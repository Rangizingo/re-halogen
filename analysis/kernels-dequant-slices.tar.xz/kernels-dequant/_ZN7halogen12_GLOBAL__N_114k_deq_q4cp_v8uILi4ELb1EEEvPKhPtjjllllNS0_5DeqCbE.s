000000000027b900 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE>:
; _ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE():
	s_mov_b32 s3, exec_lo                                      // 00000027B900: BE83007E
	v_cmpx_eq_u32_e32 0, v0                                    // 00000027B904: 7D940080
	s_cbranch_execz 28                                         // 00000027B908: BFA5001C <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x7c>
	s_load_b512 s[4:19], s[0:1], 0x38                          // 00000027B90C: F4100100 F8000038
	s_waitcnt lgkmcnt(0)                                       // 00000027B914: BF89FC07
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v2, s5             // 00000027B918: CA100080 11020005
	v_dual_mov_b32 v1, s4 :: v_dual_mov_b32 v4, s7             // 00000027B920: CA100004 01040007
	v_dual_mov_b32 v3, s6 :: v_dual_mov_b32 v6, s9             // 00000027B928: CA100006 03060009
	v_dual_mov_b32 v5, s8 :: v_dual_mov_b32 v8, s11            // 00000027B930: CA100008 0508000B
	v_dual_mov_b32 v7, s10 :: v_dual_mov_b32 v10, s13          // 00000027B938: CA10000A 070A000D
	v_dual_mov_b32 v9, s12 :: v_dual_mov_b32 v12, s15          // 00000027B940: CA10000C 090C000F
	v_dual_mov_b32 v11, s14 :: v_dual_mov_b32 v14, s17         // 00000027B948: CA10000E 0B0E0011
	v_dual_mov_b32 v13, s16 :: v_dual_mov_b32 v16, s19         // 00000027B950: CA100010 0D100013
	v_mov_b32_e32 v15, s18                                     // 00000027B958: 7E1E0212
	ds_store_b128 v17, v[1:4]                                  // 00000027B95C: DB7C0000 00000111
	ds_store_b128 v17, v[5:8] offset:16                        // 00000027B964: DB7C0010 00000511
	ds_store_b128 v17, v[9:12] offset:32                       // 00000027B96C: DB7C0020 00000911
	ds_store_b128 v17, v[13:16] offset:48                      // 00000027B974: DB7C0030 00000D11
	s_or_b32 exec_lo, exec_lo, s3                              // 00000027B97C: 8C7E037E
	s_load_b64 s[16:17], s[0:1], 0x10                          // 00000027B980: F4040400 F8000010
	s_lshl_b32 s21, s2, 10                                     // 00000027B988: 84158A02
	s_waitcnt lgkmcnt(0)                                       // 00000027B98C: BF89FC07
	s_cmp_ge_u32 s21, s17                                      // 00000027B990: BF091115
	s_cbranch_scc1 1573                                        // 00000027B994: BFA20625 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x192c>
	s_load_b256 s[4:11], s[0:1], 0x18                          // 00000027B998: F40C0100 F8000018
	s_cvt_f32_u32 s3, s16                                      // 00000027B9A0: BE836510
	s_load_b128 s[12:15], s[0:1], null                         // 00000027B9A4: F4080300 F8000000
	v_mov_b32_e32 v8, 0                                        // 00000027B9AC: 7E100280
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 00000027B9B0: BF8702A9
	v_rcp_iflag_f32_e32 v1, s3                                 // 00000027B9B4: 7E025603
	s_load_b32 s3, s[0:1], 0x78                                // 00000027B9B8: F40000C0 F8000078
	v_readfirstlane_b32 s18, v1                                // 00000027B9C0: 7E240501
	s_mul_f32 s18, s18, 0x4f7ffffe                             // 00000027B9C4: A212FF12 4F7FFFFE
	s_waitcnt lgkmcnt(0)                                       // 00000027B9CC: BF89FC07
	s_lshr_b32 s0, s5, 31                                      // 00000027B9D0: 85009F05
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027B9D4: BF870009
	s_add_u32 s0, s4, s0                                       // 00000027B9D8: 80000004
	s_addc_u32 s1, s5, 0                                       // 00000027B9DC: 82018005
	s_cvt_u32_f32 s20, s18                                     // 00000027B9E0: BE946712
	s_ashr_i64 s[18:19], s[0:1], 1                             // 00000027B9E4: 86928100
	s_add_u32 s6, s12, s6                                      // 00000027B9E8: 8006060C
	s_addc_u32 s7, s13, s7                                     // 00000027B9EC: 8207070D
	s_add_u32 s8, s12, s8                                      // 00000027B9F0: 8008080C
	s_addc_u32 s9, s13, s9                                     // 00000027B9F4: 8209090D
	s_sub_i32 s0, 0, s16                                       // 00000027B9F8: 81801080
	s_mov_b32 s12, 0                                           // 00000027B9FC: BE8C0080
	s_mul_i32 s0, s0, s20                                      // 00000027BA00: 96001400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000027BA04: BF870499
	s_mul_hi_u32 s0, s20, s0                                   // 00000027BA08: 96800014
	s_add_i32 s13, s20, s0                                     // 00000027BA0C: 810D0014
	s_mov_b32 s20, -1                                          // 00000027BA10: BE9400C1
	s_branch 7                                                 // 00000027BA14: BFA00007 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x134>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027BA18: 8C7E017E
	s_add_i32 s2, s2, s3                                       // 00000027BA1C: 81020302
	s_mov_b32 s20, 0                                           // 00000027BA20: BE940080
	s_lshl_b32 s21, s2, 10                                     // 00000027BA24: 84158A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027BA28: BF870009
	s_cmp_lt_u32 s21, s17                                      // 00000027BA2C: BF0A1115
	s_cbranch_scc0 1534                                        // 00000027BA30: BFA105FE <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x192c>
	v_or_b32_e32 v21, s21, v0                                  // 00000027BA34: 382A0015
	s_add_i32 s0, s21, 0x400                                   // 00000027BA38: 8100FF15 00000400
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027BA40: BF870009
	s_cmp_le_u32 s0, s17                                       // 00000027BA44: BF0B1100
	s_cselect_b32 s21, -1, 0                                   // 00000027BA48: 981580C1
	s_waitcnt vmcnt(3)                                         // 00000027BA4C: BF890FF7
	.long 0xd72d0001                                           // 00000027BA50: D72D0001
	v_cndmask_b32_e32 v0, v21, v13, vcc_lo                     // 00000027BA54: 02001B15
	v_add_nc_u32_e32 v11, 0x300, v21                           // 00000027BA58: 4A162AFF 00000300
	s_cmp_gt_u32 s0, s17                                       // 00000027BA60: BF081100
	s_mov_b32 s0, -1                                           // 00000027BA64: BE8000C1
	v_add_nc_u32_e32 v14, 0x100, v21                           // 00000027BA68: 4A1C2AFF 00000100
	v_add_nc_u32_e32 v12, 0x200, v21                           // 00000027BA70: 4A182AFF 00000200
	.long 0xd72d0005                                           // 00000027BA78: D72D0005
	v_cndmask_b32_e32 v0, v11, v13, vcc_lo                     // 00000027BA7C: 02001B0B
	s_waitcnt vmcnt(2)                                         // 00000027BA80: BF890BF7
	.long 0xd72c0002                                           // 00000027BA84: D72C0002
	v_cndmask_b32_e32 v0, v1, v16, vcc_lo                      // 00000027BA88: 02002101
	.long 0xd72d0007                                           // 00000027BA8C: D72D0007
	v_cndmask_b32_e32 v0, v14, v13, vcc_lo                     // 00000027BA90: 02001B0E
	.long 0xd72d0006                                           // 00000027BA94: D72D0006
	v_cndmask_b32_e32 v0, v12, v13, vcc_lo                     // 00000027BA98: 02001B0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027BA9C: BF870093
	v_sub_nc_u32_e32 v2, v21, v2                               // 00000027BAA0: 4C040515
	v_subrev_nc_u32_e32 v4, s16, v2                            // 00000027BAA4: 4E080410
	v_cmp_le_u32_e32 vcc_lo, s16, v2                           // 00000027BAA8: 7C960410
	s_waitcnt vmcnt(1)                                         // 00000027BAAC: BF8907F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027BAB0: BF870092
	v_dual_cndmask_b32 v2, v2, v4 :: v_dual_add_nc_u32 v3, 1, v1// 00000027BAB4: CA600902 02020281
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000027BABC: 02020701
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027BAC0: BF870112
	v_cmp_le_u32_e32 vcc_lo, s16, v2                           // 00000027BAC4: 7C960410
	v_add_nc_u32_e32 v3, 1, v1                                 // 00000027BAC8: 4A060281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027BACC: BF870091
	v_cndmask_b32_e32 v15, v1, v3, vcc_lo                      // 00000027BAD0: 021E0701
	.long 0xd72c0001                                           // 00000027BAD4: D72C0001
	v_cndmask_b32_e32 v0, v15, v16, vcc_lo                     // 00000027BAD8: 0200210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027BADC: BF870091
	v_sub_nc_u32_e32 v1, v21, v1                               // 00000027BAE0: 4C020315
	v_lshlrev_b32_e32 v16, 3, v1                               // 00000027BAE4: 30200283
	s_cbranch_scc1 174                                         // 00000027BAE8: BFA200AE <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x4a4>
	.long 0xd72c0003                                           // 00000027BAEC: D72C0003
	v_cndmask_b32_e32 v0, v7, v16, vcc_lo                      // 00000027BAF0: 02002107
	v_add_nc_u32_e32 v10, 1, v7                                // 00000027BAF4: 4A140E81
	v_mad_u64_u32 v[1:2], null, s18, v15, s[6:7]               // 00000027BAF8: D6FE7C01 001A1E12
	.long 0xd72c0012                                           // 00000027BB00: D72C0012
	v_cndmask_b32_e32 v0, v6, v16, vcc_lo                      // 00000027BB04: 02002106
	v_lshrrev_b32_e32 v17, 4, v16                              // 00000027BB08: 32222084
	s_waitcnt vmcnt(0)                                         // 00000027BB0C: BF8903F7
	v_add_nc_u32_e32 v22, 1, v6                                // 00000027BB10: 4A2C0C81
	v_lshrrev_b32_e32 v13, 1, v16                              // 00000027BB14: 321A2081
	.long 0xd72c0017                                           // 00000027BB18: D72C0017
	v_cndmask_b32_e32 v0, v5, v16, vcc_lo                      // 00000027BB1C: 02002105
	v_sub_nc_u32_e32 v9, v14, v3                               // 00000027BB20: 4C12070E
	v_mad_u64_u32 v[3:4], null, s10, v15, s[8:9]               // 00000027BB24: D6FE7C03 00221E0A
	v_and_b32_e32 v24, 0xffffffe, v17                          // 00000027BB2C: 363022FF 0FFFFFFE
	.long 0xd700001a                                           // 00000027BB34: D700001A
	v_cndmask_b32_e32 v1, v1, v13, vcc_lo                      // 00000027BB38: 02021B01
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000027BB3C: BF870124
	v_subrev_nc_u32_e32 v19, s16, v9                           // 00000027BB40: 4E261210
	v_cmp_le_u32_e32 vcc_lo, s16, v9                           // 00000027BB44: 7C961210
	v_dual_cndmask_b32 v20, v7, v10 :: v_dual_cndmask_b32 v19, v9, v19// 00000027BB48: CA521507 14122709
	v_mad_u64_u32 v[9:10], null, s19, v15, v[2:3]              // 00000027BB50: D6FE7C09 040A1E13
	v_sub_nc_u32_e32 v2, v12, v18                              // 00000027BB58: 4C04250C
	v_mad_u64_u32 v[17:18], null, s11, v15, v[4:5]             // 00000027BB5C: D6FE7C11 04121E0B
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027BB64: BF870004
	v_add_nc_u32_e32 v25, 1, v20                               // 00000027BB68: 4A322881
	v_cmp_le_u32_e32 vcc_lo, s16, v19                          // 00000027BB6C: 7C962610
	v_sub_nc_u32_e32 v10, v11, v23                             // 00000027BB70: 4C142F0B
	v_subrev_nc_u32_e32 v18, s16, v2                           // 00000027BB74: 4E240410
	v_add_co_ci_u32_e64 v27, null, 0, v9, s0                   // 00000027BB78: D5207C1B 00021280
	v_cndmask_b32_e32 v20, v20, v25, vcc_lo                    // 00000027BB80: 02283314
	v_cmp_le_u32_e32 vcc_lo, s16, v2                           // 00000027BB84: 7C960410
	v_cndmask_b32_e32 v4, v6, v22, vcc_lo                      // 00000027BB88: 02082D06
	v_cndmask_b32_e32 v9, v2, v18, vcc_lo                      // 00000027BB8C: 02122502
	.long 0xd7006a1c                                           // 00000027BB90: D7006A1C
	v_cndmask_b32_e32 v1, v3, v24, vcc_lo                      // 00000027BB94: 02023103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000027BB98: BF870211
	v_add_co_ci_u32_e64 v29, null, 0, v17, vcc_lo              // 00000027BB9C: D5207C1D 01AA2280
	v_add_nc_u32_e32 v13, 1, v4                                // 00000027BBA4: 4A1A0881
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027BBA8: BF870004
	v_cmp_le_u32_e32 vcc_lo, s16, v9                           // 00000027BBAC: 7C961210
	.long 0xd72c0013                                           // 00000027BBB0: D72C0013
	v_cndmask_b32_e32 v0, v20, v16, vcc_lo                     // 00000027BBB4: 02002114
	v_mad_u64_u32 v[1:2], null, s18, v20, s[6:7]               // 00000027BBB8: D6FE7C01 001A2812
	v_add_nc_u32_e32 v9, 1, v5                                 // 00000027BBC0: 4A120A81
	v_cndmask_b32_e32 v17, v4, v13, vcc_lo                     // 00000027BBC4: 02221B04
	v_mad_u64_u32 v[3:4], null, s10, v20, s[8:9]               // 00000027BBC8: D6FE7C03 0022280A
	v_subrev_nc_u32_e32 v13, s16, v10                          // 00000027BBD0: 4E1A1410
	v_cmp_le_u32_e32 vcc_lo, s16, v10                          // 00000027BBD4: 7C961410
	v_sub_nc_u32_e32 v22, v14, v19                             // 00000027BBD8: 4C2C270E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000027BBDC: BF8701A4
	v_mad_u64_u32 v[18:19], null, s19, v20, v[2:3]             // 00000027BBE0: D6FE7C12 040A2813
	.long 0xd72c0002                                           // 00000027BBE8: D72C0002
	v_cndmask_b32_e32 v0, v17, v16, vcc_lo                     // 00000027BBEC: 02002111
	v_lshlrev_b32_e32 v23, 3, v22                              // 00000027BBF0: 302E2C83
	v_mad_u64_u32 v[24:25], null, s11, v20, v[4:5]             // 00000027BBF4: D6FE7C18 0412280B
	v_cndmask_b32_e32 v4, v10, v13, vcc_lo                     // 00000027BBFC: 02081B0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000027BC00: BF870254
	v_sub_nc_u32_e32 v34, v12, v2                              // 00000027BC04: 4C44050C
	v_cndmask_b32_e32 v19, v5, v9, vcc_lo                      // 00000027BC08: 02261305
	v_lshrrev_b32_e32 v9, 1, v22                               // 00000027BC0C: 32122C81
	v_lshrrev_b32_e32 v22, 1, v23                              // 00000027BC10: 322C2E81
	v_cmp_le_u32_e32 vcc_lo, s16, v4                           // 00000027BC14: 7C960810
	v_add_nc_u32_e32 v13, 1, v19                               // 00000027BC18: 4A1A2681
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000027BC1C: BF8701A4
	v_and_b32_e32 v25, 0xffffffe, v9                           // 00000027BC20: 363212FF 0FFFFFFE
	v_mad_u64_u32 v[9:10], null, s18, v17, s[6:7]              // 00000027BC28: D6FE7C09 001A2212
	v_cndmask_b32_e32 v13, v19, v13, vcc_lo                    // 00000027BC30: 021A1B13
	.long 0xd7006a1e                                           // 00000027BC34: D7006A1E
	v_cndmask_b32_e32 v1, v1, v22, vcc_lo                      // 00000027BC38: 02022D01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000027BC3C: BF8700B1
	v_add_co_ci_u32_e64 v31, null, 0, v18, vcc_lo              // 00000027BC40: D5207C1F 01AA2480
	v_lshlrev_b32_e32 v18, 3, v34                              // 00000027BC48: 30244483
	.long 0xd7006a20                                           // 00000027BC4C: D7006A20
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 00000027BC50: 02023303
	v_add_co_ci_u32_e64 v33, null, 0, v24, vcc_lo              // 00000027BC54: D5207C21 01AA3080
	v_mad_u64_u32 v[24:25], null, s19, v17, v[10:11]           // 00000027BC5C: D6FE7C18 042A2213
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000027BC64: BF8701B4
	v_lshrrev_b32_e32 v10, 1, v18                              // 00000027BC68: 32142481
	v_lshrrev_b32_e32 v19, 1, v34                              // 00000027BC6C: 32264481
	v_mad_u64_u32 v[1:2], null, s10, v17, s[8:9]               // 00000027BC70: D6FE7C01 0022220A
	.long 0xd7006a22                                           // 00000027BC78: D7006A22
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000027BC7C: 02021509
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000027BC80: BF870243
	v_and_b32_e32 v10, 0xffffffe, v19                          // 00000027BC84: 361426FF 0FFFFFFE
	.long 0xd72c0004                                           // 00000027BC8C: D72C0004
	v_cndmask_b32_e32 v0, v13, v16, vcc_lo                     // 00000027BC90: 0200210D
	v_add_co_ci_u32_e64 v35, null, 0, v24, vcc_lo              // 00000027BC94: D5207C23 01AA3080
	v_mad_u64_u32 v[24:25], null, s18, v13, s[6:7]             // 00000027BC9C: D6FE7C18 001A1A12
	.long 0xd7006a01                                           // 00000027BCA4: D7006A01
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 00000027BCA8: 02021501
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000027BCAC: BF870124
	v_sub_nc_u32_e32 v22, v11, v4                              // 00000027BCB0: 4C2C090B
	v_mad_u64_u32 v[3:4], null, s10, v13, s[8:9]               // 00000027BCB4: D6FE7C03 00221A0A
	v_lshlrev_b32_e32 v9, 3, v22                               // 00000027BCBC: 30122C83
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000027BCC0: BF870222
	v_mad_u64_u32 v[36:37], null, s11, v17, v[2:3]             // 00000027BCC4: D6FE7C24 040A220B
	v_lshrrev_b32_e32 v2, 1, v22                               // 00000027BCCC: 32042C81
	v_mad_u64_u32 v[37:38], null, s11, v13, v[4:5]             // 00000027BCD0: D6FE7C25 04121A0B
	v_mad_u64_u32 v[38:39], null, s19, v13, v[25:26]           // 00000027BCD8: D6FE7C26 04661A13
	v_lshrrev_b32_e32 v10, 1, v9                               // 00000027BCE0: 32141281
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000027BCE4: BF870124
	v_and_b32_e32 v4, 0xffffffe, v2                            // 00000027BCE8: 360804FF 0FFFFFFE
	v_add_co_ci_u32_e64 v2, null, 0, v36, vcc_lo               // 00000027BCF0: D5207C02 01AA4880
	.long 0xd7006a24                                           // 00000027BCF8: D7006A24
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 00000027BCFC: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000027BD00: BF8700A1
	v_add_co_ci_u32_e64 v37, null, 0, v37, vcc_lo              // 00000027BD04: D5207C25 01AA4A80
	.long 0xd7006a18                                           // 00000027BD0C: D7006A18
	v_cndmask_b32_e32 v1, v24, v10, vcc_lo                     // 00000027BD10: 02021518
	v_add_co_ci_u32_e64 v25, null, 0, v38, vcc_lo              // 00000027BD14: D5207C19 01AA4C80
	s_clause 0x7                                               // 00000027BD1C: BF850007
	global_load_d16_b16 v4, v[28:29], off                      // 00000027BD20: DC820000 047C001C
	global_load_d16_hi_b16 v4, v[32:33], off                   // 00000027BD28: DC8E0000 047C0020
	global_load_d16_b16 v10, v[1:2], off                       // 00000027BD30: DC820000 0A7C0001
	global_load_d16_hi_b16 v10, v[36:37], off                  // 00000027BD38: DC8E0000 0A7C0024
	global_load_b32 v1, v[26:27], off                          // 00000027BD40: DC520000 017C001A
	global_load_b32 v2, v[30:31], off                          // 00000027BD48: DC520000 027C001E
	global_load_b32 v3, v[34:35], off                          // 00000027BD50: DC520000 037C0022
	global_load_b32 v22, v[24:25], off                         // 00000027BD58: DC520000 167C0018
	s_waitcnt vmcnt(6)                                         // 00000027BD60: BF891BF7
	v_cvt_f32_f16_e32 v26, v4                                  // 00000027BD64: 7E341704
	v_cvt_f32_f16_e32 v25, v132/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000027BD68: 7E321784
	s_waitcnt vmcnt(4)                                         // 00000027BD6C: BF8913F7
	v_cvt_f32_f16_e32 v24, v10                                 // 00000027BD70: 7E30170A
	v_cvt_f32_f16_e32 v19, v138/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000027BD74: 7E26178A
	s_cbranch_execz 12                                         // 00000027BD78: BFA5000C <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x4ac>
	s_and_not1_b32 vcc_lo, exec_lo, s20                        // 00000027BD7C: 916A147E
	s_cbranch_vccnz 255                                        // 00000027BD80: BFA400FF <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x880>
	s_waitcnt vmcnt(0)                                         // 00000027BD84: BF8903F7
	s_barrier                                                  // 00000027BD88: BFBD0000
	buffer_gl0_inv                                             // 00000027BD8C: E0AC0000 00000000
	s_and_not1_b32 vcc_lo, exec_lo, s21                        // 00000027BD94: 916A157E
	s_cbranch_vccz 251                                         // 00000027BD98: BFA300FB <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x888>
	s_mov_b32 s0, 0                                            // 00000027BD9C: BE800080
	s_branch 744                                               // 00000027BDA0: BFA002E8 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x1044>
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000027BDA4: 916A007E
	s_cbranch_vccnz 65524                                      // 00000027BDA8: BFA4FFF4 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x47c>
	s_mov_b32 s0, exec_lo                                      // 00000027BDAC: BE80007E
	.long 0xd4cb007e                                           // 00000027BDB0: D4CB007E
	v_cndmask_b32_e32 v1, s17, v21, vcc_lo                     // 00000027BDB4: 02022A11
	s_xor_b32 s0, exec_lo, s0                                  // 00000027BDB8: 8D00007E
	s_cbranch_execz 2                                          // 00000027BDBC: BFA50002 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x4c8>
	s_waitcnt vmcnt(1)                                         // 00000027BDC0: BF8907F7
	v_mov_b32_e32 v1, s12                                      // 00000027BDC4: 7E02020C
	s_or_saveexec_b32 s0, s0                                   // 00000027BDC8: BE802200
	v_mov_b32_e32 v26, 0                                       // 00000027BDCC: 7E340280
	s_xor_b32 exec_lo, exec_lo, s0                             // 00000027BDD0: 8D7E007E
	s_cbranch_execz 33                                         // 00000027BDD4: BFA50021 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x55c>
	s_waitcnt vmcnt(2)                                         // 00000027BDD8: BF890BF7
	v_mad_u64_u32 v[1:2], null, s10, v15, s[8:9]               // 00000027BDDC: D6FE7C01 00221E0A
	s_waitcnt vmcnt(1)                                         // 00000027BDE4: BF8907F7
	v_mad_u64_u32 v[3:4], null, s18, v15, s[6:7]               // 00000027BDE8: D6FE7C03 001A1E12
	v_lshrrev_b32_e32 v13, 4, v16                              // 00000027BDF0: 321A2084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027BDF4: BF870112
	v_mad_u64_u32 v[9:10], null, s11, v15, v[2:3]              // 00000027BDF8: D6FE7C09 040A1E0B
	v_and_b32_e32 v2, 0xffffffe, v13                           // 00000027BE00: 36041AFF 0FFFFFFE
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000027BE08: BF8701A4
	v_mad_u64_u32 v[17:18], null, s19, v15, v[4:5]             // 00000027BE0C: D6FE7C11 04121E13
	v_lshrrev_b32_e32 v4, 1, v16                               // 00000027BE14: 32082081
	.long 0xd7006a01                                           // 00000027BE18: D7006A01
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000027BE1C: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027BE20: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v9, vcc_lo                // 00000027BE24: D5207C02 01AA1280
	.long 0xd7006a03                                           // 00000027BE2C: D7006A03
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 00000027BE30: 02020903
	s_delay_alu instid0(VALU_DEP_1)                            // 00000027BE34: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v17, vcc_lo               // 00000027BE38: D5207C04 01AA2280
	s_clause 0x1                                               // 00000027BE40: BF850001
	global_load_d16_b16 v2, v[1:2], off                        // 00000027BE44: DC820000 027C0001
	global_load_b32 v1, v[3:4], off                            // 00000027BE4C: DC520000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000027BE54: BF8907F7
	v_cvt_f32_f16_e32 v26, v2                                  // 00000027BE58: 7E341702
	s_or_b32 exec_lo, exec_lo, s0                              // 00000027BE5C: 8C7E007E
	.long 0xd72c0004                                           // 00000027BE60: D72C0004
	v_cndmask_b32_e32 v0, v7, v16, vcc_lo                      // 00000027BE64: 02002107
	.long 0xd44b0001                                           // 00000027BE68: D44B0001
	v_cndmask_b32_e32 v1, s17, v14, vcc_lo                     // 00000027BE6C: 02021C11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027BE70: BF870092
	v_sub_nc_u32_e32 v4, v14, v4                               // 00000027BE74: 4C08090E
	v_subrev_nc_u32_e32 v9, s16, v4                            // 00000027BE78: 4E120810
	v_cmp_le_u32_e32 vcc_lo, s16, v4                           // 00000027BE7C: 7C960810
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027BE80: BF870092
	v_cndmask_b32_e32 v4, v4, v9, vcc_lo                       // 00000027BE84: 02081304
	.long 0xd44b0000                                           // 00000027BE88: D44B0000
	v_cndmask_b32_e32 v1, s16, v4, vcc_lo                      // 00000027BE8C: 02020810
	s_and_saveexec_b32 s22, s1                                 // 00000027BE90: BE962001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027BE94: BF870009
	s_xor_b32 s1, exec_lo, s22                                 // 00000027BE98: 8D01167E
	s_cbranch_execz 2                                          // 00000027BE9C: BFA50002 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x5a8>
	s_waitcnt vmcnt(2)                                         // 00000027BEA0: BF890BF7
	v_mov_b32_e32 v2, s12                                      // 00000027BEA4: 7E04020C
	s_or_saveexec_b32 s1, s1                                   // 00000027BEA8: BE812201
	v_dual_mov_b32 v25, 0 :: v_dual_add_nc_u32 v4, 1, v7       // 00000027BEAC: CA200080 19040E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027BEB4: BF870091
	v_cndmask_b32_e32 v4, v7, v4, vcc_lo                       // 00000027BEB8: 02080907
	v_add_nc_u32_e32 v7, 1, v4                                 // 00000027BEBC: 4A0E0881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027BEC0: BF870091
	v_cndmask_b32_e64 v20, v4, v7, s0                          // 00000027BEC4: D5010014 00020F04
	.long 0xd72c0004                                           // 00000027BECC: D72C0004
	v_cndmask_b32_e32 v0, v20, v16, vcc_lo                     // 00000027BED0: 02002114
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027BED4: BF870091
	v_sub_nc_u32_e32 v4, v14, v4                               // 00000027BED8: 4C08090E
	v_lshlrev_b32_e32 v23, 3, v4                               // 00000027BEDC: 302E0883
	s_xor_b32 exec_lo, exec_lo, s1                             // 00000027BEE0: 8D7E017E
	s_cbranch_execz 30                                         // 00000027BEE4: BFA5001E <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x660>
	v_mad_u64_u32 v[9:10], null, s10, v20, s[8:9]              // 00000027BEE8: D6FE7C09 0022280A
	v_mad_u64_u32 v[17:18], null, s18, v20, s[6:7]             // 00000027BEF0: D6FE7C11 001A2812
	s_waitcnt vmcnt(2)                                         // 00000027BEF8: BF890BF7
	v_lshrrev_b32_e32 v2, 4, v23                               // 00000027BEFC: 32042E84
	v_lshrrev_b32_e32 v4, 1, v23                               // 00000027BF00: 32082E81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000027BF04: BF8701B2
	v_and_b32_e32 v2, 0xffffffe, v2                            // 00000027BF08: 360404FF 0FFFFFFE
	v_mad_u64_u32 v[24:25], null, s11, v20, v[10:11]           // 00000027BF10: D6FE7C18 042A280B
	v_mad_u64_u32 v[18:19], null, s19, v20, v[18:19]           // 00000027BF18: D6FE7C12 044A2813
	.long 0xd7006a09                                           // 00000027BF20: D7006A09
	v_cndmask_b32_e32 v1, v9, v2, vcc_lo                       // 00000027BF24: 02020509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000027BF28: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v24, vcc_lo              // 00000027BF2C: D5207C0A 01AA3080
	.long 0xd7006a11                                           // 00000027BF34: D7006A11
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 00000027BF38: 02020911
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 00000027BF3C: D5207C12 01AA2480
	s_clause 0x1                                               // 00000027BF44: BF850001
	global_load_d16_b16 v4, v[9:10], off                       // 00000027BF48: DC820000 047C0009
	global_load_b32 v2, v[17:18], off                          // 00000027BF50: DC520000 027C0011
	s_waitcnt vmcnt(1)                                         // 00000027BF58: BF8907F7
	v_cvt_f32_f16_e32 v25, v4                                  // 00000027BF5C: 7E321704
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027BF60: 8C7E017E
	.long 0xd72c0004                                           // 00000027BF64: D72C0004
	v_cndmask_b32_e32 v0, v6, v16, vcc_lo                      // 00000027BF68: 02002106
	.long 0xd44b0001                                           // 00000027BF6C: D44B0001
	v_cndmask_b32_e32 v1, s17, v12, vcc_lo                     // 00000027BF70: 02021811
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027BF74: BF870092
	v_sub_nc_u32_e32 v4, v12, v4                               // 00000027BF78: 4C08090C
	v_subrev_nc_u32_e32 v7, s16, v4                            // 00000027BF7C: 4E0E0810
	v_cmp_le_u32_e32 vcc_lo, s16, v4                           // 00000027BF80: 7C960810
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027BF84: BF870092
	v_cndmask_b32_e32 v4, v4, v7, vcc_lo                       // 00000027BF88: 02080F04
	.long 0xd44b0000                                           // 00000027BF8C: D44B0000
	v_cndmask_b32_e32 v1, s16, v4, vcc_lo                      // 00000027BF90: 02020810
	s_and_saveexec_b32 s22, s1                                 // 00000027BF94: BE962001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027BF98: BF870009
	s_xor_b32 s1, exec_lo, s22                                 // 00000027BF9C: 8D01167E
	s_cbranch_execz 2                                          // 00000027BFA0: BFA50002 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x6ac>
	s_waitcnt vmcnt(1)                                         // 00000027BFA4: BF8907F7
	v_mov_b32_e32 v3, s12                                      // 00000027BFA8: 7E06020C
	s_or_saveexec_b32 s1, s1                                   // 00000027BFAC: BE812201
	v_add_nc_u32_e32 v4, 1, v6                                 // 00000027BFB0: 4A080C81
	v_mov_b32_e32 v24, 0                                       // 00000027BFB4: 7E300280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027BFB8: BF870092
	v_cndmask_b32_e32 v4, v6, v4, vcc_lo                       // 00000027BFBC: 02080906
	v_add_nc_u32_e32 v6, 1, v4                                 // 00000027BFC0: 4A0C0881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027BFC4: BF870091
	v_cndmask_b32_e64 v17, v4, v6, s0                          // 00000027BFC8: D5010011 00020D04
	.long 0xd72c0004                                           // 00000027BFD0: D72C0004
	v_cndmask_b32_e32 v0, v17, v16, vcc_lo                     // 00000027BFD4: 02002111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027BFD8: BF870091
	v_sub_nc_u32_e32 v4, v12, v4                               // 00000027BFDC: 4C08090C
	v_lshlrev_b32_e32 v18, 3, v4                               // 00000027BFE0: 30240883
	s_xor_b32 exec_lo, exec_lo, s1                             // 00000027BFE4: 8D7E017E
	s_cbranch_execz 32                                         // 00000027BFE8: BFA50020 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x76c>
	s_waitcnt vmcnt(1)                                         // 00000027BFEC: BF8907F7
	v_mad_u64_u32 v[3:4], null, s10, v17, s[8:9]               // 00000027BFF0: D6FE7C03 0022220A
	v_mad_u64_u32 v[6:7], null, s18, v17, s[6:7]               // 00000027BFF8: D6FE7C06 001A2212
	v_lshrrev_b32_e32 v13, 4, v18                              // 00000027C000: 321A2484
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027C004: BF870113
	v_mad_u64_u32 v[9:10], null, s11, v17, v[4:5]              // 00000027C008: D6FE7C09 0412220B
	v_and_b32_e32 v4, 0xffffffe, v13                           // 00000027C010: 36081AFF 0FFFFFFE
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000027C018: BF8701A4
	v_mad_u64_u32 v[27:28], null, s19, v17, v[7:8]             // 00000027C01C: D6FE7C1B 041E2213
	v_lshrrev_b32_e32 v7, 1, v18                               // 00000027C024: 320E2481
	.long 0xd7006a03                                           // 00000027C028: D7006A03
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 00000027C02C: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027C030: BF870191
	v_add_co_ci_u32_e64 v4, null, 0, v9, vcc_lo                // 00000027C034: D5207C04 01AA1280
	.long 0xd7006a06                                           // 00000027C03C: D7006A06
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                       // 00000027C040: 02020F06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000027C044: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v27, vcc_lo               // 00000027C048: D5207C07 01AA3680
	s_clause 0x1                                               // 00000027C050: BF850001
	global_load_d16_b16 v4, v[3:4], off                        // 00000027C054: DC820000 047C0003
	global_load_b32 v3, v[6:7], off                            // 00000027C05C: DC520000 037C0006
	s_waitcnt vmcnt(1)                                         // 00000027C064: BF8907F7
	v_cvt_f32_f16_e32 v24, v4                                  // 00000027C068: 7E301704
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027C06C: 8C7E017E
	.long 0xd72c0004                                           // 00000027C070: D72C0004
	v_cndmask_b32_e32 v0, v5, v16, vcc_lo                      // 00000027C074: 02002105
	.long 0xd44b0001                                           // 00000027C078: D44B0001
	v_cndmask_b32_e32 v1, s17, v11, vcc_lo                     // 00000027C07C: 02021611
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027C080: BF870092
	v_sub_nc_u32_e32 v4, v11, v4                               // 00000027C084: 4C08090B
	v_subrev_nc_u32_e32 v6, s16, v4                            // 00000027C088: 4E0C0810
	v_cmp_le_u32_e32 vcc_lo, s16, v4                           // 00000027C08C: 7C960810
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027C090: BF870092
	v_cndmask_b32_e32 v4, v4, v6, vcc_lo                       // 00000027C094: 02080D04
	.long 0xd44b0000                                           // 00000027C098: D44B0000
	v_cndmask_b32_e32 v1, s16, v4, vcc_lo                      // 00000027C09C: 02020810
	s_and_saveexec_b32 s22, s1                                 // 00000027C0A0: BE962001
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000027C0A4: BF870499
	s_xor_b32 s1, exec_lo, s22                                 // 00000027C0A8: 8D01167E
	s_or_saveexec_b32 s1, s1                                   // 00000027C0AC: BE812201
	v_dual_mov_b32 v19, 0 :: v_dual_add_nc_u32 v4, 1, v5       // 00000027C0B0: CA200080 13040A81
	s_waitcnt vmcnt(0)                                         // 00000027C0B8: BF8903F7
	v_mov_b32_e32 v22, 0                                       // 00000027C0BC: 7E2C0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027C0C0: BF870092
	v_cndmask_b32_e32 v4, v5, v4, vcc_lo                       // 00000027C0C4: 02080905
	v_add_nc_u32_e32 v5, 1, v4                                 // 00000027C0C8: 4A0A0881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027C0CC: BF870091
	v_cndmask_b32_e64 v13, v4, v5, s0                          // 00000027C0D0: D501000D 00020B04
	.long 0xd72c0004                                           // 00000027C0D8: D72C0004
	v_cndmask_b32_e32 v0, v13, v16, vcc_lo                     // 00000027C0DC: 0200210D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027C0E0: BF870091
	v_sub_nc_u32_e32 v4, v11, v4                               // 00000027C0E4: 4C08090B
	v_lshlrev_b32_e32 v9, 3, v4                                // 00000027C0E8: 30120883
	s_xor_b32 exec_lo, exec_lo, s1                             // 00000027C0EC: 8D7E017E
	s_cbranch_execz 31                                         // 00000027C0F0: BFA5001F <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x870>
	v_mad_u64_u32 v[4:5], null, s10, v13, s[8:9]               // 00000027C0F4: D6FE7C04 00221A0A
	v_mad_u64_u32 v[6:7], null, s18, v13, s[6:7]               // 00000027C0FC: D6FE7C06 001A1A12
	v_lshrrev_b32_e32 v10, 4, v9                               // 00000027C104: 32141284
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027C108: BF870112
	v_mad_u64_u32 v[27:28], null, s11, v13, v[5:6]             // 00000027C10C: D6FE7C1B 04161A0B
	v_and_b32_e32 v5, 0xffffffe, v10                           // 00000027C114: 360A14FF 0FFFFFFE
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000027C11C: BF8701A4
	v_mad_u64_u32 v[28:29], null, s19, v13, v[7:8]             // 00000027C120: D6FE7C1C 041E1A13
	v_lshrrev_b32_e32 v7, 1, v9                                // 00000027C128: 320E1281
	.long 0xd7006a04                                           // 00000027C12C: D7006A04
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 00000027C130: 02020B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027C134: BF870191
	v_add_co_ci_u32_e64 v5, null, 0, v27, vcc_lo               // 00000027C138: D5207C05 01AA3680
	.long 0xd7006a06                                           // 00000027C140: D7006A06
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                       // 00000027C144: 02020F06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000027C148: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v28, vcc_lo               // 00000027C14C: D5207C07 01AA3880
	s_clause 0x1                                               // 00000027C154: BF850001
	global_load_d16_b16 v4, v[4:5], off                        // 00000027C158: DC820000 047C0004
	global_load_b32 v22, v[6:7], off                           // 00000027C160: DC520000 167C0006
	s_waitcnt vmcnt(1)                                         // 00000027C168: BF8907F7
	v_cvt_f32_f16_e32 v19, v4                                  // 00000027C16C: 7E261704
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027C170: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027C174: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s20                        // 00000027C178: 916A147E
	s_cbranch_vccz 65281                                       // 00000027C17C: BFA3FF01 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x484>
	s_and_not1_b32 vcc_lo, exec_lo, s21                        // 00000027C180: 916A157E
	s_cbranch_vccnz 65285                                      // 00000027C184: BFA4FF05 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x49c>
	s_waitcnt vmcnt(3)                                         // 00000027C188: BF890FF7
	v_lshrrev_b32_e32 v5, 2, v1                                // 00000027C18C: 320A0282
	v_lshrrev_b32_e32 v6, 6, v1                                // 00000027C190: 320C0286
	v_lshrrev_b32_e32 v7, 10, v1                               // 00000027C194: 320E028A
	v_lshrrev_b32_e32 v10, 14, v1                              // 00000027C198: 3214028E
	v_lshrrev_b32_e32 v27, 18, v1                              // 00000027C19C: 32360292
	v_and_b32_e32 v5, 60, v5                                   // 00000027C1A0: 360A0ABC
	v_and_b32_e32 v6, 60, v6                                   // 00000027C1A4: 360C0CBC
	s_waitcnt vmcnt(2)                                         // 00000027C1A8: BF890BF7
	v_and_b32_e32 v32, 15, v2                                  // 00000027C1AC: 3640048F
	v_and_b32_e32 v10, 60, v10                                 // 00000027C1B0: 361414BC
	v_and_b32_e32 v27, 60, v27                                 // 00000027C1B4: 363636BC
	ds_load_b32 v29, v5                                        // 00000027C1B8: D8D80000 1D000005
	ds_load_b32 v6, v6                                         // 00000027C1C0: D8D80000 06000006
	v_and_b32_e32 v7, 60, v7                                   // 00000027C1C8: 360E0EBC
	v_lshrrev_b32_e32 v5, 26, v1                               // 00000027C1CC: 320A029A
	v_lshlrev_b32_e32 v32, 2, v32                              // 00000027C1D0: 30404082
	.long 0x7f523880                                           // 00000027C1D4: 7F523880
	v_lshrrev_b32_e32 v33, 2, v2                               // 00000027C1D8: 32420482
	v_lshrrev_b32_e32 v34, 6, v2                               // 00000027C1DC: 32440486
	s_waitcnt vmcnt(1)                                         // 00000027C1E0: BF8907F7
	v_lshrrev_b32_e32 v45, 22, v3                              // 00000027C1E4: 325A0696
	v_lshrrev_b32_e32 v43, 14, v3                              // 00000027C1E8: 3256068E
	v_lshrrev_b32_e32 v44, 18, v3                              // 00000027C1EC: 32580692
	v_lshrrev_b32_e32 v46, 26, v3                              // 00000027C1F0: 325C069A
	s_mov_b32 s0, -1                                           // 00000027C1F4: BE8000C1
	ds_load_b32 v32, v32                                       // 00000027C1F8: D8D80000 20000020
	v_and_b32_e32 v44, 60, v44                                 // 00000027C200: 365858BC
	v_and_b32_e32 v46, 60, v46                                 // 00000027C204: 365C5CBC
	v_and_b32_e32 v45, 60, v45                                 // 00000027C208: 365A5ABC
	v_and_b32_e32 v43, 60, v43                                 // 00000027C20C: 365656BC
	s_waitcnt lgkmcnt(2)                                       // 00000027C210: BF89FC27
	v_mul_f32_e32 v29, v26, v29                                // 00000027C214: 103A3B1A
	s_waitcnt lgkmcnt(1)                                       // 00000027C218: BF89FC17
	v_mul_f32_e32 v6, v26, v6                                  // 00000027C21C: 100C0D1A
	ds_load_b32 v7, v7                                         // 00000027C220: D8D80000 07000007
	ds_load_b32 v10, v10                                       // 00000027C228: D8D80000 0A00000A
	ds_load_b32 v27, v27                                       // 00000027C230: D8D80000 1B00001B
	v_and_b32_e32 v4, 15, v1                                   // 00000027C238: 3608028F
	s_waitcnt lgkmcnt(3)                                       // 00000027C23C: BF89FC37
	v_dual_mul_f32 v32, v25, v32 :: v_dual_and_b32 v31, 60, v5 // 00000027C240: C8E44119 201E0ABC
	s_waitcnt lgkmcnt(2)                                       // 00000027C248: BF89FC27
	s_delay_alu instid0(VALU_DEP_2)                            // 00000027C24C: BF870002
	v_dual_mul_f32 v7, v26, v7 :: v_dual_lshlrev_b32 v4, 2, v4 // 00000027C250: C8E20F1A 07040882
	s_waitcnt lgkmcnt(0)                                       // 00000027C258: BF89FC07
	v_mul_f32_e32 v36, v26, v27                                // 00000027C25C: 1048371A
	ds_load_b32 v31, v31                                       // 00000027C260: D8D80000 1F00001F
	v_mul_f32_e32 v10, v26, v10                                // 00000027C268: 1014151A
	v_bfe_u32 v27, v29, 16, 1                                  // 00000027C26C: D610001B 0205211D
	ds_load_b32 v28, v4                                        // 00000027C274: D8D80000 1C000004
	v_lshrrev_b32_e32 v4, 22, v1                               // 00000027C27C: 32080296
	v_bfe_u32 v37, v7, 16, 1                                   // 00000027C280: D6100025 02052107
	v_add3_u32 v27, v29, v27, 0x7fff                           // 00000027C288: D655001B 03FE371D 00007FFF
	v_bfe_u32 v29, v36, 16, 1                                  // 00000027C294: D610001D 02052124
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000027C29C: BF870214
	v_and_b32_e32 v4, 60, v4                                   // 00000027C2A0: 360808BC
	v_add3_u32 v7, v7, v37, 0x7fff                             // 00000027C2A4: D6550007 03FE4B07 00007FFF
	v_lshrrev_b32_e32 v37, 26, v2                              // 00000027C2B0: 324A049A
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027C2B4: BF870004
	v_add3_u32 v29, v36, v29, 0x7fff                           // 00000027C2B8: D655001D 03FE3B24 00007FFF
	ds_load_b32 v30, v4                                        // 00000027C2C4: D8D80000 1E000004
	v_mad_u64_u32 v[4:5], null, s4, v15, 0                     // 00000027C2CC: D6FE7C04 02021E04
	v_lshrrev_b32_e32 v36, 22, v2                              // 00000027C2D4: 32480496
	v_and_b32_e32 v37, 60, v37                                 // 00000027C2D8: 364A4ABC
	s_waitcnt lgkmcnt(2)                                       // 00000027C2DC: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000027C2E0: BF8700B2
	v_dual_mul_f32 v31, v26, v31 :: v_dual_and_b32 v36, 60, v36// 00000027C2E4: C8E43F1A 1F2448BC
	s_waitcnt lgkmcnt(1)                                       // 00000027C2EC: BF89FC17
	v_mul_f32_e32 v28, v26, v28                                // 00000027C2F0: 1038391A
	v_bfe_u32 v35, v28, 16, 1                                  // 00000027C2F4: D6100023 0205211C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000027C2FC: BF870121
	v_add3_u32 v28, v28, v35, 0x7fff                           // 00000027C300: D655001C 03FE471C 00007FFF
	v_bfe_u32 v35, v6, 16, 1                                   // 00000027C30C: D6100023 02052106
	.long 0x7e52399c                                           // 00000027C314: 7E52399C
	s_delay_alu instid0(VALU_DEP_2)                            // 00000027C318: BF870002
	v_add3_u32 v6, v6, v35, 0x7fff                             // 00000027C31C: D6550006 03FE4706 00007FFF
	v_bfe_u32 v28, v10, 16, 1                                  // 00000027C328: D610001C 0205210A
	v_lshrrev_b32_e32 v35, 18, v2                              // 00000027C330: 32460492
	s_waitcnt lgkmcnt(0)                                       // 00000027C334: BF89FC07
	v_mul_f32_e32 v30, v26, v30                                // 00000027C338: 103C3D1A
	v_and_or_b32 v27, 0xffff0000, v27, v41                     // 00000027C33C: D657001B 04A636FF FFFF0000
	.long 0x7e523986                                           // 00000027C348: 7E523986
	v_add3_u32 v6, v10, v28, 0x7fff                            // 00000027C34C: D6550006 03FE390A 00007FFF
	v_and_b32_e32 v35, 60, v35                                 // 00000027C358: 364646BC
	v_bfe_u32 v10, v30, 16, 1                                  // 00000027C35C: D610000A 0205211E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000027C364: BF870214
	v_and_or_b32 v28, 0xffff0000, v7, v41                      // 00000027C368: D657001C 04A60EFF FFFF0000
	.long 0x7e523986                                           // 00000027C374: 7E523986
	v_mad_u64_u32 v[5:6], null, s5, v15, v[5:6]                // 00000027C378: D6FE7C05 04161E05
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027C380: BF870004
	v_add3_u32 v7, v30, v10, 0x7fff                            // 00000027C384: D6550007 03FE151E 00007FFF
	v_and_b32_e32 v10, 60, v33                                 // 00000027C390: 361442BC
	v_and_b32_e32 v30, 60, v34                                 // 00000027C394: 363C44BC
	ds_load_b32 v6, v10                                        // 00000027C398: D8D80000 0600000A
	ds_load_b32 v10, v30                                       // 00000027C3A0: D8D80000 0A00001E
	v_lshrrev_b32_e32 v30, 10, v2                              // 00000027C3A8: 323C048A
	v_lshrrev_b32_e32 v34, 14, v2                              // 00000027C3AC: 3244048E
	v_bfe_u32 v33, v31, 16, 1                                  // 00000027C3B0: D6100021 0205211F
	.long 0xd73c0004                                           // 00000027C3B8: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000027C3BC: 02020881
	v_and_or_b32 v29, 0xffff0000, v29, v41                     // 00000027C3C0: D657001D 04A63AFF FFFF0000
	v_and_b32_e32 v30, 60, v30                                 // 00000027C3CC: 363C3CBC
	v_and_b32_e32 v34, 60, v34                                 // 00000027C3D0: 364444BC
	ds_load_b32 v38, v30                                       // 00000027C3D4: D8D80000 2600001E
	ds_load_b32 v34, v34                                       // 00000027C3DC: D8D80000 22000022
	ds_load_b32 v35, v35                                       // 00000027C3E4: D8D80000 23000023
	ds_load_b32 v36, v36                                       // 00000027C3EC: D8D80000 24000024
	ds_load_b32 v37, v37                                       // 00000027C3F4: D8D80000 25000025
	.long 0x7e523987                                           // 00000027C3FC: 7E523987
	v_add3_u32 v7, v31, v33, 0x7fff                            // 00000027C400: D6550007 03FE431F 00007FFF
	v_bfe_u32 v31, v32, 16, 1                                  // 00000027C40C: D610001F 02052120
	.long 0xd7006a27                                           // 00000027C414: D7006A27
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 00000027C418: 0202080E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000027C41C: BF870001
	v_add_co_ci_u32_e64 v40, null, s15, v5, vcc_lo             // 00000027C420: D5207C28 01AA0A0F
	s_waitcnt lgkmcnt(6)                                       // 00000027C428: BF89FC67
	v_mul_f32_e32 v6, v25, v6                                  // 00000027C42C: 100C0D19
	s_waitcnt lgkmcnt(5)                                       // 00000027C430: BF89FC57
	v_mul_f32_e32 v10, v25, v10                                // 00000027C434: 10141519
	v_and_or_b32 v30, 0xffff0000, v7, v41                      // 00000027C438: D657001E 04A60EFF FFFF0000
	v_add3_u32 v7, v32, v31, 0x7fff                            // 00000027C444: D6550007 03FE3F20 00007FFF
	v_bfe_u32 v4, v6, 16, 1                                    // 00000027C450: D6100004 02052106
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027C458: BF870004
	v_bfe_u32 v5, v10, 16, 1                                   // 00000027C45C: D6100005 0205210A
	s_waitcnt lgkmcnt(4)                                       // 00000027C464: BF89FC47
	v_mul_f32_e32 v32, v25, v38                                // 00000027C468: 10404D19
	s_waitcnt lgkmcnt(3)                                       // 00000027C46C: BF89FC37
	v_mul_f32_e32 v33, v25, v34                                // 00000027C470: 10424519
	.long 0x7e523987                                           // 00000027C474: 7E523987
	v_add3_u32 v4, v6, v4, 0x7fff                              // 00000027C478: D6550004 03FE0906 00007FFF
	v_add3_u32 v5, v10, v5, 0x7fff                             // 00000027C484: D6550005 03FE0B0A 00007FFF
	v_bfe_u32 v6, v32, 16, 1                                   // 00000027C490: D6100006 02052120
	v_bfe_u32 v10, v33, 16, 1                                  // 00000027C498: D610000A 02052121
	v_mov_b32_e32 v7, v16                                      // 00000027C4A0: 7E0E0310
	v_and_or_b32 v31, 0xffff0000, v4, v41                      // 00000027C4A4: D657001F 04A608FF FFFF0000
	.long 0x7e523985                                           // 00000027C4B0: 7E523985
	v_add3_u32 v4, v32, v6, 0x7fff                             // 00000027C4B4: D6550004 03FE0D20 00007FFF
	s_waitcnt lgkmcnt(2)                                       // 00000027C4C0: BF89FC27
	v_mul_f32_e32 v6, v25, v35                                 // 00000027C4C4: 100C4719
	v_add3_u32 v5, v33, v10, 0x7fff                            // 00000027C4C8: D6550005 03FE1521 00007FFF
	s_waitcnt lgkmcnt(1)                                       // 00000027C4D4: BF89FC17
	v_mul_f32_e32 v10, v25, v36                                // 00000027C4D8: 10144919
	.long 0xd73c0021                                           // 00000027C4DC: D73C0021
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000027C4E0: 02020E81
	v_and_b32_e32 v36, 15, v3                                  // 00000027C4E4: 3648068F
	v_bfe_u32 v7, v6, 16, 1                                    // 00000027C4E8: D6100007 02052106
	v_and_or_b32 v32, 0xffff0000, v4, v41                      // 00000027C4F0: D6570020 04A608FF FFFF0000
	.long 0x7e523985                                           // 00000027C4FC: 7E523985
	v_mad_u64_u32 v[4:5], null, s4, v20, 0                     // 00000027C500: D6FE7C04 02022804
	v_bfe_u32 v35, v10, 16, 1                                  // 00000027C508: D6100023 0205210A
	v_add3_u32 v38, v6, v7, 0x7fff                             // 00000027C510: D6550026 03FE0F06 00007FFF
	v_lshlrev_b32_e32 v7, 2, v36                               // 00000027C51C: 300E4882
	v_lshrrev_b32_e32 v36, 6, v3                               // 00000027C520: 32480686
	s_waitcnt lgkmcnt(0)                                       // 00000027C524: BF89FC07
	v_mul_f32_e32 v37, v25, v37                                // 00000027C528: 104A4B19
	v_add3_u32 v10, v10, v35, 0x7fff                           // 00000027C52C: D655000A 03FE470A 00007FFF
	v_lshrrev_b32_e32 v35, 2, v3                               // 00000027C538: 32460682
	v_mad_u64_u32 v[5:6], null, s5, v20, v[5:6]                // 00000027C53C: D6FE7C05 04162805
	ds_load_b32 v6, v7                                         // 00000027C544: D8D80000 06000007
	v_bfe_u32 v42, v37, 16, 1                                  // 00000027C54C: D610002A 02052125
	v_and_b32_e32 v7, 60, v35                                  // 00000027C554: 360E46BC
	v_and_b32_e32 v35, 60, v36                                 // 00000027C558: 364648BC
	v_lshrrev_b32_e32 v36, 10, v3                              // 00000027C55C: 3248068A
	.long 0xd73c0004                                           // 00000027C560: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000027C564: 02020881
	s_delay_alu instid0(VALU_DEP_2)                            // 00000027C568: BF870002
	v_and_b32_e32 v36, 60, v36                                 // 00000027C56C: 364848BC
	ds_load_b32 v47, v7                                        // 00000027C570: D8D80000 2F000007
	ds_load_b32 v35, v35                                       // 00000027C578: D8D80000 23000023
	ds_load_b32 v36, v36                                       // 00000027C580: D8D80000 24000024
	ds_load_b32 v43, v43                                       // 00000027C588: D8D80000 2B00002B
	ds_load_b32 v44, v44                                       // 00000027C590: D8D80000 2C00002C
	ds_load_b32 v45, v45                                       // 00000027C598: D8D80000 2D00002D
	ds_load_b32 v46, v46                                       // 00000027C5A0: D8D80000 2E00002E
	s_waitcnt lgkmcnt(7)                                       // 00000027C5A8: BF89FC77
	v_mul_f32_e32 v48, v24, v6                                 // 00000027C5AC: 10600D18
	.long 0xd7006a06                                           // 00000027C5B0: D7006A06
	v_cndmask_b32_e32 v1, v39, v33, vcc_lo                     // 00000027C5B4: 02024327
	s_delay_alu instid0(VALU_DEP_1)                            // 00000027C5B8: BF870001
	v_add_co_ci_u32_e64 v7, null, v40, v34, vcc_lo             // 00000027C5BC: D5207C07 01AA4528
	v_and_or_b32 v33, 0xffff0000, v38, v41                     // 00000027C5C4: D6570021 04A64CFF FFFF0000
	.long 0x7e52398a                                           // 00000027C5D0: 7E52398A
	v_add3_u32 v10, v37, v42, 0x7fff                           // 00000027C5D4: D655000A 03FE5525 00007FFF
	global_store_b128 v[6:7], v[27:30], off                    // 00000027C5E0: DC760000 007C1B06
	s_waitcnt lgkmcnt(6)                                       // 00000027C5E8: BF89FC67
	v_mul_f32_e32 v7, v24, v47                                 // 00000027C5EC: 100E5F18
	v_bfe_u32 v37, v48, 16, 1                                  // 00000027C5F0: D6100025 02052130
	.long 0xd7006a1e                                           // 00000027C5F8: D7006A1E
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 00000027C5FC: 0202080E
	v_and_or_b32 v34, 0xffff0000, v10, v41                     // 00000027C600: D6570022 04A614FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000027C60C: BF870214
	v_bfe_u32 v4, v7, 16, 1                                    // 00000027C610: D6100004 02052107
	v_add3_u32 v6, v48, v37, 0x7fff                            // 00000027C618: D6550006 03FE4B30 00007FFF
	s_waitcnt lgkmcnt(5)                                       // 00000027C624: BF89FC57
	v_mul_f32_e32 v10, v24, v35                                // 00000027C628: 10144718
	v_add_co_ci_u32_e64 v37, null, s15, v5, vcc_lo             // 00000027C62C: D5207C25 01AA0A0F
	v_add3_u32 v4, v7, v4, 0x7fff                              // 00000027C634: D6550004 03FE0907 00007FFF
	v_mov_b32_e32 v7, v23                                      // 00000027C640: 7E0E0317
	.long 0x7e523986                                           // 00000027C644: 7E523986
	s_waitcnt lgkmcnt(3)                                       // 00000027C648: BF89FC37
	v_mul_f32_e32 v6, v24, v43                                 // 00000027C64C: 100C5718
	s_waitcnt vmcnt(0)                                         // 00000027C650: BF8903F7
	v_lshrrev_b32_e32 v43, 14, v22                             // 00000027C654: 32562C8E
	v_mul_f32_e32 v28, v24, v36                                // 00000027C658: 10384918
	.long 0xd73c0023                                           // 00000027C65C: D73C0023
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000027C660: 02020E81
	s_waitcnt lgkmcnt(1)                                       // 00000027C664: BF89FC17
	v_mul_f32_e32 v7, v24, v45                                 // 00000027C668: 100E5B18
	v_lshrrev_b32_e32 v45, 22, v22                             // 00000027C66C: 325A2C96
	v_bfe_u32 v29, v6, 16, 1                                   // 00000027C670: D610001D 02052106
	v_and_b32_e32 v43, 60, v43                                 // 00000027C678: 365656BC
	v_and_or_b32 v27, 0xffff0000, v4, v41                      // 00000027C67C: D657001B 04A608FF FFFF0000
	v_lshrrev_b32_e32 v42, 10, v22                             // 00000027C688: 32542C8A
	v_and_b32_e32 v45, 60, v45                                 // 00000027C68C: 365A5ABC
	v_bfe_u32 v5, v10, 16, 1                                   // 00000027C690: D6100005 0205210A
	v_add3_u32 v6, v6, v29, 0x7fff                             // 00000027C698: D6550006 03FE3B06 00007FFF
	v_lshrrev_b32_e32 v29, 2, v22                              // 00000027C6A4: 323A2C82
	s_waitcnt lgkmcnt(0)                                       // 00000027C6A8: BF89FC07
	v_mul_f32_e32 v39, v24, v46                                // 00000027C6AC: 104E5D18
	v_lshrrev_b32_e32 v46, 26, v22                             // 00000027C6B0: 325C2C9A
	v_add3_u32 v5, v10, v5, 0x7fff                             // 00000027C6B4: D6550005 03FE0B0A 00007FFF
	v_bfe_u32 v10, v28, 16, 1                                  // 00000027C6C0: D610000A 0205211C
	v_and_b32_e32 v42, 60, v42                                 // 00000027C6C8: 365454BC
	v_bfe_u32 v40, v39, 16, 1                                  // 00000027C6CC: D6100028 02052127
	v_and_b32_e32 v46, 60, v46                                 // 00000027C6D4: 365C5CBC
	.long 0x7e523985                                           // 00000027C6D8: 7E523985
	v_add3_u32 v4, v28, v10, 0x7fff                            // 00000027C6DC: D6550004 03FE151C 00007FFF
	v_mul_f32_e32 v5, v24, v44                                 // 00000027C6E8: 100A5918
	v_bfe_u32 v10, v7, 16, 1                                   // 00000027C6EC: D610000A 02052107
	v_lshrrev_b32_e32 v44, 18, v22                             // 00000027C6F4: 32582C92
	.long 0xd7006a23                                           // 00000027C6F8: D7006A23
	v_cndmask_b32_e32 v1, v30, v35, vcc_lo                     // 00000027C6FC: 0202471E
	v_and_or_b32 v28, 0xffff0000, v4, v41                      // 00000027C700: D657001C 04A608FF FFFF0000
	v_bfe_u32 v4, v5, 16, 1                                    // 00000027C70C: D6100004 02052105
	.long 0x7e523986                                           // 00000027C714: 7E523986
	v_and_b32_e32 v6, 15, v22                                  // 00000027C718: 360C2C8F
	v_and_b32_e32 v44, 60, v44                                 // 00000027C71C: 365858BC
	v_add_co_ci_u32_e64 v36, null, v37, v36, vcc_lo            // 00000027C720: D5207C24 01AA4925
	v_add3_u32 v38, v5, v4, 0x7fff                             // 00000027C728: D6550026 03FE0905 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027C734: BF870004
	v_lshlrev_b32_e32 v4, 2, v6                                // 00000027C738: 30080C82
	v_add3_u32 v6, v7, v10, 0x7fff                             // 00000027C73C: D6550006 03FE1507 00007FFF
	v_and_b32_e32 v7, 60, v29                                  // 00000027C748: 360E3ABC
	v_lshrrev_b32_e32 v10, 6, v22                              // 00000027C74C: 32142C86
	global_store_b128 v[35:36], v[31:34], off                  // 00000027C750: DC760000 007C1F23
	ds_load_b32 v29, v4                                        // 00000027C758: D8D80000 1D000004
	ds_load_b32 v7, v7                                         // 00000027C760: D8D80000 07000007
	v_and_b32_e32 v10, 60, v10                                 // 00000027C768: 361414BC
	ds_load_b32 v10, v10                                       // 00000027C76C: D8D80000 0A00000A
	ds_load_b32 v42, v42                                       // 00000027C774: D8D80000 2A00002A
	ds_load_b32 v43, v43                                       // 00000027C77C: D8D80000 2B00002B
	ds_load_b32 v44, v44                                       // 00000027C784: D8D80000 2C00002C
	ds_load_b32 v45, v45                                       // 00000027C78C: D8D80000 2D00002D
	ds_load_b32 v46, v46                                       // 00000027C794: D8D80000 2E00002E
	v_mad_u64_u32 v[4:5], null, s4, v17, 0                     // 00000027C79C: D6FE7C04 02022204
	s_waitcnt lgkmcnt(7)                                       // 00000027C7A4: BF89FC77
	v_mul_f32_e32 v47, v19, v29                                // 00000027C7A8: 105E3B13
	v_and_or_b32 v29, 0xffff0000, v38, v41                     // 00000027C7AC: D657001D 04A64CFF FFFF0000
	.long 0x7e523986                                           // 00000027C7B8: 7E523986
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027C7BC: BF870004
	v_mad_u64_u32 v[5:6], null, s5, v17, v[5:6]                // 00000027C7C0: D6FE7C05 04162205
	v_add3_u32 v38, v39, v40, 0x7fff                           // 00000027C7C8: D6550026 03FE5127 00007FFF
	v_bfe_u32 v6, v47, 16, 1                                   // 00000027C7D4: D6100006 0205212F
	s_waitcnt lgkmcnt(6)                                       // 00000027C7DC: BF89FC67
	v_mul_f32_e32 v39, v19, v7                                 // 00000027C7E0: 104E0F13
	s_waitcnt lgkmcnt(5)                                       // 00000027C7E4: BF89FC57
	v_dual_mul_f32 v10, v19, v10 :: v_dual_mov_b32 v7, v18     // 00000027C7E8: C8D01513 0A060112
	v_and_or_b32 v30, 0xffff0000, v38, v41                     // 00000027C7F0: D657001E 04A64CFF FFFF0000
	v_add3_u32 v6, v47, v6, 0x7fff                             // 00000027C7FC: D6550006 03FE0D2F 00007FFF
	v_bfe_u32 v40, v39, 16, 1                                  // 00000027C808: D6100028 02052127
	.long 0xd73c0025                                           // 00000027C810: D73C0025
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000027C814: 02020881
	v_bfe_u32 v5, v10, 16, 1                                   // 00000027C818: D6100005 0205210A
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027C820: BF870004
	.long 0x7e523986                                           // 00000027C824: 7E523986
	s_waitcnt lgkmcnt(4)                                       // 00000027C828: BF89FC47
	v_mul_f32_e32 v6, v19, v42                                 // 00000027C82C: 100C5513
	s_waitcnt lgkmcnt(3)                                       // 00000027C830: BF89FC37
	v_mul_f32_e32 v42, v19, v43                                // 00000027C834: 10545713
	v_add3_u32 v4, v39, v40, 0x7fff                            // 00000027C838: D6550004 03FE5127 00007FFF
	.long 0xd73c0027                                           // 00000027C844: D73C0027
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000027C848: 02020E81
	v_add3_u32 v5, v10, v5, 0x7fff                             // 00000027C84C: D6550005 03FE0B0A 00007FFF
	v_bfe_u32 v7, v6, 16, 1                                    // 00000027C858: D6100007 02052106
	v_bfe_u32 v10, v42, 16, 1                                  // 00000027C860: D610000A 0205212A
	s_waitcnt lgkmcnt(2)                                       // 00000027C868: BF89FC27
	v_mul_f32_e32 v43, v19, v44                                // 00000027C86C: 10565913
	s_waitcnt lgkmcnt(1)                                       // 00000027C870: BF89FC17
	v_mul_f32_e32 v44, v19, v45                                // 00000027C874: 10585B13
	v_and_or_b32 v4, 0xffff0000, v4, v41                       // 00000027C878: D6570004 04A608FF FFFF0000
	.long 0x7e523985                                           // 00000027C884: 7E523985
	v_add3_u32 v5, v6, v7, 0x7fff                              // 00000027C888: D6550005 03FE0F06 00007FFF
	v_add3_u32 v6, v42, v10, 0x7fff                            // 00000027C894: D6550006 03FE152A 00007FFF
	v_bfe_u32 v7, v43, 16, 1                                   // 00000027C8A0: D6100007 0205212B
	v_bfe_u32 v10, v44, 16, 1                                  // 00000027C8A8: D610000A 0205212C
	s_waitcnt lgkmcnt(0)                                       // 00000027C8B0: BF89FC07
	v_mul_f32_e32 v42, v19, v46                                // 00000027C8B4: 10545D13
	v_and_or_b32 v5, 0xffff0000, v5, v41                       // 00000027C8B8: D6570005 04A60AFF FFFF0000
	.long 0x7e523986                                           // 00000027C8C4: 7E523986
	v_add3_u32 v6, v43, v7, 0x7fff                             // 00000027C8C8: D6550006 03FE0F2B 00007FFF
	v_add3_u32 v7, v44, v10, 0x7fff                            // 00000027C8D4: D6550007 03FE152C 00007FFF
	v_bfe_u32 v10, v42, 16, 1                                  // 00000027C8E0: D610000A 0205212A
	.long 0xd7006a25                                           // 00000027C8E8: D7006A25
	v_cndmask_b32_e32 v1, s14, v37, vcc_lo                     // 00000027C8EC: 02024A0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000027C8F0: BF8700D1
	v_add_co_ci_u32_e64 v38, null, s15, v38, vcc_lo            // 00000027C8F4: D5207C26 01AA4C0F
	v_and_or_b32 v6, 0xffff0000, v6, v41                       // 00000027C8FC: D6570006 04A60CFF FFFF0000
	.long 0x7e523987                                           // 00000027C908: 7E523987
	v_add3_u32 v7, v42, v10, 0x7fff                            // 00000027C90C: D6550007 03FE152A 00007FFF
	.long 0xd7006a25                                           // 00000027C918: D7006A25
	v_cndmask_b32_e32 v1, v37, v39, vcc_lo                     // 00000027C91C: 02024F25
	v_add_co_ci_u32_e64 v38, null, v38, v40, vcc_lo            // 00000027C920: D5207C26 01AA5126
	s_delay_alu instid0(VALU_DEP_3)                            // 00000027C928: BF870003
	v_and_or_b32 v7, 0xffff0000, v7, v41                       // 00000027C92C: D6570007 04A60EFF FFFF0000
	global_store_b128 v[37:38], v[27:30], off                  // 00000027C938: DC760000 007C1B25
	s_cbranch_execnz 397                                       // 00000027C940: BFA6018D <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x1678>
	s_mov_b32 s1, exec_lo                                      // 00000027C944: BE81007E
	.long 0xd4cc007e                                           // 00000027C948: D4CC007E
	v_cndmask_b32_e32 v1, s17, v21, vcc_lo                     // 00000027C94C: 02022A11
	s_cbranch_execz 421                                        // 00000027C950: BFA501A5 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x16e8>
	s_waitcnt vmcnt(3)                                         // 00000027C954: BF890FF7
	v_lshrrev_b32_e32 v4, 22, v1                               // 00000027C958: 32080296
	v_lshrrev_b32_e32 v5, 26, v1                               // 00000027C95C: 320A029A
	v_lshrrev_b32_e32 v7, 14, v1                               // 00000027C960: 320E028E
	v_lshrrev_b32_e32 v10, 10, v1                              // 00000027C964: 3214028A
	v_lshrrev_b32_e32 v6, 18, v1                               // 00000027C968: 320C0292
	v_and_b32_e32 v4, 60, v4                                   // 00000027C96C: 360808BC
	v_lshrrev_b32_e32 v21, 6, v1                               // 00000027C970: 322A0286
	v_lshrrev_b32_e32 v27, 2, v1                               // 00000027C974: 32360282
	v_and_b32_e32 v1, 15, v1                                   // 00000027C978: 3602028F
	v_and_b32_e32 v6, 60, v6                                   // 00000027C97C: 360C0CBC
	ds_load_b32 v28, v4                                        // 00000027C980: D8D80000 1C000004
	v_and_b32_e32 v5, 60, v5                                   // 00000027C988: 360A0ABC
	v_and_b32_e32 v4, 60, v7                                   // 00000027C98C: 36080EBC
	v_and_b32_e32 v7, 60, v10                                  // 00000027C990: 360E14BC
	v_and_b32_e32 v10, 60, v21                                 // 00000027C994: 36142ABC
	v_and_b32_e32 v21, 60, v27                                 // 00000027C998: 362A36BC
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000027C99C: 30020282
	ds_load_b32 v31, v7                                        // 00000027C9A0: D8D80000 1F000007
	ds_load_b32 v10, v10                                       // 00000027C9A8: D8D80000 0A00000A
	ds_load_b32 v21, v21                                       // 00000027C9B0: D8D80000 15000015
	ds_load_b32 v1, v1                                         // 00000027C9B8: D8D80000 01000001
	v_mov_b32_e32 v7, v16                                      // 00000027C9C0: 7E0E0310
	.long 0x7f403880                                           // 00000027C9C4: 7F403880
	s_waitcnt lgkmcnt(4)                                       // 00000027C9C8: BF89FC47
	v_mul_f32_e32 v16, v26, v28                                // 00000027C9CC: 1020391A
	ds_load_b32 v27, v5                                        // 00000027C9D0: D8D80000 1B000005
	ds_load_b32 v29, v6                                        // 00000027C9D8: D8D80000 1D000006
	ds_load_b32 v30, v4                                        // 00000027C9E0: D8D80000 1E000004
	v_mad_u64_u32 v[4:5], null, s4, v15, 0                     // 00000027C9E8: D6FE7C04 02021E04
	v_bfe_u32 v28, v16, 16, 1                                  // 00000027C9F0: D610001C 02052110
	s_waitcnt lgkmcnt(5)                                       // 00000027C9F8: BF89FC57
	v_mul_f32_e32 v10, v26, v10                                // 00000027C9FC: 1014151A
	s_waitcnt lgkmcnt(4)                                       // 00000027CA00: BF89FC47
	v_mul_f32_e32 v21, v26, v21                                // 00000027CA04: 102A2B1A
	s_waitcnt lgkmcnt(3)                                       // 00000027CA08: BF89FC37
	v_mul_f32_e32 v1, v26, v1                                  // 00000027CA0C: 1002031A
	v_mad_u64_u32 v[5:6], null, s5, v15, v[5:6]                // 00000027CA10: D6FE7C05 04161E05
	v_add3_u32 v16, v16, v28, 0x7fff                           // 00000027CA18: D6550010 03FE3910 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027CA24: BF870191
	.long 0x7e403990                                           // 00000027CA28: 7E403990
	.long 0xd73c0004                                           // 00000027CA2C: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000027CA30: 02020881
	s_waitcnt lgkmcnt(2)                                       // 00000027CA34: BF89FC27
	v_mul_f32_e32 v6, v26, v27                                 // 00000027CA38: 100C371A
	s_waitcnt lgkmcnt(1)                                       // 00000027CA3C: BF89FC17
	v_mul_f32_e32 v15, v26, v29                                // 00000027CA40: 101E3B1A
	s_waitcnt lgkmcnt(0)                                       // 00000027CA44: BF89FC07
	v_mul_f32_e32 v27, v26, v30                                // 00000027CA48: 10363D1A
	v_mul_f32_e32 v30, v26, v31                                // 00000027CA4C: 103C3F1A
	v_bfe_u32 v29, v6, 16, 1                                   // 00000027CA50: D610001D 02052106
	v_bfe_u32 v26, v15, 16, 1                                  // 00000027CA58: D610001A 0205210F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027CA60: BF870194
	v_bfe_u32 v28, v27, 16, 1                                  // 00000027CA64: D610001C 0205211B
	v_add3_u32 v6, v6, v29, 0x7fff                             // 00000027CA6C: D6550006 03FE3B06 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027CA78: BF870193
	v_add3_u32 v15, v15, v26, 0x7fff                           // 00000027CA7C: D655000F 03FE350F 00007FFF
	v_add3_u32 v16, v27, v28, 0x7fff                           // 00000027CA88: D6550010 03FE391B 00007FFF
	v_bfe_u32 v27, v10, 16, 1                                  // 00000027CA94: D610001B 0205210A
	v_bfe_u32 v28, v30, 16, 1                                  // 00000027CA9C: D610001C 0205211E
	v_and_or_b32 v29, 0xffff0000, v6, v32                      // 00000027CAA4: D657001D 04820CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000027CAB0: BF870214
	.long 0x7e403990                                           // 00000027CAB4: 7E403990
	v_add3_u32 v6, v10, v27, 0x7fff                            // 00000027CAB8: D6550006 03FE370A 00007FFF
	v_bfe_u32 v10, v1, 16, 1                                   // 00000027CAC4: D610000A 02052101
	v_add3_u32 v26, v30, v28, 0x7fff                           // 00000027CACC: D655001A 03FE391E 00007FFF
	v_bfe_u32 v16, v21, 16, 1                                  // 00000027CAD8: D6100010 02052115
	v_and_or_b32 v28, 0xffff0000, v15, v32                     // 00000027CAE0: D657001C 04821EFF FFFF0000
	.long 0x7e403986                                           // 00000027CAEC: 7E403986
	v_add3_u32 v1, v1, v10, 0x7fff                             // 00000027CAF0: D6550001 03FE1501 00007FFF
	.long 0xd73c0006                                           // 00000027CAFC: D73C0006
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000027CB00: 02020E81
	v_add3_u32 v10, v21, v16, 0x7fff                           // 00000027CB04: D655000A 03FE2115 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000027CB10: BF870214
	v_and_or_b32 v27, 0xffff0000, v26, v32                     // 00000027CB14: D657001B 048234FF FFFF0000
	.long 0x7e403981                                           // 00000027CB20: 7E403981
	.long 0xd7006a01                                           // 00000027CB24: D7006A01
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 00000027CB28: 0202080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027CB2C: BF870191
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 00000027CB30: D5207C05 01AA0A0F
	v_and_or_b32 v26, 0xffff0000, v10, v32                     // 00000027CB38: D657001A 048214FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027CB44: BF870093
	.long 0xd7006a04                                           // 00000027CB48: D7006A04
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 00000027CB4C: 02020D01
	v_add_co_ci_u32_e64 v5, null, v5, v7, vcc_lo               // 00000027CB50: D5207C05 01AA0F05
	global_store_b128 v[4:5], v[26:29], off                    // 00000027CB58: DC760000 007C1A04
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027CB60: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027CB64: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000027CB68: BE81007E
	.long 0xd4cc007e                                           // 00000027CB6C: D4CC007E
	v_cndmask_b32_e32 v1, s17, v14, vcc_lo                     // 00000027CB70: 02021C11
	s_cbranch_execnz 290                                       // 00000027CB74: BFA60122 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x1700>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027CB78: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027CB7C: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000027CB80: BE81007E
	.long 0xd4cc007e                                           // 00000027CB84: D4CC007E
	v_cndmask_b32_e32 v1, s17, v12, vcc_lo                     // 00000027CB88: 02021811
	s_cbranch_execz 130                                        // 00000027CB8C: BFA50082 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x1498>
	s_waitcnt vmcnt(1)                                         // 00000027CB90: BF8907F7
	v_lshrrev_b32_e32 v1, 22, v3                               // 00000027CB94: 32020696
	v_lshrrev_b32_e32 v2, 26, v3                               // 00000027CB98: 3204069A
	v_lshrrev_b32_e32 v4, 18, v3                               // 00000027CB9C: 32080692
	v_lshrrev_b32_e32 v5, 14, v3                               // 00000027CBA0: 320A068E
	v_lshrrev_b32_e32 v6, 10, v3                               // 00000027CBA4: 320C068A
	v_and_b32_e32 v1, 60, v1                                   // 00000027CBA8: 360202BC
	v_lshrrev_b32_e32 v7, 6, v3                                // 00000027CBAC: 320E0686
	v_lshrrev_b32_e32 v10, 2, v3                               // 00000027CBB0: 32140682
	v_and_b32_e32 v2, 60, v2                                   // 00000027CBB4: 360404BC
	v_and_b32_e32 v4, 60, v4                                   // 00000027CBB8: 360808BC
	ds_load_b32 v12, v1                                        // 00000027CBBC: D8D80000 0C000001
	v_and_b32_e32 v1, 60, v5                                   // 00000027CBC4: 36020ABC
	v_and_b32_e32 v5, 60, v6                                   // 00000027CBC8: 360A0CBC
	v_and_b32_e32 v6, 60, v7                                   // 00000027CBCC: 360C0EBC
	v_and_b32_e32 v7, 60, v10                                  // 00000027CBD0: 360E14BC
	ds_load_b32 v10, v2                                        // 00000027CBD4: D8D80000 0A000002
	ds_load_b32 v4, v4                                         // 00000027CBDC: D8D80000 04000004
	ds_load_b32 v14, v1                                        // 00000027CBE4: D8D80000 0E000001
	v_and_b32_e32 v3, 15, v3                                   // 00000027CBEC: 3606068F
	.long 0x7f283880                                           // 00000027CBF0: 7F283880
	s_delay_alu instid0(VALU_DEP_2)                            // 00000027CBF4: BF870002
	v_lshlrev_b32_e32 v1, 2, v3                                // 00000027CBF8: 30020682
	ds_load_b32 v5, v5                                         // 00000027CBFC: D8D80000 05000005
	ds_load_b32 v6, v6                                         // 00000027CC04: D8D80000 06000006
	ds_load_b32 v15, v7                                        // 00000027CC0C: D8D80000 0F000007
	ds_load_b32 v16, v1                                        // 00000027CC14: D8D80000 10000001
	v_mad_u64_u32 v[1:2], null, s4, v17, 0                     // 00000027CC1C: D6FE7C01 02022204
	s_waitcnt lgkmcnt(7)                                       // 00000027CC24: BF89FC77
	v_dual_mov_b32 v7, v18 :: v_dual_mul_f32 v12, v24, v12     // 00000027CC28: CA060112 070C1918
	s_delay_alu instid0(VALU_DEP_2)                            // 00000027CC30: BF870002
	v_mad_u64_u32 v[2:3], null, s5, v17, v[2:3]                // 00000027CC34: D6FE7C02 040A2205
	s_waitcnt lgkmcnt(6)                                       // 00000027CC3C: BF89FC67
	v_mul_f32_e32 v3, v24, v10                                 // 00000027CC40: 10061518
	s_waitcnt lgkmcnt(5)                                       // 00000027CC44: BF89FC57
	v_mul_f32_e32 v4, v24, v4                                  // 00000027CC48: 10080918
	s_waitcnt lgkmcnt(4)                                       // 00000027CC4C: BF89FC47
	v_mul_f32_e32 v10, v24, v14                                // 00000027CC50: 10141D18
	v_bfe_u32 v14, v12, 16, 1                                  // 00000027CC54: D610000E 0205210C
	s_delay_alu instid0(VALU_DEP_3)                            // 00000027CC5C: BF870003
	v_bfe_u32 v18, v4, 16, 1                                   // 00000027CC60: D6100012 02052104
	s_waitcnt lgkmcnt(3)                                       // 00000027CC68: BF89FC37
	v_mul_f32_e32 v5, v24, v5                                  // 00000027CC6C: 100A0B18
	s_waitcnt lgkmcnt(2)                                       // 00000027CC70: BF89FC27
	v_mul_f32_e32 v6, v24, v6                                  // 00000027CC74: 100C0D18
	s_waitcnt lgkmcnt(1)                                       // 00000027CC78: BF89FC17
	v_mul_f32_e32 v17, v24, v15                                // 00000027CC7C: 10221F18
	v_bfe_u32 v15, v3, 16, 1                                   // 00000027CC80: D610000F 02052103
	v_add3_u32 v12, v12, v14, 0x7fff                           // 00000027CC88: D655000C 03FE1D0C 00007FFF
	v_bfe_u32 v14, v10, 16, 1                                  // 00000027CC94: D610000E 0205210A
	s_waitcnt lgkmcnt(0)                                       // 00000027CC9C: BF89FC07
	v_mul_f32_e32 v16, v24, v16                                // 00000027CCA0: 10202118
	v_add3_u32 v3, v3, v15, 0x7fff                             // 00000027CCA4: D6550003 03FE1F03 00007FFF
	.long 0x7e28398c                                           // 00000027CCB0: 7E28398C
	v_add3_u32 v10, v10, v14, 0x7fff                           // 00000027CCB4: D655000A 03FE1D0A 00007FFF
	v_bfe_u32 v12, v6, 16, 1                                   // 00000027CCC0: D610000C 02052106
	v_bfe_u32 v14, v5, 16, 1                                   // 00000027CCC8: D610000E 02052105
	v_add3_u32 v15, v4, v18, 0x7fff                            // 00000027CCD0: D655000F 03FE2504 00007FFF
	v_and_or_b32 v4, 0xffff0000, v3, v20                       // 00000027CCDC: D6570004 045206FF FFFF0000
	.long 0x7e28398a                                           // 00000027CCE8: 7E28398A
	v_add3_u32 v6, v6, v12, 0x7fff                             // 00000027CCEC: D6550006 03FE1906 00007FFF
	v_bfe_u32 v10, v16, 16, 1                                  // 00000027CCF8: D610000A 02052110
	v_add3_u32 v18, v5, v14, 0x7fff                            // 00000027CD00: D6550012 03FE1D05 00007FFF
	v_bfe_u32 v12, v17, 16, 1                                  // 00000027CD0C: D610000C 02052111
	v_and_or_b32 v3, 0xffff0000, v15, v20                      // 00000027CD14: D6570003 04521EFF FFFF0000
	.long 0x7e283986                                           // 00000027CD20: 7E283986
	.long 0xd73c0005                                           // 00000027CD24: D73C0005
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000027CD28: 02020281
	v_add3_u32 v10, v16, v10, 0x7fff                           // 00000027CD2C: D655000A 03FE1510 00007FFF
	.long 0xd73c000e                                           // 00000027CD38: D73C000E
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000027CD3C: 02020E81
	v_add3_u32 v1, v17, v12, 0x7fff                            // 00000027CD40: D6550001 03FE1911 00007FFF
	v_and_or_b32 v2, 0xffff0000, v18, v20                      // 00000027CD4C: D6570002 045224FF FFFF0000
	.long 0xd7006a05                                           // 00000027CD58: D7006A05
	v_cndmask_b32_e32 v1, s14, v5, vcc_lo                      // 00000027CD5C: 02020A0E
	.long 0x7e28398a                                           // 00000027CD60: 7E28398A
	v_add_co_ci_u32_e64 v6, null, s15, v6, vcc_lo              // 00000027CD64: D5207C06 01AA0C0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027CD6C: BF870193
	.long 0xd7006a05                                           // 00000027CD70: D7006A05
	v_cndmask_b32_e32 v1, v5, v14, vcc_lo                      // 00000027CD74: 02021D05
	v_and_or_b32 v1, 0xffff0000, v1, v20                       // 00000027CD78: D6570001 045202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000027CD84: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v15, vcc_lo              // 00000027CD88: D5207C06 01AA1F06
	global_store_b128 v[5:6], v[1:4], off                      // 00000027CD90: DC760000 007C0105
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027CD98: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027CD9C: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000027CDA0: BE81007E
	.long 0xd4cc007e                                           // 00000027CDA4: D4CC007E
	v_cndmask_b32_e32 v1, s17, v11, vcc_lo                     // 00000027CDA8: 02021611
	s_cbranch_execz 113                                        // 00000027CDAC: BFA50071 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x1674>
	s_waitcnt vmcnt(0)                                         // 00000027CDB0: BF8903F7
	v_lshrrev_b32_e32 v2, 26, v22                              // 00000027CDB4: 32042C9A
	v_lshrrev_b32_e32 v3, 18, v22                              // 00000027CDB8: 32062C92
	v_lshrrev_b32_e32 v4, 14, v22                              // 00000027CDBC: 32082C8E
	v_lshrrev_b32_e32 v1, 22, v22                              // 00000027CDC0: 32022C96
	v_lshrrev_b32_e32 v5, 10, v22                              // 00000027CDC4: 320A2C8A
	v_and_b32_e32 v2, 60, v2                                   // 00000027CDC8: 360404BC
	v_and_b32_e32 v3, 60, v3                                   // 00000027CDCC: 360606BC
	v_and_b32_e32 v4, 60, v4                                   // 00000027CDD0: 360808BC
	v_lshrrev_b32_e32 v6, 6, v22                               // 00000027CDD4: 320C2C86
	v_lshrrev_b32_e32 v7, 2, v22                               // 00000027CDD8: 320E2C82
	ds_load_b32 v2, v2                                         // 00000027CDDC: D8D80000 02000002
	ds_load_b32 v3, v3                                         // 00000027CDE4: D8D80000 03000003
	ds_load_b32 v4, v4                                         // 00000027CDEC: D8D80000 04000004
	v_and_b32_e32 v1, 60, v1                                   // 00000027CDF4: 360202BC
	v_and_b32_e32 v10, 15, v22                                 // 00000027CDF8: 36142C8F
	v_and_b32_e32 v5, 60, v5                                   // 00000027CDFC: 360A0ABC
	v_and_b32_e32 v6, 60, v6                                   // 00000027CE00: 360C0CBC
	v_and_b32_e32 v7, 60, v7                                   // 00000027CE04: 360E0EBC
	.long 0x7f163880                                           // 00000027CE08: 7F163880
	v_lshlrev_b32_e32 v10, 2, v10                              // 00000027CE0C: 30141482
	ds_load_b32 v5, v5                                         // 00000027CE10: D8D80000 05000005
	ds_load_b32 v6, v6                                         // 00000027CE18: D8D80000 06000006
	ds_load_b32 v7, v7                                         // 00000027CE20: D8D80000 07000007
	ds_load_b32 v10, v10                                       // 00000027CE28: D8D80000 0A00000A
	s_or_b32 s0, s0, exec_lo                                   // 00000027CE30: 8C007E00
	s_waitcnt lgkmcnt(6)                                       // 00000027CE34: BF89FC67
	v_mul_f32_e32 v2, v19, v2                                  // 00000027CE38: 10040513
	ds_load_b32 v1, v1                                         // 00000027CE3C: D8D80000 01000001
	s_waitcnt lgkmcnt(5)                                       // 00000027CE44: BF89FC57
	v_mul_f32_e32 v4, v19, v4                                  // 00000027CE48: 10080913
	v_mul_f32_e32 v3, v19, v3                                  // 00000027CE4C: 10060713
	s_waitcnt lgkmcnt(4)                                       // 00000027CE50: BF89FC47
	v_mul_f32_e32 v5, v19, v5                                  // 00000027CE54: 100A0B13
	s_waitcnt lgkmcnt(3)                                       // 00000027CE58: BF89FC37
	v_mul_f32_e32 v6, v19, v6                                  // 00000027CE5C: 100C0D13
	s_waitcnt lgkmcnt(2)                                       // 00000027CE60: BF89FC27
	v_mul_f32_e32 v14, v19, v7                                 // 00000027CE64: 101C0F13
	v_bfe_u32 v7, v2, 16, 1                                    // 00000027CE68: D6100007 02052102
	s_waitcnt lgkmcnt(1)                                       // 00000027CE70: BF89FC17
	v_mul_f32_e32 v10, v19, v10                                // 00000027CE74: 10141513
	v_bfe_u32 v15, v3, 16, 1                                   // 00000027CE78: D610000F 02052103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027CE80: BF870113
	v_add3_u32 v2, v2, v7, 0x7fff                              // 00000027CE84: D6550002 03FE0F02 00007FFF
	v_add3_u32 v3, v3, v15, 0x7fff                             // 00000027CE90: D6550003 03FE1F03 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 00000027CE9C: BF89FC07
	v_mul_f32_e32 v1, v19, v1                                  // 00000027CEA0: 10020313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027CEA4: BF870091
	v_bfe_u32 v12, v1, 16, 1                                   // 00000027CEA8: D610000C 02052101
	v_add3_u32 v1, v1, v12, 0x7fff                             // 00000027CEB0: D6550001 03FE1901 00007FFF
	v_bfe_u32 v12, v4, 16, 1                                   // 00000027CEBC: D610000C 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027CEC4: BF870112
	.long 0x7e163981                                           // 00000027CEC8: 7E163981
	v_add3_u32 v1, v4, v12, 0x7fff                             // 00000027CECC: D6550001 03FE1904 00007FFF
	v_bfe_u32 v4, v6, 16, 1                                    // 00000027CED8: D6100004 02052106
	v_bfe_u32 v12, v5, 16, 1                                   // 00000027CEE0: D610000C 02052105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000027CEE8: BF870214
	v_and_or_b32 v7, 0xffff0000, v2, v11                       // 00000027CEEC: D6570007 042E04FF FFFF0000
	.long 0x7e163981                                           // 00000027CEF8: 7E163981
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027CEFC: BF870004
	v_add3_u32 v1, v6, v4, 0x7fff                              // 00000027CF00: D6550001 03FE0906 00007FFF
	v_bfe_u32 v2, v10, 16, 1                                   // 00000027CF0C: D6100002 0205210A
	v_bfe_u32 v4, v14, 16, 1                                   // 00000027CF14: D6100004 0205210E
	v_add3_u32 v5, v5, v12, 0x7fff                             // 00000027CF1C: D6550005 03FE1905 00007FFF
	v_and_or_b32 v6, 0xffff0000, v3, v11                       // 00000027CF28: D6570006 042E06FF FFFF0000
	.long 0x7e163981                                           // 00000027CF34: 7E163981
	v_add3_u32 v1, v10, v2, 0x7fff                             // 00000027CF38: D6550001 03FE050A 00007FFF
	v_add3_u32 v2, v14, v4, 0x7fff                             // 00000027CF44: D6550002 03FE090E 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027CF50: BF870193
	v_and_or_b32 v5, 0xffff0000, v5, v11                       // 00000027CF54: D6570005 042E0AFF FFFF0000
	.long 0x7e163981                                           // 00000027CF60: 7E163981
	s_delay_alu instid0(VALU_DEP_1)                            // 00000027CF64: BF870001
	v_and_or_b32 v4, 0xffff0000, v2, v11                       // 00000027CF68: D6570004 042E04FF FFFF0000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027CF74: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000027CF78: BE812000
	s_cbranch_execz 64166                                      // 00000027CF7C: BFA5FAA6 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x118>
	s_waitcnt vmcnt(2)                                         // 00000027CF80: BF890BF7
	v_mad_u64_u32 v[1:2], null, s4, v13, 0                     // 00000027CF84: D6FE7C01 02021A04
	v_mov_b32_e32 v10, v8                                      // 00000027CF8C: 7E140308
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000027CF90: BF8701A1
	.long 0xd73c0009                                           // 00000027CF94: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 00000027CF98: 02021281
	s_waitcnt vmcnt(1)                                         // 00000027CF9C: BF8907F7
	v_mad_u64_u32 v[2:3], null, s5, v13, v[2:3]                // 00000027CFA0: D6FE7C02 040A1A05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027CFA8: BF870091
	.long 0xd73c0001                                           // 00000027CFAC: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000027CFB0: 02020281
	.long 0xd7006a01                                           // 00000027CFB4: D7006A01
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000027CFB8: 0202020E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027CFBC: BF870111
	v_add_co_ci_u32_e64 v2, null, s15, v2, vcc_lo              // 00000027CFC0: D5207C02 01AA040F
	.long 0xd7006a01                                           // 00000027CFC8: D7006A01
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 00000027CFCC: 02021301
	s_delay_alu instid0(VALU_DEP_1)                            // 00000027CFD0: BF870001
	v_add_co_ci_u32_e64 v2, null, v2, v10, vcc_lo              // 00000027CFD4: D5207C02 01AA1502
	global_store_b128 v[1:2], v[4:7], off                      // 00000027CFDC: DC760000 007C0401
	s_branch 64140                                             // 00000027CFE4: BFA0FA8C <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x118>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027CFE8: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027CFEC: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000027CFF0: BE81007E
	.long 0xd4cc007e                                           // 00000027CFF4: D4CC007E
	v_cndmask_b32_e32 v1, s17, v14, vcc_lo                     // 00000027CFF8: 02021C11
	s_cbranch_execz 65246                                      // 00000027CFFC: BFA5FEDE <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x1278>
	s_waitcnt vmcnt(2)                                         // 00000027D000: BF890BF7
	v_lshrrev_b32_e32 v7, 10, v2                               // 00000027D004: 320E048A
	v_lshrrev_b32_e32 v10, 6, v2                               // 00000027D008: 32140486
	v_lshrrev_b32_e32 v14, 2, v2                               // 00000027D00C: 321C0482
	v_lshrrev_b32_e32 v1, 22, v2                               // 00000027D010: 32020496
	v_lshrrev_b32_e32 v4, 26, v2                               // 00000027D014: 3208049A
	v_lshrrev_b32_e32 v5, 18, v2                               // 00000027D018: 320A0492
	v_lshrrev_b32_e32 v6, 14, v2                               // 00000027D01C: 320C048E
	v_and_b32_e32 v2, 15, v2                                   // 00000027D020: 3604048F
	v_and_b32_e32 v7, 60, v7                                   // 00000027D024: 360E0EBC
	v_and_b32_e32 v10, 60, v10                                 // 00000027D028: 361414BC
	v_and_b32_e32 v14, 60, v14                                 // 00000027D02C: 361C1CBC
	v_and_b32_e32 v4, 60, v4                                   // 00000027D030: 360808BC
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000027D034: 30040482
	ds_load_b32 v26, v7                                        // 00000027D038: D8D80000 1A000007
	ds_load_b32 v10, v10                                       // 00000027D040: D8D80000 0A00000A
	ds_load_b32 v14, v14                                       // 00000027D048: D8D80000 0E00000E
	ds_load_b32 v2, v2                                         // 00000027D050: D8D80000 02000002
	v_and_b32_e32 v5, 60, v5                                   // 00000027D058: 360A0ABC
	v_dual_mov_b32 v7, v23 :: v_dual_and_b32 v6, 60, v6        // 00000027D05C: CA240117 07060CBC
	.long 0x7f3a3880                                           // 00000027D064: 7F3A3880
	s_waitcnt lgkmcnt(2)                                       // 00000027D068: BF89FC27
	v_mul_f32_e32 v10, v25, v10                                // 00000027D06C: 10141519
	ds_load_b32 v15, v4                                        // 00000027D070: D8D80000 0F000004
	ds_load_b32 v16, v5                                        // 00000027D078: D8D80000 10000005
	ds_load_b32 v21, v6                                        // 00000027D080: D8D80000 15000006
	v_mad_u64_u32 v[4:5], null, s4, v20, 0                     // 00000027D088: D6FE7C04 02022804
	s_waitcnt lgkmcnt(4)                                       // 00000027D090: BF89FC47
	v_dual_mul_f32 v14, v25, v14 :: v_dual_and_b32 v1, 60, v1  // 00000027D094: C8E41D19 0E0002BC
	s_waitcnt lgkmcnt(3)                                       // 00000027D09C: BF89FC37
	v_mul_f32_e32 v2, v25, v2                                  // 00000027D0A0: 10040519
	s_delay_alu instid0(VALU_DEP_3)                            // 00000027D0A4: BF870003
	v_mad_u64_u32 v[5:6], null, s5, v20, v[5:6]                // 00000027D0A8: D6FE7C05 04162805
	s_waitcnt lgkmcnt(2)                                       // 00000027D0B0: BF89FC27
	v_mul_f32_e32 v6, v25, v15                                 // 00000027D0B4: 100C1F19
	ds_load_b32 v1, v1                                         // 00000027D0B8: D8D80000 01000001
	s_waitcnt lgkmcnt(2)                                       // 00000027D0C0: BF89FC27
	v_mul_f32_e32 v15, v25, v16                                // 00000027D0C4: 101E2119
	s_waitcnt lgkmcnt(1)                                       // 00000027D0C8: BF89FC17
	v_mul_f32_e32 v16, v25, v21                                // 00000027D0CC: 10202B19
	v_mul_f32_e32 v21, v25, v26                                // 00000027D0D0: 102A3519
	v_bfe_u32 v23, v6, 16, 1                                   // 00000027D0D4: D6100017 02052106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000027D0DC: BF870141
	v_add3_u32 v6, v6, v23, 0x7fff                             // 00000027D0E0: D6550006 03FE2F06 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 00000027D0EC: BF89FC07
	v_mul_f32_e32 v1, v25, v1                                  // 00000027D0F0: 10020319
	v_bfe_u32 v25, v15, 16, 1                                  // 00000027D0F4: D6100019 0205210F
	v_bfe_u32 v20, v1, 16, 1                                   // 00000027D0FC: D6100014 02052101
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027D104: BF870112
	v_add3_u32 v15, v15, v25, 0x7fff                           // 00000027D108: D655000F 03FE330F 00007FFF
	v_add3_u32 v1, v1, v20, 0x7fff                             // 00000027D114: D6550001 03FE2901 00007FFF
	v_bfe_u32 v20, v16, 16, 1                                  // 00000027D120: D6100014 02052110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027D128: BF870112
	.long 0x7e3a3981                                           // 00000027D12C: 7E3A3981
	v_add3_u32 v1, v16, v20, 0x7fff                            // 00000027D130: D6550001 03FE2910 00007FFF
	v_bfe_u32 v16, v10, 16, 1                                  // 00000027D13C: D6100010 0205210A
	v_bfe_u32 v20, v21, 16, 1                                  // 00000027D144: D6100014 02052115
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000027D14C: BF870214
	v_and_or_b32 v28, 0xffff0000, v6, v29                      // 00000027D150: D657001C 04760CFF FFFF0000
	.long 0x7e3a3981                                           // 00000027D15C: 7E3A3981
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027D160: BF870004
	v_add3_u32 v1, v10, v16, 0x7fff                            // 00000027D164: D6550001 03FE210A 00007FFF
	v_bfe_u32 v6, v2, 16, 1                                    // 00000027D170: D6100006 02052102
	v_bfe_u32 v10, v14, 16, 1                                  // 00000027D178: D610000A 0205210E
	v_add3_u32 v16, v21, v20, 0x7fff                           // 00000027D180: D6550010 03FE2915 00007FFF
	v_and_or_b32 v27, 0xffff0000, v15, v29                     // 00000027D18C: D657001B 04761EFF FFFF0000
	.long 0x7e3a3981                                           // 00000027D198: 7E3A3981
	v_add3_u32 v6, v2, v6, 0x7fff                              // 00000027D19C: D6550006 03FE0D02 00007FFF
	.long 0xd73c0001                                           // 00000027D1A8: D73C0001
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000027D1AC: 02020881
	.long 0xd73c0004                                           // 00000027D1B0: D73C0004
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000027D1B4: 02020E81
	v_add3_u32 v7, v14, v10, 0x7fff                            // 00000027D1B8: D6550007 03FE150E 00007FFF
	v_and_or_b32 v26, 0xffff0000, v16, v29                     // 00000027D1C4: D657001A 047620FF FFFF0000
	.long 0x7e3a3986                                           // 00000027D1D0: 7E3A3986
	.long 0xd7006a01                                           // 00000027D1D4: D7006A01
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000027D1D8: 0202020E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027D1DC: BF870191
	v_add_co_ci_u32_e64 v2, null, s15, v2, vcc_lo              // 00000027D1E0: D5207C02 01AA040F
	v_and_or_b32 v25, 0xffff0000, v7, v29                      // 00000027D1E8: D6570019 04760EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027D1F4: BF870093
	.long 0xd7006a01                                           // 00000027D1F8: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000027D1FC: 02020901
	v_add_co_ci_u32_e64 v2, null, v2, v5, vcc_lo               // 00000027D200: D5207C02 01AA0B02
	global_store_b128 v[1:2], v[25:28], off                    // 00000027D208: DC760000 007C1901
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027D210: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027D214: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000027D218: BE81007E
	.long 0xd4cc007e                                           // 00000027D21C: D4CC007E
	v_cndmask_b32_e32 v1, s17, v12, vcc_lo                     // 00000027D220: 02021811
	s_cbranch_execz 65244                                      // 00000027D224: BFA5FEDC <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x1498>
	s_branch 65113                                             // 00000027D228: BFA0FE59 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb1EEEvPKhPtjjllllNS0_5DeqCbE+0x1290>
	s_endpgm                                                   // 00000027D22C: BFB00000
		...

