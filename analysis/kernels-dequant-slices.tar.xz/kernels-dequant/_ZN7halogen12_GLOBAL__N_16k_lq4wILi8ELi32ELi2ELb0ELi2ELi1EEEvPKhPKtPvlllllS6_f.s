0000000000828a00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000828A00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000828A08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000828A0C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000828A10: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 000000828A14: 3602008F
	v_lshrrev_b32_e32 v28, 6, v0                               // 000000828A18: 32380086
	v_bfe_u32 v29, v0, 5, 1                                    // 000000828A1C: D610001D 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 000000828A24: 360404BC
	v_and_b32_e32 v30, 31, v0                                  // 000000828A28: 363C009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000828A2C: 30020282
	.long 0x7f0a3880                                           // 000000828A30: 7F0A3880
	v_lshlrev_b32_e32 v6, 2, v0                                // 000000828A34: 300C0082
	s_waitcnt lgkmcnt(0)                                       // 000000828A38: BF89FC07
	s_clause 0x1                                               // 000000828A3C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000828A40: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000828A48: DC520000 04040002
	s_add_u32 s0, s4, s16                                      // 000000828A50: 80001004
	s_addc_u32 s1, s5, s17                                     // 000000828A54: 82011105
	s_ashr_i32 s16, s11, 31                                    // 000000828A58: 86109F0B
	v_mov_b32_e32 v2, s3                                       // 000000828A5C: 7E040203
	s_lshr_b32 s16, s16, 27                                    // 000000828A60: 85109B10
	v_or_b32_e32 v1, s2, v28                                   // 000000828A64: 38023802
	s_add_u32 s16, s10, s16                                    // 000000828A68: 8010100A
	s_addc_u32 s17, s11, 0                                     // 000000828A6C: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828A70: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000828A74: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000828A78: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 000000828A7C: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000828A80: BF870499
	s_lshr_b32 s20, s17, 31                                    // 000000828A84: 85149F11
	s_add_i32 s17, s17, s20                                    // 000000828A88: 81111411
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000828A8C: 02020280
	s_ashr_i32 s17, s17, 1                                     // 000000828A90: 86118111
	v_cndmask_b32_e64 v2, 0, s3, vcc_lo                        // 000000828A94: D5010002 01A80680
	.long 0xd72c0007                                           // 000000828A9C: D72C0007
	v_cndmask_b32_e32 v1, s17, v29, vcc_lo                     // 000000828AA0: 02023A11
	s_cmpk_lt_i32 s16, 0x201                                   // 000000828AA4: B3900201
	.long 0xd72c0009                                           // 000000828AA8: D72C0009
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 000000828AAC: 02020213
	v_mad_u64_u32 v[24:25], null, s18, v1, s[0:1]              // 000000828AB0: D6FE7C18 00020212
	s_cselect_b32 s0, -1, 0                                    // 000000828AB8: 980080C1
	s_cmpk_gt_i32 s16, 0x200                                   // 000000828ABC: B2900200
	v_add_nc_u32_e32 v11, s17, v7                              // 000000828AC0: 4A160E11
	v_add_nc_u32_e32 v31, v7, v30                              // 000000828AC4: 4A3E3D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000828AC8: BF8704A2
	v_min_i32_e32 v32, s16, v11                                // 000000828ACC: 22401610
	s_cselect_b32 s16, -1, 0                                   // 000000828AD0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 000000828AD4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000828AD8: BF870151
	.long 0xd4410001                                           // 000000828ADC: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000828AE0: 0202411F
	s_waitcnt vmcnt(1)                                         // 000000828AE4: BF8907F7
	v_bfe_u32 v8, v3, 16, 1                                    // 000000828AE8: D6100008 02052103
	s_waitcnt vmcnt(0)                                         // 000000828AF0: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 000000828AF4: D610000A 02052104
	v_add3_u32 v3, v3, v8, 0x7fff                              // 000000828AFC: D6550003 03FE1103 00007FFF
	.long 0xd72c0008                                           // 000000828B08: D72C0008
	v_cndmask_b32_e32 v1, s18, v2, vcc_lo                      // 000000828B0C: 02020412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000828B10: BF870193
	v_add3_u32 v4, v4, v10, 0x7fff                             // 000000828B14: D6550004 03FE1504 00007FFF
	.long 0x7e0a3983                                           // 000000828B20: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000828B24: BF870113
	v_add3_u32 v33, v9, v25, v8                                // 000000828B28: D6550021 04223309
	v_and_or_b32 v3, 0xffff0000, v4, v5                        // 000000828B30: D6570003 041608FF FFFF0000
	ds_store_b32 v6, v3                                        // 000000828B3C: D8340000 00000306
	s_waitcnt lgkmcnt(0)                                       // 000000828B44: BF89FC07
	s_barrier                                                  // 000000828B48: BFBD0000
	buffer_gl0_inv                                             // 000000828B4C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000828B54: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 000000828B58: CA100080 09080080
	s_and_saveexec_b32 s17, s1                                 // 000000828B60: BE912001
	s_cbranch_execz 11                                         // 000000828B64: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v3, 1, v31                               // 000000828B68: 30063E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828B6C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000828B70: 3408069F
	.long 0xd7006a03                                           // 000000828B74: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000828B78: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000828B7C: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000828B84: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000828B8C: BF8903F7
	v_cvt_f32_f16_e32 v8, v3                                   // 000000828B90: 7E101703
	s_or_b32 exec_lo, exec_lo, s17                             // 000000828B94: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v31                               // 000000828B98: 4A063EA0
	s_mov_b32 s1, exec_lo                                      // 000000828B9C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000828BA0: BF870001
	.long 0xd4c1007e                                           // 000000828BA4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000828BA8: 02024103
	s_cbranch_execz 11                                         // 000000828BAC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000828BB0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828BB4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000828BB8: 3408069F
	.long 0xd7006a03                                           // 000000828BBC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000828BC0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000828BC4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000828BCC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000828BD4: BF8903F7
	v_cvt_f32_f16_e32 v9, v3                                   // 000000828BD8: 7E121703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000828BDC: 8C7E017E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v3, 64, v31     // 000000828BE0: CA200080 0A023EC0
	v_mov_b32_e32 v11, 0                                       // 000000828BE8: 7E160280
	s_mov_b32 s1, exec_lo                                      // 000000828BEC: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000828BF0: BF870002
	.long 0xd4c1007e                                           // 000000828BF4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000828BF8: 02024103
	s_cbranch_execz 11                                         // 000000828BFC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000828C00: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828C04: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000828C08: 3408069F
	.long 0xd7006a03                                           // 000000828C0C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000828C10: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000828C14: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000828C1C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000828C24: BF8903F7
	v_cvt_f32_f16_e32 v10, v3                                  // 000000828C28: 7E141703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000828C2C: 8C7E017E
	v_add_nc_u32_e32 v3, 0x60, v31                             // 000000828C30: 4A063EFF 00000060
	s_mov_b32 s1, exec_lo                                      // 000000828C38: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000828C3C: BF870001
	.long 0xd4c1007e                                           // 000000828C40: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000828C44: 02024103
	s_cbranch_execz 11                                         // 000000828C48: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000828C4C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828C50: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000828C54: 3408069F
	.long 0xd7006a03                                           // 000000828C58: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000828C5C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000828C60: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000828C68: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000828C70: BF8903F7
	v_cvt_f32_f16_e32 v11, v3                                  // 000000828C74: 7E161703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000828C78: 8C7E017E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v3, 0x80, v31   // 000000828C7C: CA200080 0C023EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 000000828C88: 7E1A0280
	s_mov_b32 s1, exec_lo                                      // 000000828C8C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000828C90: BF870002
	.long 0xd4c1007e                                           // 000000828C94: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000828C98: 02024103
	s_cbranch_execz 11                                         // 000000828C9C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000828CA0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828CA4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000828CA8: 3408069F
	.long 0xd7006a03                                           // 000000828CAC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000828CB0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000828CB4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000828CBC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000828CC4: BF8903F7
	v_cvt_f32_f16_e32 v12, v3                                  // 000000828CC8: 7E181703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000828CCC: 8C7E017E
	v_add_nc_u32_e32 v3, 0xa0, v31                             // 000000828CD0: 4A063EFF 000000A0
	s_mov_b32 s1, exec_lo                                      // 000000828CD8: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000828CDC: BF870001
	.long 0xd4c1007e                                           // 000000828CE0: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000828CE4: 02024103
	s_cbranch_execz 11                                         // 000000828CE8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000828CEC: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828CF0: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000828CF4: 3408069F
	.long 0xd7006a03                                           // 000000828CF8: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000828CFC: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000828D00: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000828D08: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000828D10: BF8903F7
	v_cvt_f32_f16_e32 v13, v3                                  // 000000828D14: 7E1A1703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000828D18: 8C7E017E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v3, 0xc0, v31   // 000000828D1C: CA200080 0E023EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 000000828D28: 7E1E0280
	s_mov_b32 s1, exec_lo                                      // 000000828D2C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000828D30: BF870002
	.long 0xd4c1007e                                           // 000000828D34: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000828D38: 02024103
	s_cbranch_execz 11                                         // 000000828D3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000828D40: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828D44: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000828D48: 3408069F
	.long 0xd7006a03                                           // 000000828D4C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000828D50: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000828D54: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000828D5C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000828D64: BF8903F7
	v_cvt_f32_f16_e32 v14, v3                                  // 000000828D68: 7E1C1703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000828D6C: 8C7E017E
	v_add_nc_u32_e32 v3, 0xe0, v31                             // 000000828D70: 4A063EFF 000000E0
	s_mov_b32 s1, exec_lo                                      // 000000828D78: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000828D7C: BF870001
	.long 0xd4c1007e                                           // 000000828D80: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000828D84: 02024103
	s_cbranch_execz 11                                         // 000000828D88: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000828D8C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828D90: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000828D94: 3408069F
	.long 0xd7006a03                                           // 000000828D98: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000828D9C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000828DA0: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000828DA8: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000828DB0: BF8903F7
	v_cvt_f32_f16_e32 v15, v3                                  // 000000828DB4: 7E1E1703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000828DB8: 8C7E017E
	s_branch 9                                                 // 000000828DBC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v8, 0                                        // 000000828DC0: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000828DC4: BF870001
	v_mov_b32_e32 v9, v8                                       // 000000828DC8: 7E120308
	v_mov_b32_e32 v10, v8                                      // 000000828DCC: 7E140308
	v_mov_b32_e32 v11, v8                                      // 000000828DD0: 7E160308
	v_mov_b32_e32 v12, v8                                      // 000000828DD4: 7E180308
	v_mov_b32_e32 v13, v8                                      // 000000828DD8: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 000000828DDC: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 000000828DE0: 7E1E0308
	s_add_u32 s4, s4, s14                                      // 000000828DE4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000828DE8: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 000000828DEC: 85019F0B
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v27, 0             // 000000828DF0: CA100080 141A0080
	s_add_u32 s14, s10, s1                                     // 000000828DF8: 800E010A
	s_addc_u32 s15, s11, 0                                     // 000000828DFC: 820F800B
	.long 0xd4410001                                           // 000000828E00: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000828E04: 0202411F
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000828E08: 868E810E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v21, 0             // 000000828E0C: CA100080 22140080
	v_mad_u64_u32 v[25:26], null, v1, s14, s[4:5]              // 000000828E14: D6FE7C19 00101D01
	.long 0xd72c0001                                           // 000000828E1C: D72C0001
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 000000828E20: 02001F01
	.long 0xd72c0002                                           // 000000828E24: D72C0002
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 000000828E28: 02001D02
	v_cndmask_b32_e64 v35, 0, 1, s16                           // 000000828E2C: D5010023 00410280
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000828E34: CA100080 16160080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000828E3C: BF870003
	v_add3_u32 v36, v2, v26, v1                                // 000000828E40: D6550024 04063502
	s_and_saveexec_b32 s4, s1                                  // 000000828E48: BE842001
	s_cbranch_execz 22                                         // 000000828E4C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 4, v31                               // 000000828E50: 30023E84
	v_mov_b32_e32 v27, 0                                       // 000000828E54: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828E58: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000828E5C: 3404029F
	.long 0xd7006a01                                           // 000000828E60: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 000000828E64: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 000000828E68: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000828E70: 916A107E
	global_load_b128 v[20:23], v[1:2], off                     // 000000828E74: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 000000828E7C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 1, v31                               // 000000828E80: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828E84: BF870091
	.long 0xd7006a01                                           // 000000828E88: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000828E8C: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 000000828E90: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 000000828E98: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000828EA0: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 000000828EA4: 7E361701
	s_or_b32 exec_lo, exec_lo, s4                              // 000000828EA8: 8C7E047E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 000000828EAC: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 000000828EB4: CA100080 28280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v43, 0             // 000000828EBC: CA100080 2A2A0080
	v_mov_b32_e32 v37, 0                                       // 000000828EC4: 7E4A0280
	s_and_saveexec_b32 s14, s1                                 // 000000828EC8: BE8E2001
	s_cbranch_execz 666                                        // 000000828ECC: BFA5029A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xf38>
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 000000828ED0: CA200080 2A003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 000000828ED8: CA220080 251A3E85
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v38, 0             // 000000828EE0: CA100080 29260080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000828EE8: BF870003
	v_dual_mov_b32 v43, 0 :: v_dual_lshlrev_b32 v44, 4, v1     // 000000828EEC: CA220080 2B2C0284
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v45, 1, v1     // 000000828EF4: CA220080 282C0281
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v34, 0             // 000000828EFC: CA100080 27220080
	v_mov_b32_e32 v46, v27                                     // 000000828F04: 7E5C031B
	s_mul_i32 s1, s11, 6                                       // 000000828F08: 9601860B
	s_mul_hi_u32 s15, s10, 6                                   // 000000828F0C: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000828F10: 8484820A
	s_add_i32 s15, s15, s1                                     // 000000828F14: 810F010F
	s_mul_i32 s17, s10, 6                                      // 000000828F18: 9611860A
	s_mov_b32 s16, 0                                           // 000000828F1C: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000828F20: 848A810A
	s_branch 608                                               // 000000828F24: BFA00260 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xea8>
	s_or_b32 exec_lo, exec_lo, s18                             // 000000828F28: 8C7E127E
	v_cndmask_b32_e64 v47, v27, v8, s0                         // 000000828F2C: D501002F 0002111B
	v_cndmask_b32_e64 v4, v11, v12, s0                         // 000000828F34: D5010004 0002190B
	v_cndmask_b32_e64 v3, v10, v11, s0                         // 000000828F3C: D5010003 0002170A
	v_cndmask_b32_e64 v2, v9, v10, s0                          // 000000828F44: D5010002 00021509
	v_cndmask_b32_e64 v1, v8, v9, s0                           // 000000828F4C: D5010001 00021308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 000000828F54: CA24010F 080828FF 000000FF
	v_lshrrev_b32_e32 v10, 6, v20                              // 000000828F60: 32142886
	v_lshrrev_b32_e32 v11, 14, v20                             // 000000828F64: 3216288E
	v_cndmask_b32_e64 v7, v14, v15, s0                         // 000000828F68: D5010007 00021F0E
	v_cndmask_b32_e64 v6, v13, v14, s0                         // 000000828F70: D5010006 00021D0D
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000828F78: 30121282
	v_and_b32_e32 v10, 0x3fc, v10                              // 000000828F7C: 361414FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000828F84: 361616FF 000003FC
	v_cndmask_b32_e64 v5, v12, v13, s0                         // 000000828F8C: D5010005 00021B0C
	v_ashrrev_i32_e32 v27, 31, v26                             // 000000828F94: 3436349F
	ds_load_b32 v9, v9                                         // 000000828F98: D8D80000 09000009
	ds_load_b32 v10, v10                                       // 000000828FA0: D8D80000 0A00000A
	ds_load_b32 v15, v11                                       // 000000828FA8: D8D80000 0F00000B
	v_lshrrev_b32_e32 v11, 22, v20                             // 000000828FB0: 32162896
	s_and_b32 s1, exec_lo, s1                                  // 000000828FB4: 8B01017E
	v_add_nc_u32_e32 v44, 0x200, v44                           // 000000828FB8: 4A5858FF 00000200
	s_or_b32 s16, s1, s16                                      // 000000828FC0: 8C101001
	v_add_nc_u32_e32 v45, 64, v45                              // 000000828FC4: 4A5A5AC0
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000828FC8: 361616FF 000003FC
	ds_load_b32 v60, v11                                       // 000000828FD0: D8D80000 3C00000B
	v_and_b32_e32 v11, 0xff, v21                               // 000000828FD8: 36162AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000828FE0: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 000000828FE4: 30161682
	ds_load_b32 v61, v11                                       // 000000828FE8: D8D80000 3D00000B
	v_lshrrev_b32_e32 v11, 6, v21                              // 000000828FF0: 32162A86
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000828FF4: 361616FF 000003FC
	ds_load_b32 v62, v11                                       // 000000828FFC: D8D80000 3E00000B
	v_lshrrev_b32_e32 v11, 14, v21                             // 000000829004: 32162A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000829008: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 00000082900C: 361616FF 000003FC
	ds_load_b32 v63, v11                                       // 000000829014: D8D80000 3F00000B
	v_lshrrev_b32_e32 v11, 22, v21                             // 00000082901C: 32162A96
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000829020: 361616FF 000003FC
	ds_load_b32 v64, v11                                       // 000000829028: D8D80000 4000000B
	v_and_b32_e32 v11, 0xff, v22                               // 000000829030: 36162CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000829038: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 00000082903C: 30161682
	ds_load_b32 v65, v11                                       // 000000829040: D8D80000 4100000B
	v_lshrrev_b32_e32 v11, 6, v22                              // 000000829048: 32162C86
	v_and_b32_e32 v11, 0x3fc, v11                              // 00000082904C: 361616FF 000003FC
	ds_load_b32 v66, v11                                       // 000000829054: D8D80000 4200000B
	v_lshrrev_b32_e32 v11, 14, v22                             // 00000082905C: 32162C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000829060: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000829064: 361616FF 000003FC
	ds_load_b32 v67, v11                                       // 00000082906C: D8D80000 4300000B
	v_lshrrev_b32_e32 v11, 22, v22                             // 000000829074: 32162C96
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000829078: 361616FF 000003FC
	ds_load_b32 v68, v11                                       // 000000829080: D8D80000 4400000B
	v_and_b32_e32 v11, 0xff, v23                               // 000000829088: 36162EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000829090: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 000000829094: 30161682
	ds_load_b32 v69, v11                                       // 000000829098: D8D80000 4500000B
	v_lshrrev_b32_e32 v11, 6, v23                              // 0000008290A0: 32162E86
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008290A4: 361616FF 000003FC
	ds_load_b32 v70, v11                                       // 0000008290AC: D8D80000 4600000B
	v_lshrrev_b32_e32 v11, 14, v23                             // 0000008290B4: 32162E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008290B8: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008290BC: 361616FF 000003FC
	ds_load_b32 v71, v11                                       // 0000008290C4: D8D80000 4700000B
	v_lshrrev_b32_e32 v11, 22, v23                             // 0000008290CC: 32162E96
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008290D0: 361616FF 000003FC
	ds_load_b32 v72, v11                                       // 0000008290D8: D8D80000 4800000B
	.long 0xd73c000b                                           // 0000008290E0: D73C000B
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000008290E4: 02023481
	v_dual_mov_b32 v27, v46 :: v_dual_add_nc_u32 v26, 0x400, v26// 0000008290E8: CA20012E 1B1A34FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008290F4: BF870092
	.long 0xd7006a38                                           // 0000008290F8: D7006A38
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000008290FC: 02021606
	v_add_co_ci_u32_e64 v57, null, s7, v12, vcc_lo             // 000000829100: D5207C39 01AA1807
	s_clause 0x3                                               // 000000829108: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 00000082910C: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 000000829114: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 00000082911C: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 000000829124: DC5E0030 347C0038
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000082912C: BF890CF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000829130: CC1A400B 1A02130B
	s_waitcnt lgkmcnt(14)                                      // 000000829138: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082913C: BF8700A1
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000829140: CC1A400B 1C2E150C
	s_waitcnt lgkmcnt(13)                                      // 000000829148: BF89FCD7
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 00000082914C: CC1A400B 1C2E1F0D
	s_waitcnt lgkmcnt(12)                                      // 000000829154: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000829158: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 00000082915C: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000829164: BF8908B7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000829168: CC1A400B 1C2E7B14
	s_waitcnt lgkmcnt(10)                                      // 000000829170: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000829174: BF8700A1
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000829178: CC1A400B 1C2E7D15
	s_waitcnt lgkmcnt(9)                                       // 000000829180: BF89FC97
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000829184: CC1A400B 1C2E7F16
	s_waitcnt lgkmcnt(8)                                       // 00000082918C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000829190: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000829194: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000082919C: BF890477
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000008291A0: CC1A400B 1C2E8330
	s_waitcnt lgkmcnt(6)                                       // 0000008291A8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008291AC: BF8700A1
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000008291B0: CC1A400B 1C2E8531
	s_waitcnt lgkmcnt(5)                                       // 0000008291B8: BF89FC57
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000008291BC: CC1A400B 1C2E8732
	s_waitcnt lgkmcnt(4)                                       // 0000008291C4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008291C8: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000008291CC: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008291D4: BF890037
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000008291D8: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 0000008291E0: D7006A34
	v_cndmask_b32_e32 v0, v56, v10, vcc_lo                     // 0000008291E4: 02001538
	s_waitcnt lgkmcnt(2)                                       // 0000008291E8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008291EC: BF8701C2
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000008291F0: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s11, v57, vcc_lo            // 0000008291F8: D5207C35 01AA720B
	.long 0xd7006a3a                                           // 000000829200: D7006A3A
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 000000829204: 02000938
	s_waitcnt lgkmcnt(1)                                       // 000000829208: BF89FC17
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 00000082920C: CC1A400B 1C2E8F36
	v_add_co_ci_u32_e64 v59, null, s5, v57, vcc_lo             // 000000829214: D5207C3B 01AA7205
	.long 0xd7006a38                                           // 00000082921C: D7006A38
	v_cndmask_b32_e32 v0, v56, v17, vcc_lo                     // 000000829220: 02002338
	s_waitcnt lgkmcnt(0)                                       // 000000829224: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000829228: BF870123
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 00000082922C: CC1A400B 1C2E9137
	v_add_co_ci_u32_e64 v57, null, s15, v57, vcc_lo            // 000000829234: D5207C39 01AA720F
	v_fmac_f32_e32 v37, v47, v11                               // 00000082923C: 564A172F
	s_clause 0x3                                               // 000000829240: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 000000829244: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 00000082924C: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 000000829254: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 00000082925C: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 000000829264: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000829268: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829270: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000829274: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 00000082927C: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000829284: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000829288: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000829290: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000829294: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082929C: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000008292A0: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000008292A8: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008292B0: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000008292B4: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000008292BC: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000008292C0: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008292C8: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000008292CC: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000008292D4: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008292DC: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000008292E0: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000008292E8: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000008292EC: CC1A400B 1C2E8B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008292F4: BF870091
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000008292F8: CC1A400B 1C2E8D35
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 000000829300: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829308: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 00000082930C: CC1A400B 1C2E9137
	v_fmac_f32_e32 v43, v47, v11                               // 000000829314: 5656172F
	s_clause 0x3                                               // 000000829318: BF850003
	global_load_b128 v[11:14], v[58:59], off                   // 00000082931C: DC5E0000 0B7C003A
	global_load_b128 v[20:23], v[58:59], off offset:16         // 000000829324: DC5E0010 147C003A
	global_load_b128 v[48:51], v[58:59], off offset:32         // 00000082932C: DC5E0020 307C003A
	global_load_b128 v[52:55], v[58:59], off offset:48         // 000000829334: DC5E0030 347C003A
	.long 0xd7006a3a                                           // 00000082933C: D7006A3A
	v_cndmask_b32_e32 v0, v58, v4, vcc_lo                      // 000000829340: 0200093A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000829344: BF8700B1
	v_add_co_ci_u32_e64 v59, null, s5, v59, vcc_lo             // 000000829348: D5207C3B 01AA7605
	s_waitcnt vmcnt(3)                                         // 000000829350: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000829354: CC1A400B 1A02130B
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 00000082935C: CC1A400B 1C2E150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829364: BF870091
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000829368: CC1A400B 1C2E1F0D
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000829370: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000829378: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082937C: BF870091
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000829380: CC1A400B 1C2E7B14
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000829388: CC1A400B 1C2E7D15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829390: BF870091
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000829394: CC1A400B 1C2E7F16
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 00000082939C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000008293A4: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008293A8: BF870091
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000008293AC: CC1A400B 1C2E8330
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000008293B4: CC1A400B 1C2E8531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008293BC: BF870091
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000008293C0: CC1A400B 1C2E8732
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000008293C8: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000008293D0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008293D4: BF870091
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000008293D8: CC1A400B 1C2E8B34
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000008293E0: CC1A400B 1C2E8D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008293E8: BF870091
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000008293EC: CC1A400B 1C2E8F36
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000008293F4: CC1A400B 1C2E9137
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008293FC: BF870001
	v_fmac_f32_e32 v42, v47, v11                               // 000000829400: 5654172F
	s_clause 0x3                                               // 000000829404: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 000000829408: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 000000829410: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 000000829418: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 000000829420: DC5E0030 347C0038
	.long 0xd7006a38                                           // 000000829428: D7006A38
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 00000082942C: 02000938
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000829430: BF8700B1
	v_add_co_ci_u32_e64 v57, null, s5, v57, vcc_lo             // 000000829434: D5207C39 01AA7205
	s_waitcnt vmcnt(3)                                         // 00000082943C: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000829440: CC1A400B 1A02130B
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000829448: CC1A400B 1C2E150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829450: BF870091
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000829454: CC1A400B 1C2E1F0D
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 00000082945C: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000829464: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829468: BF870091
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 00000082946C: CC1A400B 1C2E7B14
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000829474: CC1A400B 1C2E7D15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082947C: BF870091
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000829480: CC1A400B 1C2E7F16
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000829488: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 000000829490: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829494: BF870091
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000829498: CC1A400B 1C2E8330
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000008294A0: CC1A400B 1C2E8531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008294A8: BF870091
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000008294AC: CC1A400B 1C2E8732
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000008294B4: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000008294BC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008294C0: BF870091
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000008294C4: CC1A400B 1C2E8B34
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000008294CC: CC1A400B 1C2E8D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008294D4: BF870091
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000008294D8: CC1A400B 1C2E8F36
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000008294E0: CC1A400B 1C2E9137
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008294E8: BF870001
	v_fmac_f32_e32 v41, v47, v11                               // 0000008294EC: 5652172F
	s_clause 0x3                                               // 0000008294F0: BF850003
	global_load_b128 v[11:14], v[58:59], off                   // 0000008294F4: DC5E0000 0B7C003A
	global_load_b128 v[20:23], v[58:59], off offset:16         // 0000008294FC: DC5E0010 147C003A
	global_load_b128 v[48:51], v[58:59], off offset:32         // 000000829504: DC5E0020 307C003A
	global_load_b128 v[52:55], v[58:59], off offset:48         // 00000082950C: DC5E0030 347C003A
	s_waitcnt vmcnt(3)                                         // 000000829514: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000829518: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829520: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000829524: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 00000082952C: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000829534: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000829538: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000829540: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000829544: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082954C: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000829550: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000829558: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000829560: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000829564: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 00000082956C: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000829570: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829578: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 00000082957C: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 000000829584: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082958C: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000829590: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 000000829598: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 00000082959C: CC1A400B 1C2E8B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008295A4: BF870091
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000008295A8: CC1A400B 1C2E8D35
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000008295B0: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008295B8: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000008295BC: CC1A400B 1C2E9137
	v_fmac_f32_e32 v40, v47, v11                               // 0000008295C4: 5650172F
	s_clause 0x3                                               // 0000008295C8: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 0000008295CC: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 0000008295D4: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000008295DC: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 0000008295E4: DC5E0030 347C0038
	s_waitcnt vmcnt(3)                                         // 0000008295EC: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000008295F0: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008295F8: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000008295FC: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000829604: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082960C: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000829610: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000829618: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 00000082961C: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829624: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000829628: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000829630: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000829638: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 00000082963C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 000000829644: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000829648: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829650: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 000000829654: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 00000082965C: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000829664: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000829668: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 000000829670: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 000000829674: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 00000082967C: D7006A34
	v_cndmask_b32_e32 v0, v58, v4, vcc_lo                      // 000000829680: 0200093A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000829684: BF870122
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 000000829688: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s5, v59, vcc_lo             // 000000829690: D5207C35 01AA7605
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 000000829698: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008296A0: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000008296A4: CC1A400B 1C2E9137
	v_fmac_f32_e32 v39, v47, v11                               // 0000008296AC: 564E172F
	s_clause 0x3                                               // 0000008296B0: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 0000008296B4: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 0000008296BC: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 0000008296C4: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 0000008296CC: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 0000008296D4: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000008296D8: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008296E0: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000008296E4: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000008296EC: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008296F4: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000008296F8: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000829700: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000829704: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082970C: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000829710: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000829718: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000829720: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000829724: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 00000082972C: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000829730: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829738: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 00000082973C: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 000000829744: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082974C: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000829750: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 000000829758: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 00000082975C: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 000000829764: D7006A34
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 000000829768: 02000938
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000082976C: BF870122
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 000000829770: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s5, v57, vcc_lo             // 000000829778: D5207C35 01AA7205
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 000000829780: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829788: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 00000082978C: CC1A400B 1C2E9137
	v_fmac_f32_e32 v38, v47, v11                               // 000000829794: 564C172F
	s_clause 0x3                                               // 000000829798: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 00000082979C: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 0000008297A4: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 0000008297AC: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 0000008297B4: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 0000008297BC: BF890FF7
	v_dot2_f32_bf16 v9, v11, v9, 0                             // 0000008297C0: CC1A4009 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008297C8: BF870091
	v_dot2_f32_bf16 v9, v12, v10, v9                           // 0000008297CC: CC1A4009 1C26150C
	v_dot2_f32_bf16 v9, v13, v15, v9                           // 0000008297D4: CC1A4009 1C261F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008297DC: BF8700A1
	v_dot2_f32_bf16 v9, v14, v60, v9                           // 0000008297E0: CC1A4009 1C26790E
	s_waitcnt vmcnt(2)                                         // 0000008297E8: BF890BF7
	v_dot2_f32_bf16 v9, v20, v61, v9                           // 0000008297EC: CC1A4009 1C267B14
	v_mov_b32_e32 v20, v16                                     // 0000008297F4: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008297F8: BF870122
	v_dot2_f32_bf16 v9, v21, v62, v9                           // 0000008297FC: CC1A4009 1C267D15
	v_mov_b32_e32 v21, v17                                     // 000000829804: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v63, v9                           // 000000829808: CC1A4009 1C267F16
	v_mov_b32_e32 v22, v18                                     // 000000829810: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000829814: BF870132
	v_dot2_f32_bf16 v9, v23, v64, v9                           // 000000829818: CC1A4009 1C268117
	v_mov_b32_e32 v23, v19                                     // 000000829820: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 000000829824: BF8907F7
	v_dot2_f32_bf16 v9, v48, v65, v9                           // 000000829828: CC1A4009 1C268330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829830: BF870091
	v_dot2_f32_bf16 v9, v49, v66, v9                           // 000000829834: CC1A4009 1C268531
	v_dot2_f32_bf16 v9, v50, v67, v9                           // 00000082983C: CC1A4009 1C268732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000829844: BF8700A1
	v_dot2_f32_bf16 v9, v51, v68, v9                           // 000000829848: CC1A4009 1C268933
	s_waitcnt vmcnt(0)                                         // 000000829850: BF8903F7
	v_dot2_f32_bf16 v9, v52, v69, v9                           // 000000829854: CC1A4009 1C268B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082985C: BF870091
	v_dot2_f32_bf16 v9, v53, v70, v9                           // 000000829860: CC1A4009 1C268D35
	v_dot2_f32_bf16 v9, v54, v71, v9                           // 000000829868: CC1A4009 1C268F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829870: BF870091
	v_dot2_f32_bf16 v9, v55, v72, v9                           // 000000829874: CC1A4009 1C269137
	v_dual_fmac_f32 v34, v47, v9 :: v_dual_mov_b32 v15, v8     // 00000082987C: C810132F 220E0108
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 000000829884: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 00000082988C: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 000000829894: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 00000082989C: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008298A0: 917E107E
	s_cbranch_execz 35                                         // 0000008298A4: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xf34>
	s_waitcnt vmcnt(0)                                         // 0000008298A8: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 0000008298AC: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 0000008298B4: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 0000008298BC: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008298C0: BF870003
	.long 0xd4460001                                           // 0000008298C4: D4460001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008298C8: 0202411F
	s_mov_b32 s18, exec_lo                                     // 0000008298CC: BE92007E
	.long 0xd4c1007e                                           // 0000008298D0: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008298D4: 0202411F
	s_cbranch_execz 64915                                      // 0000008298D8: BFA5FD93 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x528>
	v_ashrrev_i32_e32 v2, 31, v44                              // 0000008298DC: 3404589F
	.long 0xd7006a01                                           // 0000008298E0: D7006A01
	v_cndmask_b32_e32 v1, v25, v44, vcc_lo                     // 0000008298E4: 02025919
	v_mov_b32_e32 v46, v27                                     // 0000008298E8: 7E5C031B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008298EC: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 0000008298F0: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 0000008298F8: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 0000008298FC: DC5E0000 107C0001
	s_cbranch_vccnz 64904                                      // 000000829904: BFA4FD88 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x528>
	v_ashrrev_i32_e32 v2, 31, v45                              // 000000829908: 34045A9F
	.long 0xd7006a01                                           // 00000082990C: D7006A01
	v_cndmask_b32_e32 v1, v24, v45, vcc_lo                     // 000000829910: 02025B18
	s_delay_alu instid0(VALU_DEP_1)                            // 000000829914: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000829918: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000829920: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000829928: BF8903F7
	v_cvt_f32_f16_e32 v46, v1                                  // 00000082992C: 7E5C1701
	s_branch 64893                                             // 000000829930: BFA0FD7D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x528>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000829934: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000829938: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 00000082993C: 8C7E0E7E
	.long 0xd71f0001                                           // 000000829940: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000829944: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000829948: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000082994C: 3A040290
	v_xor_b32_e32 v10, 8, v1                                   // 000000829950: 3A140288
	v_xor_b32_e32 v18, 4, v1                                   // 000000829954: 3A240284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000829958: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000082995C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000829960: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000829964: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000829968: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000082996C: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 000000829970: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 000000829978: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 00000082997C: 06060725
	ds_bpermute_b32 v5, v2, v42                                // 000000829980: DACC0000 05002A02
	ds_bpermute_b32 v7, v2, v40                                // 000000829988: DACC0000 07002802
	ds_bpermute_b32 v9, v2, v38                                // 000000829990: DACC0000 09002602
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000829998: 02141501
	ds_bpermute_b32 v4, v2, v43                                // 00000082999C: DACC0000 04002B02
	ds_bpermute_b32 v6, v2, v41                                // 0000008299A4: DACC0000 06002902
	ds_bpermute_b32 v8, v2, v39                                // 0000008299AC: DACC0000 08002702
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000008299B4: 7C9824A0
	ds_bpermute_b32 v2, v2, v34                                // 0000008299B8: DACC0000 02002202
	s_waitcnt lgkmcnt(6)                                       // 0000008299C0: BF89FC67
	v_dual_cndmask_b32 v18, v1, v18 :: v_dual_add_f32 v5, v42, v5// 0000008299C4: CA482501 12040B2A
	s_waitcnt lgkmcnt(5)                                       // 0000008299CC: BF89FC57
	v_dual_add_f32 v7, v40, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 0000008299D0: C9220F28 070A1482
	s_waitcnt lgkmcnt(4)                                       // 0000008299D8: BF89FC47
	v_add_f32_e32 v9, v38, v9                                  // 0000008299DC: 06121326
	ds_bpermute_b32 v13, v10, v5                               // 0000008299E0: DACC0000 0D00050A
	s_waitcnt lgkmcnt(4)                                       // 0000008299E8: BF89FC47
	v_add_f32_e32 v4, v43, v4                                  // 0000008299EC: 0608092B
	ds_bpermute_b32 v11, v10, v3                               // 0000008299F0: DACC0000 0B00030A
	ds_bpermute_b32 v17, v10, v9                               // 0000008299F8: DACC0000 1100090A
	s_waitcnt lgkmcnt(5)                                       // 000000829A00: BF89FC57
	v_add_f32_e32 v6, v41, v6                                  // 000000829A04: 060C0D29
	s_waitcnt lgkmcnt(4)                                       // 000000829A08: BF89FC47
	v_add_f32_e32 v8, v39, v8                                  // 000000829A0C: 06101127
	ds_bpermute_b32 v15, v10, v7                               // 000000829A10: DACC0000 0F00070A
	s_waitcnt lgkmcnt(3)                                       // 000000829A18: BF89FC37
	v_dual_add_f32 v2, v34, v2 :: v_dual_add_f32 v5, v5, v13   // 000000829A1C: C9080522 02041B05
	ds_bpermute_b32 v12, v10, v4                               // 000000829A24: DACC0000 0C00040A
	s_waitcnt lgkmcnt(3)                                       // 000000829A2C: BF89FC37
	v_dual_add_f32 v3, v3, v11 :: v_dual_lshlrev_b32 v18, 2, v18// 000000829A30: C9221703 03122482
	ds_bpermute_b32 v14, v10, v6                               // 000000829A38: DACC0000 0E00060A
	s_waitcnt lgkmcnt(3)                                       // 000000829A40: BF89FC37
	v_add_f32_e32 v9, v9, v17                                  // 000000829A44: 06122309
	ds_bpermute_b32 v16, v10, v8                               // 000000829A48: DACC0000 1000080A
	s_waitcnt lgkmcnt(3)                                       // 000000829A50: BF89FC37
	v_add_f32_e32 v7, v7, v15                                  // 000000829A54: 060E1F07
	ds_bpermute_b32 v10, v10, v2                               // 000000829A58: DACC0000 0A00020A
	s_waitcnt lgkmcnt(3)                                       // 000000829A60: BF89FC37
	v_add_f32_e32 v4, v4, v12                                  // 000000829A64: 06081904
	ds_bpermute_b32 v12, v18, v5                               // 000000829A68: DACC0000 0C000512
	s_waitcnt lgkmcnt(2)                                       // 000000829A70: BF89FC27
	v_add_f32_e32 v8, v8, v16                                  // 000000829A74: 06102108
	s_waitcnt lgkmcnt(0)                                       // 000000829A78: BF89FC07
	v_add_f32_e32 v5, v5, v12                                  // 000000829A7C: 060A1905
	ds_bpermute_b32 v16, v18, v9                               // 000000829A80: DACC0000 10000912
	v_add_f32_e32 v6, v6, v14                                  // 000000829A88: 060C1D06
	ds_bpermute_b32 v14, v18, v7                               // 000000829A8C: DACC0000 0E000712
	s_waitcnt lgkmcnt(1)                                       // 000000829A94: BF89FC17
	v_add_f32_e32 v9, v9, v16                                  // 000000829A98: 06122109
	ds_bpermute_b32 v13, v18, v6                               // 000000829A9C: DACC0000 0D000612
	s_waitcnt lgkmcnt(1)                                       // 000000829AA4: BF89FC17
	v_add_f32_e32 v7, v7, v14                                  // 000000829AA8: 060E1D07
	ds_bpermute_b32 v15, v18, v8                               // 000000829AAC: DACC0000 0F000812
	s_waitcnt lgkmcnt(0)                                       // 000000829AB4: BF89FC07
	v_add_f32_e32 v8, v8, v15                                  // 000000829AB8: 06101F08
	v_add_f32_e32 v2, v2, v10                                  // 000000829ABC: 06041502
	ds_bpermute_b32 v10, v18, v3                               // 000000829AC0: DACC0000 0A000312
	ds_bpermute_b32 v17, v18, v2                               // 000000829AC8: DACC0000 11000212
	s_waitcnt lgkmcnt(1)                                       // 000000829AD0: BF89FC17
	v_add_f32_e32 v3, v3, v10                                  // 000000829AD4: 06061503
	ds_bpermute_b32 v11, v18, v4                               // 000000829AD8: DACC0000 0B000412
	v_xor_b32_e32 v18, 2, v1                                   // 000000829AE0: 3A240282
	s_waitcnt lgkmcnt(1)                                       // 000000829AE4: BF89FC17
	v_add_f32_e32 v10, v2, v17                                 // 000000829AE8: 06142302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000829AEC: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 000000829AF0: 7C9824A0
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 000000829AF4: 02242501
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000829AF8: 30242482
	s_waitcnt lgkmcnt(0)                                       // 000000829AFC: BF89FC07
	v_add_f32_e32 v4, v4, v11                                  // 000000829B00: 06081704
	ds_bpermute_b32 v2, v18, v3                                // 000000829B04: DACC0000 02000312
	v_add_f32_e32 v6, v6, v13                                  // 000000829B0C: 060C1B06
	ds_bpermute_b32 v12, v18, v5                               // 000000829B10: DACC0000 0C000512
	ds_bpermute_b32 v14, v18, v7                               // 000000829B18: DACC0000 0E000712
	ds_bpermute_b32 v11, v18, v4                               // 000000829B20: DACC0000 0B000412
	ds_bpermute_b32 v15, v18, v8                               // 000000829B28: DACC0000 0F000812
	ds_bpermute_b32 v13, v18, v6                               // 000000829B30: DACC0000 0D000612
	ds_bpermute_b32 v16, v18, v9                               // 000000829B38: DACC0000 10000912
	ds_bpermute_b32 v17, v18, v10                              // 000000829B40: DACC0000 11000A12
	v_xor_b32_e32 v18, 1, v1                                   // 000000829B48: 3A240281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000829B4C: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 000000829B50: 7C9824A0
	v_cndmask_b32_e32 v1, v1, v18, vcc_lo                      // 000000829B54: 02022501
	s_waitcnt lgkmcnt(7)                                       // 000000829B58: BF89FC77
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v18, 2, v1 // 000000829B5C: C9220503 01120282
	s_waitcnt lgkmcnt(4)                                       // 000000829B64: BF89FC47
	v_add_f32_e32 v2, v4, v11                                  // 000000829B68: 06041704
	s_waitcnt lgkmcnt(2)                                       // 000000829B6C: BF89FC27
	v_dual_add_f32 v4, v5, v12 :: v_dual_add_f32 v5, v6, v13   // 000000829B70: C9081905 04041B06
	v_add_f32_e32 v3, v7, v14                                  // 000000829B78: 06061D07
	s_waitcnt lgkmcnt(1)                                       // 000000829B7C: BF89FC17
	v_dual_add_f32 v11, v8, v15 :: v_dual_add_f32 v12, v9, v16 // 000000829B80: C9081F08 0B0C2109
	s_waitcnt lgkmcnt(0)                                       // 000000829B88: BF89FC07
	v_add_f32_e32 v13, v10, v17                                // 000000829B8C: 061A230A
	ds_bpermute_b32 v6, v18, v1                                // 000000829B90: DACC0000 06000112
	ds_bpermute_b32 v7, v18, v2                                // 000000829B98: DACC0000 07000212
	ds_bpermute_b32 v9, v18, v4                                // 000000829BA0: DACC0000 09000412
	ds_bpermute_b32 v10, v18, v5                               // 000000829BA8: DACC0000 0A000512
	ds_bpermute_b32 v8, v18, v3                                // 000000829BB0: DACC0000 08000312
	ds_bpermute_b32 v14, v18, v11                              // 000000829BB8: DACC0000 0E000B12
	ds_bpermute_b32 v15, v18, v12                              // 000000829BC0: DACC0000 0F000C12
	ds_bpermute_b32 v16, v18, v13                              // 000000829BC8: DACC0000 10000D12
	v_cmpx_eq_u32_e32 0, v30                                   // 000000829BD0: 7D943C80
	s_cbranch_execz 17                                         // 000000829BD4: BFA50011 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x121c>
	s_waitcnt lgkmcnt(2)                                       // 000000829BD8: BF89FC27
	v_dual_add_f32 v11, v11, v14 :: v_dual_lshlrev_b32 v18, 5, v29// 000000829BDC: C9221D0B 0B123A85
	s_waitcnt lgkmcnt(0)                                       // 000000829BE4: BF89FC07
	v_dual_add_f32 v13, v13, v16 :: v_dual_add_f32 v12, v12, v15// 000000829BE8: C908210D 0D0C1F0C
	v_dual_add_f32 v17, v5, v10 :: v_dual_add_f32 v16, v4, v9  // 000000829BF0: C9081505 11101304
	v_dual_add_f32 v15, v2, v7 :: v_dual_add_f32 v14, v1, v6   // 000000829BF8: C9080F02 0F0E0D01
	v_lshl_or_b32 v1, v28, 6, v18                              // 000000829C00: D6560001 04490D1C
	v_add_f32_e32 v10, v3, v8                                  // 000000829C08: 06141103
	ds_store_b128 v1, v[14:17] offset:1024                     // 000000829C0C: DB7C0400 00000E01
	ds_store_b128 v1, v[10:13] offset:1040                     // 000000829C14: DB7C0410 00000A01
	s_or_b32 exec_lo, exec_lo, s0                              // 000000829C1C: 8C7E007E
	v_lshrrev_b32_e32 v3, 3, v0                                // 000000829C20: 32060083
	v_mov_b32_e32 v2, s3                                       // 000000829C24: 7E040203
	.long 0xd44c0000                                           // 000000829C28: D44C0000
	v_cndmask_b32_e32 v1, 32, v0, vcc_lo                       // 000000829C2C: 020200A0
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000829C30: BF890007
	s_barrier                                                  // 000000829C34: BFBD0000
	v_or_b32_e32 v1, s2, v3                                    // 000000829C38: 38020602
	buffer_gl0_inv                                             // 000000829C3C: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000829C44: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 000000829C48: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000829C4C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000829C50: BE812000
	s_cbranch_execz 76                                         // 000000829C54: BFA5004C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1388>
	v_and_b32_e32 v0, 7, v0                                    // 000000829C58: 36000087
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829C5C: BF870091
	v_lshlrev_b32_e32 v4, 2, v0                                // 000000829C60: 30080082
	v_lshl_or_b32 v3, v3, 6, v4                                // 000000829C64: D6560003 04110D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000829C6C: BF8700C1
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000829C70: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:8                     // 000000829C78: D8DC0800 03000003
	s_waitcnt lgkmcnt(0)                                       // 000000829C80: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 000000829C84: 06060680
	v_add_f32_e32 v3, v3, v4                                   // 000000829C88: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829C8C: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 000000829C90: D6100004 02052103
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000829C98: D6550003 03FE0903 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829CA4: BF870091
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000829CA8: 360606FF FFFF0000
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 000000829CB0: 100606FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000829CB8: BF870291
	v_exp_f32_e32 v3, v3                                       // 000000829CBC: 7E064B03
	v_add_f32_e32 v6, 1.0, v3                                  // 000000829CC0: 060C06F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000829CC4: BF870121
	v_div_scale_f32 v5, null, v6, v6, 1.0                      // 000000829CC8: D6FC7C05 03CA0D06
	v_div_scale_f32 v8, vcc_lo, 1.0, v6, 1.0                   // 000000829CD0: D6FC6A08 03CA0CF2
	v_rcp_f32_e32 v7, v5                                       // 000000829CD8: 7E0E5505
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829CDC: BF870095
	v_fma_f32 v3, -v5, v7, 1.0                                 // 000000829CE0: D6130003 23CA0F05
	v_fmac_f32_e32 v7, v3, v7                                  // 000000829CE8: 560E0F03
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000829CEC: D6FE7C03 0202000C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829CF4: BF870092
	v_mul_f32_e32 v9, v8, v7                                   // 000000829CF8: 10120F08
	v_fma_f32 v10, -v5, v9, v8                                 // 000000829CFC: D613000A 24221305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000829D04: BF870091
	v_fmac_f32_e32 v9, v10, v7                                 // 000000829D08: 56120F0A
	v_fma_f32 v8, -v5, v9, v8                                  // 000000829D0C: D6130008 24221305
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000829D14: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000829D1C: BF870112
	v_div_fmas_f32 v0, v8, v7, v9                              // 000000829D20: D6370000 04260F08
	.long 0xd73c0003                                           // 000000829D28: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 000000829D2C: 02020681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000829D30: BF8701A2
	v_div_fixup_f32 v5, v0, v6, 1.0                            // 000000829D34: D6270005 03CA0D00
	.long 0xd73c0000                                           // 000000829D3C: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000829D40: 02020281
	.long 0xd7006a03                                           // 000000829D44: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000829D48: 02020608
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000829D4C: BF8701A3
	v_bfe_u32 v2, v5, 16, 1                                    // 000000829D50: D6100002 02052105
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000829D58: D5207C04 01AA0809
	.long 0xd7006a00                                           // 000000829D60: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000829D64: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000829D68: BF870193
	v_add3_u32 v2, v5, v2, 0x7fff                              // 000000829D6C: D6550002 03FE0505 00007FFF
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000829D78: D5207C01 01AA0304
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000829D80: DC960000 007C0200
	s_endpgm                                                   // 000000829D88: BFB00000
		...

