000000000022e600 <_ZN7halogen12_GLOBAL__N_111k_ht_tg_sumEPKfiPKDF16_Ptii>:
; _ZN7halogen12_GLOBAL__N_111k_ht_tg_sumEPKfiPKDF16_Ptii():
	s_load_b64 s[4:5], s[0:1], 0x20                            // 00000022E600: F4040100 F8000020
	s_mov_b32 s3, 0                                            // 00000022E608: BE830080
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000022E60C: 32020085
	s_lshl_b64 s[2:3], s[2:3], 3                               // 00000022E610: 84828302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022E614: BF870119
	v_mov_b32_e32 v2, s3                                       // 00000022E618: 7E040203
	v_or_b32_e32 v1, s2, v1                                    // 00000022E61C: 38020202
	s_waitcnt lgkmcnt(0)                                       // 00000022E620: BF89FC07
	s_ashr_i32 s10, s5, 31                                     // 00000022E624: 860A9F05
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000022E628: BF870499
	s_lshr_b32 s6, s10, 25                                     // 00000022E62C: 8506990A
	s_add_i32 s3, s5, s6                                       // 00000022E630: 81030605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000022E634: BF870499
	s_ashr_i32 s12, s3, 7                                      // 00000022E638: 860C8703
	s_mul_hi_i32 s3, s12, s4                                   // 00000022E63C: 9703040C
	s_mul_i32 s2, s12, s4                                      // 00000022E640: 9602040C
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000022E644: BF870009
	v_cmp_gt_i64_e32 vcc_lo, s[2:3], v[1:2]                    // 00000022E648: 7CA80202
	s_and_saveexec_b32 s2, vcc_lo                              // 00000022E64C: BE82206A
	s_cbranch_execz 510                                        // 00000022E650: BFA501FE <_ZN7halogen12_GLOBAL__N_111k_ht_tg_sumEPKfiPKDF16_Ptii+0x84c>
	s_ashr_i32 s2, s12, 31                                     // 00000022E654: 86029F0C
	s_mov_b32 s11, s5                                          // 00000022E658: BE8B0005
	v_or_b32_e32 v3, s2, v2                                    // 00000022E65C: 38060402
	s_mov_b32 s3, exec_lo                                      // 00000022E660: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022E664: BF870001
	v_cmpx_ne_u32_e32 0, v3                                    // 00000022E668: 7D9A0680
	s_xor_b32 s3, exec_lo, s3                                  // 00000022E66C: 8D03037E
	s_cbranch_execz 170                                        // 00000022E670: BFA500AA <_ZN7halogen12_GLOBAL__N_111k_ht_tg_sumEPKfiPKDF16_Ptii+0x31c>
	s_ashr_i32 s6, s2, 31                                      // 00000022E674: 86069F02
	v_ashrrev_i32_e32 v8, 31, v2                               // 00000022E678: 3410049F
	s_add_u32 s8, s12, s6                                      // 00000022E67C: 8008060C
	s_mov_b32 s7, s6                                           // 00000022E680: BE870006
	s_addc_u32 s9, s2, s6                                      // 00000022E684: 82090602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000022E688: BF870499
	s_xor_b64 s[8:9], s[8:9], s[6:7]                           // 00000022E68C: 8D880608
	s_cvt_f32_u32 s2, s8                                       // 00000022E690: BE826508
	s_cvt_f32_u32 s7, s9                                       // 00000022E694: BE876509
	s_sub_u32 s13, 0, s8                                       // 00000022E698: 808D0880
	s_subb_u32 s14, 0, s9                                      // 00000022E69C: 828E0980
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000022E6A0: BF870599
	s_fmamk_f32 s2, s7, 0x4f800000, s2                         // 00000022E6A4: A3020207 4F800000
	v_rcp_f32_e32 v3, s2                                       // 00000022E6AC: 7E065402
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000022E6B0: BF8700A5
	v_readfirstlane_b32 s2, v3                                 // 00000022E6B4: 7E040503
	.long 0xd7006a03                                           // 00000022E6B8: D7006A03
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 00000022E6BC: 02021101
	v_add_co_ci_u32_e64 v2, null, v2, v8, vcc_lo               // 00000022E6C0: D5207C02 01AA1102
	s_mul_f32 s2, s2, 0x5f7ffffc                               // 00000022E6C8: A202FF02 5F7FFFFC
	v_xor_b32_e32 v10, v3, v8                                  // 00000022E6D0: 3A141103
	v_xor_b32_e32 v9, v2, v8                                   // 00000022E6D4: 3A121102
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000022E6D8: BF870599
	s_mul_f32 s7, s2, 0x2f800000                               // 00000022E6DC: A207FF02 2F800000
	s_trunc_f32 s7, s7                                         // 00000022E6E4: BE876207
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 00000022E6E8: BF87052B
	s_fmamk_f32 s2, s7, 0xcf800000, s2                         // 00000022E6EC: A3020207 CF800000
	s_cvt_u32_f32 s7, s7                                       // 00000022E6F4: BE876707
	s_cvt_u32_f32 s2, s2                                       // 00000022E6F8: BE826702
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_2)// 00000022E6FC: BF87051A
	s_mul_i32 s15, s13, s7                                     // 00000022E700: 960F070D
	s_mul_hi_u32 s17, s13, s2                                  // 00000022E704: 9691020D
	s_mul_i32 s16, s14, s2                                     // 00000022E708: 9610020E
	s_add_i32 s15, s17, s15                                    // 00000022E70C: 810F0F11
	s_mul_i32 s18, s13, s2                                     // 00000022E710: 9612020D
	s_add_i32 s15, s15, s16                                    // 00000022E714: 810F100F
	s_mul_hi_u32 s17, s2, s18                                  // 00000022E718: 96911202
	s_mul_i32 s20, s2, s15                                     // 00000022E71C: 96140F02
	s_mul_hi_u32 s19, s7, s18                                  // 00000022E720: 96931207
	s_mul_i32 s16, s7, s18                                     // 00000022E724: 96101207
	s_mul_hi_u32 s18, s2, s15                                  // 00000022E728: 96920F02
	s_add_u32 s17, s17, s20                                    // 00000022E72C: 80111411
	s_addc_u32 s18, 0, s18                                     // 00000022E730: 82121280
	s_mul_hi_u32 s21, s7, s15                                  // 00000022E734: 96950F07
	s_add_u32 s16, s17, s16                                    // 00000022E738: 80101011
	s_mul_i32 s15, s7, s15                                     // 00000022E73C: 960F0F07
	s_addc_u32 s16, s18, s19                                   // 00000022E740: 82101312
	s_addc_u32 s17, s21, 0                                     // 00000022E744: 82118015
	s_add_u32 s15, s16, s15                                    // 00000022E748: 800F0F10
	s_addc_u32 s16, 0, s17                                     // 00000022E74C: 82101180
	s_add_u32 s2, s2, s15                                      // 00000022E750: 80020F02
	s_addc_u32 s7, s7, s16                                     // 00000022E754: 82071007
	s_mul_hi_u32 s15, s13, s2                                  // 00000022E758: 968F020D
	s_mul_i32 s16, s13, s2                                     // 00000022E75C: 9610020D
	s_mul_i32 s13, s13, s7                                     // 00000022E760: 960D070D
	s_mul_i32 s14, s14, s2                                     // 00000022E764: 960E020E
	s_add_i32 s13, s15, s13                                    // 00000022E768: 810D0D0F
	s_mul_i32 s15, s7, s16                                     // 00000022E76C: 960F1007
	s_add_i32 s13, s13, s14                                    // 00000022E770: 810D0E0D
	s_mul_hi_u32 s14, s2, s16                                  // 00000022E774: 968E1002
	s_mul_i32 s19, s2, s13                                     // 00000022E778: 96130D02
	s_mul_hi_u32 s18, s2, s13                                  // 00000022E77C: 96920D02
	s_add_u32 s14, s14, s19                                    // 00000022E780: 800E130E
	s_mul_hi_u32 s17, s7, s16                                  // 00000022E784: 96911007
	s_addc_u32 s18, 0, s18                                     // 00000022E788: 82121280
	s_mul_hi_u32 s16, s7, s13                                  // 00000022E78C: 96900D07
	s_add_u32 s14, s14, s15                                    // 00000022E790: 800E0F0E
	s_mul_i32 s13, s7, s13                                     // 00000022E794: 960D0D07
	s_addc_u32 s14, s18, s17                                   // 00000022E798: 820E1112
	s_addc_u32 s15, s16, 0                                     // 00000022E79C: 820F8010
	s_add_u32 s13, s14, s13                                    // 00000022E7A0: 800D0D0E
	s_addc_u32 s14, 0, s15                                     // 00000022E7A4: 820E0F80
	s_add_u32 s2, s2, s13                                      // 00000022E7A8: 80020D02
	s_addc_u32 s7, s7, s14                                     // 00000022E7AC: 82070E07
	.long 0xd72d000b                                           // 00000022E7B0: D72D000B
	v_cndmask_b32_e32 v0, v10, v2, vcc_lo                      // 00000022E7B4: 0200050A
	v_mad_u64_u32 v[2:3], null, v10, s7, 0                     // 00000022E7B8: D6FE7C02 02000F0A
	v_mad_u64_u32 v[4:5], null, v9, s2, 0                      // 00000022E7C0: D6FE7C04 02000509
	v_mad_u64_u32 v[6:7], null, v9, s7, 0                      // 00000022E7C8: D6FE7C06 02000F09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E7D0: BF870093
	.long 0xd7006a02                                           // 00000022E7D4: D7006A02
	v_cndmask_b32_e32 v1, v11, v2, vcc_lo                      // 00000022E7D8: 0202050B
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000022E7DC: D5207C03 01AA0680
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022E7E4: BF870112
	.long 0xd7006a02                                           // 00000022E7E8: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000022E7EC: 02020902
	v_add_co_ci_u32_e32 v2, vcc_lo, v3, v5, vcc_lo             // 00000022E7F0: 40040B03
	v_add_co_ci_u32_e32 v3, vcc_lo, 0, v7, vcc_lo              // 00000022E7F4: 40060E80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E7F8: BF870092
	.long 0xd7006a04                                           // 00000022E7FC: D7006A04
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000022E800: 02020D02
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 00000022E804: D5207C05 01AA0680
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000022E80C: BF8701A2
	.long 0xd72c0006                                           // 00000022E810: D72C0006
	v_cndmask_b32_e32 v1, s9, v4, vcc_lo                       // 00000022E814: 02020809
	v_mad_u64_u32 v[2:3], null, s8, v4, 0                      // 00000022E818: D6FE7C02 02020808
	.long 0xd72c0007                                           // 00000022E820: D72C0007
	v_cndmask_b32_e32 v1, s8, v5, vcc_lo                       // 00000022E824: 02020A08
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022E828: BF870112
	.long 0xd7016a02                                           // 00000022E82C: D7016A02
	v_cndmask_b32_e32 v1, v10, v2, vcc_lo                      // 00000022E830: 0202050A
	v_add3_u32 v3, v3, v7, v6                                  // 00000022E834: D6550003 041A0F03
	.long 0xd7000207                                           // 00000022E83C: D7000207
	v_cndmask_b32_e32 v0, v4, v130, vcc_lo                     // 00000022E840: 02010504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000022E844: BF870191
	v_add_co_ci_u32_e64 v10, null, 0, v5, s2                   // 00000022E848: D5207C0A 000A0A80
	v_sub_nc_u32_e32 v6, v9, v3                                // 00000022E850: 4C0C0709
	.long 0xd701020b                                           // 00000022E854: D701020B
	v_cndmask_b32_e32 v0, v2, v8, vcc_lo                       // 00000022E858: 02001102
	v_sub_co_ci_u32_e64 v3, null, v9, v3, vcc_lo               // 00000022E85C: D5217C03 01AA0709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000022E864: BF870193
	v_subrev_co_ci_u32_e64 v6, null, s9, v6, vcc_lo            // 00000022E868: D5227C06 01AA0C09
	v_cmp_le_u32_e32 vcc_lo, s8, v11                           // 00000022E870: 7C961608
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000022E874: BF870122
	v_subrev_co_ci_u32_e64 v6, null, 0, v6, s2                 // 00000022E878: D5227C06 000A0C80
	v_cndmask_b32_e64 v9, 0, -1, vcc_lo                        // 00000022E880: D5010009 01A98280
	v_cmp_le_u32_e32 vcc_lo, s9, v6                            // 00000022E888: 7C960C09
	v_cndmask_b32_e64 v11, 0, -1, vcc_lo                       // 00000022E88C: D501000B 01A98280
	v_cmp_le_u32_e32 vcc_lo, s8, v2                            // 00000022E894: 7C960408
	v_cndmask_b32_e64 v2, 0, -1, vcc_lo                        // 00000022E898: D5010002 01A98280
	v_cmp_le_u32_e32 vcc_lo, s9, v3                            // 00000022E8A0: 7C960609
	v_cndmask_b32_e64 v12, 0, -1, vcc_lo                       // 00000022E8A4: D501000C 01A98280
	v_cmp_eq_u32_e32 vcc_lo, s9, v6                            // 00000022E8AC: 7C940C09
	v_cndmask_b32_e32 v6, v11, v9, vcc_lo                      // 00000022E8B0: 020C130B
	.long 0xd7006a09                                           // 00000022E8B4: D7006A09
	v_cndmask_b32_e32 v0, v4, v129, vcc_lo                     // 00000022E8B8: 02010304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000022E8BC: BF8701D1
	v_add_co_ci_u32_e64 v11, null, 0, v5, vcc_lo               // 00000022E8C0: D5207C0B 01AA0A80
	v_cmp_eq_u32_e32 vcc_lo, s9, v3                            // 00000022E8C8: 7C940609
	v_cndmask_b32_e32 v2, v12, v2, vcc_lo                      // 00000022E8CC: 0204050C
	v_cmp_ne_u32_e32 vcc_lo, 0, v6                             // 00000022E8D0: 7C9A0C80
	v_xor_b32_e32 v6, s6, v8                                   // 00000022E8D4: 3A0C1006
	.long 0xd44d0002                                           // 00000022E8D8: D44D0002
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 00000022E8DC: 02020480
	v_dual_cndmask_b32 v3, v11, v10 :: v_dual_cndmask_b32 v2, v9, v7// 00000022E8E0: CA52150B 03020F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022E8E8: BF870111
	v_cndmask_b32_e64 v3, v5, v3, s2                           // 00000022E8EC: D5010003 000A0705
	v_cndmask_b32_e64 v2, v4, v2, s2                           // 00000022E8F4: D5010002 000A0504
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022E8FC: BF870112
	v_xor_b32_e32 v3, v3, v6                                   // 00000022E900: 3A060D03
	v_xor_b32_e32 v2, v2, v6                                   // 00000022E904: 3A040D02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E908: BF870091
	.long 0xd7016a09                                           // 00000022E90C: D7016A09
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000022E910: 02020D02
	v_sub_co_ci_u32_e64 v10, null, v3, v6, vcc_lo              // 00000022E914: D5217C0A 01AA0D03
	s_and_not1_saveexec_b32 s2, s3                             // 00000022E91C: BE823003
	s_cbranch_execz 32                                         // 00000022E920: BFA50020 <_ZN7halogen12_GLOBAL__N_111k_ht_tg_sumEPKfiPKDF16_Ptii+0x3a4>
	v_cvt_f32_u32_e32 v2, s12                                  // 00000022E924: 7E040C0C
	s_sub_i32 s3, 0, s12                                       // 00000022E928: 81830C80
	v_mov_b32_e32 v10, 0                                       // 00000022E92C: 7E140280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000022E930: BF870292
	v_rcp_iflag_f32_e32 v2, v2                                 // 00000022E934: 7E045702
	v_mul_f32_e32 v2, 0x4f7ffffe, v2                           // 00000022E938: 100404FF 4F7FFFFE
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E940: BF870091
	v_cvt_u32_f32_e32 v2, v2                                   // 00000022E944: 7E040F02
	.long 0xd72c0003                                           // 00000022E948: D72C0003
	v_cndmask_b32_e32 v1, s3, v2, vcc_lo                       // 00000022E94C: 02020403
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E950: BF870091
	.long 0xd72d0003                                           // 00000022E954: D72D0003
	v_cndmask_b32_e32 v1, v2, v3, vcc_lo                       // 00000022E958: 02020702
	v_add_nc_u32_e32 v2, v2, v3                                // 00000022E95C: 4A040702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E960: BF870091
	.long 0xd72d0002                                           // 00000022E964: D72D0002
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000022E968: 02020501
	.long 0xd72c0003                                           // 00000022E96C: D72C0003
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 00000022E970: 02001902
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000022E974: 4A080481
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E978: BF870092
	v_sub_nc_u32_e32 v3, v1, v3                                // 00000022E97C: 4C060701
	v_subrev_nc_u32_e32 v5, s12, v3                            // 00000022E980: 4E0A060C
	v_cmp_le_u32_e32 vcc_lo, s12, v3                           // 00000022E984: 7C96060C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E988: BF870092
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_cndmask_b32 v2, v2, v4// 00000022E98C: CA520B03 03020902
	v_cmp_le_u32_e32 vcc_lo, s12, v3                           // 00000022E994: 7C96060C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E998: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000022E99C: 4A080481
	v_cndmask_b32_e32 v9, v2, v4, vcc_lo                       // 00000022E9A0: 02120902
	s_or_b32 exec_lo, exec_lo, s2                              // 00000022E9A4: 8C7E027E
	s_clause 0x1                                               // 00000022E9A8: BF850001
	s_load_b64 s[2:3], s[0:1], null                            // 00000022E9AC: F4040080 F8000000
	s_load_b32 s6, s[0:1], 0x8                                 // 00000022E9B4: F4000180 F8000008
	.long 0xd72c0002                                           // 00000022E9BC: D72C0002
	v_cndmask_b32_e32 v0, v9, v12, vcc_lo                      // 00000022E9C0: 02001909
	.long 0xd72c0003                                           // 00000022E9C4: D72C0003
	v_cndmask_b32_e32 v0, v10, v5, vcc_lo                      // 00000022E9C8: 02000B0A
	.long 0xd72c0004                                           // 00000022E9CC: D72C0004
	v_cndmask_b32_e32 v0, v9, v10, vcc_lo                      // 00000022E9D0: 02001509
	v_mad_u64_u32 v[5:6], null, v9, s5, 0                      // 00000022E9D4: D6FE7C05 02000B09
	v_dual_mov_b32 v8, 0 :: v_dual_and_b32 v13, 31, v0         // 00000022E9DC: CA240080 080C009F
	v_sub_nc_u32_e32 v1, v1, v2                                // 00000022E9E4: 4C020501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000022E9E8: BF870212
	v_lshlrev_b32_e32 v7, 2, v13                               // 00000022E9EC: 300E1A82
	v_add3_u32 v6, v6, v4, v3                                  // 00000022E9F0: D6550006 040E0906
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022E9F8: BF870112
	v_lshl_or_b32 v7, v1, 7, v7                                // 00000022E9FC: D6560007 041D0F01
	.long 0xd73c0001                                           // 00000022EA04: D73C0001
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000022EA08: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000022EA0C: BF870132
	.long 0xd73c000b                                           // 00000022EA10: D73C000B
	v_cndmask_b32_e32 v1, 2, v7, vcc_lo                        // 00000022EA14: 02020E82
	s_waitcnt lgkmcnt(0)                                       // 00000022EA18: BF89FC07
	s_cmp_lt_i32 s6, 2                                         // 00000022EA1C: BF048206
	.long 0xd7006a01                                           // 00000022EA20: D7006A01
	v_cndmask_b32_e32 v1, s2, v1, vcc_lo                       // 00000022EA24: 02020202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022EA28: BF870111
	v_add_co_ci_u32_e64 v2, null, s3, v2, vcc_lo               // 00000022EA2C: D5207C02 01AA0403
	.long 0xd7006a01                                           // 00000022EA34: D7006A01
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 00000022EA38: 02021701
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022EA3C: BF870001
	v_add_co_ci_u32_e64 v2, null, v2, v12, vcc_lo              // 00000022EA40: D5207C02 01AA1902
	global_load_b128 v[1:4], v[1:2], off                       // 00000022EA48: DC5E0000 017C0001
	s_cbranch_scc1 44                                          // 00000022EA50: BFA2002C <_ZN7halogen12_GLOBAL__N_111k_ht_tg_sumEPKfiPKDF16_Ptii+0x504>
	.long 0xd73c0009                                           // 00000022EA54: D73C0009
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 00000022EA58: 02021282
	s_ashr_i32 s5, s4, 31                                      // 00000022EA5C: 86059F04
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000022EA60: BF870009
	s_lshl_b64 s[8:9], s[4:5], 2                               // 00000022EA64: 84888204
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000022EA68: BF870481
	.long 0xd7006a09                                           // 00000022EA6C: D7006A09
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 00000022EA70: 02001109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022EA74: BF870111
	v_add_co_ci_u32_e64 v10, null, s9, v10, vcc_lo             // 00000022EA78: D5207C0A 01AA1409
	.long 0xd72c000e                                           // 00000022EA80: D72C000E
	v_cndmask_b32_e32 v0, v9, v10, vcc_lo                      // 00000022EA84: 02001509
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000022EA88: BF8700A2
	.long 0xd72c000f                                           // 00000022EA8C: D72C000F
	v_cndmask_b32_e32 v0, v10, v11, vcc_lo                     // 00000022EA90: 0200170A
	v_mad_u64_u32 v[9:10], null, v9, s11, v[11:12]             // 00000022EA94: D6FE7C09 042C1709
	v_add3_u32 v10, v15, v10, v14                              // 00000022EA9C: D655000A 043A150F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000022EAA4: BF870002
	.long 0xd7006a09                                           // 00000022EAA8: D7006A09
	v_cndmask_b32_e32 v1, s2, v9, vcc_lo                       // 00000022EAAC: 02021202
	s_mul_i32 s2, s11, s4                                      // 00000022EAB0: 9602040B
	v_add_co_ci_u32_e64 v10, null, s3, v10, vcc_lo             // 00000022EAB4: D5207C0A 01AA1403
	s_mul_hi_i32 s3, s11, s4                                   // 00000022EABC: 9703040B
	s_add_i32 s4, s6, -1                                       // 00000022EAC0: 8104C106
	s_lshl_b64 s[2:3], s[2:3], 2                               // 00000022EAC4: 84828202
	global_load_b128 v[14:17], v[9:10], off                    // 00000022EAC8: DC5E0000 0E7C0009
	.long 0xd7006a09                                           // 00000022EAD0: D7006A09
	v_cndmask_b32_e32 v0, v9, v2, vcc_lo                       // 00000022EAD4: 02000509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000022EAD8: BF8704A1
	v_add_co_ci_u32_e64 v10, null, s3, v10, vcc_lo             // 00000022EADC: D5207C0A 01AA1403
	s_add_i32 s4, s4, -1                                       // 00000022EAE4: 8104C104
	s_cmp_eq_u32 s4, 0                                         // 00000022EAE8: BF068004
	s_waitcnt vmcnt(0)                                         // 00000022EAEC: BF8903F7
	v_dual_add_f32 v4, v4, v17 :: v_dual_add_f32 v3, v3, v16   // 00000022EAF0: C9082304 04022103
	v_dual_add_f32 v2, v2, v15 :: v_dual_add_f32 v1, v1, v14   // 00000022EAF8: C9081F02 02001D01
	s_cbranch_scc0 65521                                       // 00000022EB00: BFA1FFF1 <_ZN7halogen12_GLOBAL__N_111k_ht_tg_sumEPKfiPKDF16_Ptii+0x4c8>
	s_load_b128 s[0:3], s[0:1], 0x10                           // 00000022EB04: F4080000 F8000010
	.long 0xd73c0007                                           // 00000022EB0C: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000022EB10: 02020E81
	s_waitcnt vmcnt(0)                                         // 00000022EB14: BF8903F7
	v_add_f32_e32 v11, v1, v2                                  // 00000022EB18: 06160501
	v_dual_sub_f32 v1, v1, v2 :: v_dual_add_f32 v2, v3, v4     // 00000022EB1C: C9480501 01020903
	v_sub_f32_e32 v3, v3, v4                                   // 00000022EB24: 08060903
	v_and_b32_e32 v4, 1, v0                                    // 00000022EB28: 36080081
	v_and_b32_e32 v12, 2, v0                                   // 00000022EB2C: 36180082
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000022EB30: BF870214
	v_dual_add_f32 v15, v11, v2 :: v_dual_and_b32 v14, 4, v0   // 00000022EB34: C924050B 0F0E0084
	v_add_f32_e32 v16, v1, v3                                  // 00000022EB3C: 06200701
	v_sub_f32_e32 v1, v1, v3                                   // 00000022EB40: 08020701
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022EB44: BF870113
	v_mov_b32_dpp v3, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022EB48: 7E0602FA FF01610F
	v_mov_b32_dpp v17, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022EB50: 7E2202FA FF016101
	s_waitcnt lgkmcnt(0)                                       // 00000022EB58: BF89FC07
	.long 0xd7006a09                                           // 00000022EB5C: D7006A09
	v_cndmask_b32_e32 v1, s0, v7, vcc_lo                       // 00000022EB60: 02020E00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022EB64: BF870001
	v_add_co_ci_u32_e64 v10, null, s1, v8, vcc_lo              // 00000022EB68: D5207C0A 01AA1001
	v_cmp_eq_u32_e32 vcc_lo, 0, v4                             // 00000022EB70: 7C940880
	s_mov_b32 s0, 0x76543210                                   // 00000022EB74: BE8000FF 76543210
	global_load_b64 v[9:10], v[9:10], off                      // 00000022EB7C: DC560000 097C0009
	v_cndmask_b32_e64 v4, -v15, v15, vcc_lo                    // 00000022EB84: D5010004 21AA1F0F
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 00000022EB8C: D5010001 21AA0301
	v_sub_f32_e32 v2, v11, v2                                  // 00000022EB94: 0804050B
	v_and_b32_e32 v0, 8, v0                                    // 00000022EB98: 36000088
	v_mov_b32_dpp v11, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022EB9C: 7E1602FA FF016110
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 00000022EBA4: D501000F 21AA2110
	v_add_f32_e32 v3, v4, v3                                   // 00000022EBAC: 06060704
	v_add_f32_e32 v1, v1, v17                                  // 00000022EBB0: 06022301
	v_mov_b32_dpp v16, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022EBB4: 7E2002FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000022EBBC: D5010002 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 00000022EBC4: 7C941880
	s_delay_alu instid0(VALU_DEP_2)                            // 00000022EBC8: BF870002
	v_add_f32_e32 v2, v2, v16                                  // 00000022EBCC: 06042102
	v_mov_b32_dpp v16, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022EBD0: 7E2002FA FF016201
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 00000022EBD8: D5010001 21AA0301
	v_add_f32_e32 v4, v15, v11                                 // 00000022EBE0: 0608170F
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022EBE4: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000022EBEC: D5010003 21AA0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000022EBF4: BF870214
	v_add_f32_e32 v1, v1, v16                                  // 00000022EBF8: 06022101
	v_mov_b32_dpp v12, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022EBFC: 7E1802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000022EC04: D5010004 21AA0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000022EC0C: BF870244
	v_add_f32_e32 v3, v3, v11                                  // 00000022EC10: 06061703
	v_mov_b32_dpp v15, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022EC14: 7E1E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000022EC1C: D5010002 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v14                            // 00000022EC24: 7C941C80
	v_mov_b32_dpp v11, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022EC28: 7E1602FA FF016403
	s_delay_alu instid0(VALU_DEP_3)                            // 00000022EC30: BF870003
	v_add_f32_e32 v2, v2, v15                                  // 00000022EC34: 06041F02
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000022EC38: D5010003 21AA0703
	v_add_f32_e32 v4, v4, v12                                  // 00000022EC40: 06081904
	v_mov_b32_dpp v15, v1 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022EC44: 7E1E02FA FF016401
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 00000022EC4C: D5010001 21AA0301
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022EC54: 7E1C02FA FF016402
	v_add_f32_e32 v3, v3, v11                                  // 00000022EC5C: 06061703
	v_mov_b32_dpp v12, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022EC60: 7E1802FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000022EC68: D5010004 21AA0904
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000022EC70: D5010002 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 00000022EC78: 7C940080
	v_add_f32_e32 v0, v1, v15                                  // 00000022EC7C: 06001F01
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000022EC80: BF870233
	v_dual_add_f32 v4, v4, v12 :: v_dual_add_f32 v1, v2, v14   // 00000022EC84: C9081904 04001D02
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022EC8C: 7E0402FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000022EC94: D5010003 21AA0703
	v_mov_b32_dpp v14, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022EC9C: 7E1C02FA FF016800
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000022ECA4: BF870254
	v_mov_b32_dpp v11, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022ECA8: 7E1602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000022ECB0: D5010004 21AA0904
	v_mov_b32_dpp v12, v1 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022ECB8: 7E1802FA FF016801
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 00000022ECC0: D5010001 21AA0301
	v_cndmask_b32_e64 v0, -v0, v0, vcc_lo                      // 00000022ECC8: D5010000 21AA0100
	v_dual_add_f32 v2, v3, v2 :: v_dual_add_f32 v3, v4, v11    // 00000022ECD0: C9080503 02021704
	v_cmp_gt_u32_e32 vcc_lo, 16, v13                           // 00000022ECD8: 7C981A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000022ECDC: BF870193
	v_dual_add_f32 v1, v1, v12 :: v_dual_add_f32 v0, v0, v14   // 00000022ECE0: C9081901 01001D00
	v_mov_b32_e32 v4, v2                                       // 00000022ECE8: 7E080302
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000022ECEC: BF870224
	v_cndmask_b32_e64 v11, -v3, v3, vcc_lo                     // 00000022ECF0: D501000B 21AA0703
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 00000022ECF8: D65C0003 03FC0103 FEDCBA98
	v_mov_b32_e32 v13, v0                                      // 00000022ED04: 7E1A0300
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000022ED08: D5010002 21AA0502
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 00000022ED10: D65C0004 03FC0104 FEDCBA98
	v_cndmask_b32_e64 v0, -v0, v0, vcc_lo                      // 00000022ED1C: D5010000 21AA0100
	v_dual_add_f32 v3, v11, v3 :: v_dual_mov_b32 v12, v1       // 00000022ED24: C910070B 030C0101
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 00000022ED2C: D5010001 21AA0301
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 00000022ED34: D65C000D 03FC010D FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000022ED40: BF870213
	v_dual_add_f32 v2, v2, v4 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 00000022ED44: C9060902 020206FF 3DB504F3
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 00000022ED50: D65C000C 03FC010C FEDCBA98
	.long 0x7f083880                                           // 00000022ED5C: 7F083880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022ED60: BF870112
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_add_f32 v1, v1, v12// 00000022ED64: C8C804FF 02001901 3DB504F3
	.long 0x7f163984                                           // 00000022ED70: 7F163984
	.long 0x7f183984                                           // 00000022ED74: 7F183984
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000022ED78: BF8701C3
	v_mul_f32_e32 v1, 0x3db504f3, v1                           // 00000022ED7C: 100202FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000022ED84: BF8903F7
	v_fma_mix_f32 v3, v9, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000022ED88: CC200803 8A020709
	v_fma_mix_f32 v2, v9, v2, neg(0) op_sel_hi:[1,0,0]         // 00000022ED90: CC200002 8A020509
	v_fma_mix_f32 v9, v10, v1, neg(0) op_sel_hi:[1,0,0]        // 00000022ED98: CC200009 8A02030A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000022EDA0: BF870223
	.long 0x7e083983                                           // 00000022EDA4: 7E083983
	v_add_f32_e32 v0, v0, v13                                  // 00000022EDA8: 06001B00
	.long 0x7e163982                                           // 00000022EDAC: 7E163982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000022EDB0: BF870194
	.long 0x7e183989                                           // 00000022EDB4: 7E183989
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 00000022EDB8: 100000FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022EDC0: BF870001
	v_fma_mix_f32 v10, v10, v0, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000022EDC4: CC20080A 8A02010A
	.long 0xd73c0000                                           // 00000022EDCC: D73C0000
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000022EDD0: 02020A81
	v_and_b32_e32 v5, 1, v4                                    // 00000022EDD4: 360A0881
	v_and_b32_e32 v6, 1, v11                                   // 00000022EDD8: 360C1681
	v_and_b32_e32 v11, 1, v12                                  // 00000022EDDC: 36161881
	.long 0x7e08398a                                           // 00000022EDE0: 7E08398A
	.long 0xd7006a00                                           // 00000022EDE4: D7006A00
	v_cndmask_b32_e32 v1, s2, v0, vcc_lo                       // 00000022EDE8: 02020002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000022EDEC: BF870191
	v_add_co_ci_u32_e64 v1, null, s3, v1, vcc_lo               // 00000022EDF0: D5207C01 01AA0203
	v_and_b32_e32 v4, 1, v4                                    // 00000022EDF8: 36080881
	v_add3_u32 v6, v2, v6, 0x7fff                              // 00000022EDFC: D6550006 03FE0D02 00007FFF
	v_add3_u32 v9, v9, v11, 0x7fff                             // 00000022EE08: D6550009 03FE1709 00007FFF
	.long 0xd7006a00                                           // 00000022EE14: D7006A00
	v_cndmask_b32_e32 v1, v0, v7, vcc_lo                       // 00000022EE18: 02020F00
	v_add3_u32 v2, v3, v5, 0x7fff                              // 00000022EE1C: D6550002 03FE0B03 00007FFF
	v_add3_u32 v3, v10, v4, 0x7fff                             // 00000022EE28: D6550003 03FE090A 00007FFF
	v_add_co_ci_u32_e64 v1, null, v1, v8, vcc_lo               // 00000022EE34: D5207C01 01AA1101
	.long 0x7e063989                                           // 00000022EE3C: 7E063989
	.long 0x7e043986                                           // 00000022EE40: 7E043986
	global_store_b64 v[0:1], v[2:3], off                       // 00000022EE44: DC6E0000 007C0200
	s_endpgm                                                   // 00000022EE4C: BFB00000
		...

