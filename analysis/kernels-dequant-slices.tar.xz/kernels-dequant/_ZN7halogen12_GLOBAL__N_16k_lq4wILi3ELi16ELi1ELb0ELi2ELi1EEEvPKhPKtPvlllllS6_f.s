0000000000801b00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000801B00: F4100100 F8000000
	v_and_b32_e32 v23, 15, v0                                  // 000000801B08: 362E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000801B0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000801B10: 86039F02
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000801B14: 30000082
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000801B18: 84808402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000801B1C: BF870009
	v_dual_mov_b32 v17, s1 :: v_dual_lshlrev_b32 v2, 2, v23    // 000000801B20: CA220001 11022E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 000000801B28: 30060282
	v_or_b32_e32 v16, s0, v1                                   // 000000801B2C: 38200200
	.long 0x7f023880                                           // 000000801B30: 7F023880
	s_waitcnt lgkmcnt(0)                                       // 000000801B34: BF89FC07
	s_clause 0x1                                               // 000000801B38: BF850001
	global_load_b32 v2, v2, s[4:5]                             // 000000801B3C: DC520000 02040002
	global_load_b32 v3, v3, s[4:5]                             // 000000801B44: DC520000 03040003
	.long 0xd4540000                                           // 000000801B4C: D4540000
	v_cndmask_b32_e32 v1, s12, v16, vcc_lo                     // 000000801B50: 0202200C
	s_add_u32 s22, s4, s16                                     // 000000801B54: 80161004
	s_addc_u32 s23, s5, s17                                    // 000000801B58: 82171105
	s_ashr_i32 s2, s11, 31                                     // 000000801B5C: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000801B60: BF870159
	s_lshr_b32 s2, s2, 27                                      // 000000801B64: 85029B02
	v_cndmask_b32_e64 v8, 0, v16, s0                           // 000000801B68: D5010008 00022080
	v_cndmask_b32_e64 v9, 0, s1, s0                            // 000000801B70: D5010009 00000280
	s_add_u32 s2, s10, s2                                      // 000000801B78: 8002020A
	s_addc_u32 s3, s11, 0                                      // 000000801B7C: 8203800B
	.long 0xd72c0004                                           // 000000801B80: D72C0004
	v_cndmask_b32_e32 v1, s19, v8, vcc_lo                      // 000000801B84: 02021013
	v_mad_u64_u32 v[12:13], null, s18, v8, 0                   // 000000801B88: D6FE7C0C 02021012
	s_lshr_b64 s[20:21], s[2:3], 5                             // 000000801B90: 85948502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000801B94: BF870009
	s_cmpk_lt_i32 s20, 0x81                                    // 000000801B98: B3940081
	.long 0xd4440002                                           // 000000801B9C: D4440002
	v_cndmask_b32_e32 v1, s20, v23, vcc_lo                     // 000000801BA0: 02022E14
	s_cselect_b32 s1, -1, 0                                    // 000000801BA4: 980180C1
	s_cmpk_gt_i32 s20, 0x80                                    // 000000801BA8: B2940080
	.long 0xd700030e                                           // 000000801BAC: D700030E
	v_cndmask_b32_e32 v1, s22, v12, vcc_lo                     // 000000801BB0: 02021816
	s_waitcnt vmcnt(1)                                         // 000000801BB4: BF8907F7
	v_bfe_u32 v5, v2, 16, 1                                    // 000000801BB8: D6100005 02052102
	s_waitcnt vmcnt(0)                                         // 000000801BC0: BF8903F7
	v_bfe_u32 v6, v3, 16, 1                                    // 000000801BC4: D6100006 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000801BCC: BF8701A2
	v_add3_u32 v2, v2, v5, 0x7fff                              // 000000801BD0: D6550002 03FE0B02 00007FFF
	.long 0xd72c0005                                           // 000000801BDC: D72C0005
	v_cndmask_b32_e32 v1, s18, v9, vcc_lo                      // 000000801BE0: 02021212
	v_add3_u32 v3, v3, v6, 0x7fff                              // 000000801BE4: D6550003 03FE0D03 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 000000801BF0: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000801BF4: BF8701A9
	s_and_b32 vcc_lo, exec_lo, s18                             // 000000801BF8: 8B6A127E
	.long 0x7e023982                                           // 000000801BFC: 7E023982
	v_add3_u32 v13, v13, v5, v4                                // 000000801C00: D655000D 04120B0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000801C08: BF870112
	v_and_or_b32 v1, 0xffff0000, v3, v1                        // 000000801C0C: D6570001 040606FF FFFF0000
	v_add_co_ci_u32_e64 v15, null, s23, v13, s3                // 000000801C18: D5207C0F 000E1A17
	ds_store_b32 v0, v1                                        // 000000801C20: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000801C28: BF89FC07
	s_barrier                                                  // 000000801C2C: BFBD0000
	buffer_gl0_inv                                             // 000000801C30: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 000000801C38: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x37c>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 000000801C3C: CA100080 01000080
	s_and_saveexec_b32 s3, s2                                  // 000000801C44: BE832002
	s_cbranch_execz 10                                         // 000000801C48: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x174>
	v_lshlrev_b32_e32 v0, 1, v23                               // 000000801C4C: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000801C50: BF870091
	.long 0xd7006a02                                           // 000000801C54: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 000000801C58: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 000000801C5C: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 000000801C64: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 000000801C6C: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 000000801C70: 7E001700
	s_or_b32 exec_lo, exec_lo, s3                              // 000000801C74: 8C7E037E
	v_or_b32_e32 v2, 16, v23                                   // 000000801C78: 38042E90
	s_mov_b32 s2, exec_lo                                      // 000000801C7C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000801C80: BF870001
	.long 0xd4c4007e                                           // 000000801C84: D4C4007E
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000801C88: 02020414
	s_cbranch_execz 10                                         // 000000801C8C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1b8>
	v_lshlrev_b32_e32 v1, 1, v2                                // 000000801C90: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000801C94: BF870091
	.long 0xd7006a01                                           // 000000801C98: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 000000801C9C: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 000000801CA0: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 000000801CA8: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000801CB0: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000801CB4: 7E021701
	s_or_b32 exec_lo, exec_lo, s2                              // 000000801CB8: 8C7E027E
	v_or_b32_e32 v4, 32, v23                                   // 000000801CBC: 38082EA0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 000000801CC0: CA100080 03020080
	s_mov_b32 s2, exec_lo                                      // 000000801CC8: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000801CCC: BF870002
	.long 0xd4c4007e                                           // 000000801CD0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 000000801CD4: 02020814
	s_cbranch_execz 10                                         // 000000801CD8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x204>
	v_lshlrev_b32_e32 v2, 1, v4                                // 000000801CDC: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000801CE0: BF870091
	.long 0xd7006a04                                           // 000000801CE4: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 000000801CE8: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 000000801CEC: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 000000801CF4: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 000000801CFC: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 000000801D00: 7E041702
	s_or_b32 exec_lo, exec_lo, s2                              // 000000801D04: 8C7E027E
	v_or_b32_e32 v4, 48, v23                                   // 000000801D08: 38082EB0
	s_mov_b32 s2, exec_lo                                      // 000000801D0C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000801D10: BF870001
	.long 0xd4c4007e                                           // 000000801D14: D4C4007E
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 000000801D18: 02020814
	s_cbranch_execz 10                                         // 000000801D1C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x248>
	v_lshlrev_b32_e32 v3, 1, v4                                // 000000801D20: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000801D24: BF870091
	.long 0xd7006a03                                           // 000000801D28: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 000000801D2C: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 000000801D30: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 000000801D38: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000801D40: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000801D44: 7E061703
	s_or_b32 exec_lo, exec_lo, s2                              // 000000801D48: 8C7E027E
	v_or_b32_e32 v6, 64, v23                                   // 000000801D4C: 380C2EC0
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 000000801D50: CA100080 05040080
	s_mov_b32 s2, exec_lo                                      // 000000801D58: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000801D5C: BF870002
	.long 0xd4c4007e                                           // 000000801D60: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000801D64: 02020C14
	s_cbranch_execz 10                                         // 000000801D68: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x294>
	v_lshlrev_b32_e32 v4, 1, v6                                // 000000801D6C: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000801D70: BF870091
	.long 0xd7006a06                                           // 000000801D74: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 000000801D78: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 000000801D7C: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 000000801D84: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 000000801D8C: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000801D90: 7E081704
	s_or_b32 exec_lo, exec_lo, s2                              // 000000801D94: 8C7E027E
	v_or_b32_e32 v6, 0x50, v23                                 // 000000801D98: 380C2EFF 00000050
	s_mov_b32 s2, exec_lo                                      // 000000801DA0: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000801DA4: BF870001
	.long 0xd4c4007e                                           // 000000801DA8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000801DAC: 02020C14
	s_cbranch_execz 10                                         // 000000801DB0: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2dc>
	v_lshlrev_b32_e32 v5, 1, v6                                // 000000801DB4: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000801DB8: BF870091
	.long 0xd7006a05                                           // 000000801DBC: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 000000801DC0: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 000000801DC4: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 000000801DCC: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 000000801DD4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 000000801DD8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s2                              // 000000801DDC: 8C7E027E
	v_or_b32_e32 v10, 0x60, v23                                // 000000801DE0: 38142EFF 00000060
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 000000801DE8: CA100080 07060080
	s_mov_b32 s2, exec_lo                                      // 000000801DF0: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000801DF4: BF870002
	.long 0xd4c4007e                                           // 000000801DF8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v10, vcc_lo                     // 000000801DFC: 02021414
	s_cbranch_execz 10                                         // 000000801E00: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x32c>
	v_lshlrev_b32_e32 v6, 1, v10                               // 000000801E04: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000801E08: BF870091
	.long 0xd7006a0a                                           // 000000801E0C: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 000000801E10: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 000000801E14: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 000000801E1C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 000000801E24: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000801E28: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000801E2C: 8C7E027E
	v_or_b32_e32 v10, 0x70, v23                                // 000000801E30: 38142EFF 00000070
	s_mov_b32 s2, exec_lo                                      // 000000801E38: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000801E3C: BF870001
	.long 0xd4c4007e                                           // 000000801E40: D4C4007E
	v_cndmask_b32_e32 v1, s20, v10, vcc_lo                     // 000000801E44: 02021414
	s_cbranch_execz 10                                         // 000000801E48: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x374>
	v_lshlrev_b32_e32 v7, 1, v10                               // 000000801E4C: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000801E50: BF870091
	.long 0xd7006a0a                                           // 000000801E54: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 000000801E58: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 000000801E5C: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 000000801E64: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 000000801E6C: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000801E70: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s2                              // 000000801E74: 8C7E027E
	s_branch 9                                                 // 000000801E78: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3a0>
	v_mov_b32_e32 v0, 0                                        // 000000801E7C: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000801E80: BF870001
	v_mov_b32_e32 v1, v0                                       // 000000801E84: 7E020300
	v_mov_b32_e32 v2, v0                                       // 000000801E88: 7E040300
	v_mov_b32_e32 v3, v0                                       // 000000801E8C: 7E060300
	v_mov_b32_e32 v4, v0                                       // 000000801E90: 7E080300
	v_mov_b32_e32 v5, v0                                       // 000000801E94: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 000000801E98: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 000000801E9C: 7E0E0300
	s_add_u32 s2, s4, s14                                      // 000000801EA0: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000801EA4: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 000000801EA8: 850E9F0B
	v_mov_b32_e32 v26, 0                                       // 000000801EAC: 7E340280
	s_add_u32 s14, s10, s14                                    // 000000801EB0: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000801EB4: 820F800B
	v_cndmask_b32_e64 v24, 0, 1, s18                           // 000000801EB8: D5010018 00490280
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000801EC0: 868E810E
	v_mov_b32_e32 v32, 0                                       // 000000801EC4: 7E400280
	v_mad_u64_u32 v[18:19], null, v8, s14, s[2:3]              // 000000801EC8: D6FE7C12 00081D08
	.long 0xd72c000b                                           // 000000801ED0: D72C000B
	v_cndmask_b32_e32 v0, v8, v15, vcc_lo                      // 000000801ED4: 02001F08
	.long 0xd72c0014                                           // 000000801ED8: D72C0014
	v_cndmask_b32_e32 v0, v9, v14, vcc_lo                      // 000000801EDC: 02001D09
	.long 0xd4440002                                           // 000000801EE0: D4440002
	v_cndmask_b32_e32 v1, s20, v23, vcc_lo                     // 000000801EE4: 02022E14
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 000000801EE8: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 000000801EF0: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000801EF4: BF870004
	v_add3_u32 v25, v20, v19, v11                              // 000000801EF8: D6550019 042E2714
	v_mov_b32_e32 v11, 0                                       // 000000801F00: 7E160280
	s_and_saveexec_b32 s3, s2                                  // 000000801F04: BE832002
	s_cbranch_execz 21                                         // 000000801F08: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x460>
	v_lshlrev_b32_e32 v8, 4, v23                               // 000000801F0C: 30102E84
	v_mov_b32_e32 v32, 0                                       // 000000801F10: 7E400280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000801F14: BF870092
	.long 0xd7006a08                                           // 000000801F18: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 000000801F1C: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 000000801F20: D5207C09 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 000000801F28: 916A127E
	global_load_b128 v[8:11], v[8:9], off                      // 000000801F2C: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 000000801F34: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x460>
	v_lshlrev_b32_e32 v19, 1, v23                              // 000000801F38: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000801F3C: BF870091
	.long 0xd7006a0e                                           // 000000801F40: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 000000801F44: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 000000801F48: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 000000801F50: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 000000801F58: BF8903F7
	v_cvt_f32_f16_e32 v32, v14                                 // 000000801F5C: 7E40170E
	s_or_b32 exec_lo, exec_lo, s3                              // 000000801F60: 8C7E037E
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 000000801F64: CA100080 1B1C0080
	s_and_saveexec_b32 s3, s2                                  // 000000801F6C: BE832002
	s_cbranch_execz 352                                        // 000000801F70: BFA50160 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x9f4>
	.long 0xd7006a0c                                           // 000000801F74: D7006A0C
	v_cndmask_b32_e32 v1, s16, v12, vcc_lo                     // 000000801F78: 02021810
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 000000801F7C: CA220080 14122E85
	v_lshlrev_b32_e32 v14, 1, v23                              // 000000801F84: 301C2E81
	v_add_co_ci_u32_e64 v13, null, s17, v13, vcc_lo            // 000000801F88: D5207C0D 01AA1A11
	v_lshl_or_b32 v29, v23, 4, 0x100                           // 000000801F90: D656001D 03FD0917 00000100
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000801F9C: BF870214
	v_mov_b32_e32 v27, v20                                     // 000000801FA0: 7E360314
	.long 0xd7006a0c                                           // 000000801FA4: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 000000801FA8: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000801FAC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 000000801FB0: D5207C0D 01AA1A80
	v_dual_mov_b32 v30, v23 :: v_dual_mov_b32 v31, v32         // 000000801FB8: CA100117 1E1E0120
	.long 0xd7006a0c                                           // 000000801FC0: D7006A0C
	v_cndmask_b32_e32 v1, s4, v12, vcc_lo                      // 000000801FC4: 02021804
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000801FC8: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s5, v13, vcc_lo             // 000000801FCC: D5207C0D 01AA1A05
	v_mov_b32_e32 v28, v20                                     // 000000801FD4: 7E380314
	.long 0xd7006a15                                           // 000000801FD8: D7006A15
	v_cndmask_b32_e32 v0, v12, v160, vcc_lo                    // 000000801FDC: 0201410C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000801FE0: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 000000801FE4: D5207C16 01AA1A80
	v_mov_b32_e32 v26, v20                                     // 000000801FEC: 7E340314
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000801FF0: 8484820A
	s_mov_b32 s14, 0                                           // 000000801FF4: BE8E0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000801FF8: 848A810A
	s_branch 288                                               // 000000801FFC: BFA00120 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x980>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000802000: 8C7E0F7E
	.long 0xd73c0021                                           // 000000802004: D73C0021
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000802008: 02022681
	v_and_b32_e32 v81, 0xff, v8                                // 00000080200C: 36A210FF 000000FF
	v_cndmask_b32_e64 v82, v32, v0, s1                         // 000000802014: D5010052 00060120
	v_lshrrev_b32_e32 v32, 6, v8                               // 00000080201C: 32401086
	v_lshrrev_b32_e32 v83, 14, v8                              // 000000802020: 32A6108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 000000802024: 32101096
	.long 0xd7006a45                                           // 000000802028: D7006A45
	v_cndmask_b32_e32 v1, s6, v33, vcc_lo                      // 00000080202C: 02024206
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000802030: BF8701A1
	v_add_co_ci_u32_e64 v70, null, s7, v34, vcc_lo             // 000000802034: D5207C46 01AA4407
	v_lshlrev_b32_e32 v81, 2, v81                              // 00000080203C: 30A2A282
	.long 0xd7006a49                                           // 000000802040: D7006A49
	v_cndmask_b32_e32 v0, v69, v10, vcc_lo                     // 000000802044: 02001545
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000802048: BF8700A1
	v_add_co_ci_u32_e64 v74, null, s11, v70, vcc_lo            // 00000080204C: D5207C4A 01AA8C0B
	.long 0xd7006a4d                                           // 000000802054: D7006A4D
	v_cndmask_b32_e32 v0, v69, v4, vcc_lo                      // 000000802058: 02000945
	v_add_co_ci_u32_e64 v78, null, s5, v70, vcc_lo             // 00000080205C: D5207C4E 01AA8C05
	s_clause 0xb                                               // 000000802064: BF85000B
	global_load_b128 v[33:36], v[69:70], off                   // 000000802068: DC5E0000 217C0045
	global_load_b128 v[37:40], v[73:74], off                   // 000000802070: DC5E0000 257C0049
	global_load_b128 v[41:44], v[77:78], off                   // 000000802078: DC5E0000 297C004D
	global_load_b128 v[45:48], v[69:70], off offset:16         // 000000802080: DC5E0010 2D7C0045
	global_load_b128 v[49:52], v[73:74], off offset:16         // 000000802088: DC5E0010 317C0049
	global_load_b128 v[53:56], v[77:78], off offset:16         // 000000802090: DC5E0010 357C004D
	global_load_b128 v[57:60], v[69:70], off offset:32         // 000000802098: DC5E0020 397C0045
	global_load_b128 v[61:64], v[73:74], off offset:32         // 0000008020A0: DC5E0020 3D7C0049
	global_load_b128 v[65:68], v[77:78], off offset:32         // 0000008020A8: DC5E0020 417C004D
	global_load_b128 v[69:72], v[69:70], off offset:48         // 0000008020B0: DC5E0030 457C0045
	global_load_b128 v[73:76], v[73:74], off offset:48         // 0000008020B8: DC5E0030 497C0049
	global_load_b128 v[77:80], v[77:78], off offset:48         // 0000008020C0: DC5E0030 4D7C004D
	v_and_b32_e32 v32, 0x3fc, v32                              // 0000008020C8: 364040FF 000003FC
	ds_load_b32 v81, v81                                       // 0000008020D0: D8D80000 51000051
	v_and_b32_e32 v83, 0x3fc, v83                              // 0000008020D8: 36A6A6FF 000003FC
	v_and_b32_e32 v84, 0xff, v9                                // 0000008020E0: 36A812FF 000000FF
	v_lshrrev_b32_e32 v85, 6, v9                               // 0000008020E8: 32AA1286
	v_lshrrev_b32_e32 v86, 14, v9                              // 0000008020EC: 32AC128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000008020F0: 32121296
	ds_load_b32 v83, v83                                       // 0000008020F4: D8D80000 53000053
	ds_load_b32 v32, v32                                       // 0000008020FC: D8D80000 20000020
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000802104: 361010FF 000003FC
	v_lshlrev_b32_e32 v84, 2, v84                              // 00000080210C: 30A8A882
	v_and_b32_e32 v85, 0x3fc, v85                              // 000000802110: 36AAAAFF 000003FC
	v_and_b32_e32 v86, 0x3fc, v86                              // 000000802118: 36ACACFF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000802120: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 000000802128: D8D80000 08000008
	ds_load_b32 v84, v84                                       // 000000802130: D8D80000 54000054
	ds_load_b32 v85, v85                                       // 000000802138: D8D80000 55000055
	ds_load_b32 v86, v86                                       // 000000802140: D8D80000 56000056
	ds_load_b32 v9, v9                                         // 000000802148: D8D80000 09000009
	v_and_b32_e32 v87, 0xff, v10                               // 000000802150: 36AE14FF 000000FF
	v_lshrrev_b32_e32 v88, 6, v10                              // 000000802158: 32B01486
	v_lshrrev_b32_e32 v89, 14, v10                             // 00000080215C: 32B2148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 000000802160: 32141496
	v_and_b32_e32 v90, 0xff, v11                               // 000000802164: 36B416FF 000000FF
	v_lshrrev_b32_e32 v91, 14, v11                             // 00000080216C: 32B6168E
	.long 0xd7006a15                                           // 000000802170: D7006A15
	v_cndmask_b32_e32 v0, v21, v160, vcc_lo                    // 000000802174: 02014115
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000802178: BF8704A1
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 00000080217C: D5207C16 01AA2C80
	s_and_b32 s2, exec_lo, s2                                  // 000000802184: 8B02027E
	s_or_b32 s14, s2, s14                                      // 000000802188: 8C0E0E02
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 00000080218C: BF892C77
	v_dot2_f32_bf16 v33, v33, v81, 0                           // 000000802190: CC1A4021 1A02A321
	s_waitcnt vmcnt(10)                                        // 000000802198: BF892BF7
	v_dot2_f32_bf16 v37, v37, v81, 0                           // 00000080219C: CC1A4025 1A02A325
	s_waitcnt vmcnt(9)                                         // 0000008021A4: BF8927F7
	v_dot2_f32_bf16 v41, v41, v81, 0                           // 0000008021A8: CC1A4029 1A02A329
	v_lshrrev_b32_e32 v81, 6, v11                              // 0000008021B0: 32A21686
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000008021B4: 32161696
	s_waitcnt lgkmcnt(5)                                       // 0000008021B8: BF89FC57
	v_dot2_f32_bf16 v33, v34, v32, v33                         // 0000008021BC: CC1A4021 1C864122
	v_dot2_f32_bf16 v34, v38, v32, v37                         // 0000008021C4: CC1A4022 1C964126
	v_dot2_f32_bf16 v32, v42, v32, v41                         // 0000008021CC: CC1A4020 1CA6412A
	v_lshlrev_b32_e32 v37, 2, v87                              // 0000008021D4: 304AAE82
	v_and_b32_e32 v38, 0x3fc, v89                              // 0000008021D8: 364CB2FF 000003FC
	v_dot2_f32_bf16 v33, v35, v83, v33                         // 0000008021E0: CC1A4021 1C86A723
	v_dot2_f32_bf16 v34, v39, v83, v34                         // 0000008021E8: CC1A4022 1C8AA727
	v_dot2_f32_bf16 v32, v43, v83, v32                         // 0000008021F0: CC1A4020 1C82A72B
	v_and_b32_e32 v35, 0x3fc, v88                              // 0000008021F8: 3646B0FF 000003FC
	v_and_b32_e32 v39, 0x3fc, v91                              // 000000802200: 364EB6FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 000000802208: BF89FC47
	v_dot2_f32_bf16 v33, v36, v8, v33                          // 00000080220C: CC1A4021 1C861124
	v_dot2_f32_bf16 v34, v40, v8, v34                          // 000000802214: CC1A4022 1C8A1128
	v_dot2_f32_bf16 v8, v44, v8, v32                           // 00000080221C: CC1A4008 1C82112C
	ds_load_b32 v36, v37                                       // 000000802224: D8D80000 24000025
	ds_load_b32 v40, v38                                       // 00000080222C: D8D80000 28000026
	ds_load_b32 v35, v35                                       // 000000802234: D8D80000 23000023
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 00000080223C: BF892067
	v_dot2_f32_bf16 v33, v45, v84, v33                         // 000000802240: CC1A4021 1C86A92D
	s_waitcnt vmcnt(7)                                         // 000000802248: BF891FF7
	v_dot2_f32_bf16 v34, v49, v84, v34                         // 00000080224C: CC1A4022 1C8AA931
	s_waitcnt vmcnt(6)                                         // 000000802254: BF891BF7
	v_dot2_f32_bf16 v8, v53, v84, v8                           // 000000802258: CC1A4008 1C22A935
	v_cndmask_b32_e64 v38, v5, v6, s1                          // 000000802260: D5010026 00060D05
	v_and_b32_e32 v10, 0x3fc, v10                              // 000000802268: 361414FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 000000802270: BF89FC57
	v_dot2_f32_bf16 v33, v46, v85, v33                         // 000000802274: CC1A4021 1C86AB2E
	v_dot2_f32_bf16 v34, v50, v85, v34                         // 00000080227C: CC1A4022 1C8AAB32
	v_dot2_f32_bf16 v8, v54, v85, v8                           // 000000802284: CC1A4008 1C22AB36
	v_lshlrev_b32_e32 v32, 2, v90                              // 00000080228C: 3040B482
	v_and_b32_e32 v37, 0x3fc, v81                              // 000000802290: 364AA2FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 000000802298: BF89FC47
	v_dot2_f32_bf16 v33, v47, v86, v33                         // 00000080229C: CC1A4021 1C86AD2F
	v_dot2_f32_bf16 v34, v51, v86, v34                         // 0000008022A4: CC1A4022 1C8AAD33
	v_dot2_f32_bf16 v8, v55, v86, v8                           // 0000008022AC: CC1A4008 1C22AD37
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008022B4: 361616FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000008022BC: BF89FC37
	v_dot2_f32_bf16 v33, v48, v9, v33                          // 0000008022C0: CC1A4021 1C861330
	v_dot2_f32_bf16 v34, v52, v9, v34                          // 0000008022C8: CC1A4022 1C8A1334
	v_dot2_f32_bf16 v8, v56, v9, v8                            // 0000008022D0: CC1A4008 1C221338
	ds_load_b32 v9, v10                                        // 0000008022D8: D8D80000 0900000A
	ds_load_b32 v10, v32                                       // 0000008022E0: D8D80000 0A000020
	ds_load_b32 v32, v37                                       // 0000008022E8: D8D80000 20000025
	ds_load_b32 v41, v39                                       // 0000008022F0: D8D80000 29000027
	ds_load_b32 v42, v11                                       // 0000008022F8: D8D80000 2A00000B
	v_cndmask_b32_e64 v39, v6, v7, s1                          // 000000802300: D5010027 00060F06
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 000000802308: BF891477
	v_dot2_f32_bf16 v11, v57, v36, v33                         // 00000080230C: CC1A400B 1C864939
	s_waitcnt vmcnt(4)                                         // 000000802314: BF8913F7
	v_dot2_f32_bf16 v33, v61, v36, v34                         // 000000802318: CC1A4021 1C8A493D
	s_waitcnt vmcnt(3)                                         // 000000802320: BF890FF7
	v_dot2_f32_bf16 v8, v65, v36, v8                           // 000000802324: CC1A4008 1C224941
	v_cndmask_b32_e64 v37, v4, v5, s1                          // 00000080232C: D5010025 00060B04
	v_cndmask_b32_e64 v36, v3, v4, s1                          // 000000802334: D5010024 00060903
	s_waitcnt lgkmcnt(5)                                       // 00000080233C: BF89FC57
	v_dot2_f32_bf16 v6, v58, v35, v11                          // 000000802340: CC1A4006 1C2E473A
	v_dot2_f32_bf16 v11, v62, v35, v33                         // 000000802348: CC1A400B 1C86473E
	v_dot2_f32_bf16 v8, v66, v35, v8                           // 000000802350: CC1A4008 1C224742
	v_cndmask_b32_e64 v35, v2, v3, s1                          // 000000802358: D5010023 00060702
	v_cndmask_b32_e64 v34, v1, v2, s1                          // 000000802360: D5010022 00060501
	v_dot2_f32_bf16 v4, v59, v40, v6                           // 000000802368: CC1A4004 1C1A513B
	v_dot2_f32_bf16 v5, v63, v40, v11                          // 000000802370: CC1A4005 1C2E513F
	v_dot2_f32_bf16 v6, v67, v40, v8                           // 000000802378: CC1A4006 1C225143
	v_cndmask_b32_e64 v33, v0, v1, s1                          // 000000802380: D5010021 00060300
	v_mov_b32_e32 v40, v7                                      // 000000802388: 7E500307
	s_waitcnt lgkmcnt(4)                                       // 00000080238C: BF89FC47
	v_dot2_f32_bf16 v2, v60, v9, v4                            // 000000802390: CC1A4002 1C12133C
	v_dot2_f32_bf16 v3, v64, v9, v5                            // 000000802398: CC1A4003 1C161340
	v_dot2_f32_bf16 v4, v68, v9, v6                            // 0000008023A0: CC1A4004 1C1A1344
	v_add_nc_u32_e32 v19, 0x200, v19                           // 0000008023A8: 4A2626FF 00000200
	v_add_nc_u32_e32 v29, 0x100, v29                           // 0000008023B0: 4A3A3AFF 00000100
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000008023B8: BF890837
	v_dot2_f32_bf16 v0, v69, v10, v2                           // 0000008023BC: CC1A4000 1C0A1545
	s_waitcnt vmcnt(1)                                         // 0000008023C4: BF8907F7
	v_dot2_f32_bf16 v1, v73, v10, v3                           // 0000008023C8: CC1A4001 1C0E1549
	s_waitcnt vmcnt(0)                                         // 0000008023D0: BF8903F7
	v_dot2_f32_bf16 v2, v77, v10, v4                           // 0000008023D4: CC1A4002 1C12154D
	v_dual_mov_b32 v11, v15 :: v_dual_mov_b32 v10, v14         // 0000008023DC: CA10010F 0B0A010E
	s_waitcnt lgkmcnt(2)                                       // 0000008023E4: BF89FC27
	v_dot2_f32_bf16 v0, v70, v32, v0                           // 0000008023E8: CC1A4000 1C024146
	v_dot2_f32_bf16 v1, v74, v32, v1                           // 0000008023F0: CC1A4001 1C06414A
	v_dot2_f32_bf16 v2, v78, v32, v2                           // 0000008023F8: CC1A4002 1C0A414E
	v_dual_mov_b32 v9, v13 :: v_dual_mov_b32 v8, v12           // 000000802400: CA10010D 0908010C
	s_waitcnt lgkmcnt(1)                                       // 000000802408: BF89FC17
	v_dot2_f32_bf16 v0, v71, v41, v0                           // 00000080240C: CC1A4000 1C025347
	v_dot2_f32_bf16 v1, v75, v41, v1                           // 000000802414: CC1A4001 1C06534B
	v_dot2_f32_bf16 v2, v79, v41, v2                           // 00000080241C: CC1A4002 1C0A534F
	v_mov_b32_e32 v32, v31                                     // 000000802424: 7E40031F
	s_waitcnt lgkmcnt(0)                                       // 000000802428: BF89FC07
	v_dot2_f32_bf16 v0, v72, v42, v0                           // 00000080242C: CC1A4000 1C025548
	v_dot2_f32_bf16 v1, v76, v42, v1                           // 000000802434: CC1A4001 1C06554C
	v_dot2_f32_bf16 v2, v80, v42, v2                           // 00000080243C: CC1A4002 1C0A5550
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000802444: BF870193
	v_fmac_f32_e32 v28, v82, v0                                // 000000802448: 56380152
	v_fmac_f32_e32 v27, v82, v1                                // 00000080244C: 56360352
	s_delay_alu instid0(VALU_DEP_3)                            // 000000802450: BF870003
	v_fmac_f32_e32 v26, v82, v2                                // 000000802454: 56340552
	v_dual_mov_b32 v0, v33 :: v_dual_mov_b32 v1, v34           // 000000802458: CA100121 00000122
	v_dual_mov_b32 v2, v35 :: v_dual_mov_b32 v3, v36           // 000000802460: CA100123 02020124
	v_dual_mov_b32 v4, v37 :: v_dual_mov_b32 v5, v38           // 000000802468: CA100125 04040126
	v_dual_mov_b32 v6, v39 :: v_dual_mov_b32 v7, v40           // 000000802470: CA100127 06060128
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 000000802478: 917E0E7E
	s_cbranch_execz 28                                         // 00000080247C: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x9f0>
	s_waitcnt vmcnt(0)                                         // 000000802480: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v30, 16, v30   // 000000802484: CA200109 0D1E3C90
	v_dual_mov_b32 v12, v8 :: v_dual_mov_b32 v15, v11          // 00000080248C: CA100108 0C0E010B
	v_mov_b32_e32 v14, v10                                     // 000000802494: 7E1C030A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000802498: BF870003
	.long 0xd4430002                                           // 00000080249C: D4430002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 0000008024A0: 02023C14
	s_mov_b32 s15, exec_lo                                     // 0000008024A4: BE8F007E
	.long 0xd4c4007e                                           // 0000008024A8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 0000008024AC: 02023C14
	s_cbranch_execz 65235                                      // 0000008024B0: BFA5FED3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	.long 0xd7006a0c                                           // 0000008024B4: D7006A0C
	v_cndmask_b32_e32 v1, v18, v29, vcc_lo                     // 0000008024B8: 02023B12
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008024BC: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 0000008024C0: D5207C0D 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 0000008024C8: 7C9A3081
	v_mov_b32_e32 v31, v32                                     // 0000008024CC: 7E3E0320
	global_load_b128 v[12:15], v[12:13], off                   // 0000008024D0: DC5E0000 0C7C000C
	s_cbranch_vccnz 65225                                      // 0000008024D8: BFA4FEC9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	global_load_d16_b16 v31, v[21:22], off                     // 0000008024DC: DC820000 1F7C0015
	s_waitcnt vmcnt(0)                                         // 0000008024E4: BF8903F7
	v_cvt_f32_f16_e32 v31, v31                                 // 0000008024E8: 7E3E171F
	s_branch 65220                                             // 0000008024EC: BFA0FEC4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000008024F0: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008024F4: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008024F8: 8C7E037E
	.long 0xd71f0000                                           // 0000008024FC: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000802500: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000802504: 3A020088
	v_xor_b32_e32 v4, 4, v0                                    // 000000802508: 3A080084
	v_xor_b32_e32 v7, 2, v0                                    // 00000080250C: 3A0E0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000802510: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000802514: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000802518: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000080251C: 7C9808A0
	v_cndmask_b32_e32 v4, v0, v4, vcc_lo                       // 000000802520: 02080900
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 000000802524: 7C980EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000802528: BF870002
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000080252C: 30080882
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000802530: 30020282
	ds_bpermute_b32 v2, v1, v28                                // 000000802534: DACC0000 02001C01
	s_waitcnt lgkmcnt(0)                                       // 00000080253C: BF89FC07
	v_add_f32_e32 v2, v28, v2                                  // 000000802540: 0604051C
	ds_bpermute_b32 v3, v1, v27                                // 000000802544: DACC0000 03001B01
	ds_bpermute_b32 v1, v1, v26                                // 00000080254C: DACC0000 01001A01
	ds_bpermute_b32 v5, v4, v2                                 // 000000802554: DACC0000 05000204
	v_cndmask_b32_e32 v7, v0, v7, vcc_lo                       // 00000080255C: 020E0F00
	s_waitcnt lgkmcnt(2)                                       // 000000802560: BF89FC27
	v_add_f32_e32 v3, v27, v3                                  // 000000802564: 0606071B
	s_waitcnt lgkmcnt(1)                                       // 000000802568: BF89FC17
	v_add_f32_e32 v1, v26, v1                                  // 00000080256C: 0602031A
	s_waitcnt lgkmcnt(0)                                       // 000000802570: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 000000802574: 06040B02
	ds_bpermute_b32 v6, v4, v3                                 // 000000802578: DACC0000 06000304
	ds_bpermute_b32 v4, v4, v1                                 // 000000802580: DACC0000 04000104
	s_waitcnt lgkmcnt(0)                                       // 000000802588: BF89FC07
	v_dual_add_f32 v4, v1, v4 :: v_dual_lshlrev_b32 v7, 2, v7  // 00000080258C: C9220901 04060E82
	ds_bpermute_b32 v1, v7, v2                                 // 000000802594: DACC0000 01000207
	v_add_f32_e32 v3, v3, v6                                   // 00000080259C: 06060D03
	ds_bpermute_b32 v6, v7, v4                                 // 0000008025A0: DACC0000 06000407
	ds_bpermute_b32 v5, v7, v3                                 // 0000008025A8: DACC0000 05000307
	v_xor_b32_e32 v7, 1, v0                                    // 0000008025B0: 3A0E0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008025B4: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000008025B8: 7C980EA0
	v_cndmask_b32_e32 v0, v0, v7, vcc_lo                       // 0000008025BC: 02000F00
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 0000008025C0: 7C942E80
	s_waitcnt lgkmcnt(2)                                       // 0000008025C4: BF89FC27
	v_dual_add_f32 v0, v2, v1 :: v_dual_lshlrev_b32 v7, 2, v0  // 0000008025C8: C9220302 00060082
	s_waitcnt lgkmcnt(1)                                       // 0000008025D0: BF89FC17
	v_add_f32_e32 v2, v4, v6                                   // 0000008025D4: 06040D04
	s_and_b32 s0, vcc_lo, s0                                   // 0000008025D8: 8B00006A
	s_waitcnt lgkmcnt(0)                                       // 0000008025DC: BF89FC07
	v_add_f32_e32 v1, v3, v5                                   // 0000008025E0: 06020B03
	ds_bpermute_b32 v3, v7, v0                                 // 0000008025E4: DACC0000 03000007
	ds_bpermute_b32 v5, v7, v2                                 // 0000008025EC: DACC0000 05000207
	ds_bpermute_b32 v4, v7, v1                                 // 0000008025F4: DACC0000 04000107
	s_and_saveexec_b32 s1, s0                                  // 0000008025FC: BE812000
	s_cbranch_execz 158                                        // 000000802600: BFA5009E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xd7c>
	s_waitcnt lgkmcnt(0)                                       // 000000802604: BF89FC07
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v1, v1, v4     // 000000802608: C9080700 00000901
	.long 0x7f283880                                           // 000000802610: 7F283880
	s_lshl_b64 s[2:3], s[12:13], 1                             // 000000802614: 8482810C
	s_lshl_b64 s[4:5], s[12:13], 2                             // 000000802618: 8484820C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000080261C: BF870122
	v_bfe_u32 v3, v0, 16, 1                                    // 000000802620: D6100003 02052100
	v_bfe_u32 v4, v1, 16, 1                                    // 000000802628: D6100004 02052101
	v_add3_u32 v0, v0, v3, 0x7fff                              // 000000802630: D6550000 03FE0700 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080263C: BF870092
	v_add3_u32 v1, v1, v4, 0x7fff                              // 000000802640: D6550001 03FE0901 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 00000080264C: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000802654: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000802658: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 000000802660: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000802664: BF870095
	v_add_f32_e32 v4, 1.0, v1                                  // 000000802668: 060802F2
	v_div_scale_f32 v6, null, v4, v4, 1.0                      // 00000080266C: D6FC7C06 03CA0904
	v_div_scale_f32 v13, s0, 1.0, v4, 1.0                      // 000000802674: D6FC000D 03CA08F2
	s_waitcnt vmcnt(0)                                         // 00000080267C: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000802680: BF870292
	v_rcp_f32_e32 v9, v6                                       // 000000802684: 7E125506
	v_fma_f32 v1, -v6, v9, 1.0                                 // 000000802688: D6130001 23CA1306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000802690: BF870091
	v_dual_fmac_f32 v9, v1, v9 :: v_dual_and_b32 v0, 0xffff0000, v0// 000000802694: C8241301 090000FF FFFF0000
	v_dual_mul_f32 v0, 0xbfb8aa3b, v0 :: v_dual_mul_f32 v15, v13, v9// 0000008026A0: C8C600FF 000E130D BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000008026AC: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000008026B0: 7E004B00
	v_dual_add_f32 v2, v2, v5 :: v_dual_add_f32 v3, 1.0, v0    // 0000008026B4: C9080B02 020200F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008026BC: BF870111
	v_bfe_u32 v5, v2, 16, 1                                    // 0000008026C0: D6100005 02052102
	v_div_scale_f32 v11, vcc_lo, 1.0, v3, 1.0                  // 0000008026C8: D6FC6A0B 03CA06F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008026D0: BF870122
	v_add3_u32 v2, v2, v5, 0x7fff                              // 0000008026D4: D6550002 03FE0B02 00007FFF
	v_div_scale_f32 v5, null, v3, v3, 1.0                      // 0000008026E0: D6FC7C05 03CA0703
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000008026E8: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008026F0: BF870092
	v_rcp_f32_e32 v8, v5                                       // 0000008026F4: 7E105505
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 0000008026F8: 100404FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000802700: BF870311
	v_exp_f32_e32 v2, v2                                       // 000000802704: 7E044B02
	v_fma_f32 v0, -v5, v8, 1.0                                 // 000000802708: D6130000 23CA1105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000802710: BF870001
	v_fmac_f32_e32 v8, v0, v8                                  // 000000802714: 56101100
	.long 0xd73c0000                                           // 000000802718: D73C0000
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 00000080271C: 02022081
	v_fma_f32 v17, -v6, v15, v13                               // 000000802720: D6130011 24361F06
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 000000802728: BF870085
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_fmac_f32 v15, v17, v9 // 00000080272C: C90004F2 020E1311
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000802734: BF8701A1
	v_div_scale_f32 v7, null, v2, v2, 1.0                      // 000000802738: D6FC7C07 03CA0502
	v_div_scale_f32 v14, s1, 1.0, v2, 1.0                      // 000000802740: D6FC010E 03CA04F2
	v_fma_f32 v6, -v6, v15, v13                                // 000000802748: D6130006 24361F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000802750: BF870293
	v_rcp_f32_e32 v10, v7                                      // 000000802754: 7E145507
	v_fma_f32 v12, -v7, v10, 1.0                               // 000000802758: D613000C 23CA1507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000802760: BF870121
	v_fmac_f32_e32 v10, v12, v10                               // 000000802764: 5614150C
	v_mul_f32_e32 v12, v11, v8                                 // 000000802768: 1018110B
	v_mul_f32_e32 v18, v14, v10                                // 00000080276C: 1024150E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000802770: BF870112
	v_fma_f32 v16, -v5, v12, v11                               // 000000802774: D6130010 242E1905
	v_fma_f32 v19, -v7, v18, v14                               // 00000080277C: D6130013 243A2507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000802784: BF8701A2
	v_fmac_f32_e32 v12, v16, v8                                // 000000802788: 56181110
	.long 0x7f203994                                           // 00000080278C: 7F203994
	v_fmac_f32_e32 v18, v19, v10                               // 000000802790: 56241513
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000802794: BF870113
	v_fma_f32 v5, -v5, v12, v11                                // 000000802798: D6130005 242E1905
	v_fma_f32 v7, -v7, v18, v14                                // 0000008027A0: D6130007 243A2507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008027A8: BF870142
	v_div_fmas_f32 v5, v5, v8, v12                             // 0000008027AC: D6370005 04321105
	s_mov_b32 vcc_lo, s0                                       // 0000008027B4: BEEA0000
	v_div_fmas_f32 v6, v6, v9, v15                             // 0000008027B8: D6370006 043E1306
	s_mov_b32 vcc_lo, s1                                       // 0000008027C0: BEEA0001
	v_div_fixup_f32 v8, v5, v3, 1.0                            // 0000008027C4: D6270008 03CA0705
	v_div_fmas_f32 v7, v7, v10, v18                            // 0000008027CC: D6370007 044A1507
	.long 0xd7006a00                                           // 0000008027D4: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000008027D8: 02020008
	v_div_fixup_f32 v6, v6, v4, 1.0                            // 0000008027DC: D6270006 03CA0906
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008027E4: BF870214
	.long 0x7e203988                                           // 0000008027E8: 7E203988
	v_div_fixup_f32 v7, v7, v2, 1.0                            // 0000008027EC: D6270007 03CA0507
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000008027F4: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008027FC: BF870214
	.long 0x7e283986                                           // 000000802800: 7E283986
	v_and_b32_e32 v10, 1, v16                                  // 000000802804: 36142081
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000802808: BF870224
	v_bfe_u32 v9, v7, 16, 1                                    // 00000080280C: D6100009 02052107
	.long 0xd7006a02                                           // 000000802814: D7006A02
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 000000802818: 02000500
	v_and_b32_e32 v11, 1, v20                                  // 00000080281C: 36162881
	v_add_co_ci_u32_e64 v3, null, s3, v1, vcc_lo               // 000000802820: D5207C03 01AA0203
	.long 0xd7006a04                                           // 000000802828: D7006A04
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 00000080282C: 02000900
	v_add3_u32 v8, v8, v10, 0x7fff                             // 000000802830: D6550008 03FE1508 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000080283C: BF870004
	v_add3_u32 v6, v6, v11, 0x7fff                             // 000000802840: D6550006 03FE1706 00007FFF
	v_add_co_ci_u32_e64 v5, null, s5, v1, vcc_lo               // 00000080284C: D5207C05 01AA0205
	v_add3_u32 v7, v7, v9, 0x7fff                              // 000000802854: D6550007 03FE1307 00007FFF
	s_clause 0x2                                               // 000000802860: BF850002
	global_store_d16_hi_b16 v[0:1], v8, off                    // 000000802864: DC960000 007C0800
	global_store_d16_hi_b16 v[2:3], v6, off                    // 00000080286C: DC960000 007C0602
	global_store_d16_hi_b16 v[4:5], v7, off                    // 000000802874: DC960000 007C0704
	s_endpgm                                                   // 00000080287C: BFB00000
		...

