0000000000338700 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi3ELi32ELi2EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6wILi3ELi32ELi2EEEvPKhPKtPtll():
	s_load_b256 s[4:11], s[0:1], null                          // 000000338700: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 000000338708: BE830080
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000033870C: F4040300 F8000020
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000338714: 84828202
	v_lshrrev_b32_e32 v16, 6, v0                               // 000000338718: 32200086
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v2, s3             // 00000033871C: CA100080 13020003
	v_bfe_u32 v17, v0, 5, 1                                    // 000000338724: D6100011 02050B00
	v_dual_mov_b32 v7, 0 :: v_dual_and_b32 v18, 31, v0         // 00000033872C: CA240080 0712009F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000338734: BF870244
	v_or_b32_e32 v1, s2, v16                                   // 000000338738: 38022002
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v6, 0               // 00000033873C: CA100080 05060080
	v_mov_b32_e32 v8, 0                                        // 000000338744: 7E100280
	v_mov_b32_e32 v14, 0                                       // 000000338748: 7E1C0280
	.long 0xd73c0003                                           // 00000033874C: D73C0003
	v_cndmask_b32_e32 v1, 4, v1, vcc_lo                        // 000000338750: 02020284
	v_mov_b32_e32 v15, 0                                       // 000000338754: 7E1E0280
	s_waitcnt lgkmcnt(0)                                       // 000000338758: BF89FC07
	s_ashr_i32 s18, s11, 31                                    // 00000033875C: 86129F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000338760: BF8704C9
	s_lshr_b32 s0, s18, 27                                     // 000000338764: 85009B12
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000338768: 7CA8020C
	s_add_u32 s0, s10, s0                                      // 00000033876C: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000338770: 8201800B
	s_lshr_b64 s[0:1], s[0:1], 5                               // 000000338774: 85808500
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000338778: BF8704B9
	s_add_i32 s1, s0, 1                                        // 00000033877C: 81018100
	v_dual_cndmask_b32 v2, 0, v4 :: v_dual_cndmask_b32 v3, 0, v3// 000000338780: CA520880 02020680
	s_lshr_b32 s14, s1, 31                                     // 000000338788: 850E9F01
	s_add_i32 s1, s1, s14                                      // 00000033878C: 81010E01
	s_lshr_b32 s14, s11, 31                                    // 000000338790: 850E9F0B
	s_ashr_i32 s1, s1, 1                                       // 000000338794: 86018101
	s_add_u32 s14, s10, s14                                    // 000000338798: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000033879C: 820F800B
	s_lshr_b32 s19, s18, 30                                    // 0000003387A0: 85139E12
	s_ashr_i64 s[16:17], s[14:15], 1                           // 0000003387A4: 8690810E
	s_add_u32 s14, s10, s19                                    // 0000003387A8: 800E130A
	s_addc_u32 s15, s11, 0                                     // 0000003387AC: 820F800B
	s_lshr_b32 s18, s18, 28                                    // 0000003387B0: 85129C12
	s_ashr_i64 s[14:15], s[14:15], 2                           // 0000003387B4: 868E820E
	s_add_u32 s18, s10, s18                                    // 0000003387B8: 8012120A
	s_addc_u32 s19, s11, 0                                     // 0000003387BC: 8213800B
	.long 0xd72c0001                                           // 0000003387C0: D72C0001
	v_cndmask_b32_e32 v1, s1, v17, vcc_lo                      // 0000003387C4: 02022201
	s_ashr_i64 s[18:19], s[18:19], 4                           // 0000003387C8: 86928412
	s_add_u32 s20, s14, s16                                    // 0000003387CC: 8014100E
	s_addc_u32 s21, s15, s17                                   // 0000003387D0: 8215110F
	s_add_u32 s18, s20, s18                                    // 0000003387D4: 80121214
	s_addc_u32 s19, s21, s19                                   // 0000003387D8: 82131315
	s_add_u32 s18, s18, 15                                     // 0000003387DC: 80128F12
	s_addc_u32 s19, s19, 0                                     // 0000003387E0: 82138013
	v_add_nc_u32_e32 v4, s1, v1                                // 0000003387E4: 4A080201
	s_ashr_i32 s20, s19, 31                                    // 0000003387E8: 86149F13
	v_add_nc_u32_e32 v20, v1, v18                              // 0000003387EC: 4A282501
	s_lshr_b32 s20, s20, 28                                    // 0000003387F0: 85149C14
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000003387F4: BF8704C9
	s_add_u32 s18, s18, s20                                    // 0000003387F8: 80121412
	s_addc_u32 s19, s19, 0                                     // 0000003387FC: 82138013
	v_min_i32_e32 v21, s0, v4                                  // 000000338800: 222A0800
	s_ashr_i64 s[18:19], s[18:19], 4                           // 000000338804: 86928412
	.long 0xd72c000b                                           // 000000338808: D72C000B
	v_cndmask_b32_e32 v0, v3, v19, vcc_lo                      // 00000033880C: 02002703
	.long 0xd72c0002                                           // 000000338810: D72C0002
	v_cndmask_b32_e32 v0, v2, v18, vcc_lo                      // 000000338814: 02002502
	v_mad_u64_u32 v[9:10], null, v3, s18, s[4:5]               // 000000338818: D6FE7C09 00102503
	s_delay_alu instid0(VALU_DEP_1)                            // 000000338820: BF870001
	v_add3_u32 v22, v2, v10, v11                               // 000000338824: D6550016 042E1502
	v_mov_b32_e32 v11, 0                                       // 00000033882C: 7E160280
	v_cmp_lt_i32_e32 vcc_lo, v20, v21                          // 000000338830: 7C822B14
	s_and_saveexec_b32 s1, vcc_lo                              // 000000338834: BE81206A
	s_cbranch_execz 39                                         // 000000338838: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi3ELi32ELi2EEEvPKhPKtPtll+0x1d8>
	v_lshlrev_b32_e32 v1, 4, v20                               // 00000033883C: 30022884
	v_lshlrev_b32_e32 v4, 1, v20                               // 000000338840: 30082881
	v_lshlrev_b32_e32 v3, 3, v20                               // 000000338844: 30062883
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000338848: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000033884C: 3404029F
	.long 0xd7000001                                           // 000000338850: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 000000338854: 02020309
	v_and_b32_e32 v8, -4, v4                                   // 000000338858: 361008C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000033885C: BF870214
	v_ashrrev_i32_e32 v7, 31, v3                               // 000000338860: 340E069F
	v_add_co_ci_u32_e64 v2, null, v22, v2, s0                  // 000000338864: D5207C02 00020516
	.long 0xd7000005                                           // 00000033886C: D7000005
	v_cndmask_b32_e32 v0, v9, v16, vcc_lo                      // 000000338870: 02002109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000338874: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v22, s0                 // 000000338878: D5207C06 00022C11
	v_ashrrev_i32_e32 v12, 31, v8                              // 000000338880: 3418109F
	.long 0xd700000a                                           // 000000338884: D700000A
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 000000338888: 02001D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000033888C: BF8700A1
	v_add_co_ci_u32_e64 v11, null, s15, v6, s0                 // 000000338890: D5207C0B 00020C0F
	.long 0xd7000003                                           // 000000338898: D7000003
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 00000033889C: 02020705
	v_add_co_ci_u32_e64 v4, null, v6, v7, s0                   // 0000003388A0: D5207C04 00020F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003388A8: BF870094
	.long 0xd700000a                                           // 0000003388AC: D700000A
	v_cndmask_b32_e32 v1, v10, v8, vcc_lo                      // 0000003388B0: 0202110A
	v_add_co_ci_u32_e64 v11, null, v11, v12, s0                // 0000003388B4: D5207C0B 0002190B
	s_clause 0x2                                               // 0000003388BC: BF850002
	global_load_b128 v[5:8], v[1:2], off                       // 0000003388C0: DC5E0000 057C0001
	global_load_b64 v[14:15], v[3:4], off                      // 0000003388C8: DC560000 0E7C0003
	global_load_b32 v11, v[10:11], off                         // 0000003388D0: DC520000 0B7C000A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000003388D8: 8C7E017E
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 0000003388DC: CA100080 17180080
	s_and_saveexec_b32 s1, vcc_lo                              // 0000003388E4: BE81206A
	s_cbranch_execz 829                                        // 0000003388E8: BFA5033D <_ZN7halogen12_GLOBAL__N_16k_lq6wILi3ELi32ELi2EEEvPKhPKtPtll+0xee0>
	.long 0xd7006a19                                           // 0000003388EC: D7006A19
	v_cndmask_b32_e32 v0, v9, v16, vcc_lo                      // 0000003388F0: 02002109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003388F4: BF8701A1
	v_add_co_ci_u32_e64 v26, null, s17, v22, vcc_lo            // 0000003388F8: D5207C1A 01AA2C11
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v1, 32, v20     // 000000338900: CA200080 180028A0
	.long 0xd7006a1b                                           // 000000338908: D7006A1B
	v_cndmask_b32_e32 v0, v25, v14, vcc_lo                     // 00000033890C: 02001D19
	s_delay_alu instid0(VALU_DEP_1)                            // 000000338910: BF870001
	v_add_co_ci_u32_e64 v28, null, s15, v26, vcc_lo            // 000000338914: D5207C1C 01AA340F
	v_dual_mov_b32 v19, 0 :: v_dual_lshlrev_b32 v10, 5, v20    // 00000033891C: CA220080 130A2885
	s_waitcnt vmcnt(0)                                         // 000000338924: BF8903F7
	v_dual_mov_b32 v32, v11 :: v_dual_lshlrev_b32 v29, 4, v1   // 000000338928: CA22010B 201C0284
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v30, 3, v1     // 000000338930: CA220080 171E0283
	v_lshlrev_b32_e32 v31, 1, v1                               // 000000338938: 303E0281
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000033893C: 8484820A
	s_mov_b32 s14, 0                                           // 000000338940: BE8E0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000338944: 848A810A
	s_branch 765                                               // 000000338948: BFA002FD <_ZN7halogen12_GLOBAL__N_16k_lq6wILi3ELi32ELi2EEEvPKhPKtPtll+0xe40>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000033894C: 8C7E0F7E
	v_lshlrev_b32_e32 v33, 4, v14                              // 000000338950: 30421C84
	v_lshlrev_b32_e32 v35, 2, v14                              // 000000338954: 30461C82
	v_lshrrev_b32_e32 v34, 4, v5                               // 000000338958: 32440A84
	v_lshrrev_b32_e32 v36, 2, v14                              // 00000033895C: 32481C82
	.long 0x7f523880                                           // 000000338960: 7F523880
	v_and_b32_e32 v33, 48, v33                                 // 000000338964: 364242B0
	v_and_b32_e32 v35, 48, v35                                 // 000000338968: 364646B0
	v_lshrrev_b32_e32 v38, 6, v14                              // 00000033896C: 324C1C86
	v_and_b32_e32 v36, 48, v36                                 // 000000338970: 364848B0
	v_lshrrev_b32_e32 v37, 20, v5                              // 000000338974: 324A0A94
	v_and_or_b32 v33, v5, 15, v33                              // 000000338978: D6570021 04851F05
	v_and_or_b32 v34, v34, 15, v35                             // 000000338980: D6570022 048D1F22
	v_and_b32_e32 v38, 48, v38                                 // 000000338988: 364C4CB0
	v_lshrrev_b32_e32 v40, 18, v14                             // 00000033898C: 32501C92
	v_lshrrev_b32_e32 v42, 22, v14                             // 000000338990: 32541C96
	v_cvt_f32_ubyte0_e32 v33, v33                              // 000000338994: 7E422321
	v_lshrrev_b32_e32 v44, 6, v15                              // 000000338998: 32581E86
	v_and_or_b32 v37, v37, 15, v38                             // 00000033899C: D6570025 04991F25
	v_and_b32_e32 v40, 48, v40                                 // 0000003389A4: 365050B0
	v_and_b32_e32 v42, 48, v42                                 // 0000003389A8: 365454B0
	v_fma_mix_f32 v33, v33, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003389AC: CC206021 142E1721
	v_lshrrev_b32_e32 v43, 20, v7                              // 0000003389B4: 32560E94
	v_and_b32_e32 v44, 48, v44                                 // 0000003389B8: 365858B0
	v_lshrrev_b32_e32 v45, 18, v15                             // 0000003389BC: 325A1E92
	s_and_b32 s0, exec_lo, vcc_lo                              // 0000003389C0: 8B006A7E
	v_bfe_u32 v35, v33, 16, 1                                  // 0000003389C4: D6100023 02052121
	v_add_nc_u32_e32 v29, 0x200, v29                           // 0000003389CC: 4A3A3AFF 00000200
	v_and_or_b32 v43, v43, 15, v44                             // 0000003389D4: D657002B 04B11F2B
	v_and_b32_e32 v45, 48, v45                                 // 0000003389DC: 365A5AB0
	v_add_nc_u32_e32 v30, 0x100, v30                           // 0000003389E0: 4A3C3CFF 00000100
	v_add3_u32 v33, v33, v35, 0x7fff                           // 0000003389E8: D6550021 03FE4721 00007FFF
	v_and_b32_e32 v35, 48, v14                                 // 0000003389F4: 36461CB0
	v_add_nc_u32_e32 v31, 64, v31                              // 0000003389F8: 4A3E3EC0
	s_or_b32 s14, s0, s14                                      // 0000003389FC: 8C0E0E00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000338A00: BF8700A3
	.long 0x7e5239a1                                           // 000000338A04: 7E5239A1
	v_cvt_f32_ubyte0_e32 v33, v34                              // 000000338A08: 7E422322
	v_fma_mix_f32 v33, v33, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338A0C: CC206021 142E1721
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338A14: BF870091
	v_bfe_u32 v34, v33, 16, 1                                  // 000000338A18: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 000000338A20: D6550021 03FE4521 00007FFF
	v_lshrrev_b32_e32 v34, 8, v5                               // 000000338A2C: 32440A88
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338A30: BF870112
	v_and_or_b32 v33, 0xffff0000, v33, v41                     // 000000338A34: D6570021 04A642FF FFFF0000
	v_and_or_b32 v34, v34, 15, v35                             // 000000338A40: D6570022 048D1F22
	v_lshrrev_b32_e32 v35, 12, v5                              // 000000338A48: 32460A8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338A4C: BF870112
	v_cvt_f32_ubyte0_e32 v34, v34                              // 000000338A50: 7E442322
	v_and_or_b32 v35, v35, 15, v36                             // 000000338A54: D6570023 04911F23
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338A5C: BF870092
	v_fma_mix_f32 v34, v34, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338A60: CC206022 142E1722
	v_bfe_u32 v36, v34, 16, 1                                  // 000000338A68: D6100024 02052122
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000338A70: BF870121
	v_add3_u32 v34, v34, v36, 0x7fff                           // 000000338A74: D6550022 03FE4922 00007FFF
	v_lshrrev_b32_e32 v36, 8, v14                              // 000000338A80: 32481C88
	.long 0x7e5239a2                                           // 000000338A84: 7E5239A2
	v_cvt_f32_ubyte0_e32 v34, v35                              // 000000338A88: 7E442323
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338A8C: BF870113
	v_and_b32_e32 v36, 48, v36                                 // 000000338A90: 364848B0
	v_fma_mix_f32 v34, v34, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338A94: CC206022 142E1722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338A9C: BF870091
	v_bfe_u32 v35, v34, 16, 1                                  // 000000338AA0: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 000000338AA8: D6550022 03FE4722 00007FFF
	v_lshrrev_b32_e32 v35, 4, v14                              // 000000338AB4: 32461C84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000338AB8: BF8701A2
	v_and_or_b32 v34, 0xffff0000, v34, v41                     // 000000338ABC: D6570022 04A644FF FFFF0000
	.long 0x7e523985                                           // 000000338AC8: 7E523985
	v_and_b32_e32 v35, 48, v35                                 // 000000338ACC: 364646B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338AD0: BF870091
	v_and_or_b32 v35, v41, 15, v35                             // 000000338AD4: D6570023 048D1F29
	v_cvt_f32_ubyte0_e32 v35, v35                              // 000000338ADC: 7E462323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338AE0: BF870091
	v_fma_mix_f32 v35, v35, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338AE4: CC206023 142E1723
	v_bfe_u32 v38, v35, 16, 1                                  // 000000338AEC: D6100026 02052123
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000338AF4: BF870121
	v_add3_u32 v35, v35, v38, 0x7fff                           // 000000338AF8: D6550023 03FE4D23 00007FFF
	v_lshrrev_b32_e32 v38, 12, v14                             // 000000338B04: 324C1C8C
	.long 0x7e5239a3                                           // 000000338B08: 7E5239A3
	v_cvt_f32_ubyte0_e32 v35, v37                              // 000000338B0C: 7E462325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338B10: BF870091
	v_fma_mix_f32 v35, v35, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338B14: CC206023 142E1723
	v_bfe_u32 v37, v35, 16, 1                                  // 000000338B1C: D6100025 02052123
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000338B24: BF8701B1
	v_add3_u32 v35, v35, v37, 0x7fff                           // 000000338B28: D6550023 03FE4B23 00007FFF
	v_lshrrev_b32_e32 v37, 24, v5                              // 000000338B34: 324A0A98
	v_lshrrev_b32_e32 v5, 28, v5                               // 000000338B38: 320A0A9C
	v_and_or_b32 v35, 0xffff0000, v35, v41                     // 000000338B3C: D6570023 04A646FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000338B48: BF870123
	v_and_or_b32 v36, v37, 15, v36                             // 000000338B4C: D6570024 04911F25
	v_lshrrev_b32_e32 v37, 10, v14                             // 000000338B54: 324A1C8A
	v_cvt_f32_ubyte0_e32 v36, v36                              // 000000338B58: 7E482324
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338B5C: BF870112
	v_and_or_b32 v5, v37, 48, v5                               // 000000338B60: D6570005 04156125
	v_fma_mix_f32 v36, v36, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338B68: CC206024 142E1724
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338B70: BF870112
	v_cvt_f32_ubyte0_e32 v5, v5                                // 000000338B74: 7E0A2305
	v_bfe_u32 v37, v36, 16, 1                                  // 000000338B78: D6100025 02052124
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338B80: BF870112
	v_fma_mix_f32 v5, v5, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338B84: CC206005 142E1705
	v_add3_u32 v36, v36, v37, 0x7fff                           // 000000338B8C: D6550024 03FE4B24 00007FFF
	v_lshrrev_b32_e32 v37, 4, v6                               // 000000338B98: 324A0C84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000338B9C: BF870212
	.long 0x7e5239a4                                           // 000000338BA0: 7E5239A4
	v_bfe_u32 v36, v5, 16, 1                                   // 000000338BA4: D6100024 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000338BAC: BF8701B1
	v_add3_u32 v5, v5, v36, 0x7fff                             // 000000338BB0: D6550005 03FE4905 00007FFF
	v_and_b32_e32 v36, 48, v38                                 // 000000338BBC: 36484CB0
	v_lshrrev_b32_e32 v38, 14, v14                             // 000000338BC0: 324C1C8E
	v_and_or_b32 v5, 0xffff0000, v5, v41                       // 000000338BC4: D6570005 04A60AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000338BD0: BF870193
	v_and_or_b32 v36, v6, 15, v36                              // 000000338BD4: D6570024 04911F06
	v_and_b32_e32 v38, 48, v38                                 // 000000338BDC: 364C4CB0
	.long 0x7e52398e                                           // 000000338BE0: 7E52398E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000338BE4: BF870193
	v_cvt_f32_ubyte0_e32 v36, v36                              // 000000338BE8: 7E482324
	v_and_or_b32 v37, v37, 15, v38                             // 000000338BEC: D6570025 04991F25
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000338BF4: BF870193
	v_and_b32_e32 v39, 48, v41                                 // 000000338BF8: 364E52B0
	v_fma_mix_f32 v36, v36, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338BFC: CC206024 142E1724
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338C04: BF870113
	v_cvt_f32_ubyte0_e32 v37, v37                              // 000000338C08: 7E4A2325
	v_bfe_u32 v38, v36, 16, 1                                  // 000000338C0C: D6100026 02052124
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338C14: BF870112
	v_fma_mix_f32 v37, v37, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338C18: CC206025 142E1725
	v_add3_u32 v36, v36, v38, 0x7fff                           // 000000338C20: D6550024 03FE4D24 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338C2C: BF870112
	v_bfe_u32 v38, v37, 16, 1                                  // 000000338C30: D6100026 02052125
	.long 0x7e4839a4                                           // 000000338C38: 7E4839A4
	.long 0x7f4839a9                                           // 000000338C3C: 7F4839A9
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000338C40: BF870123
	v_add3_u32 v37, v37, v38, 0x7fff                           // 000000338C44: D6550025 03FE4D25 00007FFF
	v_lshrrev_b32_e32 v38, 20, v14                             // 000000338C50: 324C1C94
	v_and_or_b32 v36, 0xffff0000, v37, v36                     // 000000338C54: D6570024 04924AFF FFFF0000
	v_lshrrev_b32_e32 v37, 8, v6                               // 000000338C60: 324A0C88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338C64: BF870113
	v_and_b32_e32 v38, 48, v38                                 // 000000338C68: 364C4CB0
	v_and_or_b32 v37, v37, 15, v39                             // 000000338C6C: D6570025 049D1F25
	v_lshrrev_b32_e32 v39, 12, v6                              // 000000338C74: 324E0C8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338C78: BF870112
	v_cvt_f32_ubyte0_e32 v37, v37                              // 000000338C7C: 7E4A2325
	v_and_or_b32 v39, v39, 15, v40                             // 000000338C80: D6570027 04A11F27
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338C88: BF870092
	v_fma_mix_f32 v37, v37, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338C8C: CC206025 142E1725
	v_bfe_u32 v40, v37, 16, 1                                  // 000000338C94: D6100028 02052125
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000338C9C: BF870121
	v_add3_u32 v37, v37, v40, 0x7fff                           // 000000338CA0: D6550025 03FE5125 00007FFF
	v_lshrrev_b32_e32 v40, 20, v6                              // 000000338CAC: 32500C94
	.long 0x7e5239a5                                           // 000000338CB0: 7E5239A5
	v_cvt_f32_ubyte0_e32 v37, v39                              // 000000338CB4: 7E4A2327
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338CB8: BF870113
	v_and_or_b32 v40, v40, 15, v42                             // 000000338CBC: D6570028 04A91F28
	v_fma_mix_f32 v37, v37, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338CC4: CC206025 142E1725
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338CCC: BF870091
	v_bfe_u32 v39, v37, 16, 1                                  // 000000338CD0: D6100027 02052125
	v_add3_u32 v37, v37, v39, 0x7fff                           // 000000338CD8: D6550025 03FE4F25 00007FFF
	v_lshrrev_b32_e32 v39, 24, v14                             // 000000338CE4: 324E1C98
	v_lshrrev_b32_e32 v14, 26, v14                             // 000000338CE8: 321C1C9A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000338CEC: BF870223
	v_and_or_b32 v37, 0xffff0000, v37, v41                     // 000000338CF0: D6570025 04A64AFF FFFF0000
	.long 0x7e523986                                           // 000000338CFC: 7E523986
	v_and_b32_e32 v39, 48, v39                                 // 000000338D00: 364E4EB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338D04: BF870092
	v_and_or_b32 v38, v41, 15, v38                             // 000000338D08: D6570026 04991F29
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000338D10: 7E4C2326
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338D14: BF870091
	v_fma_mix_f32 v38, v38, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338D18: CC206026 142E1726
	v_bfe_u32 v42, v38, 16, 1                                  // 000000338D20: D610002A 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000338D28: BF870121
	v_add3_u32 v38, v38, v42, 0x7fff                           // 000000338D2C: D6550026 03FE5526 00007FFF
	v_lshrrev_b32_e32 v42, 2, v15                              // 000000338D38: 32541E82
	.long 0x7e5239a6                                           // 000000338D3C: 7E5239A6
	v_cvt_f32_ubyte0_e32 v38, v40                              // 000000338D40: 7E4C2328
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338D44: BF870113
	v_and_b32_e32 v42, 48, v42                                 // 000000338D48: 365454B0
	v_fma_mix_f32 v38, v38, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338D4C: CC206026 142E1726
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338D54: BF870091
	v_bfe_u32 v40, v38, 16, 1                                  // 000000338D58: D6100028 02052126
	v_add3_u32 v38, v38, v40, 0x7fff                           // 000000338D60: D6550026 03FE5126 00007FFF
	v_lshrrev_b32_e32 v40, 24, v6                              // 000000338D6C: 32500C98
	v_lshrrev_b32_e32 v6, 28, v6                               // 000000338D70: 320C0C9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000338D74: BF870193
	v_and_or_b32 v38, 0xffff0000, v38, v41                     // 000000338D78: D6570026 04A64CFF FFFF0000
	v_and_or_b32 v39, v40, 15, v39                             // 000000338D84: D6570027 049D1F28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000338D8C: BF8701A3
	v_and_or_b32 v6, v14, 48, v6                               // 000000338D90: D6570006 0419610E
	v_lshlrev_b32_e32 v40, 2, v15                              // 000000338D98: 30501E82
	v_cvt_f32_ubyte0_e32 v14, v39                              // 000000338D9C: 7E1C2327
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000338DA0: BF870193
	v_cvt_f32_ubyte0_e32 v6, v6                                // 000000338DA4: 7E0C2306
	v_and_b32_e32 v40, 48, v40                                 // 000000338DA8: 365050B0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000338DAC: BF870193
	v_fma_mix_f32 v14, v14, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338DB0: CC20600E 142E170E
	v_fma_mix_f32 v6, v6, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338DB8: CC206006 142E1706
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338DC0: BF870092
	v_bfe_u32 v39, v14, 16, 1                                  // 000000338DC4: D6100027 0205210E
	v_add3_u32 v14, v14, v39, 0x7fff                           // 000000338DCC: D655000E 03FE4F0E 00007FFF
	v_lshrrev_b32_e32 v39, 4, v7                               // 000000338DD8: 324E0E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000338DDC: BF8701A2
	.long 0x7e52398e                                           // 000000338DE0: 7E52398E
	v_bfe_u32 v14, v6, 16, 1                                   // 000000338DE4: D610000E 02052106
	v_and_or_b32 v39, v39, 15, v40                             // 000000338DEC: D6570027 04A11F27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000338DF4: BF870122
	v_add3_u32 v6, v6, v14, 0x7fff                             // 000000338DF8: D6550006 03FE1D06 00007FFF
	v_lshlrev_b32_e32 v14, 4, v15                              // 000000338E04: 301C1E84
	v_and_or_b32 v6, 0xffff0000, v6, v41                       // 000000338E08: D6570006 04A60CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338E14: BF870092
	v_and_b32_e32 v14, 48, v14                                 // 000000338E18: 361C1CB0
	v_and_or_b32 v14, v7, 15, v14                              // 000000338E1C: D657000E 04391F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338E24: BF870091
	v_cvt_f32_ubyte0_e32 v14, v14                              // 000000338E28: 7E1C230E
	v_fma_mix_f32 v14, v14, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338E2C: CC20600E 142E170E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338E34: BF870091
	v_bfe_u32 v40, v14, 16, 1                                  // 000000338E38: D6100028 0205210E
	v_add3_u32 v14, v14, v40, 0x7fff                           // 000000338E40: D655000E 03FE510E 00007FFF
	v_and_b32_e32 v40, 48, v15                                 // 000000338E4C: 36501EB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000338E50: BF8700A2
	.long 0x7e52398e                                           // 000000338E54: 7E52398E
	v_cvt_f32_ubyte0_e32 v14, v39                              // 000000338E58: 7E1C2327
	v_fma_mix_f32 v14, v14, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338E5C: CC20600E 142E170E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338E64: BF870091
	v_bfe_u32 v39, v14, 16, 1                                  // 000000338E68: D6100027 0205210E
	v_add3_u32 v14, v14, v39, 0x7fff                           // 000000338E70: D655000E 03FE4F0E 00007FFF
	v_lshrrev_b32_e32 v39, 8, v7                               // 000000338E7C: 324E0E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338E80: BF870112
	v_and_or_b32 v14, 0xffff0000, v14, v41                     // 000000338E84: D657000E 04A61CFF FFFF0000
	v_and_or_b32 v39, v39, 15, v40                             // 000000338E90: D6570027 04A11F27
	v_lshrrev_b32_e32 v40, 12, v7                              // 000000338E98: 32500E8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338E9C: BF870112
	v_cvt_f32_ubyte0_e32 v39, v39                              // 000000338EA0: 7E4E2327
	v_and_or_b32 v40, v40, 15, v42                             // 000000338EA4: D6570028 04A91F28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338EAC: BF870092
	v_fma_mix_f32 v39, v39, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338EB0: CC206027 142E1727
	v_bfe_u32 v42, v39, 16, 1                                  // 000000338EB8: D610002A 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000338EC0: BF870121
	v_add3_u32 v39, v39, v42, 0x7fff                           // 000000338EC4: D6550027 03FE5527 00007FFF
	v_lshrrev_b32_e32 v42, 8, v15                              // 000000338ED0: 32541E88
	.long 0x7e5239a7                                           // 000000338ED4: 7E5239A7
	v_cvt_f32_ubyte0_e32 v39, v40                              // 000000338ED8: 7E4E2328
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338EDC: BF870113
	v_and_b32_e32 v42, 48, v42                                 // 000000338EE0: 365454B0
	v_fma_mix_f32 v39, v39, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338EE4: CC206027 142E1727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338EEC: BF870091
	v_bfe_u32 v40, v39, 16, 1                                  // 000000338EF0: D6100028 02052127
	v_add3_u32 v39, v39, v40, 0x7fff                           // 000000338EF8: D6550027 03FE5127 00007FFF
	v_lshrrev_b32_e32 v40, 4, v15                              // 000000338F04: 32501E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000338F08: BF8701A2
	v_and_or_b32 v39, 0xffff0000, v39, v41                     // 000000338F0C: D6570027 04A64EFF FFFF0000
	.long 0x7e523987                                           // 000000338F18: 7E523987
	v_and_b32_e32 v40, 48, v40                                 // 000000338F1C: 365050B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338F20: BF870091
	v_and_or_b32 v40, v41, 15, v40                             // 000000338F24: D6570028 04A11F29
	v_cvt_f32_ubyte0_e32 v40, v40                              // 000000338F2C: 7E502328
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338F30: BF870091
	v_fma_mix_f32 v40, v40, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338F34: CC206028 142E1728
	v_bfe_u32 v44, v40, 16, 1                                  // 000000338F3C: D610002C 02052128
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000338F44: BF870121
	v_add3_u32 v40, v40, v44, 0x7fff                           // 000000338F48: D6550028 03FE5928 00007FFF
	v_lshrrev_b32_e32 v44, 12, v15                             // 000000338F54: 32581E8C
	.long 0x7e5239a8                                           // 000000338F58: 7E5239A8
	v_cvt_f32_ubyte0_e32 v40, v43                              // 000000338F5C: 7E50232B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000338F60: BF870091
	v_fma_mix_f32 v40, v40, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338F64: CC206028 142E1728
	v_bfe_u32 v43, v40, 16, 1                                  // 000000338F6C: D610002B 02052128
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000338F74: BF8701B1
	v_add3_u32 v40, v40, v43, 0x7fff                           // 000000338F78: D6550028 03FE5728 00007FFF
	v_lshrrev_b32_e32 v43, 24, v7                              // 000000338F84: 32560E98
	v_lshrrev_b32_e32 v7, 28, v7                               // 000000338F88: 320E0E9C
	v_and_or_b32 v40, 0xffff0000, v40, v41                     // 000000338F8C: D6570028 04A650FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000338F98: BF870123
	v_and_or_b32 v42, v43, 15, v42                             // 000000338F9C: D657002A 04A91F2B
	v_lshrrev_b32_e32 v43, 10, v15                             // 000000338FA4: 32561E8A
	v_cvt_f32_ubyte0_e32 v42, v42                              // 000000338FA8: 7E54232A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338FAC: BF870112
	v_and_or_b32 v7, v43, 48, v7                               // 000000338FB0: D6570007 041D612B
	v_fma_mix_f32 v42, v42, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338FB8: CC20602A 142E172A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338FC0: BF870112
	v_cvt_f32_ubyte0_e32 v7, v7                                // 000000338FC4: 7E0E2307
	v_bfe_u32 v43, v42, 16, 1                                  // 000000338FC8: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000338FD0: BF870112
	v_fma_mix_f32 v7, v7, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000338FD4: CC206007 142E1707
	v_add3_u32 v42, v42, v43, 0x7fff                           // 000000338FDC: D655002A 03FE572A 00007FFF
	v_lshrrev_b32_e32 v43, 4, v8                               // 000000338FE8: 32561084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000338FEC: BF870212
	.long 0x7e5239aa                                           // 000000338FF0: 7E5239AA
	v_bfe_u32 v42, v7, 16, 1                                   // 000000338FF4: D610002A 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000338FFC: BF870121
	v_add3_u32 v7, v7, v42, 0x7fff                             // 000000339000: D6550007 03FE5507 00007FFF
	v_and_b32_e32 v42, 15, v8                                  // 00000033900C: 3654108F
	v_and_or_b32 v7, 0xffff0000, v7, v41                       // 000000339010: D6570007 04A60EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000033901C: BF8701B2
	v_and_or_b32 v42, v44, 48, v42                             // 000000339020: D657002A 04A9612C
	v_lshrrev_b32_e32 v44, 14, v15                             // 000000339028: 32581E8E
	.long 0x7e52398f                                           // 00000033902C: 7E52398F
	v_cvt_f32_ubyte0_e32 v42, v42                              // 000000339030: 7E54232A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000339034: BF870113
	v_and_b32_e32 v44, 48, v44                                 // 000000339038: 365858B0
	v_fma_mix_f32 v42, v42, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033903C: CC20602A 142E172A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000339044: BF870112
	v_and_or_b32 v43, v43, 15, v44                             // 000000339048: D657002B 04B11F2B
	v_bfe_u32 v44, v42, 16, 1                                  // 000000339050: D610002C 0205212A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000339058: BF870112
	v_cvt_f32_ubyte0_e32 v43, v43                              // 00000033905C: 7E56232B
	v_add3_u32 v42, v42, v44, 0x7fff                           // 000000339060: D655002A 03FE592A 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000033906C: BF870112
	v_fma_mix_f32 v43, v43, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000339070: CC20602B 142E172B
	.long 0x7e5439aa                                           // 000000339078: 7E5439AA
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000033907C: BF870122
	v_bfe_u32 v44, v43, 16, 1                                  // 000000339080: D610002C 0205212B
	.long 0x7f5439a9                                           // 000000339088: 7F5439A9
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000033908C: D655002B 03FE592B 00007FFF
	v_and_b32_e32 v44, 48, v41                                 // 000000339098: 365852B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000033909C: BF870132
	v_and_or_b32 v59, 0xffff0000, v43, v42                     // 0000003390A0: D657003B 04AA56FF FFFF0000
	v_lshrrev_b32_e32 v42, 8, v8                               // 0000003390AC: 32541088
	v_lshrrev_b32_e32 v43, 20, v15                             // 0000003390B0: 32561E94
	v_and_or_b32 v42, v42, 15, v44                             // 0000003390B4: D657002A 04B11F2A
	v_lshrrev_b32_e32 v44, 12, v8                              // 0000003390BC: 3258108C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003390C0: BF870193
	v_and_b32_e32 v43, 48, v43                                 // 0000003390C4: 365656B0
	v_cvt_f32_ubyte0_e32 v42, v42                              // 0000003390C8: 7E54232A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003390CC: BF870113
	v_and_or_b32 v44, v44, 15, v45                             // 0000003390D0: D657002C 04B51F2C
	v_fma_mix_f32 v42, v42, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003390D8: CC20602A 142E172A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003390E0: BF870091
	v_bfe_u32 v45, v42, 16, 1                                  // 0000003390E4: D610002D 0205212A
	v_add3_u32 v42, v42, v45, 0x7fff                           // 0000003390EC: D655002A 03FE5B2A 00007FFF
	v_lshrrev_b32_e32 v45, 22, v15                             // 0000003390F8: 325A1E96
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003390FC: BF8701A2
	.long 0x7e5239aa                                           // 000000339100: 7E5239AA
	v_cvt_f32_ubyte0_e32 v42, v44                              // 000000339104: 7E54232C
	v_and_b32_e32 v45, 48, v45                                 // 000000339108: 365A5AB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000033910C: BF870092
	v_fma_mix_f32 v42, v42, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000339110: CC20602A 142E172A
	v_bfe_u32 v44, v42, 16, 1                                  // 000000339118: D610002C 0205212A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000339120: BF870121
	v_add3_u32 v42, v42, v44, 0x7fff                           // 000000339124: D655002A 03FE592A 00007FFF
	v_lshrrev_b32_e32 v44, 20, v8                              // 000000339130: 32581094
	v_and_or_b32 v60, 0xffff0000, v42, v41                     // 000000339134: D657003C 04A654FF FFFF0000
	.long 0x7e523988                                           // 000000339140: 7E523988
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000339144: BF870233
	v_and_or_b32 v44, v44, 15, v45                             // 000000339148: D657002C 04B51F2C
	v_lshrrev_b32_e32 v42, 24, v15                             // 000000339150: 32541E98
	v_lshrrev_b32_e32 v15, 26, v15                             // 000000339154: 321E1E9A
	v_and_or_b32 v43, v41, 15, v43                             // 000000339158: D657002B 04AD1F29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000339160: BF870113
	v_and_b32_e32 v42, 48, v42                                 // 000000339164: 365454B0
	v_cvt_f32_ubyte0_e32 v43, v43                              // 000000339168: 7E56232B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000033916C: BF870091
	v_fma_mix_f32 v43, v43, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000339170: CC20602B 142E172B
	v_bfe_u32 v45, v43, 16, 1                                  // 000000339178: D610002D 0205212B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000339180: BF870091
	v_add3_u32 v43, v43, v45, 0x7fff                           // 000000339184: D655002B 03FE5B2B 00007FFF
	.long 0x7e5239ab                                           // 000000339190: 7E5239AB
	v_cvt_f32_ubyte0_e32 v43, v44                              // 000000339194: 7E56232C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000339198: BF870091
	v_fma_mix_f32 v43, v43, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033919C: CC20602B 142E172B
	v_bfe_u32 v44, v43, 16, 1                                  // 0000003391A4: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003391AC: BF870091
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000003391B0: D655002B 03FE592B 00007FFF
	v_and_or_b32 v61, 0xffff0000, v43, v41                     // 0000003391BC: D657003D 04A656FF FFFF0000
	v_lshrrev_b32_e32 v43, 24, v8                              // 0000003391C8: 32561098
	v_lshrrev_b32_e32 v8, 28, v8                               // 0000003391CC: 3210109C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003391D0: BF870112
	v_and_or_b32 v42, v43, 15, v42                             // 0000003391D4: D657002A 04A91F2B
	v_and_or_b32 v8, v15, 48, v8                               // 0000003391DC: D6570008 0421610F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003391E4: BF870112
	v_cvt_f32_ubyte0_e32 v15, v42                              // 0000003391E8: 7E1E232A
	v_cvt_f32_ubyte0_e32 v8, v8                                // 0000003391EC: 7E102308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003391F0: BF870112
	v_fma_mix_f32 v15, v15, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003391F4: CC20600F 142E170F
	v_fma_mix_f32 v8, v8, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003391FC: CC206008 142E1708
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000339204: BF870112
	v_bfe_u32 v42, v15, 16, 1                                  // 000000339208: D610002A 0205210F
	v_bfe_u32 v11, v8, 16, 1                                   // 000000339210: D610000B 02052108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000339218: BF870112
	v_add3_u32 v15, v15, v42, 0x7fff                           // 00000033921C: D655000F 03FE550F 00007FFF
	v_add3_u32 v8, v8, v11, 0x7fff                             // 000000339228: D6550008 03FE1708 00007FFF
	v_ashrrev_i32_e32 v11, 31, v10                             // 000000339234: 3416149F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000339238: BF870133
	.long 0x7e52398f                                           // 00000033923C: 7E52398F
	s_waitcnt vmcnt(1)                                         // 000000339240: BF8907F7
	v_mov_b32_e32 v15, v13                                     // 000000339244: 7E1E030D
	v_and_or_b32 v8, 0xffff0000, v8, v41                       // 000000339248: D6570008 04A610FF FFFF0000
	.long 0xd73c0029                                           // 000000339254: D73C0029
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 000000339258: 02021481
	v_add_nc_u32_e32 v10, 0x400, v10                           // 00000033925C: 4A1414FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000339264: BF870092
	.long 0xd7006a39                                           // 000000339268: D7006A39
	v_cndmask_b32_e32 v1, s6, v41, vcc_lo                      // 00000033926C: 02025206
	v_add_co_ci_u32_e64 v58, null, s7, v42, vcc_lo             // 000000339270: D5207C3A 01AA5407
	s_clause 0x3                                               // 000000339278: BF850003
	global_load_b128 v[41:44], v[57:58], off                   // 00000033927C: DC5E0000 297C0039
	global_load_b128 v[45:48], v[57:58], off offset:16         // 000000339284: DC5E0010 2D7C0039
	global_load_b128 v[49:52], v[57:58], off offset:32         // 00000033928C: DC5E0020 317C0039
	global_load_b128 v[53:56], v[57:58], off offset:48         // 000000339294: DC5E0030 357C0039
	s_waitcnt vmcnt(3)                                         // 00000033929C: BF890FF7
	v_dot2_f32_bf16 v11, v41, v33, 0                           // 0000003392A0: CC1A400B 1A024329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003392A8: BF870091
	v_dot2_f32_bf16 v11, v42, v34, v11                         // 0000003392AC: CC1A400B 1C2E452A
	v_dot2_f32_bf16 v11, v43, v35, v11                         // 0000003392B4: CC1A400B 1C2E472B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003392BC: BF8700A1
	v_dot2_f32_bf16 v11, v44, v5, v11                          // 0000003392C0: CC1A400B 1C2E0B2C
	s_waitcnt vmcnt(2)                                         // 0000003392C8: BF890BF7
	v_dot2_f32_bf16 v11, v45, v36, v11                         // 0000003392CC: CC1A400B 1C2E492D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003392D4: BF870091
	v_dot2_f32_bf16 v11, v46, v37, v11                         // 0000003392D8: CC1A400B 1C2E4B2E
	v_dot2_f32_bf16 v11, v47, v38, v11                         // 0000003392E0: CC1A400B 1C2E4D2F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003392E8: BF8700A1
	v_dot2_f32_bf16 v11, v48, v6, v11                          // 0000003392EC: CC1A400B 1C2E0D30
	s_waitcnt vmcnt(1)                                         // 0000003392F4: BF8907F7
	v_dot2_f32_bf16 v11, v49, v14, v11                         // 0000003392F8: CC1A400B 1C2E1D31
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000339300: BF870091
	v_dot2_f32_bf16 v11, v50, v39, v11                         // 000000339304: CC1A400B 1C2E4F32
	v_dot2_f32_bf16 v11, v51, v40, v11                         // 00000033930C: CC1A400B 1C2E5133
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000339314: BF8700A1
	v_dot2_f32_bf16 v11, v52, v7, v11                          // 000000339318: CC1A400B 1C2E0F34
	s_waitcnt vmcnt(0)                                         // 000000339320: BF8903F7
	v_dot2_f32_bf16 v11, v53, v59, v11                         // 000000339324: CC1A400B 1C2E7735
	.long 0xd7006a35                                           // 00000033932C: D7006A35
	v_cndmask_b32_e32 v0, v57, v10, vcc_lo                     // 000000339330: 02001539
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000339334: BF870122
	v_dot2_f32_bf16 v11, v54, v60, v11                         // 000000339338: CC1A400B 1C2E7936
	v_add_co_ci_u32_e64 v54, null, s11, v58, vcc_lo            // 000000339340: D5207C36 01AA740B
	v_dot2_f32_bf16 v11, v55, v61, v11                         // 000000339348: CC1A400B 1C2E7B37
	s_delay_alu instid0(VALU_DEP_1)                            // 000000339350: BF870001
	v_dot2_f32_bf16 v11, v56, v8, v11                          // 000000339354: CC1A400B 1C2E1138
	s_clause 0x3                                               // 00000033935C: BF850003
	global_load_b128 v[41:44], v[53:54], off                   // 000000339360: DC5E0000 297C0035
	global_load_b128 v[45:48], v[53:54], off offset:16         // 000000339368: DC5E0010 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:32         // 000000339370: DC5E0020 317C0035
	global_load_b128 v[53:56], v[53:54], off offset:48         // 000000339378: DC5E0030 357C0035
	v_add_f32_e32 v24, v24, v11                                // 000000339380: 06301718
	s_waitcnt vmcnt(3)                                         // 000000339384: BF890FF7
	v_dot2_f32_bf16 v11, v41, v33, 0                           // 000000339388: CC1A400B 1A024329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000339390: BF870091
	v_dot2_f32_bf16 v11, v42, v34, v11                         // 000000339394: CC1A400B 1C2E452A
	v_dot2_f32_bf16 v11, v43, v35, v11                         // 00000033939C: CC1A400B 1C2E472B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003393A4: BF8700A1
	v_dot2_f32_bf16 v11, v44, v5, v11                          // 0000003393A8: CC1A400B 1C2E0B2C
	s_waitcnt vmcnt(2)                                         // 0000003393B0: BF890BF7
	v_dot2_f32_bf16 v11, v45, v36, v11                         // 0000003393B4: CC1A400B 1C2E492D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003393BC: BF870091
	v_dot2_f32_bf16 v11, v46, v37, v11                         // 0000003393C0: CC1A400B 1C2E4B2E
	v_dot2_f32_bf16 v11, v47, v38, v11                         // 0000003393C8: CC1A400B 1C2E4D2F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003393D0: BF8700A1
	v_dot2_f32_bf16 v11, v48, v6, v11                          // 0000003393D4: CC1A400B 1C2E0D30
	s_waitcnt vmcnt(1)                                         // 0000003393DC: BF8907F7
	v_dot2_f32_bf16 v11, v49, v14, v11                         // 0000003393E0: CC1A400B 1C2E1D31
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003393E8: BF870091
	v_dot2_f32_bf16 v11, v50, v39, v11                         // 0000003393EC: CC1A400B 1C2E4F32
	v_dot2_f32_bf16 v11, v51, v40, v11                         // 0000003393F4: CC1A400B 1C2E5133
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003393FC: BF8700A1
	v_dot2_f32_bf16 v11, v52, v7, v11                          // 000000339400: CC1A400B 1C2E0F34
	s_waitcnt vmcnt(0)                                         // 000000339408: BF8903F7
	v_dot2_f32_bf16 v11, v53, v59, v11                         // 00000033940C: CC1A400B 1C2E7735
	.long 0xd7006a35                                           // 000000339414: D7006A35
	v_cndmask_b32_e32 v0, v57, v4, vcc_lo                      // 000000339418: 02000939
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000033941C: BF870122
	v_dot2_f32_bf16 v11, v54, v60, v11                         // 000000339420: CC1A400B 1C2E7936
	v_add_co_ci_u32_e64 v54, null, s5, v58, vcc_lo             // 000000339428: D5207C36 01AA7405
	v_dot2_f32_bf16 v11, v55, v61, v11                         // 000000339430: CC1A400B 1C2E7B37
	s_delay_alu instid0(VALU_DEP_1)                            // 000000339438: BF870001
	v_dot2_f32_bf16 v11, v56, v8, v11                          // 00000033943C: CC1A400B 1C2E1138
	s_clause 0x3                                               // 000000339444: BF850003
	global_load_b128 v[41:44], v[53:54], off                   // 000000339448: DC5E0000 297C0035
	global_load_b128 v[45:48], v[53:54], off offset:16         // 000000339450: DC5E0010 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:32         // 000000339458: DC5E0020 317C0035
	global_load_b128 v[53:56], v[53:54], off offset:48         // 000000339460: DC5E0030 357C0035
	v_add_f32_e32 v23, v23, v11                                // 000000339468: 062E1717
	s_waitcnt vmcnt(3)                                         // 00000033946C: BF890FF7
	v_dot2_f32_bf16 v11, v41, v33, 0                           // 000000339470: CC1A400B 1A024329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000339478: BF870091
	v_dot2_f32_bf16 v11, v42, v34, v11                         // 00000033947C: CC1A400B 1C2E452A
	v_dot2_f32_bf16 v11, v43, v35, v11                         // 000000339484: CC1A400B 1C2E472B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000033948C: BF870131
	v_dot2_f32_bf16 v5, v44, v5, v11                           // 000000339490: CC1A4005 1C2E0B2C
	v_mov_b32_e32 v11, v32                                     // 000000339498: 7E160320
	s_waitcnt vmcnt(2)                                         // 00000033949C: BF890BF7
	v_dot2_f32_bf16 v5, v45, v36, v5                           // 0000003394A0: CC1A4005 1C16492D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003394A8: BF870091
	v_dot2_f32_bf16 v5, v46, v37, v5                           // 0000003394AC: CC1A4005 1C164B2E
	v_dot2_f32_bf16 v5, v47, v38, v5                           // 0000003394B4: CC1A4005 1C164D2F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003394BC: BF870131
	v_dot2_f32_bf16 v5, v48, v6, v5                            // 0000003394C0: CC1A4005 1C160D30
	v_mov_b32_e32 v6, v2                                       // 0000003394C8: 7E0C0302
	s_waitcnt vmcnt(1)                                         // 0000003394CC: BF8907F7
	v_dot2_f32_bf16 v5, v49, v14, v5                           // 0000003394D0: CC1A4005 1C161D31
	v_mov_b32_e32 v14, v12                                     // 0000003394D8: 7E1C030C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003394DC: BF870092
	v_dot2_f32_bf16 v5, v50, v39, v5                           // 0000003394E0: CC1A4005 1C164F32
	v_dot2_f32_bf16 v5, v51, v40, v5                           // 0000003394E8: CC1A4005 1C165133
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003394F0: BF870131
	v_dot2_f32_bf16 v5, v52, v7, v5                            // 0000003394F4: CC1A4005 1C160F34
	v_mov_b32_e32 v7, v3                                       // 0000003394FC: 7E0E0303
	s_waitcnt vmcnt(0)                                         // 000000339500: BF8903F7
	v_dot2_f32_bf16 v5, v53, v59, v5                           // 000000339504: CC1A4005 1C167735
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000033950C: BF870091
	v_dot2_f32_bf16 v5, v54, v60, v5                           // 000000339510: CC1A4005 1C167936
	v_dot2_f32_bf16 v5, v55, v61, v5                           // 000000339518: CC1A4005 1C167B37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000339520: BF870091
	v_dot2_f32_bf16 v5, v56, v8, v5                            // 000000339524: CC1A4005 1C161138
	v_dual_mov_b32 v8, v4 :: v_dual_add_f32 v19, v19, v5       // 00000033952C: CA080104 08120B13
	v_mov_b32_e32 v5, v1                                       // 000000339534: 7E0A0301
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 000000339538: 917E0E7E
	s_cbranch_execz 39                                         // 00000033953C: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi3ELi32ELi2EEEvPKhPKtPtll+0xedc>
	s_delay_alu instid0(VALU_DEP_1)                            // 000000339540: BF870001
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v20, 32, v20    // 000000339544: CA200105 011428A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 00000033954C: CA100106 02020107
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v13, v15           // 000000339554: CA100108 040C010F
	v_mov_b32_e32 v12, v14                                     // 00000033955C: 7E18030E
	s_mov_b32 s15, exec_lo                                     // 000000339560: BE8F007E
	v_cmp_ge_i32_e32 vcc_lo, v20, v21                          // 000000339564: 7C8C2B14
	.long 0xd4c1007e                                           // 000000339568: D4C1007E
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                     // 00000033956C: 02022B14
	s_cbranch_execz 64758                                      // 000000339570: BFA5FCF6 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi3ELi32ELi2EEEvPKhPKtPtll+0x24c>
	v_and_b32_e32 v3, -4, v31                                  // 000000339574: 36063EC4
	v_ashrrev_i32_e32 v2, 31, v29                              // 000000339578: 34043A9F
	v_ashrrev_i32_e32 v4, 31, v30                              // 00000033957C: 34083C9F
	.long 0xd7000001                                           // 000000339580: D7000001
	v_cndmask_b32_e32 v1, v9, v29, vcc_lo                      // 000000339584: 02023B09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000339588: BF870214
	v_ashrrev_i32_e32 v33, 31, v3                              // 00000033958C: 3442069F
	v_add_co_ci_u32_e64 v2, null, v22, v2, s0                  // 000000339590: D5207C02 00020516
	.long 0xd700000c                                           // 000000339598: D700000C
	v_cndmask_b32_e32 v1, v25, v30, vcc_lo                     // 00000033959C: 02023D19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003395A0: BF8700A1
	v_add_co_ci_u32_e64 v13, null, v26, v4, s0                 // 0000003395A4: D5207C0D 0002091A
	.long 0xd7000020                                           // 0000003395AC: D7000020
	v_cndmask_b32_e32 v1, v27, v3, vcc_lo                      // 0000003395B0: 0202071B
	v_add_co_ci_u32_e64 v33, null, v28, v33, s0                // 0000003395B4: D5207C21 0002431C
	s_clause 0x2                                               // 0000003395BC: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 0000003395C0: DC5E0000 017C0001
	global_load_b64 v[12:13], v[12:13], off                    // 0000003395C8: DC560000 0C7C000C
	global_load_b32 v32, v[32:33], off                         // 0000003395D0: DC520000 207C0020
	s_branch 64732                                             // 0000003395D8: BFA0FCDC <_ZN7halogen12_GLOBAL__N_16k_lq6wILi3ELi32ELi2EEEvPKhPKtPtll+0x24c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000003395DC: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003395E0: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000003395E4: 8C7E017E
	.long 0xd71f0001                                           // 0000003395E8: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003395EC: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000003395F0: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000003395F4: 3A040290
	s_waitcnt vmcnt(2)                                         // 0000003395F8: BF890BF7
	v_xor_b32_e32 v5, 8, v1                                    // 0000003395FC: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 000000339600: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000339604: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000339608: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000033960C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000339610: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 000000339614: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000339618: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000033961C: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000339620: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000339624: 30040482
	ds_bpermute_b32 v3, v2, v24                                // 000000339628: DACC0000 03001802
	s_waitcnt lgkmcnt(0)                                       // 000000339630: BF89FC07
	v_add_f32_e32 v3, v24, v3                                  // 000000339634: 06060718
	ds_bpermute_b32 v4, v2, v23                                // 000000339638: DACC0000 04001702
	ds_bpermute_b32 v2, v2, v19                                // 000000339640: DACC0000 02001302
	ds_bpermute_b32 v6, v5, v3                                 // 000000339648: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 000000339650: 02101101
	s_waitcnt lgkmcnt(2)                                       // 000000339654: BF89FC27
	v_add_f32_e32 v4, v23, v4                                  // 000000339658: 06080917
	s_waitcnt lgkmcnt(1)                                       // 00000033965C: BF89FC17
	v_add_f32_e32 v2, v19, v2                                  // 000000339660: 06040513
	s_waitcnt lgkmcnt(0)                                       // 000000339664: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 000000339668: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 00000033966C: DACC0000 07000405
	ds_bpermute_b32 v5, v5, v2                                 // 000000339674: DACC0000 05000205
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000033967C: 30101082
	s_waitcnt lgkmcnt(0)                                       // 000000339680: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 000000339684: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 000000339688: DACC0000 05000308
	s_waitcnt lgkmcnt(0)                                       // 000000339690: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v7     // 000000339694: C9080B03 03040F04
	ds_bpermute_b32 v7, v8, v2                                 // 00000033969C: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 0000003396A4: DACC0000 06000408
	v_xor_b32_e32 v8, 2, v1                                    // 0000003396AC: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003396B0: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000003396B4: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000003396B8: 02101101
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000003396BC: 30101082
	s_waitcnt lgkmcnt(1)                                       // 0000003396C0: BF89FC17
	v_add_f32_e32 v2, v2, v7                                   // 0000003396C4: 06040F02
	s_waitcnt lgkmcnt(0)                                       // 0000003396C8: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 0000003396CC: 06080D04
	ds_bpermute_b32 v5, v8, v3                                 // 0000003396D0: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 0000003396D8: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 0000003396E0: DACC0000 06000408
	v_xor_b32_e32 v8, 1, v1                                    // 0000003396E8: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003396EC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000003396F0: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 0000003396F4: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 0000003396F8: 30100282
	s_waitcnt lgkmcnt(1)                                       // 0000003396FC: BF89FC17
	v_dual_add_f32 v1, v3, v5 :: v_dual_add_f32 v2, v2, v7     // 000000339700: C9080B03 01020F02
	s_waitcnt lgkmcnt(0)                                       // 000000339708: BF89FC07
	v_add_f32_e32 v3, v4, v6                                   // 00000033970C: 06060D04
	ds_bpermute_b32 v4, v8, v1                                 // 000000339710: DACC0000 04000108
	ds_bpermute_b32 v5, v8, v2                                 // 000000339718: DACC0000 05000208
	ds_bpermute_b32 v6, v8, v3                                 // 000000339720: DACC0000 06000308
	v_cmpx_eq_u32_e32 0, v18                                   // 000000339728: 7D942480
	s_cbranch_execz 12                                         // 00000033972C: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq6wILi3ELi32ELi2EEEvPKhPKtPtll+0x1060>
	v_lshl_or_b32 v7, v16, 1, v17                              // 000000339730: D6560007 04450310
	s_waitcnt lgkmcnt(0)                                       // 000000339738: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v2, v2, v5     // 00000033973C: C9080D03 03020B02
	v_add_f32_e32 v1, v1, v4                                   // 000000339744: 06020901
	s_delay_alu instid0(VALU_DEP_3)                            // 000000339748: BF870003
	v_mul_u32_u24_e32 v4, 12, v7                               // 00000033974C: 16080E8C
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 000000339750: D8380100 00030104
	ds_store_b32 v4, v2 offset:8                               // 000000339758: D8340008 00000204
	s_or_b32 exec_lo, exec_lo, s0                              // 000000339760: 8C7E007E
	.long 0xd7050001                                           // 000000339764: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 000000339768: 020200FF 000000AB
	.long 0x7f063880                                           // 000000339770: 7F063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000339774: BF890007
	s_barrier                                                  // 000000339778: BFBD0000
	buffer_gl0_inv                                             // 00000033977C: E0AC0000 00000000
	.long 0xd7390003                                           // 000000339784: D7390003
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 000000339788: 02020289
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000033978C: BF870091
	.long 0xd7000001                                           // 000000339790: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000339794: 02020602
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 000000339798: D5207C02 00010003
	.long 0xd44c0000                                           // 0000003397A0: D44C0000
	v_cndmask_b32_e32 v1, 12, v0, vcc_lo                       // 0000003397A4: 0202008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003397A8: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000003397AC: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 0000003397B0: 8B006A00
	s_and_saveexec_b32 s1, s0                                  // 0000003397B4: BE812000
	s_cbranch_execz 45                                         // 0000003397B8: BFA5002D <_ZN7halogen12_GLOBAL__N_16k_lq6wILi3ELi32ELi2EEEvPKhPKtPtll+0x1170>
	.long 0xd7054000                                           // 0000003397BC: D7054000
	v_cndmask_b32_e32 v0, v3, v131, vcc_lo                     // 0000003397C0: 02010703
	.long 0xd7380003                                           // 0000003397C4: D7380003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000003397C8: 02020681
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003397CC: BF870112
	.long 0xd7041000                                           // 0000003397D0: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000003397D4: 02020100
	v_mul_u32_u24_e32 v3, 12, v3                               // 0000003397D8: 1606068C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003397DC: BF870092
	v_and_b32_e32 v0, 0xff, v0                                 // 0000003397E0: 360000FF 000000FF
	v_lshl_add_u32 v3, v0, 2, v3                               // 0000003397E8: D6460003 040D0500
	ds_load_2addr_b32 v[6:7], v3 offset1:3                     // 0000003397F0: D8DC0300 06000003
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 0000003397F8: D6FE7C03 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000339800: BF870091
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000339804: D6FE7C04 0412000D
	.long 0xd73c0003                                           // 00000033980C: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 000000339810: 02020681
	s_waitcnt lgkmcnt(0)                                       // 000000339814: BF89FC07
	v_add_f32_e32 v0, 0, v6                                    // 000000339818: 06000C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000033981C: BF870112
	.long 0xd7006a03                                           // 000000339820: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000339824: 02020608
	v_add_f32_e32 v5, v0, v7                                   // 000000339828: 060A0F00
	.long 0xd73c0000                                           // 00000033982C: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000339830: 02020281
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000339834: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000033983C: BF870193
	v_bfe_u32 v2, v5, 16, 1                                    // 000000339840: D6100002 02052105
	.long 0xd7006a00                                           // 000000339848: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000033984C: 02020103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000339850: BF870191
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000339854: D5207C01 01AA0304
	v_add3_u32 v2, v5, v2, 0x7fff                              // 00000033985C: D6550002 03FE0505 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000339868: DC960000 007C0200
	s_endpgm                                                   // 000000339870: BFB00000
		...

