0000000000faca00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000FACA00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000FACA08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000FACA0C: 32040082
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000FACA10: 84808302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FACA14: BF8701A9
	v_dual_mov_b32 v24, s1 :: v_dual_and_b32 v1, 15, v0        // 000000FACA18: CA240001 1800008F
	v_and_b32_e32 v30, 31, v0                                  // 000000FACA20: 363C009F
	v_and_b32_e32 v2, 60, v2                                   // 000000FACA24: 360404BC
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000FACA28: 300E0082
	s_delay_alu instid0(VALU_DEP_4)                            // 000000FACA2C: BF870004
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000FACA30: 30020282
	.long 0x7f0c3880                                           // 000000FACA34: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 000000FACA38: BF89FC07
	s_clause 0x1                                               // 000000FACA3C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000FACA40: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000FACA48: DC520000 04040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000FACA50: 32020085
	s_add_u32 s22, s4, s16                                     // 000000FACA54: 80161004
	s_addc_u32 s23, s5, s17                                    // 000000FACA58: 82171105
	s_ashr_i32 s2, s11, 31                                     // 000000FACA5C: 86029F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000FACA60: BF8704A1
	v_or_b32_e32 v23, s0, v1                                   // 000000FACA64: 382E0200
	s_lshr_b32 s2, s2, 27                                      // 000000FACA68: 85029B02
	s_add_u32 s2, s10, s2                                      // 000000FACA6C: 8002020A
	s_addc_u32 s3, s11, 0                                      // 000000FACA70: 8203800B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000FACA74: BF8704A1
	.long 0xd4540000                                           // 000000FACA78: D4540000
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 000000FACA7C: 02022E0C
	s_lshr_b64 s[20:21], s[2:3], 5                             // 000000FACA80: 85948502
	s_cmpk_lt_i32 s20, 0x101                                   // 000000FACA84: B3940101
	.long 0xd4440002                                           // 000000FACA88: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 000000FACA8C: 02023C14
	v_cndmask_b32_e64 v2, 0, v23, s0                           // 000000FACA90: D5010002 00022E80
	v_cndmask_b32_e64 v5, 0, s1, s0                            // 000000FACA98: D5010005 00000280
	s_cselect_b32 s1, -1, 0                                    // 000000FACAA0: 980180C1
	s_cmpk_gt_i32 s20, 0x100                                   // 000000FACAA4: B2940100
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FACAA8: BF870002
	.long 0xd72c0008                                           // 000000FACAAC: D72C0008
	v_cndmask_b32_e32 v1, s19, v2, vcc_lo                      // 000000FACAB0: 02020413
	v_mad_u64_u32 v[0:1], null, s18, v2, 0                     // 000000FACAB4: D6FE7C00 02020412
	s_waitcnt vmcnt(1)                                         // 000000FACABC: BF8907F7
	v_bfe_u32 v9, v3, 16, 1                                    // 000000FACAC0: D6100009 02052103
	s_waitcnt vmcnt(0)                                         // 000000FACAC8: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 000000FACACC: D610000A 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FACAD4: BF8701A2
	v_add3_u32 v3, v3, v9, 0x7fff                              // 000000FACAD8: D6550003 03FE1303 00007FFF
	.long 0xd72c0009                                           // 000000FACAE4: D72C0009
	v_cndmask_b32_e32 v1, s18, v5, vcc_lo                      // 000000FACAE8: 02020A12
	v_add3_u32 v4, v4, v10, 0x7fff                             // 000000FACAEC: D6550004 03FE1504 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 000000FACAF8: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000FACAFC: BF870239
	s_and_b32 vcc_lo, exec_lo, s18                             // 000000FACB00: 8B6A127E
	.long 0x7e0c3983                                           // 000000FACB04: 7E0C3983
	.long 0xd7000303                                           // 000000FACB08: D7000303
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 000000FACB0C: 02020016
	v_add3_u32 v1, v1, v9, v8                                  // 000000FACB10: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FACB18: BF870113
	v_and_or_b32 v6, 0xffff0000, v4, v6                        // 000000FACB1C: D6570006 041A08FF FFFF0000
	v_add_co_ci_u32_e64 v4, null, s23, v1, s3                  // 000000FACB28: D5207C04 000E0217
	ds_store_b32 v7, v6                                        // 000000FACB30: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 000000FACB38: BF89FC07
	s_barrier                                                  // 000000FACB3C: BFBD0000
	buffer_gl0_inv                                             // 000000FACB40: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 000000FACB48: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x394>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 000000FACB4C: CA100080 08060080
	s_and_saveexec_b32 s3, s2                                  // 000000FACB54: BE832002
	s_cbranch_execz 10                                         // 000000FACB58: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x184>
	v_lshlrev_b32_e32 v6, 1, v30                               // 000000FACB5C: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FACB60: BF870091
	.long 0xd7006a06                                           // 000000FACB64: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000FACB68: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 000000FACB6C: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 000000FACB74: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000FACB7C: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 000000FACB80: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s3                              // 000000FACB84: 8C7E037E
	v_or_b32_e32 v6, 32, v30                                   // 000000FACB88: 380C3CA0
	s_mov_b32 s2, exec_lo                                      // 000000FACB8C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FACB90: BF870001
	.long 0xd4c4007e                                           // 000000FACB94: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000FACB98: 02020C14
	s_cbranch_execz 10                                         // 000000FACB9C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x1c8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000FACBA0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FACBA4: BF870091
	.long 0xd7006a08                                           // 000000FACBA8: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000FACBAC: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 000000FACBB0: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 000000FACBB8: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 000000FACBC0: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 000000FACBC4: 7E101706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000FACBC8: 8C7E027E
	v_or_b32_e32 v6, 64, v30                                   // 000000FACBCC: 380C3CC0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 000000FACBD0: CA100080 0A080080
	s_mov_b32 s2, exec_lo                                      // 000000FACBD8: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FACBDC: BF870002
	.long 0xd4c4007e                                           // 000000FACBE0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000FACBE4: 02020C14
	s_cbranch_execz 10                                         // 000000FACBE8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x214>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000FACBEC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FACBF0: BF870091
	.long 0xd7006a0b                                           // 000000FACBF4: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000FACBF8: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 000000FACBFC: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 000000FACC04: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 000000FACC0C: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 000000FACC10: 7E121706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000FACC14: 8C7E027E
	v_or_b32_e32 v6, 0x60, v30                                 // 000000FACC18: 380C3CFF 00000060
	s_mov_b32 s2, exec_lo                                      // 000000FACC20: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FACC24: BF870001
	.long 0xd4c4007e                                           // 000000FACC28: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000FACC2C: 02020C14
	s_cbranch_execz 10                                         // 000000FACC30: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x25c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000FACC34: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FACC38: BF870091
	.long 0xd7006a0a                                           // 000000FACC3C: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000FACC40: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 000000FACC44: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 000000FACC4C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 000000FACC54: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 000000FACC58: 7E141706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000FACC5C: 8C7E027E
	v_or_b32_e32 v6, 0x80, v30                                 // 000000FACC60: 380C3CFF 00000080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 000000FACC68: CA100080 0C0A0080
	s_mov_b32 s2, exec_lo                                      // 000000FACC70: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FACC74: BF870002
	.long 0xd4c4007e                                           // 000000FACC78: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000FACC7C: 02020C14
	s_cbranch_execz 10                                         // 000000FACC80: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x2ac>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000FACC84: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FACC88: BF870091
	.long 0xd7006a0d                                           // 000000FACC8C: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000FACC90: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 000000FACC94: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 000000FACC9C: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 000000FACCA4: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 000000FACCA8: 7E161706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000FACCAC: 8C7E027E
	v_or_b32_e32 v6, 0xa0, v30                                 // 000000FACCB0: 380C3CFF 000000A0
	s_mov_b32 s2, exec_lo                                      // 000000FACCB8: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FACCBC: BF870001
	.long 0xd4c4007e                                           // 000000FACCC0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000FACCC4: 02020C14
	s_cbranch_execz 10                                         // 000000FACCC8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x2f4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000FACCCC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FACCD0: BF870091
	.long 0xd7006a0c                                           // 000000FACCD4: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000FACCD8: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 000000FACCDC: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 000000FACCE4: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 000000FACCEC: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 000000FACCF0: 7E181706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000FACCF4: 8C7E027E
	v_or_b32_e32 v6, 0xc0, v30                                 // 000000FACCF8: 380C3CFF 000000C0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 000000FACD00: CA100080 0E0C0080
	s_mov_b32 s2, exec_lo                                      // 000000FACD08: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FACD0C: BF870002
	.long 0xd4c4007e                                           // 000000FACD10: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000FACD14: 02020C14
	s_cbranch_execz 10                                         // 000000FACD18: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x344>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000FACD1C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FACD20: BF870091
	.long 0xd7006a0f                                           // 000000FACD24: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000FACD28: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 000000FACD2C: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 000000FACD34: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 000000FACD3C: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 000000FACD40: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000FACD44: 8C7E027E
	v_or_b32_e32 v6, 0xe0, v30                                 // 000000FACD48: 380C3CFF 000000E0
	s_mov_b32 s2, exec_lo                                      // 000000FACD50: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FACD54: BF870001
	.long 0xd4c4007e                                           // 000000FACD58: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000FACD5C: 02020C14
	s_cbranch_execz 10                                         // 000000FACD60: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x38c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000FACD64: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FACD68: BF870091
	.long 0xd7006a0e                                           // 000000FACD6C: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000FACD70: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 000000FACD74: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 000000FACD7C: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 000000FACD84: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 000000FACD88: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000FACD8C: 8C7E027E
	s_branch 9                                                 // 000000FACD90: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_mov_b32_e32 v7, 0                                        // 000000FACD94: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FACD98: BF870001
	v_mov_b32_e32 v8, v7                                       // 000000FACD9C: 7E100307
	v_mov_b32_e32 v9, v7                                       // 000000FACDA0: 7E120307
	v_mov_b32_e32 v10, v7                                      // 000000FACDA4: 7E140307
	v_mov_b32_e32 v11, v7                                      // 000000FACDA8: 7E160307
	v_mov_b32_e32 v12, v7                                      // 000000FACDAC: 7E180307
	v_mov_b32_e32 v13, v7                                      // 000000FACDB0: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 000000FACDB4: 7E1C0307
	s_add_u32 s2, s4, s14                                      // 000000FACDB8: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000FACDBC: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 000000FACDC0: 850E9F0B
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 000000FACDC4: CA100080 13140080
	s_add_u32 s14, s10, s14                                    // 000000FACDCC: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000FACDD0: 820F800B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v22, 0             // 000000FACDD4: CA100080 1F160080
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000FACDDC: 868E810E
	v_cndmask_b32_e64 v32, 0, 1, s18                           // 000000FACDE0: D5010020 00490280
	v_mad_u64_u32 v[25:26], null, v2, s14, s[2:3]              // 000000FACDE8: D6FE7C19 00081D02
	.long 0xd72c0002                                           // 000000FACDF0: D72C0002
	v_cndmask_b32_e32 v0, v2, v15, vcc_lo                      // 000000FACDF4: 02001F02
	.long 0xd72c0005                                           // 000000FACDF8: D72C0005
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 000000FACDFC: 02001D05
	.long 0xd4440002                                           // 000000FACE00: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 000000FACE04: 02023C14
	v_mov_b32_e32 v43, 0                                       // 000000FACE08: 7E560280
	v_mov_b32_e32 v21, 0                                       // 000000FACE0C: 7E2A0280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000FACE10: BF870004
	v_add3_u32 v33, v5, v26, v2                                // 000000FACE14: D6550021 040A3505
	s_and_saveexec_b32 s3, s2                                  // 000000FACE1C: BE832002
	s_cbranch_execz 21                                         // 000000FACE20: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_dual_mov_b32 v43, 0 :: v_dual_lshlrev_b32 v2, 4, v30     // 000000FACE24: CA220080 2B023C84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FACE2C: BF870091
	.long 0xd7006a05                                           // 000000FACE30: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 000000FACE34: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 000000FACE38: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 000000FACE40: 916A127E
	global_load_b128 v[19:22], v[5:6], off                     // 000000FACE44: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 000000FACE4C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 1, v30                               // 000000FACE50: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FACE54: BF870091
	.long 0xd7006a02                                           // 000000FACE58: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 000000FACE5C: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 000000FACE60: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 000000FACE68: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000FACE70: BF8903F7
	v_cvt_f32_f16_e32 v43, v2                                  // 000000FACE74: 7E561702
	s_or_b32 exec_lo, exec_lo, s3                              // 000000FACE78: 8C7E037E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 000000FACE7C: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 000000FACE84: CA100080 24240080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 000000FACE8C: CA100080 26260080
	s_and_saveexec_b32 s3, s2                                  // 000000FACE94: BE832002
	s_cbranch_execz 627                                        // 000000FACE98: BFA50273 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xe68>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 000000FACE9C: CA220080 1B023C81
	.long 0xd7006a00                                           // 000000FACEA4: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000FACEA8: 02020010
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FACEAC: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000FACEB0: D5207C01 01AA0211
	v_dual_mov_b32 v41, v30 :: v_dual_lshlrev_b32 v26, 5, v30  // 000000FACEB8: CA22011E 291A3C85
	.long 0xd7006a00                                           // 000000FACEC0: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 000000FACEC4: 02020500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FACEC8: BF8701A1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000FACECC: D5207C01 01AA0280
	v_lshl_or_b32 v40, v30, 4, 0x200                           // 000000FACED4: D6560028 03FD091E 00000200
	.long 0xd7006a00                                           // 000000FACEE0: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 000000FACEE4: 02020004
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FACEE8: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 000000FACEEC: D5207C01 01AA0205
	v_mov_b32_e32 v39, v27                                     // 000000FACEF4: 7E4E031B
	.long 0xd7006a1c                                           // 000000FACEF8: D7006A1C
	v_cndmask_b32_e32 v0, v0, v192, vcc_lo                     // 000000FACEFC: 02018100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FACF00: BF870001
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 000000FACF04: D5207C1D 01AA0280
	v_mov_b32_e32 v38, v27                                     // 000000FACF0C: 7E4C031B
	v_mov_b32_e32 v37, v27                                     // 000000FACF10: 7E4A031B
	v_mov_b32_e32 v36, v27                                     // 000000FACF14: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 000000FACF18: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 000000FACF1C: 7E44031B
	v_mov_b32_e32 v31, v27                                     // 000000FACF20: 7E3E031B
	v_mov_b32_e32 v42, v43                                     // 000000FACF24: 7E54032B
	s_mul_i32 s2, s11, 6                                       // 000000FACF28: 9602860B
	s_mul_hi_u32 s18, s10, 6                                   // 000000FACF2C: 9692860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000FACF30: 848E820A
	s_add_i32 s18, s18, s2                                     // 000000FACF34: 81120212
	s_mul_i32 s17, s10, 6                                      // 000000FACF38: 9611860A
	s_mov_b32 s16, 0                                           // 000000FACF3C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000FACF40: 8484810A
	s_branch 555                                               // 000000FACF44: BFA0022B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xdf4>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000FACF48: 8C7E0A7E
	v_cndmask_b32_e64 v53, v43, v7, s1                         // 000000FACF4C: D5010035 00060F2B
	v_cndmask_b32_e64 v1, v8, v9, s1                           // 000000FACF54: D5010001 00061308
	v_cndmask_b32_e64 v0, v7, v8, s1                           // 000000FACF5C: D5010000 00061107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 000000FACF64: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s1                         // 000000FACF70: D5010006 00061D0D
	v_cndmask_b32_e64 v5, v12, v13, s1                         // 000000FACF78: D5010005 00061B0C
	v_cndmask_b32_e64 v4, v11, v12, s1                         // 000000FACF80: D5010004 0006190B
	v_cndmask_b32_e64 v3, v10, v11, s1                         // 000000FACF88: D5010003 0006170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000FACF90: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s1                          // 000000FACF94: D5010002 00061509
	v_add_nc_u32_e32 v40, 0x200, v40                           // 000000FACF9C: 4A5050FF 00000200
	s_and_b32 s2, exec_lo, s2                                  // 000000FACFA4: 8B02027E
	ds_load_b32 v14, v8                                        // 000000FACFA8: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 000000FACFB0: 32102686
	s_or_b32 s16, s2, s16                                      // 000000FACFB4: 8C101002
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FACFB8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FACFBC: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 000000FACFC4: D8D80000 36000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 000000FACFCC: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FACFD0: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 000000FACFD8: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 000000FACFE0: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FACFE4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FACFE8: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 000000FACFF0: D8D80000 38000008
	v_and_b32_e32 v8, 0xff, v20                                // 000000FACFF8: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000FAD000: 30101082
	ds_load_b32 v57, v8                                        // 000000FAD004: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 000000FAD00C: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FAD010: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FAD014: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 000000FAD01C: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 000000FAD024: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FAD028: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 000000FAD030: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 000000FAD038: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FAD03C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FAD040: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 000000FAD048: D8D80000 3C000008
	v_and_b32_e32 v8, 0xff, v21                                // 000000FAD050: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000FAD058: 30101082
	ds_load_b32 v61, v8                                        // 000000FAD05C: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 000000FAD064: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FAD068: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FAD06C: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 000000FAD074: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 000000FAD07C: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FAD080: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 000000FAD088: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 000000FAD090: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FAD094: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FAD098: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 000000FAD0A0: D8D80000 40000008
	v_and_b32_e32 v8, 0xff, v22                                // 000000FAD0A8: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000FAD0B0: 30101082
	ds_load_b32 v65, v8                                        // 000000FAD0B4: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 000000FAD0BC: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FAD0C0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FAD0C4: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 000000FAD0CC: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 000000FAD0D4: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FAD0D8: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 000000FAD0E0: D8D80000 43000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 000000FAD0E8: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000FAD0EC: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FAD0F0: 361010FF 000003FC
	ds_load_b32 v68, v8                                        // 000000FAD0F8: D8D80000 44000008
	.long 0xd73c0008                                           // 000000FAD100: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 000000FAD104: 02023481
	v_add_nc_u32_e32 v26, 0x400, v26                           // 000000FAD108: 4A3434FF 00000400
	.long 0xd7006a0c                                           // 000000FAD110: D7006A0C
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 000000FAD114: 02021006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FAD118: BF870001
	v_add_co_ci_u32_e64 v13, null, s7, v9, vcc_lo              // 000000FAD11C: D5207C0D 01AA1207
	s_clause 0x3                                               // 000000FAD124: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000FAD128: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000FAD130: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 000000FAD138: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 000000FAD140: DC5E0030 2F7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000FAD148: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000FAD14C: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 000000FAD154: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD158: BF8700A1
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 000000FAD15C: CC1A4008 1C226D09
	s_waitcnt lgkmcnt(13)                                      // 000000FAD164: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 000000FAD168: CC1A4008 1C226F0A
	s_waitcnt lgkmcnt(12)                                      // 000000FAD170: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD174: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 000000FAD178: CC1A4008 1C22710B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000FAD180: BF8908B7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 000000FAD184: CC1A4008 1C227313
	s_waitcnt lgkmcnt(10)                                      // 000000FAD18C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD190: BF8700A1
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 000000FAD194: CC1A4008 1C227514
	s_waitcnt lgkmcnt(9)                                       // 000000FAD19C: BF89FC97
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 000000FAD1A0: CC1A4008 1C227715
	s_waitcnt lgkmcnt(8)                                       // 000000FAD1A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD1AC: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 000000FAD1B0: CC1A4008 1C227916
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000FAD1B8: BF890477
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000FAD1BC: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(6)                                       // 000000FAD1C4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD1C8: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000FAD1CC: CC1A4008 1C227D2C
	s_waitcnt lgkmcnt(5)                                       // 000000FAD1D4: BF89FC57
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000FAD1D8: CC1A4008 1C227F2D
	s_waitcnt lgkmcnt(4)                                       // 000000FAD1E0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD1E4: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000FAD1E8: CC1A4008 1C22812E
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000FAD1F0: BF890037
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000FAD1F4: CC1A4008 1C22832F
	.long 0xd7006a2f                                           // 000000FAD1FC: D7006A2F
	v_cndmask_b32_e32 v0, v12, v4, vcc_lo                      // 000000FAD200: 0200090C
	s_waitcnt lgkmcnt(2)                                       // 000000FAD204: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000FAD208: BF8701C2
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000FAD20C: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v48, null, s5, v13, vcc_lo             // 000000FAD214: D5207C30 01AA1A05
	.long 0xd7006a33                                           // 000000FAD21C: D7006A33
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 000000FAD220: 02001D0C
	s_waitcnt lgkmcnt(1)                                       // 000000FAD224: BF89FC17
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000FAD228: CC1A4008 1C228731
	v_add_co_ci_u32_e64 v52, null, s15, v13, vcc_lo            // 000000FAD230: D5207C34 01AA1A0F
	.long 0xd7006a0c                                           // 000000FAD238: D7006A0C
	v_cndmask_b32_e32 v0, v12, v17, vcc_lo                     // 000000FAD23C: 0200230C
	s_waitcnt lgkmcnt(0)                                       // 000000FAD240: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FAD244: BF870123
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 000000FAD248: CC1A4008 1C228932
	v_add_co_ci_u32_e64 v13, null, s18, v13, vcc_lo            // 000000FAD250: D5207C0D 01AA1A12
	v_fmac_f32_e32 v39, v53, v8                                // 000000FAD258: 564E1135
	s_clause 0x3                                               // 000000FAD25C: BF850003
	global_load_b128 v[8:11], v[47:48], off                    // 000000FAD260: DC5E0000 087C002F
	global_load_b128 v[19:22], v[47:48], off offset:16         // 000000FAD268: DC5E0010 137C002F
	global_load_b128 v[43:46], v[47:48], off offset:32         // 000000FAD270: DC5E0020 2B7C002F
	global_load_b128 v[47:50], v[47:48], off offset:48         // 000000FAD278: DC5E0030 2F7C002F
	s_waitcnt vmcnt(3)                                         // 000000FAD280: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000FAD284: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD28C: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 000000FAD290: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 000000FAD298: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD2A0: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 000000FAD2A4: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 000000FAD2AC: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 000000FAD2B0: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD2B8: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 000000FAD2BC: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 000000FAD2C4: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD2CC: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 000000FAD2D0: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 000000FAD2D8: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000FAD2DC: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD2E4: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000FAD2E8: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000FAD2F0: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD2F8: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000FAD2FC: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 000000FAD304: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000FAD308: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD310: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000FAD314: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000FAD31C: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD324: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 000000FAD328: CC1A4008 1C228932
	v_fmac_f32_e32 v38, v53, v8                                // 000000FAD330: 564C1135
	s_clause 0x3                                               // 000000FAD334: BF850003
	global_load_b128 v[8:11], v[51:52], off                    // 000000FAD338: DC5E0000 087C0033
	global_load_b128 v[19:22], v[51:52], off offset:16         // 000000FAD340: DC5E0010 137C0033
	global_load_b128 v[43:46], v[51:52], off offset:32         // 000000FAD348: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[51:52], off offset:48         // 000000FAD350: DC5E0030 2F7C0033
	.long 0xd7006a33                                           // 000000FAD358: D7006A33
	v_cndmask_b32_e32 v0, v51, v14, vcc_lo                     // 000000FAD35C: 02001D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FAD360: BF8700B1
	v_add_co_ci_u32_e64 v52, null, s15, v52, vcc_lo            // 000000FAD364: D5207C34 01AA680F
	s_waitcnt vmcnt(3)                                         // 000000FAD36C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000FAD370: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 000000FAD378: CC1A4008 1C226D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD380: BF870091
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 000000FAD384: CC1A4008 1C226F0A
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 000000FAD38C: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 000000FAD394: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD398: BF870091
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 000000FAD39C: CC1A4008 1C227313
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 000000FAD3A4: CC1A4008 1C227514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD3AC: BF870091
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 000000FAD3B0: CC1A4008 1C227715
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 000000FAD3B8: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 000000FAD3C0: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD3C4: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000FAD3C8: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000FAD3D0: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD3D8: BF870091
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000FAD3DC: CC1A4008 1C227F2D
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000FAD3E4: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 000000FAD3EC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD3F0: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000FAD3F4: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000FAD3FC: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD404: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000FAD408: CC1A4008 1C228731
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 000000FAD410: CC1A4008 1C228932
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FAD418: BF870001
	v_fmac_f32_e32 v37, v53, v8                                // 000000FAD41C: 564A1135
	s_clause 0x3                                               // 000000FAD420: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000FAD424: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000FAD42C: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 000000FAD434: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 000000FAD43C: DC5E0030 2F7C000C
	.long 0xd7006a0c                                           // 000000FAD444: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 000000FAD448: 02001D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FAD44C: BF8700B1
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 000000FAD450: D5207C0D 01AA1A0F
	s_waitcnt vmcnt(3)                                         // 000000FAD458: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000FAD45C: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 000000FAD464: CC1A4008 1C226D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD46C: BF870091
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 000000FAD470: CC1A4008 1C226F0A
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 000000FAD478: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 000000FAD480: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD484: BF870091
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 000000FAD488: CC1A4008 1C227313
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 000000FAD490: CC1A4008 1C227514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD498: BF870091
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 000000FAD49C: CC1A4008 1C227715
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 000000FAD4A4: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 000000FAD4AC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD4B0: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000FAD4B4: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000FAD4BC: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD4C4: BF870091
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000FAD4C8: CC1A4008 1C227F2D
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000FAD4D0: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 000000FAD4D8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD4DC: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000FAD4E0: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000FAD4E8: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD4F0: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000FAD4F4: CC1A4008 1C228731
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 000000FAD4FC: CC1A4008 1C228932
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FAD504: BF870001
	v_fmac_f32_e32 v36, v53, v8                                // 000000FAD508: 56481135
	s_clause 0x3                                               // 000000FAD50C: BF850003
	global_load_b128 v[8:11], v[51:52], off                    // 000000FAD510: DC5E0000 087C0033
	global_load_b128 v[19:22], v[51:52], off offset:16         // 000000FAD518: DC5E0010 137C0033
	global_load_b128 v[43:46], v[51:52], off offset:32         // 000000FAD520: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[51:52], off offset:48         // 000000FAD528: DC5E0030 2F7C0033
	s_waitcnt vmcnt(3)                                         // 000000FAD530: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000FAD534: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD53C: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 000000FAD540: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 000000FAD548: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD550: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 000000FAD554: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 000000FAD55C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 000000FAD560: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD568: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 000000FAD56C: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 000000FAD574: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD57C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 000000FAD580: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 000000FAD588: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000FAD58C: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD594: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000FAD598: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000FAD5A0: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD5A8: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000FAD5AC: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 000000FAD5B4: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000FAD5B8: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD5C0: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000FAD5C4: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000FAD5CC: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD5D4: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 000000FAD5D8: CC1A4008 1C228932
	v_fmac_f32_e32 v35, v53, v8                                // 000000FAD5E0: 56461135
	s_clause 0x3                                               // 000000FAD5E4: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000FAD5E8: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000FAD5F0: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 000000FAD5F8: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 000000FAD600: DC5E0030 2F7C000C
	.long 0xd7006a0c                                           // 000000FAD608: D7006A0C
	v_cndmask_b32_e32 v0, v51, v14, vcc_lo                     // 000000FAD60C: 02001D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD610: BF8700A1
	v_add_co_ci_u32_e64 v13, null, s15, v52, vcc_lo            // 000000FAD614: D5207C0D 01AA680F
	.long 0xd7006a1c                                           // 000000FAD61C: D7006A1C
	v_cndmask_b32_e32 v0, v28, v192, vcc_lo                    // 000000FAD620: 0201811C
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 000000FAD624: D5207C1D 01AA3A80
	s_waitcnt vmcnt(3)                                         // 000000FAD62C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000FAD630: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD638: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 000000FAD63C: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 000000FAD644: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD64C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 000000FAD650: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 000000FAD658: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 000000FAD65C: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD664: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 000000FAD668: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 000000FAD670: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD678: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 000000FAD67C: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 000000FAD684: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000FAD688: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD690: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000FAD694: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000FAD69C: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD6A4: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000FAD6A8: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 000000FAD6B0: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000FAD6B4: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD6BC: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000FAD6C0: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000FAD6C8: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD6D0: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 000000FAD6D4: CC1A4008 1C228932
	v_fmac_f32_e32 v34, v53, v8                                // 000000FAD6DC: 56441135
	s_clause 0x3                                               // 000000FAD6E0: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000FAD6E4: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000FAD6EC: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 000000FAD6F4: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 000000FAD6FC: DC5E0030 2F7C000C
	s_waitcnt vmcnt(3)                                         // 000000FAD704: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000FAD708: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD710: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 000000FAD714: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 000000FAD71C: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD724: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 000000FAD728: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 000000FAD730: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 000000FAD734: CC1A4008 1C227313
	v_mov_b32_e32 v19, v15                                     // 000000FAD73C: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FAD740: BF870122
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 000000FAD744: CC1A4008 1C227514
	v_mov_b32_e32 v20, v16                                     // 000000FAD74C: 7E280310
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 000000FAD750: CC1A4008 1C227715
	v_mov_b32_e32 v21, v17                                     // 000000FAD758: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000FAD75C: BF870132
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 000000FAD760: CC1A4008 1C227916
	v_mov_b32_e32 v22, v18                                     // 000000FAD768: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 000000FAD76C: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000FAD770: CC1A4008 1C227B2B
	v_mov_b32_e32 v43, v42                                     // 000000FAD778: 7E56032A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD77C: BF870092
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000FAD780: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000FAD788: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD790: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000FAD794: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 000000FAD79C: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000FAD7A0: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD7A8: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000FAD7AC: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000FAD7B4: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAD7BC: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 000000FAD7C0: CC1A4008 1C228932
	v_dual_fmac_f32 v31, v53, v8 :: v_dual_mov_b32 v14, v7     // 000000FAD7C8: C8101135 1F0E0107
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 000000FAD7D0: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 000000FAD7D8: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 000000FAD7E0: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 000000FAD7E8: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000FAD7EC: 917E107E
	s_cbranch_execz 28                                         // 000000FAD7F0: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xe64>
	s_waitcnt vmcnt(0)                                         // 000000FAD7F4: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v41, 32, v41  // 000000FAD7F8: CA200114 102852A0
	v_dual_mov_b32 v15, v19 :: v_dual_mov_b32 v18, v22         // 000000FAD800: CA100113 0F120116
	v_mov_b32_e32 v17, v21                                     // 000000FAD808: 7E220315
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FAD80C: BF870003
	.long 0xd4430002                                           // 000000FAD810: D4430002
	v_cndmask_b32_e32 v1, s20, v41, vcc_lo                     // 000000FAD814: 02025214
	s_mov_b32 s10, exec_lo                                     // 000000FAD818: BE8A007E
	.long 0xd4c4007e                                           // 000000FAD81C: D4C4007E
	v_cndmask_b32_e32 v1, s20, v41, vcc_lo                     // 000000FAD820: 02025214
	s_cbranch_execz 64968                                      // 000000FAD824: BFA5FDC8 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x548>
	.long 0xd7006a00                                           // 000000FAD828: D7006A00
	v_cndmask_b32_e32 v1, v25, v40, vcc_lo                     // 000000FAD82C: 02025119
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FAD830: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 000000FAD834: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v32                            // 000000FAD83C: 7C9A4081
	v_mov_b32_e32 v42, v43                                     // 000000FAD840: 7E54032B
	global_load_b128 v[15:18], v[0:1], off                     // 000000FAD844: DC5E0000 0F7C0000
	s_cbranch_vccnz 64958                                      // 000000FAD84C: BFA4FDBE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x548>
	global_load_d16_b16 v0, v[28:29], off                      // 000000FAD850: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 000000FAD858: BF8903F7
	v_cvt_f32_f16_e32 v42, v0                                  // 000000FAD85C: 7E541700
	s_branch 64953                                             // 000000FAD860: BFA0FDB9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x548>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000FAD864: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAD868: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000FAD86C: 8C7E037E
	.long 0xd71f0000                                           // 000000FAD870: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000FAD874: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000FAD878: 3A020090
	v_xor_b32_e32 v8, 8, v0                                    // 000000FAD87C: 3A100088
	v_xor_b32_e32 v15, 4, v0                                   // 000000FAD880: 3A1E0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000FAD884: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000FAD888: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000FAD88C: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000FAD890: 7C9810A0
	v_cndmask_b32_e32 v8, v0, v8, vcc_lo                       // 000000FAD894: 02101100
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 000000FAD898: 7C981EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FAD89C: BF870002
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000FAD8A0: 30101082
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000FAD8A4: 30020282
	ds_bpermute_b32 v2, v1, v39                                // 000000FAD8A8: DACC0000 02002701
	s_waitcnt lgkmcnt(0)                                       // 000000FAD8B0: BF89FC07
	v_add_f32_e32 v2, v39, v2                                  // 000000FAD8B4: 06040527
	ds_bpermute_b32 v4, v1, v37                                // 000000FAD8B8: DACC0000 04002501
	ds_bpermute_b32 v5, v1, v36                                // 000000FAD8C0: DACC0000 05002401
	ds_bpermute_b32 v3, v1, v38                                // 000000FAD8C8: DACC0000 03002601
	ds_bpermute_b32 v6, v1, v35                                // 000000FAD8D0: DACC0000 06002301
	ds_bpermute_b32 v7, v1, v34                                // 000000FAD8D8: DACC0000 07002201
	ds_bpermute_b32 v1, v1, v31                                // 000000FAD8E0: DACC0000 01001F01
	ds_bpermute_b32 v9, v8, v2                                 // 000000FAD8E8: DACC0000 09000208
	s_waitcnt lgkmcnt(6)                                       // 000000FAD8F0: BF89FC67
	v_dual_cndmask_b32 v15, v0, v15 :: v_dual_add_f32 v4, v37, v4// 000000FAD8F4: CA481F00 0F040925
	s_waitcnt lgkmcnt(5)                                       // 000000FAD8FC: BF89FC57
	v_add_f32_e32 v5, v36, v5                                  // 000000FAD900: 060A0B24
	s_waitcnt lgkmcnt(3)                                       // 000000FAD904: BF89FC37
	v_dual_add_f32 v3, v38, v3 :: v_dual_add_f32 v6, v35, v6   // 000000FAD908: C9080726 03060D23
	s_waitcnt lgkmcnt(2)                                       // 000000FAD910: BF89FC27
	v_add_f32_e32 v7, v34, v7                                  // 000000FAD914: 060E0F22
	ds_bpermute_b32 v11, v8, v4                                // 000000FAD918: DACC0000 0B000408
	s_waitcnt lgkmcnt(2)                                       // 000000FAD920: BF89FC27
	v_add_f32_e32 v1, v31, v1                                  // 000000FAD924: 0602031F
	ds_bpermute_b32 v10, v8, v3                                // 000000FAD928: DACC0000 0A000308
	ds_bpermute_b32 v12, v8, v5                                // 000000FAD930: DACC0000 0C000508
	ds_bpermute_b32 v13, v8, v6                                // 000000FAD938: DACC0000 0D000608
	ds_bpermute_b32 v14, v8, v7                                // 000000FAD940: DACC0000 0E000708
	s_waitcnt lgkmcnt(5)                                       // 000000FAD948: BF89FC57
	v_dual_add_f32 v2, v2, v9 :: v_dual_lshlrev_b32 v15, 2, v15// 000000FAD94C: C9221302 020E1E82
	s_waitcnt lgkmcnt(4)                                       // 000000FAD954: BF89FC47
	v_add_f32_e32 v4, v4, v11                                  // 000000FAD958: 06081704
	ds_bpermute_b32 v8, v8, v1                                 // 000000FAD95C: DACC0000 08000108
	s_waitcnt lgkmcnt(0)                                       // 000000FAD964: BF89FC07
	v_dual_add_f32 v6, v6, v13 :: v_dual_add_f32 v1, v1, v8    // 000000FAD968: C9081B06 06001101
	ds_bpermute_b32 v8, v15, v2                                // 000000FAD970: DACC0000 0800020F
	v_add_f32_e32 v3, v3, v10                                  // 000000FAD978: 06061503
	ds_bpermute_b32 v10, v15, v4                               // 000000FAD97C: DACC0000 0A00040F
	v_add_f32_e32 v5, v5, v12                                  // 000000FAD984: 060A1905
	ds_bpermute_b32 v12, v15, v6                               // 000000FAD988: DACC0000 0C00060F
	v_add_f32_e32 v7, v7, v14                                  // 000000FAD990: 060E1D07
	ds_bpermute_b32 v14, v15, v1                               // 000000FAD994: DACC0000 0E00010F
	s_waitcnt lgkmcnt(3)                                       // 000000FAD99C: BF89FC37
	v_add_f32_e32 v2, v2, v8                                   // 000000FAD9A0: 06041102
	ds_bpermute_b32 v9, v15, v3                                // 000000FAD9A4: DACC0000 0900030F
	s_waitcnt lgkmcnt(3)                                       // 000000FAD9AC: BF89FC37
	v_add_f32_e32 v4, v4, v10                                  // 000000FAD9B0: 06081504
	ds_bpermute_b32 v11, v15, v5                               // 000000FAD9B4: DACC0000 0B00050F
	s_waitcnt lgkmcnt(3)                                       // 000000FAD9BC: BF89FC37
	v_add_f32_e32 v6, v6, v12                                  // 000000FAD9C0: 060C1906
	ds_bpermute_b32 v13, v15, v7                               // 000000FAD9C4: DACC0000 0D00070F
	v_xor_b32_e32 v15, 2, v0                                   // 000000FAD9CC: 3A1E0082
	v_xor_b32_e32 v8, 1, v0                                    // 000000FAD9D0: 3A100081
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FAD9D4: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 000000FAD9D8: 7C981EA0
	v_cndmask_b32_e32 v15, v0, v15, vcc_lo                     // 000000FAD9DC: 021E1F00
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000FAD9E0: 7C9810A0
	s_waitcnt lgkmcnt(2)                                       // 000000FAD9E4: BF89FC27
	v_dual_add_f32 v3, v3, v9 :: v_dual_cndmask_b32 v0, v0, v8 // 000000FAD9E8: C9121303 03001100
	s_waitcnt lgkmcnt(1)                                       // 000000FAD9F0: BF89FC17
	v_add_f32_e32 v5, v5, v11                                  // 000000FAD9F4: 060A1705
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 000000FAD9F8: 7C943C80
	s_waitcnt lgkmcnt(0)                                       // 000000FAD9FC: BF89FC07
	v_dual_add_f32 v7, v7, v13 :: v_dual_lshlrev_b32 v16, 2, v0// 000000FADA00: C9221B07 07100082
	v_lshlrev_b32_e32 v15, 2, v15                              // 000000FADA08: 301E1E82
	s_and_b32 s0, vcc_lo, s0                                   // 000000FADA0C: 8B00006A
	ds_bpermute_b32 v10, v15, v4                               // 000000FADA10: DACC0000 0A00040F
	s_waitcnt lgkmcnt(0)                                       // 000000FADA18: BF89FC07
	v_add_f32_e32 v10, v4, v10                                 // 000000FADA1C: 06141504
	v_add_f32_e32 v11, v1, v14                                 // 000000FADA20: 06161D01
	ds_bpermute_b32 v1, v15, v2                                // 000000FADA24: DACC0000 0100020F
	s_waitcnt lgkmcnt(0)                                       // 000000FADA2C: BF89FC07
	v_add_f32_e32 v8, v2, v1                                   // 000000FADA30: 06100302
	ds_bpermute_b32 v13, v15, v6                               // 000000FADA34: DACC0000 0D00060F
	ds_bpermute_b32 v9, v15, v3                                // 000000FADA3C: DACC0000 0900030F
	ds_bpermute_b32 v14, v15, v7                               // 000000FADA44: DACC0000 0E00070F
	s_waitcnt lgkmcnt(2)                                       // 000000FADA4C: BF89FC27
	v_add_f32_e32 v0, v6, v13                                  // 000000FADA50: 06001B06
	ds_bpermute_b32 v12, v15, v5                               // 000000FADA54: DACC0000 0C00050F
	ds_bpermute_b32 v15, v15, v11                              // 000000FADA5C: DACC0000 0F000B0F
	s_waitcnt lgkmcnt(3)                                       // 000000FADA64: BF89FC37
	v_add_f32_e32 v9, v3, v9                                   // 000000FADA68: 06121303
	ds_bpermute_b32 v13, v16, v10                              // 000000FADA6C: DACC0000 0D000A10
	ds_bpermute_b32 v4, v16, v0                                // 000000FADA74: DACC0000 04000010
	s_waitcnt lgkmcnt(4)                                       // 000000FADA7C: BF89FC47
	v_add_f32_e32 v2, v7, v14                                  // 000000FADA80: 06041D07
	ds_bpermute_b32 v6, v16, v2                                // 000000FADA84: DACC0000 06000210
	s_waitcnt lgkmcnt(4)                                       // 000000FADA8C: BF89FC47
	v_add_f32_e32 v1, v5, v12                                  // 000000FADA90: 06021905
	s_waitcnt lgkmcnt(3)                                       // 000000FADA94: BF89FC37
	v_add_f32_e32 v3, v11, v15                                 // 000000FADA98: 06061F0B
	ds_bpermute_b32 v11, v16, v8                               // 000000FADA9C: DACC0000 0B000810
	ds_bpermute_b32 v12, v16, v9                               // 000000FADAA4: DACC0000 0C000910
	ds_bpermute_b32 v5, v16, v1                                // 000000FADAAC: DACC0000 05000110
	ds_bpermute_b32 v7, v16, v3                                // 000000FADAB4: DACC0000 07000310
	s_and_saveexec_b32 s1, s0                                  // 000000FADABC: BE812000
	s_cbranch_execz 242                                        // 000000FADAC0: BFA500F2 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x148c>
	s_waitcnt lgkmcnt(2)                                       // 000000FADAC4: BF89FC27
	v_dual_add_f32 v8, v8, v11 :: v_dual_add_f32 v9, v9, v12   // 000000FADAC8: C9081708 08081909
	s_waitcnt lgkmcnt(0)                                       // 000000FADAD0: BF89FC07
	v_dual_add_f32 v10, v10, v13 :: v_dual_add_f32 v3, v3, v7  // 000000FADAD4: C9081B0A 0A020F03
	s_lshl_b64 s[2:3], s[12:13], 2                             // 000000FADADC: 8482820C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FADAE0: BF870112
	v_dual_mul_f32 v8, 0xbfb8aa3b, v8 :: v_dual_mul_f32 v9, 0xbfb8aa3b, v9// 000000FADAE4: C8C610FF 080812FF BFB8AA3B
	v_dual_mul_f32 v10, 0xbfb8aa3b, v10 :: v_dual_add_f32 v5, v1, v5// 000000FADAF0: C8C814FF 0A040B01 BFB8AA3B
	v_add_f32_e32 v2, v2, v6                                   // 000000FADAFC: 06040D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FADB00: BF870193
	v_exp_f32_e32 v8, v8                                       // 000000FADB04: 7E104B08
	v_exp_f32_e32 v9, v9                                       // 000000FADB08: 7E124B09
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000FADB0C: BF8701D2
	v_exp_f32_e32 v10, v10                                     // 000000FADB10: 7E144B0A
	v_dual_mul_f32 v5, 0xbfb8aa3b, v5 :: v_dual_add_f32 v4, v0, v4// 000000FADB14: C8C80AFF 05040900 BFB8AA3B
	.long 0xd73c0000                                           // 000000FADB20: D73C0000
	v_cndmask_b32_e32 v1, 2, v23, vcc_lo                       // 000000FADB24: 02022E82
	s_lshl_b64 s[4:5], s[12:13], 3                             // 000000FADB28: 8484830C
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 000000FADB2C: 100606FF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 000000FADB34: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000FADB38: BF870317
	v_dual_add_f32 v6, 1.0, v8 :: v_dual_add_f32 v7, 1.0, v9   // 000000FADB3C: C90810F2 060612F2
	v_add_f32_e32 v8, 1.0, v10                                 // 000000FADB44: 061014F2
	.long 0xd7006a00                                           // 000000FADB48: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000FADB4C: 02020008
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000FADB50: BF870213
	v_div_scale_f32 v9, null, v6, v6, 1.0                      // 000000FADB54: D6FC7C09 03CA0D06
	v_div_scale_f32 v10, null, v7, v7, 1.0                     // 000000FADB5C: D6FC7C0A 03CA0F07
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000FADB64: D5207C01 01AA0209
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000FADB6C: BF870005
	v_add_f32_e32 v5, 1.0, v5                                  // 000000FADB70: 060A0AF2
	v_div_scale_f32 v11, null, v8, v8, 1.0                     // 000000FADB74: D6FC7C0B 03CA1108
	v_rcp_f32_e32 v12, v9                                      // 000000FADB7C: 7E185509
	v_rcp_f32_e32 v13, v10                                     // 000000FADB80: 7E1A550A
	v_div_scale_f32 v17, vcc_lo, 1.0, v6, 1.0                  // 000000FADB84: D6FC6A11 03CA0CF2
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 000000FADB8C: 100404FF BFB8AA3B
	v_rcp_f32_e32 v14, v11                                     // 000000FADB94: 7E1C550B
	v_exp_f32_e32 v16, v3                                      // 000000FADB98: 7E204B03
	v_div_scale_f32 v18, s0, 1.0, v7, 1.0                      // 000000FADB9C: D6FC0012 03CA0EF2
	s_waitcnt vmcnt(0)                                         // 000000FADBA4: BF8903F7
	v_div_scale_f32 v21, null, v5, v5, 1.0                     // 000000FADBA8: D6FC7C15 03CA0B05
	v_exp_f32_e32 v15, v2                                      // 000000FADBB0: 7E1E4B02
	v_div_scale_f32 v20, s1, 1.0, v8, 1.0                      // 000000FADBB4: D6FC0114 03CA10F2
	v_fma_f32 v2, -v9, v12, 1.0                                // 000000FADBBC: D6130002 23CA1909
	v_fma_f32 v3, -v10, v13, 1.0                               // 000000FADBC4: D6130003 23CA1B0A
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 000000FADBCC: 100808FF BFB8AA3B
	v_rcp_f32_e32 v24, v21                                     // 000000FADBD4: 7E305515
	v_fma_f32 v19, -v11, v14, 1.0                              // 000000FADBD8: D6130013 23CA1D0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FADBE0: BF870193
	v_dual_fmac_f32 v12, v2, v12 :: v_dual_fmac_f32 v13, v3, v13// 000000FADBE4: C8001902 0C0C1B03
	v_exp_f32_e32 v4, v4                                       // 000000FADBEC: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_3) | instid1(VALU_DEP_2)   // 000000FADBF0: BF870107
	v_dual_add_f32 v15, 1.0, v15 :: v_dual_fmac_f32 v14, v19, v14// 000000FADBF4: C9001EF2 0F0E1D13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FADBFC: BF8700A2
	v_mul_f32_e32 v19, v17, v12                                // 000000FADC00: 10261911
	.long 0xd7000202                                           // 000000FADC04: D7000202
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 000000FADC08: 02000500
	v_add_co_ci_u32_e64 v3, null, s3, v1, s2                   // 000000FADC0C: D5207C03 000A0203
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000FADC14: BF870293
	v_fma_f32 v25, -v9, v19, v17                               // 000000FADC18: D6130019 24462709
	v_dual_mul_f32 v22, v18, v13 :: v_dual_add_f32 v23, 1.0, v4// 000000FADC20: C8C81B12 161608F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FADC28: BF870112
	v_fmac_f32_e32 v19, v25, v12                               // 000000FADC2C: 56261919
	v_fma_f32 v26, -v10, v22, v18                              // 000000FADC30: D613001A 244A2D0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FADC38: BF870193
	v_div_scale_f32 v25, null, v23, v23, 1.0                   // 000000FADC3C: D6FC7C19 03CA2F17
	v_fma_f32 v9, -v9, v19, v17                                // 000000FADC44: D6130009 24462709
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000FADC4C: BF870233
	v_fmac_f32_e32 v22, v26, v13                               // 000000FADC50: 562C1B1A
	v_fma_f32 v26, -v21, v24, 1.0                              // 000000FADC54: D613001A 23CA3115
	v_div_scale_f32 v17, s2, 1.0, v5, 1.0                      // 000000FADC5C: D6FC0211 03CA0AF2
	v_div_fmas_f32 v9, v9, v12, v19                            // 000000FADC64: D6370009 044E1909
	s_delay_alu instid0(VALU_DEP_4)                            // 000000FADC6C: BF870004
	v_fma_f32 v10, -v10, v22, v18                              // 000000FADC70: D613000A 244A2D0A
	v_rcp_f32_e32 v18, v25                                     // 000000FADC78: 7E245519
	s_mov_b32 vcc_lo, s0                                       // 000000FADC7C: BEEA0000
	v_div_scale_f32 v12, null, v15, v15, 1.0                   // 000000FADC80: D6FC7C0C 03CA1F0F
	v_div_fixup_f32 v6, v9, v6, 1.0                            // 000000FADC88: D6270006 03CA0D09
	v_div_fmas_f32 v10, v10, v13, v22                          // 000000FADC90: D637000A 045A1B0A
	s_mov_b32 vcc_lo, s1                                       // 000000FADC98: BEEA0001
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FADC9C: BF870003
	v_rcp_f32_e32 v9, v12                                      // 000000FADCA0: 7E12550C
	global_store_b32 v[0:1], v6, off                           // 000000FADCA4: DC6A0000 007C0600
	v_div_fixup_f32 v7, v10, v7, 1.0                           // 000000FADCAC: D6270007 03CA0F0A
	v_fma_f32 v6, -v25, v18, 1.0                               // 000000FADCB4: D6130006 23CA2519
	global_store_b32 v[2:3], v7, off                           // 000000FADCBC: DC6A0000 007C0702
	v_fmac_f32_e32 v18, v6, v18                                // 000000FADCC4: 56242506
	v_div_scale_f32 v6, s0, 1.0, v23, 1.0                      // 000000FADCC8: D6FC0006 03CA2EF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FADCD0: BF870091
	v_dual_add_f32 v16, 1.0, v16 :: v_dual_mul_f32 v7, v6, v18 // 000000FADCD4: C90620F2 10062506
	v_div_scale_f32 v10, null, v16, v16, 1.0                   // 000000FADCDC: D6FC7C0A 03CA2110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000FADCE4: BF870291
	v_rcp_f32_e32 v13, v10                                     // 000000FADCE8: 7E1A550A
	v_fma_f32 v3, -v10, v13, 1.0                               // 000000FADCEC: D6130003 23CA1B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FADCF4: BF8700A1
	v_dual_fmac_f32 v24, v26, v24 :: v_dual_fmac_f32 v13, v3, v13// 000000FADCF8: C800311A 180C1B03
	v_mul_f32_e32 v4, v20, v14                                 // 000000FADD00: 10081D14
	v_fma_f32 v27, -v11, v4, v20                               // 000000FADD04: D613001B 2452090B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FADD0C: BF870091
	v_fmac_f32_e32 v4, v27, v14                                // 000000FADD10: 56081D1B
	v_fma_f32 v11, -v11, v4, v20                               // 000000FADD14: D613000B 2452090B
	v_div_scale_f32 v20, s3, 1.0, v16, 1.0                     // 000000FADD1C: D6FC0314 03CA20F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000FADD24: BF870242
	v_div_fmas_f32 v4, v11, v14, v4                            // 000000FADD28: D6370004 04121D0B
	v_mul_f32_e32 v11, v17, v24                                // 000000FADD30: 10163111
	v_fma_f32 v14, -v12, v9, 1.0                               // 000000FADD34: D613000E 23CA130C
	.long 0xd7006a03                                           // 000000FADD3C: D7006A03
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000FADD40: 02000900
	v_div_fixup_f32 v19, v4, v8, 1.0                           // 000000FADD44: D6270013 03CA1104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000FADD4C: BF870214
	v_fma_f32 v2, -v21, v11, v17                               // 000000FADD50: D6130002 24461715
	v_fmac_f32_e32 v9, v14, v9                                 // 000000FADD58: 5612130E
	v_div_scale_f32 v8, s1, 1.0, v15, 1.0                      // 000000FADD5C: D6FC0108 03CA1EF2
	v_add_co_ci_u32_e64 v4, null, s5, v1, vcc_lo               // 000000FADD64: D5207C04 01AA0205
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000FADD6C: BF870224
	v_fmac_f32_e32 v11, v2, v24                                // 000000FADD70: 56163102
	v_fma_f32 v2, -v25, v7, v6                                 // 000000FADD74: D6130002 241A0F19
	v_mul_f32_e32 v14, v8, v9                                  // 000000FADD7C: 101C1308
	v_mad_u64_u32 v[0:1], null, s12, 12, v[0:1]                // 000000FADD80: D6FE7C00 0401180C
	s_mov_b32 vcc_lo, s2                                       // 000000FADD88: BEEA0002
	v_fma_f32 v17, -v21, v11, v17                              // 000000FADD8C: D6130011 24461715
	v_mul_f32_e32 v21, v20, v13                                // 000000FADD94: 102A1B14
	v_fmac_f32_e32 v7, v2, v18                                 // 000000FADD98: 560E2502
	v_fma_f32 v2, -v12, v14, v8                                // 000000FADD9C: D6130002 24221D0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000FADDA4: BF870214
	v_div_fmas_f32 v11, v17, v24, v11                          // 000000FADDA8: D637000B 042E3111
	v_fma_f32 v17, -v10, v21, v20                              // 000000FADDB0: D6130011 24522B0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000FADDB8: BF870214
	v_fma_f32 v6, -v25, v7, v6                                 // 000000FADDBC: D6130006 241A0F19
	v_fmac_f32_e32 v14, v2, v9                                 // 000000FADDC4: 561C1302
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 000000FADDC8: D6FE7C01 0405180D
	s_mov_b32 vcc_lo, s0                                       // 000000FADDD0: BEEA0000
	v_fmac_f32_e32 v21, v17, v13                               // 000000FADDD4: 562A1B11
	v_div_fmas_f32 v6, v6, v18, v7                             // 000000FADDD8: D6370006 041E2506
	v_fma_f32 v2, -v12, v14, v8                                // 000000FADDE0: D6130002 24221D0C
	s_mov_b32 vcc_lo, s1                                       // 000000FADDE8: BEEA0001
	v_div_fixup_f32 v11, v11, v5, 1.0                          // 000000FADDEC: D627000B 03CA0B0B
	v_fma_f32 v7, -v10, v21, v20                               // 000000FADDF4: D6130007 24522B0A
	v_div_fixup_f32 v12, v6, v23, 1.0                          // 000000FADDFC: D627000C 03CA2F06
	v_div_fmas_f32 v2, v2, v9, v14                             // 000000FADE04: D6370002 043A1302
	.long 0xd7006a05                                           // 000000FADE0C: D7006A05
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 000000FADE10: 02000903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000FADE14: BF8700D1
	v_add_co_ci_u32_e64 v6, null, s5, v4, vcc_lo               // 000000FADE18: D5207C06 01AA0805
	s_mov_b32 vcc_lo, s3                                       // 000000FADE20: BEEA0003
	v_div_fixup_f32 v2, v2, v15, 1.0                           // 000000FADE24: D6270002 03CA1F02
	v_div_fmas_f32 v9, v7, v13, v21                            // 000000FADE2C: D6370009 04561B07
	.long 0xd7006a07                                           // 000000FADE34: D7006A07
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000FADE38: 02000900
	v_add_co_ci_u32_e64 v8, null, s5, v1, vcc_lo               // 000000FADE3C: D5207C08 01AA0205
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FADE44: BF8700A3
	v_div_fixup_f32 v13, v9, v16, 1.0                          // 000000FADE48: D627000D 03CA2109
	.long 0xd7006a09                                           // 000000FADE50: D7006A09
	v_cndmask_b32_e32 v0, v5, v4, vcc_lo                       // 000000FADE54: 02000905
	v_add_co_ci_u32_e64 v10, null, s5, v6, vcc_lo              // 000000FADE58: D5207C0A 01AA0C05
	s_clause 0x4                                               // 000000FADE60: BF850004
	global_store_b32 v[3:4], v19, off                          // 000000FADE64: DC6A0000 007C1303
	global_store_b32 v[0:1], v11, off                          // 000000FADE6C: DC6A0000 007C0B00
	global_store_b32 v[5:6], v12, off                          // 000000FADE74: DC6A0000 007C0C05
	global_store_b32 v[7:8], v2, off                           // 000000FADE7C: DC6A0000 007C0207
	global_store_b32 v[9:10], v13, off                         // 000000FADE84: DC6A0000 007C0D09
	s_endpgm                                                   // 000000FADE8C: BFB00000
		...

