000000000091b300 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi():
	s_clause 0x1                                               // 00000091B300: BF850001
	s_load_b32 s3, s[0:1], 0x88                                // 00000091B304: F40000C0 F8000088
	s_load_b512 s[12:27], s[0:1], null                         // 00000091B30C: F4100300 F8000000
	s_mov_b32 s4, -1                                           // 00000091B314: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 00000091B318: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 00000091B31C: BF040302
	s_cbranch_scc1 2673                                        // 00000091B320: BFA20A71 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x29e8>
	s_load_b64 s[8:9], s[0:1], 0x7c                            // 00000091B324: F4040200 F800007C
	s_sub_i32 s28, s2, s3                                      // 00000091B32C: 819C0302
	s_clause 0x1                                               // 00000091B330: BF850001
	s_load_b256 s[44:51], s[0:1], 0x60                         // 00000091B334: F40C0B00 F8000060
	s_load_b256 s[36:43], s[0:1], 0x40                         // 00000091B33C: F40C0900 F8000040
	v_lshrrev_b32_e32 v19, 5, v0                               // 00000091B344: 32260085
	v_and_b32_e32 v20, 31, v0                                  // 00000091B348: 3628009F
	s_mov_b32 s34, 0                                           // 00000091B34C: BEA20080
	s_mov_b32 s33, exec_lo                                     // 00000091B350: BEA1007E
	s_waitcnt lgkmcnt(0)                                       // 00000091B354: BF89FC07
	s_abs_i32 s4, s9                                           // 00000091B358: BE841509
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 00000091B35C: BF870529
	s_cvt_f32_u32 s5, s4                                       // 00000091B360: BE856504
	s_sub_i32 s6, 0, s4                                        // 00000091B364: 81860480
	v_rcp_iflag_f32_e32 v1, s5                                 // 00000091B368: 7E025605
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_3)// 00000091B36C: BF8705A5
	v_readfirstlane_b32 s5, v1                                 // 00000091B370: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 00000091B374: A205FF05 4F7FFFFE
	s_cvt_u32_f32 s5, s5                                       // 00000091B37C: BE856705
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000091B380: BF87049B
	s_mul_i32 s6, s6, s5                                       // 00000091B384: 96060506
	s_mul_hi_u32 s6, s5, s6                                    // 00000091B388: 96860605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000091B38C: BF8704B9
	s_add_i32 s5, s5, s6                                       // 00000091B390: 81050605
	s_ashr_i32 s6, s9, 31                                      // 00000091B394: 86069F09
	s_mul_hi_u32 s3, s28, s5                                   // 00000091B398: 9683051C
	s_mul_i32 s5, s3, s4                                       // 00000091B39C: 96050403
	s_add_i32 s7, s3, 1                                        // 00000091B3A0: 81078103
	s_sub_i32 s5, s28, s5                                      // 00000091B3A4: 8185051C
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000091B3A8: BF870009
	s_sub_i32 s10, s5, s4                                      // 00000091B3AC: 818A0405
	s_cmp_ge_u32 s5, s4                                        // 00000091B3B0: BF090405
	s_cselect_b32 s3, s7, s3                                   // 00000091B3B4: 98030307
	s_cselect_b32 s5, s10, s5                                  // 00000091B3B8: 9805050A
	s_add_i32 s7, s3, 1                                        // 00000091B3BC: 81078103
	s_cmp_ge_u32 s5, s4                                        // 00000091B3C0: BF090405
	s_cselect_b32 s3, s7, s3                                   // 00000091B3C4: 98030307
	s_ashr_i32 s11, s50, 31                                    // 00000091B3C8: 860B9F32
	s_xor_b32 s3, s3, s6                                       // 00000091B3CC: 8D030603
	s_lshr_b32 s0, s11, 25                                     // 00000091B3D0: 8500990B
	s_sub_i32 s10, s3, s6                                      // 00000091B3D4: 818A0603
	s_add_i32 s0, s50, s0                                      // 00000091B3D8: 81000032
	s_mul_i32 s30, s10, s9                                     // 00000091B3DC: 961E090A
	s_ashr_i32 s0, s0, 7                                       // 00000091B3E0: 86008700
	s_sub_i32 s29, s28, s30                                    // 00000091B3E4: 819D1E1C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000091B3E8: BF870499
	s_mul_i32 s29, s29, s8                                     // 00000091B3EC: 961D081D
	s_add_i32 s1, s29, s8                                      // 00000091B3F0: 8101081D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000091B3F4: BF870499
	s_min_i32 s0, s0, s1                                       // 00000091B3F8: 89000100
	s_sub_i32 s35, s0, s29                                     // 00000091B3FC: 81A31D00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000091B400: BF870499
	s_lshl_b32 s31, s35, 2                                     // 00000091B404: 841F8223
	.long 0xd4c4007e                                           // 00000091B408: D4C4007E
	v_cndmask_b32_e32 v1, s31, v19, vcc_lo                     // 00000091B40C: 0202261F
	s_cbranch_execz 503                                        // 00000091B410: BFA501F7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x8f0>
	s_add_i32 s51, s48, -1                                     // 00000091B414: 8133C130
	s_cmp_lg_u64 s[40:41], 0                                   // 00000091B418: BF118028
	v_dual_mov_b32 v8, v19 :: v_dual_and_b32 v1, 1, v0         // 00000091B41C: CA240113 08000081
	s_cselect_b32 s52, -1, 0                                   // 00000091B424: 983480C1
	s_abs_i32 s53, s35                                         // 00000091B428: BEB51523
	v_and_b32_e32 v2, 2, v0                                    // 00000091B42C: 36040082
	s_cvt_f32_u32 s0, s53                                      // 00000091B430: BE806535
	v_lshlrev_b32_e32 v6, 3, v20                               // 00000091B434: 300C2883
	v_lshlrev_b32_e32 v7, 7, v19                               // 00000091B438: 300E2687
	v_and_b32_e32 v3, 4, v0                                    // 00000091B43C: 36060084
	v_rcp_iflag_f32_e32 v4, s0                                 // 00000091B440: 7E085600
	v_and_b32_e32 v5, 8, v0                                    // 00000091B444: 360A0088
	.long 0xd44a0001                                           // 00000091B448: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000091B44C: 02020280
	.long 0xd44a0003                                           // 00000091B450: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 00000091B454: 02020480
	v_lshl_or_b32 v1, v19, 8, v6                               // 00000091B458: D6560001 04191113
	v_lshl_add_u32 v2, s29, 7, v7                              // 00000091B460: D6460002 041D0E1D
	s_ashr_i32 s55, s35, 31                                    // 00000091B468: 86379F23
	s_sub_i32 s57, 0, s53                                      // 00000091B46C: 81B93580
	s_mul_i32 s8, s55, 0x1400                                  // 00000091B470: 9608FF37 00001400
	.long 0xd44c0000                                           // 00000091B478: D44C0000
	v_cndmask_b32_e32 v1, 16, v20, vcc_lo                      // 00000091B47C: 02022890
	v_readfirstlane_b32 s5, v4                                 // 00000091B480: 7E0A0504
	.long 0xd44a0004                                           // 00000091B484: D44A0004
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 00000091B488: 02020680
	v_subrev_nc_u32_e32 v9, s8, v1                             // 00000091B48C: 4E120208
	v_lshl_or_b32 v1, v20, 2, v2                               // 00000091B490: D6560001 04090514
	s_lshl_b32 s6, s35, 7                                      // 00000091B498: 84068723
	s_mul_f32 s7, s5, 0x4f7ffffe                               // 00000091B49C: A207FF05 4F7FFFFE
	.long 0xd44a0005                                           // 00000091B4A4: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 00000091B4A8: 02020A80
	s_mov_b32 s54, 0x76543210                                  // 00000091B4AC: BEB600FF 76543210
	s_lshl_b32 s56, s35, 8                                     // 00000091B4B4: 84388823
	s_cvt_u32_f32 s7, s7                                       // 00000091B4B8: BE876707
	s_mov_b32 s59, 0x3db504f3                                  // 00000091B4BC: BEBB00FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000091B4C4: BF87049A
	s_mul_i32 s57, s57, s7                                     // 00000091B4C8: 96390739
	s_mul_hi_u32 s8, s7, s57                                   // 00000091B4CC: 96883907
	s_sub_i32 s57, 0, s6                                       // 00000091B4D0: 81B90680
	s_add_i32 s58, s7, s8                                      // 00000091B4D4: 813A0807
	s_branch 164                                               // 00000091B4D8: BFA000A4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x46c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091B4DC: BF870091
	.long 0xd7006a02                                           // 00000091B4E0: D7006A02
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 00000091B4E4: 0202041A
	v_add_co_ci_u32_e64 v3, null, s27, v3, vcc_lo              // 00000091B4E8: D5207C03 01AA061B
	v_sub_f32_e32 v4, v15, v13                                 // 00000091B4F0: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 00000091B4F4: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 00000091B4FC: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 00000091B504: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 00000091B508: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 00000091B510: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 00000091B518: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091B51C: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 00000091B520: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 00000091B524: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 00000091B528: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000091B52C: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091B530: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091B534: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091B53C: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000091B544: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 00000091B54C: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000091B554: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 00000091B558: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091B55C: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 00000091B564: D5010007 20060F07
	.long 0xd72c0006                                           // 00000091B56C: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 00000091B570: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 00000091B578: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091B57C: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 00000091B584: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091B58C: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 00000091B590: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091B594: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000091B59C: D5010003 20060703
	.long 0xd72c0007                                           // 00000091B5A4: D72C0007
	v_cndmask_b32_e32 v1, s56, v10, vcc_lo                     // 00000091B5A8: 02021438
	v_add_f32_e32 v2, v2, v13                                  // 00000091B5AC: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091B5B0: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 00000091B5B8: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 00000091B5C0: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091B5C4: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091B5C8: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 00000091B5D0: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 00000091B5D8: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091B5DC: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 00000091B5E4: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091B5EC: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 00000091B5F4: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 00000091B5FC: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091B600: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 00000091B608: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 00000091B60C: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 00000091B614: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091B618: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 00000091B620: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091B628: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 00000091B630: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091B638: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 00000091B640: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 00000091B648: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 00000091B64C: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 00000091B650: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091B654: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 00000091B658: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091B65C: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 00000091B664: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000091B66C: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091B670: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 00000091B678: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 00000091B680: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091B684: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 00000091B68C: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 00000091B694: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 00000091B69C: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s31, v8                           // 00000091B6A0: 7C86101F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091B6A4: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 00000091B6A8: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 00000091B6B0: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000091B6B8: BF870234
	v_mov_b32_e32 v13, v2                                      // 00000091B6BC: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 00000091B6C0: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 00000091B6C8: D5010004 20020904
	v_permlanex16_b32 v11, v11, s54, 0xfedcba98                // 00000091B6D0: D65C000B 03FC6D0B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 00000091B6DC: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 00000091B6E0: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 00000091B6E8: D5010003 20020703
	v_permlanex16_b32 v10, v10, s54, 0xfedcba98                // 00000091B6F0: D65C000A 03FC6D0A FEDCBA98
	v_permlanex16_b32 v13, v13, s54, 0xfedcba98                // 00000091B6FC: D65C000D 03FC6D0D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 00000091B708: 060A1705
	v_permlanex16_b32 v12, v12, s54, 0xfedcba98                // 00000091B70C: D65C000C 03FC6D0C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091B718: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 00000091B71C: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 00000091B728: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091B72C: BF870214
	v_fma_mixhi_f16 v2, v5, s59, 0                             // 00000091B730: CC220002 02007705
	v_add_f32_e32 v10, v3, v12                                 // 00000091B738: 06141903
	s_or_b32 s34, vcc_lo, s34                                  // 00000091B73C: 8C22226A
	v_fma_mixlo_f16 v2, v4, s59, 0                             // 00000091B740: CC210002 02007704
	v_fma_mixhi_f16 v3, v7, s59, 0                             // 00000091B748: CC220003 02007707
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091B750: BF870003
	v_fma_mixlo_f16 v3, v10, s59, 0                            // 00000091B754: CC210003 0200770A
	ds_store_b64 v6, v[2:3]                                    // 00000091B75C: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s34                       // 00000091B764: 917E227E
	s_cbranch_execz 289                                        // 00000091B768: BFA50121 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x8f0>
	.long 0xd72d0002                                           // 00000091B76C: D72D0002
	v_cndmask_b32_e32 v0, v8, v58, vcc_lo                      // 00000091B770: 02007508
	s_mov_b32 s6, -1                                           // 00000091B774: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091B778: BF870091
	.long 0xd72c0003                                           // 00000091B77C: D72C0003
	v_cndmask_b32_e32 v0, v2, v53, vcc_lo                      // 00000091B780: 02006B02
	v_sub_nc_u32_e32 v3, v8, v3                                // 00000091B784: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000091B788: BF870121
	v_subrev_nc_u32_e32 v5, s53, v3                            // 00000091B78C: 4E0A0635
	v_cmp_le_u32_e32 vcc_lo, s53, v3                           // 00000091B790: 7C960635
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 00000091B794: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091B79C: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 00000091B7A0: 02040902
	v_cmp_le_u32_e32 vcc_lo, s53, v3                           // 00000091B7A4: 7C960635
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091B7A8: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000091B7AC: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 00000091B7B0: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s52                        // 00000091B7B4: 916A347E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091B7B8: BF870091
	v_xor_b32_e32 v11, s55, v2                                 // 00000091B7BC: 3A160437
	v_subrev_nc_u32_e32 v10, s55, v11                          // 00000091B7C0: 4E141637
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000091B7C4: BF8700A1
	v_mad_u64_u32 v[6:7], null, s57, v10, v[1:2]               // 00000091B7C8: D6FE7C06 04061439
	v_min_i32_e32 v2, s51, v10                                 // 00000091B7D0: 22041433
	v_mad_i64_i32 v[4:5], null, v2, s50, 0                     // 00000091B7D4: D6FF7C04 02006502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091B7DC: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 00000091B7E0: 340E0C9F
	.long 0xd73c0002                                           // 00000091B7E4: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000091B7E8: 02020C81
	s_cbranch_vccnz 212                                        // 00000091B7EC: BFA400D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x840>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091B7F0: BF870093
	.long 0xd7006a06                                           // 00000091B7F4: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 00000091B7F8: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 00000091B7FC: D5207C07 01AA0F05
	.long 0x7f3c3880                                           // 00000091B804: 7F3C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091B808: BF870112
	.long 0xd73c0006                                           // 00000091B80C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000091B810: 02020C81
	.long 0x7f42399e                                           // 00000091B814: 7F42399E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091B818: BF870092
	.long 0xd7006a0c                                           // 00000091B81C: D7006A0C
	v_cndmask_b32_e32 v1, s38, v6, vcc_lo                      // 00000091B820: 02020C26
	v_add_co_ci_u32_e64 v13, null, s39, v7, vcc_lo             // 00000091B824: D5207C0D 01AA0E27
	.long 0xd7006a06                                           // 00000091B82C: D7006A06
	v_cndmask_b32_e32 v1, s40, v6, vcc_lo                      // 00000091B830: 02020C28
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091B834: BF870001
	v_add_co_ci_u32_e64 v7, null, s41, v7, vcc_lo              // 00000091B838: D5207C07 01AA0E29
	global_load_b64 v[12:13], v[12:13], off                    // 00000091B840: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 00000091B848: D7006A0E
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 00000091B84C: 0202041A
	global_load_b64 v[6:7], v[6:7], off                        // 00000091B850: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s27, v3, vcc_lo             // 00000091B858: D5207C0F 01AA061B
	s_clause 0x1                                               // 00000091B860: BF850001
	global_load_b32 v16, v[14:15], off                         // 00000091B864: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 00000091B86C: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 00000091B874: BF890FF7
	.long 0x7e1e390c                                           // 00000091B878: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 00000091B87C: BF890BF7
	v_and_b32_e32 v40, 0xffff0000, v6                          // 00000091B880: 36500CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000091B888: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091B88C: BF870093
	v_lshlrev_b32_e32 v15, 16, v15                             // 00000091B890: 301E1E90
	v_mul_f32_e32 v21, 0xbfb8aa3b, v15                         // 00000091B894: 102A1EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000091B89C: BF870291
	v_exp_f32_e32 v21, v21                                     // 00000091B8A0: 7E2A4B15
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_and_b32 v12, 0xffff0000, v12// 00000091B8A4: C9242AF2 150C18FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091B8B0: BF870111
	v_mul_f32_e32 v18, 0xbfb8aa3b, v12                         // 00000091B8B4: 102418FF BFB8AA3B
	v_div_scale_f32 v25, null, v21, v21, v15                   // 00000091B8BC: D6FC7C19 043E2B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000091B8C4: BF8701B2
	v_exp_f32_e32 v18, v18                                     // 00000091B8C8: 7E244B12
	v_lshlrev_b32_e32 v17, 16, v13                             // 00000091B8CC: 30221A90
	v_div_scale_f32 v38, s7, v15, v21, v15                     // 00000091B8D0: D6FC0726 043E2B0F
	v_rcp_f32_e32 v29, v25                                     // 00000091B8D8: 7E3A5519
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091B8DC: BF870196
	v_add_f32_e32 v18, 1.0, v18                                // 00000091B8E0: 062424F2
	v_mul_f32_e32 v22, 0xbfb8aa3b, v17                         // 00000091B8E4: 102C22FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091B8EC: BF870195
	v_fma_f32 v37, -v25, v29, 1.0                              // 00000091B8F0: D6130025 23CA3B19
	v_div_scale_f32 v24, null, v18, v18, v12                   // 00000091B8F8: D6FC7C18 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000091B900: BF8701B3
	v_exp_f32_e32 v22, v22                                     // 00000091B904: 7E2C4B16
	v_and_b32_e32 v13, 0xffff0000, v13                         // 00000091B908: 361A1AFF FFFF0000
	v_div_scale_f32 v34, vcc_lo, v12, v18, v12                 // 00000091B910: D6FC6A22 0432250C
	v_rcp_f32_e32 v27, v24                                     // 00000091B918: 7E365518
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 00000091B91C: BF870106
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_mul_f32 v23, 0xbfb8aa3b, v13// 00000091B920: C9062CF2 16161AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091B92C: BF870115
	v_fma_f32 v35, -v24, v27, 1.0                              // 00000091B930: D6130023 23CA3718
	v_div_scale_f32 v26, null, v22, v22, v17                   // 00000091B938: D6FC7C1A 04462D16
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091B940: BF8701A3
	v_exp_f32_e32 v23, v23                                     // 00000091B944: 7E2E4B17
	v_div_scale_f32 v36, s6, v17, v22, v17                     // 00000091B948: D6FC0624 04462D11
	v_fmac_f32_e32 v27, v35, v27                               // 00000091B950: 56363723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000091B954: BF870313
	v_rcp_f32_e32 v31, v26                                     // 00000091B958: 7E3E551A
	v_add_f32_e32 v23, 1.0, v23                                // 00000091B95C: 062E2EF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091B960: BF870115
	v_fma_f32 v39, -v26, v31, 1.0                              // 00000091B964: D6130027 23CA3F1A
	v_div_scale_f32 v28, null, v23, v23, v13                   // 00000091B96C: D6FC7C1C 04362F17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091B974: BF8701A2
	v_fmac_f32_e32 v31, v39, v31                               // 00000091B978: 563E3F27
	v_mul_f32_e32 v39, v34, v27                                // 00000091B97C: 104E3722
	v_rcp_f32_e32 v32, v28                                     // 00000091B980: 7E40551C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091B984: BF870112
	v_mul_f32_e32 v41, v36, v31                                // 00000091B988: 10523F24
	v_fma_f32 v42, -v24, v39, v34                              // 00000091B98C: D613002A 248A4F18
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091B994: BF870112
	v_fma_f32 v45, -v26, v41, v36                              // 00000091B998: D613002D 2492531A
	v_fmac_f32_e32 v39, v42, v27                               // 00000091B9A0: 564E372A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091B9A4: BF870195
	v_fma_f32 v35, -v28, v32, 1.0                              // 00000091B9A8: D6130023 23CA411C
	v_fmac_f32_e32 v41, v45, v31                               // 00000091B9B0: 56523F2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091B9B4: BF870193
	v_fma_f32 v24, -v24, v39, v34                              // 00000091B9B8: D6130018 248A4F18
	v_fmac_f32_e32 v32, v35, v32                               // 00000091B9C0: 56404123
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091B9C4: BF870193
	v_fma_f32 v26, -v26, v41, v36                              // 00000091B9C8: D613001A 2492531A
	v_div_fmas_f32 v24, v24, v27, v39                          // 00000091B9D0: D6370018 049E3718
	s_mov_b32 vcc_lo, s7                                       // 00000091B9D8: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000091B9DC: BF870131
	v_div_fixup_f32 v12, v24, v18, v12                         // 00000091B9E0: D627000C 04322518
	v_fmac_f32_e32 v29, v37, v29                               // 00000091B9E8: 563A3B25
	v_div_scale_f32 v37, s8, v13, v23, v13                     // 00000091B9EC: D6FC0825 04362F0D
	v_dual_mul_f32 v12, v12, v40 :: v_dual_mul_f32 v35, v38, v29// 00000091B9F4: C8C6510C 0C223B26
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091B9FC: BF870112
	v_mul_f32_e32 v43, v37, v32                                // 00000091BA00: 10564125
	.long 0x7e3c398c                                           // 00000091BA04: 7E3C398C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091BA08: BF870193
	v_fma_f32 v44, -v25, v35, v38                              // 00000091BA0C: D613002C 249A4719
	v_fma_f32 v42, -v28, v43, v37                              // 00000091BA14: D613002A 2496571C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091BA1C: BF870112
	v_fmac_f32_e32 v35, v44, v29                               // 00000091BA20: 56463B2C
	v_fmac_f32_e32 v43, v42, v32                               // 00000091BA24: 5656412A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091BA28: BF870112
	v_fma_f32 v25, -v25, v35, v38                              // 00000091BA2C: D6130019 249A4719
	v_fma_f32 v24, -v28, v43, v37                              // 00000091BA34: D6130018 2496571C
	s_delay_alu instid0(VALU_DEP_2)                            // 00000091BA3C: BF870002
	v_div_fmas_f32 v25, v25, v29, v35                          // 00000091BA40: D6370019 048E3B19
	s_mov_b32 vcc_lo, s6                                       // 00000091BA48: BEEA0006
	s_mov_b32 s6, 0                                            // 00000091BA4C: BE860080
	v_div_fmas_f32 v18, v26, v31, v41                          // 00000091BA50: D6370012 04A63F1A
	s_mov_b32 vcc_lo, s8                                       // 00000091BA58: BEEA0008
	v_div_fixup_f32 v15, v25, v21, v15                         // 00000091BA5C: D627000F 043E2B19
	v_lshlrev_b32_e32 v21, 16, v7                              // 00000091BA64: 302A0E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 00000091BA68: 360E0EFF FFFF0000
	v_div_fixup_f32 v17, v18, v22, v17                         // 00000091BA70: D6270011 04462D12
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091BA78: BF8701A4
	v_mul_f32_e32 v6, v15, v6                                  // 00000091BA7C: 100C0D0F
	v_div_fmas_f32 v15, v24, v32, v43                          // 00000091BA80: D637000F 04AE4118
	v_mul_f32_e32 v17, v17, v21                                // 00000091BA88: 10222B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091BA8C: BF870193
	.long 0x7e423986                                           // 00000091BA90: 7E423986
	v_div_fixup_f32 v13, v15, v23, v13                         // 00000091BA94: D627000D 04362F0F
	v_and_b32_e32 v15, 1, v30                                  // 00000091BA9C: 361E3C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091BAA0: BF870214
	v_bfe_u32 v18, v17, 16, 1                                  // 00000091BAA4: D6100012 02052111
	v_and_b32_e32 v21, 1, v33                                  // 00000091BAAC: 362A4281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091BAB0: BF870214
	v_mul_f32_e32 v7, v13, v7                                  // 00000091BAB4: 100E0F0D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 00000091BAB8: D655000C 03FE1F0C 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091BAC4: BF870214
	v_add3_u32 v13, v17, v18, 0x7fff                           // 00000091BAC8: D655000D 03FE2511 00007FFF
	v_add3_u32 v6, v6, v21, 0x7fff                             // 00000091BAD4: D6550006 03FE2B06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091BAE0: BF870214
	v_bfe_u32 v15, v7, 16, 1                                   // 00000091BAE4: D610000F 02052107
	v_and_b32_e32 v12, 0xffff0000, v12                         // 00000091BAEC: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091BAF4: BF870214
	v_and_b32_e32 v17, 0xffff0000, v13                         // 00000091BAF8: 36221AFF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000091BB00: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091BB08: BF870004
	v_add3_u32 v7, v7, v15, 0x7fff                             // 00000091BB0C: D6550007 03FE1F07 00007FFF
	s_waitcnt vmcnt(1)                                         // 00000091BB18: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000091BB1C: CC20080D 8A021910
	s_waitcnt vmcnt(0)                                         // 00000091BB24: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 00000091BB28: CC20000C 8A02230E
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 00000091BB30: CC20000F 8A020D10
	v_and_b32_e32 v14, 0xffff0000, v7                          // 00000091BB38: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 00000091BB40: 916A067E
	s_cbranch_vccnz 65125                                      // 00000091BB44: BFA4FE65 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1dc>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091BB48: BF870093
	.long 0xd73c0004                                           // 00000091BB4C: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000091BB50: 02020881
	.long 0xd7006a04                                           // 00000091BB54: D7006A04
	v_cndmask_b32_e32 v1, s38, v4, vcc_lo                      // 00000091BB58: 02020826
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091BB5C: BF870111
	v_add_co_ci_u32_e64 v5, null, s39, v5, vcc_lo              // 00000091BB60: D5207C05 01AA0A27
	.long 0xd7006a04                                           // 00000091BB68: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 00000091BB6C: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000091BB70: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 00000091BB74: D5207C05 01AA0705
	.long 0xd7006a06                                           // 00000091BB7C: D7006A06
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 00000091BB80: 0202041A
	v_add_co_ci_u32_e64 v7, null, s27, v3, vcc_lo              // 00000091BB84: D5207C07 01AA061B
	global_load_b64 v[4:5], v[4:5], off                        // 00000091BB8C: DC560000 047C0004
	s_clause 0x1                                               // 00000091BB94: BF850001
	global_load_b32 v14, v[6:7], off                           // 00000091BB98: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 00000091BBA0: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 00000091BBA8: BF890BF7
	.long 0x7e0e3904                                           // 00000091BBAC: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000091BBB0: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 00000091BBB8: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091BBBC: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 00000091BBC0: 300E0E90
	s_waitcnt vmcnt(1)                                         // 00000091BBC4: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000091BBC8: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 00000091BBD0: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 00000091BBD4: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 00000091BBDC: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 00000091BBE4: 361C0AFF FFFF0000
	s_branch 65083                                             // 00000091BBEC: BFA0FE3B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1dc>
	s_or_b32 exec_lo, exec_lo, s33                             // 00000091BBF0: 8C7E217E
	s_bfe_i32 s34, s35, 0x1001c                                // 00000091BBF4: 93A2FF23 0001001C
	s_lshr_b32 s3, s11, 28                                     // 00000091BBFC: 85039C0B
	s_lshr_b64 s[0:1], s[34:35], 29                            // 00000091BC00: 85809D22
	s_add_i32 s3, s50, s3                                      // 00000091BC04: 81030332
	s_add_i32 s0, s0, 7                                        // 00000091BC08: 81008700
	s_lshl_b32 s1, s35, 3                                      // 00000091BC0C: 84018323
	s_ashr_i32 s0, s0, 3                                       // 00000091BC10: 86008300
	s_lshl_b32 s4, s29, 3                                      // 00000091BC14: 8404831D
	.long 0xd72c0001                                           // 00000091BC18: D72C0001
	v_cndmask_b32_e32 v1, s0, v19, vcc_lo                      // 00000091BC1C: 02022600
	v_lshlrev_b32_e32 v21, 2, v20                              // 00000091BC20: 302A2882
	s_waitcnt lgkmcnt(0)                                       // 00000091BC24: BF89FC07
	s_barrier                                                  // 00000091BC28: BFBD0000
	buffer_gl0_inv                                             // 00000091BC2C: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 00000091BC34: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 00000091BC38: 86008403
	s_ashr_i32 s3, s4, 31                                      // 00000091BC3C: 86039F04
	s_mul_hi_i32 s5, s10, s0                                   // 00000091BC40: 9705000A
	s_mul_i32 s0, s10, s0                                      // 00000091BC44: 9600000A
	v_min_i32_e32 v23, s1, v2                                  // 00000091BC48: 222E0401
	s_add_u32 s0, s0, s4                                       // 00000091BC4C: 80000400
	s_addc_u32 s1, s5, s3                                      // 00000091BC50: 82010305
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091BC54: BF870099
	s_lshl_b64 s[4:5], s[0:1], 10                              // 00000091BC58: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v23                           // 00000091BC5C: 7C822F01
	s_add_u32 s1, s24, s4                                      // 00000091BC60: 80010418
	s_addc_u32 s3, s25, s5                                     // 00000091BC64: 82030519
	s_and_saveexec_b32 s4, vcc_lo                              // 00000091BC68: BE84206A
	s_cbranch_execz 93                                         // 00000091BC6C: BFA5005D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0xae4>
	.long 0xd7010002                                           // 00000091BC70: D7010002
	v_cndmask_b32_e32 v0, v20, v129, vcc_lo                    // 00000091BC74: 02010314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000091BC78: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 00000091BC7C: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000091BC84: 3404029F
	.long 0xd44c0000                                           // 00000091BC88: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 00000091BC8C: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091BC90: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 00000091BC94: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 00000091BCA0: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091BCA8: BF870114
	.long 0xd73c0005                                           // 00000091BCAC: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000091BCB0: 0202028A
	.long 0xd73c0002                                           // 00000091BCB4: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000091BCB8: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091BCBC: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 00000091BCC0: 30080E98
	v_bfe_i32 v7, v7, 7, 1                                     // 00000091BCC4: D6110007 02050F07
	.long 0xd7000008                                           // 00000091BCCC: D7000008
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 00000091BCD0: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091BCD4: BF870211
	v_add_co_ci_u32_e64 v9, null, s3, v6, s0                   // 00000091BCD8: D5207C09 00020C03
	v_ashrrev_i32_e32 v6, 22, v4                               // 00000091BCE0: 340C0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091BCE4: BF870093
	.long 0xd7000004                                           // 00000091BCE8: D7000004
	v_cndmask_b32_e32 v1, v8, v2, vcc_lo                       // 00000091BCEC: 02020508
	v_add_co_ci_u32_e64 v5, null, v9, v3, s0                   // 00000091BCF0: D5207C05 00020709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091BCF8: BF870093
	.long 0xd7000006                                           // 00000091BCFC: D7000006
	v_cndmask_b32_e32 v1, v8, v6, vcc_lo                       // 00000091BD00: 02020D08
	v_add_co_ci_u32_e64 v7, null, v9, v7, s0                   // 00000091BD04: D5207C07 00020F09
	.long 0xd7000008                                           // 00000091BD0C: D7000008
	v_cndmask_b32_e32 v1, v8, v21, vcc_lo                      // 00000091BD10: 02022B08
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091BD14: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v9, s0                    // 00000091BD18: D5207C09 00021280
	s_clause 0x17                                              // 00000091BD20: BF850017
	global_load_b32 v2, v[4:5], off                            // 00000091BD24: DC520000 027C0004
	global_load_b32 v92, v[4:5], off offset:128                // 00000091BD2C: DC520080 5C7C0004
	global_load_b32 v89, v[4:5], off offset:256                // 00000091BD34: DC520100 597C0004
	global_load_b32 v86, v[4:5], off offset:384                // 00000091BD3C: DC520180 567C0004
	global_load_b32 v83, v[4:5], off offset:512                // 00000091BD44: DC520200 537C0004
	global_load_b32 v80, v[4:5], off offset:640                // 00000091BD4C: DC520280 507C0004
	global_load_b32 v77, v[4:5], off offset:768                // 00000091BD54: DC520300 4D7C0004
	global_load_b32 v59, v[4:5], off offset:896                // 00000091BD5C: DC520380 3B7C0004
	global_load_b32 v4, v[6:7], off                            // 00000091BD64: DC520000 047C0006
	global_load_b32 v93, v[6:7], off offset:128                // 00000091BD6C: DC520080 5D7C0006
	global_load_b32 v90, v[6:7], off offset:256                // 00000091BD74: DC520100 5A7C0006
	global_load_b32 v87, v[6:7], off offset:384                // 00000091BD7C: DC520180 577C0006
	global_load_b32 v84, v[6:7], off offset:512                // 00000091BD84: DC520200 547C0006
	global_load_b32 v81, v[6:7], off offset:640                // 00000091BD8C: DC520280 517C0006
	global_load_b32 v78, v[6:7], off offset:768                // 00000091BD94: DC520300 4E7C0006
	global_load_b32 v60, v[6:7], off offset:896                // 00000091BD9C: DC520380 3C7C0006
	global_load_b32 v3, v[8:9], off                            // 00000091BDA4: DC520000 037C0008
	global_load_b32 v91, v[8:9], off offset:128                // 00000091BDAC: DC520080 5B7C0008
	global_load_b32 v88, v[8:9], off offset:256                // 00000091BDB4: DC520100 587C0008
	global_load_b32 v85, v[8:9], off offset:384                // 00000091BDBC: DC520180 557C0008
	global_load_b32 v82, v[8:9], off offset:512                // 00000091BDC4: DC520200 527C0008
	global_load_b32 v79, v[8:9], off offset:640                // 00000091BDCC: DC520280 4F7C0008
	global_load_b32 v76, v[8:9], off offset:768                // 00000091BDD4: DC520300 4C7C0008
	global_load_b32 v58, v[8:9], off offset:896                // 00000091BDDC: DC520380 3A7C0008
	s_or_b32 exec_lo, exec_lo, s4                              // 00000091BDE4: 8C7E047E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v25, 0             // 00000091BDE8: CA100080 16180080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v27, 0             // 00000091BDF0: CA100080 181A0080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v31, 0             // 00000091BDF8: CA100080 1A1E0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v33, 0             // 00000091BE00: CA100080 1C200080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v35, 0             // 00000091BE08: CA100080 1E220080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v37, 0             // 00000091BE10: CA100080 20240080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v39, 0             // 00000091BE18: CA100080 22260080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v43, 0             // 00000091BE20: CA100080 242A0080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v45, 0             // 00000091BE28: CA100080 262C0080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v29, 0             // 00000091BE30: CA100080 281C0080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v49, 0             // 00000091BE38: CA100080 2A300080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v53, 0             // 00000091BE40: CA100080 2C340080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v47, 0             // 00000091BE48: CA100080 2E2E0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v41, 0             // 00000091BE50: CA100080 30280080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v51, 0             // 00000091BE58: CA100080 34320080
	v_mov_b32_e32 v50, 0                                       // 00000091BE60: 7E640280
	v_mov_b32_e32 v54, 0                                       // 00000091BE64: 7E6C0280
	s_ashr_i32 s11, s10, 31                                    // 00000091BE68: 860B9F0A
	s_and_saveexec_b32 s0, vcc_lo                              // 00000091BE6C: BE80206A
	s_cbranch_execz 1080                                       // 00000091BE70: BFA50438 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1c54>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v5, -1, v0      // 00000091BE74: CA200080 160400C1
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v55, 16, v0        // 00000091BE7C: CA240080 18360090
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v56, 2, v20    // 00000091BE84: CA220080 19382882
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000091BE8C: BF870123
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v5, 31, v5         // 00000091BE90: CA240080 1A040A9F
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 00000091BE98: CA100080 1B1C0080
	v_dual_mov_b32 v30, 0 :: v_dual_lshlrev_b32 v57, 2, v5     // 00000091BEA0: CA220080 1E380A82
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 00000091BEA8: CA100080 1F200080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 00000091BEB0: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 00000091BEB8: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 00000091BEC0: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 00000091BEC8: CA100080 27280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v43, 0             // 00000091BED0: CA100080 2A2A0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v45, 0             // 00000091BED8: CA100080 2C2C0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v29, 0             // 00000091BEE0: CA100080 2E1C0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v49, 0             // 00000091BEE8: CA100080 30300080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v53, 0             // 00000091BEF0: CA100080 34340080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v50, 0             // 00000091BEF8: CA100080 2F320080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v54, 0             // 00000091BF00: CA100080 29360080
	v_mov_b32_e32 v51, 0                                       // 00000091BF08: 7E660280
	s_mov_b32 s4, 0                                            // 00000091BF0C: BE840080
	s_movk_i32 s5, 0x1eee                                      // 00000091BF10: B0051EEE
	s_branch 980                                               // 00000091BF14: BFA003D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1b68>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000091BF18: 8C7E067E
	s_waitcnt vmcnt(15)                                        // 00000091BF1C: BF893FF7
	v_alignbit_b32 v2, v2, v4, 16                              // 00000091BF20: D6160002 02420902
	v_lshl_or_b32 v13, v1, 5, v55                              // 00000091BF28: D656000D 04DD0B01
	s_waitcnt vmcnt(7)                                         // 00000091BF30: BF891FF7
	v_bfe_u32 v14, v3, 12, 16                                  // 00000091BF34: D610000E 02411903
	v_bfe_u32 v15, v3, 8, 16                                   // 00000091BF3C: D610000F 02411103
	v_bfe_u32 v16, v3, 4, 16                                   // 00000091BF44: D6100010 02410903
	v_bfe_u32 v1, v2, 12, 16                                   // 00000091BF4C: D6100001 02411902
	v_bfe_u32 v5, v2, 8, 16                                    // 00000091BF54: D6100005 02411102
	.long 0xd72c000e                                           // 00000091BF5C: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 00000091BF60: 02021CFF 83DCD12D
	.long 0xd72c000f                                           // 00000091BF68: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 00000091BF6C: 02021EFF 83DCD12D
	v_alignbit_b32 v92, v92, v93, 16                           // 00000091BF74: D616005C 0242BB5C
	.long 0xd72c005f                                           // 00000091BF7C: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v1, vcc_lo               // 00000091BF80: 020202FF 83DCD12D
	.long 0xd72c0061                                           // 00000091BF88: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 00000091BF8C: 02020AFF 83DCD12D
	s_waitcnt vmcnt(6)                                         // 00000091BF94: BF891BF7
	v_bfe_u32 v100, v91, 4, 16                                 // 00000091BF98: D6100064 0241095B
	v_alignbit_b32 v89, v89, v90, 16                           // 00000091BFA0: D6160059 0242B559
	v_bfe_u32 v93, v92, 12, 16                                 // 00000091BFA8: D610005D 0241195C
	v_sad_u8 v14, v14, 0, 0x6400                               // 00000091BFB0: D622000E 03FD010E 00006400
	v_sad_u8 v99, v15, 0, 0x6400                               // 00000091BFBC: D6220063 03FD010F 00006400
	v_alignbit_b32 v86, v86, v87, 16                           // 00000091BFC8: D6160056 0242AF56
	v_sad_u8 v95, v95, 0, 0x6400                               // 00000091BFD0: D622005F 03FD015F 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 00000091BFDC: D6220061 03FD0161 00006400
	.long 0xd72c005d                                           // 00000091BFE8: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 00000091BFEC: 0202BAFF 83DCD12D
	v_bfe_u32 v90, v89, 12, 16                                 // 00000091BFF4: D610005A 02411959
	v_bfe_u32 v87, v86, 12, 16                                 // 00000091BFFC: D6100057 02411956
	v_and_b32_e32 v95, 0xffff, v95                             // 00000091C004: 36BEBEFF 0000FFFF
	v_alignbit_b32 v83, v83, v84, 16                           // 00000091C00C: D6160053 0242A953
	v_alignbit_b32 v80, v80, v81, 16                           // 00000091C014: D6160050 0242A350
	.long 0xd72c005a                                           // 00000091C01C: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 00000091C020: 0202B4FF 83DCD12D
	.long 0xd72c0057                                           // 00000091C028: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 00000091C02C: 0202AEFF 83DCD12D
	v_lshl_or_b32 v95, v97, 16, v95                            // 00000091C034: D656005F 057D2161
	.long 0xd72c0061                                           // 00000091C03C: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 00000091C040: 020220FF 83DCD12D
	v_sad_u8 v93, v93, 0, 0x6400                               // 00000091C048: D622005D 03FD015D 00006400
	v_bfe_u32 v84, v83, 12, 16                                 // 00000091C054: D6100054 02411953
	v_bfe_u32 v81, v80, 12, 16                                 // 00000091C05C: D6100051 02411950
	v_pk_fma_f16 v95, v95, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C064: CC0E005F 0BFC0B5F 0000C931
	v_and_b32_e32 v4, 0xffff, v2                               // 00000091C070: 360804FF 0000FFFF
	v_bfe_u32 v2, v2, 4, 16                                    // 00000091C078: D6100002 02410902
	v_sad_u8 v90, v90, 0, 0x6400                               // 00000091C080: D622005A 03FD015A 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 00000091C08C: D6220061 03FD0161 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 00000091C098: D6220057 03FD0157 00006400
	.long 0xd72c0060                                           // 00000091C0A4: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v4, vcc_lo               // 00000091C0A8: 020208FF 83DCD12D
	.long 0xd72c0062                                           // 00000091C0B0: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v2, vcc_lo               // 00000091C0B4: 020204FF 83DCD12D
	.long 0xd72c0054                                           // 00000091C0BC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 00000091C0C0: 0202A8FF 83DCD12D
	.long 0xd72c0051                                           // 00000091C0C8: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 00000091C0CC: 0202A2FF 83DCD12D
	v_alignbit_b32 v77, v77, v78, 16                           // 00000091C0D4: D616004D 02429D4D
	v_alignbit_b32 v59, v59, v60, 16                           // 00000091C0DC: D616003B 0242793B
	v_cmp_eq_u32_e32 vcc_lo, v17, v23                          // 00000091C0E4: 7C942F11
	v_and_b32_e32 v93, 0xffff, v93                             // 00000091C0E8: 36BABAFF 0000FFFF
	v_sad_u8 v96, v96, 0, 0x6400                               // 00000091C0F0: D6220060 03FD0160 00006400
	v_sad_u8 v98, v98, 0, 0x6400                               // 00000091C0FC: D6220062 03FD0162 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 00000091C108: D6220054 03FD0154 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 00000091C114: D6220051 03FD0151 00006400
	v_bfe_u32 v78, v77, 12, 16                                 // 00000091C120: D610004E 0241194D
	v_lshlrev_b32_e32 v96, 16, v96                             // 00000091C128: 30C0C090
	v_bfe_u32 v60, v59, 12, 16                                 // 00000091C12C: D610003C 0241193B
	s_or_b32 s4, vcc_lo, s4                                    // 00000091C134: 8C04046A
	v_and_b32_e32 v90, 0xffff, v90                             // 00000091C138: 36B4B4FF 0000FFFF
	.long 0xd72c004e                                           // 00000091C140: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 00000091C144: 02029CFF 83DCD12D
	v_and_or_b32 v96, 0xffff, v98, v96                         // 00000091C14C: D6570060 0582C4FF 0000FFFF
	.long 0xd72c003c                                           // 00000091C158: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 00000091C15C: 020278FF 83DCD12D
	v_and_b32_e32 v84, 0xffff, v84                             // 00000091C164: 36A8A8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091C16C: BF870003
	v_pk_fma_f16 v96, v96, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C170: CC0E0060 0BFC0B60 0000C931
	v_and_b32_e32 v94, 0xffff, v3                              // 00000091C17C: 36BC06FF 0000FFFF
	ds_load_b128 v[1:4], v13                                   // 00000091C184: DBFC0000 0100000D
	ds_load_b128 v[5:8], v13 offset:5120                       // 00000091C18C: DBFC1400 0500000D
	ds_load_b128 v[9:12], v13 offset:10240                     // 00000091C194: DBFC2800 0900000D
	v_and_b32_e32 v87, 0xffff, v87                             // 00000091C19C: 36AEAEFF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000091C1A4: D622004E 03FD014E 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000091C1B0: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091C1BC: BF870112
	v_and_b32_e32 v78, 0xffff, v78                             // 00000091C1C0: 369C9CFF 0000FFFF
	v_and_b32_e32 v60, 0xffff, v60                             // 00000091C1C8: 367878FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 00000091C1D0: BF89FC27
	v_dot2acc_f32_f16 v54, v95, v1                             // 00000091C1D4: 046C035F
	s_waitcnt lgkmcnt(1)                                       // 00000091C1D8: BF89FC17
	v_dot2acc_f32_f16 v51, v95, v5                             // 00000091C1DC: 04660B5F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000091C1E0: BF8700A1
	v_dot2acc_f32_f16 v51, v96, v6                             // 00000091C1E4: 04660D60
	.long 0xd72c005e                                           // 00000091C1E8: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 00000091C1EC: 0202BCFF 83DCD12D
	v_sad_u8 v94, v94, 0, 0x6400                               // 00000091C1F4: D622005E 03FD015E 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091C200: BF870091
	v_lshlrev_b32_e32 v94, 16, v94                             // 00000091C204: 30BCBC90
	v_and_or_b32 v94, 0xffff, v97, v94                         // 00000091C208: D657005E 057AC2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v54, v96, v2 :: v_dual_and_b32 v97, 0xffff, v92// 00000091C214: CB240560 3660B8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2)                            // 00000091C220: BF870002
	v_pk_fma_f16 v94, v94, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C224: CC0E005E 0BFC0B5E 0000C931
	v_and_b32_e32 v98, 0xffff, v14                             // 00000091C230: 36C41CFF 0000FFFF
	ds_load_b128 v[13:16], v13 offset:15360                    // 00000091C238: DBFC3C00 0D00000D
	.long 0xd72c0061                                           // 00000091C240: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 00000091C244: 0202C2FF 83DCD12D
	v_lshl_or_b32 v98, v99, 16, v98                            // 00000091C24C: D6560062 05892163
	v_bfe_u32 v99, v91, 8, 16                                  // 00000091C254: D6100063 0241115B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091C25C: BF870212
	v_pk_fma_f16 v98, v98, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C260: CC0E0062 0BFC0B62 0000C931
	v_sad_u8 v97, v97, 0, 0x6400                               // 00000091C26C: D6220061 03FD0161 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091C278: BF870113
	.long 0xd72c0063                                           // 00000091C27C: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 00000091C280: 0202C6FF 83DCD12D
	v_dual_dot2acc_f32_f16 v54, v98, v3 :: v_dual_lshlrev_b32 v97, 16, v97// 00000091C288: CB220762 3660C290
	v_dot2acc_f32_f16 v51, v98, v7                             // 00000091C290: 04660F62
	s_waitcnt lgkmcnt(0)                                       // 00000091C294: BF89FC07
	v_dot2acc_f32_f16 v41, v95, v13                            // 00000091C298: 04521B5F
	v_dot2acc_f32_f16 v50, v95, v9                             // 00000091C29C: 0464135F
	v_bfe_u32 v95, v92, 8, 16                                  // 00000091C2A0: D610005F 0241115C
	v_bfe_u32 v92, v92, 4, 16                                  // 00000091C2A8: D610005C 0241095C
	v_dot2acc_f32_f16 v51, v94, v8                             // 00000091C2B0: 0466115E
	v_dot2acc_f32_f16 v41, v96, v14                            // 00000091C2B4: 04521D60
	v_dot2acc_f32_f16 v50, v96, v10                            // 00000091C2B8: 04641560
	.long 0xd72c005f                                           // 00000091C2BC: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 00000091C2C0: 0202BEFF 83DCD12D
	v_bfe_u32 v96, v91, 12, 16                                 // 00000091C2C8: D6100060 0241195B
	.long 0xd72c005c                                           // 00000091C2D0: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 00000091C2D4: 0202B8FF 83DCD12D
	v_and_b32_e32 v91, 0xffff, v91                             // 00000091C2DC: 36B6B6FF 0000FFFF
	v_dot2acc_f32_f16 v50, v98, v11                            // 00000091C2E4: 04641762
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091C2E8: BF870224
	.long 0xd72c0060                                           // 00000091C2EC: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 00000091C2F0: 0202C0FF 83DCD12D
	v_sad_u8 v95, v95, 0, 0x6400                               // 00000091C2F8: D622005F 03FD015F 00006400
	.long 0xd72c005b                                           // 00000091C304: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 00000091C308: 0202B6FF 83DCD12D
	v_sad_u8 v92, v92, 0, 0x6400                               // 00000091C310: D622005C 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091C31C: BF8701A3
	v_lshl_or_b32 v93, v95, 16, v93                            // 00000091C320: D656005D 0575215F
	v_sad_u8 v96, v96, 0, 0x6400                               // 00000091C328: D6220060 03FD0160 00006400
	v_and_or_b32 v92, 0xffff, v92, v97                         // 00000091C334: D657005C 0586B8FF 0000FFFF
	v_sad_u8 v91, v91, 0, 0x6400                               // 00000091C340: D622005B 03FD015B 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091C34C: BF870004
	v_pk_fma_f16 v93, v93, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C350: CC0E005D 0BFC0B5D 0000C931
	v_dot2acc_f32_f16 v41, v98, v15                            // 00000091C35C: 04521F62
	.long 0xd72c0062                                           // 00000091C360: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 00000091C364: 0202C8FF 83DCD12D
	v_pk_fma_f16 v92, v92, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C36C: CC0E005C 0BFC0B5C 0000C931
	v_dual_dot2acc_f32_f16 v54, v94, v4 :: v_dual_lshlrev_b32 v91, 16, v91// 00000091C378: CB22095E 365AB690
	v_dual_dot2acc_f32_f16 v52, v93, v9 :: v_dual_and_b32 v95, 0xffff, v96// 00000091C380: CB24135D 345EC0FF 0000FFFF
	v_sad_u8 v96, v99, 0, 0x6400                               // 00000091C38C: D6220060 03FD0163 00006400
	v_dual_dot2acc_f32_f16 v50, v94, v12 :: v_dual_dot2acc_f32_f16 v47, v93, v1// 00000091C398: CB18195E 322E035D
	v_sad_u8 v97, v98, 0, 0x6400                               // 00000091C3A0: D6220061 03FD0162 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091C3AC: BF870214
	v_dot2acc_f32_f16 v52, v92, v10                            // 00000091C3B0: 0468155C
	v_lshl_or_b32 v95, v96, 16, v95                            // 00000091C3B4: D656005F 057D2160
	s_waitcnt vmcnt(5)                                         // 00000091C3BC: BF8917F7
	v_bfe_u32 v96, v88, 12, 16                                 // 00000091C3C0: D6100060 02411958
	v_dot2acc_f32_f16 v41, v94, v16                            // 00000091C3C8: 0452215E
	v_and_or_b32 v91, 0xffff, v97, v91                         // 00000091C3CC: D657005B 056EC2FF 0000FFFF
	v_bfe_u32 v97, v88, 8, 16                                  // 00000091C3D8: D6100061 02411158
	v_pk_fma_f16 v95, v95, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C3E0: CC0E005F 0BFC0B5F 0000C931
	.long 0xd72c0060                                           // 00000091C3EC: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 00000091C3F0: 0202C0FF 83DCD12D
	v_dot2acc_f32_f16 v53, v93, v5                             // 00000091C3F8: 046A0B5D
	v_pk_fma_f16 v91, v91, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C3FC: CC0E005B 0BFC0B5B 0000C931
	v_and_b32_e32 v94, 0xffff, v89                             // 00000091C408: 36BCB2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v52, v95, v11 :: v_dual_dot2acc_f32_f16 v47, v92, v2// 00000091C410: CB18175F 342E055C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000091C418: BF870234
	v_dot2acc_f32_f16 v53, v92, v6                             // 00000091C41C: 046A0D5C
	v_bfe_u32 v98, v88, 4, 16                                  // 00000091C420: D6100062 02410958
	v_and_b32_e32 v88, 0xffff, v88                             // 00000091C428: 36B0B0FF 0000FFFF
	v_dot2acc_f32_f16 v52, v91, v12                            // 00000091C430: 0468195B
	v_dot2acc_f32_f16 v47, v95, v3                             // 00000091C434: 045E075F
	.long 0xd72c0061                                           // 00000091C438: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 00000091C43C: 0202C2FF 83DCD12D
	v_sad_u8 v96, v96, 0, 0x6400                               // 00000091C444: D6220060 03FD0160 00006400
	v_dot2acc_f32_f16 v49, v93, v13                            // 00000091C450: 04621B5D
	v_bfe_u32 v93, v89, 8, 16                                  // 00000091C454: D610005D 02411159
	v_bfe_u32 v89, v89, 4, 16                                  // 00000091C45C: D6100059 02410959
	.long 0xd72c005e                                           // 00000091C464: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 00000091C468: 0202BCFF 83DCD12D
	.long 0xd72c0058                                           // 00000091C470: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 00000091C474: 0202B0FF 83DCD12D
	v_and_b32_e32 v96, 0xffff, v96                             // 00000091C47C: 36C0C0FF 0000FFFF
	.long 0xd72c005d                                           // 00000091C484: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 00000091C488: 0202BAFF 83DCD12D
	v_sad_u8 v97, v97, 0, 0x6400                               // 00000091C490: D6220061 03FD0161 00006400
	.long 0xd72c0059                                           // 00000091C49C: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 00000091C4A0: 0202B2FF 83DCD12D
	v_dot2acc_f32_f16 v53, v95, v7                             // 00000091C4A8: 046A0F5F
	v_sad_u8 v94, v94, 0, 0x6400                               // 00000091C4AC: D622005E 03FD015E 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 00000091C4B8: D6220058 03FD0158 00006400
	v_dot2acc_f32_f16 v49, v92, v14                            // 00000091C4C4: 04621D5C
	v_sad_u8 v93, v93, 0, 0x6400                               // 00000091C4C8: D622005D 03FD015D 00006400
	v_lshl_or_b32 v92, v97, 16, v96                            // 00000091C4D4: D656005C 05812161
	v_sad_u8 v89, v89, 0, 0x6400                               // 00000091C4DC: D6220059 03FD0159 00006400
	v_lshlrev_b32_e32 v88, 16, v88                             // 00000091C4E8: 30B0B090
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091C4EC: BF870214
	v_lshl_or_b32 v90, v93, 16, v90                            // 00000091C4F0: D656005A 0569215D
	v_pk_fma_f16 v92, v92, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C4F8: CC0E005C 0BFC0B5C 0000C931
	v_lshlrev_b32_e32 v93, 16, v94                             // 00000091C504: 30BABC90
	.long 0xd72c005e                                           // 00000091C508: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 00000091C50C: 0202C4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091C514: BF870224
	v_pk_fma_f16 v90, v90, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C518: CC0E005A 0BFC0B5A 0000C931
	v_dot2acc_f32_f16 v53, v91, v8                             // 00000091C524: 046A115B
	v_and_or_b32 v89, 0xffff, v89, v93                         // 00000091C528: D6570059 0576B2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091C534: BF8701A3
	v_dual_dot2acc_f32_f16 v47, v91, v4 :: v_dual_dot2acc_f32_f16 v48, v90, v5// 00000091C538: CB18095B 2F300B5A
	v_sad_u8 v93, v94, 0, 0x6400                               // 00000091C540: D622005D 03FD015E 00006400
	v_pk_fma_f16 v89, v89, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C54C: CC0E0059 0BFC0B59 0000C931
	v_dot2acc_f32_f16 v46, v90, v9                             // 00000091C558: 045C135A
	v_dot2acc_f32_f16 v29, v90, v1                             // 00000091C55C: 043A035A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091C560: BF870214
	v_and_or_b32 v88, 0xffff, v93, v88                         // 00000091C564: D6570058 0562BAFF 0000FFFF
	v_dot2acc_f32_f16 v48, v89, v6                             // 00000091C570: 04600D59
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091C574: BF870214
	v_dot2acc_f32_f16 v46, v89, v10                            // 00000091C578: 045C1559
	v_dot2acc_f32_f16 v29, v89, v2                             // 00000091C57C: 043A0559
	s_waitcnt vmcnt(4)                                         // 00000091C580: BF8913F7
	v_bfe_u32 v93, v85, 4, 16                                  // 00000091C584: D610005D 02410955
	v_pk_fma_f16 v88, v88, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C58C: CC0E0058 0BFC0B58 0000C931
	v_dot2acc_f32_f16 v48, v92, v7                             // 00000091C598: 04600F5C
	v_dual_dot2acc_f32_f16 v46, v92, v11 :: v_dual_dot2acc_f32_f16 v45, v90, v13// 00000091C59C: CB18175C 2E2C1B5A
	v_dual_dot2acc_f32_f16 v29, v92, v3 :: v_dual_and_b32 v90, 0xffff, v86// 00000091C5A4: CB24075C 1D5AACFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091C5B0: BF870193
	v_dual_dot2acc_f32_f16 v49, v95, v15 :: v_dual_dot2acc_f32_f16 v48, v88, v8// 00000091C5B4: CB181F5F 31301158
	v_dual_dot2acc_f32_f16 v46, v88, v12 :: v_dual_dot2acc_f32_f16 v45, v89, v14// 00000091C5BC: CB181958 2E2C1D59
	v_bfe_u32 v89, v86, 8, 16                                  // 00000091C5C4: D6100059 02411156
	v_bfe_u32 v86, v86, 4, 16                                  // 00000091C5CC: D6100056 02410956
	.long 0xd72c005a                                           // 00000091C5D4: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 00000091C5D8: 0202B4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091C5E0: BF870193
	.long 0xd72c0059                                           // 00000091C5E4: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 00000091C5E8: 0202B2FF 83DCD12D
	.long 0xd72c0056                                           // 00000091C5F0: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 00000091C5F4: 0202ACFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091C5FC: BF870003
	v_sad_u8 v90, v90, 0, 0x6400                               // 00000091C600: D622005A 03FD015A 00006400
	v_dot2acc_f32_f16 v49, v91, v16                            // 00000091C60C: 0462215B
	v_bfe_u32 v91, v85, 12, 16                                 // 00000091C610: D610005B 02411955
	v_sad_u8 v89, v89, 0, 0x6400                               // 00000091C618: D6220059 03FD0159 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 00000091C624: D6220056 03FD0156 00006400
	v_lshlrev_b32_e32 v90, 16, v90                             // 00000091C630: 30B4B490
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091C634: BF870214
	.long 0xd72c005b                                           // 00000091C638: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 00000091C63C: 0202B6FF 83DCD12D
	v_lshl_or_b32 v87, v89, 16, v87                            // 00000091C644: D6560057 055D2159
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091C64C: BF870113
	v_and_or_b32 v86, 0xffff, v86, v90                         // 00000091C650: D6570056 056AACFF 0000FFFF
	v_pk_fma_f16 v87, v87, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C65C: CC0E0057 0BFC0B57 0000C931
	v_dot2acc_f32_f16 v29, v88, v4                             // 00000091C668: 043A0958
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091C66C: BF870223
	v_pk_fma_f16 v86, v86, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C670: CC0E0056 0BFC0B56 0000C931
	v_sad_u8 v91, v91, 0, 0x6400                               // 00000091C67C: D622005B 03FD015B 00006400
	v_dot2acc_f32_f16 v44, v87, v1                             // 00000091C688: 04580357
	v_dual_dot2acc_f32_f16 v42, v87, v9 :: v_dual_dot2acc_f32_f16 v45, v92, v15// 00000091C68C: CB181357 2A2C1F5C
	v_bfe_u32 v92, v85, 8, 16                                  // 00000091C694: D610005C 02411155
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091C69C: BF870193
	v_dual_dot2acc_f32_f16 v44, v86, v2 :: v_dual_and_b32 v85, 0xffff, v85// 00000091C6A0: CB240556 2C54AAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v42, v86, v10 :: v_dual_dot2acc_f32_f16 v45, v88, v16// 00000091C6AC: CB181556 2A2C2158
	v_dot2acc_f32_f16 v40, v87, v13                            // 00000091C6B4: 04501B57
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091C6B8: BF870003
	.long 0xd72c0055                                           // 00000091C6BC: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 00000091C6C0: 0202AAFF 83DCD12D
	.long 0xd72c0058                                           // 00000091C6C8: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 00000091C6CC: 0202BAFF 83DCD12D
	.long 0xd72c005c                                           // 00000091C6D4: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 00000091C6D8: 0202B8FF 83DCD12D
	v_mov_b32_e32 v93, v74                                     // 00000091C6E0: 7EBA034A
	v_dot2acc_f32_f16 v40, v86, v14                            // 00000091C6E4: 04501D56
	v_sad_u8 v85, v85, 0, 0x6400                               // 00000091C6E8: D6220055 03FD0155 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 00000091C6F4: D6220058 03FD0158 00006400
	v_sad_u8 v90, v92, 0, 0x6400                               // 00000091C700: D622005A 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091C70C: BF870093
	v_dual_mov_b32 v92, v68 :: v_dual_lshlrev_b32 v85, 16, v85 // 00000091C710: CA220144 5C54AA90
	v_and_or_b32 v85, 0xffff, v88, v85                         // 00000091C718: D6570055 0556B0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000091C724: BF870141
	v_pk_fma_f16 v85, v85, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C728: CC0E0055 0BFC0B55 0000C931
	v_and_b32_e32 v89, 0xffff, v91                             // 00000091C734: 36B2B6FF 0000FFFF
	s_waitcnt vmcnt(3)                                         // 00000091C73C: BF890FF7
	v_bfe_u32 v91, v82, 4, 16                                  // 00000091C740: D610005B 02410952
	v_lshl_or_b32 v89, v90, 16, v89                            // 00000091C748: D6560059 0565215A
	v_bfe_u32 v90, v82, 8, 16                                  // 00000091C750: D610005A 02411152
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000091C758: BF870252
	v_pk_fma_f16 v88, v89, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C75C: CC0E0058 0BFC0B59 0000C931
	v_dot2acc_f32_f16 v43, v87, v5                             // 00000091C768: 04560B57
	v_bfe_u32 v89, v82, 12, 16                                 // 00000091C76C: D6100059 02411952
	v_and_b32_e32 v82, 0xffff, v82                             // 00000091C774: 36A4A4FF 0000FFFF
	.long 0xd72c005a                                           // 00000091C77C: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 00000091C780: 0202B4FF 83DCD12D
	v_dual_dot2acc_f32_f16 v42, v88, v11 :: v_dual_dot2acc_f32_f16 v43, v86, v6// 00000091C788: CB181758 2A2A0D56
	v_bfe_u32 v86, v83, 8, 16                                  // 00000091C790: D6100056 02411153
	.long 0xd72c0059                                           // 00000091C798: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 00000091C79C: 0202B2FF 83DCD12D
	.long 0xd72c0052                                           // 00000091C7A4: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000091C7A8: 0202A4FF 83DCD12D
	v_dot2acc_f32_f16 v44, v88, v3                             // 00000091C7B0: 04580758
	v_dot2acc_f32_f16 v43, v88, v7                             // 00000091C7B4: 04560F58
	.long 0xd72c0056                                           // 00000091C7B8: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 00000091C7BC: 0202ACFF 83DCD12D
	v_sad_u8 v90, v90, 0, 0x6400                               // 00000091C7C4: D622005A 03FD015A 00006400
	v_dot2acc_f32_f16 v42, v85, v12                            // 00000091C7D0: 04541955
	v_dot2acc_f32_f16 v44, v85, v4                             // 00000091C7D4: 04580955
	v_dot2acc_f32_f16 v43, v85, v8                             // 00000091C7D8: 04561155
	v_sad_u8 v89, v89, 0, 0x6400                               // 00000091C7DC: D6220059 03FD0159 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 00000091C7E8: D6220052 03FD0152 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 00000091C7F4: D6220056 03FD0156 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091C800: BF870091
	v_lshl_or_b32 v84, v86, 16, v84                            // 00000091C804: D6560054 05512156
	v_pk_fma_f16 v84, v84, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C80C: CC0E0054 0BFC0B54 0000C931
	v_and_b32_e32 v87, 0xffff, v83                             // 00000091C818: 36AEA6FF 0000FFFF
	v_bfe_u32 v83, v83, 4, 16                                  // 00000091C820: D6100053 02410953
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091C828: BF870223
	v_dual_dot2acc_f32_f16 v39, v84, v1 :: v_dual_lshlrev_b32 v82, 16, v82// 00000091C82C: CB220354 2752A490
	v_dot2acc_f32_f16 v38, v84, v5                             // 00000091C834: 044C0B54
	.long 0xd72c0057                                           // 00000091C838: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 00000091C83C: 0202AEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091C844: BF870004
	.long 0xd72c0053                                           // 00000091C848: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 00000091C84C: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v37, v84, v9                             // 00000091C854: 044A1354
	v_dot2acc_f32_f16 v40, v88, v15                            // 00000091C858: 04501F58
	v_dot2acc_f32_f16 v36, v84, v13                            // 00000091C85C: 04481B54
	v_bfe_u32 v84, v80, 8, 16                                  // 00000091C860: D6100054 02411150
	s_waitcnt vmcnt(2)                                         // 00000091C868: BF890BF7
	v_bfe_u32 v88, v79, 4, 16                                  // 00000091C86C: D6100058 0241094F
	v_sad_u8 v87, v87, 0, 0x6400                               // 00000091C874: D6220057 03FD0157 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 00000091C880: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v40, v85, v16                            // 00000091C88C: 04502155
	v_bfe_u32 v85, v79, 12, 16                                 // 00000091C890: D6100055 0241194F
	.long 0xd72c0054                                           // 00000091C898: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 00000091C89C: 0202A8FF 83DCD12D
	v_lshlrev_b32_e32 v87, 16, v87                             // 00000091C8A4: 30AEAE90
	.long 0xd72c0058                                           // 00000091C8A8: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 00000091C8AC: 0202B0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091C8B4: BF870194
	.long 0xd72c0055                                           // 00000091C8B8: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 00000091C8BC: 0202AAFF 83DCD12D
	v_and_or_b32 v83, 0xffff, v83, v87                         // 00000091C8C4: D6570053 055EA6FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 00000091C8D0: D6220054 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 00000091C8DC: BF870002
	v_pk_fma_f16 v83, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C8E0: CC0E0053 0BFC0B53 0000C931
	v_and_b32_e32 v86, 0xffff, v89                             // 00000091C8EC: 36ACB2FF 0000FFFF
	.long 0xd72c0059                                           // 00000091C8F4: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 00000091C8F8: 0202B6FF 83DCD12D
	v_sad_u8 v85, v85, 0, 0x6400                               // 00000091C900: D6220055 03FD0155 00006400
	v_mov_b32_e32 v91, v74                                     // 00000091C90C: 7EB6034A
	v_dot2acc_f32_f16 v39, v83, v2                             // 00000091C910: 044E0553
	v_lshl_or_b32 v86, v90, 16, v86                            // 00000091C914: D6560056 0559215A
	v_dot2acc_f32_f16 v38, v83, v6                             // 00000091C91C: 044C0D53
	v_dot2acc_f32_f16 v37, v83, v10                            // 00000091C920: 044A1553
	v_dual_dot2acc_f32_f16 v36, v83, v14 :: v_dual_and_b32 v83, 0xffff, v80// 00000091C924: CB241D53 2452A0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091C930: BF870004
	v_pk_fma_f16 v86, v86, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C934: CC0E0056 0BFC0B56 0000C931
	v_sad_u8 v87, v89, 0, 0x6400                               // 00000091C940: D6220057 03FD0159 00006400
	v_bfe_u32 v80, v80, 4, 16                                  // 00000091C94C: D6100050 02410950
	v_and_b32_e32 v81, 0xffff, v81                             // 00000091C954: 36A2A2FF 0000FFFF
	.long 0xd72c0053                                           // 00000091C95C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 00000091C960: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v39, v86, v3                             // 00000091C968: 044E0756
	v_dot2acc_f32_f16 v38, v86, v7                             // 00000091C96C: 044C0F56
	v_dot2acc_f32_f16 v37, v86, v11                            // 00000091C970: 044A1756
	v_and_or_b32 v82, 0xffff, v87, v82                         // 00000091C974: D6570052 054AAEFF 0000FFFF
	v_bfe_u32 v87, v79, 8, 16                                  // 00000091C980: D6100057 0241114F
	.long 0xd72c0050                                           // 00000091C988: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 00000091C98C: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v36, v86, v15                            // 00000091C994: 04481F56
	v_sad_u8 v83, v83, 0, 0x6400                               // 00000091C998: D6220053 03FD0153 00006400
	v_pk_fma_f16 v82, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C9A4: CC0E0052 0BFC0B52 0000C931
	.long 0xd72c0057                                           // 00000091C9B0: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 00000091C9B4: 0202AEFF 83DCD12D
	v_lshl_or_b32 v81, v84, 16, v81                            // 00000091C9BC: D6560051 05452154
	v_and_b32_e32 v79, 0xffff, v79                             // 00000091C9C4: 369E9EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091C9CC: BF870004
	v_dual_dot2acc_f32_f16 v36, v82, v16 :: v_dual_lshlrev_b32 v83, 16, v83// 00000091C9D0: CB222152 2452A690
	v_sad_u8 v80, v80, 0, 0x6400                               // 00000091C9D8: D6220050 03FD0150 00006400
	v_dot2acc_f32_f16 v38, v82, v8                             // 00000091C9E4: 044C1152
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091C9E8: CC0E0051 0BFC0B51 0000C931
	v_sad_u8 v84, v87, 0, 0x6400                               // 00000091C9F4: D6220054 03FD0157 00006400
	.long 0xd72c004f                                           // 00000091CA00: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 00000091CA04: 02029EFF 83DCD12D
	v_and_or_b32 v80, 0xffff, v80, v83                         // 00000091CA0C: D6570050 054EA0FF 0000FFFF
	v_and_b32_e32 v83, 0xffff, v85                             // 00000091CA18: 36A6AAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v39, v82, v4 :: v_dual_dot2acc_f32_f16 v34, v81, v5// 00000091CA20: CB180952 27220B51
	v_sad_u8 v85, v88, 0, 0x6400                               // 00000091CA28: D6220055 03FD0158 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091CA34: BF870214
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091CA38: CC0E0050 0BFC0B50 0000C931
	v_lshl_or_b32 v83, v84, 16, v83                            // 00000091CA44: D6560053 054D2154
	v_dot2acc_f32_f16 v37, v82, v12                            // 00000091CA4C: 044A1952
	v_sad_u8 v79, v79, 0, 0x6400                               // 00000091CA50: D622004F 03FD014F 00006400
	v_and_b32_e32 v82, 0xffff, v77                             // 00000091CA5C: 36A49AFF 0000FFFF
	v_dot2acc_f32_f16 v34, v80, v6                             // 00000091CA64: 04440D50
	v_pk_fma_f16 v83, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091CA68: CC0E0053 0BFC0B53 0000C931
	v_dot2acc_f32_f16 v35, v81, v1                             // 00000091CA74: 04460351
	v_dual_dot2acc_f32_f16 v32, v81, v13 :: v_dual_lshlrev_b32 v79, 16, v79// 00000091CA78: CB221B51 204E9E90
	v_bfe_u32 v84, v77, 8, 16                                  // 00000091CA80: D6100054 0241114D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091CA88: BF870193
	v_dual_dot2acc_f32_f16 v34, v83, v7 :: v_dual_dot2acc_f32_f16 v35, v80, v2// 00000091CA8C: CB180F53 22220550
	v_and_or_b32 v79, 0xffff, v85, v79                         // 00000091CA94: D657004F 053EAAFF 0000FFFF
	v_bfe_u32 v77, v77, 4, 16                                  // 00000091CAA0: D610004D 0241094D
	.long 0xd72c0052                                           // 00000091CAA8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000091CAAC: 0202A4FF 83DCD12D
	s_waitcnt vmcnt(1)                                         // 00000091CAB4: BF8907F7
	v_bfe_u32 v85, v76, 12, 16                                 // 00000091CAB8: D6100055 0241194C
	.long 0xd72c0054                                           // 00000091CAC0: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 00000091CAC4: 0202A8FF 83DCD12D
	v_dot2acc_f32_f16 v33, v81, v9                             // 00000091CACC: 04421351
	v_bfe_u32 v86, v76, 8, 16                                  // 00000091CAD0: D6100056 0241114C
	.long 0xd72c004d                                           // 00000091CAD8: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 00000091CADC: 02029AFF 83DCD12D
	v_bfe_u32 v87, v76, 4, 16                                  // 00000091CAE4: D6100057 0241094C
	.long 0xd72c0055                                           // 00000091CAEC: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 00000091CAF0: 0202AAFF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 00000091CAF8: 369898FF 0000FFFF
	v_pk_fma_f16 v79, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091CB00: CC0E004F 0BFC0B4F 0000C931
	v_dot2acc_f32_f16 v35, v83, v3                             // 00000091CB0C: 04460753
	v_sad_u8 v82, v82, 0, 0x6400                               // 00000091CB10: D6220052 03FD0152 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 00000091CB1C: D6220054 03FD0154 00006400
	.long 0xd72c0056                                           // 00000091CB28: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 00000091CB2C: 0202ACFF 83DCD12D
	.long 0xd72c004c                                           // 00000091CB34: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 00000091CB38: 020298FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091CB40: BF870004
	v_dual_dot2acc_f32_f16 v35, v79, v4 :: v_dual_lshlrev_b32 v82, 16, v82// 00000091CB44: CB22094F 2352A490
	v_sad_u8 v77, v77, 0, 0x6400                               // 00000091CB4C: D622004D 03FD014D 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 00000091CB58: D6220055 03FD0155 00006400
	v_lshl_or_b32 v78, v84, 16, v78                            // 00000091CB64: D656004E 05392154
	.long 0xd72c0051                                           // 00000091CB6C: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 00000091CB70: 0202AEFF 83DCD12D
	v_dot2acc_f32_f16 v33, v80, v10                            // 00000091CB78: 04421550
	v_and_or_b32 v77, 0xffff, v77, v82                         // 00000091CB7C: D657004D 054A9AFF 0000FFFF
	v_and_b32_e32 v82, 0xffff, v85                             // 00000091CB88: 36A4AAFF 0000FFFF
	v_sad_u8 v84, v86, 0, 0x6400                               // 00000091CB90: D6220054 03FD0156 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000091CB9C: D622004C 03FD014C 00006400
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091CBA8: CC0E004E 0BFC0B4E 0000C931
	v_dual_dot2acc_f32_f16 v33, v83, v11 :: v_dual_dot2acc_f32_f16 v32, v80, v14// 00000091CBB4: CB181753 21201D50
	v_pk_fma_f16 v77, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091CBBC: CC0E004D 0BFC0B4D 0000C931
	v_lshl_or_b32 v80, v84, 16, v82                            // 00000091CBC8: D6560050 05492154
	v_sad_u8 v81, v81, 0, 0x6400                               // 00000091CBD0: D6220051 03FD0151 00006400
	v_dual_dot2acc_f32_f16 v31, v78, v1 :: v_dual_lshlrev_b32 v76, 16, v76// 00000091CBDC: CB22034E 1F4C9890
	v_dual_dot2acc_f32_f16 v33, v79, v12 :: v_dual_dot2acc_f32_f16 v30, v78, v5// 00000091CBE4: CB18194F 211E0B4E
	v_dot2acc_f32_f16 v28, v78, v9                             // 00000091CBEC: 0438134E
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091CBF0: CC0E0050 0BFC0B50 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000091CBFC: BF870244
	v_and_or_b32 v76, 0xffff, v81, v76                         // 00000091CC00: D657004C 0532A2FF 0000FFFF
	v_dot2acc_f32_f16 v31, v77, v2                             // 00000091CC0C: 043E054D
	v_dot2acc_f32_f16 v30, v77, v6                             // 00000091CC10: 043C0D4D
	v_dual_dot2acc_f32_f16 v32, v83, v15 :: v_dual_dot2acc_f32_f16 v27, v78, v13// 00000091CC14: CB181F53 201A1B4E
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091CC1C: CC0E004C 0BFC0B4C 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091CC28: BF870194
	v_dual_dot2acc_f32_f16 v31, v80, v3 :: v_dual_dot2acc_f32_f16 v28, v77, v10// 00000091CC2C: CB180750 1F1C154D
	v_dual_dot2acc_f32_f16 v34, v79, v8 :: v_dual_dot2acc_f32_f16 v27, v77, v14// 00000091CC34: CB18114F 221A1D4D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091CC3C: BF870194
	v_dot2acc_f32_f16 v32, v79, v16                            // 00000091CC40: 0440214F
	v_dot2acc_f32_f16 v31, v76, v4                             // 00000091CC44: 043E094C
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091CC48: BF870004
	v_dot2acc_f32_f16 v28, v80, v11                            // 00000091CC4C: 04381750
	v_bfe_u32 v79, v59, 8, 16                                  // 00000091CC50: D610004F 0241113B
	s_waitcnt vmcnt(0)                                         // 00000091CC58: BF8903F7
	v_bfe_u32 v81, v58, 12, 16                                 // 00000091CC5C: D6100051 0241193A
	v_bfe_u32 v82, v58, 8, 16                                  // 00000091CC64: D6100052 0241113A
	v_bfe_u32 v83, v58, 4, 16                                  // 00000091CC6C: D6100053 0241093A
	v_dot2acc_f32_f16 v27, v80, v15                            // 00000091CC74: 04361F50
	.long 0xd72c004f                                           // 00000091CC78: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 00000091CC7C: 02029EFF 83DCD12D
	v_dual_mov_b32 v85, v72 :: v_dual_and_b32 v58, 0xffff, v58 // 00000091CC84: CA240148 553A74FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091CC90: BF870214
	.long 0xd72c004d                                           // 00000091CC94: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 00000091CC98: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v27, v76, v16                            // 00000091CCA0: 0436214C
	.long 0xd72c0051                                           // 00000091CCA4: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 00000091CCA8: 0202A2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091CCB0: BF870004
	.long 0xd72c003a                                           // 00000091CCB4: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 00000091CCB8: 020274FF 83DCD12D
	v_mov_b32_e32 v87, v72                                     // 00000091CCC0: 7EAE0348
	v_sad_u8 v79, v79, 0, 0x6400                               // 00000091CCC4: D622004F 03FD014F 00006400
	.long 0xd72c0052                                           // 00000091CCD0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000091CCD4: 0202A4FF 83DCD12D
	v_mov_b32_e32 v89, v65                                     // 00000091CCDC: 7EB20341
	v_sad_u8 v77, v77, 0, 0x6400                               // 00000091CCE0: D622004D 03FD014D 00006400
	v_mov_b32_e32 v86, v64                                     // 00000091CCEC: 7EAC0340
	v_lshl_or_b32 v60, v79, 16, v60                            // 00000091CCF0: D656003C 04F1214F
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000091CCF8: D622003A 03FD013A 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 00000091CD04: D6220051 03FD0151 00006400
	v_dot2acc_f32_f16 v30, v80, v7                             // 00000091CD10: 043C0F50
	v_sad_u8 v82, v82, 0, 0x6400                               // 00000091CD14: D6220052 03FD0152 00006400
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091CD20: CC0E003C 0BFC0B3C 0000C931
	v_and_b32_e32 v78, 0xffff, v59                             // 00000091CD2C: 369C76FF 0000FFFF
	v_bfe_u32 v59, v59, 4, 16                                  // 00000091CD34: D610003B 0241093B
	v_lshlrev_b32_e32 v58, 16, v58                             // 00000091CD3C: 30747490
	v_and_b32_e32 v81, 0xffff, v81                             // 00000091CD40: 36A2A2FF 0000FFFF
	v_dot2acc_f32_f16 v25, v60, v5                             // 00000091CD48: 04320B3C
	.long 0xd72c004e                                           // 00000091CD4C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 00000091CD50: 02029CFF 83DCD12D
	.long 0xd72c003b                                           // 00000091CD58: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 00000091CD5C: 020276FF 83DCD12D
	v_dot2acc_f32_f16 v26, v60, v1                             // 00000091CD64: 0434033C
	v_and_or_b32 v1, 0xffff, v77, v58                          // 00000091CD68: D6570001 04EA9AFF 0000FFFF
	v_dot2acc_f32_f16 v24, v60, v9                             // 00000091CD74: 0430133C
	v_dual_dot2acc_f32_f16 v22, v60, v13 :: v_dual_mov_b32 v79, v70// 00000091CD78: CB101B3C 164E0146
	v_mov_b32_e32 v77, v61                                     // 00000091CD80: 7E9A033D
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000091CD84: D622004E 03FD014E 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000091CD90: D622003B 03FD013B 00006400
	v_pk_fma_f16 v1, v1, s5, 0xc931 op_sel_hi:[1,0,0]          // 00000091CD9C: CC0E0001 0BFC0B01 0000C931
	v_mov_b32_e32 v88, v73                                     // 00000091CDA8: 7EB00349
	v_mov_b32_e32 v90, v73                                     // 00000091CDAC: 7EB40349
	v_dual_mov_b32 v83, v63 :: v_dual_lshlrev_b32 v78, 16, v78 // 00000091CDB0: CA22013F 534E9C90
	v_mov_b32_e32 v84, v71                                     // 00000091CDB8: 7EA80347
	v_mov_b32_e32 v80, v62                                     // 00000091CDBC: 7EA0033E
	v_mov_b32_e32 v60, v67                                     // 00000091CDC0: 7E780343
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000091CDC4: BF870244
	v_and_or_b32 v59, 0xffff, v59, v78                         // 00000091CDC8: D657003B 053A76FF 0000FFFF
	v_lshl_or_b32 v78, v82, 16, v81                            // 00000091CDD4: D656004E 05452152
	v_dual_mov_b32 v81, v70 :: v_dual_mov_b32 v82, v71         // 00000091CDDC: CA100146 51520147
	v_mov_b32_e32 v58, v67                                     // 00000091CDE4: 7E740343
	v_pk_fma_f16 v59, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091CDE8: CC0E003B 0BFC0B3B 0000C931
	v_dot2acc_f32_f16 v30, v76, v8                             // 00000091CDF4: 043C114C
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091CDF8: CC0E004E 0BFC0B4E 0000C931
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091CE04: BF870003
	v_dot2acc_f32_f16 v26, v59, v2                             // 00000091CE08: 0434053B
	v_dot2acc_f32_f16 v25, v59, v6                             // 00000091CE0C: 04320D3B
	v_dot2acc_f32_f16 v24, v59, v10                            // 00000091CE10: 0430153B
	v_dot2acc_f32_f16 v22, v59, v14                            // 00000091CE14: 042C1D3B
	v_dot2acc_f32_f16 v28, v76, v12                            // 00000091CE18: 0438194C
	v_dual_dot2acc_f32_f16 v26, v78, v3 :: v_dual_mov_b32 v3, v75// 00000091CE1C: CB10074E 1A02014B
	v_dot2acc_f32_f16 v25, v78, v7                             // 00000091CE24: 04320F4E
	v_dot2acc_f32_f16 v24, v78, v11                            // 00000091CE28: 0430174E
	v_dot2acc_f32_f16 v22, v78, v15                            // 00000091CE2C: 042C1F4E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091CE30: BF870214
	v_dual_dot2acc_f32_f16 v26, v1, v4 :: v_dual_mov_b32 v59, v18// 00000091CE34: CB100901 1A3A0112
	v_dot2acc_f32_f16 v25, v1, v8                              // 00000091CE3C: 04321101
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091CE40: BF870214
	v_dot2acc_f32_f16 v24, v1, v12                             // 00000091CE44: 04301901
	v_dot2acc_f32_f16 v22, v1, v16                             // 00000091CE48: 042C2101
	v_mov_b32_e32 v4, v75                                      // 00000091CE4C: 7E08034B
	v_mov_b32_e32 v2, v66                                      // 00000091CE50: 7E040342
	v_mov_b32_e32 v78, v69                                     // 00000091CE54: 7E9C0345
	v_mov_b32_e32 v76, v69                                     // 00000091CE58: 7E980345
	v_mov_b32_e32 v1, v17                                      // 00000091CE5C: 7E020311
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000091CE60: 917E047E
	s_cbranch_execz 58                                         // 00000091CE64: BFA5003A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1c50>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000091CE68: BF8700A1
	v_add_nc_u32_e32 v17, 1, v1                                // 00000091CE6C: 4A220281
	s_mov_b32 s6, exec_lo                                      // 00000091CE70: BE86007E
	.long 0xd4c1007e                                           // 00000091CE74: D4C1007E
	v_cndmask_b32_e32 v1, v17, v23, vcc_lo                     // 00000091CE78: 02022F11
	s_cbranch_execz 64550                                      // 00000091CE7C: BFA5FC26 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0xc18>
	v_ashrrev_i32_e32 v18, 31, v17                             // 00000091CE80: 3424229F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091CE84: BF870091
	.long 0xd73c0005                                           // 00000091CE88: D73C0005
	v_cndmask_b32_e32 v1, 10, v17, vcc_lo                      // 00000091CE8C: 0202228A
	.long 0xd7006a07                                           // 00000091CE90: D7006A07
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 00000091CE94: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091CE98: BF870111
	v_add_co_ci_u32_e64 v8, null, s3, v6, vcc_lo               // 00000091CE9C: D5207C08 01AA0C03
	.long 0xd7006a05                                           // 00000091CEA4: D7006A05
	v_cndmask_b32_e32 v1, v7, v57, vcc_lo                      // 00000091CEA8: 02027307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000091CEAC: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v8, vcc_lo                // 00000091CEB0: D5207C06 01AA1080
	.long 0xd7006a07                                           // 00000091CEB8: D7006A07
	v_cndmask_b32_e32 v1, v7, v56, vcc_lo                      // 00000091CEBC: 02027107
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 00000091CEC0: D5207C08 01AA1080
	s_clause 0xf                                               // 00000091CEC8: BF85000F
	global_load_b32 v66, v[5:6], off                           // 00000091CECC: DC520000 427C0005
	global_load_b32 v68, v[5:6], off offset:128                // 00000091CED4: DC520080 447C0005
	global_load_b32 v65, v[5:6], off offset:256                // 00000091CEDC: DC520100 417C0005
	global_load_b32 v64, v[5:6], off offset:384                // 00000091CEE4: DC520180 407C0005
	global_load_b32 v63, v[5:6], off offset:512                // 00000091CEEC: DC520200 3F7C0005
	global_load_b32 v62, v[5:6], off offset:640                // 00000091CEF4: DC520280 3E7C0005
	global_load_b32 v61, v[5:6], off offset:768                // 00000091CEFC: DC520300 3D7C0005
	global_load_b32 v18, v[5:6], off offset:896                // 00000091CF04: DC520380 127C0005
	global_load_b32 v75, v[7:8], off                           // 00000091CF0C: DC520000 4B7C0007
	global_load_b32 v74, v[7:8], off offset:128                // 00000091CF14: DC520080 4A7C0007
	global_load_b32 v73, v[7:8], off offset:256                // 00000091CF1C: DC520100 497C0007
	global_load_b32 v72, v[7:8], off offset:384                // 00000091CF24: DC520180 487C0007
	global_load_b32 v71, v[7:8], off offset:512                // 00000091CF2C: DC520200 477C0007
	global_load_b32 v70, v[7:8], off offset:640                // 00000091CF34: DC520280 467C0007
	global_load_b32 v69, v[7:8], off offset:768                // 00000091CF3C: DC520300 457C0007
	global_load_b32 v67, v[7:8], off offset:896                // 00000091CF44: DC520380 437C0007
	s_branch 64498                                             // 00000091CF4C: BFA0FBF2 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0xc18>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000091CF50: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000091CF54: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 00000091CF58: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 00000091CF5C: BF895FF7
	v_dual_mov_b32 v1, v54 :: v_dual_mov_b32 v2, v51           // 00000091CF60: CA100136 01020133
	s_waitcnt vmcnt(7)                                         // 00000091CF68: BF891FF7
	v_dual_mov_b32 v4, v50 :: v_dual_mov_b32 v3, v41           // 00000091CF6C: CA100132 04020129
	v_dual_mov_b32 v5, v47 :: v_dual_mov_b32 v8, v52           // 00000091CF74: CA10012F 05080134
	v_dual_mov_b32 v7, v53 :: v_dual_mov_b32 v10, v48          // 00000091CF7C: CA100135 070A0130
	v_dual_mov_b32 v9, v49 :: v_dual_mov_b32 v14, v43          // 00000091CF84: CA100131 090E012B
	v_dual_mov_b32 v6, v29 :: v_dual_mov_b32 v11, v46          // 00000091CF8C: CA10011D 060A012E
	v_dual_mov_b32 v12, v45 :: v_dual_mov_b32 v13, v44         // 00000091CF94: CA10012D 0C0C012C
	v_dual_mov_b32 v15, v42 :: v_dual_mov_b32 v16, v40         // 00000091CF9C: CA10012A 0F100128
	v_dual_mov_b32 v17, v39 :: v_dual_mov_b32 v18, v38         // 00000091CFA4: CA100127 11120126
	v_dual_mov_b32 v23, v37 :: v_dual_mov_b32 v56, v35         // 00000091CFAC: CA100125 17380123
	s_waitcnt vmcnt(0)                                         // 00000091CFB4: BF8903F7
	v_dual_mov_b32 v55, v36 :: v_dual_mov_b32 v58, v33         // 00000091CFB8: CA100124 373A0121
	v_dual_mov_b32 v57, v34 :: v_dual_mov_b32 v60, v31         // 00000091CFC0: CA100122 393C011F
	v_dual_mov_b32 v59, v32 :: v_dual_mov_b32 v64, v26         // 00000091CFC8: CA100120 3B40011A
	v_dual_mov_b32 v61, v30 :: v_dual_mov_b32 v62, v28         // 00000091CFD0: CA10011E 3D3E011C
	v_dual_mov_b32 v63, v27 :: v_dual_mov_b32 v66, v24         // 00000091CFD8: CA10011B 3F420118
	v_mov_b32_e32 v65, v25                                     // 00000091CFE0: 7E820319
	v_mov_b32_e32 v67, v22                                     // 00000091CFE4: 7E860316
	s_mov_b32 s0, 0x76543210                                   // 00000091CFE8: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000091CFF0: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 00000091CFF4: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000091D000: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 00000091D00C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 00000091D018: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 00000091D024: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 00000091D030: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 00000091D03C: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 00000091D048: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 00000091D054: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 00000091D060: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 00000091D06C: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 00000091D078: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 00000091D084: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 00000091D090: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 00000091D09C: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 00000091D0A8: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 00000091D0B4: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 00000091D0C0: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v23, v23, s0, 0xfedcba98                 // 00000091D0CC: D65C0017 03FC0117 FEDCBA98
	v_permlanex16_b32 v55, v55, s0, 0xfedcba98                 // 00000091D0D8: D65C0037 03FC0137 FEDCBA98
	v_permlanex16_b32 v56, v56, s0, 0xfedcba98                 // 00000091D0E4: D65C0038 03FC0138 FEDCBA98
	v_permlanex16_b32 v57, v57, s0, 0xfedcba98                 // 00000091D0F0: D65C0039 03FC0139 FEDCBA98
	v_permlanex16_b32 v58, v58, s0, 0xfedcba98                 // 00000091D0FC: D65C003A 03FC013A FEDCBA98
	v_permlanex16_b32 v59, v59, s0, 0xfedcba98                 // 00000091D108: D65C003B 03FC013B FEDCBA98
	v_permlanex16_b32 v60, v60, s0, 0xfedcba98                 // 00000091D114: D65C003C 03FC013C FEDCBA98
	v_permlanex16_b32 v61, v61, s0, 0xfedcba98                 // 00000091D120: D65C003D 03FC013D FEDCBA98
	v_permlanex16_b32 v62, v62, s0, 0xfedcba98                 // 00000091D12C: D65C003E 03FC013E FEDCBA98
	v_permlanex16_b32 v63, v63, s0, 0xfedcba98                 // 00000091D138: D65C003F 03FC013F FEDCBA98
	v_permlanex16_b32 v64, v64, s0, 0xfedcba98                 // 00000091D144: D65C0040 03FC0140 FEDCBA98
	v_permlanex16_b32 v65, v65, s0, 0xfedcba98                 // 00000091D150: D65C0041 03FC0141 FEDCBA98
	v_permlanex16_b32 v66, v66, s0, 0xfedcba98                 // 00000091D15C: D65C0042 03FC0142 FEDCBA98
	v_permlanex16_b32 v67, v67, s0, 0xfedcba98                 // 00000091D168: D65C0043 03FC0143 FEDCBA98
	.long 0xd44c0000                                           // 00000091D174: D44C0000
	v_cndmask_b32_e32 v1, 16, v20, vcc_lo                      // 00000091D178: 02022890
	s_barrier                                                  // 00000091D17C: BFBD0000
	buffer_gl0_inv                                             // 00000091D180: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000091D188: BE812000
	s_cbranch_execz 68                                         // 00000091D18C: BFA50044 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1fa0>
	v_lshl_or_b32 v21, v19, 11, v21                            // 00000091D190: D6560015 04551713
	v_dual_add_f32 v12, v45, v12 :: v_dual_add_f32 v5, v47, v5 // 00000091D198: C908192D 0C040B2F
	v_dual_add_f32 v8, v52, v8 :: v_dual_add_f32 v1, v54, v1   // 00000091D1A0: C9081134 08000336
	v_dual_add_f32 v10, v48, v10 :: v_dual_add_f32 v7, v53, v7 // 00000091D1A8: C9081530 0A060F35
	v_add_f32_e32 v2, v51, v2                                  // 00000091D1B0: 06040533
	v_add_f32_e32 v20, v22, v67                                // 00000091D1B4: 06288716
	v_add_f32_e32 v22, v24, v66                                // 00000091D1B8: 062C8518
	v_dual_add_f32 v24, v25, v65 :: v_dual_add_f32 v25, v26, v64// 00000091D1BC: C9088319 1818811A
	v_dual_add_f32 v26, v27, v63 :: v_dual_add_f32 v27, v28, v62// 00000091D1C4: C9087F1B 1A1A7D1C
	v_add_f32_e32 v28, v30, v61                                // 00000091D1CC: 06387B1E
	v_dual_add_f32 v30, v31, v60 :: v_dual_add_f32 v23, v37, v23// 00000091D1D0: C908791F 1E162F25
	v_dual_add_f32 v31, v32, v59 :: v_dual_add_f32 v32, v33, v58// 00000091D1D8: C9087720 1F207521
	v_add_f32_e32 v17, v39, v17                                // 00000091D1E0: 06222327
	v_dual_add_f32 v33, v34, v57 :: v_dual_add_f32 v34, v35, v56// 00000091D1E4: C9087322 21227123
	v_add_f32_e32 v15, v42, v15                                // 00000091D1EC: 061E1F2A
	v_dual_add_f32 v35, v36, v55 :: v_dual_add_f32 v4, v50, v4 // 00000091D1F0: C9086F24 23040932
	v_dual_add_f32 v3, v41, v3 :: v_dual_add_nc_u32 v36, 0x400, v21// 00000091D1F8: C9200729 03242AFF 00000400
	v_dual_add_f32 v14, v43, v14 :: v_dual_add_f32 v9, v49, v9 // 00000091D204: C9081D2B 0E081331
	v_dual_add_f32 v18, v38, v18 :: v_dual_add_f32 v13, v44, v13// 00000091D20C: C9082526 120C1B2C
	v_add_f32_e32 v6, v29, v6                                  // 00000091D214: 060C0D1D
	v_dual_add_f32 v16, v40, v16 :: v_dual_add_f32 v11, v46, v11// 00000091D218: C9082128 100A172E
	ds_store_2addr_b32 v21, v1, v5 offset1:16                  // 00000091D220: D8381000 00050115
	ds_store_2addr_b32 v21, v2, v7 offset0:128 offset1:144     // 00000091D228: D8389080 00070215
	ds_store_2addr_b32 v36, v4, v8 offset1:16                  // 00000091D230: D8381000 00080424
	ds_store_2addr_b32 v36, v3, v9 offset0:128 offset1:144     // 00000091D238: D8389080 00090324
	ds_store_2addr_b32 v21, v6, v13 offset0:32 offset1:48      // 00000091D240: D8383020 000D0615
	ds_store_2addr_b32 v21, v10, v14 offset0:160 offset1:176   // 00000091D248: D838B0A0 000E0A15
	ds_store_2addr_b32 v36, v11, v15 offset0:32 offset1:48     // 00000091D250: D8383020 000F0B24
	ds_store_2addr_b32 v36, v12, v16 offset0:160 offset1:176   // 00000091D258: D838B0A0 00100C24
	ds_store_2addr_b32 v21, v17, v34 offset0:64 offset1:80     // 00000091D260: D8385040 00221115
	ds_store_2addr_b32 v21, v18, v33 offset0:192 offset1:208   // 00000091D268: D838D0C0 00211215
	ds_store_2addr_b32 v36, v23, v32 offset0:64 offset1:80     // 00000091D270: D8385040 00201724
	ds_store_2addr_b32 v36, v35, v31 offset0:192 offset1:208   // 00000091D278: D838D0C0 001F2324
	ds_store_2addr_b32 v21, v30, v25 offset0:96 offset1:112    // 00000091D280: D8387060 00191E15
	ds_store_2addr_b32 v21, v28, v24 offset0:224 offset1:240   // 00000091D288: D838F0E0 00181C15
	ds_store_2addr_b32 v36, v27, v22 offset0:96 offset1:112    // 00000091D290: D8387060 00161B24
	ds_store_2addr_b32 v36, v26, v20 offset0:224 offset1:240   // 00000091D298: D838F0E0 00141A24
	s_or_b32 exec_lo, exec_lo, s1                              // 00000091D2A0: 8C7E017E
	.long 0xd44c0001                                           // 00000091D2A4: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 00000091D2A8: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 00000091D2B0: BF89FC07
	s_barrier                                                  // 00000091D2B4: BFBD0000
	buffer_gl0_inv                                             // 00000091D2B8: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 00000091D2C0: BE832001
	s_cbranch_execz 49                                         // 00000091D2C4: BFA50031 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x208c>
	v_mov_b32_e32 v1, v0                                       // 00000091D2C8: 7E020300
	s_mov_b32 s4, 0                                            // 00000091D2CC: BE840080
	s_nop 0                                                    // 00000091D2D0: BF800000
	s_nop 0                                                    // 00000091D2D4: BF800000
	s_nop 0                                                    // 00000091D2D8: BF800000
	s_nop 0                                                    // 00000091D2DC: BF800000
	s_nop 0                                                    // 00000091D2E0: BF800000
	s_nop 0                                                    // 00000091D2E4: BF800000
	s_nop 0                                                    // 00000091D2E8: BF800000
	s_nop 0                                                    // 00000091D2EC: BF800000
	s_nop 0                                                    // 00000091D2F0: BF800000
	s_nop 0                                                    // 00000091D2F4: BF800000
	s_nop 0                                                    // 00000091D2F8: BF800000
	s_nop 0                                                    // 00000091D2FC: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091D300: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 00000091D304: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 00000091D308: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:8            // 00000091D310: D8E00800 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:16 offset1:24// 00000091D318: D8E01810 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:32 offset1:40// 00000091D320: D8E02820 06000008
	s_or_b32 s4, vcc_lo, s4                                    // 00000091D328: 8C04046A
	s_waitcnt lgkmcnt(2)                                       // 00000091D32C: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 00000091D330: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000091D334: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 00000091D338: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:48 offset1:56// 00000091D33C: D8E03830 02000008
	s_waitcnt lgkmcnt(2)                                       // 00000091D344: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 00000091D348: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 00000091D34C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 00000091D350: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091D354: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 00000091D358: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 00000091D35C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 00000091D360: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000091D364: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 00000091D368: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 00000091D36C: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 00000091D374: C9100702 02000104
	ds_store_b32 v8, v2 offset:16384                           // 00000091D37C: D8344000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000091D384: 917E047E
	s_cbranch_execnz 65501                                     // 00000091D388: BFA6FFDD <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2000>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000091D38C: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 00000091D390: BF048209
	s_mov_b32 s3, -1                                           // 00000091D394: BE8300C1
	s_cbranch_scc1 212                                         // 00000091D398: BFA200D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x23ec>
	s_waitcnt lgkmcnt(0)                                       // 00000091D39C: BF89FC07
	s_barrier                                                  // 00000091D3A0: BFBD0000
	buffer_gl0_inv                                             // 00000091D3A4: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 00000091D3AC: BE832001
	s_cbranch_execz 71                                         // 00000091D3B0: BFA50047 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x21d0>
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000091D3B4: 32020087
	s_ashr_i32 s29, s28, 31                                    // 00000091D3B8: 861D9F1C
	s_ashr_i32 s31, s30, 31                                    // 00000091D3BC: 861F9F1E
	s_lshl_b64 s[4:5], s[28:29], 2                             // 00000091D3C0: 8484821C
	s_lshl_b32 s6, s10, 7                                      // 00000091D3C4: 8406870A
	v_or_b32_e32 v1, s4, v1                                    // 00000091D3C8: 38020204
	v_mov_b32_e32 v2, s5                                       // 00000091D3CC: 7E040205
	s_lshl_b64 s[4:5], s[30:31], 2                             // 00000091D3D0: 8484821E
	s_ashr_i32 s7, s6, 31                                      // 00000091D3D4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000091D3D8: BF8700A9
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000091D3DC: 84868206
	.long 0xd7016a01                                           // 00000091D3E0: D7016A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000091D3E4: 02000901
	v_subrev_co_ci_u32_e64 v2, null, s5, v2, vcc_lo            // 00000091D3E8: D5227C02 01AA0405
	s_ashr_i32 s5, s49, 31                                     // 00000091D3F0: 86059F31
	s_mov_b32 s4, s49                                          // 00000091D3F4: BE840031
	.long 0xd72c0004                                           // 00000091D3F8: D72C0004
	v_cndmask_b32_e32 v0, v1, v5, vcc_lo                       // 00000091D3FC: 02000B01
	.long 0xd72c0003                                           // 00000091D400: D72C0003
	v_cndmask_b32_e32 v0, v2, v49, vcc_lo                      // 00000091D404: 02006302
	v_mad_u64_u32 v[1:2], null, v1, s49, 0                     // 00000091D408: D6FE7C01 02006301
	s_lshl_b64 s[4:5], s[4:5], 3                               // 00000091D410: 84848304
	v_add3_u32 v2, v2, v4, v3                                  // 00000091D414: D6550002 040E0902
	v_and_b32_e32 v3, 0x7f, v0                                 // 00000091D41C: 360600FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091D424: BF870112
	.long 0xd73c0001                                           // 00000091D428: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000091D42C: 02020282
	v_lshlrev_b32_e32 v4, 2, v3                                // 00000091D430: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 00000091D434: 30060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091D438: BF870093
	.long 0xd7006a01                                           // 00000091D43C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 00000091D440: 02000D01
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 00000091D444: D5207C02 01AA0407
	s_mov_b32 s6, 0                                            // 00000091D44C: BE860080
	.long 0xd7006a01                                           // 00000091D450: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000091D454: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091D458: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000091D45C: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 00000091D464: 380800FF FFFFFF00
	.long 0xd7006a01                                           // 00000091D46C: D7006A01
	v_cndmask_b32_e32 v1, s44, v1, vcc_lo                      // 00000091D470: 0202022C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091D474: BF870001
	v_add_co_ci_u32_e64 v2, null, s45, v2, vcc_lo              // 00000091D478: D5207C02 01AA042D
	ds_load_b32 v5, v3 offset:16384                            // 00000091D480: D8D84000 05000003
	.long 0xd7000704                                           // 00000091D488: D7000704
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 00000091D48C: 020208FF 00000100
	s_xor_b32 s7, s7, -1                                       // 00000091D494: 8D07C107
	v_add_nc_u32_e32 v3, 0x400, v3                             // 00000091D498: 4A0606FF 00000400
	s_and_b32 s7, exec_lo, s7                                  // 00000091D4A0: 8B07077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000091D4A4: BF8700C9
	s_or_b32 s6, s7, s6                                        // 00000091D4A8: 8C060607
	s_waitcnt lgkmcnt(0)                                       // 00000091D4AC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 00000091D4B0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 00000091D4B8: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000091D4BC: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000091D4C0: D5207C02 01AA0405
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000091D4C8: 917E067E
	s_cbranch_execnz 65516                                     // 00000091D4CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2180>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000091D4D0: 8C7E037E
	.long 0xd44a0003                                           // 00000091D4D4: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000091D4D8: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 00000091D4DC: BC7C0000
	buffer_gl1_inv                                             // 00000091D4E0: E0B00000 00000000
	buffer_gl0_inv                                             // 00000091D4E8: E0AC0000 00000000
	s_barrier                                                  // 00000091D4F0: BFBD0000
	buffer_gl0_inv                                             // 00000091D4F4: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 00000091D4FC: BE842003
	s_cbranch_execz 29                                         // 00000091D500: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2278>
	s_mov_b32 s6, exec_lo                                      // 00000091D504: BE86007E
	s_mov_b32 s5, exec_lo                                      // 00000091D508: BE85007E
	.long 0xd71f0001                                           // 00000091D50C: D71F0001
	v_cndmask_b32_e32 v0, s6, v128, vcc_lo                     // 00000091D510: 02010006
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091D514: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 00000091D518: 7D940280
	s_cbranch_execz 9                                          // 00000091D51C: BFA50009 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2244>
	s_lshl_b64 s[24:25], s[10:11], 2                           // 00000091D520: 8498820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000091D524: BF8704B9
	s_add_u32 s24, s46, s24                                    // 00000091D528: 8018182E
	s_addc_u32 s25, s47, s25                                   // 00000091D52C: 8219192F
	s_bcnt1_i32_b32 s6, s6                                     // 00000091D530: BE861806
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s6              // 00000091D534: CA100080 02020006
	global_atomic_add_u32 v2, v2, v3, s[24:25] glc             // 00000091D53C: DCD64000 02180302
	s_or_b32 exec_lo, exec_lo, s5                              // 00000091D544: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 00000091D548: BF8903F7
	v_readfirstlane_b32 s5, v2                                 // 00000091D54C: 7E0A0502
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091D550: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s5, v1       // 00000091D554: CA200080 02000205
	s_add_i32 s5, s9, -1                                       // 00000091D55C: 8105C109
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000091D560: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s5, v1                            // 00000091D564: 7C940205
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 00000091D568: D5010001 01A90280
	ds_store_b32 v2, v1 offset:36864                           // 00000091D570: D8349000 00000102
	s_or_b32 exec_lo, exec_lo, s4                              // 00000091D578: 8C7E047E
	v_mov_b32_e32 v1, 0                                        // 00000091D57C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 00000091D580: BF89FC07
	s_barrier                                                  // 00000091D584: BFBD0000
	buffer_gl0_inv                                             // 00000091D588: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:36864                            // 00000091D590: D8D89000 01000001
	s_waitcnt lgkmcnt(0)                                       // 00000091D598: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000091D59C: 7C940280
	s_cbranch_vccnz 2604                                       // 00000091D5A0: BFA40A2C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x4b54>
	buffer_gl1_inv                                             // 00000091D5A4: E0B00000 00000000
	buffer_gl0_inv                                             // 00000091D5AC: E0AC0000 00000000
	s_and_saveexec_b32 s8, s1                                  // 00000091D5B4: BE882001
	s_cbranch_execz 65                                         // 00000091D5B8: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x23c0>
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000091D5BC: 32020087
	s_lshl_b32 s4, s10, 7                                      // 00000091D5C0: 8404870A
	v_and_b32_e32 v3, 0x7f, v0                                 // 00000091D5C4: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 00000091D5CC: 86059F04
	v_mov_b32_e32 v5, v0                                       // 00000091D5D0: 7E0A0300
	v_mad_i64_i32 v[1:2], null, v1, s49, 0                     // 00000091D5D4: D6FF7C01 02006301
	s_lshl_b64 s[4:5], s[4:5], 2                               // 00000091D5DC: 84848204
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000091D5E0: 30060682
	s_ashr_i32 s7, s49, 31                                     // 00000091D5E4: 86079F31
	s_mov_b32 s6, s49                                          // 00000091D5E8: BE860031
	s_mov_b32 s24, 0                                           // 00000091D5EC: BE980080
	.long 0xd73c0001                                           // 00000091D5F0: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000091D5F4: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091D5F8: BF870091
	.long 0xd7006a01                                           // 00000091D5FC: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000091D600: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000091D604: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[6:7], 3                               // 00000091D60C: 84848306
	.long 0xd7006a01                                           // 00000091D610: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000091D614: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000091D618: BF8700B1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000091D61C: D5207C02 01AA0480
	s_lshl_b64 s[6:7], s[6:7], 4                               // 00000091D624: 84868406
	.long 0xd7006a01                                           // 00000091D628: D7006A01
	v_cndmask_b32_e32 v1, s44, v1, vcc_lo                      // 00000091D62C: 0202022C
	v_add_co_ci_u32_e64 v2, null, s45, v2, vcc_lo              // 00000091D630: D5207C02 01AA042D
	s_nop 0                                                    // 00000091D638: BF800000
	s_nop 0                                                    // 00000091D63C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091D640: BF870001
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 00000091D644: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 00000091D64C: 7E0C0280
	s_mov_b32 s1, s9                                           // 00000091D650: BE810009
	global_load_b32 v7, v[3:4], off glc                        // 00000091D654: DC524000 077C0003
	.long 0xd7006a03                                           // 00000091D65C: D7006A03
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 00000091D660: 02000D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000091D664: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s7, v4, vcc_lo               // 00000091D668: D5207C04 01AA0807
	s_add_i32 s1, s1, -1                                       // 00000091D670: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 00000091D674: BF068001
	s_waitcnt vmcnt(0)                                         // 00000091D678: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 00000091D67C: 060C0F06
	s_cbranch_scc0 65524                                       // 00000091D680: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2354>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 00000091D684: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 00000091D68C: 7C920AFF 000000FF
	.long 0xd7000101                                           // 00000091D694: D7000101
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000091D698: 02000901
	v_lshlrev_b32_e32 v3, 2, v5                                // 00000091D69C: 30060A82
	v_add_co_ci_u32_e64 v2, null, s5, v2, s1                   // 00000091D6A0: D5207C02 00060405
	v_mov_b32_e32 v5, v4                                       // 00000091D6A8: 7E0A0304
	s_or_b32 s24, vcc_lo, s24                                  // 00000091D6AC: 8C18186A
	ds_store_b32 v3, v6 offset:16384                           // 00000091D6B0: D8344000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 00000091D6B8: 917E187E
	s_cbranch_execnz 65504                                     // 00000091D6BC: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2340>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000091D6C0: 8C7E087E
	s_and_saveexec_b32 s1, s3                                  // 00000091D6C4: BE812003
	s_cbranch_execz 6                                          // 00000091D6C8: BFA50006 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x23e4>
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000091D6CC: 8484820A
	v_mov_b32_e32 v1, 0                                        // 00000091D6D0: 7E020280
	s_add_u32 s4, s46, s4                                      // 00000091D6D4: 8004042E
	s_addc_u32 s5, s47, s5                                     // 00000091D6D8: 8205052F
	global_store_b32 v1, v1, s[4:5]                            // 00000091D6DC: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 00000091D6E4: 8C7E017E
	s_mov_b32 s3, -1                                           // 00000091D6E8: BE8300C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000091D6EC: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000091D6F0: 8B6A037E
	s_cbranch_vccz 379                                         // 00000091D6F4: BFA3017B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x29e4>
	v_cmp_gt_i32_e32 vcc_lo, s48, v19                          // 00000091D6F8: 7C882630
	.long 0xd44c0001                                           // 00000091D6FC: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000091D700: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 00000091D708: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000091D70C: BC7C0000
	s_barrier                                                  // 00000091D710: BFBD0000
	buffer_gl0_inv                                             // 00000091D714: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000091D71C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000091D720: BF870009
	s_and_saveexec_b32 s3, s1                                  // 00000091D724: BE832001
	s_cbranch_execz 365                                        // 00000091D728: BFA5016D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x29e0>
	v_and_b32_e32 v1, 15, v0                                   // 00000091D72C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091D730: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 00000091D734: 30040282
	v_lshl_or_b32 v2, v19, 9, v2                               // 00000091D738: D6560002 04091313
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091D740: BF870001
	v_add_nc_u32_e32 v8, 0x4000, v2                            // 00000091D744: 4A1004FF 00004000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000091D74C: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 00000091D754: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000091D75C: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 00000091D764: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 00000091D76C: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000091D770: 36160082
	s_waitcnt lgkmcnt(3)                                       // 00000091D774: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 00000091D778: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 00000091D780: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 00000091D784: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000091D78C: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000091D790: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 00000091D798: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 00000091D79C: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 00000091D7A4: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 00000091D7AC: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000091D7B0: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 00000091D7B4: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 00000091D7BC: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000091D7C4: 7C941480
	.long 0xd44a0001                                           // 00000091D7C8: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 00000091D7CC: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 00000091D7D0: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 00000091D7D8: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 00000091D7DC: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091D7E0: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 00000091D7E4: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 00000091D7E8: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000091D7F0: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 00000091D7F4: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 00000091D7F8: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091D7FC: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000091D804: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091D80C: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000091D814: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091D81C: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000091D824: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091D82C: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000091D834: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091D83C: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000091D844: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091D84C: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000091D854: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091D85C: 7E2402FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 00000091D864: D5010014 21AA0703
	v_cndmask_b32_e64 v22, -v2, v2, vcc_lo                     // 00000091D86C: D5010016 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 00000091D874: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 00000091D878: C9080D07 03082108
	v_mov_b32_dpp v21, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091D880: 7E2A02FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 00000091D888: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000091D890: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091D894: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000091D89C: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 00000091D8A4: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091D8A8: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000091D8B0: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091D8B8: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 00000091D8C0: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091D8C4: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000091D8CC: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 00000091D8D4: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000091D8D8: D5010008 21AA1108
	v_add_f32_e32 v13, v22, v21                                // 00000091D8E0: 061A2B16
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091D8E4: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 00000091D8EC: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091D8F0: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000091D8F8: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000091D900: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 00000091D908: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091D90C: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000091D914: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 00000091D91C: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091D920: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000091D928: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 00000091D930: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091D934: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000091D93C: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 00000091D944: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 00000091D948: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 00000091D94C: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091D954: 7E0402FA FF016402
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 00000091D95C: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000091D964: BF870242
	v_add_f32_e32 v7, v7, v2                                   // 00000091D968: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091D96C: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 00000091D974: D5010004 20060904
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091D97C: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091D984: 7E0A02FA FF016807
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000091D98C: BF8700A3
	v_add_f32_e32 v4, v4, v10                                  // 00000091D990: 06081504
	v_add_f32_e32 v10, v20, v18                                // 00000091D994: 06142514
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091D998: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000091D9A0: D501000A 21AA150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000091D9A8: BF870241
	v_add_f32_e32 v10, v10, v12                                // 00000091D9AC: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 00000091D9B0: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091D9B4: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 00000091D9BC: D5010009 20061309
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091D9C4: 7E1E02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000091D9CC: BF870254
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091D9D0: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 00000091D9D8: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 00000091D9E0: D501000C 2006190C
	v_add_f32_e32 v6, v6, v11                                  // 00000091D9E8: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091D9EC: 7E1602FA FF016408
	v_dual_add_f32 v16, v9, v13 :: v_dual_add_f32 v15, v10, v15// 00000091D9F4: C9081B09 100E1F0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091D9FC: BF870214
	v_add_f32_e32 v17, v12, v17                                // 00000091DA00: 0622230C
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091DA04: 7E1002FA FF016806
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091DA0C: BF870004
	v_add_f32_e32 v14, v14, v11                                // 00000091DA10: 061C170E
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091DA14: 7E1202FA FF016804
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091DA1C: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091DA24: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091DA2C: 7E1A02FA FF016811
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091DA34: 7E1402FA FF01680E
	s_and_b32 exec_lo, exec_lo, s0                             // 00000091DA3C: 8B7E007E
	s_cbranch_execz 167                                        // 00000091DA40: BFA500A7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x29e0>
	v_lshl_or_b32 v20, s10, 7, v1                              // 00000091DA44: D6560014 04050E0A
	v_and_b32_e32 v1, 8, v0                                    // 00000091DA4C: 36020088
	v_mad_i64_i32 v[18:19], null, s49, v19, 0                  // 00000091DA50: D6FF7C12 02022631
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091DA58: BF870113
	v_ashrrev_i32_e32 v21, 31, v20                             // 00000091DA5C: 342A289F
	.long 0xd73c0012                                           // 00000091DA60: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000091DA64: 02022481
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091DA68: BF870092
	.long 0xd73c0014                                           // 00000091DA6C: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 00000091DA70: 02022881
	.long 0xd7006a16                                           // 00000091DA74: D7006A16
	v_cndmask_b32_e32 v1, s36, v20, vcc_lo                     // 00000091DA78: 02022824
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091DA7C: BF870001
	v_add_co_ci_u32_e64 v23, null, s37, v21, vcc_lo            // 00000091DA80: D5207C17 01AA2A25
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000091DA88: 7C940280
	s_clause 0x7                                               // 00000091DA8C: BF850007
	global_load_d16_b16 v24, v[22:23], off offset:32           // 00000091DA90: DC820020 187C0016
	global_load_d16_b16 v25, v[22:23], off                     // 00000091DA98: DC820000 197C0016
	global_load_d16_b16 v26, v[22:23], off offset:64           // 00000091DAA0: DC820040 1A7C0016
	global_load_d16_b16 v27, v[22:23], off offset:96           // 00000091DAA8: DC820060 1B7C0016
	global_load_d16_b16 v28, v[22:23], off offset:128          // 00000091DAB0: DC820080 1C7C0016
	global_load_d16_b16 v29, v[22:23], off offset:160          // 00000091DAB8: DC8200A0 1D7C0016
	global_load_d16_b16 v30, v[22:23], off offset:192          // 00000091DAC0: DC8200C0 1E7C0016
	global_load_d16_b16 v22, v[22:23], off offset:224          // 00000091DAC8: DC8200E0 167C0016
	.long 0x7f2e3880                                           // 00000091DAD0: 7F2E3880
	v_cndmask_b32_e64 v1, -v7, v7, vcc_lo                      // 00000091DAD4: D5010001 21AA0F07
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000091DADC: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000091DAE4: D501000E 21AA1D0E
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000091DAEC: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000091DAF4: D501000F 21AA1F0F
	v_add_f32_e32 v1, v1, v5                                   // 00000091DAFC: 06020B01
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 00000091DB00: D5010005 21AA0D06
	v_cndmask_b32_e64 v6, -v16, v16, vcc_lo                    // 00000091DB08: D5010006 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 00000091DB10: D5010010 21AA2311
	.long 0xd7006a11                                           // 00000091DB18: D7006A11
	v_cndmask_b32_e32 v1, s42, v18, vcc_lo                     // 00000091DB1C: 0202242A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091DB20: BF870001
	v_add_co_ci_u32_e64 v18, null, s43, v19, vcc_lo            // 00000091DB24: D5207C12 01AA262B
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v4, v4, v9     // 00000091DB2C: C9081105 05041304
	v_dual_add_f32 v8, v14, v10 :: v_dual_mul_f32 v19, 0x3db504f3, v1// 00000091DB34: C906150E 081202FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 00000091DB40: BF891FF7
	.long 0x7f303997                                           // 00000091DB44: 7F303997
	v_dual_add_f32 v3, v3, v2 :: v_dual_add_f32 v6, v6, v11    // 00000091DB48: C9080503 03061706
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 00000091DB50: 100808FF 3DB504F3
	v_dual_add_f32 v9, v15, v12 :: v_dual_add_f32 v10, v16, v13// 00000091DB58: C908190F 090A1B10
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091DB60: BF870213
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 00000091DB64: C8C606FF 030810FF 3DB504F3
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 00000091DB70: C8C60CFF 06040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091DB7C: BF870003
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 00000091DB80: 101414FF 3DB504F3
	s_waitcnt vmcnt(6)                                         // 00000091DB88: BF891BF7
	.long 0x7f323997                                           // 00000091DB8C: 7F323997
	.long 0x7f0e3997                                           // 00000091DB90: 7F0E3997
	s_waitcnt vmcnt(0)                                         // 00000091DB94: BF8903F7
	.long 0x7f2c3997                                           // 00000091DB98: 7F2C3997
	.long 0xd7006a01                                           // 00000091DB9C: D7006A01
	v_cndmask_b32_e32 v1, v17, v20, vcc_lo                     // 00000091DBA0: 02022911
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091DBA4: BF870001
	v_add_co_ci_u32_e64 v2, null, v18, v21, vcc_lo             // 00000091DBA8: D5207C02 01AA2B12
	v_fma_mix_f32 v11, v24, v19, neg(0) op_sel_hi:[1,0,0]      // 00000091DBB0: CC20000B 8A022718
	v_fma_mix_f32 v3, v25, v3, neg(0) op_sel_hi:[1,0,0]        // 00000091DBB8: CC200003 8A020719
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 00000091DBC0: CC200005 8A020B1A
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 00000091DBC8: CC200004 8A02091B
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 00000091DBD0: CC200008 8A02111C
	.long 0x7e2e398b                                           // 00000091DBD8: 7E2E398B
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 00000091DBDC: 101212FF 3DB504F3
	v_fma_mix_f32 v6, v29, v6, neg(0) op_sel_hi:[1,0,0]        // 00000091DBE4: CC200006 8A020D1D
	v_fma_mix_f32 v10, v22, v10, neg(0) op_sel_hi:[1,0,0]      // 00000091DBEC: CC20000A 8A021516
	.long 0x7e0e3983                                           // 00000091DBF4: 7E0E3983
	v_and_b32_e32 v12, 1, v23                                  // 00000091DBF8: 36182E81
	.long 0x7e2e3984                                           // 00000091DBFC: 7E2E3984
	v_fma_mix_f32 v9, v30, v9, neg(0) op_sel_hi:[1,0,0]        // 00000091DC00: CC200009 8A02131E
	.long 0x7e2c3985                                           // 00000091DC08: 7E2C3985
	.long 0x7e303988                                           // 00000091DC0C: 7E303988
	v_and_b32_e32 v7, 1, v7                                    // 00000091DC10: 360E0E81
	v_and_b32_e32 v13, 1, v23                                  // 00000091DC14: 361A2E81
	.long 0x7e2e3986                                           // 00000091DC18: 7E2E3986
	.long 0x7e323989                                           // 00000091DC1C: 7E323989
	v_and_b32_e32 v14, 1, v22                                  // 00000091DC20: 361C2C81
	v_and_b32_e32 v15, 1, v24                                  // 00000091DC24: 361E3081
	v_add3_u32 v3, v3, v7, 0x7fff                              // 00000091DC28: D6550003 03FE0F03 00007FFF
	v_and_b32_e32 v16, 1, v23                                  // 00000091DC34: 36202E81
	.long 0x7e2e398a                                           // 00000091DC38: 7E2E398A
	v_and_b32_e32 v17, 1, v25                                  // 00000091DC3C: 36223281
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000091DC40: D655000B 03FE190B 00007FFF
	v_add3_u32 v5, v5, v14, 0x7fff                             // 00000091DC4C: D6550005 03FE1D05 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 00000091DC58: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v7, 1, v23                                   // 00000091DC64: 360E2E81
	v_add3_u32 v8, v8, v15, 0x7fff                             // 00000091DC68: D6550008 03FE1F08 00007FFF
	v_add3_u32 v9, v9, v17, 0x7fff                             // 00000091DC74: D6550009 03FE2309 00007FFF
	v_add3_u32 v6, v6, v16, 0x7fff                             // 00000091DC80: D6550006 03FE2106 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091DC8C: BF870004
	v_add3_u32 v7, v10, v7, 0x7fff                             // 00000091DC90: D6550007 03FE0F0A 00007FFF
	s_clause 0x7                                               // 00000091DC9C: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 00000091DCA0: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v11, off offset:32         // 00000091DCA8: DC960020 007C0B01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 00000091DCB0: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 00000091DCB8: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 00000091DCC0: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v6, off offset:160         // 00000091DCC8: DC9600A0 007C0601
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 00000091DCD0: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v7, off offset:224         // 00000091DCD8: DC9600E0 007C0701
	s_or_b32 exec_lo, exec_lo, s3                              // 00000091DCE0: 8C7E037E
	s_mov_b32 s4, 0                                            // 00000091DCE4: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000091DCE8: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 00000091DCEC: 8B6A047E
	s_cbranch_vccz 2133                                        // 00000091DCF0: BFA30855 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x4b48>
	v_mov_b32_e32 v1, 0                                        // 00000091DCF4: 7E020280
	global_load_b32 v2, v1, s[18:19]                           // 00000091DCF8: DC520000 02120001
	s_waitcnt vmcnt(0)                                         // 00000091DD00: BF8903F7
	.long 0xd72c0002                                           // 00000091DD04: D72C0002
	v_cndmask_b32_e32 v0, v2, v148, vcc_lo                     // 00000091DD08: 02012902
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091DD0C: BF870001
	v_cmp_ge_i32_e32 vcc_lo, s2, v2                            // 00000091DD10: 7C8C0402
	s_cbranch_vccnz 2124                                       // 00000091DD14: BFA4084C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x4b48>
	s_mov_b32 s3, 0                                            // 00000091DD18: BE830080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000091DD1C: BF870499
	s_lshl_b64 s[0:1], s[2:3], 4                               // 00000091DD20: 84808402
	s_add_u32 s0, s16, s0                                      // 00000091DD24: 80000010
	s_addc_u32 s1, s17, s1                                     // 00000091DD28: 82010111
	global_load_b128 v[1:4], v1, s[0:1]                        // 00000091DD2C: DC5E0000 01000001
	s_mov_b32 s0, exec_lo                                      // 00000091DD34: BE80007E
	s_waitcnt vmcnt(0)                                         // 00000091DD38: BF8903F7
	v_readfirstlane_b32 s5, v1                                 // 00000091DD3C: 7E0A0501
	v_readfirstlane_b32 s4, v2                                 // 00000091DD40: 7E080502
	v_cmpx_gt_u32_e32 0x140, v0                                // 00000091DD44: 7D9800FF 00000140
	s_cbranch_execz 52                                         // 00000091DD4C: BFA50034 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2b20>
	v_add_nc_u32_e32 v1, -1, v4                                // 00000091DD50: 4A0208C1
	v_dual_mov_b32 v5, v0 :: v_dual_lshlrev_b32 v2, 4, v0      // 00000091DD54: CA220100 05020084
	s_set_inst_prefetch_distance 0x1                           // 00000091DD5C: BF840001
	s_nop 0                                                    // 00000091DD60: BF800000
	s_nop 0                                                    // 00000091DD64: BF800000
	s_nop 0                                                    // 00000091DD68: BF800000
	s_nop 0                                                    // 00000091DD6C: BF800000
	s_nop 0                                                    // 00000091DD70: BF800000
	s_nop 0                                                    // 00000091DD74: BF800000
	s_nop 0                                                    // 00000091DD78: BF800000
	s_nop 0                                                    // 00000091DD7C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000091DD80: BF870131
	v_add_nc_u32_e32 v10, 0x100, v5                            // 00000091DD84: 4A140AFF 00000100
	v_and_b32_e32 v6, 0xffff, v5                               // 00000091DD8C: 360C0AFF 0000FFFF
	.long 0x7f103880                                           // 00000091DD94: 7F103880
	v_mul_u32_u24_e32 v6, 0xcccd, v6                           // 00000091DD98: 160C0CFF 0000CCCD
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091DDA0: BF870091
	v_lshrrev_b32_e32 v6, 22, v6                               // 00000091DDA4: 320C0C96
	v_add_nc_u32_e32 v7, v3, v6                                // 00000091DDA8: 4A0E0D03
	.long 0xd7050006                                           // 00000091DDAC: D7050006
	v_cndmask_b32_e32 v1, 0x50, v6, vcc_lo                     // 00000091DDB0: 02020CFF 00000050
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091DDB8: BF870112
	v_min_i32_e32 v7, v7, v1                                   // 00000091DDBC: 220E0307
	.long 0xd7040008                                           // 00000091DDC0: D7040008
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 00000091DDC4: 02020D05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091DDC8: BF870112
	v_mad_i64_i32 v[6:7], null, 0x500, v7, s[14:15]            // 00000091DDCC: D6FF7C06 003A0EFF 00000500
	v_lshlrev_b32_e32 v8, 4, v8                                // 00000091DDD8: 30101084
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091DDDC: BF870091
	.long 0xd7006a06                                           // 00000091DDE0: D7006A06
	v_cndmask_b32_e32 v1, v6, v8, vcc_lo                       // 00000091DDE4: 02021106
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 00000091DDE8: D5207C07 01AA0E80
	v_cmp_lt_u32_e32 vcc_lo, 63, v5                            // 00000091DDF0: 7C920ABF
	v_mov_b32_e32 v5, v10                                      // 00000091DDF4: 7E0A030A
	global_load_b128 v[6:9], v[6:7], off                       // 00000091DDF8: DC5E0000 067C0006
	s_or_b32 s3, vcc_lo, s3                                    // 00000091DE00: 8C03036A
	s_waitcnt vmcnt(0)                                         // 00000091DE04: BF8903F7
	ds_store_b128 v2, v[6:9] offset:20480                      // 00000091DE08: DB7C5000 00000602
	v_add_nc_u32_e32 v2, 0x1000, v2                            // 00000091DE10: 4A0404FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 00000091DE18: 917E037E
	s_cbranch_execnz 65496                                     // 00000091DE1C: BFA6FFD8 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2a80>
	s_set_inst_prefetch_distance 0x2                           // 00000091DE20: BF840002
	s_or_b32 exec_lo, exec_lo, s0                              // 00000091DE24: 8C7E007E
	v_lshrrev_b32_e32 v21, 5, v0                               // 00000091DE28: 322A0085
	v_dual_mov_b32 v57, 0 :: v_dual_and_b32 v22, 31, v0        // 00000091DE2C: CA240080 3916009F
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v59, 0             // 00000091DE34: CA100080 183A0080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000091DE3C: BF870243
	v_mul_u32_u24_e32 v5, 5, v21                               // 00000091DE40: 160A2A85
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v61, 0             // 00000091DE44: CA100080 383C0080
	v_mov_b32_e32 v58, 0                                       // 00000091DE4C: 7E740280
	v_mov_b32_e32 v60, 0                                       // 00000091DE50: 7E780280
	v_min_u32_e32 v6, 35, v5                                   // 00000091DE54: 260C0AA3
	s_mul_hi_i32 s2, s5, 0x96000                               // 00000091DE58: 9702FF05 00096000
	s_mul_i32 s6, s5, 0x96000                                  // 00000091DE60: 9606FF05 00096000
	s_mul_hi_i32 s3, s4, 0x7800                                // 00000091DE68: 9703FF04 00007800
	s_mul_i32 s7, s4, 0x7800                                   // 00000091DE70: 9607FF04 00007800
	v_add_nc_u32_e32 v52, 5, v6                                // 00000091DE78: 4A680C85
	s_waitcnt lgkmcnt(0)                                       // 00000091DE7C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000091DE80: BC7C0000
	s_barrier                                                  // 00000091DE84: BFBD0000
	buffer_gl0_inv                                             // 00000091DE88: E0AC0000 00000000
	v_cmp_lt_u32_e32 vcc_lo, v5, v52                           // 00000091DE90: 7C926905
	s_and_saveexec_b32 s1, vcc_lo                              // 00000091DE94: BE81206A
	s_cbranch_execz 30                                         // 00000091DE98: BFA5001E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2c14>
	v_mul_u32_u24_e32 v1, 0xf00, v21                           // 00000091DE9C: 16022AFF 00000F00
	s_add_u32 s0, s12, s6                                      // 00000091DEA4: 8000060C
	s_addc_u32 s8, s13, s2                                     // 00000091DEA8: 8208020D
	s_add_u32 s0, s0, s7                                       // 00000091DEAC: 80000700
	s_addc_u32 s8, s8, s3                                      // 00000091DEB0: 82080308
	v_lshlrev_b32_e32 v2, 2, v22                               // 00000091DEB4: 30042C82
	.long 0xd7000001                                           // 00000091DEB8: D7000001
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 00000091DEBC: 02020200
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091DEC0: BF870111
	v_add_co_ci_u32_e64 v7, null, s8, 0, s0                    // 00000091DEC4: D5207C07 00010008
	.long 0xd7000001                                           // 00000091DECC: D7000001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000091DED0: 02020501
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091DED4: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v7, s0                    // 00000091DED8: D5207C02 00020E80
	s_clause 0x5                                               // 00000091DEE0: BF850005
	global_load_b32 v56, v[1:2], off                           // 00000091DEE4: DC520000 387C0001
	global_load_b32 v57, v[1:2], off offset:128                // 00000091DEEC: DC520080 397C0001
	global_load_b32 v58, v[1:2], off offset:256                // 00000091DEF4: DC520100 3A7C0001
	global_load_b32 v59, v[1:2], off offset:384                // 00000091DEFC: DC520180 3B7C0001
	global_load_b32 v60, v[1:2], off offset:512                // 00000091DF04: DC520200 3C7C0001
	global_load_b32 v61, v[1:2], off offset:640                // 00000091DF0C: DC520280 3D7C0001
	s_or_b32 exec_lo, exec_lo, s1                              // 00000091DF14: 8C7E017E
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v54, 0             // 00000091DF18: CA100080 37360080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v50, 0             // 00000091DF20: CA100080 35320080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v48, 0             // 00000091DF28: CA100080 33300080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v46, 0             // 00000091DF30: CA100080 312E0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v44, 0             // 00000091DF38: CA100080 2F2C0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v42, 0             // 00000091DF40: CA100080 2D2A0080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v40, 0             // 00000091DF48: CA100080 2B280080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v38, 0             // 00000091DF50: CA100080 29260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v36, 0             // 00000091DF58: CA100080 27240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v34, 0             // 00000091DF60: CA100080 25220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v32, 0             // 00000091DF68: CA100080 23200080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v30, 0             // 00000091DF70: CA100080 211E0080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v26, 0             // 00000091DF78: CA100080 191A0080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v28, 0             // 00000091DF80: CA100080 1F1C0080
	v_mov_b32_e32 v29, 0                                       // 00000091DF88: 7E3A0280
	v_mov_b32_e32 v27, 0                                       // 00000091DF8C: 7E360280
	v_mov_b32_e32 v23, 0                                       // 00000091DF90: 7E2E0280
	s_and_saveexec_b32 s1, vcc_lo                              // 00000091DF94: BE81206A
	s_cbranch_execz 1201                                       // 00000091DF98: BFA504B1 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x3f60>
	v_lshl_or_b32 v7, v22, 3, 4                                // 00000091DF9C: D6560007 02110716
	v_mad_u32_u24 v8, v22, 24, 0x2f0                           // 00000091DFA4: D60B0008 03FD3116 000002F0
	v_cmp_ne_u32_e32 vcc_lo, 0, v22                            // 00000091DFB0: 7C9A2C80
	s_movk_i32 s0, 0x320                                       // 00000091DFB4: B0000320
	v_dual_mov_b32 v28, 0 :: v_dual_lshlrev_b32 v11, 2, v22    // 00000091DFB8: CA220080 1C0A2C82
	v_mad_u32_u24 v10, v7, 3, 0x2f0                            // 00000091DFC0: D60B000A 03FD0707 000002F0
	v_lshrrev_b32_e32 v1, 5, v8                                // 00000091DFCC: 32021085
	v_mad_u32_u24 v13, v21, s0, 0x5000                         // 00000091DFD0: D60B000D 03FC0115 00005000
	v_mul_i32_i24_e32 v15, -3, v7                              // 00000091DFDC: 121E0EC3
	s_add_u32 s6, s6, s7                                       // 00000091DFE0: 80060706
	v_lshrrev_b32_e32 v12, 5, v10                              // 00000091DFE4: 32181485
	v_subrev_nc_u32_e32 v14, 24, v1                            // 00000091DFE8: 4E1C0298
	v_mov_b32_e32 v23, 0                                       // 00000091DFEC: 7E2E0280
	s_addc_u32 s7, s2, s3                                      // 00000091DFF0: 82070302
	v_mul_i32_i24_e32 v9, 0xffffffe8, v22                      // 00000091DFF4: 12122CFF FFFFFFE8
	v_subrev_nc_u32_e32 v12, 24, v12                           // 00000091DFFC: 4E181898
	v_cndmask_b32_e32 v14, 23, v14, vcc_lo                     // 00000091E000: 021C1C97
	v_cmp_lt_u32_e32 vcc_lo, 5, v7                             // 00000091E004: 7C920E85
	v_mad_u64_u32 v[1:2], null, 0x300, v5, s[6:7]              // 00000091E008: D6FE7C01 001A0AFF 00000300
	v_dual_mov_b32 v27, 0 :: v_dual_and_b32 v10, 0x7e0, v10    // 00000091E014: CA240080 1B0A14FF 000007E0
	v_sub_nc_u32_e32 v65, 0, v6                                // 00000091E020: 4C820C80
	v_dual_cndmask_b32 v7, 23, v12 :: v_dual_add_nc_u32 v12, v13, v11// 00000091E024: CA601897 070C170D
	v_cmp_gt_i32_e32 vcc_lo, 23, v14                           // 00000091E02C: 7C881C97
	v_mov_b32_e32 v26, 0                                       // 00000091E030: 7E340280
	v_add3_u32 v63, v15, v10, 0xfffffd34                       // 00000091E034: D655003F 03FE150F FFFFFD34
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091E040: BF870004
	v_add_nc_u32_e32 v17, 1, v7                                // 00000091E044: 4A220E81
	v_subrev_nc_u32_e32 v18, 23, v7                            // 00000091E048: 4E240E97
	v_cndmask_b32_e64 v16, 0xffffffe9, 1, vcc_lo               // 00000091E04C: D5010010 01A902FF FFFFFFE9
	v_lshl_add_u32 v10, v14, 2, v13                            // 00000091E058: D646000A 0435050E
	v_lshl_add_u32 v7, v7, 2, v13                              // 00000091E060: D6460007 04350507
	v_cmp_gt_u32_e32 vcc_lo, 24, v17                           // 00000091E068: 7C982298
	v_dual_mov_b32 v29, 0 :: v_dual_and_b32 v8, 0x7e0, v8      // 00000091E06C: CA240080 1D0810FF 000007E0
	v_dual_mov_b32 v31, 0 :: v_dual_add_nc_u32 v66, 1, v5      // 00000091E078: CA200080 1F420A81
	v_dual_mov_b32 v32, 0 :: v_dual_add_nc_u32 v67, 0x1400, v12// 00000091E080: CA200080 204218FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000091E08C: BF8701D3
	v_add3_u32 v62, v9, v8, 0xfffffd34                         // 00000091E090: D655003E 03FE1109 FFFFFD34
	v_cndmask_b32_e32 v9, v18, v17, vcc_lo                     // 00000091E09C: 02122312
	.long 0xd7006a01                                           // 00000091E0A0: D7006A01
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 00000091E0A4: 02021701
	v_add_nc_u32_e32 v8, v16, v14                              // 00000091E0A8: 4A101D10
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000091E0AC: D5207C02 01AA0480
	.long 0xd7006a01                                           // 00000091E0B4: D7006A01
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 00000091E0B8: 0202020C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000091E0BC: BF8701D3
	v_lshl_add_u32 v8, v8, 2, v13                              // 00000091E0C0: D6460008 04350508
	v_lshl_add_u32 v9, v9, 2, v13                              // 00000091E0C8: D6460009 04350509
	v_dual_mov_b32 v30, 0 :: v_dual_and_b32 v11, 16, v0        // 00000091E0D0: CA240080 1E0A0090
	v_add_co_ci_u32_e64 v2, null, s13, v2, vcc_lo              // 00000091E0D8: D5207C02 01AA040D
	.long 0xd7006a01                                           // 00000091E0E0: D7006A01
	v_cndmask_b32_e32 v1, 0x300, v1, vcc_lo                    // 00000091E0E4: 020202FF 00000300
	v_lshl_or_b32 v64, v5, 5, v11                              // 00000091E0EC: D6560040 042D0B05
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091E0F4: BF870003
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000091E0F8: D5207C02 01AA0480
	v_dual_mov_b32 v25, 0 :: v_dual_add_nc_u32 v68, 0x1400, v10// 00000091E100: CA200080 194414FF 00001400
	v_dual_mov_b32 v34, 0 :: v_dual_add_nc_u32 v69, 0x1400, v8 // 00000091E10C: CA200080 224410FF 00001400
	v_dual_mov_b32 v33, 0 :: v_dual_add_nc_u32 v70, 0x1400, v7 // 00000091E118: CA200080 21460EFF 00001400
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v71, 0x1400, v9 // 00000091E124: CA200080 244612FF 00001400
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v38, 0             // 00000091E130: CA100080 23260080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v40, 0             // 00000091E138: CA100080 25280080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v42, 0             // 00000091E140: CA100080 272A0080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v44, 0             // 00000091E148: CA100080 292C0080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v46, 0             // 00000091E150: CA100080 2B2E0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v48, 0             // 00000091E158: CA100080 2D300080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v50, 0             // 00000091E160: CA100080 2F320080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v54, 0             // 00000091E168: CA100080 31360080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v24, 0             // 00000091E170: CA100080 33180080
	v_mov_b32_e32 v53, 0                                       // 00000091E178: 7E6A0280
	v_mov_b32_e32 v55, 0                                       // 00000091E17C: 7E6E0280
	s_mov_b32 s2, 0                                            // 00000091E180: BE820080
	s_movk_i32 s3, 0x1eee                                      // 00000091E184: B0031EEE
	s_branch 1049                                              // 00000091E188: BFA00419 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x3ef0>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000091E18C: 8C7E007E
	ds_load_2addr_b32 v[72:73], v69 offset1:24                 // 00000091E190: D8DC1800 48000045
	ds_load_2addr_b32 v[74:75], v71 offset1:24                 // 00000091E198: D8DC1800 4A000047
	ds_load_2addr_b32 v[14:15], v68 offset1:24                 // 00000091E1A0: D8DC1800 0E000044
	ds_load_2addr_b32 v[78:79], v70 offset1:24                 // 00000091E1A8: D8DC1800 4E000046
	ds_load_b128 v[9:12], v64 offset:20480                     // 00000091E1B0: DBFC5000 09000040
	ds_load_b128 v[5:8], v64 offset:21760                      // 00000091E1B8: DBFC5500 05000040
	.long 0xd7000001                                           // 00000091E1C0: D7000001
	v_cndmask_b32_e32 v1, 0x300, v1, vcc_lo                    // 00000091E1C4: 020202FF 00000300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091E1CC: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 00000091E1D0: D5207C02 00020480
	s_waitcnt lgkmcnt(5)                                       // 00000091E1D8: BF89FC57
	v_dual_mov_b32 v13, v72 :: v_dual_add_nc_u32 v66, 1, v66   // 00000091E1DC: CA200148 0D428481
	s_waitcnt lgkmcnt(3)                                       // 00000091E1E4: BF89FC37
	v_dual_mov_b32 v77, v74 :: v_dual_mov_b32 v74, v15         // 00000091E1E8: CA10014A 4D4A010F
	s_waitcnt lgkmcnt(2)                                       // 00000091E1F0: BF89FC27
	v_mov_b32_e32 v76, v79                                     // 00000091E1F4: 7E98034F
	.long 0xd73d004f                                           // 00000091E1F8: D73D004F
	v_cndmask_b32_e32 v1, v62, v13, vcc_lo                     // 00000091E1FC: 02021B3E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091E200: BF870223
	.long 0xd73d004d                                           // 00000091E204: D73D004D
	v_cndmask_b32_e32 v1, v63, v77, vcc_lo                     // 00000091E208: 02029B3F
	.long 0xd73d0048                                           // 00000091E20C: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 00000091E210: 0202933E
	.long 0xd73d0049                                           // 00000091E214: D73D0049
	v_cndmask_b32_e32 v1, v63, v75, vcc_lo                     // 00000091E218: 0202973F
	ds_load_b128 v[13:16], v64 offset:23040                    // 00000091E21C: DBFC5A00 0D000040
	ds_load_b128 v[17:20], v64 offset:24320                    // 00000091E224: DBFC5F00 11000040
	v_add_nc_u32_e32 v64, 32, v64                              // 00000091E22C: 4A8080A0
	v_bfe_u32 v74, v79, 9, 16                                  // 00000091E230: D610004A 0241134F
	v_bfe_u32 v75, v79, 6, 16                                  // 00000091E238: D610004B 02410D4F
	v_bfe_u32 v76, v79, 3, 16                                  // 00000091E240: D610004C 0241074F
	v_bfe_u32 v80, v77, 6, 16                                  // 00000091E248: D6100050 02410D4D
	v_bfe_u32 v81, v77, 3, 16                                  // 00000091E250: D6100051 0241074D
	.long 0xd72c004a                                           // 00000091E258: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 00000091E25C: 020294FF 83DCD12D
	.long 0xd72c004b                                           // 00000091E264: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000091E268: 020296FF 83DCD12D
	.long 0xd72c004c                                           // 00000091E270: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 00000091E274: 020298FF 83DCD12D
	.long 0xd72c0050                                           // 00000091E27C: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 00000091E280: 0202A0FF 83DCD12D
	.long 0xd72c0051                                           // 00000091E288: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 00000091E28C: 0202A2FF 83DCD12D
	v_bfe_u32 v82, v72, 9, 16                                  // 00000091E294: D6100052 02411348
	v_bfe_u32 v83, v72, 6, 16                                  // 00000091E29C: D6100053 02410D48
	v_bfe_u32 v84, v72, 3, 16                                  // 00000091E2A4: D6100054 02410748
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000091E2AC: D622004A 03FD014A 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000091E2B8: D622004B 03FD014B 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000091E2C4: D622004C 03FD014C 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 00000091E2D0: D6220050 03FD0150 00006400
	.long 0xd72c0052                                           // 00000091E2DC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000091E2E0: 0202A4FF 83DCD12D
	v_and_b32_e32 v74, 0xffff, v74                             // 00000091E2E8: 369494FF 0000FFFF
	.long 0xd72c0053                                           // 00000091E2F0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 00000091E2F4: 0202A6FF 83DCD12D
	v_bfe_u32 v85, v73, 9, 16                                  // 00000091E2FC: D6100055 02411349
	v_bfe_u32 v86, v73, 6, 16                                  // 00000091E304: D6100056 02410D49
	.long 0xd72c0054                                           // 00000091E30C: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 00000091E310: 0202A8FF 83DCD12D
	v_lshl_or_b32 v74, v75, 16, v74                            // 00000091E318: D656004A 0529214B
	v_sad_u8 v75, v81, 0, 0x6400                               // 00000091E320: D622004B 03FD0151 00006400
	v_bfe_u32 v87, v73, 3, 16                                  // 00000091E32C: D6100057 02410749
	v_and_b32_e32 v73, 0xffff, v73                             // 00000091E334: 369292FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000091E33C: BF8701C4
	v_pk_fma_f16 v74, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091E340: CC0E004A 0BFC074A 0000C931
	v_and_b32_e32 v78, 0xffff, v79                             // 00000091E34C: 369C9EFF 0000FFFF
	v_bfe_u32 v79, v77, 9, 16                                  // 00000091E354: D610004F 0241134D
	s_waitcnt lgkmcnt(2)                                       // 00000091E35C: BF89FC27
	v_dual_dot2acc_f32_f16 v27, v74, v5 :: v_dual_and_b32 v72, 0xffff, v72// 00000091E360: CB240B4A 1B4890FF 0000FFFF
	v_dot2acc_f32_f16 v23, v74, v9                             // 00000091E36C: 042E134A
	.long 0xd72c004e                                           // 00000091E370: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 00000091E374: 02029CFF 83DCD12D
	.long 0xd72c004f                                           // 00000091E37C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 00000091E380: 02029EFF 83DCD12D
	s_waitcnt lgkmcnt(1)                                       // 00000091E388: BF89FC17
	v_dot2acc_f32_f16 v28, v74, v13                            // 00000091E38C: 04381B4A
	.long 0xd72c0048                                           // 00000091E390: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 00000091E394: 020290FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091E39C: BF870214
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000091E3A0: D622004E 03FD014E 00006400
	v_sad_u8 v79, v79, 0, 0x6400                               // 00000091E3AC: D622004F 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091E3B8: BF870193
	v_sad_u8 v72, v72, 0, 0x6400                               // 00000091E3BC: D6220048 03FD0148 00006400
	v_lshlrev_b32_e32 v78, 16, v78                             // 00000091E3C8: 309C9C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091E3CC: BF870113
	v_and_b32_e32 v79, 0xffff, v79                             // 00000091E3D0: 369E9EFF 0000FFFF
	v_and_or_b32 v76, 0xffff, v76, v78                         // 00000091E3D8: D657004C 053A98FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000091E3E4: BF870232
	v_lshl_or_b32 v79, v80, 16, v79                            // 00000091E3E8: D656004F 053D2150
	.long 0xd72c004e                                           // 00000091E3F0: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 00000091E3F4: 0202AAFF 83DCD12D
	.long 0xd72c0050                                           // 00000091E3FC: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 00000091E400: 020292FF 83DCD12D
	v_pk_fma_f16 v76, v76, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091E408: CC0E004C 0BFC074C 0000C931
	v_and_b32_e32 v77, 0xffff, v77                             // 00000091E414: 369A9AFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 00000091E41C: BF89FC07
	v_dot2acc_f32_f16 v26, v74, v17                            // 00000091E420: 0434234A
	v_sad_u8 v74, v82, 0, 0x6400                               // 00000091E424: D622004A 03FD0152 00006400
	.long 0xd72c0052                                           // 00000091E430: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 00000091E434: 0202AEFF 83DCD12D
	v_dot2acc_f32_f16 v28, v76, v14                            // 00000091E43C: 04381D4C
	.long 0xd72c004d                                           // 00000091E440: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 00000091E444: 02029AFF 83DCD12D
	v_dot2acc_f32_f16 v23, v76, v10                            // 00000091E44C: 042E154C
	v_dot2acc_f32_f16 v26, v76, v18                            // 00000091E450: 0434254C
	v_and_b32_e32 v74, 0xffff, v74                             // 00000091E454: 369494FF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000091E45C: D622004E 03FD014E 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 00000091E468: D6220052 03FD0152 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 00000091E474: D622004D 03FD014D 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091E480: BF870091
	v_lshlrev_b32_e32 v77, 16, v77                             // 00000091E484: 309A9A90
	v_and_or_b32 v75, 0xffff, v75, v77                         // 00000091E488: D657004B 053696FF 0000FFFF
	v_pk_fma_f16 v77, v79, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091E494: CC0E004D 0BFC074F 0000C931
	v_dot2acc_f32_f16 v27, v76, v6                             // 00000091E4A0: 04360D4C
	v_sad_u8 v76, v84, 0, 0x6400                               // 00000091E4A4: D622004C 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091E4B0: BF870214
	v_pk_fma_f16 v79, v75, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091E4B4: CC0E004F 0BFC074B 0000C931
	v_dot2acc_f32_f16 v28, v77, v15                            // 00000091E4C0: 04381F4D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091E4C4: BF870004
	v_dot2acc_f32_f16 v27, v77, v7                             // 00000091E4C8: 04360F4D
	v_sad_u8 v75, v83, 0, 0x6400                               // 00000091E4CC: D622004B 03FD0153 00006400
	v_dot2acc_f32_f16 v23, v77, v11                            // 00000091E4D8: 042E174D
	v_dot2acc_f32_f16 v26, v77, v19                            // 00000091E4DC: 0434274D
	.long 0xd72c004d                                           // 00000091E4E0: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 00000091E4E4: 0202ACFF 83DCD12D
	v_dot2acc_f32_f16 v27, v79, v8                             // 00000091E4EC: 0436114F
	v_lshl_or_b32 v74, v75, 16, v74                            // 00000091E4F0: D656004A 0529214B
	v_dot2acc_f32_f16 v28, v79, v16                            // 00000091E4F8: 0438214F
	v_dot2acc_f32_f16 v23, v79, v12                            // 00000091E4FC: 042E194F
	v_dot2acc_f32_f16 v26, v79, v20                            // 00000091E500: 0434294F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091E504: BF870004
	v_pk_fma_f16 v83, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091E508: CC0E0053 0BFC074A 0000C931
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000091E514: 30909090
	v_and_b32_e32 v78, 0xffff, v78                             // 00000091E518: 369C9CFF 0000FFFF
	v_sad_u8 v77, v77, 0, 0x6400                               // 00000091E520: D622004D 03FD014D 00006400
	v_sad_u8 v74, v80, 0, 0x6400                               // 00000091E52C: D622004A 03FD0150 00006400
	v_dot2acc_f32_f16 v29, v83, v9                             // 00000091E538: 043A1353
	v_and_or_b32 v81, 0xffff, v76, v72                         // 00000091E53C: D6570051 052298FF 0000FFFF
	ds_load_2addr_b32 v[72:73], v69 offset0:48 offset1:72      // 00000091E548: D8DC4830 48000045
	ds_load_2addr_b32 v[75:76], v68 offset0:48 offset1:72      // 00000091E550: D8DC4830 4B000044
	v_dot2acc_f32_f16 v31, v83, v13                            // 00000091E558: 043E1B53
	v_lshl_or_b32 v85, v77, 16, v78                            // 00000091E55C: D6560055 0539214D
	ds_load_2addr_b32 v[77:78], v71 offset0:48 offset1:72      // 00000091E564: D8DC4830 4D000047
	v_pk_fma_f16 v84, v81, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091E56C: CC0E0054 0BFC0751 0000C931
	v_dot2acc_f32_f16 v30, v83, v5                             // 00000091E578: 043C0B53
	ds_load_2addr_b32 v[80:81], v70 offset0:48 offset1:72      // 00000091E57C: D8DC4830 50000046
	v_pk_fma_f16 v85, v85, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091E584: CC0E0055 0BFC0755 0000C931
	v_dual_dot2acc_f32_f16 v32, v83, v17 :: v_dual_dot2acc_f32_f16 v29, v84, v10// 00000091E590: CB182353 201C1554
	v_lshlrev_b32_e32 v74, 16, v74                             // 00000091E598: 30949490
	v_dot2acc_f32_f16 v31, v84, v14                            // 00000091E59C: 043E1D54
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091E5A0: BF870193
	v_dual_dot2acc_f32_f16 v30, v84, v6 :: v_dual_dot2acc_f32_f16 v29, v85, v11// 00000091E5A4: CB180D54 1E1C1755
	v_and_or_b32 v82, 0xffff, v82, v74                         // 00000091E5AC: D6570052 052AA4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091E5B8: BF870193
	v_dot2acc_f32_f16 v31, v85, v15                            // 00000091E5BC: 043E1F55
	v_dot2acc_f32_f16 v30, v85, v7                             // 00000091E5C0: 043C0F55
	s_waitcnt lgkmcnt(3)                                       // 00000091E5C4: BF89FC37
	v_mov_b32_e32 v74, v72                                     // 00000091E5C8: 7E940348
	v_pk_fma_f16 v72, v82, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091E5CC: CC0E0048 0BFC0752 0000C931
	s_waitcnt lgkmcnt(1)                                       // 00000091E5D8: BF89FC17
	v_mov_b32_e32 v79, v77                                     // 00000091E5DC: 7E9E034D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091E5E0: BF870193
	.long 0xd73d004a                                           // 00000091E5E4: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 00000091E5E8: 0202953E
	v_dot2acc_f32_f16 v29, v72, v12                            // 00000091E5EC: 043A1948
	s_waitcnt lgkmcnt(0)                                       // 00000091E5F0: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091E5F4: BF870223
	.long 0xd73d004f                                           // 00000091E5F8: D73D004F
	v_cndmask_b32_e32 v1, v63, v79, vcc_lo                     // 00000091E5FC: 02029F3F
	v_dot2acc_f32_f16 v30, v72, v8                             // 00000091E600: 043C1148
	v_bfe_u32 v75, v74, 9, 16                                  // 00000091E604: D610004B 0241134A
	v_and_b32_e32 v77, 0xffff, v74                             // 00000091E60C: 369A94FF 0000FFFF
	v_bfe_u32 v80, v74, 6, 16                                  // 00000091E614: D6100050 02410D4A
	v_bfe_u32 v74, v74, 3, 16                                  // 00000091E61C: D610004A 0241074A
	v_bfe_u32 v82, v79, 9, 16                                  // 00000091E624: D6100052 0241134F
	.long 0xd72c004b                                           // 00000091E62C: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000091E630: 020296FF 83DCD12D
	.long 0xd72c004d                                           // 00000091E638: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 00000091E63C: 02029AFF 83DCD12D
	v_bfe_u32 v83, v79, 6, 16                                  // 00000091E644: D6100053 02410D4F
	.long 0xd72c0050                                           // 00000091E64C: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 00000091E650: 0202A0FF 83DCD12D
	.long 0xd72c004a                                           // 00000091E658: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 00000091E65C: 020294FF 83DCD12D
	.long 0xd72c0052                                           // 00000091E664: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000091E668: 0202A4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091E670: BF870004
	.long 0xd72c0053                                           // 00000091E674: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 00000091E678: 0202A6FF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000091E680: D622004B 03FD014B 00006400
	v_dot2acc_f32_f16 v32, v84, v18                            // 00000091E68C: 04402554
	v_bfe_u32 v84, v79, 3, 16                                  // 00000091E690: D6100054 0241074F
	v_and_b32_e32 v79, 0xffff, v79                             // 00000091E698: 369E9EFF 0000FFFF
	v_sad_u8 v77, v77, 0, 0x6400                               // 00000091E6A0: D622004D 03FD014D 00006400
	v_and_b32_e32 v75, 0xffff, v75                             // 00000091E6AC: 369696FF 0000FFFF
	v_dual_dot2acc_f32_f16 v31, v72, v16 :: v_dual_dot2acc_f32_f16 v32, v85, v19// 00000091E6B4: CB182148 1F202755
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000091E6BC: BF870234
	.long 0xd72c004f                                           // 00000091E6C0: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 00000091E6C4: 02029EFF 83DCD12D
	v_sad_u8 v80, v80, 0, 0x6400                               // 00000091E6CC: D6220050 03FD0150 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000091E6D8: D622004A 03FD014A 00006400
	v_dual_dot2acc_f32_f16 v32, v72, v20 :: v_dual_lshlrev_b32 v77, 16, v77// 00000091E6E4: CB222948 204C9A90
	.long 0xd72c0054                                           // 00000091E6EC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 00000091E6F0: 0202A8FF 83DCD12D
	v_sad_u8 v82, v82, 0, 0x6400                               // 00000091E6F8: D6220052 03FD0152 00006400
	v_lshl_or_b32 v75, v80, 16, v75                            // 00000091E704: D656004B 052D2150
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000091E70C: BF870234
	v_and_or_b32 v74, 0xffff, v74, v77                         // 00000091E710: D657004A 053694FF 0000FFFF
	v_sad_u8 v79, v79, 0, 0x6400                               // 00000091E71C: D622004F 03FD014F 00006400
	v_sad_u8 v80, v83, 0, 0x6400                               // 00000091E728: D6220050 03FD0153 00006400
	v_pk_fma_f16 v75, v75, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091E734: CC0E004B 0BFC074B 0000C931
	v_and_b32_e32 v77, 0xffff, v82                             // 00000091E740: 369AA4FF 0000FFFF
	v_pk_fma_f16 v82, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091E748: CC0E0052 0BFC074A 0000C931
	v_sad_u8 v74, v84, 0, 0x6400                               // 00000091E754: D622004A 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091E760: BF870214
	v_dual_dot2acc_f32_f16 v34, v75, v13 :: v_dual_lshlrev_b32 v79, 16, v79// 00000091E764: CB221B4B 224E9E90
	v_lshl_or_b32 v77, v80, 16, v77                            // 00000091E76C: D656004D 05352150
	v_dot2acc_f32_f16 v25, v75, v9                             // 00000091E774: 0432134B
	v_dot2acc_f32_f16 v35, v75, v17                            // 00000091E778: 0446234B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000091E77C: BF870244
	v_and_or_b32 v72, 0xffff, v74, v79                         // 00000091E780: D6570048 053E94FF 0000FFFF
	v_dual_mov_b32 v74, v76 :: v_dual_mov_b32 v79, v81         // 00000091E78C: CA10014C 4A4E0151
	v_pk_fma_f16 v77, v77, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091E794: CC0E004D 0BFC074D 0000C931
	v_dot2acc_f32_f16 v34, v82, v14                            // 00000091E7A0: 04441D52
	v_pk_fma_f16 v83, v72, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091E7A4: CC0E0053 0BFC0748 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091E7B0: BF870004
	.long 0xd73d0048                                           // 00000091E7B4: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 00000091E7B8: 0202933E
	v_dot2acc_f32_f16 v33, v75, v5                             // 00000091E7BC: 04420B4B
	.long 0xd73d0049                                           // 00000091E7C0: D73D0049
	v_cndmask_b32_e32 v1, v63, v78, vcc_lo                     // 00000091E7C4: 02029D3F
	v_dual_dot2acc_f32_f16 v34, v77, v15 :: v_dual_dot2acc_f32_f16 v25, v82, v10// 00000091E7C8: CB181F4D 22181552
	v_dot2acc_f32_f16 v35, v82, v18                            // 00000091E7D0: 04462552
	v_bfe_u32 v75, v72, 9, 16                                  // 00000091E7D4: D610004B 02411348
	v_dual_dot2acc_f32_f16 v33, v82, v6 :: v_dual_and_b32 v76, 0xffff, v72// 00000091E7DC: CB240D52 214C90FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091E7E8: BF870224
	v_dot2acc_f32_f16 v34, v83, v16                            // 00000091E7EC: 04442153
	v_bfe_u32 v78, v73, 6, 16                                  // 00000091E7F0: D610004E 02410D49
	.long 0xd72c004a                                           // 00000091E7F8: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000091E7FC: 020296FF 83DCD12D
	v_bfe_u32 v75, v72, 6, 16                                  // 00000091E804: D610004B 02410D48
	v_bfe_u32 v72, v72, 3, 16                                  // 00000091E80C: D6100048 02410748
	.long 0xd72c004c                                           // 00000091E814: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 00000091E818: 020298FF 83DCD12D
	.long 0xd72c004e                                           // 00000091E820: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 00000091E824: 02029CFF 83DCD12D
	v_bfe_u32 v79, v73, 3, 16                                  // 00000091E82C: D610004F 02410749
	.long 0xd72c004b                                           // 00000091E834: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000091E838: 020296FF 83DCD12D
	.long 0xd72c0048                                           // 00000091E840: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 00000091E844: 020290FF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000091E84C: D622004A 03FD014A 00006400
	v_dot2acc_f32_f16 v25, v77, v11                            // 00000091E858: 0432174D
	.long 0xd72c004f                                           // 00000091E85C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 00000091E860: 02029EFF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000091E868: D622004C 03FD014C 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000091E874: BF870234
	v_dual_dot2acc_f32_f16 v33, v77, v7 :: v_dual_and_b32 v74, 0xffff, v74// 00000091E878: CB240F4D 214A94FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000091E884: D622004B 03FD014B 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 00000091E890: D6220048 03FD0148 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 00000091E89C: 30989890
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000091E8A0: D622004E 03FD014E 00006400
	v_sad_u8 v79, v79, 0, 0x6400                               // 00000091E8AC: D622004F 03FD014F 00006400
	v_lshl_or_b32 v74, v75, 16, v74                            // 00000091E8B8: D656004A 0529214B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000091E8C0: BF8701D4
	v_and_or_b32 v81, 0xffff, v72, v76                         // 00000091E8C4: D6570051 053290FF 0000FFFF
	ds_load_2addr_b32 v[75:76], v68 offset0:96 offset1:120     // 00000091E8D0: D8DC7860 4B000044
	v_pk_fma_f16 v82, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091E8D8: CC0E0052 0BFC074A 0000C931
	v_dot2acc_f32_f16 v33, v83, v8                             // 00000091E8E4: 04421153
	v_pk_fma_f16 v84, v81, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091E8E8: CC0E0054 0BFC0751 0000C931
	v_dual_dot2acc_f32_f16 v25, v83, v12 :: v_dual_dot2acc_f32_f16 v36, v82, v9// 00000091E8F4: CB181953 19241352
	v_dual_dot2acc_f32_f16 v38, v82, v13 :: v_dual_dot2acc_f32_f16 v35, v77, v19// 00000091E8FC: CB181B52 2622274D
	v_bfe_u32 v77, v73, 9, 16                                  // 00000091E904: D610004D 02411349
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091E90C: BF870193
	v_dual_dot2acc_f32_f16 v39, v82, v17 :: v_dual_dot2acc_f32_f16 v36, v84, v10// 00000091E910: CB182352 27241554
	v_dot2acc_f32_f16 v38, v84, v14                            // 00000091E918: 044C1D54
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091E91C: BF870193
	.long 0xd72c004d                                           // 00000091E920: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 00000091E924: 02029AFF 83DCD12D
	v_dot2acc_f32_f16 v39, v84, v18                            // 00000091E92C: 044E2554
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091E930: BF870092
	v_sad_u8 v77, v77, 0, 0x6400                               // 00000091E934: D622004D 03FD014D 00006400
	v_and_b32_e32 v77, 0xffff, v77                             // 00000091E940: 369A9AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000091E948: BF8700B1
	v_lshl_or_b32 v85, v78, 16, v77                            // 00000091E94C: D6560055 0535214E
	ds_load_2addr_b32 v[77:78], v71 offset0:96 offset1:120     // 00000091E954: D8DC7860 4D000047
	v_pk_fma_f16 v85, v85, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091E95C: CC0E0055 0BFC0755 0000C931
	v_dual_dot2acc_f32_f16 v36, v85, v11 :: v_dual_and_b32 v73, 0xffff, v73// 00000091E968: CB241755 244892FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091E974: BF870001
	.long 0xd72c0050                                           // 00000091E978: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 00000091E97C: 020292FF 83DCD12D
	ds_load_2addr_b32 v[72:73], v69 offset0:96 offset1:120     // 00000091E984: D8DC7860 48000045
	v_dot2acc_f32_f16 v38, v85, v15                            // 00000091E98C: 044C1F55
	v_dot2acc_f32_f16 v39, v85, v19                            // 00000091E990: 044E2755
	v_sad_u8 v74, v80, 0, 0x6400                               // 00000091E994: D622004A 03FD0150 00006400
	ds_load_2addr_b32 v[80:81], v70 offset0:96 offset1:120     // 00000091E9A0: D8DC7860 50000046
	v_lshlrev_b32_e32 v74, 16, v74                             // 00000091E9A8: 30949490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000091E9AC: BF870131
	v_and_or_b32 v79, 0xffff, v79, v74                         // 00000091E9B0: D657004F 052A9EFF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 00000091E9BC: BF89FC17
	v_mov_b32_e32 v74, v72                                     // 00000091E9C0: 7E940348
	v_pk_fma_f16 v72, v79, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091E9C4: CC0E0048 0BFC074F 0000C931
	v_mov_b32_e32 v79, v77                                     // 00000091E9D0: 7E9E034D
	v_dot2acc_f32_f16 v37, v82, v5                             // 00000091E9D4: 044A0B52
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091E9D8: BF870214
	.long 0xd73d004a                                           // 00000091E9DC: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 00000091E9E0: 0202953E
	v_dot2acc_f32_f16 v36, v72, v12                            // 00000091E9E4: 04481948
	s_waitcnt lgkmcnt(0)                                       // 00000091E9E8: BF89FC07
	.long 0xd73d004f                                           // 00000091E9EC: D73D004F
	v_cndmask_b32_e32 v1, v63, v79, vcc_lo                     // 00000091E9F0: 02029F3F
	v_dot2acc_f32_f16 v38, v72, v16                            // 00000091E9F4: 044C2148
	v_dot2acc_f32_f16 v39, v72, v20                            // 00000091E9F8: 044E2948
	v_bfe_u32 v75, v74, 9, 16                                  // 00000091E9FC: D610004B 0241134A
	v_and_b32_e32 v77, 0xffff, v74                             // 00000091EA04: 369A94FF 0000FFFF
	v_bfe_u32 v80, v74, 6, 16                                  // 00000091EA0C: D6100050 02410D4A
	v_bfe_u32 v74, v74, 3, 16                                  // 00000091EA14: D610004A 0241074A
	v_bfe_u32 v82, v79, 9, 16                                  // 00000091EA1C: D6100052 0241134F
	.long 0xd72c004b                                           // 00000091EA24: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000091EA28: 020296FF 83DCD12D
	.long 0xd72c004d                                           // 00000091EA30: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 00000091EA34: 02029AFF 83DCD12D
	.long 0xd72c0050                                           // 00000091EA3C: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 00000091EA40: 0202A0FF 83DCD12D
	.long 0xd72c004a                                           // 00000091EA48: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 00000091EA4C: 020294FF 83DCD12D
	.long 0xd72c0052                                           // 00000091EA54: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000091EA58: 0202A4FF 83DCD12D
	v_bfe_u32 v86, v79, 3, 16                                  // 00000091EA60: D6100056 0241074F
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000091EA68: D622004B 03FD014B 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 00000091EA74: D622004D 03FD014D 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 00000091EA80: D6220050 03FD0150 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000091EA8C: D622004A 03FD014A 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 00000091EA98: D6220052 03FD0152 00006400
	v_and_b32_e32 v75, 0xffff, v75                             // 00000091EAA4: 369696FF 0000FFFF
	v_lshlrev_b32_e32 v77, 16, v77                             // 00000091EAAC: 309A9A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091EAB0: BF870112
	v_lshl_or_b32 v75, v80, 16, v75                            // 00000091EAB4: D656004B 052D2150
	v_and_or_b32 v74, 0xffff, v74, v77                         // 00000091EABC: D657004A 053694FF 0000FFFF
	v_and_b32_e32 v77, 0xffff, v82                             // 00000091EAC8: 369AA4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091EAD0: BF870223
	v_pk_fma_f16 v75, v75, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091EAD4: CC0E004B 0BFC074B 0000C931
	v_dot2acc_f32_f16 v37, v84, v6                             // 00000091EAE0: 044A0D54
	v_pk_fma_f16 v82, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091EAE4: CC0E0052 0BFC074A 0000C931
	.long 0xd72c0054                                           // 00000091EAF0: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 00000091EAF4: 0202ACFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091EAFC: BF870004
	v_dot2acc_f32_f16 v40, v75, v9                             // 00000091EB00: 0450134B
	v_dot2acc_f32_f16 v35, v83, v20                            // 00000091EB04: 04462953
	v_bfe_u32 v83, v79, 6, 16                                  // 00000091EB08: D6100053 02410D4F
	v_dual_dot2acc_f32_f16 v42, v75, v13 :: v_dual_and_b32 v79, 0xffff, v79// 00000091EB10: CB241B4B 2A4E9EFF 0000FFFF
	v_dot2acc_f32_f16 v37, v85, v7                             // 00000091EB1C: 044A0F55
	v_sad_u8 v74, v84, 0, 0x6400                               // 00000091EB20: D622004A 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091EB2C: BF870214
	.long 0xd72c0053                                           // 00000091EB30: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 00000091EB34: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v42, v82, v14                            // 00000091EB3C: 04541D52
	.long 0xd72c004f                                           // 00000091EB40: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 00000091EB44: 02029EFF 83DCD12D
	v_dual_dot2acc_f32_f16 v40, v82, v10 :: v_dual_dot2acc_f32_f16 v43, v75, v17// 00000091EB4C: CB181552 282A234B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091EB54: BF870114
	v_sad_u8 v80, v83, 0, 0x6400                               // 00000091EB58: D6220050 03FD0153 00006400
	v_dot2acc_f32_f16 v43, v82, v18                            // 00000091EB64: 04562552
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091EB68: BF870194
	v_sad_u8 v79, v79, 0, 0x6400                               // 00000091EB6C: D622004F 03FD014F 00006400
	v_lshl_or_b32 v77, v80, 16, v77                            // 00000091EB78: D656004D 05352150
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091EB80: BF870112
	v_lshlrev_b32_e32 v79, 16, v79                             // 00000091EB84: 309E9E90
	v_pk_fma_f16 v83, v77, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091EB88: CC0E0053 0BFC074D 0000C931
	v_dot2acc_f32_f16 v37, v72, v8                             // 00000091EB94: 044A1148
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091EB98: BF870193
	v_and_or_b32 v74, 0xffff, v74, v79                         // 00000091EB9C: D657004A 053E94FF 0000FFFF
	v_dual_mov_b32 v79, v81 :: v_dual_dot2acc_f32_f16 v40, v83, v11// 00000091EBA8: CA180151 4F281753
	v_dot2acc_f32_f16 v42, v83, v15                            // 00000091EBB0: 04541F53
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000091EBB4: BF870123
	v_pk_fma_f16 v84, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091EBB8: CC0E0054 0BFC074A 0000C931
	v_mov_b32_e32 v74, v76                                     // 00000091EBC4: 7E94034C
	v_dot2acc_f32_f16 v40, v84, v12                            // 00000091EBC8: 04501954
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000091EBCC: BF8701B2
	.long 0xd73d0048                                           // 00000091EBD0: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 00000091EBD4: 0202933E
	.long 0xd73d0049                                           // 00000091EBD8: D73D0049
	v_cndmask_b32_e32 v1, v63, v78, vcc_lo                     // 00000091EBDC: 02029D3F
	v_dot2acc_f32_f16 v42, v84, v16                            // 00000091EBE0: 04542154
	v_and_b32_e32 v76, 0xffff, v72                             // 00000091EBE4: 369890FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091EBEC: BF870003
	v_bfe_u32 v77, v73, 9, 16                                  // 00000091EBF0: D610004D 02411349
	v_bfe_u32 v78, v73, 6, 16                                  // 00000091EBF8: D610004E 02410D49
	v_bfe_u32 v79, v73, 3, 16                                  // 00000091EC00: D610004F 02410749
	v_and_b32_e32 v73, 0xffff, v73                             // 00000091EC08: 369292FF 0000FFFF
	.long 0xd72c004c                                           // 00000091EC10: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 00000091EC14: 020298FF 83DCD12D
	.long 0xd72c004d                                           // 00000091EC1C: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 00000091EC20: 02029AFF 83DCD12D
	.long 0xd72c004e                                           // 00000091EC28: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 00000091EC2C: 02029CFF 83DCD12D
	.long 0xd72c004f                                           // 00000091EC34: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 00000091EC38: 02029EFF 83DCD12D
	.long 0xd72c0050                                           // 00000091EC40: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 00000091EC44: 020292FF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000091EC4C: D622004C 03FD014C 00006400
	v_dot2acc_f32_f16 v41, v75, v5                             // 00000091EC58: 04520B4B
	v_bfe_u32 v75, v72, 9, 16                                  // 00000091EC5C: D610004B 02411348
	v_sad_u8 v77, v77, 0, 0x6400                               // 00000091EC64: D622004D 03FD014D 00006400
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000091EC70: D622004E 03FD014E 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 00000091EC7C: 30989890
	v_sad_u8 v79, v79, 0, 0x6400                               // 00000091EC80: D622004F 03FD014F 00006400
	.long 0xd72c004a                                           // 00000091EC8C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000091EC90: 020296FF 83DCD12D
	v_bfe_u32 v75, v72, 6, 16                                  // 00000091EC98: D610004B 02410D48
	v_bfe_u32 v72, v72, 3, 16                                  // 00000091ECA0: D6100048 02410748
	v_and_b32_e32 v77, 0xffff, v77                             // 00000091ECA8: 369A9AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091ECB0: BF870193
	.long 0xd72c004b                                           // 00000091ECB4: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000091ECB8: 020296FF 83DCD12D
	.long 0xd72c0048                                           // 00000091ECC0: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 00000091ECC4: 020290FF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000091ECCC: D622004A 03FD014A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000091ECD8: BF870154
	v_lshl_or_b32 v86, v78, 16, v77                            // 00000091ECDC: D6560056 0535214E
	ds_load_2addr_b32 v[77:78], v71 offset0:144 offset1:168    // 00000091ECE4: D8DCA890 4D000047
	v_and_b32_e32 v74, 0xffff, v74                             // 00000091ECEC: 369494FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000091ECF4: D622004B 03FD014B 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 00000091ED00: D6220048 03FD0148 00006400
	v_lshl_or_b32 v74, v75, 16, v74                            // 00000091ED0C: D656004A 0529214B
	s_delay_alu instid0(VALU_DEP_2)                            // 00000091ED14: BF870002
	v_and_or_b32 v81, 0xffff, v72, v76                         // 00000091ED18: D6570051 053290FF 0000FFFF
	ds_load_2addr_b32 v[72:73], v69 offset0:144 offset1:168    // 00000091ED24: D8DCA890 48000045
	ds_load_2addr_b32 v[75:76], v68 offset0:144 offset1:168    // 00000091ED2C: D8DCA890 4B000044
	v_dot2acc_f32_f16 v41, v82, v6                             // 00000091ED34: 04520D52
	v_pk_fma_f16 v82, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091ED38: CC0E0052 0BFC074A 0000C931
	v_sad_u8 v74, v80, 0, 0x6400                               // 00000091ED44: D622004A 03FD0150 00006400
	v_pk_fma_f16 v85, v81, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091ED50: CC0E0055 0BFC0751 0000C931
	ds_load_2addr_b32 v[80:81], v70 offset0:144 offset1:168    // 00000091ED5C: D8DCA890 50000046
	v_dot2acc_f32_f16 v44, v82, v9                             // 00000091ED64: 04581352
	v_dual_dot2acc_f32_f16 v45, v82, v5 :: v_dual_lshlrev_b32 v74, 16, v74// 00000091ED68: CB220B52 2D4A9490
	v_dot2acc_f32_f16 v46, v82, v13                            // 00000091ED70: 045C1B52
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091ED74: BF870193
	v_dual_dot2acc_f32_f16 v47, v82, v17 :: v_dual_dot2acc_f32_f16 v44, v85, v10// 00000091ED78: CB182352 2F2C1555
	v_and_or_b32 v79, 0xffff, v79, v74                         // 00000091ED80: D657004F 052A9EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091ED8C: BF8701A3
	v_dot2acc_f32_f16 v46, v85, v14                            // 00000091ED90: 045C1D55
	s_waitcnt lgkmcnt(2)                                       // 00000091ED94: BF89FC27
	v_dual_dot2acc_f32_f16 v47, v85, v18 :: v_dual_mov_b32 v74, v72// 00000091ED98: CB102555 2F4A0148
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091EDA0: BF870003
	v_pk_fma_f16 v72, v79, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091EDA4: CC0E0048 0BFC074F 0000C931
	v_mov_b32_e32 v79, v77                                     // 00000091EDB0: 7E9E034D
	v_dot2acc_f32_f16 v41, v83, v7                             // 00000091EDB4: 04520F53
	s_waitcnt lgkmcnt(1)                                       // 00000091EDB8: BF89FC17
	.long 0xd73d004a                                           // 00000091EDBC: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 00000091EDC0: 0202953E
	s_waitcnt lgkmcnt(0)                                       // 00000091EDC4: BF89FC07
	.long 0xd73d004f                                           // 00000091EDC8: D73D004F
	v_cndmask_b32_e32 v1, v63, v79, vcc_lo                     // 00000091EDCC: 02029F3F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000091EDD0: BF870002
	v_bfe_u32 v75, v74, 9, 16                                  // 00000091EDD4: D610004B 0241134A
	v_and_b32_e32 v77, 0xffff, v74                             // 00000091EDDC: 369A94FF 0000FFFF
	v_bfe_u32 v80, v74, 6, 16                                  // 00000091EDE4: D6100050 02410D4A
	v_bfe_u32 v74, v74, 3, 16                                  // 00000091EDEC: D610004A 0241074A
	v_bfe_u32 v82, v79, 9, 16                                  // 00000091EDF4: D6100052 0241134F
	.long 0xd72c004b                                           // 00000091EDFC: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000091EE00: 020296FF 83DCD12D
	.long 0xd72c004d                                           // 00000091EE08: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 00000091EE0C: 02029AFF 83DCD12D
	.long 0xd72c0050                                           // 00000091EE14: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 00000091EE18: 0202A0FF 83DCD12D
	.long 0xd72c004a                                           // 00000091EE20: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 00000091EE24: 020294FF 83DCD12D
	.long 0xd72c0052                                           // 00000091EE2C: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000091EE30: 0202A4FF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000091EE38: D622004B 03FD014B 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 00000091EE44: D622004D 03FD014D 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 00000091EE50: D6220050 03FD0150 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000091EE5C: D622004A 03FD014A 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 00000091EE68: D6220052 03FD0152 00006400
	v_and_b32_e32 v75, 0xffff, v75                             // 00000091EE74: 369696FF 0000FFFF
	v_lshlrev_b32_e32 v77, 16, v77                             // 00000091EE7C: 309A9A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091EE80: BF870112
	v_lshl_or_b32 v75, v80, 16, v75                            // 00000091EE84: D656004B 052D2150
	v_and_or_b32 v74, 0xffff, v74, v77                         // 00000091EE8C: D657004A 053694FF 0000FFFF
	v_and_b32_e32 v77, 0xffff, v82                             // 00000091EE98: 369AA4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091EEA0: BF870223
	v_pk_fma_f16 v75, v75, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091EEA4: CC0E004B 0BFC074B 0000C931
	v_dot2acc_f32_f16 v45, v85, v6                             // 00000091EEB0: 045A0D55
	v_pk_fma_f16 v82, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091EEB4: CC0E0052 0BFC074A 0000C931
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091EEC0: BF870003
	v_dot2acc_f32_f16 v48, v75, v9                             // 00000091EEC4: 0460134B
	v_dot2acc_f32_f16 v50, v75, v13                            // 00000091EEC8: 04641B4B
	v_dot2acc_f32_f16 v43, v83, v19                            // 00000091EECC: 04562753
	v_pk_fma_f16 v83, v86, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091EED0: CC0E0053 0BFC0756 0000C931
	v_dot2acc_f32_f16 v41, v84, v8                             // 00000091EEDC: 04521154
	v_bfe_u32 v86, v79, 3, 16                                  // 00000091EEE0: D6100056 0241074F
	v_dot2acc_f32_f16 v48, v82, v10                            // 00000091EEE8: 04601552
	v_dual_dot2acc_f32_f16 v50, v82, v14 :: v_dual_dot2acc_f32_f16 v43, v84, v20// 00000091EEEC: CB181D52 322A2954
	v_bfe_u32 v84, v79, 6, 16                                  // 00000091EEF4: D6100054 02410D4F
	v_and_b32_e32 v79, 0xffff, v79                             // 00000091EEFC: 369E9EFF 0000FFFF
	.long 0xd72c0055                                           // 00000091EF04: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 00000091EF08: 0202ACFF 83DCD12D
	v_dot2acc_f32_f16 v44, v83, v11                            // 00000091EF10: 04581753
	v_dot2acc_f32_f16 v46, v83, v15                            // 00000091EF14: 045C1F53
	.long 0xd72c0054                                           // 00000091EF18: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 00000091EF1C: 0202A8FF 83DCD12D
	.long 0xd72c004f                                           // 00000091EF24: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 00000091EF28: 02029EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091EF30: BF870214
	v_dual_dot2acc_f32_f16 v47, v83, v19 :: v_dual_dot2acc_f32_f16 v44, v72, v12// 00000091EF34: CB182753 2F2C1948
	v_dot2acc_f32_f16 v46, v72, v16                            // 00000091EF3C: 045C2148
	v_sad_u8 v74, v85, 0, 0x6400                               // 00000091EF40: D622004A 03FD0155 00006400
	v_dot2acc_f32_f16 v51, v75, v17                            // 00000091EF4C: 0466234B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000091EF50: BF870134
	v_dot2acc_f32_f16 v47, v72, v20                            // 00000091EF54: 045E2948
	v_sad_u8 v80, v84, 0, 0x6400                               // 00000091EF58: D6220050 03FD0154 00006400
	v_sad_u8 v79, v79, 0, 0x6400                               // 00000091EF64: D622004F 03FD014F 00006400
	v_lshl_or_b32 v77, v80, 16, v77                            // 00000091EF70: D656004D 05352150
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091EF78: BF870112
	v_lshlrev_b32_e32 v79, 16, v79                             // 00000091EF7C: 309E9E90
	v_pk_fma_f16 v77, v77, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091EF80: CC0E004D 0BFC074D 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091EF8C: BF8701A2
	v_and_or_b32 v74, 0xffff, v74, v79                         // 00000091EF90: D657004A 053E94FF 0000FFFF
	v_mov_b32_e32 v79, v81                                     // 00000091EF9C: 7E9E0351
	v_dot2acc_f32_f16 v48, v77, v11                            // 00000091EFA0: 0460174D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000091EFA4: BF8701B3
	v_pk_fma_f16 v80, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091EFA8: CC0E0050 0BFC074A 0000C931
	v_dual_dot2acc_f32_f16 v45, v83, v7 :: v_dual_mov_b32 v74, v76// 00000091EFB4: CB100F53 2D4A014C
	v_dot2acc_f32_f16 v50, v77, v15                            // 00000091EFBC: 04641F4D
	v_dot2acc_f32_f16 v48, v80, v12                            // 00000091EFC0: 04601950
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091EFC4: BF870213
	v_dot2acc_f32_f16 v45, v72, v8                             // 00000091EFC8: 045A1148
	.long 0xd73d0048                                           // 00000091EFCC: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 00000091EFD0: 0202933E
	.long 0xd73d0049                                           // 00000091EFD4: D73D0049
	v_cndmask_b32_e32 v1, v63, v78, vcc_lo                     // 00000091EFD8: 02029D3F
	v_dot2acc_f32_f16 v50, v80, v16                            // 00000091EFDC: 04642150
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091EFE0: BF870193
	v_and_b32_e32 v76, 0xffff, v72                             // 00000091EFE4: 369890FF 0000FFFF
	v_bfe_u32 v78, v73, 9, 16                                  // 00000091EFEC: D610004E 02411349
	v_bfe_u32 v79, v73, 6, 16                                  // 00000091EFF4: D610004F 02410D49
	v_bfe_u32 v81, v73, 3, 16                                  // 00000091EFFC: D6100051 02410749
	v_and_b32_e32 v73, 0xffff, v73                             // 00000091F004: 369292FF 0000FFFF
	.long 0xd72c004c                                           // 00000091F00C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 00000091F010: 020298FF 83DCD12D
	.long 0xd72c004e                                           // 00000091F018: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 00000091F01C: 02029CFF 83DCD12D
	.long 0xd72c004f                                           // 00000091F024: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 00000091F028: 02029EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091F030: BF870214
	.long 0xd72c0049                                           // 00000091F034: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 00000091F038: 020292FF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000091F040: D622004C 03FD014C 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091F04C: BF870004
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000091F050: D622004E 03FD014E 00006400
	v_dot2acc_f32_f16 v49, v75, v5                             // 00000091F05C: 04620B4B
	v_bfe_u32 v75, v72, 9, 16                                  // 00000091F060: D610004B 02411348
	v_sad_u8 v79, v79, 0, 0x6400                               // 00000091F068: D622004F 03FD014F 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 00000091F074: D6220049 03FD0149 00006400
	v_and_b32_e32 v78, 0xffff, v78                             // 00000091F080: 369C9CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000091F088: BF8701C4
	.long 0xd72c004a                                           // 00000091F08C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000091F090: 020296FF 83DCD12D
	v_bfe_u32 v75, v72, 6, 16                                  // 00000091F098: D610004B 02410D48
	v_bfe_u32 v72, v72, 3, 16                                  // 00000091F0A0: D6100048 02410748
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000091F0A8: 30929290
	.long 0xd72c004b                                           // 00000091F0AC: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000091F0B0: 020296FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000091F0B8: BF8700A3
	.long 0xd72c0048                                           // 00000091F0BC: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 00000091F0C0: 020290FF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000091F0C8: D622004A 03FD014A 00006400
	v_and_b32_e32 v74, 0xffff, v74                             // 00000091F0D4: 369494FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091F0DC: BF870214
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000091F0E0: D622004B 03FD014B 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 00000091F0EC: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000091F0F8: BF8701B2
	v_lshl_or_b32 v74, v75, 16, v74                            // 00000091F0FC: D656004A 0529214B
	v_lshlrev_b32_e32 v75, 16, v76                             // 00000091F104: 30969890
	.long 0xd72c004c                                           // 00000091F108: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 00000091F10C: 0202A2FF 83DCD12D
	v_pk_fma_f16 v74, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091F114: CC0E004A 0BFC074A 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091F120: BF870223
	v_and_or_b32 v72, 0xffff, v72, v75                         // 00000091F124: D6570048 052E90FF 0000FFFF
	v_lshl_or_b32 v75, v79, 16, v78                            // 00000091F130: D656004B 0539214F
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000091F138: D622004C 03FD014C 00006400
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091F144: BF870003
	v_pk_fma_f16 v72, v72, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091F148: CC0E0048 0BFC0748 0000C931
	v_dot2acc_f32_f16 v54, v74, v5                             // 00000091F154: 046C0B4A
	v_dot2acc_f32_f16 v24, v74, v17                            // 00000091F158: 0430234A
	v_pk_fma_f16 v75, v75, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091F15C: CC0E004B 0BFC074B 0000C931
	v_dot2acc_f32_f16 v53, v74, v9                             // 00000091F168: 046A134A
	v_and_or_b32 v9, 0xffff, v76, v73                          // 00000091F16C: D6570009 052698FF 0000FFFF
	v_dual_dot2acc_f32_f16 v55, v74, v13 :: v_dual_dot2acc_f32_f16 v54, v72, v6// 00000091F178: CB181B4A 37360D48
	v_dot2acc_f32_f16 v24, v72, v18                            // 00000091F180: 04302548
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091F184: BF870214
	v_dot2acc_f32_f16 v53, v72, v10                            // 00000091F188: 046A1548
	v_pk_fma_f16 v5, v9, s3, 0xc931 op_sel_hi:[1,0,0]          // 00000091F18C: CC0E0005 0BFC0709 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091F198: BF870214
	v_dual_dot2acc_f32_f16 v55, v72, v14 :: v_dual_dot2acc_f32_f16 v54, v75, v7// 00000091F19C: CB181D48 37360F4B
	v_dual_dot2acc_f32_f16 v49, v82, v6 :: v_dual_dot2acc_f32_f16 v24, v75, v19// 00000091F1A4: CB180D52 3118274B
	v_add_nc_u32_e32 v6, v65, v66                              // 00000091F1AC: 4A0C8541
	v_dot2acc_f32_f16 v51, v82, v18                            // 00000091F1B0: 04662552
	v_dot2acc_f32_f16 v53, v75, v11                            // 00000091F1B4: 046A174B
	v_dual_dot2acc_f32_f16 v55, v75, v15 :: v_dual_dot2acc_f32_f16 v54, v5, v8// 00000091F1B8: CB181F4B 37361105
	v_dot2acc_f32_f16 v49, v77, v7                             // 00000091F1C0: 04620F4D
	v_dot2acc_f32_f16 v24, v5, v20                             // 00000091F1C4: 04302905
	v_dot2acc_f32_f16 v51, v77, v19                            // 00000091F1C8: 0466274D
	v_cmp_eq_u32_e32 vcc_lo, 6, v6                             // 00000091F1CC: 7C940C86
	v_dot2acc_f32_f16 v53, v5, v12                             // 00000091F1D0: 046A1905
	v_dot2acc_f32_f16 v49, v80, v8                             // 00000091F1D4: 04621150
	v_dot2acc_f32_f16 v55, v5, v16                             // 00000091F1D8: 046E2105
	v_dot2acc_f32_f16 v51, v80, v20                            // 00000091F1DC: 04662950
	s_or_b32 s2, vcc_lo, s2                                    // 00000091F1E0: 8C02026A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000091F1E4: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 00000091F1E8: 917E027E
	s_cbranch_execz 27                                         // 00000091F1EC: BFA5001B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x3f5c>
	s_mov_b32 s0, exec_lo                                      // 00000091F1F0: BE80007E
	s_waitcnt vmcnt(4)                                         // 00000091F1F4: BF8913F7
	ds_store_2addr_b32 v67, v56, v57 offset1:32                // 00000091F1F8: D8382000 00393843
	s_waitcnt vmcnt(2)                                         // 00000091F200: BF890BF7
	ds_store_2addr_b32 v67, v58, v59 offset0:64 offset1:96     // 00000091F204: D8386040 003B3A43
	s_waitcnt vmcnt(0)                                         // 00000091F20C: BF8903F7
	ds_store_2addr_b32 v67, v60, v61 offset0:128 offset1:160   // 00000091F210: D838A080 003D3C43
	.long 0xd4c9007e                                           // 00000091F218: D4C9007E
	v_cndmask_b32_e32 v1, v66, v52, vcc_lo                     // 00000091F21C: 02026942
	s_cbranch_execz 64474                                      // 00000091F220: BFA5FBDA <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2e8c>
	s_clause 0x5                                               // 00000091F224: BF850005
	global_load_b32 v56, v[1:2], off                           // 00000091F228: DC520000 387C0001
	global_load_b32 v57, v[1:2], off offset:128                // 00000091F230: DC520080 397C0001
	global_load_b32 v58, v[1:2], off offset:256                // 00000091F238: DC520100 3A7C0001
	global_load_b32 v59, v[1:2], off offset:384                // 00000091F240: DC520180 3B7C0001
	global_load_b32 v60, v[1:2], off offset:512                // 00000091F248: DC520200 3C7C0001
	global_load_b32 v61, v[1:2], off offset:640                // 00000091F250: DC520280 3D7C0001
	s_branch 64460                                             // 00000091F258: BFA0FBCC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2e8c>
	s_or_b32 exec_lo, exec_lo, s2                              // 00000091F25C: 8C7E027E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091F260: BF870099
	s_or_b32 exec_lo, exec_lo, s1                              // 00000091F264: 8C7E017E
	v_dual_mov_b32 v1, v23 :: v_dual_mov_b32 v6, v28           // 00000091F268: CA100117 0106011C
	v_dual_mov_b32 v2, v27 :: v_dual_mov_b32 v5, v26           // 00000091F270: CA10011B 0204011A
	v_dual_mov_b32 v7, v29 :: v_dual_mov_b32 v8, v30           // 00000091F278: CA10011D 0708011E
	v_dual_mov_b32 v10, v31 :: v_dual_mov_b32 v11, v32         // 00000091F280: CA10011F 0A0A0120
	v_dual_mov_b32 v9, v25 :: v_dual_mov_b32 v14, v35          // 00000091F288: CA100119 090E0123
	v_dual_mov_b32 v12, v33 :: v_dual_mov_b32 v13, v34         // 00000091F290: CA100121 0C0C0122
	v_dual_mov_b32 v15, v36 :: v_dual_mov_b32 v16, v37         // 00000091F298: CA100124 0F100125
	v_dual_mov_b32 v17, v38 :: v_dual_mov_b32 v18, v39         // 00000091F2A0: CA100126 11120127
	v_dual_mov_b32 v19, v40 :: v_dual_mov_b32 v20, v41         // 00000091F2A8: CA100128 13140129
	s_waitcnt vmcnt(4)                                         // 00000091F2B0: BF8913F7
	v_dual_mov_b32 v52, v42 :: v_dual_mov_b32 v57, v44         // 00000091F2B4: CA10012A 3438012C
	s_waitcnt vmcnt(2)                                         // 00000091F2BC: BF890BF7
	v_dual_mov_b32 v56, v43 :: v_dual_mov_b32 v59, v46         // 00000091F2C0: CA10012B 383A012E
	s_waitcnt vmcnt(0)                                         // 00000091F2C8: BF8903F7
	v_dual_mov_b32 v58, v45 :: v_dual_mov_b32 v61, v48         // 00000091F2CC: CA10012D 3A3C0130
	v_dual_mov_b32 v60, v47 :: v_dual_mov_b32 v63, v50         // 00000091F2D4: CA10012F 3C3E0132
	v_dual_mov_b32 v62, v49 :: v_dual_mov_b32 v67, v55         // 00000091F2DC: CA100131 3E420137
	v_dual_mov_b32 v64, v51 :: v_dual_mov_b32 v65, v53         // 00000091F2E4: CA100133 40400135
	v_mov_b32_e32 v66, v54                                     // 00000091F2EC: 7E840336
	v_mov_b32_e32 v68, v24                                     // 00000091F2F0: 7E880318
	s_mov_b32 s0, 0x76543210                                   // 00000091F2F4: BE8000FF 76543210
	v_cmp_gt_u32_e32 vcc_lo, 16, v22                           // 00000091F2FC: 7C982C90
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 00000091F300: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000091F30C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 00000091F318: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 00000091F324: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 00000091F330: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 00000091F33C: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 00000091F348: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 00000091F354: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 00000091F360: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 00000091F36C: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 00000091F378: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 00000091F384: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 00000091F390: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 00000091F39C: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 00000091F3A8: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 00000091F3B4: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 00000091F3C0: D65C0013 03FC0113 FEDCBA98
	v_permlanex16_b32 v20, v20, s0, 0xfedcba98                 // 00000091F3CC: D65C0014 03FC0114 FEDCBA98
	v_permlanex16_b32 v52, v52, s0, 0xfedcba98                 // 00000091F3D8: D65C0034 03FC0134 FEDCBA98
	v_permlanex16_b32 v56, v56, s0, 0xfedcba98                 // 00000091F3E4: D65C0038 03FC0138 FEDCBA98
	v_permlanex16_b32 v57, v57, s0, 0xfedcba98                 // 00000091F3F0: D65C0039 03FC0139 FEDCBA98
	v_permlanex16_b32 v58, v58, s0, 0xfedcba98                 // 00000091F3FC: D65C003A 03FC013A FEDCBA98
	v_permlanex16_b32 v59, v59, s0, 0xfedcba98                 // 00000091F408: D65C003B 03FC013B FEDCBA98
	v_permlanex16_b32 v60, v60, s0, 0xfedcba98                 // 00000091F414: D65C003C 03FC013C FEDCBA98
	v_permlanex16_b32 v61, v61, s0, 0xfedcba98                 // 00000091F420: D65C003D 03FC013D FEDCBA98
	v_permlanex16_b32 v62, v62, s0, 0xfedcba98                 // 00000091F42C: D65C003E 03FC013E FEDCBA98
	v_permlanex16_b32 v63, v63, s0, 0xfedcba98                 // 00000091F438: D65C003F 03FC013F FEDCBA98
	v_permlanex16_b32 v64, v64, s0, 0xfedcba98                 // 00000091F444: D65C0040 03FC0140 FEDCBA98
	v_permlanex16_b32 v65, v65, s0, 0xfedcba98                 // 00000091F450: D65C0041 03FC0141 FEDCBA98
	v_permlanex16_b32 v66, v66, s0, 0xfedcba98                 // 00000091F45C: D65C0042 03FC0142 FEDCBA98
	v_permlanex16_b32 v67, v67, s0, 0xfedcba98                 // 00000091F468: D65C0043 03FC0143 FEDCBA98
	v_permlanex16_b32 v68, v68, s0, 0xfedcba98                 // 00000091F474: D65C0044 03FC0144 FEDCBA98
	s_barrier                                                  // 00000091F480: BFBD0000
	buffer_gl0_inv                                             // 00000091F484: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 00000091F48C: BE80206A
	s_cbranch_execz 74                                         // 00000091F490: BFA5004A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x42bc>
	v_dual_add_f32 v43, v43, v56 :: v_dual_lshlrev_b32 v22, 2, v22// 00000091F494: C922712B 2B162C82
	v_dual_add_f32 v14, v35, v14 :: v_dual_lshlrev_b32 v35, 6, v0// 00000091F49C: C9221D23 0E220086
	v_dual_add_f32 v10, v31, v10 :: v_dual_add_f32 v7, v29, v7 // 00000091F4A4: C908151F 0A060F1D
	v_dual_add_f32 v8, v30, v8 :: v_dual_add_f32 v1, v23, v1   // 00000091F4AC: C908111E 08000317
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000091F4B4: BF8701B3
	v_and_or_b32 v22, 0x3800, v35, v22                         // 00000091F4B8: D6570016 045A46FF 00003800
	v_dual_add_f32 v2, v27, v2 :: v_dual_add_f32 v9, v25, v9   // 00000091F4C4: C908051B 02081319
	v_dual_add_f32 v6, v28, v6 :: v_dual_add_f32 v5, v26, v5   // 00000091F4CC: C9080D1C 06040B1A
	v_add_nc_u32_e32 v23, 0x5000, v22                          // 00000091F4D4: 4A2E2CFF 00005000
	v_add_nc_u32_e32 v22, 0x5400, v22                          // 00000091F4DC: 4A2C2CFF 00005400
	v_dual_add_f32 v12, v33, v12 :: v_dual_add_f32 v11, v32, v11// 00000091F4E4: C9081921 0C0A1720
	v_dual_add_f32 v18, v39, v18 :: v_dual_add_f32 v15, v36, v15// 00000091F4EC: C9082527 120E1F24
	v_dual_add_f32 v24, v24, v68 :: v_dual_add_f32 v55, v55, v67// 00000091F4F4: C9088918 18368737
	v_dual_add_f32 v54, v54, v66 :: v_dual_add_f32 v53, v53, v65// 00000091F4FC: C9088536 36348335
	v_dual_add_f32 v51, v51, v64 :: v_dual_add_f32 v50, v50, v63// 00000091F504: C9088133 33327F32
	v_dual_add_f32 v49, v49, v62 :: v_dual_add_f32 v48, v48, v61// 00000091F50C: C9087D31 31307B30
	v_dual_add_f32 v47, v47, v60 :: v_dual_add_f32 v46, v46, v59// 00000091F514: C908792F 2F2E772E
	v_dual_add_f32 v45, v45, v58 :: v_dual_add_f32 v44, v44, v57// 00000091F51C: C908752D 2D2C732C
	v_dual_add_f32 v42, v42, v52 :: v_dual_add_f32 v19, v40, v19// 00000091F524: C908692A 2A122728
	v_dual_add_f32 v20, v41, v20 :: v_dual_add_f32 v17, v38, v17// 00000091F52C: C9082929 14102326
	v_dual_add_f32 v16, v37, v16 :: v_dual_add_f32 v13, v34, v13// 00000091F534: C9082125 100C1B22
	ds_store_2addr_b32 v23, v1, v7 offset1:16                  // 00000091F53C: D8381000 00070117
	ds_store_2addr_b32 v23, v2, v8 offset0:128 offset1:144     // 00000091F544: D8389080 00080217
	ds_store_2addr_b32 v22, v6, v10 offset1:16                 // 00000091F54C: D8381000 000A0616
	ds_store_2addr_b32 v22, v5, v11 offset0:128 offset1:144    // 00000091F554: D8389080 000B0516
	ds_store_2addr_b32 v23, v9, v15 offset0:32 offset1:48      // 00000091F55C: D8383020 000F0917
	ds_store_2addr_b32 v23, v12, v16 offset0:160 offset1:176   // 00000091F564: D838B0A0 00100C17
	ds_store_2addr_b32 v22, v13, v17 offset0:32 offset1:48     // 00000091F56C: D8383020 00110D16
	ds_store_2addr_b32 v22, v14, v18 offset0:160 offset1:176   // 00000091F574: D838B0A0 00120E16
	ds_store_2addr_b32 v23, v19, v44 offset0:64 offset1:80     // 00000091F57C: D8385040 002C1317
	ds_store_2addr_b32 v23, v20, v45 offset0:192 offset1:208   // 00000091F584: D838D0C0 002D1417
	ds_store_2addr_b32 v22, v42, v46 offset0:64 offset1:80     // 00000091F58C: D8385040 002E2A16
	ds_store_2addr_b32 v22, v43, v47 offset0:192 offset1:208   // 00000091F594: D838D0C0 002F2B16
	ds_store_2addr_b32 v23, v48, v53 offset0:96 offset1:112    // 00000091F59C: D8387060 00353017
	ds_store_2addr_b32 v23, v49, v54 offset0:224 offset1:240   // 00000091F5A4: D838F0E0 00363117
	ds_store_2addr_b32 v22, v50, v55 offset0:96 offset1:112    // 00000091F5AC: D8387060 00373216
	ds_store_2addr_b32 v22, v51, v24 offset0:224 offset1:240   // 00000091F5B4: D838F0E0 00183316
	s_or_b32 exec_lo, exec_lo, s0                              // 00000091F5BC: 8C7E007E
	v_sub_nc_u32_e32 v1, v4, v3                                // 00000091F5C0: 4C020704
	s_waitcnt lgkmcnt(0)                                       // 00000091F5C4: BF89FC07
	s_barrier                                                  // 00000091F5C8: BFBD0000
	buffer_gl0_inv                                             // 00000091F5CC: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 00000091F5D4: BE81007E
	v_min_i32_e32 v1, 4, v1                                    // 00000091F5D8: 22020284
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091F5DC: BF870001
	.long 0xd4c1007e                                           // 00000091F5E0: D4C1007E
	v_cndmask_b32_e32 v1, v21, v1, vcc_lo                      // 00000091F5E4: 02020315
	s_cbranch_execz 535                                        // 00000091F5E8: BFA50217 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x4b48>
	v_and_b32_e32 v1, 15, v0                                   // 00000091F5EC: 3602008F
	v_lshlrev_b32_e32 v2, 9, v21                               // 00000091F5F0: 30042A89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091F5F4: BF870091
	v_lshl_or_b32 v2, v1, 2, v2                                // 00000091F5F8: D6560002 04090501
	v_add_nc_u32_e32 v20, 0x5000, v2                           // 00000091F600: 4A2804FF 00005000
	v_add_nc_u32_e32 v50, 0x5800, v2                           // 00000091F608: 4A6404FF 00005800
	v_add_nc_u32_e32 v51, 0x6000, v2                           // 00000091F610: 4A6604FF 00006000
	v_add_nc_u32_e32 v52, 0x6800, v2                           // 00000091F618: 4A6804FF 00006800
	v_add_nc_u32_e32 v53, 0x7000, v2                           // 00000091F620: 4A6A04FF 00007000
	v_add_nc_u32_e32 v54, 0x7800, v2                           // 00000091F628: 4A6C04FF 00007800
	v_add_nc_u32_e32 v55, 0x8000, v2                           // 00000091F630: 4A6E04FF 00008000
	v_add_nc_u32_e32 v2, 0x8800, v2                            // 00000091F638: 4A0404FF 00008800
	ds_load_2addr_b32 v[4:5], v20 offset1:16                   // 00000091F640: D8DC1000 04000014
	ds_load_2addr_b32 v[6:7], v50 offset1:16                   // 00000091F648: D8DC1000 06000032
	ds_load_2addr_b32 v[8:9], v51 offset1:16                   // 00000091F650: D8DC1000 08000033
	ds_load_2addr_b32 v[10:11], v52 offset1:16                 // 00000091F658: D8DC1000 0A000034
	ds_load_2addr_b32 v[12:13], v20 offset0:32 offset1:48      // 00000091F660: D8DC3020 0C000014
	ds_load_2addr_b32 v[14:15], v53 offset1:16                 // 00000091F668: D8DC1000 0E000035
	ds_load_2addr_b32 v[16:17], v54 offset1:16                 // 00000091F670: D8DC1000 10000036
	ds_load_2addr_b32 v[18:19], v55 offset1:16                 // 00000091F678: D8DC1000 12000037
	ds_load_2addr_b32 v[22:23], v2 offset1:16                  // 00000091F680: D8DC1000 16000002
	ds_load_2addr_b32 v[24:25], v50 offset0:32 offset1:48      // 00000091F688: D8DC3020 18000032
	ds_load_2addr_b32 v[26:27], v51 offset0:32 offset1:48      // 00000091F690: D8DC3020 1A000033
	ds_load_2addr_b32 v[28:29], v52 offset0:32 offset1:48      // 00000091F698: D8DC3020 1C000034
	ds_load_2addr_b32 v[30:31], v53 offset0:32 offset1:48      // 00000091F6A0: D8DC3020 1E000035
	ds_load_2addr_b32 v[32:33], v54 offset0:32 offset1:48      // 00000091F6A8: D8DC3020 20000036
	ds_load_2addr_b32 v[34:35], v55 offset0:32 offset1:48      // 00000091F6B0: D8DC3020 22000037
	ds_load_2addr_b32 v[36:37], v2 offset0:32 offset1:48       // 00000091F6B8: D8DC3020 24000002
	ds_load_2addr_b32 v[38:39], v20 offset0:64 offset1:80      // 00000091F6C0: D8DC5040 26000014
	ds_load_2addr_b32 v[40:41], v50 offset0:64 offset1:80      // 00000091F6C8: D8DC5040 28000032
	ds_load_2addr_b32 v[42:43], v51 offset0:64 offset1:80      // 00000091F6D0: D8DC5040 2A000033
	ds_load_2addr_b32 v[44:45], v52 offset0:64 offset1:80      // 00000091F6D8: D8DC5040 2C000034
	ds_load_2addr_b32 v[46:47], v53 offset0:64 offset1:80      // 00000091F6E0: D8DC5040 2E000035
	ds_load_2addr_b32 v[48:49], v20 offset0:96 offset1:112     // 00000091F6E8: D8DC7060 30000014
	s_waitcnt lgkmcnt(21)                                      // 00000091F6F0: BF89FD57
	v_add_f32_e32 v56, 0, v5                                   // 00000091F6F4: 06700A80
	v_add_f32_e32 v20, 0, v4                                   // 00000091F6F8: 06280880
	s_waitcnt lgkmcnt(17)                                      // 00000091F6FC: BF89FD17
	v_dual_add_f32 v12, 0, v12 :: v_dual_add_f32 v13, 0, v13   // 00000091F700: C9081880 0C0C1A80
	ds_load_2addr_b32 v[4:5], v50 offset0:96 offset1:112       // 00000091F708: D8DC7060 04000032
	ds_load_2addr_b32 v[50:51], v51 offset0:96 offset1:112     // 00000091F710: D8DC7060 32000033
	s_waitcnt lgkmcnt(14)                                      // 00000091F718: BF89FCE7
	v_dual_add_f32 v56, v56, v7 :: v_dual_add_f32 v13, v13, v25// 00000091F71C: C9080F38 380C330D
	v_add_f32_e32 v12, v12, v24                                // 00000091F724: 0618310C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091F728: BF8701A2
	v_add_f32_e32 v9, v56, v9                                  // 00000091F72C: 06121338
	s_waitcnt lgkmcnt(13)                                      // 00000091F730: BF89FCD7
	v_add_f32_e32 v13, v13, v27                                // 00000091F734: 061A370D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000091F738: BF870132
	v_add_f32_e32 v9, v9, v11                                  // 00000091F73C: 06121709
	s_waitcnt lgkmcnt(7)                                       // 00000091F740: BF89FC77
	v_add_f32_e32 v11, 0, v39                                  // 00000091F744: 06164E80
	v_dual_add_f32 v9, v9, v15 :: v_dual_add_f32 v20, v20, v6  // 00000091F748: C9081F09 09140D14
	ds_load_2addr_b32 v[6:7], v52 offset0:96 offset1:112       // 00000091F750: D8DC7060 06000034
	ds_load_2addr_b32 v[52:53], v53 offset0:96 offset1:112     // 00000091F758: D8DC7060 34000035
	v_dual_add_f32 v9, v9, v17 :: v_dual_add_f32 v8, v20, v8   // 00000091F760: C9082309 09081114
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091F768: BF870111
	v_dual_add_f32 v20, 0, v38 :: v_dual_add_f32 v9, v9, v19   // 00000091F76C: C9084C80 14082709
	v_add_f32_e32 v8, v8, v10                                  // 00000091F774: 06101508
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091F778: BF8701A1
	v_add_f32_e32 v8, v8, v14                                  // 00000091F77C: 06101D08
	s_waitcnt lgkmcnt(8)                                       // 00000091F780: BF89FC87
	v_add_f32_e32 v14, v20, v40                                // 00000091F784: 061C5114
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000091F788: BF870122
	v_add_f32_e32 v8, v8, v16                                  // 00000091F78C: 06102108
	s_waitcnt lgkmcnt(7)                                       // 00000091F790: BF89FC77
	v_add_f32_e32 v14, v14, v42                                // 00000091F794: 061C550E
	v_add_f32_e32 v12, v12, v26                                // 00000091F798: 0618350C
	s_waitcnt lgkmcnt(6)                                       // 00000091F79C: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000091F7A0: BF8701D2
	v_dual_add_f32 v8, v8, v18 :: v_dual_add_f32 v19, v14, v44 // 00000091F7A4: C9082508 0812590E
	v_add_f32_e32 v14, v11, v41                                // 00000091F7AC: 061C530B
	v_add_f32_e32 v18, v13, v29                                // 00000091F7B0: 06243B0D
	s_waitcnt lgkmcnt(4)                                       // 00000091F7B4: BF89FC47
	v_dual_add_f32 v13, 0, v49 :: v_dual_add_f32 v10, v12, v28 // 00000091F7B8: C9086280 0D0A390C
	v_add_f32_e32 v16, v14, v43                                // 00000091F7C0: 0620570E
	s_waitcnt lgkmcnt(3)                                       // 00000091F7C4: BF89FC37
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091F7C8: BF870112
	v_dual_add_f32 v12, 0, v48 :: v_dual_add_f32 v15, v13, v5  // 00000091F7CC: C9086080 0C0E0B0D
	v_add_f32_e32 v25, v16, v45                                // 00000091F7D4: 06325B10
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091F7D8: BF8701A2
	v_add_f32_e32 v12, v12, v4                                 // 00000091F7DC: 0618090C
	s_waitcnt lgkmcnt(2)                                       // 00000091F7E0: BF89FC27
	v_add_f32_e32 v24, v15, v51                                // 00000091F7E4: 0630670F
	ds_load_2addr_b32 v[14:15], v2 offset0:64 offset1:80       // 00000091F7E8: D8DC5040 0E000002
	v_add_f32_e32 v10, v10, v30                                // 00000091F7F0: 06143D0A
	ds_load_2addr_b32 v[4:5], v55 offset0:64 offset1:80        // 00000091F7F4: D8DC5040 04000037
	v_add_f32_e32 v17, v12, v50                                // 00000091F7FC: 0622650C
	ds_load_2addr_b32 v[12:13], v55 offset0:96 offset1:112     // 00000091F800: D8DC7060 0C000037
	s_waitcnt lgkmcnt(4)                                       // 00000091F808: BF89FC47
	v_add_f32_e32 v6, v17, v6                                  // 00000091F80C: 060C0D11
	ds_load_2addr_b32 v[16:17], v2 offset0:96 offset1:112      // 00000091F810: D8DC7060 10000002
	v_add_f32_e32 v2, v24, v7                                  // 00000091F818: 06040F18
	v_dual_add_f32 v7, v18, v31 :: v_dual_add_f32 v18, v19, v46// 00000091F81C: C9083F12 07125D13
	s_waitcnt lgkmcnt(4)                                       // 00000091F824: BF89FC47
	v_dual_add_f32 v19, v25, v47 :: v_dual_add_f32 v6, v6, v52 // 00000091F828: C9085F19 13066906
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091F830: BF870193
	v_add_f32_e32 v2, v2, v53                                  // 00000091F834: 06046B02
	v_dual_add_f32 v7, v7, v33 :: v_dual_add_f32 v10, v10, v32 // 00000091F838: C9084307 070A410A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091F840: BF870091
	v_add_f32_e32 v7, v7, v35                                  // 00000091F844: 060E4707
	v_dual_add_f32 v7, v7, v37 :: v_dual_add_f32 v20, v8, v22  // 00000091F848: C9084B07 07142D08
	v_add_f32_e32 v22, v9, v23                                 // 00000091F850: 062C2F09
	ds_load_2addr_b32 v[8:9], v54 offset0:64 offset1:80        // 00000091F854: D8DC5040 08000036
	s_waitcnt lgkmcnt(0)                                       // 00000091F85C: BF89FC07
	v_dual_add_f32 v9, v19, v9 :: v_dual_add_f32 v8, v18, v8   // 00000091F860: C9081313 09081112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091F868: BF870091
	v_dual_add_f32 v5, v9, v5 :: v_dual_add_f32 v10, v10, v34  // 00000091F86C: C9080B09 050A450A
	v_dual_add_f32 v4, v8, v4 :: v_dual_add_f32 v5, v5, v15    // 00000091F874: C9080908 04041F05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000091F87C: BF8700B2
	v_add_f32_e32 v23, v10, v36                                // 00000091F880: 062E490A
	ds_load_2addr_b32 v[10:11], v54 offset0:96 offset1:112     // 00000091F884: D8DC7060 0A000036
	v_dual_add_f32 v4, v4, v14 :: v_dual_and_b32 v15, 1, v0    // 00000091F88C: C9241D04 040E0081
	.long 0xd44a0000                                           // 00000091F894: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 00000091F898: 02021E80
	s_waitcnt lgkmcnt(0)                                       // 00000091F89C: BF89FC07
	v_add_f32_e32 v6, v6, v10                                  // 00000091F8A0: 060C1506
	v_add_f32_e32 v2, v2, v11                                  // 00000091F8A4: 06041702
	v_add_f32_e32 v10, v23, v7                                 // 00000091F8A8: 06140F17
	v_sub_f32_e32 v7, v23, v7                                  // 00000091F8AC: 080E0F17
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091F8B0: BF870214
	v_dual_add_f32 v11, v4, v5 :: v_dual_add_f32 v6, v6, v12   // 00000091F8B4: C9080B04 0B061906
	v_add_f32_e32 v2, v2, v13                                  // 00000091F8BC: 06041B02
	v_add_f32_e32 v8, v20, v22                                 // 00000091F8C0: 06102D14
	v_sub_f32_e32 v9, v20, v22                                 // 00000091F8C4: 08122D14
	v_sub_f32_e32 v4, v4, v5                                   // 00000091F8C8: 08080B04
	v_add_f32_e32 v6, v6, v16                                  // 00000091F8CC: 060C2106
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091F8D0: BF870214
	v_dual_add_f32 v2, v2, v17 :: v_dual_add_f32 v5, v8, v10   // 00000091F8D4: C9082302 02041508
	v_dual_add_f32 v13, v9, v7 :: v_dual_sub_f32 v8, v8, v10   // 00000091F8DC: C90A0F09 0D081508
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000091F8E4: BF870122
	v_dual_sub_f32 v9, v9, v7 :: v_dual_add_f32 v12, v6, v2    // 00000091F8E8: C9480F09 090C0506
	v_sub_f32_e32 v2, v6, v2                                   // 00000091F8F0: 08040506
	v_add_f32_e32 v6, v11, v12                                 // 00000091F8F4: 060C190B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000091F8F8: BF870232
	v_dual_add_f32 v14, v4, v2 :: v_dual_sub_f32 v11, v11, v12 // 00000091F8FC: C90A0504 0E0A190B
	v_sub_f32_e32 v2, v4, v2                                   // 00000091F904: 08040504
	v_and_b32_e32 v4, 2, v0                                    // 00000091F908: 36080082
	v_add_f32_e32 v10, v5, v6                                  // 00000091F90C: 06140D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091F910: BF870224
	v_add_f32_e32 v7, v13, v14                                 // 00000091F914: 060E1D0D
	v_sub_f32_e32 v6, v5, v6                                   // 00000091F918: 080C0D05
	.long 0xd44a0001                                           // 00000091F91C: D44A0001
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 00000091F920: 02020880
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000091F924: BF870254
	v_mov_b32_dpp v12, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091F928: 7E1802FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 00000091F930: D501000A 2002150A
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091F938: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 00000091F940: D5010007 20020F07
	v_add_f32_e32 v4, v8, v11                                  // 00000091F948: 06081708
	v_dual_sub_f32 v8, v8, v11 :: v_dual_add_f32 v5, v10, v12  // 00000091F94C: C9481708 0804190A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091F954: BF8701A3
	v_dual_sub_f32 v10, v13, v14 :: v_dual_add_f32 v7, v7, v15 // 00000091F958: C9481D0D 0A061F07
	v_dual_add_f32 v14, v9, v2 :: v_dual_and_b32 v11, 4, v0    // 00000091F960: C9240509 0E0A0084
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091F968: 7E1802FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 00000091F970: D5010005 20060B05
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091F978: BF870004
	v_mov_b32_dpp v13, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091F97C: 7E1A02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 00000091F984: D5010007 20060F07
	.long 0xd44a0002                                           // 00000091F98C: D44A0002
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 00000091F990: 02021680
	v_sub_f32_e32 v9, v9, v2                                   // 00000091F994: 08120509
	v_add_f32_e32 v5, v5, v12                                  // 00000091F998: 060A1905
	v_mov_b32_dpp v12, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091F99C: 7E1802FA FF01610E
	v_add_f32_e32 v7, v7, v13                                  // 00000091F9A4: 060E1B07
	v_cndmask_b32_e64 v13, -v14, v14, s0                       // 00000091F9A8: D501000D 20021D0E
	v_mov_b32_dpp v14, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091F9B0: 7E1C02FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 00000091F9B8: D5010004 20020904
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091F9C0: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 00000091F9C8: D5010005 200A0B05
	v_add_f32_e32 v12, v13, v12                                // 00000091F9D0: 0618190D
	v_mov_b32_dpp v13, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091F9D4: 7E1A02FA FF016407
	v_add_f32_e32 v4, v4, v14                                  // 00000091F9DC: 06081D04
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 00000091F9E0: D5010007 200A0F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091F9E8: BF870224
	v_mov_b32_dpp v14, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091F9EC: 7E1C02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 00000091F9F4: D501000C 2006190C
	v_mov_b32_dpp v15, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091F9FC: 7E1E02FA FF016204
	v_cndmask_b32_e64 v16, -v4, v4, s1                         // 00000091FA04: D5010010 20060904
	v_dual_add_f32 v4, v5, v11 :: v_dual_add_f32 v7, v7, v13   // 00000091FA0C: C9081705 04061B07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091FA14: BF870194
	v_add_f32_e32 v11, v12, v14                                // 00000091FA18: 06161D0C
	v_add_f32_e32 v12, v16, v15                                // 00000091FA1C: 06181F10
	v_mov_b32_dpp v15, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091FA20: 7E1E02FA FF016106
	v_cndmask_b32_e64 v16, -v6, v6, s0                         // 00000091FA28: D5010010 20020D06
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091FA30: BF870004
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091FA34: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 00000091FA3C: D501000B 200A170B
	v_mov_b32_dpp v14, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091FA44: 7E1C02FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 00000091FA4C: D501000C 200A190C
	v_mov_b32_dpp v2, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091FA54: 7E0402FA FF016804
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091FA5C: 7E0A02FA FF016807
	v_add_f32_e32 v6, v11, v13                                 // 00000091FA64: 060C1B0B
	v_mov_b32_dpp v11, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091FA68: 7E1602FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 00000091FA70: D501000A 2002150A
	v_add_f32_e32 v13, v16, v15                                // 00000091FA78: 061A1F10
	v_mov_b32_dpp v15, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091FA7C: 7E1E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 00000091FA84: D5010008 20021108
	v_mov_b32_dpp v16, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091FA8C: 7E2002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 00000091FA94: D5010009 20021309
	v_add_f32_e32 v10, v10, v11                                // 00000091FA9C: 0614170A
	v_mov_b32_dpp v11, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091FAA0: 7E1602FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 00000091FAA8: D501000D 20061B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091FAB0: BF870214
	v_dual_add_f32 v8, v8, v15 :: v_dual_add_f32 v9, v9, v16   // 00000091FAB4: C9081F08 08082109
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091FABC: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 00000091FAC4: D501000A 2006150A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091FACC: BF870214
	v_add_f32_e32 v11, v13, v11                                // 00000091FAD0: 0616170D
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091FAD4: 7E1A02FA FF016208
	v_mov_b32_dpp v16, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091FADC: 7E2002FA FF016209
	v_cndmask_b32_e64 v17, -v8, v8, s1                         // 00000091FAE4: D5010011 20061108
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 00000091FAEC: D5010009 20061309
	v_add_f32_e32 v10, v10, v15                                // 00000091FAF4: 06141F0A
	v_add_f32_e32 v8, v12, v14                                 // 00000091FAF8: 06101D0C
	v_mov_b32_dpp v12, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091FAFC: 7E1802FA FF01640B
	v_add_f32_e32 v13, v17, v13                                // 00000091FB04: 061A1B11
	v_add_f32_e32 v9, v9, v16                                  // 00000091FB08: 06122109
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091FB0C: 7E1C02FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 00000091FB14: D501000A 200A150A
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 00000091FB1C: D501000B 200A170B
	v_mov_b32_dpp v16, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091FB24: 7E2002FA FF01640D
	v_mov_b32_dpp v18, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091FB2C: 7E2402FA FF016409
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 00000091FB34: D501000D 200A1B0D
	v_cndmask_b32_e64 v19, -v9, v9, s2                         // 00000091FB3C: D5010013 200A1309
	v_add_f32_e32 v15, v11, v12                                // 00000091FB44: 061E190B
	v_add_f32_e32 v17, v10, v14                                // 00000091FB48: 06221D0A
	v_mov_b32_dpp v9, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091FB4C: 7E1202FA FF016808
	v_add_f32_e32 v16, v13, v16                                // 00000091FB54: 0620210D
	v_add_f32_e32 v18, v19, v18                                // 00000091FB58: 06242513
	v_mov_b32_dpp v10, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091FB5C: 7E1402FA FF016806
	v_mov_b32_dpp v11, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091FB64: 7E1602FA FF01680F
	v_mov_b32_dpp v12, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091FB6C: 7E1802FA FF016811
	v_mov_b32_dpp v13, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091FB74: 7E1A02FA FF016810
	v_mov_b32_dpp v14, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091FB7C: 7E1C02FA FF016812
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 00000091FB84: 8B7E6A7E
	s_cbranch_execz 175                                        // 00000091FB88: BFA500AF <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x4b48>
	v_lshlrev_b32_e32 v19, 1, v1                               // 00000091FB8C: 30260281
	v_add_nc_u32_e32 v1, v3, v21                               // 00000091FB90: 4A022B03
	v_and_b32_e32 v3, 8, v0                                    // 00000091FB94: 36060088
	s_mul_i32 s0, s5, 0x1400                                   // 00000091FB98: 9600FF05 00001400
	s_mul_hi_i32 s1, s5, 0x1400                                // 00000091FBA0: 9701FF05 00001400
	s_add_u32 s2, s20, s0                                      // 00000091FBA8: 80020014
	s_addc_u32 s3, s21, s1                                     // 00000091FBAC: 82030115
	v_cmp_eq_u32_e32 vcc_lo, 0, v3                             // 00000091FBB0: 7C940680
	s_lshl_b32 s0, s4, 7                                       // 00000091FBB4: 84008704
	.long 0x7f283880                                           // 00000091FBB8: 7F283880
	s_ashr_i32 s1, s0, 31                                      // 00000091FBBC: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000091FBC0: BF870009
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000091FBC4: 84808100
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000091FBC8: D5010004 21AA0904
	s_add_u32 s2, s2, s0                                       // 00000091FBD0: 80020002
	s_addc_u32 s3, s3, s1                                      // 00000091FBD4: 82030103
	v_cndmask_b32_e64 v3, -v7, v7, vcc_lo                      // 00000091FBD8: D5010003 21AA0F07
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000091FBE0: D501000F 21AA1F0F
	v_add_f32_e32 v2, v4, v2                                   // 00000091FBE8: 06040504
	s_clause 0x7                                               // 00000091FBEC: BF850007
	global_load_d16_b16 v20, v19, s[2:3] offset:32             // 00000091FBF0: DC820020 14020013
	global_load_d16_b16 v22, v19, s[2:3]                       // 00000091FBF8: DC820000 16020013
	global_load_d16_b16 v23, v19, s[2:3] offset:64             // 00000091FC00: DC820040 17020013
	global_load_d16_b16 v24, v19, s[2:3] offset:96             // 00000091FC08: DC820060 18020013
	global_load_d16_b16 v25, v19, s[2:3] offset:128            // 00000091FC10: DC820080 19020013
	global_load_d16_b16 v26, v19, s[2:3] offset:160            // 00000091FC18: DC8200A0 1A020013
	global_load_d16_b16 v27, v19, s[2:3] offset:192            // 00000091FC20: DC8200C0 1B020013
	global_load_d16_b16 v28, v19, s[2:3] offset:224            // 00000091FC28: DC8200E0 1C020013
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 00000091FC30: D5010010 21AA2110
	v_add_f32_e32 v3, v3, v5                                   // 00000091FC38: 06060B03
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 00000091FC3C: D5010005 21AA0D06
	v_cndmask_b32_e64 v6, -v8, v8, vcc_lo                      // 00000091FC44: D5010006 21AA1108
	v_cndmask_b32_e64 v8, -v17, v17, vcc_lo                    // 00000091FC4C: D5010008 21AA2311
	v_cndmask_b32_e64 v17, -v18, v18, vcc_lo                   // 00000091FC54: D5010011 21AA2512
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 00000091FC5C: 100404FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091FC64: BF870224
	v_dual_add_f32 v5, v5, v10 :: v_dual_add_f32 v4, v6, v9    // 00000091FC68: C9081505 05041306
	v_add_f32_e32 v6, v15, v11                                 // 00000091FC70: 060C170F
	v_dual_add_f32 v10, v17, v14 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 00000091FC74: C9061D11 0A0206FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091FC80: BF870213
	v_dual_add_f32 v8, v8, v12 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 00000091FC84: C9061908 08040AFF 3DB504F3
	v_dual_add_f32 v9, v16, v13 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 00000091FC90: C9061B10 090408FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091FC9C: BF870194
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 00000091FCA0: 100C0CFF 3DB504F3
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 00000091FCA8: 101010FF 3DB504F3
	v_mad_i64_i32 v[0:1], null, 0x1400, v1, s[22:23]           // 00000091FCB0: D6FF7C00 005A02FF 00001400
	s_waitcnt vmcnt(6)                                         // 00000091FCBC: BF891BF7
	.long 0x7f2c3994                                           // 00000091FCC0: 7F2C3994
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 00000091FCC4: 101212FF 3DB504F3
	s_waitcnt vmcnt(5)                                         // 00000091FCCC: BF8917F7
	.long 0x7f2e3994                                           // 00000091FCD0: 7F2E3994
	.long 0x7f0e3994                                           // 00000091FCD4: 7F0E3994
	.long 0x7f2a3994                                           // 00000091FCD8: 7F2A3994
	.long 0xd7006a00                                           // 00000091FCDC: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000091FCE0: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091FCE4: BF870111
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000091FCE8: D5207C01 01AA0201
	.long 0xd7006a00                                           // 00000091FCF0: D7006A00
	v_cndmask_b32_e32 v1, v0, v19, vcc_lo                      // 00000091FCF4: 02022700
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091FCF8: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000091FCFC: D5207C01 01AA0280
	v_fma_mix_f32 v3, v20, v3, neg(0) op_sel_hi:[1,0,0]        // 00000091FD04: CC200003 8A020714
	v_fma_mix_f32 v2, v22, v2, neg(0) op_sel_hi:[1,0,0]        // 00000091FD0C: CC200002 8A020516
	v_fma_mix_f32 v4, v23, v4, neg(0) op_sel_hi:[1,0,0]        // 00000091FD14: CC200004 8A020917
	s_waitcnt vmcnt(4)                                         // 00000091FD1C: BF8913F7
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 00000091FD20: CC200005 8A020B18
	s_waitcnt vmcnt(3)                                         // 00000091FD28: BF890FF7
	v_fma_mix_f32 v6, v25, v6, neg(0) op_sel_hi:[1,0,0]        // 00000091FD2C: CC200006 8A020D19
	.long 0x7e283983                                           // 00000091FD34: 7E283983
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 00000091FD38: 101414FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 00000091FD40: BF890BF7
	v_fma_mix_f32 v8, v26, v8, neg(0) op_sel_hi:[1,0,0]        // 00000091FD44: CC200008 8A02111A
	s_waitcnt vmcnt(1)                                         // 00000091FD4C: BF8907F7
	v_fma_mix_f32 v9, v27, v9, neg(0) op_sel_hi:[1,0,0]        // 00000091FD50: CC200009 8A02131B
	.long 0x7e0e3982                                           // 00000091FD58: 7E0E3982
	v_and_b32_e32 v11, 1, v20                                  // 00000091FD5C: 36162881
	.long 0x7e283985                                           // 00000091FD60: 7E283985
	s_waitcnt vmcnt(0)                                         // 00000091FD64: BF8903F7
	v_fma_mix_f32 v10, v28, v10, neg(0) op_sel_hi:[1,0,0]      // 00000091FD68: CC20000A 8A02151C
	.long 0x7e2a3984                                           // 00000091FD70: 7E2A3984
	.long 0x7e2c3986                                           // 00000091FD74: 7E2C3986
	.long 0x7e2e3989                                           // 00000091FD78: 7E2E3989
	v_and_b32_e32 v12, 1, v20                                  // 00000091FD7C: 36182881
	.long 0x7e283988                                           // 00000091FD80: 7E283988
	v_and_b32_e32 v7, 1, v7                                    // 00000091FD84: 360E0E81
	v_and_b32_e32 v13, 1, v21                                  // 00000091FD88: 361A2A81
	v_and_b32_e32 v14, 1, v22                                  // 00000091FD8C: 361C2C81
	v_and_b32_e32 v16, 1, v23                                  // 00000091FD90: 36202E81
	v_and_b32_e32 v15, 1, v20                                  // 00000091FD94: 361E2881
	.long 0x7e28398a                                           // 00000091FD98: 7E28398A
	v_add3_u32 v2, v2, v7, 0x7fff                              // 00000091FD9C: D6550002 03FE0F02 00007FFF
	v_add3_u32 v3, v3, v11, 0x7fff                             // 00000091FDA8: D6550003 03FE1703 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 00000091FDB4: D6550004 03FE1B04 00007FFF
	v_add3_u32 v5, v5, v12, 0x7fff                             // 00000091FDC0: D6550005 03FE1905 00007FFF
	v_and_b32_e32 v7, 1, v20                                   // 00000091FDCC: 360E2881
	v_add3_u32 v6, v6, v14, 0x7fff                             // 00000091FDD0: D6550006 03FE1D06 00007FFF
	v_add3_u32 v9, v9, v16, 0x7fff                             // 00000091FDDC: D6550009 03FE2109 00007FFF
	v_add3_u32 v8, v8, v15, 0x7fff                             // 00000091FDE8: D6550008 03FE1F08 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091FDF4: BF870004
	v_add3_u32 v7, v10, v7, 0x7fff                             // 00000091FDF8: D6550007 03FE0F0A 00007FFF
	s_clause 0x7                                               // 00000091FE04: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000091FE08: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 00000091FE10: DC960020 007C0300
	global_store_d16_hi_b16 v[0:1], v4, off offset:64          // 00000091FE18: DC960040 007C0400
	global_store_d16_hi_b16 v[0:1], v5, off offset:96          // 00000091FE20: DC960060 007C0500
	global_store_d16_hi_b16 v[0:1], v6, off offset:128         // 00000091FE28: DC960080 007C0600
	global_store_d16_hi_b16 v[0:1], v8, off offset:160         // 00000091FE30: DC9600A0 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:192         // 00000091FE38: DC9600C0 007C0900
	global_store_d16_hi_b16 v[0:1], v7, off offset:224         // 00000091FE40: DC9600E0 007C0700
	s_nop 0                                                    // 00000091FE48: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000091FE4C: BFB60003
	s_endpgm                                                   // 00000091FE50: BFB00000
	s_branch 63395                                             // 00000091FE54: BFA0F7A3 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x29e4>
		...

