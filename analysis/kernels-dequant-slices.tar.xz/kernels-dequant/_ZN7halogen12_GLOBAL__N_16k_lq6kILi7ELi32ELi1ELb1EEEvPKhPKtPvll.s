000000000071e200 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi7ELi32ELi1ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi7ELi32ELi1ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 00000071E200: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 00000071E204: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000071E20C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 00000071E214: BE830080
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000071E218: 32020085
	s_lshl_b64 s[0:1], s[2:3], 3                               // 00000071E21C: 84808302
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 00000071E220: CA100080 08080080
	v_dual_mov_b32 v2, s1 :: v_dual_mov_b32 v13, 0             // 00000071E228: CA100001 020C0080
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 00000071E230: CA100080 0A0A0080
	v_dual_mov_b32 v12, 0 :: v_dual_and_b32 v7, 31, v0         // 00000071E238: CA240080 0C06009F
	v_or_b32_e32 v1, s0, v1                                    // 00000071E240: 38020200
	v_mov_b32_e32 v14, 0                                       // 00000071E244: 7E1C0280
	s_waitcnt lgkmcnt(0)                                       // 00000071E248: BF89FC07
	s_ashr_i32 s1, s11, 31                                     // 00000071E24C: 86019F0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000071E250: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000071E254: 7CA8020C
	s_lshr_b32 s1, s1, 28                                      // 00000071E258: 85019C01
	s_add_u32 s0, s10, s1                                      // 00000071E25C: 8000010A
	s_addc_u32 s1, s11, 0                                      // 00000071E260: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000071E264: BF870009
	s_lshr_b64 s[14:15], s[0:1], 4                             // 00000071E268: 858E8400
	s_mov_b32 s1, exec_lo                                      // 00000071E26C: BE81007E
	.long 0xd4c4007e                                           // 00000071E270: D4C4007E
	v_cndmask_b32_e32 v1, s14, v7, vcc_lo                      // 00000071E274: 02020E0E
	s_cbranch_execz 631                                        // 00000071E278: BFA50277 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi7ELi32ELi1ELb1EEEvPKhPKtPvll+0xa58>
	s_ashr_i32 s0, s11, 31                                     // 00000071E27C: 86009F0B
	v_dual_cndmask_b32 v3, 0, v2 :: v_dual_and_b32 v16, 4, v0  // 00000071E280: CA640480 03100084
	s_lshr_b32 s0, s0, 24                                      // 00000071E288: 85009800
	v_cndmask_b32_e32 v5, 0, v1, vcc_lo                        // 00000071E28C: 020A0280
	s_add_u32 s16, s10, s0                                     // 00000071E290: 8010000A
	s_addc_u32 s17, s11, 0                                     // 00000071E294: 8211800B
	v_bfe_u32 v9, v0, 3, 1                                     // 00000071E298: D6100009 02050700
	s_ashr_i64 s[16:17], s[16:17], 8                           // 00000071E2A0: 86908810
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v15, 6, v0          // 00000071E2A4: CA240080 060E0086
	s_mul_i32 s0, s17, 0xd2                                    // 00000071E2AC: 9600FF11 000000D2
	s_mul_hi_u32 s2, s16, 0xd2                                 // 00000071E2B4: 9682FF10 000000D2
	s_mul_i32 s15, s16, 0xd2                                   // 00000071E2BC: 960FFF10 000000D2
	s_add_i32 s2, s2, s0                                       // 00000071E2C4: 81020002
	.long 0xd72c0008                                           // 00000071E2C8: D72C0008
	v_cndmask_b32_e32 v1, s15, v3, vcc_lo                      // 00000071E2CC: 0202060F
	v_and_b32_e32 v0, 15, v0                                   // 00000071E2D0: 3600008F
	v_mad_u64_u32 v[3:4], null, s15, v5, s[4:5]                // 00000071E2D4: D6FE7C03 00120A0F
	.long 0xd72c0005                                           // 00000071E2DC: D72C0005
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000071E2E0: 02020A02
	v_dual_mov_b32 v26, v7 :: v_dual_lshlrev_b32 v17, 6, v9    // 00000071E2E4: CA220107 1A101286
	v_dual_mov_b32 v13, v6 :: v_dual_lshlrev_b32 v18, 5, v9    // 00000071E2EC: CA220106 0D121285
	v_or_b32_e32 v19, 8, v16                                   // 00000071E2F4: 38262088
	v_or_b32_e32 v20, 8, v15                                   // 00000071E2F8: 38281E88
	v_or_b32_e32 v21, 16, v16                                  // 00000071E2FC: 382A2090
	v_add3_u32 v4, v5, v4, v8                                  // 00000071E300: D6550004 04220905
	v_lshrrev_b32_e32 v8, 4, v7                                // 00000071E308: 32100E84
	v_or_b32_e32 v22, 16, v15                                  // 00000071E30C: 382C1E90
	v_or_b32_e32 v23, 24, v16                                  // 00000071E310: 382E2098
	v_or_b32_e32 v24, 24, v15                                  // 00000071E314: 38301E98
	v_dual_mov_b32 v14, v6 :: v_dual_lshlrev_b32 v5, 4, v7     // 00000071E318: CA220106 0E040E84
	v_mul_u32_u24_e32 v25, 0xd2, v8                            // 00000071E320: 163210FF 000000D2
	v_mov_b32_e32 v12, v6                                      // 00000071E328: 7E180306
	v_mov_b32_e32 v11, v6                                      // 00000071E32C: 7E160306
	v_mov_b32_e32 v10, v6                                      // 00000071E330: 7E140306
	v_mov_b32_e32 v9, v6                                       // 00000071E334: 7E120306
	v_mov_b32_e32 v8, v6                                       // 00000071E338: 7E100306
	s_mul_i32 s0, s11, 6                                       // 00000071E33C: 9600860B
	s_mul_hi_u32 s2, s10, 6                                    // 00000071E340: 9682860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000071E344: 8484820A
	s_add_i32 s2, s2, s0                                       // 00000071E348: 81020002
	s_mul_i32 s15, s10, 6                                      // 00000071E34C: 960F860A
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000071E350: 848A810A
	.long 0xd700001b                                           // 00000071E354: D700001B
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 00000071E358: 02023303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000071E35C: BF8701A1
	v_add_co_ci_u32_e64 v28, null, 0, v4, s0                   // 00000071E360: D5207C1C 00020880
	v_and_b32_e32 v31, 32, v5                                  // 00000071E368: 363E0AA0
	.long 0xd700001d                                           // 00000071E36C: D700001D
	v_cndmask_b32_e32 v1, v27, v17, vcc_lo                     // 00000071E370: 0202231B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000071E374: BF8701A1
	v_add_co_ci_u32_e64 v30, null, 0, v28, s0                  // 00000071E378: D5207C1E 00023880
	v_and_b32_e32 v35, 16, v5                                  // 00000071E380: 36460A90
	.long 0xd700001d                                           // 00000071E384: D700001D
	v_cndmask_b32_e32 v1, v29, v31, vcc_lo                     // 00000071E388: 02023F1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000071E38C: BF8701A1
	v_add_co_ci_u32_e64 v30, null, 0, v30, s0                  // 00000071E390: D5207C1E 00023C80
	v_add_nc_u32_e32 v25, 0x1a4, v25                           // 00000071E398: 4A3232FF 000001A4
	.long 0xd700001d                                           // 00000071E3A0: D700001D
	v_cndmask_b32_e32 v1, v29, v35, vcc_lo                     // 00000071E3A4: 0202471D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000071E3A8: BF8700C1
	v_add_co_ci_u32_e64 v30, null, 0, v30, s0                  // 00000071E3AC: D5207C1E 00023C80
	v_add_nc_u32_e32 v26, 32, v26                              // 00000071E3B4: 4A3434A0
	global_load_b128 v[31:34], v[29:30], off                   // 00000071E3B8: DC5E0000 1F7C001D
	.long 0xd700001d                                           // 00000071E3C0: D700001D
	v_cndmask_b32_e32 v1, v27, v18, vcc_lo                     // 00000071E3C4: 0202251B
	v_add_co_ci_u32_e64 v30, null, 0, v28, s0                  // 00000071E3C8: D5207C1E 00023880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E3D0: BF870092
	.long 0xd700001d                                           // 00000071E3D4: D700001D
	v_cndmask_b32_e32 v1, v29, v35, vcc_lo                     // 00000071E3D8: 0202471D
	v_add_co_ci_u32_e64 v30, null, 0, v30, s0                  // 00000071E3DC: D5207C1E 00023C80
	global_load_b128 v[35:38], v[29:30], off offset:128        // 00000071E3E4: DC5E0080 237C001D
	.long 0xd700001d                                           // 00000071E3EC: D700001D
	v_cndmask_b32_e32 v1, v27, v0, vcc_lo                      // 00000071E3F0: 0202011B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000071E3F4: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v28, s0                  // 00000071E3F8: D5207C1E 00023880
	s_clause 0x1                                               // 00000071E400: BF850001
	global_load_d16_b16 v27, v[27:28], off offset:208          // 00000071E404: DC8200D0 1B7C001B
	global_load_i8 v29, v[29:30], off offset:192               // 00000071E40C: DC4600C0 1D7C001D
	s_waitcnt vmcnt(2)                                         // 00000071E414: BF890BF7
	v_lshrrev_b32_e32 v28, v15, v35                            // 00000071E418: 3238470F
	v_lshrrev_b32_e32 v30, v22, v35                            // 00000071E41C: 323C4716
	s_waitcnt vmcnt(0)                                         // 00000071E420: BF8903F7
	v_cvt_f32_i32_e32 v29, v29                                 // 00000071E424: 7E3A0B1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000071E428: BF870141
	v_fma_mix_f32 v39, v27, v29, neg(0) op_sel_hi:[1,0,0]      // 00000071E42C: CC200027 8A023B1B
	v_bfe_u32 v27, v31, v16, 4                                 // 00000071E434: D610001B 0212211F
	v_lshlrev_b32_e32 v28, 4, v28                              // 00000071E43C: 30383884
	v_lshlrev_b32_e32 v30, 4, v30                              // 00000071E440: 303C3C84
	v_and_or_b32 v27, v28, 48, v27                             // 00000071E444: D657001B 046D611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E44C: BF870091
	v_subrev_nc_u32_e32 v27, 32, v27                           // 00000071E450: 4E3636A0
	v_cvt_f32_i32_e32 v27, v27                                 // 00000071E454: 7E360B1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E458: BF870091
	v_mul_f32_e32 v27, v39, v27                                // 00000071E45C: 10363727
	v_bfe_u32 v28, v27, 16, 1                                  // 00000071E460: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000071E468: BF870131
	v_add3_u32 v29, v27, v28, 0x7fff                           // 00000071E46C: D655001D 03FE391B 00007FFF
	v_lshrrev_b32_e32 v28, v20, v35                            // 00000071E478: 32384714
	v_bfe_u32 v27, v31, v19, 4                                 // 00000071E47C: D610001B 0212271F
	v_lshlrev_b32_e32 v28, 4, v28                              // 00000071E484: 30383884
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E488: BF870091
	v_and_or_b32 v27, v28, 48, v27                             // 00000071E48C: D657001B 046D611C
	v_subrev_nc_u32_e32 v27, 32, v27                           // 00000071E494: 4E3636A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E498: BF870091
	v_cvt_f32_i32_e32 v27, v27                                 // 00000071E49C: 7E360B1B
	v_mul_f32_e32 v27, v39, v27                                // 00000071E4A0: 10363727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E4A4: BF870091
	v_bfe_u32 v28, v27, 16, 1                                  // 00000071E4A8: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000071E4B0: D655001B 03FE391B 00007FFF
	v_bfe_u32 v28, v31, v21, 4                                 // 00000071E4BC: D610001C 02122B1F
	.long 0x7e36399d                                           // 00000071E4C4: 7E36399D
	v_bfe_u32 v29, v32, v16, 4                                 // 00000071E4C8: D610001D 02122120
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E4D0: BF870093
	v_and_or_b32 v28, v30, 48, v28                             // 00000071E4D4: D657001C 0471611E
	v_subrev_nc_u32_e32 v28, 32, v28                           // 00000071E4DC: 4E3838A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E4E0: BF870091
	v_cvt_f32_i32_e32 v28, v28                                 // 00000071E4E4: 7E380B1C
	v_mul_f32_e32 v28, v39, v28                                // 00000071E4E8: 10383927
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E4EC: BF870091
	v_bfe_u32 v30, v28, 16, 1                                  // 00000071E4F0: D610001E 0205211C
	v_add3_u32 v30, v28, v30, 0x7fff                           // 00000071E4F8: D655001E 03FE3D1C 00007FFF
	v_bfe_u32 v28, v31, v23, 4                                 // 00000071E504: D610001C 02122F1F
	v_lshrrev_b32_e32 v31, v24, v35                            // 00000071E50C: 323E4718
	v_lshrrev_b32_e32 v35, v22, v36                            // 00000071E510: 32464916
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000071E514: BF870112
	v_lshlrev_b32_e32 v31, 4, v31                              // 00000071E518: 303E3E84
	v_lshlrev_b32_e32 v35, 4, v35                              // 00000071E51C: 30464684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E520: BF870092
	v_and_or_b32 v28, v31, 48, v28                             // 00000071E524: D657001C 0471611F
	v_subrev_nc_u32_e32 v28, 32, v28                           // 00000071E52C: 4E3838A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E530: BF870091
	v_cvt_f32_i32_e32 v28, v28                                 // 00000071E534: 7E380B1C
	v_mul_f32_e32 v28, v39, v28                                // 00000071E538: 10383927
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E53C: BF870091
	v_bfe_u32 v31, v28, 16, 1                                  // 00000071E540: D610001F 0205211C
	v_add3_u32 v28, v28, v31, 0x7fff                           // 00000071E548: D655001C 03FE3F1C 00007FFF
	.long 0x7e38399e                                           // 00000071E554: 7E38399E
	v_lshrrev_b32_e32 v30, v15, v36                            // 00000071E558: 323C490F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E55C: BF870091
	v_lshlrev_b32_e32 v30, 4, v30                              // 00000071E560: 303C3C84
	v_and_or_b32 v29, v30, 48, v29                             // 00000071E564: D657001D 0475611E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E56C: BF870091
	v_subrev_nc_u32_e32 v29, 32, v29                           // 00000071E570: 4E3A3AA0
	v_cvt_f32_i32_e32 v29, v29                                 // 00000071E574: 7E3A0B1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E578: BF870091
	v_mul_f32_e32 v29, v39, v29                                // 00000071E57C: 103A3B27
	v_bfe_u32 v30, v29, 16, 1                                  // 00000071E580: D610001E 0205211D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000071E588: BF870131
	v_add3_u32 v31, v29, v30, 0x7fff                           // 00000071E58C: D655001F 03FE3D1D 00007FFF
	v_lshrrev_b32_e32 v30, v20, v36                            // 00000071E598: 323C4914
	v_bfe_u32 v29, v32, v19, 4                                 // 00000071E59C: D610001D 02122720
	v_lshlrev_b32_e32 v30, 4, v30                              // 00000071E5A4: 303C3C84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E5A8: BF870091
	v_and_or_b32 v29, v30, 48, v29                             // 00000071E5AC: D657001D 0475611E
	v_subrev_nc_u32_e32 v29, 32, v29                           // 00000071E5B4: 4E3A3AA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E5B8: BF870091
	v_cvt_f32_i32_e32 v29, v29                                 // 00000071E5BC: 7E3A0B1D
	v_mul_f32_e32 v29, v39, v29                                // 00000071E5C0: 103A3B27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E5C4: BF870091
	v_bfe_u32 v30, v29, 16, 1                                  // 00000071E5C8: D610001E 0205211D
	v_add3_u32 v29, v29, v30, 0x7fff                           // 00000071E5D0: D655001D 03FE3D1D 00007FFF
	v_bfe_u32 v30, v32, v21, 4                                 // 00000071E5DC: D610001E 02122B20
	.long 0x7e3a399f                                           // 00000071E5E4: 7E3A399F
	v_bfe_u32 v31, v33, v16, 4                                 // 00000071E5E8: D610001F 02122121
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E5F0: BF870093
	v_and_or_b32 v30, v35, 48, v30                             // 00000071E5F4: D657001E 04796123
	v_subrev_nc_u32_e32 v30, 32, v30                           // 00000071E5FC: 4E3C3CA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E600: BF870091
	v_cvt_f32_i32_e32 v30, v30                                 // 00000071E604: 7E3C0B1E
	v_mul_f32_e32 v30, v39, v30                                // 00000071E608: 103C3D27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E60C: BF870091
	v_bfe_u32 v35, v30, 16, 1                                  // 00000071E610: D6100023 0205211E
	v_add3_u32 v35, v30, v35, 0x7fff                           // 00000071E618: D6550023 03FE471E 00007FFF
	v_bfe_u32 v30, v32, v23, 4                                 // 00000071E624: D610001E 02122F20
	v_lshrrev_b32_e32 v32, v24, v36                            // 00000071E62C: 32404918
	v_lshrrev_b32_e32 v36, v22, v37                            // 00000071E630: 32484B16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000071E634: BF870112
	v_lshlrev_b32_e32 v32, 4, v32                              // 00000071E638: 30404084
	v_lshlrev_b32_e32 v36, 4, v36                              // 00000071E63C: 30484884
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E640: BF870092
	v_and_or_b32 v30, v32, 48, v30                             // 00000071E644: D657001E 04796120
	v_subrev_nc_u32_e32 v30, 32, v30                           // 00000071E64C: 4E3C3CA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E650: BF870091
	v_cvt_f32_i32_e32 v30, v30                                 // 00000071E654: 7E3C0B1E
	v_mul_f32_e32 v30, v39, v30                                // 00000071E658: 103C3D27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E65C: BF870091
	v_bfe_u32 v32, v30, 16, 1                                  // 00000071E660: D6100020 0205211E
	v_add3_u32 v30, v30, v32, 0x7fff                           // 00000071E668: D655001E 03FE411E 00007FFF
	v_lshrrev_b32_e32 v32, v15, v37                            // 00000071E674: 32404B0F
	.long 0x7e3c39a3                                           // 00000071E678: 7E3C39A3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E67C: BF870092
	v_lshlrev_b32_e32 v32, 4, v32                              // 00000071E680: 30404084
	v_and_or_b32 v31, v32, 48, v31                             // 00000071E684: D657001F 047D6120
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E68C: BF870091
	v_subrev_nc_u32_e32 v31, 32, v31                           // 00000071E690: 4E3E3EA0
	v_cvt_f32_i32_e32 v31, v31                                 // 00000071E694: 7E3E0B1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E698: BF870091
	v_mul_f32_e32 v31, v39, v31                                // 00000071E69C: 103E3F27
	v_bfe_u32 v32, v31, 16, 1                                  // 00000071E6A0: D6100020 0205211F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000071E6A8: BF870131
	v_add3_u32 v35, v31, v32, 0x7fff                           // 00000071E6AC: D6550023 03FE411F 00007FFF
	v_lshrrev_b32_e32 v32, v20, v37                            // 00000071E6B8: 32404B14
	v_bfe_u32 v31, v33, v19, 4                                 // 00000071E6BC: D610001F 02122721
	v_lshlrev_b32_e32 v32, 4, v32                              // 00000071E6C4: 30404084
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E6C8: BF870091
	v_and_or_b32 v31, v32, 48, v31                             // 00000071E6CC: D657001F 047D6120
	v_subrev_nc_u32_e32 v31, 32, v31                           // 00000071E6D4: 4E3E3EA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E6D8: BF870091
	v_cvt_f32_i32_e32 v31, v31                                 // 00000071E6DC: 7E3E0B1F
	v_mul_f32_e32 v31, v39, v31                                // 00000071E6E0: 103E3F27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E6E4: BF870091
	v_bfe_u32 v32, v31, 16, 1                                  // 00000071E6E8: D6100020 0205211F
	v_add3_u32 v31, v31, v32, 0x7fff                           // 00000071E6F0: D655001F 03FE411F 00007FFF
	v_bfe_u32 v32, v33, v21, 4                                 // 00000071E6FC: D6100020 02122B21
	.long 0x7e3e39a3                                           // 00000071E704: 7E3E39A3
	v_lshrrev_b32_e32 v35, v15, v38                            // 00000071E708: 32464D0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000071E70C: BF870113
	v_and_or_b32 v32, v36, 48, v32                             // 00000071E710: D6570020 04816124
	v_lshlrev_b32_e32 v35, 4, v35                              // 00000071E718: 30464684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E71C: BF870092
	v_subrev_nc_u32_e32 v32, 32, v32                           // 00000071E720: 4E4040A0
	v_cvt_f32_i32_e32 v32, v32                                 // 00000071E724: 7E400B20
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E728: BF870091
	v_mul_f32_e32 v32, v39, v32                                // 00000071E72C: 10404127
	v_bfe_u32 v36, v32, 16, 1                                  // 00000071E730: D6100024 02052120
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000071E738: BF870141
	v_add3_u32 v36, v32, v36, 0x7fff                           // 00000071E73C: D6550024 03FE4920 00007FFF
	v_bfe_u32 v32, v33, v23, 4                                 // 00000071E748: D6100020 02122F21
	v_lshrrev_b32_e32 v33, v24, v37                            // 00000071E750: 32424B18
	v_lshrrev_b32_e32 v37, v22, v38                            // 00000071E754: 324A4D16
	v_lshlrev_b32_e32 v33, 4, v33                              // 00000071E758: 30424284
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000071E75C: BF870112
	v_lshlrev_b32_e32 v37, 4, v37                              // 00000071E760: 304A4A84
	v_and_or_b32 v32, v33, 48, v32                             // 00000071E764: D6570020 04816121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E76C: BF870091
	v_subrev_nc_u32_e32 v32, 32, v32                           // 00000071E770: 4E4040A0
	v_cvt_f32_i32_e32 v32, v32                                 // 00000071E774: 7E400B20
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E778: BF870091
	v_mul_f32_e32 v32, v39, v32                                // 00000071E77C: 10404127
	v_bfe_u32 v33, v32, 16, 1                                  // 00000071E780: D6100021 02052120
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000071E788: BF8701C1
	v_add3_u32 v32, v32, v33, 0x7fff                           // 00000071E78C: D6550020 03FE4320 00007FFF
	v_bfe_u32 v33, v34, v16, 4                                 // 00000071E798: D6100021 02122122
	.long 0x7e4039a4                                           // 00000071E7A0: 7E4039A4
	v_lshrrev_b32_e32 v36, v20, v38                            // 00000071E7A4: 32484D14
	v_and_or_b32 v33, v35, 48, v33                             // 00000071E7A8: D6570021 04856123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000071E7B0: BF870112
	v_lshlrev_b32_e32 v36, 4, v36                              // 00000071E7B4: 30484884
	v_subrev_nc_u32_e32 v33, 32, v33                           // 00000071E7B8: 4E4242A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E7BC: BF870091
	v_cvt_f32_i32_e32 v33, v33                                 // 00000071E7C0: 7E420B21
	v_mul_f32_e32 v33, v39, v33                                // 00000071E7C4: 10424327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E7C8: BF870091
	v_bfe_u32 v35, v33, 16, 1                                  // 00000071E7CC: D6100023 02052121
	v_add3_u32 v35, v33, v35, 0x7fff                           // 00000071E7D4: D6550023 03FE4721 00007FFF
	v_bfe_u32 v33, v34, v19, 4                                 // 00000071E7E0: D6100021 02122722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E7E8: BF870091
	v_and_or_b32 v33, v36, 48, v33                             // 00000071E7EC: D6570021 04856124
	v_subrev_nc_u32_e32 v33, 32, v33                           // 00000071E7F4: 4E4242A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E7F8: BF870091
	v_cvt_f32_i32_e32 v33, v33                                 // 00000071E7FC: 7E420B21
	v_mul_f32_e32 v33, v39, v33                                // 00000071E800: 10424327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E804: BF870091
	v_bfe_u32 v36, v33, 16, 1                                  // 00000071E808: D6100024 02052121
	v_add3_u32 v33, v33, v36, 0x7fff                           // 00000071E810: D6550021 03FE4921 00007FFF
	v_bfe_u32 v36, v34, v21, 4                                 // 00000071E81C: D6100024 02122B22
	v_bfe_u32 v34, v34, v23, 4                                 // 00000071E824: D6100022 02122F22
	.long 0x7e4239a3                                           // 00000071E82C: 7E4239A3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E830: BF870093
	v_and_or_b32 v36, v37, 48, v36                             // 00000071E834: D6570024 04916125
	v_subrev_nc_u32_e32 v36, 32, v36                           // 00000071E83C: 4E4848A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E840: BF870091
	v_cvt_f32_i32_e32 v36, v36                                 // 00000071E844: 7E480B24
	v_mul_f32_e32 v36, v39, v36                                // 00000071E848: 10484927
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E84C: BF870091
	v_bfe_u32 v37, v36, 16, 1                                  // 00000071E850: D6100025 02052124
	v_add3_u32 v36, v36, v37, 0x7fff                           // 00000071E858: D6550024 03FE4B24 00007FFF
	v_lshrrev_b32_e32 v37, v24, v38                            // 00000071E864: 324A4D18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E868: BF870091
	v_lshlrev_b32_e32 v37, 4, v37                              // 00000071E86C: 304A4A84
	v_and_or_b32 v34, v37, 48, v34                             // 00000071E870: D6570022 04896125
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E878: BF870091
	v_subrev_nc_u32_e32 v34, 32, v34                           // 00000071E87C: 4E4444A0
	v_cvt_f32_i32_e32 v34, v34                                 // 00000071E880: 7E440B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E884: BF870091
	v_mul_f32_e32 v34, v39, v34                                // 00000071E888: 10444527
	v_bfe_u32 v37, v34, 16, 1                                  // 00000071E88C: D6100025 02052122
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000071E894: BF870141
	v_add3_u32 v34, v34, v37, 0x7fff                           // 00000071E898: D6550022 03FE4B22 00007FFF
	.long 0x7e4439a4                                           // 00000071E8A4: 7E4439A4
	.long 0xd73c0023                                           // 00000071E8A8: D73C0023
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000071E8AC: 02020A81
	v_add_nc_u32_e32 v5, 0x200, v5                             // 00000071E8B0: 4A0A0AFF 00000200
	.long 0xd700002b                                           // 00000071E8B8: D700002B
	v_cndmask_b32_e32 v1, s6, v35, vcc_lo                      // 00000071E8BC: 02024606
	s_delay_alu instid0(VALU_DEP_1)                            // 00000071E8C0: BF870001
	v_add_co_ci_u32_e64 v44, null, s7, v36, s0                 // 00000071E8C4: D5207C2C 00024807
	s_clause 0x1                                               // 00000071E8CC: BF850001
	global_load_b128 v[35:38], v[43:44], off                   // 00000071E8D0: DC5E0000 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:16         // 00000071E8D8: DC5E0010 277C002B
	s_waitcnt vmcnt(1)                                         // 00000071E8E0: BF8907F7
	v_dot2_f32_bf16 v35, v35, v27, 0                           // 00000071E8E4: CC1A4023 1A023723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E8EC: BF870091
	v_dot2_f32_bf16 v35, v36, v28, v35                         // 00000071E8F0: CC1A4023 1C8E3924
	v_dot2_f32_bf16 v35, v37, v29, v35                         // 00000071E8F8: CC1A4023 1C8E3B25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000071E900: BF8700A1
	v_dot2_f32_bf16 v35, v38, v30, v35                         // 00000071E904: CC1A4023 1C8E3D26
	s_waitcnt vmcnt(0)                                         // 00000071E90C: BF8903F7
	v_dot2_f32_bf16 v35, v39, v31, v35                         // 00000071E910: CC1A4023 1C8E3F27
	.long 0xd7000027                                           // 00000071E918: D7000027
	v_cndmask_b32_e32 v0, v43, v10, vcc_lo                     // 00000071E91C: 0200152B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000071E920: BF8701B2
	v_dot2_f32_bf16 v35, v40, v32, v35                         // 00000071E924: CC1A4023 1C8E4128
	v_add_co_ci_u32_e64 v40, null, s11, v44, s0                // 00000071E92C: D5207C28 0002580B
	.long 0xd700002d                                           // 00000071E934: D700002D
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 00000071E938: 0200092B
	v_dot2_f32_bf16 v35, v41, v33, v35                         // 00000071E93C: CC1A4023 1C8E4329
	v_add_co_ci_u32_e64 v46, null, s5, v44, s0                 // 00000071E944: D5207C2E 00025805
	.long 0xd700002b                                           // 00000071E94C: D700002B
	v_cndmask_b32_e32 v0, v43, v15, vcc_lo                     // 00000071E950: 02001F2B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000071E954: BF870123
	v_dot2_f32_bf16 v35, v42, v34, v35                         // 00000071E958: CC1A4023 1C8E452A
	v_add_co_ci_u32_e64 v44, null, s2, v44, s0                 // 00000071E960: D5207C2C 00025802
	v_add_f32_e32 v14, v14, v35                                // 00000071E968: 061C470E
	s_clause 0x1                                               // 00000071E96C: BF850001
	global_load_b128 v[35:38], v[39:40], off                   // 00000071E970: DC5E0000 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:16         // 00000071E978: DC5E0010 277C0027
	s_waitcnt vmcnt(1)                                         // 00000071E980: BF8907F7
	v_dot2_f32_bf16 v35, v35, v27, 0                           // 00000071E984: CC1A4023 1A023723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E98C: BF870091
	v_dot2_f32_bf16 v35, v36, v28, v35                         // 00000071E990: CC1A4023 1C8E3924
	v_dot2_f32_bf16 v35, v37, v29, v35                         // 00000071E998: CC1A4023 1C8E3B25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000071E9A0: BF8700A1
	v_dot2_f32_bf16 v35, v38, v30, v35                         // 00000071E9A4: CC1A4023 1C8E3D26
	s_waitcnt vmcnt(0)                                         // 00000071E9AC: BF8903F7
	v_dot2_f32_bf16 v35, v39, v31, v35                         // 00000071E9B0: CC1A4023 1C8E3F27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E9B8: BF870091
	v_dot2_f32_bf16 v35, v40, v32, v35                         // 00000071E9BC: CC1A4023 1C8E4128
	v_dot2_f32_bf16 v35, v41, v33, v35                         // 00000071E9C4: CC1A4023 1C8E4329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071E9CC: BF870091
	v_dot2_f32_bf16 v35, v42, v34, v35                         // 00000071E9D0: CC1A4023 1C8E452A
	v_add_f32_e32 v13, v13, v35                                // 00000071E9D8: 061A470D
	s_clause 0x1                                               // 00000071E9DC: BF850001
	global_load_b128 v[35:38], v[45:46], off                   // 00000071E9E0: DC5E0000 237C002D
	global_load_b128 v[39:42], v[45:46], off offset:16         // 00000071E9E8: DC5E0010 277C002D
	.long 0xd700002d                                           // 00000071E9F0: D700002D
	v_cndmask_b32_e32 v0, v45, v4, vcc_lo                      // 00000071E9F4: 0200092D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000071E9F8: BF8700B1
	v_add_co_ci_u32_e64 v46, null, s5, v46, s0                 // 00000071E9FC: D5207C2E 00025C05
	s_waitcnt vmcnt(1)                                         // 00000071EA04: BF8907F7
	v_dot2_f32_bf16 v35, v35, v27, 0                           // 00000071EA08: CC1A4023 1A023723
	v_dot2_f32_bf16 v35, v36, v28, v35                         // 00000071EA10: CC1A4023 1C8E3924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071EA18: BF870091
	v_dot2_f32_bf16 v35, v37, v29, v35                         // 00000071EA1C: CC1A4023 1C8E3B25
	v_dot2_f32_bf16 v35, v38, v30, v35                         // 00000071EA24: CC1A4023 1C8E3D26
	s_waitcnt vmcnt(0)                                         // 00000071EA2C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071EA30: BF870091
	v_dot2_f32_bf16 v35, v39, v31, v35                         // 00000071EA34: CC1A4023 1C8E3F27
	v_dot2_f32_bf16 v35, v40, v32, v35                         // 00000071EA3C: CC1A4023 1C8E4128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071EA44: BF870091
	v_dot2_f32_bf16 v35, v41, v33, v35                         // 00000071EA48: CC1A4023 1C8E4329
	v_dot2_f32_bf16 v35, v42, v34, v35                         // 00000071EA50: CC1A4023 1C8E452A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000071EA58: BF870001
	v_add_f32_e32 v12, v12, v35                                // 00000071EA5C: 0618470C
	s_clause 0x1                                               // 00000071EA60: BF850001
	global_load_b128 v[35:38], v[43:44], off                   // 00000071EA64: DC5E0000 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:16         // 00000071EA6C: DC5E0010 277C002B
	s_waitcnt vmcnt(1)                                         // 00000071EA74: BF8907F7
	v_dot2_f32_bf16 v35, v35, v27, 0                           // 00000071EA78: CC1A4023 1A023723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071EA80: BF870091
	v_dot2_f32_bf16 v35, v36, v28, v35                         // 00000071EA84: CC1A4023 1C8E3924
	v_dot2_f32_bf16 v35, v37, v29, v35                         // 00000071EA8C: CC1A4023 1C8E3B25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000071EA94: BF8700A1
	v_dot2_f32_bf16 v35, v38, v30, v35                         // 00000071EA98: CC1A4023 1C8E3D26
	s_waitcnt vmcnt(0)                                         // 00000071EAA0: BF8903F7
	v_dot2_f32_bf16 v35, v39, v31, v35                         // 00000071EAA4: CC1A4023 1C8E3F27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071EAAC: BF870091
	v_dot2_f32_bf16 v35, v40, v32, v35                         // 00000071EAB0: CC1A4023 1C8E4128
	v_dot2_f32_bf16 v35, v41, v33, v35                         // 00000071EAB8: CC1A4023 1C8E4329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071EAC0: BF870091
	v_dot2_f32_bf16 v35, v42, v34, v35                         // 00000071EAC4: CC1A4023 1C8E452A
	v_add_f32_e32 v11, v11, v35                                // 00000071EACC: 0616470B
	s_clause 0x1                                               // 00000071EAD0: BF850001
	global_load_b128 v[35:38], v[45:46], off                   // 00000071EAD4: DC5E0000 237C002D
	global_load_b128 v[39:42], v[45:46], off offset:16         // 00000071EADC: DC5E0010 277C002D
	s_waitcnt vmcnt(1)                                         // 00000071EAE4: BF8907F7
	v_dot2_f32_bf16 v35, v35, v27, 0                           // 00000071EAE8: CC1A4023 1A023723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071EAF0: BF870091
	v_dot2_f32_bf16 v35, v36, v28, v35                         // 00000071EAF4: CC1A4023 1C8E3924
	v_dot2_f32_bf16 v35, v37, v29, v35                         // 00000071EAFC: CC1A4023 1C8E3B25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000071EB04: BF8700A1
	v_dot2_f32_bf16 v35, v38, v30, v35                         // 00000071EB08: CC1A4023 1C8E3D26
	s_waitcnt vmcnt(0)                                         // 00000071EB10: BF8903F7
	v_dot2_f32_bf16 v35, v39, v31, v35                         // 00000071EB14: CC1A4023 1C8E3F27
	.long 0xd7000027                                           // 00000071EB1C: D7000027
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 00000071EB20: 0200092B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000071EB24: BF870122
	v_dot2_f32_bf16 v35, v40, v32, v35                         // 00000071EB28: CC1A4023 1C8E4128
	v_add_co_ci_u32_e64 v40, null, s5, v44, s0                 // 00000071EB30: D5207C28 00025805
	v_dot2_f32_bf16 v35, v41, v33, v35                         // 00000071EB38: CC1A4023 1C8E4329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071EB40: BF870091
	v_dot2_f32_bf16 v35, v42, v34, v35                         // 00000071EB44: CC1A4023 1C8E452A
	v_add_f32_e32 v10, v10, v35                                // 00000071EB4C: 0614470A
	s_clause 0x1                                               // 00000071EB50: BF850001
	global_load_b128 v[35:38], v[39:40], off                   // 00000071EB54: DC5E0000 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:16         // 00000071EB5C: DC5E0010 277C0027
	s_waitcnt vmcnt(1)                                         // 00000071EB64: BF8907F7
	v_dot2_f32_bf16 v35, v35, v27, 0                           // 00000071EB68: CC1A4023 1A023723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071EB70: BF870091
	v_dot2_f32_bf16 v35, v36, v28, v35                         // 00000071EB74: CC1A4023 1C8E3924
	v_dot2_f32_bf16 v35, v37, v29, v35                         // 00000071EB7C: CC1A4023 1C8E3B25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000071EB84: BF8700A1
	v_dot2_f32_bf16 v35, v38, v30, v35                         // 00000071EB88: CC1A4023 1C8E3D26
	s_waitcnt vmcnt(0)                                         // 00000071EB90: BF8903F7
	v_dot2_f32_bf16 v35, v39, v31, v35                         // 00000071EB94: CC1A4023 1C8E3F27
	.long 0xd7000027                                           // 00000071EB9C: D7000027
	v_cndmask_b32_e32 v0, v45, v4, vcc_lo                      // 00000071EBA0: 0200092D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000071EBA4: BF8701B2
	v_dot2_f32_bf16 v35, v40, v32, v35                         // 00000071EBA8: CC1A4023 1C8E4128
	v_add_co_ci_u32_e64 v40, null, s5, v46, s0                 // 00000071EBB0: D5207C28 00025C05
	.long 0xd4430000                                           // 00000071EBB8: D4430000
	v_cndmask_b32_e32 v1, s14, v26, vcc_lo                     // 00000071EBBC: 0202340E
	v_dot2_f32_bf16 v35, v41, v33, v35                         // 00000071EBC0: CC1A4023 1C8E4329
	s_or_b32 s3, s0, s3                                        // 00000071EBC8: 8C030300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071EBCC: BF870091
	v_dot2_f32_bf16 v35, v42, v34, v35                         // 00000071EBD0: CC1A4023 1C8E452A
	v_add_f32_e32 v9, v9, v35                                  // 00000071EBD8: 06124709
	s_clause 0x1                                               // 00000071EBDC: BF850001
	global_load_b128 v[35:38], v[39:40], off                   // 00000071EBE0: DC5E0000 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:16         // 00000071EBE8: DC5E0010 277C0027
	s_waitcnt vmcnt(1)                                         // 00000071EBF0: BF8907F7
	v_dot2_f32_bf16 v27, v35, v27, 0                           // 00000071EBF4: CC1A401B 1A023723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071EBFC: BF870091
	v_dot2_f32_bf16 v27, v36, v28, v27                         // 00000071EC00: CC1A401B 1C6E3924
	v_dot2_f32_bf16 v27, v37, v29, v27                         // 00000071EC08: CC1A401B 1C6E3B25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000071EC10: BF8700A1
	v_dot2_f32_bf16 v27, v38, v30, v27                         // 00000071EC14: CC1A401B 1C6E3D26
	s_waitcnt vmcnt(0)                                         // 00000071EC1C: BF8903F7
	v_dot2_f32_bf16 v27, v39, v31, v27                         // 00000071EC20: CC1A401B 1C6E3F27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071EC28: BF870091
	v_dot2_f32_bf16 v27, v40, v32, v27                         // 00000071EC2C: CC1A401B 1C6E4128
	v_dot2_f32_bf16 v27, v41, v33, v27                         // 00000071EC34: CC1A401B 1C6E4329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071EC3C: BF870091
	v_dot2_f32_bf16 v27, v42, v34, v27                         // 00000071EC40: CC1A401B 1C6E452A
	v_add_f32_e32 v8, v8, v27                                  // 00000071EC48: 06103708
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 00000071EC4C: 917E037E
	s_cbranch_execnz 64960                                     // 00000071EC50: BFA6FDC0 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi7ELi32ELi1ELb1EEEvPKhPKtPvll+0x154>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000071EC54: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000071EC58: BF8700A9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000071EC5C: 8C7E017E
	.long 0xd71f0000                                           // 00000071EC60: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000071EC64: 020100C1
	v_xor_b32_e32 v3, 16, v0                                   // 00000071EC68: 3A060090
	v_xor_b32_e32 v18, 8, v0                                   // 00000071EC6C: 3A240088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071EC70: BF870092
	.long 0xd44c0000                                           // 00000071EC74: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 00000071EC78: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 00000071EC7C: D5010003 00020700
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000071EC84: BF870113
	.long 0xd44c0000                                           // 00000071EC88: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 00000071EC8C: 020224A0
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000071EC90: 30060682
	s_delay_alu instid0(VALU_DEP_2)                            // 00000071EC94: BF870002
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 00000071EC98: D5010012 00022500
	ds_bpermute_b32 v4, v3, v14                                // 00000071ECA0: DACC0000 04000E03
	s_waitcnt lgkmcnt(0)                                       // 00000071ECA8: BF89FC07
	v_add_f32_e32 v4, v14, v4                                  // 00000071ECAC: 0608090E
	ds_bpermute_b32 v5, v3, v13                                // 00000071ECB0: DACC0000 05000D03
	ds_bpermute_b32 v6, v3, v12                                // 00000071ECB8: DACC0000 06000C03
	ds_bpermute_b32 v15, v3, v11                               // 00000071ECC0: DACC0000 0F000B03
	ds_bpermute_b32 v16, v3, v10                               // 00000071ECC8: DACC0000 10000A03
	ds_bpermute_b32 v17, v3, v9                                // 00000071ECD0: DACC0000 11000903
	ds_bpermute_b32 v3, v3, v8                                 // 00000071ECD8: DACC0000 03000803
	s_waitcnt lgkmcnt(5)                                       // 00000071ECE0: BF89FC57
	v_dual_add_f32 v5, v13, v5 :: v_dual_lshlrev_b32 v18, 2, v18// 00000071ECE4: C9220B0D 05122482
	s_waitcnt lgkmcnt(3)                                       // 00000071ECEC: BF89FC37
	v_dual_add_f32 v6, v12, v6 :: v_dual_add_f32 v11, v11, v15 // 00000071ECF0: C9080D0C 060A1F0B
	s_waitcnt lgkmcnt(1)                                       // 00000071ECF8: BF89FC17
	v_dual_add_f32 v10, v10, v16 :: v_dual_add_f32 v9, v9, v17 // 00000071ECFC: C908210A 0A082309
	s_waitcnt lgkmcnt(0)                                       // 00000071ED04: BF89FC07
	v_add_f32_e32 v3, v8, v3                                   // 00000071ED08: 06060708
	ds_bpermute_b32 v8, v18, v4                                // 00000071ED0C: DACC0000 08000412
	ds_bpermute_b32 v12, v18, v5                               // 00000071ED14: DACC0000 0C000512
	ds_bpermute_b32 v13, v18, v6                               // 00000071ED1C: DACC0000 0D000612
	ds_bpermute_b32 v14, v18, v11                              // 00000071ED24: DACC0000 0E000B12
	ds_bpermute_b32 v15, v18, v10                              // 00000071ED2C: DACC0000 0F000A12
	ds_bpermute_b32 v16, v18, v9                               // 00000071ED34: DACC0000 10000912
	ds_bpermute_b32 v17, v18, v3                               // 00000071ED3C: DACC0000 11000312
	v_xor_b32_e32 v18, 4, v0                                   // 00000071ED44: 3A240084
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071ED48: BF870091
	.long 0xd44c0000                                           // 00000071ED4C: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 00000071ED50: 020224A0
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 00000071ED54: D5010012 00022500
	s_waitcnt lgkmcnt(4)                                       // 00000071ED5C: BF89FC47
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v6, v13   // 00000071ED60: C9081905 05061B06
	s_delay_alu instid0(VALU_DEP_2)                            // 00000071ED68: BF870002
	v_lshlrev_b32_e32 v18, 2, v18                              // 00000071ED6C: 30242482
	v_add_f32_e32 v4, v4, v8                                   // 00000071ED70: 06081104
	s_waitcnt lgkmcnt(1)                                       // 00000071ED74: BF89FC17
	v_dual_add_f32 v8, v11, v14 :: v_dual_add_f32 v9, v9, v16  // 00000071ED78: C9081D0B 08082109
	s_waitcnt lgkmcnt(0)                                       // 00000071ED80: BF89FC07
	v_add_f32_e32 v3, v3, v17                                  // 00000071ED84: 06062303
	ds_bpermute_b32 v12, v18, v5                               // 00000071ED88: DACC0000 0C000512
	ds_bpermute_b32 v11, v18, v4                               // 00000071ED90: DACC0000 0B000412
	v_add_f32_e32 v10, v10, v15                                // 00000071ED98: 06141F0A
	ds_bpermute_b32 v13, v18, v6                               // 00000071ED9C: DACC0000 0D000612
	ds_bpermute_b32 v14, v18, v8                               // 00000071EDA4: DACC0000 0E000812
	ds_bpermute_b32 v16, v18, v9                               // 00000071EDAC: DACC0000 10000912
	ds_bpermute_b32 v17, v18, v3                               // 00000071EDB4: DACC0000 11000312
	s_waitcnt lgkmcnt(4)                                       // 00000071EDBC: BF89FC47
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v11, v5, v12  // 00000071EDC0: C9081704 040A1905
	ds_bpermute_b32 v15, v18, v10                              // 00000071EDC8: DACC0000 0F000A12
	v_xor_b32_e32 v18, 2, v0                                   // 00000071EDD0: 3A240082
	v_xor_b32_e32 v5, 1, v0                                    // 00000071EDD4: 3A0A0081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071EDD8: BF870092
	.long 0xd44c0000                                           // 00000071EDDC: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 00000071EDE0: 020224A0
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 00000071EDE4: D5010012 00022500
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000071EDEC: BF870113
	.long 0xd44c0000                                           // 00000071EDF0: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 00000071EDF4: 02020AA0
	v_lshlrev_b32_e32 v18, 2, v18                              // 00000071EDF8: 30242482
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000071EDFC: BF870132
	v_cndmask_b32_e64 v0, v0, v5, s0                           // 00000071EE00: D5010000 00020B00
	.long 0xd44a0000                                           // 00000071EE08: D44A0000
	v_cndmask_b32_e32 v1, 0, v7, vcc_lo                        // 00000071EE0C: 02020E80
	s_waitcnt lgkmcnt(4)                                       // 00000071EE10: BF89FC47
	v_dual_add_f32 v6, v6, v13 :: v_dual_lshlrev_b32 v19, 2, v0// 00000071EE14: C9221B06 06120082
	s_waitcnt lgkmcnt(0)                                       // 00000071EE1C: BF89FC07
	v_dual_add_f32 v13, v9, v16 :: v_dual_add_f32 v10, v10, v15// 00000071EE20: C9082109 0D0A1F0A
	s_and_b32 s0, s0, vcc_lo                                   // 00000071EE28: 8B006A00
	ds_bpermute_b32 v16, v18, v10                              // 00000071EE2C: DACC0000 10000A12
	v_add_f32_e32 v12, v8, v14                                 // 00000071EE34: 06181D08
	v_add_f32_e32 v14, v3, v17                                 // 00000071EE38: 061C2303
	ds_bpermute_b32 v3, v18, v4                                // 00000071EE3C: DACC0000 03000412
	ds_bpermute_b32 v8, v18, v11                               // 00000071EE44: DACC0000 08000B12
	ds_bpermute_b32 v17, v18, v13                              // 00000071EE4C: DACC0000 11000D12
	s_waitcnt lgkmcnt(2)                                       // 00000071EE54: BF89FC27
	v_add_f32_e32 v5, v4, v3                                   // 00000071EE58: 060A0704
	ds_bpermute_b32 v9, v18, v6                                // 00000071EE5C: DACC0000 09000612
	s_waitcnt lgkmcnt(1)                                       // 00000071EE64: BF89FC17
	v_dual_add_f32 v8, v11, v8 :: v_dual_add_f32 v11, v13, v17 // 00000071EE68: C908110B 080A230D
	s_waitcnt lgkmcnt(0)                                       // 00000071EE70: BF89FC07
	v_add_f32_e32 v0, v6, v9                                   // 00000071EE74: 06001306
	v_add_f32_e32 v9, v10, v16                                 // 00000071EE78: 0612210A
	ds_bpermute_b32 v15, v18, v12                              // 00000071EE7C: DACC0000 0F000C12
	ds_bpermute_b32 v10, v19, v5                               // 00000071EE84: DACC0000 0A000513
	ds_bpermute_b32 v4, v19, v0                                // 00000071EE8C: DACC0000 04000013
	ds_bpermute_b32 v13, v19, v9                               // 00000071EE94: DACC0000 0D000913
	s_waitcnt lgkmcnt(3)                                       // 00000071EE9C: BF89FC37
	v_add_f32_e32 v3, v12, v15                                 // 00000071EEA0: 06061F0C
	ds_bpermute_b32 v18, v18, v14                              // 00000071EEA4: DACC0000 12000E12
	ds_bpermute_b32 v6, v19, v3                                // 00000071EEAC: DACC0000 06000313
	s_waitcnt lgkmcnt(1)                                       // 00000071EEB4: BF89FC17
	v_add_f32_e32 v15, v14, v18                                // 00000071EEB8: 061E250E
	ds_bpermute_b32 v12, v19, v8                               // 00000071EEBC: DACC0000 0C000813
	ds_bpermute_b32 v14, v19, v11                              // 00000071EEC4: DACC0000 0E000B13
	ds_bpermute_b32 v16, v19, v15                              // 00000071EECC: DACC0000 10000F13
	s_and_saveexec_b32 s1, s0                                  // 00000071EED4: BE812000
	s_cbranch_execz 61                                         // 00000071EED8: BFA5003D <_ZN7halogen12_GLOBAL__N_16k_lq6kILi7ELi32ELi1ELb1EEEvPKhPKtPvll+0xdd0>
	.long 0xd73c0001                                           // 00000071EEDC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000071EEE0: 02020282
	s_waitcnt lgkmcnt(1)                                       // 00000071EEE4: BF89FC17
	v_dual_add_f32 v11, v11, v14 :: v_dual_add_f32 v12, v8, v12// 00000071EEE8: C9081D0B 0B0C1908
	s_waitcnt lgkmcnt(0)                                       // 00000071EEF0: BF89FC07
	v_add_f32_e32 v15, v15, v16                                // 00000071EEF4: 061E210F
	v_dual_add_f32 v5, v5, v10 :: v_dual_add_f32 v16, v0, v4   // 00000071EEF8: C9081505 05100900
	.long 0xd7006a07                                           // 00000071EF00: D7006A07
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 00000071EF04: 02020208
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000071EF08: BF8700D1
	v_add_co_ci_u32_e64 v8, null, s9, v2, vcc_lo               // 00000071EF0C: D5207C08 01AA0409
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000071EF14: 8480820C
	v_dual_add_f32 v13, v9, v13 :: v_dual_add_f32 v14, v3, v6  // 00000071EF18: C9081B09 0D0E0D03
	v_mad_u64_u32 v[0:1], null, s12, 12, v[7:8]                // 00000071EF20: D6FE7C00 041D180C
	.long 0xd7006a09                                           // 00000071EF28: D7006A09
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 00000071EF2C: 02000107
	v_add_co_ci_u32_e64 v10, null, s1, v8, vcc_lo              // 00000071EF30: D5207C0A 01AA1001
	s_lshl_b64 s[0:1], s[12:13], 3                             // 00000071EF38: 8480830C
	s_clause 0x1                                               // 00000071EF3C: BF850001
	global_store_b32 v[7:8], v5, off                           // 00000071EF40: DC6A0000 007C0507
	global_store_b32 v[9:10], v12, off                         // 00000071EF48: DC6A0000 007C0C09
	.long 0xd7006a03                                           // 00000071EF50: D7006A03
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 00000071EF54: 02000107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000071EF58: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s1, v8, vcc_lo               // 00000071EF5C: D5207C04 01AA1001
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 00000071EF64: D6FE7C01 0405180D
	.long 0xd7006a05                                           // 00000071EF6C: D7006A05
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 00000071EF70: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000071EF74: BF8700A1
	v_add_co_ci_u32_e64 v6, null, s1, v4, vcc_lo               // 00000071EF78: D5207C06 01AA0801
	.long 0xd7006a07                                           // 00000071EF80: D7006A07
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000071EF84: 02000100
	v_add_co_ci_u32_e64 v8, null, s1, v1, vcc_lo               // 00000071EF88: D5207C08 01AA0201
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071EF90: BF870094
	.long 0xd7006a09                                           // 00000071EF94: D7006A09
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 00000071EF98: 02000105
	v_add_co_ci_u32_e64 v10, null, s1, v6, vcc_lo              // 00000071EF9C: D5207C0A 01AA0C01
	s_clause 0x4                                               // 00000071EFA4: BF850004
	global_store_b32 v[3:4], v16, off                          // 00000071EFA8: DC6A0000 007C1003
	global_store_b32 v[0:1], v14, off                          // 00000071EFB0: DC6A0000 007C0E00
	global_store_b32 v[5:6], v13, off                          // 00000071EFB8: DC6A0000 007C0D05
	global_store_b32 v[7:8], v11, off                          // 00000071EFC0: DC6A0000 007C0B07
	global_store_b32 v[9:10], v15, off                         // 00000071EFC8: DC6A0000 007C0F09
	s_endpgm                                                   // 00000071EFD0: BFB00000
		...

