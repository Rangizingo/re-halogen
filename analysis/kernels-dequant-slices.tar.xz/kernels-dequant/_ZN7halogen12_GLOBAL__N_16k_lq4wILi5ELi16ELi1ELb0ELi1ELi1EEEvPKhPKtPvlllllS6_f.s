00000000007d3400 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000007D3400: F4100200 F8000000
	v_and_b32_e32 v30, 15, v0                                  // 0000007D3408: 363C008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000007D340C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 0000007D3410: 86039F02
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000007D3414: 300E0082
	s_lshl_b64 s[2:3], s[2:3], 4                               // 0000007D3418: 84828402
	v_lshlrev_b32_e32 v2, 2, v30                               // 0000007D341C: 30043C82
	v_dual_mov_b32 v24, s3 :: v_dual_lshlrev_b32 v3, 2, v1     // 0000007D3420: CA220003 18020282
	v_or_b32_e32 v23, s2, v1                                   // 0000007D3428: 382E0202
	.long 0x7f0c3880                                           // 0000007D342C: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 0000007D3430: BF89FC07
	s_clause 0x1                                               // 0000007D3434: BF850001
	global_load_b32 v4, v2, s[8:9]                             // 0000007D3438: DC520000 04080002
	global_load_b32 v3, v3, s[8:9]                             // 0000007D3440: DC520000 03080003
	.long 0xd4540002                                           // 0000007D3448: D4540002
	v_cndmask_b32_e32 v1, s16, v23, vcc_lo                     // 0000007D344C: 02022E10
	s_add_u32 s24, s8, s20                                     // 0000007D3450: 80181408
	s_addc_u32 s25, s9, s21                                    // 0000007D3454: 82191509
	s_ashr_i32 s4, s15, 31                                     // 0000007D3458: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007D345C: BF870159
	s_lshr_b32 s4, s4, 27                                      // 0000007D3460: 85049B04
	v_cndmask_b32_e64 v2, 0, v23, s2                           // 0000007D3464: D5010002 000A2E80
	v_cndmask_b32_e64 v5, 0, s3, s2                            // 0000007D346C: D5010005 00080680
	s_add_u32 s4, s14, s4                                      // 0000007D3474: 8004040E
	s_addc_u32 s5, s15, 0                                      // 0000007D3478: 8205800F
	.long 0xd72c0008                                           // 0000007D347C: D72C0008
	v_cndmask_b32_e32 v1, s23, v2, vcc_lo                      // 0000007D3480: 02020417
	v_mad_u64_u32 v[0:1], null, s22, v2, 0                     // 0000007D3484: D6FE7C00 02020416
	s_lshr_b64 s[6:7], s[4:5], 5                               // 0000007D348C: 85868504
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000007D3490: BF8704D9
	s_cmpk_lt_i32 s6, 0x81                                     // 0000007D3494: B3860081
	.long 0xd4440004                                           // 0000007D3498: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000007D349C: 02023C06
	s_cselect_b32 s3, -1, 0                                    // 0000007D34A0: 980380C1
	s_cmpk_gt_i32 s6, 0x80                                     // 0000007D34A4: B2860080
	s_cselect_b32 s7, -1, 0                                    // 0000007D34A8: 980780C1
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000007D34AC: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000007D34B0: BF8907F7
	v_bfe_u32 v9, v4, 16, 1                                    // 0000007D34B4: D6100009 02052104
	s_waitcnt vmcnt(0)                                         // 0000007D34BC: BF8903F7
	v_bfe_u32 v10, v3, 16, 1                                   // 0000007D34C0: D610000A 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007D34C8: BF8701A2
	v_add3_u32 v4, v4, v9, 0x7fff                              // 0000007D34CC: D6550004 03FE1304 00007FFF
	.long 0xd72c0009                                           // 0000007D34D8: D72C0009
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000007D34DC: 02020A16
	v_add3_u32 v3, v3, v10, 0x7fff                             // 0000007D34E0: D6550003 03FE1503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007D34EC: BF870193
	.long 0x7e0c3984                                           // 0000007D34F0: 7E0C3984
	v_add3_u32 v1, v1, v9, v8                                  // 0000007D34F4: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D34FC: BF8700A2
	v_and_or_b32 v6, 0xffff0000, v3, v6                        // 0000007D3500: D6570006 041A06FF FFFF0000
	.long 0xd7000503                                           // 0000007D350C: D7000503
	v_cndmask_b32_e32 v1, s24, v0, vcc_lo                      // 0000007D3510: 02020018
	v_add_co_ci_u32_e64 v4, null, s25, v1, s5                  // 0000007D3514: D5207C04 00160219
	ds_store_b32 v7, v6                                        // 0000007D351C: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 0000007D3524: BF89FC07
	s_barrier                                                  // 0000007D3528: BFBD0000
	buffer_gl0_inv                                             // 0000007D352C: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 0000007D3534: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 0000007D3538: CA100080 08060080
	s_and_saveexec_b32 s5, s4                                  // 0000007D3540: BE852004
	s_cbranch_execz 10                                         // 0000007D3544: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x170>
	v_lshlrev_b32_e32 v6, 1, v30                               // 0000007D3548: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D354C: BF870091
	.long 0xd7006a06                                           // 0000007D3550: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007D3554: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 0000007D3558: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 0000007D3560: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 0000007D3568: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 0000007D356C: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007D3570: 8C7E057E
	v_or_b32_e32 v6, 16, v30                                   // 0000007D3574: 380C3C90
	s_mov_b32 s4, exec_lo                                      // 0000007D3578: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007D357C: BF870001
	.long 0xd4c4007e                                           // 0000007D3580: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007D3584: 02020C06
	s_cbranch_execz 10                                         // 0000007D3588: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1b4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007D358C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3590: BF870091
	.long 0xd7006a08                                           // 0000007D3594: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007D3598: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 0000007D359C: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 0000007D35A4: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 0000007D35AC: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 0000007D35B0: 7E101706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007D35B4: 8C7E047E
	v_or_b32_e32 v6, 32, v30                                   // 0000007D35B8: 380C3CA0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 0000007D35BC: CA100080 0A080080
	s_mov_b32 s4, exec_lo                                      // 0000007D35C4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007D35C8: BF870002
	.long 0xd4c4007e                                           // 0000007D35CC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007D35D0: 02020C06
	s_cbranch_execz 10                                         // 0000007D35D4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x200>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007D35D8: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D35DC: BF870091
	.long 0xd7006a0b                                           // 0000007D35E0: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007D35E4: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 0000007D35E8: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 0000007D35F0: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 0000007D35F8: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 0000007D35FC: 7E121706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007D3600: 8C7E047E
	v_or_b32_e32 v6, 48, v30                                   // 0000007D3604: 380C3CB0
	s_mov_b32 s4, exec_lo                                      // 0000007D3608: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007D360C: BF870001
	.long 0xd4c4007e                                           // 0000007D3610: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007D3614: 02020C06
	s_cbranch_execz 10                                         // 0000007D3618: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x244>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007D361C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3620: BF870091
	.long 0xd7006a0a                                           // 0000007D3624: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007D3628: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 0000007D362C: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 0000007D3634: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 0000007D363C: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 0000007D3640: 7E141706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007D3644: 8C7E047E
	v_or_b32_e32 v6, 64, v30                                   // 0000007D3648: 380C3CC0
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 0000007D364C: CA100080 0C0A0080
	s_mov_b32 s4, exec_lo                                      // 0000007D3654: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007D3658: BF870002
	.long 0xd4c4007e                                           // 0000007D365C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007D3660: 02020C06
	s_cbranch_execz 10                                         // 0000007D3664: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x290>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007D3668: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D366C: BF870091
	.long 0xd7006a0d                                           // 0000007D3670: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007D3674: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 0000007D3678: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 0000007D3680: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 0000007D3688: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 0000007D368C: 7E161706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007D3690: 8C7E047E
	v_or_b32_e32 v6, 0x50, v30                                 // 0000007D3694: 380C3CFF 00000050
	s_mov_b32 s4, exec_lo                                      // 0000007D369C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007D36A0: BF870001
	.long 0xd4c4007e                                           // 0000007D36A4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007D36A8: 02020C06
	s_cbranch_execz 10                                         // 0000007D36AC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2d8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007D36B0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D36B4: BF870091
	.long 0xd7006a0c                                           // 0000007D36B8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007D36BC: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 0000007D36C0: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 0000007D36C8: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 0000007D36D0: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 0000007D36D4: 7E181706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007D36D8: 8C7E047E
	v_or_b32_e32 v6, 0x60, v30                                 // 0000007D36DC: 380C3CFF 00000060
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 0000007D36E4: CA100080 0E0C0080
	s_mov_b32 s4, exec_lo                                      // 0000007D36EC: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007D36F0: BF870002
	.long 0xd4c4007e                                           // 0000007D36F4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007D36F8: 02020C06
	s_cbranch_execz 10                                         // 0000007D36FC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x328>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007D3700: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3704: BF870091
	.long 0xd7006a0f                                           // 0000007D3708: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007D370C: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 0000007D3710: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 0000007D3718: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 0000007D3720: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 0000007D3724: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007D3728: 8C7E047E
	v_or_b32_e32 v6, 0x70, v30                                 // 0000007D372C: 380C3CFF 00000070
	s_mov_b32 s4, exec_lo                                      // 0000007D3734: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007D3738: BF870001
	.long 0xd4c4007e                                           // 0000007D373C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007D3740: 02020C06
	s_cbranch_execz 10                                         // 0000007D3744: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x370>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007D3748: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D374C: BF870091
	.long 0xd7006a0e                                           // 0000007D3750: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007D3754: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 0000007D3758: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 0000007D3760: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 0000007D3768: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 0000007D376C: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007D3770: 8C7E047E
	s_branch 9                                                 // 0000007D3774: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x39c>
	v_mov_b32_e32 v7, 0                                        // 0000007D3778: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007D377C: BF870001
	v_mov_b32_e32 v8, v7                                       // 0000007D3780: 7E100307
	v_mov_b32_e32 v9, v7                                       // 0000007D3784: 7E120307
	v_mov_b32_e32 v10, v7                                      // 0000007D3788: 7E140307
	v_mov_b32_e32 v11, v7                                      // 0000007D378C: 7E160307
	v_mov_b32_e32 v12, v7                                      // 0000007D3790: 7E180307
	v_mov_b32_e32 v13, v7                                      // 0000007D3794: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 0000007D3798: 7E1C0307
	s_add_u32 s4, s8, s18                                      // 0000007D379C: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000007D37A0: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000007D37A4: 85129F0F
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000007D37A8: CA100080 13140080
	s_add_u32 s18, s14, s18                                    // 0000007D37B0: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000007D37B4: 8213800F
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v22, 0             // 0000007D37B8: CA100080 1F160080
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000007D37C0: 86928112
	v_cndmask_b32_e64 v32, 0, 1, s7                            // 0000007D37C4: D5010020 001D0280
	v_mad_u64_u32 v[25:26], null, v2, s18, s[4:5]              // 0000007D37CC: D6FE7C19 00102502
	.long 0xd72c0002                                           // 0000007D37D4: D72C0002
	v_cndmask_b32_e32 v0, v2, v19, vcc_lo                      // 0000007D37D8: 02002702
	.long 0xd72c0005                                           // 0000007D37DC: D72C0005
	v_cndmask_b32_e32 v0, v5, v18, vcc_lo                      // 0000007D37E0: 02002505
	.long 0xd4440004                                           // 0000007D37E4: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000007D37E8: 02023C06
	v_mov_b32_e32 v41, 0                                       // 0000007D37EC: 7E520280
	v_mov_b32_e32 v21, 0                                       // 0000007D37F0: 7E2A0280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007D37F4: BF870004
	v_add3_u32 v33, v5, v26, v2                                // 0000007D37F8: D6550021 040A3505
	s_and_saveexec_b32 s5, s4                                  // 0000007D3800: BE852004
	s_cbranch_execz 21                                         // 0000007D3804: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_dual_mov_b32 v41, 0 :: v_dual_lshlrev_b32 v2, 4, v30     // 0000007D3808: CA220080 29023C84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3810: BF870091
	.long 0xd7006a05                                           // 0000007D3814: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 0000007D3818: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 0000007D381C: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000007D3824: 916A077E
	global_load_b128 v[19:22], v[5:6], off                     // 0000007D3828: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 0000007D3830: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_lshlrev_b32_e32 v2, 1, v30                               // 0000007D3834: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3838: BF870091
	.long 0xd7006a02                                           // 0000007D383C: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 0000007D3840: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 0000007D3844: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 0000007D384C: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000007D3854: BF8903F7
	v_cvt_f32_f16_e32 v41, v2                                  // 0000007D3858: 7E521702
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007D385C: 8C7E057E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 0000007D3860: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 0000007D3868: CA100080 24240080
	s_and_saveexec_b32 s5, s4                                  // 0000007D3870: BE852004
	s_cbranch_execz 507                                        // 0000007D3874: BFA501FB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xc64>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 0000007D3878: CA220080 1B023C81
	.long 0xd7006a00                                           // 0000007D3880: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 0000007D3884: 02020014
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007D3888: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 0000007D388C: D5207C01 01AA0215
	v_dual_mov_b32 v39, v30 :: v_dual_lshlrev_b32 v26, 5, v30  // 0000007D3894: CA22011E 271A3C85
	.long 0xd7006a00                                           // 0000007D389C: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 0000007D38A0: 02020500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007D38A4: BF8701A1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000007D38A8: D5207C01 01AA0280
	v_lshl_or_b32 v38, v30, 4, 0x100                           // 0000007D38B0: D6560026 03FD091E 00000100
	.long 0xd7006a00                                           // 0000007D38BC: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007D38C0: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007D38C4: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007D38C8: D5207C01 01AA0209
	v_dual_mov_b32 v37, v27 :: v_dual_mov_b32 v40, v41         // 0000007D38D0: CA10011B 25280129
	.long 0xd7006a1c                                           // 0000007D38D8: D7006A1C
	v_cndmask_b32_e32 v0, v0, v160, vcc_lo                     // 0000007D38DC: 02014100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007D38E0: BF870001
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 0000007D38E4: D5207C1D 01AA0280
	v_mov_b32_e32 v36, v27                                     // 0000007D38EC: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 0000007D38F0: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 0000007D38F4: 7E44031B
	v_mov_b32_e32 v31, v27                                     // 0000007D38F8: 7E3E031B
	s_mul_i32 s4, s15, 6                                       // 0000007D38FC: 9604860F
	s_mul_hi_u32 s7, s14, 6                                    // 0000007D3900: 9687860E
	s_lshl_b64 s[18:19], s[14:15], 2                           // 0000007D3904: 8492820E
	s_add_i32 s7, s7, s4                                       // 0000007D3908: 81070407
	s_mul_i32 s21, s14, 6                                      // 0000007D390C: 9615860E
	s_mov_b32 s20, 0                                           // 0000007D3910: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000007D3914: 8488810E
	s_branch 437                                               // 0000007D3918: BFA001B5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xbf0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007D391C: 8C7E0E7E
	v_cndmask_b32_e64 v51, v41, v7, s3                         // 0000007D3920: D5010033 000E0F29
	v_cndmask_b32_e64 v1, v8, v9, s3                           // 0000007D3928: D5010001 000E1308
	v_cndmask_b32_e64 v0, v7, v8, s3                           // 0000007D3930: D5010000 000E1107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 0000007D3938: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s3                         // 0000007D3944: D5010006 000E1D0D
	v_cndmask_b32_e64 v5, v12, v13, s3                         // 0000007D394C: D5010005 000E1B0C
	v_cndmask_b32_e64 v4, v11, v12, s3                         // 0000007D3954: D5010004 000E190B
	v_cndmask_b32_e64 v3, v10, v11, s3                         // 0000007D395C: D5010003 000E170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007D3964: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s3                          // 0000007D3968: D5010002 000E1509
	s_and_b32 s4, exec_lo, s4                                  // 0000007D3970: 8B04047E
	v_add_nc_u32_e32 v38, 0x100, v38                           // 0000007D3974: 4A4C4CFF 00000100
	s_or_b32 s20, s4, s20                                      // 0000007D397C: 8C141404
	ds_load_b32 v14, v8                                        // 0000007D3980: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 0000007D3988: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007D398C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007D3990: 361010FF 000003FC
	ds_load_b32 v52, v8                                        // 0000007D3998: D8D80000 34000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 0000007D39A0: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007D39A4: 361010FF 000003FC
	ds_load_b32 v53, v8                                        // 0000007D39AC: D8D80000 35000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 0000007D39B4: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007D39B8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007D39BC: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 0000007D39C4: D8D80000 36000008
	v_and_b32_e32 v8, 0xff, v20                                // 0000007D39CC: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007D39D4: 30101082
	ds_load_b32 v55, v8                                        // 0000007D39D8: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 0000007D39E0: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007D39E4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007D39E8: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 0000007D39F0: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 0000007D39F8: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007D39FC: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 0000007D3A04: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 0000007D3A0C: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007D3A10: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007D3A14: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 0000007D3A1C: D8D80000 3A000008
	v_and_b32_e32 v8, 0xff, v21                                // 0000007D3A24: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007D3A2C: 30101082
	ds_load_b32 v59, v8                                        // 0000007D3A30: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 0000007D3A38: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007D3A3C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007D3A40: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 0000007D3A48: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 0000007D3A50: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007D3A54: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 0000007D3A5C: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 0000007D3A64: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007D3A68: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007D3A6C: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 0000007D3A74: D8D80000 3E000008
	v_and_b32_e32 v8, 0xff, v22                                // 0000007D3A7C: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007D3A84: 30101082
	ds_load_b32 v63, v8                                        // 0000007D3A88: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 0000007D3A90: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007D3A94: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007D3A98: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 0000007D3AA0: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 0000007D3AA8: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007D3AAC: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 0000007D3AB4: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 0000007D3ABC: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007D3AC0: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007D3AC4: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 0000007D3ACC: D8D80000 42000008
	.long 0xd73c0008                                           // 0000007D3AD4: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000007D3AD8: 02023481
	v_add_nc_u32_e32 v26, 0x200, v26                           // 0000007D3ADC: 4A3434FF 00000200
	.long 0xd7006a0c                                           // 0000007D3AE4: D7006A0C
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 0000007D3AE8: 0202100A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007D3AEC: BF870001
	v_add_co_ci_u32_e64 v13, null, s11, v9, vcc_lo             // 0000007D3AF0: D5207C0D 01AA120B
	s_clause 0x3                                               // 0000007D3AF8: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000007D3AFC: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000007D3B04: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 0000007D3B0C: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 0000007D3B14: DC5E0030 2D7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000007D3B1C: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007D3B20: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 0000007D3B28: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3B2C: BF8700A1
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 0000007D3B30: CC1A4008 1C226909
	s_waitcnt lgkmcnt(13)                                      // 0000007D3B38: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 0000007D3B3C: CC1A4008 1C226B0A
	s_waitcnt lgkmcnt(12)                                      // 0000007D3B44: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3B48: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 0000007D3B4C: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000007D3B54: BF8908B7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 0000007D3B58: CC1A4008 1C226F13
	s_waitcnt lgkmcnt(10)                                      // 0000007D3B60: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3B64: BF8700A1
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 0000007D3B68: CC1A4008 1C227114
	s_waitcnt lgkmcnt(9)                                       // 0000007D3B70: BF89FC97
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 0000007D3B74: CC1A4008 1C227315
	s_waitcnt lgkmcnt(8)                                       // 0000007D3B7C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3B80: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 0000007D3B84: CC1A4008 1C227516
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000007D3B8C: BF890477
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000007D3B90: CC1A4008 1C227729
	s_waitcnt lgkmcnt(6)                                       // 0000007D3B98: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3B9C: BF8700A1
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000007D3BA0: CC1A4008 1C22792A
	s_waitcnt lgkmcnt(5)                                       // 0000007D3BA8: BF89FC57
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000007D3BAC: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(4)                                       // 0000007D3BB4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3BB8: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000007D3BBC: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007D3BC4: BF890037
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000007D3BC8: CC1A4008 1C227F2D
	.long 0xd7006a2d                                           // 0000007D3BD0: D7006A2D
	v_cndmask_b32_e32 v0, v12, v8, vcc_lo                      // 0000007D3BD4: 0200110C
	s_waitcnt lgkmcnt(2)                                       // 0000007D3BD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000007D3BDC: BF8701C2
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000007D3BE0: CC1A4008 1C22812E
	v_add_co_ci_u32_e64 v46, null, s9, v13, vcc_lo             // 0000007D3BE8: D5207C2E 01AA1A09
	.long 0xd7006a31                                           // 0000007D3BF0: D7006A31
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 0000007D3BF4: 0200250C
	s_waitcnt lgkmcnt(1)                                       // 0000007D3BF8: BF89FC17
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000007D3BFC: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v50, null, s19, v13, vcc_lo            // 0000007D3C04: D5207C32 01AA1A13
	.long 0xd7006a0c                                           // 0000007D3C0C: D7006A0C
	v_cndmask_b32_e32 v0, v12, v21, vcc_lo                     // 0000007D3C10: 02002B0C
	s_waitcnt lgkmcnt(0)                                       // 0000007D3C14: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007D3C18: BF870123
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000007D3C1C: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v13, null, s7, v13, vcc_lo             // 0000007D3C24: D5207C0D 01AA1A07
	v_fmac_f32_e32 v37, v51, v8                                // 0000007D3C2C: 564A1133
	s_clause 0x3                                               // 0000007D3C30: BF850003
	global_load_b128 v[8:11], v[45:46], off                    // 0000007D3C34: DC5E0000 087C002D
	global_load_b128 v[19:22], v[45:46], off offset:16         // 0000007D3C3C: DC5E0010 137C002D
	global_load_b128 v[41:44], v[45:46], off offset:32         // 0000007D3C44: DC5E0020 297C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 0000007D3C4C: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 0000007D3C54: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007D3C58: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3C60: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 0000007D3C64: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 0000007D3C6C: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3C74: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 0000007D3C78: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 0000007D3C80: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 0000007D3C84: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3C8C: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 0000007D3C90: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 0000007D3C98: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3CA0: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 0000007D3CA4: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 0000007D3CAC: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000007D3CB0: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3CB8: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000007D3CBC: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000007D3CC4: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3CCC: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000007D3CD0: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000007D3CD8: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000007D3CDC: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3CE4: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000007D3CE8: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000007D3CF0: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3CF8: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000007D3CFC: CC1A4008 1C228530
	v_fmac_f32_e32 v36, v51, v8                                // 0000007D3D04: 56481133
	s_clause 0x3                                               // 0000007D3D08: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 0000007D3D0C: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 0000007D3D14: DC5E0010 137C0031
	global_load_b128 v[41:44], v[49:50], off offset:32         // 0000007D3D1C: DC5E0020 297C0031
	global_load_b128 v[45:48], v[49:50], off offset:48         // 0000007D3D24: DC5E0030 2D7C0031
	s_waitcnt vmcnt(3)                                         // 0000007D3D2C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007D3D30: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3D38: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 0000007D3D3C: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 0000007D3D44: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3D4C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 0000007D3D50: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 0000007D3D58: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 0000007D3D5C: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3D64: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 0000007D3D68: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 0000007D3D70: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3D78: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 0000007D3D7C: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 0000007D3D84: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000007D3D88: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3D90: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000007D3D94: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000007D3D9C: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3DA4: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000007D3DA8: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000007D3DB0: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000007D3DB4: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3DBC: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000007D3DC0: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000007D3DC8: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3DD0: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000007D3DD4: CC1A4008 1C228530
	v_fmac_f32_e32 v35, v51, v8                                // 0000007D3DDC: 56461133
	s_clause 0x3                                               // 0000007D3DE0: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000007D3DE4: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000007D3DEC: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 0000007D3DF4: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 0000007D3DFC: DC5E0030 2D7C000C
	.long 0xd7006a0c                                           // 0000007D3E04: D7006A0C
	v_cndmask_b32_e32 v0, v49, v18, vcc_lo                     // 0000007D3E08: 02002531
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3E0C: BF8700A1
	v_add_co_ci_u32_e64 v13, null, s19, v50, vcc_lo            // 0000007D3E10: D5207C0D 01AA6413
	.long 0xd7006a1c                                           // 0000007D3E18: D7006A1C
	v_cndmask_b32_e32 v0, v28, v160, vcc_lo                    // 0000007D3E1C: 0201411C
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 0000007D3E20: D5207C1D 01AA3A80
	s_waitcnt vmcnt(3)                                         // 0000007D3E28: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007D3E2C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3E34: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 0000007D3E38: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 0000007D3E40: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3E48: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 0000007D3E4C: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 0000007D3E54: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 0000007D3E58: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3E60: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 0000007D3E64: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 0000007D3E6C: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3E74: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 0000007D3E78: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 0000007D3E80: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000007D3E84: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3E8C: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000007D3E90: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000007D3E98: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3EA0: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000007D3EA4: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000007D3EAC: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000007D3EB0: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3EB8: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000007D3EBC: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000007D3EC4: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3ECC: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000007D3ED0: CC1A4008 1C228530
	v_fmac_f32_e32 v34, v51, v8                                // 0000007D3ED8: 56441133
	s_clause 0x3                                               // 0000007D3EDC: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000007D3EE0: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000007D3EE8: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 0000007D3EF0: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 0000007D3EF8: DC5E0030 2D7C000C
	s_waitcnt vmcnt(3)                                         // 0000007D3F00: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007D3F04: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3F0C: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 0000007D3F10: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 0000007D3F18: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3F20: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 0000007D3F24: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 0000007D3F2C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 0000007D3F30: CC1A4008 1C226F13
	v_mov_b32_e32 v19, v15                                     // 0000007D3F38: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007D3F3C: BF870122
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 0000007D3F40: CC1A4008 1C227114
	v_mov_b32_e32 v20, v16                                     // 0000007D3F48: 7E280310
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 0000007D3F4C: CC1A4008 1C227315
	v_mov_b32_e32 v21, v17                                     // 0000007D3F54: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007D3F58: BF870132
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 0000007D3F5C: CC1A4008 1C227516
	v_mov_b32_e32 v22, v18                                     // 0000007D3F64: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 0000007D3F68: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000007D3F6C: CC1A4008 1C227729
	v_mov_b32_e32 v41, v40                                     // 0000007D3F74: 7E520328
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3F78: BF870092
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000007D3F7C: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000007D3F84: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D3F8C: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000007D3F90: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000007D3F98: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000007D3F9C: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3FA4: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000007D3FA8: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000007D3FB0: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D3FB8: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000007D3FBC: CC1A4008 1C228530
	v_fmac_f32_e32 v31, v51, v8                                // 0000007D3FC4: 563E1133
	v_mov_b32_e32 v14, v7                                      // 0000007D3FC8: 7E1C0307
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 0000007D3FCC: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 0000007D3FD4: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 0000007D3FDC: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 0000007D3FE4: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 0000007D3FE8: 917E147E
	s_cbranch_execz 28                                         // 0000007D3FEC: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xc60>
	s_waitcnt vmcnt(0)                                         // 0000007D3FF0: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v39, 16, v39  // 0000007D3FF4: CA200114 10264E90
	v_dual_mov_b32 v15, v19 :: v_dual_mov_b32 v18, v22         // 0000007D3FFC: CA100113 0F120116
	v_mov_b32_e32 v17, v21                                     // 0000007D4004: 7E220315
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007D4008: BF870003
	.long 0xd4430004                                           // 0000007D400C: D4430004
	v_cndmask_b32_e32 v1, s6, v39, vcc_lo                      // 0000007D4010: 02024E06
	s_mov_b32 s14, exec_lo                                     // 0000007D4014: BE8E007E
	.long 0xd4c4007e                                           // 0000007D4018: D4C4007E
	v_cndmask_b32_e32 v1, s6, v39, vcc_lo                      // 0000007D401C: 02024E06
	s_cbranch_execz 65086                                      // 0000007D4020: BFA5FE3E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	.long 0xd7006a00                                           // 0000007D4024: D7006A00
	v_cndmask_b32_e32 v1, v25, v38, vcc_lo                     // 0000007D4028: 02024D19
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007D402C: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 0000007D4030: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v32                            // 0000007D4038: 7C9A4081
	v_mov_b32_e32 v40, v41                                     // 0000007D403C: 7E500329
	global_load_b128 v[15:18], v[0:1], off                     // 0000007D4040: DC5E0000 0F7C0000
	s_cbranch_vccnz 65076                                      // 0000007D4048: BFA4FE34 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	global_load_d16_b16 v0, v[28:29], off                      // 0000007D404C: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 0000007D4054: BF8903F7
	v_cvt_f32_f16_e32 v40, v0                                  // 0000007D4058: 7E501700
	s_branch 65071                                             // 0000007D405C: BFA0FE2F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	s_or_b32 exec_lo, exec_lo, s20                             // 0000007D4060: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D4064: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007D4068: 8C7E057E
	.long 0xd71f0000                                           // 0000007D406C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007D4070: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 0000007D4074: 3A020088
	v_xor_b32_e32 v6, 4, v0                                    // 0000007D4078: 3A0C0084
	v_xor_b32_e32 v11, 2, v0                                   // 0000007D407C: 3A160082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007D4080: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000007D4084: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000007D4088: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000007D408C: 7C980CA0
	v_cndmask_b32_e32 v6, v0, v6, vcc_lo                       // 0000007D4090: 020C0D00
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 0000007D4094: 7C9816A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007D4098: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000007D409C: 300C0C82
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007D40A0: 30020282
	ds_bpermute_b32 v2, v1, v37                                // 0000007D40A4: DACC0000 02002501
	s_waitcnt lgkmcnt(0)                                       // 0000007D40AC: BF89FC07
	v_add_f32_e32 v2, v37, v2                                  // 0000007D40B0: 06040525
	ds_bpermute_b32 v3, v1, v36                                // 0000007D40B4: DACC0000 03002401
	ds_bpermute_b32 v4, v1, v35                                // 0000007D40BC: DACC0000 04002301
	ds_bpermute_b32 v5, v1, v34                                // 0000007D40C4: DACC0000 05002201
	ds_bpermute_b32 v1, v1, v31                                // 0000007D40CC: DACC0000 01001F01
	ds_bpermute_b32 v7, v6, v2                                 // 0000007D40D4: DACC0000 07000206
	s_waitcnt lgkmcnt(3)                                       // 0000007D40DC: BF89FC37
	v_dual_add_f32 v3, v36, v3 :: v_dual_add_f32 v4, v35, v4   // 0000007D40E0: C9080724 03040923
	s_waitcnt lgkmcnt(2)                                       // 0000007D40E8: BF89FC27
	v_add_f32_e32 v5, v34, v5                                  // 0000007D40EC: 060A0B22
	s_waitcnt lgkmcnt(0)                                       // 0000007D40F0: BF89FC07
	v_dual_add_f32 v1, v31, v1 :: v_dual_add_f32 v2, v2, v7    // 0000007D40F4: C908031F 01020F02
	ds_bpermute_b32 v8, v6, v3                                 // 0000007D40FC: DACC0000 08000306
	ds_bpermute_b32 v9, v6, v4                                 // 0000007D4104: DACC0000 09000406
	ds_bpermute_b32 v10, v6, v5                                // 0000007D410C: DACC0000 0A000506
	ds_bpermute_b32 v6, v6, v1                                 // 0000007D4114: DACC0000 06000106
	v_xor_b32_e32 v7, 1, v0                                    // 0000007D411C: 3A0E0081
	v_cndmask_b32_e32 v11, v0, v11, vcc_lo                     // 0000007D4120: 02161700
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007D4124: BF870132
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000007D4128: 7C980EA0
	v_cndmask_b32_e32 v0, v0, v7, vcc_lo                       // 0000007D412C: 02000F00
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 0000007D4130: 7C943C80
	v_lshlrev_b32_e32 v12, 2, v0                               // 0000007D4134: 30180082
	s_waitcnt lgkmcnt(2)                                       // 0000007D4138: BF89FC27
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v4, v4, v9     // 0000007D413C: C9081103 03041304
	s_waitcnt lgkmcnt(1)                                       // 0000007D4144: BF89FC17
	v_add_f32_e32 v5, v5, v10                                  // 0000007D4148: 060A1505
	s_waitcnt lgkmcnt(0)                                       // 0000007D414C: BF89FC07
	v_dual_add_f32 v8, v1, v6 :: v_dual_lshlrev_b32 v11, 2, v11// 0000007D4150: C9220D01 080A1682
	s_and_b32 s2, vcc_lo, s2                                   // 0000007D4158: 8B02026A
	ds_bpermute_b32 v1, v11, v2                                // 0000007D415C: DACC0000 0100020B
	ds_bpermute_b32 v6, v11, v3                                // 0000007D4164: DACC0000 0600030B
	ds_bpermute_b32 v9, v11, v4                                // 0000007D416C: DACC0000 0900040B
	ds_bpermute_b32 v10, v11, v5                               // 0000007D4174: DACC0000 0A00050B
	ds_bpermute_b32 v11, v11, v8                               // 0000007D417C: DACC0000 0B00080B
	s_waitcnt lgkmcnt(3)                                       // 0000007D4184: BF89FC37
	v_dual_add_f32 v7, v2, v1 :: v_dual_add_f32 v6, v3, v6     // 0000007D4188: C9080302 07060D03
	s_waitcnt lgkmcnt(1)                                       // 0000007D4190: BF89FC17
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v1, v5, v10    // 0000007D4194: C9081304 04001505
	s_waitcnt lgkmcnt(0)                                       // 0000007D419C: BF89FC07
	v_add_f32_e32 v0, v8, v11                                  // 0000007D41A0: 06001708
	ds_bpermute_b32 v9, v12, v7                                // 0000007D41A4: DACC0000 0900070C
	ds_bpermute_b32 v8, v12, v6                                // 0000007D41AC: DACC0000 0800060C
	ds_bpermute_b32 v5, v12, v4                                // 0000007D41B4: DACC0000 0500040C
	ds_bpermute_b32 v2, v12, v1                                // 0000007D41BC: DACC0000 0200010C
	ds_bpermute_b32 v3, v12, v0                                // 0000007D41C4: DACC0000 0300000C
	s_and_saveexec_b32 s3, s2                                  // 0000007D41CC: BE832002
	s_cbranch_execz 261                                        // 0000007D41D0: BFA50105 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x11e8>
	s_waitcnt lgkmcnt(3)                                       // 0000007D41D4: BF89FC37
	v_dual_add_f32 v7, v7, v9 :: v_dual_add_f32 v6, v6, v8     // 0000007D41D8: C9081307 07061106
	.long 0x7f163880                                           // 0000007D41E0: 7F163880
	s_load_b32 s1, s[0:1], 0x48                                // 0000007D41E4: F4000040 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000007D41EC: BF89FC07
	v_add_f32_e32 v0, v0, v3                                   // 0000007D41F0: 06000700
	.long 0x7e103987                                           // 0000007D41F4: 7E103987
	.long 0x7e163986                                           // 0000007D41F8: 7E163986
	.long 0x7f10398b                                           // 0000007D41FC: 7F10398B
	v_add_f32_e32 v4, v4, v5                                   // 0000007D4200: 06080B04
	v_bfe_u32 v3, v0, 16, 1                                    // 0000007D4204: D6100003 02052100
	.long 0x7f0a398b                                           // 0000007D420C: 7F0A398B
	v_and_b32_e32 v9, 1, v11                                   // 0000007D4210: 36121681
	v_and_b32_e32 v8, 1, v8                                    // 0000007D4214: 36101081
	.long 0x7e0a3984                                           // 0000007D4218: 7E0A3984
	v_add3_u32 v0, v0, v3, 0x7fff                              // 0000007D421C: D6550000 03FE0700 00007FFF
	.long 0x7f38398b                                           // 0000007D4228: 7F38398B
	v_add3_u32 v6, v6, v9, 0x7fff                              // 0000007D422C: D6550006 03FE1306 00007FFF
	v_add3_u32 v7, v7, v8, 0x7fff                              // 0000007D4238: D6550007 03FE1107 00007FFF
	s_lshl_b64 s[4:5], s[16:17], 1                             // 0000007D4244: 84848110
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007D4248: 360000FF FFFF0000
	s_lshl_b64 s[6:7], s[16:17], 2                             // 0000007D4250: 84868210
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000007D4254: 360C0CFF FFFF0000
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000007D425C: 360E0EFF FFFF0000
	v_dual_add_f32 v1, v1, v2 :: v_dual_and_b32 v2, 1, v5      // 0000007D4264: C9240501 01020A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007D426C: BF870112
	v_dual_mul_f32 v6, s1, v6 :: v_dual_mul_f32 v9, s1, v7     // 0000007D4270: C8C60C01 06080E01
	v_add3_u32 v2, v4, v2, 0x7fff                              // 0000007D4278: D6550002 03FE0504 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D4284: BF870092
	v_dual_mul_f32 v8, 0xbfb8aa3b, v6 :: v_dual_mul_f32 v7, 0xbfb8aa3b, v9// 0000007D4288: C8C60CFF 080612FF BFB8AA3B
	v_exp_f32_e32 v8, v8                                       // 0000007D4294: 7E104B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007D4298: BF870291
	v_exp_f32_e32 v7, v7                                       // 0000007D429C: 7E0E4B07
	v_dual_add_f32 v10, 1.0, v7 :: v_dual_add_f32 v7, 1.0, v8  // 0000007D42A0: C9080EF2 0A0610F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007D42A8: BF870111
	v_div_scale_f32 v8, null, v10, v10, v9                     // 0000007D42AC: D6FC7C08 0426150A
	v_div_scale_f32 v12, null, v7, v7, v6                      // 0000007D42B4: D6FC7C0C 041A0F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D42BC: BF870092
	v_rcp_f32_e32 v13, v8                                      // 0000007D42C0: 7E1A5508
	v_rcp_f32_e32 v14, v12                                     // 0000007D42C4: 7E1C550C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007D42C8: BF870296
	v_fma_f32 v15, -v8, v13, 1.0                               // 0000007D42CC: D613000F 23CA1B08
	v_fma_f32 v16, -v12, v14, 1.0                              // 0000007D42D4: D6130010 23CA1D0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007D42DC: BF8701A2
	v_fmac_f32_e32 v13, v15, v13                               // 0000007D42E0: 561A1B0F
	v_div_scale_f32 v15, s0, v6, v7, v6                        // 0000007D42E4: D6FC000F 041A0F06
	v_fmac_f32_e32 v14, v16, v14                               // 0000007D42EC: 561C1D10
	v_div_scale_f32 v17, vcc_lo, v9, v10, v9                   // 0000007D42F0: D6FC6A11 04261509
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007D42F8: BF870112
	v_mul_f32_e32 v18, v15, v14                                // 0000007D42FC: 10241D0F
	v_mul_f32_e32 v16, v17, v13                                // 0000007D4300: 10201B11
	s_waitcnt vmcnt(0)                                         // 0000007D4304: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D4308: BF870092
	v_fma_f32 v20, -v12, v18, v15                              // 0000007D430C: D6130014 243E250C
	v_fmac_f32_e32 v18, v20, v14                               // 0000007D4314: 56241D14
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007D4318: BF8700B1
	v_fma_f32 v12, -v12, v18, v15                              // 0000007D431C: D613000C 243E250C
	v_mul_f32_e32 v15, s1, v0                                  // 0000007D4324: 101E0001
	v_fma_f32 v19, -v8, v16, v17                               // 0000007D4328: D6130013 24462108
	v_fmac_f32_e32 v16, v19, v13                               // 0000007D4330: 56201B13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D4334: BF870091
	v_fma_f32 v8, -v8, v16, v17                                // 0000007D4338: D6130008 24462108
	v_div_fmas_f32 v13, v8, v13, v16                           // 0000007D4340: D637000D 04421B08
	s_mov_b32 vcc_lo, s0                                       // 0000007D4348: BEEA0000
	v_div_fmas_f32 v8, v12, v14, v18                           // 0000007D434C: D6370008 044A1D0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007D4354: BF870112
	v_div_fixup_f32 v13, v13, v10, v9                          // 0000007D4358: D627000D 0426150D
	v_div_fixup_f32 v12, v8, v7, v6                            // 0000007D4360: D627000C 041A0F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D4368: BF870091
	.long 0x7e16398c                                           // 0000007D436C: 7E16398C
	v_and_b32_e32 v14, 1, v11                                  // 0000007D4370: 361C1681
	.long 0x7e163981                                           // 0000007D4374: 7E163981
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007D4378: BF870112
	v_add3_u32 v12, v12, v14, 0x7fff                           // 0000007D437C: D655000C 03FE1D0C 00007FFF
	v_and_b32_e32 v4, 1, v11                                   // 0000007D4388: 36081681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D438C: BF870091
	v_add3_u32 v1, v1, v4, 0x7fff                              // 0000007D4390: D6550001 03FE0901 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007D439C: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D43A4: BF870091
	v_dual_mul_f32 v16, s1, v1 :: v_dual_mul_f32 v1, 0xbfb8aa3b, v15// 0000007D43A8: C8C60201 10001EFF BFB8AA3B
	v_mul_f32_e32 v3, 0xbfb8aa3b, v16                          // 0000007D43B4: 100620FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D43BC: BF870092
	v_exp_f32_e32 v1, v1                                       // 0000007D43C0: 7E024B01
	v_exp_f32_e32 v3, v3                                       // 0000007D43C4: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007D43C8: BF870296
	v_add_f32_e32 v18, 1.0, v1                                 // 0000007D43CC: 062402F2
	v_add_f32_e32 v20, 1.0, v3                                 // 0000007D43D0: 062806F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007D43D4: BF8701A2
	v_div_scale_f32 v21, null, v18, v18, v15                   // 0000007D43D8: D6FC7C15 043E2512
	v_div_scale_f32 v29, s0, v15, v18, v15                     // 0000007D43E0: D6FC001D 043E250F
	v_div_scale_f32 v25, null, v20, v20, v16                   // 0000007D43E8: D6FC7C19 04422914
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D43F0: BF870093
	v_rcp_f32_e32 v26, v21                                     // 0000007D43F4: 7E345515
	v_rcp_f32_e32 v27, v25                                     // 0000007D43F8: 7E365519
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000007D43FC: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 0000007D4404: BF870321
	v_mul_f32_e32 v2, s1, v2                                   // 0000007D4408: 10040401
	v_div_scale_f32 v31, s1, v16, v20, v16                     // 0000007D440C: D6FC011F 04422910
	v_fma_f32 v4, -v21, v26, 1.0                               // 0000007D4414: D6130004 23CA3515
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007D441C: BF870113
	v_mul_f32_e32 v0, 0xbfb8aa3b, v2                           // 0000007D4420: 100004FF BFB8AA3B
	v_fmac_f32_e32 v26, v4, v26                                // 0000007D4428: 56343504
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007D442C: BF870292
	v_exp_f32_e32 v0, v0                                       // 0000007D4430: 7E004B00
	v_dual_mul_f32 v32, v29, v26 :: v_dual_add_f32 v17, 1.0, v0// 0000007D4434: C8C8351D 201000F2
	.long 0xd73c0000                                           // 0000007D443C: D73C0000
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000007D4440: 02022E81
	.long 0x7f2e398b                                           // 0000007D4444: 7F2E398B
	.long 0x7e2e398d                                           // 0000007D4448: 7E2E398D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007D444C: BF870124
	v_div_scale_f32 v19, null, v17, v17, v2                    // 0000007D4450: D6FC7C13 040A2311
	v_div_scale_f32 v24, vcc_lo, v2, v17, v2                   // 0000007D4458: D6FC6A18 040A2302
	v_rcp_f32_e32 v22, v19                                     // 0000007D4460: 7E2C5513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007D4464: BF870095
	v_fma_f32 v3, -v19, v22, 1.0                               // 0000007D4468: D6130003 23CA2D13
	v_fmac_f32_e32 v22, v3, v22                                // 0000007D4470: 562C2D03
	v_fma_f32 v3, -v25, v27, 1.0                               // 0000007D4474: D6130003 23CA3719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007D447C: BF8700A1
	v_dual_mul_f32 v30, v24, v22 :: v_dual_fmac_f32 v27, v3, v27// 0000007D4480: C8C02D18 1E1A3703
	.long 0xd7000203                                           // 0000007D4488: D7000203
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 0000007D448C: 0202000C
	v_add_co_ci_u32_e64 v4, null, s13, v1, s2                  // 0000007D4490: D5207C04 000A020D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007D4498: BF870213
	v_fma_f32 v0, -v19, v30, v24                               // 0000007D449C: D6130000 24623D13
	v_mul_f32_e32 v33, v31, v27                                // 0000007D44A4: 1042371F
	v_fma_f32 v1, -v21, v32, v29                               // 0000007D44A8: D6130001 24764115
	.long 0xd7000205                                           // 0000007D44B0: D7000205
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 0000007D44B4: 02000903
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007D44B8: BF870214
	v_fmac_f32_e32 v30, v0, v22                                // 0000007D44BC: 563C2D00
	v_fma_f32 v0, -v25, v33, v31                               // 0000007D44C0: D6130000 247E4319
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007D44C8: BF870224
	v_fmac_f32_e32 v32, v1, v26                                // 0000007D44CC: 56403501
	v_add_co_ci_u32_e64 v6, null, s5, v4, s2                   // 0000007D44D0: D5207C06 000A0805
	v_fma_f32 v19, -v19, v30, v24                              // 0000007D44D8: D6130013 24623D13
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007D44E0: BF870214
	v_fmac_f32_e32 v33, v0, v27                                // 0000007D44E4: 56423700
	v_fma_f32 v21, -v21, v32, v29                              // 0000007D44E8: D6130015 24764115
	v_mad_u64_u32 v[0:1], null, s16, 6, v[3:4]                 // 0000007D44F0: D6FE7C00 040D0C10
	.long 0xd7000207                                           // 0000007D44F8: D7000207
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 0000007D44FC: 02000D03
	v_div_fmas_f32 v19, v19, v22, v30                          // 0000007D4500: D6370013 047A2D13
	v_fma_f32 v22, -v25, v33, v31                              // 0000007D4508: D6130016 247E4319
	s_mov_b32 vcc_lo, s1                                       // 0000007D4510: BEEA0001
	v_add_co_ci_u32_e64 v8, null, s7, v4, s2                   // 0000007D4514: D5207C08 000A0807
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007D451C: BF870193
	v_div_fixup_f32 v17, v19, v17, v2                          // 0000007D4520: D6270011 040A2313
	v_div_fmas_f32 v2, v22, v27, v33                           // 0000007D4528: D6370002 04863716
	s_mov_b32 vcc_lo, s0                                       // 0000007D4530: BEEA0000
	v_div_fmas_f32 v19, v21, v26, v32                          // 0000007D4534: D6370013 04823515
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007D453C: BF870193
	.long 0x7e383991                                           // 0000007D4540: 7E383991
	v_div_fixup_f32 v16, v2, v20, v16                          // 0000007D4544: D6270010 04422902
	v_mad_u64_u32 v[1:2], null, s17, 6, v[1:2]                 // 0000007D454C: D6FE7C01 04050C11
	.long 0xd7006a09                                           // 0000007D4554: D7006A09
	v_cndmask_b32_e32 v0, v7, v6, vcc_lo                       // 0000007D4558: 02000D07
	v_div_fixup_f32 v15, v19, v18, v15                         // 0000007D455C: D627000F 043E2513
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000007D4564: BF870244
	.long 0x7e163990                                           // 0000007D4568: 7E163990
	v_and_b32_e32 v18, 1, v23                                  // 0000007D456C: 36242E81
	v_and_b32_e32 v2, 1, v28                                   // 0000007D4570: 36043881
	v_add_co_ci_u32_e64 v10, null, s7, v8, vcc_lo              // 0000007D4574: D5207C0A 01AA1007
	v_and_b32_e32 v11, 1, v11                                  // 0000007D457C: 36161681
	v_bfe_u32 v19, v15, 16, 1                                  // 0000007D4580: D6100013 0205210F
	v_add3_u32 v13, v13, v18, 0x7fff                           // 0000007D4588: D655000D 03FE250D 00007FFF
	v_add3_u32 v2, v17, v2, 0x7fff                             // 0000007D4594: D6550002 03FE0511 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007D45A0: BF870214
	v_add3_u32 v11, v16, v11, 0x7fff                           // 0000007D45A4: D655000B 03FE1710 00007FFF
	v_add3_u32 v14, v15, v19, 0x7fff                           // 0000007D45B0: D655000E 03FE270F 00007FFF
	s_clause 0x4                                               // 0000007D45BC: BF850004
	global_store_d16_hi_b16 v[3:4], v13, off                   // 0000007D45C0: DC960000 007C0D03
	global_store_d16_hi_b16 v[5:6], v12, off                   // 0000007D45C8: DC960000 007C0C05
	global_store_d16_hi_b16 v[7:8], v2, off                    // 0000007D45D0: DC960000 007C0207
	global_store_d16_hi_b16 v[0:1], v11, off                   // 0000007D45D8: DC960000 007C0B00
	global_store_d16_hi_b16 v[9:10], v14, off                  // 0000007D45E0: DC960000 007C0E09
	s_endpgm                                                   // 0000007D45E8: BFB00000
		...

