0000000000f96000 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000F96000: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000F96008: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000F9600C: 32040082
	v_lshrrev_b32_e32 v29, 5, v0                               // 000000F96010: 323A0085
	v_and_b32_e32 v30, 31, v0                                  // 000000F96014: 363C009F
	.long 0x7f0a3880                                           // 000000F96018: 7F0A3880
	v_lshlrev_b32_e32 v28, 2, v0                               // 000000F9601C: 30380082
	s_waitcnt lgkmcnt(0)                                       // 000000F96020: BF89FC07
	.long 0xd4510000                                           // 000000F96024: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000F96028: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 000000F9602C: 8B007E00
	s_cselect_b32 s20, s3, 0                                   // 000000F96030: 98148003
	s_cselect_b32 s21, s2, 0                                   // 000000F96034: 98158002
	s_add_u32 s0, s4, s16                                      // 000000F96038: 80001004
	s_addc_u32 s1, s5, s17                                     // 000000F9603C: 82011105
	v_and_b32_e32 v1, 15, v0                                   // 000000F96040: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 000000F96044: 360404BC
	s_ashr_i32 s16, s11, 31                                    // 000000F96048: 86109F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F9604C: BF870119
	s_lshr_b32 s16, s16, 27                                    // 000000F96050: 85109B10
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F96054: 30020282
	s_add_u32 s16, s10, s16                                    // 000000F96058: 8010100A
	s_clause 0x1                                               // 000000F9605C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000F96060: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000F96068: DC520000 04040002
	s_addc_u32 s17, s11, 0                                     // 000000F96070: 8211800B
	v_mov_b32_e32 v2, s1                                       // 000000F96074: 7E040201
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000F96078: 85908510
	v_mov_b32_e32 v1, s0                                       // 000000F9607C: 7E020200
	s_add_i32 s17, s16, 7                                      // 000000F96080: 81118710
	s_mul_i32 s1, s19, s21                                     // 000000F96084: 96011513
	s_ashr_i32 s22, s17, 31                                    // 000000F96088: 86169F11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000F9608C: BF8704B9
	s_lshr_b32 s0, s22, 29                                     // 000000F96090: 85009D16
	v_mad_u64_u32 v[24:25], null, s18, s21, v[1:2]             // 000000F96094: D6FE7C18 04042A12
	s_add_i32 s17, s17, s0                                     // 000000F9609C: 81110011
	s_ashr_i32 s0, s17, 3                                      // 000000F960A0: 86008311
	s_cmpk_lt_i32 s16, 0x801                                   // 000000F960A4: B3900801
	.long 0xd72c0001                                           // 000000F960A8: D72C0001
	v_cndmask_b32_e32 v1, s0, v29, vcc_lo                      // 000000F960AC: 02023A00
	s_mul_i32 s17, s18, s20                                    // 000000F960B0: 96111412
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000F960B4: BF870141
	v_add_nc_u32_e32 v7, s0, v1                                // 000000F960B8: 4A0E0200
	v_add_nc_u32_e32 v31, v1, v30                              // 000000F960BC: 4A3E3D01
	s_cselect_b32 s0, -1, 0                                    // 000000F960C0: 980080C1
	s_cmpk_gt_i32 s16, 0x800                                   // 000000F960C4: B2900800
	v_min_i32_e32 v32, s16, v7                                 // 000000F960C8: 22400E10
	s_cselect_b32 s16, -1, 0                                   // 000000F960CC: 981080C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000F960D0: BF870159
	s_and_b32 vcc_lo, exec_lo, s16                             // 000000F960D4: 8B6A107E
	s_waitcnt vmcnt(1)                                         // 000000F960D8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 000000F960DC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 000000F960E4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 000000F960E8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000F960F0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s1, v25                               // 000000F960FC: 4A063201
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F96100: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000F96104: D6550004 03FE0D04 00007FFF
	.long 0xd4410001                                           // 000000F96110: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000F96114: 0202411F
	.long 0x7e0a3982                                           // 000000F96118: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F9611C: BF870114
	v_add_nc_u32_e32 v33, s17, v3                              // 000000F96120: 4A420611
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 000000F96124: D6570001 041608FF FFFF0000
	ds_store_b32 v28, v1                                       // 000000F96130: D8340000 0000011C
	s_waitcnt lgkmcnt(0)                                       // 000000F96138: BF89FC07
	s_barrier                                                  // 000000F9613C: BFBD0000
	buffer_gl0_inv                                             // 000000F96140: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000F96148: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 000000F9614C: CA100080 09080080
	s_and_saveexec_b32 s17, s1                                 // 000000F96154: BE912001
	s_cbranch_execz 11                                         // 000000F96158: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v31                               // 000000F9615C: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F96160: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000F96164: 3404029F
	.long 0xd7006a01                                           // 000000F96168: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000F9616C: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000F96170: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000F96178: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000F96180: BF8903F7
	v_cvt_f32_f16_e32 v8, v1                                   // 000000F96184: 7E101701
	s_or_b32 exec_lo, exec_lo, s17                             // 000000F96188: 8C7E117E
	v_add_nc_u32_e32 v1, 32, v31                               // 000000F9618C: 4A023EA0
	s_mov_b32 s1, exec_lo                                      // 000000F96190: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F96194: BF870001
	.long 0xd4c1007e                                           // 000000F96198: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000F9619C: 02024101
	s_cbranch_execz 11                                         // 000000F961A0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000F961A4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F961A8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000F961AC: 3404029F
	.long 0xd7006a01                                           // 000000F961B0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000F961B4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000F961B8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000F961C0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000F961C8: BF8903F7
	v_cvt_f32_f16_e32 v9, v1                                   // 000000F961CC: 7E121701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F961D0: 8C7E017E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v1, 64, v31     // 000000F961D4: CA200080 0A003EC0
	v_mov_b32_e32 v11, 0                                       // 000000F961DC: 7E160280
	s_mov_b32 s1, exec_lo                                      // 000000F961E0: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F961E4: BF870002
	.long 0xd4c1007e                                           // 000000F961E8: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000F961EC: 02024101
	s_cbranch_execz 11                                         // 000000F961F0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000F961F4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F961F8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000F961FC: 3404029F
	.long 0xd7006a01                                           // 000000F96200: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000F96204: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000F96208: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000F96210: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000F96218: BF8903F7
	v_cvt_f32_f16_e32 v10, v1                                  // 000000F9621C: 7E141701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F96220: 8C7E017E
	v_add_nc_u32_e32 v1, 0x60, v31                             // 000000F96224: 4A023EFF 00000060
	s_mov_b32 s1, exec_lo                                      // 000000F9622C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F96230: BF870001
	.long 0xd4c1007e                                           // 000000F96234: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000F96238: 02024101
	s_cbranch_execz 11                                         // 000000F9623C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000F96240: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F96244: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000F96248: 3404029F
	.long 0xd7006a01                                           // 000000F9624C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000F96250: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000F96254: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000F9625C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000F96264: BF8903F7
	v_cvt_f32_f16_e32 v11, v1                                  // 000000F96268: 7E161701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F9626C: 8C7E017E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v1, 0x80, v31   // 000000F96270: CA200080 0C003EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 000000F9627C: 7E1A0280
	s_mov_b32 s1, exec_lo                                      // 000000F96280: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F96284: BF870002
	.long 0xd4c1007e                                           // 000000F96288: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000F9628C: 02024101
	s_cbranch_execz 11                                         // 000000F96290: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000F96294: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F96298: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000F9629C: 3404029F
	.long 0xd7006a01                                           // 000000F962A0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000F962A4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000F962A8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000F962B0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000F962B8: BF8903F7
	v_cvt_f32_f16_e32 v12, v1                                  // 000000F962BC: 7E181701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F962C0: 8C7E017E
	v_add_nc_u32_e32 v1, 0xa0, v31                             // 000000F962C4: 4A023EFF 000000A0
	s_mov_b32 s1, exec_lo                                      // 000000F962CC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F962D0: BF870001
	.long 0xd4c1007e                                           // 000000F962D4: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000F962D8: 02024101
	s_cbranch_execz 11                                         // 000000F962DC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000F962E0: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F962E4: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000F962E8: 3404029F
	.long 0xd7006a01                                           // 000000F962EC: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000F962F0: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000F962F4: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000F962FC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000F96304: BF8903F7
	v_cvt_f32_f16_e32 v13, v1                                  // 000000F96308: 7E1A1701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F9630C: 8C7E017E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v1, 0xc0, v31   // 000000F96310: CA200080 0E003EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 000000F9631C: 7E1E0280
	s_mov_b32 s1, exec_lo                                      // 000000F96320: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F96324: BF870002
	.long 0xd4c1007e                                           // 000000F96328: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000F9632C: 02024101
	s_cbranch_execz 11                                         // 000000F96330: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000F96334: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F96338: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000F9633C: 3404029F
	.long 0xd7006a01                                           // 000000F96340: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000F96344: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000F96348: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000F96350: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000F96358: BF8903F7
	v_cvt_f32_f16_e32 v14, v1                                  // 000000F9635C: 7E1C1701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F96360: 8C7E017E
	v_add_nc_u32_e32 v1, 0xe0, v31                             // 000000F96364: 4A023EFF 000000E0
	s_mov_b32 s1, exec_lo                                      // 000000F9636C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F96370: BF870001
	.long 0xd4c1007e                                           // 000000F96374: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000F96378: 02024101
	s_cbranch_execz 11                                         // 000000F9637C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000F96380: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F96384: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000F96388: 3404029F
	.long 0xd7006a01                                           // 000000F9638C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000F96390: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000F96394: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000F9639C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000F963A4: BF8903F7
	v_cvt_f32_f16_e32 v15, v1                                  // 000000F963A8: 7E1E1701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F963AC: 8C7E017E
	s_branch 9                                                 // 000000F963B0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v8, 0                                        // 000000F963B4: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F963B8: BF870001
	v_mov_b32_e32 v9, v8                                       // 000000F963BC: 7E120308
	v_mov_b32_e32 v10, v8                                      // 000000F963C0: 7E140308
	v_mov_b32_e32 v11, v8                                      // 000000F963C4: 7E160308
	v_mov_b32_e32 v12, v8                                      // 000000F963C8: 7E180308
	v_mov_b32_e32 v13, v8                                      // 000000F963CC: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 000000F963D0: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 000000F963D4: 7E1E0308
	s_add_u32 s4, s4, s14                                      // 000000F963D8: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000F963DC: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 000000F963E0: 85019F0B
	v_dual_mov_b32 v1, s21 :: v_dual_mov_b32 v20, 0            // 000000F963E4: CA100015 01140080
	s_add_u32 s14, s10, s1                                     // 000000F963EC: 800E010A
	s_addc_u32 s15, s11, 0                                     // 000000F963F0: 820F800B
	.long 0xd4410001                                           // 000000F963F4: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000F963F8: 0202411F
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000F963FC: 868E810E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v27, 0             // 000000F96400: CA100080 221A0080
	v_mad_u64_u32 v[25:26], null, v1, s14, s[4:5]              // 000000F96408: D6FE7C19 00101D01
	.long 0xd72c0001                                           // 000000F96410: D72C0001
	v_cndmask_b32_e32 v0, s21, v15, vcc_lo                     // 000000F96414: 02001E15
	.long 0xd72c0002                                           // 000000F96418: D72C0002
	v_cndmask_b32_e32 v0, s20, v14, vcc_lo                     // 000000F9641C: 02001C14
	v_cndmask_b32_e64 v35, 0, 1, s16                           // 000000F96420: D5010023 00410280
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000F96428: CA100080 15160080
	v_mov_b32_e32 v23, 0                                       // 000000F96430: 7E2E0280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000F96434: BF870004
	v_add3_u32 v36, v2, v26, v1                                // 000000F96438: D6550024 04063502
	s_and_saveexec_b32 s4, s1                                  // 000000F96440: BE842001
	s_cbranch_execz 22                                         // 000000F96444: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 4, v31                               // 000000F96448: 30023E84
	v_mov_b32_e32 v27, 0                                       // 000000F9644C: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F96450: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000F96454: 3404029F
	.long 0xd7006a01                                           // 000000F96458: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 000000F9645C: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 000000F96460: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000F96468: 916A107E
	global_load_b128 v[20:23], v[1:2], off                     // 000000F9646C: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 000000F96474: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 1, v31                               // 000000F96478: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9647C: BF870091
	.long 0xd7006a01                                           // 000000F96480: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000F96484: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 000000F96488: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 000000F96490: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000F96498: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 000000F9649C: 7E361701
	s_or_b32 exec_lo, exec_lo, s4                              // 000000F964A0: 8C7E047E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 000000F964A4: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v37, 0             // 000000F964AC: CA100080 28240080
	s_and_saveexec_b32 s14, s1                                 // 000000F964B4: BE8E2001
	s_cbranch_execz 490                                        // 000000F964B8: BFA501EA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xc64>
	v_dual_mov_b32 v40, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 000000F964BC: CA200080 28003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 000000F964C4: CA220080 251A3E85
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v43, v27           // 000000F964CC: CA100080 222A011B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F964D4: BF870003
	v_dual_mov_b32 v38, 0 :: v_dual_lshlrev_b32 v41, 4, v1     // 000000F964D8: CA220080 26280284
	v_dual_mov_b32 v39, 0 :: v_dual_lshlrev_b32 v42, 1, v1     // 000000F964E0: CA220080 272A0281
	s_mul_i32 s1, s11, 6                                       // 000000F964E8: 9601860B
	s_mul_hi_u32 s15, s10, 6                                   // 000000F964EC: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000F964F0: 8484820A
	s_add_i32 s15, s15, s1                                     // 000000F964F4: 810F010F
	s_mul_i32 s17, s10, 6                                      // 000000F964F8: 9611860A
	s_mov_b32 s16, 0                                           // 000000F964FC: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000F96500: 848A810A
	s_branch 435                                               // 000000F96504: BFA001B3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xbd4>
	s_or_b32 exec_lo, exec_lo, s18                             // 000000F96508: 8C7E127E
	v_cndmask_b32_e64 v54, v27, v8, s0                         // 000000F9650C: D5010036 0002111B
	v_cndmask_b32_e64 v2, v9, v10, s0                          // 000000F96514: D5010002 00021509
	v_cndmask_b32_e64 v1, v8, v9, s0                           // 000000F9651C: D5010001 00021308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 000000F96524: CA24010F 080828FF 000000FF
	v_cndmask_b32_e64 v7, v14, v15, s0                         // 000000F96530: D5010007 00021F0E
	v_cndmask_b32_e64 v6, v13, v14, s0                         // 000000F96538: D5010006 00021D0D
	v_cndmask_b32_e64 v5, v12, v13, s0                         // 000000F96540: D5010005 00021B0C
	v_cndmask_b32_e64 v4, v11, v12, s0                         // 000000F96548: D5010004 0002190B
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000F96550: 30121282
	v_cndmask_b32_e64 v3, v10, v11, s0                         // 000000F96554: D5010003 0002170A
	v_ashrrev_i32_e32 v27, 31, v26                             // 000000F9655C: 3436349F
	v_add_nc_u32_e32 v41, 0x200, v41                           // 000000F96560: 4A5252FF 00000200
	s_and_b32 s1, exec_lo, s1                                  // 000000F96568: 8B01017E
	ds_load_b32 v15, v9                                        // 000000F9656C: D8D80000 0F000009
	v_lshrrev_b32_e32 v9, 6, v20                               // 000000F96574: 32122886
	s_or_b32 s16, s1, s16                                      // 000000F96578: 8C101001
	v_add_nc_u32_e32 v42, 64, v42                              // 000000F9657C: 4A5454C0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F96580: BF8700B2
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000F96584: 361212FF 000003FC
	ds_load_b32 v55, v9                                        // 000000F9658C: D8D80000 37000009
	v_lshrrev_b32_e32 v9, 14, v20                              // 000000F96594: 3212288E
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000F96598: 361212FF 000003FC
	ds_load_b32 v56, v9                                        // 000000F965A0: D8D80000 38000009
	v_lshrrev_b32_e32 v9, 22, v20                              // 000000F965A8: 32122896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F965AC: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000F965B0: 361212FF 000003FC
	ds_load_b32 v57, v9                                        // 000000F965B8: D8D80000 39000009
	v_and_b32_e32 v9, 0xff, v21                                // 000000F965C0: 36122AFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000F965C8: 30121282
	ds_load_b32 v58, v9                                        // 000000F965CC: D8D80000 3A000009
	v_lshrrev_b32_e32 v9, 6, v21                               // 000000F965D4: 32122A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F965D8: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000F965DC: 361212FF 000003FC
	ds_load_b32 v59, v9                                        // 000000F965E4: D8D80000 3B000009
	v_lshrrev_b32_e32 v9, 14, v21                              // 000000F965EC: 32122A8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000F965F0: 361212FF 000003FC
	ds_load_b32 v60, v9                                        // 000000F965F8: D8D80000 3C000009
	v_lshrrev_b32_e32 v9, 22, v21                              // 000000F96600: 32122A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F96604: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000F96608: 361212FF 000003FC
	ds_load_b32 v61, v9                                        // 000000F96610: D8D80000 3D000009
	v_and_b32_e32 v9, 0xff, v22                                // 000000F96618: 36122CFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000F96620: 30121282
	ds_load_b32 v62, v9                                        // 000000F96624: D8D80000 3E000009
	v_lshrrev_b32_e32 v9, 6, v22                               // 000000F9662C: 32122C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F96630: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000F96634: 361212FF 000003FC
	ds_load_b32 v63, v9                                        // 000000F9663C: D8D80000 3F000009
	v_lshrrev_b32_e32 v9, 14, v22                              // 000000F96644: 32122C8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000F96648: 361212FF 000003FC
	ds_load_b32 v64, v9                                        // 000000F96650: D8D80000 40000009
	v_lshrrev_b32_e32 v9, 22, v22                              // 000000F96658: 32122C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F9665C: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000F96660: 361212FF 000003FC
	ds_load_b32 v65, v9                                        // 000000F96668: D8D80000 41000009
	v_and_b32_e32 v9, 0xff, v23                                // 000000F96670: 36122EFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000F96678: 30121282
	ds_load_b32 v66, v9                                        // 000000F9667C: D8D80000 42000009
	v_lshrrev_b32_e32 v9, 6, v23                               // 000000F96684: 32122E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F96688: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000F9668C: 361212FF 000003FC
	ds_load_b32 v67, v9                                        // 000000F96694: D8D80000 43000009
	v_lshrrev_b32_e32 v9, 14, v23                              // 000000F9669C: 32122E8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000F966A0: 361212FF 000003FC
	ds_load_b32 v68, v9                                        // 000000F966A8: D8D80000 44000009
	v_lshrrev_b32_e32 v9, 22, v23                              // 000000F966B0: 32122E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000F966B4: BF870141
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000F966B8: 361212FF 000003FC
	ds_load_b32 v69, v9                                        // 000000F966C0: D8D80000 45000009
	.long 0xd73c0009                                           // 000000F966C8: D73C0009
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 000000F966CC: 02023481
	v_dual_mov_b32 v27, v43 :: v_dual_add_nc_u32 v26, 0x400, v26// 000000F966D0: CA20012B 1B1A34FF 00000400
	.long 0xd7006a0d                                           // 000000F966DC: D7006A0D
	v_cndmask_b32_e32 v1, s6, v9, vcc_lo                       // 000000F966E0: 02021206
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F966E4: BF870001
	v_add_co_ci_u32_e64 v14, null, s7, v10, vcc_lo             // 000000F966E8: D5207C0E 01AA1407
	s_clause 0x3                                               // 000000F966F0: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 000000F966F4: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 000000F966FC: DC5E0010 147C000D
	global_load_b128 v[44:47], v[13:14], off offset:32         // 000000F96704: DC5E0020 2C7C000D
	global_load_b128 v[48:51], v[13:14], off offset:48         // 000000F9670C: DC5E0030 307C000D
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000F96714: BF890CF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000F96718: CC1A4009 1A021F09
	s_waitcnt lgkmcnt(14)                                      // 000000F96720: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F96724: BF8700A1
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 000000F96728: CC1A4009 1C266F0A
	s_waitcnt lgkmcnt(13)                                      // 000000F96730: BF89FCD7
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 000000F96734: CC1A4009 1C26710B
	s_waitcnt lgkmcnt(12)                                      // 000000F9673C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F96740: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 000000F96744: CC1A4009 1C26730C
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000F9674C: BF8908B7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 000000F96750: CC1A4009 1C267514
	s_waitcnt lgkmcnt(10)                                      // 000000F96758: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F9675C: BF8700A1
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 000000F96760: CC1A4009 1C267715
	s_waitcnt lgkmcnt(9)                                       // 000000F96768: BF89FC97
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 000000F9676C: CC1A4009 1C267916
	s_waitcnt lgkmcnt(8)                                       // 000000F96774: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F96778: BF8700A1
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 000000F9677C: CC1A4009 1C267B17
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000F96784: BF890477
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 000000F96788: CC1A4009 1C267D2C
	s_waitcnt lgkmcnt(6)                                       // 000000F96790: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F96794: BF8700A1
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000F96798: CC1A4009 1C267F2D
	s_waitcnt lgkmcnt(5)                                       // 000000F967A0: BF89FC57
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000F967A4: CC1A4009 1C26812E
	s_waitcnt lgkmcnt(4)                                       // 000000F967AC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F967B0: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 000000F967B4: CC1A4009 1C26832F
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000F967BC: BF890037
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000F967C0: CC1A4009 1C268530
	.long 0xd7006a30                                           // 000000F967C8: D7006A30
	v_cndmask_b32_e32 v0, v13, v10, vcc_lo                     // 000000F967CC: 0200150D
	s_waitcnt lgkmcnt(2)                                       // 000000F967D0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000F967D4: BF8701C2
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 000000F967D8: CC1A4009 1C268731
	v_add_co_ci_u32_e64 v49, null, s11, v14, vcc_lo            // 000000F967E0: D5207C31 01AA1C0B
	.long 0xd7006a34                                           // 000000F967E8: D7006A34
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 000000F967EC: 0200090D
	s_waitcnt lgkmcnt(1)                                       // 000000F967F0: BF89FC17
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 000000F967F4: CC1A4009 1C268932
	v_add_co_ci_u32_e64 v53, null, s5, v14, vcc_lo             // 000000F967FC: D5207C35 01AA1C05
	.long 0xd7006a0d                                           // 000000F96804: D7006A0D
	v_cndmask_b32_e32 v0, v13, v17, vcc_lo                     // 000000F96808: 0200230D
	s_waitcnt lgkmcnt(0)                                       // 000000F9680C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F96810: BF870123
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 000000F96814: CC1A4009 1C268B33
	v_add_co_ci_u32_e64 v14, null, s15, v14, vcc_lo            // 000000F9681C: D5207C0E 01AA1C0F
	v_fmac_f32_e32 v37, v54, v9                                // 000000F96824: 564A1336
	s_clause 0x3                                               // 000000F96828: BF850003
	global_load_b128 v[9:12], v[48:49], off                    // 000000F9682C: DC5E0000 097C0030
	global_load_b128 v[20:23], v[48:49], off offset:16         // 000000F96834: DC5E0010 147C0030
	global_load_b128 v[44:47], v[48:49], off offset:32         // 000000F9683C: DC5E0020 2C7C0030
	global_load_b128 v[48:51], v[48:49], off offset:48         // 000000F96844: DC5E0030 307C0030
	s_waitcnt vmcnt(3)                                         // 000000F9684C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000F96850: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96858: BF870091
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 000000F9685C: CC1A4009 1C266F0A
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 000000F96864: CC1A4009 1C26710B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F9686C: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 000000F96870: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 000000F96878: BF890BF7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 000000F9687C: CC1A4009 1C267514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96884: BF870091
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 000000F96888: CC1A4009 1C267715
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 000000F96890: CC1A4009 1C267916
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F96898: BF8700A1
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 000000F9689C: CC1A4009 1C267B17
	s_waitcnt vmcnt(1)                                         // 000000F968A4: BF8907F7
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 000000F968A8: CC1A4009 1C267D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F968B0: BF870091
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000F968B4: CC1A4009 1C267F2D
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000F968BC: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F968C4: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 000000F968C8: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 000000F968D0: BF8903F7
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000F968D4: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F968DC: BF870091
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 000000F968E0: CC1A4009 1C268731
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 000000F968E8: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F968F0: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 000000F968F4: CC1A4009 1C268B33
	v_fmac_f32_e32 v40, v54, v9                                // 000000F968FC: 56501336
	s_clause 0x3                                               // 000000F96900: BF850003
	global_load_b128 v[9:12], v[52:53], off                    // 000000F96904: DC5E0000 097C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 000000F9690C: DC5E0010 147C0034
	global_load_b128 v[44:47], v[52:53], off offset:32         // 000000F96914: DC5E0020 2C7C0034
	global_load_b128 v[48:51], v[52:53], off offset:48         // 000000F9691C: DC5E0030 307C0034
	s_waitcnt vmcnt(3)                                         // 000000F96924: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000F96928: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96930: BF870091
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 000000F96934: CC1A4009 1C266F0A
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 000000F9693C: CC1A4009 1C26710B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F96944: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 000000F96948: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 000000F96950: BF890BF7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 000000F96954: CC1A4009 1C267514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9695C: BF870091
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 000000F96960: CC1A4009 1C267715
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 000000F96968: CC1A4009 1C267916
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F96970: BF8700A1
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 000000F96974: CC1A4009 1C267B17
	s_waitcnt vmcnt(1)                                         // 000000F9697C: BF8907F7
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 000000F96980: CC1A4009 1C267D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96988: BF870091
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000F9698C: CC1A4009 1C267F2D
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000F96994: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F9699C: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 000000F969A0: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 000000F969A8: BF8903F7
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000F969AC: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F969B4: BF870091
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 000000F969B8: CC1A4009 1C268731
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 000000F969C0: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F969C8: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 000000F969CC: CC1A4009 1C268B33
	v_fmac_f32_e32 v39, v54, v9                                // 000000F969D4: 564E1336
	s_clause 0x3                                               // 000000F969D8: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 000000F969DC: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 000000F969E4: DC5E0010 147C000D
	global_load_b128 v[44:47], v[13:14], off offset:32         // 000000F969EC: DC5E0020 2C7C000D
	global_load_b128 v[48:51], v[13:14], off offset:48         // 000000F969F4: DC5E0030 307C000D
	.long 0xd7006a0d                                           // 000000F969FC: D7006A0D
	v_cndmask_b32_e32 v0, v52, v4, vcc_lo                      // 000000F96A00: 02000934
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F96A04: BF8700B1
	v_add_co_ci_u32_e64 v14, null, s5, v53, vcc_lo             // 000000F96A08: D5207C0E 01AA6A05
	s_waitcnt vmcnt(3)                                         // 000000F96A10: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000F96A14: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 000000F96A1C: CC1A4009 1C266F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96A24: BF870091
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 000000F96A28: CC1A4009 1C26710B
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 000000F96A30: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 000000F96A38: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96A3C: BF870091
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 000000F96A40: CC1A4009 1C267514
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 000000F96A48: CC1A4009 1C267715
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96A50: BF870091
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 000000F96A54: CC1A4009 1C267916
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 000000F96A5C: CC1A4009 1C267B17
	s_waitcnt vmcnt(1)                                         // 000000F96A64: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96A68: BF870091
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 000000F96A6C: CC1A4009 1C267D2C
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000F96A74: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96A7C: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000F96A80: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 000000F96A88: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 000000F96A90: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96A94: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000F96A98: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 000000F96AA0: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96AA8: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 000000F96AAC: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 000000F96AB4: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F96ABC: BF870001
	v_fmac_f32_e32 v38, v54, v9                                // 000000F96AC0: 564C1336
	s_clause 0x3                                               // 000000F96AC4: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 000000F96AC8: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 000000F96AD0: DC5E0010 147C000D
	global_load_b128 v[44:47], v[13:14], off offset:32         // 000000F96AD8: DC5E0020 2C7C000D
	global_load_b128 v[48:51], v[13:14], off offset:48         // 000000F96AE0: DC5E0030 307C000D
	s_waitcnt vmcnt(3)                                         // 000000F96AE8: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000F96AEC: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96AF4: BF870091
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 000000F96AF8: CC1A4009 1C266F0A
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 000000F96B00: CC1A4009 1C26710B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F96B08: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 000000F96B0C: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 000000F96B14: BF890BF7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 000000F96B18: CC1A4009 1C267514
	v_mov_b32_e32 v20, v16                                     // 000000F96B20: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F96B24: BF870122
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 000000F96B28: CC1A4009 1C267715
	v_mov_b32_e32 v21, v17                                     // 000000F96B30: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 000000F96B34: CC1A4009 1C267916
	v_mov_b32_e32 v22, v18                                     // 000000F96B3C: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000F96B40: BF870132
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 000000F96B44: CC1A4009 1C267B17
	v_mov_b32_e32 v23, v19                                     // 000000F96B4C: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 000000F96B50: BF8907F7
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 000000F96B54: CC1A4009 1C267D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96B5C: BF870091
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000F96B60: CC1A4009 1C267F2D
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000F96B68: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F96B70: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 000000F96B74: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 000000F96B7C: BF8903F7
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000F96B80: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96B88: BF870091
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 000000F96B8C: CC1A4009 1C268731
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 000000F96B94: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96B9C: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 000000F96BA0: CC1A4009 1C268B33
	v_dual_fmac_f32 v34, v54, v9 :: v_dual_mov_b32 v15, v8     // 000000F96BA8: C8101336 220E0108
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 000000F96BB0: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 000000F96BB8: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 000000F96BC0: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 000000F96BC8: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000F96BCC: 917E107E
	s_cbranch_execz 35                                         // 000000F96BD0: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xc60>
	s_waitcnt vmcnt(0)                                         // 000000F96BD4: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 000000F96BD8: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 000000F96BE0: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 000000F96BE8: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F96BEC: BF870003
	.long 0xd4460001                                           // 000000F96BF0: D4460001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000F96BF4: 0202411F
	s_mov_b32 s18, exec_lo                                     // 000000F96BF8: BE92007E
	.long 0xd4c1007e                                           // 000000F96BFC: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000F96C00: 0202411F
	s_cbranch_execz 65088                                      // 000000F96C04: BFA5FE40 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	v_ashrrev_i32_e32 v2, 31, v41                              // 000000F96C08: 3404529F
	.long 0xd7006a01                                           // 000000F96C0C: D7006A01
	v_cndmask_b32_e32 v1, v25, v41, vcc_lo                     // 000000F96C10: 02025319
	v_mov_b32_e32 v43, v27                                     // 000000F96C14: 7E56031B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F96C18: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 000000F96C1C: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 000000F96C24: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 000000F96C28: DC5E0000 107C0001
	s_cbranch_vccnz 65077                                      // 000000F96C30: BFA4FE35 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	v_ashrrev_i32_e32 v2, 31, v42                              // 000000F96C34: 3404549F
	.long 0xd7006a01                                           // 000000F96C38: D7006A01
	v_cndmask_b32_e32 v1, v24, v42, vcc_lo                     // 000000F96C3C: 02025518
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F96C40: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000F96C44: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000F96C4C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000F96C54: BF8903F7
	v_cvt_f32_f16_e32 v43, v1                                  // 000000F96C58: 7E561701
	s_branch 65066                                             // 000000F96C5C: BFA0FE2A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000F96C60: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F96C64: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 000000F96C68: 8C7E0E7E
	.long 0xd71f0001                                           // 000000F96C6C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000F96C70: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000F96C74: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000F96C78: 3A040290
	v_xor_b32_e32 v7, 8, v1                                    // 000000F96C7C: 3A0E0288
	v_xor_b32_e32 v12, 4, v1                                   // 000000F96C80: 3A180284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F96C84: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000F96C88: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000F96C8C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 000000F96C90: 7C980EA0
	v_cndmask_b32_e32 v7, v1, v7, vcc_lo                       // 000000F96C94: 020E0F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 000000F96C98: 7C9818A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F96C9C: BF870002
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000F96CA0: 300E0E82
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000F96CA4: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 000000F96CA8: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 000000F96CB0: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 000000F96CB4: 06060725
	ds_bpermute_b32 v4, v2, v40                                // 000000F96CB8: DACC0000 04002802
	ds_bpermute_b32 v5, v2, v39                                // 000000F96CC0: DACC0000 05002702
	ds_bpermute_b32 v6, v2, v38                                // 000000F96CC8: DACC0000 06002602
	ds_bpermute_b32 v2, v2, v34                                // 000000F96CD0: DACC0000 02002202
	ds_bpermute_b32 v8, v7, v3                                 // 000000F96CD8: DACC0000 08000307
	s_waitcnt lgkmcnt(3)                                       // 000000F96CE0: BF89FC37
	v_dual_add_f32 v4, v40, v4 :: v_dual_add_f32 v5, v39, v5   // 000000F96CE4: C9080928 04040B27
	s_waitcnt lgkmcnt(2)                                       // 000000F96CEC: BF89FC27
	v_add_f32_e32 v6, v38, v6                                  // 000000F96CF0: 060C0D26
	s_waitcnt lgkmcnt(0)                                       // 000000F96CF4: BF89FC07
	v_dual_add_f32 v2, v34, v2 :: v_dual_add_f32 v3, v3, v8    // 000000F96CF8: C9080522 02021103
	ds_bpermute_b32 v9, v7, v4                                 // 000000F96D00: DACC0000 09000407
	ds_bpermute_b32 v10, v7, v5                                // 000000F96D08: DACC0000 0A000507
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 000000F96D10: 02181901
	ds_bpermute_b32 v11, v7, v6                                // 000000F96D14: DACC0000 0B000607
	ds_bpermute_b32 v7, v7, v2                                 // 000000F96D1C: DACC0000 07000207
	v_lshlrev_b32_e32 v12, 2, v12                              // 000000F96D24: 30181882
	s_waitcnt lgkmcnt(2)                                       // 000000F96D28: BF89FC27
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v10    // 000000F96D2C: C9081304 04041505
	ds_bpermute_b32 v8, v12, v4                                // 000000F96D34: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 000000F96D3C: DACC0000 0900050C
	s_waitcnt lgkmcnt(3)                                       // 000000F96D44: BF89FC37
	v_add_f32_e32 v6, v6, v11                                  // 000000F96D48: 060C1706
	s_waitcnt lgkmcnt(1)                                       // 000000F96D4C: BF89FC17
	v_add_f32_e32 v4, v4, v8                                   // 000000F96D50: 06081104
	v_add_f32_e32 v2, v2, v7                                   // 000000F96D54: 06040F02
	ds_bpermute_b32 v7, v12, v3                                // 000000F96D58: DACC0000 0700030C
	s_waitcnt lgkmcnt(1)                                       // 000000F96D60: BF89FC17
	v_add_f32_e32 v5, v5, v9                                   // 000000F96D64: 060A1305
	ds_bpermute_b32 v10, v12, v6                               // 000000F96D68: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 000000F96D70: DACC0000 0B00020C
	v_xor_b32_e32 v12, 2, v1                                   // 000000F96D78: 3A180282
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F96D7C: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 000000F96D80: 7C9818A0
	s_waitcnt lgkmcnt(2)                                       // 000000F96D84: BF89FC27
	v_dual_add_f32 v3, v3, v7 :: v_dual_cndmask_b32 v12, v1, v12// 000000F96D88: C9120F03 030C1901
	s_waitcnt lgkmcnt(1)                                       // 000000F96D90: BF89FC17
	v_add_f32_e32 v6, v6, v10                                  // 000000F96D94: 060C1506
	s_waitcnt lgkmcnt(0)                                       // 000000F96D98: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 000000F96D9C: 06041702
	v_lshlrev_b32_e32 v12, 2, v12                              // 000000F96DA0: 30181882
	ds_bpermute_b32 v7, v12, v3                                // 000000F96DA4: DACC0000 0700030C
	ds_bpermute_b32 v8, v12, v4                                // 000000F96DAC: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 000000F96DB4: DACC0000 0900050C
	ds_bpermute_b32 v10, v12, v6                               // 000000F96DBC: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 000000F96DC4: DACC0000 0B00020C
	v_xor_b32_e32 v12, 1, v1                                   // 000000F96DCC: 3A180281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F96DD0: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 000000F96DD4: 7C9818A0
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 000000F96DD8: 02021901
	s_waitcnt lgkmcnt(4)                                       // 000000F96DDC: BF89FC47
	v_dual_add_f32 v1, v3, v7 :: v_dual_lshlrev_b32 v12, 2, v1 // 000000F96DE0: C9220F03 010C0282
	s_waitcnt lgkmcnt(2)                                       // 000000F96DE8: BF89FC27
	v_dual_add_f32 v3, v4, v8 :: v_dual_add_f32 v4, v5, v9     // 000000F96DEC: C9081104 03041305
	s_waitcnt lgkmcnt(1)                                       // 000000F96DF4: BF89FC17
	v_add_f32_e32 v7, v6, v10                                  // 000000F96DF8: 060E1506
	s_waitcnt lgkmcnt(0)                                       // 000000F96DFC: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 000000F96E00: 06041702
	ds_bpermute_b32 v5, v12, v1                                // 000000F96E04: DACC0000 0500010C
	ds_bpermute_b32 v8, v12, v3                                // 000000F96E0C: DACC0000 0800030C
	ds_bpermute_b32 v9, v12, v4                                // 000000F96E14: DACC0000 0900040C
	ds_bpermute_b32 v10, v12, v7                               // 000000F96E1C: DACC0000 0A00070C
	ds_bpermute_b32 v6, v12, v2                                // 000000F96E24: DACC0000 0600020C
	v_cmpx_eq_u32_e32 0, v30                                   // 000000F96E2C: 7D943C80
	s_cbranch_execz 18                                         // 000000F96E30: BFA50012 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xe7c>
	v_mul_u32_u24_e32 v11, 20, v29                             // 000000F96E34: 16163A94
	s_waitcnt lgkmcnt(0)                                       // 000000F96E38: BF89FC07
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v2, v2, v6     // 000000F96E3C: C9081103 03020D02
	v_add_f32_e32 v1, v1, v5                                   // 000000F96E44: 06020B01
	v_dual_add_f32 v7, v7, v10 :: v_dual_add_f32 v4, v4, v9    // 000000F96E48: C9081507 07041304
	v_or_b32_e32 v5, 0x400, v11                                // 000000F96E50: 380A16FF 00000400
	v_mad_u32_u24 v8, v29, 20, 0x408                           // 000000F96E58: D60B0008 03FD291D 00000408
	ds_store_2addr_b32 v5, v1, v3 offset1:1                    // 000000F96E64: D8380100 00030105
	ds_store_2addr_b32 v8, v4, v7 offset1:1                    // 000000F96E6C: D8380100 00070408
	ds_store_b32 v11, v2 offset:1040                           // 000000F96E74: D8340410 0000020B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000F96E7C: 8C7E007E
	.long 0xd4510000                                           // 000000F96E80: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000F96E84: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 5, v0                             // 000000F96E88: 7C980085
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000F96E8C: BF890007
	s_barrier                                                  // 000000F96E90: BFBD0000
	buffer_gl0_inv                                             // 000000F96E94: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000F96E9C: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000F96EA0: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000F96EA4: BE812000
	s_cbranch_execz 74                                         // 000000F96EA8: BFA5004A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xfd4>
	v_add_nc_u32_e32 v7, 0x400, v28                            // 000000F96EAC: 4A0E38FF 00000400
	s_lshl_b64 s[0:1], s[2:3], 2                               // 000000F96EB4: 84808202
	ds_load_2addr_b32 v[1:2], v7 offset1:5                     // 000000F96EB8: D8DC0500 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:10 offset1:15         // 000000F96EC0: D8DC0F0A 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:20 offset1:25         // 000000F96EC8: D8DC1914 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000F96ED0: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000F96ED4: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000F96ED8: BF8700C1
	v_add_f32_e32 v8, v1, v2                                   // 000000F96EDC: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:30 offset1:35         // 000000F96EE0: D8DC231E 01000007
	s_waitcnt lgkmcnt(2)                                       // 000000F96EE8: BF89FC27
	v_add_f32_e32 v3, v8, v3                                   // 000000F96EEC: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 000000F96EF0: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000F96EF4: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96EF8: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000F96EFC: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000F96F00: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000F96F04: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96F08: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000F96F0C: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000F96F10: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96F14: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000F96F18: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 000000F96F20: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96F24: BF870095
	v_add_f32_e32 v4, 1.0, v1                                  // 000000F96F28: 060802F2
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 000000F96F2C: D6FC7C05 03CA0904
	v_div_scale_f32 v7, vcc_lo, 1.0, v4, 1.0                   // 000000F96F34: D6FC6A07 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000F96F3C: BF870292
	v_rcp_f32_e32 v6, v5                                       // 000000F96F40: 7E0C5505
	v_fma_f32 v1, -v5, v6, 1.0                                 // 000000F96F44: D6130001 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F96F4C: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 000000F96F50: 560C0D01
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000F96F54: D6FE7C01 0202000C
	v_mul_f32_e32 v8, v7, v6                                   // 000000F96F5C: 10100D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F96F60: BF870112
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000F96F64: D6FE7C02 040A000D
	v_fma_f32 v9, -v5, v8, v7                                  // 000000F96F6C: D6130009 241E1105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F96F74: BF870191
	v_fmac_f32_e32 v8, v9, v6                                  // 000000F96F78: 56100D09
	.long 0xd73c0000                                           // 000000F96F7C: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000F96F80: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96F84: BF870092
	v_fma_f32 v3, -v5, v8, v7                                  // 000000F96F88: D6130003 241E1105
	v_div_fmas_f32 v2, v3, v6, v8                              // 000000F96F90: D6370002 04220D03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F96F98: BF870093
	.long 0xd7006a00                                           // 000000F96F9C: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000F96FA0: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000F96FA4: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F96FAC: BF870193
	v_div_fixup_f32 v2, v2, v4, 1.0                            // 000000F96FB0: D6270002 03CA0902
	.long 0xd7006a00                                           // 000000F96FB8: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000F96FBC: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F96FC0: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000F96FC4: D5207C01 01AA0201
	global_store_b32 v[0:1], v2, off                           // 000000F96FCC: DC6A0000 007C0200
	s_endpgm                                                   // 000000F96FD4: BFB00000
		...

