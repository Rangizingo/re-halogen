00000000007c5f00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007C5F00: F4100100 F8000000
	v_and_b32_e32 v16, 15, v0                                  // 0000007C5F08: 3620008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000007C5F0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 0000007C5F10: 86039F02
	.long 0x7f103880                                           // 0000007C5F14: 7F103880
	s_lshl_b64 s[2:3], s[2:3], 4                               // 0000007C5F18: 84828402
	v_mov_b32_e32 v17, 0                                       // 0000007C5F1C: 7E220280
	v_dual_mov_b32 v10, s3 :: v_dual_lshlrev_b32 v3, 2, v1     // 0000007C5F20: CA220003 0A020282
	v_or_b32_e32 v9, s2, v1                                    // 0000007C5F28: 38120202
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v2, 2, v16      // 0000007C5F2C: CA220080 01022082
	s_waitcnt lgkmcnt(0)                                       // 0000007C5F34: BF89FC07
	s_clause 0x1                                               // 0000007C5F38: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 0000007C5F3C: DC520000 04040002
	global_load_b32 v7, v3, s[4:5]                             // 0000007C5F44: DC520000 07040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 0000007C5F4C: 7CA8120C
	s_add_u32 s14, s4, s14                                     // 0000007C5F50: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000007C5F54: 820F0F05
	s_lshr_b32 s2, s11, 31                                     // 0000007C5F58: 85029F0B
	v_mov_b32_e32 v18, 0                                       // 0000007C5F5C: 7E240280
	s_add_u32 s20, s10, s2                                     // 0000007C5F60: 8014020A
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 0000007C5F64: 02161280
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 0000007C5F68: D501000E 01A80680
	s_addc_u32 s21, s11, 0                                     // 0000007C5F70: 8215800B
	s_ashr_i32 s22, s11, 31                                    // 0000007C5F74: 86169F0B
	s_ashr_i64 s[2:3], s[20:21], 1                             // 0000007C5F78: 86828114
	.long 0xd72c000d                                           // 0000007C5F7C: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 0000007C5F80: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 0000007C5F84: D6FE7C05 02021612
	.long 0xd72c000f                                           // 0000007C5F8C: D72C000F
	v_cndmask_b32_e32 v0, v11, v3, vcc_lo                      // 0000007C5F90: 0200070B
	.long 0xd72c0014                                           // 0000007C5F94: D72C0014
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 0000007C5F98: 0200050E
	.long 0xd72c000e                                           // 0000007C5F9C: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000007C5FA0: 02021C12
	s_lshr_b32 s19, s22, 27                                    // 0000007C5FA4: 85139B16
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 0000007C5FA8: CA100080 02020080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007C5FB0: BF870152
	v_add3_u32 v6, v6, v14, v13                                // 0000007C5FB4: D6550006 04361D06
	s_waitcnt vmcnt(1)                                         // 0000007C5FBC: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 0000007C5FC0: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 0000007C5FC8: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 0000007C5FCC: D6100013 02052107
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000007C5FD4: D6550004 03FE1904 00007FFF
	v_mad_u64_u32 v[11:12], null, v11, s2, s[14:15]            // 0000007C5FE0: D6FE7C0B 0038050B
	s_add_u32 s14, s10, s19                                    // 0000007C5FE8: 800E130A
	v_add3_u32 v7, v7, v19, 0x7fff                             // 0000007C5FEC: D6550007 03FE2707 00007FFF
	s_addc_u32 s15, s11, 0                                     // 0000007C5FF8: 820F800B
	.long 0x7e103984                                           // 0000007C5FFC: 7E103984
	s_lshr_b64 s[14:15], s[14:15], 5                           // 0000007C6000: 858E850E
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v19, 2, v0      // 0000007C6004: CA220080 04120082
	.long 0xd4440002                                           // 0000007C600C: D4440002
	v_cndmask_b32_e32 v1, s14, v16, vcc_lo                     // 0000007C6010: 0202200E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C6014: BF870003
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 0000007C6018: D6570007 04220EFF FFFF0000
	v_add3_u32 v0, v20, v12, v15                               // 0000007C6024: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 0000007C602C: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 0000007C6034: BF89FC07
	s_barrier                                                  // 0000007C6038: BFBD0000
	buffer_gl0_inv                                             // 0000007C603C: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 0000007C6044: BE8F2002
	s_cbranch_execz 26                                         // 0000007C6048: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x1b4>
	s_add_u32 s3, s4, s16                                      // 0000007C604C: 80031004
	s_addc_u32 s18, s5, s17                                    // 0000007C6050: 82121105
	v_lshlrev_b32_e32 v1, 1, v16                               // 0000007C6054: 30022081
	.long 0xd7000302                                           // 0000007C6058: D7000302
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 0000007C605C: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C6060: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s18, v6, s3                  // 0000007C6064: D5207C03 000E0C12
	v_lshlrev_b32_e32 v4, 4, v16                               // 0000007C606C: 30082084
	.long 0xd7000301                                           // 0000007C6070: D7000301
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000007C6074: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C6078: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s3                    // 0000007C607C: D5207C02 000E0680
	.long 0xd7000303                                           // 0000007C6084: D7000303
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 0000007C6088: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C608C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s3                    // 0000007C6090: D5207C04 000E0080
	s_clause 0x1                                               // 0000007C6098: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 0000007C609C: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000007C60A4: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000007C60AC: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 0000007C60B0: 7E241707
	s_or_b32 exec_lo, exec_lo, s15                             // 0000007C60B4: 8C7E0F7E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000007C60B8: CA100080 13140080
	s_and_saveexec_b32 s15, s2                                 // 0000007C60C0: BE8F2002
	s_cbranch_execz 331                                        // 0000007C60C4: BFA5014B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x6f4>
	v_dual_mov_b32 v22, v16 :: v_dual_lshlrev_b32 v7, 1, v16   // 0000007C60C8: CA220110 16062081
	.long 0xd7000205                                           // 0000007C60D0: D7000205
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 0000007C60D4: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C60D8: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s2                  // 0000007C60DC: D5207C06 000A0C11
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 0000007C60E4: CA220080 0D0C2085
	.long 0xd7000205                                           // 0000007C60EC: D7000205
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000007C60F0: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C60F4: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s2                    // 0000007C60F8: D5207C06 000A0C80
	v_lshl_or_b32 v21, v16, 4, 0x100                           // 0000007C6100: D6560015 03FD0910 00000100
	.long 0xd7000205                                           // 0000007C610C: D7000205
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000007C6110: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C6114: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s2                   // 0000007C6118: D5207C06 000A0C05
	v_dual_mov_b32 v20, v13 :: v_dual_mov_b32 v23, v18         // 0000007C6120: CA10010D 14160112
	.long 0xd700020e                                           // 0000007C6128: D700020E
	v_cndmask_b32_e32 v0, v5, v160, vcc_lo                     // 0000007C612C: 02014105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C6130: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s2                   // 0000007C6134: D5207C0F 000A0C80
	v_mov_b32_e32 v19, v13                                     // 0000007C613C: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 0000007C6140: 7E22030D
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000007C6144: 8484820A
	s_mov_b32 s16, 0                                           // 0000007C6148: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000007C614C: 848A810A
	s_branch 270                                               // 0000007C6150: BFA0010E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x68c>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000007C6154: 8C7E117E
	.long 0xd73c0018                                           // 0000007C6158: D73C0018
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000007C615C: 02021881
	v_and_b32_e32 v72, 0xff, v1                                // 0000007C6160: 369002FF 000000FF
	v_lshrrev_b32_e32 v73, 6, v1                               // 0000007C6168: 32920286
	v_lshrrev_b32_e32 v74, 14, v1                              // 0000007C616C: 3294028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000007C6170: 32020296
	v_and_b32_e32 v75, 0xff, v2                                // 0000007C6174: 369604FF 000000FF
	.long 0xd700033c                                           // 0000007C617C: D700033C
	v_cndmask_b32_e32 v1, s6, v24, vcc_lo                      // 0000007C6180: 02023006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C6184: BF8701A1
	v_add_co_ci_u32_e64 v61, null, s7, v25, s3                 // 0000007C6188: D5207C3D 000E3207
	v_lshlrev_b32_e32 v72, 2, v72                              // 0000007C6190: 30909082
	.long 0xd7000340                                           // 0000007C6194: D7000340
	v_cndmask_b32_e32 v0, v60, v10, vcc_lo                     // 0000007C6198: 0200153C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C619C: BF8700A1
	v_add_co_ci_u32_e64 v65, null, s11, v61, s3                // 0000007C61A0: D5207C41 000E7A0B
	.long 0xd7000344                                           // 0000007C61A8: D7000344
	v_cndmask_b32_e32 v0, v60, v4, vcc_lo                      // 0000007C61AC: 0200093C
	v_add_co_ci_u32_e64 v69, null, s5, v61, s3                 // 0000007C61B0: D5207C45 000E7A05
	s_clause 0xb                                               // 0000007C61B8: BF85000B
	global_load_b128 v[24:27], v[60:61], off                   // 0000007C61BC: DC5E0000 187C003C
	global_load_b128 v[28:31], v[64:65], off                   // 0000007C61C4: DC5E0000 1C7C0040
	global_load_b128 v[32:35], v[68:69], off                   // 0000007C61CC: DC5E0000 207C0044
	global_load_b128 v[36:39], v[60:61], off offset:16         // 0000007C61D4: DC5E0010 247C003C
	global_load_b128 v[40:43], v[64:65], off offset:16         // 0000007C61DC: DC5E0010 287C0040
	global_load_b128 v[44:47], v[68:69], off offset:16         // 0000007C61E4: DC5E0010 2C7C0044
	global_load_b128 v[48:51], v[60:61], off offset:32         // 0000007C61EC: DC5E0020 307C003C
	global_load_b128 v[52:55], v[64:65], off offset:32         // 0000007C61F4: DC5E0020 347C0040
	global_load_b128 v[56:59], v[68:69], off offset:32         // 0000007C61FC: DC5E0020 387C0044
	global_load_b128 v[60:63], v[60:61], off offset:48         // 0000007C6204: DC5E0030 3C7C003C
	global_load_b128 v[64:67], v[64:65], off offset:48         // 0000007C620C: DC5E0030 407C0040
	global_load_b128 v[68:71], v[68:69], off offset:48         // 0000007C6214: DC5E0030 447C0044
	v_and_b32_e32 v73, 0x3fc, v73                              // 0000007C621C: 369292FF 000003FC
	ds_load_b32 v72, v72                                       // 0000007C6224: D8D80000 48000048
	v_and_b32_e32 v74, 0x3fc, v74                              // 0000007C622C: 369494FF 000003FC
	v_lshrrev_b32_e32 v76, 6, v2                               // 0000007C6234: 32980486
	v_lshrrev_b32_e32 v77, 14, v2                              // 0000007C6238: 329A048E
	ds_load_b32 v73, v73                                       // 0000007C623C: D8D80000 49000049
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000007C6244: 32040496
	ds_load_b32 v74, v74                                       // 0000007C6248: D8D80000 4A00004A
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C6250: 360202FF 000003FC
	v_lshlrev_b32_e32 v75, 2, v75                              // 0000007C6258: 30969682
	v_and_b32_e32 v76, 0x3fc, v76                              // 0000007C625C: 369898FF 000003FC
	v_and_b32_e32 v77, 0x3fc, v77                              // 0000007C6264: 369A9AFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000007C626C: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000007C6274: D8D80000 01000001
	ds_load_b32 v75, v75                                       // 0000007C627C: D8D80000 4B00004B
	ds_load_b32 v76, v76                                       // 0000007C6284: D8D80000 4C00004C
	ds_load_b32 v77, v77                                       // 0000007C628C: D8D80000 4D00004D
	ds_load_b32 v2, v2                                         // 0000007C6294: D8D80000 02000002
	v_and_b32_e32 v78, 0xff, v3                                // 0000007C629C: 369C06FF 000000FF
	v_lshrrev_b32_e32 v79, 6, v3                               // 0000007C62A4: 329E0686
	v_lshrrev_b32_e32 v80, 14, v3                              // 0000007C62A8: 32A0068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000007C62AC: 32060696
	v_and_b32_e32 v81, 0xff, v4                                // 0000007C62B0: 36A208FF 000000FF
	v_lshrrev_b32_e32 v82, 14, v4                              // 0000007C62B8: 32A4088E
	s_and_b32 s3, exec_lo, s2                                  // 0000007C62BC: 8B03027E
	.long 0xd700020e                                           // 0000007C62C0: D700020E
	v_cndmask_b32_e32 v0, v14, v160, vcc_lo                    // 0000007C62C4: 0201410E
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000007C62C8: 360606FF 000003FC
	v_add_nc_u32_e32 v12, 0x200, v12                           // 0000007C62D0: 4A1818FF 00000200
	v_add_nc_u32_e32 v21, 0x100, v21                           // 0000007C62D8: 4A2A2AFF 00000100
	v_add_co_ci_u32_e64 v15, null, 0, v15, s2                  // 0000007C62E0: D5207C0F 000A1E80
	s_or_b32 s16, s3, s16                                      // 0000007C62E8: 8C101003
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 0000007C62EC: BF892C77
	v_dot2_f32_bf16 v24, v24, v72, 0                           // 0000007C62F0: CC1A4018 1A029118
	s_waitcnt vmcnt(10)                                        // 0000007C62F8: BF892BF7
	v_dot2_f32_bf16 v28, v28, v72, 0                           // 0000007C62FC: CC1A401C 1A02911C
	s_waitcnt vmcnt(9)                                         // 0000007C6304: BF8927F7
	v_dot2_f32_bf16 v32, v32, v72, 0                           // 0000007C6308: CC1A4020 1A029120
	v_lshrrev_b32_e32 v72, 6, v4                               // 0000007C6310: 32900886
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000007C6314: 32080896
	s_waitcnt lgkmcnt(6)                                       // 0000007C6318: BF89FC67
	v_dot2_f32_bf16 v24, v25, v73, v24                         // 0000007C631C: CC1A4018 1C629319
	v_dot2_f32_bf16 v25, v29, v73, v28                         // 0000007C6324: CC1A4019 1C72931D
	v_dot2_f32_bf16 v28, v33, v73, v32                         // 0000007C632C: CC1A401C 1C829321
	v_lshlrev_b32_e32 v29, 2, v78                              // 0000007C6334: 303A9C82
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007C6338: 360808FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000007C6340: BF89FC57
	v_dot2_f32_bf16 v24, v26, v74, v24                         // 0000007C6344: CC1A4018 1C62951A
	v_dot2_f32_bf16 v25, v30, v74, v25                         // 0000007C634C: CC1A4019 1C66951E
	v_dot2_f32_bf16 v26, v34, v74, v28                         // 0000007C6354: CC1A401A 1C729522
	v_and_b32_e32 v28, 0x3fc, v79                              // 0000007C635C: 36389EFF 000003FC
	v_and_b32_e32 v30, 0x3fc, v80                              // 0000007C6364: 363CA0FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000007C636C: BF89FC47
	v_dot2_f32_bf16 v24, v27, v1, v24                          // 0000007C6370: CC1A4018 1C62031B
	v_dot2_f32_bf16 v25, v31, v1, v25                          // 0000007C6378: CC1A4019 1C66031F
	v_dot2_f32_bf16 v1, v35, v1, v26                           // 0000007C6380: CC1A4001 1C6A0323
	ds_load_b32 v27, v29                                       // 0000007C6388: D8D80000 1B00001D
	ds_load_b32 v30, v30                                       // 0000007C6390: D8D80000 1E00001E
	ds_load_b32 v28, v28                                       // 0000007C6398: D8D80000 1C00001C
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 0000007C63A0: BF892067
	v_dot2_f32_bf16 v24, v36, v75, v24                         // 0000007C63A4: CC1A4018 1C629724
	s_waitcnt vmcnt(7)                                         // 0000007C63AC: BF891FF7
	v_dot2_f32_bf16 v25, v40, v75, v25                         // 0000007C63B0: CC1A4019 1C669728
	s_waitcnt vmcnt(6)                                         // 0000007C63B8: BF891BF7
	v_dot2_f32_bf16 v1, v44, v75, v1                           // 0000007C63BC: CC1A4001 1C06972C
	v_lshlrev_b32_e32 v26, 2, v81                              // 0000007C63C4: 3034A282
	v_and_b32_e32 v29, 0x3fc, v72                              // 0000007C63C8: 363A90FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000007C63D0: BF89FC57
	v_dot2_f32_bf16 v24, v37, v76, v24                         // 0000007C63D4: CC1A4018 1C629925
	v_dot2_f32_bf16 v25, v41, v76, v25                         // 0000007C63DC: CC1A4019 1C669929
	v_dot2_f32_bf16 v1, v45, v76, v1                           // 0000007C63E4: CC1A4001 1C06992D
	v_and_b32_e32 v31, 0x3fc, v82                              // 0000007C63EC: 363EA4FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000007C63F4: BF89FC47
	v_dot2_f32_bf16 v24, v38, v77, v24                         // 0000007C63F8: CC1A4018 1C629B26
	v_dot2_f32_bf16 v25, v42, v77, v25                         // 0000007C6400: CC1A4019 1C669B2A
	v_dot2_f32_bf16 v1, v46, v77, v1                           // 0000007C6408: CC1A4001 1C069B2E
	s_waitcnt lgkmcnt(3)                                       // 0000007C6410: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C6414: BF870193
	v_dot2_f32_bf16 v24, v39, v2, v24                          // 0000007C6418: CC1A4018 1C620527
	v_dot2_f32_bf16 v25, v43, v2, v25                          // 0000007C6420: CC1A4019 1C66052B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C6428: BF870003
	v_dot2_f32_bf16 v1, v47, v2, v1                            // 0000007C642C: CC1A4001 1C06052F
	ds_load_b32 v2, v3                                         // 0000007C6434: D8D80000 02000003
	ds_load_b32 v3, v26                                        // 0000007C643C: D8D80000 0300001A
	ds_load_b32 v26, v29                                       // 0000007C6444: D8D80000 1A00001D
	ds_load_b32 v29, v31                                       // 0000007C644C: D8D80000 1D00001F
	ds_load_b32 v31, v4                                        // 0000007C6454: D8D80000 1F000004
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 0000007C645C: BF891477
	v_dot2_f32_bf16 v4, v48, v27, v24                          // 0000007C6460: CC1A4004 1C623730
	s_waitcnt vmcnt(4)                                         // 0000007C6468: BF8913F7
	v_dot2_f32_bf16 v24, v52, v27, v25                         // 0000007C646C: CC1A4018 1C663734
	s_waitcnt vmcnt(3)                                         // 0000007C6474: BF890FF7
	v_dot2_f32_bf16 v1, v56, v27, v1                           // 0000007C6478: CC1A4001 1C063738
	s_waitcnt lgkmcnt(5)                                       // 0000007C6480: BF89FC57
	v_dot2_f32_bf16 v4, v49, v28, v4                           // 0000007C6484: CC1A4004 1C123931
	v_dot2_f32_bf16 v24, v53, v28, v24                         // 0000007C648C: CC1A4018 1C623935
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C6494: BF870193
	v_dot2_f32_bf16 v1, v57, v28, v1                           // 0000007C6498: CC1A4001 1C063939
	v_dot2_f32_bf16 v4, v50, v30, v4                           // 0000007C64A0: CC1A4004 1C123D32
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C64A8: BF870193
	v_dot2_f32_bf16 v24, v54, v30, v24                         // 0000007C64AC: CC1A4018 1C623D36
	v_dot2_f32_bf16 v1, v58, v30, v1                           // 0000007C64B4: CC1A4001 1C063D3A
	s_waitcnt lgkmcnt(4)                                       // 0000007C64BC: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C64C0: BF870193
	v_dot2_f32_bf16 v4, v51, v2, v4                            // 0000007C64C4: CC1A4004 1C120533
	v_dot2_f32_bf16 v24, v55, v2, v24                          // 0000007C64CC: CC1A4018 1C620537
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C64D4: BF8701A3
	v_dot2_f32_bf16 v1, v59, v2, v1                            // 0000007C64D8: CC1A4001 1C06053B
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000007C64E0: BF890837
	v_dot2_f32_bf16 v2, v60, v3, v4                            // 0000007C64E4: CC1A4002 1C12073C
	s_waitcnt vmcnt(1)                                         // 0000007C64EC: BF8907F7
	v_dot2_f32_bf16 v4, v64, v3, v24                           // 0000007C64F0: CC1A4004 1C620740
	s_waitcnt vmcnt(0)                                         // 0000007C64F8: BF8903F7
	v_dot2_f32_bf16 v1, v68, v3, v1                            // 0000007C64FC: CC1A4001 1C060744
	s_waitcnt lgkmcnt(2)                                       // 0000007C6504: BF89FC27
	v_dot2_f32_bf16 v2, v61, v26, v2                           // 0000007C6508: CC1A4002 1C0A353D
	v_dot2_f32_bf16 v3, v65, v26, v4                           // 0000007C6510: CC1A4003 1C123541
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C6518: BF870003
	v_dot2_f32_bf16 v1, v69, v26, v1                           // 0000007C651C: CC1A4001 1C063545
	v_mov_b32_e32 v4, v8                                       // 0000007C6524: 7E080308
	s_waitcnt lgkmcnt(1)                                       // 0000007C6528: BF89FC17
	v_dot2_f32_bf16 v2, v62, v29, v2                           // 0000007C652C: CC1A4002 1C0A3B3E
	v_dot2_f32_bf16 v24, v66, v29, v3                          // 0000007C6534: CC1A4018 1C0E3B42
	v_dot2_f32_bf16 v1, v70, v29, v1                           // 0000007C653C: CC1A4001 1C063B46
	v_mov_b32_e32 v3, v7                                       // 0000007C6544: 7E060307
	s_waitcnt lgkmcnt(0)                                       // 0000007C6548: BF89FC07
	v_dot2_f32_bf16 v7, v63, v31, v2                           // 0000007C654C: CC1A4007 1C0A3F3F
	v_dot2_f32_bf16 v8, v67, v31, v24                          // 0000007C6554: CC1A4008 1C623F43
	v_dot2_f32_bf16 v24, v71, v31, v1                          // 0000007C655C: CC1A4018 1C063F47
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 0000007C6564: CA100106 02000105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007C656C: BF870214
	v_fmac_f32_e32 v20, v18, v7                                // 0000007C6570: 56280F12
	v_fmac_f32_e32 v19, v18, v8                                // 0000007C6574: 56261112
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007C6578: BF870004
	v_dual_fmac_f32 v17, v18, v24 :: v_dual_mov_b32 v18, v23   // 0000007C657C: C8103112 11120117
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000007C6584: 917E107E
	s_cbranch_execz 25                                         // 0000007C6588: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x6f0>
	s_waitcnt vmcnt(0)                                         // 0000007C658C: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v22, 16, v22    // 0000007C6590: CA200101 05162C90
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 0000007C6598: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 0000007C65A0: 7E100304
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C65A4: BF870003
	.long 0xd4430002                                           // 0000007C65A8: D4430002
	v_cndmask_b32_e32 v1, s14, v22, vcc_lo                     // 0000007C65AC: 02022C0E
	s_mov_b32 s17, exec_lo                                     // 0000007C65B0: BE91007E
	.long 0xd4c4007e                                           // 0000007C65B4: D4C4007E
	v_cndmask_b32_e32 v1, s14, v22, vcc_lo                     // 0000007C65B8: 02022C0E
	s_cbranch_execz 65253                                      // 0000007C65BC: BFA5FEE5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x254>
	.long 0xd7000305                                           // 0000007C65C0: D7000305
	v_cndmask_b32_e32 v1, v11, v21, vcc_lo                     // 0000007C65C4: 02022B0B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C65C8: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s3                    // 0000007C65CC: D5207C06 000E0080
	global_load_d16_b16 v23, v[14:15], off                     // 0000007C65D4: DC820000 177C000E
	global_load_b128 v[5:8], v[5:6], off                       // 0000007C65DC: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 0000007C65E4: BF8907F7
	v_cvt_f32_f16_e32 v23, v23                                 // 0000007C65E8: 7E2E1717
	s_branch 65241                                             // 0000007C65EC: BFA0FED9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x254>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000007C65F0: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C65F4: BF8700B9
	s_or_b32 exec_lo, exec_lo, s15                             // 0000007C65F8: 8C7E0F7E
	.long 0xd71f0000                                           // 0000007C65FC: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007C6600: 020100C1
	s_waitcnt vmcnt(0)                                         // 0000007C6604: BF8903F7
	v_xor_b32_e32 v1, 8, v0                                    // 0000007C6608: 3A020088
	v_xor_b32_e32 v4, 4, v0                                    // 0000007C660C: 3A080084
	v_xor_b32_e32 v7, 2, v0                                    // 0000007C6610: 3A0E0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C6614: BF870093
	.long 0xd44c0002                                           // 0000007C6618: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000007C661C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 0000007C6620: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C6628: BF870114
	.long 0xd44c0002                                           // 0000007C662C: D44C0002
	v_cndmask_b32_e32 v1, 32, v4, vcc_lo                       // 0000007C6630: 020208A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007C6634: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C6638: BF870002
	v_cndmask_b32_e64 v4, v0, v4, s2                           // 0000007C663C: D5010004 000A0900
	.long 0xd44c0002                                           // 0000007C6644: D44C0002
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 0000007C6648: 02020EA0
	ds_bpermute_b32 v2, v1, v20                                // 0000007C664C: DACC0000 02001401
	v_cndmask_b32_e64 v7, v0, v7, s2                           // 0000007C6654: D5010007 000A0F00
	s_waitcnt lgkmcnt(0)                                       // 0000007C665C: BF89FC07
	v_add_f32_e32 v2, v20, v2                                  // 0000007C6660: 06040514
	ds_bpermute_b32 v3, v1, v19                                // 0000007C6664: DACC0000 03001301
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007C666C: 30080882
	ds_bpermute_b32 v1, v1, v17                                // 0000007C6670: DACC0000 01001101
	s_waitcnt lgkmcnt(1)                                       // 0000007C6678: BF89FC17
	v_add_f32_e32 v3, v19, v3                                  // 0000007C667C: 06060713
	ds_bpermute_b32 v5, v4, v2                                 // 0000007C6680: DACC0000 05000204
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000007C6688: 300E0E82
	ds_bpermute_b32 v6, v4, v3                                 // 0000007C668C: DACC0000 06000304
	s_waitcnt lgkmcnt(1)                                       // 0000007C6694: BF89FC17
	v_add_f32_e32 v2, v2, v5                                   // 0000007C6698: 06040B02
	v_add_f32_e32 v1, v17, v1                                  // 0000007C669C: 06020311
	s_waitcnt lgkmcnt(0)                                       // 0000007C66A0: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 0000007C66A4: 06060D03
	ds_bpermute_b32 v4, v4, v1                                 // 0000007C66A8: DACC0000 04000104
	ds_bpermute_b32 v5, v7, v3                                 // 0000007C66B0: DACC0000 05000307
	s_waitcnt lgkmcnt(1)                                       // 0000007C66B8: BF89FC17
	v_add_f32_e32 v1, v1, v4                                   // 0000007C66BC: 06020901
	ds_bpermute_b32 v4, v7, v2                                 // 0000007C66C0: DACC0000 04000207
	s_waitcnt lgkmcnt(0)                                       // 0000007C66C8: BF89FC07
	v_add_f32_e32 v4, v2, v4                                   // 0000007C66CC: 06080902
	v_add_f32_e32 v2, v3, v5                                   // 0000007C66D0: 06040B03
	ds_bpermute_b32 v6, v7, v1                                 // 0000007C66D4: DACC0000 06000107
	v_xor_b32_e32 v7, 1, v0                                    // 0000007C66DC: 3A0E0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C66E0: BF870091
	.long 0xd44c0002                                           // 0000007C66E4: D44C0002
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 0000007C66E8: 02020EA0
	v_cndmask_b32_e64 v0, v0, v7, s2                           // 0000007C66EC: D5010000 000A0F00
	.long 0xd44a0002                                           // 0000007C66F4: D44A0002
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 0000007C66F8: 02022080
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C66FC: BF870002
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000007C6700: 300E0082
	s_and_b32 s2, s2, vcc_lo                                   // 0000007C6704: 8B026A02
	s_waitcnt lgkmcnt(0)                                       // 0000007C6708: BF89FC07
	v_add_f32_e32 v0, v1, v6                                   // 0000007C670C: 06000D01
	ds_bpermute_b32 v5, v7, v4                                 // 0000007C6710: DACC0000 05000407
	ds_bpermute_b32 v3, v7, v2                                 // 0000007C6718: DACC0000 03000207
	ds_bpermute_b32 v1, v7, v0                                 // 0000007C6720: DACC0000 01000007
	s_and_saveexec_b32 s3, s2                                  // 0000007C6728: BE832002
	s_cbranch_execz 163                                        // 0000007C672C: BFA500A3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0xabc>
	s_waitcnt lgkmcnt(2)                                       // 0000007C6730: BF89FC27
	v_add_f32_e32 v4, v4, v5                                   // 0000007C6734: 06080B04
	.long 0x7f0a3880                                           // 0000007C6738: 7F0A3880
	s_waitcnt lgkmcnt(1)                                       // 0000007C673C: BF89FC17
	v_add_f32_e32 v2, v2, v3                                   // 0000007C6740: 06040702
	s_load_b32 s0, s[0:1], 0x48                                // 0000007C6744: F4000000 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000007C674C: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 0000007C6750: 06000300
	.long 0x7e063984                                           // 0000007C6754: 7E063984
	.long 0x7f063985                                           // 0000007C6758: 7F063985
	s_lshl_b64 s[2:3], s[12:13], 1                             // 0000007C675C: 8482810C
	s_lshl_b64 s[4:5], s[12:13], 2                             // 0000007C6760: 8484820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C6764: BF870121
	v_and_b32_e32 v1, 1, v3                                    // 0000007C6768: 36020681
	v_bfe_u32 v3, v0, 16, 1                                    // 0000007C676C: D6100003 02052100
	v_add3_u32 v1, v4, v1, 0x7fff                              // 0000007C6774: D6550001 03FE0304 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C6780: BF870112
	v_add3_u32 v0, v0, v3, 0x7fff                              // 0000007C6784: D6550000 03FE0700 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007C6790: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C6798: BF870122
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007C679C: 360000FF FFFF0000
	.long 0x7e0a3982                                           // 0000007C67A4: 7E0A3982
	v_dual_mul_f32 v3, s0, v1 :: v_dual_mul_f32 v4, s0, v0     // 0000007C67A8: C8C60200 03040000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C67B0: BF870091
	v_dual_mul_f32 v0, 0xbfb8aa3b, v3 :: v_dual_mul_f32 v1, 0xbfb8aa3b, v4// 0000007C67B4: C8C606FF 000008FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000007C67C0: 7E004B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000007C67C4: BF870311
	v_exp_f32_e32 v1, v1                                       // 0000007C67C8: 7E024B01
	v_dual_add_f32 v7, 1.0, v0 :: v_dual_and_b32 v6, 1, v5     // 0000007C67CC: C92400F2 07060A81
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C67D4: BF870115
	v_add_f32_e32 v8, 1.0, v1                                  // 0000007C67D8: 061002F2
	v_add3_u32 v2, v2, v6, 0x7fff                              // 0000007C67DC: D6550002 03FE0D02 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C67E8: BF870193
	v_div_scale_f32 v11, null, v7, v7, v3                      // 0000007C67EC: D6FC7C0B 040E0F07
	v_div_scale_f32 v12, null, v8, v8, v4                      // 0000007C67F4: D6FC7C0C 04121108
	v_div_scale_f32 v19, vcc_lo, v3, v7, v3                    // 0000007C67FC: D6FC6A13 040E0F03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C6804: BF870113
	v_rcp_f32_e32 v14, v11                                     // 0000007C6808: 7E1C550B
	v_rcp_f32_e32 v15, v12                                     // 0000007C680C: 7E1E550C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007C6810: BF870296
	v_fma_f32 v0, -v11, v14, 1.0                               // 0000007C6814: D6130000 23CA1D0B
	v_fma_f32 v1, -v12, v15, 1.0                               // 0000007C681C: D6130001 23CA1F0C
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000007C6824: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C682C: BF870112
	v_dual_fmac_f32 v14, v0, v14 :: v_dual_fmac_f32 v15, v1, v15// 0000007C6830: C8001D00 0E0E1F01
	v_mul_f32_e32 v2, s0, v2                                   // 0000007C6838: 10040400
	v_div_scale_f32 v17, s0, v4, v8, v4                        // 0000007C683C: D6FC0011 04121104
	.long 0xd73c0000                                           // 0000007C6844: D73C0000
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000007C6848: 02021281
	.long 0x7f123985                                           // 0000007C684C: 7F123985
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C6850: BF870093
	v_mul_f32_e32 v21, v17, v15                                // 0000007C6854: 102A1F11
	v_fma_f32 v24, -v12, v21, v17                              // 0000007C6858: D6130018 24462B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C6860: BF870091
	v_dual_fmac_f32 v21, v24, v15 :: v_dual_mul_f32 v6, 0xbfb8aa3b, v2// 0000007C6864: C8061F18 150604FF BFB8AA3B
	v_exp_f32_e32 v6, v6                                       // 0000007C6870: 7E0C4B06
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C6874: BF870095
	v_add_f32_e32 v6, 1.0, v6                                  // 0000007C6878: 060C0CF2
	v_div_scale_f32 v13, null, v6, v6, v2                      // 0000007C687C: D6FC7C0D 040A0D06
	v_div_scale_f32 v20, s1, v2, v6, v2                        // 0000007C6884: D6FC0114 040A0D02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007C688C: BF870292
	v_rcp_f32_e32 v16, v13                                     // 0000007C6890: 7E20550D
	v_fma_f32 v18, -v13, v16, 1.0                              // 0000007C6894: D6130012 23CA210D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C689C: BF870121
	v_fmac_f32_e32 v16, v18, v16                               // 0000007C68A0: 56202112
	v_mul_f32_e32 v18, v19, v14                                // 0000007C68A4: 10241D13
	v_mul_f32_e32 v22, v20, v16                                // 0000007C68A8: 102C2114
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C68AC: BF870112
	v_fma_f32 v23, -v11, v18, v19                              // 0000007C68B0: D6130017 244E250B
	v_fma_f32 v25, -v13, v22, v20                              // 0000007C68B8: D6130019 24522D0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C68C0: BF870112
	v_fmac_f32_e32 v18, v23, v14                               // 0000007C68C4: 56241D17
	v_fmac_f32_e32 v22, v25, v16                               // 0000007C68C8: 562C2119
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C68CC: BF8701A2
	v_fma_f32 v10, -v11, v18, v19                              // 0000007C68D0: D613000A 244E250B
	v_fma_f32 v11, -v12, v21, v17                              // 0000007C68D8: D613000B 24462B0C
	v_fma_f32 v12, -v13, v22, v20                              // 0000007C68E0: D613000C 24522D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C68E8: BF870123
	v_div_fmas_f32 v10, v10, v14, v18                          // 0000007C68EC: D637000A 044A1D0A
	s_mov_b32 vcc_lo, s1                                       // 0000007C68F4: BEEA0001
	v_div_fmas_f32 v12, v12, v16, v22                          // 0000007C68F8: D637000C 045A210C
	s_mov_b32 vcc_lo, s0                                       // 0000007C6900: BEEA0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000007C6904: BF870242
	v_div_fixup_f32 v7, v10, v7, v3                            // 0000007C6908: D6270007 040E0F0A
	v_div_fmas_f32 v11, v11, v15, v21                          // 0000007C6910: D637000B 04561F0B
	.long 0xd7006a00                                           // 0000007C6918: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007C691C: 02020008
	v_div_fixup_f32 v6, v12, v6, v2                            // 0000007C6920: D6270006 040A0D0C
	.long 0x7e123987                                           // 0000007C6928: 7E123987
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007C692C: BF870224
	v_div_fixup_f32 v8, v11, v8, v4                            // 0000007C6930: D6270008 0412110B
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007C6938: D5207C01 01AA0209
	.long 0x7e0a3986                                           // 0000007C6940: 7E0A3986
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007C6944: BF870214
	v_and_b32_e32 v9, 1, v9                                    // 0000007C6948: 36121281
	v_bfe_u32 v10, v8, 16, 1                                   // 0000007C694C: D610000A 02052108
	.long 0xd7006a02                                           // 0000007C6954: D7006A02
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 0000007C6958: 02000500
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000007C695C: BF870244
	v_and_b32_e32 v11, 1, v5                                   // 0000007C6960: 36160A81
	v_add_co_ci_u32_e64 v3, null, s3, v1, vcc_lo               // 0000007C6964: D5207C03 01AA0203
	.long 0xd7006a04                                           // 0000007C696C: D7006A04
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 0000007C6970: 02000900
	v_add3_u32 v7, v7, v9, 0x7fff                              // 0000007C6974: D6550007 03FE1307 00007FFF
	v_add3_u32 v6, v6, v11, 0x7fff                             // 0000007C6980: D6550006 03FE1706 00007FFF
	v_add_co_ci_u32_e64 v5, null, s5, v1, vcc_lo               // 0000007C698C: D5207C05 01AA0205
	v_add3_u32 v8, v8, v10, 0x7fff                             // 0000007C6994: D6550008 03FE1508 00007FFF
	s_clause 0x2                                               // 0000007C69A0: BF850002
	global_store_d16_hi_b16 v[0:1], v7, off                    // 0000007C69A4: DC960000 007C0700
	global_store_d16_hi_b16 v[2:3], v6, off                    // 0000007C69AC: DC960000 007C0602
	global_store_d16_hi_b16 v[4:5], v8, off                    // 0000007C69B4: DC960000 007C0804
	s_endpgm                                                   // 0000007C69BC: BFB00000
		...

