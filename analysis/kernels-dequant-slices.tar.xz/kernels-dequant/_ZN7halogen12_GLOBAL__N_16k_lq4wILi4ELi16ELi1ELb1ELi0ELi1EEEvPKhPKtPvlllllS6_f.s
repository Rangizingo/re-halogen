000000000074aa00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000074AA00: F4100100 F8000000
	v_and_b32_e32 v23, 15, v0                                  // 00000074AA08: 362E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000074AA0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 00000074AA10: 86039F02
	v_lshlrev_b32_e32 v0, 2, v0                                // 00000074AA14: 30000082
	s_lshl_b64 s[0:1], s[2:3], 4                               // 00000074AA18: 84808402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000074AA1C: BF870009
	v_dual_mov_b32 v17, s1 :: v_dual_lshlrev_b32 v2, 2, v23    // 00000074AA20: CA220001 11022E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 00000074AA28: 30060282
	v_or_b32_e32 v16, s0, v1                                   // 00000074AA2C: 38200200
	.long 0x7f023880                                           // 00000074AA30: 7F023880
	s_waitcnt lgkmcnt(0)                                       // 00000074AA34: BF89FC07
	s_clause 0x1                                               // 00000074AA38: BF850001
	global_load_b32 v2, v2, s[4:5]                             // 00000074AA3C: DC520000 02040002
	global_load_b32 v3, v3, s[4:5]                             // 00000074AA44: DC520000 03040003
	.long 0xd4540000                                           // 00000074AA4C: D4540000
	v_cndmask_b32_e32 v1, s12, v16, vcc_lo                     // 00000074AA50: 0202200C
	s_add_u32 s22, s4, s16                                     // 00000074AA54: 80161004
	s_addc_u32 s23, s5, s17                                    // 00000074AA58: 82171105
	s_ashr_i32 s2, s11, 31                                     // 00000074AA5C: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000074AA60: BF870159
	s_lshr_b32 s2, s2, 27                                      // 00000074AA64: 85029B02
	v_cndmask_b32_e64 v10, 0, v16, s0                          // 00000074AA68: D501000A 00022080
	v_cndmask_b32_e64 v12, 0, s1, s0                           // 00000074AA70: D501000C 00000280
	s_add_u32 s2, s10, s2                                      // 00000074AA78: 8002020A
	s_addc_u32 s3, s11, 0                                      // 00000074AA7C: 8203800B
	.long 0xd72c0004                                           // 00000074AA80: D72C0004
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 00000074AA84: 02021413
	v_mad_u64_u32 v[8:9], null, s18, v10, 0                    // 00000074AA88: D6FE7C08 02021412
	s_lshr_b64 s[20:21], s[2:3], 5                             // 00000074AA90: 85948502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000074AA94: BF870009
	s_cmpk_lt_i32 s20, 0x81                                    // 00000074AA98: B3940081
	.long 0xd4440002                                           // 00000074AA9C: D4440002
	v_cndmask_b32_e32 v1, s20, v23, vcc_lo                     // 00000074AAA0: 02022E14
	s_cselect_b32 s1, -1, 0                                    // 00000074AAA4: 980180C1
	s_cmpk_gt_i32 s20, 0x80                                    // 00000074AAA8: B2940080
	.long 0xd700030b                                           // 00000074AAAC: D700030B
	v_cndmask_b32_e32 v1, s22, v8, vcc_lo                      // 00000074AAB0: 02021016
	s_waitcnt vmcnt(1)                                         // 00000074AAB4: BF8907F7
	v_bfe_u32 v5, v2, 16, 1                                    // 00000074AAB8: D6100005 02052102
	s_waitcnt vmcnt(0)                                         // 00000074AAC0: BF8903F7
	v_bfe_u32 v6, v3, 16, 1                                    // 00000074AAC4: D6100006 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000074AACC: BF8701A2
	v_add3_u32 v2, v2, v5, 0x7fff                              // 00000074AAD0: D6550002 03FE0B02 00007FFF
	.long 0xd72c0005                                           // 00000074AADC: D72C0005
	v_cndmask_b32_e32 v1, s18, v12, vcc_lo                     // 00000074AAE0: 02021812
	v_add3_u32 v3, v3, v6, 0x7fff                              // 00000074AAE4: D6550003 03FE0D03 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 00000074AAF0: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000074AAF4: BF8701A9
	s_and_b32 vcc_lo, exec_lo, s18                             // 00000074AAF8: 8B6A127E
	.long 0x7e023982                                           // 00000074AAFC: 7E023982
	v_add3_u32 v9, v9, v5, v4                                  // 00000074AB00: D6550009 04120B09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000074AB08: BF870112
	v_and_or_b32 v1, 0xffff0000, v3, v1                        // 00000074AB0C: D6570001 040606FF FFFF0000
	v_add_co_ci_u32_e64 v20, null, s23, v9, s3                 // 00000074AB18: D5207C14 000E1217
	ds_store_b32 v0, v1                                        // 00000074AB20: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 00000074AB28: BF89FC07
	s_barrier                                                  // 00000074AB2C: BFBD0000
	buffer_gl0_inv                                             // 00000074AB30: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 00000074AB38: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x37c>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 00000074AB3C: CA100080 01000080
	s_and_saveexec_b32 s3, s2                                  // 00000074AB44: BE832002
	s_cbranch_execz 10                                         // 00000074AB48: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x174>
	v_lshlrev_b32_e32 v0, 1, v23                               // 00000074AB4C: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074AB50: BF870091
	.long 0xd7006a02                                           // 00000074AB54: D7006A02
	v_cndmask_b32_e32 v1, v11, v0, vcc_lo                      // 00000074AB58: 0202010B
	v_add_co_ci_u32_e64 v3, null, 0, v20, vcc_lo               // 00000074AB5C: D5207C03 01AA2880
	global_load_d16_b16 v0, v[2:3], off                        // 00000074AB64: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 00000074AB6C: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 00000074AB70: 7E001700
	s_or_b32 exec_lo, exec_lo, s3                              // 00000074AB74: 8C7E037E
	v_or_b32_e32 v2, 16, v23                                   // 00000074AB78: 38042E90
	s_mov_b32 s2, exec_lo                                      // 00000074AB7C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074AB80: BF870001
	.long 0xd4c4007e                                           // 00000074AB84: D4C4007E
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 00000074AB88: 02020414
	s_cbranch_execz 10                                         // 00000074AB8C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1b8>
	v_lshlrev_b32_e32 v1, 1, v2                                // 00000074AB90: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074AB94: BF870091
	.long 0xd7006a01                                           // 00000074AB98: D7006A01
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 00000074AB9C: 0202030B
	v_add_co_ci_u32_e64 v2, null, 0, v20, vcc_lo               // 00000074ABA0: D5207C02 01AA2880
	global_load_d16_b16 v1, v[1:2], off                        // 00000074ABA8: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000074ABB0: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 00000074ABB4: 7E021701
	s_or_b32 exec_lo, exec_lo, s2                              // 00000074ABB8: 8C7E027E
	v_or_b32_e32 v4, 32, v23                                   // 00000074ABBC: 38082EA0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 00000074ABC0: CA100080 03020080
	s_mov_b32 s2, exec_lo                                      // 00000074ABC8: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000074ABCC: BF870002
	.long 0xd4c4007e                                           // 00000074ABD0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 00000074ABD4: 02020814
	s_cbranch_execz 10                                         // 00000074ABD8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x204>
	v_lshlrev_b32_e32 v2, 1, v4                                // 00000074ABDC: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074ABE0: BF870091
	.long 0xd7006a04                                           // 00000074ABE4: D7006A04
	v_cndmask_b32_e32 v1, v11, v2, vcc_lo                      // 00000074ABE8: 0202050B
	v_add_co_ci_u32_e64 v5, null, 0, v20, vcc_lo               // 00000074ABEC: D5207C05 01AA2880
	global_load_d16_b16 v2, v[4:5], off                        // 00000074ABF4: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 00000074ABFC: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 00000074AC00: 7E041702
	s_or_b32 exec_lo, exec_lo, s2                              // 00000074AC04: 8C7E027E
	v_or_b32_e32 v4, 48, v23                                   // 00000074AC08: 38082EB0
	s_mov_b32 s2, exec_lo                                      // 00000074AC0C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074AC10: BF870001
	.long 0xd4c4007e                                           // 00000074AC14: D4C4007E
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 00000074AC18: 02020814
	s_cbranch_execz 10                                         // 00000074AC1C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x248>
	v_lshlrev_b32_e32 v3, 1, v4                                // 00000074AC20: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074AC24: BF870091
	.long 0xd7006a03                                           // 00000074AC28: D7006A03
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 00000074AC2C: 0202070B
	v_add_co_ci_u32_e64 v4, null, 0, v20, vcc_lo               // 00000074AC30: D5207C04 01AA2880
	global_load_d16_b16 v3, v[3:4], off                        // 00000074AC38: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000074AC40: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 00000074AC44: 7E061703
	s_or_b32 exec_lo, exec_lo, s2                              // 00000074AC48: 8C7E027E
	v_or_b32_e32 v6, 64, v23                                   // 00000074AC4C: 380C2EC0
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 00000074AC50: CA100080 05040080
	s_mov_b32 s2, exec_lo                                      // 00000074AC58: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000074AC5C: BF870002
	.long 0xd4c4007e                                           // 00000074AC60: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000074AC64: 02020C14
	s_cbranch_execz 10                                         // 00000074AC68: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x294>
	v_lshlrev_b32_e32 v4, 1, v6                                // 00000074AC6C: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074AC70: BF870091
	.long 0xd7006a06                                           // 00000074AC74: D7006A06
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 00000074AC78: 0202090B
	v_add_co_ci_u32_e64 v7, null, 0, v20, vcc_lo               // 00000074AC7C: D5207C07 01AA2880
	global_load_d16_b16 v4, v[6:7], off                        // 00000074AC84: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 00000074AC8C: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 00000074AC90: 7E081704
	s_or_b32 exec_lo, exec_lo, s2                              // 00000074AC94: 8C7E027E
	v_or_b32_e32 v6, 0x50, v23                                 // 00000074AC98: 380C2EFF 00000050
	s_mov_b32 s2, exec_lo                                      // 00000074ACA0: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074ACA4: BF870001
	.long 0xd4c4007e                                           // 00000074ACA8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000074ACAC: 02020C14
	s_cbranch_execz 10                                         // 00000074ACB0: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2dc>
	v_lshlrev_b32_e32 v5, 1, v6                                // 00000074ACB4: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074ACB8: BF870091
	.long 0xd7006a05                                           // 00000074ACBC: D7006A05
	v_cndmask_b32_e32 v1, v11, v5, vcc_lo                      // 00000074ACC0: 02020B0B
	v_add_co_ci_u32_e64 v6, null, 0, v20, vcc_lo               // 00000074ACC4: D5207C06 01AA2880
	global_load_d16_b16 v5, v[5:6], off                        // 00000074ACCC: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 00000074ACD4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 00000074ACD8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s2                              // 00000074ACDC: 8C7E027E
	v_or_b32_e32 v13, 0x60, v23                                // 00000074ACE0: 381A2EFF 00000060
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 00000074ACE8: CA100080 07060080
	s_mov_b32 s2, exec_lo                                      // 00000074ACF0: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000074ACF4: BF870002
	.long 0xd4c4007e                                           // 00000074ACF8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v13, vcc_lo                     // 00000074ACFC: 02021A14
	s_cbranch_execz 10                                         // 00000074AD00: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x32c>
	v_lshlrev_b32_e32 v6, 1, v13                               // 00000074AD04: 300C1A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074AD08: BF870091
	.long 0xd7006a0d                                           // 00000074AD0C: D7006A0D
	v_cndmask_b32_e32 v1, v11, v6, vcc_lo                      // 00000074AD10: 02020D0B
	v_add_co_ci_u32_e64 v14, null, 0, v20, vcc_lo              // 00000074AD14: D5207C0E 01AA2880
	global_load_d16_b16 v6, v[13:14], off                      // 00000074AD1C: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 00000074AD24: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 00000074AD28: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000074AD2C: 8C7E027E
	v_or_b32_e32 v13, 0x70, v23                                // 00000074AD30: 381A2EFF 00000070
	s_mov_b32 s2, exec_lo                                      // 00000074AD38: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074AD3C: BF870001
	.long 0xd4c4007e                                           // 00000074AD40: D4C4007E
	v_cndmask_b32_e32 v1, s20, v13, vcc_lo                     // 00000074AD44: 02021A14
	s_cbranch_execz 10                                         // 00000074AD48: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x374>
	v_lshlrev_b32_e32 v7, 1, v13                               // 00000074AD4C: 300E1A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074AD50: BF870091
	.long 0xd7006a0d                                           // 00000074AD54: D7006A0D
	v_cndmask_b32_e32 v1, v11, v7, vcc_lo                      // 00000074AD58: 02020F0B
	v_add_co_ci_u32_e64 v14, null, 0, v20, vcc_lo              // 00000074AD5C: D5207C0E 01AA2880
	global_load_d16_b16 v7, v[13:14], off                      // 00000074AD64: DC820000 077C000D
	s_waitcnt vmcnt(0)                                         // 00000074AD6C: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 00000074AD70: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s2                              // 00000074AD74: 8C7E027E
	s_branch 9                                                 // 00000074AD78: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3a0>
	v_mov_b32_e32 v0, 0                                        // 00000074AD7C: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074AD80: BF870001
	v_mov_b32_e32 v1, v0                                       // 00000074AD84: 7E020300
	v_mov_b32_e32 v2, v0                                       // 00000074AD88: 7E040300
	v_mov_b32_e32 v3, v0                                       // 00000074AD8C: 7E060300
	v_mov_b32_e32 v4, v0                                       // 00000074AD90: 7E080300
	v_mov_b32_e32 v5, v0                                       // 00000074AD94: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 00000074AD98: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 00000074AD9C: 7E0E0300
	s_add_u32 s2, s4, s14                                      // 00000074ADA0: 80020E04
	s_addc_u32 s3, s5, s15                                     // 00000074ADA4: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 00000074ADA8: 850E9F0B
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v13, 0             // 00000074ADAC: CA100080 1A0C0080
	s_add_u32 s14, s10, s14                                    // 00000074ADB4: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000074ADB8: 820F800B
	v_cndmask_b32_e64 v24, 0, 1, s18                           // 00000074ADBC: D5010018 00490280
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000074ADC4: 868E810E
	v_mov_b32_e32 v33, 0                                       // 00000074ADC8: 7E420280
	v_mad_u64_u32 v[18:19], null, v10, s14, s[2:3]             // 00000074ADCC: D6FE7C12 00081D0A
	.long 0xd72c000a                                           // 00000074ADD4: D72C000A
	v_cndmask_b32_e32 v0, v10, v15, vcc_lo                     // 00000074ADD8: 02001F0A
	.long 0xd72c000f                                           // 00000074ADDC: D72C000F
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 00000074ADE0: 02001D0C
	.long 0xd4440002                                           // 00000074ADE4: D4440002
	v_cndmask_b32_e32 v1, s20, v23, vcc_lo                     // 00000074ADE8: 02022E14
	v_mov_b32_e32 v12, 0                                       // 00000074ADEC: 7E180280
	v_mov_b32_e32 v14, 0                                       // 00000074ADF0: 7E1C0280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000074ADF4: BF870004
	v_add3_u32 v25, v15, v19, v10                              // 00000074ADF8: D6550019 042A270F
	v_mov_b32_e32 v15, 0                                       // 00000074AE00: 7E1E0280
	s_and_saveexec_b32 s3, s2                                  // 00000074AE04: BE832002
	s_cbranch_execz 21                                         // 00000074AE08: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x460>
	v_dual_mov_b32 v33, 0 :: v_dual_lshlrev_b32 v10, 4, v23    // 00000074AE0C: CA220080 210A2E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074AE14: BF870091
	.long 0xd7006a0c                                           // 00000074AE18: D7006A0C
	v_cndmask_b32_e32 v1, v18, v10, vcc_lo                     // 00000074AE1C: 02021512
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 00000074AE20: D5207C0D 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 00000074AE28: 916A127E
	global_load_b128 v[12:15], v[12:13], off                   // 00000074AE2C: DC5E0000 0C7C000C
	s_cbranch_vccnz 10                                         // 00000074AE34: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x460>
	v_lshlrev_b32_e32 v10, 1, v23                              // 00000074AE38: 30142E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074AE3C: BF870091
	.long 0xd7006a0a                                           // 00000074AE40: D7006A0A
	v_cndmask_b32_e32 v1, v11, v10, vcc_lo                     // 00000074AE44: 0202150B
	v_add_co_ci_u32_e64 v11, null, 0, v20, vcc_lo              // 00000074AE48: D5207C0B 01AA2880
	global_load_d16_b16 v10, v[10:11], off                     // 00000074AE50: DC820000 0A7C000A
	s_waitcnt vmcnt(0)                                         // 00000074AE58: BF8903F7
	v_cvt_f32_f16_e32 v33, v10                                 // 00000074AE5C: 7E42170A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000074AE60: 8C7E037E
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 00000074AE64: CA100080 1B1C0080
	v_mov_b32_e32 v29, 0                                       // 00000074AE6C: 7E3A0280
	s_and_saveexec_b32 s3, s2                                  // 00000074AE70: BE832002
	s_cbranch_execz 447                                        // 00000074AE74: BFA501BF <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xb74>
	v_dual_mov_b32 v31, v23 :: v_dual_lshlrev_b32 v10, 1, v23  // 00000074AE78: CA220117 1F0A2E81
	.long 0xd7006a08                                           // 00000074AE80: D7006A08
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 00000074AE84: 02021010
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000074AE88: BF8701A1
	v_add_co_ci_u32_e64 v9, null, s17, v9, vcc_lo              // 00000074AE8C: D5207C09 01AA1211
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 00000074AE94: CA220080 14122E85
	.long 0xd7006a08                                           // 00000074AE9C: D7006A08
	v_cndmask_b32_e32 v1, v8, v10, vcc_lo                      // 00000074AEA0: 02021508
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000074AEA4: BF8701A1
	v_add_co_ci_u32_e64 v9, null, 0, v9, vcc_lo                // 00000074AEA8: D5207C09 01AA1280
	v_lshl_or_b32 v30, v23, 4, 0x100                           // 00000074AEB0: D656001E 03FD0917 00000100
	.long 0xd7006a08                                           // 00000074AEBC: D7006A08
	v_cndmask_b32_e32 v1, s4, v8, vcc_lo                       // 00000074AEC0: 02021004
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000074AEC4: BF8701A1
	v_add_co_ci_u32_e64 v9, null, s5, v9, vcc_lo               // 00000074AEC8: D5207C09 01AA1205
	v_dual_mov_b32 v29, v20 :: v_dual_mov_b32 v32, v33         // 00000074AED0: CA100114 1D200121
	.long 0xd7006a15                                           // 00000074AED8: D7006A15
	v_cndmask_b32_e32 v0, v8, v160, vcc_lo                     // 00000074AEDC: 02014108
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074AEE0: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v9, vcc_lo               // 00000074AEE4: D5207C16 01AA1280
	v_mov_b32_e32 v28, v20                                     // 00000074AEEC: 7E380314
	v_mov_b32_e32 v27, v20                                     // 00000074AEF0: 7E360314
	v_mov_b32_e32 v26, v20                                     // 00000074AEF4: 7E340314
	s_mul_i32 s2, s11, 6                                       // 00000074AEF8: 9602860B
	s_mul_hi_u32 s18, s10, 6                                   // 00000074AEFC: 9692860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 00000074AF00: 848E820A
	s_add_i32 s18, s18, s2                                     // 00000074AF04: 81120212
	s_mul_i32 s17, s10, 6                                      // 00000074AF08: 9611860A
	s_mov_b32 s16, 0                                           // 00000074AF0C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000074AF10: 8484810A
	s_branch 378                                               // 00000074AF14: BFA0017A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xb00>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000074AF18: 8C7E0A7E
	v_cndmask_b32_e64 v33, v33, v0, s1                         // 00000074AF1C: D5010021 00060121
	v_cndmask_b32_e64 v34, v0, v1, s1                          // 00000074AF24: D5010022 00060300
	v_dual_mov_b32 v41, v7 :: v_dual_and_b32 v0, 0xff, v12     // 00000074AF2C: CA240107 290018FF 000000FF
	v_cndmask_b32_e64 v40, v6, v7, s1                          // 00000074AF38: D5010028 00060F06
	v_cndmask_b32_e64 v39, v5, v6, s1                          // 00000074AF40: D5010027 00060D05
	v_cndmask_b32_e64 v38, v4, v5, s1                          // 00000074AF48: D5010026 00060B04
	v_cndmask_b32_e64 v37, v3, v4, s1                          // 00000074AF50: D5010025 00060903
	v_lshlrev_b32_e32 v0, 2, v0                                // 00000074AF58: 30000082
	v_cndmask_b32_e64 v36, v2, v3, s1                          // 00000074AF5C: D5010024 00060702
	v_cndmask_b32_e64 v35, v1, v2, s1                          // 00000074AF64: D5010023 00060501
	s_and_b32 s2, exec_lo, s2                                  // 00000074AF6C: 8B02027E
	v_add_nc_u32_e32 v30, 0x100, v30                           // 00000074AF70: 4A3C3CFF 00000100
	ds_load_b32 v48, v0                                        // 00000074AF78: D8D80000 30000000
	v_lshrrev_b32_e32 v0, 6, v12                               // 00000074AF80: 32001886
	s_or_b32 s16, s2, s16                                      // 00000074AF84: 8C101002
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074AF88: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 00000074AF8C: 360000FF 000003FC
	ds_load_b32 v49, v0                                        // 00000074AF94: D8D80000 31000000
	v_lshrrev_b32_e32 v0, 14, v12                              // 00000074AF9C: 3200188E
	v_and_b32_e32 v0, 0x3fc, v0                                // 00000074AFA0: 360000FF 000003FC
	ds_load_b32 v50, v0                                        // 00000074AFA8: D8D80000 32000000
	v_lshrrev_b32_e32 v0, 22, v12                              // 00000074AFB0: 32001896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074AFB4: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 00000074AFB8: 360000FF 000003FC
	ds_load_b32 v51, v0                                        // 00000074AFC0: D8D80000 33000000
	v_and_b32_e32 v0, 0xff, v13                                // 00000074AFC8: 36001AFF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 00000074AFD0: 30000082
	ds_load_b32 v52, v0                                        // 00000074AFD4: D8D80000 34000000
	v_lshrrev_b32_e32 v0, 6, v13                               // 00000074AFDC: 32001A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074AFE0: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 00000074AFE4: 360000FF 000003FC
	ds_load_b32 v53, v0                                        // 00000074AFEC: D8D80000 35000000
	v_lshrrev_b32_e32 v0, 14, v13                              // 00000074AFF4: 32001A8E
	v_and_b32_e32 v0, 0x3fc, v0                                // 00000074AFF8: 360000FF 000003FC
	ds_load_b32 v54, v0                                        // 00000074B000: D8D80000 36000000
	v_lshrrev_b32_e32 v0, 22, v13                              // 00000074B008: 32001A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074B00C: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 00000074B010: 360000FF 000003FC
	ds_load_b32 v55, v0                                        // 00000074B018: D8D80000 37000000
	v_and_b32_e32 v0, 0xff, v14                                // 00000074B020: 36001CFF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 00000074B028: 30000082
	ds_load_b32 v56, v0                                        // 00000074B02C: D8D80000 38000000
	v_lshrrev_b32_e32 v0, 6, v14                               // 00000074B034: 32001C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074B038: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 00000074B03C: 360000FF 000003FC
	ds_load_b32 v57, v0                                        // 00000074B044: D8D80000 39000000
	v_lshrrev_b32_e32 v0, 14, v14                              // 00000074B04C: 32001C8E
	v_and_b32_e32 v0, 0x3fc, v0                                // 00000074B050: 360000FF 000003FC
	ds_load_b32 v58, v0                                        // 00000074B058: D8D80000 3A000000
	v_lshrrev_b32_e32 v0, 22, v14                              // 00000074B060: 32001C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074B064: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 00000074B068: 360000FF 000003FC
	ds_load_b32 v59, v0                                        // 00000074B070: D8D80000 3B000000
	v_and_b32_e32 v0, 0xff, v15                                // 00000074B078: 36001EFF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 00000074B080: 30000082
	ds_load_b32 v60, v0                                        // 00000074B084: D8D80000 3C000000
	v_lshrrev_b32_e32 v0, 6, v15                               // 00000074B08C: 32001E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074B090: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 00000074B094: 360000FF 000003FC
	ds_load_b32 v61, v0                                        // 00000074B09C: D8D80000 3D000000
	v_lshrrev_b32_e32 v0, 14, v15                              // 00000074B0A4: 32001E8E
	v_and_b32_e32 v0, 0x3fc, v0                                // 00000074B0A8: 360000FF 000003FC
	ds_load_b32 v62, v0                                        // 00000074B0B0: D8D80000 3E000000
	v_lshrrev_b32_e32 v0, 22, v15                              // 00000074B0B8: 32001E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000074B0BC: BF870141
	v_and_b32_e32 v0, 0x3fc, v0                                // 00000074B0C0: 360000FF 000003FC
	ds_load_b32 v63, v0                                        // 00000074B0C8: D8D80000 3F000000
	.long 0xd73c0000                                           // 00000074B0D0: D73C0000
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 00000074B0D4: 02022681
	v_add_nc_u32_e32 v19, 0x200, v19                           // 00000074B0D8: 4A2626FF 00000200
	.long 0xd7006a2e                                           // 00000074B0E0: D7006A2E
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 00000074B0E4: 02020006
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074B0E8: BF870001
	v_add_co_ci_u32_e64 v47, null, s7, v1, vcc_lo              // 00000074B0EC: D5207C2F 01AA0207
	s_clause 0x3                                               // 00000074B0F4: BF850003
	global_load_b128 v[0:3], v[46:47], off                     // 00000074B0F8: DC5E0000 007C002E
	global_load_b128 v[4:7], v[46:47], off offset:16           // 00000074B100: DC5E0010 047C002E
	global_load_b128 v[12:15], v[46:47], off offset:32         // 00000074B108: DC5E0020 0C7C002E
	global_load_b128 v[42:45], v[46:47], off offset:48         // 00000074B110: DC5E0030 2A7C002E
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000074B118: BF890CF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 00000074B11C: CC1A4000 1A026100
	s_waitcnt lgkmcnt(14)                                      // 00000074B124: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074B128: BF8700A1
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 00000074B12C: CC1A4000 1C026301
	s_waitcnt lgkmcnt(13)                                      // 00000074B134: BF89FCD7
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 00000074B138: CC1A4000 1C026502
	s_waitcnt lgkmcnt(12)                                      // 00000074B140: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074B144: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 00000074B148: CC1A4000 1C026703
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000074B150: BF8908B7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 00000074B154: CC1A4000 1C026904
	s_waitcnt lgkmcnt(10)                                      // 00000074B15C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074B160: BF8700A1
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 00000074B164: CC1A4000 1C026B05
	s_waitcnt lgkmcnt(9)                                       // 00000074B16C: BF89FC97
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 00000074B170: CC1A4000 1C026D06
	s_waitcnt lgkmcnt(8)                                       // 00000074B178: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074B17C: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 00000074B180: CC1A4000 1C026F07
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000074B188: BF890477
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 00000074B18C: CC1A4000 1C02710C
	s_waitcnt lgkmcnt(6)                                       // 00000074B194: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074B198: BF8700A1
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 00000074B19C: CC1A4000 1C02730D
	s_waitcnt lgkmcnt(5)                                       // 00000074B1A4: BF89FC57
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 00000074B1A8: CC1A4000 1C02750E
	s_waitcnt lgkmcnt(4)                                       // 00000074B1B0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074B1B4: BF8700A1
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 00000074B1B8: CC1A4000 1C02770F
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000074B1C0: BF890037
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 00000074B1C4: CC1A4000 1C02792A
	.long 0xd7006a2a                                           // 00000074B1CC: D7006A2A
	v_cndmask_b32_e32 v0, v46, v4, vcc_lo                      // 00000074B1D0: 0200092E
	s_waitcnt lgkmcnt(2)                                       // 00000074B1D4: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000074B1D8: BF870132
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 00000074B1DC: CC1A4000 1C027B2B
	v_add_co_ci_u32_e64 v43, null, s5, v47, vcc_lo             // 00000074B1E4: D5207C2B 01AA5E05
	s_waitcnt lgkmcnt(1)                                       // 00000074B1EC: BF89FC17
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 00000074B1F0: CC1A4000 1C027D2C
	s_waitcnt lgkmcnt(0)                                       // 00000074B1F8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074B1FC: BF870091
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 00000074B200: CC1A4000 1C027F2D
	v_fmac_f32_e32 v29, v33, v0                                // 00000074B208: 563A0121
	s_clause 0x3                                               // 00000074B20C: BF850003
	global_load_b128 v[0:3], v[42:43], off                     // 00000074B210: DC5E0000 007C002A
	global_load_b128 v[4:7], v[42:43], off offset:16           // 00000074B218: DC5E0010 047C002A
	global_load_b128 v[12:15], v[42:43], off offset:32         // 00000074B220: DC5E0020 0C7C002A
	global_load_b128 v[42:45], v[42:43], off offset:48         // 00000074B228: DC5E0030 2A7C002A
	s_waitcnt vmcnt(3)                                         // 00000074B230: BF890FF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 00000074B234: CC1A4000 1A026100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074B23C: BF870091
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 00000074B240: CC1A4000 1C026301
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 00000074B248: CC1A4000 1C026502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074B250: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 00000074B254: CC1A4000 1C026703
	s_waitcnt vmcnt(2)                                         // 00000074B25C: BF890BF7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 00000074B260: CC1A4000 1C026904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074B268: BF870091
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 00000074B26C: CC1A4000 1C026B05
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 00000074B274: CC1A4000 1C026D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074B27C: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 00000074B280: CC1A4000 1C026F07
	s_waitcnt vmcnt(1)                                         // 00000074B288: BF8907F7
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 00000074B28C: CC1A4000 1C02710C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074B294: BF870091
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 00000074B298: CC1A4000 1C02730D
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 00000074B2A0: CC1A4000 1C02750E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074B2A8: BF8700A1
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 00000074B2AC: CC1A4000 1C02770F
	s_waitcnt vmcnt(0)                                         // 00000074B2B4: BF8903F7
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 00000074B2B8: CC1A4000 1C02792A
	.long 0xd7006a2a                                           // 00000074B2C0: D7006A2A
	v_cndmask_b32_e32 v0, v46, v14, vcc_lo                     // 00000074B2C4: 02001D2E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000074B2C8: BF870122
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 00000074B2CC: CC1A4000 1C027B2B
	v_add_co_ci_u32_e64 v43, null, s15, v47, vcc_lo            // 00000074B2D4: D5207C2B 01AA5E0F
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 00000074B2DC: CC1A4000 1C027D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074B2E4: BF870091
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 00000074B2E8: CC1A4000 1C027F2D
	v_fmac_f32_e32 v28, v33, v0                                // 00000074B2F0: 56380121
	s_clause 0x3                                               // 00000074B2F4: BF850003
	global_load_b128 v[0:3], v[42:43], off                     // 00000074B2F8: DC5E0000 007C002A
	global_load_b128 v[4:7], v[42:43], off offset:16           // 00000074B300: DC5E0010 047C002A
	global_load_b128 v[12:15], v[42:43], off offset:32         // 00000074B308: DC5E0020 0C7C002A
	global_load_b128 v[42:45], v[42:43], off offset:48         // 00000074B310: DC5E0030 2A7C002A
	s_waitcnt vmcnt(3)                                         // 00000074B318: BF890FF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 00000074B31C: CC1A4000 1A026100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074B324: BF870091
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 00000074B328: CC1A4000 1C026301
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 00000074B330: CC1A4000 1C026502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074B338: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 00000074B33C: CC1A4000 1C026703
	s_waitcnt vmcnt(2)                                         // 00000074B344: BF890BF7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 00000074B348: CC1A4000 1C026904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074B350: BF870091
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 00000074B354: CC1A4000 1C026B05
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 00000074B35C: CC1A4000 1C026D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074B364: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 00000074B368: CC1A4000 1C026F07
	s_waitcnt vmcnt(1)                                         // 00000074B370: BF8907F7
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 00000074B374: CC1A4000 1C02710C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074B37C: BF870091
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 00000074B380: CC1A4000 1C02730D
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 00000074B388: CC1A4000 1C02750E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074B390: BF8700A1
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 00000074B394: CC1A4000 1C02770F
	s_waitcnt vmcnt(0)                                         // 00000074B39C: BF8903F7
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 00000074B3A0: CC1A4000 1C02792A
	.long 0xd7006a2a                                           // 00000074B3A8: D7006A2A
	v_cndmask_b32_e32 v0, v46, v17, vcc_lo                     // 00000074B3AC: 0200232E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000074B3B0: BF8701B2
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 00000074B3B4: CC1A4000 1C027B2B
	v_add_co_ci_u32_e64 v43, null, s18, v47, vcc_lo            // 00000074B3BC: D5207C2B 01AA5E12
	.long 0xd7006a15                                           // 00000074B3C4: D7006A15
	v_cndmask_b32_e32 v0, v21, v160, vcc_lo                    // 00000074B3C8: 02014115
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 00000074B3CC: CC1A4000 1C027D2C
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 00000074B3D4: D5207C16 01AA2C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074B3DC: BF870092
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 00000074B3E0: CC1A4000 1C027F2D
	v_fmac_f32_e32 v27, v33, v0                                // 00000074B3E8: 56360121
	s_clause 0x3                                               // 00000074B3EC: BF850003
	global_load_b128 v[0:3], v[42:43], off                     // 00000074B3F0: DC5E0000 007C002A
	global_load_b128 v[4:7], v[42:43], off offset:16           // 00000074B3F8: DC5E0010 047C002A
	global_load_b128 v[12:15], v[42:43], off offset:32         // 00000074B400: DC5E0020 0C7C002A
	global_load_b128 v[42:45], v[42:43], off offset:48         // 00000074B408: DC5E0030 2A7C002A
	s_waitcnt vmcnt(3)                                         // 00000074B410: BF890FF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 00000074B414: CC1A4000 1A026100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074B41C: BF870091
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 00000074B420: CC1A4000 1C026301
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 00000074B428: CC1A4000 1C026502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074B430: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 00000074B434: CC1A4000 1C026703
	s_waitcnt vmcnt(2)                                         // 00000074B43C: BF890BF7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 00000074B440: CC1A4000 1C026904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074B448: BF870091
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 00000074B44C: CC1A4000 1C026B05
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 00000074B454: CC1A4000 1C026D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074B45C: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 00000074B460: CC1A4000 1C026F07
	s_waitcnt vmcnt(1)                                         // 00000074B468: BF8907F7
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 00000074B46C: CC1A4000 1C02710C
	v_mov_b32_e32 v12, v8                                      // 00000074B474: 7E180308
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000074B478: BF870122
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 00000074B47C: CC1A4000 1C02730D
	v_mov_b32_e32 v13, v9                                      // 00000074B484: 7E1A0309
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 00000074B488: CC1A4000 1C02750E
	v_mov_b32_e32 v14, v10                                     // 00000074B490: 7E1C030A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000074B494: BF870132
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 00000074B498: CC1A4000 1C02770F
	v_mov_b32_e32 v15, v11                                     // 00000074B4A0: 7E1E030B
	s_waitcnt vmcnt(0)                                         // 00000074B4A4: BF8903F7
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 00000074B4A8: CC1A4000 1C02792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074B4B0: BF870091
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 00000074B4B4: CC1A4000 1C027B2B
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 00000074B4BC: CC1A4000 1C027D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074B4C4: BF870091
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 00000074B4C8: CC1A4000 1C027F2D
	v_fmac_f32_e32 v26, v33, v0                                // 00000074B4D0: 56340121
	v_dual_mov_b32 v0, v34 :: v_dual_mov_b32 v33, v32          // 00000074B4D4: CA100122 00200120
	v_dual_mov_b32 v1, v35 :: v_dual_mov_b32 v2, v36           // 00000074B4DC: CA100123 01020124
	v_dual_mov_b32 v3, v37 :: v_dual_mov_b32 v4, v38           // 00000074B4E4: CA100125 03040126
	v_dual_mov_b32 v5, v39 :: v_dual_mov_b32 v6, v40           // 00000074B4EC: CA100127 05060128
	v_mov_b32_e32 v7, v41                                      // 00000074B4F4: 7E0E0329
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000074B4F8: 917E107E
	s_cbranch_execz 28                                         // 00000074B4FC: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xb70>
	s_waitcnt vmcnt(0)                                         // 00000074B500: BF8903F7
	v_dual_mov_b32 v8, v12 :: v_dual_add_nc_u32 v31, 16, v31   // 00000074B504: CA20010C 081E3E90
	v_dual_mov_b32 v9, v13 :: v_dual_mov_b32 v10, v14          // 00000074B50C: CA10010D 090A010E
	v_mov_b32_e32 v11, v15                                     // 00000074B514: 7E16030F
	s_delay_alu instid0(VALU_DEP_3)                            // 00000074B518: BF870003
	.long 0xd4430002                                           // 00000074B51C: D4430002
	v_cndmask_b32_e32 v1, s20, v31, vcc_lo                     // 00000074B520: 02023E14
	s_mov_b32 s10, exec_lo                                     // 00000074B524: BE8A007E
	.long 0xd4c4007e                                           // 00000074B528: D4C4007E
	v_cndmask_b32_e32 v1, s20, v31, vcc_lo                     // 00000074B52C: 02023E14
	s_cbranch_execz 65145                                      // 00000074B530: BFA5FE79 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	.long 0xd7006a08                                           // 00000074B534: D7006A08
	v_cndmask_b32_e32 v1, v18, v30, vcc_lo                     // 00000074B538: 02023D12
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074B53C: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 00000074B540: D5207C09 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 00000074B548: 7C9A3081
	v_mov_b32_e32 v32, v33                                     // 00000074B54C: 7E400321
	global_load_b128 v[8:11], v[8:9], off                      // 00000074B550: DC5E0000 087C0008
	s_cbranch_vccnz 65135                                      // 00000074B558: BFA4FE6F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	global_load_d16_b16 v32, v[21:22], off                     // 00000074B55C: DC820000 207C0015
	s_waitcnt vmcnt(0)                                         // 00000074B564: BF8903F7
	v_cvt_f32_f16_e32 v32, v32                                 // 00000074B568: 7E401720
	s_branch 65130                                             // 00000074B56C: BFA0FE6A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000074B570: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074B574: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000074B578: 8C7E037E
	.long 0xd71f0000                                           // 00000074B57C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000074B580: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 00000074B584: 3A020088
	v_xor_b32_e32 v5, 4, v0                                    // 00000074B588: 3A0A0084
	v_xor_b32_e32 v9, 2, v0                                    // 00000074B58C: 3A120082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000074B590: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 00000074B594: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000074B598: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 00000074B59C: 7C980AA0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000074B5A0: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000074B5A4: 30020282
	ds_bpermute_b32 v4, v1, v27                                // 00000074B5A8: DACC0000 04001B01
	s_waitcnt lgkmcnt(0)                                       // 00000074B5B0: BF89FC07
	v_add_f32_e32 v4, v27, v4                                  // 00000074B5B4: 0608091B
	ds_bpermute_b32 v2, v1, v29                                // 00000074B5B8: DACC0000 02001D01
	ds_bpermute_b32 v3, v1, v28                                // 00000074B5C0: DACC0000 03001C01
	ds_bpermute_b32 v1, v1, v26                                // 00000074B5C8: DACC0000 01001A01
	s_waitcnt lgkmcnt(2)                                       // 00000074B5D0: BF89FC27
	v_dual_add_f32 v2, v29, v2 :: v_dual_cndmask_b32 v5, v0, v5// 00000074B5D4: C912051D 02040B00
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 00000074B5DC: 7C9812A0
	s_waitcnt lgkmcnt(0)                                       // 00000074B5E0: BF89FC07
	v_add_f32_e32 v1, v26, v1                                  // 00000074B5E4: 0602031A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000074B5E8: BF870003
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000074B5EC: 300A0A82
	v_cndmask_b32_e32 v9, v0, v9, vcc_lo                       // 00000074B5F0: 02121300
	ds_bpermute_b32 v6, v5, v2                                 // 00000074B5F4: DACC0000 06000205
	ds_bpermute_b32 v8, v5, v4                                 // 00000074B5FC: DACC0000 08000405
	s_waitcnt lgkmcnt(1)                                       // 00000074B604: BF89FC17
	v_dual_add_f32 v2, v2, v6 :: v_dual_lshlrev_b32 v9, 2, v9  // 00000074B608: C9220D02 02081282
	s_waitcnt lgkmcnt(0)                                       // 00000074B610: BF89FC07
	v_add_f32_e32 v6, v4, v8                                   // 00000074B614: 060C1104
	ds_bpermute_b32 v4, v9, v2                                 // 00000074B618: DACC0000 04000209
	s_waitcnt lgkmcnt(0)                                       // 00000074B620: BF89FC07
	v_dual_add_f32 v3, v28, v3 :: v_dual_add_f32 v2, v2, v4    // 00000074B624: C908071C 03020902
	ds_bpermute_b32 v7, v5, v3                                 // 00000074B62C: DACC0000 07000305
	ds_bpermute_b32 v5, v5, v1                                 // 00000074B634: DACC0000 05000105
	s_waitcnt lgkmcnt(1)                                       // 00000074B63C: BF89FC17
	v_add_f32_e32 v3, v3, v7                                   // 00000074B640: 06060F03
	s_waitcnt lgkmcnt(0)                                       // 00000074B644: BF89FC07
	v_add_f32_e32 v1, v1, v5                                   // 00000074B648: 06020B01
	ds_bpermute_b32 v7, v9, v6                                 // 00000074B64C: DACC0000 07000609
	ds_bpermute_b32 v5, v9, v3                                 // 00000074B654: DACC0000 05000309
	ds_bpermute_b32 v8, v9, v1                                 // 00000074B65C: DACC0000 08000109
	v_xor_b32_e32 v9, 1, v0                                    // 00000074B664: 3A120081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000074B668: BF870131
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 00000074B66C: 7C9812A0
	v_cndmask_b32_e32 v0, v0, v9, vcc_lo                       // 00000074B670: 02001300
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 00000074B674: 7C942E80
	v_lshlrev_b32_e32 v9, 2, v0                                // 00000074B678: 30120082
	s_and_b32 s0, vcc_lo, s0                                   // 00000074B67C: 8B00006A
	s_waitcnt lgkmcnt(1)                                       // 00000074B680: BF89FC17
	v_dual_add_f32 v4, v3, v5 :: v_dual_add_f32 v5, v6, v7     // 00000074B684: C9080B03 04040F06
	s_waitcnt lgkmcnt(0)                                       // 00000074B68C: BF89FC07
	v_add_f32_e32 v0, v1, v8                                   // 00000074B690: 06001101
	ds_bpermute_b32 v3, v9, v2                                 // 00000074B694: DACC0000 03000209
	ds_bpermute_b32 v6, v9, v4                                 // 00000074B69C: DACC0000 06000409
	ds_bpermute_b32 v7, v9, v5                                 // 00000074B6A4: DACC0000 07000509
	ds_bpermute_b32 v1, v9, v0                                 // 00000074B6AC: DACC0000 01000009
	s_and_saveexec_b32 s1, s0                                  // 00000074B6B4: BE812000
	s_cbranch_execz 39                                         // 00000074B6B8: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xd58>
	.long 0xd73c0008                                           // 00000074B6BC: D73C0008
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 00000074B6C0: 02022082
	s_waitcnt lgkmcnt(1)                                       // 00000074B6C4: BF89FC17
	v_dual_add_f32 v10, v5, v7 :: v_dual_add_f32 v11, v4, v6   // 00000074B6C8: C9080F05 0A0A0D04
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000074B6D0: 8480820C
	s_waitcnt vmcnt(0)                                         // 00000074B6D4: BF8903F7
	v_add_f32_e32 v12, v2, v3                                  // 00000074B6D8: 06180702
	s_lshl_b64 s[2:3], s[12:13], 3                             // 00000074B6DC: 8482830C
	.long 0xd7006a08                                           // 00000074B6E0: D7006A08
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 00000074B6E4: 02021008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000074B6E8: BF8701B1
	v_add_co_ci_u32_e64 v9, null, s9, v9, vcc_lo               // 00000074B6EC: D5207C09 01AA1209
	s_waitcnt lgkmcnt(0)                                       // 00000074B6F4: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 00000074B6F8: 06000300
	.long 0xd7006a02                                           // 00000074B6FC: D7006A02
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 00000074B700: 02000108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000074B704: BF870123
	v_mad_u64_u32 v[4:5], null, s12, 12, v[8:9]                // 00000074B708: D6FE7C04 0421180C
	v_add_co_ci_u32_e64 v3, null, s1, v9, vcc_lo               // 00000074B710: D5207C03 01AA1201
	v_mad_u64_u32 v[5:6], null, s13, 12, v[5:6]                // 00000074B718: D6FE7C05 0415180D
	.long 0xd7006a06                                           // 00000074B720: D7006A06
	v_cndmask_b32_e32 v0, v8, v2, vcc_lo                       // 00000074B724: 02000508
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074B728: BF870001
	v_add_co_ci_u32_e64 v7, null, s3, v9, vcc_lo               // 00000074B72C: D5207C07 01AA1203
	s_clause 0x3                                               // 00000074B734: BF850003
	global_store_b32 v[8:9], v12, off                          // 00000074B738: DC6A0000 007C0C08
	global_store_b32 v[2:3], v11, off                          // 00000074B740: DC6A0000 007C0B02
	global_store_b32 v[6:7], v10, off                          // 00000074B748: DC6A0000 007C0A06
	global_store_b32 v[4:5], v0, off                           // 00000074B750: DC6A0000 007C0004
	s_endpgm                                                   // 00000074B758: BFB00000
		...

