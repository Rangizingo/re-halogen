00000000008c7400 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008C7400: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000008C7408: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008C740C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000008C7410: 84828302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C7414: BF8701A9
	v_dual_mov_b32 v10, s3 :: v_dual_and_b32 v1, 15, v0        // 0000008C7418: CA240003 0A00008F
	.long 0x7f103880                                           // 0000008C7420: 7F103880
	v_and_b32_e32 v2, 60, v2                                   // 0000008C7424: 360404BC
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C7428: BF870003
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 0000008C742C: CA220080 12000282
	v_dual_mov_b32 v3, 0 :: v_dual_and_b32 v16, 31, v0         // 0000008C7434: CA240080 0310009F
	v_mov_b32_e32 v17, 0                                       // 0000008C743C: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 0000008C7440: BF89FC07
	s_clause 0x1                                               // 0000008C7444: BF850001
	global_load_b32 v4, v1, s[4:5]                             // 0000008C7448: DC520000 04040001
	global_load_b32 v7, v2, s[4:5]                             // 0000008C7450: DC520000 07040002
	v_lshrrev_b32_e32 v2, 5, v0                                // 0000008C7458: 32040085
	s_add_u32 s14, s4, s14                                     // 0000008C745C: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000008C7460: 820F0F05
	v_mov_b32_e32 v1, 0                                        // 0000008C7464: 7E020280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C7468: BF870002
	v_or_b32_e32 v9, s2, v2                                    // 0000008C746C: 38120402
	s_lshr_b32 s2, s11, 31                                     // 0000008C7470: 85029F0B
	v_mov_b32_e32 v2, 0                                        // 0000008C7474: 7E040280
	s_add_u32 s20, s10, s2                                     // 0000008C7478: 8014020A
	s_addc_u32 s21, s11, 0                                     // 0000008C747C: 8215800B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 0000008C7480: 7CA8120C
	s_ashr_i32 s22, s11, 31                                    // 0000008C7484: 86169F0B
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 0000008C7488: 02161280
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 0000008C748C: D501000E 01A80680
	s_ashr_i64 s[2:3], s[20:21], 1                             // 0000008C7494: 86828114
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000008C7498: BF870481
	.long 0xd72c0014                                           // 0000008C749C: D72C0014
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 0000008C74A0: 0200050E
	.long 0xd72c000e                                           // 0000008C74A4: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000008C74A8: 02021C12
	s_waitcnt vmcnt(1)                                         // 0000008C74AC: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 0000008C74B0: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 0000008C74B8: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 0000008C74BC: D6100013 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008C74C4: BF870112
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000008C74C8: D6550004 03FE1904 00007FFF
	v_add3_u32 v7, v7, v19, 0x7fff                             // 0000008C74D4: D6550007 03FE2707 00007FFF
	v_lshlrev_b32_e32 v19, 2, v0                               // 0000008C74E0: 30260082
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C74E4: BF870003
	.long 0x7e103984                                           // 0000008C74E8: 7E103984
	v_mov_b32_e32 v4, 0                                        // 0000008C74EC: 7E080280
	.long 0xd72c000d                                           // 0000008C74F0: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 0000008C74F4: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 0000008C74F8: D6FE7C05 02021612
	.long 0xd72c000f                                           // 0000008C7500: D72C000F
	v_cndmask_b32_e32 v0, v11, v3, vcc_lo                      // 0000008C7504: 0200070B
	v_mad_u64_u32 v[11:12], null, v11, s2, s[14:15]            // 0000008C7508: D6FE7C0B 0038050B
	s_lshr_b32 s19, s22, 27                                    // 0000008C7510: 85139B16
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 0000008C7514: D6570007 04220EFF FFFF0000
	s_add_u32 s14, s10, s19                                    // 0000008C7520: 800E130A
	s_addc_u32 s15, s11, 0                                     // 0000008C7524: 820F800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008C7528: BF870009
	s_lshr_b64 s[14:15], s[14:15], 5                           // 0000008C752C: 858E850E
	v_add3_u32 v6, v6, v14, v13                                // 0000008C7530: D6550006 04361D06
	.long 0xd4440002                                           // 0000008C7538: D4440002
	v_cndmask_b32_e32 v1, s14, v16, vcc_lo                     // 0000008C753C: 0202200E
	v_add3_u32 v0, v20, v12, v15                               // 0000008C7540: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 0000008C7548: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 0000008C7550: BF89FC07
	s_barrier                                                  // 0000008C7554: BFBD0000
	buffer_gl0_inv                                             // 0000008C7558: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 0000008C7560: BE8F2002
	s_cbranch_execz 26                                         // 0000008C7564: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x1d0>
	s_add_u32 s3, s4, s16                                      // 0000008C7568: 80031004
	s_addc_u32 s18, s5, s17                                    // 0000008C756C: 82121105
	v_lshlrev_b32_e32 v1, 1, v16                               // 0000008C7570: 30022081
	.long 0xd7000302                                           // 0000008C7574: D7000302
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 0000008C7578: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C757C: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s18, v6, s3                  // 0000008C7580: D5207C03 000E0C12
	v_lshlrev_b32_e32 v4, 4, v16                               // 0000008C7588: 30082084
	.long 0xd7000301                                           // 0000008C758C: D7000301
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000008C7590: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C7594: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s3                    // 0000008C7598: D5207C02 000E0680
	.long 0xd7000303                                           // 0000008C75A0: D7000303
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 0000008C75A4: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C75A8: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s3                    // 0000008C75AC: D5207C04 000E0080
	s_clause 0x1                                               // 0000008C75B4: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 0000008C75B8: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000008C75C0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000008C75C8: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 0000008C75CC: 7E241707
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008C75D0: 8C7E0F7E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000008C75D4: CA100080 13140080
	v_mov_b32_e32 v21, 0                                       // 0000008C75DC: 7E2A0280
	s_and_saveexec_b32 s15, s2                                 // 0000008C75E0: BE8F2002
	s_cbranch_execz 382                                        // 0000008C75E4: BFA5017E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x7e0>
	s_mul_i32 s2, s11, 6                                       // 0000008C75E8: 9602860B
	s_mul_hi_u32 s3, s10, 6                                    // 0000008C75EC: 9683860A
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 0000008C75F0: CA220080 0D0C2085
	s_add_i32 s20, s3, s2                                      // 0000008C75F8: 81140203
	v_lshlrev_b32_e32 v7, 1, v16                               // 0000008C75FC: 300E2081
	.long 0xd7000205                                           // 0000008C7600: D7000205
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 0000008C7604: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C7608: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s2                  // 0000008C760C: D5207C06 000A0C11
	v_mov_b32_e32 v20, v13                                     // 0000008C7614: 7E28030D
	.long 0xd7000205                                           // 0000008C7618: D7000205
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000008C761C: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C7620: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s2                    // 0000008C7624: D5207C06 000A0C80
	v_lshl_or_b32 v22, v16, 4, 0x200                           // 0000008C762C: D6560016 03FD0910 00000200
	.long 0xd7000205                                           // 0000008C7638: D7000205
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000008C763C: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C7640: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s2                   // 0000008C7644: D5207C06 000A0C05
	v_dual_mov_b32 v23, v16 :: v_dual_mov_b32 v24, v18         // 0000008C764C: CA100110 17180112
	.long 0xd700020e                                           // 0000008C7654: D700020E
	v_cndmask_b32_e32 v0, v5, v192, vcc_lo                     // 0000008C7658: 02018105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C765C: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s2                   // 0000008C7660: D5207C0F 000A0C80
	v_mov_b32_e32 v21, v13                                     // 0000008C7668: 7E2A030D
	v_mov_b32_e32 v19, v13                                     // 0000008C766C: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 0000008C7670: 7E22030D
	s_lshl_b64 s[18:19], s[10:11], 2                           // 0000008C7674: 8492820A
	s_mul_i32 s17, s10, 6                                      // 0000008C7678: 9611860A
	s_mov_b32 s16, 0                                           // 0000008C767C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000008C7680: 8484810A
	s_branch 316                                               // 0000008C7684: BFA0013C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x778>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000008C7688: 8C7E0A7E
	.long 0xd73c0019                                           // 0000008C768C: D73C0019
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000008C7690: 02021881
	v_and_b32_e32 v57, 0xff, v1                                // 0000008C7694: 367202FF 000000FF
	v_lshrrev_b32_e32 v58, 6, v1                               // 0000008C769C: 32740286
	v_lshrrev_b32_e32 v59, 14, v1                              // 0000008C76A0: 3276028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000008C76A4: 32020296
	v_and_b32_e32 v60, 0xff, v2                                // 0000008C76A8: 367804FF 000000FF
	.long 0xd7000349                                           // 0000008C76B0: D7000349
	v_cndmask_b32_e32 v1, s6, v25, vcc_lo                      // 0000008C76B4: 02023206
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C76B8: BF8701A1
	v_add_co_ci_u32_e64 v74, null, s7, v26, s3                 // 0000008C76BC: D5207C4A 000E3407
	v_lshlrev_b32_e32 v57, 2, v57                              // 0000008C76C4: 30727282
	.long 0xd700034d                                           // 0000008C76C8: D700034D
	v_cndmask_b32_e32 v0, v73, v4, vcc_lo                      // 0000008C76CC: 02000949
	global_load_b128 v[25:28], v[73:74], off                   // 0000008C76D0: DC5E0000 197C0049
	v_add_co_ci_u32_e64 v78, null, s5, v74, s3                 // 0000008C76D8: D5207C4E 000E9405
	.long 0xd700034f                                           // 0000008C76E0: D700034F
	v_cndmask_b32_e32 v0, v73, v18, vcc_lo                     // 0000008C76E4: 02002549
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C76E8: BF8700A1
	v_add_co_ci_u32_e64 v80, null, s19, v74, s3                // 0000008C76EC: D5207C50 000E9413
	.long 0xd7000351                                           // 0000008C76F4: D7000351
	v_cndmask_b32_e32 v0, v73, v17, vcc_lo                     // 0000008C76F8: 02002349
	v_add_co_ci_u32_e64 v82, null, s20, v74, s3                // 0000008C76FC: D5207C52 000E9414
	s_clause 0x6                                               // 0000008C7704: BF850006
	global_load_b128 v[29:32], v[77:78], off                   // 0000008C7708: DC5E0000 1D7C004D
	global_load_b128 v[33:36], v[79:80], off                   // 0000008C7710: DC5E0000 217C004F
	global_load_b128 v[37:40], v[81:82], off                   // 0000008C7718: DC5E0000 257C0051
	global_load_b128 v[41:44], v[73:74], off offset:16         // 0000008C7720: DC5E0010 297C0049
	global_load_b128 v[45:48], v[77:78], off offset:16         // 0000008C7728: DC5E0010 2D7C004D
	global_load_b128 v[49:52], v[79:80], off offset:16         // 0000008C7730: DC5E0010 317C004F
	global_load_b128 v[53:56], v[81:82], off offset:16         // 0000008C7738: DC5E0010 357C0051
	v_and_b32_e32 v58, 0x3fc, v58                              // 0000008C7740: 367474FF 000003FC
	ds_load_b32 v75, v57                                       // 0000008C7748: D8D80000 4B000039
	v_lshrrev_b32_e32 v61, 6, v2                               // 0000008C7750: 327A0486
	v_lshrrev_b32_e32 v62, 14, v2                              // 0000008C7754: 327C048E
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000008C7758: 32040496
	ds_load_b32 v83, v58                                       // 0000008C775C: D8D80000 5300003A
	v_and_b32_e32 v57, 0x3fc, v59                              // 0000008C7764: 367276FF 000003FC
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008C776C: 360202FF 000003FC
	v_lshlrev_b32_e32 v76, 2, v60                              // 0000008C7774: 30987882
	v_and_b32_e32 v84, 0x3fc, v61                              // 0000008C7778: 36A87AFF 000003FC
	v_and_b32_e32 v88, 0x3fc, v62                              // 0000008C7780: 36B07CFF 000003FC
	ds_load_b32 v89, v57                                       // 0000008C7788: D8D80000 59000039
	s_clause 0x3                                               // 0000008C7790: BF850003
	global_load_b128 v[57:60], v[73:74], off offset:32         // 0000008C7794: DC5E0020 397C0049
	global_load_b128 v[61:64], v[77:78], off offset:32         // 0000008C779C: DC5E0020 3D7C004D
	global_load_b128 v[65:68], v[79:80], off offset:32         // 0000008C77A4: DC5E0020 417C004F
	global_load_b128 v[69:72], v[81:82], off offset:32         // 0000008C77AC: DC5E0020 457C0051
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000008C77B4: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000008C77BC: D8D80000 01000001
	ds_load_b32 v90, v76                                       // 0000008C77C4: D8D80000 5A00004C
	ds_load_b32 v91, v84                                       // 0000008C77CC: D8D80000 5B000054
	ds_load_b32 v88, v88                                       // 0000008C77D4: D8D80000 58000058
	ds_load_b32 v2, v2                                         // 0000008C77DC: D8D80000 02000002
	v_and_b32_e32 v85, 0xff, v3                                // 0000008C77E4: 36AA06FF 000000FF
	v_lshrrev_b32_e32 v86, 6, v3                               // 0000008C77EC: 32AC0686
	v_lshrrev_b32_e32 v87, 14, v3                              // 0000008C77F0: 32AE068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000008C77F4: 32060696
	v_and_b32_e32 v92, 0xff, v4                                // 0000008C77F8: 36B808FF 000000FF
	v_lshrrev_b32_e32 v93, 6, v4                               // 0000008C7800: 32BA0886
	v_lshrrev_b32_e32 v94, 14, v4                              // 0000008C7804: 32BC088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000008C7808: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000008C780C: 360606FF 000003FC
	s_and_b32 s3, exec_lo, s2                                  // 0000008C7814: 8B03027E
	.long 0xd700020e                                           // 0000008C7818: D700020E
	v_cndmask_b32_e32 v0, v14, v192, vcc_lo                    // 0000008C781C: 0201810E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C7820: BF870003
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008C7824: 360808FF 000003FC
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000008C782C: 4A1818FF 00000400
	v_add_nc_u32_e32 v22, 0x200, v22                           // 0000008C7834: 4A2C2CFF 00000200
	v_add_co_ci_u32_e64 v15, null, 0, v15, s2                  // 0000008C783C: D5207C0F 000A1E80
	s_or_b32 s16, s3, s16                                      // 0000008C7844: 8C101003
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 0000008C7848: BF892C77
	v_dot2_f32_bf16 v25, v25, v75, 0                           // 0000008C784C: CC1A4019 1A029719
	s_waitcnt lgkmcnt(6)                                       // 0000008C7854: BF89FC67
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C7858: BF870001
	v_dot2_f32_bf16 v25, v26, v83, v25                         // 0000008C785C: CC1A4019 1C66A71A
	s_waitcnt vmcnt(10)                                        // 0000008C7864: BF892BF7
	v_dot2_f32_bf16 v26, v29, v75, 0                           // 0000008C7868: CC1A401A 1A02971D
	s_waitcnt vmcnt(9)                                         // 0000008C7870: BF8927F7
	v_dot2_f32_bf16 v29, v33, v75, 0                           // 0000008C7874: CC1A401D 1A029721
	s_waitcnt vmcnt(8)                                         // 0000008C787C: BF8923F7
	v_dot2_f32_bf16 v33, v37, v75, 0                           // 0000008C7880: CC1A4021 1A029725
	s_waitcnt lgkmcnt(5)                                       // 0000008C7888: BF89FC57
	v_dot2_f32_bf16 v25, v27, v89, v25                         // 0000008C788C: CC1A4019 1C66B31B
	global_load_b128 v[73:76], v[73:74], off offset:48         // 0000008C7894: DC5E0030 497C0049
	v_dot2_f32_bf16 v30, v30, v83, v26                         // 0000008C789C: CC1A401E 1C6AA71E
	v_dot2_f32_bf16 v29, v34, v83, v29                         // 0000008C78A4: CC1A401D 1C76A722
	v_dot2_f32_bf16 v33, v38, v83, v33                         // 0000008C78AC: CC1A4021 1C86A726
	s_waitcnt lgkmcnt(4)                                       // 0000008C78B4: BF89FC47
	v_dot2_f32_bf16 v34, v28, v1, v25                          // 0000008C78B8: CC1A4022 1C66031C
	s_clause 0x2                                               // 0000008C78C0: BF850002
	global_load_b128 v[25:28], v[77:78], off offset:48         // 0000008C78C4: DC5E0030 197C004D
	global_load_b128 v[77:80], v[79:80], off offset:48         // 0000008C78CC: DC5E0030 4D7C004F
	global_load_b128 v[81:84], v[81:82], off offset:48         // 0000008C78D4: DC5E0030 517C0051
	v_dot2_f32_bf16 v30, v31, v89, v30                         // 0000008C78DC: CC1A401E 1C7AB31F
	v_dot2_f32_bf16 v29, v35, v89, v29                         // 0000008C78E4: CC1A401D 1C76B323
	v_dot2_f32_bf16 v31, v39, v89, v33                         // 0000008C78EC: CC1A401F 1C86B327
	v_lshlrev_b32_e32 v33, 2, v85                              // 0000008C78F4: 3042AA82
	v_and_b32_e32 v35, 0x3fc, v86                              // 0000008C78F8: 3646ACFF 000003FC
	v_dot2_f32_bf16 v30, v32, v1, v30                          // 0000008C7900: CC1A401E 1C7A0320
	v_dot2_f32_bf16 v29, v36, v1, v29                          // 0000008C7908: CC1A401D 1C760324
	v_dot2_f32_bf16 v1, v40, v1, v31                           // 0000008C7910: CC1A4001 1C7E0328
	v_and_b32_e32 v37, 0x3fc, v87                              // 0000008C7918: 364AAEFF 000003FC
	s_waitcnt vmcnt(11) lgkmcnt(3)                             // 0000008C7920: BF892C37
	v_dot2_f32_bf16 v31, v41, v90, v34                         // 0000008C7924: CC1A401F 1C8AB529
	s_waitcnt vmcnt(10)                                        // 0000008C792C: BF892BF7
	v_dot2_f32_bf16 v30, v45, v90, v30                         // 0000008C7930: CC1A401E 1C7AB52D
	s_waitcnt vmcnt(9)                                         // 0000008C7938: BF8927F7
	v_dot2_f32_bf16 v29, v49, v90, v29                         // 0000008C793C: CC1A401D 1C76B531
	s_waitcnt vmcnt(8)                                         // 0000008C7944: BF8923F7
	v_dot2_f32_bf16 v1, v53, v90, v1                           // 0000008C7948: CC1A4001 1C06B535
	ds_load_b32 v32, v33                                       // 0000008C7950: D8D80000 20000021
	ds_load_b32 v34, v37                                       // 0000008C7958: D8D80000 22000025
	s_waitcnt lgkmcnt(4)                                       // 0000008C7960: BF89FC47
	v_dot2_f32_bf16 v31, v42, v91, v31                         // 0000008C7964: CC1A401F 1C7EB72A
	v_dot2_f32_bf16 v30, v46, v91, v30                         // 0000008C796C: CC1A401E 1C7AB72E
	v_dot2_f32_bf16 v29, v50, v91, v29                         // 0000008C7974: CC1A401D 1C76B732
	v_dot2_f32_bf16 v1, v54, v91, v1                           // 0000008C797C: CC1A4001 1C06B736
	ds_load_b32 v33, v35                                       // 0000008C7984: D8D80000 21000023
	s_waitcnt lgkmcnt(4)                                       // 0000008C798C: BF89FC47
	v_dot2_f32_bf16 v31, v43, v88, v31                         // 0000008C7990: CC1A401F 1C7EB12B
	v_dot2_f32_bf16 v30, v47, v88, v30                         // 0000008C7998: CC1A401E 1C7AB12F
	v_dot2_f32_bf16 v29, v51, v88, v29                         // 0000008C79A0: CC1A401D 1C76B133
	v_dot2_f32_bf16 v1, v55, v88, v1                           // 0000008C79A8: CC1A4001 1C06B137
	v_lshlrev_b32_e32 v38, 2, v92                              // 0000008C79B0: 304CB882
	s_waitcnt lgkmcnt(3)                                       // 0000008C79B4: BF89FC37
	v_dot2_f32_bf16 v31, v44, v2, v31                          // 0000008C79B8: CC1A401F 1C7E052C
	v_dot2_f32_bf16 v30, v48, v2, v30                          // 0000008C79C0: CC1A401E 1C7A0530
	v_dot2_f32_bf16 v29, v52, v2, v29                          // 0000008C79C8: CC1A401D 1C760534
	v_dot2_f32_bf16 v1, v56, v2, v1                            // 0000008C79D0: CC1A4001 1C060538
	v_and_b32_e32 v39, 0x3fc, v93                              // 0000008C79D8: 364EBAFF 000003FC
	v_and_b32_e32 v85, 0x3fc, v94                              // 0000008C79E0: 36AABCFF 000003FC
	ds_load_b32 v2, v3                                         // 0000008C79E8: D8D80000 02000003
	ds_load_b32 v3, v38                                        // 0000008C79F0: D8D80000 03000026
	ds_load_b32 v35, v39                                       // 0000008C79F8: D8D80000 23000027
	ds_load_b32 v36, v85                                       // 0000008C7A00: D8D80000 24000055
	ds_load_b32 v37, v4                                        // 0000008C7A08: D8D80000 25000004
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000008C7A10: BF891C77
	v_dot2_f32_bf16 v4, v57, v32, v31                          // 0000008C7A14: CC1A4004 1C7E4139
	s_waitcnt vmcnt(6)                                         // 0000008C7A1C: BF891BF7
	v_dot2_f32_bf16 v30, v61, v32, v30                         // 0000008C7A20: CC1A401E 1C7A413D
	s_waitcnt vmcnt(5)                                         // 0000008C7A28: BF8917F7
	v_dot2_f32_bf16 v29, v65, v32, v29                         // 0000008C7A2C: CC1A401D 1C764141
	s_waitcnt vmcnt(4)                                         // 0000008C7A34: BF8913F7
	v_dot2_f32_bf16 v1, v69, v32, v1                           // 0000008C7A38: CC1A4001 1C064145
	s_waitcnt lgkmcnt(5)                                       // 0000008C7A40: BF89FC57
	v_dot2_f32_bf16 v4, v58, v33, v4                           // 0000008C7A44: CC1A4004 1C12433A
	v_dot2_f32_bf16 v30, v62, v33, v30                         // 0000008C7A4C: CC1A401E 1C7A433E
	v_dot2_f32_bf16 v29, v66, v33, v29                         // 0000008C7A54: CC1A401D 1C764342
	v_dot2_f32_bf16 v1, v70, v33, v1                           // 0000008C7A5C: CC1A4001 1C064346
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008C7A64: BF870214
	v_dot2_f32_bf16 v4, v59, v34, v4                           // 0000008C7A68: CC1A4004 1C12453B
	v_dot2_f32_bf16 v30, v63, v34, v30                         // 0000008C7A70: CC1A401E 1C7A453F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008C7A78: BF870214
	v_dot2_f32_bf16 v29, v67, v34, v29                         // 0000008C7A7C: CC1A401D 1C764543
	v_dot2_f32_bf16 v1, v71, v34, v1                           // 0000008C7A84: CC1A4001 1C064547
	s_waitcnt lgkmcnt(4)                                       // 0000008C7A8C: BF89FC47
	v_dot2_f32_bf16 v4, v60, v2, v4                            // 0000008C7A90: CC1A4004 1C12053C
	v_dot2_f32_bf16 v30, v64, v2, v30                          // 0000008C7A98: CC1A401E 1C7A0540
	v_dot2_f32_bf16 v29, v68, v2, v29                          // 0000008C7AA0: CC1A401D 1C760544
	v_dot2_f32_bf16 v1, v72, v2, v1                            // 0000008C7AA8: CC1A4001 1C060548
	s_waitcnt vmcnt(3) lgkmcnt(3)                              // 0000008C7AB0: BF890C37
	v_dot2_f32_bf16 v2, v73, v3, v4                            // 0000008C7AB4: CC1A4002 1C120749
	v_mov_b32_e32 v4, v8                                       // 0000008C7ABC: 7E080308
	s_waitcnt vmcnt(2)                                         // 0000008C7AC0: BF890BF7
	v_dot2_f32_bf16 v25, v25, v3, v30                          // 0000008C7AC4: CC1A4019 1C7A0719
	s_waitcnt vmcnt(1)                                         // 0000008C7ACC: BF8907F7
	v_dot2_f32_bf16 v29, v77, v3, v29                          // 0000008C7AD0: CC1A401D 1C76074D
	s_waitcnt vmcnt(0)                                         // 0000008C7AD8: BF8903F7
	v_dot2_f32_bf16 v1, v81, v3, v1                            // 0000008C7ADC: CC1A4001 1C060751
	s_waitcnt lgkmcnt(2)                                       // 0000008C7AE4: BF89FC27
	v_dot2_f32_bf16 v2, v74, v35, v2                           // 0000008C7AE8: CC1A4002 1C0A474A
	v_mov_b32_e32 v3, v7                                       // 0000008C7AF0: 7E060307
	v_dot2_f32_bf16 v8, v26, v35, v25                          // 0000008C7AF4: CC1A4008 1C66471A
	v_dot2_f32_bf16 v25, v78, v35, v29                         // 0000008C7AFC: CC1A4019 1C76474E
	v_dot2_f32_bf16 v1, v82, v35, v1                           // 0000008C7B04: CC1A4001 1C064752
	s_waitcnt lgkmcnt(1)                                       // 0000008C7B0C: BF89FC17
	v_dot2_f32_bf16 v7, v75, v36, v2                           // 0000008C7B10: CC1A4007 1C0A494B
	v_mov_b32_e32 v2, v6                                       // 0000008C7B18: 7E040306
	v_dot2_f32_bf16 v8, v27, v36, v8                           // 0000008C7B1C: CC1A4008 1C22491B
	v_dot2_f32_bf16 v25, v79, v36, v25                         // 0000008C7B24: CC1A4019 1C66494F
	v_dot2_f32_bf16 v1, v83, v36, v1                           // 0000008C7B2C: CC1A4001 1C064953
	s_waitcnt lgkmcnt(0)                                       // 0000008C7B34: BF89FC07
	v_dot2_f32_bf16 v6, v76, v37, v7                           // 0000008C7B38: CC1A4006 1C1E4B4C
	v_dot2_f32_bf16 v7, v28, v37, v8                           // 0000008C7B40: CC1A4007 1C224B1C
	v_dot2_f32_bf16 v8, v80, v37, v25                          // 0000008C7B48: CC1A4008 1C664B50
	v_dot2_f32_bf16 v25, v84, v37, v1                          // 0000008C7B50: CC1A4019 1C064B54
	v_mov_b32_e32 v1, v5                                       // 0000008C7B58: 7E020305
	v_fmac_f32_e32 v21, v18, v6                                // 0000008C7B5C: 562A0D12
	v_fmac_f32_e32 v20, v18, v7                                // 0000008C7B60: 56280F12
	v_fmac_f32_e32 v19, v18, v8                                // 0000008C7B64: 56261112
	v_dual_fmac_f32 v17, v18, v25 :: v_dual_mov_b32 v18, v24   // 0000008C7B68: C8103312 11120118
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008C7B70: 917E107E
	s_cbranch_execz 25                                         // 0000008C7B74: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x7dc>
	s_waitcnt vmcnt(0)                                         // 0000008C7B78: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v23, 32, v23    // 0000008C7B7C: CA200102 06162EA0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000008C7B84: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000008C7B8C: 7E0E0303
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C7B90: BF870003
	.long 0xd4430002                                           // 0000008C7B94: D4430002
	v_cndmask_b32_e32 v1, s14, v23, vcc_lo                     // 0000008C7B98: 02022E0E
	s_mov_b32 s10, exec_lo                                     // 0000008C7B9C: BE8A007E
	.long 0xd4c4007e                                           // 0000008C7BA0: D4C4007E
	v_cndmask_b32_e32 v1, s14, v23, vcc_lo                     // 0000008C7BA4: 02022E0E
	s_cbranch_execz 65207                                      // 0000008C7BA8: BFA5FEB7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x288>
	.long 0xd7000305                                           // 0000008C7BAC: D7000305
	v_cndmask_b32_e32 v1, v11, v22, vcc_lo                     // 0000008C7BB0: 02022D0B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C7BB4: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s3                    // 0000008C7BB8: D5207C06 000E0080
	global_load_d16_b16 v24, v[14:15], off                     // 0000008C7BC0: DC820000 187C000E
	global_load_b128 v[5:8], v[5:6], off                       // 0000008C7BC8: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 0000008C7BD0: BF8907F7
	v_cvt_f32_f16_e32 v24, v24                                 // 0000008C7BD4: 7E301718
	s_branch 65195                                             // 0000008C7BD8: BFA0FEAB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x288>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000008C7BDC: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C7BE0: BF8700B9
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008C7BE4: 8C7E0F7E
	.long 0xd71f0000                                           // 0000008C7BE8: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008C7BEC: 020100C1
	s_waitcnt vmcnt(0)                                         // 0000008C7BF0: BF8903F7
	v_xor_b32_e32 v1, 16, v0                                   // 0000008C7BF4: 3A020090
	v_xor_b32_e32 v5, 8, v0                                    // 0000008C7BF8: 3A0A0088
	v_xor_b32_e32 v11, 4, v0                                   // 0000008C7BFC: 3A160084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C7C00: BF870093
	.long 0xd44c0002                                           // 0000008C7C04: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000008C7C08: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 0000008C7C0C: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008C7C14: BF870114
	.long 0xd44c0002                                           // 0000008C7C18: D44C0002
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000008C7C1C: 02020AA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008C7C20: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C7C24: BF870002
	v_cndmask_b32_e64 v5, v0, v5, s2                           // 0000008C7C28: D5010005 000A0B00
	.long 0xd44c0002                                           // 0000008C7C30: D44C0002
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 0000008C7C34: 020216A0
	ds_bpermute_b32 v2, v1, v21                                // 0000008C7C38: DACC0000 02001501
	v_cndmask_b32_e64 v11, v0, v11, s2                         // 0000008C7C40: D501000B 000A1700
	s_waitcnt lgkmcnt(0)                                       // 0000008C7C48: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 0000008C7C4C: 06040515
	ds_bpermute_b32 v4, v1, v19                                // 0000008C7C50: DACC0000 04001301
	ds_bpermute_b32 v3, v1, v20                                // 0000008C7C58: DACC0000 03001401
	ds_bpermute_b32 v1, v1, v17                                // 0000008C7C60: DACC0000 01001101
	s_waitcnt lgkmcnt(2)                                       // 0000008C7C68: BF89FC27
	v_dual_add_f32 v4, v19, v4 :: v_dual_lshlrev_b32 v5, 2, v5 // 0000008C7C6C: C9220913 04040A82
	ds_bpermute_b32 v6, v5, v2                                 // 0000008C7C74: DACC0000 06000205
	s_waitcnt lgkmcnt(2)                                       // 0000008C7C7C: BF89FC27
	v_add_f32_e32 v3, v20, v3                                  // 0000008C7C80: 06060714
	ds_bpermute_b32 v8, v5, v4                                 // 0000008C7C84: DACC0000 08000405
	s_waitcnt lgkmcnt(1)                                       // 0000008C7C8C: BF89FC17
	v_dual_add_f32 v1, v17, v1 :: v_dual_add_f32 v2, v2, v6    // 0000008C7C90: C9080311 01020D02
	ds_bpermute_b32 v7, v5, v3                                 // 0000008C7C98: DACC0000 07000305
	s_waitcnt lgkmcnt(1)                                       // 0000008C7CA0: BF89FC17
	v_dual_add_f32 v4, v4, v8 :: v_dual_lshlrev_b32 v11, 2, v11// 0000008C7CA4: C9221104 040A1682
	ds_bpermute_b32 v5, v5, v1                                 // 0000008C7CAC: DACC0000 05000105
	s_waitcnt lgkmcnt(1)                                       // 0000008C7CB4: BF89FC17
	v_add_f32_e32 v3, v3, v7                                   // 0000008C7CB8: 06060F03
	s_waitcnt lgkmcnt(0)                                       // 0000008C7CBC: BF89FC07
	v_add_f32_e32 v1, v1, v5                                   // 0000008C7CC0: 06020B01
	ds_bpermute_b32 v5, v11, v2                                // 0000008C7CC4: DACC0000 0500020B
	s_waitcnt lgkmcnt(0)                                       // 0000008C7CCC: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 0000008C7CD0: 06040B02
	ds_bpermute_b32 v6, v11, v3                                // 0000008C7CD4: DACC0000 0600030B
	ds_bpermute_b32 v7, v11, v4                                // 0000008C7CDC: DACC0000 0700040B
	ds_bpermute_b32 v8, v11, v1                                // 0000008C7CE4: DACC0000 0800010B
	v_xor_b32_e32 v11, 2, v0                                   // 0000008C7CEC: 3A160082
	v_xor_b32_e32 v5, 1, v0                                    // 0000008C7CF0: 3A0A0081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C7CF4: BF870092
	.long 0xd44c0002                                           // 0000008C7CF8: D44C0002
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 0000008C7CFC: 020216A0
	v_cndmask_b32_e64 v11, v0, v11, s2                         // 0000008C7D00: D501000B 000A1700
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C7D08: BF870093
	.long 0xd44c0002                                           // 0000008C7D0C: D44C0002
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000008C7D10: 02020AA0
	v_cndmask_b32_e64 v0, v0, v5, s2                           // 0000008C7D14: D5010000 000A0B00
	.long 0xd44a0002                                           // 0000008C7D1C: D44A0002
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 0000008C7D20: 02022080
	s_waitcnt lgkmcnt(2)                                       // 0000008C7D24: BF89FC27
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C7D28: BF870002
	v_dual_add_f32 v3, v3, v6 :: v_dual_lshlrev_b32 v12, 2, v0 // 0000008C7D2C: C9220D03 030C0082
	s_waitcnt lgkmcnt(1)                                       // 0000008C7D34: BF89FC17
	v_add_f32_e32 v6, v4, v7                                   // 0000008C7D38: 060C0F04
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000008C7D3C: 30161682
	s_waitcnt lgkmcnt(0)                                       // 0000008C7D40: BF89FC07
	v_add_f32_e32 v1, v1, v8                                   // 0000008C7D44: 06021101
	s_and_b32 s2, s2, vcc_lo                                   // 0000008C7D48: 8B026A02
	ds_bpermute_b32 v8, v11, v6                                // 0000008C7D4C: DACC0000 0800060B
	s_waitcnt lgkmcnt(0)                                       // 0000008C7D54: BF89FC07
	v_add_f32_e32 v0, v6, v8                                   // 0000008C7D58: 06001106
	ds_bpermute_b32 v4, v11, v2                                // 0000008C7D5C: DACC0000 0400020B
	ds_bpermute_b32 v7, v11, v3                                // 0000008C7D64: DACC0000 0700030B
	s_waitcnt lgkmcnt(0)                                       // 0000008C7D6C: BF89FC07
	v_dual_add_f32 v5, v2, v4 :: v_dual_add_f32 v4, v3, v7     // 0000008C7D70: C9080902 05040F03
	ds_bpermute_b32 v11, v11, v1                               // 0000008C7D78: DACC0000 0B00010B
	ds_bpermute_b32 v2, v12, v0                                // 0000008C7D80: DACC0000 0200000C
	ds_bpermute_b32 v6, v12, v5                                // 0000008C7D88: DACC0000 0600050C
	ds_bpermute_b32 v7, v12, v4                                // 0000008C7D90: DACC0000 0700040C
	s_waitcnt lgkmcnt(3)                                       // 0000008C7D98: BF89FC37
	v_add_f32_e32 v1, v1, v11                                  // 0000008C7D9C: 06021701
	ds_bpermute_b32 v3, v12, v1                                // 0000008C7DA0: DACC0000 0300010C
	s_and_saveexec_b32 s3, s2                                  // 0000008C7DA8: BE832002
	s_cbranch_execz 100                                        // 0000008C7DAC: BFA50064 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xb40>
	v_ashrrev_i32_e32 v8, 31, v10                              // 0000008C7DB0: 3410149F
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008C7DB4: F4040080 F8000040
	s_lshr_b32 s0, s13, 31                                     // 0000008C7DBC: 85009F0D
	s_waitcnt lgkmcnt(0)                                       // 0000008C7DC0: BF89FC07
	v_dual_mov_b32 v14, s8 :: v_dual_add_f32 v7, v4, v7        // 0000008C7DC4: CA080008 0E060F04
	v_lshrrev_b32_e32 v8, 23, v8                               // 0000008C7DCC: 32101097
	s_add_u32 s4, s12, s0                                      // 0000008C7DD0: 8004000C
	s_addc_u32 s5, s13, 0                                      // 0000008C7DD4: 8205800D
	v_mov_b32_e32 v13, s9                                      // 0000008C7DD8: 7E1A0209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C7DDC: BF870092
	.long 0xd7006a08                                           // 0000008C7DE0: D7006A08
	v_cndmask_b32_e32 v1, v9, v8, vcc_lo                       // 0000008C7DE4: 02021109
	v_add_co_ci_u32_e64 v11, null, 0, v10, vcc_lo              // 0000008C7DE8: D5207C0B 01AA1480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C7DF0: BF870092
	v_and_b32_e32 v12, 0xfffffe00, v8                          // 0000008C7DF4: 361810FF FFFFFE00
	.long 0xd7016a08                                           // 0000008C7DFC: D7016A08
	v_cndmask_b32_e32 v1, v9, v12, vcc_lo                      // 0000008C7E00: 02021909
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C7E04: BF8701A1
	v_sub_co_ci_u32_e64 v9, null, v10, v11, vcc_lo             // 0000008C7E08: D5217C09 01AA170A
	.long 0x7f143880                                           // 0000008C7E10: 7F143880
	.long 0xd7000004                                           // 0000008C7E14: D7000004
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 0000008C7E18: 020210FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008C7E20: BF870153
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 0000008C7E24: 7CA810FF 00000100
	v_add_f32_e32 v6, v5, v6                                   // 0000008C7E2C: 060C0D05
	v_add_co_ci_u32_e64 v5, null, -1, v9, s0                   // 0000008C7E30: D5207C05 000212C1
	.long 0x7e143987                                           // 0000008C7E38: 7E143987
	s_ashr_i64 s[0:1], s[4:5], 1                               // 0000008C7E3C: 86808104
	v_dual_cndmask_b32 v4, v4, v8 :: v_dual_cndmask_b32 v5, v5, v9// 0000008C7E40: CA521104 04041305
	v_cndmask_b32_e32 v13, s3, v13, vcc_lo                     // 0000008C7E48: 021A1A03
	.long 0x7e103986                                           // 0000008C7E4C: 7E103986
	.long 0x7f10398a                                           // 0000008C7E50: 7F10398A
	v_cndmask_b32_e32 v9, s2, v14, vcc_lo                      // 0000008C7E54: 02121C02
	.long 0xd73c0004                                           // 0000008C7E58: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000008C7E5C: 02020881
	v_and_b32_e32 v14, 1, v10                                  // 0000008C7E60: 361C1481
	s_and_b32 s2, s4, -2                                       // 0000008C7E64: 8B02C204
	v_and_b32_e32 v8, 1, v8                                    // 0000008C7E68: 36101081
	.long 0xd7006a09                                           // 0000008C7E6C: D7006A09
	v_cndmask_b32_e32 v1, v9, v12, vcc_lo                      // 0000008C7E70: 02021909
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C7E74: BF870191
	v_add_co_ci_u32_e64 v11, null, v13, v11, vcc_lo            // 0000008C7E78: D5207C0B 01AA170D
	v_add3_u32 v8, v6, v8, 0x7fff                              // 0000008C7E80: D6550008 03FE1106 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C7E8C: BF870093
	.long 0xd7006a04                                           // 0000008C7E90: D7006A04
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 0000008C7E94: 02020909
	v_add_co_ci_u32_e64 v5, null, v11, v5, vcc_lo              // 0000008C7E98: D5207C05 01AA0B0B
	v_add_f32_e32 v11, v0, v2                                  // 0000008C7EA0: 06160500
	v_add_f32_e32 v9, v1, v3                                   // 0000008C7EA4: 06120701
	.long 0x7f04398a                                           // 0000008C7EA8: 7F04398A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008C7EAC: BF870004
	v_mad_u64_u32 v[0:1], null, s0, 6, v[4:5]                  // 0000008C7EB0: D6FE7C00 04110C00
	.long 0xd7006a06                                           // 0000008C7EB8: D7006A06
	v_cndmask_b32_e32 v0, v4, v2, vcc_lo                       // 0000008C7EBC: 02000504
	.long 0x7e04398b                                           // 0000008C7EC0: 7E04398B
	.long 0x7e143989                                           // 0000008C7EC4: 7E143989
	s_lshl_b64 s[2:3], s[0:1], 2                               // 0000008C7EC8: 84828200
	v_add3_u32 v12, v7, v14, 0x7fff                            // 0000008C7ECC: D655000C 03FE1D07 00007FFF
	v_add_co_ci_u32_e64 v7, null, s5, v5, vcc_lo               // 0000008C7ED8: D5207C07 01AA0A05
	v_and_b32_e32 v13, 1, v2                                   // 0000008C7EE0: 361A0481
	v_and_b32_e32 v10, 1, v10                                  // 0000008C7EE4: 36141481
	v_mad_u64_u32 v[1:2], null, s1, 6, v[1:2]                  // 0000008C7EE8: D6FE7C01 04050C01
	.long 0xd7006a02                                           // 0000008C7EF0: D7006A02
	v_cndmask_b32_e32 v0, v4, v2, vcc_lo                       // 0000008C7EF4: 02000504
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C7EF8: BF870001
	v_add_co_ci_u32_e64 v3, null, s3, v5, vcc_lo               // 0000008C7EFC: D5207C03 01AA0A03
	v_add3_u32 v11, v11, v13, 0x7fff                           // 0000008C7F04: D655000B 03FE1B0B 00007FFF
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000008C7F10: D6550009 03FE1509 00007FFF
	s_clause 0x3                                               // 0000008C7F1C: BF850003
	global_store_d16_hi_b16 v[4:5], v8, off                    // 0000008C7F20: DC960000 007C0804
	global_store_d16_hi_b16 v[6:7], v12, off                   // 0000008C7F28: DC960000 007C0C06
	global_store_d16_hi_b16 v[2:3], v11, off                   // 0000008C7F30: DC960000 007C0B02
	global_store_d16_hi_b16 v[0:1], v9, off                    // 0000008C7F38: DC960000 007C0900
	s_endpgm                                                   // 0000008C7F40: BFB00000
		...

