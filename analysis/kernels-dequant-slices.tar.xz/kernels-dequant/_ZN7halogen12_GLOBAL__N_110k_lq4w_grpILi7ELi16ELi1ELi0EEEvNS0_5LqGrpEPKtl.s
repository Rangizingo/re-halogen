00000000002bda00 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 0000002BDA00: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000002BDA04: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 0000002BDA0C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 0000002BDA14: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 0000002BDA1C: F4000180 F8000118
	v_dual_mov_b32 v20, 0 :: v_dual_and_b32 v17, 15, v0        // 0000002BDA24: CA240080 1410008F
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000002BDA2C: 32040084
	v_lshlrev_b32_e32 v16, 2, v0                               // 0000002BDA30: 30200082
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002BDA34: BF870002
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v3, 2, v2      // 0000002BDA38: CA220080 18020482
	s_waitcnt lgkmcnt(0)                                       // 0000002BDA40: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000002BDA44: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000002BDA48: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 0000002BDA4C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 0000002BDA50: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BDA54: BF870009
	s_and_b32 s4, s7, s4                                       // 0000002BDA58: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000002BDA5C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000002BDA60: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000002BDA68: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 0000002BDA6C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 0000002BDA70: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BDA74: BF870009
	s_and_b32 s4, s7, s5                                       // 0000002BDA78: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000002BDA7C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000002BDA80: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000002BDA84: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000002BDA88: BF030602
	v_lshlrev_b32_e32 v1, 2, v17                               // 0000002BDA8C: 30022282
	s_cselect_b32 s6, -1, 0                                    // 0000002BDA90: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000002BDA94: BF8704D9
	s_and_b32 s3, s3, s6                                       // 0000002BDA98: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000002BDA9C: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000002BDAA0: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000002BDAA4: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000002BDAA8: 98030483
	s_mulk_i32 s3, 0x48                                        // 0000002BDAAC: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BDAB0: BF870009
	s_add_u32 s16, s0, s3                                      // 0000002BDAB4: 80100300
	s_addc_u32 s17, s1, 0                                      // 0000002BDAB8: 82118001
	s_clause 0x1                                               // 0000002BDABC: BF850001
	s_load_b256 s[4:11], s[16:17], 0x18                        // 0000002BDAC0: F40C0108 F8000018
	s_load_b64 s[18:19], s[16:17], null                        // 0000002BDAC8: F4040488 F8000000
	s_waitcnt lgkmcnt(0)                                       // 0000002BDAD0: BF89FC07
	.long 0xd4540003                                           // 0000002BDAD4: D4540003
	v_cndmask_b32_e32 v0, s10, v136, vcc_lo                    // 0000002BDAD8: 0201100A
	s_and_b32 s12, s3, exec_lo                                 // 0000002BDADC: 8B0C7E03
	s_load_b128 s[12:15], s[0:1], 0x128                        // 0000002BDAE0: F4080300 F8000128
	s_clause 0x1                                               // 0000002BDAE8: BF850001
	global_load_b32 v1, v1, s[18:19]                           // 0000002BDAEC: DC520000 01120001
	global_load_b32 v3, v3, s[18:19]                           // 0000002BDAF4: DC520000 03120003
	s_cselect_b32 s24, 1, 16                                   // 0000002BDAFC: 98189081
	s_cselect_b32 s0, 0, 4                                     // 0000002BDB00: 98008480
	s_add_i32 s25, s24, -1                                     // 0000002BDB04: 8119C118
	v_lshrrev_b32_e32 v18, s0, v2                              // 0000002BDB08: 32240400
	v_and_b32_e32 v19, s25, v2                                 // 0000002BDB0C: 36260419
	s_waitcnt vmcnt(1)                                         // 0000002BDB10: BF8907F7
	v_bfe_u32 v4, v1, 16, 1                                    // 0000002BDB14: D6100004 02052101
	s_waitcnt vmcnt(0)                                         // 0000002BDB1C: BF8903F7
	v_bfe_u32 v5, v3, 16, 1                                    // 0000002BDB20: D6100005 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002BDB28: BF8701A2
	v_add3_u32 v1, v1, v4, 0x7fff                              // 0000002BDB2C: D6550001 03FE0901 00007FFF
	.long 0x7f083880                                           // 0000002BDB38: 7F083880
	v_add3_u32 v3, v3, v5, 0x7fff                              // 0000002BDB3C: D6550003 03FE0B03 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BDB48: BF870093
	.long 0x7e083981                                           // 0000002BDB4C: 7E083981
	v_and_or_b32 v1, 0xffff0000, v3, v4                        // 0000002BDB50: D6570001 041206FF FFFF0000
	ds_store_b32 v16, v1                                       // 0000002BDB5C: D8340000 00000110
	v_cvt_f32_ubyte0_e32 v1, s24                               // 0000002BDB64: 7E022218
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BDB68: BF870291
	v_rcp_iflag_f32_e32 v1, v1                                 // 0000002BDB6C: 7E025701
	v_readfirstlane_b32 s1, v1                                 // 0000002BDB70: 7E020501
	v_mov_b32_e32 v1, 0                                        // 0000002BDB74: 7E020280
	s_mul_f32 s22, s1, 0x4f7ffffe                              // 0000002BDB78: A216FF01 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3)                          // 0000002BDB80: BF87000B
	s_cvt_u32_f32 s26, s22                                     // 0000002BDB84: BE9A6716
	s_waitcnt lgkmcnt(0)                                       // 0000002BDB88: BF89FC07
	s_barrier                                                  // 0000002BDB8C: BFBD0000
	buffer_gl0_inv                                             // 0000002BDB90: E0AC0000 00000000
	s_load_b32 s20, s[16:17], 0x40                             // 0000002BDB98: F4000508 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002BDBA0: BF89FC07
	s_sub_i32 s0, s2, s20                                      // 0000002BDBA4: 81801402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BDBA8: BF870009
	s_ashr_i32 s1, s0, 31                                      // 0000002BDBAC: 86019F00
	s_and_b32 s3, s3, exec_lo                                  // 0000002BDBB0: 8B037E03
	s_cselect_b32 s3, 4, 0                                     // 0000002BDBB4: 98038084
	s_lshr_b32 s20, s15, 31                                    // 0000002BDBB8: 85149F0F
	s_lshl_b64 s[0:1], s[0:1], s3                              // 0000002BDBBC: 84800300
	s_add_u32 s20, s14, s20                                    // 0000002BDBC0: 8014140E
	s_addc_u32 s21, s15, 0                                     // 0000002BDBC4: 8215800F
	s_ashr_i32 s3, s15, 31                                     // 0000002BDBC8: 86039F0F
	s_ashr_i64 s[20:21], s[20:21], 1                           // 0000002BDBCC: 86948114
	s_lshr_b32 s3, s3, 27                                      // 0000002BDBD0: 85039B03
	.long 0xd7000009                                           // 0000002BDBD4: D7000009
	v_cndmask_b32_e32 v1, s0, v18, vcc_lo                      // 0000002BDBD8: 02022400
	s_add_u32 s22, s14, s3                                     // 0000002BDBDC: 8016030E
	s_addc_u32 s23, s15, 0                                     // 0000002BDBE0: 8217800F
	s_sub_i32 s3, 0, s24                                       // 0000002BDBE4: 81831880
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000002BDBE8: 85968516
	s_mul_i32 s3, s3, s26                                      // 0000002BDBEC: 96031A03
	s_add_i32 s23, s25, s22                                    // 0000002BDBF0: 81171619
	s_mul_hi_u32 s3, s26, s3                                   // 0000002BDBF4: 9683031A
	s_abs_i32 s27, s23                                         // 0000002BDBF8: BE9B1517
	s_add_i32 s26, s26, s3                                     // 0000002BDBFC: 811A031A
	v_add_co_ci_u32_e64 v10, null, s1, 0, s0                   // 0000002BDC00: D5207C0A 00010001
	s_mul_hi_u32 s3, s27, s26                                  // 0000002BDC08: 96831A1B
	s_ashr_i32 s1, s23, 31                                     // 0000002BDC0C: 86019F17
	s_mul_i32 s0, s3, s24                                      // 0000002BDC10: 96001803
	s_add_i32 s26, s3, 1                                       // 0000002BDC14: 811A8103
	s_sub_i32 s23, s27, s0                                     // 0000002BDC18: 8197001B
	.long 0xd4540000                                           // 0000002BDC1C: D4540000
	v_cndmask_b32_e32 v1, s10, v9, vcc_lo                      // 0000002BDC20: 0202120A
	s_sub_i32 s27, s23, s24                                    // 0000002BDC24: 819B1817
	s_cmp_ge_u32 s23, s24                                      // 0000002BDC28: BF091817
	s_cselect_b32 s3, s26, s3                                  // 0000002BDC2C: 9803031A
	s_cselect_b32 s23, s27, s23                                // 0000002BDC30: 9817171B
	s_add_i32 s26, s3, 1                                       // 0000002BDC34: 811A8103
	s_cmp_ge_u32 s23, s24                                      // 0000002BDC38: BF091817
	v_cndmask_b32_e64 v3, 0, v10, s0                           // 0000002BDC3C: D5010003 00021480
	s_cselect_b32 s3, s26, s3                                  // 0000002BDC44: 9803031A
	v_cndmask_b32_e64 v2, 0, v9, s0                            // 0000002BDC48: D5010002 00021280
	s_xor_b32 s3, s3, s1                                       // 0000002BDC50: 8D030103
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BDC54: BF870009
	s_sub_i32 s1, s3, s1                                       // 0000002BDC58: 81810103
	s_add_u32 s4, s18, s4                                      // 0000002BDC5C: 80040412
	s_addc_u32 s5, s19, s5                                     // 0000002BDC60: 82050513
	.long 0xd72c0004                                           // 0000002BDC64: D72C0004
	v_cndmask_b32_e32 v0, v3, v20, vcc_lo                      // 0000002BDC68: 02002903
	.long 0xd72c0007                                           // 0000002BDC6C: D72C0007
	v_cndmask_b32_e32 v0, v2, v21, vcc_lo                      // 0000002BDC70: 02002B02
	v_mad_u64_u32 v[11:12], null, v2, s20, s[4:5]              // 0000002BDC74: D6FE7C0B 00102902
	s_add_u32 s6, s18, s6                                      // 0000002BDC7C: 80060612
	.long 0xd72c0006                                           // 0000002BDC80: D72C0006
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000002BDC84: 02001103
	s_addc_u32 s7, s19, s7                                     // 0000002BDC88: 82070713
	.long 0xd72c0008                                           // 0000002BDC8C: D72C0008
	v_cndmask_b32_e32 v0, v2, v9, vcc_lo                       // 0000002BDC90: 02001302
	v_mad_u64_u32 v[13:14], null, v2, s8, s[6:7]               // 0000002BDC94: D6FE7C0D 00181102
	.long 0xd4510003                                           // 0000002BDC9C: D4510003
	v_cndmask_b32_e32 v0, s10, v137, vcc_lo                    // 0000002BDCA0: 0201120A
	v_mov_b32_e32 v2, 0                                        // 0000002BDCA4: 7E040280
	v_add3_u32 v12, v4, v12, v7                                // 0000002BDCA8: D655000C 041E1904
	v_mov_b32_e32 v4, 0                                        // 0000002BDCB0: 7E080280
	.long 0xd72c0005                                           // 0000002BDCB4: D72C0005
	v_cndmask_b32_e32 v1, s1, v19, vcc_lo                      // 0000002BDCB8: 02022601
	v_add3_u32 v23, v6, v14, v8                                // 0000002BDCBC: D6550017 04221D06
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BDCC4: BF870122
	v_add_nc_u32_e32 v3, s1, v5                                // 0000002BDCC8: 4A060A01
	v_add_nc_u32_e32 v21, v5, v17                              // 0000002BDCCC: 4A2A2305
	v_min_i32_e32 v22, s22, v3                                 // 0000002BDCD0: 222C0616
	v_mov_b32_e32 v3, 0                                        // 0000002BDCD4: 7E060280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002BDCD8: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v21, v22                          // 0000002BDCDC: 7C822D15
	s_and_saveexec_b32 s4, vcc_lo                              // 0000002BDCE0: BE84206A
	s_cbranch_execz 21                                         // 0000002BDCE4: BFA50015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x33c>
	v_lshlrev_b32_e32 v1, 1, v21                               // 0000002BDCE8: 30022A81
	v_lshlrev_b32_e32 v3, 4, v21                               // 0000002BDCEC: 30062A84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BDCF0: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002BDCF4: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002BDCF8: 3408069F
	.long 0xd7000101                                           // 0000002BDCFC: D7000101
	v_cndmask_b32_e32 v1, v13, v1, vcc_lo                      // 0000002BDD00: 0202030D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BDD04: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v23, v2, s1                  // 0000002BDD08: D5207C02 00060517
	.long 0xd7000103                                           // 0000002BDD10: D7000103
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 0000002BDD14: 0202070B
	v_add_co_ci_u32_e64 v4, null, v12, v4, s1                  // 0000002BDD18: D5207C04 0006090C
	s_clause 0x1                                               // 0000002BDD20: BF850001
	global_load_d16_b16 v6, v[1:2], off                        // 0000002BDD24: DC820000 067C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000002BDD2C: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000002BDD34: BF8907F7
	v_cvt_f32_f16_e32 v24, v6                                  // 0000002BDD38: 7E301706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000002BDD3C: 8C7E047E
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 0000002BDD40: CA100080 1A1A0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0             // 0000002BDD48: CA100080 1C1C0080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v25, 0             // 0000002BDD50: CA100080 1E180080
	s_and_saveexec_b32 s8, vcc_lo                              // 0000002BDD58: BE88206A
	s_cbranch_execz 526                                        // 0000002BDD5C: BFA5020E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xb98>
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v6, 5, v17     // 0000002BDD60: CA220080 19062285
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v7, 16, v21     // 0000002BDD68: CA200080 1E062A90
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0             // 0000002BDD70: CA100080 1B1A0080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BDD78: BF870193
	v_lshl_add_u32 v14, v5, 5, v6                              // 0000002BDD7C: D646000E 04190B05
	v_dual_mov_b32 v28, 0 :: v_dual_lshlrev_b32 v31, 4, v7     // 0000002BDD84: CA220080 1C1E0E84
	v_dual_mov_b32 v29, 0 :: v_dual_lshlrev_b32 v32, 1, v7     // 0000002BDD8C: CA220080 1D200E81
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v33, v24           // 0000002BDD94: CA100080 14200118
	s_mul_i32 s1, s15, 6                                       // 0000002BDD9C: 9601860F
	s_mul_hi_u32 s6, s14, 6                                    // 0000002BDDA0: 9686860E
	s_lshl_b64 s[4:5], s[14:15], 2                             // 0000002BDDA4: 8484820E
	s_add_i32 s9, s6, s1                                       // 0000002BDDA8: 81090106
	s_mul_i32 s19, s14, 6                                      // 0000002BDDAC: 9613860E
	s_mov_b32 s18, 0                                           // 0000002BDDB0: BE920080
	s_lshl_b64 s[6:7], s[14:15], 1                             // 0000002BDDB4: 8486810E
	s_branch 471                                               // 0000002BDDB8: BFA001D7 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xb18>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000002BDDBC: 8C7E0E7E
	v_ashrrev_i32_e32 v15, 31, v14                             // 0000002BDDC0: 341E1C9F
	v_lshrrev_b32_e32 v66, 6, v1                               // 0000002BDDC4: 32840286
	v_and_b32_e32 v68, 0xff, v2                                // 0000002BDDC8: 368804FF 000000FF
	v_lshrrev_b32_e32 v69, 6, v2                               // 0000002BDDD0: 328A0486
	v_lshrrev_b32_e32 v74, 14, v2                              // 0000002BDDD4: 3294048E
	.long 0xd73c0022                                           // 0000002BDDD8: D73C0022
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000002BDDDC: 02021C81
	v_and_b32_e32 v15, 0xff, v1                                // 0000002BDDE0: 361E02FF 000000FF
	v_lshrrev_b32_e32 v75, 22, v2                              // 0000002BDDE8: 32960496
	v_and_b32_e32 v66, 0x3fc, v66                              // 0000002BDDEC: 368484FF 000003FC
	v_lshrrev_b32_e32 v67, 14, v1                              // 0000002BDDF4: 3286028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000002BDDF8: 32020296
	.long 0xd700015e                                           // 0000002BDDFC: D700015E
	v_cndmask_b32_e32 v1, s12, v34, vcc_lo                     // 0000002BDE00: 0202440C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002BDE04: BF8701A1
	v_add_co_ci_u32_e64 v95, null, s13, v35, s1                // 0000002BDE08: D5207C5F 0006460D
	v_lshlrev_b32_e32 v2, 2, v15                               // 0000002BDE10: 30041E82
	.long 0xd7000160                                           // 0000002BDE14: D7000160
	v_cndmask_b32_e32 v0, v94, v6, vcc_lo                      // 0000002BDE18: 02000D5E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BDE1C: BF870001
	v_add_co_ci_u32_e64 v97, null, s7, v95, s1                 // 0000002BDE20: D5207C61 0006BE07
	.long 0xd7000162                                           // 0000002BDE28: D7000162
	v_cndmask_b32_e32 v0, v94, v4, vcc_lo                      // 0000002BDE2C: 0200095E
	s_clause 0x1                                               // 0000002BDE30: BF850001
	global_load_b128 v[34:37], v[94:95], off                   // 0000002BDE34: DC5E0000 227C005E
	global_load_b128 v[90:93], v[96:97], off offset:32         // 0000002BDE3C: DC5E0020 5A7C0060
	v_add_co_ci_u32_e64 v99, null, s5, v95, s1                 // 0000002BDE44: D5207C63 0006BE05
	.long 0xd7000164                                           // 0000002BDE4C: D7000164
	v_cndmask_b32_e32 v0, v94, v19, vcc_lo                     // 0000002BDE50: 0200275E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BDE54: BF870001
	v_add_co_ci_u32_e64 v101, null, s9, v95, s1                // 0000002BDE58: D5207C65 0006BE09
	s_clause 0x2                                               // 0000002BDE60: BF850002
	global_load_b128 v[38:41], v[96:97], off                   // 0000002BDE64: DC5E0000 267C0060
	global_load_b128 v[42:45], v[98:99], off                   // 0000002BDE6C: DC5E0000 2A7C0062
	global_load_b128 v[46:49], v[100:101], off                 // 0000002BDE74: DC5E0000 2E7C0064
	.long 0xd7000166                                           // 0000002BDE7C: D7000166
	v_cndmask_b32_e32 v0, v98, v4, vcc_lo                      // 0000002BDE80: 02000962
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BDE84: BF8700A1
	v_add_co_ci_u32_e64 v103, null, s5, v99, s1                // 0000002BDE88: D5207C67 0006C605
	.long 0xd700016a                                           // 0000002BDE90: D700016A
	v_cndmask_b32_e32 v0, v100, v4, vcc_lo                     // 0000002BDE94: 02000964
	v_add_co_ci_u32_e64 v107, null, s5, v101, s1               // 0000002BDE98: D5207C6B 0006CA05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BDEA0: BF870094
	.long 0xd700016c                                           // 0000002BDEA4: D700016C
	v_cndmask_b32_e32 v0, v102, v4, vcc_lo                     // 0000002BDEA8: 02000966
	v_add_co_ci_u32_e64 v109, null, s5, v103, s1               // 0000002BDEAC: D5207C6D 0006CE05
	s_clause 0x3                                               // 0000002BDEB4: BF850003
	global_load_b128 v[50:53], v[102:103], off                 // 0000002BDEB8: DC5E0000 327C0066
	global_load_b128 v[54:57], v[106:107], off                 // 0000002BDEC0: DC5E0000 367C006A
	global_load_b128 v[58:61], v[108:109], off                 // 0000002BDEC8: DC5E0000 3A7C006C
	global_load_b128 v[62:65], v[94:95], off offset:16         // 0000002BDED0: DC5E0010 3E7C005E
	ds_load_b32 v104, v2                                       // 0000002BDED8: D8D80000 68000002
	ds_load_b32 v105, v66                                      // 0000002BDEE0: D8D80000 69000042
	s_waitcnt vmcnt(9)                                         // 0000002BDEE8: BF8927F7
	v_dual_mov_b32 v2, v6 :: v_dual_and_b32 v1, 0x3fc, v1      // 0000002BDEEC: CA240106 020002FF 000003FC
	v_and_b32_e32 v6, 0x3fc, v67                               // 0000002BDEF8: 360C86FF 000003FC
	v_and_b32_e32 v110, 0xff, v3                               // 0000002BDF00: 36DC06FF 000000FF
	v_lshrrev_b32_e32 v111, 6, v3                              // 0000002BDF08: 32DE0686
	v_lshrrev_b32_e32 v112, 14, v3                             // 0000002BDF0C: 32E0068E
	v_lshrrev_b32_e32 v113, 22, v3                             // 0000002BDF10: 32E20696
	ds_load_b32 v117, v6                                       // 0000002BDF14: D8D80000 75000006
	v_and_b32_e32 v114, 0xff, v4                               // 0000002BDF1C: 36E408FF 000000FF
	v_lshrrev_b32_e32 v15, 6, v4                               // 0000002BDF24: 321E0886
	v_lshrrev_b32_e32 v115, 14, v4                             // 0000002BDF28: 32E6088E
	v_lshrrev_b32_e32 v116, 22, v4                             // 0000002BDF2C: 32E80896
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 0000002BDF30: CA100108 04020107
	v_lshlrev_b32_e32 v7, 2, v68                               // 0000002BDF38: 300E8882
	v_and_b32_e32 v8, 0x3fc, v69                               // 0000002BDF3C: 36108AFF 000003FC
	s_clause 0x1                                               // 0000002BDF44: BF850001
	global_load_b128 v[66:69], v[96:97], off offset:16         // 0000002BDF48: DC5E0010 427C0060
	global_load_b128 v[70:73], v[98:99], off offset:16         // 0000002BDF50: DC5E0010 467C0062
	v_and_b32_e32 v6, 0x3fc, v74                               // 0000002BDF58: 360C94FF 000003FC
	v_and_b32_e32 v74, 0x3fc, v75                              // 0000002BDF60: 369496FF 000003FC
	ds_load_b32 v118, v1                                       // 0000002BDF68: D8D80000 76000001
	ds_load_b32 v119, v7                                       // 0000002BDF70: D8D80000 77000007
	ds_load_b32 v120, v8                                       // 0000002BDF78: D8D80000 78000008
	ds_load_b32 v121, v6                                       // 0000002BDF80: D8D80000 79000006
	ds_load_b32 v122, v74                                      // 0000002BDF88: D8D80000 7A00004A
	v_mov_b32_e32 v1, v5                                       // 0000002BDF90: 7E020305
	s_clause 0x4                                               // 0000002BDF94: BF850004
	global_load_b128 v[5:8], v[102:103], off offset:16         // 0000002BDF98: DC5E0010 057C0066
	global_load_b128 v[78:81], v[106:107], off offset:16       // 0000002BDFA0: DC5E0010 4E7C006A
	global_load_b128 v[74:77], v[100:101], off offset:16       // 0000002BDFA8: DC5E0010 4A7C0064
	global_load_b128 v[82:85], v[94:95], off offset:32         // 0000002BDFB0: DC5E0020 527C005E
	global_load_b128 v[86:89], v[108:109], off offset:16       // 0000002BDFB8: DC5E0010 567C006C
	v_lshlrev_b32_e32 v110, 2, v110                            // 0000002BDFC0: 30DCDC82
	v_and_b32_e32 v111, 0x3fc, v111                            // 0000002BDFC4: 36DEDEFF 000003FC
	v_and_b32_e32 v112, 0x3fc, v112                            // 0000002BDFCC: 36E0E0FF 000003FC
	v_and_b32_e32 v113, 0x3fc, v113                            // 0000002BDFD4: 36E2E2FF 000003FC
	v_lshlrev_b32_e32 v114, 2, v114                            // 0000002BDFDC: 30E4E482
	v_and_b32_e32 v15, 0x3fc, v15                              // 0000002BDFE0: 361E1EFF 000003FC
	v_and_b32_e32 v115, 0x3fc, v115                            // 0000002BDFE8: 36E6E6FF 000003FC
	v_and_b32_e32 v116, 0x3fc, v116                            // 0000002BDFF0: 36E8E8FF 000003FC
	ds_load_b32 v110, v110                                     // 0000002BDFF8: D8D80000 6E00006E
	ds_load_b32 v111, v111                                     // 0000002BE000: D8D80000 6F00006F
	ds_load_b32 v112, v112                                     // 0000002BE008: D8D80000 70000070
	ds_load_b32 v113, v113                                     // 0000002BE010: D8D80000 71000071
	ds_load_b32 v114, v114                                     // 0000002BE018: D8D80000 72000072
	ds_load_b32 v15, v15                                       // 0000002BE020: D8D80000 0F00000F
	ds_load_b32 v115, v115                                     // 0000002BE028: D8D80000 73000073
	ds_load_b32 v116, v116                                     // 0000002BE030: D8D80000 74000074
	v_add_nc_u32_e32 v32, 32, v32                              // 0000002BE038: 4A4040A0
	v_add_nc_u32_e32 v14, 0x200, v14                           // 0000002BE03C: 4A1C1CFF 00000200
	s_and_b32 s1, exec_lo, vcc_lo                              // 0000002BE044: 8B016A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002BE048: BF8700C9
	s_or_b32 s18, s1, s18                                      // 0000002BE04C: 8C121201
	s_waitcnt vmcnt(15) lgkmcnt(15)                            // 0000002BE050: BF893CF7
	v_dot2_f32_bf16 v34, v34, v104, 0                          // 0000002BE054: CC1A4022 1A02D122
	s_waitcnt lgkmcnt(14)                                      // 0000002BE05C: BF89FCE7
	v_dot2_f32_bf16 v34, v35, v105, v34                        // 0000002BE060: CC1A4022 1C8AD323
	s_waitcnt vmcnt(13)                                        // 0000002BE068: BF8937F7
	v_dot2_f32_bf16 v38, v38, v104, 0                          // 0000002BE06C: CC1A4026 1A02D126
	s_waitcnt vmcnt(12)                                        // 0000002BE074: BF8933F7
	v_dot2_f32_bf16 v35, v42, v104, 0                          // 0000002BE078: CC1A4023 1A02D12A
	s_waitcnt lgkmcnt(13)                                      // 0000002BE080: BF89FCD7
	v_dot2_f32_bf16 v34, v36, v117, v34                        // 0000002BE084: CC1A4022 1C8AEB24
	v_dot2_f32_bf16 v38, v39, v105, v38                        // 0000002BE08C: CC1A4026 1C9AD327
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002BE094: BF870003
	v_dot2_f32_bf16 v42, v43, v105, v35                        // 0000002BE098: CC1A402A 1C8ED32B
	s_waitcnt vmcnt(11)                                        // 0000002BE0A0: BF892FF7
	v_dot2_f32_bf16 v39, v46, v104, 0                          // 0000002BE0A4: CC1A4027 1A02D12E
	s_waitcnt lgkmcnt(12)                                      // 0000002BE0AC: BF89FCC7
	v_dot2_f32_bf16 v123, v37, v118, v34                       // 0000002BE0B0: CC1A407B 1C8AED25
	global_load_b128 v[34:37], v[98:99], off offset:32         // 0000002BE0B8: DC5E0020 227C0062
	v_dot2_f32_bf16 v38, v40, v117, v38                        // 0000002BE0C0: CC1A4026 1C9AEB28
	v_dot2_f32_bf16 v42, v44, v117, v42                        // 0000002BE0C8: CC1A402A 1CAAEB2C
	v_dot2_f32_bf16 v43, v47, v105, v39                        // 0000002BE0D0: CC1A402B 1C9ED32F
	s_waitcnt vmcnt(11)                                        // 0000002BE0D8: BF892FF7
	v_dot2_f32_bf16 v44, v50, v104, 0                          // 0000002BE0DC: CC1A402C 1A02D132
	s_waitcnt vmcnt(10)                                        // 0000002BE0E4: BF892BF7
	v_dot2_f32_bf16 v46, v54, v104, 0                          // 0000002BE0E8: CC1A402E 1A02D136
	s_waitcnt vmcnt(9)                                         // 0000002BE0F0: BF8927F7
	v_dot2_f32_bf16 v47, v58, v104, 0                          // 0000002BE0F4: CC1A402F 1A02D13A
	v_dot2_f32_bf16 v124, v41, v118, v38                       // 0000002BE0FC: CC1A407C 1C9AED29
	v_dot2_f32_bf16 v43, v48, v117, v43                        // 0000002BE104: CC1A402B 1CAEEB30
	v_dot2_f32_bf16 v50, v51, v105, v44                        // 0000002BE10C: CC1A4032 1CB2D333
	v_dot2_f32_bf16 v51, v55, v105, v46                        // 0000002BE114: CC1A4033 1CBAD337
	global_load_b128 v[38:41], v[100:101], off offset:32       // 0000002BE11C: DC5E0020 267C0064
	v_dot2_f32_bf16 v125, v45, v118, v42                       // 0000002BE124: CC1A407D 1CAAED2D
	v_dot2_f32_bf16 v126, v49, v118, v43                       // 0000002BE12C: CC1A407E 1CAEED31
	v_dot2_f32_bf16 v50, v52, v117, v50                        // 0000002BE134: CC1A4032 1CCAEB34
	global_load_b128 v[42:45], v[102:103], off offset:32       // 0000002BE13C: DC5E0020 2A7C0066
	v_dot2_f32_bf16 v58, v59, v105, v47                        // 0000002BE144: CC1A403A 1CBED33B
	global_load_b128 v[46:49], v[106:107], off offset:32       // 0000002BE14C: DC5E0020 2E7C006A
	v_dot2_f32_bf16 v54, v56, v117, v51                        // 0000002BE154: CC1A4036 1CCEEB38
	v_dot2_f32_bf16 v127, v53, v118, v50                       // 0000002BE15C: CC1A407F 1CCAED35
	global_load_b128 v[50:53], v[108:109], off offset:32       // 0000002BE164: DC5E0020 327C006C
	s_waitcnt vmcnt(12) lgkmcnt(11)                            // 0000002BE16C: BF8930B7
	v_dot2_f32_bf16 v62, v62, v119, v123                       // 0000002BE170: CC1A403E 1DEEEF3E
	v_dot2_f32_bf16 v58, v60, v117, v58                        // 0000002BE178: CC1A403A 1CEAEB3C
	v_dot2_f32_bf16 v128, v57, v118, v54                       // 0000002BE180: CC1A4080 1CDAED39
	s_clause 0x1                                               // 0000002BE188: BF850001
	global_load_b128 v[54:57], v[94:95], off offset:48         // 0000002BE18C: DC5E0030 367C005E
	global_load_b128 v[94:97], v[96:97], off offset:48         // 0000002BE194: DC5E0030 5E7C0060
	s_waitcnt lgkmcnt(10)                                      // 0000002BE19C: BF89FCA7
	v_dot2_f32_bf16 v62, v63, v120, v62                        // 0000002BE1A0: CC1A403E 1CFAF13F
	v_dot2_f32_bf16 v117, v61, v118, v58                       // 0000002BE1A8: CC1A4075 1CEAED3D
	s_clause 0x2                                               // 0000002BE1B0: BF850002
	global_load_b128 v[58:61], v[98:99], off offset:48         // 0000002BE1B4: DC5E0030 3A7C0062
	global_load_b128 v[98:101], v[100:101], off offset:48      // 0000002BE1BC: DC5E0030 627C0064
	global_load_b128 v[102:105], v[102:103], off offset:48     // 0000002BE1C4: DC5E0030 667C0066
	s_waitcnt lgkmcnt(9)                                       // 0000002BE1CC: BF89FC97
	v_dot2_f32_bf16 v62, v64, v121, v62                        // 0000002BE1D0: CC1A403E 1CFAF340
	s_waitcnt vmcnt(16)                                        // 0000002BE1D8: BF8943F7
	v_dot2_f32_bf16 v66, v66, v119, v124                       // 0000002BE1DC: CC1A4042 1DF2EF42
	s_waitcnt vmcnt(15)                                        // 0000002BE1E4: BF893FF7
	v_dot2_f32_bf16 v70, v70, v119, v125                       // 0000002BE1E8: CC1A4046 1DF6EF46
	s_waitcnt vmcnt(14)                                        // 0000002BE1F0: BF893BF7
	v_dot2_f32_bf16 v5, v5, v119, v127                         // 0000002BE1F4: CC1A4005 1DFEEF05
	s_waitcnt vmcnt(12)                                        // 0000002BE1FC: BF8933F7
	v_dot2_f32_bf16 v74, v74, v119, v126                       // 0000002BE200: CC1A404A 1DFAEF4A
	s_waitcnt lgkmcnt(8)                                       // 0000002BE208: BF89FC87
	v_dot2_f32_bf16 v118, v65, v122, v62                       // 0000002BE20C: CC1A4076 1CFAF541
	s_clause 0x1                                               // 0000002BE214: BF850001
	global_load_b128 v[62:65], v[106:107], off offset:48       // 0000002BE218: DC5E0030 3E7C006A
	global_load_b128 v[106:109], v[108:109], off offset:48     // 0000002BE220: DC5E0030 6A7C006C
	v_dot2_f32_bf16 v66, v67, v120, v66                        // 0000002BE228: CC1A4042 1D0AF143
	v_dot2_f32_bf16 v67, v71, v120, v70                        // 0000002BE230: CC1A4043 1D1AF147
	v_dot2_f32_bf16 v70, v78, v119, v128                       // 0000002BE238: CC1A4046 1E02EF4E
	v_dot2_f32_bf16 v5, v6, v120, v5                           // 0000002BE240: CC1A4005 1C16F106
	v_dot2_f32_bf16 v71, v75, v120, v74                        // 0000002BE248: CC1A4047 1D2AF14B
	v_dot2_f32_bf16 v66, v68, v121, v66                        // 0000002BE250: CC1A4042 1D0AF344
	s_waitcnt vmcnt(12)                                        // 0000002BE258: BF8933F7
	v_dot2_f32_bf16 v68, v86, v119, v117                       // 0000002BE25C: CC1A4044 1DD6EF56
	v_dot2_f32_bf16 v70, v79, v120, v70                        // 0000002BE264: CC1A4046 1D1AF14F
	v_dot2_f32_bf16 v5, v7, v121, v5                           // 0000002BE26C: CC1A4005 1C16F307
	v_dot2_f32_bf16 v67, v72, v121, v67                        // 0000002BE274: CC1A4043 1D0EF348
	v_dot2_f32_bf16 v6, v76, v121, v71                         // 0000002BE27C: CC1A4006 1D1EF34C
	v_dot2_f32_bf16 v7, v87, v120, v68                         // 0000002BE284: CC1A4007 1D12F157
	v_dot2_f32_bf16 v68, v80, v121, v70                        // 0000002BE28C: CC1A4044 1D1AF350
	v_dot2_f32_bf16 v66, v69, v122, v66                        // 0000002BE294: CC1A4042 1D0AF545
	v_dot2_f32_bf16 v67, v73, v122, v67                        // 0000002BE29C: CC1A4043 1D0EF549
	s_waitcnt lgkmcnt(7)                                       // 0000002BE2A4: BF89FC77
	v_dot2_f32_bf16 v69, v82, v110, v118                       // 0000002BE2A8: CC1A4045 1DDADD52
	v_dot2_f32_bf16 v7, v88, v121, v7                          // 0000002BE2B0: CC1A4007 1C1EF358
	v_dot2_f32_bf16 v6, v77, v122, v6                          // 0000002BE2B8: CC1A4006 1C1AF54D
	v_dot2_f32_bf16 v5, v8, v122, v5                           // 0000002BE2C0: CC1A4005 1C16F508
	v_dot2_f32_bf16 v8, v81, v122, v68                         // 0000002BE2C8: CC1A4008 1D12F551
	s_waitcnt lgkmcnt(6)                                       // 0000002BE2D0: BF89FC67
	v_dot2_f32_bf16 v68, v83, v111, v69                        // 0000002BE2D4: CC1A4044 1D16DF53
	v_dot2_f32_bf16 v7, v89, v122, v7                          // 0000002BE2DC: CC1A4007 1C1EF559
	v_dot2_f32_bf16 v66, v90, v110, v66                        // 0000002BE2E4: CC1A4042 1D0ADD5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002BE2EC: BF8700B1
	v_dot2_f32_bf16 v66, v91, v111, v66                        // 0000002BE2F0: CC1A4042 1D0ADF5B
	s_waitcnt vmcnt(11)                                        // 0000002BE2F8: BF892FF7
	v_dot2_f32_bf16 v34, v34, v110, v67                        // 0000002BE2FC: CC1A4022 1D0EDD22
	v_dot2_f32_bf16 v34, v35, v111, v34                        // 0000002BE304: CC1A4022 1C8ADF23
	s_waitcnt lgkmcnt(5)                                       // 0000002BE30C: BF89FC57
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BE310: BF870001
	v_dot2_f32_bf16 v34, v36, v112, v34                        // 0000002BE314: CC1A4022 1C8AE124
	s_waitcnt vmcnt(10)                                        // 0000002BE31C: BF892BF7
	v_dot2_f32_bf16 v6, v38, v110, v6                          // 0000002BE320: CC1A4006 1C1ADD26
	v_dot2_f32_bf16 v38, v84, v112, v68                        // 0000002BE328: CC1A4026 1D12E154
	s_waitcnt vmcnt(9)                                         // 0000002BE330: BF8927F7
	v_dot2_f32_bf16 v5, v42, v110, v5                          // 0000002BE334: CC1A4005 1C16DD2A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002BE33C: BF870003
	v_dot2_f32_bf16 v6, v39, v111, v6                          // 0000002BE340: CC1A4006 1C1ADF27
	s_waitcnt vmcnt(8)                                         // 0000002BE348: BF8923F7
	v_dot2_f32_bf16 v8, v46, v110, v8                          // 0000002BE34C: CC1A4008 1C22DD2E
	s_waitcnt lgkmcnt(4)                                       // 0000002BE354: BF89FC47
	v_dot2_f32_bf16 v35, v85, v113, v38                        // 0000002BE358: CC1A4023 1C9AE355
	v_dot2_f32_bf16 v38, v92, v112, v66                        // 0000002BE360: CC1A4026 1D0AE15C
	s_waitcnt vmcnt(7)                                         // 0000002BE368: BF891FF7
	v_dot2_f32_bf16 v7, v50, v110, v7                          // 0000002BE36C: CC1A4007 1C1EDD32
	v_dot2_f32_bf16 v5, v43, v111, v5                          // 0000002BE374: CC1A4005 1C16DF2B
	v_dot2_f32_bf16 v8, v47, v111, v8                          // 0000002BE37C: CC1A4008 1C22DF2F
	v_dot2_f32_bf16 v6, v40, v112, v6                          // 0000002BE384: CC1A4006 1C1AE128
	v_dot2_f32_bf16 v36, v93, v113, v38                        // 0000002BE38C: CC1A4024 1C9AE35D
	v_dot2_f32_bf16 v7, v51, v111, v7                          // 0000002BE394: CC1A4007 1C1EDF33
	v_dot2_f32_bf16 v5, v44, v112, v5                          // 0000002BE39C: CC1A4005 1C16E12C
	v_dot2_f32_bf16 v8, v48, v112, v8                          // 0000002BE3A4: CC1A4008 1C22E130
	v_dot2_f32_bf16 v34, v37, v113, v34                        // 0000002BE3AC: CC1A4022 1C8AE325
	v_dot2_f32_bf16 v6, v41, v113, v6                          // 0000002BE3B4: CC1A4006 1C1AE329
	v_dot2_f32_bf16 v7, v52, v112, v7                          // 0000002BE3BC: CC1A4007 1C1EE134
	v_dot2_f32_bf16 v5, v45, v113, v5                          // 0000002BE3C4: CC1A4005 1C16E32D
	v_dot2_f32_bf16 v8, v49, v113, v8                          // 0000002BE3CC: CC1A4008 1C22E331
	s_waitcnt vmcnt(6) lgkmcnt(3)                              // 0000002BE3D4: BF891837
	v_dot2_f32_bf16 v35, v54, v114, v35                        // 0000002BE3D8: CC1A4023 1C8EE536
	s_waitcnt vmcnt(5)                                         // 0000002BE3E0: BF8917F7
	v_dot2_f32_bf16 v36, v94, v114, v36                        // 0000002BE3E4: CC1A4024 1C92E55E
	v_dot2_f32_bf16 v7, v53, v113, v7                          // 0000002BE3EC: CC1A4007 1C1EE335
	s_waitcnt vmcnt(4)                                         // 0000002BE3F4: BF8913F7
	v_dot2_f32_bf16 v34, v58, v114, v34                        // 0000002BE3F8: CC1A4022 1C8AE53A
	s_waitcnt vmcnt(3)                                         // 0000002BE400: BF890FF7
	v_dot2_f32_bf16 v6, v98, v114, v6                          // 0000002BE404: CC1A4006 1C1AE562
	s_waitcnt vmcnt(2)                                         // 0000002BE40C: BF890BF7
	v_dot2_f32_bf16 v5, v102, v114, v5                         // 0000002BE410: CC1A4005 1C16E566
	s_waitcnt vmcnt(1)                                         // 0000002BE418: BF8907F7
	v_dot2_f32_bf16 v8, v62, v114, v8                          // 0000002BE41C: CC1A4008 1C22E53E
	s_waitcnt vmcnt(0)                                         // 0000002BE424: BF8903F7
	v_dot2_f32_bf16 v7, v106, v114, v7                         // 0000002BE428: CC1A4007 1C1EE56A
	s_waitcnt lgkmcnt(2)                                       // 0000002BE430: BF89FC27
	v_dot2_f32_bf16 v35, v55, v15, v35                         // 0000002BE434: CC1A4023 1C8E1F37
	v_dot2_f32_bf16 v36, v95, v15, v36                         // 0000002BE43C: CC1A4024 1C921F5F
	v_dot2_f32_bf16 v34, v59, v15, v34                         // 0000002BE444: CC1A4022 1C8A1F3B
	v_dot2_f32_bf16 v6, v99, v15, v6                           // 0000002BE44C: CC1A4006 1C1A1F63
	v_dot2_f32_bf16 v5, v103, v15, v5                          // 0000002BE454: CC1A4005 1C161F67
	v_dot2_f32_bf16 v8, v63, v15, v8                           // 0000002BE45C: CC1A4008 1C221F3F
	v_dot2_f32_bf16 v7, v107, v15, v7                          // 0000002BE464: CC1A4007 1C1E1F6B
	s_waitcnt lgkmcnt(1)                                       // 0000002BE46C: BF89FC17
	v_dot2_f32_bf16 v35, v56, v115, v35                        // 0000002BE470: CC1A4023 1C8EE738
	v_dot2_f32_bf16 v36, v96, v115, v36                        // 0000002BE478: CC1A4024 1C92E760
	v_dot2_f32_bf16 v34, v60, v115, v34                        // 0000002BE480: CC1A4022 1C8AE73C
	v_dot2_f32_bf16 v6, v100, v115, v6                         // 0000002BE488: CC1A4006 1C1AE764
	v_dot2_f32_bf16 v5, v104, v115, v5                         // 0000002BE490: CC1A4005 1C16E768
	v_dot2_f32_bf16 v8, v64, v115, v8                          // 0000002BE498: CC1A4008 1C22E740
	v_dot2_f32_bf16 v7, v108, v115, v7                         // 0000002BE4A0: CC1A4007 1C1EE76C
	s_waitcnt lgkmcnt(0)                                       // 0000002BE4A8: BF89FC07
	v_dot2_f32_bf16 v35, v57, v116, v35                        // 0000002BE4AC: CC1A4023 1C8EE939
	v_dot2_f32_bf16 v15, v97, v116, v36                        // 0000002BE4B4: CC1A400F 1C92E961
	v_dot2_f32_bf16 v34, v61, v116, v34                        // 0000002BE4BC: CC1A4022 1C8AE93D
	v_dot2_f32_bf16 v6, v101, v116, v6                         // 0000002BE4C4: CC1A4006 1C1AE965
	v_dot2_f32_bf16 v5, v105, v116, v5                         // 0000002BE4CC: CC1A4005 1C16E969
	v_dot2_f32_bf16 v8, v65, v116, v8                          // 0000002BE4D4: CC1A4008 1C22E941
	v_dot2_f32_bf16 v7, v109, v116, v7                         // 0000002BE4DC: CC1A4007 1C1EE96D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002BE4E4: BF870004
	v_dual_fmac_f32 v28, v24, v6 :: v_dual_add_nc_u32 v31, 0x100, v31// 0000002BE4E8: C8200D18 1C1E3EFF 00000100
	v_fmac_f32_e32 v25, v24, v35                               // 0000002BE4F4: 56324718
	v_fmac_f32_e32 v30, v24, v15                               // 0000002BE4F8: 563C1F18
	v_fmac_f32_e32 v29, v24, v34                               // 0000002BE4FC: 563A4518
	v_fmac_f32_e32 v27, v24, v5                                // 0000002BE500: 56360B18
	v_fmac_f32_e32 v26, v24, v8                                // 0000002BE504: 56341118
	v_fmac_f32_e32 v20, v24, v7                                // 0000002BE508: 56280F18
	v_mov_b32_e32 v24, v33                                     // 0000002BE50C: 7E300321
	s_and_not1_b32 exec_lo, exec_lo, s18                       // 0000002BE510: 917E127E
	s_cbranch_execz 31                                         // 0000002BE514: BFA5001F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xb94>
	s_waitcnt vmcnt(0)                                         // 0000002BE518: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v21, 16, v21    // 0000002BE51C: CA200102 06142A90
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000002BE524: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000002BE52C: 7E0E0303
	s_mov_b32 s14, exec_lo                                     // 0000002BE530: BE8E007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002BE534: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v21, v22                          // 0000002BE538: 7C8C2D15
	.long 0xd4c1007e                                           // 0000002BE53C: D4C1007E
	v_cndmask_b32_e32 v1, v21, v22, vcc_lo                     // 0000002BE540: 02022D15
	s_cbranch_execz 65053                                      // 0000002BE544: BFA5FE1D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3bc>
	v_ashrrev_i32_e32 v6, 31, v32                              // 0000002BE548: 340C409F
	v_ashrrev_i32_e32 v8, 31, v31                              // 0000002BE54C: 34103E9F
	.long 0xd7000105                                           // 0000002BE550: D7000105
	v_cndmask_b32_e32 v1, v13, v32, vcc_lo                     // 0000002BE554: 0202410D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BE558: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v23, v6, s1                  // 0000002BE55C: D5207C06 00060D17
	.long 0xd7000107                                           // 0000002BE564: D7000107
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 0000002BE568: 02023F0B
	v_add_co_ci_u32_e64 v8, null, v12, v8, s1                  // 0000002BE56C: D5207C08 0006110C
	s_clause 0x1                                               // 0000002BE574: BF850001
	global_load_d16_b16 v15, v[5:6], off                       // 0000002BE578: DC820000 0F7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 0000002BE580: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 0000002BE588: BF8907F7
	v_cvt_f32_f16_e32 v33, v15                                 // 0000002BE58C: 7E42170F
	s_branch 65034                                             // 0000002BE590: BFA0FE0A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3bc>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000002BE594: 8C7E127E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000002BE598: BF870149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000002BE59C: 8C7E087E
	s_waitcnt vmcnt(0)                                         // 0000002BE5A0: BF8903F7
	.long 0xd71f0001                                           // 0000002BE5A4: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002BE5A8: 020100C1
	.long 0xd44a0001                                           // 0000002BE5AC: D44A0001
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 0000002BE5B0: 02022280
	v_xor_b32_e32 v2, 8, v1                                    // 0000002BE5B4: 3A040288
	v_xor_b32_e32 v11, 4, v1                                   // 0000002BE5B8: 3A160284
	v_xor_b32_e32 v22, 2, v1                                   // 0000002BE5BC: 3A2C0282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002BE5C0: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000002BE5C4: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000002BE5C8: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 0000002BE5CC: 7C9816A0
	v_cndmask_b32_e32 v11, v1, v11, vcc_lo                     // 0000002BE5D0: 02161701
	v_cmp_gt_u32_e32 vcc_lo, 32, v22                           // 0000002BE5D4: 7C982CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002BE5D8: BF870002
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000002BE5DC: 30161682
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000002BE5E0: 30040482
	ds_bpermute_b32 v3, v2, v25                                // 0000002BE5E4: DACC0000 03001902
	s_waitcnt lgkmcnt(0)                                       // 0000002BE5EC: BF89FC07
	v_add_f32_e32 v3, v25, v3                                  // 0000002BE5F0: 06060719
	ds_bpermute_b32 v7, v2, v27                                // 0000002BE5F4: DACC0000 07001B02
	ds_bpermute_b32 v4, v2, v30                                // 0000002BE5FC: DACC0000 04001E02
	ds_bpermute_b32 v5, v2, v29                                // 0000002BE604: DACC0000 05001D02
	ds_bpermute_b32 v6, v2, v28                                // 0000002BE60C: DACC0000 06001C02
	ds_bpermute_b32 v8, v2, v26                                // 0000002BE614: DACC0000 08001A02
	ds_bpermute_b32 v2, v2, v20                                // 0000002BE61C: DACC0000 02001402
	ds_bpermute_b32 v12, v11, v3                               // 0000002BE624: DACC0000 0C00030B
	s_waitcnt lgkmcnt(5)                                       // 0000002BE62C: BF89FC57
	v_dual_add_f32 v7, v27, v7 :: v_dual_add_f32 v4, v30, v4   // 0000002BE630: C9080F1B 0704091E
	s_waitcnt lgkmcnt(3)                                       // 0000002BE638: BF89FC37
	v_dual_add_f32 v5, v29, v5 :: v_dual_add_f32 v6, v28, v6   // 0000002BE63C: C9080B1D 05060D1C
	s_waitcnt lgkmcnt(2)                                       // 0000002BE644: BF89FC27
	v_add_f32_e32 v8, v26, v8                                  // 0000002BE648: 0610111A
	s_waitcnt lgkmcnt(0)                                       // 0000002BE64C: BF89FC07
	v_dual_add_f32 v2, v20, v2 :: v_dual_add_f32 v3, v3, v12   // 0000002BE650: C9080514 02021903
	ds_bpermute_b32 v20, v11, v7                               // 0000002BE658: DACC0000 1400070B
	ds_bpermute_b32 v13, v11, v4                               // 0000002BE660: DACC0000 0D00040B
	ds_bpermute_b32 v14, v11, v5                               // 0000002BE668: DACC0000 0E00050B
	ds_bpermute_b32 v15, v11, v6                               // 0000002BE670: DACC0000 0F00060B
	ds_bpermute_b32 v21, v11, v8                               // 0000002BE678: DACC0000 1500080B
	ds_bpermute_b32 v11, v11, v2                               // 0000002BE680: DACC0000 0B00020B
	s_waitcnt lgkmcnt(5)                                       // 0000002BE688: BF89FC57
	v_dual_cndmask_b32 v22, v1, v22 :: v_dual_add_f32 v7, v7, v20// 0000002BE68C: CA482D01 16062907
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BE694: BF870001
	v_lshlrev_b32_e32 v22, 2, v22                              // 0000002BE698: 302C2C82
	s_waitcnt lgkmcnt(3)                                       // 0000002BE69C: BF89FC37
	v_dual_add_f32 v4, v4, v13 :: v_dual_add_f32 v5, v5, v14   // 0000002BE6A0: C9081B04 04041D05
	s_waitcnt lgkmcnt(2)                                       // 0000002BE6A8: BF89FC27
	v_add_f32_e32 v6, v6, v15                                  // 0000002BE6AC: 060C1F06
	s_waitcnt lgkmcnt(0)                                       // 0000002BE6B0: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 0000002BE6B4: 06041702
	ds_bpermute_b32 v11, v22, v3                               // 0000002BE6B8: DACC0000 0B000316
	s_waitcnt lgkmcnt(0)                                       // 0000002BE6C0: BF89FC07
	v_add_f32_e32 v3, v3, v11                                  // 0000002BE6C4: 06061703
	ds_bpermute_b32 v15, v22, v7                               // 0000002BE6C8: DACC0000 0F000716
	v_add_f32_e32 v8, v8, v21                                  // 0000002BE6D0: 06102B08
	ds_bpermute_b32 v12, v22, v4                               // 0000002BE6D4: DACC0000 0C000416
	ds_bpermute_b32 v13, v22, v5                               // 0000002BE6DC: DACC0000 0D000516
	ds_bpermute_b32 v14, v22, v6                               // 0000002BE6E4: DACC0000 0E000616
	ds_bpermute_b32 v21, v22, v2                               // 0000002BE6EC: DACC0000 15000216
	s_waitcnt lgkmcnt(4)                                       // 0000002BE6F4: BF89FC47
	v_add_f32_e32 v7, v7, v15                                  // 0000002BE6F8: 060E1F07
	ds_bpermute_b32 v20, v22, v8                               // 0000002BE6FC: DACC0000 14000816
	v_xor_b32_e32 v22, 1, v1                                   // 0000002BE704: 3A2C0281
	s_waitcnt lgkmcnt(3)                                       // 0000002BE708: BF89FC37
	v_dual_add_f32 v4, v4, v12 :: v_dual_add_f32 v5, v5, v13   // 0000002BE70C: C9081904 04041B05
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002BE714: BF870002
	v_cmp_gt_u32_e32 vcc_lo, 32, v22                           // 0000002BE718: 7C982CA0
	v_cndmask_b32_e32 v1, v1, v22, vcc_lo                      // 0000002BE71C: 02022D01
	s_waitcnt lgkmcnt(2)                                       // 0000002BE720: BF89FC27
	v_add_f32_e32 v6, v6, v14                                  // 0000002BE724: 060C1D06
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000002BE728: 8B6A037E
	s_mov_b32 s3, -1                                           // 0000002BE72C: BE8300C1
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002BE730: 30020282
	s_waitcnt lgkmcnt(0)                                       // 0000002BE734: BF89FC07
	v_add_f32_e32 v11, v8, v20                                 // 0000002BE738: 06162908
	ds_bpermute_b32 v8, v1, v3                                 // 0000002BE73C: DACC0000 08000301
	v_add_f32_e32 v2, v2, v21                                  // 0000002BE744: 06042B02
	ds_bpermute_b32 v12, v1, v4                                // 0000002BE748: DACC0000 0C000401
	ds_bpermute_b32 v13, v1, v5                                // 0000002BE750: DACC0000 0D000501
	ds_bpermute_b32 v20, v1, v6                                // 0000002BE758: DACC0000 14000601
	ds_bpermute_b32 v21, v1, v7                                // 0000002BE760: DACC0000 15000701
	ds_bpermute_b32 v22, v1, v11                               // 0000002BE768: DACC0000 16000B01
	s_waitcnt lgkmcnt(5)                                       // 0000002BE770: BF89FC57
	v_add_f32_e32 v17, v3, v8                                  // 0000002BE774: 06221103
	ds_bpermute_b32 v1, v1, v2                                 // 0000002BE778: DACC0000 01000201
	s_waitcnt lgkmcnt(4)                                       // 0000002BE780: BF89FC47
	v_dual_add_f32 v15, v4, v12 :: v_dual_add_f32 v14, v5, v13 // 0000002BE784: C9081904 0F0E1B05
	s_waitcnt lgkmcnt(2)                                       // 0000002BE78C: BF89FC27
	v_dual_add_f32 v13, v6, v20 :: v_dual_add_f32 v8, v7, v21  // 0000002BE790: C9082906 0D082B07
	s_waitcnt lgkmcnt(0)                                       // 0000002BE798: BF89FC07
	v_dual_add_f32 v7, v11, v22 :: v_dual_add_f32 v6, v2, v1   // 0000002BE79C: C9082D0B 07060302
	s_cbranch_vccz 441                                         // 0000002BE7A4: BFA301B9 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x148c>
	s_and_saveexec_b32 s3, s1                                  // 0000002BE7A8: BE832001
	s_cbranch_execz 21                                         // 0000002BE7AC: BFA50015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xe04>
	v_lshl_or_b32 v1, v18, 4, v19                              // 0000002BE7B0: D6560001 044D0912
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BE7B8: BF870001
	v_mad_u32_u24 v2, v1, 28, 0x400                            // 0000002BE7BC: D60B0002 03FD3901 00000400
	v_mad_u32_u24 v3, v1, 28, 0x408                            // 0000002BE7C8: D60B0003 03FD3901 00000408
	v_mad_u32_u24 v4, v1, 28, 0x410                            // 0000002BE7D4: D60B0004 03FD3901 00000410
	v_mul_u32_u24_e32 v1, 28, v1                               // 0000002BE7E0: 1602029C
	ds_store_2addr_b32 v2, v17, v15 offset1:1                  // 0000002BE7E4: D8380100 000F1102
	ds_store_2addr_b32 v3, v14, v13 offset1:1                  // 0000002BE7EC: D8380100 000D0E03
	ds_store_2addr_b32 v4, v8, v7 offset1:1                    // 0000002BE7F4: D8380100 00070804
	ds_store_b32 v1, v6 offset:1048                            // 0000002BE7FC: D8340418 00000601
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002BE804: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BE808: BF870009
	s_mov_b32 s8, exec_lo                                      // 0000002BE80C: BE88007E
	s_waitcnt lgkmcnt(0)                                       // 0000002BE810: BF89FC07
	s_barrier                                                  // 0000002BE814: BFBD0000
	buffer_gl0_inv                                             // 0000002BE818: E0AC0000 00000000
	v_cmpx_gt_u32_e32 7, v0                                    // 0000002BE820: 7D980087
	s_cbranch_execz 407                                        // 0000002BE824: BFA50197 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1484>
	s_load_b32 s3, s[16:17], 0x40                              // 0000002BE828: F40000C8 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002BE830: BF89FC07
	s_sub_i32 s2, s2, s3                                       // 0000002BE834: 81820302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002BE838: BF870499
	s_ashr_i32 s3, s2, 31                                      // 0000002BE83C: 86039F02
	.long 0xd4530004                                           // 0000002BE840: D4530004
	v_cndmask_b32_e32 v0, s10, v2, vcc_lo                      // 0000002BE844: 0200040A
	s_and_b32 vcc_lo, exec_lo, s4                              // 0000002BE848: 8B6A047E
	s_cbranch_vccnz 397                                        // 0000002BE84C: BFA4018D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1484>
	v_add_nc_u32_e32 v5, 0x400, v16                            // 0000002BE850: 4A0A20FF 00000400
	s_clause 0x1                                               // 0000002BE858: BF850001
	s_load_b64 s[6:7], s[16:17], 0x38                          // 0000002BE85C: F4040188 F8000038
	s_load_b64 s[4:5], s[16:17], 0x8                           // 0000002BE864: F4040108 F8000008
	s_mov_b32 s9, 0                                            // 0000002BE86C: BE890080
	s_mov_b32 s13, -1                                          // 0000002BE870: BE8D00C1
	s_mov_b32 s12, 0                                           // 0000002BE874: BE8C0080
	ds_load_2addr_b32 v[1:2], v5 offset1:7                     // 0000002BE878: D8DC0700 01000005
	ds_load_2addr_b32 v[3:4], v5 offset0:14 offset1:21         // 0000002BE880: D8DC150E 03000005
	ds_load_2addr_b32 v[11:12], v5 offset0:28 offset1:35       // 0000002BE888: D8DC231C 0B000005
	s_waitcnt lgkmcnt(0)                                       // 0000002BE890: BF89FC07
	s_cmp_lt_i32 s7, 3                                         // 0000002BE894: BF048307
	v_add_f32_e32 v1, 0, v1                                    // 0000002BE898: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002BE89C: BF8700B1
	v_add_f32_e32 v16, v1, v2                                  // 0000002BE8A0: 06200501
	ds_load_2addr_b32 v[1:2], v5 offset0:42 offset1:49         // 0000002BE8A4: D8DC312A 01000005
	v_add_f32_e32 v3, v16, v3                                  // 0000002BE8AC: 06060710
	v_add_f32_e32 v16, v3, v4                                  // 0000002BE8B0: 06200903
	ds_load_2addr_b32 v[3:4], v5 offset0:56 offset1:63         // 0000002BE8B4: D8DC3F38 03000005
	v_add_f32_e32 v11, v16, v11                                // 0000002BE8BC: 06161710
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002BE8C0: BF8700C1
	v_add_f32_e32 v16, v11, v12                                // 0000002BE8C4: 0620190B
	ds_load_2addr_b32 v[11:12], v5 offset0:70 offset1:77       // 0000002BE8C8: D8DC4D46 0B000005
	s_waitcnt lgkmcnt(2)                                       // 0000002BE8D0: BF89FC27
	v_add_f32_e32 v1, v16, v1                                  // 0000002BE8D4: 06020310
	v_add_f32_e32 v1, v1, v2                                   // 0000002BE8D8: 06020501
	s_waitcnt lgkmcnt(1)                                       // 0000002BE8DC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002BE8E0: BF8700C1
	v_add_f32_e32 v3, v1, v3                                   // 0000002BE8E4: 06060701
	ds_load_2addr_b32 v[1:2], v5 offset0:84 offset1:91         // 0000002BE8E8: D8DC5B54 01000005
	v_add_f32_e32 v3, v3, v4                                   // 0000002BE8F0: 06060903
	s_waitcnt lgkmcnt(1)                                       // 0000002BE8F4: BF89FC17
	v_add_f32_e32 v11, v3, v11                                 // 0000002BE8F8: 06161703
	ds_load_2addr_b32 v[3:4], v5 offset0:98 offset1:105        // 0000002BE8FC: D8DC6962 03000005
	v_add_f32_e32 v5, v11, v12                                 // 0000002BE904: 060A190B
	s_waitcnt lgkmcnt(1)                                       // 0000002BE908: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BE90C: BF870091
	v_add_f32_e32 v1, v5, v1                                   // 0000002BE910: 06020305
	v_add_f32_e32 v1, v1, v2                                   // 0000002BE914: 06020501
	s_waitcnt lgkmcnt(0)                                       // 0000002BE918: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BE91C: BF870091
	v_add_f32_e32 v1, v1, v3                                   // 0000002BE920: 06020701
	v_add_f32_e32 v1, v1, v4                                   // 0000002BE924: 06020901
	s_cbranch_scc1 178                                         // 0000002BE928: BFA200B2 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x11f4>
	s_cmp_gt_i32 s7, 3                                         // 0000002BE92C: BF028307
	s_cbranch_scc0 112                                         // 0000002BE930: BFA10070 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x10f4>
	s_cmp_gt_i32 s7, 4                                         // 0000002BE934: BF028407
	s_cbranch_scc0 58                                          // 0000002BE938: BFA1003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1024>
	s_cmp_eq_u32 s7, 5                                         // 0000002BE93C: BF068507
	s_mov_b32 s12, -1                                          // 0000002BE940: BE8C00C1
	s_cbranch_scc0 54                                          // 0000002BE944: BFA10036 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1020>
	s_ashr_i32 s14, s2, 31                                     // 0000002BE948: 860E9F02
	s_load_b64 s[12:13], s[16:17], 0x10                        // 0000002BE94C: F4040308 F8000010
	s_lshr_b32 s14, s14, 23                                    // 0000002BE954: 850E970E
	s_lshr_b32 s15, s10, 31                                    // 0000002BE958: 850F9F0A
	s_add_i32 s14, s2, s14                                     // 0000002BE95C: 810E0E02
	s_add_i32 s18, s10, s15                                    // 0000002BE960: 81120F0A
	s_ashr_i32 s14, s14, 9                                     // 0000002BE964: 860E890E
	s_ashr_i32 s18, s18, 1                                     // 0000002BE968: 86128112
	s_ashr_i32 s15, s14, 31                                    // 0000002BE96C: 860F9F0E
	v_mad_i64_i32 v[2:3], null, s18, v0, 0                     // 0000002BE970: D6FF7C02 02020012
	s_lshl_b64 s[14:15], s[14:15], 9                           // 0000002BE978: 848E890E
	v_bfe_u32 v4, v1, 16, 1                                    // 0000002BE97C: D6100004 02052101
	s_sub_u32 s18, s2, s14                                     // 0000002BE984: 80920E02
	s_subb_u32 s19, s3, s15                                    // 0000002BE988: 82930F03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BE98C: BF870119
	.long 0xd4540014                                           // 0000002BE990: D4540014
	v_cndmask_b32_e32 v0, 0x100, v18, vcc_lo                   // 0000002BE994: 020024FF 00000100
	v_add3_u32 v4, v1, v4, 0x7fff                              // 0000002BE99C: D6550004 03FE0901 00007FFF
	.long 0xd73c0002                                           // 0000002BE9A8: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000002BE9AC: 02020481
	s_and_b32 s21, s20, exec_lo                                // 0000002BE9B0: 8B157E14
	s_waitcnt lgkmcnt(0)                                       // 0000002BE9B4: BF89FC07
	s_cselect_b32 s12, s4, s12                                 // 0000002BE9B8: 980C0C04
	s_cselect_b32 s21, s5, s13                                 // 0000002BE9BC: 98150D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BE9C0: BF870091
	.long 0xd7006a02                                           // 0000002BE9C4: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000002BE9C8: 0202040C
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo              // 0000002BE9CC: D5207C03 01AA0615
	s_add_u32 s22, s18, 0xffffff00                             // 0000002BE9D4: 8016FF12 FFFFFF00
	s_addc_u32 s13, s19, -1                                    // 0000002BE9DC: 820DC113
	s_and_b32 s20, s20, exec_lo                                // 0000002BE9E0: 8B147E14
	.long 0xd7006a02                                           // 0000002BE9E4: D7006A02
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 0000002BE9E8: 02001D02
	s_cselect_b32 s13, s19, s13                                // 0000002BE9EC: 980D0D13
	s_cselect_b32 s12, s18, s22                                // 0000002BE9F0: 980C1612
	v_add_co_ci_u32_e64 v3, null, s15, v3, vcc_lo              // 0000002BE9F4: D5207C03 01AA060F
	s_lshl_b64 s[12:13], s[12:13], 1                           // 0000002BE9FC: 848C810C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEA00: BF870099
	.long 0xd7006a02                                           // 0000002BEA04: D7006A02
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 0000002BEA08: 02001902
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 0000002BEA0C: D5207C03 01AA060D
	s_mov_b32 s12, 0                                           // 0000002BEA14: BE8C0080
	global_store_d16_hi_b16 v[2:3], v4, off                    // 0000002BEA18: DC960000 007C0402
	s_mov_b32 s13, 0                                           // 0000002BEA20: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BEA24: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002BEA28: 8B6A0D7E
	s_cbranch_vccz 48                                          // 0000002BEA2C: BFA30030 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x10f0>
	v_mul_f32_e32 v2, 0xbfb8aa3b, v1                           // 0000002BEA30: 100402FF BFB8AA3B
	s_lshl_b64 s[14:15], s[2:3], 2                             // 0000002BEA38: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BEA3C: BF870291
	v_exp_f32_e32 v2, v2                                       // 0000002BEA40: 7E044B02
	v_add_f32_e32 v5, 1.0, v2                                  // 0000002BEA44: 060A04F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEA48: BF870091
	v_div_scale_f32 v11, null, v5, v5, 1.0                     // 0000002BEA4C: D6FC7C0B 03CA0B05
	v_rcp_f32_e32 v12, v11                                     // 0000002BEA54: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEA58: BF870095
	v_fma_f32 v2, -v11, v12, 1.0                               // 0000002BEA5C: D6130002 23CA190B
	v_fmac_f32_e32 v12, v2, v12                                // 0000002BEA64: 56181902
	v_div_scale_f32 v16, vcc_lo, 1.0, v5, 1.0                  // 0000002BEA68: D6FC6A10 03CA0AF2
	v_mad_u64_u32 v[2:3], null, s10, v0, 0                     // 0000002BEA70: D6FE7C02 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BEA78: BF870112
	v_mul_f32_e32 v18, v16, v12                                // 0000002BEA7C: 10241910
	v_mad_u64_u32 v[3:4], null, s11, v0, v[3:4]                // 0000002BEA80: D6FE7C03 040E000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEA88: BF870092
	v_fma_f32 v19, -v11, v18, v16                              // 0000002BEA8C: D6130013 2442250B
	v_fmac_f32_e32 v18, v19, v12                               // 0000002BEA94: 56241913
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BEA98: BF870113
	.long 0xd73c0002                                           // 0000002BEA9C: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 0000002BEAA0: 02020482
	v_fma_f32 v4, -v11, v18, v16                               // 0000002BEAA4: D6130004 2442250B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BEAAC: BF870191
	v_div_fmas_f32 v4, v4, v12, v18                            // 0000002BEAB0: D6370004 044A1904
	.long 0xd7006a02                                           // 0000002BEAB8: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 0000002BEABC: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BEAC0: BF870191
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 0000002BEAC4: D5207C03 01AA0605
	v_div_fixup_f32 v4, v4, v5, 1.0                            // 0000002BEACC: D6270004 03CA0B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEAD4: BF870093
	.long 0xd7006a02                                           // 0000002BEAD8: D7006A02
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 0000002BEADC: 02001D02
	v_add_co_ci_u32_e64 v3, null, s15, v3, vcc_lo              // 0000002BEAE0: D5207C03 01AA060F
	global_store_b32 v[2:3], v4, off                           // 0000002BEAE8: DC6A0000 007C0402
	s_mov_b32 s13, 0                                           // 0000002BEAF0: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BEAF4: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002BEAF8: 8B6A0D7E
	s_cbranch_vccz 60                                          // 0000002BEAFC: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x11f0>
	v_bfe_u32 v2, v1, 16, 1                                    // 0000002BEB00: D6100002 02052101
	s_lshl_b64 s[14:15], s[2:3], 2                             // 0000002BEB08: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEB0C: BF870091
	v_add3_u32 v2, v1, v2, 0x7fff                              // 0000002BEB10: D6550002 03FE0501 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000002BEB1C: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEB24: BF870091
	v_mul_f32_e32 v2, s6, v2                                   // 0000002BEB28: 10040406
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 0000002BEB2C: 100404FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BEB34: BF870291
	v_exp_f32_e32 v2, v2                                       // 0000002BEB38: 7E044B02
	v_add_f32_e32 v5, 1.0, v2                                  // 0000002BEB3C: 060A04F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEB40: BF870091
	v_div_scale_f32 v11, null, v5, v5, 1.0                     // 0000002BEB44: D6FC7C0B 03CA0B05
	v_rcp_f32_e32 v12, v11                                     // 0000002BEB4C: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEB50: BF870095
	v_fma_f32 v2, -v11, v12, 1.0                               // 0000002BEB54: D6130002 23CA190B
	v_fmac_f32_e32 v12, v2, v12                                // 0000002BEB5C: 56181902
	v_div_scale_f32 v16, vcc_lo, 1.0, v5, 1.0                  // 0000002BEB60: D6FC6A10 03CA0AF2
	v_mad_u64_u32 v[2:3], null, s10, v0, 0                     // 0000002BEB68: D6FE7C02 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEB70: BF870092
	v_mul_f32_e32 v18, v16, v12                                // 0000002BEB74: 10241910
	v_fma_f32 v4, -v11, v18, v16                               // 0000002BEB78: D6130004 2442250B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002BEB80: BF870211
	v_fmac_f32_e32 v18, v4, v12                                // 0000002BEB84: 56241904
	v_mad_u64_u32 v[3:4], null, s11, v0, v[3:4]                // 0000002BEB88: D6FE7C03 040E000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BEB90: BF870112
	v_fma_f32 v4, -v11, v18, v16                               // 0000002BEB94: D6130004 2442250B
	.long 0xd73c0002                                           // 0000002BEB9C: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 0000002BEBA0: 02020482
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BEBA4: BF870112
	v_div_fmas_f32 v4, v4, v12, v18                            // 0000002BEBA8: D6370004 044A1904
	.long 0xd7006a02                                           // 0000002BEBB0: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 0000002BEBB4: 02020404
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002BEBB8: BF870212
	v_div_fixup_f32 v4, v4, v5, 1.0                            // 0000002BEBBC: D6270004 03CA0B04
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 0000002BEBC4: D5207C03 01AA0605
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BEBCC: BF870193
	.long 0xd7006a02                                           // 0000002BEBD0: D7006A02
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 0000002BEBD4: 02001D02
	v_add_f32_e32 v4, v4, v4                                   // 0000002BEBD8: 06080904
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002BEBDC: BF870003
	v_add_co_ci_u32_e64 v3, null, s15, v3, vcc_lo              // 0000002BEBE0: D5207C03 01AA060F
	global_store_b32 v[2:3], v4, off                           // 0000002BEBE8: DC6A0000 007C0402
	s_mov_b32 s13, 0                                           // 0000002BEBF0: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BEBF4: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002BEBF8: 8B6A0D7E
	s_cbranch_vccz 72                                          // 0000002BEBFC: BFA30048 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1320>
	s_cmp_gt_i32 s7, 1                                         // 0000002BEC00: BF028107
	s_mov_b32 s9, -1                                           // 0000002BEC04: BE8900C1
	s_cbranch_scc0 63                                          // 0000002BEC08: BFA1003F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1308>
	v_bfe_u32 v2, v1, 16, 1                                    // 0000002BEC0C: D6100002 02052101
	s_lshl_b64 s[14:15], s[2:3], 1                             // 0000002BEC14: 848E8102
	s_mov_b32 s9, 0                                            // 0000002BEC18: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEC1C: BF870091
	v_add3_u32 v2, v1, v2, 0x7fff                              // 0000002BEC20: D6550002 03FE0501 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000002BEC2C: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEC34: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 0000002BEC38: 100404FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 0000002BEC40: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEC44: BF870095
	v_add_f32_e32 v5, 1.0, v2                                  // 0000002BEC48: 060A04F2
	v_div_scale_f32 v4, null, v5, v5, 1.0                      // 0000002BEC4C: D6FC7C04 03CA0B05
	v_div_scale_f32 v12, vcc_lo, 1.0, v5, 1.0                  // 0000002BEC54: D6FC6A0C 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BEC5C: BF870292
	v_rcp_f32_e32 v11, v4                                      // 0000002BEC60: 7E165504
	v_fma_f32 v2, -v4, v11, 1.0                                // 0000002BEC64: D6130002 23CA1704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BEC6C: BF870121
	v_fmac_f32_e32 v11, v2, v11                                // 0000002BEC70: 56161702
	v_mad_u64_u32 v[2:3], null, s10, v0, 0                     // 0000002BEC74: D6FE7C02 0202000A
	v_mul_f32_e32 v16, v12, v11                                // 0000002BEC7C: 1020170C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEC80: BF870091
	v_fma_f32 v18, -v4, v16, v12                               // 0000002BEC84: D6130012 24322104
	v_fmac_f32_e32 v16, v18, v11                               // 0000002BEC8C: 56201712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BEC90: BF870121
	v_fma_f32 v12, -v4, v16, v12                               // 0000002BEC94: D613000C 24322104
	v_mad_u64_u32 v[3:4], null, s11, v0, v[3:4]                // 0000002BEC9C: D6FE7C03 040E000B
	v_div_fmas_f32 v4, v12, v11, v16                           // 0000002BECA4: D6370004 0442170C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BECAC: BF870112
	.long 0xd73c0002                                           // 0000002BECB0: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000002BECB4: 02020481
	v_div_fixup_f32 v4, v4, v5, 1.0                            // 0000002BECB8: D6270004 03CA0B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BECC0: BF870112
	.long 0xd7006a02                                           // 0000002BECC4: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 0000002BECC8: 02020404
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002BECCC: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BECD4: BF870194
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 0000002BECD8: D5207C03 01AA0605
	.long 0xd7006a02                                           // 0000002BECE0: D7006A02
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 0000002BECE4: 02001D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BECE8: BF870193
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002BECEC: D6550004 03FE0B04 00007FFF
	v_add_co_ci_u32_e64 v3, null, s15, v3, vcc_lo              // 0000002BECF8: D5207C03 01AA060F
	global_store_d16_hi_b16 v[2:3], v4, off                    // 0000002BED00: DC960000 007C0402
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 0000002BED08: 916A097E
	s_mov_b32 s9, 0                                            // 0000002BED0C: BE890080
	s_cbranch_vccnz 3                                          // 0000002BED10: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1320>
	s_cmp_lg_u32 s7, 1                                         // 0000002BED14: BF078107
	s_mov_b32 s9, -1                                           // 0000002BED18: BE8900C1
	s_cselect_b32 s12, -1, 0                                   // 0000002BED1C: 980C80C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BED20: BF8700A1
	v_bfe_u32 v2, v1, 16, 1                                    // 0000002BED24: D6100002 02052101
	s_and_b32 vcc_lo, exec_lo, s12                             // 0000002BED2C: 8B6A0C7E
	v_add3_u32 v1, v1, v2, 0x7fff                              // 0000002BED30: D6550001 03FE0501 00007FFF
	s_cbranch_vccz 21                                          // 0000002BED3C: BFA30015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1394>
	v_mad_u64_u32 v[2:3], null, s10, v0, 0                     // 0000002BED40: D6FE7C02 0202000A
	s_lshl_b64 s[12:13], s[2:3], 1                             // 0000002BED48: 848C8102
	s_mov_b32 s9, 0                                            // 0000002BED4C: BE890080
	v_mad_u64_u32 v[3:4], null, s11, v0, v[3:4]                // 0000002BED50: D6FE7C03 040E000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BED58: BF870091
	.long 0xd73c0002                                           // 0000002BED5C: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000002BED60: 02020481
	.long 0xd7006a02                                           // 0000002BED64: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 0000002BED68: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BED6C: BF870111
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 0000002BED70: D5207C03 01AA0605
	.long 0xd7006a02                                           // 0000002BED78: D7006A02
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 0000002BED7C: 02001902
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BED80: BF870001
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 0000002BED84: D5207C03 01AA060D
	global_store_d16_hi_b16 v[2:3], v1, off                    // 0000002BED8C: DC960000 007C0102
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 0000002BED94: 916A097E
	s_cbranch_vccnz 58                                         // 0000002BED98: BFA4003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1484>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BED9C: BF8700A1
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002BEDA0: 360202FF FFFF0000
	s_lshl_b64 s[2:3], s[2:3], 1                               // 0000002BEDA8: 84828102
	v_mul_f32_e32 v4, s6, v1                                   // 0000002BEDAC: 10080206
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEDB0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v4                           // 0000002BEDB4: 100208FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000002BEDBC: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEDC0: BF870095
	v_add_f32_e32 v5, 1.0, v1                                  // 0000002BEDC4: 060A02F2
	v_div_scale_f32 v3, null, v5, v5, v4                       // 0000002BEDC8: D6FC7C03 04120B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BEDD0: BF870291
	v_rcp_f32_e32 v11, v3                                      // 0000002BEDD4: 7E165503
	v_fma_f32 v1, -v3, v11, 1.0                                // 0000002BEDD8: D6130001 23CA1703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002BEDE0: BF870131
	v_fmac_f32_e32 v11, v1, v11                                // 0000002BEDE4: 56161701
	v_div_scale_f32 v12, vcc_lo, v4, v5, v4                    // 0000002BEDE8: D6FC6A0C 04120B04
	v_mad_u64_u32 v[1:2], null, s10, v0, 0                     // 0000002BEDF0: D6FE7C01 0202000A
	v_mul_f32_e32 v16, v12, v11                                // 0000002BEDF8: 1020170C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEDFC: BF870091
	v_fma_f32 v18, -v3, v16, v12                               // 0000002BEE00: D6130012 24322103
	v_fmac_f32_e32 v16, v18, v11                               // 0000002BEE08: 56201712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BEE0C: BF870121
	v_fma_f32 v12, -v3, v16, v12                               // 0000002BEE10: D613000C 24322103
	v_mad_u64_u32 v[2:3], null, s11, v0, v[2:3]                // 0000002BEE18: D6FE7C02 040A000B
	v_div_fmas_f32 v0, v12, v11, v16                           // 0000002BEE20: D6370000 0442170C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BEE28: BF870191
	v_div_fixup_f32 v3, v0, v5, v4                             // 0000002BEE2C: D6270003 04120B00
	.long 0xd73c0000                                           // 0000002BEE34: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002BEE38: 02020281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BEE3C: BF870112
	v_bfe_u32 v2, v3, 16, 1                                    // 0000002BEE40: D6100002 02052103
	.long 0xd7006a00                                           // 0000002BEE48: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002BEE4C: 02020004
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BEE50: BF870191
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000002BEE54: D5207C01 01AA0205
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000002BEE5C: D6550002 03FE0503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEE68: BF870093
	.long 0xd7006a00                                           // 0000002BEE6C: D7006A00
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 0000002BEE70: 02000500
	v_add_co_ci_u32_e64 v1, null, s3, v1, vcc_lo               // 0000002BEE74: D5207C01 01AA0203
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002BEE7C: DC960000 007C0200
	s_or_b32 exec_lo, exec_lo, s8                              // 0000002BEE84: 8C7E087E
	s_mov_b32 s3, 0                                            // 0000002BEE88: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BEE8C: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000002BEE90: 8B6A037E
	s_cbranch_vccz 1884                                        // 0000002BEE94: BFA3075C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3208>
	s_and_b32 s0, s1, s0                                       // 0000002BEE98: 8B000001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BEE9C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000002BEEA0: BE812000
	s_cbranch_execz 1880                                       // 0000002BEEA4: BFA50758 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3208>
	v_ashrrev_i32_e32 v0, 31, v10                              // 0000002BEEA8: 3400149F
	s_clause 0x1                                               // 0000002BEEAC: BF850001
	s_load_b64 s[4:5], s[16:17], 0x8                           // 0000002BEEB0: F4040108 F8000008
	s_load_b64 s[2:3], s[16:17], 0x38                          // 0000002BEEB8: F4040088 F8000038
	.long 0xd73c0002                                           // 0000002BEEC0: D73C0002
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 0000002BEEC4: 02021282
	s_mov_b32 s7, -1                                           // 0000002BEEC8: BE8700C1
	s_mov_b32 s1, 0                                            // 0000002BEECC: BE810080
	v_lshrrev_b32_e32 v0, 23, v0                               // 0000002BEED0: 32000097
	s_mov_b32 s6, 0                                            // 0000002BEED4: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002BEED8: BF8701B1
	.long 0xd7006a04                                           // 0000002BEEDC: D7006A04
	v_cndmask_b32_e32 v1, v9, v0, vcc_lo                       // 0000002BEEE0: 02020109
	.long 0xd73c0000                                           // 0000002BEEE4: D73C0000
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002BEEE8: 02021281
	v_add_co_ci_u32_e64 v11, null, 0, v10, vcc_lo              // 0000002BEEEC: D5207C0B 01AA1480
	v_and_b32_e32 v12, 0xfffffe00, v4                          // 0000002BEEF4: 361808FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEEFC: BF870093
	.long 0xd7016a00                                           // 0000002BEF00: D7016A00
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000002BEF04: 02020080
	v_sub_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000002BEF08: D5217C01 01AA0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEF10: BF870093
	.long 0xd7016a04                                           // 0000002BEF14: D7016A04
	v_cndmask_b32_e32 v1, v9, v12, vcc_lo                      // 0000002BEF18: 02021909
	v_sub_co_ci_u32_e64 v5, null, v10, v11, vcc_lo             // 0000002BEF1C: D5217C05 01AA170A
	s_waitcnt lgkmcnt(0)                                       // 0000002BEF24: BF89FC07
	.long 0xd7006a02                                           // 0000002BEF28: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 0000002BEF2C: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002BEF30: BF8700D1
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 0000002BEF34: D5207C03 01AA0605
	.long 0xd7006a09                                           // 0000002BEF3C: D7006A09
	v_cndmask_b32_e32 v1, 0xffffff00, v4, vcc_lo               // 0000002BEF40: 020208FF FFFFFF00
	.long 0xd4540000                                           // 0000002BEF48: D4540000
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 0000002BEF4C: 020208FF 00000100
	v_add_co_ci_u32_e64 v10, null, -1, v5, vcc_lo              // 0000002BEF54: D5207C0A 01AA0AC1
	.long 0xd7006a00                                           // 0000002BEF5C: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 0000002BEF60: 02020102
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 0000002BEF64: D5207C01 01AA0303
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002BEF6C: BF870003
	v_cndmask_b32_e64 v5, v10, v5, s0                          // 0000002BEF70: D5010005 00020B0A
	v_cndmask_b32_e64 v4, v9, v4, s0                           // 0000002BEF78: D5010004 00020909
	s_cmp_lt_i32 s3, 3                                         // 0000002BEF80: BF048303
	s_cbranch_scc1 118                                         // 0000002BEF84: BFA20076 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1760>
	s_cmp_gt_i32 s3, 3                                         // 0000002BEF88: BF028303
	s_cbranch_scc0 70                                          // 0000002BEF8C: BFA10046 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x16a8>
	s_cmp_gt_i32 s3, 4                                         // 0000002BEF90: BF028403
	s_cbranch_scc0 34                                          // 0000002BEF94: BFA10022 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1620>
	s_cmp_eq_u32 s3, 5                                         // 0000002BEF98: BF068503
	s_mov_b32 s6, -1                                           // 0000002BEF9C: BE8600C1
	s_cbranch_scc0 30                                          // 0000002BEFA0: BFA1001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x161c>
	s_load_b64 s[6:7], s[16:17], 0x10                          // 0000002BEFA4: F4040188 F8000010
	v_dual_mov_b32 v9, s4 :: v_dual_mov_b32 v10, s5            // 0000002BEFAC: CA100004 090A0005
	v_bfe_u32 v18, v17, 16, 1                                  // 0000002BEFB4: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002BEFBC: BF8701A1
	v_add3_u32 v18, v17, v18, 0x7fff                           // 0000002BEFC0: D6550012 03FE2511 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002BEFCC: BF89FC07
	v_cndmask_b32_e64 v16, s6, v9, s0                          // 0000002BEFD0: D5010010 00021206
	v_cndmask_b32_e64 v19, s7, v10, s0                         // 0000002BEFD8: D5010013 00021407
	.long 0xd73c0009                                           // 0000002BEFE0: D73C0009
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002BEFE4: 02020881
	s_mov_b32 s6, 0                                            // 0000002BEFE8: BE860080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BEFEC: BF870093
	.long 0xd7006a10                                           // 0000002BEFF0: D7006A10
	v_cndmask_b32_e32 v1, v16, v12, vcc_lo                     // 0000002BEFF4: 02021910
	v_add_co_ci_u32_e64 v19, null, v19, v11, vcc_lo            // 0000002BEFF8: D5207C13 01AA1713
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF000: BF870092
	.long 0xd7006a09                                           // 0000002BF004: D7006A09
	v_cndmask_b32_e32 v1, v16, v9, vcc_lo                      // 0000002BF008: 02021310
	v_add_co_ci_u32_e64 v10, null, v19, v10, vcc_lo            // 0000002BF00C: D5207C0A 01AA1513
	global_store_d16_hi_b16 v[9:10], v18, off                  // 0000002BF014: DC960000 007C1209
	s_mov_b32 s7, 0                                            // 0000002BF01C: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BF020: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002BF024: 8B6A077E
	s_cbranch_vccz 30                                          // 0000002BF028: BFA3001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x16a4>
	v_mul_f32_e32 v9, 0xbfb8aa3b, v17                          // 0000002BF02C: 101222FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BF034: BF870291
	v_exp_f32_e32 v9, v9                                       // 0000002BF038: 7E124B09
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002BF03C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF040: BF870091
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002BF044: D6FC7C0A 03CA1309
	v_rcp_f32_e32 v16, v10                                     // 0000002BF04C: 7E20550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF050: BF870095
	v_fma_f32 v18, -v10, v16, 1.0                              // 0000002BF054: D6130012 23CA210A
	v_fmac_f32_e32 v16, v18, v16                               // 0000002BF05C: 56202112
	v_div_scale_f32 v18, vcc_lo, 1.0, v9, 1.0                  // 0000002BF060: D6FC6A12 03CA12F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF068: BF870091
	v_mul_f32_e32 v19, v18, v16                                // 0000002BF06C: 10262112
	v_fma_f32 v20, -v10, v19, v18                              // 0000002BF070: D6130014 244A270A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF078: BF870091
	v_fmac_f32_e32 v19, v20, v16                               // 0000002BF07C: 56262114
	v_fma_f32 v10, -v10, v19, v18                              // 0000002BF080: D613000A 244A270A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF088: BF870091
	v_div_fmas_f32 v10, v10, v16, v19                          // 0000002BF08C: D637000A 044E210A
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000002BF094: D6270009 03CA130A
	global_store_b32 v[2:3], v9, off                           // 0000002BF09C: DC6A0000 007C0902
	s_mov_b32 s7, 0                                            // 0000002BF0A4: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BF0A8: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002BF0AC: 8B6A077E
	s_cbranch_vccz 42                                          // 0000002BF0B0: BFA3002A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x175c>
	v_bfe_u32 v9, v17, 16, 1                                   // 0000002BF0B4: D6100009 02052111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF0BC: BF870091
	v_add3_u32 v9, v17, v9, 0x7fff                             // 0000002BF0C0: D6550009 03FE1311 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000002BF0CC: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF0D4: BF870091
	v_mul_f32_e32 v9, s2, v9                                   // 0000002BF0D8: 10121202
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 0000002BF0DC: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BF0E4: BF870291
	v_exp_f32_e32 v9, v9                                       // 0000002BF0E8: 7E124B09
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002BF0EC: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF0F0: BF870091
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002BF0F4: D6FC7C0A 03CA1309
	v_rcp_f32_e32 v16, v10                                     // 0000002BF0FC: 7E20550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF100: BF870095
	v_fma_f32 v18, -v10, v16, 1.0                              // 0000002BF104: D6130012 23CA210A
	v_fmac_f32_e32 v16, v18, v16                               // 0000002BF10C: 56202112
	v_div_scale_f32 v18, vcc_lo, 1.0, v9, 1.0                  // 0000002BF110: D6FC6A12 03CA12F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF118: BF870091
	v_mul_f32_e32 v19, v18, v16                                // 0000002BF11C: 10262112
	v_fma_f32 v20, -v10, v19, v18                              // 0000002BF120: D6130014 244A270A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF128: BF870091
	v_fmac_f32_e32 v19, v20, v16                               // 0000002BF12C: 56262114
	v_fma_f32 v10, -v10, v19, v18                              // 0000002BF130: D613000A 244A270A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF138: BF870091
	v_div_fmas_f32 v10, v10, v16, v19                          // 0000002BF13C: D637000A 044E210A
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000002BF144: D6270009 03CA130A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BF14C: BF870001
	v_add_f32_e32 v9, v9, v9                                   // 0000002BF150: 06121309
	global_store_b32 v[2:3], v9, off                           // 0000002BF154: DC6A0000 007C0902
	s_mov_b32 s7, 0                                            // 0000002BF15C: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BF160: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002BF164: 8B6A077E
	s_cbranch_vccz 55                                          // 0000002BF168: BFA30037 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1848>
	s_cmp_gt_i32 s3, 1                                         // 0000002BF16C: BF028103
	s_mov_b32 s1, -1                                           // 0000002BF170: BE8100C1
	s_cbranch_scc0 46                                          // 0000002BF174: BFA1002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1830>
	v_bfe_u32 v9, v17, 16, 1                                   // 0000002BF178: D6100009 02052111
	s_mov_b32 s1, 0                                            // 0000002BF180: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF184: BF870091
	v_add3_u32 v9, v17, v9, 0x7fff                             // 0000002BF188: D6550009 03FE1311 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000002BF194: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF19C: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 0000002BF1A0: 101212FF BFB8AA3B
	v_exp_f32_e32 v9, v9                                       // 0000002BF1A8: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF1AC: BF870095
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002BF1B0: 061212F2
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002BF1B4: D6FC7C0A 03CA1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BF1BC: BF870291
	v_rcp_f32_e32 v16, v10                                     // 0000002BF1C0: 7E20550A
	v_fma_f32 v18, -v10, v16, 1.0                              // 0000002BF1C4: D6130012 23CA210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BF1CC: BF8700A1
	v_fmac_f32_e32 v16, v18, v16                               // 0000002BF1D0: 56202112
	v_div_scale_f32 v18, vcc_lo, 1.0, v9, 1.0                  // 0000002BF1D4: D6FC6A12 03CA12F2
	v_mul_f32_e32 v19, v18, v16                                // 0000002BF1DC: 10262112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF1E0: BF870091
	v_fma_f32 v20, -v10, v19, v18                              // 0000002BF1E4: D6130014 244A270A
	v_fmac_f32_e32 v19, v20, v16                               // 0000002BF1EC: 56262114
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF1F0: BF870091
	v_fma_f32 v10, -v10, v19, v18                              // 0000002BF1F4: D613000A 244A270A
	v_div_fmas_f32 v10, v10, v16, v19                          // 0000002BF1FC: D637000A 044E210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF204: BF870091
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000002BF208: D6270009 03CA130A
	v_bfe_u32 v10, v9, 16, 1                                   // 0000002BF210: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BF218: BF870001
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000002BF21C: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off                    // 0000002BF228: DC960000 007C0900
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002BF230: 916A017E
	s_mov_b32 s1, 0                                            // 0000002BF234: BE810080
	s_cbranch_vccnz 3                                          // 0000002BF238: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1848>
	s_cmp_lg_u32 s3, 1                                         // 0000002BF23C: BF078103
	s_mov_b32 s1, -1                                           // 0000002BF240: BE8100C1
	s_cselect_b32 s6, -1, 0                                    // 0000002BF244: 980680C1
	v_bfe_u32 v9, v17, 16, 1                                   // 0000002BF248: D6100009 02052111
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002BF250: 8B6A067E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BF254: BF870001
	v_add3_u32 v9, v17, v9, 0x7fff                             // 0000002BF258: D6550009 03FE1311 00007FFF
	s_cbranch_vccz 3                                           // 0000002BF264: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1874>
	s_mov_b32 s1, 0                                            // 0000002BF268: BE810080
	global_store_d16_hi_b16 v[0:1], v9, off                    // 0000002BF26C: DC960000 007C0900
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002BF274: 916A017E
	s_cbranch_vccnz 41                                         // 0000002BF278: BFA40029 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1920>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF27C: BF870091
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000002BF280: 361212FF FFFF0000
	v_mul_f32_e32 v9, s2, v9                                   // 0000002BF288: 10121202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF28C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000002BF290: 101412FF BFB8AA3B
	v_exp_f32_e32 v10, v10                                     // 0000002BF298: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF29C: BF870095
	v_add_f32_e32 v10, 1.0, v10                                // 0000002BF2A0: 061414F2
	v_div_scale_f32 v16, null, v10, v10, v9                    // 0000002BF2A4: D6FC7C10 0426150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BF2AC: BF870291
	v_rcp_f32_e32 v17, v16                                     // 0000002BF2B0: 7E225510
	v_fma_f32 v18, -v16, v17, 1.0                              // 0000002BF2B4: D6130012 23CA2310
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BF2BC: BF8700A1
	v_fmac_f32_e32 v17, v18, v17                               // 0000002BF2C0: 56222312
	v_div_scale_f32 v18, vcc_lo, v9, v10, v9                   // 0000002BF2C4: D6FC6A12 04261509
	v_mul_f32_e32 v19, v18, v17                                // 0000002BF2CC: 10262312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF2D0: BF870091
	v_fma_f32 v20, -v16, v19, v18                              // 0000002BF2D4: D6130014 244A2710
	v_fmac_f32_e32 v19, v20, v17                               // 0000002BF2DC: 56262314
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF2E0: BF870091
	v_fma_f32 v16, -v16, v19, v18                              // 0000002BF2E4: D6130010 244A2710
	v_div_fmas_f32 v16, v16, v17, v19                          // 0000002BF2EC: D6370010 044E2310
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF2F4: BF870091
	v_div_fixup_f32 v9, v16, v10, v9                           // 0000002BF2F8: D6270009 04261510
	v_bfe_u32 v10, v9, 16, 1                                   // 0000002BF300: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BF308: BF870001
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000002BF30C: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off                    // 0000002BF318: DC960000 007C0900
	s_lshr_b64 s[6:7], s[10:11], 1                             // 0000002BF320: 8586810A
	s_mov_b32 s9, -1                                           // 0000002BF324: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002BF328: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002BF32C: BF048303
	s_mov_b32 s8, 0                                            // 0000002BF330: BE880080
	s_cbranch_scc1 135                                         // 0000002BF334: BFA20087 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1b54>
	s_cmp_gt_i32 s3, 3                                         // 0000002BF338: BF028303
	s_cbranch_scc0 82                                          // 0000002BF33C: BFA10052 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1a88>
	s_cmp_gt_i32 s3, 4                                         // 0000002BF340: BF028403
	s_cbranch_scc0 40                                          // 0000002BF344: BFA10028 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x19e8>
	s_cmp_eq_u32 s3, 5                                         // 0000002BF348: BF068503
	s_mov_b32 s8, -1                                           // 0000002BF34C: BE8800C1
	s_cbranch_scc0 36                                          // 0000002BF350: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x19e4>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002BF354: F4040208 F8000010
	v_dual_mov_b32 v9, s4 :: v_dual_mov_b32 v10, s5            // 0000002BF35C: CA100004 090A0005
	v_bfe_u32 v16, v15, 16, 1                                  // 0000002BF364: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002BF36C: BF8701A1
	v_add3_u32 v16, v15, v16, 0x7fff                           // 0000002BF370: D6550010 03FE210F 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002BF37C: BF89FC07
	v_cndmask_b32_e64 v9, s8, v9, s0                           // 0000002BF380: D5010009 00021208
	v_cndmask_b32_e64 v10, s9, v10, s0                         // 0000002BF388: D501000A 00021409
	s_lshl_b64 s[8:9], s[6:7], 1                               // 0000002BF390: 84888106
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000002BF394: BF870482
	.long 0xd7006a11                                           // 0000002BF398: D7006A11
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 0000002BF39C: 02001109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002BF3A0: BF8701A1
	v_add_co_ci_u32_e64 v18, null, s9, v10, vcc_lo             // 0000002BF3A4: D5207C12 01AA1409
	.long 0xd73c0009                                           // 0000002BF3AC: D73C0009
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002BF3B0: 02020881
	.long 0xd7006a11                                           // 0000002BF3B4: D7006A11
	v_cndmask_b32_e32 v1, v17, v12, vcc_lo                     // 0000002BF3B8: 02021911
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002BF3BC: BF8700B1
	v_add_co_ci_u32_e64 v18, null, v18, v11, vcc_lo            // 0000002BF3C0: D5207C12 01AA1712
	s_mov_b32 s8, 0                                            // 0000002BF3C8: BE880080
	.long 0xd7006a09                                           // 0000002BF3CC: D7006A09
	v_cndmask_b32_e32 v1, v17, v9, vcc_lo                      // 0000002BF3D0: 02021311
	v_add_co_ci_u32_e64 v10, null, v18, v10, vcc_lo            // 0000002BF3D4: D5207C0A 01AA1512
	global_store_d16_hi_b16 v[9:10], v16, off                  // 0000002BF3DC: DC960000 007C1009
	s_mov_b32 s9, 0                                            // 0000002BF3E4: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BF3E8: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002BF3EC: 8B6A097E
	s_cbranch_vccz 36                                          // 0000002BF3F0: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1a84>
	v_mul_f32_e32 v9, 0xbfb8aa3b, v15                          // 0000002BF3F4: 10121EFF BFB8AA3B
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000002BF3FC: 848C820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BF400: BF870291
	v_exp_f32_e32 v9, v9                                       // 0000002BF404: 7E124B09
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002BF408: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BF40C: BF870121
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002BF410: D6FC7C0A 03CA1309
	v_div_scale_f32 v18, vcc_lo, 1.0, v9, 1.0                  // 0000002BF418: D6FC6A12 03CA12F2
	v_rcp_f32_e32 v16, v10                                     // 0000002BF420: 7E20550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF424: BF870095
	v_fma_f32 v17, -v10, v16, 1.0                              // 0000002BF428: D6130011 23CA210A
	v_fmac_f32_e32 v16, v17, v16                               // 0000002BF430: 56202111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF434: BF870091
	v_mul_f32_e32 v17, v18, v16                                // 0000002BF438: 10222112
	v_fma_f32 v19, -v10, v17, v18                              // 0000002BF43C: D6130013 244A230A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF444: BF870091
	v_fmac_f32_e32 v17, v19, v16                               // 0000002BF448: 56222113
	v_fma_f32 v10, -v10, v17, v18                              // 0000002BF44C: D613000A 244A230A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF454: BF870091
	v_div_fmas_f32 v10, v10, v16, v17                          // 0000002BF458: D637000A 0446210A
	v_div_fixup_f32 v16, v10, v9, 1.0                          // 0000002BF460: D6270010 03CA130A
	.long 0xd7006a09                                           // 0000002BF468: D7006A09
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 0000002BF46C: 02001902
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BF470: BF870001
	v_add_co_ci_u32_e64 v10, null, s13, v3, vcc_lo             // 0000002BF474: D5207C0A 01AA060D
	global_store_b32 v[9:10], v16, off                         // 0000002BF47C: DC6A0000 007C1009
	s_mov_b32 s9, 0                                            // 0000002BF484: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BF488: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002BF48C: 8B6A097E
	s_cbranch_vccz 47                                          // 0000002BF490: BFA3002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1b50>
	v_bfe_u32 v9, v15, 16, 1                                   // 0000002BF494: D6100009 0205210F
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000002BF49C: 848C820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF4A0: BF870091
	v_add3_u32 v9, v15, v9, 0x7fff                             // 0000002BF4A4: D6550009 03FE130F 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000002BF4B0: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF4B8: BF870091
	v_mul_f32_e32 v9, s2, v9                                   // 0000002BF4BC: 10121202
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 0000002BF4C0: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BF4C8: BF870291
	v_exp_f32_e32 v9, v9                                       // 0000002BF4CC: 7E124B09
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002BF4D0: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BF4D4: BF870121
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002BF4D8: D6FC7C0A 03CA1309
	v_div_scale_f32 v18, vcc_lo, 1.0, v9, 1.0                  // 0000002BF4E0: D6FC6A12 03CA12F2
	v_rcp_f32_e32 v16, v10                                     // 0000002BF4E8: 7E20550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF4EC: BF870095
	v_fma_f32 v17, -v10, v16, 1.0                              // 0000002BF4F0: D6130011 23CA210A
	v_fmac_f32_e32 v16, v17, v16                               // 0000002BF4F8: 56202111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF4FC: BF870091
	v_mul_f32_e32 v17, v18, v16                                // 0000002BF500: 10222112
	v_fma_f32 v19, -v10, v17, v18                              // 0000002BF504: D6130013 244A230A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF50C: BF870091
	v_fmac_f32_e32 v17, v19, v16                               // 0000002BF510: 56222113
	v_fma_f32 v10, -v10, v17, v18                              // 0000002BF514: D613000A 244A230A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF51C: BF870091
	v_div_fmas_f32 v10, v10, v16, v17                          // 0000002BF520: D637000A 0446210A
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000002BF528: D6270009 03CA130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BF530: BF8700A1
	v_add_f32_e32 v16, v9, v9                                  // 0000002BF534: 06201309
	.long 0xd7006a09                                           // 0000002BF538: D7006A09
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 0000002BF53C: 02001902
	v_add_co_ci_u32_e64 v10, null, s13, v3, vcc_lo             // 0000002BF540: D5207C0A 01AA060D
	global_store_b32 v[9:10], v16, off                         // 0000002BF548: DC6A0000 007C1009
	s_mov_b32 s9, 0                                            // 0000002BF550: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BF554: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002BF558: 8B6A097E
	s_cbranch_vccz 60                                          // 0000002BF55C: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1c50>
	s_cmp_gt_i32 s3, 1                                         // 0000002BF560: BF028103
	s_mov_b32 s1, -1                                           // 0000002BF564: BE8100C1
	s_cbranch_scc0 51                                          // 0000002BF568: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1c38>
	v_bfe_u32 v9, v15, 16, 1                                   // 0000002BF56C: D6100009 0205210F
	s_lshl_b64 s[12:13], s[10:11], 1                           // 0000002BF574: 848C810A
	s_mov_b32 s1, 0                                            // 0000002BF578: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF57C: BF870091
	v_add3_u32 v9, v15, v9, 0x7fff                             // 0000002BF580: D6550009 03FE130F 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000002BF58C: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF594: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 0000002BF598: 101212FF BFB8AA3B
	v_exp_f32_e32 v9, v9                                       // 0000002BF5A0: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF5A4: BF870095
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002BF5A8: 061212F2
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002BF5AC: D6FC7C0A 03CA1309
	v_div_scale_f32 v18, vcc_lo, 1.0, v9, 1.0                  // 0000002BF5B4: D6FC6A12 03CA12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BF5BC: BF870292
	v_rcp_f32_e32 v16, v10                                     // 0000002BF5C0: 7E20550A
	v_fma_f32 v17, -v10, v16, 1.0                              // 0000002BF5C4: D6130011 23CA210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF5CC: BF870091
	v_fmac_f32_e32 v16, v17, v16                               // 0000002BF5D0: 56202111
	v_mul_f32_e32 v17, v18, v16                                // 0000002BF5D4: 10222112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF5D8: BF870091
	v_fma_f32 v19, -v10, v17, v18                              // 0000002BF5DC: D6130013 244A230A
	v_fmac_f32_e32 v17, v19, v16                               // 0000002BF5E4: 56222113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF5E8: BF870091
	v_fma_f32 v10, -v10, v17, v18                              // 0000002BF5EC: D613000A 244A230A
	v_div_fmas_f32 v10, v10, v16, v17                          // 0000002BF5F4: D637000A 0446210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF5FC: BF870091
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000002BF600: D6270009 03CA130A
	v_bfe_u32 v10, v9, 16, 1                                   // 0000002BF608: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BF610: BF8700A1
	v_add3_u32 v16, v9, v10, 0x7fff                            // 0000002BF614: D6550010 03FE1509 00007FFF
	.long 0xd7006a09                                           // 0000002BF620: D7006A09
	v_cndmask_b32_e32 v0, v0, v12, vcc_lo                      // 0000002BF624: 02001900
	v_add_co_ci_u32_e64 v10, null, s13, v1, vcc_lo             // 0000002BF628: D5207C0A 01AA020D
	global_store_d16_hi_b16 v[9:10], v16, off                  // 0000002BF630: DC960000 007C1009
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002BF638: 916A017E
	s_mov_b32 s1, 0                                            // 0000002BF63C: BE810080
	s_cbranch_vccnz 3                                          // 0000002BF640: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1c50>
	s_cmp_lg_u32 s3, 1                                         // 0000002BF644: BF078103
	s_mov_b32 s1, -1                                           // 0000002BF648: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002BF64C: 980880C1
	v_bfe_u32 v9, v15, 16, 1                                   // 0000002BF650: D6100009 0205210F
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002BF658: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BF65C: BF870001
	v_add3_u32 v9, v15, v9, 0x7fff                             // 0000002BF660: D6550009 03FE130F 00007FFF
	s_cbranch_vccz 9                                           // 0000002BF66C: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1c94>
	s_lshl_b64 s[8:9], s[10:11], 1                             // 0000002BF670: 8488810A
	s_mov_b32 s1, 0                                            // 0000002BF674: BE810080
	.long 0xd7006a0f                                           // 0000002BF678: D7006A0F
	v_cndmask_b32_e32 v0, v0, v8, vcc_lo                       // 0000002BF67C: 02001100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BF680: BF870001
	v_add_co_ci_u32_e64 v16, null, s9, v1, vcc_lo              // 0000002BF684: D5207C10 01AA0209
	global_store_d16_hi_b16 v[15:16], v9, off                  // 0000002BF68C: DC960000 007C090F
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002BF694: 916A017E
	s_cbranch_vccnz 46                                         // 0000002BF698: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1d54>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BF69C: BF8700A1
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000002BF6A0: 361212FF FFFF0000
	s_lshl_b64 s[8:9], s[10:11], 1                             // 0000002BF6A8: 8488810A
	v_mul_f32_e32 v9, s2, v9                                   // 0000002BF6AC: 10121202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF6B0: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000002BF6B4: 101412FF BFB8AA3B
	v_exp_f32_e32 v10, v10                                     // 0000002BF6BC: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF6C0: BF870095
	v_add_f32_e32 v10, 1.0, v10                                // 0000002BF6C4: 061414F2
	v_div_scale_f32 v15, null, v10, v10, v9                    // 0000002BF6C8: D6FC7C0F 0426150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BF6D0: BF870291
	v_rcp_f32_e32 v16, v15                                     // 0000002BF6D4: 7E20550F
	v_fma_f32 v17, -v15, v16, 1.0                              // 0000002BF6D8: D6130011 23CA210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BF6E0: BF8700A1
	v_fmac_f32_e32 v16, v17, v16                               // 0000002BF6E4: 56202111
	v_div_scale_f32 v18, vcc_lo, v9, v10, v9                   // 0000002BF6E8: D6FC6A12 04261509
	v_mul_f32_e32 v17, v18, v16                                // 0000002BF6F0: 10222112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF6F4: BF870091
	v_fma_f32 v19, -v15, v17, v18                              // 0000002BF6F8: D6130013 244A230F
	v_fmac_f32_e32 v17, v19, v16                               // 0000002BF700: 56222113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF704: BF870091
	v_fma_f32 v15, -v15, v17, v18                              // 0000002BF708: D613000F 244A230F
	v_div_fmas_f32 v15, v15, v16, v17                          // 0000002BF710: D637000F 0446210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF718: BF870091
	v_div_fixup_f32 v9, v15, v10, v9                           // 0000002BF71C: D6270009 0426150F
	v_bfe_u32 v10, v9, 16, 1                                   // 0000002BF724: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BF72C: BF8700A1
	v_add3_u32 v15, v9, v10, 0x7fff                            // 0000002BF730: D655000F 03FE1509 00007FFF
	.long 0xd7006a09                                           // 0000002BF73C: D7006A09
	v_cndmask_b32_e32 v0, v0, v8, vcc_lo                       // 0000002BF740: 02001100
	v_add_co_ci_u32_e64 v10, null, s9, v1, vcc_lo              // 0000002BF744: D5207C0A 01AA0209
	global_store_d16_hi_b16 v[9:10], v15, off                  // 0000002BF74C: DC960000 007C0F09
	s_mov_b32 s9, -1                                           // 0000002BF754: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002BF758: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002BF75C: BF048303
	s_mov_b32 s8, 0                                            // 0000002BF760: BE880080
	s_cbranch_scc1 138                                         // 0000002BF764: BFA2008A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1f90>
	s_cmp_gt_i32 s3, 3                                         // 0000002BF768: BF028303
	s_cbranch_scc0 85                                          // 0000002BF76C: BFA10055 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1ec4>
	s_cmp_gt_i32 s3, 4                                         // 0000002BF770: BF028403
	s_cbranch_scc0 43                                          // 0000002BF774: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1e24>
	s_cmp_eq_u32 s3, 5                                         // 0000002BF778: BF068503
	s_mov_b32 s8, -1                                           // 0000002BF77C: BE8800C1
	s_cbranch_scc0 39                                          // 0000002BF780: BFA10027 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1e20>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002BF784: F4040208 F8000010
	v_dual_mov_b32 v9, s4 :: v_dual_mov_b32 v10, s5            // 0000002BF78C: CA100004 090A0005
	s_and_b32 s13, s11, 0x7fffffff                             // 0000002BF794: 8B0DFF0B 7FFFFFFF
	s_and_b32 s12, s10, -2                                     // 0000002BF79C: 8B0CC20A
	v_bfe_u32 v15, v14, 16, 1                                  // 0000002BF7A0: D610000F 0205210E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BF7A8: BF870001
	v_add3_u32 v15, v14, v15, 0x7fff                           // 0000002BF7AC: D655000F 03FE1F0E 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002BF7B8: BF89FC07
	v_cndmask_b32_e64 v9, s8, v9, s0                           // 0000002BF7BC: D5010009 00021208
	v_cndmask_b32_e64 v10, s9, v10, s0                         // 0000002BF7C4: D501000A 00021409
	s_lshl_b64 s[8:9], s[12:13], 1                             // 0000002BF7CC: 8488810C
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000002BF7D0: BF870482
	.long 0xd7006a10                                           // 0000002BF7D4: D7006A10
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 0000002BF7D8: 02001109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002BF7DC: BF8701A1
	v_add_co_ci_u32_e64 v17, null, s9, v10, vcc_lo             // 0000002BF7E0: D5207C11 01AA1409
	.long 0xd73c0009                                           // 0000002BF7E8: D73C0009
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002BF7EC: 02020881
	.long 0xd7006a10                                           // 0000002BF7F0: D7006A10
	v_cndmask_b32_e32 v1, v16, v12, vcc_lo                     // 0000002BF7F4: 02021910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002BF7F8: BF8700B1
	v_add_co_ci_u32_e64 v17, null, v17, v11, vcc_lo            // 0000002BF7FC: D5207C11 01AA1711
	s_mov_b32 s8, 0                                            // 0000002BF804: BE880080
	.long 0xd7006a09                                           // 0000002BF808: D7006A09
	v_cndmask_b32_e32 v1, v16, v9, vcc_lo                      // 0000002BF80C: 02021310
	v_add_co_ci_u32_e64 v10, null, v17, v10, vcc_lo            // 0000002BF810: D5207C0A 01AA1511
	global_store_d16_hi_b16 v[9:10], v15, off                  // 0000002BF818: DC960000 007C0F09
	s_mov_b32 s9, 0                                            // 0000002BF820: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BF824: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002BF828: 8B6A097E
	s_cbranch_vccz 36                                          // 0000002BF82C: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1ec0>
	v_mul_f32_e32 v9, 0xbfb8aa3b, v14                          // 0000002BF830: 10121CFF BFB8AA3B
	s_lshl_b64 s[12:13], s[10:11], 3                           // 0000002BF838: 848C830A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BF83C: BF870291
	v_exp_f32_e32 v9, v9                                       // 0000002BF840: 7E124B09
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002BF844: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BF848: BF870121
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002BF84C: D6FC7C0A 03CA1309
	v_div_scale_f32 v17, vcc_lo, 1.0, v9, 1.0                  // 0000002BF854: D6FC6A11 03CA12F2
	v_rcp_f32_e32 v15, v10                                     // 0000002BF85C: 7E1E550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF860: BF870095
	v_fma_f32 v16, -v10, v15, 1.0                              // 0000002BF864: D6130010 23CA1F0A
	v_fmac_f32_e32 v15, v16, v15                               // 0000002BF86C: 561E1F10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF870: BF870091
	v_mul_f32_e32 v16, v17, v15                                // 0000002BF874: 10201F11
	v_fma_f32 v18, -v10, v16, v17                              // 0000002BF878: D6130012 2446210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF880: BF870091
	v_fmac_f32_e32 v16, v18, v15                               // 0000002BF884: 56201F12
	v_fma_f32 v10, -v10, v16, v17                              // 0000002BF888: D613000A 2446210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF890: BF870091
	v_div_fmas_f32 v10, v10, v15, v16                          // 0000002BF894: D637000A 04421F0A
	v_div_fixup_f32 v15, v10, v9, 1.0                          // 0000002BF89C: D627000F 03CA130A
	.long 0xd7006a09                                           // 0000002BF8A4: D7006A09
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 0000002BF8A8: 02001902
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BF8AC: BF870001
	v_add_co_ci_u32_e64 v10, null, s13, v3, vcc_lo             // 0000002BF8B0: D5207C0A 01AA060D
	global_store_b32 v[9:10], v15, off                         // 0000002BF8B8: DC6A0000 007C0F09
	s_mov_b32 s9, 0                                            // 0000002BF8C0: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BF8C4: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002BF8C8: 8B6A097E
	s_cbranch_vccz 47                                          // 0000002BF8CC: BFA3002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1f8c>
	v_bfe_u32 v9, v14, 16, 1                                   // 0000002BF8D0: D6100009 0205210E
	s_lshl_b64 s[12:13], s[10:11], 3                           // 0000002BF8D8: 848C830A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF8DC: BF870091
	v_add3_u32 v9, v14, v9, 0x7fff                             // 0000002BF8E0: D6550009 03FE130E 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000002BF8EC: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF8F4: BF870091
	v_mul_f32_e32 v9, s2, v9                                   // 0000002BF8F8: 10121202
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 0000002BF8FC: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BF904: BF870291
	v_exp_f32_e32 v9, v9                                       // 0000002BF908: 7E124B09
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002BF90C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BF910: BF870121
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002BF914: D6FC7C0A 03CA1309
	v_div_scale_f32 v17, vcc_lo, 1.0, v9, 1.0                  // 0000002BF91C: D6FC6A11 03CA12F2
	v_rcp_f32_e32 v15, v10                                     // 0000002BF924: 7E1E550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF928: BF870095
	v_fma_f32 v16, -v10, v15, 1.0                              // 0000002BF92C: D6130010 23CA1F0A
	v_fmac_f32_e32 v15, v16, v15                               // 0000002BF934: 561E1F10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF938: BF870091
	v_mul_f32_e32 v16, v17, v15                                // 0000002BF93C: 10201F11
	v_fma_f32 v18, -v10, v16, v17                              // 0000002BF940: D6130012 2446210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF948: BF870091
	v_fmac_f32_e32 v16, v18, v15                               // 0000002BF94C: 56201F12
	v_fma_f32 v10, -v10, v16, v17                              // 0000002BF950: D613000A 2446210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF958: BF870091
	v_div_fmas_f32 v10, v10, v15, v16                          // 0000002BF95C: D637000A 04421F0A
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000002BF964: D6270009 03CA130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BF96C: BF8700A1
	v_add_f32_e32 v15, v9, v9                                  // 0000002BF970: 061E1309
	.long 0xd7006a09                                           // 0000002BF974: D7006A09
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 0000002BF978: 02001902
	v_add_co_ci_u32_e64 v10, null, s13, v3, vcc_lo             // 0000002BF97C: D5207C0A 01AA060D
	global_store_b32 v[9:10], v15, off                         // 0000002BF984: DC6A0000 007C0F09
	s_mov_b32 s9, 0                                            // 0000002BF98C: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BF990: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002BF994: 8B6A097E
	s_cbranch_vccz 60                                          // 0000002BF998: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x208c>
	s_cmp_gt_i32 s3, 1                                         // 0000002BF99C: BF028103
	s_mov_b32 s1, -1                                           // 0000002BF9A0: BE8100C1
	s_cbranch_scc0 51                                          // 0000002BF9A4: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2074>
	v_bfe_u32 v9, v14, 16, 1                                   // 0000002BF9A8: D6100009 0205210E
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000002BF9B0: 848C820A
	s_mov_b32 s1, 0                                            // 0000002BF9B4: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF9B8: BF870091
	v_add3_u32 v9, v14, v9, 0x7fff                             // 0000002BF9BC: D6550009 03FE130E 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000002BF9C8: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF9D0: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 0000002BF9D4: 101212FF BFB8AA3B
	v_exp_f32_e32 v9, v9                                       // 0000002BF9DC: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BF9E0: BF870095
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002BF9E4: 061212F2
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002BF9E8: D6FC7C0A 03CA1309
	v_div_scale_f32 v17, vcc_lo, 1.0, v9, 1.0                  // 0000002BF9F0: D6FC6A11 03CA12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BF9F8: BF870292
	v_rcp_f32_e32 v15, v10                                     // 0000002BF9FC: 7E1E550A
	v_fma_f32 v16, -v10, v15, 1.0                              // 0000002BFA00: D6130010 23CA1F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFA08: BF870091
	v_fmac_f32_e32 v15, v16, v15                               // 0000002BFA0C: 561E1F10
	v_mul_f32_e32 v16, v17, v15                                // 0000002BFA10: 10201F11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFA14: BF870091
	v_fma_f32 v18, -v10, v16, v17                              // 0000002BFA18: D6130012 2446210A
	v_fmac_f32_e32 v16, v18, v15                               // 0000002BFA20: 56201F12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFA24: BF870091
	v_fma_f32 v10, -v10, v16, v17                              // 0000002BFA28: D613000A 2446210A
	v_div_fmas_f32 v10, v10, v15, v16                          // 0000002BFA30: D637000A 04421F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFA38: BF870091
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000002BFA3C: D6270009 03CA130A
	v_bfe_u32 v10, v9, 16, 1                                   // 0000002BFA44: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BFA4C: BF8700A1
	v_add3_u32 v15, v9, v10, 0x7fff                            // 0000002BFA50: D655000F 03FE1509 00007FFF
	.long 0xd7006a09                                           // 0000002BFA5C: D7006A09
	v_cndmask_b32_e32 v0, v0, v12, vcc_lo                      // 0000002BFA60: 02001900
	v_add_co_ci_u32_e64 v10, null, s13, v1, vcc_lo             // 0000002BFA64: D5207C0A 01AA020D
	global_store_d16_hi_b16 v[9:10], v15, off                  // 0000002BFA6C: DC960000 007C0F09
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002BFA74: 916A017E
	s_mov_b32 s1, 0                                            // 0000002BFA78: BE810080
	s_cbranch_vccnz 3                                          // 0000002BFA7C: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x208c>
	s_cmp_lg_u32 s3, 1                                         // 0000002BFA80: BF078103
	s_mov_b32 s1, -1                                           // 0000002BFA84: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002BFA88: 980880C1
	v_bfe_u32 v9, v14, 16, 1                                   // 0000002BFA8C: D6100009 0205210E
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002BFA94: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BFA98: BF870001
	v_add3_u32 v9, v14, v9, 0x7fff                             // 0000002BFA9C: D6550009 03FE130E 00007FFF
	s_cbranch_vccz 9                                           // 0000002BFAA8: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x20d0>
	s_lshl_b64 s[8:9], s[10:11], 2                             // 0000002BFAAC: 8488820A
	s_mov_b32 s1, 0                                            // 0000002BFAB0: BE810080
	.long 0xd7006a0e                                           // 0000002BFAB4: D7006A0E
	v_cndmask_b32_e32 v0, v0, v8, vcc_lo                       // 0000002BFAB8: 02001100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BFABC: BF870001
	v_add_co_ci_u32_e64 v15, null, s9, v1, vcc_lo              // 0000002BFAC0: D5207C0F 01AA0209
	global_store_d16_hi_b16 v[14:15], v9, off                  // 0000002BFAC8: DC960000 007C090E
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002BFAD0: 916A017E
	s_cbranch_vccnz 46                                         // 0000002BFAD4: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2190>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BFAD8: BF8700A1
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000002BFADC: 361212FF FFFF0000
	s_lshl_b64 s[8:9], s[10:11], 2                             // 0000002BFAE4: 8488820A
	v_mul_f32_e32 v9, s2, v9                                   // 0000002BFAE8: 10121202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFAEC: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000002BFAF0: 101412FF BFB8AA3B
	v_exp_f32_e32 v10, v10                                     // 0000002BFAF8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFAFC: BF870095
	v_add_f32_e32 v10, 1.0, v10                                // 0000002BFB00: 061414F2
	v_div_scale_f32 v14, null, v10, v10, v9                    // 0000002BFB04: D6FC7C0E 0426150A
	v_div_scale_f32 v17, vcc_lo, v9, v10, v9                   // 0000002BFB0C: D6FC6A11 04261509
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BFB14: BF870292
	v_rcp_f32_e32 v15, v14                                     // 0000002BFB18: 7E1E550E
	v_fma_f32 v16, -v14, v15, 1.0                              // 0000002BFB1C: D6130010 23CA1F0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFB24: BF870091
	v_fmac_f32_e32 v15, v16, v15                               // 0000002BFB28: 561E1F10
	v_mul_f32_e32 v16, v17, v15                                // 0000002BFB2C: 10201F11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFB30: BF870091
	v_fma_f32 v18, -v14, v16, v17                              // 0000002BFB34: D6130012 2446210E
	v_fmac_f32_e32 v16, v18, v15                               // 0000002BFB3C: 56201F12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFB40: BF870091
	v_fma_f32 v14, -v14, v16, v17                              // 0000002BFB44: D613000E 2446210E
	v_div_fmas_f32 v14, v14, v15, v16                          // 0000002BFB4C: D637000E 04421F0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFB54: BF870091
	v_div_fixup_f32 v9, v14, v10, v9                           // 0000002BFB58: D6270009 0426150E
	v_bfe_u32 v10, v9, 16, 1                                   // 0000002BFB60: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BFB68: BF8700A1
	v_add3_u32 v14, v9, v10, 0x7fff                            // 0000002BFB6C: D655000E 03FE1509 00007FFF
	.long 0xd7006a09                                           // 0000002BFB78: D7006A09
	v_cndmask_b32_e32 v0, v0, v8, vcc_lo                       // 0000002BFB7C: 02001100
	v_add_co_ci_u32_e64 v10, null, s9, v1, vcc_lo              // 0000002BFB80: D5207C0A 01AA0209
	global_store_d16_hi_b16 v[9:10], v14, off                  // 0000002BFB88: DC960000 007C0E09
	s_mov_b32 s9, -1                                           // 0000002BFB90: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002BFB94: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002BFB98: BF048303
	s_mov_b32 s8, 0                                            // 0000002BFB9C: BE880080
	s_cbranch_scc1 133                                         // 0000002BFBA0: BFA20085 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x23b8>
	s_cmp_gt_i32 s3, 3                                         // 0000002BFBA4: BF028303
	s_cbranch_scc0 81                                          // 0000002BFBA8: BFA10051 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x22f0>
	s_cmp_gt_i32 s3, 4                                         // 0000002BFBAC: BF028403
	s_cbranch_scc0 40                                          // 0000002BFBB0: BFA10028 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2254>
	s_cmp_eq_u32 s3, 5                                         // 0000002BFBB4: BF068503
	s_mov_b32 s8, -1                                           // 0000002BFBB8: BE8800C1
	s_cbranch_scc0 36                                          // 0000002BFBBC: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2250>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002BFBC0: F4040208 F8000010
	v_dual_mov_b32 v9, s5 :: v_dual_mov_b32 v14, s4            // 0000002BFBC8: CA100005 090E0004
	s_waitcnt lgkmcnt(0)                                       // 0000002BFBD0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BFBD4: BF870111
	v_cndmask_b32_e64 v10, s9, v9, s0                          // 0000002BFBD8: D501000A 00021209
	v_cndmask_b32_e64 v9, s8, v14, s0                          // 0000002BFBE0: D5010009 00021C08
	s_mov_b32 s8, 0                                            // 0000002BFBE8: BE880080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFBEC: BF870091
	v_mad_u64_u32 v[9:10], null, s6, 6, v[9:10]                // 0000002BFBF0: D6FE7C09 04250C06
	v_mad_u64_u32 v[14:15], null, s7, 6, v[10:11]              // 0000002BFBF8: D6FE7C0E 04290C07
	.long 0xd73c000f                                           // 0000002BFC00: D73C000F
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002BFC04: 02020881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002BFC08: BF870223
	.long 0xd7006a09                                           // 0000002BFC0C: D7006A09
	v_cndmask_b32_e32 v1, v9, v12, vcc_lo                      // 0000002BFC10: 02021909
	v_bfe_u32 v10, v13, 16, 1                                  // 0000002BFC14: D610000A 0205210D
	v_add_co_ci_u32_e64 v14, null, v14, v11, vcc_lo            // 0000002BFC1C: D5207C0E 01AA170E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BFC24: BF870193
	.long 0xd7006a09                                           // 0000002BFC28: D7006A09
	v_cndmask_b32_e32 v1, v9, v15, vcc_lo                      // 0000002BFC2C: 02021F09
	v_add3_u32 v17, v13, v10, 0x7fff                           // 0000002BFC30: D6550011 03FE150D 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002BFC3C: BF870003
	v_add_co_ci_u32_e64 v10, null, v14, v16, vcc_lo            // 0000002BFC40: D5207C0A 01AA210E
	global_store_d16_hi_b16 v[9:10], v17, off                  // 0000002BFC48: DC960000 007C1109
	s_mov_b32 s9, 0                                            // 0000002BFC50: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BFC54: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002BFC58: 8B6A097E
	s_cbranch_vccz 35                                          // 0000002BFC5C: BFA30023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x22ec>
	v_mul_f32_e32 v9, 0xbfb8aa3b, v13                          // 0000002BFC60: 10121AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BFC68: BF870291
	v_exp_f32_e32 v9, v9                                       // 0000002BFC6C: 7E124B09
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002BFC70: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BFC74: BF870121
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002BFC78: D6FC7C0A 03CA1309
	v_div_scale_f32 v17, vcc_lo, 1.0, v9, 1.0                  // 0000002BFC80: D6FC6A11 03CA12F2
	v_rcp_f32_e32 v16, v10                                     // 0000002BFC88: 7E20550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFC8C: BF870095
	v_fma_f32 v14, -v10, v16, 1.0                              // 0000002BFC90: D613000E 23CA210A
	v_fmac_f32_e32 v16, v14, v16                               // 0000002BFC98: 5620210E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFC9C: BF870091
	v_mul_f32_e32 v18, v17, v16                                // 0000002BFCA0: 10242111
	v_fma_f32 v14, -v10, v18, v17                              // 0000002BFCA4: D613000E 2446250A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BFCAC: BF870121
	v_fmac_f32_e32 v18, v14, v16                               // 0000002BFCB0: 5624210E
	v_mad_u64_u32 v[14:15], null, s10, 12, v[2:3]              // 0000002BFCB4: D6FE7C0E 0409180A
	v_fma_f32 v10, -v10, v18, v17                              // 0000002BFCBC: D613000A 2446250A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BFCC4: BF870191
	v_div_fmas_f32 v10, v10, v16, v18                          // 0000002BFCC8: D637000A 044A210A
	v_mad_u64_u32 v[15:16], null, s11, 12, v[15:16]            // 0000002BFCD0: D6FE7C0F 043D180B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002BFCD8: BF870002
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000002BFCDC: D6270009 03CA130A
	global_store_b32 v[14:15], v9, off                         // 0000002BFCE4: DC6A0000 007C090E
	s_mov_b32 s9, 0                                            // 0000002BFCEC: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BFCF0: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002BFCF4: 8B6A097E
	s_cbranch_vccz 46                                          // 0000002BFCF8: BFA3002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x23b4>
	v_bfe_u32 v9, v13, 16, 1                                   // 0000002BFCFC: D6100009 0205210D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFD04: BF870091
	v_add3_u32 v9, v13, v9, 0x7fff                             // 0000002BFD08: D6550009 03FE130D 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000002BFD14: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFD1C: BF870091
	v_mul_f32_e32 v9, s2, v9                                   // 0000002BFD20: 10121202
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 0000002BFD24: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BFD2C: BF870291
	v_exp_f32_e32 v9, v9                                       // 0000002BFD30: 7E124B09
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002BFD34: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFD38: BF870091
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002BFD3C: D6FC7C0A 03CA1309
	v_rcp_f32_e32 v16, v10                                     // 0000002BFD44: 7E20550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFD48: BF870095
	v_fma_f32 v14, -v10, v16, 1.0                              // 0000002BFD4C: D613000E 23CA210A
	v_fmac_f32_e32 v16, v14, v16                               // 0000002BFD54: 5620210E
	v_div_scale_f32 v14, vcc_lo, 1.0, v9, 1.0                  // 0000002BFD58: D6FC6A0E 03CA12F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFD60: BF870091
	v_mul_f32_e32 v17, v14, v16                                // 0000002BFD64: 1022210E
	v_fma_f32 v15, -v10, v17, v14                              // 0000002BFD68: D613000F 243A230A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFD70: BF870091
	v_fmac_f32_e32 v17, v15, v16                               // 0000002BFD74: 5622210F
	v_fma_f32 v10, -v10, v17, v14                              // 0000002BFD78: D613000A 243A230A
	v_mad_u64_u32 v[14:15], null, s10, 12, v[2:3]              // 0000002BFD80: D6FE7C0E 0409180A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BFD88: BF870112
	v_div_fmas_f32 v10, v10, v16, v17                          // 0000002BFD8C: D637000A 0446210A
	v_mad_u64_u32 v[15:16], null, s11, 12, v[15:16]            // 0000002BFD94: D6FE7C0F 043D180B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFD9C: BF870092
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000002BFDA0: D6270009 03CA130A
	v_add_f32_e32 v9, v9, v9                                   // 0000002BFDA8: 06121309
	global_store_b32 v[14:15], v9, off                         // 0000002BFDAC: DC6A0000 007C090E
	s_mov_b32 s9, 0                                            // 0000002BFDB4: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BFDB8: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002BFDBC: 8B6A097E
	s_cbranch_vccz 59                                          // 0000002BFDC0: BFA3003B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x24b0>
	s_cmp_gt_i32 s3, 1                                         // 0000002BFDC4: BF028103
	s_mov_b32 s1, -1                                           // 0000002BFDC8: BE8100C1
	s_cbranch_scc0 50                                          // 0000002BFDCC: BFA10032 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2498>
	v_bfe_u32 v9, v13, 16, 1                                   // 0000002BFDD0: D6100009 0205210D
	s_mov_b32 s1, 0                                            // 0000002BFDD8: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFDDC: BF870091
	v_add3_u32 v9, v13, v9, 0x7fff                             // 0000002BFDE0: D6550009 03FE130D 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000002BFDEC: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFDF4: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 0000002BFDF8: 101212FF BFB8AA3B
	v_exp_f32_e32 v9, v9                                       // 0000002BFE00: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFE04: BF870095
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002BFE08: 061212F2
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002BFE0C: D6FC7C0A 03CA1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BFE14: BF870291
	v_rcp_f32_e32 v14, v10                                     // 0000002BFE18: 7E1C550A
	v_fma_f32 v15, -v10, v14, 1.0                              // 0000002BFE1C: D613000F 23CA1D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BFE24: BF8700A1
	v_fmac_f32_e32 v14, v15, v14                               // 0000002BFE28: 561C1D0F
	v_div_scale_f32 v15, vcc_lo, 1.0, v9, 1.0                  // 0000002BFE2C: D6FC6A0F 03CA12F2
	v_mul_f32_e32 v16, v15, v14                                // 0000002BFE34: 10201D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFE38: BF870091
	v_fma_f32 v17, -v10, v16, v15                              // 0000002BFE3C: D6130011 243E210A
	v_fmac_f32_e32 v16, v17, v14                               // 0000002BFE44: 56201D11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFE48: BF870091
	v_fma_f32 v10, -v10, v16, v15                              // 0000002BFE4C: D613000A 243E210A
	v_div_fmas_f32 v10, v10, v14, v16                          // 0000002BFE54: D637000A 04421D0A
	v_mad_u64_u32 v[14:15], null, s10, 6, v[0:1]               // 0000002BFE5C: D6FE7C0E 04010C0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BFE64: BF870112
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000002BFE68: D6270009 03CA130A
	v_mad_u64_u32 v[15:16], null, s11, 6, v[15:16]             // 0000002BFE70: D6FE7C0F 043D0C0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFE78: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 0000002BFE7C: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000002BFE84: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[14:15], v9, off                  // 0000002BFE90: DC960000 007C090E
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002BFE98: 916A017E
	s_mov_b32 s1, 0                                            // 0000002BFE9C: BE810080
	s_cbranch_vccnz 3                                          // 0000002BFEA0: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x24b0>
	s_cmp_lg_u32 s3, 1                                         // 0000002BFEA4: BF078103
	s_mov_b32 s1, -1                                           // 0000002BFEA8: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002BFEAC: 980880C1
	v_bfe_u32 v9, v13, 16, 1                                   // 0000002BFEB0: D6100009 0205210D
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002BFEB8: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BFEBC: BF870001
	v_add3_u32 v9, v13, v9, 0x7fff                             // 0000002BFEC0: D6550009 03FE130D 00007FFF
	s_cbranch_vccz 7                                           // 0000002BFECC: BFA30007 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x24ec>
	v_mad_u64_u32 v[13:14], null, s10, 6, v[0:1]               // 0000002BFED0: D6FE7C0D 04010C0A
	s_mov_b32 s1, 0                                            // 0000002BFED8: BE810080
	v_mad_u64_u32 v[14:15], null, s11, 6, v[14:15]             // 0000002BFEDC: D6FE7C0E 04390C0B
	global_store_d16_hi_b16 v[13:14], v9, off                  // 0000002BFEE4: DC960000 007C090D
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002BFEEC: 916A017E
	s_cbranch_vccnz 45                                         // 0000002BFEF0: BFA4002D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x25a8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFEF4: BF870091
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000002BFEF8: 361212FF FFFF0000
	v_mul_f32_e32 v9, s2, v9                                   // 0000002BFF00: 10121202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFF04: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000002BFF08: 101412FF BFB8AA3B
	v_exp_f32_e32 v10, v10                                     // 0000002BFF10: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFF14: BF870095
	v_add_f32_e32 v10, 1.0, v10                                // 0000002BFF18: 061414F2
	v_div_scale_f32 v13, null, v10, v10, v9                    // 0000002BFF1C: D6FC7C0D 0426150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BFF24: BF870291
	v_rcp_f32_e32 v14, v13                                     // 0000002BFF28: 7E1C550D
	v_fma_f32 v15, -v13, v14, 1.0                              // 0000002BFF2C: D613000F 23CA1D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BFF34: BF8700A1
	v_fmac_f32_e32 v14, v15, v14                               // 0000002BFF38: 561C1D0F
	v_div_scale_f32 v15, vcc_lo, v9, v10, v9                   // 0000002BFF3C: D6FC6A0F 04261509
	v_mul_f32_e32 v16, v15, v14                                // 0000002BFF44: 10201D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFF48: BF870091
	v_fma_f32 v17, -v13, v16, v15                              // 0000002BFF4C: D6130011 243E210D
	v_fmac_f32_e32 v16, v17, v14                               // 0000002BFF54: 56201D11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFF58: BF870091
	v_fma_f32 v13, -v13, v16, v15                              // 0000002BFF5C: D613000D 243E210D
	v_div_fmas_f32 v15, v13, v14, v16                          // 0000002BFF64: D637000F 04421D0D
	v_mad_u64_u32 v[13:14], null, s10, 6, v[0:1]               // 0000002BFF6C: D6FE7C0D 04010C0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BFF74: BF870112
	v_div_fixup_f32 v9, v15, v10, v9                           // 0000002BFF78: D6270009 0426150F
	v_mad_u64_u32 v[14:15], null, s11, 6, v[14:15]             // 0000002BFF80: D6FE7C0E 04390C0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BFF88: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 0000002BFF8C: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000002BFF94: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[13:14], v9, off                  // 0000002BFFA0: DC960000 007C090D
	s_mov_b32 s9, -1                                           // 0000002BFFA8: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002BFFAC: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002BFFB0: BF048303
	s_mov_b32 s8, 0                                            // 0000002BFFB4: BE880080
	s_cbranch_scc1 135                                         // 0000002BFFB8: BFA20087 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x27d8>
	s_cmp_gt_i32 s3, 3                                         // 0000002BFFBC: BF028303
	s_cbranch_scc0 82                                          // 0000002BFFC0: BFA10052 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x270c>
	s_cmp_gt_i32 s3, 4                                         // 0000002BFFC4: BF028403
	s_cbranch_scc0 40                                          // 0000002BFFC8: BFA10028 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x266c>
	s_cmp_eq_u32 s3, 5                                         // 0000002BFFCC: BF068503
	s_mov_b32 s8, -1                                           // 0000002BFFD0: BE8800C1
	s_cbranch_scc0 36                                          // 0000002BFFD4: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2668>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002BFFD8: F4040208 F8000010
	v_dual_mov_b32 v9, s4 :: v_dual_mov_b32 v10, s5            // 0000002BFFE0: CA100004 090A0005
	v_bfe_u32 v13, v8, 16, 1                                   // 0000002BFFE8: D610000D 02052108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002BFFF0: BF8701A1
	v_add3_u32 v13, v8, v13, 0x7fff                            // 0000002BFFF4: D655000D 03FE1B08 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002C0000: BF89FC07
	v_cndmask_b32_e64 v9, s8, v9, s0                           // 0000002C0004: D5010009 00021208
	v_cndmask_b32_e64 v10, s9, v10, s0                         // 0000002C000C: D501000A 00021409
	s_lshl_b64 s[8:9], s[6:7], 3                               // 0000002C0014: 84888306
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000002C0018: BF870482
	.long 0xd7006a0e                                           // 0000002C001C: D7006A0E
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 0000002C0020: 02001109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002C0024: BF8701A1
	v_add_co_ci_u32_e64 v15, null, s9, v10, vcc_lo             // 0000002C0028: D5207C0F 01AA1409
	.long 0xd73c0009                                           // 0000002C0030: D73C0009
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002C0034: 02020881
	.long 0xd7006a0e                                           // 0000002C0038: D7006A0E
	v_cndmask_b32_e32 v1, v14, v12, vcc_lo                     // 0000002C003C: 0202190E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002C0040: BF8700B1
	v_add_co_ci_u32_e64 v15, null, v15, v11, vcc_lo            // 0000002C0044: D5207C0F 01AA170F
	s_mov_b32 s8, 0                                            // 0000002C004C: BE880080
	.long 0xd7006a09                                           // 0000002C0050: D7006A09
	v_cndmask_b32_e32 v1, v14, v9, vcc_lo                      // 0000002C0054: 0202130E
	v_add_co_ci_u32_e64 v10, null, v15, v10, vcc_lo            // 0000002C0058: D5207C0A 01AA150F
	global_store_d16_hi_b16 v[9:10], v13, off                  // 0000002C0060: DC960000 007C0D09
	s_mov_b32 s9, 0                                            // 0000002C0068: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C006C: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C0070: 8B6A097E
	s_cbranch_vccz 36                                          // 0000002C0074: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2708>
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 0000002C0078: 101210FF BFB8AA3B
	s_lshl_b64 s[12:13], s[10:11], 4                           // 0000002C0080: 848C840A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C0084: BF870291
	v_exp_f32_e32 v9, v9                                       // 0000002C0088: 7E124B09
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002C008C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C0090: BF870121
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002C0094: D6FC7C0A 03CA1309
	v_div_scale_f32 v15, vcc_lo, 1.0, v9, 1.0                  // 0000002C009C: D6FC6A0F 03CA12F2
	v_rcp_f32_e32 v13, v10                                     // 0000002C00A4: 7E1A550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C00A8: BF870095
	v_fma_f32 v14, -v10, v13, 1.0                              // 0000002C00AC: D613000E 23CA1B0A
	v_fmac_f32_e32 v13, v14, v13                               // 0000002C00B4: 561A1B0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C00B8: BF870091
	v_mul_f32_e32 v14, v15, v13                                // 0000002C00BC: 101C1B0F
	v_fma_f32 v16, -v10, v14, v15                              // 0000002C00C0: D6130010 243E1D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C00C8: BF870091
	v_fmac_f32_e32 v14, v16, v13                               // 0000002C00CC: 561C1B10
	v_fma_f32 v10, -v10, v14, v15                              // 0000002C00D0: D613000A 243E1D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C00D8: BF870091
	v_div_fmas_f32 v10, v10, v13, v14                          // 0000002C00DC: D637000A 043A1B0A
	v_div_fixup_f32 v13, v10, v9, 1.0                          // 0000002C00E4: D627000D 03CA130A
	.long 0xd7006a09                                           // 0000002C00EC: D7006A09
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 0000002C00F0: 02001902
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C00F4: BF870001
	v_add_co_ci_u32_e64 v10, null, s13, v3, vcc_lo             // 0000002C00F8: D5207C0A 01AA060D
	global_store_b32 v[9:10], v13, off                         // 0000002C0100: DC6A0000 007C0D09
	s_mov_b32 s9, 0                                            // 0000002C0108: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C010C: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C0110: 8B6A097E
	s_cbranch_vccz 47                                          // 0000002C0114: BFA3002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x27d4>
	v_bfe_u32 v9, v8, 16, 1                                    // 0000002C0118: D6100009 02052108
	s_lshl_b64 s[12:13], s[10:11], 4                           // 0000002C0120: 848C840A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0124: BF870091
	v_add3_u32 v9, v8, v9, 0x7fff                              // 0000002C0128: D6550009 03FE1308 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000002C0134: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C013C: BF870091
	v_mul_f32_e32 v9, s2, v9                                   // 0000002C0140: 10121202
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 0000002C0144: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C014C: BF870291
	v_exp_f32_e32 v9, v9                                       // 0000002C0150: 7E124B09
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002C0154: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C0158: BF870121
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002C015C: D6FC7C0A 03CA1309
	v_div_scale_f32 v15, vcc_lo, 1.0, v9, 1.0                  // 0000002C0164: D6FC6A0F 03CA12F2
	v_rcp_f32_e32 v13, v10                                     // 0000002C016C: 7E1A550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0170: BF870095
	v_fma_f32 v14, -v10, v13, 1.0                              // 0000002C0174: D613000E 23CA1B0A
	v_fmac_f32_e32 v13, v14, v13                               // 0000002C017C: 561A1B0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0180: BF870091
	v_mul_f32_e32 v14, v15, v13                                // 0000002C0184: 101C1B0F
	v_fma_f32 v16, -v10, v14, v15                              // 0000002C0188: D6130010 243E1D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0190: BF870091
	v_fmac_f32_e32 v14, v16, v13                               // 0000002C0194: 561C1B10
	v_fma_f32 v10, -v10, v14, v15                              // 0000002C0198: D613000A 243E1D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C01A0: BF870091
	v_div_fmas_f32 v10, v10, v13, v14                          // 0000002C01A4: D637000A 043A1B0A
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000002C01AC: D6270009 03CA130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C01B4: BF8700A1
	v_add_f32_e32 v13, v9, v9                                  // 0000002C01B8: 061A1309
	.long 0xd7006a09                                           // 0000002C01BC: D7006A09
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 0000002C01C0: 02001902
	v_add_co_ci_u32_e64 v10, null, s13, v3, vcc_lo             // 0000002C01C4: D5207C0A 01AA060D
	global_store_b32 v[9:10], v13, off                         // 0000002C01CC: DC6A0000 007C0D09
	s_mov_b32 s9, 0                                            // 0000002C01D4: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C01D8: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C01DC: 8B6A097E
	s_cbranch_vccz 60                                          // 0000002C01E0: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x28d4>
	s_cmp_gt_i32 s3, 1                                         // 0000002C01E4: BF028103
	s_mov_b32 s1, -1                                           // 0000002C01E8: BE8100C1
	s_cbranch_scc0 51                                          // 0000002C01EC: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x28bc>
	v_bfe_u32 v9, v8, 16, 1                                    // 0000002C01F0: D6100009 02052108
	s_lshl_b64 s[12:13], s[10:11], 3                           // 0000002C01F8: 848C830A
	s_mov_b32 s1, 0                                            // 0000002C01FC: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0200: BF870091
	v_add3_u32 v9, v8, v9, 0x7fff                              // 0000002C0204: D6550009 03FE1308 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000002C0210: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0218: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 0000002C021C: 101212FF BFB8AA3B
	v_exp_f32_e32 v9, v9                                       // 0000002C0224: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0228: BF870095
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002C022C: 061212F2
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002C0230: D6FC7C0A 03CA1309
	v_div_scale_f32 v15, vcc_lo, 1.0, v9, 1.0                  // 0000002C0238: D6FC6A0F 03CA12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C0240: BF870292
	v_rcp_f32_e32 v13, v10                                     // 0000002C0244: 7E1A550A
	v_fma_f32 v14, -v10, v13, 1.0                              // 0000002C0248: D613000E 23CA1B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0250: BF870091
	v_fmac_f32_e32 v13, v14, v13                               // 0000002C0254: 561A1B0E
	v_mul_f32_e32 v14, v15, v13                                // 0000002C0258: 101C1B0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C025C: BF870091
	v_fma_f32 v16, -v10, v14, v15                              // 0000002C0260: D6130010 243E1D0A
	v_fmac_f32_e32 v14, v16, v13                               // 0000002C0268: 561C1B10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C026C: BF870091
	v_fma_f32 v10, -v10, v14, v15                              // 0000002C0270: D613000A 243E1D0A
	v_div_fmas_f32 v10, v10, v13, v14                          // 0000002C0278: D637000A 043A1B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0280: BF870091
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000002C0284: D6270009 03CA130A
	v_bfe_u32 v10, v9, 16, 1                                   // 0000002C028C: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C0294: BF8700A1
	v_add3_u32 v13, v9, v10, 0x7fff                            // 0000002C0298: D655000D 03FE1509 00007FFF
	.long 0xd7006a09                                           // 0000002C02A4: D7006A09
	v_cndmask_b32_e32 v0, v0, v12, vcc_lo                      // 0000002C02A8: 02001900
	v_add_co_ci_u32_e64 v10, null, s13, v1, vcc_lo             // 0000002C02AC: D5207C0A 01AA020D
	global_store_d16_hi_b16 v[9:10], v13, off                  // 0000002C02B4: DC960000 007C0D09
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002C02BC: 916A017E
	s_mov_b32 s1, 0                                            // 0000002C02C0: BE810080
	s_cbranch_vccnz 3                                          // 0000002C02C4: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x28d4>
	s_cmp_lg_u32 s3, 1                                         // 0000002C02C8: BF078103
	s_mov_b32 s1, -1                                           // 0000002C02CC: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002C02D0: 980880C1
	v_bfe_u32 v9, v8, 16, 1                                    // 0000002C02D4: D6100009 02052108
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002C02DC: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C02E0: BF870001
	v_add3_u32 v8, v8, v9, 0x7fff                              // 0000002C02E4: D6550008 03FE1308 00007FFF
	s_cbranch_vccz 9                                           // 0000002C02F0: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2918>
	s_lshl_b64 s[8:9], s[10:11], 3                             // 0000002C02F4: 8488830A
	s_mov_b32 s1, 0                                            // 0000002C02F8: BE810080
	.long 0xd7006a09                                           // 0000002C02FC: D7006A09
	v_cndmask_b32_e32 v0, v0, v8, vcc_lo                       // 0000002C0300: 02001100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C0304: BF870001
	v_add_co_ci_u32_e64 v10, null, s9, v1, vcc_lo              // 0000002C0308: D5207C0A 01AA0209
	global_store_d16_hi_b16 v[9:10], v8, off                   // 0000002C0310: DC960000 007C0809
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002C0318: 916A017E
	s_cbranch_vccnz 46                                         // 0000002C031C: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x29d8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C0320: BF8700A1
	v_and_b32_e32 v8, 0xffff0000, v8                           // 0000002C0324: 361010FF FFFF0000
	s_lshl_b64 s[8:9], s[10:11], 3                             // 0000002C032C: 8488830A
	v_mul_f32_e32 v8, s2, v8                                   // 0000002C0330: 10101002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0334: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 0000002C0338: 101210FF BFB8AA3B
	v_exp_f32_e32 v9, v9                                       // 0000002C0340: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0344: BF870095
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002C0348: 061212F2
	v_div_scale_f32 v10, null, v9, v9, v8                      // 0000002C034C: D6FC7C0A 04221309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C0354: BF870291
	v_rcp_f32_e32 v13, v10                                     // 0000002C0358: 7E1A550A
	v_fma_f32 v14, -v10, v13, 1.0                              // 0000002C035C: D613000E 23CA1B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C0364: BF8700A1
	v_fmac_f32_e32 v13, v14, v13                               // 0000002C0368: 561A1B0E
	v_div_scale_f32 v15, vcc_lo, v8, v9, v8                    // 0000002C036C: D6FC6A0F 04221308
	v_mul_f32_e32 v14, v15, v13                                // 0000002C0374: 101C1B0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0378: BF870091
	v_fma_f32 v16, -v10, v14, v15                              // 0000002C037C: D6130010 243E1D0A
	v_fmac_f32_e32 v14, v16, v13                               // 0000002C0384: 561C1B10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0388: BF870091
	v_fma_f32 v10, -v10, v14, v15                              // 0000002C038C: D613000A 243E1D0A
	v_div_fmas_f32 v10, v10, v13, v14                          // 0000002C0394: D637000A 043A1B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C039C: BF870091
	v_div_fixup_f32 v8, v10, v9, v8                            // 0000002C03A0: D6270008 0422130A
	v_bfe_u32 v9, v8, 16, 1                                    // 0000002C03A8: D6100009 02052108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C03B0: BF8700A1
	v_add3_u32 v10, v8, v9, 0x7fff                             // 0000002C03B4: D655000A 03FE1308 00007FFF
	.long 0xd7006a08                                           // 0000002C03C0: D7006A08
	v_cndmask_b32_e32 v0, v0, v8, vcc_lo                       // 0000002C03C4: 02001100
	v_add_co_ci_u32_e64 v9, null, s9, v1, vcc_lo               // 0000002C03C8: D5207C09 01AA0209
	global_store_d16_hi_b16 v[8:9], v10, off                   // 0000002C03D0: DC960000 007C0A08
	s_mov_b32 s9, -1                                           // 0000002C03D8: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002C03DC: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002C03E0: BF048303
	s_mov_b32 s8, 0                                            // 0000002C03E4: BE880080
	s_cbranch_scc1 133                                         // 0000002C03E8: BFA20085 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2c00>
	s_cmp_gt_i32 s3, 3                                         // 0000002C03EC: BF028303
	s_cbranch_scc0 81                                          // 0000002C03F0: BFA10051 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2b38>
	s_cmp_gt_i32 s3, 4                                         // 0000002C03F4: BF028403
	s_cbranch_scc0 40                                          // 0000002C03F8: BFA10028 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2a9c>
	s_cmp_eq_u32 s3, 5                                         // 0000002C03FC: BF068503
	s_mov_b32 s8, -1                                           // 0000002C0400: BE8800C1
	s_cbranch_scc0 36                                          // 0000002C0404: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2a98>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002C0408: F4040208 F8000010
	v_mov_b32_e32 v8, s5                                       // 0000002C0410: 7E100205
	v_mov_b32_e32 v10, s4                                      // 0000002C0414: 7E140204
	.long 0xd73c000d                                           // 0000002C0418: D73C000D
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002C041C: 02020881
	s_waitcnt lgkmcnt(0)                                       // 0000002C0420: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C0424: BF870193
	v_cndmask_b32_e64 v9, s9, v8, s0                           // 0000002C0428: D5010009 00021009
	v_cndmask_b32_e64 v8, s8, v10, s0                          // 0000002C0430: D5010008 00021408
	s_mov_b32 s8, 0                                            // 0000002C0438: BE880080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C043C: BF870091
	v_mad_u64_u32 v[8:9], null, s6, 10, v[8:9]                 // 0000002C0440: D6FE7C08 04211406
	v_mad_u64_u32 v[9:10], null, s7, 10, v[9:10]               // 0000002C0448: D6FE7C09 04251407
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C0450: BF8700A2
	.long 0xd7006a08                                           // 0000002C0454: D7006A08
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 0000002C0458: 02021908
	v_bfe_u32 v10, v7, 16, 1                                   // 0000002C045C: D610000A 02052107
	v_add3_u32 v10, v7, v10, 0x7fff                            // 0000002C0464: D655000A 03FE1507 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002C0470: BF870214
	v_add_co_ci_u32_e64 v9, null, v9, v11, vcc_lo              // 0000002C0474: D5207C09 01AA1709
	.long 0xd7006a08                                           // 0000002C047C: D7006A08
	v_cndmask_b32_e32 v1, v8, v13, vcc_lo                      // 0000002C0480: 02021B08
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C0484: BF870001
	v_add_co_ci_u32_e64 v9, null, v9, v14, vcc_lo              // 0000002C0488: D5207C09 01AA1D09
	global_store_d16_hi_b16 v[8:9], v10, off                   // 0000002C0490: DC960000 007C0A08
	s_mov_b32 s9, 0                                            // 0000002C0498: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C049C: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C04A0: 8B6A097E
	s_cbranch_vccz 35                                          // 0000002C04A4: BFA30023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2b34>
	v_mul_f32_e32 v8, 0xbfb8aa3b, v7                           // 0000002C04A8: 10100EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C04B0: BF870291
	v_exp_f32_e32 v8, v8                                       // 0000002C04B4: 7E104B08
	v_add_f32_e32 v13, 1.0, v8                                 // 0000002C04B8: 061A10F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C04BC: BF870091
	v_div_scale_f32 v10, null, v13, v13, 1.0                   // 0000002C04C0: D6FC7C0A 03CA1B0D
	v_rcp_f32_e32 v14, v10                                     // 0000002C04C8: 7E1C550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C04CC: BF870095
	v_fma_f32 v8, -v10, v14, 1.0                               // 0000002C04D0: D6130008 23CA1D0A
	v_fmac_f32_e32 v14, v8, v14                                // 0000002C04D8: 561C1D08
	v_div_scale_f32 v15, vcc_lo, 1.0, v13, 1.0                 // 0000002C04DC: D6FC6A0F 03CA1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C04E4: BF870091
	v_mul_f32_e32 v16, v15, v14                                // 0000002C04E8: 10201D0F
	v_fma_f32 v8, -v10, v16, v15                               // 0000002C04EC: D6130008 243E210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C04F4: BF870121
	v_fmac_f32_e32 v16, v8, v14                                // 0000002C04F8: 56201D08
	v_mad_u64_u32 v[8:9], null, s10, 20, v[2:3]                // 0000002C04FC: D6FE7C08 0409280A
	v_fma_f32 v10, -v10, v16, v15                              // 0000002C0504: D613000A 243E210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C050C: BF870191
	v_div_fmas_f32 v14, v10, v14, v16                          // 0000002C0510: D637000E 04421D0A
	v_mad_u64_u32 v[9:10], null, s11, 20, v[9:10]              // 0000002C0518: D6FE7C09 0425280B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002C0520: BF870002
	v_div_fixup_f32 v10, v14, v13, 1.0                         // 0000002C0524: D627000A 03CA1B0E
	global_store_b32 v[8:9], v10, off                          // 0000002C052C: DC6A0000 007C0A08
	s_mov_b32 s9, 0                                            // 0000002C0534: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C0538: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C053C: 8B6A097E
	s_cbranch_vccz 46                                          // 0000002C0540: BFA3002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2bfc>
	v_bfe_u32 v8, v7, 16, 1                                    // 0000002C0544: D6100008 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C054C: BF870091
	v_add3_u32 v8, v7, v8, 0x7fff                              // 0000002C0550: D6550008 03FE1107 00007FFF
	v_and_b32_e32 v8, 0xffff0000, v8                           // 0000002C055C: 361010FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0564: BF870091
	v_mul_f32_e32 v8, s2, v8                                   // 0000002C0568: 10101002
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 0000002C056C: 101010FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C0574: BF870291
	v_exp_f32_e32 v8, v8                                       // 0000002C0578: 7E104B08
	v_add_f32_e32 v10, 1.0, v8                                 // 0000002C057C: 061410F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0580: BF870091
	v_div_scale_f32 v8, null, v10, v10, 1.0                    // 0000002C0584: D6FC7C08 03CA150A
	v_rcp_f32_e32 v13, v8                                      // 0000002C058C: 7E1A5508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0590: BF870095
	v_fma_f32 v9, -v8, v13, 1.0                                // 0000002C0594: D6130009 23CA1B08
	v_fmac_f32_e32 v13, v9, v13                                // 0000002C059C: 561A1B09
	v_div_scale_f32 v9, vcc_lo, 1.0, v10, 1.0                  // 0000002C05A0: D6FC6A09 03CA14F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C05A8: BF870091
	v_mul_f32_e32 v14, v9, v13                                 // 0000002C05AC: 101C1B09
	v_fma_f32 v15, -v8, v14, v9                                // 0000002C05B0: D613000F 24261D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C05B8: BF870091
	v_fmac_f32_e32 v14, v15, v13                               // 0000002C05BC: 561C1B0F
	v_fma_f32 v15, -v8, v14, v9                                // 0000002C05C0: D613000F 24261D08
	v_mad_u64_u32 v[8:9], null, s10, 20, v[2:3]                // 0000002C05C8: D6FE7C08 0409280A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C05D0: BF870092
	v_div_fmas_f32 v13, v15, v13, v14                          // 0000002C05D4: D637000D 043A1B0F
	v_div_fixup_f32 v13, v13, v10, 1.0                         // 0000002C05DC: D627000D 03CA150D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C05E4: BF870113
	v_mad_u64_u32 v[9:10], null, s11, 20, v[9:10]              // 0000002C05E8: D6FE7C09 0425280B
	v_add_f32_e32 v10, v13, v13                                // 0000002C05F0: 06141B0D
	global_store_b32 v[8:9], v10, off                          // 0000002C05F4: DC6A0000 007C0A08
	s_mov_b32 s9, 0                                            // 0000002C05FC: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C0600: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C0604: 8B6A097E
	s_cbranch_vccz 59                                          // 0000002C0608: BFA3003B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2cf8>
	s_cmp_gt_i32 s3, 1                                         // 0000002C060C: BF028103
	s_mov_b32 s1, -1                                           // 0000002C0610: BE8100C1
	s_cbranch_scc0 50                                          // 0000002C0614: BFA10032 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2ce0>
	v_bfe_u32 v8, v7, 16, 1                                    // 0000002C0618: D6100008 02052107
	s_mov_b32 s1, 0                                            // 0000002C0620: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0624: BF870091
	v_add3_u32 v8, v7, v8, 0x7fff                              // 0000002C0628: D6550008 03FE1107 00007FFF
	v_and_b32_e32 v8, 0xffff0000, v8                           // 0000002C0634: 361010FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C063C: BF870091
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 0000002C0640: 101010FF BFB8AA3B
	v_exp_f32_e32 v8, v8                                       // 0000002C0648: 7E104B08
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C064C: BF870095
	v_add_f32_e32 v10, 1.0, v8                                 // 0000002C0650: 061410F2
	v_div_scale_f32 v8, null, v10, v10, 1.0                    // 0000002C0654: D6FC7C08 03CA150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C065C: BF870291
	v_rcp_f32_e32 v9, v8                                       // 0000002C0660: 7E125508
	v_fma_f32 v13, -v8, v9, 1.0                                // 0000002C0664: D613000D 23CA1308
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C066C: BF8700A1
	v_fmac_f32_e32 v9, v13, v9                                 // 0000002C0670: 5612130D
	v_div_scale_f32 v13, vcc_lo, 1.0, v10, 1.0                 // 0000002C0674: D6FC6A0D 03CA14F2
	v_mul_f32_e32 v14, v13, v9                                 // 0000002C067C: 101C130D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0680: BF870091
	v_fma_f32 v15, -v8, v14, v13                               // 0000002C0684: D613000F 24361D08
	v_fmac_f32_e32 v14, v15, v9                                // 0000002C068C: 561C130F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0690: BF870091
	v_fma_f32 v8, -v8, v14, v13                                // 0000002C0694: D6130008 24361D08
	v_div_fmas_f32 v13, v8, v9, v14                            // 0000002C069C: D637000D 043A1308
	v_mad_u64_u32 v[8:9], null, s10, 10, v[0:1]                // 0000002C06A4: D6FE7C08 0401140A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C06AC: BF870112
	v_div_fixup_f32 v13, v13, v10, 1.0                         // 0000002C06B0: D627000D 03CA150D
	v_mad_u64_u32 v[9:10], null, s11, 10, v[9:10]              // 0000002C06B8: D6FE7C09 0425140B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C06C0: BF870092
	v_bfe_u32 v14, v13, 16, 1                                  // 0000002C06C4: D610000E 0205210D
	v_add3_u32 v10, v13, v14, 0x7fff                           // 0000002C06CC: D655000A 03FE1D0D 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off                   // 0000002C06D8: DC960000 007C0A08
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002C06E0: 916A017E
	s_mov_b32 s1, 0                                            // 0000002C06E4: BE810080
	s_cbranch_vccnz 3                                          // 0000002C06E8: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2cf8>
	s_cmp_lg_u32 s3, 1                                         // 0000002C06EC: BF078103
	s_mov_b32 s1, -1                                           // 0000002C06F0: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002C06F4: 980880C1
	v_bfe_u32 v8, v7, 16, 1                                    // 0000002C06F8: D6100008 02052107
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002C0700: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C0704: BF870001
	v_add3_u32 v7, v7, v8, 0x7fff                              // 0000002C0708: D6550007 03FE1107 00007FFF
	s_cbranch_vccz 7                                           // 0000002C0714: BFA30007 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2d34>
	v_mad_u64_u32 v[8:9], null, s10, 10, v[0:1]                // 0000002C0718: D6FE7C08 0401140A
	s_mov_b32 s1, 0                                            // 0000002C0720: BE810080
	v_mad_u64_u32 v[9:10], null, s11, 10, v[9:10]              // 0000002C0724: D6FE7C09 0425140B
	global_store_d16_hi_b16 v[8:9], v7, off                    // 0000002C072C: DC960000 007C0708
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002C0734: 916A017E
	s_cbranch_vccnz 45                                         // 0000002C0738: BFA4002D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2df0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C073C: BF870091
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000002C0740: 360E0EFF FFFF0000
	v_mul_f32_e32 v9, s2, v7                                   // 0000002C0748: 10120E02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C074C: BF870091
	v_mul_f32_e32 v7, 0xbfb8aa3b, v9                           // 0000002C0750: 100E12FF BFB8AA3B
	v_exp_f32_e32 v7, v7                                       // 0000002C0758: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C075C: BF870095
	v_add_f32_e32 v10, 1.0, v7                                 // 0000002C0760: 06140EF2
	v_div_scale_f32 v7, null, v10, v10, v9                     // 0000002C0764: D6FC7C07 0426150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C076C: BF870291
	v_rcp_f32_e32 v8, v7                                       // 0000002C0770: 7E105507
	v_fma_f32 v13, -v7, v8, 1.0                                // 0000002C0774: D613000D 23CA1107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C077C: BF8700A1
	v_fmac_f32_e32 v8, v13, v8                                 // 0000002C0780: 5610110D
	v_div_scale_f32 v13, vcc_lo, v9, v10, v9                   // 0000002C0784: D6FC6A0D 04261509
	v_mul_f32_e32 v14, v13, v8                                 // 0000002C078C: 101C110D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0790: BF870091
	v_fma_f32 v15, -v7, v14, v13                               // 0000002C0794: D613000F 24361D07
	v_fmac_f32_e32 v14, v15, v8                                // 0000002C079C: 561C110F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C07A0: BF870091
	v_fma_f32 v7, -v7, v14, v13                                // 0000002C07A4: D6130007 24361D07
	v_div_fmas_f32 v13, v7, v8, v14                            // 0000002C07AC: D637000D 043A1107
	v_mad_u64_u32 v[7:8], null, s10, 10, v[0:1]                // 0000002C07B4: D6FE7C07 0401140A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C07BC: BF870112
	v_div_fixup_f32 v10, v13, v10, v9                          // 0000002C07C0: D627000A 0426150D
	v_mad_u64_u32 v[8:9], null, s11, 10, v[8:9]                // 0000002C07C8: D6FE7C08 0421140B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C07D0: BF870092
	v_bfe_u32 v13, v10, 16, 1                                  // 0000002C07D4: D610000D 0205210A
	v_add3_u32 v9, v10, v13, 0x7fff                            // 0000002C07DC: D6550009 03FE1B0A 00007FFF
	global_store_d16_hi_b16 v[7:8], v9, off                    // 0000002C07E8: DC960000 007C0907
	s_mov_b32 s9, -1                                           // 0000002C07F0: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002C07F4: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002C07F8: BF048303
	s_mov_b32 s8, 0                                            // 0000002C07FC: BE880080
	s_cbranch_scc1 134                                         // 0000002C0800: BFA20086 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x301c>
	s_cmp_gt_i32 s3, 3                                         // 0000002C0804: BF028303
	s_cbranch_scc0 43                                          // 0000002C0808: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2eb8>
	s_cmp_gt_i32 s3, 4                                         // 0000002C080C: BF028403
	s_cbranch_scc0 43                                          // 0000002C0810: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2ec0>
	s_cmp_eq_u32 s3, 5                                         // 0000002C0814: BF068503
	s_mov_b32 s8, -1                                           // 0000002C0818: BE8800C1
	s_cbranch_scc0 36                                          // 0000002C081C: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2eb0>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002C0820: F4040208 F8000010
	v_mov_b32_e32 v7, s5                                       // 0000002C0828: 7E0E0205
	v_mov_b32_e32 v9, s4                                       // 0000002C082C: 7E120204
	.long 0xd73c0004                                           // 0000002C0830: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002C0834: 02020881
	s_waitcnt lgkmcnt(0)                                       // 0000002C0838: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C083C: BF870193
	v_cndmask_b32_e64 v8, s9, v7, s0                           // 0000002C0840: D5010008 00020E09
	v_cndmask_b32_e64 v7, s8, v9, s0                           // 0000002C0848: D5010007 00021208
	s_mov_b32 s8, 0                                            // 0000002C0850: BE880080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0854: BF870091
	v_mad_u64_u32 v[7:8], null, s6, 12, v[7:8]                 // 0000002C0858: D6FE7C07 041D1806
	v_mad_u64_u32 v[8:9], null, s7, 12, v[8:9]                 // 0000002C0860: D6FE7C08 04211807
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C0868: BF8700A2
	.long 0xd7006a07                                           // 0000002C086C: D7006A07
	v_cndmask_b32_e32 v1, v7, v12, vcc_lo                      // 0000002C0870: 02021907
	v_bfe_u32 v9, v6, 16, 1                                    // 0000002C0874: D6100009 02052106
	v_add3_u32 v9, v6, v9, 0x7fff                              // 0000002C087C: D6550009 03FE1306 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002C0888: BF870214
	v_add_co_ci_u32_e64 v8, null, v8, v11, vcc_lo              // 0000002C088C: D5207C08 01AA1708
	.long 0xd7006a04                                           // 0000002C0894: D7006A04
	v_cndmask_b32_e32 v1, v7, v4, vcc_lo                       // 0000002C0898: 02020907
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C089C: BF870001
	v_add_co_ci_u32_e64 v5, null, v8, v5, vcc_lo               // 0000002C08A0: D5207C05 01AA0B08
	global_store_d16_hi_b16 v[4:5], v9, off                    // 0000002C08A8: DC960000 007C0904
	s_mov_b32 s0, 0                                            // 0000002C08B0: BE800080
	s_branch 3                                                 // 0000002C08B4: BFA00003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2ec4>
	s_cbranch_execnz 41                                        // 0000002C08B8: BFA60029 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2f60>
	s_branch 86                                                // 0000002C08BC: BFA00056 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3018>
	s_mov_b32 s0, -1                                           // 0000002C08C0: BE8000C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C08C4: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 0000002C08C8: 8B6A007E
	s_cbranch_vccz 35                                          // 0000002C08CC: BFA30023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2f5c>
	v_mul_f32_e32 v4, 0xbfb8aa3b, v6                           // 0000002C08D0: 10080CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C08D8: BF870291
	v_exp_f32_e32 v4, v4                                       // 0000002C08DC: 7E084B04
	v_add_f32_e32 v4, 1.0, v4                                  // 0000002C08E0: 060808F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C08E4: BF870121
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 0000002C08E8: D6FC7C05 03CA0904
	v_div_scale_f32 v10, vcc_lo, 1.0, v4, 1.0                  // 0000002C08F0: D6FC6A0A 03CA08F2
	v_rcp_f32_e32 v9, v5                                       // 0000002C08F8: 7E125505
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C08FC: BF870095
	v_fma_f32 v7, -v5, v9, 1.0                                 // 0000002C0900: D6130007 23CA1305
	v_fmac_f32_e32 v9, v7, v9                                  // 0000002C0908: 56121307
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C090C: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 0000002C0910: 1016130A
	v_fma_f32 v7, -v5, v11, v10                                // 0000002C0914: D6130007 242A1705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C091C: BF870121
	v_fmac_f32_e32 v11, v7, v9                                 // 0000002C0920: 56161307
	v_mad_u64_u32 v[7:8], null, s10, 24, v[2:3]                // 0000002C0924: D6FE7C07 0409300A
	v_fma_f32 v5, -v5, v11, v10                                // 0000002C092C: D6130005 242A1705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C0934: BF870191
	v_div_fmas_f32 v5, v5, v9, v11                             // 0000002C0938: D6370005 042E1305
	v_mad_u64_u32 v[8:9], null, s11, 24, v[8:9]                // 0000002C0940: D6FE7C08 0421300B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002C0948: BF870002
	v_div_fixup_f32 v4, v5, v4, 1.0                            // 0000002C094C: D6270004 03CA0905
	global_store_b32 v[7:8], v4, off                           // 0000002C0954: DC6A0000 007C0407
	s_branch 46                                                // 0000002C095C: BFA0002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3018>
	v_bfe_u32 v4, v6, 16, 1                                    // 0000002C0960: D6100004 02052106
	v_mad_u64_u32 v[2:3], null, s10, 24, v[2:3]                // 0000002C0968: D6FE7C02 0409300A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0970: BF870092
	v_add3_u32 v4, v6, v4, 0x7fff                              // 0000002C0974: D6550004 03FE0906 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000002C0980: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0988: BF870091
	v_mul_f32_e32 v4, s2, v4                                   // 0000002C098C: 10080802
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 0000002C0990: 100808FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C0998: BF870291
	v_exp_f32_e32 v4, v4                                       // 0000002C099C: 7E084B04
	v_add_f32_e32 v4, 1.0, v4                                  // 0000002C09A0: 060808F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C09A4: BF870091
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 0000002C09A8: D6FC7C05 03CA0904
	v_rcp_f32_e32 v7, v5                                       // 0000002C09B0: 7E0E5505
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C09B4: BF870095
	v_fma_f32 v8, -v5, v7, 1.0                                 // 0000002C09B8: D6130008 23CA0F05
	v_fmac_f32_e32 v7, v8, v7                                  // 0000002C09C0: 560E0F08
	v_div_scale_f32 v8, vcc_lo, 1.0, v4, 1.0                   // 0000002C09C4: D6FC6A08 03CA08F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C09CC: BF870091
	v_mul_f32_e32 v9, v8, v7                                   // 0000002C09D0: 10120F08
	v_fma_f32 v10, -v5, v9, v8                                 // 0000002C09D4: D613000A 24221305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C09DC: BF870091
	v_fmac_f32_e32 v9, v10, v7                                 // 0000002C09E0: 56120F0A
	v_fma_f32 v5, -v5, v9, v8                                  // 0000002C09E4: D6130005 24221305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C09EC: BF870091
	v_div_fmas_f32 v5, v5, v7, v9                              // 0000002C09F0: D6370005 04260F05
	v_div_fixup_f32 v5, v5, v4, 1.0                            // 0000002C09F8: D6270005 03CA0905
	v_mad_u64_u32 v[3:4], null, s11, 24, v[3:4]                // 0000002C0A00: D6FE7C03 040D300B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002C0A08: BF870002
	v_add_f32_e32 v4, v5, v5                                   // 0000002C0A0C: 06080B05
	global_store_b32 v[2:3], v4, off                           // 0000002C0A10: DC6A0000 007C0402
	s_mov_b32 s9, 0                                            // 0000002C0A18: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C0A1C: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C0A20: 8B6A097E
	s_cbranch_vccz 58                                          // 0000002C0A24: BFA3003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3110>
	s_cmp_gt_i32 s3, 1                                         // 0000002C0A28: BF028103
	s_mov_b32 s0, -1                                           // 0000002C0A2C: BE8000C1
	s_cbranch_scc0 50                                          // 0000002C0A30: BFA10032 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x30fc>
	v_bfe_u32 v2, v6, 16, 1                                    // 0000002C0A34: D6100002 02052106
	s_mov_b32 s0, 0                                            // 0000002C0A3C: BE800080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0A40: BF870091
	v_add3_u32 v2, v6, v2, 0x7fff                              // 0000002C0A44: D6550002 03FE0506 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000002C0A50: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0A58: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 0000002C0A5C: 100404FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 0000002C0A64: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0A68: BF870095
	v_add_f32_e32 v4, 1.0, v2                                  // 0000002C0A6C: 060804F2
	v_div_scale_f32 v2, null, v4, v4, 1.0                      // 0000002C0A70: D6FC7C02 03CA0904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C0A78: BF870291
	v_rcp_f32_e32 v3, v2                                       // 0000002C0A7C: 7E065502
	v_fma_f32 v5, -v2, v3, 1.0                                 // 0000002C0A80: D6130005 23CA0702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C0A88: BF8700A1
	v_fmac_f32_e32 v3, v5, v3                                  // 0000002C0A8C: 56060705
	v_div_scale_f32 v5, vcc_lo, 1.0, v4, 1.0                   // 0000002C0A90: D6FC6A05 03CA08F2
	v_mul_f32_e32 v7, v5, v3                                   // 0000002C0A98: 100E0705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0A9C: BF870091
	v_fma_f32 v8, -v2, v7, v5                                  // 0000002C0AA0: D6130008 24160F02
	v_fmac_f32_e32 v7, v8, v3                                  // 0000002C0AA8: 560E0708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0AAC: BF870091
	v_fma_f32 v2, -v2, v7, v5                                  // 0000002C0AB0: D6130002 24160F02
	v_div_fmas_f32 v5, v2, v3, v7                              // 0000002C0AB8: D6370005 041E0702
	v_mad_u64_u32 v[2:3], null, s10, 12, v[0:1]                // 0000002C0AC0: D6FE7C02 0401180A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C0AC8: BF870112
	v_div_fixup_f32 v5, v5, v4, 1.0                            // 0000002C0ACC: D6270005 03CA0905
	v_mad_u64_u32 v[3:4], null, s11, 12, v[3:4]                // 0000002C0AD4: D6FE7C03 040D180B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0ADC: BF870092
	v_bfe_u32 v7, v5, 16, 1                                    // 0000002C0AE0: D6100007 02052105
	v_add3_u32 v4, v5, v7, 0x7fff                              // 0000002C0AE8: D6550004 03FE0F05 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 0000002C0AF4: DC960000 007C0402
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000002C0AFC: 916A007E
	s_cbranch_vccnz 3                                          // 0000002C0B00: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3110>
	s_cmp_lg_u32 s3, 1                                         // 0000002C0B04: BF078103
	s_mov_b32 s1, -1                                           // 0000002C0B08: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002C0B0C: 980880C1
	v_bfe_u32 v2, v6, 16, 1                                    // 0000002C0B10: D6100002 02052106
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002C0B18: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C0B1C: BF870001
	v_add3_u32 v2, v6, v2, 0x7fff                              // 0000002C0B20: D6550002 03FE0506 00007FFF
	s_cbranch_vccz 7                                           // 0000002C0B2C: BFA30007 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x314c>
	v_mad_u64_u32 v[3:4], null, s10, 12, v[0:1]                // 0000002C0B30: D6FE7C03 0401180A
	s_mov_b32 s1, 0                                            // 0000002C0B38: BE810080
	v_mad_u64_u32 v[4:5], null, s11, 12, v[4:5]                // 0000002C0B3C: D6FE7C04 0411180B
	global_store_d16_hi_b16 v[3:4], v2, off                    // 0000002C0B44: DC960000 007C0203
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002C0B4C: 916A017E
	s_cbranch_vccnz 45                                         // 0000002C0B50: BFA4002D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3208>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C0B54: BF870121
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000002C0B58: 360404FF FFFF0000
	v_mad_u64_u32 v[0:1], null, s10, 12, v[0:1]                // 0000002C0B60: D6FE7C00 0401180A
	v_mul_f32_e32 v2, s2, v2                                   // 0000002C0B68: 10040402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0B6C: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v2                           // 0000002C0B70: 100604FF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 0000002C0B78: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0B7C: BF870095
	v_add_f32_e32 v3, 1.0, v3                                  // 0000002C0B80: 060606F2
	v_div_scale_f32 v4, null, v3, v3, v2                       // 0000002C0B84: D6FC7C04 040A0703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C0B8C: BF870291
	v_rcp_f32_e32 v5, v4                                       // 0000002C0B90: 7E0A5504
	v_fma_f32 v6, -v4, v5, 1.0                                 // 0000002C0B94: D6130006 23CA0B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C0B9C: BF8700A1
	v_fmac_f32_e32 v5, v6, v5                                  // 0000002C0BA0: 560A0B06
	v_div_scale_f32 v6, vcc_lo, v2, v3, v2                     // 0000002C0BA4: D6FC6A06 040A0702
	v_mul_f32_e32 v7, v6, v5                                   // 0000002C0BAC: 100E0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0BB0: BF870091
	v_fma_f32 v8, -v4, v7, v6                                  // 0000002C0BB4: D6130008 241A0F04
	v_fmac_f32_e32 v7, v8, v5                                  // 0000002C0BBC: 560E0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C0BC0: BF870091
	v_fma_f32 v4, -v4, v7, v6                                  // 0000002C0BC4: D6130004 241A0F04
	v_div_fmas_f32 v4, v4, v5, v7                              // 0000002C0BCC: D6370004 041E0B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C0BD4: BF870121
	v_div_fixup_f32 v3, v4, v3, v2                             // 0000002C0BD8: D6270003 040A0704
	v_mad_u64_u32 v[1:2], null, s11, 12, v[1:2]                // 0000002C0BE0: D6FE7C01 0405180B
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002C0BE8: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C0BF0: BF870001
	v_add3_u32 v2, v3, v4, 0x7fff                              // 0000002C0BF4: D6550002 03FE0903 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002C0C00: DC960000 007C0200
	s_nop 0                                                    // 0000002C0C08: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000002C0C0C: BFB60003
	s_endpgm                                                   // 0000002C0C10: BFB00000
		...

