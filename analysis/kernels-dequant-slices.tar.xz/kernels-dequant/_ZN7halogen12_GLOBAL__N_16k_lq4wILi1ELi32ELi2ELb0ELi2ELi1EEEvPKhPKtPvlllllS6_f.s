00000000007f5d00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007F5D00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000007F5D08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007F5D0C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 0000007F5D10: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 0000007F5D14: 3602008F
	v_lshrrev_b32_e32 v21, 6, v0                               // 0000007F5D18: 322A0086
	v_bfe_u32 v22, v0, 5, 1                                    // 0000007F5D1C: D6100016 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 0000007F5D24: 360404BC
	v_and_b32_e32 v23, 31, v0                                  // 0000007F5D28: 362E009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007F5D2C: 30020282
	.long 0x7f0a3880                                           // 0000007F5D30: 7F0A3880
	s_waitcnt lgkmcnt(0)                                       // 0000007F5D34: BF89FC07
	s_clause 0x1                                               // 0000007F5D38: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 0000007F5D3C: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 0000007F5D44: DC520000 04040002
	s_add_u32 s0, s4, s16                                      // 0000007F5D4C: 80001004
	s_addc_u32 s1, s5, s17                                     // 0000007F5D50: 82011105
	s_ashr_i32 s16, s11, 31                                    // 0000007F5D54: 86109F0B
	v_mov_b32_e32 v2, s3                                       // 0000007F5D58: 7E040203
	s_lshr_b32 s16, s16, 27                                    // 0000007F5D5C: 85109B10
	v_or_b32_e32 v1, s2, v21                                   // 0000007F5D60: 38022A02
	s_add_u32 s16, s10, s16                                    // 0000007F5D64: 8010100A
	s_addc_u32 s17, s11, 0                                     // 0000007F5D68: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F5D6C: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 0000007F5D70: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007F5D74: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 0000007F5D78: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000007F5D7C: BF870499
	s_lshr_b32 s20, s17, 31                                    // 0000007F5D80: 85149F11
	s_add_i32 s17, s17, s20                                    // 0000007F5D84: 81111411
	v_cndmask_b32_e32 v9, 0, v1, vcc_lo                        // 0000007F5D88: 02120280
	s_ashr_i32 s17, s17, 1                                     // 0000007F5D8C: 86118111
	v_cndmask_b32_e64 v10, 0, s3, vcc_lo                       // 0000007F5D90: D501000A 01A80680
	.long 0xd72c0002                                           // 0000007F5D98: D72C0002
	v_cndmask_b32_e32 v1, s17, v22, vcc_lo                     // 0000007F5D9C: 02022C11
	s_cmpk_lt_i32 s16, 0x201                                   // 0000007F5DA0: B3900201
	.long 0xd72c0007                                           // 0000007F5DA4: D72C0007
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 0000007F5DA8: 02021213
	v_mad_u64_u32 v[17:18], null, s18, v9, s[0:1]              // 0000007F5DAC: D6FE7C11 00021212
	s_cselect_b32 s0, -1, 0                                    // 0000007F5DB4: 980080C1
	s_cmpk_gt_i32 s16, 0x200                                   // 0000007F5DB8: B2900200
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000007F5DBC: 30020082
	v_add_nc_u32_e32 v11, s17, v2                              // 0000007F5DC0: 4A160411
	v_add_nc_u32_e32 v24, v2, v23                              // 0000007F5DC4: 4A302F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007F5DC8: BF8704A2
	v_min_i32_e32 v25, s16, v11                                // 0000007F5DCC: 22321610
	s_cselect_b32 s16, -1, 0                                   // 0000007F5DD0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000007F5DD4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007F5DD8: BF870151
	.long 0xd4410001                                           // 0000007F5DDC: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007F5DE0: 02023318
	s_waitcnt vmcnt(1)                                         // 0000007F5DE4: BF8907F7
	v_bfe_u32 v6, v3, 16, 1                                    // 0000007F5DE8: D6100006 02052103
	s_waitcnt vmcnt(0)                                         // 0000007F5DF0: BF8903F7
	v_bfe_u32 v8, v4, 16, 1                                    // 0000007F5DF4: D6100008 02052104
	v_add3_u32 v3, v3, v6, 0x7fff                              // 0000007F5DFC: D6550003 03FE0D03 00007FFF
	.long 0xd72c0006                                           // 0000007F5E08: D72C0006
	v_cndmask_b32_e32 v1, s18, v10, vcc_lo                     // 0000007F5E0C: 02021412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007F5E10: BF870193
	v_add3_u32 v4, v4, v8, 0x7fff                              // 0000007F5E14: D6550004 03FE1104 00007FFF
	.long 0x7e0a3983                                           // 0000007F5E20: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F5E24: BF870113
	v_add3_u32 v26, v7, v18, v6                                // 0000007F5E28: D655001A 041A2507
	v_and_or_b32 v2, 0xffff0000, v4, v5                        // 0000007F5E30: D6570002 041608FF FFFF0000
	ds_store_b32 v1, v2                                        // 0000007F5E3C: D8340000 00000201
	s_waitcnt lgkmcnt(0)                                       // 0000007F5E44: BF89FC07
	s_barrier                                                  // 0000007F5E48: BFBD0000
	buffer_gl0_inv                                             // 0000007F5E4C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000007F5E54: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 0000007F5E58: CA100080 02000080
	s_and_saveexec_b32 s17, s1                                 // 0000007F5E60: BE912001
	s_cbranch_execz 11                                         // 0000007F5E64: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v1, 1, v24                               // 0000007F5E68: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F5E6C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 0000007F5E70: 3408029F
	.long 0xd7006a03                                           // 0000007F5E74: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000007F5E78: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 0000007F5E7C: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 0000007F5E84: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 0000007F5E8C: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000007F5E90: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 0000007F5E94: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v24                               // 0000007F5E98: 4A0630A0
	s_mov_b32 s1, exec_lo                                      // 0000007F5E9C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F5EA0: BF870001
	.long 0xd4c1007e                                           // 0000007F5EA4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 0000007F5EA8: 02023303
	s_cbranch_execz 11                                         // 0000007F5EAC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v2, 1, v3                                // 0000007F5EB0: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F5EB4: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000007F5EB8: 3406049F
	.long 0xd7006a02                                           // 0000007F5EBC: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 0000007F5EC0: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 0000007F5EC4: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 0000007F5ECC: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000007F5ED4: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007F5ED8: 7E041702
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007F5EDC: 8C7E017E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 0000007F5EE0: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 0000007F5EE8: 7E060280
	s_mov_b32 s1, exec_lo                                      // 0000007F5EEC: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F5EF0: BF870002
	.long 0xd4c1007e                                           // 0000007F5EF4: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000007F5EF8: 02023305
	s_cbranch_execz 11                                         // 0000007F5EFC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v5                                // 0000007F5F00: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F5F04: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 0000007F5F08: 340C069F
	.long 0xd7006a05                                           // 0000007F5F0C: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 0000007F5F10: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 0000007F5F14: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 0000007F5F1C: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 0000007F5F24: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000007F5F28: 7E061703
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007F5F2C: 8C7E017E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 0000007F5F30: 4A0A30FF 00000060
	s_mov_b32 s1, exec_lo                                      // 0000007F5F38: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F5F3C: BF870001
	.long 0xd4c1007e                                           // 0000007F5F40: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000007F5F44: 02023305
	s_cbranch_execz 11                                         // 0000007F5F48: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v4, 1, v5                                // 0000007F5F4C: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F5F50: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 0000007F5F54: 340A089F
	.long 0xd7006a04                                           // 0000007F5F58: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 0000007F5F5C: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 0000007F5F60: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 0000007F5F68: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000007F5F70: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000007F5F74: 7E081704
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007F5F78: 8C7E017E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 0000007F5F7C: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 0000007F5F88: 7E0A0280
	s_mov_b32 s1, exec_lo                                      // 0000007F5F8C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F5F90: BF870002
	.long 0xd4c1007e                                           // 0000007F5F94: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000007F5F98: 02023307
	s_cbranch_execz 11                                         // 0000007F5F9C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v5, 1, v7                                // 0000007F5FA0: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F5FA4: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 0000007F5FA8: 34100A9F
	.long 0xd7006a07                                           // 0000007F5FAC: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000007F5FB0: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 0000007F5FB4: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 0000007F5FBC: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000007F5FC4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007F5FC8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007F5FCC: 8C7E017E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 0000007F5FD0: 4A0E30FF 000000A0
	s_mov_b32 s1, exec_lo                                      // 0000007F5FD8: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F5FDC: BF870001
	.long 0xd4c1007e                                           // 0000007F5FE0: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000007F5FE4: 02023307
	s_cbranch_execz 11                                         // 0000007F5FE8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000007F5FEC: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F5FF0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000007F5FF4: 340E0C9F
	.long 0xd7006a06                                           // 0000007F5FF8: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000007F5FFC: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 0000007F6000: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 0000007F6008: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 0000007F6010: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000007F6014: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007F6018: 8C7E017E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0xc0, v24   // 0000007F601C: CA200080 080A30FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 0000007F6028: 7E0E0280
	s_mov_b32 s1, exec_lo                                      // 0000007F602C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F6030: BF870002
	.long 0xd4c1007e                                           // 0000007F6034: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 0000007F6038: 0202330B
	s_cbranch_execz 11                                         // 0000007F603C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v7, 1, v11                               // 0000007F6040: 300E1681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F6044: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v7                              // 0000007F6048: 34180E9F
	.long 0xd7006a0b                                           // 0000007F604C: D7006A0B
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 0000007F6050: 02020F11
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 0000007F6054: D5207C0C 01AA191A
	global_load_d16_b16 v7, v[11:12], off                      // 0000007F605C: DC820000 077C000B
	s_waitcnt vmcnt(0)                                         // 0000007F6064: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000007F6068: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007F606C: 8C7E017E
	v_add_nc_u32_e32 v11, 0xe0, v24                            // 0000007F6070: 4A1630FF 000000E0
	s_mov_b32 s1, exec_lo                                      // 0000007F6078: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F607C: BF870001
	.long 0xd4c1007e                                           // 0000007F6080: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 0000007F6084: 0202330B
	s_cbranch_execz 11                                         // 0000007F6088: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v8, 1, v11                               // 0000007F608C: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F6090: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 0000007F6094: 3418109F
	.long 0xd7006a0b                                           // 0000007F6098: D7006A0B
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 0000007F609C: 02021111
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 0000007F60A0: D5207C0C 01AA191A
	global_load_d16_b16 v8, v[11:12], off                      // 0000007F60A8: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 0000007F60B0: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000007F60B4: 7E101708
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007F60B8: 8C7E017E
	s_branch 9                                                 // 0000007F60BC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v1, 0                                        // 0000007F60C0: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F60C4: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000007F60C8: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000007F60CC: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000007F60D0: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000007F60D4: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000007F60D8: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000007F60DC: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000007F60E0: 7E100301
	s_add_u32 s4, s4, s14                                      // 0000007F60E4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 0000007F60E8: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 0000007F60EC: 85019F0B
	v_mov_b32_e32 v27, 0                                       // 0000007F60F0: 7E360280
	s_add_u32 s10, s10, s1                                     // 0000007F60F4: 800A010A
	s_addc_u32 s11, s11, 0                                     // 0000007F60F8: 820B800B
	.long 0xd4410001                                           // 0000007F60FC: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007F6100: 02023318
	s_ashr_i64 s[10:11], s[10:11], 1                           // 0000007F6104: 868A810A
	v_cndmask_b32_e64 v28, 0, 1, s16                           // 0000007F6108: D501001C 00410280
	v_mad_u64_u32 v[18:19], null, v9, s10, s[4:5]              // 0000007F6110: D6FE7C12 00101509
	.long 0xd72c000c                                           // 0000007F6118: D72C000C
	v_cndmask_b32_e32 v0, v9, v11, vcc_lo                      // 0000007F611C: 02001709
	.long 0xd72c000d                                           // 0000007F6120: D72C000D
	v_cndmask_b32_e32 v0, v10, v10, vcc_lo                     // 0000007F6124: 0200150A
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v30, 0              // 0000007F6128: CA100080 091E0080
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 0000007F6130: CA100080 0A0A0080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F6138: BF870003
	v_add3_u32 v29, v13, v19, v12                              // 0000007F613C: D655001D 0432270D
	v_mov_b32_e32 v12, 0                                       // 0000007F6144: 7E180280
	s_and_saveexec_b32 s4, s1                                  // 0000007F6148: BE842001
	s_cbranch_execz 22                                         // 0000007F614C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_dual_mov_b32 v30, 0 :: v_dual_lshlrev_b32 v9, 4, v24     // 0000007F6150: CA220080 1E083084
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F6158: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000007F615C: 3414129F
	.long 0xd7006a09                                           // 0000007F6160: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 0000007F6164: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 0000007F6168: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 0000007F6170: 916A107E
	global_load_b128 v[9:12], v[9:10], off                     // 0000007F6174: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 0000007F617C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v13, 1, v24                              // 0000007F6180: 301A3081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F6184: BF870091
	.long 0xd7006a0d                                           // 0000007F6188: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 0000007F618C: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v26, vcc_lo              // 0000007F6190: D5207C0E 01AA3480
	global_load_d16_b16 v13, v[13:14], off                     // 0000007F6198: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 0000007F61A0: BF8903F7
	v_cvt_f32_f16_e32 v30, v13                                 // 0000007F61A4: 7E3C170D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007F61A8: 8C7E047E
	s_and_saveexec_b32 s4, s1                                  // 0000007F61AC: BE842001
	s_cbranch_execz 232                                        // 0000007F61B0: BFA500E8 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x854>
	v_add_nc_u32_e32 v13, 32, v24                              // 0000007F61B4: 4A1A30A0
	v_lshlrev_b32_e32 v19, 5, v24                              // 0000007F61B8: 30263085
	v_mov_b32_e32 v27, 0                                       // 0000007F61BC: 7E360280
	v_mov_b32_e32 v33, v30                                     // 0000007F61C0: 7E42031E
	s_mov_b32 s5, 0                                            // 0000007F61C4: BE850080
	v_lshlrev_b32_e32 v31, 4, v13                              // 0000007F61C8: 303E1A84
	v_lshlrev_b32_e32 v32, 1, v13                              // 0000007F61CC: 30401A81
	s_branch 188                                               // 0000007F61D0: BFA000BC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x7c4>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000007F61D4: 8C7E0A7E
	v_ashrrev_i32_e32 v20, 31, v19                             // 0000007F61D8: 3428269F
	v_lshrrev_b32_e32 v50, 6, v9                               // 0000007F61DC: 32641286
	v_lshrrev_b32_e32 v51, 14, v9                              // 0000007F61E0: 3266128E
	v_and_b32_e32 v52, 0xff, v10                               // 0000007F61E4: 366814FF 000000FF
	v_lshrrev_b32_e32 v53, 6, v10                              // 0000007F61EC: 326A1486
	.long 0xd73c0022                                           // 0000007F61F0: D73C0022
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000007F61F4: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 0000007F61F8: 362812FF 000000FF
	v_and_b32_e32 v50, 0x3fc, v50                              // 0000007F6200: 366464FF 000003FC
	v_and_b32_e32 v51, 0x3fc, v51                              // 0000007F6208: 366666FF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000007F6210: 32121296
	v_lshrrev_b32_e32 v54, 14, v10                             // 0000007F6214: 326C148E
	.long 0xd7006a2e                                           // 0000007F6218: D7006A2E
	v_cndmask_b32_e32 v1, s6, v34, vcc_lo                      // 0000007F621C: 02024406
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F6220: BF870001
	v_add_co_ci_u32_e64 v47, null, s7, v35, vcc_lo             // 0000007F6224: D5207C2F 01AA4607
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000007F622C: 30282882
	ds_load_b32 v50, v50                                       // 0000007F6230: D8D80000 32000032
	ds_load_b32 v51, v51                                       // 0000007F6238: D8D80000 33000033
	s_clause 0x3                                               // 0000007F6240: BF850003
	global_load_b128 v[34:37], v[46:47], off                   // 0000007F6244: DC5E0000 227C002E
	global_load_b128 v[38:41], v[46:47], off offset:16         // 0000007F624C: DC5E0010 267C002E
	global_load_b128 v[42:45], v[46:47], off offset:32         // 0000007F6254: DC5E0020 2A7C002E
	global_load_b128 v[46:49], v[46:47], off offset:48         // 0000007F625C: DC5E0030 2E7C002E
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000007F6264: 32141496
	ds_load_b32 v20, v20                                       // 0000007F6268: D8D80000 14000014
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007F6270: 361212FF 000003FC
	v_lshlrev_b32_e32 v52, 2, v52                              // 0000007F6278: 30686882
	v_and_b32_e32 v53, 0x3fc, v53                              // 0000007F627C: 366A6AFF 000003FC
	v_and_b32_e32 v54, 0x3fc, v54                              // 0000007F6284: 366C6CFF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000007F628C: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 0000007F6294: D8D80000 09000009
	ds_load_b32 v52, v52                                       // 0000007F629C: D8D80000 34000034
	ds_load_b32 v53, v53                                       // 0000007F62A4: D8D80000 35000035
	ds_load_b32 v54, v54                                       // 0000007F62AC: D8D80000 36000036
	ds_load_b32 v10, v10                                       // 0000007F62B4: D8D80000 0A00000A
	v_add_nc_u32_e32 v32, 64, v32                              // 0000007F62BC: 4A4040C0
	s_and_b32 s1, exec_lo, s1                                  // 0000007F62C0: 8B01017E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007F62C4: BF870149
	s_or_b32 s5, s1, s5                                        // 0000007F62C8: 8C050501
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 0000007F62CC: BF890C57
	v_dot2_f32_bf16 v20, v34, v20, 0                           // 0000007F62D0: CC1A4014 1A022922
	v_and_b32_e32 v34, 0xff, v11                               // 0000007F62D8: 364416FF 000000FF
	v_dot2_f32_bf16 v20, v35, v50, v20                         // 0000007F62E0: CC1A4014 1C526523
	v_lshrrev_b32_e32 v35, 6, v11                              // 0000007F62E8: 32461686
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007F62EC: BF8701A2
	v_dot2_f32_bf16 v20, v36, v51, v20                         // 0000007F62F0: CC1A4014 1C526724
	v_lshrrev_b32_e32 v36, 14, v11                             // 0000007F62F8: 3248168E
	v_and_b32_e32 v35, 0x3fc, v35                              // 0000007F62FC: 364646FF 000003FC
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000007F6304: 32161696
	s_waitcnt lgkmcnt(4)                                       // 0000007F6308: BF89FC47
	v_dot2_f32_bf16 v9, v37, v9, v20                           // 0000007F630C: CC1A4009 1C521325
	v_and_b32_e32 v36, 0x3fc, v36                              // 0000007F6314: 364848FF 000003FC
	v_lshrrev_b32_e32 v37, 6, v12                              // 0000007F631C: 324A1886
	ds_load_b32 v35, v35                                       // 0000007F6320: D8D80000 23000023
	s_waitcnt vmcnt(2) lgkmcnt(4)                              // 0000007F6328: BF890847
	v_dot2_f32_bf16 v9, v38, v52, v9                           // 0000007F632C: CC1A4009 1C266926
	ds_load_b32 v36, v36                                       // 0000007F6334: D8D80000 24000024
	v_lshrrev_b32_e32 v38, 14, v12                             // 0000007F633C: 324C188E
	v_and_b32_e32 v37, 0x3fc, v37                              // 0000007F6340: 364A4AFF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000007F6348: BF89FC47
	v_dot2_f32_bf16 v9, v39, v53, v9                           // 0000007F634C: CC1A4009 1C266B27
	v_cndmask_b32_e64 v39, v6, v7, s0                          // 0000007F6354: D5010027 00020F06
	v_and_b32_e32 v38, 0x3fc, v38                              // 0000007F635C: 364C4CFF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000007F6364: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007F6368: BF870133
	v_dot2_f32_bf16 v9, v40, v54, v9                           // 0000007F636C: CC1A4009 1C266D28
	v_cndmask_b32_e64 v40, v7, v8, s0                          // 0000007F6374: D5010028 00021107
	s_waitcnt lgkmcnt(2)                                       // 0000007F637C: BF89FC27
	v_dot2_f32_bf16 v9, v41, v10, v9                           // 0000007F6380: CC1A4009 1C261529
	v_dual_mov_b32 v41, v8 :: v_dual_lshlrev_b32 v20, 2, v34   // 0000007F6388: CA220108 29144482
	v_and_b32_e32 v34, 0xff, v12                               // 0000007F6390: 364418FF 000000FF
	v_lshrrev_b32_e32 v12, 22, v12                             // 0000007F6398: 32181896
	ds_load_b32 v20, v20                                       // 0000007F639C: D8D80000 14000014
	v_lshlrev_b32_e32 v34, 2, v34                              // 0000007F63A4: 30444482
	v_and_b32_e32 v12, 0x3fc, v12                              // 0000007F63A8: 361818FF 000003FC
	s_waitcnt vmcnt(1) lgkmcnt(0)                              // 0000007F63B0: BF890407
	v_dot2_f32_bf16 v9, v42, v20, v9                           // 0000007F63B4: CC1A4009 1C26292A
	v_cndmask_b32_e64 v20, v30, v1, s0                         // 0000007F63BC: D5010014 0002031E
	v_mov_b32_e32 v30, v33                                     // 0000007F63C4: 7E3C0321
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007F63C8: BF870123
	v_dot2_f32_bf16 v9, v43, v35, v9                           // 0000007F63CC: CC1A4009 1C26472B
	v_cndmask_b32_e64 v35, v2, v3, s0                          // 0000007F63D4: D5010023 00020702
	v_dot2_f32_bf16 v9, v44, v36, v9                           // 0000007F63DC: CC1A4009 1C26492C
	v_cndmask_b32_e64 v36, v3, v4, s0                          // 0000007F63E4: D5010024 00020903
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007F63EC: 361616FF 000003FC
	ds_load_b32 v10, v11                                       // 0000007F63F4: D8D80000 0A00000B
	ds_load_b32 v11, v34                                       // 0000007F63FC: D8D80000 0B000022
	ds_load_b32 v34, v37                                       // 0000007F6404: D8D80000 22000025
	ds_load_b32 v50, v38                                       // 0000007F640C: D8D80000 32000026
	ds_load_b32 v51, v12                                       // 0000007F6414: D8D80000 3300000C
	v_cndmask_b32_e64 v38, v5, v6, s0                          // 0000007F641C: D5010026 00020D05
	v_cndmask_b32_e64 v37, v4, v5, s0                          // 0000007F6424: D5010025 00020B04
	v_mov_b32_e32 v12, v16                                     // 0000007F642C: 7E180310
	s_waitcnt lgkmcnt(4)                                       // 0000007F6430: BF89FC47
	v_dot2_f32_bf16 v9, v45, v10, v9                           // 0000007F6434: CC1A4009 1C26152D
	v_mov_b32_e32 v10, v14                                     // 0000007F643C: 7E14030E
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007F6440: BF890037
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007F6444: BF870132
	v_dot2_f32_bf16 v9, v46, v11, v9                           // 0000007F6448: CC1A4009 1C26172E
	v_mov_b32_e32 v11, v15                                     // 0000007F6450: 7E16030F
	s_waitcnt lgkmcnt(2)                                       // 0000007F6454: BF89FC27
	v_dot2_f32_bf16 v5, v47, v34, v9                           // 0000007F6458: CC1A4005 1C26452F
	v_cndmask_b32_e64 v34, v1, v2, s0                          // 0000007F6460: D5010022 00020501
	v_add_nc_u32_e32 v31, 0x200, v31                           // 0000007F6468: 4A3E3EFF 00000200
	v_mov_b32_e32 v9, v13                                      // 0000007F6470: 7E12030D
	v_add_nc_u32_e32 v19, 0x400, v19                           // 0000007F6474: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 0000007F647C: BF89FC17
	v_dot2_f32_bf16 v1, v48, v50, v5                           // 0000007F6480: CC1A4001 1C166530
	s_waitcnt lgkmcnt(0)                                       // 0000007F6488: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F648C: BF870091
	v_dot2_f32_bf16 v1, v49, v51, v1                           // 0000007F6490: CC1A4001 1C066731
	v_fmac_f32_e32 v27, v20, v1                                // 0000007F6498: 56360314
	v_dual_mov_b32 v1, v34 :: v_dual_mov_b32 v2, v35           // 0000007F649C: CA100122 01020123
	v_dual_mov_b32 v3, v36 :: v_dual_mov_b32 v4, v37           // 0000007F64A4: CA100124 03040125
	v_dual_mov_b32 v5, v38 :: v_dual_mov_b32 v6, v39           // 0000007F64AC: CA100126 05060127
	v_dual_mov_b32 v7, v40 :: v_dual_mov_b32 v8, v41           // 0000007F64B4: CA100128 07080129
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000007F64BC: 917E057E
	s_cbranch_execz 35                                         // 0000007F64C0: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x850>
	s_waitcnt vmcnt(0)                                         // 0000007F64C4: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v24, 32, v24   // 0000007F64C8: CA200109 0D1830A0
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 0000007F64D0: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 0000007F64D8: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F64DC: BF870003
	.long 0xd4460001                                           // 0000007F64E0: D4460001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007F64E4: 02023318
	s_mov_b32 s10, exec_lo                                     // 0000007F64E8: BE8A007E
	.long 0xd4c1007e                                           // 0000007F64EC: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007F64F0: 02023318
	s_cbranch_execz 65335                                      // 0000007F64F4: BFA5FF37 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4d4>
	v_ashrrev_i32_e32 v14, 31, v31                             // 0000007F64F8: 341C3E9F
	.long 0xd7006a0d                                           // 0000007F64FC: D7006A0D
	v_cndmask_b32_e32 v1, v18, v31, vcc_lo                     // 0000007F6500: 02023F12
	v_mov_b32_e32 v33, v30                                     // 0000007F6504: 7E42031E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F6508: BF870003
	v_add_co_ci_u32_e64 v14, null, v29, v14, vcc_lo            // 0000007F650C: D5207C0E 01AA1D1D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 0000007F6514: 7C9A3881
	global_load_b128 v[13:16], v[13:14], off                   // 0000007F6518: DC5E0000 0D7C000D
	s_cbranch_vccnz 65324                                      // 0000007F6520: BFA4FF2C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4d4>
	v_ashrrev_i32_e32 v20, 31, v32                             // 0000007F6524: 3428409F
	.long 0xd7006a21                                           // 0000007F6528: D7006A21
	v_cndmask_b32_e32 v1, v17, v32, vcc_lo                     // 0000007F652C: 02024111
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F6530: BF870001
	v_add_co_ci_u32_e64 v34, null, v26, v20, vcc_lo            // 0000007F6534: D5207C22 01AA291A
	global_load_d16_b16 v20, v[33:34], off                     // 0000007F653C: DC820000 147C0021
	s_waitcnt vmcnt(0)                                         // 0000007F6544: BF8903F7
	v_cvt_f32_f16_e32 v33, v20                                 // 0000007F6548: 7E421714
	s_branch 65313                                             // 0000007F654C: BFA0FF21 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4d4>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007F6550: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007F6554: BF8700B9
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007F6558: 8C7E047E
	.long 0xd71f0001                                           // 0000007F655C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007F6560: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000007F6564: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007F6568: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 0000007F656C: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 0000007F6570: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007F6574: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007F6578: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007F657C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007F6580: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 0000007F6584: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007F6588: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F658C: BF870002
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000007F6590: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007F6594: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000007F6598: 02080901
	ds_bpermute_b32 v2, v2, v27                                // 0000007F659C: DACC0000 02001B02
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007F65A4: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000007F65A8: BF89FC07
	v_add_f32_e32 v2, v27, v2                                  // 0000007F65AC: 0604051B
	ds_bpermute_b32 v3, v3, v2                                 // 0000007F65B0: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 0000007F65B8: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000007F65BC: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000007F65C0: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 0000007F65C8: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F65CC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007F65D0: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000007F65D4: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007F65D8: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000007F65DC: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000007F65E0: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000007F65E4: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 0000007F65EC: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007F65F0: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007F65F4: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 0000007F65F8: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 0000007F65FC: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 0000007F6604: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 0000007F6608: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v23                                   // 0000007F6610: 7D942E80
	s_cbranch_execz 8                                          // 0000007F6614: BFA50008 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x938>
	v_lshlrev_b32_e32 v3, 2, v22                               // 0000007F6618: 30062C82
	s_waitcnt lgkmcnt(0)                                       // 0000007F661C: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000007F6620: 06020501
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F6624: BF870002
	v_lshl_or_b32 v3, v21, 3, v3                               // 0000007F6628: D6560003 040D0715
	ds_store_b32 v3, v1 offset:1024                            // 0000007F6630: D8340400 00000103
	s_or_b32 exec_lo, exec_lo, s0                              // 0000007F6638: 8C7E007E
	v_or_b32_e32 v1, s2, v0                                    // 0000007F663C: 38020002
	s_waitcnt lgkmcnt(0)                                       // 0000007F6640: BF89FC07
	v_mov_b32_e32 v2, s3                                       // 0000007F6644: 7E040203
	.long 0xd44c0000                                           // 0000007F6648: D44C0000
	v_cndmask_b32_e32 v1, 4, v0, vcc_lo                        // 0000007F664C: 02020084
	s_waitcnt vmcnt(0)                                         // 0000007F6650: BF8903F7
	s_barrier                                                  // 0000007F6654: BFBD0000
	buffer_gl0_inv                                             // 0000007F6658: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007F6660: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 0000007F6664: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007F6668: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000007F666C: BE812000
	s_cbranch_execz 59                                         // 0000007F6670: BFA5003B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xa60>
	v_lshlrev_b32_e32 v0, 3, v0                                // 0000007F6674: 30000083
	ds_load_b64 v[3:4], v0 offset:1024                         // 0000007F6678: D9D80400 03000000
	s_waitcnt lgkmcnt(0)                                       // 0000007F6680: BF89FC07
	v_add_f32_e32 v0, 0, v3                                    // 0000007F6684: 06000680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F6688: BF870091
	v_add_f32_e32 v0, v0, v4                                   // 0000007F668C: 06000900
	v_bfe_u32 v3, v0, 16, 1                                    // 0000007F6690: D6100003 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F6698: BF870091
	v_add3_u32 v0, v0, v3, 0x7fff                              // 0000007F669C: D6550000 03FE0700 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007F66A8: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F66B0: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000007F66B4: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000007F66BC: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F66C0: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 0000007F66C4: 060000F2
	v_div_scale_f32 v3, null, v0, v0, 1.0                      // 0000007F66C8: D6FC7C03 03CA0100
	v_div_scale_f32 v6, vcc_lo, 1.0, v0, 1.0                   // 0000007F66D0: D6FC6A06 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007F66D8: BF870292
	v_rcp_f32_e32 v4, v3                                       // 0000007F66DC: 7E085503
	v_fma_f32 v5, -v3, v4, 1.0                                 // 0000007F66E0: D6130005 23CA0903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F66E8: BF870091
	v_fmac_f32_e32 v4, v5, v4                                  // 0000007F66EC: 56080905
	v_mul_f32_e32 v5, v6, v4                                   // 0000007F66F0: 100A0906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F66F4: BF870091
	v_fma_f32 v7, -v3, v5, v6                                  // 0000007F66F8: D6130007 241A0B03
	v_fmac_f32_e32 v5, v7, v4                                  // 0000007F6700: 560A0907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F6704: BF870091
	v_fma_f32 v3, -v3, v5, v6                                  // 0000007F6708: D6130003 241A0B03
	v_div_fmas_f32 v3, v3, v4, v5                              // 0000007F6710: D6370003 04160903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007F6718: BF870121
	v_div_fixup_f32 v3, v3, v0, 1.0                            // 0000007F671C: D6270003 03CA0103
	.long 0xd73c0000                                           // 0000007F6724: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000007F6728: 02020281
	v_bfe_u32 v4, v3, 16, 1                                    // 0000007F672C: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F6734: BF870092
	.long 0xd7006a00                                           // 0000007F6738: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007F673C: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007F6740: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F6748: BF870003
	v_add3_u32 v2, v3, v4, 0x7fff                              // 0000007F674C: D6550002 03FE0903 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007F6758: DC960000 007C0200
	s_endpgm                                                   // 0000007F6760: BFB00000
		...

