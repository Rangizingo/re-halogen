00000000009af800 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi():
	s_load_b256 s[4:11], s[0:1], null                          // 0000009AF800: F40C0100 F8000000
	s_mul_hi_i32 s3, s2, 0x66666667                            // 0000009AF808: 9703FF02 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000009AF810: BF8704A9
	s_lshr_b32 s12, s3, 31                                     // 0000009AF814: 850C9F03
	s_ashr_i32 s3, s3, 1                                       // 0000009AF818: 86038103
	s_add_i32 s16, s3, s12                                     // 0000009AF81C: 81100C03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009AF820: BF870499
	s_ashr_i32 s17, s16, 31                                    // 0000009AF824: 86119F10
	s_lshl_b64 s[12:13], s[16:17], 2                           // 0000009AF828: 848C8210
	s_waitcnt lgkmcnt(0)                                       // 0000009AF82C: BF89FC07
	s_add_u32 s8, s8, s12                                      // 0000009AF830: 80080C08
	s_addc_u32 s9, s9, s13                                     // 0000009AF834: 82090D09
	s_load_b128 s[12:15], s[0:1], 0x20                         // 0000009AF838: F4080300 F8000020
	s_load_b32 s8, s[8:9], null                                // 0000009AF840: F4000204 F8000000
	s_mov_b32 s1, exec_lo                                      // 0000009AF848: BE81007E
	v_cmpx_gt_u32_e32 0x140, v0                                // 0000009AF84C: 7D9800FF 00000140
	s_cbranch_execz 46                                         // 0000009AF854: BFA5002E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x110>
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 0000009AF858: 9700FF02 51EB851F
	v_lshlrev_b32_e32 v4, 4, v0                                // 0000009AF860: 30080084
	s_lshr_b32 s3, s0, 31                                      // 0000009AF864: 85039F00
	s_ashr_i32 s0, s0, 4                                       // 0000009AF868: 86008400
	v_or_b32_e32 v3, 0xffffff00, v0                            // 0000009AF86C: 380600FF FFFFFF00
	s_add_i32 s0, s0, s3                                       // 0000009AF874: 81000300
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000009AF878: BF8700D9
	s_mul_i32 s3, s0, 0x1400                                   // 0000009AF87C: 9603FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 0000009AF884: 9700FF00 00001400
	s_add_u32 s3, s6, s3                                       // 0000009AF88C: 80030306
	s_addc_u32 s0, s7, s0                                      // 0000009AF890: 82000007
	.long 0xd7000301                                           // 0000009AF894: D7000301
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 0000009AF898: 02020803
	v_add_co_ci_u32_e64 v2, null, s0, 0, s3                    // 0000009AF89C: D5207C02 000D0000
	s_mov_b32 s3, 0                                            // 0000009AF8A4: BE830080
	s_nop 0                                                    // 0000009AF8A8: BF800000
	s_nop 0                                                    // 0000009AF8AC: BF800000
	s_nop 0                                                    // 0000009AF8B0: BF800000
	s_nop 0                                                    // 0000009AF8B4: BF800000
	s_nop 0                                                    // 0000009AF8B8: BF800000
	s_nop 0                                                    // 0000009AF8BC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 0000009AF8C0: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x100, v3                             // 0000009AF8C8: 4A0606FF 00000100
	.long 0xd7006a01                                           // 0000009AF8D0: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 0000009AF8D4: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009AF8DC: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000009AF8E0: D5207C02 01AA0480
	.long 0xd4490000                                           // 0000009AF8E8: D4490000
	v_cndmask_b32_e32 v1, 63, v3, vcc_lo                       // 0000009AF8EC: 020206BF
	s_or_b32 s3, s0, s3                                        // 0000009AF8F0: 8C030300
	s_waitcnt vmcnt(0)                                         // 0000009AF8F4: BF8903F7
	ds_store_b128 v4, v[5:8]                                   // 0000009AF8F8: DB7C0000 00000504
	v_add_nc_u32_e32 v4, 0x1000, v4                            // 0000009AF900: 4A0808FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 0000009AF908: 917E037E
	s_cbranch_execnz 65516                                     // 0000009AF90C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xc0>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009AF910: 8C7E017E
	v_and_b32_e32 v72, 31, v0                                  // 0000009AF914: 3690009F
	v_lshrrev_b32_e32 v71, 5, v0                               // 0000009AF918: 328E0085
	s_mul_i32 s6, s16, -5                                      // 0000009AF91C: 9606C510
	s_waitcnt lgkmcnt(0)                                       // 0000009AF920: BF89FC07
	s_mul_i32 s1, s8, 0x12c000                                 // 0000009AF924: 9601FF08 0012C000
	s_mul_hi_i32 s0, s8, 0x12c000                              // 0000009AF92C: 9700FF08 0012C000
	v_mad_u32_u24 v88, v72, 24, 0x2f0                          // 0000009AF934: D60B0058 03FD3148 000002F0
	v_mul_u32_u24_e32 v25, 20, v71                             // 0000009AF940: 16328E94
	v_cmp_eq_u32_e32 vcc_lo, 0, v72                            // 0000009AF944: 7C949080
	s_add_i32 s6, s6, s2                                       // 0000009AF948: 81060206
	s_add_u32 s1, s4, s1                                       // 0000009AF94C: 80010104
	v_lshrrev_b32_e32 v1, 5, v88                               // 0000009AF950: 3202B085
	v_min_u32_e32 v26, 0x8c, v25                               // 0000009AF954: 263432FF 0000008C
	s_addc_u32 s3, s5, s0                                      // 0000009AF95C: 82030005
	s_mul_i32 s2, s6, 0x3c000                                  // 0000009AF960: 9602FF06 0003C000
	v_add_nc_u32_e32 v89, 8, v88                               // 0000009AF968: 4AB2B088
	v_subrev_nc_u32_e32 v1, 24, v1                             // 0000009AF96C: 4E020298
	v_add_nc_u32_e32 v73, 20, v26                              // 0000009AF970: 4A923494
	s_mul_hi_i32 s4, s6, 0x3c000                               // 0000009AF974: 9704FF06 0003C000
	s_add_u32 s2, s1, s2                                       // 0000009AF97C: 80020201
	s_addc_u32 s3, s3, s4                                      // 0000009AF980: 82030403
	v_cndmask_b32_e64 v15, v1, 23, vcc_lo                      // 0000009AF984: D501000F 01A92F01
	.long 0xd4490000                                           // 0000009AF98C: D4490000
	v_cndmask_b32_e32 v1, v25, v73, vcc_lo                     // 0000009AF990: 02029319
	s_barrier                                                  // 0000009AF994: BFBD0000
	buffer_gl0_inv                                             // 0000009AF998: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000009AF9A0: BE842000
	s_cbranch_execz 190                                        // 0000009AF9A4: BFA500BE <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4a0>
	v_lshrrev_b32_e32 v1, 5, v89                               // 0000009AF9A8: 3202B285
	.long 0xd4440001                                           // 0000009AF9AC: D4440001
	v_cndmask_b32_e32 v1, 23, v15, vcc_lo                      // 0000009AF9B0: 02021E97
	v_mul_u32_u24_e32 v6, 0x7800, v71                          // 0000009AF9B4: 160C8EFF 00007800
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009AF9BC: BF870193
	v_subrev_nc_u32_e32 v1, 24, v1                             // 0000009AF9C0: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s1                          // 0000009AF9C4: D5010002 000502FF 000000E9
	v_mov_b32_e32 v16, 0                                       // 0000009AF9D0: 7E200280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009AF9D4: BF870193
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 0000009AF9D8: D5010001 01A92F01
	v_add_nc_u32_e32 v5, v2, v15                               // 0000009AF9E0: 4A0A1F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009AF9E4: BF870223
	.long 0xd73c0003                                           // 0000009AF9E8: D73C0003
	v_cndmask_b32_e32 v1, 2, v15, vcc_lo                       // 0000009AF9EC: 02021E82
	v_mov_b32_e32 v2, v16                                      // 0000009AF9F0: 7E040310
	.long 0xd4440001                                           // 0000009AF9F4: D4440001
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 0000009AF9F8: 02020297
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009AF9FC: BF8701A4
	v_lshlrev_b32_e32 v7, 24, v5                               // 0000009AFA00: 300E0A98
	v_bfe_i32 v9, v5, 7, 1                                     // 0000009AFA04: D6110009 02050F05
	v_cndmask_b32_e64 v8, 0xe9, 1, s1                          // 0000009AFA0C: D5010008 000502FF 000000E9
	.long 0xd700010b                                           // 0000009AFA18: D700010B
	v_cndmask_b32_e32 v1, s2, v6, vcc_lo                       // 0000009AFA1C: 02020C02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009AFA20: BF870191
	v_add_co_ci_u32_e64 v12, null, s3, 0, s1                   // 0000009AFA24: D5207C0C 00050003
	v_add_nc_u32_e32 v10, v8, v1                               // 0000009AFA2C: 4A140308
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009AFA30: BF870233
	.long 0xd7000105                                           // 0000009AFA34: D7000105
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 0000009AFA38: 0202070B
	v_ashrrev_i32_e32 v7, 22, v7                               // 0000009AFA3C: 340E0E96
	.long 0xd73c0001                                           // 0000009AFA40: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000009AFA44: 02020282
	v_lshlrev_b32_e32 v3, 24, v10                              // 0000009AFA48: 30061498
	v_add_co_ci_u32_e64 v6, null, v12, v4, s1                  // 0000009AFA4C: D5207C06 0006090C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009AFA54: BF870194
	.long 0xd7000107                                           // 0000009AFA58: D7000107
	v_cndmask_b32_e32 v1, v11, v7, vcc_lo                      // 0000009AFA5C: 02020F0B
	v_ashrrev_i32_e32 v3, 22, v3                               // 0000009AFA60: 34060696
	v_bfe_i32 v4, v10, 7, 1                                    // 0000009AFA64: D6110004 02050F0A
	v_add_co_ci_u32_e64 v8, null, v12, v9, s1                  // 0000009AFA6C: D5207C08 0006130C
	.long 0xd7000109                                           // 0000009AFA74: D7000109
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000009AFA78: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009AFA7C: BF8700A1
	v_add_co_ci_u32_e64 v10, null, v12, v2, s1                 // 0000009AFA80: D5207C0A 0006050C
	.long 0xd700014a                                           // 0000009AFA88: D700014A
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 0000009AFA8C: 0202070B
	v_add_co_ci_u32_e64 v75, null, v12, v4, s1                 // 0000009AFA90: D5207C4B 0006090C
	s_clause 0x1f                                              // 0000009AFA98: BF85001F
	global_load_b32 v2, v[5:6], off                            // 0000009AFA9C: DC520000 027C0005
	global_load_b32 v68, v[5:6], off offset:96                 // 0000009AFAA4: DC520060 447C0005
	global_load_b32 v64, v[5:6], off offset:192                // 0000009AFAAC: DC5200C0 407C0005
	global_load_b32 v60, v[5:6], off offset:288                // 0000009AFAB4: DC520120 3C7C0005
	global_load_b32 v56, v[5:6], off offset:384                // 0000009AFABC: DC520180 387C0005
	global_load_b32 v52, v[5:6], off offset:480                // 0000009AFAC4: DC5201E0 347C0005
	global_load_b32 v48, v[5:6], off offset:576                // 0000009AFACC: DC520240 307C0005
	global_load_b32 v44, v[5:6], off offset:672                // 0000009AFAD4: DC5202A0 2C7C0005
	global_load_b32 v1, v[7:8], off                            // 0000009AFADC: DC520000 017C0007
	global_load_b32 v67, v[7:8], off offset:96                 // 0000009AFAE4: DC520060 437C0007
	global_load_b32 v63, v[7:8], off offset:192                // 0000009AFAEC: DC5200C0 3F7C0007
	global_load_b32 v59, v[7:8], off offset:288                // 0000009AFAF4: DC520120 3B7C0007
	global_load_b32 v55, v[7:8], off offset:384                // 0000009AFAFC: DC520180 377C0007
	global_load_b32 v51, v[7:8], off offset:480                // 0000009AFB04: DC5201E0 337C0007
	global_load_b32 v47, v[7:8], off offset:576                // 0000009AFB0C: DC520240 2F7C0007
	global_load_b32 v43, v[7:8], off offset:672                // 0000009AFB14: DC5202A0 2B7C0007
	global_load_b32 v4, v[9:10], off                           // 0000009AFB1C: DC520000 047C0009
	global_load_b32 v70, v[9:10], off offset:96                // 0000009AFB24: DC520060 467C0009
	global_load_b32 v66, v[9:10], off offset:192               // 0000009AFB2C: DC5200C0 427C0009
	global_load_b32 v62, v[9:10], off offset:288               // 0000009AFB34: DC520120 3E7C0009
	global_load_b32 v58, v[9:10], off offset:384               // 0000009AFB3C: DC520180 3A7C0009
	global_load_b32 v54, v[9:10], off offset:480               // 0000009AFB44: DC5201E0 367C0009
	global_load_b32 v50, v[9:10], off offset:576               // 0000009AFB4C: DC520240 327C0009
	global_load_b32 v46, v[9:10], off offset:672               // 0000009AFB54: DC5202A0 2E7C0009
	global_load_b32 v3, v[74:75], off                          // 0000009AFB5C: DC520000 037C004A
	global_load_b32 v69, v[74:75], off offset:96               // 0000009AFB64: DC520060 457C004A
	global_load_b32 v65, v[74:75], off offset:192              // 0000009AFB6C: DC5200C0 417C004A
	global_load_b32 v61, v[74:75], off offset:288              // 0000009AFB74: DC520120 3D7C004A
	global_load_b32 v57, v[74:75], off offset:384              // 0000009AFB7C: DC520180 397C004A
	global_load_b32 v53, v[74:75], off offset:480              // 0000009AFB84: DC5201E0 357C004A
	global_load_b32 v49, v[74:75], off offset:576              // 0000009AFB8C: DC520240 317C004A
	global_load_b32 v45, v[74:75], off offset:672              // 0000009AFB94: DC5202A0 2D7C004A
	s_clause 0x1f                                              // 0000009AFB9C: BF85001F
	global_load_b32 v40, v[5:6], off offset:768                // 0000009AFBA0: DC520300 287C0005
	global_load_b32 v36, v[5:6], off offset:864                // 0000009AFBA8: DC520360 247C0005
	global_load_b32 v32, v[5:6], off offset:960                // 0000009AFBB0: DC5203C0 207C0005
	global_load_b32 v28, v[5:6], off offset:1056               // 0000009AFBB8: DC520420 1C7C0005
	global_load_b32 v22, v[5:6], off offset:1152               // 0000009AFBC0: DC520480 167C0005
	global_load_b32 v18, v[5:6], off offset:1248               // 0000009AFBC8: DC5204E0 127C0005
	global_load_b32 v12, v[5:6], off offset:1344               // 0000009AFBD0: DC520540 0C7C0005
	global_load_b32 v6, v[5:6], off offset:1440                // 0000009AFBD8: DC5205A0 067C0005
	global_load_b32 v39, v[7:8], off offset:768                // 0000009AFBE0: DC520300 277C0007
	global_load_b32 v35, v[7:8], off offset:864                // 0000009AFBE8: DC520360 237C0007
	global_load_b32 v31, v[7:8], off offset:960                // 0000009AFBF0: DC5203C0 1F7C0007
	global_load_b32 v27, v[7:8], off offset:1056               // 0000009AFBF8: DC520420 1B7C0007
	global_load_b32 v21, v[7:8], off offset:1152               // 0000009AFC00: DC520480 157C0007
	global_load_b32 v17, v[7:8], off offset:1248               // 0000009AFC08: DC5204E0 117C0007
	global_load_b32 v11, v[7:8], off offset:1344               // 0000009AFC10: DC520540 0B7C0007
	global_load_b32 v5, v[7:8], off offset:1440                // 0000009AFC18: DC5205A0 057C0007
	global_load_b32 v42, v[9:10], off offset:768               // 0000009AFC20: DC520300 2A7C0009
	global_load_b32 v38, v[9:10], off offset:864               // 0000009AFC28: DC520360 267C0009
	global_load_b32 v34, v[9:10], off offset:960               // 0000009AFC30: DC5203C0 227C0009
	global_load_b32 v30, v[9:10], off offset:1056              // 0000009AFC38: DC520420 1E7C0009
	global_load_b32 v24, v[9:10], off offset:1152              // 0000009AFC40: DC520480 187C0009
	global_load_b32 v20, v[9:10], off offset:1248              // 0000009AFC48: DC5204E0 147C0009
	global_load_b32 v14, v[9:10], off offset:1344              // 0000009AFC50: DC520540 0E7C0009
	global_load_b32 v8, v[9:10], off offset:1440               // 0000009AFC58: DC5205A0 087C0009
	global_load_b32 v41, v[74:75], off offset:768              // 0000009AFC60: DC520300 297C004A
	global_load_b32 v37, v[74:75], off offset:864              // 0000009AFC68: DC520360 257C004A
	global_load_b32 v33, v[74:75], off offset:960              // 0000009AFC70: DC5203C0 217C004A
	global_load_b32 v29, v[74:75], off offset:1056             // 0000009AFC78: DC520420 1D7C004A
	global_load_b32 v23, v[74:75], off offset:1152             // 0000009AFC80: DC520480 177C004A
	global_load_b32 v19, v[74:75], off offset:1248             // 0000009AFC88: DC5204E0 137C004A
	global_load_b32 v13, v[74:75], off offset:1344             // 0000009AFC90: DC520540 0D7C004A
	global_load_b32 v7, v[74:75], off offset:1440              // 0000009AFC98: DC5205A0 077C004A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000009AFCA0: 8C7E047E
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v75, 0             // 0000009AFCA4: CA100080 0A4A0080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v77, 0             // 0000009AFCAC: CA100080 4A4C0080
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v79, 0             // 0000009AFCB4: CA100080 4C4E0080
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v81, 0             // 0000009AFCBC: CA100080 4E500080
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v83, 0             // 0000009AFCC4: CA100080 50520080
	v_dual_mov_b32 v82, 0 :: v_dual_mov_b32 v85, 0             // 0000009AFCCC: CA100080 52540080
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v87, 0             // 0000009AFCD4: CA100080 54560080
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v9, 0              // 0000009AFCDC: CA100080 56080080
	s_and_saveexec_b32 s1, s0                                  // 0000009AFCE4: BE812000
	s_cbranch_execz 2083                                       // 0000009AFCE8: BFA50823 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2578>
	v_lshrrev_b32_e32 v9, 5, v89                               // 0000009AFCEC: 3212B285
	v_mul_i32_i24_e32 v74, 0xffffffe8, v72                     // 0000009AFCF0: 129490FF FFFFFFE8
	v_dual_mov_b32 v10, 0 :: v_dual_and_b32 v75, 0x7e0, v88    // 0000009AFCF8: CA240080 0A4AB0FF 000007E0
	v_and_b32_e32 v78, 16, v0                                  // 0000009AFD04: 369C0090
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009AFD08: BF870004
	v_subrev_nc_u32_e32 v9, 24, v9                             // 0000009AFD0C: 4E121298
	v_sub_nc_u32_e32 v89, 0, v26                               // 0000009AFD10: 4CB23480
	v_add_nc_u32_e32 v88, 1, v25                               // 0000009AFD14: 4AB03281
	v_add3_u32 v90, v74, v75, 0xfffffd34                       // 0000009AFD18: D655005A 03FE974A FFFFFD34
	v_mov_b32_e32 v75, v10                                     // 0000009AFD24: 7E96030A
	v_cndmask_b32_e64 v9, v9, 23, vcc_lo                       // 0000009AFD28: D5010009 01A92F09
	v_lshl_or_b32 v91, v25, 5, v78                             // 0000009AFD30: D656005B 05390B19
	.long 0xd4440000                                           // 0000009AFD38: D4440000
	v_cndmask_b32_e32 v1, 23, v15, vcc_lo                      // 0000009AFD3C: 02021E97
	v_lshl_or_b32 v76, v72, 3, 4                               // 0000009AFD40: D656004C 02110748
	v_ashrrev_i32_e32 v16, 31, v15                             // 0000009AFD48: 34201E9F
	.long 0xd703001a                                           // 0000009AFD4C: D703001A
	v_cndmask_b32_e32 v0, v9, v129, vcc_lo                     // 0000009AFD50: 02010309
	v_mov_b32_e32 v79, v10                                     // 0000009AFD54: 7E9E030A
	v_cndmask_b32_e64 v77, 0xe9, 1, s0                         // 0000009AFD58: D501004D 000102FF 000000E9
	v_mad_u32_u24 v83, v76, 3, 0x2f0                           // 0000009AFD64: D60B0053 03FD074C 000002F0
	v_mul_i32_i24_e32 v85, -3, v76                             // 0000009AFD70: 12AA98C3
	.long 0xd7620019                                           // 0000009AFD74: D7620019
	v_cndmask_b32_e32 v1, 0xff, v26, vcc_lo                    // 0000009AFD78: 020234FF 000000FF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009AFD80: BF870234
	v_dual_mov_b32 v81, v10 :: v_dual_add_nc_u32 v84, v77, v15 // 0000009AFD84: CA20010A 51541F4D
	.long 0xd73c000f                                           // 0000009AFD8C: D73C000F
	v_cndmask_b32_e32 v1, 2, v15, vcc_lo                       // 0000009AFD90: 02021E82
	v_mov_b32_e32 v77, v10                                     // 0000009AFD94: 7E9A030A
	v_cmp_ne_u16_e32 vcc_lo, 24, v25                           // 0000009AFD98: 7C7A3298
	v_mov_b32_e32 v78, v10                                     // 0000009AFD9C: 7E9C030A
	v_and_b32_e32 v86, 0xff, v84                               // 0000009AFDA0: 36ACA8FF 000000FF
	v_mov_b32_e32 v80, v10                                     // 0000009AFDA8: 7EA0030A
	v_mov_b32_e32 v82, v10                                     // 0000009AFDAC: 7EA4030A
	v_cndmask_b16 v25, 0, v26, vcc_lo                          // 0000009AFDB0: D65D0019 01AA3480
	v_mov_b32_e32 v74, v10                                     // 0000009AFDB8: 7E94030A
	v_dual_mov_b32 v83, v10 :: v_dual_and_b32 v26, 0x7e0, v83  // 0000009AFDBC: CA24010A 531AA6FF 000007E0
	v_dual_mov_b32 v76, v10 :: v_dual_lshlrev_b32 v93, 2, v86  // 0000009AFDC8: CA22010A 4C5CAC82
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009AFDD0: BF870194
	v_and_b32_e32 v25, 0xff, v25                               // 0000009AFDD4: 363232FF 000000FF
	v_add3_u32 v92, v85, v26, 0xfffffd34                       // 0000009AFDDC: D655005C 03FE3555 FFFFFD34
	v_mov_b32_e32 v84, v10                                     // 0000009AFDE8: 7EA8030A
	v_mov_b32_e32 v86, v10                                     // 0000009AFDEC: 7EAC030A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009AFDF0: BF870004
	v_dual_mov_b32 v85, v10 :: v_dual_lshlrev_b32 v94, 2, v25  // 0000009AFDF4: CA22010A 555E3282
	.long 0xd73c0019                                           // 0000009AFDFC: D73C0019
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 0000009AFE00: 02021282
	v_mov_b32_e32 v87, v10                                     // 0000009AFE04: 7EAE030A
	v_mov_b32_e32 v9, v10                                      // 0000009AFE08: 7E12030A
	s_mov_b32 s0, 0                                            // 0000009AFE0C: BE800080
	s_mov_b32 s4, 0xdcd12d                                     // 0000009AFE10: BE8400FF 00DCD12D
	s_movk_i32 s5, 0x83                                        // 0000009AFE18: B0050083
	s_movk_i32 s7, 0x1eee                                      // 0000009AFE1C: B0071EEE
	s_branch 1847                                              // 0000009AFE20: BFA00737 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2300>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000009AFE24: 8C7E097E
	s_waitcnt vmcnt(55)                                        // 0000009AFE28: BF89DFF7
	.long 0xd73d0001                                           // 0000009AFE2C: D73D0001
	v_cndmask_b32_e32 v1, v90, v1, vcc_lo                      // 0000009AFE30: 0202035A
	s_waitcnt vmcnt(39)                                        // 0000009AFE34: BF899FF7
	.long 0xd73d0002                                           // 0000009AFE38: D73D0002
	v_cndmask_b32_e32 v1, v92, v3, vcc_lo                      // 0000009AFE3C: 0202075C
	.long 0xd73d0043                                           // 0000009AFE40: D73D0043
	v_cndmask_b32_e32 v1, v90, v67, vcc_lo                     // 0000009AFE44: 0202875A
	s_waitcnt vmcnt(38)                                        // 0000009AFE48: BF899BF7
	.long 0xd73d0044                                           // 0000009AFE4C: D73D0044
	v_cndmask_b32_e32 v1, v92, v69, vcc_lo                     // 0000009AFE50: 02028B5C
	.long 0xd73d003f                                           // 0000009AFE54: D73D003F
	v_cndmask_b32_e32 v1, v90, v63, vcc_lo                     // 0000009AFE58: 02027F5A
	.long 0xd73d003b                                           // 0000009AFE5C: D73D003B
	v_cndmask_b32_e32 v1, v90, v59, vcc_lo                     // 0000009AFE60: 0202775A
	v_bfe_u32 v3, v1, 9, 16                                    // 0000009AFE64: D6100003 02411301
	v_bfe_u32 v160, v2, 9, 16                                  // 0000009AFE6C: D61000A0 02411302
	v_bfe_u32 v161, v2, 6, 16                                  // 0000009AFE74: D61000A1 02410D02
	v_bfe_u32 v162, v2, 3, 16                                  // 0000009AFE7C: D61000A2 02410702
	v_and_b32_e32 v163, 0xffff, v2                             // 0000009AFE84: 374604FF 0000FFFF
	v_mul_u32_u24_e32 v2, s4, v3                               // 0000009AFE8C: 16040604
	v_mul_u32_u24_e32 v3, s5, v3                               // 0000009AFE90: 16060605
	v_lshl_add_u32 v2, v3, 24, v2                              // 0000009AFE94: D6460002 04093103
	v_bfe_u32 v4, v1, 6, 16                                    // 0000009AFE9C: D6100004 02410D01
	v_mul_u32_u24_e32 v3, s4, v4                               // 0000009AFEA4: 16060804
	v_bfe_u32 v159, v1, 3, 16                                  // 0000009AFEA8: D610009F 02410701
	v_mul_u32_u24_e32 v4, s5, v4                               // 0000009AFEB0: 16080805
	v_sad_u8 v2, v2, 0, 0x6400                                 // 0000009AFEB4: D6220002 03FD0102 00006400
	v_lshl_add_u32 v3, v4, 24, v3                              // 0000009AFEC0: D6460003 040D3104
	v_and_b32_e32 v1, 0xffff, v1                               // 0000009AFEC8: 360202FF 0000FFFF
	v_mul_u32_u24_e32 v164, s4, v159                           // 0000009AFED0: 17493E04
	v_mul_u32_u24_e32 v4, s5, v159                             // 0000009AFED4: 16093E05
	v_mul_u32_u24_e32 v159, s4, v160                           // 0000009AFED8: 173F4004
	v_and_b32_e32 v166, 0xffff, v2                             // 0000009AFEDC: 374C04FF 0000FFFF
	v_mul_u32_u24_e32 v2, s5, v160                             // 0000009AFEE4: 16054005
	v_lshl_add_u32 v159, v2, 24, v159                          // 0000009AFEE8: D646009F 067D3102
	v_mul_u32_u24_e32 v2, s4, v1                               // 0000009AFEF0: 16040204
	v_mul_u32_u24_e32 v1, s5, v1                               // 0000009AFEF4: 16020205
	v_lshl_add_u32 v160, v1, 24, v2                            // 0000009AFEF8: D64600A0 04093101
	v_mul_u32_u24_e32 v1, s4, v161                             // 0000009AFF00: 16034204
	v_mul_u32_u24_e32 v2, s5, v161                             // 0000009AFF04: 16054205
	v_lshl_add_u32 v161, v2, 24, v1                            // 0000009AFF08: D64600A1 04053102
	v_mul_u32_u24_e32 v1, s4, v162                             // 0000009AFF10: 16034404
	v_mul_u32_u24_e32 v2, s5, v162                             // 0000009AFF14: 16054405
	v_lshl_add_u32 v164, v4, 24, v164                          // 0000009AFF18: D64600A4 06913104
	v_sad_u8 v165, v3, 0, 0x6400                               // 0000009AFF20: D62200A5 03FD0103 00006400
	v_lshl_add_u32 v162, v2, 24, v1                            // 0000009AFF2C: D64600A2 04053102
	ds_load_b128 v[1:4], v91                                   // 0000009AFF34: DBFC0000 0100005B
	v_sad_u8 v159, v159, 0, 0x6400                             // 0000009AFF3C: D622009F 03FD019F 00006400
	v_sad_u8 v164, v164, 0, 0x6400                             // 0000009AFF48: D62200A4 03FD01A4 00006400
	v_lshl_or_b32 v165, v165, 16, v166                         // 0000009AFF54: D65600A5 069921A5
	v_sad_u8 v160, v160, 0, 0x6400                             // 0000009AFF5C: D62200A0 03FD01A0 00006400
	v_sad_u8 v161, v161, 0, 0x6400                             // 0000009AFF68: D62200A1 03FD01A1 00006400
	v_and_b32_e32 v159, 0xffff, v159                           // 0000009AFF74: 373F3EFF 0000FFFF
	v_and_b32_e32 v164, 0xffff, v164                           // 0000009AFF7C: 374948FF 0000FFFF
	v_pk_fma_f16 v165, v165, s7, 0xc931 op_sel_hi:[1,0,0]      // 0000009AFF84: CC0E00A5 0BFC0FA5 0000C931
	v_mul_u32_u24_e32 v167, s4, v163                           // 0000009AFF90: 174F4604
	v_mul_u32_u24_e32 v163, s5, v163                           // 0000009AFF94: 17474605
	v_lshl_add_u32 v163, v163, 24, v167                        // 0000009AFF98: D64600A3 069D31A3
	v_lshl_or_b32 v160, v160, 16, v164                         // 0000009AFFA0: D65600A0 069121A0
	v_sad_u8 v162, v162, 0, 0x6400                             // 0000009AFFA8: D62200A2 03FD01A2 00006400
	v_lshl_or_b32 v159, v161, 16, v159                         // 0000009AFFB4: D656009F 067D21A1
	v_bfe_u32 v69, v67, 9, 16                                  // 0000009AFFBC: D6100045 02411343
	v_sad_u8 v163, v163, 0, 0x6400                             // 0000009AFFC4: D62200A3 03FD01A3 00006400
	v_pk_fma_f16 v160, v160, s7, 0xc931 op_sel_hi:[1,0,0]      // 0000009AFFD0: CC0E00A0 0BFC0FA0 0000C931
	v_mul_u32_u24_e32 v164, s4, v69                            // 0000009AFFDC: 17488A04
	v_pk_fma_f16 v159, v159, s7, 0xc931 op_sel_hi:[1,0,0]      // 0000009AFFE0: CC0E009F 0BFC0F9F 0000C931
	s_waitcnt lgkmcnt(0)                                       // 0000009AFFEC: BF89FC07
	v_dot2acc_f32_f16 v9, v165, v1                             // 0000009AFFF0: 041203A5
	v_mul_u32_u24_e32 v69, s5, v69                             // 0000009AFFF4: 168A8A05
	v_lshl_add_u32 v69, v69, 24, v164                          // 0000009AFFF8: D6460045 06913145
	v_bfe_u32 v70, v67, 6, 16                                  // 0000009B0000: D6100046 02410D43
	v_bfe_u32 v164, v68, 6, 16                                 // 0000009B0008: D61000A4 02410D44
	v_dot2acc_f32_f16 v9, v160, v2                             // 0000009B0010: 041205A0
	v_and_b32_e32 v162, 0xffff, v162                           // 0000009B0014: 374544FF 0000FFFF
	v_sad_u8 v69, v69, 0, 0x6400                               // 0000009B001C: D6220045 03FD0145 00006400
	v_bfe_u32 v165, v68, 3, 16                                 // 0000009B0028: D61000A5 02410744
	s_waitcnt vmcnt(36)                                        // 0000009B0030: BF8993F7
	.long 0xd73d003c                                           // 0000009B0034: D73D003C
	v_cndmask_b32_e32 v1, v92, v61, vcc_lo                     // 0000009B0038: 02027B5C
	v_dot2acc_f32_f16 v9, v159, v3                             // 0000009B003C: 0412079F
	v_lshl_or_b32 v161, v163, 16, v162                         // 0000009B0040: D65600A1 068921A3
	v_bfe_u32 v162, v67, 3, 16                                 // 0000009B0048: D61000A2 02410743
	v_mul_u32_u24_e32 v166, s4, v162                           // 0000009B0050: 174D4404
	v_mul_u32_u24_e32 v162, s5, v162                           // 0000009B0054: 17454405
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B0058: BF870001
	v_lshl_add_u32 v162, v162, 24, v166                        // 0000009B005C: D64600A2 069931A2
	v_mul_u32_u24_e32 v166, s4, v70                            // 0000009B0064: 174C8C04
	v_mul_u32_u24_e32 v70, s5, v70                             // 0000009B0068: 168C8C05
	v_lshl_add_u32 v70, v70, 24, v166                          // 0000009B006C: D6460046 06993146
	v_and_b32_e32 v67, 0xffff, v67                             // 0000009B0074: 368686FF 0000FFFF
	v_bfe_u32 v163, v68, 9, 16                                 // 0000009B007C: D61000A3 02411344
	v_mul_u32_u24_e32 v166, s4, v67                            // 0000009B0084: 174C8604
	v_mul_u32_u24_e32 v67, s5, v67                             // 0000009B0088: 16868605
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B008C: BF870002
	v_lshl_add_u32 v67, v67, 24, v166                          // 0000009B0090: D6460043 06993143
	v_mul_u32_u24_e32 v166, s4, v163                           // 0000009B0098: 174D4604
	v_mul_u32_u24_e32 v163, s5, v163                           // 0000009B009C: 17474605
	v_lshl_add_u32 v163, v163, 24, v166                        // 0000009B00A0: D64600A3 069931A3
	v_sad_u8 v162, v162, 0, 0x6400                             // 0000009B00A8: D62200A2 03FD01A2 00006400
	v_and_b32_e32 v69, 0xffff, v69                             // 0000009B00B4: 368A8AFF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 0000009B00BC: D6220046 03FD0146 00006400
	v_mul_u32_u24_e32 v166, s4, v164                           // 0000009B00C8: 174D4804
	v_mul_u32_u24_e32 v164, s5, v164                           // 0000009B00CC: 17494805
	v_lshl_add_u32 v164, v164, 24, v166                        // 0000009B00D0: D64600A4 069931A4
	v_and_b32_e32 v162, 0xffff, v162                           // 0000009B00D8: 374544FF 0000FFFF
	v_sad_u8 v67, v67, 0, 0x6400                               // 0000009B00E0: D6220043 03FD0143 00006400
	v_sad_u8 v163, v163, 0, 0x6400                             // 0000009B00EC: D62200A3 03FD01A3 00006400
	v_lshl_or_b32 v69, v70, 16, v69                            // 0000009B00F8: D6560045 05152146
	v_bfe_u32 v61, v59, 9, 16                                  // 0000009B0100: D610003D 0241133B
	v_bfe_u32 v62, v59, 6, 16                                  // 0000009B0108: D610003E 02410D3B
	v_lshl_or_b32 v67, v67, 16, v162                           // 0000009B0110: D6560043 06892143
	v_and_b32_e32 v70, 0xffff, v163                            // 0000009B0118: 368D46FF 0000FFFF
	v_sad_u8 v162, v164, 0, 0x6400                             // 0000009B0120: D62200A2 03FD01A4 00006400
	v_pk_fma_f16 v69, v69, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B012C: CC0E0045 0BFC0F45 0000C931
	v_mul_u32_u24_e32 v166, s4, v165                           // 0000009B0138: 174D4A04
	v_pk_fma_f16 v67, v67, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B013C: CC0E0043 0BFC0F43 0000C931
	v_mul_u32_u24_e32 v165, s5, v165                           // 0000009B0148: 174B4A05
	v_lshl_or_b32 v70, v162, 16, v70                           // 0000009B014C: D6560046 051921A2
	v_dual_dot2acc_f32_f16 v87, v69, v1 :: v_dual_and_b32 v68, 0xffff, v68// 0000009B0154: CB240345 574488FF 0000FFFF
	v_bfe_u32 v69, v63, 9, 16                                  // 0000009B0160: D6100045 0241133F
	v_lshl_add_u32 v165, v165, 24, v166                        // 0000009B0168: D64600A5 069931A5
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B0170: BF870214
	v_pk_fma_f16 v64, v70, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0174: CC0E0040 0BFC0F46 0000C931
	v_dot2acc_f32_f16 v87, v67, v2                             // 0000009B0180: 04AE0543
	v_bfe_u32 v70, v63, 6, 16                                  // 0000009B0184: D6100046 02410D3F
	v_pk_fma_f16 v67, v161, s7, 0xc931 op_sel_hi:[1,0,0]       // 0000009B018C: CC0E0043 0BFC0FA1 0000C931
	v_mul_u32_u24_e32 v161, s4, v70                            // 0000009B0198: 17428C04
	v_mul_u32_u24_e32 v70, s5, v70                             // 0000009B019C: 168C8C05
	v_dot2acc_f32_f16 v87, v64, v3                             // 0000009B01A0: 04AE0740
	.long 0xd73d0040                                           // 0000009B01A4: D73D0040
	v_cndmask_b32_e32 v1, v92, v65, vcc_lo                     // 0000009B01A8: 0202835C
	v_mul_u32_u24_e32 v65, s4, v69                             // 0000009B01AC: 16828A04
	v_mul_u32_u24_e32 v66, s5, v69                             // 0000009B01B0: 16848A05
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B01B4: BF870001
	v_lshl_add_u32 v65, v66, 24, v65                           // 0000009B01B8: D6460041 05053142
	v_lshl_add_u32 v70, v70, 24, v161                          // 0000009B01C0: D6460046 06853146
	v_bfe_u32 v66, v63, 3, 16                                  // 0000009B01C8: D6100042 0241073F
	v_bfe_u32 v69, v64, 9, 16                                  // 0000009B01D0: D6100045 02411340
	v_mul_u32_u24_e32 v161, s4, v66                            // 0000009B01D8: 17428404
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009B01DC: D6220041 03FD0141 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 0000009B01E8: D6220046 03FD0146 00006400
	v_mul_u32_u24_e32 v66, s5, v66                             // 0000009B01F4: 16848405
	v_and_b32_e32 v63, 0xffff, v63                             // 0000009B01F8: 367E7EFF 0000FFFF
	v_lshl_add_u32 v66, v66, 24, v161                          // 0000009B0200: D6460042 06853142
	v_and_b32_e32 v65, 0xffff, v65                             // 0000009B0208: 368282FF 0000FFFF
	v_mul_u32_u24_e32 v161, s4, v69                            // 0000009B0210: 17428A04
	v_mul_u32_u24_e32 v69, s5, v69                             // 0000009B0214: 168A8A05
	v_bfe_u32 v159, v64, 6, 16                                 // 0000009B0218: D610009F 02410D40
	v_lshl_add_u32 v69, v69, 24, v161                          // 0000009B0220: D6460045 06853145
	v_lshl_or_b32 v65, v70, 16, v65                            // 0000009B0228: D6560041 05052146
	v_mul_u32_u24_e32 v161, s4, v63                            // 0000009B0230: 17427E04
	v_mul_u32_u24_e32 v63, s5, v63                             // 0000009B0234: 167E7E05
	v_lshl_add_u32 v63, v63, 24, v161                          // 0000009B0238: D646003F 0685313F
	v_mul_u32_u24_e32 v161, s4, v159                           // 0000009B0240: 17433E04
	v_pk_fma_f16 v65, v65, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0244: CC0E0041 0BFC0F41 0000C931
	v_mul_u32_u24_e32 v159, s5, v159                           // 0000009B0250: 173F3E05
	v_lshl_add_u32 v159, v159, 24, v161                        // 0000009B0254: D646009F 0685319F
	v_mul_u32_u24_e32 v161, s4, v61                            // 0000009B025C: 17427A04
	v_mul_u32_u24_e32 v61, s5, v61                             // 0000009B0260: 167A7A05
	v_lshl_add_u32 v61, v61, 24, v161                          // 0000009B0264: D646003D 0685313D
	v_dot2acc_f32_f16 v86, v65, v1                             // 0000009B026C: 04AC0341
	v_bfe_u32 v65, v59, 3, 16                                  // 0000009B0270: D6100041 0241073B
	v_mul_u32_u24_e32 v161, s4, v65                            // 0000009B0278: 17428204
	v_mul_u32_u24_e32 v65, s5, v65                             // 0000009B027C: 16828205
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B0280: BF870001
	v_lshl_add_u32 v65, v65, 24, v161                          // 0000009B0284: D6460041 06853141
	v_mul_u32_u24_e32 v161, s4, v62                            // 0000009B028C: 17427C04
	v_mul_u32_u24_e32 v62, s5, v62                             // 0000009B0290: 167C7C05
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000009B0294: D622003D 03FD013D 00006400
	v_lshl_add_u32 v62, v62, 24, v161                          // 0000009B02A0: D646003E 0685313E
	v_and_b32_e32 v59, 0xffff, v59                             // 0000009B02A8: 367676FF 0000FFFF
	v_mul_u32_u24_e32 v161, s4, v59                            // 0000009B02B0: 17427604
	v_mul_u32_u24_e32 v59, s5, v59                             // 0000009B02B4: 16767605
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009B02B8: D6220041 03FD0141 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B02C4: BF870002
	v_lshl_add_u32 v59, v59, 24, v161                          // 0000009B02C8: D646003B 0685313B
	v_and_b32_e32 v61, 0xffff, v61                             // 0000009B02D0: 367A7AFF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009B02D8: D622003E 03FD013E 00006400
	v_sad_u8 v163, v165, 0, 0x6400                             // 0000009B02E4: D62200A3 03FD01A5 00006400
	v_and_b32_e32 v65, 0xffff, v65                             // 0000009B02F0: 368282FF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009B02F8: D622003B 03FD013B 00006400
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000009B0304: D6220042 03FD0142 00006400
	v_lshl_or_b32 v61, v62, 16, v61                            // 0000009B0310: D656003D 04F5213E
	v_sad_u8 v69, v69, 0, 0x6400                               // 0000009B0318: D6220045 03FD0145 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 0000009B0324: D622003F 03FD013F 00006400
	v_lshl_or_b32 v59, v59, 16, v65                            // 0000009B0330: D656003B 0505213B
	v_sad_u8 v70, v159, 0, 0x6400                              // 0000009B0338: D6220046 03FD019F 00006400
	v_pk_fma_f16 v61, v61, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0344: CC0E003D 0BFC0F3D 0000C931
	v_and_b32_e32 v69, 0xffff, v69                             // 0000009B0350: 368A8AFF 0000FFFF
	v_bfe_u32 v160, v64, 3, 16                                 // 0000009B0358: D61000A0 02410740
	v_pk_fma_f16 v59, v59, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0360: CC0E003B 0BFC0F3B 0000C931
	v_mul_u32_u24_e32 v159, s4, v160                           // 0000009B036C: 173F4004
	v_dual_dot2acc_f32_f16 v85, v61, v1 :: v_dual_and_b32 v162, 0xffff, v163// 0000009B0370: CB24033D 55A346FF 0000FFFF
	v_and_b32_e32 v64, 0xffff, v64                             // 0000009B037C: 368080FF 0000FFFF
	v_mul_u32_u24_e32 v160, s5, v160                           // 0000009B0384: 17414005
	v_lshl_add_u32 v159, v160, 24, v159                        // 0000009B0388: D646009F 067D31A0
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009B0390: BF870003
	v_dot2acc_f32_f16 v85, v59, v2                             // 0000009B0394: 04AA053B
	v_and_b32_e32 v66, 0xffff, v66                             // 0000009B0398: 368484FF 0000FFFF
	v_bfe_u32 v160, v60, 3, 16                                 // 0000009B03A0: D61000A0 0241073C
	v_dot2acc_f32_f16 v9, v67, v4                              // 0000009B03A8: 04120943
	v_mul_u32_u24_e32 v164, s4, v68                            // 0000009B03AC: 17488804
	v_mul_u32_u24_e32 v68, s5, v68                             // 0000009B03B0: 16888805
	v_lshl_or_b32 v63, v63, 16, v66                            // 0000009B03B4: D656003F 0509213F
	v_lshl_or_b32 v66, v70, 16, v69                            // 0000009B03BC: D6560042 05152146
	v_mul_u32_u24_e32 v70, s4, v64                             // 0000009B03C4: 168C8004
	v_mul_u32_u24_e32 v64, s5, v64                             // 0000009B03C8: 16808005
	v_lshl_add_u32 v64, v64, 24, v70                           // 0000009B03CC: D6460040 05193140
	v_bfe_u32 v70, v60, 9, 16                                  // 0000009B03D4: D6100046 0241133C
	v_mul_u32_u24_e32 v161, s4, v70                            // 0000009B03DC: 17428C04
	v_mul_u32_u24_e32 v70, s5, v70                             // 0000009B03E0: 168C8C05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000009B03E4: BF8700D1
	v_lshl_add_u32 v70, v70, 24, v161                          // 0000009B03E8: D6460046 06853146
	v_sad_u8 v69, v159, 0, 0x6400                              // 0000009B03F0: D6220045 03FD019F 00006400
	v_bfe_u32 v159, v60, 6, 16                                 // 0000009B03FC: D610009F 02410D3C
	v_mul_u32_u24_e32 v161, s4, v159                           // 0000009B0404: 17433E04
	v_mul_u32_u24_e32 v159, s5, v159                           // 0000009B0408: 173F3E05
	v_lshl_add_u32 v159, v159, 24, v161                        // 0000009B040C: D646009F 0685319F
	v_mul_u32_u24_e32 v161, s4, v160                           // 0000009B0414: 17434004
	v_mul_u32_u24_e32 v160, s5, v160                           // 0000009B0418: 17414005
	v_sad_u8 v70, v70, 0, 0x6400                               // 0000009B041C: D6220046 03FD0146 00006400
	v_lshl_add_u32 v160, v160, 24, v161                        // 0000009B0428: D64600A0 068531A0
	v_and_b32_e32 v60, 0xffff, v60                             // 0000009B0430: 367878FF 0000FFFF
	v_sad_u8 v65, v159, 0, 0x6400                              // 0000009B0438: D6220041 03FD019F 00006400
	v_mul_u32_u24_e32 v159, s4, v60                            // 0000009B0444: 173E7804
	v_mul_u32_u24_e32 v60, s5, v60                             // 0000009B0448: 16787805
	v_and_b32_e32 v62, 0xffff, v70                             // 0000009B044C: 367C8CFF 0000FFFF
	v_sad_u8 v70, v160, 0, 0x6400                              // 0000009B0454: D6220046 03FD01A0 00006400
	v_lshl_add_u32 v60, v60, 24, v159                          // 0000009B0460: D646003C 067D313C
	v_pk_fma_f16 v63, v63, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0468: CC0E003F 0BFC0F3F 0000C931
	v_and_b32_e32 v69, 0xffff, v69                             // 0000009B0474: 368A8AFF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000009B047C: D6220040 03FD0140 00006400
	v_lshl_or_b32 v62, v65, 16, v62                            // 0000009B0488: D656003E 04F92141
	v_and_b32_e32 v65, 0xffff, v70                             // 0000009B0490: 36828CFF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009B0498: D622003C 03FD013C 00006400
	v_pk_fma_f16 v66, v66, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B04A4: CC0E0042 0BFC0F42 0000C931
	v_lshl_or_b32 v61, v64, 16, v69                            // 0000009B04B0: D656003D 05152140
	v_dot2acc_f32_f16 v86, v63, v2                             // 0000009B04B8: 04AC053F
	v_pk_fma_f16 v62, v62, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B04BC: CC0E003E 0BFC0F3E 0000C931
	v_lshl_or_b32 v60, v60, 16, v65                            // 0000009B04C8: D656003C 0505213C
	v_lshl_add_u32 v68, v68, 24, v164                          // 0000009B04D0: D6460044 06913144
	.long 0xd73d0037                                           // 0000009B04D8: D73D0037
	v_cndmask_b32_e32 v1, v90, v55, vcc_lo                     // 0000009B04DC: 02026F5A
	v_pk_fma_f16 v59, v61, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B04E0: CC0E003B 0BFC0F3D 0000C931
	v_dot2acc_f32_f16 v86, v66, v3                             // 0000009B04EC: 04AC0742
	v_pk_fma_f16 v56, v60, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B04F0: CC0E0038 0BFC0F3C 0000C931
	v_dot2acc_f32_f16 v85, v62, v3                             // 0000009B04FC: 04AA073E
	v_sad_u8 v68, v68, 0, 0x6400                               // 0000009B0500: D6220044 03FD0144 00006400
	v_bfe_u32 v60, v55, 6, 16                                  // 0000009B050C: D610003C 02410D37
	v_dot2acc_f32_f16 v86, v59, v4                             // 0000009B0514: 04AC093B
	v_bfe_u32 v59, v55, 9, 16                                  // 0000009B0518: D610003B 02411337
	v_dot2acc_f32_f16 v85, v56, v4                             // 0000009B0520: 04AA0938
	s_waitcnt vmcnt(35)                                        // 0000009B0524: BF898FF7
	.long 0xd73d0038                                           // 0000009B0528: D73D0038
	v_cndmask_b32_e32 v1, v92, v57, vcc_lo                     // 0000009B052C: 0202735C
	v_mul_u32_u24_e32 v58, s4, v59                             // 0000009B0530: 16747604
	v_lshl_or_b32 v68, v68, 16, v162                           // 0000009B0534: D6560044 06892144
	v_mul_u32_u24_e32 v59, s5, v59                             // 0000009B053C: 16767605
	v_lshl_add_u32 v58, v59, 24, v58                           // 0000009B0540: D646003A 04E9313B
	v_bfe_u32 v57, v55, 3, 16                                  // 0000009B0548: D6100039 02410737
	v_mul_u32_u24_e32 v63, s4, v60                             // 0000009B0550: 167E7804
	v_mul_u32_u24_e32 v60, s5, v60                             // 0000009B0554: 16787805
	v_pk_fma_f16 v68, v68, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0558: CC0E0044 0BFC0F44 0000C931
	v_bfe_u32 v59, v56, 9, 16                                  // 0000009B0564: D610003B 02411338
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000009B056C: D622003A 03FD013A 00006400
	v_lshl_add_u32 v60, v60, 24, v63                           // 0000009B0578: D646003C 04FD313C
	v_mul_u32_u24_e32 v63, s4, v57                             // 0000009B0580: 167E7204
	v_mul_u32_u24_e32 v57, s5, v57                             // 0000009B0584: 16727205
	v_lshl_add_u32 v57, v57, 24, v63                           // 0000009B0588: D6460039 04FD3139
	v_mul_u32_u24_e32 v63, s4, v59                             // 0000009B0590: 167E7604
	v_mul_u32_u24_e32 v59, s5, v59                             // 0000009B0594: 16767605
	v_lshl_add_u32 v59, v59, 24, v63                           // 0000009B0598: D646003B 04FD313B
	v_and_b32_e32 v55, 0xffff, v55                             // 0000009B05A0: 366E6EFF 0000FFFF
	v_bfe_u32 v61, v56, 6, 16                                  // 0000009B05A8: D610003D 02410D38
	v_mul_u32_u24_e32 v63, s4, v55                             // 0000009B05B0: 167E6E04
	v_mul_u32_u24_e32 v55, s5, v55                             // 0000009B05B4: 166E6E05
	v_dual_dot2acc_f32_f16 v87, v68, v4 :: v_dual_and_b32 v58, 0xffff, v58// 0000009B05B8: CB240944 573A74FF 0000FFFF
	v_bfe_u32 v62, v56, 3, 16                                  // 0000009B05C4: D610003E 02410738
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009B05CC: D622003C 03FD013C 00006400
	v_lshl_add_u32 v55, v55, 24, v63                           // 0000009B05D8: D6460037 04FD3137
	v_mul_u32_u24_e32 v63, s4, v61                             // 0000009B05E0: 167E7A04
	v_mul_u32_u24_e32 v61, s5, v61                             // 0000009B05E4: 167A7A05
	v_lshl_add_u32 v61, v61, 24, v63                           // 0000009B05E8: D646003D 04FD313D
	v_mul_u32_u24_e32 v63, s4, v62                             // 0000009B05F0: 167E7C04
	v_mul_u32_u24_e32 v62, s5, v62                             // 0000009B05F4: 167C7C05
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009B05F8: D6220039 03FD0139 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009B0604: D622003B 03FD013B 00006400
	v_lshl_add_u32 v62, v62, 24, v63                           // 0000009B0610: D646003E 04FD313E
	v_lshl_or_b32 v58, v60, 16, v58                            // 0000009B0618: D656003A 04E9213C
	.long 0xd73d0033                                           // 0000009B0620: D73D0033
	v_cndmask_b32_e32 v1, v90, v51, vcc_lo                     // 0000009B0624: 0202675A
	v_and_b32_e32 v57, 0xffff, v57                             // 0000009B0628: 367272FF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009B0630: D6220037 03FD0137 00006400
	v_and_b32_e32 v59, 0xffff, v59                             // 0000009B063C: 367676FF 0000FFFF
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000009B0644: D622003D 03FD013D 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009B0650: D622003E 03FD013E 00006400
	v_pk_fma_f16 v58, v58, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B065C: CC0E003A 0BFC0F3A 0000C931
	s_waitcnt vmcnt(34)                                        // 0000009B0668: BF898BF7
	.long 0xd73d0034                                           // 0000009B066C: D73D0034
	v_cndmask_b32_e32 v1, v92, v53, vcc_lo                     // 0000009B0670: 02026B5C
	v_bfe_u32 v53, v51, 9, 16                                  // 0000009B0674: D6100035 02411333
	v_lshl_or_b32 v55, v55, 16, v57                            // 0000009B067C: D6560037 04E52137
	v_lshl_or_b32 v57, v61, 16, v59                            // 0000009B0684: D6560039 04ED213D
	v_and_b32_e32 v59, 0xffff, v62                             // 0000009B068C: 36767CFF 0000FFFF
	v_mul_u32_u24_e32 v62, s4, v53                             // 0000009B0694: 167C6A04
	v_mul_u32_u24_e32 v53, s5, v53                             // 0000009B0698: 166A6A05
	v_lshl_add_u32 v53, v53, 24, v62                           // 0000009B069C: D6460035 04F93135
	v_dot2acc_f32_f16 v84, v58, v1                             // 0000009B06A4: 04A8033A
	v_bfe_u32 v58, v51, 3, 16                                  // 0000009B06A8: D610003A 02410733
	v_bfe_u32 v54, v51, 6, 16                                  // 0000009B06B0: D6100036 02410D33
	v_mul_u32_u24_e32 v62, s4, v58                             // 0000009B06B8: 167C7404
	v_mul_u32_u24_e32 v58, s5, v58                             // 0000009B06BC: 16747405
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B06C0: BF870002
	v_lshl_add_u32 v58, v58, 24, v62                           // 0000009B06C4: D646003A 04F9313A
	v_mul_u32_u24_e32 v62, s4, v54                             // 0000009B06CC: 167C6C04
	v_mul_u32_u24_e32 v54, s5, v54                             // 0000009B06D0: 166C6C05
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009B06D4: D6220035 03FD0135 00006400
	v_lshl_add_u32 v54, v54, 24, v62                           // 0000009B06E0: D6460036 04F93136
	v_and_b32_e32 v51, 0xffff, v51                             // 0000009B06E8: 366666FF 0000FFFF
	v_mul_u32_u24_e32 v62, s4, v51                             // 0000009B06F0: 167C6604
	v_mul_u32_u24_e32 v51, s5, v51                             // 0000009B06F4: 16666605
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000009B06F8: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B0704: BF870002
	v_lshl_add_u32 v51, v51, 24, v62                           // 0000009B0708: D6460033 04F93133
	v_and_b32_e32 v53, 0xffff, v53                             // 0000009B0710: 366A6AFF 0000FFFF
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009B0718: D6220036 03FD0136 00006400
	v_bfe_u32 v60, v52, 6, 16                                  // 0000009B0724: D610003C 02410D34
	v_and_b32_e32 v58, 0xffff, v58                             // 0000009B072C: 367474FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000009B0734: D6220033 03FD0133 00006400
	.long 0xd73d002f                                           // 0000009B0740: D73D002F
	v_cndmask_b32_e32 v1, v90, v47, vcc_lo                     // 0000009B0744: 02025F5A
	v_lshl_or_b32 v53, v54, 16, v53                            // 0000009B0748: D6560035 04D52136
	v_pk_fma_f16 v55, v55, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0750: CC0E0037 0BFC0F37 0000C931
	v_bfe_u32 v61, v52, 3, 16                                  // 0000009B075C: D610003D 02410734
	v_lshl_or_b32 v51, v51, 16, v58                            // 0000009B0764: D6560033 04E92133
	v_pk_fma_f16 v57, v57, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B076C: CC0E0039 0BFC0F39 0000C931
	v_pk_fma_f16 v53, v53, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0778: CC0E0035 0BFC0F35 0000C931
	v_dot2acc_f32_f16 v84, v55, v2                             // 0000009B0784: 04A80537
	.long 0xd73d002b                                           // 0000009B0788: D73D002B
	v_cndmask_b32_e32 v1, v90, v43, vcc_lo                     // 0000009B078C: 0202575A
	v_pk_fma_f16 v51, v51, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0790: CC0E0033 0BFC0F33 0000C931
	s_waitcnt vmcnt(32)                                        // 0000009B079C: BF8983F7
	.long 0xd73d002c                                           // 0000009B07A0: D73D002C
	v_cndmask_b32_e32 v1, v92, v45, vcc_lo                     // 0000009B07A4: 02025B5C
	v_dual_dot2acc_f32_f16 v83, v53, v1 :: v_dual_and_b32 v56, 0xffff, v56// 0000009B07A8: CB240335 533870FF 0000FFFF
	v_bfe_u32 v53, v47, 9, 16                                  // 0000009B07B4: D6100035 0241132F
	v_dot2acc_f32_f16 v84, v57, v3                             // 0000009B07BC: 04A80739
	v_bfe_u32 v45, v43, 9, 16                                  // 0000009B07C0: D610002D 0241132B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B07C8: BF870004
	v_dot2acc_f32_f16 v83, v51, v2                             // 0000009B07CC: 04A60533
	v_mul_u32_u24_e32 v63, s4, v56                             // 0000009B07D0: 167E7004
	v_mul_u32_u24_e32 v56, s5, v56                             // 0000009B07D4: 16707005
	v_lshl_add_u32 v56, v56, 24, v63                           // 0000009B07D8: D6460038 04FD3138
	v_bfe_u32 v46, v43, 6, 16                                  // 0000009B07E0: D610002E 02410D2B
	s_waitcnt vmcnt(23)                                        // 0000009B07E8: BF895FF7
	.long 0xd73d0027                                           // 0000009B07EC: D73D0027
	v_cndmask_b32_e32 v1, v90, v39, vcc_lo                     // 0000009B07F0: 02024F5A
	s_waitcnt vmcnt(22)                                        // 0000009B07F4: BF895BF7
	.long 0xd73d0023                                           // 0000009B07F8: D73D0023
	v_cndmask_b32_e32 v1, v90, v35, vcc_lo                     // 0000009B07FC: 0202475A
	s_waitcnt vmcnt(6)                                         // 0000009B0800: BF891BF7
	.long 0xd73d0024                                           // 0000009B0804: D73D0024
	v_cndmask_b32_e32 v1, v92, v37, vcc_lo                     // 0000009B0808: 02024B5C
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009B080C: D6220038 03FD0138 00006400
	.long 0xd73d001f                                           // 0000009B0818: D73D001F
	v_cndmask_b32_e32 v1, v90, v31, vcc_lo                     // 0000009B081C: 02023F5A
	.long 0xd73d001b                                           // 0000009B0820: D73D001B
	v_cndmask_b32_e32 v1, v90, v27, vcc_lo                     // 0000009B0824: 0202375A
	s_waitcnt vmcnt(4)                                         // 0000009B0828: BF8913F7
	.long 0xd73d001c                                           // 0000009B082C: D73D001C
	v_cndmask_b32_e32 v1, v92, v29, vcc_lo                     // 0000009B0830: 02023B5C
	v_bfe_u32 v37, v35, 9, 16                                  // 0000009B0834: D6100025 02411323
	v_lshl_or_b32 v56, v56, 16, v59                            // 0000009B083C: D6560038 04ED2138
	v_bfe_u32 v59, v52, 9, 16                                  // 0000009B0844: D610003B 02411334
	v_mul_u32_u24_e32 v62, s4, v59                             // 0000009B084C: 167C7604
	v_mul_u32_u24_e32 v59, s5, v59                             // 0000009B0850: 16767605
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B0854: BF870001
	v_lshl_add_u32 v59, v59, 24, v62                           // 0000009B0858: D646003B 04F9313B
	v_mul_u32_u24_e32 v62, s4, v60                             // 0000009B0860: 167C7804
	v_mul_u32_u24_e32 v60, s5, v60                             // 0000009B0864: 16787805
	v_lshl_add_u32 v60, v60, 24, v62                           // 0000009B0868: D646003C 04F9313C
	v_mul_u32_u24_e32 v62, s4, v61                             // 0000009B0870: 167C7A04
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009B0874: D622003B 03FD013B 00006400
	v_mul_u32_u24_e32 v61, s5, v61                             // 0000009B0880: 167A7A05
	v_lshl_add_u32 v61, v61, 24, v62                           // 0000009B0884: D646003D 04F9313D
	v_sad_u8 v58, v60, 0, 0x6400                               // 0000009B088C: D622003A 03FD013C 00006400
	v_pk_fma_f16 v51, v56, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0898: CC0E0033 0BFC0F38 0000C931
	v_and_b32_e32 v54, 0xffff, v59                             // 0000009B08A4: 366C76FF 0000FFFF
	v_bfe_u32 v38, v35, 6, 16                                  // 0000009B08AC: D6100026 02410D23
	v_sad_u8 v59, v61, 0, 0x6400                               // 0000009B08B4: D622003B 03FD013D 00006400
	v_bfe_u32 v29, v27, 9, 16                                  // 0000009B08C0: D610001D 0241131B
	v_bfe_u32 v30, v27, 6, 16                                  // 0000009B08C8: D610001E 02410D1B
	v_lshl_or_b32 v54, v58, 16, v54                            // 0000009B08D0: D6560036 04D9213A
	.long 0xd73d0015                                           // 0000009B08D8: D73D0015
	v_cndmask_b32_e32 v1, v90, v21, vcc_lo                     // 0000009B08DC: 02022B5A
	.long 0xd73d0011                                           // 0000009B08E0: D73D0011
	v_cndmask_b32_e32 v1, v90, v17, vcc_lo                     // 0000009B08E4: 0202235A
	s_waitcnt vmcnt(2)                                         // 0000009B08E8: BF890BF7
	.long 0xd73d0012                                           // 0000009B08EC: D73D0012
	v_cndmask_b32_e32 v1, v92, v19, vcc_lo                     // 0000009B08F0: 0202275C
	.long 0xd73d000b                                           // 0000009B08F4: D73D000B
	v_cndmask_b32_e32 v1, v90, v11, vcc_lo                     // 0000009B08F8: 0202175A
	v_pk_fma_f16 v48, v54, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B08FC: CC0E0030 0BFC0F36 0000C931
	v_and_b32_e32 v52, 0xffff, v52                             // 0000009B0908: 366868FF 0000FFFF
	v_bfe_u32 v54, v47, 6, 16                                  // 0000009B0910: D6100036 02410D2F
	v_mul_u32_u24_e32 v57, s4, v54                             // 0000009B0918: 16726C04
	v_mul_u32_u24_e32 v54, s5, v54                             // 0000009B091C: 166C6C05
	v_dot2acc_f32_f16 v83, v48, v3                             // 0000009B0920: 04A60730
	.long 0xd73d0030                                           // 0000009B0924: D73D0030
	v_cndmask_b32_e32 v1, v92, v49, vcc_lo                     // 0000009B0928: 0202635C
	v_mul_u32_u24_e32 v49, s4, v53                             // 0000009B092C: 16626A04
	v_mul_u32_u24_e32 v50, s5, v53                             // 0000009B0930: 16646A05
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B0934: BF870001
	v_lshl_add_u32 v49, v50, 24, v49                           // 0000009B0938: D6460031 04C53132
	v_lshl_add_u32 v54, v54, 24, v57                           // 0000009B0940: D6460036 04E53136
	v_bfe_u32 v50, v47, 3, 16                                  // 0000009B0948: D6100032 0241072F
	v_bfe_u32 v53, v48, 9, 16                                  // 0000009B0950: D6100035 02411330
	v_mul_u32_u24_e32 v57, s4, v50                             // 0000009B0958: 16726404
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009B095C: D6220031 03FD0131 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009B0968: D6220036 03FD0136 00006400
	v_mul_u32_u24_e32 v50, s5, v50                             // 0000009B0974: 16646405
	v_and_b32_e32 v47, 0xffff, v47                             // 0000009B0978: 365E5EFF 0000FFFF
	v_lshl_add_u32 v50, v50, 24, v57                           // 0000009B0980: D6460032 04E53132
	v_and_b32_e32 v49, 0xffff, v49                             // 0000009B0988: 366262FF 0000FFFF
	v_mul_u32_u24_e32 v57, s4, v53                             // 0000009B0990: 16726A04
	v_mul_u32_u24_e32 v53, s5, v53                             // 0000009B0994: 166A6A05
	v_bfe_u32 v55, v48, 6, 16                                  // 0000009B0998: D6100037 02410D30
	v_lshl_add_u32 v53, v53, 24, v57                           // 0000009B09A0: D6460035 04E53135
	v_lshl_or_b32 v49, v54, 16, v49                            // 0000009B09A8: D6560031 04C52136
	v_mul_u32_u24_e32 v57, s4, v47                             // 0000009B09B0: 16725E04
	v_mul_u32_u24_e32 v47, s5, v47                             // 0000009B09B4: 165E5E05
	v_lshl_add_u32 v47, v47, 24, v57                           // 0000009B09B8: D646002F 04E5312F
	v_mul_u32_u24_e32 v57, s4, v55                             // 0000009B09C0: 16726E04
	v_pk_fma_f16 v49, v49, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B09C4: CC0E0031 0BFC0F31 0000C931
	v_mul_u32_u24_e32 v55, s5, v55                             // 0000009B09D0: 166E6E05
	v_lshl_add_u32 v55, v55, 24, v57                           // 0000009B09D4: D6460037 04E53137
	v_mul_u32_u24_e32 v57, s4, v45                             // 0000009B09DC: 16725A04
	v_mul_u32_u24_e32 v45, s5, v45                             // 0000009B09E0: 165A5A05
	v_lshl_add_u32 v45, v45, 24, v57                           // 0000009B09E4: D646002D 04E5312D
	v_dot2acc_f32_f16 v82, v49, v1                             // 0000009B09EC: 04A40331
	v_bfe_u32 v49, v43, 3, 16                                  // 0000009B09F0: D6100031 0241072B
	v_mul_u32_u24_e32 v57, s4, v49                             // 0000009B09F8: 16726204
	v_mul_u32_u24_e32 v49, s5, v49                             // 0000009B09FC: 16626205
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B0A00: BF870001
	v_lshl_add_u32 v49, v49, 24, v57                           // 0000009B0A04: D6460031 04E53131
	v_mul_u32_u24_e32 v57, s4, v46                             // 0000009B0A0C: 16725C04
	v_mul_u32_u24_e32 v46, s5, v46                             // 0000009B0A10: 165C5C05
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009B0A14: D622002D 03FD012D 00006400
	v_lshl_add_u32 v46, v46, 24, v57                           // 0000009B0A20: D646002E 04E5312E
	v_and_b32_e32 v43, 0xffff, v43                             // 0000009B0A28: 365656FF 0000FFFF
	v_mul_u32_u24_e32 v57, s4, v43                             // 0000009B0A30: 16725604
	v_mul_u32_u24_e32 v43, s5, v43                             // 0000009B0A34: 16565605
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009B0A38: D6220031 03FD0131 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B0A44: BF870002
	v_lshl_add_u32 v43, v43, 24, v57                           // 0000009B0A48: D646002B 04E5312B
	v_and_b32_e32 v45, 0xffff, v45                             // 0000009B0A50: 365A5AFF 0000FFFF
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009B0A58: D622002E 03FD012E 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009B0A64: D6220032 03FD0132 00006400
	v_and_b32_e32 v49, 0xffff, v49                             // 0000009B0A70: 366262FF 0000FFFF
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009B0A78: D622002B 03FD012B 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009B0A84: D6220035 03FD0135 00006400
	v_lshl_or_b32 v45, v46, 16, v45                            // 0000009B0A90: D656002D 04B5212E
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000009B0A98: D622002F 03FD012F 00006400
	v_sad_u8 v54, v55, 0, 0x6400                               // 0000009B0AA4: D6220036 03FD0137 00006400
	v_lshl_or_b32 v43, v43, 16, v49                            // 0000009B0AB0: D656002B 04C5212B
	v_and_b32_e32 v53, 0xffff, v53                             // 0000009B0AB8: 366A6AFF 0000FFFF
	v_pk_fma_f16 v45, v45, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0AC0: CC0E002D 0BFC0F2D 0000C931
	v_mul_u32_u24_e32 v60, s4, v52                             // 0000009B0ACC: 16786804
	v_mul_u32_u24_e32 v52, s5, v52                             // 0000009B0AD0: 16686805
	v_pk_fma_f16 v43, v43, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0AD4: CC0E002B 0BFC0F2B 0000C931
	v_lshl_add_u32 v52, v52, 24, v60                           // 0000009B0AE0: D6460034 04F13134
	v_dual_dot2acc_f32_f16 v81, v45, v1 :: v_dual_and_b32 v58, 0xffff, v59// 0000009B0AE8: CB24032D 513A76FF 0000FFFF
	v_bfe_u32 v56, v48, 3, 16                                  // 0000009B0AF4: D6100038 02410730
	v_mul_u32_u24_e32 v55, s4, v56                             // 0000009B0AFC: 166E7004
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B0B00: BF870002
	v_dual_dot2acc_f32_f16 v81, v43, v2 :: v_dual_and_b32 v48, 0xffff, v48// 0000009B0B04: CB24052B 513060FF 0000FFFF
	v_and_b32_e32 v50, 0xffff, v50                             // 0000009B0B10: 366464FF 0000FFFF
	v_mul_u32_u24_e32 v56, s5, v56                             // 0000009B0B18: 16707005
	v_lshl_add_u32 v55, v56, 24, v55                           // 0000009B0B1C: D6460037 04DD3138
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000009B0B24: D6220034 03FD0134 00006400
	v_bfe_u32 v56, v44, 3, 16                                  // 0000009B0B30: D6100038 0241072C
	v_lshl_or_b32 v47, v47, 16, v50                            // 0000009B0B38: D656002F 04C9212F
	v_lshl_or_b32 v50, v54, 16, v53                            // 0000009B0B40: D6560032 04D52136
	v_mul_u32_u24_e32 v54, s4, v48                             // 0000009B0B48: 166C6004
	v_mul_u32_u24_e32 v48, s5, v48                             // 0000009B0B4C: 16606005
	v_lshl_add_u32 v48, v48, 24, v54                           // 0000009B0B50: D6460030 04D93130
	v_bfe_u32 v54, v44, 9, 16                                  // 0000009B0B58: D6100036 0241132C
	v_mul_u32_u24_e32 v57, s4, v54                             // 0000009B0B60: 16726C04
	v_mul_u32_u24_e32 v54, s5, v54                             // 0000009B0B64: 166C6C05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000009B0B68: BF8700D1
	v_lshl_add_u32 v54, v54, 24, v57                           // 0000009B0B6C: D6460036 04E53136
	v_sad_u8 v53, v55, 0, 0x6400                               // 0000009B0B74: D6220035 03FD0137 00006400
	v_bfe_u32 v55, v44, 6, 16                                  // 0000009B0B80: D6100037 02410D2C
	v_mul_u32_u24_e32 v57, s4, v55                             // 0000009B0B88: 16726E04
	v_mul_u32_u24_e32 v55, s5, v55                             // 0000009B0B8C: 166E6E05
	v_lshl_add_u32 v55, v55, 24, v57                           // 0000009B0B90: D6460037 04E53137
	v_mul_u32_u24_e32 v57, s4, v56                             // 0000009B0B98: 16727004
	v_mul_u32_u24_e32 v56, s5, v56                             // 0000009B0B9C: 16707005
	v_lshl_or_b32 v52, v52, 16, v58                            // 0000009B0BA0: D6560034 04E92134
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009B0BA8: D6220036 03FD0136 00006400
	v_lshl_add_u32 v56, v56, 24, v57                           // 0000009B0BB4: D6460038 04E53138
	v_and_b32_e32 v44, 0xffff, v44                             // 0000009B0BBC: 365858FF 0000FFFF
	v_sad_u8 v49, v55, 0, 0x6400                               // 0000009B0BC4: D6220031 03FD0137 00006400
	v_mul_u32_u24_e32 v55, s4, v44                             // 0000009B0BD0: 166E5804
	v_mul_u32_u24_e32 v44, s5, v44                             // 0000009B0BD4: 16585805
	v_pk_fma_f16 v52, v52, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0BD8: CC0E0034 0BFC0F34 0000C931
	v_and_b32_e32 v46, 0xffff, v54                             // 0000009B0BE4: 365C6CFF 0000FFFF
	v_sad_u8 v54, v56, 0, 0x6400                               // 0000009B0BEC: D6220036 03FD0138 00006400
	v_lshl_add_u32 v44, v44, 24, v55                           // 0000009B0BF8: D646002C 04DD312C
	v_pk_fma_f16 v47, v47, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0C00: CC0E002F 0BFC0F2F 0000C931
	v_and_b32_e32 v53, 0xffff, v53                             // 0000009B0C0C: 366A6AFF 0000FFFF
	v_sad_u8 v48, v48, 0, 0x6400                               // 0000009B0C14: D6220030 03FD0130 00006400
	v_dot2acc_f32_f16 v83, v52, v4                             // 0000009B0C20: 04A60934
	v_lshl_or_b32 v46, v49, 16, v46                            // 0000009B0C24: D656002E 04B92131
	v_and_b32_e32 v49, 0xffff, v54                             // 0000009B0C2C: 36626CFF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009B0C34: D622002C 03FD012C 00006400
	v_pk_fma_f16 v50, v50, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0C40: CC0E0032 0BFC0F32 0000C931
	v_lshl_or_b32 v45, v48, 16, v53                            // 0000009B0C4C: D656002D 04D52130
	v_dot2acc_f32_f16 v82, v47, v2                             // 0000009B0C54: 04A4052F
	v_pk_fma_f16 v46, v46, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0C58: CC0E002E 0BFC0F2E 0000C931
	v_lshl_or_b32 v44, v44, 16, v49                            // 0000009B0C64: D656002C 04C5212C
	v_bfe_u32 v19, v17, 9, 16                                  // 0000009B0C6C: D6100013 02411311
	v_pk_fma_f16 v43, v45, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0C74: CC0E002B 0BFC0F2D 0000C931
	v_dot2acc_f32_f16 v82, v50, v3                             // 0000009B0C80: 04A40732
	v_dot2acc_f32_f16 v81, v46, v3                             // 0000009B0C84: 04A2072E
	v_pk_fma_f16 v40, v44, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0C88: CC0E0028 0BFC0F2C 0000C931
	v_bfe_u32 v44, v39, 6, 16                                  // 0000009B0C94: D610002C 02410D27
	v_mul_u32_u24_e32 v47, s4, v44                             // 0000009B0C9C: 165E5804
	v_dot2acc_f32_f16 v82, v43, v4                             // 0000009B0CA0: 04A4092B
	v_bfe_u32 v43, v39, 9, 16                                  // 0000009B0CA4: D610002B 02411327
	v_dot2acc_f32_f16 v81, v40, v4                             // 0000009B0CAC: 04A20928
	.long 0xd73d0028                                           // 0000009B0CB0: D73D0028
	v_cndmask_b32_e32 v1, v92, v41, vcc_lo                     // 0000009B0CB4: 0202535C
	v_mul_u32_u24_e32 v42, s4, v43                             // 0000009B0CB8: 16545604
	v_mul_u32_u24_e32 v43, s5, v43                             // 0000009B0CBC: 16565605
	v_lshl_add_u32 v42, v43, 24, v42                           // 0000009B0CC0: D646002A 04A9312B
	v_bfe_u32 v41, v39, 3, 16                                  // 0000009B0CC8: D6100029 02410727
	v_mul_u32_u24_e32 v44, s5, v44                             // 0000009B0CD0: 16585805
	v_bfe_u32 v43, v40, 9, 16                                  // 0000009B0CD4: D610002B 02411328
	v_lshl_add_u32 v44, v44, 24, v47                           // 0000009B0CDC: D646002C 04BD312C
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000009B0CE4: D622002A 03FD012A 00006400
	v_mul_u32_u24_e32 v47, s4, v41                             // 0000009B0CF0: 165E5204
	v_mul_u32_u24_e32 v41, s5, v41                             // 0000009B0CF4: 16525205
	v_lshl_add_u32 v41, v41, 24, v47                           // 0000009B0CF8: D6460029 04BD3129
	v_mul_u32_u24_e32 v47, s4, v43                             // 0000009B0D00: 165E5604
	v_mul_u32_u24_e32 v43, s5, v43                             // 0000009B0D04: 16565605
	v_lshl_add_u32 v43, v43, 24, v47                           // 0000009B0D08: D646002B 04BD312B
	v_and_b32_e32 v39, 0xffff, v39                             // 0000009B0D10: 364E4EFF 0000FFFF
	v_bfe_u32 v45, v40, 6, 16                                  // 0000009B0D18: D610002D 02410D28
	v_mul_u32_u24_e32 v47, s4, v39                             // 0000009B0D20: 165E4E04
	v_mul_u32_u24_e32 v39, s5, v39                             // 0000009B0D24: 164E4E05
	v_bfe_u32 v46, v40, 3, 16                                  // 0000009B0D28: D610002E 02410728
	v_and_b32_e32 v42, 0xffff, v42                             // 0000009B0D30: 365454FF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009B0D38: D622002C 03FD012C 00006400
	v_lshl_add_u32 v39, v39, 24, v47                           // 0000009B0D44: D6460027 04BD3127
	v_mul_u32_u24_e32 v47, s4, v45                             // 0000009B0D4C: 165E5A04
	v_mul_u32_u24_e32 v45, s5, v45                             // 0000009B0D50: 165A5A05
	v_lshl_add_u32 v45, v45, 24, v47                           // 0000009B0D54: D646002D 04BD312D
	v_mul_u32_u24_e32 v47, s4, v46                             // 0000009B0D5C: 165E5C04
	v_mul_u32_u24_e32 v46, s5, v46                             // 0000009B0D60: 165C5C05
	v_sad_u8 v41, v41, 0, 0x6400                               // 0000009B0D64: D6220029 03FD0129 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009B0D70: D622002B 03FD012B 00006400
	v_lshl_add_u32 v46, v46, 24, v47                           // 0000009B0D7C: D646002E 04BD312E
	v_lshl_or_b32 v42, v44, 16, v42                            // 0000009B0D84: D656002A 04A9212C
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000009B0D8C: D6220027 03FD0127 00006400
	v_and_b32_e32 v41, 0xffff, v41                             // 0000009B0D98: 365252FF 0000FFFF
	v_and_b32_e32 v43, 0xffff, v43                             // 0000009B0DA0: 365656FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009B0DA8: D622002D 03FD012D 00006400
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009B0DB4: D622002E 03FD012E 00006400
	v_pk_fma_f16 v42, v42, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0DC0: CC0E002A 0BFC0F2A 0000C931
	v_lshl_or_b32 v39, v39, 16, v41                            // 0000009B0DCC: D6560027 04A52127
	v_bfe_u32 v44, v36, 6, 16                                  // 0000009B0DD4: D610002C 02410D24
	v_lshl_or_b32 v41, v45, 16, v43                            // 0000009B0DDC: D6560029 04AD212D
	v_and_b32_e32 v43, 0xffff, v46                             // 0000009B0DE4: 36565CFF 0000FFFF
	v_mul_u32_u24_e32 v46, s4, v37                             // 0000009B0DEC: 165C4A04
	v_mul_u32_u24_e32 v37, s5, v37                             // 0000009B0DF0: 164A4A05
	v_lshl_add_u32 v37, v37, 24, v46                           // 0000009B0DF4: D6460025 04B93125
	v_dot2acc_f32_f16 v80, v42, v1                             // 0000009B0DFC: 04A0032A
	v_bfe_u32 v42, v35, 3, 16                                  // 0000009B0E00: D610002A 02410723
	v_mul_u32_u24_e32 v46, s4, v42                             // 0000009B0E08: 165C5404
	v_mul_u32_u24_e32 v42, s5, v42                             // 0000009B0E0C: 16545405
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B0E10: BF870001
	v_lshl_add_u32 v42, v42, 24, v46                           // 0000009B0E14: D646002A 04B9312A
	v_mul_u32_u24_e32 v46, s4, v38                             // 0000009B0E1C: 165C4C04
	v_mul_u32_u24_e32 v38, s5, v38                             // 0000009B0E20: 164C4C05
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000009B0E24: D6220025 03FD0125 00006400
	v_lshl_add_u32 v38, v38, 24, v46                           // 0000009B0E30: D6460026 04B93126
	v_and_b32_e32 v35, 0xffff, v35                             // 0000009B0E38: 364646FF 0000FFFF
	v_mul_u32_u24_e32 v46, s4, v35                             // 0000009B0E40: 165C4604
	v_mul_u32_u24_e32 v35, s5, v35                             // 0000009B0E44: 16464605
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000009B0E48: D622002A 03FD012A 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B0E54: BF870002
	v_lshl_add_u32 v35, v35, 24, v46                           // 0000009B0E58: D6460023 04B93123
	v_and_b32_e32 v37, 0xffff, v37                             // 0000009B0E60: 364A4AFF 0000FFFF
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000009B0E68: D6220026 03FD0126 00006400
	v_pk_fma_f16 v39, v39, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0E74: CC0E0027 0BFC0F27 0000C931
	v_and_b32_e32 v42, 0xffff, v42                             // 0000009B0E80: 365454FF 0000FFFF
	v_sad_u8 v35, v35, 0, 0x6400                               // 0000009B0E88: D6220023 03FD0123 00006400
	v_pk_fma_f16 v41, v41, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0E94: CC0E0029 0BFC0F29 0000C931
	v_lshl_or_b32 v37, v38, 16, v37                            // 0000009B0EA0: D6560025 04952126
	v_dot2acc_f32_f16 v80, v39, v2                             // 0000009B0EA8: 04A00527
	v_bfe_u32 v45, v36, 3, 16                                  // 0000009B0EAC: D610002D 02410724
	v_lshl_or_b32 v35, v35, 16, v42                            // 0000009B0EB4: D6560023 04A92123
	v_bfe_u32 v20, v17, 6, 16                                  // 0000009B0EBC: D6100014 02410D11
	v_pk_fma_f16 v37, v37, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0EC4: CC0E0025 0BFC0F25 0000C931
	v_dot2acc_f32_f16 v80, v41, v3                             // 0000009B0ED0: 04A00729
	.long 0xd73d0005                                           // 0000009B0ED4: D73D0005
	v_cndmask_b32_e32 v1, v90, v5, vcc_lo                      // 0000009B0ED8: 02020B5A
	v_pk_fma_f16 v35, v35, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0EDC: CC0E0023 0BFC0F23 0000C931
	s_waitcnt vmcnt(0)                                         // 0000009B0EE8: BF8903F7
	.long 0xd73d0006                                           // 0000009B0EEC: D73D0006
	v_cndmask_b32_e32 v1, v92, v7, vcc_lo                      // 0000009B0EF0: 02020F5C
	v_dot2acc_f32_f16 v79, v37, v1                             // 0000009B0EF4: 049E0325
	v_bfe_u32 v37, v31, 9, 16                                  // 0000009B0EF8: D6100025 0241131F
	v_add_nc_u32_e32 v88, 1, v88                               // 0000009B0F00: 4AB0B081
	v_bfe_u32 v7, v5, 9, 16                                    // 0000009B0F04: D6100007 02411305
	v_bfe_u32 v8, v5, 6, 16                                    // 0000009B0F0C: D6100008 02410D05
	v_dual_dot2acc_f32_f16 v79, v35, v2 :: v_dual_and_b32 v40, 0xffff, v40// 0000009B0F14: CB240523 4F2850FF 0000FFFF
	v_mul_u32_u24_e32 v47, s4, v40                             // 0000009B0F20: 165E5004
	v_mul_u32_u24_e32 v40, s5, v40                             // 0000009B0F24: 16505005
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009B0F28: BF8701B1
	v_lshl_add_u32 v40, v40, 24, v47                           // 0000009B0F2C: D6460028 04BD3128
	v_dual_dot2acc_f32_f16 v84, v51, v4 :: v_dual_add_nc_u32 v91, 32, v91// 0000009B0F34: CB200933 545AB6A0
	v_dual_mov_b32 v62, v124 :: v_dual_mov_b32 v49, v122       // 0000009B0F3C: CA10017C 3E30017A
	v_sad_u8 v40, v40, 0, 0x6400                               // 0000009B0F44: D6220028 03FD0128 00006400
	v_mov_b32_e32 v47, v104                                    // 0000009B0F50: 7E5E0368
	v_mov_b32_e32 v53, v125                                    // 0000009B0F54: 7E6A037D
	v_mov_b32_e32 v51, v105                                    // 0000009B0F58: 7E660369
	v_mov_b32_e32 v57, v129                                    // 0000009B0F5C: 7E720381
	v_lshl_or_b32 v40, v40, 16, v43                            // 0000009B0F60: D6560028 04AD2128
	v_bfe_u32 v43, v36, 9, 16                                  // 0000009B0F68: D610002B 02411324
	v_mul_u32_u24_e32 v46, s4, v43                             // 0000009B0F70: 165C5604
	v_mul_u32_u24_e32 v43, s5, v43                             // 0000009B0F74: 16565605
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B0F78: BF870001
	v_lshl_add_u32 v43, v43, 24, v46                           // 0000009B0F7C: D646002B 04B9312B
	v_mul_u32_u24_e32 v46, s4, v44                             // 0000009B0F84: 165C5804
	v_mul_u32_u24_e32 v44, s5, v44                             // 0000009B0F88: 16585805
	v_lshl_add_u32 v44, v44, 24, v46                           // 0000009B0F8C: D646002C 04B9312C
	v_pk_fma_f16 v35, v40, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B0F94: CC0E0023 0BFC0F28 0000C931
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009B0FA0: D622002B 03FD012B 00006400
	v_mul_u32_u24_e32 v46, s4, v45                             // 0000009B0FAC: 165C5A04
	v_mul_u32_u24_e32 v45, s5, v45                             // 0000009B0FB0: 165A5A05
	v_sad_u8 v42, v44, 0, 0x6400                               // 0000009B0FB4: D622002A 03FD012C 00006400
	v_lshl_add_u32 v45, v45, 24, v46                           // 0000009B0FC0: D646002D 04B9312D
	v_and_b32_e32 v38, 0xffff, v43                             // 0000009B0FC8: 364C56FF 0000FFFF
	v_dot2acc_f32_f16 v80, v35, v4                             // 0000009B0FD0: 04A00923
	v_dual_mov_b32 v46, v106 :: v_dual_mov_b32 v35, v147       // 0000009B0FD4: CA10016A 2E220193
	v_mov_b32_e32 v64, v100                                    // 0000009B0FDC: 7E800364
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B0FE0: BF870004
	v_lshl_or_b32 v38, v42, 16, v38                            // 0000009B0FE4: D6560026 0499212A
	v_sad_u8 v43, v45, 0, 0x6400                               // 0000009B0FEC: D622002B 03FD012D 00006400
	v_mov_b32_e32 v45, v119                                    // 0000009B0FF8: 7E5A0377
	v_mov_b32_e32 v55, v107                                    // 0000009B0FFC: 7E6E036B
	v_mov_b32_e32 v61, v132                                    // 0000009B1000: 7E7A0384
	v_pk_fma_f16 v32, v38, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B1004: CC0E0020 0BFC0F26 0000C931
	v_bfe_u32 v38, v31, 6, 16                                  // 0000009B1010: D6100026 02410D1F
	v_mul_u32_u24_e32 v41, s4, v38                             // 0000009B1018: 16524C04
	v_mul_u32_u24_e32 v38, s5, v38                             // 0000009B101C: 164C4C05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000009B1020: BF8700D1
	v_lshl_add_u32 v38, v38, 24, v41                           // 0000009B1024: D6460026 04A53126
	v_dot2acc_f32_f16 v79, v32, v3                             // 0000009B102C: 049E0720
	.long 0xd73d0020                                           // 0000009B1030: D73D0020
	v_cndmask_b32_e32 v1, v92, v33, vcc_lo                     // 0000009B1034: 0202435C
	v_mul_u32_u24_e32 v33, s4, v37                             // 0000009B1038: 16424A04
	v_mul_u32_u24_e32 v34, s5, v37                             // 0000009B103C: 16444A05
	v_lshl_add_u32 v33, v34, 24, v33                           // 0000009B1040: D6460021 04853122
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000009B1048: D6220026 03FD0126 00006400
	v_bfe_u32 v34, v31, 3, 16                                  // 0000009B1054: D6100022 0241071F
	v_bfe_u32 v37, v32, 9, 16                                  // 0000009B105C: D6100025 02411320
	v_mul_u32_u24_e32 v41, s4, v34                             // 0000009B1064: 16524404
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000009B1068: D6220021 03FD0121 00006400
	v_mul_u32_u24_e32 v34, s5, v34                             // 0000009B1074: 16444405
	v_lshl_add_u32 v34, v34, 24, v41                           // 0000009B1078: D6460022 04A53122
	v_mul_u32_u24_e32 v41, s4, v37                             // 0000009B1080: 16524A04
	v_mul_u32_u24_e32 v37, s5, v37                             // 0000009B1084: 164A4A05
	v_and_b32_e32 v33, 0xffff, v33                             // 0000009B1088: 364242FF 0000FFFF
	v_lshl_add_u32 v37, v37, 24, v41                           // 0000009B1090: D6460025 04A53125
	v_and_b32_e32 v31, 0xffff, v31                             // 0000009B1098: 363E3EFF 0000FFFF
	v_bfe_u32 v39, v32, 6, 16                                  // 0000009B10A0: D6100027 02410D20
	v_mul_u32_u24_e32 v41, s4, v31                             // 0000009B10A8: 16523E04
	v_lshl_or_b32 v33, v38, 16, v33                            // 0000009B10AC: D6560021 04852126
	v_mul_u32_u24_e32 v31, s5, v31                             // 0000009B10B4: 163E3E05
	v_lshl_add_u32 v31, v31, 24, v41                           // 0000009B10B8: D646001F 04A5311F
	v_mul_u32_u24_e32 v41, s4, v39                             // 0000009B10C0: 16524E04
	v_mul_u32_u24_e32 v39, s5, v39                             // 0000009B10C4: 164E4E05
	v_sad_u8 v34, v34, 0, 0x6400                               // 0000009B10C8: D6220022 03FD0122 00006400
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000009B10D4: D6220025 03FD0125 00006400
	v_lshl_add_u32 v39, v39, 24, v41                           // 0000009B10E0: D6460027 04A53127
	v_pk_fma_f16 v33, v33, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B10E8: CC0E0021 0BFC0F21 0000C931
	v_mul_u32_u24_e32 v41, s4, v29                             // 0000009B10F4: 16523A04
	v_mul_u32_u24_e32 v29, s5, v29                             // 0000009B10F8: 163A3A05
	v_lshl_add_u32 v29, v29, 24, v41                           // 0000009B10FC: D646001D 04A5311D
	v_and_b32_e32 v34, 0xffff, v34                             // 0000009B1104: 364444FF 0000FFFF
	v_sad_u8 v31, v31, 0, 0x6400                               // 0000009B110C: D622001F 03FD011F 00006400
	v_and_b32_e32 v37, 0xffff, v37                             // 0000009B1118: 364A4AFF 0000FFFF
	v_sad_u8 v38, v39, 0, 0x6400                               // 0000009B1120: D6220026 03FD0127 00006400
	v_dot2acc_f32_f16 v78, v33, v1                             // 0000009B112C: 049C0321
	v_bfe_u32 v33, v27, 3, 16                                  // 0000009B1130: D6100021 0241071B
	v_mul_u32_u24_e32 v41, s4, v33                             // 0000009B1138: 16524204
	v_mul_u32_u24_e32 v33, s5, v33                             // 0000009B113C: 16424205
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B1140: BF870001
	v_lshl_add_u32 v33, v33, 24, v41                           // 0000009B1144: D6460021 04A53121
	v_mul_u32_u24_e32 v41, s4, v30                             // 0000009B114C: 16523C04
	v_mul_u32_u24_e32 v30, s5, v30                             // 0000009B1150: 163C3C05
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000009B1154: D622001D 03FD011D 00006400
	v_lshl_add_u32 v30, v30, 24, v41                           // 0000009B1160: D646001E 04A5311E
	v_bfe_u32 v40, v32, 3, 16                                  // 0000009B1168: D6100028 02410720
	v_mul_u32_u24_e32 v39, s4, v40                             // 0000009B1170: 164E5004
	v_and_b32_e32 v32, 0xffff, v32                             // 0000009B1174: 364040FF 0000FFFF
	v_mul_u32_u24_e32 v40, s5, v40                             // 0000009B117C: 16505005
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B1180: BF870002
	v_lshl_add_u32 v39, v40, 24, v39                           // 0000009B1184: D6460027 049D3128
	v_lshl_or_b32 v31, v31, 16, v34                            // 0000009B118C: D656001F 0489211F
	v_lshl_or_b32 v34, v38, 16, v37                            // 0000009B1194: D6560022 04952126
	v_mul_u32_u24_e32 v38, s4, v32                             // 0000009B119C: 164C4004
	v_mul_u32_u24_e32 v32, s5, v32                             // 0000009B11A0: 16404005
	v_and_b32_e32 v27, 0xffff, v27                             // 0000009B11A4: 363636FF 0000FFFF
	v_lshl_add_u32 v32, v32, 24, v38                           // 0000009B11AC: D6460020 04993120
	v_bfe_u32 v38, v28, 9, 16                                  // 0000009B11B4: D6100026 0241131C
	v_mul_u32_u24_e32 v41, s4, v27                             // 0000009B11BC: 16523604
	v_mul_u32_u24_e32 v27, s5, v27                             // 0000009B11C0: 16363605
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000009B11C4: D6220021 03FD0121 00006400
	v_lshl_add_u32 v27, v27, 24, v41                           // 0000009B11D0: D646001B 04A5311B
	v_mul_u32_u24_e32 v41, s4, v38                             // 0000009B11D8: 16524C04
	v_mul_u32_u24_e32 v38, s5, v38                             // 0000009B11DC: 164C4C05
	v_lshl_add_u32 v38, v38, 24, v41                           // 0000009B11E0: D6460026 04A53126
	v_and_b32_e32 v29, 0xffff, v29                             // 0000009B11E8: 363A3AFF 0000FFFF
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000009B11F0: D622001E 03FD011E 00006400
	v_sad_u8 v37, v39, 0, 0x6400                               // 0000009B11FC: D6220025 03FD0127 00006400
	v_bfe_u32 v39, v28, 6, 16                                  // 0000009B1208: D6100027 02410D1C
	v_bfe_u32 v40, v28, 3, 16                                  // 0000009B1210: D6100028 0241071C
	v_mul_u32_u24_e32 v41, s4, v39                             // 0000009B1218: 16524E04
	v_mul_u32_u24_e32 v39, s5, v39                             // 0000009B121C: 164E4E05
	v_and_b32_e32 v33, 0xffff, v33                             // 0000009B1220: 364242FF 0000FFFF
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000009B1228: D622001B 03FD011B 00006400
	v_lshl_add_u32 v39, v39, 24, v41                           // 0000009B1234: D6460027 04A53127
	v_mul_u32_u24_e32 v41, s4, v40                             // 0000009B123C: 16525004
	v_mul_u32_u24_e32 v40, s5, v40                             // 0000009B1240: 16505005
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000009B1244: D6220026 03FD0126 00006400
	v_lshl_add_u32 v40, v40, 24, v41                           // 0000009B1250: D6460028 04A53128
	v_lshl_or_b32 v29, v30, 16, v29                            // 0000009B1258: D656001D 0475211E
	v_and_b32_e32 v28, 0xffff, v28                             // 0000009B1260: 363838FF 0000FFFF
	v_lshl_or_b32 v27, v27, 16, v33                            // 0000009B1268: D656001B 0485211B
	v_sad_u8 v33, v39, 0, 0x6400                               // 0000009B1270: D6220021 03FD0127 00006400
	v_mul_u32_u24_e32 v39, s4, v28                             // 0000009B127C: 164E3804
	v_mul_u32_u24_e32 v28, s5, v28                             // 0000009B1280: 16383805
	v_and_b32_e32 v30, 0xffff, v38                             // 0000009B1284: 363C4CFF 0000FFFF
	v_sad_u8 v38, v40, 0, 0x6400                               // 0000009B128C: D6220026 03FD0128 00006400
	v_lshl_add_u32 v28, v28, 24, v39                           // 0000009B1298: D646001C 049D311C
	v_pk_fma_f16 v29, v29, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B12A0: CC0E001D 0BFC0F1D 0000C931
	v_and_b32_e32 v36, 0xffff, v36                             // 0000009B12AC: 364848FF 0000FFFF
	v_pk_fma_f16 v31, v31, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B12B4: CC0E001F 0BFC0F1F 0000C931
	v_and_b32_e32 v37, 0xffff, v37                             // 0000009B12C0: 364A4AFF 0000FFFF
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000009B12C8: D6220020 03FD0120 00006400
	v_pk_fma_f16 v27, v27, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B12D4: CC0E001B 0BFC0F1B 0000C931
	v_lshl_or_b32 v30, v33, 16, v30                            // 0000009B12E0: D656001E 04792121
	v_and_b32_e32 v33, 0xffff, v38                             // 0000009B12E8: 36424CFF 0000FFFF
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000009B12F0: D622001C 03FD011C 00006400
	v_dot2acc_f32_f16 v77, v29, v1                             // 0000009B12FC: 049A031D
	v_pk_fma_f16 v34, v34, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B1300: CC0E0022 0BFC0F22 0000C931
	v_lshl_or_b32 v29, v32, 16, v37                            // 0000009B130C: D656001D 04952120
	v_dot2acc_f32_f16 v78, v31, v2                             // 0000009B1314: 049C051F
	v_pk_fma_f16 v30, v30, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B1318: CC0E001E 0BFC0F1E 0000C931
	v_lshl_or_b32 v28, v28, 16, v33                            // 0000009B1324: D656001C 0485211C
	v_dot2acc_f32_f16 v77, v27, v2                             // 0000009B132C: 049A051B
	v_pk_fma_f16 v27, v29, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B1330: CC0E001B 0BFC0F1D 0000C931
	v_dot2acc_f32_f16 v78, v34, v3                             // 0000009B133C: 049C0722
	v_mul_u32_u24_e32 v44, s4, v36                             // 0000009B1340: 16584804
	v_pk_fma_f16 v22, v28, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B1344: CC0E0016 0BFC0F1C 0000C931
	v_dot2acc_f32_f16 v77, v30, v3                             // 0000009B1350: 049A071E
	v_bfe_u32 v28, v21, 6, 16                                  // 0000009B1354: D610001C 02410D15
	v_dot2acc_f32_f16 v78, v27, v4                             // 0000009B135C: 049C091B
	v_bfe_u32 v27, v21, 9, 16                                  // 0000009B1360: D610001B 02411315
	v_mul_u32_u24_e32 v31, s4, v28                             // 0000009B1368: 163E3804
	v_dot2acc_f32_f16 v77, v22, v4                             // 0000009B136C: 049A0916
	.long 0xd73d0016                                           // 0000009B1370: D73D0016
	v_cndmask_b32_e32 v1, v92, v23, vcc_lo                     // 0000009B1374: 02022F5C
	v_mul_u32_u24_e32 v24, s4, v27                             // 0000009B1378: 16303604
	v_mul_u32_u24_e32 v27, s5, v27                             // 0000009B137C: 16363605
	v_lshl_add_u32 v24, v27, 24, v24                           // 0000009B1380: D6460018 0461311B
	v_bfe_u32 v23, v21, 3, 16                                  // 0000009B1388: D6100017 02410715
	v_mul_u32_u24_e32 v28, s5, v28                             // 0000009B1390: 16383805
	v_bfe_u32 v27, v22, 9, 16                                  // 0000009B1394: D610001B 02411316
	v_lshl_add_u32 v28, v28, 24, v31                           // 0000009B139C: D646001C 047D311C
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000009B13A4: D6220018 03FD0118 00006400
	v_mul_u32_u24_e32 v31, s4, v23                             // 0000009B13B0: 163E2E04
	v_mul_u32_u24_e32 v23, s5, v23                             // 0000009B13B4: 162E2E05
	v_lshl_add_u32 v23, v23, 24, v31                           // 0000009B13B8: D6460017 047D3117
	v_mul_u32_u24_e32 v31, s4, v27                             // 0000009B13C0: 163E3604
	v_mul_u32_u24_e32 v27, s5, v27                             // 0000009B13C4: 16363605
	v_lshl_add_u32 v27, v27, 24, v31                           // 0000009B13C8: D646001B 047D311B
	v_and_b32_e32 v21, 0xffff, v21                             // 0000009B13D0: 362A2AFF 0000FFFF
	v_bfe_u32 v29, v22, 6, 16                                  // 0000009B13D8: D610001D 02410D16
	v_mul_u32_u24_e32 v31, s4, v21                             // 0000009B13E0: 163E2A04
	v_mul_u32_u24_e32 v21, s5, v21                             // 0000009B13E4: 162A2A05
	v_mul_u32_u24_e32 v36, s5, v36                             // 0000009B13E8: 16484805
	v_bfe_u32 v30, v22, 3, 16                                  // 0000009B13EC: D610001E 02410716
	v_and_b32_e32 v24, 0xffff, v24                             // 0000009B13F4: 363030FF 0000FFFF
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000009B13FC: D622001C 03FD011C 00006400
	v_lshl_add_u32 v21, v21, 24, v31                           // 0000009B1408: D6460015 047D3115
	v_mul_u32_u24_e32 v31, s4, v29                             // 0000009B1410: 163E3A04
	v_mul_u32_u24_e32 v29, s5, v29                             // 0000009B1414: 163A3A05
	v_lshl_add_u32 v36, v36, 24, v44                           // 0000009B1418: D6460024 04B13124
	v_lshl_add_u32 v29, v29, 24, v31                           // 0000009B1420: D646001D 047D311D
	v_mul_u32_u24_e32 v31, s4, v30                             // 0000009B1428: 163E3C04
	v_mul_u32_u24_e32 v30, s5, v30                             // 0000009B142C: 163C3C05
	v_sad_u8 v23, v23, 0, 0x6400                               // 0000009B1430: D6220017 03FD0117 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000009B143C: D622001B 03FD011B 00006400
	v_lshl_add_u32 v30, v30, 24, v31                           // 0000009B1448: D646001E 047D311E
	v_lshl_or_b32 v24, v28, 16, v24                            // 0000009B1450: D6560018 0461211C
	v_and_b32_e32 v42, 0xffff, v43                             // 0000009B1458: 365456FF 0000FFFF
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000009B1460: D6220024 03FD0124 00006400
	v_dual_mov_b32 v34, v151 :: v_dual_and_b32 v23, 0xffff, v23// 0000009B146C: CA240197 22162EFF 0000FFFF
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000009B1478: D6220015 03FD0115 00006400
	v_dual_mov_b32 v32, v116 :: v_dual_and_b32 v27, 0xffff, v27// 0000009B1484: CA240174 201A36FF 0000FFFF
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000009B1490: D622001D 03FD011D 00006400
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000009B149C: D622001E 03FD011E 00006400
	v_and_b32_e32 v22, 0xffff, v22                             // 0000009B14A8: 362C2CFF 0000FFFF
	v_mul_u32_u24_e32 v31, s4, v22                             // 0000009B14B0: 163E2C04
	v_mul_u32_u24_e32 v22, s5, v22                             // 0000009B14B4: 162C2C05
	v_pk_fma_f16 v24, v24, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B14B8: CC0E0018 0BFC0F18 0000C931
	v_lshl_or_b32 v36, v36, 16, v42                            // 0000009B14C4: D6560024 04A92124
	v_lshl_add_u32 v22, v22, 24, v31                           // 0000009B14CC: D6460016 047D3116
	v_lshl_or_b32 v21, v21, 16, v23                            // 0000009B14D4: D6560015 045D2115
	v_lshl_or_b32 v23, v29, 16, v27                            // 0000009B14DC: D6560017 046D211D
	v_dual_mov_b32 v38, v153 :: v_dual_and_b32 v27, 0xffff, v30// 0000009B14E4: CA240199 261A3CFF 0000FFFF
	v_mul_u32_u24_e32 v30, s4, v19                             // 0000009B14F0: 163C2604
	v_mul_u32_u24_e32 v19, s5, v19                             // 0000009B14F4: 16262605
	v_lshl_add_u32 v19, v19, 24, v30                           // 0000009B14F8: D6460013 04793113
	v_dot2acc_f32_f16 v76, v24, v1                             // 0000009B1500: 04980318
	v_bfe_u32 v24, v17, 3, 16                                  // 0000009B1504: D6100018 02410711
	v_pk_fma_f16 v36, v36, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B150C: CC0E0024 0BFC0F24 0000C931
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000009B1518: D6220016 03FD0116 00006400
	v_mul_u32_u24_e32 v30, s4, v24                             // 0000009B1524: 163C3004
	v_mul_u32_u24_e32 v24, s5, v24                             // 0000009B1528: 16303005
	v_lshl_add_u32 v24, v24, 24, v30                           // 0000009B152C: D6460018 04793118
	v_mul_u32_u24_e32 v30, s4, v20                             // 0000009B1534: 163C2804
	v_mul_u32_u24_e32 v20, s5, v20                             // 0000009B1538: 16282805
	v_sad_u8 v19, v19, 0, 0x6400                               // 0000009B153C: D6220013 03FD0113 00006400
	v_lshl_add_u32 v20, v20, 24, v30                           // 0000009B1548: D6460014 04793114
	v_and_b32_e32 v17, 0xffff, v17                             // 0000009B1550: 362222FF 0000FFFF
	v_dot2acc_f32_f16 v79, v36, v4                             // 0000009B1558: 049E0924
	v_lshl_or_b32 v22, v22, 16, v27                            // 0000009B155C: D6560016 046D2116
	v_bfe_u32 v27, v18, 9, 16                                  // 0000009B1564: D610001B 02411312
	v_mov_b32_e32 v36, v117                                    // 0000009B156C: 7E480375
	v_mul_u32_u24_e32 v30, s4, v17                             // 0000009B1570: 163C2204
	v_mul_u32_u24_e32 v17, s5, v17                             // 0000009B1574: 16222205
	v_lshl_add_u32 v17, v17, 24, v30                           // 0000009B1578: D6460011 04793111
	v_mul_u32_u24_e32 v30, s4, v27                             // 0000009B1580: 163C3604
	v_mul_u32_u24_e32 v27, s5, v27                             // 0000009B1584: 16363605
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000009B1588: D6220018 03FD0118 00006400
	v_lshl_add_u32 v27, v27, 24, v30                           // 0000009B1594: D646001B 0479311B
	v_dual_mov_b32 v42, v155 :: v_dual_and_b32 v19, 0xffff, v19// 0000009B159C: CA24019B 2A1226FF 0000FFFF
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000009B15A8: D6220014 03FD0114 00006400
	v_bfe_u32 v28, v18, 6, 16                                  // 0000009B15B4: D610001C 02410D12
	v_mul_u32_u24_e32 v30, s4, v28                             // 0000009B15BC: 163C3804
	v_mul_u32_u24_e32 v28, s5, v28                             // 0000009B15C0: 16383805
	v_and_b32_e32 v24, 0xffff, v24                             // 0000009B15C4: 363030FF 0000FFFF
	v_sad_u8 v17, v17, 0, 0x6400                               // 0000009B15CC: D6220011 03FD0111 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000009B15D8: D622001B 03FD011B 00006400
	v_lshl_add_u32 v28, v28, 24, v30                           // 0000009B15E4: D646001C 0479311C
	v_lshl_or_b32 v19, v20, 16, v19                            // 0000009B15EC: D6560013 044D2114
	v_pk_fma_f16 v21, v21, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B15F4: CC0E0015 0BFC0F15 0000C931
	v_lshl_or_b32 v17, v17, 16, v24                            // 0000009B1600: D6560011 04612111
	v_and_b32_e32 v20, 0xffff, v27                             // 0000009B1608: 362836FF 0000FFFF
	v_sad_u8 v24, v28, 0, 0x6400                               // 0000009B1610: D6220018 03FD011C 00006400
	v_pk_fma_f16 v19, v19, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B161C: CC0E0013 0BFC0F13 0000C931
	v_pk_fma_f16 v23, v23, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B1628: CC0E0017 0BFC0F17 0000C931
	v_pk_fma_f16 v17, v17, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B1634: CC0E0011 0BFC0F11 0000C931
	v_dot2acc_f32_f16 v76, v21, v2                             // 0000009B1640: 04980515
	v_lshl_or_b32 v20, v24, 16, v20                            // 0000009B1644: D6560014 04512118
	v_dot2acc_f32_f16 v75, v19, v1                             // 0000009B164C: 04960313
	v_bfe_u32 v19, v11, 9, 16                                  // 0000009B1650: D6100013 0241130B
	v_mov_b32_e32 v40, v118                                    // 0000009B1658: 7E500376
	v_dot2acc_f32_f16 v76, v23, v3                             // 0000009B165C: 04980717
	v_pk_fma_f16 v12, v20, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B1660: CC0E000C 0BFC0F14 0000C931
	v_dot2acc_f32_f16 v75, v17, v2                             // 0000009B166C: 04960511
	v_bfe_u32 v20, v11, 6, 16                                  // 0000009B1670: D6100014 02410D0B
	v_mul_u32_u24_e32 v23, s4, v20                             // 0000009B1678: 162E2804
	v_mul_u32_u24_e32 v20, s5, v20                             // 0000009B167C: 16282805
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000009B1680: BF8700D1
	v_lshl_add_u32 v20, v20, 24, v23                           // 0000009B1684: D6460014 045D3114
	v_dot2acc_f32_f16 v75, v12, v3                             // 0000009B168C: 0496070C
	.long 0xd73d000c                                           // 0000009B1690: D73D000C
	v_cndmask_b32_e32 v1, v92, v13, vcc_lo                     // 0000009B1694: 02021B5C
	v_mul_u32_u24_e32 v13, s4, v19                             // 0000009B1698: 161A2604
	v_mul_u32_u24_e32 v14, s5, v19                             // 0000009B169C: 161C2605
	v_lshl_add_u32 v13, v14, 24, v13                           // 0000009B16A0: D646000D 0435310E
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000009B16A8: D6220014 03FD0114 00006400
	v_bfe_u32 v14, v11, 3, 16                                  // 0000009B16B4: D610000E 0241070B
	v_bfe_u32 v19, v12, 9, 16                                  // 0000009B16BC: D6100013 0241130C
	v_mul_u32_u24_e32 v23, s4, v14                             // 0000009B16C4: 162E1C04
	v_sad_u8 v13, v13, 0, 0x6400                               // 0000009B16C8: D622000D 03FD010D 00006400
	v_mul_u32_u24_e32 v14, s5, v14                             // 0000009B16D4: 161C1C05
	v_and_b32_e32 v11, 0xffff, v11                             // 0000009B16D8: 361616FF 0000FFFF
	v_lshl_add_u32 v14, v14, 24, v23                           // 0000009B16E0: D646000E 045D310E
	v_mul_u32_u24_e32 v23, s4, v19                             // 0000009B16E8: 162E2604
	v_and_b32_e32 v13, 0xffff, v13                             // 0000009B16EC: 361A1AFF 0000FFFF
	v_mul_u32_u24_e32 v19, s5, v19                             // 0000009B16F4: 16262605
	v_bfe_u32 v21, v12, 6, 16                                  // 0000009B16F8: D6100015 02410D0C
	v_lshl_add_u32 v19, v19, 24, v23                           // 0000009B1700: D6460013 045D3113
	v_mul_u32_u24_e32 v23, s4, v11                             // 0000009B1708: 162E1604
	v_lshl_or_b32 v13, v20, 16, v13                            // 0000009B170C: D656000D 04352114
	v_mul_u32_u24_e32 v11, s5, v11                             // 0000009B1714: 16161605
	v_lshl_add_u32 v11, v11, 24, v23                           // 0000009B1718: D646000B 045D310B
	v_mul_u32_u24_e32 v23, s4, v21                             // 0000009B1720: 162E2A04
	v_mul_u32_u24_e32 v21, s5, v21                             // 0000009B1724: 162A2A05
	v_pk_fma_f16 v13, v13, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B1728: CC0E000D 0BFC0F0D 0000C931
	v_lshl_add_u32 v21, v21, 24, v23                           // 0000009B1734: D6460015 045D3115
	v_mul_u32_u24_e32 v23, s4, v7                              // 0000009B173C: 162E0E04
	v_mul_u32_u24_e32 v7, s5, v7                               // 0000009B1740: 160E0E05
	v_lshl_add_u32 v7, v7, 24, v23                             // 0000009B1744: D6460007 045D3107
	v_dot2acc_f32_f16 v74, v13, v1                             // 0000009B174C: 0494030D
	v_bfe_u32 v13, v5, 3, 16                                   // 0000009B1750: D610000D 02410705
	v_mul_u32_u24_e32 v23, s4, v13                             // 0000009B1758: 162E1A04
	v_mul_u32_u24_e32 v13, s5, v13                             // 0000009B175C: 161A1A05
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B1760: BF870001
	v_lshl_add_u32 v13, v13, 24, v23                           // 0000009B1764: D646000D 045D310D
	v_mul_u32_u24_e32 v23, s4, v8                              // 0000009B176C: 162E1004
	v_mul_u32_u24_e32 v8, s5, v8                               // 0000009B1770: 16101005
	v_sad_u8 v7, v7, 0, 0x6400                                 // 0000009B1774: D6220007 03FD0107 00006400
	v_lshl_add_u32 v8, v8, 24, v23                             // 0000009B1780: D6460008 045D3108
	v_sad_u8 v14, v14, 0, 0x6400                               // 0000009B1788: D622000E 03FD010E 00006400
	v_sad_u8 v19, v19, 0, 0x6400                               // 0000009B1794: D6220013 03FD0113 00006400
	v_dual_mov_b32 v48, v96 :: v_dual_and_b32 v5, 0xffff, v5   // 0000009B17A0: CA240160 30040AFF 0000FFFF
	v_mul_u32_u24_e32 v23, s4, v5                              // 0000009B17AC: 162E0A04
	v_mul_u32_u24_e32 v5, s5, v5                               // 0000009B17B0: 160A0A05
	v_sad_u8 v13, v13, 0, 0x6400                               // 0000009B17B4: D622000D 03FD010D 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B17C0: BF870002
	v_lshl_add_u32 v5, v5, 24, v23                             // 0000009B17C4: D6460005 045D3105
	v_dual_mov_b32 v54, v110 :: v_dual_and_b32 v7, 0xffff, v7  // 0000009B17CC: CA24016E 36060EFF 0000FFFF
	v_sad_u8 v8, v8, 0, 0x6400                                 // 0000009B17D8: D6220008 03FD0108 00006400
	v_pk_fma_f16 v17, v22, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B17E4: CC0E0011 0BFC0F16 0000C931
	v_and_b32_e32 v14, 0xffff, v14                             // 0000009B17F0: 361C1CFF 0000FFFF
	v_sad_u8 v11, v11, 0, 0x6400                               // 0000009B17F8: D622000B 03FD010B 00006400
	v_dual_mov_b32 v44, v95 :: v_dual_and_b32 v19, 0xffff, v19 // 0000009B1804: CA24015F 2C1226FF 0000FFFF
	v_sad_u8 v20, v21, 0, 0x6400                               // 0000009B1810: D6220014 03FD0115 00006400
	v_bfe_u32 v22, v12, 3, 16                                  // 0000009B181C: D6100016 0241070C
	v_and_b32_e32 v12, 0xffff, v12                             // 0000009B1824: 361818FF 0000FFFF
	v_dual_mov_b32 v52, v97 :: v_dual_and_b32 v13, 0xffff, v13 // 0000009B182C: CA240161 340C1AFF 0000FFFF
	v_sad_u8 v5, v5, 0, 0x6400                                 // 0000009B1838: D6220005 03FD0105 00006400
	v_lshl_or_b32 v7, v8, 16, v7                               // 0000009B1844: D6560007 041D2108
	v_mul_u32_u24_e32 v21, s4, v22                             // 0000009B184C: 162A2C04
	v_dot2acc_f32_f16 v76, v17, v4                             // 0000009B1850: 04980911
	v_mov_b32_e32 v17, v133                                    // 0000009B1854: 7E220385
	v_lshl_or_b32 v11, v11, 16, v14                            // 0000009B1858: D656000B 0439210B
	v_lshl_or_b32 v14, v20, 16, v19                            // 0000009B1860: D656000E 044D2114
	v_mul_u32_u24_e32 v20, s4, v12                             // 0000009B1868: 16281804
	v_mul_u32_u24_e32 v12, s5, v12                             // 0000009B186C: 16181805
	v_mul_u32_u24_e32 v22, s5, v22                             // 0000009B1870: 162C2C05
	v_lshl_add_u32 v21, v22, 24, v21                           // 0000009B1874: D6460015 04553116
	v_lshl_add_u32 v12, v12, 24, v20                           // 0000009B187C: D646000C 0451310C
	v_bfe_u32 v20, v6, 9, 16                                   // 0000009B1884: D6100014 02411306
	v_mul_u32_u24_e32 v23, s4, v20                             // 0000009B188C: 162E2804
	v_mul_u32_u24_e32 v20, s5, v20                             // 0000009B1890: 16282805
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B1894: BF870001
	v_lshl_add_u32 v20, v20, 24, v23                           // 0000009B1898: D6460014 045D3114
	v_lshl_or_b32 v5, v5, 16, v13                              // 0000009B18A0: D6560005 04352105
	v_pk_fma_f16 v7, v7, s7, 0xc931 op_sel_hi:[1,0,0]          // 0000009B18A8: CC0E0007 0BFC0F07 0000C931
	v_sad_u8 v19, v21, 0, 0x6400                               // 0000009B18B4: D6220013 03FD0115 00006400
	v_bfe_u32 v21, v6, 6, 16                                   // 0000009B18C0: D6100015 02410D06
	v_mul_u32_u24_e32 v23, s4, v21                             // 0000009B18C8: 162E2A04
	v_mul_u32_u24_e32 v21, s5, v21                             // 0000009B18CC: 162A2A05
	v_bfe_u32 v29, v18, 3, 16                                  // 0000009B18D0: D610001D 02410712
	v_bfe_u32 v22, v6, 3, 16                                   // 0000009B18D8: D6100016 02410706
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000009B18E0: D6220014 03FD0114 00006400
	v_lshl_add_u32 v21, v21, 24, v23                           // 0000009B18EC: D6460015 045D3115
	v_mul_u32_u24_e32 v30, s4, v29                             // 0000009B18F4: 163C3A04
	v_mul_u32_u24_e32 v29, s5, v29                             // 0000009B18F8: 163A3A05
	v_mul_u32_u24_e32 v23, s4, v22                             // 0000009B18FC: 162E2C04
	v_mul_u32_u24_e32 v22, s5, v22                             // 0000009B1900: 162C2C05
	v_pk_fma_f16 v5, v5, s7, 0xc931 op_sel_hi:[1,0,0]          // 0000009B1904: CC0E0005 0BFC0F05 0000C931
	v_dot2acc_f32_f16 v10, v7, v1                              // 0000009B1910: 04140307
	v_lshl_add_u32 v29, v29, 24, v30                           // 0000009B1914: D646001D 0479311D
	v_lshl_add_u32 v22, v22, 24, v23                           // 0000009B191C: D6460016 045D3116
	v_and_b32_e32 v18, 0xffff, v18                             // 0000009B1924: 362424FF 0000FFFF
	v_and_b32_e32 v6, 0xffff, v6                               // 0000009B192C: 360C0CFF 0000FFFF
	v_and_b32_e32 v8, 0xffff, v20                              // 0000009B1934: 361028FF 0000FFFF
	v_sad_u8 v13, v21, 0, 0x6400                               // 0000009B193C: D622000D 03FD0115 00006400
	v_mul_u32_u24_e32 v21, s4, v6                              // 0000009B1948: 162A0C04
	v_mul_u32_u24_e32 v6, s5, v6                               // 0000009B194C: 160C0C05
	v_dual_dot2acc_f32_f16 v10, v5, v2 :: v_dual_mov_b32 v5, v126// 0000009B1950: CB100505 0A04017E
	v_mul_u32_u24_e32 v28, s4, v18                             // 0000009B1958: 16382404
	v_mul_u32_u24_e32 v18, s5, v18                             // 0000009B195C: 16242405
	v_sad_u8 v27, v29, 0, 0x6400                               // 0000009B1960: D622001B 03FD011D 00006400
	v_lshl_add_u32 v18, v18, 24, v28                           // 0000009B196C: D6460012 04713112
	v_sad_u8 v20, v22, 0, 0x6400                               // 0000009B1974: D6220014 03FD0116 00006400
	v_lshl_add_u32 v6, v6, 24, v21                             // 0000009B1980: D6460006 04553106
	v_pk_fma_f16 v11, v11, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B1988: CC0E000B 0BFC0F0B 0000C931
	v_mov_b32_e32 v29, v154                                    // 0000009B1994: 7E3A039A
	v_lshl_or_b32 v8, v13, 16, v8                              // 0000009B1998: D6560008 0421210D
	v_and_b32_e32 v24, 0xffff, v27                             // 0000009B19A0: 363036FF 0000FFFF
	v_sad_u8 v18, v18, 0, 0x6400                               // 0000009B19A8: D6220012 03FD0112 00006400
	v_dual_mov_b32 v50, v108 :: v_dual_and_b32 v19, 0xffff, v19// 0000009B19B4: CA24016C 321226FF 0000FFFF
	v_sad_u8 v12, v12, 0, 0x6400                               // 0000009B19C0: D622000C 03FD010C 00006400
	v_dual_mov_b32 v58, v121 :: v_dual_and_b32 v13, 0xffff, v20// 0000009B19CC: CA240179 3A0C28FF 0000FFFF
	v_sad_u8 v6, v6, 0, 0x6400                                 // 0000009B19D8: D6220006 03FD0106 00006400
	v_pk_fma_f16 v14, v14, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B19E4: CC0E000E 0BFC0F0E 0000C931
	v_dot2acc_f32_f16 v74, v11, v2                             // 0000009B19F0: 0494050B
	v_pk_fma_f16 v7, v8, s7, 0xc931 op_sel_hi:[1,0,0]          // 0000009B19F4: CC0E0007 0BFC0F08 0000C931
	v_lshl_or_b32 v1, v12, 16, v19                             // 0000009B1A00: D6560001 044D210C
	v_lshl_or_b32 v6, v6, 16, v13                              // 0000009B1A08: D6560006 04352106
	v_mov_b32_e32 v19, v149                                    // 0000009B1A10: 7E260395
	v_lshl_or_b32 v18, v18, 16, v24                            // 0000009B1A14: D6560012 04612112
	v_dot2acc_f32_f16 v74, v14, v3                             // 0000009B1A1C: 0494070E
	v_dual_dot2acc_f32_f16 v10, v7, v3 :: v_dual_mov_b32 v27, v140// 0000009B1A20: CB100707 0A1A018C
	v_dual_mov_b32 v56, v98 :: v_dual_add_nc_u32 v3, v89, v88  // 0000009B1A28: CA200162 3802B159
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009B1A30: BF870234
	v_pk_fma_f16 v18, v18, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009B1A34: CC0E0012 0BFC0F12 0000C931
	v_pk_fma_f16 v1, v1, s7, 0xc931 op_sel_hi:[1,0,0]          // 0000009B1A40: CC0E0001 0BFC0F01 0000C931
	v_pk_fma_f16 v2, v6, s7, 0xc931 op_sel_hi:[1,0,0]          // 0000009B1A4C: CC0E0002 0BFC0F06 0000C931
	v_cmp_eq_u32_e32 vcc_lo, 21, v3                            // 0000009B1A58: 7C940695
	v_mov_b32_e32 v7, v142                                     // 0000009B1A5C: 7E0E038E
	v_dot2acc_f32_f16 v75, v18, v4                             // 0000009B1A60: 04960912
	v_dot2acc_f32_f16 v74, v1, v4                              // 0000009B1A64: 04940901
	v_dot2acc_f32_f16 v10, v2, v4                              // 0000009B1A68: 04140902
	v_mov_b32_e32 v8, v134                                     // 0000009B1A6C: 7E100386
	v_dual_mov_b32 v6, v111 :: v_dual_mov_b32 v13, v146        // 0000009B1A70: CA10016F 060C0192
	v_mov_b32_e32 v14, v138                                    // 0000009B1A78: 7E1C038A
	v_dual_mov_b32 v11, v130 :: v_dual_mov_b32 v12, v112       // 0000009B1A7C: CA100182 0B0C0170
	v_mov_b32_e32 v20, v141                                    // 0000009B1A84: 7E28038D
	v_dual_mov_b32 v18, v113 :: v_dual_mov_b32 v23, v152       // 0000009B1A88: CA100171 12160198
	v_mov_b32_e32 v24, v145                                    // 0000009B1A90: 7E300391
	v_dual_mov_b32 v21, v137 :: v_dual_mov_b32 v22, v114       // 0000009B1A94: CA100189 15160172
	v_mov_b32_e32 v30, v148                                    // 0000009B1A9C: 7E3C0394
	v_dual_mov_b32 v28, v115 :: v_dual_mov_b32 v33, v156       // 0000009B1AA0: CA100173 1C20019C
	v_dual_mov_b32 v60, v99 :: v_dual_mov_b32 v31, v144        // 0000009B1AA8: CA100163 3C1E0190
	v_dual_mov_b32 v70, v131 :: v_dual_mov_b32 v37, v157       // 0000009B1AB0: CA100183 4624019D
	v_dual_mov_b32 v66, v128 :: v_dual_mov_b32 v41, v158       // 0000009B1AB8: CA100180 4228019E
	v_dual_mov_b32 v68, v101 :: v_dual_mov_b32 v39, v150       // 0000009B1AC0: CA100165 44260196
	v_mov_b32_e32 v4, v135                                     // 0000009B1AC8: 7E080387
	v_mov_b32_e32 v43, v103                                    // 0000009B1ACC: 7E560367
	v_mov_b32_e32 v59, v109                                    // 0000009B1AD0: 7E76036D
	v_mov_b32_e32 v65, v136                                    // 0000009B1AD4: 7E820388
	v_mov_b32_e32 v63, v120                                    // 0000009B1AD8: 7E7E0378
	v_mov_b32_e32 v69, v139                                    // 0000009B1ADC: 7E8A038B
	v_mov_b32_e32 v67, v123                                    // 0000009B1AE0: 7E86037B
	v_mov_b32_e32 v3, v143                                     // 0000009B1AE4: 7E06038F
	v_dual_mov_b32 v1, v127 :: v_dual_mov_b32 v2, v102         // 0000009B1AE8: CA10017F 01020166
	s_or_b32 s0, vcc_lo, s0                                    // 0000009B1AF0: 8C00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B1AF4: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 0000009B1AF8: 917E007E
	s_cbranch_execz 157                                        // 0000009B1AFC: BFA5009D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2574>
	s_mov_b32 s9, exec_lo                                      // 0000009B1B00: BE89007E
	.long 0xd4c9007e                                           // 0000009B1B04: D4C9007E
	v_cndmask_b32_e32 v1, v88, v73, vcc_lo                     // 0000009B1B08: 02029358
	s_cbranch_execz 63685                                      // 0000009B1B0C: BFA5F8C5 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x624>
	v_mad_u64_u32 v[95:96], null, 0x600, v88, s[2:3]           // 0000009B1B10: D6FE7C5F 000AB0FF 00000600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B1B1C: BF870091
	.long 0xd7006a85                                           // 0000009B1B20: D7006A85
	v_cndmask_b32_e32 v1, v95, v15, vcc_lo                     // 0000009B1B24: 02021F5F
	v_add_co_ci_u32_e64 v134, null, v96, v16, vcc_lo           // 0000009B1B28: D5207C86 01AA2160
	.long 0xd7006a8d                                           // 0000009B1B30: D7006A8D
	v_cndmask_b32_e32 v1, v95, v93, vcc_lo                     // 0000009B1B34: 0202BB5F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009B1B38: BF8700A1
	v_add_co_ci_u32_e64 v142, null, 0, v96, vcc_lo             // 0000009B1B3C: D5207C8E 01AAC080
	.long 0xd7006a9c                                           // 0000009B1B44: D7006A9C
	v_cndmask_b32_e32 v1, v95, v25, vcc_lo                     // 0000009B1B48: 0202335F
	v_add_co_ci_u32_e64 v157, null, v96, v26, vcc_lo           // 0000009B1B4C: D5207C9D 01AA3560
	.long 0xd7006a9f                                           // 0000009B1B54: D7006A9F
	v_cndmask_b32_e32 v1, v95, v94, vcc_lo                     // 0000009B1B58: 0202BD5F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B1B5C: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v96, vcc_lo             // 0000009B1B60: D5207CA0 01AAC080
	s_clause 0x1f                                              // 0000009B1B68: BF85001F
	global_load_b32 v102, v[133:134], off                      // 0000009B1B6C: DC520000 667C0085
	global_load_b32 v101, v[133:134], off offset:96            // 0000009B1B74: DC520060 657C0085
	global_load_b32 v100, v[133:134], off offset:192           // 0000009B1B7C: DC5200C0 647C0085
	global_load_b32 v99, v[133:134], off offset:288            // 0000009B1B84: DC520120 637C0085
	global_load_b32 v98, v[133:134], off offset:384            // 0000009B1B8C: DC520180 627C0085
	global_load_b32 v97, v[133:134], off offset:480            // 0000009B1B94: DC5201E0 617C0085
	global_load_b32 v96, v[133:134], off offset:576            // 0000009B1B9C: DC520240 607C0085
	global_load_b32 v95, v[133:134], off offset:672            // 0000009B1BA4: DC5202A0 5F7C0085
	global_load_b32 v127, v[141:142], off                      // 0000009B1BAC: DC520000 7F7C008D
	global_load_b32 v123, v[141:142], off offset:96            // 0000009B1BB4: DC520060 7B7C008D
	global_load_b32 v120, v[141:142], off offset:192           // 0000009B1BBC: DC5200C0 787C008D
	global_load_b32 v109, v[141:142], off offset:288           // 0000009B1BC4: DC520120 6D7C008D
	global_load_b32 v107, v[141:142], off offset:384           // 0000009B1BCC: DC520180 6B7C008D
	global_load_b32 v105, v[141:142], off offset:480           // 0000009B1BD4: DC5201E0 697C008D
	global_load_b32 v104, v[141:142], off offset:576           // 0000009B1BDC: DC520240 687C008D
	global_load_b32 v103, v[141:142], off offset:672           // 0000009B1BE4: DC5202A0 677C008D
	global_load_b32 v135, v[156:157], off                      // 0000009B1BEC: DC520000 877C009C
	global_load_b32 v131, v[156:157], off offset:96            // 0000009B1BF4: DC520060 837C009C
	global_load_b32 v128, v[156:157], off offset:192           // 0000009B1BFC: DC5200C0 807C009C
	global_load_b32 v124, v[156:157], off offset:288           // 0000009B1C04: DC520120 7C7C009C
	global_load_b32 v121, v[156:157], off offset:384           // 0000009B1C0C: DC520180 797C009C
	global_load_b32 v110, v[156:157], off offset:480           // 0000009B1C14: DC5201E0 6E7C009C
	global_load_b32 v108, v[156:157], off offset:576           // 0000009B1C1C: DC520240 6C7C009C
	global_load_b32 v106, v[156:157], off offset:672           // 0000009B1C24: DC5202A0 6A7C009C
	global_load_b32 v143, v[159:160], off                      // 0000009B1C2C: DC520000 8F7C009F
	global_load_b32 v139, v[159:160], off offset:96            // 0000009B1C34: DC520060 8B7C009F
	global_load_b32 v136, v[159:160], off offset:192           // 0000009B1C3C: DC5200C0 887C009F
	global_load_b32 v132, v[159:160], off offset:288           // 0000009B1C44: DC520120 847C009F
	global_load_b32 v129, v[159:160], off offset:384           // 0000009B1C4C: DC520180 817C009F
	global_load_b32 v125, v[159:160], off offset:480           // 0000009B1C54: DC5201E0 7D7C009F
	global_load_b32 v122, v[159:160], off offset:576           // 0000009B1C5C: DC520240 7A7C009F
	global_load_b32 v119, v[159:160], off offset:672           // 0000009B1C64: DC5202A0 777C009F
	s_clause 0x1f                                              // 0000009B1C6C: BF85001F
	global_load_b32 v118, v[133:134], off offset:768           // 0000009B1C70: DC520300 767C0085
	global_load_b32 v117, v[133:134], off offset:864           // 0000009B1C78: DC520360 757C0085
	global_load_b32 v116, v[133:134], off offset:960           // 0000009B1C80: DC5203C0 747C0085
	global_load_b32 v115, v[133:134], off offset:1056          // 0000009B1C88: DC520420 737C0085
	global_load_b32 v114, v[133:134], off offset:1152          // 0000009B1C90: DC520480 727C0085
	global_load_b32 v113, v[133:134], off offset:1248          // 0000009B1C98: DC5204E0 717C0085
	global_load_b32 v112, v[133:134], off offset:1344          // 0000009B1CA0: DC520540 707C0085
	global_load_b32 v111, v[133:134], off offset:1440          // 0000009B1CA8: DC5205A0 6F7C0085
	global_load_b32 v150, v[141:142], off offset:768           // 0000009B1CB0: DC520300 967C008D
	global_load_b32 v147, v[141:142], off offset:864           // 0000009B1CB8: DC520360 937C008D
	global_load_b32 v144, v[141:142], off offset:960           // 0000009B1CC0: DC5203C0 907C008D
	global_load_b32 v140, v[141:142], off offset:1056          // 0000009B1CC8: DC520420 8C7C008D
	global_load_b32 v137, v[141:142], off offset:1152          // 0000009B1CD0: DC520480 897C008D
	global_load_b32 v133, v[141:142], off offset:1248          // 0000009B1CD8: DC5204E0 857C008D
	global_load_b32 v130, v[141:142], off offset:1344          // 0000009B1CE0: DC520540 827C008D
	global_load_b32 v126, v[141:142], off offset:1440          // 0000009B1CE8: DC5205A0 7E7C008D
	global_load_b32 v155, v[156:157], off offset:768           // 0000009B1CF0: DC520300 9B7C009C
	global_load_b32 v153, v[156:157], off offset:864           // 0000009B1CF8: DC520360 997C009C
	global_load_b32 v151, v[156:157], off offset:960           // 0000009B1D00: DC5203C0 977C009C
	global_load_b32 v148, v[156:157], off offset:1056          // 0000009B1D08: DC520420 947C009C
	global_load_b32 v145, v[156:157], off offset:1152          // 0000009B1D10: DC520480 917C009C
	global_load_b32 v141, v[156:157], off offset:1248          // 0000009B1D18: DC5204E0 8D7C009C
	global_load_b32 v138, v[156:157], off offset:1344          // 0000009B1D20: DC520540 8A7C009C
	global_load_b32 v134, v[156:157], off offset:1440          // 0000009B1D28: DC5205A0 867C009C
	global_load_b32 v158, v[159:160], off offset:768           // 0000009B1D30: DC520300 9E7C009F
	global_load_b32 v157, v[159:160], off offset:864           // 0000009B1D38: DC520360 9D7C009F
	global_load_b32 v156, v[159:160], off offset:960           // 0000009B1D40: DC5203C0 9C7C009F
	global_load_b32 v154, v[159:160], off offset:1056          // 0000009B1D48: DC520420 9A7C009F
	global_load_b32 v152, v[159:160], off offset:1152          // 0000009B1D50: DC520480 987C009F
	global_load_b32 v149, v[159:160], off offset:1248          // 0000009B1D58: DC5204E0 957C009F
	global_load_b32 v146, v[159:160], off offset:1344          // 0000009B1D60: DC520540 927C009F
	global_load_b32 v142, v[159:160], off offset:1440          // 0000009B1D68: DC5205A0 8E7C009F
	s_branch 63532                                             // 0000009B1D70: BFA0F82C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x624>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000009B1D74: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B1D78: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009B1D7C: 8C7E017E
	s_waitcnt vmcnt(55)                                        // 0000009B1D80: BF89DFF7
	v_dual_mov_b32 v1, v9 :: v_dual_mov_b32 v2, v87            // 0000009B1D84: CA100109 01020157
	s_waitcnt vmcnt(39)                                        // 0000009B1D8C: BF899FF7
	v_dual_mov_b32 v3, v86 :: v_dual_mov_b32 v4, v85           // 0000009B1D90: CA100156 03040155
	s_waitcnt vmcnt(0)                                         // 0000009B1D98: BF8903F7
	v_dual_mov_b32 v7, v84 :: v_dual_mov_b32 v14, v82          // 0000009B1D9C: CA100154 070E0152
	v_dual_mov_b32 v11, v83 :: v_dual_mov_b32 v6, v80          // 0000009B1DA4: CA100153 0B060150
	v_dual_mov_b32 v5, v81 :: v_dual_mov_b32 v8, v79           // 0000009B1DAC: CA100151 0508014F
	v_dual_mov_b32 v12, v78 :: v_dual_mov_b32 v13, v77         // 0000009B1DB4: CA10014E 0C0C014D
	v_dual_mov_b32 v15, v76 :: v_dual_mov_b32 v16, v75         // 0000009B1DBC: CA10014C 0F10014B
	v_mov_b32_e32 v17, v74                                     // 0000009B1DC4: 7E22034A
	v_mov_b32_e32 v18, v10                                     // 0000009B1DC8: 7E24030A
	s_mov_b32 s0, 0x76543210                                   // 0000009B1DCC: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B1DD4: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 0000009B1DD8: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 0000009B1DE4: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 0000009B1DF0: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 0000009B1DFC: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 0000009B1E08: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 0000009B1E14: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 0000009B1E20: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 0000009B1E2C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 0000009B1E38: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 0000009B1E44: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 0000009B1E50: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 0000009B1E5C: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 0000009B1E68: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 0000009B1E74: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 0000009B1E80: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 0000009B1E8C: D65C0012 03FC0112 FEDCBA98
	.long 0xd44c0000                                           // 0000009B1E98: D44C0000
	v_cndmask_b32_e32 v1, 16, v72, vcc_lo                      // 0000009B1E9C: 02029090
	s_barrier                                                  // 0000009B1EA0: BFBD0000
	buffer_gl0_inv                                             // 0000009B1EA4: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000009B1EAC: BE812000
	s_cbranch_execz 36                                         // 0000009B1EB0: BFA50024 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2744>
	v_dual_add_f32 v10, v10, v18 :: v_dual_add_f32 v1, v9, v1  // 0000009B1EB4: C908250A 0A000309
	v_add_f32_e32 v9, v83, v11                                 // 0000009B1EBC: 06121753
	v_dual_add_f32 v11, v82, v14 :: v_dual_add_f32 v8, v79, v8 // 0000009B1EC0: C9081D52 0B08114F
	v_lshlrev_b32_e32 v14, 2, v72                              // 0000009B1EC8: 301C9082
	v_dual_add_f32 v2, v87, v2 :: v_dual_add_f32 v3, v86, v3   // 0000009B1ECC: C9080557 02020756
	v_dual_add_f32 v4, v85, v4 :: v_dual_add_f32 v7, v84, v7   // 0000009B1ED4: C9080955 04060F54
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009B1EDC: BF870003
	v_lshl_or_b32 v14, v71, 10, v14                            // 0000009B1EE0: D656000E 04391547
	v_dual_add_f32 v5, v81, v5 :: v_dual_add_f32 v6, v80, v6   // 0000009B1EE8: C9080B51 05060D50
	v_dual_add_f32 v12, v78, v12 :: v_dual_add_f32 v13, v77, v13// 0000009B1EF0: C908194E 0C0C1B4D
	v_dual_add_f32 v15, v76, v15 :: v_dual_add_f32 v16, v75, v16// 0000009B1EF8: C9081F4C 0F10214B
	v_add_f32_e32 v17, v74, v17                                // 0000009B1F00: 0622234A
	ds_store_2addr_b32 v14, v1, v2 offset1:16                  // 0000009B1F04: D8381000 0002010E
	ds_store_2addr_b32 v14, v3, v4 offset0:32 offset1:48       // 0000009B1F0C: D8383020 0004030E
	ds_store_2addr_b32 v14, v7, v9 offset0:64 offset1:80       // 0000009B1F14: D8385040 0009070E
	ds_store_2addr_b32 v14, v11, v5 offset0:96 offset1:112     // 0000009B1F1C: D8387060 00050B0E
	ds_store_2addr_b32 v14, v6, v8 offset0:128 offset1:144     // 0000009B1F24: D8389080 0008060E
	ds_store_2addr_b32 v14, v12, v13 offset0:160 offset1:176   // 0000009B1F2C: D838B0A0 000D0C0E
	ds_store_2addr_b32 v14, v15, v16 offset0:192 offset1:208   // 0000009B1F34: D838D0C0 00100F0E
	ds_store_2addr_b32 v14, v17, v10 offset0:224 offset1:240   // 0000009B1F3C: D838F0E0 000A110E
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009B1F44: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 0000009B1F48: BF89FC07
	s_barrier                                                  // 0000009B1F4C: BFBD0000
	buffer_gl0_inv                                             // 0000009B1F50: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 0000009B1F58: BE81007E
	v_cmpx_eq_u32_e32 0, v71                                   // 0000009B1F5C: 7D948E80
	s_cbranch_execz 1333                                       // 0000009B1F60: BFA50535 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x3c38>
	v_and_b32_e32 v3, 15, v0                                   // 0000009B1F64: 3606008F
	s_mul_i32 s1, s8, 0xa00                                    // 0000009B1F68: 9601FF08 00000A00
	s_mul_hi_i32 s2, s8, 0xa00                                 // 0000009B1F70: 9702FF08 00000A00
	s_add_u32 s1, s10, s1                                      // 0000009B1F78: 8001010A
	s_addc_u32 s4, s11, s2                                     // 0000009B1F7C: 8204020B
	v_lshlrev_b32_e32 v4, 2, v3                                // 0000009B1F80: 30080682
	s_lshl_b32 s2, s6, 7                                       // 0000009B1F84: 84028706
	ds_load_2addr_b32 v[1:2], v4 offset1:16                    // 0000009B1F88: D8DC1000 01000004
	ds_load_2addr_b32 v[5:6], v4 offset0:128 offset1:144       // 0000009B1F90: D8DC9080 05000004
	s_ashr_i32 s3, s2, 31                                      // 0000009B1F98: 86039F02
	v_lshlrev_b32_e32 v52, 1, v0                               // 0000009B1F9C: 30680081
	s_lshl_b64 s[10:11], s[2:3], 1                             // 0000009B1FA0: 848A8102
	s_mul_hi_i32 s2, s8, 0x500                                 // 0000009B1FA4: 9702FF08 00000500
	s_add_u32 s6, s1, s10                                      // 0000009B1FAC: 80060A01
	s_addc_u32 s7, s4, s11                                     // 0000009B1FB0: 82070B04
	s_mul_i32 s1, s8, 0x500                                    // 0000009B1FB4: 9601FF08 00000500
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B1FBC: BF870009
	s_add_u32 s1, s12, s1                                      // 0000009B1FC0: 8001010C
	s_addc_u32 s2, s13, s2                                     // 0000009B1FC4: 8202020D
	s_add_u32 s8, s1, s10                                      // 0000009B1FC8: 80080A01
	s_addc_u32 s9, s2, s11                                     // 0000009B1FCC: 82090B02
	s_waitcnt lgkmcnt(1)                                       // 0000009B1FD0: BF89FC17
	v_add_f32_e32 v1, 0, v1                                    // 0000009B1FD4: 06020280
	v_add_nc_u32_e32 v45, 0x400, v4                            // 0000009B1FD8: 4A5A08FF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000009B1FE0: BF89FC07
	v_dual_add_f32 v5, 0, v5 :: v_dual_add_nc_u32 v46, 0x800, v4// 0000009B1FE4: C9200A80 052E08FF 00000800
	v_add_nc_u32_e32 v47, 0xc00, v4                            // 0000009B1FF0: 4A5E08FF 00000C00
	v_add_nc_u32_e32 v48, 0x1000, v4                           // 0000009B1FF8: 4A6008FF 00001000
	v_add_nc_u32_e32 v49, 0x1400, v4                           // 0000009B2000: 4A6208FF 00001400
	v_add_nc_u32_e32 v50, 0x1800, v4                           // 0000009B2008: 4A6408FF 00001800
	v_add_nc_u32_e32 v51, 0x1c00, v4                           // 0000009B2010: 4A6608FF 00001C00
	ds_load_2addr_b32 v[7:8], v45 offset1:16                   // 0000009B2018: D8DC1000 0700002D
	ds_load_2addr_b32 v[9:10], v4 offset0:32 offset1:48        // 0000009B2020: D8DC3020 09000004
	ds_load_2addr_b32 v[11:12], v4 offset0:160 offset1:176     // 0000009B2028: D8DCB0A0 0B000004
	ds_load_2addr_b32 v[13:14], v45 offset0:128 offset1:144    // 0000009B2030: D8DC9080 0D00002D
	ds_load_2addr_b32 v[15:16], v46 offset1:16                 // 0000009B2038: D8DC1000 0F00002E
	ds_load_2addr_b32 v[17:18], v46 offset0:128 offset1:144    // 0000009B2040: D8DC9080 1100002E
	ds_load_2addr_b32 v[19:20], v47 offset1:16                 // 0000009B2048: D8DC1000 1300002F
	ds_load_2addr_b32 v[21:22], v47 offset0:128 offset1:144    // 0000009B2050: D8DC9080 1500002F
	ds_load_2addr_b32 v[23:24], v48 offset1:16                 // 0000009B2058: D8DC1000 17000030
	ds_load_2addr_b32 v[25:26], v48 offset0:128 offset1:144    // 0000009B2060: D8DC9080 19000030
	ds_load_2addr_b32 v[27:28], v49 offset1:16                 // 0000009B2068: D8DC1000 1B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:128 offset1:144    // 0000009B2070: D8DC9080 1D000031
	ds_load_2addr_b32 v[31:32], v50 offset1:16                 // 0000009B2078: D8DC1000 1F000032
	ds_load_2addr_b32 v[33:34], v50 offset0:128 offset1:144    // 0000009B2080: D8DC9080 21000032
	ds_load_2addr_b32 v[35:36], v51 offset1:16                 // 0000009B2088: D8DC1000 23000033
	v_add_f32_e32 v2, 0, v2                                    // 0000009B2090: 06040480
	ds_load_2addr_b32 v[43:44], v46 offset0:32 offset1:48      // 0000009B2094: D8DC3020 2B00002E
	s_waitcnt lgkmcnt(15)                                      // 0000009B209C: BF89FCF7
	v_add_f32_e32 v1, v1, v7                                   // 0000009B20A0: 06020F01
	v_dual_add_f32 v7, 0, v6 :: v_dual_add_f32 v2, v2, v8      // 0000009B20A4: C9080C80 07021102
	s_waitcnt lgkmcnt(12)                                      // 0000009B20AC: BF89FCC7
	v_add_f32_e32 v13, v5, v13                                 // 0000009B20B0: 061A1B05
	ds_load_2addr_b32 v[5:6], v46 offset0:160 offset1:176      // 0000009B20B4: D8DCB0A0 0500002E
	s_waitcnt lgkmcnt(12)                                      // 0000009B20BC: BF89FCC7
	v_dual_add_f32 v1, v1, v15 :: v_dual_add_f32 v14, v7, v14  // 0000009B20C0: C9081F01 010E1D07
	s_waitcnt lgkmcnt(11)                                      // 0000009B20C8: BF89FCB7
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v13, v13, v17 // 0000009B20CC: C9082102 020C230D
	ds_load_2addr_b32 v[15:16], v48 offset0:32 offset1:48      // 0000009B20D4: D8DC3020 0F000030
	v_add_f32_e32 v14, v14, v18                                // 0000009B20DC: 061C250E
	s_waitcnt lgkmcnt(11)                                      // 0000009B20E0: BF89FCB7
	v_dual_add_f32 v2, v2, v20 :: v_dual_add_f32 v1, v1, v19   // 0000009B20E4: C9082902 02002701
	ds_load_2addr_b32 v[7:8], v47 offset0:32 offset1:48        // 0000009B20EC: D8DC3020 0700002F
	ds_load_2addr_b32 v[17:18], v48 offset0:160 offset1:176    // 0000009B20F4: D8DCB0A0 11000030
	s_waitcnt lgkmcnt(12)                                      // 0000009B20FC: BF89FCC7
	v_add_f32_e32 v14, v14, v22                                // 0000009B2100: 061C2D0E
	s_waitcnt lgkmcnt(11)                                      // 0000009B2104: BF89FCB7
	v_dual_add_f32 v2, v2, v24 :: v_dual_add_f32 v1, v1, v23   // 0000009B2108: C9083102 02002F01
	ds_load_2addr_b32 v[19:20], v49 offset0:32 offset1:48      // 0000009B2110: D8DC3020 13000031
	s_waitcnt lgkmcnt(11)                                      // 0000009B2118: BF89FCB7
	v_add_f32_e32 v14, v14, v26                                // 0000009B211C: 061C350E
	ds_load_2addr_b32 v[37:38], v51 offset0:128 offset1:144    // 0000009B2120: D8DC9080 25000033
	ds_load_2addr_b32 v[39:40], v45 offset0:32 offset1:48      // 0000009B2128: D8DC3020 2700002D
	ds_load_2addr_b32 v[41:42], v45 offset0:160 offset1:176    // 0000009B2130: D8DCB0A0 2900002D
	v_add_f32_e32 v13, v13, v21                                // 0000009B2138: 061A2B0D
	s_waitcnt lgkmcnt(13)                                      // 0000009B213C: BF89FCD7
	v_add_f32_e32 v1, v1, v27                                  // 0000009B2140: 06023701
	v_add_f32_e32 v23, v2, v28                                 // 0000009B2144: 062E3902
	s_waitcnt lgkmcnt(12)                                      // 0000009B2148: BF89FCC7
	v_dual_add_f32 v24, v14, v30 :: v_dual_add_f32 v9, 0, v9   // 0000009B214C: C9083D0E 18081280
	ds_load_2addr_b32 v[21:22], v49 offset0:160 offset1:176    // 0000009B2154: D8DCB0A0 15000031
	v_add_f32_e32 v11, 0, v11                                  // 0000009B215C: 06161680
	s_waitcnt lgkmcnt(11)                                      // 0000009B2160: BF89FCB7
	v_dual_add_f32 v1, v1, v31 :: v_dual_add_f32 v26, v24, v34 // 0000009B2164: C9083F01 011A4518
	s_waitcnt lgkmcnt(3)                                       // 0000009B216C: BF89FC37
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B2170: BF870001
	v_dual_add_f32 v13, v13, v25 :: v_dual_add_f32 v54, v26, v38// 0000009B2174: C908330D 0D364D1A
	s_waitcnt lgkmcnt(2)                                       // 0000009B217C: BF89FC27
	v_add_f32_e32 v9, v9, v39                                  // 0000009B2180: 06124F09
	v_add_f32_e32 v39, v1, v35                                 // 0000009B2184: 064E4701
	v_lshlrev_b32_e32 v1, 1, v3                                // 0000009B2188: 30020681
	s_waitcnt lgkmcnt(1)                                       // 0000009B218C: BF89FC17
	v_add_f32_e32 v3, v11, v41                                 // 0000009B2190: 0606530B
	v_add_f32_e32 v11, v23, v32                                // 0000009B2194: 06164117
	v_add_f32_e32 v9, v9, v43                                  // 0000009B2198: 06125709
	ds_load_2addr_b32 v[23:24], v50 offset0:32 offset1:48      // 0000009B219C: D8DC3020 17000032
	v_or_b32_e32 v41, 32, v52                                  // 0000009B21A4: 385268A0
	v_add_f32_e32 v5, v3, v5                                   // 0000009B21A8: 060A0B03
	v_add_f32_e32 v53, v11, v36                                // 0000009B21AC: 066A490B
	v_add_f32_e32 v7, v9, v7                                   // 0000009B21B0: 060E0F09
	global_load_d16_b16 v3, v41, s[6:7]                        // 0000009B21B4: DC820000 03060029
	v_add_f32_e32 v7, v7, v15                                  // 0000009B21BC: 060E1F07
	v_add_f32_e32 v15, 0, v12                                  // 0000009B21C0: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:192 offset1:208     // 0000009B21C4: D8DCD0C0 0B000004
	ds_load_2addr_b32 v[27:28], v51 offset0:32 offset1:48      // 0000009B21CC: D8DC3020 1B000033
	v_add_f32_e32 v7, v7, v19                                  // 0000009B21D4: 060E2707
	s_waitcnt lgkmcnt(2)                                       // 0000009B21D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B21DC: BF870001
	v_add_f32_e32 v19, v7, v23                                 // 0000009B21E0: 06262F07
	v_add_f32_e32 v13, v13, v29                                // 0000009B21E4: 061A3B0D
	ds_load_2addr_b32 v[29:30], v45 offset0:64 offset1:80      // 0000009B21E8: D8DC5040 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:192 offset1:208    // 0000009B21F0: D8DCD0C0 1F00002D
	v_add_f32_e32 v25, v13, v33                                // 0000009B21F8: 0632430D
	ds_load_2addr_b32 v[13:14], v47 offset0:160 offset1:176    // 0000009B21FC: D8DCB0A0 0D00002F
	s_waitcnt lgkmcnt(4)                                       // 0000009B2204: BF89FC47
	v_add_f32_e32 v11, 0, v11                                  // 0000009B2208: 06161680
	v_add_f32_e32 v43, v25, v37                                // 0000009B220C: 06564B19
	ds_load_2addr_b32 v[25:26], v50 offset0:160 offset1:176    // 0000009B2210: D8DCB0A0 19000032
	ds_load_2addr_b32 v[37:38], v48 offset0:192 offset1:208    // 0000009B2218: D8DCD0C0 25000030
	s_waitcnt lgkmcnt(3)                                       // 0000009B2220: BF89FC37
	v_add_f32_e32 v11, v11, v31                                // 0000009B2224: 06163F0B
	s_waitcnt lgkmcnt(2)                                       // 0000009B2228: BF89FC27
	v_add_f32_e32 v5, v5, v13                                  // 0000009B222C: 060A1B05
	v_add_f32_e32 v13, 0, v10                                  // 0000009B2230: 061A1480
	ds_load_2addr_b32 v[9:10], v4 offset0:64 offset1:80        // 0000009B2234: D8DC5040 09000004
	v_add_f32_e32 v5, v5, v17                                  // 0000009B223C: 060A2305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000009B2240: BF8701C1
	v_add_f32_e32 v17, v5, v21                                 // 0000009B2244: 06222B05
	v_add_f32_e32 v5, v13, v40                                 // 0000009B2248: 060A510D
	v_add_f32_e32 v13, v15, v42                                // 0000009B224C: 061A550F
	s_waitcnt lgkmcnt(2)                                       // 0000009B2250: BF89FC27
	v_dual_add_f32 v40, v19, v27 :: v_dual_add_f32 v21, v17, v25// 0000009B2254: C9083713 28143311
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009B225C: BF870193
	v_add_f32_e32 v7, v5, v44                                  // 0000009B2260: 060E5905
	v_add_f32_e32 v13, v13, v6                                 // 0000009B2264: 061A0D0D
	ds_load_2addr_b32 v[5:6], v46 offset0:64 offset1:80        // 0000009B2268: D8DC5040 0500002E
	ds_load_2addr_b32 v[33:34], v46 offset0:192 offset1:208    // 0000009B2270: D8DCD0C0 2100002E
	ds_load_2addr_b32 v[35:36], v51 offset0:160 offset1:176    // 0000009B2278: D8DCB0A0 23000033
	v_add_f32_e32 v15, v7, v8                                  // 0000009B2280: 061E1107
	ds_load_2addr_b32 v[7:8], v47 offset0:64 offset1:80        // 0000009B2284: D8DC5040 0700002F
	v_add_f32_e32 v17, v13, v14                                // 0000009B228C: 06221D0D
	ds_load_2addr_b32 v[13:14], v47 offset0:192 offset1:208    // 0000009B2290: D8DCD0C0 0D00002F
	s_waitcnt lgkmcnt(5)                                       // 0000009B2298: BF89FC57
	v_add_f32_e32 v9, 0, v9                                    // 0000009B229C: 06121280
	v_add_f32_e32 v23, v15, v16                                // 0000009B22A0: 062E210F
	ds_load_2addr_b32 v[15:16], v48 offset0:64 offset1:80      // 0000009B22A4: D8DC5040 0F000030
	v_add_f32_e32 v17, v17, v18                                // 0000009B22AC: 06222511
	v_add_f32_e32 v9, v9, v29                                  // 0000009B22B0: 06123B09
	v_add_f32_e32 v23, v23, v20                                // 0000009B22B4: 062E2917
	ds_load_2addr_b32 v[19:20], v49 offset0:192 offset1:208    // 0000009B22B8: D8DCD0C0 13000031
	v_add_f32_e32 v22, v17, v22                                // 0000009B22C0: 062C2D11
	ds_load_2addr_b32 v[17:18], v49 offset0:64 offset1:80      // 0000009B22C4: D8DC5040 11000031
	s_waitcnt lgkmcnt(7)                                       // 0000009B22CC: BF89FC77
	v_add_f32_e32 v5, v9, v5                                   // 0000009B22D0: 060A0B09
	s_waitcnt lgkmcnt(5)                                       // 0000009B22D4: BF89FC57
	v_dual_add_f32 v9, v11, v33 :: v_dual_add_f32 v42, v21, v35// 0000009B22D8: C908430B 092A4715
	v_add_f32_e32 v27, v23, v24                                // 0000009B22E0: 06363117
	v_add_f32_e32 v33, v22, v26                                // 0000009B22E4: 06423516
	ds_load_2addr_b32 v[21:22], v50 offset0:64 offset1:80      // 0000009B22E8: D8DC5040 15000032
	ds_load_2addr_b32 v[23:24], v50 offset0:192 offset1:208    // 0000009B22F0: D8DCD0C0 17000032
	s_waitcnt lgkmcnt(6)                                       // 0000009B22F8: BF89FC67
	v_add_f32_e32 v5, v5, v7                                   // 0000009B22FC: 060A0F05
	s_waitcnt lgkmcnt(5)                                       // 0000009B2300: BF89FC57
	v_add_f32_e32 v7, v9, v13                                  // 0000009B2304: 060E1B09
	s_waitcnt lgkmcnt(4)                                       // 0000009B2308: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B230C: BF870002
	v_add_f32_e32 v13, v5, v15                                 // 0000009B2310: 061A1F05
	v_add_f32_e32 v5, 0, v10                                   // 0000009B2314: 060A1480
	ds_load_2addr_b32 v[9:10], v51 offset0:64 offset1:80       // 0000009B2318: D8DC5040 09000033
	ds_load_2addr_b32 v[25:26], v51 offset0:192 offset1:208    // 0000009B2320: D8DCD0C0 19000033
	v_add_f32_e32 v7, v7, v37                                  // 0000009B2328: 060E4B07
	v_add_f32_e32 v15, 0, v12                                  // 0000009B232C: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:96 offset1:112      // 0000009B2330: D8DC7060 0B000004
	v_add_f32_e32 v31, v5, v30                                 // 0000009B2338: 063E3D05
	ds_load_2addr_b32 v[29:30], v4 offset0:224 offset1:240     // 0000009B233C: D8DCF0E0 1D000004
	s_waitcnt lgkmcnt(6)                                       // 0000009B2344: BF89FC67
	v_dual_add_f32 v13, v13, v17 :: v_dual_add_f32 v4, v15, v32// 0000009B2348: C908230D 0D04410F
	v_add_f32_e32 v15, v7, v19                                 // 0000009B2350: 061E2707
	v_add_f32_e32 v17, v31, v6                                 // 0000009B2354: 06220D1F
	ds_load_2addr_b32 v[6:7], v45 offset0:96 offset1:112       // 0000009B2358: D8DC7060 0600002D
	ds_load_2addr_b32 v[31:32], v45 offset0:224 offset1:240    // 0000009B2360: D8DCF0E0 1F00002D
	s_waitcnt lgkmcnt(7)                                       // 0000009B2368: BF89FC77
	v_dual_add_f32 v13, v13, v21 :: v_dual_add_f32 v4, v4, v34 // 0000009B236C: C9082B0D 0D044504
	s_waitcnt lgkmcnt(6)                                       // 0000009B2374: BF89FC67
	v_dual_add_f32 v15, v15, v23 :: v_dual_add_f32 v8, v17, v8 // 0000009B2378: C9082F0F 0F081111
	s_clause 0x1                                               // 0000009B2380: BF850001
	global_load_d16_b16 v2, v1, s[6:7]                         // 0000009B2384: DC820000 02060001
	global_load_d16_b16 v5, v1, s[6:7] offset:64               // 0000009B238C: DC820040 05060001
	v_dual_add_f32 v4, v4, v14 :: v_dual_add_f32 v37, v27, v28 // 0000009B2394: C9081D04 0424391B
	s_waitcnt lgkmcnt(5)                                       // 0000009B239C: BF89FC57
	v_add_f32_e32 v23, v13, v9                                 // 0000009B23A0: 062E130D
	s_waitcnt lgkmcnt(4)                                       // 0000009B23A4: BF89FC47
	v_dual_add_f32 v25, v15, v25 :: v_dual_add_f32 v8, v8, v16 // 0000009B23A8: C908330F 19082108
	ds_load_2addr_b32 v[13:14], v46 offset0:96 offset1:112     // 0000009B23B0: D8DC7060 0D00002E
	ds_load_2addr_b32 v[15:16], v46 offset0:224 offset1:240    // 0000009B23B8: D8DCF0E0 0F00002E
	v_add_f32_e32 v9, v4, v38                                  // 0000009B23C0: 06124D04
	s_waitcnt lgkmcnt(5)                                       // 0000009B23C4: BF89FC57
	v_add_f32_e32 v11, 0, v11                                  // 0000009B23C8: 06161680
	s_waitcnt lgkmcnt(4)                                       // 0000009B23CC: BF89FC47
	v_dual_add_f32 v17, 0, v29 :: v_dual_add_f32 v38, v8, v18  // 0000009B23D0: C9083A80 11262508
	v_add_f32_e32 v21, v33, v36                                // 0000009B23D8: 062A4921
	v_add_f32_e32 v44, v9, v20                                 // 0000009B23DC: 06582909
	s_waitcnt lgkmcnt(2)                                       // 0000009B23E0: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009B23E4: BF870003
	v_dual_add_f32 v8, v11, v6 :: v_dual_add_f32 v11, v17, v31 // 0000009B23E8: C9080D0B 080A3F11
	ds_load_2addr_b32 v[17:18], v47 offset0:96 offset1:112     // 0000009B23F0: D8DC7060 1100002F
	ds_load_2addr_b32 v[19:20], v47 offset0:224 offset1:240    // 0000009B23F8: D8DCF0E0 1300002F
	ds_load_2addr_b32 v[27:28], v48 offset0:96 offset1:112     // 0000009B2400: D8DC7060 1B000030
	ds_load_2addr_b32 v[33:34], v48 offset0:224 offset1:240    // 0000009B2408: D8DCF0E0 21000030
	v_add_f32_e32 v31, 0, v12                                  // 0000009B2410: 063E1880
	v_add_f32_e32 v35, 0, v30                                  // 0000009B2414: 06463C80
	s_clause 0x1                                               // 0000009B2418: BF850001
	global_load_d16_b16 v6, v41, s[6:7] offset:1280            // 0000009B241C: DC820500 06060029
	global_load_d16_b16 v4, v1, s[6:7] offset:1280             // 0000009B2424: DC820500 04060001
	v_or_b32_e32 v45, 0x60, v52                                // 0000009B242C: 385A68FF 00000060
	v_add_f32_e32 v7, v31, v7                                  // 0000009B2434: 060E0F1F
	s_waitcnt lgkmcnt(5)                                       // 0000009B2438: BF89FC57
	v_add_f32_e32 v13, v8, v13                                 // 0000009B243C: 061A1B08
	global_load_d16_b16 v8, v41, s[8:9]                        // 0000009B2440: DC820000 08080029
	s_waitcnt lgkmcnt(4)                                       // 0000009B2448: BF89FC47
	v_add_f32_e32 v15, v11, v15                                // 0000009B244C: 061E1F0B
	ds_load_2addr_b32 v[11:12], v49 offset0:96 offset1:112     // 0000009B2450: D8DC7060 0B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:224 offset1:240    // 0000009B2458: D8DCF0E0 1D000031
	v_add_f32_e32 v41, v35, v32                                // 0000009B2460: 06524123
	ds_load_2addr_b32 v[31:32], v50 offset0:96 offset1:112     // 0000009B2464: D8DC7060 1F000032
	ds_load_2addr_b32 v[35:36], v50 offset0:224 offset1:240    // 0000009B246C: D8DCF0E0 23000032
	v_add_f32_e32 v7, v7, v14                                  // 0000009B2474: 060E1D07
	global_load_d16_b16 v9, v45, s[6:7]                        // 0000009B2478: DC820000 0906002D
	v_add_f32_e32 v41, v41, v16                                // 0000009B2480: 06522129
	s_waitcnt lgkmcnt(7)                                       // 0000009B2484: BF89FC77
	v_add_f32_e32 v17, v13, v17                                // 0000009B2488: 0622230D
	s_waitcnt lgkmcnt(6)                                       // 0000009B248C: BF89FC67
	v_add_f32_e32 v19, v15, v19                                // 0000009B2490: 0626270F
	ds_load_2addr_b32 v[13:14], v51 offset0:96 offset1:112     // 0000009B2494: D8DC7060 0D000033
	ds_load_2addr_b32 v[15:16], v51 offset0:224 offset1:240    // 0000009B249C: D8DCF0E0 0F000033
	v_dual_add_f32 v7, v7, v18 :: v_dual_add_f32 v18, v41, v20 // 0000009B24A4: C9082507 07122929
	s_waitcnt lgkmcnt(7)                                       // 0000009B24AC: BF89FC77
	v_add_f32_e32 v17, v17, v27                                // 0000009B24B0: 06223711
	s_waitcnt lgkmcnt(6)                                       // 0000009B24B4: BF89FC67
	v_dual_add_f32 v19, v19, v33 :: v_dual_add_f32 v20, v38, v22// 0000009B24B8: C9084313 13142D26
	v_dual_add_f32 v7, v7, v28 :: v_dual_add_f32 v18, v18, v34 // 0000009B24C0: C9083907 07124512
	v_add_f32_e32 v22, v44, v24                                // 0000009B24C8: 062C312C
	v_or_b32_e32 v28, 0xa0, v52                                // 0000009B24CC: 383868FF 000000A0
	s_waitcnt lgkmcnt(5)                                       // 0000009B24D4: BF89FC57
	v_add_f32_e32 v11, v17, v11                                // 0000009B24D8: 06161711
	s_waitcnt lgkmcnt(4)                                       // 0000009B24DC: BF89FC47
	v_add_f32_e32 v17, v19, v29                                // 0000009B24E0: 06223B13
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v12, v18, v30 // 0000009B24E4: C9081907 070C3D12
	s_waitcnt lgkmcnt(3)                                       // 0000009B24EC: BF89FC37
	v_dual_add_f32 v10, v20, v10 :: v_dual_add_f32 v11, v11, v31// 0000009B24F0: C9081514 0A0A3F0B
	s_waitcnt lgkmcnt(2)                                       // 0000009B24F8: BF89FC27
	v_dual_add_f32 v17, v17, v35 :: v_dual_add_f32 v18, v22, v26// 0000009B24FC: C9084711 11123516
	v_add_f32_e32 v12, v12, v36                                // 0000009B2504: 0618490C
	v_add_f32_e32 v7, v7, v32                                  // 0000009B2508: 060E4107
	s_waitcnt lgkmcnt(1)                                       // 0000009B250C: BF89FC17
	v_add_f32_e32 v11, v11, v13                                // 0000009B2510: 06161B0B
	s_waitcnt lgkmcnt(0)                                       // 0000009B2514: BF89FC07
	v_add_f32_e32 v13, v17, v15                                // 0000009B2518: 061A1F11
	v_dual_add_f32 v19, v23, v10 :: v_dual_add_f32 v12, v12, v16// 0000009B251C: C9081517 130C210C
	v_sub_f32_e32 v10, v23, v10                                // 0000009B2524: 08141517
	v_dual_add_f32 v22, v43, v54 :: v_dual_add_f32 v23, v42, v21// 0000009B2528: C9086D2B 16162B2A
	v_add_f32_e32 v24, v25, v18                                // 0000009B2530: 06302519
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B2534: BF870004
	v_add_f32_e32 v27, v13, v12                                // 0000009B2538: 0636190D
	v_add_f32_e32 v7, v7, v14                                  // 0000009B253C: 060E1D07
	v_sub_f32_e32 v15, v39, v53                                // 0000009B2540: 081E6B27
	v_add_f32_e32 v16, v40, v37                                // 0000009B2544: 06204B28
	v_dual_sub_f32 v17, v40, v37 :: v_dual_add_f32 v30, v22, v23// 0000009B2548: C9484B28 111E2F16
	v_add_f32_e32 v31, v24, v27                                // 0000009B2550: 063E3718
	v_dual_add_f32 v20, v11, v7 :: v_dual_and_b32 v37, 1, v0   // 0000009B2554: C9240F0B 14240081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009B255C: BF870223
	v_add_f32_e32 v36, v15, v17                                // 0000009B2560: 0648230F
	v_sub_f32_e32 v15, v15, v17                                // 0000009B2564: 081E230F
	v_add_f32_e32 v17, v30, v31                                // 0000009B2568: 06223F1E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B256C: BF870004
	.long 0xd44a0002                                           // 0000009B2570: D44A0002
	v_cndmask_b32_e32 v1, 0, v37, vcc_lo                       // 0000009B2574: 02024A80
	v_add_f32_e32 v14, v39, v53                                // 0000009B2578: 061C6B27
	v_add_f32_e32 v39, v19, v20                                // 0000009B257C: 064E2913
	v_sub_f32_e32 v19, v19, v20                                // 0000009B2580: 08262913
	v_mov_b32_dpp v20, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B2584: 7E2802FA FF016111
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 0000009B258C: D5010011 200A2311
	v_sub_f32_e32 v37, v43, v54                                // 0000009B2594: 084A6D2B
	v_dual_sub_f32 v21, v42, v21 :: v_dual_sub_f32 v18, v25, v18// 0000009B2598: C94A2B2A 15122519
	v_dual_sub_f32 v12, v13, v12 :: v_dual_sub_f32 v11, v11, v7// 0000009B25A0: C94A190D 0C0A0F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009B25A8: BF8701A4
	v_add_f32_e32 v13, v17, v20                                // 0000009B25AC: 061A2911
	v_and_b32_e32 v17, 2, v0                                   // 0000009B25B0: 36220082
	v_dual_add_f32 v25, v37, v21 :: v_dual_add_f32 v40, v18, v12// 0000009B25B4: C9082B25 19281912
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009B25BC: BF870224
	v_add_f32_e32 v20, v10, v11                                // 0000009B25C0: 0628170A
	v_sub_f32_e32 v10, v10, v11                                // 0000009B25C4: 0814170A
	.long 0xd44a0003                                           // 0000009B25C8: D44A0003
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 0000009B25CC: 02022280
	v_sub_f32_e32 v17, v22, v23                                // 0000009B25D0: 08222F16
	v_dual_add_f32 v11, v25, v40 :: v_dual_sub_f32 v22, v24, v27// 0000009B25D4: C90A5119 0B163718
	v_and_b32_e32 v23, 4, v0                                   // 0000009B25DC: 362E0084
	v_mov_b32_dpp v41, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B25E0: 7E5202FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 0000009B25E8: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000009B25F0: BF870254
	v_mov_b32_dpp v24, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B25F4: 7E3002FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 0000009B25FC: D501000B 200A170B
	v_add_f32_e32 v27, v17, v22                                // 0000009B2604: 06362D11
	.long 0xd44a0004                                           // 0000009B2608: D44A0004
	v_cndmask_b32_e32 v1, 0, v23, vcc_lo                       // 0000009B260C: 02022E80
	v_dual_add_f32 v13, v13, v41 :: v_dual_and_b32 v0, 8, v0   // 0000009B2610: C924530D 0D000088
	v_add_f32_e32 v11, v11, v24                                // 0000009B2618: 0616310B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009B261C: BF870224
	v_mov_b32_dpp v23, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B2620: 7E2E02FA FF01611B
	v_cndmask_b32_e64 v24, -v27, v27, s2                       // 0000009B2628: D5010018 200A371B
	.long 0xd44a0001                                           // 0000009B2630: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000009B2634: 02020080
	v_sub_f32_e32 v0, v37, v21                                 // 0000009B2638: 08002B25
	v_mov_b32_dpp v27, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B263C: 7E3602FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 0000009B2644: D501000B 200E170B
	v_dual_add_f32 v23, v24, v23 :: v_dual_sub_f32 v12, v18, v12// 0000009B264C: C90A2F18 170C1912
	v_mov_b32_dpp v41, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B2654: 7E5202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 0000009B265C: D501000D 20121B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B2664: BF870214
	v_add_f32_e32 v11, v11, v27                                // 0000009B2668: 0616370B
	v_mov_b32_dpp v18, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B266C: 7E2402FA FF016217
	v_cndmask_b32_e64 v21, -v23, v23, s3                       // 0000009B2674: D5010015 200E2F17
	v_sub_f32_e32 v24, v25, v40                                // 0000009B267C: 08305119
	v_add_f32_e32 v13, v13, v41                                // 0000009B2680: 061A530D
	v_mov_b32_dpp v25, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B2684: 7E3202FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 0000009B268C: D501000B 2012170B
	v_dual_add_f32 v18, v21, v18 :: v_dual_add_f32 v21, v0, v12// 0000009B2694: C9082515 12141900
	v_sub_f32_e32 v23, v30, v31                                // 0000009B269C: 082E3F1E
	v_sub_f32_e32 v17, v17, v22                                // 0000009B26A0: 08222D11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B26A4: BF870214
	v_add_f32_e32 v11, v11, v25                                // 0000009B26A8: 0616330B
	v_mov_b32_dpp v25, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B26AC: 7E3202FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 0000009B26B4: D5010012 20122512
	v_mov_b32_dpp v30, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B26BC: 7E3C02FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 0000009B26C4: D5010015 200A2B15
	v_mov_b32_dpp v22, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B26CC: 7E2C02FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 0000009B26D4: D501000D 20061B0D
	v_add_f32_e32 v18, v18, v25                                // 0000009B26DC: 06243312
	v_add_f32_e32 v29, v14, v16                                // 0000009B26E0: 063A210E
	v_dual_add_f32 v21, v21, v30 :: v_dual_sub_f32 v14, v14, v16// 0000009B26E4: C90A3D15 150E210E
	v_or_b32_e32 v16, 0xe0, v52                                // 0000009B26EC: 382068FF 000000E0
	v_sub_f32_e32 v0, v0, v12                                  // 0000009B26F4: 08001900
	v_add_f32_e32 v12, v13, v22                                // 0000009B26F8: 06182D0D
	v_mov_b32_dpp v13, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B26FC: 7E1A02FA FF016812
	v_mov_b32_dpp v22, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B2704: 7E2C02FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 0000009B270C: D5010015 200E2B15
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 0000009B2714: D5010012 20062512
	v_mov_b32_dpp v25, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B271C: 7E3202FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s2                       // 0000009B2724: D5010017 200A2F17
	global_load_d16_b16 v38, v16, s[6:7]                       // 0000009B272C: DC820000 26060010
	v_add_f32_e32 v21, v21, v22                                // 0000009B2734: 062A2D15
	v_add_f32_e32 v13, v18, v13                                // 0000009B2738: 061A1B12
	global_load_d16_b16 v22, v28, s[6:7] offset:1280           // 0000009B273C: DC820500 1606001C
	v_add_f32_e32 v18, v23, v25                                // 0000009B2744: 06243317
	s_clause 0x7                                               // 0000009B2748: BF850007
	global_load_d16_b16 v25, v16, s[6:7] offset:1280           // 0000009B274C: DC820500 19060010
	global_load_d16_b16 v26, v1, s[6:7] offset:128             // 0000009B2754: DC820080 1A060001
	global_load_d16_b16 v32, v28, s[6:7]                       // 0000009B275C: DC820000 2006001C
	global_load_d16_b16 v33, v1, s[6:7] offset:1344            // 0000009B2764: DC820540 21060001
	global_load_d16_b16 v7, v1, s[6:7] offset:1408             // 0000009B276C: DC820580 07060001
	global_load_d16_b16 v34, v1, s[6:7] offset:1472            // 0000009B2774: DC8205C0 22060001
	global_load_d16_b16 v35, v1, s[6:7] offset:192             // 0000009B277C: DC8200C0 23060001
	global_load_d16_b16 v27, v45, s[6:7] offset:1280           // 0000009B2784: DC820500 1B06002D
	v_mov_b32_dpp v23, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B278C: 7E2E02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s4                       // 0000009B2794: D5010015 20122B15
	s_clause 0x5                                               // 0000009B279C: BF850005
	global_load_d16_b16 v28, v28, s[8:9]                       // 0000009B27A0: DC820000 1C08001C
	global_load_d16_b16 v16, v16, s[8:9]                       // 0000009B27A8: DC820000 10080010
	global_load_d16_b16 v37, v1, s[8:9]                        // 0000009B27B0: DC820000 25080001
	global_load_d16_b16 v40, v1, s[8:9] offset:64              // 0000009B27B8: DC820040 28080001
	global_load_d16_b16 v41, v1, s[8:9] offset:128             // 0000009B27C0: DC820080 29080001
	global_load_d16_b16 v42, v1, s[8:9] offset:192             // 0000009B27C8: DC8200C0 2A080001
	v_mov_b32_dpp v31, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B27D0: 7E3E02FA FF01680B
	v_add_f32_e32 v21, v21, v23                                // 0000009B27D8: 062A2F15
	global_load_d16_b16 v23, v45, s[8:9]                       // 0000009B27DC: DC820000 1708002D
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 0000009B27E4: D501000B 2006170B
	v_mov_b32_dpp v30, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B27EC: 7E3C02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 0000009B27F4: D5010012 200E2512
	v_add_f32_e32 v43, v36, v20                                // 0000009B27FC: 06562924
	v_mov_b32_dpp v47, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B2800: 7E5E02FA FF016118
	v_add_f32_e32 v11, v11, v31                                // 0000009B2808: 06163F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B280C: BF870214
	v_dual_add_f32 v31, v29, v39 :: v_dual_add_f32 v18, v18, v30// 0000009B2810: C9084F1D 1F123D12
	v_mov_b32_dpp v45, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B2818: 7E5A02FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 0000009B2820: D501002B 200A572B
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 0000009B2828: D5010018 200A3118
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B2830: BF870004
	v_mov_b32_dpp v30, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B2834: 7E3C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 0000009B283C: D501001F 200A3F1F
	v_mov_b32_dpp v44, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B2844: 7E5802FA FF016815
	v_add_f32_e32 v43, v43, v45                                // 0000009B284C: 06565B2B
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 0000009B2850: D5010015 20062B15
	v_add_f32_e32 v24, v24, v47                                // 0000009B2858: 06305F18
	v_add_f32_e32 v30, v31, v30                                // 0000009B285C: 063C3D1F
	v_mov_b32_dpp v31, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B2860: 7E3E02FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 0000009B2868: D5010012 20122512
	v_add_f32_e32 v21, v21, v44                                // 0000009B2870: 062A5915
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 0000009B2874: 101818FF 3DB504F3
	v_mov_b32_dpp v46, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B287C: 7E5C02FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 0000009B2884: D501001E 200E3D1E
	v_add_f32_e32 v18, v18, v31                                // 0000009B288C: 06243F12
	v_mov_b32_dpp v31, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B2890: 7E3E02FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 0000009B2898: D501002B 200E572B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009B28A0: BF870234
	v_dual_sub_f32 v29, v29, v39 :: v_dual_add_f32 v30, v30, v46// 0000009B28A4: C9484F1D 1D1E5D1E
	v_mov_b32_dpp v46, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B28AC: 7E5C02FA FF016218
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 0000009B28B4: D5010018 200E3118
	v_add_f32_e32 v31, v43, v31                                // 0000009B28BC: 063E3F2B
	v_mov_b32_dpp v43, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B28C0: 7E5602FA FF016812
	v_mov_b32_dpp v45, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B28C8: 7E5A02FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s4                       // 0000009B28D0: D501001E 20123D1E
	v_add_f32_e32 v24, v24, v46                                // 0000009B28D8: 06305D18
	v_mov_b32_dpp v44, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B28DC: 7E5802FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 0000009B28E4: D501001F 20123F1F
	v_mov_b32_dpp v46, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B28EC: 7E5C02FA FF016111
	v_add_f32_e32 v30, v30, v45                                // 0000009B28F4: 063C5B1E
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 0000009B28F8: D5010011 200A2311
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 0000009B2900: D5010012 20062512
	v_add_f32_e32 v31, v31, v44                                // 0000009B2908: 063E591F
	v_mov_b32_dpp v44, v24 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B290C: 7E5802FA FF016418
	v_mov_b32_dpp v45, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B2914: 7E5A02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 0000009B291C: D501001E 20063D1E
	v_add_f32_e32 v17, v17, v46                                // 0000009B2924: 06225D11
	v_cndmask_b32_e64 v24, -v24, v24, s4                       // 0000009B2928: D5010018 20123118
	v_add_f32_e32 v18, v18, v43                                // 0000009B2930: 06245712
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B2934: BF870004
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_add_f32 v30, v30, v45// 0000009B2938: C8C816FF 0B1E5B1E 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B2944: 7E5A02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 0000009B294C: D501001F 20063F1F
	v_mov_b32_dpp v46, v17 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B2954: 7E5C02FA FF016211
	v_cndmask_b32_e64 v17, -v17, v17, s3                       // 0000009B295C: D5010011 200E2311
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 0000009B2964: 103C3CFF 3DB504F3
	v_add_f32_e32 v24, v24, v44                                // 0000009B296C: 06305918
	v_dual_sub_f32 v20, v36, v20 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 0000009B2970: C9462924 140C1AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009B297C: BF8701A4
	v_add_f32_e32 v17, v17, v46                                // 0000009B2980: 06225D11
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 0000009B2984: C8C62AFF 151224FF 3DB504F3
	v_mov_b32_dpp v36, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B2990: 7E4802FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 0000009B2998: D5010014 200A2914
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009B29A0: BF8700A4
	v_mov_b32_dpp v44, v17 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B29A4: 7E5802FA FF016411
	v_cndmask_b32_e64 v17, -v17, v17, s4                       // 0000009B29AC: D5010011 20122311
	v_add_f32_e32 v17, v17, v44                                // 0000009B29B4: 06225911
	v_mov_b32_dpp v44, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B29B8: 7E5802FA FF016100
	v_cndmask_b32_e64 v0, -v0, v0, s2                          // 0000009B29C0: D5010000 200A0100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B29C8: BF870211
	v_add_f32_e32 v0, v0, v44                                  // 0000009B29CC: 06005900
	v_mov_b32_dpp v44, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B29D0: 7E5802FA FF016811
	v_cndmask_b32_e64 v17, -v17, v17, s1                       // 0000009B29D8: D5010011 20062311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B29E0: BF870091
	v_add_f32_e32 v17, v17, v44                                // 0000009B29E4: 06225911
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 0000009B29E8: 102222FF 3DB504F3
	s_waitcnt vmcnt(22)                                        // 0000009B29F0: BF895BF7
	v_fma_mix_f32 v2, v2, v30, neg(0) op_sel_hi:[1,0,0]        // 0000009B29F4: CC200002 8A023D02
	v_add_f32_e32 v30, v31, v45                                // 0000009B29FC: 063C5B1F
	v_mov_b32_dpp v31, v24 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B2A00: 7E3E02FA FF016818
	v_cndmask_b32_e64 v24, -v24, v24, s1                       // 0000009B2A08: D5010018 20063118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B2A10: BF870214
	v_mul_f32_e32 v43, 0xbfb8aa3b, v2                          // 0000009B2A14: 105604FF BFB8AA3B
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 0000009B2A1C: 103C3CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009B2A24: BF870223
	v_add_f32_e32 v24, v24, v31                                // 0000009B2A28: 06303F18
	v_add_f32_e32 v31, v14, v19                                // 0000009B2A2C: 063E270E
	v_exp_f32_e32 v43, v43                                     // 0000009B2A30: 7E564B2B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009B2A34: BF870003
	v_fma_mix_f32 v3, v3, v30, neg(0) op_sel_hi:[1,0,0]        // 0000009B2A38: CC200003 8A023D03
	v_sub_f32_e32 v14, v14, v19                                // 0000009B2A40: 081C270E
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 0000009B2A44: 103030FF 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B2A4C: 7E5A02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 0000009B2A54: D501001F 200A3F1F
	v_mul_f32_e32 v30, 0xbfb8aa3b, v3                          // 0000009B2A5C: 103C06FF BFB8AA3B
	v_mov_b32_dpp v19, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B2A64: 7E2602FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 0000009B2A6C: D501000E 200A1D0E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B2A74: BF870215
	v_add_f32_e32 v43, 1.0, v43                                // 0000009B2A78: 065656F2
	v_exp_f32_e32 v30, v30                                     // 0000009B2A7C: 7E3C4B1E
	v_add_f32_e32 v31, v31, v45                                // 0000009B2A80: 063E5B1F
	v_mov_b32_dpp v45, v0 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B2A84: 7E5A02FA FF016200
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 0000009B2A8C: D5010000 200E0100
	v_div_scale_f32 v46, null, v43, v43, v2                    // 0000009B2A94: D6FC7C2E 040A572B
	s_waitcnt vmcnt(19)                                        // 0000009B2A9C: BF894FF7
	v_fma_mix_f32 v4, v4, v12, neg(0) op_sel_hi:[1,0,0]        // 0000009B2AA0: CC200004 8A021904
	v_mov_b32_dpp v48, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B2AA8: 7E6002FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 0000009B2AB0: D501001F 200E3F1F
	v_add_f32_e32 v0, v0, v45                                  // 0000009B2AB8: 06005B00
	v_rcp_f32_e32 v47, v46                                     // 0000009B2ABC: 7E5E552E
	v_add_f32_e32 v30, 1.0, v30                                // 0000009B2AC0: 063C3CF2
	v_fma_mix_f32 v6, v6, v11, neg(0) op_sel_hi:[1,0,0]        // 0000009B2AC4: CC200006 8A021706
	v_add_f32_e32 v31, v31, v48                                // 0000009B2ACC: 063E611F
	v_mov_b32_dpp v44, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B2AD0: 7E5802FA FF016400
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 0000009B2AD8: D5010000 20120100
	v_div_scale_f32 v45, null, v30, v30, v3                    // 0000009B2AE0: D6FC7C2D 040E3D1E
	v_add_f32_e32 v14, v14, v19                                // 0000009B2AE8: 061C270E
	v_mov_b32_dpp v50, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B2AEC: 7E6402FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 0000009B2AF4: D501001F 20123F1F
	v_add_f32_e32 v0, v0, v44                                  // 0000009B2AFC: 06005900
	v_rcp_f32_e32 v48, v45                                     // 0000009B2B00: 7E60552D
	v_add_f32_e32 v44, v15, v10                                // 0000009B2B04: 0658150F
	v_fma_f32 v49, -v46, v47, 1.0                              // 0000009B2B08: D6130031 23CA5F2E
	v_add_f32_e32 v31, v31, v50                                // 0000009B2B10: 063E651F
	v_sub_f32_e32 v10, v15, v10                                // 0000009B2B14: 0814150F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 0000009B2B18: BF8702C4
	v_mov_b32_dpp v51, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B2B1C: 7E6602FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 0000009B2B24: D501002C 200A592C
	v_fmac_f32_e32 v47, v49, v47                               // 0000009B2B2C: 565E5F31
	v_div_scale_f32 v49, vcc_lo, v2, v43, v2                   // 0000009B2B30: D6FC6A31 040A5702
	v_fma_f32 v50, -v45, v48, 1.0                              // 0000009B2B38: D6130032 23CA612D
	v_mov_b32_dpp v52, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B2B40: 7E6802FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 0000009B2B48: D501001F 20063F1F
	v_add_f32_e32 v44, v44, v51                                // 0000009B2B50: 0658672C
	v_mov_b32_dpp v51, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B2B54: 7E6602FA FF016800
	v_fmac_f32_e32 v48, v50, v48                               // 0000009B2B5C: 56606132
	v_div_scale_f32 v50, s5, v3, v30, v3                       // 0000009B2B60: D6FC0532 040E3D03
	v_dual_add_f32 v31, v31, v52 :: v_dual_mul_f32 v52, v49, v47// 0000009B2B68: C906691F 1F345F31
	v_mov_b32_dpp v54, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B2B70: 7E6C02FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 0000009B2B78: D501002C 200E592C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B2B80: BF870214
	v_mul_f32_e32 v53, v50, v48                                // 0000009B2B84: 106A6132
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 0000009B2B88: 103E3EFF 3DB504F3
	v_fma_f32 v55, -v46, v52, v49                              // 0000009B2B90: D6130037 24C6692E
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 0000009B2B98: D5010000 20060100
	v_add_f32_e32 v44, v44, v54                                // 0000009B2BA0: 06586D2C
	v_fma_f32 v56, -v45, v53, v50                              // 0000009B2BA4: D6130038 24CA6B2D
	v_fma_mix_f32 v5, v5, v31, neg(0) op_sel_hi:[1,0,0]        // 0000009B2BAC: CC200005 8A023F05
	v_fmac_f32_e32 v52, v55, v47                               // 0000009B2BB4: 56685F37
	v_add_f32_e32 v0, v0, v51                                  // 0000009B2BB8: 06006700
	v_mov_b32_dpp v31, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B2BBC: 7E3E02FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s4                       // 0000009B2BC4: D501002C 2012592C
	v_fmac_f32_e32 v53, v56, v48                               // 0000009B2BCC: 566A6138
	v_fma_f32 v46, -v46, v52, v49                              // 0000009B2BD0: D613002E 24C6692E
	v_mul_f32_e32 v51, 0xbfb8aa3b, v5                          // 0000009B2BD8: 10660AFF BFB8AA3B
	v_mov_b32_dpp v19, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B2BE0: 7E2602FA FF01610A
	v_add_f32_e32 v31, v44, v31                                // 0000009B2BE8: 063E3F2C
	v_fma_f32 v45, -v45, v53, v50                              // 0000009B2BEC: D613002D 24CA6B2D
	v_div_fmas_f32 v44, v46, v47, v52                          // 0000009B2BF4: D637002C 04D25F2E
	s_mov_b32 vcc_lo, s5                                       // 0000009B2BFC: BEEA0005
	v_exp_f32_e32 v49, v51                                     // 0000009B2C00: 7E624B33
	v_mov_b32_dpp v46, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B2C04: 7E5C02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 0000009B2C0C: D501001F 20063F1F
	v_div_fmas_f32 v45, v45, v48, v53                          // 0000009B2C14: D637002D 04D6612D
	v_div_fixup_f32 v2, v44, v43, v2                           // 0000009B2C1C: D6270002 040A572C
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 0000009B2C24: D501000A 200A150A
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000009B2C2C: 100000FF 3DB504F3
	v_add_f32_e32 v12, v31, v46                                // 0000009B2C34: 06185D1F
	v_mov_b32_dpp v31, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B2C38: 7E3E02FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 0000009B2C40: D501001D 200A3B1D
	v_div_fixup_f32 v3, v45, v30, v3                           // 0000009B2C48: D6270003 040E3D2D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009B2C50: BF870224
	v_dual_mul_f32 v2, v4, v2 :: v_dual_mul_f32 v11, 0x3db504f3, v12// 0000009B2C54: C8C60504 020A18FF 3DB504F3
	v_add_f32_e32 v10, v10, v19                                // 0000009B2C60: 0614270A
	v_add_f32_e32 v4, v29, v31                                 // 0000009B2C64: 06083F1D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B2C68: BF870004
	v_mul_f32_e32 v3, v6, v3                                   // 0000009B2C6C: 10060706
	v_add_f32_e32 v47, 1.0, v49                                // 0000009B2C70: 065E62F2
	s_waitcnt vmcnt(17)                                        // 0000009B2C74: BF8947F7
	v_fma_mix_f32 v6, v9, v11, neg(0) op_sel_hi:[1,0,0]        // 0000009B2C78: CC200006 8A021709
	v_add_f32_e32 v9, v20, v36                                 // 0000009B2C80: 06124914
	v_mov_b32_dpp v20, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B2C84: 7E2802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000009B2C8C: D5010004 200E0904
	v_fma_mix_f32 v3, v8, v3, neg(0) op_sel_hi:[1,0,0]         // 0000009B2C94: CC200003 8A020708
	v_mul_f32_e32 v8, 0xbfb8aa3b, v6                           // 0000009B2C9C: 10100CFF BFB8AA3B
	v_mov_b32_dpp v29, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B2CA4: 7E3A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000009B2CAC: D5010009 200E1309
	v_add_f32_e32 v4, v4, v20                                  // 0000009B2CB4: 06082904
	v_div_scale_f32 v30, null, v47, v47, v5                    // 0000009B2CB8: D6FC7C1E 04165F2F
	v_exp_f32_e32 v8, v8                                       // 0000009B2CC0: 7E104B08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009B2CC4: BF870193
	v_add_f32_e32 v9, v9, v29                                  // 0000009B2CC8: 06123B09
	v_mov_b32_dpp v15, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B2CCC: 7E1E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 0000009B2CD4: D5010004 20120904
	v_mov_b32_dpp v29, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B2CDC: 7E3A02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 0000009B2CE4: D501000E 200E1D0E
	v_mov_b32_dpp v20, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B2CEC: 7E2802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 0000009B2CF4: D5010009 20121309
	v_add_f32_e32 v4, v4, v15                                  // 0000009B2CFC: 06081F04
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B2D00: 7E1E02FA FF01620A
	v_add_f32_e32 v14, v14, v29                                // 0000009B2D08: 061C3B0E
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 0000009B2D0C: D501000A 200E150A
	v_add_f32_e32 v9, v9, v20                                  // 0000009B2D14: 06122909
	v_mov_b32_dpp v19, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B2D18: 7E2602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000009B2D20: D5010004 20060904
	v_mov_b32_dpp v20, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B2D28: 7E2802FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 0000009B2D30: D501000E 20121D0E
	v_add_f32_e32 v10, v10, v15                                // 0000009B2D38: 06141F0A
	v_rcp_f32_e32 v12, v30                                     // 0000009B2D3C: 7E18551E
	v_mov_b32_dpp v15, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B2D40: 7E1E02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000009B2D48: D5010009 20061309
	v_add_f32_e32 v4, v4, v19                                  // 0000009B2D50: 06082704
	v_add_f32_e32 v14, v14, v20                                // 0000009B2D54: 061C290E
	v_mov_b32_dpp v19, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B2D58: 7E2602FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 0000009B2D60: D501000A 2012150A
	v_dual_add_f32 v8, 1.0, v8 :: v_dual_add_f32 v9, v9, v15   // 0000009B2D68: C90810F2 08081F09
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009B2D70: BF870224
	v_mov_b32_dpp v15, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B2D74: 7E1E02FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 0000009B2D7C: D501000E 20061D0E
	v_add_f32_e32 v10, v10, v19                                // 0000009B2D84: 0614270A
	v_fma_f32 v11, -v30, v12, 1.0                              // 0000009B2D88: D613000B 23CA191E
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 0000009B2D90: 100808FF 3DB504F3
	v_div_scale_f32 v19, null, v8, v8, v6                      // 0000009B2D98: D6FC7C13 041A1108
	v_add_f32_e32 v14, v14, v15                                // 0000009B2DA0: 061C1F0E
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B2DA4: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 0000009B2DAC: D501000A 2006150A
	v_fmac_f32_e32 v12, v11, v12                               // 0000009B2DB4: 5618190B
	v_div_scale_f32 v11, vcc_lo, v5, v47, v5                   // 0000009B2DB8: D6FC6A0B 04165F05
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 0000009B2DC0: 101212FF 3DB504F3
	v_rcp_f32_e32 v20, v19                                     // 0000009B2DC8: 7E285513
	v_add_f32_e32 v10, v10, v15                                // 0000009B2DCC: 06141F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009B2DD0: BF8701B3
	v_dual_mul_f32 v14, 0x3db504f3, v14 :: v_dual_mul_f32 v15, v11, v12// 0000009B2DD4: C8C61CFF 0E0E190B 3DB504F3
	s_waitcnt vmcnt(12)                                        // 0000009B2DE0: BF8933F7
	v_fma_mix_f32 v9, v32, v9, neg(0) op_sel_hi:[1,0,0]        // 0000009B2DE4: CC200009 8A021320
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 0000009B2DEC: 101414FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009B2DF4: BF870003
	v_fma_f32 v31, -v30, v15, v11                              // 0000009B2DF8: D613001F 242E1F1E
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 0000009B2E00: CC200004 8A02091A
	s_waitcnt vmcnt(8)                                         // 0000009B2E08: BF8923F7
	v_fma_mix_f32 v14, v35, v14, neg(0) op_sel_hi:[1,0,0]      // 0000009B2E0C: CC20000E 8A021D23
	v_mul_f32_e32 v29, 0xbfb8aa3b, v9                          // 0000009B2E14: 103A12FF BFB8AA3B
	v_fma_f32 v32, -v19, v20, 1.0                              // 0000009B2E1C: D6130020 23CA2913
	v_fma_mix_f32 v10, v38, v10, neg(0) op_sel_hi:[1,0,0]      // 0000009B2E24: CC20000A 8A021526
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B2E2C: BF870214
	v_dual_mul_f32 v26, 0xbfb8aa3b, v4 :: v_dual_mul_f32 v35, 0xbfb8aa3b, v14// 0000009B2E30: C8C608FF 1A221CFF BFB8AA3B
	v_exp_f32_e32 v29, v29                                     // 0000009B2E3C: 7E3A4B1D
	v_fmac_f32_e32 v15, v31, v12                               // 0000009B2E40: 561E191F
	v_fmac_f32_e32 v20, v32, v20                               // 0000009B2E44: 56282920
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009B2E48: BF870003
	v_exp_f32_e32 v26, v26                                     // 0000009B2E4C: 7E344B1A
	v_mul_f32_e32 v32, 0xbfb8aa3b, v10                         // 0000009B2E50: 104014FF BFB8AA3B
	v_exp_f32_e32 v31, v35                                     // 0000009B2E58: 7E3E4B23
	v_fma_f32 v11, -v30, v15, v11                              // 0000009B2E5C: D613000B 242E1F1E
	v_div_scale_f32 v35, s5, v6, v8, v6                        // 0000009B2E64: D6FC0523 041A1106
	v_fma_mix_f32 v13, v33, v13, neg(0) op_sel_hi:[1,0,0]      // 0000009B2E6C: CC20000D 8A021B21
	v_exp_f32_e32 v30, v32                                     // 0000009B2E74: 7E3C4B20
	v_add_f32_e32 v29, 1.0, v29                                // 0000009B2E78: 063A3AF2
	v_div_fmas_f32 v11, v11, v12, v15                          // 0000009B2E7C: D637000B 043E190B
	v_mul_f32_e32 v32, v35, v20                                // 0000009B2E84: 10402923
	v_add_f32_e32 v26, 1.0, v26                                // 0000009B2E88: 063434F2
	s_mov_b32 vcc_lo, s5                                       // 0000009B2E8C: BEEA0005
	v_add_f32_e32 v31, 1.0, v31                                // 0000009B2E90: 063E3EF2
	v_div_scale_f32 v39, null, v29, v29, v9                    // 0000009B2E94: D6FC7C27 04263B1D
	v_fma_f32 v15, -v19, v32, v35                              // 0000009B2E9C: D613000F 248E4113
	v_div_scale_f32 v36, null, v26, v26, v4                    // 0000009B2EA4: D6FC7C24 0412351A
	v_add_f32_e32 v30, 1.0, v30                                // 0000009B2EAC: 063C3CF2
	v_div_scale_f32 v12, null, v31, v31, v14                   // 0000009B2EB0: D6FC7C0C 043A3F1F
	v_rcp_f32_e32 v43, v39                                     // 0000009B2EB8: 7E565527
	v_fmac_f32_e32 v32, v15, v20                               // 0000009B2EBC: 5640290F
	v_rcp_f32_e32 v38, v36                                     // 0000009B2EC0: 7E4C5524
	v_div_scale_f32 v33, null, v30, v30, v10                   // 0000009B2EC4: D6FC7C21 042A3D1E
	v_rcp_f32_e32 v45, v12                                     // 0000009B2ECC: 7E5A550C
	v_div_fixup_f32 v5, v11, v47, v5                           // 0000009B2ED0: D6270005 04165F0B
	v_div_scale_f32 v11, s6, v4, v26, v4                       // 0000009B2ED8: D6FC060B 04123504
	v_fma_f32 v19, -v19, v32, v35                              // 0000009B2EE0: D6130013 248E4113
	v_rcp_f32_e32 v15, v33                                     // 0000009B2EE8: 7E1E5521
	s_waitcnt vmcnt(7)                                         // 0000009B2EEC: BF891FF7
	v_fma_mix_f32 v21, v27, v21, neg(0) op_sel_hi:[1,0,0]      // 0000009B2EF0: CC200015 8A022B1B
	v_mul_f32_e32 v5, v13, v5                                  // 0000009B2EF8: 100A0B0D
	v_fma_mix_f32 v0, v25, v0, neg(0) op_sel_hi:[1,0,0]        // 0000009B2EFC: CC200000 8A020119
	v_fma_f32 v44, -v36, v38, 1.0                              // 0000009B2F04: D613002C 23CA4D24
	v_div_fmas_f32 v19, v19, v20, v32                          // 0000009B2F0C: D6370013 04822913
	v_fma_f32 v13, -v12, v45, 1.0                              // 0000009B2F14: D613000D 23CA5B0C
	s_mov_b32 vcc_lo, s6                                       // 0000009B2F1C: BEEA0006
	v_fma_mix_f32 v7, v7, v18, neg(0) op_sel_hi:[1,0,0]        // 0000009B2F20: CC200007 8A022507
	v_fmac_f32_e32 v38, v44, v38                               // 0000009B2F28: 564C4D2C
	v_fma_f32 v44, -v39, v43, 1.0                              // 0000009B2F2C: D613002C 23CA5727
	v_fma_f32 v46, -v33, v15, 1.0                              // 0000009B2F34: D613002E 23CA1F21
	v_fmac_f32_e32 v45, v13, v45                               // 0000009B2F3C: 565A5B0D
	v_div_scale_f32 v13, s8, v14, v31, v14                     // 0000009B2F40: D6FC080D 043A3F0E
	v_mul_f32_e32 v35, v11, v38                                // 0000009B2F48: 10464D0B
	v_fmac_f32_e32 v43, v44, v43                               // 0000009B2F4C: 5656572C
	v_div_scale_f32 v44, s7, v9, v29, v9                       // 0000009B2F50: D6FC072C 04263B09
	v_fmac_f32_e32 v15, v46, v15                               // 0000009B2F58: 561E1F2E
	v_div_scale_f32 v46, s5, v10, v30, v10                     // 0000009B2F5C: D6FC052E 042A3D0A
	v_fma_f32 v20, -v36, v35, v11                              // 0000009B2F64: D6130014 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009B2F6C: BF8701A4
	v_dual_mul_f32 v47, v13, v45 :: v_dual_mul_f32 v32, v44, v43// 0000009B2F70: C8C65B0D 2F20572C
	v_div_fixup_f32 v6, v19, v8, v6                            // 0000009B2F78: D6270006 041A1113
	v_dual_fmac_f32 v35, v20, v38 :: v_dual_mul_f32 v20, v46, v15// 0000009B2F80: C8064D14 23141F2E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B2F88: BF870213
	v_fma_f32 v8, -v39, v32, v44                               // 0000009B2F8C: D6130008 24B24127
	v_fma_f32 v19, -v12, v47, v13                              // 0000009B2F94: D6130013 24365F0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B2F9C: BF870214
	v_mul_f32_e32 v6, v21, v6                                  // 0000009B2FA0: 100C0D15
	v_fma_f32 v11, -v36, v35, v11                              // 0000009B2FA4: D613000B 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009B2FAC: BF870234
	v_fmac_f32_e32 v32, v8, v43                                // 0000009B2FB0: 56405708
	v_fma_f32 v8, -v33, v20, v46                               // 0000009B2FB4: D6130008 24BA2921
	v_fmac_f32_e32 v47, v19, v45                               // 0000009B2FBC: 565E5B13
	v_div_fmas_f32 v11, v11, v38, v35                          // 0000009B2FC0: D637000B 048E4D0B
	s_mov_b32 vcc_lo, s7                                       // 0000009B2FC8: BEEA0007
	v_fma_f32 v19, -v39, v32, v44                              // 0000009B2FCC: D6130013 24B24127
	v_fmac_f32_e32 v20, v8, v15                                // 0000009B2FD4: 56281F08
	v_fma_f32 v8, -v12, v47, v13                               // 0000009B2FD8: D6130008 24365F0C
	v_div_fixup_f32 v4, v11, v26, v4                           // 0000009B2FE0: D6270004 0412350B
	v_fma_mix_f32 v11, v34, v17, neg(0) op_sel_hi:[1,0,0]      // 0000009B2FE8: CC20000B 8A022322
	v_div_fmas_f32 v12, v19, v43, v32                          // 0000009B2FF0: D637000C 04825713
	v_fma_f32 v13, -v33, v20, v46                              // 0000009B2FF8: D613000D 24BA2921
	s_mov_b32 vcc_lo, s8                                       // 0000009B3000: BEEA0008
	s_waitcnt vmcnt(0)                                         // 0000009B3004: BF8903F7
	v_fma_mix_f32 v6, v23, v6, neg(0) op_sel_hi:[1,0,0]        // 0000009B3008: CC200006 8A020D17
	v_div_fmas_f32 v8, v8, v45, v47                            // 0000009B3010: D6370008 04BE5B08
	s_mov_b32 vcc_lo, s5                                       // 0000009B3018: BEEA0005
	v_div_fixup_f32 v9, v12, v29, v9                           // 0000009B301C: D6270009 04263B0C
	v_div_fmas_f32 v13, v13, v15, v20                          // 0000009B3024: D637000D 04521F0D
	v_fma_mix_f32 v12, v22, v24, neg(0) op_sel_hi:[1,0,0]      // 0000009B302C: CC20000C 8A023116
	v_div_fixup_f32 v8, v8, v31, v14                           // 0000009B3034: D6270008 043A3F08
	v_mul_f32_e32 v4, v7, v4                                   // 0000009B303C: 10080907
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009B3040: BF870194
	v_div_fixup_f32 v10, v13, v30, v10                         // 0000009B3044: D627000A 042A3D0D
	v_dual_mul_f32 v9, v12, v9 :: v_dual_mul_f32 v8, v11, v8   // 0000009B304C: C8C6130C 0908110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009B3054: BF870112
	v_mul_f32_e32 v0, v0, v10                                  // 0000009B3058: 10001500
	v_fma_mix_f32 v7, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 0000009B305C: CC200007 8A02131C
	v_fma_mix_f32 v9, v2, v37, v3 op_sel_hi:[0,1,0]            // 0000009B3064: CC200009 140E4B02
	v_fma_mix_f32 v10, v5, v40, v6 op_sel_hi:[0,1,0]           // 0000009B306C: CC20000A 141A5105
	v_fma_mix_f32 v2, v2, v37, -v3 op_sel_hi:[0,1,0]           // 0000009B3074: CC200002 940E4B02
	v_fma_mix_f32 v0, v16, v0, neg(0) op_sel_hi:[1,0,0]        // 0000009B307C: CC200000 8A020110
	v_fma_mix_f32 v11, v4, v41, v7 op_sel_hi:[0,1,0]           // 0000009B3084: CC20000B 141E5304
	v_fma_mix_f32 v3, v5, v40, -v6 op_sel_hi:[0,1,0]           // 0000009B308C: CC200003 941A5105
	v_fma_mix_f32 v4, v4, v41, -v7 op_sel_hi:[0,1,0]           // 0000009B3094: CC200004 941E5304
	v_add_f32_e32 v5, v9, v10                                  // 0000009B309C: 060A1509
	v_fma_mix_f32 v12, v8, v42, v0 op_sel_hi:[0,1,0]           // 0000009B30A0: CC20000C 14025508
	v_fma_mix_f32 v0, v8, v42, -v0 op_sel_hi:[0,1,0]           // 0000009B30A8: CC200000 94025508
	v_dual_sub_f32 v7, v9, v10 :: v_dual_add_f32 v8, v2, v3    // 0000009B30B0: C9481509 07080702
	v_sub_f32_e32 v2, v2, v3                                   // 0000009B30B8: 08040702
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009B30BC: BF8701B4
	v_add_f32_e32 v6, v11, v12                                 // 0000009B30C0: 060C190B
	v_sub_f32_e32 v9, v11, v12                                 // 0000009B30C4: 0812190B
	v_add_f32_e32 v10, v4, v0                                  // 0000009B30C8: 06140104
	v_dual_sub_f32 v0, v4, v0 :: v_dual_add_f32 v3, v5, v6     // 0000009B30CC: C9480104 00020D05
	v_sub_f32_e32 v4, v5, v6                                   // 0000009B30D4: 08080D05
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009B30D8: BF870003
	v_add_f32_e32 v6, v8, v10                                  // 0000009B30DC: 060C1508
	v_sub_f32_e32 v8, v8, v10                                  // 0000009B30E0: 08101508
	v_add_f32_e32 v10, v7, v9                                  // 0000009B30E4: 06141307
	v_mov_b32_dpp v5, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B30E8: 7E0A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 0000009B30F0: D5010003 200A0703
	v_sub_f32_e32 v7, v7, v9                                   // 0000009B30F8: 080E1307
	v_mov_b32_dpp v14, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B30FC: 7E1C02FA FF016104
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B3104: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 0000009B310C: D501000A 200A150A
	v_add_f32_e32 v3, v3, v5                                   // 0000009B3114: 06060B03
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B3118: 7E0A02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 0000009B3120: D5010006 200A0D06
	v_cndmask_b32_e64 v15, -v4, v4, s2                         // 0000009B3128: D501000F 200A0904
	v_add_f32_e32 v9, v10, v9                                  // 0000009B3130: 0612130A
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B3134: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 0000009B313C: D5010003 200E0703
	v_add_f32_e32 v5, v6, v5                                   // 0000009B3144: 060A0B06
	v_add_f32_e32 v6, v2, v0                                   // 0000009B3148: 060C0102
	v_sub_f32_e32 v10, v2, v0                                  // 0000009B314C: 08140102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B3150: BF870214
	v_add_f32_e32 v0, v3, v11                                  // 0000009B3154: 06001703
	v_mov_b32_dpp v2, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B3158: 7E0402FA FF016205
	v_cndmask_b32_e64 v3, -v5, v5, s3                          // 0000009B3160: D5010003 200E0B05
	v_mov_b32_dpp v5, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B3168: 7E0A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000009B3170: D5010009 200E1309
	v_mov_b32_dpp v11, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B3178: 7E1602FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 0000009B3180: D5010006 200A0D06
	v_add_f32_e32 v2, v3, v2                                   // 0000009B3188: 06040503
	v_mov_b32_dpp v16, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B318C: 7E2002FA FF01610A
	v_add_f32_e32 v5, v9, v5                                   // 0000009B3194: 060A0B09
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 0000009B3198: D501000A 200A150A
	v_add_f32_e32 v6, v6, v11                                  // 0000009B31A0: 060C1706
	v_mov_b32_dpp v9, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B31A4: 7E1202FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 0000009B31AC: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B31B4: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 0000009B31BC: D5010005 20120B05
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B31C4: 7E1802FA FF016206
	v_cndmask_b32_e64 v13, -v6, v6, s3                         // 0000009B31CC: D501000D 200E0D06
	v_add_f32_e32 v4, v2, v9                                   // 0000009B31D4: 06081302
	v_add_f32_e32 v10, v10, v16                                // 0000009B31D8: 0614210A
	v_dual_add_f32 v6, v5, v11 :: v_dual_add_f32 v11, v15, v14 // 0000009B31DC: C9081705 060A1D0F
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B31E4: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 0000009B31EC: D5010008 200A1108
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B31F4: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 0000009B31FC: D5010007 200A0F07
	v_add_f32_e32 v9, v13, v12                                 // 0000009B3204: 0612190D
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B3208: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 0000009B3210: D501000B 200E170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009B3218: BF870234
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v7, v15   // 0000009B321C: C9081D08 08061F07
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B3224: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 0000009B322C: D501000A 200E150A
	v_add_f32_e32 v11, v11, v13                                // 0000009B3234: 06161B0B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B3238: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B323C: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 0000009B3244: D5010008 200E1108
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B324C: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 0000009B3254: D5010007 200E0F07
	v_add_f32_e32 v10, v10, v15                                // 0000009B325C: 06141F0A
	v_mov_b32_dpp v3, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B3260: 7E0602FA FF016400
	v_add_f32_e32 v8, v8, v13                                  // 0000009B3268: 06101B08
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 0000009B326C: D5010000 20120100
	v_add_f32_e32 v7, v7, v14                                  // 0000009B3274: 060E1D07
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B3278: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 0000009B3280: D5010009 20121309
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B3288: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 0000009B3290: D501000B 2012170B
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B3298: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 0000009B32A0: D5010008 20121108
	v_mov_b32_dpp v15, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B32A8: 7E1E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 0000009B32B0: D5010007 20120F07
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B32B8: 7E2002FA FF01640A
	v_cndmask_b32_e64 v17, -v10, v10, s4                       // 0000009B32C0: D5010011 2012150A
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v9, v9, v12    // 0000009B32C8: C9080700 00081909
	v_dual_add_f32 v10, v11, v13 :: v_dual_add_f32 v11, v8, v14// 0000009B32D0: C9081B0B 0A0A1D08
	v_add_f32_e32 v13, v7, v15                                 // 0000009B32D8: 061A1F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B32DC: BF870214
	v_add_f32_e32 v15, v17, v16                                // 0000009B32E0: 061E2111
	v_mov_b32_dpp v2, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B32E4: 7E0402FA FF016800
	v_mov_b32_dpp v3, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B32EC: 7E0602FA FF016804
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B32F4: 7E0A02FA FF016806
	v_mov_b32_dpp v7, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B32FC: 7E0E02FA FF016809
	v_mov_b32_dpp v8, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B3304: 7E1002FA FF01680A
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B330C: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B3314: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B331C: 7E2002FA FF01680F
	s_mov_b32 s2, 0x3db504f3                                   // 0000009B3324: BE8200FF 3DB504F3
	s_and_b32 exec_lo, exec_lo, s0                             // 0000009B332C: 8B7E007E
	s_cbranch_execz 65                                         // 0000009B3330: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x3c38>
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 0000009B3334: D501000F 20061F0F
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 0000009B333C: D5010000 20060100
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000009B3344: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000009B334C: D5010006 20060D06
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000009B3354: D5010009 20061309
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 0000009B335C: D501000D 20061B0D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 0000009B3364: D501000A 2006150A
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 0000009B336C: D501000B 2006170B
	v_dual_add_f32 v15, v15, v16 :: v_dual_add_f32 v0, v0, v2  // 0000009B3374: C908210F 0F000500
	v_add_f32_e32 v3, v4, v3                                   // 0000009B337C: 06060704
	v_add_f32_e32 v5, v6, v5                                   // 0000009B3380: 060A0B06
	v_add_f32_e32 v7, v9, v7                                   // 0000009B3384: 060E0F09
	s_mul_i32 s0, s16, 0x500                                   // 0000009B3388: 9600FF10 00000500
	v_dual_add_f32 v13, v13, v14 :: v_dual_add_f32 v8, v10, v8 // 0000009B3390: C9081D0D 0D08110A
	s_mul_hi_i32 s1, s16, 0x500                                // 0000009B3398: 9701FF10 00000500
	v_add_f32_e32 v11, v11, v12                                // 0000009B33A0: 0616190B
	s_add_u32 s0, s14, s0                                      // 0000009B33A4: 8000000E
	v_fma_mixlo_f16 v0, v0, s2, 0                              // 0000009B33A8: CC210000 02000500
	s_addc_u32 s1, s15, s1                                     // 0000009B33B0: 8201010F
	v_fma_mixhi_f16 v0, v3, s2, 0                              // 0000009B33B4: CC220000 02000503
	s_add_u32 s0, s0, s10                                      // 0000009B33BC: 80000A00
	v_fma_mixlo_f16 v2, v5, s2, 0                              // 0000009B33C0: CC210002 02000505
	s_addc_u32 s1, s1, s11                                     // 0000009B33C8: 82010B01
	v_fma_mixhi_f16 v2, v7, s2, 0                              // 0000009B33CC: CC220002 02000507
	v_fma_mixlo_f16 v3, v8, s2, 0                              // 0000009B33D4: CC210003 02000508
	v_fma_mixhi_f16 v3, v11, s2, 0                             // 0000009B33DC: CC220003 0200050B
	v_fma_mixlo_f16 v4, v13, s2, 0                             // 0000009B33E4: CC210004 0200050D
	v_fma_mixhi_f16 v4, v15, s2, 0                             // 0000009B33EC: CC220004 0200050F
	s_clause 0x7                                               // 0000009B33F4: BF850007
	global_store_b16 v1, v0, s[0:1]                            // 0000009B33F8: DC660000 00000001
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 0000009B3400: DC960020 00000001
	global_store_b16 v1, v2, s[0:1] offset:64                  // 0000009B3408: DC660040 00000201
	global_store_d16_hi_b16 v1, v2, s[0:1] offset:96           // 0000009B3410: DC960060 00000201
	global_store_b16 v1, v3, s[0:1] offset:128                 // 0000009B3418: DC660080 00000301
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:160          // 0000009B3420: DC9600A0 00000301
	global_store_b16 v1, v4, s[0:1] offset:192                 // 0000009B3428: DC6600C0 00000401
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:224          // 0000009B3430: DC9600E0 00000401
	s_nop 0                                                    // 0000009B3438: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000009B343C: BFB60003
	s_endpgm                                                   // 0000009B3440: BFB00000
		...

