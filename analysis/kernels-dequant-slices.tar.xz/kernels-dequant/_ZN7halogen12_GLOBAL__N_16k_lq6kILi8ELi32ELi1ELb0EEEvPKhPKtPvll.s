00000000005ac100 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi32ELi1ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi32ELi1ELb0EEEvPKhPKtPvll():
	s_clause 0x1                                               // 0000005AC100: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 0000005AC104: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000005AC10C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 0000005AC114: BE830080
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000005AC118: 32020085
	s_lshl_b64 s[0:1], s[2:3], 3                               // 0000005AC11C: 84808302
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000005AC120: CA100080 08080080
	v_dual_mov_b32 v2, s1 :: v_dual_and_b32 v7, 31, v0         // 0000005AC128: CA240001 0206009F
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v10, 0             // 0000005AC130: CA100080 0B0A0080
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v12, 0             // 0000005AC138: CA100080 0D0C0080
	v_or_b32_e32 v1, s0, v1                                    // 0000005AC140: 38020200
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v15, 0             // 0000005AC144: CA100080 0E0E0080
	s_waitcnt lgkmcnt(0)                                       // 0000005AC14C: BF89FC07
	s_ashr_i32 s1, s11, 31                                     // 0000005AC150: 86019F0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000005AC154: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000005AC158: 7CA8020C
	s_lshr_b32 s1, s1, 28                                      // 0000005AC15C: 85019C01
	s_add_u32 s0, s10, s1                                      // 0000005AC160: 8000010A
	s_addc_u32 s1, s11, 0                                      // 0000005AC164: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005AC168: BF870009
	s_lshr_b64 s[14:15], s[0:1], 4                             // 0000005AC16C: 858E8400
	s_mov_b32 s1, exec_lo                                      // 0000005AC170: BE81007E
	.long 0xd4c4007e                                           // 0000005AC174: D4C4007E
	v_cndmask_b32_e32 v1, s14, v7, vcc_lo                      // 0000005AC178: 02020E0E
	s_cbranch_execz 664                                        // 0000005AC17C: BFA50298 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi32ELi1ELb0EEEvPKhPKtPvll+0xae0>
	s_ashr_i32 s0, s11, 31                                     // 0000005AC180: 86009F0B
	v_dual_cndmask_b32 v3, 0, v2 :: v_dual_and_b32 v16, 6, v0  // 0000005AC184: CA640480 03100086
	s_lshr_b32 s0, s0, 24                                      // 0000005AC18C: 85009800
	v_cndmask_b32_e32 v5, 0, v1, vcc_lo                        // 0000005AC190: 020A0280
	s_add_u32 s16, s10, s0                                     // 0000005AC194: 8010000A
	s_addc_u32 s17, s11, 0                                     // 0000005AC198: 8211800B
	v_bfe_u32 v9, v0, 3, 1                                     // 0000005AC19C: D6100009 02050700
	s_ashr_i64 s[16:17], s[16:17], 8                           // 0000005AC1A4: 86908810
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v17, 4, v0          // 0000005AC1A8: CA240080 06100084
	s_mul_i32 s0, s17, 0xd2                                    // 0000005AC1B0: 9600FF11 000000D2
	s_mul_hi_u32 s2, s16, 0xd2                                 // 0000005AC1B8: 9682FF10 000000D2
	s_mul_i32 s15, s16, 0xd2                                   // 0000005AC1C0: 960FFF10 000000D2
	s_add_i32 s2, s2, s0                                       // 0000005AC1C8: 81020002
	.long 0xd72c0008                                           // 0000005AC1CC: D72C0008
	v_cndmask_b32_e32 v1, s15, v3, vcc_lo                      // 0000005AC1D0: 0202060F
	v_and_b32_e32 v0, 15, v0                                   // 0000005AC1D4: 3600008F
	v_mad_u64_u32 v[3:4], null, s15, v5, s[4:5]                // 0000005AC1D8: D6FE7C03 00120A0F
	.long 0xd72c0005                                           // 0000005AC1E0: D72C0005
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000005AC1E4: 02020A02
	v_dual_mov_b32 v27, v7 :: v_dual_lshlrev_b32 v18, 6, v9    // 0000005AC1E8: CA220107 1B121286
	v_dual_mov_b32 v14, v6 :: v_dual_lshlrev_b32 v19, 5, v9    // 0000005AC1F0: CA220106 0E121285
	v_or_b32_e32 v20, 8, v17                                   // 0000005AC1F8: 38282288
	v_or_b32_e32 v21, 8, v16                                   // 0000005AC1FC: 382A2088
	v_or_b32_e32 v22, 16, v17                                  // 0000005AC200: 382C2290
	v_add3_u32 v4, v5, v4, v8                                  // 0000005AC204: D6550004 04220905
	v_lshrrev_b32_e32 v8, 4, v7                                // 0000005AC20C: 32100E84
	v_or_b32_e32 v23, 16, v16                                  // 0000005AC210: 382E2090
	v_or_b32_e32 v24, 24, v17                                  // 0000005AC214: 38302298
	v_or_b32_e32 v25, 24, v16                                  // 0000005AC218: 38322098
	v_dual_mov_b32 v12, v6 :: v_dual_lshlrev_b32 v5, 4, v7     // 0000005AC21C: CA220106 0C040E84
	v_mul_u32_u24_e32 v26, 0xd2, v8                            // 0000005AC224: 163410FF 000000D2
	v_mov_b32_e32 v15, v6                                      // 0000005AC22C: 7E1E0306
	v_mov_b32_e32 v13, v6                                      // 0000005AC230: 7E1A0306
	v_mov_b32_e32 v10, v6                                      // 0000005AC234: 7E140306
	v_mov_b32_e32 v11, v6                                      // 0000005AC238: 7E160306
	v_mov_b32_e32 v9, v6                                       // 0000005AC23C: 7E120306
	v_mov_b32_e32 v8, v6                                       // 0000005AC240: 7E100306
	s_mul_i32 s0, s11, 6                                       // 0000005AC244: 9600860B
	s_mul_hi_u32 s2, s10, 6                                    // 0000005AC248: 9682860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000005AC24C: 8484820A
	s_add_i32 s2, s2, s0                                       // 0000005AC250: 81020002
	s_mul_i32 s15, s10, 6                                      // 0000005AC254: 960F860A
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000005AC258: 848A810A
	.long 0xd700001c                                           // 0000005AC25C: D700001C
	v_cndmask_b32_e32 v1, v3, v26, vcc_lo                      // 0000005AC260: 02023503
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005AC264: BF8701A1
	v_add_co_ci_u32_e64 v29, null, 0, v4, s0                   // 0000005AC268: D5207C1D 00020880
	v_and_b32_e32 v32, 32, v5                                  // 0000005AC270: 36400AA0
	.long 0xd700001e                                           // 0000005AC274: D700001E
	v_cndmask_b32_e32 v1, v28, v18, vcc_lo                     // 0000005AC278: 0202251C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005AC27C: BF8701A1
	v_add_co_ci_u32_e64 v31, null, 0, v29, s0                  // 0000005AC280: D5207C1F 00023A80
	v_and_b32_e32 v36, 16, v5                                  // 0000005AC288: 36480A90
	.long 0xd700001e                                           // 0000005AC28C: D700001E
	v_cndmask_b32_e32 v1, v30, v32, vcc_lo                     // 0000005AC290: 0202411E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005AC294: BF8701A1
	v_add_co_ci_u32_e64 v31, null, 0, v31, s0                  // 0000005AC298: D5207C1F 00023E80
	v_add_nc_u32_e32 v26, 0x1a4, v26                           // 0000005AC2A0: 4A3434FF 000001A4
	.long 0xd700001e                                           // 0000005AC2A8: D700001E
	v_cndmask_b32_e32 v1, v30, v36, vcc_lo                     // 0000005AC2AC: 0202491E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000005AC2B0: BF8700C1
	v_add_co_ci_u32_e64 v31, null, 0, v31, s0                  // 0000005AC2B4: D5207C1F 00023E80
	v_add_nc_u32_e32 v27, 32, v27                              // 0000005AC2BC: 4A3636A0
	global_load_b128 v[32:35], v[30:31], off                   // 0000005AC2C0: DC5E0000 207C001E
	.long 0xd700001e                                           // 0000005AC2C8: D700001E
	v_cndmask_b32_e32 v1, v28, v19, vcc_lo                     // 0000005AC2CC: 0202271C
	v_add_co_ci_u32_e64 v31, null, 0, v29, s0                  // 0000005AC2D0: D5207C1F 00023A80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC2D8: BF870092
	.long 0xd700001e                                           // 0000005AC2DC: D700001E
	v_cndmask_b32_e32 v1, v30, v36, vcc_lo                     // 0000005AC2E0: 0202491E
	v_add_co_ci_u32_e64 v31, null, 0, v31, s0                  // 0000005AC2E4: D5207C1F 00023E80
	global_load_b128 v[36:39], v[30:31], off offset:128        // 0000005AC2EC: DC5E0080 247C001E
	.long 0xd700001e                                           // 0000005AC2F4: D700001E
	v_cndmask_b32_e32 v1, v28, v0, vcc_lo                      // 0000005AC2F8: 0202011C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005AC2FC: BF870001
	v_add_co_ci_u32_e64 v31, null, 0, v29, s0                  // 0000005AC300: D5207C1F 00023A80
	s_clause 0x1                                               // 0000005AC308: BF850001
	global_load_d16_b16 v28, v[28:29], off offset:208          // 0000005AC30C: DC8200D0 1C7C001C
	global_load_i8 v30, v[30:31], off offset:192               // 0000005AC314: DC4600C0 1E7C001E
	s_waitcnt vmcnt(2)                                         // 0000005AC31C: BF890BF7
	v_lshrrev_b32_e32 v29, v16, v36                            // 0000005AC320: 323A4910
	v_lshrrev_b32_e32 v31, v23, v36                            // 0000005AC324: 323E4917
	s_waitcnt vmcnt(0)                                         // 0000005AC328: BF8903F7
	v_cvt_f32_i32_e32 v30, v30                                 // 0000005AC32C: 7E3C0B1E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000005AC330: BF870141
	v_fma_mix_f32 v40, v28, v30, neg(0) op_sel_hi:[1,0,0]      // 0000005AC334: CC200028 8A023D1C
	v_bfe_u32 v28, v32, v17, 4                                 // 0000005AC33C: D610001C 02122320
	v_lshlrev_b32_e32 v29, 4, v29                              // 0000005AC344: 303A3A84
	v_lshlrev_b32_e32 v31, 4, v31                              // 0000005AC348: 303E3E84
	v_and_or_b32 v28, v29, 48, v28                             // 0000005AC34C: D657001C 0471611D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC354: BF870091
	v_subrev_nc_u32_e32 v28, 32, v28                           // 0000005AC358: 4E3838A0
	v_cvt_f32_i32_e32 v28, v28                                 // 0000005AC35C: 7E380B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC360: BF870091
	v_mul_f32_e32 v28, v40, v28                                // 0000005AC364: 10383928
	v_bfe_u32 v29, v28, 16, 1                                  // 0000005AC368: D610001D 0205211C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000005AC370: BF870131
	v_add3_u32 v30, v28, v29, 0x7fff                           // 0000005AC374: D655001E 03FE3B1C 00007FFF
	v_lshrrev_b32_e32 v29, v21, v36                            // 0000005AC380: 323A4915
	v_bfe_u32 v28, v32, v20, 4                                 // 0000005AC384: D610001C 02122920
	v_lshlrev_b32_e32 v29, 4, v29                              // 0000005AC38C: 303A3A84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC390: BF870091
	v_and_or_b32 v28, v29, 48, v28                             // 0000005AC394: D657001C 0471611D
	v_subrev_nc_u32_e32 v28, 32, v28                           // 0000005AC39C: 4E3838A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC3A0: BF870091
	v_cvt_f32_i32_e32 v28, v28                                 // 0000005AC3A4: 7E380B1C
	v_mul_f32_e32 v28, v40, v28                                // 0000005AC3A8: 10383928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC3AC: BF870091
	v_bfe_u32 v29, v28, 16, 1                                  // 0000005AC3B0: D610001D 0205211C
	v_add3_u32 v28, v28, v29, 0x7fff                           // 0000005AC3B8: D655001C 03FE3B1C 00007FFF
	v_bfe_u32 v29, v32, v22, 4                                 // 0000005AC3C4: D610001D 02122D20
	.long 0x7e38399e                                           // 0000005AC3CC: 7E38399E
	v_bfe_u32 v30, v33, v17, 4                                 // 0000005AC3D0: D610001E 02122321
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC3D8: BF870093
	v_and_or_b32 v29, v31, 48, v29                             // 0000005AC3DC: D657001D 0475611F
	v_subrev_nc_u32_e32 v29, 32, v29                           // 0000005AC3E4: 4E3A3AA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC3E8: BF870091
	v_cvt_f32_i32_e32 v29, v29                                 // 0000005AC3EC: 7E3A0B1D
	v_mul_f32_e32 v29, v40, v29                                // 0000005AC3F0: 103A3B28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC3F4: BF870091
	v_bfe_u32 v31, v29, 16, 1                                  // 0000005AC3F8: D610001F 0205211D
	v_add3_u32 v31, v29, v31, 0x7fff                           // 0000005AC400: D655001F 03FE3F1D 00007FFF
	v_bfe_u32 v29, v32, v24, 4                                 // 0000005AC40C: D610001D 02123120
	v_lshrrev_b32_e32 v32, v25, v36                            // 0000005AC414: 32404919
	v_lshrrev_b32_e32 v36, v23, v37                            // 0000005AC418: 32484B17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005AC41C: BF870112
	v_lshlrev_b32_e32 v32, 4, v32                              // 0000005AC420: 30404084
	v_lshlrev_b32_e32 v36, 4, v36                              // 0000005AC424: 30484884
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC428: BF870092
	v_and_or_b32 v29, v32, 48, v29                             // 0000005AC42C: D657001D 04756120
	v_subrev_nc_u32_e32 v29, 32, v29                           // 0000005AC434: 4E3A3AA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC438: BF870091
	v_cvt_f32_i32_e32 v29, v29                                 // 0000005AC43C: 7E3A0B1D
	v_mul_f32_e32 v29, v40, v29                                // 0000005AC440: 103A3B28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC444: BF870091
	v_bfe_u32 v32, v29, 16, 1                                  // 0000005AC448: D6100020 0205211D
	v_add3_u32 v29, v29, v32, 0x7fff                           // 0000005AC450: D655001D 03FE411D 00007FFF
	.long 0x7e3a399f                                           // 0000005AC45C: 7E3A399F
	v_lshrrev_b32_e32 v31, v16, v37                            // 0000005AC460: 323E4B10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC464: BF870091
	v_lshlrev_b32_e32 v31, 4, v31                              // 0000005AC468: 303E3E84
	v_and_or_b32 v30, v31, 48, v30                             // 0000005AC46C: D657001E 0479611F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC474: BF870091
	v_subrev_nc_u32_e32 v30, 32, v30                           // 0000005AC478: 4E3C3CA0
	v_cvt_f32_i32_e32 v30, v30                                 // 0000005AC47C: 7E3C0B1E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC480: BF870091
	v_mul_f32_e32 v30, v40, v30                                // 0000005AC484: 103C3D28
	v_bfe_u32 v31, v30, 16, 1                                  // 0000005AC488: D610001F 0205211E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000005AC490: BF870131
	v_add3_u32 v32, v30, v31, 0x7fff                           // 0000005AC494: D6550020 03FE3F1E 00007FFF
	v_lshrrev_b32_e32 v31, v21, v37                            // 0000005AC4A0: 323E4B15
	v_bfe_u32 v30, v33, v20, 4                                 // 0000005AC4A4: D610001E 02122921
	v_lshlrev_b32_e32 v31, 4, v31                              // 0000005AC4AC: 303E3E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC4B0: BF870091
	v_and_or_b32 v30, v31, 48, v30                             // 0000005AC4B4: D657001E 0479611F
	v_subrev_nc_u32_e32 v30, 32, v30                           // 0000005AC4BC: 4E3C3CA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC4C0: BF870091
	v_cvt_f32_i32_e32 v30, v30                                 // 0000005AC4C4: 7E3C0B1E
	v_mul_f32_e32 v30, v40, v30                                // 0000005AC4C8: 103C3D28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC4CC: BF870091
	v_bfe_u32 v31, v30, 16, 1                                  // 0000005AC4D0: D610001F 0205211E
	v_add3_u32 v30, v30, v31, 0x7fff                           // 0000005AC4D8: D655001E 03FE3F1E 00007FFF
	v_bfe_u32 v31, v33, v22, 4                                 // 0000005AC4E4: D610001F 02122D21
	.long 0x7e3c39a0                                           // 0000005AC4EC: 7E3C39A0
	v_bfe_u32 v32, v34, v17, 4                                 // 0000005AC4F0: D6100020 02122322
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC4F8: BF870093
	v_and_or_b32 v31, v36, 48, v31                             // 0000005AC4FC: D657001F 047D6124
	v_subrev_nc_u32_e32 v31, 32, v31                           // 0000005AC504: 4E3E3EA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC508: BF870091
	v_cvt_f32_i32_e32 v31, v31                                 // 0000005AC50C: 7E3E0B1F
	v_mul_f32_e32 v31, v40, v31                                // 0000005AC510: 103E3F28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC514: BF870091
	v_bfe_u32 v36, v31, 16, 1                                  // 0000005AC518: D6100024 0205211F
	v_add3_u32 v36, v31, v36, 0x7fff                           // 0000005AC520: D6550024 03FE491F 00007FFF
	v_bfe_u32 v31, v33, v24, 4                                 // 0000005AC52C: D610001F 02123121
	v_lshrrev_b32_e32 v33, v25, v37                            // 0000005AC534: 32424B19
	v_lshrrev_b32_e32 v37, v23, v38                            // 0000005AC538: 324A4D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005AC53C: BF870112
	v_lshlrev_b32_e32 v33, 4, v33                              // 0000005AC540: 30424284
	v_lshlrev_b32_e32 v37, 4, v37                              // 0000005AC544: 304A4A84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC548: BF870092
	v_and_or_b32 v31, v33, 48, v31                             // 0000005AC54C: D657001F 047D6121
	v_subrev_nc_u32_e32 v31, 32, v31                           // 0000005AC554: 4E3E3EA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC558: BF870091
	v_cvt_f32_i32_e32 v31, v31                                 // 0000005AC55C: 7E3E0B1F
	v_mul_f32_e32 v31, v40, v31                                // 0000005AC560: 103E3F28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC564: BF870091
	v_bfe_u32 v33, v31, 16, 1                                  // 0000005AC568: D6100021 0205211F
	v_add3_u32 v31, v31, v33, 0x7fff                           // 0000005AC570: D655001F 03FE431F 00007FFF
	v_lshrrev_b32_e32 v33, v16, v38                            // 0000005AC57C: 32424D10
	.long 0x7e3e39a4                                           // 0000005AC580: 7E3E39A4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC584: BF870092
	v_lshlrev_b32_e32 v33, 4, v33                              // 0000005AC588: 30424284
	v_and_or_b32 v32, v33, 48, v32                             // 0000005AC58C: D6570020 04816121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC594: BF870091
	v_subrev_nc_u32_e32 v32, 32, v32                           // 0000005AC598: 4E4040A0
	v_cvt_f32_i32_e32 v32, v32                                 // 0000005AC59C: 7E400B20
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC5A0: BF870091
	v_mul_f32_e32 v32, v40, v32                                // 0000005AC5A4: 10404128
	v_bfe_u32 v33, v32, 16, 1                                  // 0000005AC5A8: D6100021 02052120
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000005AC5B0: BF870131
	v_add3_u32 v36, v32, v33, 0x7fff                           // 0000005AC5B4: D6550024 03FE4320 00007FFF
	v_lshrrev_b32_e32 v33, v21, v38                            // 0000005AC5C0: 32424D15
	v_bfe_u32 v32, v34, v20, 4                                 // 0000005AC5C4: D6100020 02122922
	v_lshlrev_b32_e32 v33, 4, v33                              // 0000005AC5CC: 30424284
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC5D0: BF870091
	v_and_or_b32 v32, v33, 48, v32                             // 0000005AC5D4: D6570020 04816121
	v_subrev_nc_u32_e32 v32, 32, v32                           // 0000005AC5DC: 4E4040A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC5E0: BF870091
	v_cvt_f32_i32_e32 v32, v32                                 // 0000005AC5E4: 7E400B20
	v_mul_f32_e32 v32, v40, v32                                // 0000005AC5E8: 10404128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC5EC: BF870091
	v_bfe_u32 v33, v32, 16, 1                                  // 0000005AC5F0: D6100021 02052120
	v_add3_u32 v32, v32, v33, 0x7fff                           // 0000005AC5F8: D6550020 03FE4320 00007FFF
	v_bfe_u32 v33, v34, v22, 4                                 // 0000005AC604: D6100021 02122D22
	.long 0x7e4039a4                                           // 0000005AC60C: 7E4039A4
	v_lshrrev_b32_e32 v36, v16, v39                            // 0000005AC610: 32484F10
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005AC614: BF870113
	v_and_or_b32 v33, v37, 48, v33                             // 0000005AC618: D6570021 04856125
	v_lshlrev_b32_e32 v36, 4, v36                              // 0000005AC620: 30484884
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC624: BF870092
	v_subrev_nc_u32_e32 v33, 32, v33                           // 0000005AC628: 4E4242A0
	v_cvt_f32_i32_e32 v33, v33                                 // 0000005AC62C: 7E420B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC630: BF870091
	v_mul_f32_e32 v33, v40, v33                                // 0000005AC634: 10424328
	v_bfe_u32 v37, v33, 16, 1                                  // 0000005AC638: D6100025 02052121
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000005AC640: BF870141
	v_add3_u32 v37, v33, v37, 0x7fff                           // 0000005AC644: D6550025 03FE4B21 00007FFF
	v_bfe_u32 v33, v34, v24, 4                                 // 0000005AC650: D6100021 02123122
	v_lshrrev_b32_e32 v34, v25, v38                            // 0000005AC658: 32444D19
	v_lshrrev_b32_e32 v38, v23, v39                            // 0000005AC65C: 324C4F17
	v_lshlrev_b32_e32 v34, 4, v34                              // 0000005AC660: 30444484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005AC664: BF870112
	v_lshlrev_b32_e32 v38, 4, v38                              // 0000005AC668: 304C4C84
	v_and_or_b32 v33, v34, 48, v33                             // 0000005AC66C: D6570021 04856122
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC674: BF870091
	v_subrev_nc_u32_e32 v33, 32, v33                           // 0000005AC678: 4E4242A0
	v_cvt_f32_i32_e32 v33, v33                                 // 0000005AC67C: 7E420B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC680: BF870091
	v_mul_f32_e32 v33, v40, v33                                // 0000005AC684: 10424328
	v_bfe_u32 v34, v33, 16, 1                                  // 0000005AC688: D6100022 02052121
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000005AC690: BF8701C1
	v_add3_u32 v33, v33, v34, 0x7fff                           // 0000005AC694: D6550021 03FE4521 00007FFF
	v_bfe_u32 v34, v35, v17, 4                                 // 0000005AC6A0: D6100022 02122323
	.long 0x7e4239a5                                           // 0000005AC6A8: 7E4239A5
	v_lshrrev_b32_e32 v37, v21, v39                            // 0000005AC6AC: 324A4F15
	v_and_or_b32 v34, v36, 48, v34                             // 0000005AC6B0: D6570022 04896124
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005AC6B8: BF870112
	v_lshlrev_b32_e32 v37, 4, v37                              // 0000005AC6BC: 304A4A84
	v_subrev_nc_u32_e32 v34, 32, v34                           // 0000005AC6C0: 4E4444A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC6C4: BF870091
	v_cvt_f32_i32_e32 v34, v34                                 // 0000005AC6C8: 7E440B22
	v_mul_f32_e32 v34, v40, v34                                // 0000005AC6CC: 10444528
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC6D0: BF870091
	v_bfe_u32 v36, v34, 16, 1                                  // 0000005AC6D4: D6100024 02052122
	v_add3_u32 v36, v34, v36, 0x7fff                           // 0000005AC6DC: D6550024 03FE4922 00007FFF
	v_bfe_u32 v34, v35, v20, 4                                 // 0000005AC6E8: D6100022 02122923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC6F0: BF870091
	v_and_or_b32 v34, v37, 48, v34                             // 0000005AC6F4: D6570022 04896125
	v_subrev_nc_u32_e32 v34, 32, v34                           // 0000005AC6FC: 4E4444A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC700: BF870091
	v_cvt_f32_i32_e32 v34, v34                                 // 0000005AC704: 7E440B22
	v_mul_f32_e32 v34, v40, v34                                // 0000005AC708: 10444528
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC70C: BF870091
	v_bfe_u32 v37, v34, 16, 1                                  // 0000005AC710: D6100025 02052122
	v_add3_u32 v34, v34, v37, 0x7fff                           // 0000005AC718: D6550022 03FE4B22 00007FFF
	v_bfe_u32 v37, v35, v22, 4                                 // 0000005AC724: D6100025 02122D23
	v_bfe_u32 v35, v35, v24, 4                                 // 0000005AC72C: D6100023 02123123
	.long 0x7e4439a4                                           // 0000005AC734: 7E4439A4
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC738: BF870093
	v_and_or_b32 v37, v38, 48, v37                             // 0000005AC73C: D6570025 04956126
	v_subrev_nc_u32_e32 v37, 32, v37                           // 0000005AC744: 4E4A4AA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC748: BF870091
	v_cvt_f32_i32_e32 v37, v37                                 // 0000005AC74C: 7E4A0B25
	v_mul_f32_e32 v37, v40, v37                                // 0000005AC750: 104A4B28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC754: BF870091
	v_bfe_u32 v38, v37, 16, 1                                  // 0000005AC758: D6100026 02052125
	v_add3_u32 v37, v37, v38, 0x7fff                           // 0000005AC760: D6550025 03FE4D25 00007FFF
	v_lshrrev_b32_e32 v38, v25, v39                            // 0000005AC76C: 324C4F19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC770: BF870091
	v_lshlrev_b32_e32 v38, 4, v38                              // 0000005AC774: 304C4C84
	v_and_or_b32 v35, v38, 48, v35                             // 0000005AC778: D6570023 048D6126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC780: BF870091
	v_subrev_nc_u32_e32 v35, 32, v35                           // 0000005AC784: 4E4646A0
	v_cvt_f32_i32_e32 v35, v35                                 // 0000005AC788: 7E460B23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC78C: BF870091
	v_mul_f32_e32 v35, v40, v35                                // 0000005AC790: 10464728
	v_bfe_u32 v38, v35, 16, 1                                  // 0000005AC794: D6100026 02052123
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000005AC79C: BF870141
	v_add3_u32 v35, v35, v38, 0x7fff                           // 0000005AC7A0: D6550023 03FE4D23 00007FFF
	.long 0x7e4639a5                                           // 0000005AC7AC: 7E4639A5
	.long 0xd73c0024                                           // 0000005AC7B0: D73C0024
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000005AC7B4: 02020A81
	v_add_nc_u32_e32 v5, 0x200, v5                             // 0000005AC7B8: 4A0A0AFF 00000200
	.long 0xd700002c                                           // 0000005AC7C0: D700002C
	v_cndmask_b32_e32 v1, s6, v36, vcc_lo                      // 0000005AC7C4: 02024806
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005AC7C8: BF870001
	v_add_co_ci_u32_e64 v45, null, s7, v37, s0                 // 0000005AC7CC: D5207C2D 00024A07
	s_clause 0x1                                               // 0000005AC7D4: BF850001
	global_load_b128 v[36:39], v[44:45], off                   // 0000005AC7D8: DC5E0000 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:16         // 0000005AC7E0: DC5E0010 287C002C
	s_waitcnt vmcnt(1)                                         // 0000005AC7E8: BF8907F7
	v_dot2_f32_bf16 v36, v36, v28, 0                           // 0000005AC7EC: CC1A4024 1A023924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC7F4: BF870091
	v_dot2_f32_bf16 v36, v37, v29, v36                         // 0000005AC7F8: CC1A4024 1C923B25
	v_dot2_f32_bf16 v36, v38, v30, v36                         // 0000005AC800: CC1A4024 1C923D26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005AC808: BF8700A1
	v_dot2_f32_bf16 v36, v39, v31, v36                         // 0000005AC80C: CC1A4024 1C923F27
	s_waitcnt vmcnt(0)                                         // 0000005AC814: BF8903F7
	v_dot2_f32_bf16 v36, v40, v32, v36                         // 0000005AC818: CC1A4024 1C924128
	.long 0xd7000028                                           // 0000005AC820: D7000028
	v_cndmask_b32_e32 v0, v44, v10, vcc_lo                     // 0000005AC824: 0200152C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000005AC828: BF8701B2
	v_dot2_f32_bf16 v36, v41, v33, v36                         // 0000005AC82C: CC1A4024 1C924329
	v_add_co_ci_u32_e64 v41, null, s11, v45, s0                // 0000005AC834: D5207C29 00025A0B
	.long 0xd700002e                                           // 0000005AC83C: D700002E
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 0000005AC840: 0200092C
	v_dot2_f32_bf16 v36, v42, v34, v36                         // 0000005AC844: CC1A4024 1C92452A
	v_add_co_ci_u32_e64 v47, null, s5, v45, s0                 // 0000005AC84C: D5207C2F 00025A05
	.long 0xd700002c                                           // 0000005AC854: D700002C
	v_cndmask_b32_e32 v0, v44, v15, vcc_lo                     // 0000005AC858: 02001F2C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005AC85C: BF870123
	v_dot2_f32_bf16 v36, v43, v35, v36                         // 0000005AC860: CC1A4024 1C92472B
	v_add_co_ci_u32_e64 v45, null, s2, v45, s0                 // 0000005AC868: D5207C2D 00025A02
	v_add_f32_e32 v15, v15, v36                                // 0000005AC870: 061E490F
	s_clause 0x1                                               // 0000005AC874: BF850001
	global_load_b128 v[36:39], v[40:41], off                   // 0000005AC878: DC5E0000 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:16         // 0000005AC880: DC5E0010 287C0028
	s_waitcnt vmcnt(1)                                         // 0000005AC888: BF8907F7
	v_dot2_f32_bf16 v36, v36, v28, 0                           // 0000005AC88C: CC1A4024 1A023924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC894: BF870091
	v_dot2_f32_bf16 v36, v37, v29, v36                         // 0000005AC898: CC1A4024 1C923B25
	v_dot2_f32_bf16 v36, v38, v30, v36                         // 0000005AC8A0: CC1A4024 1C923D26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005AC8A8: BF8700A1
	v_dot2_f32_bf16 v36, v39, v31, v36                         // 0000005AC8AC: CC1A4024 1C923F27
	s_waitcnt vmcnt(0)                                         // 0000005AC8B4: BF8903F7
	v_dot2_f32_bf16 v36, v40, v32, v36                         // 0000005AC8B8: CC1A4024 1C924128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC8C0: BF870091
	v_dot2_f32_bf16 v36, v41, v33, v36                         // 0000005AC8C4: CC1A4024 1C924329
	v_dot2_f32_bf16 v36, v42, v34, v36                         // 0000005AC8CC: CC1A4024 1C92452A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC8D4: BF870091
	v_dot2_f32_bf16 v36, v43, v35, v36                         // 0000005AC8D8: CC1A4024 1C92472B
	v_add_f32_e32 v14, v14, v36                                // 0000005AC8E0: 061C490E
	s_clause 0x1                                               // 0000005AC8E4: BF850001
	global_load_b128 v[36:39], v[46:47], off                   // 0000005AC8E8: DC5E0000 247C002E
	global_load_b128 v[40:43], v[46:47], off offset:16         // 0000005AC8F0: DC5E0010 287C002E
	.long 0xd700002e                                           // 0000005AC8F8: D700002E
	v_cndmask_b32_e32 v0, v46, v4, vcc_lo                      // 0000005AC8FC: 0200092E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005AC900: BF8700B1
	v_add_co_ci_u32_e64 v47, null, s5, v47, s0                 // 0000005AC904: D5207C2F 00025E05
	s_waitcnt vmcnt(1)                                         // 0000005AC90C: BF8907F7
	v_dot2_f32_bf16 v36, v36, v28, 0                           // 0000005AC910: CC1A4024 1A023924
	v_dot2_f32_bf16 v36, v37, v29, v36                         // 0000005AC918: CC1A4024 1C923B25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC920: BF870091
	v_dot2_f32_bf16 v36, v38, v30, v36                         // 0000005AC924: CC1A4024 1C923D26
	v_dot2_f32_bf16 v36, v39, v31, v36                         // 0000005AC92C: CC1A4024 1C923F27
	s_waitcnt vmcnt(0)                                         // 0000005AC934: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC938: BF870091
	v_dot2_f32_bf16 v36, v40, v32, v36                         // 0000005AC93C: CC1A4024 1C924128
	v_dot2_f32_bf16 v36, v41, v33, v36                         // 0000005AC944: CC1A4024 1C924329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC94C: BF870091
	v_dot2_f32_bf16 v36, v42, v34, v36                         // 0000005AC950: CC1A4024 1C92452A
	v_dot2_f32_bf16 v36, v43, v35, v36                         // 0000005AC958: CC1A4024 1C92472B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000005AC960: BF8700D1
	v_add_f32_e32 v12, v12, v36                                // 0000005AC964: 0618490C
	s_clause 0x1                                               // 0000005AC968: BF850001
	global_load_b128 v[36:39], v[44:45], off                   // 0000005AC96C: DC5E0000 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:16         // 0000005AC974: DC5E0010 287C002C
	.long 0xd700002c                                           // 0000005AC97C: D700002C
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 0000005AC980: 0200092C
	v_add_co_ci_u32_e64 v45, null, s5, v45, s0                 // 0000005AC984: D5207C2D 00025A05
	s_waitcnt vmcnt(1)                                         // 0000005AC98C: BF8907F7
	v_dot2_f32_bf16 v36, v36, v28, 0                           // 0000005AC990: CC1A4024 1A023924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC998: BF870091
	v_dot2_f32_bf16 v36, v37, v29, v36                         // 0000005AC99C: CC1A4024 1C923B25
	v_dot2_f32_bf16 v36, v38, v30, v36                         // 0000005AC9A4: CC1A4024 1C923D26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005AC9AC: BF8700A1
	v_dot2_f32_bf16 v36, v39, v31, v36                         // 0000005AC9B0: CC1A4024 1C923F27
	s_waitcnt vmcnt(0)                                         // 0000005AC9B8: BF8903F7
	v_dot2_f32_bf16 v36, v40, v32, v36                         // 0000005AC9BC: CC1A4024 1C924128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC9C4: BF870091
	v_dot2_f32_bf16 v36, v41, v33, v36                         // 0000005AC9C8: CC1A4024 1C924329
	v_dot2_f32_bf16 v36, v42, v34, v36                         // 0000005AC9D0: CC1A4024 1C92452A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AC9D8: BF870091
	v_dot2_f32_bf16 v36, v43, v35, v36                         // 0000005AC9DC: CC1A4024 1C92472B
	v_add_f32_e32 v13, v13, v36                                // 0000005AC9E4: 061A490D
	s_clause 0x1                                               // 0000005AC9E8: BF850001
	global_load_b128 v[36:39], v[46:47], off                   // 0000005AC9EC: DC5E0000 247C002E
	global_load_b128 v[40:43], v[46:47], off offset:16         // 0000005AC9F4: DC5E0010 287C002E
	s_waitcnt vmcnt(1)                                         // 0000005AC9FC: BF8907F7
	v_dot2_f32_bf16 v36, v36, v28, 0                           // 0000005ACA00: CC1A4024 1A023924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005ACA08: BF870091
	v_dot2_f32_bf16 v36, v37, v29, v36                         // 0000005ACA0C: CC1A4024 1C923B25
	v_dot2_f32_bf16 v36, v38, v30, v36                         // 0000005ACA14: CC1A4024 1C923D26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005ACA1C: BF8700A1
	v_dot2_f32_bf16 v36, v39, v31, v36                         // 0000005ACA20: CC1A4024 1C923F27
	s_waitcnt vmcnt(0)                                         // 0000005ACA28: BF8903F7
	v_dot2_f32_bf16 v36, v40, v32, v36                         // 0000005ACA2C: CC1A4024 1C924128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005ACA34: BF870091
	v_dot2_f32_bf16 v36, v41, v33, v36                         // 0000005ACA38: CC1A4024 1C924329
	v_dot2_f32_bf16 v36, v42, v34, v36                         // 0000005ACA40: CC1A4024 1C92452A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005ACA48: BF870091
	v_dot2_f32_bf16 v36, v43, v35, v36                         // 0000005ACA4C: CC1A4024 1C92472B
	v_add_f32_e32 v10, v10, v36                                // 0000005ACA54: 0614490A
	s_clause 0x1                                               // 0000005ACA58: BF850001
	global_load_b128 v[36:39], v[44:45], off                   // 0000005ACA5C: DC5E0000 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:16         // 0000005ACA64: DC5E0010 287C002C
	s_waitcnt vmcnt(1)                                         // 0000005ACA6C: BF8907F7
	v_dot2_f32_bf16 v36, v36, v28, 0                           // 0000005ACA70: CC1A4024 1A023924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005ACA78: BF870091
	v_dot2_f32_bf16 v36, v37, v29, v36                         // 0000005ACA7C: CC1A4024 1C923B25
	v_dot2_f32_bf16 v36, v38, v30, v36                         // 0000005ACA84: CC1A4024 1C923D26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005ACA8C: BF8700A1
	v_dot2_f32_bf16 v36, v39, v31, v36                         // 0000005ACA90: CC1A4024 1C923F27
	s_waitcnt vmcnt(0)                                         // 0000005ACA98: BF8903F7
	v_dot2_f32_bf16 v36, v40, v32, v36                         // 0000005ACA9C: CC1A4024 1C924128
	.long 0xd7000028                                           // 0000005ACAA4: D7000028
	v_cndmask_b32_e32 v0, v46, v4, vcc_lo                      // 0000005ACAA8: 0200092E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005ACAAC: BF870122
	v_dot2_f32_bf16 v36, v41, v33, v36                         // 0000005ACAB0: CC1A4024 1C924329
	v_add_co_ci_u32_e64 v41, null, s5, v47, s0                 // 0000005ACAB8: D5207C29 00025E05
	v_dot2_f32_bf16 v36, v42, v34, v36                         // 0000005ACAC0: CC1A4024 1C92452A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005ACAC8: BF870091
	v_dot2_f32_bf16 v36, v43, v35, v36                         // 0000005ACACC: CC1A4024 1C92472B
	v_add_f32_e32 v11, v11, v36                                // 0000005ACAD4: 0616490B
	s_clause 0x1                                               // 0000005ACAD8: BF850001
	global_load_b128 v[36:39], v[40:41], off                   // 0000005ACADC: DC5E0000 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:16         // 0000005ACAE4: DC5E0010 287C0028
	s_waitcnt vmcnt(1)                                         // 0000005ACAEC: BF8907F7
	v_dot2_f32_bf16 v36, v36, v28, 0                           // 0000005ACAF0: CC1A4024 1A023924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005ACAF8: BF870091
	v_dot2_f32_bf16 v36, v37, v29, v36                         // 0000005ACAFC: CC1A4024 1C923B25
	v_dot2_f32_bf16 v36, v38, v30, v36                         // 0000005ACB04: CC1A4024 1C923D26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005ACB0C: BF8700A1
	v_dot2_f32_bf16 v36, v39, v31, v36                         // 0000005ACB10: CC1A4024 1C923F27
	s_waitcnt vmcnt(0)                                         // 0000005ACB18: BF8903F7
	v_dot2_f32_bf16 v36, v40, v32, v36                         // 0000005ACB1C: CC1A4024 1C924128
	.long 0xd7000028                                           // 0000005ACB24: D7000028
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 0000005ACB28: 0200092C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000005ACB2C: BF8701B2
	v_dot2_f32_bf16 v36, v41, v33, v36                         // 0000005ACB30: CC1A4024 1C924329
	v_add_co_ci_u32_e64 v41, null, s5, v45, s0                 // 0000005ACB38: D5207C29 00025A05
	.long 0xd4430000                                           // 0000005ACB40: D4430000
	v_cndmask_b32_e32 v1, s14, v27, vcc_lo                     // 0000005ACB44: 0202360E
	v_dot2_f32_bf16 v36, v42, v34, v36                         // 0000005ACB48: CC1A4024 1C92452A
	s_or_b32 s3, s0, s3                                        // 0000005ACB50: 8C030300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005ACB54: BF870091
	v_dot2_f32_bf16 v36, v43, v35, v36                         // 0000005ACB58: CC1A4024 1C92472B
	v_add_f32_e32 v9, v9, v36                                  // 0000005ACB60: 06124909
	s_clause 0x1                                               // 0000005ACB64: BF850001
	global_load_b128 v[36:39], v[40:41], off                   // 0000005ACB68: DC5E0000 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:16         // 0000005ACB70: DC5E0010 287C0028
	s_waitcnt vmcnt(1)                                         // 0000005ACB78: BF8907F7
	v_dot2_f32_bf16 v28, v36, v28, 0                           // 0000005ACB7C: CC1A401C 1A023924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005ACB84: BF870091
	v_dot2_f32_bf16 v28, v37, v29, v28                         // 0000005ACB88: CC1A401C 1C723B25
	v_dot2_f32_bf16 v28, v38, v30, v28                         // 0000005ACB90: CC1A401C 1C723D26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005ACB98: BF8700A1
	v_dot2_f32_bf16 v28, v39, v31, v28                         // 0000005ACB9C: CC1A401C 1C723F27
	s_waitcnt vmcnt(0)                                         // 0000005ACBA4: BF8903F7
	v_dot2_f32_bf16 v28, v40, v32, v28                         // 0000005ACBA8: CC1A401C 1C724128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005ACBB0: BF870091
	v_dot2_f32_bf16 v28, v41, v33, v28                         // 0000005ACBB4: CC1A401C 1C724329
	v_dot2_f32_bf16 v28, v42, v34, v28                         // 0000005ACBBC: CC1A401C 1C72452A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005ACBC4: BF870091
	v_dot2_f32_bf16 v28, v43, v35, v28                         // 0000005ACBC8: CC1A401C 1C72472B
	v_add_f32_e32 v8, v8, v28                                  // 0000005ACBD0: 06103908
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 0000005ACBD4: 917E037E
	s_cbranch_execnz 64928                                     // 0000005ACBD8: BFA6FDA0 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi32ELi1ELb0EEEvPKhPKtPvll+0x15c>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000005ACBDC: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005ACBE0: BF8700A9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005ACBE4: 8C7E017E
	.long 0xd71f0000                                           // 0000005ACBE8: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000005ACBEC: 020100C1
	v_xor_b32_e32 v3, 16, v0                                   // 0000005ACBF0: 3A060090
	v_xor_b32_e32 v20, 8, v0                                   // 0000005ACBF4: 3A280088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005ACBF8: BF870092
	.long 0xd44c0000                                           // 0000005ACBFC: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000005ACC00: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 0000005ACC04: D5010003 00020700
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005ACC0C: BF870113
	.long 0xd44c0000                                           // 0000005ACC10: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 0000005ACC14: 020228A0
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000005ACC18: 30060682
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005ACC1C: BF870002
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 0000005ACC20: D5010014 00022900
	ds_bpermute_b32 v4, v3, v14                                // 0000005ACC28: DACC0000 04000E03
	s_waitcnt lgkmcnt(0)                                       // 0000005ACC30: BF89FC07
	v_add_f32_e32 v4, v14, v4                                  // 0000005ACC34: 0608090E
	ds_bpermute_b32 v5, v3, v15                                // 0000005ACC38: DACC0000 05000F03
	ds_bpermute_b32 v6, v3, v13                                // 0000005ACC40: DACC0000 06000D03
	ds_bpermute_b32 v17, v3, v11                               // 0000005ACC48: DACC0000 11000B03
	ds_bpermute_b32 v16, v3, v12                               // 0000005ACC50: DACC0000 10000C03
	ds_bpermute_b32 v18, v3, v10                               // 0000005ACC58: DACC0000 12000A03
	ds_bpermute_b32 v19, v3, v8                                // 0000005ACC60: DACC0000 13000803
	ds_bpermute_b32 v3, v3, v9                                 // 0000005ACC68: DACC0000 03000903
	s_waitcnt lgkmcnt(6)                                       // 0000005ACC70: BF89FC67
	v_dual_add_f32 v5, v15, v5 :: v_dual_lshlrev_b32 v20, 2, v20// 0000005ACC74: C9220B0F 05142882
	s_waitcnt lgkmcnt(4)                                       // 0000005ACC7C: BF89FC47
	v_dual_add_f32 v6, v13, v6 :: v_dual_add_f32 v11, v11, v17 // 0000005ACC80: C9080D0D 060A230B
	s_waitcnt lgkmcnt(3)                                       // 0000005ACC88: BF89FC37
	v_add_f32_e32 v12, v12, v16                                // 0000005ACC8C: 0618210C
	ds_bpermute_b32 v13, v20, v5                               // 0000005ACC90: DACC0000 0D000514
	s_waitcnt lgkmcnt(3)                                       // 0000005ACC98: BF89FC37
	v_add_f32_e32 v10, v10, v18                                // 0000005ACC9C: 0614250A
	ds_bpermute_b32 v16, v20, v11                              // 0000005ACCA0: DACC0000 10000B14
	s_waitcnt lgkmcnt(3)                                       // 0000005ACCA8: BF89FC37
	v_add_f32_e32 v8, v8, v19                                  // 0000005ACCAC: 06102708
	s_waitcnt lgkmcnt(2)                                       // 0000005ACCB0: BF89FC27
	v_add_f32_e32 v3, v9, v3                                   // 0000005ACCB4: 06060709
	ds_bpermute_b32 v9, v20, v4                                // 0000005ACCB8: DACC0000 09000414
	ds_bpermute_b32 v15, v20, v12                              // 0000005ACCC0: DACC0000 0F000C14
	ds_bpermute_b32 v14, v20, v6                               // 0000005ACCC8: DACC0000 0E000614
	ds_bpermute_b32 v19, v20, v3                               // 0000005ACCD0: DACC0000 13000314
	s_waitcnt lgkmcnt(5)                                       // 0000005ACCD8: BF89FC57
	v_add_f32_e32 v5, v5, v13                                  // 0000005ACCDC: 060A1B05
	ds_bpermute_b32 v17, v20, v10                              // 0000005ACCE0: DACC0000 11000A14
	s_waitcnt lgkmcnt(5)                                       // 0000005ACCE8: BF89FC57
	v_add_f32_e32 v11, v11, v16                                // 0000005ACCEC: 0616210B
	ds_bpermute_b32 v18, v20, v8                               // 0000005ACCF0: DACC0000 12000814
	v_xor_b32_e32 v20, 4, v0                                   // 0000005ACCF8: 3A280084
	s_waitcnt lgkmcnt(5)                                       // 0000005ACCFC: BF89FC57
	v_add_f32_e32 v4, v4, v9                                   // 0000005ACD00: 06081304
	s_waitcnt lgkmcnt(4)                                       // 0000005ACD04: BF89FC47
	v_add_f32_e32 v9, v12, v15                                 // 0000005ACD08: 06121F0C
	.long 0xd44c0000                                           // 0000005ACD0C: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 0000005ACD10: 020228A0
	s_waitcnt lgkmcnt(2)                                       // 0000005ACD14: BF89FC27
	v_add_f32_e32 v3, v3, v19                                  // 0000005ACD18: 06062703
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005ACD1C: BF870092
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 0000005ACD20: D5010014 00022900
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000005ACD28: 30282882
	ds_bpermute_b32 v13, v20, v5                               // 0000005ACD2C: DACC0000 0D000514
	ds_bpermute_b32 v15, v20, v9                               // 0000005ACD34: DACC0000 0F000914
	ds_bpermute_b32 v16, v20, v11                              // 0000005ACD3C: DACC0000 10000B14
	v_add_f32_e32 v6, v6, v14                                  // 0000005ACD44: 060C1D06
	s_waitcnt lgkmcnt(4)                                       // 0000005ACD48: BF89FC47
	v_add_f32_e32 v10, v10, v17                                // 0000005ACD4C: 0614230A
	s_waitcnt lgkmcnt(3)                                       // 0000005ACD50: BF89FC37
	v_add_f32_e32 v8, v8, v18                                  // 0000005ACD54: 06102508
	ds_bpermute_b32 v12, v20, v4                               // 0000005ACD58: DACC0000 0C000414
	ds_bpermute_b32 v19, v20, v3                               // 0000005ACD60: DACC0000 13000314
	s_waitcnt lgkmcnt(4)                                       // 0000005ACD68: BF89FC47
	v_add_f32_e32 v5, v5, v13                                  // 0000005ACD6C: 060A1B05
	ds_bpermute_b32 v14, v20, v6                               // 0000005ACD70: DACC0000 0E000614
	s_waitcnt lgkmcnt(4)                                       // 0000005ACD78: BF89FC47
	v_add_f32_e32 v9, v9, v15                                  // 0000005ACD7C: 06121F09
	ds_bpermute_b32 v17, v20, v10                              // 0000005ACD80: DACC0000 11000A14
	s_waitcnt lgkmcnt(4)                                       // 0000005ACD88: BF89FC47
	v_add_f32_e32 v13, v11, v16                                // 0000005ACD8C: 061A210B
	ds_bpermute_b32 v18, v20, v8                               // 0000005ACD90: DACC0000 12000814
	v_xor_b32_e32 v20, 2, v0                                   // 0000005ACD98: 3A280082
	s_waitcnt lgkmcnt(4)                                       // 0000005ACD9C: BF89FC47
	v_add_f32_e32 v4, v4, v12                                  // 0000005ACDA0: 06081904
	v_xor_b32_e32 v15, 1, v0                                   // 0000005ACDA4: 3A1E0081
	s_waitcnt lgkmcnt(3)                                       // 0000005ACDA8: BF89FC37
	v_add_f32_e32 v3, v3, v19                                  // 0000005ACDAC: 06062703
	.long 0xd44c0000                                           // 0000005ACDB0: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 0000005ACDB4: 020228A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005ACDB8: BF870121
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 0000005ACDBC: D5010014 00022900
	.long 0xd44c0000                                           // 0000005ACDC4: D44C0000
	v_cndmask_b32_e32 v1, 32, v15, vcc_lo                      // 0000005ACDC8: 02021EA0
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000005ACDCC: 30282882
	s_waitcnt lgkmcnt(2)                                       // 0000005ACDD0: BF89FC27
	v_add_f32_e32 v6, v6, v14                                  // 0000005ACDD4: 060C1D06
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005ACDD8: BF870003
	v_cndmask_b32_e64 v0, v0, v15, s0                          // 0000005ACDDC: D5010000 00021F00
	s_waitcnt lgkmcnt(1)                                       // 0000005ACDE4: BF89FC17
	v_add_f32_e32 v10, v10, v17                                // 0000005ACDE8: 0614230A
	s_waitcnt lgkmcnt(0)                                       // 0000005ACDEC: BF89FC07
	v_add_f32_e32 v14, v8, v18                                 // 0000005ACDF0: 061C2508
	ds_bpermute_b32 v8, v20, v4                                // 0000005ACDF4: DACC0000 08000414
	ds_bpermute_b32 v11, v20, v5                               // 0000005ACDFC: DACC0000 0B000514
	ds_bpermute_b32 v17, v20, v9                               // 0000005ACE04: DACC0000 11000914
	ds_bpermute_b32 v18, v20, v13                              // 0000005ACE0C: DACC0000 12000D14
	ds_bpermute_b32 v19, v20, v10                              // 0000005ACE14: DACC0000 13000A14
	v_lshlrev_b32_e32 v22, 2, v0                               // 0000005ACE1C: 302C0082
	.long 0xd44a0000                                           // 0000005ACE20: D44A0000
	v_cndmask_b32_e32 v1, 0, v7, vcc_lo                        // 0000005ACE24: 02020E80
	s_and_b32 s0, s0, vcc_lo                                   // 0000005ACE28: 8B006A00
	s_waitcnt lgkmcnt(4)                                       // 0000005ACE2C: BF89FC47
	v_add_f32_e32 v15, v4, v8                                  // 0000005ACE30: 061E1104
	ds_bpermute_b32 v12, v20, v6                               // 0000005ACE34: DACC0000 0C000614
	s_waitcnt lgkmcnt(0)                                       // 0000005ACE3C: BF89FC07
	v_dual_add_f32 v16, v5, v11 :: v_dual_add_f32 v11, v6, v12 // 0000005ACE40: C9081705 100A1906
	ds_bpermute_b32 v21, v20, v14                              // 0000005ACE48: DACC0000 15000E14
	ds_bpermute_b32 v20, v20, v3                               // 0000005ACE50: DACC0000 14000314
	v_add_f32_e32 v12, v9, v17                                 // 0000005ACE58: 06182309
	v_add_f32_e32 v6, v13, v18                                 // 0000005ACE5C: 060C250D
	ds_bpermute_b32 v17, v22, v16                              // 0000005ACE60: DACC0000 11001016
	ds_bpermute_b32 v18, v22, v15                              // 0000005ACE68: DACC0000 12000F16
	ds_bpermute_b32 v13, v22, v11                              // 0000005ACE70: DACC0000 0D000B16
	s_waitcnt lgkmcnt(3)                                       // 0000005ACE78: BF89FC37
	v_dual_add_f32 v0, v14, v21 :: v_dual_add_f32 v3, v3, v20  // 0000005ACE7C: C9082B0E 00022903
	v_add_f32_e32 v8, v10, v19                                 // 0000005ACE84: 0610270A
	ds_bpermute_b32 v14, v22, v12                              // 0000005ACE88: DACC0000 0E000C16
	ds_bpermute_b32 v10, v22, v6                               // 0000005ACE90: DACC0000 0A000616
	ds_bpermute_b32 v5, v22, v0                                // 0000005ACE98: DACC0000 05000016
	ds_bpermute_b32 v4, v22, v3                                // 0000005ACEA0: DACC0000 04000316
	ds_bpermute_b32 v9, v22, v8                                // 0000005ACEA8: DACC0000 09000816
	s_and_saveexec_b32 s1, s0                                  // 0000005ACEB0: BE812000
	s_cbranch_execz 116                                        // 0000005ACEB4: BFA50074 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi32ELi1ELb0EEEvPKhPKtPvll+0xf88>
	s_waitcnt lgkmcnt(6)                                       // 0000005ACEB8: BF89FC67
	v_add_f32_e32 v7, v15, v18                                 // 0000005ACEBC: 060E250F
	v_add_f32_e32 v15, v16, v17                                // 0000005ACEC0: 061E2310
	.long 0x7f223880                                           // 0000005ACEC4: 7F223880
	.long 0xd73c0001                                           // 0000005ACEC8: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000005ACECC: 02020281
	s_lshl_b64 s[0:1], s[12:13], 1                             // 0000005ACED0: 8480810C
	.long 0x7e223987                                           // 0000005ACED4: 7E223987
	.long 0x7e20398f                                           // 0000005ACED8: 7E20398F
	.long 0x7f203991                                           // 0000005ACEDC: 7F203991
	s_waitcnt lgkmcnt(4)                                       // 0000005ACEE0: BF89FC47
	v_dual_add_f32 v14, v12, v14 :: v_dual_add_f32 v13, v11, v13// 0000005ACEE4: C9081D0C 0E0C1B0B
	v_and_b32_e32 v18, 1, v17                                  // 0000005ACEEC: 36242281
	.long 0xd7006a01                                           // 0000005ACEF0: D7006A01
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000005ACEF4: 02020208
	v_and_b32_e32 v16, 1, v16                                  // 0000005ACEF8: 36202081
	v_add_co_ci_u32_e64 v2, null, s9, v2, vcc_lo               // 0000005ACEFC: D5207C02 01AA0409
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005ACF04: BF870224
	v_add3_u32 v7, v7, v18, 0x7fff                             // 0000005ACF08: D6550007 03FE2507 00007FFF
	.long 0x7e22398d                                           // 0000005ACF14: 7E22398D
	v_add3_u32 v18, v15, v16, 0x7fff                           // 0000005ACF18: D6550012 03FE210F 00007FFF
	.long 0xd7006a0f                                           // 0000005ACF24: D7006A0F
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 0000005ACF28: 02000101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005ACF2C: BF870001
	v_add_co_ci_u32_e64 v16, null, s1, v2, vcc_lo              // 0000005ACF30: D5207C10 01AA0401
	s_clause 0x1                                               // 0000005ACF38: BF850001
	global_store_d16_hi_b16 v[1:2], v18, off                   // 0000005ACF3C: DC960000 007C1201
	global_store_d16_hi_b16 v[15:16], v7, off                  // 0000005ACF44: DC960000 007C070F
	.long 0x7e0e398e                                           // 0000005ACF4C: 7E0E398E
	.long 0x7f0e3991                                           // 0000005ACF50: 7F0E3991
	s_lshl_b64 s[0:1], s[12:13], 2                             // 0000005ACF54: 8480820C
	s_waitcnt lgkmcnt(3)                                       // 0000005ACF58: BF89FC37
	v_add_f32_e32 v10, v6, v10                                 // 0000005ACF5C: 06141506
	.long 0xd7006a0b                                           // 0000005ACF60: D7006A0B
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 0000005ACF64: 02000101
	v_and_b32_e32 v15, 1, v7                                   // 0000005ACF68: 361E0E81
	v_add_co_ci_u32_e64 v12, null, s1, v2, vcc_lo              // 0000005ACF6C: D5207C0C 01AA0401
	v_mad_u64_u32 v[6:7], null, s12, 6, v[1:2]                 // 0000005ACF74: D6FE7C06 04050C0C
	v_and_b32_e32 v1, 1, v17                                   // 0000005ACF7C: 36022281
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005ACF80: BF870004
	v_add3_u32 v2, v14, v15, 0x7fff                            // 0000005ACF84: D6550002 03FE1F0E 00007FFF
	.long 0x7f1c3991                                           // 0000005ACF90: 7F1C3991
	s_waitcnt lgkmcnt(0)                                       // 0000005ACF94: BF89FC07
	v_add_f32_e32 v9, v8, v9                                   // 0000005ACF98: 06121308
	.long 0x7e22398a                                           // 0000005ACF9C: 7E22398A
	v_add_f32_e32 v15, v0, v5                                  // 0000005ACFA0: 061E0B00
	global_store_d16_hi_b16 v[11:12], v2, off                  // 0000005ACFA4: DC960000 007C020B
	v_mad_u64_u32 v[7:8], null, s13, 6, v[7:8]                 // 0000005ACFAC: D6FE7C07 041D0C0D
	.long 0x7e1c3989                                           // 0000005ACFB4: 7E1C3989
	v_and_b32_e32 v2, 1, v17                                   // 0000005ACFB8: 36042281
	.long 0x7e22398f                                           // 0000005ACFBC: 7E22398F
	.long 0xd7006a00                                           // 0000005ACFC0: D7006A00
	v_cndmask_b32_e32 v0, v11, v0, vcc_lo                      // 0000005ACFC4: 0200010B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000005ACFC8: BF870254
	v_and_b32_e32 v8, 1, v14                                   // 0000005ACFCC: 36101C81
	v_add_f32_e32 v14, v3, v4                                  // 0000005ACFD0: 061C0903
	.long 0x7f083991                                           // 0000005ACFD4: 7F083991
	v_add3_u32 v13, v13, v1, 0x7fff                            // 0000005ACFD8: D655000D 03FE030D 00007FFF
	v_add_co_ci_u32_e64 v1, null, s1, v12, vcc_lo              // 0000005ACFE4: D5207C01 01AA1801
	.long 0x7e08398e                                           // 0000005ACFEC: 7E08398E
	v_add3_u32 v10, v10, v2, 0x7fff                            // 0000005ACFF0: D655000A 03FE050A 00007FFF
	v_add3_u32 v11, v9, v8, 0x7fff                             // 0000005ACFFC: D655000B 03FE1109 00007FFF
	.long 0xd7006a02                                           // 0000005AD008: D7006A02
	v_cndmask_b32_e32 v0, v6, v0, vcc_lo                       // 0000005AD00C: 02000106
	v_and_b32_e32 v8, 1, v17                                   // 0000005AD010: 36102281
	v_and_b32_e32 v9, 1, v4                                    // 0000005AD014: 36120881
	v_add_co_ci_u32_e64 v3, null, s1, v7, vcc_lo               // 0000005AD018: D5207C03 01AA0E01
	.long 0xd7006a04                                           // 0000005AD020: D7006A04
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000005AD024: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005AD028: BF870001
	v_add_co_ci_u32_e64 v5, null, s1, v1, vcc_lo               // 0000005AD02C: D5207C05 01AA0201
	v_add3_u32 v12, v15, v8, 0x7fff                            // 0000005AD034: D655000C 03FE110F 00007FFF
	.long 0xd7006a08                                           // 0000005AD040: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 0000005AD044: 02000102
	v_add3_u32 v14, v14, v9, 0x7fff                            // 0000005AD048: D655000E 03FE130E 00007FFF
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 0000005AD054: D5207C09 01AA0601
	s_clause 0x4                                               // 0000005AD05C: BF850004
	global_store_d16_hi_b16 v[6:7], v13, off                   // 0000005AD060: DC960000 007C0D06
	global_store_d16_hi_b16 v[0:1], v11, off                   // 0000005AD068: DC960000 007C0B00
	global_store_d16_hi_b16 v[2:3], v10, off                   // 0000005AD070: DC960000 007C0A02
	global_store_d16_hi_b16 v[4:5], v14, off                   // 0000005AD078: DC960000 007C0E04
	global_store_d16_hi_b16 v[8:9], v12, off                   // 0000005AD080: DC960000 007C0C08
	s_endpgm                                                   // 0000005AD088: BFB00000
		...

