00000000007f7000 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007F7000: F4100100 F8000000
	v_and_b32_e32 v23, 15, v0                                  // 0000007F7008: 362E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000007F700C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 0000007F7010: 86039F02
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000007F7014: 30000082
	s_lshl_b64 s[0:1], s[2:3], 4                               // 0000007F7018: 84808402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007F701C: BF870009
	v_dual_mov_b32 v17, s1 :: v_dual_lshlrev_b32 v2, 2, v23    // 0000007F7020: CA220001 11022E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 0000007F7028: 30060282
	v_or_b32_e32 v16, s0, v1                                   // 0000007F702C: 38200200
	.long 0x7f023880                                           // 0000007F7030: 7F023880
	s_waitcnt lgkmcnt(0)                                       // 0000007F7034: BF89FC07
	s_clause 0x1                                               // 0000007F7038: BF850001
	global_load_b32 v2, v2, s[4:5]                             // 0000007F703C: DC520000 02040002
	global_load_b32 v3, v3, s[4:5]                             // 0000007F7044: DC520000 03040003
	.long 0xd4540000                                           // 0000007F704C: D4540000
	v_cndmask_b32_e32 v1, s12, v16, vcc_lo                     // 0000007F7050: 0202200C
	s_add_u32 s20, s4, s16                                     // 0000007F7054: 80141004
	s_addc_u32 s21, s5, s17                                    // 0000007F7058: 82151105
	s_ashr_i32 s2, s11, 31                                     // 0000007F705C: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007F7060: BF870159
	s_lshr_b32 s2, s2, 27                                      // 0000007F7064: 85029B02
	v_cndmask_b32_e64 v8, 0, v16, s0                           // 0000007F7068: D5010008 00022080
	v_cndmask_b32_e64 v9, 0, s1, s0                            // 0000007F7070: D5010009 00000280
	s_add_u32 s2, s10, s2                                      // 0000007F7078: 8002020A
	s_addc_u32 s3, s11, 0                                      // 0000007F707C: 8203800B
	.long 0xd72c0004                                           // 0000007F7080: D72C0004
	v_cndmask_b32_e32 v1, s19, v8, vcc_lo                      // 0000007F7084: 02021013
	v_mad_u64_u32 v[12:13], null, s18, v8, 0                   // 0000007F7088: D6FE7C0C 02021012
	s_lshr_b64 s[12:13], s[2:3], 5                             // 0000007F7090: 858C8502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007F7094: BF870009
	s_cmpk_lt_i32 s12, 0x81                                    // 0000007F7098: B38C0081
	.long 0xd4440002                                           // 0000007F709C: D4440002
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 0000007F70A0: 02022E0C
	s_cselect_b32 s1, -1, 0                                    // 0000007F70A4: 980180C1
	s_cmpk_gt_i32 s12, 0x80                                    // 0000007F70A8: B28C0080
	.long 0xd700030e                                           // 0000007F70AC: D700030E
	v_cndmask_b32_e32 v1, s20, v12, vcc_lo                     // 0000007F70B0: 02021814
	s_cselect_b32 s13, -1, 0                                   // 0000007F70B4: 980D80C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007F70B8: BF870159
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000007F70BC: 8B6A0D7E
	s_waitcnt vmcnt(1)                                         // 0000007F70C0: BF8907F7
	v_bfe_u32 v5, v2, 16, 1                                    // 0000007F70C4: D6100005 02052102
	s_waitcnt vmcnt(0)                                         // 0000007F70CC: BF8903F7
	v_bfe_u32 v6, v3, 16, 1                                    // 0000007F70D0: D6100006 02052103
	v_add3_u32 v2, v2, v5, 0x7fff                              // 0000007F70D8: D6550002 03FE0B02 00007FFF
	.long 0xd72c0005                                           // 0000007F70E4: D72C0005
	v_cndmask_b32_e32 v1, s18, v9, vcc_lo                      // 0000007F70E8: 02021212
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007F70EC: BF870193
	v_add3_u32 v3, v3, v6, 0x7fff                              // 0000007F70F0: D6550003 03FE0D03 00007FFF
	.long 0x7e023982                                           // 0000007F70FC: 7E023982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F7100: BF870113
	v_add3_u32 v13, v13, v5, v4                                // 0000007F7104: D655000D 04120B0D
	v_and_or_b32 v1, 0xffff0000, v3, v1                        // 0000007F710C: D6570001 040606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F7118: BF870002
	v_add_co_ci_u32_e64 v15, null, s21, v13, s3                // 0000007F711C: D5207C0F 000E1A15
	ds_store_b32 v0, v1                                        // 0000007F7124: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000007F712C: BF89FC07
	s_barrier                                                  // 0000007F7130: BFBD0000
	buffer_gl0_inv                                             // 0000007F7134: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 0000007F713C: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x380>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 0000007F7140: CA100080 01000080
	s_and_saveexec_b32 s3, s2                                  // 0000007F7148: BE832002
	s_cbranch_execz 10                                         // 0000007F714C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x178>
	v_lshlrev_b32_e32 v0, 1, v23                               // 0000007F7150: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F7154: BF870091
	.long 0xd7006a02                                           // 0000007F7158: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 0000007F715C: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 0000007F7160: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 0000007F7168: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 0000007F7170: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 0000007F7174: 7E001700
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007F7178: 8C7E037E
	v_or_b32_e32 v2, 16, v23                                   // 0000007F717C: 38042E90
	s_mov_b32 s2, exec_lo                                      // 0000007F7180: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F7184: BF870001
	.long 0xd4c4007e                                           // 0000007F7188: D4C4007E
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000007F718C: 0202040C
	s_cbranch_execz 10                                         // 0000007F7190: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1bc>
	v_lshlrev_b32_e32 v1, 1, v2                                // 0000007F7194: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F7198: BF870091
	.long 0xd7006a01                                           // 0000007F719C: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 0000007F71A0: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 0000007F71A4: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 0000007F71AC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007F71B4: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000007F71B8: 7E021701
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007F71BC: 8C7E027E
	v_or_b32_e32 v4, 32, v23                                   // 0000007F71C0: 38082EA0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 0000007F71C4: CA100080 03020080
	s_mov_b32 s2, exec_lo                                      // 0000007F71CC: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F71D0: BF870002
	.long 0xd4c4007e                                           // 0000007F71D4: D4C4007E
	v_cndmask_b32_e32 v1, s12, v4, vcc_lo                      // 0000007F71D8: 0202080C
	s_cbranch_execz 10                                         // 0000007F71DC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x208>
	v_lshlrev_b32_e32 v2, 1, v4                                // 0000007F71E0: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F71E4: BF870091
	.long 0xd7006a04                                           // 0000007F71E8: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 0000007F71EC: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 0000007F71F0: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 0000007F71F8: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 0000007F7200: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007F7204: 7E041702
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007F7208: 8C7E027E
	v_or_b32_e32 v4, 48, v23                                   // 0000007F720C: 38082EB0
	s_mov_b32 s2, exec_lo                                      // 0000007F7210: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F7214: BF870001
	.long 0xd4c4007e                                           // 0000007F7218: D4C4007E
	v_cndmask_b32_e32 v1, s12, v4, vcc_lo                      // 0000007F721C: 0202080C
	s_cbranch_execz 10                                         // 0000007F7220: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x24c>
	v_lshlrev_b32_e32 v3, 1, v4                                // 0000007F7224: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F7228: BF870091
	.long 0xd7006a03                                           // 0000007F722C: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 0000007F7230: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 0000007F7234: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 0000007F723C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007F7244: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000007F7248: 7E061703
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007F724C: 8C7E027E
	v_or_b32_e32 v6, 64, v23                                   // 0000007F7250: 380C2EC0
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 0000007F7254: CA100080 05040080
	s_mov_b32 s2, exec_lo                                      // 0000007F725C: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F7260: BF870002
	.long 0xd4c4007e                                           // 0000007F7264: D4C4007E
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 0000007F7268: 02020C0C
	s_cbranch_execz 10                                         // 0000007F726C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x298>
	v_lshlrev_b32_e32 v4, 1, v6                                // 0000007F7270: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F7274: BF870091
	.long 0xd7006a06                                           // 0000007F7278: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 0000007F727C: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 0000007F7280: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 0000007F7288: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 0000007F7290: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000007F7294: 7E081704
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007F7298: 8C7E027E
	v_or_b32_e32 v6, 0x50, v23                                 // 0000007F729C: 380C2EFF 00000050
	s_mov_b32 s2, exec_lo                                      // 0000007F72A4: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F72A8: BF870001
	.long 0xd4c4007e                                           // 0000007F72AC: D4C4007E
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 0000007F72B0: 02020C0C
	s_cbranch_execz 10                                         // 0000007F72B4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2e0>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000007F72B8: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F72BC: BF870091
	.long 0xd7006a05                                           // 0000007F72C0: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 0000007F72C4: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 0000007F72C8: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 0000007F72D0: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000007F72D8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007F72DC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007F72E0: 8C7E027E
	v_or_b32_e32 v10, 0x60, v23                                // 0000007F72E4: 38142EFF 00000060
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 0000007F72EC: CA100080 07060080
	s_mov_b32 s2, exec_lo                                      // 0000007F72F4: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F72F8: BF870002
	.long 0xd4c4007e                                           // 0000007F72FC: D4C4007E
	v_cndmask_b32_e32 v1, s12, v10, vcc_lo                     // 0000007F7300: 0202140C
	s_cbranch_execz 10                                         // 0000007F7304: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x330>
	v_lshlrev_b32_e32 v6, 1, v10                               // 0000007F7308: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F730C: BF870091
	.long 0xd7006a0a                                           // 0000007F7310: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 0000007F7314: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000007F7318: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 0000007F7320: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 0000007F7328: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000007F732C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007F7330: 8C7E027E
	v_or_b32_e32 v10, 0x70, v23                                // 0000007F7334: 38142EFF 00000070
	s_mov_b32 s2, exec_lo                                      // 0000007F733C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F7340: BF870001
	.long 0xd4c4007e                                           // 0000007F7344: D4C4007E
	v_cndmask_b32_e32 v1, s12, v10, vcc_lo                     // 0000007F7348: 0202140C
	s_cbranch_execz 10                                         // 0000007F734C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_lshlrev_b32_e32 v7, 1, v10                               // 0000007F7350: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F7354: BF870091
	.long 0xd7006a0a                                           // 0000007F7358: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 0000007F735C: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000007F7360: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 0000007F7368: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 0000007F7370: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000007F7374: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007F7378: 8C7E027E
	s_branch 9                                                 // 0000007F737C: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3a4>
	v_mov_b32_e32 v0, 0                                        // 0000007F7380: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F7384: BF870001
	v_mov_b32_e32 v1, v0                                       // 0000007F7388: 7E020300
	v_mov_b32_e32 v2, v0                                       // 0000007F738C: 7E040300
	v_mov_b32_e32 v3, v0                                       // 0000007F7390: 7E060300
	v_mov_b32_e32 v4, v0                                       // 0000007F7394: 7E080300
	v_mov_b32_e32 v5, v0                                       // 0000007F7398: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 0000007F739C: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 0000007F73A0: 7E0E0300
	s_add_u32 s2, s4, s14                                      // 0000007F73A4: 80020E04
	s_addc_u32 s3, s5, s15                                     // 0000007F73A8: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 0000007F73AC: 850E9F0B
	v_mov_b32_e32 v26, 0                                       // 0000007F73B0: 7E340280
	s_add_u32 s10, s10, s14                                    // 0000007F73B4: 800A0E0A
	s_addc_u32 s11, s11, 0                                     // 0000007F73B8: 820B800B
	v_cndmask_b32_e64 v24, 0, 1, s13                           // 0000007F73BC: D5010018 00350280
	s_ashr_i64 s[10:11], s[10:11], 1                           // 0000007F73C4: 868A810A
	v_mov_b32_e32 v27, 0                                       // 0000007F73C8: 7E360280
	v_mad_u64_u32 v[18:19], null, v8, s10, s[2:3]              // 0000007F73CC: D6FE7C12 00081508
	.long 0xd72c000b                                           // 0000007F73D4: D72C000B
	v_cndmask_b32_e32 v0, v8, v11, vcc_lo                      // 0000007F73D8: 02001708
	.long 0xd72c0014                                           // 0000007F73DC: D72C0014
	v_cndmask_b32_e32 v0, v9, v10, vcc_lo                      // 0000007F73E0: 02001509
	.long 0xd4440002                                           // 0000007F73E4: D4440002
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 0000007F73E8: 02022E0C
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000007F73EC: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 0000007F73F4: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007F73F8: BF870004
	v_add3_u32 v25, v20, v19, v11                              // 0000007F73FC: D6550019 042E2714
	v_mov_b32_e32 v11, 0                                       // 0000007F7404: 7E160280
	s_and_saveexec_b32 s3, s2                                  // 0000007F7408: BE832002
	s_cbranch_execz 21                                         // 0000007F740C: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x464>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v8, 4, v23     // 0000007F7410: CA220080 1B082E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F7418: BF870091
	.long 0xd7006a08                                           // 0000007F741C: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 0000007F7420: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 0000007F7424: D5207C09 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s13                        // 0000007F742C: 916A0D7E
	global_load_b128 v[8:11], v[8:9], off                      // 0000007F7430: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 0000007F7438: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x464>
	v_lshlrev_b32_e32 v19, 1, v23                              // 0000007F743C: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F7440: BF870091
	.long 0xd7006a0e                                           // 0000007F7444: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 0000007F7448: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 0000007F744C: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 0000007F7454: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 0000007F745C: BF8903F7
	v_cvt_f32_f16_e32 v27, v14                                 // 0000007F7460: 7E36170E
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007F7464: 8C7E037E
	s_and_saveexec_b32 s3, s2                                  // 0000007F7468: BE832002
	s_cbranch_execz 256                                        // 0000007F746C: BFA50100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x870>
	v_dual_mov_b32 v29, v23 :: v_dual_lshlrev_b32 v14, 1, v23  // 0000007F7470: CA220117 1D0E2E81
	.long 0xd7006a0c                                           // 0000007F7478: D7006A0C
	v_cndmask_b32_e32 v1, s16, v12, vcc_lo                     // 0000007F747C: 02021810
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007F7480: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s17, v13, vcc_lo            // 0000007F7484: D5207C0D 01AA1A11
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 0000007F748C: CA220080 14122E85
	.long 0xd7006a0c                                           // 0000007F7494: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 0000007F7498: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007F749C: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 0000007F74A0: D5207C0D 01AA1A80
	v_lshl_or_b32 v28, v23, 4, 0x100                           // 0000007F74A8: D656001C 03FD0917 00000100
	.long 0xd7006a0c                                           // 0000007F74B4: D7006A0C
	v_cndmask_b32_e32 v1, s4, v12, vcc_lo                      // 0000007F74B8: 02021804
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007F74BC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s5, v13, vcc_lo             // 0000007F74C0: D5207C0D 01AA1A05
	v_mov_b32_e32 v26, v20                                     // 0000007F74C8: 7E340314
	.long 0xd7006a15                                           // 0000007F74CC: D7006A15
	v_cndmask_b32_e32 v0, v12, v160, vcc_lo                    // 0000007F74D0: 0201410C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F74D4: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 0000007F74D8: D5207C16 01AA1A80
	v_mov_b32_e32 v30, v27                                     // 0000007F74E0: 7E3C031B
	s_mov_b32 s4, 0                                            // 0000007F74E4: BE840080
	s_branch 196                                               // 0000007F74E8: BFA000C4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x7fc>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007F74EC: 8C7E057E
	.long 0xd73c001f                                           // 0000007F74F0: D73C001F
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000007F74F4: 02022681
	v_and_b32_e32 v47, 0xff, v8                                // 0000007F74F8: 365E10FF 000000FF
	v_lshrrev_b32_e32 v48, 6, v8                               // 0000007F7500: 32601086
	v_lshrrev_b32_e32 v49, 14, v8                              // 0000007F7504: 3262108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 0000007F7508: 32101096
	v_and_b32_e32 v50, 0xff, v9                                // 0000007F750C: 366412FF 000000FF
	.long 0xd7006a2b                                           // 0000007F7514: D7006A2B
	v_cndmask_b32_e32 v1, s6, v31, vcc_lo                      // 0000007F7518: 02023E06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F751C: BF870001
	v_add_co_ci_u32_e64 v44, null, s7, v32, vcc_lo             // 0000007F7520: D5207C2C 01AA4007
	v_lshlrev_b32_e32 v47, 2, v47                              // 0000007F7528: 305E5E82
	v_and_b32_e32 v48, 0x3fc, v48                              // 0000007F752C: 366060FF 000003FC
	v_and_b32_e32 v49, 0x3fc, v49                              // 0000007F7534: 366262FF 000003FC
	s_clause 0x3                                               // 0000007F753C: BF850003
	global_load_b128 v[31:34], v[43:44], off                   // 0000007F7540: DC5E0000 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:16         // 0000007F7548: DC5E0010 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:32         // 0000007F7550: DC5E0020 277C002B
	global_load_b128 v[43:46], v[43:44], off offset:48         // 0000007F7558: DC5E0030 2B7C002B
	v_lshrrev_b32_e32 v51, 6, v9                               // 0000007F7560: 32661286
	ds_load_b32 v47, v47                                       // 0000007F7564: D8D80000 2F00002F
	ds_load_b32 v48, v48                                       // 0000007F756C: D8D80000 30000030
	ds_load_b32 v49, v49                                       // 0000007F7574: D8D80000 31000031
	v_lshrrev_b32_e32 v52, 14, v9                              // 0000007F757C: 3268128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000007F7580: 32121296
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007F7584: 361010FF 000003FC
	v_lshlrev_b32_e32 v50, 2, v50                              // 0000007F758C: 30646482
	v_and_b32_e32 v51, 0x3fc, v51                              // 0000007F7590: 366666FF 000003FC
	v_and_b32_e32 v52, 0x3fc, v52                              // 0000007F7598: 366868FF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007F75A0: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 0000007F75A8: D8D80000 08000008
	ds_load_b32 v50, v50                                       // 0000007F75B0: D8D80000 32000032
	ds_load_b32 v51, v51                                       // 0000007F75B8: D8D80000 33000033
	ds_load_b32 v52, v52                                       // 0000007F75C0: D8D80000 34000034
	ds_load_b32 v9, v9                                         // 0000007F75C8: D8D80000 09000009
	.long 0xd7006a15                                           // 0000007F75D0: D7006A15
	v_cndmask_b32_e32 v0, v21, v160, vcc_lo                    // 0000007F75D4: 02014115
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007F75D8: BF8704A1
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 0000007F75DC: D5207C16 01AA2C80
	s_and_b32 s2, exec_lo, s2                                  // 0000007F75E4: 8B02027E
	s_or_b32 s4, s2, s4                                        // 0000007F75E8: 8C040402
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 0000007F75EC: BF890C77
	v_dot2_f32_bf16 v31, v31, v47, 0                           // 0000007F75F0: CC1A401F 1A025F1F
	v_lshrrev_b32_e32 v47, 14, v10                             // 0000007F75F8: 325E148E
	s_waitcnt lgkmcnt(6)                                       // 0000007F75FC: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007F7600: BF870132
	v_dot2_f32_bf16 v31, v32, v48, v31                         // 0000007F7604: CC1A401F 1C7E6120
	v_and_b32_e32 v32, 0xff, v10                               // 0000007F760C: 364014FF 000000FF
	s_waitcnt lgkmcnt(5)                                       // 0000007F7614: BF89FC57
	v_dot2_f32_bf16 v31, v33, v49, v31                         // 0000007F7618: CC1A401F 1C7E6321
	v_lshrrev_b32_e32 v33, 6, v10                              // 0000007F7620: 32421486
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000007F7624: 32141496
	s_waitcnt lgkmcnt(4)                                       // 0000007F7628: BF89FC47
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F762C: BF870003
	v_dot2_f32_bf16 v8, v34, v8, v31                           // 0000007F7630: CC1A4008 1C7E1122
	v_lshlrev_b32_e32 v31, 2, v32                              // 0000007F7638: 303E4082
	v_and_b32_e32 v33, 0x3fc, v33                              // 0000007F763C: 364242FF 000003FC
	v_and_b32_e32 v32, 0xff, v11                               // 0000007F7644: 364016FF 000000FF
	v_lshrrev_b32_e32 v34, 6, v11                              // 0000007F764C: 32441686
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000007F7650: BF890837
	v_dot2_f32_bf16 v8, v35, v50, v8                           // 0000007F7654: CC1A4008 1C226523
	ds_load_b32 v31, v31                                       // 0000007F765C: D8D80000 1F00001F
	ds_load_b32 v33, v33                                       // 0000007F7664: D8D80000 21000021
	v_lshrrev_b32_e32 v35, 14, v11                             // 0000007F766C: 3246168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000007F7670: 32161696
	s_waitcnt lgkmcnt(4)                                       // 0000007F7674: BF89FC47
	v_dot2_f32_bf16 v8, v36, v51, v8                           // 0000007F7678: CC1A4008 1C226724
	v_lshlrev_b32_e32 v32, 2, v32                              // 0000007F7680: 30404082
	v_and_b32_e32 v34, 0x3fc, v34                              // 0000007F7684: 364444FF 000003FC
	v_and_b32_e32 v35, 0x3fc, v35                              // 0000007F768C: 364646FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000007F7694: BF89FC37
	v_dot2_f32_bf16 v8, v37, v52, v8                           // 0000007F7698: CC1A4008 1C226925
	v_cndmask_b32_e64 v37, v6, v7, s1                          // 0000007F76A0: D5010025 00060F06
	v_and_b32_e32 v47, 0x3fc, v47                              // 0000007F76A8: 365E5EFF 000003FC
	s_waitcnt lgkmcnt(2)                                       // 0000007F76B0: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F76B4: BF870003
	v_dot2_f32_bf16 v8, v38, v9, v8                            // 0000007F76B8: CC1A4008 1C221326
	ds_load_b32 v36, v47                                       // 0000007F76C0: D8D80000 2400002F
	s_waitcnt vmcnt(1) lgkmcnt(2)                              // 0000007F76C8: BF890427
	v_dot2_f32_bf16 v8, v39, v31, v8                           // 0000007F76CC: CC1A4008 1C223F27
	v_cndmask_b32_e64 v31, v0, v1, s1                          // 0000007F76D4: D501001F 00060300
	v_cndmask_b32_e64 v39, v27, v0, s1                         // 0000007F76DC: D5010027 0006011B
	v_mov_b32_e32 v27, v30                                     // 0000007F76E4: 7E36031E
	s_waitcnt lgkmcnt(1)                                       // 0000007F76E8: BF89FC17
	v_dot2_f32_bf16 v8, v40, v33, v8                           // 0000007F76EC: CC1A4008 1C224328
	v_cndmask_b32_e64 v33, v2, v3, s1                          // 0000007F76F4: D5010021 00060702
	s_waitcnt lgkmcnt(0)                                       // 0000007F76FC: BF89FC07
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F7700: BF870002
	v_dot2_f32_bf16 v8, v41, v36, v8                           // 0000007F7704: CC1A4008 1C224929
	v_cndmask_b32_e64 v36, v5, v6, s1                          // 0000007F770C: D5010024 00060D05
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000007F7714: 361414FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007F771C: 361616FF 000003FC
	ds_load_b32 v9, v10                                        // 0000007F7724: D8D80000 0900000A
	ds_load_b32 v10, v32                                       // 0000007F772C: D8D80000 0A000020
	ds_load_b32 v38, v34                                       // 0000007F7734: D8D80000 26000022
	ds_load_b32 v47, v35                                       // 0000007F773C: D8D80000 2F000023
	ds_load_b32 v48, v11                                       // 0000007F7744: D8D80000 3000000B
	v_cndmask_b32_e64 v32, v1, v2, s1                          // 0000007F774C: D5010020 00060501
	v_cndmask_b32_e64 v35, v4, v5, s1                          // 0000007F7754: D5010023 00060B04
	v_cndmask_b32_e64 v34, v3, v4, s1                          // 0000007F775C: D5010022 00060903
	v_mov_b32_e32 v11, v15                                     // 0000007F7764: 7E16030F
	s_waitcnt lgkmcnt(4)                                       // 0000007F7768: BF89FC47
	v_dot2_f32_bf16 v8, v42, v9, v8                            // 0000007F776C: CC1A4008 1C22132A
	v_mov_b32_e32 v9, v13                                      // 0000007F7774: 7E12030D
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007F7778: BF890037
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000007F777C: BF8701C2
	v_dot2_f32_bf16 v6, v43, v10, v8                           // 0000007F7780: CC1A4006 1C22152B
	v_mov_b32_e32 v10, v14                                     // 0000007F7788: 7E14030E
	v_mov_b32_e32 v8, v12                                      // 0000007F778C: 7E10030C
	s_waitcnt lgkmcnt(2)                                       // 0000007F7790: BF89FC27
	v_dot2_f32_bf16 v2, v44, v38, v6                           // 0000007F7794: CC1A4002 1C1A4D2C
	v_dual_mov_b32 v38, v7 :: v_dual_add_nc_u32 v19, 0x200, v19// 0000007F779C: CA200107 261226FF 00000200
	v_add_nc_u32_e32 v28, 0x100, v28                           // 0000007F77A8: 4A3838FF 00000100
	s_waitcnt lgkmcnt(1)                                       // 0000007F77B0: BF89FC17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F77B4: BF8700A3
	v_dot2_f32_bf16 v0, v45, v47, v2                           // 0000007F77B8: CC1A4000 1C0A5F2D
	s_waitcnt lgkmcnt(0)                                       // 0000007F77C0: BF89FC07
	v_dot2_f32_bf16 v0, v46, v48, v0                           // 0000007F77C4: CC1A4000 1C02612E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F77CC: BF870001
	v_fmac_f32_e32 v26, v39, v0                                // 0000007F77D0: 56340127
	v_dual_mov_b32 v0, v31 :: v_dual_mov_b32 v1, v32           // 0000007F77D4: CA10011F 00000120
	v_dual_mov_b32 v2, v33 :: v_dual_mov_b32 v3, v34           // 0000007F77DC: CA100121 02020122
	v_dual_mov_b32 v4, v35 :: v_dual_mov_b32 v5, v36           // 0000007F77E4: CA100123 04040124
	v_dual_mov_b32 v6, v37 :: v_dual_mov_b32 v7, v38           // 0000007F77EC: CA100125 06060126
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000007F77F4: 917E047E
	s_cbranch_execz 28                                         // 0000007F77F8: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x86c>
	s_waitcnt vmcnt(0)                                         // 0000007F77FC: BF8903F7
	v_dual_mov_b32 v12, v8 :: v_dual_add_nc_u32 v29, 16, v29   // 0000007F7800: CA200108 0C1C3A90
	v_dual_mov_b32 v13, v9 :: v_dual_mov_b32 v14, v10          // 0000007F7808: CA100109 0D0E010A
	v_mov_b32_e32 v15, v11                                     // 0000007F7810: 7E1E030B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F7814: BF870003
	.long 0xd4430002                                           // 0000007F7818: D4430002
	v_cndmask_b32_e32 v1, s12, v29, vcc_lo                     // 0000007F781C: 02023A0C
	s_mov_b32 s5, exec_lo                                      // 0000007F7820: BE85007E
	.long 0xd4c4007e                                           // 0000007F7824: D4C4007E
	v_cndmask_b32_e32 v1, s12, v29, vcc_lo                     // 0000007F7828: 02023A0C
	s_cbranch_execz 65327                                      // 0000007F782C: BFA5FF2F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4ec>
	.long 0xd7006a0c                                           // 0000007F7830: D7006A0C
	v_cndmask_b32_e32 v1, v18, v28, vcc_lo                     // 0000007F7834: 02023912
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F7838: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 0000007F783C: D5207C0D 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 0000007F7844: 7C9A3081
	v_mov_b32_e32 v30, v27                                     // 0000007F7848: 7E3C031B
	global_load_b128 v[12:15], v[12:13], off                   // 0000007F784C: DC5E0000 0C7C000C
	s_cbranch_vccnz 65317                                      // 0000007F7854: BFA4FF25 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4ec>
	global_load_d16_b16 v30, v[21:22], off                     // 0000007F7858: DC820000 1E7C0015
	s_waitcnt vmcnt(0)                                         // 0000007F7860: BF8903F7
	v_cvt_f32_f16_e32 v30, v30                                 // 0000007F7864: 7E3C171E
	s_branch 65312                                             // 0000007F7868: BFA0FF20 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4ec>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007F786C: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F7870: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007F7874: 8C7E037E
	.long 0xd71f0000                                           // 0000007F7878: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007F787C: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 0000007F7880: 3A020088
	v_xor_b32_e32 v2, 4, v0                                    // 0000007F7884: 3A040084
	v_xor_b32_e32 v3, 2, v0                                    // 0000007F7888: 3A060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007F788C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000007F7890: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000007F7894: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007F7898: 7C9804A0
	v_cndmask_b32_e32 v2, v0, v2, vcc_lo                       // 0000007F789C: 02040500
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007F78A0: 7C9806A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F78A4: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007F78A8: 30040482
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007F78AC: 30020282
	ds_bpermute_b32 v1, v1, v26                                // 0000007F78B0: DACC0000 01001A01
	s_waitcnt lgkmcnt(0)                                       // 0000007F78B8: BF89FC07
	v_add_f32_e32 v1, v26, v1                                  // 0000007F78BC: 0602031A
	ds_bpermute_b32 v2, v2, v1                                 // 0000007F78C0: DACC0000 02000102
	s_waitcnt lgkmcnt(0)                                       // 0000007F78C8: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000007F78CC: 06020501
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 0000007F78D0: 02060700
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007F78D4: BF8700B1
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000007F78D8: 30060682
	ds_bpermute_b32 v2, v3, v1                                 // 0000007F78DC: DACC0000 02000103
	v_xor_b32_e32 v3, 1, v0                                    // 0000007F78E4: 3A060081
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007F78E8: 7C9806A0
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 0000007F78EC: 02060700
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 0000007F78F0: 7C942E80
	s_and_b32 s0, vcc_lo, s0                                   // 0000007F78F4: 8B00006A
	s_waitcnt lgkmcnt(0)                                       // 0000007F78F8: BF89FC07
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F78FC: BF870002
	v_dual_add_f32 v0, v1, v2 :: v_dual_lshlrev_b32 v1, 2, v3  // 0000007F7900: C9220501 00000682
	ds_bpermute_b32 v1, v1, v0                                 // 0000007F7908: DACC0000 01000001
	s_and_saveexec_b32 s1, s0                                  // 0000007F7910: BE812000
	s_cbranch_execz 54                                         // 0000007F7914: BFA50036 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x9f0>
	s_waitcnt lgkmcnt(0)                                       // 0000007F7918: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 0000007F791C: 06000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F7920: BF870091
	v_bfe_u32 v1, v0, 16, 1                                    // 0000007F7924: D6100001 02052100
	v_add3_u32 v0, v0, v1, 0x7fff                              // 0000007F792C: D6550000 03FE0300 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F7938: BF870091
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007F793C: 360000FF FFFF0000
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000007F7944: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007F794C: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000007F7950: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000007F7954: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007F7958: BF870121
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 0000007F795C: D6FC7C01 03CA0100
	v_div_scale_f32 v4, vcc_lo, 1.0, v0, 1.0                   // 0000007F7964: D6FC6A04 03CA00F2
	v_rcp_f32_e32 v2, v1                                       // 0000007F796C: 7E045501
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F7970: BF870095
	v_fma_f32 v3, -v1, v2, 1.0                                 // 0000007F7974: D6130003 23CA0501
	v_fmac_f32_e32 v2, v3, v2                                  // 0000007F797C: 56040503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F7980: BF870091
	v_mul_f32_e32 v3, v4, v2                                   // 0000007F7984: 10060504
	v_fma_f32 v5, -v1, v3, v4                                  // 0000007F7988: D6130005 24120701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F7990: BF870091
	v_fmac_f32_e32 v3, v5, v2                                  // 0000007F7994: 56060505
	v_fma_f32 v1, -v1, v3, v4                                  // 0000007F7998: D6130001 24120701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F79A0: BF870091
	v_div_fmas_f32 v1, v1, v2, v3                              // 0000007F79A4: D6370001 040E0501
	v_div_fixup_f32 v2, v1, v0, 1.0                            // 0000007F79AC: D6270002 03CA0101
	.long 0xd73c0000                                           // 0000007F79B4: D73C0000
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000007F79B8: 02022081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F79BC: BF870112
	v_bfe_u32 v3, v2, 16, 1                                    // 0000007F79C0: D6100003 02052102
	.long 0xd7006a00                                           // 0000007F79C8: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007F79CC: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007F79D0: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007F79D4: D5207C01 01AA0209
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000007F79DC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007F79E8: DC960000 007C0200
	s_endpgm                                                   // 0000007F79F0: BFB00000
		...

