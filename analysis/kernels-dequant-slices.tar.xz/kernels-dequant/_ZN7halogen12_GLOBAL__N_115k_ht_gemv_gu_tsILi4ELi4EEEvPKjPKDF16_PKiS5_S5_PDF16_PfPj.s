0000000000946c00 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj>:
; _ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj():
	s_load_b512 s[4:19], s[0:1], null                          // 000000946C00: F4100100 F8000000
	s_mul_hi_i32 s0, s2, 0x66666667                            // 000000946C08: 9700FF02 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000946C10: BF8704A9
	s_lshr_b32 s1, s0, 31                                      // 000000946C14: 85019F00
	s_ashr_i32 s0, s0, 3                                       // 000000946C18: 86008300
	s_add_i32 s20, s0, s1                                      // 000000946C1C: 81140100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000946C20: BF870499
	s_ashr_i32 s21, s20, 31                                    // 000000946C24: 86159F14
	s_lshl_b64 s[0:1], s[20:21], 2                             // 000000946C28: 84808214
	s_waitcnt lgkmcnt(0)                                       // 000000946C2C: BF89FC07
	s_add_u32 s0, s8, s0                                       // 000000946C30: 80000008
	s_addc_u32 s1, s9, s1                                      // 000000946C34: 82010109
	s_load_b32 s8, s[0:1], null                                // 000000946C38: F4000200 F8000000
	s_mov_b32 s1, exec_lo                                      // 000000946C40: BE81007E
	v_cmpx_gt_u32_e32 0x140, v0                                // 000000946C44: 7D9800FF 00000140
	s_cbranch_execz 48                                         // 000000946C4C: BFA50030 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x110>
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 000000946C50: 9700FF02 51EB851F
	v_lshlrev_b32_e32 v4, 4, v0                                // 000000946C58: 30080084
	s_lshr_b32 s3, s0, 31                                      // 000000946C5C: 85039F00
	s_ashr_i32 s0, s0, 6                                       // 000000946C60: 86008600
	v_or_b32_e32 v3, 0xffffffc0, v0                            // 000000946C64: 380600FF FFFFFFC0
	s_add_i32 s0, s0, s3                                       // 000000946C6C: 81000300
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000946C70: BF8700D9
	s_mul_i32 s3, s0, 0x1400                                   // 000000946C74: 9603FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 000000946C7C: 9700FF00 00001400
	s_add_u32 s3, s6, s3                                       // 000000946C84: 80030306
	s_addc_u32 s0, s7, s0                                      // 000000946C88: 82000007
	.long 0xd7000301                                           // 000000946C8C: D7000301
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 000000946C90: 02020803
	v_add_co_ci_u32_e64 v2, null, s0, 0, s3                    // 000000946C94: D5207C02 000D0000
	s_mov_b32 s3, 0                                            // 000000946C9C: BE830080
	s_nop 0                                                    // 000000946CA0: BF800000
	s_nop 0                                                    // 000000946CA4: BF800000
	s_nop 0                                                    // 000000946CA8: BF800000
	s_nop 0                                                    // 000000946CAC: BF800000
	s_nop 0                                                    // 000000946CB0: BF800000
	s_nop 0                                                    // 000000946CB4: BF800000
	s_nop 0                                                    // 000000946CB8: BF800000
	s_nop 0                                                    // 000000946CBC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 000000946CC0: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 64, v3                                // 000000946CC8: 4A0606C0
	.long 0xd7006a01                                           // 000000946CCC: D7006A01
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 000000946CD0: 020202FF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000946CD8: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000946CDC: D5207C02 01AA0480
	.long 0xd4490000                                           // 000000946CE4: D4490000
	v_cndmask_b32_e32 v1, 0xff, v3, vcc_lo                     // 000000946CE8: 020206FF 000000FF
	s_or_b32 s3, s0, s3                                        // 000000946CF0: 8C030300
	s_waitcnt vmcnt(0)                                         // 000000946CF4: BF8903F7
	ds_store_b128 v4, v[5:8]                                   // 000000946CF8: DB7C0000 00000504
	v_add_nc_u32_e32 v4, 0x400, v4                             // 000000946D00: 4A0808FF 00000400
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000946D08: 917E037E
	s_cbranch_execnz 65516                                     // 000000946D0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0xc0>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000946D10: 8C7E017E
	s_ashr_i32 s0, s2, 31                                      // 000000946D14: 86009F02
	v_lshrrev_b32_e32 v25, 5, v0                               // 000000946D18: 32320085
	s_lshr_b32 s0, s0, 30                                      // 000000946D1C: 85009E00
	v_dual_mov_b32 v1, 0 :: v_dual_and_b32 v26, 31, v0         // 000000946D20: CA240080 011A009F
	s_add_i32 s0, s2, s0                                       // 000000946D28: 81000002
	s_mul_i32 s3, s20, -5                                      // 000000946D2C: 9603C514
	s_ashr_i32 s6, s0, 2                                       // 000000946D30: 86068200
	s_lshl_b32 s0, s2, 1                                       // 000000946D34: 84008102
	s_lshl_b32 s1, s6, 3                                       // 000000946D38: 84018306
	v_mov_b32_e32 v16, v1                                      // 000000946D3C: 7E200301
	s_sub_i32 s0, s0, s1                                       // 000000946D40: 81800100
	v_mov_b32_e32 v3, v1                                       // 000000946D44: 7E060301
	v_or_b32_e32 v22, s0, v25                                  // 000000946D48: 382C3200
	v_dual_mov_b32 v4, v1 :: v_dual_lshlrev_b32 v27, 2, v26    // 000000946D4C: CA220101 041A3482
	v_mov_b32_e32 v5, v1                                       // 000000946D54: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000946D58: 7E0C0301
	s_delay_alu instid0(VALU_DEP_4)                            // 000000946D5C: BF870004
	.long 0xd72c0012                                           // 000000946D60: D72C0012
	v_cndmask_b32_e32 v0, v22, v148, vcc_lo                    // 000000946D64: 02012916
	v_mov_b32_e32 v7, v1                                       // 000000946D68: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 000000946D6C: 7E100301
	v_mov_b32_e32 v9, v1                                       // 000000946D70: 7E120301
	v_mov_b32_e32 v10, v1                                      // 000000946D74: 7E140301
	v_mov_b32_e32 v11, v1                                      // 000000946D78: 7E160301
	v_mov_b32_e32 v12, v1                                      // 000000946D7C: 7E180301
	v_mov_b32_e32 v13, v1                                      // 000000946D80: 7E1A0301
	v_min_i32_e32 v20, 0x8c, v18                               // 000000946D84: 222824FF 0000008C
	v_mov_b32_e32 v2, v1                                       // 000000946D8C: 7E040301
	v_mov_b32_e32 v14, v1                                      // 000000946D90: 7E1C0301
	v_mov_b32_e32 v15, v1                                      // 000000946D94: 7E1E0301
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000946D98: 3426249F
	v_add_nc_u32_e32 v29, 20, v20                              // 000000946D9C: 4A3A2894
	v_mov_b32_e32 v17, v16                                     // 000000946DA0: 7E220310
	s_delay_alu instid0(VALU_DEP_4)                            // 000000946DA4: BF870004
	v_mov_b32_e32 v16, v15                                     // 000000946DA8: 7E20030F
	v_mov_b32_e32 v15, v14                                     // 000000946DAC: 7E1E030E
	v_mov_b32_e32 v14, v13                                     // 000000946DB0: 7E1C030D
	v_cmp_lt_i32_e32 vcc_lo, v18, v29                          // 000000946DB4: 7C823B12
	v_mov_b32_e32 v13, v12                                     // 000000946DB8: 7E1A030C
	v_mov_b32_e32 v12, v11                                     // 000000946DBC: 7E18030B
	v_mov_b32_e32 v11, v10                                     // 000000946DC0: 7E16030A
	v_mov_b32_e32 v10, v9                                      // 000000946DC4: 7E140309
	v_mov_b32_e32 v9, v8                                       // 000000946DC8: 7E120308
	v_mov_b32_e32 v8, v7                                       // 000000946DCC: 7E100307
	v_mov_b32_e32 v7, v6                                       // 000000946DD0: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 000000946DD4: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000946DD8: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000946DDC: 7E080303
	v_mov_b32_e32 v3, v2                                       // 000000946DE0: 7E060302
	v_mov_b32_e32 v2, v1                                       // 000000946DE4: 7E040301
	s_add_i32 s2, s3, s6                                       // 000000946DE8: 81020603
	s_waitcnt lgkmcnt(0)                                       // 000000946DEC: BF89FC07
	s_mul_hi_i32 s1, s8, 0x190000                              // 000000946DF0: 9701FF08 00190000
	s_mul_i32 s7, s8, 0x190000                                 // 000000946DF8: 9607FF08 00190000
	s_mul_hi_i32 s9, s2, 0x50000                               // 000000946E00: 9709FF02 00050000
	s_mul_i32 s21, s2, 0x50000                                 // 000000946E08: 9615FF02 00050000
	s_barrier                                                  // 000000946E10: BFBD0000
	buffer_gl0_inv                                             // 000000946E14: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 000000946E1C: BE83206A
	s_cbranch_execz 49                                         // 000000946E20: BFA50031 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x2e8>
	.long 0xd73c0002                                           // 000000946E24: D73C0002
	v_cndmask_b32_e32 v1, 11, v18, vcc_lo                      // 000000946E28: 0202248B
	s_add_u32 s0, s4, s7                                       // 000000946E2C: 80000704
	s_addc_u32 s22, s5, s1                                     // 000000946E30: 82160105
	s_add_u32 s0, s0, s21                                      // 000000946E34: 80001500
	s_addc_u32 s22, s22, s9                                    // 000000946E38: 82160916
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000946E3C: BF870091
	.long 0xd7000002                                           // 000000946E40: D7000002
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000946E44: 02020400
	v_add_co_ci_u32_e64 v3, null, s22, v3, s0                  // 000000946E48: D5207C03 00020616
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000946E50: BF870092
	.long 0xd7000017                                           // 000000946E54: D7000017
	v_cndmask_b32_e32 v1, v2, v27, vcc_lo                      // 000000946E58: 02023702
	v_add_co_ci_u32_e64 v24, null, 0, v3, s0                   // 000000946E5C: D5207C18 00020680
	s_clause 0xf                                               // 000000946E64: BF85000F
	global_load_b32 v2, v[23:24], off                          // 000000946E68: DC520000 027C0017
	global_load_b32 v3, v[23:24], off offset:128               // 000000946E70: DC520080 037C0017
	global_load_b32 v4, v[23:24], off offset:256               // 000000946E78: DC520100 047C0017
	global_load_b32 v5, v[23:24], off offset:384               // 000000946E80: DC520180 057C0017
	global_load_b32 v6, v[23:24], off offset:512               // 000000946E88: DC520200 067C0017
	global_load_b32 v7, v[23:24], off offset:640               // 000000946E90: DC520280 077C0017
	global_load_b32 v8, v[23:24], off offset:768               // 000000946E98: DC520300 087C0017
	global_load_b32 v9, v[23:24], off offset:896               // 000000946EA0: DC520380 097C0017
	global_load_b32 v10, v[23:24], off offset:1024             // 000000946EA8: DC520400 0A7C0017
	global_load_b32 v11, v[23:24], off offset:1152             // 000000946EB0: DC520480 0B7C0017
	global_load_b32 v12, v[23:24], off offset:1280             // 000000946EB8: DC520500 0C7C0017
	global_load_b32 v13, v[23:24], off offset:1408             // 000000946EC0: DC520580 0D7C0017
	global_load_b32 v14, v[23:24], off offset:1536             // 000000946EC8: DC520600 0E7C0017
	global_load_b32 v15, v[23:24], off offset:1664             // 000000946ED0: DC520680 0F7C0017
	global_load_b32 v16, v[23:24], off offset:1792             // 000000946ED8: DC520700 107C0017
	global_load_b32 v17, v[23:24], off offset:1920             // 000000946EE0: DC520780 117C0017
	s_or_b32 exec_lo, exec_lo, s3                              // 000000946EE8: 8C7E037E
	.long 0xd44a0000                                           // 000000946EEC: D44A0000
	v_cndmask_b32_e32 v1, 0, v26, vcc_lo                       // 000000946EF0: 02023480
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v31, 0             // 000000946EF4: CA100080 1E1E0080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v33, 0             // 000000946EFC: CA100080 20200080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 000000946F04: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 000000946F0C: CA100080 24240080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 000000946F14: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 000000946F1C: CA100080 28280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v43, 0             // 000000946F24: CA100080 2A2A0080
	v_mov_b32_e32 v28, 0                                       // 000000946F2C: 7E380280
	s_and_saveexec_b32 s3, vcc_lo                              // 000000946F30: BE83206A
	s_cbranch_execz 1859                                       // 000000946F34: BFA50743 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x2044>
	v_dual_mov_b32 v28, 0 :: v_dual_lshlrev_b32 v1, 5, v26     // 000000946F38: CA220080 1C003485
	.long 0xd73c0017                                           // 000000946F40: D73C0017
	v_cndmask_b32_e32 v1, 11, v18, vcc_lo                      // 000000946F44: 0202248B
	.long 0xd72c0013                                           // 000000946F48: D72C0013
	v_cndmask_b32_e32 v1, 0x280, v22, vcc_lo                   // 000000946F4C: 02022CFF 00000280
	s_add_u32 s7, s7, s21                                      // 000000946F54: 80071507
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000946F58: BF8701A3
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v21, 0x3f0, v1  // 000000946F5C: CA200080 2A1402FF 000003F0
	s_addc_u32 s1, s1, s9                                      // 000000946F68: 82010901
	.long 0xd7006a17                                           // 000000946F6C: D7006A17
	v_cndmask_b32_e32 v1, s7, v23, vcc_lo                      // 000000946F70: 02022E07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000946F74: BF870212
	v_lshrrev_b32_e32 v32, 5, v21                              // 000000946F78: 32402A85
	v_and_or_b32 v44, v0, 16, v19                              // 000000946F7C: D657002C 044D2100
	v_dual_mov_b32 v40, 0 :: v_dual_and_b32 v19, 0x7e0, v21    // 000000946F84: CA240080 28122AFF 000007E0
	v_add_co_ci_u32_e64 v24, null, s1, v24, vcc_lo             // 000000946F90: D5207C18 01AA3001
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000946F98: BF870194
	v_subrev_nc_u32_e32 v32, 32, v32                           // 000000946F9C: 4E4040A0
	v_sub_nc_u32_e32 v1, v19, v1                               // 000000946FA0: 4C020313
	.long 0xd7006a17                                           // 000000946FA4: D7006A17
	v_cndmask_b32_e32 v1, v23, v27, vcc_lo                     // 000000946FA8: 02023717
	v_mul_u32_u24_e32 v30, 0x840, v25                          // 000000946FAC: 163C32FF 00000840
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000946FB4: BF8701B4
	v_cndmask_b32_e64 v21, v32, 31, s0                         // 000000946FB8: D5010015 00013F20
	v_add_co_ci_u32_e64 v24, null, 0, v24, vcc_lo              // 000000946FC0: D5207C18 01AA3080
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v45, 0xfffffc30, v1// 000000946FC8: CA200080 242C02FF FFFFFC30
	v_dual_mov_b32 v38, 0 :: v_dual_add_nc_u32 v19, 1, v21     // 000000946FD4: CA200080 26122A81
	.long 0xd7006a17                                           // 000000946FDC: D7006A17
	v_cndmask_b32_e32 v1, s4, v23, vcc_lo                      // 000000946FE0: 02022E04
	v_mad_u32_u24 v31, 0x840, v25, v27                         // 000000946FE4: D60B001F 046E32FF 00000840
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000946FF0: BF8701B3
	v_dual_mov_b32 v34, 0 :: v_dual_and_b32 v1, 31, v19        // 000000946FF4: CA240080 2200269F
	v_add_co_ci_u32_e64 v24, null, s5, v24, vcc_lo             // 000000946FFC: D5207C18 01AA3005
	v_lshl_add_u32 v19, v21, 2, v30                            // 000000947004: D6460013 04790515
	v_lshl_add_u32 v1, v1, 2, v30                              // 00000094700C: D6460001 04790501
	.long 0xd7006a17                                           // 000000947014: D7006A17
	v_cndmask_b32_e32 v1, 0x800, v23, vcc_lo                   // 000000947018: 02022EFF 00000800
	s_delay_alu instid0(VALU_DEP_1)                            // 000000947020: BF870001
	v_add_co_ci_u32_e64 v24, null, 0, v24, vcc_lo              // 000000947024: D5207C18 01AA3080
	v_sub_nc_u32_e32 v46, 0, v20                               // 00000094702C: 4C5C2880
	v_dual_mov_b32 v32, 0 :: v_dual_add_nc_u32 v47, 1, v18     // 000000947030: CA200080 202E2481
	v_dual_mov_b32 v43, 0 :: v_dual_add_nc_u32 v48, 0x1400, v31// 000000947038: CA200080 2B303EFF 00001400
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v49, 0x1800, v31// 000000947044: CA200080 1E303EFF 00001800
	v_dual_mov_b32 v41, 0 :: v_dual_add_nc_u32 v50, 0x1400, v19// 000000947050: CA200080 293226FF 00001400
	v_add_nc_u32_e32 v51, 0x1400, v1                           // 00000094705C: 4A6602FF 00001400
	v_dual_mov_b32 v39, 0 :: v_dual_add_nc_u32 v52, 0x1800, v19// 000000947064: CA200080 273426FF 00001800
	v_add_nc_u32_e32 v53, 0x1800, v1                           // 000000947070: 4A6A02FF 00001800
	v_mov_b32_e32 v37, 0                                       // 000000947078: 7E4A0280
	v_mov_b32_e32 v35, 0                                       // 00000094707C: 7E460280
	v_mov_b32_e32 v33, 0                                       // 000000947080: 7E420280
	v_mov_b32_e32 v31, 0                                       // 000000947084: 7E3E0280
	v_mov_b32_e32 v1, 0                                        // 000000947088: 7E020280
	s_mov_b32 s4, 0                                            // 00000094708C: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000947090: B0051EEE
	s_branch 1708                                              // 000000947094: BFA006AC <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x1f48>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000947098: 8C7E017E
	ds_load_2addr_b32 v[54:55], v51 offset1:32                 // 00000094709C: D8DC2000 36000033
	ds_load_2addr_b32 v[64:65], v48 offset1:32                 // 0000009470A4: D8DC2000 40000030
	ds_load_2addr_b32 v[58:59], v50 offset1:32                 // 0000009470AC: D8DC2000 3A000032
	ds_load_b128 v[18:21], v44                                 // 0000009470B4: DBFC0000 1200002C
	ds_load_2addr_b32 v[60:61], v50 offset0:64 offset1:96      // 0000009470BC: D8DC6040 3C000032
	ds_load_2addr_b32 v[62:63], v51 offset0:64 offset1:96      // 0000009470C4: D8DC6040 3E000033
	.long 0xd7000117                                           // 0000009470CC: D7000117
	v_cndmask_b32_e32 v1, 0x800, v23, vcc_lo                   // 0000009470D0: 02022EFF 00000800
	v_add_nc_u32_e32 v44, 32, v44                              // 0000009470D8: 4A5858A0
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000009470DC: D5207C18 00063080
	s_waitcnt lgkmcnt(5)                                       // 0000009470E4: BF89FC57
	v_mov_b32_e32 v57, v54                                     // 0000009470E8: 7E720336
	s_waitcnt lgkmcnt(4)                                       // 0000009470EC: BF89FC47
	v_bfe_u32 v54, v64, 12, 16                                 // 0000009470F0: D6100036 02411940
	v_bfe_u32 v66, v64, 8, 16                                  // 0000009470F8: D6100042 02411140
	v_bfe_u32 v67, v64, 4, 16                                  // 000000947100: D6100043 02410940
	v_and_b32_e32 v64, 0xffff, v64                             // 000000947108: 368080FF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 000000947110: BF89FC37
	.long 0xd73d0039                                           // 000000947114: D73D0039
	v_cndmask_b32_e32 v1, v45, v57, vcc_lo                     // 000000947118: 0202732D
	v_mov_b32_e32 v56, v59                                     // 00000094711C: 7E70033B
	v_bfe_u32 v59, v65, 12, 16                                 // 000000947120: D610003B 02411941
	v_bfe_u32 v68, v65, 8, 16                                  // 000000947128: D6100044 02411141
	v_bfe_u32 v69, v65, 4, 16                                  // 000000947130: D6100045 02410941
	v_and_b32_e32 v65, 0xffff, v65                             // 000000947138: 368282FF 0000FFFF
	.long 0xd72c003a                                           // 000000947140: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000947144: 02026CFF 83DCD12D
	.long 0xd73d0036                                           // 00000094714C: D73D0036
	v_cndmask_b32_e32 v1, v45, v55, vcc_lo                     // 000000947150: 02026F2D
	v_bfe_u32 v56, v57, 12, 16                                 // 000000947154: D6100038 02411939
	.long 0xd72c0037                                           // 00000094715C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000947160: 020276FF 83DCD12D
	v_bfe_u32 v59, v57, 8, 16                                  // 000000947168: D610003B 02411139
	.long 0xd72c0042                                           // 000000947170: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000947174: 020284FF 83DCD12D
	v_bfe_u32 v70, v57, 4, 16                                  // 00000094717C: D6100046 02410939
	.long 0xd72c0038                                           // 000000947184: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000947188: 020270FF 83DCD12D
	.long 0xd72c0040                                           // 000000947190: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000947194: 020280FF 83DCD12D
	.long 0xd72c003b                                           // 00000094719C: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009471A0: 020276FF 83DCD12D
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000009471A8: D622003A 03FD013A 00006400
	.long 0xd72c0043                                           // 0000009471B4: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 0000009471B8: 020286FF 83DCD12D
	v_bfe_u32 v71, v54, 12, 16                                 // 0000009471C0: D6100047 02411936
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000009471C8: D6220042 03FD0142 00006400
	.long 0xd72c0046                                           // 0000009471D4: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 0000009471D8: 02028CFF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009471E0: D6220038 03FD0138 00006400
	v_and_b32_e32 v58, 0xffff, v58                             // 0000009471EC: 367474FF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009471F4: D622003B 03FD013B 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000947200: D6220040 03FD0140 00006400
	v_bfe_u32 v72, v54, 8, 16                                  // 00000094720C: D6100048 02411136
	v_and_b32_e32 v56, 0xffff, v56                             // 000000947214: 367070FF 0000FFFF
	.long 0xd72c0047                                           // 00000094721C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000947220: 02028EFF 83DCD12D
	v_lshl_or_b32 v58, v66, 16, v58                            // 000000947228: D656003A 04E92142
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000947230: D6220043 03FD0143 00006400
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000094723C: 30808090
	v_lshl_or_b32 v56, v59, 16, v56                            // 000000947240: D6560038 04E1213B
	.long 0xd72c0048                                           // 000000947248: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 00000094724C: 020290FF 83DCD12D
	v_sad_u8 v66, v70, 0, 0x6400                               // 000000947254: D6220042 03FD0146 00006400
	v_pk_fma_f16 v70, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947260: CC0E0046 0BFC0B3A 0000C931
	v_and_or_b32 v59, 0xffff, v67, v64                         // 00000094726C: D657003B 050286FF 0000FFFF
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947278: CC0E0038 0BFC0B38 0000C931
	v_and_b32_e32 v57, 0xffff, v57                             // 000000947284: 367272FF 0000FFFF
	v_sad_u8 v64, v71, 0, 0x6400                               // 00000094728C: D6220040 03FD0147 00006400
	.long 0xd72c0044                                           // 000000947298: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 00000094729C: 020288FF 83DCD12D
	v_bfe_u32 v73, v54, 4, 16                                  // 0000009472A4: D6100049 02410936
	s_waitcnt lgkmcnt(2)                                       // 0000009472AC: BF89FC27
	v_dot2acc_f32_f16 v28, v56, v18                            // 0000009472B0: 04382538
	.long 0xd72c0039                                           // 0000009472B4: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009472B8: 020272FF 83DCD12D
	v_and_b32_e32 v54, 0xffff, v54                             // 0000009472C0: 366C6CFF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009472C8: D6220037 03FD0137 00006400
	v_sad_u8 v67, v72, 0, 0x6400                               // 0000009472D4: D6220043 03FD0148 00006400
	v_and_b32_e32 v64, 0xffff, v64                             // 0000009472E0: 368080FF 0000FFFF
	v_pk_fma_f16 v71, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009472E8: CC0E0047 0BFC0B3B 0000C931
	s_waitcnt lgkmcnt(0)                                       // 0000009472F4: BF89FC07
	v_mov_b32_e32 v59, v62                                     // 0000009472F8: 7E76033E
	.long 0xd72c0036                                           // 0000009472FC: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000947300: 02026CFF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000947308: D6220039 03FD0139 00006400
	v_lshl_or_b32 v64, v67, 16, v64                            // 000000947314: D6560040 05012143
	v_and_b32_e32 v67, 0xffff, v55                             // 00000094731C: 36866EFF 0000FFFF
	v_sad_u8 v62, v68, 0, 0x6400                               // 000000947324: D622003E 03FD0144 00006400
	.long 0xd72c0049                                           // 000000947330: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000947334: 020292FF 83DCD12D
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000094733C: 30727290
	.long 0xd72c0041                                           // 000000947340: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000947344: 020282FF 83DCD12D
	ds_load_2addr_b32 v[55:56], v48 offset0:64 offset1:96      // 00000094734C: D8DC6040 37000030
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000947354: D6220036 03FD0136 00006400
	v_and_or_b32 v57, 0xffff, v66, v57                         // 000000947360: D6570039 04E684FF 0000FFFF
	v_sad_u8 v66, v73, 0, 0x6400                               // 00000094736C: D6220042 03FD0149 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000947378: BF870092
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000094737C: CC0E0039 0BFC0B39 0000C931
	v_dot2acc_f32_f16 v28, v57, v19                            // 000000947388: 04382739
	.long 0xd73d0039                                           // 00000094738C: D73D0039
	v_cndmask_b32_e32 v1, v45, v59, vcc_lo                     // 000000947390: 0202772D
	v_lshl_or_b32 v58, v62, 16, v67                            // 000000947394: D656003A 050D213E
	v_sad_u8 v60, v65, 0, 0x6400                               // 00000094739C: D622003C 03FD0141 00006400
	v_pk_fma_f16 v59, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009473A8: CC0E003B 0BFC0B40 0000C931
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009473B4: BF870003
	v_pk_fma_f16 v65, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009473B8: CC0E0041 0BFC0B3A 0000C931
	v_lshlrev_b32_e32 v54, 16, v54                             // 0000009473C4: 306C6C90
	v_bfe_u32 v62, v57, 12, 16                                 // 0000009473C8: D610003E 02411939
	v_and_b32_e32 v64, 0xffff, v57                             // 0000009473D0: 368072FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 0000009473D8: BF89FC07
	v_bfe_u32 v67, v55, 12, 16                                 // 0000009473DC: D6100043 02411937
	v_bfe_u32 v68, v55, 8, 16                                  // 0000009473E4: D6100044 02411137
	v_and_or_b32 v54, 0xffff, v66, v54                         // 0000009473EC: D6570036 04DA84FF 0000FFFF
	.long 0xd72c0042                                           // 0000009473F8: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 0000009473FC: 02028AFF 83DCD12D
	.long 0xd72c003e                                           // 000000947404: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000947408: 02027CFF 83DCD12D
	.long 0xd72c0040                                           // 000000947410: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000947414: 020280FF 83DCD12D
	.long 0xd72c0043                                           // 00000094741C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000947420: 020286FF 83DCD12D
	.long 0xd72c0044                                           // 000000947428: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 00000094742C: 020288FF 83DCD12D
	v_lshlrev_b32_e32 v60, 16, v60                             // 000000947434: 30787890
	v_bfe_u32 v69, v55, 4, 16                                  // 000000947438: D6100045 02410937
	v_and_b32_e32 v55, 0xffff, v55                             // 000000947440: 366E6EFF 0000FFFF
	v_sad_u8 v58, v66, 0, 0x6400                               // 000000947448: D622003A 03FD0142 00006400
	v_bfe_u32 v66, v57, 8, 16                                  // 000000947454: D6100042 02411139
	v_bfe_u32 v57, v57, 4, 16                                  // 00000094745C: D6100039 02410939
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000947464: D622003E 03FD013E 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000947470: D6220040 03FD0140 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 00000094747C: D6220043 03FD0143 00006400
	.long 0xd72c0042                                           // 000000947488: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 00000094748C: 020284FF 83DCD12D
	.long 0xd72c0039                                           // 000000947494: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000947498: 020272FF 83DCD12D
	v_and_b32_e32 v62, 0xffff, v62                             // 0000009474A0: 367C7CFF 0000FFFF
	v_lshlrev_b32_e32 v64, 16, v64                             // 0000009474A8: 30808090
	v_and_or_b32 v58, 0xffff, v58, v60                         // 0000009474AC: D657003A 04F274FF 0000FFFF
	v_dot2acc_f32_f16 v43, v59, v18                            // 0000009474B8: 0456253B
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009474BC: CC0E0036 0BFC0B36 0000C931
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000009474C8: D6220042 03FD0142 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009474D4: D6220039 03FD0139 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009474E0: BF870193
	v_dot2acc_f32_f16 v43, v54, v19                            // 0000009474E4: 04562736
	v_lshl_or_b32 v60, v66, 16, v62                            // 0000009474E8: D656003C 04F92142
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009474F0: BF870003
	v_and_or_b32 v57, 0xffff, v57, v64                         // 0000009474F4: D6570039 050272FF 0000FFFF
	v_and_b32_e32 v64, 0xffff, v67                             // 000000947500: 368086FF 0000FFFF
	v_sad_u8 v66, v68, 0, 0x6400                               // 000000947508: D6220042 03FD0144 00006400
	.long 0xd72c003e                                           // 000000947514: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000947518: 02028AFF 83DCD12D
	v_pk_fma_f16 v59, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947520: CC0E003B 0BFC0B3C 0000C931
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000094752C: CC0E0039 0BFC0B39 0000C931
	v_dot2acc_f32_f16 v43, v65, v20                            // 000000947538: 04562941
	v_lshl_or_b32 v60, v66, 16, v64                            // 00000094753C: D656003C 05012142
	v_mov_b32_e32 v64, v61                                     // 000000947544: 7E80033D
	.long 0xd72c0037                                           // 000000947548: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 00000094754C: 02026EFF 83DCD12D
	v_dot2acc_f32_f16 v42, v59, v18                            // 000000947554: 0454253B
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000947558: D622003E 03FD013E 00006400
	v_pk_fma_f16 v54, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947564: CC0E0036 0BFC0B3C 0000C931
	v_and_b32_e32 v65, 0xffff, v56                             // 000000947570: 368270FF 0000FFFF
	v_pk_fma_f16 v59, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947578: CC0E003B 0BFC0B3A 0000C931
	v_dot2acc_f32_f16 v42, v57, v19                            // 000000947584: 04542739
	.long 0xd73d0039                                           // 000000947588: D73D0039
	v_cndmask_b32_e32 v1, v45, v63, vcc_lo                     // 00000094758C: 02027F2D
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000947590: D6220037 03FD0137 00006400
	v_bfe_u32 v63, v56, 8, 16                                  // 00000094759C: D610003F 02411138
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009475A4: BF870224
	v_dual_dot2acc_f32_f16 v43, v59, v21 :: v_dual_dot2acc_f32_f16 v42, v54, v20// 0000009475A8: CB182B3B 2B2A2936
	.long 0xd72c0041                                           // 0000009475B0: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 0000009475B4: 020282FF 83DCD12D
	v_lshlrev_b32_e32 v55, 16, v55                             // 0000009475BC: 306E6E90
	v_bfe_u32 v54, v57, 12, 16                                 // 0000009475C0: D6100036 02411939
	v_bfe_u32 v58, v57, 8, 16                                  // 0000009475C8: D610003A 02411139
	v_bfe_u32 v59, v57, 4, 16                                  // 0000009475D0: D610003B 02410939
	v_and_b32_e32 v61, 0xffff, v57                             // 0000009475D8: 367A72FF 0000FFFF
	v_and_or_b32 v55, 0xffff, v62, v55                         // 0000009475E0: D6570037 04DE7CFF 0000FFFF
	.long 0xd72c003c                                           // 0000009475EC: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009475F0: 02026CFF 83DCD12D
	v_bfe_u32 v62, v56, 12, 16                                 // 0000009475F8: D610003E 02411938
	.long 0xd72c0040                                           // 000000947600: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000947604: 020274FF 83DCD12D
	ds_load_2addr_b32 v[57:58], v50 offset0:128 offset1:160    // 00000094760C: D8DCA080 39000032
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947614: CC0E0037 0BFC0B37 0000C931
	.long 0xd72c003b                                           // 000000947620: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000947624: 020276FF 83DCD12D
	.long 0xd72c003d                                           // 00000094762C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000947630: 02027AFF 83DCD12D
	.long 0xd72c003e                                           // 000000947638: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 00000094763C: 02027CFF 83DCD12D
	v_bfe_u32 v56, v56, 4, 16                                  // 000000947644: D6100038 02410938
	v_dot2acc_f32_f16 v42, v55, v21                            // 00000094764C: 04542B37
	ds_load_2addr_b32 v[54:55], v51 offset0:128 offset1:160    // 000000947650: D8DCA080 36000033
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000947658: D6220041 03FD0141 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000947664: D622003C 03FD013C 00006400
	v_sad_u8 v67, v59, 0, 0x6400                               // 000000947670: D6220043 03FD013B 00006400
	v_sad_u8 v59, v61, 0, 0x6400                               // 00000094767C: D622003B 03FD013D 00006400
	v_sad_u8 v61, v62, 0, 0x6400                               // 000000947688: D622003D 03FD013E 00006400
	.long 0xd72c003e                                           // 000000947694: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000947698: 02027EFF 83DCD12D
	.long 0xd72c003f                                           // 0000009476A0: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009476A4: 020270FF 83DCD12D
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000009476AC: D6220040 03FD0140 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000009476B8: BF870144
	v_dual_dot2acc_f32_f16 v28, v70, v20 :: v_dual_and_b32 v61, 0xffff, v61// 0000009476BC: CB242946 1C3C7AFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 0000009476C8: BF89FC07
	v_mov_b32_e32 v56, v54                                     // 0000009476CC: 7E700336
	v_lshlrev_b32_e32 v54, 16, v59                             // 0000009476D0: 306C7690
	.long 0xd73d0038                                           // 0000009476D4: D73D0038
	v_cndmask_b32_e32 v1, v45, v56, vcc_lo                     // 0000009476D8: 0202712D
	v_sad_u8 v57, v62, 0, 0x6400                               // 0000009476DC: D6220039 03FD013E 00006400
	v_sad_u8 v62, v63, 0, 0x6400                               // 0000009476E8: D622003E 03FD013F 00006400
	v_lshlrev_b32_e32 v63, 16, v65                             // 0000009476F4: 307E8290
	v_and_or_b32 v54, 0xffff, v67, v54                         // 0000009476F8: D6570036 04DA86FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000947704: BF870224
	v_lshl_or_b32 v57, v57, 16, v61                            // 000000947708: D6560039 04F52139
	v_bfe_u32 v65, v56, 12, 16                                 // 000000947710: D6100041 02411938
	v_and_or_b32 v61, 0xffff, v62, v63                         // 000000947718: D657003D 04FE7CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000947724: BF870214
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947728: CC0E0036 0BFC0B36 0000C931
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947734: CC0E0039 0BFC0B39 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000947740: BF870214
	.long 0xd72c003f                                           // 000000947744: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000947748: 020282FF 83DCD12D
	v_pk_fma_f16 v61, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947750: CC0E003D 0BFC0B3D 0000C931
	v_and_b32_e32 v66, 0xffff, v60                             // 00000094775C: 368478FF 0000FFFF
	ds_load_2addr_b32 v[59:60], v48 offset0:128 offset1:160    // 000000947764: D8DCA080 3B000030
	v_lshl_or_b32 v64, v64, 16, v66                            // 00000094776C: D6560040 05092140
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000947774: D622003F 03FD013F 00006400
	v_dot2acc_f32_f16 v28, v71, v21                            // 000000947780: 04382B47
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000947784: BF870223
	v_pk_fma_f16 v62, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947788: CC0E003E 0BFC0B40 0000C931
	v_and_b32_e32 v64, 0xffff, v56                             // 000000947794: 368070FF 0000FFFF
	v_and_b32_e32 v63, 0xffff, v63                             // 00000094779C: 367E7EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009477A4: BF870243
	v_dot2acc_f32_f16 v41, v62, v18                            // 0000009477A8: 0452253E
	v_bfe_u32 v62, v56, 8, 16                                  // 0000009477AC: D610003E 02411138
	v_bfe_u32 v56, v56, 4, 16                                  // 0000009477B4: D6100038 02410938
	.long 0xd72c0040                                           // 0000009477BC: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 0000009477C0: 020280FF 83DCD12D
	v_dot2acc_f32_f16 v41, v54, v19                            // 0000009477C8: 04522736
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009477CC: BF870004
	.long 0xd72c003e                                           // 0000009477D0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000009477D4: 02027CFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 0000009477DC: BF89FC07
	v_bfe_u32 v65, v59, 12, 16                                 // 0000009477E0: D6100041 0241193B
	v_bfe_u32 v54, v59, 8, 16                                  // 0000009477E8: D6100036 0241113B
	.long 0xd72c0038                                           // 0000009477F0: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009477F4: 020270FF 83DCD12D
	v_bfe_u32 v66, v59, 4, 16                                  // 0000009477FC: D6100042 0241093B
	v_and_b32_e32 v59, 0xffff, v59                             // 000000947804: 367676FF 0000FFFF
	.long 0xd72c0041                                           // 00000094780C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000947810: 020282FF 83DCD12D
	.long 0xd72c0036                                           // 000000947818: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 00000094781C: 02026CFF 83DCD12D
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000947824: D622003E 03FD013E 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000947830: D6220040 03FD0140 00006400
	v_dot2acc_f32_f16 v41, v57, v20                            // 00000094783C: 04522939
	v_bfe_u32 v68, v60, 4, 16                                  // 000000947840: D6100044 0241093C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000947848: BF870004
	v_lshl_or_b32 v62, v62, 16, v63                            // 00000094784C: D656003E 04FD213E
	v_sad_u8 v63, v56, 0, 0x6400                               // 000000947854: D622003F 03FD0138 00006400
	v_mov_b32_e32 v56, v58                                     // 000000947860: 7E70033A
	.long 0xd72c003a                                           // 000000947864: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000947868: 020276FF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000947870: D6220041 03FD0141 00006400
	v_sad_u8 v59, v54, 0, 0x6400                               // 00000094787C: D622003B 03FD0136 00006400
	v_lshlrev_b32_e32 v64, 16, v64                             // 000000947888: 30808090
	.long 0xd73d0036                                           // 00000094788C: D73D0036
	v_cndmask_b32_e32 v1, v45, v55, vcc_lo                     // 000000947890: 02026F2D
	v_pk_fma_f16 v56, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947894: CC0E0038 0BFC0B3E 0000C931
	v_and_b32_e32 v65, 0xffff, v65                             // 0000009478A0: 368282FF 0000FFFF
	.long 0xd72c0044                                           // 0000009478A8: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 0000009478AC: 020288FF 83DCD12D
	v_sad_u8 v57, v58, 0, 0x6400                               // 0000009478B4: D6220039 03FD013A 00006400
	v_and_or_b32 v63, 0xffff, v63, v64                         // 0000009478C0: D657003F 05027EFF 0000FFFF
	v_bfe_u32 v58, v54, 12, 16                                 // 0000009478CC: D610003A 02411936
	v_dot2acc_f32_f16 v40, v56, v18                            // 0000009478D4: 04502538
	v_lshl_or_b32 v55, v59, 16, v65                            // 0000009478D8: D6560037 0505213B
	v_lshlrev_b32_e32 v65, 16, v57                             // 0000009478E0: 30827290
	v_pk_fma_f16 v62, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009478E4: CC0E003E 0BFC0B3F 0000C931
	.long 0xd72c0039                                           // 0000009478F0: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009478F4: 020274FF 83DCD12D
	v_bfe_u32 v58, v54, 8, 16                                  // 0000009478FC: D610003A 02411136
	v_pk_fma_f16 v63, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947904: CC0E003F 0BFC0B37 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000947910: BF870224
	v_dual_dot2acc_f32_f16 v40, v62, v19 :: v_dual_and_b32 v55, 0xffff, v54// 000000947914: CB24273E 28366CFF 0000FFFF
	v_bfe_u32 v54, v54, 4, 16                                  // 000000947920: D6100036 02410936
	.long 0xd72c003a                                           // 000000947928: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 00000094792C: 020274FF 83DCD12D
	.long 0xd72c0040                                           // 000000947934: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000947938: 020284FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000947940: BF870004
	.long 0xd72c0043                                           // 000000947944: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000947948: 02026EFF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000947950: D6220039 03FD0139 00006400
	.long 0xd72c0045                                           // 00000094795C: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000947960: 02026CFF 83DCD12D
	ds_load_2addr_b32 v[54:55], v51 offset0:192 offset1:224    // 000000947968: D8DCE0C0 36000033
	v_bfe_u32 v59, v60, 12, 16                                 // 000000947970: D610003B 0241193C
	v_bfe_u32 v66, v60, 8, 16                                  // 000000947978: D6100042 0241113C
	v_and_b32_e32 v70, 0xffff, v57                             // 000000947980: 368C72FF 0000FFFF
	v_sad_u8 v71, v58, 0, 0x6400                               // 000000947988: D6220047 03FD013A 00006400
	ds_load_2addr_b32 v[57:58], v50 offset0:192 offset1:224    // 000000947994: D8DCE0C0 39000032
	v_sad_u8 v67, v67, 0, 0x6400                               // 00000094799C: D6220043 03FD0143 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 0000009479A8: D6220045 03FD0145 00006400
	v_and_b32_e32 v60, 0xffff, v60                             // 0000009479B4: 367878FF 0000FFFF
	v_lshl_or_b32 v56, v71, 16, v70                            // 0000009479BC: D6560038 05192147
	.long 0xd72c003b                                           // 0000009479C4: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009479C8: 020276FF 83DCD12D
	v_dual_dot2acc_f32_f16 v40, v63, v20 :: v_dual_lshlrev_b32 v67, 16, v67// 0000009479D0: CB22293F 28428690
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000009479D8: D6220040 03FD0140 00006400
	.long 0xd72c0042                                           // 0000009479E4: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 0000009479E8: 020284FF 83DCD12D
	.long 0xd72c003c                                           // 0000009479F0: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000009479F4: 020278FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009479FC: BF870004
	v_and_or_b32 v67, 0xffff, v69, v67                         // 000000947A00: D6570043 050E8AFF 0000FFFF
	v_pk_fma_f16 v69, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947A0C: CC0E0045 0BFC0B38 0000C931
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000947A18: D622003B 03FD013B 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000947A24: BF89FC17
	v_dual_dot2acc_f32_f16 v41, v61, v21 :: v_dual_mov_b32 v56, v54// 000000947A28: CB102B3D 29380136
	v_pk_fma_f16 v67, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947A30: CC0E0043 0BFC0B43 0000C931
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000947A3C: D6220042 03FD0142 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000947A48: D622003C 03FD013C 00006400
	v_dot2acc_f32_f16 v39, v69, v18                            // 000000947A54: 044E2545
	s_waitcnt lgkmcnt(0)                                       // 000000947A58: BF89FC07
	.long 0xd73d0038                                           // 000000947A5C: D73D0038
	v_cndmask_b32_e32 v1, v45, v56, vcc_lo                     // 000000947A60: 0202712D
	v_and_or_b32 v57, 0xffff, v64, v65                         // 000000947A64: D6570039 050680FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000947A70: BF870113
	v_dot2acc_f32_f16 v39, v67, v19                            // 000000947A74: 044E2743
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947A78: CC0E0039 0BFC0B39 0000C931
	v_and_b32_e32 v59, 0xffff, v59                             // 000000947A84: 367676FF 0000FFFF
	v_bfe_u32 v64, v56, 12, 16                                 // 000000947A8C: D6100040 02411938
	v_bfe_u32 v63, v56, 8, 16                                  // 000000947A94: D610003F 02411138
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000947A9C: BF870214
	v_dot2acc_f32_f16 v40, v57, v21                            // 000000947AA0: 04502B39
	v_lshl_or_b32 v54, v66, 16, v59                            // 000000947AA4: D6560036 04ED2142
	v_sad_u8 v66, v68, 0, 0x6400                               // 000000947AAC: D6220042 03FD0144 00006400
	v_lshlrev_b32_e32 v68, 16, v60                             // 000000947AB8: 30887890
	ds_load_2addr_b32 v[59:60], v48 offset0:192 offset1:224    // 000000947ABC: D8DCE0C0 3B000030
	v_bfe_u32 v57, v56, 4, 16                                  // 000000947AC4: D6100039 02410938
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947ACC: CC0E0036 0BFC0B36 0000C931
	v_and_b32_e32 v56, 0xffff, v56                             // 000000947AD8: 367070FF 0000FFFF
	v_and_or_b32 v62, 0xffff, v66, v68                         // 000000947AE0: D657003E 051284FF 0000FFFF
	.long 0xd72c003d                                           // 000000947AEC: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000947AF0: 02027EFF 83DCD12D
	.long 0xd72c0039                                           // 000000947AF8: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000947AFC: 020272FF 83DCD12D
	v_dot2acc_f32_f16 v39, v54, v20                            // 000000947B04: 044E2936
	.long 0xd72c0036                                           // 000000947B08: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000947B0C: 020280FF 83DCD12D
	v_pk_fma_f16 v62, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947B14: CC0E003E 0BFC0B3E 0000C931
	.long 0xd72c0038                                           // 000000947B20: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000947B24: 020270FF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000947B2C: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000947B38: BF870003
	v_dot2acc_f32_f16 v39, v62, v21                            // 000000947B3C: 044E2B3E
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000947B40: D6220039 03FD0139 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000947B4C: D6220036 03FD0136 00006400
	v_sad_u8 v65, v56, 0, 0x6400                               // 000000947B58: D6220041 03FD0138 00006400
	v_mov_b32_e32 v56, v58                                     // 000000947B64: 7E70033A
	s_waitcnt lgkmcnt(0)                                       // 000000947B68: BF89FC07
	v_bfe_u32 v62, v59, 12, 16                                 // 000000947B6C: D610003E 0241193B
	v_and_b32_e32 v64, 0xffff, v59                             // 000000947B74: 368076FF 0000FFFF
	v_bfe_u32 v63, v59, 8, 16                                  // 000000947B7C: D610003F 0241113B
	v_bfe_u32 v59, v59, 4, 16                                  // 000000947B84: D610003B 0241093B
	v_and_b32_e32 v54, 0xffff, v54                             // 000000947B8C: 366C6CFF 0000FFFF
	.long 0xd72c003e                                           // 000000947B94: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000947B98: 02027CFF 83DCD12D
	.long 0xd72c0040                                           // 000000947BA0: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000947BA4: 020280FF 83DCD12D
	.long 0xd72c003f                                           // 000000947BAC: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000947BB0: 02027EFF 83DCD12D
	.long 0xd72c003a                                           // 000000947BB8: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000947BBC: 020276FF 83DCD12D
	v_lshl_or_b32 v61, v61, 16, v54                            // 000000947BC4: D656003D 04D9213D
	.long 0xd73d0036                                           // 000000947BCC: D73D0036
	v_cndmask_b32_e32 v1, v45, v55, vcc_lo                     // 000000947BD0: 02026F2D
	v_lshlrev_b32_e32 v55, 16, v65                             // 000000947BD4: 306E8290
	v_bfe_u32 v66, v60, 8, 16                                  // 000000947BD8: D6100042 0241113C
	v_sad_u8 v59, v62, 0, 0x6400                               // 000000947BE0: D622003B 03FD013E 00006400
	v_sad_u8 v62, v64, 0, 0x6400                               // 000000947BEC: D622003E 03FD0140 00006400
	v_pk_fma_f16 v61, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947BF8: CC0E003D 0BFC0B3D 0000C931
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000947C04: D622003A 03FD013A 00006400
	v_and_or_b32 v55, 0xffff, v57, v55                         // 000000947C10: D6570037 04DE72FF 0000FFFF
	v_and_b32_e32 v56, 0xffff, v59                             // 000000947C1C: 367076FF 0000FFFF
	v_sad_u8 v59, v63, 0, 0x6400                               // 000000947C24: D622003B 03FD013F 00006400
	v_lshlrev_b32_e32 v62, 16, v62                             // 000000947C30: 307C7C90
	v_bfe_u32 v63, v54, 12, 16                                 // 000000947C34: D610003F 02411936
	v_and_b32_e32 v68, 0xffff, v60                             // 000000947C3C: 368878FF 0000FFFF
	.long 0xd72c0042                                           // 000000947C44: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000947C48: 020284FF 83DCD12D
	v_lshl_or_b32 v56, v59, 16, v56                            // 000000947C50: D6560038 04E1213B
	v_and_or_b32 v57, 0xffff, v58, v62                         // 000000947C58: D6570039 04FA74FF 0000FFFF
	.long 0xd72c003a                                           // 000000947C64: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000947C68: 02027EFF 83DCD12D
	v_pk_fma_f16 v62, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947C70: CC0E003E 0BFC0B37 0000C931
	v_and_b32_e32 v55, 0xffff, v54                             // 000000947C7C: 366E6CFF 0000FFFF
	v_bfe_u32 v59, v54, 8, 16                                  // 000000947C84: D610003B 02411136
	v_pk_fma_f16 v64, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947C8C: CC0E0040 0BFC0B39 0000C931
	v_pk_fma_f16 v63, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947C98: CC0E003F 0BFC0B38 0000C931
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000947CA4: D6220042 03FD0142 00006400
	v_sad_u8 v57, v58, 0, 0x6400                               // 000000947CB0: D6220039 03FD013A 00006400
	v_dot2acc_f32_f16 v38, v61, v18                            // 000000947CBC: 044C253D
	v_bfe_u32 v58, v54, 4, 16                                  // 000000947CC0: D610003A 02410936
	.long 0xd72c003d                                           // 000000947CC8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000947CCC: 02026EFF 83DCD12D
	ds_load_2addr_b32 v[54:55], v53 offset1:32                 // 000000947CD4: D8DC2000 36000035
	.long 0xd72c0038                                           // 000000947CDC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000947CE0: 020276FF 83DCD12D
	v_and_b32_e32 v65, 0xffff, v57                             // 000000947CE8: 368272FF 0000FFFF
	.long 0xd72c0043                                           // 000000947CF0: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000947CF4: 020274FF 83DCD12D
	ds_load_2addr_b32 v[57:58], v52 offset1:32                 // 000000947CFC: D8DC2000 39000034
	v_bfe_u32 v59, v60, 12, 16                                 // 000000947D04: D610003B 0241193C
	v_bfe_u32 v60, v60, 4, 16                                  // 000000947D0C: D610003C 0241093C
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000947D14: D622003D 03FD013D 00006400
	v_dot2acc_f32_f16 v38, v62, v19                            // 000000947D20: 044C273E
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000947D24: D6220038 03FD0138 00006400
	.long 0xd72c003b                                           // 000000947D30: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000947D34: 020276FF 83DCD12D
	.long 0xd72c0045                                           // 000000947D3C: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000947D40: 020278FF 83DCD12D
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000947D48: D6220043 03FD0143 00006400
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000947D54: 307A7A90
	v_lshl_or_b32 v56, v56, 16, v65                            // 000000947D58: D6560038 05052138
	.long 0xd72c0041                                           // 000000947D60: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000947D64: 020288FF 83DCD12D
	v_dot2acc_f32_f16 v38, v63, v20                            // 000000947D6C: 044C293F
	v_sad_u8 v70, v59, 0, 0x6400                               // 000000947D70: D6220046 03FD013B 00006400
	ds_load_2addr_b32 v[59:60], v49 offset1:32                 // 000000947D7C: D8DC2000 3B000031
	v_pk_fma_f16 v68, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947D84: CC0E0044 0BFC0B38 0000C931
	s_waitcnt lgkmcnt(2)                                       // 000000947D90: BF89FC27
	v_mov_b32_e32 v56, v54                                     // 000000947D94: 7E700336
	v_and_or_b32 v61, 0xffff, v67, v61                         // 000000947D98: D657003D 04F686FF 0000FFFF
	v_and_b32_e32 v54, 0xffff, v70                             // 000000947DA4: 366C8CFF 0000FFFF
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000947DAC: D6220041 03FD0141 00006400
	v_dot2acc_f32_f16 v37, v68, v18                            // 000000947DB8: 044A2544
	s_waitcnt lgkmcnt(1)                                       // 000000947DBC: BF89FC17
	.long 0xd73d0038                                           // 000000947DC0: D73D0038
	v_cndmask_b32_e32 v1, v45, v56, vcc_lo                     // 000000947DC4: 0202712D
	v_pk_fma_f16 v57, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947DC8: CC0E0039 0BFC0B3D 0000C931
	v_lshl_or_b32 v54, v66, 16, v54                            // 000000947DD4: D6560036 04D92142
	v_sad_u8 v67, v69, 0, 0x6400                               // 000000947DDC: D6220043 03FD0145 00006400
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000947DE8: 30828290
	v_bfe_u32 v62, v56, 12, 16                                 // 000000947DEC: D610003E 02411938
	s_delay_alu instid0(VALU_DEP_4)                            // 000000947DF4: BF870004
	v_pk_fma_f16 v63, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947DF8: CC0E003F 0BFC0B36 0000C931
	v_dot2acc_f32_f16 v37, v57, v19                            // 000000947E04: 044A2739
	v_bfe_u32 v57, v56, 8, 16                                  // 000000947E08: D6100039 02411138
	v_and_or_b32 v61, 0xffff, v67, v65                         // 000000947E10: D657003D 050686FF 0000FFFF
	.long 0xd72c0036                                           // 000000947E1C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000947E20: 02027CFF 83DCD12D
	v_and_b32_e32 v62, 0xffff, v56                             // 000000947E28: 367C70FF 0000FFFF
	v_bfe_u32 v56, v56, 4, 16                                  // 000000947E30: D6100038 02410938
	s_waitcnt lgkmcnt(0)                                       // 000000947E38: BF89FC07
	v_bfe_u32 v65, v59, 12, 16                                 // 000000947E3C: D6100041 0241193B
	.long 0xd72c0039                                           // 000000947E44: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000947E48: 020272FF 83DCD12D
	v_bfe_u32 v66, v59, 8, 16                                  // 000000947E50: D6100042 0241113B
	.long 0xd72c003e                                           // 000000947E58: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000947E5C: 02027CFF 83DCD12D
	.long 0xd72c0038                                           // 000000947E64: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000947E68: 020270FF 83DCD12D
	.long 0xd72c0041                                           // 000000947E70: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000947E74: 020282FF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000947E7C: D6220036 03FD0136 00006400
	v_bfe_u32 v67, v59, 4, 16                                  // 000000947E88: D6100043 0241093B
	v_and_b32_e32 v59, 0xffff, v59                             // 000000947E90: 367676FF 0000FFFF
	.long 0xd72c0042                                           // 000000947E98: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000947E9C: 020284FF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000947EA4: D6220039 03FD0139 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000947EB0: D622003E 03FD013E 00006400
	v_and_b32_e32 v54, 0xffff, v54                             // 000000947EBC: 366C6CFF 0000FFFF
	v_sad_u8 v68, v56, 0, 0x6400                               // 000000947EC4: D6220044 03FD0138 00006400
	v_mov_b32_e32 v56, v58                                     // 000000947ED0: 7E70033A
	.long 0xd72c003b                                           // 000000947ED4: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000947ED8: 020276FF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000947EE0: D6220041 03FD0141 00006400
	v_lshlrev_b32_e32 v62, 16, v62                             // 000000947EEC: 307C7C90
	.long 0xd72c0043                                           // 000000947EF0: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000947EF4: 020286FF 83DCD12D
	v_lshl_or_b32 v57, v57, 16, v54                            // 000000947EFC: D6560039 04D92139
	.long 0xd73d0036                                           // 000000947F04: D73D0036
	v_cndmask_b32_e32 v1, v45, v55, vcc_lo                     // 000000947F08: 02026F2D
	v_and_b32_e32 v58, 0xffff, v65                             // 000000947F0C: 367482FF 0000FFFF
	v_sad_u8 v65, v66, 0, 0x6400                               // 000000947F14: D6220041 03FD0142 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000947F20: D622003B 03FD013B 00006400
	v_and_or_b32 v55, 0xffff, v68, v62                         // 000000947F2C: D6570037 04FA88FF 0000FFFF
	v_pk_fma_f16 v62, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947F38: CC0E003E 0BFC0B39 0000C931
	v_bfe_u32 v57, v54, 12, 16                                 // 000000947F44: D6100039 02411936
	v_lshl_or_b32 v56, v65, 16, v58                            // 000000947F4C: D6560038 04E92141
	v_sad_u8 v58, v67, 0, 0x6400                               // 000000947F54: D622003A 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000947F60: BF870004
	v_dual_dot2acc_f32_f16 v36, v62, v18 :: v_dual_lshlrev_b32 v59, 16, v59// 000000947F64: CB22253E 243A7690
	v_pk_fma_f16 v65, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947F6C: CC0E0041 0BFC0B37 0000C931
	v_and_b32_e32 v55, 0xffff, v54                             // 000000947F78: 366E6CFF 0000FFFF
	v_pk_fma_f16 v66, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000947F80: CC0E0042 0BFC0B38 0000C931
	.long 0xd72c0038                                           // 000000947F8C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000947F90: 020272FF 83DCD12D
	v_bfe_u32 v57, v54, 8, 16                                  // 000000947F98: D6100039 02411136
	v_bfe_u32 v54, v54, 4, 16                                  // 000000947FA0: D6100036 02410936
	v_and_or_b32 v67, 0xffff, v58, v59                         // 000000947FA8: D6570043 04EE74FF 0000FFFF
	v_bfe_u32 v58, v60, 12, 16                                 // 000000947FB4: D610003A 0241193C
	.long 0xd72c0037                                           // 000000947FBC: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000947FC0: 02026EFF 83DCD12D
	v_bfe_u32 v59, v60, 8, 16                                  // 000000947FC8: D610003B 0241113C
	.long 0xd72c0036                                           // 000000947FD0: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000947FD4: 02026CFF 83DCD12D
	.long 0xd72c0039                                           // 000000947FDC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000947FE0: 020272FF 83DCD12D
	v_bfe_u32 v68, v60, 4, 16                                  // 000000947FE8: D6100044 0241093C
	v_and_b32_e32 v60, 0xffff, v60                             // 000000947FF0: 367878FF 0000FFFF
	.long 0xd72c003a                                           // 000000947FF8: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000947FFC: 020274FF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000948004: D6220038 03FD0138 00006400
	v_sad_u8 v69, v55, 0, 0x6400                               // 000000948010: D6220045 03FD0137 00006400
	.long 0xd72c003b                                           // 00000094801C: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000948020: 020276FF 83DCD12D
	.long 0xd72c003c                                           // 000000948028: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 00000094802C: 020278FF 83DCD12D
	v_sad_u8 v71, v54, 0, 0x6400                               // 000000948034: D6220047 03FD0136 00006400
	ds_load_2addr_b32 v[54:55], v53 offset0:64 offset1:96      // 000000948040: D8DC6040 36000035
	v_and_b32_e32 v56, 0xffff, v56                             // 000000948048: 367070FF 0000FFFF
	v_sad_u8 v70, v57, 0, 0x6400                               // 000000948050: D6220046 03FD0139 00006400
	v_dual_dot2acc_f32_f16 v36, v65, v19 :: v_dual_lshlrev_b32 v69, 16, v69// 00000094805C: CB222741 24448A90
	v_sad_u8 v72, v58, 0, 0x6400                               // 000000948064: D6220048 03FD013A 00006400
	ds_load_2addr_b32 v[57:58], v52 offset0:64 offset1:96      // 000000948070: D8DC6040 39000034
	v_lshl_or_b32 v56, v70, 16, v56                            // 000000948078: D6560038 04E12146
	v_and_or_b32 v69, 0xffff, v71, v69                         // 000000948080: D6570045 05168EFF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000094808C: D622003B 03FD013B 00006400
	v_and_b32_e32 v70, 0xffff, v72                             // 000000948098: 368C90FF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009480A0: D622003C 03FD013C 00006400
	.long 0xd72c0044                                           // 0000009480AC: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 0000009480B0: 020288FF 83DCD12D
	v_pk_fma_f16 v62, v69, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009480B8: CC0E003E 0BFC0B45 0000C931
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009480C4: CC0E0038 0BFC0B38 0000C931
	v_lshl_or_b32 v69, v59, 16, v70                            // 0000009480D0: D6560045 0519213B
	v_lshlrev_b32_e32 v70, 16, v60                             // 0000009480D8: 308C7890
	ds_load_2addr_b32 v[59:60], v49 offset0:64 offset1:96      // 0000009480DC: D8DC6040 3B000031
	v_pk_fma_f16 v61, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009480E4: CC0E003D 0BFC0B3D 0000C931
	s_waitcnt lgkmcnt(2)                                       // 0000009480F0: BF89FC27
	v_dual_dot2acc_f32_f16 v35, v56, v18 :: v_dual_mov_b32 v56, v54// 0000009480F4: CB102538 23380136
	v_sad_u8 v68, v68, 0, 0x6400                               // 0000009480FC: D6220044 03FD0144 00006400
	v_pk_fma_f16 v54, v69, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000948108: CC0E0036 0BFC0B45 0000C931
	v_dot2acc_f32_f16 v37, v63, v20                            // 000000948114: 044A293F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000948118: BF870004
	v_dot2acc_f32_f16 v35, v62, v19                            // 00000094811C: 0446273E
	v_dot2acc_f32_f16 v36, v66, v20                            // 000000948120: 04482942
	s_waitcnt lgkmcnt(1)                                       // 000000948124: BF89FC17
	.long 0xd73d0038                                           // 000000948128: D73D0038
	v_cndmask_b32_e32 v1, v45, v56, vcc_lo                     // 00000094812C: 0202712D
	v_and_or_b32 v65, 0xffff, v68, v70                         // 000000948130: D6570041 051A88FF 0000FFFF
	v_pk_fma_f16 v57, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000094813C: CC0E0039 0BFC0B43 0000C931
	v_dual_dot2acc_f32_f16 v35, v54, v20 :: v_dual_dot2acc_f32_f16 v38, v64, v21// 000000948148: CB182936 23262B40
	v_dot2acc_f32_f16 v37, v61, v21                            // 000000948150: 044A2B3D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000948154: BF870004
	v_pk_fma_f16 v62, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000948158: CC0E003E 0BFC0B41 0000C931
	v_bfe_u32 v54, v56, 12, 16                                 // 000000948164: D6100036 02411938
	s_waitcnt lgkmcnt(0)                                       // 00000094816C: BF89FC07
	v_bfe_u32 v61, v59, 12, 16                                 // 000000948170: D610003D 0241193B
	v_bfe_u32 v63, v59, 8, 16                                  // 000000948178: D610003F 0241113B
	v_bfe_u32 v64, v59, 4, 16                                  // 000000948180: D6100040 0241093B
	v_dual_dot2acc_f32_f16 v36, v57, v21 :: v_dual_and_b32 v59, 0xffff, v59// 000000948188: CB242B39 243A76FF 0000FFFF
	v_and_b32_e32 v57, 0xffff, v56                             // 000000948194: 367270FF 0000FFFF
	v_dot2acc_f32_f16 v35, v62, v21                            // 00000094819C: 04462B3E
	.long 0xd72c0036                                           // 0000009481A0: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009481A4: 02026CFF 83DCD12D
	v_bfe_u32 v62, v56, 8, 16                                  // 0000009481AC: D610003E 02411138
	v_bfe_u32 v56, v56, 4, 16                                  // 0000009481B4: D6100038 02410938
	.long 0xd72c0039                                           // 0000009481BC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009481C0: 020272FF 83DCD12D
	.long 0xd72c003d                                           // 0000009481C8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000009481CC: 02027AFF 83DCD12D
	.long 0xd72c003f                                           // 0000009481D4: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 0000009481D8: 02027EFF 83DCD12D
	.long 0xd72c003e                                           // 0000009481E0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000009481E4: 02027CFF 83DCD12D
	.long 0xd72c0038                                           // 0000009481EC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009481F0: 020270FF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009481F8: D6220036 03FD0136 00006400
	.long 0xd72c003b                                           // 000000948204: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000948208: 020276FF 83DCD12D
	.long 0xd72c0040                                           // 000000948210: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000948214: 020280FF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 00000094821C: D6220039 03FD0139 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000948228: D622003D 03FD013D 00006400
	v_and_b32_e32 v54, 0xffff, v54                             // 000000948234: 366C6CFF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000094823C: D622003E 03FD013E 00006400
	v_sad_u8 v65, v56, 0, 0x6400                               // 000000948248: D6220041 03FD0138 00006400
	v_dual_mov_b32 v56, v58 :: v_dual_lshlrev_b32 v57, 16, v57 // 000000948254: CA22013A 38387290
	v_and_b32_e32 v61, 0xffff, v61                             // 00000094825C: 367A7AFF 0000FFFF
	v_sad_u8 v58, v63, 0, 0x6400                               // 000000948264: D622003A 03FD013F 00006400
	v_lshl_or_b32 v62, v62, 16, v54                            // 000000948270: D656003E 04D9213E
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000948278: D622003B 03FD013B 00006400
	.long 0xd73d0036                                           // 000000948284: D73D0036
	v_cndmask_b32_e32 v1, v45, v55, vcc_lo                     // 000000948288: 02026F2D
	v_and_or_b32 v57, 0xffff, v65, v57                         // 00000094828C: D6570039 04E682FF 0000FFFF
	v_lshl_or_b32 v55, v58, 16, v61                            // 000000948298: D6560037 04F5213A
	v_sad_u8 v56, v64, 0, 0x6400                               // 0000009482A0: D6220038 03FD0140 00006400
	v_lshlrev_b32_e32 v58, 16, v59                             // 0000009482AC: 30747690
	v_pk_fma_f16 v59, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009482B0: CC0E003B 0BFC0B3E 0000C931
	v_bfe_u32 v61, v54, 12, 16                                 // 0000009482BC: D610003D 02411936
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009482C4: CC0E0039 0BFC0B39 0000C931
	v_pk_fma_f16 v62, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009482D0: CC0E003E 0BFC0B37 0000C931
	v_and_or_b32 v55, 0xffff, v56, v58                         // 0000009482DC: D6570037 04EA70FF 0000FFFF
	v_dot2acc_f32_f16 v34, v59, v18                            // 0000009482E8: 0444253B
	v_bfe_u32 v56, v54, 8, 16                                  // 0000009482EC: D6100038 02411136
	.long 0xd72c003a                                           // 0000009482F4: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000009482F8: 02027AFF 83DCD12D
	v_and_b32_e32 v59, 0xffff, v54                             // 000000948300: 36766CFF 0000FFFF
	v_pk_fma_f16 v61, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000948308: CC0E003D 0BFC0B37 0000C931
	v_dot2acc_f32_f16 v34, v57, v19                            // 000000948314: 04442739
	v_bfe_u32 v57, v54, 4, 16                                  // 000000948318: D6100039 02410936
	ds_load_2addr_b32 v[54:55], v53 offset0:128 offset1:160    // 000000948320: D8DCA080 36000035
	.long 0xd72c0038                                           // 000000948328: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 00000094832C: 020270FF 83DCD12D
	.long 0xd72c003b                                           // 000000948334: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000948338: 020276FF 83DCD12D
	v_sad_u8 v63, v58, 0, 0x6400                               // 000000948340: D622003F 03FD013A 00006400
	.long 0xd72c0042                                           // 00000094834C: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000948350: 020272FF 83DCD12D
	ds_load_2addr_b32 v[57:58], v52 offset0:128 offset1:160    // 000000948358: D8DCA080 39000034
	v_bfe_u32 v64, v60, 12, 16                                 // 000000948360: D6100040 0241193C
	v_bfe_u32 v65, v60, 8, 16                                  // 000000948368: D6100041 0241113C
	v_and_b32_e32 v63, 0xffff, v63                             // 000000948370: 367E7EFF 0000FFFF
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000948378: D6220038 03FD0138 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000948384: D622003B 03FD013B 00006400
	.long 0xd72c0040                                           // 000000948390: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000948394: 020280FF 83DCD12D
	.long 0xd72c0041                                           // 00000094839C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 0000009483A0: 020282FF 83DCD12D
	v_bfe_u32 v67, v60, 4, 16                                  // 0000009483A8: D6100043 0241093C
	v_lshl_or_b32 v56, v56, 16, v63                            // 0000009483B0: D6560038 04FD2138
	v_sad_u8 v63, v66, 0, 0x6400                               // 0000009483B8: D622003F 03FD0142 00006400
	v_lshlrev_b32_e32 v59, 16, v59                             // 0000009483C4: 30767690
	v_and_b32_e32 v60, 0xffff, v60                             // 0000009483C8: 367878FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009483D0: BF870004
	v_pk_fma_f16 v66, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009483D4: CC0E0042 0BFC0B38 0000C931
	s_waitcnt lgkmcnt(1)                                       // 0000009483E0: BF89FC17
	v_mov_b32_e32 v56, v54                                     // 0000009483E4: 7E700336
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000009483E8: D6220040 03FD0140 00006400
	v_and_or_b32 v63, 0xffff, v63, v59                         // 0000009483F4: D657003F 04EE7EFF 0000FFFF
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000948400: D6220041 03FD0141 00006400
	.long 0xd72c003c                                           // 00000094840C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000948410: 020278FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000948418: BF89FC07
	.long 0xd73d0038                                           // 00000094841C: D73D0038
	v_cndmask_b32_e32 v1, v45, v56, vcc_lo                     // 000000948420: 0202712D
	v_and_b32_e32 v64, 0xffff, v64                             // 000000948424: 368080FF 0000FFFF
	v_pk_fma_f16 v57, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000094842C: CC0E0039 0BFC0B3F 0000C931
	v_dot2acc_f32_f16 v33, v66, v18                            // 000000948438: 04422542
	.long 0xd72c0036                                           // 00000094843C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000948440: 020286FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000948448: BF870224
	v_lshl_or_b32 v63, v65, 16, v64                            // 00000094844C: D656003F 05012141
	v_bfe_u32 v65, v56, 12, 16                                 // 000000948454: D6100041 02411938
	v_dot2acc_f32_f16 v33, v57, v19                            // 00000094845C: 04422739
	v_sad_u8 v67, v60, 0, 0x6400                               // 000000948460: D6220043 03FD013C 00006400
	ds_load_2addr_b32 v[59:60], v49 offset0:128 offset1:160    // 00000094846C: D8DCA080 3B000031
	.long 0xd72c0039                                           // 000000948474: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000948478: 020282FF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000948480: D6220036 03FD0136 00006400
	v_lshlrev_b32_e32 v64, 16, v67                             // 00000094848C: 30808690
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000948490: BF870211
	v_and_or_b32 v54, 0xffff, v54, v64                         // 000000948494: D6570036 05026CFF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009484A0: D6220039 03FD0139 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000009484AC: BF8701C1
	v_dual_dot2acc_f32_f16 v34, v62, v20 :: v_dual_and_b32 v57, 0xffff, v57// 0000009484B0: CB24293E 223872FF 0000FFFF
	v_pk_fma_f16 v62, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009484BC: CC0E003E 0BFC0B3F 0000C931
	v_bfe_u32 v63, v56, 8, 16                                  // 0000009484C8: D610003F 02411138
	s_waitcnt lgkmcnt(0)                                       // 0000009484D0: BF89FC07
	v_dual_dot2acc_f32_f16 v34, v61, v21 :: v_dual_and_b32 v65, 0xffff, v59// 0000009484D4: CB242B3D 224076FF 0000FFFF
	v_pk_fma_f16 v61, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009484E0: CC0E003D 0BFC0B36 0000C931
	v_bfe_u32 v54, v56, 4, 16                                  // 0000009484EC: D6100036 02410938
	v_and_b32_e32 v56, 0xffff, v56                             // 0000009484F4: 367070FF 0000FFFF
	v_dot2acc_f32_f16 v33, v62, v20                            // 0000009484FC: 0442293E
	.long 0xd72c003e                                           // 000000948500: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000948504: 02027EFF 83DCD12D
	v_bfe_u32 v63, v59, 12, 16                                 // 00000094850C: D610003F 0241193B
	.long 0xd72c0036                                           // 000000948514: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000948518: 02026CFF 83DCD12D
	.long 0xd72c0038                                           // 000000948520: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000948524: 020270FF 83DCD12D
	.long 0xd72c0041                                           // 00000094852C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000948530: 020282FF 83DCD12D
	v_bfe_u32 v64, v59, 8, 16                                  // 000000948538: D6100040 0241113B
	.long 0xd72c003f                                           // 000000948540: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000948544: 02027EFF 83DCD12D
	v_bfe_u32 v59, v59, 4, 16                                  // 00000094854C: D610003B 0241093B
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000948554: D622003E 03FD013E 00006400
	v_dot2acc_f32_f16 v33, v61, v21                            // 000000948560: 04422B3D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000948564: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000948570: BF870214
	.long 0xd72c003b                                           // 000000948574: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000948578: 020276FF 83DCD12D
	v_lshl_or_b32 v57, v62, 16, v57                            // 000000948580: D6560039 04E5213E
	.long 0xd72c003e                                           // 000000948588: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 00000094858C: 020280FF 83DCD12D
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000948594: D622003F 03FD013F 00006400
	v_sad_u8 v64, v54, 0, 0x6400                               // 0000009485A0: D6220040 03FD0136 00006400
	v_lshlrev_b32_e32 v66, 16, v56                             // 0000009485AC: 30847090
	v_sad_u8 v54, v65, 0, 0x6400                               // 0000009485B0: D6220036 03FD0141 00006400
	v_mov_b32_e32 v56, v58                                     // 0000009485BC: 7E70033A
	v_and_b32_e32 v58, 0xffff, v63                             // 0000009485C0: 36747EFF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009485C8: D622003B 03FD013B 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009485D4: D622003E 03FD013E 00006400
	v_lshlrev_b32_e32 v63, 16, v54                             // 0000009485E0: 307E6C90
	.long 0xd73d0036                                           // 0000009485E4: D73D0036
	v_cndmask_b32_e32 v1, v45, v55, vcc_lo                     // 0000009485E8: 02026F2D
	v_pk_fma_f16 v56, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009485EC: CC0E0038 0BFC0B39 0000C931
	v_and_or_b32 v55, 0xffff, v64, v66                         // 0000009485F8: D6570037 050A80FF 0000FFFF
	v_lshl_or_b32 v57, v62, 16, v58                            // 000000948604: D6560039 04E9213E
	v_and_or_b32 v58, 0xffff, v59, v63                         // 00000094860C: D657003A 04FE76FF 0000FFFF
	v_bfe_u32 v63, v60, 8, 16                                  // 000000948618: D610003F 0241113C
	v_bfe_u32 v59, v54, 12, 16                                 // 000000948620: D610003B 02411936
	v_dot2acc_f32_f16 v32, v56, v18                            // 000000948628: 04402538
	v_pk_fma_f16 v61, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000094862C: CC0E003D 0BFC0B39 0000C931
	v_bfe_u32 v57, v54, 8, 16                                  // 000000948638: D6100039 02411136
	v_pk_fma_f16 v62, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000948640: CC0E003E 0BFC0B3A 0000C931
	.long 0xd72c0038                                           // 00000094864C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000948650: 020276FF 83DCD12D
	v_bfe_u32 v58, v54, 4, 16                                  // 000000948658: D610003A 02410936
	v_and_b32_e32 v54, 0xffff, v54                             // 000000948660: 366C6CFF 0000FFFF
	v_bfe_u32 v59, v60, 12, 16                                 // 000000948668: D610003B 0241193C
	.long 0xd72c0039                                           // 000000948670: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000948674: 020272FF 83DCD12D
	v_bfe_u32 v64, v60, 4, 16                                  // 00000094867C: D6100040 0241093C
	v_and_b32_e32 v60, 0xffff, v60                             // 000000948684: 367878FF 0000FFFF
	.long 0xd72c0041                                           // 00000094868C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000948690: 02026CFF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000948698: D6220038 03FD0138 00006400
	.long 0xd72c003b                                           // 0000009486A4: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009486A8: 020276FF 83DCD12D
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009486B0: CC0E0037 0BFC0B37 0000C931
	.long 0xd72c003c                                           // 0000009486BC: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000009486C0: 020278FF 83DCD12D
	v_sad_u8 v66, v57, 0, 0x6400                               // 0000009486C8: D6220042 03FD0139 00006400
	v_and_b32_e32 v56, 0xffff, v56                             // 0000009486D4: 367070FF 0000FFFF
	.long 0xd72c0043                                           // 0000009486DC: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009486E0: 020274FF 83DCD12D
	ds_load_2addr_b32 v[57:58], v52 offset0:192 offset1:224    // 0000009486E8: D8DCE0C0 39000034
	.long 0xd72c003f                                           // 0000009486F0: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 0000009486F4: 02027EFF 83DCD12D
	.long 0xd72c0040                                           // 0000009486FC: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000948700: 020280FF 83DCD12D
	v_lshl_or_b32 v66, v66, 16, v56                            // 000000948708: D6560042 04E12142
	v_sad_u8 v56, v65, 0, 0x6400                               // 000000948710: D6220038 03FD0141 00006400
	v_sad_u8 v65, v59, 0, 0x6400                               // 00000094871C: D6220041 03FD013B 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000948728: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000948734: BF870214
	v_pk_fma_f16 v66, v66, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000948738: CC0E0042 0BFC0B42 0000C931
	v_lshlrev_b32_e32 v68, 16, v56                             // 000000948744: 30887090
	v_sad_u8 v56, v60, 0, 0x6400                               // 000000948748: D6220038 03FD013C 00006400
	v_dual_dot2acc_f32_f16 v32, v55, v19 :: v_dual_and_b32 v65, 0xffff, v65// 000000948754: CB242737 204082FF 0000FFFF
	ds_load_2addr_b32 v[54:55], v53 offset0:192 offset1:224    // 000000948760: D8DCE0C0 36000035
	ds_load_2addr_b32 v[59:60], v49 offset0:192 offset1:224    // 000000948768: D8DCE0C0 3B000031
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000948770: D622003F 03FD013F 00006400
	v_lshlrev_b32_e32 v69, 16, v56                             // 00000094877C: 308A7090
	v_dot2acc_f32_f16 v31, v66, v18                            // 000000948780: 043E2542
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000948784: D6220040 03FD0140 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000948790: BF870114
	v_lshl_or_b32 v63, v63, 16, v65                            // 000000948794: D656003F 0505213F
	v_and_or_b32 v64, 0xffff, v64, v69                         // 00000094879C: D6570040 051680FF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 0000009487A8: BF89FC17
	v_mov_b32_e32 v56, v54                                     // 0000009487AC: 7E700336
	v_and_or_b32 v54, 0xffff, v67, v68                         // 0000009487B0: D6570036 051286FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 0000009487BC: BF89FC07
	v_bfe_u32 v65, v59, 12, 16                                 // 0000009487C0: D6100041 0241193B
	v_bfe_u32 v66, v59, 8, 16                                  // 0000009487C8: D6100042 0241113B
	v_bfe_u32 v67, v59, 4, 16                                  // 0000009487D0: D6100043 0241093B
	v_and_b32_e32 v59, 0xffff, v59                             // 0000009487D8: 367676FF 0000FFFF
	.long 0xd73d0038                                           // 0000009487E0: D73D0038
	v_cndmask_b32_e32 v1, v45, v56, vcc_lo                     // 0000009487E4: 0202712D
	v_pk_fma_f16 v57, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009487E8: CC0E0039 0BFC0B3F 0000C931
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009487F4: CC0E0036 0BFC0B36 0000C931
	.long 0xd72c0041                                           // 000000948800: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000948804: 020282FF 83DCD12D
	.long 0xd72c0042                                           // 00000094880C: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000948810: 020284FF 83DCD12D
	v_bfe_u32 v63, v56, 12, 16                                 // 000000948818: D610003F 02411938
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000948820: BF870114
	v_dual_dot2acc_f32_f16 v31, v54, v19 :: v_dual_and_b32 v54, 0xffff, v56// 000000948824: CB242736 1F3670FF 0000FFFF
	.long 0xd72c003f                                           // 000000948830: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000948834: 02027EFF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 00000094883C: D6220041 03FD0141 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000948848: BF870213
	.long 0xd72c0036                                           // 00000094884C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000948850: 02026CFF 83DCD12D
	v_dot2acc_f32_f16 v31, v57, v20                            // 000000948858: 043E2939
	s_delay_alu instid0(VALU_DEP_3)                            // 00000094885C: BF870003
	v_and_b32_e32 v65, 0xffff, v65                             // 000000948860: 368282FF 0000FFFF
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000948868: D622003F 03FD013F 00006400
	v_dot2acc_f32_f16 v32, v61, v20                            // 000000948874: 0440293D
	v_pk_fma_f16 v61, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000948878: CC0E003D 0BFC0B40 0000C931
	v_bfe_u32 v64, v56, 8, 16                                  // 000000948884: D6100040 02411138
	v_bfe_u32 v56, v56, 4, 16                                  // 00000094888C: D6100038 02410938
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000948894: D6220036 03FD0136 00006400
	v_and_b32_e32 v63, 0xffff, v63                             // 0000009488A0: 367E7EFF 0000FFFF
	v_dual_dot2acc_f32_f16 v32, v62, v21 :: v_dual_add_nc_u32 v47, 1, v47// 0000009488A8: CB202B3E 202E5E81
	.long 0xd72c0040                                           // 0000009488B0: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 0000009488B4: 020280FF 83DCD12D
	.long 0xd72c0038                                           // 0000009488BC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009488C0: 020270FF 83DCD12D
	v_dual_dot2acc_f32_f16 v31, v61, v21 :: v_dual_lshlrev_b32 v54, 16, v54// 0000009488C8: CB222B3D 1F366C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009488D0: BF870193
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000009488D4: D6220040 03FD0140 00006400
	v_sad_u8 v68, v56, 0, 0x6400                               // 0000009488E0: D6220044 03FD0138 00006400
	v_mov_b32_e32 v56, v58                                     // 0000009488EC: 7E70033A
	v_sad_u8 v58, v66, 0, 0x6400                               // 0000009488F0: D622003A 03FD0142 00006400
	.long 0xd72c0042                                           // 0000009488FC: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000948900: 020286FF 83DCD12D
	v_lshl_or_b32 v63, v64, 16, v63                            // 000000948908: D656003F 04FD2140
	v_and_or_b32 v64, 0xffff, v68, v54                         // 000000948910: D6570040 04DA88FF 0000FFFF
	.long 0xd73d0036                                           // 00000094891C: D73D0036
	v_cndmask_b32_e32 v1, v45, v55, vcc_lo                     // 000000948920: 02026F2D
	.long 0xd72c0038                                           // 000000948924: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000948928: 020276FF 83DCD12D
	v_lshl_or_b32 v55, v58, 16, v65                            // 000000948930: D6560037 0505213A
	v_pk_fma_f16 v57, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000948938: CC0E0039 0BFC0B3F 0000C931
	v_pk_fma_f16 v58, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000948944: CC0E003A 0BFC0B40 0000C931
	v_sad_u8 v63, v66, 0, 0x6400                               // 000000948950: D622003F 03FD0142 00006400
	v_bfe_u32 v59, v54, 12, 16                                 // 00000094895C: D610003B 02411936
	v_and_b32_e32 v64, 0xffff, v54                             // 000000948964: 36806CFF 0000FFFF
	v_bfe_u32 v65, v54, 8, 16                                  // 00000094896C: D6100041 02411136
	v_bfe_u32 v54, v54, 4, 16                                  // 000000948974: D6100036 02410936
	v_bfe_u32 v66, v60, 12, 16                                 // 00000094897C: D6100042 0241193C
	.long 0xd72c003b                                           // 000000948984: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000948988: 020276FF 83DCD12D
	.long 0xd72c0040                                           // 000000948990: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000948994: 020280FF 83DCD12D
	.long 0xd72c0041                                           // 00000094899C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 0000009489A0: 020282FF 83DCD12D
	.long 0xd72c0036                                           // 0000009489A8: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009489AC: 02026CFF 83DCD12D
	v_bfe_u32 v67, v60, 8, 16                                  // 0000009489B4: D6100043 0241113C
	.long 0xd72c0042                                           // 0000009489BC: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 0000009489C0: 020284FF 83DCD12D
	v_bfe_u32 v68, v60, 4, 16                                  // 0000009489C8: D6100044 0241093C
	v_and_b32_e32 v60, 0xffff, v60                             // 0000009489D0: 367878FF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009489D8: D622003B 03FD013B 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000009489E4: D6220040 03FD0140 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009489F0: D6220041 03FD0141 00006400
	.long 0xd72c0043                                           // 0000009489FC: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000948A00: 020286FF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000948A08: D6220036 03FD0136 00006400
	v_dual_dot2acc_f32_f16 v30, v57, v18 :: v_dual_and_b32 v59, 0xffff, v59// 000000948A14: CB242539 1E3A76FF 0000FFFF
	v_lshlrev_b32_e32 v64, 16, v64                             // 000000948A20: 30808090
	.long 0xd72c003c                                           // 000000948A24: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000948A28: 020278FF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000948A30: D6220042 03FD0142 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000948A3C: BF870004
	v_lshl_or_b32 v59, v65, 16, v59                            // 000000948A40: D656003B 04ED2141
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000948A48: D6220038 03FD0138 00006400
	v_and_or_b32 v54, 0xffff, v54, v64                         // 000000948A54: D6570036 05026CFF 0000FFFF
	.long 0xd72c0040                                           // 000000948A60: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000948A64: 020288FF 83DCD12D
	v_dual_dot2acc_f32_f16 v30, v58, v19 :: v_dual_and_b32 v65, 0xffff, v66// 000000948A6C: CB24273A 1E4084FF 0000FFFF
	v_sad_u8 v66, v67, 0, 0x6400                               // 000000948A78: D6220042 03FD0143 00006400
	v_pk_fma_f16 v59, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000948A84: CC0E003B 0BFC0B3B 0000C931
	v_sad_u8 v57, v60, 0, 0x6400                               // 000000948A90: D6220039 03FD013C 00006400
	v_lshlrev_b32_e32 v56, 16, v56                             // 000000948A9C: 30707090
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000948AA0: CC0E0036 0BFC0B36 0000C931
	v_lshl_or_b32 v60, v66, 16, v65                            // 000000948AAC: D656003C 05052142
	v_dot2acc_f32_f16 v1, v59, v18                             // 000000948AB4: 0402253B
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000948AB8: CC0E0037 0BFC0B37 0000C931
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000948AC4: D6220040 03FD0140 00006400
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000948AD0: 30727290
	v_and_or_b32 v18, 0xffff, v63, v56                         // 000000948AD4: D6570012 04E27EFF 0000FFFF
	v_pk_fma_f16 v56, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000948AE0: CC0E0038 0BFC0B3C 0000C931
	v_dual_dot2acc_f32_f16 v1, v54, v19 :: v_dual_dot2acc_f32_f16 v30, v55, v20// 000000948AEC: CB182736 011E2937
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000948AF4: BF870214
	v_and_or_b32 v57, 0xffff, v64, v57                         // 000000948AF8: D6570039 04E680FF 0000FFFF
	v_pk_fma_f16 v18, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000948B04: CC0E0012 0BFC0B12 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000948B10: BF870193
	v_dual_dot2acc_f32_f16 v1, v56, v20 :: v_dual_add_nc_u32 v20, v46, v47// 000000948B14: CB202938 01145F2E
	v_pk_fma_f16 v19, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000948B1C: CC0E0013 0BFC0B39 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000948B28: BF870193
	v_dot2acc_f32_f16 v30, v18, v21                            // 000000948B2C: 043C2B12
	v_cmp_eq_u32_e32 vcc_lo, 21, v20                           // 000000948B30: 7C942895
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000948B34: BF8704A3
	v_dot2acc_f32_f16 v1, v19, v21                             // 000000948B38: 04022B13
	s_or_b32 s4, vcc_lo, s4                                    // 000000948B3C: 8C04046A
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000948B40: 917E047E
	s_cbranch_execz 62                                         // 000000948B44: BFA5003E <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x2040>
	s_mov_b32 s1, exec_lo                                      // 000000948B48: BE81007E
	s_waitcnt vmcnt(14)                                        // 000000948B4C: BF893BF7
	ds_store_2addr_b32 v48, v2, v3 offset1:32                  // 000000948B50: D8382000 00030230
	s_waitcnt vmcnt(12)                                        // 000000948B58: BF8933F7
	ds_store_2addr_b32 v48, v4, v5 offset0:64 offset1:96       // 000000948B5C: D8386040 00050430
	s_waitcnt vmcnt(10)                                        // 000000948B64: BF892BF7
	ds_store_2addr_b32 v48, v6, v7 offset0:128 offset1:160     // 000000948B68: D838A080 00070630
	s_waitcnt vmcnt(8)                                         // 000000948B70: BF8923F7
	ds_store_2addr_b32 v48, v8, v9 offset0:192 offset1:224     // 000000948B74: D838E0C0 00090830
	s_waitcnt vmcnt(6)                                         // 000000948B7C: BF891BF7
	ds_store_2addr_b32 v49, v10, v11 offset1:32                // 000000948B80: D8382000 000B0A31
	s_waitcnt vmcnt(4)                                         // 000000948B88: BF8913F7
	ds_store_2addr_b32 v49, v12, v13 offset0:64 offset1:96     // 000000948B8C: D8386040 000D0C31
	s_waitcnt vmcnt(2)                                         // 000000948B94: BF890BF7
	ds_store_2addr_b32 v49, v14, v15 offset0:128 offset1:160   // 000000948B98: D838A080 000F0E31
	s_waitcnt vmcnt(0)                                         // 000000948BA0: BF8903F7
	ds_store_2addr_b32 v49, v16, v17 offset0:192 offset1:224   // 000000948BA4: D838E0C0 00111031
	.long 0xd4c1007e                                           // 000000948BAC: D4C1007E
	v_cndmask_b32_e32 v1, v47, v29, vcc_lo                     // 000000948BB0: 02023B2F
	s_cbranch_execz 63800                                      // 000000948BB4: BFA5F938 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x498>
	s_clause 0xf                                               // 000000948BB8: BF85000F
	global_load_b32 v2, v[23:24], off                          // 000000948BBC: DC520000 027C0017
	global_load_b32 v3, v[23:24], off offset:128               // 000000948BC4: DC520080 037C0017
	global_load_b32 v4, v[23:24], off offset:256               // 000000948BCC: DC520100 047C0017
	global_load_b32 v5, v[23:24], off offset:384               // 000000948BD4: DC520180 057C0017
	global_load_b32 v6, v[23:24], off offset:512               // 000000948BDC: DC520200 067C0017
	global_load_b32 v7, v[23:24], off offset:640               // 000000948BE4: DC520280 077C0017
	global_load_b32 v8, v[23:24], off offset:768               // 000000948BEC: DC520300 087C0017
	global_load_b32 v9, v[23:24], off offset:896               // 000000948BF4: DC520380 097C0017
	global_load_b32 v10, v[23:24], off offset:1024             // 000000948BFC: DC520400 0A7C0017
	global_load_b32 v11, v[23:24], off offset:1152             // 000000948C04: DC520480 0B7C0017
	global_load_b32 v12, v[23:24], off offset:1280             // 000000948C0C: DC520500 0C7C0017
	global_load_b32 v13, v[23:24], off offset:1408             // 000000948C14: DC520580 0D7C0017
	global_load_b32 v14, v[23:24], off offset:1536             // 000000948C1C: DC520600 0E7C0017
	global_load_b32 v15, v[23:24], off offset:1664             // 000000948C24: DC520680 0F7C0017
	global_load_b32 v16, v[23:24], off offset:1792             // 000000948C2C: DC520700 107C0017
	global_load_b32 v17, v[23:24], off offset:1920             // 000000948C34: DC520780 117C0017
	s_branch 63766                                             // 000000948C3C: BFA0F916 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x498>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000948C40: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000948C44: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 000000948C48: 8C7E037E
	s_waitcnt vmcnt(10)                                        // 000000948C4C: BF892BF7
	v_dual_mov_b32 v2, v28 :: v_dual_mov_b32 v7, v42           // 000000948C50: CA10011C 0206012A
	v_dual_mov_b32 v4, v43 :: v_dual_mov_b32 v5, v40           // 000000948C58: CA10012B 04040128
	s_waitcnt vmcnt(8)                                         // 000000948C60: BF8923F7
	v_dual_mov_b32 v8, v41 :: v_dual_mov_b32 v9, v38           // 000000948C64: CA100129 08080126
	s_waitcnt vmcnt(6)                                         // 000000948C6C: BF891BF7
	v_dual_mov_b32 v6, v39 :: v_dual_mov_b32 v11, v37          // 000000948C70: CA100127 060A0125
	s_waitcnt vmcnt(4)                                         // 000000948C78: BF8913F7
	v_dual_mov_b32 v13, v36 :: v_dual_mov_b32 v10, v33         // 000000948C7C: CA100124 0D0A0121
	s_waitcnt vmcnt(2)                                         // 000000948C84: BF890BF7
	v_dual_mov_b32 v15, v35 :: v_dual_mov_b32 v12, v32         // 000000948C88: CA100123 0F0C0120
	v_dual_mov_b32 v3, v34 :: v_dual_mov_b32 v14, v31          // 000000948C90: CA100122 030E011F
	s_waitcnt vmcnt(0)                                         // 000000948C98: BF8903F7
	v_dual_mov_b32 v16, v30 :: v_dual_mov_b32 v17, v1          // 000000948C9C: CA10011E 10100101
	s_mov_b32 s1, 0x76543210                                   // 000000948CA4: BE8100FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000948CAC: BF870009
	v_permlanex16_b32 v2, v2, s1, 0xfedcba98                   // 000000948CB0: D65C0002 03FC0302 FEDCBA98
	v_permlanex16_b32 v4, v4, s1, 0xfedcba98                   // 000000948CBC: D65C0004 03FC0304 FEDCBA98
	v_permlanex16_b32 v7, v7, s1, 0xfedcba98                   // 000000948CC8: D65C0007 03FC0307 FEDCBA98
	v_permlanex16_b32 v8, v8, s1, 0xfedcba98                   // 000000948CD4: D65C0008 03FC0308 FEDCBA98
	v_permlanex16_b32 v5, v5, s1, 0xfedcba98                   // 000000948CE0: D65C0005 03FC0305 FEDCBA98
	v_permlanex16_b32 v6, v6, s1, 0xfedcba98                   // 000000948CEC: D65C0006 03FC0306 FEDCBA98
	v_permlanex16_b32 v9, v9, s1, 0xfedcba98                   // 000000948CF8: D65C0009 03FC0309 FEDCBA98
	v_permlanex16_b32 v11, v11, s1, 0xfedcba98                 // 000000948D04: D65C000B 03FC030B FEDCBA98
	v_permlanex16_b32 v13, v13, s1, 0xfedcba98                 // 000000948D10: D65C000D 03FC030D FEDCBA98
	v_permlanex16_b32 v15, v15, s1, 0xfedcba98                 // 000000948D1C: D65C000F 03FC030F FEDCBA98
	v_permlanex16_b32 v3, v3, s1, 0xfedcba98                   // 000000948D28: D65C0003 03FC0303 FEDCBA98
	v_permlanex16_b32 v10, v10, s1, 0xfedcba98                 // 000000948D34: D65C000A 03FC030A FEDCBA98
	v_permlanex16_b32 v12, v12, s1, 0xfedcba98                 // 000000948D40: D65C000C 03FC030C FEDCBA98
	v_permlanex16_b32 v14, v14, s1, 0xfedcba98                 // 000000948D4C: D65C000E 03FC030E FEDCBA98
	v_permlanex16_b32 v16, v16, s1, 0xfedcba98                 // 000000948D58: D65C0010 03FC0310 FEDCBA98
	v_permlanex16_b32 v17, v17, s1, 0xfedcba98                 // 000000948D64: D65C0011 03FC0311 FEDCBA98
	.long 0xd44c0001                                           // 000000948D70: D44C0001
	v_cndmask_b32_e32 v1, 16, v26, vcc_lo                      // 000000948D74: 02023490
	s_and_saveexec_b32 s3, s1                                  // 000000948D78: BE832001
	s_cbranch_execz 72                                         // 000000948D7C: BFA50048 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x22a0>
	v_ashrrev_i32_e32 v23, 31, v22                             // 000000948D80: 342E2C9F
	v_dual_add_f32 v17, v1, v17 :: v_dual_add_f32 v18, v28, v2 // 000000948D84: C9082301 1112051C
	s_ashr_i32 s7, s6, 31                                      // 000000948D8C: 86079F06
	v_dual_add_f32 v4, v43, v4 :: v_dual_add_f32 v7, v42, v7   // 000000948D90: C908092B 04060F2A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000948D98: BF8701C3
	.long 0xd73c0001                                           // 000000948D9C: D73C0001
	v_cndmask_b32_e32 v1, 4, v22, vcc_lo                       // 000000948DA0: 02022C84
	s_lshl_b64 s[4:5], s[6:7], 7                               // 000000948DA4: 84848706
	v_dual_add_f32 v8, v41, v8 :: v_dual_add_f32 v5, v40, v5   // 000000948DA8: C9081129 08040B28
	v_dual_add_f32 v6, v39, v6 :: v_dual_add_f32 v9, v38, v9   // 000000948DB0: C9080D27 06081326
	.long 0xd7006a01                                           // 000000948DB8: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000948DBC: 02000901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000948DC0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000948DC4: D5207C02 01AA0405
	.long 0xd7000413                                           // 000000948DCC: D7000413
	v_cndmask_b32_e32 v1, s16, v27, vcc_lo                     // 000000948DD0: 02023610
	v_add_co_ci_u32_e64 v20, null, s17, 0, s4                  // 000000948DD4: D5207C14 00110011
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000948DDC: BF870243
	.long 0xd73c0001                                           // 000000948DE0: D73C0001
	v_cndmask_b32_e32 v1, 6, v1, vcc_lo                        // 000000948DE4: 02020286
	v_dual_add_f32 v11, v37, v11 :: v_dual_add_f32 v12, v32, v12// 000000948DE8: C9081725 0B0C1920
	v_dual_add_f32 v13, v36, v13 :: v_dual_add_f32 v10, v33, v10// 000000948DF0: C9081B24 0D0A1521
	v_dual_add_f32 v15, v35, v15 :: v_dual_add_f32 v16, v30, v16// 000000948DF8: C9081F23 0F10211E
	.long 0xd7006a01                                           // 000000948E00: D7006A01
	v_cndmask_b32_e32 v1, v19, v1, vcc_lo                      // 000000948E04: 02020313
	s_delay_alu instid0(VALU_DEP_1)                            // 000000948E08: BF870001
	v_add_co_ci_u32_e64 v2, null, v20, v2, vcc_lo              // 000000948E0C: D5207C02 01AA0514
	v_dual_add_f32 v3, v34, v3 :: v_dual_add_f32 v14, v31, v14 // 000000948E14: C9080722 030E1D1F
	s_clause 0xf                                               // 000000948E1C: BF85000F
	global_store_b32 v[1:2], v18, off                          // 000000948E20: DC6A0000 007C1201
	global_store_b32 v[1:2], v4, off offset:64                 // 000000948E28: DC6A0040 007C0401
	global_store_b32 v[1:2], v7, off offset:128                // 000000948E30: DC6A0080 007C0701
	global_store_b32 v[1:2], v8, off offset:192                // 000000948E38: DC6A00C0 007C0801
	global_store_b32 v[1:2], v5, off offset:256                // 000000948E40: DC6A0100 007C0501
	global_store_b32 v[1:2], v6, off offset:320                // 000000948E48: DC6A0140 007C0601
	global_store_b32 v[1:2], v9, off offset:384                // 000000948E50: DC6A0180 007C0901
	global_store_b32 v[1:2], v11, off offset:448               // 000000948E58: DC6A01C0 007C0B01
	global_store_b32 v[1:2], v13, off offset:512               // 000000948E60: DC6A0200 007C0D01
	global_store_b32 v[1:2], v15, off offset:576               // 000000948E68: DC6A0240 007C0F01
	global_store_b32 v[1:2], v3, off offset:640                // 000000948E70: DC6A0280 007C0301
	global_store_b32 v[1:2], v10, off offset:704               // 000000948E78: DC6A02C0 007C0A01
	global_store_b32 v[1:2], v12, off offset:768               // 000000948E80: DC6A0300 007C0C01
	global_store_b32 v[1:2], v14, off offset:832               // 000000948E88: DC6A0340 007C0E01
	global_store_b32 v[1:2], v16, off offset:896               // 000000948E90: DC6A0380 007C1001
	global_store_b32 v[1:2], v17, off offset:960               // 000000948E98: DC6A03C0 007C1101
	s_or_b32 exec_lo, exec_lo, s3                              // 000000948EA0: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000948EA4: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000948EA8: BE83007E
	s_waitcnt_vscnt null, 0x0                                  // 000000948EAC: BC7C0000
	buffer_gl1_inv                                             // 000000948EB0: E0B00000 00000000
	buffer_gl0_inv                                             // 000000948EB8: E0AC0000 00000000
	s_barrier                                                  // 000000948EC0: BFBD0000
	buffer_gl0_inv                                             // 000000948EC4: E0AC0000 00000000
	v_cmpx_eq_u32_e32 0, v0                                    // 000000948ECC: 7D940080
	s_cbranch_execz 29                                         // 000000948ED0: BFA5001D <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x2348>
	s_mov_b32 s5, exec_lo                                      // 000000948ED4: BE85007E
	s_mov_b32 s4, exec_lo                                      // 000000948ED8: BE84007E
	.long 0xd71f0001                                           // 000000948EDC: D71F0001
	v_cndmask_b32_e32 v0, s5, v128, vcc_lo                     // 000000948EE0: 02010005
	s_delay_alu instid0(VALU_DEP_1)                            // 000000948EE4: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000948EE8: 7D940280
	s_cbranch_execz 11                                         // 000000948EEC: BFA5000B <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x231c>
	s_ashr_i32 s7, s6, 31                                      // 000000948EF0: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000948EF4: BF870499
	s_lshl_b64 s[22:23], s[6:7], 2                             // 000000948EF8: 84968206
	s_add_u32 s22, s18, s22                                    // 000000948EFC: 80161612
	s_addc_u32 s23, s19, s23                                   // 000000948F00: 82171713
	s_bcnt1_i32_b32 s5, s5                                     // 000000948F04: BE851805
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000948F08: BF870009
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s5              // 000000948F0C: CA100080 02020005
	global_atomic_add_u32 v2, v2, v3, s[22:23] glc             // 000000948F14: DCD64000 02160302
	s_or_b32 exec_lo, exec_lo, s4                              // 000000948F1C: 8C7E047E
	s_waitcnt vmcnt(0)                                         // 000000948F20: BF8903F7
	v_readfirstlane_b32 s4, v2                                 // 000000948F24: 7E080502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000948F28: BF870091
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s4, v1       // 000000948F2C: CA200080 02000204
	v_cmp_eq_u32_e32 vcc_lo, 3, v1                             // 000000948F34: 7C940283
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000948F38: D5010001 01A90280
	ds_store_b32 v2, v1 offset:9344                            // 000000948F40: D8342480 00000102
	s_or_b32 exec_lo, exec_lo, s3                              // 000000948F48: 8C7E037E
	v_mov_b32_e32 v1, 0                                        // 000000948F4C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000948F50: BF89FC07
	s_barrier                                                  // 000000948F54: BFBD0000
	buffer_gl0_inv                                             // 000000948F58: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:9344                             // 000000948F60: D8D82480 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000948F68: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000948F6C: 7C940280
	s_cbranch_vccnz 1456                                       // 000000948F70: BFA405B0 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x3a34>
	buffer_gl1_inv                                             // 000000948F74: E0B00000 00000000
	buffer_gl0_inv                                             // 000000948F7C: E0AC0000 00000000
	s_mov_b32 s3, exec_lo                                      // 000000948F84: BE83007E
	v_cmpx_eq_u32_e32 0, v25                                   // 000000948F88: 7D943280
	s_cbranch_execz 1449                                       // 000000948F8C: BFA505A9 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x3a34>
	v_dual_mov_b32 v98, 0 :: v_dual_and_b32 v1, 15, v0         // 000000948F90: CA240080 6200008F
	s_ashr_i32 s7, s6, 31                                      // 000000948F98: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000948F9C: BF870099
	s_lshl_b64 s[4:5], s[6:7], 13                              // 000000948FA0: 84848D06
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000948FA4: 30040282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000948FA8: BF870091
	.long 0xd7000302                                           // 000000948FAC: D7000302
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 000000948FB0: 02020410
	v_add_co_ci_u32_e64 v3, null, s17, 0, s3                   // 000000948FB4: D5207C03 000D0011
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000948FBC: BF870092
	.long 0xd7006a34                                           // 000000948FC0: D7006A34
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 000000948FC4: 02000902
	v_add_co_ci_u32_e64 v53, null, s5, v3, vcc_lo              // 000000948FC8: D5207C35 01AA0605
	s_clause 0x3                                               // 000000948FD0: BF850003
	global_load_b32 v99, v[52:53], off glc                     // 000000948FD4: DC524000 637C0034
	global_load_b32 v100, v[52:53], off offset:512 glc         // 000000948FDC: DC524200 647C0034
	global_load_b32 v102, v[52:53], off offset:1024 glc        // 000000948FE4: DC524400 667C0034
	global_load_b32 v103, v[52:53], off offset:1536 glc        // 000000948FEC: DC524600 677C0034
	.long 0xd7006a83                                           // 000000948FF4: D7006A83
	v_cndmask_b32_e32 v1, 0x1000, v52, vcc_lo                  // 000000948FF8: 020268FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000949000: BF870001
	v_add_co_ci_u32_e64 v132, null, 0, v53, vcc_lo             // 000000949004: D5207C84 01AA6A80
	s_clause 0x1f                                              // 00000094900C: BF85001F
	global_load_b32 v70, v[52:53], off offset:2048 glc         // 000000949010: DC524800 467C0034
	global_load_b32 v71, v[52:53], off offset:2560 glc         // 000000949018: DC524A00 477C0034
	global_load_b32 v64, v[52:53], off offset:3072 glc         // 000000949020: DC524C00 407C0034
	global_load_b32 v65, v[52:53], off offset:3584 glc         // 000000949028: DC524E00 417C0034
	global_load_b32 v14, v[131:132], off glc                   // 000000949030: DC524000 0E7C0083
	global_load_b32 v15, v[131:132], off offset:512 glc        // 000000949038: DC524200 0F7C0083
	global_load_b32 v8, v[131:132], off offset:1024 glc        // 000000949040: DC524400 087C0083
	global_load_b32 v9, v[131:132], off offset:1536 glc        // 000000949048: DC524600 097C0083
	global_load_b32 v4, v[131:132], off offset:2048 glc        // 000000949050: DC524800 047C0083
	global_load_b32 v5, v[131:132], off offset:2560 glc        // 000000949058: DC524A00 057C0083
	global_load_b32 v2, v[131:132], off offset:3072 glc        // 000000949060: DC524C00 027C0083
	global_load_b32 v3, v[131:132], off offset:3584 glc        // 000000949068: DC524E00 037C0083
	global_load_b32 v101, v[52:53], off offset:64 glc          // 000000949070: DC524040 657C0034
	global_load_b32 v108, v[52:53], off offset:576 glc         // 000000949078: DC524240 6C7C0034
	global_load_b32 v104, v[52:53], off offset:1088 glc        // 000000949080: DC524440 687C0034
	global_load_b32 v105, v[52:53], off offset:1600 glc        // 000000949088: DC524640 697C0034
	global_load_b32 v74, v[52:53], off offset:2112 glc         // 000000949090: DC524840 4A7C0034
	global_load_b32 v75, v[52:53], off offset:2624 glc         // 000000949098: DC524A40 4B7C0034
	global_load_b32 v68, v[52:53], off offset:3136 glc         // 0000009490A0: DC524C40 447C0034
	global_load_b32 v69, v[52:53], off offset:3648 glc         // 0000009490A8: DC524E40 457C0034
	global_load_b32 v22, v[131:132], off offset:64 glc         // 0000009490B0: DC524040 167C0083
	global_load_b32 v23, v[131:132], off offset:576 glc        // 0000009490B8: DC524240 177C0083
	global_load_b32 v16, v[131:132], off offset:1088 glc       // 0000009490C0: DC524440 107C0083
	global_load_b32 v17, v[131:132], off offset:1600 glc       // 0000009490C8: DC524640 117C0083
	global_load_b32 v10, v[131:132], off offset:2112 glc       // 0000009490D0: DC524840 0A7C0083
	global_load_b32 v11, v[131:132], off offset:2624 glc       // 0000009490D8: DC524A40 0B7C0083
	global_load_b32 v6, v[131:132], off offset:3136 glc        // 0000009490E0: DC524C40 067C0083
	global_load_b32 v7, v[131:132], off offset:3648 glc        // 0000009490E8: DC524E40 077C0083
	global_load_b32 v111, v[52:53], off offset:128 glc         // 0000009490F0: DC524080 6F7C0034
	global_load_b32 v112, v[52:53], off offset:640 glc         // 0000009490F8: DC524280 707C0034
	global_load_b32 v106, v[52:53], off offset:1152 glc        // 000000949100: DC524480 6A7C0034
	global_load_b32 v107, v[52:53], off offset:1664 glc        // 000000949108: DC524680 6B7C0034
	s_clause 0x1f                                              // 000000949110: BF85001F
	global_load_b32 v78, v[52:53], off offset:2176 glc         // 000000949114: DC524880 4E7C0034
	global_load_b32 v79, v[52:53], off offset:2688 glc         // 00000094911C: DC524A80 4F7C0034
	global_load_b32 v72, v[52:53], off offset:3200 glc         // 000000949124: DC524C80 487C0034
	global_load_b32 v73, v[52:53], off offset:3712 glc         // 00000094912C: DC524E80 497C0034
	global_load_b32 v30, v[131:132], off offset:128 glc        // 000000949134: DC524080 1E7C0083
	global_load_b32 v31, v[131:132], off offset:640 glc        // 00000094913C: DC524280 1F7C0083
	global_load_b32 v24, v[131:132], off offset:1152 glc       // 000000949144: DC524480 187C0083
	global_load_b32 v25, v[131:132], off offset:1664 glc       // 00000094914C: DC524680 197C0083
	global_load_b32 v18, v[131:132], off offset:2176 glc       // 000000949154: DC524880 127C0083
	global_load_b32 v19, v[131:132], off offset:2688 glc       // 00000094915C: DC524A80 137C0083
	global_load_b32 v12, v[131:132], off offset:3200 glc       // 000000949164: DC524C80 0C7C0083
	global_load_b32 v13, v[131:132], off offset:3712 glc       // 00000094916C: DC524E80 0D7C0083
	global_load_b32 v115, v[52:53], off offset:192 glc         // 000000949174: DC5240C0 737C0034
	global_load_b32 v116, v[52:53], off offset:704 glc         // 00000094917C: DC5242C0 747C0034
	global_load_b32 v109, v[52:53], off offset:1216 glc        // 000000949184: DC5244C0 6D7C0034
	global_load_b32 v110, v[52:53], off offset:1728 glc        // 00000094918C: DC5246C0 6E7C0034
	global_load_b32 v82, v[52:53], off offset:2240 glc         // 000000949194: DC5248C0 527C0034
	global_load_b32 v83, v[52:53], off offset:2752 glc         // 00000094919C: DC524AC0 537C0034
	global_load_b32 v76, v[52:53], off offset:3264 glc         // 0000009491A4: DC524CC0 4C7C0034
	global_load_b32 v77, v[52:53], off offset:3776 glc         // 0000009491AC: DC524EC0 4D7C0034
	global_load_b32 v38, v[131:132], off offset:192 glc        // 0000009491B4: DC5240C0 267C0083
	global_load_b32 v39, v[131:132], off offset:704 glc        // 0000009491BC: DC5242C0 277C0083
	global_load_b32 v32, v[131:132], off offset:1216 glc       // 0000009491C4: DC5244C0 207C0083
	global_load_b32 v33, v[131:132], off offset:1728 glc       // 0000009491CC: DC5246C0 217C0083
	global_load_b32 v26, v[131:132], off offset:2240 glc       // 0000009491D4: DC5248C0 1A7C0083
	global_load_b32 v27, v[131:132], off offset:2752 glc       // 0000009491DC: DC524AC0 1B7C0083
	global_load_b32 v20, v[131:132], off offset:3264 glc       // 0000009491E4: DC524CC0 147C0083
	global_load_b32 v21, v[131:132], off offset:3776 glc       // 0000009491EC: DC524EC0 157C0083
	global_load_b32 v119, v[52:53], off offset:256 glc         // 0000009491F4: DC524100 777C0034
	global_load_b32 v120, v[52:53], off offset:768 glc         // 0000009491FC: DC524300 787C0034
	global_load_b32 v113, v[52:53], off offset:1280 glc        // 000000949204: DC524500 717C0034
	global_load_b32 v114, v[52:53], off offset:1792 glc        // 00000094920C: DC524700 727C0034
	s_clause 0x1f                                              // 000000949214: BF85001F
	global_load_b32 v86, v[52:53], off offset:2304 glc         // 000000949218: DC524900 567C0034
	global_load_b32 v87, v[52:53], off offset:2816 glc         // 000000949220: DC524B00 577C0034
	global_load_b32 v80, v[52:53], off offset:3328 glc         // 000000949228: DC524D00 507C0034
	global_load_b32 v81, v[52:53], off offset:3840 glc         // 000000949230: DC524F00 517C0034
	global_load_b32 v46, v[131:132], off offset:256 glc        // 000000949238: DC524100 2E7C0083
	global_load_b32 v47, v[131:132], off offset:768 glc        // 000000949240: DC524300 2F7C0083
	global_load_b32 v40, v[131:132], off offset:1280 glc       // 000000949248: DC524500 287C0083
	global_load_b32 v41, v[131:132], off offset:1792 glc       // 000000949250: DC524700 297C0083
	global_load_b32 v34, v[131:132], off offset:2304 glc       // 000000949258: DC524900 227C0083
	global_load_b32 v35, v[131:132], off offset:2816 glc       // 000000949260: DC524B00 237C0083
	global_load_b32 v28, v[131:132], off offset:3328 glc       // 000000949268: DC524D00 1C7C0083
	global_load_b32 v29, v[131:132], off offset:3840 glc       // 000000949270: DC524F00 1D7C0083
	global_load_b32 v123, v[52:53], off offset:320 glc         // 000000949278: DC524140 7B7C0034
	global_load_b32 v124, v[52:53], off offset:832 glc         // 000000949280: DC524340 7C7C0034
	global_load_b32 v117, v[52:53], off offset:1344 glc        // 000000949288: DC524540 757C0034
	global_load_b32 v118, v[52:53], off offset:1856 glc        // 000000949290: DC524740 767C0034
	global_load_b32 v90, v[52:53], off offset:2368 glc         // 000000949298: DC524940 5A7C0034
	global_load_b32 v91, v[52:53], off offset:2880 glc         // 0000009492A0: DC524B40 5B7C0034
	global_load_b32 v84, v[52:53], off offset:3392 glc         // 0000009492A8: DC524D40 547C0034
	global_load_b32 v85, v[52:53], off offset:3904 glc         // 0000009492B0: DC524F40 557C0034
	global_load_b32 v54, v[131:132], off offset:320 glc        // 0000009492B8: DC524140 367C0083
	global_load_b32 v55, v[131:132], off offset:832 glc        // 0000009492C0: DC524340 377C0083
	global_load_b32 v48, v[131:132], off offset:1344 glc       // 0000009492C8: DC524540 307C0083
	global_load_b32 v49, v[131:132], off offset:1856 glc       // 0000009492D0: DC524740 317C0083
	global_load_b32 v42, v[131:132], off offset:2368 glc       // 0000009492D8: DC524940 2A7C0083
	global_load_b32 v43, v[131:132], off offset:2880 glc       // 0000009492E0: DC524B40 2B7C0083
	global_load_b32 v36, v[131:132], off offset:3392 glc       // 0000009492E8: DC524D40 247C0083
	global_load_b32 v37, v[131:132], off offset:3904 glc       // 0000009492F0: DC524F40 257C0083
	global_load_b32 v127, v[52:53], off offset:384 glc         // 0000009492F8: DC524180 7F7C0034
	global_load_b32 v128, v[52:53], off offset:896 glc         // 000000949300: DC524380 807C0034
	global_load_b32 v121, v[52:53], off offset:1408 glc        // 000000949308: DC524580 797C0034
	global_load_b32 v122, v[52:53], off offset:1920 glc        // 000000949310: DC524780 7A7C0034
	s_clause 0x1b                                              // 000000949318: BF85001B
	global_load_b32 v94, v[52:53], off offset:2432 glc         // 00000094931C: DC524980 5E7C0034
	global_load_b32 v95, v[52:53], off offset:2944 glc         // 000000949324: DC524B80 5F7C0034
	global_load_b32 v88, v[52:53], off offset:3456 glc         // 00000094932C: DC524D80 587C0034
	global_load_b32 v89, v[52:53], off offset:3968 glc         // 000000949334: DC524F80 597C0034
	global_load_b32 v60, v[131:132], off offset:384 glc        // 00000094933C: DC524180 3C7C0083
	global_load_b32 v61, v[131:132], off offset:896 glc        // 000000949344: DC524380 3D7C0083
	global_load_b32 v56, v[131:132], off offset:1408 glc       // 00000094934C: DC524580 387C0083
	global_load_b32 v57, v[131:132], off offset:1920 glc       // 000000949354: DC524780 397C0083
	global_load_b32 v50, v[131:132], off offset:2432 glc       // 00000094935C: DC524980 327C0083
	global_load_b32 v51, v[131:132], off offset:2944 glc       // 000000949364: DC524B80 337C0083
	global_load_b32 v44, v[131:132], off offset:3456 glc       // 00000094936C: DC524D80 2C7C0083
	global_load_b32 v45, v[131:132], off offset:3968 glc       // 000000949374: DC524F80 2D7C0083
	global_load_b32 v129, v[52:53], off offset:448 glc         // 00000094937C: DC5241C0 817C0034
	global_load_b32 v130, v[52:53], off offset:960 glc         // 000000949384: DC5243C0 827C0034
	global_load_b32 v125, v[52:53], off offset:1472 glc        // 00000094938C: DC5245C0 7D7C0034
	global_load_b32 v126, v[52:53], off offset:1984 glc        // 000000949394: DC5247C0 7E7C0034
	global_load_b32 v96, v[52:53], off offset:2496 glc         // 00000094939C: DC5249C0 607C0034
	global_load_b32 v97, v[52:53], off offset:3008 glc         // 0000009493A4: DC524BC0 617C0034
	global_load_b32 v92, v[52:53], off offset:3520 glc         // 0000009493AC: DC524DC0 5C7C0034
	global_load_b32 v93, v[52:53], off offset:4032 glc         // 0000009493B4: DC524FC0 5D7C0034
	global_load_b32 v66, v[131:132], off offset:448 glc        // 0000009493BC: DC5241C0 427C0083
	global_load_b32 v67, v[131:132], off offset:960 glc        // 0000009493C4: DC5243C0 437C0083
	global_load_b32 v62, v[131:132], off offset:1472 glc       // 0000009493CC: DC5245C0 3E7C0083
	global_load_b32 v63, v[131:132], off offset:1984 glc       // 0000009493D4: DC5247C0 3F7C0083
	global_load_b32 v58, v[131:132], off offset:2496 glc       // 0000009493DC: DC5249C0 3A7C0083
	global_load_b32 v59, v[131:132], off offset:3008 glc       // 0000009493E4: DC524BC0 3B7C0083
	global_load_b32 v52, v[131:132], off offset:3520 glc       // 0000009493EC: DC524DC0 347C0083
	global_load_b32 v53, v[131:132], off offset:4032 glc       // 0000009493F4: DC524FC0 357C0083
	s_and_saveexec_b32 s3, s0                                  // 0000009493FC: BE832000
	s_cbranch_execz 6                                          // 000000949400: BFA50006 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x281c>
	s_lshl_b64 s[4:5], s[6:7], 2                               // 000000949404: 84848206
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000949408: BF870009
	s_add_u32 s4, s18, s4                                      // 00000094940C: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000949410: 82050513
	global_store_b32 v98, v98, s[4:5]                          // 000000949414: DC6A0000 00046262
	s_or_b32 exec_lo, exec_lo, s3                              // 00000094941C: 8C7E037E
	s_mul_i32 s0, s8, 0xa00                                    // 000000949420: 9600FF08 00000A00
	s_mul_hi_i32 s3, s8, 0xa00                                 // 000000949428: 9703FF08 00000A00
	s_add_u32 s0, s10, s0                                      // 000000949430: 8000000A
	s_waitcnt vmcnt(14)                                        // 000000949434: BF893BF7
	v_dual_add_f32 v130, 0, v130 :: v_dual_lshlrev_b32 v131, 1, v0// 000000949438: C9230480 82820081
	s_addc_u32 s4, s11, s3                                     // 000000949440: 8204030B
	s_lshl_b32 s2, s2, 7                                       // 000000949444: 84028702
	v_dual_add_f32 v134, 0, v100 :: v_dual_lshlrev_b32 v1, 1, v1// 000000949448: C922C880 86000281
	s_ashr_i32 s3, s2, 31                                      // 000000949450: 86039F02
	v_or_b32_e32 v132, 32, v131                                // 000000949454: 390906A0
	s_lshl_b64 s[10:11], s[2:3], 1                             // 000000949458: 848A8102
	v_dual_add_f32 v133, 0, v99 :: v_dual_add_f32 v108, 0, v108// 00000094945C: C908C680 856CD880
	s_add_u32 s2, s0, s10                                      // 000000949464: 80020A00
	s_addc_u32 s3, s4, s11                                     // 000000949468: 82030B04
	v_dual_add_f32 v135, 0, v101 :: v_dual_add_f32 v112, 0, v112// 00000094946C: C908CA80 8770E080
	s_clause 0x1                                               // 000000949474: BF850001
	global_load_d16_b16 v98, v1, s[2:3]                        // 000000949478: DC820000 62020001
	global_load_d16_b16 v99, v132, s[2:3]                      // 000000949480: DC820000 63020084
	v_dual_add_f32 v111, 0, v111 :: v_dual_add_f32 v116, 0, v116// 000000949488: C908DE80 6F74E880
	v_dual_add_f32 v115, 0, v115 :: v_dual_add_f32 v120, 0, v120// 000000949490: C908E680 7378F080
	v_dual_add_f32 v127, 0, v127 :: v_dual_and_b32 v136, 1, v0 // 000000949498: C924FE80 7F880081
	v_dual_add_f32 v129, 0, v129 :: v_dual_and_b32 v100, 4, v0 // 0000009494A0: C9250280 81640084
	v_dual_add_f32 v102, v133, v102 :: v_dual_and_b32 v101, 2, v0// 0000009494A8: C924CD85 66640082
	v_dual_add_f32 v103, v134, v103 :: v_dual_and_b32 v0, 8, v0// 0000009494B0: C924CF86 67000088
	v_dual_add_f32 v104, v135, v104 :: v_dual_add_f32 v105, v108, v105// 0000009494B8: C908D187 6868D36C
	v_dual_add_f32 v106, v111, v106 :: v_dual_add_f32 v107, v112, v107// 0000009494C0: C908D56F 6A6AD770
	v_dual_add_f32 v108, v115, v109 :: v_dual_add_f32 v109, v116, v110// 0000009494C8: C908DB73 6C6CDD74
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009494D0: BF870214
	v_dual_add_f32 v102, v102, v70 :: v_dual_add_f32 v103, v103, v71// 0000009494D4: C9088D66 66668F67
	v_dual_add_f32 v74, v104, v74 :: v_dual_add_f32 v75, v105, v75// 0000009494DC: C9089568 4A4A9769
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009494E4: BF870214
	v_dual_add_f32 v104, v106, v78 :: v_dual_add_f32 v79, v107, v79// 0000009494E8: C9089D6A 684E9F6B
	v_dual_add_f32 v82, v108, v82 :: v_dual_add_f32 v83, v109, v83// 0000009494F0: C908A56C 5252A76D
	s_clause 0x6                                               // 0000009494F8: BF850006
	global_load_d16_b16 v105, v1, s[2:3] offset:1280           // 0000009494FC: DC820500 69020001
	global_load_d16_b16 v106, v1, s[2:3] offset:64             // 000000949504: DC820040 6A020001
	global_load_d16_b16 v78, v1, s[2:3] offset:1344            // 00000094950C: DC820540 4E020001
	global_load_d16_b16 v107, v1, s[2:3] offset:128            // 000000949514: DC820080 6B020001
	global_load_d16_b16 v71, v1, s[2:3] offset:1408            // 00000094951C: DC820580 47020001
	global_load_d16_b16 v70, v1, s[2:3] offset:1472            // 000000949524: DC8205C0 46020001
	global_load_d16_b16 v108, v1, s[2:3] offset:192            // 00000094952C: DC8200C0 6C020001
	v_dual_add_f32 v119, 0, v119 :: v_dual_add_f32 v124, 0, v124// 000000949534: C908EE80 777CF880
	v_dual_add_f32 v123, 0, v123 :: v_dual_add_f32 v128, 0, v128// 00000094953C: C908F680 7B810080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000949544: BF870112
	v_dual_add_f32 v111, v120, v114 :: v_dual_add_f32 v110, v119, v113// 000000949548: C908E578 6F6EE377
	v_dual_add_f32 v113, v124, v118 :: v_dual_add_f32 v112, v123, v117// 000000949550: C908ED7C 7170EB7B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000949558: BF870003
	v_dual_add_f32 v114, v127, v121 :: v_dual_add_f32 v115, v128, v122// 00000094955C: C908F37F 7272F580
	s_waitcnt vmcnt(21)                                        // 000000949564: BF8957F7
	v_dual_add_f32 v116, v129, v125 :: v_dual_add_f32 v117, v130, v126// 000000949568: C908FB81 7474FD82
	v_dual_add_f32 v86, v110, v86 :: v_dual_add_f32 v87, v111, v87// 000000949570: C908AD6E 5656AF6F
	v_dual_add_f32 v90, v112, v90 :: v_dual_add_f32 v91, v113, v91// 000000949578: C908B570 5A5AB771
	v_dual_add_f32 v94, v114, v94 :: v_dual_add_f32 v95, v115, v95// 000000949580: C908BD72 5E5EBF73
	s_waitcnt vmcnt(19)                                        // 000000949588: BF894FF7
	v_dual_add_f32 v96, v116, v96 :: v_dual_add_f32 v97, v117, v97// 00000094958C: C908C174 6060C375
	v_dual_add_f32 v102, v102, v64 :: v_dual_add_f32 v103, v103, v65// 000000949594: C9088166 66668367
	v_dual_add_f32 v109, v74, v68 :: v_dual_add_f32 v110, v75, v69// 00000094959C: C908894A 6D6E8B4B
	v_dual_add_f32 v104, v104, v72 :: v_dual_add_f32 v79, v79, v73// 0000009495A4: C9089168 684E934F
	v_dual_add_f32 v76, v82, v76 :: v_dual_add_f32 v77, v83, v77// 0000009495AC: C9089952 4C4C9B53
	v_dual_add_f32 v80, v86, v80 :: v_dual_add_f32 v81, v87, v81// 0000009495B4: C908A156 5050A357
	v_dual_add_f32 v82, v90, v84 :: v_dual_add_f32 v83, v91, v85// 0000009495BC: C908A95A 5252AB5B
	v_dual_add_f32 v84, v94, v88 :: v_dual_add_f32 v85, v95, v89// 0000009495C4: C908B15E 5454B35F
	s_waitcnt vmcnt(17)                                        // 0000009495CC: BF8947F7
	v_dual_add_f32 v86, v96, v92 :: v_dual_add_f32 v87, v97, v93// 0000009495D0: C908B960 5656BB61
	v_dual_add_f32 v14, v102, v14 :: v_dual_add_f32 v15, v103, v15// 0000009495D8: C9081D66 0E0E1F67
	v_dual_add_f32 v22, v109, v22 :: v_dual_add_f32 v23, v110, v23// 0000009495E0: C9082D6D 16162F6E
	v_dual_add_f32 v30, v104, v30 :: v_dual_add_f32 v31, v79, v31// 0000009495E8: C9083D68 1E1E3F4F
	v_dual_add_f32 v38, v76, v38 :: v_dual_add_f32 v39, v77, v39// 0000009495F0: C9084D4C 26264F4D
	v_dual_add_f32 v46, v80, v46 :: v_dual_add_f32 v47, v81, v47// 0000009495F8: C9085D50 2E2E5F51
	v_dual_add_f32 v54, v82, v54 :: v_dual_add_f32 v55, v83, v55// 000000949600: C9086D52 36366F53
	v_dual_add_f32 v60, v84, v60 :: v_dual_add_f32 v61, v85, v61// 000000949608: C9087954 3C3C7B55
	s_waitcnt vmcnt(15)                                        // 000000949610: BF893FF7
	v_dual_add_f32 v66, v86, v66 :: v_dual_add_f32 v67, v87, v67// 000000949614: C9088556 42428757
	s_mul_hi_i32 s0, s8, 0x500                                 // 00000094961C: 9700FF08 00000500
	s_mulk_i32 s8, 0x500                                       // 000000949624: B8080500
	v_dual_add_f32 v8, v14, v8 :: v_dual_add_f32 v9, v15, v9   // 000000949628: C908110E 0808130F
	s_add_u32 s4, s12, s8                                      // 000000949630: 8004080C
	v_dual_add_f32 v14, v22, v16 :: v_dual_add_f32 v15, v23, v17// 000000949634: C9082116 0E0E2317
	v_dual_add_f32 v16, v30, v24 :: v_dual_add_f32 v17, v31, v25// 00000094963C: C908311E 1010331F
	v_dual_add_f32 v22, v38, v32 :: v_dual_add_f32 v23, v39, v33// 000000949644: C9084126 16164327
	v_dual_add_f32 v24, v46, v40 :: v_dual_add_f32 v25, v47, v41// 00000094964C: C908512E 1818532F
	v_dual_add_f32 v30, v54, v48 :: v_dual_add_f32 v31, v55, v49// 000000949654: C9086136 1E1E6337
	v_dual_add_f32 v32, v60, v56 :: v_dual_add_f32 v33, v61, v57// 00000094965C: C908713C 2020733D
	s_waitcnt vmcnt(13)                                        // 000000949664: BF8937F7
	v_dual_add_f32 v38, v66, v62 :: v_dual_add_f32 v39, v67, v63// 000000949668: C9087D42 26267F43
	v_or_b32_e32 v118, 0x60, v131                              // 000000949670: 38ED06FF 00000060
	s_addc_u32 s0, s13, s0                                     // 000000949678: 8200000D
	s_add_u32 s4, s4, s10                                      // 00000094967C: 80040A04
	s_addc_u32 s5, s0, s11                                     // 000000949680: 82050B00
	v_or_b32_e32 v119, 0xa0, v131                              // 000000949684: 38EF06FF 000000A0
	v_or_b32_e32 v120, 0xe0, v131                              // 00000094968C: 38F106FF 000000E0
	s_clause 0x1                                               // 000000949694: BF850001
	global_load_d16_b16 v88, v132, s[2:3] offset:1280          // 000000949698: DC820500 58020084
	global_load_d16_b16 v89, v132, s[4:5]                      // 0000009496A0: DC820000 59040084
	s_clause 0x2                                               // 0000009496A8: BF850002
	global_load_d16_b16 v90, v118, s[2:3]                      // 0000009496AC: DC820000 5A020076
	global_load_d16_b16 v75, v118, s[2:3] offset:1280          // 0000009496B4: DC820500 4B020076
	global_load_d16_b16 v72, v118, s[4:5]                      // 0000009496BC: DC820000 48040076
	s_clause 0x6                                               // 0000009496C4: BF850006
	global_load_d16_b16 v91, v119, s[2:3]                      // 0000009496C8: DC820000 5B020077
	global_load_d16_b16 v74, v119, s[2:3] offset:1280          // 0000009496D0: DC820500 4A020077
	global_load_d16_b16 v73, v119, s[4:5]                      // 0000009496D8: DC820000 49040077
	global_load_d16_b16 v65, v1, s[4:5]                        // 0000009496E0: DC820000 41040001
	global_load_d16_b16 v68, v1, s[4:5] offset:64              // 0000009496E8: DC820040 44040001
	global_load_d16_b16 v69, v1, s[4:5] offset:128             // 0000009496F0: DC820080 45040001
	global_load_d16_b16 v64, v1, s[4:5] offset:192             // 0000009496F8: DC8200C0 40040001
	s_clause 0x2                                               // 000000949700: BF850002
	global_load_d16_b16 v92, v120, s[2:3]                      // 000000949704: DC820000 5C020078
	global_load_d16_b16 v93, v120, s[2:3] offset:1280          // 00000094970C: DC820500 5D020078
	global_load_d16_b16 v94, v120, s[4:5]                      // 000000949714: DC820000 5E040078
	v_dual_add_f32 v4, v8, v4 :: v_dual_add_f32 v5, v9, v5     // 00000094971C: C9080908 04040B09
	v_dual_add_f32 v8, v14, v10 :: v_dual_add_f32 v9, v15, v11 // 000000949724: C908150E 0808170F
	v_dual_add_f32 v10, v16, v18 :: v_dual_add_f32 v11, v17, v19// 00000094972C: C9082510 0A0A2711
	v_dual_add_f32 v14, v22, v26 :: v_dual_add_f32 v15, v23, v27// 000000949734: C9083516 0E0E3717
	v_dual_add_f32 v16, v24, v34 :: v_dual_add_f32 v17, v25, v35// 00000094973C: C9084518 10104719
	v_dual_add_f32 v18, v30, v42 :: v_dual_add_f32 v19, v31, v43// 000000949744: C908551E 1212571F
	v_dual_add_f32 v22, v32, v50 :: v_dual_add_f32 v23, v33, v51// 00000094974C: C9086520 16166721
	s_waitcnt vmcnt(26)                                        // 000000949754: BF896BF7
	v_dual_add_f32 v24, v38, v58 :: v_dual_add_f32 v25, v39, v59// 000000949758: C9087526 18187727
	v_dual_add_f32 v2, v4, v2 :: v_dual_add_f32 v3, v5, v3     // 000000949760: C9080504 02020705
	v_dual_add_f32 v4, v8, v6 :: v_dual_add_f32 v5, v9, v7     // 000000949768: C9080D08 04040F09
	v_dual_add_f32 v6, v10, v12 :: v_dual_add_f32 v7, v11, v13 // 000000949770: C908190A 06061B0B
	v_dual_add_f32 v8, v14, v20 :: v_dual_add_f32 v9, v15, v21 // 000000949778: C908290E 08082B0F
	v_dual_add_f32 v10, v16, v28 :: v_dual_add_f32 v11, v17, v29// 000000949780: C9083910 0A0A3B11
	v_dual_add_f32 v12, v18, v36 :: v_dual_add_f32 v13, v19, v37// 000000949788: C9084912 0C0C4B13
	v_dual_add_f32 v14, v22, v44 :: v_dual_add_f32 v15, v23, v45// 000000949790: C9085916 0E0E5B17
	s_waitcnt vmcnt(24)                                        // 000000949798: BF8963F7
	v_dual_add_f32 v16, v24, v52 :: v_dual_add_f32 v17, v25, v53// 00000094979C: C9086918 10106B19
	v_add_f32_e32 v18, v2, v4                                  // 0000009497A4: 06240902
	v_sub_f32_e32 v2, v2, v4                                   // 0000009497A8: 08040902
	v_add_f32_e32 v4, v6, v8                                   // 0000009497AC: 06081106
	v_sub_f32_e32 v6, v6, v8                                   // 0000009497B0: 080C1106
	v_add_f32_e32 v8, v10, v12                                 // 0000009497B4: 0610190A
	v_sub_f32_e32 v10, v10, v12                                // 0000009497B8: 0814190A
	v_add_f32_e32 v12, v14, v16                                // 0000009497BC: 0618210E
	v_sub_f32_e32 v14, v14, v16                                // 0000009497C0: 081C210E
	v_add_f32_e32 v16, v3, v5                                  // 0000009497C4: 06200B03
	v_sub_f32_e32 v3, v3, v5                                   // 0000009497C8: 08060B03
	v_add_f32_e32 v5, v7, v9                                   // 0000009497CC: 060A1307
	v_sub_f32_e32 v7, v7, v9                                   // 0000009497D0: 080E1307
	v_add_f32_e32 v9, v11, v13                                 // 0000009497D4: 06121B0B
	v_sub_f32_e32 v11, v11, v13                                // 0000009497D8: 08161B0B
	v_add_f32_e32 v13, v15, v17                                // 0000009497DC: 061A230F
	v_sub_f32_e32 v15, v15, v17                                // 0000009497E0: 081E230F
	v_add_f32_e32 v17, v18, v4                                 // 0000009497E4: 06220912
	v_sub_f32_e32 v4, v18, v4                                  // 0000009497E8: 08080912
	v_add_f32_e32 v18, v2, v6                                  // 0000009497EC: 06240D02
	v_sub_f32_e32 v2, v2, v6                                   // 0000009497F0: 08040D02
	v_add_f32_e32 v6, v8, v12                                  // 0000009497F4: 060C1908
	v_sub_f32_e32 v8, v8, v12                                  // 0000009497F8: 08101908
	v_add_f32_e32 v12, v10, v14                                // 0000009497FC: 06181D0A
	v_sub_f32_e32 v10, v10, v14                                // 000000949800: 08141D0A
	v_add_f32_e32 v14, v16, v5                                 // 000000949804: 061C0B10
	v_dual_sub_f32 v5, v16, v5 :: v_dual_add_f32 v16, v3, v7   // 000000949808: C9480B10 05100F03
	v_add_f32_e32 v19, v9, v13                                 // 000000949810: 06261B09
	v_sub_f32_e32 v3, v3, v7                                   // 000000949814: 08060F03
	v_sub_f32_e32 v7, v9, v13                                  // 000000949818: 080E1B09
	v_add_f32_e32 v9, v11, v15                                 // 00000094981C: 06121F0B
	v_sub_f32_e32 v11, v11, v15                                // 000000949820: 08161F0B
	.long 0xd44a0000                                           // 000000949824: D44A0000
	v_cndmask_b32_e32 v1, 0, v136, vcc_lo                      // 000000949828: 02031080
	v_add_f32_e32 v21, v4, v8                                  // 00000094982C: 062A1104
	.long 0xd44a0002                                           // 000000949830: D44A0002
	v_cndmask_b32_e32 v1, 0, v101, vcc_lo                      // 000000949834: 0202CA80
	v_add_f32_e32 v15, v16, v9                                 // 000000949838: 061E1310
	v_dual_sub_f32 v9, v16, v9 :: v_dual_add_f32 v16, v5, v7   // 00000094983C: C9481310 09100F05
	v_sub_f32_e32 v5, v5, v7                                   // 000000949844: 080A0F05
	v_dual_add_f32 v7, v3, v11 :: v_dual_add_f32 v20, v2, v10  // 000000949848: C9081703 07141502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000949850: BF870214
	v_mov_b32_dpp v23, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000949854: 7E2E02FA FF01610F
	v_mov_b32_dpp v24, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000094985C: 7E3002FA FF016110
	v_cndmask_b32_e64 v16, -v16, v16, s0                       // 000000949864: D5010010 20022110
	v_add_f32_e32 v13, v14, v19                                // 00000094986C: 061A270E
	v_dual_sub_f32 v14, v14, v19 :: v_dual_add_f32 v19, v17, v6// 000000949870: C948270E 0E120D11
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 000000949878: D501000F 20021F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000949880: BF870214
	v_add_f32_e32 v16, v16, v24                                // 000000949884: 06203110
	v_mov_b32_dpp v22, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000949888: 7E2C02FA FF01610D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000949890: BF870004
	v_mov_b32_dpp v26, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000949894: 7E3402FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 00000094989C: D501000E 20021D0E
	v_sub_f32_e32 v3, v3, v11                                  // 0000009498A4: 08061703
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 0000009498A8: D501000D 20021B0D
	v_mov_b32_dpp v24, v16 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009498B0: 7E3002FA FF016210
	v_cndmask_b32_e64 v16, -v16, v16, s2                       // 0000009498B8: D5010010 200A2110
	v_add_f32_e32 v14, v14, v26                                // 0000009498C0: 061C350E
	v_mov_b32_dpp v25, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009498C4: 7E3202FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 0000009498CC: D5010007 20020F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009498D4: BF870214
	v_dual_add_f32 v13, v13, v22 :: v_dual_add_f32 v16, v16, v24// 0000009498D8: C9082D0D 0D103110
	v_mov_b32_dpp v26, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009498E0: 7E3402FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 0000009498E8: D501000E 200A1D0E
	.long 0xd44a0004                                           // 0000009498F0: D44A0004
	v_cndmask_b32_e32 v1, 0, v100, vcc_lo                      // 0000009498F4: 0202C880
	v_mov_b32_dpp v27, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009498F8: 7E3602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000949900: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_4)                            // 000000949908: BF870004
	v_dual_add_f32 v15, v15, v23 :: v_dual_add_f32 v14, v14, v26// 00000094990C: C9082F0F 0F0E350E
	v_mov_b32_dpp v24, v16 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000949914: 7E3002FA FF016410
	v_cndmask_b32_e64 v16, -v16, v16, s4                       // 00000094991C: D5010010 20122110
	v_add_f32_e32 v7, v7, v25                                  // 000000949924: 060E3307
	v_add_f32_e32 v11, v18, v12                                // 000000949928: 06161912
	v_mov_b32_dpp v26, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000094992C: 7E3402FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000949934: D501000E 20121D0E
	v_dual_add_f32 v9, v9, v27 :: v_dual_add_f32 v16, v16, v24 // 00000094993C: C9083709 09103110
	v_mov_b32_dpp v25, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000949944: 7E3202FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 00000094994C: D5010007 200A0F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000949954: BF870214
	v_add_f32_e32 v14, v14, v26                                // 000000949958: 061C350E
	v_mov_b32_dpp v27, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000094995C: 7E3602FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000949964: D5010009 200A1309
	v_mov_b32_dpp v31, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000094996C: 7E3E02FA FF01610B
	v_add_f32_e32 v7, v7, v25                                  // 000000949974: 060E3307
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000949978: D501000B 2002170B
	v_mov_b32_dpp v33, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000949980: 7E4202FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000949988: D5010014 20022914
	v_add_f32_e32 v9, v9, v27                                  // 000000949990: 06123709
	v_mov_b32_dpp v25, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000949994: 7E3202FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 00000094999C: D5010007 20120F07
	.long 0xd44a0003                                           // 0000009499A4: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000009499A8: 02020080
	v_mov_b32_dpp v30, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009499AC: 7E3C02FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 0000009499B4: D5010013 20022713
	v_add_f32_e32 v20, v20, v33                                // 0000009499BC: 06284314
	v_mov_b32_dpp v27, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009499C0: 7E3602FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 0000009499C8: D5010009 20121309
	v_add_f32_e32 v7, v7, v25                                  // 0000009499D0: 060E3307
	v_mov_b32_dpp v25, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009499D4: 7E3202FA FF016810
	v_cndmask_b32_e64 v16, -v16, v16, s3                       // 0000009499DC: D5010010 200E2110
	v_add_f32_e32 v11, v11, v31                                // 0000009499E4: 06163F0B
	v_add_f32_e32 v9, v9, v27                                  // 0000009499E8: 06123709
	v_mov_b32_dpp v27, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009499EC: 7E3602FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 0000009499F4: D501000E 200E1D0E
	v_dual_add_f32 v19, v19, v30 :: v_dual_add_f32 v16, v16, v25// 0000009499FC: C9083D13 13103310
	v_mov_b32_dpp v31, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000949A04: 7E3E02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000949A0C: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000949A14: BF870214
	v_add_f32_e32 v14, v14, v27                                // 000000949A18: 061C370E
	v_mov_b32_dpp v30, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000949A1C: 7E3C02FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000949A24: D5010013 200A2713
	v_mov_b32_dpp v29, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000949A2C: 7E3A02FA FF016103
	v_add_f32_e32 v11, v11, v31                                // 000000949A34: 06163F0B
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000949A38: D5010003 20020703
	v_mov_b32_dpp v32, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000949A40: 7E4002FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000949A48: D5010015 20022B15
	v_add_f32_e32 v19, v19, v30                                // 000000949A50: 06263D13
	v_mov_b32_dpp v30, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000949A54: 7E3C02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000949A5C: D501000B 2012170B
	v_add_f32_e32 v3, v3, v29                                  // 000000949A64: 06063B03
	v_dual_add_f32 v21, v21, v32 :: v_dual_mul_f32 v14, 0x3db504f3, v14// 000000949A68: C9064115 150E1CFF 3DB504F3
	v_mov_b32_dpp v28, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000949A74: 7E3802FA FF016105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000949A7C: BF870214
	v_add_f32_e32 v11, v11, v30                                // 000000949A80: 06163D0B
	v_mov_b32_dpp v29, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000949A84: 7E3A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000949A8C: D5010003 200A0703
	v_mov_b32_dpp v32, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000949A94: 7E4002FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000949A9C: D5010015 200A2B15
	v_mov_b32_dpp v30, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000949AA4: 7E3C02FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000949AAC: D501000B 200E170B
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000949AB4: D5010005 20020B05
	v_mov_b32_dpp v22, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000949ABC: 7E2C02FA FF01620D
	v_add_f32_e32 v21, v21, v32                                // 000000949AC4: 062A4115
	v_mov_b32_dpp v32, v20 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000949AC8: 7E4002FA FF016214
	v_dual_add_f32 v11, v11, v30 :: v_dual_sub_f32 v4, v4, v8  // 000000949AD0: C90A3D0B 0B041104
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000949AD8: D5010014 200A2914
	v_add_f32_e32 v3, v3, v29                                  // 000000949AE0: 06063B03
	v_mov_b32_dpp v29, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000949AE4: 7E3A02FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s4                       // 000000949AEC: D5010013 20122713
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000949AF4: D501000D 200A1B0D
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_add_f32 v20, v20, v32// 000000949AFC: C8C816FF 0B144114 3DB504F3
	v_mov_b32_dpp v0, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000949B08: 7E0002FA FF016403
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000949B10: BF8701B4
	v_dual_add_f32 v19, v19, v29 :: v_dual_sub_f32 v6, v17, v6 // 000000949B14: C90A3B13 13060D11
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000949B1C: D5010003 20120703
	v_dual_add_f32 v13, v13, v22 :: v_dual_sub_f32 v12, v18, v12// 000000949B24: C90A2D0D 0D0C1912
	v_mov_b32_dpp v29, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000949B2C: 7E3A02FA FF016813
	v_cndmask_b32_e64 v19, -v19, v19, s3                       // 000000949B34: D5010013 200E2713
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000949B3C: BF870214
	v_add_f32_e32 v0, v3, v0                                   // 000000949B40: 06000103
	v_mov_b32_dpp v22, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000949B44: 7E2C02FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000949B4C: D501000D 20121B0D
	v_mov_b32_dpp v23, v15 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000949B54: 7E2E02FA FF01620F
	v_add_f32_e32 v19, v19, v29                                // 000000949B5C: 06263B13
	v_mov_b32_dpp v30, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000949B60: 7E3C02FA FF016800
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 000000949B68: D5010000 200E0100
	v_add_f32_e32 v13, v13, v22                                // 000000949B70: 061A2D0D
	v_cndmask_b32_e64 v15, -v15, v15, s2                       // 000000949B74: D501000F 200A1F0F
	v_dual_mul_f32 v19, 0x3db504f3, v19 :: v_dual_mul_f32 v16, 0x3db504f3, v16// 000000949B7C: C8C626FF 131020FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 000000949B88: BF870004
	v_add_f32_e32 v0, v0, v30                                  // 000000949B8C: 06003D00
	v_mov_b32_dpp v30, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000949B90: 7E3C02FA FF016414
	v_cndmask_b32_e64 v20, -v20, v20, s4                       // 000000949B98: D5010014 20122914
	v_cndmask_b32_e64 v22, -v13, v13, s3                       // 000000949BA0: D5010016 200E1B0D
	v_mov_b32_dpp v13, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000949BA8: 7E1A02FA FF01680D
	v_dual_add_f32 v15, v15, v23 :: v_dual_mul_f32 v0, 0x3db504f3, v0// 000000949BB0: C9062F0F 0F0000FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 000000949BBC: BF870004
	v_add_f32_e32 v20, v20, v30                                // 000000949BC0: 06283D14
	v_mov_b32_dpp v31, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000949BC4: 7E3E02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s4                       // 000000949BCC: D5010015 20122B15
	v_add_f32_e32 v13, v22, v13                                // 000000949BD4: 061A1B16
	v_mov_b32_dpp v23, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000949BD8: 7E2E02FA FF01640F
	v_cndmask_b32_e64 v15, -v15, v15, s4                       // 000000949BE0: D501000F 20121F0F
	v_sub_f32_e32 v2, v2, v10                                  // 000000949BE8: 08041502
	s_waitcnt vmcnt(23)                                        // 000000949BEC: BF895FF7
	v_fma_mix_f32 v19, v98, v19, neg(0) op_sel_hi:[1,0,0]      // 000000949BF0: CC200013 8A022762
	s_waitcnt vmcnt(22)                                        // 000000949BF8: BF895BF7
	v_fma_mix_f32 v3, v99, v11, neg(0) op_sel_hi:[1,0,0]       // 000000949BFC: CC200003 8A021763
	v_add_f32_e32 v5, v5, v28                                  // 000000949C04: 060A3905
	v_add_f32_e32 v11, v21, v31                                // 000000949C08: 06163F15
	v_mul_f32_e32 v21, 0xbfb8aa3b, v19                         // 000000949C0C: 102A26FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000949C14: BF870214
	v_mul_f32_e32 v24, 0xbfb8aa3b, v3                          // 000000949C18: 103006FF BFB8AA3B
	v_mov_b32_dpp v28, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000949C20: 7E3802FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000949C28: D5010005 200A0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000949C30: BF870194
	v_exp_f32_e32 v21, v21                                     // 000000949C34: 7E2A4B15
	v_exp_f32_e32 v24, v24                                     // 000000949C38: 7E304B18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000949C3C: BF870091
	v_add_f32_e32 v5, v5, v28                                  // 000000949C40: 060A3905
	v_mov_b32_dpp v28, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000949C44: 7E3802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000949C4C: D5010005 20120B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000949C54: BF870115
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_add_f32 v24, 1.0, v24// 000000949C58: C9082AF2 151830F2
	v_add_f32_e32 v5, v5, v28                                  // 000000949C60: 060A3905
	s_waitcnt vmcnt(19)                                        // 000000949C64: BF894FF7
	v_fma_mix_f32 v16, v78, v16, neg(0) op_sel_hi:[1,0,0]      // 000000949C68: CC200010 8A02214E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000949C70: BF870193
	v_div_scale_f32 v22, null, v21, v21, v19                   // 000000949C74: D6FC7C16 044E2B15
	v_mov_b32_dpp v29, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000949C7C: 7E3A02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000949C84: D5010005 200E0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000949C8C: BF870093
	v_rcp_f32_e32 v25, v22                                     // 000000949C90: 7E325516
	v_add_f32_e32 v5, v5, v29                                  // 000000949C94: 060A3B05
	v_div_scale_f32 v29, vcc_lo, v19, v21, v19                 // 000000949C98: D6FC6A1D 044E2B13
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000949CA0: BF870095
	v_fma_f32 v27, -v22, v25, 1.0                              // 000000949CA4: D613001B 23CA3316
	v_fmac_f32_e32 v25, v27, v25                               // 000000949CAC: 5632331B
	v_mov_b32_dpp v27, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000949CB0: 7E3602FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000949CB8: D501000B 200E170B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000949CC0: BF870211
	v_add_f32_e32 v11, v11, v27                                // 000000949CC4: 0616370B
	v_mul_f32_e32 v27, v29, v25                                // 000000949CC8: 1036331D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000949CCC: BF870112
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000949CD0: 101616FF 3DB504F3
	v_fma_f32 v33, -v22, v27, v29                              // 000000949CD8: D6130021 24763716
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000949CE0: BF870092
	v_fma_mix_f32 v11, v106, v11, neg(0) op_sel_hi:[1,0,0]     // 000000949CE4: CC20000B 8A02176A
	v_dual_fmac_f32 v27, v33, v25 :: v_dual_mul_f32 v32, 0xbfb8aa3b, v11// 000000949CEC: C8063321 1B2016FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000949CF8: BF870091
	v_fma_f32 v22, -v22, v27, v29                              // 000000949CFC: D6130016 24763716
	v_div_fmas_f32 v22, v22, v25, v27                          // 000000949D04: D6370016 046E3316
	v_mov_b32_dpp v25, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000949D0C: 7E3202FA FF016814
	v_cndmask_b32_e64 v20, -v20, v20, s3                       // 000000949D14: D5010014 200E2914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000949D1C: BF8701A3
	v_div_fixup_f32 v19, v22, v21, v19                         // 000000949D20: D6270013 044E2B16
	v_mov_b32_dpp v22, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000949D28: 7E2C02FA FF01610C
	v_add_f32_e32 v20, v20, v25                                // 000000949D30: 06283314
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000949D34: D501000C 2002190C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000949D3C: BF870232
	v_mul_f32_e32 v17, 0x3db504f3, v20                         // 000000949D40: 102228FF 3DB504F3
	v_mov_b32_dpp v20, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000949D48: 7E2802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000949D50: D5010006 20020D06
	v_dual_add_f32 v15, v15, v23 :: v_dual_add_f32 v12, v12, v22// 000000949D58: C9082F0F 0F0C2D0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000949D60: BF870112
	v_add_f32_e32 v6, v6, v20                                  // 000000949D64: 060C2906
	v_mov_b32_dpp v23, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000949D68: 7E2E02FA FF01680F
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 000000949D70: D501000F 200E1F0F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000949D78: BF870004
	v_mov_b32_dpp v22, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000949D7C: 7E2C02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000949D84: D501000C 200A190C
	v_mov_b32_dpp v20, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000949D8C: 7E2802FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000949D94: D5010006 200A0D06
	v_add_f32_e32 v15, v15, v23                                // 000000949D9C: 061E2F0F
	v_div_scale_f32 v23, null, v24, v24, v3                    // 000000949DA0: D6FC7C17 040E3118
	v_add_f32_e32 v12, v12, v22                                // 000000949DA8: 06182D0C
	v_mov_b32_dpp v26, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000949DAC: 7E3402FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000949DB4: D5010007 200E0F07
	v_add_f32_e32 v6, v6, v20                                  // 000000949DBC: 060C2906
	v_mov_b32_dpp v28, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000949DC0: 7E3802FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000949DC8: D5010009 200E1309
	v_mov_b32_dpp v20, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000949DD0: 7E2802FA FF01640C
	v_add_f32_e32 v7, v7, v26                                  // 000000949DD8: 060E3507
	v_rcp_f32_e32 v26, v23                                     // 000000949DDC: 7E345517
	v_cndmask_b32_e64 v12, -v12, v12, s4                       // 000000949DE0: D501000C 2012190C
	v_add_f32_e32 v9, v9, v28                                  // 000000949DE8: 06123909
	s_waitcnt vmcnt(1)                                         // 000000949DEC: BF8907F7
	v_fma_mix_f32 v0, v93, v0, neg(0) op_sel_hi:[1,0,0]        // 000000949DF0: CC200000 8A02015D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000949DF8: BF870293
	v_dual_add_f32 v12, v12, v20 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 000000949DFC: C906290C 0C0C1AFF 3DB504F3
	v_fma_f32 v28, -v23, v26, 1.0                              // 000000949E08: D613001C 23CA3517
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000949E10: BF870112
	v_fma_mix_f32 v13, v105, v13, neg(0) op_sel_hi:[1,0,0]     // 000000949E14: CC20000D 8A021B69
	v_fmac_f32_e32 v26, v28, v26                               // 000000949E1C: 5634351C
	v_div_scale_f32 v28, s5, v3, v24, v3                       // 000000949E20: D6FC051C 040E3103
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000949E28: BF870123
	v_mul_f32_e32 v13, v13, v19                                // 000000949E2C: 101A270D
	s_mov_b32 vcc_lo, s5                                       // 000000949E30: BEEA0005
	v_mul_f32_e32 v31, v28, v26                                // 000000949E34: 103E351C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000949E38: BF870091
	v_fma_f32 v34, -v23, v31, v28                              // 000000949E3C: D6130022 24723F17
	v_fmac_f32_e32 v31, v34, v26                               // 000000949E44: 563E3522
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000949E48: BF8700A1
	v_fma_f32 v23, -v23, v31, v28                              // 000000949E4C: D6130017 24723F17
	v_exp_f32_e32 v28, v32                                     // 000000949E54: 7E384B20
	v_div_fmas_f32 v23, v23, v26, v31                          // 000000949E58: D6370017 047E3517
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000949E60: BF870291
	v_div_fixup_f32 v3, v23, v24, v3                           // 000000949E64: D6270003 040E3117
	v_add_f32_e32 v26, 1.0, v28                                // 000000949E6C: 063438F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000949E70: BF870121
	v_div_scale_f32 v21, null, v26, v26, v11                   // 000000949E74: D6FC7C15 042E351A
	v_div_scale_f32 v8, vcc_lo, v11, v26, v11                  // 000000949E7C: D6FC6A08 042E350B
	v_rcp_f32_e32 v18, v21                                     // 000000949E84: 7E245515
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000949E88: BF870095
	v_fma_f32 v19, -v21, v18, 1.0                              // 000000949E8C: D6130013 23CA2515
	v_fmac_f32_e32 v18, v19, v18                               // 000000949E94: 56242513
	v_mov_b32_dpp v19, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000949E98: 7E2602FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000949EA0: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000949EA8: BF8701B1
	v_add_f32_e32 v4, v4, v19                                  // 000000949EAC: 06082704
	v_mov_b32_dpp v19, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000949EB0: 7E2602FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000949EB8: D5010002 20020502
	v_mov_b32_dpp v22, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000949EC0: 7E2C02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000949EC8: D5010004 200A0904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000949ED0: BF870113
	v_add_f32_e32 v2, v2, v19                                  // 000000949ED4: 06042702
	v_dual_add_f32 v4, v4, v22 :: v_dual_mul_f32 v15, 0x3db504f3, v15// 000000949ED8: C9062D04 040E1EFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000949EE4: BF870111
	v_mov_b32_dpp v20, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000949EE8: 7E2802FA FF016404
	v_fma_mix_f32 v15, v88, v15, neg(0) op_sel_hi:[1,0,0]      // 000000949EF0: CC20000F 8A021F58
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000949EF8: D5010004 20120904
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000949F00: BF8700A2
	v_mul_f32_e32 v3, v15, v3                                  // 000000949F04: 1006070F
	v_fma_mix_f32 v15, v90, v17, neg(0) op_sel_hi:[1,0,0]      // 000000949F08: CC20000F 8A02235A
	v_dual_add_f32 v4, v4, v20 :: v_dual_mul_f32 v17, 0xbfb8aa3b, v15// 000000949F10: C9062904 04101EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000949F1C: BF8700B1
	v_exp_f32_e32 v10, v17                                     // 000000949F20: 7E144B11
	v_mov_b32_dpp v17, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000949F24: 7E2202FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 000000949F2C: D5010006 20120D06
	v_add_f32_e32 v6, v6, v17                                  // 000000949F34: 060C2306
	v_mov_b32_dpp v17, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000949F38: 7E2202FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000949F40: D5010002 200A0502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000949F48: BF870215
	v_add_f32_e32 v10, 1.0, v10                                // 000000949F4C: 061414F2
	v_mov_b32_dpp v19, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000949F50: 7E2602FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000949F58: D5010006 200E0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000949F60: BF870234
	v_add_f32_e32 v2, v2, v17                                  // 000000949F64: 06042302
	v_mov_b32_dpp v17, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000949F68: 7E2202FA FF01680C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000949F70: D501000C 200E190C
	v_add_f32_e32 v6, v6, v19                                  // 000000949F78: 060C2706
	s_delay_alu instid0(VALU_DEP_4)                            // 000000949F7C: BF870004
	v_mov_b32_dpp v19, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000949F80: 7E2602FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000949F88: D5010002 20120502
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000949F90: 101212FF 3DB504F3
	v_add_f32_e32 v12, v12, v17                                // 000000949F98: 0618230C
	v_mov_b32_dpp v17, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000949F9C: 7E2202FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000949FA4: D5010004 200E0904
	v_add_f32_e32 v2, v2, v19                                  // 000000949FAC: 06042702
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v6, 0x3db504f3, v6// 000000949FB0: C8C60EFF 07060CFF 3DB504F3
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v12, 0x3db504f3, v12// 000000949FBC: C8C60AFF 050C18FF 3DB504F3
	v_div_scale_f32 v19, null, v10, v10, v15                   // 000000949FC8: D6FC7C13 043E150A
	v_add_f32_e32 v4, v4, v17                                  // 000000949FD0: 06082304
	v_mov_b32_dpp v17, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000949FD4: 7E2202FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000949FDC: D5010002 200E0502
	v_fma_mix_f32 v6, v107, v6, neg(0) op_sel_hi:[1,0,0]       // 000000949FE4: CC200006 8A020D6B
	v_rcp_f32_e32 v20, v19                                     // 000000949FEC: 7E285513
	v_fma_mix_f32 v12, v91, v12, neg(0) op_sel_hi:[1,0,0]      // 000000949FF0: CC20000C 8A02195B
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000949FF8: 100808FF 3DB504F3
	v_add_f32_e32 v2, v2, v17                                  // 00000094A000: 06042302
	v_mul_f32_e32 v22, 0xbfb8aa3b, v6                          // 00000094A004: 102C0CFF BFB8AA3B
	v_fma_mix_f32 v5, v70, v5, neg(0) op_sel_hi:[1,0,0]        // 00000094A00C: CC200005 8A020B46
	v_mul_f32_e32 v17, v8, v18                                 // 00000094A014: 10222508
	v_mul_f32_e32 v23, 0xbfb8aa3b, v12                         // 00000094A018: 102E18FF BFB8AA3B
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 00000094A020: 100404FF 3DB504F3
	v_fma_mix_f32 v4, v108, v4, neg(0) op_sel_hi:[1,0,0]       // 00000094A028: CC200004 8A02096C
	v_exp_f32_e32 v22, v22                                     // 00000094A030: 7E2C4B16
	v_fma_f32 v24, -v21, v17, v8                               // 00000094A034: D6130018 24222315
	v_fma_f32 v25, -v19, v20, 1.0                              // 00000094A03C: D6130019 23CA2913
	v_exp_f32_e32 v23, v23                                     // 00000094A044: 7E2E4B17
	v_fma_mix_f32 v2, v92, v2, neg(0) op_sel_hi:[1,0,0]        // 00000094A048: CC200002 8A02055C
	v_mul_f32_e32 v27, 0xbfb8aa3b, v4                          // 00000094A050: 103608FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000094A058: BF870223
	v_dual_fmac_f32 v17, v24, v18 :: v_dual_fmac_f32 v20, v25, v20// 00000094A05C: C8002518 11142919
	v_fma_mix_f32 v7, v75, v7, neg(0) op_sel_hi:[1,0,0]        // 00000094A064: CC200007 8A020F4B
	v_mul_f32_e32 v25, 0xbfb8aa3b, v2                          // 00000094A06C: 103204FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_2)// 00000094A074: BF870334
	v_exp_f32_e32 v24, v27                                     // 00000094A078: 7E304B1B
	v_add_f32_e32 v22, 1.0, v22                                // 00000094A07C: 062C2CF2
	v_fma_f32 v8, -v21, v17, v8                                // 00000094A080: D6130008 24222315
	v_add_f32_e32 v21, 1.0, v23                                // 00000094A088: 062A2EF2
	v_exp_f32_e32 v23, v25                                     // 00000094A08C: 7E2E4B19
	v_div_scale_f32 v27, s5, v15, v10, v15                     // 00000094A090: D6FC051B 043E150F
	v_div_scale_f32 v28, null, v22, v22, v6                    // 00000094A098: D6FC7C1C 041A2D16
	v_div_fmas_f32 v8, v8, v18, v17                            // 00000094A0A0: D6370008 04462508
	v_div_scale_f32 v30, null, v21, v21, v12                   // 00000094A0A8: D6FC7C1E 04322B15
	s_mov_b32 vcc_lo, s5                                       // 00000094A0B0: BEEA0005
	v_add_f32_e32 v24, 1.0, v24                                // 00000094A0B4: 063030F2
	v_mul_f32_e32 v25, v27, v20                                // 00000094A0B8: 1032291B
	v_rcp_f32_e32 v29, v28                                     // 00000094A0BC: 7E3A551C
	v_rcp_f32_e32 v31, v30                                     // 00000094A0C0: 7E3E551E
	v_add_f32_e32 v23, 1.0, v23                                // 00000094A0C4: 062E2EF2
	v_div_scale_f32 v17, null, v24, v24, v4                    // 00000094A0C8: D6FC7C11 04123118
	v_fma_f32 v18, -v19, v25, v27                              // 00000094A0D0: D6130012 246E3313
	v_div_fixup_f32 v8, v8, v26, v11                           // 00000094A0D8: D6270008 042E3508
	v_div_scale_f32 v11, s6, v6, v22, v6                       // 00000094A0E0: D6FC060B 041A2D06
	v_div_scale_f32 v34, null, v23, v23, v2                    // 00000094A0E8: D6FC7C22 040A2F17
	v_rcp_f32_e32 v33, v17                                     // 00000094A0F0: 7E425511
	v_fmac_f32_e32 v25, v18, v20                               // 00000094A0F4: 56322912
	v_fma_f32 v32, -v28, v29, 1.0                              // 00000094A0F8: D6130020 23CA3B1C
	v_fma_f32 v26, -v30, v31, 1.0                              // 00000094A100: D613001A 23CA3F1E
	v_rcp_f32_e32 v18, v34                                     // 00000094A108: 7E245522
	v_mul_f32_e32 v8, v16, v8                                  // 00000094A10C: 10101110
	v_fma_f32 v19, -v19, v25, v27                              // 00000094A110: D6130013 246E3313
	v_fmac_f32_e32 v29, v32, v29                               // 00000094A118: 563A3B20
	v_fmac_f32_e32 v31, v26, v31                               // 00000094A11C: 563E3F1A
	v_div_scale_f32 v26, s7, v12, v21, v12                     // 00000094A120: D6FC071A 04322B0C
	v_fma_f32 v16, -v17, v33, 1.0                              // 00000094A128: D6130010 23CA4311
	v_div_fmas_f32 v19, v19, v20, v25                          // 00000094A130: D6370013 04662913
	v_mul_f32_e32 v27, v11, v29                                // 00000094A138: 10363B0B
	s_mov_b32 vcc_lo, s6                                       // 00000094A13C: BEEA0006
	v_fma_f32 v32, -v34, v18, 1.0                              // 00000094A140: D6130020 23CA2522
	v_fmac_f32_e32 v33, v16, v33                               // 00000094A148: 56424310
	v_div_scale_f32 v16, s8, v4, v24, v4                       // 00000094A14C: D6FC0810 04123104
	v_fma_f32 v20, -v28, v27, v11                              // 00000094A154: D6130014 242E371C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000094A15C: BF870224
	v_dual_mul_f32 v25, v26, v31 :: v_dual_fmac_f32 v18, v32, v18// 00000094A160: C8C03F1A 19122520
	v_div_scale_f32 v32, s5, v2, v23, v2                       // 00000094A168: D6FC0520 040A2F02
	v_mul_f32_e32 v35, v16, v33                                // 00000094A170: 10464310
	v_div_fixup_f32 v10, v19, v10, v15                         // 00000094A174: D627000A 043E1513
	v_fmac_f32_e32 v27, v20, v29                               // 00000094A17C: 56363B14
	v_fma_f32 v15, -v30, v25, v26                              // 00000094A180: D613000F 246A331E
	v_mul_f32_e32 v20, v32, v18                                // 00000094A188: 10282520
	v_fma_f32 v19, -v17, v35, v16                              // 00000094A18C: D6130013 24424711
	v_mul_f32_e32 v7, v7, v10                                  // 00000094A194: 100E1507
	v_fma_f32 v11, -v28, v27, v11                              // 00000094A198: D613000B 242E371C
	v_fmac_f32_e32 v25, v15, v31                               // 00000094A1A0: 56323F0F
	v_fma_f32 v15, -v34, v20, v32                              // 00000094A1A4: D613000F 24822922
	v_fmac_f32_e32 v35, v19, v33                               // 00000094A1AC: 56464313
	v_fma_mix_f32 v9, v74, v9, neg(0) op_sel_hi:[1,0,0]        // 00000094A1B0: CC200009 8A02134A
	v_div_fmas_f32 v11, v11, v29, v27                          // 00000094A1B8: D637000B 046E3B0B
	v_fma_f32 v19, -v30, v25, v26                              // 00000094A1C0: D6130013 246A331E
	v_fmac_f32_e32 v20, v15, v18                               // 00000094A1C8: 5628250F
	v_fma_f32 v15, -v17, v35, v16                              // 00000094A1CC: D613000F 24424711
	s_mov_b32 vcc_lo, s7                                       // 00000094A1D4: BEEA0007
	v_div_fixup_f32 v6, v11, v22, v6                           // 00000094A1D8: D6270006 041A2D0B
	v_div_fmas_f32 v16, v19, v31, v25                          // 00000094A1E0: D6370010 04663F13
	v_fma_f32 v17, -v34, v20, v32                              // 00000094A1E8: D6130011 24822922
	s_mov_b32 vcc_lo, s8                                       // 00000094A1F0: BEEA0008
	v_fma_mix_f32 v3, v89, v3, neg(0) op_sel_hi:[1,0,0]        // 00000094A1F4: CC200003 8A020759
	v_div_fmas_f32 v15, v15, v33, v35                          // 00000094A1FC: D637000F 048E430F
	s_mov_b32 vcc_lo, s5                                       // 00000094A204: BEEA0005
	v_div_fixup_f32 v10, v16, v21, v12                         // 00000094A208: D627000A 04322B10
	v_div_fmas_f32 v17, v17, v18, v20                          // 00000094A210: D6370011 04522511
	v_fma_mix_f32 v12, v71, v14, neg(0) op_sel_hi:[1,0,0]      // 00000094A218: CC20000C 8A021D47
	v_div_fixup_f32 v4, v15, v24, v4                           // 00000094A220: D6270004 0412310F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000094A228: BF870214
	v_mul_f32_e32 v9, v9, v10                                  // 00000094A22C: 10121509
	v_div_fixup_f32 v2, v17, v23, v2                           // 00000094A230: D6270002 040A2F11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000094A238: BF870214
	v_mul_f32_e32 v6, v12, v6                                  // 00000094A23C: 100C0D0C
	v_mul_f32_e32 v4, v5, v4                                   // 00000094A240: 10080905
	v_fma_mix_f32 v5, v13, v65, v3 op_sel_hi:[0,1,0]           // 00000094A244: CC200005 140E830D
	v_fma_mix_f32 v3, v13, v65, -v3 op_sel_hi:[0,1,0]          // 00000094A24C: CC200003 940E830D
	v_mul_f32_e32 v0, v0, v2                                   // 00000094A254: 10000500
	v_fma_mix_f32 v2, v72, v7, neg(0) op_sel_hi:[1,0,0]        // 00000094A258: CC200002 8A020F48
	v_fma_mix_f32 v7, v73, v9, neg(0) op_sel_hi:[1,0,0]        // 00000094A260: CC200007 8A021349
	s_waitcnt vmcnt(0)                                         // 00000094A268: BF8903F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000094A26C: BF870193
	v_fma_mix_f32 v0, v94, v0, neg(0) op_sel_hi:[1,0,0]        // 00000094A270: CC200000 8A02015E
	v_fma_mix_f32 v9, v8, v68, v2 op_sel_hi:[0,1,0]            // 00000094A278: CC200009 140A8908
	s_delay_alu instid0(VALU_DEP_3)                            // 00000094A280: BF870003
	v_fma_mix_f32 v10, v6, v69, v7 op_sel_hi:[0,1,0]           // 00000094A284: CC20000A 141E8B06
	v_fma_mix_f32 v2, v8, v68, -v2 op_sel_hi:[0,1,0]           // 00000094A28C: CC200002 940A8908
	v_fma_mix_f32 v6, v6, v69, -v7 op_sel_hi:[0,1,0]           // 00000094A294: CC200006 941E8B06
	v_fma_mix_f32 v11, v4, v64, v0 op_sel_hi:[0,1,0]           // 00000094A29C: CC20000B 14028104
	v_add_f32_e32 v7, v5, v9                                   // 00000094A2A4: 060E1305
	v_fma_mix_f32 v0, v4, v64, -v0 op_sel_hi:[0,1,0]           // 00000094A2A8: CC200000 94028104
	v_dual_sub_f32 v4, v5, v9 :: v_dual_add_f32 v5, v3, v2     // 00000094A2B0: C9481305 04040503
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000094A2B8: BF870224
	v_add_f32_e32 v8, v10, v11                                 // 00000094A2BC: 0610170A
	v_dual_sub_f32 v2, v3, v2 :: v_dual_sub_f32 v9, v10, v11   // 00000094A2C0: C94A0503 0208170A
	v_add_f32_e32 v10, v6, v0                                  // 00000094A2C8: 06140106
	v_sub_f32_e32 v0, v6, v0                                   // 00000094A2CC: 08000106
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000094A2D0: BF870224
	v_add_f32_e32 v3, v7, v8                                   // 00000094A2D4: 06061107
	v_sub_f32_e32 v6, v7, v8                                   // 00000094A2D8: 080C1107
	v_add_f32_e32 v8, v5, v10                                  // 00000094A2DC: 06101505
	v_sub_f32_e32 v10, v5, v10                                 // 00000094A2E0: 08141505
	s_delay_alu instid0(VALU_DEP_4)                            // 00000094A2E4: BF870004
	v_mov_b32_dpp v7, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000094A2E8: 7E0E02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 00000094A2F0: D5010003 20020703
	v_add_f32_e32 v5, v4, v9                                   // 00000094A2F8: 060A1304
	v_sub_f32_e32 v9, v4, v9                                   // 00000094A2FC: 08121304
	v_mov_b32_dpp v4, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000094A300: 7E0802FA FF016108
	v_mov_b32_dpp v14, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000094A308: 7E1C02FA FF016106
	v_add_f32_e32 v3, v3, v7                                   // 00000094A310: 06060F03
	v_cndmask_b32_e64 v7, -v8, v8, s0                          // 00000094A314: D5010007 20021108
	v_mov_b32_dpp v8, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000094A31C: 7E1002FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 00000094A324: D5010005 20020B05
	v_cndmask_b32_e64 v15, -v6, v6, s0                         // 00000094A32C: D501000F 20020D06
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000094A334: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 00000094A33C: D5010003 200A0703
	v_add_f32_e32 v4, v7, v4                                   // 00000094A344: 06080907
	v_add_f32_e32 v5, v5, v8                                   // 00000094A348: 060A1105
	v_add_f32_e32 v7, v2, v0                                   // 00000094A34C: 060E0102
	v_sub_f32_e32 v8, v2, v0                                   // 00000094A350: 08100102
	v_add_f32_e32 v0, v3, v11                                  // 00000094A354: 06001703
	v_mov_b32_dpp v2, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000094A358: 7E0402FA FF016204
	v_cndmask_b32_e64 v3, -v4, v4, s2                          // 00000094A360: D5010003 200A0904
	v_mov_b32_dpp v4, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000094A368: 7E0802FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 00000094A370: D5010005 200A0B05
	v_mov_b32_dpp v11, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000094A378: 7E1602FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 00000094A380: D5010007 20020F07
	v_add_f32_e32 v2, v3, v2                                   // 00000094A388: 06040503
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000094A38C: 7E2002FA FF016108
	v_add_f32_e32 v4, v5, v4                                   // 00000094A394: 06080905
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 00000094A398: D5010008 20021108
	v_add_f32_e32 v5, v7, v11                                  // 00000094A3A0: 060A1707
	v_mov_b32_dpp v7, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000094A3A4: 7E0E02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 00000094A3AC: D5010002 20120502
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000094A3B4: 7E1602FA FF016404
	v_cndmask_b32_e64 v12, -v4, v4, s4                         // 00000094A3BC: D501000C 20120904
	v_mov_b32_dpp v13, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000094A3C4: 7E1A02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 00000094A3CC: D5010005 200A0B05
	v_add_f32_e32 v4, v2, v7                                   // 00000094A3D4: 06080F02
	v_add_f32_e32 v8, v8, v16                                  // 00000094A3D8: 06102108
	v_dual_add_f32 v6, v12, v11 :: v_dual_add_f32 v11, v15, v14// 00000094A3DC: C908170C 060A1D0F
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000094A3E4: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 00000094A3EC: D501000A 2002150A
	v_mov_b32_dpp v15, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000094A3F4: 7E1E02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 00000094A3FC: D5010009 20021309
	v_add_f32_e32 v7, v5, v13                                  // 00000094A404: 060E1B05
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000094A408: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 00000094A410: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000094A418: BF870234
	v_dual_add_f32 v10, v10, v14 :: v_dual_add_f32 v9, v9, v15 // 00000094A41C: C9081D0A 0A081F09
	v_mov_b32_dpp v15, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000094A424: 7E1E02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 00000094A42C: D5010008 200A1108
	v_add_f32_e32 v11, v11, v13                                // 00000094A434: 06161B0B
	s_delay_alu instid0(VALU_DEP_4)                            // 00000094A438: BF870004
	v_mov_b32_dpp v13, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000094A43C: 7E1A02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 00000094A444: D501000A 200A150A
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000094A44C: 7E1C02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 00000094A454: D5010009 200A1309
	v_add_f32_e32 v8, v8, v15                                  // 00000094A45C: 06101F08
	v_mov_b32_dpp v3, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000094A460: 7E0602FA FF016400
	v_add_f32_e32 v10, v10, v13                                // 00000094A468: 06141B0A
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 00000094A46C: D5010000 20120100
	v_add_f32_e32 v9, v9, v14                                  // 00000094A474: 06121D09
	v_mov_b32_dpp v12, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000094A478: 7E1802FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 00000094A480: D5010007 20120F07
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000094A488: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 00000094A490: D501000B 2012170B
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000094A498: 7E1C02FA FF01640A
	v_cndmask_b32_e64 v15, -v10, v10, s4                       // 00000094A4A0: D501000F 2012150A
	v_mov_b32_dpp v16, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000094A4A8: 7E2002FA FF016409
	v_cndmask_b32_e64 v17, -v9, v9, s4                         // 00000094A4B0: D5010011 20121309
	v_mov_b32_dpp v18, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000094A4B8: 7E2402FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 00000094A4C0: D5010008 20121108
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v9, v7, v12    // 00000094A4C8: C9080700 00081907
	v_add_f32_e32 v10, v11, v13                                // 00000094A4D0: 06141B0B
	v_add_f32_e32 v11, v15, v14                                // 00000094A4D4: 06161D0F
	v_add_f32_e32 v13, v17, v16                                // 00000094A4D8: 061A2111
	v_add_f32_e32 v15, v8, v18                                 // 00000094A4DC: 061E2508
	v_mov_b32_dpp v2, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000094A4E0: 7E0402FA FF016800
	v_mov_b32_dpp v3, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000094A4E8: 7E0602FA FF016804
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000094A4F0: 7E0A02FA FF016806
	v_mov_b32_dpp v7, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000094A4F8: 7E0E02FA FF016809
	v_mov_b32_dpp v8, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000094A500: 7E1002FA FF01680A
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000094A508: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000094A510: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000094A518: 7E2002FA FF01680F
	s_mov_b32 s0, 0x3db504f3                                   // 00000094A520: BE8000FF 3DB504F3
	s_and_b32 exec_lo, exec_lo, s1                             // 00000094A528: 8B7E017E
	s_cbranch_execz 65                                         // 00000094A52C: BFA50041 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x3a34>
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 00000094A530: D501000F 200E1F0F
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 00000094A538: D5010000 200E0100
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 00000094A540: D5010004 200E0904
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 00000094A548: D5010006 200E0D06
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 00000094A550: D5010009 200E1309
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 00000094A558: D501000D 200E1B0D
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 00000094A560: D501000A 200E150A
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 00000094A568: D501000B 200E170B
	v_dual_add_f32 v15, v15, v16 :: v_dual_add_f32 v0, v0, v2  // 00000094A570: C908210F 0F000500
	v_add_f32_e32 v3, v4, v3                                   // 00000094A578: 06060704
	v_add_f32_e32 v5, v6, v5                                   // 00000094A57C: 060A0B06
	v_add_f32_e32 v7, v9, v7                                   // 00000094A580: 060E0F09
	s_mul_i32 s1, s20, 0x500                                   // 00000094A584: 9601FF14 00000500
	v_dual_add_f32 v13, v13, v14 :: v_dual_add_f32 v8, v10, v8 // 00000094A58C: C9081D0D 0D08110A
	s_mul_hi_i32 s2, s20, 0x500                                // 00000094A594: 9702FF14 00000500
	v_add_f32_e32 v11, v11, v12                                // 00000094A59C: 0616190B
	s_add_u32 s1, s14, s1                                      // 00000094A5A0: 8001010E
	v_fma_mixlo_f16 v0, v0, s0, 0                              // 00000094A5A4: CC210000 02000100
	s_addc_u32 s3, s15, s2                                     // 00000094A5AC: 8203020F
	v_fma_mixhi_f16 v0, v3, s0, 0                              // 00000094A5B0: CC220000 02000103
	s_add_u32 s2, s1, s10                                      // 00000094A5B8: 80020A01
	v_fma_mixlo_f16 v2, v5, s0, 0                              // 00000094A5BC: CC210002 02000105
	s_addc_u32 s3, s3, s11                                     // 00000094A5C4: 82030B03
	v_fma_mixhi_f16 v2, v7, s0, 0                              // 00000094A5C8: CC220002 02000107
	v_fma_mixlo_f16 v3, v8, s0, 0                              // 00000094A5D0: CC210003 02000108
	v_fma_mixhi_f16 v3, v11, s0, 0                             // 00000094A5D8: CC220003 0200010B
	v_fma_mixlo_f16 v4, v13, s0, 0                             // 00000094A5E0: CC210004 0200010D
	v_fma_mixhi_f16 v4, v15, s0, 0                             // 00000094A5E8: CC220004 0200010F
	s_clause 0x7                                               // 00000094A5F0: BF850007
	global_store_b16 v1, v0, s[2:3]                            // 00000094A5F4: DC660000 00020001
	global_store_d16_hi_b16 v1, v0, s[2:3] offset:32           // 00000094A5FC: DC960020 00020001
	global_store_b16 v1, v2, s[2:3] offset:64                  // 00000094A604: DC660040 00020201
	global_store_d16_hi_b16 v1, v2, s[2:3] offset:96           // 00000094A60C: DC960060 00020201
	global_store_b16 v1, v3, s[2:3] offset:128                 // 00000094A614: DC660080 00020301
	global_store_d16_hi_b16 v1, v3, s[2:3] offset:160          // 00000094A61C: DC9600A0 00020301
	global_store_b16 v1, v4, s[2:3] offset:192                 // 00000094A624: DC6600C0 00020401
	global_store_d16_hi_b16 v1, v4, s[2:3] offset:224          // 00000094A62C: DC9600E0 00020401
	s_nop 0                                                    // 00000094A634: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000094A638: BFB60003
	s_endpgm                                                   // 00000094A63C: BFB00000
		...

