0000000000727e00 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi16ELi1ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi16ELi1ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000727E00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000727E04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000727E0C: F4040300 F8000020
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000727E14: 32020084
	s_mov_b32 s3, 0                                            // 000000727E18: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 15, v0        // 000000727E1C: CA240080 100E008F
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000727E24: 84808402
	.long 0x7e2c3880                                           // 000000727E28: 7E2C3880
	v_or_b32_e32 v9, s0, v1                                    // 000000727E2C: 38120200
	v_dual_mov_b32 v10, s1 :: v_dual_mov_b32 v3, 0             // 000000727E30: CA100001 0A020080
	v_lshlrev_b32_e32 v11, 4, v15                              // 000000727E38: 30161E84
	s_waitcnt lgkmcnt(0)                                       // 000000727E3C: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 000000727E40: 86009F0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000727E44: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 000000727E48: 7CA8120C
	s_lshr_b32 s0, s0, 28                                      // 000000727E4C: 85009C00
	s_add_u32 s2, s10, s0                                      // 000000727E50: 8002000A
	s_addc_u32 s3, s11, 0                                      // 000000727E54: 8203800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000727E58: BF870009
	s_ashr_i64 s[2:3], s[2:3], 4                               // 000000727E5C: 86828402
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000727E60: 02021280
	s_add_u32 s0, s10, s2                                      // 000000727E64: 8000020A
	v_cndmask_b32_e64 v2, 0, s1, vcc_lo                        // 000000727E68: D5010002 01A80280
	s_addc_u32 s1, s11, s3                                     // 000000727E70: 8201030B
	s_add_u32 s0, s0, 15                                       // 000000727E74: 80008F00
	s_addc_u32 s1, s1, 0                                       // 000000727E78: 82018001
	s_and_b32 s0, s0, -16                                      // 000000727E7C: 8B00D000
	.long 0xd72c0004                                           // 000000727E80: D72C0004
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 000000727E84: 02000301
	.long 0xd72c0007                                           // 000000727E88: D72C0007
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 000000727E8C: 02000102
	v_mad_u64_u32 v[5:6], null, v1, s0, 0                      // 000000727E90: D6FE7C05 02000101
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 000000727E98: CA100080 01020080
	.long 0xd4440000                                           // 000000727EA0: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 000000727EA4: 02021E02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000727EA8: BF870213
	v_add3_u32 v6, v6, v4, v7                                  // 000000727EAC: D6550006 041E0906
	.long 0xd7000111                                           // 000000727EB4: D7000111
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000727EB8: 02020A04
	v_mov_b32_e32 v4, 0                                        // 000000727EBC: 7E080280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000727EC0: BF870003
	v_add_co_ci_u32_e64 v18, null, s5, v6, s1                  // 000000727EC4: D5207C12 00060C05
	s_and_saveexec_b32 s3, s0                                  // 000000727ECC: BE832000
	s_cbranch_execz 21                                         // 000000727ED0: BFA50015 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi16ELi1ELb1EEEvPKhPKtPvll+0x128>
	v_lshlrev_b32_e32 v1, 4, v15                               // 000000727ED4: 30021E84
	.long 0xd7000103                                           // 000000727ED8: D7000103
	v_cndmask_b32_e32 v0, v17, v10, vcc_lo                     // 000000727EDC: 02001511
	v_and_b32_e32 v7, 14, v0                                   // 000000727EE0: 360E008E
	v_add_co_ci_u32_e64 v4, null, s11, v18, s1                 // 000000727EE4: D5207C04 0006240B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000727EEC: BF870094
	.long 0xd7000101                                           // 000000727EF0: D7000101
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000727EF4: 02020311
	v_add_co_ci_u32_e64 v2, null, 0, v18, s1                   // 000000727EF8: D5207C02 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000727F00: BF870094
	.long 0xd7000107                                           // 000000727F04: D7000107
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 000000727F08: 02020F03
	v_add_co_ci_u32_e64 v8, null, 0, v4, s1                    // 000000727F0C: D5207C08 00060880
	s_clause 0x1                                               // 000000727F14: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 000000727F18: DC5E0000 017C0001
	global_load_d16_b16 v22, v[7:8], off                       // 000000727F20: DC820000 167C0007
	s_or_b32 exec_lo, exec_lo, s3                              // 000000727F28: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 000000727F2C: CA100080 13140080
	s_and_saveexec_b32 s3, s0                                  // 000000727F34: BE832000
	s_cbranch_execz 356                                        // 000000727F38: BFA50164 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi16ELi1ELb1EEEvPKhPKtPvll+0x6cc>
	v_and_or_b32 v0, v0, 14, 16                                // 000000727F3C: D6570000 02411D00
	.long 0xd7000005                                           // 000000727F44: D7000005
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000727F48: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000727F4C: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s11, v6, s0                  // 000000727F50: D5207C06 00020C0B
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v21, v15           // 000000727F58: CA100080 0C14010F
	.long 0xd7000000                                           // 000000727F60: D7000000
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 000000727F64: 02020105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000727F68: BF870191
	v_add_co_ci_u32_e64 v5, null, 0, v6, s0                    // 000000727F6C: D5207C05 00020C80
	v_mov_b32_e32 v20, v12                                     // 000000727F74: 7E28030C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000727F78: BF870093
	.long 0xd700000d                                           // 000000727F7C: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 000000727F80: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v5, s0                  // 000000727F84: D5207C0E 00020A05
	v_mov_b32_e32 v19, v12                                     // 000000727F8C: 7E26030C
	v_mov_b32_e32 v16, v12                                     // 000000727F90: 7E20030C
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000727F94: 8484820A
	s_mov_b32 s14, 0                                           // 000000727F98: BE8E0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000727F9C: 848A810A
	s_branch 300                                               // 000000727FA0: BFA0012C <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi16ELi1ELb1EEEvPKhPKtPvll+0x654>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000727FA4: 8C7E0F7E
	.long 0xd73c0018                                           // 000000727FA8: D73C0018
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000727FAC: 02021681
	v_bfe_i32 v11, v1, 0, 8                                    // 000000727FB0: D611000B 02210101
	v_bfe_i32 v48, v1, 8, 8                                    // 000000727FB8: D6110030 02211101
	v_bfe_i32 v49, v1, 16, 8                                   // 000000727FC0: D6110031 02212101
	.long 0x7f2c3880                                           // 000000727FC8: 7F2C3880
	v_ashrrev_i32_e32 v1, 24, v1                               // 000000727FCC: 34020298
	.long 0xd7000124                                           // 000000727FD0: D7000124
	v_cndmask_b32_e32 v1, s6, v24, vcc_lo                      // 000000727FD4: 02023006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000727FD8: BF8701A1
	v_add_co_ci_u32_e64 v37, null, s7, v25, s1                 // 000000727FDC: D5207C25 00063207
	v_cvt_f32_i32_e32 v11, v11                                 // 000000727FE4: 7E160B0B
	.long 0xd7000128                                           // 000000727FE8: D7000128
	v_cndmask_b32_e32 v0, v36, v10, vcc_lo                     // 000000727FEC: 02001524
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000727FF0: BF8700A1
	v_add_co_ci_u32_e64 v41, null, s11, v37, s1                // 000000727FF4: D5207C29 00064A0B
	.long 0xd700012c                                           // 000000727FFC: D700012C
	v_cndmask_b32_e32 v0, v36, v4, vcc_lo                      // 000000728000: 02000924
	v_add_co_ci_u32_e64 v45, null, s5, v37, s1                 // 000000728004: D5207C2D 00064A05
	s_clause 0x5                                               // 00000072800C: BF850005
	global_load_b128 v[24:27], v[36:37], off                   // 000000728010: DC5E0000 187C0024
	global_load_b128 v[28:31], v[40:41], off                   // 000000728018: DC5E0000 1C7C0028
	global_load_b128 v[32:35], v[44:45], off                   // 000000728020: DC5E0000 207C002C
	global_load_b128 v[36:39], v[36:37], off offset:16         // 000000728028: DC5E0010 247C0024
	global_load_b128 v[40:43], v[40:41], off offset:16         // 000000728030: DC5E0010 287C0028
	global_load_b128 v[44:47], v[44:45], off offset:16         // 000000728038: DC5E0010 2C7C002C
	v_bfe_i32 v50, v2, 0, 8                                    // 000000728040: D6110032 02210102
	v_cvt_f32_i32_e32 v48, v48                                 // 000000728048: 7E600B30
	v_cvt_f32_i32_e32 v49, v49                                 // 00000072804C: 7E620B31
	v_fma_mix_f32 v11, v22, v11, neg(0) op_sel_hi:[1,0,0]      // 000000728050: CC20000B 8A021716
	v_bfe_i32 v51, v2, 8, 8                                    // 000000728058: D6110033 02211102
	v_bfe_i32 v52, v2, 16, 8                                   // 000000728060: D6110034 02212102
	v_ashrrev_i32_e32 v2, 24, v2                               // 000000728068: 34040498
	v_bfe_i32 v53, v3, 0, 8                                    // 00000072806C: D6110035 02210103
	v_bfe_i32 v54, v3, 8, 8                                    // 000000728074: D6110036 02211103
	v_bfe_i32 v55, v3, 16, 8                                   // 00000072807C: D6110037 02212103
	v_ashrrev_i32_e32 v3, 24, v3                               // 000000728084: 34060698
	v_bfe_i32 v56, v4, 0, 8                                    // 000000728088: D6110038 02210104
	v_bfe_i32 v57, v4, 8, 8                                    // 000000728090: D6110039 02211104
	v_bfe_i32 v58, v4, 16, 8                                   // 000000728098: D611003A 02212104
	v_ashrrev_i32_e32 v4, 24, v4                               // 0000007280A0: 34080898
	v_cvt_f32_i32_e32 v1, v1                                   // 0000007280A4: 7E020B01
	v_cvt_f32_i32_e32 v50, v50                                 // 0000007280A8: 7E640B32
	v_fma_mix_f32 v48, v22, v48, neg(0) op_sel_hi:[1,0,0]      // 0000007280AC: CC200030 8A026116
	v_fma_mix_f32 v49, v22, v49, neg(0) op_sel_hi:[1,0,0]      // 0000007280B4: CC200031 8A026316
	v_bfe_u32 v63, v11, 16, 1                                  // 0000007280BC: D610003F 0205210B
	v_cvt_f32_i32_e32 v51, v51                                 // 0000007280C4: 7E660B33
	v_cvt_f32_i32_e32 v52, v52                                 // 0000007280C8: 7E680B34
	v_cvt_f32_i32_e32 v2, v2                                   // 0000007280CC: 7E040B02
	v_cvt_f32_i32_e32 v53, v53                                 // 0000007280D0: 7E6A0B35
	v_cvt_f32_i32_e32 v54, v54                                 // 0000007280D4: 7E6C0B36
	v_cvt_f32_i32_e32 v55, v55                                 // 0000007280D8: 7E6E0B37
	v_cvt_f32_i32_e32 v3, v3                                   // 0000007280DC: 7E060B03
	v_cvt_f32_i32_e32 v56, v56                                 // 0000007280E0: 7E700B38
	v_cvt_f32_i32_e32 v57, v57                                 // 0000007280E4: 7E720B39
	v_cvt_f32_i32_e32 v58, v58                                 // 0000007280E8: 7E740B3A
	v_cvt_f32_i32_e32 v4, v4                                   // 0000007280EC: 7E080B04
	v_fma_mix_f32 v1, v22, v1, neg(0) op_sel_hi:[1,0,0]        // 0000007280F0: CC200001 8A020316
	v_fma_mix_f32 v50, v22, v50, neg(0) op_sel_hi:[1,0,0]      // 0000007280F8: CC200032 8A026516
	v_bfe_u32 v64, v48, 16, 1                                  // 000000728100: D6100040 02052130
	v_bfe_u32 v65, v49, 16, 1                                  // 000000728108: D6100041 02052131
	v_add3_u32 v11, v11, v63, 0x7fff                           // 000000728110: D655000B 03FE7F0B 00007FFF
	v_fma_mix_f32 v51, v22, v51, neg(0) op_sel_hi:[1,0,0]      // 00000072811C: CC200033 8A026716
	v_fma_mix_f32 v52, v22, v52, neg(0) op_sel_hi:[1,0,0]      // 000000728124: CC200034 8A026916
	v_fma_mix_f32 v2, v22, v2, neg(0) op_sel_hi:[1,0,0]        // 00000072812C: CC200002 8A020516
	v_fma_mix_f32 v53, v22, v53, neg(0) op_sel_hi:[1,0,0]      // 000000728134: CC200035 8A026B16
	v_fma_mix_f32 v54, v22, v54, neg(0) op_sel_hi:[1,0,0]      // 00000072813C: CC200036 8A026D16
	v_fma_mix_f32 v55, v22, v55, neg(0) op_sel_hi:[1,0,0]      // 000000728144: CC200037 8A026F16
	v_fma_mix_f32 v3, v22, v3, neg(0) op_sel_hi:[1,0,0]        // 00000072814C: CC200003 8A020716
	v_fma_mix_f32 v56, v22, v56, neg(0) op_sel_hi:[1,0,0]      // 000000728154: CC200038 8A027116
	v_fma_mix_f32 v57, v22, v57, neg(0) op_sel_hi:[1,0,0]      // 00000072815C: CC200039 8A027316
	v_fma_mix_f32 v58, v22, v58, neg(0) op_sel_hi:[1,0,0]      // 000000728164: CC20003A 8A027516
	v_fma_mix_f32 v4, v22, v4, neg(0) op_sel_hi:[1,0,0]        // 00000072816C: CC200004 8A020916
	v_bfe_u32 v66, v1, 16, 1                                   // 000000728174: D6100042 02052101
	v_bfe_u32 v67, v50, 16, 1                                  // 00000072817C: D6100043 02052132
	v_add3_u32 v48, v48, v64, 0x7fff                           // 000000728184: D6550030 03FE8130 00007FFF
	v_add3_u32 v49, v49, v65, 0x7fff                           // 000000728190: D6550031 03FE8331 00007FFF
	.long 0x7e2c398b                                           // 00000072819C: 7E2C398B
	.long 0x7f763996                                           // 0000007281A0: 7F763996
	v_bfe_u32 v68, v51, 16, 1                                  // 0000007281A4: D6100044 02052133
	v_bfe_u32 v69, v52, 16, 1                                  // 0000007281AC: D6100045 02052134
	v_add3_u32 v1, v1, v66, 0x7fff                             // 0000007281B4: D6550001 03FE8501 00007FFF
	v_add3_u32 v50, v50, v67, 0x7fff                           // 0000007281C0: D6550032 03FE8732 00007FFF
	.long 0x7e7639b1                                           // 0000007281CC: 7E7639B1
	v_and_or_b32 v48, 0xffff0000, v48, v22                     // 0000007281D0: D6570030 045A60FF FFFF0000
	v_bfe_u32 v70, v2, 16, 1                                   // 0000007281DC: D6100046 02052102
	v_bfe_u32 v71, v53, 16, 1                                  // 0000007281E4: D6100047 02052135
	v_add3_u32 v51, v51, v68, 0x7fff                           // 0000007281EC: D6550033 03FE8933 00007FFF
	v_add3_u32 v52, v52, v69, 0x7fff                           // 0000007281F8: D6550034 03FE8B34 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v59                       // 000000728204: D6570001 04EE02FF FFFF0000
	.long 0x7e2c39b2                                           // 000000728210: 7E2C39B2
	.long 0x7f783996                                           // 000000728214: 7F783996
	v_bfe_u32 v72, v54, 16, 1                                  // 000000728218: D6100048 02052136
	v_bfe_u32 v73, v55, 16, 1                                  // 000000728220: D6100049 02052137
	v_add3_u32 v2, v2, v70, 0x7fff                             // 000000728228: D6550002 03FE8D02 00007FFF
	v_add3_u32 v53, v53, v71, 0x7fff                           // 000000728234: D6550035 03FE8F35 00007FFF
	.long 0x7e7839b4                                           // 000000728240: 7E7839B4
	v_bfe_u32 v74, v3, 16, 1                                   // 000000728244: D610004A 02052103
	v_bfe_u32 v75, v56, 16, 1                                  // 00000072824C: D610004B 02052138
	v_add3_u32 v54, v54, v72, 0x7fff                           // 000000728254: D6550036 03FE9136 00007FFF
	v_add3_u32 v55, v55, v73, 0x7fff                           // 000000728260: D6550037 03FE9337 00007FFF
	v_and_or_b32 v2, 0xffff0000, v2, v60                       // 00000072826C: D6570002 04F204FF FFFF0000
	.long 0x7f7a3996                                           // 000000728278: 7F7A3996
	v_bfe_u32 v76, v57, 16, 1                                  // 00000072827C: D610004C 02052139
	v_bfe_u32 v77, v58, 16, 1                                  // 000000728284: D610004D 0205213A
	v_add3_u32 v3, v3, v74, 0x7fff                             // 00000072828C: D6550003 03FE9503 00007FFF
	v_add3_u32 v11, v56, v75, 0x7fff                           // 000000728298: D655000B 03FE9738 00007FFF
	.long 0x7e7a39b7                                           // 0000007282A4: 7E7A39B7
	v_bfe_u32 v78, v4, 16, 1                                   // 0000007282A8: D610004E 02052104
	v_add3_u32 v49, v57, v76, 0x7fff                           // 0000007282B0: D6550031 03FE9939 00007FFF
	v_add3_u32 v56, v58, v77, 0x7fff                           // 0000007282BC: D6550038 03FE9B3A 00007FFF
	.long 0x7f7c3996                                           // 0000007282C8: 7F7C3996
	s_and_b32 s1, exec_lo, s0                                  // 0000007282CC: 8B01007E
	v_add3_u32 v4, v4, v78, 0x7fff                             // 0000007282D0: D6550004 03FE9D04 00007FFF
	.long 0xd700000d                                           // 0000007282DC: D700000D
	v_cndmask_b32_e32 v0, v13, v144, vcc_lo                    // 0000007282E0: 0201210D
	.long 0x7e7c39b8                                           // 0000007282E4: 7E7C39B8
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 0000007282E8: D5207C0E 00021C80
	s_or_b32 s14, s1, s14                                      // 0000007282F0: 8C0E0E01
	s_waitcnt vmcnt(5)                                         // 0000007282F4: BF8917F7
	v_dot2_f32_bf16 v24, v24, v48, 0                           // 0000007282F8: CC1A4018 1A026118
	s_waitcnt vmcnt(4)                                         // 000000728300: BF8913F7
	v_dot2_f32_bf16 v28, v28, v48, 0                           // 000000728304: CC1A401C 1A02611C
	s_waitcnt vmcnt(3)                                         // 00000072830C: BF890FF7
	v_dot2_f32_bf16 v32, v32, v48, 0                           // 000000728310: CC1A4020 1A026120
	v_and_or_b32 v48, 0xffff0000, v51, v22                     // 000000728318: D6570030 045A66FF FFFF0000
	.long 0x7e2c39b5                                           // 000000728324: 7E2C39B5
	v_dot2_f32_bf16 v24, v25, v1, v24                          // 000000728328: CC1A4018 1C620319
	v_dot2_f32_bf16 v25, v29, v1, v28                          // 000000728330: CC1A4019 1C72031D
	v_dot2_f32_bf16 v1, v33, v1, v32                           // 000000728338: CC1A4001 1C820321
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000728340: BF870193
	v_dot2_f32_bf16 v24, v26, v48, v24                         // 000000728344: CC1A4018 1C62611A
	v_dot2_f32_bf16 v25, v30, v48, v25                         // 00000072834C: CC1A4019 1C66611E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000728354: BF870003
	v_dot2_f32_bf16 v1, v34, v48, v1                           // 000000728358: CC1A4001 1C066122
	v_and_or_b32 v26, 0xffff0000, v54, v22                     // 000000728360: D657001A 045A6CFF FFFF0000
	.long 0x7e2c398b                                           // 00000072836C: 7E2C398B
	v_dot2_f32_bf16 v24, v27, v2, v24                          // 000000728370: CC1A4018 1C62051B
	v_dot2_f32_bf16 v25, v31, v2, v25                          // 000000728378: CC1A4019 1C66051F
	v_dot2_f32_bf16 v1, v35, v2, v1                            // 000000728380: CC1A4001 1C060523
	v_and_or_b32 v2, 0xffff0000, v3, v61                       // 000000728388: D6570002 04F606FF FFFF0000
	v_and_or_b32 v22, 0xffff0000, v49, v22                     // 000000728394: D6570016 045A62FF FFFF0000
	s_waitcnt vmcnt(2)                                         // 0000007283A0: BF890BF7
	v_dot2_f32_bf16 v3, v36, v26, v24                          // 0000007283A4: CC1A4003 1C623524
	s_waitcnt vmcnt(1)                                         // 0000007283AC: BF8907F7
	v_dot2_f32_bf16 v11, v40, v26, v25                         // 0000007283B0: CC1A400B 1C663528
	s_waitcnt vmcnt(0)                                         // 0000007283B8: BF8903F7
	v_dot2_f32_bf16 v1, v44, v26, v1                           // 0000007283BC: CC1A4001 1C06352C
	v_dot2_f32_bf16 v3, v37, v2, v3                            // 0000007283C4: CC1A4003 1C0E0525
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007283CC: BF870193
	v_dot2_f32_bf16 v24, v41, v2, v11                          // 0000007283D0: CC1A4018 1C2E0529
	v_dot2_f32_bf16 v1, v45, v2, v1                            // 0000007283D8: CC1A4001 1C06052D
	v_mov_b32_e32 v11, v23                                     // 0000007283E0: 7E160317
	v_and_or_b32 v2, 0xffff0000, v4, v62                       // 0000007283E4: D6570002 04FA08FF FFFF0000
	v_dot2_f32_bf16 v23, v38, v22, v3                          // 0000007283F0: CC1A4017 1C0E2D26
	v_dot2_f32_bf16 v24, v42, v22, v24                         // 0000007283F8: CC1A4018 1C622D2A
	v_dot2_f32_bf16 v1, v46, v22, v1                           // 000000728400: CC1A4001 1C062D2E
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 000000728408: CA100108 04020107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000728410: BF870214
	v_dot2_f32_bf16 v7, v39, v2, v23                           // 000000728414: CC1A4007 1C5E0527
	v_dot2_f32_bf16 v8, v43, v2, v24                           // 00000072841C: CC1A4008 1C62052B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000728424: BF8701A4
	v_dot2_f32_bf16 v22, v47, v2, v1                           // 000000728428: CC1A4016 1C06052F
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 000000728430: CA100106 02000105
	v_dual_add_f32 v20, v20, v7 :: v_dual_add_f32 v19, v19, v8 // 000000728438: C9080F14 14121113
	s_delay_alu instid0(VALU_DEP_3)                            // 000000728440: BF870003
	v_add_f32_e32 v16, v16, v22                                // 000000728444: 06202D10
	.long 0x7e2c3900                                           // 000000728448: 7E2C3900
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 00000072844C: 917E0E7E
	s_cbranch_execz 29                                         // 000000728450: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi16ELi1ELb1EEEvPKhPKtPvll+0x6c8>
	v_add_nc_u32_e32 v21, 16, v21                              // 000000728454: 4A2A2A90
	v_add_nc_u32_e32 v23, 0x100, v11                           // 000000728458: 4A2E16FF 00000100
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000728460: BF8704A2
	.long 0xd4430000                                           // 000000728464: D4430000
	v_cndmask_b32_e32 v1, s2, v21, vcc_lo                      // 000000728468: 02022A02
	s_and_saveexec_b32 s1, s0                                  // 00000072846C: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 000000728470: 8D01017E
	v_add_nc_u32_e32 v23, 0x100, v11                           // 000000728474: 4A2E16FF 00000100
	s_or_saveexec_b32 s15, s1                                  // 00000072847C: BE8F2201
	s_waitcnt vmcnt(0)                                         // 000000728480: BF8903F7
	.long 0x7e003916                                           // 000000728484: 7E003916
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v6, v2             // 000000728488: CA100101 05060102
	v_dual_mov_b32 v7, v3 :: v_dual_mov_b32 v8, v4             // 000000728490: CA100103 07080104
	s_xor_b32 exec_lo, exec_lo, s15                            // 000000728498: 8D7E0F7E
	s_cbranch_execz 65217                                      // 00000072849C: BFA5FEC1 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi16ELi1ELb1EEEvPKhPKtPvll+0x1a4>
	.long 0xd7000105                                           // 0000007284A0: D7000105
	v_cndmask_b32_e32 v1, v17, v23, vcc_lo                     // 0000007284A4: 02022F11
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007284A8: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v18, s1                   // 0000007284AC: D5207C06 00062480
	global_load_b128 v[5:8], v[5:6], off                       // 0000007284B4: DC5E0000 057C0005
	global_load_d16_b16 v0, v[13:14], off                      // 0000007284BC: DC820000 007C000D
	s_branch 65207                                             // 0000007284C4: BFA0FEB7 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi16ELi1ELb1EEEvPKhPKtPvll+0x1a4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007284C8: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007284CC: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007284D0: 8C7E037E
	.long 0xd71f0000                                           // 0000007284D4: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007284D8: 020100C1
	s_waitcnt vmcnt(1)                                         // 0000007284DC: BF8907F7
	v_xor_b32_e32 v1, 8, v0                                    // 0000007284E0: 3A020088
	v_xor_b32_e32 v4, 4, v0                                    // 0000007284E4: 3A080084
	v_xor_b32_e32 v7, 2, v0                                    // 0000007284E8: 3A0E0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007284EC: BF870093
	.long 0xd44c0000                                           // 0000007284F0: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000007284F4: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 0000007284F8: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000728500: BF870114
	.long 0xd44c0000                                           // 000000728504: D44C0000
	v_cndmask_b32_e32 v1, 32, v4, vcc_lo                       // 000000728508: 020208A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000072850C: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000728510: BF870002
	v_cndmask_b32_e64 v4, v0, v4, s0                           // 000000728514: D5010004 00020900
	.long 0xd44c0000                                           // 00000072851C: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 000000728520: 02020EA0
	ds_bpermute_b32 v2, v1, v20                                // 000000728524: DACC0000 02001401
	v_cndmask_b32_e64 v7, v0, v7, s0                           // 00000072852C: D5010007 00020F00
	s_waitcnt lgkmcnt(0)                                       // 000000728534: BF89FC07
	v_add_f32_e32 v2, v20, v2                                  // 000000728538: 06040514
	ds_bpermute_b32 v3, v1, v19                                // 00000072853C: DACC0000 03001301
	ds_bpermute_b32 v1, v1, v16                                // 000000728544: DACC0000 01001001
	s_waitcnt lgkmcnt(1)                                       // 00000072854C: BF89FC17
	v_dual_add_f32 v3, v19, v3 :: v_dual_lshlrev_b32 v4, 2, v4 // 000000728550: C9220713 03040882
	s_waitcnt lgkmcnt(0)                                       // 000000728558: BF89FC07
	v_add_f32_e32 v1, v16, v1                                  // 00000072855C: 06020310
	ds_bpermute_b32 v5, v4, v2                                 // 000000728560: DACC0000 05000204
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000728568: 300E0E82
	ds_bpermute_b32 v6, v4, v3                                 // 00000072856C: DACC0000 06000304
	ds_bpermute_b32 v4, v4, v1                                 // 000000728574: DACC0000 04000104
	s_waitcnt lgkmcnt(1)                                       // 00000072857C: BF89FC17
	v_dual_add_f32 v2, v2, v5 :: v_dual_add_f32 v3, v3, v6     // 000000728580: C9080B02 02020D03
	s_waitcnt lgkmcnt(0)                                       // 000000728588: BF89FC07
	v_add_f32_e32 v4, v1, v4                                   // 00000072858C: 06080901
	ds_bpermute_b32 v1, v7, v2                                 // 000000728590: DACC0000 01000207
	ds_bpermute_b32 v5, v7, v3                                 // 000000728598: DACC0000 05000307
	ds_bpermute_b32 v6, v7, v4                                 // 0000007285A0: DACC0000 06000407
	v_xor_b32_e32 v7, 1, v0                                    // 0000007285A8: 3A0E0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007285AC: BF870091
	.long 0xd44c0000                                           // 0000007285B0: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 0000007285B4: 02020EA0
	v_cndmask_b32_e64 v0, v0, v7, s0                           // 0000007285B8: D5010000 00020F00
	.long 0xd44a0000                                           // 0000007285C0: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 0000007285C4: 02021E80
	s_waitcnt lgkmcnt(2)                                       // 0000007285C8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007285CC: BF870002
	v_dual_add_f32 v0, v2, v1 :: v_dual_lshlrev_b32 v7, 2, v0  // 0000007285D0: C9220302 00060082
	s_and_b32 s0, s0, vcc_lo                                   // 0000007285D8: 8B006A00
	s_waitcnt lgkmcnt(1)                                       // 0000007285DC: BF89FC17
	v_add_f32_e32 v1, v3, v5                                   // 0000007285E0: 06020B03
	s_waitcnt lgkmcnt(0)                                       // 0000007285E4: BF89FC07
	v_add_f32_e32 v3, v4, v6                                   // 0000007285E8: 06060D04
	ds_bpermute_b32 v2, v7, v0                                 // 0000007285EC: DACC0000 02000007
	ds_bpermute_b32 v4, v7, v1                                 // 0000007285F4: DACC0000 04000107
	ds_bpermute_b32 v5, v7, v3                                 // 0000007285FC: DACC0000 05000307
	s_and_saveexec_b32 s1, s0                                  // 000000728604: BE812000
	s_cbranch_execz 31                                         // 000000728608: BFA5001F <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi16ELi1ELb1EEEvPKhPKtPvll+0x888>
	.long 0xd73c0006                                           // 00000072860C: D73C0006
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000728610: 02021282
	s_waitcnt lgkmcnt(2)                                       // 000000728614: BF89FC27
	v_add_f32_e32 v10, v0, v2                                  // 000000728618: 06140500
	s_waitcnt lgkmcnt(0)                                       // 00000072861C: BF89FC07
	v_dual_add_f32 v8, v3, v5 :: v_dual_add_f32 v9, v1, v4     // 000000728620: C9080B03 08080901
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000728628: 8480820C
	.long 0xd7006a00                                           // 00000072862C: D7006A00
	v_cndmask_b32_e32 v1, s8, v6, vcc_lo                       // 000000728630: 02020C08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000728634: BF870111
	v_add_co_ci_u32_e64 v1, null, s9, v7, vcc_lo               // 000000728638: D5207C01 01AA0E09
	.long 0xd7006a02                                           // 000000728640: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000728644: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000728648: BF8704A1
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 00000072864C: D5207C03 01AA0201
	s_lshl_b64 s[0:1], s[12:13], 3                             // 000000728654: 8480830C
	.long 0xd7006a04                                           // 000000728658: D7006A04
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000072865C: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000728660: BF870001
	v_add_co_ci_u32_e64 v5, null, s1, v1, vcc_lo               // 000000728664: D5207C05 01AA0201
	s_clause 0x2                                               // 00000072866C: BF850002
	global_store_b32 v[0:1], v10, off                          // 000000728670: DC6A0000 007C0A00
	global_store_b32 v[2:3], v9, off                           // 000000728678: DC6A0000 007C0902
	global_store_b32 v[4:5], v8, off                           // 000000728680: DC6A0000 007C0804
	s_endpgm                                                   // 000000728688: BFB00000
		...

