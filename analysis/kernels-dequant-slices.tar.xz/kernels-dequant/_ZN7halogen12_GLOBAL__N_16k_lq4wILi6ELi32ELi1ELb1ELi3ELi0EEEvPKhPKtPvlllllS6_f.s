0000000000857400 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000857400: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v1, 15, v0          // 000000857408: CA240080 0400008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000857410: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000857414: 86039F02
	s_delay_alu instid0(VALU_DEP_2)                            // 000000857418: BF870002
	v_dual_mov_b32 v16, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 00000085741C: CA220080 10000282
	s_lshl_b64 s[2:3], s[2:3], 3                               // 000000857424: 84828302
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 000000857428: BF870482
	v_dual_mov_b32 v9, s3 :: v_dual_and_b32 v2, 60, v2         // 00000085742C: CA240003 090204BC
	.long 0x7f183880                                           // 000000857434: 7F183880
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v15, 31, v0         // 000000857438: CA240080 060E009F
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v5, 0              // 000000857440: CA100080 1A040080
	s_waitcnt lgkmcnt(0)                                       // 000000857448: BF89FC07
	s_clause 0x1                                               // 00000085744C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000857450: DC520000 03040001
	global_load_b32 v7, v2, s[4:5]                             // 000000857458: DC520000 07040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000857460: 32020085
	s_add_u32 s14, s4, s14                                     // 000000857464: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 000000857468: 820F0F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000085746C: BF8704A1
	v_or_b32_e32 v8, s2, v1                                    // 000000857470: 38100202
	s_lshr_b32 s2, s11, 31                                     // 000000857474: 85029F0B
	s_add_u32 s20, s10, s2                                     // 000000857478: 8014020A
	s_addc_u32 s21, s11, 0                                     // 00000085747C: 8215800B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000857480: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 000000857484: 7CA8100C
	s_ashr_i32 s22, s11, 31                                    // 000000857488: 86169F0B
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 00000085748C: 02141080
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 000000857490: D501000E 01A80680
	s_ashr_i64 s[2:3], s[20:21], 1                             // 000000857498: 86828114
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000085749C: BF870481
	.long 0xd72c0013                                           // 0000008574A0: D72C0013
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 0000008574A4: 0200050E
	s_waitcnt vmcnt(1)                                         // 0000008574A8: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 0000008574AC: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 0000008574B4: BF8903F7
	v_bfe_u32 v18, v7, 16, 1                                   // 0000008574B8: D6100012 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008574C0: BF870112
	v_add3_u32 v3, v3, v11, 0x7fff                             // 0000008574C4: D6550003 03FE1703 00007FFF
	v_add3_u32 v7, v7, v18, 0x7fff                             // 0000008574D0: D6550007 03FE2507 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008574DC: BF8701B2
	.long 0x7e183983                                           // 0000008574E0: 7E183983
	.long 0xd72c0003                                           // 0000008574E4: D72C0003
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000008574E8: 02021C12
	v_lshlrev_b32_e32 v14, 2, v0                               // 0000008574EC: 301C0082
	v_and_or_b32 v12, 0xffff0000, v7, v12                      // 0000008574F0: D657000C 04320EFF FFFF0000
	v_mov_b32_e32 v7, 0                                        // 0000008574FC: 7E0E0280
	.long 0xd72c000d                                           // 000000857500: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 000000857504: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 000000857508: D6FE7C01 02021412
	.long 0xd72c0011                                           // 000000857510: D72C0011
	v_cndmask_b32_e32 v0, v10, v3, vcc_lo                      // 000000857514: 0200070A
	v_mad_u64_u32 v[10:11], null, v10, s2, s[14:15]            // 000000857518: D6FE7C0A 0038050A
	s_lshr_b32 s19, s22, 27                                    // 000000857520: 85139B16
	ds_store_b32 v14, v12                                      // 000000857524: D8340000 00000C0E
	s_add_u32 s14, s10, s19                                    // 00000085752C: 800E130A
	s_addc_u32 s15, s11, 0                                     // 000000857530: 820F800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000857534: BF870009
	s_lshr_b64 s[14:15], s[14:15], 5                           // 000000857538: 858E850E
	v_add3_u32 v0, v2, v3, v13                                 // 00000085753C: D6550000 04360702
	.long 0xd4440002                                           // 000000857544: D4440002
	v_cndmask_b32_e32 v1, s14, v15, vcc_lo                     // 000000857548: 02021E0E
	v_add3_u32 v17, v19, v11, v17                              // 00000085754C: D6550011 04461713
	s_waitcnt lgkmcnt(0)                                       // 000000857554: BF89FC07
	s_barrier                                                  // 000000857558: BFBD0000
	buffer_gl0_inv                                             // 00000085755C: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 000000857564: BE8F2002
	s_cbranch_execz 26                                         // 000000857568: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x1d4>
	s_add_u32 s3, s4, s16                                      // 00000085756C: 80031004
	s_addc_u32 s18, s5, s17                                    // 000000857570: 82121105
	v_lshlrev_b32_e32 v2, 1, v15                               // 000000857574: 30041E81
	.long 0xd7000303                                           // 000000857578: D7000303
	v_cndmask_b32_e32 v1, s3, v1, vcc_lo                       // 00000085757C: 02020203
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000857580: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s18, v0, s3                  // 000000857584: D5207C04 000E0012
	v_lshlrev_b32_e32 v5, 4, v15                               // 00000085758C: 300A1E84
	.long 0xd7000302                                           // 000000857590: D7000302
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 000000857594: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000857598: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s3                    // 00000085759C: D5207C03 000E0880
	.long 0xd7000304                                           // 0000008575A4: D7000304
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 0000008575A8: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008575AC: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s3                   // 0000008575B0: D5207C05 000E2280
	s_clause 0x1                                               // 0000008575B8: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 0000008575BC: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 0000008575C4: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 0000008575CC: BF8907F7
	v_cvt_f32_f16_e32 v26, v2                                  // 0000008575D0: 7E341702
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008575D4: 8C7E0F7E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 0000008575D8: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 0000008575E0: CA100080 14140080
	v_mov_b32_e32 v22, 0                                       // 0000008575E8: 7E2C0280
	s_and_saveexec_b32 s15, s2                                 // 0000008575EC: BE8F2002
	s_cbranch_execz 537                                        // 0000008575F0: BFA50219 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xa58>
	s_mul_i32 s2, s11, 6                                       // 0000008575F4: 9602860B
	s_mul_hi_u32 s3, s10, 6                                    // 0000008575F8: 9683860A
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 0000008575FC: CA220080 0C0A1E85
	s_add_i32 s20, s3, s2                                      // 000000857604: 81140203
	v_lshlrev_b32_e32 v2, 1, v15                               // 000000857608: 30041E81
	.long 0xd7000201                                           // 00000085760C: D7000201
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 000000857610: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000857614: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s2                  // 000000857618: D5207C00 000A0011
	v_mov_b32_e32 v21, v12                                     // 000000857620: 7E2A030C
	.long 0xd7000201                                           // 000000857624: D7000201
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000857628: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000085762C: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s2                    // 000000857630: D5207C00 000A0080
	v_lshl_or_b32 v23, v15, 4, 0x200                           // 000000857638: D6560017 03FD090F 00000200
	.long 0xd7000201                                           // 000000857644: D7000201
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000857648: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000085764C: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s2                   // 000000857650: D5207C00 000A0005
	v_dual_mov_b32 v24, v15 :: v_dual_mov_b32 v19, v12         // 000000857658: CA10010F 1812010C
	.long 0xd700020d                                           // 000000857660: D700020D
	v_cndmask_b32_e32 v0, v1, v192, vcc_lo                     // 000000857664: 02018101
	s_delay_alu instid0(VALU_DEP_1)                            // 000000857668: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s2                   // 00000085766C: D5207C0E 000A0080
	v_dual_mov_b32 v22, v12 :: v_dual_mov_b32 v25, v26         // 000000857674: CA10010C 1618011A
	v_mov_b32_e32 v20, v12                                     // 00000085767C: 7E28030C
	v_mov_b32_e32 v18, v12                                     // 000000857680: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 000000857684: 7E20030C
	s_lshl_b64 s[18:19], s[10:11], 2                           // 000000857688: 8492820A
	s_mul_i32 s17, s10, 6                                      // 00000085768C: 9611860A
	s_mov_b32 s16, 0                                           // 000000857690: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000857694: 8484810A
	s_branch 469                                               // 000000857698: BFA001D5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x9f0>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000085769C: 8C7E0A7E
	v_and_b32_e32 v27, 0xff, v4                                // 0000008576A0: 363608FF 000000FF
	s_and_b32 s2, exec_lo, s2                                  // 0000008576A8: 8B02027E
	v_add_nc_u32_e32 v23, 0x200, v23                           // 0000008576AC: 4A2E2EFF 00000200
	s_or_b32 s16, s2, s16                                      // 0000008576B4: 8C101002
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008576B8: BF8700B2
	v_lshlrev_b32_e32 v27, 2, v27                              // 0000008576BC: 30363682
	ds_load_b32 v43, v27                                       // 0000008576C0: D8D80000 2B00001B
	v_lshrrev_b32_e32 v27, 6, v4                               // 0000008576C8: 32360886
	v_and_b32_e32 v27, 0x3fc, v27                              // 0000008576CC: 363636FF 000003FC
	ds_load_b32 v44, v27                                       // 0000008576D4: D8D80000 2C00001B
	v_lshrrev_b32_e32 v27, 14, v4                              // 0000008576DC: 3236088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000008576E0: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008576E4: BF870112
	v_and_b32_e32 v27, 0x3fc, v27                              // 0000008576E8: 363636FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008576F0: 360808FF 000003FC
	ds_load_b32 v45, v27                                       // 0000008576F8: D8D80000 2D00001B
	ds_load_b32 v46, v4                                        // 000000857700: D8D80000 2E000004
	v_and_b32_e32 v4, 0xff, v5                                 // 000000857708: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000857710: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000857714: 30080882
	ds_load_b32 v47, v4                                        // 000000857718: D8D80000 2F000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 000000857720: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000857724: 360808FF 000003FC
	ds_load_b32 v48, v4                                        // 00000085772C: D8D80000 30000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 000000857734: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000857738: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000085773C: 360808FF 000003FC
	ds_load_b32 v49, v4                                        // 000000857744: D8D80000 31000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 00000085774C: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000857750: 360808FF 000003FC
	ds_load_b32 v50, v4                                        // 000000857758: D8D80000 32000004
	v_and_b32_e32 v4, 0xff, v6                                 // 000000857760: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000857768: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000085776C: 30080882
	ds_load_b32 v51, v4                                        // 000000857770: D8D80000 33000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 000000857778: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000085777C: 360808FF 000003FC
	ds_load_b32 v52, v4                                        // 000000857784: D8D80000 34000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 00000085778C: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000857790: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000857794: 360808FF 000003FC
	ds_load_b32 v53, v4                                        // 00000085779C: D8D80000 35000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 0000008577A4: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008577A8: 360808FF 000003FC
	ds_load_b32 v54, v4                                        // 0000008577B0: D8D80000 36000004
	v_and_b32_e32 v4, 0xff, v7                                 // 0000008577B8: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008577C0: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008577C4: 30080882
	ds_load_b32 v55, v4                                        // 0000008577C8: D8D80000 37000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 0000008577D0: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008577D4: 360808FF 000003FC
	ds_load_b32 v56, v4                                        // 0000008577DC: D8D80000 38000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 0000008577E4: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008577E8: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008577EC: 360808FF 000003FC
	ds_load_b32 v57, v4                                        // 0000008577F4: D8D80000 39000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 0000008577FC: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000857800: 360808FF 000003FC
	ds_load_b32 v58, v4                                        // 000000857808: D8D80000 3A000004
	.long 0xd73c0004                                           // 000000857810: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000857814: 02021681
	v_add_nc_u32_e32 v11, 0x400, v11                           // 000000857818: 4A1616FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857820: BF870092
	.long 0xd7000227                                           // 000000857824: D7000227
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000857828: 02020806
	v_add_co_ci_u32_e64 v40, null, s7, v5, s2                  // 00000085782C: D5207C28 000A0A07
	s_clause 0x3                                               // 000000857834: BF850003
	global_load_b128 v[4:7], v[39:40], off                     // 000000857838: DC5E0000 047C0027
	global_load_b128 v[27:30], v[39:40], off offset:16         // 000000857840: DC5E0010 1B7C0027
	global_load_b128 v[31:34], v[39:40], off offset:32         // 000000857848: DC5E0020 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:48         // 000000857850: DC5E0030 237C0027
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000857858: BF890CF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 00000085785C: CC1A4004 1A025704
	s_waitcnt lgkmcnt(14)                                      // 000000857864: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000857868: BF8700A1
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 00000085786C: CC1A4004 1C125905
	s_waitcnt lgkmcnt(13)                                      // 000000857874: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000857878: CC1A4004 1C125B06
	s_waitcnt lgkmcnt(12)                                      // 000000857880: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000857884: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 000000857888: CC1A4004 1C125D07
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000857890: BF8908B7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000857894: CC1A4004 1C125F1B
	s_waitcnt lgkmcnt(10)                                      // 00000085789C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008578A0: BF8700A1
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000008578A4: CC1A4004 1C12611C
	s_waitcnt lgkmcnt(9)                                       // 0000008578AC: BF89FC97
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008578B0: CC1A4004 1C12631D
	s_waitcnt lgkmcnt(8)                                       // 0000008578B8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008578BC: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008578C0: CC1A4004 1C12651E
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008578C8: BF890477
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008578CC: CC1A4004 1C12671F
	s_waitcnt lgkmcnt(6)                                       // 0000008578D4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008578D8: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008578DC: CC1A4004 1C126920
	s_waitcnt lgkmcnt(5)                                       // 0000008578E4: BF89FC57
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008578E8: CC1A4004 1C126B21
	s_waitcnt lgkmcnt(4)                                       // 0000008578F0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008578F4: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008578F8: CC1A4004 1C126D22
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000857900: BF890037
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000857904: CC1A4004 1C126F23
	.long 0xd7000223                                           // 00000085790C: D7000223
	v_cndmask_b32_e32 v0, v39, v4, vcc_lo                      // 000000857910: 02000927
	s_waitcnt lgkmcnt(2)                                       // 000000857914: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000857918: BF8701C2
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000085791C: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v36, null, s5, v40, s2                 // 000000857924: D5207C24 000A5005
	.long 0xd7000229                                           // 00000085792C: D7000229
	v_cndmask_b32_e32 v0, v39, v18, vcc_lo                     // 000000857930: 02002527
	s_waitcnt lgkmcnt(1)                                       // 000000857934: BF89FC17
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000857938: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v42, null, s19, v40, s2                // 000000857940: D5207C2A 000A5013
	.long 0xd7000227                                           // 000000857948: D7000227
	v_cndmask_b32_e32 v0, v39, v17, vcc_lo                     // 00000085794C: 02002327
	s_waitcnt lgkmcnt(0)                                       // 000000857950: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000857954: BF870123
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000857958: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v40, null, s20, v40, s2                // 000000857960: D5207C28 000A5014
	v_fmac_f32_e32 v22, v26, v4                                // 000000857968: 562C091A
	s_clause 0x3                                               // 00000085796C: BF850003
	global_load_b128 v[4:7], v[35:36], off                     // 000000857970: DC5E0000 047C0023
	global_load_b128 v[27:30], v[35:36], off offset:16         // 000000857978: DC5E0010 1B7C0023
	global_load_b128 v[31:34], v[35:36], off offset:32         // 000000857980: DC5E0020 1F7C0023
	global_load_b128 v[35:38], v[35:36], off offset:48         // 000000857988: DC5E0030 237C0023
	s_waitcnt vmcnt(3)                                         // 000000857990: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000857994: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085799C: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 0000008579A0: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 0000008579A8: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008579B0: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 0000008579B4: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 0000008579BC: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 0000008579C0: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008579C8: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000008579CC: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008579D4: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008579DC: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008579E0: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 0000008579E8: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008579EC: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008579F4: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008579F8: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000857A00: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000857A08: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000857A0C: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 000000857A14: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000857A18: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857A20: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000857A24: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000857A2C: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857A34: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000857A38: CC1A4004 1C127526
	v_fmac_f32_e32 v21, v26, v4                                // 000000857A40: 562A091A
	s_clause 0x3                                               // 000000857A44: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 000000857A48: DC5E0000 047C0029
	global_load_b128 v[27:30], v[41:42], off offset:16         // 000000857A50: DC5E0010 1B7C0029
	global_load_b128 v[31:34], v[41:42], off offset:32         // 000000857A58: DC5E0020 1F7C0029
	global_load_b128 v[35:38], v[41:42], off offset:48         // 000000857A60: DC5E0030 237C0029
	s_waitcnt vmcnt(3)                                         // 000000857A68: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000857A6C: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857A74: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 000000857A78: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000857A80: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000857A88: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 000000857A8C: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 000000857A94: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000857A98: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857AA0: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000857AA4: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000857AAC: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000857AB4: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000857AB8: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 000000857AC0: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000857AC4: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857ACC: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000857AD0: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000857AD8: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000857AE0: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000857AE4: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 000000857AEC: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000857AF0: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857AF8: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000857AFC: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000857B04: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857B0C: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000857B10: CC1A4004 1C127526
	v_fmac_f32_e32 v20, v26, v4                                // 000000857B18: 5628091A
	s_clause 0x3                                               // 000000857B1C: BF850003
	global_load_b128 v[4:7], v[39:40], off                     // 000000857B20: DC5E0000 047C0027
	global_load_b128 v[27:30], v[39:40], off offset:16         // 000000857B28: DC5E0010 1B7C0027
	global_load_b128 v[31:34], v[39:40], off offset:32         // 000000857B30: DC5E0020 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:48         // 000000857B38: DC5E0030 237C0027
	s_waitcnt vmcnt(3)                                         // 000000857B40: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000857B44: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857B4C: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 000000857B50: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000857B58: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000857B60: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 000000857B64: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 000000857B6C: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000857B70: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857B78: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000857B7C: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000857B84: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000857B8C: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000857B90: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 000000857B98: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000857B9C: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857BA4: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000857BA8: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000857BB0: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000857BB8: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000857BBC: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 000000857BC4: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000857BC8: CC1A4004 1C126F23
	.long 0xd7000223                                           // 000000857BD0: D7000223
	v_cndmask_b32_e32 v0, v41, v18, vcc_lo                     // 000000857BD4: 02002529
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000857BD8: BF870122
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000857BDC: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v36, null, s19, v42, s2                // 000000857BE4: D5207C24 000A5413
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000857BEC: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857BF4: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000857BF8: CC1A4004 1C127526
	v_fmac_f32_e32 v19, v26, v4                                // 000000857C00: 5626091A
	s_clause 0x3                                               // 000000857C04: BF850003
	global_load_b128 v[4:7], v[35:36], off                     // 000000857C08: DC5E0000 047C0023
	global_load_b128 v[27:30], v[35:36], off offset:16         // 000000857C10: DC5E0010 1B7C0023
	global_load_b128 v[31:34], v[35:36], off offset:32         // 000000857C18: DC5E0020 1F7C0023
	global_load_b128 v[35:38], v[35:36], off offset:48         // 000000857C20: DC5E0030 237C0023
	s_waitcnt vmcnt(3)                                         // 000000857C28: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000857C2C: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857C34: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 000000857C38: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000857C40: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000857C48: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 000000857C4C: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 000000857C54: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000857C58: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857C60: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000857C64: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000857C6C: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000857C74: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000857C78: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 000000857C80: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000857C84: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857C8C: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000857C90: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000857C98: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000857CA0: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000857CA4: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 000000857CAC: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000857CB0: CC1A4004 1C126F23
	.long 0xd7000223                                           // 000000857CB8: D7000223
	v_cndmask_b32_e32 v0, v39, v18, vcc_lo                     // 000000857CBC: 02002527
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000857CC0: BF8701B2
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000857CC4: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v36, null, s19, v40, s2                // 000000857CCC: D5207C24 000A5013
	.long 0xd700020d                                           // 000000857CD4: D700020D
	v_cndmask_b32_e32 v0, v13, v192, vcc_lo                    // 000000857CD8: 0201810D
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000857CDC: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v14, null, 0, v14, s2                  // 000000857CE4: D5207C0E 000A1C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857CEC: BF870092
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000857CF0: CC1A4004 1C127526
	v_fmac_f32_e32 v18, v26, v4                                // 000000857CF8: 5624091A
	s_clause 0x3                                               // 000000857CFC: BF850003
	global_load_b128 v[4:7], v[35:36], off                     // 000000857D00: DC5E0000 047C0023
	global_load_b128 v[27:30], v[35:36], off offset:16         // 000000857D08: DC5E0010 1B7C0023
	global_load_b128 v[31:34], v[35:36], off offset:32         // 000000857D10: DC5E0020 1F7C0023
	global_load_b128 v[35:38], v[35:36], off offset:48         // 000000857D18: DC5E0030 237C0023
	s_waitcnt vmcnt(3)                                         // 000000857D20: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000857D24: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000857D2C: BF870121
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 000000857D30: CC1A4004 1C125905
	v_mov_b32_e32 v5, v1                                       // 000000857D38: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000857D3C: CC1A4004 1C125B06
	v_mov_b32_e32 v6, v2                                       // 000000857D44: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000857D48: BF870132
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 000000857D4C: CC1A4004 1C125D07
	v_mov_b32_e32 v7, v3                                       // 000000857D54: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 000000857D58: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000857D5C: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857D64: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000857D68: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000857D70: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000857D78: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000857D7C: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 000000857D84: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000857D88: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857D90: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000857D94: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000857D9C: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000857DA4: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000857DA8: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 000000857DB0: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000857DB4: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857DBC: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000857DC0: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000857DC8: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857DD0: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000857DD4: CC1A4004 1C127526
	v_fmac_f32_e32 v16, v26, v4                                // 000000857DDC: 5620091A
	v_mov_b32_e32 v4, v0                                       // 000000857DE0: 7E080300
	v_mov_b32_e32 v26, v25                                     // 000000857DE4: 7E340319
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000857DE8: 917E107E
	s_cbranch_execz 25                                         // 000000857DEC: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xa54>
	s_waitcnt vmcnt(0)                                         // 000000857DF0: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v24, 32, v24    // 000000857DF4: CA200105 011830A0
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v3, v7             // 000000857DFC: CA100104 00020107
	v_mov_b32_e32 v2, v6                                       // 000000857E04: 7E040306
	s_delay_alu instid0(VALU_DEP_3)                            // 000000857E08: BF870003
	.long 0xd4430002                                           // 000000857E0C: D4430002
	v_cndmask_b32_e32 v1, s14, v24, vcc_lo                     // 000000857E10: 0202300E
	s_mov_b32 s10, exec_lo                                     // 000000857E14: BE8A007E
	.long 0xd4c4007e                                           // 000000857E18: D4C4007E
	v_cndmask_b32_e32 v1, s14, v24, vcc_lo                     // 000000857E1C: 0202300E
	s_cbranch_execz 65054                                      // 000000857E20: BFA5FE1E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x29c>
	.long 0xd7000300                                           // 000000857E24: D7000300
	v_cndmask_b32_e32 v1, v10, v23, vcc_lo                     // 000000857E28: 02022F0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000857E2C: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s3                   // 000000857E30: D5207C01 000E2280
	global_load_d16_b16 v25, v[13:14], off                     // 000000857E38: DC820000 197C000D
	global_load_b128 v[0:3], v[0:1], off                       // 000000857E40: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 000000857E48: BF8907F7
	v_cvt_f32_f16_e32 v25, v25                                 // 000000857E4C: 7E321719
	s_branch 65042                                             // 000000857E50: BFA0FE12 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x29c>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000857E54: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000857E58: BF8700A9
	s_or_b32 exec_lo, exec_lo, s15                             // 000000857E5C: 8C7E0F7E
	.long 0xd71f0000                                           // 000000857E60: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000857E64: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000857E68: 3A020090
	s_waitcnt vmcnt(0)                                         // 000000857E6C: BF8903F7
	v_xor_b32_e32 v7, 8, v0                                    // 000000857E70: 3A0E0088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857E74: BF870092
	.long 0xd44c0002                                           // 000000857E78: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000857E7C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 000000857E80: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000857E88: BF870113
	.long 0xd44c0002                                           // 000000857E8C: D44C0002
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 000000857E90: 02020EA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000857E94: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000857E98: BF870002
	v_cndmask_b32_e64 v7, v0, v7, s2                           // 000000857E9C: D5010007 000A0F00
	ds_bpermute_b32 v2, v1, v22                                // 000000857EA4: DACC0000 02001601
	s_waitcnt lgkmcnt(0)                                       // 000000857EAC: BF89FC07
	v_add_f32_e32 v2, v22, v2                                  // 000000857EB0: 06040516
	ds_bpermute_b32 v4, v1, v20                                // 000000857EB4: DACC0000 04001401
	ds_bpermute_b32 v3, v1, v21                                // 000000857EBC: DACC0000 03001501
	ds_bpermute_b32 v5, v1, v19                                // 000000857EC4: DACC0000 05001301
	ds_bpermute_b32 v6, v1, v18                                // 000000857ECC: DACC0000 06001201
	ds_bpermute_b32 v1, v1, v16                                // 000000857ED4: DACC0000 01001001
	s_waitcnt lgkmcnt(4)                                       // 000000857EDC: BF89FC47
	v_dual_add_f32 v4, v20, v4 :: v_dual_lshlrev_b32 v7, 2, v7 // 000000857EE0: C9220914 04060E82
	ds_bpermute_b32 v10, v7, v2                                // 000000857EE8: DACC0000 0A000207
	s_waitcnt lgkmcnt(2)                                       // 000000857EF0: BF89FC27
	v_dual_add_f32 v3, v21, v3 :: v_dual_add_f32 v6, v18, v6   // 000000857EF4: C9080715 03060D12
	s_waitcnt lgkmcnt(1)                                       // 000000857EFC: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 000000857F00: 06020310
	v_xor_b32_e32 v16, 4, v0                                   // 000000857F04: 3A200084
	ds_bpermute_b32 v12, v7, v4                                // 000000857F08: DACC0000 0C000407
	ds_bpermute_b32 v11, v7, v3                                // 000000857F10: DACC0000 0B000307
	ds_bpermute_b32 v14, v7, v6                                // 000000857F18: DACC0000 0E000607
	.long 0xd44c0002                                           // 000000857F20: D44C0002
	v_cndmask_b32_e32 v1, 32, v16, vcc_lo                      // 000000857F24: 020220A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857F28: BF870091
	v_cndmask_b32_e64 v16, v0, v16, s2                         // 000000857F2C: D5010010 000A2100
	v_dual_add_f32 v5, v19, v5 :: v_dual_lshlrev_b32 v16, 2, v16// 000000857F34: C9220B13 05102082
	ds_bpermute_b32 v13, v7, v5                                // 000000857F3C: DACC0000 0D000507
	s_waitcnt lgkmcnt(4)                                       // 000000857F44: BF89FC47
	v_add_f32_e32 v2, v2, v10                                  // 000000857F48: 06041502
	ds_bpermute_b32 v7, v7, v1                                 // 000000857F4C: DACC0000 07000107
	s_waitcnt lgkmcnt(3)                                       // 000000857F54: BF89FC37
	v_dual_add_f32 v4, v4, v12 :: v_dual_add_f32 v3, v3, v11   // 000000857F58: C9081904 04021703
	s_waitcnt lgkmcnt(2)                                       // 000000857F60: BF89FC27
	v_add_f32_e32 v6, v6, v14                                  // 000000857F64: 060C1D06
	ds_bpermute_b32 v11, v16, v4                               // 000000857F68: DACC0000 0B000410
	ds_bpermute_b32 v10, v16, v3                               // 000000857F70: DACC0000 0A000310
	s_waitcnt lgkmcnt(3)                                       // 000000857F78: BF89FC37
	v_add_f32_e32 v5, v5, v13                                  // 000000857F7C: 060A1B05
	ds_bpermute_b32 v13, v16, v6                               // 000000857F80: DACC0000 0D000610
	s_waitcnt lgkmcnt(3)                                       // 000000857F88: BF89FC37
	v_add_f32_e32 v1, v1, v7                                   // 000000857F8C: 06020F01
	ds_bpermute_b32 v7, v16, v2                                // 000000857F90: DACC0000 07000210
	ds_bpermute_b32 v12, v16, v5                               // 000000857F98: DACC0000 0C000510
	ds_bpermute_b32 v14, v16, v1                               // 000000857FA0: DACC0000 0E000110
	v_xor_b32_e32 v16, 2, v0                                   // 000000857FA8: 3A200082
	s_waitcnt lgkmcnt(4)                                       // 000000857FAC: BF89FC47
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v3, v3, v10   // 000000857FB0: C9081704 04021503
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857FB8: BF870092
	.long 0xd44c0002                                           // 000000857FBC: D44C0002
	v_cndmask_b32_e32 v1, 32, v16, vcc_lo                      // 000000857FC0: 020220A0
	v_cndmask_b32_e64 v16, v0, v16, s2                         // 000000857FC4: D5010010 000A2100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000857FCC: BF870001
	v_lshlrev_b32_e32 v16, 2, v16                              // 000000857FD0: 30202082
	s_waitcnt lgkmcnt(1)                                       // 000000857FD4: BF89FC17
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v5, v5, v12    // 000000857FD8: C9080F02 02041905
	s_waitcnt lgkmcnt(0)                                       // 000000857FE0: BF89FC07
	v_dual_add_f32 v10, v6, v13 :: v_dual_add_f32 v11, v1, v14 // 000000857FE4: C9081B06 0A0A1D01
	ds_bpermute_b32 v7, v16, v3                                // 000000857FEC: DACC0000 07000310
	ds_bpermute_b32 v1, v16, v2                                // 000000857FF4: DACC0000 01000210
	ds_bpermute_b32 v12, v16, v4                               // 000000857FFC: DACC0000 0C000410
	ds_bpermute_b32 v13, v16, v5                               // 000000858004: DACC0000 0D000510
	ds_bpermute_b32 v14, v16, v10                              // 00000085800C: DACC0000 0E000A10
	ds_bpermute_b32 v16, v16, v11                              // 000000858014: DACC0000 10000B10
	v_xor_b32_e32 v6, 1, v0                                    // 00000085801C: 3A0C0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000858020: BF870091
	.long 0xd44c0002                                           // 000000858024: D44C0002
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 000000858028: 02020CA0
	v_cndmask_b32_e64 v0, v0, v6, s2                           // 00000085802C: D5010000 000A0D00
	.long 0xd44a0002                                           // 000000858034: D44A0002
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000858038: 02021E80
	s_waitcnt lgkmcnt(5)                                       // 00000085803C: BF89FC57
	v_add_f32_e32 v7, v3, v7                                   // 000000858040: 060E0F03
	s_waitcnt lgkmcnt(4)                                       // 000000858044: BF89FC47
	v_dual_add_f32 v6, v2, v1 :: v_dual_lshlrev_b32 v17, 2, v0 // 000000858048: C9220302 06100082
	s_waitcnt lgkmcnt(2)                                       // 000000858050: BF89FC27
	v_dual_add_f32 v0, v4, v12 :: v_dual_add_f32 v1, v5, v13   // 000000858054: C9081904 00001B05
	s_waitcnt lgkmcnt(1)                                       // 00000085805C: BF89FC17
	v_add_f32_e32 v2, v10, v14                                 // 000000858060: 06041D0A
	s_waitcnt lgkmcnt(0)                                       // 000000858064: BF89FC07
	v_add_f32_e32 v10, v11, v16                                // 000000858068: 0614210B
	ds_bpermute_b32 v11, v17, v6                               // 00000085806C: DACC0000 0B000611
	ds_bpermute_b32 v12, v17, v7                               // 000000858074: DACC0000 0C000711
	ds_bpermute_b32 v3, v17, v0                                // 00000085807C: DACC0000 03000011
	ds_bpermute_b32 v4, v17, v1                                // 000000858084: DACC0000 04000111
	ds_bpermute_b32 v5, v17, v2                                // 00000085808C: DACC0000 05000211
	ds_bpermute_b32 v13, v17, v10                              // 000000858094: DACC0000 0D000A11
	s_and_b32 s2, s2, vcc_lo                                   // 00000085809C: 8B026A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008580A0: BF870009
	s_and_saveexec_b32 s3, s2                                  // 0000008580A4: BE832002
	s_cbranch_execz 280                                        // 0000008580A8: BFA50118 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x110c>
	s_waitcnt lgkmcnt(4)                                       // 0000008580AC: BF89FC47
	v_dual_add_f32 v6, v6, v11 :: v_dual_add_f32 v7, v7, v12   // 0000008580B0: C9081706 06061907
	s_waitcnt lgkmcnt(0)                                       // 0000008580B8: BF89FC07
	v_dual_add_f32 v10, v10, v13 :: v_dual_add_f32 v1, v1, v4  // 0000008580BC: C9081B0A 0A000901
	v_add_f32_e32 v0, v0, v3                                   // 0000008580C4: 06000700
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008580C8: BF870143
	v_bfe_u32 v11, v6, 16, 1                                   // 0000008580CC: D610000B 02052106
	s_load_b32 s0, s[0:1], 0x48                                // 0000008580D4: F4000000 F8000048
	v_bfe_u32 v12, v7, 16, 1                                   // 0000008580DC: D610000C 02052107
	s_lshl_b64 s[4:5], s[12:13], 2                             // 0000008580E4: 8484820C
	v_add3_u32 v3, v6, v11, 0x7fff                             // 0000008580E8: D6550003 03FE1706 00007FFF
	v_bfe_u32 v6, v1, 16, 1                                    // 0000008580F4: D6100006 02052101
	v_add_f32_e32 v2, v2, v5                                   // 0000008580FC: 06040B02
	v_bfe_u32 v11, v10, 16, 1                                  // 000000858100: D610000B 0205210A
	v_add3_u32 v4, v7, v12, 0x7fff                             // 000000858108: D6550004 03FE1907 00007FFF
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000858114: 360606FF FFFF0000
	v_add3_u32 v1, v1, v6, 0x7fff                              // 00000085811C: D6550001 03FE0D01 00007FFF
	v_bfe_u32 v7, v2, 16, 1                                    // 000000858128: D6100007 02052102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000858130: BF870194
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000858134: 360808FF FFFF0000
	v_and_b32_e32 v1, 0xffff0000, v1                           // 00000085813C: 360202FF FFFF0000
	v_bfe_u32 v5, v0, 16, 1                                    // 000000858144: D6100005 02052100
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000085814C: BF8701B4
	v_add3_u32 v2, v2, v7, 0x7fff                              // 000000858150: D6550002 03FE0F02 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 00000085815C: BF89FC07
	v_mul_f32_e32 v3, s0, v3                                   // 000000858160: 10060600
	v_add3_u32 v0, v0, v5, 0x7fff                              // 000000858164: D6550000 03FE0B00 00007FFF
	v_add3_u32 v5, v10, v11, 0x7fff                            // 000000858170: D6550005 03FE170A 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000085817C: BF870113
	v_dual_mul_f32 v4, s0, v4 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v3// 000000858180: C8C60800 040206FF BFB8AA3B
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000085818C: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000858194: BF870194
	v_and_b32_e32 v0, 0xffff0000, v0                           // 000000858198: 360000FF FFFF0000
	v_exp_f32_e32 v3, v3                                       // 0000008581A0: 7E064B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008581A4: BF8701B1
	v_dual_mul_f32 v5, s0, v5 :: v_dual_mul_f32 v0, s0, v0     // 0000008581A8: C8C60A00 05000000
	v_mul_f32_e32 v6, s0, v1                                   // 0000008581B0: 100C0200
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 0000008581B4: 100808FF BFB8AA3B
	v_mul_f32_e32 v7, 0xbfb8aa3b, v0                           // 0000008581BC: 100E00FF BFB8AA3B
	.long 0xd73c0000                                           // 0000008581C4: D73C0000
	v_cndmask_b32_e32 v1, 2, v8, vcc_lo                        // 0000008581C8: 02021082
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008581CC: BF870215
	v_dual_add_f32 v8, 1.0, v3 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v5// 0000008581D0: C90606F2 08020AFF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 0000008581DC: 7E084B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008581E0: BF870123
	v_exp_f32_e32 v7, v7                                       // 0000008581E4: 7E0E4B07
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000008581E8: 360404FF FFFF0000
	v_exp_f32_e32 v11, v3                                      // 0000008581F0: 7E164B03
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_1)   // 0000008581F4: BF870086
	v_dual_add_f32 v7, 1.0, v7 :: v_dual_mul_f32 v2, s0, v2    // 0000008581F8: C9060EF2 07020400
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 000000858200: BF870085
	v_dual_add_f32 v11, 1.0, v11 :: v_dual_mul_f32 v2, 0xbfb8aa3b, v2// 000000858204: C90616F2 0B0204FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000858210: BF870111
	v_div_scale_f32 v21, null, v11, v11, 1.0                   // 000000858214: D6FC7C15 03CA170B
	v_exp_f32_e32 v10, v2                                      // 00000085821C: 7E144B02
	.long 0xd7006a02                                           // 000000858220: D7006A02
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000858224: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000858228: BF870141
	v_add_co_ci_u32_e64 v3, null, s9, v1, vcc_lo               // 00000085822C: D5207C03 01AA0209
	v_div_scale_f32 v1, null, v7, v7, 1.0                      // 000000858234: D6FC7C01 03CA0F07
	v_rcp_f32_e32 v27, v21                                     // 00000085823C: 7E365515
	v_div_scale_f32 v15, vcc_lo, 1.0, v8, 1.0                  // 000000858240: D6FC6A0F 03CA10F2
	v_rcp_f32_e32 v17, v1                                      // 000000858248: 7E225501
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000085824C: BF870296
	v_fma_f32 v28, -v21, v27, 1.0                              // 000000858250: D613001C 23CA3715
	v_fma_f32 v23, -v1, v17, 1.0                               // 000000858258: D6130017 23CA2301
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000858260: BF870112
	v_dual_add_f32 v4, 1.0, v4 :: v_dual_fmac_f32 v27, v28, v27// 000000858264: C90008F2 041A371C
	v_fmac_f32_e32 v17, v23, v17                               // 00000085826C: 56222317
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000858270: BF8701B2
	v_div_scale_f32 v9, null, v4, v4, 1.0                      // 000000858274: D6FC7C09 03CA0904
	v_div_scale_f32 v16, s0, 1.0, v4, 1.0                      // 00000085827C: D6FC0010 03CA08F2
	v_add_f32_e32 v10, 1.0, v10                                // 000000858284: 061414F2
	v_rcp_f32_e32 v13, v9                                      // 000000858288: 7E1A5509
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085828C: BF870095
	v_fma_f32 v14, -v9, v13, 1.0                               // 000000858290: D613000E 23CA1B09
	v_dual_mul_f32 v6, 0xbfb8aa3b, v6 :: v_dual_fmac_f32 v13, v14, v13// 000000858298: C8C00CFF 060C1B0E BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008582A4: BF870121
	v_exp_f32_e32 v5, v6                                       // 0000008582A8: 7E0A4B06
	v_div_scale_f32 v6, null, v8, v8, 1.0                      // 0000008582AC: D6FC7C06 03CA1108
	v_mul_f32_e32 v20, v16, v13                                // 0000008582B4: 10281B10
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008582B8: BF870092
	v_rcp_f32_e32 v12, v6                                      // 0000008582BC: 7E185506
	v_fma_f32 v25, -v9, v20, v16                               // 0000008582C0: D6130019 24422909
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008582C8: BF870091
	v_fmac_f32_e32 v20, v25, v13                               // 0000008582CC: 56281B19
	v_fma_f32 v9, -v9, v20, v16                                // 0000008582D0: D6130009 24422909
	v_div_scale_f32 v16, s3, 1.0, v10, 1.0                     // 0000008582D8: D6FC0310 03CA14F2
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000008582E0: BF870296
	v_add_f32_e32 v0, 1.0, v5                                  // 0000008582E4: 06000AF2
	v_fma_f32 v5, -v6, v12, 1.0                                // 0000008582E8: D6130005 23CA1906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008582F0: BF870121
	v_fmac_f32_e32 v12, v5, v12                                // 0000008582F4: 56181905
	v_div_scale_f32 v5, s1, 1.0, v7, 1.0                       // 0000008582F8: D6FC0105 03CA0EF2
	v_mul_f32_e32 v19, v15, v12                                // 000000858300: 1026190F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000858304: BF8701A2
	v_mul_f32_e32 v25, v5, v17                                 // 000000858308: 10322305
	v_div_scale_f32 v18, null, v10, v10, 1.0                   // 00000085830C: D6FC7C12 03CA150A
	v_fma_f32 v24, -v6, v19, v15                               // 000000858314: D6130018 243E2706
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085831C: BF870092
	v_rcp_f32_e32 v26, v18                                     // 000000858320: 7E345512
	v_fmac_f32_e32 v19, v24, v12                               // 000000858324: 56261918
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000858328: BF870291
	v_fma_f32 v6, -v6, v19, v15                                // 00000085832C: D6130006 243E2706
	v_fma_f32 v15, -v18, v26, 1.0                              // 000000858334: D613000F 23CA3512
	s_delay_alu instid0(VALU_DEP_2)                            // 00000085833C: BF870002
	v_div_fmas_f32 v6, v6, v12, v19                            // 000000858340: D6370006 044E1906
	s_mov_b32 vcc_lo, s0                                       // 000000858348: BEEA0000
	v_fma_f32 v12, -v1, v25, v5                                // 00000085834C: D613000C 24163301
	v_div_fmas_f32 v9, v9, v13, v20                            // 000000858354: D6370009 04521B09
	v_fmac_f32_e32 v26, v15, v26                               // 00000085835C: 5634350F
	s_mov_b32 vcc_lo, s1                                       // 000000858360: BEEA0001
	v_div_fixup_f32 v6, v6, v8, 1.0                            // 000000858364: D6270006 03CA1106
	v_fmac_f32_e32 v25, v12, v17                               // 00000085836C: 5632230C
	v_div_fixup_f32 v4, v9, v4, 1.0                            // 000000858370: D6270004 03CA0909
	v_mul_f32_e32 v9, v16, v26                                 // 000000858378: 10123510
	v_div_scale_f32 v14, null, v0, v0, 1.0                     // 00000085837C: D6FC7C0E 03CA0100
	v_div_scale_f32 v23, s2, 1.0, v0, 1.0                      // 000000858384: D6FC0217 03CA00F2
	v_fma_f32 v1, -v1, v25, v5                                 // 00000085838C: D6130001 24163301
	v_add_f32_e32 v12, v4, v4                                  // 000000858394: 06180904
	v_fma_f32 v5, -v18, v9, v16                                // 000000858398: D6130005 24421312
	v_rcp_f32_e32 v22, v14                                     // 0000008583A0: 7E2C550E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008583A4: BF870113
	v_div_fmas_f32 v1, v1, v17, v25                            // 0000008583A8: D6370001 04662301
	v_fmac_f32_e32 v9, v5, v26                                 // 0000008583B0: 56123505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008583B4: BF870112
	v_div_fixup_f32 v1, v1, v7, 1.0                            // 0000008583B8: D6270001 03CA0F01
	v_fma_f32 v15, -v18, v9, v16                               // 0000008583C0: D613000F 24421312
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008583C8: BF870095
	v_fma_f32 v24, -v14, v22, 1.0                              // 0000008583CC: D6130018 23CA2D0E
	v_dual_add_f32 v13, v1, v1 :: v_dual_fmac_f32 v22, v24, v22// 0000008583D4: C9000301 0D162D18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008583DC: BF870091
	v_mul_f32_e32 v8, v23, v22                                 // 0000008583E0: 10102D17
	v_fma_f32 v4, -v14, v8, v23                                // 0000008583E4: D6130004 245E110E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008583EC: BF8700A1
	v_fmac_f32_e32 v8, v4, v22                                 // 0000008583F0: 56102D04
	.long 0xd7006a04                                           // 0000008583F4: D7006A04
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 0000008583F8: 02000902
	v_add_co_ci_u32_e64 v5, null, s5, v3, vcc_lo               // 0000008583FC: D5207C05 01AA0605
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000858404: BF8700A3
	v_fma_f32 v1, -v14, v8, v23                                // 000000858408: D6130001 245E110E
	s_mov_b32 vcc_lo, s2                                       // 000000858410: BEEA0002
	v_div_fmas_f32 v1, v1, v22, v8                             // 000000858414: D6370001 04222D01
	s_mov_b32 vcc_lo, s3                                       // 00000085841C: BEEA0003
	s_lshl_b64 s[2:3], s[12:13], 3                             // 000000858420: 8482830C
	v_div_fmas_f32 v8, v15, v26, v9                            // 000000858424: D6370008 0426350F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000085842C: BF8701A2
	v_div_fixup_f32 v9, v1, v0, 1.0                            // 000000858430: D6270009 03CA0101
	v_mad_u64_u32 v[0:1], null, s12, 12, v[2:3]                // 000000858438: D6FE7C00 0409180C
	v_div_fixup_f32 v8, v8, v10, 1.0                           // 000000858440: D6270008 03CA1508
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000858448: BF8700D1
	v_dual_add_f32 v6, v6, v6 :: v_dual_add_f32 v15, v8, v8    // 00000085844C: C9080D06 060E1108
	global_store_b32 v[2:3], v6, off                           // 000000858454: DC6A0000 007C0602
	v_div_scale_f32 v6, s0, 1.0, v11, 1.0                      // 00000085845C: D6FC0006 03CA16F2
	s_mov_b32 vcc_lo, s0                                       // 000000858464: BEEA0000
	v_mul_f32_e32 v7, v6, v27                                  // 000000858468: 100E3706
	v_fma_f32 v14, -v21, v7, v6                                // 00000085846C: D613000E 241A0F15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000858474: BF870091
	v_dual_fmac_f32 v7, v14, v27 :: v_dual_add_f32 v14, v9, v9 // 000000858478: C808370E 070E1309
	v_fma_f32 v6, -v21, v7, v6                                 // 000000858480: D6130006 241A0F15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000858488: BF870241
	v_div_fmas_f32 v10, v6, v27, v7                            // 00000085848C: D637000A 041E3706
	.long 0xd7006a06                                           // 000000858494: D7006A06
	v_cndmask_b32_e32 v0, v2, v2, vcc_lo                       // 000000858498: 02000502
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 00000085849C: D6FE7C01 0405180D
	v_add_co_ci_u32_e64 v7, null, s3, v3, vcc_lo               // 0000008584A4: D5207C07 01AA0603
	v_div_fixup_f32 v8, v10, v11, 1.0                          // 0000008584AC: D6270008 03CA170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008584B4: BF870094
	.long 0xd7006a02                                           // 0000008584B8: D7006A02
	v_cndmask_b32_e32 v0, v6, v2, vcc_lo                       // 0000008584BC: 02000506
	v_add_co_ci_u32_e64 v3, null, s3, v7, vcc_lo               // 0000008584C0: D5207C03 01AA0E03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008584C8: BF8700A3
	v_add_f32_e32 v10, v8, v8                                  // 0000008584CC: 06141108
	.long 0xd7006a08                                           // 0000008584D0: D7006A08
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 0000008584D4: 02000500
	v_add_co_ci_u32_e64 v9, null, s3, v1, vcc_lo               // 0000008584D8: D5207C09 01AA0203
	s_clause 0x4                                               // 0000008584E0: BF850004
	global_store_b32 v[4:5], v12, off                          // 0000008584E4: DC6A0000 007C0C04
	global_store_b32 v[6:7], v13, off                          // 0000008584EC: DC6A0000 007C0D06
	global_store_b32 v[0:1], v14, off                          // 0000008584F4: DC6A0000 007C0E00
	global_store_b32 v[2:3], v15, off                          // 0000008584FC: DC6A0000 007C0F02
	global_store_b32 v[8:9], v10, off                          // 000000858504: DC6A0000 007C0A08
	s_endpgm                                                   // 00000085850C: BFB00000
		...

