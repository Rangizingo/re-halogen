000000000055b100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000055B100: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 00000055B108: CA240080 1200008F
	v_lshrrev_b32_e32 v14, 2, v0                               // 00000055B110: 321C0082
	v_lshrrev_b32_e32 v15, 6, v0                               // 00000055B114: 321E0086
	v_mov_b32_e32 v5, 0                                        // 00000055B118: 7E0A0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000055B11C: BF870214
	v_dual_mov_b32 v22, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 00000055B120: CA220080 16000282
	v_and_b32_e32 v2, 60, v14                                  // 00000055B128: 36041CBC
	s_ashr_i32 s3, s2, 31                                      // 00000055B12C: 86039F02
	v_bfe_u32 v16, v0, 5, 1                                    // 00000055B130: D6100010 02050B00
	s_lshl_b64 s[2:3], s[2:3], 2                               // 00000055B138: 84828202
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v17, 31, v0         // 00000055B13C: CA240080 0610009F
	.long 0x7f103880                                           // 00000055B144: 7F103880
	s_waitcnt lgkmcnt(0)                                       // 00000055B148: BF89FC07
	s_clause 0x1                                               // 00000055B14C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000055B150: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 00000055B158: DC520000 04040002
	v_or_b32_e32 v1, s2, v15                                   // 00000055B160: 38021E02
	v_mov_b32_e32 v2, s3                                       // 00000055B164: 7E040203
	s_add_u32 s0, s4, s14                                      // 00000055B168: 80000E04
	s_addc_u32 s1, s5, s15                                     // 00000055B16C: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 00000055B170: 850E9F0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000055B174: BF870009
	s_add_u32 s14, s10, s14                                    // 00000055B178: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000055B17C: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000055B180: 86149F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000055B184: 7CA8020C
	s_lshr_b32 s20, s20, 27                                    // 00000055B188: 85149B14
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000055B18C: 868E810E
	s_add_u32 s20, s10, s20                                    // 00000055B190: 8014140A
	s_addc_u32 s21, s11, 0                                     // 00000055B194: 8215800B
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000055B198: 02020280
	s_lshr_b64 s[20:21], s[20:21], 5                           // 00000055B19C: 85948514
	v_cndmask_b32_e64 v7, 0, s3, vcc_lo                        // 00000055B1A0: D5010007 01A80680
	s_add_i32 s21, s20, 1                                      // 00000055B1A8: 81158114
	s_delay_alu instid0(VALU_DEP_2)                            // 00000055B1AC: BF870002
	.long 0xd72c0002                                           // 00000055B1B0: D72C0002
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 00000055B1B4: 02020213
	s_lshr_b32 s19, s21, 31                                    // 00000055B1B8: 85139F15
	.long 0xd72c000d                                           // 00000055B1BC: D72C000D
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 00000055B1C0: 02001F01
	s_add_i32 s21, s21, s19                                    // 00000055B1C4: 81151315
	v_mad_u64_u32 v[9:10], null, v1, s14, s[0:1]               // 00000055B1C8: D6FE7C09 00001D01
	s_ashr_i32 s15, s21, 1                                     // 00000055B1D0: 860F8115
	s_add_u32 s0, s4, s16                                      // 00000055B1D4: 80001004
	.long 0xd72c0013                                           // 00000055B1D8: D72C0013
	v_cndmask_b32_e32 v1, s15, v16, vcc_lo                     // 00000055B1DC: 0202200F
	s_addc_u32 s1, s5, s17                                     // 00000055B1E0: 82011105
	.long 0xd72c0015                                           // 00000055B1E4: D72C0015
	v_cndmask_b32_e32 v0, v7, v14, vcc_lo                      // 00000055B1E8: 02001D07
	.long 0xd72c0017                                           // 00000055B1EC: D72C0017
	v_cndmask_b32_e32 v1, s18, v7, vcc_lo                      // 00000055B1F0: 02020E12
	v_mov_b32_e32 v7, 0                                        // 00000055B1F4: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000055B1F8: BF870153
	v_add3_u32 v10, v21, v10, v13                              // 00000055B1FC: D655000A 04361515
	s_waitcnt vmcnt(1)                                         // 00000055B204: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 00000055B208: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 00000055B210: BF8903F7
	v_bfe_u32 v20, v4, 16, 1                                   // 00000055B214: D6100014 02052104
	v_add3_u32 v3, v3, v11, 0x7fff                             // 00000055B21C: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v1, s[0:1]              // 00000055B228: D6FE7C0B 00020212
	v_add_nc_u32_e32 v1, s15, v19                              // 00000055B230: 4A02260F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000055B234: BF870004
	v_add3_u32 v4, v4, v20, 0x7fff                             // 00000055B238: D6550004 03FE2904 00007FFF
	v_add_nc_u32_e32 v19, v19, v17                             // 00000055B244: 4A262313
	.long 0x7e103983                                           // 00000055B248: 7E103983
	v_lshlrev_b32_e32 v3, 2, v0                                // 00000055B24C: 30060082
	v_min_i32_e32 v20, s20, v1                                 // 00000055B250: 22280214
	v_add3_u32 v21, v2, v12, v23                               // 00000055B254: D6550015 045E1902
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000055B25C: BF870224
	v_and_or_b32 v1, 0xffff0000, v4, v8                        // 00000055B260: D6570001 042208FF FFFF0000
	v_mov_b32_e32 v8, 0                                        // 00000055B26C: 7E100280
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 00000055B270: 7C822913
	ds_store_b32 v3, v1                                        // 00000055B274: D8340000 00000103
	s_waitcnt lgkmcnt(0)                                       // 00000055B27C: BF89FC07
	s_barrier                                                  // 00000055B280: BFBD0000
	buffer_gl0_inv                                             // 00000055B284: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 00000055B28C: BE81206A
	s_cbranch_execz 21                                         // 00000055B290: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1e8>
	v_lshlrev_b32_e32 v1, 1, v19                               // 00000055B294: 30022681
	v_lshlrev_b32_e32 v3, 4, v19                               // 00000055B298: 30062684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000055B29C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000055B2A0: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000055B2A4: 3408069F
	.long 0xd7000001                                           // 00000055B2A8: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 00000055B2AC: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055B2B0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s0                  // 00000055B2B4: D5207C02 00020515
	.long 0xd7000003                                           // 00000055B2BC: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 00000055B2C0: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 00000055B2C4: D5207C04 0002090A
	s_clause 0x1                                               // 00000055B2CC: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 00000055B2D0: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 00000055B2D8: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 00000055B2E0: BF8907F7
	v_cvt_f32_f16_e32 v22, v1                                  // 00000055B2E4: 7E2C1701
	s_or_b32 exec_lo, exec_lo, s1                              // 00000055B2E8: 8C7E017E
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 00000055B2EC: CA100080 18180080
	v_mov_b32_e32 v23, 0                                       // 00000055B2F4: 7E2E0280
	s_and_saveexec_b32 s1, vcc_lo                              // 00000055B2F8: BE81206A
	s_cbranch_execz 401                                        // 00000055B2FC: BFA50191 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x844>
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v1, 32, v19     // 00000055B300: CA200080 180026A0
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v12, 5, v19    // 00000055B308: CA220080 170C2685
	v_mov_b32_e32 v28, v22                                     // 00000055B310: 7E380316
	s_delay_alu instid0(VALU_DEP_3)                            // 00000055B314: BF870003
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v26, 4, v1     // 00000055B318: CA220080 191A0284
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v27, 1, v1     // 00000055B320: CA220080 121A0281
	s_mul_i32 s0, s11, 6                                       // 00000055B328: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 00000055B32C: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000055B330: 8484820A
	s_add_i32 s14, s14, s0                                     // 00000055B334: 810E000E
	s_mul_i32 s16, s10, 6                                      // 00000055B338: 9610860A
	s_mov_b32 s15, 0                                           // 00000055B33C: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000055B340: 848A810A
	s_branch 351                                               // 00000055B344: BFA0015F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x7c4>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000055B348: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 00000055B34C: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000055B354: 8B006A7E
	v_add_nc_u32_e32 v26, 0x200, v26                           // 00000055B358: 4A3434FF 00000200
	s_or_b32 s15, s0, s15                                      // 00000055B360: 8C0F0F00
	v_add_nc_u32_e32 v27, 64, v27                              // 00000055B364: 4A3636C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000055B368: 301A1A82
	ds_load_b32 v43, v13                                       // 00000055B36C: D8D80000 2B00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 00000055B374: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000055B378: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 00000055B37C: 361A1AFF 000003FC
	ds_load_b32 v44, v13                                       // 00000055B384: D8D80000 2C00000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 00000055B38C: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 00000055B390: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 00000055B394: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000055B39C: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000055B3A0: 360A0AFF 000003FC
	ds_load_b32 v45, v13                                       // 00000055B3A8: D8D80000 2D00000D
	ds_load_b32 v46, v5                                        // 00000055B3B0: D8D80000 2E000005
	v_and_b32_e32 v5, 0xff, v6                                 // 00000055B3B8: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 00000055B3C0: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000055B3C4: 300A0A82
	ds_load_b32 v47, v5                                        // 00000055B3C8: D8D80000 2F000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 00000055B3D0: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055B3D4: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000055B3D8: 360A0AFF 000003FC
	ds_load_b32 v48, v5                                        // 00000055B3E0: D8D80000 30000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 00000055B3E8: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000055B3EC: 360A0AFF 000003FC
	ds_load_b32 v49, v5                                        // 00000055B3F4: D8D80000 31000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 00000055B3FC: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055B400: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000055B404: 360A0AFF 000003FC
	ds_load_b32 v50, v5                                        // 00000055B40C: D8D80000 32000005
	v_and_b32_e32 v5, 0xff, v7                                 // 00000055B414: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000055B41C: 300A0A82
	ds_load_b32 v51, v5                                        // 00000055B420: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 00000055B428: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055B42C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000055B430: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 00000055B438: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 00000055B440: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000055B444: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 00000055B44C: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 00000055B454: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055B458: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000055B45C: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 00000055B464: D8D80000 36000005
	v_and_b32_e32 v5, 0xff, v8                                 // 00000055B46C: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000055B474: 300A0A82
	ds_load_b32 v55, v5                                        // 00000055B478: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 00000055B480: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055B484: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000055B488: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 00000055B490: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 00000055B498: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000055B49C: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 00000055B4A4: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 00000055B4AC: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000055B4B0: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000055B4B4: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 00000055B4BC: D8D80000 3A000005
	.long 0xd73c0005                                           // 00000055B4C4: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000055B4C8: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 00000055B4CC: 4A1818FF 00000400
	.long 0xd7006a29                                           // 00000055B4D4: D7006A29
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 00000055B4D8: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000055B4DC: BF870001
	v_add_co_ci_u32_e64 v42, null, s7, v6, vcc_lo              // 00000055B4E0: D5207C2A 01AA0C07
	s_clause 0x3                                               // 00000055B4E8: BF850003
	global_load_b128 v[5:8], v[41:42], off                     // 00000055B4EC: DC5E0000 057C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 00000055B4F4: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 00000055B4FC: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 00000055B504: DC5E0030 257C0029
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000055B50C: BF890CF7
	v_dot2_f32_bf16 v5, v5, v43, 0                             // 00000055B510: CC1A4005 1A025705
	s_waitcnt lgkmcnt(14)                                      // 00000055B518: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055B51C: BF8700A1
	v_dot2_f32_bf16 v5, v6, v44, v5                            // 00000055B520: CC1A4005 1C165906
	s_waitcnt lgkmcnt(13)                                      // 00000055B528: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v45, v5                            // 00000055B52C: CC1A4005 1C165B07
	s_waitcnt lgkmcnt(12)                                      // 00000055B534: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055B538: BF8700A1
	v_dot2_f32_bf16 v5, v8, v46, v5                            // 00000055B53C: CC1A4005 1C165D08
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000055B544: BF8908B7
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 00000055B548: CC1A4005 1C165F1D
	s_waitcnt lgkmcnt(10)                                      // 00000055B550: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055B554: BF8700A1
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 00000055B558: CC1A4005 1C16611E
	s_waitcnt lgkmcnt(9)                                       // 00000055B560: BF89FC97
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 00000055B564: CC1A4005 1C16631F
	s_waitcnt lgkmcnt(8)                                       // 00000055B56C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055B570: BF8700A1
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 00000055B574: CC1A4005 1C166520
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000055B57C: BF890477
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 00000055B580: CC1A4005 1C166721
	s_waitcnt lgkmcnt(6)                                       // 00000055B588: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055B58C: BF8700A1
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 00000055B590: CC1A4005 1C166922
	s_waitcnt lgkmcnt(5)                                       // 00000055B598: BF89FC57
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 00000055B59C: CC1A4005 1C166B23
	s_waitcnt lgkmcnt(4)                                       // 00000055B5A4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055B5A8: BF8700A1
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 00000055B5AC: CC1A4005 1C166D24
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000055B5B4: BF890037
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 00000055B5B8: CC1A4005 1C166F25
	.long 0xd7006a25                                           // 00000055B5C0: D7006A25
	v_cndmask_b32_e32 v0, v41, v10, vcc_lo                     // 00000055B5C4: 02001529
	s_waitcnt lgkmcnt(2)                                       // 00000055B5C8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000055B5CC: BF870132
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 00000055B5D0: CC1A4005 1C167126
	v_add_co_ci_u32_e64 v38, null, s11, v42, vcc_lo            // 00000055B5D8: D5207C26 01AA540B
	s_waitcnt lgkmcnt(1)                                       // 00000055B5E0: BF89FC17
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 00000055B5E4: CC1A4005 1C167327
	s_waitcnt lgkmcnt(0)                                       // 00000055B5EC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055B5F0: BF870091
	v_dot2_f32_bf16 v5, v40, v58, v5                           // 00000055B5F4: CC1A4005 1C167528
	v_fmac_f32_e32 v23, v22, v5                                // 00000055B5FC: 562E0B16
	s_clause 0x3                                               // 00000055B600: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 00000055B604: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 00000055B60C: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 00000055B614: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 00000055B61C: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 00000055B624: BF890FF7
	v_dot2_f32_bf16 v5, v5, v43, 0                             // 00000055B628: CC1A4005 1A025705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055B630: BF870091
	v_dot2_f32_bf16 v5, v6, v44, v5                            // 00000055B634: CC1A4005 1C165906
	v_dot2_f32_bf16 v5, v7, v45, v5                            // 00000055B63C: CC1A4005 1C165B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055B644: BF8700A1
	v_dot2_f32_bf16 v5, v8, v46, v5                            // 00000055B648: CC1A4005 1C165D08
	s_waitcnt vmcnt(2)                                         // 00000055B650: BF890BF7
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 00000055B654: CC1A4005 1C165F1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055B65C: BF870091
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 00000055B660: CC1A4005 1C16611E
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 00000055B668: CC1A4005 1C16631F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055B670: BF8700A1
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 00000055B674: CC1A4005 1C166520
	s_waitcnt vmcnt(1)                                         // 00000055B67C: BF8907F7
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 00000055B680: CC1A4005 1C166721
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055B688: BF870091
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 00000055B68C: CC1A4005 1C166922
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 00000055B694: CC1A4005 1C166B23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055B69C: BF8700A1
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 00000055B6A0: CC1A4005 1C166D24
	s_waitcnt vmcnt(0)                                         // 00000055B6A8: BF8903F7
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 00000055B6AC: CC1A4005 1C166F25
	.long 0xd7006a25                                           // 00000055B6B4: D7006A25
	v_cndmask_b32_e32 v0, v41, v4, vcc_lo                      // 00000055B6B8: 02000929
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000055B6BC: BF870122
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 00000055B6C0: CC1A4005 1C167126
	v_add_co_ci_u32_e64 v38, null, s5, v42, vcc_lo             // 00000055B6C8: D5207C26 01AA5405
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 00000055B6D0: CC1A4005 1C167327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055B6D8: BF870091
	v_dot2_f32_bf16 v5, v40, v58, v5                           // 00000055B6DC: CC1A4005 1C167528
	v_fmac_f32_e32 v25, v22, v5                                // 00000055B6E4: 56320B16
	s_clause 0x3                                               // 00000055B6E8: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 00000055B6EC: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 00000055B6F4: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 00000055B6FC: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 00000055B704: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 00000055B70C: BF890FF7
	v_dot2_f32_bf16 v5, v5, v43, 0                             // 00000055B710: CC1A4005 1A025705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055B718: BF870091
	v_dot2_f32_bf16 v5, v6, v44, v5                            // 00000055B71C: CC1A4005 1C165906
	v_dot2_f32_bf16 v5, v7, v45, v5                            // 00000055B724: CC1A4005 1C165B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055B72C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v46, v5                            // 00000055B730: CC1A4005 1C165D08
	s_waitcnt vmcnt(2)                                         // 00000055B738: BF890BF7
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 00000055B73C: CC1A4005 1C165F1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055B744: BF870091
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 00000055B748: CC1A4005 1C16611E
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 00000055B750: CC1A4005 1C16631F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055B758: BF8700A1
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 00000055B75C: CC1A4005 1C166520
	s_waitcnt vmcnt(1)                                         // 00000055B764: BF8907F7
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 00000055B768: CC1A4005 1C166721
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055B770: BF870091
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 00000055B774: CC1A4005 1C166922
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 00000055B77C: CC1A4005 1C166B23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055B784: BF8700A1
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 00000055B788: CC1A4005 1C166D24
	s_waitcnt vmcnt(0)                                         // 00000055B790: BF8903F7
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 00000055B794: CC1A4005 1C166F25
	.long 0xd7006a25                                           // 00000055B79C: D7006A25
	v_cndmask_b32_e32 v0, v41, v16, vcc_lo                     // 00000055B7A0: 02002129
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000055B7A4: BF870122
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 00000055B7A8: CC1A4005 1C167126
	v_add_co_ci_u32_e64 v38, null, s14, v42, vcc_lo            // 00000055B7B0: D5207C26 01AA540E
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 00000055B7B8: CC1A4005 1C167327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055B7C0: BF870091
	v_dot2_f32_bf16 v5, v40, v58, v5                           // 00000055B7C4: CC1A4005 1C167528
	v_fmac_f32_e32 v24, v22, v5                                // 00000055B7CC: 56300B16
	s_clause 0x3                                               // 00000055B7D0: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 00000055B7D4: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 00000055B7DC: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 00000055B7E4: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 00000055B7EC: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 00000055B7F4: BF890FF7
	v_dot2_f32_bf16 v5, v5, v43, 0                             // 00000055B7F8: CC1A4005 1A025705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000055B800: BF870121
	v_dot2_f32_bf16 v5, v6, v44, v5                            // 00000055B804: CC1A4005 1C165906
	v_mov_b32_e32 v6, v2                                       // 00000055B80C: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v45, v5                            // 00000055B810: CC1A4005 1C165B07
	v_mov_b32_e32 v7, v3                                       // 00000055B818: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000055B81C: BF870132
	v_dot2_f32_bf16 v5, v8, v46, v5                            // 00000055B820: CC1A4005 1C165D08
	v_mov_b32_e32 v8, v4                                       // 00000055B828: 7E100304
	s_waitcnt vmcnt(2)                                         // 00000055B82C: BF890BF7
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 00000055B830: CC1A4005 1C165F1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055B838: BF870091
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 00000055B83C: CC1A4005 1C16611E
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 00000055B844: CC1A4005 1C16631F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055B84C: BF8700A1
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 00000055B850: CC1A4005 1C166520
	s_waitcnt vmcnt(1)                                         // 00000055B858: BF8907F7
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 00000055B85C: CC1A4005 1C166721
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055B864: BF870091
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 00000055B868: CC1A4005 1C166922
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 00000055B870: CC1A4005 1C166B23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055B878: BF8700A1
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 00000055B87C: CC1A4005 1C166D24
	s_waitcnt vmcnt(0)                                         // 00000055B884: BF8903F7
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 00000055B888: CC1A4005 1C166F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055B890: BF870091
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 00000055B894: CC1A4005 1C167126
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 00000055B89C: CC1A4005 1C167327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055B8A4: BF870091
	v_dot2_f32_bf16 v5, v40, v58, v5                           // 00000055B8A8: CC1A4005 1C167528
	v_dual_fmac_f32 v18, v22, v5 :: v_dual_mov_b32 v5, v1      // 00000055B8B0: C8100B16 12040101
	v_mov_b32_e32 v22, v28                                     // 00000055B8B8: 7E2C031C
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000055B8BC: 917E0F7E
	s_cbranch_execz 31                                         // 00000055B8C0: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x840>
	s_waitcnt vmcnt(0)                                         // 00000055B8C4: BF8903F7
	v_dual_mov_b32 v2, v6 :: v_dual_add_nc_u32 v19, 32, v19    // 00000055B8C8: CA200106 021226A0
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v4, v8             // 00000055B8D0: CA100105 01040108
	v_mov_b32_e32 v3, v7                                       // 00000055B8D8: 7E060307
	s_mov_b32 s17, exec_lo                                     // 00000055B8DC: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000055B8E0: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 00000055B8E4: 7C8C2913
	.long 0xd4c1007e                                           // 00000055B8E8: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 00000055B8EC: 02022913
	s_cbranch_execz 65173                                      // 00000055B8F0: BFA5FE95 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x248>
	v_ashrrev_i32_e32 v2, 31, v27                              // 00000055B8F4: 3404369F
	v_ashrrev_i32_e32 v4, 31, v26                              // 00000055B8F8: 3408349F
	.long 0xd7000001                                           // 00000055B8FC: D7000001
	v_cndmask_b32_e32 v1, v11, v27, vcc_lo                     // 00000055B900: 0202370B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055B904: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s0                  // 00000055B908: D5207C02 00020515
	.long 0xd7000003                                           // 00000055B910: D7000003
	v_cndmask_b32_e32 v1, v9, v26, vcc_lo                      // 00000055B914: 02023509
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 00000055B918: D5207C04 0002090A
	s_clause 0x1                                               // 00000055B920: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 00000055B924: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 00000055B92C: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000055B934: BF8907F7
	v_cvt_f32_f16_e32 v28, v13                                 // 00000055B938: 7E38170D
	s_branch 65154                                             // 00000055B93C: BFA0FE82 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x248>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000055B940: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055B944: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000055B948: 8C7E017E
	.long 0xd71f0001                                           // 00000055B94C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000055B950: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000055B954: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000055B958: 3A040290
	s_waitcnt vmcnt(0)                                         // 00000055B95C: BF8903F7
	v_xor_b32_e32 v6, 8, v1                                    // 00000055B960: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 00000055B964: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000055B968: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000055B96C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000055B970: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000055B974: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000055B978: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000055B97C: 30040482
	ds_bpermute_b32 v5, v2, v24                                // 00000055B980: DACC0000 05001802
	s_waitcnt lgkmcnt(0)                                       // 00000055B988: BF89FC07
	v_add_f32_e32 v5, v24, v5                                  // 00000055B98C: 060A0B18
	ds_bpermute_b32 v3, v2, v23                                // 00000055B990: DACC0000 03001702
	ds_bpermute_b32 v4, v2, v25                                // 00000055B998: DACC0000 04001902
	ds_bpermute_b32 v2, v2, v18                                // 00000055B9A0: DACC0000 02001202
	s_waitcnt lgkmcnt(2)                                       // 00000055B9A8: BF89FC27
	v_dual_add_f32 v3, v23, v3 :: v_dual_cndmask_b32 v6, v1, v6// 00000055B9AC: C9120717 03060D01
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000055B9B4: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000055B9B8: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 00000055B9BC: 300C0C82
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 00000055B9C0: 02141501
	ds_bpermute_b32 v9, v6, v5                                 // 00000055B9C4: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 00000055B9CC: BF89FC07
	v_dual_add_f32 v5, v5, v9 :: v_dual_lshlrev_b32 v10, 2, v10// 00000055B9D0: C9221305 050A1482
	ds_bpermute_b32 v7, v6, v3                                 // 00000055B9D8: DACC0000 07000306
	s_waitcnt lgkmcnt(0)                                       // 00000055B9E0: BF89FC07
	v_dual_add_f32 v2, v18, v2 :: v_dual_add_f32 v3, v3, v7    // 00000055B9E4: C9080512 02020F03
	v_add_f32_e32 v4, v25, v4                                  // 00000055B9EC: 06080919
	ds_bpermute_b32 v8, v6, v4                                 // 00000055B9F0: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 00000055B9F8: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 00000055BA00: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 00000055BA04: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 00000055BA08: DACC0000 0600030A
	ds_bpermute_b32 v9, v10, v2                                // 00000055BA10: DACC0000 0900020A
	s_waitcnt lgkmcnt(1)                                       // 00000055BA18: BF89FC17
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v8     // 00000055BA1C: C9080D03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 00000055BA24: DACC0000 0800050A
	s_waitcnt lgkmcnt(1)                                       // 00000055BA2C: BF89FC17
	v_add_f32_e32 v6, v2, v9                                   // 00000055BA30: 060C1302
	ds_bpermute_b32 v7, v10, v4                                // 00000055BA34: DACC0000 0700040A
	v_xor_b32_e32 v10, 2, v1                                   // 00000055BA3C: 3A140282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055BA40: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000055BA44: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 00000055BA48: 02141501
	s_waitcnt lgkmcnt(1)                                       // 00000055BA4C: BF89FC17
	v_dual_add_f32 v5, v5, v8 :: v_dual_lshlrev_b32 v10, 2, v10// 00000055BA50: C9221105 050A1482
	ds_bpermute_b32 v2, v10, v3                                // 00000055BA58: DACC0000 0200030A
	s_waitcnt lgkmcnt(1)                                       // 00000055BA60: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 00000055BA64: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 00000055BA68: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 00000055BA70: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 00000055BA78: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 00000055BA80: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055BA84: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000055BA88: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 00000055BA8C: 02021501
	s_waitcnt lgkmcnt(3)                                       // 00000055BA90: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 00000055BA94: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 00000055BA9C: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 00000055BAA0: 06061105
	s_waitcnt lgkmcnt(0)                                       // 00000055BAA4: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 00000055BAA8: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 00000055BAB0: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 00000055BAB8: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 00000055BAC0: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 00000055BAC8: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v17                                   // 00000055BAD0: 7D942280
	s_cbranch_execz 11                                         // 00000055BAD4: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xa04>
	s_waitcnt lgkmcnt(0)                                       // 00000055BAD8: BF89FC07
	v_dual_add_f32 v6, v2, v6 :: v_dual_lshlrev_b32 v9, 4, v16 // 00000055BADC: C9220D02 06082084
	v_dual_add_f32 v8, v5, v8 :: v_dual_add_f32 v7, v3, v7     // 00000055BAE4: C9081105 08060F03
	v_add_f32_e32 v5, v1, v4                                   // 00000055BAEC: 060A0901
	s_delay_alu instid0(VALU_DEP_3)                            // 00000055BAF0: BF870003
	v_lshl_or_b32 v1, v15, 5, v9                               // 00000055BAF4: D6560001 04250B0F
	ds_store_b128 v1, v[5:8] offset:1024                       // 00000055BAFC: DB7C0400 00000501
	s_or_b32 exec_lo, exec_lo, s0                              // 00000055BB04: 8C7E007E
	v_or_b32_e32 v1, s2, v14                                   // 00000055BB08: 38021C02
	v_mov_b32_e32 v2, s3                                       // 00000055BB0C: 7E040203
	.long 0xd44c0000                                           // 00000055BB10: D44C0000
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 00000055BB14: 02020090
	s_waitcnt lgkmcnt(0)                                       // 00000055BB18: BF89FC07
	s_barrier                                                  // 00000055BB1C: BFBD0000
	buffer_gl0_inv                                             // 00000055BB20: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000055BB28: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 00000055BB2C: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000055BB30: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000055BB34: BE812000
	s_cbranch_execz 40                                         // 00000055BB38: BFA50028 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xadc>
	v_and_b32_e32 v0, 3, v0                                    // 00000055BB3C: 36000083
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055BB40: BF870091
	v_lshlrev_b32_e32 v3, 2, v0                                // 00000055BB44: 30060082
	v_lshl_or_b32 v3, v14, 5, v3                               // 00000055BB48: D6560003 040D0B0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055BB50: BF8700B1
	v_add_nc_u32_e32 v3, 0x400, v3                             // 00000055BB54: 4A0606FF 00000400
	ds_load_2addr_b32 v[6:7], v3 offset1:4                     // 00000055BB5C: D8DC0400 06000003
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 00000055BB64: D6FE7C03 0202000C
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 00000055BB6C: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000055BB74: BF870131
	.long 0xd73c0003                                           // 00000055BB78: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000055BB7C: 02020681
	s_waitcnt lgkmcnt(0)                                       // 00000055BB80: BF89FC07
	v_add_f32_e32 v0, 0, v6                                    // 00000055BB84: 06000C80
	.long 0xd7006a03                                           // 00000055BB88: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 00000055BB8C: 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000055BB90: BF8701B2
	v_add_f32_e32 v5, v0, v7                                   // 00000055BB94: 060A0F00
	.long 0xd73c0000                                           // 00000055BB98: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000055BB9C: 02020281
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000055BBA0: D5207C04 01AA0809
	v_bfe_u32 v2, v5, 16, 1                                    // 00000055BBA8: D6100002 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055BBB0: BF870093
	.long 0xd7006a00                                           // 00000055BBB4: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000055BBB8: 02020103
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 00000055BBBC: D5207C01 01AA0304
	s_delay_alu instid0(VALU_DEP_3)                            // 00000055BBC4: BF870003
	v_add3_u32 v2, v5, v2, 0x7fff                              // 00000055BBC8: D6550002 03FE0505 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000055BBD4: DC960000 007C0200
	s_endpgm                                                   // 00000055BBDC: BFB00000
		...

