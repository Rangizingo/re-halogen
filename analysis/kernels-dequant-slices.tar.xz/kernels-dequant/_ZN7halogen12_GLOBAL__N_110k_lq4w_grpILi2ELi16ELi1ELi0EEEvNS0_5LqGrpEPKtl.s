0000000000298500 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 000000298500: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 000000298504: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 00000029850C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 000000298514: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 00000029851C: F4000180 F8000118
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v17, 15, v0        // 000000298524: CA240080 1810008F
	v_lshrrev_b32_e32 v2, 4, v0                                // 00000029852C: 32040084
	v_dual_mov_b32 v19, 0 :: v_dual_lshlrev_b32 v16, 2, v0     // 000000298530: CA220080 13100082
	s_delay_alu instid0(VALU_DEP_2)                            // 000000298538: BF870002
	v_lshlrev_b32_e32 v3, 2, v2                                // 00000029853C: 30060482
	s_waitcnt lgkmcnt(0)                                       // 000000298540: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 000000298544: BF028103
	s_cselect_b32 s7, -1, 0                                    // 000000298548: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000029854C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 000000298550: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000298554: BF870009
	s_and_b32 s4, s7, s4                                       // 000000298558: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000029855C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 000000298560: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 000000298568: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000029856C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 000000298570: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000298574: BF870009
	s_and_b32 s4, s7, s5                                       // 000000298578: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000029857C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 000000298580: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 000000298584: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000298588: BF030602
	v_lshlrev_b32_e32 v1, 2, v17                               // 00000029858C: 30022282
	s_cselect_b32 s6, -1, 0                                    // 000000298590: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000298594: BF8704D9
	s_and_b32 s3, s3, s6                                       // 000000298598: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 00000029859C: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000002985A0: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000002985A4: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000002985A8: 98030483
	s_mulk_i32 s3, 0x48                                        // 0000002985AC: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002985B0: BF870009
	s_add_u32 s16, s0, s3                                      // 0000002985B4: 80100300
	s_addc_u32 s17, s1, 0                                      // 0000002985B8: 82118001
	s_clause 0x1                                               // 0000002985BC: BF850001
	s_load_b256 s[4:11], s[16:17], 0x18                        // 0000002985C0: F40C0108 F8000018
	s_load_b64 s[18:19], s[16:17], null                        // 0000002985C8: F4040488 F8000000
	s_waitcnt lgkmcnt(0)                                       // 0000002985D0: BF89FC07
	.long 0xd4540003                                           // 0000002985D4: D4540003
	v_cndmask_b32_e32 v0, s10, v136, vcc_lo                    // 0000002985D8: 0201100A
	s_and_b32 s12, s3, exec_lo                                 // 0000002985DC: 8B0C7E03
	s_load_b128 s[12:15], s[0:1], 0x128                        // 0000002985E0: F4080300 F8000128
	s_clause 0x1                                               // 0000002985E8: BF850001
	global_load_b32 v1, v1, s[18:19]                           // 0000002985EC: DC520000 01120001
	global_load_b32 v3, v3, s[18:19]                           // 0000002985F4: DC520000 03120003
	s_cselect_b32 s24, 1, 16                                   // 0000002985FC: 98189081
	s_cselect_b32 s0, 0, 4                                     // 000000298600: 98008480
	s_add_i32 s25, s24, -1                                     // 000000298604: 8119C118
	v_lshrrev_b32_e32 v18, s0, v2                              // 000000298608: 32240400
	v_and_b32_e32 v20, s25, v2                                 // 00000029860C: 36280419
	s_waitcnt vmcnt(1)                                         // 000000298610: BF8907F7
	v_bfe_u32 v4, v1, 16, 1                                    // 000000298614: D6100004 02052101
	s_waitcnt vmcnt(0)                                         // 00000029861C: BF8903F7
	v_bfe_u32 v5, v3, 16, 1                                    // 000000298620: D6100005 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000298628: BF8701A2
	v_add3_u32 v1, v1, v4, 0x7fff                              // 00000029862C: D6550001 03FE0901 00007FFF
	.long 0x7f083880                                           // 000000298638: 7F083880
	v_add3_u32 v3, v3, v5, 0x7fff                              // 00000029863C: D6550003 03FE0B03 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000298648: BF870093
	.long 0x7e083981                                           // 00000029864C: 7E083981
	v_and_or_b32 v1, 0xffff0000, v3, v4                        // 000000298650: D6570001 041206FF FFFF0000
	ds_store_b32 v16, v1                                       // 00000029865C: D8340000 00000110
	v_cvt_f32_ubyte0_e32 v1, s24                               // 000000298664: 7E022218
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000298668: BF870291
	v_rcp_iflag_f32_e32 v1, v1                                 // 00000029866C: 7E025701
	v_readfirstlane_b32 s1, v1                                 // 000000298670: 7E020501
	v_mov_b32_e32 v1, 0                                        // 000000298674: 7E020280
	s_mul_f32 s22, s1, 0x4f7ffffe                              // 000000298678: A216FF01 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3)                          // 000000298680: BF87000B
	s_cvt_u32_f32 s26, s22                                     // 000000298684: BE9A6716
	s_waitcnt lgkmcnt(0)                                       // 000000298688: BF89FC07
	s_barrier                                                  // 00000029868C: BFBD0000
	buffer_gl0_inv                                             // 000000298690: E0AC0000 00000000
	s_load_b32 s20, s[16:17], 0x40                             // 000000298698: F4000508 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002986A0: BF89FC07
	s_sub_i32 s0, s2, s20                                      // 0000002986A4: 81801402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002986A8: BF870009
	s_ashr_i32 s1, s0, 31                                      // 0000002986AC: 86019F00
	s_and_b32 s3, s3, exec_lo                                  // 0000002986B0: 8B037E03
	s_cselect_b32 s3, 4, 0                                     // 0000002986B4: 98038084
	s_lshr_b32 s20, s15, 31                                    // 0000002986B8: 85149F0F
	s_lshl_b64 s[0:1], s[0:1], s3                              // 0000002986BC: 84800300
	s_add_u32 s20, s14, s20                                    // 0000002986C0: 8014140E
	s_addc_u32 s21, s15, 0                                     // 0000002986C4: 8215800F
	s_ashr_i32 s3, s15, 31                                     // 0000002986C8: 86039F0F
	s_ashr_i64 s[20:21], s[20:21], 1                           // 0000002986CC: 86948114
	s_lshr_b32 s3, s3, 27                                      // 0000002986D0: 85039B03
	.long 0xd7000009                                           // 0000002986D4: D7000009
	v_cndmask_b32_e32 v1, s0, v18, vcc_lo                      // 0000002986D8: 02022400
	s_add_u32 s22, s14, s3                                     // 0000002986DC: 8016030E
	s_addc_u32 s23, s15, 0                                     // 0000002986E0: 8217800F
	s_sub_i32 s3, 0, s24                                       // 0000002986E4: 81831880
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000002986E8: 85968516
	s_mul_i32 s3, s3, s26                                      // 0000002986EC: 96031A03
	s_add_i32 s23, s25, s22                                    // 0000002986F0: 81171619
	s_mul_hi_u32 s3, s26, s3                                   // 0000002986F4: 9683031A
	s_abs_i32 s27, s23                                         // 0000002986F8: BE9B1517
	s_add_i32 s26, s26, s3                                     // 0000002986FC: 811A031A
	v_add_co_ci_u32_e64 v10, null, s1, 0, s0                   // 000000298700: D5207C0A 00010001
	s_mul_hi_u32 s3, s27, s26                                  // 000000298708: 96831A1B
	s_ashr_i32 s1, s23, 31                                     // 00000029870C: 86019F17
	s_mul_i32 s0, s3, s24                                      // 000000298710: 96001803
	s_add_i32 s26, s3, 1                                       // 000000298714: 811A8103
	s_sub_i32 s23, s27, s0                                     // 000000298718: 8197001B
	.long 0xd4540000                                           // 00000029871C: D4540000
	v_cndmask_b32_e32 v1, s10, v9, vcc_lo                      // 000000298720: 0202120A
	s_sub_i32 s27, s23, s24                                    // 000000298724: 819B1817
	s_cmp_ge_u32 s23, s24                                      // 000000298728: BF091817
	s_cselect_b32 s3, s26, s3                                  // 00000029872C: 9803031A
	s_cselect_b32 s23, s27, s23                                // 000000298730: 9817171B
	s_add_i32 s26, s3, 1                                       // 000000298734: 811A8103
	s_cmp_ge_u32 s23, s24                                      // 000000298738: BF091817
	v_cndmask_b32_e64 v3, 0, v10, s0                           // 00000029873C: D5010003 00021480
	s_cselect_b32 s3, s26, s3                                  // 000000298744: 9803031A
	v_cndmask_b32_e64 v2, 0, v9, s0                            // 000000298748: D5010002 00021280
	s_xor_b32 s3, s3, s1                                       // 000000298750: 8D030103
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000298754: BF870009
	s_sub_i32 s1, s3, s1                                       // 000000298758: 81810103
	s_add_u32 s4, s18, s4                                      // 00000029875C: 80040412
	.long 0xd72c0005                                           // 000000298760: D72C0005
	v_cndmask_b32_e32 v1, s1, v20, vcc_lo                      // 000000298764: 02022801
	s_addc_u32 s5, s19, s5                                     // 000000298768: 82050513
	s_add_u32 s6, s18, s6                                      // 00000029876C: 80060612
	.long 0xd72c0004                                           // 000000298770: D72C0004
	v_cndmask_b32_e32 v0, v3, v20, vcc_lo                      // 000000298774: 02002903
	.long 0xd72c0006                                           // 000000298778: D72C0006
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 00000029877C: 02001103
	s_addc_u32 s7, s19, s7                                     // 000000298780: 82070713
	.long 0xd72c0007                                           // 000000298784: D72C0007
	v_cndmask_b32_e32 v0, v2, v21, vcc_lo                      // 000000298788: 02002B02
	.long 0xd72c0008                                           // 00000029878C: D72C0008
	v_cndmask_b32_e32 v0, v2, v9, vcc_lo                       // 000000298790: 02001302
	v_add_nc_u32_e32 v3, s1, v5                                // 000000298794: 4A060A01
	v_mad_u64_u32 v[11:12], null, v2, s20, s[4:5]              // 000000298798: D6FE7C0B 00102902
	v_mad_u64_u32 v[13:14], null, v2, s8, s[6:7]               // 0000002987A0: D6FE7C0D 00181102
	v_add_nc_u32_e32 v21, v5, v17                              // 0000002987A8: 4A2A2305
	.long 0xd4510003                                           // 0000002987AC: D4510003
	v_cndmask_b32_e32 v0, s10, v137, vcc_lo                    // 0000002987B0: 0201120A
	v_min_i32_e32 v22, s22, v3                                 // 0000002987B4: 222C0616
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 0000002987B8: CA100080 02020080
	v_add3_u32 v12, v4, v12, v7                                // 0000002987C0: D655000C 041E1904
	v_add3_u32 v23, v6, v14, v8                                // 0000002987C8: D6550017 04221D06
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002987D0: BF870004
	v_cmp_lt_i32_e32 vcc_lo, v21, v22                          // 0000002987D4: 7C822D15
	v_mov_b32_e32 v4, 0                                        // 0000002987D8: 7E080280
	s_and_saveexec_b32 s4, vcc_lo                              // 0000002987DC: BE84206A
	s_cbranch_execz 21                                         // 0000002987E0: BFA50015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x338>
	v_lshlrev_b32_e32 v1, 1, v21                               // 0000002987E4: 30022A81
	v_lshlrev_b32_e32 v3, 4, v21                               // 0000002987E8: 30062A84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002987EC: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002987F0: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002987F4: 3408069F
	.long 0xd7000101                                           // 0000002987F8: D7000101
	v_cndmask_b32_e32 v1, v13, v1, vcc_lo                      // 0000002987FC: 0202030D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000298800: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v23, v2, s1                  // 000000298804: D5207C02 00060517
	.long 0xd7000103                                           // 00000029880C: D7000103
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 000000298810: 0202070B
	v_add_co_ci_u32_e64 v4, null, v12, v4, s1                  // 000000298814: D5207C04 0006090C
	s_clause 0x1                                               // 00000029881C: BF850001
	global_load_d16_b16 v6, v[1:2], off                        // 000000298820: DC820000 067C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000298828: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000298830: BF8907F7
	v_cvt_f32_f16_e32 v24, v6                                  // 000000298834: 7E301706
	s_or_b32 exec_lo, exec_lo, s4                              // 000000298838: 8C7E047E
	v_mov_b32_e32 v25, 0                                       // 00000029883C: 7E320280
	s_and_saveexec_b32 s6, vcc_lo                              // 000000298840: BE86206A
	s_cbranch_execz 266                                        // 000000298844: BFA5010A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x770>
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v6, 5, v17     // 000000298848: CA220080 19062285
	v_dual_mov_b32 v28, v24 :: v_dual_add_nc_u32 v7, 16, v21   // 000000298850: CA200118 1C062A90
	s_mov_b32 s7, 0                                            // 000000298858: BE870080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029885C: BF870112
	v_lshl_add_u32 v14, v5, 5, v6                              // 000000298860: D646000E 04190B05
	v_dual_mov_b32 v19, 0 :: v_dual_lshlrev_b32 v26, 4, v7     // 000000298868: CA220080 131A0E84
	v_lshlrev_b32_e32 v27, 1, v7                               // 000000298870: 30360E81
	s_lshl_b64 s[4:5], s[14:15], 1                             // 000000298874: 8484810E
	s_branch 221                                               // 000000298878: BFA000DD <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x6f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000029887C: 8C7E087E
	v_ashrrev_i32_e32 v15, 31, v14                             // 000000298880: 341E1C9F
	v_lshrrev_b32_e32 v61, 6, v1                               // 000000298884: 327A0286
	v_lshrrev_b32_e32 v62, 14, v1                              // 000000298888: 327C028E
	v_and_b32_e32 v63, 0xff, v2                                // 00000029888C: 367E04FF 000000FF
	v_lshrrev_b32_e32 v64, 6, v2                               // 000000298894: 32800486
	.long 0xd73c001d                                           // 000000298898: D73C001D
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 00000029889C: 02021C81
	v_and_b32_e32 v15, 0xff, v1                                // 0000002988A0: 361E02FF 000000FF
	v_and_b32_e32 v61, 0x3fc, v61                              // 0000002988A8: 367A7AFF 000003FC
	v_and_b32_e32 v62, 0x3fc, v62                              // 0000002988B0: 367C7CFF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000002988B8: 32020296
	v_lshrrev_b32_e32 v65, 14, v2                              // 0000002988BC: 3282048E
	.long 0xd7000135                                           // 0000002988C0: D7000135
	v_cndmask_b32_e32 v1, s12, v29, vcc_lo                     // 0000002988C4: 02023A0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002988C8: BF8701A1
	v_add_co_ci_u32_e64 v54, null, s13, v30, s1                // 0000002988CC: D5207C36 00063C0D
	v_lshlrev_b32_e32 v15, 2, v15                              // 0000002988D4: 301E1E82
	.long 0xd7000139                                           // 0000002988D8: D7000139
	v_cndmask_b32_e32 v0, v53, v4, vcc_lo                      // 0000002988DC: 02000935
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002988E0: BF870001
	v_add_co_ci_u32_e64 v58, null, s5, v54, s1                 // 0000002988E4: D5207C3A 00066C05
	ds_load_b32 v15, v15                                       // 0000002988EC: D8D80000 0F00000F
	ds_load_b32 v61, v61                                       // 0000002988F4: D8D80000 3D00003D
	ds_load_b32 v62, v62                                       // 0000002988FC: D8D80000 3E00003E
	s_clause 0x7                                               // 000000298904: BF850007
	global_load_b128 v[29:32], v[53:54], off                   // 000000298908: DC5E0000 1D7C0035
	global_load_b128 v[33:36], v[57:58], off                   // 000000298910: DC5E0000 217C0039
	global_load_b128 v[37:40], v[53:54], off offset:16         // 000000298918: DC5E0010 257C0035
	global_load_b128 v[41:44], v[57:58], off offset:16         // 000000298920: DC5E0010 297C0039
	global_load_b128 v[45:48], v[53:54], off offset:32         // 000000298928: DC5E0020 2D7C0035
	global_load_b128 v[49:52], v[57:58], off offset:32         // 000000298930: DC5E0020 317C0039
	global_load_b128 v[53:56], v[53:54], off offset:48         // 000000298938: DC5E0030 357C0035
	global_load_b128 v[57:60], v[57:58], off offset:48         // 000000298940: DC5E0030 397C0039
	v_lshrrev_b32_e32 v2, 22, v2                               // 000000298948: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000029894C: 360202FF 000003FC
	v_lshlrev_b32_e32 v63, 2, v63                              // 000000298954: 307E7E82
	v_and_b32_e32 v64, 0x3fc, v64                              // 000000298958: 368080FF 000003FC
	v_and_b32_e32 v65, 0x3fc, v65                              // 000000298960: 368282FF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 000000298968: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 000000298970: D8D80000 01000001
	ds_load_b32 v63, v63                                       // 000000298978: D8D80000 3F00003F
	ds_load_b32 v64, v64                                       // 000000298980: D8D80000 40000040
	ds_load_b32 v65, v65                                       // 000000298988: D8D80000 41000041
	ds_load_b32 v2, v2                                         // 000000298990: D8D80000 02000002
	v_add_nc_u32_e32 v26, 0x100, v26                           // 000000298998: 4A3434FF 00000100
	v_add_nc_u32_e32 v27, 32, v27                              // 0000002989A0: 4A3636A0
	v_add_nc_u32_e32 v14, 0x200, v14                           // 0000002989A4: 4A1C1CFF 00000200
	s_and_b32 s1, exec_lo, vcc_lo                              // 0000002989AC: 8B016A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002989B0: BF870009
	s_or_b32 s7, s1, s7                                        // 0000002989B4: 8C070701
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000002989B8: BF891C77
	v_dot2_f32_bf16 v29, v29, v15, 0                           // 0000002989BC: CC1A401D 1A021F1D
	s_waitcnt vmcnt(6)                                         // 0000002989C4: BF891BF7
	v_dot2_f32_bf16 v15, v33, v15, 0                           // 0000002989C8: CC1A400F 1A021F21
	v_and_b32_e32 v33, 0xff, v3                                // 0000002989D0: 364206FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 0000002989D8: BF89FC67
	v_dot2_f32_bf16 v29, v30, v61, v29                         // 0000002989DC: CC1A401D 1C767B1E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002989E4: BF870003
	v_dot2_f32_bf16 v15, v34, v61, v15                         // 0000002989E8: CC1A400F 1C3E7B22
	v_lshrrev_b32_e32 v30, 6, v3                               // 0000002989F0: 323C0686
	v_lshrrev_b32_e32 v34, 14, v3                              // 0000002989F4: 3244068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000002989F8: 32060696
	s_waitcnt lgkmcnt(5)                                       // 0000002989FC: BF89FC57
	v_dot2_f32_bf16 v29, v31, v62, v29                         // 000000298A00: CC1A401D 1C767D1F
	v_dot2_f32_bf16 v15, v35, v62, v15                         // 000000298A08: CC1A400F 1C3E7D23
	v_and_b32_e32 v30, 0x3fc, v30                              // 000000298A10: 363C3CFF 000003FC
	v_and_b32_e32 v31, 0xff, v4                                // 000000298A18: 363E08FF 000000FF
	v_lshrrev_b32_e32 v35, 6, v4                               // 000000298A20: 32460886
	s_waitcnt lgkmcnt(4)                                       // 000000298A24: BF89FC47
	v_dot2_f32_bf16 v29, v32, v1, v29                          // 000000298A28: CC1A401D 1C760320
	v_dot2_f32_bf16 v1, v36, v1, v15                           // 000000298A30: CC1A4001 1C3E0324
	v_lshlrev_b32_e32 v15, 2, v33                              // 000000298A38: 301E4282
	v_and_b32_e32 v32, 0x3fc, v34                              // 000000298A3C: 364044FF 000003FC
	v_lshrrev_b32_e32 v61, 14, v4                              // 000000298A44: 327A088E
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 000000298A48: BF891437
	v_dot2_f32_bf16 v29, v37, v63, v29                         // 000000298A4C: CC1A401D 1C767F25
	s_waitcnt vmcnt(4)                                         // 000000298A54: BF8913F7
	v_dot2_f32_bf16 v1, v41, v63, v1                           // 000000298A58: CC1A4001 1C067F29
	ds_load_b32 v15, v15                                       // 000000298A60: D8D80000 0F00000F
	ds_load_b32 v30, v30                                       // 000000298A68: D8D80000 1E00001E
	ds_load_b32 v32, v32                                       // 000000298A70: D8D80000 20000020
	s_waitcnt lgkmcnt(5)                                       // 000000298A78: BF89FC57
	v_dot2_f32_bf16 v29, v38, v64, v29                         // 000000298A7C: CC1A401D 1C768126
	v_dot2_f32_bf16 v1, v42, v64, v1                           // 000000298A84: CC1A4001 1C06812A
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000298A8C: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 000000298A90: 360606FF 000003FC
	v_lshlrev_b32_e32 v31, 2, v31                              // 000000298A98: 303E3E82
	s_waitcnt lgkmcnt(4)                                       // 000000298A9C: BF89FC47
	v_dot2_f32_bf16 v29, v39, v65, v29                         // 000000298AA0: CC1A401D 1C768327
	v_dot2_f32_bf16 v1, v43, v65, v1                           // 000000298AA8: CC1A4001 1C06832B
	v_and_b32_e32 v33, 0x3fc, v35                              // 000000298AB0: 364246FF 000003FC
	v_and_b32_e32 v34, 0x3fc, v61                              // 000000298AB8: 36447AFF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000298AC0: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 000000298AC8: BF89FC37
	v_dot2_f32_bf16 v29, v40, v2, v29                          // 000000298ACC: CC1A401D 1C760528
	v_dot2_f32_bf16 v1, v44, v2, v1                            // 000000298AD4: CC1A4001 1C06052C
	ds_load_b32 v2, v3                                         // 000000298ADC: D8D80000 02000003
	ds_load_b32 v3, v31                                        // 000000298AE4: D8D80000 0300001F
	ds_load_b32 v31, v33                                       // 000000298AEC: D8D80000 1F000021
	ds_load_b32 v33, v34                                       // 000000298AF4: D8D80000 21000022
	ds_load_b32 v34, v4                                        // 000000298AFC: D8D80000 22000004
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 000000298B04: BF890C77
	v_dot2_f32_bf16 v4, v45, v15, v29                          // 000000298B08: CC1A4004 1C761F2D
	s_waitcnt vmcnt(2)                                         // 000000298B10: BF890BF7
	v_dot2_f32_bf16 v1, v49, v15, v1                           // 000000298B14: CC1A4001 1C061F31
	s_waitcnt lgkmcnt(6)                                       // 000000298B1C: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000298B20: BF870112
	v_dot2_f32_bf16 v4, v46, v30, v4                           // 000000298B24: CC1A4004 1C123D2E
	v_dot2_f32_bf16 v1, v50, v30, v1                           // 000000298B2C: CC1A4001 1C063D32
	s_waitcnt lgkmcnt(5)                                       // 000000298B34: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000298B38: BF870112
	v_dot2_f32_bf16 v4, v47, v32, v4                           // 000000298B3C: CC1A4004 1C12412F
	v_dot2_f32_bf16 v1, v51, v32, v1                           // 000000298B44: CC1A4001 1C064133
	s_waitcnt lgkmcnt(4)                                       // 000000298B4C: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000298B50: BF870112
	v_dot2_f32_bf16 v4, v48, v2, v4                            // 000000298B54: CC1A4004 1C120530
	v_dot2_f32_bf16 v1, v52, v2, v1                            // 000000298B5C: CC1A4001 1C060534
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 000000298B64: BF890437
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000298B68: BF870122
	v_dot2_f32_bf16 v2, v53, v3, v4                            // 000000298B6C: CC1A4002 1C120735
	s_waitcnt vmcnt(0)                                         // 000000298B74: BF8903F7
	v_dot2_f32_bf16 v1, v57, v3, v1                            // 000000298B78: CC1A4001 1C060739
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 000000298B80: CA100108 04020107
	s_waitcnt lgkmcnt(2)                                       // 000000298B88: BF89FC27
	v_dot2_f32_bf16 v2, v54, v31, v2                           // 000000298B8C: CC1A4002 1C0A3F36
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000298B94: BF870123
	v_dot2_f32_bf16 v1, v58, v31, v1                           // 000000298B98: CC1A4001 1C063F3A
	s_waitcnt lgkmcnt(1)                                       // 000000298BA0: BF89FC17
	v_dot2_f32_bf16 v2, v55, v33, v2                           // 000000298BA4: CC1A4002 1C0A4337
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000298BAC: BF870122
	v_dot2_f32_bf16 v1, v59, v33, v1                           // 000000298BB0: CC1A4001 1C06433B
	s_waitcnt lgkmcnt(0)                                       // 000000298BB8: BF89FC07
	v_dot2_f32_bf16 v7, v56, v34, v2                           // 000000298BBC: CC1A4007 1C0A4538
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000298BC4: BF8701A2
	v_dot2_f32_bf16 v8, v60, v34, v1                           // 000000298BC8: CC1A4008 1C06453C
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 000000298BD0: CA100106 02000105
	v_fmac_f32_e32 v25, v24, v7                                // 000000298BD8: 56320F18
	s_delay_alu instid0(VALU_DEP_3)                            // 000000298BDC: BF870003
	v_fmac_f32_e32 v19, v24, v8                                // 000000298BE0: 56261118
	v_mov_b32_e32 v24, v28                                     // 000000298BE4: 7E30031C
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 000000298BE8: 917E077E
	s_cbranch_execz 31                                         // 000000298BEC: BFA5001F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x76c>
	s_waitcnt vmcnt(0)                                         // 000000298BF0: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v21, 16, v21    // 000000298BF4: CA200102 06142A90
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 000000298BFC: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 000000298C04: 7E0E0303
	s_mov_b32 s8, exec_lo                                      // 000000298C08: BE88007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000298C0C: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v21, v22                          // 000000298C10: 7C8C2D15
	.long 0xd4c1007e                                           // 000000298C14: D4C1007E
	v_cndmask_b32_e32 v1, v21, v22, vcc_lo                     // 000000298C18: 02022D15
	s_cbranch_execz 65303                                      // 000000298C1C: BFA5FF17 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x37c>
	v_ashrrev_i32_e32 v6, 31, v27                              // 000000298C20: 340C369F
	v_ashrrev_i32_e32 v8, 31, v26                              // 000000298C24: 3410349F
	.long 0xd7000105                                           // 000000298C28: D7000105
	v_cndmask_b32_e32 v1, v13, v27, vcc_lo                     // 000000298C2C: 0202370D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000298C30: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v23, v6, s1                  // 000000298C34: D5207C06 00060D17
	.long 0xd7000107                                           // 000000298C3C: D7000107
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 000000298C40: 0202350B
	v_add_co_ci_u32_e64 v8, null, v12, v8, s1                  // 000000298C44: D5207C08 0006110C
	s_clause 0x1                                               // 000000298C4C: BF850001
	global_load_d16_b16 v15, v[5:6], off                       // 000000298C50: DC820000 0F7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 000000298C58: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 000000298C60: BF8907F7
	v_cvt_f32_f16_e32 v28, v15                                 // 000000298C64: 7E38170F
	s_branch 65284                                             // 000000298C68: BFA0FF04 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x37c>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000298C6C: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000298C70: BF870149
	s_or_b32 exec_lo, exec_lo, s6                              // 000000298C74: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000298C78: BF8903F7
	.long 0xd71f0001                                           // 000000298C7C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000298C80: 020100C1
	.long 0xd44a0001                                           // 000000298C84: D44A0001
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 000000298C88: 02022280
	v_xor_b32_e32 v2, 8, v1                                    // 000000298C8C: 3A040288
	v_xor_b32_e32 v4, 4, v1                                    // 000000298C90: 3A080284
	v_xor_b32_e32 v6, 2, v1                                    // 000000298C94: 3A0C0282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000298C98: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000298C9C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000298CA0: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000298CA4: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000298CA8: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000298CAC: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000298CB0: 02080901
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000298CB4: 7C980CA0
	ds_bpermute_b32 v3, v2, v25                                // 000000298CB8: DACC0000 03001902
	s_waitcnt lgkmcnt(0)                                       // 000000298CC0: BF89FC07
	v_dual_add_f32 v3, v25, v3 :: v_dual_lshlrev_b32 v4, 2, v4 // 000000298CC4: C9220719 03040882
	ds_bpermute_b32 v2, v2, v19                                // 000000298CCC: DACC0000 02001302
	ds_bpermute_b32 v5, v4, v3                                 // 000000298CD4: DACC0000 05000304
	s_waitcnt lgkmcnt(1)                                       // 000000298CDC: BF89FC17
	v_add_f32_e32 v2, v19, v2                                  // 000000298CE0: 06040513
	s_waitcnt lgkmcnt(0)                                       // 000000298CE4: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 000000298CE8: 06060B03
	ds_bpermute_b32 v4, v4, v2                                 // 000000298CEC: DACC0000 04000204
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 000000298CF4: 020C0D01
	s_delay_alu instid0(VALU_DEP_1)                            // 000000298CF8: BF870001
	v_lshlrev_b32_e32 v6, 2, v6                                // 000000298CFC: 300C0C82
	s_waitcnt lgkmcnt(0)                                       // 000000298D00: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 000000298D04: 06040902
	ds_bpermute_b32 v4, v6, v3                                 // 000000298D08: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 000000298D10: DACC0000 05000206
	v_xor_b32_e32 v6, 1, v1                                    // 000000298D18: 3A0C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000298D1C: BF8700C1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000298D20: 7C980CA0
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 000000298D24: 02020D01
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000298D28: 8B6A037E
	s_mov_b32 s3, -1                                           // 000000298D2C: BE8300C1
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000298D30: 30020282
	s_waitcnt lgkmcnt(0)                                       // 000000298D34: BF89FC07
	v_dual_add_f32 v3, v3, v4 :: v_dual_add_f32 v2, v2, v5     // 000000298D38: C9080903 03020B02
	ds_bpermute_b32 v4, v1, v3                                 // 000000298D40: DACC0000 04000301
	ds_bpermute_b32 v5, v1, v2                                 // 000000298D48: DACC0000 05000201
	s_waitcnt lgkmcnt(0)                                       // 000000298D50: BF89FC07
	v_dual_add_f32 v1, v3, v4 :: v_dual_add_f32 v2, v2, v5     // 000000298D54: C9080903 01020B02
	s_cbranch_vccz 426                                         // 000000298D5C: BFA301AA <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xf08>
	s_and_saveexec_b32 s3, s1                                  // 000000298D60: BE832001
	v_lshlrev_b32_e32 v3, 3, v20                               // 000000298D64: 30062883
	s_delay_alu instid0(VALU_DEP_1)                            // 000000298D68: BF870001
	v_lshl_or_b32 v3, v18, 7, v3                               // 000000298D6C: D6560003 040D0F12
	ds_store_b64 v3, v[1:2] offset:1024                        // 000000298D74: D9340400 00000103
	s_or_b32 exec_lo, exec_lo, s3                              // 000000298D7C: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000298D80: BF870009
	s_mov_b32 s8, exec_lo                                      // 000000298D84: BE88007E
	s_waitcnt lgkmcnt(0)                                       // 000000298D88: BF89FC07
	s_barrier                                                  // 000000298D8C: BFBD0000
	buffer_gl0_inv                                             // 000000298D90: E0AC0000 00000000
	v_cmpx_gt_u32_e32 2, v0                                    // 000000298D98: 7D980082
	s_cbranch_execz 408                                        // 000000298D9C: BFA50198 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xf00>
	s_load_b32 s3, s[16:17], 0x40                              // 000000298DA0: F40000C8 F8000040
	s_waitcnt lgkmcnt(0)                                       // 000000298DA8: BF89FC07
	s_sub_i32 s2, s2, s3                                       // 000000298DAC: 81820302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000298DB0: BF870499
	s_ashr_i32 s3, s2, 31                                      // 000000298DB4: 86039F02
	.long 0xd4530004                                           // 000000298DB8: D4530004
	v_cndmask_b32_e32 v0, s10, v2, vcc_lo                      // 000000298DBC: 0200040A
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000298DC0: 8B6A047E
	s_cbranch_vccnz 398                                        // 000000298DC4: BFA4018E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xf00>
	v_add_nc_u32_e32 v11, 0x400, v16                           // 000000298DC8: 4A1620FF 00000400
	s_clause 0x1                                               // 000000298DD0: BF850001
	s_load_b64 s[6:7], s[16:17], 0x38                          // 000000298DD4: F4040188 F8000038
	s_load_b64 s[4:5], s[16:17], 0x8                           // 000000298DDC: F4040108 F8000008
	s_mov_b32 s9, 0                                            // 000000298DE4: BE890080
	s_mov_b32 s13, -1                                          // 000000298DE8: BE8D00C1
	s_mov_b32 s12, 0                                           // 000000298DEC: BE8C0080
	ds_load_2addr_b32 v[3:4], v11 offset1:2                    // 000000298DF0: D8DC0200 0300000B
	ds_load_2addr_b32 v[5:6], v11 offset0:4 offset1:6          // 000000298DF8: D8DC0604 0500000B
	ds_load_2addr_b32 v[7:8], v11 offset0:8 offset1:10         // 000000298E00: D8DC0A08 0700000B
	s_waitcnt lgkmcnt(0)                                       // 000000298E08: BF89FC07
	s_cmp_lt_i32 s7, 3                                         // 000000298E0C: BF048307
	v_add_f32_e32 v3, 0, v3                                    // 000000298E10: 06060680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000298E14: BF870091
	v_add_f32_e32 v12, v3, v4                                  // 000000298E18: 06180903
	v_add_f32_e32 v5, v12, v5                                  // 000000298E1C: 060A0B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000298E20: BF8700C1
	v_add_f32_e32 v12, v5, v6                                  // 000000298E24: 06180D05
	ds_load_2addr_b32 v[3:4], v11 offset0:12 offset1:14        // 000000298E28: D8DC0E0C 0300000B
	ds_load_2addr_b32 v[5:6], v11 offset0:16 offset1:18        // 000000298E30: D8DC1210 0500000B
	v_add_f32_e32 v7, v12, v7                                  // 000000298E38: 060E0F0C
	v_add_f32_e32 v12, v7, v8                                  // 000000298E3C: 06181107
	ds_load_2addr_b32 v[7:8], v11 offset0:20 offset1:22        // 000000298E40: D8DC1614 0700000B
	s_waitcnt lgkmcnt(2)                                       // 000000298E48: BF89FC27
	v_add_f32_e32 v3, v12, v3                                  // 000000298E4C: 0606070C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000298E50: BF8700A1
	v_add_f32_e32 v3, v3, v4                                   // 000000298E54: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000298E58: BF89FC17
	v_add_f32_e32 v5, v3, v5                                   // 000000298E5C: 060A0B03
	ds_load_2addr_b32 v[3:4], v11 offset0:24 offset1:26        // 000000298E60: D8DC1A18 0300000B
	v_add_f32_e32 v5, v5, v6                                   // 000000298E68: 060A0D05
	s_waitcnt lgkmcnt(1)                                       // 000000298E6C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000298E70: BF8700C1
	v_add_f32_e32 v7, v5, v7                                   // 000000298E74: 060E0F05
	ds_load_2addr_b32 v[5:6], v11 offset0:28 offset1:30        // 000000298E78: D8DC1E1C 0500000B
	v_add_f32_e32 v7, v7, v8                                   // 000000298E80: 060E1107
	s_waitcnt lgkmcnt(1)                                       // 000000298E84: BF89FC17
	v_add_f32_e32 v3, v7, v3                                   // 000000298E88: 06060707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000298E8C: BF8700A1
	v_add_f32_e32 v3, v3, v4                                   // 000000298E90: 06060903
	s_waitcnt lgkmcnt(0)                                       // 000000298E94: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 000000298E98: 06060B03
	s_delay_alu instid0(VALU_DEP_1)                            // 000000298E9C: BF870001
	v_add_f32_e32 v3, v3, v6                                   // 000000298EA0: 06060D03
	s_cbranch_scc1 178                                         // 000000298EA4: BFA200B2 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xc70>
	s_cmp_gt_i32 s7, 3                                         // 000000298EA8: BF028307
	s_cbranch_scc0 112                                         // 000000298EAC: BFA10070 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xb70>
	s_cmp_gt_i32 s7, 4                                         // 000000298EB0: BF028407
	s_cbranch_scc0 58                                          // 000000298EB4: BFA1003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xaa0>
	s_cmp_eq_u32 s7, 5                                         // 000000298EB8: BF068507
	s_mov_b32 s12, -1                                          // 000000298EBC: BE8C00C1
	s_cbranch_scc0 54                                          // 000000298EC0: BFA10036 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xa9c>
	s_ashr_i32 s14, s2, 31                                     // 000000298EC4: 860E9F02
	s_load_b64 s[12:13], s[16:17], 0x10                        // 000000298EC8: F4040308 F8000010
	s_lshr_b32 s14, s14, 23                                    // 000000298ED0: 850E970E
	s_lshr_b32 s15, s10, 31                                    // 000000298ED4: 850F9F0A
	s_add_i32 s14, s2, s14                                     // 000000298ED8: 810E0E02
	s_add_i32 s18, s10, s15                                    // 000000298EDC: 81120F0A
	s_ashr_i32 s14, s14, 9                                     // 000000298EE0: 860E890E
	s_ashr_i32 s18, s18, 1                                     // 000000298EE4: 86128112
	s_ashr_i32 s15, s14, 31                                    // 000000298EE8: 860F9F0E
	v_mad_i64_i32 v[4:5], null, s18, v0, 0                     // 000000298EEC: D6FF7C04 02020012
	s_lshl_b64 s[14:15], s[14:15], 9                           // 000000298EF4: 848E890E
	v_bfe_u32 v6, v3, 16, 1                                    // 000000298EF8: D6100006 02052103
	s_sub_u32 s18, s2, s14                                     // 000000298F00: 80920E02
	s_subb_u32 s19, s3, s15                                    // 000000298F04: 82930F03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000298F08: BF870119
	.long 0xd4540014                                           // 000000298F0C: D4540014
	v_cndmask_b32_e32 v0, 0x100, v18, vcc_lo                   // 000000298F10: 020024FF 00000100
	v_add3_u32 v6, v3, v6, 0x7fff                              // 000000298F18: D6550006 03FE0D03 00007FFF
	.long 0xd73c0004                                           // 000000298F24: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000298F28: 02020881
	s_and_b32 s21, s20, exec_lo                                // 000000298F2C: 8B157E14
	s_waitcnt lgkmcnt(0)                                       // 000000298F30: BF89FC07
	s_cselect_b32 s12, s4, s12                                 // 000000298F34: 980C0C04
	s_cselect_b32 s21, s5, s13                                 // 000000298F38: 98150D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000298F3C: BF870091
	.long 0xd7006a04                                           // 000000298F40: D7006A04
	v_cndmask_b32_e32 v1, s12, v4, vcc_lo                      // 000000298F44: 0202080C
	v_add_co_ci_u32_e64 v5, null, s21, v5, vcc_lo              // 000000298F48: D5207C05 01AA0A15
	s_add_u32 s22, s18, 0xffffff00                             // 000000298F50: 8016FF12 FFFFFF00
	s_addc_u32 s13, s19, -1                                    // 000000298F58: 820DC113
	s_and_b32 s20, s20, exec_lo                                // 000000298F5C: 8B147E14
	.long 0xd7006a04                                           // 000000298F60: D7006A04
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 000000298F64: 02001D04
	s_cselect_b32 s13, s19, s13                                // 000000298F68: 980D0D13
	s_cselect_b32 s12, s18, s22                                // 000000298F6C: 980C1612
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 000000298F70: D5207C05 01AA0A0F
	s_lshl_b64 s[12:13], s[12:13], 1                           // 000000298F78: 848C810C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000298F7C: BF870099
	.long 0xd7006a04                                           // 000000298F80: D7006A04
	v_cndmask_b32_e32 v0, v4, v12, vcc_lo                      // 000000298F84: 02001904
	v_add_co_ci_u32_e64 v5, null, s13, v5, vcc_lo              // 000000298F88: D5207C05 01AA0A0D
	s_mov_b32 s12, 0                                           // 000000298F90: BE8C0080
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000298F94: DC960000 007C0604
	s_mov_b32 s13, 0                                           // 000000298F9C: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000298FA0: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 000000298FA4: 8B6A0D7E
	s_cbranch_vccz 48                                          // 000000298FA8: BFA30030 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xb6c>
	v_mul_f32_e32 v4, 0xbfb8aa3b, v3                           // 000000298FAC: 100806FF BFB8AA3B
	s_lshl_b64 s[14:15], s[2:3], 2                             // 000000298FB4: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000298FB8: BF870291
	v_exp_f32_e32 v4, v4                                       // 000000298FBC: 7E084B04
	v_add_f32_e32 v7, 1.0, v4                                  // 000000298FC0: 060E08F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000298FC4: BF870121
	v_div_scale_f32 v8, null, v7, v7, 1.0                      // 000000298FC8: D6FC7C08 03CA0F07
	v_div_scale_f32 v12, vcc_lo, 1.0, v7, 1.0                  // 000000298FD0: D6FC6A0C 03CA0EF2
	v_rcp_f32_e32 v11, v8                                      // 000000298FD8: 7E165508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000298FDC: BF870095
	v_fma_f32 v4, -v8, v11, 1.0                                // 000000298FE0: D6130004 23CA1708
	v_fmac_f32_e32 v11, v4, v11                                // 000000298FE8: 56161704
	v_mad_u64_u32 v[4:5], null, s10, v0, 0                     // 000000298FEC: D6FE7C04 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000298FF4: BF870112
	v_mul_f32_e32 v13, v12, v11                                // 000000298FF8: 101A170C
	v_mad_u64_u32 v[5:6], null, s11, v0, v[5:6]                // 000000298FFC: D6FE7C05 0416000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299004: BF870092
	v_fma_f32 v14, -v8, v13, v12                               // 000000299008: D613000E 24321B08
	v_fmac_f32_e32 v13, v14, v11                               // 000000299010: 561A170E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000299014: BF870113
	.long 0xd73c0004                                           // 000000299018: D73C0004
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 00000029901C: 02020882
	v_fma_f32 v6, -v8, v13, v12                                // 000000299020: D6130006 24321B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000299028: BF870191
	v_div_fmas_f32 v6, v6, v11, v13                            // 00000029902C: D6370006 04361706
	.long 0xd7006a04                                           // 000000299034: D7006A04
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 000000299038: 02020804
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029903C: BF870191
	v_add_co_ci_u32_e64 v5, null, s5, v5, vcc_lo               // 000000299040: D5207C05 01AA0A05
	v_div_fixup_f32 v6, v6, v7, 1.0                            // 000000299048: D6270006 03CA0F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299050: BF870093
	.long 0xd7006a04                                           // 000000299054: D7006A04
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 000000299058: 02001D04
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 00000029905C: D5207C05 01AA0A0F
	global_store_b32 v[4:5], v6, off                           // 000000299064: DC6A0000 007C0604
	s_mov_b32 s13, 0                                           // 00000029906C: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000299070: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 000000299074: 8B6A0D7E
	s_cbranch_vccz 60                                          // 000000299078: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xc6c>
	v_bfe_u32 v4, v3, 16, 1                                    // 00000029907C: D6100004 02052103
	s_lshl_b64 s[14:15], s[2:3], 2                             // 000000299084: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299088: BF870091
	v_add3_u32 v4, v3, v4, 0x7fff                              // 00000029908C: D6550004 03FE0903 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000299098: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002990A0: BF870091
	v_mul_f32_e32 v4, s6, v4                                   // 0000002990A4: 10080806
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 0000002990A8: 100808FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002990B0: BF870291
	v_exp_f32_e32 v4, v4                                       // 0000002990B4: 7E084B04
	v_add_f32_e32 v7, 1.0, v4                                  // 0000002990B8: 060E08F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002990BC: BF870121
	v_div_scale_f32 v8, null, v7, v7, 1.0                      // 0000002990C0: D6FC7C08 03CA0F07
	v_div_scale_f32 v12, vcc_lo, 1.0, v7, 1.0                  // 0000002990C8: D6FC6A0C 03CA0EF2
	v_rcp_f32_e32 v11, v8                                      // 0000002990D0: 7E165508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002990D4: BF870095
	v_fma_f32 v4, -v8, v11, 1.0                                // 0000002990D8: D6130004 23CA1708
	v_fmac_f32_e32 v11, v4, v11                                // 0000002990E0: 56161704
	v_mad_u64_u32 v[4:5], null, s10, v0, 0                     // 0000002990E4: D6FE7C04 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002990EC: BF870092
	v_mul_f32_e32 v13, v12, v11                                // 0000002990F0: 101A170C
	v_fma_f32 v6, -v8, v13, v12                                // 0000002990F4: D6130006 24321B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002990FC: BF870211
	v_fmac_f32_e32 v13, v6, v11                                // 000000299100: 561A1706
	v_mad_u64_u32 v[5:6], null, s11, v0, v[5:6]                // 000000299104: D6FE7C05 0416000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029910C: BF870112
	v_fma_f32 v6, -v8, v13, v12                                // 000000299110: D6130006 24321B08
	.long 0xd73c0004                                           // 000000299118: D73C0004
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 00000029911C: 02020882
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000299120: BF870112
	v_div_fmas_f32 v6, v6, v11, v13                            // 000000299124: D6370006 04361706
	.long 0xd7006a04                                           // 00000029912C: D7006A04
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 000000299130: 02020804
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000299134: BF870212
	v_div_fixup_f32 v6, v6, v7, 1.0                            // 000000299138: D6270006 03CA0F06
	v_add_co_ci_u32_e64 v5, null, s5, v5, vcc_lo               // 000000299140: D5207C05 01AA0A05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000299148: BF870193
	.long 0xd7006a04                                           // 00000029914C: D7006A04
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 000000299150: 02001D04
	v_add_f32_e32 v6, v6, v6                                   // 000000299154: 060C0D06
	s_delay_alu instid0(VALU_DEP_3)                            // 000000299158: BF870003
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 00000029915C: D5207C05 01AA0A0F
	global_store_b32 v[4:5], v6, off                           // 000000299164: DC6A0000 007C0604
	s_mov_b32 s13, 0                                           // 00000029916C: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000299170: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 000000299174: 8B6A0D7E
	s_cbranch_vccz 72                                          // 000000299178: BFA30048 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xd9c>
	s_cmp_gt_i32 s7, 1                                         // 00000029917C: BF028107
	s_mov_b32 s9, -1                                           // 000000299180: BE8900C1
	s_cbranch_scc0 63                                          // 000000299184: BFA1003F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xd84>
	v_bfe_u32 v4, v3, 16, 1                                    // 000000299188: D6100004 02052103
	s_lshl_b64 s[14:15], s[2:3], 1                             // 000000299190: 848E8102
	s_mov_b32 s9, 0                                            // 000000299194: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299198: BF870091
	v_add3_u32 v4, v3, v4, 0x7fff                              // 00000029919C: D6550004 03FE0903 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000002991A8: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002991B0: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 0000002991B4: 100808FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 0000002991BC: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002991C0: BF870095
	v_add_f32_e32 v7, 1.0, v4                                  // 0000002991C4: 060E08F2
	v_div_scale_f32 v6, null, v7, v7, 1.0                      // 0000002991C8: D6FC7C06 03CA0F07
	v_div_scale_f32 v11, vcc_lo, 1.0, v7, 1.0                  // 0000002991D0: D6FC6A0B 03CA0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002991D8: BF870292
	v_rcp_f32_e32 v8, v6                                       // 0000002991DC: 7E105506
	v_fma_f32 v4, -v6, v8, 1.0                                 // 0000002991E0: D6130004 23CA1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002991E8: BF870121
	v_fmac_f32_e32 v8, v4, v8                                  // 0000002991EC: 56101104
	v_mad_u64_u32 v[4:5], null, s10, v0, 0                     // 0000002991F0: D6FE7C04 0202000A
	v_mul_f32_e32 v12, v11, v8                                 // 0000002991F8: 1018110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002991FC: BF870091
	v_fma_f32 v13, -v6, v12, v11                               // 000000299200: D613000D 242E1906
	v_fmac_f32_e32 v12, v13, v8                                // 000000299208: 5618110D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029920C: BF870121
	v_fma_f32 v11, -v6, v12, v11                               // 000000299210: D613000B 242E1906
	v_mad_u64_u32 v[5:6], null, s11, v0, v[5:6]                // 000000299218: D6FE7C05 0416000B
	v_div_fmas_f32 v6, v11, v8, v12                            // 000000299220: D6370006 0432110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000299228: BF870112
	.long 0xd73c0004                                           // 00000029922C: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000299230: 02020881
	v_div_fixup_f32 v6, v6, v7, 1.0                            // 000000299234: D6270006 03CA0F06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029923C: BF870112
	.long 0xd7006a04                                           // 000000299240: D7006A04
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 000000299244: 02020804
	v_bfe_u32 v7, v6, 16, 1                                    // 000000299248: D6100007 02052106
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000299250: BF870194
	v_add_co_ci_u32_e64 v5, null, s5, v5, vcc_lo               // 000000299254: D5207C05 01AA0A05
	.long 0xd7006a04                                           // 00000029925C: D7006A04
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 000000299260: 02001D04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000299264: BF870193
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000299268: D6550006 03FE0F06 00007FFF
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 000000299274: D5207C05 01AA0A0F
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000029927C: DC960000 007C0604
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 000000299284: 916A097E
	s_mov_b32 s9, 0                                            // 000000299288: BE890080
	s_cbranch_vccnz 3                                          // 00000029928C: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xd9c>
	s_cmp_lg_u32 s7, 1                                         // 000000299290: BF078107
	s_mov_b32 s9, -1                                           // 000000299294: BE8900C1
	s_cselect_b32 s12, -1, 0                                   // 000000299298: 980C80C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029929C: BF8700A1
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002992A0: D6100004 02052103
	s_and_b32 vcc_lo, exec_lo, s12                             // 0000002992A8: 8B6A0C7E
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000002992AC: D6550003 03FE0903 00007FFF
	s_cbranch_vccz 21                                          // 0000002992B8: BFA30015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xe10>
	v_mad_u64_u32 v[4:5], null, s10, v0, 0                     // 0000002992BC: D6FE7C04 0202000A
	s_lshl_b64 s[12:13], s[2:3], 1                             // 0000002992C4: 848C8102
	s_mov_b32 s9, 0                                            // 0000002992C8: BE890080
	v_mad_u64_u32 v[5:6], null, s11, v0, v[5:6]                // 0000002992CC: D6FE7C05 0416000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002992D4: BF870091
	.long 0xd73c0004                                           // 0000002992D8: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002992DC: 02020881
	.long 0xd7006a04                                           // 0000002992E0: D7006A04
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 0000002992E4: 02020804
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002992E8: BF870111
	v_add_co_ci_u32_e64 v5, null, s5, v5, vcc_lo               // 0000002992EC: D5207C05 01AA0A05
	.long 0xd7006a04                                           // 0000002992F4: D7006A04
	v_cndmask_b32_e32 v0, v4, v12, vcc_lo                      // 0000002992F8: 02001904
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002992FC: BF870001
	v_add_co_ci_u32_e64 v5, null, s13, v5, vcc_lo              // 000000299300: D5207C05 01AA0A0D
	global_store_d16_hi_b16 v[4:5], v3, off                    // 000000299308: DC960000 007C0304
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 000000299310: 916A097E
	s_cbranch_vccnz 58                                         // 000000299314: BFA4003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xf00>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000299318: BF8700A1
	v_and_b32_e32 v3, 0xffff0000, v3                           // 00000029931C: 360606FF FFFF0000
	s_lshl_b64 s[2:3], s[2:3], 1                               // 000000299324: 84828102
	v_mul_f32_e32 v6, s6, v3                                   // 000000299328: 100C0606
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029932C: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v6                           // 000000299330: 10060CFF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 000000299338: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029933C: BF870095
	v_add_f32_e32 v7, 1.0, v3                                  // 000000299340: 060E06F2
	v_div_scale_f32 v5, null, v7, v7, v6                       // 000000299344: D6FC7C05 041A0F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029934C: BF870291
	v_rcp_f32_e32 v8, v5                                       // 000000299350: 7E105505
	v_fma_f32 v3, -v5, v8, 1.0                                 // 000000299354: D6130003 23CA1105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000029935C: BF870131
	v_fmac_f32_e32 v8, v3, v8                                  // 000000299360: 56101103
	v_div_scale_f32 v11, vcc_lo, v6, v7, v6                    // 000000299364: D6FC6A0B 041A0F06
	v_mad_u64_u32 v[3:4], null, s10, v0, 0                     // 00000029936C: D6FE7C03 0202000A
	v_mul_f32_e32 v12, v11, v8                                 // 000000299374: 1018110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299378: BF870091
	v_fma_f32 v13, -v5, v12, v11                               // 00000029937C: D613000D 242E1905
	v_fmac_f32_e32 v12, v13, v8                                // 000000299384: 5618110D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000299388: BF870121
	v_fma_f32 v11, -v5, v12, v11                               // 00000029938C: D613000B 242E1905
	v_mad_u64_u32 v[4:5], null, s11, v0, v[4:5]                // 000000299394: D6FE7C04 0412000B
	v_div_fmas_f32 v0, v11, v8, v12                            // 00000029939C: D6370000 0432110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002993A4: BF870112
	.long 0xd73c0003                                           // 0000002993A8: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000002993AC: 02020681
	v_div_fixup_f32 v0, v0, v7, v6                             // 0000002993B0: D6270000 041A0F00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002993B8: BF870112
	.long 0xd7006a03                                           // 0000002993BC: D7006A03
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000002993C0: 02020604
	v_bfe_u32 v5, v0, 16, 1                                    // 0000002993C4: D6100005 02052100
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002993CC: BF870194
	v_add_co_ci_u32_e64 v4, null, s5, v4, vcc_lo               // 0000002993D0: D5207C04 01AA0805
	.long 0xd7006a03                                           // 0000002993D8: D7006A03
	v_cndmask_b32_e32 v0, v3, v2, vcc_lo                       // 0000002993DC: 02000503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002993E0: BF870193
	v_add3_u32 v0, v0, v5, 0x7fff                              // 0000002993E4: D6550000 03FE0B00 00007FFF
	v_add_co_ci_u32_e64 v4, null, s3, v4, vcc_lo               // 0000002993F0: D5207C04 01AA0803
	global_store_d16_hi_b16 v[3:4], v0, off                    // 0000002993F8: DC960000 007C0003
	s_or_b32 exec_lo, exec_lo, s8                              // 000000299400: 8C7E087E
	s_mov_b32 s3, 0                                            // 000000299404: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000299408: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000029940C: 8B6A037E
	s_cbranch_vccz 558                                         // 000000299410: BFA3022E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x17cc>
	s_and_b32 s0, s1, s0                                       // 000000299414: 8B000001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000299418: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000029941C: BE812000
	s_cbranch_execz 554                                        // 000000299420: BFA5022A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x17cc>
	v_ashrrev_i32_e32 v0, 31, v10                              // 000000299424: 3400149F
	s_clause 0x1                                               // 000000299428: BF850001
	s_load_b64 s[4:5], s[16:17], 0x8                           // 00000029942C: F4040108 F8000008
	s_load_b64 s[2:3], s[16:17], 0x38                          // 000000299434: F4040088 F8000038
	.long 0xd73c0003                                           // 00000029943C: D73C0003
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 000000299440: 02021281
	.long 0xd73c0005                                           // 000000299444: D73C0005
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000299448: 02021282
	s_mov_b32 s7, -1                                           // 00000029944C: BE8700C1
	v_lshrrev_b32_e32 v0, 23, v0                               // 000000299450: 32000097
	s_mov_b32 s1, 0                                            // 000000299454: BE810080
	s_mov_b32 s6, 0                                            // 000000299458: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029945C: BF870091
	.long 0xd7006a07                                           // 000000299460: D7006A07
	v_cndmask_b32_e32 v1, v9, v0, vcc_lo                       // 000000299464: 02020109
	v_add_co_ci_u32_e64 v0, null, 0, v10, vcc_lo               // 000000299468: D5207C00 01AA1480
	.long 0xd7016a03                                           // 000000299470: D7016A03
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000299474: 02020680
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000299478: BF870123
	v_and_b32_e32 v11, 0xfffffe00, v7                          // 00000029947C: 36160EFF FFFFFE00
	v_sub_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000299484: D5217C04 01AA0880
	.long 0xd7016a07                                           // 00000029948C: D7016A07
	v_cndmask_b32_e32 v1, v9, v11, vcc_lo                      // 000000299490: 02021709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000299494: BF8700B1
	v_sub_co_ci_u32_e64 v8, null, v10, v0, vcc_lo              // 000000299498: D5217C08 01AA010A
	s_waitcnt lgkmcnt(0)                                       // 0000002994A0: BF89FC07
	.long 0xd7006a05                                           // 0000002994A4: D7006A05
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000002994A8: 02020A04
	v_add_co_ci_u32_e64 v6, null, s5, v6, vcc_lo               // 0000002994AC: D5207C06 01AA0C05
	.long 0xd7006a09                                           // 0000002994B4: D7006A09
	v_cndmask_b32_e32 v1, 0xffffff00, v7, vcc_lo               // 0000002994B8: 02020EFF FFFFFF00
	.long 0xd4540000                                           // 0000002994C0: D4540000
	v_cndmask_b32_e32 v1, 0x100, v7, vcc_lo                    // 0000002994C4: 02020EFF 00000100
	v_add_co_ci_u32_e64 v10, null, -1, v8, vcc_lo              // 0000002994CC: D5207C0A 01AA10C1
	.long 0xd7006a03                                           // 0000002994D4: D7006A03
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 0000002994D8: 02020705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002994DC: BF870191
	v_add_co_ci_u32_e64 v4, null, v6, v4, vcc_lo               // 0000002994E0: D5207C04 01AA0906
	v_cndmask_b32_e64 v8, v10, v8, s0                          // 0000002994E8: D5010008 0002110A
	v_cndmask_b32_e64 v7, v9, v7, s0                           // 0000002994F0: D5010007 00020F09
	s_cmp_lt_i32 s3, 3                                         // 0000002994F8: BF048303
	s_cbranch_scc1 118                                         // 0000002994FC: BFA20076 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x11d8>
	s_cmp_gt_i32 s3, 3                                         // 000000299500: BF028303
	s_cbranch_scc0 70                                          // 000000299504: BFA10046 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1120>
	s_cmp_gt_i32 s3, 4                                         // 000000299508: BF028403
	s_cbranch_scc0 34                                          // 00000029950C: BFA10022 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1098>
	s_cmp_eq_u32 s3, 5                                         // 000000299510: BF068503
	s_mov_b32 s6, -1                                           // 000000299514: BE8600C1
	s_cbranch_scc0 30                                          // 000000299518: BFA1001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1094>
	s_load_b64 s[6:7], s[16:17], 0x10                          // 00000029951C: F4040188 F8000010
	v_dual_mov_b32 v9, s4 :: v_dual_mov_b32 v10, s5            // 000000299524: CA100004 090A0005
	v_bfe_u32 v13, v1, 16, 1                                   // 00000029952C: D610000D 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000299534: BF8701A1
	v_add3_u32 v13, v1, v13, 0x7fff                            // 000000299538: D655000D 03FE1B01 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 000000299544: BF89FC07
	v_cndmask_b32_e64 v12, s6, v9, s0                          // 000000299548: D501000C 00021206
	v_cndmask_b32_e64 v14, s7, v10, s0                         // 000000299550: D501000E 00021407
	.long 0xd73c0009                                           // 000000299558: D73C0009
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000029955C: 02020E81
	s_mov_b32 s6, 0                                            // 000000299560: BE860080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299564: BF870093
	.long 0xd7006a0c                                           // 000000299568: D7006A0C
	v_cndmask_b32_e32 v1, v12, v11, vcc_lo                     // 00000029956C: 0202170C
	v_add_co_ci_u32_e64 v14, null, v14, v0, vcc_lo             // 000000299570: D5207C0E 01AA010E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299578: BF870092
	.long 0xd7006a09                                           // 00000029957C: D7006A09
	v_cndmask_b32_e32 v1, v12, v9, vcc_lo                      // 000000299580: 0202130C
	v_add_co_ci_u32_e64 v10, null, v14, v10, vcc_lo            // 000000299584: D5207C0A 01AA150E
	global_store_d16_hi_b16 v[9:10], v13, off                  // 00000029958C: DC960000 007C0D09
	s_mov_b32 s7, 0                                            // 000000299594: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000299598: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000029959C: 8B6A077E
	s_cbranch_vccz 30                                          // 0000002995A0: BFA3001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x111c>
	v_mul_f32_e32 v9, 0xbfb8aa3b, v1                           // 0000002995A4: 101202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002995AC: BF870291
	v_exp_f32_e32 v9, v9                                       // 0000002995B0: 7E124B09
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002995B4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002995B8: BF870091
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002995BC: D6FC7C0A 03CA1309
	v_rcp_f32_e32 v12, v10                                     // 0000002995C4: 7E18550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002995C8: BF870095
	v_fma_f32 v13, -v10, v12, 1.0                              // 0000002995CC: D613000D 23CA190A
	v_fmac_f32_e32 v12, v13, v12                               // 0000002995D4: 5618190D
	v_div_scale_f32 v13, vcc_lo, 1.0, v9, 1.0                  // 0000002995D8: D6FC6A0D 03CA12F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002995E0: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000002995E4: 101C190D
	v_fma_f32 v15, -v10, v14, v13                              // 0000002995E8: D613000F 24361D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002995F0: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000002995F4: 561C190F
	v_fma_f32 v10, -v10, v14, v13                              // 0000002995F8: D613000A 24361D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299600: BF870091
	v_div_fmas_f32 v10, v10, v12, v14                          // 000000299604: D637000A 043A190A
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 00000029960C: D6270009 03CA130A
	global_store_b32 v[5:6], v9, off                           // 000000299614: DC6A0000 007C0905
	s_mov_b32 s7, 0                                            // 00000029961C: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000299620: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 000000299624: 8B6A077E
	s_cbranch_vccz 42                                          // 000000299628: BFA3002A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x11d4>
	v_bfe_u32 v9, v1, 16, 1                                    // 00000029962C: D6100009 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299634: BF870091
	v_add3_u32 v9, v1, v9, 0x7fff                              // 000000299638: D6550009 03FE1301 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 000000299644: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029964C: BF870091
	v_mul_f32_e32 v9, s2, v9                                   // 000000299650: 10121202
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 000000299654: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029965C: BF870291
	v_exp_f32_e32 v9, v9                                       // 000000299660: 7E124B09
	v_add_f32_e32 v9, 1.0, v9                                  // 000000299664: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299668: BF870091
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 00000029966C: D6FC7C0A 03CA1309
	v_rcp_f32_e32 v12, v10                                     // 000000299674: 7E18550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299678: BF870095
	v_fma_f32 v13, -v10, v12, 1.0                              // 00000029967C: D613000D 23CA190A
	v_fmac_f32_e32 v12, v13, v12                               // 000000299684: 5618190D
	v_div_scale_f32 v13, vcc_lo, 1.0, v9, 1.0                  // 000000299688: D6FC6A0D 03CA12F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299690: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000299694: 101C190D
	v_fma_f32 v15, -v10, v14, v13                              // 000000299698: D613000F 24361D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002996A0: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000002996A4: 561C190F
	v_fma_f32 v10, -v10, v14, v13                              // 0000002996A8: D613000A 24361D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002996B0: BF870091
	v_div_fmas_f32 v10, v10, v12, v14                          // 0000002996B4: D637000A 043A190A
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000002996BC: D6270009 03CA130A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002996C4: BF870001
	v_add_f32_e32 v9, v9, v9                                   // 0000002996C8: 06121309
	global_store_b32 v[5:6], v9, off                           // 0000002996CC: DC6A0000 007C0905
	s_mov_b32 s7, 0                                            // 0000002996D4: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002996D8: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002996DC: 8B6A077E
	s_cbranch_vccz 55                                          // 0000002996E0: BFA30037 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x12c0>
	s_cmp_gt_i32 s3, 1                                         // 0000002996E4: BF028103
	s_mov_b32 s1, -1                                           // 0000002996E8: BE8100C1
	s_cbranch_scc0 46                                          // 0000002996EC: BFA1002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x12a8>
	v_bfe_u32 v9, v1, 16, 1                                    // 0000002996F0: D6100009 02052101
	s_mov_b32 s1, 0                                            // 0000002996F8: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002996FC: BF870091
	v_add3_u32 v9, v1, v9, 0x7fff                              // 000000299700: D6550009 03FE1301 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 00000029970C: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299714: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 000000299718: 101212FF BFB8AA3B
	v_exp_f32_e32 v9, v9                                       // 000000299720: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299724: BF870095
	v_add_f32_e32 v9, 1.0, v9                                  // 000000299728: 061212F2
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 00000029972C: D6FC7C0A 03CA1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000299734: BF870291
	v_rcp_f32_e32 v12, v10                                     // 000000299738: 7E18550A
	v_fma_f32 v13, -v10, v12, 1.0                              // 00000029973C: D613000D 23CA190A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000299744: BF8700A1
	v_fmac_f32_e32 v12, v13, v12                               // 000000299748: 5618190D
	v_div_scale_f32 v13, vcc_lo, 1.0, v9, 1.0                  // 00000029974C: D6FC6A0D 03CA12F2
	v_mul_f32_e32 v14, v13, v12                                // 000000299754: 101C190D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299758: BF870091
	v_fma_f32 v15, -v10, v14, v13                              // 00000029975C: D613000F 24361D0A
	v_fmac_f32_e32 v14, v15, v12                               // 000000299764: 561C190F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299768: BF870091
	v_fma_f32 v10, -v10, v14, v13                              // 00000029976C: D613000A 24361D0A
	v_div_fmas_f32 v10, v10, v12, v14                          // 000000299774: D637000A 043A190A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029977C: BF870091
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 000000299780: D6270009 03CA130A
	v_bfe_u32 v10, v9, 16, 1                                   // 000000299788: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 000000299790: BF870001
	v_add3_u32 v9, v9, v10, 0x7fff                             // 000000299794: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[3:4], v9, off                    // 0000002997A0: DC960000 007C0903
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002997A8: 916A017E
	s_mov_b32 s1, 0                                            // 0000002997AC: BE810080
	s_cbranch_vccnz 3                                          // 0000002997B0: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x12c0>
	s_cmp_lg_u32 s3, 1                                         // 0000002997B4: BF078103
	s_mov_b32 s1, -1                                           // 0000002997B8: BE8100C1
	s_cselect_b32 s6, -1, 0                                    // 0000002997BC: 980680C1
	v_bfe_u32 v9, v1, 16, 1                                    // 0000002997C0: D6100009 02052101
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002997C8: 8B6A067E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002997CC: BF870001
	v_add3_u32 v1, v1, v9, 0x7fff                              // 0000002997D0: D6550001 03FE1301 00007FFF
	s_cbranch_vccz 3                                           // 0000002997DC: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x12ec>
	s_mov_b32 s1, 0                                            // 0000002997E0: BE810080
	global_store_d16_hi_b16 v[3:4], v1, off                    // 0000002997E4: DC960000 007C0103
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002997EC: 916A017E
	s_cbranch_vccnz 41                                         // 0000002997F0: BFA40029 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1398>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002997F4: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002997F8: 360202FF FFFF0000
	v_mul_f32_e32 v1, s2, v1                                   // 000000299800: 10020202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299804: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v1                           // 000000299808: 101202FF BFB8AA3B
	v_exp_f32_e32 v9, v9                                       // 000000299810: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299814: BF870095
	v_add_f32_e32 v9, 1.0, v9                                  // 000000299818: 061212F2
	v_div_scale_f32 v10, null, v9, v9, v1                      // 00000029981C: D6FC7C0A 04061309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000299824: BF870291
	v_rcp_f32_e32 v12, v10                                     // 000000299828: 7E18550A
	v_fma_f32 v13, -v10, v12, 1.0                              // 00000029982C: D613000D 23CA190A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000299834: BF8700A1
	v_fmac_f32_e32 v12, v13, v12                               // 000000299838: 5618190D
	v_div_scale_f32 v13, vcc_lo, v1, v9, v1                    // 00000029983C: D6FC6A0D 04061301
	v_mul_f32_e32 v14, v13, v12                                // 000000299844: 101C190D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299848: BF870091
	v_fma_f32 v15, -v10, v14, v13                              // 00000029984C: D613000F 24361D0A
	v_fmac_f32_e32 v14, v15, v12                               // 000000299854: 561C190F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299858: BF870091
	v_fma_f32 v10, -v10, v14, v13                              // 00000029985C: D613000A 24361D0A
	v_div_fmas_f32 v10, v10, v12, v14                          // 000000299864: D637000A 043A190A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029986C: BF870091
	v_div_fixup_f32 v1, v10, v9, v1                            // 000000299870: D6270001 0406130A
	v_bfe_u32 v9, v1, 16, 1                                    // 000000299878: D6100009 02052101
	s_delay_alu instid0(VALU_DEP_1)                            // 000000299880: BF870001
	v_add3_u32 v1, v1, v9, 0x7fff                              // 000000299884: D6550001 03FE1301 00007FFF
	global_store_d16_hi_b16 v[3:4], v1, off                    // 000000299890: DC960000 007C0103
	s_mov_b32 s7, -1                                           // 000000299898: BE8700C1
	s_mov_b32 s1, 0                                            // 00000029989C: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002998A0: BF048303
	s_mov_b32 s6, 0                                            // 0000002998A4: BE860080
	s_cbranch_scc1 136                                         // 0000002998A8: BFA20088 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x15cc>
	s_cmp_gt_i32 s3, 3                                         // 0000002998AC: BF028303
	s_cbranch_scc0 43                                          // 0000002998B0: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1460>
	s_cmp_gt_i32 s3, 4                                         // 0000002998B4: BF028403
	s_cbranch_scc0 43                                          // 0000002998B8: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1468>
	s_cmp_eq_u32 s3, 5                                         // 0000002998BC: BF068503
	s_mov_b32 s6, -1                                           // 0000002998C0: BE8600C1
	s_cbranch_scc0 36                                          // 0000002998C4: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1458>
	s_load_b64 s[6:7], s[16:17], 0x10                          // 0000002998C8: F4040188 F8000010
	v_mov_b32_e32 v1, s4                                       // 0000002998D0: 7E020204
	v_mov_b32_e32 v9, s5                                       // 0000002998D4: 7E120205
	.long 0xd73c0007                                           // 0000002998D8: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 0000002998DC: 02020E81
	v_bfe_u32 v10, v2, 16, 1                                   // 0000002998E0: D610000A 02052102
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002998E8: BF870001
	v_add3_u32 v10, v2, v10, 0x7fff                            // 0000002998EC: D655000A 03FE1502 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002998F8: BF89FC07
	v_cndmask_b32_e64 v1, s6, v1, s0                           // 0000002998FC: D5010001 00020206
	v_cndmask_b32_e64 v9, s7, v9, s0                           // 000000299904: D5010009 00021207
	s_and_b32 s0, s10, -2                                      // 00000029990C: 8B00C20A
	s_mov_b32 s6, 0                                            // 000000299910: BE860080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299914: BF870092
	.long 0xd7006a01                                           // 000000299918: D7006A01
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 00000029991C: 02000101
	v_add_co_ci_u32_e64 v9, null, s11, v9, vcc_lo              // 000000299920: D5207C09 01AA120B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299928: BF870092
	.long 0xd7006a01                                           // 00000029992C: D7006A01
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 000000299930: 02021701
	v_add_co_ci_u32_e64 v9, null, v9, v0, vcc_lo               // 000000299934: D5207C09 01AA0109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029993C: BF870092
	.long 0xd7006a00                                           // 000000299940: D7006A00
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 000000299944: 02020F01
	v_add_co_ci_u32_e64 v1, null, v9, v8, vcc_lo               // 000000299948: D5207C01 01AA1109
	global_store_d16_hi_b16 v[0:1], v10, off                   // 000000299950: DC960000 007C0A00
	s_mov_b32 s0, 0                                            // 000000299958: BE800080
	s_branch 3                                                 // 00000029995C: BFA00003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x146c>
	s_cbranch_execnz 42                                        // 000000299960: BFA6002A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x150c>
	s_branch 88                                                // 000000299964: BFA00058 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x15c8>
	s_mov_b32 s0, -1                                           // 000000299968: BE8000C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029996C: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 000000299970: 8B6A007E
	s_cbranch_vccz 36                                          // 000000299974: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1508>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v2                           // 000000299978: 100004FF BFB8AA3B
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000299980: 8484820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000299984: BF870291
	v_exp_f32_e32 v0, v0                                       // 000000299988: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 00000029998C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000299990: BF870121
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 000000299994: D6FC7C01 03CA0100
	v_div_scale_f32 v9, vcc_lo, 1.0, v0, 1.0                   // 00000029999C: D6FC6A09 03CA00F2
	v_rcp_f32_e32 v7, v1                                       // 0000002999A4: 7E0E5501
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002999A8: BF870095
	v_fma_f32 v8, -v1, v7, 1.0                                 // 0000002999AC: D6130008 23CA0F01
	v_fmac_f32_e32 v7, v8, v7                                  // 0000002999B4: 560E0F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002999B8: BF870091
	v_mul_f32_e32 v8, v9, v7                                   // 0000002999BC: 10100F09
	v_fma_f32 v10, -v1, v8, v9                                 // 0000002999C0: D613000A 24261101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002999C8: BF870091
	v_fmac_f32_e32 v8, v10, v7                                 // 0000002999CC: 56100F0A
	v_fma_f32 v1, -v1, v8, v9                                  // 0000002999D0: D6130001 24261101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002999D8: BF870091
	v_div_fmas_f32 v1, v1, v7, v8                              // 0000002999DC: D6370001 04220F01
	v_div_fixup_f32 v7, v1, v0, 1.0                            // 0000002999E4: D6270007 03CA0101
	.long 0xd7006a00                                           // 0000002999EC: D7006A00
	v_cndmask_b32_e32 v0, v5, v4, vcc_lo                       // 0000002999F0: 02000905
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002999F4: BF870001
	v_add_co_ci_u32_e64 v1, null, s5, v6, vcc_lo               // 0000002999F8: D5207C01 01AA0C05
	global_store_b32 v[0:1], v7, off                           // 000000299A00: DC6A0000 007C0700
	s_branch 47                                                // 000000299A08: BFA0002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x15c8>
	v_bfe_u32 v0, v2, 16, 1                                    // 000000299A0C: D6100000 02052102
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000299A14: 8484820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299A18: BF870091
	v_add3_u32 v0, v2, v0, 0x7fff                              // 000000299A1C: D6550000 03FE0102 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 000000299A28: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299A30: BF870091
	v_mul_f32_e32 v0, s2, v0                                   // 000000299A34: 10000002
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 000000299A38: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000299A40: BF870291
	v_exp_f32_e32 v0, v0                                       // 000000299A44: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 000000299A48: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000299A4C: BF870121
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 000000299A50: D6FC7C01 03CA0100
	v_div_scale_f32 v9, vcc_lo, 1.0, v0, 1.0                   // 000000299A58: D6FC6A09 03CA00F2
	v_rcp_f32_e32 v7, v1                                       // 000000299A60: 7E0E5501
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299A64: BF870095
	v_fma_f32 v8, -v1, v7, 1.0                                 // 000000299A68: D6130008 23CA0F01
	v_fmac_f32_e32 v7, v8, v7                                  // 000000299A70: 560E0F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299A74: BF870091
	v_mul_f32_e32 v8, v9, v7                                   // 000000299A78: 10100F09
	v_fma_f32 v10, -v1, v8, v9                                 // 000000299A7C: D613000A 24261101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299A84: BF870091
	v_fmac_f32_e32 v8, v10, v7                                 // 000000299A88: 56100F0A
	v_fma_f32 v1, -v1, v8, v9                                  // 000000299A8C: D6130001 24261101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299A94: BF870091
	v_div_fmas_f32 v1, v1, v7, v8                              // 000000299A98: D6370001 04220F01
	v_div_fixup_f32 v0, v1, v0, 1.0                            // 000000299AA0: D6270000 03CA0101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000299AA8: BF8700A1
	v_add_f32_e32 v7, v0, v0                                   // 000000299AAC: 060E0100
	.long 0xd7006a00                                           // 000000299AB0: D7006A00
	v_cndmask_b32_e32 v0, v5, v4, vcc_lo                       // 000000299AB4: 02000905
	v_add_co_ci_u32_e64 v1, null, s5, v6, vcc_lo               // 000000299AB8: D5207C01 01AA0C05
	global_store_b32 v[0:1], v7, off                           // 000000299AC0: DC6A0000 007C0700
	s_mov_b32 s7, 0                                            // 000000299AC8: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000299ACC: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 000000299AD0: 8B6A077E
	s_cbranch_vccz 60                                          // 000000299AD4: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x16c8>
	s_cmp_gt_i32 s3, 1                                         // 000000299AD8: BF028103
	s_mov_b32 s0, -1                                           // 000000299ADC: BE8000C1
	s_cbranch_scc0 51                                          // 000000299AE0: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x16b0>
	v_bfe_u32 v0, v2, 16, 1                                    // 000000299AE4: D6100000 02052102
	s_lshl_b64 s[0:1], s[10:11], 1                             // 000000299AEC: 8480810A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299AF0: BF870091
	v_add3_u32 v0, v2, v0, 0x7fff                              // 000000299AF4: D6550000 03FE0102 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 000000299B00: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299B08: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 000000299B0C: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 000000299B14: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299B18: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 000000299B1C: 060000F2
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 000000299B20: D6FC7C01 03CA0100
	v_div_scale_f32 v7, vcc_lo, 1.0, v0, 1.0                   // 000000299B28: D6FC6A07 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000299B30: BF870292
	v_rcp_f32_e32 v5, v1                                       // 000000299B34: 7E0A5501
	v_fma_f32 v6, -v1, v5, 1.0                                 // 000000299B38: D6130006 23CA0B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299B40: BF870091
	v_fmac_f32_e32 v5, v6, v5                                  // 000000299B44: 560A0B06
	v_mul_f32_e32 v6, v7, v5                                   // 000000299B48: 100C0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299B4C: BF870091
	v_fma_f32 v8, -v1, v6, v7                                  // 000000299B50: D6130008 241E0D01
	v_fmac_f32_e32 v6, v8, v5                                  // 000000299B58: 560C0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299B5C: BF870091
	v_fma_f32 v1, -v1, v6, v7                                  // 000000299B60: D6130001 241E0D01
	v_div_fmas_f32 v1, v1, v5, v6                              // 000000299B68: D6370001 041A0B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299B70: BF870091
	v_div_fixup_f32 v0, v1, v0, 1.0                            // 000000299B74: D6270000 03CA0101
	v_bfe_u32 v1, v0, 16, 1                                    // 000000299B7C: D6100001 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000299B84: BF8700A1
	v_add3_u32 v5, v0, v1, 0x7fff                              // 000000299B88: D6550005 03FE0300 00007FFF
	.long 0xd7006a00                                           // 000000299B94: D7006A00
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 000000299B98: 02000103
	v_add_co_ci_u32_e64 v1, null, s1, v4, vcc_lo               // 000000299B9C: D5207C01 01AA0801
	s_mov_b32 s0, 0                                            // 000000299BA4: BE800080
	global_store_d16_hi_b16 v[0:1], v5, off                    // 000000299BA8: DC960000 007C0500
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000299BB0: 916A007E
	s_mov_b32 s1, 0                                            // 000000299BB4: BE810080
	s_cbranch_vccnz 3                                          // 000000299BB8: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x16c8>
	s_cmp_lg_u32 s3, 1                                         // 000000299BBC: BF078103
	s_mov_b32 s1, -1                                           // 000000299BC0: BE8100C1
	s_cselect_b32 s6, -1, 0                                    // 000000299BC4: 980680C1
	v_bfe_u32 v0, v2, 16, 1                                    // 000000299BC8: D6100000 02052102
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000299BD0: 8B6A067E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000299BD4: BF870001
	v_add3_u32 v0, v2, v0, 0x7fff                              // 000000299BD8: D6550000 03FE0102 00007FFF
	s_cbranch_vccz 9                                           // 000000299BE4: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x170c>
	s_lshl_b64 s[0:1], s[10:11], 1                             // 000000299BE8: 8480810A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299BEC: BF870099
	.long 0xd7006a01                                           // 000000299BF0: D7006A01
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 000000299BF4: 02000103
	v_add_co_ci_u32_e64 v2, null, s1, v4, vcc_lo               // 000000299BF8: D5207C02 01AA0801
	s_mov_b32 s1, 0                                            // 000000299C00: BE810080
	global_store_d16_hi_b16 v[1:2], v0, off                    // 000000299C04: DC960000 007C0001
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000299C0C: 916A017E
	s_cbranch_vccnz 46                                         // 000000299C10: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x17cc>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000299C14: BF8700A1
	v_and_b32_e32 v0, 0xffff0000, v0                           // 000000299C18: 360000FF FFFF0000
	s_lshl_b64 s[0:1], s[10:11], 1                             // 000000299C20: 8480810A
	v_mul_f32_e32 v0, s2, v0                                   // 000000299C24: 10000002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299C28: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000299C2C: 100200FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 000000299C34: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299C38: BF870095
	v_add_f32_e32 v1, 1.0, v1                                  // 000000299C3C: 060202F2
	v_div_scale_f32 v2, null, v1, v1, v0                       // 000000299C40: D6FC7C02 04020301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000299C48: BF870291
	v_rcp_f32_e32 v5, v2                                       // 000000299C4C: 7E0A5502
	v_fma_f32 v6, -v2, v5, 1.0                                 // 000000299C50: D6130006 23CA0B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000299C58: BF8700A1
	v_fmac_f32_e32 v5, v6, v5                                  // 000000299C5C: 560A0B06
	v_div_scale_f32 v7, vcc_lo, v0, v1, v0                     // 000000299C60: D6FC6A07 04020300
	v_mul_f32_e32 v6, v7, v5                                   // 000000299C68: 100C0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299C6C: BF870091
	v_fma_f32 v8, -v2, v6, v7                                  // 000000299C70: D6130008 241E0D02
	v_fmac_f32_e32 v6, v8, v5                                  // 000000299C78: 560C0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299C7C: BF870091
	v_fma_f32 v2, -v2, v6, v7                                  // 000000299C80: D6130002 241E0D02
	v_div_fmas_f32 v2, v2, v5, v6                              // 000000299C88: D6370002 041A0B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000299C90: BF870091
	v_div_fixup_f32 v0, v2, v1, v0                             // 000000299C94: D6270000 04020302
	v_bfe_u32 v1, v0, 16, 1                                    // 000000299C9C: D6100001 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000299CA4: BF8700A1
	v_add3_u32 v2, v0, v1, 0x7fff                              // 000000299CA8: D6550002 03FE0300 00007FFF
	.long 0xd7006a00                                           // 000000299CB4: D7006A00
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 000000299CB8: 02000103
	v_add_co_ci_u32_e64 v1, null, s1, v4, vcc_lo               // 000000299CBC: D5207C01 01AA0801
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000299CC4: DC960000 007C0200
	s_endpgm                                                   // 000000299CCC: BFB00000
		...

