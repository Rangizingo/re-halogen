00000000003f7000 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj>:
; _ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj():
	s_clause 0x1                                               // 0000003F7000: BF850001
	s_load_b64 s[4:5], s[0:1], 0x130                           // 0000003F7004: F4040100 F8000130
	s_load_b128 s[16:19], s[0:1], 0x198                        // 0000003F700C: F4080400 F8000198
	s_waitcnt lgkmcnt(0)                                       // 0000003F7014: BF89FC07
	s_cmp_eq_u64 s[4:5], 0                                     // 0000003F7018: BF108004
	s_cbranch_scc1 246                                         // 0000003F701C: BFA200F6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f8>
	s_load_b32 s6, s[0:1], 0x138                               // 0000003F7020: F4000180 F8000138
	s_waitcnt lgkmcnt(0)                                       // 0000003F7028: BF89FC07
	s_cmp_lt_i32 s2, s6                                        // 0000003F702C: BF040602
	s_cselect_b32 s3, -1, 0                                    // 0000003F7030: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000003F7034: BF030602
	s_cbranch_scc0 233                                         // 0000003F7038: BFA100E9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3e0>
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000003F703C: 32020085
	s_sub_i32 s6, s2, s6                                       // 0000003F7040: 81860602
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000003F7044: BF870481
	v_lshl_or_b32 v1, s6, 3, v1                                // 0000003F7048: D6560001 04050606
	s_mul_i32 s6, s18, 20                                      // 0000003F7050: 96069412
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000003F7054: BF870481
	v_cmp_gt_i32_e32 vcc_lo, s6, v1                            // 0000003F7058: 7C880206
	s_and_saveexec_b32 s6, vcc_lo                              // 0000003F705C: BE86206A
	s_cbranch_execz 222                                        // 0000003F7060: BFA500DE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3dc>
	.long 0xd72e0002                                           // 0000003F7064: D72E0002
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 0000003F7068: 020202FF 66666667
	v_and_b32_e32 v9, 31, v0                                   // 0000003F7070: 3612009F
	s_load_b64 s[8:9], s[0:1], 0x128                           // 0000003F7074: F4040200 F8000128
	s_mov_b32 s7, 0x76543210                                   // 0000003F707C: BE8700FF 76543210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F7084: BF8700A2
	v_lshrrev_b32_e32 v3, 31, v2                               // 0000003F7088: 3206049F
	v_ashrrev_i32_e32 v2, 3, v2                                // 0000003F708C: 34040483
	v_add_nc_u32_e32 v8, v2, v3                                // 0000003F7090: 4A100702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003F7094: BF870121
	.long 0xd72c0002                                           // 0000003F7098: D72C0002
	v_cndmask_b32_e32 v1, 0xffffffec, v8, vcc_lo               // 0000003F709C: 020210FF FFFFFFEC
	v_mad_i64_i32 v[4:5], null, 0x1400, v8, s[16:17]           // 0000003F70A4: D6FF7C04 004210FF 00001400
	v_add_lshl_u32 v1, v2, v1, 7                               // 0000003F70B0: D6470001 021E0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F70B8: BF870091
	v_lshl_or_b32 v2, v9, 2, v1                                // 0000003F70BC: D6560002 04050509
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000003F70C4: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F70C8: BF870091
	.long 0xd73c0002                                           // 0000003F70CC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000003F70D0: 02020481
	.long 0xd7006a04                                           // 0000003F70D4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000003F70D8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003F70DC: BF8700B1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000003F70E0: D5207C05 01AA0705
	s_waitcnt lgkmcnt(0)                                       // 0000003F70E8: BF89FC07
	.long 0xd7006a02                                           // 0000003F70EC: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000003F70F0: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 0000003F70F4: D5207C03 01AA0609
	global_load_b64 v[4:5], v[4:5], off                        // 0000003F70FC: DC560000 047C0004
	s_mov_b32 s8, 0x3db504f3                                   // 0000003F7104: BE8800FF 3DB504F3
	global_load_b64 v[6:7], v[2:3], off                        // 0000003F710C: DC560000 067C0002
	s_waitcnt vmcnt(1)                                         // 0000003F7114: BF8907F7
	.long 0x7e043904                                           // 0000003F7118: 7E043904
	v_and_b32_e32 v3, 0xffff0000, v4                           // 0000003F711C: 360608FF FFFF0000
	.long 0x7e083905                                           // 0000003F7124: 7E083905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000003F7128: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F7130: BF870004
	v_lshlrev_b32_e32 v14, 16, v2                              // 0000003F7134: 301C0490
	s_waitcnt vmcnt(0)                                         // 0000003F7138: BF8903F7
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003F713C: CC200803 8A020706
	v_lshlrev_b32_e32 v4, 16, v4                               // 0000003F7144: 30080890
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003F7148: CC200805 8A020B07
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000003F7150: 3404029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F7154: BF870224
	v_fma_mix_f32 v15, v6, v14, v3 op_sel_hi:[1,0,0]           // 0000003F7158: CC20000F 0C0E1D06
	v_fma_mix_f32 v6, v6, v14, -v3 op_sel_hi:[1,0,0]           // 0000003F7160: CC200006 8C0E1D06
	v_fma_mix_f32 v14, v7, v4, v5 op_sel_hi:[1,0,0]            // 0000003F7168: CC20000E 0C160907
	v_fma_mix_f32 v5, v7, v4, -v5 op_sel_hi:[1,0,0]            // 0000003F7170: CC200005 8C160907
	v_and_b32_e32 v10, 1, v0                                   // 0000003F7178: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000003F717C: 36160082
	v_and_b32_e32 v13, 8, v0                                   // 0000003F7180: 361A0088
	.long 0xd73c0001                                           // 0000003F7184: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003F7188: 02020281
	v_add_f32_e32 v16, v6, v5                                  // 0000003F718C: 06200B06
	v_sub_f32_e32 v5, v6, v5                                   // 0000003F7190: 080A0B06
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000003F7194: 7C941480
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F7198: BF870193
	v_mov_b32_dpp v10, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F719C: 7E1402FA FF016110
	v_mov_b32_dpp v17, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F71A4: 7E2202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F71AC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000003F71B4: BF8701D1
	v_add_f32_e32 v5, v5, v17                                  // 0000003F71B8: 060A2305
	v_mad_i64_i32 v[3:4], null, 0x1400, v8, s[4:5]             // 0000003F71BC: D6FF7C03 001210FF 00001400
	v_add_f32_e32 v8, v15, v14                                 // 0000003F71C8: 06101D0F
	v_sub_f32_e32 v14, v15, v14                                // 0000003F71CC: 081C1D0F
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 0000003F71D0: D501000F 21AA2110
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F71D8: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003F71E0: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003F71E8: BF870234
	v_mov_b32_dpp v16, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F71EC: 7E2002FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000003F71F4: D501000E 21AA1D0E
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000003F71FC: 7C941680
	v_dual_add_f32 v6, v8, v6 :: v_dual_lshlrev_b32 v7, 3, v9  // 0000003F7200: C9220D08 06061283
	v_add_f32_e32 v8, v15, v10                                 // 0000003F7208: 0610150F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F720C: BF870004
	v_add_f32_e32 v10, v14, v16                                // 0000003F7210: 0614210E
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F7214: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F721C: D5010005 21AA0B05
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F7224: 7E1602FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003F722C: D5010006 21AA0D06
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F7234: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000003F723C: D501000A 21AA150A
	v_add_f32_e32 v5, v5, v16                                  // 0000003F7244: 060A2105
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F7248: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003F7250: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 0000003F7258: 060C1706
	v_add_f32_e32 v10, v10, v15                                // 0000003F725C: 06141F0A
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F7260: 7E1E02FA FF016405
	v_and_b32_e32 v12, 4, v0                                   // 0000003F7268: 36180084
	v_add_f32_e32 v8, v8, v14                                  // 0000003F726C: 06101D08
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F7270: 7E1602FA FF016406
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F7278: 7E1C02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000003F7280: BF8701C4
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 0000003F7284: 7C941880
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003F7288: D5010006 21AA0D06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F7290: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000003F7298: D501000A 21AA150A
	v_add_f32_e32 v6, v6, v11                                  // 0000003F72A0: 060C1706
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003F72A4: BF870003
	v_add_f32_e32 v5, v5, v15                                  // 0000003F72A8: 060A1F05
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F72AC: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003F72B4: D5010008 21AA1108
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 0000003F72BC: 7C941A80
	v_add_f32_e32 v10, v10, v14                                // 0000003F72C0: 06141D0A
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F72C4: 7E1602FA FF016806
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F72CC: 7E1C02FA FF016805
	v_add_f32_e32 v8, v8, v12                                  // 0000003F72D4: 06101908
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003F72D8: D5010006 21AA0D06
	v_mov_b32_dpp v13, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F72E0: 7E1A02FA FF01680A
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F72E8: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000003F72F0: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F72F8: 7E1802FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003F7300: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 0000003F7308: 060C1706
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 0000003F730C: 7C981290
	v_add_f32_e32 v5, v5, v14                                  // 0000003F7310: 060A1D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F7314: BF870214
	v_dual_add_f32 v9, v10, v13 :: v_dual_add_f32 v8, v8, v12  // 0000003F7318: C9081B0A 09081908
	v_mov_b32_e32 v10, v6                                      // 0000003F7320: 7E140306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003F7324: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F732C: BF870214
	v_mov_b32_e32 v13, v5                                      // 0000003F7330: 7E1A0305
	v_mov_b32_e32 v12, v9                                      // 0000003F7334: 7E180309
	v_cndmask_b32_e64 v11, -v8, v8, vcc_lo                     // 0000003F7338: D501000B 21AA1108
	v_permlanex16_b32 v8, v8, s7, 0xfedcba98                   // 0000003F7340: D65C0008 03FC0F08 FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F734C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003F7354: D5010009 21AA1309
	v_permlanex16_b32 v10, v10, s7, 0xfedcba98                 // 0000003F735C: D65C000A 03FC0F0A FEDCBA98
	v_permlanex16_b32 v12, v12, s7, 0xfedcba98                 // 0000003F7368: D65C000C 03FC0F0C FEDCBA98
	v_permlanex16_b32 v13, v13, s7, 0xfedcba98                 // 0000003F7374: D65C000D 03FC0F0D FEDCBA98
	.long 0xd7006a01                                           // 0000003F7380: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 0000003F7384: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003F7388: BF8700D1
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 0000003F738C: D5207C02 01AA0504
	v_dual_add_f32 v3, v11, v8 :: v_dual_add_f32 v4, v6, v10   // 0000003F7394: C908110B 03041506
	v_add_f32_e32 v6, v9, v12                                  // 0000003F739C: 060C1909
	v_add_f32_e32 v5, v5, v13                                  // 0000003F73A0: 060A1B05
	.long 0xd7006a01                                           // 0000003F73A4: D7006A01
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 0000003F73A8: 02020F01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000003F73AC: D5207C02 01AA0480
	v_fma_mixhi_f16 v3, v3, s8, 0                              // 0000003F73B4: CC220003 02001103
	v_fma_mixlo_f16 v3, v4, s8, 0                              // 0000003F73BC: CC210003 02001104
	v_fma_mixhi_f16 v4, v5, s8, 0                              // 0000003F73C4: CC220004 02001105
	v_fma_mixlo_f16 v4, v6, s8, 0                              // 0000003F73CC: CC210004 02001106
	global_store_b64 v[1:2], v[3:4], off                       // 0000003F73D4: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 0000003F73DC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F73E0: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000003F73E4: 8B6A037E
	s_cbranch_vccnz 4                                          // 0000003F73E8: BFA40004 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3fc>
	s_nop 0                                                    // 0000003F73EC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003F73F0: BFB60003
	s_endpgm                                                   // 0000003F73F4: BFB00000
	s_cbranch_execz 65532                                      // 0000003F73F8: BFA5FFFC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_clause 0x3                                               // 0000003F73FC: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000003F7400: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x7c                                // 0000003F7408: F4000100 F800007C
	s_load_b32 s5, s[0:1], 0xc4                                // 0000003F7410: F4000140 F80000C4
	s_load_b32 s6, s[0:1], 0x10c                               // 0000003F7418: F4000180 F800010C
	v_and_b32_e32 v49, 31, v0                                  // 0000003F7420: 3662009F
	v_lshrrev_b32_e32 v48, 5, v0                               // 0000003F7424: 32600085
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003F7428: BF870002
	v_lshlrev_b32_e32 v7, 3, v49                               // 0000003F742C: 300E6283
	s_waitcnt lgkmcnt(0)                                       // 0000003F7430: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000003F7434: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000003F7438: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 0000003F743C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 0000003F7440: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F7444: BF870009
	s_and_b32 s4, s7, s4                                       // 0000003F7448: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000003F744C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000003F7450: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000003F7458: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 0000003F745C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 0000003F7460: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F7464: BF870009
	s_and_b32 s4, s7, s5                                       // 0000003F7468: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000003F746C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000003F7470: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000003F7474: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000003F7478: BF030602
	s_cselect_b32 s6, -1, 0                                    // 0000003F747C: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000003F7480: BF8704D9
	s_and_b32 s3, s3, s6                                       // 0000003F7484: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000003F7488: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000003F748C: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000003F7490: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000003F7494: 98030483
	s_mulk_i32 s3, 0x48                                        // 0000003F7498: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F749C: BF870009
	s_add_u32 s4, s0, s3                                       // 0000003F74A0: 80040300
	s_addc_u32 s5, s1, 0                                       // 0000003F74A4: 82058001
	s_clause 0x3                                               // 0000003F74A8: BF850003
	s_load_b32 s30, s[4:5], 0x38                               // 0000003F74AC: F4000782 F8000038
	s_load_b64 s[28:29], s[4:5], 0x40                          // 0000003F74B4: F4040702 F8000040
	s_load_b128 s[20:23], s[4:5], 0x28                         // 0000003F74BC: F4080502 F8000028
	s_load_b64 s[24:25], s[4:5], 0x20                          // 0000003F74C4: F4040602 F8000020
	s_waitcnt lgkmcnt(0)                                       // 0000003F74CC: BF89FC07
	s_abs_i32 s3, s21                                          // 0000003F74D0: BE831515
	s_sub_i32 s34, s2, s23                                     // 0000003F74D4: 81A21702
	s_cvt_f32_u32 s6, s3                                       // 0000003F74D8: BE866503
	s_sub_i32 s7, 0, s3                                        // 0000003F74DC: 81870380
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003F74E0: BF87029A
	v_rcp_iflag_f32_e32 v1, s6                                 // 0000003F74E4: 7E025606
	v_readfirstlane_b32 s6, v1                                 // 0000003F74E8: 7E0C0501
	s_mul_f32 s6, s6, 0x4f7ffffe                               // 0000003F74EC: A206FF06 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000003F74F4: BF87059B
	s_cvt_u32_f32 s6, s6                                       // 0000003F74F8: BE866706
	s_mul_i32 s7, s7, s6                                       // 0000003F74FC: 96070607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000003F7500: BF8704B9
	s_mul_hi_u32 s2, s6, s7                                    // 0000003F7504: 96820706
	s_abs_i32 s7, s34                                          // 0000003F7508: BE871522
	s_add_i32 s6, s6, s2                                       // 0000003F750C: 81060206
	s_mul_hi_u32 s2, s7, s6                                    // 0000003F7510: 96820607
	s_xor_b32 s6, s34, s21                                     // 0000003F7514: 8D061522
	s_mul_i32 s8, s2, s3                                       // 0000003F7518: 96080302
	s_ashr_i32 s6, s6, 31                                      // 0000003F751C: 86069F06
	s_sub_i32 s7, s7, s8                                       // 0000003F7520: 81870807
	s_add_i32 s8, s2, 1                                        // 0000003F7524: 81088102
	s_sub_i32 s9, s7, s3                                       // 0000003F7528: 81890307
	s_cmp_ge_u32 s7, s3                                        // 0000003F752C: BF090307
	s_cselect_b32 s2, s8, s2                                   // 0000003F7530: 98020208
	s_cselect_b32 s7, s9, s7                                   // 0000003F7534: 98070709
	s_add_i32 s8, s2, 1                                        // 0000003F7538: 81088102
	s_cmp_ge_u32 s7, s3                                        // 0000003F753C: BF090307
	s_cselect_b32 s2, s8, s2                                   // 0000003F7540: 98020208
	s_load_b256 s[8:15], s[4:5], null                          // 0000003F7544: F40C0202 F8000000
	s_xor_b32 s2, s2, s6                                       // 0000003F754C: 8D020602
	s_ashr_i32 s27, s19, 31                                    // 0000003F7550: 861B9F13
	s_sub_i32 s26, s2, s6                                      // 0000003F7554: 819A0602
	s_lshr_b32 s2, s27, 25                                     // 0000003F7558: 8502991B
	s_mul_i32 s36, s26, s21                                    // 0000003F755C: 9624151A
	s_add_i32 s2, s19, s2                                      // 0000003F7560: 81020213
	s_sub_i32 s3, s34, s36                                     // 0000003F7564: 81832422
	s_ashr_i32 s2, s2, 7                                       // 0000003F7568: 86028702
	s_mul_i32 s23, s22, s3                                     // 0000003F756C: 96170316
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000003F7570: BF870499
	s_add_i32 s3, s23, s22                                     // 0000003F7574: 81031617
	s_min_i32 s2, s2, s3                                       // 0000003F7578: 89020302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000003F757C: BF8704B9
	s_sub_i32 s7, s2, s23                                      // 0000003F7580: 81871702
	s_mov_b32 s2, exec_lo                                      // 0000003F7584: BE82007E
	s_lshl_b32 s22, s7, 2                                      // 0000003F7588: 84168207
	.long 0xd4c3007e                                           // 0000003F758C: D4C3007E
	v_cndmask_b32_e32 v1, s22, v48, vcc_lo                     // 0000003F7590: 02026016
	s_xor_b32 s2, exec_lo, s2                                  // 0000003F7594: 8D02027E
	v_lshlrev_b32_e32 v7, 3, v49                               // 0000003F7598: 300E6283
	s_and_not1_saveexec_b32 s31, s2                            // 0000003F759C: BE9F3002
	s_cbranch_execz 286                                        // 0000003F75A0: BFA5011E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xa1c>
	s_abs_i32 s33, s7                                          // 0000003F75A4: BEA11507
	v_lshlrev_b32_e32 v9, 7, v48                               // 0000003F75A8: 30126087
	s_cvt_f32_u32 s2, s33                                      // 0000003F75AC: BE826521
	v_and_b32_e32 v4, 4, v0                                    // 0000003F75B0: 36080084
	v_and_b32_e32 v5, 8, v0                                    // 0000003F75B4: 360A0088
	v_lshl_or_b32 v8, v48, 8, v7                               // 0000003F75B8: D6560008 041D1130
	v_rcp_iflag_f32_e32 v1, s2                                 // 0000003F75C0: 7E025602
	s_sub_i32 s2, 0, s33                                       // 0000003F75C4: 81822180
	v_lshl_add_u32 v9, s23, 7, v9                              // 0000003F75C8: D6460009 04250E17
	s_ashr_i32 s39, s7, 31                                     // 0000003F75D0: 86279F07
	.long 0xd44a0004                                           // 0000003F75D4: D44A0004
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 0000003F75D8: 02020880
	s_mul_i32 s41, s39, 0x1400                                 // 0000003F75DC: 9629FF27 00001400
	.long 0xd44a0005                                           // 0000003F75E4: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000003F75E8: 02020A80
	s_lshl_b32 s6, s7, 7                                       // 0000003F75EC: 84068707
	s_add_i32 s35, s18, -1                                     // 0000003F75F0: 8123C112
	s_mov_b32 s37, s19                                         // 0000003F75F4: BEA50013
	v_dual_mul_f32 v1, 0x4f7ffffe, v1 :: v_dual_and_b32 v2, 1, v0// 0000003F75F8: C8E402FF 01020081 4F7FFFFE
	s_mov_b32 s38, 0                                           // 0000003F7604: BEA60080
	s_lshl_b32 s40, s7, 8                                      // 0000003F7608: 84288807
	s_mov_b32 s42, 0x76543210                                  // 0000003F760C: BEAA00FF 76543210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000003F7614: BF8701C1
	v_cvt_u32_f32_e32 v3, v1                                   // 0000003F7618: 7E060F01
	v_dual_mov_b32 v4, v48 :: v_dual_and_b32 v1, 2, v0         // 0000003F761C: CA240130 04000082
	s_mov_b32 s43, 0x3db504f3                                  // 0000003F7624: BEAB00FF 3DB504F3
	v_cmp_gt_u32_e32 vcc_lo, 16, v49                           // 0000003F762C: 7C986290
	.long 0xd72c0006                                           // 0000003F7630: D72C0006
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 0000003F7634: 02020602
	.long 0xd44a0002                                           // 0000003F7638: D44A0002
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000003F763C: 02020480
	.long 0xd44a0003                                           // 0000003F7640: D44A0003
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000003F7644: 02020280
	v_subrev_nc_u32_e32 v2, s41, v8                            // 0000003F7648: 4E041029
	v_lshl_or_b32 v1, v49, 2, v9                               // 0000003F764C: D6560001 04250531
	s_sub_i32 s41, 0, s6                                       // 0000003F7654: 81A90680
	.long 0xd72d0006                                           // 0000003F7658: D72D0006
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000003F765C: 02020D03
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F7660: BF870001
	v_add_nc_u32_e32 v3, v3, v6                                // 0000003F7664: 4A060D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F7668: BF870091
	.long 0xd72d0005                                           // 0000003F766C: D72D0005
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 0000003F7670: 02020704
	.long 0xd72c0006                                           // 0000003F7674: D72C0006
	v_cndmask_b32_e32 v0, v5, v33, vcc_lo                      // 0000003F7678: 02004305
	v_add_nc_u32_e32 v8, 1, v5                                 // 0000003F767C: 4A100A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F7680: BF870092
	v_sub_nc_u32_e32 v6, v4, v6                                // 0000003F7684: 4C0C0D04
	v_subrev_nc_u32_e32 v9, s33, v6                            // 0000003F7688: 4E120C21
	.long 0xd44b0006                                           // 0000003F768C: D44B0006
	v_cndmask_b32_e32 v1, s33, v6, vcc_lo                      // 0000003F7690: 02020C21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F7694: BF870191
	v_cndmask_b32_e64 v5, v5, v8, s6                           // 0000003F7698: D5010005 001A1105
	v_cndmask_b32_e64 v6, v6, v9, s6                           // 0000003F76A0: D5010006 001A1306
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F76A8: BF870112
	v_add_nc_u32_e32 v8, 1, v5                                 // 0000003F76AC: 4A100A81
	.long 0xd44b0006                                           // 0000003F76B0: D44B0006
	v_cndmask_b32_e32 v1, s33, v6, vcc_lo                      // 0000003F76B4: 02020C21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F76B8: BF870091
	v_cndmask_b32_e64 v5, v5, v8, s6                           // 0000003F76BC: D5010005 001A1105
	v_xor_b32_e32 v10, s39, v5                                 // 0000003F76C4: 3A140A27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003F76C8: BF870121
	v_subrev_nc_u32_e32 v11, s39, v10                          // 0000003F76CC: 4E161427
	.long 0xd72c000a                                           // 0000003F76D0: D72C000A
	v_cndmask_b32_e32 v1, 0x1400, v10, vcc_lo                  // 0000003F76D4: 020214FF 00001400
	v_min_i32_e32 v8, s35, v11                                 // 0000003F76DC: 22101623
	v_mad_u64_u32 v[5:6], null, s41, v11, v[1:2]               // 0000003F76E0: D6FE7C05 04061629
	.long 0xd72c000b                                           // 0000003F76E8: D72C000B
	v_cndmask_b32_e32 v1, s40, v11, vcc_lo                     // 0000003F76EC: 02021628
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F76F0: BF870193
	v_mad_i64_i32 v[8:9], null, v8, s37, 0                     // 0000003F76F4: D6FF7C08 02004B08
	v_ashrrev_i32_e32 v6, 31, v5                               // 0000003F76FC: 340C0A9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F7700: BF870193
	v_sub_nc_u32_e32 v10, v10, v11                             // 0000003F7704: 4C14170A
	.long 0xd73c0008                                           // 0000003F7708: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000003F770C: 02021081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F7710: BF870193
	.long 0xd73c0005                                           // 0000003F7714: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000003F7718: 02020A81
	v_add_nc_u32_e32 v10, v2, v10                              // 0000003F771C: 4A141502
	v_add_nc_u32_e32 v2, 0x800, v2                             // 0000003F7720: 4A0404FF 00000800
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F7728: BF870094
	.long 0xd700060c                                           // 0000003F772C: D700060C
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 0000003F7730: 02021010
	v_add_co_ci_u32_e64 v13, null, s17, v9, s6                 // 0000003F7734: D5207C0D 001A1211
	s_waitcnt lgkmcnt(0)                                       // 0000003F773C: BF89FC07
	.long 0xd7000608                                           // 0000003F7740: D7000608
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000003F7744: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F7748: BF8700A1
	v_add_co_ci_u32_e64 v9, null, s11, v6, s6                  // 0000003F774C: D5207C09 001A0C0B
	.long 0xd7000605                                           // 0000003F7754: D7000605
	v_cndmask_b32_e32 v1, v12, v5, vcc_lo                      // 0000003F7758: 02020B0C
	v_add_co_ci_u32_e64 v6, null, v13, v6, s6                  // 0000003F775C: D5207C06 001A0D0D
	global_load_b64 v[5:6], v[5:6], off                        // 0000003F7764: DC560000 057C0005
	global_load_b64 v[8:9], v[8:9], off                        // 0000003F776C: DC560000 087C0008
	s_waitcnt vmcnt(1)                                         // 0000003F7774: BF8907F7
	.long 0x7e1a3906                                           // 0000003F7778: 7E1A3906
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000003F777C: 360C0CFF FFFF0000
	.long 0x7e183905                                           // 0000003F7784: 7E183905
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F7788: BF8701A3
	v_lshlrev_b32_e32 v13, 16, v13                             // 0000003F778C: 301A1A90
	s_waitcnt vmcnt(0)                                         // 0000003F7790: BF8903F7
	v_fma_mix_f32 v6, v9, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003F7794: CC200806 8A020D09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F779C: BF870113
	v_lshlrev_b32_e32 v12, 16, v12                             // 0000003F77A0: 30181890
	v_fma_mix_f32 v14, v9, v13, v6 op_sel_hi:[1,0,0]           // 0000003F77A4: CC20000E 0C1A1B09
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000003F77AC: 360A0AFF FFFF0000
	v_fma_mix_f32 v6, v9, v13, -v6 op_sel_hi:[1,0,0]           // 0000003F77B4: CC200006 8C1A1B09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F77BC: BF870092
	v_fma_mix_f32 v5, v8, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003F77C0: CC200805 8A020B08
	v_fma_mix_f32 v15, v8, v12, v5 op_sel_hi:[1,0,0]           // 0000003F77C8: CC20000F 0C161908
	v_add_nc_u32_e32 v1, 0x400, v1                             // 0000003F77D0: 4A0202FF 00000400
	v_fma_mix_f32 v5, v8, v12, -v5 op_sel_hi:[1,0,0]           // 0000003F77D8: CC200005 8C161908
	v_add_nc_u32_e32 v4, 8, v4                                 // 0000003F77E0: 4A080888
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F77E4: BF870194
	v_add_f32_e32 v8, v15, v14                                 // 0000003F77E8: 06101D0F
	v_dual_sub_f32 v12, v15, v14 :: v_dual_add_f32 v9, v6, v5  // 0000003F77EC: C9481D0F 0C080B06
	v_sub_f32_e32 v5, v5, v6                                   // 0000003F77F4: 080A0D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F77F8: BF870214
	.long 0xd4430006                                           // 0000003F77FC: D4430006
	v_cndmask_b32_e32 v1, s22, v4, vcc_lo                      // 0000003F7800: 02020816
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F7804: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 0000003F780C: D5010008 200A1108
	v_mov_b32_dpp v14, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F7814: 7E1C02FA FF01610C
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F781C: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 0000003F7824: D5010005 200A0B05
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 0000003F782C: D501000C 200A190C
	v_add_f32_e32 v6, v8, v6                                   // 0000003F7834: 060C0D08
	v_mov_b32_dpp v13, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F7838: 7E1A02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 0000003F7840: D5010009 200A1309
	v_add_f32_e32 v5, v5, v15                                  // 0000003F7848: 060A1F05
	s_or_b32 s38, s6, s38                                      // 0000003F784C: 8C262606
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F7850: BF870112
	v_dual_add_f32 v8, v9, v13 :: v_dual_add_f32 v9, v12, v14  // 0000003F7854: C9081B09 08081D0C
	v_mov_b32_dpp v15, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F785C: 7E1E02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 0000003F7864: D5010005 200E0B05
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F786C: 7E1802FA FF016206
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F7874: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F7878: 7E1A02FA FF016208
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F7880: 7E1C02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000003F7888: D5010009 200E1309
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 0000003F7890: D5010006 200E0D06
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 0000003F7898: D5010008 200E1108
	v_add_f32_e32 v5, v5, v15                                  // 0000003F78A0: 060A1F05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F78A4: BF870114
	v_add_f32_e32 v9, v9, v14                                  // 0000003F78A8: 06121D09
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F78AC: 7E1E02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 0000003F78B4: D5010005 20120B05
	v_add_f32_e32 v6, v6, v12                                  // 0000003F78BC: 060C1906
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F78C0: BF870224
	v_mov_b32_dpp v14, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F78C4: 7E1C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 0000003F78CC: D5010009 20121309
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v5, v5, v15   // 0000003F78D4: C9081B08 08041F05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F78DC: BF870224
	v_mov_b32_dpp v12, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F78E0: 7E1802FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 0000003F78E8: D5010006 20120D06
	v_add_f32_e32 v9, v9, v14                                  // 0000003F78F0: 06121D09
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F78F4: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F78F8: 7E1A02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 0000003F7900: D5010008 20121108
	v_mov_b32_dpp v15, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F7908: 7E1E02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 0000003F7910: D5010005 20160B05
	v_add_f32_e32 v6, v6, v12                                  // 0000003F7918: 060C1906
	v_mov_b32_dpp v14, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F791C: 7E1C02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 0000003F7924: D5010009 20161309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F792C: BF870214
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v5, v5, v15   // 0000003F7930: C9081B08 08041F05
	v_mov_b32_dpp v12, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F7938: 7E1802FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 0000003F7940: D5010006 20160D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F7948: BF870214
	v_add_f32_e32 v9, v9, v14                                  // 0000003F794C: 06121D09
	v_mov_b32_dpp v13, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F7950: 7E1A02FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 0000003F7958: D5010008 20161108
	v_mov_b32_e32 v15, v5                                      // 0000003F7960: 7E1E0305
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F7964: D5010005 21AA0B05
	v_mov_b32_e32 v14, v9                                      // 0000003F796C: 7E1C0309
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003F7970: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v13                                  // 0000003F7978: 06101B08
	v_add_f32_e32 v6, v6, v12                                  // 0000003F797C: 060C1906
	v_permlanex16_b32 v15, v15, s42, 0xfedcba98                // 0000003F7980: D65C000F 03FC550F FEDCBA98
	v_permlanex16_b32 v14, v14, s42, 0xfedcba98                // 0000003F798C: D65C000E 03FC550E FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F7998: BF870193
	v_dual_mov_b32 v13, v8 :: v_dual_mov_b32 v12, v6           // 0000003F799C: CA100108 0D0C0106
	v_add_f32_e32 v11, v5, v15                                 // 0000003F79A4: 06161F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003F79A8: D5010008 21AA1108
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003F79B0: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003F79B8: BF870124
	v_permlanex16_b32 v13, v13, s42, 0xfedcba98                // 0000003F79BC: D65C000D 03FC550D FEDCBA98
	v_permlanex16_b32 v12, v12, s42, 0xfedcba98                // 0000003F79C8: D65C000C 03FC550C FEDCBA98
	v_dual_add_f32 v9, v9, v14 :: v_dual_add_f32 v8, v8, v13   // 0000003F79D4: C9081D09 09081B08
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F79DC: BF870112
	v_add_f32_e32 v6, v6, v12                                  // 0000003F79E0: 060C1906
	v_fma_mixhi_f16 v5, v8, s43, 0                             // 0000003F79E4: CC220005 02005708
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003F79EC: BF870002
	v_fma_mixlo_f16 v5, v6, s43, 0                             // 0000003F79F0: CC210005 02005706
	v_fma_mixhi_f16 v6, v11, s43, 0                            // 0000003F79F8: CC220006 0200570B
	v_fma_mixlo_f16 v6, v9, s43, 0                             // 0000003F7A00: CC210006 02005709
	ds_store_b64 v10, v[5:6]                                   // 0000003F7A08: D9340000 0000050A
	s_and_not1_b32 exec_lo, exec_lo, s38                       // 0000003F7A10: 917E267E
	s_cbranch_execnz 65300                                     // 0000003F7A14: BFA6FF14 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x668>
	s_or_b32 exec_lo, exec_lo, s38                             // 0000003F7A18: 8C7E267E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F7A1C: BF870009
	s_or_b32 exec_lo, exec_lo, s31                             // 0000003F7A20: 8C7E1F7E
	s_bfe_i32 s6, s7, 0x1001c                                  // 0000003F7A24: 9386FF07 0001001C
	v_mad_u32_u24 v9, v49, 24, 0x2f0                           // 0000003F7A2C: D60B0009 03FD3131 000002F0
	s_lshr_b64 s[2:3], s[6:7], 29                              // 0000003F7A38: 85829D06
	s_lshr_b32 s3, s27, 28                                     // 0000003F7A3C: 85039C1B
	s_add_i32 s2, s2, 7                                        // 0000003F7A40: 81028702
	s_add_i32 s3, s19, s3                                      // 0000003F7A44: 81030313
	s_ashr_i32 s2, s2, 3                                       // 0000003F7A48: 86028302
	v_lshrrev_b32_e32 v1, 5, v9                                // 0000003F7A4C: 32021285
	.long 0xd72c0008                                           // 0000003F7A50: D72C0008
	v_cndmask_b32_e32 v1, s2, v48, vcc_lo                      // 0000003F7A54: 02026002
	s_ashr_i32 s3, s3, 4                                       // 0000003F7A58: 86038403
	s_lshl_b32 s4, s7, 3                                       // 0000003F7A5C: 84048307
	s_lshl_b32 s5, s23, 3                                      // 0000003F7A60: 84058317
	s_mul_hi_i32 s7, s26, s3                                   // 0000003F7A64: 9707031A
	s_mul_i32 s3, s26, s3                                      // 0000003F7A68: 9603031A
	s_ashr_i32 s6, s5, 31                                      // 0000003F7A6C: 86069F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v49                            // 0000003F7A70: 7C946280
	v_add_nc_u32_e32 v2, s2, v8                                // 0000003F7A74: 4A041002
	s_add_u32 s2, s3, s5                                       // 0000003F7A78: 80020503
	s_addc_u32 s3, s7, s6                                      // 0000003F7A7C: 82030607
	s_mul_i32 s5, s2, 0x300                                    // 0000003F7A80: 9605FF02 00000300
	s_mulk_i32 s3, 0x300                                       // 0000003F7A88: B8030300
	v_min_i32_e32 v50, s4, v2                                  // 0000003F7A8C: 22640404
	v_subrev_nc_u32_e32 v2, 24, v1                             // 0000003F7A90: 4E040298
	v_add_nc_u32_e32 v1, 1, v8                                 // 0000003F7A94: 4A021081
	s_mul_hi_u32 s4, s2, 0x300                                 // 0000003F7A98: 9684FF02 00000300
	v_add_nc_u32_e32 v10, 8, v9                                // 0000003F7AA0: 4A141288
	s_add_i32 s3, s4, s3                                       // 0000003F7AA4: 81030304
	v_cndmask_b32_e64 v3, v2, 23, vcc_lo                       // 0000003F7AA8: D5010003 01A92F02
	.long 0xd4410002                                           // 0000003F7AB0: D4410002
	v_cndmask_b32_e32 v1, v1, v50, vcc_lo                      // 0000003F7AB4: 02026501
	s_waitcnt lgkmcnt(0)                                       // 0000003F7AB8: BF89FC07
	s_add_u32 s4, s8, s5                                       // 0000003F7ABC: 80040508
	s_addc_u32 s5, s9, s3                                      // 0000003F7AC0: 82050309
	s_waitcnt_vscnt null, 0x0                                  // 0000003F7AC4: BC7C0000
	s_barrier                                                  // 0000003F7AC8: BFBD0000
	buffer_gl0_inv                                             // 0000003F7ACC: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 0000003F7AD4: BE832002
	s_cbranch_execz 121                                        // 0000003F7AD8: BFA50079 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xcc0>
	v_lshrrev_b32_e32 v2, 5, v10                               // 0000003F7ADC: 32041485
	.long 0xd4440002                                           // 0000003F7AE0: D4440002
	v_cndmask_b32_e32 v1, 23, v3, vcc_lo                       // 0000003F7AE4: 02020697
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F7AE8: BF870112
	v_subrev_nc_u32_e32 v2, 24, v2                             // 0000003F7AEC: 4E040498
	v_cndmask_b32_e64 v4, 0xe9, 1, s2                          // 0000003F7AF0: D5010004 000902FF 000000E9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F7AFC: BF870112
	v_cndmask_b32_e64 v5, v2, 23, vcc_lo                       // 0000003F7B00: D5010005 01A92F02
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v13, v4, v3      // 0000003F7B08: CA200080 040C0704
	v_mad_i64_i32 v[1:2], null, 0x300, v1, s[4:5]              // 0000003F7B10: D6FF7C01 001202FF 00000300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F7B1C: BF870193
	.long 0xd4440002                                           // 0000003F7B20: D4440002
	v_cndmask_b32_e32 v1, 23, v5, vcc_lo                       // 0000003F7B24: 02020A97
	v_lshlrev_b32_e32 v14, 24, v13                             // 0000003F7B28: 301C1A98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F7B2C: BF870224
	.long 0xd73c000b                                           // 0000003F7B30: D73C000B
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 0000003F7B34: 02020682
	v_bfe_i32 v16, v13, 7, 1                                   // 0000003F7B38: D6110010 02050F0D
	v_cndmask_b32_e64 v15, 0xe9, 1, s2                         // 0000003F7B40: D501000F 000902FF 000000E9
	v_mov_b32_e32 v6, v4                                       // 0000003F7B4C: 7E0C0304
	v_ashrrev_i32_e32 v13, 22, v14                             // 0000003F7B50: 341A1C96
	.long 0xd700020b                                           // 0000003F7B54: D700020B
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 0000003F7B58: 02021701
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F7B5C: BF870214
	v_add_nc_u32_e32 v15, v15, v5                              // 0000003F7B60: 4A1E0B0F
	.long 0xd73c0004                                           // 0000003F7B64: D73C0004
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000003F7B68: 02020A82
	v_add_co_ci_u32_e64 v12, null, v2, v12, s2                 // 0000003F7B6C: D5207C0C 000A1902
	.long 0xd700020d                                           // 0000003F7B74: D700020D
	v_cndmask_b32_e32 v1, v1, v13, vcc_lo                      // 0000003F7B78: 02021B01
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003F7B7C: BF870244
	v_lshlrev_b32_e32 v6, 24, v15                              // 0000003F7B80: 300C1E98
	v_bfe_i32 v15, v15, 7, 1                                   // 0000003F7B84: D611000F 02050F0F
	v_add_co_ci_u32_e64 v14, null, v2, v16, s2                 // 0000003F7B8C: D5207C0E 000A2102
	.long 0xd7000204                                           // 0000003F7B94: D7000204
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 0000003F7B98: 02020901
	v_ashrrev_i32_e32 v6, 22, v6                               // 0000003F7B9C: 340C0C96
	v_add_co_ci_u32_e64 v5, null, v2, v5, s2                   // 0000003F7BA0: D5207C05 000A0B02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F7BA8: BF870092
	.long 0xd7000201                                           // 0000003F7BAC: D7000201
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 0000003F7BB0: 02020D01
	v_add_co_ci_u32_e64 v2, null, v2, v15, s2                  // 0000003F7BB4: D5207C02 000A1F02
	s_clause 0x1f                                              // 0000003F7BBC: BF85001F
	global_load_b32 v54, v[11:12], off                         // 0000003F7BC0: DC520000 367C000B
	global_load_b32 v53, v[11:12], off offset:96               // 0000003F7BC8: DC520060 357C000B
	global_load_b32 v52, v[11:12], off offset:192              // 0000003F7BD0: DC5200C0 347C000B
	global_load_b32 v51, v[11:12], off offset:288              // 0000003F7BD8: DC520120 337C000B
	global_load_b32 v55, v[11:12], off offset:384              // 0000003F7BE0: DC520180 377C000B
	global_load_b32 v56, v[11:12], off offset:480              // 0000003F7BE8: DC5201E0 387C000B
	global_load_b32 v57, v[11:12], off offset:576              // 0000003F7BF0: DC520240 397C000B
	global_load_b32 v58, v[11:12], off offset:672              // 0000003F7BF8: DC5202A0 3A7C000B
	global_load_b32 v63, v[13:14], off                         // 0000003F7C00: DC520000 3F7C000D
	global_load_b32 v61, v[13:14], off offset:96               // 0000003F7C08: DC520060 3D7C000D
	global_load_b32 v60, v[13:14], off offset:192              // 0000003F7C10: DC5200C0 3C7C000D
	global_load_b32 v59, v[13:14], off offset:288              // 0000003F7C18: DC520120 3B7C000D
	global_load_b32 v72, v[13:14], off offset:384              // 0000003F7C20: DC520180 487C000D
	global_load_b32 v69, v[13:14], off offset:480              // 0000003F7C28: DC5201E0 457C000D
	global_load_b32 v67, v[13:14], off offset:576              // 0000003F7C30: DC520240 437C000D
	global_load_b32 v65, v[13:14], off offset:672              // 0000003F7C38: DC5202A0 417C000D
	global_load_b32 v70, v[4:5], off                           // 0000003F7C40: DC520000 467C0004
	global_load_b32 v66, v[4:5], off offset:96                 // 0000003F7C48: DC520060 427C0004
	global_load_b32 v64, v[4:5], off offset:192                // 0000003F7C50: DC5200C0 407C0004
	global_load_b32 v62, v[4:5], off offset:288                // 0000003F7C58: DC520120 3E7C0004
	global_load_b32 v78, v[4:5], off offset:384                // 0000003F7C60: DC520180 4E7C0004
	global_load_b32 v77, v[4:5], off offset:480                // 0000003F7C68: DC5201E0 4D7C0004
	global_load_b32 v76, v[4:5], off offset:576                // 0000003F7C70: DC520240 4C7C0004
	global_load_b32 v75, v[4:5], off offset:672                // 0000003F7C78: DC5202A0 4B7C0004
	global_load_b32 v74, v[1:2], off                           // 0000003F7C80: DC520000 4A7C0001
	global_load_b32 v73, v[1:2], off offset:96                 // 0000003F7C88: DC520060 497C0001
	global_load_b32 v71, v[1:2], off offset:192                // 0000003F7C90: DC5200C0 477C0001
	global_load_b32 v68, v[1:2], off offset:288                // 0000003F7C98: DC520120 447C0001
	global_load_b32 v82, v[1:2], off offset:384                // 0000003F7CA0: DC520180 527C0001
	global_load_b32 v81, v[1:2], off offset:480                // 0000003F7CA8: DC5201E0 517C0001
	global_load_b32 v80, v[1:2], off offset:576                // 0000003F7CB0: DC520240 507C0001
	global_load_b32 v79, v[1:2], off offset:672                // 0000003F7CB8: DC5202A0 4F7C0001
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003F7CC0: 8C7E037E
	.long 0xd4410002                                           // 0000003F7CC4: D4410002
	v_cndmask_b32_e32 v1, v8, v50, vcc_lo                      // 0000003F7CC8: 02026508
	s_and_saveexec_b32 s6, s2                                  // 0000003F7CCC: BE862002
	s_cbranch_execz 124                                        // 0000003F7CD0: BFA5007C <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xec4>
	v_lshrrev_b32_e32 v1, 5, v10                               // 0000003F7CD4: 32021485
	.long 0xd4440003                                           // 0000003F7CD8: D4440003
	v_cndmask_b32_e32 v1, 23, v3, vcc_lo                       // 0000003F7CDC: 02020697
	v_mad_i64_i32 v[5:6], null, 0x300, v8, s[4:5]              // 0000003F7CE0: D6FF7C05 001210FF 00000300
	v_mov_b32_e32 v4, 0                                        // 0000003F7CEC: 7E080280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F7CF0: BF870214
	v_subrev_nc_u32_e32 v1, 24, v1                             // 0000003F7CF4: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s3                          // 0000003F7CF8: D5010002 000D02FF 000000E9
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F7D04: BF870193
	.long 0xd73c000b                                           // 0000003F7D08: D73C000B
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 0000003F7D0C: 02020682
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 0000003F7D10: D5010001 01A92F01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F7D18: BF870113
	v_dual_mov_b32 v2, v4 :: v_dual_add_nc_u32 v13, v2, v3     // 0000003F7D1C: CA200104 020C0702
	.long 0xd4440003                                           // 0000003F7D24: D4440003
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 0000003F7D28: 02020297
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F7D2C: BF8701A2
	v_lshlrev_b32_e32 v14, 24, v13                             // 0000003F7D30: 301C1A98
	v_bfe_i32 v4, v13, 7, 1                                    // 0000003F7D34: D6110004 02050F0D
	v_cndmask_b32_e64 v15, 0xe9, 1, s3                         // 0000003F7D3C: D501000F 000D02FF 000000E9
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F7D48: BF8700A3
	v_ashrrev_i32_e32 v13, 22, v14                             // 0000003F7D4C: 341A1C96
	.long 0xd700030b                                           // 0000003F7D50: D700030B
	v_cndmask_b32_e32 v1, v5, v11, vcc_lo                      // 0000003F7D54: 02021705
	v_add_co_ci_u32_e64 v12, null, v6, v12, s3                 // 0000003F7D58: D5207C0C 000E1906
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F7D60: BF870214
	v_add_nc_u32_e32 v14, v15, v1                              // 0000003F7D64: 4A1C030F
	.long 0xd700030f                                           // 0000003F7D68: D700030F
	v_cndmask_b32_e32 v1, v5, v13, vcc_lo                      // 0000003F7D6C: 02021B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F7D70: BF870191
	v_add_co_ci_u32_e64 v16, null, v6, v4, s3                  // 0000003F7D74: D5207C10 000E0906
	v_lshlrev_b32_e32 v17, 24, v14                             // 0000003F7D7C: 30221C98
	.long 0xd73c0001                                           // 0000003F7D80: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000003F7D84: 02020282
	v_bfe_i32 v4, v14, 7, 1                                    // 0000003F7D88: D6110004 02050F0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F7D90: BF870193
	v_ashrrev_i32_e32 v13, 22, v17                             // 0000003F7D94: 341A2296
	.long 0xd7000311                                           // 0000003F7D98: D7000311
	v_cndmask_b32_e32 v1, v5, v1, vcc_lo                       // 0000003F7D9C: 02020305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F7DA0: BF870191
	v_add_co_ci_u32_e64 v18, null, v6, v2, s3                  // 0000003F7DA4: D5207C12 000E0506
	.long 0xd7000313                                           // 0000003F7DAC: D7000313
	v_cndmask_b32_e32 v1, v5, v13, vcc_lo                      // 0000003F7DB0: 02021B05
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F7DB4: BF870001
	v_add_co_ci_u32_e64 v20, null, v6, v4, s3                  // 0000003F7DB8: D5207C14 000E0906
	s_clause 0x1f                                              // 0000003F7DC0: BF85001F
	global_load_b32 v2, v[11:12], off                          // 0000003F7DC4: DC520000 027C000B
	global_load_b32 v14, v[11:12], off offset:96               // 0000003F7DCC: DC520060 0E7C000B
	global_load_b32 v43, v[11:12], off offset:192              // 0000003F7DD4: DC5200C0 2B7C000B
	global_load_b32 v39, v[11:12], off offset:288              // 0000003F7DDC: DC520120 277C000B
	global_load_b32 v35, v[11:12], off offset:384              // 0000003F7DE4: DC520180 237C000B
	global_load_b32 v31, v[11:12], off offset:480              // 0000003F7DEC: DC5201E0 1F7C000B
	global_load_b32 v27, v[11:12], off offset:576              // 0000003F7DF4: DC520240 1B7C000B
	global_load_b32 v23, v[11:12], off offset:672              // 0000003F7DFC: DC5202A0 177C000B
	global_load_b32 v1, v[15:16], off                          // 0000003F7E04: DC520000 017C000F
	global_load_b32 v13, v[15:16], off offset:96               // 0000003F7E0C: DC520060 0D7C000F
	global_load_b32 v42, v[15:16], off offset:192              // 0000003F7E14: DC5200C0 2A7C000F
	global_load_b32 v38, v[15:16], off offset:288              // 0000003F7E1C: DC520120 267C000F
	global_load_b32 v34, v[15:16], off offset:384              // 0000003F7E24: DC520180 227C000F
	global_load_b32 v30, v[15:16], off offset:480              // 0000003F7E2C: DC5201E0 1E7C000F
	global_load_b32 v26, v[15:16], off offset:576              // 0000003F7E34: DC520240 1A7C000F
	global_load_b32 v22, v[15:16], off offset:672              // 0000003F7E3C: DC5202A0 167C000F
	global_load_b32 v6, v[17:18], off                          // 0000003F7E44: DC520000 067C0011
	global_load_b32 v47, v[17:18], off offset:96               // 0000003F7E4C: DC520060 2F7C0011
	global_load_b32 v45, v[17:18], off offset:192              // 0000003F7E54: DC5200C0 2D7C0011
	global_load_b32 v41, v[17:18], off offset:288              // 0000003F7E5C: DC520120 297C0011
	global_load_b32 v37, v[17:18], off offset:384              // 0000003F7E64: DC520180 257C0011
	global_load_b32 v33, v[17:18], off offset:480              // 0000003F7E6C: DC5201E0 217C0011
	global_load_b32 v29, v[17:18], off offset:576              // 0000003F7E74: DC520240 1D7C0011
	global_load_b32 v25, v[17:18], off offset:672              // 0000003F7E7C: DC5202A0 197C0011
	global_load_b32 v5, v[19:20], off                          // 0000003F7E84: DC520000 057C0013
	global_load_b32 v46, v[19:20], off offset:96               // 0000003F7E8C: DC520060 2E7C0013
	global_load_b32 v44, v[19:20], off offset:192              // 0000003F7E94: DC5200C0 2C7C0013
	global_load_b32 v40, v[19:20], off offset:288              // 0000003F7E9C: DC520120 287C0013
	global_load_b32 v36, v[19:20], off offset:384              // 0000003F7EA4: DC520180 247C0013
	global_load_b32 v32, v[19:20], off offset:480              // 0000003F7EAC: DC5201E0 207C0013
	global_load_b32 v28, v[19:20], off offset:576              // 0000003F7EB4: DC520240 1C7C0013
	global_load_b32 v24, v[19:20], off offset:672              // 0000003F7EBC: DC5202A0 187C0013
	s_or_b32 exec_lo, exec_lo, s6                              // 0000003F7EC4: 8C7E067E
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v84, 0             // 0000003F7EC8: CA100080 11540080
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v86, 0             // 0000003F7ED0: CA100080 53560080
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v88, 0             // 0000003F7ED8: CA100080 55580080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v90, 0             // 0000003F7EE0: CA100080 575A0080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v92, 0             // 0000003F7EE8: CA100080 595C0080
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v98, 0             // 0000003F7EF0: CA100080 5B620080
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v106, 0            // 0000003F7EF8: CA100080 5D6A0080
	v_dual_mov_b32 v95, 0 :: v_dual_mov_b32 v108, 0            // 0000003F7F00: CA100080 5F6C0080
	v_dual_mov_b32 v99, 0 :: v_dual_mov_b32 v112, 0            // 0000003F7F08: CA100080 63700080
	v_dual_mov_b32 v101, 0 :: v_dual_mov_b32 v96, 0            // 0000003F7F10: CA100080 65600080
	v_dual_mov_b32 v103, 0 :: v_dual_mov_b32 v94, 0            // 0000003F7F18: CA100080 675E0080
	v_dual_mov_b32 v107, 0 :: v_dual_mov_b32 v100, 0           // 0000003F7F20: CA100080 6B640080
	v_dual_mov_b32 v111, 0 :: v_dual_mov_b32 v102, 0           // 0000003F7F28: CA100080 6F660080
	v_dual_mov_b32 v104, 0 :: v_dual_mov_b32 v105, 0           // 0000003F7F30: CA100080 68680080
	v_dual_mov_b32 v97, 0 :: v_dual_mov_b32 v110, 0            // 0000003F7F38: CA100080 616E0080
	v_mov_b32_e32 v109, 0                                      // 0000003F7F40: 7EDA0280
	v_mov_b32_e32 v113, 0                                      // 0000003F7F44: 7EE20280
	s_ashr_i32 s27, s26, 31                                    // 0000003F7F48: 861B9F1A
	s_and_saveexec_b32 s3, s2                                  // 0000003F7F4C: BE832002
	s_cbranch_execz 1205                                       // 0000003F7F50: BFA504B5 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2228>
	v_lshrrev_b32_e32 v4, 5, v10                               // 0000003F7F54: 32081485
	v_or_b32_e32 v11, 4, v7                                    // 0000003F7F58: 38160E84
	v_mul_i32_i24_e32 v10, 0xffffffe8, v49                     // 0000003F7F5C: 121462FF FFFFFFE8
	.long 0xd4440002                                           // 0000003F7F64: D4440002
	v_cndmask_b32_e32 v1, 23, v3, vcc_lo                       // 0000003F7F68: 02020697
	v_mov_b32_e32 v17, 0                                       // 0000003F7F6C: 7E220280
	v_subrev_nc_u32_e32 v7, 24, v4                             // 0000003F7F70: 4E0E0898
	v_and_b32_e32 v9, 0x7e0, v9                                // 0000003F7F74: 361212FF 000007E0
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000003F7F7C: 3408069F
	v_cndmask_b32_e64 v12, 0xe9, 1, s2                         // 0000003F7F80: D501000C 000902FF 000000E9
	v_mov_b32_e32 v84, v17                                     // 0000003F7F8C: 7EA80311
	v_cndmask_b32_e64 v16, v7, 23, vcc_lo                      // 0000003F7F90: D5010010 01A92F07
	v_add3_u32 v116, v10, v9, 0xfffffd34                       // 0000003F7F98: D6550074 03FE130A FFFFFD34
	v_mad_u32_u24 v9, v11, 3, 0x2f0                            // 0000003F7FA4: D60B0009 03FD070B 000002F0
	v_mul_i32_i24_e32 v10, -3, v11                             // 0000003F7FB0: 121416C3
	.long 0xd73c0012                                           // 0000003F7FB4: D73C0012
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 0000003F7FB8: 02020682
	.long 0xd7030007                                           // 0000003F7FBC: D7030007
	v_cndmask_b32_e32 v0, v16, v129, vcc_lo                    // 0000003F7FC0: 02010310
	v_sub_nc_u32_e32 v114, 0, v50                              // 0000003F7FC4: 4CE46480
	v_and_b32_e32 v4, 0x7e0, v9                                // 0000003F7FC8: 360812FF 000007E0
	v_dual_mov_b32 v90, v17 :: v_dual_add_nc_u32 v11, v12, v3  // 0000003F7FD0: CA200111 5A0A070C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003F7FD8: BF870244
	.long 0xd7620003                                           // 0000003F7FDC: D7620003
	v_cndmask_b32_e32 v1, 0xff, v7, vcc_lo                     // 0000003F7FE0: 02020EFF 000000FF
	v_dual_mov_b32 v88, v17 :: v_dual_and_b32 v15, 16, v0      // 0000003F7FE8: CA240111 580E0090
	.long 0xd73c0014                                           // 0000003F7FF0: D73C0014
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 0000003F7FF4: 02022082
	v_dual_mov_b32 v86, v17 :: v_dual_add_nc_u32 v115, 2, v8   // 0000003F7FF8: CA200111 56721082
	v_cmp_ne_u16_e32 vcc_lo, 24, v3                            // 0000003F8000: 7C7A0698
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F8004: BF870004
	v_lshl_or_b32 v117, v8, 5, v15                             // 0000003F8008: D6560075 043D0B08
	v_mov_b32_e32 v85, v17                                     // 0000003F8010: 7EAA0311
	v_mov_b32_e32 v87, v17                                     // 0000003F8014: 7EAE0311
	v_mov_b32_e32 v89, v17                                     // 0000003F8018: 7EB20311
	v_cndmask_b16 v3, 0, v7, vcc_lo                            // 0000003F801C: D65D0003 01AA0E80
	v_dual_mov_b32 v92, v17 :: v_dual_and_b32 v7, 0xff, v11    // 0000003F8024: CA240111 5C0616FF 000000FF
	v_mov_b32_e32 v91, v17                                     // 0000003F8030: 7EB60311
	v_mov_b32_e32 v93, v17                                     // 0000003F8034: 7EBA0311
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003F8038: BF870244
	v_dual_mov_b32 v98, v17 :: v_dual_and_b32 v3, 0xff, v3     // 0000003F803C: CA240111 620206FF 000000FF
	v_mov_b32_e32 v83, v17                                     // 0000003F8048: 7EA60311
	v_add3_u32 v118, v10, v4, 0xfffffd34                       // 0000003F804C: D6550076 03FE090A FFFFFD34
	v_dual_mov_b32 v106, v17 :: v_dual_lshlrev_b32 v119, 2, v7 // 0000003F8058: CA220111 6A760E82
	v_dual_mov_b32 v95, v17 :: v_dual_lshlrev_b32 v120, 2, v3  // 0000003F8060: CA220111 5F780682
	v_mov_b32_e32 v99, v17                                     // 0000003F8068: 7EC60311
	v_mov_b32_e32 v101, v17                                    // 0000003F806C: 7ECA0311
	v_mov_b32_e32 v103, v17                                    // 0000003F8070: 7ECE0311
	v_mov_b32_e32 v107, v17                                    // 0000003F8074: 7ED60311
	v_mov_b32_e32 v108, v17                                    // 0000003F8078: 7ED80311
	v_mov_b32_e32 v111, v17                                    // 0000003F807C: 7EDE0311
	v_mov_b32_e32 v112, v17                                    // 0000003F8080: 7EE00311
	v_mov_b32_e32 v96, v17                                     // 0000003F8084: 7EC00311
	v_mov_b32_e32 v94, v17                                     // 0000003F8088: 7EBC0311
	v_mov_b32_e32 v100, v17                                    // 0000003F808C: 7EC80311
	v_mov_b32_e32 v102, v17                                    // 0000003F8090: 7ECC0311
	v_mov_b32_e32 v104, v17                                    // 0000003F8094: 7ED00311
	v_mov_b32_e32 v105, v17                                    // 0000003F8098: 7ED20311
	v_mov_b32_e32 v97, v17                                     // 0000003F809C: 7EC20311
	v_mov_b32_e32 v109, v17                                    // 0000003F80A0: 7EDA0311
	v_mov_b32_e32 v110, v17                                    // 0000003F80A4: 7EDC0311
	v_mov_b32_e32 v113, v17                                    // 0000003F80A8: 7EE20311
	s_mov_b32 s2, 0                                            // 0000003F80AC: BE820080
	s_movk_i32 s6, 0x1eee                                      // 0000003F80B0: B0061EEE
	s_branch 1001                                              // 0000003F80B4: BFA003E9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x205c>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000003F80B8: 8C7E077E
	.long 0xd73d000f                                           // 0000003F80BC: D73D000F
	v_cndmask_b32_e32 v1, v116, v1, vcc_lo                     // 0000003F80C0: 02020374
	.long 0xd73d0099                                           // 0000003F80C4: D73D0099
	v_cndmask_b32_e32 v1, v118, v5, vcc_lo                     // 0000003F80C8: 02020B76
	ds_load_b128 v[9:12], v117                                 // 0000003F80CC: DBFC0000 09000075
	ds_load_b128 v[1:4], v117 offset:5120                      // 0000003F80D4: DBFC1400 01000075
	.long 0xd73d002e                                           // 0000003F80DC: D73D002E
	v_cndmask_b32_e32 v1, v118, v46, vcc_lo                    // 0000003F80E0: 02025D76
	ds_load_b128 v[5:8], v117 offset:10240                     // 0000003F80E4: DBFC2800 05000075
	.long 0xd73d002a                                           // 0000003F80EC: D73D002A
	v_cndmask_b32_e32 v1, v116, v42, vcc_lo                    // 0000003F80F0: 02025574
	v_bfe_u32 v16, v15, 9, 16                                  // 0000003F80F4: D6100010 0241130F
	v_bfe_u32 v154, v15, 6, 16                                 // 0000003F80FC: D610009A 02410D0F
	v_bfe_u32 v155, v15, 3, 16                                 // 0000003F8104: D610009B 0241070F
	v_and_b32_e32 v15, 0xffff, v15                             // 0000003F810C: 361E1EFF 0000FFFF
	v_bfe_u32 v158, v153, 3, 16                                // 0000003F8114: D610009E 02410799
	.long 0xd72c0010                                           // 0000003F811C: D72C0010
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 0000003F8120: 020220FF 83DCD12D
	.long 0xd72c009a                                           // 0000003F8128: D72C009A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v154, vcc_lo             // 0000003F812C: 020334FF 83DCD12D
	.long 0xd72c009b                                           // 0000003F8134: D72C009B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v155, vcc_lo             // 0000003F8138: 020336FF 83DCD12D
	.long 0xd72c000f                                           // 0000003F8140: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 0000003F8144: 02021EFF 83DCD12D
	v_bfe_u32 v156, v153, 9, 16                                // 0000003F814C: D610009C 02411399
	.long 0xd72c009e                                           // 0000003F8154: D72C009E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v158, vcc_lo             // 0000003F8158: 02033CFF 83DCD12D
	v_bfe_u32 v157, v153, 6, 16                                // 0000003F8160: D610009D 02410D99
	v_bfe_u32 v160, v46, 9, 16                                 // 0000003F8168: D61000A0 0241132E
	v_sad_u8 v16, v16, 0, 0x6400                               // 0000003F8170: D6220010 03FD0110 00006400
	v_sad_u8 v154, v154, 0, 0x6400                             // 0000003F817C: D622009A 03FD019A 00006400
	v_sad_u8 v155, v155, 0, 0x6400                             // 0000003F8188: D622009B 03FD019B 00006400
	v_sad_u8 v15, v15, 0, 0x6400                               // 0000003F8194: D622000F 03FD010F 00006400
	.long 0xd72c009c                                           // 0000003F81A0: D72C009C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v156, vcc_lo             // 0000003F81A4: 020338FF 83DCD12D
	v_and_b32_e32 v16, 0xffff, v16                             // 0000003F81AC: 362020FF 0000FFFF
	.long 0xd72c009d                                           // 0000003F81B4: D72C009D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v157, vcc_lo             // 0000003F81B8: 02033AFF 83DCD12D
	v_bfe_u32 v161, v46, 6, 16                                 // 0000003F81C0: D61000A1 02410D2E
	v_lshlrev_b32_e32 v15, 16, v15                             // 0000003F81C8: 301E1E90
	v_bfe_u32 v162, v46, 3, 16                                 // 0000003F81CC: D61000A2 0241072E
	v_lshl_or_b32 v16, v154, 16, v16                           // 0000003F81D4: D6560010 0441219A
	.long 0xd72c00a0                                           // 0000003F81DC: D72C00A0
	v_cndmask_b32_e32 v1, 0x83dcd12d, v160, vcc_lo             // 0000003F81E0: 020340FF 83DCD12D
	v_sad_u8 v156, v156, 0, 0x6400                             // 0000003F81E8: D622009C 03FD019C 00006400
	v_and_or_b32 v15, 0xffff, v155, v15                        // 0000003F81F4: D657000F 043F36FF 0000FFFF
	v_sad_u8 v154, v157, 0, 0x6400                             // 0000003F8200: D622009A 03FD019D 00006400
	v_pk_fma_f16 v155, v16, s6, 0xc931 op_sel_hi:[1,0,0]       // 0000003F820C: CC0E009B 0BFC0D10 0000C931
	v_sad_u8 v16, v158, 0, 0x6400                              // 0000003F8218: D6220010 03FD019E 00006400
	.long 0xd72c00a1                                           // 0000003F8224: D72C00A1
	v_cndmask_b32_e32 v1, 0x83dcd12d, v161, vcc_lo             // 0000003F8228: 020342FF 83DCD12D
	v_pk_fma_f16 v158, v15, s6, 0xc931 op_sel_hi:[1,0,0]       // 0000003F8230: CC0E009E 0BFC0D0F 0000C931
	v_sad_u8 v160, v160, 0, 0x6400                             // 0000003F823C: D62200A0 03FD01A0 00006400
	s_waitcnt lgkmcnt(1)                                       // 0000003F8248: BF89FC17
	v_dot2acc_f32_f16 v110, v155, v1                           // 0000003F824C: 04DC039B
	v_and_b32_e32 v153, 0xffff, v153                           // 0000003F8250: 373332FF 0000FFFF
	v_dual_dot2acc_f32_f16 v113, v155, v9 :: v_dual_and_b32 v156, 0xffff, v156// 0000003F8258: CB24139B 719D38FF 0000FFFF
	.long 0xd73d002b                                           // 0000003F8264: D73D002B
	v_cndmask_b32_e32 v1, v118, v44, vcc_lo                    // 0000003F8268: 02025976
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F826C: BF870214
	v_dot2acc_f32_f16 v110, v158, v2                           // 0000003F8270: 04DC059E
	.long 0xd72c0099                                           // 0000003F8274: D72C0099
	v_cndmask_b32_e32 v1, 0x83dcd12d, v153, vcc_lo             // 0000003F8278: 020332FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F8280: BF870004
	v_dot2acc_f32_f16 v113, v158, v10                          // 0000003F8284: 04E2159E
	v_lshl_or_b32 v156, v154, 16, v156                         // 0000003F8288: D656009C 0671219A
	v_bfe_u32 v45, v42, 6, 16                                  // 0000003F8290: D610002D 02410D2A
	.long 0xd73d0026                                           // 0000003F8298: D73D0026
	v_cndmask_b32_e32 v1, v116, v38, vcc_lo                    // 0000003F829C: 02024D74
	.long 0xd73d0027                                           // 0000003F82A0: D73D0027
	v_cndmask_b32_e32 v1, v118, v40, vcc_lo                    // 0000003F82A4: 02025176
	.long 0xd73d0022                                           // 0000003F82A8: D73D0022
	v_cndmask_b32_e32 v1, v116, v34, vcc_lo                    // 0000003F82AC: 02024574
	v_pk_fma_f16 v156, v156, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000003F82B0: CC0E009C 0BFC0D9C 0000C931
	v_sad_u8 v153, v153, 0, 0x6400                             // 0000003F82BC: D6220099 03FD0199 00006400
	.long 0xd72c002d                                           // 0000003F82C8: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000003F82CC: 02025AFF 83DCD12D
	.long 0xd73d0023                                           // 0000003F82D4: D73D0023
	v_cndmask_b32_e32 v1, v118, v36, vcc_lo                    // 0000003F82D8: 02024976
	.long 0xd73d001e                                           // 0000003F82DC: D73D001E
	v_cndmask_b32_e32 v1, v116, v30, vcc_lo                    // 0000003F82E0: 02023D74
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F82E4: BF870004
	v_dual_dot2acc_f32_f16 v110, v156, v3 :: v_dual_lshlrev_b32 v157, 16, v153// 0000003F82E8: CB22079C 6E9D3290
	.long 0xd73d0099                                           // 0000003F82F0: D73D0099
	v_cndmask_b32_e32 v1, v116, v13, vcc_lo                    // 0000003F82F4: 02021B74
	v_bfe_u32 v37, v34, 6, 16                                  // 0000003F82F8: D6100025 02410D22
	.long 0xd73d001f                                           // 0000003F8300: D73D001F
	v_cndmask_b32_e32 v1, v118, v32, vcc_lo                    // 0000003F8304: 02024176
	v_and_b32_e32 v46, 0xffff, v46                             // 0000003F8308: 365C5CFF 0000FFFF
	v_and_or_b32 v154, 0xffff, v16, v157                       // 0000003F8310: D657009A 067620FF 0000FFFF
	ds_load_b128 v[13:16], v117 offset:15360                   // 0000003F831C: DBFC3C00 0D000075
	v_bfe_u32 v157, v153, 9, 16                                // 0000003F8324: D610009D 02411399
	s_waitcnt lgkmcnt(1)                                       // 0000003F832C: BF89FC17
	v_dot2acc_f32_f16 v109, v155, v5                           // 0000003F8330: 04DA0B9B
	.long 0xd72c002e                                           // 0000003F8334: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000003F8338: 02025CFF 83DCD12D
	v_pk_fma_f16 v154, v154, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000003F8340: CC0E009A 0BFC0D9A 0000C931
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000003F834C: D622002D 03FD012D 00006400
	.long 0xd72c002f                                           // 0000003F8358: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v157, vcc_lo             // 0000003F835C: 02033AFF 83DCD12D
	v_bfe_u32 v157, v153, 6, 16                                // 0000003F8364: D610009D 02410D99
	.long 0xd72c0025                                           // 0000003F836C: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 0000003F8370: 02024AFF 83DCD12D
	v_dot2acc_f32_f16 v110, v154, v4                           // 0000003F8378: 04DC099A
	v_bfe_u32 v33, v30, 6, 16                                  // 0000003F837C: D6100021 02410D1E
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000003F8384: D622002E 03FD012E 00006400
	.long 0xd72c009d                                           // 0000003F8390: D72C009D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v157, vcc_lo             // 0000003F8394: 02033AFF 83DCD12D
	v_dot2acc_f32_f16 v113, v156, v11                          // 0000003F839C: 04E2179C
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000003F83A0: D622002F 03FD012F 00006400
	.long 0xd72c0021                                           // 0000003F83AC: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 0000003F83B0: 020242FF 83DCD12D
	v_lshlrev_b32_e32 v46, 16, v46                             // 0000003F83B8: 305C5C90
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000003F83BC: D6220025 03FD0125 00006400
	.long 0xd73d001a                                           // 0000003F83C8: D73D001A
	v_cndmask_b32_e32 v1, v116, v26, vcc_lo                    // 0000003F83CC: 02023574
	v_and_b32_e32 v47, 0xffff, v47                             // 0000003F83D0: 365E5EFF 0000FFFF
	v_sad_u8 v157, v157, 0, 0x6400                             // 0000003F83D8: D622009D 03FD019D 00006400
	s_waitcnt lgkmcnt(0)                                       // 0000003F83E4: BF89FC07
	v_dot2acc_f32_f16 v97, v155, v13                           // 0000003F83E8: 04C21B9B
	.long 0xd73d001b                                           // 0000003F83EC: D73D001B
	v_cndmask_b32_e32 v1, v118, v28, vcc_lo                    // 0000003F83F0: 02023976
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000003F83F4: D6220021 03FD0121 00006400
	v_bfe_u32 v29, v26, 6, 16                                  // 0000003F8400: D610001D 02410D1A
	v_lshl_or_b32 v47, v157, 16, v47                           // 0000003F8408: D656002F 04BD219D
	v_dot2acc_f32_f16 v97, v158, v14                           // 0000003F8410: 04C21D9E
	.long 0xd72c009d                                           // 0000003F8414: D72C009D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v162, vcc_lo             // 0000003F8418: 020344FF 83DCD12D
	.long 0xd73d0016                                           // 0000003F8420: D73D0016
	v_cndmask_b32_e32 v1, v116, v22, vcc_lo                    // 0000003F8424: 02022D74
	.long 0xd72c001d                                           // 0000003F8428: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 0000003F842C: 02023AFF 83DCD12D
	v_pk_fma_f16 v47, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8434: CC0E002F 0BFC0D2F 0000C931
	v_dot2acc_f32_f16 v109, v158, v6                           // 0000003F8440: 04DA0D9E
	v_bfe_u32 v158, v43, 3, 16                                 // 0000003F8444: D610009E 0241072B
	.long 0xd73d0017                                           // 0000003F844C: D73D0017
	v_cndmask_b32_e32 v1, v118, v24, vcc_lo                    // 0000003F8450: 02023176
	v_bfe_u32 v25, v22, 6, 16                                  // 0000003F8454: D6100019 02410D16
	v_dot2acc_f32_f16 v104, v47, v1                            // 0000003F845C: 04D0032F
	v_and_b32_e32 v159, 0xffff, v153                           // 0000003F8460: 373F32FF 0000FFFF
	v_bfe_u32 v153, v153, 3, 16                                // 0000003F8468: D6100099 02410799
	v_dual_dot2acc_f32_f16 v109, v156, v7 :: v_dual_dot2acc_f32_f16 v102, v47, v5// 0000003F8470: CB180F9C 6D660B2F
	v_sad_u8 v157, v157, 0, 0x6400                             // 0000003F8478: D622009D 03FD019D 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F8484: BF870214
	.long 0xd72c009f                                           // 0000003F8488: D72C009F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v159, vcc_lo             // 0000003F848C: 02033EFF 83DCD12D
	.long 0xd72c0099                                           // 0000003F8494: D72C0099
	v_cndmask_b32_e32 v1, 0x83dcd12d, v153, vcc_lo             // 0000003F8498: 020332FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F84A0: BF870004
	v_dot2acc_f32_f16 v109, v154, v8                           // 0000003F84A4: 04DA119A
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000003F84A8: D622001D 03FD011D 00006400
	v_and_or_b32 v46, 0xffff, v157, v46                        // 0000003F84B4: D657002E 04BB3AFF 0000FFFF
	v_bfe_u32 v157, v43, 6, 16                                 // 0000003F84C0: D610009D 02410D2B
	.long 0xd72c0019                                           // 0000003F84C8: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 0000003F84CC: 020232FF 83DCD12D
	v_add_nc_u32_e32 v115, 1, v115                             // 0000003F84D4: 4AE6E681
	v_sad_u8 v159, v159, 0, 0x6400                             // 0000003F84D8: D622009F 03FD019F 00006400
	v_sad_u8 v153, v153, 0, 0x6400                             // 0000003F84E4: D6220099 03FD0199 00006400
	v_pk_fma_f16 v46, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F84F0: CC0E002E 0BFC0D2E 0000C931
	.long 0xd72c009d                                           // 0000003F84FC: D72C009D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v157, vcc_lo             // 0000003F8500: 02033AFF 83DCD12D
	v_add_nc_u32_e32 v117, 32, v117                            // 0000003F8508: 4AEAEAA0
	v_dual_dot2acc_f32_f16 v100, v47, v13 :: v_dual_lshlrev_b32 v159, 16, v159// 0000003F850C: CB221B2F 649F3E90
	v_sad_u8 v25, v25, 0, 0x6400                               // 0000003F8514: D6220019 03FD0119 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003F8520: BF870242
	v_and_or_b32 v153, 0xffff, v153, v159                      // 0000003F8524: D6570099 067F32FF 0000FFFF
	v_and_b32_e32 v159, 0xffff, v160                           // 0000003F8530: 373F40FF 0000FFFF
	v_sad_u8 v160, v161, 0, 0x6400                             // 0000003F8538: D62200A0 03FD01A1 00006400
	v_sad_u8 v157, v157, 0, 0x6400                             // 0000003F8544: D622009D 03FD019D 00006400
	v_pk_fma_f16 v153, v153, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000003F8550: CC0E0099 0BFC0D99 0000C931
	v_dot2acc_f32_f16 v97, v156, v15                           // 0000003F855C: 04C21F9C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F8560: BF870224
	v_lshl_or_b32 v155, v160, 16, v159                         // 0000003F8564: D656009B 067D21A0
	v_bfe_u32 v156, v43, 9, 16                                 // 0000003F856C: D610009C 0241132B
	v_dot2acc_f32_f16 v104, v153, v2                           // 0000003F8574: 04D00599
	v_dot2acc_f32_f16 v102, v153, v6                           // 0000003F8578: 04CC0D99
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F857C: BF870004
	v_pk_fma_f16 v155, v155, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000003F8580: CC0E009B 0BFC0D9B 0000C931
	v_dual_dot2acc_f32_f16 v113, v154, v12 :: v_dual_dot2acc_f32_f16 v100, v153, v14// 0000003F858C: CB18199A 71641D99
	v_dot2acc_f32_f16 v97, v154, v16                           // 0000003F8594: 04C2219A
	v_bfe_u32 v154, v42, 9, 16                                 // 0000003F8598: D610009A 0241132A
	.long 0xd72c009c                                           // 0000003F85A0: D72C009C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v156, vcc_lo             // 0000003F85A4: 020338FF 83DCD12D
	v_dot2acc_f32_f16 v104, v155, v3                           // 0000003F85AC: 04D0079B
	v_dot2acc_f32_f16 v102, v155, v7                           // 0000003F85B0: 04CC0F9B
	v_dot2acc_f32_f16 v100, v155, v15                          // 0000003F85B4: 04C81F9B
	.long 0xd72c002c                                           // 0000003F85B8: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v154, vcc_lo             // 0000003F85BC: 020334FF 83DCD12D
	v_and_b32_e32 v154, 0xffff, v42                            // 0000003F85C4: 373454FF 0000FFFF
	v_bfe_u32 v42, v42, 3, 16                                  // 0000003F85CC: D610002A 0241072A
	v_dot2acc_f32_f16 v104, v46, v4                            // 0000003F85D4: 04D0092E
	v_sad_u8 v156, v156, 0, 0x6400                             // 0000003F85D8: D622009C 03FD019C 00006400
	v_dot2acc_f32_f16 v105, v47, v9                            // 0000003F85E4: 04D2132F
	.long 0xd72c009a                                           // 0000003F85E8: D72C009A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v154, vcc_lo             // 0000003F85EC: 020334FF 83DCD12D
	.long 0xd72c002a                                           // 0000003F85F4: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 0000003F85F8: 020254FF 83DCD12D
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000003F8600: D622002C 03FD012C 00006400
	v_and_b32_e32 v156, 0xffff, v156                           // 0000003F860C: 373938FF 0000FFFF
	v_dot2acc_f32_f16 v100, v46, v16                           // 0000003F8614: 04C8212E
	v_dot2acc_f32_f16 v102, v46, v8                            // 0000003F8618: 04CC112E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003F861C: BF8701B4
	v_and_b32_e32 v44, 0xffff, v44                             // 0000003F8620: 365858FF 0000FFFF
	v_sad_u8 v154, v154, 0, 0x6400                             // 0000003F8628: D622009A 03FD019A 00006400
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000003F8634: D622002A 03FD012A 00006400
	v_lshl_or_b32 v44, v45, 16, v44                            // 0000003F8640: D656002C 04B1212D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F8648: BF870211
	v_pk_fma_f16 v44, v44, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F864C: CC0E002C 0BFC0D2C 0000C931
	v_lshlrev_b32_e32 v45, 16, v154                            // 0000003F8658: 305B3490
	v_dot2acc_f32_f16 v105, v153, v10                          // 0000003F865C: 04D21599
	.long 0xd72c009a                                           // 0000003F8660: D72C009A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v158, vcc_lo             // 0000003F8664: 02033CFF 83DCD12D
	v_bfe_u32 v153, v39, 6, 16                                 // 0000003F866C: D6100099 02410D27
	v_dot2acc_f32_f16 v112, v44, v5                            // 0000003F8674: 04E00B2C
	v_and_or_b32 v42, 0xffff, v42, v45                         // 0000003F8678: D657002A 04B654FF 0000FFFF
	v_dot2acc_f32_f16 v96, v44, v1                             // 0000003F8684: 04C0032C
	v_dot2acc_f32_f16 v94, v44, v9                             // 0000003F8688: 04BC132C
	v_lshl_or_b32 v45, v157, 16, v156                          // 0000003F868C: D656002D 0671219D
	v_dot2acc_f32_f16 v111, v44, v13                           // 0000003F8694: 04DE1B2C
	v_pk_fma_f16 v42, v42, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8698: CC0E002A 0BFC0D2A 0000C931
	v_and_b32_e32 v43, 0xffff, v43                             // 0000003F86A4: 365656FF 0000FFFF
	v_dot2acc_f32_f16 v105, v155, v11                          // 0000003F86AC: 04D2179B
	v_sad_u8 v47, v154, 0, 0x6400                              // 0000003F86B0: D622002F 03FD019A 00006400
	v_pk_fma_f16 v45, v45, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F86BC: CC0E002D 0BFC0D2D 0000C931
	v_dot2acc_f32_f16 v96, v42, v2                             // 0000003F86C8: 04C0052A
	.long 0xd72c002b                                           // 0000003F86CC: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 0000003F86D0: 020256FF 83DCD12D
	v_dot2acc_f32_f16 v94, v42, v10                            // 0000003F86D8: 04BC152A
	v_dot2acc_f32_f16 v105, v46, v12                           // 0000003F86DC: 04D2192E
	v_bfe_u32 v46, v38, 9, 16                                  // 0000003F86E0: D610002E 02411326
	v_dot2acc_f32_f16 v96, v45, v3                             // 0000003F86E8: 04C0072D
	v_bfe_u32 v154, v39, 3, 16                                 // 0000003F86EC: D610009A 02410727
	.long 0xd72c0099                                           // 0000003F86F4: D72C0099
	v_cndmask_b32_e32 v1, 0x83dcd12d, v153, vcc_lo             // 0000003F86F8: 020332FF 83DCD12D
	v_dot2acc_f32_f16 v111, v42, v14                           // 0000003F8700: 04DE1D2A
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000003F8704: D622002B 03FD012B 00006400
	.long 0xd72c0029                                           // 0000003F8710: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000003F8714: 02025CFF 83DCD12D
	v_bfe_u32 v46, v38, 6, 16                                  // 0000003F871C: D610002E 02410D26
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F8724: BF870214
	v_dual_dot2acc_f32_f16 v111, v45, v15 :: v_dual_and_b32 v40, 0xffff, v38// 0000003F8728: CB241F2D 6F284CFF 0000FFFF
	v_lshlrev_b32_e32 v43, 16, v43                             // 0000003F8734: 30565690
	v_bfe_u32 v38, v38, 3, 16                                  // 0000003F8738: D6100026 02410726
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F8740: BF870214
	.long 0xd72c002e                                           // 0000003F8744: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000003F8748: 02025CFF 83DCD12D
	.long 0xd72c0028                                           // 0000003F8750: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 0000003F8754: 020250FF 83DCD12D
	v_sad_u8 v41, v41, 0, 0x6400                               // 0000003F875C: D6220029 03FD0129 00006400
	v_and_or_b32 v43, 0xffff, v47, v43                         // 0000003F8768: D657002B 04AE5EFF 0000FFFF
	v_dot2acc_f32_f16 v94, v45, v11                            // 0000003F8774: 04BC172D
	v_bfe_u32 v47, v39, 9, 16                                  // 0000003F8778: D610002F 02411327
	.long 0xd72c0026                                           // 0000003F8780: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 0000003F8784: 02024CFF 83DCD12D
	v_and_b32_e32 v41, 0xffff, v41                             // 0000003F878C: 365252FF 0000FFFF
	v_pk_fma_f16 v43, v43, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8794: CC0E002B 0BFC0D2B 0000C931
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000003F87A0: D622002E 03FD012E 00006400
	.long 0xd72c002f                                           // 0000003F87AC: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000003F87B0: 02025EFF 83DCD12D
	v_and_b32_e32 v39, 0xffff, v39                             // 0000003F87B8: 364E4EFF 0000FFFF
	v_sad_u8 v44, v153, 0, 0x6400                              // 0000003F87C0: D622002C 03FD0199 00006400
	v_dot2acc_f32_f16 v94, v43, v12                            // 0000003F87CC: 04BC192B
	v_lshl_or_b32 v41, v46, 16, v41                            // 0000003F87D0: D6560029 04A5212E
	.long 0xd72c009a                                           // 0000003F87D8: D72C009A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v154, vcc_lo             // 0000003F87DC: 020334FF 83DCD12D
	.long 0xd72c0027                                           // 0000003F87E4: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000003F87E8: 02024EFF 83DCD12D
	v_sad_u8 v40, v40, 0, 0x6400                               // 0000003F87F0: D6220028 03FD0128 00006400
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000003F87FC: D6220026 03FD0126 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000003F8808: D622002F 03FD012F 00006400
	v_pk_fma_f16 v41, v41, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8814: CC0E0029 0BFC0D29 0000C931
	v_dot2acc_f32_f16 v96, v43, v4                             // 0000003F8820: 04C0092B
	v_lshlrev_b32_e32 v40, 16, v40                             // 0000003F8824: 30505090
	v_sad_u8 v46, v154, 0, 0x6400                              // 0000003F8828: D622002E 03FD019A 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000003F8834: D6220027 03FD0127 00006400
	v_dual_dot2acc_f32_f16 v103, v41, v13 :: v_dual_dot2acc_f32_f16 v112, v42, v6// 0000003F8840: CB181B29 67700D2A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003F8848: BF870244
	v_and_or_b32 v38, 0xffff, v38, v40                         // 0000003F884C: D6570026 04A24CFF 0000FFFF
	v_dual_dot2acc_f32_f16 v111, v43, v16 :: v_dual_and_b32 v40, 0xffff, v47// 0000003F8858: CB24212B 6F285EFF 0000FFFF
	v_dot2acc_f32_f16 v107, v41, v1                            // 0000003F8864: 04D60329
	v_bfe_u32 v42, v34, 9, 16                                  // 0000003F8868: D610002A 02411322
	v_pk_fma_f16 v38, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8870: CC0E0026 0BFC0D26 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003F887C: BF870234
	v_lshl_or_b32 v40, v44, 16, v40                            // 0000003F8880: D6560028 04A1212C
	v_lshlrev_b32_e32 v39, 16, v39                             // 0000003F8888: 304E4E90
	v_dot2acc_f32_f16 v112, v45, v7                            // 0000003F888C: 04E00F2D
	v_dual_dot2acc_f32_f16 v106, v41, v5 :: v_dual_dot2acc_f32_f16 v107, v38, v2// 0000003F8890: CB180B29 6A6A0526
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F8898: BF870004
	v_pk_fma_f16 v40, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F889C: CC0E0028 0BFC0D28 0000C931
	v_dot2acc_f32_f16 v108, v41, v9                            // 0000003F88A8: 04D81329
	.long 0xd72c0024                                           // 0000003F88AC: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 0000003F88B0: 020254FF 83DCD12D
	v_and_b32_e32 v41, 0xffff, v34                             // 0000003F88B8: 365244FF 0000FFFF
	v_bfe_u32 v34, v34, 3, 16                                  // 0000003F88C0: D6100022 02410722
	v_bfe_u32 v42, v35, 9, 16                                  // 0000003F88C8: D610002A 02411323
	v_and_or_b32 v39, 0xffff, v46, v39                         // 0000003F88D0: D6570027 049E5CFF 0000FFFF
	v_dot2acc_f32_f16 v112, v43, v8                            // 0000003F88DC: 04E0112B
	.long 0xd72c0029                                           // 0000003F88E0: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 0000003F88E4: 020252FF 83DCD12D
	v_bfe_u32 v43, v35, 6, 16                                  // 0000003F88EC: D610002B 02410D23
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000003F88F4: D6220024 03FD0124 00006400
	.long 0xd72c002a                                           // 0000003F8900: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 0000003F8904: 020254FF 83DCD12D
	.long 0xd72c0022                                           // 0000003F890C: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 0000003F8910: 020244FF 83DCD12D
	v_bfe_u32 v44, v35, 3, 16                                  // 0000003F8918: D610002C 02410723
	v_and_b32_e32 v35, 0xffff, v35                             // 0000003F8920: 364646FF 0000FFFF
	v_pk_fma_f16 v39, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8928: CC0E0027 0BFC0D27 0000C931
	v_dual_dot2acc_f32_f16 v107, v40, v3 :: v_dual_dot2acc_f32_f16 v108, v38, v10// 0000003F8934: CB180728 6B6C1526
	v_and_b32_e32 v36, 0xffff, v36                             // 0000003F893C: 364848FF 0000FFFF
	v_sad_u8 v41, v41, 0, 0x6400                               // 0000003F8944: D6220029 03FD0129 00006400
	.long 0xd72c002b                                           // 0000003F8950: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 0000003F8954: 020256FF 83DCD12D
	.long 0xd72c0023                                           // 0000003F895C: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 0000003F8960: 020246FF 83DCD12D
	v_dual_dot2acc_f32_f16 v107, v39, v4 :: v_dual_dot2acc_f32_f16 v108, v40, v11// 0000003F8968: CB180927 6B6C1728
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000003F8970: D622002A 03FD012A 00006400
	v_lshl_or_b32 v36, v37, 16, v36                            // 0000003F897C: D6560024 04912125
	v_sad_u8 v34, v34, 0, 0x6400                               // 0000003F8984: D6220022 03FD0122 00006400
	v_lshlrev_b32_e32 v37, 16, v41                             // 0000003F8990: 304A5290
	.long 0xd72c0029                                           // 0000003F8994: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000003F8998: 020258FF 83DCD12D
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000003F89A0: D622002B 03FD012B 00006400
	v_pk_fma_f16 v36, v36, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F89AC: CC0E0024 0BFC0D24 0000C931
	v_and_b32_e32 v42, 0xffff, v42                             // 0000003F89B8: 365454FF 0000FFFF
	v_and_or_b32 v34, 0xffff, v34, v37                         // 0000003F89C0: D6570022 049644FF 0000FFFF
	v_sad_u8 v35, v35, 0, 0x6400                               // 0000003F89CC: D6220023 03FD0123 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F89D8: BF870214
	v_dual_dot2acc_f32_f16 v106, v38, v6 :: v_dual_dot2acc_f32_f16 v101, v36, v9// 0000003F89DC: CB180D26 6A641324
	v_lshl_or_b32 v37, v43, 16, v42                            // 0000003F89E4: D6560025 04A9212B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003F89EC: BF870244
	v_pk_fma_f16 v34, v34, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F89F0: CC0E0022 0BFC0D22 0000C931
	v_dual_dot2acc_f32_f16 v108, v39, v12 :: v_dual_dot2acc_f32_f16 v103, v38, v14// 0000003F89FC: CB181927 6C661D26
	v_sad_u8 v38, v41, 0, 0x6400                               // 0000003F8A04: D6220026 03FD0129 00006400
	v_lshlrev_b32_e32 v35, 16, v35                             // 0000003F8A10: 30464690
	v_dual_dot2acc_f32_f16 v106, v40, v7 :: v_dual_dot2acc_f32_f16 v101, v34, v10// 0000003F8A14: CB180F28 6A641522
	v_pk_fma_f16 v37, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8A1C: CC0E0025 0BFC0D25 0000C931
	v_dot2acc_f32_f16 v98, v36, v5                             // 0000003F8A28: 04C40B24
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000003F8A2C: BF870254
	v_and_or_b32 v35, 0xffff, v38, v35                         // 0000003F8A30: D6570023 048E4CFF 0000FFFF
	v_bfe_u32 v38, v30, 9, 16                                  // 0000003F8A3C: D6100026 0241131E
	v_dual_dot2acc_f32_f16 v103, v40, v15 :: v_dual_dot2acc_f32_f16 v106, v39, v8// 0000003F8A44: CB181F28 676A1127
	v_dot2acc_f32_f16 v101, v37, v11                           // 0000003F8A4C: 04CA1725
	v_dual_dot2acc_f32_f16 v99, v36, v1 :: v_dual_dot2acc_f32_f16 v98, v34, v6// 0000003F8A50: CB180324 63620D22
	.long 0xd72c0020                                           // 0000003F8A58: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 0000003F8A5C: 02024CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F8A64: BF870004
	v_dot2acc_f32_f16 v103, v39, v16                           // 0000003F8A68: 04CE2127
	v_and_b32_e32 v39, 0xffff, v30                             // 0000003F8A6C: 364E3CFF 0000FFFF
	v_bfe_u32 v30, v30, 3, 16                                  // 0000003F8A74: D610001E 0241071E
	v_dual_dot2acc_f32_f16 v98, v37, v7 :: v_dual_dot2acc_f32_f16 v99, v34, v2// 0000003F8A7C: CB180F25 62620522
	v_pk_fma_f16 v35, v35, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8A84: CC0E0023 0BFC0D23 0000C931
	v_bfe_u32 v38, v31, 9, 16                                  // 0000003F8A90: D6100026 0241131F
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000003F8A98: D6220020 03FD0120 00006400
	v_dot2acc_f32_f16 v95, v36, v13                            // 0000003F8AA4: 04BE1B24
	.long 0xd72c0024                                           // 0000003F8AA8: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000003F8AAC: 02024EFF 83DCD12D
	.long 0xd72c001e                                           // 0000003F8AB4: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 0000003F8AB8: 02023CFF 83DCD12D
	v_dual_dot2acc_f32_f16 v99, v37, v3 :: v_dual_dot2acc_f32_f16 v98, v35, v8// 0000003F8AC0: CB180725 63621123
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F8AC8: BF870004
	v_dual_dot2acc_f32_f16 v95, v34, v14 :: v_dual_and_b32 v32, 0xffff, v32// 0000003F8ACC: CB241D22 5F2040FF 0000FFFF
	v_bfe_u32 v39, v31, 6, 16                                  // 0000003F8AD8: D6100027 02410D1F
	v_bfe_u32 v40, v31, 3, 16                                  // 0000003F8AE0: D6100028 0241071F
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000003F8AE8: D6220024 03FD0124 00006400
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000003F8AF4: D622001E 03FD011E 00006400
	v_lshl_or_b32 v32, v33, 16, v32                            // 0000003F8B00: D6560020 04812121
	.long 0xd72c0026                                           // 0000003F8B08: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 0000003F8B0C: 02024CFF 83DCD12D
	.long 0xd72c0021                                           // 0000003F8B14: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 0000003F8B18: 020250FF 83DCD12D
	v_lshlrev_b32_e32 v36, 16, v36                             // 0000003F8B20: 30484890
	.long 0xd72c0027                                           // 0000003F8B24: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000003F8B28: 02024EFF 83DCD12D
	v_pk_fma_f16 v32, v32, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8B30: CC0E0020 0BFC0D20 0000C931
	v_dot2acc_f32_f16 v99, v35, v4                             // 0000003F8B3C: 04C60923
	v_mov_b32_e32 v41, v62                                     // 0000003F8B40: 7E52033E
	v_and_or_b32 v30, 0xffff, v30, v36                         // 0000003F8B44: D657001E 04923CFF 0000FFFF
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000003F8B50: D6220026 03FD0126 00006400
	v_dot2acc_f32_f16 v92, v32, v1                             // 0000003F8B5C: 04B80320
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000003F8B60: D6220021 03FD0121 00006400
	v_dot2acc_f32_f16 v101, v35, v12                           // 0000003F8B6C: 04CA1923
	v_pk_fma_f16 v30, v30, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8B70: CC0E001E 0BFC0D1E 0000C931
	v_dual_dot2acc_f32_f16 v90, v32, v13 :: v_dual_and_b32 v31, 0xffff, v31// 0000003F8B7C: CB241B20 5A1E3EFF 0000FFFF
	v_and_b32_e32 v34, 0xffff, v38                             // 0000003F8B88: 36444CFF 0000FFFF
	v_sad_u8 v36, v39, 0, 0x6400                               // 0000003F8B90: D6220024 03FD0127 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F8B9C: BF870214
	v_dot2acc_f32_f16 v92, v30, v2                             // 0000003F8BA0: 04B8051E
	.long 0xd72c001f                                           // 0000003F8BA4: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 0000003F8BA8: 02023EFF 83DCD12D
	v_dual_dot2acc_f32_f16 v91, v32, v5 :: v_dual_dot2acc_f32_f16 v90, v30, v14// 0000003F8BB0: CB180B20 5B5A1D1E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F8BB8: BF870004
	v_lshl_or_b32 v34, v36, 16, v34                            // 0000003F8BBC: D6560022 04892124
	v_bfe_u32 v36, v27, 6, 16                                  // 0000003F8BC4: D6100024 02410D1B
	v_mov_b32_e32 v47, v66                                     // 0000003F8BCC: 7E5E0342
	v_mov_b32_e32 v39, v51                                     // 0000003F8BD0: 7E4E0333
	v_mov_b32_e32 v45, v64                                     // 0000003F8BD4: 7E5A0340
	v_sad_u8 v31, v31, 0, 0x6400                               // 0000003F8BD8: D622001F 03FD011F 00006400
	v_pk_fma_f16 v34, v34, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8BE4: CC0E0022 0BFC0D22 0000C931
	.long 0xd72c0024                                           // 0000003F8BF0: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 0000003F8BF4: 020248FF 83DCD12D
	v_mov_b32_e32 v43, v52                                     // 0000003F8BFC: 7E560334
	s_waitcnt vmcnt(28)                                        // 0000003F8C00: BF8973F7
	v_mov_b32_e32 v51, v121                                    // 0000003F8C04: 7E660379
	v_lshlrev_b32_e32 v31, 16, v31                             // 0000003F8C08: 303E3E90
	v_dot2acc_f32_f16 v92, v34, v3                             // 0000003F8C0C: 04B80722
	v_dot2acc_f32_f16 v90, v34, v15                            // 0000003F8C10: 04B41F22
	v_mov_b32_e32 v40, v68                                     // 0000003F8C14: 7E500344
	v_mov_b32_e32 v44, v71                                     // 0000003F8C18: 7E580347
	v_and_or_b32 v31, 0xffff, v33, v31                         // 0000003F8C1C: D657001F 047E42FF 0000FFFF
	v_bfe_u32 v33, v26, 9, 16                                  // 0000003F8C28: D6100021 0241131A
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000003F8C30: D6220024 03FD0124 00006400
	s_waitcnt vmcnt(5)                                         // 0000003F8C3C: BF8917F7
	v_dual_mov_b32 v71, v134 :: v_dual_mov_b32 v38, v59        // 0000003F8C40: CA100186 4726013B
	v_pk_fma_f16 v31, v31, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8C48: CC0E001F 0BFC0D1F 0000C931
	.long 0xd72c001c                                           // 0000003F8C54: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 0000003F8C58: 020242FF 83DCD12D
	v_dot2acc_f32_f16 v95, v37, v15                            // 0000003F8C60: 04BE1F25
	v_and_b32_e32 v33, 0xffff, v26                             // 0000003F8C64: 364234FF 0000FFFF
	v_bfe_u32 v26, v26, 3, 16                                  // 0000003F8C6C: D610001A 0241071A
	v_dot2acc_f32_f16 v92, v31, v4                             // 0000003F8C74: 04B8091F
	v_bfe_u32 v37, v27, 3, 16                                  // 0000003F8C78: D6100025 0241071B
	v_dot2acc_f32_f16 v95, v35, v16                            // 0000003F8C80: 04BE2123
	v_bfe_u32 v35, v27, 9, 16                                  // 0000003F8C84: D6100023 0241131B
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000003F8C8C: D622001C 03FD011C 00006400
	v_dot2acc_f32_f16 v93, v32, v9                             // 0000003F8C98: 04BA1320
	.long 0xd72c0021                                           // 0000003F8C9C: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 0000003F8CA0: 020242FF 83DCD12D
	.long 0xd72c001a                                           // 0000003F8CA8: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 0000003F8CAC: 020234FF 83DCD12D
	.long 0xd72c0023                                           // 0000003F8CB4: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 0000003F8CB8: 020246FF 83DCD12D
	v_dual_dot2acc_f32_f16 v91, v30, v6 :: v_dual_and_b32 v28, 0xffff, v28// 0000003F8CC0: CB240D1E 5B1C38FF 0000FFFF
	v_dual_dot2acc_f32_f16 v90, v31, v16 :: v_dual_mov_b32 v59, v125// 0000003F8CCC: CB10211F 5A3A017D
	v_mov_b32_e32 v42, v60                                     // 0000003F8CD4: 7E54033C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003F8CD8: BF870003
	v_lshl_or_b32 v28, v29, 16, v28                            // 0000003F8CDC: D656001C 0471211D
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000003F8CE4: D6220021 03FD0121 00006400
	v_sad_u8 v35, v35, 0, 0x6400                               // 0000003F8CF0: D6220023 03FD0123 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000003F8CFC: D622001A 03FD011A 00006400
	v_mov_b32_e32 v60, v126                                    // 0000003F8D08: 7E78037E
	v_pk_fma_f16 v28, v28, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8D0C: CC0E001C 0BFC0D1C 0000C931
	v_dot2acc_f32_f16 v93, v30, v10                            // 0000003F8D18: 04BA151E
	v_lshlrev_b32_e32 v29, 16, v33                             // 0000003F8D1C: 303A4290
	.long 0xd72c0021                                           // 0000003F8D20: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 0000003F8D24: 02024AFF 83DCD12D
	v_bfe_u32 v30, v23, 6, 16                                  // 0000003F8D2C: D610001E 02410D17
	v_dot2acc_f32_f16 v89, v28, v9                             // 0000003F8D34: 04B2131C
	v_dual_dot2acc_f32_f16 v88, v28, v1 :: v_dual_dot2acc_f32_f16 v93, v34, v11// 0000003F8D38: CB18031C 585C1722
	v_dot2acc_f32_f16 v86, v28, v13                            // 0000003F8D40: 04AC1B1C
	v_dot2acc_f32_f16 v87, v28, v5                             // 0000003F8D44: 04AE0B1C
	v_bfe_u32 v28, v22, 9, 16                                  // 0000003F8D48: D610001C 02411316
	v_and_or_b32 v26, 0xffff, v26, v29                         // 0000003F8D50: D657001A 047634FF 0000FFFF
	v_sad_u8 v32, v33, 0, 0x6400                               // 0000003F8D5C: D6220020 03FD0121 00006400
	.long 0xd72c001e                                           // 0000003F8D68: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 0000003F8D6C: 02023CFF 83DCD12D
	v_mov_b32_e32 v46, v73                                     // 0000003F8D74: 7E5C0349
	.long 0xd72c0018                                           // 0000003F8D78: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 0000003F8D7C: 020238FF 83DCD12D
	v_pk_fma_f16 v26, v26, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8D84: CC0E001A 0BFC0D1A 0000C931
	v_bfe_u32 v28, v23, 9, 16                                  // 0000003F8D90: D610001C 02411317
	v_dot2acc_f32_f16 v93, v31, v12                            // 0000003F8D98: 04BA191F
	v_mov_b32_e32 v73, v135                                    // 0000003F8D9C: 7E920387
	v_mov_b32_e32 v37, v150                                    // 0000003F8DA0: 7E4A0396
	v_dot2acc_f32_f16 v88, v26, v2                             // 0000003F8DA4: 04B0051A
	.long 0xd72c001c                                           // 0000003F8DA8: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 0000003F8DAC: 020238FF 83DCD12D
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000003F8DB4: D6220018 03FD0118 00006400
	v_dot2acc_f32_f16 v86, v26, v14                            // 0000003F8DC0: 04AC1D1A
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000003F8DC4: D622001E 03FD011E 00006400
	v_dual_mov_b32 v33, v146 :: v_dual_mov_b32 v62, v128       // 0000003F8DD0: CA100192 213E0180
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F8DD8: BF870004
	v_and_b32_e32 v24, 0xffff, v24                             // 0000003F8DDC: 363030FF 0000FFFF
	s_waitcnt vmcnt(4)                                         // 0000003F8DE4: BF8913F7
	v_mov_b32_e32 v68, v132                                    // 0000003F8DE8: 7E880384
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000003F8DEC: D622001C 03FD011C 00006400
	v_dual_dot2acc_f32_f16 v89, v26, v10 :: v_dual_mov_b32 v66, v131// 0000003F8DF8: CB10151A 59420183
	v_lshl_or_b32 v24, v25, 16, v24                            // 0000003F8E00: D6560018 04612119
	v_mov_b32_e32 v52, v122                                    // 0000003F8E08: 7E68037A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F8E0C: BF870224
	v_and_b32_e32 v28, 0xffff, v28                             // 0000003F8E10: 363838FF 0000FFFF
	v_mov_b32_e32 v64, v130                                    // 0000003F8E18: 7E800382
	v_pk_fma_f16 v24, v24, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8E1C: CC0E0018 0BFC0D18 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F8E28: BF870091
	v_dual_dot2acc_f32_f16 v84, v24, v1 :: v_dual_and_b32 v27, 0xffff, v27// 0000003F8E2C: CB240318 541A36FF 0000FFFF
	.long 0xd72c001b                                           // 0000003F8E38: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 0000003F8E3C: 020236FF 83DCD12D
	v_and_b32_e32 v35, 0xffff, v35                             // 0000003F8E44: 364646FF 0000FFFF
	v_dot2acc_f32_f16 v85, v24, v9                             // 0000003F8E4C: 04AA1318
	v_dot2acc_f32_f16 v83, v24, v5                             // 0000003F8E50: 04A60B18
	v_dot2acc_f32_f16 v17, v24, v13                            // 0000003F8E54: 04221B18
	v_mov_b32_e32 v13, v61                                     // 0000003F8E58: 7E1A033D
	v_lshl_or_b32 v29, v36, 16, v35                            // 0000003F8E5C: D656001D 048D2124
	v_dual_mov_b32 v5, v74 :: v_dual_mov_b32 v24, v137         // 0000003F8E64: CA10014A 05180189
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000003F8E6C: D622001B 03FD011B 00006400
	v_mov_b32_e32 v61, v127                                    // 0000003F8E78: 7E7A037F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F8E7C: BF870004
	v_pk_fma_f16 v29, v29, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8E80: CC0E001D 0BFC0D1D 0000C931
	v_dot2acc_f32_f16 v87, v26, v6                             // 0000003F8E8C: 04AE0D1A
	v_and_b32_e32 v26, 0xffff, v22                             // 0000003F8E90: 36342CFF 0000FFFF
	v_lshlrev_b32_e32 v27, 16, v27                             // 0000003F8E98: 30363690
	v_bfe_u32 v22, v22, 3, 16                                  // 0000003F8E9C: D6100016 02410716
	v_dot2acc_f32_f16 v88, v29, v3                             // 0000003F8EA4: 04B0071D
	v_dot2acc_f32_f16 v86, v29, v15                            // 0000003F8EA8: 04AC1F1D
	.long 0xd72c001a                                           // 0000003F8EAC: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 0000003F8EB0: 020234FF 83DCD12D
	v_and_or_b32 v27, 0xffff, v32, v27                         // 0000003F8EB8: D657001B 046E40FF 0000FFFF
	.long 0xd72c0016                                           // 0000003F8EC4: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 0000003F8EC8: 02022CFF 83DCD12D
	v_dot2acc_f32_f16 v87, v29, v7                             // 0000003F8ED0: 04AE0F1D
	v_dual_dot2acc_f32_f16 v89, v29, v11 :: v_dual_mov_b32 v74, v136// 0000003F8ED4: CB10171D 594A0188
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F8EDC: BF870004
	v_pk_fma_f16 v27, v27, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8EE0: CC0E001B 0BFC0D1B 0000C931
	v_dot2acc_f32_f16 v91, v34, v7                             // 0000003F8EEC: 04B60F22
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000003F8EF0: D622001A 03FD011A 00006400
	v_mov_b32_e32 v35, v152                                    // 0000003F8EFC: 7E460398
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000003F8F00: D6220016 03FD0116 00006400
	v_dot2acc_f32_f16 v88, v27, v4                             // 0000003F8F0C: 04B0091B
	v_dot2acc_f32_f16 v91, v31, v8                             // 0000003F8F10: 04B6111F
	v_bfe_u32 v31, v23, 3, 16                                  // 0000003F8F14: D610001F 02410717
	v_and_b32_e32 v23, 0xffff, v23                             // 0000003F8F1C: 362E2EFF 0000FFFF
	v_lshlrev_b32_e32 v25, 16, v26                             // 0000003F8F24: 30323490
	v_dot2acc_f32_f16 v87, v27, v8                             // 0000003F8F28: 04AE111B
	v_dot2acc_f32_f16 v86, v27, v16                            // 0000003F8F2C: 04AC211B
	.long 0xd72c001a                                           // 0000003F8F30: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 0000003F8F34: 02023EFF 83DCD12D
	.long 0xd72c0017                                           // 0000003F8F3C: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 0000003F8F40: 02022EFF 83DCD12D
	v_and_or_b32 v22, 0xffff, v22, v25                         // 0000003F8F48: D6570016 04662CFF 0000FFFF
	v_lshl_or_b32 v25, v30, 16, v28                            // 0000003F8F54: D6560019 0471211E
	v_mov_b32_e32 v34, v151                                    // 0000003F8F5C: 7E440397
	v_dual_mov_b32 v36, v149 :: v_dual_mov_b32 v31, v148       // 0000003F8F60: CA100195 241E0194
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F8F68: BF870004
	v_pk_fma_f16 v22, v22, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8F6C: CC0E0016 0BFC0D16 0000C931
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000003F8F78: D622001A 03FD011A 00006400
	v_sad_u8 v23, v23, 0, 0x6400                               // 0000003F8F84: D6220017 03FD0117 00006400
	v_pk_fma_f16 v25, v25, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003F8F90: CC0E0019 0BFC0D19 0000C931
	v_mov_b32_e32 v32, v145                                    // 0000003F8F9C: 7E400391
	v_dot2acc_f32_f16 v84, v22, v2                             // 0000003F8FA0: 04A80516
	v_add_nc_u32_e32 v2, v114, v115                            // 0000003F8FA4: 4A04E772
	v_lshlrev_b32_e32 v23, 16, v23                             // 0000003F8FA8: 302E2E90
	v_dot2acc_f32_f16 v83, v22, v6                             // 0000003F8FAC: 04A60D16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F8FB0: BF870214
	v_dual_dot2acc_f32_f16 v89, v27, v12 :: v_dual_dot2acc_f32_f16 v84, v25, v3// 0000003F8FB4: CB18191B 59540719
	v_cmp_eq_u32_e32 vcc_lo, 2, v2                             // 0000003F8FBC: 7C940482
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003F8FC0: BF870244
	v_and_or_b32 v9, 0xffff, v26, v23                          // 0000003F8FC4: D6570009 045E34FF 0000FFFF
	v_mov_b32_e32 v2, v54                                      // 0000003F8FD0: 7E040336
	v_dual_dot2acc_f32_f16 v17, v22, v14 :: v_dual_mov_b32 v14, v53// 0000003F8FD4: CB101D16 110E0135
	v_dot2acc_f32_f16 v85, v22, v10                            // 0000003F8FDC: 04AA1516
	v_pk_fma_f16 v1, v9, s6, 0xc931 op_sel_hi:[1,0,0]          // 0000003F8FE0: CC0E0001 0BFC0D09 0000C931
	v_dot2acc_f32_f16 v83, v25, v7                             // 0000003F8FEC: 04A60F19
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F8FF0: BF870214
	v_dual_dot2acc_f32_f16 v17, v25, v15 :: v_dual_mov_b32 v6, v70// 0000003F8FF4: CB101F19 11060146
	v_dot2acc_f32_f16 v85, v25, v11                            // 0000003F8FFC: 04AA1719
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F9000: BF870214
	v_dot2acc_f32_f16 v84, v1, v4                              // 0000003F9004: 04A80901
	v_dot2acc_f32_f16 v83, v1, v8                              // 0000003F9008: 04A61101
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F900C: BF870214
	v_dual_dot2acc_f32_f16 v17, v1, v16 :: v_dual_mov_b32 v30, v147// 0000003F9010: CB102101 111E0193
	v_dual_dot2acc_f32_f16 v85, v1, v12 :: v_dual_mov_b32 v54, v124// 0000003F9018: CB101901 5536017C
	v_mov_b32_e32 v1, v63                                      // 0000003F9020: 7E02033F
	v_dual_mov_b32 v53, v123 :: v_dual_mov_b32 v70, v133       // 0000003F9024: CA10017B 35460185
	v_mov_b32_e32 v63, v129                                    // 0000003F902C: 7E7E0381
	v_dual_mov_b32 v27, v144 :: v_dual_mov_b32 v26, v143       // 0000003F9030: CA100190 1B1A018F
	v_dual_mov_b32 v29, v142 :: v_dual_mov_b32 v28, v141       // 0000003F9038: CA10018E 1D1C018D
	v_dual_mov_b32 v23, v140 :: v_dual_mov_b32 v22, v139       // 0000003F9040: CA10018C 1716018B
	v_mov_b32_e32 v25, v138                                    // 0000003F9048: 7E32038A
	s_or_b32 s2, vcc_lo, s2                                    // 0000003F904C: 8C02026A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F9050: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 0000003F9054: 917E027E
	s_cbranch_execz 114                                        // 0000003F9058: BFA50072 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2224>
	s_waitcnt vmcnt(19)                                        // 0000003F905C: BF894FF7
	v_dual_mov_b32 v152, v55 :: v_dual_mov_b32 v151, v72       // 0000003F9060: CA100137 98960148
	s_waitcnt vmcnt(11)                                        // 0000003F9068: BF892FF7
	v_dual_mov_b32 v150, v78 :: v_dual_mov_b32 v147, v69       // 0000003F906C: CA10014E 96920145
	s_waitcnt vmcnt(3)                                         // 0000003F9074: BF890FF7
	v_dual_mov_b32 v149, v82 :: v_dual_mov_b32 v148, v56       // 0000003F9078: CA100152 95940138
	v_dual_mov_b32 v146, v77 :: v_dual_mov_b32 v143, v67       // 0000003F9080: CA10014D 928E0143
	s_waitcnt vmcnt(2)                                         // 0000003F9088: BF890BF7
	v_dual_mov_b32 v145, v81 :: v_dual_mov_b32 v142, v76       // 0000003F908C: CA100151 918E014C
	s_waitcnt vmcnt(1)                                         // 0000003F9094: BF8907F7
	v_dual_mov_b32 v144, v57 :: v_dual_mov_b32 v141, v80       // 0000003F9098: CA100139 908C0150
	v_dual_mov_b32 v140, v58 :: v_dual_mov_b32 v139, v65       // 0000003F90A0: CA10013A 8C8A0141
	v_mov_b32_e32 v138, v75                                    // 0000003F90A8: 7F14034B
	s_waitcnt vmcnt(0)                                         // 0000003F90AC: BF8903F7
	v_mov_b32_e32 v137, v79                                    // 0000003F90B0: 7F12034F
	s_mov_b32 s7, exec_lo                                      // 0000003F90B4: BE87007E
	.long 0xd4c1007e                                           // 0000003F90B8: D4C1007E
	v_cndmask_b32_e32 v1, v115, v50, vcc_lo                    // 0000003F90BC: 02026573
	s_cbranch_execz 64509                                      // 0000003F90C0: BFA5FBFD <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x10b8>
	v_mad_i64_i32 v[3:4], null, 0x300, v115, s[4:5]            // 0000003F90C4: D6FF7C03 0012E6FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F90D0: BF870091
	.long 0xd7006a07                                           // 0000003F90D4: D7006A07
	v_cndmask_b32_e32 v1, v3, v18, vcc_lo                      // 0000003F90D8: 02022503
	v_add_co_ci_u32_e64 v8, null, v4, v19, vcc_lo              // 0000003F90DC: D5207C08 01AA2704
	.long 0xd7006a09                                           // 0000003F90E4: D7006A09
	v_cndmask_b32_e32 v1, v3, v119, vcc_lo                     // 0000003F90E8: 0202EF03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F90EC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v4, vcc_lo               // 0000003F90F0: D5207C0A 01AA0880
	.long 0xd7006a0b                                           // 0000003F90F8: D7006A0B
	v_cndmask_b32_e32 v1, v3, v20, vcc_lo                      // 0000003F90FC: 02022903
	v_add_co_ci_u32_e64 v12, null, v4, v21, vcc_lo             // 0000003F9100: D5207C0C 01AA2B04
	.long 0xd7006a03                                           // 0000003F9108: D7006A03
	v_cndmask_b32_e32 v1, v3, v120, vcc_lo                     // 0000003F910C: 0202F103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F9110: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 0000003F9114: D5207C04 01AA0880
	s_clause 0x1f                                              // 0000003F911C: BF85001F
	global_load_b32 v124, v[7:8], off                          // 0000003F9120: DC520000 7C7C0007
	global_load_b32 v123, v[7:8], off offset:96                // 0000003F9128: DC520060 7B7C0007
	global_load_b32 v122, v[7:8], off offset:192               // 0000003F9130: DC5200C0 7A7C0007
	global_load_b32 v121, v[7:8], off offset:288               // 0000003F9138: DC520120 797C0007
	global_load_b32 v55, v[7:8], off offset:384                // 0000003F9140: DC520180 377C0007
	global_load_b32 v56, v[7:8], off offset:480                // 0000003F9148: DC5201E0 387C0007
	global_load_b32 v57, v[7:8], off offset:576                // 0000003F9150: DC520240 397C0007
	global_load_b32 v58, v[7:8], off offset:672                // 0000003F9158: DC5202A0 3A7C0007
	global_load_b32 v129, v[9:10], off                         // 0000003F9160: DC520000 817C0009
	global_load_b32 v127, v[9:10], off offset:96               // 0000003F9168: DC520060 7F7C0009
	global_load_b32 v126, v[9:10], off offset:192              // 0000003F9170: DC5200C0 7E7C0009
	global_load_b32 v125, v[9:10], off offset:288              // 0000003F9178: DC520120 7D7C0009
	global_load_b32 v72, v[9:10], off offset:384               // 0000003F9180: DC520180 487C0009
	global_load_b32 v69, v[9:10], off offset:480               // 0000003F9188: DC5201E0 457C0009
	global_load_b32 v67, v[9:10], off offset:576               // 0000003F9190: DC520240 437C0009
	global_load_b32 v65, v[9:10], off offset:672               // 0000003F9198: DC5202A0 417C0009
	global_load_b32 v133, v[11:12], off                        // 0000003F91A0: DC520000 857C000B
	global_load_b32 v131, v[11:12], off offset:96              // 0000003F91A8: DC520060 837C000B
	global_load_b32 v130, v[11:12], off offset:192             // 0000003F91B0: DC5200C0 827C000B
	global_load_b32 v128, v[11:12], off offset:288             // 0000003F91B8: DC520120 807C000B
	global_load_b32 v78, v[11:12], off offset:384              // 0000003F91C0: DC520180 4E7C000B
	global_load_b32 v77, v[11:12], off offset:480              // 0000003F91C8: DC5201E0 4D7C000B
	global_load_b32 v76, v[11:12], off offset:576              // 0000003F91D0: DC520240 4C7C000B
	global_load_b32 v75, v[11:12], off offset:672              // 0000003F91D8: DC5202A0 4B7C000B
	global_load_b32 v136, v[3:4], off                          // 0000003F91E0: DC520000 887C0003
	global_load_b32 v135, v[3:4], off offset:96                // 0000003F91E8: DC520060 877C0003
	global_load_b32 v134, v[3:4], off offset:192               // 0000003F91F0: DC5200C0 867C0003
	global_load_b32 v132, v[3:4], off offset:288               // 0000003F91F8: DC520120 847C0003
	global_load_b32 v82, v[3:4], off offset:384                // 0000003F9200: DC520180 527C0003
	global_load_b32 v81, v[3:4], off offset:480                // 0000003F9208: DC5201E0 517C0003
	global_load_b32 v80, v[3:4], off offset:576                // 0000003F9210: DC520240 507C0003
	global_load_b32 v79, v[3:4], off offset:672                // 0000003F9218: DC5202A0 4F7C0003
	s_branch 64421                                             // 0000003F9220: BFA0FBA5 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x10b8>
	s_or_b32 exec_lo, exec_lo, s2                              // 0000003F9224: 8C7E027E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F9228: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003F922C: 8C7E037E
	s_waitcnt vmcnt(23)                                        // 0000003F9230: BF895FF7
	v_dual_mov_b32 v1, v113 :: v_dual_mov_b32 v2, v110         // 0000003F9234: CA100171 0102016E
	v_dual_mov_b32 v4, v109 :: v_dual_mov_b32 v9, v100         // 0000003F923C: CA10016D 04080164
	s_waitcnt vmcnt(15)                                        // 0000003F9244: BF893FF7
	v_dual_mov_b32 v3, v97 :: v_dual_mov_b32 v6, v104          // 0000003F9248: CA100161 03060168
	s_waitcnt vmcnt(7)                                         // 0000003F9250: BF891FF7
	v_dual_mov_b32 v5, v105 :: v_dual_mov_b32 v8, v102         // 0000003F9254: CA100169 05080166
	v_dual_mov_b32 v7, v94 :: v_dual_mov_b32 v10, v96          // 0000003F925C: CA10015E 070A0160
	v_dual_mov_b32 v11, v112 :: v_dual_mov_b32 v12, v111       // 0000003F9264: CA100170 0B0C016F
	v_dual_mov_b32 v13, v108 :: v_dual_mov_b32 v14, v107       // 0000003F926C: CA10016C 0D0E016B
	v_dual_mov_b32 v15, v106 :: v_dual_mov_b32 v16, v103       // 0000003F9274: CA10016A 0F100167
	v_dual_mov_b32 v18, v101 :: v_dual_mov_b32 v19, v99        // 0000003F927C: CA100165 12120163
	v_dual_mov_b32 v20, v98 :: v_dual_mov_b32 v21, v95         // 0000003F9284: CA100162 1414015F
	v_dual_mov_b32 v22, v93 :: v_dual_mov_b32 v23, v92         // 0000003F928C: CA10015D 1616015C
	s_waitcnt vmcnt(0)                                         // 0000003F9294: BF8903F7
	v_dual_mov_b32 v24, v91 :: v_dual_mov_b32 v25, v90         // 0000003F9298: CA10015B 1818015A
	v_dual_mov_b32 v26, v89 :: v_dual_mov_b32 v27, v88         // 0000003F92A0: CA100159 1A1A0158
	v_dual_mov_b32 v28, v87 :: v_dual_mov_b32 v29, v86         // 0000003F92A8: CA100157 1C1C0156
	v_dual_mov_b32 v30, v85 :: v_dual_mov_b32 v31, v84         // 0000003F92B0: CA100155 1E1E0154
	v_dual_mov_b32 v32, v83 :: v_dual_mov_b32 v33, v17         // 0000003F92B8: CA100153 20200111
	s_mov_b32 s2, 0x76543210                                   // 0000003F92C0: BE8200FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F92C8: BF870009
	v_permlanex16_b32 v1, v1, s2, 0xfedcba98                   // 0000003F92CC: D65C0001 03FC0501 FEDCBA98
	v_permlanex16_b32 v2, v2, s2, 0xfedcba98                   // 0000003F92D8: D65C0002 03FC0502 FEDCBA98
	v_permlanex16_b32 v4, v4, s2, 0xfedcba98                   // 0000003F92E4: D65C0004 03FC0504 FEDCBA98
	v_permlanex16_b32 v3, v3, s2, 0xfedcba98                   // 0000003F92F0: D65C0003 03FC0503 FEDCBA98
	v_permlanex16_b32 v5, v5, s2, 0xfedcba98                   // 0000003F92FC: D65C0005 03FC0505 FEDCBA98
	v_permlanex16_b32 v6, v6, s2, 0xfedcba98                   // 0000003F9308: D65C0006 03FC0506 FEDCBA98
	v_permlanex16_b32 v8, v8, s2, 0xfedcba98                   // 0000003F9314: D65C0008 03FC0508 FEDCBA98
	v_permlanex16_b32 v9, v9, s2, 0xfedcba98                   // 0000003F9320: D65C0009 03FC0509 FEDCBA98
	v_permlanex16_b32 v7, v7, s2, 0xfedcba98                   // 0000003F932C: D65C0007 03FC0507 FEDCBA98
	v_permlanex16_b32 v10, v10, s2, 0xfedcba98                 // 0000003F9338: D65C000A 03FC050A FEDCBA98
	v_permlanex16_b32 v11, v11, s2, 0xfedcba98                 // 0000003F9344: D65C000B 03FC050B FEDCBA98
	v_permlanex16_b32 v12, v12, s2, 0xfedcba98                 // 0000003F9350: D65C000C 03FC050C FEDCBA98
	v_permlanex16_b32 v13, v13, s2, 0xfedcba98                 // 0000003F935C: D65C000D 03FC050D FEDCBA98
	v_permlanex16_b32 v14, v14, s2, 0xfedcba98                 // 0000003F9368: D65C000E 03FC050E FEDCBA98
	v_permlanex16_b32 v15, v15, s2, 0xfedcba98                 // 0000003F9374: D65C000F 03FC050F FEDCBA98
	v_permlanex16_b32 v16, v16, s2, 0xfedcba98                 // 0000003F9380: D65C0010 03FC0510 FEDCBA98
	v_permlanex16_b32 v18, v18, s2, 0xfedcba98                 // 0000003F938C: D65C0012 03FC0512 FEDCBA98
	v_permlanex16_b32 v19, v19, s2, 0xfedcba98                 // 0000003F9398: D65C0013 03FC0513 FEDCBA98
	v_permlanex16_b32 v20, v20, s2, 0xfedcba98                 // 0000003F93A4: D65C0014 03FC0514 FEDCBA98
	v_permlanex16_b32 v21, v21, s2, 0xfedcba98                 // 0000003F93B0: D65C0015 03FC0515 FEDCBA98
	v_permlanex16_b32 v22, v22, s2, 0xfedcba98                 // 0000003F93BC: D65C0016 03FC0516 FEDCBA98
	v_permlanex16_b32 v23, v23, s2, 0xfedcba98                 // 0000003F93C8: D65C0017 03FC0517 FEDCBA98
	v_permlanex16_b32 v24, v24, s2, 0xfedcba98                 // 0000003F93D4: D65C0018 03FC0518 FEDCBA98
	v_permlanex16_b32 v25, v25, s2, 0xfedcba98                 // 0000003F93E0: D65C0019 03FC0519 FEDCBA98
	v_permlanex16_b32 v26, v26, s2, 0xfedcba98                 // 0000003F93EC: D65C001A 03FC051A FEDCBA98
	v_permlanex16_b32 v27, v27, s2, 0xfedcba98                 // 0000003F93F8: D65C001B 03FC051B FEDCBA98
	v_permlanex16_b32 v28, v28, s2, 0xfedcba98                 // 0000003F9404: D65C001C 03FC051C FEDCBA98
	v_permlanex16_b32 v29, v29, s2, 0xfedcba98                 // 0000003F9410: D65C001D 03FC051D FEDCBA98
	v_permlanex16_b32 v30, v30, s2, 0xfedcba98                 // 0000003F941C: D65C001E 03FC051E FEDCBA98
	v_permlanex16_b32 v31, v31, s2, 0xfedcba98                 // 0000003F9428: D65C001F 03FC051F FEDCBA98
	v_permlanex16_b32 v32, v32, s2, 0xfedcba98                 // 0000003F9434: D65C0020 03FC0520 FEDCBA98
	v_permlanex16_b32 v33, v33, s2, 0xfedcba98                 // 0000003F9440: D65C0021 03FC0521 FEDCBA98
	.long 0xd44c0002                                           // 0000003F944C: D44C0002
	v_cndmask_b32_e32 v1, 16, v49, vcc_lo                      // 0000003F9450: 02026290
	s_barrier                                                  // 0000003F9454: BFBD0000
	buffer_gl0_inv                                             // 0000003F9458: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 0000003F9460: BE832002
	s_cbranch_execz 70                                         // 0000003F9464: BFA50046 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2580>
	v_dual_add_f32 v17, v17, v33 :: v_dual_add_f32 v32, v83, v32// 0000003F9468: C9084311 11204153
	v_dual_add_f32 v10, v96, v10 :: v_dual_lshlrev_b32 v33, 2, v49// 0000003F9470: C9221560 0A206282
	v_dual_add_f32 v6, v104, v6 :: v_dual_add_f32 v5, v105, v5 // 0000003F9478: C9080D68 06040B69
	v_dual_add_f32 v1, v113, v1 :: v_dual_add_f32 v2, v110, v2 // 0000003F9480: C9080371 0102056E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003F9488: BF8701B3
	v_lshl_or_b32 v33, v48, 11, v33                            // 0000003F948C: D6560021 04851730
	v_dual_add_f32 v9, v100, v9 :: v_dual_add_f32 v8, v102, v8 // 0000003F9494: C9081364 09081166
	v_dual_add_f32 v4, v109, v4 :: v_dual_add_f32 v7, v94, v7  // 0000003F949C: C908096D 04060F5E
	v_dual_add_f32 v3, v97, v3 :: v_dual_add_nc_u32 v34, 0x400, v33// 0000003F94A4: C9200761 032242FF 00000400
	v_dual_add_f32 v14, v107, v14 :: v_dual_add_f32 v13, v108, v13// 0000003F94B0: C9081D6B 0E0C1B6C
	v_dual_add_f32 v31, v84, v31 :: v_dual_add_f32 v30, v85, v30// 0000003F94B8: C9083F54 1F1E3D55
	v_dual_add_f32 v29, v86, v29 :: v_dual_add_f32 v28, v87, v28// 0000003F94C0: C9083B56 1D1C3957
	v_dual_add_f32 v27, v88, v27 :: v_dual_add_f32 v26, v89, v26// 0000003F94C8: C9083758 1B1A3559
	v_dual_add_f32 v25, v90, v25 :: v_dual_add_f32 v24, v91, v24// 0000003F94D0: C908335A 1918315B
	v_dual_add_f32 v23, v92, v23 :: v_dual_add_f32 v22, v93, v22// 0000003F94D8: C9082F5C 17162D5D
	v_dual_add_f32 v21, v95, v21 :: v_dual_add_f32 v20, v98, v20// 0000003F94E0: C9082B5F 15142962
	v_dual_add_f32 v19, v99, v19 :: v_dual_add_f32 v18, v101, v18// 0000003F94E8: C9082763 13122565
	v_dual_add_f32 v16, v103, v16 :: v_dual_add_f32 v15, v106, v15// 0000003F94F0: C9082167 100E1F6A
	v_dual_add_f32 v12, v111, v12 :: v_dual_add_f32 v11, v112, v11// 0000003F94F8: C908196F 0C0A1770
	ds_store_2addr_b32 v33, v1, v5 offset1:16                  // 0000003F9500: D8381000 00050121
	ds_store_2addr_b32 v33, v2, v6 offset0:128 offset1:144     // 0000003F9508: D8389080 00060221
	ds_store_2addr_b32 v34, v4, v8 offset1:16                  // 0000003F9510: D8381000 00080422
	ds_store_2addr_b32 v34, v3, v9 offset0:128 offset1:144     // 0000003F9518: D8389080 00090322
	ds_store_2addr_b32 v33, v7, v13 offset0:32 offset1:48      // 0000003F9520: D8383020 000D0721
	ds_store_2addr_b32 v33, v10, v14 offset0:160 offset1:176   // 0000003F9528: D838B0A0 000E0A21
	ds_store_2addr_b32 v34, v11, v15 offset0:32 offset1:48     // 0000003F9530: D8383020 000F0B22
	ds_store_2addr_b32 v34, v12, v16 offset0:160 offset1:176   // 0000003F9538: D838B0A0 00100C22
	ds_store_2addr_b32 v33, v18, v22 offset0:64 offset1:80     // 0000003F9540: D8385040 00161221
	ds_store_2addr_b32 v33, v19, v23 offset0:192 offset1:208   // 0000003F9548: D838D0C0 00171321
	ds_store_2addr_b32 v34, v20, v24 offset0:64 offset1:80     // 0000003F9550: D8385040 00181422
	ds_store_2addr_b32 v34, v21, v25 offset0:192 offset1:208   // 0000003F9558: D838D0C0 00191522
	ds_store_2addr_b32 v33, v26, v30 offset0:96 offset1:112    // 0000003F9560: D8387060 001E1A21
	ds_store_2addr_b32 v33, v27, v31 offset0:224 offset1:240   // 0000003F9568: D838F0E0 001F1B21
	ds_store_2addr_b32 v34, v28, v32 offset0:96 offset1:112    // 0000003F9570: D8387060 00201C22
	ds_store_2addr_b32 v34, v29, v17 offset0:224 offset1:240   // 0000003F9578: D838F0E0 00111D22
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003F9580: 8C7E037E
	.long 0xd44c0003                                           // 0000003F9584: D44C0003
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000003F9588: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 0000003F9590: BF89FC07
	s_barrier                                                  // 0000003F9594: BFBD0000
	buffer_gl0_inv                                             // 0000003F9598: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000003F95A0: BE842003
	s_cbranch_execz 41                                         // 0000003F95A4: BFA50029 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x264c>
	v_mov_b32_e32 v1, v0                                       // 0000003F95A8: 7E020300
	s_mov_b32 s5, 0                                            // 0000003F95AC: BE850080
	s_nop 0                                                    // 0000003F95B0: BF800000
	s_nop 0                                                    // 0000003F95B4: BF800000
	s_nop 0                                                    // 0000003F95B8: BF800000
	s_nop 0                                                    // 0000003F95BC: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F95C0: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 0000003F95C4: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 0000003F95C8: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:8            // 0000003F95D0: D8E00800 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:16 offset1:24// 0000003F95D8: D8E01810 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:32 offset1:40// 0000003F95E0: D8E02820 06000008
	s_or_b32 s5, vcc_lo, s5                                    // 0000003F95E8: 8C05056A
	s_waitcnt lgkmcnt(2)                                       // 0000003F95EC: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 0000003F95F0: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000003F95F4: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 0000003F95F8: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:48 offset1:56// 0000003F95FC: D8E03830 02000008
	s_waitcnt lgkmcnt(2)                                       // 0000003F9604: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 0000003F9608: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 0000003F960C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 0000003F9610: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F9614: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 0000003F9618: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 0000003F961C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 0000003F9620: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F9624: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 0000003F9628: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 0000003F962C: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 0000003F9634: C9100702 02000104
	ds_store_b32 v8, v2 offset:16384                           // 0000003F963C: D8344000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000003F9644: 917E057E
	s_cbranch_execnz 65501                                     // 0000003F9648: BFA6FFDD <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x25c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003F964C: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 0000003F9650: BF048215
	s_mov_b32 s4, -1                                           // 0000003F9654: BE8400C1
	s_cbranch_scc1 243                                         // 0000003F9658: BFA200F3 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a28>
	s_load_b128 s[4:7], s[0:1], 0x1a8                          // 0000003F965C: F4080100 F80001A8
	s_waitcnt lgkmcnt(0)                                       // 0000003F9664: BF89FC07
	s_barrier                                                  // 0000003F9668: BFBD0000
	buffer_gl0_inv                                             // 0000003F966C: E0AC0000 00000000
	s_and_saveexec_b32 s8, s3                                  // 0000003F9674: BE882003
	s_cbranch_execz 85                                         // 0000003F9678: BFA50055 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x27d0>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000003F967C: 32020087
	s_ashr_i32 s35, s34, 31                                    // 0000003F9680: 86239F22
	s_ashr_i32 s37, s36, 31                                    // 0000003F9684: 86259F24
	s_lshl_b64 s[0:1], s[34:35], 2                             // 0000003F9688: 84808222
	s_lshl_b32 s10, s26, 7                                     // 0000003F968C: 840A871A
	v_or_b32_e32 v1, s0, v1                                    // 0000003F9690: 38020200
	v_mov_b32_e32 v2, s1                                       // 0000003F9694: 7E040201
	s_lshl_b64 s[0:1], s[36:37], 2                             // 0000003F9698: 84808224
	s_ashr_i32 s11, s10, 31                                    // 0000003F969C: 860B9F0A
	s_lshl_b64 s[16:17], s[28:29], 2                           // 0000003F96A0: 8490821C
	.long 0xd7016a01                                           // 0000003F96A4: D7016A01
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 0000003F96A8: 02000101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F96AC: BF870001
	v_subrev_co_ci_u32_e64 v2, null, s1, v2, vcc_lo            // 0000003F96B0: D5227C02 01AA0401
	s_ashr_i32 s1, s20, 31                                     // 0000003F96B8: 86019F14
	s_lshl_b64 s[10:11], s[10:11], 2                           // 0000003F96BC: 848A820A
	.long 0xd72c0004                                           // 0000003F96C0: D72C0004
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 0000003F96C4: 02000301
	.long 0xd72c0003                                           // 0000003F96C8: D72C0003
	v_cndmask_b32_e32 v0, v2, v20, vcc_lo                      // 0000003F96CC: 02002902
	v_mad_u64_u32 v[1:2], null, v1, s20, 0                     // 0000003F96D0: D6FE7C01 02002901
	s_add_u32 s9, s10, s16                                     // 0000003F96D8: 8009100A
	s_addc_u32 s10, s11, s17                                   // 0000003F96DC: 820A110B
	s_mov_b32 s0, s20                                          // 0000003F96E0: BE800014
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003F96E4: BF870139
	s_lshl_b64 s[0:1], s[0:1], 3                               // 0000003F96E8: 84808300
	v_add3_u32 v2, v2, v4, v3                                  // 0000003F96EC: D6550002 040E0902
	v_and_b32_e32 v3, 0x7f, v0                                 // 0000003F96F4: 360600FF 0000007F
	.long 0xd73c0001                                           // 0000003F96FC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000003F9700: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F9704: BF8701A2
	v_lshlrev_b32_e32 v4, 2, v3                                // 0000003F9708: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 0000003F970C: 30060082
	.long 0xd7006a01                                           // 0000003F9710: D7006A01
	v_cndmask_b32_e32 v1, s9, v1, vcc_lo                       // 0000003F9714: 02020209
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003F9718: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s10, v2, vcc_lo              // 0000003F971C: D5207C02 01AA040A
	s_mov_b32 s9, 0                                            // 0000003F9724: BE890080
	.long 0xd7006a01                                           // 0000003F9728: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 0000003F972C: 02020901
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000003F9730: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 0000003F9738: 380800FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F9740: BF870093
	.long 0xd7006a01                                           // 0000003F9744: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000003F9748: 02020204
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000003F974C: D5207C02 01AA0405
	s_nop 0                                                    // 0000003F9754: BF800000
	s_nop 0                                                    // 0000003F9758: BF800000
	s_nop 0                                                    // 0000003F975C: BF800000
	s_nop 0                                                    // 0000003F9760: BF800000
	s_nop 0                                                    // 0000003F9764: BF800000
	s_nop 0                                                    // 0000003F9768: BF800000
	s_nop 0                                                    // 0000003F976C: BF800000
	s_nop 0                                                    // 0000003F9770: BF800000
	s_nop 0                                                    // 0000003F9774: BF800000
	s_nop 0                                                    // 0000003F9778: BF800000
	s_nop 0                                                    // 0000003F977C: BF800000
	ds_load_b32 v5, v3 offset:16384                            // 0000003F9780: D8D84000 05000003
	.long 0xd7000a04                                           // 0000003F9788: D7000A04
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 0000003F978C: 020208FF 00000100
	s_xor_b32 s10, s10, -1                                     // 0000003F9794: 8D0AC10A
	v_add_nc_u32_e32 v3, 0x400, v3                             // 0000003F9798: 4A0606FF 00000400
	s_and_b32 s10, exec_lo, s10                                // 0000003F97A0: 8B0A0A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000003F97A4: BF8700C9
	s_or_b32 s9, s10, s9                                       // 0000003F97A8: 8C09090A
	s_waitcnt lgkmcnt(0)                                       // 0000003F97AC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000003F97B0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 0000003F97B8: D7006A01
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 0000003F97BC: 02000101
	v_add_co_ci_u32_e64 v2, null, s1, v2, vcc_lo               // 0000003F97C0: D5207C02 01AA0401
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000003F97C8: 917E097E
	s_cbranch_execnz 65516                                     // 0000003F97CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2780>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000003F97D0: 8C7E087E
	s_ashr_i32 s31, s30, 31                                    // 0000003F97D4: 861F9F1E
	.long 0xd44a0000                                           // 0000003F97D8: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000003F97DC: 02020080
	s_lshl_b64 s[8:9], s[30:31], 2                             // 0000003F97E0: 8488821E
	s_waitcnt_vscnt null, 0x0                                  // 0000003F97E4: BC7C0000
	buffer_gl1_inv                                             // 0000003F97E8: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003F97F0: E0AC0000 00000000
	s_add_u32 s8, s6, s8                                       // 0000003F97F8: 80080806
	s_addc_u32 s9, s7, s9                                      // 0000003F97FC: 82090907
	s_barrier                                                  // 0000003F9800: BFBD0000
	buffer_gl0_inv                                             // 0000003F9804: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000003F980C: BE812000
	s_cbranch_execz 29                                         // 0000003F9810: BFA5001D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2888>
	s_mov_b32 s7, exec_lo                                      // 0000003F9814: BE87007E
	s_mov_b32 s6, exec_lo                                      // 0000003F9818: BE86007E
	.long 0xd71f0001                                           // 0000003F981C: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 0000003F9820: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F9824: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 0000003F9828: 7D940280
	s_cbranch_execz 9                                          // 0000003F982C: BFA50009 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2854>
	s_lshl_b64 s[10:11], s[26:27], 2                           // 0000003F9830: 848A821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000003F9834: BF8704B9
	s_add_u32 s10, s8, s10                                     // 0000003F9838: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 0000003F983C: 820B0B09
	s_bcnt1_i32_b32 s7, s7                                     // 0000003F9840: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 0000003F9844: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[10:11] glc             // 0000003F984C: DCD64000 020A0302
	s_or_b32 exec_lo, exec_lo, s6                              // 0000003F9854: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 0000003F9858: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 0000003F985C: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F9860: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 0000003F9864: CA200080 02000206
	s_add_i32 s6, s21, -1                                      // 0000003F986C: 8106C115
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000003F9870: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 0000003F9874: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000003F9878: D5010001 01A90280
	ds_store_b32 v2, v1 offset:20480                           // 0000003F9880: D8345000 00000102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000003F9888: 8C7E017E
	v_mov_b32_e32 v1, 0                                        // 0000003F988C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000003F9890: BF89FC07
	s_barrier                                                  // 0000003F9894: BFBD0000
	buffer_gl0_inv                                             // 0000003F9898: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:20480                            // 0000003F98A0: D8D85000 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000003F98A8: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000003F98AC: 7C940280
	s_cbranch_vccnz 932                                        // 0000003F98B0: BFA403A4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3744>
	buffer_gl1_inv                                             // 0000003F98B4: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003F98BC: E0AC0000 00000000
	s_and_saveexec_b32 s10, s3                                 // 0000003F98C4: BE8A2003
	s_cbranch_execz 76                                         // 0000003F98C8: BFA5004C <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x29fc>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000003F98CC: 32020087
	s_lshl_b32 s16, s26, 7                                     // 0000003F98D0: 8410871A
	v_and_b32_e32 v3, 0x7f, v0                                 // 0000003F98D4: 360600FF 0000007F
	s_ashr_i32 s17, s16, 31                                    // 0000003F98DC: 86119F10
	s_lshl_b64 s[22:23], s[28:29], 2                           // 0000003F98E0: 8496821C
	v_mad_i64_i32 v[1:2], null, v1, s20, 0                     // 0000003F98E4: D6FF7C01 02002901
	s_lshl_b64 s[16:17], s[16:17], 2                           // 0000003F98EC: 84908210
	s_ashr_i32 s7, s20, 31                                     // 0000003F98F0: 86079F14
	s_add_u32 s1, s16, s22                                     // 0000003F98F4: 80011610
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000003F98F8: 30060682
	s_addc_u32 s3, s17, s23                                    // 0000003F98FC: 82031711
	v_mov_b32_e32 v5, v0                                       // 0000003F9900: 7E0A0300
	s_mov_b32 s6, s20                                          // 0000003F9904: BE860014
	.long 0xd73c0001                                           // 0000003F9908: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000003F990C: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F9910: BF870091
	.long 0xd7006a01                                           // 0000003F9914: D7006A01
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 0000003F9918: 02020201
	v_add_co_ci_u32_e64 v2, null, s3, v2, vcc_lo               // 0000003F991C: D5207C02 01AA0403
	s_mov_b32 s3, 0                                            // 0000003F9924: BE830080
	.long 0xd7006a01                                           // 0000003F9928: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000003F992C: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F9930: BF870111
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000003F9934: D5207C02 01AA0480
	.long 0xd7006a01                                           // 0000003F993C: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000003F9940: 02020204
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F9944: BF870001
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000003F9948: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[6:7], 3                               // 0000003F9950: 84848306
	s_lshl_b64 s[6:7], s[6:7], 4                               // 0000003F9954: 84868406
	s_nop 0                                                    // 0000003F9958: BF800000
	s_nop 0                                                    // 0000003F995C: BF800000
	s_nop 0                                                    // 0000003F9960: BF800000
	s_nop 0                                                    // 0000003F9964: BF800000
	s_nop 0                                                    // 0000003F9968: BF800000
	s_nop 0                                                    // 0000003F996C: BF800000
	s_nop 0                                                    // 0000003F9970: BF800000
	s_nop 0                                                    // 0000003F9974: BF800000
	s_nop 0                                                    // 0000003F9978: BF800000
	s_nop 0                                                    // 0000003F997C: BF800000
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 0000003F9980: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 0000003F9988: 7E0C0280
	s_mov_b32 s1, s21                                          // 0000003F998C: BE810015
	global_load_b32 v7, v[3:4], off glc                        // 0000003F9990: DC524000 077C0003
	.long 0xd7006a03                                           // 0000003F9998: D7006A03
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 0000003F999C: 02000D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003F99A0: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s7, v4, vcc_lo               // 0000003F99A4: D5207C04 01AA0807
	s_add_i32 s1, s1, -1                                       // 0000003F99AC: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 0000003F99B0: BF068001
	s_waitcnt vmcnt(0)                                         // 0000003F99B4: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 0000003F99B8: 060C0F06
	s_cbranch_scc0 65524                                       // 0000003F99BC: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2990>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 0000003F99C0: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 0000003F99C8: 7C920AFF 000000FF
	.long 0xd7000101                                           // 0000003F99D0: D7000101
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 0000003F99D4: 02000901
	v_lshlrev_b32_e32 v3, 2, v5                                // 0000003F99D8: 30060A82
	v_add_co_ci_u32_e64 v2, null, s5, v2, s1                   // 0000003F99DC: D5207C02 00060405
	v_mov_b32_e32 v5, v4                                       // 0000003F99E4: 7E0A0304
	s_or_b32 s3, vcc_lo, s3                                    // 0000003F99E8: 8C03036A
	ds_store_b32 v3, v6 offset:16384                           // 0000003F99EC: D8344000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 0000003F99F4: 917E037E
	s_cbranch_execnz 65505                                     // 0000003F99F8: BFA6FFE1 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2980>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000003F99FC: 8C7E0A7E
	s_and_saveexec_b32 s1, s0                                  // 0000003F9A00: BE812000
	s_cbranch_execz 6                                          // 0000003F9A04: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a20>
	s_lshl_b64 s[4:5], s[26:27], 2                             // 0000003F9A08: 8484821A
	v_mov_b32_e32 v1, 0                                        // 0000003F9A0C: 7E020280
	s_add_u32 s4, s8, s4                                       // 0000003F9A10: 80040408
	s_addc_u32 s5, s9, s5                                      // 0000003F9A14: 82050509
	global_store_b32 v1, v1, s[4:5]                            // 0000003F9A18: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 0000003F9A20: 8C7E017E
	s_mov_b32 s4, -1                                           // 0000003F9A24: BE8400C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F9A28: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 0000003F9A2C: 8B6A047E
	s_cbranch_vccz 63086                                       // 0000003F9A30: BFA3F66E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_cmp_gt_i32_e32 vcc_lo, s18, v48                          // 0000003F9A34: 7C886012
	.long 0xd44c0000                                           // 0000003F9A38: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000003F9A3C: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 0000003F9A44: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000003F9A48: BC7C0000
	s_barrier                                                  // 0000003F9A4C: BFBD0000
	buffer_gl0_inv                                             // 0000003F9A50: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 0000003F9A58: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F9A5C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000003F9A60: BE812000
	s_cbranch_execz 63073                                      // 0000003F9A64: BFA5F661 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_and_b32_e32 v1, 15, v0                                   // 0000003F9A68: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F9A6C: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000003F9A70: 30040282
	v_lshl_or_b32 v2, v48, 9, v2                               // 0000003F9A74: D6560002 04091330
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F9A7C: BF870001
	v_add_nc_u32_e32 v8, 0x4000, v2                            // 0000003F9A80: 4A1004FF 00004000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000003F9A88: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000003F9A90: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000003F9A98: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000003F9AA0: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000003F9AA8: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000003F9AAC: 36160082
	s_waitcnt lgkmcnt(3)                                       // 0000003F9AB0: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 0000003F9AB4: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 0000003F9ABC: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 0000003F9AC0: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 0000003F9AC8: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000003F9ACC: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000003F9AD4: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 0000003F9AD8: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 0000003F9AE0: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 0000003F9AE8: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003F9AEC: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 0000003F9AF0: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 0000003F9AF8: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000003F9B00: 7C941480
	.long 0xd44a0000                                           // 0000003F9B04: D44A0000
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 0000003F9B08: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 0000003F9B0C: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 0000003F9B14: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 0000003F9B18: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003F9B1C: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 0000003F9B20: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 0000003F9B24: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 0000003F9B2C: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 0000003F9B30: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 0000003F9B34: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F9B38: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000003F9B40: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F9B48: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003F9B50: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F9B58: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000003F9B60: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F9B68: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F9B70: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F9B78: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003F9B80: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F9B88: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000003F9B90: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F9B98: 7E2402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000003F9BA0: D5010003 21AA0703
	v_mov_b32_dpp v19, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F9BA8: 7E2602FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000003F9BB0: D5010002 21AA0502
	v_dual_add_f32 v6, v7, v6 :: v_dual_add_f32 v5, v5, v15    // 0000003F9BB8: C9080D07 06041F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000003F9BC0: 7C941680
	v_dual_add_f32 v7, v9, v10 :: v_dual_add_f32 v8, v8, v16   // 0000003F9BC4: C9081509 07082108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003F9BCC: BF870233
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F9BD0: 7E1402FA FF016206
	v_add_f32_e32 v4, v4, v17                                  // 0000003F9BD8: 06082304
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003F9BDC: D5010006 21AA0D06
	v_mov_b32_dpp v11, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F9BE4: 7E1602FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000003F9BEC: D5010007 21AA0F07
	v_add_f32_e32 v2, v2, v19                                  // 0000003F9BF4: 06042702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F9BF8: BF870092
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 0000003F9BFC: C9081506 06061707
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F9C04: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 0000003F9C0C: D5010006 20020D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003F9C14: BF8700D3
	v_mov_b32_dpp v11, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F9C18: 7E1602FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 0000003F9C20: D5010007 20020F07
	v_add_f32_e32 v9, v13, v14                                 // 0000003F9C28: 06121D0D
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F9C2C: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F9C34: D5010005 21AA0B05
	v_dual_add_f32 v15, v5, v14 :: v_dual_add_f32 v14, v7, v11 // 0000003F9C3C: C9081D05 0F0E1707
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F9C44: BF8701A4
	v_mov_b32_dpp v13, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F9C48: 7E1A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003F9C50: D5010009 21AA1309
	v_mov_b32_dpp v7, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F9C58: 7E0E02FA FF01640F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F9C60: BF870194
	v_mov_b32_dpp v23, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F9C64: 7E2E02FA FF01680E
	v_add_f32_e32 v9, v9, v13                                  // 0000003F9C6C: 06121B09
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F9C70: 7E1A02FA FF016208
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F9C78: BF8700A2
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F9C7C: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 0000003F9C84: D5010009 20021309
	v_add_f32_e32 v21, v9, v12                                 // 0000003F9C8C: 062A1909
	v_mov_b32_dpp v12, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F9C90: 7E1802FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000003F9C98: D5010002 21AA0502
	v_add_f32_e32 v3, v3, v18                                  // 0000003F9CA0: 06062503
	v_cndmask_b32_e64 v9, -v15, v15, s0                        // 0000003F9CA4: D5010009 20021F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F9CAC: BF870193
	v_add_f32_e32 v2, v2, v12                                  // 0000003F9CB0: 06041902
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F9CB4: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000003F9CBC: D5010003 21AA0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F9CC4: BF870114
	v_add_f32_e32 v19, v9, v7                                  // 0000003F9CC8: 06260F09
	v_add_f32_e32 v3, v3, v11                                  // 0000003F9CCC: 06061703
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F9CD0: BF870112
	v_mov_b32_dpp v20, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F9CD4: 7E2802FA FF016813
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F9CDC: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 0000003F9CE4: D5010003 20020703
	v_add_f32_e32 v5, v6, v10                                  // 0000003F9CEC: 060A1506
	v_cndmask_b32_e64 v6, -v8, v8, vcc_lo                      // 0000003F9CF0: D5010006 21AA1108
	v_mov_b32_dpp v10, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F9CF8: 7E1402FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000003F9D00: D5010004 21AA0904
	v_add_f32_e32 v12, v3, v12                                 // 0000003F9D08: 06181903
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F9D0C: 7E1002FA FF016805
	v_add_f32_e32 v6, v6, v13                                  // 0000003F9D14: 060C1B06
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F9D18: 7E1A02FA FF016402
	v_add_f32_e32 v4, v4, v10                                  // 0000003F9D20: 06081504
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 0000003F9D24: D5010002 20020502
	v_mov_b32_dpp v22, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F9D2C: 7E2C02FA FF016815
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F9D34: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 0000003F9D3C: D5010006 20020D06
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F9D44: 7E1602FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 0000003F9D4C: D5010004 20020904
	v_add_f32_e32 v9, v2, v13                                  // 0000003F9D54: 06121B02
	v_mov_b32_dpp v13, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F9D58: 7E1A02FA FF01680C
	v_add_f32_e32 v17, v6, v10                                 // 0000003F9D60: 06221506
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F9D64: BF870214
	v_add_f32_e32 v15, v4, v11                                 // 0000003F9D68: 061E1704
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F9D6C: 7E1402FA FF016809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F9D74: BF870193
	v_mov_b32_dpp v18, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F9D78: 7E2402FA FF016811
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F9D80: 7E2002FA FF01680F
	s_and_b32 exec_lo, exec_lo, s2                             // 0000003F9D88: 8B7E027E
	s_cbranch_execz 62871                                      // 0000003F9D8C: BFA5F597 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_lshl_or_b32 v3, s26, 7, v1                               // 0000003F9D90: D6560003 04050E1A
	v_and_b32_e32 v0, 8, v0                                    // 0000003F9D98: 36000088
	s_cmp_lg_u64 s[24:25], 0                                   // 0000003F9D9C: BF118018
	s_cselect_b32 s1, -1, 0                                    // 0000003F9DA0: 980180C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F9DA4: BF870112
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000003F9DA8: 3408069F
	.long 0xd44a0000                                           // 0000003F9DAC: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000003F9DB0: 02020080
	s_lshr_b32 s2, s20, 31                                     // 0000003F9DB4: 85029F14
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F9DB8: BF870009
	s_add_i32 s2, s20, s2                                      // 0000003F9DBC: 81020214
	.long 0xd73c0001                                           // 0000003F9DC0: D73C0001
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000003F9DC4: 02020681
	v_cndmask_b32_e64 v0, -v5, v5, s0                          // 0000003F9DC8: D5010000 20020B05
	v_mad_i64_i32 v[4:5], null, s20, v48, 0                    // 0000003F9DD0: D6FF7C04 02026014
	s_ashr_i32 s2, s2, 1                                       // 0000003F9DD8: 86028102
	s_cmp_eq_u64 s[24:25], 0                                   // 0000003F9DDC: BF108018
	v_mad_i64_i32 v[24:25], null, s2, v48, 0                   // 0000003F9DE0: D6FF7C18 02026002
	.long 0xd7006a06                                           // 0000003F9DE8: D7006A06
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 0000003F9DEC: 0202020C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F9DF0: BF870001
	v_add_co_ci_u32_e64 v7, null, s13, v2, vcc_lo              // 0000003F9DF4: D5207C07 01AA040D
	v_add_f32_e32 v0, v0, v8                                   // 0000003F9DFC: 06001100
	.long 0xd73c0004                                           // 0000003F9E00: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000003F9E04: 02020881
	global_load_d16_b16 v11, v[6:7], off                       // 0000003F9E08: DC820000 0B7C0006
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000003F9E10: 100000FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F9E18: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F9E1C: BF8700A1
	v_fma_mix_f32 v26, v11, v0, neg(0) op_sel_hi:[1,0,0]       // 0000003F9E20: CC20001A 8A02010B
	.long 0xd7006a00                                           // 0000003F9E28: D7006A00
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 0000003F9E2C: 0202080E
	v_add_co_ci_u32_e64 v8, null, s15, v5, vcc_lo              // 0000003F9E30: D5207C08 01AA0A0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003F9E38: BF8701B3
	v_bfe_u32 v27, v26, 16, 1                                  // 0000003F9E3C: D610001B 0205211A
	.long 0xd73c0004                                           // 0000003F9E44: D73C0004
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000003F9E48: 02023081
	v_ashrrev_i32_e32 v11, 31, v3                              // 0000003F9E4C: 3416069F
	v_add3_u32 v24, v26, v27, 0x7fff                           // 0000003F9E50: D6550018 03FE371A 00007FFF
	s_cbranch_scc1 570                                         // 0000003F9E5C: BFA2023A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3748>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003F9E60: BF870122
	v_lshrrev_b32_e32 v25, 23, v11                             // 0000003F9E64: 32321697
	v_mov_b32_e32 v29, s14                                     // 0000003F9E68: 7E3A020E
	v_add_nc_u32_e32 v25, v3, v25                              // 0000003F9E6C: 4A323303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F9E70: BF870091
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 0000003F9E74: 363432FF FFFFFE00
	v_sub_nc_u32_e32 v27, v3, v26                              // 0000003F9E7C: 4C363503
	v_mov_b32_e32 v26, s15                                     // 0000003F9E80: 7E34020F
	v_ashrrev_i32_e32 v25, 9, v25                              // 0000003F9E84: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F9E88: BF8701A3
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v27                        // 0000003F9E8C: 7C8836FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v27                      // 0000003F9E94: 4A3836FF FFFFFF00
	v_dual_cndmask_b32 v30, s25, v26 :: v_dual_lshlrev_b32 v25, 8, v25// 0000003F9E9C: CA623419 1E183288
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F9EA4: BF870112
	v_cndmask_b32_e32 v27, v28, v27, vcc_lo                    // 0000003F9EA8: 0236371C
	v_ashrrev_i32_e32 v26, 31, v25                             // 0000003F9EAC: 3434329F
	v_cndmask_b32_e32 v29, s24, v29, vcc_lo                    // 0000003F9EB0: 023A3A18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F9EB4: BF870193
	v_ashrrev_i32_e32 v28, 31, v27                             // 0000003F9EB8: 3438369F
	.long 0xd73c0019                                           // 0000003F9EBC: D73C0019
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 0000003F9EC0: 02023281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F9EC4: BF870093
	.long 0xd7006a1d                                           // 0000003F9EC8: D7006A1D
	v_cndmask_b32_e32 v1, v29, v4, vcc_lo                      // 0000003F9ECC: 0202091D
	v_add_co_ci_u32_e64 v30, null, v30, v5, vcc_lo             // 0000003F9ED0: D5207C1E 01AA0B1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F9ED8: BF870194
	.long 0xd73c001b                                           // 0000003F9EDC: D73C001B
	v_cndmask_b32_e32 v1, 1, v27, vcc_lo                       // 0000003F9EE0: 02023681
	.long 0xd7006a19                                           // 0000003F9EE4: D7006A19
	v_cndmask_b32_e32 v1, v29, v25, vcc_lo                     // 0000003F9EE8: 0202331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F9EEC: BF870111
	v_add_co_ci_u32_e64 v26, null, v30, v26, vcc_lo            // 0000003F9EF0: D5207C1A 01AA351E
	.long 0xd7006a19                                           // 0000003F9EF8: D7006A19
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 0000003F9EFC: 02023719
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F9F00: BF870001
	v_add_co_ci_u32_e64 v26, null, v26, v28, vcc_lo            // 0000003F9F04: D5207C1A 01AA391A
	global_store_d16_hi_b16 v[25:26], v24, off                 // 0000003F9F0C: DC960000 007C1819
	s_cbranch_execnz 7                                         // 0000003F9F14: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2f34>
	.long 0xd7006a19                                           // 0000003F9F18: D7006A19
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F9F1C: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F9F20: BF870001
	v_add_co_ci_u32_e64 v26, null, v8, v2, vcc_lo              // 0000003F9F24: D5207C1A 01AA0508
	global_store_d16_hi_b16 v[25:26], v24, off                 // 0000003F9F2C: DC960000 007C1819
	global_load_d16_b16 v24, v[6:7], off offset:32             // 0000003F9F34: DC820020 187C0006
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 0000003F9F3C: D501000E 20021D0E
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000003F9F44: 916A017E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F9F48: BF870091
	v_add_f32_e32 v14, v14, v23                                // 0000003F9F4C: 061C2F0E
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 0000003F9F50: 101C1CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F9F58: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003F9F5C: BF870121
	v_fma_mix_f32 v23, v24, v14, neg(0) op_sel_hi:[1,0,0]      // 0000003F9F60: CC200017 8A021D18
	v_cndmask_b32_e64 v14, 0, 1, s1                            // 0000003F9F68: D501000E 00050280
	v_bfe_u32 v24, v23, 16, 1                                  // 0000003F9F70: D6100018 02052117
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F9F78: BF870001
	v_add3_u32 v23, v23, v24, 0x7fff                           // 0000003F9F7C: D6550017 03FE3117 00007FFF
	s_cbranch_vccnz 496                                        // 0000003F9F88: BFA401F0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x374c>
	v_or_b32_e32 v24, 16, v3                                   // 0000003F9F8C: 38300690
	v_lshrrev_b32_e32 v25, 23, v11                             // 0000003F9F90: 32321697
	v_mov_b32_e32 v27, s15                                     // 0000003F9F94: 7E36020F
	v_mov_b32_e32 v29, s14                                     // 0000003F9F98: 7E3A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F9F9C: BF870093
	v_add_nc_u32_e32 v25, v24, v25                             // 0000003F9FA0: 4A323318
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 0000003F9FA4: 363432FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F9FAC: BF870091
	v_sub_nc_u32_e32 v26, v24, v26                             // 0000003F9FB0: 4C343518
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v26                        // 0000003F9FB4: 7C8834FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v26                      // 0000003F9FBC: 4A3834FF FFFFFF00
	v_cndmask_b32_e32 v30, s25, v27, vcc_lo                    // 0000003F9FC4: 023C3619
	v_ashrrev_i32_e32 v25, 9, v25                              // 0000003F9FC8: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F9FCC: BF8701A3
	v_cndmask_b32_e32 v26, v28, v26, vcc_lo                    // 0000003F9FD0: 0234351C
	v_cndmask_b32_e32 v28, s24, v29, vcc_lo                    // 0000003F9FD4: 02383A18
	v_lshlrev_b32_e32 v24, 8, v25                              // 0000003F9FD8: 30303288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F9FDC: BF870193
	v_ashrrev_i32_e32 v27, 31, v26                             // 0000003F9FE0: 3436349F
	.long 0xd7006a1c                                           // 0000003F9FE4: D7006A1C
	v_cndmask_b32_e32 v1, v28, v4, vcc_lo                      // 0000003F9FE8: 0202091C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F9FEC: BF870211
	v_add_co_ci_u32_e64 v29, null, v30, v5, vcc_lo             // 0000003F9FF0: D5207C1D 01AA0B1E
	v_ashrrev_i32_e32 v25, 31, v24                             // 0000003F9FF8: 3432309F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F9FFC: BF870114
	.long 0xd73c001a                                           // 0000003FA000: D73C001A
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000003FA004: 02023481
	.long 0xd73c0018                                           // 0000003FA008: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000003FA00C: 02023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA010: BF870091
	.long 0xd7006a18                                           // 0000003FA014: D7006A18
	v_cndmask_b32_e32 v1, v28, v24, vcc_lo                     // 0000003FA018: 0202311C
	v_add_co_ci_u32_e64 v25, null, v29, v25, vcc_lo            // 0000003FA01C: D5207C19 01AA331D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA024: BF870092
	.long 0xd7006a18                                           // 0000003FA028: D7006A18
	v_cndmask_b32_e32 v1, v24, v26, vcc_lo                     // 0000003FA02C: 02023518
	v_add_co_ci_u32_e64 v25, null, v25, v27, vcc_lo            // 0000003FA030: D5207C19 01AA3719
	global_store_d16_hi_b16 v[24:25], v23, off                 // 0000003FA038: DC960000 007C1718
	s_cbranch_execnz 7                                         // 0000003FA040: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3060>
	.long 0xd7006a18                                           // 0000003FA044: D7006A18
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003FA048: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003FA04C: BF870001
	v_add_co_ci_u32_e64 v25, null, v8, v2, vcc_lo              // 0000003FA050: D5207C19 01AA0508
	global_store_d16_hi_b16 v[24:25], v23, off offset:32       // 0000003FA058: DC960020 007C1718
	global_load_d16_b16 v23, v[6:7], off offset:64             // 0000003FA060: DC820040 177C0006
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 0000003FA068: D5010015 20022B15
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003FA070: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003FA074: BF8700A2
	v_add_f32_e32 v21, v21, v22                                // 0000003FA078: 062A2D15
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003FA07C: 8B6A6A7E
	v_mul_f32_e32 v21, 0x3db504f3, v21                         // 0000003FA080: 102A2AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003FA088: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA08C: BF870091
	v_fma_mix_f32 v21, v23, v21, neg(0) op_sel_hi:[1,0,0]      // 0000003FA090: CC200015 8A022B17
	v_bfe_u32 v22, v21, 16, 1                                  // 0000003FA098: D6100016 02052115
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003FA0A0: BF870001
	v_add3_u32 v21, v21, v22, 0x7fff                           // 0000003FA0A4: D6550015 03FE2D15 00007FFF
	s_cbranch_vccnz 423                                        // 0000003FA0B0: BFA401A7 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3750>
	v_or_b32_e32 v22, 32, v3                                   // 0000003FA0B4: 382C06A0
	v_lshrrev_b32_e32 v23, 23, v11                             // 0000003FA0B8: 322E1697
	v_mov_b32_e32 v25, s15                                     // 0000003FA0BC: 7E32020F
	v_mov_b32_e32 v27, s14                                     // 0000003FA0C0: 7E36020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA0C4: BF870093
	v_add_nc_u32_e32 v23, v22, v23                             // 0000003FA0C8: 4A2E2F16
	v_and_b32_e32 v24, 0xfffffe00, v23                         // 0000003FA0CC: 36302EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA0D4: BF870091
	v_sub_nc_u32_e32 v24, v22, v24                             // 0000003FA0D8: 4C303116
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v24                        // 0000003FA0DC: 7C8830FF 00000100
	v_add_nc_u32_e32 v26, 0xffffff00, v24                      // 0000003FA0E4: 4A3430FF FFFFFF00
	v_cndmask_b32_e32 v28, s25, v25, vcc_lo                    // 0000003FA0EC: 02383219
	v_ashrrev_i32_e32 v23, 9, v23                              // 0000003FA0F0: 342E2E89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003FA0F4: BF8701A3
	v_cndmask_b32_e32 v24, v26, v24, vcc_lo                    // 0000003FA0F8: 0230311A
	v_cndmask_b32_e32 v26, s24, v27, vcc_lo                    // 0000003FA0FC: 02343618
	v_lshlrev_b32_e32 v22, 8, v23                              // 0000003FA100: 302C2E88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003FA104: BF870193
	v_ashrrev_i32_e32 v25, 31, v24                             // 0000003FA108: 3432309F
	.long 0xd7006a1a                                           // 0000003FA10C: D7006A1A
	v_cndmask_b32_e32 v1, v26, v4, vcc_lo                      // 0000003FA110: 0202091A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003FA114: BF870211
	v_add_co_ci_u32_e64 v27, null, v28, v5, vcc_lo             // 0000003FA118: D5207C1B 01AA0B1C
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000003FA120: 342E2C9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003FA124: BF870114
	.long 0xd73c0018                                           // 0000003FA128: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000003FA12C: 02023081
	.long 0xd73c0016                                           // 0000003FA130: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000003FA134: 02022C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA138: BF870091
	.long 0xd7006a16                                           // 0000003FA13C: D7006A16
	v_cndmask_b32_e32 v1, v26, v22, vcc_lo                     // 0000003FA140: 02022D1A
	v_add_co_ci_u32_e64 v23, null, v27, v23, vcc_lo            // 0000003FA144: D5207C17 01AA2F1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA14C: BF870092
	.long 0xd7006a16                                           // 0000003FA150: D7006A16
	v_cndmask_b32_e32 v1, v22, v24, vcc_lo                     // 0000003FA154: 02023116
	v_add_co_ci_u32_e64 v23, null, v23, v25, vcc_lo            // 0000003FA158: D5207C17 01AA3317
	global_store_d16_hi_b16 v[22:23], v21, off                 // 0000003FA160: DC960000 007C1516
	s_cbranch_execnz 7                                         // 0000003FA168: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3188>
	.long 0xd7006a16                                           // 0000003FA16C: D7006A16
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003FA170: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003FA174: BF870001
	v_add_co_ci_u32_e64 v23, null, v8, v2, vcc_lo              // 0000003FA178: D5207C17 01AA0508
	global_store_d16_hi_b16 v[22:23], v21, off offset:64       // 0000003FA180: DC960040 007C1516
	global_load_d16_b16 v21, v[6:7], off offset:96             // 0000003FA188: DC820060 157C0006
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 0000003FA190: D5010013 20022713
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003FA198: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003FA19C: BF8700A2
	v_add_f32_e32 v19, v19, v20                                // 0000003FA1A0: 06262913
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003FA1A4: 8B6A6A7E
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 0000003FA1A8: 102626FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003FA1B0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA1B4: BF870091
	v_fma_mix_f32 v19, v21, v19, neg(0) op_sel_hi:[1,0,0]      // 0000003FA1B8: CC200013 8A022715
	v_bfe_u32 v20, v19, 16, 1                                  // 0000003FA1C0: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003FA1C8: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000003FA1CC: D6550013 03FE2913 00007FFF
	s_cbranch_vccnz 350                                        // 0000003FA1D8: BFA4015E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3754>
	v_or_b32_e32 v20, 48, v3                                   // 0000003FA1DC: 382806B0
	v_lshrrev_b32_e32 v21, 23, v11                             // 0000003FA1E0: 322A1697
	v_mov_b32_e32 v23, s15                                     // 0000003FA1E4: 7E2E020F
	v_mov_b32_e32 v25, s14                                     // 0000003FA1E8: 7E32020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA1EC: BF870093
	v_add_nc_u32_e32 v21, v20, v21                             // 0000003FA1F0: 4A2A2B14
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 0000003FA1F4: 362C2AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA1FC: BF870091
	v_sub_nc_u32_e32 v22, v20, v22                             // 0000003FA200: 4C2C2D14
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 0000003FA204: 7C882CFF 00000100
	v_add_nc_u32_e32 v24, 0xffffff00, v22                      // 0000003FA20C: 4A302CFF FFFFFF00
	v_cndmask_b32_e32 v26, s25, v23, vcc_lo                    // 0000003FA214: 02342E19
	v_ashrrev_i32_e32 v21, 9, v21                              // 0000003FA218: 342A2A89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003FA21C: BF8701A3
	v_cndmask_b32_e32 v22, v24, v22, vcc_lo                    // 0000003FA220: 022C2D18
	v_cndmask_b32_e32 v24, s24, v25, vcc_lo                    // 0000003FA224: 02303218
	v_lshlrev_b32_e32 v20, 8, v21                              // 0000003FA228: 30282A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003FA22C: BF870193
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000003FA230: 342E2C9F
	.long 0xd7006a18                                           // 0000003FA234: D7006A18
	v_cndmask_b32_e32 v1, v24, v4, vcc_lo                      // 0000003FA238: 02020918
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003FA23C: BF870211
	v_add_co_ci_u32_e64 v25, null, v26, v5, vcc_lo             // 0000003FA240: D5207C19 01AA0B1A
	v_ashrrev_i32_e32 v21, 31, v20                             // 0000003FA248: 342A289F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003FA24C: BF870114
	.long 0xd73c0016                                           // 0000003FA250: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000003FA254: 02022C81
	.long 0xd73c0014                                           // 0000003FA258: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000003FA25C: 02022881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA260: BF870091
	.long 0xd7006a14                                           // 0000003FA264: D7006A14
	v_cndmask_b32_e32 v1, v24, v20, vcc_lo                     // 0000003FA268: 02022918
	v_add_co_ci_u32_e64 v21, null, v25, v21, vcc_lo            // 0000003FA26C: D5207C15 01AA2B19
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA274: BF870092
	.long 0xd7006a14                                           // 0000003FA278: D7006A14
	v_cndmask_b32_e32 v1, v20, v22, vcc_lo                     // 0000003FA27C: 02022D14
	v_add_co_ci_u32_e64 v21, null, v21, v23, vcc_lo            // 0000003FA280: D5207C15 01AA2F15
	global_store_d16_hi_b16 v[20:21], v19, off                 // 0000003FA288: DC960000 007C1314
	s_cbranch_execnz 7                                         // 0000003FA290: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x32b0>
	.long 0xd7006a14                                           // 0000003FA294: D7006A14
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003FA298: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003FA29C: BF870001
	v_add_co_ci_u32_e64 v21, null, v8, v2, vcc_lo              // 0000003FA2A0: D5207C15 01AA0508
	global_store_d16_hi_b16 v[20:21], v19, off offset:96       // 0000003FA2A8: DC960060 007C1314
	global_load_d16_b16 v19, v[6:7], off offset:128            // 0000003FA2B0: DC820080 137C0006
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 0000003FA2B8: D5010011 20022311
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003FA2C0: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003FA2C4: BF8700A2
	v_add_f32_e32 v17, v17, v18                                // 0000003FA2C8: 06222511
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003FA2CC: 8B6A6A7E
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 0000003FA2D0: 102222FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003FA2D8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA2DC: BF870091
	v_fma_mix_f32 v17, v19, v17, neg(0) op_sel_hi:[1,0,0]      // 0000003FA2E0: CC200011 8A022313
	v_bfe_u32 v18, v17, 16, 1                                  // 0000003FA2E8: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003FA2F0: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 0000003FA2F4: D6550011 03FE2511 00007FFF
	s_cbranch_vccnz 277                                        // 0000003FA300: BFA40115 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3758>
	v_or_b32_e32 v18, 64, v3                                   // 0000003FA304: 382406C0
	v_lshrrev_b32_e32 v19, 23, v11                             // 0000003FA308: 32261697
	v_mov_b32_e32 v21, s15                                     // 0000003FA30C: 7E2A020F
	v_mov_b32_e32 v23, s14                                     // 0000003FA310: 7E2E020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA314: BF870093
	v_add_nc_u32_e32 v19, v18, v19                             // 0000003FA318: 4A262712
	v_and_b32_e32 v20, 0xfffffe00, v19                         // 0000003FA31C: 362826FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA324: BF870091
	v_sub_nc_u32_e32 v20, v18, v20                             // 0000003FA328: 4C282912
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v20                        // 0000003FA32C: 7C8828FF 00000100
	v_add_nc_u32_e32 v22, 0xffffff00, v20                      // 0000003FA334: 4A2C28FF FFFFFF00
	v_cndmask_b32_e32 v24, s25, v21, vcc_lo                    // 0000003FA33C: 02302A19
	v_ashrrev_i32_e32 v19, 9, v19                              // 0000003FA340: 34262689
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003FA344: BF8701A3
	v_cndmask_b32_e32 v20, v22, v20, vcc_lo                    // 0000003FA348: 02282916
	v_cndmask_b32_e32 v22, s24, v23, vcc_lo                    // 0000003FA34C: 022C2E18
	v_lshlrev_b32_e32 v18, 8, v19                              // 0000003FA350: 30242688
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003FA354: BF870193
	v_ashrrev_i32_e32 v21, 31, v20                             // 0000003FA358: 342A289F
	.long 0xd7006a16                                           // 0000003FA35C: D7006A16
	v_cndmask_b32_e32 v1, v22, v4, vcc_lo                      // 0000003FA360: 02020916
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003FA364: BF870211
	v_add_co_ci_u32_e64 v23, null, v24, v5, vcc_lo             // 0000003FA368: D5207C17 01AA0B18
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000003FA370: 3426249F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003FA374: BF870114
	.long 0xd73c0014                                           // 0000003FA378: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000003FA37C: 02022881
	.long 0xd73c0012                                           // 0000003FA380: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000003FA384: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA388: BF870091
	.long 0xd7006a12                                           // 0000003FA38C: D7006A12
	v_cndmask_b32_e32 v1, v22, v18, vcc_lo                     // 0000003FA390: 02022516
	v_add_co_ci_u32_e64 v19, null, v23, v19, vcc_lo            // 0000003FA394: D5207C13 01AA2717
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA39C: BF870092
	.long 0xd7006a12                                           // 0000003FA3A0: D7006A12
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 0000003FA3A4: 02022912
	v_add_co_ci_u32_e64 v19, null, v19, v21, vcc_lo            // 0000003FA3A8: D5207C13 01AA2B13
	global_store_d16_hi_b16 v[18:19], v17, off                 // 0000003FA3B0: DC960000 007C1112
	s_cbranch_execnz 7                                         // 0000003FA3B8: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x33d8>
	.long 0xd7006a12                                           // 0000003FA3BC: D7006A12
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003FA3C0: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003FA3C4: BF870001
	v_add_co_ci_u32_e64 v19, null, v8, v2, vcc_lo              // 0000003FA3C8: D5207C13 01AA0508
	global_store_d16_hi_b16 v[18:19], v17, off offset:128      // 0000003FA3D0: DC960080 007C1112
	global_load_d16_b16 v17, v[6:7], off offset:160            // 0000003FA3D8: DC8200A0 117C0006
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 0000003FA3E0: D501000F 20021F0F
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003FA3E8: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003FA3EC: BF8700A2
	v_add_f32_e32 v15, v15, v16                                // 0000003FA3F0: 061E210F
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003FA3F4: 8B6A6A7E
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 0000003FA3F8: 101E1EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003FA400: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA404: BF870091
	v_fma_mix_f32 v15, v17, v15, neg(0) op_sel_hi:[1,0,0]      // 0000003FA408: CC20000F 8A021F11
	v_bfe_u32 v16, v15, 16, 1                                  // 0000003FA410: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003FA418: BF870001
	v_add3_u32 v15, v15, v16, 0x7fff                           // 0000003FA41C: D655000F 03FE210F 00007FFF
	s_cbranch_vccnz 204                                        // 0000003FA428: BFA400CC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x375c>
	v_or_b32_e32 v16, 0x50, v3                                 // 0000003FA42C: 382006FF 00000050
	v_lshrrev_b32_e32 v17, 23, v11                             // 0000003FA434: 32221697
	v_mov_b32_e32 v19, s15                                     // 0000003FA438: 7E26020F
	v_mov_b32_e32 v21, s14                                     // 0000003FA43C: 7E2A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA440: BF870093
	v_add_nc_u32_e32 v17, v16, v17                             // 0000003FA444: 4A222310
	v_and_b32_e32 v18, 0xfffffe00, v17                         // 0000003FA448: 362422FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA450: BF870091
	v_sub_nc_u32_e32 v18, v16, v18                             // 0000003FA454: 4C242510
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v18                        // 0000003FA458: 7C8824FF 00000100
	v_add_nc_u32_e32 v20, 0xffffff00, v18                      // 0000003FA460: 4A2824FF FFFFFF00
	v_cndmask_b32_e32 v22, s25, v19, vcc_lo                    // 0000003FA468: 022C2619
	v_ashrrev_i32_e32 v17, 9, v17                              // 0000003FA46C: 34222289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003FA470: BF8701A3
	v_cndmask_b32_e32 v18, v20, v18, vcc_lo                    // 0000003FA474: 02242514
	v_cndmask_b32_e32 v20, s24, v21, vcc_lo                    // 0000003FA478: 02282A18
	v_lshlrev_b32_e32 v16, 8, v17                              // 0000003FA47C: 30202288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003FA480: BF870193
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000003FA484: 3426249F
	.long 0xd7006a14                                           // 0000003FA488: D7006A14
	v_cndmask_b32_e32 v1, v20, v4, vcc_lo                      // 0000003FA48C: 02020914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003FA490: BF870211
	v_add_co_ci_u32_e64 v21, null, v22, v5, vcc_lo             // 0000003FA494: D5207C15 01AA0B16
	v_ashrrev_i32_e32 v17, 31, v16                             // 0000003FA49C: 3422209F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003FA4A0: BF870114
	.long 0xd73c0012                                           // 0000003FA4A4: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000003FA4A8: 02022481
	.long 0xd73c0010                                           // 0000003FA4AC: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000003FA4B0: 02022081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA4B4: BF870091
	.long 0xd7006a10                                           // 0000003FA4B8: D7006A10
	v_cndmask_b32_e32 v1, v20, v16, vcc_lo                     // 0000003FA4BC: 02022114
	v_add_co_ci_u32_e64 v17, null, v21, v17, vcc_lo            // 0000003FA4C0: D5207C11 01AA2315
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA4C8: BF870092
	.long 0xd7006a10                                           // 0000003FA4CC: D7006A10
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 0000003FA4D0: 02022510
	v_add_co_ci_u32_e64 v17, null, v17, v19, vcc_lo            // 0000003FA4D4: D5207C11 01AA2711
	global_store_d16_hi_b16 v[16:17], v15, off                 // 0000003FA4DC: DC960000 007C0F10
	s_cbranch_execnz 7                                         // 0000003FA4E4: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3504>
	.long 0xd7006a10                                           // 0000003FA4E8: D7006A10
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003FA4EC: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003FA4F0: BF870001
	v_add_co_ci_u32_e64 v17, null, v8, v2, vcc_lo              // 0000003FA4F4: D5207C11 01AA0508
	global_store_d16_hi_b16 v[16:17], v15, off offset:160      // 0000003FA4FC: DC9600A0 007C0F10
	global_load_d16_b16 v15, v[6:7], off offset:192            // 0000003FA504: DC8200C0 0F7C0006
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 0000003FA50C: D501000C 2002190C
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003FA514: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003FA518: BF8700A2
	v_add_f32_e32 v12, v12, v13                                // 0000003FA51C: 06181B0C
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003FA520: 8B6A6A7E
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 0000003FA524: 101818FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003FA52C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA530: BF870091
	v_fma_mix_f32 v12, v15, v12, neg(0) op_sel_hi:[1,0,0]      // 0000003FA534: CC20000C 8A02190F
	v_bfe_u32 v13, v12, 16, 1                                  // 0000003FA53C: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003FA544: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 0000003FA548: D655000C 03FE1B0C 00007FFF
	s_cbranch_vccnz 130                                        // 0000003FA554: BFA40082 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3760>
	v_or_b32_e32 v13, 0x60, v3                                 // 0000003FA558: 381A06FF 00000060
	v_lshrrev_b32_e32 v15, 23, v11                             // 0000003FA560: 321E1697
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA564: BF870091
	v_dual_mov_b32 v18, s14 :: v_dual_add_nc_u32 v15, v13, v15 // 0000003FA568: CA20000E 120E1F0D
	v_and_b32_e32 v16, 0xfffffe00, v15                         // 0000003FA570: 36201EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003FA578: BF8701B1
	v_sub_nc_u32_e32 v13, v13, v16                             // 0000003FA57C: 4C1A210D
	v_mov_b32_e32 v16, s15                                     // 0000003FA580: 7E20020F
	v_ashrrev_i32_e32 v15, 9, v15                              // 0000003FA584: 341E1E89
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v13                        // 0000003FA588: 7C881AFF 00000100
	v_add_nc_u32_e32 v17, 0xffffff00, v13                      // 0000003FA590: 4A221AFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003FA598: BF8701A3
	v_lshlrev_b32_e32 v15, 8, v15                              // 0000003FA59C: 301E1E88
	v_cndmask_b32_e32 v19, s25, v16, vcc_lo                    // 0000003FA5A0: 02262019
	v_cndmask_b32_e32 v17, v17, v13, vcc_lo                    // 0000003FA5A4: 02221B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003FA5A8: BF8701A3
	v_ashrrev_i32_e32 v16, 31, v15                             // 0000003FA5AC: 34201E9F
	v_cndmask_b32_e32 v13, s24, v18, vcc_lo                    // 0000003FA5B0: 021A2418
	v_ashrrev_i32_e32 v18, 31, v17                             // 0000003FA5B4: 3424229F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003FA5B8: BF870193
	.long 0xd73c000f                                           // 0000003FA5BC: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000003FA5C0: 02021E81
	.long 0xd7006a0d                                           // 0000003FA5C4: D7006A0D
	v_cndmask_b32_e32 v1, v13, v4, vcc_lo                      // 0000003FA5C8: 0202090D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003FA5CC: BF870211
	v_add_co_ci_u32_e64 v19, null, v19, v5, vcc_lo             // 0000003FA5D0: D5207C13 01AA0B13
	.long 0xd73c0011                                           // 0000003FA5D8: D73C0011
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 0000003FA5DC: 02022281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA5E0: BF870093
	.long 0xd7006a0d                                           // 0000003FA5E4: D7006A0D
	v_cndmask_b32_e32 v1, v13, v15, vcc_lo                     // 0000003FA5E8: 02021F0D
	v_add_co_ci_u32_e64 v16, null, v19, v16, vcc_lo            // 0000003FA5EC: D5207C10 01AA2113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA5F4: BF870092
	.long 0xd7006a0f                                           // 0000003FA5F8: D7006A0F
	v_cndmask_b32_e32 v1, v13, v17, vcc_lo                     // 0000003FA5FC: 0202230D
	v_add_co_ci_u32_e64 v16, null, v16, v18, vcc_lo            // 0000003FA600: D5207C10 01AA2510
	global_store_d16_hi_b16 v[15:16], v12, off                 // 0000003FA608: DC960000 007C0C0F
	s_cbranch_execnz 7                                         // 0000003FA610: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3630>
	.long 0xd7006a0f                                           // 0000003FA614: D7006A0F
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003FA618: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003FA61C: BF870001
	v_add_co_ci_u32_e64 v16, null, v8, v2, vcc_lo              // 0000003FA620: D5207C10 01AA0508
	global_store_d16_hi_b16 v[15:16], v12, off offset:192      // 0000003FA628: DC9600C0 007C0C0F
	global_load_d16_b16 v6, v[6:7], off offset:224             // 0000003FA630: DC8200E0 067C0006
	v_cndmask_b32_e64 v7, -v9, v9, s0                          // 0000003FA638: D5010007 20021309
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003FA640: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003FA644: BF8700A2
	v_add_f32_e32 v7, v7, v10                                  // 0000003FA648: 060E1507
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003FA64C: 8B6A6A7E
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 0000003FA650: 100E0EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003FA658: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA65C: BF870091
	v_fma_mix_f32 v6, v6, v7, neg(0) op_sel_hi:[1,0,0]         // 0000003FA660: CC200006 8A020F06
	v_bfe_u32 v7, v6, 16, 1                                    // 0000003FA668: D6100007 02052106
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003FA670: BF870001
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000003FA674: D6550006 03FE0F06 00007FFF
	s_cbranch_vccnz 56                                         // 0000003FA680: BFA40038 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3764>
	v_or_b32_e32 v3, 0x70, v3                                  // 0000003FA684: 380606FF 00000070
	v_lshrrev_b32_e32 v7, 23, v11                              // 0000003FA68C: 320E1697
	v_mov_b32_e32 v10, s15                                     // 0000003FA690: 7E14020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA694: BF870092
	v_dual_mov_b32 v12, s14 :: v_dual_add_nc_u32 v7, v3, v7    // 0000003FA698: CA20000E 0C060F03
	v_and_b32_e32 v9, 0xfffffe00, v7                           // 0000003FA6A0: 36120EFF FFFFFE00
	v_ashrrev_i32_e32 v7, 9, v7                                // 0000003FA6A8: 340E0E89
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003FA6AC: BF870112
	v_sub_nc_u32_e32 v3, v3, v9                                // 0000003FA6B0: 4C061303
	v_lshlrev_b32_e32 v9, 8, v7                                // 0000003FA6B4: 30120E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003FA6B8: BF870232
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v3                         // 0000003FA6BC: 7C8806FF 00000100
	v_add_nc_u32_e32 v7, 0xffffff00, v3                        // 0000003FA6C4: 4A0E06FF FFFFFF00
	v_cndmask_b32_e32 v13, s25, v10, vcc_lo                    // 0000003FA6CC: 021A1419
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000003FA6D0: 3414129F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003FA6D4: BF8701A3
	v_cndmask_b32_e32 v11, v7, v3, vcc_lo                      // 0000003FA6D8: 02160707
	v_cndmask_b32_e32 v3, s24, v12, vcc_lo                     // 0000003FA6DC: 02061818
	.long 0xd73c0009                                           // 0000003FA6E0: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000003FA6E4: 02021281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003FA6E8: BF870193
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000003FA6EC: 3418169F
	.long 0xd7006a07                                           // 0000003FA6F0: D7006A07
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 0000003FA6F4: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003FA6F8: BF870191
	v_add_co_ci_u32_e64 v5, null, v13, v5, vcc_lo              // 0000003FA6FC: D5207C05 01AA0B0D
	.long 0xd73c0003                                           // 0000003FA704: D73C0003
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000003FA708: 02021681
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA70C: BF870093
	.long 0xd7006a07                                           // 0000003FA710: D7006A07
	v_cndmask_b32_e32 v1, v7, v9, vcc_lo                       // 0000003FA714: 02021307
	v_add_co_ci_u32_e64 v5, null, v5, v10, vcc_lo              // 0000003FA718: D5207C05 01AA1505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003FA720: BF870092
	.long 0xd7006a03                                           // 0000003FA724: D7006A03
	v_cndmask_b32_e32 v1, v7, v3, vcc_lo                       // 0000003FA728: 02020707
	v_add_co_ci_u32_e64 v4, null, v5, v4, vcc_lo               // 0000003FA72C: D5207C04 01AA0905
	global_store_d16_hi_b16 v[3:4], v6, off                    // 0000003FA734: DC960000 007C0603
	s_cbranch_execnz 62251                                     // 0000003FA73C: BFA6F32B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 8                                                 // 0000003FA740: BFA00008 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3764>
	s_branch 62249                                             // 0000003FA744: BFA0F329 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 65011                                             // 0000003FA748: BFA0FDF3 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2f18>
	s_branch 65085                                             // 0000003FA74C: BFA0FE3D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3044>
	s_branch 65158                                             // 0000003FA750: BFA0FE86 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x316c>
	s_branch 65231                                             // 0000003FA754: BFA0FECF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3294>
	s_branch 65304                                             // 0000003FA758: BFA0FF18 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x33bc>
	s_branch 65378                                             // 0000003FA75C: BFA0FF62 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x34e8>
	s_branch 65452                                             // 0000003FA760: BFA0FFAC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3614>
	.long 0xd7006a00                                           // 0000003FA764: D7006A00
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003FA768: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003FA76C: BF870001
	v_add_co_ci_u32_e64 v1, null, v8, v2, vcc_lo               // 0000003FA770: D5207C01 01AA0508
	global_store_d16_hi_b16 v[0:1], v6, off offset:224         // 0000003FA778: DC9600E0 007C0600
	s_nop 0                                                    // 0000003FA780: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003FA784: BFB60003
	s_endpgm                                                   // 0000003FA788: BFB00000
		...

