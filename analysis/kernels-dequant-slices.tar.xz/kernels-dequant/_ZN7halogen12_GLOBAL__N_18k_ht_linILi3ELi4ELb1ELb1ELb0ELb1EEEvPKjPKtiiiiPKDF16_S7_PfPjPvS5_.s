0000000000508600 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x2                                               // 000000508600: BF850002
	s_load_b128 s[24:27], s[0:1], 0x10                         // 000000508604: F4080600 F8000010
	s_load_b256 s[12:19], s[0:1], 0x20                         // 00000050860C: F40C0300 F8000020
	s_load_b128 s[20:23], s[0:1], 0x40                         // 000000508614: F4080500 F8000040
	s_mov_b32 s10, s3                                          // 00000050861C: BE8A0003
	v_and_b32_e32 v50, 31, v0                                  // 000000508620: 3664009F
	v_lshrrev_b32_e32 v48, 5, v0                               // 000000508624: 32600085
	s_delay_alu instid0(VALU_DEP_2)                            // 000000508628: BF870002
	v_lshlrev_b32_e32 v8, 3, v50                               // 00000050862C: 30106483
	s_waitcnt lgkmcnt(0)                                       // 000000508630: BF89FC07
	s_ashr_i32 s34, s25, 31                                    // 000000508634: 86229F19
	s_mul_i32 s11, s27, s10                                    // 000000508638: 960B0A1B
	s_lshr_b32 s3, s34, 25                                     // 00000050863C: 85039922
	s_add_i32 s4, s11, s27                                     // 000000508640: 81041B0B
	s_add_i32 s3, s25, s3                                      // 000000508644: 81030319
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000508648: BF870499
	s_ashr_i32 s3, s3, 7                                       // 00000050864C: 86038703
	s_min_i32 s3, s3, s4                                       // 000000508650: 89030403
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000508654: BF8704B9
	s_sub_i32 s9, s3, s11                                      // 000000508658: 81890B03
	s_mov_b32 s3, exec_lo                                      // 00000050865C: BE83007E
	s_lshl_b32 s27, s9, 2                                      // 000000508660: 841B8209
	.long 0xd4c3007e                                           // 000000508664: D4C3007E
	v_cndmask_b32_e32 v1, s27, v48, vcc_lo                     // 000000508668: 0202601B
	s_xor_b32 s3, exec_lo, s3                                  // 00000050866C: 8D03037E
	v_lshlrev_b32_e32 v8, 3, v50                               // 000000508670: 30106483
	s_or_saveexec_b32 s35, s3                                  // 000000508674: BEA32203
	s_clause 0x1                                               // 000000508678: BF850001
	s_load_b32 s33, s[0:1], 0x54                               // 00000050867C: F4000840 F8000054
	s_load_b128 s[28:31], s[0:1], null                         // 000000508684: F4080700 F8000000
	v_lshlrev_b32_e32 v49, 2, v50                              // 00000050868C: 30626482
	s_xor_b32 exec_lo, exec_lo, s35                            // 000000508690: 8D7E237E
	s_cbranch_execz 502                                        // 000000508694: BFA501F6 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x870>
	s_add_i32 s36, s24, -1                                     // 000000508698: 8124C118
	s_cmp_lg_u64 s[22:23], 0                                   // 00000050869C: BF118016
	v_and_b32_e32 v1, 1, v0                                    // 0000005086A0: 36020081
	s_cselect_b32 s37, -1, 0                                   // 0000005086A4: 982580C1
	s_abs_i32 s38, s9                                          // 0000005086A8: BEA61509
	v_and_b32_e32 v3, 2, v0                                    // 0000005086AC: 36060082
	s_cvt_f32_u32 s0, s38                                      // 0000005086B0: BE806526
	v_dual_mov_b32 v9, v48 :: v_dual_and_b32 v4, 4, v0         // 0000005086B4: CA240130 09040084
	v_and_b32_e32 v5, 8, v0                                    // 0000005086BC: 360A0088
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005086C0: BF870009
	v_rcp_iflag_f32_e32 v2, s0                                 // 0000005086C4: 7E045600
	v_lshl_or_b32 v6, v48, 8, v8                               // 0000005086C8: D6560006 04211130
	v_add_nc_u32_e32 v7, s11, v48                              // 0000005086D0: 4A0E600B
	s_ashr_i32 s42, s9, 31                                     // 0000005086D4: 862A9F09
	s_sub_i32 s8, 0, s38                                       // 0000005086D8: 81882680
	s_mul_i32 s44, s42, 0x1400                                 // 0000005086DC: 962CFF2A 00001400
	.long 0xd44c0000                                           // 0000005086E4: D44C0000
	v_cndmask_b32_e32 v1, 16, v50, vcc_lo                      // 0000005086E8: 02026490
	.long 0xd44a0001                                           // 0000005086EC: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000005086F0: 02020280
	.long 0xd44a0004                                           // 0000005086F4: D44A0004
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 0000005086F8: 02020880
	.long 0xd44a0005                                           // 0000005086FC: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000508700: 02020A80
	v_readfirstlane_b32 s3, v2                                 // 000000508704: 7E060502
	v_lshl_or_b32 v1, v7, 7, v49                               // 000000508708: D6560001 04C50F07
	v_subrev_nc_u32_e32 v10, s44, v6                           // 000000508710: 4E140C2C
	s_lshl_b32 s6, s9, 7                                       // 000000508714: 84068709
	s_mov_b32 s39, s25                                         // 000000508718: BEA70019
	s_mul_f32 s7, s3, 0x4f7ffffe                               // 00000050871C: A207FF03 4F7FFFFE
	.long 0xd44a0003                                           // 000000508724: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000508728: 02020680
	s_mov_b32 s40, 0                                           // 00000050872C: BEA80080
	s_mov_b32 s41, 0x76543210                                  // 000000508730: BEA900FF 76543210
	s_cvt_u32_f32 s7, s7                                       // 000000508738: BE876707
	s_lshl_b32 s43, s9, 8                                      // 00000050873C: 842B8809
	s_sub_i32 s44, 0, s6                                       // 000000508740: 81AC0680
	s_mov_b32 s46, 0x3db504f3                                  // 000000508744: BEAE00FF 3DB504F3
	s_mul_i32 s8, s8, s7                                       // 00000050874C: 96080708
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000508750: BF870499
	s_mul_hi_u32 s8, s7, s8                                    // 000000508754: 96880807
	s_add_i32 s45, s7, s8                                      // 000000508758: 812D0807
	s_branch 161                                               // 00000050875C: BFA000A1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3e4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000508760: BF870091
	.long 0xd7006a02                                           // 000000508764: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000508768: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 00000050876C: D5207C03 01AA060D
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000508774: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 00000050877C: DC820006 027C0002
	v_add_f32_e32 v3, v16, v14                                 // 000000508784: 06061D10
	s_waitcnt vmcnt(0)                                         // 000000508788: BF8903F7
	v_fma_mix_f32 v5, v15, v2, v13 op_sel_hi:[0,1,0]           // 00000050878C: CC200005 1436050F
	v_sub_f32_e32 v4, v16, v14                                 // 000000508794: 08081D10
	v_fma_mix_f32 v2, -v15, v2, v13 op_sel_hi:[0,1,0]          // 000000508798: CC200002 3436050F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005087A0: BF870121
	v_dual_add_f32 v6, v3, v5 :: v_dual_add_f32 v7, v4, v2     // 0000005087A4: C9080B03 06060504
	v_sub_f32_e32 v2, v4, v2                                   // 0000005087AC: 08040504
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005087B0: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000005087B8: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000005087C0: BF870241
	v_dual_add_f32 v4, v6, v4 :: v_dual_sub_f32 v3, v3, v5     // 0000005087C4: C90A0906 04020B03
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005087CC: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000005087D4: D5010007 20060F07
	.long 0xd72c0006                                           // 0000005087DC: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v12, vcc_lo                  // 0000005087E0: 020218FF 00001400
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005087E8: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000005087F0: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005087F8: BF870004
	v_add_f32_e32 v5, v7, v5                                   // 0000005087FC: 060A0B07
	v_mov_b32_dpp v14, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000508800: 7E1C02FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000508808: D5010002 20060502
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000508810: 7E0E02FA FF016204
	v_add_f32_e32 v3, v3, v13                                  // 000000508818: 06061B03
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 00000050881C: D5010004 200E0904
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000508824: 7E1802FA FF016205
	v_add_f32_e32 v2, v2, v14                                  // 00000050882C: 06041D02
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000508830: D5010005 200E0B05
	v_mov_b32_dpp v13, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000508838: 7E1A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000508840: D5010003 200E0703
	v_add_f32_e32 v4, v4, v7                                   // 000000508848: 06080F04
	v_mov_b32_dpp v14, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000050884C: 7E1C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000508854: D5010002 200E0502
	v_add_f32_e32 v5, v5, v12                                  // 00000050885C: 060A1905
	.long 0xd72c0007                                           // 000000508860: D72C0007
	v_cndmask_b32_e32 v1, s43, v11, vcc_lo                     // 000000508864: 0202162B
	v_add_f32_e32 v3, v3, v13                                  // 000000508868: 06061B03
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000050886C: 7E1602FA FF016404
	v_add_f32_e32 v2, v2, v14                                  // 000000508874: 06041D02
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000508878: D5010004 20120904
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000508880: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000508888: D5010005 20120B05
	v_mov_b32_dpp v13, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000508890: 7E1A02FA FF016403
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000508898: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 0000005088A0: D5010002 20120502
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 0000005088A8: D5010003 20120703
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v5, v5, v12   // 0000005088B0: C9081704 04041905
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005088B8: BF8701A3
	v_dual_add_f32 v2, v2, v14 :: v_dual_add_nc_u32 v9, 8, v9  // 0000005088BC: C9201D02 02081288
	v_sub_nc_u32_e32 v6, v6, v7                                // 0000005088C4: 4C0C0F06
	v_mov_b32_dpp v11, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005088C8: 7E1602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 0000005088D0: D5010004 20160904
	v_add_f32_e32 v3, v3, v13                                  // 0000005088D8: 06061B03
	v_mov_b32_dpp v12, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005088DC: 7E1802FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 0000005088E4: D5010005 20160B05
	v_mov_b32_dpp v14, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005088EC: 7E1C02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 0000005088F4: D5010002 20160502
	v_add_f32_e32 v4, v4, v11                                  // 0000005088FC: 06081704
	v_mov_b32_dpp v13, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000508900: 7E1A02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000508908: D5010003 20160703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000508910: BF870214
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v2, v2, v14   // 000000508914: C9081905 05021D02
	v_mov_b32_e32 v11, v4                                      // 00000050891C: 7E160304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000508920: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000508928: BF870213
	v_dual_add_f32 v3, v3, v13 :: v_dual_mov_b32 v12, v5       // 00000050892C: C9101B03 030C0105
	v_mov_b32_e32 v14, v2                                      // 000000508934: 7E1C0302
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000508938: BF870224
	v_permlanex16_b32 v11, v11, s41, 0xfedcba98                // 00000050893C: D65C000B 03FC530B FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000508948: D5010005 20020B05
	v_mov_b32_e32 v13, v3                                      // 000000508950: 7E1A0303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000508954: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 00000050895C: D5010003 20020703
	v_permlanex16_b32 v12, v12, s41, 0xfedcba98                // 000000508964: D65C000C 03FC530C FEDCBA98
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 000000508970: D65C000E 03FC530E FEDCBA98
	v_add_f32_e32 v4, v4, v11                                  // 00000050897C: 06081704
	v_permlanex16_b32 v13, v13, s41, 0xfedcba98                // 000000508980: D65C000D 03FC530D FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s27, v9                           // 00000050898C: 7C86121B
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_nc_u32 v6, v10, v6// 000000508990: C9201905 05060D0A
	v_add_f32_e32 v7, v2, v14                                  // 000000508998: 060E1D02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000050899C: BF870194
	v_dual_add_f32 v11, v3, v13 :: v_dual_add_nc_u32 v10, 0x800, v10// 0000005089A0: C9201B03 0B0A14FF 00000800
	v_fma_mixhi_f16 v2, v5, s46, 0                             // 0000005089AC: CC220002 02005D05
	v_fma_mixlo_f16 v2, v4, s46, 0                             // 0000005089B4: CC210002 02005D04
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005089BC: BF870214
	v_fma_mixhi_f16 v3, v7, s46, 0                             // 0000005089C0: CC220003 02005D07
	v_fma_mixlo_f16 v3, v11, s46, 0                            // 0000005089C8: CC210003 02005D0B
	s_or_b32 s40, vcc_lo, s40                                  // 0000005089D0: 8C28286A
	ds_store_b64 v6, v[2:3]                                    // 0000005089D4: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 0000005089DC: 917E287E
	s_cbranch_execz 290                                        // 0000005089E0: BFA50122 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x86c>
	.long 0xd72d0002                                           // 0000005089E4: D72D0002
	v_cndmask_b32_e32 v0, v9, v45, vcc_lo                      // 0000005089E8: 02005B09
	s_mov_b32 s6, -1                                           // 0000005089EC: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005089F0: BF870091
	.long 0xd72c0003                                           // 0000005089F4: D72C0003
	v_cndmask_b32_e32 v0, v2, v38, vcc_lo                      // 0000005089F8: 02004D02
	v_sub_nc_u32_e32 v3, v9, v3                                // 0000005089FC: 4C060709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000508A00: BF870121
	v_subrev_nc_u32_e32 v5, s38, v3                            // 000000508A04: 4E0A0626
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000508A08: 7C960626
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000508A0C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000508A14: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000508A18: 02040902
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000508A1C: 7C960626
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000508A20: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000508A24: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000508A28: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s37                        // 000000508A2C: 916A257E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000508A30: BF870091
	v_xor_b32_e32 v12, s42, v2                                 // 000000508A34: 3A18042A
	v_subrev_nc_u32_e32 v11, s42, v12                          // 000000508A38: 4E16182A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000508A3C: BF8700A1
	v_mad_u64_u32 v[6:7], null, s44, v11, v[1:2]               // 000000508A40: D6FE7C06 0406162C
	v_min_i32_e32 v2, s36, v11                                 // 000000508A48: 22041624
	v_mad_i64_i32 v[4:5], null, v2, s39, 0                     // 000000508A4C: D6FF7C04 02004F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000508A54: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000508A58: 340E0C9F
	.long 0xd73c0002                                           // 000000508A5C: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000508A60: 02020C81
	s_cbranch_vccnz 212                                        // 000000508A64: BFA400D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7b8>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000508A68: BF870093
	.long 0xd7006a06                                           // 000000508A6C: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000508A70: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000508A74: D5207C07 01AA0F05
	.long 0x7f3a3880                                           // 000000508A7C: 7F3A3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000508A80: BF870112
	.long 0xd73c0006                                           // 000000508A84: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000508A88: 02020C81
	.long 0x7f40399d                                           // 000000508A8C: 7F40399D
	s_waitcnt lgkmcnt(0)                                       // 000000508A90: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000508A94: BF870092
	.long 0xd7006a0d                                           // 000000508A98: D7006A0D
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000508A9C: 02020C1E
	v_add_co_ci_u32_e64 v14, null, s31, v7, vcc_lo             // 000000508AA0: D5207C0E 01AA0E1F
	.long 0xd7006a06                                           // 000000508AA8: D7006A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 000000508AAC: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 000000508AB0: BF870001
	v_add_co_ci_u32_e64 v7, null, s23, v7, vcc_lo              // 000000508AB4: D5207C07 01AA0E17
	global_load_b64 v[13:14], v[13:14], off                    // 000000508ABC: DC560000 0D7C000D
	.long 0xd7006a0f                                           // 000000508AC4: D7006A0F
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000508AC8: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 000000508ACC: DC560000 067C0006
	v_add_co_ci_u32_e64 v16, null, s13, v3, vcc_lo             // 000000508AD4: D5207C10 01AA060D
	s_clause 0x1                                               // 000000508ADC: BF850001
	global_load_b32 v17, v[15:16], off                         // 000000508AE0: DC520000 117C000F
	global_load_d16_b16 v15, v[15:16], off offset:4            // 000000508AE8: DC820004 0F7C000F
	s_waitcnt vmcnt(3)                                         // 000000508AF0: BF890FF7
	.long 0x7e20390d                                           // 000000508AF4: 7E20390D
	s_waitcnt vmcnt(2)                                         // 000000508AF8: BF890BF7
	v_and_b32_e32 v39, 0xffff0000, v6                          // 000000508AFC: 364E0CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000508B04: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000508B08: BF870093
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000508B0C: 30202090
	v_mul_f32_e32 v20, 0xbfb8aa3b, v16                         // 000000508B10: 102820FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000508B18: BF870291
	v_exp_f32_e32 v20, v20                                     // 000000508B1C: 7E284B14
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_and_b32 v13, 0xffff0000, v13// 000000508B20: C92428F2 140C1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000508B2C: BF870111
	v_mul_f32_e32 v19, 0xbfb8aa3b, v13                         // 000000508B30: 10261AFF BFB8AA3B
	v_div_scale_f32 v24, null, v20, v20, v16                   // 000000508B38: D6FC7C18 04422914
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000508B40: BF8701B2
	v_exp_f32_e32 v19, v19                                     // 000000508B44: 7E264B13
	v_lshlrev_b32_e32 v18, 16, v14                             // 000000508B48: 30241C90
	v_div_scale_f32 v37, s7, v16, v20, v16                     // 000000508B4C: D6FC0725 04422910
	v_rcp_f32_e32 v28, v24                                     // 000000508B54: 7E385518
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000508B58: BF870196
	v_add_f32_e32 v19, 1.0, v19                                // 000000508B5C: 062626F2
	v_mul_f32_e32 v21, 0xbfb8aa3b, v18                         // 000000508B60: 102A24FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000508B68: BF870195
	v_fma_f32 v36, -v24, v28, 1.0                              // 000000508B6C: D6130024 23CA3918
	v_div_scale_f32 v23, null, v19, v19, v13                   // 000000508B74: D6FC7C17 04362713
	s_delay_alu instid0(VALU_DEP_3)                            // 000000508B7C: BF870003
	v_exp_f32_e32 v21, v21                                     // 000000508B80: 7E2A4B15
	v_and_b32_e32 v14, 0xffff0000, v14                         // 000000508B84: 361C1CFF FFFF0000
	v_div_scale_f32 v33, vcc_lo, v13, v19, v13                 // 000000508B8C: D6FC6A21 0436270D
	v_fmac_f32_e32 v28, v36, v28                               // 000000508B94: 56383924
	v_rcp_f32_e32 v26, v23                                     // 000000508B98: 7E345517
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000508B9C: BF870186
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_mul_f32 v22, 0xbfb8aa3b, v14// 000000508BA0: C9062AF2 15161CFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000508BAC: BF870115
	v_fma_f32 v34, -v23, v26, 1.0                              // 000000508BB0: D6130022 23CA3517
	v_div_scale_f32 v25, null, v21, v21, v18                   // 000000508BB8: D6FC7C19 044A2B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000508BC0: BF8701A3
	v_exp_f32_e32 v22, v22                                     // 000000508BC4: 7E2C4B16
	v_div_scale_f32 v35, s6, v18, v21, v18                     // 000000508BC8: D6FC0623 044A2B12
	v_fmac_f32_e32 v26, v34, v26                               // 000000508BD0: 56343522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000508BD4: BF870293
	v_rcp_f32_e32 v30, v25                                     // 000000508BD8: 7E3C5519
	v_fma_f32 v38, -v25, v30, 1.0                              // 000000508BDC: D6130026 23CA3D19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000508BE4: BF870191
	v_fmac_f32_e32 v30, v38, v30                               // 000000508BE8: 563C3D26
	v_mul_f32_e32 v38, v33, v26                                // 000000508BEC: 104C3521
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000508BF0: BF870112
	v_mul_f32_e32 v40, v35, v30                                // 000000508BF4: 10503D23
	v_fma_f32 v41, -v23, v38, v33                              // 000000508BF8: D6130029 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000508C00: BF870112
	v_fma_f32 v44, -v25, v40, v35                              // 000000508C04: D613002C 248E5119
	v_fmac_f32_e32 v38, v41, v26                               // 000000508C0C: 564C3529
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000508C10: BF870112
	v_fmac_f32_e32 v40, v44, v30                               // 000000508C14: 56503D2C
	v_fma_f32 v23, -v23, v38, v33                              // 000000508C18: D6130017 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000508C20: BF870112
	v_fma_f32 v25, -v25, v40, v35                              // 000000508C24: D6130019 248E5119
	v_div_fmas_f32 v23, v23, v26, v38                          // 000000508C2C: D6370017 049A3517
	s_mov_b32 vcc_lo, s7                                       // 000000508C34: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000508C38: BF870091
	v_div_fixup_f32 v13, v23, v19, v13                         // 000000508C3C: D627000D 04362717
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_mul_f32 v13, v13, v39// 000000508C44: C9062CF2 160C4F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000508C4C: BF8701A1
	v_div_scale_f32 v27, null, v22, v22, v14                   // 000000508C50: D6FC7C1B 043A2D16
	v_div_scale_f32 v36, s8, v14, v22, v14                     // 000000508C58: D6FC0824 043A2D0E
	.long 0x7e3a398d                                           // 000000508C60: 7E3A398D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000508C64: BF870293
	v_rcp_f32_e32 v31, v27                                     // 000000508C68: 7E3E551B
	v_fma_f32 v34, -v27, v31, 1.0                              // 000000508C6C: D6130022 23CA3F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000508C74: BF870091
	v_dual_fmac_f32 v31, v34, v31 :: v_dual_mul_f32 v34, v37, v28// 000000508C78: C8063F22 1F223925
	v_mul_f32_e32 v42, v36, v31                                // 000000508C80: 10543F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000508C84: BF870112
	v_fma_f32 v43, -v24, v34, v37                              // 000000508C88: D613002B 24964518
	v_fma_f32 v41, -v27, v42, v36                              // 000000508C90: D6130029 2492551B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000508C98: BF870112
	v_fmac_f32_e32 v34, v43, v28                               // 000000508C9C: 5644392B
	v_fmac_f32_e32 v42, v41, v31                               // 000000508CA0: 56543F29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000508CA4: BF870112
	v_fma_f32 v24, -v24, v34, v37                              // 000000508CA8: D6130018 24964518
	v_fma_f32 v23, -v27, v42, v36                              // 000000508CB0: D6130017 2492551B
	s_delay_alu instid0(VALU_DEP_2)                            // 000000508CB8: BF870002
	v_div_fmas_f32 v24, v24, v28, v34                          // 000000508CBC: D6370018 048A3918
	s_mov_b32 vcc_lo, s6                                       // 000000508CC4: BEEA0006
	s_mov_b32 s6, 0                                            // 000000508CC8: BE860080
	v_div_fmas_f32 v19, v25, v30, v40                          // 000000508CCC: D6370013 04A23D19
	s_mov_b32 vcc_lo, s8                                       // 000000508CD4: BEEA0008
	v_div_fixup_f32 v16, v24, v20, v16                         // 000000508CD8: D6270010 04422918
	v_lshlrev_b32_e32 v20, 16, v7                              // 000000508CE0: 30280E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000508CE4: 360E0EFF FFFF0000
	v_div_fixup_f32 v18, v19, v21, v18                         // 000000508CEC: D6270012 044A2B13
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000508CF4: BF8701A4
	v_mul_f32_e32 v6, v16, v6                                  // 000000508CF8: 100C0D10
	v_div_fmas_f32 v16, v23, v31, v42                          // 000000508CFC: D6370010 04AA3F17
	v_mul_f32_e32 v18, v18, v20                                // 000000508D04: 10242912
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000508D08: BF870193
	.long 0x7e403986                                           // 000000508D0C: 7E403986
	v_div_fixup_f32 v14, v16, v22, v14                         // 000000508D10: D627000E 043A2D10
	v_and_b32_e32 v16, 1, v29                                  // 000000508D18: 36203A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000508D1C: BF870194
	v_bfe_u32 v19, v18, 16, 1                                  // 000000508D20: D6100013 02052112
	v_dual_mul_f32 v7, v14, v7 :: v_dual_and_b32 v20, 1, v32   // 000000508D28: C8E40F0E 07144081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000508D30: BF870193
	v_add3_u32 v13, v13, v16, 0x7fff                           // 000000508D34: D655000D 03FE210D 00007FFF
	v_add3_u32 v14, v18, v19, 0x7fff                           // 000000508D40: D655000E 03FE2712 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000508D4C: BF870213
	v_add3_u32 v6, v6, v20, 0x7fff                             // 000000508D50: D6550006 03FE2906 00007FFF
	v_bfe_u32 v16, v7, 16, 1                                   // 000000508D5C: D6100010 02052107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000508D64: BF870214
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000508D68: 361A1AFF FFFF0000
	v_and_b32_e32 v18, 0xffff0000, v14                         // 000000508D70: 36241CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000508D78: BF870214
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000508D7C: 360C0CFF FFFF0000
	v_add3_u32 v7, v7, v16, 0x7fff                             // 000000508D84: D6550007 03FE2107 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000508D90: BF8907F7
	v_fma_mix_f32 v14, v17, v13, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000508D94: CC20080E 8A021B11
	s_waitcnt vmcnt(0)                                         // 000000508D9C: BF8903F7
	v_fma_mix_f32 v13, v15, v18, neg(0) op_sel_hi:[1,0,0]      // 000000508DA0: CC20000D 8A02250F
	v_fma_mix_f32 v16, v17, v6, neg(0) op_sel_hi:[1,0,0]       // 000000508DA8: CC200010 8A020D11
	v_and_b32_e32 v15, 0xffff0000, v7                          // 000000508DB0: 361E0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000508DB8: 916A067E
	s_cbranch_vccnz 65128                                      // 000000508DBC: BFA4FE68 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000508DC0: BF8700A3
	.long 0xd73c0004                                           // 000000508DC4: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000508DC8: 02020881
	s_waitcnt lgkmcnt(0)                                       // 000000508DCC: BF89FC07
	.long 0xd7006a04                                           // 000000508DD0: D7006A04
	v_cndmask_b32_e32 v1, s30, v4, vcc_lo                      // 000000508DD4: 0202081E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000508DD8: BF870111
	v_add_co_ci_u32_e64 v5, null, s31, v5, vcc_lo              // 000000508DDC: D5207C05 01AA0A1F
	.long 0xd7006a04                                           // 000000508DE4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000508DE8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000508DEC: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000508DF0: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000508DF8: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000508DFC: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 000000508E00: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 000000508E08: DC560000 047C0004
	s_clause 0x1                                               // 000000508E10: BF850001
	global_load_b32 v15, v[6:7], off                           // 000000508E14: DC520000 0F7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000508E1C: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000508E24: BF890BF7
	.long 0x7e0e3904                                           // 000000508E28: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000508E2C: 360808FF FFFF0000
	v_lshlrev_b32_e32 v13, 16, v5                              // 000000508E34: 301A0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000508E38: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000508E3C: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000508E40: BF8907F7
	v_fma_mix_f32 v14, v15, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000508E44: CC20080E 8A02090F
	s_waitcnt vmcnt(0)                                         // 000000508E4C: BF8903F7
	v_fma_mix_f32 v13, v6, v13, neg(0) op_sel_hi:[1,0,0]       // 000000508E50: CC20000D 8A021B06
	v_fma_mix_f32 v16, v15, v7, neg(0) op_sel_hi:[1,0,0]       // 000000508E58: CC200010 8A020F0F
	v_and_b32_e32 v15, 0xffff0000, v5                          // 000000508E60: 361E0AFF FFFF0000
	s_branch 65085                                             // 000000508E68: BFA0FE3D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_or_b32 exec_lo, exec_lo, s40                             // 000000508E6C: 8C7E287E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000508E70: BF870009
	s_or_b32 exec_lo, exec_lo, s35                             // 000000508E74: 8C7E237E
	s_bfe_i32 s8, s9, 0x1001c                                  // 000000508E78: 9388FF09 0001001C
	v_mad_u32_u24 v6, v50, 24, 0x2f0                           // 000000508E80: D60B0006 03FD3132 000002F0
	s_lshr_b64 s[0:1], s[8:9], 29                              // 000000508E8C: 85809D08
	s_lshr_b32 s1, s34, 28                                     // 000000508E90: 85019C22
	s_add_i32 s0, s0, 7                                        // 000000508E94: 81008700
	s_add_i32 s1, s25, s1                                      // 000000508E98: 81010119
	s_ashr_i32 s0, s0, 3                                       // 000000508E9C: 86008300
	v_lshrrev_b32_e32 v1, 5, v6                                // 000000508EA0: 32020C85
	.long 0xd72c0005                                           // 000000508EA4: D72C0005
	v_cndmask_b32_e32 v1, s0, v48, vcc_lo                      // 000000508EA8: 02026000
	s_ashr_i32 s1, s1, 4                                       // 000000508EAC: 86018401
	s_lshl_b32 s3, s9, 3                                       // 000000508EB0: 84038309
	s_lshl_b32 s4, s11, 3                                      // 000000508EB4: 8404830B
	s_mul_hi_i32 s6, s1, s2                                    // 000000508EB8: 97060201
	s_mul_i32 s1, s1, s2                                       // 000000508EBC: 96010201
	s_ashr_i32 s5, s4, 31                                      // 000000508EC0: 86059F04
	v_cmp_eq_u32_e32 vcc_lo, 0, v50                            // 000000508EC4: 7C946480
	v_add_nc_u32_e32 v2, s0, v5                                // 000000508EC8: 4A040A00
	s_add_u32 s0, s1, s4                                       // 000000508ECC: 80000401
	s_addc_u32 s1, s6, s5                                      // 000000508ED0: 82010506
	s_mul_i32 s4, s0, 0x300                                    // 000000508ED4: 9604FF00 00000300
	s_mulk_i32 s1, 0x300                                       // 000000508EDC: B8010300
	v_min_i32_e32 v51, s3, v2                                  // 000000508EE0: 22660403
	v_subrev_nc_u32_e32 v2, 24, v1                             // 000000508EE4: 4E040298
	v_add_nc_u32_e32 v1, 1, v5                                 // 000000508EE8: 4A020A81
	s_mul_hi_u32 s3, s0, 0x300                                 // 000000508EEC: 9683FF00 00000300
	v_add_nc_u32_e32 v7, 8, v6                                 // 000000508EF4: 4A0E0C88
	s_add_i32 s3, s3, s1                                       // 000000508EF8: 81030103
	v_cndmask_b32_e64 v3, v2, 23, vcc_lo                       // 000000508EFC: D5010003 01A92F02
	.long 0xd4410000                                           // 000000508F04: D4410000
	v_cndmask_b32_e32 v1, v1, v51, vcc_lo                      // 000000508F08: 02026701
	s_waitcnt lgkmcnt(0)                                       // 000000508F0C: BF89FC07
	s_add_u32 s4, s28, s4                                      // 000000508F10: 8004041C
	s_addc_u32 s5, s29, s3                                     // 000000508F14: 8205031D
	s_barrier                                                  // 000000508F18: BFBD0000
	buffer_gl0_inv                                             // 000000508F1C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000508F24: BE812000
	s_cbranch_execz 120                                        // 000000508F28: BFA50078 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb0c>
	v_lshrrev_b32_e32 v2, 5, v7                                // 000000508F2C: 32040E85
	.long 0xd4440000                                           // 000000508F30: D4440000
	v_cndmask_b32_e32 v1, 23, v3, vcc_lo                       // 000000508F34: 02020697
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000508F38: BF870112
	v_subrev_nc_u32_e32 v2, 24, v2                             // 000000508F3C: 4E040498
	v_cndmask_b32_e64 v4, 0xe9, 1, s0                          // 000000508F40: D5010004 000102FF 000000E9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000508F4C: BF870112
	v_cndmask_b32_e64 v9, v2, 23, vcc_lo                       // 000000508F50: D5010009 01A92F02
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v13, v4, v3      // 000000508F58: CA200080 040C0704
	v_mad_i64_i32 v[1:2], null, 0x300, v1, s[4:5]              // 000000508F60: D6FF7C01 001202FF 00000300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000508F6C: BF870193
	.long 0xd4440000                                           // 000000508F70: D4440000
	v_cndmask_b32_e32 v1, 23, v9, vcc_lo                       // 000000508F74: 02021297
	v_lshlrev_b32_e32 v14, 24, v13                             // 000000508F78: 301C1A98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000508F7C: BF870194
	.long 0xd73c000b                                           // 000000508F80: D73C000B
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000508F84: 02020682
	v_cndmask_b32_e64 v15, 0xe9, 1, s0                         // 000000508F88: D501000F 000102FF 000000E9
	v_mov_b32_e32 v10, v4                                      // 000000508F94: 7E140304
	v_bfe_i32 v4, v13, 7, 1                                    // 000000508F98: D6110004 02050F0D
	v_ashrrev_i32_e32 v13, 22, v14                             // 000000508FA0: 341A1C96
	.long 0xd700000b                                           // 000000508FA4: D700000B
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 000000508FA8: 02021701
	v_add_nc_u32_e32 v15, v15, v9                              // 000000508FAC: 4A1E130F
	.long 0xd73c0009                                           // 000000508FB0: D73C0009
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000508FB4: 02021282
	v_add_co_ci_u32_e64 v12, null, v2, v12, s0                 // 000000508FB8: D5207C0C 00021902
	.long 0xd700000d                                           // 000000508FC0: D700000D
	v_cndmask_b32_e32 v1, v1, v13, vcc_lo                      // 000000508FC4: 02021B01
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000508FC8: BF870244
	v_lshlrev_b32_e32 v16, 24, v15                             // 000000508FCC: 30201E98
	v_add_co_ci_u32_e64 v14, null, v2, v4, s0                  // 000000508FD0: D5207C0E 00020902
	v_bfe_i32 v4, v15, 7, 1                                    // 000000508FD8: D6110004 02050F0F
	.long 0xd7000009                                           // 000000508FE0: D7000009
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 000000508FE4: 02021301
	v_ashrrev_i32_e32 v15, 22, v16                             // 000000508FE8: 341E2096
	v_add_co_ci_u32_e64 v10, null, v2, v10, s0                 // 000000508FEC: D5207C0A 00021502
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000508FF4: BF870092
	.long 0xd7000001                                           // 000000508FF8: D7000001
	v_cndmask_b32_e32 v1, v1, v15, vcc_lo                      // 000000508FFC: 02021F01
	v_add_co_ci_u32_e64 v2, null, v2, v4, s0                   // 000000509000: D5207C02 00020902
	s_clause 0x1f                                              // 000000509008: BF85001F
	global_load_b32 v55, v[11:12], off                         // 00000050900C: DC520000 377C000B
	global_load_b32 v54, v[11:12], off offset:96               // 000000509014: DC520060 367C000B
	global_load_b32 v53, v[11:12], off offset:192              // 00000050901C: DC5200C0 357C000B
	global_load_b32 v52, v[11:12], off offset:288              // 000000509024: DC520120 347C000B
	global_load_b32 v56, v[11:12], off offset:384              // 00000050902C: DC520180 387C000B
	global_load_b32 v57, v[11:12], off offset:480              // 000000509034: DC5201E0 397C000B
	global_load_b32 v58, v[11:12], off offset:576              // 00000050903C: DC520240 3A7C000B
	global_load_b32 v59, v[11:12], off offset:672              // 000000509044: DC5202A0 3B7C000B
	global_load_b32 v64, v[13:14], off                         // 00000050904C: DC520000 407C000D
	global_load_b32 v62, v[13:14], off offset:96               // 000000509054: DC520060 3E7C000D
	global_load_b32 v61, v[13:14], off offset:192              // 00000050905C: DC5200C0 3D7C000D
	global_load_b32 v60, v[13:14], off offset:288              // 000000509064: DC520120 3C7C000D
	global_load_b32 v73, v[13:14], off offset:384              // 00000050906C: DC520180 497C000D
	global_load_b32 v70, v[13:14], off offset:480              // 000000509074: DC5201E0 467C000D
	global_load_b32 v68, v[13:14], off offset:576              // 00000050907C: DC520240 447C000D
	global_load_b32 v66, v[13:14], off offset:672              // 000000509084: DC5202A0 427C000D
	global_load_b32 v71, v[9:10], off                          // 00000050908C: DC520000 477C0009
	global_load_b32 v67, v[9:10], off offset:96                // 000000509094: DC520060 437C0009
	global_load_b32 v65, v[9:10], off offset:192               // 00000050909C: DC5200C0 417C0009
	global_load_b32 v63, v[9:10], off offset:288               // 0000005090A4: DC520120 3F7C0009
	global_load_b32 v79, v[9:10], off offset:384               // 0000005090AC: DC520180 4F7C0009
	global_load_b32 v78, v[9:10], off offset:480               // 0000005090B4: DC5201E0 4E7C0009
	global_load_b32 v77, v[9:10], off offset:576               // 0000005090BC: DC520240 4D7C0009
	global_load_b32 v76, v[9:10], off offset:672               // 0000005090C4: DC5202A0 4C7C0009
	global_load_b32 v75, v[1:2], off                           // 0000005090CC: DC520000 4B7C0001
	global_load_b32 v74, v[1:2], off offset:96                 // 0000005090D4: DC520060 4A7C0001
	global_load_b32 v72, v[1:2], off offset:192                // 0000005090DC: DC5200C0 487C0001
	global_load_b32 v69, v[1:2], off offset:288                // 0000005090E4: DC520120 457C0001
	global_load_b32 v83, v[1:2], off offset:384                // 0000005090EC: DC520180 537C0001
	global_load_b32 v82, v[1:2], off offset:480                // 0000005090F4: DC5201E0 527C0001
	global_load_b32 v81, v[1:2], off offset:576                // 0000005090FC: DC520240 517C0001
	global_load_b32 v80, v[1:2], off offset:672                // 000000509104: DC5202A0 507C0001
	s_or_b32 exec_lo, exec_lo, s1                              // 00000050910C: 8C7E017E
	.long 0xd4410000                                           // 000000509110: D4410000
	v_cndmask_b32_e32 v1, v5, v51, vcc_lo                      // 000000509114: 02026705
	s_and_saveexec_b32 s3, s0                                  // 000000509118: BE832000
	s_cbranch_execz 124                                        // 00000050911C: BFA5007C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xd10>
	v_lshrrev_b32_e32 v1, 5, v7                                // 000000509120: 32020E85
	.long 0xd4440001                                           // 000000509124: D4440001
	v_cndmask_b32_e32 v1, 23, v3, vcc_lo                       // 000000509128: 02020697
	v_mad_i64_i32 v[9:10], null, 0x300, v5, s[4:5]             // 00000050912C: D6FF7C09 00120AFF 00000300
	v_mov_b32_e32 v4, 0                                        // 000000509138: 7E080280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050913C: BF870214
	v_subrev_nc_u32_e32 v1, 24, v1                             // 000000509140: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s1                          // 000000509144: D5010002 000502FF 000000E9
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000509150: BF870193
	.long 0xd73c000b                                           // 000000509154: D73C000B
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000509158: 02020682
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 00000050915C: D5010001 01A92F01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000509164: BF870113
	v_dual_mov_b32 v2, v4 :: v_dual_add_nc_u32 v13, v2, v3     // 000000509168: CA200104 020C0702
	.long 0xd4440001                                           // 000000509170: D4440001
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 000000509174: 02020297
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000509178: BF8701A2
	v_lshlrev_b32_e32 v14, 24, v13                             // 00000050917C: 301C1A98
	v_bfe_i32 v4, v13, 7, 1                                    // 000000509180: D6110004 02050F0D
	v_cndmask_b32_e64 v15, 0xe9, 1, s1                         // 000000509188: D501000F 000502FF 000000E9
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000509194: BF8700A3
	v_ashrrev_i32_e32 v13, 22, v14                             // 000000509198: 341A1C96
	.long 0xd700010b                                           // 00000050919C: D700010B
	v_cndmask_b32_e32 v1, v9, v11, vcc_lo                      // 0000005091A0: 02021709
	v_add_co_ci_u32_e64 v12, null, v10, v12, s1                // 0000005091A4: D5207C0C 0006190A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005091AC: BF870214
	v_add_nc_u32_e32 v14, v15, v1                              // 0000005091B0: 4A1C030F
	.long 0xd700010f                                           // 0000005091B4: D700010F
	v_cndmask_b32_e32 v1, v9, v13, vcc_lo                      // 0000005091B8: 02021B09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005091BC: BF870191
	v_add_co_ci_u32_e64 v16, null, v10, v4, s1                 // 0000005091C0: D5207C10 0006090A
	v_lshlrev_b32_e32 v17, 24, v14                             // 0000005091C8: 30221C98
	.long 0xd73c0001                                           // 0000005091CC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000005091D0: 02020282
	v_bfe_i32 v4, v14, 7, 1                                    // 0000005091D4: D6110004 02050F0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005091DC: BF870193
	v_ashrrev_i32_e32 v13, 22, v17                             // 0000005091E0: 341A2296
	.long 0xd7000111                                           // 0000005091E4: D7000111
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 0000005091E8: 02020309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005091EC: BF870191
	v_add_co_ci_u32_e64 v18, null, v10, v2, s1                 // 0000005091F0: D5207C12 0006050A
	.long 0xd7000113                                           // 0000005091F8: D7000113
	v_cndmask_b32_e32 v1, v9, v13, vcc_lo                      // 0000005091FC: 02021B09
	s_delay_alu instid0(VALU_DEP_1)                            // 000000509200: BF870001
	v_add_co_ci_u32_e64 v20, null, v10, v4, s1                 // 000000509204: D5207C14 0006090A
	s_clause 0x1f                                              // 00000050920C: BF85001F
	global_load_b32 v2, v[11:12], off                          // 000000509210: DC520000 027C000B
	global_load_b32 v14, v[11:12], off offset:96               // 000000509218: DC520060 0E7C000B
	global_load_b32 v43, v[11:12], off offset:192              // 000000509220: DC5200C0 2B7C000B
	global_load_b32 v39, v[11:12], off offset:288              // 000000509228: DC520120 277C000B
	global_load_b32 v35, v[11:12], off offset:384              // 000000509230: DC520180 237C000B
	global_load_b32 v31, v[11:12], off offset:480              // 000000509238: DC5201E0 1F7C000B
	global_load_b32 v27, v[11:12], off offset:576              // 000000509240: DC520240 1B7C000B
	global_load_b32 v23, v[11:12], off offset:672              // 000000509248: DC5202A0 177C000B
	global_load_b32 v1, v[15:16], off                          // 000000509250: DC520000 017C000F
	global_load_b32 v13, v[15:16], off offset:96               // 000000509258: DC520060 0D7C000F
	global_load_b32 v42, v[15:16], off offset:192              // 000000509260: DC5200C0 2A7C000F
	global_load_b32 v38, v[15:16], off offset:288              // 000000509268: DC520120 267C000F
	global_load_b32 v34, v[15:16], off offset:384              // 000000509270: DC520180 227C000F
	global_load_b32 v30, v[15:16], off offset:480              // 000000509278: DC5201E0 1E7C000F
	global_load_b32 v26, v[15:16], off offset:576              // 000000509280: DC520240 1A7C000F
	global_load_b32 v22, v[15:16], off offset:672              // 000000509288: DC5202A0 167C000F
	global_load_b32 v10, v[17:18], off                         // 000000509290: DC520000 0A7C0011
	global_load_b32 v47, v[17:18], off offset:96               // 000000509298: DC520060 2F7C0011
	global_load_b32 v45, v[17:18], off offset:192              // 0000005092A0: DC5200C0 2D7C0011
	global_load_b32 v41, v[17:18], off offset:288              // 0000005092A8: DC520120 297C0011
	global_load_b32 v37, v[17:18], off offset:384              // 0000005092B0: DC520180 257C0011
	global_load_b32 v33, v[17:18], off offset:480              // 0000005092B8: DC5201E0 217C0011
	global_load_b32 v29, v[17:18], off offset:576              // 0000005092C0: DC520240 1D7C0011
	global_load_b32 v25, v[17:18], off offset:672              // 0000005092C8: DC5202A0 197C0011
	global_load_b32 v9, v[19:20], off                          // 0000005092D0: DC520000 097C0013
	global_load_b32 v46, v[19:20], off offset:96               // 0000005092D8: DC520060 2E7C0013
	global_load_b32 v44, v[19:20], off offset:192              // 0000005092E0: DC5200C0 2C7C0013
	global_load_b32 v40, v[19:20], off offset:288              // 0000005092E8: DC520120 287C0013
	global_load_b32 v36, v[19:20], off offset:384              // 0000005092F0: DC520180 247C0013
	global_load_b32 v32, v[19:20], off offset:480              // 0000005092F8: DC5201E0 207C0013
	global_load_b32 v28, v[19:20], off offset:576              // 000000509300: DC520240 1C7C0013
	global_load_b32 v24, v[19:20], off offset:672              // 000000509308: DC5202A0 187C0013
	s_or_b32 exec_lo, exec_lo, s3                              // 000000509310: 8C7E037E
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v84, 0             // 000000509314: CA100080 11540080
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v86, 0             // 00000050931C: CA100080 55560080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v88, 0             // 000000509324: CA100080 57580080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v90, 0             // 00000050932C: CA100080 595A0080
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v94, 0             // 000000509334: CA100080 5B5E0080
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v96, 0             // 00000050933C: CA100080 5D600080
	v_dual_mov_b32 v95, 0 :: v_dual_mov_b32 v98, 0             // 000000509344: CA100080 5F620080
	v_dual_mov_b32 v97, 0 :: v_dual_mov_b32 v100, 0            // 00000050934C: CA100080 61640080
	v_dual_mov_b32 v99, 0 :: v_dual_mov_b32 v102, 0            // 000000509354: CA100080 63660080
	v_dual_mov_b32 v103, 0 :: v_dual_mov_b32 v104, 0           // 00000050935C: CA100080 67680080
	v_dual_mov_b32 v105, 0 :: v_dual_mov_b32 v106, 0           // 000000509364: CA100080 696A0080
	v_dual_mov_b32 v108, 0 :: v_dual_mov_b32 v109, 0           // 00000050936C: CA100080 6C6C0080
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v113, 0            // 000000509374: CA100080 5C700080
	v_dual_mov_b32 v112, 0 :: v_dual_mov_b32 v107, 0           // 00000050937C: CA100080 706A0080
	v_dual_mov_b32 v101, 0 :: v_dual_mov_b32 v110, 0           // 000000509384: CA100080 656E0080
	v_dual_mov_b32 v111, 0 :: v_dual_mov_b32 v114, 0           // 00000050938C: CA100080 6F720080
	s_ashr_i32 s3, s2, 31                                      // 000000509394: 86039F02
	s_and_saveexec_b32 s1, s0                                  // 000000509398: BE812000
	s_cbranch_execz 1211                                       // 00000050939C: BFA504BB <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x208c>
	v_lshrrev_b32_e32 v4, 5, v7                                // 0000005093A0: 32080E85
	v_mul_i32_i24_e32 v7, 0xffffffe8, v50                      // 0000005093A4: 120E64FF FFFFFFE8
	v_dual_mov_b32 v12, 23 :: v_dual_and_b32 v11, 0x7e0, v6    // 0000005093AC: CA240097 0C0A0CFF 000007E0
	v_or_b32_e32 v8, 4, v8                                     // 0000005093B8: 38101084
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000005093BC: BF870244
	v_subrev_nc_u32_e32 v15, 24, v4                            // 0000005093C0: 4E1E0898
	.long 0xd7030006                                           // 0000005093C4: D7030006
	v_cndmask_b32_e32 v0, v3, v129, vcc_lo                     // 0000005093C8: 02010303
	v_dual_mov_b32 v17, 0 :: v_dual_add_nc_u32 v116, 2, v5     // 0000005093CC: CA200080 11740A82
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000005093D4: 3408069F
	v_cndmask_b32_e64 v16, v15, 23, vcc_lo                     // 0000005093D8: D5010010 01A92F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000005093E0: BF870233
	v_dual_mov_b32 v84, v17 :: v_dual_and_b32 v15, 16, v0      // 0000005093E4: CA240111 540E0090
	v_add3_u32 v117, v7, v11, 0xfffffd34                       // 0000005093EC: D6550075 03FE1707 FFFFFD34
	v_mad_u32_u24 v11, v8, 3, 0x2f0                            // 0000005093F8: D60B000B 03FD0708 000002F0
	.long 0xd7034006                                           // 000000509404: D7034006
	v_cndmask_b32_e32 v0, v16, v129, vcc_lo                    // 000000509408: 02010310
	v_mul_i32_i24_e32 v20, -3, v8                              // 00000050940C: 122810C3
	.long 0xd7620007                                           // 000000509410: D7620007
	v_cndmask_b32_e32 v1, 0xff, v6, vcc_lo                     // 000000509414: 02020CFF 000000FF
	.long 0x7e10390c                                           // 00000050941C: 7E10390C
	v_lshl_or_b32 v118, v5, 5, v15                             // 000000509420: D6560076 043D0B05
	.long 0xd7621005                                           // 000000509428: D7621005
	v_cndmask_b32_e32 v1, 0xff, v6, vcc_lo                     // 00000050942C: 02020CFF 000000FF
	.long 0xd73c0012                                           // 000000509434: D73C0012
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000509438: 02020682
	v_cmp_gt_u16_e32 vcc_lo, 24, v7                            // 00000050943C: 7C780E98
	.long 0xd7040003                                           // 000000509440: D7040003
	v_cndmask_b32_e32 v1, v3, v8, vcc_lo                       // 000000509444: 02021103
	v_mov_b32_e32 v86, v17                                     // 000000509448: 7EAC0311
	.long 0xd43d0000                                           // 00000050944C: D43D0000
	v_cndmask_b32_e32 v1, 24, v5, vcc_lo                       // 000000509450: 02020A98
	v_and_b32_e32 v5, 0x7e0, v11                               // 000000509454: 360A16FF 000007E0
	v_sub_nc_u32_e32 v115, 0, v51                              // 00000050945C: 4CE66680
	v_cndmask_b16 v3, v3, v6, vcc_lo                           // 000000509460: D65D0003 01AA0D03
	v_mov_b32_e32 v88, v17                                     // 000000509468: 7EB00311
	v_cndmask_b16 v4, 0, v6, s0                                // 00000050946C: D65D1004 00020C80
	v_mov_b32_e32 v85, v17                                     // 000000509474: 7EAA0311
	v_add3_u32 v119, v20, v5, 0xfffffd34                       // 000000509478: D6550077 03FE0B14 FFFFFD34
	v_and_b32_e32 v3, 0xff, v3                                 // 000000509484: 360606FF 000000FF
	.long 0xd73c0014                                           // 00000050948C: D73C0014
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 000000509490: 02022082
	v_dual_mov_b32 v87, v17 :: v_dual_and_b32 v4, 0xff, v4     // 000000509494: CA240111 570408FF 000000FF
	v_mov_b32_e32 v89, v17                                     // 0000005094A0: 7EB20311
	v_mov_b32_e32 v90, v17                                     // 0000005094A4: 7EB40311
	v_lshlrev_b32_e32 v120, 2, v3                              // 0000005094A8: 30F00682
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005094AC: BF870004
	v_lshlrev_b32_e32 v121, 2, v4                              // 0000005094B0: 30F20882
	v_mov_b32_e32 v91, v17                                     // 0000005094B4: 7EB60311
	v_mov_b32_e32 v93, v17                                     // 0000005094B8: 7EBA0311
	v_mov_b32_e32 v94, v17                                     // 0000005094BC: 7EBC0311
	v_mov_b32_e32 v95, v17                                     // 0000005094C0: 7EBE0311
	v_mov_b32_e32 v96, v17                                     // 0000005094C4: 7EC00311
	v_mov_b32_e32 v97, v17                                     // 0000005094C8: 7EC20311
	v_mov_b32_e32 v98, v17                                     // 0000005094CC: 7EC40311
	v_mov_b32_e32 v99, v17                                     // 0000005094D0: 7EC60311
	v_mov_b32_e32 v100, v17                                    // 0000005094D4: 7EC80311
	v_mov_b32_e32 v102, v17                                    // 0000005094D8: 7ECC0311
	v_mov_b32_e32 v103, v17                                    // 0000005094DC: 7ECE0311
	v_mov_b32_e32 v104, v17                                    // 0000005094E0: 7ED00311
	v_mov_b32_e32 v105, v17                                    // 0000005094E4: 7ED20311
	v_mov_b32_e32 v106, v17                                    // 0000005094E8: 7ED40311
	v_mov_b32_e32 v108, v17                                    // 0000005094EC: 7ED80311
	v_mov_b32_e32 v92, v17                                     // 0000005094F0: 7EB80311
	v_mov_b32_e32 v109, v17                                    // 0000005094F4: 7EDA0311
	v_mov_b32_e32 v112, v17                                    // 0000005094F8: 7EE00311
	v_mov_b32_e32 v113, v17                                    // 0000005094FC: 7EE20311
	v_mov_b32_e32 v107, v17                                    // 000000509500: 7ED60311
	v_mov_b32_e32 v101, v17                                    // 000000509504: 7ECA0311
	v_mov_b32_e32 v110, v17                                    // 000000509508: 7EDC0311
	v_mov_b32_e32 v111, v17                                    // 00000050950C: 7EDE0311
	v_mov_b32_e32 v114, v17                                    // 000000509510: 7EE40311
	s_mov_b32 s0, 0                                            // 000000509514: BE800080
	s_movk_i32 s6, 0x1eee                                      // 000000509518: B0061EEE
	s_branch 1000                                              // 00000050951C: BFA003E8 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ec0>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000509520: 8C7E077E
	.long 0xd73d000f                                           // 000000509524: D73D000F
	v_cndmask_b32_e32 v1, v117, v1, vcc_lo                     // 000000509528: 02020375
	.long 0xd73d009a                                           // 00000050952C: D73D009A
	v_cndmask_b32_e32 v1, v119, v9, vcc_lo                     // 000000509530: 02021377
	ds_load_b128 v[5:8], v118                                  // 000000509534: DBFC0000 05000076
	ds_load_b128 v[1:4], v118 offset:5120                      // 00000050953C: DBFC1400 01000076
	ds_load_b128 v[9:12], v118 offset:10240                    // 000000509544: DBFC2800 09000076
	.long 0xd73d002e                                           // 00000050954C: D73D002E
	v_cndmask_b32_e32 v1, v119, v46, vcc_lo                    // 000000509550: 02025D77
	.long 0xd73d002a                                           // 000000509554: D73D002A
	v_cndmask_b32_e32 v1, v117, v42, vcc_lo                    // 000000509558: 02025575
	v_bfe_u32 v16, v15, 9, 16                                  // 00000050955C: D6100010 0241130F
	v_bfe_u32 v155, v15, 6, 16                                 // 000000509564: D610009B 02410D0F
	v_bfe_u32 v156, v15, 3, 16                                 // 00000050956C: D610009C 0241070F
	v_and_b32_e32 v15, 0xffff, v15                             // 000000509574: 361E1EFF 0000FFFF
	v_bfe_u32 v157, v154, 9, 16                                // 00000050957C: D610009D 0241139A
	.long 0xd72c0010                                           // 000000509584: D72C0010
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 000000509588: 020220FF 83DCD12D
	.long 0xd72c009b                                           // 000000509590: D72C009B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v155, vcc_lo             // 000000509594: 020336FF 83DCD12D
	.long 0xd72c009c                                           // 00000050959C: D72C009C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v156, vcc_lo             // 0000005095A0: 020338FF 83DCD12D
	.long 0xd72c000f                                           // 0000005095A8: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 0000005095AC: 02021EFF 83DCD12D
	v_bfe_u32 v158, v154, 6, 16                                // 0000005095B4: D610009E 02410D9A
	v_bfe_u32 v159, v154, 3, 16                                // 0000005095BC: D610009F 0241079A
	.long 0xd72c009d                                           // 0000005095C4: D72C009D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v157, vcc_lo             // 0000005095C8: 02033AFF 83DCD12D
	v_bfe_u32 v161, v46, 9, 16                                 // 0000005095D0: D61000A1 0241132E
	v_sad_u8 v16, v16, 0, 0x6400                               // 0000005095D8: D6220010 03FD0110 00006400
	v_sad_u8 v155, v155, 0, 0x6400                             // 0000005095E4: D622009B 03FD019B 00006400
	v_sad_u8 v156, v156, 0, 0x6400                             // 0000005095F0: D622009C 03FD019C 00006400
	v_sad_u8 v15, v15, 0, 0x6400                               // 0000005095FC: D622000F 03FD010F 00006400
	.long 0xd72c009e                                           // 000000509608: D72C009E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v158, vcc_lo             // 00000050960C: 02033CFF 83DCD12D
	v_and_b32_e32 v16, 0xffff, v16                             // 000000509614: 362020FF 0000FFFF
	.long 0xd72c009f                                           // 00000050961C: D72C009F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v159, vcc_lo             // 000000509620: 02033EFF 83DCD12D
	v_sad_u8 v157, v157, 0, 0x6400                             // 000000509628: D622009D 03FD019D 00006400
	v_lshlrev_b32_e32 v15, 16, v15                             // 000000509634: 301E1E90
	v_bfe_u32 v162, v46, 6, 16                                 // 000000509638: D61000A2 02410D2E
	v_lshl_or_b32 v16, v155, 16, v16                           // 000000509640: D6560010 0441219B
	.long 0xd72c00a1                                           // 000000509648: D72C00A1
	v_cndmask_b32_e32 v1, 0x83dcd12d, v161, vcc_lo             // 00000050964C: 020342FF 83DCD12D
	v_sad_u8 v155, v158, 0, 0x6400                             // 000000509654: D622009B 03FD019E 00006400
	v_and_or_b32 v15, 0xffff, v156, v15                        // 000000509660: D657000F 043F38FF 0000FFFF
	.long 0xd72c00a2                                           // 00000050966C: D72C00A2
	v_cndmask_b32_e32 v1, 0x83dcd12d, v162, vcc_lo             // 000000509670: 020344FF 83DCD12D
	v_pk_fma_f16 v156, v16, s6, 0xc931 op_sel_hi:[1,0,0]       // 000000509678: CC0E009C 0BFC0D10 0000C931
	v_and_b32_e32 v154, 0xffff, v154                           // 000000509684: 373534FF 0000FFFF
	v_sad_u8 v16, v159, 0, 0x6400                              // 00000050968C: D6220010 03FD019F 00006400
	v_pk_fma_f16 v159, v15, s6, 0xc931 op_sel_hi:[1,0,0]       // 000000509698: CC0E009F 0BFC0D0F 0000C931
	v_and_b32_e32 v157, 0xffff, v157                           // 0000005096A4: 373B3AFF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 0000005096AC: BF89FC17
	v_dot2acc_f32_f16 v111, v156, v1                           // 0000005096B0: 04DE039C
	.long 0xd72c009a                                           // 0000005096B4: D72C009A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v154, vcc_lo             // 0000005096B8: 020334FF 83DCD12D
	v_dot2acc_f32_f16 v114, v156, v5                           // 0000005096C0: 04E40B9C
	v_sad_u8 v161, v161, 0, 0x6400                             // 0000005096C4: D62200A1 03FD01A1 00006400
	v_lshl_or_b32 v157, v155, 16, v157                         // 0000005096D0: D656009D 0675219B
	v_dot2acc_f32_f16 v111, v159, v2                           // 0000005096D8: 04DE059F
	v_bfe_u32 v163, v46, 3, 16                                 // 0000005096DC: D61000A3 0241072E
	v_dot2acc_f32_f16 v114, v159, v6                           // 0000005096E4: 04E40D9F
	.long 0xd73d002b                                           // 0000005096E8: D73D002B
	v_cndmask_b32_e32 v1, v119, v44, vcc_lo                    // 0000005096EC: 02025977
	v_sad_u8 v154, v154, 0, 0x6400                             // 0000005096F0: D622009A 03FD019A 00006400
	v_pk_fma_f16 v157, v157, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000005096FC: CC0E009D 0BFC0D9D 0000C931
	v_bfe_u32 v45, v42, 6, 16                                  // 000000509708: D610002D 02410D2A
	.long 0xd73d0026                                           // 000000509710: D73D0026
	v_cndmask_b32_e32 v1, v117, v38, vcc_lo                    // 000000509714: 02024D75
	.long 0xd73d0027                                           // 000000509718: D73D0027
	v_cndmask_b32_e32 v1, v119, v40, vcc_lo                    // 00000050971C: 02025177
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000509720: BF870244
	v_dual_dot2acc_f32_f16 v111, v157, v3 :: v_dual_lshlrev_b32 v158, 16, v154// 000000509724: CB22079D 6F9F3490
	.long 0xd73d009a                                           // 00000050972C: D73D009A
	v_cndmask_b32_e32 v1, v117, v13, vcc_lo                    // 000000509730: 02021B75
	.long 0xd72c002d                                           // 000000509734: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000509738: 02025AFF 83DCD12D
	.long 0xd73d0022                                           // 000000509740: D73D0022
	v_cndmask_b32_e32 v1, v117, v34, vcc_lo                    // 000000509744: 02024575
	v_and_or_b32 v155, 0xffff, v16, v158                       // 000000509748: D657009B 067A20FF 0000FFFF
	ds_load_b128 v[13:16], v118 offset:15360                   // 000000509754: DBFC3C00 0D000076
	v_dot2acc_f32_f16 v114, v157, v7                           // 00000050975C: 04E40F9D
	v_bfe_u32 v158, v154, 9, 16                                // 000000509760: D610009E 0241139A
	.long 0xd73d0023                                           // 000000509768: D73D0023
	v_cndmask_b32_e32 v1, v119, v36, vcc_lo                    // 00000050976C: 02024977
	v_pk_fma_f16 v155, v155, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000509770: CC0E009B 0BFC0D9B 0000C931
	s_waitcnt lgkmcnt(1)                                       // 00000050977C: BF89FC17
	v_dot2acc_f32_f16 v110, v156, v9                           // 000000509780: 04DC139C
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000509784: D622002D 03FD012D 00006400
	.long 0xd72c002f                                           // 000000509790: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v158, vcc_lo             // 000000509794: 02033CFF 83DCD12D
	v_bfe_u32 v158, v154, 6, 16                                // 00000050979C: D610009E 02410D9A
	v_dot2acc_f32_f16 v111, v155, v4                           // 0000005097A4: 04DE099B
	v_dot2acc_f32_f16 v110, v159, v10                          // 0000005097A8: 04DC159F
	v_bfe_u32 v37, v34, 6, 16                                  // 0000005097AC: D6100025 02410D22
	.long 0xd73d001e                                           // 0000005097B4: D73D001E
	v_cndmask_b32_e32 v1, v117, v30, vcc_lo                    // 0000005097B8: 02023D75
	.long 0xd72c009e                                           // 0000005097BC: D72C009E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v158, vcc_lo             // 0000005097C0: 02033CFF 83DCD12D
	.long 0xd73d001f                                           // 0000005097C8: D73D001F
	v_cndmask_b32_e32 v1, v119, v32, vcc_lo                    // 0000005097CC: 02024177
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000005097D0: D622002F 03FD012F 00006400
	.long 0xd72c0025                                           // 0000005097DC: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 0000005097E0: 02024AFF 83DCD12D
	.long 0xd73d001a                                           // 0000005097E8: D73D001A
	v_cndmask_b32_e32 v1, v117, v26, vcc_lo                    // 0000005097EC: 02023575
	v_bfe_u32 v33, v30, 6, 16                                  // 0000005097F0: D6100021 02410D1E
	.long 0xd73d001b                                           // 0000005097F8: D73D001B
	v_cndmask_b32_e32 v1, v119, v28, vcc_lo                    // 0000005097FC: 02023977
	v_and_b32_e32 v47, 0xffff, v47                             // 000000509800: 365E5EFF 0000FFFF
	v_sad_u8 v158, v158, 0, 0x6400                             // 000000509808: D622009E 03FD019E 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000509814: BF89FC07
	v_dual_dot2acc_f32_f16 v101, v156, v13 :: v_dual_dot2acc_f32_f16 v114, v155, v8// 000000509818: CB181B9C 6572119B
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000509820: D6220025 03FD0125 00006400
	.long 0xd72c0021                                           // 00000050982C: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000509830: 020242FF 83DCD12D
	v_lshl_or_b32 v47, v158, 16, v47                           // 000000509838: D656002F 04BD219E
	.long 0xd72c009e                                           // 000000509840: D72C009E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v163, vcc_lo             // 000000509844: 020346FF 83DCD12D
	v_bfe_u32 v29, v26, 6, 16                                  // 00000050984C: D610001D 02410D1A
	.long 0xd73d0016                                           // 000000509854: D73D0016
	v_cndmask_b32_e32 v1, v117, v22, vcc_lo                    // 000000509858: 02022D75
	.long 0xd73d0017                                           // 00000050985C: D73D0017
	v_cndmask_b32_e32 v1, v119, v24, vcc_lo                    // 000000509860: 02023177
	v_pk_fma_f16 v47, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000509864: CC0E002F 0BFC0D2F 0000C931
	v_and_b32_e32 v160, 0xffff, v154                           // 000000509870: 374134FF 0000FFFF
	v_bfe_u32 v154, v154, 3, 16                                // 000000509878: D610009A 0241079A
	v_dot2acc_f32_f16 v110, v157, v11                          // 000000509880: 04DC179D
	v_sad_u8 v158, v158, 0, 0x6400                             // 000000509884: D622009E 03FD019E 00006400
	v_dot2acc_f32_f16 v107, v47, v5                            // 000000509890: 04D60B2F
	.long 0xd72c00a0                                           // 000000509894: D72C00A0
	v_cndmask_b32_e32 v1, 0x83dcd12d, v160, vcc_lo             // 000000509898: 020340FF 83DCD12D
	.long 0xd72c009a                                           // 0000005098A0: D72C009A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v154, vcc_lo             // 0000005098A4: 020334FF 83DCD12D
	v_dot2acc_f32_f16 v113, v47, v1                            // 0000005098AC: 04E2032F
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000005098B0: D6220021 03FD0121 00006400
	.long 0xd72c001d                                           // 0000005098BC: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 0000005098C0: 02023AFF 83DCD12D
	v_bfe_u32 v25, v22, 6, 16                                  // 0000005098C8: D6100019 02410D16
	v_dot2acc_f32_f16 v101, v159, v14                          // 0000005098D0: 04CA1D9F
	v_and_b32_e32 v46, 0xffff, v46                             // 0000005098D4: 365C5CFF 0000FFFF
	v_sad_u8 v160, v160, 0, 0x6400                             // 0000005098DC: D62200A0 03FD01A0 00006400
	v_sad_u8 v154, v154, 0, 0x6400                             // 0000005098E8: D622009A 03FD019A 00006400
	v_bfe_u32 v159, v43, 3, 16                                 // 0000005098F4: D610009F 0241072B
	.long 0xd72c0019                                           // 0000005098FC: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000509900: 020232FF 83DCD12D
	v_sad_u8 v29, v29, 0, 0x6400                               // 000000509908: D622001D 03FD011D 00006400
	v_dual_dot2acc_f32_f16 v101, v157, v15 :: v_dual_lshlrev_b32 v160, 16, v160// 000000509914: CB221F9D 65A14090
	.long 0xd72c002e                                           // 00000050991C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000509920: 02025CFF 83DCD12D
	v_bfe_u32 v157, v43, 9, 16                                 // 000000509928: D610009D 0241132B
	v_dot2acc_f32_f16 v112, v47, v9                            // 000000509930: 04E0132F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000509934: BF870004
	v_and_or_b32 v154, 0xffff, v154, v160                      // 000000509938: D657009A 068334FF 0000FFFF
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000509944: D6220019 03FD0119 00006400
	v_dot2acc_f32_f16 v109, v47, v13                           // 000000509950: 04DA1B2F
	.long 0xd72c009d                                           // 000000509954: D72C009D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v157, vcc_lo             // 000000509958: 02033AFF 83DCD12D
	v_add_nc_u32_e32 v116, 1, v116                             // 000000509960: 4AE8E881
	v_pk_fma_f16 v154, v154, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000509964: CC0E009A 0BFC0D9A 0000C931
	v_and_b32_e32 v160, 0xffff, v161                           // 000000509970: 374142FF 0000FFFF
	v_sad_u8 v161, v162, 0, 0x6400                             // 000000509978: D62200A1 03FD01A2 00006400
	v_dot2acc_f32_f16 v110, v155, v12                          // 000000509984: 04DC199B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000509988: BF870224
	v_dual_dot2acc_f32_f16 v101, v155, v16 :: v_dual_dot2acc_f32_f16 v112, v154, v10// 00000050998C: CB18219B 6570159A
	v_dot2acc_f32_f16 v113, v154, v2                           // 000000509994: 04E2059A
	v_lshl_or_b32 v156, v161, 16, v160                         // 000000509998: D656009C 068121A1
	v_bfe_u32 v155, v42, 9, 16                                 // 0000005099A0: D610009B 0241132A
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000005099A8: D622002E 03FD012E 00006400
	v_dot2acc_f32_f16 v107, v154, v6                           // 0000005099B4: 04D60D9A
	v_sad_u8 v157, v157, 0, 0x6400                             // 0000005099B8: D622009D 03FD019D 00006400
	v_pk_fma_f16 v156, v156, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000005099C4: CC0E009C 0BFC0D9C 0000C931
	.long 0xd72c002c                                           // 0000005099D0: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v155, vcc_lo             // 0000005099D4: 020336FF 83DCD12D
	v_and_b32_e32 v155, 0xffff, v42                            // 0000005099DC: 373654FF 0000FFFF
	v_lshlrev_b32_e32 v46, 16, v46                             // 0000005099E4: 305C5C90
	v_bfe_u32 v42, v42, 3, 16                                  // 0000005099E8: D610002A 0241072A
	v_dot2acc_f32_f16 v113, v156, v3                           // 0000005099F0: 04E2079C
	v_dot2acc_f32_f16 v112, v156, v11                          // 0000005099F4: 04E0179C
	.long 0xd72c009b                                           // 0000005099F8: D72C009B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v155, vcc_lo             // 0000005099FC: 020336FF 83DCD12D
	v_dot2acc_f32_f16 v107, v156, v7                           // 000000509A04: 04D60F9C
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000509A08: D622002C 03FD012C 00006400
	v_and_or_b32 v46, 0xffff, v158, v46                        // 000000509A14: D657002E 04BB3CFF 0000FFFF
	.long 0xd72c002a                                           // 000000509A20: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000509A24: 020254FF 83DCD12D
	v_bfe_u32 v158, v43, 6, 16                                 // 000000509A2C: D610009E 02410D2B
	v_add_nc_u32_e32 v118, 32, v118                            // 000000509A34: 4AECECA0
	v_and_b32_e32 v44, 0xffff, v44                             // 000000509A38: 365858FF 0000FFFF
	v_pk_fma_f16 v46, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000509A40: CC0E002E 0BFC0D2E 0000C931
	v_sad_u8 v155, v155, 0, 0x6400                             // 000000509A4C: D622009B 03FD019B 00006400
	.long 0xd72c009e                                           // 000000509A58: D72C009E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v158, vcc_lo             // 000000509A5C: 02033CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000509A64: BF8701B4
	v_lshl_or_b32 v44, v45, 16, v44                            // 000000509A68: D656002C 04B1212D
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000509A70: D622002A 03FD012A 00006400
	v_dot2acc_f32_f16 v112, v46, v12                           // 000000509A7C: 04E0192E
	v_pk_fma_f16 v44, v44, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000509A80: CC0E002C 0BFC0D2C 0000C931
	v_dot2acc_f32_f16 v113, v46, v4                            // 000000509A8C: 04E2092E
	v_dot2acc_f32_f16 v107, v46, v8                            // 000000509A90: 04D6112E
	v_sad_u8 v158, v158, 0, 0x6400                             // 000000509A94: D622009E 03FD019E 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000509AA0: BF870004
	v_dual_dot2acc_f32_f16 v108, v44, v1 :: v_dual_lshlrev_b32 v45, 16, v155// 000000509AA4: CB22032C 6C2D3690
	v_dot2acc_f32_f16 v92, v44, v5                             // 000000509AAC: 04B80B2C
	.long 0xd72c009b                                           // 000000509AB0: D72C009B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v159, vcc_lo             // 000000509AB4: 02033EFF 83DCD12D
	v_dot2acc_f32_f16 v106, v44, v9                            // 000000509ABC: 04D4132C
	v_dot2acc_f32_f16 v105, v44, v13                           // 000000509AC0: 04D21B2C
	v_and_or_b32 v42, 0xffff, v42, v45                         // 000000509AC4: D657002A 04B654FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000509AD0: BF870241
	v_pk_fma_f16 v42, v42, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000509AD4: CC0E002A 0BFC0D2A 0000C931
	v_and_b32_e32 v43, 0xffff, v43                             // 000000509AE0: 365656FF 0000FFFF
	v_sad_u8 v47, v155, 0, 0x6400                              // 000000509AE8: D622002F 03FD019B 00006400
	v_bfe_u32 v155, v39, 3, 16                                 // 000000509AF4: D610009B 02410727
	v_dual_dot2acc_f32_f16 v92, v42, v6 :: v_dual_and_b32 v157, 0xffff, v157// 000000509AFC: CB240D2A 5C9D3AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000509B08: BF870004
	.long 0xd72c002b                                           // 000000509B0C: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000509B10: 020256FF 83DCD12D
	v_dot2acc_f32_f16 v108, v42, v2                            // 000000509B18: 04D8052A
	v_dot2acc_f32_f16 v106, v42, v10                           // 000000509B1C: 04D4152A
	v_dot2acc_f32_f16 v105, v42, v14                           // 000000509B20: 04D21D2A
	v_lshl_or_b32 v45, v158, 16, v157                          // 000000509B24: D656002D 0675219E
	.long 0xd72c009b                                           // 000000509B2C: D72C009B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v155, vcc_lo             // 000000509B30: 020336FF 83DCD12D
	v_bfe_u32 v42, v34, 9, 16                                  // 000000509B38: D610002A 02411322
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000509B40: D622002B 03FD012B 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000509B4C: BF870004
	v_pk_fma_f16 v45, v45, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000509B50: CC0E002D 0BFC0D2D 0000C931
	v_dot2acc_f32_f16 v109, v154, v14                          // 000000509B5C: 04DA1D9A
	v_bfe_u32 v154, v39, 6, 16                                 // 000000509B60: D610009A 02410D27
	.long 0xd72c0024                                           // 000000509B68: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000509B6C: 020254FF 83DCD12D
	v_lshlrev_b32_e32 v43, 16, v43                             // 000000509B74: 30565690
	v_dot2acc_f32_f16 v108, v45, v3                            // 000000509B78: 04D8072D
	v_dot2acc_f32_f16 v109, v156, v15                          // 000000509B7C: 04DA1F9C
	v_dot2acc_f32_f16 v92, v45, v7                             // 000000509B80: 04B80F2D
	.long 0xd72c009a                                           // 000000509B84: D72C009A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v154, vcc_lo             // 000000509B88: 020334FF 83DCD12D
	v_and_or_b32 v43, 0xffff, v47, v43                         // 000000509B90: D657002B 04AE5EFF 0000FFFF
	v_bfe_u32 v47, v39, 9, 16                                  // 000000509B9C: D610002F 02411327
	v_and_b32_e32 v39, 0xffff, v39                             // 000000509BA4: 364E4EFF 0000FFFF
	v_dual_dot2acc_f32_f16 v109, v46, v16 :: v_dual_dot2acc_f32_f16 v106, v45, v11// 000000509BAC: CB18212E 6D6A172D
	v_bfe_u32 v46, v38, 9, 16                                  // 000000509BB4: D610002E 02411326
	v_pk_fma_f16 v43, v43, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000509BBC: CC0E002B 0BFC0D2B 0000C931
	.long 0xd72c002f                                           // 000000509BC8: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000509BCC: 02025EFF 83DCD12D
	.long 0xd72c0027                                           // 000000509BD4: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000509BD8: 02024EFF 83DCD12D
	v_sad_u8 v44, v154, 0, 0x6400                              // 000000509BE0: D622002C 03FD019A 00006400
	.long 0xd72c0029                                           // 000000509BEC: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000509BF0: 02025CFF 83DCD12D
	v_bfe_u32 v46, v38, 6, 16                                  // 000000509BF8: D610002E 02410D26
	v_dual_dot2acc_f32_f16 v108, v43, v4 :: v_dual_dot2acc_f32_f16 v105, v45, v15// 000000509C00: CB18092B 6C681F2D
	v_dot2acc_f32_f16 v106, v43, v12                           // 000000509C08: 04D4192B
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000509C0C: D622002F 03FD012F 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000509C18: BF870004
	.long 0xd72c002e                                           // 000000509C1C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000509C20: 02025CFF 83DCD12D
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000509C28: D6220027 03FD0127 00006400
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000509C34: D6220029 03FD0129 00006400
	v_dot2acc_f32_f16 v92, v43, v8                             // 000000509C40: 04B8112B
	v_dot2acc_f32_f16 v105, v43, v16                           // 000000509C44: 04D2212B
	v_bfe_u32 v42, v35, 9, 16                                  // 000000509C48: D610002A 02411323
	v_bfe_u32 v43, v35, 6, 16                                  // 000000509C50: D610002B 02410D23
	v_and_b32_e32 v41, 0xffff, v41                             // 000000509C58: 365252FF 0000FFFF
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000509C60: D622002E 03FD012E 00006400
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000509C6C: D6220024 03FD0124 00006400
	.long 0xd72c002a                                           // 000000509C78: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000509C7C: 020254FF 83DCD12D
	.long 0xd72c002b                                           // 000000509C84: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000509C88: 020256FF 83DCD12D
	v_mov_b32_e32 v45, v65                                     // 000000509C90: 7E5A0341
	v_lshl_or_b32 v41, v46, 16, v41                            // 000000509C94: D6560029 04A5212E
	v_sad_u8 v46, v155, 0, 0x6400                              // 000000509C9C: D622002E 03FD019B 00006400
	s_waitcnt vmcnt(13)                                        // 000000509CA8: BF8937F7
	v_dual_mov_b32 v65, v131 :: v_dual_and_b32 v36, 0xffff, v36// 000000509CAC: CA240183 412448FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000509CB8: BF870003
	v_pk_fma_f16 v41, v41, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000509CBC: CC0E0029 0BFC0D29 0000C931
	v_and_b32_e32 v40, 0xffff, v38                             // 000000509CC8: 36504CFF 0000FFFF
	v_bfe_u32 v38, v38, 3, 16                                  // 000000509CD0: D6100026 02410726
	v_lshlrev_b32_e32 v39, 16, v39                             // 000000509CD8: 304E4E90
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000509CDC: D622002A 03FD012A 00006400
	v_dot2acc_f32_f16 v103, v41, v1                            // 000000509CE8: 04CE0329
	.long 0xd72c0028                                           // 000000509CEC: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000509CF0: 020250FF 83DCD12D
	.long 0xd72c0026                                           // 000000509CF8: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000509CFC: 02024CFF 83DCD12D
	v_dot2acc_f32_f16 v104, v41, v5                            // 000000509D04: 04D00B29
	v_and_or_b32 v39, 0xffff, v46, v39                         // 000000509D08: D6570027 049E5CFF 0000FFFF
	v_lshl_or_b32 v36, v37, 16, v36                            // 000000509D14: D6560024 04912125
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000509D1C: D622002B 03FD012B 00006400
	v_mov_b32_e32 v46, v74                                     // 000000509D28: 7E5C034A
	s_waitcnt vmcnt(6)                                         // 000000509D2C: BF891BF7
	v_mov_b32_e32 v74, v136                                    // 000000509D30: 7E940388
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000509D34: D6220028 03FD0128 00006400
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000509D40: D6220026 03FD0126 00006400
	v_pk_fma_f16 v39, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000509D4C: CC0E0027 0BFC0D27 0000C931
	v_pk_fma_f16 v36, v36, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000509D58: CC0E0024 0BFC0D24 0000C931
	v_and_b32_e32 v42, 0xffff, v42                             // 000000509D64: 365454FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000509D6C: BF870122
	v_dual_dot2acc_f32_f16 v99, v36, v5 :: v_dual_lshlrev_b32 v40, 16, v40// 000000509D70: CB220B24 63285090
	v_dot2acc_f32_f16 v97, v36, v9                             // 000000509D78: 04C21324
	v_and_or_b32 v38, 0xffff, v38, v40                         // 000000509D7C: D6570026 04A24CFF 0000FFFF
	v_dot2acc_f32_f16 v96, v36, v13                            // 000000509D88: 04C01B24
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000509D8C: BF8701B2
	v_pk_fma_f16 v38, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000509D90: CC0E0026 0BFC0D26 0000C931
	v_dual_mov_b32 v47, v67 :: v_dual_and_b32 v40, 0xffff, v47 // 000000509D9C: CA240143 2F285EFF 0000FFFF
	v_mov_b32_e32 v67, v132                                    // 000000509DA8: 7E860384
	v_dot2acc_f32_f16 v103, v38, v2                            // 000000509DAC: 04CE0526
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000509DB0: BF870243
	v_lshl_or_b32 v40, v44, 16, v40                            // 000000509DB4: D6560028 04A1212C
	v_dot2acc_f32_f16 v104, v38, v6                            // 000000509DBC: 04D00D26
	v_bfe_u32 v44, v35, 3, 16                                  // 000000509DC0: D610002C 02410723
	v_and_b32_e32 v35, 0xffff, v35                             // 000000509DC8: 364646FF 0000FFFF
	v_pk_fma_f16 v40, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000509DD0: CC0E0028 0BFC0D28 0000C931
	v_dot2acc_f32_f16 v102, v41, v9                            // 000000509DDC: 04CC1329
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000509DE0: BF870193
	.long 0xd72c0023                                           // 000000509DE4: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000509DE8: 020246FF 83DCD12D
	v_dot2acc_f32_f16 v104, v40, v7                            // 000000509DF0: 04D00F28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000509DF4: BF870113
	v_dual_dot2acc_f32_f16 v103, v40, v3 :: v_dual_dot2acc_f32_f16 v102, v38, v10// 000000509DF8: CB180728 67661526
	v_dot2acc_f32_f16 v104, v39, v8                            // 000000509E00: 04D01127
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000509E04: BF8701C4
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000509E08: D6220023 03FD0123 00006400
	v_dual_dot2acc_f32_f16 v100, v41, v13 :: v_dual_and_b32 v41, 0xffff, v34// 000000509E14: CB241B29 642844FF 0000FFFF
	v_bfe_u32 v34, v34, 3, 16                                  // 000000509E20: D6100022 02410722
	v_dot2acc_f32_f16 v103, v39, v4                            // 000000509E28: 04CE0927
	v_dual_dot2acc_f32_f16 v100, v38, v14 :: v_dual_lshlrev_b32 v35, 16, v35// 000000509E2C: CB221D26 64224690
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000509E34: BF870214
	.long 0xd72c0029                                           // 000000509E38: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 000000509E3C: 020252FF 83DCD12D
	.long 0xd72c0022                                           // 000000509E44: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000509E48: 020244FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000509E50: BF8701A2
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000509E54: D6220029 03FD0129 00006400
	v_dot2acc_f32_f16 v102, v40, v11                           // 000000509E60: 04CC1728
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000509E64: D6220022 03FD0122 00006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000509E70: BF870003
	v_lshlrev_b32_e32 v37, 16, v41                             // 000000509E74: 304A5290
	.long 0xd72c0029                                           // 000000509E78: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000509E7C: 020258FF 83DCD12D
	v_mov_b32_e32 v44, v72                                     // 000000509E84: 7E580348
	s_waitcnt vmcnt(5)                                         // 000000509E88: BF8917F7
	v_mov_b32_e32 v72, v135                                    // 000000509E8C: 7E900387
	v_and_or_b32 v34, 0xffff, v34, v37                         // 000000509E90: D6570022 049644FF 0000FFFF
	v_lshl_or_b32 v37, v43, 16, v42                            // 000000509E9C: D6560025 04A9212B
	v_mov_b32_e32 v42, v61                                     // 000000509EA4: 7E54033D
	v_mov_b32_e32 v43, v53                                     // 000000509EA8: 7E560335
	v_sad_u8 v38, v41, 0, 0x6400                               // 000000509EAC: D6220026 03FD0129 00006400
	v_pk_fma_f16 v34, v34, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000509EB8: CC0E0022 0BFC0D22 0000C931
	v_dot2acc_f32_f16 v98, v36, v1                             // 000000509EC4: 04C40324
	v_pk_fma_f16 v37, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000509EC8: CC0E0025 0BFC0D25 0000C931
	v_mov_b32_e32 v41, v63                                     // 000000509ED4: 7E52033F
	v_and_or_b32 v35, 0xffff, v38, v35                         // 000000509ED8: D6570023 048E4CFF 0000FFFF
	v_dot2acc_f32_f16 v99, v34, v6                             // 000000509EE4: 04C60D22
	v_dot2acc_f32_f16 v97, v34, v10                            // 000000509EE8: 04C21522
	v_dot2acc_f32_f16 v98, v34, v2                             // 000000509EEC: 04C40522
	v_dot2acc_f32_f16 v102, v39, v12                           // 000000509EF0: 04CC1927
	v_pk_fma_f16 v35, v35, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000509EF4: CC0E0023 0BFC0D23 0000C931
	v_dot2acc_f32_f16 v99, v37, v7                             // 000000509F00: 04C60F25
	v_dot2acc_f32_f16 v100, v40, v15                           // 000000509F04: 04C81F28
	v_bfe_u32 v38, v30, 9, 16                                  // 000000509F08: D6100026 0241131E
	v_dot2acc_f32_f16 v97, v37, v11                            // 000000509F10: 04C21725
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000509F14: BF870214
	v_dual_dot2acc_f32_f16 v98, v37, v3 :: v_dual_dot2acc_f32_f16 v99, v35, v8// 000000509F18: CB180725 62621123
	v_dual_dot2acc_f32_f16 v100, v39, v16 :: v_dual_and_b32 v39, 0xffff, v30// 000000509F20: CB242127 64263CFF 0000FFFF
	v_bfe_u32 v30, v30, 3, 16                                  // 000000509F2C: D610001E 0241071E
	.long 0xd72c0020                                           // 000000509F34: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000509F38: 02024CFF 83DCD12D
	v_dot2acc_f32_f16 v97, v35, v12                            // 000000509F40: 04C21923
	v_dot2acc_f32_f16 v98, v35, v4                             // 000000509F44: 04C40923
	.long 0xd72c0024                                           // 000000509F48: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000509F4C: 02024EFF 83DCD12D
	.long 0xd72c001e                                           // 000000509F54: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 000000509F58: 02023CFF 83DCD12D
	v_bfe_u32 v38, v31, 9, 16                                  // 000000509F60: D6100026 0241131F
	v_bfe_u32 v39, v31, 6, 16                                  // 000000509F68: D6100027 02410D1F
	v_bfe_u32 v40, v31, 3, 16                                  // 000000509F70: D6100028 0241071F
	v_sad_u8 v32, v32, 0, 0x6400                               // 000000509F78: D6220020 03FD0120 00006400
	v_and_b32_e32 v31, 0xffff, v31                             // 000000509F84: 363E3EFF 0000FFFF
	.long 0xd72c0026                                           // 000000509F8C: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000509F90: 02024CFF 83DCD12D
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000509F98: D6220024 03FD0124 00006400
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000509FA4: D622001E 03FD011E 00006400
	.long 0xd72c0027                                           // 000000509FB0: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000509FB4: 02024EFF 83DCD12D
	.long 0xd72c001f                                           // 000000509FBC: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000509FC0: 02023EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000509FC8: BF870244
	v_dual_mov_b32 v63, v129 :: v_dual_lshlrev_b32 v36, 16, v36// 000000509FCC: CA220181 3F244890
	v_mov_b32_e32 v61, v127                                    // 000000509FD4: 7E7A037F
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000509FD8: D6220026 03FD0126 00006400
	v_mov_b32_e32 v53, v123                                    // 000000509FE4: 7E6A037B
	v_and_or_b32 v30, 0xffff, v30, v36                         // 000000509FE8: D657001E 04923CFF 0000FFFF
	v_sad_u8 v31, v31, 0, 0x6400                               // 000000509FF4: D622001F 03FD011F 00006400
	v_sad_u8 v36, v39, 0, 0x6400                               // 00000050A000: D6220024 03FD0127 00006400
	v_dual_mov_b32 v39, v52 :: v_dual_mov_b32 v52, v122        // 00000050A00C: CA100134 2734017A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000050A014: BF870134
	v_pk_fma_f16 v30, v30, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050A018: CC0E001E 0BFC0D1E 0000C931
	v_and_b32_e32 v32, 0xffff, v32                             // 00000050A024: 364040FF 0000FFFF
	v_lshlrev_b32_e32 v31, 16, v31                             // 00000050A02C: 303E3E90
	v_lshl_or_b32 v32, v33, 16, v32                            // 00000050A030: D6560020 04812121
	.long 0xd72c0021                                           // 00000050A038: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 00000050A03C: 020250FF 83DCD12D
	v_mov_b32_e32 v40, v69                                     // 00000050A044: 7E500345
	s_waitcnt vmcnt(4)                                         // 00000050A048: BF8913F7
	v_mov_b32_e32 v69, v133                                    // 00000050A04C: 7E8A0385
	v_pk_fma_f16 v32, v32, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050A050: CC0E0020 0BFC0D20 0000C931
	v_dot2acc_f32_f16 v96, v34, v14                            // 00000050A05C: 04C01D22
	v_sad_u8 v33, v33, 0, 0x6400                               // 00000050A060: D6220021 03FD0121 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000050A06C: BF870193
	v_dot2acc_f32_f16 v95, v32, v5                             // 00000050A070: 04BE0B20
	v_dual_dot2acc_f32_f16 v93, v32, v9 :: v_dual_dot2acc_f32_f16 v96, v37, v15// 00000050A074: CB181320 5D601F25
	v_dot2acc_f32_f16 v91, v32, v13                            // 00000050A07C: 04B61B20
	s_delay_alu instid0(VALU_DEP_4)                            // 00000050A080: BF870004
	v_and_or_b32 v31, 0xffff, v33, v31                         // 00000050A084: D657001F 047E42FF 0000FFFF
	v_bfe_u32 v33, v26, 9, 16                                  // 00000050A090: D6100021 0241131A
	v_dot2acc_f32_f16 v95, v30, v6                             // 00000050A098: 04BE0D1E
	v_dot2acc_f32_f16 v93, v30, v10                            // 00000050A09C: 04BA151E
	v_bfe_u32 v37, v27, 3, 16                                  // 00000050A0A0: D6100025 0241071B
	v_pk_fma_f16 v31, v31, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050A0A8: CC0E001F 0BFC0D1F 0000C931
	v_and_b32_e32 v34, 0xffff, v38                             // 00000050A0B4: 36444CFF 0000FFFF
	.long 0xd72c001c                                           // 00000050A0BC: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 00000050A0C0: 020242FF 83DCD12D
	v_and_b32_e32 v33, 0xffff, v26                             // 00000050A0C8: 364234FF 0000FFFF
	v_bfe_u32 v26, v26, 3, 16                                  // 00000050A0D0: D610001A 0241071A
	v_mov_b32_e32 v38, v60                                     // 00000050A0D8: 7E4C033C
	v_lshl_or_b32 v34, v36, 16, v34                            // 00000050A0DC: D6560022 04892124
	v_bfe_u32 v36, v27, 6, 16                                  // 00000050A0E4: D6100024 02410D1B
	.long 0xd72c0021                                           // 00000050A0EC: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 00000050A0F0: 020242FF 83DCD12D
	.long 0xd72c001a                                           // 00000050A0F8: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 00000050A0FC: 020234FF 83DCD12D
	v_sad_u8 v28, v28, 0, 0x6400                               // 00000050A104: D622001C 03FD011C 00006400
	v_pk_fma_f16 v34, v34, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050A110: CC0E0022 0BFC0D22 0000C931
	v_dot2acc_f32_f16 v94, v32, v1                             // 00000050A11C: 04BC0320
	v_dot2acc_f32_f16 v96, v35, v16                            // 00000050A120: 04C02123
	v_bfe_u32 v35, v27, 9, 16                                  // 00000050A124: D6100023 0241131B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000050A12C: BF870234
	v_dual_dot2acc_f32_f16 v95, v34, v7 :: v_dual_and_b32 v28, 0xffff, v28// 00000050A130: CB240F22 5F1C38FF 0000FFFF
	v_dot2acc_f32_f16 v93, v34, v11                            // 00000050A13C: 04BA1722
	v_dot2acc_f32_f16 v94, v30, v2                             // 00000050A140: 04BC051E
	.long 0xd72c0023                                           // 00000050A144: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 00000050A148: 020246FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000050A150: BF870224
	v_lshl_or_b32 v28, v29, 16, v28                            // 00000050A154: D656001C 0471211D
	v_and_b32_e32 v27, 0xffff, v27                             // 00000050A15C: 363636FF 0000FFFF
	v_dual_dot2acc_f32_f16 v93, v31, v12 :: v_dual_dot2acc_f32_f16 v94, v34, v3// 00000050A164: CB18191F 5D5E0722
	v_sad_u8 v33, v33, 0, 0x6400                               // 00000050A16C: D6220021 03FD0121 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050A178: BF870214
	v_pk_fma_f16 v28, v28, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050A17C: CC0E001C 0BFC0D1C 0000C931
	.long 0xd72c001b                                           // 00000050A188: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 00000050A18C: 020236FF 83DCD12D
	v_sad_u8 v35, v35, 0, 0x6400                               // 00000050A194: D6220023 03FD0123 00006400
	v_dot2acc_f32_f16 v94, v31, v4                             // 00000050A1A0: 04BC091F
	.long 0xd72c0024                                           // 00000050A1A4: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 00000050A1A8: 020248FF 83DCD12D
	v_sad_u8 v26, v26, 0, 0x6400                               // 00000050A1B0: D622001A 03FD011A 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000050A1BC: BF870004
	v_dual_dot2acc_f32_f16 v90, v28, v5 :: v_dual_and_b32 v35, 0xffff, v35// 00000050A1C0: CB240B1C 5A2246FF 0000FFFF
	v_lshlrev_b32_e32 v29, 16, v33                             // 00000050A1CC: 303A4290
	.long 0xd72c0021                                           // 00000050A1D0: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 00000050A1D4: 02024AFF 83DCD12D
	v_sad_u8 v27, v27, 0, 0x6400                               // 00000050A1DC: D622001B 03FD011B 00006400
	v_dot2acc_f32_f16 v88, v28, v9                             // 00000050A1E8: 04B0131C
	v_sad_u8 v36, v36, 0, 0x6400                               // 00000050A1EC: D6220024 03FD0124 00006400
	v_and_or_b32 v26, 0xffff, v26, v29                         // 00000050A1F8: D657001A 047634FF 0000FFFF
	v_dot2acc_f32_f16 v87, v28, v13                            // 00000050A204: 04AE1B1C
	v_lshlrev_b32_e32 v27, 16, v27                             // 00000050A208: 30363690
	v_dot2acc_f32_f16 v95, v31, v8                             // 00000050A20C: 04BE111F
	v_lshl_or_b32 v29, v36, 16, v35                            // 00000050A210: D656001D 048D2124
	v_pk_fma_f16 v26, v26, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050A218: CC0E001A 0BFC0D1A 0000C931
	v_dot2acc_f32_f16 v89, v28, v1                             // 00000050A224: 04B2031C
	v_bfe_u32 v28, v22, 9, 16                                  // 00000050A228: D610001C 02411316
	v_sad_u8 v32, v33, 0, 0x6400                               // 00000050A230: D6220020 03FD0121 00006400
	v_pk_fma_f16 v29, v29, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050A23C: CC0E001D 0BFC0D1D 0000C931
	v_dot2acc_f32_f16 v90, v26, v6                             // 00000050A248: 04B40D1A
	v_dot2acc_f32_f16 v91, v30, v14                            // 00000050A24C: 04B61D1E
	.long 0xd72c0018                                           // 00000050A250: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 00000050A254: 020238FF 83DCD12D
	v_bfe_u32 v28, v23, 9, 16                                  // 00000050A25C: D610001C 02411317
	v_and_or_b32 v27, 0xffff, v32, v27                         // 00000050A264: D657001B 046E40FF 0000FFFF
	v_dot2acc_f32_f16 v90, v29, v7                             // 00000050A270: 04B40F1D
	v_dot2acc_f32_f16 v88, v26, v10                            // 00000050A274: 04B0151A
	v_dot2acc_f32_f16 v89, v26, v2                             // 00000050A278: 04B2051A
	.long 0xd72c001c                                           // 00000050A27C: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 00000050A280: 020238FF 83DCD12D
	v_pk_fma_f16 v27, v27, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050A288: CC0E001B 0BFC0D1B 0000C931
	v_dot2acc_f32_f16 v91, v34, v15                            // 00000050A294: 04B61F22
	v_sad_u8 v24, v24, 0, 0x6400                               // 00000050A298: D6220018 03FD0118 00006400
	v_bfe_u32 v30, v23, 6, 16                                  // 00000050A2A4: D610001E 02410D17
	v_dot2acc_f32_f16 v88, v29, v11                            // 00000050A2AC: 04B0171D
	v_dot2acc_f32_f16 v90, v27, v8                             // 00000050A2B0: 04B4111B
	v_dot2acc_f32_f16 v91, v31, v16                            // 00000050A2B4: 04B6211F
	v_and_b32_e32 v24, 0xffff, v24                             // 00000050A2B8: 363030FF 0000FFFF
	v_sad_u8 v28, v28, 0, 0x6400                               // 00000050A2C0: D622001C 03FD011C 00006400
	v_dot2acc_f32_f16 v87, v26, v14                            // 00000050A2CC: 04AE1D1A
	v_and_b32_e32 v26, 0xffff, v22                             // 00000050A2D0: 36342CFF 0000FFFF
	v_bfe_u32 v22, v22, 3, 16                                  // 00000050A2D8: D6100016 02410716
	v_lshl_or_b32 v24, v25, 16, v24                            // 00000050A2E0: D6560018 04612119
	v_bfe_u32 v31, v23, 3, 16                                  // 00000050A2E8: D610001F 02410717
	.long 0xd72c001e                                           // 00000050A2F0: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 00000050A2F4: 02023CFF 83DCD12D
	.long 0xd72c001a                                           // 00000050A2FC: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 00000050A300: 020234FF 83DCD12D
	.long 0xd72c0016                                           // 00000050A308: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 00000050A30C: 02022CFF 83DCD12D
	v_pk_fma_f16 v24, v24, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050A314: CC0E0018 0BFC0D18 0000C931
	v_and_b32_e32 v23, 0xffff, v23                             // 00000050A320: 362E2EFF 0000FFFF
	v_dual_dot2acc_f32_f16 v89, v29, v3 :: v_dual_and_b32 v28, 0xffff, v28// 00000050A328: CB24071D 591C38FF 0000FFFF
	v_dot2acc_f32_f16 v88, v27, v12                            // 00000050A334: 04B0191B
	s_delay_alu instid0(VALU_DEP_4)                            // 00000050A338: BF870004
	v_dot2acc_f32_f16 v84, v24, v9                             // 00000050A33C: 04A81318
	v_sad_u8 v26, v26, 0, 0x6400                               // 00000050A340: D622001A 03FD011A 00006400
	.long 0xd72c0017                                           // 00000050A34C: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 00000050A350: 02022EFF 83DCD12D
	v_sad_u8 v22, v22, 0, 0x6400                               // 00000050A358: D6220016 03FD0116 00006400
	v_sad_u8 v30, v30, 0, 0x6400                               // 00000050A364: D622001E 03FD011E 00006400
	v_dual_dot2acc_f32_f16 v89, v27, v4 :: v_dual_dot2acc_f32_f16 v86, v24, v5// 00000050A370: CB18091B 59560B18
	v_lshlrev_b32_e32 v25, 16, v26                             // 00000050A378: 30323490
	.long 0xd72c001a                                           // 00000050A37C: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 00000050A380: 02023EFF 83DCD12D
	v_dot2acc_f32_f16 v85, v24, v1                             // 00000050A388: 04AA0318
	v_sad_u8 v23, v23, 0, 0x6400                               // 00000050A38C: D6220017 03FD0117 00006400
	v_mov_b32_e32 v9, v75                                      // 00000050A398: 7E12034B
	v_and_or_b32 v22, 0xffff, v22, v25                         // 00000050A39C: D6570016 04662CFF 0000FFFF
	v_lshl_or_b32 v25, v30, 16, v28                            // 00000050A3A8: D6560019 0471211E
	v_dual_mov_b32 v60, v126 :: v_dual_mov_b32 v75, v137       // 00000050A3B0: CA10017E 3C4A0189
	v_mov_b32_e32 v30, v148                                    // 00000050A3B8: 7E3C0394
	v_sad_u8 v26, v26, 0, 0x6400                               // 00000050A3BC: D622001A 03FD011A 00006400
	v_pk_fma_f16 v22, v22, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050A3C8: CC0E0016 0BFC0D16 0000C931
	v_lshlrev_b32_e32 v23, 16, v23                             // 00000050A3D4: 302E2E90
	v_pk_fma_f16 v25, v25, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050A3D8: CC0E0019 0BFC0D19 0000C931
	v_dot2acc_f32_f16 v87, v29, v15                            // 00000050A3E4: 04AE1F1D
	v_dual_mov_b32 v35, v153 :: v_dual_mov_b32 v28, v142       // 00000050A3E8: CA100199 231C018E
	v_dot2acc_f32_f16 v84, v22, v10                            // 00000050A3F0: 04A81516
	v_and_or_b32 v5, 0xffff, v26, v23                          // 00000050A3F4: D6570005 045E34FF 0000FFFF
	v_dual_dot2acc_f32_f16 v17, v24, v13 :: v_dual_dot2acc_f32_f16 v86, v22, v6// 00000050A400: CB181B18 11560D16
	v_dual_dot2acc_f32_f16 v85, v22, v2 :: v_dual_add_nc_u32 v2, v115, v116// 00000050A408: CB200516 5502E973
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000050A410: BF870193
	v_pk_fma_f16 v1, v5, s6, 0xc931 op_sel_hi:[1,0,0]          // 00000050A414: CC0E0001 0BFC0D05 0000C931
	v_dual_dot2acc_f32_f16 v84, v25, v11 :: v_dual_dot2acc_f32_f16 v17, v22, v14// 00000050A420: CB181719 54101D16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050A428: BF870214
	v_dual_dot2acc_f32_f16 v87, v27, v16 :: v_dual_dot2acc_f32_f16 v86, v25, v7// 00000050A42C: CB18211B 57560F19
	v_dot2acc_f32_f16 v85, v25, v3                             // 00000050A434: 04AA0719
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050A438: BF870213
	v_dot2acc_f32_f16 v84, v1, v12                             // 00000050A43C: 04A81901
	v_dot2acc_f32_f16 v17, v25, v15                            // 00000050A440: 04221F19
	v_cmp_eq_u32_e32 vcc_lo, 2, v2                             // 00000050A444: 7C940482
	v_dot2acc_f32_f16 v86, v1, v8                              // 00000050A448: 04AC1101
	v_dot2acc_f32_f16 v85, v1, v4                              // 00000050A44C: 04AA0901
	v_dual_mov_b32 v13, v62 :: v_dual_mov_b32 v2, v55          // 00000050A450: CA10013E 0D020137
	v_dual_dot2acc_f32_f16 v17, v1, v16 :: v_dual_mov_b32 v14, v54// 00000050A458: CB102101 110E0136
	v_dual_mov_b32 v10, v71 :: v_dual_mov_b32 v1, v64          // 00000050A460: CA100147 0A000140
	v_mov_b32_e32 v62, v128                                    // 00000050A468: 7E7C0380
	v_dual_mov_b32 v54, v124 :: v_dual_mov_b32 v71, v134       // 00000050A46C: CA10017C 36460186
	v_mov_b32_e32 v26, v144                                    // 00000050A474: 7E340390
	v_dual_mov_b32 v64, v130 :: v_dual_mov_b32 v55, v125       // 00000050A478: CA100182 4036017D
	v_mov_b32_e32 v32, v146                                    // 00000050A480: 7E400392
	v_dual_mov_b32 v34, v152 :: v_dual_mov_b32 v37, v151       // 00000050A484: CA100198 22240197
	v_mov_b32_e32 v22, v140                                    // 00000050A48C: 7E2C038C
	v_dual_mov_b32 v36, v150 :: v_dual_mov_b32 v31, v149       // 00000050A490: CA100196 241E0195
	v_dual_mov_b32 v24, v138 :: v_dual_mov_b32 v33, v147       // 00000050A498: CA10018A 18200193
	v_mov_b32_e32 v27, v145                                    // 00000050A4A0: 7E360391
	v_mov_b32_e32 v29, v143                                    // 00000050A4A4: 7E3A038F
	v_mov_b32_e32 v23, v141                                    // 00000050A4A8: 7E2E038D
	v_mov_b32_e32 v25, v139                                    // 00000050A4AC: 7E32038B
	s_or_b32 s0, vcc_lo, s0                                    // 00000050A4B0: 8C00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000050A4B4: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 00000050A4B8: 917E007E
	s_cbranch_execz 114                                        // 00000050A4BC: BFA50072 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2088>
	s_waitcnt vmcnt(19)                                        // 00000050A4C0: BF894FF7
	v_dual_mov_b32 v153, v56 :: v_dual_mov_b32 v152, v73       // 00000050A4C4: CA100138 99980149
	s_waitcnt vmcnt(11)                                        // 00000050A4CC: BF892FF7
	v_dual_mov_b32 v151, v79 :: v_dual_mov_b32 v148, v70       // 00000050A4D0: CA10014F 97940146
	s_waitcnt vmcnt(3)                                         // 00000050A4D8: BF890FF7
	v_dual_mov_b32 v150, v83 :: v_dual_mov_b32 v149, v57       // 00000050A4DC: CA100153 96940139
	v_dual_mov_b32 v147, v78 :: v_dual_mov_b32 v144, v68       // 00000050A4E4: CA10014E 93900144
	s_waitcnt vmcnt(2)                                         // 00000050A4EC: BF890BF7
	v_dual_mov_b32 v146, v82 :: v_dual_mov_b32 v143, v77       // 00000050A4F0: CA100152 928E014D
	s_waitcnt vmcnt(1)                                         // 00000050A4F8: BF8907F7
	v_dual_mov_b32 v145, v58 :: v_dual_mov_b32 v142, v81       // 00000050A4FC: CA10013A 918E0151
	v_dual_mov_b32 v141, v59 :: v_dual_mov_b32 v140, v66       // 00000050A504: CA10013B 8D8C0142
	v_mov_b32_e32 v139, v76                                    // 00000050A50C: 7F16034C
	s_waitcnt vmcnt(0)                                         // 00000050A510: BF8903F7
	v_mov_b32_e32 v138, v80                                    // 00000050A514: 7F140350
	s_mov_b32 s7, exec_lo                                      // 00000050A518: BE87007E
	.long 0xd4c1007e                                           // 00000050A51C: D4C1007E
	v_cndmask_b32_e32 v1, v116, v51, vcc_lo                    // 00000050A520: 02026774
	s_cbranch_execz 64510                                      // 00000050A524: BFA5FBFE <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xf20>
	v_mad_i64_i32 v[3:4], null, 0x300, v116, s[4:5]            // 00000050A528: D6FF7C03 0012E8FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050A534: BF870091
	.long 0xd7006a05                                           // 00000050A538: D7006A05
	v_cndmask_b32_e32 v1, v3, v18, vcc_lo                      // 00000050A53C: 02022503
	v_add_co_ci_u32_e64 v6, null, v4, v19, vcc_lo              // 00000050A540: D5207C06 01AA2704
	.long 0xd7006a07                                           // 00000050A548: D7006A07
	v_cndmask_b32_e32 v1, v3, v120, vcc_lo                     // 00000050A54C: 0202F103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000050A550: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v4, vcc_lo                // 00000050A554: D5207C08 01AA0880
	.long 0xd7006a0b                                           // 00000050A55C: D7006A0B
	v_cndmask_b32_e32 v1, v3, v20, vcc_lo                      // 00000050A560: 02022903
	v_add_co_ci_u32_e64 v12, null, v4, v21, vcc_lo             // 00000050A564: D5207C0C 01AA2B04
	.long 0xd7006a03                                           // 00000050A56C: D7006A03
	v_cndmask_b32_e32 v1, v3, v121, vcc_lo                     // 00000050A570: 0202F303
	s_delay_alu instid0(VALU_DEP_1)                            // 00000050A574: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000050A578: D5207C04 01AA0880
	s_clause 0x1f                                              // 00000050A580: BF85001F
	global_load_b32 v125, v[5:6], off                          // 00000050A584: DC520000 7D7C0005
	global_load_b32 v124, v[5:6], off offset:96                // 00000050A58C: DC520060 7C7C0005
	global_load_b32 v123, v[5:6], off offset:192               // 00000050A594: DC5200C0 7B7C0005
	global_load_b32 v122, v[5:6], off offset:288               // 00000050A59C: DC520120 7A7C0005
	global_load_b32 v56, v[5:6], off offset:384                // 00000050A5A4: DC520180 387C0005
	global_load_b32 v57, v[5:6], off offset:480                // 00000050A5AC: DC5201E0 397C0005
	global_load_b32 v58, v[5:6], off offset:576                // 00000050A5B4: DC520240 3A7C0005
	global_load_b32 v59, v[5:6], off offset:672                // 00000050A5BC: DC5202A0 3B7C0005
	global_load_b32 v130, v[7:8], off                          // 00000050A5C4: DC520000 827C0007
	global_load_b32 v128, v[7:8], off offset:96                // 00000050A5CC: DC520060 807C0007
	global_load_b32 v127, v[7:8], off offset:192               // 00000050A5D4: DC5200C0 7F7C0007
	global_load_b32 v126, v[7:8], off offset:288               // 00000050A5DC: DC520120 7E7C0007
	global_load_b32 v73, v[7:8], off offset:384                // 00000050A5E4: DC520180 497C0007
	global_load_b32 v70, v[7:8], off offset:480                // 00000050A5EC: DC5201E0 467C0007
	global_load_b32 v68, v[7:8], off offset:576                // 00000050A5F4: DC520240 447C0007
	global_load_b32 v66, v[7:8], off offset:672                // 00000050A5FC: DC5202A0 427C0007
	global_load_b32 v134, v[11:12], off                        // 00000050A604: DC520000 867C000B
	global_load_b32 v132, v[11:12], off offset:96              // 00000050A60C: DC520060 847C000B
	global_load_b32 v131, v[11:12], off offset:192             // 00000050A614: DC5200C0 837C000B
	global_load_b32 v129, v[11:12], off offset:288             // 00000050A61C: DC520120 817C000B
	global_load_b32 v79, v[11:12], off offset:384              // 00000050A624: DC520180 4F7C000B
	global_load_b32 v78, v[11:12], off offset:480              // 00000050A62C: DC5201E0 4E7C000B
	global_load_b32 v77, v[11:12], off offset:576              // 00000050A634: DC520240 4D7C000B
	global_load_b32 v76, v[11:12], off offset:672              // 00000050A63C: DC5202A0 4C7C000B
	global_load_b32 v137, v[3:4], off                          // 00000050A644: DC520000 897C0003
	global_load_b32 v136, v[3:4], off offset:96                // 00000050A64C: DC520060 887C0003
	global_load_b32 v135, v[3:4], off offset:192               // 00000050A654: DC5200C0 877C0003
	global_load_b32 v133, v[3:4], off offset:288               // 00000050A65C: DC520120 857C0003
	global_load_b32 v83, v[3:4], off offset:384                // 00000050A664: DC520180 537C0003
	global_load_b32 v82, v[3:4], off offset:480                // 00000050A66C: DC5201E0 527C0003
	global_load_b32 v81, v[3:4], off offset:576                // 00000050A674: DC520240 517C0003
	global_load_b32 v80, v[3:4], off offset:672                // 00000050A67C: DC5202A0 507C0003
	s_branch 64422                                             // 00000050A684: BFA0FBA6 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xf20>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000050A688: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000050A68C: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000050A690: 8C7E017E
	s_waitcnt vmcnt(23)                                        // 00000050A694: BF895FF7
	v_dual_mov_b32 v1, v114 :: v_dual_mov_b32 v2, v111         // 00000050A698: CA100172 0102016F
	v_dual_mov_b32 v4, v110 :: v_dual_mov_b32 v3, v101         // 00000050A6A0: CA10016E 04020165
	v_dual_mov_b32 v5, v107 :: v_dual_mov_b32 v8, v112         // 00000050A6A8: CA10016B 05080170
	v_dual_mov_b32 v7, v113 :: v_dual_mov_b32 v6, v92          // 00000050A6B0: CA100171 0706015C
	s_waitcnt vmcnt(7)                                         // 00000050A6B8: BF891FF7
	v_dual_mov_b32 v9, v109 :: v_dual_mov_b32 v10, v108        // 00000050A6BC: CA10016D 090A016C
	v_dual_mov_b32 v11, v106 :: v_dual_mov_b32 v12, v105       // 00000050A6C4: CA10016A 0B0C0169
	v_dual_mov_b32 v13, v104 :: v_dual_mov_b32 v14, v103       // 00000050A6CC: CA100168 0D0E0167
	v_dual_mov_b32 v15, v102 :: v_dual_mov_b32 v16, v100       // 00000050A6D4: CA100166 0F100164
	v_dual_mov_b32 v18, v99 :: v_dual_mov_b32 v19, v98         // 00000050A6DC: CA100163 12120162
	v_dual_mov_b32 v20, v97 :: v_dual_mov_b32 v21, v96         // 00000050A6E4: CA100161 14140160
	v_dual_mov_b32 v22, v95 :: v_dual_mov_b32 v23, v94         // 00000050A6EC: CA10015F 1616015E
	s_waitcnt vmcnt(0)                                         // 00000050A6F4: BF8903F7
	v_dual_mov_b32 v24, v93 :: v_dual_mov_b32 v25, v91         // 00000050A6F8: CA10015D 1818015B
	v_dual_mov_b32 v26, v90 :: v_dual_mov_b32 v27, v89         // 00000050A700: CA10015A 1A1A0159
	v_dual_mov_b32 v28, v88 :: v_dual_mov_b32 v29, v87         // 00000050A708: CA100158 1C1C0157
	v_dual_mov_b32 v30, v86 :: v_dual_mov_b32 v31, v85         // 00000050A710: CA100156 1E1E0155
	v_dual_mov_b32 v32, v84 :: v_dual_mov_b32 v33, v17         // 00000050A718: CA100154 20200111
	s_mov_b32 s0, 0x76543210                                   // 00000050A720: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000050A728: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 00000050A72C: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000050A738: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 00000050A744: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 00000050A750: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 00000050A75C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 00000050A768: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 00000050A774: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 00000050A780: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 00000050A78C: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 00000050A798: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 00000050A7A4: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 00000050A7B0: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 00000050A7BC: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 00000050A7C8: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 00000050A7D4: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 00000050A7E0: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 00000050A7EC: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 00000050A7F8: D65C0013 03FC0113 FEDCBA98
	v_permlanex16_b32 v20, v20, s0, 0xfedcba98                 // 00000050A804: D65C0014 03FC0114 FEDCBA98
	v_permlanex16_b32 v21, v21, s0, 0xfedcba98                 // 00000050A810: D65C0015 03FC0115 FEDCBA98
	v_permlanex16_b32 v22, v22, s0, 0xfedcba98                 // 00000050A81C: D65C0016 03FC0116 FEDCBA98
	v_permlanex16_b32 v23, v23, s0, 0xfedcba98                 // 00000050A828: D65C0017 03FC0117 FEDCBA98
	v_permlanex16_b32 v24, v24, s0, 0xfedcba98                 // 00000050A834: D65C0018 03FC0118 FEDCBA98
	v_permlanex16_b32 v25, v25, s0, 0xfedcba98                 // 00000050A840: D65C0019 03FC0119 FEDCBA98
	v_permlanex16_b32 v26, v26, s0, 0xfedcba98                 // 00000050A84C: D65C001A 03FC011A FEDCBA98
	v_permlanex16_b32 v27, v27, s0, 0xfedcba98                 // 00000050A858: D65C001B 03FC011B FEDCBA98
	v_permlanex16_b32 v28, v28, s0, 0xfedcba98                 // 00000050A864: D65C001C 03FC011C FEDCBA98
	v_permlanex16_b32 v29, v29, s0, 0xfedcba98                 // 00000050A870: D65C001D 03FC011D FEDCBA98
	v_permlanex16_b32 v30, v30, s0, 0xfedcba98                 // 00000050A87C: D65C001E 03FC011E FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 00000050A888: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 00000050A894: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v33, v33, s0, 0xfedcba98                 // 00000050A8A0: D65C0021 03FC0121 FEDCBA98
	.long 0xd44c0000                                           // 00000050A8AC: D44C0000
	v_cndmask_b32_e32 v1, 16, v50, vcc_lo                      // 00000050A8B0: 02026490
	s_barrier                                                  // 00000050A8B4: BFBD0000
	buffer_gl0_inv                                             // 00000050A8B8: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000050A8C0: BE812000
	s_cbranch_execz 69                                         // 00000050A8C4: BFA50045 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x23dc>
	v_dual_add_f32 v17, v17, v33 :: v_dual_add_f32 v32, v84, v32// 00000050A8C8: C9084311 11204154
	v_lshl_or_b32 v33, v48, 11, v49                            // 00000050A8D0: D6560021 04C51730
	v_dual_add_f32 v5, v107, v5 :: v_dual_add_f32 v4, v110, v4 // 00000050A8D8: C9080B6B 0504096E
	v_dual_add_f32 v1, v114, v1 :: v_dual_add_f32 v2, v111, v2 // 00000050A8E0: C9080372 0102056F
	v_dual_add_f32 v8, v112, v8 :: v_dual_add_f32 v7, v113, v7 // 00000050A8E8: C9081170 08060F71
	s_delay_alu instid0(VALU_DEP_4)                            // 00000050A8F0: BF870004
	v_dual_add_f32 v3, v101, v3 :: v_dual_add_nc_u32 v34, 0x400, v33// 00000050A8F4: C9200765 032242FF 00000400
	v_dual_add_f32 v10, v108, v10 :: v_dual_add_f32 v9, v109, v9// 00000050A900: C908156C 0A08136D
	v_dual_add_f32 v14, v103, v14 :: v_dual_add_f32 v13, v104, v13// 00000050A908: C9081D67 0E0C1B68
	v_dual_add_f32 v6, v92, v6 :: v_dual_add_f32 v31, v85, v31 // 00000050A910: C9080D5C 061E3F55
	v_dual_add_f32 v30, v86, v30 :: v_dual_add_f32 v29, v87, v29// 00000050A918: C9083D56 1E1C3B57
	v_dual_add_f32 v28, v88, v28 :: v_dual_add_f32 v27, v89, v27// 00000050A920: C9083958 1C1A3759
	v_dual_add_f32 v26, v90, v26 :: v_dual_add_f32 v25, v91, v25// 00000050A928: C908355A 1A18335B
	v_dual_add_f32 v24, v93, v24 :: v_dual_add_f32 v23, v94, v23// 00000050A930: C908315D 18162F5E
	v_dual_add_f32 v22, v95, v22 :: v_dual_add_f32 v21, v96, v21// 00000050A938: C9082D5F 16142B60
	v_dual_add_f32 v20, v97, v20 :: v_dual_add_f32 v19, v98, v19// 00000050A940: C9082961 14122762
	v_add_f32_e32 v18, v99, v18                                // 00000050A948: 06242563
	v_dual_add_f32 v16, v100, v16 :: v_dual_add_f32 v15, v102, v15// 00000050A94C: C9082164 100E1F66
	v_dual_add_f32 v12, v105, v12 :: v_dual_add_f32 v11, v106, v11// 00000050A954: C9081969 0C0A176A
	ds_store_2addr_b32 v33, v1, v5 offset1:16                  // 00000050A95C: D8381000 00050121
	ds_store_2addr_b32 v33, v2, v7 offset0:128 offset1:144     // 00000050A964: D8389080 00070221
	ds_store_2addr_b32 v34, v4, v8 offset1:16                  // 00000050A96C: D8381000 00080422
	ds_store_2addr_b32 v34, v3, v9 offset0:128 offset1:144     // 00000050A974: D8389080 00090322
	ds_store_2addr_b32 v33, v6, v13 offset0:32 offset1:48      // 00000050A97C: D8383020 000D0621
	ds_store_2addr_b32 v33, v10, v14 offset0:160 offset1:176   // 00000050A984: D838B0A0 000E0A21
	ds_store_2addr_b32 v34, v11, v15 offset0:32 offset1:48     // 00000050A98C: D8383020 000F0B22
	ds_store_2addr_b32 v34, v12, v16 offset0:160 offset1:176   // 00000050A994: D838B0A0 00100C22
	ds_store_2addr_b32 v33, v18, v22 offset0:64 offset1:80     // 00000050A99C: D8385040 00161221
	ds_store_2addr_b32 v33, v19, v23 offset0:192 offset1:208   // 00000050A9A4: D838D0C0 00171321
	ds_store_2addr_b32 v34, v20, v24 offset0:64 offset1:80     // 00000050A9AC: D8385040 00181422
	ds_store_2addr_b32 v34, v21, v25 offset0:192 offset1:208   // 00000050A9B4: D838D0C0 00191522
	ds_store_2addr_b32 v33, v26, v30 offset0:96 offset1:112    // 00000050A9BC: D8387060 001E1A21
	ds_store_2addr_b32 v33, v27, v31 offset0:224 offset1:240   // 00000050A9C4: D838F0E0 001F1B21
	ds_store_2addr_b32 v34, v28, v32 offset0:96 offset1:112    // 00000050A9CC: D8387060 00201C22
	ds_store_2addr_b32 v34, v29, v17 offset0:224 offset1:240   // 00000050A9D4: D838F0E0 00111D22
	s_or_b32 exec_lo, exec_lo, s1                              // 00000050A9DC: 8C7E017E
	.long 0xd44c0001                                           // 00000050A9E0: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 00000050A9E4: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 00000050A9EC: BF89FC07
	s_barrier                                                  // 00000050A9F0: BFBD0000
	buffer_gl0_inv                                             // 00000050A9F4: E0AC0000 00000000
	s_and_saveexec_b32 s4, s1                                  // 00000050A9FC: BE842001
	s_cbranch_execz 50                                         // 00000050AA00: BFA50032 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x24cc>
	v_mov_b32_e32 v1, v0                                       // 00000050AA04: 7E020300
	s_mov_b32 s5, 0                                            // 00000050AA08: BE850080
	s_nop 0                                                    // 00000050AA0C: BF800000
	s_nop 0                                                    // 00000050AA10: BF800000
	s_nop 0                                                    // 00000050AA14: BF800000
	s_nop 0                                                    // 00000050AA18: BF800000
	s_nop 0                                                    // 00000050AA1C: BF800000
	s_nop 0                                                    // 00000050AA20: BF800000
	s_nop 0                                                    // 00000050AA24: BF800000
	s_nop 0                                                    // 00000050AA28: BF800000
	s_nop 0                                                    // 00000050AA2C: BF800000
	s_nop 0                                                    // 00000050AA30: BF800000
	s_nop 0                                                    // 00000050AA34: BF800000
	s_nop 0                                                    // 00000050AA38: BF800000
	s_nop 0                                                    // 00000050AA3C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000050AA40: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 00000050AA44: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 00000050AA48: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:8            // 00000050AA50: D8E00800 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:16 offset1:24// 00000050AA58: D8E01810 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:32 offset1:40// 00000050AA60: D8E02820 06000008
	s_or_b32 s5, vcc_lo, s5                                    // 00000050AA68: 8C05056A
	s_waitcnt lgkmcnt(2)                                       // 00000050AA6C: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 00000050AA70: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000050AA74: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 00000050AA78: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:48 offset1:56// 00000050AA7C: D8E03830 02000008
	s_waitcnt lgkmcnt(2)                                       // 00000050AA84: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 00000050AA88: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 00000050AA8C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 00000050AA90: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050AA94: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 00000050AA98: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 00000050AA9C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 00000050AAA0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000050AAA4: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 00000050AAA8: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 00000050AAAC: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 00000050AAB4: C9100702 02000104
	ds_store_b32 v8, v2 offset:16384                           // 00000050AABC: D8344000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000050AAC4: 917E057E
	s_cbranch_execnz 65501                                     // 00000050AAC8: BFA6FFDD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2440>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000050AACC: 8C7E047E
	s_cmp_lt_i32 s33, 2                                        // 00000050AAD0: BF048221
	s_mov_b32 s4, -1                                           // 00000050AAD4: BE8400C1
	s_cbranch_scc1 212                                         // 00000050AAD8: BFA200D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x282c>
	s_waitcnt lgkmcnt(0)                                       // 00000050AADC: BF89FC07
	s_barrier                                                  // 00000050AAE0: BFBD0000
	buffer_gl0_inv                                             // 00000050AAE4: E0AC0000 00000000
	s_and_saveexec_b32 s6, s1                                  // 00000050AAEC: BE862001
	s_cbranch_execz 71                                         // 00000050AAF0: BFA50047 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2610>
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000050AAF4: 32020087
	s_ashr_i32 s11, s10, 31                                    // 00000050AAF8: 860B9F0A
	s_ashr_i32 s27, s26, 31                                    // 00000050AAFC: 861B9F1A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000050AB00: 8484820A
	s_mov_b32 s7, 0                                            // 00000050AB04: BE870080
	v_or_b32_e32 v1, s4, v1                                    // 00000050AB08: 38020204
	s_mul_i32 s4, s5, s26                                      // 00000050AB0C: 96041A05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000050AB10: BF8700A1
	.long 0xd72c0003                                           // 00000050AB14: D72C0003
	v_cndmask_b32_e32 v0, v1, v27, vcc_lo                      // 00000050AB18: 02003701
	v_mad_u64_u32 v[1:2], null, v1, s26, 0                     // 00000050AB1C: D6FE7C01 02003501
	v_add3_u32 v2, v2, v3, s4                                  // 00000050AB24: D6550002 00120702
	s_lshl_b32 s4, s2, 7                                       // 00000050AB2C: 84048702
	v_and_b32_e32 v3, 0x7f, v0                                 // 00000050AB30: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 00000050AB38: 86059F04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000050AB3C: BF870122
	.long 0xd73c0001                                           // 00000050AB40: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000050AB44: 02020282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 00000050AB48: 84848204
	v_lshlrev_b32_e32 v4, 2, v3                                // 00000050AB4C: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 00000050AB50: 30060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050AB54: BF870093
	.long 0xd7006a01                                           // 00000050AB58: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000050AB5C: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000050AB60: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[26:27], 3                             // 00000050AB68: 8484831A
	.long 0xd7006a01                                           // 00000050AB6C: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000050AB70: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000050AB74: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000050AB78: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 00000050AB80: 380800FF FFFFFF00
	.long 0xd7006a01                                           // 00000050AB88: D7006A01
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000050AB8C: 02020210
	s_delay_alu instid0(VALU_DEP_1)                            // 00000050AB90: BF870001
	v_add_co_ci_u32_e64 v2, null, s17, v2, vcc_lo              // 00000050AB94: D5207C02 01AA0411
	s_nop 0                                                    // 00000050AB9C: BF800000
	s_nop 0                                                    // 00000050ABA0: BF800000
	s_nop 0                                                    // 00000050ABA4: BF800000
	s_nop 0                                                    // 00000050ABA8: BF800000
	s_nop 0                                                    // 00000050ABAC: BF800000
	s_nop 0                                                    // 00000050ABB0: BF800000
	s_nop 0                                                    // 00000050ABB4: BF800000
	s_nop 0                                                    // 00000050ABB8: BF800000
	s_nop 0                                                    // 00000050ABBC: BF800000
	ds_load_b32 v5, v3 offset:16384                            // 00000050ABC0: D8D84000 05000003
	.long 0xd7000804                                           // 00000050ABC8: D7000804
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 00000050ABCC: 020208FF 00000100
	s_xor_b32 s8, s8, -1                                       // 00000050ABD4: 8D08C108
	v_add_nc_u32_e32 v3, 0x400, v3                             // 00000050ABD8: 4A0606FF 00000400
	s_and_b32 s8, exec_lo, s8                                  // 00000050ABE0: 8B08087E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000050ABE4: BF8700C9
	s_or_b32 s7, s8, s7                                        // 00000050ABE8: 8C070708
	s_waitcnt lgkmcnt(0)                                       // 00000050ABEC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 00000050ABF0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 00000050ABF8: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000050ABFC: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000050AC00: D5207C02 01AA0405
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 00000050AC08: 917E077E
	s_cbranch_execnz 65516                                     // 00000050AC0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x25c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000050AC10: 8C7E067E
	.long 0xd44a0004                                           // 00000050AC14: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000050AC18: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 00000050AC1C: BC7C0000
	buffer_gl1_inv                                             // 00000050AC20: E0B00000 00000000
	buffer_gl0_inv                                             // 00000050AC28: E0AC0000 00000000
	s_barrier                                                  // 00000050AC30: BFBD0000
	buffer_gl0_inv                                             // 00000050AC34: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 00000050AC3C: BE852004
	s_cbranch_execz 29                                         // 00000050AC40: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x26b8>
	s_mov_b32 s7, exec_lo                                      // 00000050AC44: BE87007E
	s_mov_b32 s6, exec_lo                                      // 00000050AC48: BE86007E
	.long 0xd71f0001                                           // 00000050AC4C: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 00000050AC50: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 00000050AC54: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 00000050AC58: 7D940280
	s_cbranch_execz 9                                          // 00000050AC5C: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2684>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 00000050AC60: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000050AC64: BF8704B9
	s_add_u32 s8, s18, s8                                      // 00000050AC68: 80080812
	s_addc_u32 s9, s19, s9                                     // 00000050AC6C: 82090913
	s_bcnt1_i32_b32 s7, s7                                     // 00000050AC70: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 00000050AC74: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 00000050AC7C: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 00000050AC84: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 00000050AC88: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 00000050AC8C: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 00000050AC90: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 00000050AC94: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 00000050AC9C: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000050ACA0: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 00000050ACA4: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 00000050ACA8: D5010001 01A90280
	ds_store_b32 v2, v1 offset:20480                           // 00000050ACB0: D8345000 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 00000050ACB8: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 00000050ACBC: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 00000050ACC0: BF89FC07
	s_barrier                                                  // 00000050ACC4: BFBD0000
	buffer_gl0_inv                                             // 00000050ACC8: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:20480                            // 00000050ACD0: D8D85000 01000001
	s_waitcnt lgkmcnt(0)                                       // 00000050ACD8: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000050ACDC: 7C940280
	s_cbranch_vccnz 424                                        // 00000050ACE0: BFA401A8 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2d84>
	buffer_gl1_inv                                             // 00000050ACE4: E0B00000 00000000
	buffer_gl0_inv                                             // 00000050ACEC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 00000050ACF4: BE852001
	s_cbranch_execz 65                                         // 00000050ACF8: BFA50041 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2800>
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000050ACFC: 32020087
	s_lshl_b32 s6, s2, 7                                       // 00000050AD00: 84068702
	v_and_b32_e32 v3, 0x7f, v0                                 // 00000050AD04: 360600FF 0000007F
	s_ashr_i32 s7, s6, 31                                      // 00000050AD0C: 86079F06
	v_mov_b32_e32 v5, v0                                       // 00000050AD10: 7E0A0300
	v_mad_i64_i32 v[1:2], null, v1, s26, 0                     // 00000050AD14: D6FF7C01 02003501
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000050AD1C: 84868206
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000050AD20: 30060682
	s_ashr_i32 s27, s26, 31                                    // 00000050AD24: 861B9F1A
	s_mov_b32 s10, 0                                           // 00000050AD28: BE8A0080
	s_lshl_b64 s[8:9], s[26:27], 4                             // 00000050AD2C: 8488841A
	.long 0xd73c0001                                           // 00000050AD30: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000050AD34: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050AD38: BF870091
	.long 0xd7006a01                                           // 00000050AD3C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 00000050AD40: 02000D01
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 00000050AD44: D5207C02 01AA0407
	s_lshl_b64 s[6:7], s[26:27], 3                             // 00000050AD4C: 8486831A
	.long 0xd7006a01                                           // 00000050AD50: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000050AD54: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050AD58: BF870111
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000050AD5C: D5207C02 01AA0480
	.long 0xd7006a01                                           // 00000050AD64: D7006A01
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000050AD68: 02020210
	s_delay_alu instid0(VALU_DEP_1)                            // 00000050AD6C: BF870001
	v_add_co_ci_u32_e64 v2, null, s17, v2, vcc_lo              // 00000050AD70: D5207C02 01AA0411
	s_nop 0                                                    // 00000050AD78: BF800000
	s_nop 0                                                    // 00000050AD7C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000050AD80: BF870001
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 00000050AD84: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 00000050AD8C: 7E0C0280
	s_mov_b32 s1, s33                                          // 00000050AD90: BE810021
	global_load_b32 v7, v[3:4], off glc                        // 00000050AD94: DC524000 077C0003
	.long 0xd7006a03                                           // 00000050AD9C: D7006A03
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 00000050ADA0: 02001103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000050ADA4: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000050ADA8: D5207C04 01AA0809
	s_add_i32 s1, s1, -1                                       // 00000050ADB0: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 00000050ADB4: BF068001
	s_waitcnt vmcnt(0)                                         // 00000050ADB8: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 00000050ADBC: 060C0F06
	s_cbranch_scc0 65524                                       // 00000050ADC0: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2794>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 00000050ADC4: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 00000050ADCC: 7C920AFF 000000FF
	.long 0xd7000101                                           // 00000050ADD4: D7000101
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 00000050ADD8: 02000D01
	v_lshlrev_b32_e32 v3, 2, v5                                // 00000050ADDC: 30060A82
	v_add_co_ci_u32_e64 v2, null, s7, v2, s1                   // 00000050ADE0: D5207C02 00060407
	v_mov_b32_e32 v5, v4                                       // 00000050ADE8: 7E0A0304
	s_or_b32 s10, vcc_lo, s10                                  // 00000050ADEC: 8C0A0A6A
	ds_store_b32 v3, v6 offset:16384                           // 00000050ADF0: D8344000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000050ADF8: 917E0A7E
	s_cbranch_execnz 65504                                     // 00000050ADFC: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2780>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000050AE00: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 00000050AE04: BE812004
	s_cbranch_execz 6                                          // 00000050AE08: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2824>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 00000050AE0C: 84848202
	v_mov_b32_e32 v1, 0                                        // 00000050AE10: 7E020280
	s_add_u32 s4, s18, s4                                      // 00000050AE14: 80040412
	s_addc_u32 s5, s19, s5                                     // 00000050AE18: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 00000050AE1C: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 00000050AE24: 8C7E017E
	s_mov_b32 s4, -1                                           // 00000050AE28: BE8400C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000050AE2C: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 00000050AE30: 8B6A047E
	s_cbranch_vccz 339                                         // 00000050AE34: BFA30153 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2d84>
	v_cmp_gt_i32_e32 vcc_lo, s24, v48                          // 00000050AE38: 7C886018
	.long 0xd44c0001                                           // 00000050AE3C: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000050AE40: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 00000050AE48: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000050AE4C: BC7C0000
	s_barrier                                                  // 00000050AE50: BFBD0000
	buffer_gl0_inv                                             // 00000050AE54: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000050AE5C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000050AE60: BF870009
	s_and_saveexec_b32 s3, s1                                  // 00000050AE64: BE832001
	s_cbranch_execz 326                                        // 00000050AE68: BFA50146 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2d84>
	v_and_b32_e32 v1, 15, v0                                   // 00000050AE6C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050AE70: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 00000050AE74: 30040282
	v_lshl_or_b32 v2, v48, 9, v2                               // 00000050AE78: D6560002 04091330
	s_delay_alu instid0(VALU_DEP_1)                            // 00000050AE80: BF870001
	v_add_nc_u32_e32 v8, 0x4000, v2                            // 00000050AE84: 4A1004FF 00004000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000050AE8C: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 00000050AE94: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000050AE9C: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 00000050AEA4: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 00000050AEAC: 36140081
	s_waitcnt lgkmcnt(3)                                       // 00000050AEB0: BF89FC37
	v_dual_add_f32 v12, v2, v3 :: v_dual_and_b32 v11, 2, v0    // 00000050AEB4: C9240702 0C0A0082
	s_waitcnt lgkmcnt(2)                                       // 00000050AEBC: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 00000050AEC0: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000050AEC8: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000050AECC: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 00000050AED4: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_sub_f32 v7, v8, v9     // 00000050AED8: C94A0F06 06061308
	v_dual_add_f32 v8, v8, v9 :: v_dual_and_b32 v9, 4, v0      // 00000050AEE0: C9241308 08080084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000050AEE8: BF8701A3
	v_add_f32_e32 v13, v2, v4                                  // 00000050AEEC: 061A0902
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000050AEF0: 7C941480
	v_add_f32_e32 v16, v5, v8                                  // 00000050AEF4: 06201105
	v_dual_sub_f32 v5, v5, v8 :: v_dual_add_f32 v14, v12, v3   // 00000050AEF8: C9481105 050E070C
	v_add_f32_e32 v15, v6, v7                                  // 00000050AF00: 061E0F06
	v_dual_sub_f32 v3, v12, v3 :: v_dual_sub_f32 v2, v2, v4    // 00000050AF04: C94A070C 03020902
	v_sub_f32_e32 v4, v6, v7                                   // 00000050AF0C: 08080F06
	.long 0xd44a0001                                           // 00000050AF10: D44A0001
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 00000050AF14: 02021280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050AF18: BF870214
	v_add_f32_e32 v6, v13, v15                                 // 00000050AF1C: 060C1F0D
	v_dual_sub_f32 v8, v13, v15 :: v_dual_add_f32 v13, v3, v5  // 00000050AF20: C9481F0D 080C0B03
	v_add_f32_e32 v7, v14, v16                                 // 00000050AF28: 060E210E
	v_dual_sub_f32 v3, v3, v5 :: v_dual_add_f32 v12, v2, v4    // 00000050AF2C: C9480B03 030C0902
	v_sub_f32_e32 v2, v2, v4                                   // 00000050AF34: 08040902
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000050AF38: 7E0A02FA FF016106
	s_delay_alu instid0(VALU_DEP_4)                            // 00000050AF40: BF870004
	v_mov_b32_dpp v4, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000050AF44: 7E0802FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000050AF4C: D5010007 21AA0F07
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000050AF54: D5010006 21AA0D06
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000050AF5C: 7E2402FA FF016103
	v_cndmask_b32_e64 v21, -v3, v3, vcc_lo                     // 00000050AF64: D5010015 21AA0703
	v_mov_b32_dpp v19, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000050AF6C: 7E2602FA FF016102
	v_add_f32_e32 v3, v7, v4                                   // 00000050AF74: 06060907
	v_mov_b32_dpp v15, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000050AF78: 7E1E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000050AF80: D5010008 21AA1108
	v_cndmask_b32_e64 v20, -v2, v2, vcc_lo                     // 00000050AF88: D5010014 21AA0502
	v_add_f32_e32 v2, v6, v5                                   // 00000050AF90: 06040B06
	v_mov_b32_dpp v6, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000050AF94: 7E0C02FA FF016203
	v_sub_f32_e32 v10, v14, v16                                // 00000050AF9C: 0814210E
	v_mov_b32_dpp v16, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000050AFA0: 7E2002FA FF01610D
	v_mov_b32_dpp v17, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000050AFA8: 7E2202FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 00000050AFB0: D501000C 21AA190C
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000050AFB8: D501000D 21AA1B0D
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000050AFC0: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000050AFC8: D501000A 21AA150A
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 00000050AFD0: 7C941680
	v_add_f32_e32 v4, v8, v15                                  // 00000050AFD4: 06081F08
	v_dual_add_f32 v7, v12, v17 :: v_dual_add_f32 v8, v13, v16 // 00000050AFD8: C908230C 0708210D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000050AFE0: BF870224
	v_add_f32_e32 v5, v10, v14                                 // 00000050AFE4: 060A1D0A
	v_add_f32_e32 v13, v20, v19                                // 00000050AFE8: 061A2714
	v_mov_b32_dpp v12, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000050AFEC: 7E1802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000050AFF4: D5010004 21AA0904
	v_mov_b32_dpp v10, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000050AFFC: 7E1402FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000050B004: D5010002 21AA0502
	v_mov_b32_dpp v9, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000050B00C: 7E1202FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000050B014: D5010008 21AA1108
	v_add_f32_e32 v4, v4, v12                                  // 00000050B01C: 06081904
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000050B020: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000050B028: D5010005 21AA0B05
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000050B030: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000050B038: D501000D 21AA1B0D
	v_mov_b32_dpp v12, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000050B040: 7E1802FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 00000050B048: D5010004 20060904
	v_dual_add_f32 v8, v8, v9 :: v_dual_add_f32 v11, v5, v11   // 00000050B050: C9081308 080A1705
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000050B058: D5010003 21AA0703
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000050B060: 7E1C02FA FF016207
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000050B068: BF8701C4
	v_add_f32_e32 v4, v4, v12                                  // 00000050B06C: 06081904
	v_add_f32_e32 v12, v21, v18                                // 00000050B070: 06182515
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000050B074: D5010007 21AA0F07
	v_add_f32_e32 v3, v3, v6                                   // 00000050B07C: 06060D03
	v_mov_b32_dpp v9, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000050B080: 7E1202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 00000050B088: D501000C 21AA190C
	v_add_f32_e32 v2, v2, v10                                  // 00000050B090: 06041502
	v_add_f32_e32 v14, v7, v14                                 // 00000050B094: 061C1D07
	v_mov_b32_dpp v6, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000050B098: 7E0C02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000050B0A0: D5010003 20060703
	v_add_f32_e32 v9, v12, v9                                  // 00000050B0A8: 0612130C
	v_cndmask_b32_e64 v10, -v2, v2, s1                         // 00000050B0AC: D501000A 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000050B0B4: 7E0402FA FF016402
	v_mov_b32_dpp v12, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000050B0BC: 7E1802FA FF01640E
	v_add_f32_e32 v3, v3, v6                                   // 00000050B0C4: 06060D03
	v_mov_b32_dpp v16, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000050B0C8: 7E2002FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 00000050B0D0: D5010009 20061309
	v_add_f32_e32 v5, v10, v2                                  // 00000050B0D8: 060A050A
	v_mov_b32_dpp v10, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000050B0DC: 7E1402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 00000050B0E4: D501000B 2006170B
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000050B0EC: 7E0402FA FF016803
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000050B0F4: BF870194
	v_mov_b32_dpp v6, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000050B0F8: 7E0C02FA FF016805
	v_add_f32_e32 v7, v11, v10                                 // 00000050B100: 060E150B
	v_add_f32_e32 v11, v13, v15                                // 00000050B104: 06161F0D
	v_mov_b32_dpp v10, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000050B108: 7E1402FA FF016408
	v_cndmask_b32_e64 v13, -v14, v14, s1                       // 00000050B110: D501000D 20061D0E
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 00000050B118: D501000E 20061108
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000050B120: 7E1002FA FF016807
	v_mov_b32_dpp v18, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000050B128: 7E2402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 00000050B130: D501000B 2006170B
	v_add_f32_e32 v17, v13, v12                                // 00000050B138: 0622190D
	v_dual_add_f32 v15, v14, v10 :: v_dual_add_f32 v14, v9, v16// 00000050B13C: C908150E 0F0E2109
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000050B144: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050B14C: BF870214
	v_add_f32_e32 v16, v11, v18                                // 00000050B150: 0620250B
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000050B154: 7E1A02FA FF016811
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000050B15C: BF870224
	v_mov_b32_dpp v11, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000050B160: 7E1602FA FF01680F
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000050B168: 7E1402FA FF01680E
	v_mov_b32_dpp v12, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000050B170: 7E1802FA FF016810
	s_and_b32 exec_lo, exec_lo, s0                             // 00000050B178: 8B7E007E
	s_cbranch_execz 129                                        // 00000050B17C: BFA50081 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2d84>
	v_lshl_or_b32 v18, s2, 7, v1                               // 00000050B180: D6560012 04050E02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050B188: BF870091
	v_ashrrev_i32_e32 v19, 31, v18                             // 00000050B18C: 3426249F
	.long 0xd73c0014                                           // 00000050B190: D73C0014
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000050B194: 02022481
	.long 0xd73c0012                                           // 00000050B198: D73C0012
	v_cndmask_b32_e32 v1, 2, v18, vcc_lo                       // 00000050B19C: 02022482
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050B1A0: BF870092
	.long 0xd7006a14                                           // 00000050B1A4: D7006A14
	v_cndmask_b32_e32 v1, s14, v20, vcc_lo                     // 00000050B1A8: 0202280E
	v_add_co_ci_u32_e64 v21, null, s15, v21, vcc_lo            // 00000050B1AC: D5207C15 01AA2A0F
	s_clause 0x7                                               // 00000050B1B4: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 00000050B1B8: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 00000050B1C0: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:96           // 00000050B1C8: DC820060 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:64           // 00000050B1D0: DC820040 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:160          // 00000050B1D8: DC8200A0 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:128          // 00000050B1E0: DC820080 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:224          // 00000050B1E8: DC8200E0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:192          // 00000050B1F0: DC8200C0 147C0014
	v_and_b32_e32 v21, 8, v0                                   // 00000050B1F8: 362A0088
	v_mad_i64_i32 v[0:1], null, s26, v48, 0                    // 00000050B1FC: D6FF7C00 0202601A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050B204: BF870112
	v_cmp_eq_u32_e32 vcc_lo, 0, v21                            // 00000050B208: 7C942A80
	.long 0xd73c0000                                           // 00000050B20C: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000050B210: 02020082
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000050B214: D5010005 21AA0B05
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000050B21C: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000050B224: D501000F 21AA1F0F
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000050B22C: D5010004 21AA0904
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000050B234: D5010007 21AA0F07
	v_add_f32_e32 v5, v5, v6                                   // 00000050B23C: 060A0D05
	v_cndmask_b32_e64 v6, -v17, v17, vcc_lo                    // 00000050B240: D5010006 21AA2311
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 00000050B248: D5010010 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000050B250: D501000E 21AA1D0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050B258: BF870214
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 00000050B25C: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v13 :: v_dual_add_f32 v6, v15, v11  // 00000050B268: C9081B06 0506170F
	.long 0xd7006a00                                           // 00000050B270: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 00000050B274: 02020014
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v7, v7, v8     // 00000050B278: C9081304 04061107
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 00000050B280: D5207C01 01AA0215
	v_dual_add_f32 v8, v16, v12 :: v_dual_add_f32 v9, v14, v10 // 00000050B288: C9081910 0808150E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000050B290: BF870003
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 00000050B294: 100808FF 3DB504F3
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 00000050B29C: 100404FF 3DB504F3
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 00000050B2A4: C8C60CFF 06040AFF 3DB504F3
	.long 0xd7006a00                                           // 00000050B2B0: D7006A00
	v_cndmask_b32_e32 v1, v0, v18, vcc_lo                      // 00000050B2B4: 02022500
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 00000050B2B8: C8C60EFF 070810FF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, v1, v19, vcc_lo              // 00000050B2C4: D5207C01 01AA2701
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 00000050B2CC: 101212FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 00000050B2D4: BF891FF7
	v_fma_mix_f32 v3, v22, v3, neg(0) op_sel_hi:[1,0,0]        // 00000050B2D8: CC200003 8A020716
	s_waitcnt vmcnt(6)                                         // 00000050B2E0: BF891BF7
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 00000050B2E4: CC200002 8A020517
	s_waitcnt vmcnt(5)                                         // 00000050B2EC: BF8917F7
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 00000050B2F0: CC200005 8A020B18
	s_waitcnt vmcnt(4)                                         // 00000050B2F8: BF8913F7
	v_fma_mix_f32 v6, v25, v6, neg(0) op_sel_hi:[1,0,0]        // 00000050B2FC: CC200006 8A020D19
	s_waitcnt vmcnt(3)                                         // 00000050B304: BF890FF7
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 00000050B308: CC200004 8A02091A
	s_waitcnt vmcnt(2)                                         // 00000050B310: BF890BF7
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 00000050B314: CC200007 8A020F1B
	s_waitcnt vmcnt(1)                                         // 00000050B31C: BF8907F7
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 00000050B320: CC200008 8A02111C
	s_waitcnt vmcnt(0)                                         // 00000050B328: BF8903F7
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 00000050B32C: CC200009 8A021314
	s_clause 0x7                                               // 00000050B334: BF850007
	global_store_b32 v[0:1], v2, off                           // 00000050B338: DC6A0000 007C0200
	global_store_b32 v[0:1], v3, off offset:64                 // 00000050B340: DC6A0040 007C0300
	global_store_b32 v[0:1], v6, off offset:128                // 00000050B348: DC6A0080 007C0600
	global_store_b32 v[0:1], v5, off offset:192                // 00000050B350: DC6A00C0 007C0500
	global_store_b32 v[0:1], v7, off offset:256                // 00000050B358: DC6A0100 007C0700
	global_store_b32 v[0:1], v4, off offset:320                // 00000050B360: DC6A0140 007C0400
	global_store_b32 v[0:1], v9, off offset:384                // 00000050B368: DC6A0180 007C0900
	global_store_b32 v[0:1], v8, off offset:448                // 00000050B370: DC6A01C0 007C0800
	s_nop 0                                                    // 00000050B378: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000050B37C: BFB60003
	s_endpgm                                                   // 00000050B380: BFB00000
	s_nop 0                                                    // 00000050B384: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000050B388: BFB60003
	s_endpgm                                                   // 00000050B38C: BFB00000
		...

