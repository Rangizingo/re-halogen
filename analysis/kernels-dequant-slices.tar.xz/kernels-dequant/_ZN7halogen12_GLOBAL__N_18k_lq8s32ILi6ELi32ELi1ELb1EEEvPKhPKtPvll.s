0000000000730d00 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi1ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi1ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000730D00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000730D04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000730D0C: F4040300 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000730D14: 32020085
	s_mov_b32 s3, 0                                            // 000000730D18: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 000000730D1C: CA240080 100E009F
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000730D24: 84808302
	.long 0x7e343880                                           // 000000730D28: 7E343880
	v_or_b32_e32 v9, s0, v1                                    // 000000730D2C: 38120200
	v_mov_b32_e32 v10, s1                                      // 000000730D30: 7E140201
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 000000730D34: CA100080 04040080
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v11, 4, v15     // 000000730D3C: CA220080 060A1E84
	s_waitcnt lgkmcnt(0)                                       // 000000730D44: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 000000730D48: 86009F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 000000730D4C: 7CA8120C
	s_lshr_b32 s0, s0, 28                                      // 000000730D50: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000730D54: BF8704A9
	s_add_u32 s2, s10, s0                                      // 000000730D58: 8002000A
	s_addc_u32 s3, s11, 0                                      // 000000730D5C: 8203800B
	s_ashr_i64 s[2:3], s[2:3], 4                               // 000000730D60: 86828402
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000730D64: 02021280
	s_add_u32 s0, s10, s2                                      // 000000730D68: 8000020A
	v_cndmask_b32_e64 v2, 0, s1, vcc_lo                        // 000000730D6C: D5010002 01A80280
	s_addc_u32 s1, s11, s3                                     // 000000730D74: 8201030B
	s_add_u32 s0, s0, 15                                       // 000000730D78: 80008F00
	s_addc_u32 s1, s1, 0                                       // 000000730D7C: 82018001
	s_and_b32 s0, s0, -16                                      // 000000730D80: 8B00D000
	.long 0xd72c0003                                           // 000000730D84: D72C0003
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 000000730D88: 02000301
	.long 0xd72c0007                                           // 000000730D8C: D72C0007
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 000000730D90: 02000102
	v_mad_u64_u32 v[1:2], null, v1, s0, 0                      // 000000730D94: D6FE7C01 02000101
	.long 0xd4440000                                           // 000000730D9C: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 000000730DA0: 02021E02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000730DA4: BF870192
	v_add3_u32 v2, v2, v3, v7                                  // 000000730DA8: D6550002 041E0702
	.long 0xd7000111                                           // 000000730DB0: D7000111
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000730DB4: 02020204
	v_mov_b32_e32 v7, 0                                        // 000000730DB8: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000730DBC: BF870003
	v_add_co_ci_u32_e64 v18, null, s5, v2, s1                  // 000000730DC0: D5207C12 00060405
	s_and_saveexec_b32 s3, s0                                  // 000000730DC8: BE832000
	s_cbranch_execz 21                                         // 000000730DCC: BFA50015 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi1ELb1EEEvPKhPKtPvll+0x124>
	v_lshlrev_b32_e32 v3, 4, v15                               // 000000730DD0: 30061E84
	.long 0xd7000105                                           // 000000730DD4: D7000105
	v_cndmask_b32_e32 v0, v17, v10, vcc_lo                     // 000000730DD8: 02001511
	v_and_b32_e32 v7, 30, v0                                   // 000000730DDC: 360E009E
	v_add_co_ci_u32_e64 v6, null, s11, v18, s1                 // 000000730DE0: D5207C06 0006240B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730DE8: BF870094
	.long 0xd7000103                                           // 000000730DEC: D7000103
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 000000730DF0: 02020711
	v_add_co_ci_u32_e64 v4, null, 0, v18, s1                   // 000000730DF4: D5207C04 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730DFC: BF870094
	.long 0xd700010c                                           // 000000730E00: D700010C
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000730E04: 02020F05
	v_add_co_ci_u32_e64 v13, null, 0, v6, s1                   // 000000730E08: D5207C0D 00060C80
	s_clause 0x1                                               // 000000730E10: BF850001
	global_load_b128 v[4:7], v[3:4], off                       // 000000730E14: DC5E0000 047C0003
	global_load_d16_b16 v26, v[12:13], off                     // 000000730E1C: DC820000 1A7C000C
	s_or_b32 exec_lo, exec_lo, s3                              // 000000730E24: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 000000730E28: CA100080 13140080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000730E30: CA100080 15160080
	v_mov_b32_e32 v23, 0                                       // 000000730E38: 7E2E0280
	s_and_saveexec_b32 s3, s0                                  // 000000730E3C: BE832000
	s_cbranch_execz 505                                        // 000000730E40: BFA501F9 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi1ELb1EEEvPKhPKtPvll+0x928>
	v_and_or_b32 v0, v0, 30, 32                                // 000000730E44: D6570000 02813D00
	.long 0xd7000001                                           // 000000730E4C: D7000001
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 000000730E50: 0202020A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000730E54: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s11, v2, s0                  // 000000730E58: D5207C02 0002040B
	v_mov_b32_e32 v12, 0                                       // 000000730E60: 7E180280
	.long 0xd7000000                                           // 000000730E64: D7000000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 000000730E68: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000730E6C: BF870191
	v_add_co_ci_u32_e64 v1, null, 0, v2, s0                    // 000000730E70: D5207C01 00020480
	v_dual_mov_b32 v24, v15 :: v_dual_mov_b32 v23, v12         // 000000730E78: CA10010F 1816010C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730E80: BF870093
	.long 0xd700000d                                           // 000000730E84: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 000000730E88: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v1, s0                  // 000000730E8C: D5207C0E 00020205
	v_mov_b32_e32 v22, v12                                     // 000000730E94: 7E2C030C
	v_mov_b32_e32 v21, v12                                     // 000000730E98: 7E2A030C
	v_mov_b32_e32 v20, v12                                     // 000000730E9C: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 000000730EA0: 7E26030C
	v_mov_b32_e32 v16, v12                                     // 000000730EA4: 7E20030C
	s_mul_i32 s1, s11, 6                                       // 000000730EA8: 9601860B
	s_mul_hi_u32 s16, s10, 6                                   // 000000730EAC: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000730EB0: 848E820A
	s_add_i32 s16, s16, s1                                     // 000000730EB4: 81100110
	s_mul_i32 s18, s10, 6                                      // 000000730EB8: 9612860A
	s_mov_b32 s17, 0                                           // 000000730EBC: BE910080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000730EC0: 8484810A
	s_branch 442                                               // 000000730EC4: BFA001BA <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi1ELb1EEEvPKhPKtPvll+0x8b0>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000730EC8: 8C7E0A7E
	v_bfe_i32 v27, v4, 0, 8                                    // 000000730ECC: D611001B 02210104
	s_and_b32 s0, exec_lo, s0                                  // 000000730ED4: 8B00007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730ED8: BF870099
	s_or_b32 s17, s0, s17                                      // 000000730EDC: 8C111100
	v_cvt_f32_i32_e32 v27, v27                                 // 000000730EE0: 7E360B1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730EE4: BF870091
	v_fma_mix_f32 v27, v26, v27, neg(0) op_sel_hi:[1,0,0]      // 000000730EE8: CC20001B 8A02371A
	v_bfe_u32 v28, v27, 16, 1                                  // 000000730EF0: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000730EF8: BF870121
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000730EFC: D655001B 03FE391B 00007FFF
	.long 0x7f383880                                           // 000000730F08: 7F383880
	.long 0x7e38399b                                           // 000000730F0C: 7E38399B
	v_bfe_i32 v27, v4, 8, 8                                    // 000000730F10: D611001B 02211104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730F18: BF870091
	v_cvt_f32_i32_e32 v27, v27                                 // 000000730F1C: 7E360B1B
	v_fma_mix_f32 v27, v26, v27, neg(0) op_sel_hi:[1,0,0]      // 000000730F20: CC20001B 8A02371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730F28: BF870091
	v_bfe_u32 v29, v27, 16, 1                                  // 000000730F2C: D610001D 0205211B
	v_add3_u32 v27, v27, v29, 0x7fff                           // 000000730F34: D655001B 03FE3B1B 00007FFF
	v_bfe_i32 v29, v4, 16, 8                                   // 000000730F40: D611001D 02212104
	v_ashrrev_i32_e32 v4, 24, v4                               // 000000730F48: 34080898
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000730F4C: BF870193
	v_and_or_b32 v34, 0xffff0000, v27, v28                     // 000000730F50: D6570022 047236FF FFFF0000
	v_cvt_f32_i32_e32 v29, v29                                 // 000000730F5C: 7E3A0B1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000730F60: BF870113
	v_cvt_f32_i32_e32 v4, v4                                   // 000000730F64: 7E080B04
	v_fma_mix_f32 v29, v26, v29, neg(0) op_sel_hi:[1,0,0]      // 000000730F68: CC20001D 8A023B1A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000730F70: BF870112
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000730F74: CC200004 8A02091A
	v_bfe_u32 v30, v29, 16, 1                                  // 000000730F7C: D610001E 0205211D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000730F84: BF870191
	v_add3_u32 v29, v29, v30, 0x7fff                           // 000000730F88: D655001D 03FE3D1D 00007FFF
	v_bfe_u32 v30, v4, 16, 1                                   // 000000730F94: D610001E 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000730F9C: BF8701A2
	.long 0x7e3a399d                                           // 000000730FA0: 7E3A399D
	.long 0x7f3a399c                                           // 000000730FA4: 7F3A399C
	v_add3_u32 v4, v4, v30, 0x7fff                             // 000000730FA8: D6550004 03FE3D04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000730FB4: BF8700A1
	v_and_or_b32 v35, 0xffff0000, v4, v29                      // 000000730FB8: D6570023 047608FF FFFF0000
	v_bfe_i32 v4, v5, 0, 8                                     // 000000730FC4: D6110004 02210105
	v_cvt_f32_i32_e32 v4, v4                                   // 000000730FCC: 7E080B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730FD0: BF870091
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000730FD4: CC200004 8A02091A
	v_bfe_u32 v27, v4, 16, 1                                   // 000000730FDC: D610001B 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730FE4: BF870091
	v_add3_u32 v4, v4, v27, 0x7fff                             // 000000730FE8: D6550004 03FE3704 00007FFF
	.long 0x7e383984                                           // 000000730FF4: 7E383984
	v_bfe_i32 v4, v5, 8, 8                                     // 000000730FF8: D6110004 02211105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731000: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 000000731004: 7E080B04
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000731008: CC200004 8A02091A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731010: BF870091
	v_bfe_u32 v27, v4, 16, 1                                   // 000000731014: D610001B 02052104
	v_add3_u32 v4, v4, v27, 0x7fff                             // 00000073101C: D6550004 03FE3704 00007FFF
	v_bfe_i32 v27, v5, 16, 8                                   // 000000731028: D611001B 02212105
	v_ashrrev_i32_e32 v5, 24, v5                               // 000000731030: 340A0A98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000731034: BF870193
	v_and_or_b32 v36, 0xffff0000, v4, v28                      // 000000731038: D6570024 047208FF FFFF0000
	v_cvt_f32_i32_e32 v27, v27                                 // 000000731044: 7E360B1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000731048: BF8701A3
	v_cvt_f32_i32_e32 v5, v5                                   // 00000073104C: 7E0A0B05
	v_bfe_i32 v4, v6, 0, 8                                     // 000000731050: D6110004 02210106
	v_fma_mix_f32 v27, v26, v27, neg(0) op_sel_hi:[1,0,0]      // 000000731058: CC20001B 8A02371A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000731060: BF870193
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 000000731064: CC200005 8A020B1A
	v_cvt_f32_i32_e32 v4, v4                                   // 00000073106C: 7E080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000731070: BF870113
	v_bfe_u32 v29, v27, 16, 1                                  // 000000731074: D610001D 0205211B
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 00000073107C: CC200004 8A02091A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000731084: BF870122
	v_add3_u32 v27, v27, v29, 0x7fff                           // 000000731088: D655001B 03FE3B1B 00007FFF
	v_bfe_u32 v29, v5, 16, 1                                   // 000000731094: D610001D 02052105
	.long 0x7e36399b                                           // 00000073109C: 7E36399B
	.long 0x7f36399c                                           // 0000007310A0: 7F36399C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007310A4: BF870093
	v_add3_u32 v5, v5, v29, 0x7fff                             // 0000007310A8: D6550005 03FE3B05 00007FFF
	v_and_or_b32 v37, 0xffff0000, v5, v27                      // 0000007310B4: D6570025 046E0AFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 0000007310C0: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007310C8: BF870091
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000007310CC: D6550004 03FE0B04 00007FFF
	.long 0x7e383984                                           // 0000007310D8: 7E383984
	v_bfe_i32 v4, v6, 8, 8                                     // 0000007310DC: D6110004 02211106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007310E4: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 0000007310E8: 7E080B04
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 0000007310EC: CC200004 8A02091A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007310F4: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 0000007310F8: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 000000731100: D6550004 03FE0B04 00007FFF
	v_bfe_i32 v5, v6, 16, 8                                    // 00000073110C: D6110005 02212106
	v_ashrrev_i32_e32 v6, 24, v6                               // 000000731114: 340C0C98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000731118: BF870193
	v_and_or_b32 v38, 0xffff0000, v4, v28                      // 00000073111C: D6570026 047208FF FFFF0000
	v_cvt_f32_i32_e32 v5, v5                                   // 000000731128: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000073112C: BF8701A3
	v_cvt_f32_i32_e32 v6, v6                                   // 000000731130: 7E0C0B06
	v_bfe_i32 v4, v7, 0, 8                                     // 000000731134: D6110004 02210107
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 00000073113C: CC200005 8A020B1A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000731144: BF870193
	v_fma_mix_f32 v6, v26, v6, neg(0) op_sel_hi:[1,0,0]        // 000000731148: CC200006 8A020D1A
	v_cvt_f32_i32_e32 v4, v4                                   // 000000731150: 7E080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000731154: BF870113
	v_bfe_u32 v27, v5, 16, 1                                   // 000000731158: D610001B 02052105
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000731160: CC200004 8A02091A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000731168: BF870122
	v_add3_u32 v5, v5, v27, 0x7fff                             // 00000073116C: D6550005 03FE3705 00007FFF
	v_bfe_u32 v27, v6, 16, 1                                   // 000000731178: D610001B 02052106
	.long 0x7e0a3985                                           // 000000731180: 7E0A3985
	.long 0x7f0a399c                                           // 000000731184: 7F0A399C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731188: BF870093
	v_add3_u32 v6, v6, v27, 0x7fff                             // 00000073118C: D6550006 03FE3706 00007FFF
	v_and_or_b32 v39, 0xffff0000, v6, v5                       // 000000731198: D6570027 04160CFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 0000007311A4: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007311AC: BF870091
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000007311B0: D6550004 03FE0B04 00007FFF
	.long 0x7e383984                                           // 0000007311BC: 7E383984
	v_bfe_i32 v4, v7, 8, 8                                     // 0000007311C0: D6110004 02211107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007311C8: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 0000007311CC: 7E080B04
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 0000007311D0: CC200004 8A02091A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007311D8: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 0000007311DC: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000007311E4: D6550004 03FE0B04 00007FFF
	v_bfe_i32 v5, v7, 16, 8                                    // 0000007311F0: D6110005 02212107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007311F8: BF870112
	v_and_or_b32 v40, 0xffff0000, v4, v28                      // 0000007311FC: D6570028 047208FF FFFF0000
	v_cvt_f32_i32_e32 v5, v5                                   // 000000731208: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073120C: BF870091
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 000000731210: CC200005 8A020B1A
	v_bfe_u32 v6, v5, 16, 1                                    // 000000731218: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000731220: BF870121
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000731224: D6550005 03FE0D05 00007FFF
	v_ashrrev_i32_e32 v6, 24, v7                               // 000000731230: 340C0E98
	.long 0x7e0a3985                                           // 000000731234: 7E0A3985
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000731238: BF870122
	v_cvt_f32_i32_e32 v6, v6                                   // 00000073123C: 7E0C0B06
	.long 0x7f0a399c                                           // 000000731240: 7F0A399C
	v_fma_mix_f32 v6, v26, v6, neg(0) op_sel_hi:[1,0,0]        // 000000731244: CC200006 8A020D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073124C: BF870091
	v_bfe_u32 v7, v6, 16, 1                                    // 000000731250: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000731258: D6550006 03FE0F06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000731264: BF870131
	v_and_or_b32 v41, 0xffff0000, v6, v5                       // 000000731268: D6570029 04160CFF FFFF0000
	.long 0xd73c0004                                           // 000000731274: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000731278: 02021681
	v_mov_b32_e32 v11, v25                                     // 00000073127C: 7E160319
	.long 0xd700001e                                           // 000000731280: D700001E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000731284: 02020806
	s_delay_alu instid0(VALU_DEP_1)                            // 000000731288: BF870001
	v_add_co_ci_u32_e64 v31, null, s7, v5, s0                  // 00000073128C: D5207C1F 00020A07
	s_clause 0x1                                               // 000000731294: BF850001
	global_load_b128 v[4:7], v[30:31], off                     // 000000731298: DC5E0000 047C001E
	global_load_b128 v[26:29], v[30:31], off offset:16         // 0000007312A0: DC5E0010 1A7C001E
	s_waitcnt vmcnt(1)                                         // 0000007312A8: BF8907F7
	v_dot2_f32_bf16 v4, v4, v34, 0                             // 0000007312AC: CC1A4004 1A024504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007312B4: BF870091
	v_dot2_f32_bf16 v4, v5, v35, v4                            // 0000007312B8: CC1A4004 1C124705
	v_dot2_f32_bf16 v4, v6, v36, v4                            // 0000007312C0: CC1A4004 1C124906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007312C8: BF8700A1
	v_dot2_f32_bf16 v4, v7, v37, v4                            // 0000007312CC: CC1A4004 1C124B07
	s_waitcnt vmcnt(0)                                         // 0000007312D4: BF8903F7
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 0000007312D8: CC1A4004 1C124D1A
	.long 0xd700001a                                           // 0000007312E0: D700001A
	v_cndmask_b32_e32 v0, v30, v4, vcc_lo                      // 0000007312E4: 0200091E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007312E8: BF8701B2
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000007312EC: CC1A4004 1C124F1B
	v_add_co_ci_u32_e64 v27, null, s5, v31, s0                 // 0000007312F4: D5207C1B 00023E05
	.long 0xd7000020                                           // 0000007312FC: D7000020
	v_cndmask_b32_e32 v0, v30, v14, vcc_lo                     // 000000731300: 02001D1E
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000731304: CC1A4004 1C12511C
	v_add_co_ci_u32_e64 v33, null, s15, v31, s0                // 00000073130C: D5207C21 00023E0F
	.long 0xd700001e                                           // 000000731314: D700001E
	v_cndmask_b32_e32 v0, v30, v18, vcc_lo                     // 000000731318: 0200251E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000073131C: BF870123
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000731320: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v31, null, s16, v31, s0                // 000000731328: D5207C1F 00023E10
	v_add_f32_e32 v23, v23, v4                                 // 000000731330: 062E0917
	s_clause 0x1                                               // 000000731334: BF850001
	global_load_b128 v[4:7], v[26:27], off                     // 000000731338: DC5E0000 047C001A
	global_load_b128 v[26:29], v[26:27], off offset:16         // 000000731340: DC5E0010 1A7C001A
	s_waitcnt vmcnt(1)                                         // 000000731348: BF8907F7
	v_dot2_f32_bf16 v4, v4, v34, 0                             // 00000073134C: CC1A4004 1A024504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731354: BF870091
	v_dot2_f32_bf16 v4, v5, v35, v4                            // 000000731358: CC1A4004 1C124705
	v_dot2_f32_bf16 v4, v6, v36, v4                            // 000000731360: CC1A4004 1C124906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000731368: BF8700A1
	v_dot2_f32_bf16 v4, v7, v37, v4                            // 00000073136C: CC1A4004 1C124B07
	s_waitcnt vmcnt(0)                                         // 000000731374: BF8903F7
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 000000731378: CC1A4004 1C124D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731380: BF870091
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 000000731384: CC1A4004 1C124F1B
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000073138C: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731394: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000731398: CC1A4004 1C12531D
	v_add_f32_e32 v22, v22, v4                                 // 0000007313A0: 062C0916
	s_clause 0x1                                               // 0000007313A4: BF850001
	global_load_b128 v[4:7], v[32:33], off                     // 0000007313A8: DC5E0000 047C0020
	global_load_b128 v[26:29], v[32:33], off offset:16         // 0000007313B0: DC5E0010 1A7C0020
	s_waitcnt vmcnt(1)                                         // 0000007313B8: BF8907F7
	v_dot2_f32_bf16 v4, v4, v34, 0                             // 0000007313BC: CC1A4004 1A024504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007313C4: BF870091
	v_dot2_f32_bf16 v4, v5, v35, v4                            // 0000007313C8: CC1A4004 1C124705
	v_dot2_f32_bf16 v4, v6, v36, v4                            // 0000007313D0: CC1A4004 1C124906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007313D8: BF8700A1
	v_dot2_f32_bf16 v4, v7, v37, v4                            // 0000007313DC: CC1A4004 1C124B07
	s_waitcnt vmcnt(0)                                         // 0000007313E4: BF8903F7
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 0000007313E8: CC1A4004 1C124D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007313F0: BF870091
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000007313F4: CC1A4004 1C124F1B
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000007313FC: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731404: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000731408: CC1A4004 1C12531D
	v_add_f32_e32 v21, v21, v4                                 // 000000731410: 062A0915
	s_clause 0x1                                               // 000000731414: BF850001
	global_load_b128 v[4:7], v[30:31], off                     // 000000731418: DC5E0000 047C001E
	global_load_b128 v[26:29], v[30:31], off offset:16         // 000000731420: DC5E0010 1A7C001E
	s_waitcnt vmcnt(1)                                         // 000000731428: BF8907F7
	v_dot2_f32_bf16 v4, v4, v34, 0                             // 00000073142C: CC1A4004 1A024504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731434: BF870091
	v_dot2_f32_bf16 v4, v5, v35, v4                            // 000000731438: CC1A4004 1C124705
	v_dot2_f32_bf16 v4, v6, v36, v4                            // 000000731440: CC1A4004 1C124906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000731448: BF8700A1
	v_dot2_f32_bf16 v4, v7, v37, v4                            // 00000073144C: CC1A4004 1C124B07
	s_waitcnt vmcnt(0)                                         // 000000731454: BF8903F7
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 000000731458: CC1A4004 1C124D1A
	.long 0xd700001a                                           // 000000731460: D700001A
	v_cndmask_b32_e32 v0, v32, v14, vcc_lo                     // 000000731464: 02001D20
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000731468: BF870122
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 00000073146C: CC1A4004 1C124F1B
	v_add_co_ci_u32_e64 v27, null, s15, v33, s0                // 000000731474: D5207C1B 0002420F
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000073147C: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731484: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000731488: CC1A4004 1C12531D
	v_add_f32_e32 v20, v20, v4                                 // 000000731490: 06280914
	s_clause 0x1                                               // 000000731494: BF850001
	global_load_b128 v[4:7], v[26:27], off                     // 000000731498: DC5E0000 047C001A
	global_load_b128 v[26:29], v[26:27], off offset:16         // 0000007314A0: DC5E0010 1A7C001A
	s_waitcnt vmcnt(1)                                         // 0000007314A8: BF8907F7
	v_dot2_f32_bf16 v4, v4, v34, 0                             // 0000007314AC: CC1A4004 1A024504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007314B4: BF870091
	v_dot2_f32_bf16 v4, v5, v35, v4                            // 0000007314B8: CC1A4004 1C124705
	v_dot2_f32_bf16 v4, v6, v36, v4                            // 0000007314C0: CC1A4004 1C124906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007314C8: BF8700A1
	v_dot2_f32_bf16 v4, v7, v37, v4                            // 0000007314CC: CC1A4004 1C124B07
	s_waitcnt vmcnt(0)                                         // 0000007314D4: BF8903F7
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 0000007314D8: CC1A4004 1C124D1A
	.long 0xd700001a                                           // 0000007314E0: D700001A
	v_cndmask_b32_e32 v0, v30, v14, vcc_lo                     // 0000007314E4: 02001D1E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007314E8: BF8701B2
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000007314EC: CC1A4004 1C124F1B
	v_add_co_ci_u32_e64 v27, null, s15, v31, s0                // 0000007314F4: D5207C1B 00023E0F
	.long 0xd700000d                                           // 0000007314FC: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 000000731500: 0201410D
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000731504: CC1A4004 1C12511C
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 00000073150C: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731514: BF870092
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000731518: CC1A4004 1C12531D
	v_add_f32_e32 v19, v19, v4                                 // 000000731520: 06260913
	s_clause 0x1                                               // 000000731524: BF850001
	global_load_b128 v[4:7], v[26:27], off                     // 000000731528: DC5E0000 047C001A
	global_load_b128 v[26:29], v[26:27], off offset:16         // 000000731530: DC5E0010 1A7C001A
	s_waitcnt vmcnt(1)                                         // 000000731538: BF8907F7
	v_dot2_f32_bf16 v4, v4, v34, 0                             // 00000073153C: CC1A4004 1A024504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000731544: BF870121
	v_dot2_f32_bf16 v4, v5, v35, v4                            // 000000731548: CC1A4004 1C124705
	v_mov_b32_e32 v5, v1                                       // 000000731550: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v36, v4                            // 000000731554: CC1A4004 1C124906
	v_mov_b32_e32 v6, v2                                       // 00000073155C: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000731560: BF870132
	v_dot2_f32_bf16 v4, v7, v37, v4                            // 000000731564: CC1A4004 1C124B07
	v_mov_b32_e32 v7, v3                                       // 00000073156C: 7E0E0303
	s_waitcnt vmcnt(0)                                         // 000000731570: BF8903F7
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 000000731574: CC1A4004 1C124D1A
	.long 0x7e343908                                           // 00000073157C: 7E343908
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731580: BF870092
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 000000731584: CC1A4004 1C124F1B
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000073158C: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731594: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000731598: CC1A4004 1C12531D
	v_add_f32_e32 v16, v16, v4                                 // 0000007315A0: 06200910
	v_mov_b32_e32 v4, v0                                       // 0000007315A4: 7E080300
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 0000007315A8: 917E117E
	s_cbranch_execz 29                                         // 0000007315AC: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi1ELb1EEEvPKhPKtPvll+0x924>
	v_add_nc_u32_e32 v24, 32, v24                              // 0000007315B0: 4A3030A0
	v_add_nc_u32_e32 v25, 0x200, v11                           // 0000007315B4: 4A3216FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007315BC: BF8704A2
	.long 0xd4430000                                           // 0000007315C0: D4430000
	v_cndmask_b32_e32 v1, s2, v24, vcc_lo                      // 0000007315C4: 02023002
	s_and_saveexec_b32 s1, s0                                  // 0000007315C8: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 0000007315CC: 8D01017E
	v_add_nc_u32_e32 v25, 0x200, v11                           // 0000007315D0: 4A3216FF 00000200
	s_or_saveexec_b32 s10, s1                                  // 0000007315D8: BE8A2201
	s_waitcnt vmcnt(0)                                         // 0000007315DC: BF8903F7
	.long 0x7e10391a                                           // 0000007315E0: 7E10391A
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v1, v5             // 0000007315E4: CA100104 00000105
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 0000007315EC: CA100106 02020107
	s_xor_b32 exec_lo, exec_lo, s10                            // 0000007315F4: 8D7E0A7E
	s_cbranch_execz 65075                                      // 0000007315F8: BFA5FE33 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi1ELb1EEEvPKhPKtPvll+0x1c8>
	.long 0xd7000100                                           // 0000007315FC: D7000100
	v_cndmask_b32_e32 v1, v17, v25, vcc_lo                     // 000000731600: 02023311
	s_delay_alu instid0(VALU_DEP_1)                            // 000000731604: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v18, s1                   // 000000731608: D5207C01 00062480
	global_load_b128 v[0:3], v[0:1], off                       // 000000731610: DC5E0000 007C0000
	global_load_d16_b16 v8, v[13:14], off                      // 000000731618: DC820000 087C000D
	s_branch 65065                                             // 000000731620: BFA0FE29 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi1ELb1EEEvPKhPKtPvll+0x1c8>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000731624: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000731628: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000073162C: 8C7E037E
	.long 0xd71f0000                                           // 000000731630: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000731634: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000731638: 3A020090
	s_waitcnt vmcnt(1)                                         // 00000073163C: BF8907F7
	v_xor_b32_e32 v7, 8, v0                                    // 000000731640: 3A0E0088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731644: BF870092
	.long 0xd44c0000                                           // 000000731648: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 00000073164C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000731650: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000731658: BF870113
	.long 0xd44c0000                                           // 00000073165C: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 000000731660: 02020EA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000731664: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000731668: BF870002
	v_cndmask_b32_e64 v7, v0, v7, s0                           // 00000073166C: D5010007 00020F00
	ds_bpermute_b32 v2, v1, v23                                // 000000731674: DACC0000 02001701
	s_waitcnt lgkmcnt(0)                                       // 00000073167C: BF89FC07
	v_add_f32_e32 v2, v23, v2                                  // 000000731680: 06040517
	ds_bpermute_b32 v4, v1, v21                                // 000000731684: DACC0000 04001501
	ds_bpermute_b32 v3, v1, v22                                // 00000073168C: DACC0000 03001601
	ds_bpermute_b32 v5, v1, v20                                // 000000731694: DACC0000 05001401
	ds_bpermute_b32 v6, v1, v19                                // 00000073169C: DACC0000 06001301
	ds_bpermute_b32 v1, v1, v16                                // 0000007316A4: DACC0000 01001001
	s_waitcnt lgkmcnt(4)                                       // 0000007316AC: BF89FC47
	v_dual_add_f32 v4, v21, v4 :: v_dual_lshlrev_b32 v7, 2, v7 // 0000007316B0: C9220915 04060E82
	ds_bpermute_b32 v8, v7, v2                                 // 0000007316B8: DACC0000 08000207
	s_waitcnt lgkmcnt(2)                                       // 0000007316C0: BF89FC27
	v_dual_add_f32 v3, v22, v3 :: v_dual_add_f32 v6, v19, v6   // 0000007316C4: C9080716 03060D13
	s_waitcnt lgkmcnt(1)                                       // 0000007316CC: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 0000007316D0: 06020310
	v_xor_b32_e32 v16, 4, v0                                   // 0000007316D4: 3A200084
	ds_bpermute_b32 v12, v7, v4                                // 0000007316D8: DACC0000 0C000407
	ds_bpermute_b32 v11, v7, v3                                // 0000007316E0: DACC0000 0B000307
	ds_bpermute_b32 v14, v7, v6                                // 0000007316E8: DACC0000 0E000607
	.long 0xd44c0000                                           // 0000007316F0: D44C0000
	v_cndmask_b32_e32 v1, 32, v16, vcc_lo                      // 0000007316F4: 020220A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007316F8: BF870091
	v_cndmask_b32_e64 v16, v0, v16, s0                         // 0000007316FC: D5010010 00022100
	v_dual_add_f32 v5, v20, v5 :: v_dual_lshlrev_b32 v16, 2, v16// 000000731704: C9220B14 05102082
	ds_bpermute_b32 v13, v7, v5                                // 00000073170C: DACC0000 0D000507
	s_waitcnt lgkmcnt(4)                                       // 000000731714: BF89FC47
	v_add_f32_e32 v2, v2, v8                                   // 000000731718: 06041102
	ds_bpermute_b32 v7, v7, v1                                 // 00000073171C: DACC0000 07000107
	s_waitcnt lgkmcnt(3)                                       // 000000731724: BF89FC37
	v_dual_add_f32 v4, v4, v12 :: v_dual_add_f32 v3, v3, v11   // 000000731728: C9081904 04021703
	s_waitcnt lgkmcnt(2)                                       // 000000731730: BF89FC27
	v_add_f32_e32 v6, v6, v14                                  // 000000731734: 060C1D06
	ds_bpermute_b32 v11, v16, v4                               // 000000731738: DACC0000 0B000410
	ds_bpermute_b32 v8, v16, v3                                // 000000731740: DACC0000 08000310
	s_waitcnt lgkmcnt(3)                                       // 000000731748: BF89FC37
	v_add_f32_e32 v5, v5, v13                                  // 00000073174C: 060A1B05
	ds_bpermute_b32 v13, v16, v6                               // 000000731750: DACC0000 0D000610
	s_waitcnt lgkmcnt(3)                                       // 000000731758: BF89FC37
	v_add_f32_e32 v1, v1, v7                                   // 00000073175C: 06020F01
	ds_bpermute_b32 v7, v16, v2                                // 000000731760: DACC0000 07000210
	ds_bpermute_b32 v12, v16, v5                               // 000000731768: DACC0000 0C000510
	ds_bpermute_b32 v14, v16, v1                               // 000000731770: DACC0000 0E000110
	v_xor_b32_e32 v16, 2, v0                                   // 000000731778: 3A200082
	s_waitcnt lgkmcnt(5)                                       // 00000073177C: BF89FC57
	v_add_f32_e32 v4, v4, v11                                  // 000000731780: 06081704
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731784: BF870092
	.long 0xd44c0000                                           // 000000731788: D44C0000
	v_cndmask_b32_e32 v1, 32, v16, vcc_lo                      // 00000073178C: 020220A0
	v_cndmask_b32_e64 v16, v0, v16, s0                         // 000000731790: D5010010 00022100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000731798: BF870001
	v_lshlrev_b32_e32 v16, 2, v16                              // 00000073179C: 30202082
	s_waitcnt lgkmcnt(2)                                       // 0000007317A0: BF89FC27
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v7, v3, v8     // 0000007317A4: C9080F02 02061103
	v_xor_b32_e32 v3, 1, v0                                    // 0000007317AC: 3A060081
	s_waitcnt lgkmcnt(0)                                       // 0000007317B0: BF89FC07
	v_add_f32_e32 v8, v1, v14                                  // 0000007317B4: 06101D01
	v_add_f32_e32 v5, v5, v12                                  // 0000007317B8: 060A1905
	ds_bpermute_b32 v1, v16, v2                                // 0000007317BC: DACC0000 01000210
	ds_bpermute_b32 v11, v16, v7                               // 0000007317C4: DACC0000 0B000710
	.long 0xd44c0000                                           // 0000007317CC: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000007317D0: 020206A0
	ds_bpermute_b32 v12, v16, v4                               // 0000007317D4: DACC0000 0C000410
	v_cndmask_b32_e64 v0, v0, v3, s0                           // 0000007317DC: D5010000 00020700
	v_add_f32_e32 v6, v6, v13                                  // 0000007317E4: 060C1B06
	ds_bpermute_b32 v13, v16, v5                               // 0000007317E8: DACC0000 0D000510
	.long 0xd44a0000                                           // 0000007317F0: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 0000007317F4: 02021E80
	v_lshlrev_b32_e32 v17, 2, v0                               // 0000007317F8: 30220082
	ds_bpermute_b32 v14, v16, v6                               // 0000007317FC: DACC0000 0E000610
	s_and_b32 s0, s0, vcc_lo                                   // 000000731804: 8B006A00
	s_waitcnt lgkmcnt(4)                                       // 000000731808: BF89FC47
	v_add_f32_e32 v3, v2, v1                                   // 00000073180C: 06060302
	ds_bpermute_b32 v16, v16, v8                               // 000000731810: DACC0000 10000810
	s_waitcnt lgkmcnt(3)                                       // 000000731818: BF89FC37
	v_dual_add_f32 v0, v7, v11 :: v_dual_add_f32 v1, v4, v12   // 00000073181C: C9081707 00001904
	ds_bpermute_b32 v11, v17, v3                               // 000000731824: DACC0000 0B000311
	s_waitcnt lgkmcnt(3)                                       // 00000073182C: BF89FC37
	v_add_f32_e32 v2, v5, v13                                  // 000000731830: 06041B05
	ds_bpermute_b32 v5, v17, v0                                // 000000731834: DACC0000 05000011
	s_waitcnt lgkmcnt(3)                                       // 00000073183C: BF89FC37
	v_add_f32_e32 v4, v6, v14                                  // 000000731840: 06081D06
	ds_bpermute_b32 v6, v17, v1                                // 000000731844: DACC0000 06000111
	ds_bpermute_b32 v7, v17, v2                                // 00000073184C: DACC0000 07000211
	ds_bpermute_b32 v12, v17, v4                               // 000000731854: DACC0000 0C000411
	s_waitcnt lgkmcnt(5)                                       // 00000073185C: BF89FC57
	v_add_f32_e32 v8, v8, v16                                  // 000000731860: 06102108
	ds_bpermute_b32 v13, v17, v8                               // 000000731864: DACC0000 0D000811
	s_and_saveexec_b32 s1, s0                                  // 00000073186C: BE812000
	s_cbranch_execz 52                                         // 000000731870: BFA50034 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi1ELb1EEEvPKhPKtPvll+0xc44>
	.long 0xd73c0009                                           // 000000731874: D73C0009
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000731878: 02021282
	s_waitcnt lgkmcnt(0)                                       // 00000073187C: BF89FC07
	v_add_f32_e32 v13, v8, v13                                 // 000000731880: 061A1B08
	v_dual_add_f32 v3, v3, v11 :: v_dual_add_f32 v14, v1, v6   // 000000731884: C9081703 030E0D01
	v_add_f32_e32 v15, v0, v5                                  // 00000073188C: 061E0B00
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000731890: 8480820C
	.long 0xd7006a08                                           // 000000731894: D7006A08
	v_cndmask_b32_e32 v1, s8, v9, vcc_lo                       // 000000731898: 02021208
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000073189C: BF870121
	v_add_co_ci_u32_e64 v9, null, s9, v10, vcc_lo              // 0000007318A0: D5207C09 01AA1409
	v_dual_add_f32 v11, v4, v12 :: v_dual_add_f32 v12, v2, v7  // 0000007318A8: C9081904 0B0C0F02
	v_mad_u64_u32 v[0:1], null, s12, 12, v[8:9]                // 0000007318B0: D6FE7C00 0421180C
	global_store_b32 v[8:9], v3, off                           // 0000007318B8: DC6A0000 007C0308
	.long 0xd7006a03                                           // 0000007318C0: D7006A03
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 0000007318C4: 02000108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007318C8: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s1, v9, vcc_lo               // 0000007318CC: D5207C04 01AA1201
	s_lshl_b64 s[0:1], s[12:13], 3                             // 0000007318D4: 8480830C
	.long 0xd7006a05                                           // 0000007318D8: D7006A05
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 0000007318DC: 02000108
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 0000007318E0: D6FE7C01 0405180D
	v_add_co_ci_u32_e64 v6, null, s1, v9, vcc_lo               // 0000007318E8: D5207C06 01AA1201
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007318F0: BF870093
	.long 0xd7006a07                                           // 0000007318F4: D7006A07
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 0000007318F8: 02000105
	v_add_co_ci_u32_e64 v8, null, s1, v6, vcc_lo               // 0000007318FC: D5207C08 01AA0C01
	.long 0xd7006a09                                           // 000000731904: D7006A09
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000731908: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000073190C: BF870001
	v_add_co_ci_u32_e64 v10, null, s1, v1, vcc_lo              // 000000731910: D5207C0A 01AA0201
	s_clause 0x4                                               // 000000731918: BF850004
	global_store_b32 v[3:4], v15, off                          // 00000073191C: DC6A0000 007C0F03
	global_store_b32 v[5:6], v14, off                          // 000000731924: DC6A0000 007C0E05
	global_store_b32 v[0:1], v12, off                          // 00000073192C: DC6A0000 007C0C00
	global_store_b32 v[7:8], v11, off                          // 000000731934: DC6A0000 007C0B07
	global_store_b32 v[9:10], v13, off                         // 00000073193C: DC6A0000 007C0D09
	s_endpgm                                                   // 000000731944: BFB00000
		...

