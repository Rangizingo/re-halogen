0000000000754000 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000754000: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v1, 15, v0          // 000000754008: CA240080 0400008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000754010: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000754014: 86039F02
	s_delay_alu instid0(VALU_DEP_2)                            // 000000754018: BF870002
	v_dual_mov_b32 v16, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 00000075401C: CA220080 10000282
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000754024: 84808302
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 000000754028: BF870482
	v_dual_mov_b32 v9, s1 :: v_dual_and_b32 v2, 60, v2         // 00000075402C: CA240001 090204BC
	.long 0x7f183880                                           // 000000754034: 7F183880
	v_and_b32_e32 v15, 31, v0                                  // 000000754038: 361E009F
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v6, 0              // 00000075403C: CA100080 19060080
	s_waitcnt lgkmcnt(0)                                       // 000000754044: BF89FC07
	s_clause 0x1                                               // 000000754048: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000075404C: DC520000 03040001
	global_load_b32 v7, v2, s[4:5]                             // 000000754054: DC520000 07040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000075405C: 32020085
	s_add_u32 s2, s4, s14                                      // 000000754060: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000754064: 82030F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000754068: BF8704A1
	v_or_b32_e32 v8, s0, v1                                    // 00000075406C: 38100200
	s_lshr_b32 s0, s11, 31                                     // 000000754070: 85009F0B
	s_add_u32 s14, s10, s0                                     // 000000754074: 800E000A
	s_addc_u32 s15, s11, 0                                     // 000000754078: 820F800B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075407C: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 000000754080: 7CA8100C
	v_mov_b32_e32 v5, 0                                        // 000000754084: 7E0A0280
	s_ashr_i32 s20, s11, 31                                    // 000000754088: 86149F0B
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 00000075408C: 02141080
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 000000754090: D501000E 01A80280
	s_ashr_i64 s[0:1], s[14:15], 1                             // 000000754098: 8680810E
	s_lshr_b32 s14, s20, 27                                    // 00000075409C: 850E9B14
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007540A0: BF870002
	.long 0xd72c000d                                           // 0000007540A4: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 0000007540A8: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 0000007540AC: D6FE7C01 02021412
	.long 0xd72c0011                                           // 0000007540B4: D72C0011
	v_cndmask_b32_e32 v0, v10, v1, vcc_lo                      // 0000007540B8: 0200030A
	.long 0xd72c0013                                           // 0000007540BC: D72C0013
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 0000007540C0: 0200010E
	s_waitcnt vmcnt(1)                                         // 0000007540C4: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 0000007540C8: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 0000007540D0: BF8903F7
	v_bfe_u32 v18, v7, 16, 1                                   // 0000007540D4: D6100012 02052107
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007540DC: BF870002
	v_add3_u32 v3, v3, v11, 0x7fff                             // 0000007540E0: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[10:11], null, v10, s0, s[2:3]              // 0000007540EC: D6FE7C0A 0008010A
	s_add_u32 s2, s10, s14                                     // 0000007540F4: 80020E0A
	v_add3_u32 v7, v7, v18, 0x7fff                             // 0000007540F8: D6550007 03FE2507 00007FFF
	s_addc_u32 s3, s11, 0                                      // 000000754104: 8203800B
	.long 0x7e183983                                           // 000000754108: 7E183983
	.long 0xd72c0003                                           // 00000075410C: D72C0003
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 000000754110: 02021C12
	s_lshr_b64 s[2:3], s[2:3], 5                               // 000000754114: 85828502
	v_lshlrev_b32_e32 v14, 2, v0                               // 000000754118: 301C0082
	.long 0xd4440000                                           // 00000075411C: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 000000754120: 02021E02
	v_and_or_b32 v12, 0xffff0000, v7, v12                      // 000000754124: D657000C 04320EFF FFFF0000
	v_mov_b32_e32 v7, 0                                        // 000000754130: 7E0E0280
	v_add3_u32 v17, v19, v11, v17                              // 000000754134: D6550011 04461713
	v_add3_u32 v0, v2, v3, v13                                 // 00000075413C: D6550000 04360702
	ds_store_b32 v14, v12                                      // 000000754144: D8340000 00000C0E
	s_waitcnt lgkmcnt(0)                                       // 00000075414C: BF89FC07
	s_barrier                                                  // 000000754150: BFBD0000
	buffer_gl0_inv                                             // 000000754154: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 00000075415C: BE832000
	s_cbranch_execz 26                                         // 000000754160: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1cc>
	s_add_u32 s1, s4, s16                                      // 000000754164: 80011004
	s_addc_u32 s14, s5, s17                                    // 000000754168: 820E1105
	v_lshlrev_b32_e32 v2, 1, v15                               // 00000075416C: 30041E81
	.long 0xd7000103                                           // 000000754170: D7000103
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 000000754174: 02020201
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000754178: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s14, v0, s1                  // 00000075417C: D5207C04 0006000E
	v_lshlrev_b32_e32 v5, 4, v15                               // 000000754184: 300A1E84
	.long 0xd7000102                                           // 000000754188: D7000102
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000075418C: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000754190: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s1                    // 000000754194: D5207C03 00060880
	.long 0xd7000104                                           // 00000075419C: D7000104
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 0000007541A0: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007541A4: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s1                   // 0000007541A8: D5207C05 00062280
	s_clause 0x1                                               // 0000007541B0: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 0000007541B4: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 0000007541BC: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 0000007541C4: BF8907F7
	v_cvt_f32_f16_e32 v25, v2                                  // 0000007541C8: 7E321702
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007541CC: 8C7E037E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 0000007541D0: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 0000007541D8: CA100080 14140080
	s_and_saveexec_b32 s3, s0                                  // 0000007541E0: BE832000
	s_cbranch_execz 478                                        // 0000007541E4: BFA501DE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x960>
	s_mul_i32 s0, s11, 6                                       // 0000007541E8: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 0000007541EC: 9681860A
	v_dual_mov_b32 v23, v15 :: v_dual_lshlrev_b32 v2, 1, v15   // 0000007541F0: CA22010F 17021E81
	s_add_i32 s18, s1, s0                                      // 0000007541F8: 81120001
	.long 0xd7000001                                           // 0000007541FC: D7000001
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 000000754200: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000754204: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s0                  // 000000754208: D5207C00 00020011
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 000000754210: CA220080 0C0A1E85
	.long 0xd7000001                                           // 000000754218: D7000001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000075421C: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000754220: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s0                    // 000000754224: D5207C00 00020080
	v_lshl_or_b32 v22, v15, 4, 0x200                           // 00000075422C: D6560016 03FD090F 00000200
	.long 0xd7000001                                           // 000000754238: D7000001
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000075423C: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000754240: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s0                   // 000000754244: D5207C00 00020005
	v_dual_mov_b32 v21, v12 :: v_dual_mov_b32 v24, v25         // 00000075424C: CA10010C 15180119
	.long 0xd700000d                                           // 000000754254: D700000D
	v_cndmask_b32_e32 v0, v1, v192, vcc_lo                     // 000000754258: 02018101
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075425C: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s0                   // 000000754260: D5207C0E 00020080
	v_mov_b32_e32 v20, v12                                     // 000000754268: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 00000075426C: 7E26030C
	v_mov_b32_e32 v18, v12                                     // 000000754270: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 000000754274: 7E20030C
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000754278: 848E820A
	s_mul_i32 s17, s10, 6                                      // 00000075427C: 9611860A
	s_mov_b32 s16, 0                                           // 000000754280: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000754284: 8484810A
	s_branch 411                                               // 000000754288: BFA0019B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x8f8>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000075428C: 8C7E0A7E
	v_and_b32_e32 v26, 0xff, v4                                // 000000754290: 363408FF 000000FF
	s_and_b32 s0, exec_lo, s0                                  // 000000754298: 8B00007E
	v_add_nc_u32_e32 v22, 0x200, v22                           // 00000075429C: 4A2C2CFF 00000200
	s_or_b32 s16, s0, s16                                      // 0000007542A4: 8C101000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007542A8: BF8700B2
	v_lshlrev_b32_e32 v26, 2, v26                              // 0000007542AC: 30343482
	ds_load_b32 v42, v26                                       // 0000007542B0: D8D80000 2A00001A
	v_lshrrev_b32_e32 v26, 6, v4                               // 0000007542B8: 32340886
	v_and_b32_e32 v26, 0x3fc, v26                              // 0000007542BC: 363434FF 000003FC
	ds_load_b32 v43, v26                                       // 0000007542C4: D8D80000 2B00001A
	v_lshrrev_b32_e32 v26, 14, v4                              // 0000007542CC: 3234088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000007542D0: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007542D4: BF870112
	v_and_b32_e32 v26, 0x3fc, v26                              // 0000007542D8: 363434FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007542E0: 360808FF 000003FC
	ds_load_b32 v44, v26                                       // 0000007542E8: D8D80000 2C00001A
	ds_load_b32 v45, v4                                        // 0000007542F0: D8D80000 2D000004
	v_and_b32_e32 v4, 0xff, v5                                 // 0000007542F8: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000754300: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000754304: 30080882
	ds_load_b32 v46, v4                                        // 000000754308: D8D80000 2E000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 000000754310: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000754314: 360808FF 000003FC
	ds_load_b32 v47, v4                                        // 00000075431C: D8D80000 2F000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 000000754324: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000754328: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000075432C: 360808FF 000003FC
	ds_load_b32 v48, v4                                        // 000000754334: D8D80000 30000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 00000075433C: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000754340: 360808FF 000003FC
	ds_load_b32 v49, v4                                        // 000000754348: D8D80000 31000004
	v_and_b32_e32 v4, 0xff, v6                                 // 000000754350: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000754358: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000075435C: 30080882
	ds_load_b32 v50, v4                                        // 000000754360: D8D80000 32000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 000000754368: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000075436C: 360808FF 000003FC
	ds_load_b32 v51, v4                                        // 000000754374: D8D80000 33000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 00000075437C: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000754380: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000754384: 360808FF 000003FC
	ds_load_b32 v52, v4                                        // 00000075438C: D8D80000 34000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 000000754394: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000754398: 360808FF 000003FC
	ds_load_b32 v53, v4                                        // 0000007543A0: D8D80000 35000004
	v_and_b32_e32 v4, 0xff, v7                                 // 0000007543A8: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007543B0: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007543B4: 30080882
	ds_load_b32 v54, v4                                        // 0000007543B8: D8D80000 36000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 0000007543C0: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007543C4: 360808FF 000003FC
	ds_load_b32 v55, v4                                        // 0000007543CC: D8D80000 37000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 0000007543D4: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007543D8: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007543DC: 360808FF 000003FC
	ds_load_b32 v56, v4                                        // 0000007543E4: D8D80000 38000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 0000007543EC: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007543F0: 360808FF 000003FC
	ds_load_b32 v57, v4                                        // 0000007543F8: D8D80000 39000004
	.long 0xd73c0004                                           // 000000754400: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000754404: 02021681
	v_add_nc_u32_e32 v11, 0x400, v11                           // 000000754408: 4A1616FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000754410: BF870092
	.long 0xd7000026                                           // 000000754414: D7000026
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000754418: 02020806
	v_add_co_ci_u32_e64 v39, null, s7, v5, s0                  // 00000075441C: D5207C27 00020A07
	s_clause 0x3                                               // 000000754424: BF850003
	global_load_b128 v[4:7], v[38:39], off                     // 000000754428: DC5E0000 047C0026
	global_load_b128 v[26:29], v[38:39], off offset:16         // 000000754430: DC5E0010 1A7C0026
	global_load_b128 v[30:33], v[38:39], off offset:32         // 000000754438: DC5E0020 1E7C0026
	global_load_b128 v[34:37], v[38:39], off offset:48         // 000000754440: DC5E0030 227C0026
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000754448: BF890CF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 00000075444C: CC1A4004 1A025504
	s_waitcnt lgkmcnt(14)                                      // 000000754454: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000754458: BF8700A1
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 00000075445C: CC1A4004 1C125705
	s_waitcnt lgkmcnt(13)                                      // 000000754464: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 000000754468: CC1A4004 1C125906
	s_waitcnt lgkmcnt(12)                                      // 000000754470: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000754474: BF8700A1
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 000000754478: CC1A4004 1C125B07
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000754480: BF8908B7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 000000754484: CC1A4004 1C125D1A
	s_waitcnt lgkmcnt(10)                                      // 00000075448C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000754490: BF8700A1
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000754494: CC1A4004 1C125F1B
	s_waitcnt lgkmcnt(9)                                       // 00000075449C: BF89FC97
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007544A0: CC1A4004 1C12611C
	s_waitcnt lgkmcnt(8)                                       // 0000007544A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007544AC: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007544B0: CC1A4004 1C12631D
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000007544B8: BF890477
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007544BC: CC1A4004 1C12651E
	s_waitcnt lgkmcnt(6)                                       // 0000007544C4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007544C8: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007544CC: CC1A4004 1C12671F
	s_waitcnt lgkmcnt(5)                                       // 0000007544D4: BF89FC57
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007544D8: CC1A4004 1C126920
	s_waitcnt lgkmcnt(4)                                       // 0000007544E0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007544E4: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007544E8: CC1A4004 1C126B21
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007544F0: BF890037
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007544F4: CC1A4004 1C126D22
	.long 0xd7000022                                           // 0000007544FC: D7000022
	v_cndmask_b32_e32 v0, v38, v4, vcc_lo                      // 000000754500: 02000926
	s_waitcnt lgkmcnt(2)                                       // 000000754504: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000754508: BF8701C2
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000075450C: CC1A4004 1C126F23
	v_add_co_ci_u32_e64 v35, null, s5, v39, s0                 // 000000754514: D5207C23 00024E05
	.long 0xd7000028                                           // 00000075451C: D7000028
	v_cndmask_b32_e32 v0, v38, v14, vcc_lo                     // 000000754520: 02001D26
	s_waitcnt lgkmcnt(1)                                       // 000000754524: BF89FC17
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000754528: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v41, null, s15, v39, s0                // 000000754530: D5207C29 00024E0F
	s_waitcnt lgkmcnt(0)                                       // 000000754538: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075453C: BF870092
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000754540: CC1A4004 1C127325
	v_fmac_f32_e32 v21, v25, v4                                // 000000754548: 562A0919
	s_clause 0x3                                               // 00000075454C: BF850003
	global_load_b128 v[4:7], v[34:35], off                     // 000000754550: DC5E0000 047C0022
	global_load_b128 v[26:29], v[34:35], off offset:16         // 000000754558: DC5E0010 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:32         // 000000754560: DC5E0020 1E7C0022
	global_load_b128 v[34:37], v[34:35], off offset:48         // 000000754568: DC5E0030 227C0022
	s_waitcnt vmcnt(3)                                         // 000000754570: BF890FF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 000000754574: CC1A4004 1A025504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075457C: BF870091
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 000000754580: CC1A4004 1C125705
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 000000754588: CC1A4004 1C125906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000754590: BF8700A1
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 000000754594: CC1A4004 1C125B07
	s_waitcnt vmcnt(2)                                         // 00000075459C: BF890BF7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 0000007545A0: CC1A4004 1C125D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007545A8: BF870091
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 0000007545AC: CC1A4004 1C125F1B
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007545B4: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007545BC: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007545C0: CC1A4004 1C12631D
	s_waitcnt vmcnt(1)                                         // 0000007545C8: BF8907F7
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007545CC: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007545D4: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007545D8: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007545E0: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007545E8: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007545EC: CC1A4004 1C126B21
	s_waitcnt vmcnt(0)                                         // 0000007545F4: BF8903F7
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007545F8: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000754600: BF870091
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000754604: CC1A4004 1C126F23
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000075460C: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000754614: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000754618: CC1A4004 1C127325
	v_fmac_f32_e32 v20, v25, v4                                // 000000754620: 56280919
	s_clause 0x3                                               // 000000754624: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 000000754628: DC5E0000 047C0028
	global_load_b128 v[26:29], v[40:41], off offset:16         // 000000754630: DC5E0010 1A7C0028
	global_load_b128 v[30:33], v[40:41], off offset:32         // 000000754638: DC5E0020 1E7C0028
	global_load_b128 v[34:37], v[40:41], off offset:48         // 000000754640: DC5E0030 227C0028
	s_waitcnt vmcnt(3)                                         // 000000754648: BF890FF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 00000075464C: CC1A4004 1A025504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000754654: BF870091
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 000000754658: CC1A4004 1C125705
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 000000754660: CC1A4004 1C125906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000754668: BF8700A1
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 00000075466C: CC1A4004 1C125B07
	s_waitcnt vmcnt(2)                                         // 000000754674: BF890BF7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 000000754678: CC1A4004 1C125D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000754680: BF870091
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000754684: CC1A4004 1C125F1B
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000075468C: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000754694: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000754698: CC1A4004 1C12631D
	s_waitcnt vmcnt(1)                                         // 0000007546A0: BF8907F7
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007546A4: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007546AC: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007546B0: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007546B8: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007546C0: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007546C4: CC1A4004 1C126B21
	s_waitcnt vmcnt(0)                                         // 0000007546CC: BF8903F7
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007546D0: CC1A4004 1C126D22
	.long 0xd7000022                                           // 0000007546D8: D7000022
	v_cndmask_b32_e32 v0, v38, v17, vcc_lo                     // 0000007546DC: 02002326
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007546E0: BF870122
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007546E4: CC1A4004 1C126F23
	v_add_co_ci_u32_e64 v35, null, s18, v39, s0                // 0000007546EC: D5207C23 00024E12
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007546F4: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007546FC: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000754700: CC1A4004 1C127325
	v_fmac_f32_e32 v19, v25, v4                                // 000000754708: 56260919
	s_clause 0x3                                               // 00000075470C: BF850003
	global_load_b128 v[4:7], v[34:35], off                     // 000000754710: DC5E0000 047C0022
	global_load_b128 v[26:29], v[34:35], off offset:16         // 000000754718: DC5E0010 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:32         // 000000754720: DC5E0020 1E7C0022
	global_load_b128 v[34:37], v[34:35], off offset:48         // 000000754728: DC5E0030 227C0022
	s_waitcnt vmcnt(3)                                         // 000000754730: BF890FF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 000000754734: CC1A4004 1A025504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075473C: BF870091
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 000000754740: CC1A4004 1C125705
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 000000754748: CC1A4004 1C125906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000754750: BF8700A1
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 000000754754: CC1A4004 1C125B07
	s_waitcnt vmcnt(2)                                         // 00000075475C: BF890BF7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 000000754760: CC1A4004 1C125D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000754768: BF870091
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000075476C: CC1A4004 1C125F1B
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000754774: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075477C: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000754780: CC1A4004 1C12631D
	s_waitcnt vmcnt(1)                                         // 000000754788: BF8907F7
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000075478C: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000754794: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000754798: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007547A0: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007547A8: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007547AC: CC1A4004 1C126B21
	s_waitcnt vmcnt(0)                                         // 0000007547B4: BF8903F7
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007547B8: CC1A4004 1C126D22
	.long 0xd7000022                                           // 0000007547C0: D7000022
	v_cndmask_b32_e32 v0, v40, v14, vcc_lo                     // 0000007547C4: 02001D28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007547C8: BF8701B2
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007547CC: CC1A4004 1C126F23
	v_add_co_ci_u32_e64 v35, null, s15, v41, s0                // 0000007547D4: D5207C23 0002520F
	.long 0xd700000d                                           // 0000007547DC: D700000D
	v_cndmask_b32_e32 v0, v13, v192, vcc_lo                    // 0000007547E0: 0201810D
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007547E4: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 0000007547EC: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007547F4: BF870092
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007547F8: CC1A4004 1C127325
	v_fmac_f32_e32 v18, v25, v4                                // 000000754800: 56240919
	s_clause 0x3                                               // 000000754804: BF850003
	global_load_b128 v[4:7], v[34:35], off                     // 000000754808: DC5E0000 047C0022
	global_load_b128 v[26:29], v[34:35], off offset:16         // 000000754810: DC5E0010 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:32         // 000000754818: DC5E0020 1E7C0022
	global_load_b128 v[34:37], v[34:35], off offset:48         // 000000754820: DC5E0030 227C0022
	s_waitcnt vmcnt(3)                                         // 000000754828: BF890FF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 00000075482C: CC1A4004 1A025504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000754834: BF870121
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 000000754838: CC1A4004 1C125705
	v_mov_b32_e32 v5, v1                                       // 000000754840: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 000000754844: CC1A4004 1C125906
	v_mov_b32_e32 v6, v2                                       // 00000075484C: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000754850: BF870132
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 000000754854: CC1A4004 1C125B07
	v_mov_b32_e32 v7, v3                                       // 00000075485C: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 000000754860: BF890BF7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 000000754864: CC1A4004 1C125D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075486C: BF870091
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000754870: CC1A4004 1C125F1B
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000754878: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000754880: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000754884: CC1A4004 1C12631D
	s_waitcnt vmcnt(1)                                         // 00000075488C: BF8907F7
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000754890: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000754898: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000075489C: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007548A4: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007548AC: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007548B0: CC1A4004 1C126B21
	s_waitcnt vmcnt(0)                                         // 0000007548B8: BF8903F7
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007548BC: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007548C4: BF870091
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007548C8: CC1A4004 1C126F23
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007548D0: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007548D8: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007548DC: CC1A4004 1C127325
	v_fmac_f32_e32 v16, v25, v4                                // 0000007548E4: 56200919
	v_mov_b32_e32 v4, v0                                       // 0000007548E8: 7E080300
	v_mov_b32_e32 v25, v24                                     // 0000007548EC: 7E320318
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000007548F0: 917E107E
	s_cbranch_execz 25                                         // 0000007548F4: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x95c>
	s_waitcnt vmcnt(0)                                         // 0000007548F8: BF8903F7
	v_dual_mov_b32 v0, v4 :: v_dual_add_nc_u32 v23, 32, v23    // 0000007548FC: CA200104 00162EA0
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 000000754904: CA100105 01020106
	v_mov_b32_e32 v3, v7                                       // 00000075490C: 7E060307
	s_delay_alu instid0(VALU_DEP_3)                            // 000000754910: BF870003
	.long 0xd4430000                                           // 000000754914: D4430000
	v_cndmask_b32_e32 v1, s2, v23, vcc_lo                      // 000000754918: 02022E02
	s_mov_b32 s10, exec_lo                                     // 00000075491C: BE8A007E
	.long 0xd4c4007e                                           // 000000754920: D4C4007E
	v_cndmask_b32_e32 v1, s2, v23, vcc_lo                      // 000000754924: 02022E02
	s_cbranch_execz 65112                                      // 000000754928: BFA5FE58 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x28c>
	.long 0xd7000100                                           // 00000075492C: D7000100
	v_cndmask_b32_e32 v1, v10, v22, vcc_lo                     // 000000754930: 02022D0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000754934: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s1                   // 000000754938: D5207C01 00062280
	global_load_d16_b16 v24, v[13:14], off                     // 000000754940: DC820000 187C000D
	global_load_b128 v[0:3], v[0:1], off                       // 000000754948: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 000000754950: BF8907F7
	v_cvt_f32_f16_e32 v24, v24                                 // 000000754954: 7E301718
	s_branch 65100                                             // 000000754958: BFA0FE4C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x28c>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000075495C: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000754960: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000754964: 8C7E037E
	.long 0xd71f0000                                           // 000000754968: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000075496C: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000754970: 3A020090
	s_waitcnt vmcnt(0)                                         // 000000754974: BF8903F7
	v_xor_b32_e32 v6, 8, v0                                    // 000000754978: 3A0C0088
	v_xor_b32_e32 v13, 4, v0                                   // 00000075497C: 3A1A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000754980: BF870093
	.long 0xd44c0000                                           // 000000754984: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000754988: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 00000075498C: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000754994: BF870114
	.long 0xd44c0000                                           // 000000754998: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 00000075499C: 02020CA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007549A0: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007549A4: BF870002
	v_cndmask_b32_e64 v6, v0, v6, s0                           // 0000007549A8: D5010006 00020D00
	.long 0xd44c0000                                           // 0000007549B0: D44C0000
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 0000007549B4: 02021AA0
	ds_bpermute_b32 v2, v1, v21                                // 0000007549B8: DACC0000 02001501
	v_cndmask_b32_e64 v13, v0, v13, s0                         // 0000007549C0: D501000D 00021B00
	s_waitcnt lgkmcnt(0)                                       // 0000007549C8: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 0000007549CC: 06040515
	ds_bpermute_b32 v3, v1, v20                                // 0000007549D0: DACC0000 03001401
	ds_bpermute_b32 v4, v1, v19                                // 0000007549D8: DACC0000 04001301
	ds_bpermute_b32 v5, v1, v18                                // 0000007549E0: DACC0000 05001201
	ds_bpermute_b32 v1, v1, v16                                // 0000007549E8: DACC0000 01001001
	s_waitcnt lgkmcnt(3)                                       // 0000007549F0: BF89FC37
	v_dual_add_f32 v3, v20, v3 :: v_dual_lshlrev_b32 v6, 2, v6 // 0000007549F4: C9220714 03060C82
	ds_bpermute_b32 v7, v6, v2                                 // 0000007549FC: DACC0000 07000206
	s_waitcnt lgkmcnt(2)                                       // 000000754A04: BF89FC27
	v_dual_add_f32 v4, v19, v4 :: v_dual_add_f32 v5, v18, v5   // 000000754A08: C9080913 04040B12
	s_waitcnt lgkmcnt(1)                                       // 000000754A10: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 000000754A14: 06020310
	ds_bpermute_b32 v10, v6, v3                                // 000000754A18: DACC0000 0A000306
	ds_bpermute_b32 v11, v6, v4                                // 000000754A20: DACC0000 0B000406
	ds_bpermute_b32 v12, v6, v5                                // 000000754A28: DACC0000 0C000506
	s_waitcnt lgkmcnt(3)                                       // 000000754A30: BF89FC37
	v_dual_add_f32 v2, v2, v7 :: v_dual_lshlrev_b32 v13, 2, v13// 000000754A34: C9220F02 020C1A82
	ds_bpermute_b32 v6, v6, v1                                 // 000000754A3C: DACC0000 06000106
	s_waitcnt lgkmcnt(0)                                       // 000000754A44: BF89FC07
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v1, v1, v6    // 000000754A48: C9081704 04000D01
	ds_bpermute_b32 v6, v13, v2                                // 000000754A50: DACC0000 0600020D
	v_add_f32_e32 v5, v5, v12                                  // 000000754A58: 060A1905
	ds_bpermute_b32 v12, v13, v1                               // 000000754A5C: DACC0000 0C00010D
	v_add_f32_e32 v3, v3, v10                                  // 000000754A64: 06061503
	ds_bpermute_b32 v10, v13, v4                               // 000000754A68: DACC0000 0A00040D
	s_waitcnt lgkmcnt(2)                                       // 000000754A70: BF89FC27
	v_add_f32_e32 v2, v2, v6                                   // 000000754A74: 06040D02
	ds_bpermute_b32 v11, v13, v5                               // 000000754A78: DACC0000 0B00050D
	s_waitcnt lgkmcnt(2)                                       // 000000754A80: BF89FC27
	v_add_f32_e32 v6, v1, v12                                  // 000000754A84: 060C1901
	ds_bpermute_b32 v7, v13, v3                                // 000000754A88: DACC0000 0700030D
	v_xor_b32_e32 v13, 2, v0                                   // 000000754A90: 3A1A0082
	s_waitcnt lgkmcnt(2)                                       // 000000754A94: BF89FC27
	v_add_f32_e32 v4, v4, v10                                  // 000000754A98: 06081504
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000754A9C: BF870092
	.long 0xd44c0000                                           // 000000754AA0: D44C0000
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 000000754AA4: 02021AA0
	v_cndmask_b32_e64 v13, v0, v13, s0                         // 000000754AA8: D501000D 00021B00
	s_delay_alu instid0(VALU_DEP_1)                            // 000000754AB0: BF870001
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000754AB4: 301A1A82
	ds_bpermute_b32 v1, v13, v2                                // 000000754AB8: DACC0000 0100020D
	s_waitcnt lgkmcnt(1)                                       // 000000754AC0: BF89FC17
	v_add_f32_e32 v3, v3, v7                                   // 000000754AC4: 06060F03
	ds_bpermute_b32 v10, v13, v4                               // 000000754AC8: DACC0000 0A00040D
	v_add_f32_e32 v5, v5, v11                                  // 000000754AD0: 060A1705
	ds_bpermute_b32 v12, v13, v6                               // 000000754AD4: DACC0000 0C00060D
	ds_bpermute_b32 v7, v13, v3                                // 000000754ADC: DACC0000 0700030D
	ds_bpermute_b32 v11, v13, v5                               // 000000754AE4: DACC0000 0B00050D
	v_xor_b32_e32 v13, 1, v0                                   // 000000754AEC: 3A1A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000754AF0: BF870091
	.long 0xd44c0000                                           // 000000754AF4: D44C0000
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 000000754AF8: 02021AA0
	v_cndmask_b32_e64 v0, v0, v13, s0                          // 000000754AFC: D5010000 00021B00
	.long 0xd44a0000                                           // 000000754B04: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000754B08: 02021E80
	s_waitcnt lgkmcnt(4)                                       // 000000754B0C: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 000000754B10: BF870002
	v_dual_add_f32 v0, v2, v1 :: v_dual_lshlrev_b32 v13, 2, v0 // 000000754B14: C9220302 000C0082
	s_waitcnt lgkmcnt(1)                                       // 000000754B1C: BF89FC17
	v_dual_add_f32 v1, v3, v7 :: v_dual_add_f32 v2, v4, v10    // 000000754B20: C9080F03 01021504
	s_waitcnt lgkmcnt(0)                                       // 000000754B28: BF89FC07
	v_add_f32_e32 v5, v5, v11                                  // 000000754B2C: 060A1705
	v_add_f32_e32 v7, v6, v12                                  // 000000754B30: 060E1906
	ds_bpermute_b32 v3, v13, v0                                // 000000754B34: DACC0000 0300000D
	ds_bpermute_b32 v4, v13, v1                                // 000000754B3C: DACC0000 0400010D
	ds_bpermute_b32 v6, v13, v2                                // 000000754B44: DACC0000 0600020D
	ds_bpermute_b32 v10, v13, v5                               // 000000754B4C: DACC0000 0A00050D
	ds_bpermute_b32 v11, v13, v7                               // 000000754B54: DACC0000 0B00070D
	s_and_b32 s0, s0, vcc_lo                                   // 000000754B5C: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000754B60: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000754B64: BE812000
	s_cbranch_execz 45                                         // 000000754B68: BFA5002D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xc20>
	.long 0xd73c0008                                           // 000000754B6C: D73C0008
	v_cndmask_b32_e32 v1, 2, v8, vcc_lo                        // 000000754B70: 02021082
	s_waitcnt lgkmcnt(0)                                       // 000000754B74: BF89FC07
	v_dual_add_f32 v11, v7, v11 :: v_dual_add_f32 v12, v5, v10 // 000000754B78: C9081707 0B0C1505
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000754B80: 8480820C
	v_dual_add_f32 v13, v2, v6 :: v_dual_add_f32 v14, v1, v4   // 000000754B84: C9080D02 0D0E0901
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000754B8C: BF870093
	.long 0xd7006a07                                           // 000000754B90: D7006A07
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 000000754B94: 02021008
	v_add_co_ci_u32_e64 v8, null, s9, v9, vcc_lo               // 000000754B98: D5207C08 01AA1209
	v_add_f32_e32 v15, v0, v3                                  // 000000754BA0: 061E0700
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000754BA4: BF870193
	.long 0xd7006a03                                           // 000000754BA8: D7006A03
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 000000754BAC: 02000107
	v_mad_u64_u32 v[0:1], null, s12, 12, v[7:8]                // 000000754BB0: D6FE7C00 041D180C
	v_add_co_ci_u32_e64 v4, null, s1, v8, vcc_lo               // 000000754BB8: D5207C04 01AA1001
	s_lshl_b64 s[0:1], s[12:13], 3                             // 000000754BC0: 8480830C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000754BC4: BF870099
	.long 0xd7006a05                                           // 000000754BC8: D7006A05
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 000000754BCC: 02000107
	v_add_co_ci_u32_e64 v6, null, s1, v8, vcc_lo               // 000000754BD0: D5207C06 01AA1001
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 000000754BD8: D6FE7C01 0405180D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000754BE0: BF870093
	.long 0xd7006a09                                           // 000000754BE4: D7006A09
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 000000754BE8: 02000105
	v_add_co_ci_u32_e64 v10, null, s1, v6, vcc_lo              // 000000754BEC: D5207C0A 01AA0C01
	s_clause 0x4                                               // 000000754BF4: BF850004
	global_store_b32 v[7:8], v15, off                          // 000000754BF8: DC6A0000 007C0F07
	global_store_b32 v[3:4], v14, off                          // 000000754C00: DC6A0000 007C0E03
	global_store_b32 v[5:6], v13, off                          // 000000754C08: DC6A0000 007C0D05
	global_store_b32 v[0:1], v12, off                          // 000000754C10: DC6A0000 007C0C00
	global_store_b32 v[9:10], v11, off                         // 000000754C18: DC6A0000 007C0B09
	s_endpgm                                                   // 000000754C20: BFB00000
		...

