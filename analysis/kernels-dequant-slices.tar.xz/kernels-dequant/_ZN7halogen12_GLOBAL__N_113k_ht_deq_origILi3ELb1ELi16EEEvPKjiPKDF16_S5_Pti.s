000000000049a900 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi3ELb1ELi16EEEvPKjiPKDF16_S5_Pti>:
; _ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi3ELb1ELi16EEEvPKjiPKDF16_S5_Pti():
	s_clause 0x1                                               // 00000049A900: BF850001
	s_load_b32 s13, s[0:1], 0x28                               // 00000049A904: F4000340 F8000028
	s_load_b32 s12, s[0:1], 0x8                                // 00000049A90C: F4000300 F8000008
	v_lshlrev_b32_e32 v1, 2, v0                                // 00000049A914: 30020082
	v_lshrrev_b32_e32 v3, 7, v0                                // 00000049A918: 32060087
	s_clause 0x2                                               // 00000049A91C: BF850002
	s_load_b64 s[10:11], s[0:1], null                          // 00000049A920: F4040280 F8000000
	s_load_b128 s[4:7], s[0:1], 0x10                           // 00000049A928: F4080100 F8000010
	s_load_b64 s[8:9], s[0:1], 0x20                            // 00000049A930: F4040200 F8000020
	v_and_b32_e32 v4, 31, v0                                   // 00000049A938: 3608009F
	v_and_b32_e32 v2, 0x60, v1                                 // 00000049A93C: 360402FF 00000060
	v_and_b32_e32 v1, 28, v1                                   // 00000049A944: 3602029C
	v_bfe_u32 v30, v0, 5, 3                                    // 00000049A948: D610001E 020D0B00
	v_lshrrev_b32_e32 v14, 6, v0                               // 00000049A950: 321C0086
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000049A954: BF870113
	v_or3_b32 v2, v2, v3, v1                                   // 00000049A958: D6580002 04060702
	v_and_b32_e32 v33, 4, v14                                  // 00000049A960: 36421C84
	v_or_b32_e32 v34, 3, v14                                   // 00000049A964: 38441C83
	s_waitcnt lgkmcnt(0)                                       // 00000049A968: BF89FC07
	s_cmp_eq_u32 s13, 0                                        // 00000049A96C: BF06800D
	s_cselect_b32 s0, s3, s2                                   // 00000049A970: 98000203
	s_cselect_b32 s3, s2, s3                                   // 00000049A974: 98030302
	s_lshl_b32 s2, s0, 7                                       // 00000049A978: 84028700
	s_lshl_b32 s1, s3, 7                                       // 00000049A97C: 84018703
	v_or_b32_e32 v1, s2, v2                                    // 00000049A980: 38020402
	v_or_b32_e32 v8, s1, v2                                    // 00000049A984: 38100401
	v_lshl_or_b32 v6, s0, 3, v30                               // 00000049A988: D6560006 04790600
	s_ashr_i32 s13, s12, 31                                    // 00000049A990: 860D9F0C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000049A994: BF8701D9
	s_lshr_b32 s0, s13, 28                                     // 00000049A998: 85009C0D
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000049A99C: 3404029F
	v_ashrrev_i32_e32 v9, 31, v8                               // 00000049A9A0: 3412109F
	v_ashrrev_i32_e32 v7, 31, v6                               // 00000049A9A4: 340E0C9F
	s_add_i32 s0, s12, s0                                      // 00000049A9A8: 8100000C
	.long 0xd73c000a                                           // 00000049A9AC: D73C000A
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000049A9B0: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000049A9B4: BF8704A3
	.long 0xd73c0008                                           // 00000049A9B8: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000049A9BC: 02021081
	s_ashr_i32 s0, s0, 4                                       // 00000049A9C0: 86008400
	v_mad_i64_i32 v[6:7], null, s3, s0, v[6:7]                 // 00000049A9C4: D6FF7C06 04180003
	s_movk_i32 s3, 0x1eee                                      // 00000049A9CC: B0031EEE
	.long 0xd7006a0a                                           // 00000049A9D0: D7006A0A
	v_cndmask_b32_e32 v1, s4, v10, vcc_lo                      // 00000049A9D4: 02021404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000049A9D8: BF8700A1
	v_add_co_ci_u32_e64 v11, null, s5, v11, vcc_lo             // 00000049A9DC: D5207C0B 01AA1605
	.long 0xd7006a08                                           // 00000049A9E4: D7006A08
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 00000049A9E8: 02021006
	v_add_co_ci_u32_e64 v9, null, s7, v9, vcc_lo               // 00000049A9EC: D5207C09 01AA1207
	.long 0xd73c0006                                           // 00000049A9F4: D73C0006
	v_cndmask_b32_e32 v1, 3, v6, vcc_lo                        // 00000049A9F8: 02020C83
	global_load_d16_hi_b16 v1, v[10:11], off                   // 00000049A9FC: DC8E0000 017C000A
	.long 0xd4490000                                           // 00000049AA04: D4490000
	v_cndmask_b32_e32 v1, 0x1ff, v0, vcc_lo                    // 00000049AA08: 020200FF 000001FF
	global_load_d16_b16 v1, v[8:9], off                        // 00000049AA10: DC820000 017C0008
	v_mov_b32_e32 v9, 0                                        // 00000049AA18: 7E120280
	v_lshl_or_b32 v5, v4, 3, 4                                 // 00000049AA1C: D6560005 02110704
	v_mad_u32_u24 v31, v4, 24, 0x2f0                           // 00000049AA24: D60B001F 03FD3104 000002F0
	v_cmp_ne_u32_e32 vcc_lo, 0, v4                             // 00000049AA30: 7C9A0880
	v_or_b32_e32 v10, v6, v33                                  // 00000049AA34: 38144306
	.long 0xd72c0016                                           // 00000049AA38: D72C0016
	v_cndmask_b32_e32 v1, 0x60, v7, vcc_lo                     // 00000049AA3C: 02020EFF 00000060
	v_mad_u32_u24 v32, v5, 3, 0x2f0                            // 00000049AA44: D60B0020 03FD0705 000002F0
	v_lshrrev_b32_e32 v13, 5, v31                              // 00000049AA50: 321A3E85
	v_or_b32_e32 v6, v6, v34                                   // 00000049AA54: 380C4506
	v_mad_u64_u32 v[10:11], null, 0x60, v10, s[10:11]          // 00000049AA58: D6FE7C0A 002A14FF 00000060
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049AA64: BF870214
	v_lshrrev_b32_e32 v12, 5, v32                              // 00000049AA68: 32184085
	v_subrev_nc_u32_e32 v8, 24, v13                            // 00000049AA6C: 4E101A98
	v_add_nc_u32_e32 v13, 0xe9, v13                            // 00000049AA70: 4A1A1AFF 000000E9
	v_mad_u64_u32 v[18:19], null, 0x60, v6, s[10:11]           // 00000049AA78: D6FE7C12 002A0CFF 00000060
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049AA84: BF870214
	.long 0xd7030002                                           // 00000049AA88: D7030002
	v_cndmask_b32_e32 v0, v12, v129, vcc_lo                    // 00000049AA8C: 0201030C
	v_cndmask_b32_e32 v8, 23, v8, vcc_lo                       // 00000049AA90: 02101097
	v_subrev_nc_u32_e32 v12, 24, v12                           // 00000049AA94: 4E181898
	v_cmp_lt_u32_e32 vcc_lo, 5, v5                             // 00000049AA98: 7C920A85
	v_and_b32_e32 v16, 0xff, v13                               // 00000049AA9C: 36201AFF 000000FF
	.long 0xd7624002                                           // 00000049AAA4: D7624002
	v_cndmask_b32_e32 v1, 0xff, v2, vcc_lo                     // 00000049AAA8: 020204FF 000000FF
	v_add_nc_u32_e32 v11, v22, v11                             // 00000049AAB0: 4A161716
	v_add_nc_u32_e32 v29, v22, v19                             // 00000049AAB4: 4A3A2716
	v_cndmask_b32_e32 v7, 23, v12, vcc_lo                      // 00000049AAB8: 020E1897
	.long 0xd73c000c                                           // 00000049AABC: D73C000C
	v_cndmask_b32_e32 v1, 2, v8, vcc_lo                        // 00000049AAC0: 02021082
	.long 0xd7055002                                           // 00000049AAC4: D7055002
	v_cndmask_b32_e32 v1, 0xab, v2, vcc_lo                     // 00000049AAC8: 020204FF 000000AB
	v_mov_b32_e32 v8, v9                                       // 00000049AAD0: 7E100309
	v_lshlrev_b32_e32 v26, 2, v16                              // 00000049AAD4: 30342082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049AAD8: BF870193
	.long 0xd7395002                                           // 00000049AADC: D7395002
	v_cndmask_b32_e32 v1, 12, v2, vcc_lo                       // 00000049AAE0: 0202048C
	.long 0xd73c0007                                           // 00000049AAE4: D73C0007
	v_cndmask_b32_e32 v1, 2, v7, vcc_lo                        // 00000049AAE8: 02020E82
	.long 0xd7006a0e                                           // 00000049AAEC: D7006A0E
	v_cndmask_b32_e32 v1, v10, v12, vcc_lo                     // 00000049AAF0: 0202190A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049AAF4: BF870211
	v_add_co_ci_u32_e64 v15, null, v11, v13, vcc_lo            // 00000049AAF8: D5207C0F 01AA1B0B
	.long 0xd7054802                                           // 00000049AB00: D7054802
	v_cndmask_b32_e32 v0, v2, v152, vcc_lo                     // 00000049AB04: 02013102
	.long 0xd7006a10                                           // 00000049AB08: D7006A10
	v_cndmask_b32_e32 v1, v10, v26, vcc_lo                     // 00000049AB0C: 0202350A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049AB10: BF870191
	v_add_co_ci_u32_e64 v17, null, 0, v11, vcc_lo              // 00000049AB14: D5207C11 01AA1680
	.long 0xd7041002                                           // 00000049AB1C: D7041002
	v_cndmask_b32_e32 v1, v2, v2, vcc_lo                       // 00000049AB20: 02020502
	.long 0xd7006a14                                           // 00000049AB24: D7006A14
	v_cndmask_b32_e32 v1, v10, v7, vcc_lo                      // 00000049AB28: 02020F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049AB2C: BF870191
	v_add_co_ci_u32_e64 v21, null, v11, v8, vcc_lo             // 00000049AB30: D5207C15 01AA110B
	v_and_b32_e32 v2, 0xff, v2                                 // 00000049AB38: 360404FF 000000FF
	s_clause 0x7                                               // 00000049AB40: BF850007
	global_load_b32 v23, v[14:15], off                         // 00000049AB44: DC520000 177C000E
	global_load_b32 v22, v[16:17], off                         // 00000049AB4C: DC520000 167C0010
	global_load_b32 v19, v[20:21], off                         // 00000049AB54: DC520000 137C0014
	global_load_b32 v25, v[14:15], off offset:96               // 00000049AB5C: DC520060 197C000E
	global_load_b32 v24, v[16:17], off offset:96               // 00000049AB64: DC520060 187C0010
	global_load_b32 v27, v[20:21], off offset:96               // 00000049AB6C: DC520060 1B7C0014
	global_load_b32 v16, v[16:17], off offset:192              // 00000049AB74: DC5200C0 107C0010
	global_load_b32 v17, v[14:15], off offset:192              // 00000049AB7C: DC5200C0 117C000E
	v_and_b32_e32 v15, 0x7e0, v31                              // 00000049AB84: 361E3EFF 000007E0
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000049AB8C: 30040482
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000049AB90: BF870112
	v_mad_i32_i24 v15, 0xffffffe8, v4, v15                     // 00000049AB94: D60A000F 043E08FF FFFFFFE8
	.long 0xd7006a09                                           // 00000049ABA0: D7006A09
	v_cndmask_b32_e32 v1, v10, v2, vcc_lo                      // 00000049ABA4: 0202050A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000049ABA8: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v11, vcc_lo              // 00000049ABAC: D5207C0A 01AA1680
	.long 0xd7006a0b                                           // 00000049ABB4: D7006A0B
	v_cndmask_b32_e32 v1, v18, v12, vcc_lo                     // 00000049ABB8: 02021912
	v_add_co_ci_u32_e64 v12, null, v29, v13, vcc_lo            // 00000049ABBC: D5207C0C 01AA1B1D
	.long 0xd7006a0d                                           // 00000049ABC4: D7006A0D
	v_cndmask_b32_e32 v1, v18, v26, vcc_lo                     // 00000049ABC8: 02023512
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000049ABCC: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v29, vcc_lo              // 00000049ABD0: D5207C0E 01AA3A80
	.long 0xd7006a06                                           // 00000049ABD8: D7006A06
	v_cndmask_b32_e32 v1, v18, v7, vcc_lo                      // 00000049ABDC: 02020F12
	v_add_co_ci_u32_e64 v7, null, v29, v8, vcc_lo              // 00000049ABE0: D5207C07 01AA111D
	.long 0xd7006a1c                                           // 00000049ABE8: D7006A1C
	v_cndmask_b32_e32 v1, v18, v2, vcc_lo                      // 00000049ABEC: 02020512
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049ABF0: BF870001
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 00000049ABF4: D5207C1D 01AA3A80
	s_clause 0x7                                               // 00000049ABFC: BF850007
	global_load_b32 v18, v[9:10], off                          // 00000049AC00: DC520000 127C0009
	global_load_b32 v26, v[9:10], off offset:96                // 00000049AC08: DC520060 1A7C0009
	global_load_b32 v8, v[9:10], off offset:192                // 00000049AC10: DC5200C0 087C0009
	global_load_b32 v11, v[11:12], off                         // 00000049AC18: DC520000 0B7C000B
	global_load_b32 v10, v[13:14], off                         // 00000049AC20: DC520000 0A7C000D
	global_load_b32 v7, v[6:7], off                            // 00000049AC28: DC520000 077C0006
	global_load_b32 v6, v[28:29], off                          // 00000049AC30: DC520000 067C001C
	global_load_b32 v9, v[20:21], off offset:192               // 00000049AC38: DC5200C0 097C0014
	v_lshrrev_b32_e32 v2, 1, v0                                // 00000049AC40: 32040081
	v_and_b32_e32 v12, 15, v0                                  // 00000049AC44: 3618008F
	v_lshlrev_b32_e32 v20, 4, v33                              // 00000049AC48: 30284284
	v_and_b32_e32 v28, 0x7e0, v32                              // 00000049AC4C: 363840FF 000007E0
	v_add_nc_u32_e32 v39, 0xfffffd3d, v15                      // 00000049AC54: 4A4E1EFF FFFFFD3D
	v_and_b32_e32 v13, 8, v2                                   // 00000049AC5C: 361A0488
	v_lshlrev_b32_e32 v14, 9, v12                              // 00000049AC60: 301C1889
	v_lshl_or_b32 v21, v34, 4, v12                             // 00000049AC64: D6560015 04310922
	v_or3_b32 v20, v20, v12, 16                                // 00000049AC6C: D6580014 02421914
	v_add_nc_u32_e32 v40, 0xfffffd3a, v15                      // 00000049AC74: 4A501EFF FFFFFD3A
	v_lshl_or_b32 v13, v30, 4, v13                             // 00000049AC7C: D656000D 0435091E
	v_lshl_or_b32 v14, v33, 13, v14                            // 00000049AC84: D656000E 04391B21
	v_add_nc_u32_e32 v41, 0xfffffd37, v15                      // 00000049AC8C: 4A521EFF FFFFFD37
	v_add_nc_u32_e32 v42, 0xfffffd34, v15                      // 00000049AC94: 4A541EFF FFFFFD34
	v_mad_i32_i24 v5, v5, -3, v28                              // 00000049AC9C: D60A0005 04718705
	v_xor_b32_e32 v29, v13, v12                                // 00000049ACA4: 3A3A190D
	v_or_b32_e32 v30, 1, v13                                   // 00000049ACA8: 383C1A81
	v_or_b32_e32 v31, 2, v13                                   // 00000049ACAC: 383E1A82
	v_or_b32_e32 v32, 3, v13                                   // 00000049ACB0: 38401A83
	v_or_b32_e32 v33, 4, v13                                   // 00000049ACB4: 38421A84
	v_or_b32_e32 v34, 5, v13                                   // 00000049ACB8: 38441A85
	v_or_b32_e32 v35, 6, v13                                   // 00000049ACBC: 38461A86
	v_or_b32_e32 v36, 7, v13                                   // 00000049ACC0: 38481A87
	v_lshlrev_b32_e32 v15, 2, v29                              // 00000049ACC4: 301E3A82
	v_xor_b32_e32 v28, v30, v12                                // 00000049ACC8: 3A38191E
	v_xor_b32_e32 v29, v31, v12                                // 00000049ACCC: 3A3A191F
	v_and_b32_e32 v38, 31, v21                                 // 00000049ACD0: 364C2A9F
	v_and_b32_e32 v47, 31, v20                                 // 00000049ACD4: 365E289F
	v_xor_b32_e32 v43, v32, v12                                // 00000049ACD8: 3A561920
	v_xor_b32_e32 v44, v33, v12                                // 00000049ACDC: 3A581921
	v_xor_b32_e32 v45, v34, v12                                // 00000049ACE0: 3A5A1922
	v_xor_b32_e32 v46, v35, v12                                // 00000049ACE4: 3A5C1923
	v_xor_b32_e32 v12, v36, v12                                // 00000049ACE8: 3A181924
	v_or_b32_e32 v37, 0x4000, v14                              // 00000049ACEC: 384A1CFF 00004000
	v_add_nc_u32_e32 v57, 0xfffffd37, v5                       // 00000049ACF4: 4A720AFF FFFFFD37
	v_lshlrev_b32_e32 v28, 2, v28                              // 00000049ACFC: 30383882
	v_lshlrev_b32_e32 v29, 2, v29                              // 00000049AD00: 303A3A82
	v_lshlrev_b32_e32 v20, 9, v20                              // 00000049AD04: 30282889
	v_xor_b32_e32 v49, v30, v38                                // 00000049AD08: 3A624D1E
	v_xor_b32_e32 v30, v30, v47                                // 00000049AD0C: 3A3C5F1E
	v_xor_b32_e32 v50, v31, v38                                // 00000049AD10: 3A644D1F
	v_xor_b32_e32 v31, v31, v47                                // 00000049AD14: 3A3E5F1F
	v_xor_b32_e32 v48, v13, v38                                // 00000049AD18: 3A604D0D
	v_xor_b32_e32 v51, v32, v38                                // 00000049AD1C: 3A664D20
	v_lshlrev_b32_e32 v12, 2, v12                              // 00000049AD20: 30181882
	v_xor_b32_e32 v13, v13, v47                                // 00000049AD24: 3A1A5F0D
	v_xor_b32_e32 v32, v32, v47                                // 00000049AD28: 3A405F20
	v_lshlrev_b32_e32 v21, 9, v21                              // 00000049AD2C: 302A2A89
	v_xor_b32_e32 v52, v33, v38                                // 00000049AD30: 3A684D21
	v_xor_b32_e32 v53, v34, v38                                // 00000049AD34: 3A6A4D22
	v_xor_b32_e32 v54, v35, v38                                // 00000049AD38: 3A6C4D23
	v_xor_b32_e32 v38, v36, v38                                // 00000049AD3C: 3A4C4D24
	v_add_nc_u32_e32 v56, 0xfffffd3a, v5                       // 00000049AD40: 4A700AFF FFFFFD3A
	v_lshlrev_b32_e32 v43, 2, v43                              // 00000049AD48: 30565682
	v_lshlrev_b32_e32 v44, 2, v44                              // 00000049AD4C: 30585882
	v_lshlrev_b32_e32 v45, 2, v45                              // 00000049AD50: 305A5A82
	v_lshlrev_b32_e32 v46, 2, v46                              // 00000049AD54: 305C5C82
	v_xor_b32_e32 v33, v33, v47                                // 00000049AD58: 3A425F21
	v_xor_b32_e32 v34, v34, v47                                // 00000049AD5C: 3A445F22
	v_xor_b32_e32 v35, v35, v47                                // 00000049AD60: 3A465F23
	v_xor_b32_e32 v36, v36, v47                                // 00000049AD64: 3A485F24
	v_add_nc_u32_e32 v55, 0xfffffd3d, v5                       // 00000049AD68: 4A6E0AFF FFFFFD3D
	v_or_b32_e32 v60, v14, v28                                 // 00000049AD70: 3878390E
	v_or_b32_e32 v61, v14, v29                                 // 00000049AD74: 387A3B0E
	v_or_b32_e32 v75, v37, v28                                 // 00000049AD78: 38963925
	v_or_b32_e32 v76, v37, v29                                 // 00000049AD7C: 38983B25
	v_lshl_or_b32 v68, v30, 2, v20                             // 00000049AD80: D6560044 0451051E
	v_lshl_or_b32 v69, v31, 2, v20                             // 00000049AD88: D6560045 0451051F
	v_or_b32_e32 v66, v14, v12                                 // 00000049AD90: 3884190E
	v_lshl_or_b32 v67, v13, 2, v20                             // 00000049AD94: D6560043 0451050D
	v_lshl_or_b32 v70, v32, 2, v20                             // 00000049AD9C: D6560046 04510520
	v_or_b32_e32 v78, v37, v12                                 // 00000049ADA4: 389C1925
	v_add_nc_u32_e32 v5, 0xfffffd34, v5                        // 00000049ADA8: 4A0A0AFF FFFFFD34
	v_or_b32_e32 v58, v14, v15                                 // 00000049ADB0: 38741F0E
	v_lshl_or_b32 v48, v48, 2, v21                             // 00000049ADB4: D6560030 04550530
	v_lshl_or_b32 v49, v49, 2, v21                             // 00000049ADBC: D6560031 04550531
	v_lshl_or_b32 v50, v50, 2, v21                             // 00000049ADC4: D6560032 04550532
	v_lshl_or_b32 v51, v51, 2, v21                             // 00000049ADCC: D6560033 04550533
	v_lshl_or_b32 v52, v52, 2, v21                             // 00000049ADD4: D6560034 04550534
	v_lshl_or_b32 v53, v53, 2, v21                             // 00000049ADDC: D6560035 04550535
	v_lshl_or_b32 v54, v54, 2, v21                             // 00000049ADE4: D6560036 04550536
	v_lshl_or_b32 v59, v38, 2, v21                             // 00000049ADEC: D656003B 04550526
	v_or_b32_e32 v62, v14, v43                                 // 00000049ADF4: 387C570E
	v_or_b32_e32 v63, v14, v44                                 // 00000049ADF8: 387E590E
	v_or_b32_e32 v64, v14, v45                                 // 00000049ADFC: 38805B0E
	v_or_b32_e32 v65, v14, v46                                 // 00000049AE00: 38825D0E
	v_lshl_or_b32 v71, v33, 2, v20                             // 00000049AE04: D6560047 04510521
	v_lshl_or_b32 v72, v34, 2, v20                             // 00000049AE0C: D6560048 04510522
	v_lshl_or_b32 v73, v35, 2, v20                             // 00000049AE14: D6560049 04510523
	v_lshl_or_b32 v74, v36, 2, v20                             // 00000049AE1C: D656004A 04510524
	v_or_b32_e32 v47, v37, v15                                 // 00000049AE24: 385E1F25
	v_or_b32_e32 v77, v37, v43                                 // 00000049AE28: 389A5725
	v_or_b32_e32 v44, v37, v44                                 // 00000049AE2C: 38585925
	v_or_b32_e32 v45, v37, v45                                 // 00000049AE30: 385A5B25
	v_or_b32_e32 v46, v37, v46                                 // 00000049AE34: 385C5D25
	v_and_b32_e32 v2, 0x7f, v0                                 // 00000049AE38: 360400FF 0000007F
	v_cmp_gt_u32_e32 vcc_lo, 0x200, v0                         // 00000049AE40: 7C9800FF 00000200
	s_waitcnt vmcnt(14)                                        // 00000049AE48: BF893BF7
	.long 0xd73d000c                                           // 00000049AE4C: D73D000C
	v_cndmask_b32_e32 v1, v39, v22, vcc_lo                     // 00000049AE50: 02022D27
	.long 0xd73d000d                                           // 00000049AE54: D73D000D
	v_cndmask_b32_e32 v1, v40, v22, vcc_lo                     // 00000049AE58: 02022D28
	.long 0xd73d0014                                           // 00000049AE5C: D73D0014
	v_cndmask_b32_e32 v1, v42, v22, vcc_lo                     // 00000049AE60: 02022D2A
	.long 0xd73d000e                                           // 00000049AE64: D73D000E
	v_cndmask_b32_e32 v1, v41, v22, vcc_lo                     // 00000049AE68: 02022D29
	s_waitcnt vmcnt(7)                                         // 00000049AE6C: BF891FF7
	.long 0xd73d001c                                           // 00000049AE70: D73D001C
	v_cndmask_b32_e32 v1, v57, v18, vcc_lo                     // 00000049AE74: 02022539
	.long 0xd73d001d                                           // 00000049AE78: D73D001D
	v_cndmask_b32_e32 v1, v39, v24, vcc_lo                     // 00000049AE7C: 02023127
	.long 0xd73d001e                                           // 00000049AE80: D73D001E
	v_cndmask_b32_e32 v1, v40, v24, vcc_lo                     // 00000049AE84: 02023128
	.long 0xd73d001f                                           // 00000049AE88: D73D001F
	v_cndmask_b32_e32 v1, v41, v24, vcc_lo                     // 00000049AE8C: 02023129
	s_waitcnt vmcnt(6)                                         // 00000049AE90: BF891BF7
	.long 0xd73d0020                                           // 00000049AE94: D73D0020
	v_cndmask_b32_e32 v1, v56, v26, vcc_lo                     // 00000049AE98: 02023538
	.long 0xd73d0015                                           // 00000049AE9C: D73D0015
	v_cndmask_b32_e32 v1, v55, v18, vcc_lo                     // 00000049AEA0: 02022537
	.long 0xd73d0021                                           // 00000049AEA4: D73D0021
	v_cndmask_b32_e32 v1, v57, v26, vcc_lo                     // 00000049AEA8: 02023539
	.long 0xd73d0016                                           // 00000049AEAC: D73D0016
	v_cndmask_b32_e32 v1, v56, v18, vcc_lo                     // 00000049AEB0: 02022538
	.long 0xd73d0022                                           // 00000049AEB4: D73D0022
	v_cndmask_b32_e32 v1, v40, v16, vcc_lo                     // 00000049AEB8: 02022128
	.long 0xd73d0017                                           // 00000049AEBC: D73D0017
	v_cndmask_b32_e32 v1, v42, v24, vcc_lo                     // 00000049AEC0: 0202312A
	.long 0xd73d0023                                           // 00000049AEC4: D73D0023
	v_cndmask_b32_e32 v1, v41, v16, vcc_lo                     // 00000049AEC8: 02022129
	.long 0xd73d0018                                           // 00000049AECC: D73D0018
	v_cndmask_b32_e32 v1, v55, v26, vcc_lo                     // 00000049AED0: 02023537
	s_waitcnt vmcnt(0)                                         // 00000049AED4: BF8903F7
	.long 0xd73d0024                                           // 00000049AED8: D73D0024
	v_cndmask_b32_e32 v1, v56, v8, vcc_lo                      // 00000049AEDC: 02021138
	.long 0xd73d0019                                           // 00000049AEE0: D73D0019
	v_cndmask_b32_e32 v1, v5, v26, vcc_lo                      // 00000049AEE4: 02023505
	.long 0xd73d0025                                           // 00000049AEE8: D73D0025
	v_cndmask_b32_e32 v1, v57, v8, vcc_lo                      // 00000049AEEC: 02021139
	.long 0xd73d001a                                           // 00000049AEF0: D73D001A
	v_cndmask_b32_e32 v1, v39, v16, vcc_lo                     // 00000049AEF4: 02022127
	.long 0xd73d0026                                           // 00000049AEF8: D73D0026
	v_cndmask_b32_e32 v1, v39, v10, vcc_lo                     // 00000049AEFC: 02021527
	.long 0xd73d000f                                           // 00000049AF00: D73D000F
	v_cndmask_b32_e32 v1, v42, v16, vcc_lo                     // 00000049AF04: 0202212A
	.long 0xd73d0027                                           // 00000049AF08: D73D0027
	v_cndmask_b32_e32 v1, v40, v10, vcc_lo                     // 00000049AF0C: 02021528
	.long 0xd73d0010                                           // 00000049AF10: D73D0010
	v_cndmask_b32_e32 v1, v55, v8, vcc_lo                      // 00000049AF14: 02021137
	.long 0xd73d0008                                           // 00000049AF18: D73D0008
	v_cndmask_b32_e32 v1, v5, v8, vcc_lo                       // 00000049AF1C: 02021105
	.long 0xd73d0028                                           // 00000049AF20: D73D0028
	v_cndmask_b32_e32 v1, v41, v10, vcc_lo                     // 00000049AF24: 02021529
	.long 0xd73d0009                                           // 00000049AF28: D73D0009
	v_cndmask_b32_e32 v1, v42, v10, vcc_lo                     // 00000049AF2C: 0202152A
	.long 0xd73d0029                                           // 00000049AF30: D73D0029
	v_cndmask_b32_e32 v1, v56, v6, vcc_lo                      // 00000049AF34: 02020D38
	.long 0xd73d0012                                           // 00000049AF38: D73D0012
	v_cndmask_b32_e32 v1, v5, v18, vcc_lo                      // 00000049AF3C: 02022505
	.long 0xd73d000a                                           // 00000049AF40: D73D000A
	v_cndmask_b32_e32 v1, v55, v6, vcc_lo                      // 00000049AF44: 02020D37
	.long 0xd73d002a                                           // 00000049AF48: D73D002A
	v_cndmask_b32_e32 v1, v57, v6, vcc_lo                      // 00000049AF4C: 02020D39
	.long 0xd73d0005                                           // 00000049AF50: D73D0005
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 00000049AF54: 02020D05
	v_and_b32_e32 v6, 0xffff, v12                              // 00000049AF58: 360C18FF 0000FFFF
	v_and_b32_e32 v11, 0xffff, v14                             // 00000049AF60: 36161CFF 0000FFFF
	v_and_b32_e32 v7, 0xffff, v13                              // 00000049AF68: 360E1AFF 0000FFFF
	v_and_b32_e32 v13, 0xffff, v21                             // 00000049AF70: 361A2AFF 0000FFFF
	v_and_b32_e32 v12, 0xffff, v20                             // 00000049AF78: 361828FF 0000FFFF
	v_and_b32_e32 v14, 0xffff, v22                             // 00000049AF80: 361C2CFF 0000FFFF
	v_and_b32_e32 v17, 0xffff, v28                             // 00000049AF88: 362238FF 0000FFFF
	v_and_b32_e32 v19, 0xffff, v29                             // 00000049AF90: 36263AFF 0000FFFF
	v_and_b32_e32 v20, 0xffff, v30                             // 00000049AF98: 36283CFF 0000FFFF
	v_and_b32_e32 v21, 0xffff, v31                             // 00000049AFA0: 362A3EFF 0000FFFF
	v_and_b32_e32 v22, 0xffff, v23                             // 00000049AFA8: 362C2EFF 0000FFFF
	v_and_b32_e32 v23, 0xffff, v24                             // 00000049AFB0: 362E30FF 0000FFFF
	v_and_b32_e32 v24, 0xffff, v32                             // 00000049AFB8: 363040FF 0000FFFF
	v_and_b32_e32 v27, 0xffff, v33                             // 00000049AFC0: 363642FF 0000FFFF
	v_and_b32_e32 v26, 0xffff, v26                             // 00000049AFC8: 363434FF 0000FFFF
	v_and_b32_e32 v28, 0xffff, v34                             // 00000049AFD0: 363844FF 0000FFFF
	v_and_b32_e32 v29, 0xffff, v35                             // 00000049AFD8: 363A46FF 0000FFFF
	v_and_b32_e32 v16, 0xffff, v16                             // 00000049AFE0: 362020FF 0000FFFF
	v_and_b32_e32 v30, 0xffff, v36                             // 00000049AFE8: 363C48FF 0000FFFF
	v_and_b32_e32 v31, 0xffff, v37                             // 00000049AFF0: 363E4AFF 0000FFFF
	v_and_b32_e32 v32, 0xffff, v38                             // 00000049AFF8: 36404CFF 0000FFFF
	v_and_b32_e32 v34, 0xffff, v40                             // 00000049B000: 364450FF 0000FFFF
	v_and_b32_e32 v10, 0xffff, v10                             // 00000049B008: 361414FF 0000FFFF
	v_and_b32_e32 v36, 0xffff, v42                             // 00000049B010: 364854FF 0000FFFF
	.long 0xd72c0006                                           // 00000049B018: D72C0006
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 00000049B01C: 02020CFF 83DCD12D
	.long 0xd72c000b                                           // 00000049B024: D72C000B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v11, vcc_lo              // 00000049B028: 020216FF 83DCD12D
	.long 0xd72c000d                                           // 00000049B030: D72C000D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v13, vcc_lo              // 00000049B034: 02021AFF 83DCD12D
	v_and_b32_e32 v18, 0xffff, v18                             // 00000049B03C: 362424FF 0000FFFF
	v_and_b32_e32 v25, 0xffff, v25                             // 00000049B044: 363232FF 0000FFFF
	v_and_b32_e32 v15, 0xffff, v15                             // 00000049B04C: 361E1EFF 0000FFFF
	v_and_b32_e32 v8, 0xffff, v8                               // 00000049B054: 361010FF 0000FFFF
	v_and_b32_e32 v33, 0xffff, v39                             // 00000049B05C: 36424EFF 0000FFFF
	v_and_b32_e32 v9, 0xffff, v9                               // 00000049B064: 361212FF 0000FFFF
	v_and_b32_e32 v35, 0xffff, v41                             // 00000049B06C: 364652FF 0000FFFF
	v_and_b32_e32 v5, 0xffff, v5                               // 00000049B074: 360A0AFF 0000FFFF
	.long 0xd72c0007                                           // 00000049B07C: D72C0007
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 00000049B080: 02020EFF 83DCD12D
	.long 0xd72c0011                                           // 00000049B088: D72C0011
	v_cndmask_b32_e32 v1, 0x83dcd12d, v17, vcc_lo              // 00000049B08C: 020222FF 83DCD12D
	.long 0xd72c0013                                           // 00000049B094: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 00000049B098: 020226FF 83DCD12D
	.long 0xd72c0015                                           // 00000049B0A0: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 00000049B0A4: 02022AFF 83DCD12D
	.long 0xd72c0017                                           // 00000049B0AC: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 00000049B0B0: 02022EFF 83DCD12D
	.long 0xd72c001b                                           // 00000049B0B8: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 00000049B0BC: 020236FF 83DCD12D
	.long 0xd72c001a                                           // 00000049B0C4: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 00000049B0C8: 020234FF 83DCD12D
	.long 0xd72c001d                                           // 00000049B0D0: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 00000049B0D4: 02023AFF 83DCD12D
	.long 0xd72c0010                                           // 00000049B0DC: D72C0010
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 00000049B0E0: 020220FF 83DCD12D
	.long 0xd72c001f                                           // 00000049B0E8: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 00000049B0EC: 02023EFF 83DCD12D
	.long 0xd72c0020                                           // 00000049B0F4: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 00000049B0F8: 020240FF 83DCD12D
	.long 0xd72c0022                                           // 00000049B100: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 00000049B104: 020244FF 83DCD12D
	.long 0xd72c000a                                           // 00000049B10C: D72C000A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v10, vcc_lo              // 00000049B110: 020214FF 83DCD12D
	.long 0xd72c0024                                           // 00000049B118: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 00000049B11C: 020248FF 83DCD12D
	.long 0xd72c000c                                           // 00000049B124: D72C000C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v12, vcc_lo              // 00000049B128: 020218FF 83DCD12D
	v_sad_u8 v6, v6, 0, 0x6400                                 // 00000049B130: D6220006 03FD0106 00006400
	.long 0xd72c000e                                           // 00000049B13C: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 00000049B140: 02021CFF 83DCD12D
	.long 0xd72c0012                                           // 00000049B148: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 00000049B14C: 020224FF 83DCD12D
	.long 0xd72c0014                                           // 00000049B154: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v20, vcc_lo              // 00000049B158: 020228FF 83DCD12D
	.long 0xd72c0016                                           // 00000049B160: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 00000049B164: 02022CFF 83DCD12D
	.long 0xd72c0018                                           // 00000049B16C: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 00000049B170: 020230FF 83DCD12D
	.long 0xd72c0019                                           // 00000049B178: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 00000049B17C: 020232FF 83DCD12D
	.long 0xd72c001c                                           // 00000049B184: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 00000049B188: 020238FF 83DCD12D
	.long 0xd72c000f                                           // 00000049B190: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 00000049B194: 02021EFF 83DCD12D
	.long 0xd72c001e                                           // 00000049B19C: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 00000049B1A0: 02023CFF 83DCD12D
	.long 0xd72c0008                                           // 00000049B1A8: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v8, vcc_lo               // 00000049B1AC: 020210FF 83DCD12D
	.long 0xd72c0021                                           // 00000049B1B4: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 00000049B1B8: 020242FF 83DCD12D
	.long 0xd72c0009                                           // 00000049B1C0: D72C0009
	v_cndmask_b32_e32 v1, 0x83dcd12d, v9, vcc_lo               // 00000049B1C4: 020212FF 83DCD12D
	.long 0xd72c0023                                           // 00000049B1CC: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 00000049B1D0: 020246FF 83DCD12D
	.long 0xd72c0005                                           // 00000049B1D8: D72C0005
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 00000049B1DC: 02020AFF 83DCD12D
	v_sad_u8 v11, v11, 0, 0x6400                               // 00000049B1E4: D622000B 03FD010B 00006400
	v_sad_u8 v13, v13, 0, 0x6400                               // 00000049B1F0: D622000D 03FD010D 00006400
	v_sad_u8 v7, v7, 0, 0x6400                                 // 00000049B1FC: D6220007 03FD0107 00006400
	v_sad_u8 v17, v17, 0, 0x6400                               // 00000049B208: D6220011 03FD0111 00006400
	v_sad_u8 v19, v19, 0, 0x6400                               // 00000049B214: D6220013 03FD0113 00006400
	v_sad_u8 v21, v21, 0, 0x6400                               // 00000049B220: D6220015 03FD0115 00006400
	v_sad_u8 v23, v23, 0, 0x6400                               // 00000049B22C: D6220017 03FD0117 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 00000049B238: D622001B 03FD011B 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 00000049B244: D622001A 03FD011A 00006400
	v_sad_u8 v29, v29, 0, 0x6400                               // 00000049B250: D622001D 03FD011D 00006400
	v_sad_u8 v16, v16, 0, 0x6400                               // 00000049B25C: D6220010 03FD0110 00006400
	v_sad_u8 v31, v31, 0, 0x6400                               // 00000049B268: D622001F 03FD011F 00006400
	v_sad_u8 v32, v32, 0, 0x6400                               // 00000049B274: D6220020 03FD0120 00006400
	v_sad_u8 v34, v34, 0, 0x6400                               // 00000049B280: D6220022 03FD0122 00006400
	v_sad_u8 v10, v10, 0, 0x6400                               // 00000049B28C: D622000A 03FD010A 00006400
	v_sad_u8 v36, v36, 0, 0x6400                               // 00000049B298: D6220024 03FD0124 00006400
	v_and_b32_e32 v6, 0xffff, v6                               // 00000049B2A4: 360C0CFF 0000FFFF
	v_sad_u8 v12, v12, 0, 0x6400                               // 00000049B2AC: D622000C 03FD010C 00006400
	v_and_b32_e32 v11, 0xffff, v11                             // 00000049B2B8: 361616FF 0000FFFF
	v_sad_u8 v14, v14, 0, 0x6400                               // 00000049B2C0: D622000E 03FD010E 00006400
	v_and_b32_e32 v13, 0xffff, v13                             // 00000049B2CC: 361A1AFF 0000FFFF
	v_sad_u8 v18, v18, 0, 0x6400                               // 00000049B2D4: D6220012 03FD0112 00006400
	v_sad_u8 v20, v20, 0, 0x6400                               // 00000049B2E0: D6220014 03FD0114 00006400
	v_sad_u8 v22, v22, 0, 0x6400                               // 00000049B2EC: D6220016 03FD0116 00006400
	v_sad_u8 v24, v24, 0, 0x6400                               // 00000049B2F8: D6220018 03FD0118 00006400
	v_sad_u8 v25, v25, 0, 0x6400                               // 00000049B304: D6220019 03FD0119 00006400
	v_sad_u8 v28, v28, 0, 0x6400                               // 00000049B310: D622001C 03FD011C 00006400
	v_sad_u8 v15, v15, 0, 0x6400                               // 00000049B31C: D622000F 03FD010F 00006400
	v_sad_u8 v30, v30, 0, 0x6400                               // 00000049B328: D622001E 03FD011E 00006400
	v_sad_u8 v8, v8, 0, 0x6400                                 // 00000049B334: D6220008 03FD0108 00006400
	v_sad_u8 v33, v33, 0, 0x6400                               // 00000049B340: D6220021 03FD0121 00006400
	v_sad_u8 v9, v9, 0, 0x6400                                 // 00000049B34C: D6220009 03FD0109 00006400
	v_sad_u8 v35, v35, 0, 0x6400                               // 00000049B358: D6220023 03FD0123 00006400
	v_sad_u8 v5, v5, 0, 0x6400                                 // 00000049B364: D6220005 03FD0105 00006400
	v_and_b32_e32 v17, 0xffff, v17                             // 00000049B370: 362222FF 0000FFFF
	v_and_b32_e32 v19, 0xffff, v19                             // 00000049B378: 362626FF 0000FFFF
	v_and_b32_e32 v21, 0xffff, v21                             // 00000049B380: 362A2AFF 0000FFFF
	v_and_b32_e32 v23, 0xffff, v23                             // 00000049B388: 362E2EFF 0000FFFF
	v_and_b32_e32 v27, 0xffff, v27                             // 00000049B390: 363636FF 0000FFFF
	v_and_b32_e32 v26, 0xffff, v26                             // 00000049B398: 363434FF 0000FFFF
	v_and_b32_e32 v29, 0xffff, v29                             // 00000049B3A0: 363A3AFF 0000FFFF
	v_and_b32_e32 v16, 0xffff, v16                             // 00000049B3A8: 362020FF 0000FFFF
	v_and_b32_e32 v31, 0xffff, v31                             // 00000049B3B0: 363E3EFF 0000FFFF
	v_and_b32_e32 v32, 0xffff, v32                             // 00000049B3B8: 364040FF 0000FFFF
	v_and_b32_e32 v34, 0xffff, v34                             // 00000049B3C0: 364444FF 0000FFFF
	v_and_b32_e32 v10, 0xffff, v10                             // 00000049B3C8: 361414FF 0000FFFF
	v_and_b32_e32 v36, 0xffff, v36                             // 00000049B3D0: 364848FF 0000FFFF
	v_lshl_or_b32 v6, v7, 16, v6                               // 00000049B3D8: D6560006 04192107
	v_lshl_or_b32 v7, v12, 16, v11                             // 00000049B3E0: D6560007 042D210C
	v_lshl_or_b32 v11, v14, 16, v13                            // 00000049B3E8: D656000B 0435210E
	v_lshl_or_b32 v12, v18, 16, v17                            // 00000049B3F0: D656000C 04452112
	v_lshl_or_b32 v13, v20, 16, v19                            // 00000049B3F8: D656000D 044D2114
	v_lshl_or_b32 v14, v22, 16, v21                            // 00000049B400: D656000E 04552116
	v_lshl_or_b32 v17, v24, 16, v23                            // 00000049B408: D6560011 045D2118
	v_lshl_or_b32 v18, v25, 16, v27                            // 00000049B410: D6560012 046D2119
	v_lshl_or_b32 v19, v28, 16, v26                            // 00000049B418: D6560013 0469211C
	v_lshl_or_b32 v15, v15, 16, v29                            // 00000049B420: D656000F 0475210F
	v_lshl_or_b32 v16, v30, 16, v16                            // 00000049B428: D6560010 0441211E
	v_lshl_or_b32 v8, v8, 16, v31                              // 00000049B430: D6560008 047D2108
	v_lshl_or_b32 v20, v33, 16, v32                            // 00000049B438: D6560014 04812121
	v_lshl_or_b32 v9, v9, 16, v34                              // 00000049B440: D6560009 04892109
	v_lshl_or_b32 v10, v35, 16, v10                            // 00000049B448: D656000A 04292123
	v_lshl_or_b32 v5, v5, 16, v36                              // 00000049B450: D6560005 04912105
	v_pk_fma_f16 v6, v6, s3, 0xc931 op_sel_hi:[1,0,0]          // 00000049B458: CC0E0006 0BFC0706 0000C931
	v_pk_fma_f16 v7, v7, s3, 0xc931 op_sel_hi:[1,0,0]          // 00000049B464: CC0E0007 0BFC0707 0000C931
	v_pk_fma_f16 v11, v11, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000049B470: CC0E000B 0BFC070B 0000C931
	v_pk_fma_f16 v12, v12, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000049B47C: CC0E000C 0BFC070C 0000C931
	v_pk_fma_f16 v13, v13, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000049B488: CC0E000D 0BFC070D 0000C931
	v_pk_fma_f16 v14, v14, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000049B494: CC0E000E 0BFC070E 0000C931
	v_pk_fma_f16 v17, v17, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000049B4A0: CC0E0011 0BFC0711 0000C931
	v_pk_fma_f16 v18, v18, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000049B4AC: CC0E0012 0BFC0712 0000C931
	v_pk_fma_f16 v19, v19, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000049B4B8: CC0E0013 0BFC0713 0000C931
	v_pk_fma_f16 v15, v15, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000049B4C4: CC0E000F 0BFC070F 0000C931
	v_pk_fma_f16 v16, v16, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000049B4D0: CC0E0010 0BFC0710 0000C931
	v_pk_fma_f16 v8, v8, s3, 0xc931 op_sel_hi:[1,0,0]          // 00000049B4DC: CC0E0008 0BFC0708 0000C931
	v_pk_fma_f16 v20, v20, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000049B4E8: CC0E0014 0BFC0714 0000C931
	v_pk_fma_f16 v9, v9, s3, 0xc931 op_sel_hi:[1,0,0]          // 00000049B4F4: CC0E0009 0BFC0709 0000C931
	v_pk_fma_f16 v10, v10, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000049B500: CC0E000A 0BFC070A 0000C931
	v_pk_fma_f16 v5, v5, s3, 0xc931 op_sel_hi:[1,0,0]          // 00000049B50C: CC0E0005 0BFC0705 0000C931
	v_cvt_f32_f16_e32 v21, v134/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049B518: 7E2A1786
	v_cvt_f32_f16_e32 v6, v6                                   // 00000049B51C: 7E0C1706
	v_cvt_f32_f16_e32 v22, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049B520: 7E2C1787
	v_cvt_f32_f16_e32 v7, v7                                   // 00000049B524: 7E0E1707
	v_cvt_f32_f16_e32 v23, v139/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049B528: 7E2E178B
	v_cvt_f32_f16_e32 v11, v11                                 // 00000049B52C: 7E16170B
	v_cvt_f32_f16_e32 v24, v140/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049B530: 7E30178C
	v_cvt_f32_f16_e32 v12, v12                                 // 00000049B534: 7E18170C
	v_cvt_f32_f16_e32 v25, v141/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049B538: 7E32178D
	v_cvt_f32_f16_e32 v13, v13                                 // 00000049B53C: 7E1A170D
	v_cvt_f32_f16_e32 v26, v142/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049B540: 7E34178E
	v_cvt_f32_f16_e32 v14, v14                                 // 00000049B544: 7E1C170E
	v_cvt_f32_f16_e32 v27, v145/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049B548: 7E361791
	v_cvt_f32_f16_e32 v17, v17                                 // 00000049B54C: 7E221711
	v_cvt_f32_f16_e32 v28, v146/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049B550: 7E381792
	v_cvt_f32_f16_e32 v18, v18                                 // 00000049B554: 7E241712
	v_cvt_f32_f16_e32 v29, v147/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049B558: 7E3A1793
	v_cvt_f32_f16_e32 v19, v19                                 // 00000049B55C: 7E261713
	v_cvt_f32_f16_e32 v30, v143/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049B560: 7E3C178F
	v_cvt_f32_f16_e32 v15, v15                                 // 00000049B564: 7E1E170F
	v_cvt_f32_f16_e32 v31, v144/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049B568: 7E3E1790
	v_cvt_f32_f16_e32 v16, v16                                 // 00000049B56C: 7E201710
	v_cvt_f32_f16_e32 v32, v136/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049B570: 7E401788
	v_cvt_f32_f16_e32 v8, v8                                   // 00000049B574: 7E101708
	v_cvt_f32_f16_e32 v33, v148/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049B578: 7E421794
	v_cvt_f32_f16_e32 v20, v20                                 // 00000049B57C: 7E281714
	v_cvt_f32_f16_e32 v34, v137/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049B580: 7E441789
	v_cvt_f32_f16_e32 v9, v9                                   // 00000049B584: 7E121709
	v_cvt_f32_f16_e32 v35, v138/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049B588: 7E46178A
	v_cvt_f32_f16_e32 v10, v10                                 // 00000049B58C: 7E14170A
	v_cvt_f32_f16_e32 v36, v133/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049B590: 7E481785
	v_cvt_f32_f16_e32 v5, v5                                   // 00000049B594: 7E0A1705
	ds_store_b32 v58, v6                                       // 00000049B598: D8340000 0000063A
	ds_store_b32 v60, v21                                      // 00000049B5A0: D8340000 0000153C
	ds_store_b32 v61, v7                                       // 00000049B5A8: D8340000 0000073D
	ds_store_b32 v62, v22                                      // 00000049B5B0: D8340000 0000163E
	ds_store_b32 v63, v11                                      // 00000049B5B8: D8340000 00000B3F
	ds_store_b32 v64, v23                                      // 00000049B5C0: D8340000 00001740
	ds_store_b32 v65, v12                                      // 00000049B5C8: D8340000 00000C41
	ds_store_b32 v66, v24                                      // 00000049B5D0: D8340000 00001842
	ds_store_b32 v67, v13                                      // 00000049B5D8: D8340000 00000D43
	ds_store_b32 v68, v25                                      // 00000049B5E0: D8340000 00001944
	ds_store_b32 v69, v14                                      // 00000049B5E8: D8340000 00000E45
	ds_store_b32 v70, v26                                      // 00000049B5F0: D8340000 00001A46
	ds_store_b32 v71, v17                                      // 00000049B5F8: D8340000 00001147
	ds_store_b32 v72, v27                                      // 00000049B600: D8340000 00001B48
	ds_store_b32 v73, v18                                      // 00000049B608: D8340000 00001249
	ds_store_b32 v74, v28                                      // 00000049B610: D8340000 00001C4A
	ds_store_b32 v47, v19                                      // 00000049B618: D8340000 0000132F
	ds_store_b32 v75, v29                                      // 00000049B620: D8340000 00001D4B
	ds_store_b32 v76, v15                                      // 00000049B628: D8340000 00000F4C
	ds_store_b32 v77, v30                                      // 00000049B630: D8340000 00001E4D
	ds_store_b32 v44, v16                                      // 00000049B638: D8340000 0000102C
	ds_store_b32 v45, v31                                      // 00000049B640: D8340000 00001F2D
	ds_store_b32 v46, v8                                       // 00000049B648: D8340000 0000082E
	ds_store_b32 v78, v32                                      // 00000049B650: D8340000 0000204E
	ds_store_b32 v48, v20                                      // 00000049B658: D8340000 00001430
	ds_store_b32 v49, v33                                      // 00000049B660: D8340000 00002131
	ds_store_b32 v50, v9                                       // 00000049B668: D8340000 00000932
	ds_store_b32 v51, v34                                      // 00000049B670: D8340000 00002233
	ds_store_b32 v52, v10                                      // 00000049B678: D8340000 00000A34
	ds_store_b32 v53, v35                                      // 00000049B680: D8340000 00002335
	ds_store_b32 v54, v5                                       // 00000049B688: D8340000 00000536
	ds_store_b32 v59, v36                                      // 00000049B690: D8340000 0000243B
	s_waitcnt lgkmcnt(0)                                       // 00000049B698: BF89FC07
	s_barrier                                                  // 00000049B69C: BFBD0000
	buffer_gl0_inv                                             // 00000049B6A0: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 00000049B6A8: BE832000
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000049B6AC: BF870009
	s_xor_b32 s0, exec_lo, s3                                  // 00000049B6B0: 8D00037E
	v_and_b32_e32 v2, 0x7f, v0                                 // 00000049B6B4: 360400FF 0000007F
	s_or_saveexec_b32 s0, s0                                   // 00000049B6BC: BE802200
	v_lshrrev_b32_e32 v11, 5, v0                               // 00000049B6C0: 32160085
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049B6C4: BF870001
	v_lshlrev_b32_e32 v12, 3, v11                              // 00000049B6C8: 30181683
	s_xor_b32 exec_lo, exec_lo, s0                             // 00000049B6CC: 8D7E007E
	s_cbranch_execz 437                                        // 00000049B6D0: BFA501B5 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi3ELb1ELi16EEEvPKjiPKDF16_S5_Pti+0x14a8>
	v_and_b32_e32 v0, 0x60, v0                                 // 00000049B6D4: 360000FF 00000060
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000049B6DC: BF870112
	v_and_or_b32 v5, 0x60, v12, v4                             // 00000049B6E0: D6570005 041218FF 00000060
	v_or_b32_e32 v6, 1, v0                                     // 00000049B6EC: 380C0081
	v_or_b32_e32 v7, 2, v0                                     // 00000049B6F0: 380E0082
	v_or_b32_e32 v8, 3, v0                                     // 00000049B6F4: 38100083
	v_or_b32_e32 v9, 4, v0                                     // 00000049B6F8: 38120084
	v_lshlrev_b32_e32 v5, 9, v5                                // 00000049B6FC: 300A0A89
	v_or_b32_e32 v10, 5, v0                                    // 00000049B700: 38140085
	v_or_b32_e32 v14, 6, v0                                    // 00000049B704: 381C0086
	v_or_b32_e32 v15, 7, v0                                    // 00000049B708: 381E0087
	v_xor_b32_e32 v6, v6, v4                                   // 00000049B70C: 3A0C0906
	v_xor_b32_e32 v7, v7, v4                                   // 00000049B710: 3A0E0907
	v_xor_b32_e32 v8, v8, v4                                   // 00000049B714: 3A100908
	v_xor_b32_e32 v9, v9, v4                                   // 00000049B718: 3A120909
	v_lshl_or_b32 v13, v2, 2, v5                               // 00000049B71C: D656000D 04150502
	v_xor_b32_e32 v10, v10, v4                                 // 00000049B724: 3A14090A
	v_xor_b32_e32 v14, v14, v4                                 // 00000049B728: 3A1C090E
	v_xor_b32_e32 v15, v15, v4                                 // 00000049B72C: 3A1E090F
	v_lshl_or_b32 v6, v6, 2, v5                                // 00000049B730: D6560006 04150506
	v_lshl_or_b32 v7, v7, 2, v5                                // 00000049B738: D6560007 04150507
	v_lshl_or_b32 v8, v8, 2, v5                                // 00000049B740: D6560008 04150508
	v_lshl_or_b32 v9, v9, 2, v5                                // 00000049B748: D6560009 04150509
	v_lshl_or_b32 v10, v10, 2, v5                              // 00000049B750: D656000A 0415050A
	v_lshl_or_b32 v14, v14, 2, v5                              // 00000049B758: D656000E 0415050E
	v_lshl_or_b32 v15, v15, 2, v5                              // 00000049B760: D656000F 0415050F
	ds_load_b32 v20, v13                                       // 00000049B768: D8D80000 1400000D
	ds_load_b32 v21, v6                                        // 00000049B770: D8D80000 15000006
	ds_load_b32 v22, v7                                        // 00000049B778: D8D80000 16000007
	ds_load_b32 v23, v8                                        // 00000049B780: D8D80000 17000008
	ds_load_b32 v24, v9                                        // 00000049B788: D8D80000 18000009
	ds_load_b32 v25, v10                                       // 00000049B790: D8D80000 1900000A
	ds_load_b32 v26, v14                                       // 00000049B798: D8D80000 1A00000E
	ds_load_b32 v27, v15                                       // 00000049B7A0: D8D80000 1B00000F
	s_waitcnt lgkmcnt(6)                                       // 00000049B7A8: BF89FC67
	v_add_f32_e32 v70, v20, v21                                // 00000049B7AC: 068C2B14
	s_waitcnt lgkmcnt(4)                                       // 00000049B7B0: BF89FC47
	v_dual_sub_f32 v20, v20, v21 :: v_dual_add_f32 v21, v22, v23// 00000049B7B4: C9482B14 14142F16
	v_or_b32_e32 v16, 8, v0                                    // 00000049B7BC: 38200088
	v_or_b32_e32 v32, 16, v0                                   // 00000049B7C0: 38400090
	v_or_b32_e32 v48, 24, v0                                   // 00000049B7C4: 38600098
	v_or_b32_e32 v17, 9, v0                                    // 00000049B7C8: 38220089
	v_or_b32_e32 v33, 17, v0                                   // 00000049B7CC: 38420091
	v_or_b32_e32 v49, 25, v0                                   // 00000049B7D0: 38620099
	v_or_b32_e32 v18, 10, v0                                   // 00000049B7D4: 3824008A
	v_or_b32_e32 v34, 18, v0                                   // 00000049B7D8: 38440092
	v_or_b32_e32 v50, 26, v0                                   // 00000049B7DC: 3864009A
	v_or_b32_e32 v19, 11, v0                                   // 00000049B7E0: 3826008B
	v_or_b32_e32 v43, 19, v0                                   // 00000049B7E4: 38560093
	v_or_b32_e32 v59, 27, v0                                   // 00000049B7E8: 3876009B
	v_or_b32_e32 v28, 12, v0                                   // 00000049B7EC: 3838008C
	v_or_b32_e32 v44, 20, v0                                   // 00000049B7F0: 38580094
	v_or_b32_e32 v60, 28, v0                                   // 00000049B7F4: 3878009C
	v_xor_b32_e32 v16, v16, v4                                 // 00000049B7F8: 3A200910
	v_or_b32_e32 v29, 13, v0                                   // 00000049B7FC: 383A008D
	v_or_b32_e32 v30, 14, v0                                   // 00000049B800: 383C008E
	v_or_b32_e32 v31, 15, v0                                   // 00000049B804: 383E008F
	v_xor_b32_e32 v32, v32, v4                                 // 00000049B808: 3A400920
	v_or_b32_e32 v45, 21, v0                                   // 00000049B80C: 385A0095
	v_or_b32_e32 v46, 22, v0                                   // 00000049B810: 385C0096
	v_or_b32_e32 v47, 23, v0                                   // 00000049B814: 385E0097
	v_xor_b32_e32 v48, v48, v4                                 // 00000049B818: 3A600930
	v_or_b32_e32 v61, 29, v0                                   // 00000049B81C: 387A009D
	v_or_b32_e32 v62, 30, v0                                   // 00000049B820: 387C009E
	v_or_b32_e32 v0, 31, v0                                    // 00000049B824: 3800009F
	v_xor_b32_e32 v17, v17, v4                                 // 00000049B828: 3A220911
	v_xor_b32_e32 v33, v33, v4                                 // 00000049B82C: 3A420921
	v_xor_b32_e32 v49, v49, v4                                 // 00000049B830: 3A620931
	v_xor_b32_e32 v18, v18, v4                                 // 00000049B834: 3A240912
	v_xor_b32_e32 v34, v34, v4                                 // 00000049B838: 3A440922
	v_xor_b32_e32 v50, v50, v4                                 // 00000049B83C: 3A640932
	v_xor_b32_e32 v19, v19, v4                                 // 00000049B840: 3A260913
	v_xor_b32_e32 v43, v43, v4                                 // 00000049B844: 3A56092B
	v_xor_b32_e32 v59, v59, v4                                 // 00000049B848: 3A76093B
	v_xor_b32_e32 v28, v28, v4                                 // 00000049B84C: 3A38091C
	v_xor_b32_e32 v44, v44, v4                                 // 00000049B850: 3A58092C
	v_xor_b32_e32 v60, v60, v4                                 // 00000049B854: 3A78093C
	v_xor_b32_e32 v29, v29, v4                                 // 00000049B858: 3A3A091D
	v_xor_b32_e32 v30, v30, v4                                 // 00000049B85C: 3A3C091E
	v_xor_b32_e32 v31, v31, v4                                 // 00000049B860: 3A3E091F
	v_xor_b32_e32 v45, v45, v4                                 // 00000049B864: 3A5A092D
	v_xor_b32_e32 v46, v46, v4                                 // 00000049B868: 3A5C092E
	v_xor_b32_e32 v47, v47, v4                                 // 00000049B86C: 3A5E092F
	v_xor_b32_e32 v61, v61, v4                                 // 00000049B870: 3A7A093D
	v_xor_b32_e32 v62, v62, v4                                 // 00000049B874: 3A7C093E
	v_xor_b32_e32 v0, v0, v4                                   // 00000049B878: 3A000900
	v_sub_f32_e32 v22, v22, v23                                // 00000049B87C: 082C2F16
	v_lshl_or_b32 v16, v16, 2, v5                              // 00000049B880: D6560010 04150510
	v_lshl_or_b32 v32, v32, 2, v5                              // 00000049B888: D6560020 04150520
	v_lshl_or_b32 v48, v48, 2, v5                              // 00000049B890: D6560030 04150530
	v_lshl_or_b32 v17, v17, 2, v5                              // 00000049B898: D6560011 04150511
	v_lshl_or_b32 v33, v33, 2, v5                              // 00000049B8A0: D6560021 04150521
	v_lshl_or_b32 v49, v49, 2, v5                              // 00000049B8A8: D6560031 04150531
	v_lshl_or_b32 v18, v18, 2, v5                              // 00000049B8B0: D6560012 04150512
	v_lshl_or_b32 v34, v34, 2, v5                              // 00000049B8B8: D6560022 04150522
	v_lshl_or_b32 v50, v50, 2, v5                              // 00000049B8C0: D6560032 04150532
	v_lshl_or_b32 v19, v19, 2, v5                              // 00000049B8C8: D6560013 04150513
	v_lshl_or_b32 v43, v43, 2, v5                              // 00000049B8D0: D656002B 0415052B
	v_lshl_or_b32 v59, v59, 2, v5                              // 00000049B8D8: D656003B 0415053B
	v_lshl_or_b32 v28, v28, 2, v5                              // 00000049B8E0: D656001C 0415051C
	v_lshl_or_b32 v44, v44, 2, v5                              // 00000049B8E8: D656002C 0415052C
	v_lshl_or_b32 v60, v60, 2, v5                              // 00000049B8F0: D656003C 0415053C
	v_lshl_or_b32 v29, v29, 2, v5                              // 00000049B8F8: D656001D 0415051D
	v_lshl_or_b32 v30, v30, 2, v5                              // 00000049B900: D656001E 0415051E
	v_lshl_or_b32 v31, v31, 2, v5                              // 00000049B908: D656001F 0415051F
	ds_load_b32 v35, v16                                       // 00000049B910: D8D80000 23000010
	ds_load_b32 v36, v17                                       // 00000049B918: D8D80000 24000011
	ds_load_b32 v37, v18                                       // 00000049B920: D8D80000 25000012
	ds_load_b32 v38, v19                                       // 00000049B928: D8D80000 26000013
	ds_load_b32 v39, v28                                       // 00000049B930: D8D80000 2700001C
	ds_load_b32 v40, v29                                       // 00000049B938: D8D80000 2800001D
	ds_load_b32 v41, v30                                       // 00000049B940: D8D80000 2900001E
	ds_load_b32 v42, v31                                       // 00000049B948: D8D80000 2A00001F
	v_lshl_or_b32 v45, v45, 2, v5                              // 00000049B950: D656002D 0415052D
	v_lshl_or_b32 v46, v46, 2, v5                              // 00000049B958: D656002E 0415052E
	v_lshl_or_b32 v47, v47, 2, v5                              // 00000049B960: D656002F 0415052F
	ds_load_b32 v51, v32                                       // 00000049B968: D8D80000 33000020
	ds_load_b32 v52, v33                                       // 00000049B970: D8D80000 34000021
	ds_load_b32 v53, v34                                       // 00000049B978: D8D80000 35000022
	ds_load_b32 v54, v43                                       // 00000049B980: D8D80000 3600002B
	ds_load_b32 v55, v44                                       // 00000049B988: D8D80000 3700002C
	ds_load_b32 v56, v45                                       // 00000049B990: D8D80000 3800002D
	ds_load_b32 v57, v46                                       // 00000049B998: D8D80000 3900002E
	ds_load_b32 v58, v47                                       // 00000049B9A0: D8D80000 3A00002F
	v_lshl_or_b32 v61, v61, 2, v5                              // 00000049B9A8: D656003D 0415053D
	v_lshl_or_b32 v62, v62, 2, v5                              // 00000049B9B0: D656003E 0415053E
	v_lshl_or_b32 v0, v0, 2, v5                                // 00000049B9B8: D6560000 04150500
	ds_load_b32 v5, v48                                        // 00000049B9C0: D8D80000 05000030
	ds_load_b32 v63, v49                                       // 00000049B9C8: D8D80000 3F000031
	ds_load_b32 v64, v50                                       // 00000049B9D0: D8D80000 40000032
	ds_load_b32 v65, v59                                       // 00000049B9D8: D8D80000 4100003B
	ds_load_b32 v66, v60                                       // 00000049B9E0: D8D80000 4200003C
	ds_load_b32 v67, v61                                       // 00000049B9E8: D8D80000 4300003D
	ds_load_b32 v68, v62                                       // 00000049B9F0: D8D80000 4400003E
	ds_load_b32 v69, v0                                        // 00000049B9F8: D8D80000 45000000
	s_waitcnt lgkmcnt(26)                                      // 00000049BA00: BF89FDA7
	v_add_f32_e32 v23, v24, v25                                // 00000049BA04: 062E3318
	s_waitcnt lgkmcnt(24)                                      // 00000049BA08: BF89FD87
	v_dual_sub_f32 v24, v24, v25 :: v_dual_add_f32 v25, v26, v27// 00000049BA0C: C9483318 1818371A
	s_waitcnt lgkmcnt(22)                                      // 00000049BA14: BF89FD67
	v_dual_sub_f32 v26, v26, v27 :: v_dual_add_f32 v27, v35, v36// 00000049BA18: C948371A 1A1A4923
	s_waitcnt lgkmcnt(20)                                      // 00000049BA20: BF89FD47
	v_dual_sub_f32 v35, v35, v36 :: v_dual_add_f32 v36, v37, v38// 00000049BA24: C9484923 23244D25
	s_waitcnt lgkmcnt(18)                                      // 00000049BA2C: BF89FD27
	v_dual_sub_f32 v37, v37, v38 :: v_dual_add_f32 v38, v39, v40// 00000049BA30: C9484D25 25265127
	s_waitcnt lgkmcnt(16)                                      // 00000049BA38: BF89FD07
	v_dual_sub_f32 v39, v39, v40 :: v_dual_add_f32 v40, v41, v42// 00000049BA3C: C9485127 27285529
	s_waitcnt lgkmcnt(14)                                      // 00000049BA44: BF89FCE7
	v_dual_sub_f32 v41, v41, v42 :: v_dual_add_f32 v42, v51, v52// 00000049BA48: C9485529 292A6933
	s_waitcnt lgkmcnt(12)                                      // 00000049BA50: BF89FCC7
	v_dual_sub_f32 v51, v51, v52 :: v_dual_add_f32 v52, v53, v54// 00000049BA54: C9486933 33346D35
	s_waitcnt lgkmcnt(10)                                      // 00000049BA5C: BF89FCA7
	v_dual_sub_f32 v53, v53, v54 :: v_dual_add_f32 v54, v55, v56// 00000049BA60: C9486D35 35367137
	s_waitcnt lgkmcnt(8)                                       // 00000049BA68: BF89FC87
	v_dual_sub_f32 v55, v55, v56 :: v_dual_add_f32 v56, v57, v58// 00000049BA6C: C9487137 37387539
	v_sub_f32_e32 v57, v57, v58                                // 00000049BA74: 08727539
	s_waitcnt lgkmcnt(6)                                       // 00000049BA78: BF89FC67
	v_add_f32_e32 v58, v5, v63                                 // 00000049BA7C: 06747F05
	v_sub_f32_e32 v5, v5, v63                                  // 00000049BA80: 080A7F05
	s_waitcnt lgkmcnt(4)                                       // 00000049BA84: BF89FC47
	v_add_f32_e32 v63, v64, v65                                // 00000049BA88: 067E8340
	s_waitcnt lgkmcnt(2)                                       // 00000049BA8C: BF89FC27
	v_dual_sub_f32 v64, v64, v65 :: v_dual_add_f32 v65, v66, v67// 00000049BA90: C9488340 40408742
	s_waitcnt lgkmcnt(0)                                       // 00000049BA98: BF89FC07
	v_dual_sub_f32 v66, v66, v67 :: v_dual_add_f32 v67, v68, v69// 00000049BA9C: C9488742 42428B44
	v_sub_f32_e32 v68, v68, v69                                // 00000049BAA4: 08888B44
	v_add_f32_e32 v69, v70, v21                                // 00000049BAA8: 068A2B46
	v_dual_sub_f32 v21, v70, v21 :: v_dual_add_f32 v70, v20, v22// 00000049BAAC: C9482B46 15462D14
	v_sub_f32_e32 v20, v20, v22                                // 00000049BAB4: 08282D14
	v_add_f32_e32 v22, v23, v25                                // 00000049BAB8: 062C3317
	v_sub_f32_e32 v23, v23, v25                                // 00000049BABC: 082E3317
	v_add_f32_e32 v25, v24, v26                                // 00000049BAC0: 06323518
	v_sub_f32_e32 v24, v24, v26                                // 00000049BAC4: 08303518
	v_add_f32_e32 v26, v27, v36                                // 00000049BAC8: 0634491B
	v_sub_f32_e32 v27, v27, v36                                // 00000049BACC: 0836491B
	v_add_f32_e32 v36, v35, v37                                // 00000049BAD0: 06484B23
	v_sub_f32_e32 v35, v35, v37                                // 00000049BAD4: 08464B23
	v_add_f32_e32 v37, v38, v40                                // 00000049BAD8: 064A5126
	v_sub_f32_e32 v38, v38, v40                                // 00000049BADC: 084C5126
	v_add_f32_e32 v40, v39, v41                                // 00000049BAE0: 06505327
	v_sub_f32_e32 v39, v39, v41                                // 00000049BAE4: 084E5327
	v_add_f32_e32 v41, v42, v52                                // 00000049BAE8: 0652692A
	v_sub_f32_e32 v42, v42, v52                                // 00000049BAEC: 0854692A
	v_add_f32_e32 v52, v51, v53                                // 00000049BAF0: 06686B33
	v_sub_f32_e32 v51, v51, v53                                // 00000049BAF4: 08666B33
	v_add_f32_e32 v53, v54, v56                                // 00000049BAF8: 066A7136
	v_sub_f32_e32 v54, v54, v56                                // 00000049BAFC: 086C7136
	v_add_f32_e32 v56, v55, v57                                // 00000049BB00: 06707337
	v_sub_f32_e32 v55, v55, v57                                // 00000049BB04: 086E7337
	v_add_f32_e32 v57, v58, v63                                // 00000049BB08: 06727F3A
	v_dual_sub_f32 v58, v58, v63 :: v_dual_add_f32 v63, v5, v64// 00000049BB0C: C9487F3A 3A3E8105
	v_sub_f32_e32 v5, v5, v64                                  // 00000049BB14: 080A8105
	v_add_f32_e32 v64, v65, v67                                // 00000049BB18: 06808741
	v_sub_f32_e32 v65, v65, v67                                // 00000049BB1C: 08828741
	v_add_f32_e32 v67, v66, v68                                // 00000049BB20: 06868942
	v_sub_f32_e32 v66, v66, v68                                // 00000049BB24: 08848942
	v_add_f32_e32 v68, v69, v22                                // 00000049BB28: 06882D45
	v_dual_sub_f32 v22, v69, v22 :: v_dual_add_f32 v69, v70, v25// 00000049BB2C: C9482D45 16443346
	v_dual_sub_f32 v25, v70, v25 :: v_dual_add_f32 v70, v21, v23// 00000049BB34: C9483346 19462F15
	v_sub_f32_e32 v21, v21, v23                                // 00000049BB3C: 082A2F15
	v_add_f32_e32 v23, v20, v24                                // 00000049BB40: 062E3114
	v_sub_f32_e32 v20, v20, v24                                // 00000049BB44: 08283114
	v_add_f32_e32 v24, v26, v37                                // 00000049BB48: 06304B1A
	v_dual_sub_f32 v26, v26, v37 :: v_dual_add_f32 v37, v36, v40// 00000049BB4C: C9484B1A 1A245124
	v_sub_f32_e32 v36, v36, v40                                // 00000049BB54: 08485124
	v_add_f32_e32 v40, v27, v38                                // 00000049BB58: 06504D1B
	v_sub_f32_e32 v27, v27, v38                                // 00000049BB5C: 08364D1B
	v_add_f32_e32 v38, v35, v39                                // 00000049BB60: 064C4F23
	v_sub_f32_e32 v35, v35, v39                                // 00000049BB64: 08464F23
	v_add_f32_e32 v39, v41, v53                                // 00000049BB68: 064E6B29
	v_sub_f32_e32 v41, v41, v53                                // 00000049BB6C: 08526B29
	v_add_f32_e32 v53, v52, v56                                // 00000049BB70: 066A7134
	v_sub_f32_e32 v52, v52, v56                                // 00000049BB74: 08687134
	v_add_f32_e32 v56, v42, v54                                // 00000049BB78: 06706D2A
	v_sub_f32_e32 v42, v42, v54                                // 00000049BB7C: 08546D2A
	v_add_f32_e32 v54, v51, v55                                // 00000049BB80: 066C6F33
	v_sub_f32_e32 v51, v51, v55                                // 00000049BB84: 08666F33
	v_add_f32_e32 v55, v57, v64                                // 00000049BB88: 066E8139
	v_dual_sub_f32 v57, v57, v64 :: v_dual_add_f32 v64, v63, v67// 00000049BB8C: C9488139 3940873F
	v_sub_f32_e32 v63, v63, v67                                // 00000049BB94: 087E873F
	v_add_f32_e32 v67, v58, v65                                // 00000049BB98: 0686833A
	v_dual_sub_f32 v58, v58, v65 :: v_dual_add_f32 v65, v5, v66// 00000049BB9C: C948833A 3A408505
	v_dual_sub_f32 v5, v5, v66 :: v_dual_add_f32 v66, v68, v24 // 00000049BBA4: C9488505 05423144
	v_sub_f32_e32 v24, v68, v24                                // 00000049BBAC: 08303144
	v_add_f32_e32 v68, v69, v37                                // 00000049BBB0: 06884B45
	v_sub_f32_e32 v37, v69, v37                                // 00000049BBB4: 084A4B45
	v_add_f32_e32 v69, v70, v40                                // 00000049BBB8: 068A5146
	v_sub_f32_e32 v40, v70, v40                                // 00000049BBBC: 08505146
	v_add_f32_e32 v70, v23, v38                                // 00000049BBC0: 068C4D17
	v_sub_f32_e32 v23, v23, v38                                // 00000049BBC4: 082E4D17
	v_add_f32_e32 v38, v22, v26                                // 00000049BBC8: 064C3516
	v_sub_f32_e32 v22, v22, v26                                // 00000049BBCC: 082C3516
	v_add_f32_e32 v26, v25, v36                                // 00000049BBD0: 06344919
	v_sub_f32_e32 v25, v25, v36                                // 00000049BBD4: 08324919
	v_add_f32_e32 v36, v21, v27                                // 00000049BBD8: 06483715
	v_sub_f32_e32 v21, v21, v27                                // 00000049BBDC: 082A3715
	v_add_f32_e32 v27, v20, v35                                // 00000049BBE0: 06364714
	v_sub_f32_e32 v20, v20, v35                                // 00000049BBE4: 08284714
	v_add_f32_e32 v35, v39, v55                                // 00000049BBE8: 06466F27
	v_sub_f32_e32 v39, v39, v55                                // 00000049BBEC: 084E6F27
	v_add_f32_e32 v55, v53, v64                                // 00000049BBF0: 066E8135
	v_dual_sub_f32 v53, v53, v64 :: v_dual_add_f32 v64, v56, v67// 00000049BBF4: C9488135 35408738
	v_dual_sub_f32 v56, v56, v67 :: v_dual_add_f32 v67, v54, v65// 00000049BBFC: C9488738 38428336
	v_sub_f32_e32 v54, v54, v65                                // 00000049BC04: 086C8336
	v_add_f32_e32 v65, v41, v57                                // 00000049BC08: 06827329
	v_sub_f32_e32 v41, v41, v57                                // 00000049BC0C: 08527329
	v_add_f32_e32 v57, v52, v63                                // 00000049BC10: 06727F34
	v_dual_sub_f32 v52, v52, v63 :: v_dual_add_f32 v63, v42, v58// 00000049BC14: C9487F34 343E752A
	v_sub_f32_e32 v42, v42, v58                                // 00000049BC1C: 0854752A
	v_add_f32_e32 v58, v51, v5                                 // 00000049BC20: 06740B33
	v_sub_f32_e32 v5, v51, v5                                  // 00000049BC24: 080A0B33
	v_add_f32_e32 v51, v66, v35                                // 00000049BC28: 06664742
	v_sub_f32_e32 v35, v66, v35                                // 00000049BC2C: 08464742
	v_add_f32_e32 v66, v68, v55                                // 00000049BC30: 06846F44
	v_dual_sub_f32 v55, v68, v55 :: v_dual_add_f32 v68, v69, v64// 00000049BC34: C9486F44 37448145
	v_dual_sub_f32 v64, v69, v64 :: v_dual_add_f32 v69, v70, v67// 00000049BC3C: C9488145 40448746
	v_sub_f32_e32 v67, v70, v67                                // 00000049BC44: 08868746
	v_add_f32_e32 v70, v38, v65                                // 00000049BC48: 068C8326
	v_sub_f32_e32 v38, v38, v65                                // 00000049BC4C: 084C8326
	v_add_f32_e32 v65, v26, v57                                // 00000049BC50: 0682731A
	v_dual_sub_f32 v26, v26, v57 :: v_dual_add_f32 v57, v36, v63// 00000049BC54: C948731A 1A387F24
	v_dual_sub_f32 v36, v36, v63 :: v_dual_add_f32 v63, v27, v58// 00000049BC5C: C9487F24 243E751B
	v_dual_sub_f32 v27, v27, v58 :: v_dual_add_f32 v58, v24, v39// 00000049BC64: C948751B 1B3A4F18
	v_dual_sub_f32 v24, v24, v39 :: v_dual_add_f32 v39, v37, v53// 00000049BC6C: C9484F18 18266B25
	v_sub_f32_e32 v37, v37, v53                                // 00000049BC74: 084A6B25
	v_add_f32_e32 v53, v40, v56                                // 00000049BC78: 066A7128
	v_sub_f32_e32 v40, v40, v56                                // 00000049BC7C: 08507128
	v_add_f32_e32 v56, v23, v54                                // 00000049BC80: 06706D17
	v_dual_sub_f32 v23, v23, v54 :: v_dual_add_f32 v54, v22, v41// 00000049BC84: C9486D17 17365316
	v_dual_sub_f32 v22, v22, v41 :: v_dual_add_f32 v41, v25, v52// 00000049BC8C: C9485316 16286919
	v_sub_f32_e32 v25, v25, v52                                // 00000049BC94: 08326919
	v_add_f32_e32 v52, v21, v42                                // 00000049BC98: 06685515
	v_dual_sub_f32 v21, v21, v42 :: v_dual_add_f32 v42, v20, v5// 00000049BC9C: C9485515 152A0B14
	v_sub_f32_e32 v5, v20, v5                                  // 00000049BCA4: 080A0B14
	ds_store_b32 v13, v51                                      // 00000049BCA8: D8340000 0000330D
	ds_store_b32 v6, v66                                       // 00000049BCB0: D8340000 00004206
	ds_store_b32 v7, v68                                       // 00000049BCB8: D8340000 00004407
	ds_store_b32 v8, v69                                       // 00000049BCC0: D8340000 00004508
	ds_store_b32 v9, v70                                       // 00000049BCC8: D8340000 00004609
	ds_store_b32 v10, v65                                      // 00000049BCD0: D8340000 0000410A
	ds_store_b32 v14, v57                                      // 00000049BCD8: D8340000 0000390E
	ds_store_b32 v15, v63                                      // 00000049BCE0: D8340000 00003F0F
	ds_store_b32 v16, v58                                      // 00000049BCE8: D8340000 00003A10
	ds_store_b32 v17, v39                                      // 00000049BCF0: D8340000 00002711
	ds_store_b32 v18, v53                                      // 00000049BCF8: D8340000 00003512
	ds_store_b32 v19, v56                                      // 00000049BD00: D8340000 00003813
	ds_store_b32 v28, v54                                      // 00000049BD08: D8340000 0000361C
	ds_store_b32 v29, v41                                      // 00000049BD10: D8340000 0000291D
	ds_store_b32 v30, v52                                      // 00000049BD18: D8340000 0000341E
	ds_store_b32 v31, v42                                      // 00000049BD20: D8340000 00002A1F
	ds_store_b32 v32, v35                                      // 00000049BD28: D8340000 00002320
	ds_store_b32 v33, v55                                      // 00000049BD30: D8340000 00003721
	ds_store_b32 v34, v64                                      // 00000049BD38: D8340000 00004022
	ds_store_b32 v43, v67                                      // 00000049BD40: D8340000 0000432B
	ds_store_b32 v44, v38                                      // 00000049BD48: D8340000 0000262C
	ds_store_b32 v45, v26                                      // 00000049BD50: D8340000 00001A2D
	ds_store_b32 v46, v36                                      // 00000049BD58: D8340000 0000242E
	ds_store_b32 v47, v27                                      // 00000049BD60: D8340000 00001B2F
	ds_store_b32 v48, v24                                      // 00000049BD68: D8340000 00001830
	ds_store_b32 v49, v37                                      // 00000049BD70: D8340000 00002531
	ds_store_b32 v50, v40                                      // 00000049BD78: D8340000 00002832
	ds_store_b32 v59, v23                                      // 00000049BD80: D8340000 0000173B
	ds_store_b32 v60, v22                                      // 00000049BD88: D8340000 0000163C
	ds_store_b32 v61, v25                                      // 00000049BD90: D8340000 0000193D
	ds_store_b32 v62, v21                                      // 00000049BD98: D8340000 0000153E
	ds_store_b32 v0, v5                                        // 00000049BDA0: D8340000 00000500
	s_or_b32 exec_lo, exec_lo, s0                              // 00000049BDA8: 8C7E007E
	v_or_b32_e32 v0, 32, v3                                    // 00000049BDAC: 380006A0
	v_or_b32_e32 v5, 64, v3                                    // 00000049BDB0: 380A06C0
	v_or_b32_e32 v6, 0x60, v3                                  // 00000049BDB4: 380C06FF 00000060
	v_lshlrev_b32_e32 v14, 9, v2                               // 00000049BDBC: 301C0489
	v_xor_b32_e32 v7, v3, v4                                   // 00000049BDC0: 3A0E0903
	v_xor_b32_e32 v0, v0, v4                                   // 00000049BDC4: 3A000900
	v_xor_b32_e32 v5, v5, v4                                   // 00000049BDC8: 3A0A0905
	v_xor_b32_e32 v6, v6, v4                                   // 00000049BDCC: 3A0C0906
	s_waitcnt lgkmcnt(0)                                       // 00000049BDD0: BF89FC07
	v_lshl_or_b32 v13, v7, 2, v14                              // 00000049BDD4: D656000D 04390507
	v_lshl_or_b32 v0, v0, 2, v14                               // 00000049BDDC: D6560000 04390500
	v_lshl_or_b32 v5, v5, 2, v14                               // 00000049BDE4: D6560005 04390505
	v_lshl_or_b32 v6, v6, 2, v14                               // 00000049BDEC: D6560006 04390506
	s_barrier                                                  // 00000049BDF4: BFBD0000
	buffer_gl0_inv                                             // 00000049BDF8: E0AC0000 00000000
	ds_load_b32 v7, v13                                        // 00000049BE00: D8D80000 0700000D
	ds_load_b32 v8, v0                                         // 00000049BE08: D8D80000 08000000
	ds_load_b32 v9, v5                                         // 00000049BE10: D8D80000 09000005
	ds_load_b32 v15, v6                                        // 00000049BE18: D8D80000 0F000006
	v_or_b32_e32 v10, 4, v3                                    // 00000049BE20: 38140684
	v_cvt_f32_f16_e32 v17, v129/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049BE24: 7E221781
	v_or_b32_e32 v18, 36, v3                                   // 00000049BE28: 382406A4
	v_or_b32_e32 v19, 0x44, v3                                 // 00000049BE2C: 382606FF 00000044
	v_or_b32_e32 v20, 0x64, v3                                 // 00000049BE34: 382806FF 00000064
	v_xor_b32_e32 v16, v10, v4                                 // 00000049BE3C: 3A20090A
	.long 0xd7600000                                           // 00000049BE40: D7600000
	v_cndmask_b32_e32 v0, v17, v136, vcc_lo                    // 00000049BE44: 02011111
	.long 0xd7600003                                           // 00000049BE48: D7600003
	v_cndmask_b32_e32 v0, v17, v144, vcc_lo                    // 00000049BE4C: 02012111
	.long 0xd7600004                                           // 00000049BE50: D7600004
	v_cndmask_b32_e32 v0, v17, v152, vcc_lo                    // 00000049BE54: 02013111
	v_xor_b32_e32 v20, v20, v4                                 // 00000049BE58: 3A280914
	.long 0xd7600005                                           // 00000049BE5C: D7600005
	v_cndmask_b32_e32 v0, v17, v153, vcc_lo                    // 00000049BE60: 02013311
	.long 0xd7600006                                           // 00000049BE64: D7600006
	v_cndmask_b32_e32 v0, v17, v159, vcc_lo                    // 00000049BE68: 02013F11
	s_waitcnt lgkmcnt(2)                                       // 00000049BE6C: BF89FC27
	v_add_f32_e32 v22, v7, v8                                  // 00000049BE70: 062C1107
	s_waitcnt lgkmcnt(0)                                       // 00000049BE74: BF89FC07
	v_dual_sub_f32 v7, v7, v8 :: v_dual_sub_f32 v8, v9, v15    // 00000049BE78: C94A1107 07081F09
	v_lshl_or_b32 v16, v16, 2, v14                             // 00000049BE80: D6560010 04390510
	v_add_f32_e32 v15, v9, v15                                 // 00000049BE88: 061E1F09
	v_lshl_or_b32 v20, v20, 2, v14                             // 00000049BE8C: D6560014 04390514
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049BE94: BF870004
	v_add_f32_e32 v9, v7, v8                                   // 00000049BE98: 06121107
	ds_load_b32 v21, v16                                       // 00000049BE9C: D8D80000 15000010
	v_sub_f32_e32 v23, v22, v15                                // 00000049BEA4: 082E1F16
	v_add_f32_e32 v15, v22, v15                                // 00000049BEA8: 061E1F16
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 00000049BEAC: 101212FF 3DB504F3
	v_sub_f32_e32 v7, v7, v8                                   // 00000049BEB4: 080E1107
	v_xor_b32_e32 v8, v18, v4                                  // 00000049BEB8: 3A100912
	v_xor_b32_e32 v18, v19, v4                                 // 00000049BEBC: 3A240913
	v_mul_f32_e32 v19, 0x3db504f3, v23                         // 00000049BEC0: 10262EFF 3DB504F3
	v_mul_f32_e32 v9, s0, v9                                   // 00000049BEC8: 10121200
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 00000049BECC: 100E0EFF 3DB504F3
	v_lshl_or_b32 v8, v8, 2, v14                               // 00000049BED4: D6560008 04390508
	v_lshl_or_b32 v18, v18, 2, v14                             // 00000049BEDC: D6560012 04390512
	v_mul_f32_e32 v19, s3, v19                                 // 00000049BEE4: 10262603
	v_or_b32_e32 v23, 0x68, v3                                 // 00000049BEE8: 382E06FF 00000068
	v_mul_f32_e32 v7, s4, v7                                   // 00000049BEF0: 100E0E04
	ds_store_b32 v0, v9                                        // 00000049BEF4: D8340000 00000900
	ds_store_b32 v5, v19                                       // 00000049BEFC: D8340000 00001305
	ds_store_b32 v6, v7                                        // 00000049BF04: D8340000 00000706
	ds_load_b32 v0, v8                                         // 00000049BF0C: D8D80000 00000008
	ds_load_b32 v5, v18                                        // 00000049BF14: D8D80000 05000012
	ds_load_b32 v6, v20                                        // 00000049BF1C: D8D80000 06000014
	v_or_b32_e32 v9, 8, v3                                     // 00000049BF24: 38120688
	v_or_b32_e32 v7, 40, v3                                    // 00000049BF28: 380E06A8
	v_or_b32_e32 v19, 0x48, v3                                 // 00000049BF2C: 382606FF 00000048
	.long 0xd7600000                                           // 00000049BF34: D7600000
	v_cndmask_b32_e32 v0, v17, v129, vcc_lo                    // 00000049BF38: 02010311
	.long 0xd7600003                                           // 00000049BF3C: D7600003
	v_cndmask_b32_e32 v0, v17, v137, vcc_lo                    // 00000049BF40: 02011311
	v_xor_b32_e32 v24, v9, v4                                  // 00000049BF44: 3A300909
	v_xor_b32_e32 v7, v7, v4                                   // 00000049BF48: 3A0E0907
	.long 0xd7600004                                           // 00000049BF4C: D7600004
	v_cndmask_b32_e32 v0, v17, v145, vcc_lo                    // 00000049BF50: 02012311
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 00000049BF54: 101E1EFF 3DB504F3
	s_waitcnt lgkmcnt(2)                                       // 00000049BF5C: BF89FC27
	v_add_f32_e32 v25, v21, v0                                 // 00000049BF60: 06320115
	v_sub_f32_e32 v0, v21, v0                                  // 00000049BF64: 08000115
	s_waitcnt lgkmcnt(0)                                       // 00000049BF68: BF89FC07
	v_add_f32_e32 v21, v5, v6                                  // 00000049BF6C: 062A0D05
	v_sub_f32_e32 v5, v5, v6                                   // 00000049BF70: 080A0D05
	v_xor_b32_e32 v6, v19, v4                                  // 00000049BF74: 3A0C0913
	v_xor_b32_e32 v19, v23, v4                                 // 00000049BF78: 3A260917
	v_lshl_or_b32 v23, v24, 2, v14                             // 00000049BF7C: D6560017 04390518
	v_add_f32_e32 v24, v25, v21                                // 00000049BF84: 06302B19
	v_add_f32_e32 v26, v0, v5                                  // 00000049BF88: 06340B00
	v_sub_f32_e32 v21, v25, v21                                // 00000049BF8C: 082A2B19
	v_sub_f32_e32 v0, v0, v5                                   // 00000049BF90: 08000B00
	v_lshl_or_b32 v5, v7, 2, v14                               // 00000049BF94: D6560005 04390507
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049BF9C: BF870194
	v_dual_mul_f32 v7, 0x3db504f3, v24 :: v_dual_mul_f32 v24, 0x3db504f3, v26// 00000049BFA0: C8C630FF 071834FF 3DB504F3
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_mul_f32 v0, 0x3db504f3, v0// 00000049BFAC: C8C62AFF 150000FF 3DB504F3
	v_lshl_or_b32 v6, v6, 2, v14                               // 00000049BFB8: D6560006 04390506
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000049BFC0: BF870223
	v_dual_mul_f32 v7, s0, v7 :: v_dual_mul_f32 v24, s3, v24   // 00000049BFC4: C8C60E00 07183003
	v_lshl_or_b32 v19, v19, 2, v14                             // 00000049BFCC: D6560013 04390513
	v_mul_f32_e32 v0, s5, v0                                   // 00000049BFD4: 10000005
	.long 0xd7600005                                           // 00000049BFD8: D7600005
	v_cndmask_b32_e32 v0, v17, v154, vcc_lo                    // 00000049BFDC: 02013511
	v_mul_f32_e32 v21, s4, v21                                 // 00000049BFE0: 102A2A04
	ds_store_b32 v16, v7                                       // 00000049BFE4: D8340000 00000710
	ds_store_b32 v8, v24                                       // 00000049BFEC: D8340000 00001808
	ds_store_b32 v18, v21                                      // 00000049BFF4: D8340000 00001512
	ds_store_b32 v20, v0                                       // 00000049BFFC: D8340000 00000014
	ds_load_b32 v0, v23                                        // 00000049C004: D8D80000 00000017
	ds_load_b32 v7, v5                                         // 00000049C00C: D8D80000 07000005
	ds_load_b32 v16, v6                                        // 00000049C014: D8D80000 10000006
	ds_load_b32 v18, v19                                       // 00000049C01C: D8D80000 12000013
	v_or_b32_e32 v8, 12, v3                                    // 00000049C024: 3810068C
	v_or_b32_e32 v20, 44, v3                                   // 00000049C028: 382806AC
	v_or_b32_e32 v21, 0x4c, v3                                 // 00000049C02C: 382A06FF 0000004C
	v_or_b32_e32 v24, 0x6c, v3                                 // 00000049C034: 383006FF 0000006C
	.long 0xd7600000                                           // 00000049C03C: D7600000
	v_cndmask_b32_e32 v0, v17, v130, vcc_lo                    // 00000049C040: 02010511
	v_xor_b32_e32 v25, v8, v4                                  // 00000049C044: 3A320908
	v_xor_b32_e32 v20, v20, v4                                 // 00000049C048: 3A280914
	.long 0xd7600003                                           // 00000049C04C: D7600003
	v_cndmask_b32_e32 v0, v17, v138, vcc_lo                    // 00000049C050: 02011511
	.long 0xd7600004                                           // 00000049C054: D7600004
	v_cndmask_b32_e32 v0, v17, v146, vcc_lo                    // 00000049C058: 02012511
	s_waitcnt lgkmcnt(2)                                       // 00000049C05C: BF89FC27
	v_add_f32_e32 v26, v0, v7                                  // 00000049C060: 06340F00
	v_sub_f32_e32 v0, v0, v7                                   // 00000049C064: 08000F00
	s_waitcnt lgkmcnt(0)                                       // 00000049C068: BF89FC07
	v_add_f32_e32 v7, v16, v18                                 // 00000049C06C: 060E2510
	v_sub_f32_e32 v16, v16, v18                                // 00000049C070: 08202510
	v_xor_b32_e32 v18, v21, v4                                 // 00000049C074: 3A240915
	v_xor_b32_e32 v21, v24, v4                                 // 00000049C078: 3A2A0918
	v_lshl_or_b32 v24, v25, 2, v14                             // 00000049C07C: D6560018 04390519
	v_add_f32_e32 v25, v26, v7                                 // 00000049C084: 06320F1A
	v_add_f32_e32 v27, v0, v16                                 // 00000049C088: 06362100
	v_dual_sub_f32 v7, v26, v7 :: v_dual_sub_f32 v0, v0, v16   // 00000049C08C: C94A0F1A 07002100
	v_lshl_or_b32 v16, v20, 2, v14                             // 00000049C094: D6560010 04390514
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049C09C: BF870193
	v_dual_mul_f32 v20, 0x3db504f3, v25 :: v_dual_mul_f32 v25, 0x3db504f3, v27// 00000049C0A0: C8C632FF 141836FF 3DB504F3
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v0, 0x3db504f3, v0// 00000049C0AC: C8C60EFF 070000FF 3DB504F3
	v_lshl_or_b32 v18, v18, 2, v14                             // 00000049C0B8: D6560012 04390512
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049C0C0: BF870193
	v_dual_mul_f32 v20, s0, v20 :: v_dual_mul_f32 v25, s3, v25 // 00000049C0C4: C8C62800 14183203
	v_dual_mul_f32 v7, s4, v7 :: v_dual_mul_f32 v0, s5, v0     // 00000049C0CC: C8C60E04 07000005
	v_lshl_or_b32 v21, v21, 2, v14                             // 00000049C0D4: D6560015 04390515
	ds_store_b32 v23, v20                                      // 00000049C0DC: D8340000 00001417
	ds_store_b32 v5, v25                                       // 00000049C0E4: D8340000 00001905
	ds_store_b32 v6, v7                                        // 00000049C0EC: D8340000 00000706
	ds_store_b32 v19, v0                                       // 00000049C0F4: D8340000 00000013
	ds_load_b32 v0, v24                                        // 00000049C0FC: D8D80000 00000018
	ds_load_b32 v5, v16                                        // 00000049C104: D8D80000 05000010
	ds_load_b32 v6, v18                                        // 00000049C10C: D8D80000 06000012
	ds_load_b32 v19, v21                                       // 00000049C114: D8D80000 13000015
	v_or_b32_e32 v7, 16, v3                                    // 00000049C11C: 380E0690
	v_or_b32_e32 v23, 0x50, v3                                 // 00000049C120: 382E06FF 00000050
	v_or_b32_e32 v25, 0x70, v3                                 // 00000049C128: 383206FF 00000070
	.long 0xd7600000                                           // 00000049C130: D7600000
	v_cndmask_b32_e32 v0, v17, v131, vcc_lo                    // 00000049C134: 02010711
	.long 0xd7600003                                           // 00000049C138: D7600003
	v_cndmask_b32_e32 v0, v17, v139, vcc_lo                    // 00000049C13C: 02011711
	v_xor_b32_e32 v26, v7, v4                                  // 00000049C140: 3A340907
	v_or_b32_e32 v20, 48, v3                                   // 00000049C144: 382806B0
	.long 0xd7600005                                           // 00000049C148: D7600005
	v_cndmask_b32_e32 v0, v17, v155, vcc_lo                    // 00000049C14C: 02013711
	.long 0xd7600004                                           // 00000049C150: D7600004
	v_cndmask_b32_e32 v0, v17, v147, vcc_lo                    // 00000049C154: 02012711
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000049C158: BF870093
	v_xor_b32_e32 v20, v20, v4                                 // 00000049C15C: 3A280914
	v_lshl_or_b32 v20, v20, 2, v14                             // 00000049C160: D6560014 04390514
	s_waitcnt lgkmcnt(2)                                       // 00000049C168: BF89FC27
	v_add_f32_e32 v27, v0, v5                                  // 00000049C16C: 06360B00
	s_waitcnt lgkmcnt(0)                                       // 00000049C170: BF89FC07
	v_dual_sub_f32 v0, v0, v5 :: v_dual_add_f32 v5, v6, v19    // 00000049C174: C9480B00 00042706
	v_sub_f32_e32 v6, v6, v19                                  // 00000049C17C: 080C2706
	v_xor_b32_e32 v19, v23, v4                                 // 00000049C180: 3A260917
	v_xor_b32_e32 v23, v25, v4                                 // 00000049C184: 3A2E0919
	v_lshl_or_b32 v25, v26, 2, v14                             // 00000049C188: D6560019 0439051A
	v_add_f32_e32 v26, v27, v5                                 // 00000049C190: 06340B1B
	v_add_f32_e32 v28, v0, v6                                  // 00000049C194: 06380D00
	v_sub_f32_e32 v0, v0, v6                                   // 00000049C198: 08000D00
	v_lshl_or_b32 v19, v19, 2, v14                             // 00000049C19C: D6560013 04390513
	v_lshl_or_b32 v23, v23, 2, v14                             // 00000049C1A4: D6560017 04390517
	v_mul_f32_e32 v6, 0x3db504f3, v26                          // 00000049C1AC: 100C34FF 3DB504F3
	v_mul_f32_e32 v26, 0x3db504f3, v28                         // 00000049C1B4: 103438FF 3DB504F3
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 00000049C1BC: 100000FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049C1C4: BF870193
	v_mul_f32_e32 v6, s0, v6                                   // 00000049C1C8: 100C0C00
	v_dual_mul_f32 v26, s3, v26 :: v_dual_sub_f32 v5, v27, v5  // 00000049C1CC: C8CA3403 1A040B1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000049C1D4: BF8700D3
	v_mul_f32_e32 v0, s5, v0                                   // 00000049C1D8: 10000005
	.long 0xd7600003                                           // 00000049C1DC: D7600003
	v_cndmask_b32_e32 v0, v17, v140, vcc_lo                    // 00000049C1E0: 02011911
	.long 0xd7600005                                           // 00000049C1E4: D7600005
	v_cndmask_b32_e32 v0, v17, v156, vcc_lo                    // 00000049C1E8: 02013911
	.long 0xd7600000                                           // 00000049C1EC: D7600000
	v_cndmask_b32_e32 v0, v17, v132, vcc_lo                    // 00000049C1F0: 02010911
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 00000049C1F4: 100A0AFF 3DB504F3
	v_mul_f32_e32 v5, s4, v5                                   // 00000049C1FC: 100A0A04
	ds_store_b32 v24, v6                                       // 00000049C200: D8340000 00000618
	ds_store_b32 v16, v26                                      // 00000049C208: D8340000 00001A10
	ds_store_b32 v18, v5                                       // 00000049C210: D8340000 00000512
	ds_store_b32 v21, v0                                       // 00000049C218: D8340000 00000015
	ds_load_b32 v0, v25                                        // 00000049C220: D8D80000 00000019
	ds_load_b32 v5, v20                                        // 00000049C228: D8D80000 05000014
	ds_load_b32 v16, v19                                       // 00000049C230: D8D80000 10000013
	ds_load_b32 v18, v23                                       // 00000049C238: D8D80000 12000017
	v_or_b32_e32 v6, 20, v3                                    // 00000049C240: 380C0694
	v_or_b32_e32 v21, 52, v3                                   // 00000049C244: 382A06B4
	v_or_b32_e32 v24, 0x54, v3                                 // 00000049C248: 383006FF 00000054
	v_or_b32_e32 v26, 0x74, v3                                 // 00000049C250: 383406FF 00000074
	.long 0xd7600004                                           // 00000049C258: D7600004
	v_cndmask_b32_e32 v0, v17, v148, vcc_lo                    // 00000049C25C: 02012911
	v_xor_b32_e32 v27, v6, v4                                  // 00000049C260: 3A360906
	v_xor_b32_e32 v21, v21, v4                                 // 00000049C264: 3A2A0915
	s_waitcnt lgkmcnt(2)                                       // 00000049C268: BF89FC27
	v_add_f32_e32 v28, v0, v5                                  // 00000049C26C: 06380B00
	v_sub_f32_e32 v0, v0, v5                                   // 00000049C270: 08000B00
	s_waitcnt lgkmcnt(0)                                       // 00000049C274: BF89FC07
	v_add_f32_e32 v5, v16, v18                                 // 00000049C278: 060A2510
	v_sub_f32_e32 v16, v16, v18                                // 00000049C27C: 08202510
	v_xor_b32_e32 v18, v24, v4                                 // 00000049C280: 3A240918
	v_xor_b32_e32 v24, v26, v4                                 // 00000049C284: 3A30091A
	v_lshl_or_b32 v26, v27, 2, v14                             // 00000049C288: D656001A 0439051B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000049C290: BF870254
	v_add_f32_e32 v29, v0, v16                                 // 00000049C294: 063A2100
	v_sub_f32_e32 v0, v0, v16                                  // 00000049C298: 08002100
	v_lshl_or_b32 v16, v21, 2, v14                             // 00000049C29C: D6560010 04390515
	v_lshl_or_b32 v18, v18, 2, v14                             // 00000049C2A4: D6560012 04390512
	v_lshl_or_b32 v24, v24, 2, v14                             // 00000049C2AC: D6560018 04390518
	v_dual_mul_f32 v0, 0x3db504f3, v0 :: v_dual_add_f32 v27, v28, v5// 00000049C2B4: C8C800FF 001A0B1C 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000049C2C0: BF870241
	v_dual_mul_f32 v0, s5, v0 :: v_dual_mul_f32 v21, 0x3db504f3, v27// 00000049C2C4: C8C60005 001436FF 3DB504F3
	v_sub_f32_e32 v5, v28, v5                                  // 00000049C2D0: 080A0B1C
	v_mul_f32_e32 v27, 0x3db504f3, v29                         // 00000049C2D4: 10363AFF 3DB504F3
	.long 0xd7600005                                           // 00000049C2DC: D7600005
	v_cndmask_b32_e32 v0, v17, v157, vcc_lo                    // 00000049C2E0: 02013B11
	v_mul_f32_e32 v21, s0, v21                                 // 00000049C2E4: 102A2A00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049C2E8: BF870214
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 00000049C2EC: 100A0AFF 3DB504F3
	v_mul_f32_e32 v27, s3, v27                                 // 00000049C2F4: 10363603
	.long 0xd7600003                                           // 00000049C2F8: D7600003
	v_cndmask_b32_e32 v0, v17, v141, vcc_lo                    // 00000049C2FC: 02011B11
	.long 0xd7600000                                           // 00000049C300: D7600000
	v_cndmask_b32_e32 v0, v17, v133, vcc_lo                    // 00000049C304: 02010B11
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049C308: BF870004
	v_mul_f32_e32 v5, s4, v5                                   // 00000049C30C: 100A0A04
	ds_store_b32 v25, v21                                      // 00000049C310: D8340000 00001519
	ds_store_b32 v20, v27                                      // 00000049C318: D8340000 00001B14
	ds_store_b32 v19, v5                                       // 00000049C320: D8340000 00000513
	ds_store_b32 v23, v0                                       // 00000049C328: D8340000 00000017
	ds_load_b32 v0, v26                                        // 00000049C330: D8D80000 0000001A
	ds_load_b32 v19, v16                                       // 00000049C338: D8D80000 13000010
	ds_load_b32 v20, v18                                       // 00000049C340: D8D80000 14000012
	ds_load_b32 v21, v24                                       // 00000049C348: D8D80000 15000018
	v_or_b32_e32 v5, 24, v3                                    // 00000049C350: 380A0698
	v_or_b32_e32 v23, 56, v3                                   // 00000049C354: 382E06B8
	v_or_b32_e32 v25, 0x58, v3                                 // 00000049C358: 383206FF 00000058
	v_or_b32_e32 v27, 0x78, v3                                 // 00000049C360: 383606FF 00000078
	.long 0xd7600004                                           // 00000049C368: D7600004
	v_cndmask_b32_e32 v0, v17, v149, vcc_lo                    // 00000049C36C: 02012B11
	v_xor_b32_e32 v28, v5, v4                                  // 00000049C370: 3A380905
	v_xor_b32_e32 v23, v23, v4                                 // 00000049C374: 3A2E0917
	s_waitcnt lgkmcnt(2)                                       // 00000049C378: BF89FC27
	v_add_f32_e32 v29, v0, v19                                 // 00000049C37C: 063A2700
	v_sub_f32_e32 v0, v0, v19                                  // 00000049C380: 08002700
	s_waitcnt lgkmcnt(0)                                       // 00000049C384: BF89FC07
	v_add_f32_e32 v19, v20, v21                                // 00000049C388: 06262B14
	v_sub_f32_e32 v20, v20, v21                                // 00000049C38C: 08282B14
	v_xor_b32_e32 v21, v25, v4                                 // 00000049C390: 3A2A0919
	v_xor_b32_e32 v25, v27, v4                                 // 00000049C394: 3A32091B
	v_lshl_or_b32 v27, v28, 2, v14                             // 00000049C398: D656001B 0439051C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000049C3A0: BF870254
	v_add_f32_e32 v30, v0, v20                                 // 00000049C3A4: 063C2900
	v_sub_f32_e32 v0, v0, v20                                  // 00000049C3A8: 08002900
	v_lshl_or_b32 v20, v23, 2, v14                             // 00000049C3AC: D6560014 04390517
	v_lshl_or_b32 v21, v21, 2, v14                             // 00000049C3B4: D6560015 04390515
	v_lshl_or_b32 v25, v25, 2, v14                             // 00000049C3BC: D6560019 04390519
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 00000049C3C4: 100000FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000049C3CC: BF870131
	v_mul_f32_e32 v0, s5, v0                                   // 00000049C3D0: 10000005
	v_add_f32_e32 v28, v29, v19                                // 00000049C3D4: 0638271D
	.long 0xd7600005                                           // 00000049C3D8: D7600005
	v_cndmask_b32_e32 v0, v17, v158, vcc_lo                    // 00000049C3DC: 02013D11
	v_dual_mul_f32 v23, 0x3db504f3, v28 :: v_dual_mul_f32 v28, 0x3db504f3, v30// 00000049C3E0: C8C638FF 171C3CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000049C3EC: BF8701C1
	v_dual_mul_f32 v23, s0, v23 :: v_dual_mul_f32 v28, s3, v28 // 00000049C3F0: C8C62E00 171C3803
	v_sub_f32_e32 v19, v29, v19                                // 00000049C3F8: 0826271D
	.long 0xd7600003                                           // 00000049C3FC: D7600003
	v_cndmask_b32_e32 v0, v17, v142, vcc_lo                    // 00000049C400: 02011D11
	.long 0xd7600000                                           // 00000049C404: D7600000
	v_cndmask_b32_e32 v0, v17, v134, vcc_lo                    // 00000049C408: 02010D11
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 00000049C40C: 102626FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049C414: BF870001
	v_mul_f32_e32 v19, s4, v19                                 // 00000049C418: 10262604
	ds_store_b32 v26, v23                                      // 00000049C41C: D8340000 0000171A
	ds_store_b32 v16, v28                                      // 00000049C424: D8340000 00001C10
	ds_store_b32 v18, v19                                      // 00000049C42C: D8340000 00001312
	ds_store_b32 v24, v0                                       // 00000049C434: D8340000 00000018
	ds_load_b32 v16, v27                                       // 00000049C43C: D8D80000 1000001B
	ds_load_b32 v18, v20                                       // 00000049C444: D8D80000 12000014
	ds_load_b32 v19, v21                                       // 00000049C44C: D8D80000 13000015
	ds_load_b32 v23, v25                                       // 00000049C454: D8D80000 17000019
	v_or_b32_e32 v0, 28, v3                                    // 00000049C45C: 3800069C
	v_or_b32_e32 v24, 60, v3                                   // 00000049C460: 383006BC
	v_or_b32_e32 v26, 0x5c, v3                                 // 00000049C464: 383406FF 0000005C
	v_or_b32_e32 v28, 0x7c, v3                                 // 00000049C46C: 383806FF 0000007C
	.long 0xd7600004                                           // 00000049C474: D7600004
	v_cndmask_b32_e32 v0, v17, v150, vcc_lo                    // 00000049C478: 02012D11
	v_xor_b32_e32 v29, v0, v4                                  // 00000049C47C: 3A3A0900
	v_xor_b32_e32 v24, v24, v4                                 // 00000049C480: 3A300918
	s_waitcnt lgkmcnt(2)                                       // 00000049C484: BF89FC27
	v_add_f32_e32 v30, v16, v18                                // 00000049C488: 063C2510
	v_sub_f32_e32 v16, v16, v18                                // 00000049C48C: 08202510
	s_waitcnt lgkmcnt(0)                                       // 00000049C490: BF89FC07
	v_add_f32_e32 v18, v19, v23                                // 00000049C494: 06242F13
	v_sub_f32_e32 v19, v19, v23                                // 00000049C498: 08262F13
	v_xor_b32_e32 v23, v26, v4                                 // 00000049C49C: 3A2E091A
	v_xor_b32_e32 v26, v28, v4                                 // 00000049C4A0: 3A34091C
	v_lshl_or_b32 v28, v29, 2, v14                             // 00000049C4A4: D656001C 0439051D
	v_add_f32_e32 v29, v30, v18                                // 00000049C4AC: 063A251E
	v_add_f32_e32 v31, v16, v19                                // 00000049C4B0: 063E2710
	v_sub_f32_e32 v16, v16, v19                                // 00000049C4B4: 08202710
	v_lshl_or_b32 v19, v24, 2, v14                             // 00000049C4B8: D6560013 04390518
	v_lshl_or_b32 v23, v23, 2, v14                             // 00000049C4C0: D6560017 04390517
	v_mul_f32_e32 v24, 0x3db504f3, v29                         // 00000049C4C8: 10303AFF 3DB504F3
	v_lshl_or_b32 v14, v26, 2, v14                             // 00000049C4D0: D656000E 0439051A
	v_dual_mul_f32 v16, 0x3db504f3, v16 :: v_dual_mul_f32 v29, 0x3db504f3, v31// 00000049C4D8: C8C620FF 101C3EFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000049C4E4: BF8701A3
	v_mul_f32_e32 v24, s0, v24                                 // 00000049C4E8: 10303000
	.long 0xd7600000                                           // 00000049C4EC: D7600000
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                    // 00000049C4F0: 02010111
	v_dual_mul_f32 v16, s5, v16 :: v_dual_mul_f32 v29, s3, v29 // 00000049C4F4: C8C62005 101C3A03
	v_sub_f32_e32 v18, v30, v18                                // 00000049C4FC: 0824251E
	.long 0xd7600003                                           // 00000049C500: D7600003
	v_cndmask_b32_e32 v0, v17, v135, vcc_lo                    // 00000049C504: 02010F11
	.long 0xd7600005                                           // 00000049C508: D7600005
	v_cndmask_b32_e32 v0, v17, v151, vcc_lo                    // 00000049C50C: 02012F11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000049C510: BF870093
	v_dual_mul_f32 v15, s0, v15 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 00000049C514: C8C61E00 0F1224FF 3DB504F3
	v_mul_f32_e32 v18, s4, v18                                 // 00000049C520: 10242404
	ds_store_b32 v27, v24                                      // 00000049C524: D8340000 0000181B
	ds_store_b32 v20, v29                                      // 00000049C52C: D8340000 00001D14
	ds_store_b32 v21, v18                                      // 00000049C534: D8340000 00001215
	ds_store_b32 v25, v16                                      // 00000049C53C: D8340000 00001019
	ds_load_b32 v16, v28                                       // 00000049C544: D8D80000 1000001C
	ds_load_b32 v18, v19                                       // 00000049C54C: D8D80000 12000013
	ds_load_b32 v20, v23                                       // 00000049C554: D8D80000 14000017
	ds_load_b32 v21, v14                                       // 00000049C55C: D8D80000 1500000E
	.long 0xd7600004                                           // 00000049C564: D7600004
	v_cndmask_b32_e32 v0, v17, v143, vcc_lo                    // 00000049C568: 02011F11
	s_waitcnt lgkmcnt(2)                                       // 00000049C56C: BF89FC27
	v_add_f32_e32 v22, v16, v18                                // 00000049C570: 062C2510
	v_sub_f32_e32 v16, v16, v18                                // 00000049C574: 08202510
	s_waitcnt lgkmcnt(0)                                       // 00000049C578: BF89FC07
	v_add_f32_e32 v18, v20, v21                                // 00000049C57C: 06242B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000049C580: BF870091
	v_dual_sub_f32 v20, v20, v21 :: v_dual_add_f32 v21, v22, v18// 00000049C584: C9482B14 14142516
	v_dual_mul_f32 v17, 0x3db504f3, v21 :: v_dual_add_f32 v24, v16, v20// 00000049C58C: C8C82AFF 11182910 3DB504F3
	v_sub_f32_e32 v18, v22, v18                                // 00000049C598: 08242516
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049C59C: BF870192
	v_dual_sub_f32 v16, v16, v20 :: v_dual_mul_f32 v17, s3, v17// 00000049C5A0: C9462910 10102203
	v_mul_f32_e32 v20, 0x3db504f3, v24                         // 00000049C5A8: 102830FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049C5B0: BF870193
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 00000049C5B4: 102424FF 3DB504F3
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 00000049C5BC: 102020FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049C5C4: BF870193
	v_mul_f32_e32 v20, s4, v20                                 // 00000049C5C8: 10282804
	v_mul_f32_e32 v18, s5, v18                                 // 00000049C5CC: 10242405
	s_delay_alu instid0(VALU_DEP_3)                            // 00000049C5D0: BF870003
	v_mul_f32_e32 v16, s6, v16                                 // 00000049C5D4: 10202006
	ds_store_b32 v13, v15                                      // 00000049C5D8: D8340000 00000F0D
	ds_store_b32 v28, v17                                      // 00000049C5E0: D8340000 0000111C
	ds_store_b32 v19, v20                                      // 00000049C5E8: D8340000 00001413
	ds_store_b32 v23, v18                                      // 00000049C5F0: D8340000 00001217
	ds_store_b32 v14, v16                                      // 00000049C5F8: D8340000 0000100E
	s_waitcnt lgkmcnt(0)                                       // 00000049C600: BF89FC07
	s_barrier                                                  // 00000049C604: BFBD0000
	buffer_gl0_inv                                             // 00000049C608: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 00000049C610: BE80206A
	s_cbranch_execz 406                                        // 00000049C614: BFA50196 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi3ELb1ELi16EEEvPKjiPKDF16_S5_Pti+0x2370>
	v_lshlrev_b32_e32 v11, 14, v11                             // 00000049C618: 3016168E
	v_and_or_b32 v4, 0x60, v12, v4                             // 00000049C61C: D6570004 041218FF 00000060
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000049C628: BF870112
	v_and_b32_e32 v11, 0xc000, v11                             // 00000049C62C: 361616FF 0000C000
	v_xor_b32_e32 v12, 1, v4                                   // 00000049C634: 3A180881
	v_xor_b32_e32 v13, 2, v4                                   // 00000049C638: 3A1A0882
	v_xor_b32_e32 v14, 3, v4                                   // 00000049C63C: 3A1C0883
	v_xor_b32_e32 v15, 4, v4                                   // 00000049C640: 3A1E0884
	v_xor_b32_e32 v16, 5, v4                                   // 00000049C644: 3A200885
	v_lshl_or_b32 v17, v4, 2, v11                              // 00000049C648: D6560011 042D0504
	v_xor_b32_e32 v18, 6, v4                                   // 00000049C650: 3A240886
	v_xor_b32_e32 v19, 7, v4                                   // 00000049C654: 3A260887
	v_lshl_or_b32 v12, v12, 2, v11                             // 00000049C658: D656000C 042D050C
	v_lshl_or_b32 v13, v13, 2, v11                             // 00000049C660: D656000D 042D050D
	v_lshl_or_b32 v14, v14, 2, v11                             // 00000049C668: D656000E 042D050E
	v_lshl_or_b32 v15, v15, 2, v11                             // 00000049C670: D656000F 042D050F
	v_lshl_or_b32 v16, v16, 2, v11                             // 00000049C678: D6560010 042D0510
	v_lshl_or_b32 v18, v18, 2, v11                             // 00000049C680: D6560012 042D0512
	v_lshl_or_b32 v19, v19, 2, v11                             // 00000049C688: D6560013 042D0513
	ds_load_b32 v23, v17                                       // 00000049C690: D8D80000 17000011
	ds_load_b32 v24, v12 offset:512                            // 00000049C698: D8D80200 1800000C
	ds_load_b32 v25, v13 offset:1024                           // 00000049C6A0: D8D80400 1900000D
	ds_load_b32 v26, v14 offset:1536                           // 00000049C6A8: D8D80600 1A00000E
	ds_load_b32 v27, v15 offset:2048                           // 00000049C6B0: D8D80800 1B00000F
	ds_load_b32 v28, v16 offset:2560                           // 00000049C6B8: D8D80A00 1C000010
	ds_load_b32 v29, v18 offset:3072                           // 00000049C6C0: D8D80C00 1D000012
	ds_load_b32 v30, v19 offset:3584                           // 00000049C6C8: D8D80E00 1E000013
	v_xor_b32_e32 v20, 8, v4                                   // 00000049C6D0: 3A280888
	v_xor_b32_e32 v36, 16, v4                                  // 00000049C6D4: 3A480890
	v_xor_b32_e32 v52, 24, v4                                  // 00000049C6D8: 3A680898
	v_xor_b32_e32 v21, 9, v4                                   // 00000049C6DC: 3A2A0889
	v_xor_b32_e32 v37, 17, v4                                  // 00000049C6E0: 3A4A0891
	v_xor_b32_e32 v53, 25, v4                                  // 00000049C6E4: 3A6A0899
	v_xor_b32_e32 v22, 10, v4                                  // 00000049C6E8: 3A2C088A
	v_xor_b32_e32 v38, 18, v4                                  // 00000049C6EC: 3A4C0892
	v_xor_b32_e32 v54, 26, v4                                  // 00000049C6F0: 3A6C089A
	v_xor_b32_e32 v31, 11, v4                                  // 00000049C6F4: 3A3E088B
	v_xor_b32_e32 v47, 19, v4                                  // 00000049C6F8: 3A5E0893
	v_xor_b32_e32 v63, 27, v4                                  // 00000049C6FC: 3A7E089B
	v_xor_b32_e32 v32, 12, v4                                  // 00000049C700: 3A40088C
	v_xor_b32_e32 v48, 20, v4                                  // 00000049C704: 3A600894
	v_xor_b32_e32 v64, 28, v4                                  // 00000049C708: 3A80089C
	v_xor_b32_e32 v33, 13, v4                                  // 00000049C70C: 3A42088D
	v_xor_b32_e32 v34, 14, v4                                  // 00000049C710: 3A44088E
	v_xor_b32_e32 v35, 15, v4                                  // 00000049C714: 3A46088F
	v_xor_b32_e32 v49, 21, v4                                  // 00000049C718: 3A620895
	v_xor_b32_e32 v50, 22, v4                                  // 00000049C71C: 3A640896
	v_xor_b32_e32 v51, 23, v4                                  // 00000049C720: 3A660897
	v_xor_b32_e32 v65, 29, v4                                  // 00000049C724: 3A82089D
	v_xor_b32_e32 v66, 30, v4                                  // 00000049C728: 3A84089E
	v_xor_b32_e32 v4, 31, v4                                   // 00000049C72C: 3A08089F
	s_waitcnt lgkmcnt(6)                                       // 00000049C730: BF89FC67
	v_add_f32_e32 v74, v23, v24                                // 00000049C734: 06943117
	s_waitcnt lgkmcnt(4)                                       // 00000049C738: BF89FC47
	v_dual_sub_f32 v23, v23, v24 :: v_dual_add_f32 v24, v25, v26// 00000049C73C: C9483117 17183519
	v_lshl_or_b32 v20, v20, 2, v11                             // 00000049C744: D6560014 042D0514
	v_lshl_or_b32 v36, v36, 2, v11                             // 00000049C74C: D6560024 042D0524
	v_lshl_or_b32 v52, v52, 2, v11                             // 00000049C754: D6560034 042D0534
	v_lshl_or_b32 v21, v21, 2, v11                             // 00000049C75C: D6560015 042D0515
	v_lshl_or_b32 v37, v37, 2, v11                             // 00000049C764: D6560025 042D0525
	v_lshl_or_b32 v53, v53, 2, v11                             // 00000049C76C: D6560035 042D0535
	v_lshl_or_b32 v22, v22, 2, v11                             // 00000049C774: D6560016 042D0516
	v_lshl_or_b32 v38, v38, 2, v11                             // 00000049C77C: D6560026 042D0526
	v_lshl_or_b32 v54, v54, 2, v11                             // 00000049C784: D6560036 042D0536
	v_lshl_or_b32 v31, v31, 2, v11                             // 00000049C78C: D656001F 042D051F
	v_lshl_or_b32 v47, v47, 2, v11                             // 00000049C794: D656002F 042D052F
	v_lshl_or_b32 v63, v63, 2, v11                             // 00000049C79C: D656003F 042D053F
	v_lshl_or_b32 v32, v32, 2, v11                             // 00000049C7A4: D6560020 042D0520
	v_lshl_or_b32 v48, v48, 2, v11                             // 00000049C7AC: D6560030 042D0530
	v_lshl_or_b32 v64, v64, 2, v11                             // 00000049C7B4: D6560040 042D0540
	v_lshl_or_b32 v33, v33, 2, v11                             // 00000049C7BC: D6560021 042D0521
	v_lshl_or_b32 v34, v34, 2, v11                             // 00000049C7C4: D6560022 042D0522
	v_lshl_or_b32 v35, v35, 2, v11                             // 00000049C7CC: D6560023 042D0523
	ds_load_b32 v39, v20 offset:4096                           // 00000049C7D4: D8D81000 27000014
	ds_load_b32 v40, v21 offset:4608                           // 00000049C7DC: D8D81200 28000015
	ds_load_b32 v41, v22 offset:5120                           // 00000049C7E4: D8D81400 29000016
	ds_load_b32 v42, v31 offset:5632                           // 00000049C7EC: D8D81600 2A00001F
	ds_load_b32 v43, v32 offset:6144                           // 00000049C7F4: D8D81800 2B000020
	ds_load_b32 v44, v33 offset:6656                           // 00000049C7FC: D8D81A00 2C000021
	ds_load_b32 v45, v34 offset:7168                           // 00000049C804: D8D81C00 2D000022
	ds_load_b32 v46, v35 offset:7680                           // 00000049C80C: D8D81E00 2E000023
	v_lshl_or_b32 v49, v49, 2, v11                             // 00000049C814: D6560031 042D0531
	v_lshl_or_b32 v50, v50, 2, v11                             // 00000049C81C: D6560032 042D0532
	v_lshl_or_b32 v51, v51, 2, v11                             // 00000049C824: D6560033 042D0533
	ds_load_b32 v55, v36 offset:8192                           // 00000049C82C: D8D82000 37000024
	ds_load_b32 v56, v37 offset:8704                           // 00000049C834: D8D82200 38000025
	ds_load_b32 v57, v38 offset:9216                           // 00000049C83C: D8D82400 39000026
	ds_load_b32 v58, v47 offset:9728                           // 00000049C844: D8D82600 3A00002F
	ds_load_b32 v59, v48 offset:10240                          // 00000049C84C: D8D82800 3B000030
	ds_load_b32 v60, v49 offset:10752                          // 00000049C854: D8D82A00 3C000031
	ds_load_b32 v61, v50 offset:11264                          // 00000049C85C: D8D82C00 3D000032
	ds_load_b32 v62, v51 offset:11776                          // 00000049C864: D8D82E00 3E000033
	v_lshl_or_b32 v65, v65, 2, v11                             // 00000049C86C: D6560041 042D0541
	v_lshl_or_b32 v66, v66, 2, v11                             // 00000049C874: D6560042 042D0542
	v_lshl_or_b32 v4, v4, 2, v11                               // 00000049C87C: D6560004 042D0504
	ds_load_b32 v11, v52 offset:12288                          // 00000049C884: D8D83000 0B000034
	ds_load_b32 v67, v53 offset:12800                          // 00000049C88C: D8D83200 43000035
	ds_load_b32 v68, v54 offset:13312                          // 00000049C894: D8D83400 44000036
	ds_load_b32 v69, v63 offset:13824                          // 00000049C89C: D8D83600 4500003F
	ds_load_b32 v70, v64 offset:14336                          // 00000049C8A4: D8D83800 46000040
	ds_load_b32 v71, v65 offset:14848                          // 00000049C8AC: D8D83A00 47000041
	ds_load_b32 v72, v66 offset:15360                          // 00000049C8B4: D8D83C00 48000042
	ds_load_b32 v73, v4 offset:15872                           // 00000049C8BC: D8D83E00 49000004
	s_waitcnt lgkmcnt(26)                                      // 00000049C8C4: BF89FDA7
	v_dual_sub_f32 v25, v25, v26 :: v_dual_add_f32 v26, v27, v28// 00000049C8C8: C9483519 191A391B
	s_waitcnt lgkmcnt(24)                                      // 00000049C8D0: BF89FD87
	v_dual_sub_f32 v27, v27, v28 :: v_dual_add_f32 v28, v29, v30// 00000049C8D4: C948391B 1B1C3D1D
	s_waitcnt lgkmcnt(22)                                      // 00000049C8DC: BF89FD67
	v_dual_sub_f32 v29, v29, v30 :: v_dual_add_f32 v30, v39, v40// 00000049C8E0: C9483D1D 1D1E5127
	s_waitcnt lgkmcnt(20)                                      // 00000049C8E8: BF89FD47
	v_dual_sub_f32 v39, v39, v40 :: v_dual_add_f32 v40, v41, v42// 00000049C8EC: C9485127 27285529
	s_waitcnt lgkmcnt(18)                                      // 00000049C8F4: BF89FD27
	v_dual_sub_f32 v41, v41, v42 :: v_dual_add_f32 v42, v43, v44// 00000049C8F8: C9485529 292A592B
	s_waitcnt lgkmcnt(16)                                      // 00000049C900: BF89FD07
	v_dual_sub_f32 v43, v43, v44 :: v_dual_add_f32 v44, v45, v46// 00000049C904: C948592B 2B2C5D2D
	s_waitcnt lgkmcnt(14)                                      // 00000049C90C: BF89FCE7
	v_dual_sub_f32 v45, v45, v46 :: v_dual_add_f32 v46, v55, v56// 00000049C910: C9485D2D 2D2E7137
	s_waitcnt lgkmcnt(12)                                      // 00000049C918: BF89FCC7
	v_dual_sub_f32 v55, v55, v56 :: v_dual_add_f32 v56, v57, v58// 00000049C91C: C9487137 37387539
	s_waitcnt lgkmcnt(10)                                      // 00000049C924: BF89FCA7
	v_dual_sub_f32 v57, v57, v58 :: v_dual_add_f32 v58, v59, v60// 00000049C928: C9487539 393A793B
	s_waitcnt lgkmcnt(8)                                       // 00000049C930: BF89FC87
	v_dual_sub_f32 v59, v59, v60 :: v_dual_add_f32 v60, v61, v62// 00000049C934: C948793B 3B3C7D3D
	s_waitcnt lgkmcnt(6)                                       // 00000049C93C: BF89FC67
	v_dual_sub_f32 v61, v61, v62 :: v_dual_add_f32 v62, v11, v67// 00000049C940: C9487D3D 3D3E870B
	v_sub_f32_e32 v11, v11, v67                                // 00000049C948: 0816870B
	s_waitcnt lgkmcnt(4)                                       // 00000049C94C: BF89FC47
	v_add_f32_e32 v67, v68, v69                                // 00000049C950: 06868B44
	s_waitcnt lgkmcnt(2)                                       // 00000049C954: BF89FC27
	v_dual_sub_f32 v68, v68, v69 :: v_dual_add_f32 v69, v70, v71// 00000049C958: C9488B44 44448F46
	s_waitcnt lgkmcnt(0)                                       // 00000049C960: BF89FC07
	v_dual_sub_f32 v70, v70, v71 :: v_dual_add_f32 v71, v72, v73// 00000049C964: C9488F46 46469348
	v_dual_sub_f32 v72, v72, v73 :: v_dual_add_f32 v73, v74, v24// 00000049C96C: C9489348 4848314A
	v_sub_f32_e32 v24, v74, v24                                // 00000049C974: 0830314A
	v_add_f32_e32 v74, v23, v25                                // 00000049C978: 06943317
	v_sub_f32_e32 v23, v23, v25                                // 00000049C97C: 082E3317
	v_add_f32_e32 v25, v26, v28                                // 00000049C980: 0632391A
	v_sub_f32_e32 v26, v26, v28                                // 00000049C984: 0834391A
	v_add_f32_e32 v28, v27, v29                                // 00000049C988: 06383B1B
	v_sub_f32_e32 v27, v27, v29                                // 00000049C98C: 08363B1B
	v_add_f32_e32 v29, v30, v40                                // 00000049C990: 063A511E
	v_sub_f32_e32 v30, v30, v40                                // 00000049C994: 083C511E
	v_add_f32_e32 v40, v39, v41                                // 00000049C998: 06505327
	v_sub_f32_e32 v39, v39, v41                                // 00000049C99C: 084E5327
	v_add_f32_e32 v41, v42, v44                                // 00000049C9A0: 0652592A
	v_sub_f32_e32 v42, v42, v44                                // 00000049C9A4: 0854592A
	v_add_f32_e32 v44, v43, v45                                // 00000049C9A8: 06585B2B
	v_sub_f32_e32 v43, v43, v45                                // 00000049C9AC: 08565B2B
	v_add_f32_e32 v45, v46, v56                                // 00000049C9B0: 065A712E
	v_sub_f32_e32 v46, v46, v56                                // 00000049C9B4: 085C712E
	v_add_f32_e32 v56, v55, v57                                // 00000049C9B8: 06707337
	v_sub_f32_e32 v55, v55, v57                                // 00000049C9BC: 086E7337
	v_add_f32_e32 v57, v58, v60                                // 00000049C9C0: 0672793A
	v_sub_f32_e32 v58, v58, v60                                // 00000049C9C4: 0874793A
	v_add_f32_e32 v60, v59, v61                                // 00000049C9C8: 06787B3B
	v_sub_f32_e32 v59, v59, v61                                // 00000049C9CC: 08767B3B
	v_add_f32_e32 v61, v62, v67                                // 00000049C9D0: 067A873E
	v_dual_sub_f32 v62, v62, v67 :: v_dual_add_f32 v67, v11, v68// 00000049C9D4: C948873E 3E42890B
	v_dual_sub_f32 v11, v11, v68 :: v_dual_add_f32 v68, v69, v71// 00000049C9DC: C948890B 0B448F45
	v_sub_f32_e32 v69, v69, v71                                // 00000049C9E4: 088A8F45
	v_add_f32_e32 v71, v70, v72                                // 00000049C9E8: 068E9146
	v_sub_f32_e32 v70, v70, v72                                // 00000049C9EC: 088C9146
	v_add_f32_e32 v72, v73, v25                                // 00000049C9F0: 06903349
	v_sub_f32_e32 v25, v73, v25                                // 00000049C9F4: 08323349
	v_add_f32_e32 v73, v74, v28                                // 00000049C9F8: 0692394A
	v_sub_f32_e32 v28, v74, v28                                // 00000049C9FC: 0838394A
	v_add_f32_e32 v74, v24, v26                                // 00000049CA00: 06943518
	v_sub_f32_e32 v24, v24, v26                                // 00000049CA04: 08303518
	v_add_f32_e32 v26, v23, v27                                // 00000049CA08: 06343717
	v_sub_f32_e32 v23, v23, v27                                // 00000049CA0C: 082E3717
	v_add_f32_e32 v27, v29, v41                                // 00000049CA10: 0636531D
	v_sub_f32_e32 v29, v29, v41                                // 00000049CA14: 083A531D
	v_add_f32_e32 v41, v40, v44                                // 00000049CA18: 06525928
	v_sub_f32_e32 v40, v40, v44                                // 00000049CA1C: 08505928
	v_add_f32_e32 v44, v30, v42                                // 00000049CA20: 0658551E
	v_sub_f32_e32 v30, v30, v42                                // 00000049CA24: 083C551E
	v_add_f32_e32 v42, v39, v43                                // 00000049CA28: 06545727
	v_sub_f32_e32 v39, v39, v43                                // 00000049CA2C: 084E5727
	v_add_f32_e32 v43, v45, v57                                // 00000049CA30: 0656732D
	v_sub_f32_e32 v45, v45, v57                                // 00000049CA34: 085A732D
	v_add_f32_e32 v57, v56, v60                                // 00000049CA38: 06727938
	v_sub_f32_e32 v56, v56, v60                                // 00000049CA3C: 08707938
	v_add_f32_e32 v60, v46, v58                                // 00000049CA40: 0678752E
	v_sub_f32_e32 v46, v46, v58                                // 00000049CA44: 085C752E
	v_add_f32_e32 v58, v55, v59                                // 00000049CA48: 06747737
	v_sub_f32_e32 v55, v55, v59                                // 00000049CA4C: 086E7737
	v_add_f32_e32 v59, v61, v68                                // 00000049CA50: 0676893D
	v_dual_sub_f32 v61, v61, v68 :: v_dual_add_f32 v68, v67, v71// 00000049CA54: C948893D 3D448F43
	v_sub_f32_e32 v67, v67, v71                                // 00000049CA5C: 08868F43
	v_add_f32_e32 v71, v62, v69                                // 00000049CA60: 068E8B3E
	v_dual_sub_f32 v62, v62, v69 :: v_dual_add_f32 v69, v11, v70// 00000049CA64: C9488B3E 3E448D0B
	v_dual_sub_f32 v11, v11, v70 :: v_dual_add_f32 v70, v72, v27// 00000049CA6C: C9488D0B 0B463748
	v_dual_sub_f32 v27, v72, v27 :: v_dual_add_f32 v72, v73, v41// 00000049CA74: C9483748 1B485349
	v_sub_f32_e32 v41, v73, v41                                // 00000049CA7C: 08525349
	v_add_f32_e32 v73, v74, v44                                // 00000049CA80: 0692594A
	v_sub_f32_e32 v44, v74, v44                                // 00000049CA84: 0858594A
	v_add_f32_e32 v74, v26, v42                                // 00000049CA88: 0694551A
	v_sub_f32_e32 v26, v26, v42                                // 00000049CA8C: 0834551A
	v_add_f32_e32 v42, v25, v29                                // 00000049CA90: 06543B19
	v_sub_f32_e32 v25, v25, v29                                // 00000049CA94: 08323B19
	v_add_f32_e32 v29, v28, v40                                // 00000049CA98: 063A511C
	v_sub_f32_e32 v28, v28, v40                                // 00000049CA9C: 0838511C
	v_add_f32_e32 v40, v24, v30                                // 00000049CAA0: 06503D18
	v_sub_f32_e32 v24, v24, v30                                // 00000049CAA4: 08303D18
	v_add_f32_e32 v30, v23, v39                                // 00000049CAA8: 063C4F17
	v_sub_f32_e32 v23, v23, v39                                // 00000049CAAC: 082E4F17
	v_add_f32_e32 v39, v43, v59                                // 00000049CAB0: 064E772B
	v_sub_f32_e32 v43, v43, v59                                // 00000049CAB4: 0856772B
	v_add_f32_e32 v59, v57, v68                                // 00000049CAB8: 06768939
	v_dual_sub_f32 v57, v57, v68 :: v_dual_add_f32 v68, v60, v71// 00000049CABC: C9488939 39448F3C
	v_dual_sub_f32 v60, v60, v71 :: v_dual_add_f32 v71, v58, v69// 00000049CAC4: C9488F3C 3C468B3A
	v_sub_f32_e32 v58, v58, v69                                // 00000049CACC: 08748B3A
	v_add_f32_e32 v69, v45, v61                                // 00000049CAD0: 068A7B2D
	v_sub_f32_e32 v45, v45, v61                                // 00000049CAD4: 085A7B2D
	v_add_f32_e32 v61, v56, v67                                // 00000049CAD8: 067A8738
	v_dual_sub_f32 v56, v56, v67 :: v_dual_add_f32 v67, v46, v62// 00000049CADC: C9488738 38427D2E
	v_sub_f32_e32 v46, v46, v62                                // 00000049CAE4: 085C7D2E
	v_add_f32_e32 v62, v55, v11                                // 00000049CAE8: 067C1737
	v_sub_f32_e32 v11, v55, v11                                // 00000049CAEC: 08161737
	v_add_f32_e32 v55, v70, v39                                // 00000049CAF0: 066E4F46
	v_sub_f32_e32 v39, v70, v39                                // 00000049CAF4: 084E4F46
	v_add_f32_e32 v70, v72, v59                                // 00000049CAF8: 068C7748
	v_dual_sub_f32 v59, v72, v59 :: v_dual_add_f32 v72, v73, v68// 00000049CAFC: C9487748 3B488949
	v_dual_sub_f32 v68, v73, v68 :: v_dual_add_f32 v73, v74, v71// 00000049CB04: C9488949 44488F4A
	v_sub_f32_e32 v71, v74, v71                                // 00000049CB0C: 088E8F4A
	v_add_f32_e32 v74, v42, v69                                // 00000049CB10: 06948B2A
	v_sub_f32_e32 v42, v42, v69                                // 00000049CB14: 08548B2A
	v_add_f32_e32 v69, v29, v61                                // 00000049CB18: 068A7B1D
	v_sub_f32_e32 v29, v29, v61                                // 00000049CB1C: 083A7B1D
	v_add_f32_e32 v61, v40, v67                                // 00000049CB20: 067A8728
	v_dual_sub_f32 v40, v40, v67 :: v_dual_add_f32 v67, v30, v62// 00000049CB24: C9488728 28427D1E
	v_sub_f32_e32 v30, v30, v62                                // 00000049CB2C: 083C7D1E
	v_add_f32_e32 v62, v27, v43                                // 00000049CB30: 067C571B
	v_sub_f32_e32 v27, v27, v43                                // 00000049CB34: 0836571B
	v_add_f32_e32 v43, v41, v57                                // 00000049CB38: 06567329
	v_sub_f32_e32 v41, v41, v57                                // 00000049CB3C: 08527329
	v_add_f32_e32 v57, v44, v60                                // 00000049CB40: 0672792C
	v_sub_f32_e32 v44, v44, v60                                // 00000049CB44: 0858792C
	v_add_f32_e32 v60, v26, v58                                // 00000049CB48: 0678751A
	v_sub_f32_e32 v26, v26, v58                                // 00000049CB4C: 0834751A
	v_add_f32_e32 v58, v25, v45                                // 00000049CB50: 06745B19
	v_sub_f32_e32 v25, v25, v45                                // 00000049CB54: 08325B19
	v_add_f32_e32 v45, v28, v56                                // 00000049CB58: 065A711C
	v_sub_f32_e32 v28, v28, v56                                // 00000049CB5C: 0838711C
	v_add_f32_e32 v56, v24, v46                                // 00000049CB60: 06705D18
	v_sub_f32_e32 v24, v24, v46                                // 00000049CB64: 08305D18
	v_add_f32_e32 v46, v23, v11                                // 00000049CB68: 065C1717
	v_sub_f32_e32 v11, v23, v11                                // 00000049CB6C: 08161717
	ds_store_b32 v17, v55                                      // 00000049CB70: D8340000 00003711
	ds_store_b32 v12, v70 offset:512                           // 00000049CB78: D8340200 0000460C
	ds_store_b32 v13, v72 offset:1024                          // 00000049CB80: D8340400 0000480D
	ds_store_b32 v14, v73 offset:1536                          // 00000049CB88: D8340600 0000490E
	ds_store_b32 v15, v74 offset:2048                          // 00000049CB90: D8340800 00004A0F
	ds_store_b32 v16, v69 offset:2560                          // 00000049CB98: D8340A00 00004510
	ds_store_b32 v18, v61 offset:3072                          // 00000049CBA0: D8340C00 00003D12
	ds_store_b32 v19, v67 offset:3584                          // 00000049CBA8: D8340E00 00004313
	ds_store_b32 v20, v62 offset:4096                          // 00000049CBB0: D8341000 00003E14
	ds_store_b32 v21, v43 offset:4608                          // 00000049CBB8: D8341200 00002B15
	ds_store_b32 v22, v57 offset:5120                          // 00000049CBC0: D8341400 00003916
	ds_store_b32 v31, v60 offset:5632                          // 00000049CBC8: D8341600 00003C1F
	ds_store_b32 v32, v58 offset:6144                          // 00000049CBD0: D8341800 00003A20
	ds_store_b32 v33, v45 offset:6656                          // 00000049CBD8: D8341A00 00002D21
	ds_store_b32 v34, v56 offset:7168                          // 00000049CBE0: D8341C00 00003822
	ds_store_b32 v35, v46 offset:7680                          // 00000049CBE8: D8341E00 00002E23
	ds_store_b32 v36, v39 offset:8192                          // 00000049CBF0: D8342000 00002724
	ds_store_b32 v37, v59 offset:8704                          // 00000049CBF8: D8342200 00003B25
	ds_store_b32 v38, v68 offset:9216                          // 00000049CC00: D8342400 00004426
	ds_store_b32 v47, v71 offset:9728                          // 00000049CC08: D8342600 0000472F
	ds_store_b32 v48, v42 offset:10240                         // 00000049CC10: D8342800 00002A30
	ds_store_b32 v49, v29 offset:10752                         // 00000049CC18: D8342A00 00001D31
	ds_store_b32 v50, v40 offset:11264                         // 00000049CC20: D8342C00 00002832
	ds_store_b32 v51, v30 offset:11776                         // 00000049CC28: D8342E00 00001E33
	ds_store_b32 v52, v27 offset:12288                         // 00000049CC30: D8343000 00001B34
	ds_store_b32 v53, v41 offset:12800                         // 00000049CC38: D8343200 00002935
	ds_store_b32 v54, v44 offset:13312                         // 00000049CC40: D8343400 00002C36
	ds_store_b32 v63, v26 offset:13824                         // 00000049CC48: D8343600 00001A3F
	ds_store_b32 v64, v25 offset:14336                         // 00000049CC50: D8343800 00001940
	ds_store_b32 v65, v28 offset:14848                         // 00000049CC58: D8343A00 00001C41
	ds_store_b32 v66, v24 offset:15360                         // 00000049CC60: D8343C00 00001842
	ds_store_b32 v4, v11 offset:15872                          // 00000049CC68: D8343E00 00000B04
	s_or_b32 exec_lo, exec_lo, s0                              // 00000049CC70: 8C7E007E
	v_xor_b32_e32 v4, v3, v2                                   // 00000049CC74: 3A080503
	v_lshlrev_b32_e32 v11, 9, v3                               // 00000049CC78: 30160689
	s_waitcnt lgkmcnt(0)                                       // 00000049CC7C: BF89FC07
	s_barrier                                                  // 00000049CC80: BFBD0000
	buffer_gl0_inv                                             // 00000049CC84: E0AC0000 00000000
	v_or_b32_e32 v23, s1, v3                                   // 00000049CC8C: 382E0601
	v_lshl_add_u32 v4, v4, 2, v11                              // 00000049CC90: D6460004 042D0504
	s_ashr_i32 s3, s2, 31                                      // 00000049CC98: 86039F02
	v_cvt_f32_f16_e32 v1, v1                                   // 00000049CC9C: 7E021701
	s_lshl_b64 s[2:3], s[2:3], 1                               // 00000049CCA0: 84828102
	ds_load_2addr_stride64_b32 v[13:14], v4 offset1:64         // 00000049CCA4: D8E04000 0D000004
	ds_load_2addr_stride64_b32 v[15:16], v4 offset0:128 offset1:192// 00000049CCAC: D8E0C080 0F000004
	v_mov_b32_e32 v3, 0                                        // 00000049CCB4: 7E060280
	v_mad_i64_i32 v[11:12], null, v23, s12, 0                  // 00000049CCB8: D6FF7C0B 02001917
	v_or_b32_e32 v17, 32, v23                                  // 00000049CCC0: 38222EA0
	v_or_b32_e32 v19, 64, v23                                  // 00000049CCC4: 38262EC0
	s_add_u32 s0, s8, s2                                       // 00000049CCC8: 80000208
	.long 0xd73c0003                                           // 00000049CCCC: D73C0003
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 00000049CCD0: 02020481
	s_addc_u32 s2, s9, s3                                      // 00000049CCD4: 82020309
	v_mad_i64_i32 v[17:18], null, v17, s12, 0                  // 00000049CCD8: D6FF7C11 02001911
	v_mad_i64_i32 v[19:20], null, v19, s12, 0                  // 00000049CCE0: D6FF7C13 02001913
	.long 0xd73c000b                                           // 00000049CCE8: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000049CCEC: 02021681
	.long 0xd7600004                                           // 00000049CCF0: D7600004
	v_cndmask_b32_e32 v0, v1, v152, vcc_lo                     // 00000049CCF4: 02013101
	.long 0xd7006a03                                           // 00000049CCF8: D7006A03
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 00000049CCFC: 02020600
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000049CD00: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s2, v4, vcc_lo               // 00000049CD04: D5207C04 01AA0802
	.long 0xd7600002                                           // 00000049CD0C: D7600002
	v_cndmask_b32_e32 v0, v1, v136, vcc_lo                     // 00000049CD10: 02011101
	.long 0xd7006a15                                           // 00000049CD14: D7006A15
	v_cndmask_b32_e32 v1, v3, v11, vcc_lo                      // 00000049CD18: 02021703
	s_waitcnt lgkmcnt(0)                                       // 00000049CD1C: BF89FC07
	v_dual_sub_f32 v24, v13, v14 :: v_dual_sub_f32 v25, v15, v16// 00000049CD20: C94A1D0D 1818210F
	v_add_co_ci_u32_e64 v22, null, v4, v12, vcc_lo             // 00000049CD28: D5207C16 01AA1904
	.long 0xd73c000b                                           // 00000049CD30: D73C000B
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 00000049CD34: 02022281
	.long 0xd73c0011                                           // 00000049CD38: D73C0011
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 00000049CD3C: 02022681
	v_dual_add_f32 v19, v13, v14 :: v_dual_add_f32 v20, v15, v16// 00000049CD40: C9081D0D 1314210F
	v_add_f32_e32 v15, v24, v25                                // 00000049CD48: 061E3318
	.long 0xd7600000                                           // 00000049CD4C: D7600000
	v_cndmask_b32_e32 v0, v1, v128, vcc_lo                     // 00000049CD50: 02010101
	.long 0xd7006a0d                                           // 00000049CD54: D7006A0D
	v_cndmask_b32_e32 v1, v3, v11, vcc_lo                      // 00000049CD58: 02021703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049CD5C: BF870211
	v_add_co_ci_u32_e64 v14, null, v4, v12, vcc_lo             // 00000049CD60: D5207C0E 01AA1904
	v_mul_f32_e32 v12, 0x3db504f3, v15                         // 00000049CD68: 10181EFF 3DB504F3
	.long 0xd7006a0f                                           // 00000049CD70: D7006A0F
	v_cndmask_b32_e32 v1, v3, v17, vcc_lo                      // 00000049CD74: 02022303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049CD78: BF870191
	v_add_co_ci_u32_e64 v16, null, v4, v18, vcc_lo             // 00000049CD7C: D5207C10 01AA2504
	v_dual_mul_f32 v12, s2, v12 :: v_dual_sub_f32 v17, v24, v25// 00000049CD84: C8CA1802 0C103318
	v_sub_f32_e32 v18, v19, v20                                // 00000049CD8C: 08242913
	v_add_f32_e32 v11, v19, v20                                // 00000049CD90: 06162913
	.long 0xd7600003                                           // 00000049CD94: D7600003
	v_cndmask_b32_e32 v0, v1, v144, vcc_lo                     // 00000049CD98: 02012101
	.long 0xd7600002                                           // 00000049CD9C: D7600002
	v_cndmask_b32_e32 v0, v1, v137, vcc_lo                     // 00000049CDA0: 02011301
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049CDA4: BF870214
	v_dual_mul_f32 v17, 0x3db504f3, v17 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 00000049CDA8: C8C622FF 111224FF 3DB504F3
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_lshlrev_b32 v24, 9, v10// 00000049CDB4: C8E216FF 0B181489 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000049CDC0: BF8701A2
	v_mul_f32_e32 v26, s4, v17                                 // 00000049CDC4: 10342204
	v_or_b32_e32 v17, 0x60, v23                                // 00000049CDC8: 38222EFF 00000060
	v_mul_f32_e32 v25, s0, v11                                 // 00000049CDD0: 10321600
	.long 0x7f163880                                           // 00000049CDD4: 7F163880
	.long 0x7e16398c                                           // 00000049CDD8: 7E16398C
	v_xor_b32_e32 v23, v10, v2                                 // 00000049CDDC: 3A2E050A
	.long 0xd7600000                                           // 00000049CDE0: D7600000
	v_cndmask_b32_e32 v0, v1, v129, vcc_lo                     // 00000049CDE4: 02010301
	.long 0x7e263999                                           // 00000049CDE8: 7E263999
	.long 0x7f26398b                                           // 00000049CDEC: 7F26398B
	v_and_b32_e32 v20, 1, v11                                  // 00000049CDF0: 36281681
	v_lshl_add_u32 v23, v23, 2, v24                            // 00000049CDF4: D6460017 04610517
	.long 0x7f38398b                                           // 00000049CDFC: 7F38398B
	v_mul_f32_e32 v27, s3, v18                                 // 00000049CE00: 10362403
	v_mad_i64_i32 v[17:18], null, v17, s12, 0                  // 00000049CE04: D6FF7C11 02001911
	v_and_b32_e32 v29, 1, v19                                  // 00000049CE0C: 363A2681
	v_add3_u32 v12, v12, v20, 0x7fff                           // 00000049CE10: D655000C 03FE290C 00007FFF
	ds_load_2addr_stride64_b32 v[19:20], v23 offset1:64        // 00000049CE1C: D8E04000 13000017
	ds_load_2addr_stride64_b32 v[23:24], v23 offset0:128 offset1:192// 00000049CE24: D8E0C080 17000017
	.long 0x7e38399b                                           // 00000049CE2C: 7E38399B
	.long 0x7e16399a                                           // 00000049CE30: 7E16399A
	v_add3_u32 v29, v25, v29, 0x7fff                           // 00000049CE34: D655001D 03FE3B19 00007FFF
	s_clause 0x1                                               // 00000049CE40: BF850001
	global_store_d16_hi_b16 v[21:22], v29, off                 // 00000049CE44: DC960000 007C1D15
	global_store_d16_hi_b16 v[13:14], v12, off                 // 00000049CE4C: DC960000 007C0C0D
	.long 0xd73c0011                                           // 00000049CE54: D73C0011
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 00000049CE58: 02022281
	v_and_b32_e32 v28, 1, v28                                  // 00000049CE5C: 36383881
	v_and_b32_e32 v30, 1, v11                                  // 00000049CE60: 363C1681
	v_or_b32_e32 v10, s1, v10                                  // 00000049CE64: 38141401
	.long 0xd7600003                                           // 00000049CE68: D7600003
	v_cndmask_b32_e32 v0, v1, v145, vcc_lo                     // 00000049CE6C: 02012301
	v_or_b32_e32 v29, s1, v8                                   // 00000049CE70: 383A1001
	.long 0xd7006a11                                           // 00000049CE74: D7006A11
	v_cndmask_b32_e32 v1, v3, v17, vcc_lo                      // 00000049CE78: 02022303
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000049CE7C: D655001B 03FE391B 00007FFF
	v_add3_u32 v30, v26, v30, 0x7fff                           // 00000049CE88: D655001E 03FE3D1A 00007FFF
	v_add_co_ci_u32_e64 v18, null, v4, v18, vcc_lo             // 00000049CE94: D5207C12 01AA2504
	s_clause 0x1                                               // 00000049CE9C: BF850001
	global_store_d16_hi_b16 v[15:16], v27, off                 // 00000049CEA0: DC960000 007C1B0F
	global_store_d16_hi_b16 v[17:18], v30, off                 // 00000049CEA8: DC960000 007C1E11
	s_waitcnt lgkmcnt(1)                                       // 00000049CEB0: BF89FC17
	v_sub_f32_e32 v18, v19, v20                                // 00000049CEB4: 08242913
	v_add_f32_e32 v19, v19, v20                                // 00000049CEB8: 06262913
	s_waitcnt lgkmcnt(0)                                       // 00000049CEBC: BF89FC07
	v_add_f32_e32 v21, v23, v24                                // 00000049CEC0: 062A3117
	v_or_b32_e32 v14, 32, v10                                  // 00000049CEC4: 381C14A0
	v_mad_i64_i32 v[25:26], null, v10, s12, 0                  // 00000049CEC8: D6FF7C19 0200190A
	v_or_b32_e32 v22, 64, v10                                  // 00000049CED0: 382C14C0
	v_or_b32_e32 v10, 0x60, v10                                // 00000049CED4: 381414FF 00000060
	v_add_f32_e32 v17, v19, v21                                // 00000049CEDC: 06222B13
	v_sub_f32_e32 v20, v23, v24                                // 00000049CEE0: 08283117
	v_mad_i64_i32 v[14:15], null, v14, s12, 0                  // 00000049CEE4: D6FF7C0E 0200190E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000049CEEC: BF8701B3
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 00000049CEF0: 102222FF 3DB504F3
	.long 0xd73c000c                                           // 00000049CEF8: D73C000C
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 00000049CEFC: 02023281
	v_lshlrev_b32_e32 v26, 9, v9                               // 00000049CF00: 30341289
	v_mul_f32_e32 v24, s0, v17                                 // 00000049CF04: 10302200
	v_add_f32_e32 v16, v18, v20                                // 00000049CF08: 06202912
	v_sub_f32_e32 v18, v18, v20                                // 00000049CF0C: 08242912
	.long 0xd7600000                                           // 00000049CF10: D7600000
	v_cndmask_b32_e32 v0, v1, v153, vcc_lo                     // 00000049CF14: 02013301
	.long 0x7f28398b                                           // 00000049CF18: 7F28398B
	.long 0x7e283998                                           // 00000049CF1C: 7E283998
	.long 0xd73c000e                                           // 00000049CF20: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 00000049CF24: 02021C81
	v_dual_mul_f32 v18, 0x3db504f3, v18 :: v_dual_sub_f32 v19, v19, v21// 00000049CF28: C8CA24FF 12122B13 3DB504F3
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 00000049CF34: 102020FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000049CF3C: BF870224
	v_and_b32_e32 v20, 1, v20                                  // 00000049CF40: 36282881
	.long 0xd7006a0c                                           // 00000049CF44: D7006A0C
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 00000049CF48: 02021903
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 00000049CF4C: 102626FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000049CF54: BF870244
	v_mul_f32_e32 v23, s2, v16                                 // 00000049CF58: 102E2002
	v_mad_i64_i32 v[16:17], null, v22, s12, 0                  // 00000049CF5C: D6FF7C10 02001916
	v_mul_f32_e32 v22, s0, v18                                 // 00000049CF64: 102C2400
	v_add_co_ci_u32_e64 v13, null, v4, v13, vcc_lo             // 00000049CF68: D5207C0D 01AA1B04
	.long 0x7e163997                                           // 00000049CF70: 7E163997
	.long 0xd7006a0e                                           // 00000049CF74: D7006A0E
	v_cndmask_b32_e32 v1, v3, v14, vcc_lo                      // 00000049CF78: 02021D03
	v_mul_f32_e32 v25, s3, v19                                 // 00000049CF7C: 10322603
	v_add3_u32 v20, v24, v20, 0x7fff                           // 00000049CF80: D6550014 03FE2918 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000049CF8C: BF870244
	v_and_b32_e32 v21, 1, v11                                  // 00000049CF90: 362A1681
	v_xor_b32_e32 v24, v9, v2                                  // 00000049CF94: 3A300509
	v_add_co_ci_u32_e64 v15, null, v4, v15, vcc_lo             // 00000049CF98: D5207C0F 01AA1F04
	.long 0x7e163996                                           // 00000049CFA0: 7E163996
	v_add3_u32 v21, v23, v21, 0x7fff                           // 00000049CFA4: D6550015 03FE2B17 00007FFF
	.long 0x7e2e3999                                           // 00000049CFB0: 7E2E3999
	.long 0x7f2e398b                                           // 00000049CFB4: 7F2E398B
	s_clause 0x1                                               // 00000049CFB8: BF850001
	global_store_d16_hi_b16 v[12:13], v20, off                 // 00000049CFBC: DC960000 007C140C
	global_store_d16_hi_b16 v[14:15], v21, off                 // 00000049CFC4: DC960000 007C150E
	v_lshl_add_u32 v14, v24, 2, v26                            // 00000049CFCC: D646000E 04690518
	v_mad_i64_i32 v[18:19], null, v10, s12, 0                  // 00000049CFD4: D6FF7C12 0200190A
	v_and_b32_e32 v10, 1, v11                                  // 00000049CFDC: 36141681
	.long 0xd73c0010                                           // 00000049CFE0: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 00000049CFE4: 02022081
	v_or_b32_e32 v21, s1, v9                                   // 00000049CFE8: 382A1201
	ds_load_2addr_stride64_b32 v[12:13], v14 offset1:64        // 00000049CFEC: D8E04000 0C00000E
	v_and_b32_e32 v15, 1, v23                                  // 00000049CFF4: 361E2E81
	v_add3_u32 v20, v22, v10, 0x7fff                           // 00000049CFF8: D6550014 03FE1516 00007FFF
	.long 0xd7600002                                           // 00000049D004: D7600002
	v_cndmask_b32_e32 v0, v1, v138, vcc_lo                     // 00000049D008: 02011501
	.long 0xd73c0009                                           // 00000049D00C: D73C0009
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000049D010: 02022481
	.long 0xd7006a10                                           // 00000049D014: D7006A10
	v_cndmask_b32_e32 v1, v3, v16, vcc_lo                      // 00000049D018: 02022103
	v_add3_u32 v22, v25, v15, 0x7fff                           // 00000049D01C: D6550016 03FE1F19 00007FFF
	ds_load_2addr_stride64_b32 v[14:15], v14 offset0:128 offset1:192// 00000049D028: D8E0C080 0E00000E
	v_add_co_ci_u32_e64 v17, null, v4, v17, vcc_lo             // 00000049D030: D5207C11 01AA2304
	v_mad_i64_i32 v[18:19], null, v21, s12, 0                  // 00000049D038: D6FF7C12 02001915
	.long 0xd7006a09                                           // 00000049D040: D7006A09
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 00000049D044: 02021303
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049D048: BF870001
	v_add_co_ci_u32_e64 v10, null, v4, v10, vcc_lo             // 00000049D04C: D5207C0A 01AA1504
	global_store_d16_hi_b16 v[16:17], v22, off                 // 00000049D054: DC960000 007C1610
	v_or_b32_e32 v22, 32, v21                                  // 00000049D05C: 382C2AA0
	v_or_b32_e32 v23, 64, v21                                  // 00000049D060: 382E2AC0
	.long 0xd73c0010                                           // 00000049D064: D73C0010
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000049D068: 02022481
	global_store_d16_hi_b16 v[9:10], v20, off                  // 00000049D06C: DC960000 007C1409
	s_waitcnt lgkmcnt(1)                                       // 00000049D074: BF89FC17
	v_sub_f32_e32 v20, v12, v13                                // 00000049D078: 08281B0C
	v_mad_i64_i32 v[9:10], null, v22, s12, 0                   // 00000049D07C: D6FF7C09 02001916
	v_mad_i64_i32 v[18:19], null, v23, s12, 0                  // 00000049D084: D6FF7C12 02001917
	v_dual_add_f32 v22, v12, v13 :: v_dual_lshlrev_b32 v25, 9, v8// 00000049D08C: C9221B0C 16181089
	.long 0xd7600000                                           // 00000049D094: D7600000
	v_cndmask_b32_e32 v0, v1, v130, vcc_lo                     // 00000049D098: 02010501
	.long 0xd7600003                                           // 00000049D09C: D7600003
	v_cndmask_b32_e32 v0, v1, v146, vcc_lo                     // 00000049D0A0: 02012501
	s_waitcnt lgkmcnt(0)                                       // 00000049D0A4: BF89FC07
	v_sub_f32_e32 v23, v14, v15                                // 00000049D0A8: 082E1F0E
	v_add_f32_e32 v14, v14, v15                                // 00000049D0AC: 061C1F0E
	.long 0xd73c0009                                           // 00000049D0B0: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 00000049D0B4: 02021281
	.long 0xd73c000c                                           // 00000049D0B8: D73C000C
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000049D0BC: 02022481
	.long 0x7f34398b                                           // 00000049D0C0: 7F34398B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000049D0C4: BF8701B4
	v_dual_add_f32 v15, v20, v23 :: v_dual_add_f32 v18, v22, v14// 00000049D0C8: C9082F14 0F121D16
	v_sub_f32_e32 v14, v22, v14                                // 00000049D0D0: 081C1D16
	.long 0xd7006a10                                           // 00000049D0D4: D7006A10
	v_cndmask_b32_e32 v1, v3, v16, vcc_lo                      // 00000049D0D8: 02022103
	v_dual_mul_f32 v15, 0x3db504f3, v15 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 00000049D0DC: C8C61EFF 0F1224FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000049D0E8: BF8701A3
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 00000049D0EC: 101C1CFF 3DB504F3
	v_add_co_ci_u32_e64 v17, null, v4, v17, vcc_lo             // 00000049D0F4: D5207C11 01AA2304
	v_mul_f32_e32 v19, s2, v15                                 // 00000049D0FC: 10261E02
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000049D100: BF870234
	v_dual_sub_f32 v15, v20, v23 :: v_dual_mul_f32 v22, s0, v18// 00000049D104: C9462F14 0F162400
	.long 0xd7600000                                           // 00000049D10C: D7600000
	v_cndmask_b32_e32 v0, v1, v154, vcc_lo                     // 00000049D110: 02013501
	v_mul_f32_e32 v24, s3, v14                                 // 00000049D114: 10301C03
	.long 0x7e163993                                           // 00000049D118: 7E163993
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049D11C: BF870004
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 00000049D120: 101E1EFF 3DB504F3
	v_or_b32_e32 v14, 0x60, v21                                // 00000049D128: 381C2AFF 00000060
	v_xor_b32_e32 v21, v8, v2                                  // 00000049D130: 3A2A0508
	.long 0x7e243996                                           // 00000049D134: 7E243996
	.long 0x7f24398b                                           // 00000049D138: 7F24398B
	v_mul_f32_e32 v23, s0, v15                                 // 00000049D13C: 102E1E00
	v_and_b32_e32 v20, 1, v11                                  // 00000049D140: 36281681
	v_lshl_add_u32 v21, v21, 2, v25                            // 00000049D144: D6460015 04650515
	v_mad_i64_i32 v[14:15], null, v14, s12, 0                  // 00000049D14C: D6FF7C0E 0200190E
	v_and_b32_e32 v25, 1, v18                                  // 00000049D154: 36322481
	.long 0x7e343998                                           // 00000049D158: 7E343998
	v_add3_u32 v27, v19, v20, 0x7fff                           // 00000049D15C: D655001B 03FE2913 00007FFF
	ds_load_2addr_stride64_b32 v[18:19], v21 offset1:64        // 00000049D168: D8E04000 12000015
	ds_load_2addr_stride64_b32 v[20:21], v21 offset0:128 offset1:192// 00000049D170: D8E0C080 14000015
	.long 0x7e163997                                           // 00000049D178: 7E163997
	.long 0xd7006a09                                           // 00000049D17C: D7006A09
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 00000049D180: 02021303
	.long 0xd73c000e                                           // 00000049D184: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 00000049D188: 02021C81
	v_and_b32_e32 v26, 1, v26                                  // 00000049D18C: 36343481
	v_add3_u32 v8, v22, v25, 0x7fff                            // 00000049D190: D6550008 03FE3316 00007FFF
	v_add_co_ci_u32_e64 v10, null, v4, v10, vcc_lo             // 00000049D19C: D5207C0A 01AA1504
	.long 0xd7600003                                           // 00000049D1A4: D7600003
	v_cndmask_b32_e32 v0, v1, v147, vcc_lo                     // 00000049D1A8: 02012701
	v_and_b32_e32 v28, 1, v11                                  // 00000049D1AC: 36381681
	.long 0xd7006a0c                                           // 00000049D1B0: D7006A0C
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 00000049D1B4: 02021903
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049D1B8: BF870001
	v_add_co_ci_u32_e64 v13, null, v4, v13, vcc_lo             // 00000049D1BC: D5207C0D 01AA1B04
	.long 0xd7006a0e                                           // 00000049D1C4: D7006A0E
	v_cndmask_b32_e32 v1, v3, v14, vcc_lo                      // 00000049D1C8: 02021D03
	v_add3_u32 v24, v24, v26, 0x7fff                           // 00000049D1CC: D6550018 03FE3518 00007FFF
	s_clause 0x1                                               // 00000049D1D8: BF850001
	global_store_d16_hi_b16 v[16:17], v8, off                  // 00000049D1DC: DC960000 007C0810
	global_store_d16_hi_b16 v[9:10], v27, off                  // 00000049D1E4: DC960000 007C1B09
	v_or_b32_e32 v10, 32, v29                                  // 00000049D1EC: 38143AA0
	v_add3_u32 v25, v23, v28, 0x7fff                           // 00000049D1F0: D6550019 03FE3917 00007FFF
	v_add_co_ci_u32_e64 v15, null, v4, v15, vcc_lo             // 00000049D1FC: D5207C0F 01AA1F04
	s_clause 0x1                                               // 00000049D204: BF850001
	global_store_d16_hi_b16 v[12:13], v24, off                 // 00000049D208: DC960000 007C180C
	global_store_d16_hi_b16 v[14:15], v25, off                 // 00000049D210: DC960000 007C190E
	v_mad_i64_i32 v[12:13], null, v10, s12, 0                  // 00000049D218: D6FF7C0C 0200190A
	s_waitcnt lgkmcnt(0)                                       // 00000049D220: BF89FC07
	v_dual_sub_f32 v10, v18, v19 :: v_dual_sub_f32 v17, v20, v21// 00000049D224: C94A2712 0A102B14
	.long 0xd7600000                                           // 00000049D22C: D7600000
	v_cndmask_b32_e32 v0, v1, v131, vcc_lo                     // 00000049D230: 02010701
	v_mad_i64_i32 v[22:23], null, v29, s12, 0                  // 00000049D234: D6FF7C16 0200191D
	.long 0xd7600002                                           // 00000049D23C: D7600002
	v_cndmask_b32_e32 v0, v1, v139, vcc_lo                     // 00000049D240: 02011701
	v_or_b32_e32 v27, s1, v6                                   // 00000049D244: 38360C01
	v_add_f32_e32 v14, v10, v17                                // 00000049D248: 061C230A
	v_sub_f32_e32 v10, v10, v17                                // 00000049D24C: 0814230A
	.long 0x7f22398b                                           // 00000049D250: 7F22398B
	v_add_f32_e32 v16, v18, v19                                // 00000049D254: 06202712
	v_add_f32_e32 v18, v20, v21                                // 00000049D258: 06242B14
	.long 0xd73c0008                                           // 00000049D25C: D73C0008
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 00000049D260: 02022C81
	v_dual_mul_f32 v14, 0x3db504f3, v14 :: v_dual_lshlrev_b32 v23, 9, v7// 00000049D264: C8E21CFF 0E160E89 3DB504F3
	v_or_b32_e32 v19, 64, v29                                  // 00000049D270: 38263AC0
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049D274: BF870004
	v_add_f32_e32 v15, v16, v18                                // 00000049D278: 061E2510
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 00000049D27C: 101414FF 3DB504F3
	.long 0xd73c000c                                           // 00000049D284: D73C000C
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000049D288: 02021881
	v_mul_f32_e32 v20, s2, v14                                 // 00000049D28C: 10281C02
	.long 0xd7600002                                           // 00000049D290: D7600002
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 00000049D294: 02011901
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 00000049D298: 101E1EFF 3DB504F3
	.long 0xd7006a08                                           // 00000049D2A0: D7006A08
	v_cndmask_b32_e32 v1, v3, v8, vcc_lo                       // 00000049D2A4: 02021103
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000049D2A8: BF870224
	.long 0x7e163994                                           // 00000049D2AC: 7E163994
	v_add_co_ci_u32_e64 v9, null, v4, v9, vcc_lo               // 00000049D2B0: D5207C09 01AA1304
	v_mul_f32_e32 v21, s0, v15                                 // 00000049D2B8: 102A1E00
	.long 0xd7600000                                           // 00000049D2BC: D7600000
	v_cndmask_b32_e32 v0, v1, v155, vcc_lo                     // 00000049D2C0: 02013701
	v_mad_i64_i32 v[14:15], null, v19, s12, 0                  // 00000049D2C4: D6FF7C0E 02001913
	.long 0xd7006a0c                                           // 00000049D2CC: D7006A0C
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 00000049D2D0: 02021903
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049D2D4: BF870214
	.long 0x7e223995                                           // 00000049D2D8: 7E223995
	v_mul_f32_e32 v10, s0, v10                                 // 00000049D2DC: 10141400
	v_xor_b32_e32 v22, v7, v2                                  // 00000049D2E0: 3A2C0507
	v_add_co_ci_u32_e64 v13, null, v4, v13, vcc_lo             // 00000049D2E4: D5207C0D 01AA1B04
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049D2EC: BF870004
	v_dual_sub_f32 v16, v16, v18 :: v_dual_and_b32 v17, 1, v17 // 00000049D2F0: C9642510 10102281
	v_and_b32_e32 v18, 1, v11                                  // 00000049D2F8: 36241681
	.long 0x7e16398a                                           // 00000049D2FC: 7E16398A
	.long 0xd73c000e                                           // 00000049D300: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 00000049D304: 02021C81
	.long 0xd7600000                                           // 00000049D308: D7600000
	v_cndmask_b32_e32 v0, v1, v132, vcc_lo                     // 00000049D30C: 02010901
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 00000049D310: 102020FF 3DB504F3
	v_add3_u32 v18, v20, v18, 0x7fff                           // 00000049D318: D6550012 03FE2514 00007FFF
	v_add3_u32 v20, v21, v17, 0x7fff                           // 00000049D324: D6550014 03FE2315 00007FFF
	.long 0x7f2a398b                                           // 00000049D330: 7F2A398B
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049D334: BF870004
	v_dual_mul_f32 v19, s3, v16 :: v_dual_and_b32 v24, 1, v11  // 00000049D338: C8E42003 13181681
	v_or_b32_e32 v16, 0x60, v29                                // 00000049D340: 38203AFF 00000060
	s_clause 0x1                                               // 00000049D348: BF850001
	global_store_d16_hi_b16 v[8:9], v20, off                   // 00000049D34C: DC960000 007C1408
	global_store_d16_hi_b16 v[12:13], v18, off                 // 00000049D354: DC960000 007C120C
	v_lshl_add_u32 v12, v22, 2, v23                            // 00000049D35C: D646000C 045D0516
	v_add3_u32 v18, v10, v24, 0x7fff                           // 00000049D364: D6550012 03FE310A 00007FFF
	.long 0x7e2a3993                                           // 00000049D370: 7E2A3993
	v_mad_i64_i32 v[16:17], null, v16, s12, 0                  // 00000049D374: D6FF7C10 02001910
	v_or_b32_e32 v20, s1, v7                                   // 00000049D37C: 38280E01
	ds_load_2addr_stride64_b32 v[9:10], v12 offset1:64         // 00000049D380: D8E04000 0900000C
	.long 0xd7006a0e                                           // 00000049D388: D7006A0E
	v_cndmask_b32_e32 v1, v3, v14, vcc_lo                      // 00000049D38C: 02021D03
	v_and_b32_e32 v13, 1, v21                                  // 00000049D390: 361A2A81
	v_add_co_ci_u32_e64 v15, null, v4, v15, vcc_lo             // 00000049D394: D5207C0F 01AA1F04
	.long 0xd73c0007                                           // 00000049D39C: D73C0007
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 00000049D3A0: 02022081
	v_mad_i64_i32 v[16:17], null, v20, s12, 0                  // 00000049D3A4: D6FF7C10 02001914
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000049D3AC: BF8700D4
	v_add3_u32 v19, v19, v13, 0x7fff                           // 00000049D3B0: D6550013 03FE1B13 00007FFF
	ds_load_2addr_stride64_b32 v[12:13], v12 offset0:128 offset1:192// 00000049D3BC: D8E0C080 0C00000C
	v_or_b32_e32 v21, 64, v20                                  // 00000049D3C4: 382A28C0
	.long 0xd7600003                                           // 00000049D3C8: D7600003
	v_cndmask_b32_e32 v0, v1, v148, vcc_lo                     // 00000049D3CC: 02012901
	.long 0xd7006a07                                           // 00000049D3D0: D7006A07
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 00000049D3D4: 02020F03
	v_add_co_ci_u32_e64 v8, null, v4, v8, vcc_lo               // 00000049D3D8: D5207C08 01AA1104
	global_store_d16_hi_b16 v[14:15], v19, off                 // 00000049D3E0: DC960000 007C130E
	v_or_b32_e32 v19, 32, v20                                  // 00000049D3E8: 382628A0
	.long 0xd73c000e                                           // 00000049D3EC: D73C000E
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 00000049D3F0: 02022081
	v_mad_i64_i32 v[16:17], null, v21, s12, 0                  // 00000049D3F4: D6FF7C10 02001915
	global_store_d16_hi_b16 v[7:8], v18, off                   // 00000049D3FC: DC960000 007C1207
	s_waitcnt lgkmcnt(1)                                       // 00000049D404: BF89FC17
	v_sub_f32_e32 v18, v9, v10                                 // 00000049D408: 08241509
	v_mad_i64_i32 v[7:8], null, v19, s12, 0                    // 00000049D40C: D6FF7C07 02001913
	v_add_f32_e32 v19, v9, v10                                 // 00000049D414: 06261509
	.long 0x7f30398b                                           // 00000049D418: 7F30398B
	.long 0xd7006a0e                                           // 00000049D41C: D7006A0E
	v_cndmask_b32_e32 v1, v3, v14, vcc_lo                      // 00000049D420: 02021D03
	.long 0xd73c0009                                           // 00000049D424: D73C0009
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 00000049D428: 02022081
	v_add_co_ci_u32_e64 v15, null, v4, v15, vcc_lo             // 00000049D42C: D5207C0F 01AA1F04
	s_waitcnt lgkmcnt(0)                                       // 00000049D434: BF89FC07
	v_sub_f32_e32 v21, v12, v13                                // 00000049D438: 082A1B0C
	v_add_f32_e32 v12, v12, v13                                // 00000049D43C: 06181B0C
	.long 0xd73c0007                                           // 00000049D440: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000049D444: 02020E81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000049D448: BF870232
	v_add_f32_e32 v16, v19, v12                                // 00000049D44C: 06201913
	v_sub_f32_e32 v12, v19, v12                                // 00000049D450: 08181913
	v_xor_b32_e32 v19, v6, v2                                  // 00000049D454: 3A260506
	.long 0xd7006a07                                           // 00000049D458: D7006A07
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 00000049D45C: 02020F03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049D460: BF870214
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 00000049D464: 102020FF 3DB504F3
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 00000049D46C: 101818FF 3DB504F3
	v_add_co_ci_u32_e64 v8, null, v4, v8, vcc_lo               // 00000049D474: D5207C08 01AA1104
	.long 0xd7006a09                                           // 00000049D47C: D7006A09
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 00000049D480: 02021303
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000049D484: BF870253
	v_mul_f32_e32 v23, s3, v12                                 // 00000049D488: 102E1803
	v_add_f32_e32 v13, v18, v21                                // 00000049D48C: 061A2B12
	v_or_b32_e32 v12, 0x60, v20                                // 00000049D490: 381828FF 00000060
	v_lshlrev_b32_e32 v20, 9, v6                               // 00000049D498: 30280C89
	v_add_co_ci_u32_e64 v10, null, v4, v10, vcc_lo             // 00000049D49C: D5207C0A 01AA1504
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 00000049D4A4: 101A1AFF 3DB504F3
	.long 0x7e303997                                           // 00000049D4AC: 7E303997
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000049D4B0: BF870224
	v_lshl_add_u32 v19, v19, 2, v20                            // 00000049D4B4: D6460013 04510513
	.long 0xd7600003                                           // 00000049D4BC: D7600003
	v_cndmask_b32_e32 v0, v1, v149, vcc_lo                     // 00000049D4C0: 02012B01
	v_mul_f32_e32 v17, s2, v13                                 // 00000049D4C4: 10221A02
	v_sub_f32_e32 v13, v18, v21                                // 00000049D4C8: 081A2B12
	v_mul_f32_e32 v21, s0, v16                                 // 00000049D4CC: 102A2000
	.long 0xd7600000                                           // 00000049D4D0: D7600000
	v_cndmask_b32_e32 v0, v1, v156, vcc_lo                     // 00000049D4D4: 02013901
	.long 0x7f20398b                                           // 00000049D4D8: 7F20398B
	.long 0x7e163991                                           // 00000049D4DC: 7E163991
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 00000049D4E0: 101A1AFF 3DB504F3
	.long 0x7e203995                                           // 00000049D4E8: 7E203995
	v_and_b32_e32 v24, 1, v24                                  // 00000049D4EC: 36303081
	.long 0xd7600002                                           // 00000049D4F0: D7600002
	v_cndmask_b32_e32 v0, v1, v141, vcc_lo                     // 00000049D4F4: 02011B01
	v_and_b32_e32 v18, 1, v11                                  // 00000049D4F8: 36241681
	v_mul_f32_e32 v22, s0, v13                                 // 00000049D4FC: 102C1A00
	v_mad_i64_i32 v[12:13], null, v12, s12, 0                  // 00000049D500: D6FF7C0C 0200190C
	v_and_b32_e32 v20, 1, v16                                  // 00000049D508: 36282081
	v_add3_u32 v23, v23, v24, 0x7fff                           // 00000049D50C: D6550017 03FE3117 00007FFF
	v_add3_u32 v25, v17, v18, 0x7fff                           // 00000049D518: D6550019 03FE2511 00007FFF
	ds_load_2addr_stride64_b32 v[16:17], v19 offset1:64        // 00000049D524: D8E04000 10000013
	ds_load_2addr_stride64_b32 v[18:19], v19 offset0:128 offset1:192// 00000049D52C: D8E0C080 12000013
	.long 0x7e163996                                           // 00000049D534: 7E163996
	v_add3_u32 v6, v21, v20, 0x7fff                            // 00000049D538: D6550006 03FE2915 00007FFF
	s_clause 0x1                                               // 00000049D544: BF850001
	global_store_d16_hi_b16 v[14:15], v6, off                  // 00000049D548: DC960000 007C060E
	global_store_d16_hi_b16 v[7:8], v25, off                   // 00000049D550: DC960000 007C1907
	.long 0xd73c000c                                           // 00000049D558: D73C000C
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000049D55C: 02021881
	v_and_b32_e32 v26, 1, v11                                  // 00000049D560: 36341681
	v_mad_i64_i32 v[20:21], null, v27, s12, 0                  // 00000049D564: D6FF7C14 0200191B
	.long 0xd7600000                                           // 00000049D56C: D7600000
	v_cndmask_b32_e32 v0, v1, v133, vcc_lo                     // 00000049D570: 02010B01
	v_or_b32_e32 v8, 32, v27                                   // 00000049D574: 381036A0
	.long 0xd7006a0c                                           // 00000049D578: D7006A0C
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 00000049D57C: 02021903
	v_add3_u32 v22, v22, v26, 0x7fff                           // 00000049D580: D6550016 03FE3516 00007FFF
	v_add_co_ci_u32_e64 v13, null, v4, v13, vcc_lo             // 00000049D58C: D5207C0D 01AA1B04
	s_clause 0x1                                               // 00000049D594: BF850001
	global_store_d16_hi_b16 v[9:10], v23, off                  // 00000049D598: DC960000 007C1709
	global_store_d16_hi_b16 v[12:13], v22, off                 // 00000049D5A0: DC960000 007C160C
	s_waitcnt lgkmcnt(1)                                       // 00000049D5A8: BF89FC17
	v_sub_f32_e32 v10, v16, v17                                // 00000049D5AC: 08142310
	s_waitcnt lgkmcnt(0)                                       // 00000049D5B0: BF89FC07
	v_dual_add_f32 v14, v16, v17 :: v_dual_sub_f32 v15, v18, v19// 00000049D5B4: C90A2310 0E0E2712
	v_add_f32_e32 v16, v18, v19                                // 00000049D5BC: 06202712
	.long 0xd73c0006                                           // 00000049D5C0: D73C0006
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 00000049D5C4: 02022881
	v_or_b32_e32 v12, 64, v27                                  // 00000049D5C8: 381836C0
	v_or_b32_e32 v19, 0x60, v27                                // 00000049D5CC: 382636FF 00000060
	v_add_f32_e32 v17, v10, v15                                // 00000049D5D4: 06221F0A
	v_add_f32_e32 v18, v14, v16                                // 00000049D5D8: 0624210E
	v_sub_f32_e32 v14, v14, v16                                // 00000049D5DC: 081C210E
	v_sub_f32_e32 v10, v10, v15                                // 00000049D5E0: 08141F0A
	.long 0x7f1e398b                                           // 00000049D5E4: 7F1E398B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049D5E8: BF870214
	v_dual_mul_f32 v17, 0x3db504f3, v17 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 00000049D5EC: C8C622FF 111224FF 3DB504F3
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 00000049D5F8: 101C1CFF 3DB504F3
	v_lshlrev_b32_e32 v16, 9, v5                               // 00000049D600: 30200A89
	v_mad_i64_i32 v[8:9], null, v8, s12, 0                     // 00000049D604: D6FF7C08 02001908
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049D60C: BF870214
	v_dual_mul_f32 v20, s2, v17 :: v_dual_mul_f32 v17, s0, v18 // 00000049D610: C8C62202 14102400
	v_mul_f32_e32 v22, s3, v14                                 // 00000049D618: 102C1C03
	.long 0x7f24398b                                           // 00000049D61C: 7F24398B
	v_mad_i64_i32 v[12:13], null, v12, s12, 0                  // 00000049D620: D6FF7C0C 0200190C
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049D628: BF870004
	.long 0x7e163994                                           // 00000049D62C: 7E163994
	.long 0x7e1e3991                                           // 00000049D630: 7E1E3991
	.long 0x7e243996                                           // 00000049D634: 7E243996
	.long 0xd73c0008                                           // 00000049D638: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000049D63C: 02021081
	.long 0xd7600000                                           // 00000049D640: D7600000
	v_cndmask_b32_e32 v0, v1, v157, vcc_lo                     // 00000049D644: 02013B01
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 00000049D648: 101414FF 3DB504F3
	v_and_b32_e32 v14, 1, v15                                  // 00000049D650: 361C1E81
	v_xor_b32_e32 v15, v5, v2                                  // 00000049D654: 3A1E0505
	v_and_b32_e32 v25, 1, v18                                  // 00000049D658: 36322481
	.long 0xd73c000c                                           // 00000049D65C: D73C000C
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000049D660: 02021881
	.long 0xd7006a06                                           // 00000049D664: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000049D668: 02020D03
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049D66C: BF870004
	v_lshl_add_u32 v23, v15, 2, v16                            // 00000049D670: D6460017 0441050F
	v_add3_u32 v24, v17, v14, 0x7fff                           // 00000049D678: D6550018 03FE1D11 00007FFF
	v_mad_i64_i32 v[14:15], null, v19, s12, 0                  // 00000049D684: D6FF7C0E 02001913
	ds_load_2addr_stride64_b32 v[16:17], v23 offset1:64        // 00000049D68C: D8E04000 10000017
	ds_load_2addr_stride64_b32 v[18:19], v23 offset0:128 offset1:192// 00000049D694: D8E0C080 12000017
	v_dual_mul_f32 v10, s0, v10 :: v_dual_and_b32 v21, 1, v11  // 00000049D69C: C8E41400 0A141681
	v_add_co_ci_u32_e64 v7, null, v4, v7, vcc_lo               // 00000049D6A4: D5207C07 01AA0F04
	.long 0xd7006a08                                           // 00000049D6AC: D7006A08
	v_cndmask_b32_e32 v1, v3, v8, vcc_lo                       // 00000049D6B0: 02021103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049D6B4: BF870001
	v_add_co_ci_u32_e64 v9, null, v4, v9, vcc_lo               // 00000049D6B8: D5207C09 01AA1304
	.long 0xd7006a0c                                           // 00000049D6C0: D7006A0C
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 00000049D6C4: 02021903
	.long 0x7e16398a                                           // 00000049D6C8: 7E16398A
	v_add_co_ci_u32_e64 v13, null, v4, v13, vcc_lo             // 00000049D6CC: D5207C0D 01AA1B04
	v_add3_u32 v20, v20, v21, 0x7fff                           // 00000049D6D4: D6550014 03FE2B14 00007FFF
	v_add3_u32 v21, v22, v25, 0x7fff                           // 00000049D6E0: D6550015 03FE3316 00007FFF
	global_store_d16_hi_b16 v[6:7], v24, off                   // 00000049D6EC: DC960000 007C1806
	v_or_b32_e32 v22, s1, v5                                   // 00000049D6F4: 382C0A01
	.long 0xd73c0005                                           // 00000049D6F8: D73C0005
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 00000049D6FC: 02021C81
	v_and_b32_e32 v7, 1, v11                                   // 00000049D700: 360E1681
	s_clause 0x1                                               // 00000049D704: BF850001
	global_store_d16_hi_b16 v[8:9], v20, off                   // 00000049D708: DC960000 007C1408
	global_store_d16_hi_b16 v[12:13], v21, off                 // 00000049D710: DC960000 007C150C
	s_waitcnt lgkmcnt(1)                                       // 00000049D718: BF89FC17
	v_sub_f32_e32 v12, v16, v17                                // 00000049D71C: 08182310
	s_waitcnt lgkmcnt(0)                                       // 00000049D720: BF89FC07
	v_dual_add_f32 v13, v16, v17 :: v_dual_add_f32 v16, v18, v19// 00000049D724: C9082310 0D102712
	.long 0xd7006a05                                           // 00000049D72C: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 00000049D730: 02020B03
	v_add3_u32 v14, v10, v7, 0x7fff                            // 00000049D734: D655000E 03FE0F0A 00007FFF
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 00000049D740: D5207C06 01AA0D04
	v_sub_f32_e32 v15, v18, v19                                // 00000049D748: 081E2712
	v_add_f32_e32 v17, v13, v16                                // 00000049D74C: 0622210D
	.long 0xd7600000                                           // 00000049D750: D7600000
	v_cndmask_b32_e32 v0, v1, v134, vcc_lo                     // 00000049D754: 02010D01
	global_store_d16_hi_b16 v[5:6], v14, off                   // 00000049D758: DC960000 007C0E05
	.long 0xd7600002                                           // 00000049D760: D7600002
	v_cndmask_b32_e32 v0, v1, v142, vcc_lo                     // 00000049D764: 02011D01
	v_dual_add_f32 v14, v12, v15 :: v_dual_mul_f32 v17, 0x3db504f3, v17// 00000049D768: C9061F0C 0E1022FF 3DB504F3
	v_sub_f32_e32 v13, v13, v16                                // 00000049D774: 081A210D
	v_or_b32_e32 v9, 32, v22                                   // 00000049D778: 38122CA0
	.long 0x7f24398b                                           // 00000049D77C: 7F24398B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000049D780: BF8701B4
	v_dual_mul_f32 v14, 0x3db504f3, v14 :: v_dual_mul_f32 v17, s0, v17// 00000049D784: C8C61CFF 0E102200 3DB504F3
	.long 0xd7600000                                           // 00000049D790: D7600000
	v_cndmask_b32_e32 v0, v1, v150, vcc_lo                     // 00000049D794: 02012D01
	v_dual_sub_f32 v12, v12, v15 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 00000049D798: C9461F0C 0C0C1AFF 3DB504F3
	v_mul_f32_e32 v14, s2, v14                                 // 00000049D7A4: 101C1C02
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049D7A8: BF870004
	.long 0x7e243991                                           // 00000049D7AC: 7E243991
	v_mad_i64_i32 v[7:8], null, v22, s12, 0                    // 00000049D7B0: D6FF7C07 02001916
	v_mad_i64_i32 v[9:10], null, v9, s12, 0                    // 00000049D7B8: D6FF7C09 02001909
	.long 0xd7600002                                           // 00000049D7C0: D7600002
	v_cndmask_b32_e32 v0, v1, v158, vcc_lo                     // 00000049D7C4: 02013D01
	.long 0x7e16398e                                           // 00000049D7C8: 7E16398E
	v_and_b32_e32 v16, 1, v18                                  // 00000049D7CC: 36202481
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 00000049D7D0: 101818FF 3DB504F3
	v_mul_f32_e32 v18, s0, v13                                 // 00000049D7D8: 10241A00
	v_xor_b32_e32 v2, v0, v2                                   // 00000049D7DC: 3A040500
	.long 0xd73c0005                                           // 00000049D7E0: D73C0005
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000049D7E4: 02020E81
	.long 0xd73c0007                                           // 00000049D7E8: D73C0007
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 00000049D7EC: 02021281
	v_or_b32_e32 v9, 64, v22                                   // 00000049D7F0: 38122CC0
	v_and_b32_e32 v15, 1, v11                                  // 00000049D7F4: 361E1681
	v_mul_f32_e32 v23, s2, v12                                 // 00000049D7F8: 102E1802
	v_lshlrev_b32_e32 v12, 9, v0                               // 00000049D7FC: 30180089
	.long 0x7e1a3992                                           // 00000049D800: 7E1A3992
	.long 0x7f1a398b                                           // 00000049D804: 7F1A398B
	v_mad_i64_i32 v[9:10], null, v9, s12, 0                    // 00000049D808: D6FF7C09 02001909
	v_add3_u32 v20, v14, v15, 0x7fff                           // 00000049D810: D6550014 03FE1F0E 00007FFF
	v_or_b32_e32 v14, 0x60, v22                                // 00000049D81C: 381C2CFF 00000060
	v_lshl_add_u32 v2, v2, 2, v12                              // 00000049D824: D6460002 04310502
	v_or_b32_e32 v22, s1, v0                                   // 00000049D82C: 382C0001
	v_and_b32_e32 v0, 1, v13                                   // 00000049D830: 36001A81
	.long 0xd7006a05                                           // 00000049D834: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 00000049D838: 02020B03
	v_mad_i64_i32 v[12:13], null, v14, s12, 0                  // 00000049D83C: D6FF7C0C 0200190E
	ds_load_2addr_stride64_b32 v[14:15], v2 offset1:64         // 00000049D844: D8E04000 0E000002
	v_add3_u32 v0, v18, v0, 0x7fff                             // 00000049D84C: D6550000 03FE0112 00007FFF
	ds_load_2addr_stride64_b32 v[18:19], v2 offset0:128 offset1:192// 00000049D858: D8E0C080 12000002
	.long 0xd73c0009                                           // 00000049D860: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 00000049D864: 02021281
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 00000049D868: D5207C06 01AA0D04
	.long 0xd7006a07                                           // 00000049D870: D7006A07
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 00000049D874: 02020F03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049D878: BF870211
	v_add_co_ci_u32_e64 v8, null, v4, v8, vcc_lo               // 00000049D87C: D5207C08 01AA1104
	.long 0xd7006a09                                           // 00000049D884: D7006A09
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 00000049D888: 02021303
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049D88C: BF870001
	v_add_co_ci_u32_e64 v10, null, v4, v10, vcc_lo             // 00000049D890: D5207C0A 01AA1504
	v_add3_u32 v21, v17, v16, 0x7fff                           // 00000049D898: D6550015 03FE2111 00007FFF
	s_clause 0x2                                               // 00000049D8A4: BF850002
	global_store_d16_hi_b16 v[5:6], v21, off                   // 00000049D8A8: DC960000 007C1505
	global_store_d16_hi_b16 v[7:8], v20, off                   // 00000049D8B0: DC960000 007C1407
	global_store_d16_hi_b16 v[9:10], v0, off                   // 00000049D8B8: DC960000 007C0009
	v_add_nc_u32_e32 v0, 32, v22                               // 00000049D8C0: 4A002CA0
	v_mad_i64_i32 v[16:17], null, v22, s12, 0                  // 00000049D8C4: D6FF7C10 02001916
	s_waitcnt lgkmcnt(1)                                       // 00000049D8CC: BF89FC17
	v_add_f32_e32 v2, v14, v15                                 // 00000049D8D0: 06041F0E
	.long 0xd73c0005                                           // 00000049D8D4: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000049D8D8: 02021881
	v_or_b32_e32 v12, 64, v22                                  // 00000049D8DC: 38182CC0
	v_mad_i64_i32 v[9:10], null, v0, s12, 0                    // 00000049D8E0: D6FF7C09 02001900
	v_sub_f32_e32 v0, v14, v15                                 // 00000049D8E8: 08001F0E
	s_waitcnt lgkmcnt(0)                                       // 00000049D8EC: BF89FC07
	v_sub_f32_e32 v14, v18, v19                                // 00000049D8F0: 081C2712
	v_add_f32_e32 v15, v18, v19                                // 00000049D8F4: 061E2712
	.long 0xd73c0007                                           // 00000049D8F8: D73C0007
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 00000049D8FC: 02022081
	v_mad_i64_i32 v[12:13], null, v12, s12, 0                  // 00000049D900: D6FF7C0C 0200190C
	.long 0xd7600001                                           // 00000049D908: D7600001
	v_cndmask_b32_e32 v0, v1, v143, vcc_lo                     // 00000049D90C: 02011F01
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000049D910: BF870244
	v_dual_add_f32 v16, v0, v14 :: v_dual_add_f32 v17, v2, v15 // 00000049D914: C9081D00 10101F02
	v_sub_f32_e32 v0, v0, v14                                  // 00000049D91C: 08001D00
	v_sub_f32_e32 v2, v2, v15                                  // 00000049D920: 08041F02
	.long 0x7e163997                                           // 00000049D924: 7E163997
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 00000049D928: 102020FF 3DB504F3
	.long 0xd7600000                                           // 00000049D930: D7600000
	v_cndmask_b32_e32 v0, v1, v135, vcc_lo                     // 00000049D934: 02010F01
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 00000049D938: 102222FF 3DB504F3
	.long 0xd7600003                                           // 00000049D940: D7600003
	v_cndmask_b32_e32 v0, v1, v159, vcc_lo                     // 00000049D944: 02013F01
	.long 0xd7600002                                           // 00000049D948: D7600002
	v_cndmask_b32_e32 v0, v1, v151, vcc_lo                     // 00000049D94C: 02012F01
	v_mul_f32_e32 v14, s1, v16                                 // 00000049D950: 101C2001
	v_mul_f32_e32 v16, 0x3db504f3, v0                          // 00000049D954: 102000FF 3DB504F3
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 00000049D95C: 100404FF 3DB504F3
	.long 0xd73c0000                                           // 00000049D964: D73C0000
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000049D968: 02021881
	v_add_nc_u32_e32 v12, 0x60, v22                            // 00000049D96C: 4A182CFF 00000060
	v_dual_mul_f32 v15, s0, v17 :: v_dual_and_b32 v24, 1, v11  // 00000049D974: C8E42200 0F181681
	.long 0x7e16398e                                           // 00000049D97C: 7E16398E
	v_mul_f32_e32 v16, s3, v16                                 // 00000049D980: 10202003
	v_mul_f32_e32 v2, s2, v2                                   // 00000049D984: 10040402
	v_mad_i64_i32 v[12:13], null, v12, s12, 0                  // 00000049D988: D6FF7C0C 0200190C
	.long 0x7e22398f                                           // 00000049D990: 7E22398F
	.long 0x7f22398b                                           // 00000049D994: 7F22398B
	v_and_b32_e32 v18, 1, v11                                  // 00000049D998: 36241681
	.long 0x7e163990                                           // 00000049D99C: 7E163990
	.long 0xd73c0009                                           // 00000049D9A0: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 00000049D9A4: 02021281
	.long 0x7e263982                                           // 00000049D9A8: 7E263982
	.long 0x7f26398b                                           // 00000049D9AC: 7F26398B
	.long 0xd7006a05                                           // 00000049D9B0: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 00000049D9B4: 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049D9B8: BF870001
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 00000049D9BC: D5207C06 01AA0D04
	.long 0xd7006a07                                           // 00000049D9C4: D7006A07
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 00000049D9C8: 02020F03
	v_and_b32_e32 v17, 1, v17                                  // 00000049D9CC: 36222281
	v_and_b32_e32 v21, 1, v11                                  // 00000049D9D0: 362A1681
	.long 0xd73c000b                                           // 00000049D9D4: D73C000B
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000049D9D8: 02021881
	v_and_b32_e32 v19, 1, v19                                  // 00000049D9DC: 36262681
	v_add_co_ci_u32_e64 v8, null, v4, v8, vcc_lo               // 00000049D9E0: D5207C08 01AA1104
	.long 0xd7006a09                                           // 00000049D9E8: D7006A09
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 00000049D9EC: 02021303
	v_add3_u32 v20, v23, v24, 0x7fff                           // 00000049D9F0: D6550014 03FE3117 00007FFF
	v_add_co_ci_u32_e64 v10, null, v4, v10, vcc_lo             // 00000049D9FC: D5207C0A 01AA1504
	.long 0xd7006a00                                           // 00000049DA04: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000049DA08: 02020103
	v_add3_u32 v13, v14, v18, 0x7fff                           // 00000049DA0C: D655000D 03FE250E 00007FFF
	v_add3_u32 v14, v15, v17, 0x7fff                           // 00000049DA18: D655000E 03FE230F 00007FFF
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 00000049DA24: D5207C01 01AA0304
	v_add3_u32 v15, v16, v21, 0x7fff                           // 00000049DA2C: D655000F 03FE2B10 00007FFF
	v_add3_u32 v16, v2, v19, 0x7fff                            // 00000049DA38: D6550010 03FE2702 00007FFF
	.long 0xd7006a02                                           // 00000049DA44: D7006A02
	v_cndmask_b32_e32 v1, v3, v11, vcc_lo                      // 00000049DA48: 02021703
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049DA4C: BF870001
	v_add_co_ci_u32_e64 v3, null, v4, v12, vcc_lo              // 00000049DA50: D5207C03 01AA1904
	s_clause 0x4                                               // 00000049DA58: BF850004
	global_store_d16_hi_b16 v[5:6], v20, off                   // 00000049DA5C: DC960000 007C1405
	global_store_d16_hi_b16 v[7:8], v14, off                   // 00000049DA64: DC960000 007C0E07
	global_store_d16_hi_b16 v[9:10], v13, off                  // 00000049DA6C: DC960000 007C0D09
	global_store_d16_hi_b16 v[0:1], v16, off                   // 00000049DA74: DC960000 007C1000
	global_store_d16_hi_b16 v[2:3], v15, off                   // 00000049DA7C: DC960000 007C0F02
	s_endpgm                                                   // 00000049DA84: BFB00000
		...

