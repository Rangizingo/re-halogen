000000000029b100 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 00000029B100: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 00000029B104: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 00000029B10C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 00000029B114: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 00000029B11C: F4000180 F8000118
	v_and_b32_e32 v24, 15, v0                                  // 00000029B124: 3630008F
	v_lshlrev_b32_e32 v23, 2, v0                               // 00000029B128: 302E0082
	s_delay_alu instid0(VALU_DEP_2)                            // 00000029B12C: BF870002
	v_lshlrev_b32_e32 v2, 2, v24                               // 00000029B130: 30043082
	s_waitcnt lgkmcnt(0)                                       // 00000029B134: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 00000029B138: BF028103
	s_cselect_b32 s7, -1, 0                                    // 00000029B13C: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000029B140: BF030402
	s_cselect_b32 s4, -1, 0                                    // 00000029B144: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029B148: BF870009
	s_and_b32 s4, s7, s4                                       // 00000029B14C: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000029B150: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 00000029B154: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 00000029B15C: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000029B160: BF030502
	s_cselect_b32 s5, -1, 0                                    // 00000029B164: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029B168: BF870009
	s_and_b32 s4, s7, s5                                       // 00000029B16C: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000029B170: BF028303
	v_readfirstlane_b32 s5, v1                                 // 00000029B174: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 00000029B178: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 00000029B17C: BF030602
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000029B180: 32020084
	s_cselect_b32 s6, -1, 0                                    // 00000029B184: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029B188: BF870009
	s_and_b32 s3, s3, s6                                       // 00000029B18C: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 00000029B190: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 00000029B194: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 00000029B198: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 00000029B19C: 98030483
	v_lshlrev_b32_e32 v3, 2, v1                                // 00000029B1A0: 30060282
	s_mulk_i32 s3, 0x48                                        // 00000029B1A4: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029B1A8: BF870009
	s_add_u32 s16, s0, s3                                      // 00000029B1AC: 80100300
	s_addc_u32 s17, s1, 0                                      // 00000029B1B0: 82118001
	s_clause 0x1                                               // 00000029B1B4: BF850001
	s_load_b256 s[4:11], s[16:17], 0x18                        // 00000029B1B8: F40C0108 F8000018
	s_load_b64 s[18:19], s[16:17], null                        // 00000029B1C0: F4040488 F8000000
	s_waitcnt lgkmcnt(0)                                       // 00000029B1C8: BF89FC07
	.long 0xd4540003                                           // 00000029B1CC: D4540003
	v_cndmask_b32_e32 v0, s10, v136, vcc_lo                    // 00000029B1D0: 0201100A
	s_and_b32 s12, s3, exec_lo                                 // 00000029B1D4: 8B0C7E03
	s_load_b128 s[12:15], s[0:1], 0x128                        // 00000029B1D8: F4080300 F8000128
	s_clause 0x1                                               // 00000029B1E0: BF850001
	global_load_b32 v2, v2, s[18:19]                           // 00000029B1E4: DC520000 02120002
	global_load_b32 v3, v3, s[18:19]                           // 00000029B1EC: DC520000 03120003
	s_cselect_b32 s22, 1, 16                                   // 00000029B1F4: 98169081
	s_cselect_b32 s23, 0, 4                                    // 00000029B1F8: 98178480
	s_add_i32 s24, s22, -1                                     // 00000029B1FC: 8118C116
	v_lshrrev_b32_e32 v25, s23, v1                             // 00000029B200: 32320217
	v_and_b32_e32 v26, s24, v1                                 // 00000029B204: 36340218
	s_waitcnt vmcnt(1)                                         // 00000029B208: BF8907F7
	v_bfe_u32 v4, v2, 16, 1                                    // 00000029B20C: D6100004 02052102
	s_waitcnt vmcnt(0)                                         // 00000029B214: BF8903F7
	v_bfe_u32 v5, v3, 16, 1                                    // 00000029B218: D6100005 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029B220: BF8701A2
	v_add3_u32 v2, v2, v4, 0x7fff                              // 00000029B224: D6550002 03FE0902 00007FFF
	.long 0x7f083880                                           // 00000029B230: 7F083880
	v_add3_u32 v3, v3, v5, 0x7fff                              // 00000029B234: D6550003 03FE0B03 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029B240: BF870093
	.long 0x7e083982                                           // 00000029B244: 7E083982
	v_and_or_b32 v2, 0xffff0000, v3, v4                        // 00000029B248: D6570002 041206FF FFFF0000
	ds_store_b32 v23, v2                                       // 00000029B254: D8340000 00000217
	v_cvt_f32_ubyte0_e32 v2, s22                               // 00000029B25C: 7E042216
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029B260: BF870291
	v_rcp_iflag_f32_e32 v2, v2                                 // 00000029B264: 7E045702
	v_readfirstlane_b32 s21, v2                                // 00000029B268: 7E2A0502
	s_waitcnt lgkmcnt(0)                                       // 00000029B26C: BF89FC07
	s_barrier                                                  // 00000029B270: BFBD0000
	buffer_gl0_inv                                             // 00000029B274: E0AC0000 00000000
	s_load_b32 s20, s[16:17], 0x40                             // 00000029B27C: F4000508 F8000040
	s_waitcnt lgkmcnt(0)                                       // 00000029B284: BF89FC07
	s_sub_i32 s0, s2, s20                                      // 00000029B288: 81801402
	s_mul_f32 s20, s21, 0x4f7ffffe                             // 00000029B28C: A214FF15 4F7FFFFE
	s_ashr_i32 s1, s0, 31                                      // 00000029B294: 86019F00
	s_and_b32 s3, s3, exec_lo                                  // 00000029B298: 8B037E03
	s_cselect_b32 s3, 4, 0                                     // 00000029B29C: 98038084
	s_cvt_u32_f32 s25, s20                                     // 00000029B2A0: BE996714
	s_lshl_b64 s[0:1], s[0:1], s3                              // 00000029B2A4: 84800300
	s_add_u32 s6, s18, s6                                      // 00000029B2A8: 80060612
	s_addc_u32 s7, s19, s7                                     // 00000029B2AC: 82070713
	s_ashr_i32 s3, s15, 31                                     // 00000029B2B0: 86039F0F
	.long 0xd7000011                                           // 00000029B2B4: D7000011
	v_cndmask_b32_e32 v1, s0, v25, vcc_lo                      // 00000029B2B8: 02023200
	s_lshr_b32 s3, s3, 27                                      // 00000029B2BC: 85039B03
	v_add_co_ci_u32_e64 v18, null, s1, 0, s0                   // 00000029B2C0: D5207C12 00010001
	s_add_u32 s20, s14, s3                                     // 00000029B2C8: 8014030E
	s_addc_u32 s21, s15, 0                                     // 00000029B2CC: 8215800F
	s_sub_i32 s3, 0, s22                                       // 00000029B2D0: 81831680
	s_lshr_b64 s[20:21], s[20:21], 5                           // 00000029B2D4: 85948514
	s_mul_i32 s3, s3, s25                                      // 00000029B2D8: 96031903
	s_add_i32 s21, s24, s20                                    // 00000029B2DC: 81151418
	s_mul_hi_u32 s3, s25, s3                                   // 00000029B2E0: 96830319
	s_abs_i32 s26, s21                                         // 00000029B2E4: BE9A1515
	s_add_i32 s25, s25, s3                                     // 00000029B2E8: 81190319
	s_ashr_i32 s21, s21, 31                                    // 00000029B2EC: 86159F15
	s_mul_hi_u32 s3, s26, s25                                  // 00000029B2F0: 9683191A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000029B2F4: BF8704B9
	s_mul_i32 s23, s3, s22                                     // 00000029B2F8: 96171603
	s_add_i32 s25, s3, 1                                       // 00000029B2FC: 81198103
	s_sub_i32 s23, s26, s23                                    // 00000029B300: 8197171A
	s_sub_i32 s26, s23, s22                                    // 00000029B304: 819A1617
	s_cmp_ge_u32 s23, s22                                      // 00000029B308: BF091617
	s_cselect_b32 s0, s25, s3                                  // 00000029B30C: 98000319
	s_cselect_b32 s1, s26, s23                                 // 00000029B310: 9801171A
	s_add_i32 s3, s0, 1                                        // 00000029B314: 81038100
	s_cmp_ge_u32 s1, s22                                       // 00000029B318: BF091601
	s_cselect_b32 s1, s3, s0                                   // 00000029B31C: 98010003
	.long 0xd4540000                                           // 00000029B320: D4540000
	v_cndmask_b32_e32 v1, s10, v17, vcc_lo                     // 00000029B324: 0202220A
	s_xor_b32 s1, s1, s21                                      // 00000029B328: 8D011501
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000029B32C: BF870499
	s_sub_i32 s3, s1, s21                                      // 00000029B330: 81831501
	.long 0xd72c000d                                           // 00000029B334: D72C000D
	v_cndmask_b32_e32 v1, s3, v26, vcc_lo                      // 00000029B338: 02023403
	v_cndmask_b32_e64 v9, 0, v18, s0                           // 00000029B33C: D5010009 00022480
	v_cndmask_b32_e64 v10, 0, v17, s0                          // 00000029B344: D501000A 00022280
	s_cmpk_lt_i32 s3, 0x81                                     // 00000029B34C: B3830081
	s_cselect_b32 s1, -1, 0                                    // 00000029B350: 980180C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029B354: BF870112
	.long 0xd72c0002                                           // 00000029B358: D72C0002
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 00000029B35C: 02001109
	.long 0xd72c0003                                           // 00000029B360: D72C0003
	v_cndmask_b32_e32 v0, v10, v9, vcc_lo                      // 00000029B364: 0200130A
	v_add_nc_u32_e32 v1, s3, v13                               // 00000029B368: 4A021A03
	v_mad_u64_u32 v[19:20], null, v10, s8, s[6:7]              // 00000029B36C: D6FE7C13 0018110A
	.long 0xd4510008                                           // 00000029B374: D4510008
	v_cndmask_b32_e32 v0, s10, v137, vcc_lo                    // 00000029B378: 0201120A
	s_cmpk_gt_i32 s3, 0x80                                     // 00000029B37C: B2830080
	v_min_i32_e32 v27, s20, v1                                 // 00000029B380: 22360214
	v_dual_mov_b32 v1, 0 :: v_dual_add_nc_u32 v28, v13, v24    // 00000029B384: CA200080 011C310D
	s_cselect_b32 s6, -1, 0                                    // 00000029B38C: 980680C1
	v_add3_u32 v29, v2, v20, v3                                // 00000029B390: D655001D 040E2902
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000029B398: 8B6A067E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000029B39C: BF870002
	.long 0xd4410003                                           // 00000029B3A0: D4410003
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                     // 00000029B3A4: 0202371C
	s_cbranch_vccnz 151                                        // 00000029B3A8: BFA40097 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x508>
	s_and_saveexec_b32 s7, s3                                  // 00000029B3AC: BE872003
	s_cbranch_execz 11                                         // 00000029B3B0: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2e0>
	v_lshlrev_b32_e32 v1, 1, v28                               // 00000029B3B4: 30023881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029B3B8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000029B3BC: 3404029F
	.long 0xd7006a01                                           // 00000029B3C0: D7006A01
	v_cndmask_b32_e32 v1, v19, v1, vcc_lo                      // 00000029B3C4: 02020313
	v_add_co_ci_u32_e64 v2, null, v29, v2, vcc_lo              // 00000029B3C8: D5207C02 01AA051D
	global_load_d16_b16 v1, v[1:2], off                        // 00000029B3D0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000029B3D8: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 00000029B3DC: 7E021701
	s_or_b32 exec_lo, exec_lo, s7                              // 00000029B3E0: 8C7E077E
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v4, 16, v28      // 00000029B3E4: CA200080 03043890
	v_mov_b32_e32 v2, 0                                        // 00000029B3EC: 7E040280
	s_mov_b32 s3, exec_lo                                      // 00000029B3F0: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000029B3F4: BF870002
	.long 0xd4c1007e                                           // 00000029B3F8: D4C1007E
	v_cndmask_b32_e32 v1, v4, v27, vcc_lo                      // 00000029B3FC: 02023704
	s_cbranch_execz 11                                         // 00000029B400: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x330>
	v_lshlrev_b32_e32 v2, 1, v4                                // 00000029B404: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029B408: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v2                               // 00000029B40C: 340A049F
	.long 0xd7006a04                                           // 00000029B410: D7006A04
	v_cndmask_b32_e32 v1, v19, v2, vcc_lo                      // 00000029B414: 02020513
	v_add_co_ci_u32_e64 v5, null, v29, v5, vcc_lo              // 00000029B418: D5207C05 01AA0B1D
	global_load_d16_b16 v2, v[4:5], off                        // 00000029B420: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 00000029B428: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 00000029B42C: 7E041702
	s_or_b32 exec_lo, exec_lo, s3                              // 00000029B430: 8C7E037E
	v_add_nc_u32_e32 v4, 32, v28                               // 00000029B434: 4A0838A0
	s_mov_b32 s3, exec_lo                                      // 00000029B438: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029B43C: BF870001
	.long 0xd4c1007e                                           // 00000029B440: D4C1007E
	v_cndmask_b32_e32 v1, v4, v27, vcc_lo                      // 00000029B444: 02023704
	s_cbranch_execz 11                                         // 00000029B448: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x378>
	v_lshlrev_b32_e32 v3, 1, v4                                // 00000029B44C: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029B450: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000029B454: 3408069F
	.long 0xd7006a03                                           // 00000029B458: D7006A03
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 00000029B45C: 02020713
	v_add_co_ci_u32_e64 v4, null, v29, v4, vcc_lo              // 00000029B460: D5207C04 01AA091D
	global_load_d16_b16 v3, v[3:4], off                        // 00000029B468: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000029B470: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 00000029B474: 7E061703
	s_or_b32 exec_lo, exec_lo, s3                              // 00000029B478: 8C7E037E
	v_dual_mov_b32 v5, 0 :: v_dual_add_nc_u32 v6, 48, v28      // 00000029B47C: CA200080 050638B0
	v_mov_b32_e32 v4, 0                                        // 00000029B484: 7E080280
	s_mov_b32 s3, exec_lo                                      // 00000029B488: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000029B48C: BF870002
	.long 0xd4c1007e                                           // 00000029B490: D4C1007E
	v_cndmask_b32_e32 v1, v6, v27, vcc_lo                      // 00000029B494: 02023706
	s_cbranch_execz 11                                         // 00000029B498: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x3c8>
	v_lshlrev_b32_e32 v4, 1, v6                                // 00000029B49C: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029B4A0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v4                               // 00000029B4A4: 340E089F
	.long 0xd7006a06                                           // 00000029B4A8: D7006A06
	v_cndmask_b32_e32 v1, v19, v4, vcc_lo                      // 00000029B4AC: 02020913
	v_add_co_ci_u32_e64 v7, null, v29, v7, vcc_lo              // 00000029B4B0: D5207C07 01AA0F1D
	global_load_d16_b16 v4, v[6:7], off                        // 00000029B4B8: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 00000029B4C0: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 00000029B4C4: 7E081704
	s_or_b32 exec_lo, exec_lo, s3                              // 00000029B4C8: 8C7E037E
	v_add_nc_u32_e32 v6, 64, v28                               // 00000029B4CC: 4A0C38C0
	s_mov_b32 s3, exec_lo                                      // 00000029B4D0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029B4D4: BF870001
	.long 0xd4c1007e                                           // 00000029B4D8: D4C1007E
	v_cndmask_b32_e32 v1, v6, v27, vcc_lo                      // 00000029B4DC: 02023706
	s_cbranch_execz 11                                         // 00000029B4E0: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x410>
	v_lshlrev_b32_e32 v5, 1, v6                                // 00000029B4E4: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029B4E8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v5                               // 00000029B4EC: 340C0A9F
	.long 0xd7006a05                                           // 00000029B4F0: D7006A05
	v_cndmask_b32_e32 v1, v19, v5, vcc_lo                      // 00000029B4F4: 02020B13
	v_add_co_ci_u32_e64 v6, null, v29, v6, vcc_lo              // 00000029B4F8: D5207C06 01AA0D1D
	global_load_d16_b16 v5, v[5:6], off                        // 00000029B500: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 00000029B508: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 00000029B50C: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s3                              // 00000029B510: 8C7E037E
	v_dual_mov_b32 v7, 0 :: v_dual_add_nc_u32 v8, 0x50, v28    // 00000029B514: CA200080 070838FF 00000050
	v_mov_b32_e32 v6, 0                                        // 00000029B520: 7E0C0280
	s_mov_b32 s3, exec_lo                                      // 00000029B524: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000029B528: BF870002
	.long 0xd4c1007e                                           // 00000029B52C: D4C1007E
	v_cndmask_b32_e32 v1, v8, v27, vcc_lo                      // 00000029B530: 02023708
	s_cbranch_execz 11                                         // 00000029B534: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x464>
	v_lshlrev_b32_e32 v6, 1, v8                                // 00000029B538: 300C1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029B53C: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v6                               // 00000029B540: 34100C9F
	.long 0xd7006a0b                                           // 00000029B544: D7006A0B
	v_cndmask_b32_e32 v1, v19, v6, vcc_lo                      // 00000029B548: 02020D13
	v_add_co_ci_u32_e64 v12, null, v29, v8, vcc_lo             // 00000029B54C: D5207C0C 01AA111D
	global_load_d16_b16 v6, v[11:12], off                      // 00000029B554: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 00000029B55C: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 00000029B560: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s3                              // 00000029B564: 8C7E037E
	v_add_nc_u32_e32 v8, 0x60, v28                             // 00000029B568: 4A1038FF 00000060
	s_mov_b32 s3, exec_lo                                      // 00000029B570: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029B574: BF870001
	.long 0xd4c1007e                                           // 00000029B578: D4C1007E
	v_cndmask_b32_e32 v1, v8, v27, vcc_lo                      // 00000029B57C: 02023708
	s_cbranch_execz 11                                         // 00000029B580: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x4b0>
	v_lshlrev_b32_e32 v7, 1, v8                                // 00000029B584: 300E1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029B588: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v7                               // 00000029B58C: 34100E9F
	.long 0xd7006a07                                           // 00000029B590: D7006A07
	v_cndmask_b32_e32 v1, v19, v7, vcc_lo                      // 00000029B594: 02020F13
	v_add_co_ci_u32_e64 v8, null, v29, v8, vcc_lo              // 00000029B598: D5207C08 01AA111D
	global_load_d16_b16 v7, v[7:8], off                        // 00000029B5A0: DC820000 077C0007
	s_waitcnt vmcnt(0)                                         // 00000029B5A8: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 00000029B5AC: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s3                              // 00000029B5B0: 8C7E037E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0x70, v28   // 00000029B5B4: CA200080 080A38FF 00000070
	s_mov_b32 s3, exec_lo                                      // 00000029B5C0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029B5C4: BF870001
	.long 0xd4c1007e                                           // 00000029B5C8: D4C1007E
	v_cndmask_b32_e32 v1, v11, v27, vcc_lo                     // 00000029B5CC: 0202370B
	s_cbranch_execz 11                                         // 00000029B5D0: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x500>
	v_lshlrev_b32_e32 v8, 1, v11                               // 00000029B5D4: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029B5D8: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 00000029B5DC: 3418109F
	.long 0xd7006a0b                                           // 00000029B5E0: D7006A0B
	v_cndmask_b32_e32 v1, v19, v8, vcc_lo                      // 00000029B5E4: 02021113
	v_add_co_ci_u32_e64 v12, null, v29, v12, vcc_lo            // 00000029B5E8: D5207C0C 01AA191D
	global_load_d16_b16 v8, v[11:12], off                      // 00000029B5F0: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 00000029B5F8: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 00000029B5FC: 7E101708
	s_or_b32 exec_lo, exec_lo, s3                              // 00000029B600: 8C7E037E
	s_branch 9                                                 // 00000029B604: BFA00009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x52c>
	v_mov_b32_e32 v1, 0                                        // 00000029B608: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029B60C: BF870001
	v_mov_b32_e32 v2, v1                                       // 00000029B610: 7E040301
	v_mov_b32_e32 v3, v1                                       // 00000029B614: 7E060301
	v_mov_b32_e32 v4, v1                                       // 00000029B618: 7E080301
	v_mov_b32_e32 v5, v1                                       // 00000029B61C: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 00000029B620: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000029B624: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 00000029B628: 7E100301
	s_add_u32 s4, s18, s4                                      // 00000029B62C: 80040412
	s_addc_u32 s5, s19, s5                                     // 00000029B630: 82050513
	s_lshr_b32 s3, s15, 31                                     // 00000029B634: 85039F0F
	v_cndmask_b32_e64 v31, 0, 1, s6                            // 00000029B638: D501001F 00190280
	s_add_u32 s18, s14, s3                                     // 00000029B640: 8012030E
	s_addc_u32 s19, s15, 0                                     // 00000029B644: 8213800F
	.long 0xd4410003                                           // 00000029B648: D4410003
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                     // 00000029B64C: 0202371C
	s_ashr_i64 s[18:19], s[18:19], 1                           // 00000029B650: 86928112
	v_mov_b32_e32 v30, 0                                       // 00000029B654: 7E3C0280
	v_mad_u64_u32 v[20:21], null, v10, s18, s[4:5]             // 00000029B658: D6FE7C14 0010250A
	.long 0xd72c000c                                           // 00000029B660: D72C000C
	v_cndmask_b32_e32 v0, v10, v19, vcc_lo                     // 00000029B664: 0200270A
	.long 0xd72c000e                                           // 00000029B668: D72C000E
	v_cndmask_b32_e32 v0, v9, v18, vcc_lo                      // 00000029B66C: 02002509
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v38, 0              // 00000029B670: CA100080 09260080
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v10, 0             // 00000029B678: CA100080 0B0A0080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029B680: BF870003
	v_add3_u32 v32, v14, v21, v12                              // 00000029B684: D6550020 04322B0E
	v_mov_b32_e32 v12, 0                                       // 00000029B68C: 7E180280
	s_and_saveexec_b32 s4, s3                                  // 00000029B690: BE842003
	s_cbranch_execz 22                                         // 00000029B694: BFA50016 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x5f0>
	v_dual_mov_b32 v38, 0 :: v_dual_lshlrev_b32 v9, 4, v28     // 00000029B698: CA220080 26083884
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029B6A0: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000029B6A4: 3414129F
	.long 0xd7006a09                                           // 00000029B6A8: D7006A09
	v_cndmask_b32_e32 v1, v20, v9, vcc_lo                      // 00000029B6AC: 02021314
	v_add_co_ci_u32_e64 v10, null, v32, v10, vcc_lo            // 00000029B6B0: D5207C0A 01AA1520
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 00000029B6B8: 916A067E
	global_load_b128 v[9:12], v[9:10], off                     // 00000029B6BC: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 00000029B6C4: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x5f0>
	v_lshlrev_b32_e32 v14, 1, v28                              // 00000029B6C8: 301C3881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029B6CC: BF870091
	.long 0xd7006a0e                                           // 00000029B6D0: D7006A0E
	v_cndmask_b32_e32 v1, v19, v14, vcc_lo                     // 00000029B6D4: 02021D13
	v_add_co_ci_u32_e64 v15, null, 0, v29, vcc_lo              // 00000029B6D8: D5207C0F 01AA3A80
	global_load_d16_b16 v14, v[14:15], off                     // 00000029B6E0: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 00000029B6E8: BF8903F7
	v_cvt_f32_f16_e32 v38, v14                                 // 00000029B6EC: 7E4C170E
	s_or_b32 exec_lo, exec_lo, s4                              // 00000029B6F0: 8C7E047E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v33, 0             // 00000029B6F4: CA100080 22200080
	s_and_saveexec_b32 s9, s3                                  // 00000029B6FC: BE892003
	s_cbranch_execz 341                                        // 00000029B700: BFA50155 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xb58>
	v_dual_mov_b32 v33, 0 :: v_dual_lshlrev_b32 v14, 5, v24    // 00000029B704: CA220080 210E3085
	v_dual_mov_b32 v34, 0 :: v_dual_add_nc_u32 v15, 16, v28    // 00000029B70C: CA200080 220E3890
	s_lshl_b64 s[4:5], s[14:15], 2                             // 00000029B714: 8484820E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029B718: BF870112
	v_lshl_add_u32 v21, v13, 5, v14                            // 00000029B71C: D6460015 04390B0D
	v_dual_mov_b32 v30, 0 :: v_dual_lshlrev_b32 v35, 4, v15    // 00000029B724: CA220080 1E221E84
	v_dual_mov_b32 v37, v38 :: v_dual_lshlrev_b32 v36, 1, v15  // 00000029B72C: CA220126 25241E81
	s_mov_b32 s18, 0                                           // 00000029B734: BE920080
	s_lshl_b64 s[6:7], s[14:15], 1                             // 00000029B738: 8486810E
	s_branch 290                                               // 00000029B73C: BFA00122 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xac8>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000029B740: 8C7E0E7E
	v_ashrrev_i32_e32 v22, 31, v21                             // 00000029B744: 342C2A9F
	v_cndmask_b32_e64 v87, v38, v1, s1                         // 00000029B748: D5010057 00060326
	v_lshrrev_b32_e32 v38, 6, v9                               // 00000029B750: 324C1286
	v_lshrrev_b32_e32 v88, 14, v9                              // 00000029B754: 32B0128E
	v_lshrrev_b32_e32 v93, 6, v11                              // 00000029B758: 32BA1686
	.long 0xd73c0027                                           // 00000029B75C: D73C0027
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 00000029B760: 02022A81
	v_and_b32_e32 v22, 0xff, v9                                // 00000029B764: 362C12FF 000000FF
	v_and_b32_e32 v38, 0x3fc, v38                              // 00000029B76C: 364C4CFF 000003FC
	v_and_b32_e32 v88, 0x3fc, v88                              // 00000029B774: 36B0B0FF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 00000029B77C: 32121296
	v_and_b32_e32 v89, 0xff, v10                               // 00000029B780: 36B214FF 000000FF
	.long 0xd7006a4b                                           // 00000029B788: D7006A4B
	v_cndmask_b32_e32 v1, s12, v39, vcc_lo                     // 00000029B78C: 02024E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029B790: BF8701A1
	v_add_co_ci_u32_e64 v76, null, s13, v40, vcc_lo            // 00000029B794: D5207C4C 01AA500D
	v_lshlrev_b32_e32 v22, 2, v22                              // 00000029B79C: 302C2C82
	.long 0xd7006a4f                                           // 00000029B7A0: D7006A4F
	v_cndmask_b32_e32 v0, v75, v6, vcc_lo                      // 00000029B7A4: 02000D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029B7A8: BF8700A1
	v_add_co_ci_u32_e64 v80, null, s7, v76, vcc_lo             // 00000029B7AC: D5207C50 01AA9807
	.long 0xd7006a53                                           // 00000029B7B4: D7006A53
	v_cndmask_b32_e32 v0, v75, v4, vcc_lo                      // 00000029B7B8: 0200094B
	v_add_co_ci_u32_e64 v84, null, s5, v76, vcc_lo             // 00000029B7BC: D5207C54 01AA9805
	s_clause 0xb                                               // 00000029B7C4: BF85000B
	global_load_b128 v[39:42], v[75:76], off                   // 00000029B7C8: DC5E0000 277C004B
	global_load_b128 v[43:46], v[79:80], off                   // 00000029B7D0: DC5E0000 2B7C004F
	global_load_b128 v[47:50], v[83:84], off                   // 00000029B7D8: DC5E0000 2F7C0053
	global_load_b128 v[51:54], v[75:76], off offset:16         // 00000029B7E0: DC5E0010 337C004B
	global_load_b128 v[55:58], v[79:80], off offset:16         // 00000029B7E8: DC5E0010 377C004F
	global_load_b128 v[59:62], v[83:84], off offset:16         // 00000029B7F0: DC5E0010 3B7C0053
	global_load_b128 v[63:66], v[75:76], off offset:32         // 00000029B7F8: DC5E0020 3F7C004B
	global_load_b128 v[67:70], v[79:80], off offset:32         // 00000029B800: DC5E0020 437C004F
	global_load_b128 v[71:74], v[83:84], off offset:32         // 00000029B808: DC5E0020 477C0053
	global_load_b128 v[75:78], v[75:76], off offset:48         // 00000029B810: DC5E0030 4B7C004B
	global_load_b128 v[79:82], v[79:80], off offset:48         // 00000029B818: DC5E0030 4F7C004F
	global_load_b128 v[83:86], v[83:84], off offset:48         // 00000029B820: DC5E0030 537C0053
	ds_load_b32 v22, v22                                       // 00000029B828: D8D80000 16000016
	ds_load_b32 v38, v38                                       // 00000029B830: D8D80000 26000026
	ds_load_b32 v88, v88                                       // 00000029B838: D8D80000 58000058
	v_lshrrev_b32_e32 v90, 6, v10                              // 00000029B840: 32B41486
	v_lshrrev_b32_e32 v91, 14, v10                             // 00000029B844: 32B6148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 00000029B848: 32141496
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000029B84C: 361212FF 000003FC
	v_lshrrev_b32_e32 v94, 14, v11                             // 00000029B854: 32BC168E
	v_and_b32_e32 v95, 0xff, v12                               // 00000029B858: 36BE18FF 000000FF
	v_and_b32_e32 v91, 0x3fc, v91                              // 00000029B860: 36B6B6FF 000003FC
	v_lshrrev_b32_e32 v96, 14, v12                             // 00000029B868: 32C0188E
	v_add_nc_u32_e32 v36, 32, v36                              // 00000029B86C: 4A4848A0
	s_and_b32 s3, exec_lo, s3                                  // 00000029B870: 8B03037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029B874: BF870009
	s_or_b32 s18, s3, s18                                      // 00000029B878: 8C121203
	s_waitcnt vmcnt(11) lgkmcnt(2)                             // 00000029B87C: BF892C27
	v_dot2_f32_bf16 v39, v39, v22, 0                           // 00000029B880: CC1A4027 1A022D27
	s_waitcnt vmcnt(10)                                        // 00000029B888: BF892BF7
	v_dot2_f32_bf16 v43, v43, v22, 0                           // 00000029B88C: CC1A402B 1A022D2B
	s_waitcnt vmcnt(9)                                         // 00000029B894: BF8927F7
	v_dot2_f32_bf16 v22, v47, v22, 0                           // 00000029B898: CC1A4016 1A022D2F
	v_lshrrev_b32_e32 v47, 6, v12                              // 00000029B8A0: 325E1886
	v_lshrrev_b32_e32 v12, 22, v12                             // 00000029B8A4: 32181896
	s_waitcnt lgkmcnt(1)                                       // 00000029B8A8: BF89FC17
	v_dot2_f32_bf16 v39, v40, v38, v39                         // 00000029B8AC: CC1A4027 1C9E4D28
	v_dot2_f32_bf16 v40, v44, v38, v43                         // 00000029B8B4: CC1A4028 1CAE4D2C
	v_dot2_f32_bf16 v22, v48, v38, v22                         // 00000029B8BC: CC1A4016 1C5A4D30
	v_and_b32_e32 v43, 0x3fc, v94                              // 00000029B8C4: 3656BCFF 000003FC
	v_and_b32_e32 v44, 0x3fc, v96                              // 00000029B8CC: 3658C0FF 000003FC
	s_waitcnt lgkmcnt(0)                                       // 00000029B8D4: BF89FC07
	v_dot2_f32_bf16 v39, v41, v88, v39                         // 00000029B8D8: CC1A4027 1C9EB129
	v_dot2_f32_bf16 v40, v45, v88, v40                         // 00000029B8E0: CC1A4028 1CA2B12D
	v_cndmask_b32_e64 v45, v7, v8, s1                          // 00000029B8E8: D501002D 00061107
	v_and_b32_e32 v92, 0xff, v11                               // 00000029B8F0: 36B816FF 000000FF
	v_and_b32_e32 v41, 0x3fc, v93                              // 00000029B8F8: 3652BAFF 000003FC
	v_and_b32_e32 v90, 0x3fc, v90                              // 00000029B900: 36B4B4FF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 00000029B908: 361414FF 000003FC
	v_dot2_f32_bf16 v22, v49, v88, v22                         // 00000029B910: CC1A4016 1C5AB131
	v_lshlrev_b32_e32 v38, 2, v92                              // 00000029B918: 304CB882
	ds_load_b32 v41, v41                                       // 00000029B91C: D8D80000 29000029
	v_lshlrev_b32_e32 v89, 2, v89                              // 00000029B924: 30B2B282
	v_lshrrev_b32_e32 v11, 22, v11                             // 00000029B928: 32161696
	v_and_b32_e32 v12, 0x3fc, v12                              // 00000029B92C: 361818FF 000003FC
	ds_load_b32 v38, v38                                       // 00000029B934: D8D80000 26000026
	ds_load_b32 v9, v9                                         // 00000029B93C: D8D80000 09000009
	ds_load_b32 v89, v89                                       // 00000029B944: D8D80000 59000059
	ds_load_b32 v90, v90                                       // 00000029B94C: D8D80000 5A00005A
	ds_load_b32 v91, v91                                       // 00000029B954: D8D80000 5B00005B
	ds_load_b32 v10, v10                                       // 00000029B95C: D8D80000 0A00000A
	s_waitcnt lgkmcnt(4)                                       // 00000029B964: BF89FC47
	v_dot2_f32_bf16 v39, v42, v9, v39                          // 00000029B968: CC1A4027 1C9E132A
	v_dot2_f32_bf16 v40, v46, v9, v40                          // 00000029B970: CC1A4028 1CA2132E
	v_dot2_f32_bf16 v9, v50, v9, v22                           // 00000029B978: CC1A4009 1C5A1332
	ds_load_b32 v46, v43                                       // 00000029B980: D8D80000 2E00002B
	v_cndmask_b32_e64 v43, v5, v6, s1                          // 00000029B988: D501002B 00060D05
	s_waitcnt vmcnt(8) lgkmcnt(4)                              // 00000029B990: BF892047
	v_dot2_f32_bf16 v39, v51, v89, v39                         // 00000029B994: CC1A4027 1C9EB333
	s_waitcnt vmcnt(7)                                         // 00000029B99C: BF891FF7
	v_dot2_f32_bf16 v40, v55, v89, v40                         // 00000029B9A0: CC1A4028 1CA2B337
	s_waitcnt vmcnt(6)                                         // 00000029B9A8: BF891BF7
	v_dot2_f32_bf16 v9, v59, v89, v9                           // 00000029B9AC: CC1A4009 1C26B33B
	v_and_b32_e32 v11, 0x3fc, v11                              // 00000029B9B4: 361616FF 000003FC
	v_lshlrev_b32_e32 v22, 2, v95                              // 00000029B9BC: 302CBE82
	s_waitcnt lgkmcnt(3)                                       // 00000029B9C0: BF89FC37
	v_dot2_f32_bf16 v39, v52, v90, v39                         // 00000029B9C4: CC1A4027 1C9EB534
	v_dot2_f32_bf16 v40, v56, v90, v40                         // 00000029B9CC: CC1A4028 1CA2B538
	v_dot2_f32_bf16 v9, v60, v90, v9                           // 00000029B9D4: CC1A4009 1C26B53C
	v_and_b32_e32 v42, 0x3fc, v47                              // 00000029B9DC: 36545EFF 000003FC
	s_waitcnt lgkmcnt(2)                                       // 00000029B9E4: BF89FC27
	v_dot2_f32_bf16 v39, v53, v91, v39                         // 00000029B9E8: CC1A4027 1C9EB735
	v_dot2_f32_bf16 v40, v57, v91, v40                         // 00000029B9F0: CC1A4028 1CA2B739
	v_dot2_f32_bf16 v9, v61, v91, v9                           // 00000029B9F8: CC1A4009 1C26B73D
	s_waitcnt lgkmcnt(1)                                       // 00000029BA00: BF89FC17
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029BA04: BF870193
	v_dot2_f32_bf16 v39, v54, v10, v39                         // 00000029BA08: CC1A4027 1C9E1536
	v_dot2_f32_bf16 v40, v58, v10, v40                         // 00000029BA10: CC1A4028 1CA2153A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029BA18: BF870003
	v_dot2_f32_bf16 v9, v62, v10, v9                           // 00000029BA1C: CC1A4009 1C26153E
	ds_load_b32 v10, v11                                       // 00000029BA24: D8D80000 0A00000B
	ds_load_b32 v11, v22                                       // 00000029BA2C: D8D80000 0B000016
	ds_load_b32 v22, v42                                       // 00000029BA34: D8D80000 1600002A
	ds_load_b32 v47, v44                                       // 00000029BA3C: D8D80000 2F00002C
	ds_load_b32 v48, v12                                       // 00000029BA44: D8D80000 3000000C
	v_cndmask_b32_e64 v44, v6, v7, s1                          // 00000029BA4C: D501002C 00060F06
	s_waitcnt vmcnt(5)                                         // 00000029BA54: BF8917F7
	v_dot2_f32_bf16 v12, v63, v38, v39                         // 00000029BA58: CC1A400C 1C9E4D3F
	s_waitcnt vmcnt(4)                                         // 00000029BA60: BF8913F7
	v_dot2_f32_bf16 v39, v67, v38, v40                         // 00000029BA64: CC1A4027 1CA24D43
	s_waitcnt vmcnt(3)                                         // 00000029BA6C: BF890FF7
	v_dot2_f32_bf16 v9, v71, v38, v9                           // 00000029BA70: CC1A4009 1C264D47
	v_cndmask_b32_e64 v42, v4, v5, s1                          // 00000029BA78: D501002A 00060B04
	v_cndmask_b32_e64 v40, v2, v3, s1                          // 00000029BA80: D5010028 00060702
	v_dot2_f32_bf16 v7, v64, v41, v12                          // 00000029BA88: CC1A4007 1C325340
	v_dot2_f32_bf16 v12, v68, v41, v39                         // 00000029BA90: CC1A400C 1C9E5344
	v_dot2_f32_bf16 v9, v72, v41, v9                           // 00000029BA98: CC1A4009 1C265348
	v_cndmask_b32_e64 v41, v3, v4, s1                          // 00000029BAA0: D5010029 00060903
	v_cndmask_b32_e64 v39, v1, v2, s1                          // 00000029BAA8: D5010027 00060501
	s_waitcnt lgkmcnt(5)                                       // 00000029BAB0: BF89FC57
	v_dot2_f32_bf16 v5, v65, v46, v7                           // 00000029BAB4: CC1A4005 1C1E5D41
	v_dot2_f32_bf16 v6, v69, v46, v12                          // 00000029BABC: CC1A4006 1C325D45
	v_dot2_f32_bf16 v7, v73, v46, v9                           // 00000029BAC4: CC1A4007 1C265D49
	v_dual_mov_b32 v46, v8 :: v_dual_add_nc_u32 v35, 0x100, v35// 00000029BACC: CA200108 2E2246FF 00000100
	s_waitcnt lgkmcnt(4)                                       // 00000029BAD8: BF89FC47
	v_dot2_f32_bf16 v3, v66, v10, v5                           // 00000029BADC: CC1A4003 1C161542
	v_dot2_f32_bf16 v4, v70, v10, v6                           // 00000029BAE4: CC1A4004 1C1A1546
	v_dot2_f32_bf16 v5, v74, v10, v7                           // 00000029BAEC: CC1A4005 1C1E154A
	v_mov_b32_e32 v12, v16                                     // 00000029BAF4: 7E180310
	v_mov_b32_e32 v10, v14                                     // 00000029BAF8: 7E14030E
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 00000029BAFC: BF890837
	v_dot2_f32_bf16 v1, v75, v11, v3                           // 00000029BB00: CC1A4001 1C0E174B
	s_waitcnt vmcnt(1)                                         // 00000029BB08: BF8907F7
	v_dot2_f32_bf16 v2, v79, v11, v4                           // 00000029BB0C: CC1A4002 1C12174F
	s_waitcnt vmcnt(0)                                         // 00000029BB14: BF8903F7
	v_dot2_f32_bf16 v3, v83, v11, v5                           // 00000029BB18: CC1A4003 1C161753
	v_mov_b32_e32 v11, v15                                     // 00000029BB20: 7E16030F
	v_mov_b32_e32 v9, v13                                      // 00000029BB24: 7E12030D
	s_waitcnt lgkmcnt(2)                                       // 00000029BB28: BF89FC27
	v_dot2_f32_bf16 v1, v76, v22, v1                           // 00000029BB2C: CC1A4001 1C062D4C
	v_dot2_f32_bf16 v2, v80, v22, v2                           // 00000029BB34: CC1A4002 1C0A2D50
	v_dot2_f32_bf16 v3, v84, v22, v3                           // 00000029BB3C: CC1A4003 1C0E2D54
	v_dual_mov_b32 v38, v37 :: v_dual_add_nc_u32 v21, 0x200, v21// 00000029BB44: CA200125 26142AFF 00000200
	s_waitcnt lgkmcnt(1)                                       // 00000029BB50: BF89FC17
	v_dot2_f32_bf16 v1, v77, v47, v1                           // 00000029BB54: CC1A4001 1C065F4D
	v_dot2_f32_bf16 v2, v81, v47, v2                           // 00000029BB5C: CC1A4002 1C0A5F51
	v_dot2_f32_bf16 v3, v85, v47, v3                           // 00000029BB64: CC1A4003 1C0E5F55
	s_waitcnt lgkmcnt(0)                                       // 00000029BB6C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029BB70: BF870193
	v_dot2_f32_bf16 v1, v78, v48, v1                           // 00000029BB74: CC1A4001 1C06614E
	v_dot2_f32_bf16 v2, v82, v48, v2                           // 00000029BB7C: CC1A4002 1C0A6152
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029BB84: BF870193
	v_dot2_f32_bf16 v3, v86, v48, v3                           // 00000029BB88: CC1A4003 1C0E6156
	v_fmac_f32_e32 v33, v87, v1                                // 00000029BB90: 56420357
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029BB94: BF870193
	v_fmac_f32_e32 v34, v87, v2                                // 00000029BB98: 56440557
	v_fmac_f32_e32 v30, v87, v3                                // 00000029BB9C: 563C0757
	v_dual_mov_b32 v1, v39 :: v_dual_mov_b32 v2, v40           // 00000029BBA0: CA100127 01020128
	v_dual_mov_b32 v3, v41 :: v_dual_mov_b32 v4, v42           // 00000029BBA8: CA100129 0304012A
	v_dual_mov_b32 v5, v43 :: v_dual_mov_b32 v6, v44           // 00000029BBB0: CA10012B 0506012C
	v_dual_mov_b32 v7, v45 :: v_dual_mov_b32 v8, v46           // 00000029BBB8: CA10012D 0708012E
	s_and_not1_b32 exec_lo, exec_lo, s18                       // 00000029BBC0: 917E127E
	s_cbranch_execz 35                                         // 00000029BBC4: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xb54>
	s_waitcnt vmcnt(0)                                         // 00000029BBC8: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v28, 16, v28   // 00000029BBCC: CA200109 0D1C3890
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 00000029BBD4: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 00000029BBDC: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029BBE0: BF870003
	.long 0xd4460003                                           // 00000029BBE4: D4460003
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                     // 00000029BBE8: 0202371C
	s_mov_b32 s14, exec_lo                                     // 00000029BBEC: BE8E007E
	.long 0xd4c1007e                                           // 00000029BBF0: D4C1007E
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                     // 00000029BBF4: 0202371C
	s_cbranch_execz 65233                                      // 00000029BBF8: BFA5FED1 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x640>
	v_ashrrev_i32_e32 v14, 31, v35                             // 00000029BBFC: 341C469F
	.long 0xd7006a0d                                           // 00000029BC00: D7006A0D
	v_cndmask_b32_e32 v1, v20, v35, vcc_lo                     // 00000029BC04: 02024714
	v_mov_b32_e32 v37, v38                                     // 00000029BC08: 7E4A0326
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029BC0C: BF870003
	v_add_co_ci_u32_e64 v14, null, v32, v14, vcc_lo            // 00000029BC10: D5207C0E 01AA1D20
	v_cmp_ne_u32_e32 vcc_lo, 1, v31                            // 00000029BC18: 7C9A3E81
	global_load_b128 v[13:16], v[13:14], off                   // 00000029BC1C: DC5E0000 0D7C000D
	s_cbranch_vccnz 65222                                      // 00000029BC24: BFA4FEC6 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x640>
	v_ashrrev_i32_e32 v22, 31, v36                             // 00000029BC28: 342C489F
	.long 0xd7006a27                                           // 00000029BC2C: D7006A27
	v_cndmask_b32_e32 v1, v19, v36, vcc_lo                     // 00000029BC30: 02024913
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029BC34: BF870001
	v_add_co_ci_u32_e64 v40, null, v29, v22, vcc_lo            // 00000029BC38: D5207C28 01AA2D1D
	global_load_d16_b16 v22, v[39:40], off                     // 00000029BC40: DC820000 167C0027
	s_waitcnt vmcnt(0)                                         // 00000029BC48: BF8903F7
	v_cvt_f32_f16_e32 v37, v22                                 // 00000029BC4C: 7E4A1716
	s_branch 65211                                             // 00000029BC50: BFA0FEBB <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x640>
	s_or_b32 exec_lo, exec_lo, s18                             // 00000029BC54: 8C7E127E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029BC58: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 00000029BC5C: 8C7E097E
	.long 0xd71f0001                                           // 00000029BC60: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000029BC64: 020100C1
	.long 0xd44a0001                                           // 00000029BC68: D44A0001
	v_cndmask_b32_e32 v1, 0, v24, vcc_lo                       // 00000029BC6C: 02023080
	s_mov_b32 s3, -1                                           // 00000029BC70: BE8300C1
	v_xor_b32_e32 v2, 8, v1                                    // 00000029BC74: 3A040288
	v_xor_b32_e32 v5, 4, v1                                    // 00000029BC78: 3A0A0284
	v_xor_b32_e32 v8, 2, v1                                    // 00000029BC7C: 3A100282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000029BC80: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000029BC84: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000029BC88: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 00000029BC8C: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 00000029BC90: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000029BC94: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000029BC98: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000029BC9C: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000029BCA0: 30040482
	ds_bpermute_b32 v3, v2, v33                                // 00000029BCA4: DACC0000 03002102
	s_waitcnt lgkmcnt(0)                                       // 00000029BCAC: BF89FC07
	v_add_f32_e32 v3, v33, v3                                  // 00000029BCB0: 06060721
	ds_bpermute_b32 v4, v2, v34                                // 00000029BCB4: DACC0000 04002202
	ds_bpermute_b32 v2, v2, v30                                // 00000029BCBC: DACC0000 02001E02
	ds_bpermute_b32 v6, v5, v3                                 // 00000029BCC4: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 00000029BCCC: 02101101
	s_waitcnt lgkmcnt(2)                                       // 00000029BCD0: BF89FC27
	v_add_f32_e32 v4, v34, v4                                  // 00000029BCD4: 06080922
	s_waitcnt lgkmcnt(1)                                       // 00000029BCD8: BF89FC17
	v_add_f32_e32 v2, v30, v2                                  // 00000029BCDC: 0604051E
	s_waitcnt lgkmcnt(0)                                       // 00000029BCE0: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 00000029BCE4: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 00000029BCE8: DACC0000 07000405
	ds_bpermute_b32 v5, v5, v2                                 // 00000029BCF0: DACC0000 05000205
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000029BCF8: 30101082
	s_waitcnt lgkmcnt(1)                                       // 00000029BCFC: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 00000029BD00: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 00000029BD04: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 00000029BD08: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 00000029BD0C: DACC0000 05000308
	s_waitcnt lgkmcnt(0)                                       // 00000029BD14: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 00000029BD18: 06060B03
	ds_bpermute_b32 v6, v8, v4                                 // 00000029BD1C: DACC0000 06000408
	ds_bpermute_b32 v7, v8, v2                                 // 00000029BD24: DACC0000 07000208
	v_xor_b32_e32 v8, 1, v1                                    // 00000029BD2C: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000029BD30: BF8700C1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000029BD34: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 00000029BD38: 02021101
	s_and_b32 vcc_lo, exec_lo, s8                              // 00000029BD3C: 8B6A087E
	s_waitcnt lgkmcnt(1)                                       // 00000029BD40: BF89FC17
	v_dual_add_f32 v4, v4, v6 :: v_dual_lshlrev_b32 v1, 2, v1  // 00000029BD44: C9220D04 04000282
	s_waitcnt lgkmcnt(0)                                       // 00000029BD4C: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 00000029BD50: 06040F02
	ds_bpermute_b32 v5, v1, v3                                 // 00000029BD54: DACC0000 05000301
	ds_bpermute_b32 v6, v1, v4                                 // 00000029BD5C: DACC0000 06000401
	ds_bpermute_b32 v1, v1, v2                                 // 00000029BD64: DACC0000 01000201
	s_waitcnt lgkmcnt(1)                                       // 00000029BD6C: BF89FC17
	v_dual_add_f32 v8, v3, v5 :: v_dual_add_f32 v7, v4, v6     // 00000029BD70: C9080B03 08060D04
	s_waitcnt lgkmcnt(0)                                       // 00000029BD78: BF89FC07
	v_add_f32_e32 v6, v2, v1                                   // 00000029BD7C: 060C0302
	s_cbranch_vccz 431                                         // 00000029BD80: BFA301AF <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1340>
	s_and_saveexec_b32 s3, s1                                  // 00000029BD84: BE832001
	s_cbranch_execz 11                                         // 00000029BD88: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xcb8>
	v_lshl_or_b32 v1, v25, 4, v26                              // 00000029BD8C: D6560001 04690919
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029BD94: BF870001
	v_mad_u32_u24 v2, v1, 12, 0x400                            // 00000029BD98: D60B0002 03FD1901 00000400
	v_mul_u32_u24_e32 v1, 12, v1                               // 00000029BDA4: 1602028C
	ds_store_2addr_b32 v2, v8, v7 offset1:1                    // 00000029BDA8: D8380100 00070802
	ds_store_b32 v1, v6 offset:1032                            // 00000029BDB0: D8340408 00000601
	s_or_b32 exec_lo, exec_lo, s3                              // 00000029BDB8: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029BDBC: BF870009
	s_mov_b32 s8, exec_lo                                      // 00000029BDC0: BE88007E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000029BDC4: BF890007
	s_barrier                                                  // 00000029BDC8: BFBD0000
	buffer_gl0_inv                                             // 00000029BDCC: E0AC0000 00000000
	v_cmpx_gt_u32_e32 3, v0                                    // 00000029BDD4: 7D980083
	s_cbranch_execz 407                                        // 00000029BDD8: BFA50197 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1338>
	s_load_b32 s3, s[16:17], 0x40                              // 00000029BDDC: F40000C8 F8000040
	s_waitcnt lgkmcnt(0)                                       // 00000029BDE4: BF89FC07
	s_sub_i32 s2, s2, s3                                       // 00000029BDE8: 81820302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000029BDEC: BF870499
	s_ashr_i32 s3, s2, 31                                      // 00000029BDF0: 86039F02
	.long 0xd4530004                                           // 00000029BDF4: D4530004
	v_cndmask_b32_e32 v0, s10, v2, vcc_lo                      // 00000029BDF8: 0200040A
	s_and_b32 vcc_lo, exec_lo, s4                              // 00000029BDFC: 8B6A047E
	s_cbranch_vccnz 397                                        // 00000029BE00: BFA4018D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1338>
	v_add_nc_u32_e32 v5, 0x400, v23                            // 00000029BE04: 4A0A2EFF 00000400
	s_clause 0x1                                               // 00000029BE0C: BF850001
	s_load_b64 s[6:7], s[16:17], 0x38                          // 00000029BE10: F4040188 F8000038
	s_load_b64 s[4:5], s[16:17], 0x8                           // 00000029BE18: F4040108 F8000008
	s_mov_b32 s9, 0                                            // 00000029BE20: BE890080
	s_mov_b32 s13, -1                                          // 00000029BE24: BE8D00C1
	s_mov_b32 s12, 0                                           // 00000029BE28: BE8C0080
	ds_load_2addr_b32 v[1:2], v5 offset1:3                     // 00000029BE2C: D8DC0300 01000005
	ds_load_2addr_b32 v[3:4], v5 offset0:6 offset1:9           // 00000029BE34: D8DC0906 03000005
	ds_load_2addr_b32 v[9:10], v5 offset0:12 offset1:15        // 00000029BE3C: D8DC0F0C 09000005
	s_waitcnt lgkmcnt(0)                                       // 00000029BE44: BF89FC07
	s_cmp_lt_i32 s7, 3                                         // 00000029BE48: BF048307
	v_add_f32_e32 v1, 0, v1                                    // 00000029BE4C: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000029BE50: BF8700B1
	v_add_f32_e32 v11, v1, v2                                  // 00000029BE54: 06160501
	ds_load_2addr_b32 v[1:2], v5 offset0:18 offset1:21         // 00000029BE58: D8DC1512 01000005
	v_add_f32_e32 v3, v11, v3                                  // 00000029BE60: 0606070B
	v_add_f32_e32 v11, v3, v4                                  // 00000029BE64: 06160903
	ds_load_2addr_b32 v[3:4], v5 offset0:24 offset1:27         // 00000029BE68: D8DC1B18 03000005
	v_add_f32_e32 v9, v11, v9                                  // 00000029BE70: 0612130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000029BE74: BF8700C1
	v_add_f32_e32 v11, v9, v10                                 // 00000029BE78: 06161509
	ds_load_2addr_b32 v[9:10], v5 offset0:30 offset1:33        // 00000029BE7C: D8DC211E 09000005
	s_waitcnt lgkmcnt(2)                                       // 00000029BE84: BF89FC27
	v_add_f32_e32 v1, v11, v1                                  // 00000029BE88: 0602030B
	v_add_f32_e32 v1, v1, v2                                   // 00000029BE8C: 06020501
	s_waitcnt lgkmcnt(1)                                       // 00000029BE90: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000029BE94: BF8700C1
	v_add_f32_e32 v3, v1, v3                                   // 00000029BE98: 06060701
	ds_load_2addr_b32 v[1:2], v5 offset0:36 offset1:39         // 00000029BE9C: D8DC2724 01000005
	v_add_f32_e32 v3, v3, v4                                   // 00000029BEA4: 06060903
	s_waitcnt lgkmcnt(1)                                       // 00000029BEA8: BF89FC17
	v_add_f32_e32 v9, v3, v9                                   // 00000029BEAC: 06121303
	ds_load_2addr_b32 v[3:4], v5 offset0:42 offset1:45         // 00000029BEB0: D8DC2D2A 03000005
	v_add_f32_e32 v5, v9, v10                                  // 00000029BEB8: 060A1509
	s_waitcnt lgkmcnt(1)                                       // 00000029BEBC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029BEC0: BF870091
	v_add_f32_e32 v1, v5, v1                                   // 00000029BEC4: 06020305
	v_add_f32_e32 v1, v1, v2                                   // 00000029BEC8: 06020501
	s_waitcnt lgkmcnt(0)                                       // 00000029BECC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029BED0: BF870091
	v_add_f32_e32 v1, v1, v3                                   // 00000029BED4: 06020701
	v_add_f32_e32 v1, v1, v4                                   // 00000029BED8: 06020901
	s_cbranch_scc1 178                                         // 00000029BEDC: BFA200B2 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x10a8>
	s_cmp_gt_i32 s7, 3                                         // 00000029BEE0: BF028307
	s_cbranch_scc0 112                                         // 00000029BEE4: BFA10070 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xfa8>
	s_cmp_gt_i32 s7, 4                                         // 00000029BEE8: BF028407
	s_cbranch_scc0 58                                          // 00000029BEEC: BFA1003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xed8>
	s_cmp_eq_u32 s7, 5                                         // 00000029BEF0: BF068507
	s_mov_b32 s12, -1                                          // 00000029BEF4: BE8C00C1
	s_cbranch_scc0 54                                          // 00000029BEF8: BFA10036 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xed4>
	s_ashr_i32 s14, s2, 31                                     // 00000029BEFC: 860E9F02
	s_load_b64 s[12:13], s[16:17], 0x10                        // 00000029BF00: F4040308 F8000010
	s_lshr_b32 s14, s14, 23                                    // 00000029BF08: 850E970E
	s_lshr_b32 s15, s10, 31                                    // 00000029BF0C: 850F9F0A
	s_add_i32 s14, s2, s14                                     // 00000029BF10: 810E0E02
	s_add_i32 s18, s10, s15                                    // 00000029BF14: 81120F0A
	s_ashr_i32 s14, s14, 9                                     // 00000029BF18: 860E890E
	s_ashr_i32 s18, s18, 1                                     // 00000029BF1C: 86128112
	s_ashr_i32 s15, s14, 31                                    // 00000029BF20: 860F9F0E
	v_mad_i64_i32 v[2:3], null, s18, v0, 0                     // 00000029BF24: D6FF7C02 02020012
	s_lshl_b64 s[14:15], s[14:15], 9                           // 00000029BF2C: 848E890E
	v_bfe_u32 v4, v1, 16, 1                                    // 00000029BF30: D6100004 02052101
	s_sub_u32 s18, s2, s14                                     // 00000029BF38: 80920E02
	s_subb_u32 s19, s3, s15                                    // 00000029BF3C: 82930F03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029BF40: BF870119
	.long 0xd4540014                                           // 00000029BF44: D4540014
	v_cndmask_b32_e32 v0, 0x100, v18, vcc_lo                   // 00000029BF48: 020024FF 00000100
	v_add3_u32 v4, v1, v4, 0x7fff                              // 00000029BF50: D6550004 03FE0901 00007FFF
	.long 0xd73c0002                                           // 00000029BF5C: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 00000029BF60: 02020481
	s_and_b32 s21, s20, exec_lo                                // 00000029BF64: 8B157E14
	s_waitcnt lgkmcnt(0)                                       // 00000029BF68: BF89FC07
	s_cselect_b32 s12, s4, s12                                 // 00000029BF6C: 980C0C04
	s_cselect_b32 s21, s5, s13                                 // 00000029BF70: 98150D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029BF74: BF870091
	.long 0xd7006a02                                           // 00000029BF78: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 00000029BF7C: 0202040C
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo              // 00000029BF80: D5207C03 01AA0615
	s_add_u32 s22, s18, 0xffffff00                             // 00000029BF88: 8016FF12 FFFFFF00
	s_addc_u32 s13, s19, -1                                    // 00000029BF90: 820DC113
	s_and_b32 s20, s20, exec_lo                                // 00000029BF94: 8B147E14
	.long 0xd7006a02                                           // 00000029BF98: D7006A02
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 00000029BF9C: 02001D02
	s_cselect_b32 s13, s19, s13                                // 00000029BFA0: 980D0D13
	s_cselect_b32 s12, s18, s22                                // 00000029BFA4: 980C1612
	v_add_co_ci_u32_e64 v3, null, s15, v3, vcc_lo              // 00000029BFA8: D5207C03 01AA060F
	s_lshl_b64 s[12:13], s[12:13], 1                           // 00000029BFB0: 848C810C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029BFB4: BF870099
	.long 0xd7006a02                                           // 00000029BFB8: D7006A02
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 00000029BFBC: 02001902
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 00000029BFC0: D5207C03 01AA060D
	s_mov_b32 s12, 0                                           // 00000029BFC8: BE8C0080
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000029BFCC: DC960000 007C0402
	s_mov_b32 s13, 0                                           // 00000029BFD4: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029BFD8: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 00000029BFDC: 8B6A0D7E
	s_cbranch_vccz 48                                          // 00000029BFE0: BFA30030 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xfa4>
	v_mul_f32_e32 v2, 0xbfb8aa3b, v1                           // 00000029BFE4: 100402FF BFB8AA3B
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000029BFEC: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029BFF0: BF870291
	v_exp_f32_e32 v2, v2                                       // 00000029BFF4: 7E044B02
	v_add_f32_e32 v5, 1.0, v2                                  // 00000029BFF8: 060A04F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029BFFC: BF870121
	v_div_scale_f32 v9, null, v5, v5, 1.0                      // 00000029C000: D6FC7C09 03CA0B05
	v_div_scale_f32 v11, vcc_lo, 1.0, v5, 1.0                  // 00000029C008: D6FC6A0B 03CA0AF2
	v_rcp_f32_e32 v10, v9                                      // 00000029C010: 7E145509
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C014: BF870095
	v_fma_f32 v2, -v9, v10, 1.0                                // 00000029C018: D6130002 23CA1509
	v_fmac_f32_e32 v10, v2, v10                                // 00000029C020: 56141502
	v_mad_u64_u32 v[2:3], null, s10, v0, 0                     // 00000029C024: D6FE7C02 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029C02C: BF870112
	v_mul_f32_e32 v12, v11, v10                                // 00000029C030: 1018150B
	v_mad_u64_u32 v[3:4], null, s11, v0, v[3:4]                // 00000029C034: D6FE7C03 040E000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C03C: BF870092
	v_fma_f32 v13, -v9, v12, v11                               // 00000029C040: D613000D 242E1909
	v_fmac_f32_e32 v12, v13, v10                               // 00000029C048: 5618150D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029C04C: BF870113
	.long 0xd73c0002                                           // 00000029C050: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 00000029C054: 02020482
	v_fma_f32 v4, -v9, v12, v11                                // 00000029C058: D6130004 242E1909
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029C060: BF870191
	v_div_fmas_f32 v4, v4, v10, v12                            // 00000029C064: D6370004 04321504
	.long 0xd7006a02                                           // 00000029C06C: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000029C070: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029C074: BF870191
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000029C078: D5207C03 01AA0605
	v_div_fixup_f32 v4, v4, v5, 1.0                            // 00000029C080: D6270004 03CA0B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C088: BF870093
	.long 0xd7006a02                                           // 00000029C08C: D7006A02
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 00000029C090: 02001D02
	v_add_co_ci_u32_e64 v3, null, s15, v3, vcc_lo              // 00000029C094: D5207C03 01AA060F
	global_store_b32 v[2:3], v4, off                           // 00000029C09C: DC6A0000 007C0402
	s_mov_b32 s13, 0                                           // 00000029C0A4: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029C0A8: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 00000029C0AC: 8B6A0D7E
	s_cbranch_vccz 60                                          // 00000029C0B0: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x10a4>
	v_bfe_u32 v2, v1, 16, 1                                    // 00000029C0B4: D6100002 02052101
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000029C0BC: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C0C0: BF870091
	v_add3_u32 v2, v1, v2, 0x7fff                              // 00000029C0C4: D6550002 03FE0501 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000029C0D0: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C0D8: BF870091
	v_mul_f32_e32 v2, s6, v2                                   // 00000029C0DC: 10040406
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 00000029C0E0: 100404FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029C0E8: BF870291
	v_exp_f32_e32 v2, v2                                       // 00000029C0EC: 7E044B02
	v_add_f32_e32 v5, 1.0, v2                                  // 00000029C0F0: 060A04F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029C0F4: BF870121
	v_div_scale_f32 v9, null, v5, v5, 1.0                      // 00000029C0F8: D6FC7C09 03CA0B05
	v_div_scale_f32 v11, vcc_lo, 1.0, v5, 1.0                  // 00000029C100: D6FC6A0B 03CA0AF2
	v_rcp_f32_e32 v10, v9                                      // 00000029C108: 7E145509
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C10C: BF870095
	v_fma_f32 v2, -v9, v10, 1.0                                // 00000029C110: D6130002 23CA1509
	v_fmac_f32_e32 v10, v2, v10                                // 00000029C118: 56141502
	v_mad_u64_u32 v[2:3], null, s10, v0, 0                     // 00000029C11C: D6FE7C02 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C124: BF870092
	v_mul_f32_e32 v12, v11, v10                                // 00000029C128: 1018150B
	v_fma_f32 v4, -v9, v12, v11                                // 00000029C12C: D6130004 242E1909
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000029C134: BF870211
	v_fmac_f32_e32 v12, v4, v10                                // 00000029C138: 56181504
	v_mad_u64_u32 v[3:4], null, s11, v0, v[3:4]                // 00000029C13C: D6FE7C03 040E000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029C144: BF870112
	v_fma_f32 v4, -v9, v12, v11                                // 00000029C148: D6130004 242E1909
	.long 0xd73c0002                                           // 00000029C150: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 00000029C154: 02020482
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029C158: BF870112
	v_div_fmas_f32 v4, v4, v10, v12                            // 00000029C15C: D6370004 04321504
	.long 0xd7006a02                                           // 00000029C164: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000029C168: 02020404
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000029C16C: BF870212
	v_div_fixup_f32 v4, v4, v5, 1.0                            // 00000029C170: D6270004 03CA0B04
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000029C178: D5207C03 01AA0605
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029C180: BF870193
	.long 0xd7006a02                                           // 00000029C184: D7006A02
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 00000029C188: 02001D02
	v_add_f32_e32 v4, v4, v4                                   // 00000029C18C: 06080904
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029C190: BF870003
	v_add_co_ci_u32_e64 v3, null, s15, v3, vcc_lo              // 00000029C194: D5207C03 01AA060F
	global_store_b32 v[2:3], v4, off                           // 00000029C19C: DC6A0000 007C0402
	s_mov_b32 s13, 0                                           // 00000029C1A4: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029C1A8: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 00000029C1AC: 8B6A0D7E
	s_cbranch_vccz 72                                          // 00000029C1B0: BFA30048 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x11d4>
	s_cmp_gt_i32 s7, 1                                         // 00000029C1B4: BF028107
	s_mov_b32 s9, -1                                           // 00000029C1B8: BE8900C1
	s_cbranch_scc0 63                                          // 00000029C1BC: BFA1003F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x11bc>
	v_bfe_u32 v2, v1, 16, 1                                    // 00000029C1C0: D6100002 02052101
	s_lshl_b64 s[14:15], s[2:3], 1                             // 00000029C1C8: 848E8102
	s_mov_b32 s9, 0                                            // 00000029C1CC: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C1D0: BF870091
	v_add3_u32 v2, v1, v2, 0x7fff                              // 00000029C1D4: D6550002 03FE0501 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000029C1E0: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C1E8: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 00000029C1EC: 100404FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 00000029C1F4: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C1F8: BF870095
	v_add_f32_e32 v5, 1.0, v2                                  // 00000029C1FC: 060A04F2
	v_div_scale_f32 v4, null, v5, v5, 1.0                      // 00000029C200: D6FC7C04 03CA0B05
	v_div_scale_f32 v10, vcc_lo, 1.0, v5, 1.0                  // 00000029C208: D6FC6A0A 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029C210: BF870292
	v_rcp_f32_e32 v9, v4                                       // 00000029C214: 7E125504
	v_fma_f32 v2, -v4, v9, 1.0                                 // 00000029C218: D6130002 23CA1304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029C220: BF870121
	v_fmac_f32_e32 v9, v2, v9                                  // 00000029C224: 56121302
	v_mad_u64_u32 v[2:3], null, s10, v0, 0                     // 00000029C228: D6FE7C02 0202000A
	v_mul_f32_e32 v11, v10, v9                                 // 00000029C230: 1016130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C234: BF870091
	v_fma_f32 v12, -v4, v11, v10                               // 00000029C238: D613000C 242A1704
	v_fmac_f32_e32 v11, v12, v9                                // 00000029C240: 5616130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029C244: BF870121
	v_fma_f32 v10, -v4, v11, v10                               // 00000029C248: D613000A 242A1704
	v_mad_u64_u32 v[3:4], null, s11, v0, v[3:4]                // 00000029C250: D6FE7C03 040E000B
	v_div_fmas_f32 v4, v10, v9, v11                            // 00000029C258: D6370004 042E130A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029C260: BF870112
	.long 0xd73c0002                                           // 00000029C264: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 00000029C268: 02020481
	v_div_fixup_f32 v4, v4, v5, 1.0                            // 00000029C26C: D6270004 03CA0B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029C274: BF870112
	.long 0xd7006a02                                           // 00000029C278: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000029C27C: 02020404
	v_bfe_u32 v5, v4, 16, 1                                    // 00000029C280: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029C288: BF870194
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000029C28C: D5207C03 01AA0605
	.long 0xd7006a02                                           // 00000029C294: D7006A02
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 00000029C298: 02001D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029C29C: BF870193
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000029C2A0: D6550004 03FE0B04 00007FFF
	v_add_co_ci_u32_e64 v3, null, s15, v3, vcc_lo              // 00000029C2AC: D5207C03 01AA060F
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000029C2B4: DC960000 007C0402
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 00000029C2BC: 916A097E
	s_mov_b32 s9, 0                                            // 00000029C2C0: BE890080
	s_cbranch_vccnz 3                                          // 00000029C2C4: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x11d4>
	s_cmp_lg_u32 s7, 1                                         // 00000029C2C8: BF078107
	s_mov_b32 s9, -1                                           // 00000029C2CC: BE8900C1
	s_cselect_b32 s12, -1, 0                                   // 00000029C2D0: 980C80C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029C2D4: BF8700A1
	v_bfe_u32 v2, v1, 16, 1                                    // 00000029C2D8: D6100002 02052101
	s_and_b32 vcc_lo, exec_lo, s12                             // 00000029C2E0: 8B6A0C7E
	v_add3_u32 v1, v1, v2, 0x7fff                              // 00000029C2E4: D6550001 03FE0501 00007FFF
	s_cbranch_vccz 21                                          // 00000029C2F0: BFA30015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1248>
	v_mad_u64_u32 v[2:3], null, s10, v0, 0                     // 00000029C2F4: D6FE7C02 0202000A
	s_lshl_b64 s[12:13], s[2:3], 1                             // 00000029C2FC: 848C8102
	s_mov_b32 s9, 0                                            // 00000029C300: BE890080
	v_mad_u64_u32 v[3:4], null, s11, v0, v[3:4]                // 00000029C304: D6FE7C03 040E000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C30C: BF870091
	.long 0xd73c0002                                           // 00000029C310: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 00000029C314: 02020481
	.long 0xd7006a02                                           // 00000029C318: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000029C31C: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029C320: BF870111
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000029C324: D5207C03 01AA0605
	.long 0xd7006a02                                           // 00000029C32C: D7006A02
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 00000029C330: 02001902
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029C334: BF870001
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 00000029C338: D5207C03 01AA060D
	global_store_d16_hi_b16 v[2:3], v1, off                    // 00000029C340: DC960000 007C0102
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 00000029C348: 916A097E
	s_cbranch_vccnz 58                                         // 00000029C34C: BFA4003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1338>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029C350: BF8700A1
	v_and_b32_e32 v1, 0xffff0000, v1                           // 00000029C354: 360202FF FFFF0000
	s_lshl_b64 s[2:3], s[2:3], 1                               // 00000029C35C: 84828102
	v_mul_f32_e32 v4, s6, v1                                   // 00000029C360: 10080206
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C364: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v4                           // 00000029C368: 100208FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 00000029C370: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C374: BF870095
	v_add_f32_e32 v5, 1.0, v1                                  // 00000029C378: 060A02F2
	v_div_scale_f32 v3, null, v5, v5, v4                       // 00000029C37C: D6FC7C03 04120B05
	v_div_scale_f32 v10, vcc_lo, v4, v5, v4                    // 00000029C384: D6FC6A0A 04120B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029C38C: BF870292
	v_rcp_f32_e32 v9, v3                                       // 00000029C390: 7E125503
	v_fma_f32 v1, -v3, v9, 1.0                                 // 00000029C394: D6130001 23CA1303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029C39C: BF870121
	v_fmac_f32_e32 v9, v1, v9                                  // 00000029C3A0: 56121301
	v_mad_u64_u32 v[1:2], null, s10, v0, 0                     // 00000029C3A4: D6FE7C01 0202000A
	v_mul_f32_e32 v11, v10, v9                                 // 00000029C3AC: 1016130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C3B0: BF870091
	v_fma_f32 v12, -v3, v11, v10                               // 00000029C3B4: D613000C 242A1703
	v_fmac_f32_e32 v11, v12, v9                                // 00000029C3BC: 5616130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029C3C0: BF870121
	v_fma_f32 v10, -v3, v11, v10                               // 00000029C3C4: D613000A 242A1703
	v_mad_u64_u32 v[2:3], null, s11, v0, v[2:3]                // 00000029C3CC: D6FE7C02 040A000B
	v_div_fmas_f32 v0, v10, v9, v11                            // 00000029C3D4: D6370000 042E130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029C3DC: BF870191
	v_div_fixup_f32 v3, v0, v5, v4                             // 00000029C3E0: D6270003 04120B00
	.long 0xd73c0000                                           // 00000029C3E8: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000029C3EC: 02020281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029C3F0: BF870112
	v_bfe_u32 v2, v3, 16, 1                                    // 00000029C3F4: D6100002 02052103
	.long 0xd7006a00                                           // 00000029C3FC: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 00000029C400: 02020004
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029C404: BF870191
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 00000029C408: D5207C01 01AA0205
	v_add3_u32 v2, v3, v2, 0x7fff                              // 00000029C410: D6550002 03FE0503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C41C: BF870093
	.long 0xd7006a00                                           // 00000029C420: D7006A00
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 00000029C424: 02000500
	v_add_co_ci_u32_e64 v1, null, s3, v1, vcc_lo               // 00000029C428: D5207C01 01AA0203
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000029C430: DC960000 007C0200
	s_or_b32 exec_lo, exec_lo, s8                              // 00000029C438: 8C7E087E
	s_mov_b32 s3, 0                                            // 00000029C43C: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029C440: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000029C444: 8B6A037E
	s_cbranch_vccz 830                                         // 00000029C448: BFA3033E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2044>
	s_and_b32 s0, s1, s0                                       // 00000029C44C: 8B000001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029C450: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000029C454: BE812000
	s_cbranch_execz 826                                        // 00000029C458: BFA5033A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2044>
	v_ashrrev_i32_e32 v0, 31, v18                              // 00000029C45C: 3400249F
	s_clause 0x1                                               // 00000029C460: BF850001
	s_load_b64 s[4:5], s[16:17], 0x8                           // 00000029C464: F4040108 F8000008
	s_load_b64 s[2:3], s[16:17], 0x38                          // 00000029C46C: F4040088 F8000038
	.long 0xd73c0002                                           // 00000029C474: D73C0002
	v_cndmask_b32_e32 v1, 2, v17, vcc_lo                       // 00000029C478: 02022282
	s_mov_b32 s7, -1                                           // 00000029C47C: BE8700C1
	s_mov_b32 s1, 0                                            // 00000029C480: BE810080
	v_lshrrev_b32_e32 v0, 23, v0                               // 00000029C484: 32000097
	s_mov_b32 s6, 0                                            // 00000029C488: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000029C48C: BF8701C1
	.long 0xd7006a04                                           // 00000029C490: D7006A04
	v_cndmask_b32_e32 v1, v17, v0, vcc_lo                      // 00000029C494: 02020111
	.long 0xd73c0000                                           // 00000029C498: D73C0000
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 00000029C49C: 02022281
	s_waitcnt vmcnt(0)                                         // 00000029C4A0: BF8903F7
	v_add_co_ci_u32_e64 v9, null, 0, v18, vcc_lo               // 00000029C4A4: D5207C09 01AA2480
	v_and_b32_e32 v10, 0xfffffe00, v4                          // 00000029C4AC: 361408FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C4B4: BF870093
	.long 0xd7016a00                                           // 00000029C4B8: D7016A00
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000029C4BC: 02020080
	v_sub_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000029C4C0: D5217C01 01AA0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C4C8: BF870093
	.long 0xd7016a04                                           // 00000029C4CC: D7016A04
	v_cndmask_b32_e32 v1, v17, v10, vcc_lo                     // 00000029C4D0: 02021511
	v_sub_co_ci_u32_e64 v5, null, v18, v9, vcc_lo              // 00000029C4D4: D5217C05 01AA1312
	s_waitcnt lgkmcnt(0)                                       // 00000029C4DC: BF89FC07
	.long 0xd7006a02                                           // 00000029C4E0: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000029C4E4: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000029C4E8: BF8700D1
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000029C4EC: D5207C03 01AA0605
	.long 0xd7006a0b                                           // 00000029C4F4: D7006A0B
	v_cndmask_b32_e32 v1, 0xffffff00, v4, vcc_lo               // 00000029C4F8: 020208FF FFFFFF00
	.long 0xd4540000                                           // 00000029C500: D4540000
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 00000029C504: 020208FF 00000100
	v_add_co_ci_u32_e64 v12, null, -1, v5, vcc_lo              // 00000029C50C: D5207C0C 01AA0AC1
	.long 0xd7006a00                                           // 00000029C514: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 00000029C518: 02020102
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 00000029C51C: D5207C01 01AA0303
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029C524: BF870003
	v_cndmask_b32_e64 v5, v12, v5, s0                          // 00000029C528: D5010005 00020B0C
	v_cndmask_b32_e64 v4, v11, v4, s0                          // 00000029C530: D5010004 0002090B
	s_cmp_lt_i32 s3, 3                                         // 00000029C538: BF048303
	s_cbranch_scc1 118                                         // 00000029C53C: BFA20076 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1618>
	s_cmp_gt_i32 s3, 3                                         // 00000029C540: BF028303
	s_cbranch_scc0 70                                          // 00000029C544: BFA10046 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1560>
	s_cmp_gt_i32 s3, 4                                         // 00000029C548: BF028403
	s_cbranch_scc0 34                                          // 00000029C54C: BFA10022 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x14d8>
	s_cmp_eq_u32 s3, 5                                         // 00000029C550: BF068503
	s_mov_b32 s6, -1                                           // 00000029C554: BE8600C1
	s_cbranch_scc0 30                                          // 00000029C558: BFA1001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x14d4>
	s_load_b64 s[6:7], s[16:17], 0x10                          // 00000029C55C: F4040188 F8000010
	v_dual_mov_b32 v11, s4 :: v_dual_mov_b32 v12, s5           // 00000029C564: CA100004 0B0C0005
	v_bfe_u32 v14, v8, 16, 1                                   // 00000029C56C: D610000E 02052108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029C574: BF8701A1
	v_add3_u32 v14, v8, v14, 0x7fff                            // 00000029C578: D655000E 03FE1D08 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 00000029C584: BF89FC07
	v_cndmask_b32_e64 v13, s6, v11, s0                         // 00000029C588: D501000D 00021606
	v_cndmask_b32_e64 v15, s7, v12, s0                         // 00000029C590: D501000F 00021807
	.long 0xd73c000b                                           // 00000029C598: D73C000B
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000029C59C: 02020881
	s_mov_b32 s6, 0                                            // 00000029C5A0: BE860080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C5A4: BF870093
	.long 0xd7006a0d                                           // 00000029C5A8: D7006A0D
	v_cndmask_b32_e32 v1, v13, v10, vcc_lo                     // 00000029C5AC: 0202150D
	v_add_co_ci_u32_e64 v15, null, v15, v9, vcc_lo             // 00000029C5B0: D5207C0F 01AA130F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C5B8: BF870092
	.long 0xd7006a0b                                           // 00000029C5BC: D7006A0B
	v_cndmask_b32_e32 v1, v13, v11, vcc_lo                     // 00000029C5C0: 0202170D
	v_add_co_ci_u32_e64 v12, null, v15, v12, vcc_lo            // 00000029C5C4: D5207C0C 01AA190F
	global_store_d16_hi_b16 v[11:12], v14, off                 // 00000029C5CC: DC960000 007C0E0B
	s_mov_b32 s7, 0                                            // 00000029C5D4: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029C5D8: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000029C5DC: 8B6A077E
	s_cbranch_vccz 30                                          // 00000029C5E0: BFA3001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x155c>
	v_mul_f32_e32 v11, 0xbfb8aa3b, v8                          // 00000029C5E4: 101610FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029C5EC: BF870291
	v_exp_f32_e32 v11, v11                                     // 00000029C5F0: 7E164B0B
	v_add_f32_e32 v11, 1.0, v11                                // 00000029C5F4: 061616F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C5F8: BF870091
	v_div_scale_f32 v12, null, v11, v11, 1.0                   // 00000029C5FC: D6FC7C0C 03CA170B
	v_rcp_f32_e32 v13, v12                                     // 00000029C604: 7E1A550C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C608: BF870095
	v_fma_f32 v14, -v12, v13, 1.0                              // 00000029C60C: D613000E 23CA1B0C
	v_fmac_f32_e32 v13, v14, v13                               // 00000029C614: 561A1B0E
	v_div_scale_f32 v14, vcc_lo, 1.0, v11, 1.0                 // 00000029C618: D6FC6A0E 03CA16F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C620: BF870091
	v_mul_f32_e32 v15, v14, v13                                // 00000029C624: 101E1B0E
	v_fma_f32 v16, -v12, v15, v14                              // 00000029C628: D6130010 243A1F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C630: BF870091
	v_fmac_f32_e32 v15, v16, v13                               // 00000029C634: 561E1B10
	v_fma_f32 v12, -v12, v15, v14                              // 00000029C638: D613000C 243A1F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C640: BF870091
	v_div_fmas_f32 v12, v12, v13, v15                          // 00000029C644: D637000C 043E1B0C
	v_div_fixup_f32 v11, v12, v11, 1.0                         // 00000029C64C: D627000B 03CA170C
	global_store_b32 v[2:3], v11, off                          // 00000029C654: DC6A0000 007C0B02
	s_mov_b32 s7, 0                                            // 00000029C65C: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029C660: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000029C664: 8B6A077E
	s_cbranch_vccz 42                                          // 00000029C668: BFA3002A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1614>
	v_bfe_u32 v11, v8, 16, 1                                   // 00000029C66C: D610000B 02052108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C674: BF870091
	v_add3_u32 v11, v8, v11, 0x7fff                            // 00000029C678: D655000B 03FE1708 00007FFF
	v_and_b32_e32 v11, 0xffff0000, v11                         // 00000029C684: 361616FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C68C: BF870091
	v_mul_f32_e32 v11, s2, v11                                 // 00000029C690: 10161602
	v_mul_f32_e32 v11, 0xbfb8aa3b, v11                         // 00000029C694: 101616FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029C69C: BF870291
	v_exp_f32_e32 v11, v11                                     // 00000029C6A0: 7E164B0B
	v_add_f32_e32 v11, 1.0, v11                                // 00000029C6A4: 061616F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C6A8: BF870091
	v_div_scale_f32 v12, null, v11, v11, 1.0                   // 00000029C6AC: D6FC7C0C 03CA170B
	v_rcp_f32_e32 v13, v12                                     // 00000029C6B4: 7E1A550C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C6B8: BF870095
	v_fma_f32 v14, -v12, v13, 1.0                              // 00000029C6BC: D613000E 23CA1B0C
	v_fmac_f32_e32 v13, v14, v13                               // 00000029C6C4: 561A1B0E
	v_div_scale_f32 v14, vcc_lo, 1.0, v11, 1.0                 // 00000029C6C8: D6FC6A0E 03CA16F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C6D0: BF870091
	v_mul_f32_e32 v15, v14, v13                                // 00000029C6D4: 101E1B0E
	v_fma_f32 v16, -v12, v15, v14                              // 00000029C6D8: D6130010 243A1F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C6E0: BF870091
	v_fmac_f32_e32 v15, v16, v13                               // 00000029C6E4: 561E1B10
	v_fma_f32 v12, -v12, v15, v14                              // 00000029C6E8: D613000C 243A1F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C6F0: BF870091
	v_div_fmas_f32 v12, v12, v13, v15                          // 00000029C6F4: D637000C 043E1B0C
	v_div_fixup_f32 v11, v12, v11, 1.0                         // 00000029C6FC: D627000B 03CA170C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029C704: BF870001
	v_add_f32_e32 v11, v11, v11                                // 00000029C708: 0616170B
	global_store_b32 v[2:3], v11, off                          // 00000029C70C: DC6A0000 007C0B02
	s_mov_b32 s7, 0                                            // 00000029C714: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029C718: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000029C71C: 8B6A077E
	s_cbranch_vccz 55                                          // 00000029C720: BFA30037 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1700>
	s_cmp_gt_i32 s3, 1                                         // 00000029C724: BF028103
	s_mov_b32 s1, -1                                           // 00000029C728: BE8100C1
	s_cbranch_scc0 46                                          // 00000029C72C: BFA1002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x16e8>
	v_bfe_u32 v11, v8, 16, 1                                   // 00000029C730: D610000B 02052108
	s_mov_b32 s1, 0                                            // 00000029C738: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C73C: BF870091
	v_add3_u32 v11, v8, v11, 0x7fff                            // 00000029C740: D655000B 03FE1708 00007FFF
	v_and_b32_e32 v11, 0xffff0000, v11                         // 00000029C74C: 361616FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C754: BF870091
	v_mul_f32_e32 v11, 0xbfb8aa3b, v11                         // 00000029C758: 101616FF BFB8AA3B
	v_exp_f32_e32 v11, v11                                     // 00000029C760: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C764: BF870095
	v_add_f32_e32 v11, 1.0, v11                                // 00000029C768: 061616F2
	v_div_scale_f32 v12, null, v11, v11, 1.0                   // 00000029C76C: D6FC7C0C 03CA170B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029C774: BF870291
	v_rcp_f32_e32 v13, v12                                     // 00000029C778: 7E1A550C
	v_fma_f32 v14, -v12, v13, 1.0                              // 00000029C77C: D613000E 23CA1B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029C784: BF8700A1
	v_fmac_f32_e32 v13, v14, v13                               // 00000029C788: 561A1B0E
	v_div_scale_f32 v14, vcc_lo, 1.0, v11, 1.0                 // 00000029C78C: D6FC6A0E 03CA16F2
	v_mul_f32_e32 v15, v14, v13                                // 00000029C794: 101E1B0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C798: BF870091
	v_fma_f32 v16, -v12, v15, v14                              // 00000029C79C: D6130010 243A1F0C
	v_fmac_f32_e32 v15, v16, v13                               // 00000029C7A4: 561E1B10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C7A8: BF870091
	v_fma_f32 v12, -v12, v15, v14                              // 00000029C7AC: D613000C 243A1F0C
	v_div_fmas_f32 v12, v12, v13, v15                          // 00000029C7B4: D637000C 043E1B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C7BC: BF870091
	v_div_fixup_f32 v11, v12, v11, 1.0                         // 00000029C7C0: D627000B 03CA170C
	v_bfe_u32 v12, v11, 16, 1                                  // 00000029C7C8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029C7D0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000029C7D4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[0:1], v11, off                   // 00000029C7E0: DC960000 007C0B00
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000029C7E8: 916A017E
	s_mov_b32 s1, 0                                            // 00000029C7EC: BE810080
	s_cbranch_vccnz 3                                          // 00000029C7F0: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1700>
	s_cmp_lg_u32 s3, 1                                         // 00000029C7F4: BF078103
	s_mov_b32 s1, -1                                           // 00000029C7F8: BE8100C1
	s_cselect_b32 s6, -1, 0                                    // 00000029C7FC: 980680C1
	v_bfe_u32 v11, v8, 16, 1                                   // 00000029C800: D610000B 02052108
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000029C808: 8B6A067E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029C80C: BF870001
	v_add3_u32 v8, v8, v11, 0x7fff                             // 00000029C810: D6550008 03FE1708 00007FFF
	s_cbranch_vccz 3                                           // 00000029C81C: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x172c>
	s_mov_b32 s1, 0                                            // 00000029C820: BE810080
	global_store_d16_hi_b16 v[0:1], v8, off                    // 00000029C824: DC960000 007C0800
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000029C82C: 916A017E
	s_cbranch_vccnz 41                                         // 00000029C830: BFA40029 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x17d8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C834: BF870091
	v_and_b32_e32 v8, 0xffff0000, v8                           // 00000029C838: 361010FF FFFF0000
	v_mul_f32_e32 v8, s2, v8                                   // 00000029C840: 10101002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C844: BF870091
	v_mul_f32_e32 v11, 0xbfb8aa3b, v8                          // 00000029C848: 101610FF BFB8AA3B
	v_exp_f32_e32 v11, v11                                     // 00000029C850: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C854: BF870095
	v_add_f32_e32 v11, 1.0, v11                                // 00000029C858: 061616F2
	v_div_scale_f32 v12, null, v11, v11, v8                    // 00000029C85C: D6FC7C0C 0422170B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029C864: BF870291
	v_rcp_f32_e32 v13, v12                                     // 00000029C868: 7E1A550C
	v_fma_f32 v14, -v12, v13, 1.0                              // 00000029C86C: D613000E 23CA1B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029C874: BF8700A1
	v_fmac_f32_e32 v13, v14, v13                               // 00000029C878: 561A1B0E
	v_div_scale_f32 v14, vcc_lo, v8, v11, v8                   // 00000029C87C: D6FC6A0E 04221708
	v_mul_f32_e32 v15, v14, v13                                // 00000029C884: 101E1B0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C888: BF870091
	v_fma_f32 v16, -v12, v15, v14                              // 00000029C88C: D6130010 243A1F0C
	v_fmac_f32_e32 v15, v16, v13                               // 00000029C894: 561E1B10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C898: BF870091
	v_fma_f32 v12, -v12, v15, v14                              // 00000029C89C: D613000C 243A1F0C
	v_div_fmas_f32 v12, v12, v13, v15                          // 00000029C8A4: D637000C 043E1B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C8AC: BF870091
	v_div_fixup_f32 v8, v12, v11, v8                           // 00000029C8B0: D6270008 0422170C
	v_bfe_u32 v11, v8, 16, 1                                   // 00000029C8B8: D610000B 02052108
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029C8C0: BF870001
	v_add3_u32 v8, v8, v11, 0x7fff                             // 00000029C8C4: D6550008 03FE1708 00007FFF
	global_store_d16_hi_b16 v[0:1], v8, off                    // 00000029C8D0: DC960000 007C0800
	s_mov_b32 s7, -1                                           // 00000029C8D8: BE8700C1
	s_mov_b32 s1, 0                                            // 00000029C8DC: BE810080
	s_cmp_lt_i32 s3, 3                                         // 00000029C8E0: BF048303
	s_mov_b32 s6, 0                                            // 00000029C8E4: BE860080
	s_cbranch_scc1 135                                         // 00000029C8E8: BFA20087 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1a08>
	s_cmp_gt_i32 s3, 3                                         // 00000029C8EC: BF028303
	s_cbranch_scc0 82                                          // 00000029C8F0: BFA10052 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x193c>
	s_cmp_gt_i32 s3, 4                                         // 00000029C8F4: BF028403
	s_cbranch_scc0 40                                          // 00000029C8F8: BFA10028 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x189c>
	s_cmp_eq_u32 s3, 5                                         // 00000029C8FC: BF068503
	s_mov_b32 s6, -1                                           // 00000029C900: BE8600C1
	s_cbranch_scc0 36                                          // 00000029C904: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1898>
	s_load_b64 s[6:7], s[16:17], 0x10                          // 00000029C908: F4040188 F8000010
	v_dual_mov_b32 v8, s4 :: v_dual_mov_b32 v11, s5            // 00000029C910: CA100004 080A0005
	v_bfe_u32 v13, v7, 16, 1                                   // 00000029C918: D610000D 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029C920: BF8701A1
	v_add3_u32 v13, v7, v13, 0x7fff                            // 00000029C924: D655000D 03FE1B07 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 00000029C930: BF89FC07
	v_cndmask_b32_e64 v8, s6, v8, s0                           // 00000029C934: D5010008 00021006
	v_cndmask_b32_e64 v11, s7, v11, s0                         // 00000029C93C: D501000B 00021607
	s_and_b32 s6, s10, -2                                      // 00000029C944: 8B06C20A
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 00000029C948: BF870482
	.long 0xd7006a08                                           // 00000029C94C: D7006A08
	v_cndmask_b32_e32 v0, v8, v6, vcc_lo                       // 00000029C950: 02000D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029C954: BF8701A1
	v_add_co_ci_u32_e64 v14, null, s11, v11, vcc_lo            // 00000029C958: D5207C0E 01AA160B
	.long 0xd73c000b                                           // 00000029C960: D73C000B
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000029C964: 02020881
	.long 0xd7006a08                                           // 00000029C968: D7006A08
	v_cndmask_b32_e32 v1, v8, v10, vcc_lo                      // 00000029C96C: 02021508
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000029C970: BF8700B1
	v_add_co_ci_u32_e64 v14, null, v14, v9, vcc_lo             // 00000029C974: D5207C0E 01AA130E
	s_mov_b32 s6, 0                                            // 00000029C97C: BE860080
	.long 0xd7006a0b                                           // 00000029C980: D7006A0B
	v_cndmask_b32_e32 v1, v8, v11, vcc_lo                      // 00000029C984: 02021708
	v_add_co_ci_u32_e64 v12, null, v14, v12, vcc_lo            // 00000029C988: D5207C0C 01AA190E
	global_store_d16_hi_b16 v[11:12], v13, off                 // 00000029C990: DC960000 007C0D0B
	s_mov_b32 s7, 0                                            // 00000029C998: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029C99C: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000029C9A0: 8B6A077E
	s_cbranch_vccz 36                                          // 00000029C9A4: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1938>
	v_mul_f32_e32 v8, 0xbfb8aa3b, v7                           // 00000029C9A8: 10100EFF BFB8AA3B
	s_lshl_b64 s[8:9], s[10:11], 2                             // 00000029C9B0: 8488820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029C9B4: BF870291
	v_exp_f32_e32 v8, v8                                       // 00000029C9B8: 7E104B08
	v_add_f32_e32 v8, 1.0, v8                                  // 00000029C9BC: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029C9C0: BF870121
	v_div_scale_f32 v11, null, v8, v8, 1.0                     // 00000029C9C4: D6FC7C0B 03CA1108
	v_div_scale_f32 v14, vcc_lo, 1.0, v8, 1.0                  // 00000029C9CC: D6FC6A0E 03CA10F2
	v_rcp_f32_e32 v12, v11                                     // 00000029C9D4: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C9D8: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000029C9DC: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 00000029C9E4: 5618190D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C9E8: BF870091
	v_mul_f32_e32 v13, v14, v12                                // 00000029C9EC: 101A190E
	v_fma_f32 v15, -v11, v13, v14                              // 00000029C9F0: D613000F 243A1B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029C9F8: BF870091
	v_fmac_f32_e32 v13, v15, v12                               // 00000029C9FC: 561A190F
	v_fma_f32 v11, -v11, v13, v14                              // 00000029CA00: D613000B 243A1B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CA08: BF870091
	v_div_fmas_f32 v11, v11, v12, v13                          // 00000029CA0C: D637000B 0436190B
	v_div_fixup_f32 v8, v11, v8, 1.0                           // 00000029CA14: D6270008 03CA110B
	.long 0xd7006a0b                                           // 00000029CA1C: D7006A0B
	v_cndmask_b32_e32 v0, v2, v8, vcc_lo                       // 00000029CA20: 02001102
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029CA24: BF870001
	v_add_co_ci_u32_e64 v12, null, s9, v3, vcc_lo              // 00000029CA28: D5207C0C 01AA0609
	global_store_b32 v[11:12], v8, off                         // 00000029CA30: DC6A0000 007C080B
	s_mov_b32 s7, 0                                            // 00000029CA38: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029CA3C: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000029CA40: 8B6A077E
	s_cbranch_vccz 47                                          // 00000029CA44: BFA3002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1a04>
	v_bfe_u32 v8, v7, 16, 1                                    // 00000029CA48: D6100008 02052107
	s_lshl_b64 s[8:9], s[10:11], 2                             // 00000029CA50: 8488820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CA54: BF870091
	v_add3_u32 v8, v7, v8, 0x7fff                              // 00000029CA58: D6550008 03FE1107 00007FFF
	v_and_b32_e32 v8, 0xffff0000, v8                           // 00000029CA64: 361010FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CA6C: BF870091
	v_mul_f32_e32 v8, s2, v8                                   // 00000029CA70: 10101002
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 00000029CA74: 101010FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029CA7C: BF870291
	v_exp_f32_e32 v8, v8                                       // 00000029CA80: 7E104B08
	v_add_f32_e32 v8, 1.0, v8                                  // 00000029CA84: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029CA88: BF870121
	v_div_scale_f32 v11, null, v8, v8, 1.0                     // 00000029CA8C: D6FC7C0B 03CA1108
	v_div_scale_f32 v14, vcc_lo, 1.0, v8, 1.0                  // 00000029CA94: D6FC6A0E 03CA10F2
	v_rcp_f32_e32 v12, v11                                     // 00000029CA9C: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CAA0: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000029CAA4: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 00000029CAAC: 5618190D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CAB0: BF870091
	v_mul_f32_e32 v13, v14, v12                                // 00000029CAB4: 101A190E
	v_fma_f32 v15, -v11, v13, v14                              // 00000029CAB8: D613000F 243A1B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CAC0: BF870091
	v_fmac_f32_e32 v13, v15, v12                               // 00000029CAC4: 561A190F
	v_fma_f32 v11, -v11, v13, v14                              // 00000029CAC8: D613000B 243A1B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CAD0: BF870091
	v_div_fmas_f32 v11, v11, v12, v13                          // 00000029CAD4: D637000B 0436190B
	v_div_fixup_f32 v8, v11, v8, 1.0                           // 00000029CADC: D6270008 03CA110B
	.long 0xd7006a0b                                           // 00000029CAE4: D7006A0B
	v_cndmask_b32_e32 v0, v2, v8, vcc_lo                       // 00000029CAE8: 02001102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029CAEC: BF870191
	v_add_co_ci_u32_e64 v12, null, s9, v3, vcc_lo              // 00000029CAF0: D5207C0C 01AA0609
	v_add_f32_e32 v8, v8, v8                                   // 00000029CAF8: 06101108
	global_store_b32 v[11:12], v8, off                         // 00000029CAFC: DC6A0000 007C080B
	s_mov_b32 s7, 0                                            // 00000029CB04: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029CB08: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000029CB0C: 8B6A077E
	s_cbranch_vccz 60                                          // 00000029CB10: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1b04>
	s_cmp_gt_i32 s3, 1                                         // 00000029CB14: BF028103
	s_mov_b32 s1, -1                                           // 00000029CB18: BE8100C1
	s_cbranch_scc0 51                                          // 00000029CB1C: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1aec>
	v_bfe_u32 v8, v7, 16, 1                                    // 00000029CB20: D6100008 02052107
	s_lshl_b64 s[8:9], s[10:11], 1                             // 00000029CB28: 8488810A
	s_mov_b32 s1, 0                                            // 00000029CB2C: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CB30: BF870091
	v_add3_u32 v8, v7, v8, 0x7fff                              // 00000029CB34: D6550008 03FE1107 00007FFF
	v_and_b32_e32 v8, 0xffff0000, v8                           // 00000029CB40: 361010FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CB48: BF870091
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 00000029CB4C: 101010FF BFB8AA3B
	v_exp_f32_e32 v8, v8                                       // 00000029CB54: 7E104B08
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CB58: BF870095
	v_add_f32_e32 v8, 1.0, v8                                  // 00000029CB5C: 061010F2
	v_div_scale_f32 v11, null, v8, v8, 1.0                     // 00000029CB60: D6FC7C0B 03CA1108
	v_div_scale_f32 v14, vcc_lo, 1.0, v8, 1.0                  // 00000029CB68: D6FC6A0E 03CA10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029CB70: BF870292
	v_rcp_f32_e32 v12, v11                                     // 00000029CB74: 7E18550B
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000029CB78: D613000D 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CB80: BF870091
	v_fmac_f32_e32 v12, v13, v12                               // 00000029CB84: 5618190D
	v_mul_f32_e32 v13, v14, v12                                // 00000029CB88: 101A190E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CB8C: BF870091
	v_fma_f32 v15, -v11, v13, v14                              // 00000029CB90: D613000F 243A1B0B
	v_fmac_f32_e32 v13, v15, v12                               // 00000029CB98: 561A190F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CB9C: BF870091
	v_fma_f32 v11, -v11, v13, v14                              // 00000029CBA0: D613000B 243A1B0B
	v_div_fmas_f32 v11, v11, v12, v13                          // 00000029CBA8: D637000B 0436190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CBB0: BF870091
	v_div_fixup_f32 v8, v11, v8, 1.0                           // 00000029CBB4: D6270008 03CA110B
	v_bfe_u32 v11, v8, 16, 1                                   // 00000029CBBC: D610000B 02052108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029CBC4: BF8700A1
	v_add3_u32 v8, v8, v11, 0x7fff                             // 00000029CBC8: D6550008 03FE1708 00007FFF
	.long 0xd7006a0b                                           // 00000029CBD4: D7006A0B
	v_cndmask_b32_e32 v0, v0, v8, vcc_lo                       // 00000029CBD8: 02001100
	v_add_co_ci_u32_e64 v12, null, s9, v1, vcc_lo              // 00000029CBDC: D5207C0C 01AA0209
	global_store_d16_hi_b16 v[11:12], v8, off                  // 00000029CBE4: DC960000 007C080B
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000029CBEC: 916A017E
	s_mov_b32 s1, 0                                            // 00000029CBF0: BE810080
	s_cbranch_vccnz 3                                          // 00000029CBF4: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1b04>
	s_cmp_lg_u32 s3, 1                                         // 00000029CBF8: BF078103
	s_mov_b32 s1, -1                                           // 00000029CBFC: BE8100C1
	s_cselect_b32 s6, -1, 0                                    // 00000029CC00: 980680C1
	v_bfe_u32 v8, v7, 16, 1                                    // 00000029CC04: D6100008 02052107
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000029CC0C: 8B6A067E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029CC10: BF870001
	v_add3_u32 v7, v7, v8, 0x7fff                              // 00000029CC14: D6550007 03FE1107 00007FFF
	s_cbranch_vccz 9                                           // 00000029CC20: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1b48>
	s_lshl_b64 s[6:7], s[10:11], 1                             // 00000029CC24: 8486810A
	s_mov_b32 s1, 0                                            // 00000029CC28: BE810080
	.long 0xd7006a0b                                           // 00000029CC2C: D7006A0B
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo                       // 00000029CC30: 02000D00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029CC34: BF870001
	v_add_co_ci_u32_e64 v12, null, s7, v1, vcc_lo              // 00000029CC38: D5207C0C 01AA0207
	global_store_d16_hi_b16 v[11:12], v7, off                  // 00000029CC40: DC960000 007C070B
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000029CC48: 916A017E
	s_cbranch_vccnz 46                                         // 00000029CC4C: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1c08>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029CC50: BF8700A1
	v_and_b32_e32 v7, 0xffff0000, v7                           // 00000029CC54: 360E0EFF FFFF0000
	s_lshl_b64 s[6:7], s[10:11], 1                             // 00000029CC5C: 8486810A
	v_mul_f32_e32 v7, s2, v7                                   // 00000029CC60: 100E0E02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CC64: BF870091
	v_mul_f32_e32 v8, 0xbfb8aa3b, v7                           // 00000029CC68: 10100EFF BFB8AA3B
	v_exp_f32_e32 v8, v8                                       // 00000029CC70: 7E104B08
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CC74: BF870095
	v_add_f32_e32 v8, 1.0, v8                                  // 00000029CC78: 061010F2
	v_div_scale_f32 v11, null, v8, v8, v7                      // 00000029CC7C: D6FC7C0B 041E1108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029CC84: BF870291
	v_rcp_f32_e32 v12, v11                                     // 00000029CC88: 7E18550B
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000029CC8C: D613000D 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029CC94: BF8700A1
	v_fmac_f32_e32 v12, v13, v12                               // 00000029CC98: 5618190D
	v_div_scale_f32 v14, vcc_lo, v7, v8, v7                    // 00000029CC9C: D6FC6A0E 041E1107
	v_mul_f32_e32 v13, v14, v12                                // 00000029CCA4: 101A190E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CCA8: BF870091
	v_fma_f32 v15, -v11, v13, v14                              // 00000029CCAC: D613000F 243A1B0B
	v_fmac_f32_e32 v13, v15, v12                               // 00000029CCB4: 561A190F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CCB8: BF870091
	v_fma_f32 v11, -v11, v13, v14                              // 00000029CCBC: D613000B 243A1B0B
	v_div_fmas_f32 v11, v11, v12, v13                          // 00000029CCC4: D637000B 0436190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CCCC: BF870091
	v_div_fixup_f32 v7, v11, v8, v7                            // 00000029CCD0: D6270007 041E110B
	v_bfe_u32 v8, v7, 16, 1                                    // 00000029CCD8: D6100008 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029CCE0: BF8700A1
	v_add3_u32 v11, v7, v8, 0x7fff                             // 00000029CCE4: D655000B 03FE1107 00007FFF
	.long 0xd7006a07                                           // 00000029CCF0: D7006A07
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo                       // 00000029CCF4: 02000D00
	v_add_co_ci_u32_e64 v8, null, s7, v1, vcc_lo               // 00000029CCF8: D5207C08 01AA0207
	global_store_d16_hi_b16 v[7:8], v11, off                   // 00000029CD00: DC960000 007C0B07
	s_mov_b32 s7, -1                                           // 00000029CD08: BE8700C1
	s_mov_b32 s1, 0                                            // 00000029CD0C: BE810080
	s_cmp_lt_i32 s3, 3                                         // 00000029CD10: BF048303
	s_mov_b32 s6, 0                                            // 00000029CD14: BE860080
	s_cbranch_scc1 138                                         // 00000029CD18: BFA2008A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1e44>
	s_cmp_gt_i32 s3, 3                                         // 00000029CD1C: BF028303
	s_cbranch_scc0 45                                          // 00000029CD20: BFA1002D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1cd8>
	s_cmp_gt_i32 s3, 4                                         // 00000029CD24: BF028403
	s_cbranch_scc0 45                                          // 00000029CD28: BFA1002D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1ce0>
	s_cmp_eq_u32 s3, 5                                         // 00000029CD2C: BF068503
	s_mov_b32 s6, -1                                           // 00000029CD30: BE8600C1
	s_cbranch_scc0 38                                          // 00000029CD34: BFA10026 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1cd0>
	s_load_b64 s[6:7], s[16:17], 0x10                          // 00000029CD38: F4040188 F8000010
	v_dual_mov_b32 v7, s4 :: v_dual_mov_b32 v8, s5             // 00000029CD40: CA100004 07080005
	s_and_b32 s5, s11, 0x7fffffff                              // 00000029CD48: 8B05FF0B 7FFFFFFF
	s_and_b32 s4, s10, -2                                      // 00000029CD50: 8B04C20A
	.long 0xd73c0004                                           // 00000029CD54: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000029CD58: 02020881
	s_lshl_b64 s[4:5], s[4:5], 1                               // 00000029CD5C: 84848104
	v_bfe_u32 v11, v6, 16, 1                                   // 00000029CD60: D610000B 02052106
	s_waitcnt lgkmcnt(0)                                       // 00000029CD68: BF89FC07
	v_cndmask_b32_e64 v7, s6, v7, s0                           // 00000029CD6C: D5010007 00020E06
	v_cndmask_b32_e64 v8, s7, v8, s0                           // 00000029CD74: D5010008 00021007
	s_mov_b32 s6, 0                                            // 00000029CD7C: BE860080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CD80: BF870092
	.long 0xd7006a07                                           // 00000029CD84: D7006A07
	v_cndmask_b32_e32 v0, v7, v4, vcc_lo                       // 00000029CD88: 02000907
	v_add_co_ci_u32_e64 v8, null, s5, v8, vcc_lo               // 00000029CD8C: D5207C08 01AA1005
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CD94: BF870092
	.long 0xd7006a07                                           // 00000029CD98: D7006A07
	v_cndmask_b32_e32 v1, v7, v10, vcc_lo                      // 00000029CD9C: 02021507
	v_add_co_ci_u32_e64 v8, null, v8, v9, vcc_lo               // 00000029CDA0: D5207C08 01AA1308
	v_add3_u32 v9, v6, v11, 0x7fff                             // 00000029CDA8: D6550009 03FE1706 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CDB4: BF870093
	.long 0xd7006a04                                           // 00000029CDB8: D7006A04
	v_cndmask_b32_e32 v1, v7, v4, vcc_lo                       // 00000029CDBC: 02020907
	v_add_co_ci_u32_e64 v5, null, v8, v5, vcc_lo               // 00000029CDC0: D5207C05 01AA0B08
	global_store_d16_hi_b16 v[4:5], v9, off                    // 00000029CDC8: DC960000 007C0904
	s_mov_b32 s0, 0                                            // 00000029CDD0: BE800080
	s_branch 3                                                 // 00000029CDD4: BFA00003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1ce4>
	s_cbranch_execnz 42                                        // 00000029CDD8: BFA6002A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1d84>
	s_branch 88                                                // 00000029CDDC: BFA00058 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1e40>
	s_mov_b32 s0, -1                                           // 00000029CDE0: BE8000C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029CDE4: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 00000029CDE8: 8B6A007E
	s_cbranch_vccz 36                                          // 00000029CDEC: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1d80>
	v_mul_f32_e32 v4, 0xbfb8aa3b, v6                           // 00000029CDF0: 10080CFF BFB8AA3B
	s_lshl_b64 s[4:5], s[10:11], 3                             // 00000029CDF8: 8484830A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029CDFC: BF870291
	v_exp_f32_e32 v4, v4                                       // 00000029CE00: 7E084B04
	v_add_f32_e32 v4, 1.0, v4                                  // 00000029CE04: 060808F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029CE08: BF870121
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 00000029CE0C: D6FC7C05 03CA0904
	v_div_scale_f32 v9, vcc_lo, 1.0, v4, 1.0                   // 00000029CE14: D6FC6A09 03CA08F2
	v_rcp_f32_e32 v7, v5                                       // 00000029CE1C: 7E0E5505
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CE20: BF870095
	v_fma_f32 v8, -v5, v7, 1.0                                 // 00000029CE24: D6130008 23CA0F05
	v_fmac_f32_e32 v7, v8, v7                                  // 00000029CE2C: 560E0F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CE30: BF870091
	v_mul_f32_e32 v8, v9, v7                                   // 00000029CE34: 10100F09
	v_fma_f32 v10, -v5, v8, v9                                 // 00000029CE38: D613000A 24261105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CE40: BF870091
	v_fmac_f32_e32 v8, v10, v7                                 // 00000029CE44: 56100F0A
	v_fma_f32 v5, -v5, v8, v9                                  // 00000029CE48: D6130005 24261105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CE50: BF870091
	v_div_fmas_f32 v5, v5, v7, v8                              // 00000029CE54: D6370005 04220F05
	v_div_fixup_f32 v7, v5, v4, 1.0                            // 00000029CE5C: D6270007 03CA0905
	.long 0xd7006a04                                           // 00000029CE64: D7006A04
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 00000029CE68: 02000902
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029CE6C: BF870001
	v_add_co_ci_u32_e64 v5, null, s5, v3, vcc_lo               // 00000029CE70: D5207C05 01AA0605
	global_store_b32 v[4:5], v7, off                           // 00000029CE78: DC6A0000 007C0704
	s_branch 47                                                // 00000029CE80: BFA0002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1e40>
	v_bfe_u32 v4, v6, 16, 1                                    // 00000029CE84: D6100004 02052106
	s_lshl_b64 s[4:5], s[10:11], 3                             // 00000029CE8C: 8484830A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CE90: BF870091
	v_add3_u32 v4, v6, v4, 0x7fff                              // 00000029CE94: D6550004 03FE0906 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000029CEA0: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CEA8: BF870091
	v_mul_f32_e32 v4, s2, v4                                   // 00000029CEAC: 10080802
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 00000029CEB0: 100808FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029CEB8: BF870291
	v_exp_f32_e32 v4, v4                                       // 00000029CEBC: 7E084B04
	v_add_f32_e32 v4, 1.0, v4                                  // 00000029CEC0: 060808F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029CEC4: BF870121
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 00000029CEC8: D6FC7C05 03CA0904
	v_div_scale_f32 v9, vcc_lo, 1.0, v4, 1.0                   // 00000029CED0: D6FC6A09 03CA08F2
	v_rcp_f32_e32 v7, v5                                       // 00000029CED8: 7E0E5505
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CEDC: BF870095
	v_fma_f32 v8, -v5, v7, 1.0                                 // 00000029CEE0: D6130008 23CA0F05
	v_fmac_f32_e32 v7, v8, v7                                  // 00000029CEE8: 560E0F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CEEC: BF870091
	v_mul_f32_e32 v8, v9, v7                                   // 00000029CEF0: 10100F09
	v_fma_f32 v10, -v5, v8, v9                                 // 00000029CEF4: D613000A 24261105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CEFC: BF870091
	v_fmac_f32_e32 v8, v10, v7                                 // 00000029CF00: 56100F0A
	v_fma_f32 v5, -v5, v8, v9                                  // 00000029CF04: D6130005 24261105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029CF0C: BF8700A1
	v_div_fmas_f32 v5, v5, v7, v8                              // 00000029CF10: D6370005 04220F05
	.long 0xd7006a02                                           // 00000029CF18: D7006A02
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 00000029CF1C: 02000902
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000029CF20: D5207C03 01AA0605
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CF28: BF870093
	v_div_fixup_f32 v4, v5, v4, 1.0                            // 00000029CF2C: D6270004 03CA0905
	v_add_f32_e32 v4, v4, v4                                   // 00000029CF34: 06080904
	global_store_b32 v[2:3], v4, off                           // 00000029CF38: DC6A0000 007C0402
	s_mov_b32 s7, 0                                            // 00000029CF40: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029CF44: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000029CF48: 8B6A077E
	s_cbranch_vccz 60                                          // 00000029CF4C: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1f40>
	s_cmp_gt_i32 s3, 1                                         // 00000029CF50: BF028103
	s_mov_b32 s0, -1                                           // 00000029CF54: BE8000C1
	s_cbranch_scc0 51                                          // 00000029CF58: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1f28>
	v_bfe_u32 v2, v6, 16, 1                                    // 00000029CF5C: D6100002 02052106
	s_lshl_b64 s[0:1], s[10:11], 2                             // 00000029CF64: 8480820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CF68: BF870091
	v_add3_u32 v2, v6, v2, 0x7fff                              // 00000029CF6C: D6550002 03FE0506 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000029CF78: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CF80: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 00000029CF84: 100404FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 00000029CF8C: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CF90: BF870095
	v_add_f32_e32 v2, 1.0, v2                                  // 00000029CF94: 060404F2
	v_div_scale_f32 v3, null, v2, v2, 1.0                      // 00000029CF98: D6FC7C03 03CA0502
	v_div_scale_f32 v7, vcc_lo, 1.0, v2, 1.0                   // 00000029CFA0: D6FC6A07 03CA04F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029CFA8: BF870292
	v_rcp_f32_e32 v4, v3                                       // 00000029CFAC: 7E085503
	v_fma_f32 v5, -v3, v4, 1.0                                 // 00000029CFB0: D6130005 23CA0903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CFB8: BF870091
	v_fmac_f32_e32 v4, v5, v4                                  // 00000029CFBC: 56080905
	v_mul_f32_e32 v5, v7, v4                                   // 00000029CFC0: 100A0907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CFC4: BF870091
	v_fma_f32 v8, -v3, v5, v7                                  // 00000029CFC8: D6130008 241E0B03
	v_fmac_f32_e32 v5, v8, v4                                  // 00000029CFD0: 560A0908
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CFD4: BF870091
	v_fma_f32 v3, -v3, v5, v7                                  // 00000029CFD8: D6130003 241E0B03
	v_div_fmas_f32 v3, v3, v4, v5                              // 00000029CFE0: D6370003 04160903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029CFE8: BF870091
	v_div_fixup_f32 v2, v3, v2, 1.0                            // 00000029CFEC: D6270002 03CA0503
	v_bfe_u32 v3, v2, 16, 1                                    // 00000029CFF4: D6100003 02052102
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029CFFC: BF8700A1
	v_add3_u32 v4, v2, v3, 0x7fff                              // 00000029D000: D6550004 03FE0702 00007FFF
	.long 0xd7006a02                                           // 00000029D00C: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000029D010: 02000100
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 00000029D014: D5207C03 01AA0201
	s_mov_b32 s0, 0                                            // 00000029D01C: BE800080
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000029D020: DC960000 007C0402
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000029D028: 916A007E
	s_mov_b32 s1, 0                                            // 00000029D02C: BE810080
	s_cbranch_vccnz 3                                          // 00000029D030: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1f40>
	s_cmp_lg_u32 s3, 1                                         // 00000029D034: BF078103
	s_mov_b32 s1, -1                                           // 00000029D038: BE8100C1
	s_cselect_b32 s6, -1, 0                                    // 00000029D03C: 980680C1
	v_bfe_u32 v2, v6, 16, 1                                    // 00000029D040: D6100002 02052106
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000029D048: 8B6A067E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029D04C: BF870001
	v_add3_u32 v2, v6, v2, 0x7fff                              // 00000029D050: D6550002 03FE0506 00007FFF
	s_cbranch_vccz 9                                           // 00000029D05C: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1f84>
	s_lshl_b64 s[0:1], s[10:11], 2                             // 00000029D060: 8480820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029D064: BF870099
	.long 0xd7006a03                                           // 00000029D068: D7006A03
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000029D06C: 02000100
	v_add_co_ci_u32_e64 v4, null, s1, v1, vcc_lo               // 00000029D070: D5207C04 01AA0201
	s_mov_b32 s1, 0                                            // 00000029D078: BE810080
	global_store_d16_hi_b16 v[3:4], v2, off                    // 00000029D07C: DC960000 007C0203
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000029D084: 916A017E
	s_cbranch_vccnz 46                                         // 00000029D088: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2044>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029D08C: BF8700A1
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000029D090: 360404FF FFFF0000
	s_lshl_b64 s[0:1], s[10:11], 2                             // 00000029D098: 8480820A
	v_mul_f32_e32 v2, s2, v2                                   // 00000029D09C: 10040402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029D0A0: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v2                           // 00000029D0A4: 100604FF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 00000029D0AC: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029D0B0: BF870095
	v_add_f32_e32 v3, 1.0, v3                                  // 00000029D0B4: 060606F2
	v_div_scale_f32 v4, null, v3, v3, v2                       // 00000029D0B8: D6FC7C04 040A0703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029D0C0: BF870291
	v_rcp_f32_e32 v5, v4                                       // 00000029D0C4: 7E0A5504
	v_fma_f32 v6, -v4, v5, 1.0                                 // 00000029D0C8: D6130006 23CA0B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029D0D0: BF8700A1
	v_fmac_f32_e32 v5, v6, v5                                  // 00000029D0D4: 560A0B06
	v_div_scale_f32 v7, vcc_lo, v2, v3, v2                     // 00000029D0D8: D6FC6A07 040A0702
	v_mul_f32_e32 v6, v7, v5                                   // 00000029D0E0: 100C0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029D0E4: BF870091
	v_fma_f32 v8, -v4, v6, v7                                  // 00000029D0E8: D6130008 241E0D04
	v_fmac_f32_e32 v6, v8, v5                                  // 00000029D0F0: 560C0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029D0F4: BF870091
	v_fma_f32 v4, -v4, v6, v7                                  // 00000029D0F8: D6130004 241E0D04
	v_div_fmas_f32 v4, v4, v5, v6                              // 00000029D100: D6370004 041A0B04
	.long 0xd7006a00                                           // 00000029D108: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000029D10C: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029D110: BF870191
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000029D114: D5207C01 01AA0201
	v_div_fixup_f32 v2, v4, v3, v2                             // 00000029D11C: D6270002 040A0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029D124: BF870091
	v_bfe_u32 v3, v2, 16, 1                                    // 00000029D128: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000029D130: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000029D13C: DC960000 007C0200
	s_nop 0                                                    // 00000029D144: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000029D148: BFB60003
	s_endpgm                                                   // 00000029D14C: BFB00000
		...

