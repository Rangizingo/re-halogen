00000000005a5d00 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi7ELi32ELi8ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi7ELi32ELi8ELb0EEEvPKhPKtPvll():
	s_load_b256 s[4:11], s[0:1], null                          // 0000005A5D00: F40C0100 F8000000
	v_lshrrev_b32_e32 v5, 5, v0                                // 0000005A5D08: 320A0085
	v_dual_mov_b32 v11, 0 :: v_dual_and_b32 v6, 31, v0         // 0000005A5D0C: CA240080 0B06009F
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v15, 0             // 0000005A5D14: CA100080 0E0E0080
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 0000005A5D1C: CA100080 0A080080
	s_mov_b32 s16, exec_lo                                     // 0000005A5D24: BE90007E
	v_mov_b32_e32 v13, 0                                       // 0000005A5D28: 7E1A0280
	s_waitcnt lgkmcnt(0)                                       // 0000005A5D2C: BF89FC07
	s_ashr_i32 s3, s11, 31                                     // 0000005A5D30: 86039F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000005A5D34: BF870499
	s_lshr_b32 s3, s3, 28                                      // 0000005A5D38: 85039C03
	s_add_u32 s12, s10, s3                                     // 0000005A5D3C: 800C030A
	s_addc_u32 s13, s11, 0                                     // 0000005A5D40: 820D800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000005A5D44: BF870499
	s_lshr_b64 s[14:15], s[12:13], 4                           // 0000005A5D48: 858E840C
	s_add_i32 s3, s14, 7                                       // 0000005A5D4C: 8103870E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000005A5D50: BF870499
	s_ashr_i32 s12, s3, 31                                     // 0000005A5D54: 860C9F03
	s_lshr_b32 s12, s12, 29                                    // 0000005A5D58: 850C9D0C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000005A5D5C: BF8704B9
	s_add_i32 s3, s3, s12                                      // 0000005A5D60: 81030C03
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000005A5D64: F4040300 F8000020
	s_ashr_i32 s3, s3, 3                                       // 0000005A5D6C: 86038303
	.long 0xd72c0001                                           // 0000005A5D70: D72C0001
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 0000005A5D74: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005A5D78: BF8700B1
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v7, v1, v6      // 0000005A5D7C: CA200080 0C060D01
	v_add_nc_u32_e32 v2, s3, v1                                // 0000005A5D84: 4A040203
	s_mov_b32 s3, 0                                            // 0000005A5D88: BE830080
	v_min_i32_e32 v8, s14, v2                                  // 0000005A5D8C: 2210040E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005A5D90: BF870001
	.long 0xd4c1007e                                           // 0000005A5D94: D4C1007E
	v_cndmask_b32_e32 v1, v7, v8, vcc_lo                       // 0000005A5D98: 02021107
	s_cbranch_execz 553                                        // 0000005A5D9C: BFA50229 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi7ELi32ELi8ELb0EEEvPKhPKtPvll+0x944>
	s_waitcnt lgkmcnt(0)                                       // 0000005A5DA0: BF89FC07
	.long 0xd4510000                                           // 0000005A5DA4: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000005A5DA8: 02001802
	v_dual_mov_b32 v10, 0 :: v_dual_lshlrev_b32 v1, 4, v7      // 0000005A5DAC: CA220080 0A000E84
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v12, 0             // 0000005A5DB4: CA100080 0F0C0080
	v_mov_b32_e32 v13, 0                                       // 0000005A5DBC: 7E1A0280
	s_and_b32 s0, s0, exec_lo                                  // 0000005A5DC0: 8B007E00
	s_cselect_b32 s14, s2, 0                                   // 0000005A5DC4: 980E8002
	s_cselect_b32 s15, 0, 0                                    // 0000005A5DC8: 980F8080
	s_ashr_i32 s0, s11, 31                                     // 0000005A5DCC: 86009F0B
	v_mov_b32_e32 v11, 0                                       // 0000005A5DD0: 7E160280
	s_lshr_b32 s0, s0, 24                                      // 0000005A5DD4: 85009800
	s_mul_i32 s17, s11, 6                                      // 0000005A5DD8: 9611860B
	s_add_u32 s0, s10, s0                                      // 0000005A5DDC: 8000000A
	s_addc_u32 s1, s11, 0                                      // 0000005A5DE0: 8201800B
	s_mul_hi_u32 s18, s10, 6                                   // 0000005A5DE4: 9692860A
	s_ashr_i64 s[0:1], s[0:1], 8                               // 0000005A5DE8: 86808800
	v_mov_b32_e32 v14, 0                                       // 0000005A5DEC: 7E1C0280
	s_mul_i32 s15, s0, s15                                     // 0000005A5DF0: 960F0F00
	s_mul_hi_u32 s19, s0, s14                                  // 0000005A5DF4: 96930E00
	s_mul_i32 s1, s1, s14                                      // 0000005A5DF8: 96010E01
	s_add_i32 s15, s19, s15                                    // 0000005A5DFC: 810F0F13
	s_mul_i32 s0, s0, s14                                      // 0000005A5E00: 96000E00
	s_add_i32 s1, s15, s1                                      // 0000005A5E04: 8101010F
	s_mul_hi_u32 s14, s0, 0xd2                                 // 0000005A5E08: 968EFF00 000000D2
	s_mulk_i32 s1, 0xd2                                        // 0000005A5E10: B80100D2
	s_mulk_i32 s0, 0xd2                                        // 0000005A5E14: B80000D2
	s_add_i32 s14, s14, s1                                     // 0000005A5E18: 810E010E
	s_add_u32 s0, s4, s0                                       // 0000005A5E1C: 80000004
	s_addc_u32 s1, s5, s14                                     // 0000005A5E20: 82010E05
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005A5E24: BF870009
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v4, s1              // 0000005A5E28: CA100080 09040001
	v_mov_b32_e32 v3, s0                                       // 0000005A5E30: 7E060200
	s_lshl_b64 s[14:15], s[10:11], 2                           // 0000005A5E34: 848E820A
	s_add_i32 s5, s18, s17                                     // 0000005A5E38: 81051112
	s_mul_i32 s17, s10, 6                                      // 0000005A5E3C: 9611860A
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000005A5E40: 848A810A
	s_mov_b32 s18, s3                                          // 0000005A5E44: BE920003
	v_ashrrev_i32_e32 v16, 4, v7                               // 0000005A5E48: 34200E84
	v_bfe_u32 v17, v7, 3, 1                                    // 0000005A5E4C: D6100011 02050707
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000005A5E54: 3404029F
	v_and_b32_e32 v26, 15, v7                                  // 0000005A5E58: 36340E8F
	v_and_b32_e32 v54, 16, v1                                  // 0000005A5E5C: 366C0290
	.long 0xd72c0012                                           // 0000005A5E60: D72C0012
	v_cndmask_b32_e32 v1, 0xd2, v16, vcc_lo                    // 0000005A5E64: 020220FF 000000D2
	v_lshlrev_b32_e32 v27, 6, v17                              // 0000005A5E6C: 30362286
	v_lshlrev_b32_e32 v30, 5, v17                              // 0000005A5E70: 303C2285
	.long 0xd73c0010                                           // 0000005A5E74: D73C0010
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000005A5E78: 02020281
	v_and_b32_e32 v53, 32, v1                                  // 0000005A5E7C: 366A02A0
	v_and_b32_e32 v61, 6, v7                                   // 0000005A5E80: 367A0E86
	v_and_b32_e32 v60, 4, v7                                   // 0000005A5E84: 36780E84
	v_ashrrev_i32_e32 v31, 31, v18                             // 0000005A5E88: 343E249F
	.long 0xd7006a18                                           // 0000005A5E8C: D7006A18
	v_cndmask_b32_e32 v1, s6, v16, vcc_lo                      // 0000005A5E90: 02022006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005A5E94: BF8701A1
	v_add_co_ci_u32_e64 v25, null, s7, v17, vcc_lo             // 0000005A5E98: D5207C19 01AA2207
	.long 0xd7006a38                                           // 0000005A5EA0: D7006A38
	v_cndmask_b32_e32 v1, v3, v18, vcc_lo                      // 0000005A5EA4: 02022503
	.long 0xd700001c                                           // 0000005A5EA8: D700001C
	v_cndmask_b32_e32 v0, v24, v10, vcc_lo                     // 0000005A5EAC: 02001518
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005A5EB0: BF8700A1
	v_add_co_ci_u32_e64 v29, null, s11, v25, s0                // 0000005A5EB4: D5207C1D 0002320B
	.long 0xd7000030                                           // 0000005A5EBC: D7000030
	v_cndmask_b32_e32 v0, v24, v14, vcc_lo                     // 0000005A5EC0: 02001D18
	v_add_co_ci_u32_e64 v49, null, s15, v25, s0                // 0000005A5EC4: D5207C31 0002320F
	v_add_co_ci_u32_e64 v57, null, v4, v31, vcc_lo             // 0000005A5ECC: D5207C39 01AA3F04
	.long 0xd7000032                                           // 0000005A5ED4: D7000032
	v_cndmask_b32_e32 v0, v24, v17, vcc_lo                     // 0000005A5ED8: 02002318
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005A5EDC: BF870001
	v_add_co_ci_u32_e64 v51, null, s5, v25, s0                 // 0000005A5EE0: D5207C33 00023205
	.long 0xd7000044                                           // 0000005A5EE8: D7000044
	v_cndmask_b32_e32 v1, v56, v30, vcc_lo                     // 0000005A5EEC: 02023D38
	.long 0xd700043a                                           // 0000005A5EF0: D700043A
	v_cndmask_b32_e32 v0, v48, v14, vcc_lo                     // 0000005A5EF4: 02001D30
	s_clause 0x1                                               // 0000005A5EF8: BF850001
	global_load_b128 v[16:19], v[24:25], off                   // 0000005A5EFC: DC5E0000 107C0018
	global_load_b128 v[20:23], v[24:25], off offset:16         // 0000005A5F04: DC5E0010 147C0018
	.long 0xd7006a37                                           // 0000005A5F0C: D7006A37
	v_cndmask_b32_e32 v1, v56, v27, vcc_lo                     // 0000005A5F10: 02023738
	.long 0xd7000134                                           // 0000005A5F14: D7000134
	v_cndmask_b32_e32 v1, v56, v26, vcc_lo                     // 0000005A5F18: 02023538
	s_clause 0x5                                               // 0000005A5F1C: BF850005
	global_load_b128 v[24:27], v[28:29], off                   // 0000005A5F20: DC5E0000 187C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 0000005A5F28: DC5E0010 1C7C001C
	global_load_b128 v[32:35], v[48:49], off                   // 0000005A5F30: DC5E0000 207C0030
	global_load_b128 v[36:39], v[48:49], off offset:16         // 0000005A5F38: DC5E0010 247C0030
	global_load_b128 v[40:43], v[50:51], off                   // 0000005A5F40: DC5E0000 287C0032
	global_load_b128 v[44:47], v[50:51], off offset:16         // 0000005A5F48: DC5E0010 2C7C0032
	v_add_co_ci_u32_e64 v59, null, s15, v49, s4                // 0000005A5F50: D5207C3B 0012620F
	v_add_co_ci_u32_e64 v49, null, 0, v57, s0                  // 0000005A5F58: D5207C31 00027280
	.long 0xd7000440                                           // 0000005A5F60: D7000440
	v_cndmask_b32_e32 v0, v50, v14, vcc_lo                     // 0000005A5F64: 02001D32
	v_add_co_ci_u32_e64 v50, null, 0, v57, vcc_lo              // 0000005A5F68: D5207C32 01AA7280
	.long 0xd7000030                                           // 0000005A5F70: D7000030
	v_cndmask_b32_e32 v1, v68, v54, vcc_lo                     // 0000005A5F74: 02026D44
	v_add_co_ci_u32_e64 v65, null, s15, v51, s4                // 0000005A5F78: D5207C41 0012660F
	.long 0xd7006a33                                           // 0000005A5F80: D7006A33
	v_cndmask_b32_e32 v1, v55, v53, vcc_lo                     // 0000005A5F84: 02026B37
	v_add_co_ci_u32_e64 v49, null, 0, v49, s0                  // 0000005A5F88: D5207C31 00026280
	v_add_co_ci_u32_e64 v55, null, 0, v50, vcc_lo              // 0000005A5F90: D5207C37 01AA6480
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005A5F98: BF870003
	.long 0xd7006a36                                           // 0000005A5F9C: D7006A36
	v_cndmask_b32_e32 v1, v51, v54, vcc_lo                     // 0000005A5FA0: 02026D33
	global_load_b128 v[48:51], v[48:49], off offset:128        // 0000005A5FA4: DC5E0080 307C0030
	v_add_co_ci_u32_e64 v53, null, 0, v57, s1                  // 0000005A5FAC: D5207C35 00067280
	v_add_co_ci_u32_e64 v55, null, 0, v55, vcc_lo              // 0000005A5FB4: D5207C37 01AA6E80
	s_clause 0x2                                               // 0000005A5FBC: BF850002
	global_load_i8 v71, v[52:53], off offset:192               // 0000005A5FC0: DC4600C0 477C0034
	global_load_b128 v[52:55], v[54:55], off                   // 0000005A5FC8: DC5E0000 347C0036
	global_load_d16_b16 v56, v[56:57], off offset:208          // 0000005A5FD0: DC8200D0 387C0038
	v_or_b32_e32 v63, 8, v61                                   // 0000005A5FD8: 387E7A88
	v_or_b32_e32 v70, 24, v61                                  // 0000005A5FDC: 388C7A98
	v_or_b32_e32 v62, 8, v60                                   // 0000005A5FE0: 387C7888
	v_or_b32_e32 v66, 16, v61                                  // 0000005A5FE4: 38847A90
	v_or_b32_e32 v67, 24, v60                                  // 0000005A5FE8: 38867898
	v_or_b32_e32 v2, 16, v60                                   // 0000005A5FEC: 38047890
	.long 0xd7000144                                           // 0000005A5FF0: D7000144
	v_cndmask_b32_e32 v0, v58, v14, vcc_lo                     // 0000005A5FF4: 02001D3A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005A5FF8: BF870001
	v_add_co_ci_u32_e64 v69, null, s15, v59, s1                // 0000005A5FFC: D5207C45 0006760F
	s_waitcnt vmcnt(3)                                         // 0000005A6004: BF890FF7
	v_lshrrev_b32_e32 v82, v70, v50                            // 0000005A6008: 32A46546
	v_lshrrev_b32_e32 v84, v63, v51                            // 0000005A600C: 32A8673F
	v_lshrrev_b32_e32 v85, v66, v51                            // 0000005A6010: 32AA6742
	v_lshrrev_b32_e32 v86, v70, v51                            // 0000005A6014: 32AC6746
	v_lshrrev_b32_e32 v73, v66, v48                            // 0000005A6018: 32926142
	v_lshlrev_b32_e32 v82, 4, v82                              // 0000005A601C: 30A4A484
	s_waitcnt vmcnt(1)                                         // 0000005A6020: BF8907F7
	v_bfe_u32 v94, v54, v67, 4                                 // 0000005A6024: D610005E 02128736
	v_bfe_u32 v96, v55, v62, 4                                 // 0000005A602C: D6100060 02127D37
	v_lshlrev_b32_e32 v84, 4, v84                              // 0000005A6034: 30A8A884
	v_lshrrev_b32_e32 v77, v66, v49                            // 0000005A6038: 329A6342
	v_lshrrev_b32_e32 v81, v66, v50                            // 0000005A603C: 32A26542
	v_bfe_u32 v66, v52, v2, 4                                  // 0000005A6040: D6100042 02120534
	v_bfe_u32 v89, v53, v2, 4                                  // 0000005A6048: D6100059 02120535
	v_bfe_u32 v93, v54, v2, 4                                  // 0000005A6050: D610005D 02120536
	v_bfe_u32 v2, v55, v2, 4                                   // 0000005A6058: D6100002 02120537
	v_bfe_u32 v97, v55, v67, 4                                 // 0000005A6060: D6100061 02128737
	v_lshlrev_b32_e32 v85, 4, v85                              // 0000005A6068: 30AAAA84
	v_lshlrev_b32_e32 v86, 4, v86                              // 0000005A606C: 30ACAC84
	v_and_or_b32 v82, v82, 48, v94                             // 0000005A6070: D6570052 05796152
	v_and_or_b32 v84, v84, 48, v96                             // 0000005A6078: D6570054 05816154
	v_lshrrev_b32_e32 v57, v61, v48                            // 0000005A6080: 3272613D
	v_lshrrev_b32_e32 v72, v63, v48                            // 0000005A6084: 3290613F
	v_lshrrev_b32_e32 v74, v70, v48                            // 0000005A6088: 32946146
	v_lshrrev_b32_e32 v75, v61, v49                            // 0000005A608C: 3296633D
	v_lshrrev_b32_e32 v76, v63, v49                            // 0000005A6090: 3298633F
	v_lshrrev_b32_e32 v78, v70, v49                            // 0000005A6094: 329C6346
	v_lshrrev_b32_e32 v79, v61, v50                            // 0000005A6098: 329E653D
	v_lshrrev_b32_e32 v80, v63, v50                            // 0000005A609C: 32A0653F
	v_lshrrev_b32_e32 v83, v61, v51                            // 0000005A60A0: 32A6673D
	v_bfe_u32 v61, v52, v60, 4                                 // 0000005A60A4: D610003D 02127934
	v_bfe_u32 v63, v52, v62, 4                                 // 0000005A60AC: D610003F 02127D34
	v_bfe_u32 v70, v52, v67, 4                                 // 0000005A60B4: D6100046 02128734
	v_bfe_u32 v87, v53, v60, 4                                 // 0000005A60BC: D6100057 02127935
	v_bfe_u32 v88, v53, v62, 4                                 // 0000005A60C4: D6100058 02127D35
	v_bfe_u32 v90, v53, v67, 4                                 // 0000005A60CC: D610005A 02128735
	v_bfe_u32 v91, v54, v60, 4                                 // 0000005A60D4: D610005B 02127936
	v_bfe_u32 v92, v54, v62, 4                                 // 0000005A60DC: D610005C 02127D36
	v_bfe_u32 v95, v55, v60, 4                                 // 0000005A60E4: D610005F 02127937
	s_clause 0x1                                               // 0000005A60EC: BF850001
	global_load_b128 v[48:51], v[58:59], off                   // 0000005A60F0: DC5E0000 307C003A
	global_load_b128 v[52:55], v[58:59], off offset:16         // 0000005A60F8: DC5E0010 347C003A
	v_cvt_f32_i32_e32 v58, v71                                 // 0000005A6100: 7E740B47
	v_and_or_b32 v2, v85, 48, v2                               // 0000005A6104: D6570002 04096155
	v_and_or_b32 v85, v86, 48, v97                             // 0000005A610C: D6570055 05856156
	v_subrev_nc_u32_e32 v82, 32, v82                           // 0000005A6114: 4EA4A4A0
	v_subrev_nc_u32_e32 v84, 32, v84                           // 0000005A6118: 4EA8A8A0
	v_lshlrev_b32_e32 v81, 4, v81                              // 0000005A611C: 30A2A284
	v_subrev_nc_u32_e32 v2, 32, v2                             // 0000005A6120: 4E0404A0
	v_subrev_nc_u32_e32 v85, 32, v85                           // 0000005A6124: 4EAAAAA0
	v_cvt_f32_i32_e32 v82, v82                                 // 0000005A6128: 7EA40B52
	v_lshlrev_b32_e32 v59, 4, v72                              // 0000005A612C: 30769084
	s_waitcnt vmcnt(2)                                         // 0000005A6130: BF890BF7
	v_fma_mix_f32 v72, v56, v58, neg(0) op_sel_hi:[1,0,0]      // 0000005A6134: CC200048 8A027538
	v_cvt_f32_i32_e32 v84, v84                                 // 0000005A613C: 7EA80B54
	v_lshlrev_b32_e32 v67, 4, v78                              // 0000005A6140: 30869C84
	v_cvt_f32_i32_e32 v85, v85                                 // 0000005A6144: 7EAA0B55
	v_lshlrev_b32_e32 v71, 4, v80                              // 0000005A6148: 308EA084
	v_and_or_b32 v81, v81, 48, v93                             // 0000005A614C: D6570051 05756151
	v_mul_f32_e32 v84, v72, v84                                // 0000005A6154: 10A8A948
	v_and_or_b32 v78, v67, 48, v90                             // 0000005A6158: D657004E 05696143
	v_cvt_f32_i32_e32 v2, v2                                   // 0000005A6160: 7E040B02
	v_and_or_b32 v80, v71, 48, v92                             // 0000005A6164: D6570050 05716147
	v_subrev_nc_u32_e32 v81, 32, v81                           // 0000005A616C: 4EA2A2A0
	v_mul_f32_e32 v82, v72, v82                                // 0000005A6170: 10A4A548
	v_subrev_nc_u32_e32 v78, 32, v78                           // 0000005A6174: 4E9C9CA0
	v_and_or_b32 v99, v59, 48, v63                             // 0000005A6178: D6570063 04FD613B
	v_subrev_nc_u32_e32 v80, 32, v80                           // 0000005A6180: 4EA0A0A0
	v_dual_mul_f32 v2, v72, v2 :: v_dual_lshlrev_b32 v63, 4, v76// 0000005A6184: C8E20548 023E9884
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005A618C: BF870224
	v_cvt_f32_i32_e32 v78, v78                                 // 0000005A6190: 7E9C0B4E
	v_lshlrev_b32_e32 v57, 4, v57                              // 0000005A6194: 30727284
	v_cvt_f32_i32_e32 v80, v80                                 // 0000005A6198: 7EA00B50
	v_cvt_f32_i32_e32 v81, v81                                 // 0000005A619C: 7EA20B51
	v_lshlrev_b32_e32 v62, 4, v75                              // 0000005A61A0: 307C9684
	v_mul_f32_e32 v78, v72, v78                                // 0000005A61A4: 109C9D48
	v_and_or_b32 v98, v57, 48, v61                             // 0000005A61A8: D6570062 04F56139
	v_dual_mul_f32 v80, v72, v80 :: v_dual_lshlrev_b32 v61, 4, v74// 0000005A61B0: C8E2A148 503C9484
	global_load_b128 v[56:59], v[64:65], off                   // 0000005A61B8: DC5E0000 387C0040
	v_and_or_b32 v76, v63, 48, v88                             // 0000005A61C0: D657004C 0561613F
	v_lshlrev_b32_e32 v83, 4, v83                              // 0000005A61C8: 30A6A684
	v_and_or_b32 v74, v61, 48, v70                             // 0000005A61CC: D657004A 0519613D
	v_dual_mul_f32 v81, v72, v81 :: v_dual_lshlrev_b32 v70, 4, v79// 0000005A61D4: C8E2A348 51469E84
	v_and_or_b32 v75, v62, 48, v87                             // 0000005A61DC: D657004B 055D613E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005A61E4: BF870224
	v_and_or_b32 v83, v83, 48, v95                             // 0000005A61E8: D6570053 057D6153
	v_subrev_nc_u32_e32 v86, 32, v98                           // 0000005A61F0: 4EACC4A0
	v_and_or_b32 v79, v70, 48, v91                             // 0000005A61F4: D657004F 056D6146
	v_subrev_nc_u32_e32 v87, 32, v99                           // 0000005A61FC: 4EAEC6A0
	v_subrev_nc_u32_e32 v74, 32, v74                           // 0000005A6200: 4E9494A0
	v_subrev_nc_u32_e32 v83, 32, v83                           // 0000005A6204: 4EA6A6A0
	v_subrev_nc_u32_e32 v75, 32, v75                           // 0000005A6208: 4E9696A0
	v_subrev_nc_u32_e32 v79, 32, v79                           // 0000005A620C: 4E9E9EA0
	v_subrev_nc_u32_e32 v76, 32, v76                           // 0000005A6210: 4E9898A0
	v_cvt_f32_i32_e32 v86, v86                                 // 0000005A6214: 7EAC0B56
	v_cvt_f32_i32_e32 v83, v83                                 // 0000005A6218: 7EA60B53
	v_cvt_f32_i32_e32 v87, v87                                 // 0000005A621C: 7EAE0B57
	v_cvt_f32_i32_e32 v79, v79                                 // 0000005A6220: 7E9E0B4F
	v_lshlrev_b32_e32 v60, 4, v73                              // 0000005A6224: 30789284
	v_cvt_f32_i32_e32 v74, v74                                 // 0000005A6228: 7E940B4A
	v_mul_f32_e32 v83, v72, v83                                // 0000005A622C: 10A6A748
	v_cvt_f32_i32_e32 v75, v75                                 // 0000005A6230: 7E960B4B
	v_mul_f32_e32 v79, v72, v79                                // 0000005A6234: 109E9F48
	v_and_or_b32 v73, v60, 48, v66                             // 0000005A6238: D6570049 0509613C
	global_load_b128 v[60:63], v[68:69], off                   // 0000005A6240: DC5E0000 3C7C0044
	v_lshlrev_b32_e32 v66, 4, v77                              // 0000005A6248: 30849A84
	global_load_b128 v[68:71], v[68:69], off offset:16         // 0000005A624C: DC5E0010 447C0044
	v_cvt_f32_i32_e32 v76, v76                                 // 0000005A6254: 7E980B4C
	v_subrev_nc_u32_e32 v73, 32, v73                           // 0000005A6258: 4E9292A0
	v_mul_f32_e32 v86, v72, v86                                // 0000005A625C: 10ACAD48
	v_and_or_b32 v77, v66, 48, v89                             // 0000005A6260: D657004D 05656142
	global_load_b128 v[64:67], v[64:65], off offset:16         // 0000005A6268: DC5E0010 407C0040
	v_mul_f32_e32 v87, v72, v87                                // 0000005A6270: 10AEAF48
	v_cvt_f32_i32_e32 v73, v73                                 // 0000005A6274: 7E920B49
	v_mul_f32_e32 v74, v72, v74                                // 0000005A6278: 10949548
	v_subrev_nc_u32_e32 v77, 32, v77                           // 0000005A627C: 4E9A9AA0
	v_mul_f32_e32 v75, v72, v75                                // 0000005A6280: 10969748
	v_mul_f32_e32 v76, v72, v76                                // 0000005A6284: 10989948
	v_mul_f32_e32 v73, v72, v73                                // 0000005A6288: 10929348
	v_bfe_u32 v88, v87, 16, 1                                  // 0000005A628C: D6100058 02052157
	v_cvt_f32_i32_e32 v77, v77                                 // 0000005A6294: 7E9A0B4D
	v_bfe_u32 v90, v74, 16, 1                                  // 0000005A6298: D610005A 0205214A
	v_bfe_u32 v91, v75, 16, 1                                  // 0000005A62A0: D610005B 0205214B
	v_bfe_u32 v89, v73, 16, 1                                  // 0000005A62A8: D6100059 02052149
	v_add3_u32 v87, v87, v88, 0x7fff                           // 0000005A62B0: D6550057 03FEB157 00007FFF
	v_mul_f32_e32 v77, v72, v77                                // 0000005A62BC: 109A9B48
	v_mul_f32_e32 v72, v72, v85                                // 0000005A62C0: 1090AB48
	v_bfe_u32 v85, v86, 16, 1                                  // 0000005A62C4: D6100055 02052156
	v_bfe_u32 v88, v79, 16, 1                                  // 0000005A62CC: D6100058 0205214F
	v_add3_u32 v73, v73, v89, 0x7fff                           // 0000005A62D4: D6550049 03FEB349 00007FFF
	v_bfe_u32 v92, v76, 16, 1                                  // 0000005A62E0: D610005C 0205214C
	v_add3_u32 v74, v74, v90, 0x7fff                           // 0000005A62E8: D655004A 03FEB54A 00007FFF
	v_add3_u32 v85, v86, v85, 0x7fff                           // 0000005A62F4: D6550055 03FEAB56 00007FFF
	v_bfe_u32 v86, v78, 16, 1                                  // 0000005A6300: D6100056 0205214E
	v_add3_u32 v79, v79, v88, 0x7fff                           // 0000005A6308: D655004F 03FEB14F 00007FFF
	v_bfe_u32 v88, v72, 16, 1                                  // 0000005A6314: D6100058 02052148
	v_bfe_u32 v93, v77, 16, 1                                  // 0000005A631C: D610005D 0205214D
	.long 0x7eae39d5                                           // 0000005A6324: 7EAE39D5
	v_add3_u32 v78, v78, v86, 0x7fff                           // 0000005A6328: D655004E 03FEAD4E 00007FFF
	v_bfe_u32 v86, v2, 16, 1                                   // 0000005A6334: D6100056 02052102
	v_add3_u32 v72, v72, v88, 0x7fff                           // 0000005A633C: D6550048 03FEB148 00007FFF
	v_add3_u32 v75, v75, v91, 0x7fff                           // 0000005A6348: D655004B 03FEB74B 00007FFF
	.long 0x7e9439c9                                           // 0000005A6354: 7E9439C9
	v_add3_u32 v76, v76, v92, 0x7fff                           // 0000005A6358: D655004C 03FEB94C 00007FFF
	v_add3_u32 v2, v2, v86, 0x7fff                             // 0000005A6364: D6550002 03FEAD02 00007FFF
	v_add3_u32 v77, v77, v93, 0x7fff                           // 0000005A6370: D655004D 03FEBB4D 00007FFF
	.long 0x7e9839cb                                           // 0000005A637C: 7E9839CB
	v_bfe_u32 v89, v80, 16, 1                                  // 0000005A6380: D6100059 02052150
	v_bfe_u32 v90, v81, 16, 1                                  // 0000005A6388: D610005A 02052151
	.long 0x7e903982                                           // 0000005A6390: 7E903982
	v_dot2_f32_bf16 v2, v16, v87, 0                            // 0000005A6394: CC1A4002 1A02AF10
	v_dot2_f32_bf16 v16, v24, v87, 0                           // 0000005A639C: CC1A4010 1A02AF18
	v_dot2_f32_bf16 v24, v32, v87, 0                           // 0000005A63A4: CC1A4018 1A02AF20
	v_dot2_f32_bf16 v32, v40, v87, 0                           // 0000005A63AC: CC1A4020 1A02AF28
	.long 0x7e9c39cd                                           // 0000005A63B4: 7E9C39CD
	v_dot2_f32_bf16 v2, v17, v74, v2                           // 0000005A63B8: CC1A4002 1C0A9511
	v_dot2_f32_bf16 v16, v25, v74, v16                         // 0000005A63C0: CC1A4010 1C429519
	v_dot2_f32_bf16 v17, v33, v74, v24                         // 0000005A63C8: CC1A4011 1C629521
	v_dot2_f32_bf16 v24, v41, v74, v32                         // 0000005A63D0: CC1A4018 1C829529
	v_bfe_u32 v91, v82, 16, 1                                  // 0000005A63D8: D610005B 02052152
	v_dot2_f32_bf16 v2, v18, v76, v2                           // 0000005A63E0: CC1A4002 1C0A9912
	v_dot2_f32_bf16 v16, v26, v76, v16                         // 0000005A63E8: CC1A4010 1C42991A
	v_dot2_f32_bf16 v17, v34, v76, v17                         // 0000005A63F0: CC1A4011 1C469922
	v_dot2_f32_bf16 v18, v42, v76, v24                         // 0000005A63F8: CC1A4012 1C62992A
	v_add3_u32 v80, v80, v89, 0x7fff                           // 0000005A6400: D6550050 03FEB350 00007FFF
	v_bfe_u32 v92, v83, 16, 1                                  // 0000005A640C: D610005C 02052153
	v_add3_u32 v81, v81, v90, 0x7fff                           // 0000005A6414: D6550051 03FEB551 00007FFF
	.long 0x7ea039cf                                           // 0000005A6420: 7EA039CF
	v_dot2_f32_bf16 v16, v27, v78, v16                         // 0000005A6424: CC1A4010 1C429D1B
	v_dot2_f32_bf16 v2, v19, v78, v2                           // 0000005A642C: CC1A4002 1C0A9D13
	v_dot2_f32_bf16 v17, v35, v78, v17                         // 0000005A6434: CC1A4011 1C469D23
	v_dot2_f32_bf16 v18, v43, v78, v18                         // 0000005A643C: CC1A4012 1C4A9D2B
	v_bfe_u32 v93, v84, 16, 1                                  // 0000005A6444: D610005D 02052154
	v_add3_u32 v82, v82, v91, 0x7fff                           // 0000005A644C: D6550052 03FEB752 00007FFF
	v_add3_u32 v83, v83, v92, 0x7fff                           // 0000005A6458: D6550053 03FEB953 00007FFF
	.long 0x7ea439d1                                           // 0000005A6464: 7EA439D1
	v_dot2_f32_bf16 v16, v28, v80, v16                         // 0000005A6468: CC1A4010 1C42A11C
	v_dot2_f32_bf16 v2, v20, v80, v2                           // 0000005A6470: CC1A4002 1C0AA114
	v_dot2_f32_bf16 v17, v36, v80, v17                         // 0000005A6478: CC1A4011 1C46A124
	v_dot2_f32_bf16 v18, v44, v80, v18                         // 0000005A6480: CC1A4012 1C4AA12C
	v_add3_u32 v84, v84, v93, 0x7fff                           // 0000005A6488: D6550054 03FEBB54 00007FFF
	.long 0x7ea839d3                                           // 0000005A6494: 7EA839D3
	v_dot2_f32_bf16 v16, v29, v82, v16                         // 0000005A6498: CC1A4010 1C42A51D
	v_dot2_f32_bf16 v2, v21, v82, v2                           // 0000005A64A0: CC1A4002 1C0AA515
	v_dot2_f32_bf16 v17, v37, v82, v17                         // 0000005A64A8: CC1A4011 1C46A525
	v_dot2_f32_bf16 v18, v45, v82, v18                         // 0000005A64B0: CC1A4012 1C4AA52D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005A64B8: BF870214
	v_dot2_f32_bf16 v16, v30, v84, v16                         // 0000005A64BC: CC1A4010 1C42A91E
	v_dot2_f32_bf16 v2, v22, v84, v2                           // 0000005A64C4: CC1A4002 1C0AA916
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005A64CC: BF870214
	v_dot2_f32_bf16 v17, v38, v84, v17                         // 0000005A64D0: CC1A4011 1C46A926
	v_dot2_f32_bf16 v18, v46, v84, v18                         // 0000005A64D8: CC1A4012 1C4AA92E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005A64E0: BF870004
	v_dot2_f32_bf16 v16, v31, v72, v16                         // 0000005A64E4: CC1A4010 1C42911F
	v_add_nc_u32_e32 v7, 32, v7                                // 0000005A64EC: 4A0E0EA0
	v_dot2_f32_bf16 v2, v23, v72, v2                           // 0000005A64F0: CC1A4002 1C0A9117
	v_dot2_f32_bf16 v17, v39, v72, v17                         // 0000005A64F8: CC1A4011 1C469127
	v_dot2_f32_bf16 v18, v47, v72, v18                         // 0000005A6500: CC1A4012 1C4A912F
	v_add_f32_e32 v10, v10, v16                                // 0000005A6508: 0614210A
	v_cmp_ge_i32_e32 vcc_lo, v7, v8                            // 0000005A650C: 7C8C1107
	v_add_nc_u32_e32 v1, 0x200, v1                             // 0000005A6510: 4A0202FF 00000200
	v_add_f32_e32 v9, v9, v2                                   // 0000005A6518: 06120509
	v_dual_add_f32 v15, v15, v17 :: v_dual_add_f32 v14, v14, v18// 0000005A651C: C908230F 0F0E250E
	s_or_b32 s18, vcc_lo, s18                                  // 0000005A6524: 8C12126A
	s_waitcnt vmcnt(5)                                         // 0000005A6528: BF8917F7
	v_dot2_f32_bf16 v40, v48, v87, 0                           // 0000005A652C: CC1A4028 1A02AF30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A6534: BF870091
	v_dot2_f32_bf16 v25, v49, v74, v40                         // 0000005A6538: CC1A4019 1CA29531
	v_dot2_f32_bf16 v24, v50, v76, v25                         // 0000005A6540: CC1A4018 1C669932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005A6548: BF8700A1
	v_dot2_f32_bf16 v19, v51, v78, v24                         // 0000005A654C: CC1A4013 1C629D33
	s_waitcnt vmcnt(4)                                         // 0000005A6554: BF8913F7
	v_dot2_f32_bf16 v19, v52, v80, v19                         // 0000005A6558: CC1A4013 1C4EA134
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A6560: BF870091
	v_dot2_f32_bf16 v19, v53, v82, v19                         // 0000005A6564: CC1A4013 1C4EA535
	v_dot2_f32_bf16 v19, v54, v84, v19                         // 0000005A656C: CC1A4013 1C4EA936
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000005A6574: BF870131
	v_dot2_f32_bf16 v19, v55, v72, v19                         // 0000005A6578: CC1A4013 1C4E9137
	s_waitcnt vmcnt(3)                                         // 0000005A6580: BF890FF7
	v_dot2_f32_bf16 v48, v56, v87, 0                           // 0000005A6584: CC1A4030 1A02AF38
	v_add_f32_e32 v13, v13, v19                                // 0000005A658C: 061A270D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A6590: BF870092
	v_dot2_f32_bf16 v32, v57, v74, v48                         // 0000005A6594: CC1A4020 1CC29539
	v_dot2_f32_bf16 v25, v58, v76, v32                         // 0000005A659C: CC1A4019 1C82993A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005A65A4: BF8700B1
	v_dot2_f32_bf16 v24, v59, v78, v25                         // 0000005A65A8: CC1A4018 1C669D3B
	s_waitcnt vmcnt(2)                                         // 0000005A65B0: BF890BF7
	v_dot2_f32_bf16 v56, v60, v87, 0                           // 0000005A65B4: CC1A4038 1A02AF3C
	v_dot2_f32_bf16 v33, v61, v74, v56                         // 0000005A65BC: CC1A4021 1CE2953D
	s_waitcnt vmcnt(0)                                         // 0000005A65C4: BF8903F7
	v_dot2_f32_bf16 v20, v64, v80, v24                         // 0000005A65C8: CC1A4014 1C62A140
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005A65D0: BF870112
	v_dot2_f32_bf16 v26, v62, v76, v33                         // 0000005A65D4: CC1A401A 1C86993E
	v_dot2_f32_bf16 v20, v65, v82, v20                         // 0000005A65DC: CC1A4014 1C52A541
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005A65E4: BF870112
	v_dot2_f32_bf16 v25, v63, v78, v26                         // 0000005A65E8: CC1A4019 1C6A9D3F
	v_dot2_f32_bf16 v20, v66, v84, v20                         // 0000005A65F0: CC1A4014 1C52A942
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005A65F8: BF870112
	v_dot2_f32_bf16 v24, v68, v80, v25                         // 0000005A65FC: CC1A4018 1C66A144
	v_dot2_f32_bf16 v20, v67, v72, v20                         // 0000005A6604: CC1A4014 1C529143
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005A660C: BF870112
	v_dot2_f32_bf16 v21, v69, v82, v24                         // 0000005A6610: CC1A4015 1C62A545
	v_add_f32_e32 v12, v12, v20                                // 0000005A6618: 0618290C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A661C: BF870092
	v_dot2_f32_bf16 v21, v70, v84, v21                         // 0000005A6620: CC1A4015 1C56A946
	v_dot2_f32_bf16 v21, v71, v72, v21                         // 0000005A6628: CC1A4015 1C569147
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005A6630: BF870001
	v_add_f32_e32 v11, v11, v21                                // 0000005A6634: 06162B0B
	s_and_not1_b32 exec_lo, exec_lo, s18                       // 0000005A6638: 917E127E
	s_cbranch_execnz 65026                                     // 0000005A663C: BFA6FE02 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi7ELi32ELi8ELb0EEEvPKhPKtPvll+0x148>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000005A6640: 8C7E127E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005A6644: BF8700B9
	s_or_b32 exec_lo, exec_lo, s16                             // 0000005A6648: 8C7E107E
	.long 0xd71f0001                                           // 0000005A664C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000005A6650: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000005A6654: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000005A6658: 3A040290
	v_xor_b32_e32 v18, 8, v1                                   // 0000005A665C: 3A240288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005A6660: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000005A6664: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000005A6668: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000005A666C: 7C9824A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005A6670: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000005A6674: 30040482
	ds_bpermute_b32 v3, v2, v9                                 // 0000005A6678: DACC0000 03000902
	s_waitcnt lgkmcnt(0)                                       // 0000005A6680: BF89FC07
	v_add_f32_e32 v3, v9, v3                                   // 0000005A6684: 06060709
	ds_bpermute_b32 v16, v2, v13                               // 0000005A6688: DACC0000 10000D02
	ds_bpermute_b32 v7, v2, v15                                // 0000005A6690: DACC0000 07000F02
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 0000005A6698: 02242501
	ds_bpermute_b32 v4, v2, v10                                // 0000005A669C: DACC0000 04000A02
	ds_bpermute_b32 v8, v2, v14                                // 0000005A66A4: DACC0000 08000E02
	ds_bpermute_b32 v17, v2, v12                               // 0000005A66AC: DACC0000 11000C02
	ds_bpermute_b32 v2, v2, v11                                // 0000005A66B4: DACC0000 02000B02
	s_waitcnt lgkmcnt(5)                                       // 0000005A66BC: BF89FC57
	v_dual_add_f32 v9, v13, v16 :: v_dual_lshlrev_b32 v18, 2, v18// 0000005A66C0: C922210D 09122482
	s_waitcnt lgkmcnt(4)                                       // 0000005A66C8: BF89FC47
	v_add_f32_e32 v7, v15, v7                                  // 0000005A66CC: 060E0F0F
	ds_bpermute_b32 v15, v18, v9                               // 0000005A66D0: DACC0000 0F000912
	s_waitcnt lgkmcnt(3)                                       // 0000005A66D8: BF89FC37
	v_add_f32_e32 v8, v14, v8                                  // 0000005A66DC: 0610110E
	ds_bpermute_b32 v13, v18, v7                               // 0000005A66E0: DACC0000 0D000712
	s_waitcnt lgkmcnt(1)                                       // 0000005A66E8: BF89FC17
	v_dual_add_f32 v4, v10, v4 :: v_dual_add_f32 v9, v9, v15   // 0000005A66EC: C908090A 04081F09
	v_add_f32_e32 v2, v11, v2                                  // 0000005A66F4: 0604050B
	ds_bpermute_b32 v11, v18, v3                               // 0000005A66F8: DACC0000 0B000312
	ds_bpermute_b32 v14, v18, v8                               // 0000005A6700: DACC0000 0E000812
	s_waitcnt lgkmcnt(2)                                       // 0000005A6708: BF89FC27
	v_add_f32_e32 v7, v7, v13                                  // 0000005A670C: 060E1B07
	s_waitcnt lgkmcnt(1)                                       // 0000005A6710: BF89FC17
	v_dual_add_f32 v3, v3, v11 :: v_dual_add_f32 v10, v12, v17 // 0000005A6714: C9081703 030A230C
	ds_bpermute_b32 v12, v18, v4                               // 0000005A671C: DACC0000 0C000412
	ds_bpermute_b32 v17, v18, v2                               // 0000005A6724: DACC0000 11000212
	ds_bpermute_b32 v16, v18, v10                              // 0000005A672C: DACC0000 10000A12
	v_xor_b32_e32 v18, 4, v1                                   // 0000005A6734: 3A240284
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005A6738: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000005A673C: 7C9824A0
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 0000005A6740: 02242501
	v_lshlrev_b32_e32 v18, 2, v18                              // 0000005A6744: 30242482
	s_waitcnt lgkmcnt(2)                                       // 0000005A6748: BF89FC27
	v_add_f32_e32 v4, v4, v12                                  // 0000005A674C: 06081904
	ds_bpermute_b32 v15, v18, v9                               // 0000005A6750: DACC0000 0F000912
	ds_bpermute_b32 v11, v18, v3                               // 0000005A6758: DACC0000 0B000312
	s_waitcnt lgkmcnt(1)                                       // 0000005A6760: BF89FC17
	v_dual_add_f32 v9, v9, v15 :: v_dual_add_f32 v2, v2, v17   // 0000005A6764: C9081F09 09022302
	s_waitcnt lgkmcnt(0)                                       // 0000005A676C: BF89FC07
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v3, v3, v11   // 0000005A6770: C9081D08 08021703
	v_add_f32_e32 v10, v10, v16                                // 0000005A6778: 0614210A
	ds_bpermute_b32 v17, v18, v2                               // 0000005A677C: DACC0000 11000212
	s_waitcnt lgkmcnt(0)                                       // 0000005A6784: BF89FC07
	v_add_f32_e32 v11, v2, v17                                 // 0000005A6788: 06162302
	ds_bpermute_b32 v12, v18, v4                               // 0000005A678C: DACC0000 0C000412
	ds_bpermute_b32 v13, v18, v7                               // 0000005A6794: DACC0000 0D000712
	ds_bpermute_b32 v14, v18, v8                               // 0000005A679C: DACC0000 0E000812
	ds_bpermute_b32 v16, v18, v10                              // 0000005A67A4: DACC0000 10000A12
	v_xor_b32_e32 v18, 2, v1                                   // 0000005A67AC: 3A240282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005A67B0: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000005A67B4: 7C9824A0
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 0000005A67B8: 02242501
	v_lshlrev_b32_e32 v18, 2, v18                              // 0000005A67BC: 30242482
	s_waitcnt lgkmcnt(2)                                       // 0000005A67C0: BF89FC27
	v_dual_add_f32 v4, v4, v12 :: v_dual_add_f32 v7, v7, v13   // 0000005A67C4: C9081904 04061B07
	s_waitcnt lgkmcnt(1)                                       // 0000005A67CC: BF89FC17
	v_add_f32_e32 v8, v8, v14                                  // 0000005A67D0: 06101D08
	s_waitcnt lgkmcnt(0)                                       // 0000005A67D4: BF89FC07
	v_add_f32_e32 v10, v10, v16                                // 0000005A67D8: 0614210A
	ds_bpermute_b32 v2, v18, v3                                // 0000005A67DC: DACC0000 02000312
	ds_bpermute_b32 v12, v18, v4                               // 0000005A67E4: DACC0000 0C000412
	ds_bpermute_b32 v13, v18, v7                               // 0000005A67EC: DACC0000 0D000712
	ds_bpermute_b32 v14, v18, v8                               // 0000005A67F4: DACC0000 0E000812
	ds_bpermute_b32 v15, v18, v9                               // 0000005A67FC: DACC0000 0F000912
	ds_bpermute_b32 v16, v18, v10                              // 0000005A6804: DACC0000 10000A12
	ds_bpermute_b32 v17, v18, v11                              // 0000005A680C: DACC0000 11000B12
	v_xor_b32_e32 v18, 1, v1                                   // 0000005A6814: 3A240281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005A6818: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000005A681C: 7C9824A0
	s_waitcnt lgkmcnt(5)                                       // 0000005A6820: BF89FC57
	v_dual_cndmask_b32 v1, v1, v18 :: v_dual_add_f32 v4, v4, v12// 0000005A6824: CA482501 01041904
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v18, 2, v1 // 0000005A682C: C9220503 01120282
	s_waitcnt lgkmcnt(4)                                       // 0000005A6834: BF89FC47
	v_add_f32_e32 v2, v7, v13                                  // 0000005A6838: 06041B07
	s_waitcnt lgkmcnt(2)                                       // 0000005A683C: BF89FC27
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v3, v9, v15   // 0000005A6840: C9081D08 08021F09
	s_waitcnt lgkmcnt(0)                                       // 0000005A6848: BF89FC07
	v_dual_add_f32 v14, v10, v16 :: v_dual_add_f32 v7, v11, v17// 0000005A684C: C908210A 0E06230B
	ds_bpermute_b32 v9, v18, v1                                // 0000005A6854: DACC0000 09000112
	ds_bpermute_b32 v12, v18, v4                               // 0000005A685C: DACC0000 0C000412
	ds_bpermute_b32 v10, v18, v2                               // 0000005A6864: DACC0000 0A000212
	ds_bpermute_b32 v15, v18, v8                               // 0000005A686C: DACC0000 0F000812
	ds_bpermute_b32 v11, v18, v3                               // 0000005A6874: DACC0000 0B000312
	ds_bpermute_b32 v16, v18, v14                              // 0000005A687C: DACC0000 10000E12
	ds_bpermute_b32 v13, v18, v7                               // 0000005A6884: DACC0000 0D000712
	v_cmpx_eq_u32_e32 0, v6                                    // 0000005A688C: 7D940C80
	s_cbranch_execz 18                                         // 0000005A6890: BFA50012 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi7ELi32ELi8ELb0EEEvPKhPKtPvll+0xbdc>
	s_waitcnt lgkmcnt(1)                                       // 0000005A6894: BF89FC17
	v_dual_add_f32 v6, v14, v16 :: v_dual_add_f32 v1, v1, v9   // 0000005A6898: C908210E 06001301
	v_dual_add_f32 v4, v4, v12 :: v_dual_add_f32 v3, v3, v11   // 0000005A68A0: C9081904 04021703
	v_mul_u32_u24_e32 v5, 28, v5                               // 0000005A68A8: 160A0A9C
	s_waitcnt lgkmcnt(0)                                       // 0000005A68AC: BF89FC07
	v_dual_add_f32 v8, v8, v15 :: v_dual_add_f32 v7, v7, v13   // 0000005A68B0: C9081F08 08061B07
	v_add_f32_e32 v2, v2, v10                                  // 0000005A68B8: 06041502
	ds_store_2addr_b32 v5, v1, v4 offset1:1                    // 0000005A68BC: D8380100 00040105
	ds_store_2addr_b32 v5, v2, v8 offset0:2 offset1:3          // 0000005A68C4: D8380302 00080205
	ds_store_2addr_b32 v5, v3, v6 offset0:4 offset1:5          // 0000005A68CC: D8380504 00060305
	ds_store_b32 v5, v7 offset:24                              // 0000005A68D4: D8340018 00000705
	s_or_b32 exec_lo, exec_lo, s0                              // 0000005A68DC: 8C7E007E
	.long 0xd4540000                                           // 0000005A68E0: D4540000
	v_cndmask_b32_e32 v0, s12, v2, vcc_lo                      // 0000005A68E4: 0200040C
	v_cmp_gt_u32_e32 vcc_lo, 7, v0                             // 0000005A68E8: 7C980087
	s_waitcnt lgkmcnt(0)                                       // 0000005A68EC: BF89FC07
	s_barrier                                                  // 0000005A68F0: BFBD0000
	buffer_gl0_inv                                             // 0000005A68F4: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 0000005A68FC: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005A6900: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000005A6904: BE812000
	s_cbranch_execz 50                                         // 0000005A6908: BFA50032 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi7ELi32ELi8ELb0EEEvPKhPKtPvll+0xcd4>
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000005A690C: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 1                               // 0000005A6910: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:7                     // 0000005A6914: D8DC0700 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:14 offset1:21         // 0000005A691C: D8DC150E 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:28 offset1:35         // 0000005A6924: D8DC231C 05000007
	s_waitcnt lgkmcnt(2)                                       // 0000005A692C: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 0000005A6930: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005A6934: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 0000005A6938: 06020501
	s_waitcnt lgkmcnt(1)                                       // 0000005A693C: BF89FC17
	v_add_f32_e32 v1, v1, v3                                   // 0000005A6940: 06020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000005A6944: BF870131
	v_add_f32_e32 v3, v1, v4                                   // 0000005A6948: 06060901
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 0000005A694C: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(0)                                       // 0000005A6954: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 0000005A6958: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000005A695C: BF8700D1
	v_add_f32_e32 v4, v3, v6                                   // 0000005A6960: 06080D03
	ds_load_2addr_b32 v[7:8], v7 offset0:42 offset1:49         // 0000005A6964: D8DC312A 07000007
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 0000005A696C: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 0000005A6974: BF89FC07
	v_add_f32_e32 v0, v4, v7                                   // 0000005A6978: 06000F04
	v_add_f32_e32 v3, v0, v8                                   // 0000005A697C: 06061100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005A6980: BF870113
	.long 0xd73c0000                                           // 0000005A6984: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000005A6988: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 0000005A698C: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A6994: BF870092
	.long 0xd7006a00                                           // 0000005A6998: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000005A699C: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000005A69A0: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005A69A8: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000005A69AC: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 0000005A69B8: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000005A69BC: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005A69C0: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000005A69C4: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000005A69CC: DC960000 007C0200
	s_nop 0                                                    // 0000005A69D4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000005A69D8: BFB60003
	s_endpgm                                                   // 0000005A69DC: BFB00000
		...

