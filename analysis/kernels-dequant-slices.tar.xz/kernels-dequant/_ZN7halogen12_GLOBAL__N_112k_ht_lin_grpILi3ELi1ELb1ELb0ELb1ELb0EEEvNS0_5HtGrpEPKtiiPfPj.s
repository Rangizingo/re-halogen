00000000003df100 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj>:
; _ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj():
	s_clause 0x1                                               // 0000003DF100: BF850001
	s_load_b64 s[4:5], s[0:1], 0x130                           // 0000003DF104: F4040100 F8000130
	s_load_b128 s[16:19], s[0:1], 0x198                        // 0000003DF10C: F4080400 F8000198
	s_waitcnt lgkmcnt(0)                                       // 0000003DF114: BF89FC07
	s_cmp_eq_u64 s[4:5], 0                                     // 0000003DF118: BF108004
	s_cbranch_scc1 246                                         // 0000003DF11C: BFA200F6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f8>
	s_load_b32 s6, s[0:1], 0x138                               // 0000003DF120: F4000180 F8000138
	s_waitcnt lgkmcnt(0)                                       // 0000003DF128: BF89FC07
	s_cmp_lt_i32 s2, s6                                        // 0000003DF12C: BF040602
	s_cselect_b32 s3, -1, 0                                    // 0000003DF130: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000003DF134: BF030602
	s_cbranch_scc0 233                                         // 0000003DF138: BFA100E9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3e0>
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000003DF13C: 32020085
	s_sub_i32 s6, s2, s6                                       // 0000003DF140: 81860602
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000003DF144: BF870481
	v_lshl_or_b32 v1, s6, 3, v1                                // 0000003DF148: D6560001 04050606
	s_mul_i32 s6, s18, 20                                      // 0000003DF150: 96069412
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000003DF154: BF870481
	v_cmp_gt_i32_e32 vcc_lo, s6, v1                            // 0000003DF158: 7C880206
	s_and_saveexec_b32 s6, vcc_lo                              // 0000003DF15C: BE86206A
	s_cbranch_execz 222                                        // 0000003DF160: BFA500DE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3dc>
	.long 0xd72e0002                                           // 0000003DF164: D72E0002
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 0000003DF168: 020202FF 66666667
	v_and_b32_e32 v9, 31, v0                                   // 0000003DF170: 3612009F
	s_load_b64 s[8:9], s[0:1], 0x128                           // 0000003DF174: F4040200 F8000128
	s_mov_b32 s7, 0x76543210                                   // 0000003DF17C: BE8700FF 76543210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003DF184: BF8700A2
	v_lshrrev_b32_e32 v3, 31, v2                               // 0000003DF188: 3206049F
	v_ashrrev_i32_e32 v2, 3, v2                                // 0000003DF18C: 34040483
	v_add_nc_u32_e32 v8, v2, v3                                // 0000003DF190: 4A100702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003DF194: BF870121
	.long 0xd72c0002                                           // 0000003DF198: D72C0002
	v_cndmask_b32_e32 v1, 0xffffffec, v8, vcc_lo               // 0000003DF19C: 020210FF FFFFFFEC
	v_mad_i64_i32 v[4:5], null, 0x1400, v8, s[16:17]           // 0000003DF1A4: D6FF7C04 004210FF 00001400
	v_add_lshl_u32 v1, v2, v1, 7                               // 0000003DF1B0: D6470001 021E0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DF1B8: BF870091
	v_lshl_or_b32 v2, v9, 2, v1                                // 0000003DF1BC: D6560002 04050509
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000003DF1C4: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DF1C8: BF870091
	.long 0xd73c0002                                           // 0000003DF1CC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000003DF1D0: 02020481
	.long 0xd7006a04                                           // 0000003DF1D4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000003DF1D8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003DF1DC: BF8700B1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000003DF1E0: D5207C05 01AA0705
	s_waitcnt lgkmcnt(0)                                       // 0000003DF1E8: BF89FC07
	.long 0xd7006a02                                           // 0000003DF1EC: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000003DF1F0: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 0000003DF1F4: D5207C03 01AA0609
	global_load_b64 v[4:5], v[4:5], off                        // 0000003DF1FC: DC560000 047C0004
	s_mov_b32 s8, 0x3db504f3                                   // 0000003DF204: BE8800FF 3DB504F3
	global_load_b64 v[6:7], v[2:3], off                        // 0000003DF20C: DC560000 067C0002
	s_waitcnt vmcnt(1)                                         // 0000003DF214: BF8907F7
	.long 0x7e043904                                           // 0000003DF218: 7E043904
	v_and_b32_e32 v3, 0xffff0000, v4                           // 0000003DF21C: 360608FF FFFF0000
	.long 0x7e083905                                           // 0000003DF224: 7E083905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000003DF228: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003DF230: BF870004
	v_lshlrev_b32_e32 v14, 16, v2                              // 0000003DF234: 301C0490
	s_waitcnt vmcnt(0)                                         // 0000003DF238: BF8903F7
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003DF23C: CC200803 8A020706
	v_lshlrev_b32_e32 v4, 16, v4                               // 0000003DF244: 30080890
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003DF248: CC200805 8A020B07
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000003DF250: 3404029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003DF254: BF870224
	v_fma_mix_f32 v15, v6, v14, v3 op_sel_hi:[1,0,0]           // 0000003DF258: CC20000F 0C0E1D06
	v_fma_mix_f32 v6, v6, v14, -v3 op_sel_hi:[1,0,0]           // 0000003DF260: CC200006 8C0E1D06
	v_fma_mix_f32 v14, v7, v4, v5 op_sel_hi:[1,0,0]            // 0000003DF268: CC20000E 0C160907
	v_fma_mix_f32 v5, v7, v4, -v5 op_sel_hi:[1,0,0]            // 0000003DF270: CC200005 8C160907
	v_and_b32_e32 v10, 1, v0                                   // 0000003DF278: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000003DF27C: 36160082
	v_and_b32_e32 v13, 8, v0                                   // 0000003DF280: 361A0088
	.long 0xd73c0001                                           // 0000003DF284: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003DF288: 02020281
	v_add_f32_e32 v16, v6, v5                                  // 0000003DF28C: 06200B06
	v_sub_f32_e32 v5, v6, v5                                   // 0000003DF290: 080A0B06
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000003DF294: 7C941480
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DF298: BF870193
	v_mov_b32_dpp v10, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003DF29C: 7E1402FA FF016110
	v_mov_b32_dpp v17, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003DF2A4: 7E2202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003DF2AC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000003DF2B4: BF8701D1
	v_add_f32_e32 v5, v5, v17                                  // 0000003DF2B8: 060A2305
	v_mad_i64_i32 v[3:4], null, 0x1400, v8, s[4:5]             // 0000003DF2BC: D6FF7C03 001210FF 00001400
	v_add_f32_e32 v8, v15, v14                                 // 0000003DF2C8: 06101D0F
	v_sub_f32_e32 v14, v15, v14                                // 0000003DF2CC: 081C1D0F
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 0000003DF2D0: D501000F 21AA2110
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003DF2D8: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003DF2E0: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003DF2E8: BF870234
	v_mov_b32_dpp v16, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003DF2EC: 7E2002FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000003DF2F4: D501000E 21AA1D0E
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000003DF2FC: 7C941680
	v_dual_add_f32 v6, v8, v6 :: v_dual_lshlrev_b32 v7, 3, v9  // 0000003DF300: C9220D08 06061283
	v_add_f32_e32 v8, v15, v10                                 // 0000003DF308: 0610150F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003DF30C: BF870004
	v_add_f32_e32 v10, v14, v16                                // 0000003DF310: 0614210E
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003DF314: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003DF31C: D5010005 21AA0B05
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003DF324: 7E1602FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003DF32C: D5010006 21AA0D06
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003DF334: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000003DF33C: D501000A 21AA150A
	v_add_f32_e32 v5, v5, v16                                  // 0000003DF344: 060A2105
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003DF348: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003DF350: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 0000003DF358: 060C1706
	v_add_f32_e32 v10, v10, v15                                // 0000003DF35C: 06141F0A
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003DF360: 7E1E02FA FF016405
	v_and_b32_e32 v12, 4, v0                                   // 0000003DF368: 36180084
	v_add_f32_e32 v8, v8, v14                                  // 0000003DF36C: 06101D08
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003DF370: 7E1602FA FF016406
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003DF378: 7E1C02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000003DF380: BF8701C4
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 0000003DF384: 7C941880
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003DF388: D5010006 21AA0D06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003DF390: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000003DF398: D501000A 21AA150A
	v_add_f32_e32 v6, v6, v11                                  // 0000003DF3A0: 060C1706
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003DF3A4: BF870003
	v_add_f32_e32 v5, v5, v15                                  // 0000003DF3A8: 060A1F05
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003DF3AC: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003DF3B4: D5010008 21AA1108
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 0000003DF3BC: 7C941A80
	v_add_f32_e32 v10, v10, v14                                // 0000003DF3C0: 06141D0A
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003DF3C4: 7E1602FA FF016806
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003DF3CC: 7E1C02FA FF016805
	v_add_f32_e32 v8, v8, v12                                  // 0000003DF3D4: 06101908
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003DF3D8: D5010006 21AA0D06
	v_mov_b32_dpp v13, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003DF3E0: 7E1A02FA FF01680A
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003DF3E8: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000003DF3F0: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003DF3F8: 7E1802FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003DF400: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 0000003DF408: 060C1706
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 0000003DF40C: 7C981290
	v_add_f32_e32 v5, v5, v14                                  // 0000003DF410: 060A1D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003DF414: BF870214
	v_dual_add_f32 v9, v10, v13 :: v_dual_add_f32 v8, v8, v12  // 0000003DF418: C9081B0A 09081908
	v_mov_b32_e32 v10, v6                                      // 0000003DF420: 7E140306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003DF424: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003DF42C: BF870214
	v_mov_b32_e32 v13, v5                                      // 0000003DF430: 7E1A0305
	v_mov_b32_e32 v12, v9                                      // 0000003DF434: 7E180309
	v_cndmask_b32_e64 v11, -v8, v8, vcc_lo                     // 0000003DF438: D501000B 21AA1108
	v_permlanex16_b32 v8, v8, s7, 0xfedcba98                   // 0000003DF440: D65C0008 03FC0F08 FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003DF44C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003DF454: D5010009 21AA1309
	v_permlanex16_b32 v10, v10, s7, 0xfedcba98                 // 0000003DF45C: D65C000A 03FC0F0A FEDCBA98
	v_permlanex16_b32 v12, v12, s7, 0xfedcba98                 // 0000003DF468: D65C000C 03FC0F0C FEDCBA98
	v_permlanex16_b32 v13, v13, s7, 0xfedcba98                 // 0000003DF474: D65C000D 03FC0F0D FEDCBA98
	.long 0xd7006a01                                           // 0000003DF480: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 0000003DF484: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003DF488: BF8700D1
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 0000003DF48C: D5207C02 01AA0504
	v_dual_add_f32 v3, v11, v8 :: v_dual_add_f32 v4, v6, v10   // 0000003DF494: C908110B 03041506
	v_add_f32_e32 v6, v9, v12                                  // 0000003DF49C: 060C1909
	v_add_f32_e32 v5, v5, v13                                  // 0000003DF4A0: 060A1B05
	.long 0xd7006a01                                           // 0000003DF4A4: D7006A01
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 0000003DF4A8: 02020F01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000003DF4AC: D5207C02 01AA0480
	v_fma_mixhi_f16 v3, v3, s8, 0                              // 0000003DF4B4: CC220003 02001103
	v_fma_mixlo_f16 v3, v4, s8, 0                              // 0000003DF4BC: CC210003 02001104
	v_fma_mixhi_f16 v4, v5, s8, 0                              // 0000003DF4C4: CC220004 02001105
	v_fma_mixlo_f16 v4, v6, s8, 0                              // 0000003DF4CC: CC210004 02001106
	global_store_b64 v[1:2], v[3:4], off                       // 0000003DF4D4: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 0000003DF4DC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003DF4E0: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000003DF4E4: 8B6A037E
	s_cbranch_vccnz 4                                          // 0000003DF4E8: BFA40004 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3fc>
	s_nop 0                                                    // 0000003DF4EC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003DF4F0: BFB60003
	s_endpgm                                                   // 0000003DF4F4: BFB00000
	s_cbranch_execz 65532                                      // 0000003DF4F8: BFA5FFFC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_clause 0x3                                               // 0000003DF4FC: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000003DF500: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x7c                                // 0000003DF508: F4000100 F800007C
	s_load_b32 s5, s[0:1], 0xc4                                // 0000003DF510: F4000140 F80000C4
	s_load_b32 s6, s[0:1], 0x10c                               // 0000003DF518: F4000180 F800010C
	v_and_b32_e32 v41, 31, v0                                  // 0000003DF520: 3652009F
	v_lshrrev_b32_e32 v40, 5, v0                               // 0000003DF524: 32500085
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003DF528: BF870002
	v_lshlrev_b32_e32 v3, 3, v41                               // 0000003DF52C: 30065283
	s_waitcnt lgkmcnt(0)                                       // 0000003DF530: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000003DF534: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000003DF538: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 0000003DF53C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 0000003DF540: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003DF544: BF870009
	s_and_b32 s4, s7, s4                                       // 0000003DF548: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000003DF54C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000003DF550: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000003DF558: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 0000003DF55C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 0000003DF560: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003DF564: BF870009
	s_and_b32 s4, s7, s5                                       // 0000003DF568: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000003DF56C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000003DF570: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000003DF574: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000003DF578: BF030602
	s_cselect_b32 s6, -1, 0                                    // 0000003DF57C: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000003DF580: BF8704D9
	s_and_b32 s3, s3, s6                                       // 0000003DF584: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000003DF588: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000003DF58C: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000003DF590: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000003DF594: 98030483
	s_mulk_i32 s3, 0x48                                        // 0000003DF598: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003DF59C: BF870009
	s_add_u32 s4, s0, s3                                       // 0000003DF5A0: 80040300
	s_addc_u32 s5, s1, 0                                       // 0000003DF5A4: 82058001
	s_clause 0x3                                               // 0000003DF5A8: BF850003
	s_load_b32 s28, s[4:5], 0x38                               // 0000003DF5AC: F4000702 F8000038
	s_load_b64 s[30:31], s[4:5], 0x40                          // 0000003DF5B4: F4040782 F8000040
	s_load_b128 s[20:23], s[4:5], 0x28                         // 0000003DF5BC: F4080502 F8000028
	s_load_b64 s[24:25], s[4:5], 0x20                          // 0000003DF5C4: F4040602 F8000020
	s_waitcnt lgkmcnt(0)                                       // 0000003DF5CC: BF89FC07
	s_abs_i32 s3, s21                                          // 0000003DF5D0: BE831515
	s_sub_i32 s2, s2, s23                                      // 0000003DF5D4: 81821702
	s_cvt_f32_u32 s6, s3                                       // 0000003DF5D8: BE866503
	s_sub_i32 s7, 0, s3                                        // 0000003DF5DC: 81870380
	s_abs_i32 s8, s2                                           // 0000003DF5E0: BE881502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003DF5E4: BF870299
	v_rcp_iflag_f32_e32 v1, s6                                 // 0000003DF5E8: 7E025606
	v_readfirstlane_b32 s6, v1                                 // 0000003DF5EC: 7E0C0501
	s_mul_f32 s6, s6, 0x4f7ffffe                               // 0000003DF5F0: A206FF06 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000003DF5F8: BF87059B
	s_cvt_u32_f32 s6, s6                                       // 0000003DF5FC: BE866706
	s_mul_i32 s7, s7, s6                                       // 0000003DF600: 96070607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000003DF604: BF870499
	s_mul_hi_u32 s7, s6, s7                                    // 0000003DF608: 96870706
	s_add_i32 s6, s6, s7                                       // 0000003DF60C: 81060706
	s_xor_b32 s7, s2, s21                                      // 0000003DF610: 8D071502
	s_mul_hi_u32 s6, s8, s6                                    // 0000003DF614: 96860608
	s_ashr_i32 s7, s7, 31                                      // 0000003DF618: 86079F07
	s_mul_i32 s9, s6, s3                                       // 0000003DF61C: 96090306
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003DF620: BF870009
	s_sub_i32 s8, s8, s9                                       // 0000003DF624: 81880908
	s_add_i32 s9, s6, 1                                        // 0000003DF628: 81098106
	s_sub_i32 s10, s8, s3                                      // 0000003DF62C: 818A0308
	s_cmp_ge_u32 s8, s3                                        // 0000003DF630: BF090308
	s_cselect_b32 s6, s9, s6                                   // 0000003DF634: 98060609
	s_cselect_b32 s8, s10, s8                                  // 0000003DF638: 9808080A
	s_add_i32 s9, s6, 1                                        // 0000003DF63C: 81098106
	s_cmp_ge_u32 s8, s3                                        // 0000003DF640: BF090308
	s_cselect_b32 s3, s9, s6                                   // 0000003DF644: 98030609
	s_load_b256 s[8:15], s[4:5], null                          // 0000003DF648: F40C0202 F8000000
	s_xor_b32 s3, s3, s7                                       // 0000003DF650: 8D030703
	s_ashr_i32 s29, s19, 31                                    // 0000003DF654: 861D9F13
	s_sub_i32 s26, s3, s7                                      // 0000003DF658: 819A0703
	s_lshr_b32 s4, s29, 25                                     // 0000003DF65C: 8504991D
	s_mul_i32 s3, s26, s21                                     // 0000003DF660: 9603151A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000003DF664: BF8704D9
	s_sub_i32 s23, s2, s3                                      // 0000003DF668: 81970302
	s_add_i32 s2, s19, s4                                      // 0000003DF66C: 81020413
	s_mul_i32 s27, s22, s23                                    // 0000003DF670: 961B1716
	s_ashr_i32 s2, s2, 7                                       // 0000003DF674: 86028702
	s_add_i32 s3, s27, s22                                     // 0000003DF678: 8103161B
	s_min_i32 s2, s2, s3                                       // 0000003DF67C: 89020302
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003DF680: BF870009
	s_sub_i32 s7, s2, s27                                      // 0000003DF684: 81871B02
	s_mov_b32 s2, exec_lo                                      // 0000003DF688: BE82007E
	.long 0xd4c3007e                                           // 0000003DF68C: D4C3007E
	v_cndmask_b32_e32 v1, s7, v40, vcc_lo                      // 0000003DF690: 02025007
	s_xor_b32 s2, exec_lo, s2                                  // 0000003DF694: 8D02027E
	v_lshlrev_b32_e32 v3, 3, v41                               // 0000003DF698: 30065283
	s_and_not1_saveexec_b32 s22, s2                            // 0000003DF69C: BE963002
	s_cbranch_execz 288                                        // 0000003DF6A0: BFA50120 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xa24>
	s_abs_i32 s33, s7                                          // 0000003DF6A4: BEA11507
	v_lshlrev_b32_e32 v9, 7, v40                               // 0000003DF6A8: 30125087
	s_cvt_f32_u32 s2, s33                                      // 0000003DF6AC: BE826521
	v_and_b32_e32 v5, 4, v0                                    // 0000003DF6B0: 360A0084
	v_and_b32_e32 v6, 8, v0                                    // 0000003DF6B4: 360C0088
	v_lshl_or_b32 v8, v40, 8, v3                               // 0000003DF6B8: D6560008 040D1128
	v_rcp_iflag_f32_e32 v1, s2                                 // 0000003DF6C0: 7E025602
	s_sub_i32 s2, 0, s33                                       // 0000003DF6C4: 81822180
	v_lshl_add_u32 v9, s27, 7, v9                              // 0000003DF6C8: D6460009 04250E1B
	s_ashr_i32 s37, s7, 31                                     // 0000003DF6D0: 86259F07
	.long 0xd44a0004                                           // 0000003DF6D4: D44A0004
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000003DF6D8: 02020A80
	s_mul_i32 s39, s37, 0x1400                                 // 0000003DF6DC: 9627FF25 00001400
	v_mov_b32_e32 v5, v40                                      // 0000003DF6E4: 7E0A0328
	.long 0xd44a0005                                           // 0000003DF6E8: D44A0005
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 0000003DF6EC: 02020C80
	s_lshl_b32 s6, s7, 7                                       // 0000003DF6F0: 84068707
	s_add_i32 s34, s18, -1                                     // 0000003DF6F4: 8122C112
	v_dual_mul_f32 v1, 0x4f7ffffe, v1 :: v_dual_and_b32 v2, 1, v0// 0000003DF6F8: C8E402FF 01020081 4F7FFFFE
	s_mov_b32 s35, s19                                         // 0000003DF704: BEA30013
	s_mov_b32 s36, 0                                           // 0000003DF708: BEA40080
	s_lshl_b32 s38, s7, 8                                      // 0000003DF70C: 84268807
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003DF710: BF870001
	v_cvt_u32_f32_e32 v4, v1                                   // 0000003DF714: 7E080F01
	v_and_b32_e32 v1, 2, v0                                    // 0000003DF718: 36020082
	s_mov_b32 s40, 0x76543210                                  // 0000003DF71C: BEA800FF 76543210
	s_mov_b32 s41, 0x3db504f3                                  // 0000003DF724: BEA900FF 3DB504F3
	v_cmp_gt_u32_e32 vcc_lo, 16, v41                           // 0000003DF72C: 7C985290
	.long 0xd72c0007                                           // 0000003DF730: D72C0007
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 0000003DF734: 02020802
	.long 0xd44a0002                                           // 0000003DF738: D44A0002
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000003DF73C: 02020480
	.long 0xd44a0003                                           // 0000003DF740: D44A0003
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000003DF744: 02020280
	v_subrev_nc_u32_e32 v2, s39, v8                            // 0000003DF748: 4E041027
	v_lshl_or_b32 v1, v41, 2, v9                               // 0000003DF74C: D6560001 04250529
	s_sub_i32 s39, 0, s6                                       // 0000003DF754: 81A70680
	.long 0xd72d0007                                           // 0000003DF758: D72D0007
	v_cndmask_b32_e32 v1, v4, v7, vcc_lo                       // 0000003DF75C: 02020F04
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003DF760: BF870001
	v_add_nc_u32_e32 v4, v4, v7                                // 0000003DF764: 4A080F04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DF768: BF870091
	.long 0xd72d0006                                           // 0000003DF76C: D72D0006
	v_cndmask_b32_e32 v1, v5, v4, vcc_lo                       // 0000003DF770: 02020905
	.long 0xd72c0007                                           // 0000003DF774: D72C0007
	v_cndmask_b32_e32 v0, v6, v33, vcc_lo                      // 0000003DF778: 02004306
	v_add_nc_u32_e32 v8, 1, v6                                 // 0000003DF77C: 4A100C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DF780: BF870092
	v_sub_nc_u32_e32 v7, v5, v7                                // 0000003DF784: 4C0E0F05
	v_subrev_nc_u32_e32 v9, s33, v7                            // 0000003DF788: 4E120E21
	.long 0xd44b0006                                           // 0000003DF78C: D44B0006
	v_cndmask_b32_e32 v1, s33, v7, vcc_lo                      // 0000003DF790: 02020E21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DF794: BF870191
	v_cndmask_b32_e64 v6, v6, v8, s6                           // 0000003DF798: D5010006 001A1106
	v_cndmask_b32_e64 v7, v7, v9, s6                           // 0000003DF7A0: D5010007 001A1307
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DF7A8: BF870112
	v_add_nc_u32_e32 v8, 1, v6                                 // 0000003DF7AC: 4A100C81
	.long 0xd44b0006                                           // 0000003DF7B0: D44B0006
	v_cndmask_b32_e32 v1, s33, v7, vcc_lo                      // 0000003DF7B4: 02020E21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DF7B8: BF870091
	v_cndmask_b32_e64 v6, v6, v8, s6                           // 0000003DF7BC: D5010006 001A1106
	v_xor_b32_e32 v10, s37, v6                                 // 0000003DF7C4: 3A140C25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003DF7C8: BF870121
	v_subrev_nc_u32_e32 v11, s37, v10                          // 0000003DF7CC: 4E161425
	.long 0xd72c000a                                           // 0000003DF7D0: D72C000A
	v_cndmask_b32_e32 v1, 0x1400, v10, vcc_lo                  // 0000003DF7D4: 020214FF 00001400
	v_min_i32_e32 v8, s34, v11                                 // 0000003DF7DC: 22101622
	v_mad_u64_u32 v[6:7], null, s39, v11, v[1:2]               // 0000003DF7E0: D6FE7C06 04061627
	.long 0xd72c000b                                           // 0000003DF7E8: D72C000B
	v_cndmask_b32_e32 v1, s38, v11, vcc_lo                     // 0000003DF7EC: 02021626
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DF7F0: BF870193
	v_mad_i64_i32 v[8:9], null, v8, s35, 0                     // 0000003DF7F4: D6FF7C08 02004708
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000003DF7FC: 340E0C9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DF800: BF870193
	v_sub_nc_u32_e32 v10, v10, v11                             // 0000003DF804: 4C14170A
	.long 0xd73c0008                                           // 0000003DF808: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000003DF80C: 02021081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DF810: BF870193
	.long 0xd73c0006                                           // 0000003DF814: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000003DF818: 02020C81
	v_add_nc_u32_e32 v10, v2, v10                              // 0000003DF81C: 4A141502
	v_add_nc_u32_e32 v2, 0x800, v2                             // 0000003DF820: 4A0404FF 00000800
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DF828: BF870094
	.long 0xd700060c                                           // 0000003DF82C: D700060C
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 0000003DF830: 02021010
	v_add_co_ci_u32_e64 v13, null, s17, v9, s6                 // 0000003DF834: D5207C0D 001A1211
	s_waitcnt lgkmcnt(0)                                       // 0000003DF83C: BF89FC07
	.long 0xd7000608                                           // 0000003DF840: D7000608
	v_cndmask_b32_e32 v1, s10, v6, vcc_lo                      // 0000003DF844: 02020C0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003DF848: BF8700A1
	v_add_co_ci_u32_e64 v9, null, s11, v7, s6                  // 0000003DF84C: D5207C09 001A0E0B
	.long 0xd7000606                                           // 0000003DF854: D7000606
	v_cndmask_b32_e32 v1, v12, v6, vcc_lo                      // 0000003DF858: 02020D0C
	v_add_co_ci_u32_e64 v7, null, v13, v7, s6                  // 0000003DF85C: D5207C07 001A0F0D
	global_load_b64 v[6:7], v[6:7], off                        // 0000003DF864: DC560000 067C0006
	global_load_b64 v[8:9], v[8:9], off                        // 0000003DF86C: DC560000 087C0008
	s_waitcnt vmcnt(1)                                         // 0000003DF874: BF8907F7
	.long 0x7e1a3907                                           // 0000003DF878: 7E1A3907
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000003DF87C: 360E0EFF FFFF0000
	.long 0x7e183906                                           // 0000003DF884: 7E183906
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000003DF888: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003DF890: BF8701B4
	v_lshlrev_b32_e32 v13, 16, v13                             // 0000003DF894: 301A1A90
	s_waitcnt vmcnt(0)                                         // 0000003DF898: BF8903F7
	v_fma_mix_f32 v7, v9, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003DF89C: CC200807 8A020F09
	v_fma_mix_f32 v6, v8, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003DF8A4: CC200806 8A020D08
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003DF8AC: BF8700B2
	v_fma_mix_f32 v14, v9, v13, v7 op_sel_hi:[1,0,0]           // 0000003DF8B0: CC20000E 0C1E1B09
	v_fma_mix_f32 v7, v9, v13, -v7 op_sel_hi:[1,0,0]           // 0000003DF8B8: CC200007 8C1E1B09
	v_lshlrev_b32_e32 v12, 16, v12                             // 0000003DF8C0: 30181890
	v_fma_mix_f32 v15, v8, v12, v6 op_sel_hi:[1,0,0]           // 0000003DF8C4: CC20000F 0C1A1908
	v_fma_mix_f32 v6, v8, v12, -v6 op_sel_hi:[1,0,0]           // 0000003DF8CC: CC200006 8C1A1908
	v_add_nc_u32_e32 v5, 8, v5                                 // 0000003DF8D4: 4A0A0A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003DF8D8: BF870223
	v_dual_sub_f32 v12, v15, v14 :: v_dual_add_nc_u32 v1, 0x400, v1// 0000003DF8DC: C9601D0F 0C0002FF 00000400
	v_add_f32_e32 v8, v15, v14                                 // 0000003DF8E8: 06101D0F
	v_dual_add_f32 v9, v7, v6 :: v_dual_sub_f32 v6, v6, v7     // 0000003DF8EC: C90A0D07 09060F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003DF8F4: BF870214
	.long 0xd4430006                                           // 0000003DF8F8: D4430006
	v_cndmask_b32_e32 v1, s7, v5, vcc_lo                       // 0000003DF8FC: 02020A07
	v_mov_b32_dpp v14, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003DF900: 7E1C02FA FF01610C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003DF908: BF870214
	v_mov_b32_dpp v7, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003DF90C: 7E0E02FA FF016108
	v_mov_b32_dpp v13, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003DF914: 7E1A02FA FF016109
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 0000003DF91C: D5010008 200A1108
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 0000003DF924: D5010009 200A1309
	v_mov_b32_dpp v15, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003DF92C: 7E1E02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 0000003DF934: D5010006 200A0D06
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 0000003DF93C: D501000C 200A190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003DF944: BF870124
	v_dual_add_f32 v7, v8, v7 :: v_dual_add_f32 v8, v9, v13    // 0000003DF948: C9080F08 07081B09
	s_or_b32 s36, s6, s36                                      // 0000003DF950: 8C242406
	v_dual_add_f32 v6, v6, v15 :: v_dual_add_f32 v9, v12, v14  // 0000003DF954: C9081F06 06081D0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DF95C: BF870192
	v_mov_b32_dpp v12, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003DF960: 7E1802FA FF016207
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003DF968: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 0000003DF970: D5010008 200E1108
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 0000003DF978: D5010007 200E0F07
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003DF980: 7E1C02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000003DF988: D5010009 200E1309
	v_mov_b32_dpp v15, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003DF990: 7E1E02FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 0000003DF998: D5010006 200E0D06
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v7, v7, v12   // 0000003DF9A0: C9081B08 08061907
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DF9A8: BF870114
	v_add_f32_e32 v9, v9, v14                                  // 0000003DF9AC: 06121D09
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003DF9B0: 7E1A02FA FF016408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DF9B8: BF870193
	v_mov_b32_dpp v12, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003DF9BC: 7E1802FA FF016407
	v_mov_b32_dpp v14, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003DF9C4: 7E1C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 0000003DF9CC: D5010009 20121309
	v_add_f32_e32 v6, v6, v15                                  // 0000003DF9D4: 060C1F06
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 0000003DF9D8: D5010007 20120F07
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 0000003DF9E0: D5010008 20121108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003DF9E8: BF870214
	v_add_f32_e32 v9, v9, v14                                  // 0000003DF9EC: 06121D09
	v_mov_b32_dpp v15, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003DF9F0: 7E1E02FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 0000003DF9F8: D5010006 20120D06
	v_add_f32_e32 v7, v7, v12                                  // 0000003DFA00: 060E1907
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003DFA04: BF870224
	v_mov_b32_dpp v14, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003DFA08: 7E1C02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 0000003DFA10: D5010009 20161309
	v_add_f32_e32 v6, v6, v15                                  // 0000003DFA18: 060C1F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003DFA1C: BF870224
	v_mov_b32_dpp v12, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003DFA20: 7E1802FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s5                          // 0000003DFA28: D5010007 20160F07
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v9, v9, v14   // 0000003DFA30: C9081B08 08081D09
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003DFA38: BF870224
	v_mov_b32_dpp v15, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003DFA3C: 7E1E02FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 0000003DFA44: D5010006 20160D06
	v_add_f32_e32 v7, v7, v12                                  // 0000003DFA4C: 060E1907
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003DFA50: BF870224
	v_mov_b32_dpp v13, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003DFA54: 7E1A02FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 0000003DFA5C: D5010008 20161108
	v_add_f32_e32 v6, v6, v15                                  // 0000003DFA64: 060C1F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DFA68: BF870091
	v_dual_add_f32 v8, v8, v13 :: v_dual_mov_b32 v15, v6       // 0000003DFA6C: C9101B08 080E0106
	v_mov_b32_e32 v13, v8                                      // 0000003DFA74: 7E1A0308
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003DFA78: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003DFA80: BF870003
	v_permlanex16_b32 v15, v15, s40, 0xfedcba98                // 0000003DFA84: D65C000F 03FC510F FEDCBA98
	v_mov_b32_e32 v12, v7                                      // 0000003DFA90: 7E180307
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000003DFA94: D5010007 21AA0F07
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003DFA9C: D5010008 21AA1108
	v_permlanex16_b32 v13, v13, s40, 0xfedcba98                // 0000003DFAA4: D65C000D 03FC510D FEDCBA98
	v_add_f32_e32 v11, v6, v15                                 // 0000003DFAB0: 06161F06
	v_permlanex16_b32 v12, v12, s40, 0xfedcba98                // 0000003DFAB4: D65C000C 03FC510C FEDCBA98
	v_mov_b32_e32 v14, v9                                      // 0000003DFAC0: 7E1C0309
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003DFAC4: D5010009 21AA1309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DFACC: BF870193
	v_add_f32_e32 v7, v7, v12                                  // 0000003DFAD0: 060E1907
	v_permlanex16_b32 v14, v14, s40, 0xfedcba98                // 0000003DFAD4: D65C000E 03FC510E FEDCBA98
	v_add_f32_e32 v8, v8, v13                                  // 0000003DFAE0: 06101B08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DFAE4: BF870193
	v_fma_mixlo_f16 v6, v7, s41, 0                             // 0000003DFAE8: CC210006 02005307
	v_add_f32_e32 v9, v9, v14                                  // 0000003DFAF0: 06121D09
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003DFAF4: BF8701A3
	v_fma_mixhi_f16 v6, v8, s41, 0                             // 0000003DFAF8: CC220006 02005308
	v_fma_mixhi_f16 v7, v11, s41, 0                            // 0000003DFB00: CC220007 0200530B
	v_fma_mixlo_f16 v7, v9, s41, 0                             // 0000003DFB08: CC210007 02005309
	ds_store_b64 v10, v[6:7]                                   // 0000003DFB10: D9340000 0000060A
	s_and_not1_b32 exec_lo, exec_lo, s36                       // 0000003DFB18: 917E247E
	s_cbranch_execnz 65298                                     // 0000003DFB1C: BFA6FF12 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x668>
	s_or_b32 exec_lo, exec_lo, s36                             // 0000003DFB20: 8C7E247E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003DFB24: BF870009
	s_or_b32 exec_lo, exec_lo, s22                             // 0000003DFB28: 8C7E167E
	s_bfe_i32 s6, s7, 0x1001c                                  // 0000003DFB2C: 9386FF07 0001001C
	v_mad_u32_u24 v4, v41, 24, 0x2f0                           // 0000003DFB34: D60B0004 03FD3129 000002F0
	s_lshr_b64 s[2:3], s[6:7], 29                              // 0000003DFB40: 85829D06
	s_lshr_b32 s3, s29, 28                                     // 0000003DFB44: 85039C1D
	s_add_i32 s2, s2, 7                                        // 0000003DFB48: 81028702
	s_add_i32 s3, s19, s3                                      // 0000003DFB4C: 81030313
	s_ashr_i32 s2, s2, 3                                       // 0000003DFB50: 86028302
	v_lshrrev_b32_e32 v1, 5, v4                                // 0000003DFB54: 32020885
	.long 0xd72c0010                                           // 0000003DFB58: D72C0010
	v_cndmask_b32_e32 v1, s2, v40, vcc_lo                      // 0000003DFB5C: 02025002
	s_ashr_i32 s3, s3, 4                                       // 0000003DFB60: 86038403
	s_lshl_b32 s4, s7, 3                                       // 0000003DFB64: 84048307
	s_lshl_b32 s5, s27, 3                                      // 0000003DFB68: 8405831B
	s_mul_hi_i32 s7, s26, s3                                   // 0000003DFB6C: 9707031A
	s_mul_i32 s3, s26, s3                                      // 0000003DFB70: 9603031A
	s_ashr_i32 s6, s5, 31                                      // 0000003DFB74: 86069F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v41                            // 0000003DFB78: 7C945280
	v_add_nc_u32_e32 v2, s2, v16                               // 0000003DFB7C: 4A042002
	s_add_u32 s2, s3, s5                                       // 0000003DFB80: 80020503
	s_addc_u32 s3, s7, s6                                      // 0000003DFB84: 82030607
	s_mul_i32 s5, s2, 0x300                                    // 0000003DFB88: 9605FF02 00000300
	s_mulk_i32 s3, 0x300                                       // 0000003DFB90: B8030300
	v_min_i32_e32 v42, s4, v2                                  // 0000003DFB94: 22540404
	v_subrev_nc_u32_e32 v2, 24, v1                             // 0000003DFB98: 4E040298
	v_add_nc_u32_e32 v1, 1, v16                                // 0000003DFB9C: 4A022081
	s_mul_hi_u32 s4, s2, 0x300                                 // 0000003DFBA0: 9684FF02 00000300
	v_add_nc_u32_e32 v17, 8, v4                                // 0000003DFBA8: 4A220888
	s_add_i32 s3, s4, s3                                       // 0000003DFBAC: 81030304
	v_cndmask_b32_e64 v10, v2, 23, vcc_lo                      // 0000003DFBB0: D501000A 01A92F02
	.long 0xd4410002                                           // 0000003DFBB8: D4410002
	v_cndmask_b32_e32 v1, v1, v42, vcc_lo                      // 0000003DFBBC: 02025501
	s_waitcnt lgkmcnt(0)                                       // 0000003DFBC0: BF89FC07
	s_add_u32 s4, s8, s5                                       // 0000003DFBC4: 80040508
	s_addc_u32 s5, s9, s3                                      // 0000003DFBC8: 82050309
	s_waitcnt_vscnt null, 0x0                                  // 0000003DFBCC: BC7C0000
	s_barrier                                                  // 0000003DFBD0: BFBD0000
	buffer_gl0_inv                                             // 0000003DFBD4: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 0000003DFBDC: BE832002
	s_cbranch_execz 123                                        // 0000003DFBE0: BFA5007B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xcd0>
	v_lshrrev_b32_e32 v2, 5, v17                               // 0000003DFBE4: 32042285
	.long 0xd4440002                                           // 0000003DFBE8: D4440002
	v_cndmask_b32_e32 v1, 23, v10, vcc_lo                      // 0000003DFBEC: 02021497
	v_mov_b32_e32 v11, 0                                       // 0000003DFBF0: 7E160280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DFBF4: BF870193
	v_subrev_nc_u32_e32 v2, 24, v2                             // 0000003DFBF8: 4E040498
	v_cndmask_b32_e64 v5, 0xe9, 1, s2                          // 0000003DFBFC: D5010005 000902FF 000000E9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DFC08: BF870191
	v_dual_mov_b32 v6, v11 :: v_dual_add_nc_u32 v9, v5, v10    // 0000003DFC0C: CA20010B 06081505
	v_cndmask_b32_e64 v5, v2, 23, vcc_lo                       // 0000003DFC14: D5010005 01A92F02
	v_mad_i64_i32 v[1:2], null, 0x300, v1, s[4:5]              // 0000003DFC1C: D6FF7C01 001202FF 00000300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DFC28: BF870193
	v_lshlrev_b32_e32 v12, 24, v9                              // 0000003DFC2C: 30181298
	.long 0xd4440002                                           // 0000003DFC30: D4440002
	v_cndmask_b32_e32 v1, 23, v5, vcc_lo                       // 0000003DFC34: 02020A97
	.long 0xd73c0007                                           // 0000003DFC38: D73C0007
	v_cndmask_b32_e32 v1, 2, v10, vcc_lo                       // 0000003DFC3C: 02021482
	v_bfe_i32 v9, v9, 7, 1                                     // 0000003DFC40: D6110009 02050F09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003DFC48: BF870214
	v_ashrrev_i32_e32 v11, 22, v12                             // 0000003DFC4C: 34161896
	v_cndmask_b32_e64 v13, 0xe9, 1, s2                         // 0000003DFC50: D501000D 000902FF 000000E9
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DFC5C: BF870094
	.long 0xd7000207                                           // 0000003DFC60: D7000207
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 0000003DFC64: 02020F01
	v_add_co_ci_u32_e64 v8, null, v2, v8, s2                   // 0000003DFC68: D5207C08 000A1102
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003DFC70: BF8700B3
	v_add_nc_u32_e32 v13, v13, v5                              // 0000003DFC74: 4A1A0B0D
	.long 0xd73c0005                                           // 0000003DFC78: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000003DFC7C: 02020A82
	.long 0xd700020b                                           // 0000003DFC80: D700020B
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 0000003DFC84: 02021701
	v_add_co_ci_u32_e64 v12, null, v2, v9, s2                  // 0000003DFC88: D5207C0C 000A1302
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003DFC90: BF8700B4
	v_lshlrev_b32_e32 v14, 24, v13                             // 0000003DFC94: 301C1A98
	v_bfe_i32 v9, v13, 7, 1                                    // 0000003DFC98: D6110009 02050F0D
	.long 0xd7000205                                           // 0000003DFCA0: D7000205
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 0000003DFCA4: 02020B01
	v_add_co_ci_u32_e64 v6, null, v2, v6, s2                   // 0000003DFCA8: D5207C06 000A0D02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DFCB0: BF870094
	v_ashrrev_i32_e32 v13, 22, v14                             // 0000003DFCB4: 341A1C96
	.long 0xd7000201                                           // 0000003DFCB8: D7000201
	v_cndmask_b32_e32 v1, v1, v13, vcc_lo                      // 0000003DFCBC: 02021B01
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003DFCC0: BF870001
	v_add_co_ci_u32_e64 v2, null, v2, v9, s2                   // 0000003DFCC4: D5207C02 000A1302
	s_clause 0x1f                                              // 0000003DFCCC: BF85001F
	global_load_b32 v50, v[7:8], off                           // 0000003DFCD0: DC520000 327C0007
	global_load_b32 v49, v[7:8], off offset:96                 // 0000003DFCD8: DC520060 317C0007
	global_load_b32 v48, v[7:8], off offset:192                // 0000003DFCE0: DC5200C0 307C0007
	global_load_b32 v47, v[7:8], off offset:288                // 0000003DFCE8: DC520120 2F7C0007
	global_load_b32 v46, v[7:8], off offset:384                // 0000003DFCF0: DC520180 2E7C0007
	global_load_b32 v45, v[7:8], off offset:480                // 0000003DFCF8: DC5201E0 2D7C0007
	global_load_b32 v44, v[7:8], off offset:576                // 0000003DFD00: DC520240 2C7C0007
	global_load_b32 v43, v[7:8], off offset:672                // 0000003DFD08: DC5202A0 2B7C0007
	global_load_b32 v66, v[11:12], off                         // 0000003DFD10: DC520000 427C000B
	global_load_b32 v63, v[11:12], off offset:96               // 0000003DFD18: DC520060 3F7C000B
	global_load_b32 v60, v[11:12], off offset:192              // 0000003DFD20: DC5200C0 3C7C000B
	global_load_b32 v57, v[11:12], off offset:288              // 0000003DFD28: DC520120 397C000B
	global_load_b32 v55, v[11:12], off offset:384              // 0000003DFD30: DC520180 377C000B
	global_load_b32 v53, v[11:12], off offset:480              // 0000003DFD38: DC5201E0 357C000B
	global_load_b32 v52, v[11:12], off offset:576              // 0000003DFD40: DC520240 347C000B
	global_load_b32 v51, v[11:12], off offset:672              // 0000003DFD48: DC5202A0 337C000B
	global_load_b32 v71, v[5:6], off                           // 0000003DFD50: DC520000 477C0005
	global_load_b32 v69, v[5:6], off offset:96                 // 0000003DFD58: DC520060 457C0005
	global_load_b32 v67, v[5:6], off offset:192                // 0000003DFD60: DC5200C0 437C0005
	global_load_b32 v64, v[5:6], off offset:288                // 0000003DFD68: DC520120 407C0005
	global_load_b32 v61, v[5:6], off offset:384                // 0000003DFD70: DC520180 3D7C0005
	global_load_b32 v58, v[5:6], off offset:480                // 0000003DFD78: DC5201E0 3A7C0005
	global_load_b32 v56, v[5:6], off offset:576                // 0000003DFD80: DC520240 387C0005
	global_load_b32 v54, v[5:6], off offset:672                // 0000003DFD88: DC5202A0 367C0005
	global_load_b32 v74, v[1:2], off                           // 0000003DFD90: DC520000 4A7C0001
	global_load_b32 v73, v[1:2], off offset:96                 // 0000003DFD98: DC520060 497C0001
	global_load_b32 v72, v[1:2], off offset:192                // 0000003DFDA0: DC5200C0 487C0001
	global_load_b32 v70, v[1:2], off offset:288                // 0000003DFDA8: DC520120 467C0001
	global_load_b32 v68, v[1:2], off offset:384                // 0000003DFDB0: DC520180 447C0001
	global_load_b32 v65, v[1:2], off offset:480                // 0000003DFDB8: DC5201E0 417C0001
	global_load_b32 v62, v[1:2], off offset:576                // 0000003DFDC0: DC520240 3E7C0001
	global_load_b32 v59, v[1:2], off offset:672                // 0000003DFDC8: DC5202A0 3B7C0001
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003DFDD0: 8C7E037E
	.long 0xd4410002                                           // 0000003DFDD4: D4410002
	v_cndmask_b32_e32 v1, v16, v42, vcc_lo                     // 0000003DFDD8: 02025510
	s_and_saveexec_b32 s6, s2                                  // 0000003DFDDC: BE862002
	s_cbranch_execz 121                                        // 0000003DFDE0: BFA50079 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xec8>
	v_lshrrev_b32_e32 v1, 5, v17                               // 0000003DFDE4: 32022285
	.long 0xd4440003                                           // 0000003DFDE8: D4440003
	v_cndmask_b32_e32 v1, 23, v10, vcc_lo                      // 0000003DFDEC: 02021497
	v_mov_b32_e32 v11, 0                                       // 0000003DFDF0: 7E160280
	v_mad_i64_i32 v[5:6], null, 0x300, v16, s[4:5]             // 0000003DFDF4: D6FF7C05 001220FF 00000300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003DFE00: BF870214
	v_subrev_nc_u32_e32 v1, 24, v1                             // 0000003DFE04: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s3                          // 0000003DFE08: D5010002 000D02FF 000000E9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DFE14: BF870112
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 0000003DFE18: D5010001 01A92F01
	v_dual_mov_b32 v2, v11 :: v_dual_add_nc_u32 v9, v2, v10    // 0000003DFE20: CA20010B 02081502
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DFE28: BF870112
	.long 0xd4440003                                           // 0000003DFE2C: D4440003
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 0000003DFE30: 02020297
	v_lshlrev_b32_e32 v12, 24, v9                              // 0000003DFE34: 30181298
	.long 0xd73c0007                                           // 0000003DFE38: D73C0007
	v_cndmask_b32_e32 v1, 2, v10, vcc_lo                       // 0000003DFE3C: 02021482
	v_bfe_i32 v9, v9, 7, 1                                     // 0000003DFE40: D6110009 02050F09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003DFE48: BF870214
	v_cndmask_b32_e64 v13, 0xe9, 1, s3                         // 0000003DFE4C: D501000D 000D02FF 000000E9
	v_ashrrev_i32_e32 v11, 22, v12                             // 0000003DFE58: 34161896
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DFE5C: BF870194
	.long 0xd7000307                                           // 0000003DFE60: D7000307
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000003DFE64: 02020F05
	v_add_nc_u32_e32 v12, v13, v1                              // 0000003DFE68: 4A18030D
	.long 0xd73c0001                                           // 0000003DFE6C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000003DFE70: 02020282
	v_add_co_ci_u32_e64 v8, null, v6, v8, s3                   // 0000003DFE74: D5207C08 000E1106
	.long 0xd700030e                                           // 0000003DFE7C: D700030E
	v_cndmask_b32_e32 v1, v5, v11, vcc_lo                      // 0000003DFE80: 02021705
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003DFE84: BF870244
	v_lshlrev_b32_e32 v13, 24, v12                             // 0000003DFE88: 301A1898
	v_add_co_ci_u32_e64 v15, null, v6, v9, s3                  // 0000003DFE8C: D5207C0F 000E1306
	v_bfe_i32 v9, v12, 7, 1                                    // 0000003DFE94: D6110009 02050F0C
	.long 0xd700034b                                           // 0000003DFE9C: D700034B
	v_cndmask_b32_e32 v1, v5, v1, vcc_lo                       // 0000003DFEA0: 02020305
	v_ashrrev_i32_e32 v11, 22, v13                             // 0000003DFEA4: 34161A96
	v_add_co_ci_u32_e64 v76, null, v6, v2, s3                  // 0000003DFEA8: D5207C4C 000E0506
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DFEB0: BF870092
	.long 0xd7000305                                           // 0000003DFEB4: D7000305
	v_cndmask_b32_e32 v1, v5, v11, vcc_lo                      // 0000003DFEB8: 02021705
	v_add_co_ci_u32_e64 v6, null, v6, v9, s3                   // 0000003DFEBC: D5207C06 000E1306
	s_clause 0x1f                                              // 0000003DFEC4: BF85001F
	global_load_b32 v2, v[7:8], off                            // 0000003DFEC8: DC520000 027C0007
	global_load_b32 v35, v[7:8], off offset:96                 // 0000003DFED0: DC520060 237C0007
	global_load_b32 v31, v[7:8], off offset:192                // 0000003DFED8: DC5200C0 1F7C0007
	global_load_b32 v27, v[7:8], off offset:288                // 0000003DFEE0: DC520120 1B7C0007
	global_load_b32 v23, v[7:8], off offset:384                // 0000003DFEE8: DC520180 177C0007
	global_load_b32 v19, v[7:8], off offset:480                // 0000003DFEF0: DC5201E0 137C0007
	global_load_b32 v13, v[7:8], off offset:576                // 0000003DFEF8: DC520240 0D7C0007
	global_load_b32 v9, v[7:8], off offset:672                 // 0000003DFF00: DC5202A0 097C0007
	global_load_b32 v1, v[14:15], off                          // 0000003DFF08: DC520000 017C000E
	global_load_b32 v34, v[14:15], off offset:96               // 0000003DFF10: DC520060 227C000E
	global_load_b32 v30, v[14:15], off offset:192              // 0000003DFF18: DC5200C0 1E7C000E
	global_load_b32 v26, v[14:15], off offset:288              // 0000003DFF20: DC520120 1A7C000E
	global_load_b32 v22, v[14:15], off offset:384              // 0000003DFF28: DC520180 167C000E
	global_load_b32 v18, v[14:15], off offset:480              // 0000003DFF30: DC5201E0 127C000E
	global_load_b32 v12, v[14:15], off offset:576              // 0000003DFF38: DC520240 0C7C000E
	global_load_b32 v8, v[14:15], off offset:672               // 0000003DFF40: DC5202A0 087C000E
	global_load_b32 v39, v[75:76], off                         // 0000003DFF48: DC520000 277C004B
	global_load_b32 v37, v[75:76], off offset:96               // 0000003DFF50: DC520060 257C004B
	global_load_b32 v33, v[75:76], off offset:192              // 0000003DFF58: DC5200C0 217C004B
	global_load_b32 v29, v[75:76], off offset:288              // 0000003DFF60: DC520120 1D7C004B
	global_load_b32 v25, v[75:76], off offset:384              // 0000003DFF68: DC520180 197C004B
	global_load_b32 v21, v[75:76], off offset:480              // 0000003DFF70: DC5201E0 157C004B
	global_load_b32 v15, v[75:76], off offset:576              // 0000003DFF78: DC520240 0F7C004B
	global_load_b32 v7, v[75:76], off offset:672               // 0000003DFF80: DC5202A0 077C004B
	global_load_b32 v38, v[5:6], off                           // 0000003DFF88: DC520000 267C0005
	global_load_b32 v36, v[5:6], off offset:96                 // 0000003DFF90: DC520060 247C0005
	global_load_b32 v32, v[5:6], off offset:192                // 0000003DFF98: DC5200C0 207C0005
	global_load_b32 v28, v[5:6], off offset:288                // 0000003DFFA0: DC520120 1C7C0005
	global_load_b32 v24, v[5:6], off offset:384                // 0000003DFFA8: DC520180 187C0005
	global_load_b32 v20, v[5:6], off offset:480                // 0000003DFFB0: DC5201E0 147C0005
	global_load_b32 v14, v[5:6], off offset:576                // 0000003DFFB8: DC520240 0E7C0005
	global_load_b32 v6, v[5:6], off offset:672                 // 0000003DFFC0: DC5202A0 067C0005
	s_or_b32 exec_lo, exec_lo, s6                              // 0000003DFFC8: 8C7E067E
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v76, 0              // 0000003DFFCC: CA100080 054C0080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v78, 0             // 0000003DFFD4: CA100080 4B4E0080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v80, 0             // 0000003DFFDC: CA100080 4D500080
	v_mov_b32_e32 v79, 0                                       // 0000003DFFE4: 7E9E0280
	v_mov_b32_e32 v81, 0                                       // 0000003DFFE8: 7EA20280
	s_ashr_i32 s27, s26, 31                                    // 0000003DFFEC: 861B9F1A
	s_and_saveexec_b32 s3, s2                                  // 0000003DFFF0: BE832002
	s_cbranch_execz 1057                                       // 0000003DFFF4: BFA50421 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1f7c>
	v_lshrrev_b32_e32 v5, 5, v17                               // 0000003DFFF8: 320A2285
	v_and_b32_e32 v75, 0x7e0, v4                               // 0000003DFFFC: 369608FF 000007E0
	v_or_b32_e32 v76, 4, v3                                    // 0000003E0004: 38980684
	v_mul_i32_i24_e32 v17, 0xffffffe8, v41                     // 0000003E0008: 122252FF FFFFFFE8
	v_ashrrev_i32_e32 v11, 31, v10                             // 0000003E0010: 3416149F
	v_subrev_nc_u32_e32 v5, 24, v5                             // 0000003E0014: 4E0A0A98
	v_sub_nc_u32_e32 v82, 0, v42                               // 0000003E0018: 4CA45480
	v_mul_i32_i24_e32 v81, -3, v76                             // 0000003E001C: 12A298C3
	v_add3_u32 v84, v17, v75, 0xfffffd34                       // 0000003E0020: D6550054 03FE9711 FFFFFD34
	v_mad_u32_u24 v17, v76, 3, 0x2f0                           // 0000003E002C: D60B0011 03FD074C 000002F0
	v_cndmask_b32_e64 v4, v5, 23, vcc_lo                       // 0000003E0038: D5010004 01A92F05
	v_cmp_gt_i32_e32 vcc_lo, 23, v10                           // 0000003E0040: 7C881497
	v_dual_mov_b32 v5, 0 :: v_dual_and_b32 v78, 16, v0         // 0000003E0044: CA240080 054E0090
	v_add_nc_u32_e32 v83, 2, v16                               // 0000003E004C: 4AA62082
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003E0050: BF870224
	.long 0xd7030003                                           // 0000003E0054: D7030003
	v_cndmask_b32_e32 v0, v4, v129, vcc_lo                     // 0000003E0058: 02010304
	v_cndmask_b32_e64 v77, 0xe9, 1, vcc_lo                     // 0000003E005C: D501004D 01A902FF 000000E9
	v_mov_b32_e32 v75, v5                                      // 0000003E0068: 7E960305
	v_lshl_or_b32 v85, v16, 5, v78                             // 0000003E006C: D6560055 05390B10
	v_and_b32_e32 v16, 0x7e0, v17                              // 0000003E0074: 362022FF 000007E0
	.long 0xd7624003                                           // 0000003E007C: D7624003
	v_cndmask_b32_e32 v1, 0xff, v3, vcc_lo                     // 0000003E0080: 020206FF 000000FF
	v_add_nc_u32_e32 v79, v77, v10                             // 0000003E0088: 4A9E154D
	.long 0xd73c000a                                           // 0000003E008C: D73C000A
	v_cndmask_b32_e32 v1, 2, v10, vcc_lo                       // 0000003E0090: 02021482
	v_mov_b32_e32 v76, v5                                      // 0000003E0094: 7E980305
	v_add3_u32 v86, v81, v16, 0xfffffd34                       // 0000003E0098: D6550056 03FE2151 FFFFFD34
	v_cmp_ne_u16_e32 vcc_lo, 24, v131/*Invalid register, operand has 'VGPR_32_Lo128' register class*/// 0000003E00A4: 7C7B0698
	v_dual_mov_b32 v80, v5 :: v_dual_and_b32 v17, 0xff, v79    // 0000003E00A8: CA240105 50109EFF 000000FF
	v_mov_b32_e32 v78, v5                                      // 0000003E00B4: 7E9C0305
	v_mov_b32_e32 v79, v5                                      // 0000003E00B8: 7E9E0305
	v_cndmask_b16 v3, 0, v3, vcc_lo                            // 0000003E00BC: D65D0003 01AA0680
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003E00C4: BF870004
	v_lshlrev_b32_e32 v87, 2, v17                              // 0000003E00C8: 30AE2282
	.long 0xd73c0010                                           // 0000003E00CC: D73C0010
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 0000003E00D0: 02020882
	v_mov_b32_e32 v81, v5                                      // 0000003E00D4: 7EA20305
	s_mov_b32 s2, 0                                            // 0000003E00D8: BE820080
	v_and_b32_e32 v3, 0xff, v3                                 // 0000003E00DC: 360606FF 000000FF
	v_mov_b32_e32 v77, v5                                      // 0000003E00E4: 7E9A0305
	s_movk_i32 s6, 0x1eee                                      // 0000003E00E8: B0061EEE
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003E00EC: BF870002
	v_lshlrev_b32_e32 v88, 2, v3                               // 0000003E00F0: 30B00682
	s_branch 900                                               // 0000003E00F4: BFA00384 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1e08>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000003E00F8: 8C7E077E
	s_waitcnt vmcnt(23)                                        // 0000003E00FC: BF895FF7
	.long 0xd73d0079                                           // 0000003E0100: D73D0079
	v_cndmask_b32_e32 v1, v84, v1, vcc_lo                      // 0000003E0104: 02020354
	s_waitcnt vmcnt(7)                                         // 0000003E0108: BF891FF7
	.long 0xd73d0026                                           // 0000003E010C: D73D0026
	v_cndmask_b32_e32 v1, v86, v38, vcc_lo                     // 0000003E0110: 02024D56
	ds_load_b128 v[1:4], v85                                   // 0000003E0114: DBFC0000 01000055
	.long 0xd73d0022                                           // 0000003E011C: D73D0022
	v_cndmask_b32_e32 v1, v84, v34, vcc_lo                     // 0000003E0120: 02024554
	s_waitcnt vmcnt(6)                                         // 0000003E0124: BF891BF7
	.long 0xd73d0023                                           // 0000003E0128: D73D0023
	v_cndmask_b32_e32 v1, v86, v36, vcc_lo                     // 0000003E012C: 02024956
	.long 0xd73d001e                                           // 0000003E0130: D73D001E
	v_cndmask_b32_e32 v1, v84, v30, vcc_lo                     // 0000003E0134: 02023D54
	v_bfe_u32 v39, v121, 9, 16                                 // 0000003E0138: D6100027 02411379
	v_bfe_u32 v122, v121, 6, 16                                // 0000003E0140: D610007A 02410D79
	v_bfe_u32 v123, v121, 3, 16                                // 0000003E0148: D610007B 02410779
	v_and_b32_e32 v121, 0xffff, v121                           // 0000003E0150: 36F2F2FF 0000FFFF
	v_bfe_u32 v124, v38, 9, 16                                 // 0000003E0158: D610007C 02411326
	.long 0xd72c0027                                           // 0000003E0160: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000003E0164: 02024EFF 83DCD12D
	.long 0xd72c007a                                           // 0000003E016C: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 0000003E0170: 0202F4FF 83DCD12D
	.long 0xd72c007b                                           // 0000003E0178: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 0000003E017C: 0202F6FF 83DCD12D
	.long 0xd72c0079                                           // 0000003E0184: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 0000003E0188: 0202F2FF 83DCD12D
	v_bfe_u32 v125, v38, 6, 16                                 // 0000003E0190: D610007D 02410D26
	.long 0xd72c007c                                           // 0000003E0198: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 0000003E019C: 0202F8FF 83DCD12D
	v_bfe_u32 v126, v38, 3, 16                                 // 0000003E01A4: D610007E 02410726
	v_bfe_u32 v37, v34, 9, 16                                  // 0000003E01AC: D6100025 02411322
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000003E01B4: D6220027 03FD0127 00006400
	v_sad_u8 v122, v122, 0, 0x6400                             // 0000003E01C0: D622007A 03FD017A 00006400
	v_sad_u8 v123, v123, 0, 0x6400                             // 0000003E01CC: D622007B 03FD017B 00006400
	v_sad_u8 v121, v121, 0, 0x6400                             // 0000003E01D8: D6220079 03FD0179 00006400
	.long 0xd72c007d                                           // 0000003E01E4: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 0000003E01E8: 0202FAFF 83DCD12D
	v_and_b32_e32 v39, 0xffff, v39                             // 0000003E01F0: 364E4EFF 0000FFFF
	v_sad_u8 v124, v124, 0, 0x6400                             // 0000003E01F8: D622007C 03FD017C 00006400
	s_waitcnt vmcnt(5)                                         // 0000003E0204: BF8917F7
	.long 0xd73d001f                                           // 0000003E0208: D73D001F
	v_cndmask_b32_e32 v1, v86, v32, vcc_lo                     // 0000003E020C: 02024156
	v_lshlrev_b32_e32 v121, 16, v121                           // 0000003E0210: 30F2F290
	.long 0xd72c0025                                           // 0000003E0214: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 0000003E0218: 02024AFF 83DCD12D
	v_lshl_or_b32 v39, v122, 16, v39                           // 0000003E0220: D6560027 049D217A
	.long 0xd73d001a                                           // 0000003E0228: D73D001A
	v_cndmask_b32_e32 v1, v84, v26, vcc_lo                     // 0000003E022C: 02023554
	v_sad_u8 v125, v125, 0, 0x6400                             // 0000003E0230: D622007D 03FD017D 00006400
	v_and_or_b32 v121, 0xffff, v123, v121                      // 0000003E023C: D6570079 05E6F6FF 0000FFFF
	v_bfe_u32 v123, v35, 9, 16                                 // 0000003E0248: D610007B 02411323
	v_pk_fma_f16 v39, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E0250: CC0E0027 0BFC0D27 0000C931
	v_and_b32_e32 v38, 0xffff, v38                             // 0000003E025C: 364C4CFF 0000FFFF
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000003E0264: D6220025 03FD0125 00006400
	v_pk_fma_f16 v36, v121, s6, 0xc931 op_sel_hi:[1,0,0]       // 0000003E0270: CC0E0024 0BFC0D79 0000C931
	.long 0xd72c007b                                           // 0000003E027C: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 0000003E0280: 0202F6FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 0000003E0288: BF89FC07
	v_dual_dot2acc_f32_f16 v81, v39, v1 :: v_dual_and_b32 v122, 0xffff, v124// 0000003E028C: CB240327 517AF8FF 0000FFFF
	v_bfe_u32 v124, v34, 6, 16                                 // 0000003E0298: D610007C 02410D22
	.long 0xd72c0026                                           // 0000003E02A0: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 0000003E02A4: 02024CFF 83DCD12D
	.long 0xd72c007e                                           // 0000003E02AC: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 0000003E02B0: 0202FCFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003E02B8: BF870004
	v_dot2acc_f32_f16 v81, v36, v2                             // 0000003E02BC: 04A20524
	v_lshl_or_b32 v122, v125, 16, v122                         // 0000003E02C0: D656007A 05E9217D
	v_bfe_u32 v125, v35, 6, 16                                 // 0000003E02C8: D610007D 02410D23
	.long 0xd72c007c                                           // 0000003E02D0: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 0000003E02D4: 0202F8FF 83DCD12D
	v_sad_u8 v123, v123, 0, 0x6400                             // 0000003E02DC: D622007B 03FD017B 00006400
	.long 0xd73d0016                                           // 0000003E02E8: D73D0016
	v_cndmask_b32_e32 v1, v84, v22, vcc_lo                     // 0000003E02EC: 02022D54
	v_pk_fma_f16 v121, v122, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000003E02F0: CC0E0079 0BFC0D7A 0000C931
	v_and_b32_e32 v122, 0xffff, v34                            // 0000003E02FC: 36F444FF 0000FFFF
	v_bfe_u32 v34, v34, 3, 16                                  // 0000003E0304: D6100022 02410722
	.long 0xd72c0027                                           // 0000003E030C: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 0000003E0310: 0202FAFF 83DCD12D
	v_bfe_u32 v125, v35, 3, 16                                 // 0000003E0318: D610007D 02410723
	v_dot2acc_f32_f16 v81, v121, v3                            // 0000003E0320: 04A20779
	.long 0xd72c007a                                           // 0000003E0324: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 0000003E0328: 0202F4FF 83DCD12D
	.long 0xd72c0022                                           // 0000003E0330: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 0000003E0334: 020244FF 83DCD12D
	v_and_b32_e32 v35, 0xffff, v35                             // 0000003E033C: 364646FF 0000FFFF
	v_sad_u8 v124, v124, 0, 0x6400                             // 0000003E0344: D622007C 03FD017C 00006400
	v_and_b32_e32 v123, 0xffff, v123                           // 0000003E0350: 36F6F6FF 0000FFFF
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000003E0358: D6220027 03FD0127 00006400
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000003E0364: D6220026 03FD0126 00006400
	.long 0xd72c0023                                           // 0000003E0370: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 0000003E0374: 020246FF 83DCD12D
	v_sad_u8 v122, v122, 0, 0x6400                             // 0000003E037C: D622007A 03FD017A 00006400
	v_sad_u8 v34, v34, 0, 0x6400                               // 0000003E0388: D6220022 03FD0122 00006400
	v_lshl_or_b32 v39, v39, 16, v123                           // 0000003E0394: D6560027 05ED2127
	v_and_b32_e32 v123, 0xffff, v30                            // 0000003E039C: 36F63CFF 0000FFFF
	v_sad_u8 v126, v126, 0, 0x6400                             // 0000003E03A4: D622007E 03FD017E 00006400
	v_lshlrev_b32_e32 v122, 16, v122                           // 0000003E03B0: 30F4F490
	.long 0xd73d0012                                           // 0000003E03B4: D73D0012
	v_cndmask_b32_e32 v1, v84, v18, vcc_lo                     // 0000003E03B8: 02022554
	v_sad_u8 v32, v35, 0, 0x6400                               // 0000003E03BC: D6220020 03FD0123 00006400
	v_bfe_u32 v35, v30, 6, 16                                  // 0000003E03C8: D6100023 02410D1E
	.long 0xd73d000c                                           // 0000003E03D0: D73D000C
	v_cndmask_b32_e32 v1, v84, v12, vcc_lo                     // 0000003E03D4: 02021954
	v_and_or_b32 v34, 0xffff, v34, v122                        // 0000003E03D8: D6570022 05EA44FF 0000FFFF
	.long 0xd72c007a                                           // 0000003E03E4: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 0000003E03E8: 0202FAFF 83DCD12D
	v_lshlrev_b32_e32 v32, 16, v32                             // 0000003E03F0: 30404090
	.long 0xd72c0023                                           // 0000003E03F4: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 0000003E03F8: 020246FF 83DCD12D
	v_bfe_u32 v125, v31, 3, 16                                 // 0000003E0400: D610007D 0241071F
	v_pk_fma_f16 v34, v34, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E0408: CC0E0022 0BFC0D22 0000C931
	s_waitcnt vmcnt(1)                                         // 0000003E0414: BF8907F7
	.long 0xd73d000d                                           // 0000003E0418: D73D000D
	v_cndmask_b32_e32 v1, v86, v14, vcc_lo                     // 0000003E041C: 02021D56
	v_bfe_u32 v15, v12, 9, 16                                  // 0000003E0420: D610000F 0241130C
	.long 0xd73d0008                                           // 0000003E0428: D73D0008
	v_cndmask_b32_e32 v1, v84, v8, vcc_lo                      // 0000003E042C: 02021154
	v_sad_u8 v122, v122, 0, 0x6400                             // 0000003E0430: D622007A 03FD017A 00006400
	s_waitcnt vmcnt(0)                                         // 0000003E043C: BF8903F7
	.long 0xd73d0006                                           // 0000003E0440: D73D0006
	v_cndmask_b32_e32 v1, v86, v6, vcc_lo                      // 0000003E0444: 02020D56
	v_sad_u8 v35, v35, 0, 0x6400                               // 0000003E0448: D6220023 03FD0123 00006400
	.long 0xd72c000f                                           // 0000003E0454: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 0000003E0458: 02021EFF 83DCD12D
	v_add_nc_u32_e32 v83, 1, v83                               // 0000003E0460: 4AA6A681
	v_and_or_b32 v32, 0xffff, v122, v32                        // 0000003E0464: D6570020 0482F4FF 0000FFFF
	v_add_nc_u32_e32 v85, 32, v85                              // 0000003E0470: 4AAAAAA0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003E0474: BF870132
	v_pk_fma_f16 v27, v32, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E0478: CC0E001B 0BFC0D20 0000C931
	v_and_b32_e32 v37, 0xffff, v37                             // 0000003E0484: 364A4AFF 0000FFFF
	v_sad_u8 v15, v15, 0, 0x6400                               // 0000003E048C: D622000F 03FD010F 00006400
	v_lshl_or_b32 v37, v124, 16, v37                           // 0000003E0498: D6560025 0495217C
	v_bfe_u32 v124, v31, 6, 16                                 // 0000003E04A0: D610007C 02410D1F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003E04A8: BF870193
	v_and_b32_e32 v15, 0xffff, v15                             // 0000003E04AC: 361E1EFF 0000FFFF
	v_pk_fma_f16 v36, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E04B4: CC0E0024 0BFC0D25 0000C931
	v_pk_fma_f16 v37, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E04C0: CC0E0025 0BFC0D27 0000C931
	v_bfe_u32 v39, v30, 9, 16                                  // 0000003E04CC: D6100027 0241131E
	v_bfe_u32 v30, v30, 3, 16                                  // 0000003E04D4: D610001E 0241071E
	.long 0xd72c007c                                           // 0000003E04DC: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 0000003E04E0: 0202F8FF 83DCD12D
	v_dot2acc_f32_f16 v80, v36, v1                             // 0000003E04E8: 04A00324
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003E04EC: BF870004
	.long 0xd72c0021                                           // 0000003E04F0: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000003E04F4: 02024EFF 83DCD12D
	.long 0xd72c0027                                           // 0000003E04FC: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 0000003E0500: 0202F6FF 83DCD12D
	v_bfe_u32 v123, v31, 9, 16                                 // 0000003E0508: D610007B 0241131F
	v_and_b32_e32 v31, 0xffff, v31                             // 0000003E0510: 363E3EFF 0000FFFF
	.long 0xd72c001e                                           // 0000003E0518: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 0000003E051C: 02023CFF 83DCD12D
	v_dot2acc_f32_f16 v80, v34, v2                             // 0000003E0524: 04A00522
	v_mov_b32_e32 v34, v63                                     // 0000003E0528: 7E44033F
	.long 0xd72c007b                                           // 0000003E052C: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 0000003E0530: 0202F6FF 83DCD12D
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000003E0538: D6220021 03FD0121 00006400
	.long 0xd72c001f                                           // 0000003E0544: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 0000003E0548: 02023EFF 83DCD12D
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000003E0550: D6220027 03FD0127 00006400
	v_dot2acc_f32_f16 v80, v37, v3                             // 0000003E055C: 04A00725
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000003E0560: D622001E 03FD011E 00006400
	v_and_b32_e32 v33, 0xffff, v33                             // 0000003E056C: 364242FF 0000FFFF
	v_mov_b32_e32 v37, v69                                     // 0000003E0574: 7E4A0345
	v_lshlrev_b32_e32 v39, 16, v39                             // 0000003E0578: 304E4E90
	v_sad_u8 v123, v123, 0, 0x6400                             // 0000003E057C: D622007B 03FD017B 00006400
	v_sad_u8 v31, v31, 0, 0x6400                               // 0000003E0588: D622001F 03FD011F 00006400
	v_lshl_or_b32 v33, v35, 16, v33                            // 0000003E0594: D6560021 04852123
	.long 0xd72c0023                                           // 0000003E059C: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 0000003E05A0: 0202FAFF 83DCD12D
	v_and_or_b32 v30, 0xffff, v30, v39                         // 0000003E05A8: D657001E 049E3CFF 0000FFFF
	v_and_b32_e32 v39, 0xffff, v123                            // 0000003E05B4: 364EF6FF 0000FFFF
	v_sad_u8 v123, v124, 0, 0x6400                             // 0000003E05BC: D622007B 03FD017C 00006400
	v_pk_fma_f16 v33, v33, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E05C8: CC0E0021 0BFC0D21 0000C931
	v_lshlrev_b32_e32 v31, 16, v31                             // 0000003E05D4: 303E3E90
	v_lshlrev_b32_e32 v38, 16, v38                             // 0000003E05D8: 304C4C90
	v_pk_fma_f16 v30, v30, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E05DC: CC0E001E 0BFC0D1E 0000C931
	v_sad_u8 v35, v35, 0, 0x6400                               // 0000003E05E8: D6220023 03FD0123 00006400
	v_lshl_or_b32 v36, v123, 16, v39                           // 0000003E05F4: D6560024 049D217B
	v_dot2acc_f32_f16 v79, v33, v1                             // 0000003E05FC: 049E0321
	v_and_or_b32 v38, 0xffff, v126, v38                        // 0000003E0600: D6570026 049AFCFF 0000FFFF
	v_dot2acc_f32_f16 v80, v27, v4                             // 0000003E060C: 04A0091B
	v_and_or_b32 v31, 0xffff, v35, v31                         // 0000003E0610: D657001F 047E46FF 0000FFFF
	v_pk_fma_f16 v33, v36, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E061C: CC0E0021 0BFC0D24 0000C931
	v_dot2acc_f32_f16 v79, v30, v2                             // 0000003E0628: 049E051E
	.long 0xd73d001b                                           // 0000003E062C: D73D001B
	v_cndmask_b32_e32 v1, v86, v28, vcc_lo                     // 0000003E0630: 02023956
	v_pk_fma_f16 v38, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E0634: CC0E0026 0BFC0D26 0000C931
	v_pk_fma_f16 v30, v31, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E0640: CC0E001E 0BFC0D1F 0000C931
	v_bfe_u32 v31, v26, 9, 16                                  // 0000003E064C: D610001F 0241131A
	v_dot2acc_f32_f16 v79, v33, v3                             // 0000003E0654: 049E0721
	v_bfe_u32 v29, v26, 6, 16                                  // 0000003E0658: D610001D 02410D1A
	v_dot2acc_f32_f16 v81, v38, v4                             // 0000003E0660: 04A20926
	v_bfe_u32 v32, v27, 6, 16                                  // 0000003E0664: D6100020 02410D1B
	.long 0xd72c001c                                           // 0000003E066C: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 0000003E0670: 02023EFF 83DCD12D
	v_bfe_u32 v31, v27, 9, 16                                  // 0000003E0678: D610001F 0241131B
	v_dual_dot2acc_f32_f16 v79, v30, v4 :: v_dual_and_b32 v30, 0xffff, v26// 0000003E0680: CB24091E 4F1E34FF 0000FFFF
	.long 0xd72c001d                                           // 0000003E068C: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 0000003E0690: 02023AFF 83DCD12D
	v_bfe_u32 v26, v26, 3, 16                                  // 0000003E0698: D610001A 0241071A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003E06A0: BF870004
	.long 0xd72c001f                                           // 0000003E06A4: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 0000003E06A8: 02023EFF 83DCD12D
	v_bfe_u32 v33, v27, 3, 16                                  // 0000003E06B0: D6100021 0241071B
	.long 0xd72c001e                                           // 0000003E06B8: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 0000003E06BC: 02023CFF 83DCD12D
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000003E06C4: D622001C 03FD011C 00006400
	v_and_b32_e32 v27, 0xffff, v27                             // 0000003E06D0: 363636FF 0000FFFF
	.long 0xd72c0020                                           // 0000003E06D8: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 0000003E06DC: 020240FF 83DCD12D
	.long 0xd72c001a                                           // 0000003E06E4: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 0000003E06E8: 020234FF 83DCD12D
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000003E06F0: D622001D 03FD011D 00006400
	v_and_b32_e32 v28, 0xffff, v28                             // 0000003E06FC: 363838FF 0000FFFF
	v_sad_u8 v31, v31, 0, 0x6400                               // 0000003E0704: D622001F 03FD011F 00006400
	.long 0xd72c001b                                           // 0000003E0710: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 0000003E0714: 020236FF 83DCD12D
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000003E071C: D622001E 03FD011E 00006400
	v_mov_b32_e32 v35, v49                                     // 0000003E0728: 7E460331
	v_lshl_or_b32 v28, v29, 16, v28                            // 0000003E072C: D656001C 0471211D
	v_and_b32_e32 v29, 0xffff, v31                             // 0000003E0734: 363A3EFF 0000FFFF
	.long 0xd72c001f                                           // 0000003E073C: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 0000003E0740: 020242FF 83DCD12D
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000003E0748: D6220020 03FD0120 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000003E0754: D622001A 03FD011A 00006400
	v_lshlrev_b32_e32 v30, 16, v30                             // 0000003E0760: 303C3C90
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000003E0764: D622001B 03FD011B 00006400
	v_pk_fma_f16 v28, v28, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E0770: CC0E001C 0BFC0D1C 0000C931
	v_lshl_or_b32 v23, v32, 16, v29                            // 0000003E077C: D6560017 04752120
	v_and_b32_e32 v32, 0xffff, v22                             // 0000003E0784: 36402CFF 0000FFFF
	v_and_or_b32 v26, 0xffff, v26, v30                         // 0000003E078C: D657001A 047A34FF 0000FFFF
	v_sad_u8 v29, v31, 0, 0x6400                               // 0000003E0798: D622001D 03FD011F 00006400
	v_lshlrev_b32_e32 v27, 16, v27                             // 0000003E07A4: 30363690
	v_bfe_u32 v30, v22, 9, 16                                  // 0000003E07A8: D610001E 02411316
	v_pk_fma_f16 v31, v23, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E07B0: CC0E001F 0BFC0D17 0000C931
	.long 0xd73d0017                                           // 0000003E07BC: D73D0017
	v_cndmask_b32_e32 v1, v86, v24, vcc_lo                     // 0000003E07C0: 02023156
	v_pk_fma_f16 v26, v26, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E07C4: CC0E001A 0BFC0D1A 0000C931
	v_and_or_b32 v24, 0xffff, v29, v27                         // 0000003E07D0: D6570018 046E3AFF 0000FFFF
	.long 0xd72c0019                                           // 0000003E07DC: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 0000003E07E0: 02023CFF 83DCD12D
	v_bfe_u32 v27, v22, 6, 16                                  // 0000003E07E8: D610001B 02410D16
	v_bfe_u32 v22, v22, 3, 16                                  // 0000003E07F0: D6100016 02410716
	.long 0xd72c001d                                           // 0000003E07F8: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 0000003E07FC: 020240FF 83DCD12D
	v_bfe_u32 v30, v23, 9, 16                                  // 0000003E0804: D610001E 02411317
	v_bfe_u32 v32, v23, 6, 16                                  // 0000003E080C: D6100020 02410D17
	.long 0xd72c001b                                           // 0000003E0814: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 0000003E0818: 020236FF 83DCD12D
	.long 0xd72c0016                                           // 0000003E0820: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 0000003E0824: 02022CFF 83DCD12D
	v_sad_u8 v25, v25, 0, 0x6400                               // 0000003E082C: D6220019 03FD0119 00006400
	.long 0xd72c001e                                           // 0000003E0838: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 0000003E083C: 02023CFF 83DCD12D
	.long 0xd72c0020                                           // 0000003E0844: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 0000003E0848: 020240FF 83DCD12D
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000003E0850: D622001D 03FD011D 00006400
	v_dot2acc_f32_f16 v78, v28, v1                             // 0000003E085C: 049C031C
	v_and_b32_e32 v25, 0xffff, v25                             // 0000003E0860: 363232FF 0000FFFF
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000003E0868: D622001B 03FD011B 00006400
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000003E0874: D6220016 03FD0116 00006400
	v_lshlrev_b32_e32 v29, 16, v29                             // 0000003E0880: 303A3A90
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000003E0884: D622001E 03FD011E 00006400
	v_dot2acc_f32_f16 v78, v26, v2                             // 0000003E0890: 049C051A
	v_lshl_or_b32 v25, v27, 16, v25                            // 0000003E0894: D6560019 0465211B
	v_pk_fma_f16 v19, v24, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E089C: CC0E0013 0BFC0D18 0000C931
	v_and_or_b32 v22, 0xffff, v22, v29                         // 0000003E08A8: D6570016 04762CFF 0000FFFF
	v_and_b32_e32 v28, 0xffff, v30                             // 0000003E08B4: 36383CFF 0000FFFF
	v_sad_u8 v29, v32, 0, 0x6400                               // 0000003E08BC: D622001D 03FD0120 00006400
	v_pk_fma_f16 v25, v25, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E08C8: CC0E0019 0BFC0D19 0000C931
	v_dot2acc_f32_f16 v78, v31, v3                             // 0000003E08D4: 049C071F
	v_pk_fma_f16 v22, v22, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E08D8: CC0E0016 0BFC0D16 0000C931
	v_bfe_u32 v33, v23, 3, 16                                  // 0000003E08E4: D6100021 02410717
	v_lshl_or_b32 v26, v29, 16, v28                            // 0000003E08EC: D656001A 0471211D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003E08F4: BF870234
	v_dual_dot2acc_f32_f16 v77, v25, v1 :: v_dual_dot2acc_f32_f16 v78, v19, v4// 0000003E08F8: CB180319 4D4E0913
	.long 0xd73d0013                                           // 0000003E0900: D73D0013
	v_cndmask_b32_e32 v1, v86, v20, vcc_lo                     // 0000003E0904: 02022956
	v_bfe_u32 v21, v18, 6, 16                                  // 0000003E0908: D6100015 02410D12
	v_pk_fma_f16 v24, v26, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E0910: CC0E0018 0BFC0D1A 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003E091C: BF870004
	v_dot2acc_f32_f16 v77, v22, v2                             // 0000003E0920: 049A0516
	v_bfe_u32 v22, v18, 9, 16                                  // 0000003E0924: D6100016 02411312
	v_mov_b32_e32 v28, v70                                     // 0000003E092C: 7E380346
	v_and_b32_e32 v26, 0xffff, v19                             // 0000003E0930: 363426FF 0000FFFF
	v_bfe_u32 v25, v19, 6, 16                                  // 0000003E0938: D6100019 02410D13
	v_dot2acc_f32_f16 v77, v24, v3                             // 0000003E0940: 049A0718
	.long 0xd72c0014                                           // 0000003E0944: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 0000003E0948: 02022CFF 83DCD12D
	v_and_b32_e32 v22, 0xffff, v18                             // 0000003E0950: 362C24FF 0000FFFF
	v_bfe_u32 v24, v19, 9, 16                                  // 0000003E0958: D6100018 02411313
	v_bfe_u32 v18, v18, 3, 16                                  // 0000003E0960: D6100012 02410712
	.long 0xd72c0019                                           // 0000003E0968: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 0000003E096C: 020232FF 83DCD12D
	.long 0xd72c0015                                           // 0000003E0974: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 0000003E0978: 02022AFF 83DCD12D
	.long 0xd72c0016                                           // 0000003E0980: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 0000003E0984: 02022CFF 83DCD12D
	.long 0xd72c0018                                           // 0000003E098C: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 0000003E0990: 020230FF 83DCD12D
	.long 0xd72c0012                                           // 0000003E0998: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 0000003E099C: 020224FF 83DCD12D
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000003E09A4: D6220014 03FD0114 00006400
	v_bfe_u32 v19, v19, 3, 16                                  // 0000003E09B0: D6100013 02410713
	.long 0xd72c001a                                           // 0000003E09B8: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 0000003E09BC: 020234FF 83DCD12D
	v_sad_u8 v25, v25, 0, 0x6400                               // 0000003E09C4: D6220019 03FD0119 00006400
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000003E09D0: D6220015 03FD0115 00006400
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000003E09DC: D6220016 03FD0116 00006400
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000003E09E8: D6220018 03FD0118 00006400
	v_sad_u8 v18, v18, 0, 0x6400                               // 0000003E09F4: D6220012 03FD0112 00006400
	v_and_b32_e32 v20, 0xffff, v20                             // 0000003E0A00: 362828FF 0000FFFF
	.long 0xd72c0013                                           // 0000003E0A08: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 0000003E0A0C: 020226FF 83DCD12D
	v_lshlrev_b32_e32 v22, 16, v22                             // 0000003E0A14: 302C2C90
	v_and_b32_e32 v24, 0xffff, v24                             // 0000003E0A18: 363030FF 0000FFFF
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000003E0A20: D622001A 03FD011A 00006400
	v_lshl_or_b32 v20, v21, 16, v20                            // 0000003E0A2C: D6560014 04512115
	v_mov_b32_e32 v32, v72                                     // 0000003E0A34: 7E400348
	v_and_or_b32 v18, 0xffff, v18, v22                         // 0000003E0A38: D6570012 045A24FF 0000FFFF
	v_lshl_or_b32 v22, v25, 16, v24                            // 0000003E0A44: D6560016 04612119
	v_sad_u8 v19, v19, 0, 0x6400                               // 0000003E0A4C: D6220013 03FD0113 00006400
	v_pk_fma_f16 v20, v20, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E0A58: CC0E0014 0BFC0D14 0000C931
	v_lshlrev_b32_e32 v21, 16, v26                             // 0000003E0A64: 302A3490
	v_pk_fma_f16 v18, v18, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E0A68: CC0E0012 0BFC0D12 0000C931
	v_pk_fma_f16 v14, v22, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E0A74: CC0E000E 0BFC0D16 0000C931
	v_bfe_u32 v22, v12, 6, 16                                  // 0000003E0A80: D6100016 02410D0C
	v_dot2acc_f32_f16 v76, v20, v1                             // 0000003E0A88: 04980314
	v_bfe_u32 v24, v13, 6, 16                                  // 0000003E0A8C: D6100018 02410D0D
	v_and_or_b32 v19, 0xffff, v19, v21                         // 0000003E0A94: D6570013 045626FF 0000FFFF
	v_bfe_u32 v21, v13, 9, 16                                  // 0000003E0AA0: D6100015 0241130D
	.long 0xd72c0016                                           // 0000003E0AA8: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 0000003E0AAC: 02022CFF 83DCD12D
	v_dot2acc_f32_f16 v76, v18, v2                             // 0000003E0AB4: 04980512
	.long 0xd72c0012                                           // 0000003E0AB8: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 0000003E0ABC: 020230FF 83DCD12D
	v_bfe_u32 v24, v13, 3, 16                                  // 0000003E0AC4: D6100018 0241070D
	v_and_b32_e32 v13, 0xffff, v13                             // 0000003E0ACC: 361A1AFF 0000FFFF
	v_and_b32_e32 v20, 0xffff, v12                             // 0000003E0AD4: 362818FF 0000FFFF
	v_bfe_u32 v12, v12, 3, 16                                  // 0000003E0ADC: D610000C 0241070C
	.long 0xd72c0015                                           // 0000003E0AE4: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 0000003E0AE8: 02022AFF 83DCD12D
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000003E0AF0: D6220016 03FD0116 00006400
	.long 0xd72c0009                                           // 0000003E0AFC: D72C0009
	v_cndmask_b32_e32 v1, 0x83dcd12d, v13, vcc_lo              // 0000003E0B00: 02021AFF 83DCD12D
	.long 0xd72c0014                                           // 0000003E0B08: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v20, vcc_lo              // 0000003E0B0C: 020228FF 83DCD12D
	.long 0xd72c000c                                           // 0000003E0B14: D72C000C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v12, vcc_lo              // 0000003E0B18: 020218FF 83DCD12D
	v_sad_u8 v18, v18, 0, 0x6400                               // 0000003E0B20: D6220012 03FD0112 00006400
	v_lshl_or_b32 v15, v22, 16, v15                            // 0000003E0B2C: D656000F 043D2116
	v_mov_b32_e32 v26, v57                                     // 0000003E0B34: 7E340339
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000003E0B38: D6220015 03FD0115 00006400
	v_dot2acc_f32_f16 v76, v14, v3                             // 0000003E0B44: 0498070E
	v_sad_u8 v7, v9, 0, 0x6400                                 // 0000003E0B48: D6220007 03FD0109 00006400
	v_pk_fma_f16 v13, v15, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E0B54: CC0E000D 0BFC0D0F 0000C931
	v_bfe_u32 v15, v8, 9, 16                                   // 0000003E0B60: D610000F 02411308
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000003E0B68: D6220014 03FD0114 00006400
	v_sad_u8 v12, v12, 0, 0x6400                               // 0000003E0B74: D622000C 03FD010C 00006400
	v_dual_mov_b32 v30, v60 :: v_dual_and_b32 v21, 0xffff, v21 // 0000003E0B80: CA24013C 1E142AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003E0B8C: BF870234
	.long 0xd72c0009                                           // 0000003E0B90: D72C0009
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 0000003E0B94: 02021EFF 83DCD12D
	v_bfe_u32 v15, v8, 6, 16                                   // 0000003E0B9C: D610000F 02410D08
	v_lshlrev_b32_e32 v20, 16, v20                             // 0000003E0BA4: 30282890
	v_lshl_or_b32 v18, v18, 16, v21                            // 0000003E0BA8: D6560012 04552112
	v_bfe_u32 v21, v6, 9, 16                                   // 0000003E0BB0: D6100015 02411306
	v_bfe_u32 v22, v6, 6, 16                                   // 0000003E0BB8: D6100016 02410D06
	.long 0xd72c000f                                           // 0000003E0BC0: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 0000003E0BC4: 02021EFF 83DCD12D
	v_and_or_b32 v12, 0xffff, v12, v20                         // 0000003E0BCC: D657000C 045218FF 0000FFFF
	v_sad_u8 v9, v9, 0, 0x6400                                 // 0000003E0BD8: D6220009 03FD0109 00006400
	.long 0xd72c0014                                           // 0000003E0BE4: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 0000003E0BE8: 020230FF 83DCD12D
	v_pk_fma_f16 v14, v18, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E0BF0: CC0E000E 0BFC0D12 0000C931
	.long 0xd72c0015                                           // 0000003E0BFC: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 0000003E0C00: 02022AFF 83DCD12D
	v_pk_fma_f16 v12, v12, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E0C08: CC0E000C 0BFC0D0C 0000C931
	v_and_b32_e32 v9, 0xffff, v9                               // 0000003E0C14: 361212FF 0000FFFF
	v_sad_u8 v15, v15, 0, 0x6400                               // 0000003E0C1C: D622000F 03FD010F 00006400
	v_dual_mov_b32 v36, v73 :: v_dual_lshlrev_b32 v7, 16, v7   // 0000003E0C28: CA220149 24060E90
	v_sad_u8 v18, v20, 0, 0x6400                               // 0000003E0C30: D6220012 03FD0114 00006400
	v_and_b32_e32 v20, 0xffff, v8                              // 0000003E0C3C: 362810FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003E0C44: BF870004
	v_lshl_or_b32 v9, v15, 16, v9                              // 0000003E0C48: D6560009 0425210F
	v_bfe_u32 v8, v8, 3, 16                                    // 0000003E0C50: D6100008 02410708
	v_dot2acc_f32_f16 v75, v13, v1                             // 0000003E0C58: 0496030D
	.long 0xd72c0016                                           // 0000003E0C5C: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 0000003E0C60: 02022CFF 83DCD12D
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000003E0C68: D6220015 03FD0115 00006400
	v_pk_fma_f16 v9, v9, s6, 0xc931 op_sel_hi:[1,0,0]          // 0000003E0C74: CC0E0009 0BFC0D09 0000C931
	.long 0xd72c0008                                           // 0000003E0C80: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v8, vcc_lo               // 0000003E0C84: 020210FF 83DCD12D
	v_dot2acc_f32_f16 v75, v12, v2                             // 0000003E0C8C: 0496050C
	v_and_b32_e32 v23, 0xffff, v23                             // 0000003E0C90: 362E2EFF 0000FFFF
	.long 0xd72c001b                                           // 0000003E0C98: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 0000003E0C9C: 020242FF 83DCD12D
	v_dot2acc_f32_f16 v5, v9, v1                               // 0000003E0CA4: 040A0309
	v_mov_b32_e32 v9, v43                                      // 0000003E0CA8: 7E12032B
	.long 0xd72c0014                                           // 0000003E0CAC: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v20, vcc_lo              // 0000003E0CB0: 020228FF 83DCD12D
	v_and_or_b32 v1, 0xffff, v18, v7                           // 0000003E0CB8: D6570001 041E24FF 0000FFFF
	v_sad_u8 v8, v8, 0, 0x6400                                 // 0000003E0CC4: D6220008 03FD0108 00006400
	v_dot2acc_f32_f16 v75, v14, v3                             // 0000003E0CD0: 0496070E
	v_bfe_u32 v24, v6, 3, 16                                   // 0000003E0CD4: D6100018 02410706
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000003E0CDC: D622001B 03FD011B 00006400
	v_pk_fma_f16 v1, v1, s6, 0xc931 op_sel_hi:[1,0,0]          // 0000003E0CE8: CC0E0001 0BFC0D01 0000C931
	v_pk_fma_f16 v19, v19, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E0CF4: CC0E0013 0BFC0D13 0000C931
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000003E0D00: D6220014 03FD0114 00006400
	.long 0xd72c000f                                           // 0000003E0D0C: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 0000003E0D10: 020230FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003E0D18: BF870214
	v_dual_mov_b32 v14, v62 :: v_dual_dot2acc_f32_f16 v75, v1, v4// 0000003E0D1C: CA18013E 0E4A0901
	v_dot2acc_f32_f16 v76, v19, v4                             // 0000003E0D24: 04980913
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003E0D28: BF870004
	v_lshlrev_b32_e32 v20, 16, v20                             // 0000003E0D2C: 30282890
	v_mov_b32_e32 v24, v68                                     // 0000003E0D30: 7E300344
	v_mov_b32_e32 v12, v52                                     // 0000003E0D34: 7E180334
	v_mov_b32_e32 v18, v53                                     // 0000003E0D38: 7E240335
	v_sad_u8 v15, v15, 0, 0x6400                               // 0000003E0D3C: D622000F 03FD010F 00006400
	v_and_or_b32 v8, 0xffff, v8, v20                           // 0000003E0D48: D6570008 045210FF 0000FFFF
	v_and_b32_e32 v20, 0xffff, v21                             // 0000003E0D54: 36282AFF 0000FFFF
	v_sad_u8 v21, v22, 0, 0x6400                               // 0000003E0D5C: D6220015 03FD0116 00006400
	v_mov_b32_e32 v19, v45                                     // 0000003E0D68: 7E26032D
	v_dual_mov_b32 v25, v61 :: v_dual_mov_b32 v52, v98         // 0000003E0D6C: CA10013D 19340162
	v_pk_fma_f16 v8, v8, s6, 0xc931 op_sel_hi:[1,0,0]          // 0000003E0D74: CC0E0008 0BFC0D08 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003E0D80: BF870244
	v_lshl_or_b32 v13, v21, 16, v20                            // 0000003E0D84: D656000D 04512115
	v_mov_b32_e32 v20, v65                                     // 0000003E0D8C: 7E280341
	.long 0xd72c0017                                           // 0000003E0D90: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 0000003E0D94: 02022EFF 83DCD12D
	v_dual_mov_b32 v21, v58 :: v_dual_mov_b32 v62, v108        // 0000003E0D9C: CA10013A 153E016C
	v_pk_fma_f16 v7, v13, s6, 0xc931 op_sel_hi:[1,0,0]         // 0000003E0DA4: CC0E0007 0BFC0D0D 0000C931
	v_dual_dot2acc_f32_f16 v5, v8, v2 :: v_dual_mov_b32 v8, v51// 0000003E0DB0: CB100508 05080133
	v_dual_mov_b32 v13, v44 :: v_dual_mov_b32 v22, v55         // 0000003E0DB8: CA10012C 0D160137
	v_sad_u8 v23, v23, 0, 0x6400                               // 0000003E0DC0: D6220017 03FD0117 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003E0DCC: BF870233
	v_dot2acc_f32_f16 v5, v7, v3                               // 0000003E0DD0: 040A0707
	v_add_nc_u32_e32 v3, v82, v83                              // 0000003E0DD4: 4A06A752
	v_dual_mov_b32 v7, v54 :: v_dual_mov_b32 v54, v100         // 0000003E0DD8: CA100136 07360164
	v_lshlrev_b32_e32 v23, 16, v23                             // 0000003E0DE0: 302E2E90
	v_dual_mov_b32 v29, v64 :: v_dual_mov_b32 v44, v90         // 0000003E0DE4: CA100140 1D2C015A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003E0DEC: BF870224
	v_cmp_eq_u32_e32 vcc_lo, 2, v3                             // 0000003E0DF0: 7C940682
	v_mov_b32_e32 v33, v67                                     // 0000003E0DF4: 7E420343
	v_and_or_b32 v23, 0xffff, v27, v23                         // 0000003E0DF8: D6570017 045E36FF 0000FFFF
	v_dual_mov_b32 v27, v47 :: v_dual_mov_b32 v68, v114        // 0000003E0E04: CA10012F 1B440172
	v_dual_mov_b32 v31, v48 :: v_dual_mov_b32 v64, v110        // 0000003E0E0C: CA100130 1F40016E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003E0E14: BF8701B3
	v_pk_fma_f16 v23, v23, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003E0E18: CC0E0017 0BFC0D17 0000C931
	v_and_b32_e32 v6, 0xffff, v6                               // 0000003E0E24: 360C0CFF 0000FFFF
	v_dual_mov_b32 v38, v74 :: v_dual_mov_b32 v39, v71         // 0000003E0E2C: CA10014A 26260147
	v_dual_mov_b32 v60, v106 :: v_dual_dot2acc_f32_f16 v77, v23, v4// 0000003E0E34: CA18016A 3C4C0917
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003E0E3C: BF870003
	.long 0xd72c0006                                           // 0000003E0E40: D72C0006
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 0000003E0E44: 02020CFF 83DCD12D
	v_dual_mov_b32 v23, v46 :: v_dual_mov_b32 v58, v104        // 0000003E0E4C: CA10012E 173A0168
	v_dual_mov_b32 v1, v66 :: v_dual_mov_b32 v74, v120         // 0000003E0E54: CA100142 014A0178
	v_dual_mov_b32 v51, v97 :: v_dual_mov_b32 v66, v112        // 0000003E0E5C: CA100161 33420170
	v_mov_b32_e32 v43, v89                                     // 0000003E0E64: 7E560359
	v_sad_u8 v6, v6, 0, 0x6400                                 // 0000003E0E68: D6220006 03FD0106 00006400
	v_mov_b32_e32 v65, v111                                    // 0000003E0E74: 7E82036F
	v_mov_b32_e32 v53, v99                                     // 0000003E0E78: 7E6A0363
	v_mov_b32_e32 v45, v91                                     // 0000003E0E7C: 7E5A035B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003E0E80: BF8701B4
	v_dual_mov_b32 v61, v107 :: v_dual_lshlrev_b32 v6, 16, v6  // 0000003E0E84: CA22016B 3D060C90
	v_dual_mov_b32 v55, v101 :: v_dual_mov_b32 v46, v92        // 0000003E0E8C: CA100165 372E015C
	v_dual_mov_b32 v70, v116 :: v_dual_mov_b32 v57, v103       // 0000003E0E94: CA100174 46380167
	v_and_or_b32 v6, 0xffff, v15, v6                           // 0000003E0E9C: D6570006 041A1EFF 0000FFFF
	v_dual_mov_b32 v15, v56 :: v_dual_mov_b32 v56, v102        // 0000003E0EA8: CA100138 0F380166
	v_dual_mov_b32 v47, v93 :: v_dual_mov_b32 v72, v118        // 0000003E0EB0: CA10015D 2F480176
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003E0EB8: BF8701B3
	v_pk_fma_f16 v2, v6, s6, 0xc931 op_sel_hi:[1,0,0]          // 0000003E0EBC: CC0E0002 0BFC0D06 0000C931
	v_dual_mov_b32 v6, v59 :: v_dual_mov_b32 v59, v105         // 0000003E0EC8: CA10013B 063A0169
	v_dual_mov_b32 v48, v94 :: v_dual_mov_b32 v67, v113        // 0000003E0ED0: CA10015E 30420171
	v_dot2acc_f32_f16 v5, v2, v4                               // 0000003E0ED8: 040A0902
	v_dual_mov_b32 v2, v50 :: v_dual_mov_b32 v73, v119         // 0000003E0EDC: CA100132 02480177
	v_mov_b32_e32 v69, v115                                    // 0000003E0EE4: 7E8A0373
	v_mov_b32_e32 v63, v109                                    // 0000003E0EE8: 7E7E036D
	v_mov_b32_e32 v49, v95                                     // 0000003E0EEC: 7E62035F
	v_dual_mov_b32 v71, v117 :: v_dual_mov_b32 v50, v96        // 0000003E0EF0: CA100175 47320160
	s_or_b32 s2, vcc_lo, s2                                    // 0000003E0EF8: 8C02026A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003E0EFC: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 0000003E0F00: 917E027E
	s_cbranch_execz 92                                         // 0000003E0F04: BFA5005C <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1f78>
	s_mov_b32 s7, exec_lo                                      // 0000003E0F08: BE87007E
	.long 0xd4c1007e                                           // 0000003E0F0C: D4C1007E
	v_cndmask_b32_e32 v1, v83, v42, vcc_lo                     // 0000003E0F10: 02025553
	s_cbranch_execz 64632                                      // 0000003E0F14: BFA5FC78 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xff8>
	v_mad_i64_i32 v[3:4], null, 0x300, v83, s[4:5]             // 0000003E0F18: D6FF7C03 0012A6FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E0F24: BF870091
	.long 0xd7006a61                                           // 0000003E0F28: D7006A61
	v_cndmask_b32_e32 v1, v3, v10, vcc_lo                      // 0000003E0F2C: 02021503
	v_add_co_ci_u32_e64 v98, null, v4, v11, vcc_lo             // 0000003E0F30: D5207C62 01AA1704
	.long 0xd7006a68                                           // 0000003E0F38: D7006A68
	v_cndmask_b32_e32 v1, v3, v87, vcc_lo                      // 0000003E0F3C: 0202AF03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003E0F40: BF8700A1
	v_add_co_ci_u32_e64 v105, null, 0, v4, vcc_lo              // 0000003E0F44: D5207C69 01AA0880
	.long 0xd7006a76                                           // 0000003E0F4C: D7006A76
	v_cndmask_b32_e32 v1, v3, v16, vcc_lo                      // 0000003E0F50: 02022103
	v_add_co_ci_u32_e64 v119, null, v4, v17, vcc_lo            // 0000003E0F54: D5207C77 01AA2304
	.long 0xd7006a03                                           // 0000003E0F5C: D7006A03
	v_cndmask_b32_e32 v1, v3, v88, vcc_lo                      // 0000003E0F60: 0202B103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E0F64: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 0000003E0F68: D5207C04 01AA0880
	s_clause 0x1f                                              // 0000003E0F70: BF85001F
	global_load_b32 v96, v[97:98], off                         // 0000003E0F74: DC520000 607C0061
	global_load_b32 v95, v[97:98], off offset:96               // 0000003E0F7C: DC520060 5F7C0061
	global_load_b32 v94, v[97:98], off offset:192              // 0000003E0F84: DC5200C0 5E7C0061
	global_load_b32 v93, v[97:98], off offset:288              // 0000003E0F8C: DC520120 5D7C0061
	global_load_b32 v92, v[97:98], off offset:384              // 0000003E0F94: DC520180 5C7C0061
	global_load_b32 v91, v[97:98], off offset:480              // 0000003E0F9C: DC5201E0 5B7C0061
	global_load_b32 v90, v[97:98], off offset:576              // 0000003E0FA4: DC520240 5A7C0061
	global_load_b32 v89, v[97:98], off offset:672              // 0000003E0FAC: DC5202A0 597C0061
	global_load_b32 v112, v[104:105], off                      // 0000003E0FB4: DC520000 707C0068
	global_load_b32 v109, v[104:105], off offset:96            // 0000003E0FBC: DC520060 6D7C0068
	global_load_b32 v106, v[104:105], off offset:192           // 0000003E0FC4: DC5200C0 6A7C0068
	global_load_b32 v103, v[104:105], off offset:288           // 0000003E0FCC: DC520120 677C0068
	global_load_b32 v101, v[104:105], off offset:384           // 0000003E0FD4: DC520180 657C0068
	global_load_b32 v99, v[104:105], off offset:480            // 0000003E0FDC: DC5201E0 637C0068
	global_load_b32 v98, v[104:105], off offset:576            // 0000003E0FE4: DC520240 627C0068
	global_load_b32 v97, v[104:105], off offset:672            // 0000003E0FEC: DC5202A0 617C0068
	global_load_b32 v117, v[118:119], off                      // 0000003E0FF4: DC520000 757C0076
	global_load_b32 v115, v[118:119], off offset:96            // 0000003E0FFC: DC520060 737C0076
	global_load_b32 v113, v[118:119], off offset:192           // 0000003E1004: DC5200C0 717C0076
	global_load_b32 v110, v[118:119], off offset:288           // 0000003E100C: DC520120 6E7C0076
	global_load_b32 v107, v[118:119], off offset:384           // 0000003E1014: DC520180 6B7C0076
	global_load_b32 v104, v[118:119], off offset:480           // 0000003E101C: DC5201E0 687C0076
	global_load_b32 v102, v[118:119], off offset:576           // 0000003E1024: DC520240 667C0076
	global_load_b32 v100, v[118:119], off offset:672           // 0000003E102C: DC5202A0 647C0076
	global_load_b32 v120, v[3:4], off                          // 0000003E1034: DC520000 787C0003
	global_load_b32 v119, v[3:4], off offset:96                // 0000003E103C: DC520060 777C0003
	global_load_b32 v118, v[3:4], off offset:192               // 0000003E1044: DC5200C0 767C0003
	global_load_b32 v116, v[3:4], off offset:288               // 0000003E104C: DC520120 747C0003
	global_load_b32 v114, v[3:4], off offset:384               // 0000003E1054: DC520180 727C0003
	global_load_b32 v111, v[3:4], off offset:480               // 0000003E105C: DC5201E0 6F7C0003
	global_load_b32 v108, v[3:4], off offset:576               // 0000003E1064: DC520240 6C7C0003
	global_load_b32 v105, v[3:4], off offset:672               // 0000003E106C: DC5202A0 697C0003
	s_branch 64544                                             // 0000003E1074: BFA0FC20 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xff8>
	s_or_b32 exec_lo, exec_lo, s2                              // 0000003E1078: 8C7E027E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003E107C: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003E1080: 8C7E037E
	s_waitcnt vmcnt(23)                                        // 0000003E1084: BF895FF7
	v_dual_mov_b32 v1, v81 :: v_dual_mov_b32 v2, v80           // 0000003E1088: CA100151 01020150
	v_dual_mov_b32 v3, v79 :: v_dual_mov_b32 v4, v78           // 0000003E1090: CA10014F 0304014E
	s_waitcnt vmcnt(0)                                         // 0000003E1098: BF8903F7
	v_dual_mov_b32 v6, v77 :: v_dual_mov_b32 v7, v76           // 0000003E109C: CA10014D 0606014C
	v_dual_mov_b32 v8, v75 :: v_dual_mov_b32 v9, v5            // 0000003E10A4: CA10014B 08080105
	s_mov_b32 s2, 0x76543210                                   // 0000003E10AC: BE8200FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003E10B4: BF870009
	v_permlanex16_b32 v1, v1, s2, 0xfedcba98                   // 0000003E10B8: D65C0001 03FC0501 FEDCBA98
	v_permlanex16_b32 v2, v2, s2, 0xfedcba98                   // 0000003E10C4: D65C0002 03FC0502 FEDCBA98
	v_permlanex16_b32 v3, v3, s2, 0xfedcba98                   // 0000003E10D0: D65C0003 03FC0503 FEDCBA98
	v_permlanex16_b32 v4, v4, s2, 0xfedcba98                   // 0000003E10DC: D65C0004 03FC0504 FEDCBA98
	v_permlanex16_b32 v6, v6, s2, 0xfedcba98                   // 0000003E10E8: D65C0006 03FC0506 FEDCBA98
	v_permlanex16_b32 v7, v7, s2, 0xfedcba98                   // 0000003E10F4: D65C0007 03FC0507 FEDCBA98
	v_permlanex16_b32 v8, v8, s2, 0xfedcba98                   // 0000003E1100: D65C0008 03FC0508 FEDCBA98
	v_permlanex16_b32 v9, v9, s2, 0xfedcba98                   // 0000003E110C: D65C0009 03FC0509 FEDCBA98
	.long 0xd44c0002                                           // 0000003E1118: D44C0002
	v_cndmask_b32_e32 v1, 16, v41, vcc_lo                      // 0000003E111C: 02025290
	s_barrier                                                  // 0000003E1120: BFBD0000
	buffer_gl0_inv                                             // 0000003E1124: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 0000003E112C: BE832002
	s_cbranch_execz 20                                         // 0000003E1130: BFA50014 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2084>
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v2, v80, v2    // 0000003E1134: C9081305 05020550
	v_dual_add_f32 v4, v78, v4 :: v_dual_lshlrev_b32 v9, 2, v41// 0000003E113C: C922094E 04085282
	v_dual_add_f32 v1, v81, v1 :: v_dual_add_f32 v8, v75, v8   // 0000003E1144: C9080351 0108114B
	v_dual_add_f32 v3, v79, v3 :: v_dual_add_f32 v6, v77, v6   // 0000003E114C: C908074F 03060D4D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003E1154: BF870003
	v_lshl_or_b32 v9, v40, 9, v9                               // 0000003E1158: D6560009 04251328
	v_add_f32_e32 v7, v76, v7                                  // 0000003E1160: 060E0F4C
	ds_store_2addr_b32 v9, v1, v2 offset1:16                   // 0000003E1164: D8381000 00020109
	ds_store_2addr_b32 v9, v3, v4 offset0:32 offset1:48        // 0000003E116C: D8383020 00040309
	ds_store_2addr_b32 v9, v6, v7 offset0:64 offset1:80        // 0000003E1174: D8385040 00070609
	ds_store_2addr_b32 v9, v8, v5 offset0:96 offset1:112       // 0000003E117C: D8387060 00050809
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003E1184: 8C7E037E
	.long 0xd44c0003                                           // 0000003E1188: D44C0003
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000003E118C: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 0000003E1194: BF89FC07
	s_barrier                                                  // 0000003E1198: BFBD0000
	buffer_gl0_inv                                             // 0000003E119C: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000003E11A4: BE842003
	s_cbranch_execnz 7                                         // 0000003E11A8: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x20c8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003E11AC: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 0000003E11B0: BF048215
	s_mov_b32 s4, -1                                           // 0000003E11B4: BE8400C1
	s_cbranch_scc0 33                                          // 0000003E11B8: BFA10021 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2140>
	s_and_b32 vcc_lo, exec_lo, s4                              // 0000003E11BC: 8B6A047E
	s_cbranch_vccz 63690                                       // 0000003E11C0: BFA3F8CA <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 164                                               // 0000003E11C4: BFA000A4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2358>
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000003E11C8: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:2            // 0000003E11CC: D8E00200 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:4 offset1:6  // 0000003E11D4: D8E00604 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:8 offset1:10 // 0000003E11DC: D8E00A08 05000007
	s_waitcnt lgkmcnt(2)                                       // 0000003E11E4: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 0000003E11E8: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003E11EC: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 0000003E11F0: 06020501
	s_waitcnt lgkmcnt(1)                                       // 0000003E11F4: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 0000003E11F8: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:12 offset1:14// 0000003E11FC: D8E00E0C 01000007
	v_add_f32_e32 v3, v3, v4                                   // 0000003E1204: 06060903
	s_waitcnt lgkmcnt(1)                                       // 0000003E1208: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E120C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 0000003E1210: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 0000003E1214: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 0000003E1218: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E121C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 0000003E1220: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 0000003E1224: 06020501
	ds_store_b32 v7, v1 offset:4096                            // 0000003E1228: D8341000 00000107
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003E1230: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 0000003E1234: BF048215
	s_mov_b32 s4, -1                                           // 0000003E1238: BE8400C1
	s_cbranch_scc1 65503                                       // 0000003E123C: BFA2FFDF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x20bc>
	s_load_b128 s[4:7], s[0:1], 0x1a8                          // 0000003E1240: F4080100 F80001A8
	s_lshl_b64 s[8:9], s[30:31], 2                             // 0000003E1248: 8488821E
	s_waitcnt lgkmcnt(0)                                       // 0000003E124C: BF89FC07
	s_barrier                                                  // 0000003E1250: BFBD0000
	buffer_gl0_inv                                             // 0000003E1254: E0AC0000 00000000
	s_add_u32 s1, s4, s8                                       // 0000003E125C: 80010804
	s_addc_u32 s4, s5, s9                                      // 0000003E1260: 82040905
	s_and_saveexec_b32 s0, s3                                  // 0000003E1264: BE802003
	s_cbranch_execz 17                                         // 0000003E1268: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x21b0>
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000003E126C: 30020082
	s_mul_hi_i32 s9, s23, s20                                  // 0000003E1270: 97091417
	s_mul_i32 s8, s23, s20                                     // 0000003E1274: 96081417
	s_lshl_b32 s10, s26, 7                                     // 0000003E1278: 840A871A
	s_lshl_b64 s[8:9], s[8:9], 2                               // 0000003E127C: 84888208
	ds_load_b32 v2, v1 offset:4096                             // 0000003E1280: D8D81000 02000001
	s_ashr_i32 s11, s10, 31                                    // 0000003E1288: 860B9F0A
	s_add_u32 s5, s1, s8                                       // 0000003E128C: 80050801
	s_addc_u32 s16, s4, s9                                     // 0000003E1290: 82100904
	s_lshl_b64 s[8:9], s[10:11], 2                             // 0000003E1294: 8488820A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003E1298: BF870009
	s_add_u32 s8, s5, s8                                       // 0000003E129C: 80080805
	s_addc_u32 s9, s16, s9                                     // 0000003E12A0: 82090910
	s_waitcnt lgkmcnt(0)                                       // 0000003E12A4: BF89FC07
	global_store_b32 v1, v2, s[8:9]                            // 0000003E12A8: DC6A0000 00080201
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003E12B0: 8C7E007E
	s_ashr_i32 s29, s28, 31                                    // 0000003E12B4: 861D9F1C
	.long 0xd44a0000                                           // 0000003E12B8: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000003E12BC: 02020080
	s_lshl_b64 s[8:9], s[28:29], 2                             // 0000003E12C0: 8488821C
	s_waitcnt_vscnt null, 0x0                                  // 0000003E12C4: BC7C0000
	buffer_gl1_inv                                             // 0000003E12C8: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003E12D0: E0AC0000 00000000
	s_add_u32 s6, s6, s8                                       // 0000003E12D8: 80060806
	s_addc_u32 s7, s7, s9                                      // 0000003E12DC: 82070907
	s_barrier                                                  // 0000003E12E0: BFBD0000
	buffer_gl0_inv                                             // 0000003E12E4: E0AC0000 00000000
	s_and_saveexec_b32 s5, s0                                  // 0000003E12EC: BE852000
	s_cbranch_execz 29                                         // 0000003E12F0: BFA5001D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2268>
	s_mov_b32 s9, exec_lo                                      // 0000003E12F4: BE89007E
	s_mov_b32 s8, exec_lo                                      // 0000003E12F8: BE88007E
	.long 0xd71f0001                                           // 0000003E12FC: D71F0001
	v_cndmask_b32_e32 v0, s9, v128, vcc_lo                     // 0000003E1300: 02010009
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1304: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 0000003E1308: 7D940280
	s_cbranch_execz 9                                          // 0000003E130C: BFA50009 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2234>
	s_lshl_b64 s[10:11], s[26:27], 2                           // 0000003E1310: 848A821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000003E1314: BF8704B9
	s_add_u32 s10, s6, s10                                     // 0000003E1318: 800A0A06
	s_addc_u32 s11, s7, s11                                    // 0000003E131C: 820B0B07
	s_bcnt1_i32_b32 s9, s9                                     // 0000003E1320: BE891809
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s9              // 0000003E1324: CA100080 02020009
	global_atomic_add_u32 v2, v2, v3, s[10:11] glc             // 0000003E132C: DCD64000 020A0302
	s_or_b32 exec_lo, exec_lo, s8                              // 0000003E1334: 8C7E087E
	s_waitcnt vmcnt(0)                                         // 0000003E1338: BF8903F7
	v_readfirstlane_b32 s8, v2                                 // 0000003E133C: 7E100502
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1340: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s8, v1       // 0000003E1344: CA200080 02000208
	s_add_i32 s8, s21, -1                                      // 0000003E134C: 8108C115
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000003E1350: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s8, v1                            // 0000003E1354: 7C940208
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000003E1358: D5010001 01A90280
	ds_store_b32 v2, v1 offset:5120                            // 0000003E1360: D8341400 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 0000003E1368: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 0000003E136C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000003E1370: BF89FC07
	s_barrier                                                  // 0000003E1374: BFBD0000
	buffer_gl0_inv                                             // 0000003E1378: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:5120                             // 0000003E1380: D8D81400 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000003E1388: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000003E138C: 7C940280
	s_cbranch_vccnz 48                                         // 0000003E1390: BFA40030 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2354>
	buffer_gl1_inv                                             // 0000003E1394: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003E139C: E0AC0000 00000000
	s_and_saveexec_b32 s8, s3                                  // 0000003E13A4: BE882003
	s_cbranch_execz 30                                         // 0000003E13A8: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2324>
	s_lshl_b32 s10, s26, 7                                     // 0000003E13AC: 840A871A
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 0000003E13B0: CA220080 04020082
	s_ashr_i32 s11, s10, 31                                    // 0000003E13B8: 860B9F0A
	s_ashr_i32 s5, s20, 31                                     // 0000003E13BC: 86059F14
	s_lshl_b64 s[10:11], s[10:11], 2                           // 0000003E13C0: 848A820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003E13C4: BF8700B9
	s_add_u32 s1, s1, s10                                      // 0000003E13C8: 80010A01
	s_addc_u32 s3, s4, s11                                     // 0000003E13CC: 82030B04
	.long 0xd7000101                                           // 0000003E13D0: D7000101
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 0000003E13D4: 02020601
	v_add_co_ci_u32_e64 v2, null, s3, 0, s1                    // 0000003E13D8: D5207C02 00050003
	s_mov_b32 s4, s20                                          // 0000003E13E0: BE840014
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003E13E4: BF870009
	s_lshl_b64 s[4:5], s[4:5], 2                               // 0000003E13E8: 84848204
	global_load_b32 v5, v[1:2], off glc                        // 0000003E13EC: DC524000 057C0001
	.long 0xd7006a01                                           // 0000003E13F4: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 0000003E13F8: 02000901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003E13FC: BF8704A1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000003E1400: D5207C02 01AA0405
	s_add_i32 s21, s21, -1                                     // 0000003E1408: 8115C115
	s_cmp_eq_u32 s21, 0                                        // 0000003E140C: BF068015
	s_waitcnt vmcnt(0)                                         // 0000003E1410: BF8903F7
	v_add_f32_e32 v4, v4, v5                                   // 0000003E1414: 06080B04
	s_cbranch_scc0 65524                                       // 0000003E1418: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x22ec>
	ds_store_b32 v3, v4 offset:4096                            // 0000003E141C: D8341000 00000403
	s_or_b32 exec_lo, exec_lo, s8                              // 0000003E1424: 8C7E087E
	s_and_saveexec_b32 s1, s0                                  // 0000003E1428: BE812000
	s_cbranch_execz 6                                          // 0000003E142C: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2348>
	s_lshl_b64 s[4:5], s[26:27], 2                             // 0000003E1430: 8484821A
	v_mov_b32_e32 v1, 0                                        // 0000003E1434: 7E020280
	s_add_u32 s4, s6, s4                                       // 0000003E1438: 80040406
	s_addc_u32 s5, s7, s5                                      // 0000003E143C: 82050507
	global_store_b32 v1, v1, s[4:5]                            // 0000003E1440: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 0000003E1448: 8C7E017E
	s_cbranch_execz 63527                                      // 0000003E144C: BFA5F827 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 1                                                 // 0000003E1450: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2358>
	s_branch 63525                                             // 0000003E1454: BFA0F825 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_cmp_eq_u32_e32 vcc_lo, 0, v40                            // 0000003E1458: 7C945080
	s_cmp_gt_i32 s18, 0                                        // 0000003E145C: BF028012
	s_waitcnt lgkmcnt(0)                                       // 0000003E1460: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000003E1464: BC7C0000
	s_cselect_b32 s0, -1, 0                                    // 0000003E1468: 980080C1
	s_barrier                                                  // 0000003E146C: BFBD0000
	s_and_b32 s0, vcc_lo, s0                                   // 0000003E1470: 8B00006A
	buffer_gl0_inv                                             // 0000003E1474: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000003E147C: BE812000
	s_cbranch_execz 63514                                      // 0000003E1480: BFA5F81A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_and_b32_e32 v1, 15, v0                                   // 0000003E1484: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1488: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000003E148C: 30040282
	v_add_nc_u32_e32 v8, 0x1000, v2                            // 0000003E1490: 4A1004FF 00001000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000003E1498: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000003E14A0: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000003E14A8: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000003E14B0: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000003E14B8: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000003E14BC: 36160082
	s_waitcnt lgkmcnt(3)                                       // 0000003E14C0: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 0000003E14C4: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 0000003E14CC: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 0000003E14D0: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 0000003E14D8: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000003E14DC: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000003E14E4: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 0000003E14E8: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 0000003E14F0: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 0000003E14F8: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003E14FC: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 0000003E1500: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 0000003E1508: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000003E1510: 7C941480
	.long 0xd44a0000                                           // 0000003E1514: D44A0000
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 0000003E1518: 02021680
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 0000003E151C: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 0000003E1524: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 0000003E1528: 08101D09
	.long 0xd44a0001                                           // 0000003E152C: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 0000003E1530: 02021880
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003E1534: BF870004
	v_add_f32_e32 v9, v13, v4                                  // 0000003E1538: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 0000003E153C: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 0000003E1544: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 0000003E1548: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 0000003E154C: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003E1550: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000003E1558: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003E1560: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003E1568: D5010009 21AA1309
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003E1570: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003E1578: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003E1580: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003E1588: D5010008 21AA1108
	v_add_f32_e32 v6, v7, v6                                   // 0000003E1590: 060C0D07
	v_add_f32_e32 v7, v9, v10                                  // 0000003E1594: 060E1509
	v_add_f32_e32 v5, v5, v15                                  // 0000003E1598: 060A1F05
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003E159C: 7E1C02FA FF01610D
	v_add_f32_e32 v8, v8, v16                                  // 0000003E15A4: 06102108
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003E15A8: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 0000003E15B0: D5010006 20020D06
	v_mov_b32_dpp v11, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003E15B8: 7E1602FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 0000003E15C0: D5010007 20020F07
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000003E15C8: D501000D 21AA1B0D
	v_mov_b32_dpp v22, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003E15D0: 7E2C02FA FF016104
	v_add_f32_e32 v6, v6, v10                                  // 0000003E15D8: 060C1506
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000003E15DC: D5010004 21AA0904
	v_add_f32_e32 v7, v7, v11                                  // 0000003E15E4: 060E1707
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003E15E8: BF8701A3
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003E15EC: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000003E15F4: D5010006 20060D06
	v_mov_b32_dpp v11, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003E15FC: 7E1602FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000003E1604: D5010007 20060F07
	v_add_f32_e32 v9, v13, v14                                 // 0000003E160C: 06121D0D
	v_add_f32_e32 v4, v4, v22                                  // 0000003E1610: 06082D04
	v_add_f32_e32 v20, v6, v10                                 // 0000003E1614: 06281506
	v_cndmask_b32_e64 v6, -v8, v8, s0                          // 0000003E1618: D5010006 20021108
	v_add_f32_e32 v10, v7, v11                                 // 0000003E1620: 06141707
	v_mov_b32_dpp v13, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003E1624: 7E1A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 0000003E162C: D5010009 20021309
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003E1634: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 0000003E163C: D5010005 20020B05
	v_mov_b32_dpp v19, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003E1644: 7E2602FA FF01680A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003E164C: BF870004
	v_add_f32_e32 v9, v9, v13                                  // 0000003E1650: 06121B09
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003E1654: 7E1A02FA FF016208
	v_mov_b32_dpp v8, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003E165C: 7E1002FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000003E1664: D5010003 21AA0703
	v_add_f32_e32 v5, v5, v14                                  // 0000003E166C: 060A1D05
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003E1670: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000003E1678: D5010009 20061309
	v_add_f32_e32 v6, v6, v13                                  // 0000003E1680: 060C1B06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003E1684: BF870224
	v_mov_b32_dpp v7, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003E1688: 7E0E02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 0000003E1690: D5010005 20060B05
	v_add_f32_e32 v17, v9, v12                                 // 0000003E1698: 06221909
	v_mov_b32_dpp v9, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003E169C: 7E1202FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000003E16A4: D5010002 21AA0502
	v_add_f32_e32 v3, v3, v8                                   // 0000003E16AC: 06061103
	v_mov_b32_dpp v8, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003E16B0: 7E1002FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 0000003E16B8: D5010004 20020904
	v_mov_b32_dpp v21, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003E16C0: 7E2A02FA FF016814
	v_add_f32_e32 v2, v2, v9                                   // 0000003E16C8: 06041302
	v_mov_b32_dpp v9, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003E16CC: 7E1202FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 0000003E16D4: D5010003 20020703
	v_add_f32_e32 v4, v4, v8                                   // 0000003E16DC: 06081104
	v_mov_b32_dpp v8, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003E16E0: 7E1002FA FF016406
	v_mov_b32_dpp v11, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003E16E8: 7E1602FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 0000003E16F0: D5010002 20020502
	v_add_f32_e32 v3, v3, v9                                   // 0000003E16F8: 06061303
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003E16FC: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000003E1704: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000003E170C: D5010006 20060D06
	v_add_f32_e32 v2, v2, v11                                  // 0000003E1714: 06041702
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003E1718: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000003E1720: D5010003 20060703
	v_add_f32_e32 v11, v4, v9                                  // 0000003E1728: 06161304
	v_add_f32_e32 v15, v5, v7                                  // 0000003E172C: 061E0F05
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003E1730: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 0000003E1738: D5010002 20060502
	v_add_f32_e32 v13, v6, v8                                  // 0000003E1740: 061A1106
	v_add_f32_e32 v8, v3, v12                                  // 0000003E1744: 06101903
	v_mov_b32_dpp v18, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003E1748: 7E2402FA FF016811
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003E1750: 7E2002FA FF01680F
	v_add_f32_e32 v6, v2, v14                                  // 0000003E1758: 060C1D02
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003E175C: 7E1C02FA FF01680D
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003E1764: 7E1802FA FF01680B
	v_mov_b32_dpp v9, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003E176C: 7E1202FA FF016808
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003E1774: BF870004
	v_mov_b32_dpp v7, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003E1778: 7E0E02FA FF016806
	s_and_b32 exec_lo, exec_lo, s2                             // 0000003E1780: 8B7E027E
	s_cbranch_execz 63321                                      // 0000003E1784: BFA5F759 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_lshl_or_b32 v3, s26, 7, v1                               // 0000003E1788: D6560003 04050E1A
	v_and_b32_e32 v0, 8, v0                                    // 0000003E1790: 36000088
	s_cmp_lg_u64 s[24:25], 0                                   // 0000003E1794: BF118018
	s_mov_b32 s2, 0                                            // 0000003E1798: BE820080
	s_cselect_b32 s1, -1, 0                                    // 0000003E179C: 980180C1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000003E17A0: 3408069F
	.long 0xd44a0000                                           // 0000003E17A4: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000003E17A8: 02020080
	s_cmp_eq_u64 s[24:25], 0                                   // 0000003E17AC: BF108018
	.long 0xd73c0001                                           // 0000003E17B0: D73C0001
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000003E17B4: 02020681
	v_cndmask_b32_e64 v0, -v20, v20, s0                        // 0000003E17B8: D5010000 20022914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003E17C0: BF870191
	v_add_f32_e32 v0, v0, v21                                  // 0000003E17C4: 06002B00
	.long 0xd7006a04                                           // 0000003E17C8: D7006A04
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 0000003E17CC: 0202020C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003E17D0: BF870191
	v_add_co_ci_u32_e64 v5, null, s13, v2, vcc_lo              // 0000003E17D4: D5207C05 01AA040D
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000003E17DC: 100000FF 3DB504F3
	global_load_d16_b16 v22, v[4:5], off                       // 0000003E17E4: DC820000 167C0004
	s_waitcnt vmcnt(0)                                         // 0000003E17EC: BF8903F7
	v_fma_mix_f32 v20, v22, v0, neg(0) op_sel_hi:[1,0,0]       // 0000003E17F0: CC200014 8A020116
	v_ashrrev_i32_e32 v0, 31, v3                               // 0000003E17F8: 3400069F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E17FC: BF870092
	v_bfe_u32 v21, v20, 16, 1                                  // 0000003E1800: D6100015 02052114
	v_add3_u32 v20, v20, v21, 0x7fff                           // 0000003E1808: D6550014 03FE2B14 00007FFF
	s_cbranch_scc1 537                                         // 0000003E1814: BFA20219 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2f7c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003E1818: BF870123
	v_lshrrev_b32_e32 v21, 23, v0                              // 0000003E181C: 322A0097
	v_dual_mov_b32 v26, s14 :: v_dual_mov_b32 v23, s15         // 0000003E1820: CA10000E 1A16000F
	v_add_nc_u32_e32 v21, v3, v21                              // 0000003E1828: 4A2A2B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003E182C: BF870121
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 0000003E1830: 362C2AFF FFFFFE00
	v_ashrrev_i32_e32 v21, 9, v21                              // 0000003E1838: 342A2A89
	v_sub_nc_u32_e32 v22, v3, v22                              // 0000003E183C: 4C2C2D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003E1840: BF870221
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 0000003E1844: 7C882CFF 00000100
	v_add_nc_u32_e32 v24, 0xffffff00, v22                      // 0000003E184C: 4A302CFF FFFFFF00
	v_dual_cndmask_b32 v26, s24, v26 :: v_dual_lshlrev_b32 v21, 8, v21// 0000003E1854: CA623418 1A142A88
	v_cndmask_b32_e32 v25, s25, v23, vcc_lo                    // 0000003E185C: 02322E19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003E1860: BF870193
	v_cndmask_b32_e32 v23, v24, v22, vcc_lo                    // 0000003E1864: 022E2D18
	v_ashrrev_i32_e32 v22, 31, v21                             // 0000003E1868: 342C2A9F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003E186C: BF870112
	v_ashrrev_i32_e32 v24, 31, v23                             // 0000003E1870: 34302E9F
	.long 0xd73c0015                                           // 0000003E1874: D73C0015
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 0000003E1878: 02022A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003E187C: BF870112
	.long 0xd73c0017                                           // 0000003E1880: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000003E1884: 02022E81
	.long 0xd7006a15                                           // 0000003E1888: D7006A15
	v_cndmask_b32_e32 v1, v26, v21, vcc_lo                     // 0000003E188C: 02022B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003E1890: BF870111
	v_add_co_ci_u32_e64 v22, null, v25, v22, vcc_lo            // 0000003E1894: D5207C16 01AA2D19
	.long 0xd7006a15                                           // 0000003E189C: D7006A15
	v_cndmask_b32_e32 v1, v21, v23, vcc_lo                     // 0000003E18A0: 02022F15
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E18A4: BF870001
	v_add_co_ci_u32_e64 v22, null, v22, v24, vcc_lo            // 0000003E18A8: D5207C16 01AA3116
	global_store_d16_hi_b16 v[21:22], v20, off                 // 0000003E18B0: DC960000 007C1415
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 0000003E18B8: 916A027E
	s_cbranch_vccnz 7                                          // 0000003E18BC: BFA40007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x27dc>
	.long 0xd7006a15                                           // 0000003E18C0: D7006A15
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000003E18C4: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E18C8: BF870001
	v_add_co_ci_u32_e64 v22, null, s15, v2, vcc_lo             // 0000003E18CC: D5207C16 01AA040F
	global_store_d16_hi_b16 v[21:22], v20, off                 // 0000003E18D4: DC960000 007C1415
	global_load_d16_b16 v20, v[4:5], off offset:32             // 0000003E18DC: DC820020 147C0004
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 0000003E18E4: D501000A 2002150A
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000003E18EC: 916A017E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E18F0: BF870091
	v_add_f32_e32 v10, v10, v19                                // 0000003E18F4: 0614270A
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 0000003E18F8: 101414FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003E1900: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003E1904: BF870121
	v_fma_mix_f32 v19, v20, v10, neg(0) op_sel_hi:[1,0,0]      // 0000003E1908: CC200013 8A021514
	v_cndmask_b32_e64 v10, 0, 1, s1                            // 0000003E1910: D501000A 00050280
	v_bfe_u32 v20, v19, 16, 1                                  // 0000003E1918: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1920: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000003E1924: D6550013 03FE2913 00007FFF
	s_cbranch_vccnz 467                                        // 0000003E1930: BFA401D3 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2f80>
	v_or_b32_e32 v20, 16, v3                                   // 0000003E1934: 38280690
	v_lshrrev_b32_e32 v21, 23, v0                              // 0000003E1938: 322A0097
	v_mov_b32_e32 v25, s14                                     // 0000003E193C: 7E32020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1940: BF870092
	v_add_nc_u32_e32 v21, v20, v21                             // 0000003E1944: 4A2A2B14
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 0000003E1948: 362C2AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1950: BF870091
	v_sub_nc_u32_e32 v22, v20, v22                             // 0000003E1954: 4C2C2D14
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 0000003E1958: 7C882CFF 00000100
	v_add_nc_u32_e32 v23, 0xffffff00, v22                      // 0000003E1960: 4A2E2CFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003E1968: BF8701B1
	v_dual_cndmask_b32 v25, s24, v25 :: v_dual_cndmask_b32 v22, v23, v22// 0000003E196C: CA523218 19162D17
	v_ashrrev_i32_e32 v20, 9, v21                              // 0000003E1974: 34282A89
	v_mov_b32_e32 v21, s15                                     // 0000003E1978: 7E2A020F
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000003E197C: 342E2C9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003E1980: BF870193
	v_lshlrev_b32_e32 v20, 8, v20                              // 0000003E1984: 30282888
	v_cndmask_b32_e32 v24, s25, v21, vcc_lo                    // 0000003E1988: 02302A19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003E198C: BF870193
	.long 0xd73c0016                                           // 0000003E1990: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000003E1994: 02022C81
	v_ashrrev_i32_e32 v21, 31, v20                             // 0000003E1998: 342A289F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E199C: BF870091
	.long 0xd73c0014                                           // 0000003E19A0: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000003E19A4: 02022881
	.long 0xd7006a14                                           // 0000003E19A8: D7006A14
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 0000003E19AC: 02022919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003E19B0: BF870111
	v_add_co_ci_u32_e64 v21, null, v24, v21, vcc_lo            // 0000003E19B4: D5207C15 01AA2B18
	.long 0xd7006a14                                           // 0000003E19BC: D7006A14
	v_cndmask_b32_e32 v1, v20, v22, vcc_lo                     // 0000003E19C0: 02022D14
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E19C4: BF870001
	v_add_co_ci_u32_e64 v21, null, v21, v23, vcc_lo            // 0000003E19C8: D5207C15 01AA2F15
	global_store_d16_hi_b16 v[20:21], v19, off                 // 0000003E19D0: DC960000 007C1314
	s_cbranch_execnz 7                                         // 0000003E19D8: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x28f8>
	.long 0xd7006a14                                           // 0000003E19DC: D7006A14
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000003E19E0: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E19E4: BF870001
	v_add_co_ci_u32_e64 v21, null, s15, v2, vcc_lo             // 0000003E19E8: D5207C15 01AA040F
	global_store_d16_hi_b16 v[20:21], v19, off offset:32       // 0000003E19F0: DC960020 007C1314
	global_load_d16_b16 v19, v[4:5], off offset:64             // 0000003E19F8: DC820040 137C0004
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 0000003E1A00: D5010011 20022311
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 0000003E1A08: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003E1A0C: BF8700A2
	v_add_f32_e32 v17, v17, v18                                // 0000003E1A10: 06222511
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003E1A14: 8B6A6A7E
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 0000003E1A18: 102222FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003E1A20: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1A24: BF870091
	v_fma_mix_f32 v17, v19, v17, neg(0) op_sel_hi:[1,0,0]      // 0000003E1A28: CC200011 8A022313
	v_bfe_u32 v18, v17, 16, 1                                  // 0000003E1A30: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1A38: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 0000003E1A3C: D6550011 03FE2511 00007FFF
	s_cbranch_vccnz 398                                        // 0000003E1A48: BFA4018E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2f84>
	v_or_b32_e32 v18, 32, v3                                   // 0000003E1A4C: 382406A0
	v_lshrrev_b32_e32 v19, 23, v0                              // 0000003E1A50: 32260097
	v_mov_b32_e32 v23, s14                                     // 0000003E1A54: 7E2E020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1A58: BF870092
	v_add_nc_u32_e32 v19, v18, v19                             // 0000003E1A5C: 4A262712
	v_and_b32_e32 v20, 0xfffffe00, v19                         // 0000003E1A60: 362826FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1A68: BF870091
	v_sub_nc_u32_e32 v20, v18, v20                             // 0000003E1A6C: 4C282912
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v20                        // 0000003E1A70: 7C8828FF 00000100
	v_add_nc_u32_e32 v21, 0xffffff00, v20                      // 0000003E1A78: 4A2A28FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003E1A80: BF8701B1
	v_dual_cndmask_b32 v23, s24, v23 :: v_dual_cndmask_b32 v20, v21, v20// 0000003E1A84: CA522E18 17142915
	v_ashrrev_i32_e32 v18, 9, v19                              // 0000003E1A8C: 34242689
	v_mov_b32_e32 v19, s15                                     // 0000003E1A90: 7E26020F
	v_ashrrev_i32_e32 v21, 31, v20                             // 0000003E1A94: 342A289F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003E1A98: BF870193
	v_lshlrev_b32_e32 v18, 8, v18                              // 0000003E1A9C: 30242488
	v_cndmask_b32_e32 v22, s25, v19, vcc_lo                    // 0000003E1AA0: 022C2619
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003E1AA4: BF870193
	.long 0xd73c0014                                           // 0000003E1AA8: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000003E1AAC: 02022881
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000003E1AB0: 3426249F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1AB4: BF870091
	.long 0xd73c0012                                           // 0000003E1AB8: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000003E1ABC: 02022481
	.long 0xd7006a12                                           // 0000003E1AC0: D7006A12
	v_cndmask_b32_e32 v1, v23, v18, vcc_lo                     // 0000003E1AC4: 02022517
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003E1AC8: BF870111
	v_add_co_ci_u32_e64 v19, null, v22, v19, vcc_lo            // 0000003E1ACC: D5207C13 01AA2716
	.long 0xd7006a12                                           // 0000003E1AD4: D7006A12
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 0000003E1AD8: 02022912
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1ADC: BF870001
	v_add_co_ci_u32_e64 v19, null, v19, v21, vcc_lo            // 0000003E1AE0: D5207C13 01AA2B13
	global_store_d16_hi_b16 v[18:19], v17, off                 // 0000003E1AE8: DC960000 007C1112
	s_cbranch_execnz 7                                         // 0000003E1AF0: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a10>
	.long 0xd7006a12                                           // 0000003E1AF4: D7006A12
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000003E1AF8: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1AFC: BF870001
	v_add_co_ci_u32_e64 v19, null, s15, v2, vcc_lo             // 0000003E1B00: D5207C13 01AA040F
	global_store_d16_hi_b16 v[18:19], v17, off offset:64       // 0000003E1B08: DC960040 007C1112
	global_load_d16_b16 v17, v[4:5], off offset:96             // 0000003E1B10: DC820060 117C0004
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 0000003E1B18: D501000F 20021F0F
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 0000003E1B20: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003E1B24: BF8700A2
	v_add_f32_e32 v15, v15, v16                                // 0000003E1B28: 061E210F
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003E1B2C: 8B6A6A7E
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 0000003E1B30: 101E1EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003E1B38: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1B3C: BF870091
	v_fma_mix_f32 v15, v17, v15, neg(0) op_sel_hi:[1,0,0]      // 0000003E1B40: CC20000F 8A021F11
	v_bfe_u32 v16, v15, 16, 1                                  // 0000003E1B48: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1B50: BF870001
	v_add3_u32 v15, v15, v16, 0x7fff                           // 0000003E1B54: D655000F 03FE210F 00007FFF
	s_cbranch_vccnz 329                                        // 0000003E1B60: BFA40149 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2f88>
	v_or_b32_e32 v16, 48, v3                                   // 0000003E1B64: 382006B0
	v_lshrrev_b32_e32 v17, 23, v0                              // 0000003E1B68: 32220097
	v_mov_b32_e32 v21, s14                                     // 0000003E1B6C: 7E2A020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1B70: BF870092
	v_add_nc_u32_e32 v17, v16, v17                             // 0000003E1B74: 4A222310
	v_and_b32_e32 v18, 0xfffffe00, v17                         // 0000003E1B78: 362422FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1B80: BF870091
	v_sub_nc_u32_e32 v18, v16, v18                             // 0000003E1B84: 4C242510
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v18                        // 0000003E1B88: 7C8824FF 00000100
	v_add_nc_u32_e32 v19, 0xffffff00, v18                      // 0000003E1B90: 4A2624FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003E1B98: BF8701B1
	v_dual_cndmask_b32 v21, s24, v21 :: v_dual_cndmask_b32 v18, v19, v18// 0000003E1B9C: CA522A18 15122513
	v_ashrrev_i32_e32 v16, 9, v17                              // 0000003E1BA4: 34202289
	v_mov_b32_e32 v17, s15                                     // 0000003E1BA8: 7E22020F
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000003E1BAC: 3426249F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003E1BB0: BF870193
	v_lshlrev_b32_e32 v16, 8, v16                              // 0000003E1BB4: 30202088
	v_cndmask_b32_e32 v20, s25, v17, vcc_lo                    // 0000003E1BB8: 02282219
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003E1BBC: BF870193
	.long 0xd73c0012                                           // 0000003E1BC0: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000003E1BC4: 02022481
	v_ashrrev_i32_e32 v17, 31, v16                             // 0000003E1BC8: 3422209F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1BCC: BF870091
	.long 0xd73c0010                                           // 0000003E1BD0: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000003E1BD4: 02022081
	.long 0xd7006a10                                           // 0000003E1BD8: D7006A10
	v_cndmask_b32_e32 v1, v21, v16, vcc_lo                     // 0000003E1BDC: 02022115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003E1BE0: BF870111
	v_add_co_ci_u32_e64 v17, null, v20, v17, vcc_lo            // 0000003E1BE4: D5207C11 01AA2314
	.long 0xd7006a10                                           // 0000003E1BEC: D7006A10
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 0000003E1BF0: 02022510
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1BF4: BF870001
	v_add_co_ci_u32_e64 v17, null, v17, v19, vcc_lo            // 0000003E1BF8: D5207C11 01AA2711
	global_store_d16_hi_b16 v[16:17], v15, off                 // 0000003E1C00: DC960000 007C0F10
	s_cbranch_execnz 7                                         // 0000003E1C08: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2b28>
	.long 0xd7006a10                                           // 0000003E1C0C: D7006A10
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000003E1C10: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1C14: BF870001
	v_add_co_ci_u32_e64 v17, null, s15, v2, vcc_lo             // 0000003E1C18: D5207C11 01AA040F
	global_store_d16_hi_b16 v[16:17], v15, off offset:96       // 0000003E1C20: DC960060 007C0F10
	global_load_d16_b16 v15, v[4:5], off offset:128            // 0000003E1C28: DC820080 0F7C0004
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 0000003E1C30: D501000D 20021B0D
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 0000003E1C38: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003E1C3C: BF8700A2
	v_add_f32_e32 v13, v13, v14                                // 0000003E1C40: 061A1D0D
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003E1C44: 8B6A6A7E
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 0000003E1C48: 101A1AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003E1C50: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1C54: BF870091
	v_fma_mix_f32 v13, v15, v13, neg(0) op_sel_hi:[1,0,0]      // 0000003E1C58: CC20000D 8A021B0F
	v_bfe_u32 v14, v13, 16, 1                                  // 0000003E1C60: D610000E 0205210D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1C68: BF870001
	v_add3_u32 v13, v13, v14, 0x7fff                           // 0000003E1C6C: D655000D 03FE1D0D 00007FFF
	s_cbranch_vccnz 260                                        // 0000003E1C78: BFA40104 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2f8c>
	v_or_b32_e32 v14, 64, v3                                   // 0000003E1C7C: 381C06C0
	v_lshrrev_b32_e32 v15, 23, v0                              // 0000003E1C80: 321E0097
	v_mov_b32_e32 v19, s14                                     // 0000003E1C84: 7E26020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1C88: BF870092
	v_add_nc_u32_e32 v15, v14, v15                             // 0000003E1C8C: 4A1E1F0E
	v_and_b32_e32 v16, 0xfffffe00, v15                         // 0000003E1C90: 36201EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1C98: BF870091
	v_sub_nc_u32_e32 v16, v14, v16                             // 0000003E1C9C: 4C20210E
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v16                        // 0000003E1CA0: 7C8820FF 00000100
	v_add_nc_u32_e32 v17, 0xffffff00, v16                      // 0000003E1CA8: 4A2220FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003E1CB0: BF8701B1
	v_dual_cndmask_b32 v19, s24, v19 :: v_dual_cndmask_b32 v16, v17, v16// 0000003E1CB4: CA522618 13102111
	v_ashrrev_i32_e32 v14, 9, v15                              // 0000003E1CBC: 341C1E89
	v_mov_b32_e32 v15, s15                                     // 0000003E1CC0: 7E1E020F
	v_ashrrev_i32_e32 v17, 31, v16                             // 0000003E1CC4: 3422209F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003E1CC8: BF870193
	v_lshlrev_b32_e32 v14, 8, v14                              // 0000003E1CCC: 301C1C88
	v_cndmask_b32_e32 v18, s25, v15, vcc_lo                    // 0000003E1CD0: 02241E19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003E1CD4: BF870193
	.long 0xd73c0010                                           // 0000003E1CD8: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000003E1CDC: 02022081
	v_ashrrev_i32_e32 v15, 31, v14                             // 0000003E1CE0: 341E1C9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1CE4: BF870091
	.long 0xd73c000e                                           // 0000003E1CE8: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000003E1CEC: 02021C81
	.long 0xd7006a0e                                           // 0000003E1CF0: D7006A0E
	v_cndmask_b32_e32 v1, v19, v14, vcc_lo                     // 0000003E1CF4: 02021D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003E1CF8: BF870111
	v_add_co_ci_u32_e64 v15, null, v18, v15, vcc_lo            // 0000003E1CFC: D5207C0F 01AA1F12
	.long 0xd7006a0e                                           // 0000003E1D04: D7006A0E
	v_cndmask_b32_e32 v1, v14, v16, vcc_lo                     // 0000003E1D08: 0202210E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1D0C: BF870001
	v_add_co_ci_u32_e64 v15, null, v15, v17, vcc_lo            // 0000003E1D10: D5207C0F 01AA230F
	global_store_d16_hi_b16 v[14:15], v13, off                 // 0000003E1D18: DC960000 007C0D0E
	s_cbranch_execnz 7                                         // 0000003E1D20: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2c40>
	.long 0xd7006a0e                                           // 0000003E1D24: D7006A0E
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000003E1D28: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1D2C: BF870001
	v_add_co_ci_u32_e64 v15, null, s15, v2, vcc_lo             // 0000003E1D30: D5207C0F 01AA040F
	global_store_d16_hi_b16 v[14:15], v13, off offset:128      // 0000003E1D38: DC960080 007C0D0E
	global_load_d16_b16 v13, v[4:5], off offset:160            // 0000003E1D40: DC8200A0 0D7C0004
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 0000003E1D48: D501000B 2002170B
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 0000003E1D50: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003E1D54: BF8700A2
	v_add_f32_e32 v11, v11, v12                                // 0000003E1D58: 0616190B
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003E1D5C: 8B6A6A7E
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 0000003E1D60: 101616FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003E1D68: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1D6C: BF870091
	v_fma_mix_f32 v11, v13, v11, neg(0) op_sel_hi:[1,0,0]      // 0000003E1D70: CC20000B 8A02170D
	v_bfe_u32 v12, v11, 16, 1                                  // 0000003E1D78: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1D80: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000003E1D84: D655000B 03FE190B 00007FFF
	s_cbranch_vccnz 191                                        // 0000003E1D90: BFA400BF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2f90>
	v_or_b32_e32 v12, 0x50, v3                                 // 0000003E1D94: 381806FF 00000050
	v_lshrrev_b32_e32 v13, 23, v0                              // 0000003E1D9C: 321A0097
	v_mov_b32_e32 v17, s14                                     // 0000003E1DA0: 7E22020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1DA4: BF870092
	v_add_nc_u32_e32 v13, v12, v13                             // 0000003E1DA8: 4A1A1B0C
	v_and_b32_e32 v14, 0xfffffe00, v13                         // 0000003E1DAC: 361C1AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1DB4: BF870091
	v_sub_nc_u32_e32 v14, v12, v14                             // 0000003E1DB8: 4C1C1D0C
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v14                        // 0000003E1DBC: 7C881CFF 00000100
	v_add_nc_u32_e32 v15, 0xffffff00, v14                      // 0000003E1DC4: 4A1E1CFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003E1DCC: BF8701B1
	v_dual_cndmask_b32 v17, s24, v17 :: v_dual_cndmask_b32 v14, v15, v14// 0000003E1DD0: CA522218 110E1D0F
	v_ashrrev_i32_e32 v12, 9, v13                              // 0000003E1DD8: 34181A89
	v_mov_b32_e32 v13, s15                                     // 0000003E1DDC: 7E1A020F
	v_ashrrev_i32_e32 v15, 31, v14                             // 0000003E1DE0: 341E1C9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003E1DE4: BF870193
	v_lshlrev_b32_e32 v12, 8, v12                              // 0000003E1DE8: 30181888
	v_cndmask_b32_e32 v16, s25, v13, vcc_lo                    // 0000003E1DEC: 02201A19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003E1DF0: BF870193
	.long 0xd73c000e                                           // 0000003E1DF4: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000003E1DF8: 02021C81
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000003E1DFC: 341A189F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1E00: BF870091
	.long 0xd73c000c                                           // 0000003E1E04: D73C000C
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000003E1E08: 02021881
	.long 0xd7006a0c                                           // 0000003E1E0C: D7006A0C
	v_cndmask_b32_e32 v1, v17, v12, vcc_lo                     // 0000003E1E10: 02021911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003E1E14: BF870111
	v_add_co_ci_u32_e64 v13, null, v16, v13, vcc_lo            // 0000003E1E18: D5207C0D 01AA1B10
	.long 0xd7006a0c                                           // 0000003E1E20: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 0000003E1E24: 02021D0C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1E28: BF870001
	v_add_co_ci_u32_e64 v13, null, v13, v15, vcc_lo            // 0000003E1E2C: D5207C0D 01AA1F0D
	global_store_d16_hi_b16 v[12:13], v11, off                 // 0000003E1E34: DC960000 007C0B0C
	s_cbranch_execnz 7                                         // 0000003E1E3C: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2d5c>
	.long 0xd7006a0c                                           // 0000003E1E40: D7006A0C
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000003E1E44: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1E48: BF870001
	v_add_co_ci_u32_e64 v13, null, s15, v2, vcc_lo             // 0000003E1E4C: D5207C0D 01AA040F
	global_store_d16_hi_b16 v[12:13], v11, off offset:160      // 0000003E1E54: DC9600A0 007C0B0C
	global_load_d16_b16 v11, v[4:5], off offset:192            // 0000003E1E5C: DC8200C0 0B7C0004
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 0000003E1E64: D5010008 20021108
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 0000003E1E6C: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003E1E70: BF8700A2
	v_add_f32_e32 v8, v8, v9                                   // 0000003E1E74: 06101308
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003E1E78: 8B6A6A7E
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 0000003E1E7C: 101010FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003E1E84: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1E88: BF870091
	v_fma_mix_f32 v8, v11, v8, neg(0) op_sel_hi:[1,0,0]        // 0000003E1E8C: CC200008 8A02110B
	v_bfe_u32 v9, v8, 16, 1                                    // 0000003E1E94: D6100009 02052108
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1E9C: BF870001
	v_add3_u32 v8, v8, v9, 0x7fff                              // 0000003E1EA0: D6550008 03FE1308 00007FFF
	s_cbranch_vccnz 121                                        // 0000003E1EAC: BFA40079 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2f94>
	v_or_b32_e32 v9, 0x60, v3                                  // 0000003E1EB0: 381206FF 00000060
	v_lshrrev_b32_e32 v11, 23, v0                              // 0000003E1EB8: 32160097
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1EBC: BF870091
	v_add_nc_u32_e32 v11, v9, v11                              // 0000003E1EC0: 4A161709
	v_and_b32_e32 v12, 0xfffffe00, v11                         // 0000003E1EC4: 361816FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003E1ECC: BF8701B1
	v_sub_nc_u32_e32 v9, v9, v12                               // 0000003E1ED0: 4C121909
	v_mov_b32_e32 v12, s15                                     // 0000003E1ED4: 7E18020F
	v_ashrrev_i32_e32 v11, 9, v11                              // 0000003E1ED8: 34161689
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v9                         // 0000003E1EDC: 7C8812FF 00000100
	v_add_nc_u32_e32 v13, 0xffffff00, v9                       // 0000003E1EE4: 4A1A12FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003E1EEC: BF8701A3
	v_lshlrev_b32_e32 v11, 8, v11                              // 0000003E1EF0: 30161688
	v_cndmask_b32_e32 v15, s25, v12, vcc_lo                    // 0000003E1EF4: 021E1819
	v_cndmask_b32_e32 v13, v13, v9, vcc_lo                     // 0000003E1EF8: 021A130D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003E1EFC: BF8701A3
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000003E1F00: 3418169F
	v_mov_b32_e32 v9, s14                                      // 0000003E1F04: 7E12020E
	v_ashrrev_i32_e32 v14, 31, v13                             // 0000003E1F08: 341C1A9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003E1F0C: BF870193
	.long 0xd73c000b                                           // 0000003E1F10: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000003E1F14: 02021681
	v_cndmask_b32_e32 v9, s24, v9, vcc_lo                      // 0000003E1F18: 02121218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003E1F1C: BF870113
	.long 0xd73c000d                                           // 0000003E1F20: D73C000D
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000003E1F24: 02021A81
	.long 0xd7006a09                                           // 0000003E1F28: D7006A09
	v_cndmask_b32_e32 v1, v9, v11, vcc_lo                      // 0000003E1F2C: 02021709
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003E1F30: BF870111
	v_add_co_ci_u32_e64 v12, null, v15, v12, vcc_lo            // 0000003E1F34: D5207C0C 01AA190F
	.long 0xd7006a0b                                           // 0000003E1F3C: D7006A0B
	v_cndmask_b32_e32 v1, v9, v13, vcc_lo                      // 0000003E1F40: 02021B09
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1F44: BF870001
	v_add_co_ci_u32_e64 v12, null, v12, v14, vcc_lo            // 0000003E1F48: D5207C0C 01AA1D0C
	global_store_d16_hi_b16 v[11:12], v8, off                  // 0000003E1F50: DC960000 007C080B
	s_cbranch_execnz 7                                         // 0000003E1F58: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2e78>
	.long 0xd7006a0b                                           // 0000003E1F5C: D7006A0B
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000003E1F60: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1F64: BF870001
	v_add_co_ci_u32_e64 v12, null, s15, v2, vcc_lo             // 0000003E1F68: D5207C0C 01AA040F
	global_store_d16_hi_b16 v[11:12], v8, off offset:192       // 0000003E1F70: DC9600C0 007C080B
	global_load_d16_b16 v4, v[4:5], off offset:224             // 0000003E1F78: DC8200E0 047C0004
	v_cndmask_b32_e64 v5, -v6, v6, s0                          // 0000003E1F80: D5010005 20020D06
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 0000003E1F88: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003E1F8C: BF8700A2
	v_add_f32_e32 v5, v5, v7                                   // 0000003E1F90: 060A0F05
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003E1F94: 8B6A6A7E
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 0000003E1F98: 100A0AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003E1FA0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1FA4: BF870091
	v_fma_mix_f32 v4, v4, v5, neg(0) op_sel_hi:[1,0,0]         // 0000003E1FA8: CC200004 8A020B04
	v_bfe_u32 v5, v4, 16, 1                                    // 0000003E1FB0: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E1FB8: BF870001
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000003E1FBC: D6550004 03FE0B04 00007FFF
	s_cbranch_vccnz 51                                         // 0000003E1FC8: BFA40033 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2f98>
	v_or_b32_e32 v3, 0x70, v3                                  // 0000003E1FCC: 380606FF 00000070
	v_lshrrev_b32_e32 v0, 23, v0                               // 0000003E1FD4: 32000097
	v_mov_b32_e32 v6, s15                                      // 0000003E1FD8: 7E0C020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1FDC: BF870092
	v_add_nc_u32_e32 v0, v3, v0                                // 0000003E1FE0: 4A000103
	v_and_b32_e32 v5, 0xfffffe00, v0                           // 0000003E1FE4: 360A00FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E1FEC: BF870091
	v_sub_nc_u32_e32 v3, v3, v5                                // 0000003E1FF0: 4C060B03
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v3                         // 0000003E1FF4: 7C8806FF 00000100
	v_add_nc_u32_e32 v7, 0xffffff00, v3                        // 0000003E1FFC: 4A0E06FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003E2004: BF8701B1
	v_cndmask_b32_e32 v7, v7, v3, vcc_lo                       // 0000003E2008: 020E0707
	v_mov_b32_e32 v3, s14                                      // 0000003E200C: 7E06020E
	v_ashrrev_i32_e32 v0, 9, v0                                // 0000003E2010: 34000089
	v_ashrrev_i32_e32 v8, 31, v7                               // 0000003E2014: 34100E9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003E2018: BF870193
	v_cndmask_b32_e32 v3, s24, v3, vcc_lo                      // 0000003E201C: 02060618
	v_dual_cndmask_b32 v0, s25, v6 :: v_dual_lshlrev_b32 v5, 8, v0// 0000003E2020: CA620C19 00040088
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003E2028: BF870113
	.long 0xd73c0007                                           // 0000003E202C: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 0000003E2030: 02020E81
	v_ashrrev_i32_e32 v6, 31, v5                               // 0000003E2034: 340C0A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003E2038: BF870091
	.long 0xd73c0005                                           // 0000003E203C: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000003E2040: 02020A81
	.long 0xd7006a03                                           // 0000003E2044: D7006A03
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000003E2048: 02020B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003E204C: BF870111
	v_add_co_ci_u32_e64 v0, null, v0, v6, vcc_lo               // 0000003E2050: D5207C00 01AA0D00
	.long 0xd7006a05                                           // 0000003E2058: D7006A05
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 0000003E205C: 02020F03
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E2060: BF870001
	v_add_co_ci_u32_e64 v6, null, v0, v8, vcc_lo               // 0000003E2064: D5207C06 01AA1100
	global_store_d16_hi_b16 v[5:6], v4, off                    // 0000003E206C: DC960000 007C0405
	s_cbranch_execnz 62749                                     // 0000003E2074: BFA6F51D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 7                                                 // 0000003E2078: BFA00007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2f98>
	s_branch 65040                                             // 0000003E207C: BFA0FE10 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x27c0>
	s_branch 65110                                             // 0000003E2080: BFA0FE56 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x28dc>
	s_branch 65179                                             // 0000003E2084: BFA0FE9B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x29f4>
	s_branch 65248                                             // 0000003E2088: BFA0FEE0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2b0c>
	s_branch 65317                                             // 0000003E208C: BFA0FF25 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2c24>
	s_branch 65387                                             // 0000003E2090: BFA0FF6B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2d40>
	s_branch 65457                                             // 0000003E2094: BFA0FFB1 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2e5c>
	.long 0xd7006a00                                           // 0000003E2098: D7006A00
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000003E209C: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003E20A0: BF870001
	v_add_co_ci_u32_e64 v1, null, s15, v2, vcc_lo              // 0000003E20A4: D5207C01 01AA040F
	global_store_d16_hi_b16 v[0:1], v4, off offset:224         // 0000003E20AC: DC9600E0 007C0400
	s_nop 0                                                    // 0000003E20B4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003E20B8: BFB60003
	s_endpgm                                                   // 0000003E20BC: BFB00000
		...

