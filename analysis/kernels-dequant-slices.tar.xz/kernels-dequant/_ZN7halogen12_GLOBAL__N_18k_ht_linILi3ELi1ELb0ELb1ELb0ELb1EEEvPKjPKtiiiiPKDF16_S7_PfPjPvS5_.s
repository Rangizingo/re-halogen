0000000000445d00 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x2                                               // 000000445D00: BF850002
	s_load_b128 s[24:27], s[0:1], 0x10                         // 000000445D04: F4080600 F8000010
	s_load_b256 s[12:19], s[0:1], 0x20                         // 000000445D0C: F40C0300 F8000020
	s_load_b128 s[20:23], s[0:1], 0x40                         // 000000445D14: F4080500 F8000040
	s_mov_b32 s4, s3                                           // 000000445D1C: BE840003
	v_and_b32_e32 v41, 31, v0                                  // 000000445D20: 3652009F
	v_lshrrev_b32_e32 v40, 5, v0                               // 000000445D24: 32500085
	s_delay_alu instid0(VALU_DEP_2)                            // 000000445D28: BF870002
	v_lshlrev_b32_e32 v14, 3, v41                              // 000000445D2C: 301C5283
	s_waitcnt lgkmcnt(0)                                       // 000000445D30: BF89FC07
	s_ashr_i32 s35, s25, 31                                    // 000000445D34: 86239F19
	s_mul_i32 s34, s27, s4                                     // 000000445D38: 9622041B
	s_lshr_b32 s3, s35, 25                                     // 000000445D3C: 85039923
	s_add_i32 s5, s34, s27                                     // 000000445D40: 81051B22
	s_add_i32 s3, s25, s3                                      // 000000445D44: 81030319
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000445D48: BF870499
	s_ashr_i32 s3, s3, 7                                       // 000000445D4C: 86038703
	s_min_i32 s3, s3, s5                                       // 000000445D50: 89030503
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000445D54: BF870009
	s_sub_i32 s11, s3, s34                                     // 000000445D58: 818B2203
	s_mov_b32 s3, exec_lo                                      // 000000445D5C: BE83007E
	.long 0xd4c3007e                                           // 000000445D60: D4C3007E
	v_cndmask_b32_e32 v1, s11, v40, vcc_lo                     // 000000445D64: 0202500B
	s_xor_b32 s3, exec_lo, s3                                  // 000000445D68: 8D03037E
	v_lshlrev_b32_e32 v14, 3, v41                              // 000000445D6C: 301C5283
	s_or_saveexec_b32 s10, s3                                  // 000000445D70: BE8A2203
	s_clause 0x1                                               // 000000445D74: BF850001
	s_load_b32 s33, s[0:1], 0x54                               // 000000445D78: F4000840 F8000054
	s_load_b128 s[28:31], s[0:1], null                         // 000000445D80: F4080700 F8000000
	v_lshlrev_b32_e32 v42, 2, v41                              // 000000445D88: 30545282
	s_xor_b32 exec_lo, exec_lo, s10                            // 000000445D8C: 8D7E0A7E
	s_cbranch_execz 499                                        // 000000445D90: BFA501F3 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x860>
	s_add_i32 s27, s24, -1                                     // 000000445D94: 811BC118
	s_cmp_lg_u64 s[22:23], 0                                   // 000000445D98: BF118016
	v_dual_mov_b32 v8, v40 :: v_dual_and_b32 v1, 1, v0         // 000000445D9C: CA240128 08000081
	s_cselect_b32 s36, -1, 0                                   // 000000445DA4: 982480C1
	s_abs_i32 s37, s11                                         // 000000445DA8: BEA5150B
	v_and_b32_e32 v3, 2, v0                                    // 000000445DAC: 36060082
	s_cvt_f32_u32 s0, s37                                      // 000000445DB0: BE806525
	v_and_b32_e32 v4, 4, v0                                    // 000000445DB4: 36080084
	v_and_b32_e32 v5, 8, v0                                    // 000000445DB8: 360A0088
	v_lshl_or_b32 v6, v40, 8, v14                              // 000000445DBC: D6560006 04391128
	v_rcp_iflag_f32_e32 v2, s0                                 // 000000445DC4: 7E045600
	v_add_nc_u32_e32 v7, s34, v40                              // 000000445DC8: 4A0E5022
	s_ashr_i32 s41, s11, 31                                    // 000000445DCC: 86299F0B
	s_sub_i32 s9, 0, s37                                       // 000000445DD0: 81892580
	s_mul_i32 s43, s41, 0x1400                                 // 000000445DD4: 962BFF29 00001400
	.long 0xd44c0000                                           // 000000445DDC: D44C0000
	v_cndmask_b32_e32 v1, 16, v41, vcc_lo                      // 000000445DE0: 02025290
	.long 0xd44a0001                                           // 000000445DE4: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000445DE8: 02020280
	.long 0xd44a0005                                           // 000000445DEC: D44A0005
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000445DF0: 02020880
	.long 0xd44a0006                                           // 000000445DF4: D44A0006
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000445DF8: 02020A80
	v_lshl_or_b32 v1, v7, 7, v42                               // 000000445DFC: D6560001 04A90F07
	v_readfirstlane_b32 s3, v2                                 // 000000445E04: 7E060502
	v_subrev_nc_u32_e32 v9, s43, v6                            // 000000445E08: 4E120C2B
	s_lshl_b32 s7, s11, 7                                      // 000000445E0C: 8407870B
	s_mov_b32 s38, s25                                         // 000000445E10: BEA60019
	s_mov_b32 s39, 0                                           // 000000445E14: BEA70080
	s_mul_f32 s8, s3, 0x4f7ffffe                               // 000000445E18: A208FF03 4F7FFFFE
	.long 0xd44a0003                                           // 000000445E20: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000445E24: 02020680
	s_mov_b32 s40, 0x76543210                                  // 000000445E28: BEA800FF 76543210
	s_lshl_b32 s42, s11, 8                                     // 000000445E30: 842A880B
	s_cvt_u32_f32 s8, s8                                       // 000000445E34: BE886708
	s_sub_i32 s43, 0, s7                                       // 000000445E38: 81AB0780
	s_mov_b32 s45, 0x3db504f3                                  // 000000445E3C: BEAD00FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000445E44: BF870499
	s_mul_i32 s9, s9, s8                                       // 000000445E48: 96090809
	s_mul_hi_u32 s9, s8, s9                                    // 000000445E4C: 96890908
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000445E50: BF870009
	s_add_i32 s44, s8, s9                                      // 000000445E54: 812C0908
	s_branch 161                                               // 000000445E58: BFA000A1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3e0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000445E5C: BF870091
	.long 0xd7006a02                                           // 000000445E60: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000445E64: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000445E68: D5207C03 01AA060D
	v_sub_f32_e32 v4, v16, v13                                 // 000000445E70: 08081B10
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000445E74: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000445E7C: DC820006 027C0002
	v_add_f32_e32 v3, v16, v13                                 // 000000445E84: 06061B10
	s_waitcnt vmcnt(0)                                         // 000000445E88: BF8903F7
	v_fma_mix_f32 v5, v15, v2, v12 op_sel_hi:[0,1,0]           // 000000445E8C: CC200005 1432050F
	v_fma_mix_f32 v2, -v15, v2, v12 op_sel_hi:[0,1,0]          // 000000445E94: CC200002 3432050F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000445E9C: BF870121
	v_dual_add_f32 v6, v3, v5 :: v_dual_add_f32 v7, v4, v2     // 000000445EA0: C9080B03 06060504
	v_sub_f32_e32 v2, v4, v2                                   // 000000445EA8: 08040504
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000445EAC: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000445EB4: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000445EBC: BF870141
	v_dual_add_f32 v4, v6, v4 :: v_dual_sub_f32 v3, v3, v5     // 000000445EC0: C90A0906 04020B03
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000445EC8: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000445ED0: D5010007 20060F07
	.long 0xd72c0006                                           // 000000445ED8: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 000000445EDC: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 000000445EE4: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000445EE8: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000445EF0: D5010004 200E0904
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000445EF8: 7E1A02FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000445F00: D5010002 20060502
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000445F08: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000445F10: D5010005 200E0B05
	v_add_f32_e32 v4, v4, v7                                   // 000000445F18: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000445F1C: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000445F24: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000445F2C: BF870234
	v_dual_add_f32 v2, v2, v13 :: v_dual_add_f32 v5, v5, v11   // 000000445F30: C9081B02 02041705
	.long 0xd72c0007                                           // 000000445F38: D72C0007
	v_cndmask_b32_e32 v1, s42, v10, vcc_lo                     // 000000445F3C: 0202142A
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000445F40: 7E1402FA FF016404
	v_add_f32_e32 v3, v3, v12                                  // 000000445F48: 06061903
	s_delay_alu instid0(VALU_DEP_4)                            // 000000445F4C: BF870004
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000445F50: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000445F58: D5010002 200E0502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000445F60: 7E1602FA FF016405
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000445F68: D5010004 20160904
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000445F70: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000445F78: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 000000445F80: 06041B02
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000445F84: D5010005 20160B05
	v_add_f32_e32 v4, v4, v10                                  // 000000445F8C: 06081504
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000445F90: 4C0C0F06
	v_add_f32_e32 v3, v3, v12                                  // 000000445F94: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000445F98: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000445FA0: D5010002 20160502
	v_add_f32_e32 v5, v5, v11                                  // 000000445FA8: 060A1705
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000445FAC: 7E1402FA FF016804
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000445FB4: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000445FBC: D5010003 20160703
	v_add_f32_e32 v2, v2, v13                                  // 000000445FC4: 06041B02
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000445FC8: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 000000445FD0: D5010005 201A0B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000445FD8: 4A101088
	v_add_f32_e32 v3, v3, v12                                  // 000000445FDC: 06061903
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 000000445FE0: D5010004 201A0904
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000445FE8: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 000000445FF0: D5010002 201A0502
	v_add_f32_e32 v5, v5, v11                                  // 000000445FF8: 060A1705
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000445FFC: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000446004: D5010003 201A0703
	v_add_f32_e32 v4, v4, v10                                  // 00000044600C: 06081504
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000446010: BF8701A4
	v_dual_add_f32 v2, v2, v13 :: v_dual_mov_b32 v11, v5       // 000000446014: C9101B02 020A0105
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 00000044601C: D5010005 20020B05
	v_dual_add_f32 v3, v3, v12 :: v_dual_mov_b32 v10, v4       // 000000446024: C9101903 030A0104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000044602C: BF870213
	v_mov_b32_e32 v13, v2                                      // 000000446030: 7E1A0302
	v_permlanex16_b32 v11, v11, s40, 0xfedcba98                // 000000446034: D65C000B 03FC510B FEDCBA98
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000446040: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_4)                            // 000000446048: BF870004
	v_mov_b32_e32 v12, v3                                      // 00000044604C: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000446050: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000446058: D5010003 20020703
	v_permlanex16_b32 v10, v10, s40, 0xfedcba98                // 000000446060: D65C000A 03FC510A FEDCBA98
	v_permlanex16_b32 v13, v13, s40, 0xfedcba98                // 00000044606C: D65C000D 03FC510D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 000000446078: 060A1705
	v_permlanex16_b32 v12, v12, s40, 0xfedcba98                // 00000044607C: D65C000C 03FC510C FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s11, v8                           // 000000446088: 7C86100B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000044608C: BF870224
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v7, v2, v13   // 000000446090: C9081504 04061B02
	v_add_nc_u32_e32 v6, v9, v6                                // 000000446098: 4A0C0D09
	v_dual_add_f32 v10, v3, v12 :: v_dual_add_nc_u32 v9, 0x800, v9// 00000044609C: C9201903 0A0812FF 00000800
	v_fma_mixhi_f16 v2, v5, s45, 0                             // 0000004460A8: CC220002 02005B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004460B0: BF870224
	v_fma_mixlo_f16 v2, v4, s45, 0                             // 0000004460B4: CC210002 02005B04
	v_fma_mixhi_f16 v3, v7, s45, 0                             // 0000004460BC: CC220003 02005B07
	v_fma_mixlo_f16 v3, v10, s45, 0                            // 0000004460C4: CC210003 02005B0A
	s_or_b32 s39, vcc_lo, s39                                  // 0000004460CC: 8C27276A
	ds_store_b64 v6, v[2:3]                                    // 0000004460D0: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s39                       // 0000004460D8: 917E277E
	s_cbranch_execz 287                                        // 0000004460DC: BFA5011F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x85c>
	.long 0xd72d0002                                           // 0000004460E0: D72D0002
	v_cndmask_b32_e32 v0, v8, v44, vcc_lo                      // 0000004460E4: 02005908
	s_mov_b32 s7, -1                                           // 0000004460E8: BE8700C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004460EC: BF870091
	.long 0xd72c0003                                           // 0000004460F0: D72C0003
	v_cndmask_b32_e32 v0, v2, v37, vcc_lo                      // 0000004460F4: 02004B02
	v_sub_nc_u32_e32 v3, v8, v3                                // 0000004460F8: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004460FC: BF870121
	v_subrev_nc_u32_e32 v5, s37, v3                            // 000000446100: 4E0A0625
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000446104: 7C960625
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000446108: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000446110: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000446114: 02040902
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000446118: 7C960625
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044611C: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000446120: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000446124: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s36                        // 000000446128: 916A247E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044612C: BF870091
	v_xor_b32_e32 v11, s41, v2                                 // 000000446130: 3A160429
	v_subrev_nc_u32_e32 v10, s41, v11                          // 000000446134: 4E141629
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000446138: BF8700A1
	v_mad_u64_u32 v[6:7], null, s43, v10, v[1:2]               // 00000044613C: D6FE7C06 0406142B
	v_min_i32_e32 v2, s27, v10                                 // 000000446144: 2204141B
	v_mad_i64_i32 v[4:5], null, v2, s38, 0                     // 000000446148: D6FF7C04 02004D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000446150: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000446154: 340E0C9F
	.long 0xd73c0002                                           // 000000446158: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000044615C: 02020C81
	s_cbranch_vccnz 209                                        // 000000446160: BFA400D1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7a8>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000446164: BF870093
	.long 0xd7006a06                                           // 000000446168: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 00000044616C: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000446170: D5207C07 01AA0F05
	.long 0x7f3a3880                                           // 000000446178: 7F3A3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044617C: BF870112
	.long 0xd73c0006                                           // 000000446180: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000446184: 02020C81
	.long 0x7f40399d                                           // 000000446188: 7F40399D
	s_waitcnt lgkmcnt(0)                                       // 00000044618C: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000446190: BF870092
	.long 0xd7006a0c                                           // 000000446194: D7006A0C
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000446198: 02020C1E
	v_add_co_ci_u32_e64 v13, null, s31, v7, vcc_lo             // 00000044619C: D5207C0D 01AA0E1F
	.long 0xd7006a06                                           // 0000004461A4: D7006A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 0000004461A8: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004461AC: BF870001
	v_add_co_ci_u32_e64 v7, null, s23, v7, vcc_lo              // 0000004461B0: D5207C07 01AA0E17
	global_load_b64 v[12:13], v[12:13], off                    // 0000004461B8: DC560000 0C7C000C
	.long 0xd7006a0f                                           // 0000004461C0: D7006A0F
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000004461C4: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 0000004461C8: DC560000 067C0006
	v_add_co_ci_u32_e64 v16, null, s13, v3, vcc_lo             // 0000004461D0: D5207C10 01AA060D
	s_clause 0x1                                               // 0000004461D8: BF850001
	global_load_b32 v17, v[15:16], off                         // 0000004461DC: DC520000 117C000F
	global_load_d16_b16 v15, v[15:16], off offset:4            // 0000004461E4: DC820004 0F7C000F
	s_waitcnt vmcnt(3)                                         // 0000004461EC: BF890FF7
	.long 0x7e20390c                                           // 0000004461F0: 7E20390C
	v_and_b32_e32 v12, 0xffff0000, v12                         // 0000004461F4: 361818FF FFFF0000
	v_lshlrev_b32_e32 v18, 16, v13                             // 0000004461FC: 30241A90
	s_waitcnt vmcnt(2)                                         // 000000446200: BF890BF7
	v_and_b32_e32 v39, 0xffff0000, v6                          // 000000446204: 364E0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000044620C: BF870193
	v_dual_mul_f32 v19, 0xbfb8aa3b, v12 :: v_dual_lshlrev_b32 v6, 16, v6// 000000446210: C8E218FF 13060C90 BFB8AA3B
	v_dual_mul_f32 v21, 0xbfb8aa3b, v18 :: v_dual_lshlrev_b32 v16, 16, v16// 00000044621C: C8E224FF 15102090 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000446228: BF870092
	v_exp_f32_e32 v19, v19                                     // 00000044622C: 7E264B13
	v_exp_f32_e32 v21, v21                                     // 000000446230: 7E2A4B15
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000446234: BF870296
	v_dual_mul_f32 v20, 0xbfb8aa3b, v16 :: v_dual_add_f32 v19, 1.0, v19// 000000446238: C8C820FF 141226F2 BFB8AA3B
	v_add_f32_e32 v21, 1.0, v21                                // 000000446244: 062A2AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000446248: BF8701A2
	v_exp_f32_e32 v20, v20                                     // 00000044624C: 7E284B14
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000446250: 361A1AFF FFFF0000
	v_div_scale_f32 v23, null, v19, v19, v12                   // 000000446258: D6FC7C17 04322713
	v_div_scale_f32 v33, vcc_lo, v12, v19, v12                 // 000000446260: D6FC6A21 0432270C
	v_div_scale_f32 v25, null, v21, v21, v18                   // 000000446268: D6FC7C19 044A2B15
	v_div_scale_f32 v35, s7, v18, v21, v18                     // 000000446270: D6FC0723 044A2B12
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000446278: BF870114
	v_rcp_f32_e32 v26, v23                                     // 00000044627C: 7E345517
	v_rcp_f32_e32 v30, v25                                     // 000000446280: 7E3C5519
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000446284: BF870127
	v_add_f32_e32 v20, 1.0, v20                                // 000000446288: 062828F2
	v_mul_f32_e32 v22, 0xbfb8aa3b, v13                         // 00000044628C: 102C1AFF BFB8AA3B
	v_div_scale_f32 v24, null, v20, v20, v16                   // 000000446294: D6FC7C18 04422914
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 00000044629C: BF870392
	v_exp_f32_e32 v22, v22                                     // 0000004462A0: 7E2C4B16
	v_fma_f32 v34, -v23, v26, 1.0                              // 0000004462A4: D6130022 23CA3517
	v_div_scale_f32 v37, s8, v16, v20, v16                     // 0000004462AC: D6FC0825 04422910
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004462B4: BF8701A6
	v_fma_f32 v38, -v25, v30, 1.0                              // 0000004462B8: D6130026 23CA3D19
	v_rcp_f32_e32 v28, v24                                     // 0000004462C0: 7E385518
	v_fmac_f32_e32 v26, v34, v26                               // 0000004462C4: 56343522
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000004462C8: BF870312
	v_fmac_f32_e32 v30, v38, v30                               // 0000004462CC: 563C3D26
	v_add_f32_e32 v22, 1.0, v22                                // 0000004462D0: 062C2CF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000004462D4: BF870293
	v_mul_f32_e32 v38, v33, v26                                // 0000004462D8: 104C3521
	v_fma_f32 v36, -v24, v28, 1.0                              // 0000004462DC: D6130024 23CA3918
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004462E4: BF870193
	v_div_scale_f32 v27, null, v22, v22, v13                   // 0000004462E8: D6FC7C1B 04362D16
	v_fma_f32 v44, -v23, v38, v33                              // 0000004462F0: D613002C 24864D17
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004462F8: BF870193
	v_fmac_f32_e32 v28, v36, v28                               // 0000004462FC: 56383924
	v_rcp_f32_e32 v31, v27                                     // 000000446300: 7E3E551B
	v_div_scale_f32 v36, s9, v13, v22, v13                     // 000000446304: D6FC0924 04362D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044630C: BF870093
	v_fmac_f32_e32 v38, v44, v26                               // 000000446310: 564C352C
	v_fma_f32 v23, -v23, v38, v33                              // 000000446314: D6130017 24864D17
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044631C: BF870095
	v_fma_f32 v34, -v27, v31, 1.0                              // 000000446320: D6130022 23CA3F1B
	v_dual_fmac_f32 v31, v34, v31 :: v_dual_mul_f32 v34, v37, v28// 000000446328: C8063F22 1F223925
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000446330: BF870111
	v_mul_f32_e32 v45, v36, v31                                // 000000446334: 105A3F24
	v_fma_f32 v46, -v24, v34, v37                              // 000000446338: D613002E 24964518
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000446340: BF870092
	v_fma_f32 v44, -v27, v45, v36                              // 000000446344: D613002C 24925B1B
	v_dual_fmac_f32 v34, v46, v28 :: v_dual_fmac_f32 v45, v44, v31// 00000044634C: C800392E 222C3F2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000446354: BF870131
	v_fma_f32 v24, -v24, v34, v37                              // 000000446358: D6130018 24964518
	v_div_fmas_f32 v23, v23, v26, v38                          // 000000446360: D6370017 049A3517
	s_mov_b32 vcc_lo, s8                                       // 000000446368: BEEA0008
	v_div_fmas_f32 v24, v24, v28, v34                          // 00000044636C: D6370018 048A3918
	s_mov_b32 vcc_lo, s7                                       // 000000446374: BEEA0007
	s_delay_alu instid0(VALU_DEP_2)                            // 000000446378: BF870002
	v_div_fixup_f32 v12, v23, v19, v12                         // 00000044637C: D627000C 04322717
	v_fma_f32 v23, -v27, v45, v36                              // 000000446384: D6130017 24925B1B
	s_mov_b32 s7, 0                                            // 00000044638C: BE870080
	v_div_fixup_f32 v16, v24, v20, v16                         // 000000446390: D6270010 04422918
	v_lshlrev_b32_e32 v20, 16, v7                              // 000000446398: 30280E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 00000044639C: 360E0EFF FFFF0000
	v_dual_mul_f32 v43, v35, v30 :: v_dual_mul_f32 v12, v12, v39// 0000004463A4: C8C63D23 2B0C4F0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004463AC: BF870114
	v_mul_f32_e32 v6, v16, v6                                  // 0000004463B0: 100C0D10
	v_fma_f32 v47, -v25, v43, v35                              // 0000004463B4: D613002F 248E5719
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004463BC: BF870193
	.long 0x7e3a398c                                           // 0000004463C0: 7E3A398C
	.long 0x7e403986                                           // 0000004463C4: 7E403986
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004463C8: BF870093
	v_fmac_f32_e32 v43, v47, v30                               // 0000004463CC: 56563D2F
	v_fma_f32 v25, -v25, v43, v35                              // 0000004463D0: D6130019 248E5719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000004463D8: BF870131
	v_div_fmas_f32 v19, v25, v30, v43                          // 0000004463DC: D6370013 04AE3D19
	s_mov_b32 vcc_lo, s9                                       // 0000004463E4: BEEA0009
	v_div_fmas_f32 v16, v23, v31, v45                          // 0000004463E8: D6370010 04B63F17
	v_div_fixup_f32 v18, v19, v21, v18                         // 0000004463F0: D6270012 044A2B13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004463F8: BF8701A2
	v_div_fixup_f32 v13, v16, v22, v13                         // 0000004463FC: D627000D 04362D10
	v_and_b32_e32 v16, 1, v29                                  // 000000446404: 36203A81
	v_mul_f32_e32 v18, v18, v20                                // 000000446408: 10242912
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000044640C: BF870193
	v_dual_mul_f32 v7, v13, v7 :: v_dual_and_b32 v20, 1, v32   // 000000446410: C8E40F0D 07144081
	v_add3_u32 v12, v12, v16, 0x7fff                           // 000000446418: D655000C 03FE210C 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000446424: BF870193
	v_bfe_u32 v19, v18, 16, 1                                  // 000000446428: D6100013 02052112
	v_add3_u32 v6, v6, v20, 0x7fff                             // 000000446430: D6550006 03FE2906 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000044643C: BF870214
	v_bfe_u32 v16, v7, 16, 1                                   // 000000446440: D6100010 02052107
	v_and_b32_e32 v12, 0xffff0000, v12                         // 000000446448: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000446450: BF870214
	v_add3_u32 v13, v18, v19, 0x7fff                           // 000000446454: D655000D 03FE2712 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000446460: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000446468: BF870194
	v_add3_u32 v7, v7, v16, 0x7fff                             // 00000044646C: D6550007 03FE2107 00007FFF
	v_and_b32_e32 v18, 0xffff0000, v13                         // 000000446478: 36241AFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 000000446480: BF8907F7
	v_fma_mix_f32 v13, v17, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000446484: CC20080D 8A021911
	v_fma_mix_f32 v16, v17, v6, neg(0) op_sel_hi:[1,0,0]       // 00000044648C: CC200010 8A020D11
	s_waitcnt vmcnt(0)                                         // 000000446494: BF8903F7
	v_fma_mix_f32 v12, v15, v18, neg(0) op_sel_hi:[1,0,0]      // 000000446498: CC20000C 8A02250F
	v_and_b32_e32 v15, 0xffff0000, v7                          // 0000004464A0: 361E0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000004464A8: 916A077E
	s_cbranch_vccnz 65131                                      // 0000004464AC: BFA4FE6B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x15c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004464B0: BF8700A3
	.long 0xd73c0004                                           // 0000004464B4: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000004464B8: 02020881
	s_waitcnt lgkmcnt(0)                                       // 0000004464BC: BF89FC07
	.long 0xd7006a04                                           // 0000004464C0: D7006A04
	v_cndmask_b32_e32 v1, s30, v4, vcc_lo                      // 0000004464C4: 0202081E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004464C8: BF870111
	v_add_co_ci_u32_e64 v5, null, s31, v5, vcc_lo              // 0000004464CC: D5207C05 01AA0A1F
	.long 0xd7006a04                                           // 0000004464D4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000004464D8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004464DC: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000004464E0: D5207C05 01AA0705
	.long 0xd7006a06                                           // 0000004464E8: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000004464EC: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 0000004464F0: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 0000004464F8: DC560000 047C0004
	s_clause 0x1                                               // 000000446500: BF850001
	global_load_b32 v15, v[6:7], off                           // 000000446504: DC520000 0F7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 00000044650C: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000446514: BF890BF7
	.long 0x7e0e3904                                           // 000000446518: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000044651C: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 000000446524: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000446528: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 00000044652C: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000446530: BF8907F7
	v_fma_mix_f32 v13, v15, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000446534: CC20080D 8A02090F
	s_waitcnt vmcnt(0)                                         // 00000044653C: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 000000446540: CC20000C 8A021906
	v_fma_mix_f32 v16, v15, v7, neg(0) op_sel_hi:[1,0,0]       // 000000446548: CC200010 8A020F0F
	v_and_b32_e32 v15, 0xffff0000, v5                          // 000000446550: 361E0AFF FFFF0000
	s_branch 65088                                             // 000000446558: BFA0FE40 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x15c>
	s_or_b32 exec_lo, exec_lo, s39                             // 00000044655C: 8C7E277E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000446560: BF870009
	s_or_b32 exec_lo, exec_lo, s10                             // 000000446564: 8C7E0A7E
	s_bfe_i32 s10, s11, 0x1001c                                // 000000446568: 938AFF0B 0001001C
	v_mad_u32_u24 v4, v41, 24, 0x2f0                           // 000000446570: D60B0004 03FD3129 000002F0
	s_lshr_b64 s[0:1], s[10:11], 29                            // 00000044657C: 85809D0A
	s_lshr_b32 s1, s35, 28                                     // 000000446580: 85019C23
	s_add_i32 s0, s0, 7                                        // 000000446584: 81008700
	s_add_i32 s1, s25, s1                                      // 000000446588: 81010119
	s_ashr_i32 s0, s0, 3                                       // 00000044658C: 86008300
	v_lshrrev_b32_e32 v1, 5, v4                                // 000000446590: 32020885
	.long 0xd72c0003                                           // 000000446594: D72C0003
	v_cndmask_b32_e32 v1, s0, v40, vcc_lo                      // 000000446598: 02025000
	s_ashr_i32 s1, s1, 4                                       // 00000044659C: 86018401
	s_lshl_b32 s3, s11, 3                                      // 0000004465A0: 8403830B
	s_lshl_b32 s5, s34, 3                                      // 0000004465A4: 84058322
	s_mul_hi_i32 s7, s1, s2                                    // 0000004465A8: 97070201
	s_mul_i32 s1, s1, s2                                       // 0000004465AC: 96010201
	s_ashr_i32 s6, s5, 31                                      // 0000004465B0: 86069F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v41                            // 0000004465B4: 7C945280
	v_add_nc_u32_e32 v2, s0, v3                                // 0000004465B8: 4A040600
	s_add_u32 s0, s1, s5                                       // 0000004465BC: 80000501
	s_addc_u32 s1, s7, s6                                      // 0000004465C0: 82010607
	s_mul_i32 s5, s0, 0x300                                    // 0000004465C4: 9605FF00 00000300
	s_mulk_i32 s1, 0x300                                       // 0000004465CC: B8010300
	v_min_i32_e32 v43, s3, v2                                  // 0000004465D0: 22560403
	v_subrev_nc_u32_e32 v2, 24, v1                             // 0000004465D4: 4E040298
	v_add_nc_u32_e32 v1, 1, v3                                 // 0000004465D8: 4A020681
	s_mul_hi_u32 s3, s0, 0x300                                 // 0000004465DC: 9683FF00 00000300
	v_add_nc_u32_e32 v15, 8, v4                                // 0000004465E4: 4A1E0888
	s_add_i32 s3, s3, s1                                       // 0000004465E8: 81030103
	v_cndmask_b32_e64 v16, v2, 23, vcc_lo                      // 0000004465EC: D5010010 01A92F02
	.long 0xd4410000                                           // 0000004465F4: D4410000
	v_cndmask_b32_e32 v1, v1, v43, vcc_lo                      // 0000004465F8: 02025701
	s_waitcnt lgkmcnt(0)                                       // 0000004465FC: BF89FC07
	s_add_u32 s6, s28, s5                                      // 000000446600: 8006051C
	s_addc_u32 s7, s29, s3                                     // 000000446604: 8207031D
	s_barrier                                                  // 000000446608: BFBD0000
	buffer_gl0_inv                                             // 00000044660C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000446614: BE812000
	s_cbranch_execz 123                                        // 000000446618: BFA5007B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb08>
	v_lshrrev_b32_e32 v2, 5, v15                               // 00000044661C: 32041E85
	.long 0xd4440000                                           // 000000446620: D4440000
	v_cndmask_b32_e32 v1, 23, v16, vcc_lo                      // 000000446624: 02022097
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000446628: BF870112
	v_subrev_nc_u32_e32 v2, 24, v2                             // 00000044662C: 4E040498
	v_cndmask_b32_e64 v5, 0xe9, 1, s0                          // 000000446630: D5010005 000102FF 000000E9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000044663C: BF870191
	v_add_nc_u32_e32 v9, v5, v16                               // 000000446640: 4A122105
	v_cndmask_b32_e64 v5, v2, 23, vcc_lo                       // 000000446644: D5010005 01A92F02
	v_mov_b32_e32 v17, 0                                       // 00000044664C: 7E220280
	v_mad_i64_i32 v[1:2], null, 0x300, v1, s[6:7]              // 000000446650: D6FF7C01 001A02FF 00000300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000044665C: BF870214
	v_lshlrev_b32_e32 v10, 24, v9                              // 000000446660: 30141298
	.long 0xd4440000                                           // 000000446664: D4440000
	v_cndmask_b32_e32 v1, 23, v5, vcc_lo                       // 000000446668: 02020A97
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000044666C: BF870224
	.long 0xd73c0007                                           // 000000446670: D73C0007
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 000000446674: 02022082
	v_bfe_i32 v12, v9, 7, 1                                    // 000000446678: D611000C 02050F09
	v_ashrrev_i32_e32 v9, 22, v10                              // 000000446680: 34121496
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000446684: BF8700B4
	v_cndmask_b32_e64 v11, 0xe9, 1, s0                         // 000000446688: D501000B 000102FF 000000E9
	v_mov_b32_e32 v6, v17                                      // 000000446694: 7E0C0311
	.long 0xd7000007                                           // 000000446698: D7000007
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 00000044669C: 02020F01
	v_add_co_ci_u32_e64 v8, null, v2, v8, s0                   // 0000004466A0: D5207C08 00021102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004466A8: BF870214
	v_add_nc_u32_e32 v11, v11, v5                              // 0000004466AC: 4A160B0B
	.long 0xd73c0005                                           // 0000004466B0: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000004466B4: 02020A82
	.long 0xd7000009                                           // 0000004466B8: D7000009
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 0000004466BC: 02021301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004466C0: BF870211
	v_add_co_ci_u32_e64 v10, null, v2, v12, s0                 // 0000004466C4: D5207C0A 00021902
	v_lshlrev_b32_e32 v13, 24, v11                             // 0000004466CC: 301A1698
	v_bfe_i32 v11, v11, 7, 1                                   // 0000004466D0: D611000B 02050F0B
	.long 0xd7000005                                           // 0000004466D8: D7000005
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 0000004466DC: 02020B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004466E0: BF870211
	v_add_co_ci_u32_e64 v6, null, v2, v6, s0                   // 0000004466E4: D5207C06 00020D02
	v_ashrrev_i32_e32 v12, 22, v13                             // 0000004466EC: 34181A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004466F0: BF870091
	.long 0xd7000001                                           // 0000004466F4: D7000001
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 0000004466F8: 02021901
	v_add_co_ci_u32_e64 v2, null, v2, v11, s0                  // 0000004466FC: D5207C02 00021702
	s_clause 0x1f                                              // 000000446704: BF85001F
	global_load_b32 v51, v[7:8], off                           // 000000446708: DC520000 337C0007
	global_load_b32 v50, v[7:8], off offset:96                 // 000000446710: DC520060 327C0007
	global_load_b32 v49, v[7:8], off offset:192                // 000000446718: DC5200C0 317C0007
	global_load_b32 v48, v[7:8], off offset:288                // 000000446720: DC520120 307C0007
	global_load_b32 v47, v[7:8], off offset:384                // 000000446728: DC520180 2F7C0007
	global_load_b32 v46, v[7:8], off offset:480                // 000000446730: DC5201E0 2E7C0007
	global_load_b32 v45, v[7:8], off offset:576                // 000000446738: DC520240 2D7C0007
	global_load_b32 v44, v[7:8], off offset:672                // 000000446740: DC5202A0 2C7C0007
	global_load_b32 v67, v[9:10], off                          // 000000446748: DC520000 437C0009
	global_load_b32 v64, v[9:10], off offset:96                // 000000446750: DC520060 407C0009
	global_load_b32 v61, v[9:10], off offset:192               // 000000446758: DC5200C0 3D7C0009
	global_load_b32 v58, v[9:10], off offset:288               // 000000446760: DC520120 3A7C0009
	global_load_b32 v56, v[9:10], off offset:384               // 000000446768: DC520180 387C0009
	global_load_b32 v54, v[9:10], off offset:480               // 000000446770: DC5201E0 367C0009
	global_load_b32 v53, v[9:10], off offset:576               // 000000446778: DC520240 357C0009
	global_load_b32 v52, v[9:10], off offset:672               // 000000446780: DC5202A0 347C0009
	global_load_b32 v72, v[5:6], off                           // 000000446788: DC520000 487C0005
	global_load_b32 v70, v[5:6], off offset:96                 // 000000446790: DC520060 467C0005
	global_load_b32 v68, v[5:6], off offset:192                // 000000446798: DC5200C0 447C0005
	global_load_b32 v65, v[5:6], off offset:288                // 0000004467A0: DC520120 417C0005
	global_load_b32 v62, v[5:6], off offset:384                // 0000004467A8: DC520180 3E7C0005
	global_load_b32 v59, v[5:6], off offset:480                // 0000004467B0: DC5201E0 3B7C0005
	global_load_b32 v57, v[5:6], off offset:576                // 0000004467B8: DC520240 397C0005
	global_load_b32 v55, v[5:6], off offset:672                // 0000004467C0: DC5202A0 377C0005
	global_load_b32 v75, v[1:2], off                           // 0000004467C8: DC520000 4B7C0001
	global_load_b32 v74, v[1:2], off offset:96                 // 0000004467D0: DC520060 4A7C0001
	global_load_b32 v73, v[1:2], off offset:192                // 0000004467D8: DC5200C0 497C0001
	global_load_b32 v71, v[1:2], off offset:288                // 0000004467E0: DC520120 477C0001
	global_load_b32 v69, v[1:2], off offset:384                // 0000004467E8: DC520180 457C0001
	global_load_b32 v66, v[1:2], off offset:480                // 0000004467F0: DC5201E0 427C0001
	global_load_b32 v63, v[1:2], off offset:576                // 0000004467F8: DC520240 3F7C0001
	global_load_b32 v60, v[1:2], off offset:672                // 000000446800: DC5202A0 3C7C0001
	s_or_b32 exec_lo, exec_lo, s1                              // 000000446808: 8C7E017E
	.long 0xd4410000                                           // 00000044680C: D4410000
	v_cndmask_b32_e32 v1, v3, v43, vcc_lo                      // 000000446810: 02025703
	s_and_saveexec_b32 s3, s0                                  // 000000446814: BE832000
	s_cbranch_execz 121                                        // 000000446818: BFA50079 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xd00>
	v_lshrrev_b32_e32 v1, 5, v15                               // 00000044681C: 32021E85
	.long 0xd4440001                                           // 000000446820: D4440001
	v_cndmask_b32_e32 v1, 23, v16, vcc_lo                      // 000000446824: 02022097
	v_mov_b32_e32 v17, 0                                       // 000000446828: 7E220280
	v_mad_i64_i32 v[5:6], null, 0x300, v3, s[6:7]              // 00000044682C: D6FF7C05 001A06FF 00000300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000446838: BF870214
	v_subrev_nc_u32_e32 v1, 24, v1                             // 00000044683C: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s1                          // 000000446840: D5010002 000502FF 000000E9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044684C: BF870112
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 000000446850: D5010001 01A92F01
	v_dual_mov_b32 v2, v17 :: v_dual_add_nc_u32 v9, v2, v16    // 000000446858: CA200111 02082102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000446860: BF870112
	.long 0xd4440001                                           // 000000446864: D4440001
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 000000446868: 02020297
	v_lshlrev_b32_e32 v10, 24, v9                              // 00000044686C: 30141298
	.long 0xd73c0007                                           // 000000446870: D73C0007
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 000000446874: 02022082
	v_bfe_i32 v9, v9, 7, 1                                     // 000000446878: D6110009 02050F09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000446880: BF870214
	v_cndmask_b32_e64 v11, 0xe9, 1, s1                         // 000000446884: D501000B 000502FF 000000E9
	v_ashrrev_i32_e32 v10, 22, v10                             // 000000446890: 34141496
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000446894: BF870194
	.long 0xd7000107                                           // 000000446898: D7000107
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000044689C: 02020F05
	v_add_nc_u32_e32 v11, v11, v1                              // 0000004468A0: 4A16030B
	.long 0xd73c0001                                           // 0000004468A4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000004468A8: 02020282
	v_add_co_ci_u32_e64 v8, null, v6, v8, s1                   // 0000004468AC: D5207C08 00061106
	.long 0xd700010c                                           // 0000004468B4: D700010C
	v_cndmask_b32_e32 v1, v5, v10, vcc_lo                      // 0000004468B8: 02021505
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004468BC: BF870244
	v_lshlrev_b32_e32 v17, 24, v11                             // 0000004468C0: 30221698
	v_add_co_ci_u32_e64 v13, null, v6, v9, s1                  // 0000004468C4: D5207C0D 00061306
	v_bfe_i32 v9, v11, 7, 1                                    // 0000004468CC: D6110009 02050F0B
	.long 0xd700014c                                           // 0000004468D4: D700014C
	v_cndmask_b32_e32 v1, v5, v1, vcc_lo                       // 0000004468D8: 02020305
	v_ashrrev_i32_e32 v10, 22, v17                             // 0000004468DC: 34142296
	v_add_co_ci_u32_e64 v77, null, v6, v2, s1                  // 0000004468E0: D5207C4D 00060506
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004468E8: BF870092
	.long 0xd7000105                                           // 0000004468EC: D7000105
	v_cndmask_b32_e32 v1, v5, v10, vcc_lo                      // 0000004468F0: 02021505
	v_add_co_ci_u32_e64 v6, null, v6, v9, s1                   // 0000004468F4: D5207C06 00061306
	s_clause 0x1f                                              // 0000004468FC: BF85001F
	global_load_b32 v2, v[7:8], off                            // 000000446900: DC520000 027C0007
	global_load_b32 v35, v[7:8], off offset:96                 // 000000446908: DC520060 237C0007
	global_load_b32 v31, v[7:8], off offset:192                // 000000446910: DC5200C0 1F7C0007
	global_load_b32 v27, v[7:8], off offset:288                // 000000446918: DC520120 1B7C0007
	global_load_b32 v23, v[7:8], off offset:384                // 000000446920: DC520180 177C0007
	global_load_b32 v19, v[7:8], off offset:480                // 000000446928: DC5201E0 137C0007
	global_load_b32 v11, v[7:8], off offset:576                // 000000446930: DC520240 0B7C0007
	global_load_b32 v9, v[7:8], off offset:672                 // 000000446938: DC5202A0 097C0007
	global_load_b32 v1, v[12:13], off                          // 000000446940: DC520000 017C000C
	global_load_b32 v34, v[12:13], off offset:96               // 000000446948: DC520060 227C000C
	global_load_b32 v30, v[12:13], off offset:192              // 000000446950: DC5200C0 1E7C000C
	global_load_b32 v26, v[12:13], off offset:288              // 000000446958: DC520120 1A7C000C
	global_load_b32 v22, v[12:13], off offset:384              // 000000446960: DC520180 167C000C
	global_load_b32 v18, v[12:13], off offset:480              // 000000446968: DC5201E0 127C000C
	global_load_b32 v10, v[12:13], off offset:576              // 000000446970: DC520240 0A7C000C
	global_load_b32 v8, v[12:13], off offset:672               // 000000446978: DC5202A0 087C000C
	global_load_b32 v39, v[76:77], off                         // 000000446980: DC520000 277C004C
	global_load_b32 v37, v[76:77], off offset:96               // 000000446988: DC520060 257C004C
	global_load_b32 v33, v[76:77], off offset:192              // 000000446990: DC5200C0 217C004C
	global_load_b32 v29, v[76:77], off offset:288              // 000000446998: DC520120 1D7C004C
	global_load_b32 v25, v[76:77], off offset:384              // 0000004469A0: DC520180 197C004C
	global_load_b32 v21, v[76:77], off offset:480              // 0000004469A8: DC5201E0 157C004C
	global_load_b32 v13, v[76:77], off offset:576              // 0000004469B0: DC520240 0D7C004C
	global_load_b32 v7, v[76:77], off offset:672               // 0000004469B8: DC5202A0 077C004C
	global_load_b32 v38, v[5:6], off                           // 0000004469C0: DC520000 267C0005
	global_load_b32 v36, v[5:6], off offset:96                 // 0000004469C8: DC520060 247C0005
	global_load_b32 v32, v[5:6], off offset:192                // 0000004469D0: DC5200C0 207C0005
	global_load_b32 v28, v[5:6], off offset:288                // 0000004469D8: DC520120 1C7C0005
	global_load_b32 v24, v[5:6], off offset:384                // 0000004469E0: DC520180 187C0005
	global_load_b32 v20, v[5:6], off offset:480                // 0000004469E8: DC5201E0 147C0005
	global_load_b32 v12, v[5:6], off offset:576                // 0000004469F0: DC520240 0C7C0005
	global_load_b32 v6, v[5:6], off offset:672                 // 0000004469F8: DC5202A0 067C0005
	s_or_b32 exec_lo, exec_lo, s3                              // 000000446A00: 8C7E037E
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v76, 0              // 000000446A04: CA100080 054C0080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v78, 0             // 000000446A0C: CA100080 4D4E0080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v80, 0             // 000000446A14: CA100080 4F500080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v82, 0             // 000000446A1C: CA100080 51520080
	s_ashr_i32 s3, s2, 31                                      // 000000446A24: 86039F02
	s_and_saveexec_b32 s1, s0                                  // 000000446A28: BE812000
	s_cbranch_execz 1101                                       // 000000446A2C: BFA5044D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e64>
	v_lshrrev_b32_e32 v5, 5, v15                               // 000000446A30: 320A1E85
	v_dual_mov_b32 v77, 23 :: v_dual_and_b32 v76, 0x7e0, v4    // 000000446A34: CA240097 4D4C08FF 000007E0
	v_mul_i32_i24_e32 v15, 0xffffffe8, v41                     // 000000446A40: 121E52FF FFFFFFE8
	.long 0xd703004f                                           // 000000446A48: D703004F
	v_cndmask_b32_e32 v0, v16, v129, vcc_lo                    // 000000446A4C: 02010310
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000446A50: BF870244
	v_subrev_nc_u32_e32 v4, 24, v5                             // 000000446A54: 4E080A98
	v_dual_mov_b32 v5, 0 :: v_dual_add_nc_u32 v84, 2, v3       // 000000446A58: CA200080 05540682
	v_and_b32_e32 v78, 16, v0                                  // 000000446A60: 369C0090
	v_add3_u32 v85, v15, v76, 0xfffffd34                       // 000000446A64: D6550055 03FE990F FFFFFD34
	v_cndmask_b32_e64 v4, v4, 23, vcc_lo                       // 000000446A70: D5010004 01A92F04
	.long 0x7e98394d                                           // 000000446A78: 7E98394D
	.long 0xd762404c                                           // 000000446A7C: D762404C
	v_cndmask_b32_e32 v1, 0xff, v79, vcc_lo                    // 000000446A80: 02029EFF 000000FF
	v_or_b32_e32 v14, 4, v14                                   // 000000446A88: 381C1C84
	v_ashrrev_i32_e32 v17, 31, v16                             // 000000446A8C: 3422209F
	.long 0xd703404f                                           // 000000446A90: D703404F
	v_cndmask_b32_e32 v0, v4, v129, vcc_lo                     // 000000446A94: 02010304
	v_sub_nc_u32_e32 v83, 0, v43                               // 000000446A98: 4CA65680
	v_cmp_gt_u16_e32 vcc_lo, 24, v204/*Invalid register, operand has 'VGPR_32_Lo128' register class*/// 000000446A9C: 7C799898
	v_mad_u32_u24 v80, v14, 3, 0x2f0                           // 000000446AA0: D60B0050 03FD070E 000002F0
	v_mul_i32_i24_e32 v82, -3, v14                             // 000000446AAC: 12A41CC3
	.long 0xd762104d                                           // 000000446AB0: D762104D
	v_cndmask_b32_e32 v1, 0xff, v79, vcc_lo                    // 000000446AB4: 02029EFF 000000FF
	.long 0xd73c000e                                           // 000000446ABC: D73C000E
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 000000446AC0: 02022082
	v_mov_b32_e32 v81, v5                                      // 000000446AC4: 7EA20305
	s_movk_i32 s5, 0x1eee                                      // 000000446AC8: B0051EEE
	v_and_b32_e32 v17, 0x7e0, v80                              // 000000446ACC: 3622A0FF 000007E0
	.long 0xd43d0000                                           // 000000446AD4: D43D0000
	v_cndmask_b32_e32 v1, 24, v77, vcc_lo                      // 000000446AD8: 02029A98
	v_mov_b32_e32 v77, v5                                      // 000000446ADC: 7E9A0305
	v_lshl_or_b32 v86, v3, 5, v78                              // 000000446AE0: D6560056 05390B03
	.long 0xd7040003                                           // 000000446AE8: D7040003
	v_cndmask_b32_e32 v1, v16, v76, vcc_lo                     // 000000446AEC: 02029910
	v_mov_b32_e32 v76, v5                                      // 000000446AF0: 7E980305
	v_cndmask_b16 v16, 0, v79, s0                              // 000000446AF4: D65D1010 00029E80
	v_mov_b32_e32 v80, v5                                      // 000000446AFC: 7EA00305
	v_add3_u32 v87, v82, v17, 0xfffffd34                       // 000000446B00: D6550057 03FE2352 FFFFFD34
	v_cndmask_b16 v3, v3, v79, vcc_lo                          // 000000446B0C: D65D0003 01AA9F03
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000446B14: BF8701B4
	v_dual_mov_b32 v78, v5 :: v_dual_and_b32 v89, 0xff, v16    // 000000446B18: CA240105 4E5820FF 000000FF
	.long 0xd73c0010                                           // 000000446B24: D73C0010
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 000000446B28: 02020882
	s_mov_b32 s0, 0                                            // 000000446B2C: BE800080
	v_and_b32_e32 v3, 0xff, v3                                 // 000000446B30: 360606FF 000000FF
	v_mov_b32_e32 v79, v5                                      // 000000446B38: 7E9E0305
	v_dual_mov_b32 v82, v5 :: v_dual_lshlrev_b32 v89, 2, v89   // 000000446B3C: CA220105 5258B282
	s_delay_alu instid0(VALU_DEP_3)                            // 000000446B44: BF870003
	v_lshlrev_b32_e32 v88, 2, v3                               // 000000446B48: 30B00682
	s_branch 936                                               // 000000446B4C: BFA003A8 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1cf0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000446B50: 8C7E087E
	s_waitcnt vmcnt(23)                                        // 000000446B54: BF895FF7
	.long 0xd73d007a                                           // 000000446B58: D73D007A
	v_cndmask_b32_e32 v1, v85, v1, vcc_lo                      // 000000446B5C: 02020355
	s_waitcnt vmcnt(7)                                         // 000000446B60: BF891FF7
	.long 0xd73d0026                                           // 000000446B64: D73D0026
	v_cndmask_b32_e32 v1, v87, v38, vcc_lo                     // 000000446B68: 02024D57
	ds_load_b128 v[1:4], v86                                   // 000000446B6C: DBFC0000 01000056
	.long 0xd73d0022                                           // 000000446B74: D73D0022
	v_cndmask_b32_e32 v1, v85, v34, vcc_lo                     // 000000446B78: 02024555
	s_waitcnt vmcnt(6)                                         // 000000446B7C: BF891BF7
	.long 0xd73d0023                                           // 000000446B80: D73D0023
	v_cndmask_b32_e32 v1, v87, v36, vcc_lo                     // 000000446B84: 02024957
	.long 0xd73d001e                                           // 000000446B88: D73D001E
	v_cndmask_b32_e32 v1, v85, v30, vcc_lo                     // 000000446B8C: 02023D55
	v_bfe_u32 v39, v122, 9, 16                                 // 000000446B90: D6100027 0241137A
	v_bfe_u32 v123, v122, 6, 16                                // 000000446B98: D610007B 02410D7A
	v_bfe_u32 v124, v122, 3, 16                                // 000000446BA0: D610007C 0241077A
	v_and_b32_e32 v122, 0xffff, v122                           // 000000446BA8: 36F4F4FF 0000FFFF
	v_bfe_u32 v125, v38, 9, 16                                 // 000000446BB0: D610007D 02411326
	.long 0xd72c0027                                           // 000000446BB8: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000446BBC: 02024EFF 83DCD12D
	v_bfe_u32 v126, v38, 6, 16                                 // 000000446BC4: D610007E 02410D26
	.long 0xd72c007c                                           // 000000446BCC: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 000000446BD0: 0202F8FF 83DCD12D
	.long 0xd72c007a                                           // 000000446BD8: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 000000446BDC: 0202F4FF 83DCD12D
	.long 0xd72c007b                                           // 000000446BE4: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000446BE8: 0202F6FF 83DCD12D
	.long 0xd72c007d                                           // 000000446BF0: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000446BF4: 0202FAFF 83DCD12D
	.long 0xd72c007e                                           // 000000446BFC: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000446C00: 0202FCFF 83DCD12D
	v_bfe_u32 v37, v34, 9, 16                                  // 000000446C08: D6100025 02411322
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000446C10: D6220027 03FD0127 00006400
	s_waitcnt vmcnt(5)                                         // 000000446C1C: BF8917F7
	.long 0xd73d001f                                           // 000000446C20: D73D001F
	v_cndmask_b32_e32 v1, v87, v32, vcc_lo                     // 000000446C24: 02024157
	v_sad_u8 v124, v124, 0, 0x6400                             // 000000446C28: D622007C 03FD017C 00006400
	v_sad_u8 v122, v122, 0, 0x6400                             // 000000446C34: D622007A 03FD017A 00006400
	v_sad_u8 v123, v123, 0, 0x6400                             // 000000446C40: D622007B 03FD017B 00006400
	v_sad_u8 v125, v125, 0, 0x6400                             // 000000446C4C: D622007D 03FD017D 00006400
	v_sad_u8 v126, v126, 0, 0x6400                             // 000000446C58: D622007E 03FD017E 00006400
	.long 0xd72c0025                                           // 000000446C64: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000446C68: 02024AFF 83DCD12D
	v_lshlrev_b32_e32 v122, 16, v122                           // 000000446C70: 30F4F490
	.long 0xd73d001a                                           // 000000446C74: D73D001A
	v_cndmask_b32_e32 v1, v85, v26, vcc_lo                     // 000000446C78: 02023555
	v_bfe_u32 v127, v38, 3, 16                                 // 000000446C7C: D610007F 02410726
	.long 0xd73d0016                                           // 000000446C84: D73D0016
	v_cndmask_b32_e32 v1, v85, v22, vcc_lo                     // 000000446C88: 02022D55
	.long 0xd73d0012                                           // 000000446C8C: D73D0012
	v_cndmask_b32_e32 v1, v85, v18, vcc_lo                     // 000000446C90: 02022555
	v_and_or_b32 v122, 0xffff, v124, v122                      // 000000446C94: D657007A 05EAF8FF 0000FFFF
	v_bfe_u32 v124, v35, 9, 16                                 // 000000446CA0: D610007C 02411323
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000446CA8: D6220025 03FD0125 00006400
	.long 0xd73d000a                                           // 000000446CB4: D73D000A
	v_cndmask_b32_e32 v1, v85, v10, vcc_lo                     // 000000446CB8: 02021555
	s_waitcnt vmcnt(1)                                         // 000000446CBC: BF8907F7
	.long 0xd73d000b                                           // 000000446CC0: D73D000B
	v_cndmask_b32_e32 v1, v87, v12, vcc_lo                     // 000000446CC4: 02021957
	v_pk_fma_f16 v36, v122, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000446CC8: CC0E0024 0BFC0B7A 0000C931
	v_and_b32_e32 v39, 0xffff, v39                             // 000000446CD4: 364E4EFF 0000FFFF
	.long 0xd72c007c                                           // 000000446CDC: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 000000446CE0: 0202F8FF 83DCD12D
	.long 0xd73d0008                                           // 000000446CE8: D73D0008
	v_cndmask_b32_e32 v1, v85, v8, vcc_lo                      // 000000446CEC: 02021155
	v_bfe_u32 v13, v10, 9, 16                                  // 000000446CF0: D610000D 0241130A
	s_waitcnt vmcnt(0)                                         // 000000446CF8: BF8903F7
	.long 0xd73d0006                                           // 000000446CFC: D73D0006
	v_cndmask_b32_e32 v1, v87, v6, vcc_lo                      // 000000446D00: 02020D57
	v_lshl_or_b32 v39, v123, 16, v39                           // 000000446D04: D6560027 049D217B
	v_and_b32_e32 v123, 0xffff, v125                           // 000000446D0C: 36F6FAFF 0000FFFF
	v_bfe_u32 v125, v34, 6, 16                                 // 000000446D14: D610007D 02410D22
	.long 0xd72c000d                                           // 000000446D1C: D72C000D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v13, vcc_lo              // 000000446D20: 02021AFF 83DCD12D
	v_sad_u8 v124, v124, 0, 0x6400                             // 000000446D28: D622007C 03FD017C 00006400
	v_pk_fma_f16 v39, v39, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000446D34: CC0E0027 0BFC0B27 0000C931
	v_lshl_or_b32 v123, v126, 16, v123                         // 000000446D40: D656007B 05ED217E
	.long 0xd72c007d                                           // 000000446D48: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000446D4C: 0202FAFF 83DCD12D
	v_bfe_u32 v126, v35, 6, 16                                 // 000000446D54: D610007E 02410D23
	.long 0xd72c007f                                           // 000000446D5C: D72C007F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 000000446D60: 0202FEFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000446D68: BF89FC07
	v_dot2acc_f32_f16 v82, v39, v1                             // 000000446D6C: 04A40327
	v_pk_fma_f16 v122, v123, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000446D70: CC0E007A 0BFC0B7B 0000C931
	v_and_b32_e32 v123, 0xffff, v34                            // 000000446D7C: 36F644FF 0000FFFF
	.long 0xd72c0027                                           // 000000446D84: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000446D88: 0202FCFF 83DCD12D
	v_bfe_u32 v126, v35, 3, 16                                 // 000000446D90: D610007E 02410723
	v_sad_u8 v125, v125, 0, 0x6400                             // 000000446D98: D622007D 03FD017D 00006400
	v_dual_dot2acc_f32_f16 v82, v36, v2 :: v_dual_and_b32 v37, 0xffff, v37// 000000446DA4: CB240524 52244AFF 0000FFFF
	.long 0xd72c007b                                           // 000000446DB0: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000446DB4: 0202F6FF 83DCD12D
	v_bfe_u32 v34, v34, 3, 16                                  // 000000446DBC: D6100022 02410722
	v_sad_u8 v13, v13, 0, 0x6400                               // 000000446DC4: D622000D 03FD010D 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000446DD0: BF870004
	v_dot2acc_f32_f16 v82, v122, v3                            // 000000446DD4: 04A4077A
	v_lshl_or_b32 v37, v125, 16, v37                           // 000000446DD8: D6560025 0495217D
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000446DE0: D6220027 03FD0127 00006400
	v_and_b32_e32 v35, 0xffff, v35                             // 000000446DEC: 364646FF 0000FFFF
	v_bfe_u32 v125, v31, 6, 16                                 // 000000446DF4: D610007D 02410D1F
	v_sad_u8 v123, v123, 0, 0x6400                             // 000000446DFC: D622007B 03FD017B 00006400
	v_pk_fma_f16 v36, v37, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000446E08: CC0E0024 0BFC0B25 0000C931
	.long 0xd72c0022                                           // 000000446E14: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000446E18: 020244FF 83DCD12D
	.long 0xd72c0023                                           // 000000446E20: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000446E24: 020246FF 83DCD12D
	.long 0xd72c007d                                           // 000000446E2C: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000446E30: 0202FAFF 83DCD12D
	v_and_b32_e32 v13, 0xffff, v13                             // 000000446E38: 361A1AFF 0000FFFF
	v_dual_dot2acc_f32_f16 v81, v36, v1 :: v_dual_and_b32 v124, 0xffff, v124// 000000446E40: CB240324 517CF8FF 0000FFFF
	v_sad_u8 v127, v127, 0, 0x6400                             // 000000446E4C: D622007F 03FD017F 00006400
	v_add_nc_u32_e32 v84, 1, v84                               // 000000446E58: 4AA8A881
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000446E5C: D6220022 03FD0122 00006400
	v_sad_u8 v32, v35, 0, 0x6400                               // 000000446E68: D6220020 03FD0123 00006400
	v_lshl_or_b32 v39, v39, 16, v124                           // 000000446E74: D6560027 05F12127
	v_and_b32_e32 v124, 0xffff, v30                            // 000000446E7C: 36F83CFF 0000FFFF
	v_bfe_u32 v35, v30, 6, 16                                  // 000000446E84: D6100023 02410D1E
	v_add_nc_u32_e32 v86, 32, v86                              // 000000446E8C: 4AACACA0
	v_lshlrev_b32_e32 v32, 16, v32                             // 000000446E90: 30404090
	v_pk_fma_f16 v37, v39, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000446E94: CC0E0025 0BFC0B27 0000C931
	v_bfe_u32 v39, v30, 9, 16                                  // 000000446EA0: D6100027 0241131E
	v_bfe_u32 v30, v30, 3, 16                                  // 000000446EA8: D610001E 0241071E
	.long 0xd72c0023                                           // 000000446EB0: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000446EB4: 020246FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000446EBC: BF870223
	.long 0xd72c0021                                           // 000000446EC0: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000446EC4: 02024EFF 83DCD12D
	.long 0xd72c0027                                           // 000000446ECC: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 000000446ED0: 0202F8FF 83DCD12D
	.long 0xd72c001e                                           // 000000446ED8: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 000000446EDC: 02023CFF 83DCD12D
	v_bfe_u32 v124, v31, 9, 16                                 // 000000446EE4: D610007C 0241131F
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000446EEC: D6220023 03FD0123 00006400
	v_sad_u8 v33, v33, 0, 0x6400                               // 000000446EF8: D6220021 03FD0121 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000446F04: D6220027 03FD0127 00006400
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000446F10: D622001E 03FD011E 00006400
	.long 0xd72c007c                                           // 000000446F1C: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 000000446F20: 0202F8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000446F28: BF870214
	v_and_b32_e32 v33, 0xffff, v33                             // 000000446F2C: 364242FF 0000FFFF
	v_lshlrev_b32_e32 v39, 16, v39                             // 000000446F34: 304E4E90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000446F38: BF870112
	v_lshl_or_b32 v33, v35, 16, v33                            // 000000446F3C: D6560021 04852123
	v_and_or_b32 v30, 0xffff, v30, v39                         // 000000446F44: D657001E 049E3CFF 0000FFFF
	v_sad_u8 v124, v124, 0, 0x6400                             // 000000446F50: D622007C 03FD017C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000446F5C: BF870223
	v_pk_fma_f16 v33, v33, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000446F60: CC0E0021 0BFC0B21 0000C931
	v_lshlrev_b32_e32 v123, 16, v123                           // 000000446F6C: 30F6F690
	v_pk_fma_f16 v30, v30, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000446F70: CC0E001E 0BFC0B1E 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000446F7C: BF870193
	v_dot2acc_f32_f16 v80, v33, v1                             // 000000446F80: 04A00321
	v_and_or_b32 v34, 0xffff, v34, v123                        // 000000446F84: D6570022 05EE44FF 0000FFFF
	.long 0xd72c007b                                           // 000000446F90: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000446F94: 0202FCFF 83DCD12D
	v_bfe_u32 v126, v31, 3, 16                                 // 000000446F9C: D610007E 0241071F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000446FA4: BF8701A4
	v_dual_dot2acc_f32_f16 v80, v30, v2 :: v_dual_and_b32 v39, 0xffff, v124// 000000446FA8: CB24051E 5026F8FF 0000FFFF
	v_sad_u8 v124, v125, 0, 0x6400                             // 000000446FB4: D622007C 03FD017D 00006400
	.long 0xd72c0023                                           // 000000446FC0: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000446FC4: 0202FCFF 83DCD12D
	v_pk_fma_f16 v34, v34, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000446FCC: CC0E0022 0BFC0B22 0000C931
	v_sad_u8 v123, v123, 0, 0x6400                             // 000000446FD8: D622007B 03FD017B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000446FE4: BF870224
	v_lshl_or_b32 v36, v124, 16, v39                           // 000000446FE8: D6560024 049D217C
	v_mov_b32_e32 v39, v72                                     // 000000446FF0: 7E4E0348
	v_dot2acc_f32_f16 v81, v34, v2                             // 000000446FF4: 04A20522
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000446FF8: BF870234
	v_and_or_b32 v32, 0xffff, v123, v32                        // 000000446FFC: D6570020 0482F6FF 0000FFFF
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000447008: D6220023 03FD0123 00006400
	v_pk_fma_f16 v33, v36, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000447014: CC0E0021 0BFC0B24 0000C931
	v_dual_dot2acc_f32_f16 v81, v37, v3 :: v_dual_and_b32 v38, 0xffff, v38// 000000447020: CB240725 51264CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000044702C: BF870224
	v_pk_fma_f16 v27, v32, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000447030: CC0E001B 0BFC0B20 0000C931
	v_mov_b32_e32 v34, v64                                     // 00000044703C: 7E440340
	v_dot2acc_f32_f16 v80, v33, v3                             // 000000447040: 04A00721
	v_and_b32_e32 v31, 0xffff, v31                             // 000000447044: 363E3EFF 0000FFFF
	.long 0xd72c0026                                           // 00000044704C: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000447050: 02024CFF 83DCD12D
	v_dot2acc_f32_f16 v81, v27, v4                             // 000000447058: 04A2091B
	.long 0xd73d001b                                           // 00000044705C: D73D001B
	v_cndmask_b32_e32 v1, v87, v28, vcc_lo                     // 000000447060: 02023957
	v_bfe_u32 v29, v26, 6, 16                                  // 000000447064: D610001D 02410D1A
	.long 0xd72c001f                                           // 00000044706C: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000447070: 02023EFF 83DCD12D
	v_mov_b32_e32 v64, v110                                    // 000000447078: 7E80036E
	v_mov_b32_e32 v72, v118                                    // 00000044707C: 7E900376
	v_mov_b32_e32 v36, v74                                     // 000000447080: 7E48034A
	.long 0xd72c001d                                           // 000000447084: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 000000447088: 02023AFF 83DCD12D
	v_bfe_u32 v32, v27, 6, 16                                  // 000000447090: D6100020 02410D1B
	v_bfe_u32 v33, v27, 3, 16                                  // 000000447098: D6100021 0241071B
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000004470A0: D6220026 03FD0126 00006400
	v_sad_u8 v31, v31, 0, 0x6400                               // 0000004470AC: D622001F 03FD011F 00006400
	v_mov_b32_e32 v74, v120                                    // 0000004470B8: 7E940378
	.long 0xd72c0020                                           // 0000004470BC: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 0000004470C0: 020240FF 83DCD12D
	v_mov_b32_e32 v37, v70                                     // 0000004470C8: 7E4A0346
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000004470CC: D622001D 03FD011D 00006400
	v_dual_mov_b32 v70, v116 :: v_dual_lshlrev_b32 v31, 16, v31// 0000004470D8: CA220174 461E3E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004470E0: BF8701B1
	v_and_or_b32 v31, 0xffff, v35, v31                         // 0000004470E4: D657001F 047E46FF 0000FFFF
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000004470F0: D6220020 03FD0120 00006400
	v_dual_mov_b32 v35, v50 :: v_dual_mov_b32 v50, v96         // 0000004470FC: CA100132 23320160
	v_pk_fma_f16 v30, v31, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000447104: CC0E001E 0BFC0B1F 0000C931
	v_bfe_u32 v31, v26, 9, 16                                  // 000000447110: D610001F 0241131A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000447118: BF870112
	v_dot2acc_f32_f16 v80, v30, v4                             // 00000044711C: 04A0091E
	.long 0xd72c001c                                           // 000000447120: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000447124: 02023EFF 83DCD12D
	v_bfe_u32 v31, v27, 9, 16                                  // 00000044712C: D610001F 0241131B
	v_and_b32_e32 v27, 0xffff, v27                             // 000000447134: 363636FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044713C: BF870112
	.long 0xd72c001f                                           // 000000447140: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000447144: 02023EFF 83DCD12D
	.long 0xd72c001b                                           // 00000044714C: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 000000447150: 020236FF 83DCD12D
	v_sad_u8 v28, v28, 0, 0x6400                               // 000000447158: D622001C 03FD011C 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000447164: BF870211
	v_and_b32_e32 v28, 0xffff, v28                             // 000000447168: 363838FF 0000FFFF
	v_sad_u8 v31, v31, 0, 0x6400                               // 000000447170: D622001F 03FD011F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000044717C: BF870194
	v_sad_u8 v27, v27, 0, 0x6400                               // 000000447180: D622001B 03FD011B 00006400
	v_lshl_or_b32 v28, v29, 16, v28                            // 00000044718C: D656001C 0471211D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000447194: BF870223
	v_and_b32_e32 v29, 0xffff, v31                             // 000000447198: 363A3EFF 0000FFFF
	.long 0xd72c001f                                           // 0000004471A0: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 0000004471A4: 020242FF 83DCD12D
	v_lshlrev_b32_e32 v27, 16, v27                             // 0000004471AC: 30363690
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004471B0: BF870214
	v_pk_fma_f16 v28, v28, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004471B4: CC0E001C 0BFC0B1C 0000C931
	v_lshl_or_b32 v23, v32, 16, v29                            // 0000004471C0: D6560017 04752120
	v_and_b32_e32 v32, 0xffff, v22                             // 0000004471C8: 36402CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004471D0: BF870223
	v_dual_dot2acc_f32_f16 v79, v28, v1 :: v_dual_lshlrev_b32 v38, 16, v38// 0000004471D4: CB22031C 4F264C90
	v_sad_u8 v29, v31, 0, 0x6400                               // 0000004471DC: D622001D 03FD011F 00006400
	v_pk_fma_f16 v31, v23, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004471E8: CC0E001F 0BFC0B17 0000C931
	.long 0xd73d0017                                           // 0000004471F4: D73D0017
	v_cndmask_b32_e32 v1, v87, v24, vcc_lo                     // 0000004471F8: 02023157
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004471FC: BF870214
	v_and_or_b32 v38, 0xffff, v127, v38                        // 000000447200: D6570026 049AFEFF 0000FFFF
	v_and_or_b32 v24, 0xffff, v29, v27                         // 00000044720C: D6570018 046E3AFF 0000FFFF
	v_bfe_u32 v27, v22, 6, 16                                  // 000000447218: D610001B 02410D16
	.long 0xd72c001d                                           // 000000447220: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 000000447224: 020240FF 83DCD12D
	v_bfe_u32 v32, v23, 6, 16                                  // 00000044722C: D6100020 02410D17
	v_bfe_u32 v33, v23, 3, 16                                  // 000000447234: D6100021 02410717
	v_pk_fma_f16 v19, v24, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000044723C: CC0E0013 0BFC0B18 0000C931
	v_and_b32_e32 v30, 0xffff, v26                             // 000000447248: 363C34FF 0000FFFF
	v_bfe_u32 v26, v26, 3, 16                                  // 000000447250: D610001A 0241071A
	.long 0xd72c0020                                           // 000000447258: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 00000044725C: 020240FF 83DCD12D
	.long 0xd72c001b                                           // 000000447264: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 000000447268: 020236FF 83DCD12D
	v_sad_u8 v29, v29, 0, 0x6400                               // 000000447270: D622001D 03FD011D 00006400
	.long 0xd72c001e                                           // 00000044727C: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 000000447280: 02023CFF 83DCD12D
	.long 0xd72c001a                                           // 000000447288: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 00000044728C: 020234FF 83DCD12D
	v_pk_fma_f16 v38, v38, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000447294: CC0E0026 0BFC0B26 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004472A0: BF8701A4
	v_lshlrev_b32_e32 v29, 16, v29                             // 0000004472A4: 303A3A90
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000004472A8: D622001B 03FD011B 00006400
	v_dot2acc_f32_f16 v82, v38, v4                             // 0000004472B4: 04A40926
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000004472B8: D622001E 03FD011E 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000004472C4: D622001A 03FD011A 00006400
	v_dual_mov_b32 v38, v75 :: v_dual_mov_b32 v75, v121        // 0000004472D0: CA10014B 264A0179
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004472D8: BF870093
	v_lshlrev_b32_e32 v30, 16, v30                             // 0000004472DC: 303C3C90
	v_and_or_b32 v26, 0xffff, v26, v30                         // 0000004472E0: D657001A 047A34FF 0000FFFF
	v_bfe_u32 v30, v22, 9, 16                                  // 0000004472EC: D610001E 02411316
	v_bfe_u32 v22, v22, 3, 16                                  // 0000004472F4: D6100016 02410716
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004472FC: BF870193
	v_pk_fma_f16 v26, v26, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000447300: CC0E001A 0BFC0B1A 0000C931
	.long 0xd72c0019                                           // 00000044730C: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 000000447310: 02023CFF 83DCD12D
	v_bfe_u32 v30, v23, 9, 16                                  // 000000447318: D610001E 02411317
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000447320: BF870234
	.long 0xd72c0016                                           // 000000447324: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 000000447328: 02022CFF 83DCD12D
	v_and_b32_e32 v23, 0xffff, v23                             // 000000447330: 362E2EFF 0000FFFF
	v_dot2acc_f32_f16 v79, v26, v2                             // 000000447338: 049E051A
	.long 0xd72c001e                                           // 00000044733C: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 000000447340: 02023CFF 83DCD12D
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000447348: D6220019 03FD0119 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000447354: BF870253
	v_dot2acc_f32_f16 v79, v31, v3                             // 000000447358: 049E071F
	v_sad_u8 v22, v22, 0, 0x6400                               // 00000044735C: D6220016 03FD0116 00006400
	v_mov_b32_e32 v31, v49                                     // 000000447368: 7E3E0331
	v_mov_b32_e32 v49, v95                                     // 00000044736C: 7E62035F
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000447370: D622001E 03FD011E 00006400
	v_and_or_b32 v22, 0xffff, v22, v29                         // 00000044737C: D6570016 04762CFF 0000FFFF
	v_sad_u8 v29, v32, 0, 0x6400                               // 000000447388: D622001D 03FD0120 00006400
	v_dot2acc_f32_f16 v79, v19, v4                             // 000000447394: 049E0913
	.long 0xd73d0013                                           // 000000447398: D73D0013
	v_cndmask_b32_e32 v1, v87, v20, vcc_lo                     // 00000044739C: 02022957
	v_and_b32_e32 v28, 0xffff, v30                             // 0000004473A0: 36383CFF 0000FFFF
	v_pk_fma_f16 v22, v22, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004473A8: CC0E0016 0BFC0B16 0000C931
	v_bfe_u32 v21, v18, 6, 16                                  // 0000004473B4: D6100015 02410D12
	v_mov_b32_e32 v32, v73                                     // 0000004473BC: 7E400349
	v_mov_b32_e32 v30, v61                                     // 0000004473C0: 7E3C033D
	v_lshl_or_b32 v26, v29, 16, v28                            // 0000004473C4: D656001A 0471211D
	v_mov_b32_e32 v29, v65                                     // 0000004473CC: 7E3A0341
	.long 0xd72c0015                                           // 0000004473D0: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 0000004473D4: 02022AFF 83DCD12D
	v_mov_b32_e32 v28, v71                                     // 0000004473DC: 7E380347
	v_mov_b32_e32 v65, v111                                    // 0000004473E0: 7E82036F
	v_pk_fma_f16 v24, v26, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004473E4: CC0E0018 0BFC0B1A 0000C931
	v_and_b32_e32 v25, 0xffff, v25                             // 0000004473F0: 363232FF 0000FFFF
	v_mov_b32_e32 v61, v107                                    // 0000004473F8: 7E7A036B
	v_mov_b32_e32 v71, v117                                    // 0000004473FC: 7E8E0375
	v_mov_b32_e32 v73, v119                                    // 000000447400: 7E920377
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000447404: D6220015 03FD0115 00006400
	v_lshl_or_b32 v25, v27, 16, v25                            // 000000447410: D6560019 0465211B
	.long 0xd72c001b                                           // 000000447418: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 00000044741C: 020242FF 83DCD12D
	v_dual_mov_b32 v33, v68 :: v_dual_mov_b32 v68, v114        // 000000447424: CA100144 21440172
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000044742C: BF870193
	v_pk_fma_f16 v25, v25, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000447430: CC0E0019 0BFC0B19 0000C931
	v_sad_u8 v27, v27, 0, 0x6400                               // 00000044743C: D622001B 03FD011B 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000447448: BF870122
	v_dot2acc_f32_f16 v78, v25, v1                             // 00000044744C: 049C0319
	v_bfe_u32 v25, v19, 6, 16                                  // 000000447450: D6100019 02410D13
	v_dot2acc_f32_f16 v78, v22, v2                             // 000000447458: 049C0516
	v_bfe_u32 v22, v18, 9, 16                                  // 00000044745C: D6100016 02411312
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000447464: BF870193
	.long 0xd72c0019                                           // 000000447468: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 00000044746C: 020232FF 83DCD12D
	v_dot2acc_f32_f16 v78, v24, v3                             // 000000447474: 049C0718
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000447478: BF870223
	.long 0xd72c0014                                           // 00000044747C: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 000000447480: 02022CFF 83DCD12D
	v_bfe_u32 v24, v19, 9, 16                                  // 000000447488: D6100018 02411313
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000447490: D6220019 03FD0119 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000044749C: BF870212
	.long 0xd72c0018                                           // 0000004474A0: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 0000004474A4: 020230FF 83DCD12D
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000004474AC: D6220014 03FD0114 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004474B8: BF870191
	v_and_b32_e32 v20, 0xffff, v20                             // 0000004474BC: 362828FF 0000FFFF
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000004474C4: D6220018 03FD0118 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004474D0: BF870112
	v_lshl_or_b32 v20, v21, 16, v20                            // 0000004474D4: D6560014 04512115
	v_and_b32_e32 v24, 0xffff, v24                             // 0000004474DC: 363030FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004474E4: BF870092
	v_pk_fma_f16 v20, v20, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004474E8: CC0E0014 0BFC0B14 0000C931
	v_dual_dot2acc_f32_f16 v77, v20, v1 :: v_dual_and_b32 v26, 0xffff, v19// 0000004474F4: CB240314 4D1A26FF 0000FFFF
	v_bfe_u32 v19, v19, 3, 16                                  // 000000447500: D6100013 02410713
	v_and_b32_e32 v20, 0xffff, v10                             // 000000447508: 362814FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000447510: BF870193
	.long 0xd72c001a                                           // 000000447514: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 000000447518: 020234FF 83DCD12D
	.long 0xd72c0013                                           // 000000447520: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 000000447524: 020226FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044752C: BF870112
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000447530: D622001A 03FD011A 00006400
	v_sad_u8 v19, v19, 0, 0x6400                               // 00000044753C: D6220013 03FD0113 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000447548: BF870122
	v_dual_mov_b32 v26, v58 :: v_dual_lshlrev_b32 v21, 16, v26 // 00000044754C: CA22013A 1A143490
	v_mov_b32_e32 v58, v104                                    // 000000447554: 7E740368
	v_and_or_b32 v19, 0xffff, v19, v21                         // 000000447558: D6570013 045626FF 0000FFFF
	v_bfe_u32 v21, v11, 9, 16                                  // 000000447564: D6100015 0241130B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000044756C: BF870232
	v_pk_fma_f16 v19, v19, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000447570: CC0E0013 0BFC0B13 0000C931
	v_and_b32_e32 v22, 0xffff, v18                             // 00000044757C: 362C24FF 0000FFFF
	v_bfe_u32 v18, v18, 3, 16                                  // 000000447584: D6100012 02410712
	.long 0xd72c0015                                           // 00000044758C: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 000000447590: 02022AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000447598: BF870193
	.long 0xd72c0016                                           // 00000044759C: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 0000004475A0: 02022CFF 83DCD12D
	.long 0xd72c0012                                           // 0000004475A8: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 0000004475AC: 020224FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004475B4: BF870193
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000004475B8: D6220015 03FD0115 00006400
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000004475C4: D6220016 03FD0116 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004475D0: BF870193
	v_sad_u8 v18, v18, 0, 0x6400                               // 0000004475D4: D6220012 03FD0112 00006400
	v_and_b32_e32 v21, 0xffff, v21                             // 0000004475E0: 362A2AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004475E8: BF870093
	v_lshlrev_b32_e32 v22, 16, v22                             // 0000004475EC: 302C2C90
	v_and_or_b32 v18, 0xffff, v18, v22                         // 0000004475F0: D6570012 045A24FF 0000FFFF
	v_lshl_or_b32 v22, v25, 16, v24                            // 0000004475FC: D6560016 04612119
	v_bfe_u32 v24, v11, 6, 16                                  // 000000447604: D6100018 02410D0B
	v_dual_mov_b32 v25, v62 :: v_dual_mov_b32 v62, v108        // 00000044760C: CA10013E 193E016C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000447614: BF870214
	v_pk_fma_f16 v18, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000447618: CC0E0012 0BFC0B12 0000C931
	v_pk_fma_f16 v12, v22, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000447624: CC0E000C 0BFC0B16 0000C931
	v_bfe_u32 v22, v10, 6, 16                                  // 000000447630: D6100016 02410D0A
	v_bfe_u32 v10, v10, 3, 16                                  // 000000447638: D610000A 0241070A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000447640: BF870224
	v_dot2acc_f32_f16 v77, v18, v2                             // 000000447644: 049A0512
	.long 0xd72c0012                                           // 000000447648: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 00000044764C: 020230FF 83DCD12D
	.long 0xd72c0016                                           // 000000447654: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 000000447658: 02022CFF 83DCD12D
	v_bfe_u32 v24, v11, 3, 16                                  // 000000447660: D6100018 0241070B
	v_and_b32_e32 v11, 0xffff, v11                             // 000000447668: 361616FF 0000FFFF
	.long 0xd72c000a                                           // 000000447670: D72C000A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v10, vcc_lo              // 000000447674: 020214FF 83DCD12D
	v_dot2acc_f32_f16 v77, v12, v3                             // 00000044767C: 049A070C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000447680: BF870233
	.long 0xd72c0009                                           // 000000447684: D72C0009
	v_cndmask_b32_e32 v1, 0x83dcd12d, v11, vcc_lo              // 000000447688: 020216FF 83DCD12D
	v_sad_u8 v22, v22, 0, 0x6400                               // 000000447690: D6220016 03FD0116 00006400
	v_sad_u8 v18, v18, 0, 0x6400                               // 00000044769C: D6220012 03FD0112 00006400
	v_dot2acc_f32_f16 v77, v19, v4                             // 0000004476A8: 049A0913
	v_sad_u8 v10, v10, 0, 0x6400                               // 0000004476AC: D622000A 03FD010A 00006400
	v_mov_b32_e32 v19, v46                                     // 0000004476B8: 7E26032E
	v_lshl_or_b32 v13, v22, 16, v13                            // 0000004476BC: D656000D 04352116
	v_lshl_or_b32 v18, v18, 16, v21                            // 0000004476C4: D6560012 04552112
	v_sad_u8 v7, v9, 0, 0x6400                                 // 0000004476CC: D6220007 03FD0109 00006400
	v_bfe_u32 v21, v6, 9, 16                                   // 0000004476D8: D6100015 02411306
	v_bfe_u32 v22, v6, 6, 16                                   // 0000004476E0: D6100016 02410D06
	v_pk_fma_f16 v11, v13, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004476E8: CC0E000B 0BFC0B0D 0000C931
	v_bfe_u32 v13, v8, 9, 16                                   // 0000004476F4: D610000D 02411308
	v_pk_fma_f16 v12, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004476FC: CC0E000C 0BFC0B12 0000C931
	.long 0xd72c0015                                           // 000000447708: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 00000044770C: 02022AFF 83DCD12D
	.long 0xd72c0016                                           // 000000447714: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 000000447718: 02022CFF 83DCD12D
	v_dot2acc_f32_f16 v76, v11, v1                             // 000000447720: 0498030B
	.long 0xd72c0009                                           // 000000447724: D72C0009
	v_cndmask_b32_e32 v1, 0x83dcd12d, v13, vcc_lo              // 000000447728: 02021AFF 83DCD12D
	v_bfe_u32 v13, v8, 6, 16                                   // 000000447730: D610000D 02410D08
	v_dual_mov_b32 v46, v92 :: v_dual_lshlrev_b32 v7, 16, v7   // 000000447738: CA22015C 2E060E90
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000447740: D6220015 03FD0115 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000044774C: BF8700A3
	.long 0xd72c000d                                           // 000000447750: D72C000D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v13, vcc_lo              // 000000447754: 02021AFF 83DCD12D
	v_sad_u8 v9, v9, 0, 0x6400                                 // 00000044775C: D6220009 03FD0109 00006400
	v_and_b32_e32 v9, 0xffff, v9                               // 000000447768: 361212FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000447770: BF870093
	v_sad_u8 v13, v13, 0, 0x6400                               // 000000447774: D622000D 03FD010D 00006400
	v_lshl_or_b32 v9, v13, 16, v9                              // 000000447780: D6560009 0425210D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000447788: BF870091
	v_pk_fma_f16 v9, v9, s5, 0xc931 op_sel_hi:[1,0,0]          // 00000044778C: CC0E0009 0BFC0B09 0000C931
	v_dot2acc_f32_f16 v5, v9, v1                               // 000000447798: 040A0309
	v_mov_b32_e32 v9, v44                                      // 00000044779C: 7E12032C
	.long 0xd72c0014                                           // 0000004477A0: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v20, vcc_lo              // 0000004477A4: 020228FF 83DCD12D
	v_mov_b32_e32 v44, v90                                     // 0000004477AC: 7E58035A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004477B0: BF870092
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000004477B4: D6220014 03FD0114 00006400
	v_lshlrev_b32_e32 v20, 16, v20                             // 0000004477C0: 30282890
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004477C4: BF870241
	v_and_or_b32 v10, 0xffff, v10, v20                         // 0000004477C8: D657000A 045214FF 0000FFFF
	.long 0xd72c0014                                           // 0000004477D4: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 0000004477D8: 020230FF 83DCD12D
	v_bfe_u32 v24, v6, 3, 16                                   // 0000004477E0: D6100018 02410706
	v_and_b32_e32 v6, 0xffff, v6                               // 0000004477E8: 360C0CFF 0000FFFF
	v_pk_fma_f16 v10, v10, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004477F0: CC0E000A 0BFC0B0A 0000C931
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004477FC: BF870003
	.long 0xd72c000d                                           // 000000447800: D72C000D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 000000447804: 020230FF 83DCD12D
	v_mov_b32_e32 v24, v69                                     // 00000044780C: 7E300345
	v_sad_u8 v18, v20, 0, 0x6400                               // 000000447810: D6220012 03FD0114 00006400
	v_and_b32_e32 v20, 0xffff, v8                              // 00000044781C: 362810FF 0000FFFF
	v_bfe_u32 v8, v8, 3, 16                                    // 000000447824: D6100008 02410708
	v_dot2acc_f32_f16 v76, v10, v2                             // 00000044782C: 0498050A
	v_dual_mov_b32 v10, v53 :: v_dual_mov_b32 v53, v99         // 000000447830: CA100135 0A340163
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000447838: BF870214
	.long 0xd72c0014                                           // 00000044783C: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v20, vcc_lo              // 000000447840: 020228FF 83DCD12D
	.long 0xd72c0008                                           // 000000447848: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v8, vcc_lo               // 00000044784C: 020210FF 83DCD12D
	v_sad_u8 v13, v13, 0, 0x6400                               // 000000447854: D622000D 03FD010D 00006400
	v_dot2acc_f32_f16 v76, v12, v3                             // 000000447860: 0498070C
	v_dual_mov_b32 v12, v63 :: v_dual_mov_b32 v63, v109        // 000000447864: CA10013F 0C3E016D
	v_mov_b32_e32 v69, v115                                    // 00000044786C: 7E8A0373
	v_sad_u8 v20, v20, 0, 0x6400                               // 000000447870: D6220014 03FD0114 00006400
	v_sad_u8 v8, v8, 0, 0x6400                                 // 00000044787C: D6220008 03FD0108 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000447888: BF870092
	v_lshlrev_b32_e32 v20, 16, v20                             // 00000044788C: 30282890
	v_and_or_b32 v8, 0xffff, v8, v20                           // 000000447890: D6570008 045210FF 0000FFFF
	v_and_b32_e32 v20, 0xffff, v21                             // 00000044789C: 36282AFF 0000FFFF
	v_sad_u8 v21, v22, 0, 0x6400                               // 0000004478A4: D6220015 03FD0116 00006400
	v_mov_b32_e32 v22, v56                                     // 0000004478B0: 7E2C0338
	v_and_or_b32 v1, 0xffff, v18, v7                           // 0000004478B4: D6570001 041E24FF 0000FFFF
	v_pk_fma_f16 v8, v8, s5, 0xc931 op_sel_hi:[1,0,0]          // 0000004478C0: CC0E0008 0BFC0B08 0000C931
	v_mov_b32_e32 v18, v54                                     // 0000004478CC: 7E240336
	v_lshl_or_b32 v11, v21, 16, v20                            // 0000004478D0: D656000B 04512115
	v_mov_b32_e32 v21, v59                                     // 0000004478D8: 7E2A033B
	.long 0xd72c0006                                           // 0000004478DC: D72C0006
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 0000004478E0: 02020CFF 83DCD12D
	v_dot2acc_f32_f16 v5, v8, v2                               // 0000004478E8: 040A0508
	v_mov_b32_e32 v8, v52                                      // 0000004478EC: 7E100334
	v_pk_fma_f16 v7, v11, s5, 0xc931 op_sel_hi:[1,0,0]         // 0000004478F0: CC0E0007 0BFC0B0B 0000C931
	v_pk_fma_f16 v1, v1, s5, 0xc931 op_sel_hi:[1,0,0]          // 0000004478FC: CC0E0001 0BFC0B01 0000C931
	v_dual_mov_b32 v11, v45 :: v_dual_mov_b32 v20, v66         // 000000447908: CA10012D 0B140142
	v_mov_b32_e32 v52, v98                                     // 000000447910: 7E680362
	v_sad_u8 v6, v6, 0, 0x6400                                 // 000000447914: D6220006 03FD0106 00006400
	v_dot2acc_f32_f16 v5, v7, v3                               // 000000447920: 040A0707
	v_add_nc_u32_e32 v3, v83, v84                              // 000000447924: 4A06A953
	v_dual_dot2acc_f32_f16 v76, v1, v4 :: v_dual_mov_b32 v7, v55// 000000447928: CB100901 4C060137
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000447930: BF870194
	v_dual_mov_b32 v1, v67 :: v_dual_lshlrev_b32 v6, 16, v6    // 000000447934: CA220143 01060C90
	v_cmp_eq_u32_e32 vcc_lo, 2, v3                             // 00000044793C: 7C940682
	v_mov_b32_e32 v55, v101                                    // 000000447940: 7E6E0365
	v_dual_mov_b32 v45, v91 :: v_dual_mov_b32 v66, v112        // 000000447944: CA10015B 2D420170
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000044794C: BF870244
	v_and_or_b32 v6, 0xffff, v13, v6                           // 000000447950: D6570006 041A1AFF 0000FFFF
	v_mov_b32_e32 v13, v57                                     // 00000044795C: 7E1A0339
	v_mov_b32_e32 v57, v103                                    // 000000447960: 7E720367
	v_dual_mov_b32 v59, v105 :: v_dual_mov_b32 v54, v100       // 000000447964: CA100169 3B360164
	v_pk_fma_f16 v2, v6, s5, 0xc931 op_sel_hi:[1,0,0]          // 00000044796C: CC0E0002 0BFC0B06 0000C931
	v_mov_b32_e32 v6, v60                                      // 000000447978: 7E0C033C
	.long 0xd72c0017                                           // 00000044797C: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 000000447980: 02022EFF 83DCD12D
	v_mov_b32_e32 v60, v106                                    // 000000447988: 7E78036A
	v_mov_b32_e32 v56, v102                                    // 00000044798C: 7E700366
	v_dual_dot2acc_f32_f16 v5, v2, v4 :: v_dual_mov_b32 v2, v51// 000000447990: CB100902 05020133
	v_mov_b32_e32 v67, v113                                    // 000000447998: 7E860371
	v_mov_b32_e32 v51, v97                                     // 00000044799C: 7E660361
	s_or_b32 s0, vcc_lo, s0                                    // 0000004479A0: 8C00006A
	v_sad_u8 v23, v23, 0, 0x6400                               // 0000004479A4: D6220017 03FD0117 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004479B0: BF870091
	v_lshlrev_b32_e32 v23, 16, v23                             // 0000004479B4: 302E2E90
	v_and_or_b32 v23, 0xffff, v27, v23                         // 0000004479B8: D6570017 045E36FF 0000FFFF
	v_dual_mov_b32 v27, v48 :: v_dual_mov_b32 v48, v94         // 0000004479C4: CA100130 1B30015E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004479CC: BF870092
	v_pk_fma_f16 v23, v23, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004479D0: CC0E0017 0BFC0B17 0000C931
	v_dot2acc_f32_f16 v78, v23, v4                             // 0000004479DC: 049C0917
	v_mov_b32_e32 v23, v47                                     // 0000004479E0: 7E2E032F
	v_mov_b32_e32 v47, v93                                     // 0000004479E4: 7E5E035D
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 0000004479E8: 917E007E
	s_cbranch_execz 92                                         // 0000004479EC: BFA5005C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e60>
	s_mov_b32 s8, exec_lo                                      // 0000004479F0: BE88007E
	.long 0xd4c1007e                                           // 0000004479F4: D4C1007E
	v_cndmask_b32_e32 v1, v84, v43, vcc_lo                     // 0000004479F8: 02025754
	s_cbranch_execz 64596                                      // 0000004479FC: BFA5FC54 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xe50>
	v_mad_i64_i32 v[3:4], null, 0x300, v84, s[6:7]             // 000000447A00: D6FF7C03 001AA8FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000447A0C: BF870091
	.long 0xd7006a62                                           // 000000447A10: D7006A62
	v_cndmask_b32_e32 v1, v3, v14, vcc_lo                      // 000000447A14: 02021D03
	v_add_co_ci_u32_e64 v99, null, v4, v15, vcc_lo             // 000000447A18: D5207C63 01AA1F04
	.long 0xd7006a69                                           // 000000447A20: D7006A69
	v_cndmask_b32_e32 v1, v3, v88, vcc_lo                      // 000000447A24: 0202B103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000447A28: BF8700A1
	v_add_co_ci_u32_e64 v106, null, 0, v4, vcc_lo              // 000000447A2C: D5207C6A 01AA0880
	.long 0xd7006a77                                           // 000000447A34: D7006A77
	v_cndmask_b32_e32 v1, v3, v16, vcc_lo                      // 000000447A38: 02022103
	v_add_co_ci_u32_e64 v120, null, v4, v17, vcc_lo            // 000000447A3C: D5207C78 01AA2304
	.long 0xd7006a03                                           // 000000447A44: D7006A03
	v_cndmask_b32_e32 v1, v3, v89, vcc_lo                      // 000000447A48: 0202B303
	s_delay_alu instid0(VALU_DEP_1)                            // 000000447A4C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000447A50: D5207C04 01AA0880
	s_clause 0x1f                                              // 000000447A58: BF85001F
	global_load_b32 v97, v[98:99], off                         // 000000447A5C: DC520000 617C0062
	global_load_b32 v96, v[98:99], off offset:96               // 000000447A64: DC520060 607C0062
	global_load_b32 v95, v[98:99], off offset:192              // 000000447A6C: DC5200C0 5F7C0062
	global_load_b32 v94, v[98:99], off offset:288              // 000000447A74: DC520120 5E7C0062
	global_load_b32 v93, v[98:99], off offset:384              // 000000447A7C: DC520180 5D7C0062
	global_load_b32 v92, v[98:99], off offset:480              // 000000447A84: DC5201E0 5C7C0062
	global_load_b32 v91, v[98:99], off offset:576              // 000000447A8C: DC520240 5B7C0062
	global_load_b32 v90, v[98:99], off offset:672              // 000000447A94: DC5202A0 5A7C0062
	global_load_b32 v113, v[105:106], off                      // 000000447A9C: DC520000 717C0069
	global_load_b32 v110, v[105:106], off offset:96            // 000000447AA4: DC520060 6E7C0069
	global_load_b32 v107, v[105:106], off offset:192           // 000000447AAC: DC5200C0 6B7C0069
	global_load_b32 v104, v[105:106], off offset:288           // 000000447AB4: DC520120 687C0069
	global_load_b32 v102, v[105:106], off offset:384           // 000000447ABC: DC520180 667C0069
	global_load_b32 v100, v[105:106], off offset:480           // 000000447AC4: DC5201E0 647C0069
	global_load_b32 v99, v[105:106], off offset:576            // 000000447ACC: DC520240 637C0069
	global_load_b32 v98, v[105:106], off offset:672            // 000000447AD4: DC5202A0 627C0069
	global_load_b32 v118, v[119:120], off                      // 000000447ADC: DC520000 767C0077
	global_load_b32 v116, v[119:120], off offset:96            // 000000447AE4: DC520060 747C0077
	global_load_b32 v114, v[119:120], off offset:192           // 000000447AEC: DC5200C0 727C0077
	global_load_b32 v111, v[119:120], off offset:288           // 000000447AF4: DC520120 6F7C0077
	global_load_b32 v108, v[119:120], off offset:384           // 000000447AFC: DC520180 6C7C0077
	global_load_b32 v105, v[119:120], off offset:480           // 000000447B04: DC5201E0 697C0077
	global_load_b32 v103, v[119:120], off offset:576           // 000000447B0C: DC520240 677C0077
	global_load_b32 v101, v[119:120], off offset:672           // 000000447B14: DC5202A0 657C0077
	global_load_b32 v121, v[3:4], off                          // 000000447B1C: DC520000 797C0003
	global_load_b32 v120, v[3:4], off offset:96                // 000000447B24: DC520060 787C0003
	global_load_b32 v119, v[3:4], off offset:192               // 000000447B2C: DC5200C0 777C0003
	global_load_b32 v117, v[3:4], off offset:288               // 000000447B34: DC520120 757C0003
	global_load_b32 v115, v[3:4], off offset:384               // 000000447B3C: DC520180 737C0003
	global_load_b32 v112, v[3:4], off offset:480               // 000000447B44: DC5201E0 707C0003
	global_load_b32 v109, v[3:4], off offset:576               // 000000447B4C: DC520240 6D7C0003
	global_load_b32 v106, v[3:4], off offset:672               // 000000447B54: DC5202A0 6A7C0003
	s_branch 64508                                             // 000000447B5C: BFA0FBFC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xe50>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000447B60: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000447B64: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000447B68: 8C7E017E
	s_waitcnt vmcnt(23)                                        // 000000447B6C: BF895FF7
	v_dual_mov_b32 v1, v82 :: v_dual_mov_b32 v2, v81           // 000000447B70: CA100152 01020151
	s_waitcnt vmcnt(16)                                        // 000000447B78: BF8943F7
	v_dual_mov_b32 v3, v80 :: v_dual_mov_b32 v8, v79           // 000000447B7C: CA100150 0308014F
	s_waitcnt vmcnt(8)                                         // 000000447B84: BF8923F7
	v_dual_mov_b32 v4, v78 :: v_dual_mov_b32 v7, v76           // 000000447B88: CA10014E 0406014C
	s_waitcnt vmcnt(0)                                         // 000000447B90: BF8903F7
	v_mov_b32_e32 v6, v77                                      // 000000447B94: 7E0C034D
	v_mov_b32_e32 v9, v5                                       // 000000447B98: 7E120305
	s_mov_b32 s0, 0x76543210                                   // 000000447B9C: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000447BA4: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000447BA8: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000447BB4: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000447BC0: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000447BCC: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000447BD8: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000447BE4: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000447BF0: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000447BFC: D65C0009 03FC0109 FEDCBA98
	.long 0xd44c0000                                           // 000000447C08: D44C0000
	v_cndmask_b32_e32 v1, 16, v41, vcc_lo                      // 000000447C0C: 02025290
	s_barrier                                                  // 000000447C10: BFBD0000
	buffer_gl0_inv                                             // 000000447C14: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000447C1C: BE812000
	s_cbranch_execz 18                                         // 000000447C20: BFA50012 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f6c>
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v8, v79, v8    // 000000447C24: C9081305 0508114F
	v_dual_add_f32 v1, v82, v1 :: v_dual_add_f32 v2, v81, v2   // 000000447C2C: C9080352 01020551
	v_lshl_or_b32 v9, v40, 9, v42                              // 000000447C34: D6560009 04A91328
	v_dual_add_f32 v3, v80, v3 :: v_dual_add_f32 v4, v78, v4   // 000000447C3C: C9080750 0304094E
	v_dual_add_f32 v6, v77, v6 :: v_dual_add_f32 v7, v76, v7   // 000000447C44: C9080D4D 06060F4C
	ds_store_2addr_b32 v9, v1, v2 offset1:16                   // 000000447C4C: D8381000 00020109
	ds_store_2addr_b32 v9, v3, v8 offset0:32 offset1:48        // 000000447C54: D8383020 00080309
	ds_store_2addr_b32 v9, v4, v6 offset0:64 offset1:80        // 000000447C5C: D8385040 00060409
	ds_store_2addr_b32 v9, v7, v5 offset0:96 offset1:112       // 000000447C64: D8387060 00050709
	s_or_b32 exec_lo, exec_lo, s1                              // 000000447C6C: 8C7E017E
	.long 0xd44c0001                                           // 000000447C70: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000447C74: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000447C7C: BF89FC07
	s_barrier                                                  // 000000447C80: BFBD0000
	buffer_gl0_inv                                             // 000000447C84: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000447C8C: BE852001
	s_cbranch_execnz 9                                         // 000000447C90: BFA60009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1fb8>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000447C94: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 000000447C98: BF048221
	s_mov_b32 s5, -1                                           // 000000447C9C: BE8500C1
	s_cbranch_scc0 35                                          // 000000447CA0: BFA10023 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2030>
	s_and_b32 vcc_lo, exec_lo, s5                              // 000000447CA4: 8B6A057E
	s_cbranch_vccnz 156                                        // 000000447CA8: BFA4009C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x221c>
	s_nop 0                                                    // 000000447CAC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000447CB0: BFB60003
	s_endpgm                                                   // 000000447CB4: BFB00000
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000447CB8: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:2            // 000000447CBC: D8E00200 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:4 offset1:6  // 000000447CC4: D8E00604 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:8 offset1:10 // 000000447CCC: D8E00A08 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000447CD4: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000447CD8: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000447CDC: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000447CE0: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000447CE4: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000447CE8: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:12 offset1:14// 000000447CEC: D8E00E0C 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000447CF4: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000447CF8: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000447CFC: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000447D00: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000447D04: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000447D08: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000447D0C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000447D10: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000447D14: 06020501
	ds_store_b32 v7, v1 offset:4096                            // 000000447D18: D8341000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 000000447D20: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 000000447D24: BF048221
	s_mov_b32 s5, -1                                           // 000000447D28: BE8500C1
	s_cbranch_scc1 65501                                       // 000000447D2C: BFA2FFDD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1fa4>
	s_waitcnt lgkmcnt(0)                                       // 000000447D30: BF89FC07
	s_barrier                                                  // 000000447D34: BFBD0000
	buffer_gl0_inv                                             // 000000447D38: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000447D40: BE852001
	s_cbranch_execz 17                                         // 000000447D44: BFA50011 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x208c>
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000447D48: 30020082
	s_mul_hi_i32 s7, s26, s4                                   // 000000447D4C: 9707041A
	s_mul_i32 s6, s26, s4                                      // 000000447D50: 9606041A
	s_lshl_b32 s8, s2, 7                                       // 000000447D54: 84088702
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000447D58: 84868206
	ds_load_b32 v2, v1 offset:4096                             // 000000447D5C: D8D81000 02000001
	s_ashr_i32 s9, s8, 31                                      // 000000447D64: 86099F08
	s_add_u32 s4, s16, s6                                      // 000000447D68: 80040610
	s_addc_u32 s10, s17, s7                                    // 000000447D6C: 820A0711
	s_lshl_b64 s[6:7], s[8:9], 2                               // 000000447D70: 84868208
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000447D74: BF870009
	s_add_u32 s6, s4, s6                                       // 000000447D78: 80060604
	s_addc_u32 s7, s10, s7                                     // 000000447D7C: 8207070A
	s_waitcnt lgkmcnt(0)                                       // 000000447D80: BF89FC07
	global_store_b32 v1, v2, s[6:7]                            // 000000447D84: DC6A0000 00060201
	s_or_b32 exec_lo, exec_lo, s5                              // 000000447D8C: 8C7E057E
	.long 0xd44a0004                                           // 000000447D90: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000447D94: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000447D98: BC7C0000
	buffer_gl1_inv                                             // 000000447D9C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000447DA4: E0AC0000 00000000
	s_barrier                                                  // 000000447DAC: BFBD0000
	buffer_gl0_inv                                             // 000000447DB0: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000447DB8: BE852004
	s_cbranch_execz 29                                         // 000000447DBC: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2134>
	s_mov_b32 s7, exec_lo                                      // 000000447DC0: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000447DC4: BE86007E
	.long 0xd71f0001                                           // 000000447DC8: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 000000447DCC: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000447DD0: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000447DD4: 7D940280
	s_cbranch_execz 9                                          // 000000447DD8: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2100>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 000000447DDC: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000447DE0: BF8704B9
	s_add_u32 s8, s18, s8                                      // 000000447DE4: 80080812
	s_addc_u32 s9, s19, s9                                     // 000000447DE8: 82090913
	s_bcnt1_i32_b32 s7, s7                                     // 000000447DEC: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 000000447DF0: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 000000447DF8: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 000000447E00: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000447E04: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 000000447E08: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000447E0C: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 000000447E10: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 000000447E18: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000447E1C: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 000000447E20: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000447E24: D5010001 01A90280
	ds_store_b32 v2, v1 offset:5120                            // 000000447E2C: D8341400 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 000000447E34: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 000000447E38: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000447E3C: BF89FC07
	s_barrier                                                  // 000000447E40: BFBD0000
	buffer_gl0_inv                                             // 000000447E44: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:5120                             // 000000447E4C: D8D81400 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000447E54: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000447E58: 7C940280
	s_cbranch_vccnz 46                                         // 000000447E5C: BFA4002E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2218>
	buffer_gl1_inv                                             // 000000447E60: E0B00000 00000000
	buffer_gl0_inv                                             // 000000447E68: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000447E70: BE852001
	s_cbranch_execz 28                                         // 000000447E74: BFA5001C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x21e8>
	s_lshl_b32 s6, s2, 7                                       // 000000447E78: 84068702
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 000000447E7C: CA220080 04020082
	s_ashr_i32 s7, s6, 31                                      // 000000447E84: 86079F06
	s_ashr_i32 s27, s26, 31                                    // 000000447E88: 861B9F1A
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000447E8C: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000447E90: BF8700B9
	s_add_u32 s1, s16, s6                                      // 000000447E94: 80010610
	s_addc_u32 s6, s17, s7                                     // 000000447E98: 82060711
	.long 0xd7000101                                           // 000000447E9C: D7000101
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 000000447EA0: 02020601
	v_add_co_ci_u32_e64 v2, null, s6, 0, s1                    // 000000447EA4: D5207C02 00050006
	s_lshl_b64 s[6:7], s[26:27], 2                             // 000000447EAC: 8486821A
	global_load_b32 v5, v[1:2], off glc                        // 000000447EB0: DC524000 057C0001
	.long 0xd7006a01                                           // 000000447EB8: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000447EBC: 02000D01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000447EC0: BF8704A1
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000447EC4: D5207C02 01AA0407
	s_add_i32 s33, s33, -1                                     // 000000447ECC: 8121C121
	s_cmp_eq_u32 s33, 0                                        // 000000447ED0: BF068021
	s_waitcnt vmcnt(0)                                         // 000000447ED4: BF8903F7
	v_add_f32_e32 v4, v4, v5                                   // 000000447ED8: 06080B04
	s_cbranch_scc0 65524                                       // 000000447EDC: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x21b0>
	ds_store_b32 v3, v4 offset:4096                            // 000000447EE0: D8341000 00000403
	s_or_b32 exec_lo, exec_lo, s5                              // 000000447EE8: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 000000447EEC: BE812004
	s_cbranch_execz 6                                          // 000000447EF0: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x220c>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 000000447EF4: 84848202
	v_mov_b32_e32 v1, 0                                        // 000000447EF8: 7E020280
	s_add_u32 s4, s18, s4                                      // 000000447EFC: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000447F00: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 000000447F04: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000447F0C: 8C7E017E
	s_cbranch_execz 65382                                      // 000000447F10: BFA5FF66 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1fac>
	s_branch 1                                                 // 000000447F14: BFA00001 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x221c>
	s_branch 65380                                             // 000000447F18: BFA0FF64 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1fac>
	v_cmp_eq_u32_e32 vcc_lo, 0, v40                            // 000000447F1C: 7C945080
	s_cmp_gt_i32 s24, 0                                        // 000000447F20: BF028018
	s_waitcnt lgkmcnt(0)                                       // 000000447F24: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000447F28: BC7C0000
	s_cselect_b32 s1, -1, 0                                    // 000000447F2C: 980180C1
	s_barrier                                                  // 000000447F30: BFBD0000
	s_and_b32 s1, vcc_lo, s1                                   // 000000447F34: 8B01016A
	buffer_gl0_inv                                             // 000000447F38: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000447F40: BE832001
	s_cbranch_execz 65369                                      // 000000447F44: BFA5FF59 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1fac>
	v_and_b32_e32 v1, 15, v0                                   // 000000447F48: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000447F4C: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000447F50: 30040282
	v_add_nc_u32_e32 v8, 0x1000, v2                            // 000000447F54: 4A1004FF 00001000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 000000447F5C: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000447F64: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 000000447F6C: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000447F74: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000447F7C: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 000000447F80: 36160082
	s_waitcnt lgkmcnt(3)                                       // 000000447F84: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 000000447F88: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000447F90: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000447F94: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000447F9C: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000447FA0: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000447FA8: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000447FAC: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000447FB4: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000447FBC: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000447FC0: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000447FC4: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 000000447FCC: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000447FD4: 7C941480
	.long 0xd44a0001                                           // 000000447FD8: D44A0001
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 000000447FDC: 02021680
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000447FE0: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000447FE8: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000447FEC: 08101D09
	.long 0xd44a0003                                           // 000000447FF0: D44A0003
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000447FF4: 02021880
	s_delay_alu instid0(VALU_DEP_3)                            // 000000447FF8: BF870003
	v_dual_add_f32 v9, v13, v4 :: v_dual_sub_f32 v10, v2, v6   // 000000447FFC: C90A090D 090A0D02
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000448004: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000044800C: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000448010: 060A0D02
	v_mov_b32_dpp v2, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000448014: 7E0402FA FF016107
	v_cndmask_b32_e64 v6, -v7, v7, vcc_lo                      // 00000044801C: D5010006 21AA0F07
	v_mov_b32_dpp v7, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000448024: 7E0E02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000044802C: D5010009 21AA1309
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000448034: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000044803C: D5010005 21AA0B05
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000448044: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000044804C: D501000D 21AA1B0D
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000448054: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000044805C: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000448064: 7E2202FA FF016104
	v_cndmask_b32_e64 v18, -v4, v4, vcc_lo                     // 00000044806C: D5010012 21AA0904
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000448074: 7E2602FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 00000044807C: D5010014 21AA0703
	v_dual_add_f32 v3, v9, v7 :: v_dual_add_f32 v2, v6, v2     // 000000448084: C9080F09 03020506
	v_dual_add_f32 v4, v5, v15 :: v_dual_add_f32 v7, v8, v16   // 00000044808C: C9081F05 04062108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000448094: BF870192
	v_cndmask_b32_e64 v8, -v3, v3, s1                          // 000000448098: D5010008 20060703
	v_mov_b32_dpp v6, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004480A0: 7E0C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 0000004480A8: D5010002 20060502
	v_mov_b32_dpp v3, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004480B0: 7E0602FA FF016203
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004480B8: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000004480C0: D5010004 20060904
	v_add_f32_e32 v5, v13, v14                                 // 0000004480C8: 060A1D0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004480CC: BF870224
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v8, v3     // 0000004480D0: C9080D02 02020708
	v_mov_b32_dpp v13, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004480D8: 7E1A02FA FF016207
	v_add_f32_e32 v4, v4, v11                                  // 0000004480E0: 06081704
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004480E4: BF870004
	v_mov_b32_dpp v9, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004480E8: 7E1202FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 0000004480F0: D5010005 20060B05
	v_mov_b32_dpp v6, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004480F8: 7E0C02FA FF016402
	v_cndmask_b32_e64 v8, -v3, v3, s3                          // 000000448100: D5010008 200E0703
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000448108: D5010002 200E0502
	v_mov_b32_dpp v11, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000448110: 7E1602FA FF016403
	v_add_f32_e32 v5, v5, v9                                   // 000000448118: 060A1305
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000044811C: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000448124: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000044812C: BF870214
	v_dual_add_f32 v3, v2, v6 :: v_dual_add_f32 v6, v8, v11    // 000000448130: C9080D02 03061708
	v_mov_b32_dpp v8, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000448138: 7E1002FA FF016405
	v_cndmask_b32_e64 v11, -v5, v5, s3                         // 000000448140: D501000B 200E0B05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000448148: BF870004
	v_add_f32_e32 v4, v4, v9                                   // 00000044814C: 06081304
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000448150: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000448158: D501000A 21AA150A
	v_add_f32_e32 v12, v18, v17                                // 000000448160: 06182312
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000448164: D5010007 20060F07
	v_add_f32_e32 v14, v20, v19                                // 00000044816C: 061C2714
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000448170: 7E0402FA FF016803
	v_add_f32_e32 v9, v10, v9                                  // 000000448178: 0612130A
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000044817C: 7E0A02FA FF016806
	v_add_f32_e32 v13, v7, v13                                 // 000000448184: 061A1B07
	v_mov_b32_dpp v15, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000448188: 7E1E02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000448190: D501000E 20061D0E
	v_mov_b32_dpp v16, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000448198: 7E2002FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000004481A0: D5010009 20061309
	v_add_f32_e32 v7, v11, v8                                  // 0000004481A8: 060E110B
	v_mov_b32_dpp v10, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004481AC: 7E1402FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 0000004481B4: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004481BC: BF870114
	v_dual_add_f32 v8, v14, v15 :: v_dual_add_f32 v9, v9, v16  // 0000004481C0: C9081F0E 08082109
	v_add_f32_e32 v10, v12, v10                                // 0000004481C8: 0614150C
	v_mov_b32_dpp v11, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004481CC: 7E1602FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 0000004481D4: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004481DC: BF870004
	v_mov_b32_dpp v15, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004481E0: 7E1E02FA FF016408
	v_mov_b32_dpp v17, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004481E8: 7E2202FA FF016409
	v_mov_b32_dpp v12, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004481F0: 7E1802FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 0000004481F8: D501000A 200E150A
	v_cndmask_b32_e64 v18, -v8, v8, s3                         // 000000448200: D5010012 200E1108
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000448208: D5010009 200E1309
	v_add_f32_e32 v14, v13, v11                                // 000000448210: 061C170D
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000448214: 7E1002FA FF016807
	v_add_f32_e32 v16, v10, v12                                // 00000044821C: 0620190A
	v_add_f32_e32 v15, v18, v15                                // 000000448220: 061E1F12
	v_add_f32_e32 v17, v9, v17                                 // 000000448224: 06222309
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000448228: 7E1202FA FF016804
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000448230: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000448238: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000448240: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000448248: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 000000448250: 8B7E007E
	s_cbranch_execz 65173                                      // 000000448254: BFA5FE95 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1fac>
	v_lshl_or_b32 v18, s2, 7, v1                               // 000000448258: D6560012 04050E02
	v_and_b32_e32 v0, 8, v0                                    // 000000448260: 36000088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000448264: BF870092
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000448268: 3426249F
	.long 0xd73c0012                                           // 00000044826C: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000448270: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000448274: BF870091
	.long 0xd7006a14                                           // 000000448278: D7006A14
	v_cndmask_b32_e32 v1, s14, v18, vcc_lo                     // 00000044827C: 0202240E
	v_add_co_ci_u32_e64 v21, null, s15, v19, vcc_lo            // 000000448280: D5207C15 01AA260F
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000448288: 7C940080
	s_clause 0x7                                               // 00000044828C: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000448290: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000448298: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 0000004482A0: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 0000004482A8: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 0000004482B0: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 0000004482B8: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 0000004482C0: DC8200C0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:224          // 0000004482C8: DC8200E0 147C0014
	.long 0x7f2a3880                                           // 0000004482D0: 7F2A3880
	v_cndmask_b32_e64 v0, -v6, v6, vcc_lo                      // 0000004482D4: D5010000 21AA0D06
	v_cndmask_b32_e64 v1, -v3, v3, vcc_lo                      // 0000004482DC: D5010001 21AA0703
	v_cndmask_b32_e64 v3, -v4, v4, vcc_lo                      // 0000004482E4: D5010003 21AA0904
	v_cndmask_b32_e64 v4, -v7, v7, vcc_lo                      // 0000004482EC: D5010004 21AA0F07
	v_cndmask_b32_e64 v7, -v14, v14, vcc_lo                    // 0000004482F4: D5010007 21AA1D0E
	v_add_f32_e32 v0, v0, v5                                   // 0000004482FC: 06000B00
	v_cndmask_b32_e64 v5, -v16, v16, vcc_lo                    // 000000448300: D5010005 21AA2110
	v_add_f32_e32 v3, v3, v9                                   // 000000448308: 06061303
	s_waitcnt vmcnt(7)                                         // 00000044830C: BF891FF7
	.long 0x7f2c3995                                           // 000000448310: 7F2C3995
	v_dual_add_f32 v7, v7, v10 :: v_dual_mul_f32 v16, 0x3db504f3, v0// 000000448314: C9061507 071000FF 3DB504F3
	v_add_f32_e32 v5, v5, v11                                  // 000000448320: 060A1705
	v_cndmask_b32_e64 v14, -v17, v17, vcc_lo                   // 000000448324: D501000E 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000044832C: D501000F 21AA1F0F
	v_add_f32_e32 v2, v1, v2                                   // 000000448334: 06040501
	v_dual_add_f32 v4, v4, v8 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 000000448338: C9061104 040206FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000448344: BF870193
	v_dual_add_f32 v9, v14, v13 :: v_dual_add_f32 v8, v15, v12 // 000000448348: C9081B0E 0908190F
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 000000448350: C8C60AFF 050204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000044835C: BF870193
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000448360: C8C60EFF 070408FF 3DB504F3
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 00000044836C: 101212FF 3DB504F3
	s_waitcnt vmcnt(6)                                         // 000000448374: BF891BF7
	.long 0x7f2e3995                                           // 000000448378: 7F2E3995
	.long 0x7f0c3995                                           // 00000044837C: 7F0C3995
	s_waitcnt vmcnt(0)                                         // 000000448380: BF8903F7
	.long 0x7f283995                                           // 000000448384: 7F283995
	.long 0xd7006a00                                           // 000000448388: D7006A00
	v_cndmask_b32_e32 v1, s20, v18, vcc_lo                     // 00000044838C: 02022414
	s_delay_alu instid0(VALU_DEP_1)                            // 000000448390: BF870001
	v_add_co_ci_u32_e64 v1, null, s21, v19, vcc_lo             // 000000448394: D5207C01 01AA2615
	v_fma_mix_f32 v10, v22, v16, neg(0) op_sel_hi:[1,0,0]      // 00000044839C: CC20000A 8A022116
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 0000004483A4: CC200002 8A020517
	v_fma_mix_f32 v4, v24, v4, neg(0) op_sel_hi:[1,0,0]        // 0000004483AC: CC200004 8A020918
	v_fma_mix_f32 v3, v25, v3, neg(0) op_sel_hi:[1,0,0]        // 0000004483B4: CC200003 8A020719
	v_fma_mix_f32 v7, v26, v7, neg(0) op_sel_hi:[1,0,0]        // 0000004483BC: CC200007 8A020F1A
	.long 0x7e2a398a                                           // 0000004483C4: 7E2A398A
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 0000004483C8: 101010FF 3DB504F3
	v_fma_mix_f32 v5, v27, v5, neg(0) op_sel_hi:[1,0,0]        // 0000004483D0: CC200005 8A020B1B
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 0000004483D8: CC200009 8A021314
	.long 0x7e0c3982                                           // 0000004483E0: 7E0C3982
	v_and_b32_e32 v11, 1, v21                                  // 0000004483E4: 36162A81
	.long 0x7e2a3983                                           // 0000004483E8: 7E2A3983
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 0000004483EC: CC200008 8A02111C
	.long 0x7e283984                                           // 0000004483F4: 7E283984
	.long 0x7e2c3987                                           // 0000004483F8: 7E2C3987
	v_and_b32_e32 v6, 1, v6                                    // 0000004483FC: 360C0C81
	v_and_b32_e32 v12, 1, v21                                  // 000000448400: 36182A81
	.long 0x7e2a3985                                           // 000000448404: 7E2A3985
	.long 0x7e2e3988                                           // 000000448408: 7E2E3988
	v_and_b32_e32 v13, 1, v20                                  // 00000044840C: 361A2881
	v_and_b32_e32 v14, 1, v22                                  // 000000448410: 361C2C81
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000448414: D6550002 03FE0D02 00007FFF
	v_and_b32_e32 v15, 1, v21                                  // 000000448420: 361E2A81
	.long 0x7e2a3989                                           // 000000448424: 7E2A3989
	v_and_b32_e32 v16, 1, v23                                  // 000000448428: 36202E81
	v_add3_u32 v10, v10, v11, 0x7fff                           // 00000044842C: D655000A 03FE170A 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 000000448438: D6550004 03FE1B04 00007FFF
	v_add3_u32 v3, v3, v12, 0x7fff                             // 000000448444: D6550003 03FE1903 00007FFF
	v_and_b32_e32 v6, 1, v21                                   // 000000448450: 360C2A81
	v_add3_u32 v7, v7, v14, 0x7fff                             // 000000448454: D6550007 03FE1D07 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 000000448460: D6550008 03FE2108 00007FFF
	v_add3_u32 v5, v5, v15, 0x7fff                             // 00000044846C: D6550005 03FE1F05 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000448478: BF870004
	v_add3_u32 v6, v9, v6, 0x7fff                              // 00000044847C: D6550006 03FE0D09 00007FFF
	s_clause 0x7                                               // 000000448488: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000044848C: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v10, off offset:32         // 000000448494: DC960020 007C0A00
	global_store_d16_hi_b16 v[0:1], v4, off offset:64          // 00000044849C: DC960040 007C0400
	global_store_d16_hi_b16 v[0:1], v3, off offset:96          // 0000004484A4: DC960060 007C0300
	global_store_d16_hi_b16 v[0:1], v7, off offset:128         // 0000004484AC: DC960080 007C0700
	global_store_d16_hi_b16 v[0:1], v5, off offset:160         // 0000004484B4: DC9600A0 007C0500
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 0000004484BC: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v6, off offset:224         // 0000004484C4: DC9600E0 007C0600
	s_nop 0                                                    // 0000004484CC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000004484D0: BFB60003
	s_endpgm                                                   // 0000004484D4: BFB00000
		...

