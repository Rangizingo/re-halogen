0000000000483c00 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x3                                               // 000000483C00: BF850003
	s_load_b256 s[12:19], s[0:1], null                         // 000000483C04: F40C0300 F8000000
	s_load_b256 s[20:27], s[0:1], 0x20                         // 000000483C0C: F40C0500 F8000020
	s_load_b128 s[28:31], s[0:1], 0x40                         // 000000483C14: F4080700 F8000040
	s_load_b32 s33, s[0:1], 0x54                               // 000000483C1C: F4000840 F8000054
	v_and_b32_e32 v21, 31, v0                                  // 000000483C24: 362A009F
	v_lshrrev_b32_e32 v19, 5, v0                               // 000000483C28: 32260085
	s_mov_b32 s10, s3                                          // 000000483C2C: BE8A0003
	s_mov_b32 s35, exec_lo                                     // 000000483C30: BEA3007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000483C34: BF870002
	v_lshlrev_b32_e32 v20, 2, v21                              // 000000483C38: 30282A82
	s_waitcnt lgkmcnt(0)                                       // 000000483C3C: BF89FC07
	s_ashr_i32 s11, s17, 31                                    // 000000483C40: 860B9F11
	s_mul_i32 s34, s19, s3                                     // 000000483C44: 96220313
	s_lshr_b32 s0, s11, 25                                     // 000000483C48: 8500990B
	s_add_i32 s1, s34, s19                                     // 000000483C4C: 81011322
	s_add_i32 s0, s17, s0                                      // 000000483C50: 81000011
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000483C54: BF870499
	s_ashr_i32 s0, s0, 7                                       // 000000483C58: 86008700
	s_min_i32 s0, s0, s1                                       // 000000483C5C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000483C60: BF870499
	s_sub_i32 s9, s0, s34                                      // 000000483C64: 81892200
	s_lshl_b32 s19, s9, 2                                      // 000000483C68: 84138209
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000483C6C: BF870009
	.long 0xd4c4007e                                           // 000000483C70: D4C4007E
	v_cndmask_b32_e32 v1, s19, v19, vcc_lo                     // 000000483C74: 02022613
	s_cbranch_execz 499                                        // 000000483C78: BFA501F3 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x848>
	s_add_i32 s36, s16, -1                                     // 000000483C7C: 8124C110
	s_cmp_lg_u64 s[30:31], 0                                   // 000000483C80: BF11801E
	v_and_b32_e32 v2, 2, v0                                    // 000000483C84: 36040082
	s_cselect_b32 s37, -1, 0                                   // 000000483C88: 982580C1
	s_abs_i32 s38, s9                                          // 000000483C8C: BEA61509
	v_lshlrev_b32_e32 v6, 3, v21                               // 000000483C90: 300C2A83
	s_cvt_f32_u32 s0, s38                                      // 000000483C94: BE806526
	v_dual_mov_b32 v8, v19 :: v_dual_and_b32 v1, 1, v0         // 000000483C98: CA240113 08000081
	v_and_b32_e32 v4, 4, v0                                    // 000000483CA0: 36080084
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000483CA4: BF870009
	v_rcp_iflag_f32_e32 v3, s0                                 // 000000483CA8: 7E065600
	v_and_b32_e32 v5, 8, v0                                    // 000000483CAC: 360A0088
	v_add_nc_u32_e32 v7, s34, v19                              // 000000483CB0: 4A0E2622
	.long 0xd44a0003                                           // 000000483CB4: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000483CB8: 02020480
	v_lshl_or_b32 v2, v19, 8, v6                               // 000000483CBC: D6560002 04191113
	s_ashr_i32 s42, s9, 31                                     // 000000483CC4: 862A9F09
	s_sub_i32 s8, 0, s38                                       // 000000483CC8: 81882680
	s_mul_i32 s44, s42, 0x1400                                 // 000000483CCC: 962CFF2A 00001400
	.long 0xd44c0000                                           // 000000483CD4: D44C0000
	v_cndmask_b32_e32 v1, 16, v21, vcc_lo                      // 000000483CD8: 02022A90
	.long 0xd44a0001                                           // 000000483CDC: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000483CE0: 02020280
	v_readfirstlane_b32 s4, v3                                 // 000000483CE4: 7E080503
	.long 0xd44a0005                                           // 000000483CE8: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000483CEC: 02020A80
	v_lshl_or_b32 v1, v7, 7, v20                               // 000000483CF0: D6560001 04510F07
	v_subrev_nc_u32_e32 v9, s44, v2                            // 000000483CF8: 4E12042C
	s_lshl_b32 s6, s9, 7                                       // 000000483CFC: 84068709
	s_mul_f32 s7, s4, 0x4f7ffffe                               // 000000483D00: A207FF04 4F7FFFFE
	.long 0xd44a0004                                           // 000000483D08: D44A0004
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000483D0C: 02020880
	s_mov_b32 s39, s17                                         // 000000483D10: BEA70011
	s_mov_b32 s40, 0                                           // 000000483D14: BEA80080
	s_cvt_u32_f32 s7, s7                                       // 000000483D18: BE876707
	s_mov_b32 s41, 0x76543210                                  // 000000483D1C: BEA900FF 76543210
	s_lshl_b32 s43, s9, 8                                      // 000000483D24: 842B8809
	s_sub_i32 s44, 0, s6                                       // 000000483D28: 81AC0680
	s_mul_i32 s8, s8, s7                                       // 000000483D2C: 96080708
	s_mov_b32 s46, 0x3db504f3                                  // 000000483D30: BEAE00FF 3DB504F3
	s_mul_hi_u32 s8, s7, s8                                    // 000000483D38: 96880807
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000483D3C: BF870009
	s_add_i32 s45, s7, s8                                      // 000000483D40: 812D0807
	s_branch 164                                               // 000000483D44: BFA000A4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3d8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000483D48: BF870091
	.long 0xd7006a02                                           // 000000483D4C: D7006A02
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000483D50: 02020414
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo              // 000000483D54: D5207C03 01AA0615
	v_sub_f32_e32 v4, v15, v13                                 // 000000483D5C: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000483D60: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000483D68: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000483D70: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 000000483D74: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 000000483D7C: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 000000483D84: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000483D88: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000483D8C: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000483D90: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000483D94: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000483D98: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000483D9C: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000483DA0: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000483DA8: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000483DB0: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000483DB8: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000483DC0: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 000000483DC4: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000483DC8: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000483DD0: D5010007 20060F07
	.long 0xd72c0006                                           // 000000483DD8: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 000000483DDC: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 000000483DE4: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000483DE8: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000483DF0: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 000000483DF8: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 000000483DFC: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000483E00: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000483E08: D5010003 20060703
	.long 0xd72c0007                                           // 000000483E10: D72C0007
	v_cndmask_b32_e32 v1, s43, v10, vcc_lo                     // 000000483E14: 0202142B
	v_add_f32_e32 v2, v2, v13                                  // 000000483E18: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000483E1C: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000483E24: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 000000483E2C: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000483E30: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000483E34: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000483E3C: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 000000483E44: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000483E48: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000483E50: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000483E58: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000483E60: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 000000483E68: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000483E6C: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 000000483E74: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000483E78: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 000000483E80: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000483E84: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000483E8C: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000483E94: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000483E9C: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000483EA4: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000483EAC: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 000000483EB4: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000483EB8: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 000000483EBC: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000483EC0: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 000000483EC4: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000483EC8: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000483ED0: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000483ED8: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000483EDC: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000483EE4: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000483EEC: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000483EF0: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000483EF8: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 000000483F00: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 000000483F08: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s19, v8                           // 000000483F0C: 7C861013
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000483F10: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 000000483F14: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 000000483F1C: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000483F24: BF870234
	v_mov_b32_e32 v13, v2                                      // 000000483F28: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000483F2C: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000483F34: D5010004 20020904
	v_permlanex16_b32 v11, v11, s41, 0xfedcba98                // 000000483F3C: D65C000B 03FC530B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 000000483F48: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000483F4C: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000483F54: D5010003 20020703
	v_permlanex16_b32 v10, v10, s41, 0xfedcba98                // 000000483F5C: D65C000A 03FC530A FEDCBA98
	v_permlanex16_b32 v13, v13, s41, 0xfedcba98                // 000000483F68: D65C000D 03FC530D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 000000483F74: 060A1705
	v_permlanex16_b32 v12, v12, s41, 0xfedcba98                // 000000483F78: D65C000C 03FC530C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000483F84: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 000000483F88: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 000000483F94: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000483F98: BF870214
	v_fma_mixhi_f16 v2, v5, s46, 0                             // 000000483F9C: CC220002 02005D05
	v_add_f32_e32 v10, v3, v12                                 // 000000483FA4: 06141903
	s_or_b32 s40, vcc_lo, s40                                  // 000000483FA8: 8C28286A
	v_fma_mixlo_f16 v2, v4, s46, 0                             // 000000483FAC: CC210002 02005D04
	v_fma_mixhi_f16 v3, v7, s46, 0                             // 000000483FB4: CC220003 02005D07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000483FBC: BF870003
	v_fma_mixlo_f16 v3, v10, s46, 0                            // 000000483FC0: CC210003 02005D0A
	ds_store_b64 v6, v[2:3]                                    // 000000483FC8: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 000000483FD0: 917E287E
	s_cbranch_execz 284                                        // 000000483FD4: BFA5011C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x848>
	.long 0xd72d0002                                           // 000000483FD8: D72D0002
	v_cndmask_b32_e32 v0, v8, v45, vcc_lo                      // 000000483FDC: 02005B08
	s_mov_b32 s6, -1                                           // 000000483FE0: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000483FE4: BF870091
	.long 0xd72c0003                                           // 000000483FE8: D72C0003
	v_cndmask_b32_e32 v0, v2, v38, vcc_lo                      // 000000483FEC: 02004D02
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000483FF0: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000483FF4: BF870121
	v_subrev_nc_u32_e32 v5, s38, v3                            // 000000483FF8: 4E0A0626
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000483FFC: 7C960626
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000484000: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000484008: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 00000048400C: 02040902
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000484010: 7C960626
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000484014: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000484018: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 00000048401C: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s37                        // 000000484020: 916A257E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000484024: BF870091
	v_xor_b32_e32 v11, s42, v2                                 // 000000484028: 3A16042A
	v_subrev_nc_u32_e32 v10, s42, v11                          // 00000048402C: 4E14162A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000484030: BF8700A1
	v_mad_u64_u32 v[6:7], null, s44, v10, v[1:2]               // 000000484034: D6FE7C06 0406142C
	v_min_i32_e32 v2, s36, v10                                 // 00000048403C: 22041424
	v_mad_i64_i32 v[4:5], null, v2, s39, 0                     // 000000484040: D6FF7C04 02004F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000484048: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 00000048404C: 340E0C9F
	.long 0xd73c0002                                           // 000000484050: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000484054: 02020C81
	s_cbranch_vccnz 207                                        // 000000484058: BFA400CF <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x798>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000048405C: BF870093
	.long 0xd7006a06                                           // 000000484060: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000484064: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000484068: D5207C07 01AA0F05
	.long 0x7f3e3880                                           // 000000484070: 7F3E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000484074: BF870112
	.long 0xd73c0006                                           // 000000484078: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000048407C: 02020C81
	.long 0x7f44399f                                           // 000000484080: 7F44399F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000484084: BF870092
	.long 0xd7006a0c                                           // 000000484088: D7006A0C
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 00000048408C: 02020C0E
	v_add_co_ci_u32_e64 v13, null, s15, v7, vcc_lo             // 000000484090: D5207C0D 01AA0E0F
	.long 0xd7006a06                                           // 000000484098: D7006A06
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 00000048409C: 02020C1E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004840A0: BF870001
	v_add_co_ci_u32_e64 v7, null, s31, v7, vcc_lo              // 0000004840A4: D5207C07 01AA0E1F
	global_load_b64 v[12:13], v[12:13], off                    // 0000004840AC: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 0000004840B4: D7006A0E
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 0000004840B8: 02020414
	global_load_b64 v[6:7], v[6:7], off                        // 0000004840BC: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s21, v3, vcc_lo             // 0000004840C4: D5207C0F 01AA0615
	s_clause 0x1                                               // 0000004840CC: BF850001
	global_load_b32 v16, v[14:15], off                         // 0000004840D0: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 0000004840D8: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 0000004840E0: BF890FF7
	v_lshlrev_b32_e32 v17, 16, v13                             // 0000004840E4: 30221A90
	.long 0x7e1e390c                                           // 0000004840E8: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 0000004840EC: BF890BF7
	v_and_b32_e32 v41, 0xffff0000, v6                          // 0000004840F0: 36520CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004840F8: BF870093
	v_dual_mul_f32 v23, 0xbfb8aa3b, v17 :: v_dual_lshlrev_b32 v6, 16, v6// 0000004840FC: C8E222FF 17060C90 BFB8AA3B
	v_exp_f32_e32 v23, v23                                     // 000000484108: 7E2E4B17
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000048410C: BF870095
	v_dual_add_f32 v23, 1.0, v23 :: v_dual_and_b32 v12, 0xffff0000, v12// 000000484110: C9242EF2 170C18FF FFFF0000
	v_dual_mul_f32 v18, 0xbfb8aa3b, v12 :: v_dual_lshlrev_b32 v15, 16, v15// 00000048411C: C8E218FF 120E1E90 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000484128: BF870111
	v_mul_f32_e32 v22, 0xbfb8aa3b, v15                         // 00000048412C: 102C1EFF BFB8AA3B
	v_exp_f32_e32 v18, v18                                     // 000000484134: 7E244B12
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000484138: 361A1AFF FFFF0000
	v_div_scale_f32 v27, null, v23, v23, v17                   // 000000484140: D6FC7C1B 04462F17
	v_div_scale_f32 v37, s6, v17, v23, v17                     // 000000484148: D6FC0625 04462F11
	v_exp_f32_e32 v22, v22                                     // 000000484150: 7E2C4B16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 000000484154: BF870392
	v_rcp_f32_e32 v32, v27                                     // 000000484158: 7E40551B
	v_add_f32_e32 v18, 1.0, v18                                // 00000048415C: 062424F2
	v_mul_f32_e32 v24, 0xbfb8aa3b, v13                         // 000000484160: 10301AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000484168: BF870196
	v_add_f32_e32 v22, 1.0, v22                                // 00000048416C: 062C2CF2
	v_div_scale_f32 v25, null, v18, v18, v12                   // 000000484170: D6FC7C19 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 000000484178: BF870323
	v_exp_f32_e32 v24, v24                                     // 00000048417C: 7E304B18
	v_div_scale_f32 v35, vcc_lo, v12, v18, v12                 // 000000484180: D6FC6A23 0432250C
	v_fma_f32 v40, -v27, v32, 1.0                              // 000000484188: D6130028 23CA411B
	v_div_scale_f32 v26, null, v22, v22, v15                   // 000000484190: D6FC7C1A 043E2D16
	v_rcp_f32_e32 v28, v25                                     // 000000484198: 7E385519
	v_div_scale_f32 v39, s7, v15, v22, v15                     // 00000048419C: D6FC0727 043E2D0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004841A4: BF870193
	v_fmac_f32_e32 v32, v40, v32                               // 0000004841A8: 56404128
	v_rcp_f32_e32 v30, v26                                     // 0000004841AC: 7E3C551A
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004841B0: BF870117
	v_add_f32_e32 v24, 1.0, v24                                // 0000004841B4: 063030F2
	v_mul_f32_e32 v42, v37, v32                                // 0000004841B8: 10544125
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004841BC: BF870196
	v_fma_f32 v36, -v25, v28, 1.0                              // 0000004841C0: D6130024 23CA3919
	v_div_scale_f32 v29, null, v24, v24, v13                   // 0000004841C8: D6FC7C1D 04363118
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000004841D0: BF870293
	v_fma_f32 v46, -v27, v42, v37                              // 0000004841D4: D613002E 2496551B
	v_fma_f32 v38, -v26, v30, 1.0                              // 0000004841DC: D6130026 23CA3D1A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004841E4: BF870214
	v_fmac_f32_e32 v28, v36, v28                               // 0000004841E8: 56383924
	v_rcp_f32_e32 v33, v29                                     // 0000004841EC: 7E42551D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004841F0: BF870193
	v_fmac_f32_e32 v42, v46, v32                               // 0000004841F4: 5654412E
	v_fmac_f32_e32 v30, v38, v30                               // 0000004841F8: 563C3D26
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004841FC: BF870193
	v_mul_f32_e32 v40, v35, v28                                // 000000484200: 10503923
	v_fma_f32 v27, -v27, v42, v37                              // 000000484204: D613001B 2496551B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000048420C: BF870292
	v_fma_f32 v43, -v25, v40, v35                              // 000000484210: D613002B 248E5119
	v_fma_f32 v36, -v29, v33, 1.0                              // 000000484218: D6130024 23CA431D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000484220: BF8701B1
	v_dual_fmac_f32 v40, v43, v28 :: v_dual_fmac_f32 v33, v36, v33// 000000484224: C800392B 28204324
	v_mul_f32_e32 v36, v39, v30                                // 00000048422C: 10483D27
	v_div_scale_f32 v38, s8, v13, v24, v13                     // 000000484230: D6FC0826 0436310D
	v_fma_f32 v25, -v25, v40, v35                              // 000000484238: D6130019 248E5119
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000484240: BF870193
	v_fma_f32 v45, -v26, v36, v39                              // 000000484244: D613002D 249E491A
	v_mul_f32_e32 v44, v38, v33                                // 00000048424C: 10584326
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000484250: BF8701A3
	v_div_fmas_f32 v25, v25, v28, v40                          // 000000484254: D6370019 04A23919
	s_mov_b32 vcc_lo, s7                                       // 00000048425C: BEEA0007
	v_fmac_f32_e32 v36, v45, v30                               // 000000484260: 56483D2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000484264: BF870193
	v_fma_f32 v43, -v29, v44, v38                              // 000000484268: D613002B 249A591D
	v_div_fixup_f32 v12, v25, v18, v12                         // 000000484270: D627000C 04322519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000484278: BF870193
	v_fma_f32 v26, -v26, v36, v39                              // 00000048427C: D613001A 249E491A
	v_fmac_f32_e32 v44, v43, v33                               // 000000484284: 5658432B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000484288: BF870193
	v_mul_f32_e32 v12, v12, v41                                // 00000048428C: 1018530C
	v_div_fmas_f32 v26, v26, v30, v36                          // 000000484290: D637001A 04923D1A
	s_mov_b32 vcc_lo, s6                                       // 000000484298: BEEA0006
	s_delay_alu instid0(VALU_DEP_3)                            // 00000048429C: BF870003
	v_fma_f32 v25, -v29, v44, v38                              // 0000004842A0: D6130019 249A591D
	v_div_fmas_f32 v18, v27, v32, v42                          // 0000004842A8: D6370012 04AA411B
	s_mov_b32 vcc_lo, s8                                       // 0000004842B0: BEEA0008
	v_div_fixup_f32 v15, v26, v22, v15                         // 0000004842B4: D627000F 043E2D1A
	v_lshlrev_b32_e32 v22, 16, v7                              // 0000004842BC: 302C0E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000004842C0: 360E0EFF FFFF0000
	v_div_fixup_f32 v17, v18, v23, v17                         // 0000004842C8: D6270011 04462F12
	.long 0x7e3e398c                                           // 0000004842D0: 7E3E398C
	v_mul_f32_e32 v6, v15, v6                                  // 0000004842D4: 100C0D0F
	v_div_fmas_f32 v15, v25, v33, v44                          // 0000004842D8: D637000F 04B24319
	s_mov_b32 s6, 0                                            // 0000004842E0: BE860080
	v_mul_f32_e32 v17, v17, v22                                // 0000004842E4: 10222D11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004842E8: BF870193
	.long 0x7e443986                                           // 0000004842EC: 7E443986
	v_div_fixup_f32 v13, v15, v24, v13                         // 0000004842F0: D627000D 0436310F
	v_and_b32_e32 v15, 1, v31                                  // 0000004842F8: 361E3E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004842FC: BF870194
	v_bfe_u32 v18, v17, 16, 1                                  // 000000484300: D6100012 02052111
	v_dual_mul_f32 v7, v13, v7 :: v_dual_and_b32 v22, 1, v34   // 000000484308: C8E40F0D 07164481
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000484310: BF870193
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000484314: D655000C 03FE1F0C 00007FFF
	v_add3_u32 v13, v17, v18, 0x7fff                           // 000000484320: D655000D 03FE2511 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000048432C: BF870213
	v_add3_u32 v6, v6, v22, 0x7fff                             // 000000484330: D6550006 03FE2D06 00007FFF
	v_bfe_u32 v15, v7, 16, 1                                   // 00000048433C: D610000F 02052107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000484344: BF870214
	v_and_b32_e32 v12, 0xffff0000, v12                         // 000000484348: 361818FF FFFF0000
	v_and_b32_e32 v17, 0xffff0000, v13                         // 000000484350: 36221AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000484358: BF870214
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000048435C: 360C0CFF FFFF0000
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000484364: D6550007 03FE1F07 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000484370: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000484374: CC20080D 8A021910
	s_waitcnt vmcnt(0)                                         // 00000048437C: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 000000484380: CC20000C 8A02230E
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 000000484388: CC20000F 8A020D10
	v_and_b32_e32 v14, 0xffff0000, v7                          // 000000484390: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000484398: 916A067E
	s_cbranch_vccnz 65130                                      // 00000048439C: BFA4FE6A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x148>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004843A0: BF870093
	.long 0xd73c0004                                           // 0000004843A4: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000004843A8: 02020881
	.long 0xd7006a04                                           // 0000004843AC: D7006A04
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 0000004843B0: 0202080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004843B4: BF870111
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 0000004843B8: D5207C05 01AA0A0F
	.long 0xd7006a04                                           // 0000004843C0: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000004843C4: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004843C8: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000004843CC: D5207C05 01AA0705
	.long 0xd7006a06                                           // 0000004843D4: D7006A06
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 0000004843D8: 02020414
	v_add_co_ci_u32_e64 v7, null, s21, v3, vcc_lo              // 0000004843DC: D5207C07 01AA0615
	global_load_b64 v[4:5], v[4:5], off                        // 0000004843E4: DC560000 047C0004
	s_clause 0x1                                               // 0000004843EC: BF850001
	global_load_b32 v14, v[6:7], off                           // 0000004843F0: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 0000004843F8: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000484400: BF890BF7
	.long 0x7e0e3904                                           // 000000484404: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000484408: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 000000484410: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000484414: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000484418: 300E0E90
	s_waitcnt vmcnt(1)                                         // 00000048441C: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000484420: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 000000484428: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 00000048442C: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 000000484434: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 00000048443C: 361C0AFF FFFF0000
	s_branch 65088                                             // 000000484444: BFA0FE40 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x148>
	s_or_b32 exec_lo, exec_lo, s35                             // 000000484448: 8C7E237E
	s_bfe_i32 s8, s9, 0x1001c                                  // 00000048444C: 9388FF09 0001001C
	s_lshr_b32 s3, s11, 28                                     // 000000484454: 85039C0B
	s_lshr_b64 s[0:1], s[8:9], 29                              // 000000484458: 85809D08
	s_add_i32 s3, s17, s3                                      // 00000048445C: 81030311
	s_add_i32 s0, s0, 7                                        // 000000484460: 81008700
	s_lshl_b32 s1, s9, 3                                       // 000000484464: 84018309
	s_ashr_i32 s0, s0, 3                                       // 000000484468: 86008300
	s_lshl_b32 s4, s34, 3                                      // 00000048446C: 84048322
	.long 0xd72c0001                                           // 000000484470: D72C0001
	v_cndmask_b32_e32 v1, s0, v19, vcc_lo                      // 000000484474: 02022600
	s_waitcnt lgkmcnt(0)                                       // 000000484478: BF89FC07
	s_barrier                                                  // 00000048447C: BFBD0000
	buffer_gl0_inv                                             // 000000484480: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 000000484488: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 00000048448C: 86008403
	s_ashr_i32 s3, s4, 31                                      // 000000484490: 86039F04
	s_mul_hi_i32 s5, s0, s2                                    // 000000484494: 97050200
	s_mul_i32 s0, s0, s2                                       // 000000484498: 96000200
	v_min_i32_e32 v22, s1, v2                                  // 00000048449C: 222C0401
	v_add_nc_u32_e32 v2, 1, v1                                 // 0000004844A0: 4A040281
	s_add_u32 s0, s0, s4                                       // 0000004844A4: 80000400
	s_addc_u32 s1, s5, s3                                      // 0000004844A8: 82010305
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004844AC: BF870099
	s_lshl_b64 s[4:5], s[0:1], 10                              // 0000004844B0: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v2, v22                           // 0000004844B4: 7C822D02
	s_add_u32 s1, s12, s4                                      // 0000004844B8: 8001040C
	s_addc_u32 s4, s13, s5                                     // 0000004844BC: 8204050D
	s_and_saveexec_b32 s0, vcc_lo                              // 0000004844C0: BE80206A
	s_cbranch_execz 91                                         // 0000004844C4: BFA5005B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xa34>
	.long 0xd7010303                                           // 0000004844C8: D7010303
	v_cndmask_b32_e32 v0, v21, v129, vcc_lo                    // 0000004844CC: 02010315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004844D0: BF870121
	v_cndmask_b32_e64 v4, v3, 31, s3                           // 0000004844D4: D5010004 000D3F03
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000004844DC: 3406049F
	v_cmp_gt_u32_e32 vcc_lo, 31, v4                            // 0000004844E0: 7C98089F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004844E4: BF8701B2
	.long 0xd73c0002                                           // 0000004844E8: D73C0002
	v_cndmask_b32_e32 v1, 10, v2, vcc_lo                       // 0000004844EC: 0202048A
	v_cndmask_b32_e64 v6, 0xe1, 1, vcc_lo                      // 0000004844F0: D5010006 01A902FF 000000E1
	v_mov_b32_e32 v5, 0                                        // 0000004844FC: 7E0A0280
	.long 0xd7006a08                                           // 000000484500: D7006A08
	v_cndmask_b32_e32 v1, s1, v2, vcc_lo                       // 000000484504: 02020401
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000484508: BF870211
	v_add_co_ci_u32_e64 v9, null, s4, v3, vcc_lo               // 00000048450C: D5207C09 01AA0604
	v_add_nc_u32_e32 v6, v6, v4                                // 000000484514: 4A0C0906
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000484518: BF870114
	.long 0xd73c0004                                           // 00000048451C: D73C0004
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 000000484520: 02020882
	v_lshlrev_b32_e32 v7, 24, v6                               // 000000484524: 300E0C98
	v_bfe_i32 v6, v6, 7, 1                                     // 000000484528: D6110006 02050F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000484530: BF870093
	.long 0xd7006a02                                           // 000000484534: D7006A02
	v_cndmask_b32_e32 v1, v8, v4, vcc_lo                       // 000000484538: 02020908
	v_add_co_ci_u32_e64 v3, null, v9, v5, vcc_lo               // 00000048453C: D5207C03 01AA0B09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000484544: BF870094
	v_ashrrev_i32_e32 v7, 22, v7                               // 000000484548: 340E0E96
	.long 0xd7006a04                                           // 00000048454C: D7006A04
	v_cndmask_b32_e32 v1, v8, v7, vcc_lo                       // 000000484550: 02020F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000484554: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v9, v6, vcc_lo               // 000000484558: D5207C05 01AA0D09
	.long 0xd7006a06                                           // 000000484560: D7006A06
	v_cndmask_b32_e32 v1, v8, v20, vcc_lo                      // 000000484564: 02022908
	v_add_co_ci_u32_e64 v7, null, 0, v9, vcc_lo                // 000000484568: D5207C07 01AA1280
	s_clause 0x17                                              // 000000484570: BF850017
	global_load_b32 v23, v[2:3], off                           // 000000484574: DC520000 177C0002
	global_load_b32 v26, v[2:3], off offset:128                // 00000048457C: DC520080 1A7C0002
	global_load_b32 v25, v[2:3], off offset:256                // 000000484584: DC520100 197C0002
	global_load_b32 v24, v[2:3], off offset:384                // 00000048458C: DC520180 187C0002
	global_load_b32 v18, v[2:3], off offset:512                // 000000484594: DC520200 127C0002
	global_load_b32 v30, v[2:3], off offset:640                // 00000048459C: DC520280 1E7C0002
	global_load_b32 v31, v[2:3], off offset:768                // 0000004845A4: DC520300 1F7C0002
	global_load_b32 v33, v[2:3], off offset:896                // 0000004845AC: DC520380 217C0002
	global_load_b32 v32, v[4:5], off                           // 0000004845B4: DC520000 207C0004
	global_load_b32 v29, v[4:5], off offset:128                // 0000004845BC: DC520080 1D7C0004
	global_load_b32 v28, v[4:5], off offset:256                // 0000004845C4: DC520100 1C7C0004
	global_load_b32 v27, v[4:5], off offset:384                // 0000004845CC: DC520180 1B7C0004
	global_load_b32 v45, v[4:5], off offset:512                // 0000004845D4: DC520200 2D7C0004
	global_load_b32 v44, v[4:5], off offset:640                // 0000004845DC: DC520280 2C7C0004
	global_load_b32 v43, v[4:5], off offset:768                // 0000004845E4: DC520300 2B7C0004
	global_load_b32 v42, v[4:5], off offset:896                // 0000004845EC: DC520380 2A7C0004
	global_load_b32 v41, v[6:7], off                           // 0000004845F4: DC520000 297C0006
	global_load_b32 v36, v[6:7], off offset:128                // 0000004845FC: DC520080 247C0006
	global_load_b32 v35, v[6:7], off offset:256                // 000000484604: DC520100 237C0006
	global_load_b32 v34, v[6:7], off offset:384                // 00000048460C: DC520180 227C0006
	global_load_b32 v40, v[6:7], off offset:512                // 000000484614: DC520200 287C0006
	global_load_b32 v39, v[6:7], off offset:640                // 00000048461C: DC520280 277C0006
	global_load_b32 v38, v[6:7], off offset:768                // 000000484624: DC520300 267C0006
	global_load_b32 v37, v[6:7], off offset:896                // 00000048462C: DC520380 257C0006
	s_or_b32 exec_lo, exec_lo, s0                              // 000000484634: 8C7E007E
	v_cmp_lt_i32_e32 vcc_lo, v1, v22                           // 000000484638: 7C822D01
	s_and_saveexec_b32 s3, vcc_lo                              // 00000048463C: BE83206A
	s_cbranch_execz 93                                         // 000000484640: BFA5005D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xbb8>
	.long 0xd7010002                                           // 000000484644: D7010002
	v_cndmask_b32_e32 v0, v21, v129, vcc_lo                    // 000000484648: 02010315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000048464C: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 000000484650: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000484658: 3404029F
	.long 0xd44c0000                                           // 00000048465C: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000484660: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000484664: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 000000484668: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 000000484674: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000048467C: BF870114
	.long 0xd73c0005                                           // 000000484680: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000484684: 0202028A
	.long 0xd73c0002                                           // 000000484688: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000048468C: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000484690: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 000000484694: 30080E98
	v_bfe_i32 v7, v7, 7, 1                                     // 000000484698: D6110007 02050F07
	.long 0xd7000008                                           // 0000004846A0: D7000008
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 0000004846A4: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004846A8: BF870211
	v_add_co_ci_u32_e64 v9, null, s4, v6, s0                   // 0000004846AC: D5207C09 00020C04
	v_ashrrev_i32_e32 v6, 22, v4                               // 0000004846B4: 340C0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004846B8: BF870093
	.long 0xd7000004                                           // 0000004846BC: D7000004
	v_cndmask_b32_e32 v1, v8, v2, vcc_lo                       // 0000004846C0: 02020508
	v_add_co_ci_u32_e64 v5, null, v9, v3, s0                   // 0000004846C4: D5207C05 00020709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004846CC: BF870093
	.long 0xd7000006                                           // 0000004846D0: D7000006
	v_cndmask_b32_e32 v1, v8, v6, vcc_lo                       // 0000004846D4: 02020D08
	v_add_co_ci_u32_e64 v7, null, v9, v7, s0                   // 0000004846D8: D5207C07 00020F09
	.long 0xd7000008                                           // 0000004846E0: D7000008
	v_cndmask_b32_e32 v1, v8, v20, vcc_lo                      // 0000004846E4: 02022908
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004846E8: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v9, s0                    // 0000004846EC: D5207C09 00021280
	s_clause 0x17                                              // 0000004846F4: BF850017
	global_load_b32 v2, v[4:5], off                            // 0000004846F8: DC520000 027C0004
	global_load_b32 v121, v[4:5], off offset:128               // 000000484700: DC520080 797C0004
	global_load_b32 v118, v[4:5], off offset:256               // 000000484708: DC520100 767C0004
	global_load_b32 v115, v[4:5], off offset:384               // 000000484710: DC520180 737C0004
	global_load_b32 v112, v[4:5], off offset:512               // 000000484718: DC520200 707C0004
	global_load_b32 v109, v[4:5], off offset:640               // 000000484720: DC520280 6D7C0004
	global_load_b32 v106, v[4:5], off offset:768               // 000000484728: DC520300 6A7C0004
	global_load_b32 v83, v[4:5], off offset:896                // 000000484730: DC520380 537C0004
	global_load_b32 v3, v[6:7], off                            // 000000484738: DC520000 037C0006
	global_load_b32 v122, v[6:7], off offset:128               // 000000484740: DC520080 7A7C0006
	global_load_b32 v119, v[6:7], off offset:256               // 000000484748: DC520100 777C0006
	global_load_b32 v116, v[6:7], off offset:384               // 000000484750: DC520180 747C0006
	global_load_b32 v113, v[6:7], off offset:512               // 000000484758: DC520200 717C0006
	global_load_b32 v110, v[6:7], off offset:640               // 000000484760: DC520280 6E7C0006
	global_load_b32 v107, v[6:7], off offset:768               // 000000484768: DC520300 6B7C0006
	global_load_b32 v84, v[6:7], off offset:896                // 000000484770: DC520380 547C0006
	global_load_b32 v123, v[8:9], off                          // 000000484778: DC520000 7B7C0008
	global_load_b32 v120, v[8:9], off offset:128               // 000000484780: DC520080 787C0008
	global_load_b32 v117, v[8:9], off offset:256               // 000000484788: DC520100 757C0008
	global_load_b32 v114, v[8:9], off offset:384               // 000000484790: DC520180 727C0008
	global_load_b32 v111, v[8:9], off offset:512               // 000000484798: DC520200 6F7C0008
	global_load_b32 v108, v[8:9], off offset:640               // 0000004847A0: DC520280 6C7C0008
	global_load_b32 v105, v[8:9], off offset:768               // 0000004847A8: DC520300 697C0008
	global_load_b32 v82, v[8:9], off offset:896                // 0000004847B0: DC520380 527C0008
	s_or_b32 exec_lo, exec_lo, s3                              // 0000004847B8: 8C7E037E
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v47, 0             // 0000004847BC: CA100080 2E2E0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v49, 0             // 0000004847C4: CA100080 30300080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v51, 0             // 0000004847CC: CA100080 32320080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v54, 0             // 0000004847D4: CA100080 35360080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v56, 0             // 0000004847DC: CA100080 37380080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v58, 0             // 0000004847E4: CA100080 393A0080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v60, 0             // 0000004847EC: CA100080 3B3C0080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v62, 0             // 0000004847F4: CA100080 3D3E0080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v66, 0             // 0000004847FC: CA100080 3F420080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v68, 0             // 000000484804: CA100080 41440080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v52, 0             // 00000048480C: CA100080 43340080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v72, 0             // 000000484814: CA100080 45480080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v76, 0             // 00000048481C: CA100080 474C0080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v70, 0             // 000000484824: CA100080 4B460080
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v73, 0             // 00000048482C: CA100080 40480080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v77, 0             // 000000484834: CA100080 4A4C0080
	s_ashr_i32 s3, s2, 31                                      // 00000048483C: 86039F02
	s_and_saveexec_b32 s0, vcc_lo                              // 000000484840: BE80206A
	s_cbranch_execz 1108                                       // 000000484844: BFA50454 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d98>
	v_dual_mov_b32 v47, 0 :: v_dual_add_nc_u32 v4, -1, v0      // 000000484848: CA200080 2F0400C1
	v_dual_mov_b32 v48, 0 :: v_dual_and_b32 v5, 16, v0         // 000000484850: CA240080 30040090
	v_dual_mov_b32 v46, 0 :: v_dual_add_nc_u32 v17, 2, v1      // 000000484858: CA200080 2E100282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000484860: BF870243
	v_dual_mov_b32 v49, 0 :: v_dual_and_b32 v4, 31, v4         // 000000484864: CA240080 3104089F
	v_sub_nc_u32_e32 v78, 0, v22                               // 00000048486C: 4C9C2C80
	v_dual_mov_b32 v50, 0 :: v_dual_lshlrev_b32 v79, 2, v21    // 000000484870: CA220080 324E2A82
	v_lshl_or_b32 v80, v1, 5, v5                               // 000000484878: D6560050 04150B01
	v_dual_mov_b32 v54, 0 :: v_dual_lshlrev_b32 v81, 2, v4     // 000000484880: CA220080 36500882
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v56, 0             // 000000484888: CA100080 33380080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v58, 0             // 000000484890: CA100080 353A0080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v60, 0             // 000000484898: CA100080 373C0080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v62, 0             // 0000004848A0: CA100080 393E0080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v66, 0             // 0000004848A8: CA100080 3B420080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v68, 0             // 0000004848B0: CA100080 3D440080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v52, 0             // 0000004848B8: CA100080 3F340080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v72, 0             // 0000004848C0: CA100080 41480080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v76, 0             // 0000004848C8: CA100080 434C0080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v70, 0             // 0000004848D0: CA100080 45460080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v64, 0             // 0000004848D8: CA100080 47400080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v74, 0             // 0000004848E0: CA100080 4B4A0080
	v_mov_b32_e32 v73, 0                                       // 0000004848E8: 7E920280
	v_mov_b32_e32 v77, 0                                       // 0000004848EC: 7E9A0280
	s_mov_b32 s5, 0                                            // 0000004848F0: BE850080
	s_movk_i32 s6, 0x1eee                                      // 0000004848F4: B0061EEE
	s_branch 982                                               // 0000004848F8: BFA003D6 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c54>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000004848FC: 8C7E077E
	v_bfe_u32 v126, v123, 12, 16                               // 000000484900: D610007E 0241197B
	v_alignbit_b32 v124, v2, v3, 16                            // 000000484908: D616007C 02420702
	v_bfe_u32 v127, v123, 8, 16                                // 000000484910: D610007F 0241117B
	ds_load_b128 v[13:16], v80                                 // 000000484918: DBFC0000 0D000050
	ds_load_b128 v[1:4], v80 offset:5120                       // 000000484920: DBFC1400 01000050
	ds_load_b128 v[5:8], v80 offset:10240                      // 000000484928: DBFC2800 05000050
	ds_load_b128 v[9:12], v80 offset:15360                     // 000000484930: DBFC3C00 09000050
	v_bfe_u32 v130, v123, 4, 16                                // 000000484938: D6100082 0241097B
	.long 0xd72c007e                                           // 000000484940: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000484944: 0202FCFF 83DCD12D
	v_bfe_u32 v125, v124, 12, 16                               // 00000048494C: D610007D 0241197C
	.long 0xd72c007f                                           // 000000484954: D72C007F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 000000484958: 0202FEFF 83DCD12D
	v_bfe_u32 v128, v124, 8, 16                                // 000000484960: D6100080 0241117C
	.long 0xd72c0082                                           // 000000484968: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 00000048496C: 020304FF 83DCD12D
	v_alignbit_b32 v121, v121, v122, 16                        // 000000484974: D6160079 0242F579
	.long 0xd72c007d                                           // 00000048497C: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000484980: 0202FAFF 83DCD12D
	v_alignbit_b32 v118, v118, v119, 16                        // 000000484988: D6160076 0242EF76
	v_sad_u8 v126, v126, 0, 0x6400                             // 000000484990: D622007E 03FD017E 00006400
	.long 0xd72c0080                                           // 00000048499C: D72C0080
	v_cndmask_b32_e32 v1, 0x83dcd12d, v128, vcc_lo             // 0000004849A0: 020300FF 83DCD12D
	v_sad_u8 v127, v127, 0, 0x6400                             // 0000004849A8: D622007F 03FD017F 00006400
	v_alignbit_b32 v115, v115, v116, 16                        // 0000004849B4: D6160073 0242E973
	v_bfe_u32 v119, v118, 12, 16                               // 0000004849BC: D6100077 02411976
	v_and_b32_e32 v126, 0xffff, v126                           // 0000004849C4: 36FCFCFF 0000FFFF
	v_sad_u8 v125, v125, 0, 0x6400                             // 0000004849CC: D622007D 03FD017D 00006400
	v_alignbit_b32 v112, v112, v113, 16                        // 0000004849D8: D6160070 0242E370
	v_bfe_u32 v116, v115, 12, 16                               // 0000004849E0: D6100074 02411973
	v_sad_u8 v128, v128, 0, 0x6400                             // 0000004849E8: D6220080 03FD0180 00006400
	v_lshl_or_b32 v126, v127, 16, v126                         // 0000004849F4: D656007E 05F9217F
	v_bfe_u32 v127, v120, 12, 16                               // 0000004849FC: D610007F 02411978
	.long 0xd72c0077                                           // 000000484A04: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000484A08: 0202EEFF 83DCD12D
	.long 0xd72c0074                                           // 000000484A10: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 000000484A14: 0202E8FF 83DCD12D
	v_bfe_u32 v113, v112, 12, 16                               // 000000484A1C: D6100071 02411970
	v_pk_fma_f16 v126, v126, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000484A24: CC0E007E 0BFC0D7E 0000C931
	v_and_b32_e32 v125, 0xffff, v125                           // 000000484A30: 36FAFAFF 0000FFFF
	.long 0xd72c007f                                           // 000000484A38: D72C007F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 000000484A3C: 0202FEFF 83DCD12D
	v_alignbit_b32 v109, v109, v110, 16                        // 000000484A44: D616006D 0242DD6D
	.long 0xd72c0071                                           // 000000484A4C: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 000000484A50: 0202E2FF 83DCD12D
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000484A58: D6220077 03FD0177 00006400
	v_lshl_or_b32 v125, v128, 16, v125                         // 000000484A64: D656007D 05F52180
	v_sad_u8 v128, v130, 0, 0x6400                             // 000000484A6C: D6220080 03FD0182 00006400
	v_sad_u8 v116, v116, 0, 0x6400                             // 000000484A78: D6220074 03FD0174 00006400
	v_bfe_u32 v110, v109, 12, 16                               // 000000484A84: D610006E 0241196D
	v_sad_u8 v127, v127, 0, 0x6400                             // 000000484A8C: D622007F 03FD017F 00006400
	v_pk_fma_f16 v125, v125, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000484A98: CC0E007D 0BFC0D7D 0000C931
	v_and_b32_e32 v129, 0xffff, v124                           // 000000484AA4: 3702F8FF 0000FFFF
	v_bfe_u32 v124, v124, 4, 16                                // 000000484AAC: D610007C 0241097C
	v_sad_u8 v113, v113, 0, 0x6400                             // 000000484AB4: D6220071 03FD0171 00006400
	.long 0xd72c006e                                           // 000000484AC0: D72C006E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v110, vcc_lo             // 000000484AC4: 0202DCFF 83DCD12D
	s_waitcnt lgkmcnt(2)                                       // 000000484ACC: BF89FC27
	v_dot2acc_f32_f16 v74, v125, v1                            // 000000484AD0: 0494037D
	.long 0xd72c0081                                           // 000000484AD4: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 000000484AD8: 020302FF 83DCD12D
	.long 0xd72c007c                                           // 000000484AE0: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 000000484AE4: 0202F8FF 83DCD12D
	v_dot2acc_f32_f16 v77, v125, v13                           // 000000484AEC: 049A1B7D
	v_alignbit_b32 v106, v106, v107, 16                        // 000000484AF0: D616006A 0242D76A
	v_alignbit_b32 v83, v83, v84, 16                           // 000000484AF8: D6160053 0242A953
	v_add_nc_u32_e32 v17, 1, v17                               // 000000484B00: 4A222281
	v_sad_u8 v110, v110, 0, 0x6400                             // 000000484B04: D622006E 03FD016E 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000484B10: BF89FC07
	v_dot2acc_f32_f16 v64, v125, v9                            // 000000484B14: 0480137D
	v_sad_u8 v129, v129, 0, 0x6400                             // 000000484B18: D6220081 03FD0181 00006400
	v_sad_u8 v124, v124, 0, 0x6400                             // 000000484B24: D622007C 03FD017C 00006400
	v_bfe_u32 v107, v106, 12, 16                               // 000000484B30: D610006B 0241196A
	v_bfe_u32 v84, v83, 12, 16                                 // 000000484B38: D6100054 02411953
	v_and_b32_e32 v116, 0xffff, v116                           // 000000484B40: 36E8E8FF 0000FFFF
	v_lshlrev_b32_e32 v129, 16, v129                           // 000000484B48: 31030290
	v_and_b32_e32 v110, 0xffff, v110                           // 000000484B4C: 36DCDCFF 0000FFFF
	.long 0xd72c006b                                           // 000000484B54: D72C006B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v107, vcc_lo             // 000000484B58: 0202D6FF 83DCD12D
	.long 0xd72c0054                                           // 000000484B60: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000484B64: 0202A8FF 83DCD12D
	v_add_nc_u32_e32 v80, 32, v80                              // 000000484B6C: 4AA0A0A0
	v_and_or_b32 v124, 0xffff, v124, v129                      // 000000484B70: D657007C 0606F8FF 0000FFFF
	v_bfe_u32 v129, v120, 4, 16                                // 000000484B7C: D6100081 02410978
	s_delay_alu instid0(VALU_DEP_2)                            // 000000484B84: BF870002
	v_pk_fma_f16 v124, v124, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000484B88: CC0E007C 0BFC0D7C 0000C931
	v_and_b32_e32 v123, 0xffff, v123                           // 000000484B94: 36F6F6FF 0000FFFF
	v_dot2acc_f32_f16 v73, v125, v5                            // 000000484B9C: 04920B7D
	v_sad_u8 v107, v107, 0, 0x6400                             // 000000484BA0: D622006B 03FD016B 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000484BAC: D6220054 03FD0154 00006400
	v_dot2acc_f32_f16 v74, v124, v2                            // 000000484BB8: 0494057C
	.long 0xd72c007b                                           // 000000484BBC: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000484BC0: 0202F6FF 83DCD12D
	v_dot2acc_f32_f16 v77, v124, v14                           // 000000484BC8: 049A1D7C
	v_dot2acc_f32_f16 v64, v124, v10                           // 000000484BCC: 0480157C
	v_dot2acc_f32_f16 v73, v124, v6                            // 000000484BD0: 04920D7C
	v_bfe_u32 v124, v121, 8, 16                                // 000000484BD4: D610007C 02411179
	v_dual_dot2acc_f32_f16 v74, v126, v3 :: v_dual_and_b32 v125, 0xffff, v121// 000000484BDC: CB24077E 4A7CF2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000484BE8: BF870224
	v_dot2acc_f32_f16 v64, v126, v11                           // 000000484BEC: 0480177E
	v_sad_u8 v123, v123, 0, 0x6400                             // 000000484BF0: D622007B 03FD017B 00006400
	.long 0xd72c007c                                           // 000000484BFC: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 000000484C00: 0202F8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000484C08: BF870154
	.long 0xd72c007d                                           // 000000484C0C: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000484C10: 0202FAFF 83DCD12D
	v_and_b32_e32 v107, 0xffff, v107                           // 000000484C18: 36D6D6FF 0000FFFF
	v_and_b32_e32 v84, 0xffff, v84                             // 000000484C20: 36A8A8FF 0000FFFF
	v_lshlrev_b32_e32 v123, 16, v123                           // 000000484C28: 30F6F690
	v_sad_u8 v124, v124, 0, 0x6400                             // 000000484C2C: D622007C 03FD017C 00006400
	v_and_or_b32 v123, 0xffff, v128, v123                      // 000000484C38: D657007B 05EF00FF 0000FFFF
	v_bfe_u32 v128, v120, 8, 16                                // 000000484C44: D6100080 02411178
	v_and_b32_e32 v120, 0xffff, v120                           // 000000484C4C: 36F0F0FF 0000FFFF
	v_sad_u8 v125, v125, 0, 0x6400                             // 000000484C54: D622007D 03FD017D 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000484C60: BF870004
	v_pk_fma_f16 v122, v123, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000484C64: CC0E007A 0BFC0D7B 0000C931
	v_bfe_u32 v123, v121, 12, 16                               // 000000484C70: D610007B 02411979
	v_bfe_u32 v121, v121, 4, 16                                // 000000484C78: D6100079 02410979
	.long 0xd72c0078                                           // 000000484C80: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000484C84: 0202F0FF 83DCD12D
	.long 0xd72c0080                                           // 000000484C8C: D72C0080
	v_cndmask_b32_e32 v1, 0x83dcd12d, v128, vcc_lo             // 000000484C90: 020300FF 83DCD12D
	v_dot2acc_f32_f16 v64, v122, v12                           // 000000484C98: 0480197A
	.long 0xd72c007b                                           // 000000484C9C: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000484CA0: 0202F6FF 83DCD12D
	.long 0xd72c0079                                           // 000000484CA8: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000484CAC: 0202F2FF 83DCD12D
	v_dot2acc_f32_f16 v74, v122, v4                            // 000000484CB4: 0494097A
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000484CB8: D6220078 03FD0178 00006400
	v_dot2acc_f32_f16 v77, v126, v15                           // 000000484CC4: 049A1F7E
	v_sad_u8 v128, v128, 0, 0x6400                             // 000000484CC8: D6220080 03FD0180 00006400
	v_sad_u8 v123, v123, 0, 0x6400                             // 000000484CD4: D622007B 03FD017B 00006400
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000484CE0: D6220079 03FD0179 00006400
	v_lshlrev_b32_e32 v120, 16, v120                           // 000000484CEC: 30F0F090
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000484CF0: BF870093
	v_and_b32_e32 v123, 0xffff, v123                           // 000000484CF4: 36F6F6FF 0000FFFF
	v_lshl_or_b32 v123, v124, 16, v123                         // 000000484CFC: D656007B 05ED217C
	v_and_b32_e32 v124, 0xffff, v127                           // 000000484D04: 36F8FEFF 0000FFFF
	.long 0xd72c007f                                           // 000000484D0C: D72C007F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 000000484D10: 020302FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000484D18: BF870003
	v_pk_fma_f16 v123, v123, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000484D1C: CC0E007B 0BFC0D7B 0000C931
	v_dot2acc_f32_f16 v77, v122, v16                           // 000000484D28: 049A217A
	v_dot2acc_f32_f16 v73, v126, v7                            // 000000484D2C: 04920F7E
	v_lshl_or_b32 v124, v128, 16, v124                         // 000000484D30: D656007C 05F12180
	v_bfe_u32 v126, v117, 4, 16                                // 000000484D38: D610007E 02410975
	v_dot2acc_f32_f16 v76, v123, v1                            // 000000484D40: 0498037B
	v_lshlrev_b32_e32 v125, 16, v125                           // 000000484D44: 30FAFA90
	v_dot2acc_f32_f16 v70, v123, v13                           // 000000484D48: 048C1B7B
	v_pk_fma_f16 v124, v124, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000484D4C: CC0E007C 0BFC0D7C 0000C931
	v_dot2acc_f32_f16 v72, v123, v9                            // 000000484D58: 0490137B
	.long 0xd72c007e                                           // 000000484D5C: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000484D60: 0202FCFF 83DCD12D
	v_and_or_b32 v121, 0xffff, v121, v125                      // 000000484D68: D6570079 05F6F2FF 0000FFFF
	v_sad_u8 v125, v127, 0, 0x6400                             // 000000484D74: D622007D 03FD017F 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000484D80: BF8701A2
	v_pk_fma_f16 v121, v121, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000484D84: CC0E0079 0BFC0D79 0000C931
	v_dot2acc_f32_f16 v73, v122, v8                            // 000000484D90: 0492117A
	v_and_or_b32 v120, 0xffff, v125, v120                      // 000000484D94: D6570078 05E2FAFF 0000FFFF
	v_bfe_u32 v122, v118, 8, 16                                // 000000484DA0: D610007A 02411176
	v_bfe_u32 v125, v117, 8, 16                                // 000000484DA8: D610007D 02411175
	v_dual_dot2acc_f32_f16 v70, v121, v14 :: v_dual_dot2acc_f32_f16 v75, v123, v5// 000000484DB0: CB181D79 464A0B7B
	v_dot2acc_f32_f16 v76, v121, v2                            // 000000484DB8: 04980579
	v_pk_fma_f16 v120, v120, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000484DBC: CC0E0078 0BFC0D78 0000C931
	v_dot2acc_f32_f16 v72, v121, v10                           // 000000484DC8: 04901579
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000484DCC: BF870214
	v_dual_dot2acc_f32_f16 v70, v124, v15 :: v_dual_dot2acc_f32_f16 v75, v121, v6// 000000484DD0: CB181F7C 464A0D79
	v_dual_dot2acc_f32_f16 v76, v124, v3 :: v_dual_and_b32 v121, 0xffff, v118// 000000484DD8: CB24077C 4C78ECFF 0000FFFF
	v_bfe_u32 v118, v118, 4, 16                                // 000000484DE4: D6100076 02410976
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000484DEC: BF870213
	v_dot2acc_f32_f16 v70, v120, v16                           // 000000484DF0: 048C2178
	v_dot2acc_f32_f16 v75, v124, v7                            // 000000484DF4: 04960F7C
	v_bfe_u32 v123, v117, 12, 16                               // 000000484DF8: D610007B 02411975
	.long 0xd72c0079                                           // 000000484E00: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000484E04: 0202F2FF 83DCD12D
	.long 0xd72c0076                                           // 000000484E0C: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000484E10: 0202ECFF 83DCD12D
	.long 0xd72c007a                                           // 000000484E18: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 000000484E1C: 0202F4FF 83DCD12D
	v_dot2acc_f32_f16 v75, v120, v8                            // 000000484E24: 04961178
	v_dot2acc_f32_f16 v72, v124, v11                           // 000000484E28: 0490177C
	.long 0xd72c007b                                           // 000000484E2C: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000484E30: 0202F6FF 83DCD12D
	v_dual_dot2acc_f32_f16 v76, v120, v4 :: v_dual_and_b32 v117, 0xffff, v117// 000000484E38: CB240978 4C74EAFF 0000FFFF
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000484E44: D6220079 03FD0179 00006400
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000484E50: D6220076 03FD0176 00006400
	v_sad_u8 v122, v122, 0, 0x6400                             // 000000484E5C: D622007A 03FD017A 00006400
	.long 0xd72c007d                                           // 000000484E68: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000484E6C: 0202FAFF 83DCD12D
	.long 0xd72c0075                                           // 000000484E74: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000484E78: 0202EAFF 83DCD12D
	v_lshlrev_b32_e32 v121, 16, v121                           // 000000484E80: 30F2F290
	v_sad_u8 v123, v123, 0, 0x6400                             // 000000484E84: D622007B 03FD017B 00006400
	v_dot2acc_f32_f16 v72, v120, v12                           // 000000484E90: 04901978
	v_and_b32_e32 v120, 0xffff, v115                           // 000000484E94: 36F0E6FF 0000FFFF
	v_bfe_u32 v124, v114, 8, 16                                // 000000484E9C: D610007C 02411172
	v_and_or_b32 v118, 0xffff, v118, v121                      // 000000484EA4: D6570076 05E6ECFF 0000FFFF
	v_sad_u8 v117, v117, 0, 0x6400                             // 000000484EB0: D6220075 03FD0175 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000484EBC: BF870214
	.long 0xd72c0078                                           // 000000484EC0: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000484EC4: 0202F0FF 83DCD12D
	.long 0xd72c007c                                           // 000000484ECC: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 000000484ED0: 0202F8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000484ED8: BF8700A4
	v_pk_fma_f16 v118, v118, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000484EDC: CC0E0076 0BFC0D76 0000C931
	v_and_b32_e32 v119, 0xffff, v119                           // 000000484EE8: 36EEEEFF 0000FFFF
	v_lshl_or_b32 v119, v122, 16, v119                         // 000000484EF0: D6560077 05DD217A
	v_sad_u8 v122, v125, 0, 0x6400                             // 000000484EF8: D622007A 03FD017D 00006400
	v_bfe_u32 v125, v114, 4, 16                                // 000000484F04: D610007D 02410972
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000484F0C: D6220078 03FD0178 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000484F18: BF870234
	v_pk_fma_f16 v119, v119, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000484F1C: CC0E0077 0BFC0D77 0000C931
	v_and_b32_e32 v121, 0xffff, v123                           // 000000484F28: 36F2F6FF 0000FFFF
	v_sad_u8 v123, v126, 0, 0x6400                             // 000000484F30: D622007B 03FD017E 00006400
	v_lshlrev_b32_e32 v120, 16, v120                           // 000000484F3C: 30F0F090
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000484F40: BF870214
	v_dot2acc_f32_f16 v52, v119, v13                           // 000000484F44: 04681B77
	v_lshl_or_b32 v121, v122, 16, v121                         // 000000484F48: D6560079 05E5217A
	v_dot2acc_f32_f16 v71, v119, v1                            // 000000484F50: 048E0377
	v_bfe_u32 v122, v115, 8, 16                                // 000000484F54: D610007A 02411173
	v_bfe_u32 v115, v115, 4, 16                                // 000000484F5C: D6100073 02410973
	v_dot2acc_f32_f16 v52, v118, v14                           // 000000484F64: 04681D76
	v_pk_fma_f16 v121, v121, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000484F68: CC0E0079 0BFC0D79 0000C931
	v_lshlrev_b32_e32 v117, 16, v117                           // 000000484F74: 30EAEA90
	v_dot2acc_f32_f16 v71, v118, v2                            // 000000484F78: 048E0576
	.long 0xd72c007a                                           // 000000484F7C: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 000000484F80: 0202F4FF 83DCD12D
	.long 0xd72c0073                                           // 000000484F88: D72C0073
	v_cndmask_b32_e32 v1, 0x83dcd12d, v115, vcc_lo             // 000000484F8C: 0202E6FF 83DCD12D
	v_dot2acc_f32_f16 v52, v121, v15                           // 000000484F94: 04681F79
	v_and_or_b32 v117, 0xffff, v123, v117                      // 000000484F98: D6570075 05D6F6FF 0000FFFF
	v_bfe_u32 v123, v114, 12, 16                               // 000000484FA4: D610007B 02411972
	v_dual_dot2acc_f32_f16 v71, v121, v3 :: v_dual_and_b32 v114, 0xffff, v114// 000000484FAC: CB240779 4772E4FF 0000FFFF
	v_dot2acc_f32_f16 v68, v119, v9                            // 000000484FB8: 04881377
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000484FBC: BF870254
	v_pk_fma_f16 v117, v117, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000484FC0: CC0E0075 0BFC0D75 0000C931
	v_dot2acc_f32_f16 v69, v119, v5                            // 000000484FCC: 048A0B77
	.long 0xd72c007b                                           // 000000484FD0: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000484FD4: 0202F6FF 83DCD12D
	v_sad_u8 v122, v122, 0, 0x6400                             // 000000484FDC: D622007A 03FD017A 00006400
	.long 0xd72c0072                                           // 000000484FE8: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 000000484FEC: 0202E4FF 83DCD12D
	v_dual_dot2acc_f32_f16 v52, v117, v16 :: v_dual_dot2acc_f32_f16 v69, v118, v6// 000000484FF4: CB182175 34440D76
	v_sad_u8 v115, v115, 0, 0x6400                             // 000000484FFC: D6220073 03FD0173 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000485008: BF870004
	v_lshl_or_b32 v116, v122, 16, v116                         // 00000048500C: D6560074 05D1217A
	v_dot2acc_f32_f16 v71, v117, v4                            // 000000485014: 048E0975
	v_sad_u8 v123, v123, 0, 0x6400                             // 000000485018: D622007B 03FD017B 00006400
	v_dot2acc_f32_f16 v69, v121, v7                            // 000000485024: 048A0F79
	.long 0xd72c0077                                           // 000000485028: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 00000048502C: 0202FAFF 83DCD12D
	v_and_or_b32 v115, 0xffff, v115, v120                      // 000000485034: D6570073 05E2E6FF 0000FFFF
	v_sad_u8 v122, v124, 0, 0x6400                             // 000000485040: D622007A 03FD017C 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000048504C: BF870004
	v_dual_dot2acc_f32_f16 v69, v117, v8 :: v_dual_and_b32 v120, 0xffff, v123// 000000485050: CB241175 4578F6FF 0000FFFF
	v_sad_u8 v114, v114, 0, 0x6400                             // 00000048505C: D6220072 03FD0172 00006400
	v_pk_fma_f16 v116, v116, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000485068: CC0E0074 0BFC0D74 0000C931
	v_dot2acc_f32_f16 v68, v118, v10                           // 000000485074: 04881576
	v_pk_fma_f16 v115, v115, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000485078: CC0E0073 0BFC0D73 0000C931
	v_lshl_or_b32 v118, v122, 16, v120                         // 000000485084: D6560076 05E1217A
	v_sad_u8 v119, v119, 0, 0x6400                             // 00000048508C: D6220077 03FD0177 00006400
	v_dual_dot2acc_f32_f16 v65, v116, v5 :: v_dual_lshlrev_b32 v114, 16, v114// 000000485098: CB220B74 4172E490
	v_dot2acc_f32_f16 v67, v116, v13                           // 0000004850A0: 04861B74
	v_dot2acc_f32_f16 v66, v116, v1                            // 0000004850A4: 04840374
	v_pk_fma_f16 v118, v118, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000004850A8: CC0E0076 0BFC0D76 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004850B4: BF870244
	v_and_or_b32 v114, 0xffff, v119, v114                      // 0000004850B8: D6570072 05CAEEFF 0000FFFF
	v_dual_dot2acc_f32_f16 v68, v121, v11 :: v_dual_dot2acc_f32_f16 v65, v115, v6// 0000004850C4: CB181779 44400D73
	v_dot2acc_f32_f16 v67, v115, v14                           // 0000004850CC: 04861D73
	v_dot2acc_f32_f16 v66, v115, v2                            // 0000004850D0: 04840573
	v_pk_fma_f16 v114, v114, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000004850D4: CC0E0072 0BFC0D72 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004850E0: BF870214
	v_dual_dot2acc_f32_f16 v68, v117, v12 :: v_dual_dot2acc_f32_f16 v65, v118, v7// 0000004850E4: CB181975 44400F76
	v_dot2acc_f32_f16 v67, v118, v15                           // 0000004850EC: 04861F76
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004850F0: BF870244
	v_dual_dot2acc_f32_f16 v66, v118, v3 :: v_dual_and_b32 v117, 0xffff, v112// 0000004850F4: CB240776 4274E0FF 0000FFFF
	v_dot2acc_f32_f16 v63, v116, v9                            // 000000485100: 047E1374
	v_bfe_u32 v116, v112, 8, 16                                // 000000485104: D6100074 02411170
	v_bfe_u32 v112, v112, 4, 16                                // 00000048510C: D6100070 02410970
	v_dot2acc_f32_f16 v66, v114, v4                            // 000000485114: 04840972
	.long 0xd72c0075                                           // 000000485118: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 00000048511C: 0202EAFF 83DCD12D
	v_dot2acc_f32_f16 v63, v115, v10                           // 000000485124: 047E1573
	v_bfe_u32 v115, v111, 12, 16                               // 000000485128: D6100073 0241196F
	.long 0xd72c0070                                           // 000000485130: D72C0070
	v_cndmask_b32_e32 v1, 0x83dcd12d, v112, vcc_lo             // 000000485134: 0202E0FF 83DCD12D
	.long 0xd72c0074                                           // 00000048513C: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 000000485140: 0202E8FF 83DCD12D
	v_bfe_u32 v119, v111, 8, 16                                // 000000485148: D6100077 0241116F
	v_bfe_u32 v120, v111, 4, 16                                // 000000485150: D6100078 0241096F
	.long 0xd72c0073                                           // 000000485158: D72C0073
	v_cndmask_b32_e32 v1, 0x83dcd12d, v115, vcc_lo             // 00000048515C: 0202E6FF 83DCD12D
	v_sad_u8 v117, v117, 0, 0x6400                             // 000000485164: D6220075 03FD0175 00006400
	v_mov_b32_e32 v122, v29                                    // 000000485170: 7EF4031D
	.long 0xd72c0077                                           // 000000485174: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000485178: 0202EEFF 83DCD12D
	v_sad_u8 v112, v112, 0, 0x6400                             // 000000485180: D6220070 03FD0170 00006400
	v_sad_u8 v116, v116, 0, 0x6400                             // 00000048518C: D6220074 03FD0174 00006400
	v_lshlrev_b32_e32 v117, 16, v117                           // 000000485198: 30EAEA90
	v_mov_b32_e32 v121, v26                                    // 00000048519C: 7EF2031A
	v_sad_u8 v115, v115, 0, 0x6400                             // 0000004851A0: D6220073 03FD0173 00006400
	v_mov_b32_e32 v123, v41                                    // 0000004851AC: 7EF60329
	v_mov_b32_e32 v29, v87                                     // 0000004851B0: 7E3A0357
	v_and_or_b32 v112, 0xffff, v112, v117                      // 0000004851B4: D6570070 05D6E0FF 0000FFFF
	s_waitcnt vmcnt(6)                                         // 0000004851C0: BF891BF7
	v_dual_mov_b32 v26, v91 :: v_dual_and_b32 v115, 0xffff, v115// 0000004851C4: CA24015B 1A72E6FF 0000FFFF
	v_mov_b32_e32 v41, v88                                     // 0000004851D0: 7E520358
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004851D4: BF8700A3
	v_pk_fma_f16 v112, v112, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000004851D8: CC0E0070 0BFC0D70 0000C931
	v_and_b32_e32 v113, 0xffff, v113                           // 0000004851E4: 36E2E2FF 0000FFFF
	v_lshl_or_b32 v113, v116, 16, v113                         // 0000004851EC: D6560071 05C52174
	v_sad_u8 v116, v119, 0, 0x6400                             // 0000004851F4: D6220074 03FD0177 00006400
	v_dual_mov_b32 v119, v28 :: v_dual_mov_b32 v28, v86        // 000000485200: CA10011C 771C0156
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000485208: BF870223
	v_pk_fma_f16 v113, v113, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000048520C: CC0E0071 0BFC0D71 0000C931
	v_dot2acc_f32_f16 v65, v114, v8                            // 000000485218: 04821172
	v_lshl_or_b32 v115, v116, 16, v115                         // 00000048521C: D6560073 05CD2174
	v_dot2acc_f32_f16 v67, v114, v16                           // 000000485224: 04862172
	v_bfe_u32 v116, v108, 12, 16                               // 000000485228: D6100074 0241196C
	v_dot2acc_f32_f16 v60, v113, v5                            // 000000485230: 04780B71
	v_dot2acc_f32_f16 v62, v113, v13                           // 000000485234: 047C1B71
	v_pk_fma_f16 v115, v115, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000485238: CC0E0073 0BFC0D73 0000C931
	v_dot2acc_f32_f16 v59, v113, v9                            // 000000485244: 04761371
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000485248: BF870244
	v_dual_dot2acc_f32_f16 v60, v112, v6 :: v_dual_and_b32 v111, 0xffff, v111// 00000048524C: CB240D70 3C6EDEFF 0000FFFF
	v_dot2acc_f32_f16 v61, v113, v1                            // 000000485258: 047A0371
	v_bfe_u32 v113, v109, 8, 16                                // 00000048525C: D6100071 0241116D
	v_dot2acc_f32_f16 v62, v112, v14                           // 000000485264: 047C1D70
	.long 0xd72c006f                                           // 000000485268: D72C006F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 00000048526C: 0202DEFF 83DCD12D
	.long 0xd72c0074                                           // 000000485274: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 000000485278: 0202E8FF 83DCD12D
	v_dot2acc_f32_f16 v60, v115, v7                            // 000000485280: 04780F73
	.long 0xd72c0071                                           // 000000485284: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 000000485288: 0202E2FF 83DCD12D
	v_dot2acc_f32_f16 v62, v115, v15                           // 000000485290: 047C1F73
	v_dot2acc_f32_f16 v63, v118, v11                           // 000000485294: 047E1776
	.long 0xd72c0076                                           // 000000485298: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 00000048529C: 0202F0FF 83DCD12D
	v_dot2acc_f32_f16 v61, v112, v2                            // 0000004852A4: 047A0570
	v_sad_u8 v111, v111, 0, 0x6400                             // 0000004852A8: D622006F 03FD016F 00006400
	v_sad_u8 v116, v116, 0, 0x6400                             // 0000004852B4: D6220074 03FD0174 00006400
	v_mov_b32_e32 v120, v36                                    // 0000004852C0: 7EF00324
	v_sad_u8 v113, v113, 0, 0x6400                             // 0000004852C4: D6220071 03FD0171 00006400
	v_mov_b32_e32 v36, v87                                     // 0000004852D0: 7E480357
	v_sad_u8 v117, v118, 0, 0x6400                             // 0000004852D4: D6220075 03FD0176 00006400
	v_bfe_u32 v118, v108, 4, 16                                // 0000004852E0: D6100076 0241096C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004852E8: BF870124
	v_lshl_or_b32 v110, v113, 16, v110                         // 0000004852EC: D656006E 05B92171
	v_and_b32_e32 v116, 0xffff, v116                           // 0000004852F4: 36E8E8FF 0000FFFF
	v_pk_fma_f16 v110, v110, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000004852FC: CC0E006E 0BFC0D6E 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000485308: BF870091
	v_dual_dot2acc_f32_f16 v58, v110, v13 :: v_dual_lshlrev_b32 v111, 16, v111// 00000048530C: CB221B6E 3A6EDE90
	v_and_or_b32 v111, 0xffff, v117, v111                      // 000000485314: D657006F 05BEEAFF 0000FFFF
	v_bfe_u32 v117, v108, 8, 16                                // 000000485320: D6100075 0241116C
	v_dual_dot2acc_f32_f16 v61, v115, v3 :: v_dual_and_b32 v108, 0xffff, v108// 000000485328: CB240773 3D6CD8FF 0000FFFF
	v_dot2acc_f32_f16 v56, v110, v5                            // 000000485334: 04700B6E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000485338: BF870214
	v_pk_fma_f16 v111, v111, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000048533C: CC0E006F 0BFC0D6F 0000C931
	.long 0xd72c0075                                           // 000000485348: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 00000048534C: 0202EAFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000485354: BF870194
	.long 0xd72c006c                                           // 000000485358: D72C006C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v108, vcc_lo             // 00000048535C: 0202D8FF 83DCD12D
	v_dot2acc_f32_f16 v62, v111, v16                           // 000000485364: 047C216F
	v_dual_dot2acc_f32_f16 v63, v114, v12 :: v_dual_and_b32 v114, 0xffff, v109// 000000485368: CB241972 3F72DAFF 0000FFFF
	v_bfe_u32 v109, v109, 4, 16                                // 000000485374: D610006D 0241096D
	v_sad_u8 v117, v117, 0, 0x6400                             // 00000048537C: D6220075 03FD0175 00006400
	v_sad_u8 v108, v108, 0, 0x6400                             // 000000485388: D622006C 03FD016C 00006400
	v_dot2acc_f32_f16 v59, v112, v10                           // 000000485394: 04761570
	.long 0xd72c0072                                           // 000000485398: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 00000048539C: 0202E4FF 83DCD12D
	.long 0xd72c006d                                           // 0000004853A4: D72C006D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v109, vcc_lo             // 0000004853A8: 0202DAFF 83DCD12D
	v_lshl_or_b32 v112, v117, 16, v116                         // 0000004853B0: D6560070 05D12175
	v_dot2acc_f32_f16 v61, v111, v4                            // 0000004853B8: 047A096F
	v_lshlrev_b32_e32 v108, 16, v108                           // 0000004853BC: 30D8D890
	v_dot2acc_f32_f16 v60, v111, v8                            // 0000004853C0: 0478116F
	v_mov_b32_e32 v116, v27                                    // 0000004853C4: 7EE8031B
	v_pk_fma_f16 v112, v112, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000004853C8: CC0E0070 0BFC0D70 0000C931
	v_sad_u8 v114, v114, 0, 0x6400                             // 0000004853D4: D6220072 03FD0172 00006400
	v_sad_u8 v109, v109, 0, 0x6400                             // 0000004853E0: D622006D 03FD016D 00006400
	v_mov_b32_e32 v117, v35                                    // 0000004853EC: 7EEA0323
	v_mov_b32_e32 v27, v85                                     // 0000004853F0: 7E360355
	v_mov_b32_e32 v35, v86                                     // 0000004853F4: 7E460356
	v_lshlrev_b32_e32 v113, 16, v114                           // 0000004853F8: 30E2E490
	.long 0xd72c0072                                           // 0000004853FC: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000485400: 0202ECFF 83DCD12D
	s_waitcnt vmcnt(5)                                         // 000000485408: BF8917F7
	v_dual_mov_b32 v118, v25 :: v_dual_mov_b32 v25, v90        // 00000048540C: CA100119 7618015A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000485414: BF870193
	v_and_or_b32 v109, 0xffff, v109, v113                      // 000000485418: D657006D 05C6DAFF 0000FFFF
	v_sad_u8 v113, v114, 0, 0x6400                             // 000000485424: D6220071 03FD0172 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000485430: BF870002
	v_pk_fma_f16 v109, v109, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000485434: CC0E006D 0BFC0D6D 0000C931
	v_dot2acc_f32_f16 v57, v110, v1                            // 000000485440: 0472036E
	v_mov_b32_e32 v114, v34                                    // 000000485444: 7EE40322
	v_mov_b32_e32 v34, v85                                     // 000000485448: 7E440355
	v_and_or_b32 v108, 0xffff, v113, v108                      // 00000048544C: D657006C 05B2E2FF 0000FFFF
	v_dot2acc_f32_f16 v58, v109, v14                           // 000000485458: 04741D6D
	v_dot2acc_f32_f16 v56, v109, v6                            // 00000048545C: 04700D6D
	v_dot2acc_f32_f16 v57, v109, v2                            // 000000485460: 0472056D
	v_bfe_u32 v113, v105, 4, 16                                // 000000485464: D6100071 02410969
	v_pk_fma_f16 v108, v108, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000048546C: CC0E006C 0BFC0D6C 0000C931
	v_dot2acc_f32_f16 v58, v112, v15                           // 000000485478: 04741F70
	v_dot2acc_f32_f16 v59, v115, v11                           // 00000048547C: 04761773
	v_dual_dot2acc_f32_f16 v56, v112, v7 :: v_dual_dot2acc_f32_f16 v55, v110, v9// 000000485480: CB180F70 3836136E
	v_and_b32_e32 v110, 0xffff, v106                           // 000000485488: 36DCD4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000485490: BF870214
	v_dot2acc_f32_f16 v58, v108, v16                           // 000000485494: 0474216C
	v_dot2acc_f32_f16 v59, v111, v12                           // 000000485498: 0476196F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000048549C: BF870004
	v_dual_dot2acc_f32_f16 v56, v108, v8 :: v_dual_dot2acc_f32_f16 v55, v109, v10// 0000004854A0: CB18116C 3836156D
	v_bfe_u32 v109, v106, 8, 16                                // 0000004854A8: D610006D 0241116A
	v_bfe_u32 v106, v106, 4, 16                                // 0000004854B0: D610006A 0241096A
	.long 0xd72c006e                                           // 0000004854B8: D72C006E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v110, vcc_lo             // 0000004854BC: 0202DCFF 83DCD12D
	v_bfe_u32 v111, v105, 12, 16                               // 0000004854C4: D610006F 02411969
	v_mov_b32_e32 v115, v24                                    // 0000004854CC: 7EE60318
	.long 0xd72c006d                                           // 0000004854D0: D72C006D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v109, vcc_lo             // 0000004854D4: 0202DAFF 83DCD12D
	.long 0xd72c006a                                           // 0000004854DC: D72C006A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v106, vcc_lo             // 0000004854E0: 0202D4FF 83DCD12D
	s_waitcnt vmcnt(4)                                         // 0000004854E8: BF8913F7
	v_mov_b32_e32 v24, v89                                     // 0000004854EC: 7E300359
	.long 0xd72c006f                                           // 0000004854F0: D72C006F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 0000004854F4: 0202DEFF 83DCD12D
	v_sad_u8 v110, v110, 0, 0x6400                             // 0000004854FC: D622006E 03FD016E 00006400
	v_dot2acc_f32_f16 v57, v112, v3                            // 000000485508: 04720770
	v_sad_u8 v109, v109, 0, 0x6400                             // 00000048550C: D622006D 03FD016D 00006400
	v_sad_u8 v106, v106, 0, 0x6400                             // 000000485518: D622006A 03FD016A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000485524: BF870224
	v_lshlrev_b32_e32 v110, 16, v110                           // 000000485528: 30DCDC90
	v_sad_u8 v111, v111, 0, 0x6400                             // 00000048552C: D622006F 03FD016F 00006400
	v_lshl_or_b32 v107, v109, 16, v107                         // 000000485538: D656006B 05AD216D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000485540: BF870113
	v_and_or_b32 v106, 0xffff, v106, v110                      // 000000485544: D657006A 05BAD4FF 0000FFFF
	v_pk_fma_f16 v107, v107, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000485550: CC0E006B 0BFC0D6B 0000C931
	v_dot2acc_f32_f16 v57, v108, v4                            // 00000048555C: 0472096C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000485560: BF870193
	v_pk_fma_f16 v106, v106, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000485564: CC0E006A 0BFC0D6A 0000C931
	v_dual_dot2acc_f32_f16 v54, v107, v13 :: v_dual_dot2acc_f32_f16 v55, v112, v11// 000000485570: CB181B6B 36361770
	v_bfe_u32 v112, v105, 8, 16                                // 000000485578: D6100070 02411169
	v_dot2acc_f32_f16 v50, v107, v9                            // 000000485580: 0464136B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000485584: BF870213
	v_dual_dot2acc_f32_f16 v54, v106, v14 :: v_dual_and_b32 v105, 0xffff, v105// 000000485588: CB241D6A 3668D2FF 0000FFFF
	v_dot2acc_f32_f16 v55, v108, v12                           // 000000485594: 046E196C
	.long 0xd72c006c                                           // 000000485598: D72C006C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 00000048559C: 0202E2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004855A4: BF870214
	v_dot2acc_f32_f16 v50, v106, v10                           // 0000004855A8: 0464156A
	.long 0xd72c0069                                           // 0000004855AC: D72C0069
	v_cndmask_b32_e32 v1, 0x83dcd12d, v105, vcc_lo             // 0000004855B0: 0202D2FF 83DCD12D
	.long 0xd72c0070                                           // 0000004855B8: D72C0070
	v_cndmask_b32_e32 v1, 0x83dcd12d, v112, vcc_lo             // 0000004855BC: 0202E0FF 83DCD12D
	v_dot2acc_f32_f16 v53, v107, v1                            // 0000004855C4: 046A036B
	v_dot2acc_f32_f16 v51, v107, v5                            // 0000004855C8: 04660B6B
	v_and_b32_e32 v107, 0xffff, v83                            // 0000004855CC: 36D6A6FF 0000FFFF
	v_mov_b32_e32 v113, v103                                   // 0000004855D4: 7EE20367
	v_sad_u8 v108, v108, 0, 0x6400                             // 0000004855D8: D622006C 03FD016C 00006400
	v_sad_u8 v105, v105, 0, 0x6400                             // 0000004855E4: D6220069 03FD0169 00006400
	v_sad_u8 v110, v112, 0, 0x6400                             // 0000004855F0: D622006E 03FD0170 00006400
	.long 0xd72c006b                                           // 0000004855FC: D72C006B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v107, vcc_lo             // 000000485600: 0202D6FF 83DCD12D
	v_dual_dot2acc_f32_f16 v51, v106, v6 :: v_dual_mov_b32 v112, v104// 000000485608: CB100D6A 33700168
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000485610: BF870094
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000485614: 30D2D290
	v_and_or_b32 v105, 0xffff, v108, v105                      // 000000485618: D6570069 05A6D8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000485624: BF870114
	v_sad_u8 v107, v107, 0, 0x6400                             // 000000485628: D622006B 03FD016B 00006400
	v_pk_fma_f16 v105, v105, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000485634: CC0E0069 0BFC0D69 0000C931
	v_and_b32_e32 v109, 0xffff, v111                           // 000000485640: 36DADEFF 0000FFFF
	v_bfe_u32 v111, v82, 4, 16                                 // 000000485648: D610006F 02410952
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000485650: BF870122
	v_lshl_or_b32 v109, v110, 16, v109                         // 000000485654: D656006D 05B5216E
	v_bfe_u32 v110, v82, 8, 16                                 // 00000048565C: D610006E 02411152
	v_pk_fma_f16 v108, v109, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000485664: CC0E006C 0BFC0D6D 0000C931
	v_bfe_u32 v109, v82, 12, 16                                // 000000485670: D610006D 02411952
	v_and_b32_e32 v82, 0xffff, v82                             // 000000485678: 36A4A4FF 0000FFFF
	v_dot2acc_f32_f16 v53, v106, v2                            // 000000485680: 046A056A
	v_bfe_u32 v106, v83, 8, 16                                 // 000000485684: D610006A 02411153
	v_bfe_u32 v83, v83, 4, 16                                  // 00000048568C: D6100053 02410953
	.long 0xd72c006d                                           // 000000485694: D72C006D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v109, vcc_lo             // 000000485698: 0202DAFF 83DCD12D
	.long 0xd72c006e                                           // 0000004856A0: D72C006E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v110, vcc_lo             // 0000004856A4: 0202DCFF 83DCD12D
	.long 0xd72c0052                                           // 0000004856AC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 0000004856B0: 0202A4FF 83DCD12D
	.long 0xd72c006a                                           // 0000004856B8: D72C006A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v106, vcc_lo             // 0000004856BC: 0202D4FF 83DCD12D
	.long 0xd72c0053                                           // 0000004856C4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000004856C8: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v54, v108, v15                           // 0000004856D0: 046C1F6C
	v_dot2acc_f32_f16 v50, v108, v11                           // 0000004856D4: 0464176C
	v_sad_u8 v109, v109, 0, 0x6400                             // 0000004856D8: D622006D 03FD016D 00006400
	v_sad_u8 v110, v110, 0, 0x6400                             // 0000004856E4: D622006E 03FD016E 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 0000004856F0: D6220052 03FD0152 00006400
	v_sad_u8 v106, v106, 0, 0x6400                             // 0000004856FC: D622006A 03FD016A 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000485708: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v54, v105, v16                           // 000000485714: 046C2169
	v_dot2acc_f32_f16 v50, v105, v12                           // 000000485718: 04641969
	v_lshlrev_b32_e32 v82, 16, v82                             // 00000048571C: 30A4A490
	v_lshl_or_b32 v84, v106, 16, v84                           // 000000485720: D6560054 0551216A
	v_lshlrev_b32_e32 v106, 16, v107                           // 000000485728: 30D4D690
	.long 0xd72c006b                                           // 00000048572C: D72C006B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 000000485730: 0202DEFF 83DCD12D
	v_dot2acc_f32_f16 v53, v108, v3                            // 000000485738: 046A076C
	v_mov_b32_e32 v111, v102                                   // 00000048573C: 7EDE0366
	v_pk_fma_f16 v84, v84, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000485740: CC0E0054 0BFC0D54 0000C931
	v_and_or_b32 v83, 0xffff, v83, v106                        // 00000048574C: D6570053 05AAA6FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000485758: BF870112
	v_dual_dot2acc_f32_f16 v53, v105, v4 :: v_dual_dot2acc_f32_f16 v46, v84, v9// 00000048575C: CB180969 352E1354
	v_pk_fma_f16 v83, v83, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000485764: CC0E0053 0BFC0D53 0000C931
	v_dot2acc_f32_f16 v48, v84, v1                             // 000000485770: 04600354
	v_dot2acc_f32_f16 v51, v108, v7                            // 000000485774: 04660F6C
	v_sad_u8 v107, v107, 0, 0x6400                             // 000000485778: D622006B 03FD016B 00006400
	v_mov_b32_e32 v108, v99                                    // 000000485784: 7ED80363
	v_dot2acc_f32_f16 v46, v83, v10                            // 000000485788: 045C1553
	v_dual_dot2acc_f32_f16 v48, v83, v2 :: v_dual_and_b32 v109, 0xffff, v109// 00000048578C: CB240553 306CDAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v51, v105, v8 :: v_dual_add_nc_u32 v2, v78, v17// 000000485798: CB201169 3302234E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004857A0: BF8701A2
	v_lshl_or_b32 v106, v110, 16, v109                         // 0000004857A4: D656006A 05B5216E
	v_mov_b32_e32 v109, v101                                   // 0000004857AC: 7EDA0365
	v_cmp_eq_u32_e32 vcc_lo, 2, v2                             // 0000004857B0: 7C940482
	v_dual_mov_b32 v2, v23 :: v_dual_mov_b32 v23, v92          // 0000004857B4: CA100117 0216015C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000004857BC: BF870254
	v_pk_fma_f16 v105, v106, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000004857C0: CC0E0069 0BFC0D6A 0000C931
	v_dot2acc_f32_f16 v49, v84, v13                            // 0000004857CC: 04621B54
	v_and_or_b32 v13, 0xffff, v107, v82                        // 0000004857D0: D657000D 054AD6FF 0000FFFF
	v_mov_b32_e32 v110, v100                                   // 0000004857DC: 7EDC0364
	v_mov_b32_e32 v106, v98                                    // 0000004857E0: 7ED40362
	v_dual_dot2acc_f32_f16 v46, v105, v11 :: v_dual_dot2acc_f32_f16 v49, v83, v14// 0000004857E4: CB181769 2E301D53
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004857EC: BF870234
	v_pk_fma_f16 v1, v13, s6, 0xc931 op_sel_hi:[1,0,0]         // 0000004857F0: CC0E0001 0BFC0D0D 0000C931
	v_dual_dot2acc_f32_f16 v47, v84, v5 :: v_dual_dot2acc_f32_f16 v48, v105, v3// 0000004857FC: CB180B54 2F300769
	v_mov_b32_e32 v3, v32                                      // 000000485804: 7E060320
	v_dot2acc_f32_f16 v49, v105, v15                           // 000000485808: 04621F69
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000048580C: BF870213
	v_dual_dot2acc_f32_f16 v46, v1, v12 :: v_dual_dot2acc_f32_f16 v47, v83, v6// 000000485810: CB181901 2E2E0D53
	v_dot2acc_f32_f16 v48, v1, v4                              // 000000485818: 04600901
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000048581C: BF870223
	v_dual_mov_b32 v32, v88 :: v_dual_dot2acc_f32_f16 v49, v1, v16// 000000485820: CA180158 20302101
	v_mov_b32_e32 v107, v97                                    // 000000485828: 7ED60361
	v_dot2acc_f32_f16 v47, v105, v7                            // 00000048582C: 045E0F69
	v_mov_b32_e32 v105, v96                                    // 000000485830: 7ED20360
	v_dual_mov_b32 v83, v95 :: v_dual_mov_b32 v84, v94         // 000000485834: CA10015F 5354015E
	v_mov_b32_e32 v82, v93                                     // 00000048583C: 7EA4035D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000485840: BF8704A4
	v_dot2acc_f32_f16 v47, v1, v8                              // 000000485844: 045E1101
	s_or_b32 s5, vcc_lo, s5                                    // 000000485848: 8C05056A
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000048584C: 917E057E
	s_cbranch_execz 80                                         // 000000485850: BFA50050 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d94>
	s_waitcnt vmcnt(3)                                         // 000000485854: BF890FF7
	v_dual_mov_b32 v104, v18 :: v_dual_mov_b32 v103, v45       // 000000485858: CA100112 6866012D
	s_waitcnt vmcnt(2)                                         // 000000485860: BF890BF7
	v_dual_mov_b32 v102, v40 :: v_dual_mov_b32 v101, v30       // 000000485864: CA100128 6664011E
	s_waitcnt vmcnt(2)                                         // 00000048586C: BF890BF7
	v_dual_mov_b32 v100, v44 :: v_dual_mov_b32 v99, v39        // 000000485870: CA10012C 64620127
	s_waitcnt vmcnt(0)                                         // 000000485878: BF8903F7
	v_dual_mov_b32 v98, v31 :: v_dual_mov_b32 v95, v33         // 00000048587C: CA10011F 625E0121
	s_waitcnt vmcnt(1)                                         // 000000485884: BF8907F7
	v_dual_mov_b32 v97, v43 :: v_dual_mov_b32 v96, v38         // 000000485888: CA10012B 61600126
	s_waitcnt vmcnt(0)                                         // 000000485890: BF8903F7
	v_dual_mov_b32 v94, v42 :: v_dual_mov_b32 v93, v37         // 000000485894: CA10012A 5E5C0125
	s_mov_b32 s7, exec_lo                                      // 00000048589C: BE87007E
	.long 0xd4c1007e                                           // 0000004858A0: D4C1007E
	v_cndmask_b32_e32 v1, v17, v22, vcc_lo                     // 0000004858A4: 02022D11
	s_cbranch_execz 64532                                      // 0000004858A8: BFA5FC14 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xcfc>
	v_ashrrev_i32_e32 v18, 31, v17                             // 0000004858AC: 3424229F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004858B0: BF870091
	.long 0xd73c0004                                           // 0000004858B4: D73C0004
	v_cndmask_b32_e32 v1, 10, v17, vcc_lo                      // 0000004858B8: 0202228A
	.long 0xd7006a01                                           // 0000004858BC: D7006A01
	v_cndmask_b32_e32 v1, s1, v4, vcc_lo                       // 0000004858C0: 02020801
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004858C4: BF870111
	v_add_co_ci_u32_e64 v7, null, s4, v5, vcc_lo               // 0000004858C8: D5207C07 01AA0A04
	.long 0xd7006a04                                           // 0000004858D0: D7006A04
	v_cndmask_b32_e32 v1, v1, v79, vcc_lo                      // 0000004858D4: 02029F01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004858D8: BF8700A1
	v_add_co_ci_u32_e64 v5, null, 0, v7, vcc_lo                // 0000004858DC: D5207C05 01AA0E80
	.long 0xd7006a06                                           // 0000004858E4: D7006A06
	v_cndmask_b32_e32 v1, v1, v81, vcc_lo                      // 0000004858E8: 0202A301
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 0000004858EC: D5207C07 01AA0E80
	s_clause 0xf                                               // 0000004858F4: BF85000F
	global_load_b32 v88, v[4:5], off                           // 0000004858F8: DC520000 587C0004
	global_load_b32 v87, v[4:5], off offset:128                // 000000485900: DC520080 577C0004
	global_load_b32 v86, v[4:5], off offset:256                // 000000485908: DC520100 567C0004
	global_load_b32 v85, v[4:5], off offset:384                // 000000485910: DC520180 557C0004
	global_load_b32 v40, v[4:5], off offset:512                // 000000485918: DC520200 287C0004
	global_load_b32 v39, v[4:5], off offset:640                // 000000485920: DC520280 277C0004
	global_load_b32 v38, v[4:5], off offset:768                // 000000485928: DC520300 267C0004
	global_load_b32 v37, v[4:5], off offset:896                // 000000485930: DC520380 257C0004
	global_load_b32 v92, v[6:7], off                           // 000000485938: DC520000 5C7C0006
	global_load_b32 v91, v[6:7], off offset:128                // 000000485940: DC520080 5B7C0006
	global_load_b32 v90, v[6:7], off offset:256                // 000000485948: DC520100 5A7C0006
	global_load_b32 v89, v[6:7], off offset:384                // 000000485950: DC520180 597C0006
	global_load_b32 v18, v[6:7], off offset:512                // 000000485958: DC520200 127C0006
	global_load_b32 v30, v[6:7], off offset:640                // 000000485960: DC520280 1E7C0006
	global_load_b32 v31, v[6:7], off offset:768                // 000000485968: DC520300 1F7C0006
	global_load_b32 v33, v[6:7], off offset:896                // 000000485970: DC520380 217C0006
	s_waitcnt vmcnt(10)                                        // 000000485978: BF892BF7
	v_dual_mov_b32 v45, v40 :: v_dual_mov_b32 v44, v39         // 00000048597C: CA100128 2D2C0127
	s_waitcnt vmcnt(8)                                         // 000000485984: BF8923F7
	v_dual_mov_b32 v43, v38 :: v_dual_mov_b32 v42, v37         // 000000485988: CA100126 2B2A0125
	s_branch 64474                                             // 000000485990: BFA0FBDA <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xcfc>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000485994: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000485998: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 00000048599C: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 0000004859A0: BF895FF7
	v_dual_mov_b32 v1, v77 :: v_dual_mov_b32 v2, v74           // 0000004859A4: CA10014D 0102014A
	s_waitcnt vmcnt(15)                                        // 0000004859AC: BF893FF7
	v_dual_mov_b32 v4, v73 :: v_dual_mov_b32 v3, v64           // 0000004859B0: CA100149 04020140
	v_dual_mov_b32 v5, v70 :: v_dual_mov_b32 v8, v75           // 0000004859B8: CA100146 0508014B
	v_dual_mov_b32 v7, v76 :: v_dual_mov_b32 v10, v71          // 0000004859C0: CA10014C 070A0147
	v_dual_mov_b32 v9, v72 :: v_dual_mov_b32 v14, v66          // 0000004859C8: CA100148 090E0142
	v_dual_mov_b32 v6, v52 :: v_dual_mov_b32 v11, v69          // 0000004859D0: CA100134 060A0145
	v_dual_mov_b32 v12, v68 :: v_dual_mov_b32 v13, v67         // 0000004859D8: CA100144 0C0C0143
	v_dual_mov_b32 v15, v65 :: v_dual_mov_b32 v16, v63         // 0000004859E0: CA100141 0F10013F
	s_waitcnt vmcnt(3)                                         // 0000004859E8: BF890FF7
	v_dual_mov_b32 v17, v62 :: v_dual_mov_b32 v18, v61         // 0000004859EC: CA10013E 1112013D
	v_dual_mov_b32 v22, v60 :: v_dual_mov_b32 v23, v59         // 0000004859F4: CA10013C 1616013B
	v_dual_mov_b32 v24, v58 :: v_dual_mov_b32 v25, v57         // 0000004859FC: CA10013A 18180139
	v_dual_mov_b32 v26, v56 :: v_dual_mov_b32 v27, v55         // 000000485A04: CA100138 1A1A0137
	v_dual_mov_b32 v28, v54 :: v_dual_mov_b32 v29, v53         // 000000485A0C: CA100136 1C1C0135
	s_waitcnt vmcnt(1)                                         // 000000485A14: BF8907F7
	v_dual_mov_b32 v30, v51 :: v_dual_mov_b32 v31, v50         // 000000485A18: CA100133 1E1E0132
	s_waitcnt vmcnt(0)                                         // 000000485A20: BF8903F7
	v_dual_mov_b32 v32, v49 :: v_dual_mov_b32 v33, v48         // 000000485A24: CA100131 20200130
	v_dual_mov_b32 v34, v47 :: v_dual_mov_b32 v35, v46         // 000000485A2C: CA10012F 2222012E
	s_mov_b32 s0, 0x76543210                                   // 000000485A34: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000485A3C: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000485A40: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000485A4C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000485A58: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000485A64: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000485A70: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000485A7C: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000485A88: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000485A94: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000485AA0: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000485AAC: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000485AB8: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000485AC4: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000485AD0: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000485ADC: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000485AE8: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000485AF4: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000485B00: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 000000485B0C: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v22, v22, s0, 0xfedcba98                 // 000000485B18: D65C0016 03FC0116 FEDCBA98
	v_permlanex16_b32 v23, v23, s0, 0xfedcba98                 // 000000485B24: D65C0017 03FC0117 FEDCBA98
	v_permlanex16_b32 v24, v24, s0, 0xfedcba98                 // 000000485B30: D65C0018 03FC0118 FEDCBA98
	v_permlanex16_b32 v25, v25, s0, 0xfedcba98                 // 000000485B3C: D65C0019 03FC0119 FEDCBA98
	v_permlanex16_b32 v26, v26, s0, 0xfedcba98                 // 000000485B48: D65C001A 03FC011A FEDCBA98
	v_permlanex16_b32 v27, v27, s0, 0xfedcba98                 // 000000485B54: D65C001B 03FC011B FEDCBA98
	v_permlanex16_b32 v28, v28, s0, 0xfedcba98                 // 000000485B60: D65C001C 03FC011C FEDCBA98
	v_permlanex16_b32 v29, v29, s0, 0xfedcba98                 // 000000485B6C: D65C001D 03FC011D FEDCBA98
	v_permlanex16_b32 v30, v30, s0, 0xfedcba98                 // 000000485B78: D65C001E 03FC011E FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 000000485B84: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 000000485B90: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v33, v33, s0, 0xfedcba98                 // 000000485B9C: D65C0021 03FC0121 FEDCBA98
	v_permlanex16_b32 v34, v34, s0, 0xfedcba98                 // 000000485BA8: D65C0022 03FC0122 FEDCBA98
	v_permlanex16_b32 v35, v35, s0, 0xfedcba98                 // 000000485BB4: D65C0023 03FC0123 FEDCBA98
	.long 0xd44c0000                                           // 000000485BC0: D44C0000
	v_cndmask_b32_e32 v1, 16, v21, vcc_lo                      // 000000485BC4: 02022A90
	s_barrier                                                  // 000000485BC8: BFBD0000
	buffer_gl0_inv                                             // 000000485BCC: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000485BD4: BE812000
	s_cbranch_execz 68                                         // 000000485BD8: BFA50044 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x20ec>
	v_lshl_or_b32 v20, v19, 11, v20                            // 000000485BDC: D6560014 04511713
	v_dual_add_f32 v5, v70, v5 :: v_dual_add_f32 v4, v73, v4   // 000000485BE4: C9080B46 05040949
	v_dual_add_f32 v1, v77, v1 :: v_dual_add_f32 v2, v74, v2   // 000000485BEC: C908034D 0102054A
	v_dual_add_f32 v8, v75, v8 :: v_dual_add_f32 v7, v76, v7   // 000000485BF4: C908114B 08060F4C
	v_dual_add_f32 v21, v46, v35 :: v_dual_add_f32 v34, v47, v34// 000000485BFC: C908472E 1522452F
	v_dual_add_f32 v6, v52, v6 :: v_dual_add_nc_u32 v35, 0x400, v20// 000000485C04: C9200D34 062228FF 00000400
	v_dual_add_f32 v10, v71, v10 :: v_dual_add_f32 v9, v72, v9 // 000000485C10: C9081547 0A081348
	v_dual_add_f32 v3, v64, v3 :: v_dual_add_f32 v14, v66, v14 // 000000485C18: C9080740 030E1D42
	v_add_f32_e32 v13, v67, v13                                // 000000485C20: 061A1B43
	v_dual_add_f32 v33, v48, v33 :: v_dual_add_f32 v32, v49, v32// 000000485C24: C9084330 21204131
	v_dual_add_f32 v31, v50, v31 :: v_dual_add_f32 v30, v51, v30// 000000485C2C: C9083F32 1F1E3D33
	v_dual_add_f32 v29, v53, v29 :: v_dual_add_f32 v28, v54, v28// 000000485C34: C9083B35 1D1C3936
	v_dual_add_f32 v27, v55, v27 :: v_dual_add_f32 v26, v56, v26// 000000485C3C: C9083737 1B1A3538
	v_dual_add_f32 v25, v57, v25 :: v_dual_add_f32 v24, v58, v24// 000000485C44: C9083339 1918313A
	v_dual_add_f32 v23, v59, v23 :: v_dual_add_f32 v22, v60, v22// 000000485C4C: C9082F3B 17162D3C
	v_dual_add_f32 v18, v61, v18 :: v_dual_add_f32 v17, v62, v17// 000000485C54: C908253D 1210233E
	v_dual_add_f32 v16, v63, v16 :: v_dual_add_f32 v15, v65, v15// 000000485C5C: C908213F 100E1F41
	v_dual_add_f32 v12, v68, v12 :: v_dual_add_f32 v11, v69, v11// 000000485C64: C9081944 0C0A1745
	ds_store_2addr_b32 v20, v1, v5 offset1:16                  // 000000485C6C: D8381000 00050114
	ds_store_2addr_b32 v20, v2, v7 offset0:128 offset1:144     // 000000485C74: D8389080 00070214
	ds_store_2addr_b32 v35, v4, v8 offset1:16                  // 000000485C7C: D8381000 00080423
	ds_store_2addr_b32 v35, v3, v9 offset0:128 offset1:144     // 000000485C84: D8389080 00090323
	ds_store_2addr_b32 v20, v6, v13 offset0:32 offset1:48      // 000000485C8C: D8383020 000D0614
	ds_store_2addr_b32 v20, v10, v14 offset0:160 offset1:176   // 000000485C94: D838B0A0 000E0A14
	ds_store_2addr_b32 v35, v11, v15 offset0:32 offset1:48     // 000000485C9C: D8383020 000F0B23
	ds_store_2addr_b32 v35, v12, v16 offset0:160 offset1:176   // 000000485CA4: D838B0A0 00100C23
	ds_store_2addr_b32 v20, v17, v24 offset0:64 offset1:80     // 000000485CAC: D8385040 00181114
	ds_store_2addr_b32 v20, v18, v25 offset0:192 offset1:208   // 000000485CB4: D838D0C0 00191214
	ds_store_2addr_b32 v35, v22, v26 offset0:64 offset1:80     // 000000485CBC: D8385040 001A1623
	ds_store_2addr_b32 v35, v23, v27 offset0:192 offset1:208   // 000000485CC4: D838D0C0 001B1723
	ds_store_2addr_b32 v20, v28, v32 offset0:96 offset1:112    // 000000485CCC: D8387060 00201C14
	ds_store_2addr_b32 v20, v29, v33 offset0:224 offset1:240   // 000000485CD4: D838F0E0 00211D14
	ds_store_2addr_b32 v35, v30, v34 offset0:96 offset1:112    // 000000485CDC: D8387060 00221E23
	ds_store_2addr_b32 v35, v31, v21 offset0:224 offset1:240   // 000000485CE4: D838F0E0 00151F23
	s_or_b32 exec_lo, exec_lo, s1                              // 000000485CEC: 8C7E017E
	.long 0xd44c0001                                           // 000000485CF0: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000485CF4: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 000000485CFC: BF89FC07
	s_barrier                                                  // 000000485D00: BFBD0000
	buffer_gl0_inv                                             // 000000485D04: E0AC0000 00000000
	s_and_saveexec_b32 s4, s1                                  // 000000485D0C: BE842001
	s_cbranch_execz 46                                         // 000000485D10: BFA5002E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x21cc>
	v_mov_b32_e32 v1, v0                                       // 000000485D14: 7E020300
	s_mov_b32 s5, 0                                            // 000000485D18: BE850080
	s_nop 0                                                    // 000000485D1C: BF800000
	s_nop 0                                                    // 000000485D20: BF800000
	s_nop 0                                                    // 000000485D24: BF800000
	s_nop 0                                                    // 000000485D28: BF800000
	s_nop 0                                                    // 000000485D2C: BF800000
	s_nop 0                                                    // 000000485D30: BF800000
	s_nop 0                                                    // 000000485D34: BF800000
	s_nop 0                                                    // 000000485D38: BF800000
	s_nop 0                                                    // 000000485D3C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000485D40: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000485D44: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 000000485D48: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:8            // 000000485D50: D8E00800 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:16 offset1:24// 000000485D58: D8E01810 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:32 offset1:40// 000000485D60: D8E02820 06000008
	s_or_b32 s5, vcc_lo, s5                                    // 000000485D68: 8C05056A
	s_waitcnt lgkmcnt(2)                                       // 000000485D6C: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 000000485D70: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000485D74: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000485D78: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:48 offset1:56// 000000485D7C: D8E03830 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000485D84: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000485D88: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 000000485D8C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 000000485D90: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000485D94: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000485D98: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 000000485D9C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 000000485DA0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000485DA4: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 000000485DA8: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 000000485DAC: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 000000485DB4: C9100702 02000104
	ds_store_b32 v8, v2 offset:16384                           // 000000485DBC: D8344000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000485DC4: 917E057E
	s_cbranch_execnz 65501                                     // 000000485DC8: BFA6FFDD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2140>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000485DCC: 8C7E047E
	s_cmp_lt_i32 s33, 2                                        // 000000485DD0: BF048221
	s_mov_b32 s4, -1                                           // 000000485DD4: BE8400C1
	s_cbranch_scc1 212                                         // 000000485DD8: BFA200D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x252c>
	s_waitcnt lgkmcnt(0)                                       // 000000485DDC: BF89FC07
	s_barrier                                                  // 000000485DE0: BFBD0000
	buffer_gl0_inv                                             // 000000485DE4: E0AC0000 00000000
	s_and_saveexec_b32 s6, s1                                  // 000000485DEC: BE862001
	s_cbranch_execz 71                                         // 000000485DF0: BFA50047 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2310>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000485DF4: 32020087
	s_ashr_i32 s11, s10, 31                                    // 000000485DF8: 860B9F0A
	s_ashr_i32 s19, s18, 31                                    // 000000485DFC: 86139F12
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000485E00: 8484820A
	s_mov_b32 s7, 0                                            // 000000485E04: BE870080
	v_or_b32_e32 v1, s4, v1                                    // 000000485E08: 38020204
	s_mul_i32 s4, s5, s18                                      // 000000485E0C: 96041205
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000485E10: BF8700A1
	.long 0xd72c0003                                           // 000000485E14: D72C0003
	v_cndmask_b32_e32 v0, v1, v19, vcc_lo                      // 000000485E18: 02002701
	v_mad_u64_u32 v[1:2], null, v1, s18, 0                     // 000000485E1C: D6FE7C01 02002501
	v_add3_u32 v2, v2, v3, s4                                  // 000000485E24: D6550002 00120702
	s_lshl_b32 s4, s2, 7                                       // 000000485E2C: 84048702
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000485E30: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 000000485E38: 86059F04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000485E3C: BF870122
	.long 0xd73c0001                                           // 000000485E40: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000485E44: 02020282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000485E48: 84848204
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000485E4C: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000485E50: 30060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000485E54: BF870093
	.long 0xd7006a01                                           // 000000485E58: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000485E5C: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000485E60: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[18:19], 3                             // 000000485E68: 84848312
	.long 0xd7006a01                                           // 000000485E6C: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 000000485E70: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000485E74: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000485E78: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 000000485E80: 380800FF FFFFFF00
	.long 0xd7006a01                                           // 000000485E88: D7006A01
	v_cndmask_b32_e32 v1, s24, v1, vcc_lo                      // 000000485E8C: 02020218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000485E90: BF870001
	v_add_co_ci_u32_e64 v2, null, s25, v2, vcc_lo              // 000000485E94: D5207C02 01AA0419
	s_nop 0                                                    // 000000485E9C: BF800000
	s_nop 0                                                    // 000000485EA0: BF800000
	s_nop 0                                                    // 000000485EA4: BF800000
	s_nop 0                                                    // 000000485EA8: BF800000
	s_nop 0                                                    // 000000485EAC: BF800000
	s_nop 0                                                    // 000000485EB0: BF800000
	s_nop 0                                                    // 000000485EB4: BF800000
	s_nop 0                                                    // 000000485EB8: BF800000
	s_nop 0                                                    // 000000485EBC: BF800000
	ds_load_b32 v5, v3 offset:16384                            // 000000485EC0: D8D84000 05000003
	.long 0xd7000804                                           // 000000485EC8: D7000804
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 000000485ECC: 020208FF 00000100
	s_xor_b32 s8, s8, -1                                       // 000000485ED4: 8D08C108
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000485ED8: 4A0606FF 00000400
	s_and_b32 s8, exec_lo, s8                                  // 000000485EE0: 8B08087E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000485EE4: BF8700C9
	s_or_b32 s7, s8, s7                                        // 000000485EE8: 8C070708
	s_waitcnt lgkmcnt(0)                                       // 000000485EEC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 000000485EF0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 000000485EF8: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000485EFC: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000485F00: D5207C02 01AA0405
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 000000485F08: 917E077E
	s_cbranch_execnz 65516                                     // 000000485F0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x22c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000485F10: 8C7E067E
	.long 0xd44a0004                                           // 000000485F14: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000485F18: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000485F1C: BC7C0000
	buffer_gl1_inv                                             // 000000485F20: E0B00000 00000000
	buffer_gl0_inv                                             // 000000485F28: E0AC0000 00000000
	s_barrier                                                  // 000000485F30: BFBD0000
	buffer_gl0_inv                                             // 000000485F34: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000485F3C: BE852004
	s_cbranch_execz 29                                         // 000000485F40: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x23b8>
	s_mov_b32 s7, exec_lo                                      // 000000485F44: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000485F48: BE86007E
	.long 0xd71f0001                                           // 000000485F4C: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 000000485F50: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000485F54: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000485F58: 7D940280
	s_cbranch_execz 9                                          // 000000485F5C: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2384>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 000000485F60: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000485F64: BF8704B9
	s_add_u32 s8, s26, s8                                      // 000000485F68: 8008081A
	s_addc_u32 s9, s27, s9                                     // 000000485F6C: 8209091B
	s_bcnt1_i32_b32 s7, s7                                     // 000000485F70: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 000000485F74: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 000000485F7C: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 000000485F84: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000485F88: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 000000485F8C: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000485F90: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 000000485F94: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 000000485F9C: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000485FA0: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 000000485FA4: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000485FA8: D5010001 01A90280
	ds_store_b32 v2, v1 offset:20480                           // 000000485FB0: D8345000 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 000000485FB8: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 000000485FBC: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000485FC0: BF89FC07
	s_barrier                                                  // 000000485FC4: BFBD0000
	buffer_gl0_inv                                             // 000000485FC8: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:20480                            // 000000485FD0: D8D85000 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000485FD8: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000485FDC: 7C940280
	s_cbranch_vccnz 467                                        // 000000485FE0: BFA401D3 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2b30>
	buffer_gl1_inv                                             // 000000485FE4: E0B00000 00000000
	buffer_gl0_inv                                             // 000000485FEC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000485FF4: BE852001
	s_cbranch_execz 65                                         // 000000485FF8: BFA50041 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2500>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000485FFC: 32020087
	s_lshl_b32 s6, s2, 7                                       // 000000486000: 84068702
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000486004: 360600FF 0000007F
	s_ashr_i32 s7, s6, 31                                      // 00000048600C: 86079F06
	v_mov_b32_e32 v5, v0                                       // 000000486010: 7E0A0300
	v_mad_i64_i32 v[1:2], null, v1, s18, 0                     // 000000486014: D6FF7C01 02002501
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000048601C: 84868206
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000486020: 30060682
	s_ashr_i32 s19, s18, 31                                    // 000000486024: 86139F12
	s_mov_b32 s10, 0                                           // 000000486028: BE8A0080
	s_lshl_b64 s[8:9], s[18:19], 4                             // 00000048602C: 84888412
	.long 0xd73c0001                                           // 000000486030: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000486034: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000486038: BF870091
	.long 0xd7006a01                                           // 00000048603C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000486040: 02000D01
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000486044: D5207C02 01AA0407
	s_lshl_b64 s[6:7], s[18:19], 3                             // 00000048604C: 84868312
	.long 0xd7006a01                                           // 000000486050: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000486054: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000486058: BF870111
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000048605C: D5207C02 01AA0480
	.long 0xd7006a01                                           // 000000486064: D7006A01
	v_cndmask_b32_e32 v1, s24, v1, vcc_lo                      // 000000486068: 02020218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000048606C: BF870001
	v_add_co_ci_u32_e64 v2, null, s25, v2, vcc_lo              // 000000486070: D5207C02 01AA0419
	s_nop 0                                                    // 000000486078: BF800000
	s_nop 0                                                    // 00000048607C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000486080: BF870001
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 000000486084: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 00000048608C: 7E0C0280
	s_mov_b32 s1, s33                                          // 000000486090: BE810021
	global_load_b32 v7, v[3:4], off glc                        // 000000486094: DC524000 077C0003
	.long 0xd7006a03                                           // 00000048609C: D7006A03
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000004860A0: 02001103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000004860A4: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000004860A8: D5207C04 01AA0809
	s_add_i32 s1, s1, -1                                       // 0000004860B0: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 0000004860B4: BF068001
	s_waitcnt vmcnt(0)                                         // 0000004860B8: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 0000004860BC: 060C0F06
	s_cbranch_scc0 65524                                       // 0000004860C0: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2494>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 0000004860C4: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 0000004860CC: 7C920AFF 000000FF
	.long 0xd7000101                                           // 0000004860D4: D7000101
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 0000004860D8: 02000D01
	v_lshlrev_b32_e32 v3, 2, v5                                // 0000004860DC: 30060A82
	v_add_co_ci_u32_e64 v2, null, s7, v2, s1                   // 0000004860E0: D5207C02 00060407
	v_mov_b32_e32 v5, v4                                       // 0000004860E8: 7E0A0304
	s_or_b32 s10, vcc_lo, s10                                  // 0000004860EC: 8C0A0A6A
	ds_store_b32 v3, v6 offset:16384                           // 0000004860F0: D8344000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000004860F8: 917E0A7E
	s_cbranch_execnz 65504                                     // 0000004860FC: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2480>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000486100: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 000000486104: BE812004
	s_cbranch_execz 6                                          // 000000486108: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2524>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 00000048610C: 84848202
	v_mov_b32_e32 v1, 0                                        // 000000486110: 7E020280
	s_add_u32 s4, s26, s4                                      // 000000486114: 8004041A
	s_addc_u32 s5, s27, s5                                     // 000000486118: 8205051B
	global_store_b32 v1, v1, s[4:5]                            // 00000048611C: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000486124: 8C7E017E
	s_mov_b32 s4, -1                                           // 000000486128: BE8400C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000048612C: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000486130: 8B6A047E
	s_cbranch_vccz 382                                         // 000000486134: BFA3017E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2b30>
	v_cmp_gt_i32_e32 vcc_lo, s16, v19                          // 000000486138: 7C882610
	.long 0xd44c0001                                           // 00000048613C: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000486140: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000486148: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000048614C: BC7C0000
	s_barrier                                                  // 000000486150: BFBD0000
	buffer_gl0_inv                                             // 000000486154: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000048615C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000486160: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000486164: BE832001
	s_cbranch_execz 369                                        // 000000486168: BFA50171 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2b30>
	v_and_b32_e32 v1, 15, v0                                   // 00000048616C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000486170: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000486174: 30040282
	v_lshl_or_b32 v2, v19, 9, v2                               // 000000486178: D6560002 04091313
	s_delay_alu instid0(VALU_DEP_1)                            // 000000486180: BF870001
	v_add_nc_u32_e32 v8, 0x4000, v2                            // 000000486184: 4A1004FF 00004000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000048618C: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000486194: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000048619C: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000004861A4: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000004861AC: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000004861B0: 36160082
	s_waitcnt lgkmcnt(3)                                       // 0000004861B4: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 0000004861B8: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 0000004861C0: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 0000004861C4: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 0000004861CC: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000004861D0: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000004861D8: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 0000004861DC: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 0000004861E4: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 0000004861EC: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004861F0: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 0000004861F4: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 0000004861FC: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000486204: 7C941480
	.long 0xd44a0001                                           // 000000486208: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 00000048620C: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000486210: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000486218: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 00000048621C: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 000000486220: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 000000486224: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000486228: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000486230: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000486234: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000486238: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000048623C: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000486244: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000048624C: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000486254: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000048625C: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000486264: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000048626C: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000486274: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000048627C: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000486284: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000048628C: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000486294: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000048629C: 7E2402FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 0000004862A4: D5010014 21AA0703
	v_cndmask_b32_e64 v22, -v2, v2, vcc_lo                     // 0000004862AC: D5010016 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000004862B4: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 0000004862B8: C9080D07 03082108
	v_mov_b32_dpp v21, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004862C0: 7E2A02FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 0000004862C8: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004862D0: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004862D4: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000004862DC: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 0000004862E4: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004862E8: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000004862F0: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004862F8: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 000000486300: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000486304: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000048630C: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 000000486314: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000486318: D5010008 21AA1108
	v_add_f32_e32 v13, v22, v21                                // 000000486320: 061A2B16
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000486324: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 00000048632C: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000486330: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000486338: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000486340: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 000000486348: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000048634C: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000486354: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 00000048635C: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000486360: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000486368: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 000000486370: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000486374: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000048637C: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 000000486384: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 000000486388: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 00000048638C: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000486394: 7E0402FA FF016402
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 00000048639C: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004863A4: BF870242
	v_add_f32_e32 v7, v7, v2                                   // 0000004863A8: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004863AC: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000004863B4: D5010004 20060904
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004863BC: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004863C4: 7E0A02FA FF016807
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004863CC: BF8700A3
	v_add_f32_e32 v4, v4, v10                                  // 0000004863D0: 06081504
	v_add_f32_e32 v10, v20, v18                                // 0000004863D4: 06142514
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004863D8: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000004863E0: D501000A 21AA150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004863E8: BF870241
	v_add_f32_e32 v10, v10, v12                                // 0000004863EC: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 0000004863F0: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004863F4: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000004863FC: D5010009 20061309
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000486404: 7E1E02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000048640C: BF870254
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000486410: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000486418: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000486420: D501000C 2006190C
	v_add_f32_e32 v6, v6, v11                                  // 000000486428: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000048642C: 7E1602FA FF016408
	v_dual_add_f32 v16, v9, v13 :: v_dual_add_f32 v15, v10, v15// 000000486434: C9081B09 100E1F0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000048643C: BF870214
	v_add_f32_e32 v17, v12, v17                                // 000000486440: 0622230C
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000486444: 7E1002FA FF016806
	s_delay_alu instid0(VALU_DEP_4)                            // 00000048644C: BF870004
	v_add_f32_e32 v14, v14, v11                                // 000000486450: 061C170E
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000486454: 7E1202FA FF016804
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000048645C: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000486464: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000048646C: 7E1A02FA FF016811
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000486474: 7E1402FA FF01680E
	s_and_b32 exec_lo, exec_lo, s0                             // 00000048647C: 8B7E007E
	s_cbranch_execz 171                                        // 000000486480: BFA500AB <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2b30>
	v_lshl_or_b32 v20, s2, 7, v1                               // 000000486484: D6560014 04050E02
	.long 0x7f243880                                           // 00000048648C: 7F243880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000486490: BF870112
	v_ashrrev_i32_e32 v21, 31, v20                             // 000000486494: 342A289F
	.long 0x7f303992                                           // 000000486498: 7F303992
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000048649C: BF870092
	.long 0xd73c0014                                           // 0000004864A0: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000004864A4: 02022881
	.long 0xd7006a16                                           // 0000004864A8: D7006A16
	v_cndmask_b32_e32 v1, s22, v20, vcc_lo                     // 0000004864AC: 02022816
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004864B0: BF870001
	v_add_co_ci_u32_e64 v23, null, s23, v21, vcc_lo            // 0000004864B4: D5207C17 01AA2A17
	s_clause 0x7                                               // 0000004864BC: BF850007
	global_load_d16_b16 v18, v[22:23], off offset:32           // 0000004864C0: DC820020 127C0016
	global_load_d16_b16 v24, v[22:23], off                     // 0000004864C8: DC820000 187C0016
	global_load_d16_b16 v25, v[22:23], off offset:64           // 0000004864D0: DC820040 197C0016
	global_load_d16_b16 v26, v[22:23], off offset:96           // 0000004864D8: DC820060 1A7C0016
	global_load_d16_b16 v27, v[22:23], off offset:128          // 0000004864E0: DC820080 1B7C0016
	global_load_d16_b16 v28, v[22:23], off offset:160          // 0000004864E8: DC8200A0 1C7C0016
	global_load_d16_b16 v29, v[22:23], off offset:192          // 0000004864F0: DC8200C0 1D7C0016
	global_load_d16_b16 v22, v[22:23], off offset:224          // 0000004864F8: DC8200E0 167C0016
	v_and_b32_e32 v23, 8, v0                                   // 000000486500: 362E0088
	v_mad_i64_i32 v[0:1], null, s18, v19, 0                    // 000000486504: D6FF7C00 02022612
	s_waitcnt vmcnt(7)                                         // 00000048650C: BF891FF7
	.long 0x7f263992                                           // 000000486510: 7F263992
	s_waitcnt vmcnt(0)                                         // 000000486514: BF8903F7
	.long 0x7f2c3992                                           // 000000486518: 7F2C3992
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 00000048651C: 7C942E80
	.long 0x7f2e3992                                           // 000000486520: 7F2E3992
	.long 0xd73c0000                                           // 000000486524: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000486528: 02020081
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000048652C: D5010007 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000486534: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000048653C: D5010004 21AA0904
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000486544: D5010006 21AA0D06
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000048654C: D501000E 21AA1D0E
	v_add_f32_e32 v5, v7, v5                                   // 000000486554: 060A0B07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 000000486558: D5010007 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000486560: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000486568: D501000F 21AA1F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000486570: BF870124
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 000000486574: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v8 :: v_dual_add_f32 v4, v4, v9     // 000000486580: C9081106 05041304
	v_dual_add_f32 v7, v7, v11 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 000000486588: C9061707 070204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000486594: BF870194
	v_dual_add_f32 v8, v15, v12 :: v_dual_add_f32 v9, v16, v13 // 000000486598: C908190F 08081B10
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 0000004865A0: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004865A8: BF870193
	v_dual_add_f32 v6, v14, v10 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 0000004865AC: C906150E 06060EFF 3DB504F3
	v_dual_mul_f32 v8, 0x3db504f3, v8 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 0000004865B8: C8C610FF 08040AFF 3DB504F3
	.long 0xd7006a00                                           // 0000004865C4: D7006A00
	v_cndmask_b32_e32 v1, s28, v0, vcc_lo                      // 0000004865C8: 0202001C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004865CC: BF8701A3
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 0000004865D0: 100C0CFF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, s29, v1, vcc_lo              // 0000004865D8: D5207C01 01AA021D
	.long 0xd7006a00                                           // 0000004865E0: D7006A00
	v_cndmask_b32_e32 v1, v0, v20, vcc_lo                      // 0000004865E4: 02022900
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004865E8: BF870001
	v_add_co_ci_u32_e64 v1, null, v1, v21, vcc_lo              // 0000004865EC: D5207C01 01AA2B01
	v_fma_mix_f32 v3, v18, v3, neg(0) op_sel_hi:[1,0,0]        // 0000004865F4: CC200003 8A020712
	v_fma_mix_f32 v2, v24, v2, neg(0) op_sel_hi:[1,0,0]        // 0000004865FC: CC200002 8A020518
	v_fma_mix_f32 v5, v25, v5, neg(0) op_sel_hi:[1,0,0]        // 000000486604: CC200005 8A020B19
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 00000048660C: CC200004 8A02091A
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 000000486614: CC200006 8A020D1B
	.long 0x7e243983                                           // 00000048661C: 7E243983
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000486620: 101212FF 3DB504F3
	v_fma_mix_f32 v7, v28, v7, neg(0) op_sel_hi:[1,0,0]        // 000000486628: CC200007 8A020F1C
	v_fma_mix_f32 v8, v29, v8, neg(0) op_sel_hi:[1,0,0]        // 000000486630: CC200008 8A02111D
	.long 0x7e263982                                           // 000000486638: 7E263982
	v_and_b32_e32 v10, 1, v18                                  // 00000048663C: 36142481
	.long 0x7e243984                                           // 000000486640: 7E243984
	v_fma_mix_f32 v9, v22, v9, neg(0) op_sel_hi:[1,0,0]        // 000000486644: CC200009 8A021316
	.long 0x7e2c3985                                           // 00000048664C: 7E2C3985
	.long 0x7e2e3986                                           // 000000486650: 7E2E3986
	.long 0x7e303988                                           // 000000486654: 7E303988
	v_and_b32_e32 v11, 1, v18                                  // 000000486658: 36162481
	.long 0x7e243987                                           // 00000048665C: 7E243987
	v_and_b32_e32 v12, 1, v19                                  // 000000486660: 36182681
	v_and_b32_e32 v13, 1, v22                                  // 000000486664: 361A2C81
	v_and_b32_e32 v14, 1, v23                                  // 000000486668: 361C2E81
	v_and_b32_e32 v16, 1, v24                                  // 00000048666C: 36203081
	v_and_b32_e32 v15, 1, v18                                  // 000000486670: 361E2481
	.long 0x7e243989                                           // 000000486674: 7E243989
	v_add3_u32 v3, v3, v10, 0x7fff                             // 000000486678: D6550003 03FE1503 00007FFF
	v_add3_u32 v2, v2, v12, 0x7fff                             // 000000486684: D6550002 03FE1902 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 000000486690: D6550005 03FE1B05 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 00000048669C: D6550004 03FE1704 00007FFF
	v_and_b32_e32 v10, 1, v18                                  // 0000004866A8: 36142481
	v_add3_u32 v6, v6, v14, 0x7fff                             // 0000004866AC: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 0000004866B8: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 0000004866C4: D6550007 03FE1F07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004866D0: BF870004
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000004866D4: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 0000004866E0: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000004866E4: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 0000004866EC: DC960020 007C0300
	global_store_d16_hi_b16 v[0:1], v5, off offset:64          // 0000004866F4: DC960040 007C0500
	global_store_d16_hi_b16 v[0:1], v4, off offset:96          // 0000004866FC: DC960060 007C0400
	global_store_d16_hi_b16 v[0:1], v6, off offset:128         // 000000486704: DC960080 007C0600
	global_store_d16_hi_b16 v[0:1], v7, off offset:160         // 00000048670C: DC9600A0 007C0700
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 000000486714: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:224         // 00000048671C: DC9600E0 007C0900
	s_nop 0                                                    // 000000486724: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000486728: BFB60003
	s_endpgm                                                   // 00000048672C: BFB00000
	s_nop 0                                                    // 000000486730: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000486734: BFB60003
	s_endpgm                                                   // 000000486738: BFB00000
		...

