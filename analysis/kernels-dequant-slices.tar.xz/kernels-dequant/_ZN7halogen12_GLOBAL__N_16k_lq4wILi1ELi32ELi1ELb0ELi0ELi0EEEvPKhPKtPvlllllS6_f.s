000000000054d600 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000054D600: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000054D608: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000054D60C: 32040082
	s_lshl_b64 s[0:1], s[2:3], 3                               // 00000054D610: 84808302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054D614: BF8701A9
	v_dual_mov_b32 v10, s1 :: v_dual_and_b32 v1, 15, v0        // 00000054D618: CA240001 0A00008F
	.long 0x7f103880                                           // 00000054D620: 7F103880
	v_and_b32_e32 v2, 60, v2                                   // 00000054D624: 360404BC
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054D628: BF870003
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 00000054D62C: CA220080 12000282
	v_dual_mov_b32 v3, 0 :: v_dual_and_b32 v16, 31, v0         // 00000054D634: CA240080 0310009F
	v_mov_b32_e32 v17, 0                                       // 00000054D63C: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 00000054D640: BF89FC07
	s_clause 0x1                                               // 00000054D644: BF850001
	global_load_b32 v4, v1, s[4:5]                             // 00000054D648: DC520000 04040001
	global_load_b32 v7, v2, s[4:5]                             // 00000054D650: DC520000 07040002
	v_lshrrev_b32_e32 v2, 5, v0                                // 00000054D658: 32040085
	s_add_u32 s2, s4, s14                                      // 00000054D65C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 00000054D660: 82030F05
	v_mov_b32_e32 v1, 0                                        // 00000054D664: 7E020280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000054D668: BF870132
	v_or_b32_e32 v9, s0, v2                                    // 00000054D66C: 38120400
	s_lshr_b32 s0, s11, 31                                     // 00000054D670: 85009F0B
	v_mov_b32_e32 v2, 0                                        // 00000054D674: 7E040280
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 00000054D678: 7CA8120C
	s_add_u32 s12, s10, s0                                     // 00000054D67C: 800C000A
	s_addc_u32 s13, s11, 0                                     // 00000054D680: 820D800B
	s_ashr_i32 s14, s11, 31                                    // 00000054D684: 860E9F0B
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 00000054D688: 02161280
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 00000054D68C: D501000E 01A80280
	s_ashr_i64 s[0:1], s[12:13], 1                             // 00000054D694: 8680810C
	s_lshr_b32 s12, s14, 27                                    // 00000054D698: 850C9B0E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054D69C: BF870001
	.long 0xd72c0014                                           // 00000054D6A0: D72C0014
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 00000054D6A4: 0200010E
	.long 0xd72c000e                                           // 00000054D6A8: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 00000054D6AC: 02021C12
	s_waitcnt vmcnt(1)                                         // 00000054D6B0: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 00000054D6B4: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 00000054D6BC: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 00000054D6C0: D6100013 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054D6C8: BF870112
	v_add3_u32 v4, v4, v12, 0x7fff                             // 00000054D6CC: D6550004 03FE1904 00007FFF
	v_add3_u32 v7, v7, v19, 0x7fff                             // 00000054D6D8: D6550007 03FE2707 00007FFF
	v_lshlrev_b32_e32 v19, 2, v0                               // 00000054D6E4: 30260082
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054D6E8: BF870003
	.long 0x7e103984                                           // 00000054D6EC: 7E103984
	v_mov_b32_e32 v4, 0                                        // 00000054D6F0: 7E080280
	.long 0xd72c000d                                           // 00000054D6F4: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 00000054D6F8: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 00000054D6FC: D6FE7C05 02021612
	.long 0xd72c000f                                           // 00000054D704: D72C000F
	v_cndmask_b32_e32 v0, v11, v1, vcc_lo                      // 00000054D708: 0200030B
	v_mad_u64_u32 v[11:12], null, v11, s0, s[2:3]              // 00000054D70C: D6FE7C0B 0008010B
	s_add_u32 s2, s10, s12                                     // 00000054D714: 80020C0A
	s_addc_u32 s3, s11, 0                                      // 00000054D718: 8203800B
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 00000054D71C: D6570007 04220EFF FFFF0000
	s_lshr_b64 s[2:3], s[2:3], 5                               // 00000054D728: 85828502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000054D72C: BF870009
	.long 0xd4440000                                           // 00000054D730: D4440000
	v_cndmask_b32_e32 v1, s2, v16, vcc_lo                      // 00000054D734: 02022002
	v_add3_u32 v6, v6, v14, v13                                // 00000054D738: D6550006 04361D06
	v_add3_u32 v0, v20, v12, v15                               // 00000054D740: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 00000054D748: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 00000054D750: BF89FC07
	s_barrier                                                  // 00000054D754: BFBD0000
	buffer_gl0_inv                                             // 00000054D758: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 00000054D760: BE832000
	s_cbranch_execz 26                                         // 00000054D764: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1d0>
	s_add_u32 s1, s4, s16                                      // 00000054D768: 80011004
	s_addc_u32 s10, s5, s17                                    // 00000054D76C: 820A1105
	v_lshlrev_b32_e32 v1, 1, v16                               // 00000054D770: 30022081
	.long 0xd7000102                                           // 00000054D774: D7000102
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 00000054D778: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054D77C: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s10, v6, s1                  // 00000054D780: D5207C03 00060C0A
	v_lshlrev_b32_e32 v4, 4, v16                               // 00000054D788: 30082084
	.long 0xd7000101                                           // 00000054D78C: D7000101
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 00000054D790: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000054D794: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s1                    // 00000054D798: D5207C02 00060680
	.long 0xd7000103                                           // 00000054D7A0: D7000103
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 00000054D7A4: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054D7A8: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s1                    // 00000054D7AC: D5207C04 00060080
	s_clause 0x1                                               // 00000054D7B4: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 00000054D7B8: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 00000054D7C0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000054D7C8: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 00000054D7CC: 7E241707
	s_or_b32 exec_lo, exec_lo, s3                              // 00000054D7D0: 8C7E037E
	s_and_saveexec_b32 s3, s0                                  // 00000054D7D4: BE832000
	s_cbranch_execz 227                                        // 00000054D7D8: BFA500E3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x568>
	v_dual_mov_b32 v20, v16 :: v_dual_lshlrev_b32 v7, 1, v16   // 00000054D7DC: CA220110 14062081
	.long 0xd7000005                                           // 00000054D7E4: D7000005
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 00000054D7E8: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054D7EC: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s0                  // 00000054D7F0: D5207C06 00020C11
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 00000054D7F8: CA220080 0D0C2085
	.long 0xd7000005                                           // 00000054D800: D7000005
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000054D804: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054D808: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 00000054D80C: D5207C06 00020C80
	v_lshl_or_b32 v19, v16, 4, 0x200                           // 00000054D814: D6560013 03FD0910 00000200
	.long 0xd7000005                                           // 00000054D820: D7000005
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 00000054D824: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054D828: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s0                   // 00000054D82C: D5207C06 00020C05
	v_mov_b32_e32 v17, v13                                     // 00000054D834: 7E22030D
	.long 0xd700000e                                           // 00000054D838: D700000E
	v_cndmask_b32_e32 v0, v5, v192, vcc_lo                     // 00000054D83C: 02018105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054D840: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s0                   // 00000054D844: D5207C0F 00020C80
	v_mov_b32_e32 v21, v18                                     // 00000054D84C: 7E2A0312
	s_mov_b32 s4, 0                                            // 00000054D850: BE840080
	s_branch 170                                               // 00000054D854: BFA000AA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x500>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000054D858: 8C7E057E
	.long 0xd73c0016                                           // 00000054D85C: D73C0016
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000054D860: 02021881
	v_and_b32_e32 v38, 0xff, v1                                // 00000054D864: 364C02FF 000000FF
	v_lshrrev_b32_e32 v39, 6, v1                               // 00000054D86C: 324E0286
	v_lshrrev_b32_e32 v40, 14, v1                              // 00000054D870: 3250028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 00000054D874: 32020296
	v_and_b32_e32 v41, 0xff, v2                                // 00000054D878: 365204FF 000000FF
	.long 0xd7000122                                           // 00000054D880: D7000122
	v_cndmask_b32_e32 v1, s6, v22, vcc_lo                      // 00000054D884: 02022C06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054D888: BF870001
	v_add_co_ci_u32_e64 v35, null, s7, v23, s1                 // 00000054D88C: D5207C23 00062E07
	v_lshlrev_b32_e32 v38, 2, v38                              // 00000054D894: 304C4C82
	v_and_b32_e32 v39, 0x3fc, v39                              // 00000054D898: 364E4EFF 000003FC
	v_and_b32_e32 v40, 0x3fc, v40                              // 00000054D8A0: 365050FF 000003FC
	s_clause 0x3                                               // 00000054D8A8: BF850003
	global_load_b128 v[22:25], v[34:35], off                   // 00000054D8AC: DC5E0000 167C0022
	global_load_b128 v[26:29], v[34:35], off offset:16         // 00000054D8B4: DC5E0010 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:32         // 00000054D8BC: DC5E0020 1E7C0022
	global_load_b128 v[34:37], v[34:35], off offset:48         // 00000054D8C4: DC5E0030 227C0022
	v_lshrrev_b32_e32 v42, 6, v2                               // 00000054D8CC: 32540486
	ds_load_b32 v38, v38                                       // 00000054D8D0: D8D80000 26000026
	ds_load_b32 v39, v39                                       // 00000054D8D8: D8D80000 27000027
	ds_load_b32 v40, v40                                       // 00000054D8E0: D8D80000 28000028
	v_lshrrev_b32_e32 v43, 14, v2                              // 00000054D8E8: 3256048E
	v_lshrrev_b32_e32 v2, 22, v2                               // 00000054D8EC: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000054D8F0: 360202FF 000003FC
	v_lshlrev_b32_e32 v41, 2, v41                              // 00000054D8F8: 30525282
	v_and_b32_e32 v42, 0x3fc, v42                              // 00000054D8FC: 365454FF 000003FC
	v_and_b32_e32 v43, 0x3fc, v43                              // 00000054D904: 365656FF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 00000054D90C: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 00000054D914: D8D80000 01000001
	ds_load_b32 v41, v41                                       // 00000054D91C: D8D80000 29000029
	ds_load_b32 v42, v42                                       // 00000054D924: D8D80000 2A00002A
	ds_load_b32 v43, v43                                       // 00000054D92C: D8D80000 2B00002B
	ds_load_b32 v2, v2                                         // 00000054D934: D8D80000 02000002
	s_and_b32 s1, exec_lo, s0                                  // 00000054D93C: 8B01007E
	.long 0xd700000e                                           // 00000054D940: D700000E
	v_cndmask_b32_e32 v0, v14, v192, vcc_lo                    // 00000054D944: 0201810E
	v_add_nc_u32_e32 v12, 0x400, v12                           // 00000054D948: 4A1818FF 00000400
	v_add_nc_u32_e32 v19, 0x200, v19                           // 00000054D950: 4A2626FF 00000200
	v_add_co_ci_u32_e64 v15, null, 0, v15, s0                  // 00000054D958: D5207C0F 00021E80
	s_or_b32 s4, s1, s4                                        // 00000054D960: 8C040401
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 00000054D964: BF890C77
	v_dot2_f32_bf16 v22, v22, v38, 0                           // 00000054D968: CC1A4016 1A024D16
	v_lshrrev_b32_e32 v38, 14, v3                              // 00000054D970: 324C068E
	s_waitcnt lgkmcnt(6)                                       // 00000054D974: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054D978: BF8701A2
	v_dot2_f32_bf16 v22, v23, v39, v22                         // 00000054D97C: CC1A4016 1C5A4F17
	v_and_b32_e32 v23, 0xff, v3                                // 00000054D984: 362E06FF 000000FF
	v_and_b32_e32 v38, 0x3fc, v38                              // 00000054D98C: 364C4CFF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 00000054D994: BF89FC57
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000054D998: BF8701C3
	v_dot2_f32_bf16 v22, v24, v40, v22                         // 00000054D99C: CC1A4016 1C5A5118
	v_lshrrev_b32_e32 v24, 6, v3                               // 00000054D9A4: 32300686
	v_lshrrev_b32_e32 v3, 22, v3                               // 00000054D9A8: 32060696
	s_waitcnt lgkmcnt(4)                                       // 00000054D9AC: BF89FC47
	v_dot2_f32_bf16 v1, v25, v1, v22                           // 00000054D9B0: CC1A4001 1C5A0319
	v_lshlrev_b32_e32 v22, 2, v23                              // 00000054D9B8: 302C2E82
	v_and_b32_e32 v24, 0x3fc, v24                              // 00000054D9BC: 363030FF 000003FC
	v_and_b32_e32 v23, 0xff, v4                                // 00000054D9C4: 362E08FF 000000FF
	v_lshrrev_b32_e32 v25, 6, v4                               // 00000054D9CC: 32320886
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 00000054D9D0: BF890837
	v_dot2_f32_bf16 v1, v26, v41, v1                           // 00000054D9D4: CC1A4001 1C06531A
	ds_load_b32 v22, v22                                       // 00000054D9DC: D8D80000 16000016
	ds_load_b32 v24, v24                                       // 00000054D9E4: D8D80000 18000018
	v_lshrrev_b32_e32 v26, 14, v4                              // 00000054D9EC: 3234088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 00000054D9F0: 32080896
	s_waitcnt lgkmcnt(4)                                       // 00000054D9F4: BF89FC47
	v_dot2_f32_bf16 v1, v27, v42, v1                           // 00000054D9F8: CC1A4001 1C06551B
	ds_load_b32 v27, v38                                       // 00000054DA00: D8D80000 1B000026
	v_and_b32_e32 v3, 0x3fc, v3                                // 00000054DA08: 360606FF 000003FC
	v_lshlrev_b32_e32 v23, 2, v23                              // 00000054DA10: 302E2E82
	v_and_b32_e32 v25, 0x3fc, v25                              // 00000054DA14: 363232FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 00000054DA1C: BF89FC47
	v_dot2_f32_bf16 v1, v28, v43, v1                           // 00000054DA20: CC1A4001 1C06571C
	v_and_b32_e32 v26, 0x3fc, v26                              // 00000054DA28: 363434FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000054DA30: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 00000054DA38: BF89FC37
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054DA3C: BF870003
	v_dot2_f32_bf16 v1, v29, v2, v1                            // 00000054DA40: CC1A4001 1C06051D
	ds_load_b32 v2, v3                                         // 00000054DA48: D8D80000 02000003
	ds_load_b32 v3, v23                                        // 00000054DA50: D8D80000 03000017
	ds_load_b32 v23, v25                                       // 00000054DA58: D8D80000 17000019
	ds_load_b32 v25, v26                                       // 00000054DA60: D8D80000 1900001A
	ds_load_b32 v4, v4                                         // 00000054DA68: D8D80000 04000004
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000054DA70: BF890477
	v_dot2_f32_bf16 v1, v30, v22, v1                           // 00000054DA74: CC1A4001 1C062D1E
	s_waitcnt lgkmcnt(6)                                       // 00000054DA7C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054DA80: BF8700A1
	v_dot2_f32_bf16 v1, v31, v24, v1                           // 00000054DA84: CC1A4001 1C06311F
	s_waitcnt lgkmcnt(5)                                       // 00000054DA8C: BF89FC57
	v_dot2_f32_bf16 v1, v32, v27, v1                           // 00000054DA90: CC1A4001 1C063720
	s_waitcnt lgkmcnt(4)                                       // 00000054DA98: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000054DA9C: BF870131
	v_dot2_f32_bf16 v1, v33, v2, v1                            // 00000054DAA0: CC1A4001 1C060521
	v_mov_b32_e32 v2, v6                                       // 00000054DAA8: 7E040306
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000054DAAC: BF890037
	v_dot2_f32_bf16 v1, v34, v3, v1                            // 00000054DAB0: CC1A4001 1C060722
	v_mov_b32_e32 v3, v7                                       // 00000054DAB8: 7E060307
	s_waitcnt lgkmcnt(2)                                       // 00000054DABC: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054DAC0: BF8700A2
	v_dot2_f32_bf16 v1, v35, v23, v1                           // 00000054DAC4: CC1A4001 1C062F23
	s_waitcnt lgkmcnt(1)                                       // 00000054DACC: BF89FC17
	v_dot2_f32_bf16 v1, v36, v25, v1                           // 00000054DAD0: CC1A4001 1C063324
	s_waitcnt lgkmcnt(0)                                       // 00000054DAD8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000054DADC: BF870121
	v_dot2_f32_bf16 v22, v37, v4, v1                           // 00000054DAE0: CC1A4016 1C060925
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v1, v5             // 00000054DAE8: CA100108 04000105
	v_dual_fmac_f32 v17, v18, v22 :: v_dual_mov_b32 v18, v21   // 00000054DAF0: C8102D12 11120115
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000054DAF8: 917E047E
	s_cbranch_execz 25                                         // 00000054DAFC: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x564>
	s_waitcnt vmcnt(0)                                         // 00000054DB00: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v20, 32, v20    // 00000054DB04: CA200101 051428A0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 00000054DB0C: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 00000054DB14: 7E100304
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054DB18: BF870003
	.long 0xd4430000                                           // 00000054DB1C: D4430000
	v_cndmask_b32_e32 v1, s2, v20, vcc_lo                      // 00000054DB20: 02022802
	s_mov_b32 s5, exec_lo                                      // 00000054DB24: BE85007E
	.long 0xd4c4007e                                           // 00000054DB28: D4C4007E
	v_cndmask_b32_e32 v1, s2, v20, vcc_lo                      // 00000054DB2C: 02022802
	s_cbranch_execz 65353                                      // 00000054DB30: BFA5FF49 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x258>
	.long 0xd7000105                                           // 00000054DB34: D7000105
	v_cndmask_b32_e32 v1, v11, v19, vcc_lo                     // 00000054DB38: 0202270B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054DB3C: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s1                    // 00000054DB40: D5207C06 00060080
	global_load_d16_b16 v21, v[14:15], off                     // 00000054DB48: DC820000 157C000E
	global_load_b128 v[5:8], v[5:6], off                       // 00000054DB50: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 00000054DB58: BF8907F7
	v_cvt_f32_f16_e32 v21, v21                                 // 00000054DB5C: 7E2A1715
	s_branch 65341                                             // 00000054DB60: BFA0FF3D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x258>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000054DB64: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000054DB68: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000054DB6C: 8C7E037E
	.long 0xd71f0000                                           // 00000054DB70: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000054DB74: 020100C1
	s_waitcnt vmcnt(0)                                         // 00000054DB78: BF8903F7
	v_xor_b32_e32 v1, 16, v0                                   // 00000054DB7C: 3A020090
	v_xor_b32_e32 v2, 8, v0                                    // 00000054DB80: 3A040088
	v_xor_b32_e32 v3, 4, v0                                    // 00000054DB84: 3A060084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054DB88: BF870093
	.long 0xd44c0000                                           // 00000054DB8C: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 00000054DB90: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 00000054DB94: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054DB9C: BF870114
	.long 0xd44c0000                                           // 00000054DBA0: D44C0000
	v_cndmask_b32_e32 v1, 32, v2, vcc_lo                       // 00000054DBA4: 020204A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000054DBA8: 30020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000054DBAC: BF8700D2
	v_cndmask_b32_e64 v2, v0, v2, s0                           // 00000054DBB0: D5010002 00020500
	.long 0xd44c0000                                           // 00000054DBB8: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 00000054DBBC: 020206A0
	ds_bpermute_b32 v1, v1, v17                                // 00000054DBC0: DACC0000 01001101
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000054DBC8: 30040482
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 00000054DBCC: D5010003 00020700
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000054DBD4: 30060682
	s_waitcnt lgkmcnt(0)                                       // 00000054DBD8: BF89FC07
	v_add_f32_e32 v1, v17, v1                                  // 00000054DBDC: 06020311
	ds_bpermute_b32 v2, v2, v1                                 // 00000054DBE0: DACC0000 02000102
	s_waitcnt lgkmcnt(0)                                       // 00000054DBE8: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 00000054DBEC: 06020501
	ds_bpermute_b32 v2, v3, v1                                 // 00000054DBF0: DACC0000 02000103
	v_xor_b32_e32 v3, 2, v0                                    // 00000054DBF8: 3A060082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054DBFC: BF870091
	.long 0xd44c0000                                           // 00000054DC00: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 00000054DC04: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 00000054DC08: D5010003 00020700
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000054DC10: BF8700D1
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000054DC14: 30060682
	s_waitcnt lgkmcnt(0)                                       // 00000054DC18: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 00000054DC1C: 06020501
	ds_bpermute_b32 v2, v3, v1                                 // 00000054DC20: DACC0000 02000103
	v_xor_b32_e32 v3, 1, v0                                    // 00000054DC28: 3A060081
	.long 0xd44c0000                                           // 00000054DC2C: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 00000054DC30: 020206A0
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054DC34: BF870001
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 00000054DC38: D5010003 00020700
	.long 0xd44a0000                                           // 00000054DC40: D44A0000
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 00000054DC44: 02022080
	s_and_b32 s0, s0, vcc_lo                                   // 00000054DC48: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 00000054DC4C: BF89FC07
	v_dual_add_f32 v0, v1, v2 :: v_dual_lshlrev_b32 v1, 2, v3  // 00000054DC50: C9220501 00000682
	ds_bpermute_b32 v1, v1, v0                                 // 00000054DC58: DACC0000 01000001
	s_and_saveexec_b32 s1, s0                                  // 00000054DC60: BE812000
	s_cbranch_execz 17                                         // 00000054DC64: BFA50011 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x6ac>
	s_waitcnt lgkmcnt(0)                                       // 00000054DC68: BF89FC07
	v_add_f32_e32 v2, v0, v1                                   // 00000054DC6C: 06040300
	.long 0xd73c0000                                           // 00000054DC70: D73C0000
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 00000054DC74: 02021281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054DC78: BF870112
	v_bfe_u32 v3, v2, 16, 1                                    // 00000054DC7C: D6100003 02052102
	.long 0xd7006a00                                           // 00000054DC84: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000054DC88: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000054DC8C: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000054DC90: D5207C01 01AA0209
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000054DC98: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000054DCA4: DC960000 007C0200
	s_endpgm                                                   // 00000054DCAC: BFB00000
		...

