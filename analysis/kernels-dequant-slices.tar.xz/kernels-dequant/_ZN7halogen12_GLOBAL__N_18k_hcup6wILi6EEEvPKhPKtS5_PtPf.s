0000000000388500 <_ZN7halogen12_GLOBAL__N_18k_hcup6wILi6EEEvPKhPKtS5_PtPf>:
; _ZN7halogen12_GLOBAL__N_18k_hcup6wILi6EEEvPKhPKtS5_PtPf():
	s_clause 0x1                                               // 000000388500: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000388504: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000038850C: F4040300 F8000020
	v_dual_mov_b32 v8, 0 :: v_dual_and_b32 v7, 15, v0          // 000000388514: CA240080 0806008F
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v6, 0               // 00000038851C: CA100080 09060080
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 000000388524: CA100080 05040080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000038852C: BF870003
	v_cmp_gt_u32_e32 vcc_lo, 10, v7                            // 000000388530: 7C980E8A
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 000000388534: CA100080 03020080
	v_mov_b32_e32 v1, 0                                        // 00000038853C: 7E020280
	s_lshl_b32 s1, s2, 2                                       // 000000388540: 84018202
	s_and_saveexec_b32 s2, vcc_lo                              // 000000388544: BE82206A
	s_cbranch_execz 46                                         // 000000388548: BFA5002E <_ZN7halogen12_GLOBAL__N_18k_hcup6wILi6EEEvPKhPKtS5_PtPf+0x104>
	v_lshrrev_b32_e32 v1, 6, v0                                // 00000038854C: 32020086
	v_bfe_u32 v2, v0, 4, 2                                     // 000000388550: D6100002 02090900
	v_lshlrev_b32_e32 v4, 1, v0                                // 000000388558: 30080081
	v_lshlrev_b32_e32 v5, 4, v7                                // 00000038855C: 300A0E84
	v_lshlrev_b32_e32 v6, 3, v7                                // 000000388560: 300C0E83
	v_add_nc_u32_e32 v1, s1, v1                                // 000000388564: 4A020201
	v_mul_u32_u24_e32 v2, 0xa00, v2                            // 000000388568: 160404FF 00000A00
	v_and_b32_e32 v4, 28, v4                                   // 000000388570: 3608089C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000388574: BF870193
	v_ashrrev_i32_e32 v3, 31, v1                               // 000000388578: 3406029F
	.long 0xd7000001                                           // 00000038857C: D7000001
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000388580: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000388584: BF870121
	v_add_co_ci_u32_e64 v3, null, 0, v3, s0                    // 000000388588: D5207C03 00020680
	s_waitcnt lgkmcnt(0)                                       // 000000388590: BF89FC07
	v_mad_u64_u32 v[1:2], null, 0x110, v1, s[4:5]              // 000000388594: D6FE7C01 001202FF 00000110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003885A0: BF870111
	v_mad_i32_i24 v8, 0x110, v3, v2                            // 0000003885A4: D60A0008 040A06FF 00000110
	.long 0xd7000002                                           // 0000003885B0: D7000002
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 0000003885B4: 02020B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003885B8: BF8700A1
	v_add_co_ci_u32_e64 v3, null, 0, v8, s0                    // 0000003885BC: D5207C03 00021080
	.long 0xd7000005                                           // 0000003885C4: D7000005
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 0000003885C8: 02020D01
	v_add_co_ci_u32_e64 v6, null, 0, v8, s0                    // 0000003885CC: D5207C06 00021080
	.long 0xd700000a                                           // 0000003885D4: D700000A
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 0000003885D8: 02020901
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003885DC: BF870001
	v_add_co_ci_u32_e64 v11, null, 0, v8, s0                   // 0000003885E0: D5207C0B 00021080
	s_clause 0x2                                               // 0000003885E8: BF850002
	global_load_b128 v[1:4], v[2:3], off                       // 0000003885EC: DC5E0000 017C0002
	global_load_b64 v[5:6], v[5:6], off offset:160             // 0000003885F4: DC5600A0 057C0005
	global_load_b32 v8, v[10:11], off offset:240               // 0000003885FC: DC5200F0 087C000A
	s_or_b32 exec_lo, exec_lo, s2                              // 000000388604: 8C7E027E
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 000000388608: CA100080 0E0C0080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 000000388610: CA100080 0C0A0080
	v_mov_b32_e32 v10, 0                                       // 000000388618: 7E140280
	s_and_saveexec_b32 s0, vcc_lo                              // 00000038861C: BE80206A
	s_cbranch_execz 765                                        // 000000388620: BFA502FD <_ZN7halogen12_GLOBAL__N_18k_hcup6wILi6EEEvPKhPKtS5_PtPf+0xd18>
	v_lshlrev_b32_e32 v73, 6, v7                               // 000000388624: 30920E86
	s_waitcnt vmcnt(1)                                         // 000000388628: BF8907F7
	v_lshlrev_b32_e32 v33, 4, v5                               // 00000038862C: 30420A84
	v_lshlrev_b32_e32 v35, 2, v5                               // 000000388630: 30460A82
	v_lshrrev_b32_e32 v34, 4, v1                               // 000000388634: 32440284
	v_lshrrev_b32_e32 v36, 8, v1                               // 000000388638: 32480288
	s_waitcnt lgkmcnt(0)                                       // 00000038863C: BF89FC07
	s_clause 0x5                                               // 000000388640: BF850005
	global_load_b128 v[9:12], v73, s[6:7]                      // 000000388644: DC5E0000 09060049
	global_load_b128 v[13:16], v73, s[6:7] offset:640          // 00000038864C: DC5E0280 0D060049
	global_load_b128 v[17:20], v73, s[6:7] offset:1280         // 000000388654: DC5E0500 11060049
	global_load_b128 v[21:24], v73, s[6:7] offset:1920         // 00000038865C: DC5E0780 15060049
	global_load_b128 v[25:28], v73, s[6:7] offset:2560         // 000000388664: DC5E0A00 19060049
	global_load_b128 v[29:32], v73, s[6:7] offset:3200         // 00000038866C: DC5E0C80 1D060049
	v_and_b32_e32 v33, 48, v33                                 // 000000388674: 364242B0
	v_and_b32_e32 v37, 48, v5                                  // 000000388678: 364A0AB0
	v_lshrrev_b32_e32 v38, 2, v5                               // 00000038867C: 324C0A82
	v_and_b32_e32 v35, 48, v35                                 // 000000388680: 364646B0
	v_lshrrev_b32_e32 v39, 12, v1                              // 000000388684: 324E028C
	v_and_or_b32 v33, v1, 15, v33                              // 000000388688: D6570021 04851F01
	.long 0x7f9a3880                                           // 000000388690: 7F9A3880
	v_and_b32_e32 v38, 48, v38                                 // 000000388694: 364C4CB0
	v_and_or_b32 v34, v34, 15, v35                             // 000000388698: D6570022 048D1F22
	v_and_or_b32 v35, v36, 15, v37                             // 0000003886A0: D6570023 04951F24
	v_cvt_f32_ubyte0_e32 v33, v33                              // 0000003886A8: 7E422321
	v_lshrrev_b32_e32 v36, 4, v5                               // 0000003886AC: 32480A84
	v_and_or_b32 v37, v39, 15, v38                             // 0000003886B0: D6570025 04991F27
	v_cvt_f32_ubyte0_e32 v34, v34                              // 0000003886B8: 7E442322
	v_cvt_f32_ubyte0_e32 v35, v35                              // 0000003886BC: 7E462323
	s_waitcnt vmcnt(6)                                         // 0000003886C0: BF891BF7
	v_fma_mix_f32 v33, v33, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003886C4: CC206021 14221121
	v_lshrrev_b32_e32 v40, 8, v5                               // 0000003886CC: 32500A88
	v_cvt_f32_ubyte0_e32 v37, v37                              // 0000003886D0: 7E4A2325
	v_fma_mix_f32 v34, v34, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003886D4: CC206022 14221122
	v_fma_mix_f32 v35, v35, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003886DC: CC206023 14221123
	v_bfe_u32 v39, v33, 16, 1                                  // 0000003886E4: D6100027 02052121
	v_lshrrev_b32_e32 v41, 6, v5                               // 0000003886EC: 32520A86
	v_fma_mix_f32 v37, v37, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003886F0: CC206025 14221125
	v_bfe_u32 v42, v34, 16, 1                                  // 0000003886F8: D610002A 02052122
	v_and_b32_e32 v36, 48, v36                                 // 000000388700: 364848B0
	v_add3_u32 v33, v33, v39, 0x7fff                           // 000000388704: D6550021 03FE4F21 00007FFF
	v_bfe_u32 v39, v35, 16, 1                                  // 000000388710: D6100027 02052123
	v_bfe_u32 v44, v37, 16, 1                                  // 000000388718: D610002C 02052125
	v_add3_u32 v34, v34, v42, 0x7fff                           // 000000388720: D6550022 03FE5522 00007FFF
	v_lshrrev_b32_e32 v38, 20, v1                              // 00000038872C: 324C0294
	.long 0x7e9a39a1                                           // 000000388730: 7E9A39A1
	v_add3_u32 v33, v35, v39, 0x7fff                           // 000000388734: D6550021 03FE4F23 00007FFF
	v_add3_u32 v37, v37, v44, 0x7fff                           // 000000388740: D6550025 03FE5925 00007FFF
	v_lshrrev_b32_e32 v43, 24, v1                              // 00000038874C: 32560298
	v_and_b32_e32 v41, 48, v41                                 // 000000388750: 365252B0
	v_and_or_b32 v61, 0xffff0000, v34, v77                     // 000000388754: D657003D 053644FF FFFF0000
	.long 0x7e9a39a1                                           // 000000388760: 7E9A39A1
	v_and_b32_e32 v40, 48, v40                                 // 000000388764: 365050B0
	v_lshrrev_b32_e32 v39, 28, v1                              // 000000388768: 324E029C
	v_lshrrev_b32_e32 v33, 10, v5                              // 00000038876C: 32420A8A
	v_and_or_b32 v38, v38, 15, v41                             // 000000388770: D6570026 04A51F26
	v_and_or_b32 v63, 0xffff0000, v37, v77                     // 000000388778: D657003F 05364AFF FFFF0000
	.long 0x7e9a3981                                           // 000000388784: 7E9A3981
	v_and_or_b32 v40, v43, 15, v40                             // 000000388788: D6570028 04A11F2B
	v_and_or_b32 v33, v33, 48, v39                             // 000000388790: D6570021 049D6121
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000388798: 7E4C2326
	v_lshrrev_b32_e32 v1, 8, v2                                // 00000038879C: 32020488
	v_and_or_b32 v36, v77, 15, v36                             // 0000003887A0: D6570024 04911F4D
	v_cvt_f32_ubyte0_e32 v39, v40                              // 0000003887A8: 7E4E2328
	v_cvt_f32_ubyte0_e32 v33, v33                              // 0000003887AC: 7E422321
	v_fma_mix_f32 v38, v38, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003887B0: CC206026 14221126
	v_lshrrev_b32_e32 v44, 18, v5                              // 0000003887B8: 32580A92
	v_cvt_f32_ubyte0_e32 v36, v36                              // 0000003887BC: 7E482324
	v_fma_mix_f32 v39, v39, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003887C0: CC206027 14221127
	v_fma_mix_f32 v33, v33, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003887C8: CC206021 14221121
	v_bfe_u32 v47, v38, 16, 1                                  // 0000003887D0: D610002F 02052126
	v_lshrrev_b32_e32 v42, 12, v2                              // 0000003887D8: 3254048C
	v_fma_mix_f32 v36, v36, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003887DC: CC206024 14221124
	v_and_b32_e32 v44, 48, v44                                 // 0000003887E4: 365858B0
	v_bfe_u32 v49, v33, 16, 1                                  // 0000003887E8: D6100031 02052121
	v_add3_u32 v38, v38, v47, 0x7fff                           // 0000003887F0: D6550026 03FE5F26 00007FFF
	v_lshrrev_b32_e32 v37, 20, v5                              // 0000003887FC: 324A0A94
	v_bfe_u32 v43, v36, 16, 1                                  // 000000388800: D610002B 02052124
	v_and_or_b32 v42, v42, 15, v44                             // 000000388808: D657002A 04B11F2A
	v_add3_u32 v33, v33, v49, 0x7fff                           // 000000388810: D6550021 03FE6321 00007FFF
	v_lshrrev_b32_e32 v45, 24, v5                              // 00000038881C: 325A0A98
	v_lshrrev_b32_e32 v40, 22, v5                              // 000000388820: 32500A96
	v_add3_u32 v36, v36, v43, 0x7fff                           // 000000388824: D6550024 03FE5724 00007FFF
	v_bfe_u32 v43, v39, 16, 1                                  // 000000388830: D610002B 02052127
	v_cvt_f32_ubyte0_e32 v42, v42                              // 000000388838: 7E54232A
	v_and_b32_e32 v37, 48, v37                                 // 00000038883C: 364A4AB0
	v_lshrrev_b32_e32 v41, 20, v2                              // 000000388840: 32520494
	.long 0x7e9a39a4                                           // 000000388844: 7E9A39A4
	v_add3_u32 v36, v39, v43, 0x7fff                           // 000000388848: D6550024 03FE5727 00007FFF
	v_fma_mix_f32 v42, v42, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388854: CC20602A 1422112A
	v_lshrrev_b32_e32 v46, 24, v2                              // 00000038885C: 325C0498
	v_lshrrev_b32_e32 v48, 28, v2                              // 000000388860: 3260049C
	v_and_or_b32 v64, 0xffff0000, v38, v77                     // 000000388864: D6570040 05364CFF FFFF0000
	.long 0x7e9a39a4                                           // 000000388870: 7E9A39A4
	v_bfe_u32 v72, v42, 16, 1                                  // 000000388874: D6100048 0205212A
	v_lshrrev_b32_e32 v39, 26, v5                              // 00000038887C: 324E0A9A
	v_lshlrev_b32_e32 v43, 4, v6                               // 000000388880: 30560C84
	v_lshlrev_b32_e32 v38, 2, v6                               // 000000388884: 304C0C82
	v_and_or_b32 v65, 0xffff0000, v33, v77                     // 000000388888: D6570041 053642FF FFFF0000
	.long 0x7e9a3985                                           // 000000388894: 7E9A3985
	v_add3_u32 v42, v42, v72, 0x7fff                           // 000000388898: D655002A 03FE912A 00007FFF
	v_and_b32_e32 v40, 48, v40                                 // 0000003888A4: 365050B0
	v_and_b32_e32 v45, 48, v45                                 // 0000003888A8: 365A5AB0
	v_lshrrev_b32_e32 v36, 4, v3                               // 0000003888AC: 32480684
	v_and_b32_e32 v52, 48, v77                                 // 0000003888B0: 36689AB0
	v_and_b32_e32 v38, 48, v38                                 // 0000003888B4: 364C4CB0
	v_and_or_b32 v40, v41, 15, v40                             // 0000003888B8: D6570028 04A11F29
	v_and_or_b32 v41, v46, 15, v45                             // 0000003888C0: D6570029 04B51F2E
	v_lshrrev_b32_e32 v47, 8, v3                               // 0000003888C8: 325E0688
	v_and_or_b32 v1, v1, 15, v52                               // 0000003888CC: D6570001 04D11F01
	v_and_b32_e32 v49, 48, v6                                  // 0000003888D4: 36620CB0
	v_lshrrev_b32_e32 v33, 2, v6                               // 0000003888D8: 32420C82
	v_and_or_b32 v36, v36, 15, v38                             // 0000003888DC: D6570024 04991F24
	v_cvt_f32_ubyte0_e32 v38, v40                              // 0000003888E4: 7E4C2328
	v_cvt_f32_ubyte0_e32 v1, v1                                // 0000003888E8: 7E022301
	v_cvt_f32_ubyte0_e32 v40, v41                              // 0000003888EC: 7E502329
	v_lshrrev_b32_e32 v35, 12, v5                              // 0000003888F0: 32460A8C
	v_lshrrev_b32_e32 v34, 14, v5                              // 0000003888F4: 32440A8E
	v_lshrrev_b32_e32 v5, 12, v3                               // 0000003888F8: 320A068C
	v_fma_mix_f32 v1, v1, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003888FC: CC206001 14221101
	v_and_b32_e32 v33, 48, v33                                 // 000000388904: 364242B0
	v_fma_mix_f32 v38, v38, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388908: CC206026 14221126
	v_fma_mix_f32 v40, v40, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388910: CC206028 14221128
	v_cvt_f32_ubyte0_e32 v36, v36                              // 000000388918: 7E482324
	v_bfe_u32 v60, v1, 16, 1                                   // 00000038891C: D610003C 02052101
	v_and_or_b32 v5, v5, 15, v33                               // 000000388924: D6570005 04851F05
	v_lshrrev_b32_e32 v51, 4, v6                               // 00000038892C: 32660C84
	v_lshrrev_b32_e32 v50, 8, v6                               // 000000388930: 32640C88
	v_fma_mix_f32 v36, v36, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388934: CC206024 14221124
	v_add3_u32 v1, v1, v60, 0x7fff                             // 00000038893C: D6550001 03FE7901 00007FFF
	v_cvt_f32_ubyte0_e32 v5, v5                                // 000000388948: 7E0A2305
	v_lshrrev_b32_e32 v54, 6, v6                               // 00000038894C: 326C0C86
	v_and_b32_e32 v74, 48, v35                                 // 000000388950: 369446B0
	v_and_b32_e32 v35, 48, v51                                 // 000000388954: 364666B0
	.long 0x7e9a3981                                           // 000000388958: 7E9A3981
	v_and_or_b32 v1, v39, 48, v48                              // 00000038895C: D6570001 04C16127
	v_and_b32_e32 v39, 48, v43                                 // 000000388964: 364E56B0
	v_and_or_b32 v43, v47, 15, v49                             // 000000388968: D657002B 04C51F2F
	v_fma_mix_f32 v5, v5, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388970: CC206005 14221105
	v_and_or_b32 v78, 0xffff0000, v42, v77                     // 000000388978: D657004E 053654FF FFFF0000
	.long 0x7e9a3982                                           // 000000388984: 7E9A3982
	v_and_or_b32 v39, v3, 15, v39                              // 000000388988: D6570027 049D1F03
	v_cvt_f32_ubyte0_e32 v1, v1                                // 000000388990: 7E022301
	v_cvt_f32_ubyte0_e32 v33, v43                              // 000000388994: 7E42232B
	v_bfe_u32 v43, v38, 16, 1                                  // 000000388998: D610002B 02052126
	v_and_or_b32 v37, v77, 15, v37                             // 0000003889A0: D6570025 04951F4D
	v_cvt_f32_ubyte0_e32 v39, v39                              // 0000003889A8: 7E4E2327
	v_fma_mix_f32 v1, v1, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003889AC: CC206001 14221101
	v_fma_mix_f32 v33, v33, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003889B4: CC206021 14221121
	v_add3_u32 v38, v38, v43, 0x7fff                           // 0000003889BC: D6550026 03FE5726 00007FFF
	v_cvt_f32_ubyte0_e32 v37, v37                              // 0000003889C8: 7E4A2325
	v_fma_mix_f32 v39, v39, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003889CC: CC206027 14221127
	v_bfe_u32 v42, v1, 16, 1                                   // 0000003889D4: D610002A 02052101
	v_lshrrev_b32_e32 v53, 20, v3                              // 0000003889DC: 326A0694
	v_lshrrev_b32_e32 v55, 24, v3                              // 0000003889E0: 326E0698
	v_fma_mix_f32 v37, v37, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003889E4: CC206025 14221125
	v_lshrrev_b32_e32 v56, 28, v3                              // 0000003889EC: 3270069C
	v_add3_u32 v1, v1, v42, 0x7fff                             // 0000003889F0: D6550001 03FE5501 00007FFF
	v_lshrrev_b32_e32 v57, 10, v6                              // 0000003889FC: 32720C8A
	v_lshrrev_b32_e32 v67, 8, v4                               // 000000388A00: 32860888
	v_bfe_u32 v41, v37, 16, 1                                  // 000000388A04: D6100029 02052125
	v_lshrrev_b32_e32 v69, 18, v6                              // 000000388A0C: 328A0C92
	v_lshrrev_b32_e32 v68, 12, v4                              // 000000388A10: 3288088C
	v_lshrrev_b32_e32 v52, 12, v6                              // 000000388A14: 32680C8C
	v_lshrrev_b32_e32 v58, 14, v6                              // 000000388A18: 32740C8E
	v_add3_u32 v37, v37, v41, 0x7fff                           // 000000388A1C: D6550025 03FE5325 00007FFF
	v_bfe_u32 v41, v40, 16, 1                                  // 000000388A28: D6100029 02052128
	v_and_b32_e32 v69, 48, v69                                 // 000000388A30: 368A8AB0
	v_lshrrev_b32_e32 v59, 20, v6                              // 000000388A34: 32760C94
	v_lshrrev_b32_e32 v70, 24, v6                              // 000000388A38: 328C0C98
	.long 0x7e9a39a5                                           // 000000388A3C: 7E9A39A5
	v_add3_u32 v37, v40, v41, 0x7fff                           // 000000388A40: D6550025 03FE5328 00007FFF
	v_bfe_u32 v40, v39, 16, 1                                  // 000000388A4C: D6100028 02052127
	v_bfe_u32 v41, v36, 16, 1                                  // 000000388A54: D6100029 02052124
	v_and_or_b32 v68, v68, 15, v69                             // 000000388A5C: D6570044 05151F44
	v_and_or_b32 v79, 0xffff0000, v38, v77                     // 000000388A64: D657004F 05364CFF FFFF0000
	.long 0x7e9a39a5                                           // 000000388A70: 7E9A39A5
	v_add3_u32 v37, v39, v40, 0x7fff                           // 000000388A74: D6550025 03FE5127 00007FFF
	v_bfe_u32 v38, v33, 16, 1                                  // 000000388A80: D6100026 02052121
	v_bfe_u32 v39, v5, 16, 1                                   // 000000388A88: D6100027 02052105
	v_add3_u32 v36, v36, v41, 0x7fff                           // 000000388A90: D6550024 03FE5324 00007FFF
	v_and_or_b32 v80, 0xffff0000, v1, v77                      // 000000388A9C: D6570050 053602FF FFFF0000
	.long 0x7e9a39a5                                           // 000000388AA8: 7E9A39A5
	v_add3_u32 v1, v33, v38, 0x7fff                            // 000000388AAC: D6550001 03FE4D21 00007FFF
	v_add3_u32 v5, v5, v39, 0x7fff                             // 000000388AB8: D6550005 03FE4F05 00007FFF
	v_and_b32_e32 v37, 48, v50                                 // 000000388AC4: 364A64B0
	v_lshrrev_b32_e32 v33, 22, v6                              // 000000388AC8: 32420C96
	v_and_or_b32 v81, 0xffff0000, v36, v77                     // 000000388ACC: D6570051 053648FF FFFF0000
	.long 0x7e9a3981                                           // 000000388AD8: 7E9A3981
	v_and_or_b32 v38, v57, 48, v56                             // 000000388ADC: D6570026 04E16139
	v_and_or_b32 v37, v55, 15, v37                             // 000000388AE4: D6570025 04951F37
	v_and_b32_e32 v85, 48, v33                                 // 000000388AEC: 36AA42B0
	v_lshrrev_b32_e32 v36, 26, v6                              // 000000388AF0: 32480C9A
	v_and_or_b32 v5, 0xffff0000, v5, v77                       // 000000388AF4: D6570005 05360AFF FFFF0000
	.long 0x7e9a3983                                           // 000000388B00: 7E9A3983
	v_and_b32_e32 v3, 48, v34                                  // 000000388B04: 360644B0
	v_and_b32_e32 v34, 48, v54                                 // 000000388B08: 36446CB0
	v_cvt_f32_ubyte0_e32 v37, v37                              // 000000388B0C: 7E4A2325
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000388B10: 7E4C2326
	v_and_or_b32 v35, v77, 15, v35                             // 000000388B14: D6570023 048D1F4D
	v_lshrrev_b32_e32 v66, 4, v4                               // 000000388B1C: 32840884
	v_and_or_b32 v34, v53, 15, v34                             // 000000388B20: D6570022 04891F35
	v_fma_mix_f32 v33, v37, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388B28: CC206021 14221125
	v_fma_mix_f32 v37, v38, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388B30: CC206025 14221126
	v_cvt_f32_ubyte0_e32 v35, v35                              // 000000388B38: 7E462323
	v_and_b32_e32 v82, 48, v58                                 // 000000388B3C: 36A474B0
	v_cvt_f32_ubyte0_e32 v34, v34                              // 000000388B40: 7E442322
	v_and_b32_e32 v44, 15, v4                                  // 000000388B44: 3658088F
	v_bfe_u32 v40, v37, 16, 1                                  // 000000388B48: D6100028 02052125
	v_fma_mix_f32 v35, v35, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388B50: CC206023 14221123
	v_lshrrev_b32_e32 v72, 24, v4                              // 000000388B58: 32900898
	v_fma_mix_f32 v34, v34, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388B5C: CC206022 14221122
	v_lshrrev_b32_e32 v1, 28, v4                               // 000000388B64: 3202089C
	v_add3_u32 v49, v37, v40, 0x7fff                           // 000000388B68: D6550031 03FE5125 00007FFF
	v_bfe_u32 v39, v35, 16, 1                                  // 000000388B74: D6100027 02052123
	v_and_b32_e32 v70, 48, v70                                 // 000000388B7C: 368C8CB0
	v_bfe_u32 v38, v34, 16, 1                                  // 000000388B80: D6100026 02052122
	v_and_or_b32 v69, v66, 15, v82                             // 000000388B88: D6570045 05491F42
	v_lshrrev_b32_e32 v71, 20, v4                              // 000000388B90: 328E0894
	v_add3_u32 v35, v35, v39, 0x7fff                           // 000000388B94: D6550023 03FE4F23 00007FFF
	v_bfe_u32 v39, v33, 16, 1                                  // 000000388BA0: D6100027 02052121
	v_add3_u32 v38, v34, v38, 0x7fff                           // 000000388BA8: D6550026 03FE4D22 00007FFF
	v_and_or_b32 v76, v52, 48, v44                             // 000000388BB4: D657004C 04B16134
	v_and_b32_e32 v84, 48, v59                                 // 000000388BBC: 36A876B0
	.long 0x7e9a39a3                                           // 000000388BC0: 7E9A39A3
	v_add3_u32 v39, v33, v39, 0x7fff                           // 000000388BC4: D6550027 03FE4F21 00007FFF
	v_and_or_b32 v1, v36, 48, v1                               // 000000388BD0: D6570001 04056124
	s_clause 0x1                                               // 000000388BD8: BF850001
	global_load_b128 v[33:36], v73, s[6:7] offset:16           // 000000388BDC: DC5E0010 21060049
	global_load_b128 v[57:60], v73, s[6:7] offset:2576         // 000000388BE4: DC5E0A10 39060049
	v_and_or_b32 v86, 0xffff0000, v38, v77                     // 000000388BEC: D6570056 05364CFF FFFF0000
	.long 0x7e9a39a7                                           // 000000388BF8: 7E9A39A7
	s_clause 0x2                                               // 000000388BFC: BF850002
	global_load_b128 v[37:40], v73, s[6:7] offset:32           // 000000388C00: DC5E0020 25060049
	global_load_b128 v[41:44], v73, s[6:7] offset:48           // 000000388C08: DC5E0030 29060049
	global_load_b128 v[45:48], v73, s[6:7] offset:656          // 000000388C10: DC5E0290 2D060049
	v_and_or_b32 v70, v72, 15, v70                             // 000000388C18: D6570046 05191F48
	v_and_or_b32 v71, v71, 15, v85                             // 000000388C20: D6570047 05551F47
	v_lshrrev_b32_e32 v62, 4, v2                               // 000000388C28: 327C0484
	v_and_or_b32 v87, 0xffff0000, v49, v77                     // 000000388C2C: D6570057 053662FF FFFF0000
	.long 0x7e9a3986                                           // 000000388C38: 7E9A3986
	s_clause 0x1                                               // 000000388C3C: BF850001
	global_load_b128 v[49:52], v73, s[6:7] offset:1296         // 000000388C40: DC5E0510 31060049
	global_load_b128 v[53:56], v73, s[6:7] offset:1936         // 000000388C48: DC5E0790 35060049
	v_and_or_b32 v2, v2, 15, v74                               // 000000388C50: D6570002 05291F02
	v_cvt_f32_ubyte0_e32 v74, v76                              // 000000388C58: 7E94234C
	v_cvt_f32_ubyte0_e32 v1, v1                                // 000000388C5C: 7E022301
	v_and_b32_e32 v88, 48, v77                                 // 000000388C60: 36B09AB0
	v_and_or_b32 v3, v62, 15, v3                               // 000000388C64: D6570003 040D1F3E
	v_cvt_f32_ubyte0_e32 v2, v2                                // 000000388C6C: 7E042302
	v_fma_mix_f32 v74, v74, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388C70: CC20604A 1422114A
	v_fma_mix_f32 v1, v1, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388C78: CC206001 14221101
	v_and_or_b32 v67, v67, 15, v88                             // 000000388C80: D6570043 05611F43
	v_cvt_f32_ubyte0_e32 v3, v3                                // 000000388C88: 7E062303
	v_cvt_f32_ubyte0_e32 v69, v69                              // 000000388C8C: 7E8A2345
	v_cvt_f32_ubyte0_e32 v70, v70                              // 000000388C90: 7E8C2346
	v_fma_mix_f32 v2, v2, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388C94: CC206002 14221102
	.long 0x7f9639cd                                           // 000000388C9C: 7F9639CD
	v_fma_mix_f32 v3, v3, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388CA0: CC206003 14221103
	v_fma_mix_f32 v69, v69, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388CA8: CC206045 14221145
	v_fma_mix_f32 v70, v70, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388CB0: CC206046 14221146
	.long 0x7fa639cd                                           // 000000388CB8: 7FA639CD
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000388CBC: BF870094
	v_bfe_u32 v85, v3, 16, 1                                   // 000000388CC0: D6100055 02052103
	v_add3_u32 v85, v3, v85, 0x7fff                            // 000000388CC8: D6550055 03FEAB03 00007FFF
	s_waitcnt vmcnt(12)                                        // 000000388CD4: BF8933F7
	v_dot2_f32_bf16 v9, v9, v61, 0                             // 000000388CD8: CC1A4009 1A027B09
	s_waitcnt vmcnt(11)                                        // 000000388CE0: BF892FF7
	v_dot2_f32_bf16 v13, v13, v61, 0                           // 000000388CE4: CC1A400D 1A027B0D
	s_waitcnt vmcnt(10)                                        // 000000388CEC: BF892BF7
	v_dot2_f32_bf16 v17, v17, v61, 0                           // 000000388CF0: CC1A4011 1A027B11
	v_dot2_f32_bf16 v9, v10, v63, v9                           // 000000388CF8: CC1A4009 1C267F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000388D00: BF870193
	v_dot2_f32_bf16 v13, v14, v63, v13                         // 000000388D04: CC1A400D 1C367F0E
	v_dot2_f32_bf16 v14, v18, v63, v17                         // 000000388D0C: CC1A400E 1C467F12
	s_waitcnt vmcnt(9)                                         // 000000388D14: BF8927F7
	v_dot2_f32_bf16 v17, v21, v61, 0                           // 000000388D18: CC1A4011 1A027B15
	s_waitcnt vmcnt(8)                                         // 000000388D20: BF8923F7
	v_dot2_f32_bf16 v18, v25, v61, 0                           // 000000388D24: CC1A4012 1A027B19
	s_waitcnt vmcnt(7)                                         // 000000388D2C: BF891FF7
	v_dot2_f32_bf16 v21, v29, v61, 0                           // 000000388D30: CC1A4015 1A027B1D
	v_dot2_f32_bf16 v6, v11, v64, v9                           // 000000388D38: CC1A4006 1C26810B
	v_dot2_f32_bf16 v13, v15, v64, v13                         // 000000388D40: CC1A400D 1C36810F
	v_dot2_f32_bf16 v22, v22, v63, v17                         // 000000388D48: CC1A4016 1C467F16
	v_dot2_f32_bf16 v25, v26, v63, v18                         // 000000388D50: CC1A4019 1C4A7F1A
	v_cvt_f32_ubyte0_e32 v26, v67                              // 000000388D58: 7E342343
	v_dot2_f32_bf16 v21, v30, v63, v21                         // 000000388D5C: CC1A4015 1C567F1E
	v_dot2_f32_bf16 v14, v19, v64, v14                         // 000000388D64: CC1A400E 1C3A8113
	v_dot2_f32_bf16 v22, v23, v64, v22                         // 000000388D6C: CC1A4016 1C5A8117
	v_dot2_f32_bf16 v23, v27, v64, v25                         // 000000388D74: CC1A4017 1C66811B
	v_cvt_f32_ubyte0_e32 v61, v68                              // 000000388D7C: 7E7A2344
	v_fma_mix_f32 v67, v26, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388D80: CC206043 1422111A
	v_dot2_f32_bf16 v29, v31, v64, v21                         // 000000388D88: CC1A401D 1C56811F
	v_dot2_f32_bf16 v6, v12, v65, v6                           // 000000388D90: CC1A4006 1C1A830C
	v_dot2_f32_bf16 v88, v16, v65, v13                         // 000000388D98: CC1A4058 1C368310
	v_dot2_f32_bf16 v89, v20, v65, v14                         // 000000388DA0: CC1A4059 1C3A8314
	v_dot2_f32_bf16 v90, v24, v65, v22                         // 000000388DA8: CC1A405A 1C5A8318
	v_dot2_f32_bf16 v91, v28, v65, v23                         // 000000388DB0: CC1A405B 1C5E831C
	v_dot2_f32_bf16 v92, v32, v65, v29                         // 000000388DB8: CC1A405C 1C768320
	v_bfe_u32 v65, v67, 16, 1                                  // 000000388DC0: D6100041 02052143
	v_fma_mix_f32 v68, v61, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388DC8: CC206044 1422113D
	s_clause 0x2                                               // 000000388DD0: BF850002
	global_load_b128 v[9:12], v73, s[6:7] offset:3216          // 000000388DD4: DC5E0C90 09060049
	global_load_b128 v[29:32], v73, s[6:7] offset:1952         // 000000388DDC: DC5E07A0 1D060049
	global_load_b128 v[61:64], v73, s[6:7] offset:2592         // 000000388DE4: DC5E0A20 3D060049
	v_add3_u32 v65, v67, v65, 0x7fff                           // 000000388DEC: D6550041 03FE8343 00007FFF
	v_bfe_u32 v66, v68, 16, 1                                  // 000000388DF8: D6100042 02052144
	s_clause 0x3                                               // 000000388E00: BF850003
	global_load_b128 v[13:16], v73, s[6:7] offset:672          // 000000388E04: DC5E02A0 0D060049
	global_load_b128 v[17:20], v73, s[6:7] offset:688          // 000000388E0C: DC5E02B0 11060049
	global_load_b128 v[21:24], v73, s[6:7] offset:1312         // 000000388E14: DC5E0520 15060049
	global_load_b128 v[25:28], v73, s[6:7] offset:1328         // 000000388E1C: DC5E0530 19060049
	.long 0x7e9a39c1                                           // 000000388E24: 7E9A39C1
	v_add3_u32 v72, v68, v66, 0x7fff                           // 000000388E28: D6550048 03FE8544 00007FFF
	global_load_b128 v[65:68], v73, s[6:7] offset:3232         // 000000388E34: DC5E0CA0 41060049
	v_and_or_b32 v82, 0xffff0000, v72, v77                     // 000000388E3C: D6570052 053690FF FFFF0000
	.long 0x7e9a3984                                           // 000000388E48: 7E9A3984
	v_cvt_f32_ubyte0_e32 v4, v71                               // 000000388E4C: 7E082347
	v_bfe_u32 v72, v74, 16, 1                                  // 000000388E50: D6100048 0205214A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000388E58: BF870193
	v_and_or_b32 v71, v77, 15, v84                             // 000000388E5C: D6570047 05511F4D
	v_fma_mix_f32 v76, v4, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388E64: CC20604C 14221104
	v_bfe_u32 v84, v2, 16, 1                                   // 000000388E6C: D6100054 02052102
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000388E74: BF870123
	v_cvt_f32_ubyte0_e32 v4, v71                               // 000000388E78: 7E082347
	v_bfe_u32 v71, v1, 16, 1                                   // 000000388E7C: D6100047 02052101
	v_fma_mix_f32 v4, v4, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000388E84: CC206004 14221104
	v_add3_u32 v8, v74, v72, 0x7fff                            // 000000388E8C: D6550008 03FE914A 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000388E98: BF870003
	v_add3_u32 v93, v1, v71, 0x7fff                            // 000000388E9C: D655005D 03FE8F01 00007FFF
	v_bfe_u32 v74, v76, 16, 1                                  // 000000388EA8: D610004A 0205214C
	v_add3_u32 v71, v2, v84, 0x7fff                            // 000000388EB0: D6550047 03FEA902 00007FFF
	v_bfe_u32 v1, v4, 16, 1                                    // 000000388EBC: D6100001 02052104
	.long 0x7ea63988                                           // 000000388EC4: 7EA63988
	v_bfe_u32 v72, v69, 16, 1                                  // 000000388EC8: D6100048 02052145
	v_bfe_u32 v84, v70, 16, 1                                  // 000000388ED0: D6100054 02052146
	v_add3_u32 v74, v76, v74, 0x7fff                           // 000000388ED8: D655004A 03FE954C 00007FFF
	v_add3_u32 v8, v4, v1, 0x7fff                              // 000000388EE4: D6550008 03FE0304 00007FFF
	.long 0x7e9639c7                                           // 000000388EF0: 7E9639C7
	v_add3_u32 v94, v69, v72, 0x7fff                           // 000000388EF4: D655005E 03FE9145 00007FFF
	global_load_b128 v[1:4], v73, s[6:7] offset:1968           // 000000388F00: DC5E07B0 01060049
	.long 0x7e9a3988                                           // 000000388F08: 7E9A3988
	v_add3_u32 v8, v70, v84, 0x7fff                            // 000000388F0C: D6550008 03FEA946 00007FFF
	global_load_b128 v[69:72], v73, s[6:7] offset:2608         // 000000388F18: DC5E0A30 45060049
	v_and_or_b32 v84, 0xffff0000, v85, v75                     // 000000388F20: D6570054 052EAAFF FFFF0000
	v_and_or_b32 v83, 0xffff0000, v94, v83                     // 000000388F2C: D6570053 054EBCFF FFFF0000
	v_and_or_b32 v85, 0xffff0000, v74, v77                     // 000000388F38: D6570055 053694FF FFFF0000
	global_load_b128 v[73:76], v73, s[6:7] offset:3248         // 000000388F44: DC5E0CB0 49060049
	.long 0x7e9a3988                                           // 000000388F4C: 7E9A3988
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000388F50: BF870151
	v_and_or_b32 v8, 0xffff0000, v93, v77                      // 000000388F54: D6570008 0536BAFF FFFF0000
	s_waitcnt vmcnt(17)                                        // 000000388F60: BF8947F7
	v_dot2_f32_bf16 v6, v33, v84, v6                           // 000000388F64: CC1A4006 1C1AA921
	s_waitcnt vmcnt(13)                                        // 000000388F6C: BF8937F7
	v_dot2_f32_bf16 v33, v45, v84, v88                         // 000000388F70: CC1A4021 1D62A92D
	v_dot2_f32_bf16 v6, v34, v78, v6                           // 000000388F78: CC1A4006 1C1A9D22
	s_waitcnt vmcnt(12)                                        // 000000388F80: BF8933F7
	v_dot2_f32_bf16 v45, v49, v84, v89                         // 000000388F84: CC1A402D 1D66A931
	s_waitcnt vmcnt(11)                                        // 000000388F8C: BF892FF7
	v_dot2_f32_bf16 v49, v53, v84, v90                         // 000000388F90: CC1A4031 1D6AA935
	v_dot2_f32_bf16 v53, v57, v84, v91                         // 000000388F98: CC1A4035 1D6EA939
	v_dot2_f32_bf16 v33, v46, v78, v33                         // 000000388FA0: CC1A4021 1C869D2E
	v_dot2_f32_bf16 v6, v35, v79, v6                           // 000000388FA8: CC1A4006 1C1A9F23
	v_dot2_f32_bf16 v34, v50, v78, v45                         // 000000388FB0: CC1A4022 1CB69D32
	v_dot2_f32_bf16 v45, v54, v78, v49                         // 000000388FB8: CC1A402D 1CC69D36
	v_dot2_f32_bf16 v46, v58, v78, v53                         // 000000388FC0: CC1A402E 1CD69D3A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000388FC8: BF870114
	v_dot2_f32_bf16 v6, v36, v80, v6                           // 000000388FCC: CC1A4006 1C1AA124
	v_dot2_f32_bf16 v35, v59, v79, v46                         // 000000388FD4: CC1A4023 1CBA9F3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000388FDC: BF870092
	v_dot2_f32_bf16 v6, v37, v81, v6                           // 000000388FE0: CC1A4006 1C1AA325
	v_dot2_f32_bf16 v6, v38, v5, v6                            // 000000388FE8: CC1A4006 1C1A0B26
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000388FF0: BF870091
	v_dot2_f32_bf16 v6, v39, v86, v6                           // 000000388FF4: CC1A4006 1C1AAD27
	v_dot2_f32_bf16 v6, v40, v87, v6                           // 000000388FFC: CC1A4006 1C1AAF28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000389004: BF870091
	v_dot2_f32_bf16 v6, v41, v83, v6                           // 000000389008: CC1A4006 1C1AA729
	v_dot2_f32_bf16 v6, v42, v82, v6                           // 000000389010: CC1A4006 1C1AA52A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000389018: BF8700B1
	v_dot2_f32_bf16 v6, v43, v85, v6                           // 00000038901C: CC1A4006 1C1AAB2B
	s_waitcnt vmcnt(10)                                        // 000000389024: BF892BF7
	v_dot2_f32_bf16 v9, v9, v84, v92                           // 000000389028: CC1A4009 1D72A909
	v_dot2_f32_bf16 v9, v10, v78, v9                           // 000000389030: CC1A4009 1C269D0A
	v_dot2_f32_bf16 v10, v47, v79, v33                         // 000000389038: CC1A400A 1C869F2F
	v_dot2_f32_bf16 v33, v51, v79, v34                         // 000000389040: CC1A4021 1C8A9F33
	v_dot2_f32_bf16 v34, v55, v79, v45                         // 000000389048: CC1A4022 1CB69F37
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000389050: BF870214
	v_dot2_f32_bf16 v9, v11, v79, v9                           // 000000389054: CC1A4009 1C269F0B
	v_dot2_f32_bf16 v10, v48, v80, v10                         // 00000038905C: CC1A400A 1C2AA130
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000389064: BF870214
	v_dot2_f32_bf16 v11, v52, v80, v33                         // 000000389068: CC1A400B 1C86A134
	v_dot2_f32_bf16 v33, v56, v80, v34                         // 000000389070: CC1A4021 1C8AA138
	v_dot2_f32_bf16 v34, v60, v80, v35                         // 000000389078: CC1A4022 1C8EA13C
	v_dot2_f32_bf16 v9, v12, v80, v9                           // 000000389080: CC1A4009 1C26A10C
	s_waitcnt vmcnt(7)                                         // 000000389088: BF891FF7
	v_dot2_f32_bf16 v10, v13, v81, v10                         // 00000038908C: CC1A400A 1C2AA30D
	s_waitcnt vmcnt(5)                                         // 000000389094: BF8917F7
	v_dot2_f32_bf16 v11, v21, v81, v11                         // 000000389098: CC1A400B 1C2EA315
	v_dot2_f32_bf16 v12, v29, v81, v33                         // 0000003890A0: CC1A400C 1C86A31D
	v_dot2_f32_bf16 v13, v61, v81, v34                         // 0000003890A8: CC1A400D 1C8AA33D
	s_waitcnt vmcnt(3)                                         // 0000003890B0: BF890FF7
	v_dot2_f32_bf16 v9, v65, v81, v9                           // 0000003890B4: CC1A4009 1C26A341
	v_dot2_f32_bf16 v10, v14, v5, v10                          // 0000003890BC: CC1A400A 1C2A0B0E
	v_dot2_f32_bf16 v11, v22, v5, v11                          // 0000003890C4: CC1A400B 1C2E0B16
	v_dot2_f32_bf16 v12, v30, v5, v12                          // 0000003890CC: CC1A400C 1C320B1E
	v_dot2_f32_bf16 v13, v62, v5, v13                          // 0000003890D4: CC1A400D 1C360B3E
	v_dot2_f32_bf16 v5, v66, v5, v9                            // 0000003890DC: CC1A4005 1C260B42
	v_dot2_f32_bf16 v9, v15, v86, v10                          // 0000003890E4: CC1A4009 1C2AAD0F
	v_dot2_f32_bf16 v10, v23, v86, v11                         // 0000003890EC: CC1A400A 1C2EAD17
	v_dot2_f32_bf16 v11, v31, v86, v12                         // 0000003890F4: CC1A400B 1C32AD1F
	v_dot2_f32_bf16 v12, v63, v86, v13                         // 0000003890FC: CC1A400C 1C36AD3F
	v_dot2_f32_bf16 v5, v67, v86, v5                           // 000000389104: CC1A4005 1C16AD43
	v_dot2_f32_bf16 v9, v16, v87, v9                           // 00000038910C: CC1A4009 1C26AF10
	v_dot2_f32_bf16 v10, v24, v87, v10                         // 000000389114: CC1A400A 1C2AAF18
	v_dot2_f32_bf16 v11, v32, v87, v11                         // 00000038911C: CC1A400B 1C2EAF20
	v_dot2_f32_bf16 v12, v64, v87, v12                         // 000000389124: CC1A400C 1C32AF40
	v_dot2_f32_bf16 v5, v68, v87, v5                           // 00000038912C: CC1A4005 1C16AF44
	v_dot2_f32_bf16 v9, v17, v83, v9                           // 000000389134: CC1A4009 1C26A711
	v_dot2_f32_bf16 v10, v25, v83, v10                         // 00000038913C: CC1A400A 1C2AA719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000389144: BF870112
	v_dot2_f32_bf16 v9, v18, v82, v9                           // 000000389148: CC1A4009 1C26A512
	v_dot2_f32_bf16 v10, v26, v82, v10                         // 000000389150: CC1A400A 1C2AA51A
	s_waitcnt vmcnt(2)                                         // 000000389158: BF890BF7
	v_dot2_f32_bf16 v1, v1, v83, v11                           // 00000038915C: CC1A4001 1C2EA701
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000389164: BF8701B3
	v_dot2_f32_bf16 v9, v19, v85, v9                           // 000000389168: CC1A4009 1C26AB13
	s_waitcnt vmcnt(1)                                         // 000000389170: BF8907F7
	v_dot2_f32_bf16 v11, v69, v83, v12                         // 000000389174: CC1A400B 1C32A745
	v_dot2_f32_bf16 v1, v2, v82, v1                            // 00000038917C: CC1A4001 1C06A502
	v_dot2_f32_bf16 v10, v27, v85, v10                         // 000000389184: CC1A400A 1C2AAB1B
	s_waitcnt vmcnt(0)                                         // 00000038918C: BF8903F7
	v_dot2_f32_bf16 v5, v73, v83, v5                           // 000000389190: CC1A4005 1C16A749
	v_dot2_f32_bf16 v2, v70, v82, v11                          // 000000389198: CC1A4002 1C2EA546
	v_dot2_f32_bf16 v1, v3, v85, v1                            // 0000003891A0: CC1A4001 1C06AB03
	v_dot2_f32_bf16 v10, v28, v8, v10                          // 0000003891A8: CC1A400A 1C2A111C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003891B0: BF870214
	v_dot2_f32_bf16 v5, v74, v82, v5                           // 0000003891B4: CC1A4005 1C16A54A
	v_dot2_f32_bf16 v2, v71, v85, v2                           // 0000003891BC: CC1A4002 1C0AAB47
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003891C4: BF870214
	v_dot2_f32_bf16 v1, v4, v8, v1                             // 0000003891C8: CC1A4001 1C061104
	v_add_f32_e32 v12, 0, v10                                  // 0000003891D0: 06181480
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003891D4: BF870004
	v_dot2_f32_bf16 v3, v75, v85, v5                           // 0000003891D8: CC1A4003 1C16AB4B
	v_dot2_f32_bf16 v5, v44, v8, v6                            // 0000003891E0: CC1A4005 1C1A112C
	v_dot2_f32_bf16 v6, v20, v8, v9                            // 0000003891E8: CC1A4006 1C261114
	v_dot2_f32_bf16 v2, v72, v8, v2                            // 0000003891F0: CC1A4002 1C0A1148
	v_add_f32_e32 v13, 0, v1                                   // 0000003891F8: 061A0280
	v_dot2_f32_bf16 v3, v76, v8, v3                            // 0000003891FC: CC1A4003 1C0E114C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000389204: BF870114
	v_dual_add_f32 v9, 0, v5 :: v_dual_add_f32 v14, 0, v6      // 000000389208: C9080A80 090E0C80
	v_dual_add_f32 v10, 0, v2 :: v_dual_add_f32 v11, 0, v3     // 000000389210: C9080480 0A0A0680
	s_or_b32 exec_lo, exec_lo, s0                              // 000000389218: 8C7E007E
	s_waitcnt vmcnt(2)                                         // 00000038921C: BF890BF7
	.long 0xd71f0001                                           // 000000389220: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000389224: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000389228: BE80007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000038922C: BF870121
	v_xor_b32_e32 v2, 8, v1                                    // 000000389230: 3A040288
	v_xor_b32_e32 v15, 4, v1                                   // 000000389234: 3A1E0284
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000389238: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000038923C: 02040501
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000389240: BF8700A3
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 000000389244: 7C981EA0
	v_cndmask_b32_e32 v15, v1, v15, vcc_lo                     // 000000389248: 021E1F01
	v_lshlrev_b32_e32 v15, 2, v15                              // 00000038924C: 301E1E82
	s_delay_alu instid0(VALU_DEP_4)                            // 000000389250: BF870004
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000389254: 30040482
	ds_bpermute_b32 v3, v2, v14                                // 000000389258: DACC0000 03000E02
	s_waitcnt lgkmcnt(0)                                       // 000000389260: BF89FC07
	v_add_f32_e32 v3, v14, v3                                  // 000000389264: 0606070E
	ds_bpermute_b32 v4, v2, v9                                 // 000000389268: DACC0000 04000902
	s_waitcnt vmcnt(1)                                         // 000000389270: BF8907F7
	ds_bpermute_b32 v5, v2, v13                                // 000000389274: DACC0000 05000D02
	ds_bpermute_b32 v6, v2, v12                                // 00000038927C: DACC0000 06000C02
	s_waitcnt vmcnt(0)                                         // 000000389284: BF8903F7
	ds_bpermute_b32 v8, v2, v11                                // 000000389288: DACC0000 08000B02
	ds_bpermute_b32 v2, v2, v10                                // 000000389290: DACC0000 02000A02
	s_waitcnt lgkmcnt(4)                                       // 000000389298: BF89FC47
	v_add_f32_e32 v4, v9, v4                                   // 00000038929C: 06080909
	s_waitcnt lgkmcnt(2)                                       // 0000003892A0: BF89FC27
	v_dual_add_f32 v5, v13, v5 :: v_dual_add_f32 v6, v12, v6   // 0000003892A4: C9080B0D 05060D0C
	s_waitcnt lgkmcnt(1)                                       // 0000003892AC: BF89FC17
	v_add_f32_e32 v8, v11, v8                                  // 0000003892B0: 0610110B
	s_waitcnt lgkmcnt(0)                                       // 0000003892B4: BF89FC07
	v_add_f32_e32 v2, v10, v2                                  // 0000003892B8: 0604050A
	ds_bpermute_b32 v9, v15, v3                                // 0000003892BC: DACC0000 0900030F
	ds_bpermute_b32 v10, v15, v4                               // 0000003892C4: DACC0000 0A00040F
	ds_bpermute_b32 v11, v15, v5                               // 0000003892CC: DACC0000 0B00050F
	ds_bpermute_b32 v12, v15, v6                               // 0000003892D4: DACC0000 0C00060F
	ds_bpermute_b32 v13, v15, v8                               // 0000003892DC: DACC0000 0D00080F
	ds_bpermute_b32 v14, v15, v2                               // 0000003892E4: DACC0000 0E00020F
	v_xor_b32_e32 v15, 2, v1                                   // 0000003892EC: 3A1E0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003892F0: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 0000003892F4: 7C981EA0
	v_cndmask_b32_e32 v15, v1, v15, vcc_lo                     // 0000003892F8: 021E1F01
	v_lshlrev_b32_e32 v15, 2, v15                              // 0000003892FC: 301E1E82
	s_waitcnt lgkmcnt(4)                                       // 000000389300: BF89FC47
	v_dual_add_f32 v3, v3, v9 :: v_dual_add_f32 v4, v4, v10    // 000000389304: C9081303 03041504
	s_waitcnt lgkmcnt(2)                                       // 00000038930C: BF89FC27
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v6, v6, v12   // 000000389310: C9081705 05061906
	v_xor_b32_e32 v11, 1, v1                                   // 000000389318: 3A160281
	ds_bpermute_b32 v9, v15, v3                                // 00000038931C: DACC0000 0900030F
	s_waitcnt lgkmcnt(1)                                       // 000000389324: BF89FC17
	v_add_f32_e32 v2, v2, v14                                  // 000000389328: 06041D02
	ds_bpermute_b32 v10, v15, v4                               // 00000038932C: DACC0000 0A00040F
	ds_bpermute_b32 v12, v15, v5                               // 000000389334: DACC0000 0C00050F
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 00000038933C: 7C9816A0
	v_add_f32_e32 v8, v8, v13                                  // 000000389340: 06101B08
	ds_bpermute_b32 v13, v15, v6                               // 000000389344: DACC0000 0D00060F
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 00000038934C: 02021701
	ds_bpermute_b32 v14, v15, v8                               // 000000389350: DACC0000 0E00080F
	v_lshlrev_b32_e32 v16, 2, v1                               // 000000389358: 30200282
	s_waitcnt lgkmcnt(4)                                       // 00000038935C: BF89FC47
	v_add_f32_e32 v11, v3, v9                                  // 000000389360: 06161303
	ds_bpermute_b32 v15, v15, v2                               // 000000389364: DACC0000 0F00020F
	s_waitcnt lgkmcnt(3)                                       // 00000038936C: BF89FC37
	v_dual_add_f32 v10, v4, v10 :: v_dual_add_f32 v5, v5, v12  // 000000389370: C9081504 0A041905
	s_waitcnt lgkmcnt(2)                                       // 000000389378: BF89FC27
	v_add_f32_e32 v6, v6, v13                                  // 00000038937C: 060C1B06
	ds_bpermute_b32 v12, v16, v10                              // 000000389380: DACC0000 0C000A10
	ds_bpermute_b32 v13, v16, v11                              // 000000389388: DACC0000 0D000B10
	s_waitcnt lgkmcnt(3)                                       // 000000389390: BF89FC37
	v_add_f32_e32 v1, v8, v14                                  // 000000389394: 06021D08
	ds_bpermute_b32 v9, v16, v6                                // 000000389398: DACC0000 09000610
	ds_bpermute_b32 v8, v16, v5                                // 0000003893A0: DACC0000 08000510
	ds_bpermute_b32 v3, v16, v1                                // 0000003893A8: DACC0000 03000110
	s_waitcnt lgkmcnt(5)                                       // 0000003893B0: BF89FC57
	v_add_f32_e32 v2, v2, v15                                  // 0000003893B4: 06041F02
	ds_bpermute_b32 v4, v16, v2                                // 0000003893B8: DACC0000 04000210
	v_cmpx_eq_u32_e32 0, v7                                    // 0000003893C0: 7D940E80
	s_cbranch_execz 53                                         // 0000003893C4: BFA50035 <_ZN7halogen12_GLOBAL__N_18k_hcup6wILi6EEEvPKhPKtS5_PtPf+0xf9c>
	s_waitcnt lgkmcnt(4)                                       // 0000003893C8: BF89FC47
	v_dual_add_f32 v7, v11, v13 :: v_dual_add_f32 v10, v10, v12// 0000003893CC: C9081B0B 070A190A
	v_lshrrev_b32_e32 v11, 4, v0                               // 0000003893D4: 32160084
	.long 0x7f183880                                           // 0000003893D8: 7F183880
	s_waitcnt lgkmcnt(2)                                       // 0000003893DC: BF89FC27
	v_dual_add_f32 v6, v6, v9 :: v_dual_add_f32 v5, v5, v8     // 0000003893E0: C9081306 06041105
	.long 0x7e183987                                           // 0000003893E8: 7E183987
	s_waitcnt lgkmcnt(0)                                       // 0000003893EC: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v1, v1, v3     // 0000003893F0: C9080902 02000701
	v_mul_u32_u24_e32 v8, 12, v11                              // 0000003893F8: 1610168C
	.long 0x7e12398a                                           // 0000003893FC: 7E12398A
	.long 0x7f12398c                                           // 000000389400: 7F12398C
	v_and_b32_e32 v11, 1, v12                                  // 000000389404: 36161881
	.long 0x7e183985                                           // 000000389408: 7E183985
	.long 0x7e083986                                           // 00000038940C: 7E083986
	.long 0x7f08398c                                           // 000000389410: 7F08398C
	.long 0x7e063982                                           // 000000389414: 7E063982
	.long 0x7f06398c                                           // 000000389418: 7F06398C
	v_and_b32_e32 v9, 1, v9                                    // 00000038941C: 36121281
	v_and_b32_e32 v13, 1, v12                                  // 000000389420: 361A1881
	v_and_b32_e32 v4, 1, v4                                    // 000000389424: 36080881
	.long 0x7e183981                                           // 000000389428: 7E183981
	v_and_b32_e32 v3, 1, v3                                    // 00000038942C: 36060681
	v_add3_u32 v9, v10, v9, 0x7fff                             // 000000389430: D6550009 03FE130A 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000038943C: BF870004
	v_add3_u32 v4, v6, v4, 0x7fff                              // 000000389440: D6550004 03FE0906 00007FFF
	v_add3_u32 v6, v7, v11, 0x7fff                             // 00000038944C: D6550006 03FE1707 00007FFF
	v_and_b32_e32 v7, 1, v12                                   // 000000389458: 360E1881
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000038945C: D6550002 03FE0702 00007FFF
	v_add3_u32 v3, v5, v13, 0x7fff                             // 000000389468: D6550003 03FE1B05 00007FFF
	.long 0x7e063984                                           // 000000389474: 7E063984
	.long 0x7e0c3989                                           // 000000389478: 7E0C3989
	v_add3_u32 v1, v1, v7, 0x7fff                              // 00000038947C: D6550001 03FE0F01 00007FFF
	.long 0x7e023982                                           // 000000389488: 7E023982
	ds_store_2addr_b32 v8, v6, v3 offset1:1                    // 00000038948C: D8380100 00030608
	ds_store_b32 v8, v1 offset:8                               // 000000389494: D8340008 00000108
	s_or_b32 exec_lo, exec_lo, s0                              // 00000038949C: 8C7E007E
	s_waitcnt lgkmcnt(0)                                       // 0000003894A0: BF89FC07
	s_barrier                                                  // 0000003894A4: BFBD0000
	buffer_gl0_inv                                             // 0000003894A8: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 0000003894B0: BE80007E
	v_cmpx_gt_u32_e32 24, v0                                   // 0000003894B4: 7D980098
	s_cbranch_execz 260                                        // 0000003894B8: BFA50104 <_ZN7halogen12_GLOBAL__N_18k_hcup6wILi6EEEvPKhPKtS5_PtPf+0x13cc>
	.long 0xd7054000                                           // 0000003894BC: D7054000
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 0000003894C0: 020200FF 000000AB
	.long 0x7f143880                                           // 0000003894C8: 7F143880
	s_cmp_eq_u64 s[12:13], 0                                   // 0000003894CC: BF10800C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003894D0: BF870092
	.long 0xd739100a                                           // 0000003894D4: D739100A
	v_cndmask_b32_e32 v1, 10, v0, vcc_lo                       // 0000003894D8: 0202008A
	.long 0xd7054000                                           // 0000003894DC: D7054000
	v_cndmask_b32_e32 v0, v10, v134, vcc_lo                    // 0000003894E0: 02010D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003894E4: BF870121
	.long 0xd7041001                                           // 0000003894E8: D7041001
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000003894EC: 02020100
	v_add_nc_u32_e32 v0, s1, v10                               // 0000003894F0: 4A001401
	v_and_b32_e32 v11, 0xff, v1                                // 0000003894F4: 361602FF 000000FF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003894FC: BF870112
	v_ashrrev_i32_e32 v1, 31, v0                               // 000000389500: 3402009F
	v_mad_u64_u32 v[2:3], null, 0x5000, v11, s[8:9]            // 000000389504: D6FE7C02 002216FF 00005000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000389510: BF870092
	.long 0xd73c0004                                           // 000000389514: D73C0004
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000389518: 02020081
	.long 0xd7006a02                                           // 00000038951C: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000389520: 02020902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000389524: BF870111
	v_add_co_ci_u32_e64 v3, null, v3, v5, vcc_lo               // 000000389528: D5207C03 01AA0B03
	.long 0xd7006a04                                           // 000000389530: D7006A04
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 000000389534: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000038953C: BF8700A1
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 000000389540: D5207C05 01AA0680
	.long 0xd7006a06                                           // 000000389548: D7006A06
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 00000038954C: 020204FF 00003000
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 000000389554: D5207C07 01AA0680
	.long 0xd7006a08                                           // 00000038955C: D7006A08
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 000000389560: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000389568: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v3, vcc_lo                // 00000038956C: D5207C09 01AA0680
	s_clause 0x3                                               // 000000389574: BF850003
	global_load_u16 v4, v[4:5], off offset:2048                // 000000389578: DC4A0800 047C0004
	global_load_u16 v5, v[6:7], off offset:3072                // 000000389580: DC4A0C00 057C0006
	global_load_u16 v2, v[2:3], off                            // 000000389588: DC4A0000 027C0002
	global_load_u16 v3, v[8:9], off offset:1024                // 000000389590: DC4A0400 037C0008
	v_mul_u32_u24_e32 v6, 48, v10                              // 000000389598: 160C14B0
	s_delay_alu instid0(VALU_DEP_1)                            // 00000038959C: BF870001
	v_lshl_add_u32 v6, v11, 1, v6                              // 0000003895A0: D6460006 0419030B
	ds_load_u16 v7, v6                                         // 0000003895A8: D8F00000 07000006
	ds_load_u16 v8, v6 offset:12                               // 0000003895B0: D8F0000C 08000006
	ds_load_u16 v9, v6 offset:24                               // 0000003895B8: D8F00018 09000006
	ds_load_u16 v6, v6 offset:36                               // 0000003895C0: D8F00024 06000006
	s_waitcnt lgkmcnt(0)                                       // 0000003895C8: BF89FC07
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000003895CC: 300C0C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003895D0: BF870091
	v_dual_mul_f32 v6, 0xbfb8aa3b, v6 :: v_dual_lshlrev_b32 v9, 16, v9// 0000003895D4: C8E20CFF 06081290 BFB8AA3B
	v_dual_mul_f32 v9, 0xbfb8aa3b, v9 :: v_dual_lshlrev_b32 v8, 16, v8// 0000003895E0: C8E212FF 09081090 BFB8AA3B
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000003895EC: 300E0E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003895F0: BF870113
	v_exp_f32_e32 v6, v6                                       // 0000003895F4: 7E0C4B06
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 0000003895F8: 101010FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000389600: BF870113
	v_exp_f32_e32 v9, v9                                       // 000000389604: 7E124B09
	v_mul_f32_e32 v7, 0xbfb8aa3b, v7                           // 000000389608: 100E0EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000389610: BF870092
	v_exp_f32_e32 v8, v8                                       // 000000389614: 7E104B08
	v_exp_f32_e32 v7, v7                                       // 000000389618: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038961C: BF870097
	v_dual_add_f32 v6, 1.0, v6 :: v_dual_add_f32 v9, 1.0, v9   // 000000389620: C9080CF2 060812F2
	v_div_scale_f32 v14, null, v6, v6, 1.0                     // 000000389628: D6FC7C0E 03CA0D06
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000389630: BF870196
	v_add_f32_e32 v8, 1.0, v8                                  // 000000389634: 061010F2
	v_div_scale_f32 v13, null, v9, v9, 1.0                     // 000000389638: D6FC7C0D 03CA1309
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000389640: BF870005
	v_add_f32_e32 v7, 1.0, v7                                  // 000000389644: 060E0EF2
	v_div_scale_f32 v24, s1, 1.0, v9, 1.0                      // 000000389648: D6FC0118 03CA12F2
	v_rcp_f32_e32 v18, v14                                     // 000000389650: 7E24550E
	v_div_scale_f32 v12, null, v8, v8, 1.0                     // 000000389654: D6FC7C0C 03CA1108
	v_rcp_f32_e32 v17, v13                                     // 00000038965C: 7E22550D
	v_div_scale_f32 v10, null, v7, v7, 1.0                     // 000000389660: D6FC7C0A 03CA0F07
	v_div_scale_f32 v19, vcc_lo, 1.0, v7, 1.0                  // 000000389668: D6FC6A13 03CA0EF2
	v_div_scale_f32 v20, s0, 1.0, v8, 1.0                      // 000000389670: D6FC0014 03CA10F2
	v_rcp_f32_e32 v16, v12                                     // 000000389678: 7E20550C
	v_mad_u64_u32 v[0:1], null, 0xa00, v11, v[0:1]             // 00000038967C: D6FE7C00 040216FF 00000A00
	v_rcp_f32_e32 v15, v10                                     // 000000389688: 7E1E550A
	v_fma_f32 v25, -v14, v18, 1.0                              // 00000038968C: D6130019 23CA250E
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000389694: BF870117
	v_fma_f32 v23, -v13, v17, 1.0                              // 000000389698: D6130017 23CA230D
	v_fmac_f32_e32 v18, v25, v18                               // 0000003896A0: 56242519
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003896A4: BF870196
	v_fma_f32 v22, -v12, v16, 1.0                              // 0000003896A8: D6130016 23CA210C
	v_fmac_f32_e32 v17, v23, v17                               // 0000003896B0: 56222317
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003896B4: BF870095
	v_fma_f32 v21, -v10, v15, 1.0                              // 0000003896B8: D6130015 23CA1F0A
	v_dual_fmac_f32 v16, v22, v16 :: v_dual_fmac_f32 v15, v21, v15// 0000003896C0: C8002116 100E1F15
	v_div_scale_f32 v21, s2, 1.0, v6, 1.0                      // 0000003896C8: D6FC0215 03CA0CF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003896D0: BF870194
	v_mul_f32_e32 v25, v24, v17                                // 0000003896D4: 10322318
	v_dual_mul_f32 v23, v20, v16 :: v_dual_mul_f32 v22, v19, v15// 0000003896D8: C8C62114 17161F13
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003896E0: BF870193
	v_mul_f32_e32 v26, v21, v18                                // 0000003896E4: 10342515
	v_fma_f32 v29, -v13, v25, v24                              // 0000003896E8: D613001D 2462330D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003896F0: BF870213
	v_fma_f32 v28, -v12, v23, v20                              // 0000003896F4: D613001C 24522F0C
	v_fma_f32 v27, -v10, v22, v19                              // 0000003896FC: D613001B 244E2D0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000389704: BF870214
	v_fma_f32 v30, -v14, v26, v21                              // 000000389708: D613001E 2456350E
	v_fmac_f32_e32 v25, v29, v17                               // 000000389710: 5632231D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000389714: BF870193
	v_dual_fmac_f32 v23, v28, v16 :: v_dual_fmac_f32 v22, v27, v15// 000000389718: C800211C 17161F1B
	v_fmac_f32_e32 v26, v30, v18                               // 000000389720: 5634251E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000389724: BF870193
	v_fma_f32 v13, -v13, v25, v24                              // 000000389728: D613000D 2462330D
	v_fma_f32 v12, -v12, v23, v20                              // 000000389730: D613000C 24522F0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000389738: BF870214
	v_fma_f32 v10, -v10, v22, v19                              // 00000038973C: D613000A 244E2D0A
	v_fma_f32 v14, -v14, v26, v21                              // 000000389744: D613000E 2456350E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000038974C: BF870142
	v_div_fmas_f32 v10, v10, v15, v22                          // 000000389750: D637000A 045A1F0A
	s_mov_b32 vcc_lo, s0                                       // 000000389758: BEEA0000
	v_div_fmas_f32 v12, v12, v16, v23                          // 00000038975C: D637000C 045E210C
	s_mov_b32 vcc_lo, s1                                       // 000000389764: BEEA0001
	v_div_fixup_f32 v7, v10, v7, 1.0                           // 000000389768: D6270007 03CA0F0A
	v_div_fmas_f32 v10, v13, v17, v25                          // 000000389770: D637000A 0466230D
	s_mov_b32 vcc_lo, s2                                       // 000000389778: BEEA0002
	v_div_fixup_f32 v8, v12, v8, 1.0                           // 00000038977C: D6270008 03CA110C
	v_div_fmas_f32 v13, v14, v18, v26                          // 000000389784: D637000D 046A250E
	v_bfe_u32 v12, v7, 16, 1                                   // 00000038978C: D610000C 02052107
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 000000389794: D6270009 03CA130A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000038979C: BF870214
	v_bfe_u32 v10, v8, 16, 1                                   // 0000003897A0: D610000A 02052108
	v_div_fixup_f32 v6, v13, v6, 1.0                           // 0000003897A8: D6270006 03CA0D0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003897B0: BF870214
	v_add3_u32 v7, v7, v12, 0x7fff                             // 0000003897B4: D6550007 03FE1907 00007FFF
	v_bfe_u32 v12, v9, 16, 1                                   // 0000003897C0: D610000C 02052109
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003897C8: BF870214
	v_add3_u32 v8, v8, v10, 0x7fff                             // 0000003897CC: D6550008 03FE1508 00007FFF
	v_bfe_u32 v10, v6, 16, 1                                   // 0000003897D8: D610000A 02052106
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003897E0: BF870193
	v_add3_u32 v9, v9, v12, 0x7fff                             // 0000003897E4: D6550009 03FE1909 00007FFF
	v_and_b32_e32 v8, 0xffff0000, v8                           // 0000003897F0: 361010FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003897F8: BF870003
	v_add3_u32 v6, v6, v10, 0x7fff                             // 0000003897FC: D6550006 03FE1506 00007FFF
	s_waitcnt vmcnt(3)                                         // 000000389808: BF890FF7
	v_lshlrev_b32_e32 v4, 16, v4                               // 00000038980C: 30080890
	s_waitcnt vmcnt(2)                                         // 000000389810: BF890BF7
	v_lshlrev_b32_e32 v5, 16, v5                               // 000000389814: 300A0A90
	s_waitcnt vmcnt(1)                                         // 000000389818: BF8907F7
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000038981C: 30040490
	s_waitcnt vmcnt(0)                                         // 000000389820: BF8903F7
	v_lshlrev_b32_e32 v3, 16, v3                               // 000000389824: 30060690
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000389828: 360E0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000389830: BF870091
	v_fma_f32 v2, v2, v7, 0                                    // 000000389834: D6130002 02020F02
	v_dual_fmac_f32 v2, v3, v8 :: v_dual_and_b32 v3, 0xffff0000, v6// 00000038983C: C8241103 02020CFF FFFF0000
	v_and_b32_e32 v7, 0xffff0000, v9                           // 000000389848: 360E12FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000389850: BF870091
	v_fmac_f32_e32 v2, v4, v7                                  // 000000389854: 56040F04
	v_fmac_f32_e32 v2, v5, v3                                  // 000000389858: 56040705
	.long 0xd73c0003                                           // 00000038985C: D73C0003
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000389860: 02020081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000389864: BF870112
	v_mul_f32_e32 v2, 0x3e800000, v2                           // 000000389868: 100404FF 3E800000
	.long 0xd7006a03                                           // 000000389870: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 000000389874: 0202060A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000389878: BF870191
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 00000038987C: D5207C04 01AA080B
	v_bfe_u32 v5, v2, 16, 1                                    // 000000389884: D6100005 02052102
	s_delay_alu instid0(VALU_DEP_1)                            // 00000038988C: BF870001
	v_add3_u32 v5, v2, v5, 0x7fff                              // 000000389890: D6550005 03FE0B02 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000038989C: DC960000 007C0503
	s_cbranch_scc1 9                                           // 0000003898A4: BFA20009 <_ZN7halogen12_GLOBAL__N_18k_hcup6wILi6EEEvPKhPKtS5_PtPf+0x13cc>
	.long 0xd73c0000                                           // 0000003898A8: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000003898AC: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003898B0: BF870091
	.long 0xd7006a00                                           // 0000003898B4: D7006A00
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 0000003898B8: 0202000C
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 0000003898BC: D5207C01 01AA020D
	global_store_b32 v[0:1], v2, off                           // 0000003898C4: DC6A0000 007C0200
	s_endpgm                                                   // 0000003898CC: BFB00000
		...

