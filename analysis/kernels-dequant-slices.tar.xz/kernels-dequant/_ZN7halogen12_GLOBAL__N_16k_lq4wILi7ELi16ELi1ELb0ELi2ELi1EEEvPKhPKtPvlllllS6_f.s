0000000000821100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000821100: F4100100 F8000000
	v_and_b32_e32 v30, 15, v0                                  // 000000821108: 363C008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000082110C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000821110: 86039F02
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000821114: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000821118: 84808402
	v_lshlrev_b32_e32 v2, 2, v30                               // 00000082111C: 30043C82
	v_dual_mov_b32 v24, s1 :: v_dual_lshlrev_b32 v3, 2, v1     // 000000821120: CA220001 18020282
	v_or_b32_e32 v23, s0, v1                                   // 000000821128: 382E0200
	.long 0x7f0c3880                                           // 00000082112C: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 000000821130: BF89FC07
	s_clause 0x1                                               // 000000821134: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 000000821138: DC520000 04040002
	global_load_b32 v3, v3, s[4:5]                             // 000000821140: DC520000 03040003
	.long 0xd4540000                                           // 000000821148: D4540000
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 00000082114C: 02022E0C
	s_add_u32 s22, s4, s16                                     // 000000821150: 80161004
	s_addc_u32 s23, s5, s17                                    // 000000821154: 82171105
	s_ashr_i32 s2, s11, 31                                     // 000000821158: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000082115C: BF870159
	s_lshr_b32 s2, s2, 27                                      // 000000821160: 85029B02
	v_cndmask_b32_e64 v2, 0, v23, s0                           // 000000821164: D5010002 00022E80
	v_cndmask_b32_e64 v5, 0, s1, s0                            // 00000082116C: D5010005 00000280
	s_add_u32 s2, s10, s2                                      // 000000821174: 8002020A
	s_addc_u32 s3, s11, 0                                      // 000000821178: 8203800B
	.long 0xd72c0008                                           // 00000082117C: D72C0008
	v_cndmask_b32_e32 v1, s19, v2, vcc_lo                      // 000000821180: 02020413
	v_mad_u64_u32 v[0:1], null, s18, v2, 0                     // 000000821184: D6FE7C00 02020412
	s_lshr_b64 s[20:21], s[2:3], 5                             // 00000082118C: 85948502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000821190: BF870009
	s_cmpk_lt_i32 s20, 0x81                                    // 000000821194: B3940081
	.long 0xd4440002                                           // 000000821198: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 00000082119C: 02023C14
	s_cselect_b32 s1, -1, 0                                    // 0000008211A0: 980180C1
	s_cmpk_gt_i32 s20, 0x80                                    // 0000008211A4: B2940080
	s_waitcnt vmcnt(1)                                         // 0000008211A8: BF8907F7
	v_bfe_u32 v9, v4, 16, 1                                    // 0000008211AC: D6100009 02052104
	s_waitcnt vmcnt(0)                                         // 0000008211B4: BF8903F7
	v_bfe_u32 v10, v3, 16, 1                                   // 0000008211B8: D610000A 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008211C0: BF8701A2
	v_add3_u32 v4, v4, v9, 0x7fff                              // 0000008211C4: D6550004 03FE1304 00007FFF
	.long 0xd72c0009                                           // 0000008211D0: D72C0009
	v_cndmask_b32_e32 v1, s18, v5, vcc_lo                      // 0000008211D4: 02020A12
	v_add3_u32 v3, v3, v10, 0x7fff                             // 0000008211D8: D6550003 03FE1503 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 0000008211E4: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008211E8: BF8701A9
	s_and_b32 vcc_lo, exec_lo, s18                             // 0000008211EC: 8B6A127E
	.long 0x7e0c3984                                           // 0000008211F0: 7E0C3984
	v_add3_u32 v1, v1, v9, v8                                  // 0000008211F4: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008211FC: BF8700A2
	v_and_or_b32 v6, 0xffff0000, v3, v6                        // 000000821200: D6570006 041A06FF FFFF0000
	.long 0xd7000303                                           // 00000082120C: D7000303
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 000000821210: 02020016
	v_add_co_ci_u32_e64 v4, null, s23, v1, s3                  // 000000821214: D5207C04 000E0217
	ds_store_b32 v7, v6                                        // 00000082121C: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 000000821224: BF89FC07
	s_barrier                                                  // 000000821228: BFBD0000
	buffer_gl0_inv                                             // 00000082122C: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 000000821234: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 000000821238: CA100080 08060080
	s_and_saveexec_b32 s3, s2                                  // 000000821240: BE832002
	s_cbranch_execz 10                                         // 000000821244: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x170>
	v_lshlrev_b32_e32 v6, 1, v30                               // 000000821248: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082124C: BF870091
	.long 0xd7006a06                                           // 000000821250: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000821254: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 000000821258: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 000000821260: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000821268: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 00000082126C: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s3                              // 000000821270: 8C7E037E
	v_or_b32_e32 v6, 16, v30                                   // 000000821274: 380C3C90
	s_mov_b32 s2, exec_lo                                      // 000000821278: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000082127C: BF870001
	.long 0xd4c4007e                                           // 000000821280: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000821284: 02020C14
	s_cbranch_execz 10                                         // 000000821288: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1b4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000082128C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821290: BF870091
	.long 0xd7006a08                                           // 000000821294: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000821298: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 00000082129C: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 0000008212A4: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 0000008212AC: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 0000008212B0: 7E101706
	s_or_b32 exec_lo, exec_lo, s2                              // 0000008212B4: 8C7E027E
	v_or_b32_e32 v6, 32, v30                                   // 0000008212B8: 380C3CA0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 0000008212BC: CA100080 0A080080
	s_mov_b32 s2, exec_lo                                      // 0000008212C4: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008212C8: BF870002
	.long 0xd4c4007e                                           // 0000008212CC: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 0000008212D0: 02020C14
	s_cbranch_execz 10                                         // 0000008212D4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x200>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008212D8: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008212DC: BF870091
	.long 0xd7006a0b                                           // 0000008212E0: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008212E4: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 0000008212E8: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 0000008212F0: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 0000008212F8: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 0000008212FC: 7E121706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000821300: 8C7E027E
	v_or_b32_e32 v6, 48, v30                                   // 000000821304: 380C3CB0
	s_mov_b32 s2, exec_lo                                      // 000000821308: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000082130C: BF870001
	.long 0xd4c4007e                                           // 000000821310: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000821314: 02020C14
	s_cbranch_execz 10                                         // 000000821318: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x244>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000082131C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821320: BF870091
	.long 0xd7006a0a                                           // 000000821324: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000821328: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 00000082132C: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 000000821334: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 00000082133C: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 000000821340: 7E141706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000821344: 8C7E027E
	v_or_b32_e32 v6, 64, v30                                   // 000000821348: 380C3CC0
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 00000082134C: CA100080 0C0A0080
	s_mov_b32 s2, exec_lo                                      // 000000821354: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000821358: BF870002
	.long 0xd4c4007e                                           // 00000082135C: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000821360: 02020C14
	s_cbranch_execz 10                                         // 000000821364: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x290>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000821368: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082136C: BF870091
	.long 0xd7006a0d                                           // 000000821370: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000821374: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 000000821378: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 000000821380: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 000000821388: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 00000082138C: 7E161706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000821390: 8C7E027E
	v_or_b32_e32 v6, 0x50, v30                                 // 000000821394: 380C3CFF 00000050
	s_mov_b32 s2, exec_lo                                      // 00000082139C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008213A0: BF870001
	.long 0xd4c4007e                                           // 0000008213A4: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 0000008213A8: 02020C14
	s_cbranch_execz 10                                         // 0000008213AC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2d8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008213B0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008213B4: BF870091
	.long 0xd7006a0c                                           // 0000008213B8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008213BC: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 0000008213C0: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 0000008213C8: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 0000008213D0: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 0000008213D4: 7E181706
	s_or_b32 exec_lo, exec_lo, s2                              // 0000008213D8: 8C7E027E
	v_or_b32_e32 v6, 0x60, v30                                 // 0000008213DC: 380C3CFF 00000060
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 0000008213E4: CA100080 0E0C0080
	s_mov_b32 s2, exec_lo                                      // 0000008213EC: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008213F0: BF870002
	.long 0xd4c4007e                                           // 0000008213F4: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 0000008213F8: 02020C14
	s_cbranch_execz 10                                         // 0000008213FC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x328>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000821400: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821404: BF870091
	.long 0xd7006a0f                                           // 000000821408: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000082140C: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 000000821410: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 000000821418: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 000000821420: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 000000821424: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000821428: 8C7E027E
	v_or_b32_e32 v6, 0x70, v30                                 // 00000082142C: 380C3CFF 00000070
	s_mov_b32 s2, exec_lo                                      // 000000821434: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000821438: BF870001
	.long 0xd4c4007e                                           // 00000082143C: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000821440: 02020C14
	s_cbranch_execz 10                                         // 000000821444: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x370>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000821448: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082144C: BF870091
	.long 0xd7006a0e                                           // 000000821450: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000821454: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 000000821458: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 000000821460: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 000000821468: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 00000082146C: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000821470: 8C7E027E
	s_branch 9                                                 // 000000821474: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x39c>
	v_mov_b32_e32 v7, 0                                        // 000000821478: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000082147C: BF870001
	v_mov_b32_e32 v8, v7                                       // 000000821480: 7E100307
	v_mov_b32_e32 v9, v7                                       // 000000821484: 7E120307
	v_mov_b32_e32 v10, v7                                      // 000000821488: 7E140307
	v_mov_b32_e32 v11, v7                                      // 00000082148C: 7E160307
	v_mov_b32_e32 v12, v7                                      // 000000821490: 7E180307
	v_mov_b32_e32 v13, v7                                      // 000000821494: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 000000821498: 7E1C0307
	s_add_u32 s2, s4, s14                                      // 00000082149C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 0000008214A0: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 0000008214A4: 850E9F0B
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000008214A8: CA100080 13140080
	s_add_u32 s14, s10, s14                                    // 0000008214B0: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 0000008214B4: 820F800B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v22, 0             // 0000008214B8: CA100080 1F160080
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000008214C0: 868E810E
	v_cndmask_b32_e64 v32, 0, 1, s18                           // 0000008214C4: D5010020 00490280
	v_mad_u64_u32 v[25:26], null, v2, s14, s[2:3]              // 0000008214CC: D6FE7C19 00081D02
	.long 0xd72c0002                                           // 0000008214D4: D72C0002
	v_cndmask_b32_e32 v0, v2, v15, vcc_lo                      // 0000008214D8: 02001F02
	.long 0xd72c0005                                           // 0000008214DC: D72C0005
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 0000008214E0: 02001D05
	.long 0xd4440002                                           // 0000008214E4: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 0000008214E8: 02023C14
	v_mov_b32_e32 v43, 0                                       // 0000008214EC: 7E560280
	v_mov_b32_e32 v21, 0                                       // 0000008214F0: 7E2A0280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008214F4: BF870004
	v_add3_u32 v33, v5, v26, v2                                // 0000008214F8: D6550021 040A3505
	s_and_saveexec_b32 s3, s2                                  // 000000821500: BE832002
	s_cbranch_execz 21                                         // 000000821504: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_dual_mov_b32 v43, 0 :: v_dual_lshlrev_b32 v2, 4, v30     // 000000821508: CA220080 2B023C84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821510: BF870091
	.long 0xd7006a05                                           // 000000821514: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 000000821518: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 00000082151C: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 000000821524: 916A127E
	global_load_b128 v[19:22], v[5:6], off                     // 000000821528: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 000000821530: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_lshlrev_b32_e32 v2, 1, v30                               // 000000821534: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821538: BF870091
	.long 0xd7006a02                                           // 00000082153C: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 000000821540: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 000000821544: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 00000082154C: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000821554: BF8903F7
	v_cvt_f32_f16_e32 v43, v2                                  // 000000821558: 7E561702
	s_or_b32 exec_lo, exec_lo, s3                              // 00000082155C: 8C7E037E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 000000821560: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 000000821568: CA100080 24240080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 000000821570: CA100080 26260080
	s_and_saveexec_b32 s3, s2                                  // 000000821578: BE832002
	s_cbranch_execz 627                                        // 00000082157C: BFA50273 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xe4c>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 000000821580: CA220080 1B023C81
	.long 0xd7006a00                                           // 000000821588: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000082158C: 02020010
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000821590: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000821594: D5207C01 01AA0211
	v_dual_mov_b32 v41, v30 :: v_dual_lshlrev_b32 v26, 5, v30  // 00000082159C: CA22011E 291A3C85
	.long 0xd7006a00                                           // 0000008215A4: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 0000008215A8: 02020500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008215AC: BF8701A1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000008215B0: D5207C01 01AA0280
	v_lshl_or_b32 v40, v30, 4, 0x100                           // 0000008215B8: D6560028 03FD091E 00000100
	.long 0xd7006a00                                           // 0000008215C4: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000008215C8: 02020004
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008215CC: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000008215D0: D5207C01 01AA0205
	v_mov_b32_e32 v39, v27                                     // 0000008215D8: 7E4E031B
	.long 0xd7006a1c                                           // 0000008215DC: D7006A1C
	v_cndmask_b32_e32 v0, v0, v160, vcc_lo                     // 0000008215E0: 02014100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008215E4: BF870001
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 0000008215E8: D5207C1D 01AA0280
	v_mov_b32_e32 v38, v27                                     // 0000008215F0: 7E4C031B
	v_mov_b32_e32 v37, v27                                     // 0000008215F4: 7E4A031B
	v_mov_b32_e32 v36, v27                                     // 0000008215F8: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 0000008215FC: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 000000821600: 7E44031B
	v_mov_b32_e32 v31, v27                                     // 000000821604: 7E3E031B
	v_mov_b32_e32 v42, v43                                     // 000000821608: 7E54032B
	s_mul_i32 s2, s11, 6                                       // 00000082160C: 9602860B
	s_mul_hi_u32 s18, s10, 6                                   // 000000821610: 9692860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000821614: 848E820A
	s_add_i32 s18, s18, s2                                     // 000000821618: 81120212
	s_mul_i32 s17, s10, 6                                      // 00000082161C: 9611860A
	s_mov_b32 s16, 0                                           // 000000821620: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000821624: 8484810A
	s_branch 555                                               // 000000821628: BFA0022B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xdd8>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000082162C: 8C7E0A7E
	v_cndmask_b32_e64 v53, v43, v7, s1                         // 000000821630: D5010035 00060F2B
	v_cndmask_b32_e64 v1, v8, v9, s1                           // 000000821638: D5010001 00061308
	v_cndmask_b32_e64 v0, v7, v8, s1                           // 000000821640: D5010000 00061107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 000000821648: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s1                         // 000000821654: D5010006 00061D0D
	v_cndmask_b32_e64 v5, v12, v13, s1                         // 00000082165C: D5010005 00061B0C
	v_cndmask_b32_e64 v4, v11, v12, s1                         // 000000821664: D5010004 0006190B
	v_cndmask_b32_e64 v3, v10, v11, s1                         // 00000082166C: D5010003 0006170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000821674: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s1                          // 000000821678: D5010002 00061509
	v_add_nc_u32_e32 v40, 0x100, v40                           // 000000821680: 4A5050FF 00000100
	s_and_b32 s2, exec_lo, s2                                  // 000000821688: 8B02027E
	ds_load_b32 v14, v8                                        // 00000082168C: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 000000821694: 32102686
	s_or_b32 s16, s2, s16                                      // 000000821698: 8C101002
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000082169C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008216A0: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 0000008216A8: D8D80000 36000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 0000008216B0: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008216B4: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 0000008216BC: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 0000008216C4: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008216C8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008216CC: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 0000008216D4: D8D80000 38000008
	v_and_b32_e32 v8, 0xff, v20                                // 0000008216DC: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008216E4: 30101082
	ds_load_b32 v57, v8                                        // 0000008216E8: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 0000008216F0: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008216F4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008216F8: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 000000821700: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 000000821708: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000082170C: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 000000821714: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 00000082171C: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000821720: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000821724: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 00000082172C: D8D80000 3C000008
	v_and_b32_e32 v8, 0xff, v21                                // 000000821734: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000082173C: 30101082
	ds_load_b32 v61, v8                                        // 000000821740: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 000000821748: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000082174C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000821750: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 000000821758: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 000000821760: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000821764: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 00000082176C: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 000000821774: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000821778: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000082177C: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 000000821784: D8D80000 40000008
	v_and_b32_e32 v8, 0xff, v22                                // 00000082178C: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000821794: 30101082
	ds_load_b32 v65, v8                                        // 000000821798: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 0000008217A0: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008217A4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008217A8: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 0000008217B0: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 0000008217B8: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008217BC: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 0000008217C4: D8D80000 43000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 0000008217CC: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008217D0: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008217D4: 361010FF 000003FC
	ds_load_b32 v68, v8                                        // 0000008217DC: D8D80000 44000008
	.long 0xd73c0008                                           // 0000008217E4: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000008217E8: 02023481
	v_add_nc_u32_e32 v26, 0x200, v26                           // 0000008217EC: 4A3434FF 00000200
	.long 0xd7006a0c                                           // 0000008217F4: D7006A0C
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 0000008217F8: 02021006
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008217FC: BF870001
	v_add_co_ci_u32_e64 v13, null, s7, v9, vcc_lo              // 000000821800: D5207C0D 01AA1207
	s_clause 0x3                                               // 000000821808: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000082180C: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000821814: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 00000082181C: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 000000821824: DC5E0030 2F7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000082182C: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000821830: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 000000821838: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082183C: BF8700A1
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 000000821840: CC1A4008 1C226D09
	s_waitcnt lgkmcnt(13)                                      // 000000821848: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 00000082184C: CC1A4008 1C226F0A
	s_waitcnt lgkmcnt(12)                                      // 000000821854: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000821858: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 00000082185C: CC1A4008 1C22710B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000821864: BF8908B7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 000000821868: CC1A4008 1C227313
	s_waitcnt lgkmcnt(10)                                      // 000000821870: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000821874: BF8700A1
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 000000821878: CC1A4008 1C227514
	s_waitcnt lgkmcnt(9)                                       // 000000821880: BF89FC97
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 000000821884: CC1A4008 1C227715
	s_waitcnt lgkmcnt(8)                                       // 00000082188C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000821890: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 000000821894: CC1A4008 1C227916
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000082189C: BF890477
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008218A0: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(6)                                       // 0000008218A8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008218AC: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008218B0: CC1A4008 1C227D2C
	s_waitcnt lgkmcnt(5)                                       // 0000008218B8: BF89FC57
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008218BC: CC1A4008 1C227F2D
	s_waitcnt lgkmcnt(4)                                       // 0000008218C4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008218C8: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008218CC: CC1A4008 1C22812E
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008218D4: BF890037
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008218D8: CC1A4008 1C22832F
	.long 0xd7006a2f                                           // 0000008218E0: D7006A2F
	v_cndmask_b32_e32 v0, v12, v4, vcc_lo                      // 0000008218E4: 0200090C
	s_waitcnt lgkmcnt(2)                                       // 0000008218E8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008218EC: BF8701C2
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008218F0: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v48, null, s5, v13, vcc_lo             // 0000008218F8: D5207C30 01AA1A05
	.long 0xd7006a33                                           // 000000821900: D7006A33
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 000000821904: 02001D0C
	s_waitcnt lgkmcnt(1)                                       // 000000821908: BF89FC17
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000082190C: CC1A4008 1C228731
	v_add_co_ci_u32_e64 v52, null, s15, v13, vcc_lo            // 000000821914: D5207C34 01AA1A0F
	.long 0xd7006a0c                                           // 00000082191C: D7006A0C
	v_cndmask_b32_e32 v0, v12, v17, vcc_lo                     // 000000821920: 0200230C
	s_waitcnt lgkmcnt(0)                                       // 000000821924: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000821928: BF870123
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 00000082192C: CC1A4008 1C228932
	v_add_co_ci_u32_e64 v13, null, s18, v13, vcc_lo            // 000000821934: D5207C0D 01AA1A12
	v_fmac_f32_e32 v39, v53, v8                                // 00000082193C: 564E1135
	s_clause 0x3                                               // 000000821940: BF850003
	global_load_b128 v[8:11], v[47:48], off                    // 000000821944: DC5E0000 087C002F
	global_load_b128 v[19:22], v[47:48], off offset:16         // 00000082194C: DC5E0010 137C002F
	global_load_b128 v[43:46], v[47:48], off offset:32         // 000000821954: DC5E0020 2B7C002F
	global_load_b128 v[47:50], v[47:48], off offset:48         // 00000082195C: DC5E0030 2F7C002F
	s_waitcnt vmcnt(3)                                         // 000000821964: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000821968: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821970: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 000000821974: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 00000082197C: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000821984: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 000000821988: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 000000821990: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 000000821994: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082199C: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 0000008219A0: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 0000008219A8: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008219B0: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 0000008219B4: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 0000008219BC: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008219C0: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008219C8: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008219CC: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008219D4: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008219DC: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008219E0: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 0000008219E8: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008219EC: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008219F4: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008219F8: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000821A00: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821A08: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 000000821A0C: CC1A4008 1C228932
	v_fmac_f32_e32 v38, v53, v8                                // 000000821A14: 564C1135
	s_clause 0x3                                               // 000000821A18: BF850003
	global_load_b128 v[8:11], v[51:52], off                    // 000000821A1C: DC5E0000 087C0033
	global_load_b128 v[19:22], v[51:52], off offset:16         // 000000821A24: DC5E0010 137C0033
	global_load_b128 v[43:46], v[51:52], off offset:32         // 000000821A2C: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[51:52], off offset:48         // 000000821A34: DC5E0030 2F7C0033
	.long 0xd7006a33                                           // 000000821A3C: D7006A33
	v_cndmask_b32_e32 v0, v51, v14, vcc_lo                     // 000000821A40: 02001D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000821A44: BF8700B1
	v_add_co_ci_u32_e64 v52, null, s15, v52, vcc_lo            // 000000821A48: D5207C34 01AA680F
	s_waitcnt vmcnt(3)                                         // 000000821A50: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000821A54: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 000000821A5C: CC1A4008 1C226D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821A64: BF870091
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 000000821A68: CC1A4008 1C226F0A
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 000000821A70: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 000000821A78: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821A7C: BF870091
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 000000821A80: CC1A4008 1C227313
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 000000821A88: CC1A4008 1C227514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821A90: BF870091
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 000000821A94: CC1A4008 1C227715
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 000000821A9C: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 000000821AA4: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821AA8: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000821AAC: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000821AB4: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821ABC: BF870091
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000821AC0: CC1A4008 1C227F2D
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000821AC8: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 000000821AD0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821AD4: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000821AD8: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000821AE0: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821AE8: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000821AEC: CC1A4008 1C228731
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 000000821AF4: CC1A4008 1C228932
	s_delay_alu instid0(VALU_DEP_1)                            // 000000821AFC: BF870001
	v_fmac_f32_e32 v37, v53, v8                                // 000000821B00: 564A1135
	s_clause 0x3                                               // 000000821B04: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000821B08: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000821B10: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 000000821B18: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 000000821B20: DC5E0030 2F7C000C
	.long 0xd7006a0c                                           // 000000821B28: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 000000821B2C: 02001D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000821B30: BF8700B1
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 000000821B34: D5207C0D 01AA1A0F
	s_waitcnt vmcnt(3)                                         // 000000821B3C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000821B40: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 000000821B48: CC1A4008 1C226D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821B50: BF870091
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 000000821B54: CC1A4008 1C226F0A
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 000000821B5C: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 000000821B64: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821B68: BF870091
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 000000821B6C: CC1A4008 1C227313
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 000000821B74: CC1A4008 1C227514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821B7C: BF870091
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 000000821B80: CC1A4008 1C227715
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 000000821B88: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 000000821B90: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821B94: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000821B98: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000821BA0: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821BA8: BF870091
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000821BAC: CC1A4008 1C227F2D
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000821BB4: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 000000821BBC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821BC0: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000821BC4: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000821BCC: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821BD4: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000821BD8: CC1A4008 1C228731
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 000000821BE0: CC1A4008 1C228932
	s_delay_alu instid0(VALU_DEP_1)                            // 000000821BE8: BF870001
	v_fmac_f32_e32 v36, v53, v8                                // 000000821BEC: 56481135
	s_clause 0x3                                               // 000000821BF0: BF850003
	global_load_b128 v[8:11], v[51:52], off                    // 000000821BF4: DC5E0000 087C0033
	global_load_b128 v[19:22], v[51:52], off offset:16         // 000000821BFC: DC5E0010 137C0033
	global_load_b128 v[43:46], v[51:52], off offset:32         // 000000821C04: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[51:52], off offset:48         // 000000821C0C: DC5E0030 2F7C0033
	s_waitcnt vmcnt(3)                                         // 000000821C14: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000821C18: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821C20: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 000000821C24: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 000000821C2C: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000821C34: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 000000821C38: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 000000821C40: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 000000821C44: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821C4C: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 000000821C50: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 000000821C58: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000821C60: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 000000821C64: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 000000821C6C: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000821C70: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821C78: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000821C7C: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000821C84: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000821C8C: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000821C90: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 000000821C98: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000821C9C: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821CA4: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000821CA8: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000821CB0: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821CB8: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 000000821CBC: CC1A4008 1C228932
	v_fmac_f32_e32 v35, v53, v8                                // 000000821CC4: 56461135
	s_clause 0x3                                               // 000000821CC8: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000821CCC: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000821CD4: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 000000821CDC: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 000000821CE4: DC5E0030 2F7C000C
	.long 0xd7006a0c                                           // 000000821CEC: D7006A0C
	v_cndmask_b32_e32 v0, v51, v14, vcc_lo                     // 000000821CF0: 02001D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000821CF4: BF8700A1
	v_add_co_ci_u32_e64 v13, null, s15, v52, vcc_lo            // 000000821CF8: D5207C0D 01AA680F
	.long 0xd7006a1c                                           // 000000821D00: D7006A1C
	v_cndmask_b32_e32 v0, v28, v160, vcc_lo                    // 000000821D04: 0201411C
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 000000821D08: D5207C1D 01AA3A80
	s_waitcnt vmcnt(3)                                         // 000000821D10: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000821D14: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821D1C: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 000000821D20: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 000000821D28: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000821D30: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 000000821D34: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 000000821D3C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 000000821D40: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821D48: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 000000821D4C: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 000000821D54: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000821D5C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 000000821D60: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 000000821D68: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000821D6C: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821D74: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000821D78: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000821D80: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000821D88: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000821D8C: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 000000821D94: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000821D98: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821DA0: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000821DA4: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000821DAC: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821DB4: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 000000821DB8: CC1A4008 1C228932
	v_fmac_f32_e32 v34, v53, v8                                // 000000821DC0: 56441135
	s_clause 0x3                                               // 000000821DC4: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000821DC8: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000821DD0: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 000000821DD8: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 000000821DE0: DC5E0030 2F7C000C
	s_waitcnt vmcnt(3)                                         // 000000821DE8: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000821DEC: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821DF4: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 000000821DF8: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 000000821E00: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000821E08: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 000000821E0C: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 000000821E14: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 000000821E18: CC1A4008 1C227313
	v_mov_b32_e32 v19, v15                                     // 000000821E20: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000821E24: BF870122
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 000000821E28: CC1A4008 1C227514
	v_mov_b32_e32 v20, v16                                     // 000000821E30: 7E280310
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 000000821E34: CC1A4008 1C227715
	v_mov_b32_e32 v21, v17                                     // 000000821E3C: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000821E40: BF870132
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 000000821E44: CC1A4008 1C227916
	v_mov_b32_e32 v22, v18                                     // 000000821E4C: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 000000821E50: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000821E54: CC1A4008 1C227B2B
	v_mov_b32_e32 v43, v42                                     // 000000821E5C: 7E56032A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821E60: BF870092
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000821E64: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000821E6C: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000821E74: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000821E78: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 000000821E80: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000821E84: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821E8C: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000821E90: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000821E98: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821EA0: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 000000821EA4: CC1A4008 1C228932
	v_dual_fmac_f32 v31, v53, v8 :: v_dual_mov_b32 v14, v7     // 000000821EAC: C8101135 1F0E0107
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 000000821EB4: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 000000821EBC: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 000000821EC4: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 000000821ECC: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000821ED0: 917E107E
	s_cbranch_execz 28                                         // 000000821ED4: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xe48>
	s_waitcnt vmcnt(0)                                         // 000000821ED8: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v41, 16, v41  // 000000821EDC: CA200114 10285290
	v_dual_mov_b32 v15, v19 :: v_dual_mov_b32 v18, v22         // 000000821EE4: CA100113 0F120116
	v_mov_b32_e32 v17, v21                                     // 000000821EEC: 7E220315
	s_delay_alu instid0(VALU_DEP_3)                            // 000000821EF0: BF870003
	.long 0xd4430002                                           // 000000821EF4: D4430002
	v_cndmask_b32_e32 v1, s20, v41, vcc_lo                     // 000000821EF8: 02025214
	s_mov_b32 s10, exec_lo                                     // 000000821EFC: BE8A007E
	.long 0xd4c4007e                                           // 000000821F00: D4C4007E
	v_cndmask_b32_e32 v1, s20, v41, vcc_lo                     // 000000821F04: 02025214
	s_cbranch_execz 64968                                      // 000000821F08: BFA5FDC8 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x52c>
	.long 0xd7006a00                                           // 000000821F0C: D7006A00
	v_cndmask_b32_e32 v1, v25, v40, vcc_lo                     // 000000821F10: 02025119
	s_delay_alu instid0(VALU_DEP_1)                            // 000000821F14: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 000000821F18: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v32                            // 000000821F20: 7C9A4081
	v_mov_b32_e32 v42, v43                                     // 000000821F24: 7E54032B
	global_load_b128 v[15:18], v[0:1], off                     // 000000821F28: DC5E0000 0F7C0000
	s_cbranch_vccnz 64958                                      // 000000821F30: BFA4FDBE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x52c>
	global_load_d16_b16 v0, v[28:29], off                      // 000000821F34: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 000000821F3C: BF8903F7
	v_cvt_f32_f16_e32 v42, v0                                  // 000000821F40: 7E541700
	s_branch 64953                                             // 000000821F44: BFA0FDB9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x52c>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000821F48: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000821F4C: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000821F50: 8C7E037E
	.long 0xd71f0000                                           // 000000821F54: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000821F58: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000821F5C: 3A020088
	v_xor_b32_e32 v8, 4, v0                                    // 000000821F60: 3A100084
	v_xor_b32_e32 v15, 2, v0                                   // 000000821F64: 3A1E0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000821F68: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000821F6C: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000821F70: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000821F74: 7C9810A0
	v_cndmask_b32_e32 v8, v0, v8, vcc_lo                       // 000000821F78: 02101100
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 000000821F7C: 7C981EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000821F80: BF870002
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000821F84: 30101082
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000821F88: 30020282
	ds_bpermute_b32 v2, v1, v39                                // 000000821F8C: DACC0000 02002701
	s_waitcnt lgkmcnt(0)                                       // 000000821F94: BF89FC07
	v_add_f32_e32 v2, v39, v2                                  // 000000821F98: 06040527
	ds_bpermute_b32 v3, v1, v38                                // 000000821F9C: DACC0000 03002601
	ds_bpermute_b32 v6, v1, v35                                // 000000821FA4: DACC0000 06002301
	ds_bpermute_b32 v7, v1, v34                                // 000000821FAC: DACC0000 07002201
	ds_bpermute_b32 v4, v1, v37                                // 000000821FB4: DACC0000 04002501
	ds_bpermute_b32 v5, v1, v36                                // 000000821FBC: DACC0000 05002401
	ds_bpermute_b32 v1, v1, v31                                // 000000821FC4: DACC0000 01001F01
	ds_bpermute_b32 v9, v8, v2                                 // 000000821FCC: DACC0000 09000208
	v_cndmask_b32_e32 v15, v0, v15, vcc_lo                     // 000000821FD4: 021E1F00
	s_waitcnt lgkmcnt(5)                                       // 000000821FD8: BF89FC57
	v_dual_add_f32 v3, v38, v3 :: v_dual_add_f32 v6, v35, v6   // 000000821FDC: C9080726 03060D23
	s_waitcnt lgkmcnt(3)                                       // 000000821FE4: BF89FC37
	v_dual_add_f32 v7, v34, v7 :: v_dual_add_f32 v4, v37, v4   // 000000821FE8: C9080F22 07040925
	s_waitcnt lgkmcnt(2)                                       // 000000821FF0: BF89FC27
	v_add_f32_e32 v5, v36, v5                                  // 000000821FF4: 060A0B24
	ds_bpermute_b32 v10, v8, v3                                // 000000821FF8: DACC0000 0A000308
	ds_bpermute_b32 v13, v8, v6                                // 000000822000: DACC0000 0D000608
	ds_bpermute_b32 v14, v8, v7                                // 000000822008: DACC0000 0E000708
	ds_bpermute_b32 v11, v8, v4                                // 000000822010: DACC0000 0B000408
	ds_bpermute_b32 v12, v8, v5                                // 000000822018: DACC0000 0C000508
	s_waitcnt lgkmcnt(6)                                       // 000000822020: BF89FC67
	v_add_f32_e32 v1, v31, v1                                  // 000000822024: 0602031F
	s_waitcnt lgkmcnt(5)                                       // 000000822028: BF89FC57
	v_dual_add_f32 v2, v2, v9 :: v_dual_lshlrev_b32 v15, 2, v15// 00000082202C: C9221302 020E1E82
	s_waitcnt lgkmcnt(4)                                       // 000000822034: BF89FC47
	v_add_f32_e32 v3, v3, v10                                  // 000000822038: 06061503
	s_waitcnt lgkmcnt(2)                                       // 00000082203C: BF89FC27
	v_add_f32_e32 v10, v7, v14                                 // 000000822040: 06141D07
	v_xor_b32_e32 v7, 1, v0                                    // 000000822044: 3A0E0081
	s_waitcnt lgkmcnt(1)                                       // 000000822048: BF89FC17
	v_add_f32_e32 v4, v4, v11                                  // 00000082204C: 06081704
	ds_bpermute_b32 v8, v8, v1                                 // 000000822050: DACC0000 08000108
	v_add_f32_e32 v9, v6, v13                                  // 000000822058: 06121B06
	ds_bpermute_b32 v16, v15, v10                              // 00000082205C: DACC0000 10000A0F
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 000000822064: 7C980EA0
	v_cndmask_b32_e32 v0, v0, v7, vcc_lo                       // 000000822068: 02000F00
	ds_bpermute_b32 v6, v15, v3                                // 00000082206C: DACC0000 0600030F
	s_waitcnt lgkmcnt(3)                                       // 000000822074: BF89FC37
	v_add_f32_e32 v5, v5, v12                                  // 000000822078: 060A1905
	ds_bpermute_b32 v12, v15, v4                               // 00000082207C: DACC0000 0C00040F
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 000000822084: 7C943C80
	s_and_b32 s0, vcc_lo, s0                                   // 000000822088: 8B00006A
	s_waitcnt lgkmcnt(3)                                       // 00000082208C: BF89FC37
	v_add_f32_e32 v11, v1, v8                                  // 000000822090: 06161101
	ds_bpermute_b32 v1, v15, v2                                // 000000822094: DACC0000 0100020F
	s_waitcnt lgkmcnt(2)                                       // 00000082209C: BF89FC27
	v_add_f32_e32 v8, v3, v6                                   // 0000008220A0: 06100D03
	ds_bpermute_b32 v13, v15, v5                               // 0000008220A4: DACC0000 0D00050F
	s_waitcnt lgkmcnt(2)                                       // 0000008220AC: BF89FC27
	v_add_f32_e32 v6, v4, v12                                  // 0000008220B0: 060C1904
	ds_bpermute_b32 v14, v15, v9                               // 0000008220B4: DACC0000 0E00090F
	ds_bpermute_b32 v15, v15, v11                              // 0000008220BC: DACC0000 0F000B0F
	v_lshlrev_b32_e32 v17, 2, v0                               // 0000008220C4: 30220082
	s_waitcnt lgkmcnt(3)                                       // 0000008220C8: BF89FC37
	v_add_f32_e32 v7, v2, v1                                   // 0000008220CC: 060E0302
	v_add_f32_e32 v2, v10, v16                                 // 0000008220D0: 0604210A
	s_waitcnt lgkmcnt(2)                                       // 0000008220D4: BF89FC27
	v_add_f32_e32 v0, v5, v13                                  // 0000008220D8: 06001B05
	ds_bpermute_b32 v12, v17, v8                               // 0000008220DC: DACC0000 0C000811
	s_waitcnt lgkmcnt(2)                                       // 0000008220E4: BF89FC27
	v_add_f32_e32 v1, v9, v14                                  // 0000008220E8: 06021D09
	s_waitcnt lgkmcnt(1)                                       // 0000008220EC: BF89FC17
	v_add_f32_e32 v9, v11, v15                                 // 0000008220F0: 06121F0B
	ds_bpermute_b32 v11, v17, v7                               // 0000008220F4: DACC0000 0B000711
	ds_bpermute_b32 v10, v17, v6                               // 0000008220FC: DACC0000 0A000611
	ds_bpermute_b32 v3, v17, v0                                // 000000822104: DACC0000 03000011
	ds_bpermute_b32 v4, v17, v1                                // 00000082210C: DACC0000 04000111
	ds_bpermute_b32 v5, v17, v2                                // 000000822114: DACC0000 05000211
	ds_bpermute_b32 v13, v17, v9                               // 00000082211C: DACC0000 0D000911
	s_and_saveexec_b32 s1, s0                                  // 000000822124: BE812000
	s_cbranch_execz 338                                        // 000000822128: BFA50152 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1574>
	s_waitcnt lgkmcnt(5)                                       // 00000082212C: BF89FC57
	v_dual_add_f32 v7, v7, v11 :: v_dual_add_f32 v8, v8, v12   // 000000822130: C9081707 07081908
	s_waitcnt lgkmcnt(0)                                       // 000000822138: BF89FC07
	v_dual_add_f32 v9, v9, v13 :: v_dual_add_f32 v6, v6, v10   // 00000082213C: C9081B09 09061506
	v_dual_add_f32 v3, v0, v3 :: v_dual_add_f32 v4, v1, v4     // 000000822144: C9080700 03040901
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000082214C: BF870233
	v_bfe_u32 v10, v7, 16, 1                                   // 000000822150: D610000A 02052107
	v_bfe_u32 v11, v8, 16, 1                                   // 000000822158: D610000B 02052108
	v_add_f32_e32 v2, v2, v5                                   // 000000822160: 06040B02
	v_bfe_u32 v12, v3, 16, 1                                   // 000000822164: D610000C 02052103
	v_bfe_u32 v13, v4, 16, 1                                   // 00000082216C: D610000D 02052104
	v_add3_u32 v5, v7, v10, 0x7fff                             // 000000822174: D6550005 03FE1507 00007FFF
	v_add3_u32 v7, v8, v11, 0x7fff                             // 000000822180: D6550007 03FE1708 00007FFF
	v_bfe_u32 v11, v6, 16, 1                                   // 00000082218C: D610000B 02052106
	v_add3_u32 v3, v3, v12, 0x7fff                             // 000000822194: D6550003 03FE1903 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 0000008221A0: D6550004 03FE1B04 00007FFF
	v_bfe_u32 v15, v9, 16, 1                                   // 0000008221AC: D610000F 02052109
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000008221B4: 360E0EFF FFFF0000
	v_add3_u32 v6, v6, v11, 0x7fff                             // 0000008221BC: D6550006 03FE1706 00007FFF
	v_bfe_u32 v14, v2, 16, 1                                   // 0000008221C8: D610000E 02052102
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000008221D0: 360808FF FFFF0000
	v_add3_u32 v9, v9, v15, 0x7fff                             // 0000008221D8: D6550009 03FE1F09 00007FFF
	v_mul_f32_e32 v7, 0xbfb8aa3b, v7                           // 0000008221E4: 100E0EFF BFB8AA3B
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000008221EC: 360C0CFF FFFF0000
	v_add3_u32 v11, v2, v14, 0x7fff                            // 0000008221F4: D655000B 03FE1D02 00007FFF
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 000000822200: 100808FF BFB8AA3B
	v_and_b32_e32 v2, 0xffff0000, v3                           // 000000822208: 360406FF FFFF0000
	v_exp_f32_e32 v7, v7                                       // 000000822210: 7E0E4B07
	v_mul_f32_e32 v3, 0xbfb8aa3b, v6                           // 000000822214: 10060CFF BFB8AA3B
	.long 0xd73c0000                                           // 00000082221C: D73C0000
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 000000822220: 02022E81
	s_lshl_b64 s[0:1], s[12:13], 1                             // 000000822224: 8480810C
	.long 0x7f103880                                           // 000000822228: 7F103880
	v_exp_f32_e32 v4, v4                                       // 00000082222C: 7E084B04
	v_exp_f32_e32 v14, v3                                      // 000000822230: 7E1C4B03
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000822234: 360A0AFF FFFF0000
	.long 0xd7006a00                                           // 00000082223C: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000822240: 02020008
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000822244: BF8701C7
	v_add_f32_e32 v7, 1.0, v7                                  // 000000822248: 060E0EF2
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000082224C: D5207C01 01AA0209
	.long 0x7f143988                                           // 000000822254: 7F143988
	s_lshl_b64 s[4:5], s[12:13], 2                             // 000000822258: 8484820C
	v_div_scale_f32 v12, null, v7, v7, 1.0                     // 00000082225C: D6FC7C0C 03CA0F07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000822264: BF870115
	v_add_f32_e32 v14, 1.0, v14                                // 000000822268: 061C1CF2
	v_rcp_f32_e32 v16, v12                                     // 00000082226C: 7E20550C
	s_waitcnt vmcnt(0)                                         // 000000822270: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000822274: BF870291
	v_div_scale_f32 v21, null, v14, v14, 1.0                   // 000000822278: D6FC7C15 03CA1D0E
	v_fma_f32 v18, -v12, v16, 1.0                              // 000000822280: D6130012 23CA210C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000822288: BF870091
	v_dual_mul_f32 v5, 0xbfb8aa3b, v5 :: v_dual_fmac_f32 v16, v18, v16// 00000082228C: C8C00AFF 05102112 BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 000000822298: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082229C: BF870095
	v_add_f32_e32 v5, 1.0, v5                                  // 0000008222A0: 060A0AF2
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 0000008222A4: D6FC7C06 03CA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000008222AC: BF870291
	v_rcp_f32_e32 v15, v6                                      // 0000008222B0: 7E1E5506
	v_fma_f32 v17, -v6, v15, 1.0                               // 0000008222B4: D6130011 23CA1F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008222BC: BF8700B1
	v_fmac_f32_e32 v15, v17, v15                               // 0000008222C0: 561E1F11
	v_mul_f32_e32 v13, 0xbfb8aa3b, v2                          // 0000008222C4: 101A04FF BFB8AA3B
	.long 0xd7006a02                                           // 0000008222CC: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000008222D0: 02000100
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 0000008222D4: D5207C03 01AA0201
	v_div_scale_f32 v19, vcc_lo, 1.0, v5, 1.0                  // 0000008222DC: D6FC6A13 03CA0AF2
	v_div_scale_f32 v20, s0, 1.0, v7, 1.0                      // 0000008222E4: D6FC0014 03CA0EF2
	v_rcp_f32_e32 v17, v21                                     // 0000008222EC: 7E225515
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008222F0: BF870112
	v_mul_f32_e32 v18, v19, v15                                // 0000008222F4: 10241F13
	v_mul_f32_e32 v22, v20, v16                                // 0000008222F8: 102C2114
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008222FC: BF870112
	v_fma_f32 v23, -v6, v18, v19                               // 000000822300: D6130017 244E2506
	v_fma_f32 v24, -v12, v22, v20                              // 000000822308: D6130018 24522D0C
	v_and_b32_e32 v11, 0xffff0000, v11                         // 000000822310: 361616FF FFFF0000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000822318: BF870215
	v_fma_f32 v26, -v21, v17, 1.0                              // 00000082231C: D613001A 23CA2315
	v_fmac_f32_e32 v18, v23, v15                               // 000000822324: 56241F17
	v_exp_f32_e32 v13, v13                                     // 000000822328: 7E1A4B0D
	v_fmac_f32_e32 v22, v24, v16                               // 00000082232C: 562C2118
	v_div_scale_f32 v23, s1, 1.0, v14, 1.0                     // 000000822330: D6FC0117 03CA1CF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000822338: BF870193
	v_fma_f32 v6, -v6, v18, v19                                // 00000082233C: D6130006 244E2506
	v_fma_f32 v12, -v12, v22, v20                              // 000000822344: D613000C 24522D0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000082234C: BF870292
	v_div_fmas_f32 v6, v6, v15, v18                            // 000000822350: D6370006 044A1F06
	v_add_f32_e32 v13, 1.0, v13                                // 000000822358: 061A1AF2
	s_mov_b32 vcc_lo, s0                                       // 00000082235C: BEEA0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000822360: BF870112
	v_div_fixup_f32 v5, v6, v5, 1.0                            // 000000822364: D6270005 03CA0B06
	v_div_scale_f32 v25, null, v13, v13, 1.0                   // 00000082236C: D6FC7C19 03CA1B0D
	v_div_scale_f32 v19, s2, 1.0, v13, 1.0                     // 000000822374: D6FC0213 03CA1AF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000082237C: BF870193
	.long 0x7e143985                                           // 000000822380: 7E143985
	v_rcp_f32_e32 v24, v25                                     // 000000822384: 7E305519
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000822388: BF8701B1
	v_dual_fmac_f32 v17, v26, v17 :: v_dual_and_b32 v10, 1, v10// 00000082238C: C824231A 110A1481
	v_mul_f32_e32 v11, 0xbfb8aa3b, v11                         // 000000822394: 101616FF BFB8AA3B
	v_add_f32_e32 v15, 1.0, v4                                 // 00000082239C: 061E08F2
	v_add3_u32 v5, v5, v10, 0x7fff                             // 0000008223A0: D6550005 03FE1505 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000008223AC: BF8700C5
	v_fma_f32 v6, -v25, v24, 1.0                               // 0000008223B0: D6130006 23CA3119
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000008223B8: 361212FF FFFF0000
	global_store_d16_hi_b16 v[0:1], v5, off                    // 0000008223C0: DC960000 007C0500
	v_dual_fmac_f32 v24, v6, v24 :: v_dual_mul_f32 v9, 0xbfb8aa3b, v9// 0000008223C8: C8063106 180812FF BFB8AA3B
	v_mul_f32_e32 v18, v19, v24                                // 0000008223D4: 10243113
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008223D8: BF870002
	v_exp_f32_e32 v4, v9                                       // 0000008223DC: 7E084B09
	v_div_fmas_f32 v9, v12, v16, v22                           // 0000008223E0: D6370009 045A210C
	v_mul_f32_e32 v16, v23, v17                                // 0000008223E8: 10202317
	v_exp_f32_e32 v11, v11                                     // 0000008223EC: 7E164B0B
	s_mov_b32 vcc_lo, s1                                       // 0000008223F0: BEEA0001
	v_fma_f32 v10, -v25, v18, v19                              // 0000008223F4: D613000A 244E2519
	v_div_fixup_f32 v7, v9, v7, 1.0                            // 0000008223FC: D6270007 03CA0F09
	v_fma_f32 v9, -v21, v16, v23                               // 000000822404: D6130009 245E2115
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000082240C: BF870193
	v_fmac_f32_e32 v18, v10, v24                               // 000000822410: 5624310A
	.long 0x7e103987                                           // 000000822414: 7E103987
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 000000822418: BF870185
	v_dual_fmac_f32 v16, v9, v17 :: v_dual_add_f32 v11, 1.0, v11// 00000082241C: C8082309 100A16F2
	v_div_scale_f32 v12, null, v15, v15, 1.0                   // 000000822424: D6FC7C0C 03CA1F0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000082242C: BF870192
	v_fma_f32 v21, -v21, v16, v23                              // 000000822430: D6130015 245E2115
	v_div_scale_f32 v6, null, v11, v11, 1.0                    // 000000822438: D6FC7C06 03CA170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000822440: BF870093
	v_rcp_f32_e32 v20, v12                                     // 000000822444: 7E28550C
	v_rcp_f32_e32 v22, v6                                      // 000000822448: 7E2C5506
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000082244C: BF870296
	v_fma_f32 v5, -v12, v20, 1.0                               // 000000822450: D6130005 23CA290C
	v_fma_f32 v10, -v6, v22, 1.0                               // 000000822458: D613000A 23CA2D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000822460: BF870091
	v_dual_fmac_f32 v22, v10, v22 :: v_dual_and_b32 v9, 1, v8  // 000000822464: C8242D0A 16081081
	v_add3_u32 v7, v7, v9, 0x7fff                              // 00000082246C: D6550007 03FE1307 00007FFF
	v_add_f32_e32 v9, 1.0, v4                                  // 000000822478: 061208F2
	v_div_scale_f32 v10, s1, 1.0, v11, 1.0                     // 00000082247C: D6FC010A 03CA16F2
	v_div_fmas_f32 v4, v21, v17, v16                           // 000000822484: D6370004 04422315
	v_fma_f32 v16, -v25, v18, v19                              // 00000082248C: D6130010 244E2519
	v_fmac_f32_e32 v20, v5, v20                                // 000000822494: 56282905
	v_div_scale_f32 v17, null, v9, v9, 1.0                     // 000000822498: D6FC7C11 03CA1309
	v_div_scale_f32 v5, s0, 1.0, v15, 1.0                      // 0000008224A0: D6FC0005 03CA1EF2
	v_mul_f32_e32 v21, v10, v22                                // 0000008224A8: 102A2D0A
	s_mov_b32 vcc_lo, s2                                       // 0000008224AC: BEEA0002
	global_store_d16_hi_b16 v[2:3], v7, off                    // 0000008224B0: DC960000 007C0702
	v_rcp_f32_e32 v19, v17                                     // 0000008224B8: 7E265511
	v_div_fmas_f32 v16, v16, v24, v18                          // 0000008224BC: D6370010 044A3110
	v_fma_f32 v7, -v6, v21, v10                                // 0000008224C4: D6130007 242A2B06
	v_mul_f32_e32 v18, v5, v20                                 // 0000008224CC: 10242905
	v_div_fixup_f32 v14, v4, v14, 1.0                          // 0000008224D0: D627000E 03CA1D04
	s_mov_b32 vcc_lo, s0                                       // 0000008224D8: BEEA0000
	v_div_fixup_f32 v2, v16, v13, 1.0                          // 0000008224DC: D6270002 03CA1B10
	v_fmac_f32_e32 v21, v7, v22                                // 0000008224E4: 562A2D07
	v_fma_f32 v3, -v12, v18, v5                                // 0000008224E8: D6130003 2416250C
	v_div_scale_f32 v7, s2, 1.0, v9, 1.0                       // 0000008224F0: D6FC0207 03CA12F2
	v_fma_f32 v13, -v17, v19, 1.0                              // 0000008224F8: D613000D 23CA2711
	.long 0x7e103982                                           // 000000822500: 7E103982
	v_fma_f32 v4, -v6, v21, v10                                // 000000822504: D6130004 242A2B06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000082250C: BF870193
	v_dual_fmac_f32 v18, v3, v20 :: v_dual_fmac_f32 v19, v13, v19// 000000822510: C8002903 1212270D
	v_and_b32_e32 v16, 1, v8                                   // 000000822518: 36201081
	.long 0x7e1a398e                                           // 00000082251C: 7E1A398E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000822520: BF8701B3
	v_fma_f32 v3, -v12, v18, v5                                // 000000822524: D6130003 2416250C
	.long 0x7f1a3988                                           // 00000082252C: 7F1A3988
	v_mul_f32_e32 v5, v7, v19                                  // 000000822530: 100A2707
	v_div_fmas_f32 v6, v3, v20, v18                            // 000000822534: D6370006 044A2903
	s_mov_b32 vcc_lo, s1                                       // 00000082253C: BEEA0001
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000822540: BF8700B2
	v_fma_f32 v12, -v17, v5, v7                                // 000000822544: D613000C 241E0B11
	v_div_fmas_f32 v10, v4, v22, v21                           // 00000082254C: D637000A 04562D04
	.long 0xd7006a03                                           // 000000822554: D7006A03
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000822558: 02000900
	v_add_co_ci_u32_e64 v4, null, s5, v1, vcc_lo               // 00000082255C: D5207C04 01AA0205
	s_delay_alu instid0(VALU_DEP_3)                            // 000000822564: BF870003
	v_div_fixup_f32 v10, v10, v11, 1.0                         // 000000822568: D627000A 03CA170A
	v_mad_u64_u32 v[0:1], null, s12, 6, v[0:1]                 // 000000822570: D6FE7C00 04010C0C
	v_div_fixup_f32 v11, v6, v15, 1.0                          // 000000822578: D627000B 03CA1F06
	s_mov_b32 vcc_lo, s2                                       // 000000822580: BEEA0002
	.long 0x7f0c3988                                           // 000000822584: 7F0C3988
	.long 0x7e10398a                                           // 000000822588: 7E10398A
	v_fmac_f32_e32 v5, v12, v19                                // 00000082258C: 560A270C
	v_add3_u32 v12, v2, v16, 0x7fff                            // 000000822590: D655000C 03FE2102 00007FFF
	.long 0x7e0c398b                                           // 00000082259C: 7E0C398B
	v_and_b32_e32 v13, 1, v13                                  // 0000008225A0: 361A1A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008225A4: BF870194
	v_fma_f32 v2, -v17, v5, v7                                 // 0000008225A8: D6130002 241E0B11
	v_and_b32_e32 v7, 1, v6                                    // 0000008225B0: 360E0C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008225B4: BF870193
	v_add3_u32 v13, v14, v13, 0x7fff                           // 0000008225B8: D655000D 03FE1B0E 00007FFF
	v_div_fmas_f32 v5, v2, v19, v5                             // 0000008225C4: D6370005 04162702
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 0000008225CC: D6FE7C01 04050C0D
	v_and_b32_e32 v2, 1, v8                                    // 0000008225D4: 36041081
	v_add3_u32 v11, v11, v7, 0x7fff                            // 0000008225D8: D655000B 03FE0F0B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008225E4: BF870224
	v_div_fixup_f32 v9, v5, v9, 1.0                            // 0000008225E8: D6270009 03CA1305
	.long 0xd7006a05                                           // 0000008225F0: D7006A05
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 0000008225F4: 02000903
	v_add3_u32 v2, v10, v2, 0x7fff                             // 0000008225F8: D6550002 03FE050A 00007FFF
	v_add_co_ci_u32_e64 v6, null, s5, v4, vcc_lo               // 000000822604: D5207C06 01AA0805
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082260C: BF8700A4
	v_bfe_u32 v10, v9, 16, 1                                   // 000000822610: D610000A 02052109
	.long 0xd7006a07                                           // 000000822618: D7006A07
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 00000082261C: 02000900
	v_add_co_ci_u32_e64 v8, null, s5, v1, vcc_lo               // 000000822620: D5207C08 01AA0205
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000822628: BF8700A3
	v_add3_u32 v14, v9, v10, 0x7fff                            // 00000082262C: D655000E 03FE1509 00007FFF
	.long 0xd7006a09                                           // 000000822638: D7006A09
	v_cndmask_b32_e32 v0, v5, v4, vcc_lo                       // 00000082263C: 02000905
	v_add_co_ci_u32_e64 v10, null, s5, v6, vcc_lo              // 000000822640: D5207C0A 01AA0C05
	s_clause 0x4                                               // 000000822648: BF850004
	global_store_d16_hi_b16 v[3:4], v13, off                   // 00000082264C: DC960000 007C0D03
	global_store_d16_hi_b16 v[0:1], v12, off                   // 000000822654: DC960000 007C0C00
	global_store_d16_hi_b16 v[5:6], v11, off                   // 00000082265C: DC960000 007C0B05
	global_store_d16_hi_b16 v[7:8], v2, off                    // 000000822664: DC960000 007C0207
	global_store_d16_hi_b16 v[9:10], v14, off                  // 00000082266C: DC960000 007C0E09
	s_endpgm                                                   // 000000822674: BFB00000
		...

