00000000002e0300 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi1EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi1EEEvPKhPKtPtll():
	s_clause 0x1                                               // 0000002E0300: BF850001
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000002E0304: F4040300 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 0000002E030C: F40C0100 F8000000
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000002E0314: 32020085
	s_mov_b32 s3, 0                                            // 0000002E0318: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 0000002E031C: CA240080 100E009F
	s_lshl_b64 s[0:1], s[2:3], 3                               // 0000002E0324: 84808302
	v_mov_b32_e32 v19, 0                                       // 0000002E0328: 7E260280
	v_or_b32_e32 v9, s0, v1                                    // 0000002E032C: 38120200
	v_dual_mov_b32 v10, s1 :: v_dual_mov_b32 v3, 0             // 0000002E0330: CA100001 0A020080
	v_lshlrev_b32_e32 v11, 4, v15                              // 0000002E0338: 30161E84
	s_waitcnt lgkmcnt(0)                                       // 0000002E033C: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002E0340: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 0000002E0344: 7CA8120C
	s_ashr_i32 s0, s11, 31                                     // 0000002E0348: 86009F0B
	s_lshr_b32 s0, s0, 28                                      // 0000002E034C: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000002E0350: BF8704D9
	s_add_u32 s2, s10, s0                                      // 0000002E0354: 8002000A
	s_addc_u32 s3, s11, 0                                      // 0000002E0358: 8203800B
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 0000002E035C: 02021280
	v_cndmask_b32_e64 v2, 0, s1, vcc_lo                        // 0000002E0360: D5010002 01A80280
	s_ashr_i64 s[2:3], s[2:3], 4                               // 0000002E0368: 86828402
	s_add_u32 s0, s2, s10                                      // 0000002E036C: 80000A02
	s_addc_u32 s1, s3, s11                                     // 0000002E0370: 82010B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000002E0374: BF870251
	.long 0xd72c0004                                           // 0000002E0378: D72C0004
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 0000002E037C: 02000102
	v_mad_u64_u32 v[5:6], null, v1, s0, 0                      // 0000002E0380: D6FE7C05 02000101
	.long 0xd72c0007                                           // 0000002E0388: D72C0007
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 0000002E038C: 02000301
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000002E0390: CA100080 01020080
	.long 0xd4440000                                           // 0000002E0398: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 0000002E039C: 02021E02
	.long 0xd7000111                                           // 0000002E03A0: D7000111
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000002E03A4: 02020A04
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002E03A8: BF870124
	v_add3_u32 v6, v6, v7, v4                                  // 0000002E03AC: D6550006 04120F06
	v_mov_b32_e32 v4, 0                                        // 0000002E03B4: 7E080280
	v_add_co_ci_u32_e64 v18, null, s5, v6, s1                  // 0000002E03B8: D5207C12 00060C05
	s_and_saveexec_b32 s3, s0                                  // 0000002E03C0: BE832000
	s_cbranch_execz 21                                         // 0000002E03C4: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi1EEEvPKhPKtPtll+0x11c>
	v_lshlrev_b32_e32 v1, 4, v15                               // 0000002E03C8: 30021E84
	.long 0xd7000103                                           // 0000002E03CC: D7000103
	v_cndmask_b32_e32 v0, v17, v10, vcc_lo                     // 0000002E03D0: 02001511
	v_and_b32_e32 v7, 28, v0                                   // 0000002E03D4: 360E009C
	v_add_co_ci_u32_e64 v4, null, s11, v18, s1                 // 0000002E03D8: D5207C04 0006240B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E03E0: BF870094
	.long 0xd7000101                                           // 0000002E03E4: D7000101
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000002E03E8: 02020311
	v_add_co_ci_u32_e64 v2, null, 0, v18, s1                   // 0000002E03EC: D5207C02 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E03F4: BF870094
	.long 0xd7000107                                           // 0000002E03F8: D7000107
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 0000002E03FC: 02020F03
	v_add_co_ci_u32_e64 v8, null, 0, v4, s1                    // 0000002E0400: D5207C08 00060880
	s_clause 0x1                                               // 0000002E0408: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 0000002E040C: DC5E0000 017C0001
	global_load_b32 v19, v[7:8], off                           // 0000002E0414: DC520000 137C0007
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002E041C: 8C7E037E
	s_and_saveexec_b32 s3, s0                                  // 0000002E0420: BE832000
	s_cbranch_execz 271                                        // 0000002E0424: BFA5010F <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi1EEEvPKhPKtPtll+0x564>
	v_and_or_b32 v0, v0, 28, 32                                // 0000002E0428: D6570000 02813900
	.long 0xd7000005                                           // 0000002E0430: D7000005
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000002E0434: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E0438: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s11, v6, s0                  // 0000002E043C: D5207C06 00020C0B
	v_mov_b32_e32 v12, 0                                       // 0000002E0444: 7E180280
	.long 0xd7000000                                           // 0000002E0448: D7000000
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 0000002E044C: 02020105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E0450: BF870191
	v_add_co_ci_u32_e64 v5, null, 0, v6, s0                    // 0000002E0454: D5207C05 00020C80
	v_mov_b32_e32 v16, v12                                     // 0000002E045C: 7E20030C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E0460: BF870093
	.long 0xd700000d                                           // 0000002E0464: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002E0468: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v5, s0                  // 0000002E046C: D5207C0E 00020A05
	v_mov_b32_e32 v0, v15                                      // 0000002E0474: 7E00030F
	s_mov_b32 s4, 0                                            // 0000002E0478: BE840080
	s_branch 218                                               // 0000002E047C: BFA000DA <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi1EEEvPKhPKtPtll+0x4e8>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000002E0480: 8C7E057E
	.long 0xd73c0016                                           // 0000002E0484: D73C0016
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002E0488: 02021681
	v_cvt_f32_ubyte0_e32 v11, v1                               // 0000002E048C: 7E162301
	v_cvt_f32_ubyte1_e32 v31, v1                               // 0000002E0490: 7E3E2501
	v_cvt_f32_ubyte2_e32 v32, v1                               // 0000002E0494: 7E402701
	v_cvt_f32_ubyte3_e32 v1, v1                                // 0000002E0498: 7E022901
	v_cvt_f32_ubyte0_e32 v33, v2                               // 0000002E049C: 7E422302
	.long 0xd700011a                                           // 0000002E04A0: D700011A
	v_cndmask_b32_e32 v1, s6, v22, vcc_lo                      // 0000002E04A4: 02022C06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002E04A8: BF870001
	v_add_co_ci_u32_e64 v27, null, s7, v23, s1                 // 0000002E04AC: D5207C1B 00062E07
	v_cvt_f32_ubyte1_e32 v34, v2                               // 0000002E04B4: 7E442502
	v_cvt_f32_ubyte2_e32 v35, v2                               // 0000002E04B8: 7E462702
	v_cvt_f32_ubyte3_e32 v2, v2                                // 0000002E04BC: 7E042902
	s_clause 0x1                                               // 0000002E04C0: BF850001
	global_load_b128 v[22:25], v[26:27], off                   // 0000002E04C4: DC5E0000 167C001A
	global_load_b128 v[26:29], v[26:27], off offset:16         // 0000002E04CC: DC5E0010 1A7C001A
	v_cvt_f32_ubyte0_e32 v36, v3                               // 0000002E04D4: 7E482303
	v_cvt_f32_ubyte1_e32 v37, v3                               // 0000002E04D8: 7E4A2503
	v_cvt_f32_ubyte2_e32 v38, v3                               // 0000002E04DC: 7E4C2703
	v_cvt_f32_ubyte3_e32 v3, v3                                // 0000002E04E0: 7E062903
	v_cvt_f32_ubyte0_e32 v39, v4                               // 0000002E04E4: 7E4E2304
	v_cvt_f32_ubyte1_e32 v40, v4                               // 0000002E04E8: 7E502504
	v_cvt_f32_ubyte2_e32 v41, v4                               // 0000002E04EC: 7E522704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 0000002E04F0: 7E082904
	v_fma_mix_f32 v11, v11, v19, v19 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E04F4: CC20600B 144E270B
	v_fma_mix_f32 v31, v31, v19, v19 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E04FC: CC20601F 144E271F
	v_fma_mix_f32 v32, v32, v19, v19 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E0504: CC206020 144E2720
	v_fma_mix_f32 v1, v1, v19, v19 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E050C: CC206001 144E2701
	v_fma_mix_f32 v33, v33, v19, v19 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E0514: CC206021 144E2721
	v_fma_mix_f32 v34, v34, v19, v19 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E051C: CC206022 144E2722
	v_fma_mix_f32 v35, v35, v19, v19 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E0524: CC206023 144E2723
	v_fma_mix_f32 v2, v2, v19, v19 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E052C: CC206002 144E2702
	v_fma_mix_f32 v36, v36, v19, v19 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E0534: CC206024 144E2724
	v_fma_mix_f32 v37, v37, v19, v19 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E053C: CC206025 144E2725
	v_fma_mix_f32 v38, v38, v19, v19 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E0544: CC206026 144E2726
	v_fma_mix_f32 v3, v3, v19, v19 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E054C: CC206003 144E2703
	v_fma_mix_f32 v39, v39, v19, v19 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E0554: CC206027 144E2727
	v_fma_mix_f32 v40, v40, v19, v19 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E055C: CC206028 144E2728
	v_fma_mix_f32 v41, v41, v19, v19 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E0564: CC206029 144E2729
	v_fma_mix_f32 v4, v4, v19, v19 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E056C: CC206004 144E2704
	v_bfe_u32 v19, v11, 16, 1                                  // 0000002E0574: D6100013 0205210B
	v_bfe_u32 v45, v31, 16, 1                                  // 0000002E057C: D610002D 0205211F
	v_bfe_u32 v46, v32, 16, 1                                  // 0000002E0584: D610002E 02052120
	.long 0x7f3c3880                                           // 0000002E058C: 7F3C3880
	v_bfe_u32 v47, v1, 16, 1                                   // 0000002E0590: D610002F 02052101
	v_add3_u32 v11, v11, v19, 0x7fff                           // 0000002E0598: D655000B 03FE270B 00007FFF
	v_bfe_u32 v48, v33, 16, 1                                  // 0000002E05A4: D6100030 02052121
	v_add3_u32 v32, v32, v46, 0x7fff                           // 0000002E05AC: D6550020 03FE5D20 00007FFF
	v_add3_u32 v31, v31, v45, 0x7fff                           // 0000002E05B8: D655001F 03FE5B1F 00007FFF
	.long 0x7f54399e                                           // 0000002E05C4: 7F54399E
	.long 0x7e3c398b                                           // 0000002E05C8: 7E3C398B
	v_bfe_u32 v49, v34, 16, 1                                  // 0000002E05CC: D6100031 02052122
	v_bfe_u32 v50, v35, 16, 1                                  // 0000002E05D4: D6100032 02052123
	v_add3_u32 v1, v1, v47, 0x7fff                             // 0000002E05DC: D6550001 03FE5F01 00007FFF
	.long 0x7e5439a0                                           // 0000002E05E8: 7E5439A0
	v_add3_u32 v32, v33, v48, 0x7fff                           // 0000002E05EC: D6550020 03FE6121 00007FFF
	v_and_or_b32 v31, 0xffff0000, v31, v30                     // 0000002E05F8: D657001F 047A3EFF FFFF0000
	v_bfe_u32 v51, v2, 16, 1                                   // 0000002E0604: D6100033 02052102
	v_bfe_u32 v52, v36, 16, 1                                  // 0000002E060C: D6100034 02052124
	v_add3_u32 v33, v34, v49, 0x7fff                           // 0000002E0614: D6550021 03FE6322 00007FFF
	v_add3_u32 v34, v35, v50, 0x7fff                           // 0000002E0620: D6550022 03FE6523 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v42                       // 0000002E062C: D6570001 04AA02FF FFFF0000
	.long 0x7e3c39a0                                           // 0000002E0638: 7E3C39A0
	.long 0x7f56399e                                           // 0000002E063C: 7F56399E
	v_bfe_u32 v53, v37, 16, 1                                  // 0000002E0640: D6100035 02052125
	v_bfe_u32 v54, v38, 16, 1                                  // 0000002E0648: D6100036 02052126
	v_add3_u32 v2, v2, v51, 0x7fff                             // 0000002E0650: D6550002 03FE6702 00007FFF
	.long 0x7e5639a2                                           // 0000002E065C: 7E5639A2
	v_and_or_b32 v32, 0xffff0000, v33, v30                     // 0000002E0660: D6570020 047A42FF FFFF0000
	v_bfe_u32 v55, v3, 16, 1                                   // 0000002E066C: D6100037 02052103
	v_bfe_u32 v56, v39, 16, 1                                  // 0000002E0674: D6100038 02052127
	.long 0x7f58399e                                           // 0000002E067C: 7F58399E
	v_and_or_b32 v2, 0xffff0000, v2, v43                       // 0000002E0680: D6570002 04AE04FF FFFF0000
	v_bfe_u32 v19, v40, 16, 1                                  // 0000002E068C: D6100013 02052128
	v_bfe_u32 v57, v41, 16, 1                                  // 0000002E0694: D6100039 02052129
	v_add3_u32 v3, v3, v55, 0x7fff                             // 0000002E069C: D6550003 03FE6F03 00007FFF
	v_bfe_u32 v11, v4, 16, 1                                   // 0000002E06A8: D610000B 02052104
	s_and_b32 s1, exec_lo, s0                                  // 0000002E06B0: 8B01007E
	.long 0xd700000d                                           // 0000002E06B4: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 0000002E06B8: 0201410D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E06BC: BF870191
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 0000002E06C0: D5207C0E 00021C80
	v_add3_u32 v4, v4, v11, 0x7fff                             // 0000002E06C8: D6550004 03FE1704 00007FFF
	v_mov_b32_e32 v11, v20                                     // 0000002E06D4: 7E160314
	s_or_b32 s4, s1, s4                                        // 0000002E06D8: 8C040401
	s_waitcnt vmcnt(1)                                         // 0000002E06DC: BF8907F7
	v_dot2_f32_bf16 v22, v22, v31, 0                           // 0000002E06E0: CC1A4016 1A023F16
	v_add3_u32 v31, v36, v52, 0x7fff                           // 0000002E06E8: D655001F 03FE6924 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000002E06F4: BF870232
	v_dot2_f32_bf16 v1, v23, v1, v22                           // 0000002E06F8: CC1A4001 1C5A0317
	v_add3_u32 v22, v37, v53, 0x7fff                           // 0000002E0700: D6550016 03FE6B25 00007FFF
	v_add3_u32 v23, v38, v54, 0x7fff                           // 0000002E070C: D6550017 03FE6D26 00007FFF
	.long 0x7e3c399f                                           // 0000002E0718: 7E3C399F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002E071C: BF870224
	v_dot2_f32_bf16 v1, v24, v32, v1                           // 0000002E0720: CC1A4001 1C064118
	v_add3_u32 v24, v39, v56, 0x7fff                           // 0000002E0728: D6550018 03FE7127 00007FFF
	.long 0x7e583997                                           // 0000002E0734: 7E583997
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002E0738: BF870214
	v_and_or_b32 v22, 0xffff0000, v22, v30                     // 0000002E073C: D6570016 047A2CFF FFFF0000
	v_dot2_f32_bf16 v1, v25, v2, v1                            // 0000002E0748: CC1A4001 1C060519
	v_add3_u32 v2, v40, v19, 0x7fff                            // 0000002E0750: D6550002 03FE2728 00007FFF
	v_add3_u32 v19, v41, v57, 0x7fff                           // 0000002E075C: D6550013 03FE7329 00007FFF
	v_and_or_b32 v3, 0xffff0000, v3, v44                       // 0000002E0768: D6570003 04B206FF FFFF0000
	.long 0x7e3c3998                                           // 0000002E0774: 7E3C3998
	s_waitcnt vmcnt(0)                                         // 0000002E0778: BF8903F7
	v_dot2_f32_bf16 v1, v26, v22, v1                           // 0000002E077C: CC1A4001 1C062D1A
	.long 0x7f2c399e                                           // 0000002E0784: 7F2C399E
	.long 0x7e2c3993                                           // 0000002E0788: 7E2C3993
	v_and_or_b32 v2, 0xffff0000, v2, v30                       // 0000002E078C: D6570002 047A04FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E0798: BF870194
	v_dot2_f32_bf16 v1, v27, v3, v1                            // 0000002E079C: CC1A4001 1C06071B
	v_and_or_b32 v3, 0xffff0000, v4, v22                       // 0000002E07A4: D6570003 045A08FF FFFF0000
	v_mov_b32_e32 v4, v8                                       // 0000002E07B0: 7E080308
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002E07B4: BF870123
	v_dot2_f32_bf16 v1, v28, v2, v1                            // 0000002E07B8: CC1A4001 1C06051C
	v_mov_b32_e32 v2, v6                                       // 0000002E07C0: 7E040306
	v_dot2_f32_bf16 v19, v29, v3, v1                           // 0000002E07C4: CC1A4013 1C06071D
	v_mov_b32_e32 v3, v7                                       // 0000002E07CC: 7E060307
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002E07D0: BF870002
	v_dual_mov_b32 v1, v5 :: v_dual_add_f32 v16, v16, v19      // 0000002E07D4: CA080105 01102710
	v_mov_b32_e32 v19, v21                                     // 0000002E07DC: 7E260315
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000002E07E0: 917E047E
	s_cbranch_execz 30                                         // 0000002E07E4: BFA5001E <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi1EEEvPKhPKtPtll+0x560>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002E07E8: BF870121
	v_add_nc_u32_e32 v0, 32, v0                                // 0000002E07EC: 4A0000A0
	v_add_nc_u32_e32 v20, 0x200, v11                           // 0000002E07F0: 4A2816FF 00000200
	.long 0xd4430000                                           // 0000002E07F8: D4430000
	v_cndmask_b32_e32 v1, s2, v0, vcc_lo                       // 0000002E07FC: 02020002
	s_and_saveexec_b32 s1, s0                                  // 0000002E0800: BE812000
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002E0804: BF870009
	s_xor_b32 s1, exec_lo, s1                                  // 0000002E0808: 8D01017E
	v_add_nc_u32_e32 v20, 0x200, v11                           // 0000002E080C: 4A2816FF 00000200
	s_or_saveexec_b32 s5, s1                                   // 0000002E0814: BE852201
	s_waitcnt vmcnt(0)                                         // 0000002E0818: BF8903F7
	v_dual_mov_b32 v21, v19 :: v_dual_mov_b32 v6, v2           // 0000002E081C: CA100113 15060102
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000002E0824: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000002E082C: 7E0E0303
	s_xor_b32 exec_lo, exec_lo, s5                             // 0000002E0830: 8D7E057E
	s_cbranch_execz 65298                                      // 0000002E0834: BFA5FF12 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi1EEEvPKhPKtPtll+0x180>
	.long 0xd7000105                                           // 0000002E0838: D7000105
	v_cndmask_b32_e32 v1, v17, v20, vcc_lo                     // 0000002E083C: 02022911
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002E0840: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v18, s1                   // 0000002E0844: D5207C06 00062480
	global_load_b128 v[5:8], v[5:6], off                       // 0000002E084C: DC5E0000 057C0005
	global_load_b32 v21, v[13:14], off                         // 0000002E0854: DC520000 157C000D
	s_branch 65288                                             // 0000002E085C: BFA0FF08 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi1EEEvPKhPKtPtll+0x180>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000002E0860: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002E0864: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002E0868: 8C7E037E
	.long 0xd71f0000                                           // 0000002E086C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002E0870: 020100C1
	s_waitcnt vmcnt(1)                                         // 0000002E0874: BF8907F7
	v_xor_b32_e32 v1, 16, v0                                   // 0000002E0878: 3A020090
	v_xor_b32_e32 v2, 8, v0                                    // 0000002E087C: 3A040088
	v_xor_b32_e32 v3, 4, v0                                    // 0000002E0880: 3A060084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E0884: BF870093
	.long 0xd44c0000                                           // 0000002E0888: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000002E088C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 0000002E0890: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E0898: BF870114
	.long 0xd44c0000                                           // 0000002E089C: D44C0000
	v_cndmask_b32_e32 v1, 32, v2, vcc_lo                       // 0000002E08A0: 020204A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002E08A4: 30020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002E08A8: BF8700D2
	v_cndmask_b32_e64 v2, v0, v2, s0                           // 0000002E08AC: D5010002 00020500
	.long 0xd44c0000                                           // 0000002E08B4: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000002E08B8: 020206A0
	ds_bpermute_b32 v1, v1, v16                                // 0000002E08BC: DACC0000 01001001
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000002E08C4: 30040482
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 0000002E08C8: D5010003 00020700
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000002E08D0: 30060682
	s_waitcnt lgkmcnt(0)                                       // 0000002E08D4: BF89FC07
	v_add_f32_e32 v1, v16, v1                                  // 0000002E08D8: 06020310
	ds_bpermute_b32 v2, v2, v1                                 // 0000002E08DC: DACC0000 02000102
	s_waitcnt lgkmcnt(0)                                       // 0000002E08E4: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000002E08E8: 06020501
	ds_bpermute_b32 v2, v3, v1                                 // 0000002E08EC: DACC0000 02000103
	v_xor_b32_e32 v3, 2, v0                                    // 0000002E08F4: 3A060082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E08F8: BF870091
	.long 0xd44c0000                                           // 0000002E08FC: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000002E0900: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 0000002E0904: D5010003 00020700
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002E090C: BF8700D1
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000002E0910: 30060682
	s_waitcnt lgkmcnt(0)                                       // 0000002E0914: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000002E0918: 06020501
	ds_bpermute_b32 v2, v3, v1                                 // 0000002E091C: DACC0000 02000103
	v_xor_b32_e32 v3, 1, v0                                    // 0000002E0924: 3A060081
	.long 0xd44c0000                                           // 0000002E0928: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000002E092C: 020206A0
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002E0930: BF870001
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 0000002E0934: D5010003 00020700
	.long 0xd44a0000                                           // 0000002E093C: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 0000002E0940: 02021E80
	s_and_b32 s0, s0, vcc_lo                                   // 0000002E0944: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 0000002E0948: BF89FC07
	v_dual_add_f32 v0, v1, v2 :: v_dual_lshlrev_b32 v1, 2, v3  // 0000002E094C: C9220501 00000682
	ds_bpermute_b32 v1, v1, v0                                 // 0000002E0954: DACC0000 01000001
	s_and_saveexec_b32 s1, s0                                  // 0000002E095C: BE812000
	s_cbranch_execz 17                                         // 0000002E0960: BFA50011 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi1EEEvPKhPKtPtll+0x6a8>
	s_waitcnt lgkmcnt(0)                                       // 0000002E0964: BF89FC07
	v_add_f32_e32 v2, v0, v1                                   // 0000002E0968: 06040300
	.long 0xd73c0000                                           // 0000002E096C: D73C0000
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002E0970: 02021281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E0974: BF870112
	v_bfe_u32 v3, v2, 16, 1                                    // 0000002E0978: D6100003 02052102
	.long 0xd7006a00                                           // 0000002E0980: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000002E0984: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E0988: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000002E098C: D5207C01 01AA0209
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000002E0994: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002E09A0: DC960000 007C0200
	s_endpgm                                                   // 0000002E09A8: BFB00000
		...

