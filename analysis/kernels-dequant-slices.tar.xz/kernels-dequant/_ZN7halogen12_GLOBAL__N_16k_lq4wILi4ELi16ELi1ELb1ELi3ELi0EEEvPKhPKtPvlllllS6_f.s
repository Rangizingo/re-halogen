0000000000845200 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000845200: F4100100 F8000000
	v_and_b32_e32 v16, 15, v0                                  // 000000845208: 3620008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000084520C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000845210: 86039F02
	.long 0x7f103880                                           // 000000845214: 7F103880
	s_lshl_b64 s[2:3], s[2:3], 4                               // 000000845218: 84828402
	v_mov_b32_e32 v17, 0                                       // 00000084521C: 7E220280
	v_dual_mov_b32 v10, s3 :: v_dual_lshlrev_b32 v3, 2, v1     // 000000845220: CA220003 0A020282
	v_or_b32_e32 v9, s2, v1                                    // 000000845228: 38120202
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v2, 2, v16      // 00000084522C: CA220080 01022082
	s_waitcnt lgkmcnt(0)                                       // 000000845234: BF89FC07
	s_clause 0x1                                               // 000000845238: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 00000084523C: DC520000 04040002
	global_load_b32 v7, v3, s[4:5]                             // 000000845244: DC520000 07040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 00000084524C: 7CA8120C
	s_add_u32 s14, s4, s14                                     // 000000845250: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 000000845254: 820F0F05
	s_lshr_b32 s2, s11, 31                                     // 000000845258: 85029F0B
	v_mov_b32_e32 v18, 0                                       // 00000084525C: 7E240280
	s_add_u32 s20, s10, s2                                     // 000000845260: 8014020A
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 000000845264: 02161280
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 000000845268: D501000E 01A80680
	s_addc_u32 s21, s11, 0                                     // 000000845270: 8215800B
	s_ashr_i32 s22, s11, 31                                    // 000000845274: 86169F0B
	s_ashr_i64 s[2:3], s[20:21], 1                             // 000000845278: 86828114
	.long 0xd72c000d                                           // 00000084527C: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 000000845280: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 000000845284: D6FE7C05 02021612
	.long 0xd72c000f                                           // 00000084528C: D72C000F
	v_cndmask_b32_e32 v0, v11, v3, vcc_lo                      // 000000845290: 0200070B
	.long 0xd72c0014                                           // 000000845294: D72C0014
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 000000845298: 0200050E
	.long 0xd72c000e                                           // 00000084529C: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000008452A0: 02021C12
	s_lshr_b32 s19, s22, 27                                    // 0000008452A4: 85139B16
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 0000008452A8: CA100080 02020080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008452B0: BF870152
	v_add3_u32 v6, v6, v14, v13                                // 0000008452B4: D6550006 04361D06
	s_waitcnt vmcnt(1)                                         // 0000008452BC: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 0000008452C0: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 0000008452C8: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 0000008452CC: D6100013 02052107
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000008452D4: D6550004 03FE1904 00007FFF
	v_mad_u64_u32 v[11:12], null, v11, s2, s[14:15]            // 0000008452E0: D6FE7C0B 0038050B
	s_add_u32 s14, s10, s19                                    // 0000008452E8: 800E130A
	v_add3_u32 v7, v7, v19, 0x7fff                             // 0000008452EC: D6550007 03FE2707 00007FFF
	s_addc_u32 s15, s11, 0                                     // 0000008452F8: 820F800B
	.long 0x7e103984                                           // 0000008452FC: 7E103984
	s_lshr_b64 s[14:15], s[14:15], 5                           // 000000845300: 858E850E
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v19, 2, v0      // 000000845304: CA220080 04120082
	.long 0xd4440002                                           // 00000084530C: D4440002
	v_cndmask_b32_e32 v1, s14, v16, vcc_lo                     // 000000845310: 0202200E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000845314: BF870003
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 000000845318: D6570007 04220EFF FFFF0000
	v_add3_u32 v0, v20, v12, v15                               // 000000845324: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 00000084532C: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 000000845334: BF89FC07
	s_barrier                                                  // 000000845338: BFBD0000
	buffer_gl0_inv                                             // 00000084533C: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 000000845344: BE8F2002
	s_cbranch_execz 26                                         // 000000845348: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x1b4>
	s_add_u32 s3, s4, s16                                      // 00000084534C: 80031004
	s_addc_u32 s18, s5, s17                                    // 000000845350: 82121105
	v_lshlrev_b32_e32 v1, 1, v16                               // 000000845354: 30022081
	.long 0xd7000302                                           // 000000845358: D7000302
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 00000084535C: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000845360: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s18, v6, s3                  // 000000845364: D5207C03 000E0C12
	v_lshlrev_b32_e32 v4, 4, v16                               // 00000084536C: 30082084
	.long 0xd7000301                                           // 000000845370: D7000301
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000845374: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000845378: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s3                    // 00000084537C: D5207C02 000E0680
	.long 0xd7000303                                           // 000000845384: D7000303
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 000000845388: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084538C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s3                    // 000000845390: D5207C04 000E0080
	s_clause 0x1                                               // 000000845398: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 00000084539C: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000008453A4: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000008453AC: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 0000008453B0: 7E241707
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008453B4: 8C7E0F7E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000008453B8: CA100080 13140080
	v_mov_b32_e32 v21, 0                                       // 0000008453C0: 7E2A0280
	s_and_saveexec_b32 s15, s2                                 // 0000008453C4: BE8F2002
	s_cbranch_execz 382                                        // 0000008453C8: BFA5017E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x7c4>
	s_mul_i32 s2, s11, 6                                       // 0000008453CC: 9602860B
	s_mul_hi_u32 s3, s10, 6                                    // 0000008453D0: 9683860A
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 0000008453D4: CA220080 0D0C2085
	s_add_i32 s20, s3, s2                                      // 0000008453DC: 81140203
	v_lshlrev_b32_e32 v7, 1, v16                               // 0000008453E0: 300E2081
	.long 0xd7000205                                           // 0000008453E4: D7000205
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 0000008453E8: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008453EC: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s2                  // 0000008453F0: D5207C06 000A0C11
	v_mov_b32_e32 v20, v13                                     // 0000008453F8: 7E28030D
	.long 0xd7000205                                           // 0000008453FC: D7000205
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000845400: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000845404: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s2                    // 000000845408: D5207C06 000A0C80
	v_lshl_or_b32 v22, v16, 4, 0x100                           // 000000845410: D6560016 03FD0910 00000100
	.long 0xd7000205                                           // 00000084541C: D7000205
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000845420: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000845424: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s2                   // 000000845428: D5207C06 000A0C05
	v_dual_mov_b32 v23, v16 :: v_dual_mov_b32 v24, v18         // 000000845430: CA100110 17180112
	.long 0xd700020e                                           // 000000845438: D700020E
	v_cndmask_b32_e32 v0, v5, v160, vcc_lo                     // 00000084543C: 02014105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000845440: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s2                   // 000000845444: D5207C0F 000A0C80
	v_mov_b32_e32 v21, v13                                     // 00000084544C: 7E2A030D
	v_mov_b32_e32 v19, v13                                     // 000000845450: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 000000845454: 7E22030D
	s_lshl_b64 s[18:19], s[10:11], 2                           // 000000845458: 8492820A
	s_mul_i32 s17, s10, 6                                      // 00000084545C: 9611860A
	s_mov_b32 s16, 0                                           // 000000845460: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000845464: 8484810A
	s_branch 316                                               // 000000845468: BFA0013C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x75c>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000084546C: 8C7E0A7E
	.long 0xd73c0019                                           // 000000845470: D73C0019
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000845474: 02021881
	v_and_b32_e32 v57, 0xff, v1                                // 000000845478: 367202FF 000000FF
	v_lshrrev_b32_e32 v58, 6, v1                               // 000000845480: 32740286
	v_lshrrev_b32_e32 v59, 14, v1                              // 000000845484: 3276028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 000000845488: 32020296
	v_and_b32_e32 v60, 0xff, v2                                // 00000084548C: 367804FF 000000FF
	.long 0xd7000349                                           // 000000845494: D7000349
	v_cndmask_b32_e32 v1, s6, v25, vcc_lo                      // 000000845498: 02023206
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084549C: BF8701A1
	v_add_co_ci_u32_e64 v74, null, s7, v26, s3                 // 0000008454A0: D5207C4A 000E3407
	v_lshlrev_b32_e32 v57, 2, v57                              // 0000008454A8: 30727282
	.long 0xd700034d                                           // 0000008454AC: D700034D
	v_cndmask_b32_e32 v0, v73, v4, vcc_lo                      // 0000008454B0: 02000949
	global_load_b128 v[25:28], v[73:74], off                   // 0000008454B4: DC5E0000 197C0049
	v_add_co_ci_u32_e64 v78, null, s5, v74, s3                 // 0000008454BC: D5207C4E 000E9405
	.long 0xd700034f                                           // 0000008454C4: D700034F
	v_cndmask_b32_e32 v0, v73, v18, vcc_lo                     // 0000008454C8: 02002549
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008454CC: BF8700A1
	v_add_co_ci_u32_e64 v80, null, s19, v74, s3                // 0000008454D0: D5207C50 000E9413
	.long 0xd7000351                                           // 0000008454D8: D7000351
	v_cndmask_b32_e32 v0, v73, v17, vcc_lo                     // 0000008454DC: 02002349
	v_add_co_ci_u32_e64 v82, null, s20, v74, s3                // 0000008454E0: D5207C52 000E9414
	s_clause 0x6                                               // 0000008454E8: BF850006
	global_load_b128 v[29:32], v[77:78], off                   // 0000008454EC: DC5E0000 1D7C004D
	global_load_b128 v[33:36], v[79:80], off                   // 0000008454F4: DC5E0000 217C004F
	global_load_b128 v[37:40], v[81:82], off                   // 0000008454FC: DC5E0000 257C0051
	global_load_b128 v[41:44], v[73:74], off offset:16         // 000000845504: DC5E0010 297C0049
	global_load_b128 v[45:48], v[77:78], off offset:16         // 00000084550C: DC5E0010 2D7C004D
	global_load_b128 v[49:52], v[79:80], off offset:16         // 000000845514: DC5E0010 317C004F
	global_load_b128 v[53:56], v[81:82], off offset:16         // 00000084551C: DC5E0010 357C0051
	v_and_b32_e32 v58, 0x3fc, v58                              // 000000845524: 367474FF 000003FC
	ds_load_b32 v75, v57                                       // 00000084552C: D8D80000 4B000039
	v_lshrrev_b32_e32 v61, 6, v2                               // 000000845534: 327A0486
	v_lshrrev_b32_e32 v62, 14, v2                              // 000000845538: 327C048E
	v_lshrrev_b32_e32 v2, 22, v2                               // 00000084553C: 32040496
	ds_load_b32 v83, v58                                       // 000000845540: D8D80000 5300003A
	v_and_b32_e32 v57, 0x3fc, v59                              // 000000845548: 367276FF 000003FC
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000845550: 360202FF 000003FC
	v_lshlrev_b32_e32 v76, 2, v60                              // 000000845558: 30987882
	v_and_b32_e32 v84, 0x3fc, v61                              // 00000084555C: 36A87AFF 000003FC
	v_and_b32_e32 v88, 0x3fc, v62                              // 000000845564: 36B07CFF 000003FC
	ds_load_b32 v89, v57                                       // 00000084556C: D8D80000 59000039
	s_clause 0x3                                               // 000000845574: BF850003
	global_load_b128 v[57:60], v[73:74], off offset:32         // 000000845578: DC5E0020 397C0049
	global_load_b128 v[61:64], v[77:78], off offset:32         // 000000845580: DC5E0020 3D7C004D
	global_load_b128 v[65:68], v[79:80], off offset:32         // 000000845588: DC5E0020 417C004F
	global_load_b128 v[69:72], v[81:82], off offset:32         // 000000845590: DC5E0020 457C0051
	v_and_b32_e32 v2, 0x3fc, v2                                // 000000845598: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000008455A0: D8D80000 01000001
	ds_load_b32 v90, v76                                       // 0000008455A8: D8D80000 5A00004C
	ds_load_b32 v91, v84                                       // 0000008455B0: D8D80000 5B000054
	ds_load_b32 v88, v88                                       // 0000008455B8: D8D80000 58000058
	ds_load_b32 v2, v2                                         // 0000008455C0: D8D80000 02000002
	v_and_b32_e32 v85, 0xff, v3                                // 0000008455C8: 36AA06FF 000000FF
	v_lshrrev_b32_e32 v86, 6, v3                               // 0000008455D0: 32AC0686
	v_lshrrev_b32_e32 v87, 14, v3                              // 0000008455D4: 32AE068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000008455D8: 32060696
	v_and_b32_e32 v92, 0xff, v4                                // 0000008455DC: 36B808FF 000000FF
	v_lshrrev_b32_e32 v93, 6, v4                               // 0000008455E4: 32BA0886
	v_lshrrev_b32_e32 v94, 14, v4                              // 0000008455E8: 32BC088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000008455EC: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000008455F0: 360606FF 000003FC
	s_and_b32 s3, exec_lo, s2                                  // 0000008455F8: 8B03027E
	.long 0xd700020e                                           // 0000008455FC: D700020E
	v_cndmask_b32_e32 v0, v14, v160, vcc_lo                    // 000000845600: 0201410E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000845604: BF870003
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000845608: 360808FF 000003FC
	v_add_nc_u32_e32 v12, 0x200, v12                           // 000000845610: 4A1818FF 00000200
	v_add_nc_u32_e32 v22, 0x100, v22                           // 000000845618: 4A2C2CFF 00000100
	v_add_co_ci_u32_e64 v15, null, 0, v15, s2                  // 000000845620: D5207C0F 000A1E80
	s_or_b32 s16, s3, s16                                      // 000000845628: 8C101003
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 00000084562C: BF892C77
	v_dot2_f32_bf16 v25, v25, v75, 0                           // 000000845630: CC1A4019 1A029719
	s_waitcnt lgkmcnt(6)                                       // 000000845638: BF89FC67
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084563C: BF870001
	v_dot2_f32_bf16 v25, v26, v83, v25                         // 000000845640: CC1A4019 1C66A71A
	s_waitcnt vmcnt(10)                                        // 000000845648: BF892BF7
	v_dot2_f32_bf16 v26, v29, v75, 0                           // 00000084564C: CC1A401A 1A02971D
	s_waitcnt vmcnt(9)                                         // 000000845654: BF8927F7
	v_dot2_f32_bf16 v29, v33, v75, 0                           // 000000845658: CC1A401D 1A029721
	s_waitcnt vmcnt(8)                                         // 000000845660: BF8923F7
	v_dot2_f32_bf16 v33, v37, v75, 0                           // 000000845664: CC1A4021 1A029725
	s_waitcnt lgkmcnt(5)                                       // 00000084566C: BF89FC57
	v_dot2_f32_bf16 v25, v27, v89, v25                         // 000000845670: CC1A4019 1C66B31B
	global_load_b128 v[73:76], v[73:74], off offset:48         // 000000845678: DC5E0030 497C0049
	v_dot2_f32_bf16 v30, v30, v83, v26                         // 000000845680: CC1A401E 1C6AA71E
	v_dot2_f32_bf16 v29, v34, v83, v29                         // 000000845688: CC1A401D 1C76A722
	v_dot2_f32_bf16 v33, v38, v83, v33                         // 000000845690: CC1A4021 1C86A726
	s_waitcnt lgkmcnt(4)                                       // 000000845698: BF89FC47
	v_dot2_f32_bf16 v34, v28, v1, v25                          // 00000084569C: CC1A4022 1C66031C
	s_clause 0x2                                               // 0000008456A4: BF850002
	global_load_b128 v[25:28], v[77:78], off offset:48         // 0000008456A8: DC5E0030 197C004D
	global_load_b128 v[77:80], v[79:80], off offset:48         // 0000008456B0: DC5E0030 4D7C004F
	global_load_b128 v[81:84], v[81:82], off offset:48         // 0000008456B8: DC5E0030 517C0051
	v_dot2_f32_bf16 v30, v31, v89, v30                         // 0000008456C0: CC1A401E 1C7AB31F
	v_dot2_f32_bf16 v29, v35, v89, v29                         // 0000008456C8: CC1A401D 1C76B323
	v_dot2_f32_bf16 v31, v39, v89, v33                         // 0000008456D0: CC1A401F 1C86B327
	v_lshlrev_b32_e32 v33, 2, v85                              // 0000008456D8: 3042AA82
	v_and_b32_e32 v35, 0x3fc, v86                              // 0000008456DC: 3646ACFF 000003FC
	v_dot2_f32_bf16 v30, v32, v1, v30                          // 0000008456E4: CC1A401E 1C7A0320
	v_dot2_f32_bf16 v29, v36, v1, v29                          // 0000008456EC: CC1A401D 1C760324
	v_dot2_f32_bf16 v1, v40, v1, v31                           // 0000008456F4: CC1A4001 1C7E0328
	v_and_b32_e32 v37, 0x3fc, v87                              // 0000008456FC: 364AAEFF 000003FC
	s_waitcnt vmcnt(11) lgkmcnt(3)                             // 000000845704: BF892C37
	v_dot2_f32_bf16 v31, v41, v90, v34                         // 000000845708: CC1A401F 1C8AB529
	s_waitcnt vmcnt(10)                                        // 000000845710: BF892BF7
	v_dot2_f32_bf16 v30, v45, v90, v30                         // 000000845714: CC1A401E 1C7AB52D
	s_waitcnt vmcnt(9)                                         // 00000084571C: BF8927F7
	v_dot2_f32_bf16 v29, v49, v90, v29                         // 000000845720: CC1A401D 1C76B531
	s_waitcnt vmcnt(8)                                         // 000000845728: BF8923F7
	v_dot2_f32_bf16 v1, v53, v90, v1                           // 00000084572C: CC1A4001 1C06B535
	ds_load_b32 v32, v33                                       // 000000845734: D8D80000 20000021
	ds_load_b32 v34, v37                                       // 00000084573C: D8D80000 22000025
	s_waitcnt lgkmcnt(4)                                       // 000000845744: BF89FC47
	v_dot2_f32_bf16 v31, v42, v91, v31                         // 000000845748: CC1A401F 1C7EB72A
	v_dot2_f32_bf16 v30, v46, v91, v30                         // 000000845750: CC1A401E 1C7AB72E
	v_dot2_f32_bf16 v29, v50, v91, v29                         // 000000845758: CC1A401D 1C76B732
	v_dot2_f32_bf16 v1, v54, v91, v1                           // 000000845760: CC1A4001 1C06B736
	ds_load_b32 v33, v35                                       // 000000845768: D8D80000 21000023
	s_waitcnt lgkmcnt(4)                                       // 000000845770: BF89FC47
	v_dot2_f32_bf16 v31, v43, v88, v31                         // 000000845774: CC1A401F 1C7EB12B
	v_dot2_f32_bf16 v30, v47, v88, v30                         // 00000084577C: CC1A401E 1C7AB12F
	v_dot2_f32_bf16 v29, v51, v88, v29                         // 000000845784: CC1A401D 1C76B133
	v_dot2_f32_bf16 v1, v55, v88, v1                           // 00000084578C: CC1A4001 1C06B137
	v_lshlrev_b32_e32 v38, 2, v92                              // 000000845794: 304CB882
	s_waitcnt lgkmcnt(3)                                       // 000000845798: BF89FC37
	v_dot2_f32_bf16 v31, v44, v2, v31                          // 00000084579C: CC1A401F 1C7E052C
	v_dot2_f32_bf16 v30, v48, v2, v30                          // 0000008457A4: CC1A401E 1C7A0530
	v_dot2_f32_bf16 v29, v52, v2, v29                          // 0000008457AC: CC1A401D 1C760534
	v_dot2_f32_bf16 v1, v56, v2, v1                            // 0000008457B4: CC1A4001 1C060538
	v_and_b32_e32 v39, 0x3fc, v93                              // 0000008457BC: 364EBAFF 000003FC
	v_and_b32_e32 v85, 0x3fc, v94                              // 0000008457C4: 36AABCFF 000003FC
	ds_load_b32 v2, v3                                         // 0000008457CC: D8D80000 02000003
	ds_load_b32 v3, v38                                        // 0000008457D4: D8D80000 03000026
	ds_load_b32 v35, v39                                       // 0000008457DC: D8D80000 23000027
	ds_load_b32 v36, v85                                       // 0000008457E4: D8D80000 24000055
	ds_load_b32 v37, v4                                        // 0000008457EC: D8D80000 25000004
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000008457F4: BF891C77
	v_dot2_f32_bf16 v4, v57, v32, v31                          // 0000008457F8: CC1A4004 1C7E4139
	s_waitcnt vmcnt(6)                                         // 000000845800: BF891BF7
	v_dot2_f32_bf16 v30, v61, v32, v30                         // 000000845804: CC1A401E 1C7A413D
	s_waitcnt vmcnt(5)                                         // 00000084580C: BF8917F7
	v_dot2_f32_bf16 v29, v65, v32, v29                         // 000000845810: CC1A401D 1C764141
	s_waitcnt vmcnt(4)                                         // 000000845818: BF8913F7
	v_dot2_f32_bf16 v1, v69, v32, v1                           // 00000084581C: CC1A4001 1C064145
	s_waitcnt lgkmcnt(5)                                       // 000000845824: BF89FC57
	v_dot2_f32_bf16 v4, v58, v33, v4                           // 000000845828: CC1A4004 1C12433A
	v_dot2_f32_bf16 v30, v62, v33, v30                         // 000000845830: CC1A401E 1C7A433E
	v_dot2_f32_bf16 v29, v66, v33, v29                         // 000000845838: CC1A401D 1C764342
	v_dot2_f32_bf16 v1, v70, v33, v1                           // 000000845840: CC1A4001 1C064346
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000845848: BF870214
	v_dot2_f32_bf16 v4, v59, v34, v4                           // 00000084584C: CC1A4004 1C12453B
	v_dot2_f32_bf16 v30, v63, v34, v30                         // 000000845854: CC1A401E 1C7A453F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000084585C: BF870214
	v_dot2_f32_bf16 v29, v67, v34, v29                         // 000000845860: CC1A401D 1C764543
	v_dot2_f32_bf16 v1, v71, v34, v1                           // 000000845868: CC1A4001 1C064547
	s_waitcnt lgkmcnt(4)                                       // 000000845870: BF89FC47
	v_dot2_f32_bf16 v4, v60, v2, v4                            // 000000845874: CC1A4004 1C12053C
	v_dot2_f32_bf16 v30, v64, v2, v30                          // 00000084587C: CC1A401E 1C7A0540
	v_dot2_f32_bf16 v29, v68, v2, v29                          // 000000845884: CC1A401D 1C760544
	v_dot2_f32_bf16 v1, v72, v2, v1                            // 00000084588C: CC1A4001 1C060548
	s_waitcnt vmcnt(3) lgkmcnt(3)                              // 000000845894: BF890C37
	v_dot2_f32_bf16 v2, v73, v3, v4                            // 000000845898: CC1A4002 1C120749
	v_mov_b32_e32 v4, v8                                       // 0000008458A0: 7E080308
	s_waitcnt vmcnt(2)                                         // 0000008458A4: BF890BF7
	v_dot2_f32_bf16 v25, v25, v3, v30                          // 0000008458A8: CC1A4019 1C7A0719
	s_waitcnt vmcnt(1)                                         // 0000008458B0: BF8907F7
	v_dot2_f32_bf16 v29, v77, v3, v29                          // 0000008458B4: CC1A401D 1C76074D
	s_waitcnt vmcnt(0)                                         // 0000008458BC: BF8903F7
	v_dot2_f32_bf16 v1, v81, v3, v1                            // 0000008458C0: CC1A4001 1C060751
	s_waitcnt lgkmcnt(2)                                       // 0000008458C8: BF89FC27
	v_dot2_f32_bf16 v2, v74, v35, v2                           // 0000008458CC: CC1A4002 1C0A474A
	v_mov_b32_e32 v3, v7                                       // 0000008458D4: 7E060307
	v_dot2_f32_bf16 v8, v26, v35, v25                          // 0000008458D8: CC1A4008 1C66471A
	v_dot2_f32_bf16 v25, v78, v35, v29                         // 0000008458E0: CC1A4019 1C76474E
	v_dot2_f32_bf16 v1, v82, v35, v1                           // 0000008458E8: CC1A4001 1C064752
	s_waitcnt lgkmcnt(1)                                       // 0000008458F0: BF89FC17
	v_dot2_f32_bf16 v7, v75, v36, v2                           // 0000008458F4: CC1A4007 1C0A494B
	v_mov_b32_e32 v2, v6                                       // 0000008458FC: 7E040306
	v_dot2_f32_bf16 v8, v27, v36, v8                           // 000000845900: CC1A4008 1C22491B
	v_dot2_f32_bf16 v25, v79, v36, v25                         // 000000845908: CC1A4019 1C66494F
	v_dot2_f32_bf16 v1, v83, v36, v1                           // 000000845910: CC1A4001 1C064953
	s_waitcnt lgkmcnt(0)                                       // 000000845918: BF89FC07
	v_dot2_f32_bf16 v6, v76, v37, v7                           // 00000084591C: CC1A4006 1C1E4B4C
	v_dot2_f32_bf16 v7, v28, v37, v8                           // 000000845924: CC1A4007 1C224B1C
	v_dot2_f32_bf16 v8, v80, v37, v25                          // 00000084592C: CC1A4008 1C664B50
	v_dot2_f32_bf16 v25, v84, v37, v1                          // 000000845934: CC1A4019 1C064B54
	v_mov_b32_e32 v1, v5                                       // 00000084593C: 7E020305
	v_fmac_f32_e32 v21, v18, v6                                // 000000845940: 562A0D12
	v_fmac_f32_e32 v20, v18, v7                                // 000000845944: 56280F12
	v_fmac_f32_e32 v19, v18, v8                                // 000000845948: 56261112
	v_dual_fmac_f32 v17, v18, v25 :: v_dual_mov_b32 v18, v24   // 00000084594C: C8103312 11120118
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000845954: 917E107E
	s_cbranch_execz 25                                         // 000000845958: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x7c0>
	s_waitcnt vmcnt(0)                                         // 00000084595C: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v23, 16, v23    // 000000845960: CA200102 06162E90
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 000000845968: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 000000845970: 7E0E0303
	s_delay_alu instid0(VALU_DEP_3)                            // 000000845974: BF870003
	.long 0xd4430002                                           // 000000845978: D4430002
	v_cndmask_b32_e32 v1, s14, v23, vcc_lo                     // 00000084597C: 02022E0E
	s_mov_b32 s10, exec_lo                                     // 000000845980: BE8A007E
	.long 0xd4c4007e                                           // 000000845984: D4C4007E
	v_cndmask_b32_e32 v1, s14, v23, vcc_lo                     // 000000845988: 02022E0E
	s_cbranch_execz 65207                                      // 00000084598C: BFA5FEB7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x26c>
	.long 0xd7000305                                           // 000000845990: D7000305
	v_cndmask_b32_e32 v1, v11, v22, vcc_lo                     // 000000845994: 02022D0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000845998: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s3                    // 00000084599C: D5207C06 000E0080
	global_load_d16_b16 v24, v[14:15], off                     // 0000008459A4: DC820000 187C000E
	global_load_b128 v[5:8], v[5:6], off                       // 0000008459AC: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 0000008459B4: BF8907F7
	v_cvt_f32_f16_e32 v24, v24                                 // 0000008459B8: 7E301718
	s_branch 65195                                             // 0000008459BC: BFA0FEAB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x26c>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000008459C0: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008459C4: BF8700B9
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008459C8: 8C7E0F7E
	.long 0xd71f0000                                           // 0000008459CC: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008459D0: 020100C1
	s_waitcnt vmcnt(0)                                         // 0000008459D4: BF8903F7
	v_xor_b32_e32 v1, 8, v0                                    // 0000008459D8: 3A020088
	v_xor_b32_e32 v5, 4, v0                                    // 0000008459DC: 3A0A0084
	v_xor_b32_e32 v11, 2, v0                                   // 0000008459E0: 3A160082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008459E4: BF870093
	.long 0xd44c0002                                           // 0000008459E8: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000008459EC: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 0000008459F0: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008459F8: BF870114
	.long 0xd44c0002                                           // 0000008459FC: D44C0002
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 000000845A00: 02020AA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000845A04: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000845A08: BF870002
	v_cndmask_b32_e64 v5, v0, v5, s2                           // 000000845A0C: D5010005 000A0B00
	.long 0xd44c0002                                           // 000000845A14: D44C0002
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 000000845A18: 020216A0
	ds_bpermute_b32 v2, v1, v21                                // 000000845A1C: DACC0000 02001501
	v_cndmask_b32_e64 v11, v0, v11, s2                         // 000000845A24: D501000B 000A1700
	s_waitcnt lgkmcnt(0)                                       // 000000845A2C: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 000000845A30: 06040515
	ds_bpermute_b32 v4, v1, v19                                // 000000845A34: DACC0000 04001301
	ds_bpermute_b32 v3, v1, v20                                // 000000845A3C: DACC0000 03001401
	ds_bpermute_b32 v1, v1, v17                                // 000000845A44: DACC0000 01001101
	s_waitcnt lgkmcnt(2)                                       // 000000845A4C: BF89FC27
	v_dual_add_f32 v4, v19, v4 :: v_dual_lshlrev_b32 v5, 2, v5 // 000000845A50: C9220913 04040A82
	ds_bpermute_b32 v6, v5, v2                                 // 000000845A58: DACC0000 06000205
	s_waitcnt lgkmcnt(2)                                       // 000000845A60: BF89FC27
	v_add_f32_e32 v3, v20, v3                                  // 000000845A64: 06060714
	ds_bpermute_b32 v8, v5, v4                                 // 000000845A68: DACC0000 08000405
	s_waitcnt lgkmcnt(1)                                       // 000000845A70: BF89FC17
	v_dual_add_f32 v1, v17, v1 :: v_dual_add_f32 v2, v2, v6    // 000000845A74: C9080311 01020D02
	ds_bpermute_b32 v7, v5, v3                                 // 000000845A7C: DACC0000 07000305
	s_waitcnt lgkmcnt(1)                                       // 000000845A84: BF89FC17
	v_dual_add_f32 v4, v4, v8 :: v_dual_lshlrev_b32 v11, 2, v11// 000000845A88: C9221104 040A1682
	ds_bpermute_b32 v5, v5, v1                                 // 000000845A90: DACC0000 05000105
	s_waitcnt lgkmcnt(1)                                       // 000000845A98: BF89FC17
	v_add_f32_e32 v3, v3, v7                                   // 000000845A9C: 06060F03
	ds_bpermute_b32 v7, v11, v4                                // 000000845AA0: DACC0000 0700040B
	s_waitcnt lgkmcnt(1)                                       // 000000845AA8: BF89FC17
	v_add_f32_e32 v5, v1, v5                                   // 000000845AAC: 060A0B01
	ds_bpermute_b32 v1, v11, v2                                // 000000845AB0: DACC0000 0100020B
	ds_bpermute_b32 v6, v11, v3                                // 000000845AB8: DACC0000 0600030B
	ds_bpermute_b32 v8, v11, v5                                // 000000845AC0: DACC0000 0800050B
	v_xor_b32_e32 v11, 1, v0                                   // 000000845AC8: 3A160081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000845ACC: BF870091
	.long 0xd44c0002                                           // 000000845AD0: D44C0002
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 000000845AD4: 020216A0
	v_cndmask_b32_e64 v0, v0, v11, s2                          // 000000845AD8: D5010000 000A1700
	.long 0xd44a0002                                           // 000000845AE0: D44A0002
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 000000845AE4: 02022080
	s_waitcnt lgkmcnt(2)                                       // 000000845AE8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2)                            // 000000845AEC: BF870002
	v_dual_add_f32 v0, v2, v1 :: v_dual_lshlrev_b32 v11, 2, v0 // 000000845AF0: C9220302 000A0082
	s_waitcnt lgkmcnt(1)                                       // 000000845AF8: BF89FC17
	v_dual_add_f32 v1, v3, v6 :: v_dual_add_f32 v2, v4, v7     // 000000845AFC: C9080D03 01020F04
	s_waitcnt lgkmcnt(0)                                       // 000000845B04: BF89FC07
	v_add_f32_e32 v3, v5, v8                                   // 000000845B08: 06061105
	s_and_b32 s2, s2, vcc_lo                                   // 000000845B0C: 8B026A02
	ds_bpermute_b32 v4, v11, v0                                // 000000845B10: DACC0000 0400000B
	ds_bpermute_b32 v5, v11, v1                                // 000000845B18: DACC0000 0500010B
	ds_bpermute_b32 v6, v11, v2                                // 000000845B20: DACC0000 0600020B
	ds_bpermute_b32 v7, v11, v3                                // 000000845B28: DACC0000 0700030B
	s_and_saveexec_b32 s3, s2                                  // 000000845B30: BE832002
	s_cbranch_execz 182                                        // 000000845B34: BFA500B6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xc10>
	s_load_b32 s0, s[0:1], 0x48                                // 000000845B38: F4000000 F8000048
	s_waitcnt lgkmcnt(0)                                       // 000000845B40: BF89FC07
	v_dual_add_f32 v0, v0, v4 :: v_dual_add_f32 v1, v1, v5     // 000000845B44: C9080900 00000B01
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v3, v7     // 000000845B4C: C9080D02 02020F03
	s_lshl_b64 s[4:5], s[12:13], 2                             // 000000845B54: 8484820C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000845B58: BF870192
	v_bfe_u32 v4, v0, 16, 1                                    // 000000845B5C: D6100004 02052100
	v_bfe_u32 v5, v1, 16, 1                                    // 000000845B64: D6100005 02052101
	s_delay_alu instid0(VALU_DEP_3)                            // 000000845B6C: BF870003
	v_bfe_u32 v6, v2, 16, 1                                    // 000000845B70: D6100006 02052102
	v_bfe_u32 v7, v3, 16, 1                                    // 000000845B78: D6100007 02052103
	s_lshl_b64 s[6:7], s[12:13], 3                             // 000000845B80: 8486830C
	v_add3_u32 v0, v0, v4, 0x7fff                              // 000000845B84: D6550000 03FE0900 00007FFF
	v_add3_u32 v1, v1, v5, 0x7fff                              // 000000845B90: D6550001 03FE0B01 00007FFF
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000845B9C: D6550002 03FE0D02 00007FFF
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000845BA8: D6550003 03FE0F03 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000845BB4: BF8701A3
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000845BB8: 360202FF FFFF0000
	v_and_b32_e32 v0, 0xffff0000, v0                           // 000000845BC0: 360000FF FFFF0000
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000845BC8: 360606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000845BD0: BF870113
	v_dual_mul_f32 v1, s0, v1 :: v_dual_and_b32 v2, 0xffff0000, v2// 000000845BD4: C8E40200 010204FF FFFF0000
	v_dual_mul_f32 v0, s0, v0 :: v_dual_mul_f32 v3, s0, v3     // 000000845BE0: C8C60000 00020600
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000845BE8: BF870112
	v_dual_mul_f32 v2, s0, v2 :: v_dual_mul_f32 v1, 0xbfb8aa3b, v1// 000000845BEC: C8C60400 020002FF BFB8AA3B
	v_dual_mul_f32 v0, 0xbfb8aa3b, v0 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v3// 000000845BF8: C8C600FF 000206FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000845C04: BF870192
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 000000845C08: 100404FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 000000845C10: 7E024B01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000845C14: BF870112
	v_exp_f32_e32 v0, v0                                       // 000000845C18: 7E004B00
	v_exp_f32_e32 v3, v3                                       // 000000845C1C: 7E064B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 000000845C20: BF870391
	v_exp_f32_e32 v2, v2                                       // 000000845C24: 7E044B02
	v_dual_add_f32 v8, 1.0, v1 :: v_dual_add_f32 v7, 1.0, v0   // 000000845C28: C90802F2 080600F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000845C30: BF8701A5
	v_dual_add_f32 v11, 1.0, v3 :: v_dual_add_f32 v2, 1.0, v2  // 000000845C34: C90806F2 0B0204F2
	.long 0xd73c0000                                           // 000000845C3C: D73C0000
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000845C40: 02021282
	v_div_scale_f32 v13, null, v8, v8, 1.0                     // 000000845C44: D6FC7C0D 03CA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000845C4C: BF870214
	v_div_scale_f32 v12, null, v7, v7, 1.0                     // 000000845C50: D6FC7C0C 03CA0F07
	v_div_scale_f32 v15, null, v11, v11, 1.0                   // 000000845C58: D6FC7C0F 03CA170B
	v_div_scale_f32 v14, null, v2, v2, 1.0                     // 000000845C60: D6FC7C0E 03CA0502
	v_div_scale_f32 v9, vcc_lo, 1.0, v7, 1.0                   // 000000845C68: D6FC6A09 03CA0EF2
	v_rcp_f32_e32 v17, v13                                     // 000000845C70: 7E22550D
	v_rcp_f32_e32 v16, v12                                     // 000000845C74: 7E20550C
	v_rcp_f32_e32 v19, v15                                     // 000000845C78: 7E26550F
	v_rcp_f32_e32 v18, v14                                     // 000000845C7C: 7E24550E
	v_div_scale_f32 v10, s0, 1.0, v8, 1.0                      // 000000845C80: D6FC000A 03CA10F2
	v_div_scale_f32 v20, s1, 1.0, v2, 1.0                      // 000000845C88: D6FC0114 03CA04F2
	v_div_scale_f32 v21, s2, 1.0, v11, 1.0                     // 000000845C90: D6FC0215 03CA16F2
	v_fma_f32 v4, -v13, v17, 1.0                               // 000000845C98: D6130004 23CA230D
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000845CA0: BF870317
	v_fma_f32 v3, -v12, v16, 1.0                               // 000000845CA4: D6130003 23CA210C
	v_fma_f32 v6, -v15, v19, 1.0                               // 000000845CAC: D6130006 23CA270F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000845CB4: BF870195
	v_fma_f32 v5, -v14, v18, 1.0                               // 000000845CB8: D6130005 23CA250E
	v_dual_fmac_f32 v17, v4, v17 :: v_dual_fmac_f32 v16, v3, v16// 000000845CC0: C8002304 11102103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000845CC8: BF8701A2
	v_dual_fmac_f32 v19, v6, v19 :: v_dual_fmac_f32 v18, v5, v18// 000000845CCC: C8002706 13122505
	.long 0xd7000303                                           // 000000845CD4: D7000303
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000845CD8: 02020008
	v_dual_mul_f32 v22, v9, v16 :: v_dual_mul_f32 v23, v10, v17// 000000845CDC: C8C62109 1616230A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000845CE4: BF8701A3
	v_dual_mul_f32 v24, v20, v18 :: v_dual_mul_f32 v25, v21, v19// 000000845CE8: C8C62514 18182715
	v_add_co_ci_u32_e64 v4, null, s9, v1, s3                   // 000000845CF0: D5207C04 000E0209
	v_fma_f32 v0, -v12, v22, v9                                // 000000845CF8: D6130000 24262D0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000845D00: BF870214
	v_fma_f32 v1, -v13, v23, v10                               // 000000845D04: D6130001 242A2F0D
	v_fma_f32 v26, -v14, v24, v20                              // 000000845D0C: D613001A 2452310E
	v_fma_f32 v27, -v15, v25, v21                              // 000000845D14: D613001B 2456330F
	.long 0xd7000305                                           // 000000845D1C: D7000305
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 000000845D20: 02000903
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000845D24: BF870194
	v_dual_fmac_f32 v22, v0, v16 :: v_dual_fmac_f32 v23, v1, v17// 000000845D28: C8002100 16162301
	v_dual_fmac_f32 v24, v26, v18 :: v_dual_fmac_f32 v25, v27, v19// 000000845D30: C800251A 1818271B
	v_mad_u64_u32 v[0:1], null, s12, 12, v[3:4]                // 000000845D38: D6FE7C00 040D180C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000845D40: BF870213
	v_fma_f32 v9, -v12, v22, v9                                // 000000845D44: D6130009 24262D0C
	v_fma_f32 v10, -v13, v23, v10                              // 000000845D4C: D613000A 242A2F0D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000845D54: BF870004
	v_fma_f32 v12, -v14, v24, v20                              // 000000845D58: D613000C 2452310E
	v_fma_f32 v13, -v15, v25, v21                              // 000000845D60: D613000D 2456330F
	v_add_co_ci_u32_e64 v6, null, s5, v4, s3                   // 000000845D68: D5207C06 000E0805
	v_div_fmas_f32 v9, v9, v16, v22                            // 000000845D70: D6370009 045A2109
	s_mov_b32 vcc_lo, s0                                       // 000000845D78: BEEA0000
	v_div_fmas_f32 v10, v10, v17, v23                          // 000000845D7C: D637000A 045E230A
	s_mov_b32 vcc_lo, s1                                       // 000000845D84: BEEA0001
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000845D88: BF8701D2
	v_div_fixup_f32 v7, v9, v7, 1.0                            // 000000845D8C: D6270007 03CA0F09
	v_div_fmas_f32 v12, v12, v18, v24                          // 000000845D94: D637000C 0462250C
	s_mov_b32 vcc_lo, s2                                       // 000000845D9C: BEEA0002
	v_div_fixup_f32 v8, v10, v8, 1.0                           // 000000845DA0: D6270008 03CA110A
	v_div_fmas_f32 v9, v13, v19, v25                           // 000000845DA8: D6370009 0466270D
	v_div_fixup_f32 v10, v12, v2, 1.0                          // 000000845DB0: D627000A 03CA050C
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 000000845DB8: D6FE7C01 0405180D
	v_add_f32_e32 v2, v7, v7                                   // 000000845DC0: 06040F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000845DC4: BF8701B4
	v_div_fixup_f32 v9, v9, v11, 1.0                           // 000000845DC8: D6270009 03CA1709
	.long 0xd7006a07                                           // 000000845DD0: D7006A07
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 000000845DD4: 02000D03
	v_dual_add_f32 v11, v8, v8 :: v_dual_add_f32 v10, v10, v10 // 000000845DD8: C9081108 0B0A150A
	v_add_f32_e32 v9, v9, v9                                   // 000000845DE0: 06121309
	v_add_co_ci_u32_e64 v8, null, s7, v4, vcc_lo               // 000000845DE4: D5207C08 01AA0807
	s_clause 0x3                                               // 000000845DEC: BF850003
	global_store_b32 v[3:4], v2, off                           // 000000845DF0: DC6A0000 007C0203
	global_store_b32 v[5:6], v11, off                          // 000000845DF8: DC6A0000 007C0B05
	global_store_b32 v[7:8], v10, off                          // 000000845E00: DC6A0000 007C0A07
	global_store_b32 v[0:1], v9, off                           // 000000845E08: DC6A0000 007C0900
	s_endpgm                                                   // 000000845E10: BFB00000
		...

