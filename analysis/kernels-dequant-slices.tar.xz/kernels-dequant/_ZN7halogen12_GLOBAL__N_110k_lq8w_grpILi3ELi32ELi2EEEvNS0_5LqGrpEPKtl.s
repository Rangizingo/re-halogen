00000000002f5f00 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 0000002F5F00: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000002F5F04: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 0000002F5F0C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 0000002F5F14: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 0000002F5F1C: F4000180 F8000118
	v_lshrrev_b32_e32 v3, 5, v0                                // 0000002F5F24: 32060085
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 0000002F5F28: CA240080 100E009F
	v_mov_b32_e32 v23, 0                                       // 0000002F5F30: 7E2E0280
	s_waitcnt lgkmcnt(0)                                       // 0000002F5F34: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000002F5F38: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000002F5F3C: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 0000002F5F40: BF030402
	s_cselect_b32 s4, -1, 0                                    // 0000002F5F44: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F5F48: BF870009
	s_and_b32 s4, s7, s4                                       // 0000002F5F4C: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000002F5F50: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000002F5F54: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000002F5F5C: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 0000002F5F60: BF030502
	s_cselect_b32 s5, -1, 0                                    // 0000002F5F64: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F5F68: BF870009
	s_and_b32 s4, s7, s5                                       // 0000002F5F6C: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000002F5F70: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000002F5F74: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000002F5F78: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000002F5F7C: BF030602
	s_cselect_b32 s6, -1, 0                                    // 0000002F5F80: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F5F84: BF870009
	s_and_b32 s3, s3, s6                                       // 0000002F5F88: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000002F5F8C: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000002F5F90: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000002F5F94: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000002F5F98: 98030483
	s_load_b128 s[4:7], s[0:1], 0x128                          // 0000002F5F9C: F4080100 F8000128
	s_mulk_i32 s3, 0x48                                        // 0000002F5FA4: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F5FA8: BF870009
	s_add_u32 s10, s0, s3                                      // 0000002F5FAC: 800A0300
	s_addc_u32 s11, s1, 0                                      // 0000002F5FB0: 820B8001
	s_clause 0x1                                               // 0000002F5FB4: BF850001
	s_load_b64 s[8:9], s[10:11], 0x30                          // 0000002F5FB8: F4040205 F8000030
	s_load_b32 s12, s[10:11], 0x40                             // 0000002F5FC0: F4000305 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002F5FC8: BF89FC07
	.long 0xd451000e                                           // 0000002F5FCC: D451000E
	v_cndmask_b32_e32 v0, s8, v137, vcc_lo                     // 0000002F5FD0: 02011208
	s_and_b32 s0, s14, exec_lo                                 // 0000002F5FD4: 8B007E0E
	s_cselect_b32 s1, 8, 2                                     // 0000002F5FD8: 98018288
	s_cselect_b32 s3, 3, 1                                     // 0000002F5FDC: 98038183
	v_cvt_f32_ubyte0_e32 v1, s1                                // 0000002F5FE0: 7E022201
	s_sub_i32 s12, s2, s12                                     // 0000002F5FE4: 818C0C02
	s_add_i32 s0, s1, -1                                       // 0000002F5FE8: 8100C101
	s_ashr_i32 s13, s12, 31                                    // 0000002F5FEC: 860D9F0C
	s_and_b32 s15, s14, exec_lo                                // 0000002F5FF0: 8B0F7E0E
	v_rcp_iflag_f32_e32 v1, v1                                 // 0000002F5FF4: 7E025701
	s_cselect_b32 s15, 0, 2                                    // 0000002F5FF8: 980F8280
	s_ashr_i32 s16, s7, 31                                     // 0000002F5FFC: 86109F07
	s_lshl_b64 s[12:13], s[12:13], s15                         // 0000002F6000: 848C0F0C
	s_lshr_b32 s16, s16, 28                                    // 0000002F6004: 85109C10
	v_lshrrev_b32_e32 v13, s3, v3                              // 0000002F6008: 321A0603
	s_add_u32 s16, s6, s16                                     // 0000002F600C: 80101006
	s_addc_u32 s17, s7, 0                                      // 0000002F6010: 82118007
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002F6014: BF870299
	s_ashr_i64 s[16:17], s[16:17], 4                           // 0000002F6018: 86908410
	v_readfirstlane_b32 s18, v1                                // 0000002F601C: 7E240501
	s_add_u32 s20, s16, s6                                     // 0000002F6020: 80140610
	s_addc_u32 s17, s17, s7                                    // 0000002F6024: 82110711
	s_sub_i32 s19, 0, s1                                       // 0000002F6028: 81930180
	s_add_i32 s21, s0, s16                                     // 0000002F602C: 81151000
	s_mul_f32 s18, s18, 0x4f7ffffe                             // 0000002F6030: A212FF12 4F7FFFFE
	s_abs_i32 s22, s21                                         // 0000002F6038: BE961515
	.long 0xd7000c01                                           // 0000002F603C: D7000C01
	v_cndmask_b32_e32 v1, s12, v13, vcc_lo                     // 0000002F6040: 02021A0C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000002F6044: BF8704B9
	s_cvt_u32_f32 s18, s18                                     // 0000002F6048: BE926712
	v_add_co_ci_u32_e64 v2, null, s13, 0, s12                  // 0000002F604C: D5207C02 0031000D
	s_ashr_i32 s13, s21, 31                                    // 0000002F6054: 860D9F15
	s_mul_i32 s19, s19, s18                                    // 0000002F6058: 96131213
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F605C: BF870009
	s_mul_hi_u32 s19, s18, s19                                 // 0000002F6060: 96931312
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[1:2]                    // 0000002F6064: 7CA80208
	s_add_i32 s23, s18, s19                                    // 0000002F6068: 81171312
	s_load_b64 s[18:19], s[10:11], null                        // 0000002F606C: F4040485 F8000000
	s_mul_hi_u32 s23, s22, s23                                 // 0000002F6074: 96971716
	v_and_b32_e32 v14, s0, v3                                  // 0000002F6078: 361C0600
	s_mul_i32 s12, s23, s1                                     // 0000002F607C: 960C0117
	s_add_i32 s21, s23, 1                                      // 0000002F6080: 81158117
	s_sub_i32 s12, s22, s12                                    // 0000002F6084: 818C0C16
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 0000002F6088: 02040480
	s_sub_i32 s22, s12, s1                                     // 0000002F608C: 8196010C
	s_cmp_ge_u32 s12, s1                                       // 0000002F6090: BF09010C
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000002F6094: 02020280
	s_cselect_b32 s21, s21, s23                                // 0000002F6098: 98151715
	s_cselect_b32 s12, s22, s12                                // 0000002F609C: 980C0C16
	s_add_i32 s22, s21, 1                                      // 0000002F60A0: 81168115
	s_cmp_ge_u32 s12, s1                                       // 0000002F60A4: BF09010C
	.long 0xd72c0004                                           // 0000002F60A8: D72C0004
	v_cndmask_b32_e32 v0, v2, v20, vcc_lo                      // 0000002F60AC: 02002902
	s_cselect_b32 s0, s22, s21                                 // 0000002F60B0: 98001516
	.long 0xd72c0006                                           // 0000002F60B4: D72C0006
	v_cndmask_b32_e32 v0, v1, v17, vcc_lo                      // 0000002F60B8: 02002301
	s_xor_b32 s0, s0, s13                                      // 0000002F60BC: 8D000D00
	v_mov_b32_e32 v2, 0                                        // 0000002F60C0: 7E040280
	s_sub_i32 s0, s0, s13                                      // 0000002F60C4: 81800D00
	s_waitcnt lgkmcnt(0)                                       // 0000002F60C8: BF89FC07
	v_mad_u64_u32 v[9:10], null, v1, s20, s[18:19]             // 0000002F60CC: D6FE7C09 00482901
	.long 0xd72c0005                                           // 0000002F60D4: D72C0005
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 0000002F60D8: 0200010E
	v_mov_b32_e32 v1, 0                                        // 0000002F60DC: 7E020280
	v_mov_b32_e32 v3, 0                                        // 0000002F60E0: 7E060280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002F60E4: BF870214
	v_add3_u32 v10, v4, v10, v6                                // 0000002F60E8: D655000A 041A1504
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, s0, v5       // 0000002F60F0: CA200080 04060A00
	v_add_nc_u32_e32 v17, v5, v15                              // 0000002F60F8: 4A221F05
	.long 0xd7006a13                                           // 0000002F60FC: D7006A13
	v_cndmask_b32_e32 v0, v9, v6, vcc_lo                       // 0000002F6100: 02000D09
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F6104: BF870123
	v_min_i32_e32 v18, s16, v7                                 // 0000002F6108: 22240E10
	v_add_co_ci_u32_e64 v20, null, s7, v10, vcc_lo             // 0000002F610C: D5207C14 01AA1407
	v_cmp_lt_i32_e32 vcc_lo, v17, v18                          // 0000002F6114: 7C822511
	s_and_saveexec_b32 s12, vcc_lo                             // 0000002F6118: BE8C206A
	s_cbranch_execz 19                                         // 0000002F611C: BFA50013 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x26c>
	v_lshlrev_b32_e32 v1, 4, v17                               // 0000002F6120: 30022284
	v_and_b32_e32 v3, -4, v17                                  // 0000002F6124: 360622C4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F6128: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002F612C: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002F6130: 3408069F
	.long 0xd7000001                                           // 0000002F6134: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 0000002F6138: 02020309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F613C: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v10, v2, s0                  // 0000002F6140: D5207C02 0002050A
	.long 0xd7000006                                           // 0000002F6148: D7000006
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 0000002F614C: 02020713
	v_add_co_ci_u32_e64 v7, null, v20, v4, s0                  // 0000002F6150: D5207C07 00020914
	s_clause 0x1                                               // 0000002F6158: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 0000002F615C: DC5E0000 017C0001
	global_load_b32 v23, v[6:7], off                           // 0000002F6164: DC520000 177C0006
	s_or_b32 exec_lo, exec_lo, s12                             // 0000002F616C: 8C7E0C7E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v21, 0             // 0000002F6170: CA100080 16140080
	s_and_saveexec_b32 s16, vcc_lo                             // 0000002F6178: BE90206A
	s_cbranch_execz 319                                        // 0000002F617C: BFA5013F <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x77c>
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v6, 4, v15     // 0000002F6180: CA220080 15061E84
	v_mov_b32_e32 v22, 0                                       // 0000002F6188: 7E2C0280
	v_mov_b32_e32 v16, 0                                       // 0000002F618C: 7E200280
	s_lshl_b64 s[12:13], s[6:7], 2                             // 0000002F6190: 848C8206
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002F6194: BF870003
	v_lshl_add_u32 v11, v5, 4, v6                              // 0000002F6198: D646000B 04190905
	s_mov_b32 s17, 0                                           // 0000002F61A0: BE910080
	s_lshl_b64 s[6:7], s[6:7], 1                               // 0000002F61A4: 84868106
	s_branch 270                                               // 0000002F61A8: BFA0010E <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x6e4>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000002F61AC: 8C7E127E
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000002F61B0: 3418169F
	v_cvt_f32_ubyte1_e32 v50, v1                               // 0000002F61B4: 7E642501
	v_cvt_f32_ubyte2_e32 v51, v1                               // 0000002F61B8: 7E662701
	v_cvt_f32_ubyte0_e32 v52, v2                               // 0000002F61BC: 7E682302
	v_cvt_f32_ubyte1_e32 v53, v2                               // 0000002F61C0: 7E6A2502
	.long 0xd73c000b                                           // 0000002F61C4: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002F61C8: 02021681
	v_cvt_f32_ubyte2_e32 v54, v2                               // 0000002F61CC: 7E6C2702
	v_cvt_f32_ubyte3_e32 v2, v2                                // 0000002F61D0: 7E042902
	v_cvt_f32_ubyte0_e32 v55, v3                               // 0000002F61D4: 7E6E2303
	v_cvt_f32_ubyte1_e32 v56, v3                               // 0000002F61D8: 7E702503
	v_cvt_f32_ubyte2_e32 v57, v3                               // 0000002F61DC: 7E722703
	.long 0xd700000b                                           // 0000002F61E0: D700000B
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000002F61E4: 02021604
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002F61E8: BF8701A1
	v_add_co_ci_u32_e64 v12, null, s5, v12, s0                 // 0000002F61EC: D5207C0C 00021805
	v_cvt_f32_ubyte3_e32 v3, v3                                // 0000002F61F4: 7E062903
	.long 0xd700002a                                           // 0000002F61F8: D700002A
	v_cndmask_b32_e32 v0, v11, v6, vcc_lo                      // 0000002F61FC: 02000D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F6200: BF8700A1
	v_add_co_ci_u32_e64 v43, null, s7, v12, s0                 // 0000002F6204: D5207C2B 00021807
	.long 0xd700002e                                           // 0000002F620C: D700002E
	v_cndmask_b32_e32 v0, v11, v12, vcc_lo                     // 0000002F6210: 0200190B
	v_add_co_ci_u32_e64 v47, null, s13, v12, s0                // 0000002F6214: D5207C2F 0002180D
	s_clause 0x5                                               // 0000002F621C: BF850005
	global_load_b128 v[26:29], v[11:12], off                   // 0000002F6220: DC5E0000 1A7C000B
	global_load_b128 v[30:33], v[42:43], off                   // 0000002F6228: DC5E0000 1E7C002A
	global_load_b128 v[34:37], v[46:47], off                   // 0000002F6230: DC5E0000 227C002E
	global_load_b128 v[38:41], v[11:12], off offset:16         // 0000002F6238: DC5E0010 267C000B
	global_load_b128 v[42:45], v[42:43], off offset:16         // 0000002F6240: DC5E0010 2A7C002A
	global_load_b128 v[46:49], v[46:47], off offset:16         // 0000002F6248: DC5E0010 2E7C002E
	v_cvt_f32_ubyte0_e32 v11, v1                               // 0000002F6250: 7E162301
	v_cvt_f32_ubyte3_e32 v1, v1                                // 0000002F6254: 7E022901
	v_cvt_f32_ubyte0_e32 v58, v4                               // 0000002F6258: 7E742304
	v_cvt_f32_ubyte1_e32 v59, v4                               // 0000002F625C: 7E762504
	v_cvt_f32_ubyte2_e32 v60, v4                               // 0000002F6260: 7E782704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 0000002F6264: 7E082904
	v_fma_mix_f32 v11, v11, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F6268: CC20600B 145E2F0B
	v_fma_mix_f32 v50, v50, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F6270: CC206032 145E2F32
	v_fma_mix_f32 v51, v51, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F6278: CC206033 145E2F33
	v_fma_mix_f32 v1, v1, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F6280: CC206001 145E2F01
	v_fma_mix_f32 v52, v52, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F6288: CC206034 145E2F34
	v_fma_mix_f32 v53, v53, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F6290: CC206035 145E2F35
	v_fma_mix_f32 v54, v54, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F6298: CC206036 145E2F36
	v_fma_mix_f32 v2, v2, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F62A0: CC206002 145E2F02
	v_fma_mix_f32 v55, v55, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F62A8: CC206037 145E2F37
	v_fma_mix_f32 v56, v56, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F62B0: CC206038 145E2F38
	v_fma_mix_f32 v57, v57, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F62B8: CC206039 145E2F39
	v_fma_mix_f32 v3, v3, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F62C0: CC206003 145E2F03
	v_fma_mix_f32 v58, v58, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F62C8: CC20603A 145E2F3A
	v_fma_mix_f32 v59, v59, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F62D0: CC20603B 145E2F3B
	v_fma_mix_f32 v60, v60, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F62D8: CC20603C 145E2F3C
	v_fma_mix_f32 v4, v4, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F62E0: CC206004 145E2F04
	v_bfe_u32 v23, v11, 16, 1                                  // 0000002F62E8: D6100017 0205210B
	v_bfe_u32 v65, v50, 16, 1                                  // 0000002F62F0: D6100041 02052132
	v_bfe_u32 v66, v51, 16, 1                                  // 0000002F62F8: D6100042 02052133
	.long 0x7f183880                                           // 0000002F6300: 7F183880
	v_bfe_u32 v67, v1, 16, 1                                   // 0000002F6304: D6100043 02052101
	v_add3_u32 v11, v11, v23, 0x7fff                           // 0000002F630C: D655000B 03FE2F0B 00007FFF
	v_bfe_u32 v68, v52, 16, 1                                  // 0000002F6318: D6100044 02052134
	v_add3_u32 v23, v50, v65, 0x7fff                           // 0000002F6320: D6550017 03FE8332 00007FFF
	v_add3_u32 v50, v51, v66, 0x7fff                           // 0000002F632C: D6550032 03FE8533 00007FFF
	.long 0x7f7a398c                                           // 0000002F6338: 7F7A398C
	.long 0x7e18398b                                           // 0000002F633C: 7E18398B
	v_bfe_u32 v69, v53, 16, 1                                  // 0000002F6340: D6100045 02052135
	v_bfe_u32 v70, v54, 16, 1                                  // 0000002F6348: D6100046 02052136
	v_bfe_u32 v76, v58, 16, 1                                  // 0000002F6350: D610004C 0205213A
	v_bfe_u32 v79, v4, 16, 1                                   // 0000002F6358: D610004F 02052104
	v_add3_u32 v1, v1, v67, 0x7fff                             // 0000002F6360: D6550001 03FE8701 00007FFF
	v_add3_u32 v51, v52, v68, 0x7fff                           // 0000002F636C: D6550033 03FE8934 00007FFF
	.long 0x7e7a39b2                                           // 0000002F6378: 7E7A39B2
	v_and_or_b32 v23, 0xffff0000, v23, v12                     // 0000002F637C: D6570017 04322EFF FFFF0000
	v_bfe_u32 v71, v2, 16, 1                                   // 0000002F6388: D6100047 02052102
	v_bfe_u32 v72, v55, 16, 1                                  // 0000002F6390: D6100048 02052137
	v_add3_u32 v52, v53, v69, 0x7fff                           // 0000002F6398: D6550034 03FE8B35 00007FFF
	v_add3_u32 v53, v54, v70, 0x7fff                           // 0000002F63A4: D6550035 03FE8D36 00007FFF
	v_add3_u32 v11, v58, v76, 0x7fff                           // 0000002F63B0: D655000B 03FE993A 00007FFF
	v_add3_u32 v58, v4, v79, 0x7fff                            // 0000002F63BC: D655003A 03FE9F04 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v61                       // 0000002F63C8: D6570001 04F602FF FFFF0000
	.long 0x7e1839b3                                           // 0000002F63D4: 7E1839B3
	.long 0x7f7c398c                                           // 0000002F63D8: 7F7C398C
	v_bfe_u32 v73, v56, 16, 1                                  // 0000002F63DC: D6100049 02052138
	v_bfe_u32 v74, v57, 16, 1                                  // 0000002F63E4: D610004A 02052139
	v_add3_u32 v2, v2, v71, 0x7fff                             // 0000002F63EC: D6550002 03FE8F02 00007FFF
	v_add3_u32 v54, v55, v72, 0x7fff                           // 0000002F63F8: D6550036 03FE9137 00007FFF
	.long 0x7e7c39b5                                           // 0000002F6404: 7E7C39B5
	v_bfe_u32 v75, v3, 16, 1                                   // 0000002F6408: D610004B 02052103
	v_add3_u32 v55, v56, v73, 0x7fff                           // 0000002F6410: D6550037 03FE9338 00007FFF
	v_add3_u32 v56, v57, v74, 0x7fff                           // 0000002F641C: D6550038 03FE9539 00007FFF
	.long 0x7f7e398c                                           // 0000002F6428: 7F7E398C
	v_and_or_b32 v2, 0xffff0000, v2, v62                       // 0000002F642C: D6570002 04FA04FF FFFF0000
	v_bfe_u32 v77, v59, 16, 1                                  // 0000002F6438: D610004D 0205213B
	v_bfe_u32 v78, v60, 16, 1                                  // 0000002F6440: D610004E 0205213C
	v_add3_u32 v3, v3, v75, 0x7fff                             // 0000002F6448: D6550003 03FE9703 00007FFF
	.long 0x7e7e39b8                                           // 0000002F6454: 7E7E39B8
	.long 0x7f80398c                                           // 0000002F6458: 7F80398C
	v_add3_u32 v50, v59, v77, 0x7fff                           // 0000002F645C: D6550032 03FE9B3B 00007FFF
	v_add3_u32 v57, v60, v78, 0x7fff                           // 0000002F6468: D6550039 03FE9D3C 00007FFF
	s_and_b32 s0, exec_lo, vcc_lo                              // 0000002F6474: 8B006A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6478: BF870099
	s_or_b32 s17, s0, s17                                      // 0000002F647C: 8C111100
	.long 0x7e8039b9                                           // 0000002F6480: 7E8039B9
	s_waitcnt vmcnt(5)                                         // 0000002F6484: BF8917F7
	v_dot2_f32_bf16 v4, v26, v23, 0                            // 0000002F6488: CC1A4004 1A022F1A
	s_waitcnt vmcnt(4)                                         // 0000002F6490: BF8913F7
	v_dot2_f32_bf16 v26, v30, v23, 0                           // 0000002F6494: CC1A401A 1A022F1E
	s_waitcnt vmcnt(3)                                         // 0000002F649C: BF890FF7
	v_dot2_f32_bf16 v23, v34, v23, 0                           // 0000002F64A0: CC1A4017 1A022F22
	v_and_or_b32 v30, 0xffff0000, v52, v12                     // 0000002F64A8: D657001E 043268FF FFFF0000
	.long 0x7e1839b6                                           // 0000002F64B4: 7E1839B6
	v_dot2_f32_bf16 v4, v27, v1, v4                            // 0000002F64B8: CC1A4004 1C12031B
	v_dot2_f32_bf16 v26, v31, v1, v26                          // 0000002F64C0: CC1A401A 1C6A031F
	v_dot2_f32_bf16 v1, v35, v1, v23                           // 0000002F64C8: CC1A4001 1C5E0323
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F64D0: BF870193
	v_dot2_f32_bf16 v4, v28, v30, v4                           // 0000002F64D4: CC1A4004 1C123D1C
	v_dot2_f32_bf16 v23, v32, v30, v26                         // 0000002F64DC: CC1A4017 1C6A3D20
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002F64E4: BF870003
	v_dot2_f32_bf16 v1, v36, v30, v1                           // 0000002F64E8: CC1A4001 1C063D24
	v_and_or_b32 v26, 0xffff0000, v55, v12                     // 0000002F64F0: D657001A 04326EFF FFFF0000
	.long 0x7e18398b                                           // 0000002F64FC: 7E18398B
	v_dot2_f32_bf16 v4, v29, v2, v4                            // 0000002F6500: CC1A4004 1C12051D
	v_dot2_f32_bf16 v23, v33, v2, v23                          // 0000002F6508: CC1A4017 1C5E0521
	v_dot2_f32_bf16 v1, v37, v2, v1                            // 0000002F6510: CC1A4001 1C060525
	v_and_or_b32 v2, 0xffff0000, v3, v63                       // 0000002F6518: D6570002 04FE06FF FFFF0000
	v_and_or_b32 v11, 0xffff0000, v50, v12                     // 0000002F6524: D657000B 043264FF FFFF0000
	s_waitcnt vmcnt(2)                                         // 0000002F6530: BF890BF7
	v_dot2_f32_bf16 v3, v38, v26, v4                           // 0000002F6534: CC1A4003 1C123526
	s_waitcnt vmcnt(1)                                         // 0000002F653C: BF8907F7
	v_dot2_f32_bf16 v4, v42, v26, v23                          // 0000002F6540: CC1A4004 1C5E352A
	s_waitcnt vmcnt(0)                                         // 0000002F6548: BF8903F7
	v_dot2_f32_bf16 v1, v46, v26, v1                           // 0000002F654C: CC1A4001 1C06352E
	v_dot2_f32_bf16 v3, v39, v2, v3                            // 0000002F6554: CC1A4003 1C0E0527
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F655C: BF870193
	v_dot2_f32_bf16 v12, v43, v2, v4                           // 0000002F6560: CC1A400C 1C12052B
	v_dot2_f32_bf16 v1, v47, v2, v1                            // 0000002F6568: CC1A4001 1C06052F
	v_mov_b32_e32 v4, v8                                       // 0000002F6570: 7E080308
	v_and_or_b32 v8, 0xffff0000, v58, v64                      // 0000002F6574: D6570008 050274FF FFFF0000
	v_dot2_f32_bf16 v23, v40, v11, v3                          // 0000002F6580: CC1A4017 1C0E1728
	v_dot2_f32_bf16 v12, v44, v11, v12                         // 0000002F6588: CC1A400C 1C32172C
	v_dot2_f32_bf16 v1, v48, v11, v1                           // 0000002F6590: CC1A4001 1C061730
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v2, v6             // 0000002F6598: CA100107 03020106
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002F65A0: BF870214
	v_dot2_f32_bf16 v6, v41, v8, v23                           // 0000002F65A4: CC1A4006 1C5E1129
	v_dot2_f32_bf16 v7, v45, v8, v12                           // 0000002F65AC: CC1A4007 1C32112D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000002F65B4: BF870234
	v_dot2_f32_bf16 v8, v49, v8, v1                            // 0000002F65B8: CC1A4008 1C061131
	v_mov_b32_e32 v1, v5                                       // 0000002F65C0: 7E020305
	v_mov_b32_e32 v11, v24                                     // 0000002F65C4: 7E160318
	v_dual_add_f32 v21, v21, v6 :: v_dual_add_f32 v22, v22, v7 // 0000002F65C8: C9080D15 15160F16
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002F65D0: BF870004
	v_dual_add_f32 v16, v16, v8 :: v_dual_mov_b32 v23, v25     // 0000002F65D4: C9101110 10160119
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 0000002F65DC: 917E117E
	s_cbranch_execz 37                                         // 0000002F65E0: BFA50025 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x778>
	v_add_nc_u32_e32 v17, 32, v17                              // 0000002F65E4: 4A2222A0
	v_add_nc_u32_e32 v24, 0x200, v11                           // 0000002F65E8: 4A3016FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002F65F0: BF8704A2
	v_cmp_ge_i32_e32 vcc_lo, v17, v18                          // 0000002F65F4: 7C8C2511
	s_and_saveexec_b32 s0, vcc_lo                              // 0000002F65F8: BE80206A
	s_xor_b32 s0, exec_lo, s0                                  // 0000002F65FC: 8D00007E
	v_add_nc_u32_e32 v24, 0x200, v11                           // 0000002F6600: 4A3016FF 00000200
	s_or_saveexec_b32 s18, s0                                  // 0000002F6608: BE922200
	s_waitcnt vmcnt(0)                                         // 0000002F660C: BF8903F7
	v_dual_mov_b32 v25, v23 :: v_dual_mov_b32 v6, v2           // 0000002F6610: CA100117 19060102
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000002F6618: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000002F6620: 7E0E0303
	s_xor_b32 exec_lo, exec_lo, s18                            // 0000002F6624: 8D7E127E
	s_cbranch_execz 65248                                      // 0000002F6628: BFA5FEE0 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x2ac>
	v_and_b32_e32 v7, -4, v17                                  // 0000002F662C: 360E22C4
	v_ashrrev_i32_e32 v6, 31, v24                              // 0000002F6630: 340C309F
	.long 0xd7000005                                           // 0000002F6634: D7000005
	v_cndmask_b32_e32 v1, v9, v24, vcc_lo                      // 0000002F6638: 02023109
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F663C: BF870193
	v_ashrrev_i32_e32 v8, 31, v7                               // 0000002F6640: 34100E9F
	v_add_co_ci_u32_e64 v6, null, v10, v6, s0                  // 0000002F6644: D5207C06 00020D0A
	.long 0xd7000019                                           // 0000002F664C: D7000019
	v_cndmask_b32_e32 v1, v19, v7, vcc_lo                      // 0000002F6650: 02020F13
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002F6654: BF870001
	v_add_co_ci_u32_e64 v26, null, v20, v8, s0                 // 0000002F6658: D5207C1A 00021114
	s_clause 0x1                                               // 0000002F6660: BF850001
	global_load_b128 v[5:8], v[5:6], off                       // 0000002F6664: DC5E0000 057C0005
	global_load_b32 v25, v[25:26], off                         // 0000002F666C: DC520000 197C0019
	s_branch 65229                                             // 0000002F6674: BFA0FECD <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x2ac>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000002F6678: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002F667C: BF8700C9
	s_or_b32 exec_lo, exec_lo, s16                             // 0000002F6680: 8C7E107E
	s_waitcnt vmcnt(1)                                         // 0000002F6684: BF8907F7
	.long 0xd71f0001                                           // 0000002F6688: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002F668C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000002F6690: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000002F6694: 3A040290
	v_xor_b32_e32 v5, 8, v1                                    // 0000002F6698: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 0000002F669C: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002F66A0: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000002F66A4: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000002F66A8: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000002F66AC: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 0000002F66B0: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000002F66B4: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002F66B8: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000002F66BC: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000002F66C0: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 0000002F66C4: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 0000002F66CC: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 0000002F66D0: 06060715
	ds_bpermute_b32 v4, v2, v22                                // 0000002F66D4: DACC0000 04001602
	ds_bpermute_b32 v2, v2, v16                                // 0000002F66DC: DACC0000 02001002
	ds_bpermute_b32 v6, v5, v3                                 // 0000002F66E4: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000002F66EC: 02101101
	s_waitcnt lgkmcnt(0)                                       // 0000002F66F0: BF89FC07
	v_dual_add_f32 v4, v22, v4 :: v_dual_add_f32 v3, v3, v6    // 0000002F66F4: C9080916 04020D03
	ds_bpermute_b32 v7, v5, v4                                 // 0000002F66FC: DACC0000 07000405
	v_add_f32_e32 v2, v16, v2                                  // 0000002F6704: 06040510
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000002F6708: 30101082
	ds_bpermute_b32 v5, v5, v2                                 // 0000002F670C: DACC0000 05000205
	s_waitcnt lgkmcnt(1)                                       // 0000002F6714: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 0000002F6718: 06080F04
	ds_bpermute_b32 v6, v8, v4                                 // 0000002F671C: DACC0000 06000408
	s_waitcnt lgkmcnt(0)                                       // 0000002F6724: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 0000002F6728: 06080D04
	v_add_f32_e32 v2, v2, v5                                   // 0000002F672C: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 0000002F6730: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 0000002F6738: DACC0000 07000208
	v_xor_b32_e32 v8, 2, v1                                    // 0000002F6740: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002F6744: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000002F6748: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000002F674C: 02101101
	s_waitcnt lgkmcnt(1)                                       // 0000002F6750: BF89FC17
	v_dual_add_f32 v3, v3, v5 :: v_dual_lshlrev_b32 v8, 2, v8  // 0000002F6754: C9220B03 03081082
	s_waitcnt lgkmcnt(0)                                       // 0000002F675C: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 0000002F6760: 06040F02
	ds_bpermute_b32 v6, v8, v4                                 // 0000002F6764: DACC0000 06000408
	ds_bpermute_b32 v5, v8, v3                                 // 0000002F676C: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 0000002F6774: DACC0000 07000208
	v_xor_b32_e32 v8, 1, v1                                    // 0000002F677C: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F6780: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000002F6784: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 0000002F6788: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 0000002F678C: 30100282
	s_waitcnt lgkmcnt(1)                                       // 0000002F6790: BF89FC17
	v_add_f32_e32 v1, v3, v5                                   // 0000002F6794: 06020B03
	s_waitcnt lgkmcnt(0)                                       // 0000002F6798: BF89FC07
	v_dual_add_f32 v3, v4, v6 :: v_dual_add_f32 v2, v2, v7     // 0000002F679C: C9080D04 03020F02
	ds_bpermute_b32 v4, v8, v1                                 // 0000002F67A4: DACC0000 04000108
	ds_bpermute_b32 v6, v8, v3                                 // 0000002F67AC: DACC0000 06000308
	ds_bpermute_b32 v5, v8, v2                                 // 0000002F67B4: DACC0000 05000208
	v_cmpx_eq_u32_e32 0, v15                                   // 0000002F67BC: 7D941E80
	s_cbranch_execz 12                                         // 0000002F67C0: BFA5000C <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x8f4>
	v_lshl_add_u32 v7, v13, s3, v14                            // 0000002F67C4: D6460007 0438070D
	s_waitcnt lgkmcnt(0)                                       // 0000002F67CC: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v2, v2, v5     // 0000002F67D0: C9080D03 03020B02
	v_add_f32_e32 v1, v1, v4                                   // 0000002F67D8: 06020901
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002F67DC: BF870003
	v_mul_u32_u24_e32 v4, 12, v7                               // 0000002F67E0: 16080E8C
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 0000002F67E4: D8380100 00030104
	ds_store_b32 v4, v2 offset:8                               // 0000002F67EC: D8340008 00000204
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002F67F4: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F67F8: BF870009
	s_and_b32 s0, s14, exec_lo                                 // 0000002F67FC: 8B007E0E
	s_cselect_b32 s0, 3, 12                                    // 0000002F6800: 98008C83
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000002F6804: BF890007
	v_cmp_gt_u32_e32 vcc_lo, s0, v0                            // 0000002F6808: 7C980000
	s_barrier                                                  // 0000002F680C: BFBD0000
	buffer_gl0_inv                                             // 0000002F6810: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 0000002F6818: BE80206A
	s_cbranch_execz 413                                        // 0000002F681C: BFA5019D <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xf94>
	s_load_b32 s0, s[10:11], 0x40                              // 0000002F6820: F4000005 F8000040
	.long 0xd7054000                                           // 0000002F6828: D7054000
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 0000002F682C: 020200FF 000000AB
	.long 0x7f063880                                           // 0000002F6834: 7F063880
	v_mov_b32_e32 v4, 0                                        // 0000002F6838: 7E080280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000002F683C: BF8704B3
	.long 0xd7391003                                           // 0000002F6840: D7391003
	v_cndmask_b32_e32 v1, 9, v0, vcc_lo                        // 0000002F6844: 02020089
	s_waitcnt lgkmcnt(0)                                       // 0000002F6848: BF89FC07
	s_sub_i32 s4, s2, s0                                       // 0000002F684C: 81840002
	s_ashr_i32 s5, s4, 31                                      // 0000002F6850: 86059F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002F6854: BF870499
	s_lshl_b64 s[4:5], s[4:5], s15                             // 0000002F6858: 84840F04
	.long 0xd7000001                                           // 0000002F685C: D7000001
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000002F6860: 02020604
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6864: BF870091
	v_add_co_ci_u32_e64 v2, null, s5, 0, s0                    // 0000002F6868: D5207C02 00010005
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[1:2]                    // 0000002F6870: 7CA80208
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000002F6874: 8B7E6A7E
	s_cbranch_execz 390                                        // 0000002F6878: BFA50186 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xf94>
	.long 0xd7054000                                           // 0000002F687C: D7054000
	v_cndmask_b32_e32 v0, v3, v131, vcc_lo                     // 0000002F6880: 02010703
	v_lshlrev_b32_e32 v3, s3, v3                               // 0000002F6884: 30060603
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F6888: BF870112
	.long 0xd7041000                                           // 0000002F688C: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000002F6890: 02020100
	v_mul_u32_u24_e32 v3, 12, v3                               // 0000002F6894: 1606068C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6898: BF870092
	v_and_b32_e32 v5, 0xff, v0                                 // 0000002F689C: 360A00FF 000000FF
	v_lshl_add_u32 v3, v5, 2, v3                               // 0000002F68A4: D6460003 040D0505
	ds_load_b32 v5, v3                                         // 0000002F68AC: D8D80000 05000003
	v_add_nc_u32_e32 v3, 12, v3                                // 0000002F68B4: 4A06068C
	s_add_i32 s1, s1, -1                                       // 0000002F68B8: 8101C101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F68BC: BF870009
	s_cmp_eq_u32 s1, 0                                         // 0000002F68C0: BF068001
	s_waitcnt lgkmcnt(0)                                       // 0000002F68C4: BF89FC07
	v_add_f32_e32 v4, v4, v5                                   // 0000002F68C8: 06080B04
	s_cbranch_scc0 65527                                       // 0000002F68CC: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x9ac>
	s_clause 0x1                                               // 0000002F68D0: BF850001
	s_load_b64 s[4:5], s[10:11], 0x38                          // 0000002F68D4: F4040105 F8000038
	s_load_b64 s[2:3], s[10:11], 0x8                           // 0000002F68DC: F4040085 F8000008
	v_and_b32_e32 v3, 0xff, v0                                 // 0000002F68E4: 360600FF 000000FF
	s_mov_b32 s6, -1                                           // 0000002F68EC: BE8600C1
	s_mov_b32 s1, 0                                            // 0000002F68F0: BE810080
	s_mov_b32 s0, 0                                            // 0000002F68F4: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000002F68F8: BF89FC07
	s_cmp_lt_i32 s5, 3                                         // 0000002F68FC: BF048305
	s_cbranch_scc1 191                                         // 0000002F6900: BFA200BF <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xd00>
	s_cmp_gt_i32 s5, 3                                         // 0000002F6904: BF028305
	s_cbranch_scc0 125                                         // 0000002F6908: BFA1007D <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xc00>
	s_cmp_gt_i32 s5, 4                                         // 0000002F690C: BF028405
	s_cbranch_scc0 70                                          // 0000002F6910: BFA10046 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xb2c>
	s_cmp_eq_u32 s5, 5                                         // 0000002F6914: BF068505
	s_mov_b32 s0, -1                                           // 0000002F6918: BE8000C1
	s_cbranch_scc0 66                                          // 0000002F691C: BFA10042 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xb28>
	v_lshrrev_b32_e32 v0, 23, v2                               // 0000002F6920: 32000497
	s_lshr_b32 s0, s9, 31                                      // 0000002F6924: 85009F09
	s_load_b64 s[10:11], s[10:11], 0x10                        // 0000002F6928: F4040285 F8000010
	s_add_u32 s6, s8, s0                                       // 0000002F6930: 80060008
	s_addc_u32 s7, s9, 0                                       // 0000002F6934: 82078009
	.long 0xd7006a00                                           // 0000002F6938: D7006A00
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002F693C: 02020101
	s_ashr_i64 s[6:7], s[6:7], 1                               // 0000002F6940: 86868106
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000002F6944: D5207C0A 01AA0480
	v_dual_mov_b32 v11, s3 :: v_dual_and_b32 v0, 0xfffffe00, v0// 0000002F694C: CA240003 0B0000FF FFFFFE00
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 0000002F6958: D6FE7C05 02020606
	v_bfe_u32 v14, v4, 16, 1                                   // 0000002F6960: D610000E 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6968: BF870093
	.long 0xd7016a08                                           // 0000002F696C: D7016A08
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002F6970: 02020101
	v_sub_co_ci_u32_e64 v9, null, v2, v10, vcc_lo              // 0000002F6974: D5217C09 01AA1502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F697C: BF870194
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 0000002F6980: D6FE7C06 041A0607
	.long 0xd700000c                                           // 0000002F6988: D700000C
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 0000002F698C: 020210FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002F6994: BF870003
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 0000002F6998: 7CA810FF 00000100
	v_mov_b32_e32 v7, s2                                       // 0000002F69A0: 7E0E0202
	v_add_co_ci_u32_e64 v13, null, -1, v9, s0                  // 0000002F69A4: D5207C0D 000212C1
	s_mov_b32 s0, 0                                            // 0000002F69AC: BE800080
	.long 0xd73c0005                                           // 0000002F69B0: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000002F69B4: 02020A81
	s_waitcnt lgkmcnt(0)                                       // 0000002F69B8: BF89FC07
	v_dual_cndmask_b32 v8, v12, v8 :: v_dual_cndmask_b32 v7, s10, v7// 0000002F69BC: CA52110C 08060E0A
	v_cndmask_b32_e32 v11, s11, v11, vcc_lo                    // 0000002F69C4: 0216160B
	v_cndmask_b32_e32 v9, v13, v9, vcc_lo                      // 0000002F69C8: 0212130D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F69CC: BF870093
	.long 0xd7006a07                                           // 0000002F69D0: D7006A07
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 0000002F69D4: 02020B07
	v_add_co_ci_u32_e64 v11, null, v11, v6, vcc_lo             // 0000002F69D8: D5207C0B 01AA0D0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F69E0: BF870193
	.long 0xd73c0005                                           // 0000002F69E4: D73C0005
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000002F69E8: 02021081
	.long 0xd7006a00                                           // 0000002F69EC: D7006A00
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000002F69F0: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002F69F4: BF8701A1
	v_add_co_ci_u32_e64 v7, null, v11, v10, vcc_lo             // 0000002F69F8: D5207C07 01AA150B
	v_add3_u32 v8, v4, v14, 0x7fff                             // 0000002F6A00: D6550008 03FE1D04 00007FFF
	.long 0xd7006a05                                           // 0000002F6A0C: D7006A05
	v_cndmask_b32_e32 v1, v0, v5, vcc_lo                       // 0000002F6A10: 02020B00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002F6A14: BF870001
	v_add_co_ci_u32_e64 v6, null, v7, v6, vcc_lo               // 0000002F6A18: D5207C06 01AA0D07
	global_store_d16_hi_b16 v[5:6], v8, off                    // 0000002F6A20: DC960000 007C0805
	s_mov_b32 s6, 0                                            // 0000002F6A28: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F6A2C: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002F6A30: 8B6A067E
	s_cbranch_vccz 49                                          // 0000002F6A34: BFA30031 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xbfc>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v4                           // 0000002F6A38: 100008FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002F6A40: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002F6A44: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002F6A48: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F6A4C: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 0000002F6A50: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 0000002F6A58: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 0000002F6A60: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6A64: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 0000002F6A68: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 0000002F6A70: 56121305
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 0000002F6A74: D6FE7C05 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F6A7C: BF870112
	v_mul_f32_e32 v11, v10, v9                                 // 0000002F6A80: 1016130A
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 0000002F6A84: D6FE7C06 041A0609
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6A8C: BF870092
	v_fma_f32 v12, -v8, v11, v10                               // 0000002F6A90: D613000C 242A1708
	v_fmac_f32_e32 v11, v12, v9                                // 0000002F6A98: 5616130C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F6A9C: BF870113
	.long 0xd73c0005                                           // 0000002F6AA0: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000002F6AA4: 02020A82
	v_fma_f32 v10, -v8, v11, v10                               // 0000002F6AA8: D613000A 242A1708
	.long 0xd73c0007                                           // 0000002F6AB0: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000002F6AB4: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002F6AB8: BF870212
	v_div_fmas_f32 v9, v10, v9, v11                            // 0000002F6ABC: D6370009 042E130A
	.long 0xd7006a05                                           // 0000002F6AC4: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000002F6AC8: 02020A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F6ACC: BF870191
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002F6AD0: D5207C06 01AA0C03
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 0000002F6AD8: D6270000 03CA0109
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6AE0: BF870093
	.long 0xd7006a05                                           // 0000002F6AE4: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002F6AE8: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002F6AEC: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 0000002F6AF4: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 0000002F6AFC: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F6B00: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002F6B04: 8B6A067E
	s_cbranch_vccz 60                                          // 0000002F6B08: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xcfc>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002F6B0C: D6100000 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6B14: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002F6B18: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002F6B24: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6B2C: BF870091
	v_mul_f32_e32 v0, s4, v0                                   // 0000002F6B30: 10000004
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002F6B34: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002F6B3C: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002F6B40: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002F6B44: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F6B48: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 0000002F6B4C: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 0000002F6B54: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 0000002F6B5C: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6B60: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 0000002F6B64: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 0000002F6B6C: 56121305
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 0000002F6B70: D6FE7C05 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6B78: BF870092
	v_mul_f32_e32 v11, v10, v9                                 // 0000002F6B7C: 1016130A
	v_fma_f32 v7, -v8, v11, v10                                // 0000002F6B80: D6130007 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002F6B88: BF870211
	v_fmac_f32_e32 v11, v7, v9                                 // 0000002F6B8C: 56161307
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 0000002F6B90: D6FE7C06 041A0609
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F6B98: BF870112
	v_fma_f32 v7, -v8, v11, v10                                // 0000002F6B9C: D6130007 242A1708
	.long 0xd73c0005                                           // 0000002F6BA4: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000002F6BA8: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002F6BAC: BF8701A2
	v_div_fmas_f32 v9, v7, v9, v11                             // 0000002F6BB0: D6370009 042E1307
	.long 0xd73c0007                                           // 0000002F6BB8: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000002F6BBC: 02020282
	.long 0xd7006a05                                           // 0000002F6BC0: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000002F6BC4: 02020A02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002F6BC8: BF8701A3
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 0000002F6BCC: D6270000 03CA0109
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002F6BD4: D5207C06 01AA0C03
	.long 0xd7006a05                                           // 0000002F6BDC: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002F6BE0: 02020F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F6BE4: BF870193
	v_add_f32_e32 v0, v0, v0                                   // 0000002F6BE8: 06000100
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002F6BEC: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 0000002F6BF4: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 0000002F6BFC: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F6C00: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002F6C04: 8B6A067E
	s_cbranch_vccz 73                                          // 0000002F6C08: BFA30049 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xe30>
	s_cmp_gt_i32 s5, 1                                         // 0000002F6C0C: BF028105
	s_mov_b32 s1, -1                                           // 0000002F6C10: BE8100C1
	s_cbranch_scc0 64                                          // 0000002F6C14: BFA10040 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xe18>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002F6C18: D6100000 02052104
	s_mov_b32 s1, 0                                            // 0000002F6C20: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6C24: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002F6C28: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002F6C34: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6C3C: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002F6C40: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000002F6C48: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6C4C: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002F6C50: 060000F2
	v_div_scale_f32 v7, null, v0, v0, 1.0                      // 0000002F6C54: D6FC7C07 03CA0100
	v_div_scale_f32 v9, vcc_lo, 1.0, v0, 1.0                   // 0000002F6C5C: D6FC6A09 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002F6C64: BF870292
	v_rcp_f32_e32 v8, v7                                       // 0000002F6C68: 7E105507
	v_fma_f32 v5, -v7, v8, 1.0                                 // 0000002F6C6C: D6130005 23CA1107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F6C74: BF870121
	v_fmac_f32_e32 v8, v5, v8                                  // 0000002F6C78: 56101105
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 0000002F6C7C: D6FE7C05 02020608
	v_mul_f32_e32 v10, v9, v8                                  // 0000002F6C84: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6C88: BF870091
	v_fma_f32 v11, -v7, v10, v9                                // 0000002F6C8C: D613000B 24261507
	v_fmac_f32_e32 v10, v11, v8                                // 0000002F6C94: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F6C98: BF870121
	v_fma_f32 v9, -v7, v10, v9                                 // 0000002F6C9C: D6130009 24261507
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 0000002F6CA4: D6FE7C06 041A0609
	v_div_fmas_f32 v7, v9, v8, v10                             // 0000002F6CAC: D6370007 042A1109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F6CB4: BF870112
	.long 0xd73c0005                                           // 0000002F6CB8: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000002F6CBC: 02020A81
	v_div_fixup_f32 v0, v7, v0, 1.0                            // 0000002F6CC0: D6270000 03CA0107
	.long 0xd73c0007                                           // 0000002F6CC8: D73C0007
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002F6CCC: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F6CD0: BF870193
	.long 0xd7006a05                                           // 0000002F6CD4: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000002F6CD8: 02020A02
	v_bfe_u32 v9, v0, 16, 1                                    // 0000002F6CDC: D6100009 02052100
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002F6CE4: D5207C06 01AA0C03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F6CEC: BF870193
	.long 0xd7006a05                                           // 0000002F6CF0: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002F6CF4: 02020F05
	v_add3_u32 v0, v0, v9, 0x7fff                              // 0000002F6CF8: D6550000 03FE1300 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002F6D04: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002F6D08: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v0, off                    // 0000002F6D10: DC960000 007C0005
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002F6D18: 916A017E
	s_mov_b32 s1, 0                                            // 0000002F6D1C: BE810080
	s_cbranch_vccnz 3                                          // 0000002F6D20: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xe30>
	s_cmp_lg_u32 s5, 1                                         // 0000002F6D24: BF078105
	s_mov_b32 s1, -1                                           // 0000002F6D28: BE8100C1
	s_cselect_b32 s0, -1, 0                                    // 0000002F6D2C: 980080C1
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002F6D30: D6100005 02052104
	.long 0xd73c0000                                           // 0000002F6D38: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002F6D3C: 02020281
	s_and_b32 vcc_lo, exec_lo, s0                              // 0000002F6D40: 8B6A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002F6D44: BF870002
	v_add3_u32 v2, v4, v5, 0x7fff                              // 0000002F6D48: D6550002 03FE0B04 00007FFF
	s_cbranch_vccz 20                                          // 0000002F6D54: BFA30014 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xea8>
	v_mad_u64_u32 v[4:5], null, s8, v3, 0                      // 0000002F6D58: D6FE7C04 02020608
	s_mov_b32 s1, 0                                            // 0000002F6D60: BE810080
	v_mad_u64_u32 v[5:6], null, s9, v3, v[5:6]                 // 0000002F6D64: D6FE7C05 04160609
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6D6C: BF870091
	.long 0xd73c0004                                           // 0000002F6D70: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002F6D74: 02020881
	.long 0xd7006a04                                           // 0000002F6D78: D7006A04
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 0000002F6D7C: 02020802
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F6D80: BF870111
	v_add_co_ci_u32_e64 v5, null, s3, v5, vcc_lo               // 0000002F6D84: D5207C05 01AA0A03
	.long 0xd7006a04                                           // 0000002F6D8C: D7006A04
	v_cndmask_b32_e32 v1, v4, v0, vcc_lo                       // 0000002F6D90: 02020104
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002F6D94: BF870001
	v_add_co_ci_u32_e64 v5, null, v5, v1, vcc_lo               // 0000002F6D98: D5207C05 01AA0305
	global_store_d16_hi_b16 v[4:5], v2, off                    // 0000002F6DA0: DC960000 007C0204
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002F6DA8: 916A017E
	s_cbranch_vccnz 57                                         // 0000002F6DAC: BFA40039 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xf94>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6DB0: BF870091
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000002F6DB4: 360404FF FFFF0000
	v_mul_f32_e32 v2, s4, v2                                   // 0000002F6DBC: 10040404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6DC0: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v2                           // 0000002F6DC4: 100804FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 0000002F6DCC: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6DD0: BF870095
	v_add_f32_e32 v7, 1.0, v4                                  // 0000002F6DD4: 060E08F2
	v_div_scale_f32 v6, null, v7, v7, v2                       // 0000002F6DD8: D6FC7C06 040A0F07
	v_div_scale_f32 v9, vcc_lo, v2, v7, v2                     // 0000002F6DE0: D6FC6A09 040A0F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002F6DE8: BF870292
	v_rcp_f32_e32 v8, v6                                       // 0000002F6DEC: 7E105506
	v_fma_f32 v4, -v6, v8, 1.0                                 // 0000002F6DF0: D6130004 23CA1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F6DF8: BF870121
	v_fmac_f32_e32 v8, v4, v8                                  // 0000002F6DFC: 56101104
	v_mad_u64_u32 v[4:5], null, s8, v3, 0                      // 0000002F6E00: D6FE7C04 02020608
	v_mul_f32_e32 v10, v9, v8                                  // 0000002F6E08: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6E0C: BF870091
	v_fma_f32 v11, -v6, v10, v9                                // 0000002F6E10: D613000B 24261506
	v_fmac_f32_e32 v10, v11, v8                                // 0000002F6E18: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F6E1C: BF870121
	v_fma_f32 v9, -v6, v10, v9                                 // 0000002F6E20: D6130009 24261506
	v_mad_u64_u32 v[5:6], null, s9, v3, v[5:6]                 // 0000002F6E28: D6FE7C05 04160609
	v_div_fmas_f32 v3, v9, v8, v10                             // 0000002F6E30: D6370003 042A1109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F6E38: BF870191
	v_div_fixup_f32 v6, v3, v7, v2                             // 0000002F6E3C: D6270006 040A0F03
	.long 0xd73c0002                                           // 0000002F6E44: D73C0002
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002F6E48: 02020881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F6E4C: BF870112
	v_bfe_u32 v4, v6, 16, 1                                    // 0000002F6E50: D6100004 02052106
	.long 0xd7006a02                                           // 0000002F6E58: D7006A02
	v_cndmask_b32_e32 v1, s2, v2, vcc_lo                       // 0000002F6E5C: 02020402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F6E60: BF870191
	v_add_co_ci_u32_e64 v3, null, s3, v3, vcc_lo               // 0000002F6E64: D5207C03 01AA0603
	v_add3_u32 v4, v6, v4, 0x7fff                              // 0000002F6E6C: D6550004 03FE0906 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F6E78: BF870093
	.long 0xd7006a00                                           // 0000002F6E7C: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 0000002F6E80: 02020102
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 0000002F6E84: D5207C01 01AA0303
	global_store_d16_hi_b16 v[0:1], v4, off                    // 0000002F6E8C: DC960000 007C0400
	s_endpgm                                                   // 0000002F6E94: BFB00000
		...

