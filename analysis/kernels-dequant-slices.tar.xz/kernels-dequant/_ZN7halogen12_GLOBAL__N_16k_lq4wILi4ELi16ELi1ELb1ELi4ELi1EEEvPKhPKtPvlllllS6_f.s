0000000000f92900 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000F92900: F4100100 F8000000
	v_and_b32_e32 v23, 15, v0                                  // 000000F92908: 362E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000F9290C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000F92910: 86039F02
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000F92914: 30000082
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000F92918: 84808402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000F9291C: BF870009
	v_dual_mov_b32 v17, s1 :: v_dual_lshlrev_b32 v2, 2, v23    // 000000F92920: CA220001 11022E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 000000F92928: 30060282
	v_or_b32_e32 v16, s0, v1                                   // 000000F9292C: 38200200
	.long 0x7f023880                                           // 000000F92930: 7F023880
	s_waitcnt lgkmcnt(0)                                       // 000000F92934: BF89FC07
	s_clause 0x1                                               // 000000F92938: BF850001
	global_load_b32 v2, v2, s[4:5]                             // 000000F9293C: DC520000 02040002
	global_load_b32 v3, v3, s[4:5]                             // 000000F92944: DC520000 03040003
	.long 0xd4540000                                           // 000000F9294C: D4540000
	v_cndmask_b32_e32 v1, s12, v16, vcc_lo                     // 000000F92950: 0202200C
	s_add_u32 s22, s4, s16                                     // 000000F92954: 80161004
	s_addc_u32 s23, s5, s17                                    // 000000F92958: 82171105
	s_ashr_i32 s2, s11, 31                                     // 000000F9295C: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000F92960: BF870159
	s_lshr_b32 s2, s2, 27                                      // 000000F92964: 85029B02
	v_cndmask_b32_e64 v10, 0, v16, s0                          // 000000F92968: D501000A 00022080
	v_cndmask_b32_e64 v12, 0, s1, s0                           // 000000F92970: D501000C 00000280
	s_add_u32 s2, s10, s2                                      // 000000F92978: 8002020A
	s_addc_u32 s3, s11, 0                                      // 000000F9297C: 8203800B
	.long 0xd72c0004                                           // 000000F92980: D72C0004
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 000000F92984: 02021413
	v_mad_u64_u32 v[8:9], null, s18, v10, 0                    // 000000F92988: D6FE7C08 02021412
	s_lshr_b64 s[20:21], s[2:3], 5                             // 000000F92990: 85948502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000F92994: BF870009
	s_cmpk_lt_i32 s20, 0x81                                    // 000000F92998: B3940081
	.long 0xd4440002                                           // 000000F9299C: D4440002
	v_cndmask_b32_e32 v1, s20, v23, vcc_lo                     // 000000F929A0: 02022E14
	s_cselect_b32 s1, -1, 0                                    // 000000F929A4: 980180C1
	s_cmpk_gt_i32 s20, 0x80                                    // 000000F929A8: B2940080
	.long 0xd700030b                                           // 000000F929AC: D700030B
	v_cndmask_b32_e32 v1, s22, v8, vcc_lo                      // 000000F929B0: 02021016
	s_waitcnt vmcnt(1)                                         // 000000F929B4: BF8907F7
	v_bfe_u32 v5, v2, 16, 1                                    // 000000F929B8: D6100005 02052102
	s_waitcnt vmcnt(0)                                         // 000000F929C0: BF8903F7
	v_bfe_u32 v6, v3, 16, 1                                    // 000000F929C4: D6100006 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F929CC: BF8701A2
	v_add3_u32 v2, v2, v5, 0x7fff                              // 000000F929D0: D6550002 03FE0B02 00007FFF
	.long 0xd72c0005                                           // 000000F929DC: D72C0005
	v_cndmask_b32_e32 v1, s18, v12, vcc_lo                     // 000000F929E0: 02021812
	v_add3_u32 v3, v3, v6, 0x7fff                              // 000000F929E4: D6550003 03FE0D03 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 000000F929F0: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F929F4: BF8701A9
	s_and_b32 vcc_lo, exec_lo, s18                             // 000000F929F8: 8B6A127E
	.long 0x7e023982                                           // 000000F929FC: 7E023982
	v_add3_u32 v9, v9, v5, v4                                  // 000000F92A00: D6550009 04120B09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F92A08: BF870112
	v_and_or_b32 v1, 0xffff0000, v3, v1                        // 000000F92A0C: D6570001 040606FF FFFF0000
	v_add_co_ci_u32_e64 v20, null, s23, v9, s3                 // 000000F92A18: D5207C14 000E1217
	ds_store_b32 v0, v1                                        // 000000F92A20: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000F92A28: BF89FC07
	s_barrier                                                  // 000000F92A2C: BFBD0000
	buffer_gl0_inv                                             // 000000F92A30: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 000000F92A38: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x37c>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 000000F92A3C: CA100080 01000080
	s_and_saveexec_b32 s3, s2                                  // 000000F92A44: BE832002
	s_cbranch_execz 10                                         // 000000F92A48: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x174>
	v_lshlrev_b32_e32 v0, 1, v23                               // 000000F92A4C: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F92A50: BF870091
	.long 0xd7006a02                                           // 000000F92A54: D7006A02
	v_cndmask_b32_e32 v1, v11, v0, vcc_lo                      // 000000F92A58: 0202010B
	v_add_co_ci_u32_e64 v3, null, 0, v20, vcc_lo               // 000000F92A5C: D5207C03 01AA2880
	global_load_d16_b16 v0, v[2:3], off                        // 000000F92A64: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 000000F92A6C: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 000000F92A70: 7E001700
	s_or_b32 exec_lo, exec_lo, s3                              // 000000F92A74: 8C7E037E
	v_or_b32_e32 v2, 16, v23                                   // 000000F92A78: 38042E90
	s_mov_b32 s2, exec_lo                                      // 000000F92A7C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F92A80: BF870001
	.long 0xd4c4007e                                           // 000000F92A84: D4C4007E
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000F92A88: 02020414
	s_cbranch_execz 10                                         // 000000F92A8C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x1b8>
	v_lshlrev_b32_e32 v1, 1, v2                                // 000000F92A90: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F92A94: BF870091
	.long 0xd7006a01                                           // 000000F92A98: D7006A01
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 000000F92A9C: 0202030B
	v_add_co_ci_u32_e64 v2, null, 0, v20, vcc_lo               // 000000F92AA0: D5207C02 01AA2880
	global_load_d16_b16 v1, v[1:2], off                        // 000000F92AA8: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000F92AB0: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000F92AB4: 7E021701
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F92AB8: 8C7E027E
	v_or_b32_e32 v4, 32, v23                                   // 000000F92ABC: 38082EA0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 000000F92AC0: CA100080 03020080
	s_mov_b32 s2, exec_lo                                      // 000000F92AC8: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F92ACC: BF870002
	.long 0xd4c4007e                                           // 000000F92AD0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 000000F92AD4: 02020814
	s_cbranch_execz 10                                         // 000000F92AD8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x204>
	v_lshlrev_b32_e32 v2, 1, v4                                // 000000F92ADC: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F92AE0: BF870091
	.long 0xd7006a04                                           // 000000F92AE4: D7006A04
	v_cndmask_b32_e32 v1, v11, v2, vcc_lo                      // 000000F92AE8: 0202050B
	v_add_co_ci_u32_e64 v5, null, 0, v20, vcc_lo               // 000000F92AEC: D5207C05 01AA2880
	global_load_d16_b16 v2, v[4:5], off                        // 000000F92AF4: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 000000F92AFC: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 000000F92B00: 7E041702
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F92B04: 8C7E027E
	v_or_b32_e32 v4, 48, v23                                   // 000000F92B08: 38082EB0
	s_mov_b32 s2, exec_lo                                      // 000000F92B0C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F92B10: BF870001
	.long 0xd4c4007e                                           // 000000F92B14: D4C4007E
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 000000F92B18: 02020814
	s_cbranch_execz 10                                         // 000000F92B1C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x248>
	v_lshlrev_b32_e32 v3, 1, v4                                // 000000F92B20: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F92B24: BF870091
	.long 0xd7006a03                                           // 000000F92B28: D7006A03
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 000000F92B2C: 0202070B
	v_add_co_ci_u32_e64 v4, null, 0, v20, vcc_lo               // 000000F92B30: D5207C04 01AA2880
	global_load_d16_b16 v3, v[3:4], off                        // 000000F92B38: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000F92B40: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000F92B44: 7E061703
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F92B48: 8C7E027E
	v_or_b32_e32 v6, 64, v23                                   // 000000F92B4C: 380C2EC0
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 000000F92B50: CA100080 05040080
	s_mov_b32 s2, exec_lo                                      // 000000F92B58: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F92B5C: BF870002
	.long 0xd4c4007e                                           // 000000F92B60: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000F92B64: 02020C14
	s_cbranch_execz 10                                         // 000000F92B68: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x294>
	v_lshlrev_b32_e32 v4, 1, v6                                // 000000F92B6C: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F92B70: BF870091
	.long 0xd7006a06                                           // 000000F92B74: D7006A06
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 000000F92B78: 0202090B
	v_add_co_ci_u32_e64 v7, null, 0, v20, vcc_lo               // 000000F92B7C: D5207C07 01AA2880
	global_load_d16_b16 v4, v[6:7], off                        // 000000F92B84: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 000000F92B8C: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000F92B90: 7E081704
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F92B94: 8C7E027E
	v_or_b32_e32 v6, 0x50, v23                                 // 000000F92B98: 380C2EFF 00000050
	s_mov_b32 s2, exec_lo                                      // 000000F92BA0: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F92BA4: BF870001
	.long 0xd4c4007e                                           // 000000F92BA8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000F92BAC: 02020C14
	s_cbranch_execz 10                                         // 000000F92BB0: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x2dc>
	v_lshlrev_b32_e32 v5, 1, v6                                // 000000F92BB4: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F92BB8: BF870091
	.long 0xd7006a05                                           // 000000F92BBC: D7006A05
	v_cndmask_b32_e32 v1, v11, v5, vcc_lo                      // 000000F92BC0: 02020B0B
	v_add_co_ci_u32_e64 v6, null, 0, v20, vcc_lo               // 000000F92BC4: D5207C06 01AA2880
	global_load_d16_b16 v5, v[5:6], off                        // 000000F92BCC: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 000000F92BD4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 000000F92BD8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F92BDC: 8C7E027E
	v_or_b32_e32 v13, 0x60, v23                                // 000000F92BE0: 381A2EFF 00000060
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 000000F92BE8: CA100080 07060080
	s_mov_b32 s2, exec_lo                                      // 000000F92BF0: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F92BF4: BF870002
	.long 0xd4c4007e                                           // 000000F92BF8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v13, vcc_lo                     // 000000F92BFC: 02021A14
	s_cbranch_execz 10                                         // 000000F92C00: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x32c>
	v_lshlrev_b32_e32 v6, 1, v13                               // 000000F92C04: 300C1A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F92C08: BF870091
	.long 0xd7006a0d                                           // 000000F92C0C: D7006A0D
	v_cndmask_b32_e32 v1, v11, v6, vcc_lo                      // 000000F92C10: 02020D0B
	v_add_co_ci_u32_e64 v14, null, 0, v20, vcc_lo              // 000000F92C14: D5207C0E 01AA2880
	global_load_d16_b16 v6, v[13:14], off                      // 000000F92C1C: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 000000F92C24: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000F92C28: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F92C2C: 8C7E027E
	v_or_b32_e32 v13, 0x70, v23                                // 000000F92C30: 381A2EFF 00000070
	s_mov_b32 s2, exec_lo                                      // 000000F92C38: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F92C3C: BF870001
	.long 0xd4c4007e                                           // 000000F92C40: D4C4007E
	v_cndmask_b32_e32 v1, s20, v13, vcc_lo                     // 000000F92C44: 02021A14
	s_cbranch_execz 10                                         // 000000F92C48: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x374>
	v_lshlrev_b32_e32 v7, 1, v13                               // 000000F92C4C: 300E1A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F92C50: BF870091
	.long 0xd7006a0d                                           // 000000F92C54: D7006A0D
	v_cndmask_b32_e32 v1, v11, v7, vcc_lo                      // 000000F92C58: 02020F0B
	v_add_co_ci_u32_e64 v14, null, 0, v20, vcc_lo              // 000000F92C5C: D5207C0E 01AA2880
	global_load_d16_b16 v7, v[13:14], off                      // 000000F92C64: DC820000 077C000D
	s_waitcnt vmcnt(0)                                         // 000000F92C6C: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000F92C70: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F92C74: 8C7E027E
	s_branch 9                                                 // 000000F92C78: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3a0>
	v_mov_b32_e32 v0, 0                                        // 000000F92C7C: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F92C80: BF870001
	v_mov_b32_e32 v1, v0                                       // 000000F92C84: 7E020300
	v_mov_b32_e32 v2, v0                                       // 000000F92C88: 7E040300
	v_mov_b32_e32 v3, v0                                       // 000000F92C8C: 7E060300
	v_mov_b32_e32 v4, v0                                       // 000000F92C90: 7E080300
	v_mov_b32_e32 v5, v0                                       // 000000F92C94: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 000000F92C98: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 000000F92C9C: 7E0E0300
	s_add_u32 s2, s4, s14                                      // 000000F92CA0: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000F92CA4: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 000000F92CA8: 850E9F0B
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v13, 0             // 000000F92CAC: CA100080 1A0C0080
	s_add_u32 s14, s10, s14                                    // 000000F92CB4: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000F92CB8: 820F800B
	v_cndmask_b32_e64 v24, 0, 1, s18                           // 000000F92CBC: D5010018 00490280
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000F92CC4: 868E810E
	v_mov_b32_e32 v33, 0                                       // 000000F92CC8: 7E420280
	v_mad_u64_u32 v[18:19], null, v10, s14, s[2:3]             // 000000F92CCC: D6FE7C12 00081D0A
	.long 0xd72c000a                                           // 000000F92CD4: D72C000A
	v_cndmask_b32_e32 v0, v10, v15, vcc_lo                     // 000000F92CD8: 02001F0A
	.long 0xd72c000f                                           // 000000F92CDC: D72C000F
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 000000F92CE0: 02001D0C
	.long 0xd4440002                                           // 000000F92CE4: D4440002
	v_cndmask_b32_e32 v1, s20, v23, vcc_lo                     // 000000F92CE8: 02022E14
	v_mov_b32_e32 v12, 0                                       // 000000F92CEC: 7E180280
	v_mov_b32_e32 v14, 0                                       // 000000F92CF0: 7E1C0280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000F92CF4: BF870004
	v_add3_u32 v25, v15, v19, v10                              // 000000F92CF8: D6550019 042A270F
	v_mov_b32_e32 v15, 0                                       // 000000F92D00: 7E1E0280
	s_and_saveexec_b32 s3, s2                                  // 000000F92D04: BE832002
	s_cbranch_execz 21                                         // 000000F92D08: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x460>
	v_dual_mov_b32 v33, 0 :: v_dual_lshlrev_b32 v10, 4, v23    // 000000F92D0C: CA220080 210A2E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F92D14: BF870091
	.long 0xd7006a0c                                           // 000000F92D18: D7006A0C
	v_cndmask_b32_e32 v1, v18, v10, vcc_lo                     // 000000F92D1C: 02021512
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 000000F92D20: D5207C0D 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 000000F92D28: 916A127E
	global_load_b128 v[12:15], v[12:13], off                   // 000000F92D2C: DC5E0000 0C7C000C
	s_cbranch_vccnz 10                                         // 000000F92D34: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x460>
	v_lshlrev_b32_e32 v10, 1, v23                              // 000000F92D38: 30142E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F92D3C: BF870091
	.long 0xd7006a0a                                           // 000000F92D40: D7006A0A
	v_cndmask_b32_e32 v1, v11, v10, vcc_lo                     // 000000F92D44: 0202150B
	v_add_co_ci_u32_e64 v11, null, 0, v20, vcc_lo              // 000000F92D48: D5207C0B 01AA2880
	global_load_d16_b16 v10, v[10:11], off                     // 000000F92D50: DC820000 0A7C000A
	s_waitcnt vmcnt(0)                                         // 000000F92D58: BF8903F7
	v_cvt_f32_f16_e32 v33, v10                                 // 000000F92D5C: 7E42170A
	s_or_b32 exec_lo, exec_lo, s3                              // 000000F92D60: 8C7E037E
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 000000F92D64: CA100080 1B1C0080
	v_mov_b32_e32 v29, 0                                       // 000000F92D6C: 7E3A0280
	s_and_saveexec_b32 s3, s2                                  // 000000F92D70: BE832002
	s_cbranch_execz 447                                        // 000000F92D74: BFA501BF <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xb74>
	v_dual_mov_b32 v31, v23 :: v_dual_lshlrev_b32 v10, 1, v23  // 000000F92D78: CA220117 1F0A2E81
	.long 0xd7006a08                                           // 000000F92D80: D7006A08
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 000000F92D84: 02021010
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F92D88: BF8701A1
	v_add_co_ci_u32_e64 v9, null, s17, v9, vcc_lo              // 000000F92D8C: D5207C09 01AA1211
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 000000F92D94: CA220080 14122E85
	.long 0xd7006a08                                           // 000000F92D9C: D7006A08
	v_cndmask_b32_e32 v1, v8, v10, vcc_lo                      // 000000F92DA0: 02021508
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F92DA4: BF8701A1
	v_add_co_ci_u32_e64 v9, null, 0, v9, vcc_lo                // 000000F92DA8: D5207C09 01AA1280
	v_lshl_or_b32 v30, v23, 4, 0x100                           // 000000F92DB0: D656001E 03FD0917 00000100
	.long 0xd7006a08                                           // 000000F92DBC: D7006A08
	v_cndmask_b32_e32 v1, s4, v8, vcc_lo                       // 000000F92DC0: 02021004
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F92DC4: BF8701A1
	v_add_co_ci_u32_e64 v9, null, s5, v9, vcc_lo               // 000000F92DC8: D5207C09 01AA1205
	v_dual_mov_b32 v29, v20 :: v_dual_mov_b32 v32, v33         // 000000F92DD0: CA100114 1D200121
	.long 0xd7006a15                                           // 000000F92DD8: D7006A15
	v_cndmask_b32_e32 v0, v8, v160, vcc_lo                     // 000000F92DDC: 02014108
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F92DE0: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v9, vcc_lo               // 000000F92DE4: D5207C16 01AA1280
	v_mov_b32_e32 v28, v20                                     // 000000F92DEC: 7E380314
	v_mov_b32_e32 v27, v20                                     // 000000F92DF0: 7E360314
	v_mov_b32_e32 v26, v20                                     // 000000F92DF4: 7E340314
	s_mul_i32 s2, s11, 6                                       // 000000F92DF8: 9602860B
	s_mul_hi_u32 s18, s10, 6                                   // 000000F92DFC: 9692860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000F92E00: 848E820A
	s_add_i32 s18, s18, s2                                     // 000000F92E04: 81120212
	s_mul_i32 s17, s10, 6                                      // 000000F92E08: 9611860A
	s_mov_b32 s16, 0                                           // 000000F92E0C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000F92E10: 8484810A
	s_branch 378                                               // 000000F92E14: BFA0017A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xb00>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000F92E18: 8C7E0A7E
	v_cndmask_b32_e64 v33, v33, v0, s1                         // 000000F92E1C: D5010021 00060121
	v_cndmask_b32_e64 v34, v0, v1, s1                          // 000000F92E24: D5010022 00060300
	v_dual_mov_b32 v41, v7 :: v_dual_and_b32 v0, 0xff, v12     // 000000F92E2C: CA240107 290018FF 000000FF
	v_cndmask_b32_e64 v40, v6, v7, s1                          // 000000F92E38: D5010028 00060F06
	v_cndmask_b32_e64 v39, v5, v6, s1                          // 000000F92E40: D5010027 00060D05
	v_cndmask_b32_e64 v38, v4, v5, s1                          // 000000F92E48: D5010026 00060B04
	v_cndmask_b32_e64 v37, v3, v4, s1                          // 000000F92E50: D5010025 00060903
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000F92E58: 30000082
	v_cndmask_b32_e64 v36, v2, v3, s1                          // 000000F92E5C: D5010024 00060702
	v_cndmask_b32_e64 v35, v1, v2, s1                          // 000000F92E64: D5010023 00060501
	s_and_b32 s2, exec_lo, s2                                  // 000000F92E6C: 8B02027E
	v_add_nc_u32_e32 v30, 0x100, v30                           // 000000F92E70: 4A3C3CFF 00000100
	ds_load_b32 v48, v0                                        // 000000F92E78: D8D80000 30000000
	v_lshrrev_b32_e32 v0, 6, v12                               // 000000F92E80: 32001886
	s_or_b32 s16, s2, s16                                      // 000000F92E84: 8C101002
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F92E88: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F92E8C: 360000FF 000003FC
	ds_load_b32 v49, v0                                        // 000000F92E94: D8D80000 31000000
	v_lshrrev_b32_e32 v0, 14, v12                              // 000000F92E9C: 3200188E
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F92EA0: 360000FF 000003FC
	ds_load_b32 v50, v0                                        // 000000F92EA8: D8D80000 32000000
	v_lshrrev_b32_e32 v0, 22, v12                              // 000000F92EB0: 32001896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F92EB4: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F92EB8: 360000FF 000003FC
	ds_load_b32 v51, v0                                        // 000000F92EC0: D8D80000 33000000
	v_and_b32_e32 v0, 0xff, v13                                // 000000F92EC8: 36001AFF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000F92ED0: 30000082
	ds_load_b32 v52, v0                                        // 000000F92ED4: D8D80000 34000000
	v_lshrrev_b32_e32 v0, 6, v13                               // 000000F92EDC: 32001A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F92EE0: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F92EE4: 360000FF 000003FC
	ds_load_b32 v53, v0                                        // 000000F92EEC: D8D80000 35000000
	v_lshrrev_b32_e32 v0, 14, v13                              // 000000F92EF4: 32001A8E
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F92EF8: 360000FF 000003FC
	ds_load_b32 v54, v0                                        // 000000F92F00: D8D80000 36000000
	v_lshrrev_b32_e32 v0, 22, v13                              // 000000F92F08: 32001A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F92F0C: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F92F10: 360000FF 000003FC
	ds_load_b32 v55, v0                                        // 000000F92F18: D8D80000 37000000
	v_and_b32_e32 v0, 0xff, v14                                // 000000F92F20: 36001CFF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000F92F28: 30000082
	ds_load_b32 v56, v0                                        // 000000F92F2C: D8D80000 38000000
	v_lshrrev_b32_e32 v0, 6, v14                               // 000000F92F34: 32001C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F92F38: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F92F3C: 360000FF 000003FC
	ds_load_b32 v57, v0                                        // 000000F92F44: D8D80000 39000000
	v_lshrrev_b32_e32 v0, 14, v14                              // 000000F92F4C: 32001C8E
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F92F50: 360000FF 000003FC
	ds_load_b32 v58, v0                                        // 000000F92F58: D8D80000 3A000000
	v_lshrrev_b32_e32 v0, 22, v14                              // 000000F92F60: 32001C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F92F64: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F92F68: 360000FF 000003FC
	ds_load_b32 v59, v0                                        // 000000F92F70: D8D80000 3B000000
	v_and_b32_e32 v0, 0xff, v15                                // 000000F92F78: 36001EFF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000F92F80: 30000082
	ds_load_b32 v60, v0                                        // 000000F92F84: D8D80000 3C000000
	v_lshrrev_b32_e32 v0, 6, v15                               // 000000F92F8C: 32001E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F92F90: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F92F94: 360000FF 000003FC
	ds_load_b32 v61, v0                                        // 000000F92F9C: D8D80000 3D000000
	v_lshrrev_b32_e32 v0, 14, v15                              // 000000F92FA4: 32001E8E
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F92FA8: 360000FF 000003FC
	ds_load_b32 v62, v0                                        // 000000F92FB0: D8D80000 3E000000
	v_lshrrev_b32_e32 v0, 22, v15                              // 000000F92FB8: 32001E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000F92FBC: BF870141
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F92FC0: 360000FF 000003FC
	ds_load_b32 v63, v0                                        // 000000F92FC8: D8D80000 3F000000
	.long 0xd73c0000                                           // 000000F92FD0: D73C0000
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000F92FD4: 02022681
	v_add_nc_u32_e32 v19, 0x200, v19                           // 000000F92FD8: 4A2626FF 00000200
	.long 0xd7006a2e                                           // 000000F92FE0: D7006A2E
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 000000F92FE4: 02020006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F92FE8: BF870001
	v_add_co_ci_u32_e64 v47, null, s7, v1, vcc_lo              // 000000F92FEC: D5207C2F 01AA0207
	s_clause 0x3                                               // 000000F92FF4: BF850003
	global_load_b128 v[0:3], v[46:47], off                     // 000000F92FF8: DC5E0000 007C002E
	global_load_b128 v[4:7], v[46:47], off offset:16           // 000000F93000: DC5E0010 047C002E
	global_load_b128 v[12:15], v[46:47], off offset:32         // 000000F93008: DC5E0020 0C7C002E
	global_load_b128 v[42:45], v[46:47], off offset:48         // 000000F93010: DC5E0030 2A7C002E
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000F93018: BF890CF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 000000F9301C: CC1A4000 1A026100
	s_waitcnt lgkmcnt(14)                                      // 000000F93024: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F93028: BF8700A1
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 000000F9302C: CC1A4000 1C026301
	s_waitcnt lgkmcnt(13)                                      // 000000F93034: BF89FCD7
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 000000F93038: CC1A4000 1C026502
	s_waitcnt lgkmcnt(12)                                      // 000000F93040: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F93044: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 000000F93048: CC1A4000 1C026703
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000F93050: BF8908B7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 000000F93054: CC1A4000 1C026904
	s_waitcnt lgkmcnt(10)                                      // 000000F9305C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F93060: BF8700A1
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 000000F93064: CC1A4000 1C026B05
	s_waitcnt lgkmcnt(9)                                       // 000000F9306C: BF89FC97
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 000000F93070: CC1A4000 1C026D06
	s_waitcnt lgkmcnt(8)                                       // 000000F93078: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F9307C: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 000000F93080: CC1A4000 1C026F07
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000F93088: BF890477
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 000000F9308C: CC1A4000 1C02710C
	s_waitcnt lgkmcnt(6)                                       // 000000F93094: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F93098: BF8700A1
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 000000F9309C: CC1A4000 1C02730D
	s_waitcnt lgkmcnt(5)                                       // 000000F930A4: BF89FC57
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 000000F930A8: CC1A4000 1C02750E
	s_waitcnt lgkmcnt(4)                                       // 000000F930B0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F930B4: BF8700A1
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 000000F930B8: CC1A4000 1C02770F
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000F930C0: BF890037
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 000000F930C4: CC1A4000 1C02792A
	.long 0xd7006a2a                                           // 000000F930CC: D7006A2A
	v_cndmask_b32_e32 v0, v46, v4, vcc_lo                      // 000000F930D0: 0200092E
	s_waitcnt lgkmcnt(2)                                       // 000000F930D4: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000F930D8: BF870132
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 000000F930DC: CC1A4000 1C027B2B
	v_add_co_ci_u32_e64 v43, null, s5, v47, vcc_lo             // 000000F930E4: D5207C2B 01AA5E05
	s_waitcnt lgkmcnt(1)                                       // 000000F930EC: BF89FC17
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 000000F930F0: CC1A4000 1C027D2C
	s_waitcnt lgkmcnt(0)                                       // 000000F930F8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F930FC: BF870091
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 000000F93100: CC1A4000 1C027F2D
	v_fmac_f32_e32 v29, v33, v0                                // 000000F93108: 563A0121
	s_clause 0x3                                               // 000000F9310C: BF850003
	global_load_b128 v[0:3], v[42:43], off                     // 000000F93110: DC5E0000 007C002A
	global_load_b128 v[4:7], v[42:43], off offset:16           // 000000F93118: DC5E0010 047C002A
	global_load_b128 v[12:15], v[42:43], off offset:32         // 000000F93120: DC5E0020 0C7C002A
	global_load_b128 v[42:45], v[42:43], off offset:48         // 000000F93128: DC5E0030 2A7C002A
	s_waitcnt vmcnt(3)                                         // 000000F93130: BF890FF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 000000F93134: CC1A4000 1A026100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9313C: BF870091
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 000000F93140: CC1A4000 1C026301
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 000000F93148: CC1A4000 1C026502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F93150: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 000000F93154: CC1A4000 1C026703
	s_waitcnt vmcnt(2)                                         // 000000F9315C: BF890BF7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 000000F93160: CC1A4000 1C026904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F93168: BF870091
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 000000F9316C: CC1A4000 1C026B05
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 000000F93174: CC1A4000 1C026D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F9317C: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 000000F93180: CC1A4000 1C026F07
	s_waitcnt vmcnt(1)                                         // 000000F93188: BF8907F7
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 000000F9318C: CC1A4000 1C02710C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F93194: BF870091
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 000000F93198: CC1A4000 1C02730D
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 000000F931A0: CC1A4000 1C02750E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F931A8: BF8700A1
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 000000F931AC: CC1A4000 1C02770F
	s_waitcnt vmcnt(0)                                         // 000000F931B4: BF8903F7
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 000000F931B8: CC1A4000 1C02792A
	.long 0xd7006a2a                                           // 000000F931C0: D7006A2A
	v_cndmask_b32_e32 v0, v46, v14, vcc_lo                     // 000000F931C4: 02001D2E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F931C8: BF870122
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 000000F931CC: CC1A4000 1C027B2B
	v_add_co_ci_u32_e64 v43, null, s15, v47, vcc_lo            // 000000F931D4: D5207C2B 01AA5E0F
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 000000F931DC: CC1A4000 1C027D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F931E4: BF870091
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 000000F931E8: CC1A4000 1C027F2D
	v_fmac_f32_e32 v28, v33, v0                                // 000000F931F0: 56380121
	s_clause 0x3                                               // 000000F931F4: BF850003
	global_load_b128 v[0:3], v[42:43], off                     // 000000F931F8: DC5E0000 007C002A
	global_load_b128 v[4:7], v[42:43], off offset:16           // 000000F93200: DC5E0010 047C002A
	global_load_b128 v[12:15], v[42:43], off offset:32         // 000000F93208: DC5E0020 0C7C002A
	global_load_b128 v[42:45], v[42:43], off offset:48         // 000000F93210: DC5E0030 2A7C002A
	s_waitcnt vmcnt(3)                                         // 000000F93218: BF890FF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 000000F9321C: CC1A4000 1A026100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F93224: BF870091
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 000000F93228: CC1A4000 1C026301
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 000000F93230: CC1A4000 1C026502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F93238: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 000000F9323C: CC1A4000 1C026703
	s_waitcnt vmcnt(2)                                         // 000000F93244: BF890BF7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 000000F93248: CC1A4000 1C026904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F93250: BF870091
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 000000F93254: CC1A4000 1C026B05
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 000000F9325C: CC1A4000 1C026D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F93264: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 000000F93268: CC1A4000 1C026F07
	s_waitcnt vmcnt(1)                                         // 000000F93270: BF8907F7
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 000000F93274: CC1A4000 1C02710C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9327C: BF870091
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 000000F93280: CC1A4000 1C02730D
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 000000F93288: CC1A4000 1C02750E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F93290: BF8700A1
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 000000F93294: CC1A4000 1C02770F
	s_waitcnt vmcnt(0)                                         // 000000F9329C: BF8903F7
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 000000F932A0: CC1A4000 1C02792A
	.long 0xd7006a2a                                           // 000000F932A8: D7006A2A
	v_cndmask_b32_e32 v0, v46, v17, vcc_lo                     // 000000F932AC: 0200232E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000F932B0: BF8701B2
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 000000F932B4: CC1A4000 1C027B2B
	v_add_co_ci_u32_e64 v43, null, s18, v47, vcc_lo            // 000000F932BC: D5207C2B 01AA5E12
	.long 0xd7006a15                                           // 000000F932C4: D7006A15
	v_cndmask_b32_e32 v0, v21, v160, vcc_lo                    // 000000F932C8: 02014115
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 000000F932CC: CC1A4000 1C027D2C
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 000000F932D4: D5207C16 01AA2C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F932DC: BF870092
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 000000F932E0: CC1A4000 1C027F2D
	v_fmac_f32_e32 v27, v33, v0                                // 000000F932E8: 56360121
	s_clause 0x3                                               // 000000F932EC: BF850003
	global_load_b128 v[0:3], v[42:43], off                     // 000000F932F0: DC5E0000 007C002A
	global_load_b128 v[4:7], v[42:43], off offset:16           // 000000F932F8: DC5E0010 047C002A
	global_load_b128 v[12:15], v[42:43], off offset:32         // 000000F93300: DC5E0020 0C7C002A
	global_load_b128 v[42:45], v[42:43], off offset:48         // 000000F93308: DC5E0030 2A7C002A
	s_waitcnt vmcnt(3)                                         // 000000F93310: BF890FF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 000000F93314: CC1A4000 1A026100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9331C: BF870091
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 000000F93320: CC1A4000 1C026301
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 000000F93328: CC1A4000 1C026502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F93330: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 000000F93334: CC1A4000 1C026703
	s_waitcnt vmcnt(2)                                         // 000000F9333C: BF890BF7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 000000F93340: CC1A4000 1C026904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F93348: BF870091
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 000000F9334C: CC1A4000 1C026B05
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 000000F93354: CC1A4000 1C026D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F9335C: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 000000F93360: CC1A4000 1C026F07
	s_waitcnt vmcnt(1)                                         // 000000F93368: BF8907F7
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 000000F9336C: CC1A4000 1C02710C
	v_mov_b32_e32 v12, v8                                      // 000000F93374: 7E180308
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F93378: BF870122
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 000000F9337C: CC1A4000 1C02730D
	v_mov_b32_e32 v13, v9                                      // 000000F93384: 7E1A0309
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 000000F93388: CC1A4000 1C02750E
	v_mov_b32_e32 v14, v10                                     // 000000F93390: 7E1C030A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000F93394: BF870132
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 000000F93398: CC1A4000 1C02770F
	v_mov_b32_e32 v15, v11                                     // 000000F933A0: 7E1E030B
	s_waitcnt vmcnt(0)                                         // 000000F933A4: BF8903F7
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 000000F933A8: CC1A4000 1C02792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F933B0: BF870091
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 000000F933B4: CC1A4000 1C027B2B
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 000000F933BC: CC1A4000 1C027D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F933C4: BF870091
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 000000F933C8: CC1A4000 1C027F2D
	v_fmac_f32_e32 v26, v33, v0                                // 000000F933D0: 56340121
	v_dual_mov_b32 v0, v34 :: v_dual_mov_b32 v33, v32          // 000000F933D4: CA100122 00200120
	v_dual_mov_b32 v1, v35 :: v_dual_mov_b32 v2, v36           // 000000F933DC: CA100123 01020124
	v_dual_mov_b32 v3, v37 :: v_dual_mov_b32 v4, v38           // 000000F933E4: CA100125 03040126
	v_dual_mov_b32 v5, v39 :: v_dual_mov_b32 v6, v40           // 000000F933EC: CA100127 05060128
	v_mov_b32_e32 v7, v41                                      // 000000F933F4: 7E0E0329
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000F933F8: 917E107E
	s_cbranch_execz 28                                         // 000000F933FC: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xb70>
	s_waitcnt vmcnt(0)                                         // 000000F93400: BF8903F7
	v_dual_mov_b32 v8, v12 :: v_dual_add_nc_u32 v31, 16, v31   // 000000F93404: CA20010C 081E3E90
	v_dual_mov_b32 v9, v13 :: v_dual_mov_b32 v10, v14          // 000000F9340C: CA10010D 090A010E
	v_mov_b32_e32 v11, v15                                     // 000000F93414: 7E16030F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F93418: BF870003
	.long 0xd4430002                                           // 000000F9341C: D4430002
	v_cndmask_b32_e32 v1, s20, v31, vcc_lo                     // 000000F93420: 02023E14
	s_mov_b32 s10, exec_lo                                     // 000000F93424: BE8A007E
	.long 0xd4c4007e                                           // 000000F93428: D4C4007E
	v_cndmask_b32_e32 v1, s20, v31, vcc_lo                     // 000000F9342C: 02023E14
	s_cbranch_execz 65145                                      // 000000F93430: BFA5FE79 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	.long 0xd7006a08                                           // 000000F93434: D7006A08
	v_cndmask_b32_e32 v1, v18, v30, vcc_lo                     // 000000F93438: 02023D12
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F9343C: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 000000F93440: D5207C09 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 000000F93448: 7C9A3081
	v_mov_b32_e32 v32, v33                                     // 000000F9344C: 7E400321
	global_load_b128 v[8:11], v[8:9], off                      // 000000F93450: DC5E0000 087C0008
	s_cbranch_vccnz 65135                                      // 000000F93458: BFA4FE6F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	global_load_d16_b16 v32, v[21:22], off                     // 000000F9345C: DC820000 207C0015
	s_waitcnt vmcnt(0)                                         // 000000F93464: BF8903F7
	v_cvt_f32_f16_e32 v32, v32                                 // 000000F93468: 7E401720
	s_branch 65130                                             // 000000F9346C: BFA0FE6A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000F93470: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F93474: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000F93478: 8C7E037E
	.long 0xd71f0000                                           // 000000F9347C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000F93480: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000F93484: 3A020088
	v_xor_b32_e32 v5, 4, v0                                    // 000000F93488: 3A0A0084
	v_xor_b32_e32 v9, 2, v0                                    // 000000F9348C: 3A120082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F93490: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000F93494: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000F93498: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000F9349C: 7C980AA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F934A0: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F934A4: 30020282
	ds_bpermute_b32 v4, v1, v27                                // 000000F934A8: DACC0000 04001B01
	s_waitcnt lgkmcnt(0)                                       // 000000F934B0: BF89FC07
	v_add_f32_e32 v4, v27, v4                                  // 000000F934B4: 0608091B
	ds_bpermute_b32 v2, v1, v29                                // 000000F934B8: DACC0000 02001D01
	ds_bpermute_b32 v3, v1, v28                                // 000000F934C0: DACC0000 03001C01
	ds_bpermute_b32 v1, v1, v26                                // 000000F934C8: DACC0000 01001A01
	s_waitcnt lgkmcnt(2)                                       // 000000F934D0: BF89FC27
	v_dual_add_f32 v2, v29, v2 :: v_dual_cndmask_b32 v5, v0, v5// 000000F934D4: C912051D 02040B00
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 000000F934DC: 7C9812A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F934E0: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000F934E4: 300A0A82
	v_cndmask_b32_e32 v9, v0, v9, vcc_lo                       // 000000F934E8: 02121300
	ds_bpermute_b32 v8, v5, v4                                 // 000000F934EC: DACC0000 08000405
	s_waitcnt lgkmcnt(0)                                       // 000000F934F4: BF89FC07
	v_dual_add_f32 v4, v4, v8 :: v_dual_lshlrev_b32 v9, 2, v9  // 000000F934F8: C9221104 04081282
	ds_bpermute_b32 v6, v5, v2                                 // 000000F93500: DACC0000 06000205
	s_waitcnt lgkmcnt(0)                                       // 000000F93508: BF89FC07
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v28, v3    // 000000F9350C: C9080D02 0202071C
	ds_bpermute_b32 v7, v5, v3                                 // 000000F93514: DACC0000 07000305
	s_waitcnt lgkmcnt(0)                                       // 000000F9351C: BF89FC07
	v_add_f32_e32 v3, v3, v7                                   // 000000F93520: 06060F03
	ds_bpermute_b32 v7, v9, v4                                 // 000000F93524: DACC0000 07000409
	v_add_f32_e32 v1, v26, v1                                  // 000000F9352C: 0602031A
	ds_bpermute_b32 v6, v9, v3                                 // 000000F93530: DACC0000 06000309
	ds_bpermute_b32 v5, v5, v1                                 // 000000F93538: DACC0000 05000105
	s_waitcnt lgkmcnt(0)                                       // 000000F93540: BF89FC07
	v_add_f32_e32 v5, v1, v5                                   // 000000F93544: 060A0B01
	ds_bpermute_b32 v1, v9, v2                                 // 000000F93548: DACC0000 01000209
	ds_bpermute_b32 v8, v9, v5                                 // 000000F93550: DACC0000 08000509
	v_xor_b32_e32 v9, 1, v0                                    // 000000F93558: 3A120081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000F9355C: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 000000F93560: 7C9812A0
	v_cndmask_b32_e32 v0, v0, v9, vcc_lo                       // 000000F93564: 02001300
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 000000F93568: 7C942E80
	s_waitcnt lgkmcnt(1)                                       // 000000F9356C: BF89FC17
	v_dual_add_f32 v0, v2, v1 :: v_dual_lshlrev_b32 v9, 2, v0  // 000000F93570: C9220302 00080082
	v_dual_add_f32 v1, v3, v6 :: v_dual_add_f32 v2, v4, v7     // 000000F93578: C9080D03 01020F04
	s_waitcnt lgkmcnt(0)                                       // 000000F93580: BF89FC07
	v_add_f32_e32 v3, v5, v8                                   // 000000F93584: 06061105
	s_and_b32 s0, vcc_lo, s0                                   // 000000F93588: 8B00006A
	ds_bpermute_b32 v4, v9, v0                                 // 000000F9358C: DACC0000 04000009
	ds_bpermute_b32 v5, v9, v1                                 // 000000F93594: DACC0000 05000109
	ds_bpermute_b32 v6, v9, v2                                 // 000000F9359C: DACC0000 06000209
	ds_bpermute_b32 v7, v9, v3                                 // 000000F935A4: DACC0000 07000309
	s_and_saveexec_b32 s1, s0                                  // 000000F935AC: BE812000
	s_cbranch_execz 138                                        // 000000F935B0: BFA5008A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xedc>
	s_waitcnt lgkmcnt(2)                                       // 000000F935B4: BF89FC27
	v_dual_add_f32 v0, v0, v4 :: v_dual_add_f32 v1, v1, v5     // 000000F935B8: C9080900 00000B01
	s_waitcnt lgkmcnt(0)                                       // 000000F935C0: BF89FC07
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v3, v7     // 000000F935C4: C9080D02 02020F03
	s_lshl_b64 s[4:5], s[12:13], 2                             // 000000F935CC: 8484820C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F935D0: BF870112
	v_dual_mul_f32 v0, 0xbfb8aa3b, v0 :: v_dual_mul_f32 v1, 0xbfb8aa3b, v1// 000000F935D4: C8C600FF 000002FF BFB8AA3B
	v_dual_mul_f32 v2, 0xbfb8aa3b, v2 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v3// 000000F935E0: C8C604FF 020206FF BFB8AA3B
	s_lshl_b64 s[6:7], s[12:13], 3                             // 000000F935EC: 8486830C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F935F0: BF870112
	v_exp_f32_e32 v0, v0                                       // 000000F935F4: 7E004B00
	v_exp_f32_e32 v1, v1                                       // 000000F935F8: 7E024B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_3)// 000000F935FC: BF8703A1
	v_exp_f32_e32 v2, v2                                       // 000000F93600: 7E044B02
	v_exp_f32_e32 v3, v3                                       // 000000F93604: 7E064B03
	v_dual_add_f32 v7, 1.0, v0 :: v_dual_add_f32 v8, 1.0, v1   // 000000F93608: C90800F2 070802F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F93610: BF8701A5
	v_dual_add_f32 v9, 1.0, v2 :: v_dual_add_f32 v10, 1.0, v3  // 000000F93614: C90804F2 090A06F2
	.long 0xd73c0000                                           // 000000F9361C: D73C0000
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 000000F93620: 02022082
	v_div_scale_f32 v11, null, v7, v7, 1.0                     // 000000F93624: D6FC7C0B 03CA0F07
	s_waitcnt vmcnt(0)                                         // 000000F9362C: BF8903F7
	v_div_scale_f32 v12, null, v8, v8, 1.0                     // 000000F93630: D6FC7C0C 03CA1108
	v_div_scale_f32 v13, null, v9, v9, 1.0                     // 000000F93638: D6FC7C0D 03CA1309
	v_div_scale_f32 v14, null, v10, v10, 1.0                   // 000000F93640: D6FC7C0E 03CA150A
	v_div_scale_f32 v16, vcc_lo, 1.0, v7, 1.0                  // 000000F93648: D6FC6A10 03CA0EF2
	v_rcp_f32_e32 v15, v11                                     // 000000F93650: 7E1E550B
	v_rcp_f32_e32 v18, v12                                     // 000000F93654: 7E24550C
	v_rcp_f32_e32 v19, v13                                     // 000000F93658: 7E26550D
	v_rcp_f32_e32 v20, v14                                     // 000000F9365C: 7E28550E
	v_div_scale_f32 v17, s0, 1.0, v8, 1.0                      // 000000F93660: D6FC0011 03CA10F2
	v_div_scale_f32 v21, s1, 1.0, v9, 1.0                      // 000000F93668: D6FC0115 03CA12F2
	v_div_scale_f32 v22, s2, 1.0, v10, 1.0                     // 000000F93670: D6FC0216 03CA14F2
	v_fma_f32 v2, -v11, v15, 1.0                               // 000000F93678: D6130002 23CA1F0B
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000F93680: BF870317
	v_fma_f32 v3, -v12, v18, 1.0                               // 000000F93684: D6130003 23CA250C
	v_fma_f32 v4, -v13, v19, 1.0                               // 000000F9368C: D6130004 23CA270D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F93694: BF870195
	v_fma_f32 v5, -v14, v20, 1.0                               // 000000F93698: D6130005 23CA290E
	v_dual_fmac_f32 v15, v2, v15 :: v_dual_fmac_f32 v18, v3, v18// 000000F936A0: C8001F02 0F122503
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F936A8: BF8701A2
	v_dual_fmac_f32 v19, v4, v19 :: v_dual_fmac_f32 v20, v5, v20// 000000F936AC: C8002704 13142905
	.long 0xd7000303                                           // 000000F936B4: D7000303
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000F936B8: 02020008
	v_dual_mul_f32 v23, v16, v15 :: v_dual_mul_f32 v24, v17, v18// 000000F936BC: C8C61F10 17182511
	v_add_co_ci_u32_e64 v4, null, s9, v1, s3                   // 000000F936C4: D5207C04 000E0209
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F936CC: BF870194
	v_dual_mul_f32 v25, v21, v19 :: v_dual_mul_f32 v26, v22, v20// 000000F936D0: C8C62715 191A2916
	v_fma_f32 v2, -v11, v23, v16                               // 000000F936D8: D6130002 24422F0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F936E0: BF870223
	v_mad_u64_u32 v[0:1], null, s12, 12, v[3:4]                // 000000F936E4: D6FE7C00 040D180C
	v_fma_f32 v27, -v12, v24, v17                              // 000000F936EC: D613001B 2446310C
	v_fma_f32 v28, -v13, v25, v21                              // 000000F936F4: D613001C 2456330D
	v_fma_f32 v29, -v14, v26, v22                              // 000000F936FC: D613001D 245A350E
	v_fmac_f32_e32 v23, v2, v15                                // 000000F93704: 562E1F02
	.long 0xd7000305                                           // 000000F93708: D7000305
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 000000F9370C: 02000903
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000F93710: BF870214
	v_dual_fmac_f32 v24, v27, v18 :: v_dual_fmac_f32 v25, v28, v19// 000000F93714: C800251B 1818271C
	v_fmac_f32_e32 v26, v29, v20                               // 000000F9371C: 5634291D
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 000000F93720: D6FE7C01 0405180D
	v_fma_f32 v2, -v11, v23, v16                               // 000000F93728: D6130002 24422F0B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000F93730: BF870004
	v_fma_f32 v11, -v12, v24, v17                              // 000000F93734: D613000B 2446310C
	v_fma_f32 v12, -v13, v25, v21                              // 000000F9373C: D613000C 2456330D
	v_fma_f32 v13, -v14, v26, v22                              // 000000F93744: D613000D 245A350E
	v_add_co_ci_u32_e64 v6, null, s5, v4, s3                   // 000000F9374C: D5207C06 000E0805
	v_div_fmas_f32 v2, v2, v15, v23                            // 000000F93754: D6370002 045E1F02
	s_mov_b32 vcc_lo, s0                                       // 000000F9375C: BEEA0000
	v_div_fmas_f32 v11, v11, v18, v24                          // 000000F93760: D637000B 0462250B
	s_mov_b32 vcc_lo, s1                                       // 000000F93768: BEEA0001
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F9376C: BF870002
	v_div_fixup_f32 v2, v2, v7, 1.0                            // 000000F93770: D6270002 03CA0F02
	v_div_fmas_f32 v12, v12, v19, v25                          // 000000F93778: D637000C 0466270C
	s_mov_b32 vcc_lo, s2                                       // 000000F93780: BEEA0002
	v_div_fixup_f32 v11, v11, v8, 1.0                          // 000000F93784: D627000B 03CA110B
	v_div_fmas_f32 v13, v13, v20, v26                          // 000000F9378C: D637000D 046A290D
	.long 0xd7006a07                                           // 000000F93794: D7006A07
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 000000F93798: 02000D03
	v_div_fixup_f32 v9, v12, v9, 1.0                           // 000000F9379C: D6270009 03CA130C
	v_add_co_ci_u32_e64 v8, null, s7, v4, vcc_lo               // 000000F937A4: D5207C08 01AA0807
	s_delay_alu instid0(VALU_DEP_4)                            // 000000F937AC: BF870004
	v_div_fixup_f32 v10, v13, v10, 1.0                         // 000000F937B0: D627000A 03CA150D
	s_clause 0x3                                               // 000000F937B8: BF850003
	global_store_b32 v[3:4], v2, off                           // 000000F937BC: DC6A0000 007C0203
	global_store_b32 v[5:6], v11, off                          // 000000F937C4: DC6A0000 007C0B05
	global_store_b32 v[7:8], v9, off                           // 000000F937CC: DC6A0000 007C0907
	global_store_b32 v[0:1], v10, off                          // 000000F937D4: DC6A0000 007C0A00
	s_endpgm                                                   // 000000F937DC: BFB00000
		...

