0000000000fab900 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000FAB900: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v15, 15, v0         // 000000FAB908: CA240080 040E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000FAB910: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000FAB914: 86039F02
	v_mov_b32_e32 v16, 0                                       // 000000FAB918: 7E200280
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000FAB91C: 84808402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000FAB920: BF870009
	v_dual_mov_b32 v9, s1 :: v_dual_lshlrev_b32 v2, 2, v15     // 000000FAB924: CA220001 09021E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 000000FAB92C: 30060282
	v_or_b32_e32 v8, s0, v1                                    // 000000FAB930: 38100200
	.long 0x7f183880                                           // 000000FAB934: 7F183880
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v6, 0               // 000000FAB938: CA100080 05060080
	s_waitcnt lgkmcnt(0)                                       // 000000FAB940: BF89FC07
	s_clause 0x1                                               // 000000FAB944: BF850001
	global_load_b32 v7, v2, s[4:5]                             // 000000FAB948: DC520000 07040002
	global_load_b32 v3, v3, s[4:5]                             // 000000FAB950: DC520000 03040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 000000FAB958: 7CA8100C
	s_add_u32 s2, s4, s14                                      // 000000FAB95C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000FAB960: 82030F05
	s_lshr_b32 s0, s11, 31                                     // 000000FAB964: 85009F0B
	v_mov_b32_e32 v27, 0                                       // 000000FAB968: 7E360280
	s_add_u32 s14, s10, s0                                     // 000000FAB96C: 800E000A
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 000000FAB970: 02141080
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 000000FAB974: D501000E 01A80280
	s_addc_u32 s15, s11, 0                                     // 000000FAB97C: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 000000FAB980: 86149F0B
	s_ashr_i64 s[0:1], s[14:15], 1                             // 000000FAB984: 8680810E
	.long 0xd72c000d                                           // 000000FAB988: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 000000FAB98C: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 000000FAB990: D6FE7C01 02021412
	.long 0xd72c0011                                           // 000000FAB998: D72C0011
	v_cndmask_b32_e32 v0, v10, v1, vcc_lo                      // 000000FAB99C: 0200030A
	.long 0xd72c0013                                           // 000000FAB9A0: D72C0013
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 000000FAB9A4: 0200010E
	.long 0xd72c000e                                           // 000000FAB9A8: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 000000FAB9AC: 02021C12
	s_lshr_b32 s14, s20, 27                                    // 000000FAB9B0: 850E9B14
	s_waitcnt vmcnt(1)                                         // 000000FAB9B4: BF8907F7
	v_bfe_u32 v11, v7, 16, 1                                   // 000000FAB9B8: D610000B 02052107
	s_waitcnt vmcnt(0)                                         // 000000FAB9C0: BF8903F7
	v_bfe_u32 v18, v3, 16, 1                                   // 000000FAB9C4: D6100012 02052103
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FAB9CC: BF870002
	v_add3_u32 v7, v7, v11, 0x7fff                             // 000000FAB9D0: D6550007 03FE1707 00007FFF
	v_mad_u64_u32 v[10:11], null, v10, s0, s[2:3]              // 000000FAB9DC: D6FE7C0A 0008010A
	s_add_u32 s2, s10, s14                                     // 000000FAB9E4: 80020E0A
	v_add3_u32 v3, v3, v18, 0x7fff                             // 000000FAB9E8: D6550003 03FE2503 00007FFF
	s_addc_u32 s3, s11, 0                                      // 000000FAB9F4: 8203800B
	.long 0x7e183987                                           // 000000FAB9F8: 7E183987
	s_lshr_b64 s[2:3], s[2:3], 5                               // 000000FAB9FC: 85828502
	v_dual_mov_b32 v7, 0 :: v_dual_lshlrev_b32 v18, 2, v0      // 000000FABA00: CA220080 07120082
	.long 0xd4440000                                           // 000000FABA08: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 000000FABA0C: 02021E02
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FABA10: BF870003
	v_and_or_b32 v3, 0xffff0000, v3, v12                       // 000000FABA14: D6570003 043206FF FFFF0000
	v_add3_u32 v17, v19, v11, v17                              // 000000FABA20: D6550011 04461713
	v_add3_u32 v0, v2, v14, v13                                // 000000FABA28: D6550000 04361D02
	ds_store_b32 v18, v3                                       // 000000FABA30: D8340000 00000312
	s_waitcnt lgkmcnt(0)                                       // 000000FABA38: BF89FC07
	s_barrier                                                  // 000000FABA3C: BFBD0000
	buffer_gl0_inv                                             // 000000FABA40: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000FABA48: BE832000
	s_cbranch_execz 26                                         // 000000FABA4C: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x1b8>
	s_add_u32 s1, s4, s16                                      // 000000FABA50: 80011004
	s_addc_u32 s14, s5, s17                                    // 000000FABA54: 820E1105
	v_lshlrev_b32_e32 v2, 1, v15                               // 000000FABA58: 30041E81
	.long 0xd7000103                                           // 000000FABA5C: D7000103
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 000000FABA60: 02020201
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FABA64: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s14, v0, s1                  // 000000FABA68: D5207C04 0006000E
	v_lshlrev_b32_e32 v5, 4, v15                               // 000000FABA70: 300A1E84
	.long 0xd7000102                                           // 000000FABA74: D7000102
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 000000FABA78: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FABA7C: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s1                    // 000000FABA80: D5207C03 00060880
	.long 0xd7000104                                           // 000000FABA88: D7000104
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 000000FABA8C: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FABA90: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s1                   // 000000FABA94: D5207C05 00062280
	s_clause 0x1                                               // 000000FABA9C: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 000000FABAA0: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 000000FABAA8: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 000000FABAB0: BF8907F7
	v_cvt_f32_f16_e32 v27, v2                                  // 000000FABAB4: 7E361702
	s_or_b32 exec_lo, exec_lo, s3                              // 000000FABAB8: 8C7E037E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 000000FABABC: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 000000FABAC4: CA100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000FABACC: CA100080 16160080
	s_and_saveexec_b32 s3, s0                                  // 000000FABAD4: BE832000
	s_cbranch_execz 597                                        // 000000FABAD8: BFA50255 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xb30>
	s_mul_i32 s0, s11, 6                                       // 000000FABADC: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 000000FABAE0: 9681860A
	v_dual_mov_b32 v25, v15 :: v_dual_lshlrev_b32 v2, 1, v15   // 000000FABAE4: CA22010F 19021E81
	s_add_i32 s18, s1, s0                                      // 000000FABAEC: 81120001
	.long 0xd7000001                                           // 000000FABAF0: D7000001
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 000000FABAF4: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FABAF8: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s0                  // 000000FABAFC: D5207C00 00020011
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 000000FABB04: CA220080 0C0A1E85
	.long 0xd7000001                                           // 000000FABB0C: D7000001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000FABB10: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FABB14: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s0                    // 000000FABB18: D5207C00 00020080
	v_lshl_or_b32 v24, v15, 4, 0x100                           // 000000FABB20: D6560018 03FD090F 00000100
	.long 0xd7000001                                           // 000000FABB2C: D7000001
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000FABB30: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FABB34: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s0                   // 000000FABB38: D5207C00 00020005
	v_dual_mov_b32 v23, v12 :: v_dual_mov_b32 v26, v27         // 000000FABB40: CA10010C 171A011B
	.long 0xd700000d                                           // 000000FABB48: D700000D
	v_cndmask_b32_e32 v0, v1, v160, vcc_lo                     // 000000FABB4C: 02014101
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FABB50: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s0                   // 000000FABB54: D5207C0E 00020080
	v_mov_b32_e32 v22, v12                                     // 000000FABB5C: 7E2C030C
	v_mov_b32_e32 v21, v12                                     // 000000FABB60: 7E2A030C
	v_mov_b32_e32 v20, v12                                     // 000000FABB64: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 000000FABB68: 7E26030C
	v_mov_b32_e32 v18, v12                                     // 000000FABB6C: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 000000FABB70: 7E20030C
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000FABB74: 848E820A
	s_mul_i32 s17, s10, 6                                      // 000000FABB78: 9611860A
	s_mov_b32 s16, 0                                           // 000000FABB7C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000FABB80: 8484810A
	s_branch 528                                               // 000000FABB84: BFA00210 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xac8>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000FABB88: 8C7E0A7E
	v_and_b32_e32 v28, 0xff, v4                                // 000000FABB8C: 363808FF 000000FF
	s_and_b32 s0, exec_lo, s0                                  // 000000FABB94: 8B00007E
	v_add_nc_u32_e32 v24, 0x100, v24                           // 000000FABB98: 4A3030FF 00000100
	s_or_b32 s16, s0, s16                                      // 000000FABBA0: 8C101000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FABBA4: BF8700B2
	v_lshlrev_b32_e32 v28, 2, v28                              // 000000FABBA8: 30383882
	ds_load_b32 v44, v28                                       // 000000FABBAC: D8D80000 2C00001C
	v_lshrrev_b32_e32 v28, 6, v4                               // 000000FABBB4: 32380886
	v_and_b32_e32 v28, 0x3fc, v28                              // 000000FABBB8: 363838FF 000003FC
	ds_load_b32 v45, v28                                       // 000000FABBC0: D8D80000 2D00001C
	v_lshrrev_b32_e32 v28, 14, v4                              // 000000FABBC8: 3238088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000FABBCC: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FABBD0: BF870112
	v_and_b32_e32 v28, 0x3fc, v28                              // 000000FABBD4: 363838FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FABBDC: 360808FF 000003FC
	ds_load_b32 v46, v28                                       // 000000FABBE4: D8D80000 2E00001C
	ds_load_b32 v47, v4                                        // 000000FABBEC: D8D80000 2F000004
	v_and_b32_e32 v4, 0xff, v5                                 // 000000FABBF4: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FABBFC: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000FABC00: 30080882
	ds_load_b32 v48, v4                                        // 000000FABC04: D8D80000 30000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 000000FABC0C: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FABC10: 360808FF 000003FC
	ds_load_b32 v49, v4                                        // 000000FABC18: D8D80000 31000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 000000FABC20: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FABC24: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FABC28: 360808FF 000003FC
	ds_load_b32 v50, v4                                        // 000000FABC30: D8D80000 32000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 000000FABC38: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FABC3C: 360808FF 000003FC
	ds_load_b32 v51, v4                                        // 000000FABC44: D8D80000 33000004
	v_and_b32_e32 v4, 0xff, v6                                 // 000000FABC4C: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FABC54: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000FABC58: 30080882
	ds_load_b32 v52, v4                                        // 000000FABC5C: D8D80000 34000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 000000FABC64: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FABC68: 360808FF 000003FC
	ds_load_b32 v53, v4                                        // 000000FABC70: D8D80000 35000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 000000FABC78: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FABC7C: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FABC80: 360808FF 000003FC
	ds_load_b32 v54, v4                                        // 000000FABC88: D8D80000 36000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 000000FABC90: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FABC94: 360808FF 000003FC
	ds_load_b32 v55, v4                                        // 000000FABC9C: D8D80000 37000004
	v_and_b32_e32 v4, 0xff, v7                                 // 000000FABCA4: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FABCAC: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000FABCB0: 30080882
	ds_load_b32 v56, v4                                        // 000000FABCB4: D8D80000 38000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 000000FABCBC: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FABCC0: 360808FF 000003FC
	ds_load_b32 v57, v4                                        // 000000FABCC8: D8D80000 39000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 000000FABCD0: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FABCD4: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FABCD8: 360808FF 000003FC
	ds_load_b32 v58, v4                                        // 000000FABCE0: D8D80000 3A000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 000000FABCE8: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FABCEC: 360808FF 000003FC
	ds_load_b32 v59, v4                                        // 000000FABCF4: D8D80000 3B000004
	.long 0xd73c0004                                           // 000000FABCFC: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000FABD00: 02021681
	v_add_nc_u32_e32 v11, 0x200, v11                           // 000000FABD04: 4A1616FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FABD0C: BF870092
	.long 0xd7000028                                           // 000000FABD10: D7000028
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000FABD14: 02020806
	v_add_co_ci_u32_e64 v41, null, s7, v5, s0                  // 000000FABD18: D5207C29 00020A07
	s_clause 0x3                                               // 000000FABD20: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 000000FABD24: DC5E0000 047C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 000000FABD2C: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 000000FABD34: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 000000FABD3C: DC5E0030 247C0028
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000FABD44: BF890CF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000FABD48: CC1A4004 1A025904
	s_waitcnt lgkmcnt(14)                                      // 000000FABD50: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FABD54: BF8700A1
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000FABD58: CC1A4004 1C125B05
	s_waitcnt lgkmcnt(13)                                      // 000000FABD60: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000FABD64: CC1A4004 1C125D06
	s_waitcnt lgkmcnt(12)                                      // 000000FABD6C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FABD70: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000FABD74: CC1A4004 1C125F07
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000FABD7C: BF8908B7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000FABD80: CC1A4004 1C12611C
	s_waitcnt lgkmcnt(10)                                      // 000000FABD88: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FABD8C: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FABD90: CC1A4004 1C12631D
	s_waitcnt lgkmcnt(9)                                       // 000000FABD98: BF89FC97
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FABD9C: CC1A4004 1C12651E
	s_waitcnt lgkmcnt(8)                                       // 000000FABDA4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FABDA8: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FABDAC: CC1A4004 1C12671F
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000FABDB4: BF890477
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FABDB8: CC1A4004 1C126920
	s_waitcnt lgkmcnt(6)                                       // 000000FABDC0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FABDC4: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FABDC8: CC1A4004 1C126B21
	s_waitcnt lgkmcnt(5)                                       // 000000FABDD0: BF89FC57
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FABDD4: CC1A4004 1C126D22
	s_waitcnt lgkmcnt(4)                                       // 000000FABDDC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FABDE0: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FABDE4: CC1A4004 1C126F23
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000FABDEC: BF890037
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FABDF0: CC1A4004 1C127124
	.long 0xd7000024                                           // 000000FABDF8: D7000024
	v_cndmask_b32_e32 v0, v40, v4, vcc_lo                      // 000000FABDFC: 02000928
	s_waitcnt lgkmcnt(2)                                       // 000000FABE00: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000FABE04: BF8701C2
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FABE08: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s5, v41, s0                 // 000000FABE10: D5207C25 00025205
	.long 0xd700002a                                           // 000000FABE18: D700002A
	v_cndmask_b32_e32 v0, v40, v14, vcc_lo                     // 000000FABE1C: 02001D28
	s_waitcnt lgkmcnt(1)                                       // 000000FABE20: BF89FC17
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FABE24: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v43, null, s15, v41, s0                // 000000FABE2C: D5207C2B 0002520F
	.long 0xd7000028                                           // 000000FABE34: D7000028
	v_cndmask_b32_e32 v0, v40, v17, vcc_lo                     // 000000FABE38: 02002328
	s_waitcnt lgkmcnt(0)                                       // 000000FABE3C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FABE40: BF870123
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000FABE44: CC1A4004 1C127727
	v_add_co_ci_u32_e64 v41, null, s18, v41, s0                // 000000FABE4C: D5207C29 00025212
	v_fmac_f32_e32 v23, v27, v4                                // 000000FABE54: 562E091B
	s_clause 0x3                                               // 000000FABE58: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 000000FABE5C: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000FABE64: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000FABE6C: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000FABE74: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000FABE7C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000FABE80: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FABE88: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000FABE8C: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000FABE94: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FABE9C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000FABEA0: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000FABEA8: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000FABEAC: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FABEB4: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FABEB8: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FABEC0: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FABEC8: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FABECC: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000FABED4: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FABED8: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FABEE0: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FABEE4: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FABEEC: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FABEF4: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FABEF8: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000FABF00: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FABF04: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FABF0C: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FABF10: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FABF18: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FABF20: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000FABF24: CC1A4004 1C127727
	v_fmac_f32_e32 v22, v27, v4                                // 000000FABF2C: 562C091B
	s_clause 0x3                                               // 000000FABF30: BF850003
	global_load_b128 v[4:7], v[42:43], off                     // 000000FABF34: DC5E0000 047C002A
	global_load_b128 v[28:31], v[42:43], off offset:16         // 000000FABF3C: DC5E0010 1C7C002A
	global_load_b128 v[32:35], v[42:43], off offset:32         // 000000FABF44: DC5E0020 207C002A
	global_load_b128 v[36:39], v[42:43], off offset:48         // 000000FABF4C: DC5E0030 247C002A
	.long 0xd700002a                                           // 000000FABF54: D700002A
	v_cndmask_b32_e32 v0, v42, v14, vcc_lo                     // 000000FABF58: 02001D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FABF5C: BF8700B1
	v_add_co_ci_u32_e64 v43, null, s15, v43, s0                // 000000FABF60: D5207C2B 0002560F
	s_waitcnt vmcnt(3)                                         // 000000FABF68: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000FABF6C: CC1A4004 1A025904
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000FABF74: CC1A4004 1C125B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FABF7C: BF870091
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000FABF80: CC1A4004 1C125D06
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000FABF88: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000FABF90: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FABF94: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000FABF98: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FABFA0: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FABFA8: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FABFAC: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FABFB4: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000FABFBC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FABFC0: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FABFC4: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FABFCC: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FABFD4: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FABFD8: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FABFE0: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000FABFE8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FABFEC: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FABFF0: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FABFF8: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC000: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FAC004: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000FAC00C: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FAC014: BF870001
	v_fmac_f32_e32 v21, v27, v4                                // 000000FAC018: 562A091B
	s_clause 0x3                                               // 000000FAC01C: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 000000FAC020: DC5E0000 047C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 000000FAC028: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 000000FAC030: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 000000FAC038: DC5E0030 247C0028
	s_waitcnt vmcnt(3)                                         // 000000FAC040: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000FAC044: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC04C: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000FAC050: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000FAC058: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAC060: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000FAC064: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000FAC06C: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000FAC070: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC078: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FAC07C: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FAC084: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAC08C: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FAC090: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000FAC098: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FAC09C: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC0A4: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FAC0A8: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FAC0B0: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAC0B8: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FAC0BC: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000FAC0C4: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FAC0C8: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC0D0: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FAC0D4: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FAC0DC: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC0E4: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000FAC0E8: CC1A4004 1C127727
	v_fmac_f32_e32 v20, v27, v4                                // 000000FAC0F0: 5628091B
	s_clause 0x3                                               // 000000FAC0F4: BF850003
	global_load_b128 v[4:7], v[42:43], off                     // 000000FAC0F8: DC5E0000 047C002A
	global_load_b128 v[28:31], v[42:43], off offset:16         // 000000FAC100: DC5E0010 1C7C002A
	global_load_b128 v[32:35], v[42:43], off offset:32         // 000000FAC108: DC5E0020 207C002A
	global_load_b128 v[36:39], v[42:43], off offset:48         // 000000FAC110: DC5E0030 247C002A
	s_waitcnt vmcnt(3)                                         // 000000FAC118: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000FAC11C: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC124: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000FAC128: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000FAC130: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAC138: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000FAC13C: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000FAC144: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000FAC148: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC150: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FAC154: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FAC15C: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAC164: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FAC168: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000FAC170: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FAC174: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC17C: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FAC180: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FAC188: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAC190: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FAC194: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000FAC19C: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FAC1A0: CC1A4004 1C127124
	.long 0xd7000024                                           // 000000FAC1A8: D7000024
	v_cndmask_b32_e32 v0, v40, v14, vcc_lo                     // 000000FAC1AC: 02001D28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FAC1B0: BF870122
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FAC1B4: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s15, v41, s0                // 000000FAC1BC: D5207C25 0002520F
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FAC1C4: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC1CC: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000FAC1D0: CC1A4004 1C127727
	v_fmac_f32_e32 v19, v27, v4                                // 000000FAC1D8: 5626091B
	s_clause 0x3                                               // 000000FAC1DC: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 000000FAC1E0: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000FAC1E8: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000FAC1F0: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000FAC1F8: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000FAC200: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000FAC204: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC20C: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000FAC210: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000FAC218: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAC220: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000FAC224: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000FAC22C: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000FAC230: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC238: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FAC23C: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FAC244: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAC24C: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FAC250: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000FAC258: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FAC25C: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC264: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FAC268: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FAC270: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAC278: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FAC27C: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000FAC284: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FAC288: CC1A4004 1C127124
	.long 0xd7000024                                           // 000000FAC290: D7000024
	v_cndmask_b32_e32 v0, v42, v14, vcc_lo                     // 000000FAC294: 02001D2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000FAC298: BF8701B2
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FAC29C: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s15, v43, s0                // 000000FAC2A4: D5207C25 0002560F
	.long 0xd700000d                                           // 000000FAC2AC: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 000000FAC2B0: 0201410D
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FAC2B4: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 000000FAC2BC: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC2C4: BF870092
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000FAC2C8: CC1A4004 1C127727
	v_fmac_f32_e32 v18, v27, v4                                // 000000FAC2D0: 5624091B
	s_clause 0x3                                               // 000000FAC2D4: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 000000FAC2D8: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000FAC2E0: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000FAC2E8: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000FAC2F0: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000FAC2F8: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000FAC2FC: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FAC304: BF870121
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000FAC308: CC1A4004 1C125B05
	v_mov_b32_e32 v5, v1                                       // 000000FAC310: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000FAC314: CC1A4004 1C125D06
	v_mov_b32_e32 v6, v2                                       // 000000FAC31C: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000FAC320: BF870132
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000FAC324: CC1A4004 1C125F07
	v_mov_b32_e32 v7, v3                                       // 000000FAC32C: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 000000FAC330: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000FAC334: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC33C: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FAC340: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FAC348: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAC350: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FAC354: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000FAC35C: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FAC360: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC368: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FAC36C: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FAC374: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAC37C: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FAC380: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000FAC388: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FAC38C: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC394: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FAC398: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FAC3A0: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC3A8: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000FAC3AC: CC1A4004 1C127727
	v_fmac_f32_e32 v16, v27, v4                                // 000000FAC3B4: 5620091B
	v_dual_mov_b32 v4, v0 :: v_dual_mov_b32 v27, v26           // 000000FAC3B8: CA100100 041A011A
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000FAC3C0: 917E107E
	s_cbranch_execz 25                                         // 000000FAC3C4: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xb2c>
	s_waitcnt vmcnt(0)                                         // 000000FAC3C8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000FAC3CC: BF8701B1
	v_dual_mov_b32 v0, v4 :: v_dual_add_nc_u32 v25, 16, v25    // 000000FAC3D0: CA200104 00183290
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 000000FAC3D8: CA100105 01020106
	v_mov_b32_e32 v3, v7                                       // 000000FAC3E0: 7E060307
	.long 0xd4430000                                           // 000000FAC3E4: D4430000
	v_cndmask_b32_e32 v1, s2, v25, vcc_lo                      // 000000FAC3E8: 02023202
	s_mov_b32 s10, exec_lo                                     // 000000FAC3EC: BE8A007E
	.long 0xd4c4007e                                           // 000000FAC3F0: D4C4007E
	v_cndmask_b32_e32 v1, s2, v25, vcc_lo                      // 000000FAC3F4: 02023202
	s_cbranch_execz 64995                                      // 000000FAC3F8: BFA5FDE3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x288>
	.long 0xd7000100                                           // 000000FAC3FC: D7000100
	v_cndmask_b32_e32 v1, v10, v24, vcc_lo                     // 000000FAC400: 0202310A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FAC404: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s1                   // 000000FAC408: D5207C01 00062280
	global_load_d16_b16 v26, v[13:14], off                     // 000000FAC410: DC820000 1A7C000D
	global_load_b128 v[0:3], v[0:1], off                       // 000000FAC418: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 000000FAC420: BF8907F7
	v_cvt_f32_f16_e32 v26, v26                                 // 000000FAC424: 7E34171A
	s_branch 64983                                             // 000000FAC428: BFA0FDD7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x288>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000FAC42C: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAC430: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000FAC434: 8C7E037E
	.long 0xd71f0000                                           // 000000FAC438: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000FAC43C: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000FAC440: 3A020088
	v_xor_b32_e32 v10, 4, v0                                   // 000000FAC444: 3A140084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC448: BF870092
	.long 0xd44c0000                                           // 000000FAC44C: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000FAC450: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000FAC454: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FAC45C: BF870113
	.long 0xd44c0000                                           // 000000FAC460: D44C0000
	v_cndmask_b32_e32 v1, 32, v10, vcc_lo                      // 000000FAC464: 020214A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000FAC468: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FAC46C: BF870002
	v_cndmask_b32_e64 v10, v0, v10, s0                         // 000000FAC470: D501000A 00021500
	ds_bpermute_b32 v2, v1, v23                                // 000000FAC478: DACC0000 02001701
	s_waitcnt lgkmcnt(0)                                       // 000000FAC480: BF89FC07
	v_add_f32_e32 v2, v23, v2                                  // 000000FAC484: 06040517
	s_waitcnt vmcnt(0)                                         // 000000FAC488: BF8903F7
	ds_bpermute_b32 v6, v1, v19                                // 000000FAC48C: DACC0000 06001301
	ds_bpermute_b32 v7, v1, v18                                // 000000FAC494: DACC0000 07001201
	ds_bpermute_b32 v3, v1, v22                                // 000000FAC49C: DACC0000 03001601
	ds_bpermute_b32 v4, v1, v21                                // 000000FAC4A4: DACC0000 04001501
	ds_bpermute_b32 v5, v1, v20                                // 000000FAC4AC: DACC0000 05001401
	ds_bpermute_b32 v1, v1, v16                                // 000000FAC4B4: DACC0000 01001001
	v_lshlrev_b32_e32 v10, 2, v10                              // 000000FAC4BC: 30141482
	s_waitcnt lgkmcnt(4)                                       // 000000FAC4C0: BF89FC47
	v_dual_add_f32 v6, v19, v6 :: v_dual_add_f32 v7, v18, v7   // 000000FAC4C4: C9080D13 06060F12
	v_xor_b32_e32 v18, 2, v0                                   // 000000FAC4CC: 3A240082
	s_waitcnt lgkmcnt(2)                                       // 000000FAC4D0: BF89FC27
	v_dual_add_f32 v3, v22, v3 :: v_dual_add_f32 v4, v21, v4   // 000000FAC4D4: C9080716 03040915
	s_waitcnt lgkmcnt(1)                                       // 000000FAC4DC: BF89FC17
	v_add_f32_e32 v5, v20, v5                                  // 000000FAC4E0: 060A0B14
	ds_bpermute_b32 v11, v10, v2                               // 000000FAC4E4: DACC0000 0B00020A
	.long 0xd44c0000                                           // 000000FAC4EC: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 000000FAC4F0: 020224A0
	ds_bpermute_b32 v12, v10, v3                               // 000000FAC4F4: DACC0000 0C00030A
	ds_bpermute_b32 v13, v10, v4                               // 000000FAC4FC: DACC0000 0D00040A
	ds_bpermute_b32 v14, v10, v5                               // 000000FAC504: DACC0000 0E00050A
	ds_bpermute_b32 v17, v10, v7                               // 000000FAC50C: DACC0000 1100070A
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 000000FAC514: D5010012 00022500
	s_waitcnt lgkmcnt(5)                                       // 000000FAC51C: BF89FC57
	v_add_f32_e32 v1, v16, v1                                  // 000000FAC520: 06020310
	ds_bpermute_b32 v16, v10, v6                               // 000000FAC524: DACC0000 1000060A
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000FAC52C: 30242482
	ds_bpermute_b32 v10, v10, v1                               // 000000FAC530: DACC0000 0A00010A
	s_waitcnt lgkmcnt(5)                                       // 000000FAC538: BF89FC57
	v_dual_add_f32 v2, v2, v11 :: v_dual_add_f32 v3, v3, v12   // 000000FAC53C: C9081702 02021903
	s_waitcnt lgkmcnt(3)                                       // 000000FAC544: BF89FC37
	v_dual_add_f32 v4, v4, v13 :: v_dual_add_f32 v5, v5, v14   // 000000FAC548: C9081B04 04041D05
	s_waitcnt lgkmcnt(2)                                       // 000000FAC550: BF89FC27
	v_add_f32_e32 v7, v7, v17                                  // 000000FAC554: 060E2307
	ds_bpermute_b32 v11, v18, v3                               // 000000FAC558: DACC0000 0B000312
	s_waitcnt lgkmcnt(2)                                       // 000000FAC560: BF89FC27
	v_add_f32_e32 v6, v6, v16                                  // 000000FAC564: 060C2106
	ds_bpermute_b32 v12, v18, v4                               // 000000FAC568: DACC0000 0C000412
	ds_bpermute_b32 v14, v18, v5                               // 000000FAC570: DACC0000 0E000512
	ds_bpermute_b32 v17, v18, v7                               // 000000FAC578: DACC0000 11000712
	s_waitcnt lgkmcnt(4)                                       // 000000FAC580: BF89FC47
	v_add_f32_e32 v13, v1, v10                                 // 000000FAC584: 061A1501
	ds_bpermute_b32 v1, v18, v2                                // 000000FAC588: DACC0000 01000212
	v_xor_b32_e32 v10, 1, v0                                   // 000000FAC590: 3A140081
	ds_bpermute_b32 v16, v18, v6                               // 000000FAC594: DACC0000 10000612
	.long 0xd44c0000                                           // 000000FAC59C: D44C0000
	v_cndmask_b32_e32 v1, 32, v10, vcc_lo                      // 000000FAC5A0: 020214A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000FAC5A4: BF8701C1
	v_cndmask_b32_e64 v0, v0, v10, s0                          // 000000FAC5A8: D5010000 00021500
	.long 0xd44a0000                                           // 000000FAC5B0: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000FAC5B4: 02021E80
	s_waitcnt lgkmcnt(4)                                       // 000000FAC5B8: BF89FC47
	v_dual_add_f32 v11, v3, v11 :: v_dual_add_f32 v12, v4, v12 // 000000FAC5BC: C9081703 0B0C1904
	v_lshlrev_b32_e32 v19, 2, v0                               // 000000FAC5C4: 30260082
	s_and_b32 s0, s0, vcc_lo                                   // 000000FAC5C8: 8B006A00
	s_waitcnt lgkmcnt(1)                                       // 000000FAC5CC: BF89FC17
	v_add_f32_e32 v10, v2, v1                                  // 000000FAC5D0: 06140302
	ds_bpermute_b32 v18, v18, v13                              // 000000FAC5D4: DACC0000 12000D12
	s_waitcnt lgkmcnt(1)                                       // 000000FAC5DC: BF89FC17
	v_dual_add_f32 v1, v5, v14 :: v_dual_add_f32 v0, v6, v16   // 000000FAC5E0: C9081D05 01002106
	v_add_f32_e32 v2, v7, v17                                  // 000000FAC5E8: 06042307
	ds_bpermute_b32 v14, v19, v11                              // 000000FAC5EC: DACC0000 0E000B13
	ds_bpermute_b32 v16, v19, v12                              // 000000FAC5F4: DACC0000 10000C13
	ds_bpermute_b32 v5, v19, v1                                // 000000FAC5FC: DACC0000 05000113
	ds_bpermute_b32 v4, v19, v0                                // 000000FAC604: DACC0000 04000013
	ds_bpermute_b32 v6, v19, v2                                // 000000FAC60C: DACC0000 06000213
	s_waitcnt lgkmcnt(5)                                       // 000000FAC614: BF89FC57
	v_add_f32_e32 v3, v13, v18                                 // 000000FAC618: 0606250D
	ds_bpermute_b32 v13, v19, v10                              // 000000FAC61C: DACC0000 0D000A13
	ds_bpermute_b32 v7, v19, v3                                // 000000FAC624: DACC0000 07000313
	s_and_saveexec_b32 s1, s0                                  // 000000FAC62C: BE812000
	s_cbranch_execz 240                                        // 000000FAC630: BFA500F0 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x10f4>
	s_waitcnt lgkmcnt(1)                                       // 000000FAC634: BF89FC17
	v_dual_add_f32 v10, v10, v13 :: v_dual_add_f32 v11, v11, v14// 000000FAC638: C9081B0A 0A0A1D0B
	v_add_f32_e32 v12, v12, v16                                // 000000FAC640: 0618210C
	s_lshl_b64 s[2:3], s[12:13], 2                             // 000000FAC644: 8482820C
	s_lshl_b64 s[4:5], s[12:13], 3                             // 000000FAC648: 8484830C
	s_waitcnt lgkmcnt(0)                                       // 000000FAC64C: BF89FC07
	v_dual_mul_f32 v10, 0xbfb8aa3b, v10 :: v_dual_add_f32 v3, v3, v7// 000000FAC650: C8C814FF 0A020F03 BFB8AA3B
	v_dual_mul_f32 v11, 0xbfb8aa3b, v11 :: v_dual_mul_f32 v12, 0xbfb8aa3b, v12// 000000FAC65C: C8C616FF 0B0C18FF BFB8AA3B
	v_add_f32_e32 v5, v1, v5                                   // 000000FAC668: 060A0B01
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FAC66C: BF8701A3
	v_exp_f32_e32 v10, v10                                     // 000000FAC670: 7E144B0A
	v_add_f32_e32 v2, v2, v6                                   // 000000FAC674: 06040D02
	v_exp_f32_e32 v11, v11                                     // 000000FAC678: 7E164B0B
	v_exp_f32_e32 v12, v12                                     // 000000FAC67C: 7E184B0C
	v_dual_mul_f32 v5, 0xbfb8aa3b, v5 :: v_dual_add_f32 v4, v0, v4// 000000FAC680: C8C80AFF 05040900 BFB8AA3B
	.long 0xd73c0000                                           // 000000FAC68C: D73C0000
	v_cndmask_b32_e32 v1, 2, v8, vcc_lo                        // 000000FAC690: 02021082
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 000000FAC694: 100606FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 000000FAC69C: BF870393
	v_exp_f32_e32 v5, v5                                       // 000000FAC6A0: 7E0A4B05
	v_dual_add_f32 v6, 1.0, v10 :: v_dual_add_f32 v7, 1.0, v11 // 000000FAC6A4: C90814F2 060616F2
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000FAC6AC: BF870216
	v_add_f32_e32 v8, 1.0, v12                                 // 000000FAC6B0: 061018F2
	.long 0xd7006a00                                           // 000000FAC6B4: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000FAC6B8: 02020008
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000FAC6BC: BF870213
	v_div_scale_f32 v9, null, v6, v6, 1.0                      // 000000FAC6C0: D6FC7C09 03CA0D06
	v_div_scale_f32 v10, null, v7, v7, 1.0                     // 000000FAC6C8: D6FC7C0A 03CA0F07
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000FAC6D0: D5207C01 01AA0209
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000FAC6D8: BF870005
	v_add_f32_e32 v5, 1.0, v5                                  // 000000FAC6DC: 060A0AF2
	v_div_scale_f32 v11, null, v8, v8, 1.0                     // 000000FAC6E0: D6FC7C0B 03CA1108
	v_rcp_f32_e32 v12, v9                                      // 000000FAC6E8: 7E185509
	v_rcp_f32_e32 v13, v10                                     // 000000FAC6EC: 7E1A550A
	v_div_scale_f32 v17, vcc_lo, 1.0, v6, 1.0                  // 000000FAC6F0: D6FC6A11 03CA0CF2
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 000000FAC6F8: 100404FF BFB8AA3B
	v_rcp_f32_e32 v14, v11                                     // 000000FAC700: 7E1C550B
	v_exp_f32_e32 v16, v3                                      // 000000FAC704: 7E204B03
	v_div_scale_f32 v18, s0, 1.0, v7, 1.0                      // 000000FAC708: D6FC0012 03CA0EF2
	v_div_scale_f32 v21, null, v5, v5, 1.0                     // 000000FAC710: D6FC7C15 03CA0B05
	v_exp_f32_e32 v15, v2                                      // 000000FAC718: 7E1E4B02
	v_div_scale_f32 v20, s1, 1.0, v8, 1.0                      // 000000FAC71C: D6FC0114 03CA10F2
	v_fma_f32 v2, -v9, v12, 1.0                                // 000000FAC724: D6130002 23CA1909
	v_fma_f32 v3, -v10, v13, 1.0                               // 000000FAC72C: D6130003 23CA1B0A
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 000000FAC734: 100808FF BFB8AA3B
	v_rcp_f32_e32 v24, v21                                     // 000000FAC73C: 7E305515
	v_fma_f32 v19, -v11, v14, 1.0                              // 000000FAC740: D6130013 23CA1D0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FAC748: BF870193
	v_dual_fmac_f32 v12, v2, v12 :: v_dual_fmac_f32 v13, v3, v13// 000000FAC74C: C8001902 0C0C1B03
	v_exp_f32_e32 v4, v4                                       // 000000FAC754: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_3) | instid1(VALU_DEP_2)   // 000000FAC758: BF870107
	v_dual_add_f32 v15, 1.0, v15 :: v_dual_fmac_f32 v14, v19, v14// 000000FAC75C: C9001EF2 0F0E1D13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAC764: BF8700A2
	v_mul_f32_e32 v19, v17, v12                                // 000000FAC768: 10261911
	.long 0xd7000202                                           // 000000FAC76C: D7000202
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 000000FAC770: 02000500
	v_add_co_ci_u32_e64 v3, null, s3, v1, s2                   // 000000FAC774: D5207C03 000A0203
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000FAC77C: BF870293
	v_fma_f32 v25, -v9, v19, v17                               // 000000FAC780: D6130019 24462709
	v_dual_mul_f32 v22, v18, v13 :: v_dual_add_f32 v23, 1.0, v4// 000000FAC788: C8C81B12 161608F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FAC790: BF870112
	v_fmac_f32_e32 v19, v25, v12                               // 000000FAC794: 56261919
	v_fma_f32 v26, -v10, v22, v18                              // 000000FAC798: D613001A 244A2D0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FAC7A0: BF870193
	v_div_scale_f32 v25, null, v23, v23, 1.0                   // 000000FAC7A4: D6FC7C19 03CA2F17
	v_fma_f32 v9, -v9, v19, v17                                // 000000FAC7AC: D6130009 24462709
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000FAC7B4: BF870233
	v_fmac_f32_e32 v22, v26, v13                               // 000000FAC7B8: 562C1B1A
	v_fma_f32 v26, -v21, v24, 1.0                              // 000000FAC7BC: D613001A 23CA3115
	v_div_scale_f32 v17, s2, 1.0, v5, 1.0                      // 000000FAC7C4: D6FC0211 03CA0AF2
	v_div_fmas_f32 v9, v9, v12, v19                            // 000000FAC7CC: D6370009 044E1909
	s_delay_alu instid0(VALU_DEP_4)                            // 000000FAC7D4: BF870004
	v_fma_f32 v10, -v10, v22, v18                              // 000000FAC7D8: D613000A 244A2D0A
	v_rcp_f32_e32 v18, v25                                     // 000000FAC7E0: 7E245519
	s_mov_b32 vcc_lo, s0                                       // 000000FAC7E4: BEEA0000
	v_div_scale_f32 v12, null, v15, v15, 1.0                   // 000000FAC7E8: D6FC7C0C 03CA1F0F
	v_div_fixup_f32 v6, v9, v6, 1.0                            // 000000FAC7F0: D6270006 03CA0D09
	v_div_fmas_f32 v10, v10, v13, v22                          // 000000FAC7F8: D637000A 045A1B0A
	s_mov_b32 vcc_lo, s1                                       // 000000FAC800: BEEA0001
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FAC804: BF870003
	v_rcp_f32_e32 v9, v12                                      // 000000FAC808: 7E12550C
	global_store_b32 v[0:1], v6, off                           // 000000FAC80C: DC6A0000 007C0600
	v_div_fixup_f32 v7, v10, v7, 1.0                           // 000000FAC814: D6270007 03CA0F0A
	v_fma_f32 v6, -v25, v18, 1.0                               // 000000FAC81C: D6130006 23CA2519
	global_store_b32 v[2:3], v7, off                           // 000000FAC824: DC6A0000 007C0702
	v_fmac_f32_e32 v18, v6, v18                                // 000000FAC82C: 56242506
	v_div_scale_f32 v6, s0, 1.0, v23, 1.0                      // 000000FAC830: D6FC0006 03CA2EF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC838: BF870091
	v_dual_add_f32 v16, 1.0, v16 :: v_dual_mul_f32 v7, v6, v18 // 000000FAC83C: C90620F2 10062506
	v_div_scale_f32 v10, null, v16, v16, 1.0                   // 000000FAC844: D6FC7C0A 03CA2110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000FAC84C: BF870291
	v_rcp_f32_e32 v13, v10                                     // 000000FAC850: 7E1A550A
	v_fma_f32 v3, -v10, v13, 1.0                               // 000000FAC854: D6130003 23CA1B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAC85C: BF8700A1
	v_dual_fmac_f32 v24, v26, v24 :: v_dual_fmac_f32 v13, v3, v13// 000000FAC860: C800311A 180C1B03
	v_mul_f32_e32 v4, v20, v14                                 // 000000FAC868: 10081D14
	v_fma_f32 v27, -v11, v4, v20                               // 000000FAC86C: D613001B 2452090B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAC874: BF870091
	v_fmac_f32_e32 v4, v27, v14                                // 000000FAC878: 56081D1B
	v_fma_f32 v11, -v11, v4, v20                               // 000000FAC87C: D613000B 2452090B
	v_div_scale_f32 v20, s3, 1.0, v16, 1.0                     // 000000FAC884: D6FC0314 03CA20F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000FAC88C: BF870242
	v_div_fmas_f32 v4, v11, v14, v4                            // 000000FAC890: D6370004 04121D0B
	v_mul_f32_e32 v11, v17, v24                                // 000000FAC898: 10163111
	v_fma_f32 v14, -v12, v9, 1.0                               // 000000FAC89C: D613000E 23CA130C
	.long 0xd7006a03                                           // 000000FAC8A4: D7006A03
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000FAC8A8: 02000900
	v_div_fixup_f32 v19, v4, v8, 1.0                           // 000000FAC8AC: D6270013 03CA1104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000FAC8B4: BF870214
	v_fma_f32 v2, -v21, v11, v17                               // 000000FAC8B8: D6130002 24461715
	v_fmac_f32_e32 v9, v14, v9                                 // 000000FAC8C0: 5612130E
	v_div_scale_f32 v8, s1, 1.0, v15, 1.0                      // 000000FAC8C4: D6FC0108 03CA1EF2
	v_add_co_ci_u32_e64 v4, null, s5, v1, vcc_lo               // 000000FAC8CC: D5207C04 01AA0205
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000FAC8D4: BF870224
	v_fmac_f32_e32 v11, v2, v24                                // 000000FAC8D8: 56163102
	v_fma_f32 v2, -v25, v7, v6                                 // 000000FAC8DC: D6130002 241A0F19
	v_mul_f32_e32 v14, v8, v9                                  // 000000FAC8E4: 101C1308
	v_mad_u64_u32 v[0:1], null, s12, 12, v[0:1]                // 000000FAC8E8: D6FE7C00 0401180C
	s_mov_b32 vcc_lo, s2                                       // 000000FAC8F0: BEEA0002
	v_fma_f32 v17, -v21, v11, v17                              // 000000FAC8F4: D6130011 24461715
	v_mul_f32_e32 v21, v20, v13                                // 000000FAC8FC: 102A1B14
	v_fmac_f32_e32 v7, v2, v18                                 // 000000FAC900: 560E2502
	v_fma_f32 v2, -v12, v14, v8                                // 000000FAC904: D6130002 24221D0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000FAC90C: BF870214
	v_div_fmas_f32 v11, v17, v24, v11                          // 000000FAC910: D637000B 042E3111
	v_fma_f32 v17, -v10, v21, v20                              // 000000FAC918: D6130011 24522B0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000FAC920: BF870214
	v_fma_f32 v6, -v25, v7, v6                                 // 000000FAC924: D6130006 241A0F19
	v_fmac_f32_e32 v14, v2, v9                                 // 000000FAC92C: 561C1302
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 000000FAC930: D6FE7C01 0405180D
	s_mov_b32 vcc_lo, s0                                       // 000000FAC938: BEEA0000
	v_fmac_f32_e32 v21, v17, v13                               // 000000FAC93C: 562A1B11
	v_div_fmas_f32 v6, v6, v18, v7                             // 000000FAC940: D6370006 041E2506
	v_fma_f32 v2, -v12, v14, v8                                // 000000FAC948: D6130002 24221D0C
	s_mov_b32 vcc_lo, s1                                       // 000000FAC950: BEEA0001
	v_div_fixup_f32 v11, v11, v5, 1.0                          // 000000FAC954: D627000B 03CA0B0B
	v_fma_f32 v7, -v10, v21, v20                               // 000000FAC95C: D6130007 24522B0A
	v_div_fixup_f32 v12, v6, v23, 1.0                          // 000000FAC964: D627000C 03CA2F06
	v_div_fmas_f32 v2, v2, v9, v14                             // 000000FAC96C: D6370002 043A1302
	.long 0xd7006a05                                           // 000000FAC974: D7006A05
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 000000FAC978: 02000903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000FAC97C: BF8700D1
	v_add_co_ci_u32_e64 v6, null, s5, v4, vcc_lo               // 000000FAC980: D5207C06 01AA0805
	s_mov_b32 vcc_lo, s3                                       // 000000FAC988: BEEA0003
	v_div_fixup_f32 v2, v2, v15, 1.0                           // 000000FAC98C: D6270002 03CA1F02
	v_div_fmas_f32 v9, v7, v13, v21                            // 000000FAC994: D6370009 04561B07
	.long 0xd7006a07                                           // 000000FAC99C: D7006A07
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000FAC9A0: 02000900
	v_add_co_ci_u32_e64 v8, null, s5, v1, vcc_lo               // 000000FAC9A4: D5207C08 01AA0205
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAC9AC: BF8700A3
	v_div_fixup_f32 v13, v9, v16, 1.0                          // 000000FAC9B0: D627000D 03CA2109
	.long 0xd7006a09                                           // 000000FAC9B8: D7006A09
	v_cndmask_b32_e32 v0, v5, v4, vcc_lo                       // 000000FAC9BC: 02000905
	v_add_co_ci_u32_e64 v10, null, s5, v6, vcc_lo              // 000000FAC9C0: D5207C0A 01AA0C05
	s_clause 0x4                                               // 000000FAC9C8: BF850004
	global_store_b32 v[3:4], v19, off                          // 000000FAC9CC: DC6A0000 007C1303
	global_store_b32 v[0:1], v11, off                          // 000000FAC9D4: DC6A0000 007C0B00
	global_store_b32 v[5:6], v12, off                          // 000000FAC9DC: DC6A0000 007C0C05
	global_store_b32 v[7:8], v2, off                           // 000000FAC9E4: DC6A0000 007C0207
	global_store_b32 v[9:10], v13, off                         // 000000FAC9EC: DC6A0000 007C0D09
	s_endpgm                                                   // 000000FAC9F4: BFB00000
		...

