0000000000a3ff00 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi():
	s_clause 0x1                                               // 000000A3FF00: BF850001
	s_load_b32 s3, s[0:1], 0x88                                // 000000A3FF04: F40000C0 F8000088
	s_load_b512 s[12:27], s[0:1], null                         // 000000A3FF0C: F4100300 F8000000
	v_and_b32_e32 v25, 31, v0                                  // 000000A3FF14: 3632009F
	v_lshrrev_b32_e32 v24, 5, v0                               // 000000A3FF18: 32300085
	s_mov_b32 s4, -1                                           // 000000A3FF1C: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 000000A3FF20: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 000000A3FF24: BF040302
	s_cbranch_scc1 2674                                        // 000000A3FF28: BFA20A72 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x29f4>
	s_load_b64 s[8:9], s[0:1], 0x7c                            // 000000A3FF2C: F4040200 F800007C
	s_sub_i32 s28, s2, s3                                      // 000000A3FF34: 819C0302
	s_clause 0x1                                               // 000000A3FF38: BF850001
	s_load_b256 s[44:51], s[0:1], 0x60                         // 000000A3FF3C: F40C0B00 F8000060
	s_load_b256 s[36:43], s[0:1], 0x40                         // 000000A3FF44: F40C0900 F8000040
	s_mov_b32 s34, 0                                           // 000000A3FF4C: BEA20080
	s_mov_b32 s33, exec_lo                                     // 000000A3FF50: BEA1007E
	s_waitcnt lgkmcnt(0)                                       // 000000A3FF54: BF89FC07
	s_abs_i32 s4, s9                                           // 000000A3FF58: BE841509
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 000000A3FF5C: BF870529
	s_cvt_f32_u32 s5, s4                                       // 000000A3FF60: BE856504
	s_sub_i32 s6, 0, s4                                        // 000000A3FF64: 81860480
	v_rcp_iflag_f32_e32 v1, s5                                 // 000000A3FF68: 7E025605
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_3)// 000000A3FF6C: BF8705A5
	v_readfirstlane_b32 s5, v1                                 // 000000A3FF70: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 000000A3FF74: A205FF05 4F7FFFFE
	s_cvt_u32_f32 s5, s5                                       // 000000A3FF7C: BE856705
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A3FF80: BF87049B
	s_mul_i32 s6, s6, s5                                       // 000000A3FF84: 96060506
	s_mul_hi_u32 s6, s5, s6                                    // 000000A3FF88: 96860605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000A3FF8C: BF8704B9
	s_add_i32 s5, s5, s6                                       // 000000A3FF90: 81050605
	s_ashr_i32 s6, s9, 31                                      // 000000A3FF94: 86069F09
	s_mul_hi_u32 s3, s28, s5                                   // 000000A3FF98: 9683051C
	s_mul_i32 s5, s3, s4                                       // 000000A3FF9C: 96050403
	s_add_i32 s7, s3, 1                                        // 000000A3FFA0: 81078103
	s_sub_i32 s5, s28, s5                                      // 000000A3FFA4: 8185051C
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A3FFA8: BF870009
	s_sub_i32 s10, s5, s4                                      // 000000A3FFAC: 818A0405
	s_cmp_ge_u32 s5, s4                                        // 000000A3FFB0: BF090405
	s_cselect_b32 s3, s7, s3                                   // 000000A3FFB4: 98030307
	s_cselect_b32 s5, s10, s5                                  // 000000A3FFB8: 9805050A
	s_add_i32 s7, s3, 1                                        // 000000A3FFBC: 81078103
	s_cmp_ge_u32 s5, s4                                        // 000000A3FFC0: BF090405
	s_cselect_b32 s3, s7, s3                                   // 000000A3FFC4: 98030307
	s_ashr_i32 s11, s50, 31                                    // 000000A3FFC8: 860B9F32
	s_xor_b32 s3, s3, s6                                       // 000000A3FFCC: 8D030603
	s_lshr_b32 s0, s11, 25                                     // 000000A3FFD0: 8500990B
	s_sub_i32 s10, s3, s6                                      // 000000A3FFD4: 818A0603
	s_add_i32 s0, s50, s0                                      // 000000A3FFD8: 81000032
	s_mul_i32 s30, s10, s9                                     // 000000A3FFDC: 961E090A
	s_ashr_i32 s0, s0, 7                                       // 000000A3FFE0: 86008700
	s_sub_i32 s29, s28, s30                                    // 000000A3FFE4: 819D1E1C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A3FFE8: BF870499
	s_mul_i32 s29, s29, s8                                     // 000000A3FFEC: 961D081D
	s_add_i32 s1, s29, s8                                      // 000000A3FFF0: 8101081D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A3FFF4: BF870499
	s_min_i32 s0, s0, s1                                       // 000000A3FFF8: 89000100
	s_sub_i32 s35, s0, s29                                     // 000000A3FFFC: 81A31D00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A40000: BF870499
	s_lshl_b32 s31, s35, 2                                     // 000000A40004: 841F8223
	.long 0xd4c4007e                                           // 000000A40008: D4C4007E
	v_cndmask_b32_e32 v1, s31, v24, vcc_lo                     // 000000A4000C: 0202301F
	s_cbranch_execz 503                                        // 000000A40010: BFA501F7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8f0>
	s_add_i32 s51, s48, -1                                     // 000000A40014: 8133C130
	s_cmp_lg_u64 s[40:41], 0                                   // 000000A40018: BF118028
	v_dual_mov_b32 v8, v24 :: v_dual_and_b32 v1, 1, v0         // 000000A4001C: CA240118 08000081
	s_cselect_b32 s52, -1, 0                                   // 000000A40024: 983480C1
	s_abs_i32 s53, s35                                         // 000000A40028: BEB51523
	v_and_b32_e32 v2, 2, v0                                    // 000000A4002C: 36040082
	s_cvt_f32_u32 s0, s53                                      // 000000A40030: BE806535
	v_lshlrev_b32_e32 v6, 3, v25                               // 000000A40034: 300C3283
	v_lshlrev_b32_e32 v7, 7, v24                               // 000000A40038: 300E3087
	v_and_b32_e32 v3, 4, v0                                    // 000000A4003C: 36060084
	v_rcp_iflag_f32_e32 v4, s0                                 // 000000A40040: 7E085600
	v_and_b32_e32 v5, 8, v0                                    // 000000A40044: 360A0088
	.long 0xd44a0001                                           // 000000A40048: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000A4004C: 02020280
	.long 0xd44a0003                                           // 000000A40050: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000A40054: 02020480
	v_lshl_or_b32 v1, v24, 8, v6                               // 000000A40058: D6560001 04191118
	v_lshl_add_u32 v2, s29, 7, v7                              // 000000A40060: D6460002 041D0E1D
	s_ashr_i32 s55, s35, 31                                    // 000000A40068: 86379F23
	s_sub_i32 s57, 0, s53                                      // 000000A4006C: 81B93580
	s_mul_i32 s8, s55, 0x1400                                  // 000000A40070: 9608FF37 00001400
	.long 0xd44c0000                                           // 000000A40078: D44C0000
	v_cndmask_b32_e32 v1, 16, v25, vcc_lo                      // 000000A4007C: 02023290
	v_readfirstlane_b32 s5, v4                                 // 000000A40080: 7E0A0504
	.long 0xd44a0004                                           // 000000A40084: D44A0004
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000A40088: 02020680
	v_subrev_nc_u32_e32 v9, s8, v1                             // 000000A4008C: 4E120208
	v_lshl_or_b32 v1, v25, 2, v2                               // 000000A40090: D6560001 04090519
	s_lshl_b32 s6, s35, 7                                      // 000000A40098: 84068723
	s_mul_f32 s7, s5, 0x4f7ffffe                               // 000000A4009C: A207FF05 4F7FFFFE
	.long 0xd44a0005                                           // 000000A400A4: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000A400A8: 02020A80
	s_mov_b32 s54, 0x76543210                                  // 000000A400AC: BEB600FF 76543210
	s_lshl_b32 s56, s35, 8                                     // 000000A400B4: 84388823
	s_cvt_u32_f32 s7, s7                                       // 000000A400B8: BE876707
	s_mov_b32 s59, 0x3db504f3                                  // 000000A400BC: BEBB00FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A400C4: BF87049A
	s_mul_i32 s57, s57, s7                                     // 000000A400C8: 96390739
	s_mul_hi_u32 s8, s7, s57                                   // 000000A400CC: 96883907
	s_sub_i32 s57, 0, s6                                       // 000000A400D0: 81B90680
	s_add_i32 s58, s7, s8                                      // 000000A400D4: 813A0807
	s_branch 164                                               // 000000A400D8: BFA000A4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x46c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A400DC: BF870091
	.long 0xd7006a02                                           // 000000A400E0: D7006A02
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000A400E4: 0202041A
	v_add_co_ci_u32_e64 v3, null, s27, v3, vcc_lo              // 000000A400E8: D5207C03 01AA061B
	v_sub_f32_e32 v4, v15, v13                                 // 000000A400F0: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000A400F4: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000A400FC: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000A40104: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 000000A40108: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 000000A40110: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 000000A40118: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A4011C: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000A40120: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000A40124: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000A40128: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000A4012C: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A40130: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A40134: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A4013C: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A40144: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000A4014C: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A40154: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 000000A40158: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A4015C: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000A40164: D5010007 20060F07
	.long 0xd72c0006                                           // 000000A4016C: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 000000A40170: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 000000A40178: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A4017C: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000A40184: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A4018C: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 000000A40190: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A40194: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000A4019C: D5010003 20060703
	.long 0xd72c0007                                           // 000000A401A4: D72C0007
	v_cndmask_b32_e32 v1, s56, v10, vcc_lo                     // 000000A401A8: 02021438
	v_add_f32_e32 v2, v2, v13                                  // 000000A401AC: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A401B0: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000A401B8: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 000000A401C0: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A401C4: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A401C8: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000A401D0: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 000000A401D8: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A401DC: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000A401E4: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A401EC: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000A401F4: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 000000A401FC: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A40200: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 000000A40208: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000A4020C: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 000000A40214: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A40218: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000A40220: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A40228: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000A40230: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A40238: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000A40240: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 000000A40248: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000A4024C: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 000000A40250: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A40254: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 000000A40258: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A4025C: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000A40264: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A4026C: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A40270: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000A40278: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000A40280: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A40284: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000A4028C: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 000000A40294: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 000000A4029C: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s31, v8                           // 000000A402A0: 7C86101F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A402A4: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 000000A402A8: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 000000A402B0: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A402B8: BF870234
	v_mov_b32_e32 v13, v2                                      // 000000A402BC: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000A402C0: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000A402C8: D5010004 20020904
	v_permlanex16_b32 v11, v11, s54, 0xfedcba98                // 000000A402D0: D65C000B 03FC6D0B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 000000A402DC: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000A402E0: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000A402E8: D5010003 20020703
	v_permlanex16_b32 v10, v10, s54, 0xfedcba98                // 000000A402F0: D65C000A 03FC6D0A FEDCBA98
	v_permlanex16_b32 v13, v13, s54, 0xfedcba98                // 000000A402FC: D65C000D 03FC6D0D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 000000A40308: 060A1705
	v_permlanex16_b32 v12, v12, s54, 0xfedcba98                // 000000A4030C: D65C000C 03FC6D0C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A40318: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 000000A4031C: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 000000A40328: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A4032C: BF870214
	v_fma_mixhi_f16 v2, v5, s59, 0                             // 000000A40330: CC220002 02007705
	v_add_f32_e32 v10, v3, v12                                 // 000000A40338: 06141903
	s_or_b32 s34, vcc_lo, s34                                  // 000000A4033C: 8C22226A
	v_fma_mixlo_f16 v2, v4, s59, 0                             // 000000A40340: CC210002 02007704
	v_fma_mixhi_f16 v3, v7, s59, 0                             // 000000A40348: CC220003 02007707
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A40350: BF870003
	v_fma_mixlo_f16 v3, v10, s59, 0                            // 000000A40354: CC210003 0200770A
	ds_store_b64 v6, v[2:3] offset:22016                       // 000000A4035C: D9345600 00000206
	s_and_not1_b32 exec_lo, exec_lo, s34                       // 000000A40364: 917E227E
	s_cbranch_execz 289                                        // 000000A40368: BFA50121 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8f0>
	.long 0xd72d0002                                           // 000000A4036C: D72D0002
	v_cndmask_b32_e32 v0, v8, v58, vcc_lo                      // 000000A40370: 02007508
	s_mov_b32 s6, -1                                           // 000000A40374: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A40378: BF870091
	.long 0xd72c0003                                           // 000000A4037C: D72C0003
	v_cndmask_b32_e32 v0, v2, v53, vcc_lo                      // 000000A40380: 02006B02
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000A40384: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A40388: BF870121
	v_subrev_nc_u32_e32 v5, s53, v3                            // 000000A4038C: 4E0A0635
	v_cmp_le_u32_e32 vcc_lo, s53, v3                           // 000000A40390: 7C960635
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000A40394: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A4039C: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000A403A0: 02040902
	v_cmp_le_u32_e32 vcc_lo, s53, v3                           // 000000A403A4: 7C960635
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A403A8: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000A403AC: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000A403B0: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s52                        // 000000A403B4: 916A347E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A403B8: BF870091
	v_xor_b32_e32 v11, s55, v2                                 // 000000A403BC: 3A160437
	v_subrev_nc_u32_e32 v10, s55, v11                          // 000000A403C0: 4E141637
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A403C4: BF8700A1
	v_mad_u64_u32 v[6:7], null, s57, v10, v[1:2]               // 000000A403C8: D6FE7C06 04061439
	v_min_i32_e32 v2, s51, v10                                 // 000000A403D0: 22041433
	v_mad_i64_i32 v[4:5], null, v2, s50, 0                     // 000000A403D4: D6FF7C04 02006502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A403DC: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000A403E0: 340E0C9F
	.long 0xd73c0002                                           // 000000A403E4: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000A403E8: 02020C81
	s_cbranch_vccnz 212                                        // 000000A403EC: BFA400D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x840>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A403F0: BF870093
	.long 0xd7006a06                                           // 000000A403F4: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000A403F8: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000A403FC: D5207C07 01AA0F05
	.long 0x7f3c3880                                           // 000000A40404: 7F3C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A40408: BF870112
	.long 0xd73c0006                                           // 000000A4040C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000A40410: 02020C81
	.long 0x7f42399e                                           // 000000A40414: 7F42399E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A40418: BF870092
	.long 0xd7006a0c                                           // 000000A4041C: D7006A0C
	v_cndmask_b32_e32 v1, s38, v6, vcc_lo                      // 000000A40420: 02020C26
	v_add_co_ci_u32_e64 v13, null, s39, v7, vcc_lo             // 000000A40424: D5207C0D 01AA0E27
	.long 0xd7006a06                                           // 000000A4042C: D7006A06
	v_cndmask_b32_e32 v1, s40, v6, vcc_lo                      // 000000A40430: 02020C28
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A40434: BF870001
	v_add_co_ci_u32_e64 v7, null, s41, v7, vcc_lo              // 000000A40438: D5207C07 01AA0E29
	global_load_b64 v[12:13], v[12:13], off                    // 000000A40440: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 000000A40448: D7006A0E
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000A4044C: 0202041A
	global_load_b64 v[6:7], v[6:7], off                        // 000000A40450: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s27, v3, vcc_lo             // 000000A40458: D5207C0F 01AA061B
	s_clause 0x1                                               // 000000A40460: BF850001
	global_load_b32 v16, v[14:15], off                         // 000000A40464: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 000000A4046C: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 000000A40474: BF890FF7
	.long 0x7e1e390c                                           // 000000A40478: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 000000A4047C: BF890BF7
	v_and_b32_e32 v40, 0xffff0000, v6                          // 000000A40480: 36500CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000A40488: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A4048C: BF870093
	v_lshlrev_b32_e32 v15, 16, v15                             // 000000A40490: 301E1E90
	v_mul_f32_e32 v19, 0xbfb8aa3b, v15                         // 000000A40494: 10261EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000A4049C: BF870291
	v_exp_f32_e32 v19, v19                                     // 000000A404A0: 7E264B13
	v_dual_add_f32 v19, 1.0, v19 :: v_dual_and_b32 v12, 0xffff0000, v12// 000000A404A4: C92426F2 130C18FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A404B0: BF870111
	v_mul_f32_e32 v18, 0xbfb8aa3b, v12                         // 000000A404B4: 102418FF BFB8AA3B
	v_div_scale_f32 v23, null, v19, v19, v15                   // 000000A404BC: D6FC7C17 043E2713
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A404C4: BF8701B2
	v_exp_f32_e32 v18, v18                                     // 000000A404C8: 7E244B12
	v_lshlrev_b32_e32 v17, 16, v13                             // 000000A404CC: 30221A90
	v_div_scale_f32 v38, s7, v15, v19, v15                     // 000000A404D0: D6FC0726 043E270F
	v_rcp_f32_e32 v29, v23                                     // 000000A404D8: 7E3A5517
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A404DC: BF870196
	v_add_f32_e32 v18, 1.0, v18                                // 000000A404E0: 062424F2
	v_mul_f32_e32 v20, 0xbfb8aa3b, v17                         // 000000A404E4: 102822FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A404EC: BF870195
	v_fma_f32 v37, -v23, v29, 1.0                              // 000000A404F0: D6130025 23CA3B17
	v_div_scale_f32 v22, null, v18, v18, v12                   // 000000A404F8: D6FC7C16 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A40500: BF8701B3
	v_exp_f32_e32 v20, v20                                     // 000000A40504: 7E284B14
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000A40508: 361A1AFF FFFF0000
	v_div_scale_f32 v34, vcc_lo, v12, v18, v12                 // 000000A40510: D6FC6A22 0432250C
	v_rcp_f32_e32 v27, v22                                     // 000000A40518: 7E365516
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 000000A4051C: BF870106
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_mul_f32 v21, 0xbfb8aa3b, v13// 000000A40520: C90628F2 14141AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A4052C: BF870115
	v_fma_f32 v35, -v22, v27, 1.0                              // 000000A40530: D6130023 23CA3716
	v_div_scale_f32 v26, null, v20, v20, v17                   // 000000A40538: D6FC7C1A 04462914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A40540: BF8701A3
	v_exp_f32_e32 v21, v21                                     // 000000A40544: 7E2A4B15
	v_div_scale_f32 v36, s6, v17, v20, v17                     // 000000A40548: D6FC0624 04462911
	v_fmac_f32_e32 v27, v35, v27                               // 000000A40550: 56363723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000A40554: BF870313
	v_rcp_f32_e32 v31, v26                                     // 000000A40558: 7E3E551A
	v_add_f32_e32 v21, 1.0, v21                                // 000000A4055C: 062A2AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A40560: BF870115
	v_fma_f32 v39, -v26, v31, 1.0                              // 000000A40564: D6130027 23CA3F1A
	v_div_scale_f32 v28, null, v21, v21, v13                   // 000000A4056C: D6FC7C1C 04362B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A40574: BF8701A2
	v_fmac_f32_e32 v31, v39, v31                               // 000000A40578: 563E3F27
	v_mul_f32_e32 v39, v34, v27                                // 000000A4057C: 104E3722
	v_rcp_f32_e32 v32, v28                                     // 000000A40580: 7E40551C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A40584: BF870112
	v_mul_f32_e32 v41, v36, v31                                // 000000A40588: 10523F24
	v_fma_f32 v42, -v22, v39, v34                              // 000000A4058C: D613002A 248A4F16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A40594: BF870112
	v_fma_f32 v45, -v26, v41, v36                              // 000000A40598: D613002D 2492531A
	v_fmac_f32_e32 v39, v42, v27                               // 000000A405A0: 564E372A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A405A4: BF870195
	v_fma_f32 v35, -v28, v32, 1.0                              // 000000A405A8: D6130023 23CA411C
	v_fmac_f32_e32 v41, v45, v31                               // 000000A405B0: 56523F2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A405B4: BF870193
	v_fma_f32 v22, -v22, v39, v34                              // 000000A405B8: D6130016 248A4F16
	v_fmac_f32_e32 v32, v35, v32                               // 000000A405C0: 56404123
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A405C4: BF870193
	v_fma_f32 v26, -v26, v41, v36                              // 000000A405C8: D613001A 2492531A
	v_div_fmas_f32 v22, v22, v27, v39                          // 000000A405D0: D6370016 049E3716
	s_mov_b32 vcc_lo, s7                                       // 000000A405D8: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000A405DC: BF870131
	v_div_fixup_f32 v12, v22, v18, v12                         // 000000A405E0: D627000C 04322516
	v_fmac_f32_e32 v29, v37, v29                               // 000000A405E8: 563A3B25
	v_div_scale_f32 v37, s8, v13, v21, v13                     // 000000A405EC: D6FC0825 04362B0D
	v_dual_mul_f32 v12, v12, v40 :: v_dual_mul_f32 v35, v38, v29// 000000A405F4: C8C6510C 0C223B26
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A405FC: BF870112
	v_mul_f32_e32 v43, v37, v32                                // 000000A40600: 10564125
	.long 0x7e3c398c                                           // 000000A40604: 7E3C398C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A40608: BF870193
	v_fma_f32 v44, -v23, v35, v38                              // 000000A4060C: D613002C 249A4717
	v_fma_f32 v42, -v28, v43, v37                              // 000000A40614: D613002A 2496571C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A4061C: BF870112
	v_fmac_f32_e32 v35, v44, v29                               // 000000A40620: 56463B2C
	v_fmac_f32_e32 v43, v42, v32                               // 000000A40624: 5656412A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A40628: BF870112
	v_fma_f32 v23, -v23, v35, v38                              // 000000A4062C: D6130017 249A4717
	v_fma_f32 v22, -v28, v43, v37                              // 000000A40634: D6130016 2496571C
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A4063C: BF870002
	v_div_fmas_f32 v23, v23, v29, v35                          // 000000A40640: D6370017 048E3B17
	s_mov_b32 vcc_lo, s6                                       // 000000A40648: BEEA0006
	s_mov_b32 s6, 0                                            // 000000A4064C: BE860080
	v_div_fmas_f32 v18, v26, v31, v41                          // 000000A40650: D6370012 04A63F1A
	s_mov_b32 vcc_lo, s8                                       // 000000A40658: BEEA0008
	v_div_fixup_f32 v15, v23, v19, v15                         // 000000A4065C: D627000F 043E2717
	v_lshlrev_b32_e32 v19, 16, v7                              // 000000A40664: 30260E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000A40668: 360E0EFF FFFF0000
	v_div_fixup_f32 v17, v18, v20, v17                         // 000000A40670: D6270011 04462912
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A40678: BF8701A4
	v_mul_f32_e32 v6, v15, v6                                  // 000000A4067C: 100C0D0F
	v_div_fmas_f32 v15, v22, v32, v43                          // 000000A40680: D637000F 04AE4116
	v_mul_f32_e32 v17, v17, v19                                // 000000A40688: 10222711
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A4068C: BF870193
	.long 0x7e423986                                           // 000000A40690: 7E423986
	v_div_fixup_f32 v13, v15, v21, v13                         // 000000A40694: D627000D 04362B0F
	v_and_b32_e32 v15, 1, v30                                  // 000000A4069C: 361E3C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A406A0: BF870214
	v_bfe_u32 v18, v17, 16, 1                                  // 000000A406A4: D6100012 02052111
	v_and_b32_e32 v19, 1, v33                                  // 000000A406AC: 36264281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A406B0: BF870214
	v_mul_f32_e32 v7, v13, v7                                  // 000000A406B4: 100E0F0D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000A406B8: D655000C 03FE1F0C 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A406C4: BF870214
	v_add3_u32 v13, v17, v18, 0x7fff                           // 000000A406C8: D655000D 03FE2511 00007FFF
	v_add3_u32 v6, v6, v19, 0x7fff                             // 000000A406D4: D6550006 03FE2706 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A406E0: BF870214
	v_bfe_u32 v15, v7, 16, 1                                   // 000000A406E4: D610000F 02052107
	v_and_b32_e32 v12, 0xffff0000, v12                         // 000000A406EC: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A406F4: BF870214
	v_and_b32_e32 v17, 0xffff0000, v13                         // 000000A406F8: 36221AFF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000A40700: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A40708: BF870004
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000A4070C: D6550007 03FE1F07 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000A40718: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000A4071C: CC20080D 8A021910
	s_waitcnt vmcnt(0)                                         // 000000A40724: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 000000A40728: CC20000C 8A02230E
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 000000A40730: CC20000F 8A020D10
	v_and_b32_e32 v14, 0xffff0000, v7                          // 000000A40738: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000A40740: 916A067E
	s_cbranch_vccnz 65125                                      // 000000A40744: BFA4FE65 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1dc>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A40748: BF870093
	.long 0xd73c0004                                           // 000000A4074C: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000A40750: 02020881
	.long 0xd7006a04                                           // 000000A40754: D7006A04
	v_cndmask_b32_e32 v1, s38, v4, vcc_lo                      // 000000A40758: 02020826
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A4075C: BF870111
	v_add_co_ci_u32_e64 v5, null, s39, v5, vcc_lo              // 000000A40760: D5207C05 01AA0A27
	.long 0xd7006a04                                           // 000000A40768: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000A4076C: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A40770: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000A40774: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000A4077C: D7006A06
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000A40780: 0202041A
	v_add_co_ci_u32_e64 v7, null, s27, v3, vcc_lo              // 000000A40784: D5207C07 01AA061B
	global_load_b64 v[4:5], v[4:5], off                        // 000000A4078C: DC560000 047C0004
	s_clause 0x1                                               // 000000A40794: BF850001
	global_load_b32 v14, v[6:7], off                           // 000000A40798: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000A407A0: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000A407A8: BF890BF7
	.long 0x7e0e3904                                           // 000000A407AC: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000A407B0: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 000000A407B8: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A407BC: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000A407C0: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000A407C4: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000A407C8: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 000000A407D0: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 000000A407D4: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 000000A407DC: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 000000A407E4: 361C0AFF FFFF0000
	s_branch 65083                                             // 000000A407EC: BFA0FE3B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1dc>
	s_or_b32 exec_lo, exec_lo, s33                             // 000000A407F0: 8C7E217E
	s_bfe_i32 s34, s35, 0x1001c                                // 000000A407F4: 93A2FF23 0001001C
	s_lshr_b32 s3, s11, 28                                     // 000000A407FC: 85039C0B
	s_lshr_b64 s[0:1], s[34:35], 29                            // 000000A40800: 85809D22
	s_add_i32 s3, s50, s3                                      // 000000A40804: 81030332
	s_add_i32 s0, s0, 7                                        // 000000A40808: 81008700
	s_lshl_b32 s1, s35, 3                                      // 000000A4080C: 84018323
	s_ashr_i32 s0, s0, 3                                       // 000000A40810: 86008300
	s_lshl_b32 s4, s29, 3                                      // 000000A40814: 8404831D
	.long 0xd72c0001                                           // 000000A40818: D72C0001
	v_cndmask_b32_e32 v1, s0, v24, vcc_lo                      // 000000A4081C: 02023000
	v_lshlrev_b32_e32 v19, 2, v25                              // 000000A40820: 30263282
	s_waitcnt lgkmcnt(0)                                       // 000000A40824: BF89FC07
	s_barrier                                                  // 000000A40828: BFBD0000
	buffer_gl0_inv                                             // 000000A4082C: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 000000A40834: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 000000A40838: 86008403
	s_ashr_i32 s3, s4, 31                                      // 000000A4083C: 86039F04
	s_mul_hi_i32 s5, s10, s0                                   // 000000A40840: 9705000A
	s_mul_i32 s0, s10, s0                                      // 000000A40844: 9600000A
	v_min_i32_e32 v21, s1, v2                                  // 000000A40848: 222A0401
	s_add_u32 s0, s0, s4                                       // 000000A4084C: 80000400
	s_addc_u32 s1, s5, s3                                      // 000000A40850: 82010305
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A40854: BF870099
	s_lshl_b64 s[4:5], s[0:1], 10                              // 000000A40858: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v21                           // 000000A4085C: 7C822B01
	s_add_u32 s1, s24, s4                                      // 000000A40860: 80010418
	s_addc_u32 s3, s25, s5                                     // 000000A40864: 82030519
	s_and_saveexec_b32 s4, vcc_lo                              // 000000A40868: BE84206A
	s_cbranch_execz 93                                         // 000000A4086C: BFA5005D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xae4>
	.long 0xd7010002                                           // 000000A40870: D7010002
	v_cndmask_b32_e32 v0, v25, v129, vcc_lo                    // 000000A40874: 02010319
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A40878: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 000000A4087C: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000A40884: 3404029F
	.long 0xd44c0000                                           // 000000A40888: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000A4088C: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A40890: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 000000A40894: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 000000A408A0: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A408A8: BF870114
	.long 0xd73c0005                                           // 000000A408AC: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000A408B0: 0202028A
	.long 0xd73c0002                                           // 000000A408B4: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000A408B8: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A408BC: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 000000A408C0: 30080E98
	v_bfe_i32 v7, v7, 7, 1                                     // 000000A408C4: D6110007 02050F07
	.long 0xd7000008                                           // 000000A408CC: D7000008
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000A408D0: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A408D4: BF870211
	v_add_co_ci_u32_e64 v9, null, s3, v6, s0                   // 000000A408D8: D5207C09 00020C03
	v_ashrrev_i32_e32 v6, 22, v4                               // 000000A408E0: 340C0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A408E4: BF870093
	.long 0xd7000004                                           // 000000A408E8: D7000004
	v_cndmask_b32_e32 v1, v8, v2, vcc_lo                       // 000000A408EC: 02020508
	v_add_co_ci_u32_e64 v5, null, v9, v3, s0                   // 000000A408F0: D5207C05 00020709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A408F8: BF870093
	.long 0xd7000006                                           // 000000A408FC: D7000006
	v_cndmask_b32_e32 v1, v8, v6, vcc_lo                       // 000000A40900: 02020D08
	v_add_co_ci_u32_e64 v7, null, v9, v7, s0                   // 000000A40904: D5207C07 00020F09
	.long 0xd7000008                                           // 000000A4090C: D7000008
	v_cndmask_b32_e32 v1, v8, v19, vcc_lo                      // 000000A40910: 02022708
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A40914: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v9, s0                    // 000000A40918: D5207C09 00021280
	s_clause 0x17                                              // 000000A40920: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000A40924: DC520000 027C0004
	global_load_b32 v92, v[4:5], off offset:128                // 000000A4092C: DC520080 5C7C0004
	global_load_b32 v89, v[4:5], off offset:256                // 000000A40934: DC520100 597C0004
	global_load_b32 v86, v[4:5], off offset:384                // 000000A4093C: DC520180 567C0004
	global_load_b32 v83, v[4:5], off offset:512                // 000000A40944: DC520200 537C0004
	global_load_b32 v80, v[4:5], off offset:640                // 000000A4094C: DC520280 507C0004
	global_load_b32 v77, v[4:5], off offset:768                // 000000A40954: DC520300 4D7C0004
	global_load_b32 v59, v[4:5], off offset:896                // 000000A4095C: DC520380 3B7C0004
	global_load_b32 v4, v[6:7], off                            // 000000A40964: DC520000 047C0006
	global_load_b32 v93, v[6:7], off offset:128                // 000000A4096C: DC520080 5D7C0006
	global_load_b32 v90, v[6:7], off offset:256                // 000000A40974: DC520100 5A7C0006
	global_load_b32 v87, v[6:7], off offset:384                // 000000A4097C: DC520180 577C0006
	global_load_b32 v84, v[6:7], off offset:512                // 000000A40984: DC520200 547C0006
	global_load_b32 v81, v[6:7], off offset:640                // 000000A4098C: DC520280 517C0006
	global_load_b32 v78, v[6:7], off offset:768                // 000000A40994: DC520300 4E7C0006
	global_load_b32 v60, v[6:7], off offset:896                // 000000A4099C: DC520380 3C7C0006
	global_load_b32 v3, v[8:9], off                            // 000000A409A4: DC520000 037C0008
	global_load_b32 v91, v[8:9], off offset:128                // 000000A409AC: DC520080 5B7C0008
	global_load_b32 v88, v[8:9], off offset:256                // 000000A409B4: DC520100 587C0008
	global_load_b32 v85, v[8:9], off offset:384                // 000000A409BC: DC520180 557C0008
	global_load_b32 v82, v[8:9], off offset:512                // 000000A409C4: DC520200 527C0008
	global_load_b32 v79, v[8:9], off offset:640                // 000000A409CC: DC520280 4F7C0008
	global_load_b32 v76, v[8:9], off offset:768                // 000000A409D4: DC520300 4C7C0008
	global_load_b32 v58, v[8:9], off offset:896                // 000000A409DC: DC520380 3A7C0008
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A409E4: 8C7E047E
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v23, 0             // 000000A409E8: CA100080 14160080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v29, 0             // 000000A409F0: CA100080 161C0080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v31, 0             // 000000A409F8: CA100080 1A1E0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v33, 0             // 000000A40A00: CA100080 1C200080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v35, 0             // 000000A40A08: CA100080 1E220080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v37, 0             // 000000A40A10: CA100080 20240080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v39, 0             // 000000A40A18: CA100080 22260080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v41, 0             // 000000A40A20: CA100080 24280080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v45, 0             // 000000A40A28: CA100080 262C0080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v27, 0             // 000000A40A30: CA100080 281A0080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v51, 0             // 000000A40A38: CA100080 2A320080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v53, 0             // 000000A40A40: CA100080 2C340080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v47, 0             // 000000A40A48: CA100080 2E2E0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v49, 0             // 000000A40A50: CA100080 30300080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v43, 0             // 000000A40A58: CA100080 322A0080
	v_mov_b32_e32 v52, 0                                       // 000000A40A60: 7E680280
	v_mov_b32_e32 v54, 0                                       // 000000A40A64: 7E6C0280
	s_ashr_i32 s11, s10, 31                                    // 000000A40A68: 860B9F0A
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A40A6C: BE80206A
	s_cbranch_execz 1077                                       // 000000A40A70: BFA50435 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1c48>
	v_dual_mov_b32 v20, 0 :: v_dual_add_nc_u32 v5, -1, v0      // 000000A40A74: CA200080 140400C1
	v_mov_b32_e32 v22, 0                                       // 000000A40A7C: 7E2C0280
	v_and_or_b32 v55, v0, 16, 0x5600                           // 000000A40A80: D6570037 03FD2100 00005600
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v56, 2, v25    // 000000A40A8C: CA220080 17383282
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A40A94: BF8701B4
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v5, 31, v5         // 000000A40A98: CA240080 1A040A9F
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v28, 0             // 000000A40AA0: CA100080 1D1C0080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v31, 0             // 000000A40AA8: CA100080 1E1E0080
	v_dual_mov_b32 v32, 0 :: v_dual_lshlrev_b32 v57, 2, v5     // 000000A40AB0: CA220080 20380A82
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 000000A40AB8: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000A40AC0: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000A40AC8: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 000000A40AD0: CA100080 27280080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 000000A40AD8: CA100080 292A0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0             // 000000A40AE0: CA100080 2D2C0080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v46, 0             // 000000A40AE8: CA100080 1B2E0080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v48, 0             // 000000A40AF0: CA100080 33300080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v50, 0             // 000000A40AF8: CA100080 35320080
	v_mov_b32_e32 v47, 0                                       // 000000A40B00: 7E5E0280
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v52, 0             // 000000A40B04: CA100080 31340080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v54, 0             // 000000A40B0C: CA100080 2B360080
	s_mov_b32 s4, 0                                            // 000000A40B14: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000A40B18: B0051EEE
	s_branch 975                                               // 000000A40B1C: BFA003CF <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1b5c>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000A40B20: 8C7E067E
	s_waitcnt vmcnt(15)                                        // 000000A40B24: BF893FF7
	v_alignbit_b32 v2, v2, v4, 16                              // 000000A40B28: D6160002 02420902
	v_lshl_add_u32 v13, v1, 5, v55                             // 000000A40B30: D646000D 04DD0B01
	s_waitcnt vmcnt(7)                                         // 000000A40B38: BF891FF7
	v_bfe_u32 v14, v3, 12, 16                                  // 000000A40B3C: D610000E 02411903
	v_bfe_u32 v15, v3, 8, 16                                   // 000000A40B44: D610000F 02411103
	v_bfe_u32 v16, v3, 4, 16                                   // 000000A40B4C: D6100010 02410903
	v_bfe_u32 v1, v2, 12, 16                                   // 000000A40B54: D6100001 02411902
	v_bfe_u32 v5, v2, 8, 16                                    // 000000A40B5C: D6100005 02411102
	.long 0xd72c000e                                           // 000000A40B64: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 000000A40B68: 02021CFF 83DCD12D
	.long 0xd72c000f                                           // 000000A40B70: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 000000A40B74: 02021EFF 83DCD12D
	v_alignbit_b32 v92, v92, v93, 16                           // 000000A40B7C: D616005C 0242BB5C
	.long 0xd72c005f                                           // 000000A40B84: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v1, vcc_lo               // 000000A40B88: 020202FF 83DCD12D
	.long 0xd72c0061                                           // 000000A40B90: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 000000A40B94: 02020AFF 83DCD12D
	s_waitcnt vmcnt(6)                                         // 000000A40B9C: BF891BF7
	v_bfe_u32 v100, v91, 4, 16                                 // 000000A40BA0: D6100064 0241095B
	v_alignbit_b32 v89, v89, v90, 16                           // 000000A40BA8: D6160059 0242B559
	v_bfe_u32 v93, v92, 12, 16                                 // 000000A40BB0: D610005D 0241195C
	v_sad_u8 v14, v14, 0, 0x6400                               // 000000A40BB8: D622000E 03FD010E 00006400
	v_sad_u8 v99, v15, 0, 0x6400                               // 000000A40BC4: D6220063 03FD010F 00006400
	v_alignbit_b32 v86, v86, v87, 16                           // 000000A40BD0: D6160056 0242AF56
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000A40BD8: D622005F 03FD015F 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000A40BE4: D6220061 03FD0161 00006400
	.long 0xd72c005d                                           // 000000A40BF0: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000A40BF4: 0202BAFF 83DCD12D
	v_bfe_u32 v90, v89, 12, 16                                 // 000000A40BFC: D610005A 02411959
	v_bfe_u32 v87, v86, 12, 16                                 // 000000A40C04: D6100057 02411956
	v_and_b32_e32 v95, 0xffff, v95                             // 000000A40C0C: 36BEBEFF 0000FFFF
	v_alignbit_b32 v83, v83, v84, 16                           // 000000A40C14: D6160053 0242A953
	v_alignbit_b32 v80, v80, v81, 16                           // 000000A40C1C: D6160050 0242A350
	.long 0xd72c005a                                           // 000000A40C24: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000A40C28: 0202B4FF 83DCD12D
	.long 0xd72c0057                                           // 000000A40C30: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A40C34: 0202AEFF 83DCD12D
	v_lshl_or_b32 v95, v97, 16, v95                            // 000000A40C3C: D656005F 057D2161
	.long 0xd72c0061                                           // 000000A40C44: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 000000A40C48: 020220FF 83DCD12D
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000A40C50: D622005D 03FD015D 00006400
	v_bfe_u32 v84, v83, 12, 16                                 // 000000A40C5C: D6100054 02411953
	v_bfe_u32 v81, v80, 12, 16                                 // 000000A40C64: D6100051 02411950
	v_pk_fma_f16 v95, v95, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A40C6C: CC0E005F 0BFC0B5F 0000C931
	v_and_b32_e32 v4, 0xffff, v2                               // 000000A40C78: 360804FF 0000FFFF
	v_bfe_u32 v2, v2, 4, 16                                    // 000000A40C80: D6100002 02410902
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000A40C88: D622005A 03FD015A 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000A40C94: D6220061 03FD0161 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000A40CA0: D6220057 03FD0157 00006400
	.long 0xd72c0060                                           // 000000A40CAC: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v4, vcc_lo               // 000000A40CB0: 020208FF 83DCD12D
	.long 0xd72c0062                                           // 000000A40CB8: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v2, vcc_lo               // 000000A40CBC: 020204FF 83DCD12D
	.long 0xd72c0054                                           // 000000A40CC4: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A40CC8: 0202A8FF 83DCD12D
	.long 0xd72c0051                                           // 000000A40CD0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A40CD4: 0202A2FF 83DCD12D
	v_alignbit_b32 v77, v77, v78, 16                           // 000000A40CDC: D616004D 02429D4D
	v_alignbit_b32 v59, v59, v60, 16                           // 000000A40CE4: D616003B 0242793B
	v_cmp_eq_u32_e32 vcc_lo, v17, v21                          // 000000A40CEC: 7C942B11
	v_and_b32_e32 v93, 0xffff, v93                             // 000000A40CF0: 36BABAFF 0000FFFF
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000A40CF8: D6220060 03FD0160 00006400
	v_sad_u8 v98, v98, 0, 0x6400                               // 000000A40D04: D6220062 03FD0162 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A40D10: D6220054 03FD0154 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A40D1C: D6220051 03FD0151 00006400
	v_bfe_u32 v78, v77, 12, 16                                 // 000000A40D28: D610004E 0241194D
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000A40D30: 30C0C090
	v_bfe_u32 v60, v59, 12, 16                                 // 000000A40D34: D610003C 0241193B
	s_or_b32 s4, vcc_lo, s4                                    // 000000A40D3C: 8C04046A
	v_and_b32_e32 v90, 0xffff, v90                             // 000000A40D40: 36B4B4FF 0000FFFF
	.long 0xd72c004e                                           // 000000A40D48: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A40D4C: 02029CFF 83DCD12D
	v_and_or_b32 v96, 0xffff, v98, v96                         // 000000A40D54: D6570060 0582C4FF 0000FFFF
	.long 0xd72c003c                                           // 000000A40D60: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A40D64: 020278FF 83DCD12D
	v_and_b32_e32 v84, 0xffff, v84                             // 000000A40D6C: 36A8A8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A40D74: BF870003
	v_pk_fma_f16 v96, v96, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A40D78: CC0E0060 0BFC0B60 0000C931
	v_and_b32_e32 v94, 0xffff, v3                              // 000000A40D84: 36BC06FF 0000FFFF
	ds_load_b128 v[1:4], v13                                   // 000000A40D8C: DBFC0000 0100000D
	ds_load_b128 v[5:8], v13 offset:5120                       // 000000A40D94: DBFC1400 0500000D
	ds_load_b128 v[9:12], v13 offset:10240                     // 000000A40D9C: DBFC2800 0900000D
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A40DA4: D622004E 03FD014E 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A40DB0: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000A40DBC: BF8700D2
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A40DC0: 369C9CFF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 000000A40DC8: BF89FC27
	v_dot2acc_f32_f16 v54, v95, v1                             // 000000A40DCC: 046C035F
	s_waitcnt lgkmcnt(0)                                       // 000000A40DD0: BF89FC07
	v_dot2acc_f32_f16 v43, v95, v9                             // 000000A40DD4: 0456135F
	v_dot2acc_f32_f16 v43, v96, v10                            // 000000A40DD8: 04561560
	.long 0xd72c005e                                           // 000000A40DDC: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000A40DE0: 0202BCFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A40DE8: BF870091
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000A40DEC: D622005E 03FD015E 00006400
	v_lshlrev_b32_e32 v94, 16, v94                             // 000000A40DF8: 30BCBC90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A40DFC: BF870121
	v_and_or_b32 v94, 0xffff, v97, v94                         // 000000A40E00: D657005E 057AC2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v54, v96, v2 :: v_dual_and_b32 v97, 0xffff, v92// 000000A40E0C: CB240560 3660B8FF 0000FFFF
	v_pk_fma_f16 v94, v94, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A40E18: CC0E005E 0BFC0B5E 0000C931
	v_and_b32_e32 v98, 0xffff, v14                             // 000000A40E24: 36C41CFF 0000FFFF
	ds_load_b128 v[13:16], v13 offset:15360                    // 000000A40E2C: DBFC3C00 0D00000D
	.long 0xd72c0061                                           // 000000A40E34: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000A40E38: 0202C2FF 83DCD12D
	v_lshl_or_b32 v98, v99, 16, v98                            // 000000A40E40: D6560062 05892163
	v_bfe_u32 v99, v91, 8, 16                                  // 000000A40E48: D6100063 0241115B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A40E50: BF870212
	v_pk_fma_f16 v98, v98, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A40E54: CC0E0062 0BFC0B62 0000C931
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000A40E60: D6220061 03FD0161 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A40E6C: BF870113
	.long 0xd72c0063                                           // 000000A40E70: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000A40E74: 0202C6FF 83DCD12D
	v_dual_dot2acc_f32_f16 v54, v98, v3 :: v_dual_lshlrev_b32 v97, 16, v97// 000000A40E7C: CB220762 3660C290
	v_dot2acc_f32_f16 v43, v98, v11                            // 000000A40E84: 04561762
	s_waitcnt lgkmcnt(0)                                       // 000000A40E88: BF89FC07
	v_dot2acc_f32_f16 v49, v95, v13                            // 000000A40E8C: 04621B5F
	v_dot2acc_f32_f16 v52, v95, v5                             // 000000A40E90: 04680B5F
	v_bfe_u32 v95, v92, 8, 16                                  // 000000A40E94: D610005F 0241115C
	v_bfe_u32 v92, v92, 4, 16                                  // 000000A40E9C: D610005C 0241095C
	v_dot2acc_f32_f16 v43, v94, v12                            // 000000A40EA4: 0456195E
	v_dot2acc_f32_f16 v49, v96, v14                            // 000000A40EA8: 04621D60
	v_dot2acc_f32_f16 v52, v96, v6                             // 000000A40EAC: 04680D60
	.long 0xd72c005f                                           // 000000A40EB0: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000A40EB4: 0202BEFF 83DCD12D
	v_bfe_u32 v96, v91, 12, 16                                 // 000000A40EBC: D6100060 0241195B
	.long 0xd72c005c                                           // 000000A40EC4: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000A40EC8: 0202B8FF 83DCD12D
	v_and_b32_e32 v91, 0xffff, v91                             // 000000A40ED0: 36B6B6FF 0000FFFF
	v_dot2acc_f32_f16 v52, v98, v7                             // 000000A40ED8: 04680F62
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A40EDC: BF870224
	.long 0xd72c0060                                           // 000000A40EE0: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000A40EE4: 0202C0FF 83DCD12D
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000A40EEC: D622005F 03FD015F 00006400
	.long 0xd72c005b                                           // 000000A40EF8: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000A40EFC: 0202B6FF 83DCD12D
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000A40F04: D622005C 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A40F10: BF8701A3
	v_lshl_or_b32 v93, v95, 16, v93                            // 000000A40F14: D656005D 0575215F
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000A40F1C: D6220060 03FD0160 00006400
	v_and_or_b32 v92, 0xffff, v92, v97                         // 000000A40F28: D657005C 0586B8FF 0000FFFF
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000A40F34: D622005B 03FD015B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A40F40: BF870224
	v_pk_fma_f16 v93, v93, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A40F44: CC0E005D 0BFC0B5D 0000C931
	v_dot2acc_f32_f16 v49, v98, v15                            // 000000A40F50: 04621F62
	v_pk_fma_f16 v92, v92, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A40F54: CC0E005C 0BFC0B5C 0000C931
	v_dot2acc_f32_f16 v52, v94, v8                             // 000000A40F60: 0468115E
	.long 0xd72c0062                                           // 000000A40F64: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 000000A40F68: 0202C8FF 83DCD12D
	v_dual_dot2acc_f32_f16 v50, v93, v13 :: v_dual_and_b32 v95, 0xffff, v96// 000000A40F70: CB241B5D 325EC0FF 0000FFFF
	v_sad_u8 v96, v99, 0, 0x6400                               // 000000A40F7C: D6220060 03FD0163 00006400
	v_dual_dot2acc_f32_f16 v47, v93, v1 :: v_dual_dot2acc_f32_f16 v54, v94, v4// 000000A40F88: CB18035D 2F36095E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A40F90: BF870193
	v_dual_dot2acc_f32_f16 v50, v92, v14 :: v_dual_lshlrev_b32 v91, 16, v91// 000000A40F94: CB221D5C 325AB690
	v_lshl_or_b32 v95, v96, 16, v95                            // 000000A40F9C: D656005F 057D2160
	v_dot2acc_f32_f16 v53, v93, v5                             // 000000A40FA4: 046A0B5D
	v_dot2acc_f32_f16 v51, v93, v9                             // 000000A40FA8: 0466135D
	v_dot2acc_f32_f16 v47, v92, v2                             // 000000A40FAC: 045E055C
	v_bfe_u32 v93, v89, 8, 16                                  // 000000A40FB0: D610005D 02411159
	v_pk_fma_f16 v95, v95, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A40FB8: CC0E005F 0BFC0B5F 0000C931
	v_dual_dot2acc_f32_f16 v49, v94, v16 :: v_dual_and_b32 v94, 0xffff, v89// 000000A40FC4: CB24215E 315EB2FF 0000FFFF
	v_sad_u8 v97, v98, 0, 0x6400                               // 000000A40FD0: D6220061 03FD0162 00006400
	v_bfe_u32 v89, v89, 4, 16                                  // 000000A40FDC: D6100059 02410959
	s_waitcnt vmcnt(5)                                         // 000000A40FE4: BF8917F7
	v_bfe_u32 v96, v88, 12, 16                                 // 000000A40FE8: D6100060 02411958
	.long 0xd72c005d                                           // 000000A40FF0: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000A40FF4: 0202BAFF 83DCD12D
	.long 0xd72c005e                                           // 000000A40FFC: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000A41000: 0202BCFF 83DCD12D
	v_and_or_b32 v91, 0xffff, v97, v91                         // 000000A41008: D657005B 056EC2FF 0000FFFF
	v_bfe_u32 v97, v88, 8, 16                                  // 000000A41014: D6100061 02411158
	.long 0xd72c0060                                           // 000000A4101C: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000A41020: 0202C0FF 83DCD12D
	v_bfe_u32 v98, v88, 4, 16                                  // 000000A41028: D6100062 02410958
	v_and_b32_e32 v88, 0xffff, v88                             // 000000A41030: 36B0B0FF 0000FFFF
	.long 0xd72c0059                                           // 000000A41038: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000A4103C: 0202B2FF 83DCD12D
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000A41044: D622005D 03FD015D 00006400
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000A41050: D622005E 03FD015E 00006400
	.long 0xd72c0061                                           // 000000A4105C: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000A41060: 0202C2FF 83DCD12D
	.long 0xd72c0058                                           // 000000A41068: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000A4106C: 0202B0FF 83DCD12D
	v_pk_fma_f16 v91, v91, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A41074: CC0E005B 0BFC0B5B 0000C931
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000A41080: D6220060 03FD0160 00006400
	v_lshl_or_b32 v90, v93, 16, v90                            // 000000A4108C: D656005A 0569215D
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000A41094: D6220059 03FD0159 00006400
	v_dual_dot2acc_f32_f16 v50, v95, v15 :: v_dual_lshlrev_b32 v93, 16, v94// 000000A410A0: CB221F5F 325CBC90
	.long 0xd72c005e                                           // 000000A410A8: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000A410AC: 0202C4FF 83DCD12D
	v_dual_dot2acc_f32_f16 v53, v92, v6 :: v_dual_and_b32 v96, 0xffff, v96// 000000A410B4: CB240D5C 3560C0FF 0000FFFF
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000A410C0: D6220061 03FD0161 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000A410CC: D6220058 03FD0158 00006400
	v_pk_fma_f16 v90, v90, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A410D8: CC0E005A 0BFC0B5A 0000C931
	v_dot2acc_f32_f16 v50, v91, v16                            // 000000A410E4: 0464215B
	v_and_or_b32 v89, 0xffff, v89, v93                         // 000000A410E8: D6570059 0576B2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A410F4: BF870214
	v_dual_dot2acc_f32_f16 v51, v92, v10 :: v_dual_lshlrev_b32 v88, 16, v88// 000000A410F8: CB22155C 3358B090
	v_dual_dot2acc_f32_f16 v47, v95, v3 :: v_dual_dot2acc_f32_f16 v48, v90, v5// 000000A41100: CB18075F 2F300B5A
	v_lshl_or_b32 v92, v97, 16, v96                            // 000000A41108: D656005C 05812161
	v_sad_u8 v93, v94, 0, 0x6400                               // 000000A41110: D622005D 03FD015E 00006400
	v_pk_fma_f16 v89, v89, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A4111C: CC0E0059 0BFC0B59 0000C931
	v_dual_dot2acc_f32_f16 v53, v95, v7 :: v_dual_dot2acc_f32_f16 v46, v90, v9// 000000A41128: CB180F5F 352E135A
	v_dot2acc_f32_f16 v51, v95, v11                            // 000000A41130: 0466175F
	v_pk_fma_f16 v92, v92, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A41134: CC0E005C 0BFC0B5C 0000C931
	v_and_or_b32 v88, 0xffff, v93, v88                         // 000000A41140: D6570058 0562BAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v48, v89, v6 :: v_dual_dot2acc_f32_f16 v47, v91, v4// 000000A4114C: CB180D59 302E095B
	v_dual_dot2acc_f32_f16 v46, v89, v10 :: v_dual_dot2acc_f32_f16 v53, v91, v8// 000000A41154: CB181559 2E34115B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A4115C: BF870193
	v_pk_fma_f16 v88, v88, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A41160: CC0E0058 0BFC0B58 0000C931
	v_dual_dot2acc_f32_f16 v48, v92, v7 :: v_dual_dot2acc_f32_f16 v27, v90, v1// 000000A4116C: CB180F5C 301A035A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A41174: BF870113
	v_dual_dot2acc_f32_f16 v51, v91, v12 :: v_dual_dot2acc_f32_f16 v46, v92, v11// 000000A41178: CB18195B 332E175C
	v_dual_dot2acc_f32_f16 v45, v90, v13 :: v_dual_dot2acc_f32_f16 v48, v88, v8// 000000A41180: CB181B5A 2D301158
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A41188: BF8701A3
	v_dot2acc_f32_f16 v27, v89, v2                             // 000000A4118C: 04360559
	v_and_b32_e32 v90, 0xffff, v86                             // 000000A41190: 36B4ACFF 0000FFFF
	v_dual_dot2acc_f32_f16 v46, v88, v12 :: v_dual_dot2acc_f32_f16 v45, v89, v14// 000000A41198: CB181958 2E2C1D59
	v_bfe_u32 v89, v86, 8, 16                                  // 000000A411A0: D6100059 02411156
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A411A8: BF870004
	v_dot2acc_f32_f16 v27, v92, v3                             // 000000A411AC: 0436075C
	v_bfe_u32 v86, v86, 4, 16                                  // 000000A411B0: D6100056 02410956
	.long 0xd72c005a                                           // 000000A411B8: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000A411BC: 0202B4FF 83DCD12D
	s_waitcnt vmcnt(4)                                         // 000000A411C4: BF8913F7
	v_bfe_u32 v91, v85, 12, 16                                 // 000000A411C8: D610005B 02411955
	.long 0xd72c0059                                           // 000000A411D0: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000A411D4: 0202B2FF 83DCD12D
	v_bfe_u32 v93, v85, 4, 16                                  // 000000A411DC: D610005D 02410955
	.long 0xd72c0056                                           // 000000A411E4: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A411E8: 0202ACFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A411F0: BF870254
	.long 0xd72c005b                                           // 000000A411F4: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000A411F8: 0202B6FF 83DCD12D
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000A41200: D622005A 03FD015A 00006400
	v_dot2acc_f32_f16 v27, v88, v4                             // 000000A4120C: 04360958
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000A41210: D6220059 03FD0159 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000A4121C: D6220056 03FD0156 00006400
	v_lshlrev_b32_e32 v90, 16, v90                             // 000000A41228: 30B4B490
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000A4122C: D622005B 03FD015B 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A41238: BF870092
	v_and_or_b32 v86, 0xffff, v86, v90                         // 000000A4123C: D6570056 056AACFF 0000FFFF
	v_pk_fma_f16 v86, v86, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A41248: CC0E0056 0BFC0B56 0000C931
	v_and_b32_e32 v87, 0xffff, v87                             // 000000A41254: 36AEAEFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A4125C: BF870091
	v_lshl_or_b32 v87, v89, 16, v87                            // 000000A41260: D6560057 055D2159
	v_pk_fma_f16 v87, v87, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A41268: CC0E0057 0BFC0B57 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A41274: BF8701B1
	v_dual_dot2acc_f32_f16 v44, v87, v1 :: v_dual_dot2acc_f32_f16 v45, v92, v15// 000000A41278: CB180357 2C2C1F5C
	v_dot2acc_f32_f16 v42, v87, v5                             // 000000A41280: 04540B57
	v_bfe_u32 v92, v85, 8, 16                                  // 000000A41284: D610005C 02411155
	v_dual_dot2acc_f32_f16 v44, v86, v2 :: v_dual_and_b32 v85, 0xffff, v85// 000000A4128C: CB240556 2C54AAFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A41298: BF8701A4
	v_dual_dot2acc_f32_f16 v45, v88, v16 :: v_dual_dot2acc_f32_f16 v40, v87, v13// 000000A4129C: CB182158 2D281B57
	.long 0xd72c0058                                           // 000000A412A4: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000A412A8: 0202BAFF 83DCD12D
	.long 0xd72c0055                                           // 000000A412B0: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A412B4: 0202AAFF 83DCD12D
	v_dot2acc_f32_f16 v42, v86, v6                             // 000000A412BC: 04540D56
	.long 0xd72c005c                                           // 000000A412C0: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000A412C4: 0202B8FF 83DCD12D
	v_dot2acc_f32_f16 v40, v86, v14                            // 000000A412CC: 04501D56
	v_mov_b32_e32 v93, v74                                     // 000000A412D0: 7EBA034A
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000A412D4: D6220058 03FD0158 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A412E0: D6220055 03FD0155 00006400
	v_sad_u8 v90, v92, 0, 0x6400                               // 000000A412EC: D622005A 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A412F8: BF870092
	v_dual_mov_b32 v92, v68 :: v_dual_lshlrev_b32 v85, 16, v85 // 000000A412FC: CA220144 5C54AA90
	v_and_or_b32 v85, 0xffff, v88, v85                         // 000000A41304: D6570055 0556B0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A41310: BF870141
	v_pk_fma_f16 v85, v85, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A41314: CC0E0055 0BFC0B55 0000C931
	v_and_b32_e32 v89, 0xffff, v91                             // 000000A41320: 36B2B6FF 0000FFFF
	s_waitcnt vmcnt(3)                                         // 000000A41328: BF890FF7
	v_bfe_u32 v91, v82, 4, 16                                  // 000000A4132C: D610005B 02410952
	v_lshl_or_b32 v89, v90, 16, v89                            // 000000A41334: D6560059 0565215A
	v_bfe_u32 v90, v82, 8, 16                                  // 000000A4133C: D610005A 02411152
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A41344: BF870232
	v_pk_fma_f16 v88, v89, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A41348: CC0E0058 0BFC0B59 0000C931
	v_bfe_u32 v89, v82, 12, 16                                 // 000000A41354: D6100059 02411952
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A4135C: 36A4A4FF 0000FFFF
	.long 0xd72c005a                                           // 000000A41364: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000A41368: 0202B4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A41370: BF870214
	v_dual_dot2acc_f32_f16 v42, v88, v7 :: v_dual_dot2acc_f32_f16 v41, v87, v9// 000000A41374: CB180F58 2A281357
	.long 0xd72c0059                                           // 000000A4137C: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000A41380: 0202B2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A41388: BF870224
	.long 0xd72c0052                                           // 000000A4138C: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A41390: 0202A4FF 83DCD12D
	v_dot2acc_f32_f16 v44, v88, v3                             // 000000A41398: 04580758
	v_dual_dot2acc_f32_f16 v42, v85, v8 :: v_dual_dot2acc_f32_f16 v41, v86, v10// 000000A4139C: CB181155 2A281556
	v_bfe_u32 v86, v83, 8, 16                                  // 000000A413A4: D6100056 02411153
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000A413AC: D622005A 03FD015A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000A413B8: BF8701D4
	v_dot2acc_f32_f16 v44, v85, v4                             // 000000A413BC: 04580955
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000A413C0: D6220059 03FD0159 00006400
	v_dot2acc_f32_f16 v41, v88, v11                            // 000000A413CC: 04521758
	.long 0xd72c0056                                           // 000000A413D0: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A413D4: 0202ACFF 83DCD12D
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A413DC: D6220052 03FD0152 00006400
	v_dot2acc_f32_f16 v41, v85, v12                            // 000000A413E8: 04521955
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A413EC: BF870093
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000A413F0: D6220056 03FD0156 00006400
	v_lshl_or_b32 v84, v86, 16, v84                            // 000000A413FC: D6560054 05512156
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A41404: BF8701B1
	v_pk_fma_f16 v84, v84, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A41408: CC0E0054 0BFC0B54 0000C931
	v_and_b32_e32 v87, 0xffff, v83                             // 000000A41414: 36AEA6FF 0000FFFF
	v_bfe_u32 v83, v83, 4, 16                                  // 000000A4141C: D6100053 02410953
	v_dual_dot2acc_f32_f16 v39, v84, v1 :: v_dual_lshlrev_b32 v82, 16, v82// 000000A41424: CB220354 2752A490
	v_dot2acc_f32_f16 v38, v84, v5                             // 000000A4142C: 044C0B54
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A41430: BF870214
	.long 0xd72c0057                                           // 000000A41434: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A41438: 0202AEFF 83DCD12D
	.long 0xd72c0053                                           // 000000A41440: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A41444: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v37, v84, v9                             // 000000A4144C: 044A1354
	v_dot2acc_f32_f16 v40, v88, v15                            // 000000A41450: 04501F58
	v_dot2acc_f32_f16 v36, v84, v13                            // 000000A41454: 04481B54
	v_bfe_u32 v84, v80, 8, 16                                  // 000000A41458: D6100054 02411150
	s_waitcnt vmcnt(2)                                         // 000000A41460: BF890BF7
	v_bfe_u32 v88, v79, 4, 16                                  // 000000A41464: D6100058 0241094F
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000A4146C: D6220057 03FD0157 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A41478: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v40, v85, v16                            // 000000A41484: 04502155
	v_bfe_u32 v85, v79, 12, 16                                 // 000000A41488: D6100055 0241194F
	.long 0xd72c0054                                           // 000000A41490: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A41494: 0202A8FF 83DCD12D
	v_lshlrev_b32_e32 v87, 16, v87                             // 000000A4149C: 30AEAE90
	.long 0xd72c0058                                           // 000000A414A0: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000A414A4: 0202B0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A414AC: BF870194
	.long 0xd72c0055                                           // 000000A414B0: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A414B4: 0202AAFF 83DCD12D
	v_and_or_b32 v83, 0xffff, v83, v87                         // 000000A414BC: D6570053 055EA6FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A414C8: D6220054 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A414D4: BF870002
	v_pk_fma_f16 v83, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A414D8: CC0E0053 0BFC0B53 0000C931
	v_and_b32_e32 v86, 0xffff, v89                             // 000000A414E4: 36ACB2FF 0000FFFF
	.long 0xd72c0059                                           // 000000A414EC: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000A414F0: 0202B6FF 83DCD12D
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A414F8: D6220055 03FD0155 00006400
	v_mov_b32_e32 v91, v74                                     // 000000A41504: 7EB6034A
	v_dot2acc_f32_f16 v39, v83, v2                             // 000000A41508: 044E0553
	v_lshl_or_b32 v86, v90, 16, v86                            // 000000A4150C: D6560056 0559215A
	v_dot2acc_f32_f16 v38, v83, v6                             // 000000A41514: 044C0D53
	v_dot2acc_f32_f16 v37, v83, v10                            // 000000A41518: 044A1553
	v_dual_dot2acc_f32_f16 v36, v83, v14 :: v_dual_and_b32 v83, 0xffff, v80// 000000A4151C: CB241D53 2452A0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A41528: BF870004
	v_pk_fma_f16 v86, v86, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A4152C: CC0E0056 0BFC0B56 0000C931
	v_sad_u8 v87, v89, 0, 0x6400                               // 000000A41538: D6220057 03FD0159 00006400
	v_bfe_u32 v80, v80, 4, 16                                  // 000000A41544: D6100050 02410950
	v_and_b32_e32 v81, 0xffff, v81                             // 000000A4154C: 36A2A2FF 0000FFFF
	.long 0xd72c0053                                           // 000000A41554: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A41558: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v39, v86, v3                             // 000000A41560: 044E0756
	v_dot2acc_f32_f16 v38, v86, v7                             // 000000A41564: 044C0F56
	v_dot2acc_f32_f16 v37, v86, v11                            // 000000A41568: 044A1756
	v_and_or_b32 v82, 0xffff, v87, v82                         // 000000A4156C: D6570052 054AAEFF 0000FFFF
	v_bfe_u32 v87, v79, 8, 16                                  // 000000A41578: D6100057 0241114F
	.long 0xd72c0050                                           // 000000A41580: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A41584: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v36, v86, v15                            // 000000A4158C: 04481F56
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A41590: D6220053 03FD0153 00006400
	v_pk_fma_f16 v82, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A4159C: CC0E0052 0BFC0B52 0000C931
	.long 0xd72c0057                                           // 000000A415A8: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A415AC: 0202AEFF 83DCD12D
	v_lshl_or_b32 v81, v84, 16, v81                            // 000000A415B4: D6560051 05452154
	v_and_b32_e32 v79, 0xffff, v79                             // 000000A415BC: 369E9EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A415C4: BF870004
	v_dual_dot2acc_f32_f16 v36, v82, v16 :: v_dual_lshlrev_b32 v83, 16, v83// 000000A415C8: CB222152 2452A690
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A415D0: D6220050 03FD0150 00006400
	v_dot2acc_f32_f16 v38, v82, v8                             // 000000A415DC: 044C1152
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A415E0: CC0E0051 0BFC0B51 0000C931
	v_sad_u8 v84, v87, 0, 0x6400                               // 000000A415EC: D6220054 03FD0157 00006400
	.long 0xd72c004f                                           // 000000A415F8: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A415FC: 02029EFF 83DCD12D
	v_and_or_b32 v80, 0xffff, v80, v83                         // 000000A41604: D6570050 054EA0FF 0000FFFF
	v_and_b32_e32 v83, 0xffff, v85                             // 000000A41610: 36A6AAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v39, v82, v4 :: v_dual_dot2acc_f32_f16 v34, v81, v5// 000000A41618: CB180952 27220B51
	v_sad_u8 v85, v88, 0, 0x6400                               // 000000A41620: D6220055 03FD0158 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A4162C: BF870214
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A41630: CC0E0050 0BFC0B50 0000C931
	v_lshl_or_b32 v83, v84, 16, v83                            // 000000A4163C: D6560053 054D2154
	v_dot2acc_f32_f16 v37, v82, v12                            // 000000A41644: 044A1952
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A41648: D622004F 03FD014F 00006400
	v_and_b32_e32 v82, 0xffff, v77                             // 000000A41654: 36A49AFF 0000FFFF
	v_dot2acc_f32_f16 v34, v80, v6                             // 000000A4165C: 04440D50
	v_pk_fma_f16 v83, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A41660: CC0E0053 0BFC0B53 0000C931
	v_dot2acc_f32_f16 v35, v81, v1                             // 000000A4166C: 04460351
	v_dual_dot2acc_f32_f16 v32, v81, v13 :: v_dual_lshlrev_b32 v79, 16, v79// 000000A41670: CB221B51 204E9E90
	v_bfe_u32 v84, v77, 8, 16                                  // 000000A41678: D6100054 0241114D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A41680: BF870193
	v_dual_dot2acc_f32_f16 v34, v83, v7 :: v_dual_dot2acc_f32_f16 v35, v80, v2// 000000A41684: CB180F53 22220550
	v_and_or_b32 v79, 0xffff, v85, v79                         // 000000A4168C: D657004F 053EAAFF 0000FFFF
	v_bfe_u32 v77, v77, 4, 16                                  // 000000A41698: D610004D 0241094D
	.long 0xd72c0052                                           // 000000A416A0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A416A4: 0202A4FF 83DCD12D
	s_waitcnt vmcnt(1)                                         // 000000A416AC: BF8907F7
	v_bfe_u32 v85, v76, 12, 16                                 // 000000A416B0: D6100055 0241194C
	.long 0xd72c0054                                           // 000000A416B8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A416BC: 0202A8FF 83DCD12D
	v_dot2acc_f32_f16 v33, v81, v9                             // 000000A416C4: 04421351
	v_bfe_u32 v86, v76, 8, 16                                  // 000000A416C8: D6100056 0241114C
	.long 0xd72c004d                                           // 000000A416D0: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A416D4: 02029AFF 83DCD12D
	v_bfe_u32 v87, v76, 4, 16                                  // 000000A416DC: D6100057 0241094C
	.long 0xd72c0055                                           // 000000A416E4: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A416E8: 0202AAFF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A416F0: 369898FF 0000FFFF
	v_pk_fma_f16 v79, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A416F8: CC0E004F 0BFC0B4F 0000C931
	v_dot2acc_f32_f16 v35, v83, v3                             // 000000A41704: 04460753
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A41708: D6220052 03FD0152 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A41714: D6220054 03FD0154 00006400
	.long 0xd72c0056                                           // 000000A41720: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A41724: 0202ACFF 83DCD12D
	.long 0xd72c004c                                           // 000000A4172C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A41730: 020298FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A41738: BF870004
	v_dual_dot2acc_f32_f16 v35, v79, v4 :: v_dual_lshlrev_b32 v82, 16, v82// 000000A4173C: CB22094F 2352A490
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A41744: D622004D 03FD014D 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A41750: D6220055 03FD0155 00006400
	v_lshl_or_b32 v78, v84, 16, v78                            // 000000A4175C: D656004E 05392154
	.long 0xd72c0051                                           // 000000A41764: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A41768: 0202AEFF 83DCD12D
	v_dot2acc_f32_f16 v33, v80, v10                            // 000000A41770: 04421550
	v_and_or_b32 v77, 0xffff, v77, v82                         // 000000A41774: D657004D 054A9AFF 0000FFFF
	v_and_b32_e32 v82, 0xffff, v85                             // 000000A41780: 36A4AAFF 0000FFFF
	v_sad_u8 v84, v86, 0, 0x6400                               // 000000A41788: D6220054 03FD0156 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A41794: D622004C 03FD014C 00006400
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A417A0: CC0E004E 0BFC0B4E 0000C931
	v_dual_dot2acc_f32_f16 v33, v83, v11 :: v_dual_dot2acc_f32_f16 v32, v80, v14// 000000A417AC: CB181753 21201D50
	v_pk_fma_f16 v77, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A417B4: CC0E004D 0BFC0B4D 0000C931
	v_lshl_or_b32 v80, v84, 16, v82                            // 000000A417C0: D6560050 05492154
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A417C8: D6220051 03FD0151 00006400
	v_dual_dot2acc_f32_f16 v31, v78, v1 :: v_dual_lshlrev_b32 v76, 16, v76// 000000A417D4: CB22034E 1F4C9890
	v_dual_dot2acc_f32_f16 v33, v79, v12 :: v_dual_dot2acc_f32_f16 v30, v78, v5// 000000A417DC: CB18194F 211E0B4E
	v_dot2acc_f32_f16 v29, v78, v9                             // 000000A417E4: 043A134E
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A417E8: CC0E0050 0BFC0B50 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A417F4: BF870244
	v_and_or_b32 v76, 0xffff, v81, v76                         // 000000A417F8: D657004C 0532A2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v31, v77, v2 :: v_dual_dot2acc_f32_f16 v32, v83, v15// 000000A41804: CB18054D 1F201F53
	v_dot2acc_f32_f16 v30, v77, v6                             // 000000A4180C: 043C0D4D
	v_dot2acc_f32_f16 v29, v77, v10                            // 000000A41810: 043A154D
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A41814: CC0E004C 0BFC0B4C 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A41820: BF870214
	v_dual_dot2acc_f32_f16 v31, v80, v3 :: v_dual_dot2acc_f32_f16 v32, v79, v16// 000000A41824: CB180750 1F20214F
	v_dot2acc_f32_f16 v30, v80, v7                             // 000000A4182C: 043C0F50
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A41830: BF870194
	v_dual_dot2acc_f32_f16 v29, v80, v11 :: v_dual_dot2acc_f32_f16 v28, v78, v13// 000000A41834: CB181750 1D1C1B4E
	v_dual_dot2acc_f32_f16 v31, v76, v4 :: v_dual_and_b32 v78, 0xffff, v59// 000000A4183C: CB24094C 1F4E76FF 0000FFFF
	v_dot2acc_f32_f16 v34, v79, v8                             // 000000A41848: 0444114F
	v_bfe_u32 v79, v59, 8, 16                                  // 000000A4184C: D610004F 0241113B
	v_bfe_u32 v59, v59, 4, 16                                  // 000000A41854: D610003B 0241093B
	s_waitcnt vmcnt(0)                                         // 000000A4185C: BF8903F7
	v_bfe_u32 v81, v58, 12, 16                                 // 000000A41860: D6100051 0241193A
	.long 0xd72c004e                                           // 000000A41868: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A4186C: 02029CFF 83DCD12D
	v_bfe_u32 v82, v58, 8, 16                                  // 000000A41874: D6100052 0241113A
	.long 0xd72c004f                                           // 000000A4187C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A41880: 02029EFF 83DCD12D
	.long 0xd72c003b                                           // 000000A41888: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A4188C: 020276FF 83DCD12D
	.long 0xd72c0051                                           // 000000A41894: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A41898: 0202A2FF 83DCD12D
	v_dot2acc_f32_f16 v29, v76, v12                            // 000000A418A0: 043A194C
	.long 0xd72c0052                                           // 000000A418A4: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A418A8: 0202A4FF 83DCD12D
	v_bfe_u32 v83, v58, 4, 16                                  // 000000A418B0: D6100053 0241093A
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A418B8: D622004E 03FD014E 00006400
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A418C4: 367474FF 0000FFFF
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A418CC: D622004F 03FD014F 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A418D8: D622003B 03FD013B 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A418E4: D6220051 03FD0151 00006400
	v_lshlrev_b32_e32 v78, 16, v78                             // 000000A418F0: 309C9C90
	v_dot2acc_f32_f16 v30, v76, v8                             // 000000A418F4: 043C114C
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A418F8: D6220052 03FD0152 00006400
	.long 0xd72c003a                                           // 000000A41904: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A41908: 020274FF 83DCD12D
	v_and_b32_e32 v81, 0xffff, v81                             // 000000A41910: 36A2A2FF 0000FFFF
	v_and_or_b32 v59, 0xffff, v59, v78                         // 000000A41918: D657003B 053A76FF 0000FFFF
	v_mov_b32_e32 v85, v72                                     // 000000A41924: 7EAA0348
	v_mov_b32_e32 v89, v65                                     // 000000A41928: 7EB20341
	v_mov_b32_e32 v87, v72                                     // 000000A4192C: 7EAE0348
	v_lshl_or_b32 v78, v82, 16, v81                            // 000000A41930: D656004E 05452152
	v_pk_fma_f16 v59, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A41938: CC0E003B 0BFC0B3B 0000C931
	v_and_b32_e32 v60, 0xffff, v60                             // 000000A41944: 367878FF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A4194C: D622003A 03FD013A 00006400
	v_mov_b32_e32 v81, v70                                     // 000000A41958: 7EA20346
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A4195C: CC0E004E 0BFC0B4E 0000C931
	v_mov_b32_e32 v86, v64                                     // 000000A41968: 7EAC0340
	v_lshl_or_b32 v60, v79, 16, v60                            // 000000A4196C: D656003C 04F1214F
	v_dual_mov_b32 v79, v70 :: v_dual_lshlrev_b32 v58, 16, v58 // 000000A41974: CA220146 4F3A7490
	v_mov_b32_e32 v88, v73                                     // 000000A4197C: 7EB00349
	v_mov_b32_e32 v90, v73                                     // 000000A41980: 7EB40349
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A41984: BF870124
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A41988: CC0E003C 0BFC0B3C 0000C931
	v_mov_b32_e32 v84, v71                                     // 000000A41994: 7EA80347
	v_dual_mov_b32 v82, v71 :: v_dual_dot2acc_f32_f16 v23, v60, v5// 000000A41998: CA180147 52160B3C
	v_dot2acc_f32_f16 v26, v60, v1                             // 000000A419A0: 0434033C
	v_dot2acc_f32_f16 v22, v60, v9                             // 000000A419A4: 042C133C
	v_dot2acc_f32_f16 v20, v60, v13                            // 000000A419A8: 04281B3C
	v_mov_b32_e32 v60, v67                                     // 000000A419AC: 7E780343
	v_dot2acc_f32_f16 v23, v59, v6                             // 000000A419B0: 042E0D3B
	v_dot2acc_f32_f16 v28, v77, v14                            // 000000A419B4: 04381D4D
	.long 0xd72c004d                                           // 000000A419B8: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A419BC: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v26, v59, v2                             // 000000A419C4: 0434053B
	v_dot2acc_f32_f16 v22, v59, v10                            // 000000A419C8: 042C153B
	v_dual_dot2acc_f32_f16 v20, v59, v14 :: v_dual_dot2acc_f32_f16 v23, v78, v7// 000000A419CC: CB181D3B 14160F4E
	v_mov_b32_e32 v2, v66                                      // 000000A419D4: 7E040342
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A419D8: BF870254
	v_dual_dot2acc_f32_f16 v26, v78, v3 :: v_dual_mov_b32 v3, v75// 000000A419DC: CB10074E 1A02014B
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A419E4: D622004D 03FD014D 00006400
	v_dual_dot2acc_f32_f16 v22, v78, v11 :: v_dual_mov_b32 v83, v63// 000000A419F0: CB10174E 1652013F
	v_dot2acc_f32_f16 v20, v78, v15                            // 000000A419F8: 04281F4E
	v_mov_b32_e32 v78, v69                                     // 000000A419FC: 7E9C0345
	v_and_or_b32 v1, 0xffff, v77, v58                          // 000000A41A00: D6570001 04EA9AFF 0000FFFF
	v_mov_b32_e32 v77, v61                                     // 000000A41A0C: 7E9A033D
	v_dual_mov_b32 v59, v18 :: v_dual_mov_b32 v58, v67         // 000000A41A10: CA100112 3B3A0143
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A41A18: BF8701B3
	v_pk_fma_f16 v1, v1, s5, 0xc931 op_sel_hi:[1,0,0]          // 000000A41A1C: CC0E0001 0BFC0B01 0000C931
	v_dot2acc_f32_f16 v28, v80, v15                            // 000000A41A28: 04381F50
	v_mov_b32_e32 v80, v62                                     // 000000A41A2C: 7EA0033E
	v_dot2acc_f32_f16 v26, v1, v4                              // 000000A41A30: 04340901
	v_dot2acc_f32_f16 v23, v1, v8                              // 000000A41A34: 042E1101
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A41A38: BF870004
	v_dot2acc_f32_f16 v28, v76, v16                            // 000000A41A3C: 0438214C
	v_dot2acc_f32_f16 v22, v1, v12                             // 000000A41A40: 042C1901
	v_dot2acc_f32_f16 v20, v1, v16                             // 000000A41A44: 04282101
	v_mov_b32_e32 v4, v75                                      // 000000A41A48: 7E08034B
	v_mov_b32_e32 v76, v69                                     // 000000A41A4C: 7E980345
	v_mov_b32_e32 v1, v17                                      // 000000A41A50: 7E020311
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A41A54: 917E047E
	s_cbranch_execz 58                                         // 000000A41A58: BFA5003A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1c44>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A41A5C: BF8700A1
	v_add_nc_u32_e32 v17, 1, v1                                // 000000A41A60: 4A220281
	s_mov_b32 s6, exec_lo                                      // 000000A41A64: BE86007E
	.long 0xd4c1007e                                           // 000000A41A68: D4C1007E
	v_cndmask_b32_e32 v1, v17, v21, vcc_lo                     // 000000A41A6C: 02022B11
	s_cbranch_execz 64555                                      // 000000A41A70: BFA5FC2B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xc20>
	v_ashrrev_i32_e32 v18, 31, v17                             // 000000A41A74: 3424229F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A41A78: BF870091
	.long 0xd73c0005                                           // 000000A41A7C: D73C0005
	v_cndmask_b32_e32 v1, 10, v17, vcc_lo                      // 000000A41A80: 0202228A
	.long 0xd7006a07                                           // 000000A41A84: D7006A07
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000A41A88: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A41A8C: BF870111
	v_add_co_ci_u32_e64 v8, null, s3, v6, vcc_lo               // 000000A41A90: D5207C08 01AA0C03
	.long 0xd7006a05                                           // 000000A41A98: D7006A05
	v_cndmask_b32_e32 v1, v7, v57, vcc_lo                      // 000000A41A9C: 02027307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A41AA0: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v8, vcc_lo                // 000000A41AA4: D5207C06 01AA1080
	.long 0xd7006a07                                           // 000000A41AAC: D7006A07
	v_cndmask_b32_e32 v1, v7, v56, vcc_lo                      // 000000A41AB0: 02027107
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 000000A41AB4: D5207C08 01AA1080
	s_clause 0xf                                               // 000000A41ABC: BF85000F
	global_load_b32 v66, v[5:6], off                           // 000000A41AC0: DC520000 427C0005
	global_load_b32 v68, v[5:6], off offset:128                // 000000A41AC8: DC520080 447C0005
	global_load_b32 v65, v[5:6], off offset:256                // 000000A41AD0: DC520100 417C0005
	global_load_b32 v64, v[5:6], off offset:384                // 000000A41AD8: DC520180 407C0005
	global_load_b32 v63, v[5:6], off offset:512                // 000000A41AE0: DC520200 3F7C0005
	global_load_b32 v62, v[5:6], off offset:640                // 000000A41AE8: DC520280 3E7C0005
	global_load_b32 v61, v[5:6], off offset:768                // 000000A41AF0: DC520300 3D7C0005
	global_load_b32 v18, v[5:6], off offset:896                // 000000A41AF8: DC520380 127C0005
	global_load_b32 v75, v[7:8], off                           // 000000A41B00: DC520000 4B7C0007
	global_load_b32 v74, v[7:8], off offset:128                // 000000A41B08: DC520080 4A7C0007
	global_load_b32 v73, v[7:8], off offset:256                // 000000A41B10: DC520100 497C0007
	global_load_b32 v72, v[7:8], off offset:384                // 000000A41B18: DC520180 487C0007
	global_load_b32 v71, v[7:8], off offset:512                // 000000A41B20: DC520200 477C0007
	global_load_b32 v70, v[7:8], off offset:640                // 000000A41B28: DC520280 467C0007
	global_load_b32 v69, v[7:8], off offset:768                // 000000A41B30: DC520300 457C0007
	global_load_b32 v67, v[7:8], off offset:896                // 000000A41B38: DC520380 437C0007
	s_branch 64503                                             // 000000A41B40: BFA0FBF7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xc20>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A41B44: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A41B48: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A41B4C: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 000000A41B50: BF895FF7
	v_dual_mov_b32 v1, v54 :: v_dual_mov_b32 v2, v43           // 000000A41B54: CA100136 0102012B
	s_waitcnt vmcnt(7)                                         // 000000A41B5C: BF891FF7
	v_dual_mov_b32 v3, v52 :: v_dual_mov_b32 v4, v49           // 000000A41B60: CA100134 03040131
	v_dual_mov_b32 v5, v47 :: v_dual_mov_b32 v10, v48          // 000000A41B68: CA10012F 050A0130
	v_dual_mov_b32 v7, v53 :: v_dual_mov_b32 v8, v51           // 000000A41B70: CA100135 07080133
	v_dual_mov_b32 v9, v50 :: v_dual_mov_b32 v6, v27           // 000000A41B78: CA100132 0906011B
	v_dual_mov_b32 v11, v46 :: v_dual_mov_b32 v12, v45         // 000000A41B80: CA10012E 0B0C012D
	v_dual_mov_b32 v13, v44 :: v_dual_mov_b32 v14, v42         // 000000A41B88: CA10012C 0D0E012A
	v_dual_mov_b32 v15, v41 :: v_dual_mov_b32 v16, v40         // 000000A41B90: CA100129 0F100128
	v_dual_mov_b32 v17, v39 :: v_dual_mov_b32 v18, v38         // 000000A41B98: CA100127 11120126
	v_dual_mov_b32 v21, v37 :: v_dual_mov_b32 v56, v35         // 000000A41BA0: CA100125 15380123
	s_waitcnt vmcnt(0)                                         // 000000A41BA8: BF8903F7
	v_dual_mov_b32 v55, v36 :: v_dual_mov_b32 v58, v33         // 000000A41BAC: CA100124 373A0121
	v_dual_mov_b32 v57, v34 :: v_dual_mov_b32 v60, v31         // 000000A41BB4: CA100122 393C011F
	v_dual_mov_b32 v59, v32 :: v_dual_mov_b32 v62, v29         // 000000A41BBC: CA100120 3B3E011D
	v_mov_b32_e32 v61, v30                                     // 000000A41BC4: 7E7A031E
	v_dual_mov_b32 v63, v28 :: v_dual_mov_b32 v64, v26         // 000000A41BC8: CA10011C 3F40011A
	v_dual_mov_b32 v65, v23 :: v_dual_mov_b32 v66, v22         // 000000A41BD0: CA100117 41420116
	v_mov_b32_e32 v67, v20                                     // 000000A41BD8: 7E860314
	s_mov_b32 s0, 0x76543210                                   // 000000A41BDC: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A41BE4: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000A41BE8: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000A41BF4: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000A41C00: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000A41C0C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000A41C18: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000A41C24: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000A41C30: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000A41C3C: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000A41C48: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000A41C54: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000A41C60: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000A41C6C: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000A41C78: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000A41C84: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000A41C90: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000A41C9C: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000A41CA8: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 000000A41CB4: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v21, v21, s0, 0xfedcba98                 // 000000A41CC0: D65C0015 03FC0115 FEDCBA98
	v_permlanex16_b32 v55, v55, s0, 0xfedcba98                 // 000000A41CCC: D65C0037 03FC0137 FEDCBA98
	v_permlanex16_b32 v56, v56, s0, 0xfedcba98                 // 000000A41CD8: D65C0038 03FC0138 FEDCBA98
	v_permlanex16_b32 v57, v57, s0, 0xfedcba98                 // 000000A41CE4: D65C0039 03FC0139 FEDCBA98
	v_permlanex16_b32 v58, v58, s0, 0xfedcba98                 // 000000A41CF0: D65C003A 03FC013A FEDCBA98
	v_permlanex16_b32 v59, v59, s0, 0xfedcba98                 // 000000A41CFC: D65C003B 03FC013B FEDCBA98
	v_permlanex16_b32 v60, v60, s0, 0xfedcba98                 // 000000A41D08: D65C003C 03FC013C FEDCBA98
	v_permlanex16_b32 v61, v61, s0, 0xfedcba98                 // 000000A41D14: D65C003D 03FC013D FEDCBA98
	v_permlanex16_b32 v62, v62, s0, 0xfedcba98                 // 000000A41D20: D65C003E 03FC013E FEDCBA98
	v_permlanex16_b32 v63, v63, s0, 0xfedcba98                 // 000000A41D2C: D65C003F 03FC013F FEDCBA98
	v_permlanex16_b32 v64, v64, s0, 0xfedcba98                 // 000000A41D38: D65C0040 03FC0140 FEDCBA98
	v_permlanex16_b32 v65, v65, s0, 0xfedcba98                 // 000000A41D44: D65C0041 03FC0141 FEDCBA98
	v_permlanex16_b32 v66, v66, s0, 0xfedcba98                 // 000000A41D50: D65C0042 03FC0142 FEDCBA98
	v_permlanex16_b32 v67, v67, s0, 0xfedcba98                 // 000000A41D5C: D65C0043 03FC0143 FEDCBA98
	.long 0xd44c0000                                           // 000000A41D68: D44C0000
	v_cndmask_b32_e32 v1, 16, v25, vcc_lo                      // 000000A41D6C: 02023290
	s_barrier                                                  // 000000A41D70: BFBD0000
	buffer_gl0_inv                                             // 000000A41D74: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000A41D7C: BE812000
	s_cbranch_execz 73                                         // 000000A41D80: BFA50049 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1fa8>
	v_lshl_or_b32 v19, v24, 11, v19                            // 000000A41D84: D6560013 044D1718
	v_dual_add_f32 v32, v32, v59 :: v_dual_add_f32 v21, v37, v21// 000000A41D8C: C9087720 20142B25
	v_dual_add_f32 v10, v48, v10 :: v_dual_add_f32 v5, v47, v5 // 000000A41D94: C9081530 0A040B2F
	v_dual_add_f32 v4, v49, v4 :: v_dual_add_f32 v1, v54, v1   // 000000A41D9C: C9080931 04000336
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A41DA4: BF870004
	v_dual_add_f32 v2, v43, v2 :: v_dual_add_nc_u32 v37, 0x5400, v19// 000000A41DA8: C920052B 022426FF 00005400
	v_dual_add_f32 v18, v38, v18 :: v_dual_add_f32 v13, v44, v13// 000000A41DB4: C9082526 120C1B2C
	v_dual_add_f32 v14, v42, v14 :: v_dual_add_f32 v7, v53, v7 // 000000A41DBC: C9081D2A 0E060F35
	v_dual_add_f32 v8, v51, v8 :: v_dual_add_f32 v3, v52, v3   // 000000A41DC4: C9081133 08020734
	v_add_nc_u32_e32 v38, 0x5800, v19                          // 000000A41DCC: 4A4C26FF 00005800
	v_dual_add_f32 v12, v45, v12 :: v_dual_add_f32 v9, v50, v9 // 000000A41DD4: C908192D 0C081332
	v_dual_add_f32 v6, v27, v6 :: v_dual_add_nc_u32 v19, 0x5c00, v19// 000000A41DDC: C9200D1B 061226FF 00005C00
	v_dual_add_f32 v20, v20, v67 :: v_dual_add_f32 v23, v23, v65// 000000A41DE8: C9088714 14168317
	v_dual_add_f32 v22, v22, v66 :: v_dual_add_f32 v31, v31, v60// 000000A41DF0: C9088516 161E791F
	v_dual_add_f32 v26, v26, v64 :: v_dual_add_f32 v29, v29, v62// 000000A41DF8: C908811A 1A1C7D1D
	v_dual_add_f32 v28, v28, v63 :: v_dual_add_f32 v33, v33, v58// 000000A41E00: C9087F1C 1C207521
	v_dual_add_f32 v30, v30, v61 :: v_dual_add_f32 v35, v35, v56// 000000A41E08: C9087B1E 1E227123
	v_dual_add_f32 v34, v34, v57 :: v_dual_add_f32 v15, v41, v15// 000000A41E10: C9087322 220E1F29
	v_dual_add_f32 v36, v36, v55 :: v_dual_add_f32 v17, v39, v17// 000000A41E18: C9086F24 24102327
	v_dual_add_f32 v16, v40, v16 :: v_dual_add_f32 v11, v46, v11// 000000A41E20: C9082128 100A172E
	ds_store_2addr_b32 v37, v1, v5 offset0:128 offset1:144     // 000000A41E28: D8389080 00050125
	ds_store_2addr_b32 v38, v3, v7 offset1:16                  // 000000A41E30: D8381000 00070326
	ds_store_2addr_b32 v38, v2, v8 offset0:128 offset1:144     // 000000A41E38: D8389080 00080226
	ds_store_2addr_b32 v19, v4, v9 offset1:16                  // 000000A41E40: D8381000 00090413
	ds_store_2addr_b32 v37, v6, v13 offset0:160 offset1:176    // 000000A41E48: D838B0A0 000D0625
	ds_store_2addr_b32 v38, v10, v14 offset0:32 offset1:48     // 000000A41E50: D8383020 000E0A26
	ds_store_2addr_b32 v38, v11, v15 offset0:160 offset1:176   // 000000A41E58: D838B0A0 000F0B26
	ds_store_2addr_b32 v19, v12, v16 offset0:32 offset1:48     // 000000A41E60: D8383020 00100C13
	ds_store_2addr_b32 v37, v17, v35 offset0:192 offset1:208   // 000000A41E68: D838D0C0 00231125
	ds_store_2addr_b32 v38, v18, v34 offset0:64 offset1:80     // 000000A41E70: D8385040 00221226
	ds_store_2addr_b32 v38, v21, v33 offset0:192 offset1:208   // 000000A41E78: D838D0C0 00211526
	ds_store_2addr_b32 v19, v36, v32 offset0:64 offset1:80     // 000000A41E80: D8385040 00202413
	ds_store_2addr_b32 v37, v31, v26 offset0:224 offset1:240   // 000000A41E88: D838F0E0 001A1F25
	ds_store_2addr_b32 v38, v30, v23 offset0:96 offset1:112    // 000000A41E90: D8387060 00171E26
	ds_store_2addr_b32 v38, v29, v22 offset0:224 offset1:240   // 000000A41E98: D838F0E0 00161D26
	ds_store_2addr_b32 v19, v28, v20 offset0:96 offset1:112    // 000000A41EA0: D8387060 00141C13
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A41EA8: 8C7E017E
	.long 0xd44c0001                                           // 000000A41EAC: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000A41EB0: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 000000A41EB8: BF89FC07
	s_barrier                                                  // 000000A41EBC: BFBD0000
	buffer_gl0_inv                                             // 000000A41EC0: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000A41EC8: BE832001
	s_cbranch_execz 47                                         // 000000A41ECC: BFA5002F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x208c>
	v_mov_b32_e32 v1, v0                                       // 000000A41ED0: 7E020300
	s_mov_b32 s4, 0                                            // 000000A41ED4: BE840080
	s_nop 0                                                    // 000000A41ED8: BF800000
	s_nop 0                                                    // 000000A41EDC: BF800000
	s_nop 0                                                    // 000000A41EE0: BF800000
	s_nop 0                                                    // 000000A41EE4: BF800000
	s_nop 0                                                    // 000000A41EE8: BF800000
	s_nop 0                                                    // 000000A41EEC: BF800000
	s_nop 0                                                    // 000000A41EF0: BF800000
	s_nop 0                                                    // 000000A41EF4: BF800000
	s_nop 0                                                    // 000000A41EF8: BF800000
	s_nop 0                                                    // 000000A41EFC: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A41F00: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000A41F04: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 000000A41F08: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:86 offset1:94// 000000A41F10: D8E05E56 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:102 offset1:110// 000000A41F18: D8E06E66 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:118 offset1:126// 000000A41F20: D8E07E76 06000008
	s_or_b32 s4, vcc_lo, s4                                    // 000000A41F28: 8C04046A
	s_waitcnt lgkmcnt(2)                                       // 000000A41F2C: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 000000A41F30: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000A41F34: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000A41F38: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:134 offset1:142// 000000A41F3C: D8E08E86 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000A41F44: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000A41F48: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 000000A41F4C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 000000A41F50: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A41F54: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000A41F58: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 000000A41F5C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 000000A41F60: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A41F64: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 000000A41F68: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 000000A41F6C: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 000000A41F74: C9100702 02000104
	ds_store_b32 v8, v2 offset:38400                           // 000000A41F7C: D8349600 00000208
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A41F84: 917E047E
	s_cbranch_execnz 65501                                     // 000000A41F88: BFA6FFDD <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2000>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A41F8C: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 000000A41F90: BF048209
	s_mov_b32 s3, -1                                           // 000000A41F94: BE8300C1
	s_cbranch_scc1 212                                         // 000000A41F98: BFA200D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x23ec>
	s_waitcnt lgkmcnt(0)                                       // 000000A41F9C: BF89FC07
	s_barrier                                                  // 000000A41FA0: BFBD0000
	buffer_gl0_inv                                             // 000000A41FA4: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000A41FAC: BE832001
	s_cbranch_execz 71                                         // 000000A41FB0: BFA50047 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x21d0>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000A41FB4: 32020087
	s_ashr_i32 s29, s28, 31                                    // 000000A41FB8: 861D9F1C
	s_ashr_i32 s31, s30, 31                                    // 000000A41FBC: 861F9F1E
	s_lshl_b64 s[4:5], s[28:29], 2                             // 000000A41FC0: 8484821C
	s_lshl_b32 s6, s10, 7                                      // 000000A41FC4: 8406870A
	v_or_b32_e32 v1, s4, v1                                    // 000000A41FC8: 38020204
	v_mov_b32_e32 v2, s5                                       // 000000A41FCC: 7E040205
	s_lshl_b64 s[4:5], s[30:31], 2                             // 000000A41FD0: 8484821E
	s_ashr_i32 s7, s6, 31                                      // 000000A41FD4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A41FD8: BF8700A9
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000A41FDC: 84868206
	.long 0xd7016a01                                           // 000000A41FE0: D7016A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000A41FE4: 02000901
	v_subrev_co_ci_u32_e64 v2, null, s5, v2, vcc_lo            // 000000A41FE8: D5227C02 01AA0405
	s_ashr_i32 s5, s49, 31                                     // 000000A41FF0: 86059F31
	s_mov_b32 s4, s49                                          // 000000A41FF4: BE840031
	.long 0xd72c0004                                           // 000000A41FF8: D72C0004
	v_cndmask_b32_e32 v0, v1, v5, vcc_lo                       // 000000A41FFC: 02000B01
	.long 0xd72c0003                                           // 000000A42000: D72C0003
	v_cndmask_b32_e32 v0, v2, v49, vcc_lo                      // 000000A42004: 02006302
	v_mad_u64_u32 v[1:2], null, v1, s49, 0                     // 000000A42008: D6FE7C01 02006301
	s_lshl_b64 s[4:5], s[4:5], 3                               // 000000A42010: 84848304
	v_add3_u32 v2, v2, v4, v3                                  // 000000A42014: D6550002 040E0902
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000A4201C: 360600FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A42024: BF870112
	.long 0xd73c0001                                           // 000000A42028: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000A4202C: 02020282
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000A42030: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000A42034: 30060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A42038: BF870093
	.long 0xd7006a01                                           // 000000A4203C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000A42040: 02000D01
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000A42044: D5207C02 01AA0407
	s_mov_b32 s6, 0                                            // 000000A4204C: BE860080
	.long 0xd7006a01                                           // 000000A42050: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 000000A42054: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A42058: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000A4205C: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 000000A42064: 380800FF FFFFFF00
	.long 0xd7006a01                                           // 000000A4206C: D7006A01
	v_cndmask_b32_e32 v1, s44, v1, vcc_lo                      // 000000A42070: 0202022C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A42074: BF870001
	v_add_co_ci_u32_e64 v2, null, s45, v2, vcc_lo              // 000000A42078: D5207C02 01AA042D
	ds_load_b32 v5, v3 offset:38400                            // 000000A42080: D8D89600 05000003
	.long 0xd7000704                                           // 000000A42088: D7000704
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 000000A4208C: 020208FF 00000100
	s_xor_b32 s7, s7, -1                                       // 000000A42094: 8D07C107
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000A42098: 4A0606FF 00000400
	s_and_b32 s7, exec_lo, s7                                  // 000000A420A0: 8B07077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000A420A4: BF8700C9
	s_or_b32 s6, s7, s6                                        // 000000A420A8: 8C060607
	s_waitcnt lgkmcnt(0)                                       // 000000A420AC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 000000A420B0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 000000A420B8: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000A420BC: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000A420C0: D5207C02 01AA0405
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000A420C8: 917E067E
	s_cbranch_execnz 65516                                     // 000000A420CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2180>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A420D0: 8C7E037E
	.long 0xd44a0003                                           // 000000A420D4: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000A420D8: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000A420DC: BC7C0000
	buffer_gl1_inv                                             // 000000A420E0: E0B00000 00000000
	buffer_gl0_inv                                             // 000000A420E8: E0AC0000 00000000
	s_barrier                                                  // 000000A420F0: BFBD0000
	buffer_gl0_inv                                             // 000000A420F4: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 000000A420FC: BE842003
	s_cbranch_execz 29                                         // 000000A42100: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2278>
	s_mov_b32 s6, exec_lo                                      // 000000A42104: BE86007E
	s_mov_b32 s5, exec_lo                                      // 000000A42108: BE85007E
	.long 0xd71f0001                                           // 000000A4210C: D71F0001
	v_cndmask_b32_e32 v0, s6, v128, vcc_lo                     // 000000A42110: 02010006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A42114: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000A42118: 7D940280
	s_cbranch_execz 9                                          // 000000A4211C: BFA50009 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2244>
	s_lshl_b64 s[24:25], s[10:11], 2                           // 000000A42120: 8498820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000A42124: BF8704B9
	s_add_u32 s24, s46, s24                                    // 000000A42128: 8018182E
	s_addc_u32 s25, s47, s25                                   // 000000A4212C: 8219192F
	s_bcnt1_i32_b32 s6, s6                                     // 000000A42130: BE861806
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s6              // 000000A42134: CA100080 02020006
	global_atomic_add_u32 v2, v2, v3, s[24:25] glc             // 000000A4213C: DCD64000 02180302
	s_or_b32 exec_lo, exec_lo, s5                              // 000000A42144: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 000000A42148: BF8903F7
	v_readfirstlane_b32 s5, v2                                 // 000000A4214C: 7E0A0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A42150: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s5, v1       // 000000A42154: CA200080 02000205
	s_add_i32 s5, s9, -1                                       // 000000A4215C: 8105C109
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000A42160: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s5, v1                            // 000000A42164: 7C940205
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000A42168: D5010001 01A90280
	ds_store_b32 v2, v1 offset:42496                           // 000000A42170: D834A600 00000102
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A42178: 8C7E047E
	v_mov_b32_e32 v1, 0                                        // 000000A4217C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000A42180: BF89FC07
	s_barrier                                                  // 000000A42184: BFBD0000
	buffer_gl0_inv                                             // 000000A42188: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:42496                            // 000000A42190: D8D8A600 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000A42198: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000A4219C: 7C940280
	s_cbranch_vccnz 4223                                       // 000000A421A0: BFA4107F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x64a0>
	buffer_gl1_inv                                             // 000000A421A4: E0B00000 00000000
	buffer_gl0_inv                                             // 000000A421AC: E0AC0000 00000000
	s_and_saveexec_b32 s8, s1                                  // 000000A421B4: BE882001
	s_cbranch_execz 65                                         // 000000A421B8: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x23c0>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000A421BC: 32020087
	s_lshl_b32 s4, s10, 7                                      // 000000A421C0: 8404870A
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000A421C4: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 000000A421CC: 86059F04
	v_mov_b32_e32 v5, v0                                       // 000000A421D0: 7E0A0300
	v_mad_i64_i32 v[1:2], null, v1, s49, 0                     // 000000A421D4: D6FF7C01 02006301
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000A421DC: 84848204
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000A421E0: 30060682
	s_ashr_i32 s7, s49, 31                                     // 000000A421E4: 86079F31
	s_mov_b32 s6, s49                                          // 000000A421E8: BE860031
	s_mov_b32 s24, 0                                           // 000000A421EC: BE980080
	.long 0xd73c0001                                           // 000000A421F0: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000A421F4: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A421F8: BF870091
	.long 0xd7006a01                                           // 000000A421FC: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000A42200: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000A42204: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[6:7], 3                               // 000000A4220C: 84848306
	.long 0xd7006a01                                           // 000000A42210: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000A42214: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A42218: BF8700B1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000A4221C: D5207C02 01AA0480
	s_lshl_b64 s[6:7], s[6:7], 4                               // 000000A42224: 84868406
	.long 0xd7006a01                                           // 000000A42228: D7006A01
	v_cndmask_b32_e32 v1, s44, v1, vcc_lo                      // 000000A4222C: 0202022C
	v_add_co_ci_u32_e64 v2, null, s45, v2, vcc_lo              // 000000A42230: D5207C02 01AA042D
	s_nop 0                                                    // 000000A42238: BF800000
	s_nop 0                                                    // 000000A4223C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A42240: BF870001
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 000000A42244: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 000000A4224C: 7E0C0280
	s_mov_b32 s1, s9                                           // 000000A42250: BE810009
	global_load_b32 v7, v[3:4], off glc                        // 000000A42254: DC524000 077C0003
	.long 0xd7006a03                                           // 000000A4225C: D7006A03
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 000000A42260: 02000D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000A42264: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s7, v4, vcc_lo               // 000000A42268: D5207C04 01AA0807
	s_add_i32 s1, s1, -1                                       // 000000A42270: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 000000A42274: BF068001
	s_waitcnt vmcnt(0)                                         // 000000A42278: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 000000A4227C: 060C0F06
	s_cbranch_scc0 65524                                       // 000000A42280: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2354>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 000000A42284: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 000000A4228C: 7C920AFF 000000FF
	.long 0xd7000101                                           // 000000A42294: D7000101
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000A42298: 02000901
	v_lshlrev_b32_e32 v3, 2, v5                                // 000000A4229C: 30060A82
	v_add_co_ci_u32_e64 v2, null, s5, v2, s1                   // 000000A422A0: D5207C02 00060405
	v_mov_b32_e32 v5, v4                                       // 000000A422A8: 7E0A0304
	s_or_b32 s24, vcc_lo, s24                                  // 000000A422AC: 8C18186A
	ds_store_b32 v3, v6 offset:38400                           // 000000A422B0: D8349600 00000603
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 000000A422B8: 917E187E
	s_cbranch_execnz 65504                                     // 000000A422BC: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2340>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000A422C0: 8C7E087E
	s_and_saveexec_b32 s1, s3                                  // 000000A422C4: BE812003
	s_cbranch_execz 6                                          // 000000A422C8: BFA50006 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x23e4>
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000A422CC: 8484820A
	v_mov_b32_e32 v1, 0                                        // 000000A422D0: 7E020280
	s_add_u32 s4, s46, s4                                      // 000000A422D4: 8004042E
	s_addc_u32 s5, s47, s5                                     // 000000A422D8: 8205052F
	global_store_b32 v1, v1, s[4:5]                            // 000000A422DC: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A422E4: 8C7E017E
	s_mov_b32 s3, -1                                           // 000000A422E8: BE8300C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A422EC: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000A422F0: 8B6A037E
	s_cbranch_vccz 382                                         // 000000A422F4: BFA3017E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x29f0>
	v_cmp_gt_i32_e32 vcc_lo, s48, v24                          // 000000A422F8: 7C883030
	.long 0xd44c0001                                           // 000000A422FC: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000A42300: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000A42308: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000A4230C: BC7C0000
	s_barrier                                                  // 000000A42310: BFBD0000
	buffer_gl0_inv                                             // 000000A42314: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 000000A4231C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A42320: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000A42324: BE832001
	s_cbranch_execz 368                                        // 000000A42328: BFA50170 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x29ec>
	v_and_b32_e32 v1, 15, v0                                   // 000000A4232C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A42330: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000A42334: 30040282
	v_lshl_or_b32 v2, v24, 9, v2                               // 000000A42338: D6560002 04091318
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A42340: BF870001
	v_add_nc_u32_e32 v8, 0x9400, v2                            // 000000A42344: 4A1004FF 00009400
	ds_load_2addr_b32 v[2:3], v8 offset0:128 offset1:144       // 000000A4234C: D8DC9080 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:160 offset1:176       // 000000A42354: D8DCB0A0 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:192 offset1:208       // 000000A4235C: D8DCD0C0 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:224 offset1:240       // 000000A42364: D8DCF0E0 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000A4236C: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 000000A42370: 36160082
	s_waitcnt lgkmcnt(3)                                       // 000000A42374: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 000000A42378: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000A42380: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000A42384: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000A4238C: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000A42390: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000A42398: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000A4239C: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000A423A4: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000A423AC: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A423B0: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000A423B4: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 000000A423BC: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000A423C4: 7C941480
	.long 0xd44a0001                                           // 000000A423C8: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000A423CC: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000A423D0: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000A423D8: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000A423DC: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A423E0: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 000000A423E4: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000A423E8: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000A423F0: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000A423F4: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000A423F8: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A423FC: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000A42404: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A4240C: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000A42414: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A4241C: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000A42424: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A4242C: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000A42434: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A4243C: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000A42444: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A4244C: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000A42454: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A4245C: 7E2402FA FF016103
	v_cndmask_b32_e64 v19, -v3, v3, vcc_lo                     // 000000A42464: D5010013 21AA0703
	v_cndmask_b32_e64 v21, -v2, v2, vcc_lo                     // 000000A4246C: D5010015 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 000000A42474: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 000000A42478: C9080D07 03082108
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A42480: 7E2802FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 000000A42488: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A42490: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A42494: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000A4249C: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 000000A424A4: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A424A8: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000A424B0: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A424B8: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 000000A424C0: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A424C4: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000A424CC: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 000000A424D4: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000A424D8: D5010008 21AA1108
	v_add_f32_e32 v13, v21, v20                                // 000000A424E0: 061A2915
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A424E4: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 000000A424EC: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A424F0: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000A424F8: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000A42500: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 000000A42508: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A4250C: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000A42514: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 000000A4251C: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A42520: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000A42528: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 000000A42530: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A42534: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A4253C: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 000000A42544: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 000000A42548: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 000000A4254C: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A42554: 7E0402FA FF016402
	v_add_f32_e32 v6, v6, v11                                  // 000000A4255C: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A42560: 7E1602FA FF016408
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 000000A42568: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A42570: BF870234
	v_add_f32_e32 v7, v7, v2                                   // 000000A42574: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A42578: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A42580: D5010004 20060904
	v_add_f32_e32 v14, v14, v11                                // 000000A42588: 061C170E
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A4258C: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A42594: 7E0A02FA FF016807
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A4259C: 7E1002FA FF016806
	v_add_f32_e32 v4, v4, v10                                  // 000000A425A4: 06081504
	v_add_f32_e32 v10, v19, v18                                // 000000A425A8: 06142513
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A425AC: BF8700A1
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A425B0: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000A425B8: D501000A 21AA150A
	v_add_f32_e32 v10, v10, v12                                // 000000A425C0: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 000000A425C4: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A425C8: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A425D0: D5010009 20061309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A425D8: BF870214
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A425DC: 7E1E02FA FF01640A
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A425E4: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A425EC: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000A425F4: D501000C 2006190C
	v_add_f32_e32 v16, v9, v13                                 // 000000A425FC: 06201B09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A42600: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A42608: BF870214
	v_add_f32_e32 v15, v10, v15                                // 000000A4260C: 061E1F0A
	v_add_f32_e32 v17, v12, v17                                // 000000A42610: 0622230C
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A42614: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A4261C: 7E1602FA FF016810
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A42624: BF870214
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A42628: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A42630: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 000000A42638: 8B7E007E
	s_cbranch_execz 171                                        // 000000A4263C: BFA500AB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x29ec>
	v_lshl_or_b32 v18, s10, 7, v1                              // 000000A42640: D6560012 04050E0A
	v_and_b32_e32 v1, 8, v0                                    // 000000A42648: 36020088
	.long 0x7f2c3880                                           // 000000A4264C: 7F2C3880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A42650: BF870113
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000A42654: 3426249F
	.long 0x7f363996                                           // 000000A42658: 7F363996
	.long 0x7f2e3996                                           // 000000A4265C: 7F2E3996
	.long 0x7f343996                                           // 000000A42660: 7F343996
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A42664: BF870094
	.long 0xd73c0012                                           // 000000A42668: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000A4266C: 02022481
	.long 0xd7006a14                                           // 000000A42670: D7006A14
	v_cndmask_b32_e32 v1, s36, v18, vcc_lo                     // 000000A42674: 02022424
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A42678: BF870001
	v_add_co_ci_u32_e64 v21, null, s37, v19, vcc_lo            // 000000A4267C: D5207C15 01AA2625
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000A42684: 7C940280
	s_clause 0x7                                               // 000000A42688: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000A4268C: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000A42694: DC820000 177C0014
	global_load_d16_b16 v26, v[20:21], off offset:64           // 000000A4269C: DC820040 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:96           // 000000A426A4: DC820060 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:128          // 000000A426AC: DC820080 1C7C0014
	global_load_d16_b16 v29, v[20:21], off offset:160          // 000000A426B4: DC8200A0 1D7C0014
	global_load_d16_b16 v30, v[20:21], off offset:192          // 000000A426BC: DC8200C0 1E7C0014
	global_load_d16_b16 v31, v[20:21], off offset:224          // 000000A426C4: DC8200E0 1F7C0014
	v_mad_i64_i32 v[20:21], null, s49, v24, 0                  // 000000A426CC: D6FF7C14 02023031
	v_cndmask_b32_e64 v1, -v7, v7, vcc_lo                      // 000000A426D4: D5010001 21AA0F07
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000A426DC: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000A426E4: D501000E 21AA1D0E
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000A426EC: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000A426F4: D501000F 21AA1F0F
	v_add_f32_e32 v1, v1, v5                                   // 000000A426FC: 06020B01
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 000000A42700: D5010005 21AA0D06
	.long 0xd73c0014                                           // 000000A42708: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 000000A4270C: 02022881
	v_cndmask_b32_e64 v6, -v16, v16, vcc_lo                    // 000000A42710: D5010006 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000A42718: D5010010 21AA2311
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A42720: BF8700B4
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v8     // 000000A42724: C9081304 04041105
	v_add_f32_e32 v8, v14, v10                                 // 000000A4272C: 0610150E
	.long 0xd7006a11                                           // 000000A42730: D7006A11
	v_cndmask_b32_e32 v1, s42, v20, vcc_lo                     // 000000A42734: 0202282A
	v_add_co_ci_u32_e64 v20, null, s43, v21, vcc_lo            // 000000A42738: D5207C14 01AA2A2B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A42740: BF8701C4
	v_dual_mul_f32 v21, 0x3db504f3, v1 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000A42744: C8C602FF 150408FF 3DB504F3
	v_dual_add_f32 v3, v3, v2 :: v_dual_add_f32 v6, v6, v11    // 000000A42750: C9080503 03061706
	v_dual_add_f32 v9, v15, v12 :: v_dual_add_f32 v10, v16, v13// 000000A42758: C908190F 090A1B10
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000A42760: 100A0AFF 3DB504F3
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000A42768: C8C606FF 030810FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A42774: BF870214
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000A42778: 100C0CFF 3DB504F3
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000A42780: 101414FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 000000A42788: BF891FF7
	.long 0x7f0e3996                                           // 000000A4278C: 7F0E3996
	.long 0xd7006a01                                           // 000000A42790: D7006A01
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000A42794: 02022511
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A42798: BF870001
	v_add_co_ci_u32_e64 v2, null, v20, v19, vcc_lo             // 000000A4279C: D5207C02 01AA2714
	v_fma_mix_f32 v11, v22, v21, neg(0) op_sel_hi:[1,0,0]      // 000000A427A4: CC20000B 8A022B16
	s_waitcnt vmcnt(6)                                         // 000000A427AC: BF891BF7
	v_fma_mix_f32 v3, v23, v3, neg(0) op_sel_hi:[1,0,0]        // 000000A427B0: CC200003 8A020717
	s_waitcnt vmcnt(5)                                         // 000000A427B8: BF8917F7
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 000000A427BC: CC200005 8A020B1A
	s_waitcnt vmcnt(4)                                         // 000000A427C4: BF8913F7
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 000000A427C8: CC200004 8A02091B
	s_waitcnt vmcnt(3)                                         // 000000A427D0: BF890FF7
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000A427D4: CC200008 8A02111C
	.long 0x7e2c398b                                           // 000000A427DC: 7E2C398B
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000A427E0: 101212FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 000000A427E8: BF890BF7
	v_fma_mix_f32 v6, v29, v6, neg(0) op_sel_hi:[1,0,0]        // 000000A427EC: CC200006 8A020D1D
	s_waitcnt vmcnt(0)                                         // 000000A427F4: BF8903F7
	v_fma_mix_f32 v10, v31, v10, neg(0) op_sel_hi:[1,0,0]      // 000000A427F8: CC20000A 8A02151F
	.long 0x7e0e3983                                           // 000000A42800: 7E0E3983
	v_and_b32_e32 v12, 1, v22                                  // 000000A42804: 36182C81
	.long 0x7e2c3984                                           // 000000A42808: 7E2C3984
	v_fma_mix_f32 v9, v30, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A4280C: CC200009 8A02131E
	.long 0x7e2e3985                                           // 000000A42814: 7E2E3985
	.long 0x7e343988                                           // 000000A42818: 7E343988
	v_and_b32_e32 v7, 1, v7                                    // 000000A4281C: 360E0E81
	v_and_b32_e32 v13, 1, v22                                  // 000000A42820: 361A2C81
	.long 0x7e2c3986                                           // 000000A42824: 7E2C3986
	.long 0x7e363989                                           // 000000A42828: 7E363989
	v_and_b32_e32 v14, 1, v23                                  // 000000A4282C: 361C2E81
	v_and_b32_e32 v15, 1, v26                                  // 000000A42830: 361E3481
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000A42834: D6550003 03FE0F03 00007FFF
	v_and_b32_e32 v16, 1, v22                                  // 000000A42840: 36202C81
	.long 0x7e2c398a                                           // 000000A42844: 7E2C398A
	v_and_b32_e32 v17, 1, v27                                  // 000000A42848: 36223681
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000A4284C: D655000B 03FE190B 00007FFF
	v_add3_u32 v5, v5, v14, 0x7fff                             // 000000A42858: D6550005 03FE1D05 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 000000A42864: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v7, 1, v22                                   // 000000A42870: 360E2C81
	v_add3_u32 v8, v8, v15, 0x7fff                             // 000000A42874: D6550008 03FE1F08 00007FFF
	v_add3_u32 v9, v9, v17, 0x7fff                             // 000000A42880: D6550009 03FE2309 00007FFF
	v_add3_u32 v6, v6, v16, 0x7fff                             // 000000A4288C: D6550006 03FE2106 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A42898: BF870004
	v_add3_u32 v7, v10, v7, 0x7fff                             // 000000A4289C: D6550007 03FE0F0A 00007FFF
	s_clause 0x7                                               // 000000A428A8: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 000000A428AC: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v11, off offset:32         // 000000A428B4: DC960020 007C0B01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 000000A428BC: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 000000A428C4: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 000000A428CC: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v6, off offset:160         // 000000A428D4: DC9600A0 007C0601
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 000000A428DC: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v7, off offset:224         // 000000A428E4: DC9600E0 007C0701
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A428EC: 8C7E037E
	s_mov_b32 s4, 0                                            // 000000A428F0: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A428F4: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000A428F8: 8B6A047E
	s_cbranch_vccz 3749                                        // 000000A428FC: BFA30EA5 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x6494>
	s_mul_hi_i32 s0, s2, 0x66666667                            // 000000A42900: 9700FF02 66666667
	v_mov_b32_e32 v1, 0                                        // 000000A42908: 7E020280
	s_lshr_b32 s1, s0, 31                                      // 000000A4290C: 85019F00
	s_ashr_i32 s0, s0, 1                                       // 000000A42910: 86008100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A42914: BF870499
	s_add_i32 s10, s0, s1                                      // 000000A42918: 810A0100
	s_ashr_i32 s11, s10, 31                                    // 000000A4291C: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A42920: BF870499
	s_lshl_b64 s[0:1], s[10:11], 2                             // 000000A42924: 8480820A
	s_add_u32 s0, s16, s0                                      // 000000A42928: 80000010
	s_addc_u32 s1, s17, s1                                     // 000000A4292C: 82010111
	global_load_b32 v1, v1, s[0:1]                             // 000000A42930: DC520000 01000001
	s_mov_b32 s1, exec_lo                                      // 000000A42938: BE81007E
	s_waitcnt vmcnt(0)                                         // 000000A4293C: BF8903F7
	v_readfirstlane_b32 s3, v1                                 // 000000A42940: 7E060501
	v_cmpx_gt_u32_e32 0x140, v0                                // 000000A42944: 7D9800FF 00000140
	s_cbranch_execz 48                                         // 000000A4294C: BFA50030 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2b10>
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 000000A42950: 9700FF02 51EB851F
	v_lshlrev_b32_e32 v4, 4, v0                                // 000000A42958: 30080084
	s_lshr_b32 s4, s0, 31                                      // 000000A4295C: 85049F00
	s_ashr_i32 s0, s0, 4                                       // 000000A42960: 86008400
	v_or_b32_e32 v3, 0xffffff00, v0                            // 000000A42964: 380600FF FFFFFF00
	s_add_i32 s0, s0, s4                                       // 000000A4296C: 81000400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000A42970: BF8700D9
	s_mul_i32 s4, s0, 0x1400                                   // 000000A42974: 9604FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 000000A4297C: 9700FF00 00001400
	s_add_u32 s4, s14, s4                                      // 000000A42984: 8004040E
	s_addc_u32 s0, s15, s0                                     // 000000A42988: 8200000F
	.long 0xd7000401                                           // 000000A4298C: D7000401
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 000000A42990: 02020804
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 000000A42994: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 000000A4299C: BE840080
	s_nop 0                                                    // 000000A429A0: BF800000
	s_nop 0                                                    // 000000A429A4: BF800000
	s_nop 0                                                    // 000000A429A8: BF800000
	s_nop 0                                                    // 000000A429AC: BF800000
	s_nop 0                                                    // 000000A429B0: BF800000
	s_nop 0                                                    // 000000A429B4: BF800000
	s_nop 0                                                    // 000000A429B8: BF800000
	s_nop 0                                                    // 000000A429BC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 000000A429C0: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x100, v3                             // 000000A429C8: 4A0606FF 00000100
	.long 0xd7006a01                                           // 000000A429D0: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 000000A429D4: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A429DC: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000A429E0: D5207C02 01AA0480
	.long 0xd4490000                                           // 000000A429E8: D4490000
	v_cndmask_b32_e32 v1, 63, v3, vcc_lo                       // 000000A429EC: 020206BF
	s_or_b32 s4, s0, s4                                        // 000000A429F0: 8C040400
	s_waitcnt vmcnt(0)                                         // 000000A429F4: BF8903F7
	ds_store_b128 v4, v[5:8]                                   // 000000A429F8: DB7C0000 00000504
	v_add_nc_u32_e32 v4, 0x1000, v4                            // 000000A42A00: 4A0808FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A42A08: 917E047E
	s_cbranch_execnz 65516                                     // 000000A42A0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2ac0>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A42A10: 8C7E017E
	v_mul_u32_u24_e32 v18, 20, v24                             // 000000A42A14: 16243094
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v26, 2, v25     // 000000A42A18: CA220080 011A3282
	s_mul_i32 s0, s10, -5                                      // 000000A42A20: 9600C50A
	s_mul_hi_i32 s1, s3, 0x190000                              // 000000A42A24: 9701FF03 00190000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A42A2C: BF870112
	v_min_u32_e32 v19, 0x8c, v18                               // 000000A42A30: 262624FF 0000008C
	v_mov_b32_e32 v16, v1                                      // 000000A42A38: 7E200301
	v_mov_b32_e32 v2, v1                                       // 000000A42A3C: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000A42A40: 7E060301
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A42A44: BF870004
	v_dual_mov_b32 v4, v1 :: v_dual_add_nc_u32 v27, 20, v19    // 000000A42A48: CA200101 041A2694
	v_mov_b32_e32 v5, v1                                       // 000000A42A50: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000A42A54: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000A42A58: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 000000A42A5C: 7E100301
	v_mov_b32_e32 v9, v1                                       // 000000A42A60: 7E120301
	v_mov_b32_e32 v10, v1                                      // 000000A42A64: 7E140301
	v_mov_b32_e32 v11, v1                                      // 000000A42A68: 7E160301
	v_mov_b32_e32 v12, v1                                      // 000000A42A6C: 7E180301
	v_mov_b32_e32 v13, v1                                      // 000000A42A70: 7E1A0301
	v_mov_b32_e32 v14, v1                                      // 000000A42A74: 7E1C0301
	v_mov_b32_e32 v15, v1                                      // 000000A42A78: 7E1E0301
	v_mov_b32_e32 v17, v16                                     // 000000A42A7C: 7E220310
	v_cmp_lt_u32_e32 vcc_lo, v18, v27                          // 000000A42A80: 7C923712
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A42A84: BF870003
	v_mov_b32_e32 v16, v15                                     // 000000A42A88: 7E20030F
	v_mov_b32_e32 v15, v14                                     // 000000A42A8C: 7E1E030E
	v_mov_b32_e32 v14, v13                                     // 000000A42A90: 7E1C030D
	v_mov_b32_e32 v13, v12                                     // 000000A42A94: 7E1A030C
	v_mov_b32_e32 v12, v11                                     // 000000A42A98: 7E18030B
	v_mov_b32_e32 v11, v10                                     // 000000A42A9C: 7E16030A
	v_mov_b32_e32 v10, v9                                      // 000000A42AA0: 7E140309
	v_mov_b32_e32 v9, v8                                       // 000000A42AA4: 7E120308
	v_mov_b32_e32 v8, v7                                       // 000000A42AA8: 7E100307
	v_mov_b32_e32 v7, v6                                       // 000000A42AAC: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 000000A42AB0: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000A42AB4: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000A42AB8: 7E080303
	v_mov_b32_e32 v3, v2                                       // 000000A42ABC: 7E060302
	v_mov_b32_e32 v2, v1                                       // 000000A42AC0: 7E040301
	s_add_i32 s2, s0, s2                                       // 000000A42AC4: 81020200
	s_mul_i32 s6, s3, 0x190000                                 // 000000A42AC8: 9606FF03 00190000
	s_mul_hi_i32 s5, s2, 0x50000                               // 000000A42AD0: 9705FF02 00050000
	s_mul_i32 s7, s2, 0x50000                                  // 000000A42AD8: 9607FF02 00050000
	s_waitcnt lgkmcnt(0)                                       // 000000A42AE0: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000A42AE4: BC7C0000
	s_barrier                                                  // 000000A42AE8: BFBD0000
	buffer_gl0_inv                                             // 000000A42AEC: E0AC0000 00000000
	s_and_saveexec_b32 s4, vcc_lo                              // 000000A42AF4: BE84206A
	s_cbranch_execz 49                                         // 000000A42AF8: BFA50031 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2cc0>
	v_mul_u32_u24_e32 v2, 0xa000, v24                          // 000000A42AFC: 160430FF 0000A000
	s_add_u32 s0, s12, s6                                      // 000000A42B04: 8000060C
	s_addc_u32 s8, s13, s1                                     // 000000A42B08: 8208010D
	s_add_u32 s0, s0, s7                                       // 000000A42B0C: 80000700
	s_addc_u32 s8, s8, s5                                      // 000000A42B10: 82080508
	.long 0xd7000002                                           // 000000A42B14: D7000002
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000A42B18: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A42B1C: BF870111
	v_add_co_ci_u32_e64 v3, null, s8, 0, s0                    // 000000A42B20: D5207C03 00010008
	.long 0xd7000014                                           // 000000A42B28: D7000014
	v_cndmask_b32_e32 v1, v2, v26, vcc_lo                      // 000000A42B2C: 02023502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A42B30: BF870001
	v_add_co_ci_u32_e64 v21, null, 0, v3, s0                   // 000000A42B34: D5207C15 00020680
	s_clause 0xf                                               // 000000A42B3C: BF85000F
	global_load_b32 v2, v[20:21], off                          // 000000A42B40: DC520000 027C0014
	global_load_b32 v3, v[20:21], off offset:128               // 000000A42B48: DC520080 037C0014
	global_load_b32 v4, v[20:21], off offset:256               // 000000A42B50: DC520100 047C0014
	global_load_b32 v5, v[20:21], off offset:384               // 000000A42B58: DC520180 057C0014
	global_load_b32 v6, v[20:21], off offset:512               // 000000A42B60: DC520200 067C0014
	global_load_b32 v7, v[20:21], off offset:640               // 000000A42B68: DC520280 077C0014
	global_load_b32 v8, v[20:21], off offset:768               // 000000A42B70: DC520300 087C0014
	global_load_b32 v9, v[20:21], off offset:896               // 000000A42B78: DC520380 097C0014
	global_load_b32 v10, v[20:21], off offset:1024             // 000000A42B80: DC520400 0A7C0014
	global_load_b32 v11, v[20:21], off offset:1152             // 000000A42B88: DC520480 0B7C0014
	global_load_b32 v12, v[20:21], off offset:1280             // 000000A42B90: DC520500 0C7C0014
	global_load_b32 v13, v[20:21], off offset:1408             // 000000A42B98: DC520580 0D7C0014
	global_load_b32 v14, v[20:21], off offset:1536             // 000000A42BA0: DC520600 0E7C0014
	global_load_b32 v15, v[20:21], off offset:1664             // 000000A42BA8: DC520680 0F7C0014
	global_load_b32 v16, v[20:21], off offset:1792             // 000000A42BB0: DC520700 107C0014
	global_load_b32 v17, v[20:21], off offset:1920             // 000000A42BB8: DC520780 117C0014
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A42BC0: 8C7E047E
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v30, 0             // 000000A42BC4: CA100080 1D1E0080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 000000A42BCC: CA100080 1F200080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 000000A42BD4: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000A42BDC: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000A42BE4: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 000000A42BEC: CA100080 27280080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 000000A42BF4: CA100080 292A0080
	v_mov_b32_e32 v28, 0                                       // 000000A42BFC: 7E380280
	s_and_saveexec_b32 s4, vcc_lo                              // 000000A42C00: BE84206A
	s_cbranch_execz 2095                                       // 000000A42C04: BFA5082F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4dc4>
	v_dual_mov_b32 v28, 0 :: v_dual_lshlrev_b32 v1, 5, v25     // 000000A42C08: CA220080 1C003285
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v23, 11, v18   // 000000A42C10: CA220080 2816248B
	s_add_u32 s0, s6, s7                                       // 000000A42C18: 80000706
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A42C1C: BF870122
	v_dual_mov_b32 v41, 0 :: v_dual_add_nc_u32 v20, 0x3f0, v1  // 000000A42C20: CA200080 291402FF 000003F0
	s_addc_u32 s1, s1, s5                                      // 000000A42C2C: 82010501
	.long 0xd7000017                                           // 000000A42C30: D7000017
	v_cndmask_b32_e32 v1, s0, v23, vcc_lo                      // 000000A42C34: 02022E00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A42C38: BF870242
	v_lshrrev_b32_e32 v22, 5, v20                              // 000000A42C3C: 322C2885
	v_dual_mov_b32 v39, 0 :: v_dual_and_b32 v20, 0x7e0, v20    // 000000A42C40: CA240080 271428FF 000007E0
	v_cmp_eq_u32_e32 vcc_lo, 0, v25                            // 000000A42C4C: 7C943280
	v_add_co_ci_u32_e64 v29, null, s1, 0, s0                   // 000000A42C50: D5207C1D 00010001
	v_subrev_nc_u32_e32 v22, 32, v22                           // 000000A42C58: 4E2C2CA0
	v_mul_u32_u24_e32 v43, 0x840, v24                          // 000000A42C5C: 165630FF 00000840
	v_sub_nc_u32_e32 v1, v20, v1                               // 000000A42C64: 4C020314
	v_mad_u32_u24 v44, 0x840, v24, v26                         // 000000A42C68: D60B002C 046A30FF 00000840
	v_dual_mov_b32 v42, 0 :: v_dual_and_b32 v21, 16, v0        // 000000A42C74: CA240080 2A140090
	v_cndmask_b32_e64 v20, v22, 31, vcc_lo                     // 000000A42C7C: D5010014 01A93F16
	.long 0xd7000016                                           // 000000A42C84: D7000016
	v_cndmask_b32_e32 v1, v23, v26, vcc_lo                     // 000000A42C88: 02023517
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A42C8C: BF870221
	v_add_co_ci_u32_e64 v23, null, 0, v29, s0                  // 000000A42C90: D5207C17 00023A80
	v_dual_mov_b32 v38, 0 :: v_dual_add_nc_u32 v45, 0xfffffc30, v1// 000000A42C98: CA200080 262C02FF FFFFFC30
	v_lshl_add_u32 v1, v20, 2, v43                             // 000000A42CA4: D6460001 04AD0514
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A42CAC: BF870094
	.long 0xd7000014                                           // 000000A42CB0: D7000014
	v_cndmask_b32_e32 v1, s12, v22, vcc_lo                     // 000000A42CB4: 02022C0C
	v_add_co_ci_u32_e64 v23, null, s13, v23, s0                // 000000A42CB8: D5207C17 00022E0D
	v_lshl_or_b32 v46, v18, 5, v21                             // 000000A42CC0: D656002E 04550B12
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A42CC8: BF870093
	.long 0xd7000016                                           // 000000A42CCC: D7000016
	v_cndmask_b32_e32 v1, 0x800, v20, vcc_lo                   // 000000A42CD0: 020228FF 00000800
	v_add_co_ci_u32_e64 v23, null, 0, v23, s0                  // 000000A42CD8: D5207C17 00022E80
	v_sub_nc_u32_e32 v47, 0, v19                               // 000000A42CE0: 4C5E2680
	v_dual_mov_b32 v37, 0 :: v_dual_add_nc_u32 v48, 1, v18     // 000000A42CE4: CA200080 25302481
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v49, 0x1400, v1 // 000000A42CEC: CA200080 243002FF 00001400
	v_dual_mov_b32 v35, 0 :: v_dual_add_nc_u32 v50, 0x1484, v1 // 000000A42CF8: CA200080 233202FF 00001484
	v_dual_mov_b32 v34, 0 :: v_dual_add_nc_u32 v51, 0x1508, v1 // 000000A42D04: CA200080 223202FF 00001508
	v_dual_mov_b32 v33, 0 :: v_dual_add_nc_u32 v52, 0x158c, v1 // 000000A42D10: CA200080 213402FF 0000158C
	v_dual_mov_b32 v32, 0 :: v_dual_add_nc_u32 v53, 0x1610, v1 // 000000A42D1C: CA200080 203402FF 00001610
	v_dual_mov_b32 v31, 0 :: v_dual_add_nc_u32 v54, 0x1694, v1 // 000000A42D28: CA200080 1F3602FF 00001694
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v55, 0x1718, v1 // 000000A42D34: CA200080 1E3602FF 00001718
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v56, 0x179c, v1 // 000000A42D40: CA200080 1D3802FF 0000179C
	v_add_nc_u32_e32 v57, 0x1820, v1                           // 000000A42D4C: 4A7202FF 00001820
	v_add_nc_u32_e32 v58, 0x18a4, v1                           // 000000A42D54: 4A7402FF 000018A4
	v_add_nc_u32_e32 v59, 0x1928, v1                           // 000000A42D5C: 4A7602FF 00001928
	v_add_nc_u32_e32 v60, 0x19ac, v1                           // 000000A42D64: 4A7802FF 000019AC
	v_add_nc_u32_e32 v61, 0x1a30, v1                           // 000000A42D6C: 4A7A02FF 00001A30
	v_add_nc_u32_e32 v62, 0x1ab4, v1                           // 000000A42D74: 4A7C02FF 00001AB4
	v_add_nc_u32_e32 v63, 0x1b38, v1                           // 000000A42D7C: 4A7E02FF 00001B38
	v_add_nc_u32_e32 v64, 0x1bbc, v1                           // 000000A42D84: 4A8002FF 00001BBC
	v_add_nc_u32_e32 v65, 0x1400, v44                          // 000000A42D8C: 4A8258FF 00001400
	v_dual_mov_b32 v1, 0 :: v_dual_add_nc_u32 v66, 0x1800, v44 // 000000A42D94: CA200080 014258FF 00001800
	s_mov_b32 s5, 0                                            // 000000A42DA0: BE850080
	s_movk_i32 s6, 0x1eee                                      // 000000A42DA4: B0061EEE
	s_branch 1732                                              // 000000A42DA8: BFA006C4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x49bc>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A42DAC: 8C7E017E
	ds_load_2addr_b32 v[67:68], v49 offset1:1                  // 000000A42DB0: D8DC0100 43000031
	ds_load_2addr_b32 v[78:79], v65 offset1:33                 // 000000A42DB8: D8DC2100 4E000041
	ds_load_2addr_b32 v[70:71], v50 offset1:1                  // 000000A42DC0: D8DC0100 46000032
	ds_load_b128 v[18:21], v46                                 // 000000A42DC8: DBFC0000 1200002E
	ds_load_2addr_b32 v[73:74], v51 offset1:1                  // 000000A42DD0: D8DC0100 49000033
	ds_load_2addr_b32 v[76:77], v52 offset1:1                  // 000000A42DD8: D8DC0100 4C000034
	v_add_nc_u32_e32 v48, 1, v48                               // 000000A42DE0: 4A606081
	.long 0xd7000116                                           // 000000A42DE4: D7000116
	v_cndmask_b32_e32 v1, 0x800, v22, vcc_lo                   // 000000A42DE8: 02022CFF 00000800
	v_add_nc_u32_e32 v46, 32, v46                              // 000000A42DF0: 4A5C5CA0
	v_add_co_ci_u32_e64 v23, null, 0, v23, s1                  // 000000A42DF4: D5207C17 00062E80
	s_waitcnt lgkmcnt(5)                                       // 000000A42DFC: BF89FC57
	v_mov_b32_e32 v69, v67                                     // 000000A42E00: 7E8A0343
	s_waitcnt lgkmcnt(4)                                       // 000000A42E04: BF89FC47
	v_bfe_u32 v75, v78, 12, 16                                 // 000000A42E08: D610004B 0241194E
	v_bfe_u32 v80, v78, 8, 16                                  // 000000A42E10: D6100050 0241114E
	v_bfe_u32 v81, v78, 4, 16                                  // 000000A42E18: D6100051 0241094E
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A42E20: 369C9CFF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 000000A42E28: BF89FC37
	v_mov_b32_e32 v72, v70                                     // 000000A42E2C: 7E900346
	.long 0xd73d0043                                           // 000000A42E30: D73D0043
	v_cndmask_b32_e32 v1, v45, v68, vcc_lo                     // 000000A42E34: 0202892D
	v_bfe_u32 v70, v79, 12, 16                                 // 000000A42E38: D6100046 0241194F
	v_bfe_u32 v82, v79, 8, 16                                  // 000000A42E40: D6100052 0241114F
	v_bfe_u32 v83, v79, 4, 16                                  // 000000A42E48: D6100053 0241094F
	v_and_b32_e32 v79, 0xffff, v79                             // 000000A42E50: 369E9EFF 0000FFFF
	.long 0xd73d0044                                           // 000000A42E58: D73D0044
	v_cndmask_b32_e32 v1, v45, v71, vcc_lo                     // 000000A42E5C: 02028F2D
	.long 0xd72c0045                                           // 000000A42E60: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A42E64: 02028CFF 83DCD12D
	v_bfe_u32 v70, v67, 12, 16                                 // 000000A42E6C: D6100046 02411943
	v_bfe_u32 v71, v67, 8, 16                                  // 000000A42E74: D6100047 02411143
	v_bfe_u32 v72, v67, 4, 16                                  // 000000A42E7C: D6100048 02410943
	.long 0xd72c004b                                           // 000000A42E84: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A42E88: 020296FF 83DCD12D
	.long 0xd72c0050                                           // 000000A42E90: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A42E94: 0202A0FF 83DCD12D
	.long 0xd72c0046                                           // 000000A42E9C: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A42EA0: 02028CFF 83DCD12D
	.long 0xd72c0047                                           // 000000A42EA8: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A42EAC: 02028EFF 83DCD12D
	v_bfe_u32 v84, v68, 12, 16                                 // 000000A42EB4: D6100054 02411944
	.long 0xd72c0048                                           // 000000A42EBC: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A42EC0: 020290FF 83DCD12D
	v_bfe_u32 v85, v68, 8, 16                                  // 000000A42EC8: D6100055 02411144
	.long 0xd72c004e                                           // 000000A42ED0: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A42ED4: 02029CFF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A42EDC: D622004B 03FD014B 00006400
	.long 0xd72c0054                                           // 000000A42EE8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A42EEC: 0202A8FF 83DCD12D
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A42EF4: D6220046 03FD0146 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A42F00: D6220047 03FD0147 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A42F0C: D6220050 03FD0150 00006400
	v_and_b32_e32 v75, 0xffff, v75                             // 000000A42F18: 369696FF 0000FFFF
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A42F20: D6220048 03FD0148 00006400
	v_and_b32_e32 v70, 0xffff, v70                             // 000000A42F2C: 368C8CFF 0000FFFF
	.long 0xd72c0055                                           // 000000A42F34: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A42F38: 0202AAFF 83DCD12D
	.long 0xd72c0051                                           // 000000A42F40: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A42F44: 0202A2FF 83DCD12D
	v_lshl_or_b32 v75, v80, 16, v75                            // 000000A42F4C: D656004B 052D2150
	v_sad_u8 v80, v84, 0, 0x6400                               // 000000A42F54: D6220050 03FD0154 00006400
	v_lshl_or_b32 v70, v71, 16, v70                            // 000000A42F60: D6560046 05192147
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A42F68: D622004E 03FD014E 00006400
	v_bfe_u32 v86, v68, 4, 16                                  // 000000A42F74: D6100056 02410944
	v_and_b32_e32 v68, 0xffff, v68                             // 000000A42F7C: 368888FF 0000FFFF
	.long 0xd72c0052                                           // 000000A42F84: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A42F88: 0202A4FF 83DCD12D
	v_pk_fma_f16 v70, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A42F90: CC0E0046 0BFC0D46 0000C931
	v_and_b32_e32 v67, 0xffff, v67                             // 000000A42F9C: 368686FF 0000FFFF
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A42FA4: D6220051 03FD0151 00006400
	v_lshlrev_b32_e32 v78, 16, v78                             // 000000A42FB0: 309C9C90
	.long 0xd72c0056                                           // 000000A42FB4: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A42FB8: 0202ACFF 83DCD12D
	s_waitcnt lgkmcnt(2)                                       // 000000A42FC0: BF89FC27
	v_dot2acc_f32_f16 v28, v70, v18                            // 000000A42FC4: 04382546
	.long 0xd72c0043                                           // 000000A42FC8: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A42FCC: 020286FF 83DCD12D
	.long 0xd72c004f                                           // 000000A42FD4: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A42FD8: 02029EFF 83DCD12D
	v_and_or_b32 v78, 0xffff, v81, v78                         // 000000A42FE0: D657004E 053AA2FF 0000FFFF
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A42FEC: D6220045 03FD0145 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A42FF8: BF870214
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A42FFC: D6220043 03FD0143 00006400
	v_sad_u8 v70, v79, 0, 0x6400                               // 000000A43008: D6220046 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A43014: BF870112
	v_lshlrev_b32_e32 v67, 16, v67                             // 000000A43018: 30868690
	v_lshlrev_b32_e32 v70, 16, v70                             // 000000A4301C: 308C8C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A43020: BF8701B2
	v_and_or_b32 v67, 0xffff, v72, v67                         // 000000A43024: D6570043 050E90FF 0000FFFF
	v_pk_fma_f16 v72, v75, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43030: CC0E0048 0BFC0D4B 0000C931
	v_sad_u8 v75, v85, 0, 0x6400                               // 000000A4303C: D622004B 03FD0155 00006400
	v_pk_fma_f16 v67, v67, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43048: CC0E0043 0BFC0D43 0000C931
	v_and_b32_e32 v71, 0xffff, v80                             // 000000A43054: 368EA0FF 0000FFFF
	v_sad_u8 v80, v86, 0, 0x6400                               // 000000A4305C: D6220050 03FD0156 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A43068: BF870193
	v_dot2acc_f32_f16 v28, v67, v19                            // 000000A4306C: 04382743
	v_lshl_or_b32 v71, v75, 16, v71                            // 000000A43070: D6560047 051D214B
	.long 0xd72c004b                                           // 000000A43078: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A4307C: 0202A6FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A43084: BF870193
	v_dot2acc_f32_f16 v28, v72, v20                            // 000000A43088: 04382948
	v_pk_fma_f16 v71, v71, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A4308C: CC0E0047 0BFC0D47 0000C931
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A43098: BF870003
	v_sad_u8 v81, v75, 0, 0x6400                               // 000000A4309C: D6220051 03FD014B 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A430A8: BF89FC17
	v_mov_b32_e32 v75, v73                                     // 000000A430AC: 7E960349
	.long 0xd72c0044                                           // 000000A430B0: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A430B4: 020288FF 83DCD12D
	v_dot2acc_f32_f16 v42, v71, v18                            // 000000A430BC: 04542547
	v_and_or_b32 v73, 0xffff, v81, v70                         // 000000A430C0: D6570049 051AA2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A430CC: BF870234
	.long 0xd73d0046                                           // 000000A430D0: D73D0046
	v_cndmask_b32_e32 v1, v45, v74, vcc_lo                     // 000000A430D4: 0202952D
	v_pk_fma_f16 v71, v78, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A430D8: CC0E0047 0BFC0D4E 0000C931
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A430E4: D6220044 03FD0144 00006400
	v_pk_fma_f16 v72, v73, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A430F0: CC0E0048 0BFC0D49 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A430FC: BF870092
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000A43100: 30888890
	v_and_or_b32 v68, 0xffff, v80, v68                         // 000000A43104: D6570044 0512A0FF 0000FFFF
	v_sad_u8 v80, v82, 0, 0x6400                               // 000000A43110: D6220050 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A4311C: BF870092
	v_pk_fma_f16 v79, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43120: CC0E004F 0BFC0D44 0000C931
	v_dual_dot2acc_f32_f16 v42, v79, v19 :: v_dual_and_b32 v69, 0xffff, v69// 000000A4312C: CB24274F 2A448AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A43138: BF8700B1
	v_lshl_or_b32 v80, v80, 16, v69                            // 000000A4313C: D6560050 05152150
	ds_load_2addr_b32 v[68:69], v65 offset0:66 offset1:99      // 000000A43144: D8DC6342 44000041
	v_pk_fma_f16 v67, v80, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A4314C: CC0E0043 0BFC0D50 0000C931
	v_dot2acc_f32_f16 v42, v67, v20                            // 000000A43158: 04542943
	v_bfe_u32 v67, v70, 12, 16                                 // 000000A4315C: D6100043 02411946
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A43164: BF870251
	.long 0xd72c0043                                           // 000000A43168: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A4316C: 020286FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A43174: BF89FC07
	v_bfe_u32 v73, v68, 12, 16                                 // 000000A43178: D6100049 02411944
	v_bfe_u32 v74, v68, 8, 16                                  // 000000A43180: D610004A 02411144
	v_bfe_u32 v75, v68, 4, 16                                  // 000000A43188: D610004B 02410944
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A43190: D6220043 03FD0143 00006400
	v_and_b32_e32 v68, 0xffff, v68                             // 000000A4319C: 368888FF 0000FFFF
	.long 0xd72c0049                                           // 000000A431A4: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A431A8: 020292FF 83DCD12D
	.long 0xd72c004a                                           // 000000A431B0: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A431B4: 020294FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A431BC: BF870194
	v_and_b32_e32 v79, 0xffff, v67                             // 000000A431C0: 369E86FF 0000FFFF
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A431C8: D6220049 03FD0149 00006400
	v_mov_b32_e32 v78, v76                                     // 000000A431D4: 7E9C034C
	.long 0xd72c004c                                           // 000000A431D8: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A431DC: 020288FF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A431E4: D622004A 03FD014A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A431F0: BF870214
	v_and_b32_e32 v73, 0xffff, v73                             // 000000A431F4: 369292FF 0000FFFF
	.long 0xd73d0043                                           // 000000A431FC: D73D0043
	v_cndmask_b32_e32 v1, v45, v77, vcc_lo                     // 000000A43200: 02029B2D
	v_dot2acc_f32_f16 v28, v71, v21                            // 000000A43204: 04382B47
	v_bfe_u32 v71, v70, 8, 16                                  // 000000A43208: D6100047 02411146
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A43210: D622004C 03FD014C 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A4321C: BF870092
	.long 0xd72c0047                                           // 000000A43220: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A43224: 02028EFF 83DCD12D
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A4322C: D6220047 03FD0147 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A43238: BF8700B1
	v_lshl_or_b32 v71, v71, 16, v79                            // 000000A4323C: D6560047 053D2147
	ds_load_2addr_b32 v[78:79], v65 offset0:132 offset1:165    // 000000A43244: D8DCA584 4E000041
	v_pk_fma_f16 v71, v71, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A4324C: CC0E0047 0BFC0D47 0000C931
	v_dot2acc_f32_f16 v41, v71, v18                            // 000000A43258: 04522547
	v_bfe_u32 v71, v69, 12, 16                                 // 000000A4325C: D6100047 02411945
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A43264: BF870091
	.long 0xd72c0047                                           // 000000A43268: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A4326C: 02028EFF 83DCD12D
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A43274: D6220047 03FD0147 00006400
	v_dot2acc_f32_f16 v42, v72, v21                            // 000000A43280: 04542B48
	v_and_b32_e32 v72, 0xffff, v70                             // 000000A43284: 36908CFF 0000FFFF
	v_bfe_u32 v70, v70, 4, 16                                  // 000000A4328C: D6100046 02410946
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A43294: BF870194
	v_and_b32_e32 v85, 0xffff, v71                             // 000000A43298: 36AA8EFF 0000FFFF
	.long 0xd72c0048                                           // 000000A432A0: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A432A4: 020290FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A432AC: BF870113
	.long 0xd72c0046                                           // 000000A432B0: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A432B4: 02028CFF 83DCD12D
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A432BC: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A432C8: BF870112
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A432CC: D6220046 03FD0146 00006400
	v_lshlrev_b32_e32 v68, 16, v72                             // 000000A432D8: 30889090
	.long 0xd72c0048                                           // 000000A432DC: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A432E0: 020296FF 83DCD12D
	v_bfe_u32 v75, v67, 12, 16                                 // 000000A432E8: D610004B 02411943
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A432F0: BF8701A3
	v_and_or_b32 v68, 0xffff, v70, v68                         // 000000A432F4: D6570044 05128CFF 0000FFFF
	v_lshl_or_b32 v70, v74, 16, v73                            // 000000A43300: D6560046 0525214A
	.long 0xd72c0049                                           // 000000A43308: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A4330C: 020296FF 83DCD12D
	v_bfe_u32 v75, v67, 8, 16                                  // 000000A43314: D610004B 02411143
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A4331C: D6220048 03FD0148 00006400
	v_pk_fma_f16 v80, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43328: CC0E0050 0BFC0D44 0000C931
	v_pk_fma_f16 v81, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43334: CC0E0051 0BFC0D46 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A43340: BF870194
	.long 0xd72c0044                                           // 000000A43344: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A43348: 020296FF 83DCD12D
	v_dot2acc_f32_f16 v41, v80, v19                            // 000000A43350: 04522750
	v_sad_u8 v70, v73, 0, 0x6400                               // 000000A43354: D6220046 03FD0149 00006400
	v_and_b32_e32 v73, 0xffff, v67                             // 000000A43360: 369286FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A43368: BF870003
	v_dot2acc_f32_f16 v41, v81, v20                            // 000000A4336C: 04522951
	v_lshlrev_b32_e32 v74, 16, v76                             // 000000A43370: 30949890
	v_sad_u8 v75, v68, 0, 0x6400                               // 000000A43374: D622004B 03FD0144 00006400
	v_and_b32_e32 v70, 0xffff, v70                             // 000000A43380: 368C8CFF 0000FFFF
	.long 0xd72c0049                                           // 000000A43388: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A4338C: 020292FF 83DCD12D
	v_bfe_u32 v76, v69, 8, 16                                  // 000000A43394: D610004C 02411145
	v_and_or_b32 v72, 0xffff, v72, v74                         // 000000A4339C: D6570048 052A90FF 0000FFFF
	v_bfe_u32 v74, v67, 4, 16                                  // 000000A433A8: D610004A 02410943
	ds_load_2addr_b32 v[67:68], v53 offset1:1                  // 000000A433B0: D8DC0100 43000035
	v_lshl_or_b32 v70, v75, 16, v70                            // 000000A433B8: D6560046 0519214B
	.long 0xd72c004b                                           // 000000A433C0: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A433C4: 020298FF 83DCD12D
	.long 0xd72c004a                                           // 000000A433CC: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A433D0: 020294FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A433D8: D6220049 03FD0149 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A433E4: BF870234
	v_pk_fma_f16 v82, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A433E8: CC0E0052 0BFC0D46 0000C931
	v_and_b32_e32 v77, 0xffff, v69                             // 000000A433F4: 369A8AFF 0000FFFF
	v_bfe_u32 v69, v69, 4, 16                                  // 000000A433FC: D6100045 02410945
	v_lshlrev_b32_e32 v84, 16, v73                             // 000000A43404: 30A89290
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A43408: BF870214
	v_dot2acc_f32_f16 v40, v82, v18                            // 000000A4340C: 04502552
	.long 0xd72c004c                                           // 000000A43410: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A43414: 02029AFF 83DCD12D
	v_sad_u8 v83, v74, 0, 0x6400                               // 000000A4341C: D6220053 03FD014A 00006400
	.long 0xd72c0056                                           // 000000A43428: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A4342C: 02028AFF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A43434: D622004B 03FD014B 00006400
	v_pk_fma_f16 v82, v72, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43440: CC0E0052 0BFC0D48 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A4344C: BF870004
	v_and_or_b32 v83, 0xffff, v83, v84                         // 000000A43450: D6570053 0552A6FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A4345C: BF89FC07
	v_mov_b32_e32 v69, v67                                     // 000000A43460: 7E8A0343
	v_sad_u8 v87, v76, 0, 0x6400                               // 000000A43464: D6220057 03FD014C 00006400
	ds_load_2addr_b32 v[70:71], v54 offset1:1                  // 000000A43470: D8DC0100 46000036
	ds_load_2addr_b32 v[73:74], v55 offset1:1                  // 000000A43478: D8DC0100 49000037
	ds_load_2addr_b32 v[76:77], v56 offset1:1                  // 000000A43480: D8DC0100 4C000038
	v_lshl_or_b32 v75, v75, 16, v85                            // 000000A43488: D656004B 0555214B
	v_sad_u8 v84, v86, 0, 0x6400                               // 000000A43490: D6220054 03FD0156 00006400
	.long 0xd73d0043                                           // 000000A4349C: D73D0043
	v_cndmask_b32_e32 v1, v45, v68, vcc_lo                     // 000000A434A0: 0202892D
	v_pk_fma_f16 v68, v83, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A434A4: CC0E0044 0BFC0D53 0000C931
	v_bfe_u32 v83, v78, 4, 16                                  // 000000A434B0: D6100053 0241094E
	v_pk_fma_f16 v69, v75, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A434B8: CC0E0045 0BFC0D4B 0000C931
	v_dot2acc_f32_f16 v41, v82, v21                            // 000000A434C4: 04522B52
	v_bfe_u32 v72, v67, 8, 16                                  // 000000A434C8: D6100048 02411143
	v_bfe_u32 v80, v67, 12, 16                                 // 000000A434D0: D6100050 02411943
	v_dot2acc_f32_f16 v40, v68, v19                            // 000000A434D8: 04502744
	v_lshlrev_b32_e32 v85, 16, v87                             // 000000A434DC: 30AAAE90
	.long 0xd72c0053                                           // 000000A434E0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A434E4: 0202A6FF 83DCD12D
	.long 0xd72c0048                                           // 000000A434EC: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A434F0: 020290FF 83DCD12D
	.long 0xd72c0044                                           // 000000A434F8: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A434FC: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v40, v69, v20                            // 000000A43504: 04502945
	v_and_or_b32 v75, 0xffff, v84, v85                         // 000000A43508: D657004B 0556A8FF 0000FFFF
	v_and_b32_e32 v69, 0xffff, v67                             // 000000A43514: 368A86FF 0000FFFF
	v_bfe_u32 v67, v67, 4, 16                                  // 000000A4351C: D6100043 02410943
	v_bfe_u32 v80, v78, 8, 16                                  // 000000A43524: D6100050 0241114E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A4352C: BF870004
	v_pk_fma_f16 v81, v75, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43530: CC0E0051 0BFC0D4B 0000C931
	v_bfe_u32 v75, v78, 12, 16                                 // 000000A4353C: D610004B 0241194E
	v_sad_u8 v84, v72, 0, 0x6400                               // 000000A43544: D6220054 03FD0148 00006400
	s_waitcnt lgkmcnt(2)                                       // 000000A43550: BF89FC27
	v_mov_b32_e32 v72, v70                                     // 000000A43554: 7E900346
	.long 0xd72c0045                                           // 000000A43558: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A4355C: 02028AFF 83DCD12D
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A43564: D6220044 03FD0144 00006400
	.long 0xd72c004b                                           // 000000A43570: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A43574: 020296FF 83DCD12D
	.long 0xd72c0043                                           // 000000A4357C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A43580: 020286FF 83DCD12D
	.long 0xd72c0050                                           // 000000A43588: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A4358C: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v40, v81, v21                            // 000000A43594: 04502B51
	v_and_b32_e32 v68, 0xffff, v68                             // 000000A43598: 368888FF 0000FFFF
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A435A0: D6220045 03FD0145 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A435AC: D622004B 03FD014B 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A435B8: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A435C4: BF870214
	v_lshl_or_b32 v70, v84, 16, v68                            // 000000A435C8: D6560046 05112154
	v_lshlrev_b32_e32 v69, 16, v69                             // 000000A435D0: 308A8A90
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A435D4: D6220050 03FD0150 00006400
	v_and_b32_e32 v75, 0xffff, v75                             // 000000A435E0: 369696FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A435E8: BF870214
	v_pk_fma_f16 v70, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A435EC: CC0E0046 0BFC0D46 0000C931
	v_and_or_b32 v69, 0xffff, v67, v69                         // 000000A435F8: D6570045 051686FF 0000FFFF
	.long 0xd73d0043                                           // 000000A43604: D73D0043
	v_cndmask_b32_e32 v1, v45, v71, vcc_lo                     // 000000A43608: 02028F2D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A4360C: BF870004
	v_lshl_or_b32 v75, v80, 16, v75                            // 000000A43610: D656004B 052D2150
	v_sad_u8 v68, v83, 0, 0x6400                               // 000000A43618: D6220044 03FD0153 00006400
	v_dot2acc_f32_f16 v39, v70, v18                            // 000000A43624: 044E2546
	v_pk_fma_f16 v69, v69, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43628: CC0E0045 0BFC0D45 0000C931
	v_bfe_u32 v80, v79, 4, 16                                  // 000000A43634: D6100050 0241094F
	v_pk_fma_f16 v72, v75, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A4363C: CC0E0048 0BFC0D4B 0000C931
	v_bfe_u32 v75, v67, 12, 16                                 // 000000A43648: D610004B 02411943
	v_bfe_u32 v70, v67, 8, 16                                  // 000000A43650: D6100046 02411143
	v_dot2acc_f32_f16 v39, v69, v19                            // 000000A43658: 044E2745
	v_bfe_u32 v69, v79, 12, 16                                 // 000000A4365C: D6100045 0241194F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A43664: BF870214
	.long 0xd72c004b                                           // 000000A43668: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A4366C: 020296FF 83DCD12D
	.long 0xd72c0046                                           // 000000A43674: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A43678: 02028CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A43680: BF870214
	v_dual_dot2acc_f32_f16 v39, v72, v20 :: v_dual_and_b32 v78, 0xffff, v78// 000000A43684: CB242948 274E9CFF 0000FFFF
	.long 0xd72c0045                                           // 000000A43690: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A43694: 02028AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A4369C: BF870232
	.long 0xd72c004e                                           // 000000A436A0: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A436A4: 02029CFF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A436AC: D622004B 03FD014B 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A436B8: D6220046 03FD0146 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A436C4: D6220045 03FD0145 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A436D0: BF8701A3
	v_and_b32_e32 v75, 0xffff, v75                             // 000000A436D4: 369696FF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A436DC: D622004E 03FD014E 00006400
	v_and_b32_e32 v69, 0xffff, v69                             // 000000A436E8: 368A8AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A436F0: BF870003
	v_lshl_or_b32 v70, v70, 16, v75                            // 000000A436F4: D6560046 052D2146
	s_waitcnt lgkmcnt(1)                                       // 000000A436FC: BF89FC17
	v_mov_b32_e32 v75, v73                                     // 000000A43700: 7E960349
	v_lshlrev_b32_e32 v71, 16, v78                             // 000000A43704: 308E9C90
	v_bfe_u32 v78, v79, 8, 16                                  // 000000A43708: D610004E 0241114F
	.long 0xd72c0049                                           // 000000A43710: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A43714: 0202A0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A4371C: BF870253
	v_and_or_b32 v71, 0xffff, v68, v71                         // 000000A43720: D6570047 051E88FF 0000FFFF
	v_and_b32_e32 v68, 0xffff, v67                             // 000000A4372C: 368886FF 0000FFFF
	v_bfe_u32 v67, v67, 4, 16                                  // 000000A43734: D6100043 02410943
	.long 0xd72c004e                                           // 000000A4373C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A43740: 02029CFF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A43748: D6220049 03FD0149 00006400
	.long 0xd72c0044                                           // 000000A43754: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A43758: 020288FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A43760: BF870214
	.long 0xd72c0043                                           // 000000A43764: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A43768: 020286FF 83DCD12D
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A43770: D622004E 03FD014E 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A4377C: BF870193
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A43780: D6220044 03FD0144 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A4378C: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A43798: BF870092
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000A4379C: 30888890
	v_and_or_b32 v83, 0xffff, v67, v68                         // 000000A437A0: D6570053 051286FF 0000FFFF
	.long 0xd73d0043                                           // 000000A437AC: D73D0043
	v_cndmask_b32_e32 v1, v45, v74, vcc_lo                     // 000000A437B0: 0202952D
	v_pk_fma_f16 v68, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A437B4: CC0E0044 0BFC0D46 0000C931
	v_lshl_or_b32 v74, v78, 16, v69                            // 000000A437C0: D656004A 0515214E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A437C8: BF870194
	v_pk_fma_f16 v70, v83, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A437CC: CC0E0046 0BFC0D53 0000C931
	v_dot2acc_f32_f16 v38, v68, v18                            // 000000A437D8: 044C2544
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A437DC: BF870003
	v_pk_fma_f16 v74, v74, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A437E0: CC0E004A 0BFC0D4A 0000C931
	v_bfe_u32 v78, v67, 12, 16                                 // 000000A437EC: D610004E 02411943
	ds_load_2addr_b32 v[68:69], v65 offset0:198 offset1:231    // 000000A437F4: D8DCE7C6 44000041
	v_dot2acc_f32_f16 v38, v70, v19                            // 000000A437FC: 044C2746
	v_and_b32_e32 v79, 0xffff, v79                             // 000000A43800: 369E9EFF 0000FFFF
	v_pk_fma_f16 v70, v71, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43808: CC0E0046 0BFC0D47 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A43814: BF870193
	v_dot2acc_f32_f16 v38, v74, v20                            // 000000A43818: 044C294A
	.long 0xd72c004f                                           // 000000A4381C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A43820: 02029EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A43828: BF870113
	v_dot2acc_f32_f16 v39, v70, v21                            // 000000A4382C: 044E2B46
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A43830: D622004F 03FD014F 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000A4383C: BF89FC07
	v_bfe_u32 v74, v68, 8, 16                                  // 000000A43840: D610004A 02411144
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A43848: BF870112
	v_lshlrev_b32_e32 v75, 16, v79                             // 000000A4384C: 30969E90
	.long 0xd72c004a                                           // 000000A43850: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A43854: 020294FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A4385C: BF8701B2
	v_and_or_b32 v73, 0xffff, v73, v75                         // 000000A43860: D6570049 052E92FF 0000FFFF
	.long 0xd72c004b                                           // 000000A4386C: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A43870: 02029CFF 83DCD12D
	v_bfe_u32 v78, v67, 8, 16                                  // 000000A43878: D610004E 02411143
	v_pk_fma_f16 v71, v73, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43880: CC0E0047 0BFC0D49 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A4388C: BF870232
	.long 0xd72c0048                                           // 000000A43890: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A43894: 02029CFF 83DCD12D
	v_mov_b32_e32 v78, v76                                     // 000000A4389C: 7E9C034C
	v_sad_u8 v73, v75, 0, 0x6400                               // 000000A438A0: D6220049 03FD014B 00006400
	v_dot2acc_f32_f16 v38, v71, v21                            // 000000A438AC: 044C2B47
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A438B0: D622004A 03FD014A 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A438BC: BF870253
	v_and_b32_e32 v70, 0xffff, v73                             // 000000A438C0: 368C92FF 0000FFFF
	v_sad_u8 v71, v72, 0, 0x6400                               // 000000A438C8: D6220047 03FD0148 00006400
	v_and_b32_e32 v72, 0xffff, v67                             // 000000A438D4: 369086FF 0000FFFF
	v_bfe_u32 v67, v67, 4, 16                                  // 000000A438DC: D6100043 02410943
	v_bfe_u32 v73, v68, 12, 16                                 // 000000A438E4: D6100049 02411944
	v_lshl_or_b32 v70, v71, 16, v70                            // 000000A438EC: D6560046 05192147
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A438F4: BF870214
	.long 0xd72c0047                                           // 000000A438F8: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A438FC: 020290FF 83DCD12D
	.long 0xd72c004b                                           // 000000A43904: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A43908: 020286FF 83DCD12D
	v_and_b32_e32 v72, 0xffff, v68                             // 000000A43910: 369088FF 0000FFFF
	v_bfe_u32 v68, v68, 4, 16                                  // 000000A43918: D6100044 02410944
	.long 0xd72c0049                                           // 000000A43920: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A43924: 020292FF 83DCD12D
	v_pk_fma_f16 v70, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A4392C: CC0E0046 0BFC0D46 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A43938: BF870004
	.long 0xd72c0048                                           // 000000A4393C: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A43940: 020290FF 83DCD12D
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A43948: D6220047 03FD0147 00006400
	.long 0xd72c004c                                           // 000000A43954: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A43958: 020288FF 83DCD12D
	.long 0xd73d0043                                           // 000000A43960: D73D0043
	v_cndmask_b32_e32 v1, v45, v77, vcc_lo                     // 000000A43964: 02029B2D
	v_sad_u8 v68, v75, 0, 0x6400                               // 000000A43968: D6220044 03FD014B 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A43974: D6220049 03FD0149 00006400
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000A43980: 308E8E90
	v_dot2acc_f32_f16 v37, v70, v18                            // 000000A43984: 044A2546
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A43988: D6220048 03FD0148 00006400
	v_bfe_u32 v75, v67, 12, 16                                 // 000000A43994: D610004B 02411943
	v_and_b32_e32 v73, 0xffff, v73                             // 000000A4399C: 369292FF 0000FFFF
	v_and_or_b32 v68, 0xffff, v68, v71                         // 000000A439A4: D6570044 051E88FF 0000FFFF
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A439B0: D622004C 03FD014C 00006400
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000A439BC: 30909090
	v_bfe_u32 v77, v69, 8, 16                                  // 000000A439C0: D610004D 02411145
	v_lshl_or_b32 v71, v74, 16, v73                            // 000000A439C8: D6560047 0525214A
	v_pk_fma_f16 v68, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A439D0: CC0E0044 0BFC0D44 0000C931
	v_bfe_u32 v74, v67, 8, 16                                  // 000000A439DC: D610004A 02411143
	.long 0xd72c0049                                           // 000000A439E4: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A439E8: 020296FF 83DCD12D
	v_and_or_b32 v72, 0xffff, v76, v72                         // 000000A439F0: D6570048 052298FF 0000FFFF
	v_bfe_u32 v75, v67, 4, 16                                  // 000000A439FC: D610004B 02410943
	v_dot2acc_f32_f16 v37, v68, v19                            // 000000A43A04: 044A2744
	v_and_b32_e32 v68, 0xffff, v67                             // 000000A43A08: 368886FF 0000FFFF
	v_pk_fma_f16 v70, v71, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43A10: CC0E0046 0BFC0D47 0000C931
	.long 0xd72c0047                                           // 000000A43A1C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A43A20: 020294FF 83DCD12D
	v_bfe_u32 v74, v69, 12, 16                                 // 000000A43A28: D610004A 02411945
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A43A30: D6220049 03FD0149 00006400
	.long 0xd72c004c                                           // 000000A43A3C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A43A40: 020288FF 83DCD12D
	ds_load_2addr_b32 v[67:68], v57 offset1:1                  // 000000A43A48: D8DC0100 43000039
	.long 0xd72c0053                                           // 000000A43A50: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A43A54: 02029AFF 83DCD12D
	.long 0xd72c004a                                           // 000000A43A5C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A43A60: 020294FF 83DCD12D
	v_dual_dot2acc_f32_f16 v37, v70, v20 :: v_dual_and_b32 v70, 0xffff, v69// 000000A43A68: CB242946 25468AFF 0000FFFF
	v_bfe_u32 v69, v69, 4, 16                                  // 000000A43A74: D6100045 02410945
	v_and_b32_e32 v73, 0xffff, v73                             // 000000A43A7C: 369292FF 0000FFFF
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A43A84: D6220047 03FD0147 00006400
	.long 0xd72c004b                                           // 000000A43A90: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A43A94: 020296FF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A43A9C: D6220053 03FD0153 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A43AA8: D622004A 03FD014A 00006400
	.long 0xd72c0054                                           // 000000A43AB4: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A43AB8: 02028AFF 83DCD12D
	v_lshl_or_b32 v71, v71, 16, v73                            // 000000A43AC0: D6560047 05252147
	v_sad_u8 v73, v76, 0, 0x6400                               // 000000A43AC8: D6220049 03FD014C 00006400
	ds_load_2addr_b32 v[78:79], v66 offset0:8 offset1:41       // 000000A43AD4: D8DC2908 4E000042
	v_and_b32_e32 v82, 0xffff, v74                             // 000000A43ADC: 36A494FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A43AE4: D622004B 03FD014B 00006400
	v_pk_fma_f16 v80, v71, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43AF0: CC0E0050 0BFC0D47 0000C931
	v_pk_fma_f16 v72, v72, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43AFC: CC0E0048 0BFC0D48 0000C931
	.long 0xd72c0046                                           // 000000A43B08: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A43B0C: 02028CFF 83DCD12D
	s_waitcnt lgkmcnt(1)                                       // 000000A43B14: BF89FC17
	v_mov_b32_e32 v69, v67                                     // 000000A43B18: 7E8A0343
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A43B1C: D6220054 03FD0154 00006400
	v_dot2acc_f32_f16 v36, v80, v18                            // 000000A43B28: 04482550
	v_dot2acc_f32_f16 v37, v72, v21                            // 000000A43B2C: 044A2B48
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000A43B30: BF870134
	.long 0xd73d0043                                           // 000000A43B34: D73D0043
	v_cndmask_b32_e32 v1, v45, v68, vcc_lo                     // 000000A43B38: 0202892D
	v_lshl_or_b32 v68, v83, 16, v82                            // 000000A43B3C: D6560044 05492153
	v_sad_u8 v85, v70, 0, 0x6400                               // 000000A43B44: D6220055 03FD0146 00006400
	v_pk_fma_f16 v80, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43B50: CC0E0050 0BFC0D44 0000C931
	v_lshlrev_b32_e32 v81, 16, v73                             // 000000A43B5C: 30A29290
	ds_load_2addr_b32 v[70:71], v58 offset1:1                  // 000000A43B60: D8DC0100 4600003A
	ds_load_2addr_b32 v[73:74], v59 offset1:1                  // 000000A43B68: D8DC0100 4900003B
	ds_load_2addr_b32 v[76:77], v60 offset1:1                  // 000000A43B70: D8DC0100 4C00003C
	v_and_b32_e32 v68, 0xffff, v67                             // 000000A43B78: 368886FF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 000000A43B80: BF89FC37
	v_bfe_u32 v82, v78, 8, 16                                  // 000000A43B84: D6100052 0241114E
	v_bfe_u32 v83, v78, 4, 16                                  // 000000A43B8C: D6100053 0241094E
	v_and_or_b32 v75, 0xffff, v75, v81                         // 000000A43B94: D657004B 054696FF 0000FFFF
	v_bfe_u32 v81, v78, 12, 16                                 // 000000A43BA0: D6100051 0241194E
	.long 0xd72c0044                                           // 000000A43BA8: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A43BAC: 020288FF 83DCD12D
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A43BB4: 369C9CFF 0000FFFF
	.long 0xd72c0052                                           // 000000A43BBC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A43BC0: 0202A4FF 83DCD12D
	v_pk_fma_f16 v72, v75, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43BC8: CC0E0048 0BFC0D4B 0000C931
	v_bfe_u32 v75, v67, 12, 16                                 // 000000A43BD4: D610004B 02411943
	.long 0xd72c0051                                           // 000000A43BDC: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A43BE0: 0202A2FF 83DCD12D
	.long 0xd72c004e                                           // 000000A43BE8: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A43BEC: 02029CFF 83DCD12D
	.long 0xd72c0053                                           // 000000A43BF4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A43BF8: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v36, v72, v19                            // 000000A43C00: 04482748
	.long 0xd72c0048                                           // 000000A43C04: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A43C08: 020296FF 83DCD12D
	v_bfe_u32 v75, v67, 8, 16                                  // 000000A43C10: D610004B 02411143
	v_bfe_u32 v67, v67, 4, 16                                  // 000000A43C18: D6100043 02410943
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A43C20: D6220044 03FD0144 00006400
	v_lshlrev_b32_e32 v85, 16, v85                             // 000000A43C2C: 30AAAA90
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A43C30: D6220051 03FD0151 00006400
	.long 0xd72c004b                                           // 000000A43C3C: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A43C40: 020296FF 83DCD12D
	.long 0xd72c0043                                           // 000000A43C48: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A43C4C: 020286FF 83DCD12D
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A43C54: D6220048 03FD0148 00006400
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000A43C60: 30888890
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A43C64: D622004E 03FD014E 00006400
	v_and_or_b32 v69, 0xffff, v84, v85                         // 000000A43C70: D6570045 0556A8FF 0000FFFF
	v_dot2acc_f32_f16 v36, v80, v20                            // 000000A43C7C: 04482950
	v_and_b32_e32 v72, 0xffff, v72                             // 000000A43C80: 369090FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A43C88: D622004B 03FD014B 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A43C94: D6220043 03FD0143 00006400
	v_pk_fma_f16 v69, v69, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43CA0: CC0E0045 0BFC0D45 0000C931
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A43CAC: BF870003
	v_lshl_or_b32 v75, v75, 16, v72                            // 000000A43CB0: D656004B 0521214B
	s_waitcnt lgkmcnt(2)                                       // 000000A43CB8: BF89FC27
	v_mov_b32_e32 v72, v70                                     // 000000A43CBC: 7E900346
	v_and_or_b32 v84, 0xffff, v67, v68                         // 000000A43CC0: D6570054 051286FF 0000FFFF
	v_and_b32_e32 v70, 0xffff, v81                             // 000000A43CCC: 368CA2FF 0000FFFF
	v_sad_u8 v81, v82, 0, 0x6400                               // 000000A43CD4: D6220051 03FD0152 00006400
	v_pk_fma_f16 v75, v75, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43CE0: CC0E004B 0BFC0D4B 0000C931
	.long 0xd73d0043                                           // 000000A43CEC: D73D0043
	v_cndmask_b32_e32 v1, v45, v71, vcc_lo                     // 000000A43CF0: 02028F2D
	v_sad_u8 v71, v83, 0, 0x6400                               // 000000A43CF4: D6220047 03FD0153 00006400
	v_lshlrev_b32_e32 v72, 16, v78                             // 000000A43D00: 30909C90
	v_pk_fma_f16 v68, v84, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43D04: CC0E0044 0BFC0D54 0000C931
	v_lshl_or_b32 v70, v81, 16, v70                            // 000000A43D10: D6560046 05192151
	v_dot2acc_f32_f16 v35, v75, v18                            // 000000A43D18: 0446254B
	v_bfe_u32 v75, v67, 12, 16                                 // 000000A43D1C: D610004B 02411943
	v_and_or_b32 v71, 0xffff, v71, v72                         // 000000A43D24: D6570047 05228EFF 0000FFFF
	v_bfe_u32 v72, v67, 8, 16                                  // 000000A43D30: D6100048 02411143
	v_pk_fma_f16 v70, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43D38: CC0E0046 0BFC0D46 0000C931
	v_dot2acc_f32_f16 v35, v68, v19                            // 000000A43D44: 04462744
	.long 0xd72c0044                                           // 000000A43D48: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A43D4C: 020296FF 83DCD12D
	v_pk_fma_f16 v78, v71, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43D54: CC0E004E 0BFC0D47 0000C931
	v_bfe_u32 v71, v79, 12, 16                                 // 000000A43D60: D6100047 0241194F
	v_and_b32_e32 v75, 0xffff, v79                             // 000000A43D68: 36969EFF 0000FFFF
	v_dot2acc_f32_f16 v35, v70, v20                            // 000000A43D70: 04462946
	.long 0xd72c0046                                           // 000000A43D74: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A43D78: 020290FF 83DCD12D
	v_bfe_u32 v72, v79, 8, 16                                  // 000000A43D80: D6100048 0241114F
	.long 0xd72c0047                                           // 000000A43D88: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A43D8C: 02028EFF 83DCD12D
	.long 0xd72c004b                                           // 000000A43D94: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A43D98: 020296FF 83DCD12D
	v_dot2acc_f32_f16 v36, v69, v21                            // 000000A43DA0: 04482B45
	v_bfe_u32 v69, v67, 4, 16                                  // 000000A43DA4: D6100045 02410943
	v_and_b32_e32 v67, 0xffff, v67                             // 000000A43DAC: 368686FF 0000FFFF
	.long 0xd72c0048                                           // 000000A43DB4: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A43DB8: 020290FF 83DCD12D
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A43DC0: D6220044 03FD0144 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A43DCC: D6220046 03FD0146 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A43DD8: D6220047 03FD0147 00006400
	.long 0xd72c0043                                           // 000000A43DE4: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A43DE8: 020286FF 83DCD12D
	.long 0xd72c0045                                           // 000000A43DF0: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A43DF4: 02028AFF 83DCD12D
	v_and_b32_e32 v68, 0xffff, v68                             // 000000A43DFC: 368888FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A43E04: D622004B 03FD014B 00006400
	v_and_b32_e32 v71, 0xffff, v71                             // 000000A43E10: 368E8EFF 0000FFFF
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A43E18: D6220048 03FD0148 00006400
	v_bfe_u32 v79, v79, 4, 16                                  // 000000A43E24: D610004F 0241094F
	v_lshl_or_b32 v70, v70, 16, v68                            // 000000A43E2C: D6560046 05112146
	v_lshlrev_b32_e32 v81, 16, v75                             // 000000A43E34: 30A29690
	s_waitcnt lgkmcnt(1)                                       // 000000A43E38: BF89FC17
	v_mov_b32_e32 v75, v73                                     // 000000A43E3C: 7E960349
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A43E40: D6220043 03FD0143 00006400
	v_lshl_or_b32 v72, v72, 16, v71                            // 000000A43E4C: D6560048 051D2148
	v_sad_u8 v80, v69, 0, 0x6400                               // 000000A43E54: D6220050 03FD0145 00006400
	ds_load_2addr_b32 v[68:69], v66 offset0:74 offset1:107     // 000000A43E60: D8DC6B4A 44000042
	v_pk_fma_f16 v73, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43E68: CC0E0049 0BFC0D46 0000C931
	.long 0xd73d0046                                           // 000000A43E74: D73D0046
	v_cndmask_b32_e32 v1, v45, v74, vcc_lo                     // 000000A43E78: 0202952D
	v_pk_fma_f16 v71, v72, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43E7C: CC0E0047 0BFC0D48 0000C931
	v_lshlrev_b32_e32 v67, 16, v67                             // 000000A43E88: 30868690
	.long 0xd72c004f                                           // 000000A43E8C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A43E90: 02029EFF 83DCD12D
	v_dual_dot2acc_f32_f16 v34, v73, v18 :: v_dual_dot2acc_f32_f16 v35, v78, v21// 000000A43E98: CB182549 22222B4E
	v_bfe_u32 v73, v70, 12, 16                                 // 000000A43EA0: D6100049 02411946
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A43EA8: BF8701B4
	v_and_or_b32 v67, 0xffff, v80, v67                         // 000000A43EAC: D6570043 050EA0FF 0000FFFF
	v_bfe_u32 v74, v70, 8, 16                                  // 000000A43EB8: D610004A 02411146
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A43EC0: D622004F 03FD014F 00006400
	v_pk_fma_f16 v67, v67, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43ECC: CC0E0043 0BFC0D43 0000C931
	.long 0xd72c0049                                           // 000000A43ED8: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A43EDC: 020292FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A43EE4: BF870214
	.long 0xd72c004a                                           // 000000A43EE8: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A43EEC: 020294FF 83DCD12D
	v_and_or_b32 v79, 0xffff, v79, v81                         // 000000A43EF4: D657004F 05469EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A43F00: BF870004
	v_dual_dot2acc_f32_f16 v34, v67, v19 :: v_dual_and_b32 v67, 0xffff, v70// 000000A43F04: CB242743 22428CFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A43F10: BF89FC07
	v_bfe_u32 v75, v68, 12, 16                                 // 000000A43F14: D610004B 02411944
	v_bfe_u32 v70, v70, 4, 16                                  // 000000A43F1C: D6100046 02410946
	v_bfe_u32 v78, v68, 8, 16                                  // 000000A43F24: D610004E 02411144
	v_pk_fma_f16 v72, v79, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A43F2C: CC0E0048 0BFC0D4F 0000C931
	.long 0xd72c0043                                           // 000000A43F38: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A43F3C: 020286FF 83DCD12D
	.long 0xd72c004b                                           // 000000A43F44: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A43F48: 020296FF 83DCD12D
	.long 0xd72c0046                                           // 000000A43F50: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A43F54: 02028CFF 83DCD12D
	v_bfe_u32 v79, v68, 4, 16                                  // 000000A43F5C: D610004F 02410944
	v_and_b32_e32 v80, 0xffff, v68                             // 000000A43F64: 36A088FF 0000FFFF
	.long 0xd72c0044                                           // 000000A43F6C: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A43F70: 02029CFF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A43F78: D6220049 03FD0149 00006400
	v_mov_b32_e32 v78, v76                                     // 000000A43F84: 7E9C034C
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A43F88: D6220043 03FD0143 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A43F94: D622004B 03FD014B 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A43FA0: D6220046 03FD0146 00006400
	v_dual_dot2acc_f32_f16 v34, v71, v20 :: v_dual_and_b32 v73, 0xffff, v73// 000000A43FAC: CB242947 224892FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A43FB8: BF870004
	v_lshlrev_b32_e32 v67, 16, v67                             // 000000A43FBC: 30868690
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A43FC0: D622004A 03FD014A 00006400
	v_and_b32_e32 v75, 0xffff, v75                             // 000000A43FCC: 369696FF 0000FFFF
	v_sad_u8 v76, v68, 0, 0x6400                               // 000000A43FD4: D622004C 03FD0144 00006400
	v_dot2acc_f32_f16 v34, v72, v21                            // 000000A43FE0: 04442B48
	v_and_or_b32 v70, 0xffff, v70, v67                         // 000000A43FE4: D6570046 050E8CFF 0000FFFF
	.long 0xd73d0043                                           // 000000A43FF0: D73D0043
	v_cndmask_b32_e32 v1, v45, v77, vcc_lo                     // 000000A43FF4: 02029B2D
	v_lshl_or_b32 v73, v74, 16, v73                            // 000000A43FF8: D6560049 0525214A
	.long 0xd72c004a                                           // 000000A44000: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A44004: 02029EFF 83DCD12D
	v_lshl_or_b32 v68, v76, 16, v75                            // 000000A4400C: D6560044 052D214C
	.long 0xd72c004b                                           // 000000A44014: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A44018: 0202A0FF 83DCD12D
	v_pk_fma_f16 v80, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A44020: CC0E0050 0BFC0D46 0000C931
	v_bfe_u32 v70, v67, 12, 16                                 // 000000A4402C: D6100046 02411943
	v_pk_fma_f16 v71, v73, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A44034: CC0E0047 0BFC0D49 0000C931
	v_pk_fma_f16 v81, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A44040: CC0E0051 0BFC0D44 0000C931
	v_and_b32_e32 v73, 0xffff, v67                             // 000000A4404C: 369286FF 0000FFFF
	v_sad_u8 v68, v74, 0, 0x6400                               // 000000A44054: D6220044 03FD014A 00006400
	.long 0xd72c0046                                           // 000000A44060: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A44064: 02028CFF 83DCD12D
	v_sad_u8 v74, v75, 0, 0x6400                               // 000000A4406C: D622004A 03FD014B 00006400
	v_bfe_u32 v75, v67, 8, 16                                  // 000000A44078: D610004B 02411143
	v_bfe_u32 v67, v67, 4, 16                                  // 000000A44080: D6100043 02410943
	.long 0xd72c0049                                           // 000000A44088: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A4408C: 020292FF 83DCD12D
	v_bfe_u32 v76, v69, 12, 16                                 // 000000A44094: D610004C 02411945
	v_lshlrev_b32_e32 v74, 16, v74                             // 000000A4409C: 30949490
	.long 0xd72c004b                                           // 000000A440A0: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A440A4: 020296FF 83DCD12D
	.long 0xd72c0043                                           // 000000A440AC: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A440B0: 020286FF 83DCD12D
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A440B8: D6220046 03FD0146 00006400
	.long 0xd72c004c                                           // 000000A440C4: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A440C8: 020298FF 83DCD12D
	v_and_or_b32 v82, 0xffff, v68, v74                         // 000000A440D0: D6570052 052A88FF 0000FFFF
	v_bfe_u32 v74, v69, 8, 16                                  // 000000A440DC: D610004A 02411145
	v_and_b32_e32 v78, 0xffff, v69                             // 000000A440E4: 369C8AFF 0000FFFF
	v_and_b32_e32 v70, 0xffff, v70                             // 000000A440EC: 368C8CFF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A440F4: D622004B 03FD014B 00006400
	v_sad_u8 v77, v67, 0, 0x6400                               // 000000A44100: D622004D 03FD0143 00006400
	ds_load_2addr_b32 v[67:68], v61 offset1:1                  // 000000A4410C: D8DC0100 4300003D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A44114: D6220049 03FD0149 00006400
	.long 0xd72c004a                                           // 000000A44120: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A44124: 020294FF 83DCD12D
	v_bfe_u32 v69, v69, 4, 16                                  // 000000A4412C: D6100045 02410945
	v_lshl_or_b32 v70, v75, 16, v70                            // 000000A44134: D6560046 0519214B
	.long 0xd72c004b                                           // 000000A4413C: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A44140: 02029CFF 83DCD12D
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000A44148: 30929290
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A4414C: D622004C 03FD014C 00006400
	.long 0xd72c004e                                           // 000000A44158: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A4415C: 02028AFF 83DCD12D
	v_pk_fma_f16 v83, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A44164: CC0E0053 0BFC0D46 0000C931
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A44170: D622004A 03FD014A 00006400
	v_and_or_b32 v73, 0xffff, v77, v73                         // 000000A4417C: D6570049 05269AFF 0000FFFF
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A44188: 369898FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A44190: D622004B 03FD014B 00006400
	v_dot2acc_f32_f16 v33, v71, v18                            // 000000A4419C: 04422547
	v_dot2acc_f32_f16 v32, v83, v18                            // 000000A441A0: 04402553
	v_pk_fma_f16 v84, v73, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A441A4: CC0E0054 0BFC0D49 0000C931
	v_lshl_or_b32 v85, v74, 16, v76                            // 000000A441B0: D6560055 0531214A
	ds_load_2addr_b32 v[70:71], v62 offset1:1                  // 000000A441B8: D8DC0100 4600003E
	ds_load_2addr_b32 v[73:74], v63 offset1:1                  // 000000A441C0: D8DC0100 4900003F
	ds_load_2addr_b32 v[76:77], v64 offset1:1                  // 000000A441C8: D8DC0100 4C000040
	v_sad_u8 v86, v78, 0, 0x6400                               // 000000A441D0: D6220056 03FD014E 00006400
	s_waitcnt lgkmcnt(3)                                       // 000000A441DC: BF89FC37
	v_mov_b32_e32 v69, v67                                     // 000000A441E0: 7E8A0343
	ds_load_2addr_b32 v[78:79], v66 offset0:140 offset1:173    // 000000A441E4: D8DCAD8C 4E000042
	v_lshlrev_b32_e32 v75, 16, v75                             // 000000A441EC: 30969690
	v_dot2acc_f32_f16 v32, v84, v19                            // 000000A441F0: 04402754
	v_dot2acc_f32_f16 v33, v80, v19                            // 000000A441F4: 04422750
	.long 0xd73d0043                                           // 000000A441F8: D73D0043
	v_cndmask_b32_e32 v1, v45, v68, vcc_lo                     // 000000A441FC: 0202892D
	v_pk_fma_f16 v68, v85, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A44200: CC0E0044 0BFC0D55 0000C931
	v_and_or_b32 v69, 0xffff, v86, v75                         // 000000A4420C: D6570045 052EACFF 0000FFFF
	v_pk_fma_f16 v75, v82, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A44218: CC0E004B 0BFC0D52 0000C931
	v_dot2acc_f32_f16 v33, v81, v20                            // 000000A44224: 04422951
	v_bfe_u32 v80, v67, 12, 16                                 // 000000A44228: D6100050 02411943
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A44230: BF870224
	v_pk_fma_f16 v69, v69, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A44234: CC0E0045 0BFC0D45 0000C931
	v_dot2acc_f32_f16 v32, v68, v20                            // 000000A44240: 04402944
	v_dual_dot2acc_f32_f16 v33, v75, v21 :: v_dual_and_b32 v72, 0xffff, v67// 000000A44244: CB242B4B 214886FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A44250: BF870194
	.long 0xd72c0044                                           // 000000A44254: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A44258: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v32, v69, v21                            // 000000A44260: 04402B45
	v_bfe_u32 v69, v67, 8, 16                                  // 000000A44264: D6100045 02411143
	v_bfe_u32 v67, v67, 4, 16                                  // 000000A4426C: D6100043 02410943
	.long 0xd72c0048                                           // 000000A44274: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A44278: 020290FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A44280: BF89FC07
	v_bfe_u32 v75, v78, 12, 16                                 // 000000A44284: D610004B 0241194E
	v_bfe_u32 v80, v78, 8, 16                                  // 000000A4428C: D6100050 0241114E
	.long 0xd72c0045                                           // 000000A44294: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A44298: 02028AFF 83DCD12D
	.long 0xd72c0043                                           // 000000A442A0: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A442A4: 020286FF 83DCD12D
	v_bfe_u32 v81, v78, 4, 16                                  // 000000A442AC: D6100051 0241094E
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A442B4: 369C9CFF 0000FFFF
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A442BC: D6220044 03FD0144 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A442C8: D6220048 03FD0148 00006400
	.long 0xd72c004b                                           // 000000A442D4: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A442D8: 020296FF 83DCD12D
	.long 0xd72c0050                                           // 000000A442E0: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A442E4: 0202A0FF 83DCD12D
	.long 0xd72c004e                                           // 000000A442EC: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A442F0: 02029CFF 83DCD12D
	v_and_b32_e32 v68, 0xffff, v68                             // 000000A442F8: 368888FF 0000FFFF
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A44300: D6220045 03FD0145 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A4430C: D6220043 03FD0143 00006400
	v_lshlrev_b32_e32 v82, 16, v72                             // 000000A44318: 30A49090
	v_mov_b32_e32 v72, v70                                     // 000000A4431C: 7E900346
	.long 0xd72c0051                                           // 000000A44320: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A44324: 0202A2FF 83DCD12D
	v_sad_u8 v70, v75, 0, 0x6400                               // 000000A4432C: D6220046 03FD014B 00006400
	v_lshl_or_b32 v69, v69, 16, v68                            // 000000A44338: D6560045 05112145
	v_and_or_b32 v75, 0xffff, v67, v82                         // 000000A44340: D657004B 054A86FF 0000FFFF
	.long 0xd73d0043                                           // 000000A4434C: D73D0043
	v_cndmask_b32_e32 v1, v45, v71, vcc_lo                     // 000000A44350: 02028F2D
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A44354: D622004E 03FD014E 00006400
	v_and_b32_e32 v68, 0xffff, v70                             // 000000A44360: 36888CFF 0000FFFF
	v_sad_u8 v70, v80, 0, 0x6400                               // 000000A44368: D6220046 03FD0150 00006400
	v_sad_u8 v71, v81, 0, 0x6400                               // 000000A44374: D6220047 03FD0151 00006400
	v_pk_fma_f16 v69, v69, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A44380: CC0E0045 0BFC0D45 0000C931
	v_lshlrev_b32_e32 v72, 16, v78                             // 000000A4438C: 30909C90
	v_bfe_u32 v78, v67, 12, 16                                 // 000000A44390: D610004E 02411943
	v_lshl_or_b32 v68, v70, 16, v68                            // 000000A44398: D6560044 05112146
	v_pk_fma_f16 v75, v75, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A443A0: CC0E004B 0BFC0D4B 0000C931
	v_dot2acc_f32_f16 v31, v69, v18                            // 000000A443AC: 043E2545
	v_and_or_b32 v70, 0xffff, v71, v72                         // 000000A443B0: D6570046 05228EFF 0000FFFF
	.long 0xd72c0045                                           // 000000A443BC: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A443C0: 02029CFF 83DCD12D
	v_bfe_u32 v71, v67, 8, 16                                  // 000000A443C8: D6100047 02411143
	v_and_b32_e32 v78, 0xffff, v79                             // 000000A443D0: 369C9EFF 0000FFFF
	v_dot2acc_f32_f16 v31, v75, v19                            // 000000A443D8: 043E274B
	v_pk_fma_f16 v80, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A443DC: CC0E0050 0BFC0D46 0000C931
	v_bfe_u32 v75, v79, 8, 16                                  // 000000A443E8: D610004B 0241114F
	.long 0xd72c0046                                           // 000000A443F0: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A443F4: 02028EFF 83DCD12D
	v_bfe_u32 v71, v79, 12, 16                                 // 000000A443FC: D6100047 0241194F
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A44404: D6220045 03FD0145 00006400
	v_bfe_u32 v79, v79, 4, 16                                  // 000000A44410: D610004F 0241094F
	.long 0xd72c004e                                           // 000000A44418: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A4441C: 02029CFF 83DCD12D
	v_pk_fma_f16 v72, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A44424: CC0E0048 0BFC0D44 0000C931
	.long 0xd72c0047                                           // 000000A44430: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A44434: 02028EFF 83DCD12D
	v_and_b32_e32 v69, 0xffff, v69                             // 000000A4443C: 368A8AFF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A44444: D6220046 03FD0146 00006400
	v_bfe_u32 v68, v67, 4, 16                                  // 000000A44450: D6100044 02410943
	v_dot2acc_f32_f16 v31, v72, v20                            // 000000A44458: 043E2948
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A4445C: D622004E 03FD014E 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A44468: BF870004
	v_lshl_or_b32 v69, v70, 16, v69                            // 000000A4446C: D6560045 05152146
	.long 0xd72c0046                                           // 000000A44474: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A44478: 020296FF 83DCD12D
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A44480: D6220047 03FD0147 00006400
	.long 0xd72c004b                                           // 000000A4448C: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A44490: 02029EFF 83DCD12D
	v_lshlrev_b32_e32 v78, 16, v78                             // 000000A44498: 309C9C90
	.long 0xd72c0044                                           // 000000A4449C: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A444A0: 020288FF 83DCD12D
	v_dot2acc_f32_f16 v31, v80, v21                            // 000000A444A8: 043E2B50
	v_and_b32_e32 v71, 0xffff, v71                             // 000000A444AC: 368E8EFF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A444B4: D6220046 03FD0146 00006400
	v_sad_u8 v82, v75, 0, 0x6400                               // 000000A444C0: D6220052 03FD014B 00006400
	v_mov_b32_e32 v75, v73                                     // 000000A444CC: 7E960349
	v_sad_u8 v79, v68, 0, 0x6400                               // 000000A444D0: D622004F 03FD0144 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A444DC: BF870214
	v_lshl_or_b32 v71, v70, 16, v71                            // 000000A444E0: D6560047 051D2146
	v_and_or_b32 v78, 0xffff, v82, v78                         // 000000A444E8: D657004E 053AA4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A444F4: BF8701A2
	v_pk_fma_f16 v71, v71, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A444F8: CC0E0047 0BFC0D47 0000C931
	v_and_b32_e32 v67, 0xffff, v67                             // 000000A44504: 368686FF 0000FFFF
	v_pk_fma_f16 v72, v78, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A4450C: CC0E0048 0BFC0D4E 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A44518: BF870092
	.long 0xd72c0043                                           // 000000A4451C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A44520: 020286FF 83DCD12D
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A44528: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000A44534: BF8701D1
	v_lshlrev_b32_e32 v81, 16, v67                             // 000000A44538: 30A28690
	ds_load_2addr_b32 v[67:68], v66 offset0:206 offset1:239    // 000000A4453C: D8DCEFCE 43000042
	v_and_or_b32 v73, 0xffff, v79, v81                         // 000000A44544: D6570049 05469EFF 0000FFFF
	v_pk_fma_f16 v79, v69, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A44550: CC0E004F 0BFC0D45 0000C931
	.long 0xd73d0045                                           // 000000A4455C: D73D0045
	v_cndmask_b32_e32 v1, v45, v74, vcc_lo                     // 000000A44560: 0202952D
	v_pk_fma_f16 v70, v73, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A44564: CC0E0046 0BFC0D49 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A44570: BF870193
	v_dot2acc_f32_f16 v30, v79, v18                            // 000000A44574: 043C254F
	v_bfe_u32 v73, v69, 12, 16                                 // 000000A44578: D6100049 02411945
	v_bfe_u32 v74, v69, 8, 16                                  // 000000A44580: D610004A 02411145
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A44588: BF870223
	v_dot2acc_f32_f16 v30, v70, v19                            // 000000A4458C: 043C2746
	v_and_b32_e32 v70, 0xffff, v69                             // 000000A44590: 368C8AFF 0000FFFF
	.long 0xd72c0049                                           // 000000A44598: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A4459C: 020292FF 83DCD12D
	v_bfe_u32 v69, v69, 4, 16                                  // 000000A445A4: D6100045 02410945
	.long 0xd72c004a                                           // 000000A445AC: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A445B0: 020294FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A445B8: BF89FC07
	v_bfe_u32 v75, v67, 12, 16                                 // 000000A445BC: D610004B 02411943
	.long 0xd72c0046                                           // 000000A445C4: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A445C8: 02028CFF 83DCD12D
	v_bfe_u32 v78, v67, 8, 16                                  // 000000A445D0: D610004E 02411143
	.long 0xd72c0045                                           // 000000A445D8: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A445DC: 02028AFF 83DCD12D
	v_dot2acc_f32_f16 v30, v71, v20                            // 000000A445E4: 043C2947
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A445E8: D6220049 03FD0149 00006400
	.long 0xd72c004b                                           // 000000A445F4: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A445F8: 020296FF 83DCD12D
	.long 0xd72c0051                                           // 000000A44600: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A44604: 02029CFF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A4460C: D622004A 03FD014A 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A44618: D6220046 03FD0146 00006400
	v_and_b32_e32 v73, 0xffff, v73                             // 000000A44624: 369292FF 0000FFFF
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A4462C: D6220045 03FD0145 00006400
	v_mov_b32_e32 v78, v76                                     // 000000A44638: 7E9C034C
	v_bfe_u32 v79, v67, 4, 16                                  // 000000A4463C: D610004F 02410943
	v_lshlrev_b32_e32 v70, 16, v70                             // 000000A44644: 308C8C90
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A44648: D622004B 03FD014B 00006400
	v_lshl_or_b32 v73, v74, 16, v73                            // 000000A44654: D6560049 0525214A
	v_sad_u8 v76, v81, 0, 0x6400                               // 000000A4465C: D622004C 03FD0151 00006400
	.long 0xd72c004f                                           // 000000A44668: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A4466C: 02029EFF 83DCD12D
	v_and_or_b32 v74, 0xffff, v69, v70                         // 000000A44674: D657004A 051A8AFF 0000FFFF
	.long 0xd73d0045                                           // 000000A44680: D73D0045
	v_cndmask_b32_e32 v1, v45, v77, vcc_lo                     // 000000A44684: 02029B2D
	v_and_b32_e32 v75, 0xffff, v75                             // 000000A44688: 369696FF 0000FFFF
	v_pk_fma_f16 v71, v73, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A44690: CC0E0047 0BFC0D49 0000C931
	v_bfe_u32 v78, v68, 12, 16                                 // 000000A4469C: D610004E 02411944
	v_pk_fma_f16 v73, v74, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A446A4: CC0E0049 0BFC0D4A 0000C931
	v_and_b32_e32 v67, 0xffff, v67                             // 000000A446B0: 368686FF 0000FFFF
	v_bfe_u32 v74, v69, 12, 16                                 // 000000A446B8: D610004A 02411945
	v_lshl_or_b32 v70, v76, 16, v75                            // 000000A446C0: D6560046 052D214C
	v_and_b32_e32 v76, 0xffff, v69                             // 000000A446C8: 36988AFF 0000FFFF
	v_bfe_u32 v77, v69, 8, 16                                  // 000000A446D0: D610004D 02411145
	v_bfe_u32 v69, v69, 4, 16                                  // 000000A446D8: D6100045 02410945
	.long 0xd72c004a                                           // 000000A446E0: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A446E4: 020294FF 83DCD12D
	v_sad_u8 v75, v79, 0, 0x6400                               // 000000A446EC: D622004B 03FD014F 00006400
	.long 0xd72c004c                                           // 000000A446F8: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A446FC: 020298FF 83DCD12D
	.long 0xd72c004d                                           // 000000A44704: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A44708: 02029AFF 83DCD12D
	.long 0xd72c0045                                           // 000000A44710: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A44714: 02028AFF 83DCD12D
	v_bfe_u32 v79, v68, 8, 16                                  // 000000A4471C: D610004F 02411144
	.long 0xd72c004e                                           // 000000A44724: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A44728: 02029CFF 83DCD12D
	v_bfe_u32 v81, v68, 4, 16                                  // 000000A44730: D6100051 02410944
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A44738: D622004A 03FD014A 00006400
	v_and_b32_e32 v68, 0xffff, v68                             // 000000A44744: 368888FF 0000FFFF
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A4474C: D622004C 03FD014C 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A44758: D622004D 03FD014D 00006400
	.long 0xd72c0043                                           // 000000A44764: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A44768: 020286FF 83DCD12D
	v_and_b32_e32 v74, 0xffff, v74                             // 000000A44770: 369494FF 0000FFFF
	.long 0xd72c004f                                           // 000000A44778: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A4477C: 02029EFF 83DCD12D
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A44784: D6220045 03FD0145 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 000000A44790: 30989890
	.long 0xd72c0044                                           // 000000A44794: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A44798: 020288FF 83DCD12D
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A447A0: D622004E 03FD014E 00006400
	v_lshl_or_b32 v74, v77, 16, v74                            // 000000A447AC: D656004A 0529214D
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A447B4: D6220043 03FD0143 00006400
	v_and_or_b32 v69, 0xffff, v69, v76                         // 000000A447C0: D6570045 05328AFF 0000FFFF
	.long 0xd72c004c                                           // 000000A447CC: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A447D0: 0202A2FF 83DCD12D
	v_and_b32_e32 v77, 0xffff, v78                             // 000000A447D8: 369A9CFF 0000FFFF
	v_sad_u8 v78, v79, 0, 0x6400                               // 000000A447E0: D622004E 03FD014F 00006400
	v_dot2acc_f32_f16 v29, v71, v18                            // 000000A447EC: 043A2547
	v_pk_fma_f16 v71, v74, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A447F0: CC0E0047 0BFC0D4A 0000C931
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A447FC: D6220044 03FD0144 00006400
	v_lshlrev_b32_e32 v67, 16, v67                             // 000000A44808: 30868690
	v_pk_fma_f16 v69, v69, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A4480C: CC0E0045 0BFC0D45 0000C931
	v_lshl_or_b32 v74, v78, 16, v77                            // 000000A44818: D656004A 0535214E
	v_dot2acc_f32_f16 v1, v71, v18                             // 000000A44820: 04022547
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A44824: D622004C 03FD014C 00006400
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000A44830: 30888890
	v_pk_fma_f16 v70, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A44834: CC0E0046 0BFC0D46 0000C931
	v_and_or_b32 v18, 0xffff, v75, v67                         // 000000A44840: D6570012 050E96FF 0000FFFF
	v_dot2acc_f32_f16 v29, v73, v19                            // 000000A4484C: 043A2749
	v_pk_fma_f16 v67, v74, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A44850: CC0E0043 0BFC0D4A 0000C931
	v_dot2acc_f32_f16 v1, v69, v19                             // 000000A4485C: 04022745
	v_and_or_b32 v68, 0xffff, v76, v68                         // 000000A44860: D6570044 051298FF 0000FFFF
	v_pk_fma_f16 v18, v18, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A4486C: CC0E0012 0BFC0D12 0000C931
	v_dual_dot2acc_f32_f16 v29, v70, v20 :: v_dual_dot2acc_f32_f16 v30, v72, v21// 000000A44878: CB182946 1D1E2B48
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A44880: BF870234
	v_dot2acc_f32_f16 v1, v67, v20                             // 000000A44884: 04022943
	v_add_nc_u32_e32 v20, v47, v48                             // 000000A44888: 4A28612F
	v_pk_fma_f16 v19, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A4488C: CC0E0013 0BFC0D44 0000C931
	v_dot2acc_f32_f16 v29, v18, v21                            // 000000A44898: 043A2B12
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A4489C: BF870193
	.long 0xd44a0000                                           // 000000A448A0: D44A0000
	v_cndmask_b32_e32 v1, 21, v20, vcc_lo                      // 000000A448A4: 02022895
	v_dot2acc_f32_f16 v1, v19, v21                             // 000000A448A8: 04022B13
	s_or_b32 s5, s0, s5                                        // 000000A448AC: 8C050500
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A448B0: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000A448B4: 917E057E
	s_cbranch_execz 257                                        // 000000A448B8: BFA50101 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4dc0>
	s_waitcnt vmcnt(15)                                        // 000000A448BC: BF893FF7
	ds_store_b32 v44, v2 offset:5120                           // 000000A448C0: D8341400 0000022C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A448C8: BE80206A
	s_cbranch_execnz 131                                       // 000000A448CC: BFA60083 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4bdc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A448D0: 8C7E007E
	s_waitcnt vmcnt(14)                                        // 000000A448D4: BF893BF7
	ds_store_b32 v44, v3 offset:5252                           // 000000A448D8: D8341484 0000032C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A448E0: BE80206A
	s_cbranch_execnz 133                                       // 000000A448E4: BFA60085 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4bfc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A448E8: 8C7E007E
	s_waitcnt vmcnt(13)                                        // 000000A448EC: BF8937F7
	ds_store_b32 v44, v4 offset:5384                           // 000000A448F0: D8341508 0000042C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A448F8: BE80206A
	s_cbranch_execnz 135                                       // 000000A448FC: BFA60087 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4c1c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44900: 8C7E007E
	s_waitcnt vmcnt(12)                                        // 000000A44904: BF8933F7
	ds_store_b32 v44, v5 offset:5516                           // 000000A44908: D834158C 0000052C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44910: BE80206A
	s_cbranch_execnz 137                                       // 000000A44914: BFA60089 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4c3c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44918: 8C7E007E
	s_waitcnt vmcnt(11)                                        // 000000A4491C: BF892FF7
	ds_store_b32 v44, v6 offset:5648                           // 000000A44920: D8341610 0000062C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44928: BE80206A
	s_cbranch_execnz 139                                       // 000000A4492C: BFA6008B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4c5c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44930: 8C7E007E
	s_waitcnt vmcnt(10)                                        // 000000A44934: BF892BF7
	ds_store_b32 v44, v7 offset:5780                           // 000000A44938: D8341694 0000072C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44940: BE80206A
	s_cbranch_execnz 141                                       // 000000A44944: BFA6008D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4c7c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44948: 8C7E007E
	s_waitcnt vmcnt(9)                                         // 000000A4494C: BF8927F7
	ds_store_b32 v44, v8 offset:5912                           // 000000A44950: D8341718 0000082C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44958: BE80206A
	s_cbranch_execnz 143                                       // 000000A4495C: BFA6008F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4c9c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44960: 8C7E007E
	s_waitcnt vmcnt(8)                                         // 000000A44964: BF8923F7
	ds_store_b32 v44, v9 offset:6044                           // 000000A44968: D834179C 0000092C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44970: BE80206A
	s_cbranch_execnz 145                                       // 000000A44974: BFA60091 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4cbc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44978: 8C7E007E
	s_waitcnt vmcnt(7)                                         // 000000A4497C: BF891FF7
	ds_store_b32 v44, v10 offset:6176                          // 000000A44980: D8341820 00000A2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44988: BE80206A
	s_cbranch_execnz 147                                       // 000000A4498C: BFA60093 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4cdc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44990: 8C7E007E
	s_waitcnt vmcnt(6)                                         // 000000A44994: BF891BF7
	ds_store_b32 v44, v11 offset:6308                          // 000000A44998: D83418A4 00000B2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A449A0: BE80206A
	s_cbranch_execnz 149                                       // 000000A449A4: BFA60095 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4cfc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A449A8: 8C7E007E
	s_waitcnt vmcnt(5)                                         // 000000A449AC: BF8917F7
	ds_store_b32 v44, v12 offset:6440                          // 000000A449B0: D8341928 00000C2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A449B8: BE80206A
	s_cbranch_execnz 151                                       // 000000A449BC: BFA60097 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4d1c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A449C0: 8C7E007E
	s_waitcnt vmcnt(4)                                         // 000000A449C4: BF8913F7
	ds_store_b32 v44, v13 offset:6572                          // 000000A449C8: D83419AC 00000D2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A449D0: BE80206A
	s_cbranch_execnz 153                                       // 000000A449D4: BFA60099 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4d3c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A449D8: 8C7E007E
	s_waitcnt vmcnt(3)                                         // 000000A449DC: BF890FF7
	ds_store_b32 v44, v14 offset:6704                          // 000000A449E0: D8341A30 00000E2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A449E8: BE80206A
	s_cbranch_execnz 155                                       // 000000A449EC: BFA6009B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4d5c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A449F0: 8C7E007E
	s_waitcnt vmcnt(2)                                         // 000000A449F4: BF890BF7
	ds_store_b32 v44, v15 offset:6836                          // 000000A449F8: D8341AB4 00000F2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44A00: BE80206A
	s_cbranch_execnz 157                                       // 000000A44A04: BFA6009D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4d7c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44A08: 8C7E007E
	s_waitcnt vmcnt(1)                                         // 000000A44A0C: BF8907F7
	ds_store_b32 v44, v16 offset:6968                          // 000000A44A10: D8341B38 0000102C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44A18: BE80206A
	s_cbranch_execnz 159                                       // 000000A44A1C: BFA6009F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4d9c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44A20: 8C7E007E
	s_waitcnt vmcnt(0)                                         // 000000A44A24: BF8903F7
	ds_store_b32 v44, v17 offset:7100                          // 000000A44A28: D8341BBC 0000112C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44A30: BE80206A
	ds_store_b32 v43, v17 offset:7228                          // 000000A44A34: D8341C3C 0000112B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44A3C: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A44A40: BF870009
	s_mov_b32 s1, exec_lo                                      // 000000A44A44: BE81007E
	.long 0xd4c9007e                                           // 000000A44A48: D4C9007E
	v_cndmask_b32_e32 v1, v48, v27, vcc_lo                     // 000000A44A4C: 02023730
	s_cbranch_execz 63702                                      // 000000A44A50: BFA5F8D6 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2eac>
	s_clause 0xf                                               // 000000A44A54: BF85000F
	global_load_b32 v2, v[22:23], off                          // 000000A44A58: DC520000 027C0016
	global_load_b32 v3, v[22:23], off offset:128               // 000000A44A60: DC520080 037C0016
	global_load_b32 v4, v[22:23], off offset:256               // 000000A44A68: DC520100 047C0016
	global_load_b32 v5, v[22:23], off offset:384               // 000000A44A70: DC520180 057C0016
	global_load_b32 v6, v[22:23], off offset:512               // 000000A44A78: DC520200 067C0016
	global_load_b32 v7, v[22:23], off offset:640               // 000000A44A80: DC520280 077C0016
	global_load_b32 v8, v[22:23], off offset:768               // 000000A44A88: DC520300 087C0016
	global_load_b32 v9, v[22:23], off offset:896               // 000000A44A90: DC520380 097C0016
	global_load_b32 v10, v[22:23], off offset:1024             // 000000A44A98: DC520400 0A7C0016
	global_load_b32 v11, v[22:23], off offset:1152             // 000000A44AA0: DC520480 0B7C0016
	global_load_b32 v12, v[22:23], off offset:1280             // 000000A44AA8: DC520500 0C7C0016
	global_load_b32 v13, v[22:23], off offset:1408             // 000000A44AB0: DC520580 0D7C0016
	global_load_b32 v14, v[22:23], off offset:1536             // 000000A44AB8: DC520600 0E7C0016
	global_load_b32 v15, v[22:23], off offset:1664             // 000000A44AC0: DC520680 0F7C0016
	global_load_b32 v16, v[22:23], off offset:1792             // 000000A44AC8: DC520700 107C0016
	global_load_b32 v17, v[22:23], off offset:1920             // 000000A44AD0: DC520780 117C0016
	s_branch 63668                                             // 000000A44AD8: BFA0F8B4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2eac>
	ds_store_b32 v43, v2 offset:5248                           // 000000A44ADC: D8341480 0000022B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44AE4: 8C7E007E
	s_waitcnt vmcnt(14)                                        // 000000A44AE8: BF893BF7
	ds_store_b32 v44, v3 offset:5252                           // 000000A44AEC: D8341484 0000032C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44AF4: BE80206A
	s_cbranch_execz 65403                                      // 000000A44AF8: BFA5FF7B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x49e8>
	ds_store_b32 v43, v3 offset:5380                           // 000000A44AFC: D8341504 0000032B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44B04: 8C7E007E
	s_waitcnt vmcnt(13)                                        // 000000A44B08: BF8937F7
	ds_store_b32 v44, v4 offset:5384                           // 000000A44B0C: D8341508 0000042C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44B14: BE80206A
	s_cbranch_execz 65401                                      // 000000A44B18: BFA5FF79 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4a00>
	ds_store_b32 v43, v4 offset:5512                           // 000000A44B1C: D8341588 0000042B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44B24: 8C7E007E
	s_waitcnt vmcnt(12)                                        // 000000A44B28: BF8933F7
	ds_store_b32 v44, v5 offset:5516                           // 000000A44B2C: D834158C 0000052C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44B34: BE80206A
	s_cbranch_execz 65399                                      // 000000A44B38: BFA5FF77 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4a18>
	ds_store_b32 v43, v5 offset:5644                           // 000000A44B3C: D834160C 0000052B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44B44: 8C7E007E
	s_waitcnt vmcnt(11)                                        // 000000A44B48: BF892FF7
	ds_store_b32 v44, v6 offset:5648                           // 000000A44B4C: D8341610 0000062C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44B54: BE80206A
	s_cbranch_execz 65397                                      // 000000A44B58: BFA5FF75 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4a30>
	ds_store_b32 v43, v6 offset:5776                           // 000000A44B5C: D8341690 0000062B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44B64: 8C7E007E
	s_waitcnt vmcnt(10)                                        // 000000A44B68: BF892BF7
	ds_store_b32 v44, v7 offset:5780                           // 000000A44B6C: D8341694 0000072C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44B74: BE80206A
	s_cbranch_execz 65395                                      // 000000A44B78: BFA5FF73 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4a48>
	ds_store_b32 v43, v7 offset:5908                           // 000000A44B7C: D8341714 0000072B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44B84: 8C7E007E
	s_waitcnt vmcnt(9)                                         // 000000A44B88: BF8927F7
	ds_store_b32 v44, v8 offset:5912                           // 000000A44B8C: D8341718 0000082C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44B94: BE80206A
	s_cbranch_execz 65393                                      // 000000A44B98: BFA5FF71 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4a60>
	ds_store_b32 v43, v8 offset:6040                           // 000000A44B9C: D8341798 0000082B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44BA4: 8C7E007E
	s_waitcnt vmcnt(8)                                         // 000000A44BA8: BF8923F7
	ds_store_b32 v44, v9 offset:6044                           // 000000A44BAC: D834179C 0000092C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44BB4: BE80206A
	s_cbranch_execz 65391                                      // 000000A44BB8: BFA5FF6F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4a78>
	ds_store_b32 v43, v9 offset:6172                           // 000000A44BBC: D834181C 0000092B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44BC4: 8C7E007E
	s_waitcnt vmcnt(7)                                         // 000000A44BC8: BF891FF7
	ds_store_b32 v44, v10 offset:6176                          // 000000A44BCC: D8341820 00000A2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44BD4: BE80206A
	s_cbranch_execz 65389                                      // 000000A44BD8: BFA5FF6D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4a90>
	ds_store_b32 v43, v10 offset:6304                          // 000000A44BDC: D83418A0 00000A2B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44BE4: 8C7E007E
	s_waitcnt vmcnt(6)                                         // 000000A44BE8: BF891BF7
	ds_store_b32 v44, v11 offset:6308                          // 000000A44BEC: D83418A4 00000B2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44BF4: BE80206A
	s_cbranch_execz 65387                                      // 000000A44BF8: BFA5FF6B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4aa8>
	ds_store_b32 v43, v11 offset:6436                          // 000000A44BFC: D8341924 00000B2B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44C04: 8C7E007E
	s_waitcnt vmcnt(5)                                         // 000000A44C08: BF8917F7
	ds_store_b32 v44, v12 offset:6440                          // 000000A44C0C: D8341928 00000C2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44C14: BE80206A
	s_cbranch_execz 65385                                      // 000000A44C18: BFA5FF69 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4ac0>
	ds_store_b32 v43, v12 offset:6568                          // 000000A44C1C: D83419A8 00000C2B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44C24: 8C7E007E
	s_waitcnt vmcnt(4)                                         // 000000A44C28: BF8913F7
	ds_store_b32 v44, v13 offset:6572                          // 000000A44C2C: D83419AC 00000D2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44C34: BE80206A
	s_cbranch_execz 65383                                      // 000000A44C38: BFA5FF67 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4ad8>
	ds_store_b32 v43, v13 offset:6700                          // 000000A44C3C: D8341A2C 00000D2B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44C44: 8C7E007E
	s_waitcnt vmcnt(3)                                         // 000000A44C48: BF890FF7
	ds_store_b32 v44, v14 offset:6704                          // 000000A44C4C: D8341A30 00000E2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44C54: BE80206A
	s_cbranch_execz 65381                                      // 000000A44C58: BFA5FF65 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4af0>
	ds_store_b32 v43, v14 offset:6832                          // 000000A44C5C: D8341AB0 00000E2B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44C64: 8C7E007E
	s_waitcnt vmcnt(2)                                         // 000000A44C68: BF890BF7
	ds_store_b32 v44, v15 offset:6836                          // 000000A44C6C: D8341AB4 00000F2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44C74: BE80206A
	s_cbranch_execz 65379                                      // 000000A44C78: BFA5FF63 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4b08>
	ds_store_b32 v43, v15 offset:6964                          // 000000A44C7C: D8341B34 00000F2B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44C84: 8C7E007E
	s_waitcnt vmcnt(1)                                         // 000000A44C88: BF8907F7
	ds_store_b32 v44, v16 offset:6968                          // 000000A44C8C: D8341B38 0000102C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44C94: BE80206A
	s_cbranch_execz 65377                                      // 000000A44C98: BFA5FF61 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4b20>
	ds_store_b32 v43, v16 offset:7096                          // 000000A44C9C: D8341BB8 0000102B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A44CA4: 8C7E007E
	s_waitcnt vmcnt(0)                                         // 000000A44CA8: BF8903F7
	ds_store_b32 v44, v17 offset:7100                          // 000000A44CAC: D8341BBC 0000112C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A44CB4: BE80206A
	s_cbranch_execnz 65374                                     // 000000A44CB8: BFA6FF5E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4b34>
	s_branch 65375                                             // 000000A44CBC: BFA0FF5F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4b3c>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000A44CC0: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A44CC4: BF870009
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A44CC8: 8C7E047E
	s_waitcnt vmcnt(14)                                        // 000000A44CCC: BF893BF7
	v_dual_mov_b32 v2, v28 :: v_dual_mov_b32 v3, v42           // 000000A44CD0: CA10011C 0202012A
	s_waitcnt vmcnt(12)                                        // 000000A44CD8: BF8933F7
	v_dual_mov_b32 v4, v41 :: v_dual_mov_b32 v5, v40           // 000000A44CDC: CA100129 04040128
	s_waitcnt vmcnt(10)                                        // 000000A44CE4: BF892BF7
	v_dual_mov_b32 v6, v39 :: v_dual_mov_b32 v7, v38           // 000000A44CE8: CA100127 06060126
	s_waitcnt vmcnt(8)                                         // 000000A44CF0: BF8923F7
	v_dual_mov_b32 v8, v37 :: v_dual_mov_b32 v9, v36           // 000000A44CF4: CA100125 08080124
	s_waitcnt vmcnt(6)                                         // 000000A44CFC: BF891BF7
	v_dual_mov_b32 v10, v35 :: v_dual_mov_b32 v11, v34         // 000000A44D00: CA100123 0A0A0122
	s_waitcnt vmcnt(4)                                         // 000000A44D08: BF8913F7
	v_dual_mov_b32 v12, v33 :: v_dual_mov_b32 v13, v32         // 000000A44D0C: CA100121 0C0C0120
	s_waitcnt vmcnt(2)                                         // 000000A44D14: BF890BF7
	v_dual_mov_b32 v14, v31 :: v_dual_mov_b32 v15, v30         // 000000A44D18: CA10011F 0E0E011E
	s_waitcnt vmcnt(1)                                         // 000000A44D20: BF8907F7
	v_mov_b32_e32 v16, v29                                     // 000000A44D24: 7E20031D
	s_waitcnt vmcnt(0)                                         // 000000A44D28: BF8903F7
	v_mov_b32_e32 v17, v1                                      // 000000A44D2C: 7E220301
	s_mov_b32 s0, 0x76543210                                   // 000000A44D30: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A44D38: BF870009
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000A44D3C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000A44D48: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000A44D54: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000A44D60: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000A44D6C: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000A44D78: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000A44D84: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000A44D90: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000A44D9C: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000A44DA8: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000A44DB4: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000A44DC0: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000A44DCC: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000A44DD8: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000A44DE4: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000A44DF0: D65C0011 03FC0111 FEDCBA98
	.long 0xd44c0000                                           // 000000A44DFC: D44C0000
	v_cndmask_b32_e32 v1, 16, v25, vcc_lo                      // 000000A44E00: 02023290
	s_barrier                                                  // 000000A44E04: BFBD0000
	buffer_gl0_inv                                             // 000000A44E08: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000A44E10: BE812000
	s_cbranch_execz 34                                         // 000000A44E14: BFA50022 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4fa0>
	v_dual_add_f32 v1, v1, v17 :: v_dual_add_f32 v2, v28, v2   // 000000A44E18: C9082301 0102051C
	v_dual_add_f32 v3, v42, v3 :: v_dual_add_f32 v4, v41, v4   // 000000A44E20: C908072A 03040929
	v_lshl_or_b32 v17, v24, 10, v26                            // 000000A44E28: D6560011 04691518
	v_dual_add_f32 v5, v40, v5 :: v_dual_add_f32 v6, v39, v6   // 000000A44E30: C9080B28 05060D27
	v_dual_add_f32 v7, v38, v7 :: v_dual_add_f32 v8, v37, v8   // 000000A44E38: C9080F26 07081125
	v_dual_add_f32 v9, v36, v9 :: v_dual_add_f32 v10, v35, v10 // 000000A44E40: C9081324 090A1523
	v_dual_add_f32 v11, v34, v11 :: v_dual_add_f32 v12, v33, v12// 000000A44E48: C9081722 0B0C1921
	v_dual_add_f32 v13, v32, v13 :: v_dual_add_f32 v14, v31, v14// 000000A44E50: C9081B20 0D0E1D1F
	v_dual_add_f32 v15, v30, v15 :: v_dual_add_f32 v16, v29, v16// 000000A44E58: C9081F1E 0F10211D
	ds_store_2addr_b32 v17, v2, v3 offset1:16                  // 000000A44E60: D8381000 00030211
	ds_store_2addr_b32 v17, v4, v5 offset0:32 offset1:48       // 000000A44E68: D8383020 00050411
	ds_store_2addr_b32 v17, v6, v7 offset0:64 offset1:80       // 000000A44E70: D8385040 00070611
	ds_store_2addr_b32 v17, v8, v9 offset0:96 offset1:112      // 000000A44E78: D8387060 00090811
	ds_store_2addr_b32 v17, v10, v11 offset0:128 offset1:144   // 000000A44E80: D8389080 000B0A11
	ds_store_2addr_b32 v17, v12, v13 offset0:160 offset1:176   // 000000A44E88: D838B0A0 000D0C11
	ds_store_2addr_b32 v17, v14, v15 offset0:192 offset1:208   // 000000A44E90: D838D0C0 000F0E11
	ds_store_2addr_b32 v17, v16, v1 offset0:224 offset1:240    // 000000A44E98: D838F0E0 00011011
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A44EA0: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 000000A44EA4: BF89FC07
	s_barrier                                                  // 000000A44EA8: BFBD0000
	buffer_gl0_inv                                             // 000000A44EAC: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 000000A44EB4: BE81007E
	v_cmpx_eq_u32_e32 0, v24                                   // 000000A44EB8: 7D943080
	s_cbranch_execz 1333                                       // 000000A44EBC: BFA50535 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x6494>
	v_and_b32_e32 v3, 15, v0                                   // 000000A44EC0: 3606008F
	s_mul_i32 s1, s3, 0xa00                                    // 000000A44EC4: 9601FF03 00000A00
	s_mul_hi_i32 s4, s3, 0xa00                                 // 000000A44ECC: 9704FF03 00000A00
	s_add_u32 s1, s18, s1                                      // 000000A44ED4: 80010112
	s_addc_u32 s7, s19, s4                                     // 000000A44ED8: 82070413
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000A44EDC: 30080682
	s_lshl_b32 s4, s2, 7                                       // 000000A44EE0: 84048702
	s_mul_hi_i32 s2, s3, 0x500                                 // 000000A44EE4: 9702FF03 00000500
	s_ashr_i32 s5, s4, 31                                      // 000000A44EEC: 86059F04
	ds_load_2addr_b32 v[1:2], v4 offset1:16                    // 000000A44EF0: D8DC1000 01000004
	ds_load_2addr_b32 v[5:6], v4 offset0:128 offset1:144       // 000000A44EF8: D8DC9080 05000004
	s_lshl_b64 s[12:13], s[4:5], 1                             // 000000A44F00: 848C8104
	v_lshlrev_b32_e32 v52, 1, v0                               // 000000A44F04: 30680081
	s_add_u32 s6, s1, s12                                      // 000000A44F08: 80060C01
	s_addc_u32 s7, s7, s13                                     // 000000A44F0C: 82070D07
	s_mul_i32 s1, s3, 0x500                                    // 000000A44F10: 9601FF03 00000500
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A44F18: BF870009
	s_add_u32 s1, s20, s1                                      // 000000A44F1C: 80010114
	s_addc_u32 s2, s21, s2                                     // 000000A44F20: 82020215
	s_add_u32 s8, s1, s12                                      // 000000A44F24: 80080C01
	s_addc_u32 s9, s2, s13                                     // 000000A44F28: 82090D02
	s_waitcnt lgkmcnt(1)                                       // 000000A44F2C: BF89FC17
	v_add_f32_e32 v1, 0, v1                                    // 000000A44F30: 06020280
	v_add_nc_u32_e32 v45, 0x400, v4                            // 000000A44F34: 4A5A08FF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000A44F3C: BF89FC07
	v_dual_add_f32 v5, 0, v5 :: v_dual_add_nc_u32 v46, 0x800, v4// 000000A44F40: C9200A80 052E08FF 00000800
	v_add_nc_u32_e32 v47, 0xc00, v4                            // 000000A44F4C: 4A5E08FF 00000C00
	v_add_nc_u32_e32 v48, 0x1000, v4                           // 000000A44F54: 4A6008FF 00001000
	v_add_nc_u32_e32 v49, 0x1400, v4                           // 000000A44F5C: 4A6208FF 00001400
	v_add_nc_u32_e32 v50, 0x1800, v4                           // 000000A44F64: 4A6408FF 00001800
	v_add_nc_u32_e32 v51, 0x1c00, v4                           // 000000A44F6C: 4A6608FF 00001C00
	ds_load_2addr_b32 v[7:8], v45 offset1:16                   // 000000A44F74: D8DC1000 0700002D
	ds_load_2addr_b32 v[9:10], v4 offset0:32 offset1:48        // 000000A44F7C: D8DC3020 09000004
	ds_load_2addr_b32 v[11:12], v4 offset0:160 offset1:176     // 000000A44F84: D8DCB0A0 0B000004
	ds_load_2addr_b32 v[13:14], v45 offset0:128 offset1:144    // 000000A44F8C: D8DC9080 0D00002D
	ds_load_2addr_b32 v[15:16], v46 offset1:16                 // 000000A44F94: D8DC1000 0F00002E
	ds_load_2addr_b32 v[17:18], v46 offset0:128 offset1:144    // 000000A44F9C: D8DC9080 1100002E
	ds_load_2addr_b32 v[19:20], v47 offset1:16                 // 000000A44FA4: D8DC1000 1300002F
	ds_load_2addr_b32 v[21:22], v47 offset0:128 offset1:144    // 000000A44FAC: D8DC9080 1500002F
	ds_load_2addr_b32 v[23:24], v48 offset1:16                 // 000000A44FB4: D8DC1000 17000030
	ds_load_2addr_b32 v[25:26], v48 offset0:128 offset1:144    // 000000A44FBC: D8DC9080 19000030
	ds_load_2addr_b32 v[27:28], v49 offset1:16                 // 000000A44FC4: D8DC1000 1B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:128 offset1:144    // 000000A44FCC: D8DC9080 1D000031
	ds_load_2addr_b32 v[31:32], v50 offset1:16                 // 000000A44FD4: D8DC1000 1F000032
	ds_load_2addr_b32 v[33:34], v50 offset0:128 offset1:144    // 000000A44FDC: D8DC9080 21000032
	ds_load_2addr_b32 v[35:36], v51 offset1:16                 // 000000A44FE4: D8DC1000 23000033
	v_add_f32_e32 v2, 0, v2                                    // 000000A44FEC: 06040480
	ds_load_2addr_b32 v[43:44], v46 offset0:32 offset1:48      // 000000A44FF0: D8DC3020 2B00002E
	s_waitcnt lgkmcnt(15)                                      // 000000A44FF8: BF89FCF7
	v_add_f32_e32 v1, v1, v7                                   // 000000A44FFC: 06020F01
	v_dual_add_f32 v7, 0, v6 :: v_dual_add_f32 v2, v2, v8      // 000000A45000: C9080C80 07021102
	s_waitcnt lgkmcnt(12)                                      // 000000A45008: BF89FCC7
	v_add_f32_e32 v13, v5, v13                                 // 000000A4500C: 061A1B05
	ds_load_2addr_b32 v[5:6], v46 offset0:160 offset1:176      // 000000A45010: D8DCB0A0 0500002E
	s_waitcnt lgkmcnt(12)                                      // 000000A45018: BF89FCC7
	v_dual_add_f32 v1, v1, v15 :: v_dual_add_f32 v14, v7, v14  // 000000A4501C: C9081F01 010E1D07
	s_waitcnt lgkmcnt(11)                                      // 000000A45024: BF89FCB7
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v13, v13, v17 // 000000A45028: C9082102 020C230D
	ds_load_2addr_b32 v[15:16], v48 offset0:32 offset1:48      // 000000A45030: D8DC3020 0F000030
	v_add_f32_e32 v14, v14, v18                                // 000000A45038: 061C250E
	s_waitcnt lgkmcnt(11)                                      // 000000A4503C: BF89FCB7
	v_dual_add_f32 v2, v2, v20 :: v_dual_add_f32 v1, v1, v19   // 000000A45040: C9082902 02002701
	ds_load_2addr_b32 v[7:8], v47 offset0:32 offset1:48        // 000000A45048: D8DC3020 0700002F
	ds_load_2addr_b32 v[17:18], v48 offset0:160 offset1:176    // 000000A45050: D8DCB0A0 11000030
	s_waitcnt lgkmcnt(12)                                      // 000000A45058: BF89FCC7
	v_add_f32_e32 v14, v14, v22                                // 000000A4505C: 061C2D0E
	s_waitcnt lgkmcnt(11)                                      // 000000A45060: BF89FCB7
	v_dual_add_f32 v2, v2, v24 :: v_dual_add_f32 v1, v1, v23   // 000000A45064: C9083102 02002F01
	ds_load_2addr_b32 v[19:20], v49 offset0:32 offset1:48      // 000000A4506C: D8DC3020 13000031
	s_waitcnt lgkmcnt(11)                                      // 000000A45074: BF89FCB7
	v_add_f32_e32 v14, v14, v26                                // 000000A45078: 061C350E
	ds_load_2addr_b32 v[37:38], v51 offset0:128 offset1:144    // 000000A4507C: D8DC9080 25000033
	ds_load_2addr_b32 v[39:40], v45 offset0:32 offset1:48      // 000000A45084: D8DC3020 2700002D
	ds_load_2addr_b32 v[41:42], v45 offset0:160 offset1:176    // 000000A4508C: D8DCB0A0 2900002D
	v_add_f32_e32 v13, v13, v21                                // 000000A45094: 061A2B0D
	s_waitcnt lgkmcnt(13)                                      // 000000A45098: BF89FCD7
	v_add_f32_e32 v1, v1, v27                                  // 000000A4509C: 06023701
	v_add_f32_e32 v23, v2, v28                                 // 000000A450A0: 062E3902
	s_waitcnt lgkmcnt(12)                                      // 000000A450A4: BF89FCC7
	v_dual_add_f32 v24, v14, v30 :: v_dual_add_f32 v9, 0, v9   // 000000A450A8: C9083D0E 18081280
	ds_load_2addr_b32 v[21:22], v49 offset0:160 offset1:176    // 000000A450B0: D8DCB0A0 15000031
	v_add_f32_e32 v11, 0, v11                                  // 000000A450B8: 06161680
	s_waitcnt lgkmcnt(11)                                      // 000000A450BC: BF89FCB7
	v_dual_add_f32 v1, v1, v31 :: v_dual_add_f32 v26, v24, v34 // 000000A450C0: C9083F01 011A4518
	s_waitcnt lgkmcnt(3)                                       // 000000A450C8: BF89FC37
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A450CC: BF870001
	v_dual_add_f32 v13, v13, v25 :: v_dual_add_f32 v54, v26, v38// 000000A450D0: C908330D 0D364D1A
	s_waitcnt lgkmcnt(2)                                       // 000000A450D8: BF89FC27
	v_add_f32_e32 v9, v9, v39                                  // 000000A450DC: 06124F09
	v_add_f32_e32 v39, v1, v35                                 // 000000A450E0: 064E4701
	v_lshlrev_b32_e32 v1, 1, v3                                // 000000A450E4: 30020681
	s_waitcnt lgkmcnt(1)                                       // 000000A450E8: BF89FC17
	v_add_f32_e32 v3, v11, v41                                 // 000000A450EC: 0606530B
	v_add_f32_e32 v11, v23, v32                                // 000000A450F0: 06164117
	v_add_f32_e32 v9, v9, v43                                  // 000000A450F4: 06125709
	ds_load_2addr_b32 v[23:24], v50 offset0:32 offset1:48      // 000000A450F8: D8DC3020 17000032
	v_or_b32_e32 v41, 32, v52                                  // 000000A45100: 385268A0
	v_add_f32_e32 v5, v3, v5                                   // 000000A45104: 060A0B03
	v_add_f32_e32 v53, v11, v36                                // 000000A45108: 066A490B
	v_add_f32_e32 v7, v9, v7                                   // 000000A4510C: 060E0F09
	global_load_d16_b16 v3, v41, s[6:7]                        // 000000A45110: DC820000 03060029
	v_add_f32_e32 v7, v7, v15                                  // 000000A45118: 060E1F07
	v_add_f32_e32 v15, 0, v12                                  // 000000A4511C: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:192 offset1:208     // 000000A45120: D8DCD0C0 0B000004
	ds_load_2addr_b32 v[27:28], v51 offset0:32 offset1:48      // 000000A45128: D8DC3020 1B000033
	v_add_f32_e32 v7, v7, v19                                  // 000000A45130: 060E2707
	s_waitcnt lgkmcnt(2)                                       // 000000A45134: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A45138: BF870001
	v_add_f32_e32 v19, v7, v23                                 // 000000A4513C: 06262F07
	v_add_f32_e32 v13, v13, v29                                // 000000A45140: 061A3B0D
	ds_load_2addr_b32 v[29:30], v45 offset0:64 offset1:80      // 000000A45144: D8DC5040 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:192 offset1:208    // 000000A4514C: D8DCD0C0 1F00002D
	v_add_f32_e32 v25, v13, v33                                // 000000A45154: 0632430D
	ds_load_2addr_b32 v[13:14], v47 offset0:160 offset1:176    // 000000A45158: D8DCB0A0 0D00002F
	s_waitcnt lgkmcnt(4)                                       // 000000A45160: BF89FC47
	v_add_f32_e32 v11, 0, v11                                  // 000000A45164: 06161680
	v_add_f32_e32 v43, v25, v37                                // 000000A45168: 06564B19
	ds_load_2addr_b32 v[25:26], v50 offset0:160 offset1:176    // 000000A4516C: D8DCB0A0 19000032
	ds_load_2addr_b32 v[37:38], v48 offset0:192 offset1:208    // 000000A45174: D8DCD0C0 25000030
	s_waitcnt lgkmcnt(3)                                       // 000000A4517C: BF89FC37
	v_add_f32_e32 v11, v11, v31                                // 000000A45180: 06163F0B
	s_waitcnt lgkmcnt(2)                                       // 000000A45184: BF89FC27
	v_add_f32_e32 v5, v5, v13                                  // 000000A45188: 060A1B05
	v_add_f32_e32 v13, 0, v10                                  // 000000A4518C: 061A1480
	ds_load_2addr_b32 v[9:10], v4 offset0:64 offset1:80        // 000000A45190: D8DC5040 09000004
	v_add_f32_e32 v5, v5, v17                                  // 000000A45198: 060A2305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A4519C: BF8701C1
	v_add_f32_e32 v17, v5, v21                                 // 000000A451A0: 06222B05
	v_add_f32_e32 v5, v13, v40                                 // 000000A451A4: 060A510D
	v_add_f32_e32 v13, v15, v42                                // 000000A451A8: 061A550F
	s_waitcnt lgkmcnt(2)                                       // 000000A451AC: BF89FC27
	v_dual_add_f32 v40, v19, v27 :: v_dual_add_f32 v21, v17, v25// 000000A451B0: C9083713 28143311
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A451B8: BF870193
	v_add_f32_e32 v7, v5, v44                                  // 000000A451BC: 060E5905
	v_add_f32_e32 v13, v13, v6                                 // 000000A451C0: 061A0D0D
	ds_load_2addr_b32 v[5:6], v46 offset0:64 offset1:80        // 000000A451C4: D8DC5040 0500002E
	ds_load_2addr_b32 v[33:34], v46 offset0:192 offset1:208    // 000000A451CC: D8DCD0C0 2100002E
	ds_load_2addr_b32 v[35:36], v51 offset0:160 offset1:176    // 000000A451D4: D8DCB0A0 23000033
	v_add_f32_e32 v15, v7, v8                                  // 000000A451DC: 061E1107
	ds_load_2addr_b32 v[7:8], v47 offset0:64 offset1:80        // 000000A451E0: D8DC5040 0700002F
	v_add_f32_e32 v17, v13, v14                                // 000000A451E8: 06221D0D
	ds_load_2addr_b32 v[13:14], v47 offset0:192 offset1:208    // 000000A451EC: D8DCD0C0 0D00002F
	s_waitcnt lgkmcnt(5)                                       // 000000A451F4: BF89FC57
	v_add_f32_e32 v9, 0, v9                                    // 000000A451F8: 06121280
	v_add_f32_e32 v23, v15, v16                                // 000000A451FC: 062E210F
	ds_load_2addr_b32 v[15:16], v48 offset0:64 offset1:80      // 000000A45200: D8DC5040 0F000030
	v_add_f32_e32 v17, v17, v18                                // 000000A45208: 06222511
	v_add_f32_e32 v9, v9, v29                                  // 000000A4520C: 06123B09
	v_add_f32_e32 v23, v23, v20                                // 000000A45210: 062E2917
	ds_load_2addr_b32 v[19:20], v49 offset0:192 offset1:208    // 000000A45214: D8DCD0C0 13000031
	v_add_f32_e32 v22, v17, v22                                // 000000A4521C: 062C2D11
	ds_load_2addr_b32 v[17:18], v49 offset0:64 offset1:80      // 000000A45220: D8DC5040 11000031
	s_waitcnt lgkmcnt(7)                                       // 000000A45228: BF89FC77
	v_add_f32_e32 v5, v9, v5                                   // 000000A4522C: 060A0B09
	s_waitcnt lgkmcnt(5)                                       // 000000A45230: BF89FC57
	v_dual_add_f32 v9, v11, v33 :: v_dual_add_f32 v42, v21, v35// 000000A45234: C908430B 092A4715
	v_add_f32_e32 v27, v23, v24                                // 000000A4523C: 06363117
	v_add_f32_e32 v33, v22, v26                                // 000000A45240: 06423516
	ds_load_2addr_b32 v[21:22], v50 offset0:64 offset1:80      // 000000A45244: D8DC5040 15000032
	ds_load_2addr_b32 v[23:24], v50 offset0:192 offset1:208    // 000000A4524C: D8DCD0C0 17000032
	s_waitcnt lgkmcnt(6)                                       // 000000A45254: BF89FC67
	v_add_f32_e32 v5, v5, v7                                   // 000000A45258: 060A0F05
	s_waitcnt lgkmcnt(5)                                       // 000000A4525C: BF89FC57
	v_add_f32_e32 v7, v9, v13                                  // 000000A45260: 060E1B09
	s_waitcnt lgkmcnt(4)                                       // 000000A45264: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A45268: BF870002
	v_add_f32_e32 v13, v5, v15                                 // 000000A4526C: 061A1F05
	v_add_f32_e32 v5, 0, v10                                   // 000000A45270: 060A1480
	ds_load_2addr_b32 v[9:10], v51 offset0:64 offset1:80       // 000000A45274: D8DC5040 09000033
	ds_load_2addr_b32 v[25:26], v51 offset0:192 offset1:208    // 000000A4527C: D8DCD0C0 19000033
	v_add_f32_e32 v7, v7, v37                                  // 000000A45284: 060E4B07
	v_add_f32_e32 v15, 0, v12                                  // 000000A45288: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:96 offset1:112      // 000000A4528C: D8DC7060 0B000004
	v_add_f32_e32 v31, v5, v30                                 // 000000A45294: 063E3D05
	ds_load_2addr_b32 v[29:30], v4 offset0:224 offset1:240     // 000000A45298: D8DCF0E0 1D000004
	s_waitcnt lgkmcnt(6)                                       // 000000A452A0: BF89FC67
	v_dual_add_f32 v13, v13, v17 :: v_dual_add_f32 v4, v15, v32// 000000A452A4: C908230D 0D04410F
	v_add_f32_e32 v15, v7, v19                                 // 000000A452AC: 061E2707
	v_add_f32_e32 v17, v31, v6                                 // 000000A452B0: 06220D1F
	ds_load_2addr_b32 v[6:7], v45 offset0:96 offset1:112       // 000000A452B4: D8DC7060 0600002D
	ds_load_2addr_b32 v[31:32], v45 offset0:224 offset1:240    // 000000A452BC: D8DCF0E0 1F00002D
	s_waitcnt lgkmcnt(7)                                       // 000000A452C4: BF89FC77
	v_dual_add_f32 v13, v13, v21 :: v_dual_add_f32 v4, v4, v34 // 000000A452C8: C9082B0D 0D044504
	s_waitcnt lgkmcnt(6)                                       // 000000A452D0: BF89FC67
	v_dual_add_f32 v15, v15, v23 :: v_dual_add_f32 v8, v17, v8 // 000000A452D4: C9082F0F 0F081111
	s_clause 0x1                                               // 000000A452DC: BF850001
	global_load_d16_b16 v2, v1, s[6:7]                         // 000000A452E0: DC820000 02060001
	global_load_d16_b16 v5, v1, s[6:7] offset:64               // 000000A452E8: DC820040 05060001
	v_dual_add_f32 v4, v4, v14 :: v_dual_add_f32 v37, v27, v28 // 000000A452F0: C9081D04 0424391B
	s_waitcnt lgkmcnt(5)                                       // 000000A452F8: BF89FC57
	v_add_f32_e32 v23, v13, v9                                 // 000000A452FC: 062E130D
	s_waitcnt lgkmcnt(4)                                       // 000000A45300: BF89FC47
	v_dual_add_f32 v25, v15, v25 :: v_dual_add_f32 v8, v8, v16 // 000000A45304: C908330F 19082108
	ds_load_2addr_b32 v[13:14], v46 offset0:96 offset1:112     // 000000A4530C: D8DC7060 0D00002E
	ds_load_2addr_b32 v[15:16], v46 offset0:224 offset1:240    // 000000A45314: D8DCF0E0 0F00002E
	v_add_f32_e32 v9, v4, v38                                  // 000000A4531C: 06124D04
	s_waitcnt lgkmcnt(5)                                       // 000000A45320: BF89FC57
	v_add_f32_e32 v11, 0, v11                                  // 000000A45324: 06161680
	s_waitcnt lgkmcnt(4)                                       // 000000A45328: BF89FC47
	v_dual_add_f32 v17, 0, v29 :: v_dual_add_f32 v38, v8, v18  // 000000A4532C: C9083A80 11262508
	v_add_f32_e32 v21, v33, v36                                // 000000A45334: 062A4921
	v_add_f32_e32 v44, v9, v20                                 // 000000A45338: 06582909
	s_waitcnt lgkmcnt(2)                                       // 000000A4533C: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A45340: BF870003
	v_dual_add_f32 v8, v11, v6 :: v_dual_add_f32 v11, v17, v31 // 000000A45344: C9080D0B 080A3F11
	ds_load_2addr_b32 v[17:18], v47 offset0:96 offset1:112     // 000000A4534C: D8DC7060 1100002F
	ds_load_2addr_b32 v[19:20], v47 offset0:224 offset1:240    // 000000A45354: D8DCF0E0 1300002F
	ds_load_2addr_b32 v[27:28], v48 offset0:96 offset1:112     // 000000A4535C: D8DC7060 1B000030
	ds_load_2addr_b32 v[33:34], v48 offset0:224 offset1:240    // 000000A45364: D8DCF0E0 21000030
	v_add_f32_e32 v31, 0, v12                                  // 000000A4536C: 063E1880
	v_add_f32_e32 v35, 0, v30                                  // 000000A45370: 06463C80
	s_clause 0x1                                               // 000000A45374: BF850001
	global_load_d16_b16 v6, v41, s[6:7] offset:1280            // 000000A45378: DC820500 06060029
	global_load_d16_b16 v4, v1, s[6:7] offset:1280             // 000000A45380: DC820500 04060001
	v_or_b32_e32 v45, 0x60, v52                                // 000000A45388: 385A68FF 00000060
	v_add_f32_e32 v7, v31, v7                                  // 000000A45390: 060E0F1F
	s_waitcnt lgkmcnt(5)                                       // 000000A45394: BF89FC57
	v_add_f32_e32 v13, v8, v13                                 // 000000A45398: 061A1B08
	global_load_d16_b16 v8, v41, s[8:9]                        // 000000A4539C: DC820000 08080029
	s_waitcnt lgkmcnt(4)                                       // 000000A453A4: BF89FC47
	v_add_f32_e32 v15, v11, v15                                // 000000A453A8: 061E1F0B
	ds_load_2addr_b32 v[11:12], v49 offset0:96 offset1:112     // 000000A453AC: D8DC7060 0B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:224 offset1:240    // 000000A453B4: D8DCF0E0 1D000031
	v_add_f32_e32 v41, v35, v32                                // 000000A453BC: 06524123
	ds_load_2addr_b32 v[31:32], v50 offset0:96 offset1:112     // 000000A453C0: D8DC7060 1F000032
	ds_load_2addr_b32 v[35:36], v50 offset0:224 offset1:240    // 000000A453C8: D8DCF0E0 23000032
	v_add_f32_e32 v7, v7, v14                                  // 000000A453D0: 060E1D07
	global_load_d16_b16 v9, v45, s[6:7]                        // 000000A453D4: DC820000 0906002D
	v_add_f32_e32 v41, v41, v16                                // 000000A453DC: 06522129
	s_waitcnt lgkmcnt(7)                                       // 000000A453E0: BF89FC77
	v_add_f32_e32 v17, v13, v17                                // 000000A453E4: 0622230D
	s_waitcnt lgkmcnt(6)                                       // 000000A453E8: BF89FC67
	v_add_f32_e32 v19, v15, v19                                // 000000A453EC: 0626270F
	ds_load_2addr_b32 v[13:14], v51 offset0:96 offset1:112     // 000000A453F0: D8DC7060 0D000033
	ds_load_2addr_b32 v[15:16], v51 offset0:224 offset1:240    // 000000A453F8: D8DCF0E0 0F000033
	v_dual_add_f32 v7, v7, v18 :: v_dual_add_f32 v18, v41, v20 // 000000A45400: C9082507 07122929
	s_waitcnt lgkmcnt(7)                                       // 000000A45408: BF89FC77
	v_add_f32_e32 v17, v17, v27                                // 000000A4540C: 06223711
	s_waitcnt lgkmcnt(6)                                       // 000000A45410: BF89FC67
	v_dual_add_f32 v19, v19, v33 :: v_dual_add_f32 v20, v38, v22// 000000A45414: C9084313 13142D26
	v_dual_add_f32 v7, v7, v28 :: v_dual_add_f32 v18, v18, v34 // 000000A4541C: C9083907 07124512
	v_add_f32_e32 v22, v44, v24                                // 000000A45424: 062C312C
	v_or_b32_e32 v28, 0xa0, v52                                // 000000A45428: 383868FF 000000A0
	s_waitcnt lgkmcnt(5)                                       // 000000A45430: BF89FC57
	v_add_f32_e32 v11, v17, v11                                // 000000A45434: 06161711
	s_waitcnt lgkmcnt(4)                                       // 000000A45438: BF89FC47
	v_add_f32_e32 v17, v19, v29                                // 000000A4543C: 06223B13
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v12, v18, v30 // 000000A45440: C9081907 070C3D12
	s_waitcnt lgkmcnt(3)                                       // 000000A45448: BF89FC37
	v_dual_add_f32 v10, v20, v10 :: v_dual_add_f32 v11, v11, v31// 000000A4544C: C9081514 0A0A3F0B
	s_waitcnt lgkmcnt(2)                                       // 000000A45454: BF89FC27
	v_dual_add_f32 v17, v17, v35 :: v_dual_add_f32 v18, v22, v26// 000000A45458: C9084711 11123516
	v_add_f32_e32 v12, v12, v36                                // 000000A45460: 0618490C
	v_add_f32_e32 v7, v7, v32                                  // 000000A45464: 060E4107
	s_waitcnt lgkmcnt(1)                                       // 000000A45468: BF89FC17
	v_add_f32_e32 v11, v11, v13                                // 000000A4546C: 06161B0B
	s_waitcnt lgkmcnt(0)                                       // 000000A45470: BF89FC07
	v_add_f32_e32 v13, v17, v15                                // 000000A45474: 061A1F11
	v_dual_add_f32 v19, v23, v10 :: v_dual_add_f32 v12, v12, v16// 000000A45478: C9081517 130C210C
	v_sub_f32_e32 v10, v23, v10                                // 000000A45480: 08141517
	v_dual_add_f32 v22, v43, v54 :: v_dual_add_f32 v23, v42, v21// 000000A45484: C9086D2B 16162B2A
	v_add_f32_e32 v24, v25, v18                                // 000000A4548C: 06302519
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A45490: BF870004
	v_add_f32_e32 v27, v13, v12                                // 000000A45494: 0636190D
	v_add_f32_e32 v7, v7, v14                                  // 000000A45498: 060E1D07
	v_sub_f32_e32 v15, v39, v53                                // 000000A4549C: 081E6B27
	v_add_f32_e32 v16, v40, v37                                // 000000A454A0: 06204B28
	v_dual_sub_f32 v17, v40, v37 :: v_dual_add_f32 v30, v22, v23// 000000A454A4: C9484B28 111E2F16
	v_add_f32_e32 v31, v24, v27                                // 000000A454AC: 063E3718
	v_dual_add_f32 v20, v11, v7 :: v_dual_and_b32 v37, 1, v0   // 000000A454B0: C9240F0B 14240081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A454B8: BF870223
	v_add_f32_e32 v36, v15, v17                                // 000000A454BC: 0648230F
	v_sub_f32_e32 v15, v15, v17                                // 000000A454C0: 081E230F
	v_add_f32_e32 v17, v30, v31                                // 000000A454C4: 06223F1E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A454C8: BF870004
	.long 0xd44a0002                                           // 000000A454CC: D44A0002
	v_cndmask_b32_e32 v1, 0, v37, vcc_lo                       // 000000A454D0: 02024A80
	v_add_f32_e32 v14, v39, v53                                // 000000A454D4: 061C6B27
	v_add_f32_e32 v39, v19, v20                                // 000000A454D8: 064E2913
	v_sub_f32_e32 v19, v19, v20                                // 000000A454DC: 08262913
	v_mov_b32_dpp v20, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A454E0: 7E2802FA FF016111
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000A454E8: D5010011 200A2311
	v_sub_f32_e32 v37, v43, v54                                // 000000A454F0: 084A6D2B
	v_dual_sub_f32 v21, v42, v21 :: v_dual_sub_f32 v18, v25, v18// 000000A454F4: C94A2B2A 15122519
	v_dual_sub_f32 v12, v13, v12 :: v_dual_sub_f32 v11, v11, v7// 000000A454FC: C94A190D 0C0A0F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A45504: BF8701A4
	v_add_f32_e32 v13, v17, v20                                // 000000A45508: 061A2911
	v_and_b32_e32 v17, 2, v0                                   // 000000A4550C: 36220082
	v_dual_add_f32 v25, v37, v21 :: v_dual_add_f32 v40, v18, v12// 000000A45510: C9082B25 19281912
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A45518: BF870224
	v_add_f32_e32 v20, v10, v11                                // 000000A4551C: 0628170A
	v_sub_f32_e32 v10, v10, v11                                // 000000A45520: 0814170A
	.long 0xd44a0003                                           // 000000A45524: D44A0003
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 000000A45528: 02022280
	v_sub_f32_e32 v17, v22, v23                                // 000000A4552C: 08222F16
	v_dual_add_f32 v11, v25, v40 :: v_dual_sub_f32 v22, v24, v27// 000000A45530: C90A5119 0B163718
	v_and_b32_e32 v23, 4, v0                                   // 000000A45538: 362E0084
	v_mov_b32_dpp v41, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A4553C: 7E5202FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000A45544: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A4554C: BF870254
	v_mov_b32_dpp v24, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A45550: 7E3002FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000A45558: D501000B 200A170B
	v_add_f32_e32 v27, v17, v22                                // 000000A45560: 06362D11
	.long 0xd44a0004                                           // 000000A45564: D44A0004
	v_cndmask_b32_e32 v1, 0, v23, vcc_lo                       // 000000A45568: 02022E80
	v_dual_add_f32 v13, v13, v41 :: v_dual_and_b32 v0, 8, v0   // 000000A4556C: C924530D 0D000088
	v_add_f32_e32 v11, v11, v24                                // 000000A45574: 0616310B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A45578: BF870224
	v_mov_b32_dpp v23, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A4557C: 7E2E02FA FF01611B
	v_cndmask_b32_e64 v24, -v27, v27, s2                       // 000000A45584: D5010018 200A371B
	.long 0xd44a0001                                           // 000000A4558C: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000A45590: 02020080
	v_sub_f32_e32 v0, v37, v21                                 // 000000A45594: 08002B25
	v_mov_b32_dpp v27, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A45598: 7E3602FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000A455A0: D501000B 200E170B
	v_dual_add_f32 v23, v24, v23 :: v_dual_sub_f32 v12, v18, v12// 000000A455A8: C90A2F18 170C1912
	v_mov_b32_dpp v41, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A455B0: 7E5202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000A455B8: D501000D 20121B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A455C0: BF870214
	v_add_f32_e32 v11, v11, v27                                // 000000A455C4: 0616370B
	v_mov_b32_dpp v18, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A455C8: 7E2402FA FF016217
	v_cndmask_b32_e64 v21, -v23, v23, s3                       // 000000A455D0: D5010015 200E2F17
	v_sub_f32_e32 v24, v25, v40                                // 000000A455D8: 08305119
	v_add_f32_e32 v13, v13, v41                                // 000000A455DC: 061A530D
	v_mov_b32_dpp v25, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A455E0: 7E3202FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000A455E8: D501000B 2012170B
	v_dual_add_f32 v18, v21, v18 :: v_dual_add_f32 v21, v0, v12// 000000A455F0: C9082515 12141900
	v_sub_f32_e32 v23, v30, v31                                // 000000A455F8: 082E3F1E
	v_sub_f32_e32 v17, v17, v22                                // 000000A455FC: 08222D11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A45600: BF870214
	v_add_f32_e32 v11, v11, v25                                // 000000A45604: 0616330B
	v_mov_b32_dpp v25, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A45608: 7E3202FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 000000A45610: D5010012 20122512
	v_mov_b32_dpp v30, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A45618: 7E3C02FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000A45620: D5010015 200A2B15
	v_mov_b32_dpp v22, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A45628: 7E2C02FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000A45630: D501000D 20061B0D
	v_add_f32_e32 v18, v18, v25                                // 000000A45638: 06243312
	v_add_f32_e32 v29, v14, v16                                // 000000A4563C: 063A210E
	v_dual_add_f32 v21, v21, v30 :: v_dual_sub_f32 v14, v14, v16// 000000A45640: C90A3D15 150E210E
	v_or_b32_e32 v16, 0xe0, v52                                // 000000A45648: 382068FF 000000E0
	v_sub_f32_e32 v0, v0, v12                                  // 000000A45650: 08001900
	v_add_f32_e32 v12, v13, v22                                // 000000A45654: 06182D0D
	v_mov_b32_dpp v13, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A45658: 7E1A02FA FF016812
	v_mov_b32_dpp v22, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A45660: 7E2C02FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000A45668: D5010015 200E2B15
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000A45670: D5010012 20062512
	v_mov_b32_dpp v25, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A45678: 7E3202FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s2                       // 000000A45680: D5010017 200A2F17
	global_load_d16_b16 v38, v16, s[6:7]                       // 000000A45688: DC820000 26060010
	v_add_f32_e32 v21, v21, v22                                // 000000A45690: 062A2D15
	v_add_f32_e32 v13, v18, v13                                // 000000A45694: 061A1B12
	global_load_d16_b16 v22, v28, s[6:7] offset:1280           // 000000A45698: DC820500 1606001C
	v_add_f32_e32 v18, v23, v25                                // 000000A456A0: 06243317
	s_clause 0x7                                               // 000000A456A4: BF850007
	global_load_d16_b16 v25, v16, s[6:7] offset:1280           // 000000A456A8: DC820500 19060010
	global_load_d16_b16 v26, v1, s[6:7] offset:128             // 000000A456B0: DC820080 1A060001
	global_load_d16_b16 v32, v28, s[6:7]                       // 000000A456B8: DC820000 2006001C
	global_load_d16_b16 v33, v1, s[6:7] offset:1344            // 000000A456C0: DC820540 21060001
	global_load_d16_b16 v7, v1, s[6:7] offset:1408             // 000000A456C8: DC820580 07060001
	global_load_d16_b16 v34, v1, s[6:7] offset:1472            // 000000A456D0: DC8205C0 22060001
	global_load_d16_b16 v35, v1, s[6:7] offset:192             // 000000A456D8: DC8200C0 23060001
	global_load_d16_b16 v27, v45, s[6:7] offset:1280           // 000000A456E0: DC820500 1B06002D
	v_mov_b32_dpp v23, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A456E8: 7E2E02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s4                       // 000000A456F0: D5010015 20122B15
	s_clause 0x5                                               // 000000A456F8: BF850005
	global_load_d16_b16 v28, v28, s[8:9]                       // 000000A456FC: DC820000 1C08001C
	global_load_d16_b16 v16, v16, s[8:9]                       // 000000A45704: DC820000 10080010
	global_load_d16_b16 v37, v1, s[8:9]                        // 000000A4570C: DC820000 25080001
	global_load_d16_b16 v40, v1, s[8:9] offset:64              // 000000A45714: DC820040 28080001
	global_load_d16_b16 v41, v1, s[8:9] offset:128             // 000000A4571C: DC820080 29080001
	global_load_d16_b16 v42, v1, s[8:9] offset:192             // 000000A45724: DC8200C0 2A080001
	v_mov_b32_dpp v31, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A4572C: 7E3E02FA FF01680B
	v_add_f32_e32 v21, v21, v23                                // 000000A45734: 062A2F15
	global_load_d16_b16 v23, v45, s[8:9]                       // 000000A45738: DC820000 1708002D
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A45740: D501000B 2006170B
	v_mov_b32_dpp v30, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A45748: 7E3C02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000A45750: D5010012 200E2512
	v_add_f32_e32 v43, v36, v20                                // 000000A45758: 06562924
	v_mov_b32_dpp v47, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A4575C: 7E5E02FA FF016118
	v_add_f32_e32 v11, v11, v31                                // 000000A45764: 06163F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A45768: BF870214
	v_dual_add_f32 v31, v29, v39 :: v_dual_add_f32 v18, v18, v30// 000000A4576C: C9084F1D 1F123D12
	v_mov_b32_dpp v45, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A45774: 7E5A02FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 000000A4577C: D501002B 200A572B
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 000000A45784: D5010018 200A3118
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A4578C: BF870004
	v_mov_b32_dpp v30, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A45790: 7E3C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000A45798: D501001F 200A3F1F
	v_mov_b32_dpp v44, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A457A0: 7E5802FA FF016815
	v_add_f32_e32 v43, v43, v45                                // 000000A457A8: 06565B2B
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000A457AC: D5010015 20062B15
	v_add_f32_e32 v24, v24, v47                                // 000000A457B4: 06305F18
	v_add_f32_e32 v30, v31, v30                                // 000000A457B8: 063C3D1F
	v_mov_b32_dpp v31, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A457BC: 7E3E02FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 000000A457C4: D5010012 20122512
	v_add_f32_e32 v21, v21, v44                                // 000000A457CC: 062A5915
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000A457D0: 101818FF 3DB504F3
	v_mov_b32_dpp v46, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A457D8: 7E5C02FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000A457E0: D501001E 200E3D1E
	v_add_f32_e32 v18, v18, v31                                // 000000A457E8: 06243F12
	v_mov_b32_dpp v31, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A457EC: 7E3E02FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 000000A457F4: D501002B 200E572B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A457FC: BF870234
	v_dual_sub_f32 v29, v29, v39 :: v_dual_add_f32 v30, v30, v46// 000000A45800: C9484F1D 1D1E5D1E
	v_mov_b32_dpp v46, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A45808: 7E5C02FA FF016218
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000A45810: D5010018 200E3118
	v_add_f32_e32 v31, v43, v31                                // 000000A45818: 063E3F2B
	v_mov_b32_dpp v43, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A4581C: 7E5602FA FF016812
	v_mov_b32_dpp v45, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A45824: 7E5A02FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s4                       // 000000A4582C: D501001E 20123D1E
	v_add_f32_e32 v24, v24, v46                                // 000000A45834: 06305D18
	v_mov_b32_dpp v44, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A45838: 7E5802FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 000000A45840: D501001F 20123F1F
	v_mov_b32_dpp v46, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A45848: 7E5C02FA FF016111
	v_add_f32_e32 v30, v30, v45                                // 000000A45850: 063C5B1E
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000A45854: D5010011 200A2311
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000A4585C: D5010012 20062512
	v_add_f32_e32 v31, v31, v44                                // 000000A45864: 063E591F
	v_mov_b32_dpp v44, v24 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A45868: 7E5802FA FF016418
	v_mov_b32_dpp v45, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A45870: 7E5A02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000A45878: D501001E 20063D1E
	v_add_f32_e32 v17, v17, v46                                // 000000A45880: 06225D11
	v_cndmask_b32_e64 v24, -v24, v24, s4                       // 000000A45884: D5010018 20123118
	v_add_f32_e32 v18, v18, v43                                // 000000A4588C: 06245712
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A45890: BF870004
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_add_f32 v30, v30, v45// 000000A45894: C8C816FF 0B1E5B1E 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A458A0: 7E5A02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A458A8: D501001F 20063F1F
	v_mov_b32_dpp v46, v17 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A458B0: 7E5C02FA FF016211
	v_cndmask_b32_e64 v17, -v17, v17, s3                       // 000000A458B8: D5010011 200E2311
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000A458C0: 103C3CFF 3DB504F3
	v_add_f32_e32 v24, v24, v44                                // 000000A458C8: 06305918
	v_dual_sub_f32 v20, v36, v20 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 000000A458CC: C9462924 140C1AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A458D8: BF8701A4
	v_add_f32_e32 v17, v17, v46                                // 000000A458DC: 06225D11
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 000000A458E0: C8C62AFF 151224FF 3DB504F3
	v_mov_b32_dpp v36, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A458EC: 7E4802FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000A458F4: D5010014 200A2914
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A458FC: BF8700A4
	v_mov_b32_dpp v44, v17 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A45900: 7E5802FA FF016411
	v_cndmask_b32_e64 v17, -v17, v17, s4                       // 000000A45908: D5010011 20122311
	v_add_f32_e32 v17, v17, v44                                // 000000A45910: 06225911
	v_mov_b32_dpp v44, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A45914: 7E5802FA FF016100
	v_cndmask_b32_e64 v0, -v0, v0, s2                          // 000000A4591C: D5010000 200A0100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A45924: BF870211
	v_add_f32_e32 v0, v0, v44                                  // 000000A45928: 06005900
	v_mov_b32_dpp v44, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A4592C: 7E5802FA FF016811
	v_cndmask_b32_e64 v17, -v17, v17, s1                       // 000000A45934: D5010011 20062311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A4593C: BF870091
	v_add_f32_e32 v17, v17, v44                                // 000000A45940: 06225911
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 000000A45944: 102222FF 3DB504F3
	s_waitcnt vmcnt(22)                                        // 000000A4594C: BF895BF7
	v_fma_mix_f32 v2, v2, v30, neg(0) op_sel_hi:[1,0,0]        // 000000A45950: CC200002 8A023D02
	v_add_f32_e32 v30, v31, v45                                // 000000A45958: 063C5B1F
	v_mov_b32_dpp v31, v24 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A4595C: 7E3E02FA FF016818
	v_cndmask_b32_e64 v24, -v24, v24, s1                       // 000000A45964: D5010018 20063118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A4596C: BF870214
	v_mul_f32_e32 v43, 0xbfb8aa3b, v2                          // 000000A45970: 105604FF BFB8AA3B
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000A45978: 103C3CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A45980: BF870223
	v_add_f32_e32 v24, v24, v31                                // 000000A45984: 06303F18
	v_add_f32_e32 v31, v14, v19                                // 000000A45988: 063E270E
	v_exp_f32_e32 v43, v43                                     // 000000A4598C: 7E564B2B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A45990: BF870003
	v_fma_mix_f32 v3, v3, v30, neg(0) op_sel_hi:[1,0,0]        // 000000A45994: CC200003 8A023D03
	v_sub_f32_e32 v14, v14, v19                                // 000000A4599C: 081C270E
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 000000A459A0: 103030FF 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A459A8: 7E5A02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000A459B0: D501001F 200A3F1F
	v_mul_f32_e32 v30, 0xbfb8aa3b, v3                          // 000000A459B8: 103C06FF BFB8AA3B
	v_mov_b32_dpp v19, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A459C0: 7E2602FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000A459C8: D501000E 200A1D0E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A459D0: BF870215
	v_add_f32_e32 v43, 1.0, v43                                // 000000A459D4: 065656F2
	v_exp_f32_e32 v30, v30                                     // 000000A459D8: 7E3C4B1E
	v_add_f32_e32 v31, v31, v45                                // 000000A459DC: 063E5B1F
	v_mov_b32_dpp v45, v0 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A459E0: 7E5A02FA FF016200
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 000000A459E8: D5010000 200E0100
	v_div_scale_f32 v46, null, v43, v43, v2                    // 000000A459F0: D6FC7C2E 040A572B
	s_waitcnt vmcnt(19)                                        // 000000A459F8: BF894FF7
	v_fma_mix_f32 v4, v4, v12, neg(0) op_sel_hi:[1,0,0]        // 000000A459FC: CC200004 8A021904
	v_mov_b32_dpp v48, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A45A04: 7E6002FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000A45A0C: D501001F 200E3F1F
	v_add_f32_e32 v0, v0, v45                                  // 000000A45A14: 06005B00
	v_rcp_f32_e32 v47, v46                                     // 000000A45A18: 7E5E552E
	v_add_f32_e32 v30, 1.0, v30                                // 000000A45A1C: 063C3CF2
	v_fma_mix_f32 v6, v6, v11, neg(0) op_sel_hi:[1,0,0]        // 000000A45A20: CC200006 8A021706
	v_add_f32_e32 v31, v31, v48                                // 000000A45A28: 063E611F
	v_mov_b32_dpp v44, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A45A2C: 7E5802FA FF016400
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000A45A34: D5010000 20120100
	v_div_scale_f32 v45, null, v30, v30, v3                    // 000000A45A3C: D6FC7C2D 040E3D1E
	v_add_f32_e32 v14, v14, v19                                // 000000A45A44: 061C270E
	v_mov_b32_dpp v50, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A45A48: 7E6402FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 000000A45A50: D501001F 20123F1F
	v_add_f32_e32 v0, v0, v44                                  // 000000A45A58: 06005900
	v_rcp_f32_e32 v48, v45                                     // 000000A45A5C: 7E60552D
	v_add_f32_e32 v44, v15, v10                                // 000000A45A60: 0658150F
	v_fma_f32 v49, -v46, v47, 1.0                              // 000000A45A64: D6130031 23CA5F2E
	v_add_f32_e32 v31, v31, v50                                // 000000A45A6C: 063E651F
	v_sub_f32_e32 v10, v15, v10                                // 000000A45A70: 0814150F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 000000A45A74: BF8702C4
	v_mov_b32_dpp v51, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A45A78: 7E6602FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000A45A80: D501002C 200A592C
	v_fmac_f32_e32 v47, v49, v47                               // 000000A45A88: 565E5F31
	v_div_scale_f32 v49, vcc_lo, v2, v43, v2                   // 000000A45A8C: D6FC6A31 040A5702
	v_fma_f32 v50, -v45, v48, 1.0                              // 000000A45A94: D6130032 23CA612D
	v_mov_b32_dpp v52, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A45A9C: 7E6802FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A45AA4: D501001F 20063F1F
	v_add_f32_e32 v44, v44, v51                                // 000000A45AAC: 0658672C
	v_mov_b32_dpp v51, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A45AB0: 7E6602FA FF016800
	v_fmac_f32_e32 v48, v50, v48                               // 000000A45AB8: 56606132
	v_div_scale_f32 v50, s5, v3, v30, v3                       // 000000A45ABC: D6FC0532 040E3D03
	v_dual_add_f32 v31, v31, v52 :: v_dual_mul_f32 v52, v49, v47// 000000A45AC4: C906691F 1F345F31
	v_mov_b32_dpp v54, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A45ACC: 7E6C02FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000A45AD4: D501002C 200E592C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A45ADC: BF870214
	v_mul_f32_e32 v53, v50, v48                                // 000000A45AE0: 106A6132
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 000000A45AE4: 103E3EFF 3DB504F3
	v_fma_f32 v55, -v46, v52, v49                              // 000000A45AEC: D6130037 24C6692E
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000A45AF4: D5010000 20060100
	v_add_f32_e32 v44, v44, v54                                // 000000A45AFC: 06586D2C
	v_fma_f32 v56, -v45, v53, v50                              // 000000A45B00: D6130038 24CA6B2D
	v_fma_mix_f32 v5, v5, v31, neg(0) op_sel_hi:[1,0,0]        // 000000A45B08: CC200005 8A023F05
	v_fmac_f32_e32 v52, v55, v47                               // 000000A45B10: 56685F37
	v_add_f32_e32 v0, v0, v51                                  // 000000A45B14: 06006700
	v_mov_b32_dpp v31, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A45B18: 7E3E02FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s4                       // 000000A45B20: D501002C 2012592C
	v_fmac_f32_e32 v53, v56, v48                               // 000000A45B28: 566A6138
	v_fma_f32 v46, -v46, v52, v49                              // 000000A45B2C: D613002E 24C6692E
	v_mul_f32_e32 v51, 0xbfb8aa3b, v5                          // 000000A45B34: 10660AFF BFB8AA3B
	v_mov_b32_dpp v19, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A45B3C: 7E2602FA FF01610A
	v_add_f32_e32 v31, v44, v31                                // 000000A45B44: 063E3F2C
	v_fma_f32 v45, -v45, v53, v50                              // 000000A45B48: D613002D 24CA6B2D
	v_div_fmas_f32 v44, v46, v47, v52                          // 000000A45B50: D637002C 04D25F2E
	s_mov_b32 vcc_lo, s5                                       // 000000A45B58: BEEA0005
	v_exp_f32_e32 v49, v51                                     // 000000A45B5C: 7E624B33
	v_mov_b32_dpp v46, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A45B60: 7E5C02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A45B68: D501001F 20063F1F
	v_div_fmas_f32 v45, v45, v48, v53                          // 000000A45B70: D637002D 04D6612D
	v_div_fixup_f32 v2, v44, v43, v2                           // 000000A45B78: D6270002 040A572C
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A45B80: D501000A 200A150A
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000A45B88: 100000FF 3DB504F3
	v_add_f32_e32 v12, v31, v46                                // 000000A45B90: 06185D1F
	v_mov_b32_dpp v31, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A45B94: 7E3E02FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000A45B9C: D501001D 200A3B1D
	v_div_fixup_f32 v3, v45, v30, v3                           // 000000A45BA4: D6270003 040E3D2D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A45BAC: BF870224
	v_dual_mul_f32 v2, v4, v2 :: v_dual_mul_f32 v11, 0x3db504f3, v12// 000000A45BB0: C8C60504 020A18FF 3DB504F3
	v_add_f32_e32 v10, v10, v19                                // 000000A45BBC: 0614270A
	v_add_f32_e32 v4, v29, v31                                 // 000000A45BC0: 06083F1D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A45BC4: BF870004
	v_mul_f32_e32 v3, v6, v3                                   // 000000A45BC8: 10060706
	v_add_f32_e32 v47, 1.0, v49                                // 000000A45BCC: 065E62F2
	s_waitcnt vmcnt(17)                                        // 000000A45BD0: BF8947F7
	v_fma_mix_f32 v6, v9, v11, neg(0) op_sel_hi:[1,0,0]        // 000000A45BD4: CC200006 8A021709
	v_add_f32_e32 v9, v20, v36                                 // 000000A45BDC: 06124914
	v_mov_b32_dpp v20, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A45BE0: 7E2802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000A45BE8: D5010004 200E0904
	v_fma_mix_f32 v3, v8, v3, neg(0) op_sel_hi:[1,0,0]         // 000000A45BF0: CC200003 8A020708
	v_mul_f32_e32 v8, 0xbfb8aa3b, v6                           // 000000A45BF8: 10100CFF BFB8AA3B
	v_mov_b32_dpp v29, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A45C00: 7E3A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A45C08: D5010009 200E1309
	v_add_f32_e32 v4, v4, v20                                  // 000000A45C10: 06082904
	v_div_scale_f32 v30, null, v47, v47, v5                    // 000000A45C14: D6FC7C1E 04165F2F
	v_exp_f32_e32 v8, v8                                       // 000000A45C1C: 7E104B08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A45C20: BF870193
	v_add_f32_e32 v9, v9, v29                                  // 000000A45C24: 06123B09
	v_mov_b32_dpp v15, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A45C28: 7E1E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000A45C30: D5010004 20120904
	v_mov_b32_dpp v29, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A45C38: 7E3A02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 000000A45C40: D501000E 200E1D0E
	v_mov_b32_dpp v20, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A45C48: 7E2802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000A45C50: D5010009 20121309
	v_add_f32_e32 v4, v4, v15                                  // 000000A45C58: 06081F04
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A45C5C: 7E1E02FA FF01620A
	v_add_f32_e32 v14, v14, v29                                // 000000A45C64: 061C3B0E
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000A45C68: D501000A 200E150A
	v_add_f32_e32 v9, v9, v20                                  // 000000A45C70: 06122909
	v_mov_b32_dpp v19, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A45C74: 7E2602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A45C7C: D5010004 20060904
	v_mov_b32_dpp v20, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A45C84: 7E2802FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000A45C8C: D501000E 20121D0E
	v_add_f32_e32 v10, v10, v15                                // 000000A45C94: 06141F0A
	v_rcp_f32_e32 v12, v30                                     // 000000A45C98: 7E18551E
	v_mov_b32_dpp v15, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A45C9C: 7E1E02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A45CA4: D5010009 20061309
	v_add_f32_e32 v4, v4, v19                                  // 000000A45CAC: 06082704
	v_add_f32_e32 v14, v14, v20                                // 000000A45CB0: 061C290E
	v_mov_b32_dpp v19, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A45CB4: 7E2602FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 000000A45CBC: D501000A 2012150A
	v_dual_add_f32 v8, 1.0, v8 :: v_dual_add_f32 v9, v9, v15   // 000000A45CC4: C90810F2 08081F09
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A45CCC: BF870224
	v_mov_b32_dpp v15, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A45CD0: 7E1E02FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000A45CD8: D501000E 20061D0E
	v_add_f32_e32 v10, v10, v19                                // 000000A45CE0: 0614270A
	v_fma_f32 v11, -v30, v12, 1.0                              // 000000A45CE4: D613000B 23CA191E
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000A45CEC: 100808FF 3DB504F3
	v_div_scale_f32 v19, null, v8, v8, v6                      // 000000A45CF4: D6FC7C13 041A1108
	v_add_f32_e32 v14, v14, v15                                // 000000A45CFC: 061C1F0E
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A45D00: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A45D08: D501000A 2006150A
	v_fmac_f32_e32 v12, v11, v12                               // 000000A45D10: 5618190B
	v_div_scale_f32 v11, vcc_lo, v5, v47, v5                   // 000000A45D14: D6FC6A0B 04165F05
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000A45D1C: 101212FF 3DB504F3
	v_rcp_f32_e32 v20, v19                                     // 000000A45D24: 7E285513
	v_add_f32_e32 v10, v10, v15                                // 000000A45D28: 06141F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A45D2C: BF8701B3
	v_dual_mul_f32 v14, 0x3db504f3, v14 :: v_dual_mul_f32 v15, v11, v12// 000000A45D30: C8C61CFF 0E0E190B 3DB504F3
	s_waitcnt vmcnt(12)                                        // 000000A45D3C: BF8933F7
	v_fma_mix_f32 v9, v32, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A45D40: CC200009 8A021320
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000A45D48: 101414FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A45D50: BF870003
	v_fma_f32 v31, -v30, v15, v11                              // 000000A45D54: D613001F 242E1F1E
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000A45D5C: CC200004 8A02091A
	s_waitcnt vmcnt(8)                                         // 000000A45D64: BF8923F7
	v_fma_mix_f32 v14, v35, v14, neg(0) op_sel_hi:[1,0,0]      // 000000A45D68: CC20000E 8A021D23
	v_mul_f32_e32 v29, 0xbfb8aa3b, v9                          // 000000A45D70: 103A12FF BFB8AA3B
	v_fma_f32 v32, -v19, v20, 1.0                              // 000000A45D78: D6130020 23CA2913
	v_fma_mix_f32 v10, v38, v10, neg(0) op_sel_hi:[1,0,0]      // 000000A45D80: CC20000A 8A021526
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A45D88: BF870214
	v_dual_mul_f32 v26, 0xbfb8aa3b, v4 :: v_dual_mul_f32 v35, 0xbfb8aa3b, v14// 000000A45D8C: C8C608FF 1A221CFF BFB8AA3B
	v_exp_f32_e32 v29, v29                                     // 000000A45D98: 7E3A4B1D
	v_fmac_f32_e32 v15, v31, v12                               // 000000A45D9C: 561E191F
	v_fmac_f32_e32 v20, v32, v20                               // 000000A45DA0: 56282920
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A45DA4: BF870003
	v_exp_f32_e32 v26, v26                                     // 000000A45DA8: 7E344B1A
	v_mul_f32_e32 v32, 0xbfb8aa3b, v10                         // 000000A45DAC: 104014FF BFB8AA3B
	v_exp_f32_e32 v31, v35                                     // 000000A45DB4: 7E3E4B23
	v_fma_f32 v11, -v30, v15, v11                              // 000000A45DB8: D613000B 242E1F1E
	v_div_scale_f32 v35, s5, v6, v8, v6                        // 000000A45DC0: D6FC0523 041A1106
	v_fma_mix_f32 v13, v33, v13, neg(0) op_sel_hi:[1,0,0]      // 000000A45DC8: CC20000D 8A021B21
	v_exp_f32_e32 v30, v32                                     // 000000A45DD0: 7E3C4B20
	v_add_f32_e32 v29, 1.0, v29                                // 000000A45DD4: 063A3AF2
	v_div_fmas_f32 v11, v11, v12, v15                          // 000000A45DD8: D637000B 043E190B
	v_mul_f32_e32 v32, v35, v20                                // 000000A45DE0: 10402923
	v_add_f32_e32 v26, 1.0, v26                                // 000000A45DE4: 063434F2
	s_mov_b32 vcc_lo, s5                                       // 000000A45DE8: BEEA0005
	v_add_f32_e32 v31, 1.0, v31                                // 000000A45DEC: 063E3EF2
	v_div_scale_f32 v39, null, v29, v29, v9                    // 000000A45DF0: D6FC7C27 04263B1D
	v_fma_f32 v15, -v19, v32, v35                              // 000000A45DF8: D613000F 248E4113
	v_div_scale_f32 v36, null, v26, v26, v4                    // 000000A45E00: D6FC7C24 0412351A
	v_add_f32_e32 v30, 1.0, v30                                // 000000A45E08: 063C3CF2
	v_div_scale_f32 v12, null, v31, v31, v14                   // 000000A45E0C: D6FC7C0C 043A3F1F
	v_rcp_f32_e32 v43, v39                                     // 000000A45E14: 7E565527
	v_fmac_f32_e32 v32, v15, v20                               // 000000A45E18: 5640290F
	v_rcp_f32_e32 v38, v36                                     // 000000A45E1C: 7E4C5524
	v_div_scale_f32 v33, null, v30, v30, v10                   // 000000A45E20: D6FC7C21 042A3D1E
	v_rcp_f32_e32 v45, v12                                     // 000000A45E28: 7E5A550C
	v_div_fixup_f32 v5, v11, v47, v5                           // 000000A45E2C: D6270005 04165F0B
	v_div_scale_f32 v11, s6, v4, v26, v4                       // 000000A45E34: D6FC060B 04123504
	v_fma_f32 v19, -v19, v32, v35                              // 000000A45E3C: D6130013 248E4113
	v_rcp_f32_e32 v15, v33                                     // 000000A45E44: 7E1E5521
	s_waitcnt vmcnt(7)                                         // 000000A45E48: BF891FF7
	v_fma_mix_f32 v21, v27, v21, neg(0) op_sel_hi:[1,0,0]      // 000000A45E4C: CC200015 8A022B1B
	v_mul_f32_e32 v5, v13, v5                                  // 000000A45E54: 100A0B0D
	v_fma_mix_f32 v0, v25, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A45E58: CC200000 8A020119
	v_fma_f32 v44, -v36, v38, 1.0                              // 000000A45E60: D613002C 23CA4D24
	v_div_fmas_f32 v19, v19, v20, v32                          // 000000A45E68: D6370013 04822913
	v_fma_f32 v13, -v12, v45, 1.0                              // 000000A45E70: D613000D 23CA5B0C
	s_mov_b32 vcc_lo, s6                                       // 000000A45E78: BEEA0006
	v_fma_mix_f32 v7, v7, v18, neg(0) op_sel_hi:[1,0,0]        // 000000A45E7C: CC200007 8A022507
	v_fmac_f32_e32 v38, v44, v38                               // 000000A45E84: 564C4D2C
	v_fma_f32 v44, -v39, v43, 1.0                              // 000000A45E88: D613002C 23CA5727
	v_fma_f32 v46, -v33, v15, 1.0                              // 000000A45E90: D613002E 23CA1F21
	v_fmac_f32_e32 v45, v13, v45                               // 000000A45E98: 565A5B0D
	v_div_scale_f32 v13, s8, v14, v31, v14                     // 000000A45E9C: D6FC080D 043A3F0E
	v_mul_f32_e32 v35, v11, v38                                // 000000A45EA4: 10464D0B
	v_fmac_f32_e32 v43, v44, v43                               // 000000A45EA8: 5656572C
	v_div_scale_f32 v44, s7, v9, v29, v9                       // 000000A45EAC: D6FC072C 04263B09
	v_fmac_f32_e32 v15, v46, v15                               // 000000A45EB4: 561E1F2E
	v_div_scale_f32 v46, s5, v10, v30, v10                     // 000000A45EB8: D6FC052E 042A3D0A
	v_fma_f32 v20, -v36, v35, v11                              // 000000A45EC0: D6130014 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A45EC8: BF8701A4
	v_dual_mul_f32 v47, v13, v45 :: v_dual_mul_f32 v32, v44, v43// 000000A45ECC: C8C65B0D 2F20572C
	v_div_fixup_f32 v6, v19, v8, v6                            // 000000A45ED4: D6270006 041A1113
	v_dual_fmac_f32 v35, v20, v38 :: v_dual_mul_f32 v20, v46, v15// 000000A45EDC: C8064D14 23141F2E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A45EE4: BF870213
	v_fma_f32 v8, -v39, v32, v44                               // 000000A45EE8: D6130008 24B24127
	v_fma_f32 v19, -v12, v47, v13                              // 000000A45EF0: D6130013 24365F0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A45EF8: BF870214
	v_mul_f32_e32 v6, v21, v6                                  // 000000A45EFC: 100C0D15
	v_fma_f32 v11, -v36, v35, v11                              // 000000A45F00: D613000B 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A45F08: BF870234
	v_fmac_f32_e32 v32, v8, v43                                // 000000A45F0C: 56405708
	v_fma_f32 v8, -v33, v20, v46                               // 000000A45F10: D6130008 24BA2921
	v_fmac_f32_e32 v47, v19, v45                               // 000000A45F18: 565E5B13
	v_div_fmas_f32 v11, v11, v38, v35                          // 000000A45F1C: D637000B 048E4D0B
	s_mov_b32 vcc_lo, s7                                       // 000000A45F24: BEEA0007
	v_fma_f32 v19, -v39, v32, v44                              // 000000A45F28: D6130013 24B24127
	v_fmac_f32_e32 v20, v8, v15                                // 000000A45F30: 56281F08
	v_fma_f32 v8, -v12, v47, v13                               // 000000A45F34: D6130008 24365F0C
	v_div_fixup_f32 v4, v11, v26, v4                           // 000000A45F3C: D6270004 0412350B
	v_fma_mix_f32 v11, v34, v17, neg(0) op_sel_hi:[1,0,0]      // 000000A45F44: CC20000B 8A022322
	v_div_fmas_f32 v12, v19, v43, v32                          // 000000A45F4C: D637000C 04825713
	v_fma_f32 v13, -v33, v20, v46                              // 000000A45F54: D613000D 24BA2921
	s_mov_b32 vcc_lo, s8                                       // 000000A45F5C: BEEA0008
	s_waitcnt vmcnt(0)                                         // 000000A45F60: BF8903F7
	v_fma_mix_f32 v6, v23, v6, neg(0) op_sel_hi:[1,0,0]        // 000000A45F64: CC200006 8A020D17
	v_div_fmas_f32 v8, v8, v45, v47                            // 000000A45F6C: D6370008 04BE5B08
	s_mov_b32 vcc_lo, s5                                       // 000000A45F74: BEEA0005
	v_div_fixup_f32 v9, v12, v29, v9                           // 000000A45F78: D6270009 04263B0C
	v_div_fmas_f32 v13, v13, v15, v20                          // 000000A45F80: D637000D 04521F0D
	v_fma_mix_f32 v12, v22, v24, neg(0) op_sel_hi:[1,0,0]      // 000000A45F88: CC20000C 8A023116
	v_div_fixup_f32 v8, v8, v31, v14                           // 000000A45F90: D6270008 043A3F08
	v_mul_f32_e32 v4, v7, v4                                   // 000000A45F98: 10080907
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A45F9C: BF870194
	v_div_fixup_f32 v10, v13, v30, v10                         // 000000A45FA0: D627000A 042A3D0D
	v_dual_mul_f32 v9, v12, v9 :: v_dual_mul_f32 v8, v11, v8   // 000000A45FA8: C8C6130C 0908110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A45FB0: BF870112
	v_mul_f32_e32 v0, v0, v10                                  // 000000A45FB4: 10001500
	v_fma_mix_f32 v7, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A45FB8: CC200007 8A02131C
	v_fma_mix_f32 v9, v2, v37, v3 op_sel_hi:[0,1,0]            // 000000A45FC0: CC200009 140E4B02
	v_fma_mix_f32 v10, v5, v40, v6 op_sel_hi:[0,1,0]           // 000000A45FC8: CC20000A 141A5105
	v_fma_mix_f32 v2, v2, v37, -v3 op_sel_hi:[0,1,0]           // 000000A45FD0: CC200002 940E4B02
	v_fma_mix_f32 v0, v16, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A45FD8: CC200000 8A020110
	v_fma_mix_f32 v11, v4, v41, v7 op_sel_hi:[0,1,0]           // 000000A45FE0: CC20000B 141E5304
	v_fma_mix_f32 v3, v5, v40, -v6 op_sel_hi:[0,1,0]           // 000000A45FE8: CC200003 941A5105
	v_fma_mix_f32 v4, v4, v41, -v7 op_sel_hi:[0,1,0]           // 000000A45FF0: CC200004 941E5304
	v_add_f32_e32 v5, v9, v10                                  // 000000A45FF8: 060A1509
	v_fma_mix_f32 v12, v8, v42, v0 op_sel_hi:[0,1,0]           // 000000A45FFC: CC20000C 14025508
	v_fma_mix_f32 v0, v8, v42, -v0 op_sel_hi:[0,1,0]           // 000000A46004: CC200000 94025508
	v_dual_sub_f32 v7, v9, v10 :: v_dual_add_f32 v8, v2, v3    // 000000A4600C: C9481509 07080702
	v_sub_f32_e32 v2, v2, v3                                   // 000000A46014: 08040702
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A46018: BF8701B4
	v_add_f32_e32 v6, v11, v12                                 // 000000A4601C: 060C190B
	v_sub_f32_e32 v9, v11, v12                                 // 000000A46020: 0812190B
	v_add_f32_e32 v10, v4, v0                                  // 000000A46024: 06140104
	v_dual_sub_f32 v0, v4, v0 :: v_dual_add_f32 v3, v5, v6     // 000000A46028: C9480104 00020D05
	v_sub_f32_e32 v4, v5, v6                                   // 000000A46030: 08080D05
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A46034: BF870003
	v_add_f32_e32 v6, v8, v10                                  // 000000A46038: 060C1508
	v_sub_f32_e32 v8, v8, v10                                  // 000000A4603C: 08101508
	v_add_f32_e32 v10, v7, v9                                  // 000000A46040: 06141307
	v_mov_b32_dpp v5, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A46044: 7E0A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000A4604C: D5010003 200A0703
	v_sub_f32_e32 v7, v7, v9                                   // 000000A46054: 080E1307
	v_mov_b32_dpp v14, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A46058: 7E1C02FA FF016104
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A46060: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A46068: D501000A 200A150A
	v_add_f32_e32 v3, v3, v5                                   // 000000A46070: 06060B03
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A46074: 7E0A02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000A4607C: D5010006 200A0D06
	v_cndmask_b32_e64 v15, -v4, v4, s2                         // 000000A46084: D501000F 200A0904
	v_add_f32_e32 v9, v10, v9                                  // 000000A4608C: 0612130A
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A46090: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000A46098: D5010003 200E0703
	v_add_f32_e32 v5, v6, v5                                   // 000000A460A0: 060A0B06
	v_add_f32_e32 v6, v2, v0                                   // 000000A460A4: 060C0102
	v_sub_f32_e32 v10, v2, v0                                  // 000000A460A8: 08140102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A460AC: BF870214
	v_add_f32_e32 v0, v3, v11                                  // 000000A460B0: 06001703
	v_mov_b32_dpp v2, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A460B4: 7E0402FA FF016205
	v_cndmask_b32_e64 v3, -v5, v5, s3                          // 000000A460BC: D5010003 200E0B05
	v_mov_b32_dpp v5, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A460C4: 7E0A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A460CC: D5010009 200E1309
	v_mov_b32_dpp v11, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A460D4: 7E1602FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000A460DC: D5010006 200A0D06
	v_add_f32_e32 v2, v3, v2                                   // 000000A460E4: 06040503
	v_mov_b32_dpp v16, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A460E8: 7E2002FA FF01610A
	v_add_f32_e32 v5, v9, v5                                   // 000000A460F0: 060A0B09
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A460F4: D501000A 200A150A
	v_add_f32_e32 v6, v6, v11                                  // 000000A460FC: 060C1706
	v_mov_b32_dpp v9, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A46100: 7E1202FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000A46108: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A46110: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000A46118: D5010005 20120B05
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A46120: 7E1802FA FF016206
	v_cndmask_b32_e64 v13, -v6, v6, s3                         // 000000A46128: D501000D 200E0D06
	v_add_f32_e32 v4, v2, v9                                   // 000000A46130: 06081302
	v_add_f32_e32 v10, v10, v16                                // 000000A46134: 0614210A
	v_dual_add_f32 v6, v5, v11 :: v_dual_add_f32 v11, v15, v14 // 000000A46138: C9081705 060A1D0F
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A46140: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000A46148: D5010008 200A1108
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A46150: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000A46158: D5010007 200A0F07
	v_add_f32_e32 v9, v13, v12                                 // 000000A46160: 0612190D
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A46164: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000A4616C: D501000B 200E170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A46174: BF870234
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v7, v15   // 000000A46178: C9081D08 08061F07
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A46180: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000A46188: D501000A 200E150A
	v_add_f32_e32 v11, v11, v13                                // 000000A46190: 06161B0B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A46194: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A46198: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000A461A0: D5010008 200E1108
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A461A8: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000A461B0: D5010007 200E0F07
	v_add_f32_e32 v10, v10, v15                                // 000000A461B8: 06141F0A
	v_mov_b32_dpp v3, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A461BC: 7E0602FA FF016400
	v_add_f32_e32 v8, v8, v13                                  // 000000A461C4: 06101B08
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000A461C8: D5010000 20120100
	v_add_f32_e32 v7, v7, v14                                  // 000000A461D0: 060E1D07
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A461D4: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000A461DC: D5010009 20121309
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A461E4: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000A461EC: D501000B 2012170B
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A461F4: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000A461FC: D5010008 20121108
	v_mov_b32_dpp v15, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A46204: 7E1E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000A4620C: D5010007 20120F07
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A46214: 7E2002FA FF01640A
	v_cndmask_b32_e64 v17, -v10, v10, s4                       // 000000A4621C: D5010011 2012150A
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v9, v9, v12    // 000000A46224: C9080700 00081909
	v_dual_add_f32 v10, v11, v13 :: v_dual_add_f32 v11, v8, v14// 000000A4622C: C9081B0B 0A0A1D08
	v_add_f32_e32 v13, v7, v15                                 // 000000A46234: 061A1F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A46238: BF870214
	v_add_f32_e32 v15, v17, v16                                // 000000A4623C: 061E2111
	v_mov_b32_dpp v2, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A46240: 7E0402FA FF016800
	v_mov_b32_dpp v3, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A46248: 7E0602FA FF016804
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A46250: 7E0A02FA FF016806
	v_mov_b32_dpp v7, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A46258: 7E0E02FA FF016809
	v_mov_b32_dpp v8, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A46260: 7E1002FA FF01680A
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A46268: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A46270: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A46278: 7E2002FA FF01680F
	s_mov_b32 s2, 0x3db504f3                                   // 000000A46280: BE8200FF 3DB504F3
	s_and_b32 exec_lo, exec_lo, s0                             // 000000A46288: 8B7E007E
	s_cbranch_execz 65                                         // 000000A4628C: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x6494>
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000A46290: D501000F 20061F0F
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000A46298: D5010000 20060100
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A462A0: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A462A8: D5010006 20060D06
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A462B0: D5010009 20061309
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000A462B8: D501000D 20061B0D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A462C0: D501000A 2006150A
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A462C8: D501000B 2006170B
	v_dual_add_f32 v15, v15, v16 :: v_dual_add_f32 v0, v0, v2  // 000000A462D0: C908210F 0F000500
	v_add_f32_e32 v3, v4, v3                                   // 000000A462D8: 06060704
	v_add_f32_e32 v5, v6, v5                                   // 000000A462DC: 060A0B06
	v_add_f32_e32 v7, v9, v7                                   // 000000A462E0: 060E0F09
	s_mul_i32 s0, s10, 0x500                                   // 000000A462E4: 9600FF0A 00000500
	v_dual_add_f32 v13, v13, v14 :: v_dual_add_f32 v8, v10, v8 // 000000A462EC: C9081D0D 0D08110A
	s_mul_hi_i32 s1, s10, 0x500                                // 000000A462F4: 9701FF0A 00000500
	v_add_f32_e32 v11, v11, v12                                // 000000A462FC: 0616190B
	s_add_u32 s0, s22, s0                                      // 000000A46300: 80000016
	v_fma_mixlo_f16 v0, v0, s2, 0                              // 000000A46304: CC210000 02000500
	s_addc_u32 s1, s23, s1                                     // 000000A4630C: 82010117
	v_fma_mixhi_f16 v0, v3, s2, 0                              // 000000A46310: CC220000 02000503
	s_add_u32 s0, s0, s12                                      // 000000A46318: 80000C00
	v_fma_mixlo_f16 v2, v5, s2, 0                              // 000000A4631C: CC210002 02000505
	s_addc_u32 s1, s1, s13                                     // 000000A46324: 82010D01
	v_fma_mixhi_f16 v2, v7, s2, 0                              // 000000A46328: CC220002 02000507
	v_fma_mixlo_f16 v3, v8, s2, 0                              // 000000A46330: CC210003 02000508
	v_fma_mixhi_f16 v3, v11, s2, 0                             // 000000A46338: CC220003 0200050B
	v_fma_mixlo_f16 v4, v13, s2, 0                             // 000000A46340: CC210004 0200050D
	v_fma_mixhi_f16 v4, v15, s2, 0                             // 000000A46348: CC220004 0200050F
	s_clause 0x7                                               // 000000A46350: BF850007
	global_store_b16 v1, v0, s[0:1]                            // 000000A46354: DC660000 00000001
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 000000A4635C: DC960020 00000001
	global_store_b16 v1, v2, s[0:1] offset:64                  // 000000A46364: DC660040 00000201
	global_store_d16_hi_b16 v1, v2, s[0:1] offset:96           // 000000A4636C: DC960060 00000201
	global_store_b16 v1, v3, s[0:1] offset:128                 // 000000A46374: DC660080 00000301
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:160          // 000000A4637C: DC9600A0 00000301
	global_store_b16 v1, v4, s[0:1] offset:192                 // 000000A46384: DC6600C0 00000401
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:224          // 000000A4638C: DC9600E0 00000401
	s_nop 0                                                    // 000000A46394: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000A46398: BFB60003
	s_endpgm                                                   // 000000A4639C: BFB00000
	s_branch 61779                                             // 000000A463A0: BFA0F153 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x29f0>
		...

