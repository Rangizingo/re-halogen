00000000008e8a00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008E8A00: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v1, 15, v0          // 0000008E8A08: CA240080 0400008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008E8A10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000008E8A14: 86039F02
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008E8A18: BF870002
	v_dual_mov_b32 v16, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 0000008E8A1C: CA220080 10000282
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000008E8A24: 84828302
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000008E8A28: BF870482
	v_dual_mov_b32 v9, s3 :: v_dual_and_b32 v2, 60, v2         // 0000008E8A2C: CA240003 090204BC
	.long 0x7f183880                                           // 0000008E8A34: 7F183880
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v15, 31, v0         // 0000008E8A38: CA240080 060E009F
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v5, 0              // 0000008E8A40: CA100080 1C040080
	s_waitcnt lgkmcnt(0)                                       // 0000008E8A48: BF89FC07
	s_clause 0x1                                               // 0000008E8A4C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 0000008E8A50: DC520000 03040001
	global_load_b32 v7, v2, s[4:5]                             // 0000008E8A58: DC520000 07040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000008E8A60: 32020085
	s_add_u32 s14, s4, s14                                     // 0000008E8A64: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000008E8A68: 820F0F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000008E8A6C: BF8704A1
	v_or_b32_e32 v8, s2, v1                                    // 0000008E8A70: 38100202
	s_lshr_b32 s2, s11, 31                                     // 0000008E8A74: 85029F0B
	s_add_u32 s20, s10, s2                                     // 0000008E8A78: 8014020A
	s_addc_u32 s21, s11, 0                                     // 0000008E8A7C: 8215800B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008E8A80: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 0000008E8A84: 7CA8100C
	s_ashr_i32 s22, s11, 31                                    // 0000008E8A88: 86169F0B
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 0000008E8A8C: 02141080
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 0000008E8A90: D501000E 01A80680
	s_ashr_i64 s[2:3], s[20:21], 1                             // 0000008E8A98: 86828114
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000008E8A9C: BF870481
	.long 0xd72c0013                                           // 0000008E8AA0: D72C0013
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 0000008E8AA4: 0200050E
	s_waitcnt vmcnt(1)                                         // 0000008E8AA8: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 0000008E8AAC: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 0000008E8AB4: BF8903F7
	v_bfe_u32 v18, v7, 16, 1                                   // 0000008E8AB8: D6100012 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008E8AC0: BF870112
	v_add3_u32 v3, v3, v11, 0x7fff                             // 0000008E8AC4: D6550003 03FE1703 00007FFF
	v_add3_u32 v7, v7, v18, 0x7fff                             // 0000008E8AD0: D6550007 03FE2507 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008E8ADC: BF8701B2
	.long 0x7e183983                                           // 0000008E8AE0: 7E183983
	.long 0xd72c0003                                           // 0000008E8AE4: D72C0003
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000008E8AE8: 02021C12
	v_lshlrev_b32_e32 v14, 2, v0                               // 0000008E8AEC: 301C0082
	v_and_or_b32 v12, 0xffff0000, v7, v12                      // 0000008E8AF0: D657000C 04320EFF FFFF0000
	v_mov_b32_e32 v7, 0                                        // 0000008E8AFC: 7E0E0280
	.long 0xd72c000d                                           // 0000008E8B00: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 0000008E8B04: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 0000008E8B08: D6FE7C01 02021412
	.long 0xd72c0011                                           // 0000008E8B10: D72C0011
	v_cndmask_b32_e32 v0, v10, v3, vcc_lo                      // 0000008E8B14: 0200070A
	v_mad_u64_u32 v[10:11], null, v10, s2, s[14:15]            // 0000008E8B18: D6FE7C0A 0038050A
	s_lshr_b32 s19, s22, 27                                    // 0000008E8B20: 85139B16
	ds_store_b32 v14, v12                                      // 0000008E8B24: D8340000 00000C0E
	s_add_u32 s14, s10, s19                                    // 0000008E8B2C: 800E130A
	s_addc_u32 s15, s11, 0                                     // 0000008E8B30: 820F800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008E8B34: BF870009
	s_lshr_b64 s[14:15], s[14:15], 5                           // 0000008E8B38: 858E850E
	v_add3_u32 v0, v2, v3, v13                                 // 0000008E8B3C: D6550000 04360702
	.long 0xd4440002                                           // 0000008E8B44: D4440002
	v_cndmask_b32_e32 v1, s14, v15, vcc_lo                     // 0000008E8B48: 02021E0E
	v_add3_u32 v17, v19, v11, v17                              // 0000008E8B4C: D6550011 04461713
	s_waitcnt lgkmcnt(0)                                       // 0000008E8B54: BF89FC07
	s_barrier                                                  // 0000008E8B58: BFBD0000
	buffer_gl0_inv                                             // 0000008E8B5C: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 0000008E8B64: BE8F2002
	s_cbranch_execz 26                                         // 0000008E8B68: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x1d4>
	s_add_u32 s3, s4, s16                                      // 0000008E8B6C: 80031004
	s_addc_u32 s18, s5, s17                                    // 0000008E8B70: 82121105
	v_lshlrev_b32_e32 v2, 1, v15                               // 0000008E8B74: 30041E81
	.long 0xd7000303                                           // 0000008E8B78: D7000303
	v_cndmask_b32_e32 v1, s3, v1, vcc_lo                       // 0000008E8B7C: 02020203
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008E8B80: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s18, v0, s3                  // 0000008E8B84: D5207C04 000E0012
	v_lshlrev_b32_e32 v5, 4, v15                               // 0000008E8B8C: 300A1E84
	.long 0xd7000302                                           // 0000008E8B90: D7000302
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 0000008E8B94: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008E8B98: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s3                    // 0000008E8B9C: D5207C03 000E0880
	.long 0xd7000304                                           // 0000008E8BA4: D7000304
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 0000008E8BA8: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008E8BAC: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s3                   // 0000008E8BB0: D5207C05 000E2280
	s_clause 0x1                                               // 0000008E8BB8: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 0000008E8BBC: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 0000008E8BC4: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 0000008E8BCC: BF8907F7
	v_cvt_f32_f16_e32 v28, v2                                  // 0000008E8BD0: 7E381702
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008E8BD4: 8C7E0F7E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 0000008E8BD8: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 0000008E8BE0: CA100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000008E8BE8: CA100080 16160080
	v_mov_b32_e32 v24, 0                                       // 0000008E8BF0: 7E300280
	s_and_saveexec_b32 s15, s2                                 // 0000008E8BF4: BE8F2002
	s_cbranch_execz 657                                        // 0000008E8BF8: BFA50291 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xc40>
	s_mul_i32 s2, s11, 6                                       // 0000008E8BFC: 9602860B
	s_mul_hi_u32 s3, s10, 6                                    // 0000008E8C00: 9683860A
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 0000008E8C04: CA220080 0C0A1E85
	s_add_i32 s20, s3, s2                                      // 0000008E8C0C: 81140203
	v_lshlrev_b32_e32 v2, 1, v15                               // 0000008E8C10: 30041E81
	.long 0xd7000201                                           // 0000008E8C14: D7000201
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 0000008E8C18: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008E8C1C: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s2                  // 0000008E8C20: D5207C00 000A0011
	v_mov_b32_e32 v23, v12                                     // 0000008E8C28: 7E2E030C
	.long 0xd7000201                                           // 0000008E8C2C: D7000201
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000008E8C30: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008E8C34: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s2                    // 0000008E8C38: D5207C00 000A0080
	v_lshl_or_b32 v25, v15, 4, 0x200                           // 0000008E8C40: D6560019 03FD090F 00000200
	.long 0xd7000201                                           // 0000008E8C4C: D7000201
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000008E8C50: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008E8C54: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s2                   // 0000008E8C58: D5207C00 000A0005
	v_dual_mov_b32 v26, v15 :: v_dual_mov_b32 v21, v12         // 0000008E8C60: CA10010F 1A14010C
	.long 0xd700020d                                           // 0000008E8C68: D700020D
	v_cndmask_b32_e32 v0, v1, v192, vcc_lo                     // 0000008E8C6C: 02018101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008E8C70: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s2                   // 0000008E8C74: D5207C0E 000A0080
	v_mov_b32_e32 v24, v12                                     // 0000008E8C7C: 7E30030C
	v_mov_b32_e32 v22, v12                                     // 0000008E8C80: 7E2C030C
	v_mov_b32_e32 v19, v12                                     // 0000008E8C84: 7E26030C
	v_mov_b32_e32 v20, v12                                     // 0000008E8C88: 7E28030C
	v_mov_b32_e32 v18, v12                                     // 0000008E8C8C: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 0000008E8C90: 7E20030C
	v_mov_b32_e32 v27, v28                                     // 0000008E8C94: 7E36031C
	s_lshl_b64 s[18:19], s[10:11], 2                           // 0000008E8C98: 8492820A
	s_mul_i32 s17, s10, 6                                      // 0000008E8C9C: 9611860A
	s_mov_b32 s16, 0                                           // 0000008E8CA0: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000008E8CA4: 8484810A
	s_branch 587                                               // 0000008E8CA8: BFA0024B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xbd8>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000008E8CAC: 8C7E0A7E
	v_and_b32_e32 v29, 0xff, v4                                // 0000008E8CB0: 363A08FF 000000FF
	s_and_b32 s2, exec_lo, s2                                  // 0000008E8CB8: 8B02027E
	v_add_nc_u32_e32 v25, 0x200, v25                           // 0000008E8CBC: 4A3232FF 00000200
	s_or_b32 s16, s2, s16                                      // 0000008E8CC4: 8C101002
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E8CC8: BF8700B2
	v_lshlrev_b32_e32 v29, 2, v29                              // 0000008E8CCC: 303A3A82
	ds_load_b32 v45, v29                                       // 0000008E8CD0: D8D80000 2D00001D
	v_lshrrev_b32_e32 v29, 6, v4                               // 0000008E8CD8: 323A0886
	v_and_b32_e32 v29, 0x3fc, v29                              // 0000008E8CDC: 363A3AFF 000003FC
	ds_load_b32 v46, v29                                       // 0000008E8CE4: D8D80000 2E00001D
	v_lshrrev_b32_e32 v29, 14, v4                              // 0000008E8CEC: 323A088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000008E8CF0: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008E8CF4: BF870112
	v_and_b32_e32 v29, 0x3fc, v29                              // 0000008E8CF8: 363A3AFF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008E8D00: 360808FF 000003FC
	ds_load_b32 v47, v29                                       // 0000008E8D08: D8D80000 2F00001D
	ds_load_b32 v48, v4                                        // 0000008E8D10: D8D80000 30000004
	v_and_b32_e32 v4, 0xff, v5                                 // 0000008E8D18: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E8D20: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008E8D24: 30080882
	ds_load_b32 v49, v4                                        // 0000008E8D28: D8D80000 31000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 0000008E8D30: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008E8D34: 360808FF 000003FC
	ds_load_b32 v50, v4                                        // 0000008E8D3C: D8D80000 32000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 0000008E8D44: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E8D48: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008E8D4C: 360808FF 000003FC
	ds_load_b32 v51, v4                                        // 0000008E8D54: D8D80000 33000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 0000008E8D5C: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008E8D60: 360808FF 000003FC
	ds_load_b32 v52, v4                                        // 0000008E8D68: D8D80000 34000004
	v_and_b32_e32 v4, 0xff, v6                                 // 0000008E8D70: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E8D78: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008E8D7C: 30080882
	ds_load_b32 v53, v4                                        // 0000008E8D80: D8D80000 35000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 0000008E8D88: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008E8D8C: 360808FF 000003FC
	ds_load_b32 v54, v4                                        // 0000008E8D94: D8D80000 36000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 0000008E8D9C: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E8DA0: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008E8DA4: 360808FF 000003FC
	ds_load_b32 v55, v4                                        // 0000008E8DAC: D8D80000 37000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 0000008E8DB4: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008E8DB8: 360808FF 000003FC
	ds_load_b32 v56, v4                                        // 0000008E8DC0: D8D80000 38000004
	v_and_b32_e32 v4, 0xff, v7                                 // 0000008E8DC8: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E8DD0: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008E8DD4: 30080882
	ds_load_b32 v57, v4                                        // 0000008E8DD8: D8D80000 39000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 0000008E8DE0: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008E8DE4: 360808FF 000003FC
	ds_load_b32 v58, v4                                        // 0000008E8DEC: D8D80000 3A000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 0000008E8DF4: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E8DF8: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008E8DFC: 360808FF 000003FC
	ds_load_b32 v59, v4                                        // 0000008E8E04: D8D80000 3B000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 0000008E8E0C: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008E8E10: 360808FF 000003FC
	ds_load_b32 v60, v4                                        // 0000008E8E18: D8D80000 3C000004
	.long 0xd73c0004                                           // 0000008E8E20: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000008E8E24: 02021681
	v_add_nc_u32_e32 v11, 0x400, v11                           // 0000008E8E28: 4A1616FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E8E30: BF870092
	.long 0xd7000229                                           // 0000008E8E34: D7000229
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000008E8E38: 02020806
	v_add_co_ci_u32_e64 v42, null, s7, v5, s2                  // 0000008E8E3C: D5207C2A 000A0A07
	s_clause 0x3                                               // 0000008E8E44: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 0000008E8E48: DC5E0000 047C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 0000008E8E50: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 0000008E8E58: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 0000008E8E60: DC5E0030 257C0029
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000008E8E68: BF890CF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 0000008E8E6C: CC1A4004 1A025B04
	s_waitcnt lgkmcnt(14)                                      // 0000008E8E74: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E8E78: BF8700A1
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 0000008E8E7C: CC1A4004 1C125D05
	s_waitcnt lgkmcnt(13)                                      // 0000008E8E84: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 0000008E8E88: CC1A4004 1C125F06
	s_waitcnt lgkmcnt(12)                                      // 0000008E8E90: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E8E94: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 0000008E8E98: CC1A4004 1C126107
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000008E8EA0: BF8908B7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008E8EA4: CC1A4004 1C12631D
	s_waitcnt lgkmcnt(10)                                      // 0000008E8EAC: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E8EB0: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008E8EB4: CC1A4004 1C12651E
	s_waitcnt lgkmcnt(9)                                       // 0000008E8EBC: BF89FC97
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008E8EC0: CC1A4004 1C12671F
	s_waitcnt lgkmcnt(8)                                       // 0000008E8EC8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E8ECC: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008E8ED0: CC1A4004 1C126920
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008E8ED8: BF890477
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008E8EDC: CC1A4004 1C126B21
	s_waitcnt lgkmcnt(6)                                       // 0000008E8EE4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E8EE8: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008E8EEC: CC1A4004 1C126D22
	s_waitcnt lgkmcnt(5)                                       // 0000008E8EF4: BF89FC57
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008E8EF8: CC1A4004 1C126F23
	s_waitcnt lgkmcnt(4)                                       // 0000008E8F00: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E8F04: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008E8F08: CC1A4004 1C127124
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008E8F10: BF890037
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008E8F14: CC1A4004 1C127325
	.long 0xd7000225                                           // 0000008E8F1C: D7000225
	v_cndmask_b32_e32 v0, v41, v4, vcc_lo                      // 0000008E8F20: 02000929
	s_waitcnt lgkmcnt(2)                                       // 0000008E8F24: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008E8F28: BF8701C2
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000008E8F2C: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v38, null, s5, v42, s2                 // 0000008E8F34: D5207C26 000A5405
	.long 0xd700022b                                           // 0000008E8F3C: D700022B
	v_cndmask_b32_e32 v0, v41, v18, vcc_lo                     // 0000008E8F40: 02002529
	s_waitcnt lgkmcnt(1)                                       // 0000008E8F44: BF89FC17
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000008E8F48: CC1A4004 1C127727
	v_add_co_ci_u32_e64 v44, null, s19, v42, s2                // 0000008E8F50: D5207C2C 000A5413
	.long 0xd7000229                                           // 0000008E8F58: D7000229
	v_cndmask_b32_e32 v0, v41, v17, vcc_lo                     // 0000008E8F5C: 02002329
	s_waitcnt lgkmcnt(0)                                       // 0000008E8F60: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008E8F64: BF870123
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 0000008E8F68: CC1A4004 1C127928
	v_add_co_ci_u32_e64 v42, null, s20, v42, s2                // 0000008E8F70: D5207C2A 000A5414
	v_fmac_f32_e32 v23, v28, v4                                // 0000008E8F78: 562E091C
	s_clause 0x3                                               // 0000008E8F7C: BF850003
	global_load_b128 v[4:7], v[37:38], off                     // 0000008E8F80: DC5E0000 047C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000008E8F88: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000008E8F90: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000008E8F98: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 0000008E8FA0: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 0000008E8FA4: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E8FAC: BF870091
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 0000008E8FB0: CC1A4004 1C125D05
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 0000008E8FB8: CC1A4004 1C125F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E8FC0: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 0000008E8FC4: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 0000008E8FCC: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008E8FD0: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E8FD8: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008E8FDC: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008E8FE4: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E8FEC: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008E8FF0: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 0000008E8FF8: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008E8FFC: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E9004: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008E9008: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008E9010: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E9018: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008E901C: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 0000008E9024: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008E9028: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E9030: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000008E9034: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000008E903C: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E9044: BF870091
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 0000008E9048: CC1A4004 1C127928
	v_fmac_f32_e32 v24, v28, v4                                // 0000008E9050: 5630091C
	s_clause 0x3                                               // 0000008E9054: BF850003
	global_load_b128 v[4:7], v[43:44], off                     // 0000008E9058: DC5E0000 047C002B
	global_load_b128 v[29:32], v[43:44], off offset:16         // 0000008E9060: DC5E0010 1D7C002B
	global_load_b128 v[33:36], v[43:44], off offset:32         // 0000008E9068: DC5E0020 217C002B
	global_load_b128 v[37:40], v[43:44], off offset:48         // 0000008E9070: DC5E0030 257C002B
	.long 0xd700022b                                           // 0000008E9078: D700022B
	v_cndmask_b32_e32 v0, v43, v18, vcc_lo                     // 0000008E907C: 0200252B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E9080: BF8700B1
	v_add_co_ci_u32_e64 v44, null, s19, v44, s2                // 0000008E9084: D5207C2C 000A5813
	s_waitcnt vmcnt(3)                                         // 0000008E908C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 0000008E9090: CC1A4004 1A025B04
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 0000008E9098: CC1A4004 1C125D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E90A0: BF870091
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 0000008E90A4: CC1A4004 1C125F06
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 0000008E90AC: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 0000008E90B4: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E90B8: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008E90BC: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008E90C4: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E90CC: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008E90D0: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008E90D8: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 0000008E90E0: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E90E4: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008E90E8: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008E90F0: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E90F8: BF870091
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008E90FC: CC1A4004 1C126F23
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008E9104: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 0000008E910C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E9110: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008E9114: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000008E911C: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E9124: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000008E9128: CC1A4004 1C127727
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 0000008E9130: CC1A4004 1C127928
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008E9138: BF870001
	v_fmac_f32_e32 v21, v28, v4                                // 0000008E913C: 562A091C
	s_clause 0x3                                               // 0000008E9140: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 0000008E9144: DC5E0000 047C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 0000008E914C: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 0000008E9154: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 0000008E915C: DC5E0030 257C0029
	.long 0xd7000229                                           // 0000008E9164: D7000229
	v_cndmask_b32_e32 v0, v41, v18, vcc_lo                     // 0000008E9168: 02002529
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E916C: BF8700B1
	v_add_co_ci_u32_e64 v42, null, s19, v42, s2                // 0000008E9170: D5207C2A 000A5413
	s_waitcnt vmcnt(3)                                         // 0000008E9178: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 0000008E917C: CC1A4004 1A025B04
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 0000008E9184: CC1A4004 1C125D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E918C: BF870091
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 0000008E9190: CC1A4004 1C125F06
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 0000008E9198: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 0000008E91A0: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E91A4: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008E91A8: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008E91B0: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E91B8: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008E91BC: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008E91C4: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 0000008E91CC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E91D0: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008E91D4: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008E91DC: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E91E4: BF870091
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008E91E8: CC1A4004 1C126F23
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008E91F0: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 0000008E91F8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E91FC: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008E9200: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000008E9208: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E9210: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000008E9214: CC1A4004 1C127727
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 0000008E921C: CC1A4004 1C127928
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008E9224: BF870001
	v_fmac_f32_e32 v22, v28, v4                                // 0000008E9228: 562C091C
	s_clause 0x3                                               // 0000008E922C: BF850003
	global_load_b128 v[4:7], v[43:44], off                     // 0000008E9230: DC5E0000 047C002B
	global_load_b128 v[29:32], v[43:44], off offset:16         // 0000008E9238: DC5E0010 1D7C002B
	global_load_b128 v[33:36], v[43:44], off offset:32         // 0000008E9240: DC5E0020 217C002B
	global_load_b128 v[37:40], v[43:44], off offset:48         // 0000008E9248: DC5E0030 257C002B
	s_waitcnt vmcnt(3)                                         // 0000008E9250: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 0000008E9254: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E925C: BF870091
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 0000008E9260: CC1A4004 1C125D05
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 0000008E9268: CC1A4004 1C125F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E9270: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 0000008E9274: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 0000008E927C: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008E9280: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E9288: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008E928C: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008E9294: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E929C: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008E92A0: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 0000008E92A8: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008E92AC: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E92B4: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008E92B8: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008E92C0: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E92C8: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008E92CC: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 0000008E92D4: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008E92D8: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E92E0: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000008E92E4: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000008E92EC: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E92F4: BF870091
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 0000008E92F8: CC1A4004 1C127928
	v_fmac_f32_e32 v19, v28, v4                                // 0000008E9300: 5626091C
	s_clause 0x3                                               // 0000008E9304: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 0000008E9308: DC5E0000 047C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 0000008E9310: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 0000008E9318: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 0000008E9320: DC5E0030 257C0029
	s_waitcnt vmcnt(3)                                         // 0000008E9328: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 0000008E932C: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E9334: BF870091
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 0000008E9338: CC1A4004 1C125D05
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 0000008E9340: CC1A4004 1C125F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E9348: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 0000008E934C: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 0000008E9354: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008E9358: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E9360: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008E9364: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008E936C: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E9374: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008E9378: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 0000008E9380: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008E9384: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E938C: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008E9390: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008E9398: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E93A0: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008E93A4: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 0000008E93AC: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008E93B0: CC1A4004 1C127325
	.long 0xd7000225                                           // 0000008E93B8: D7000225
	v_cndmask_b32_e32 v0, v43, v18, vcc_lo                     // 0000008E93BC: 0200252B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008E93C0: BF870122
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000008E93C4: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v38, null, s19, v44, s2                // 0000008E93CC: D5207C26 000A5813
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000008E93D4: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E93DC: BF870091
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 0000008E93E0: CC1A4004 1C127928
	v_fmac_f32_e32 v20, v28, v4                                // 0000008E93E8: 5628091C
	s_clause 0x3                                               // 0000008E93EC: BF850003
	global_load_b128 v[4:7], v[37:38], off                     // 0000008E93F0: DC5E0000 047C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000008E93F8: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000008E9400: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000008E9408: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 0000008E9410: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 0000008E9414: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E941C: BF870091
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 0000008E9420: CC1A4004 1C125D05
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 0000008E9428: CC1A4004 1C125F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E9430: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 0000008E9434: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 0000008E943C: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008E9440: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E9448: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008E944C: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008E9454: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E945C: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008E9460: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 0000008E9468: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008E946C: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E9474: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008E9478: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008E9480: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E9488: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008E948C: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 0000008E9494: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008E9498: CC1A4004 1C127325
	.long 0xd7000225                                           // 0000008E94A0: D7000225
	v_cndmask_b32_e32 v0, v41, v18, vcc_lo                     // 0000008E94A4: 02002529
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008E94A8: BF8701B2
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000008E94AC: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v38, null, s19, v42, s2                // 0000008E94B4: D5207C26 000A5413
	.long 0xd700020d                                           // 0000008E94BC: D700020D
	v_cndmask_b32_e32 v0, v13, v192, vcc_lo                    // 0000008E94C0: 0201810D
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000008E94C4: CC1A4004 1C127727
	v_add_co_ci_u32_e64 v14, null, 0, v14, s2                  // 0000008E94CC: D5207C0E 000A1C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E94D4: BF870092
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 0000008E94D8: CC1A4004 1C127928
	v_fmac_f32_e32 v18, v28, v4                                // 0000008E94E0: 5624091C
	s_clause 0x3                                               // 0000008E94E4: BF850003
	global_load_b128 v[4:7], v[37:38], off                     // 0000008E94E8: DC5E0000 047C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000008E94F0: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000008E94F8: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000008E9500: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 0000008E9508: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 0000008E950C: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008E9514: BF870121
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 0000008E9518: CC1A4004 1C125D05
	v_mov_b32_e32 v5, v1                                       // 0000008E9520: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 0000008E9524: CC1A4004 1C125F06
	v_mov_b32_e32 v6, v2                                       // 0000008E952C: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008E9530: BF870132
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 0000008E9534: CC1A4004 1C126107
	v_mov_b32_e32 v7, v3                                       // 0000008E953C: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 0000008E9540: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008E9544: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E954C: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008E9550: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008E9558: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E9560: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008E9564: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 0000008E956C: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008E9570: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E9578: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008E957C: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008E9584: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E958C: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008E9590: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 0000008E9598: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008E959C: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E95A4: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000008E95A8: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000008E95B0: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E95B8: BF870091
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 0000008E95BC: CC1A4004 1C127928
	v_fmac_f32_e32 v16, v28, v4                                // 0000008E95C4: 5620091C
	v_mov_b32_e32 v4, v0                                       // 0000008E95C8: 7E080300
	v_mov_b32_e32 v28, v27                                     // 0000008E95CC: 7E38031B
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008E95D0: 917E107E
	s_cbranch_execz 25                                         // 0000008E95D4: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xc3c>
	s_waitcnt vmcnt(0)                                         // 0000008E95D8: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v26, 32, v26    // 0000008E95DC: CA200105 011A34A0
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v3, v7             // 0000008E95E4: CA100104 00020107
	v_mov_b32_e32 v2, v6                                       // 0000008E95EC: 7E040306
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008E95F0: BF870003
	.long 0xd4430002                                           // 0000008E95F4: D4430002
	v_cndmask_b32_e32 v1, s14, v26, vcc_lo                     // 0000008E95F8: 0202340E
	s_mov_b32 s10, exec_lo                                     // 0000008E95FC: BE8A007E
	.long 0xd4c4007e                                           // 0000008E9600: D4C4007E
	v_cndmask_b32_e32 v1, s14, v26, vcc_lo                     // 0000008E9604: 0202340E
	s_cbranch_execz 64936                                      // 0000008E9608: BFA5FDA8 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x2ac>
	.long 0xd7000300                                           // 0000008E960C: D7000300
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 0000008E9610: 0202330A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008E9614: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s3                   // 0000008E9618: D5207C01 000E2280
	global_load_d16_b16 v27, v[13:14], off                     // 0000008E9620: DC820000 1B7C000D
	global_load_b128 v[0:3], v[0:1], off                       // 0000008E9628: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 0000008E9630: BF8907F7
	v_cvt_f32_f16_e32 v27, v27                                 // 0000008E9634: 7E36171B
	s_branch 64924                                             // 0000008E9638: BFA0FD9C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x2ac>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000008E963C: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E9640: BF8700A9
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008E9644: 8C7E0F7E
	.long 0xd71f0000                                           // 0000008E9648: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008E964C: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 0000008E9650: 3A020090
	v_xor_b32_e32 v11, 8, v0                                   // 0000008E9654: 3A160088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E9658: BF870092
	.long 0xd44c0002                                           // 0000008E965C: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000008E9660: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 0000008E9664: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008E966C: BF870113
	.long 0xd44c0002                                           // 0000008E9670: D44C0002
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 0000008E9674: 020216A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008E9678: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008E967C: BF870002
	v_cndmask_b32_e64 v11, v0, v11, s2                         // 0000008E9680: D501000B 000A1700
	ds_bpermute_b32 v2, v1, v24                                // 0000008E9688: DACC0000 02001801
	s_waitcnt lgkmcnt(0)                                       // 0000008E9690: BF89FC07
	v_add_f32_e32 v2, v24, v2                                  // 0000008E9694: 06040518
	s_waitcnt vmcnt(0)                                         // 0000008E9698: BF8903F7
	ds_bpermute_b32 v4, v1, v22                                // 0000008E969C: DACC0000 04001601
	ds_bpermute_b32 v3, v1, v23                                // 0000008E96A4: DACC0000 03001701
	ds_bpermute_b32 v6, v1, v20                                // 0000008E96AC: DACC0000 06001401
	ds_bpermute_b32 v5, v1, v21                                // 0000008E96B4: DACC0000 05001501
	ds_bpermute_b32 v7, v1, v19                                // 0000008E96BC: DACC0000 07001301
	ds_bpermute_b32 v10, v1, v16                               // 0000008E96C4: DACC0000 0A001001
	ds_bpermute_b32 v1, v1, v18                                // 0000008E96CC: DACC0000 01001201
	s_waitcnt lgkmcnt(6)                                       // 0000008E96D4: BF89FC67
	v_dual_add_f32 v4, v22, v4 :: v_dual_lshlrev_b32 v11, 2, v11// 0000008E96D8: C9220916 040A1682
	s_waitcnt lgkmcnt(4)                                       // 0000008E96E0: BF89FC47
	v_dual_add_f32 v3, v23, v3 :: v_dual_add_f32 v6, v20, v6   // 0000008E96E4: C9080717 03060D14
	v_xor_b32_e32 v20, 4, v0                                   // 0000008E96EC: 3A280084
	s_waitcnt lgkmcnt(1)                                       // 0000008E96F0: BF89FC17
	v_dual_add_f32 v5, v21, v5 :: v_dual_add_f32 v10, v16, v10 // 0000008E96F4: C9080B15 050A1510
	ds_bpermute_b32 v14, v11, v4                               // 0000008E96FC: DACC0000 0E00040B
	s_waitcnt lgkmcnt(1)                                       // 0000008E9704: BF89FC17
	v_add_f32_e32 v1, v18, v1                                  // 0000008E9708: 06020312
	.long 0xd44c0002                                           // 0000008E970C: D44C0002
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 0000008E9710: 020228A0
	ds_bpermute_b32 v12, v11, v2                               // 0000008E9714: DACC0000 0C00020B
	ds_bpermute_b32 v13, v11, v3                               // 0000008E971C: DACC0000 0D00030B
	ds_bpermute_b32 v16, v11, v5                               // 0000008E9724: DACC0000 1000050B
	ds_bpermute_b32 v17, v11, v6                               // 0000008E972C: DACC0000 1100060B
	v_cndmask_b32_e64 v20, v0, v20, s2                         // 0000008E9734: D5010014 000A2900
	v_add_f32_e32 v7, v19, v7                                  // 0000008E973C: 060E0F13
	ds_bpermute_b32 v19, v11, v10                              // 0000008E9740: DACC0000 13000A0B
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000008E9748: 30282882
	ds_bpermute_b32 v18, v11, v7                               // 0000008E974C: DACC0000 1200070B
	s_waitcnt lgkmcnt(6)                                       // 0000008E9754: BF89FC67
	v_add_f32_e32 v4, v4, v14                                  // 0000008E9758: 06081D04
	ds_bpermute_b32 v11, v11, v1                               // 0000008E975C: DACC0000 0B00010B
	s_waitcnt lgkmcnt(5)                                       // 0000008E9764: BF89FC57
	v_dual_add_f32 v2, v2, v12 :: v_dual_add_f32 v3, v3, v13   // 0000008E9768: C9081902 02021B03
	s_waitcnt lgkmcnt(3)                                       // 0000008E9770: BF89FC37
	v_dual_add_f32 v5, v5, v16 :: v_dual_add_f32 v6, v6, v17   // 0000008E9774: C9082105 05062306
	ds_bpermute_b32 v13, v20, v4                               // 0000008E977C: DACC0000 0D000414
	s_waitcnt lgkmcnt(3)                                       // 0000008E9784: BF89FC37
	v_add_f32_e32 v10, v10, v19                                // 0000008E9788: 0614270A
	ds_bpermute_b32 v12, v20, v3                               // 0000008E978C: DACC0000 0C000314
	ds_bpermute_b32 v14, v20, v5                               // 0000008E9794: DACC0000 0E000514
	ds_bpermute_b32 v16, v20, v6                               // 0000008E979C: DACC0000 10000614
	s_waitcnt lgkmcnt(5)                                       // 0000008E97A4: BF89FC57
	v_add_f32_e32 v7, v7, v18                                  // 0000008E97A8: 060E2507
	ds_bpermute_b32 v18, v20, v10                              // 0000008E97AC: DACC0000 12000A14
	ds_bpermute_b32 v17, v20, v7                               // 0000008E97B4: DACC0000 11000714
	s_waitcnt lgkmcnt(6)                                       // 0000008E97BC: BF89FC67
	v_add_f32_e32 v1, v1, v11                                  // 0000008E97C0: 06021701
	ds_bpermute_b32 v11, v20, v2                               // 0000008E97C4: DACC0000 0B000214
	ds_bpermute_b32 v19, v20, v1                               // 0000008E97CC: DACC0000 13000114
	v_xor_b32_e32 v20, 2, v0                                   // 0000008E97D4: 3A280082
	s_waitcnt lgkmcnt(6)                                       // 0000008E97D8: BF89FC67
	v_dual_add_f32 v4, v4, v13 :: v_dual_add_f32 v3, v3, v12   // 0000008E97DC: C9081B04 04021903
	s_waitcnt lgkmcnt(5)                                       // 0000008E97E4: BF89FC57
	v_add_f32_e32 v5, v5, v14                                  // 0000008E97E8: 060A1D05
	.long 0xd44c0002                                           // 0000008E97EC: D44C0002
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 0000008E97F0: 020228A0
	s_waitcnt lgkmcnt(4)                                       // 0000008E97F4: BF89FC47
	v_add_f32_e32 v6, v6, v16                                  // 0000008E97F8: 060C2106
	v_xor_b32_e32 v14, 1, v0                                   // 0000008E97FC: 3A1C0081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008E9800: BF8701B3
	v_cndmask_b32_e64 v20, v0, v20, s2                         // 0000008E9804: D5010014 000A2900
	s_waitcnt lgkmcnt(2)                                       // 0000008E980C: BF89FC27
	v_add_f32_e32 v7, v7, v17                                  // 0000008E9810: 060E2307
	.long 0xd44c0002                                           // 0000008E9814: D44C0002
	v_cndmask_b32_e32 v1, 32, v14, vcc_lo                      // 0000008E9818: 02021CA0
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008E981C: BF870003
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000008E9820: 30282882
	s_waitcnt lgkmcnt(1)                                       // 0000008E9824: BF89FC17
	v_add_f32_e32 v2, v2, v11                                  // 0000008E9828: 06041702
	v_add_f32_e32 v12, v10, v18                                // 0000008E982C: 0618250A
	v_cndmask_b32_e64 v0, v0, v14, s2                          // 0000008E9830: D5010000 000A1D00
	s_waitcnt lgkmcnt(0)                                       // 0000008E9838: BF89FC07
	v_add_f32_e32 v1, v1, v19                                  // 0000008E983C: 06022701
	ds_bpermute_b32 v11, v20, v3                               // 0000008E9840: DACC0000 0B000314
	ds_bpermute_b32 v10, v20, v2                               // 0000008E9848: DACC0000 0A000214
	ds_bpermute_b32 v13, v20, v4                               // 0000008E9850: DACC0000 0D000414
	ds_bpermute_b32 v17, v20, v5                               // 0000008E9858: DACC0000 11000514
	ds_bpermute_b32 v18, v20, v6                               // 0000008E9860: DACC0000 12000614
	ds_bpermute_b32 v19, v20, v7                               // 0000008E9868: DACC0000 13000714
	ds_bpermute_b32 v21, v20, v12                              // 0000008E9870: DACC0000 15000C14
	ds_bpermute_b32 v20, v20, v1                               // 0000008E9878: DACC0000 14000114
	v_lshlrev_b32_e32 v22, 2, v0                               // 0000008E9880: 302C0082
	.long 0xd44a0002                                           // 0000008E9884: D44A0002
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 0000008E9888: 02021E80
	s_and_b32 s2, s2, vcc_lo                                   // 0000008E988C: 8B026A02
	s_waitcnt lgkmcnt(7)                                       // 0000008E9890: BF89FC77
	v_add_f32_e32 v16, v3, v11                                 // 0000008E9894: 06201703
	s_waitcnt lgkmcnt(6)                                       // 0000008E9898: BF89FC67
	v_add_f32_e32 v14, v2, v10                                 // 0000008E989C: 061C1502
	s_waitcnt lgkmcnt(5)                                       // 0000008E98A0: BF89FC57
	v_add_f32_e32 v10, v4, v13                                 // 0000008E98A4: 06141B04
	s_waitcnt lgkmcnt(3)                                       // 0000008E98A8: BF89FC37
	v_dual_add_f32 v11, v5, v17 :: v_dual_add_f32 v4, v6, v18  // 0000008E98AC: C9082305 0B042506
	s_waitcnt lgkmcnt(1)                                       // 0000008E98B4: BF89FC17
	v_dual_add_f32 v5, v7, v19 :: v_dual_add_f32 v0, v12, v21  // 0000008E98B8: C9082707 05002B0C
	s_waitcnt lgkmcnt(0)                                       // 0000008E98C0: BF89FC07
	v_add_f32_e32 v1, v1, v20                                  // 0000008E98C4: 06022901
	ds_bpermute_b32 v18, v22, v16                              // 0000008E98C8: DACC0000 12001016
	ds_bpermute_b32 v17, v22, v14                              // 0000008E98D0: DACC0000 11000E16
	ds_bpermute_b32 v13, v22, v11                              // 0000008E98D8: DACC0000 0D000B16
	ds_bpermute_b32 v12, v22, v10                              // 0000008E98E0: DACC0000 0C000A16
	ds_bpermute_b32 v6, v22, v5                                // 0000008E98E8: DACC0000 06000516
	ds_bpermute_b32 v7, v22, v4                                // 0000008E98F0: DACC0000 07000416
	ds_bpermute_b32 v2, v22, v1                                // 0000008E98F8: DACC0000 02000116
	ds_bpermute_b32 v3, v22, v0                                // 0000008E9900: DACC0000 03000016
	s_and_saveexec_b32 s3, s2                                  // 0000008E9908: BE832002
	s_cbranch_execz 156                                        // 0000008E990C: BFA5009C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x1180>
	v_ashrrev_i32_e32 v15, 31, v9                              // 0000008E9910: 341E129F
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008E9914: F4040080 F8000040
	s_lshr_b32 s0, s13, 31                                     // 0000008E991C: 85009F0D
	s_waitcnt lgkmcnt(0)                                       // 0000008E9920: BF89FC07
	v_dual_mov_b32 v21, s8 :: v_dual_add_f32 v16, v16, v18     // 0000008E9924: CA080008 15102510
	v_lshrrev_b32_e32 v15, 23, v15                             // 0000008E992C: 321E1E97
	s_add_u32 s4, s12, s0                                      // 0000008E9930: 8004000C
	v_dual_add_f32 v14, v14, v17 :: v_dual_add_f32 v7, v4, v7  // 0000008E9934: C908230E 0E060F04
	.long 0x7f223880                                           // 0000008E993C: 7F223880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E9940: BF870093
	.long 0xd7006a0f                                           // 0000008E9944: D7006A0F
	v_cndmask_b32_e32 v1, v8, v15, vcc_lo                      // 0000008E9948: 02021F08
	v_add_co_ci_u32_e64 v19, null, 0, v9, vcc_lo               // 0000008E994C: D5207C13 01AA1280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008E9954: BF870194
	.long 0x7e22398e                                           // 0000008E9958: 7E22398E
	v_dual_mov_b32 v20, s9 :: v_dual_and_b32 v15, 0xfffffe00, v15// 0000008E995C: CA240009 140E1EFF FFFFFE00
	.long 0x7e2e3990                                           // 0000008E9968: 7E2E3990
	.long 0x7f2e3991                                           // 0000008E996C: 7F2E3991
	s_addc_u32 s5, s13, 0                                      // 0000008E9970: 8205800D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E9974: BF870093
	.long 0xd7016a08                                           // 0000008E9978: D7016A08
	v_cndmask_b32_e32 v1, v8, v15, vcc_lo                      // 0000008E997C: 02021F08
	v_sub_co_ci_u32_e64 v9, null, v9, v19, vcc_lo              // 0000008E9980: D5217C09 01AA2709
	v_add_f32_e32 v12, v10, v12                                // 0000008E9988: 0618190A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008E998C: BF870193
	.long 0xd7000012                                           // 0000008E9990: D7000012
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 0000008E9994: 020210FF FFFFFF00
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 0000008E999C: 7CA810FF 00000100
	v_add_co_ci_u32_e64 v22, null, -1, v9, s0                  // 0000008E99A4: D5207C16 000212C1
	s_and_b32 s0, s4, -2                                       // 0000008E99AC: 8B00C204
	v_dual_add_f32 v13, v11, v13 :: v_dual_cndmask_b32 v20, s3, v20// 0000008E99B0: C9121B0B 0D142803
	v_cndmask_b32_e32 v9, v22, v9, vcc_lo                      // 0000008E99B8: 02121316
	v_cndmask_b32_e32 v8, v18, v8, vcc_lo                      // 0000008E99BC: 02101112
	v_cndmask_b32_e32 v18, s2, v21, vcc_lo                     // 0000008E99C0: 02242A02
	v_and_b32_e32 v21, 1, v17                                  // 0000008E99C4: 362A2281
	v_and_b32_e32 v22, 1, v23                                  // 0000008E99C8: 362C2E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008E99CC: BF870214
	.long 0xd73c0008                                           // 0000008E99D0: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000008E99D4: 02021081
	.long 0xd7006a0f                                           // 0000008E99D8: D7006A0F
	v_cndmask_b32_e32 v1, v18, v15, vcc_lo                     // 0000008E99DC: 02021F12
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008E99E0: BF8701A1
	v_add_co_ci_u32_e64 v18, null, v20, v19, vcc_lo            // 0000008E99E4: D5207C12 01AA2714
	v_add3_u32 v19, v14, v21, 0x7fff                           // 0000008E99EC: D6550013 03FE2B0E 00007FFF
	.long 0xd7006a08                                           // 0000008E99F8: D7006A08
	v_cndmask_b32_e32 v1, v15, v8, vcc_lo                      // 0000008E99FC: 0202110F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008E9A00: BF8701A1
	v_add_co_ci_u32_e64 v9, null, v18, v9, vcc_lo              // 0000008E9A04: D5207C09 01AA1312
	v_add3_u32 v16, v16, v22, 0x7fff                           // 0000008E9A0C: D6550010 03FE2D10 00007FFF
	.long 0xd7006a0e                                           // 0000008E9A18: D7006A0E
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 0000008E9A1C: 02000108
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008E9A20: BF870001
	v_add_co_ci_u32_e64 v15, null, s5, v9, vcc_lo              // 0000008E9A24: D5207C0F 01AA1205
	s_clause 0x1                                               // 0000008E9A2C: BF850001
	global_store_d16_hi_b16 v[8:9], v16, off                   // 0000008E9A30: DC960000 007C1008
	global_store_d16_hi_b16 v[14:15], v19, off                 // 0000008E9A38: DC960000 007C130E
	.long 0x7e1c398d                                           // 0000008E9A40: 7E1C398D
	.long 0x7f1c3991                                           // 0000008E9A44: 7F1C3991
	s_ashr_i64 s[0:1], s[4:5], 1                               // 0000008E9A48: 86808104
	v_add_f32_e32 v15, v5, v6                                  // 0000008E9A4C: 061E0D05
	s_lshl_b64 s[2:3], s[0:1], 2                               // 0000008E9A50: 84828200
	v_mad_u64_u32 v[4:5], null, s0, 6, v[8:9]                  // 0000008E9A54: D6FE7C04 04210C00
	v_and_b32_e32 v14, 1, v14                                  // 0000008E9A5C: 361C1C81
	.long 0xd7006a0a                                           // 0000008E9A60: D7006A0A
	v_cndmask_b32_e32 v0, v8, v2, vcc_lo                       // 0000008E9A64: 02000508
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008E9A68: BF870191
	v_add_co_ci_u32_e64 v11, null, s3, v9, vcc_lo              // 0000008E9A6C: D5207C0B 01AA1203
	v_add3_u32 v8, v13, v14, 0x7fff                            // 0000008E9A74: D6550008 03FE1D0D 00007FFF
	.long 0x7e12398f                                           // 0000008E9A80: 7E12398F
	.long 0x7f123991                                           // 0000008E9A84: 7F123991
	v_add_f32_e32 v13, v0, v3                                  // 0000008E9A88: 061A0700
	.long 0xd7006a00                                           // 0000008E9A8C: D7006A00
	v_cndmask_b32_e32 v0, v10, v2, vcc_lo                      // 0000008E9A90: 0200050A
	global_store_d16_hi_b16 v[10:11], v8, off                  // 0000008E9A94: DC960000 007C080A
	v_dual_add_f32 v9, v1, v2 :: v_dual_and_b32 v8, 1, v9      // 0000008E9A9C: C9240501 09081281
	.long 0x7e22398c                                           // 0000008E9AA4: 7E22398C
	v_add_co_ci_u32_e64 v1, null, s3, v11, vcc_lo              // 0000008E9AA8: D5207C01 01AA1603
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008E9AB0: BF870223
	v_add3_u32 v11, v15, v8, 0x7fff                            // 0000008E9AB4: D655000B 03FE110F 00007FFF
	.long 0xd7006a02                                           // 0000008E9AC0: D7006A02
	v_cndmask_b32_e32 v0, v4, v2, vcc_lo                       // 0000008E9AC4: 02000504
	v_and_b32_e32 v6, 1, v17                                   // 0000008E9AC8: 360C2281
	.long 0x7e223987                                           // 0000008E9ACC: 7E223987
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008E9AD0: BF8701A2
	v_add3_u32 v12, v12, v6, 0x7fff                            // 0000008E9AD4: D655000C 03FE0D0C 00007FFF
	v_mad_u64_u32 v[5:6], null, s1, 6, v[5:6]                  // 0000008E9AE0: D6FE7C05 04150C01
	v_and_b32_e32 v6, 1, v17                                   // 0000008E9AE8: 360C2281
	.long 0x7e22398d                                           // 0000008E9AEC: 7E22398D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000008E9AF0: BF870232
	v_add3_u32 v10, v7, v6, 0x7fff                             // 0000008E9AF4: D655000A 03FE0D07 00007FFF
	.long 0x7e0c3989                                           // 0000008E9B00: 7E0C3989
	.long 0x7f0c3991                                           // 0000008E9B04: 7F0C3991
	v_and_b32_e32 v8, 1, v17                                   // 0000008E9B08: 36102281
	v_add_co_ci_u32_e64 v3, null, s3, v5, vcc_lo               // 0000008E9B0C: D5207C03 01AA0A03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E9B14: BF8700A3
	v_and_b32_e32 v14, 1, v6                                   // 0000008E9B18: 361C0C81
	.long 0xd7006a06                                           // 0000008E9B1C: D7006A06
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 0000008E9B20: 02000500
	v_add_co_ci_u32_e64 v7, null, s3, v1, vcc_lo               // 0000008E9B24: D5207C07 01AA0203
	v_add3_u32 v13, v13, v8, 0x7fff                            // 0000008E9B2C: D655000D 03FE110D 00007FFF
	.long 0xd7006a08                                           // 0000008E9B38: D7006A08
	v_cndmask_b32_e32 v0, v2, v2, vcc_lo                       // 0000008E9B3C: 02000502
	v_add3_u32 v14, v9, v14, 0x7fff                            // 0000008E9B40: D655000E 03FE1D09 00007FFF
	v_add_co_ci_u32_e64 v9, null, s3, v3, vcc_lo               // 0000008E9B4C: D5207C09 01AA0603
	s_clause 0x4                                               // 0000008E9B54: BF850004
	global_store_d16_hi_b16 v[4:5], v12, off                   // 0000008E9B58: DC960000 007C0C04
	global_store_d16_hi_b16 v[0:1], v11, off                   // 0000008E9B60: DC960000 007C0B00
	global_store_d16_hi_b16 v[2:3], v10, off                   // 0000008E9B68: DC960000 007C0A02
	global_store_d16_hi_b16 v[6:7], v14, off                   // 0000008E9B70: DC960000 007C0E06
	global_store_d16_hi_b16 v[8:9], v13, off                   // 0000008E9B78: DC960000 007C0D08
	s_endpgm                                                   // 0000008E9B80: BFB00000
		...

