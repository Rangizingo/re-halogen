0000000000fa2c00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000FA2C00: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v15, 15, v0         // 000000FA2C08: CA240080 040E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000FA2C10: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000FA2C14: 86039F02
	v_mov_b32_e32 v16, 0                                       // 000000FA2C18: 7E200280
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000FA2C1C: 84808402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000FA2C20: BF870009
	v_dual_mov_b32 v9, s1 :: v_dual_lshlrev_b32 v2, 2, v15     // 000000FA2C24: CA220001 09021E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 000000FA2C2C: 30060282
	v_or_b32_e32 v8, s0, v1                                    // 000000FA2C30: 38100200
	.long 0x7f183880                                           // 000000FA2C34: 7F183880
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v5, 0              // 000000FA2C38: CA100080 1A040080
	v_mov_b32_e32 v6, 0                                        // 000000FA2C40: 7E0C0280
	s_waitcnt lgkmcnt(0)                                       // 000000FA2C44: BF89FC07
	s_clause 0x1                                               // 000000FA2C48: BF850001
	global_load_b32 v7, v2, s[4:5]                             // 000000FA2C4C: DC520000 07040002
	global_load_b32 v3, v3, s[4:5]                             // 000000FA2C54: DC520000 03040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 000000FA2C5C: 7CA8100C
	s_add_u32 s2, s4, s14                                      // 000000FA2C60: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000FA2C64: 82030F05
	s_lshr_b32 s0, s11, 31                                     // 000000FA2C68: 85009F0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000FA2C6C: BF870009
	s_add_u32 s14, s10, s0                                     // 000000FA2C70: 800E000A
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 000000FA2C74: 02141080
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 000000FA2C78: D501000E 01A80280
	s_addc_u32 s15, s11, 0                                     // 000000FA2C80: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 000000FA2C84: 86149F0B
	s_ashr_i64 s[0:1], s[14:15], 1                             // 000000FA2C88: 8680810E
	s_lshr_b32 s14, s20, 27                                    // 000000FA2C8C: 850E9B14
	.long 0xd72c0013                                           // 000000FA2C90: D72C0013
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 000000FA2C94: 0200010E
	.long 0xd72c000e                                           // 000000FA2C98: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 000000FA2C9C: 02021C12
	s_waitcnt vmcnt(1)                                         // 000000FA2CA0: BF8907F7
	v_bfe_u32 v11, v7, 16, 1                                   // 000000FA2CA4: D610000B 02052107
	s_waitcnt vmcnt(0)                                         // 000000FA2CAC: BF8903F7
	v_bfe_u32 v18, v3, 16, 1                                   // 000000FA2CB0: D6100012 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FA2CB8: BF870112
	v_add3_u32 v7, v7, v11, 0x7fff                             // 000000FA2CBC: D6550007 03FE1707 00007FFF
	v_add3_u32 v3, v3, v18, 0x7fff                             // 000000FA2CC8: D6550003 03FE2503 00007FFF
	v_lshlrev_b32_e32 v18, 2, v0                               // 000000FA2CD4: 30240082
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FA2CD8: BF870003
	.long 0x7e183987                                           // 000000FA2CDC: 7E183987
	v_mov_b32_e32 v7, 0                                        // 000000FA2CE0: 7E0E0280
	.long 0xd72c000d                                           // 000000FA2CE4: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 000000FA2CE8: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 000000FA2CEC: D6FE7C01 02021412
	.long 0xd72c0011                                           // 000000FA2CF4: D72C0011
	v_cndmask_b32_e32 v0, v10, v1, vcc_lo                      // 000000FA2CF8: 0200030A
	v_mad_u64_u32 v[10:11], null, v10, s0, s[2:3]              // 000000FA2CFC: D6FE7C0A 0008010A
	s_add_u32 s2, s10, s14                                     // 000000FA2D04: 80020E0A
	s_addc_u32 s3, s11, 0                                      // 000000FA2D08: 8203800B
	v_and_or_b32 v3, 0xffff0000, v3, v12                       // 000000FA2D0C: D6570003 043206FF FFFF0000
	s_lshr_b64 s[2:3], s[2:3], 5                               // 000000FA2D18: 85828502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000FA2D1C: BF870009
	.long 0xd4440000                                           // 000000FA2D20: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 000000FA2D24: 02021E02
	v_add3_u32 v0, v2, v14, v13                                // 000000FA2D28: D6550000 04361D02
	v_add3_u32 v17, v19, v11, v17                              // 000000FA2D30: D6550011 04461713
	ds_store_b32 v18, v3                                       // 000000FA2D38: D8340000 00000312
	s_waitcnt lgkmcnt(0)                                       // 000000FA2D40: BF89FC07
	s_barrier                                                  // 000000FA2D44: BFBD0000
	buffer_gl0_inv                                             // 000000FA2D48: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000FA2D50: BE832000
	s_cbranch_execz 26                                         // 000000FA2D54: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x1c0>
	s_add_u32 s1, s4, s16                                      // 000000FA2D58: 80011004
	s_addc_u32 s14, s5, s17                                    // 000000FA2D5C: 820E1105
	v_lshlrev_b32_e32 v2, 1, v15                               // 000000FA2D60: 30041E81
	.long 0xd7000103                                           // 000000FA2D64: D7000103
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 000000FA2D68: 02020201
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FA2D6C: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s14, v0, s1                  // 000000FA2D70: D5207C04 0006000E
	v_lshlrev_b32_e32 v5, 4, v15                               // 000000FA2D78: 300A1E84
	.long 0xd7000102                                           // 000000FA2D7C: D7000102
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 000000FA2D80: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FA2D84: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s1                    // 000000FA2D88: D5207C03 00060880
	.long 0xd7000104                                           // 000000FA2D90: D7000104
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 000000FA2D94: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FA2D98: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s1                   // 000000FA2D9C: D5207C05 00062280
	s_clause 0x1                                               // 000000FA2DA4: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 000000FA2DA8: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 000000FA2DB0: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 000000FA2DB8: BF8907F7
	v_cvt_f32_f16_e32 v26, v2                                  // 000000FA2DBC: 7E341702
	s_or_b32 exec_lo, exec_lo, s3                              // 000000FA2DC0: 8C7E037E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 000000FA2DC4: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 000000FA2DCC: CA100080 14140080
	v_mov_b32_e32 v22, 0                                       // 000000FA2DD4: 7E2C0280
	s_and_saveexec_b32 s3, s0                                  // 000000FA2DD8: BE832000
	s_cbranch_execz 537                                        // 000000FA2DDC: BFA50219 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xa44>
	s_mul_i32 s0, s11, 6                                       // 000000FA2DE0: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 000000FA2DE4: 9681860A
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 000000FA2DE8: CA220080 0C0A1E85
	s_add_i32 s18, s1, s0                                      // 000000FA2DF0: 81120001
	v_lshlrev_b32_e32 v2, 1, v15                               // 000000FA2DF4: 30041E81
	.long 0xd7000001                                           // 000000FA2DF8: D7000001
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 000000FA2DFC: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FA2E00: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s0                  // 000000FA2E04: D5207C00 00020011
	v_mov_b32_e32 v21, v12                                     // 000000FA2E0C: 7E2A030C
	.long 0xd7000001                                           // 000000FA2E10: D7000001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000FA2E14: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FA2E18: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s0                    // 000000FA2E1C: D5207C00 00020080
	v_lshl_or_b32 v23, v15, 4, 0x100                           // 000000FA2E24: D6560017 03FD090F 00000100
	.long 0xd7000001                                           // 000000FA2E30: D7000001
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000FA2E34: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FA2E38: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s0                   // 000000FA2E3C: D5207C00 00020005
	v_dual_mov_b32 v24, v15 :: v_dual_mov_b32 v19, v12         // 000000FA2E44: CA10010F 1812010C
	.long 0xd700000d                                           // 000000FA2E4C: D700000D
	v_cndmask_b32_e32 v0, v1, v160, vcc_lo                     // 000000FA2E50: 02014101
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FA2E54: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s0                   // 000000FA2E58: D5207C0E 00020080
	v_dual_mov_b32 v22, v12 :: v_dual_mov_b32 v25, v26         // 000000FA2E60: CA10010C 1618011A
	v_mov_b32_e32 v20, v12                                     // 000000FA2E68: 7E28030C
	v_mov_b32_e32 v18, v12                                     // 000000FA2E6C: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 000000FA2E70: 7E20030C
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000FA2E74: 848E820A
	s_mul_i32 s17, s10, 6                                      // 000000FA2E78: 9611860A
	s_mov_b32 s16, 0                                           // 000000FA2E7C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000FA2E80: 8484810A
	s_branch 469                                               // 000000FA2E84: BFA001D5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x9dc>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000FA2E88: 8C7E0A7E
	v_and_b32_e32 v27, 0xff, v4                                // 000000FA2E8C: 363608FF 000000FF
	s_and_b32 s0, exec_lo, s0                                  // 000000FA2E94: 8B00007E
	v_add_nc_u32_e32 v23, 0x100, v23                           // 000000FA2E98: 4A2E2EFF 00000100
	s_or_b32 s16, s0, s16                                      // 000000FA2EA0: 8C101000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FA2EA4: BF8700B2
	v_lshlrev_b32_e32 v27, 2, v27                              // 000000FA2EA8: 30363682
	ds_load_b32 v43, v27                                       // 000000FA2EAC: D8D80000 2B00001B
	v_lshrrev_b32_e32 v27, 6, v4                               // 000000FA2EB4: 32360886
	v_and_b32_e32 v27, 0x3fc, v27                              // 000000FA2EB8: 363636FF 000003FC
	ds_load_b32 v44, v27                                       // 000000FA2EC0: D8D80000 2C00001B
	v_lshrrev_b32_e32 v27, 14, v4                              // 000000FA2EC8: 3236088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000FA2ECC: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FA2ED0: BF870112
	v_and_b32_e32 v27, 0x3fc, v27                              // 000000FA2ED4: 363636FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FA2EDC: 360808FF 000003FC
	ds_load_b32 v45, v27                                       // 000000FA2EE4: D8D80000 2D00001B
	ds_load_b32 v46, v4                                        // 000000FA2EEC: D8D80000 2E000004
	v_and_b32_e32 v4, 0xff, v5                                 // 000000FA2EF4: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FA2EFC: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000FA2F00: 30080882
	ds_load_b32 v47, v4                                        // 000000FA2F04: D8D80000 2F000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 000000FA2F0C: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FA2F10: 360808FF 000003FC
	ds_load_b32 v48, v4                                        // 000000FA2F18: D8D80000 30000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 000000FA2F20: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FA2F24: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FA2F28: 360808FF 000003FC
	ds_load_b32 v49, v4                                        // 000000FA2F30: D8D80000 31000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 000000FA2F38: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FA2F3C: 360808FF 000003FC
	ds_load_b32 v50, v4                                        // 000000FA2F44: D8D80000 32000004
	v_and_b32_e32 v4, 0xff, v6                                 // 000000FA2F4C: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FA2F54: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000FA2F58: 30080882
	ds_load_b32 v51, v4                                        // 000000FA2F5C: D8D80000 33000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 000000FA2F64: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FA2F68: 360808FF 000003FC
	ds_load_b32 v52, v4                                        // 000000FA2F70: D8D80000 34000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 000000FA2F78: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FA2F7C: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FA2F80: 360808FF 000003FC
	ds_load_b32 v53, v4                                        // 000000FA2F88: D8D80000 35000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 000000FA2F90: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FA2F94: 360808FF 000003FC
	ds_load_b32 v54, v4                                        // 000000FA2F9C: D8D80000 36000004
	v_and_b32_e32 v4, 0xff, v7                                 // 000000FA2FA4: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FA2FAC: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000FA2FB0: 30080882
	ds_load_b32 v55, v4                                        // 000000FA2FB4: D8D80000 37000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 000000FA2FBC: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FA2FC0: 360808FF 000003FC
	ds_load_b32 v56, v4                                        // 000000FA2FC8: D8D80000 38000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 000000FA2FD0: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FA2FD4: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FA2FD8: 360808FF 000003FC
	ds_load_b32 v57, v4                                        // 000000FA2FE0: D8D80000 39000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 000000FA2FE8: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FA2FEC: 360808FF 000003FC
	ds_load_b32 v58, v4                                        // 000000FA2FF4: D8D80000 3A000004
	.long 0xd73c0004                                           // 000000FA2FFC: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000FA3000: 02021681
	v_add_nc_u32_e32 v11, 0x200, v11                           // 000000FA3004: 4A1616FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA300C: BF870092
	.long 0xd7000027                                           // 000000FA3010: D7000027
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000FA3014: 02020806
	v_add_co_ci_u32_e64 v40, null, s7, v5, s0                  // 000000FA3018: D5207C28 00020A07
	s_clause 0x3                                               // 000000FA3020: BF850003
	global_load_b128 v[4:7], v[39:40], off                     // 000000FA3024: DC5E0000 047C0027
	global_load_b128 v[27:30], v[39:40], off offset:16         // 000000FA302C: DC5E0010 1B7C0027
	global_load_b128 v[31:34], v[39:40], off offset:32         // 000000FA3034: DC5E0020 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:48         // 000000FA303C: DC5E0030 237C0027
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000FA3044: BF890CF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000FA3048: CC1A4004 1A025704
	s_waitcnt lgkmcnt(14)                                      // 000000FA3050: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA3054: BF8700A1
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 000000FA3058: CC1A4004 1C125905
	s_waitcnt lgkmcnt(13)                                      // 000000FA3060: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000FA3064: CC1A4004 1C125B06
	s_waitcnt lgkmcnt(12)                                      // 000000FA306C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA3070: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 000000FA3074: CC1A4004 1C125D07
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000FA307C: BF8908B7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000FA3080: CC1A4004 1C125F1B
	s_waitcnt lgkmcnt(10)                                      // 000000FA3088: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA308C: BF8700A1
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000FA3090: CC1A4004 1C12611C
	s_waitcnt lgkmcnt(9)                                       // 000000FA3098: BF89FC97
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FA309C: CC1A4004 1C12631D
	s_waitcnt lgkmcnt(8)                                       // 000000FA30A4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA30A8: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FA30AC: CC1A4004 1C12651E
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000FA30B4: BF890477
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FA30B8: CC1A4004 1C12671F
	s_waitcnt lgkmcnt(6)                                       // 000000FA30C0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA30C4: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FA30C8: CC1A4004 1C126920
	s_waitcnt lgkmcnt(5)                                       // 000000FA30D0: BF89FC57
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FA30D4: CC1A4004 1C126B21
	s_waitcnt lgkmcnt(4)                                       // 000000FA30DC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA30E0: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FA30E4: CC1A4004 1C126D22
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000FA30EC: BF890037
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FA30F0: CC1A4004 1C126F23
	.long 0xd7000023                                           // 000000FA30F8: D7000023
	v_cndmask_b32_e32 v0, v39, v4, vcc_lo                      // 000000FA30FC: 02000927
	s_waitcnt lgkmcnt(2)                                       // 000000FA3100: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000FA3104: BF8701C2
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FA3108: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v36, null, s5, v40, s0                 // 000000FA3110: D5207C24 00025005
	.long 0xd7000029                                           // 000000FA3118: D7000029
	v_cndmask_b32_e32 v0, v39, v14, vcc_lo                     // 000000FA311C: 02001D27
	s_waitcnt lgkmcnt(1)                                       // 000000FA3120: BF89FC17
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FA3124: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v42, null, s15, v40, s0                // 000000FA312C: D5207C2A 0002500F
	.long 0xd7000027                                           // 000000FA3134: D7000027
	v_cndmask_b32_e32 v0, v39, v17, vcc_lo                     // 000000FA3138: 02002327
	s_waitcnt lgkmcnt(0)                                       // 000000FA313C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FA3140: BF870123
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FA3144: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v40, null, s18, v40, s0                // 000000FA314C: D5207C28 00025012
	v_fmac_f32_e32 v22, v26, v4                                // 000000FA3154: 562C091A
	s_clause 0x3                                               // 000000FA3158: BF850003
	global_load_b128 v[4:7], v[35:36], off                     // 000000FA315C: DC5E0000 047C0023
	global_load_b128 v[27:30], v[35:36], off offset:16         // 000000FA3164: DC5E0010 1B7C0023
	global_load_b128 v[31:34], v[35:36], off offset:32         // 000000FA316C: DC5E0020 1F7C0023
	global_load_b128 v[35:38], v[35:36], off offset:48         // 000000FA3174: DC5E0030 237C0023
	s_waitcnt vmcnt(3)                                         // 000000FA317C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000FA3180: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA3188: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 000000FA318C: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000FA3194: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA319C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 000000FA31A0: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 000000FA31A8: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000FA31AC: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA31B4: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000FA31B8: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FA31C0: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA31C8: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FA31CC: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 000000FA31D4: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FA31D8: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA31E0: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FA31E4: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FA31EC: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA31F4: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FA31F8: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 000000FA3200: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FA3204: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA320C: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FA3210: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FA3218: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA3220: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FA3224: CC1A4004 1C127526
	v_fmac_f32_e32 v21, v26, v4                                // 000000FA322C: 562A091A
	s_clause 0x3                                               // 000000FA3230: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 000000FA3234: DC5E0000 047C0029
	global_load_b128 v[27:30], v[41:42], off offset:16         // 000000FA323C: DC5E0010 1B7C0029
	global_load_b128 v[31:34], v[41:42], off offset:32         // 000000FA3244: DC5E0020 1F7C0029
	global_load_b128 v[35:38], v[41:42], off offset:48         // 000000FA324C: DC5E0030 237C0029
	s_waitcnt vmcnt(3)                                         // 000000FA3254: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000FA3258: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA3260: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 000000FA3264: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000FA326C: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA3274: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 000000FA3278: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 000000FA3280: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000FA3284: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA328C: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000FA3290: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FA3298: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA32A0: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FA32A4: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 000000FA32AC: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FA32B0: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA32B8: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FA32BC: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FA32C4: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA32CC: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FA32D0: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 000000FA32D8: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FA32DC: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA32E4: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FA32E8: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FA32F0: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA32F8: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FA32FC: CC1A4004 1C127526
	v_fmac_f32_e32 v20, v26, v4                                // 000000FA3304: 5628091A
	s_clause 0x3                                               // 000000FA3308: BF850003
	global_load_b128 v[4:7], v[39:40], off                     // 000000FA330C: DC5E0000 047C0027
	global_load_b128 v[27:30], v[39:40], off offset:16         // 000000FA3314: DC5E0010 1B7C0027
	global_load_b128 v[31:34], v[39:40], off offset:32         // 000000FA331C: DC5E0020 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:48         // 000000FA3324: DC5E0030 237C0027
	s_waitcnt vmcnt(3)                                         // 000000FA332C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000FA3330: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA3338: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 000000FA333C: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000FA3344: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA334C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 000000FA3350: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 000000FA3358: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000FA335C: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA3364: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000FA3368: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FA3370: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA3378: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FA337C: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 000000FA3384: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FA3388: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA3390: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FA3394: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FA339C: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA33A4: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FA33A8: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 000000FA33B0: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FA33B4: CC1A4004 1C126F23
	.long 0xd7000023                                           // 000000FA33BC: D7000023
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 000000FA33C0: 02001D29
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FA33C4: BF870122
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FA33C8: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v36, null, s15, v42, s0                // 000000FA33D0: D5207C24 0002540F
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FA33D8: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA33E0: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FA33E4: CC1A4004 1C127526
	v_fmac_f32_e32 v19, v26, v4                                // 000000FA33EC: 5626091A
	s_clause 0x3                                               // 000000FA33F0: BF850003
	global_load_b128 v[4:7], v[35:36], off                     // 000000FA33F4: DC5E0000 047C0023
	global_load_b128 v[27:30], v[35:36], off offset:16         // 000000FA33FC: DC5E0010 1B7C0023
	global_load_b128 v[31:34], v[35:36], off offset:32         // 000000FA3404: DC5E0020 1F7C0023
	global_load_b128 v[35:38], v[35:36], off offset:48         // 000000FA340C: DC5E0030 237C0023
	s_waitcnt vmcnt(3)                                         // 000000FA3414: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000FA3418: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA3420: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 000000FA3424: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000FA342C: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA3434: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 000000FA3438: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 000000FA3440: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000FA3444: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA344C: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000FA3450: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FA3458: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA3460: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FA3464: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 000000FA346C: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FA3470: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA3478: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FA347C: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FA3484: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA348C: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FA3490: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 000000FA3498: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FA349C: CC1A4004 1C126F23
	.long 0xd7000023                                           // 000000FA34A4: D7000023
	v_cndmask_b32_e32 v0, v39, v14, vcc_lo                     // 000000FA34A8: 02001D27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000FA34AC: BF8701B2
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FA34B0: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v36, null, s15, v40, s0                // 000000FA34B8: D5207C24 0002500F
	.long 0xd700000d                                           // 000000FA34C0: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 000000FA34C4: 0201410D
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FA34C8: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 000000FA34D0: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA34D8: BF870092
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FA34DC: CC1A4004 1C127526
	v_fmac_f32_e32 v18, v26, v4                                // 000000FA34E4: 5624091A
	s_clause 0x3                                               // 000000FA34E8: BF850003
	global_load_b128 v[4:7], v[35:36], off                     // 000000FA34EC: DC5E0000 047C0023
	global_load_b128 v[27:30], v[35:36], off offset:16         // 000000FA34F4: DC5E0010 1B7C0023
	global_load_b128 v[31:34], v[35:36], off offset:32         // 000000FA34FC: DC5E0020 1F7C0023
	global_load_b128 v[35:38], v[35:36], off offset:48         // 000000FA3504: DC5E0030 237C0023
	s_waitcnt vmcnt(3)                                         // 000000FA350C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000FA3510: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FA3518: BF870121
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 000000FA351C: CC1A4004 1C125905
	v_mov_b32_e32 v5, v1                                       // 000000FA3524: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000FA3528: CC1A4004 1C125B06
	v_mov_b32_e32 v6, v2                                       // 000000FA3530: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000FA3534: BF870132
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 000000FA3538: CC1A4004 1C125D07
	v_mov_b32_e32 v7, v3                                       // 000000FA3540: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 000000FA3544: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000FA3548: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA3550: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000FA3554: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FA355C: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA3564: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FA3568: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 000000FA3570: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FA3574: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA357C: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FA3580: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FA3588: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA3590: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FA3594: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 000000FA359C: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FA35A0: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA35A8: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FA35AC: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FA35B4: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA35BC: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FA35C0: CC1A4004 1C127526
	v_fmac_f32_e32 v16, v26, v4                                // 000000FA35C8: 5620091A
	v_mov_b32_e32 v4, v0                                       // 000000FA35CC: 7E080300
	v_mov_b32_e32 v26, v25                                     // 000000FA35D0: 7E340319
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000FA35D4: 917E107E
	s_cbranch_execz 25                                         // 000000FA35D8: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xa40>
	s_waitcnt vmcnt(0)                                         // 000000FA35DC: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v24, 16, v24    // 000000FA35E0: CA200105 01183090
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v3, v7             // 000000FA35E8: CA100104 00020107
	v_mov_b32_e32 v2, v6                                       // 000000FA35F0: 7E040306
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FA35F4: BF870003
	.long 0xd4430000                                           // 000000FA35F8: D4430000
	v_cndmask_b32_e32 v1, s2, v24, vcc_lo                      // 000000FA35FC: 02023002
	s_mov_b32 s10, exec_lo                                     // 000000FA3600: BE8A007E
	.long 0xd4c4007e                                           // 000000FA3604: D4C4007E
	v_cndmask_b32_e32 v1, s2, v24, vcc_lo                      // 000000FA3608: 02023002
	s_cbranch_execz 65054                                      // 000000FA360C: BFA5FE1E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x288>
	.long 0xd7000100                                           // 000000FA3610: D7000100
	v_cndmask_b32_e32 v1, v10, v23, vcc_lo                     // 000000FA3614: 02022F0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FA3618: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s1                   // 000000FA361C: D5207C01 00062280
	global_load_d16_b16 v25, v[13:14], off                     // 000000FA3624: DC820000 197C000D
	global_load_b128 v[0:3], v[0:1], off                       // 000000FA362C: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 000000FA3634: BF8907F7
	v_cvt_f32_f16_e32 v25, v25                                 // 000000FA3638: 7E321719
	s_branch 65042                                             // 000000FA363C: BFA0FE12 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x288>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000FA3640: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA3644: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000FA3648: 8C7E037E
	.long 0xd71f0000                                           // 000000FA364C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000FA3650: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000FA3654: 3A020088
	s_waitcnt vmcnt(0)                                         // 000000FA3658: BF8903F7
	v_xor_b32_e32 v7, 4, v0                                    // 000000FA365C: 3A0E0084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA3660: BF870092
	.long 0xd44c0000                                           // 000000FA3664: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000FA3668: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000FA366C: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FA3674: BF870113
	.long 0xd44c0000                                           // 000000FA3678: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 000000FA367C: 02020EA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000FA3680: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FA3684: BF870002
	v_cndmask_b32_e64 v7, v0, v7, s0                           // 000000FA3688: D5010007 00020F00
	ds_bpermute_b32 v2, v1, v22                                // 000000FA3690: DACC0000 02001601
	s_waitcnt lgkmcnt(0)                                       // 000000FA3698: BF89FC07
	v_add_f32_e32 v2, v22, v2                                  // 000000FA369C: 06040516
	ds_bpermute_b32 v3, v1, v21                                // 000000FA36A0: DACC0000 03001501
	ds_bpermute_b32 v4, v1, v20                                // 000000FA36A8: DACC0000 04001401
	ds_bpermute_b32 v6, v1, v18                                // 000000FA36B0: DACC0000 06001201
	ds_bpermute_b32 v5, v1, v19                                // 000000FA36B8: DACC0000 05001301
	ds_bpermute_b32 v1, v1, v16                                // 000000FA36C0: DACC0000 01001001
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000FA36C8: 300E0E82
	s_waitcnt lgkmcnt(3)                                       // 000000FA36CC: BF89FC37
	v_dual_add_f32 v3, v21, v3 :: v_dual_add_f32 v4, v20, v4   // 000000FA36D0: C9080715 03040914
	s_waitcnt lgkmcnt(2)                                       // 000000FA36D8: BF89FC27
	v_add_f32_e32 v6, v18, v6                                  // 000000FA36DC: 060C0D12
	ds_bpermute_b32 v10, v7, v2                                // 000000FA36E0: DACC0000 0A000207
	s_waitcnt lgkmcnt(1)                                       // 000000FA36E8: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 000000FA36EC: 06020310
	ds_bpermute_b32 v11, v7, v3                                // 000000FA36F0: DACC0000 0B000307
	ds_bpermute_b32 v12, v7, v4                                // 000000FA36F8: DACC0000 0C000407
	v_xor_b32_e32 v16, 2, v0                                   // 000000FA3700: 3A200082
	ds_bpermute_b32 v14, v7, v6                                // 000000FA3704: DACC0000 0E000607
	.long 0xd44c0000                                           // 000000FA370C: D44C0000
	v_cndmask_b32_e32 v1, 32, v16, vcc_lo                      // 000000FA3710: 020220A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA3714: BF870091
	v_cndmask_b32_e64 v16, v0, v16, s0                         // 000000FA3718: D5010010 00022100
	v_dual_add_f32 v5, v19, v5 :: v_dual_lshlrev_b32 v16, 2, v16// 000000FA3720: C9220B13 05102082
	ds_bpermute_b32 v13, v7, v5                                // 000000FA3728: DACC0000 0D000507
	s_waitcnt lgkmcnt(4)                                       // 000000FA3730: BF89FC47
	v_add_f32_e32 v2, v2, v10                                  // 000000FA3734: 06041502
	ds_bpermute_b32 v7, v7, v1                                 // 000000FA3738: DACC0000 07000107
	s_waitcnt lgkmcnt(3)                                       // 000000FA3740: BF89FC37
	v_dual_add_f32 v3, v3, v11 :: v_dual_add_f32 v4, v4, v12   // 000000FA3744: C9081703 03041904
	s_waitcnt lgkmcnt(2)                                       // 000000FA374C: BF89FC27
	v_add_f32_e32 v11, v6, v14                                 // 000000FA3750: 06161D06
	v_xor_b32_e32 v6, 1, v0                                    // 000000FA3754: 3A0C0081
	ds_bpermute_b32 v10, v16, v4                               // 000000FA3758: DACC0000 0A000410
	.long 0xd44c0000                                           // 000000FA3760: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 000000FA3764: 02020CA0
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FA3768: BF870001
	v_cndmask_b32_e64 v0, v0, v6, s0                           // 000000FA376C: D5010000 00020D00
	.long 0xd44a0000                                           // 000000FA3774: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000FA3778: 02021E80
	s_waitcnt lgkmcnt(2)                                       // 000000FA377C: BF89FC27
	v_add_f32_e32 v5, v5, v13                                  // 000000FA3780: 060A1B05
	s_waitcnt lgkmcnt(1)                                       // 000000FA3784: BF89FC17
	v_add_f32_e32 v12, v1, v7                                  // 000000FA3788: 06180F01
	ds_bpermute_b32 v1, v16, v2                                // 000000FA378C: DACC0000 01000210
	ds_bpermute_b32 v7, v16, v3                                // 000000FA3794: DACC0000 07000310
	ds_bpermute_b32 v14, v16, v11                              // 000000FA379C: DACC0000 0E000B10
	v_lshlrev_b32_e32 v17, 2, v0                               // 000000FA37A4: 30220082
	s_and_b32 s0, s0, vcc_lo                                   // 000000FA37A8: 8B006A00
	s_waitcnt lgkmcnt(3)                                       // 000000FA37AC: BF89FC37
	v_add_f32_e32 v10, v4, v10                                 // 000000FA37B0: 06141504
	ds_bpermute_b32 v13, v16, v5                               // 000000FA37B4: DACC0000 0D000510
	ds_bpermute_b32 v16, v16, v12                              // 000000FA37BC: DACC0000 10000C10
	s_waitcnt lgkmcnt(3)                                       // 000000FA37C4: BF89FC37
	v_dual_add_f32 v6, v2, v1 :: v_dual_add_f32 v7, v3, v7     // 000000FA37C8: C9080302 06060F03
	s_waitcnt lgkmcnt(2)                                       // 000000FA37D0: BF89FC27
	v_add_f32_e32 v0, v11, v14                                 // 000000FA37D4: 06001D0B
	ds_bpermute_b32 v11, v17, v6                               // 000000FA37D8: DACC0000 0B000611
	s_waitcnt lgkmcnt(1)                                       // 000000FA37E0: BF89FC17
	v_dual_add_f32 v1, v5, v13 :: v_dual_add_f32 v2, v12, v16  // 000000FA37E4: C9081B05 0102210C
	ds_bpermute_b32 v12, v17, v7                               // 000000FA37EC: DACC0000 0C000711
	ds_bpermute_b32 v13, v17, v10                              // 000000FA37F4: DACC0000 0D000A11
	ds_bpermute_b32 v3, v17, v0                                // 000000FA37FC: DACC0000 03000011
	ds_bpermute_b32 v4, v17, v1                                // 000000FA3804: DACC0000 04000111
	ds_bpermute_b32 v5, v17, v2                                // 000000FA380C: DACC0000 05000211
	s_and_saveexec_b32 s1, s0                                  // 000000FA3814: BE812000
	s_cbranch_execz 208                                        // 000000FA3818: BFA500D0 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xf5c>
	s_waitcnt lgkmcnt(4)                                       // 000000FA381C: BF89FC47
	v_dual_add_f32 v6, v6, v11 :: v_dual_add_f32 v7, v7, v12   // 000000FA3820: C9081706 06061907
	s_waitcnt lgkmcnt(3)                                       // 000000FA3828: BF89FC37
	v_add_f32_e32 v10, v10, v13                                // 000000FA382C: 06141B0A
	s_lshl_b64 s[2:3], s[12:13], 2                             // 000000FA3830: 8482820C
	s_lshl_b64 s[4:5], s[12:13], 3                             // 000000FA3834: 8484830C
	s_waitcnt lgkmcnt(2)                                       // 000000FA3838: BF89FC27
	v_dual_mul_f32 v6, 0xbfb8aa3b, v6 :: v_dual_add_f32 v3, v0, v3// 000000FA383C: C8C80CFF 06020700 BFB8AA3B
	s_waitcnt lgkmcnt(1)                                       // 000000FA3848: BF89FC17
	v_dual_add_f32 v4, v1, v4 :: v_dual_mul_f32 v7, 0xbfb8aa3b, v7// 000000FA384C: C9060901 04060EFF BFB8AA3B
	.long 0xd73c0000                                           // 000000FA3858: D73C0000
	v_cndmask_b32_e32 v1, 2, v8, vcc_lo                        // 000000FA385C: 02021082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FA3860: BF870113
	v_exp_f32_e32 v6, v6                                       // 000000FA3864: 7E0C4B06
	v_dual_mul_f32 v3, 0xbfb8aa3b, v3 :: v_dual_mul_f32 v4, 0xbfb8aa3b, v4// 000000FA3868: C8C606FF 030408FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FA3874: BF870123
	v_exp_f32_e32 v7, v7                                       // 000000FA3878: 7E0E4B07
	v_mul_f32_e32 v10, 0xbfb8aa3b, v10                         // 000000FA387C: 101414FF BFB8AA3B
	v_exp_f32_e32 v11, v3                                      // 000000FA3884: 7E164B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(TRANS32_DEP_3)// 000000FA3888: BF8703B2
	v_exp_f32_e32 v4, v4                                       // 000000FA388C: 7E084B04
	s_waitcnt lgkmcnt(0)                                       // 000000FA3890: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 000000FA3894: 06040B02
	v_dual_add_f32 v6, 1.0, v6 :: v_dual_add_f32 v7, 1.0, v7   // 000000FA3898: C9080CF2 06060EF2
	v_exp_f32_e32 v10, v10                                     // 000000FA38A0: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FA38A4: BF870117
	v_add_f32_e32 v11, 1.0, v11                                // 000000FA38A8: 061616F2
	v_div_scale_f32 v9, null, v6, v6, 1.0                      // 000000FA38AC: D6FC7C09 03CA0D06
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000FA38B4: BF870236
	v_add_f32_e32 v15, 1.0, v4                                 // 000000FA38B8: 061E08F2
	v_mul_f32_e32 v5, 0xbfb8aa3b, v2                           // 000000FA38BC: 100A04FF BFB8AA3B
	.long 0xd7006a02                                           // 000000FA38C4: D7006A02
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000FA38C8: 02020008
	v_rcp_f32_e32 v13, v9                                      // 000000FA38CC: 7E1A5509
	v_add_co_ci_u32_e64 v3, null, s9, v1, vcc_lo               // 000000FA38D0: D5207C03 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(TRANS32_DEP_2)// 000000FA38D8: BF870353
	v_exp_f32_e32 v1, v5                                       // 000000FA38DC: 7E024B05
	v_div_scale_f32 v16, vcc_lo, 1.0, v6, 1.0                  // 000000FA38E0: D6FC6A10 03CA0CF2
	v_div_scale_f32 v17, s0, 1.0, v7, 1.0                      // 000000FA38E8: D6FC0011 03CA0EF2
	v_div_scale_f32 v19, null, v15, v15, 1.0                   // 000000FA38F0: D6FC7C13 03CA1F0F
	v_div_scale_f32 v21, null, v11, v11, 1.0                   // 000000FA38F8: D6FC7C15 03CA170B
	v_fma_f32 v4, -v9, v13, 1.0                                // 000000FA3900: D6130004 23CA1B09
	v_add_f32_e32 v8, 1.0, v10                                 // 000000FA3908: 061014F2
	v_div_scale_f32 v10, null, v7, v7, 1.0                     // 000000FA390C: D6FC7C0A 03CA0F07
	v_rcp_f32_e32 v22, v19                                     // 000000FA3914: 7E2C5513
	v_rcp_f32_e32 v27, v21                                     // 000000FA3918: 7E365515
	v_fmac_f32_e32 v13, v4, v13                                // 000000FA391C: 561A1B04
	v_div_scale_f32 v12, null, v8, v8, 1.0                     // 000000FA3920: D6FC7C0C 03CA1108
	v_rcp_f32_e32 v14, v10                                     // 000000FA3928: 7E1C550A
	v_div_scale_f32 v18, s1, 1.0, v8, 1.0                      // 000000FA392C: D6FC0112 03CA10F2
	.long 0xd7000204                                           // 000000FA3934: D7000204
	v_cndmask_b32_e32 v0, v2, v2, vcc_lo                       // 000000FA3938: 02000502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 000000FA393C: BF870323
	v_rcp_f32_e32 v0, v12                                      // 000000FA3940: 7E00550C
	v_fma_f32 v28, -v19, v22, 1.0                              // 000000FA3944: D613001C 23CA2D13
	v_fma_f32 v5, -v10, v14, 1.0                               // 000000FA394C: D6130005 23CA1D0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FA3954: BF870115
	v_fma_f32 v20, -v12, v0, 1.0                               // 000000FA3958: D6130014 23CA010C
	v_fmac_f32_e32 v14, v5, v14                                // 000000FA3960: 561C1D05
	v_add_co_ci_u32_e64 v5, null, s3, v3, s2                   // 000000FA3964: D5207C05 000A0603
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA396C: BF8700A3
	v_fmac_f32_e32 v0, v20, v0                                 // 000000FA3970: 56000114
	v_mul_f32_e32 v20, v16, v13                                // 000000FA3974: 10281B10
	v_fma_f32 v25, -v9, v20, v16                               // 000000FA3978: D6130019 24422909
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000FA3980: BF8701B1
	v_fmac_f32_e32 v20, v25, v13                               // 000000FA3984: 56281B19
	v_add_f32_e32 v25, 1.0, v1                                 // 000000FA3988: 063202F2
	v_mul_f32_e32 v23, v17, v14                                // 000000FA398C: 102E1D11
	v_fma_f32 v1, -v9, v20, v16                                // 000000FA3990: D6130001 24422909
	v_fma_f32 v16, -v21, v27, 1.0                              // 000000FA3998: D6130010 23CA3715
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000FA39A0: BF870223
	v_fma_f32 v26, -v10, v23, v17                              // 000000FA39A4: D613001A 24462F0A
	v_mul_f32_e32 v24, v18, v0                                 // 000000FA39AC: 10300112
	v_div_fmas_f32 v1, v1, v13, v20                            // 000000FA39B0: D6370001 04521B01
	s_mov_b32 vcc_lo, s0                                       // 000000FA39B8: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FA39BC: BF870003
	v_fmac_f32_e32 v23, v26, v14                               // 000000FA39C0: 562E1D1A
	v_div_scale_f32 v13, s3, 1.0, v11, 1.0                     // 000000FA39C4: D6FC030D 03CA16F2
	v_fmac_f32_e32 v27, v16, v27                               // 000000FA39CC: 56363710
	v_fma_f32 v29, -v12, v24, v18                              // 000000FA39D0: D613001D 244A310C
	v_fmac_f32_e32 v22, v28, v22                               // 000000FA39D8: 562C2D1C
	v_fma_f32 v9, -v10, v23, v17                               // 000000FA39DC: D6130009 24462F0A
	v_div_scale_f32 v17, null, v25, v25, 1.0                   // 000000FA39E4: D6FC7C11 03CA3319
	v_div_scale_f32 v10, s2, 1.0, v15, 1.0                     // 000000FA39EC: D6FC020A 03CA1EF2
	v_fmac_f32_e32 v24, v29, v0                                // 000000FA39F4: 5630011D
	v_div_fixup_f32 v1, v1, v6, 1.0                            // 000000FA39F8: D6270001 03CA0D01
	v_div_fmas_f32 v9, v9, v14, v23                            // 000000FA3A00: D6370009 045E1D09
	v_rcp_f32_e32 v20, v17                                     // 000000FA3A08: 7E285511
	s_mov_b32 vcc_lo, s1                                       // 000000FA3A0C: BEEA0001
	v_fma_f32 v12, -v12, v24, v18                              // 000000FA3A10: D613000C 244A310C
	global_store_b32 v[2:3], v1, off                           // 000000FA3A18: DC6A0000 007C0102
	v_div_fixup_f32 v14, v9, v7, 1.0                           // 000000FA3A20: D627000E 03CA0F09
	v_dual_mul_f32 v7, v13, v27 :: v_dual_mul_f32 v6, v10, v22 // 000000FA3A28: C8C6370D 07062D0A
	v_div_fmas_f32 v0, v12, v0, v24                            // 000000FA3A30: D6370000 0462010C
	s_mov_b32 vcc_lo, s2                                       // 000000FA3A38: BEEA0002
	v_fma_f32 v9, -v17, v20, 1.0                               // 000000FA3A3C: D6130009 23CA2911
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FA3A44: BF870193
	v_fma_f32 v1, -v19, v6, v10                                // 000000FA3A48: D6130001 242A0D13
	v_div_fixup_f32 v12, v0, v8, 1.0                           // 000000FA3A50: D627000C 03CA1100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FA3A58: BF870193
	v_fmac_f32_e32 v20, v9, v20                                // 000000FA3A5C: 56282909
	v_fmac_f32_e32 v6, v1, v22                                 // 000000FA3A60: 560C2D01
	v_fma_f32 v1, -v21, v7, v13                                // 000000FA3A64: D6130001 24360F15
	v_div_scale_f32 v9, s0, 1.0, v25, 1.0                      // 000000FA3A6C: D6FC0009 03CA32F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FA3A74: BF870193
	v_fma_f32 v0, -v19, v6, v10                                // 000000FA3A78: D6130000 242A0D13
	v_fmac_f32_e32 v7, v1, v27                                 // 000000FA3A80: 560E3701
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FA3A84: BF870193
	v_mul_f32_e32 v8, v9, v20                                  // 000000FA3A88: 10102909
	v_div_fmas_f32 v10, v0, v22, v6                            // 000000FA3A8C: D637000A 041A2D00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FA3A94: BF870193
	v_fma_f32 v6, -v21, v7, v13                                // 000000FA3A98: D6130006 24360F15
	v_fma_f32 v13, -v17, v8, v9                                // 000000FA3AA0: D613000D 24261111
	v_mad_u64_u32 v[0:1], null, s12, 12, v[2:3]                // 000000FA3AA8: D6FE7C00 0409180C
	s_mov_b32 vcc_lo, s3                                       // 000000FA3AB0: BEEA0003
	v_div_fixup_f32 v10, v10, v15, 1.0                         // 000000FA3AB4: D627000A 03CA1F0A
	v_div_fmas_f32 v16, v6, v27, v7                            // 000000FA3ABC: D6370010 041E3706
	v_fmac_f32_e32 v8, v13, v20                                // 000000FA3AC4: 5610290D
	.long 0xd7006a06                                           // 000000FA3AC8: D7006A06
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 000000FA3ACC: 02000902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FA3AD0: BF870191
	v_add_co_ci_u32_e64 v7, null, s5, v3, vcc_lo               // 000000FA3AD4: D5207C07 01AA0605
	v_fma_f32 v3, -v17, v8, v9                                 // 000000FA3ADC: D6130003 24261111
	s_mov_b32 vcc_lo, s0                                       // 000000FA3AE4: BEEA0000
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 000000FA3AE8: D6FE7C01 0405180D
	v_div_fixup_f32 v11, v16, v11, 1.0                         // 000000FA3AF0: D627000B 03CA1710
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA3AF8: BF8700A3
	v_div_fmas_f32 v8, v3, v20, v8                             // 000000FA3AFC: D6370008 04222903
	.long 0xd7006a02                                           // 000000FA3B04: D7006A02
	v_cndmask_b32_e32 v0, v6, v4, vcc_lo                       // 000000FA3B08: 02000906
	v_add_co_ci_u32_e64 v3, null, s5, v7, vcc_lo               // 000000FA3B0C: D5207C03 01AA0E05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA3B14: BF8700A3
	v_div_fixup_f32 v13, v8, v25, 1.0                          // 000000FA3B18: D627000D 03CA3308
	.long 0xd7006a08                                           // 000000FA3B20: D7006A08
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000FA3B24: 02000900
	v_add_co_ci_u32_e64 v9, null, s5, v1, vcc_lo               // 000000FA3B28: D5207C09 01AA0205
	s_clause 0x4                                               // 000000FA3B30: BF850004
	global_store_b32 v[4:5], v14, off                          // 000000FA3B34: DC6A0000 007C0E04
	global_store_b32 v[6:7], v12, off                          // 000000FA3B3C: DC6A0000 007C0C06
	global_store_b32 v[0:1], v10, off                          // 000000FA3B44: DC6A0000 007C0A00
	global_store_b32 v[2:3], v11, off                          // 000000FA3B4C: DC6A0000 007C0B02
	global_store_b32 v[8:9], v13, off                          // 000000FA3B54: DC6A0000 007C0D08
	s_endpgm                                                   // 000000FA3B5C: BFB00000
		...

