0000000000457100 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x2                                               // 000000457100: BF850002
	s_load_b128 s[24:27], s[0:1], 0x10                         // 000000457104: F4080600 F8000010
	s_load_b256 s[12:19], s[0:1], 0x20                         // 00000045710C: F40C0300 F8000020
	s_load_b128 s[20:23], s[0:1], 0x40                         // 000000457114: F4080500 F8000040
	s_mov_b32 s4, s3                                           // 00000045711C: BE840003
	v_and_b32_e32 v13, 31, v0                                  // 000000457120: 361A009F
	v_lshrrev_b32_e32 v11, 5, v0                               // 000000457124: 32160085
	s_delay_alu instid0(VALU_DEP_2)                            // 000000457128: BF870002
	v_lshlrev_b32_e32 v8, 3, v13                               // 00000045712C: 30101A83
	s_waitcnt lgkmcnt(0)                                       // 000000457130: BF89FC07
	s_ashr_i32 s33, s25, 31                                    // 000000457134: 86219F19
	s_mul_i32 s34, s27, s4                                     // 000000457138: 9622041B
	s_lshr_b32 s3, s33, 25                                     // 00000045713C: 85039921
	s_add_i32 s5, s34, s27                                     // 000000457140: 81051B22
	s_add_i32 s3, s25, s3                                      // 000000457144: 81030319
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000457148: BF870499
	s_ashr_i32 s3, s3, 7                                       // 00000045714C: 86038703
	s_min_i32 s3, s3, s5                                       // 000000457150: 89030503
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000457154: BF8704B9
	s_sub_i32 s11, s3, s34                                     // 000000457158: 818B2203
	s_mov_b32 s3, exec_lo                                      // 00000045715C: BE83007E
	s_lshl_b32 s10, s11, 1                                     // 000000457160: 840A810B
	.long 0xd4c3007e                                           // 000000457164: D4C3007E
	v_cndmask_b32_e32 v1, s10, v11, vcc_lo                     // 000000457168: 0202160A
	s_xor_b32 s3, exec_lo, s3                                  // 00000045716C: 8D03037E
	v_lshlrev_b32_e32 v8, 3, v13                               // 000000457170: 30101A83
	s_or_saveexec_b32 s35, s3                                  // 000000457174: BEA32203
	s_clause 0x1                                               // 000000457178: BF850001
	s_load_b32 s27, s[0:1], 0x54                               // 00000045717C: F40006C0 F8000054
	s_load_b128 s[28:31], s[0:1], null                         // 000000457184: F4080700 F8000000
	v_lshlrev_b32_e32 v12, 2, v13                              // 00000045718C: 30181A82
	s_xor_b32 exec_lo, exec_lo, s35                            // 000000457190: 8D7E237E
	s_cbranch_execz 502                                        // 000000457194: BFA501F6 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x870>
	s_add_i32 s36, s24, -1                                     // 000000457198: 8124C118
	s_cmp_lg_u64 s[22:23], 0                                   // 00000045719C: BF118016
	v_and_b32_e32 v1, 1, v0                                    // 0000004571A0: 36020081
	s_cselect_b32 s37, -1, 0                                   // 0000004571A4: 982580C1
	s_abs_i32 s38, s11                                         // 0000004571A8: BEA6150B
	v_and_b32_e32 v3, 2, v0                                    // 0000004571AC: 36060082
	s_cvt_f32_u32 s0, s38                                      // 0000004571B0: BE806526
	v_dual_mov_b32 v9, v11 :: v_dual_and_b32 v4, 4, v0         // 0000004571B4: CA24010B 09040084
	v_and_b32_e32 v5, 8, v0                                    // 0000004571BC: 360A0088
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004571C0: BF870009
	v_rcp_iflag_f32_e32 v2, s0                                 // 0000004571C4: 7E045600
	v_lshl_or_b32 v6, v11, 8, v8                               // 0000004571C8: D6560006 0421110B
	v_add_nc_u32_e32 v7, s34, v11                              // 0000004571D0: 4A0E1622
	s_ashr_i32 s42, s11, 31                                    // 0000004571D4: 862A9F0B
	s_sub_i32 s9, 0, s38                                       // 0000004571D8: 81892680
	s_mul_i32 s44, s42, 0x1400                                 // 0000004571DC: 962CFF2A 00001400
	.long 0xd44c0000                                           // 0000004571E4: D44C0000
	v_cndmask_b32_e32 v1, 16, v13, vcc_lo                      // 0000004571E8: 02021A90
	.long 0xd44a0001                                           // 0000004571EC: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000004571F0: 02020280
	.long 0xd44a0005                                           // 0000004571F4: D44A0005
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 0000004571F8: 02020880
	.long 0xd44a0006                                           // 0000004571FC: D44A0006
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000457200: 02020A80
	v_readfirstlane_b32 s3, v2                                 // 000000457204: 7E060502
	v_lshl_or_b32 v1, v7, 7, v12                               // 000000457208: D6560001 04310F07
	v_subrev_nc_u32_e32 v10, s44, v6                           // 000000457210: 4E140C2C
	s_lshl_b32 s7, s11, 7                                      // 000000457214: 8407870B
	s_mov_b32 s39, s25                                         // 000000457218: BEA70019
	s_mul_f32 s8, s3, 0x4f7ffffe                               // 00000045721C: A208FF03 4F7FFFFE
	.long 0xd44a0003                                           // 000000457224: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000457228: 02020680
	s_mov_b32 s40, 0                                           // 00000045722C: BEA80080
	s_mov_b32 s41, 0x76543210                                  // 000000457230: BEA900FF 76543210
	s_cvt_u32_f32 s8, s8                                       // 000000457238: BE886708
	s_lshl_b32 s43, s11, 8                                     // 00000045723C: 842B880B
	s_sub_i32 s44, 0, s7                                       // 000000457240: 81AC0780
	s_mov_b32 s46, 0x3db504f3                                  // 000000457244: BEAE00FF 3DB504F3
	s_mul_i32 s9, s9, s8                                       // 00000045724C: 96090809
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000457250: BF870499
	s_mul_hi_u32 s9, s8, s9                                    // 000000457254: 96890908
	s_add_i32 s45, s8, s9                                      // 000000457258: 812D0908
	s_branch 160                                               // 00000045725C: BFA000A0 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3e0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000457260: BF870091
	.long 0xd7006a02                                           // 000000457264: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000457268: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 00000045726C: D5207C03 01AA060D
	v_sub_f32_e32 v4, v19, v17                                 // 000000457274: 08082313
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000457278: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000457280: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000457288: BF8903F7
	v_fma_mix_f32 v5, v18, v2, v16 op_sel_hi:[0,1,0]           // 00000045728C: CC200005 14420512
	v_fma_mix_f32 v2, -v18, v2, v16 op_sel_hi:[0,1,0]          // 000000457294: CC200002 34420512
	v_add_f32_e32 v3, v19, v17                                 // 00000045729C: 06062313
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004572A0: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 0000004572A4: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 0000004572A8: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 0000004572AC: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 0000004572B0: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004572B4: BF870193
	v_mov_b32_dpp v17, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004572B8: 7E2202FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004572C0: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000004572C8: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 0000004572D0: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000004572D8: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 0000004572DC: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004572E0: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000004572E8: D5010007 20060F07
	.long 0xd72c0006                                           // 0000004572F0: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v15, vcc_lo                  // 0000004572F4: 02021EFF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 0000004572FC: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000457300: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000457308: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 000000457310: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 000000457314: 06080F04
	v_mov_b32_dpp v16, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000457318: 7E2002FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000457320: D5010003 20060703
	v_add_f32_e32 v2, v2, v17                                  // 000000457328: 06042302
	.long 0xd72c0007                                           // 00000045732C: D72C0007
	v_cndmask_b32_e32 v1, s43, v14, vcc_lo                     // 000000457330: 02021C2B
	v_mov_b32_dpp v14, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000457334: 7E1C02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 00000045733C: D5010004 20160904
	v_add_f32_e32 v3, v3, v16                                  // 000000457344: 06062103
	v_mov_b32_dpp v17, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000457348: 7E2202FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000457350: D5010002 200E0502
	s_delay_alu instid0(VALU_DEP_4)                            // 000000457358: BF870004
	v_add_f32_e32 v4, v4, v14                                  // 00000045735C: 06081D04
	v_mov_b32_dpp v15, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000457360: 7E1E02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000457368: D5010005 200E0B05
	v_mov_b32_dpp v16, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000457370: 7E2002FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000457378: D5010003 200E0703
	v_add_f32_e32 v2, v2, v17                                  // 000000457380: 06042302
	v_mov_b32_dpp v14, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000457384: 7E1C02FA FF016804
	v_add_f32_e32 v5, v5, v15                                  // 00000045738C: 060A1F05
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 000000457390: D5010004 201A0904
	v_add_f32_e32 v3, v3, v16                                  // 000000457398: 06062103
	v_mov_b32_dpp v17, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000045739C: 7E2202FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 0000004573A4: D5010002 20160502
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004573AC: 7E1E02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 0000004573B4: D5010005 20160B05
	v_mov_b32_dpp v16, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004573BC: 7E2002FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 0000004573C4: D5010003 20160703
	v_add_f32_e32 v2, v2, v17                                  // 0000004573CC: 06042302
	v_dual_add_f32 v4, v4, v14 :: v_dual_add_nc_u32 v9, 8, v9  // 0000004573D0: C9201D04 04081288
	v_add_f32_e32 v5, v5, v15                                  // 0000004573D8: 060A1F05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004573DC: BF870214
	v_add_f32_e32 v3, v3, v16                                  // 0000004573E0: 06062103
	v_mov_b32_dpp v17, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004573E4: 7E2202FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 0000004573EC: D5010002 201A0502
	v_mov_b32_e32 v14, v4                                      // 0000004573F4: 7E1C0304
	v_mov_b32_dpp v15, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004573F8: 7E1E02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 000000457400: D5010005 201A0B05
	v_mov_b32_dpp v16, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000457408: 7E2002FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000457410: D5010003 201A0703
	v_add_f32_e32 v2, v2, v17                                  // 000000457418: 06042302
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 00000045741C: D5010004 20020904
	v_add_f32_e32 v5, v5, v15                                  // 000000457424: 060A1F05
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 000000457428: D65C000E 03FC530E FEDCBA98
	v_add_f32_e32 v3, v3, v16                                  // 000000457434: 06062103
	v_mov_b32_e32 v17, v2                                      // 000000457438: 7E220302
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 00000045743C: D5010002 20020502
	v_mov_b32_e32 v15, v5                                      // 000000457444: 7E1E0305
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000457448: D5010005 20020B05
	v_mov_b32_e32 v16, v3                                      // 000000457450: 7E200303
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000457454: D5010003 20020703
	v_add_f32_e32 v4, v4, v14                                  // 00000045745C: 06081D04
	v_permlanex16_b32 v15, v15, s41, 0xfedcba98                // 000000457460: D65C000F 03FC530F FEDCBA98
	v_permlanex16_b32 v17, v17, s41, 0xfedcba98                // 00000045746C: D65C0011 03FC5311 FEDCBA98
	v_permlanex16_b32 v16, v16, s41, 0xfedcba98                // 000000457478: D65C0010 03FC5310 FEDCBA98
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000457484: 4C0C0F06
	v_cmp_le_i32_e32 vcc_lo, s10, v9                           // 000000457488: 7C86120A
	v_add_f32_e32 v5, v5, v15                                  // 00000045748C: 060A1F05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000457490: BF870214
	v_dual_add_f32 v7, v2, v17 :: v_dual_add_f32 v14, v3, v16  // 000000457494: C9082302 070E2103
	v_add_nc_u32_e32 v6, v10, v6                               // 00000045749C: 4A0C0D0A
	v_fma_mixlo_f16 v2, v4, s46, 0                             // 0000004574A0: CC210002 02005D04
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004574A8: BF870004
	v_fma_mixhi_f16 v2, v5, s46, 0                             // 0000004574AC: CC220002 02005D05
	v_add_nc_u32_e32 v10, 0x800, v10                           // 0000004574B4: 4A1414FF 00000800
	v_fma_mixhi_f16 v3, v7, s46, 0                             // 0000004574BC: CC220003 02005D07
	v_fma_mixlo_f16 v3, v14, s46, 0                            // 0000004574C4: CC210003 02005D0E
	s_or_b32 s40, vcc_lo, s40                                  // 0000004574CC: 8C28286A
	ds_store_b64 v6, v[2:3]                                    // 0000004574D0: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 0000004574D8: 917E287E
	s_cbranch_execz 291                                        // 0000004574DC: BFA50123 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x86c>
	.long 0xd72d0002                                           // 0000004574E0: D72D0002
	v_cndmask_b32_e32 v0, v9, v45, vcc_lo                      // 0000004574E4: 02005B09
	s_mov_b32 s7, -1                                           // 0000004574E8: BE8700C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004574EC: BF870091
	.long 0xd72c0003                                           // 0000004574F0: D72C0003
	v_cndmask_b32_e32 v0, v2, v38, vcc_lo                      // 0000004574F4: 02004D02
	v_sub_nc_u32_e32 v3, v9, v3                                // 0000004574F8: 4C060709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004574FC: BF870121
	v_subrev_nc_u32_e32 v5, s38, v3                            // 000000457500: 4E0A0626
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000457504: 7C960626
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000457508: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000457510: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000457514: 02040902
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000457518: 7C960626
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000045751C: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000457520: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000457524: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s37                        // 000000457528: 916A257E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000045752C: BF870091
	v_xor_b32_e32 v15, s42, v2                                 // 000000457530: 3A1E042A
	v_subrev_nc_u32_e32 v14, s42, v15                          // 000000457534: 4E1C1E2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000457538: BF8700A1
	v_mad_u64_u32 v[6:7], null, s44, v14, v[1:2]               // 00000045753C: D6FE7C06 04061C2C
	v_min_i32_e32 v2, s36, v14                                 // 000000457544: 22041C24
	v_mad_i64_i32 v[4:5], null, v2, s39, 0                     // 000000457548: D6FF7C04 02004F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000457550: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000457554: 340E0C9F
	.long 0xd73c0002                                           // 000000457558: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000045755C: 02020C81
	s_cbranch_vccnz 213                                        // 000000457560: BFA400D5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7b8>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000457564: BF870093
	.long 0xd7006a06                                           // 000000457568: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 00000045756C: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000457570: D5207C07 01AA0F05
	.long 0x7f403880                                           // 000000457578: 7F403880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000045757C: BF870112
	.long 0xd73c0006                                           // 000000457580: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000457584: 02020C81
	.long 0x7f4639a0                                           // 000000457588: 7F4639A0
	s_waitcnt lgkmcnt(0)                                       // 00000045758C: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000457590: BF870092
	.long 0xd7006a10                                           // 000000457594: D7006A10
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000457598: 02020C1E
	v_add_co_ci_u32_e64 v17, null, s31, v7, vcc_lo             // 00000045759C: D5207C11 01AA0E1F
	.long 0xd7006a06                                           // 0000004575A4: D7006A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 0000004575A8: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004575AC: BF870001
	v_add_co_ci_u32_e64 v7, null, s23, v7, vcc_lo              // 0000004575B0: D5207C07 01AA0E17
	global_load_b64 v[16:17], v[16:17], off                    // 0000004575B8: DC560000 107C0010
	.long 0xd7006a12                                           // 0000004575C0: D7006A12
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000004575C4: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 0000004575C8: DC560000 067C0006
	v_add_co_ci_u32_e64 v19, null, s13, v3, vcc_lo             // 0000004575D0: D5207C13 01AA060D
	s_clause 0x1                                               // 0000004575D8: BF850001
	global_load_b32 v20, v[18:19], off                         // 0000004575DC: DC520000 147C0012
	global_load_d16_b16 v18, v[18:19], off offset:4            // 0000004575E4: DC820004 127C0012
	s_waitcnt vmcnt(3)                                         // 0000004575EC: BF890FF7
	.long 0x7e263910                                           // 0000004575F0: 7E263910
	s_waitcnt vmcnt(2)                                         // 0000004575F4: BF890BF7
	v_and_b32_e32 v42, 0xffff0000, v6                          // 0000004575F8: 36540CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000457600: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000457604: BF870093
	v_lshlrev_b32_e32 v19, 16, v19                             // 000000457608: 30262690
	v_mul_f32_e32 v23, 0xbfb8aa3b, v19                         // 00000045760C: 102E26FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000457614: BF870291
	v_exp_f32_e32 v23, v23                                     // 000000457618: 7E2E4B17
	v_dual_add_f32 v23, 1.0, v23 :: v_dual_and_b32 v16, 0xffff0000, v16// 00000045761C: C9242EF2 171020FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000457628: BF870111
	v_mul_f32_e32 v22, 0xbfb8aa3b, v16                         // 00000045762C: 102C20FF BFB8AA3B
	v_div_scale_f32 v27, null, v23, v23, v19                   // 000000457634: D6FC7C1B 044E2F17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000045763C: BF8701B2
	v_exp_f32_e32 v22, v22                                     // 000000457640: 7E2C4B16
	v_lshlrev_b32_e32 v21, 16, v17                             // 000000457644: 302A2290
	v_div_scale_f32 v40, s8, v19, v23, v19                     // 000000457648: D6FC0828 044E2F13
	v_rcp_f32_e32 v31, v27                                     // 000000457650: 7E3E551B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000457654: BF870196
	v_add_f32_e32 v22, 1.0, v22                                // 000000457658: 062C2CF2
	v_mul_f32_e32 v24, 0xbfb8aa3b, v21                         // 00000045765C: 10302AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000457664: BF870195
	v_fma_f32 v39, -v27, v31, 1.0                              // 000000457668: D6130027 23CA3F1B
	v_div_scale_f32 v26, null, v22, v22, v16                   // 000000457670: D6FC7C1A 04422D16
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000457678: BF8701B3
	v_exp_f32_e32 v24, v24                                     // 00000045767C: 7E304B18
	v_and_b32_e32 v17, 0xffff0000, v17                         // 000000457680: 362222FF FFFF0000
	v_div_scale_f32 v36, vcc_lo, v16, v22, v16                 // 000000457688: D6FC6A24 04422D10
	v_rcp_f32_e32 v29, v26                                     // 000000457690: 7E3A551A
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 000000457694: BF870106
	v_dual_add_f32 v24, 1.0, v24 :: v_dual_mul_f32 v25, 0xbfb8aa3b, v17// 000000457698: C90630F2 181822FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004576A4: BF870115
	v_fma_f32 v37, -v26, v29, 1.0                              // 0000004576A8: D6130025 23CA3B1A
	v_div_scale_f32 v28, null, v24, v24, v21                   // 0000004576B0: D6FC7C1C 04563118
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004576B8: BF8701A3
	v_exp_f32_e32 v25, v25                                     // 0000004576BC: 7E324B19
	v_div_scale_f32 v38, s7, v21, v24, v21                     // 0000004576C0: D6FC0726 04563115
	v_fmac_f32_e32 v29, v37, v29                               // 0000004576C8: 563A3B25
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000004576CC: BF870313
	v_rcp_f32_e32 v33, v28                                     // 0000004576D0: 7E42551C
	v_add_f32_e32 v25, 1.0, v25                                // 0000004576D4: 063232F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004576D8: BF870115
	v_fma_f32 v41, -v28, v33, 1.0                              // 0000004576DC: D6130029 23CA431C
	v_div_scale_f32 v30, null, v25, v25, v17                   // 0000004576E4: D6FC7C1E 04463319
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004576EC: BF8701A2
	v_fmac_f32_e32 v33, v41, v33                               // 0000004576F0: 56424329
	v_mul_f32_e32 v41, v36, v29                                // 0000004576F4: 10523B24
	v_rcp_f32_e32 v34, v30                                     // 0000004576F8: 7E44551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004576FC: BF870091
	v_fma_f32 v44, -v26, v41, v36                              // 000000457700: D613002C 2492531A
	v_fmac_f32_e32 v41, v44, v29                               // 000000457708: 56523B2C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000045770C: BF870115
	v_fma_f32 v37, -v30, v34, 1.0                              // 000000457710: D6130025 23CA451E
	v_fma_f32 v26, -v26, v41, v36                              // 000000457718: D613001A 2492531A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000457720: BF870112
	v_fmac_f32_e32 v34, v37, v34                               // 000000457724: 56444525
	v_div_fmas_f32 v26, v26, v29, v41                          // 000000457728: D637001A 04A63B1A
	s_mov_b32 vcc_lo, s8                                       // 000000457730: BEEA0008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000457734: BF8701B1
	v_div_fixup_f32 v16, v26, v22, v16                         // 000000457738: D6270010 04422D1A
	v_fmac_f32_e32 v31, v39, v31                               // 000000457740: 563E3F27
	v_div_scale_f32 v39, s9, v17, v25, v17                     // 000000457744: D6FC0927 04463311
	v_mul_f32_e32 v16, v16, v42                                // 00000045774C: 10205510
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000457750: BF870193
	v_mul_f32_e32 v37, v40, v31                                // 000000457754: 104A3F28
	v_mul_f32_e32 v45, v39, v34                                // 000000457758: 105A4527
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045775C: BF870193
	.long 0x7e403990                                           // 000000457760: 7E403990
	v_fma_f32 v46, -v27, v37, v40                              // 000000457764: D613002E 24A24B1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000045776C: BF870113
	v_fma_f32 v44, -v30, v45, v39                              // 000000457770: D613002C 249E5B1E
	v_fmac_f32_e32 v37, v46, v31                               // 000000457778: 564A3F2E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000045777C: BF870112
	v_fmac_f32_e32 v45, v44, v34                               // 000000457780: 565A452C
	v_fma_f32 v27, -v27, v37, v40                              // 000000457784: D613001B 24A24B1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000045778C: BF870112
	v_fma_f32 v26, -v30, v45, v39                              // 000000457790: D613001A 249E5B1E
	v_div_fmas_f32 v27, v27, v31, v37                          // 000000457798: D637001B 04963F1B
	s_mov_b32 vcc_lo, s7                                       // 0000004577A0: BEEA0007
	s_mov_b32 s7, 0                                            // 0000004577A4: BE870080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004577A8: BF870121
	v_div_fixup_f32 v19, v27, v23, v19                         // 0000004577AC: D6270013 044E2F1B
	v_lshlrev_b32_e32 v23, 16, v7                              // 0000004577B4: 302E0E90
	v_dual_mul_f32 v6, v19, v6 :: v_dual_and_b32 v7, 0xffff0000, v7// 0000004577B8: C8E40D13 06060EFF FFFF0000
	v_mul_f32_e32 v43, v38, v33                                // 0000004577C4: 10564326
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004577C8: BF870112
	.long 0x7e463986                                           // 0000004577CC: 7E463986
	v_fma_f32 v47, -v28, v43, v38                              // 0000004577D0: D613002F 249A571C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004577D8: BF870091
	v_fmac_f32_e32 v43, v47, v33                               // 0000004577DC: 5656432F
	v_fma_f32 v28, -v28, v43, v38                              // 0000004577E0: D613001C 249A571C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000004577E8: BF870131
	v_div_fmas_f32 v22, v28, v33, v43                          // 0000004577EC: D6370016 04AE431C
	s_mov_b32 vcc_lo, s9                                       // 0000004577F4: BEEA0009
	v_div_fmas_f32 v19, v26, v34, v45                          // 0000004577F8: D6370013 04B6451A
	v_div_fixup_f32 v21, v22, v24, v21                         // 000000457800: D6270015 04563116
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000457808: BF8701A2
	v_div_fixup_f32 v17, v19, v25, v17                         // 00000045780C: D6270011 04463313
	v_and_b32_e32 v19, 1, v32                                  // 000000457814: 36264081
	v_mul_f32_e32 v21, v21, v23                                // 000000457818: 102A2F15
	v_and_b32_e32 v23, 1, v35                                  // 00000045781C: 362E4681
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000457820: BF870214
	v_mul_f32_e32 v7, v17, v7                                  // 000000457824: 100E0F11
	v_add3_u32 v16, v16, v19, 0x7fff                           // 000000457828: D6550010 03FE2710 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000457834: BF870214
	v_bfe_u32 v22, v21, 16, 1                                  // 000000457838: D6100016 02052115
	v_add3_u32 v6, v6, v23, 0x7fff                             // 000000457840: D6550006 03FE2F06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045784C: BF870214
	v_bfe_u32 v19, v7, 16, 1                                   // 000000457850: D6100013 02052107
	v_and_b32_e32 v16, 0xffff0000, v16                         // 000000457858: 362020FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000457860: BF870214
	v_add3_u32 v17, v21, v22, 0x7fff                           // 000000457864: D6550011 03FE2D15 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000457870: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000457878: BF870194
	v_add3_u32 v7, v7, v19, 0x7fff                             // 00000045787C: D6550007 03FE2707 00007FFF
	v_and_b32_e32 v21, 0xffff0000, v17                         // 000000457888: 362A22FF FFFF0000
	s_waitcnt vmcnt(1)                                         // 000000457890: BF8907F7
	v_fma_mix_f32 v17, v20, v16, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000457894: CC200811 8A022114
	v_fma_mix_f32 v19, v20, v6, neg(0) op_sel_hi:[1,0,0]       // 00000045789C: CC200013 8A020D14
	s_waitcnt vmcnt(0)                                         // 0000004578A4: BF8903F7
	v_fma_mix_f32 v16, v18, v21, neg(0) op_sel_hi:[1,0,0]      // 0000004578A8: CC200010 8A022B12
	v_and_b32_e32 v18, 0xffff0000, v7                          // 0000004578B0: 36240EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000004578B8: 916A077E
	s_cbranch_vccnz 65128                                      // 0000004578BC: BFA4FE68 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004578C0: BF8700A3
	.long 0xd73c0004                                           // 0000004578C4: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000004578C8: 02020881
	s_waitcnt lgkmcnt(0)                                       // 0000004578CC: BF89FC07
	.long 0xd7006a04                                           // 0000004578D0: D7006A04
	v_cndmask_b32_e32 v1, s30, v4, vcc_lo                      // 0000004578D4: 0202081E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004578D8: BF870111
	v_add_co_ci_u32_e64 v5, null, s31, v5, vcc_lo              // 0000004578DC: D5207C05 01AA0A1F
	.long 0xd7006a04                                           // 0000004578E4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000004578E8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004578EC: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000004578F0: D5207C05 01AA0705
	.long 0xd7006a06                                           // 0000004578F8: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000004578FC: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 000000457900: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 000000457908: DC560000 047C0004
	s_clause 0x1                                               // 000000457910: BF850001
	global_load_b32 v18, v[6:7], off                           // 000000457914: DC520000 127C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 00000045791C: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000457924: BF890BF7
	.long 0x7e0e3904                                           // 000000457928: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000045792C: 360808FF FFFF0000
	v_lshlrev_b32_e32 v16, 16, v5                              // 000000457934: 30200A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000457938: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 00000045793C: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000457940: BF8907F7
	v_fma_mix_f32 v17, v18, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000457944: CC200811 8A020912
	s_waitcnt vmcnt(0)                                         // 00000045794C: BF8903F7
	v_fma_mix_f32 v16, v6, v16, neg(0) op_sel_hi:[1,0,0]       // 000000457950: CC200010 8A022106
	v_fma_mix_f32 v19, v18, v7, neg(0) op_sel_hi:[1,0,0]       // 000000457958: CC200013 8A020F12
	v_and_b32_e32 v18, 0xffff0000, v5                          // 000000457960: 36240AFF FFFF0000
	s_branch 65085                                             // 000000457968: BFA0FE3D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_or_b32 exec_lo, exec_lo, s40                             // 00000045796C: 8C7E287E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000457970: BF870009
	s_or_b32 exec_lo, exec_lo, s35                             // 000000457974: 8C7E237E
	s_bfe_i32 s10, s11, 0x1001c                                // 000000457978: 938AFF0B 0001001C
	s_lshr_b32 s5, s33, 28                                     // 000000457980: 85059C21
	s_lshr_b64 s[0:1], s[10:11], 29                            // 000000457984: 85809D0A
	s_add_i32 s5, s25, s5                                      // 000000457988: 81050519
	s_add_i32 s0, s0, 7                                        // 00000045798C: 81008700
	s_lshl_b32 s3, s11, 3                                      // 000000457990: 8403830B
	s_ashr_i32 s0, s0, 3                                       // 000000457994: 86008300
	s_lshl_b32 s1, s34, 3                                      // 000000457998: 84018322
	.long 0xd72c0001                                           // 00000045799C: D72C0001
	v_cndmask_b32_e32 v1, s0, v11, vcc_lo                      // 0000004579A0: 02021600
	v_mov_b32_e32 v19, 0                                       // 0000004579A4: 7E260280
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v18, 0             // 0000004579A8: CA100080 0F120080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v20, 0             // 0000004579B0: CA100080 11140080
	v_mov_b32_e32 v21, 0                                       // 0000004579B8: 7E2A0280
	v_dual_mov_b32 v25, 0 :: v_dual_add_nc_u32 v2, s0, v1      // 0000004579BC: CA200080 19020200
	s_ashr_i32 s0, s5, 4                                       // 0000004579C4: 86008405
	s_ashr_i32 s5, s1, 31                                      // 0000004579C8: 86059F01
	s_mul_hi_i32 s6, s0, s2                                    // 0000004579CC: 97060200
	s_mul_i32 s0, s0, s2                                       // 0000004579D0: 96000200
	v_min_i32_e32 v16, s3, v2                                  // 0000004579D4: 22200403
	s_add_u32 s0, s0, s1                                       // 0000004579D8: 80000100
	s_addc_u32 s1, s6, s5                                      // 0000004579DC: 82010506
	s_mul_hi_u32 s3, s0, 0x300                                 // 0000004579E0: 9683FF00 00000300
	s_mulk_i32 s1, 0x300                                       // 0000004579E8: B8010300
	v_cmp_lt_i32_e32 vcc_lo, v1, v16                           // 0000004579EC: 7C822101
	s_add_i32 s7, s3, s1                                       // 0000004579F0: 81070103
	s_mul_i32 s6, s0, 0x300                                    // 0000004579F4: 9606FF00 00000300
	s_waitcnt lgkmcnt(0)                                       // 0000004579FC: BF89FC07
	s_barrier                                                  // 000000457A00: BFBD0000
	buffer_gl0_inv                                             // 000000457A04: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000457A0C: BE81206A
	s_cbranch_execz 24                                         // 000000457A10: BFA50018 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x974>
	s_add_u32 s8, s28, s6                                      // 000000457A14: 8008061C
	s_addc_u32 s9, s29, s7                                     // 000000457A18: 8209071D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000457A1C: BF870099
	v_mad_i64_i32 v[2:3], null, 0x300, v1, s[8:9]              // 000000457A20: D6FF7C02 002202FF 00000300
	.long 0xd7000002                                           // 000000457A2C: D7000002
	v_cndmask_b32_e32 v1, v2, v12, vcc_lo                      // 000000457A30: 02021902
	s_delay_alu instid0(VALU_DEP_1)                            // 000000457A34: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, s0                    // 000000457A38: D5207C03 00020680
	s_clause 0x5                                               // 000000457A40: BF850005
	global_load_b32 v17, v[2:3], off                           // 000000457A44: DC520000 117C0002
	global_load_b32 v18, v[2:3], off offset:128                // 000000457A4C: DC520080 127C0002
	global_load_b32 v19, v[2:3], off offset:256                // 000000457A54: DC520100 137C0002
	global_load_b32 v20, v[2:3], off offset:384                // 000000457A5C: DC520180 147C0002
	global_load_b32 v21, v[2:3], off offset:512                // 000000457A64: DC520200 157C0002
	global_load_b32 v25, v[2:3], off offset:640                // 000000457A6C: DC520280 197C0002
	s_or_b32 exec_lo, exec_lo, s1                              // 000000457A74: 8C7E017E
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v35, 0             // 000000457A78: CA100080 24220080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v33, 0             // 000000457A80: CA100080 22200080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v31, 0             // 000000457A88: CA100080 201E0080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v29, 0             // 000000457A90: CA100080 161C0080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v23, 0             // 000000457A98: CA100080 1E160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v27, 0             // 000000457AA0: CA100080 181A0080
	v_mov_b32_e32 v28, 0                                       // 000000457AA8: 7E380280
	v_mov_b32_e32 v26, 0                                       // 000000457AAC: 7E340280
	v_mov_b32_e32 v14, 0                                       // 000000457AB0: 7E1C0280
	s_ashr_i32 s3, s2, 31                                      // 000000457AB4: 86039F02
	s_and_saveexec_b32 s1, vcc_lo                              // 000000457AB8: BE81206A
	s_cbranch_execz 1097                                       // 000000457ABC: BFA50449 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ae4>
	v_or_b32_e32 v4, 4, v8                                     // 000000457AC0: 38081084
	v_mad_u32_u24 v7, v13, 24, 0x2f0                           // 000000457AC4: D60B0007 03FD310D 000002F0
	v_mad_i64_i32 v[2:3], null, 0x300, v1, s[6:7]              // 000000457AD0: D6FF7C02 001A02FF 00000300
	v_mul_u32_u24_e32 v6, 0x320, v11                           // 000000457ADC: 160C16FF 00000320
	v_mul_i32_i24_e32 v8, 0xffffffe8, v13                      // 000000457AE4: 12101AFF FFFFFFE8
	v_mad_u32_u24 v5, v4, 3, 0x2f0                             // 000000457AEC: D60B0005 03FD0704 000002F0
	v_cmp_lt_u32_e32 vcc_lo, 5, v4                             // 000000457AF8: 7C920885
	v_lshrrev_b32_e32 v22, 5, v7                               // 000000457AFC: 322C0E85
	v_mul_i32_i24_e32 v23, -3, v4                              // 000000457B00: 122E08C3
	v_dual_mov_b32 v14, 0 :: v_dual_and_b32 v7, 0x7e0, v7      // 000000457B04: CA240080 0E060EFF 000007E0
	v_lshrrev_b32_e32 v9, 5, v5                                // 000000457B10: 32120A85
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v5, 0x7e0, v5      // 000000457B14: CA240080 1A040AFF 000007E0
	v_mad_u32_u24 v15, 0x320, v11, v12                         // 000000457B20: D60B000F 043216FF 00000320
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000457B2C: BF870214
	v_add3_u32 v37, v8, v7, 0xfffffd34                         // 000000457B30: D6550025 03FE0F08 FFFFFD34
	v_subrev_nc_u32_e32 v9, 24, v9                             // 000000457B3C: 4E121298
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000457B40: BF870234
	v_add3_u32 v38, v23, v5, 0xfffffd34                        // 000000457B44: D6550026 03FE0B17 FFFFFD34
	v_sub_nc_u32_e32 v40, 0, v16                               // 000000457B50: 4C502080
	v_dual_mov_b32 v28, 0 :: v_dual_add_nc_u32 v41, 1, v1      // 000000457B54: CA200080 1C280281
	v_cndmask_b32_e32 v4, 23, v9, vcc_lo                       // 000000457B5C: 02081297
	.long 0xd7006a02                                           // 000000457B60: D7006A02
	v_cndmask_b32_e32 v1, v2, v12, vcc_lo                      // 000000457B64: 02021902
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000457B68: BF870221
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000457B6C: D5207C03 01AA0680
	v_subrev_nc_u32_e32 v9, 24, v22                            // 000000457B74: 4E122C98
	v_dual_mov_b32 v27, 0 :: v_dual_add_nc_u32 v22, 1, v4      // 000000457B78: CA200080 1B160881
	v_cmp_ne_u32_e32 vcc_lo, 0, v13                            // 000000457B80: 7C9A1A80
	v_and_b32_e32 v10, 16, v0                                  // 000000457B84: 36140090
	v_subrev_nc_u32_e32 v24, 23, v4                            // 000000457B88: 4E300897
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v42, 0x2800, v15// 000000457B8C: CA200080 1D2A1EFF 00002800
	v_cndmask_b32_e32 v9, 23, v9, vcc_lo                       // 000000457B98: 02121297
	v_cmp_gt_u32_e32 vcc_lo, 24, v22                           // 000000457B9C: 7C982C98
	v_lshl_or_b32 v39, v1, 5, v10                              // 000000457BA0: D6560027 04290B01
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v15, 0             // 000000457BA8: CA100080 200E0080
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000457BB0: BF870244
	v_lshl_add_u32 v7, v9, 2, v6                               // 000000457BB4: D6460007 04190509
	v_cndmask_b32_e32 v5, v24, v22, vcc_lo                     // 000000457BBC: 020A2D18
	v_cmp_gt_i32_e32 vcc_lo, 23, v9                            // 000000457BC0: 7C881297
	v_lshl_add_u32 v4, v4, 2, v6                               // 000000457BC4: D6460004 04190504
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v43, 0x2800, v7 // 000000457BCC: CA200080 182A0EFF 00002800
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000457BD8: BF8700B4
	v_lshl_add_u32 v5, v5, 2, v6                               // 000000457BDC: D6460005 04190505
	v_cndmask_b32_e64 v8, 0xffffffa4, 4, vcc_lo                // 000000457BE4: D5010008 01A908FF FFFFFFA4
	.long 0xd7006a02                                           // 000000457BF0: D7006A02
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 000000457BF4: 0202041C
	v_add_co_ci_u32_e64 v3, null, s29, v3, vcc_lo              // 000000457BF8: D5207C03 01AA061D
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v45, 0x2800, v4 // 000000457C00: CA200080 1E2C08FF 00002800
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000457C0C: BF870223
	.long 0xd7006a09                                           // 000000457C10: D7006A09
	v_cndmask_b32_e32 v1, 0x300, v2, vcc_lo                    // 000000457C14: 020204FF 00000300
	v_dual_mov_b32 v23, 0 :: v_dual_add_nc_u32 v2, v7, v8      // 000000457C1C: CA200080 17021107
	v_add_co_ci_u32_e64 v10, null, 0, v3, vcc_lo               // 000000457C24: D5207C0A 01AA0680
	v_dual_mov_b32 v33, 0 :: v_dual_add_nc_u32 v46, 0x2800, v5 // 000000457C2C: CA200080 212E0AFF 00002800
	s_delay_alu instid0(VALU_DEP_3)                            // 000000457C38: BF870003
	v_dual_mov_b32 v31, 0 :: v_dual_add_nc_u32 v44, 0x2800, v2 // 000000457C3C: CA200080 1F2C04FF 00002800
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v35, 0             // 000000457C48: CA100080 16220080
	v_mov_b32_e32 v34, 0                                       // 000000457C50: 7E440280
	v_mov_b32_e32 v36, 0                                       // 000000457C54: 7E480280
	s_mov_b32 s5, 0                                            // 000000457C58: BE850080
	s_movk_i32 s6, 0x1eee                                      // 000000457C5C: B0061EEE
	s_branch 964                                               // 000000457C60: BFA003C4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1a74>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000457C64: 8C7E007E
	ds_load_2addr_b32 v[47:48], v44 offset1:24                 // 000000457C68: D8DC1800 2F00002C
	ds_load_2addr_b32 v[49:50], v46 offset1:24                 // 000000457C70: D8DC1800 3100002E
	ds_load_2addr_b32 v[2:3], v43 offset1:24                   // 000000457C78: D8DC1800 0200002B
	ds_load_2addr_b32 v[53:54], v45 offset1:24                 // 000000457C80: D8DC1800 3500002D
	.long 0xd7000009                                           // 000000457C88: D7000009
	v_cndmask_b32_e32 v1, 0x300, v9, vcc_lo                    // 000000457C8C: 020212FF 00000300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000457C94: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v10, s0                  // 000000457C98: D5207C0A 00021480
	v_add_nc_u32_e32 v41, 1, v41                               // 000000457CA0: 4A525281
	s_waitcnt lgkmcnt(2)                                       // 000000457CA4: BF89FC27
	v_dual_mov_b32 v1, v47 :: v_dual_mov_b32 v52, v49          // 000000457CA8: CA10012F 01340131
	s_waitcnt lgkmcnt(0)                                       // 000000457CB0: BF89FC07
	v_mov_b32_e32 v51, v54                                     // 000000457CB4: 7E660336
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000457CB8: BF870192
	.long 0xd73d0038                                           // 000000457CBC: D73D0038
	v_cndmask_b32_e32 v1, v37, v1, vcc_lo                      // 000000457CC0: 02020325
	.long 0xd73d0034                                           // 000000457CC4: D73D0034
	v_cndmask_b32_e32 v1, v38, v52, vcc_lo                     // 000000457CC8: 02026926
	v_mov_b32_e32 v49, v3                                      // 000000457CCC: 7E620303
	ds_load_b128 v[1:4], v39                                   // 000000457CD0: DBFC0000 01000027
	ds_load_b128 v[5:8], v39 offset:5120                       // 000000457CD8: DBFC1400 05000027
	ds_load_2addr_b32 v[54:55], v44 offset0:48 offset1:72      // 000000457CE0: D8DC4830 3600002C
	v_add_nc_u32_e32 v39, 32, v39                              // 000000457CE8: 4A4E4EA0
	.long 0xd73d002f                                           // 000000457CEC: D73D002F
	v_cndmask_b32_e32 v1, v37, v48, vcc_lo                     // 000000457CF0: 02026125
	.long 0xd73d0030                                           // 000000457CF4: D73D0030
	v_cndmask_b32_e32 v1, v38, v50, vcc_lo                     // 000000457CF8: 02026526
	v_bfe_u32 v49, v56, 9, 16                                  // 000000457CFC: D6100031 02411338
	v_bfe_u32 v50, v56, 6, 16                                  // 000000457D04: D6100032 02410D38
	v_bfe_u32 v51, v56, 3, 16                                  // 000000457D0C: D6100033 02410738
	v_bfe_u32 v57, v52, 6, 16                                  // 000000457D14: D6100039 02410D34
	v_bfe_u32 v59, v47, 9, 16                                  // 000000457D1C: D610003B 0241132F
	.long 0xd72c0031                                           // 000000457D24: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000457D28: 020262FF 83DCD12D
	.long 0xd72c0032                                           // 000000457D30: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000457D34: 020264FF 83DCD12D
	v_bfe_u32 v60, v47, 6, 16                                  // 000000457D3C: D610003C 02410D2F
	.long 0xd72c0033                                           // 000000457D44: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000457D48: 020266FF 83DCD12D
	.long 0xd72c003b                                           // 000000457D50: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000457D54: 020276FF 83DCD12D
	v_bfe_u32 v61, v47, 3, 16                                  // 000000457D5C: D610003D 0241072F
	v_bfe_u32 v58, v52, 3, 16                                  // 000000457D64: D610003A 02410734
	.long 0xd72c003c                                           // 000000457D6C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000457D70: 020278FF 83DCD12D
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000457D78: D6220031 03FD0131 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000457D84: D6220032 03FD0132 00006400
	.long 0xd72c003d                                           // 000000457D90: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000457D94: 02027AFF 83DCD12D
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000457D9C: D6220033 03FD0133 00006400
	.long 0xd72c003a                                           // 000000457DA8: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000457DAC: 020274FF 83DCD12D
	v_and_b32_e32 v49, 0xffff, v49                             // 000000457DB4: 366262FF 0000FFFF
	.long 0xd72c0039                                           // 000000457DBC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000457DC0: 020272FF 83DCD12D
	v_bfe_u32 v62, v48, 9, 16                                  // 000000457DC8: D610003E 02411330
	v_bfe_u32 v63, v48, 6, 16                                  // 000000457DD0: D610003F 02410D30
	v_bfe_u32 v64, v48, 3, 16                                  // 000000457DD8: D6100040 02410730
	v_lshl_or_b32 v49, v50, 16, v49                            // 000000457DE0: D6560031 04C52132
	v_sad_u8 v50, v59, 0, 0x6400                               // 000000457DE8: D6220032 03FD013B 00006400
	v_sad_u8 v59, v60, 0, 0x6400                               // 000000457DF4: D622003B 03FD013C 00006400
	v_and_b32_e32 v48, 0xffff, v48                             // 000000457E00: 366060FF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000457E08: D622003A 03FD013A 00006400
	v_pk_fma_f16 v49, v49, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000457E14: CC0E0031 0BFC0D31 0000C931
	v_and_b32_e32 v53, 0xffff, v56                             // 000000457E20: 366A70FF 0000FFFF
	v_bfe_u32 v56, v52, 9, 16                                  // 000000457E28: D6100038 02411334
	v_and_b32_e32 v50, 0xffff, v50                             // 000000457E30: 366464FF 0000FFFF
	v_and_b32_e32 v52, 0xffff, v52                             // 000000457E38: 366868FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 000000457E40: BF89FC27
	v_dot2acc_f32_f16 v14, v49, v1                             // 000000457E44: 041C0331
	.long 0xd72c0035                                           // 000000457E48: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000457E4C: 02026AFF 83DCD12D
	.long 0xd72c0038                                           // 000000457E54: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000457E58: 020270FF 83DCD12D
	v_lshl_or_b32 v59, v59, 16, v50                            // 000000457E60: D656003B 04C9213B
	.long 0xd72c0034                                           // 000000457E68: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000457E6C: 020268FF 83DCD12D
	.long 0xd72c003e                                           // 000000457E74: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000457E78: 02027CFF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000457E80: D6220039 03FD0139 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000457E8C: BF870244
	v_pk_fma_f16 v59, v59, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000457E90: CC0E003B 0BFC0D3B 0000C931
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000457E9C: D6220035 03FD0135 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000457EA8: D6220038 03FD0138 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000457EB4: D6220034 03FD0134 00006400
	v_dot2acc_f32_f16 v27, v59, v1                             // 000000457EC0: 0436033B
	s_waitcnt lgkmcnt(1)                                       // 000000457EC4: BF89FC17
	v_dot2acc_f32_f16 v26, v49, v5                             // 000000457EC8: 04340B31
	v_lshlrev_b32_e32 v53, 16, v53                             // 000000457ECC: 306A6A90
	v_and_b32_e32 v56, 0xffff, v56                             // 000000457ED0: 367070FF 0000FFFF
	v_lshlrev_b32_e32 v52, 16, v52                             // 000000457ED8: 30686890
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000457EDC: BF870223
	v_and_or_b32 v51, 0xffff, v51, v53                         // 000000457EE0: D6570033 04D666FF 0000FFFF
	v_sad_u8 v53, v61, 0, 0x6400                               // 000000457EEC: D6220035 03FD013D 00006400
	v_lshl_or_b32 v56, v57, 16, v56                            // 000000457EF8: D6560038 04E12139
	v_sad_u8 v57, v62, 0, 0x6400                               // 000000457F00: D6220039 03FD013E 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000457F0C: BF8701A4
	v_pk_fma_f16 v60, v51, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000457F10: CC0E003C 0BFC0D33 0000C931
	v_and_b32_e32 v47, 0xffff, v47                             // 000000457F1C: 365E5EFF 0000FFFF
	v_and_b32_e32 v62, 0xffff, v57                             // 000000457F24: 367C72FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000457F2C: BF870193
	v_dot2acc_f32_f16 v14, v60, v2                             // 000000457F30: 041C053C
	.long 0xd72c002f                                           // 000000457F34: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000457F38: 02025EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000457F40: BF870091
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000457F44: D622002F 03FD012F 00006400
	v_lshlrev_b32_e32 v47, 16, v47                             // 000000457F50: 305E5E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000457F54: BF870121
	v_and_or_b32 v47, 0xffff, v53, v47                         // 000000457F58: D657002F 04BE6AFF 0000FFFF
	.long 0xd72c0035                                           // 000000457F64: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000457F68: 020280FF 83DCD12D
	v_pk_fma_f16 v64, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000457F70: CC0E0040 0BFC0D2F 0000C931
	s_waitcnt lgkmcnt(0)                                       // 000000457F7C: BF89FC07
	v_mov_b32_e32 v47, v54                                     // 000000457F80: 7E5E0336
	v_and_or_b32 v51, 0xffff, v58, v52                         // 000000457F84: D6570033 04D274FF 0000FFFF
	.long 0xd72c003a                                           // 000000457F90: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000457F94: 020260FF 83DCD12D
	ds_load_2addr_b32 v[48:49], v43 offset0:48 offset1:72      // 000000457F9C: D8DC4830 3000002B
	v_pk_fma_f16 v52, v56, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000457FA4: CC0E0034 0BFC0D38 0000C931
	.long 0xd72c0038                                           // 000000457FB0: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000457FB4: 02027EFF 83DCD12D
	v_pk_fma_f16 v61, v51, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000457FBC: CC0E003D 0BFC0D33 0000C931
	ds_load_2addr_b32 v[50:51], v46 offset0:48 offset1:72      // 000000457FC8: D8DC4830 3200002E
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000457FD0: D6220035 03FD0135 00006400
	v_dot2acc_f32_f16 v27, v64, v2                             // 000000457FDC: 04360540
	v_sad_u8 v63, v58, 0, 0x6400                               // 000000457FE0: D622003F 03FD013A 00006400
	ds_load_2addr_b32 v[57:58], v45 offset0:48 offset1:72      // 000000457FEC: D8DC4830 3900002D
	v_dot2acc_f32_f16 v26, v60, v6                             // 000000457FF4: 04340D3C
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000457FF8: D6220038 03FD0138 00006400
	v_dot2acc_f32_f16 v14, v52, v3                             // 000000458004: 041C0734
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000458008: BF870193
	v_dot2acc_f32_f16 v26, v52, v7                             // 00000045800C: 04340F34
	v_lshl_or_b32 v56, v56, 16, v62                            // 000000458010: D6560038 04F92138
	v_lshlrev_b32_e32 v62, 16, v63                             // 000000458018: 307C7E90
	s_delay_alu instid0(VALU_DEP_4)                            // 00000045801C: BF870004
	v_dot2acc_f32_f16 v14, v61, v4                             // 000000458020: 041C093D
	s_waitcnt lgkmcnt(2)                                       // 000000458024: BF89FC27
	.long 0xd73d002f                                           // 000000458028: D73D002F
	v_cndmask_b32_e32 v1, v37, v47, vcc_lo                     // 00000045802C: 02025F25
	v_pk_fma_f16 v54, v56, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000458030: CC0E0036 0BFC0D38 0000C931
	v_and_or_b32 v53, 0xffff, v53, v62                         // 00000045803C: D6570035 04FA6AFF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 000000458048: BF89FC17
	v_mov_b32_e32 v56, v50                                     // 00000045804C: 7E700332
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000458050: BF870194
	v_bfe_u32 v48, v47, 9, 16                                  // 000000458054: D6100030 0241132F
	v_pk_fma_f16 v60, v53, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045805C: CC0E003C 0BFC0D35 0000C931
	v_and_b32_e32 v50, 0xffff, v47                             // 000000458068: 36645EFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000458070: BF89FC07
	.long 0xd73d0034                                           // 000000458074: D73D0034
	v_cndmask_b32_e32 v1, v38, v56, vcc_lo                     // 000000458078: 02027126
	v_bfe_u32 v53, v47, 6, 16                                  // 00000045807C: D6100035 02410D2F
	.long 0xd72c0030                                           // 000000458084: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000458088: 020260FF 83DCD12D
	v_bfe_u32 v47, v47, 3, 16                                  // 000000458090: D610002F 0241072F
	.long 0xd72c0032                                           // 000000458098: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 00000045809C: 020264FF 83DCD12D
	v_dot2acc_f32_f16 v27, v54, v3                             // 0000004580A4: 04360736
	v_bfe_u32 v56, v52, 9, 16                                  // 0000004580A8: D6100038 02411334
	.long 0xd72c0035                                           // 0000004580B0: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000004580B4: 02026AFF 83DCD12D
	v_bfe_u32 v57, v52, 6, 16                                  // 0000004580BC: D6100039 02410D34
	.long 0xd72c002f                                           // 0000004580C4: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000004580C8: 02025EFF 83DCD12D
	v_sad_u8 v48, v48, 0, 0x6400                               // 0000004580D0: D6220030 03FD0130 00006400
	.long 0xd72c0038                                           // 0000004580DC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000004580E0: 020270FF 83DCD12D
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000004580E8: D6220032 03FD0132 00006400
	.long 0xd72c0039                                           // 0000004580F4: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000004580F8: 020272FF 83DCD12D
	v_dot2acc_f32_f16 v27, v60, v4                             // 000000458100: 0436093C
	v_and_b32_e32 v48, 0xffff, v48                             // 000000458104: 366060FF 0000FFFF
	v_sad_u8 v53, v53, 0, 0x6400                               // 00000045810C: D6220035 03FD0135 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000458118: D622002F 03FD012F 00006400
	v_lshlrev_b32_e32 v50, 16, v50                             // 000000458124: 30646490
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000458128: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000458134: BF870194
	v_lshl_or_b32 v48, v53, 16, v48                            // 000000458138: D6560030 04C12135
	v_and_or_b32 v47, 0xffff, v47, v50                         // 000000458140: D657002F 04CA5EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000045814C: BF870223
	v_and_b32_e32 v53, 0xffff, v56                             // 000000458150: 366A70FF 0000FFFF
	v_sad_u8 v56, v57, 0, 0x6400                               // 000000458158: D6220038 03FD0139 00006400
	v_pk_fma_f16 v48, v48, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000458164: CC0E0030 0BFC0D30 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000458170: BF870194
	v_pk_fma_f16 v47, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000458174: CC0E002F 0BFC0D2F 0000C931
	v_lshl_or_b32 v53, v56, 16, v53                            // 000000458180: D6560035 04D52138
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000458188: BF8701A3
	v_dot2acc_f32_f16 v24, v48, v1                             // 00000045818C: 04300330
	v_dual_dot2acc_f32_f16 v23, v48, v5 :: v_dual_mov_b32 v56, v49// 000000458190: CB100B30 17380131
	v_pk_fma_f16 v49, v53, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000458198: CC0E0031 0BFC0D35 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004581A4: BF870193
	v_dot2acc_f32_f16 v24, v47, v2                             // 0000004581A8: 0430052F
	v_dot2acc_f32_f16 v23, v47, v6                             // 0000004581AC: 042E0D2F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004581B0: BF870234
	.long 0xd73d002f                                           // 0000004581B4: D73D002F
	v_cndmask_b32_e32 v1, v37, v55, vcc_lo                     // 0000004581B8: 02026F25
	v_dot2acc_f32_f16 v26, v61, v8                             // 0000004581BC: 0434113D
	v_bfe_u32 v61, v52, 3, 16                                  // 0000004581C0: D610003D 02410734
	v_dual_dot2acc_f32_f16 v23, v49, v7 :: v_dual_and_b32 v52, 0xffff, v52// 0000004581C8: CB240F31 173468FF 0000FFFF
	v_dot2acc_f32_f16 v24, v49, v3                             // 0000004581D4: 04300731
	v_bfe_u32 v53, v47, 9, 16                                  // 0000004581D8: D6100035 0241132F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004581E0: BF870214
	.long 0xd72c0032                                           // 0000004581E4: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000004581E8: 02027AFF 83DCD12D
	.long 0xd72c0034                                           // 0000004581F0: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000004581F4: 020268FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004581FC: BF870112
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000458200: D6220032 03FD0132 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 00000045820C: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000458218: BF870091
	v_lshlrev_b32_e32 v52, 16, v52                             // 00000045821C: 30686890
	v_and_or_b32 v50, 0xffff, v50, v52                         // 000000458220: D6570032 04D264FF 0000FFFF
	v_mov_b32_e32 v52, v58                                     // 00000045822C: 7E68033A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000458230: BF870112
	v_pk_fma_f16 v48, v50, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000458234: CC0E0030 0BFC0D32 0000C931
	.long 0xd73d0031                                           // 000000458240: D73D0031
	v_cndmask_b32_e32 v1, v38, v51, vcc_lo                     // 000000458244: 02026726
	v_bfe_u32 v50, v47, 6, 16                                  // 000000458248: D6100032 02410D2F
	v_bfe_u32 v51, v47, 3, 16                                  // 000000458250: D6100033 0241072F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000458258: BF870234
	v_dual_dot2acc_f32_f16 v24, v48, v4 :: v_dual_and_b32 v47, 0xffff, v47// 00000045825C: CB240930 182E5EFF 0000FFFF
	v_dot2acc_f32_f16 v23, v48, v8                             // 000000458268: 042E1130
	v_bfe_u32 v52, v49, 9, 16                                  // 00000045826C: D6100034 02411331
	.long 0xd72c0038                                           // 000000458274: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000458278: 020266FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000458280: BF870004
	.long 0xd72c0039                                           // 000000458284: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000458288: 02025EFF 83DCD12D
	.long 0xd72c0030                                           // 000000458290: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000458294: 02026AFF 83DCD12D
	.long 0xd72c0032                                           // 00000045829C: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000004582A0: 020264FF 83DCD12D
	v_bfe_u32 v55, v49, 3, 16                                  // 0000004582A8: D6100037 02410731
	v_sad_u8 v61, v56, 0, 0x6400                               // 0000004582B0: D622003D 03FD0138 00006400
	v_sad_u8 v56, v57, 0, 0x6400                               // 0000004582BC: D6220038 03FD0139 00006400
	v_dot2acc_f32_f16 v28, v59, v5                             // 0000004582C8: 04380B3B
	.long 0xd72c003b                                           // 0000004582CC: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000004582D0: 020268FF 83DCD12D
	v_sad_u8 v53, v48, 0, 0x6400                               // 0000004582D8: D6220035 03FD0130 00006400
	ds_load_2addr_b32 v[47:48], v44 offset0:96 offset1:120     // 0000004582E4: D8DC7860 2F00002C
	.long 0xd72c003e                                           // 0000004582EC: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000004582F0: 02026EFF 83DCD12D
	v_and_b32_e32 v58, 0xffff, v53                             // 0000004582F8: 36746AFF 0000FFFF
	ds_load_2addr_b32 v[52:53], v46 offset0:96 offset1:120     // 000000458300: D8DC7860 3400002E
	v_sad_u8 v57, v59, 0, 0x6400                               // 000000458308: D6220039 03FD013B 00006400
	v_dual_dot2acc_f32_f16 v28, v64, v6 :: v_dual_lshlrev_b32 v59, 16, v56// 000000458314: CB220D40 1C3A7090
	ds_load_2addr_b32 v[55:56], v45 offset0:96 offset1:120     // 00000045831C: D8DC7860 3700002D
	v_and_b32_e32 v57, 0xffff, v57                             // 000000458324: 367272FF 0000FFFF
	v_and_or_b32 v59, 0xffff, v61, v59                         // 00000045832C: D657003B 04EE7AFF 0000FFFF
	v_dot2acc_f32_f16 v28, v54, v7                             // 000000458338: 04380F36
	v_bfe_u32 v54, v49, 6, 16                                  // 00000045833C: D6100036 02410D31
	s_delay_alu instid0(VALU_DEP_2)                            // 000000458344: BF870002
	v_dual_dot2acc_f32_f16 v28, v60, v8 :: v_dual_and_b32 v49, 0xffff, v49// 000000458348: CB24113C 1C3062FF 0000FFFF
	v_sad_u8 v60, v50, 0, 0x6400                               // 000000458354: D622003C 03FD0132 00006400
	ds_load_2addr_b32 v[50:51], v43 offset0:96 offset1:120     // 000000458360: D8DC7860 3200002B
	.long 0xd72c0031                                           // 000000458368: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 00000045836C: 020262FF 83DCD12D
	.long 0xd72c0036                                           // 000000458374: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000458378: 02026CFF 83DCD12D
	v_lshl_or_b32 v58, v60, 16, v58                            // 000000458380: D656003A 04E9213C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000458388: BF870193
	v_sad_u8 v60, v49, 0, 0x6400                               // 00000045838C: D622003C 03FD0131 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000458398: D6220036 03FD0136 00006400
	s_waitcnt lgkmcnt(3)                                       // 0000004583A4: BF89FC37
	v_mov_b32_e32 v49, v47                                     // 0000004583A8: 7E62032F
	v_sad_u8 v47, v62, 0, 0x6400                               // 0000004583AC: D622002F 03FD013E 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000004583B8: BF8701C3
	v_lshl_or_b32 v54, v54, 16, v57                            // 0000004583BC: D6560036 04E52136
	v_pk_fma_f16 v57, v58, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004583C4: CC0E0039 0BFC0D3A 0000C931
	s_waitcnt lgkmcnt(0)                                       // 0000004583D0: BF89FC07
	.long 0xd73d0031                                           // 0000004583D4: D73D0031
	v_cndmask_b32_e32 v1, v37, v49, vcc_lo                     // 0000004583D8: 02026325
	v_pk_fma_f16 v58, v54, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004583DC: CC0E003A 0BFC0D36 0000C931
	v_mov_b32_e32 v54, v52                                     // 0000004583E8: 7E6C0334
	v_pk_fma_f16 v50, v59, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004583EC: CC0E0032 0BFC0D3B 0000C931
	v_dot2acc_f32_f16 v29, v57, v1                             // 0000004583F8: 043A0339
	v_dot2acc_f32_f16 v30, v57, v5                             // 0000004583FC: 043C0B39
	v_bfe_u32 v52, v49, 9, 16                                  // 000000458400: D6100034 02411331
	.long 0xd73d0036                                           // 000000458408: D73D0036
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 00000045840C: 02026D26
	v_bfe_u32 v55, v49, 6, 16                                  // 000000458410: D6100037 02410D31
	v_dot2acc_f32_f16 v29, v50, v2                             // 000000458418: 043A0532
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045841C: BF870194
	.long 0xd72c0034                                           // 000000458420: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000458424: 020268FF 83DCD12D
	.long 0xd72c0037                                           // 00000045842C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000458430: 02026EFF 83DCD12D
	v_bfe_u32 v61, v54, 6, 16                                  // 000000458438: D610003D 02410D36
	v_bfe_u32 v62, v54, 3, 16                                  // 000000458440: D610003E 02410736
	v_dot2acc_f32_f16 v29, v58, v3                             // 000000458448: 043A073A
	v_sad_u8 v52, v52, 0, 0x6400                               // 00000045844C: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000458458: BF8701A4
	.long 0xd72c003d                                           // 00000045845C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000458460: 02027AFF 83DCD12D
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000458468: D6220037 03FD0137 00006400
	v_and_b32_e32 v52, 0xffff, v52                             // 000000458474: 366868FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000045847C: BF870091
	v_lshl_or_b32 v52, v55, 16, v52                            // 000000458480: D6560034 04D12137
	v_pk_fma_f16 v52, v52, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000458488: CC0E0034 0BFC0D34 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000458494: BF870091
	v_dual_dot2acc_f32_f16 v31, v52, v5 :: v_dual_lshlrev_b32 v60, 16, v60// 000000458498: CB220B34 1F3C7890
	v_and_or_b32 v47, 0xffff, v47, v60                         // 0000004584A0: D657002F 04F25EFF 0000FFFF
	v_bfe_u32 v60, v54, 9, 16                                  // 0000004584AC: D610003C 02411336
	v_and_b32_e32 v54, 0xffff, v54                             // 0000004584B4: 366C6CFF 0000FFFF
	v_dot2acc_f32_f16 v22, v52, v1                             // 0000004584BC: 042C0334
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004584C0: BF870004
	v_pk_fma_f16 v59, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004584C4: CC0E003B 0BFC0D2F 0000C931
	v_and_b32_e32 v47, 0xffff, v49                             // 0000004584D0: 365E62FF 0000FFFF
	v_bfe_u32 v49, v49, 3, 16                                  // 0000004584D8: D6100031 02410731
	.long 0xd72c003c                                           // 0000004584E0: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000004584E4: 020278FF 83DCD12D
	.long 0xd72c0036                                           // 0000004584EC: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000004584F0: 02026CFF 83DCD12D
	v_dot2acc_f32_f16 v29, v59, v4                             // 0000004584F8: 043A093B
	.long 0xd72c002f                                           // 0000004584FC: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000458500: 02025EFF 83DCD12D
	.long 0xd72c0031                                           // 000000458508: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 00000045850C: 020262FF 83DCD12D
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000458514: D622003C 03FD013C 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000458520: D6220036 03FD0136 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045852C: BF870214
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000458530: D622002F 03FD012F 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 00000045853C: D6220031 03FD0131 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000458548: BF870224
	v_and_b32_e32 v55, 0xffff, v60                             // 00000045854C: 366E78FF 0000FFFF
	v_sad_u8 v60, v61, 0, 0x6400                               // 000000458554: D622003C 03FD013D 00006400
	v_lshlrev_b32_e32 v47, 16, v47                             // 000000458560: 305E5E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000458564: BF870121
	v_and_or_b32 v47, 0xffff, v49, v47                         // 000000458568: D657002F 04BE62FF 0000FFFF
	.long 0xd72c0031                                           // 000000458574: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000458578: 02027CFF 83DCD12D
	v_pk_fma_f16 v57, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000458580: CC0E0039 0BFC0D2F 0000C931
	v_lshl_or_b32 v47, v60, 16, v55                            // 00000045858C: D656002F 04DD213C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000458594: BF8701A3
	v_sad_u8 v55, v49, 0, 0x6400                               // 000000458598: D6220037 03FD0131 00006400
	v_mov_b32_e32 v49, v51                                     // 0000004585A4: 7E620333
	v_pk_fma_f16 v60, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004585A8: CC0E003C 0BFC0D2F 0000C931
	v_dot2acc_f32_f16 v31, v57, v6                             // 0000004585B4: 043E0D39
	v_lshlrev_b32_e32 v54, 16, v54                             // 0000004585B8: 306C6C90
	v_dot2acc_f32_f16 v22, v57, v2                             // 0000004585BC: 042C0539
	.long 0xd73d002f                                           // 0000004585C0: D73D002F
	v_cndmask_b32_e32 v1, v37, v48, vcc_lo                     // 0000004585C4: 02026125
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004585C8: BF870114
	v_dot2acc_f32_f16 v31, v60, v7                             // 0000004585CC: 043E0F3C
	v_and_b32_e32 v51, 0xffff, v47                             // 0000004585D0: 36665EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004585D8: BF870091
	.long 0xd72c0033                                           // 0000004585DC: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000004585E0: 020266FF 83DCD12D
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000004585E8: D6220033 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004585F4: BF8701B1
	v_dual_dot2acc_f32_f16 v30, v50, v6 :: v_dual_lshlrev_b32 v57, 16, v51// 0000004585F8: CB220D32 1E386690
	v_and_or_b32 v50, 0xffff, v55, v54                         // 000000458600: D6570032 04DA6EFF 0000FFFF
	v_mov_b32_e32 v54, v56                                     // 00000045860C: 7E6C0338
	v_dot2acc_f32_f16 v30, v58, v7                             // 000000458610: 043C0F3A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000458614: BF870223
	v_pk_fma_f16 v58, v50, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000458618: CC0E003A 0BFC0D32 0000C931
	v_bfe_u32 v50, v47, 9, 16                                  // 000000458624: D6100032 0241132F
	.long 0xd73d0030                                           // 00000045862C: D73D0030
	v_cndmask_b32_e32 v1, v38, v53, vcc_lo                     // 000000458630: 02026B26
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000458634: BF870214
	v_dot2acc_f32_f16 v30, v59, v8                             // 000000458638: 043C113B
	v_dot2acc_f32_f16 v31, v58, v8                             // 00000045863C: 043E113A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000458640: BF870004
	.long 0xd72c0031                                           // 000000458644: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000458648: 020264FF 83DCD12D
	v_bfe_u32 v50, v47, 6, 16                                  // 000000458650: D6100032 02410D2F
	v_bfe_u32 v47, v47, 3, 16                                  // 000000458658: D610002F 0241072F
	v_bfe_u32 v52, v48, 9, 16                                  // 000000458660: D6100034 02411330
	v_bfe_u32 v53, v48, 6, 16                                  // 000000458668: D6100035 02410D30
	v_bfe_u32 v54, v48, 3, 16                                  // 000000458670: D6100036 02410730
	.long 0xd72c0032                                           // 000000458678: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 00000045867C: 020264FF 83DCD12D
	.long 0xd72c002f                                           // 000000458684: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000458688: 02025EFF 83DCD12D
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000458690: D6220031 03FD0131 00006400
	.long 0xd72c0034                                           // 00000045869C: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000004586A0: 020268FF 83DCD12D
	v_and_b32_e32 v55, 0xffff, v48                             // 0000004586A8: 366E60FF 0000FFFF
	.long 0xd72c003b                                           // 0000004586B0: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000004586B4: 02026AFF 83DCD12D
	.long 0xd72c0036                                           // 0000004586BC: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000004586C0: 02026CFF 83DCD12D
	v_and_b32_e32 v49, 0xffff, v49                             // 0000004586C8: 366262FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000004586D0: D6220032 03FD0132 00006400
	v_sad_u8 v56, v47, 0, 0x6400                               // 0000004586DC: D6220038 03FD012F 00006400
	ds_load_2addr_b32 v[47:48], v44 offset0:144 offset1:168    // 0000004586E8: D8DCA890 2F00002C
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000004586F0: D6220034 03FD0134 00006400
	.long 0xd72c0037                                           // 0000004586FC: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000458700: 02026EFF 83DCD12D
	v_lshl_or_b32 v49, v50, 16, v49                            // 000000458708: D6560031 04C52132
	ds_load_2addr_b32 v[50:51], v43 offset0:144 offset1:168    // 000000458710: D8DCA890 3200002B
	v_and_or_b32 v56, 0xffff, v56, v57                         // 000000458718: D6570038 04E670FF 0000FFFF
	v_and_b32_e32 v57, 0xffff, v52                             // 000000458724: 367268FF 0000FFFF
	ds_load_2addr_b32 v[52:53], v46 offset0:144 offset1:168    // 00000045872C: D8DCA890 3400002E
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000458734: D622003B 03FD013B 00006400
	v_pk_fma_f16 v49, v49, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000458740: CC0E0031 0BFC0D31 0000C931
	v_sad_u8 v61, v55, 0, 0x6400                               // 00000045874C: D622003D 03FD0137 00006400
	v_pk_fma_f16 v62, v56, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000458758: CC0E003E 0BFC0D38 0000C931
	ds_load_2addr_b32 v[55:56], v45 offset0:144 offset1:168    // 000000458764: D8DCA890 3700002D
	v_lshl_or_b32 v57, v59, 16, v57                            // 00000045876C: D6560039 04E5213B
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000458774: D6220036 03FD0136 00006400
	v_lshlrev_b32_e32 v59, 16, v61                             // 000000458780: 30767A90
	v_dot2acc_f32_f16 v32, v49, v1                             // 000000458784: 04400331
	v_dual_dot2acc_f32_f16 v33, v49, v5 :: v_dual_dot2acc_f32_f16 v22, v60, v3// 000000458788: CB180B31 2116073C
	s_waitcnt lgkmcnt(3)                                       // 000000458790: BF89FC37
	v_mov_b32_e32 v49, v47                                     // 000000458794: 7E62032F
	v_and_or_b32 v54, 0xffff, v54, v59                         // 000000458798: D6570036 04EE6CFF 0000FFFF
	v_pk_fma_f16 v47, v57, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004587A4: CC0E002F 0BFC0D39 0000C931
	v_dot2acc_f32_f16 v32, v62, v2                             // 0000004587B0: 0440053E
	v_dot2acc_f32_f16 v33, v62, v6                             // 0000004587B4: 04420D3E
	s_waitcnt lgkmcnt(2)                                       // 0000004587B8: BF89FC27
	.long 0xd73d0031                                           // 0000004587BC: D73D0031
	v_cndmask_b32_e32 v1, v37, v49, vcc_lo                     // 0000004587C0: 02026325
	v_pk_fma_f16 v50, v54, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004587C4: CC0E0032 0BFC0D36 0000C931
	s_waitcnt lgkmcnt(1)                                       // 0000004587D0: BF89FC17
	v_mov_b32_e32 v54, v52                                     // 0000004587D4: 7E6C0334
	v_dual_dot2acc_f32_f16 v22, v58, v4 :: v_dual_dot2acc_f32_f16 v33, v47, v7// 0000004587D8: CB18093A 16200F2F
	v_dot2acc_f32_f16 v32, v47, v3                             // 0000004587E0: 0440072F
	v_and_b32_e32 v52, 0xffff, v49                             // 0000004587E4: 366862FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 0000004587EC: BF89FC07
	.long 0xd73d0036                                           // 0000004587F0: D73D0036
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 0000004587F4: 02026D26
	v_bfe_u32 v47, v49, 9, 16                                  // 0000004587F8: D610002F 02411331
	v_dot2acc_f32_f16 v33, v50, v8                             // 000000458800: 04421132
	v_dot2acc_f32_f16 v32, v50, v4                             // 000000458804: 04400932
	v_bfe_u32 v50, v49, 6, 16                                  // 000000458808: D6100032 02410D31
	v_bfe_u32 v49, v49, 3, 16                                  // 000000458810: D6100031 02410731
	.long 0xd72c0034                                           // 000000458818: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 00000045881C: 020268FF 83DCD12D
	.long 0xd72c002f                                           // 000000458824: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000458828: 02025EFF 83DCD12D
	v_bfe_u32 v55, v54, 9, 16                                  // 000000458830: D6100037 02411336
	.long 0xd72c0032                                           // 000000458838: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 00000045883C: 020264FF 83DCD12D
	.long 0xd72c0031                                           // 000000458844: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000458848: 020262FF 83DCD12D
	v_and_b32_e32 v58, 0xffff, v54                             // 000000458850: 36746CFF 0000FFFF
	v_bfe_u32 v57, v54, 6, 16                                  // 000000458858: D6100039 02410D36
	.long 0xd72c0037                                           // 000000458860: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000458864: 02026EFF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 00000045886C: D6220034 03FD0134 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000458878: D622002F 03FD012F 00006400
	v_bfe_u32 v54, v54, 3, 16                                  // 000000458884: D6100036 02410736
	.long 0xd72c003a                                           // 00000045888C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000458890: 020274FF 83DCD12D
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000458898: D6220031 03FD0131 00006400
	v_lshlrev_b32_e32 v52, 16, v52                             // 0000004588A4: 30686890
	v_and_b32_e32 v47, 0xffff, v47                             // 0000004588A8: 365E5EFF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000004588B0: D6220032 03FD0132 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000004588BC: D6220037 03FD0137 00006400
	.long 0xd72c0036                                           // 0000004588C8: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000004588CC: 02026CFF 83DCD12D
	v_and_or_b32 v52, 0xffff, v49, v52                         // 0000004588D4: D6570034 04D262FF 0000FFFF
	.long 0xd72c0039                                           // 0000004588E0: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000004588E4: 020272FF 83DCD12D
	v_lshl_or_b32 v47, v50, 16, v47                            // 0000004588EC: D656002F 04BD2132
	v_mov_b32_e32 v49, v51                                     // 0000004588F4: 7E620333
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000004588F8: BF8701D4
	v_pk_fma_f16 v52, v52, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004588FC: CC0E0034 0BFC0D34 0000C931
	v_and_b32_e32 v50, 0xffff, v55                             // 000000458908: 36646EFF 0000FFFF
	v_sad_u8 v55, v58, 0, 0x6400                               // 000000458910: D6220037 03FD013A 00006400
	v_sad_u8 v51, v54, 0, 0x6400                               // 00000045891C: D6220033 03FD0136 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000458928: D6220039 03FD0139 00006400
	v_lshlrev_b32_e32 v54, 16, v55                             // 000000458934: 306C6E90
	v_pk_fma_f16 v55, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000458938: CC0E0037 0BFC0D2F 0000C931
	.long 0xd73d002f                                           // 000000458944: D73D002F
	v_cndmask_b32_e32 v1, v37, v48, vcc_lo                     // 000000458948: 02026125
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045894C: BF870193
	v_and_or_b32 v48, 0xffff, v51, v54                         // 000000458950: D6570030 04DA66FF 0000FFFF
	v_dot2acc_f32_f16 v35, v55, v5                             // 00000045895C: 04460B37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000458960: BF870113
	v_bfe_u32 v51, v47, 9, 16                                  // 000000458964: D6100033 0241132F
	v_dot2acc_f32_f16 v35, v52, v6                             // 00000045896C: 04460D34
	v_lshl_or_b32 v50, v57, 16, v50                            // 000000458970: D6560032 04C92139
	v_and_b32_e32 v57, 0xffff, v47                             // 000000458978: 36725EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000458980: BF8701B2
	v_pk_fma_f16 v50, v50, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000458984: CC0E0032 0BFC0D32 0000C931
	v_mov_b32_e32 v54, v56                                     // 000000458990: 7E6C0338
	v_pk_fma_f16 v56, v48, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000458994: CC0E0038 0BFC0D30 0000C931
	v_dot2acc_f32_f16 v35, v50, v7                             // 0000004589A0: 04460F32
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004589A4: BF870003
	.long 0xd73d0030                                           // 0000004589A8: D73D0030
	v_cndmask_b32_e32 v1, v38, v53, vcc_lo                     // 0000004589AC: 02026B26
	.long 0xd72c0031                                           // 0000004589B0: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000004589B4: 020266FF 83DCD12D
	v_bfe_u32 v51, v47, 6, 16                                  // 0000004589BC: D6100033 02410D2F
	v_bfe_u32 v47, v47, 3, 16                                  // 0000004589C4: D610002F 0241072F
	.long 0xd72c0035                                           // 0000004589CC: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000004589D0: 020272FF 83DCD12D
	v_dot2acc_f32_f16 v35, v56, v8                             // 0000004589D8: 04461138
	v_bfe_u32 v54, v48, 9, 16                                  // 0000004589DC: D6100036 02411330
	.long 0xd72c0033                                           // 0000004589E4: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000004589E8: 020266FF 83DCD12D
	v_bfe_u32 v57, v48, 6, 16                                  // 0000004589F0: D6100039 02410D30
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000004589F8: D6220031 03FD0131 00006400
	.long 0xd72c002f                                           // 000000458A04: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000458A08: 02025EFF 83DCD12D
	.long 0xd72c0036                                           // 000000458A10: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000458A14: 02026CFF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000458A1C: D6220035 03FD0135 00006400
	.long 0xd72c0039                                           // 000000458A28: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000458A2C: 020272FF 83DCD12D
	v_and_b32_e32 v49, 0xffff, v49                             // 000000458A34: 366262FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000458A3C: D6220033 03FD0133 00006400
	v_bfe_u32 v58, v48, 3, 16                                  // 000000458A48: D610003A 02410730
	v_and_b32_e32 v48, 0xffff, v48                             // 000000458A50: 366060FF 0000FFFF
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000458A58: D622002F 03FD012F 00006400
	v_lshlrev_b32_e32 v53, 16, v53                             // 000000458A64: 306A6A90
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000458A68: D6220036 03FD0136 00006400
	v_lshl_or_b32 v49, v51, 16, v49                            // 000000458A74: D6560031 04C52133
	.long 0xd72c0030                                           // 000000458A7C: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000458A80: 020260FF 83DCD12D
	.long 0xd72c0033                                           // 000000458A88: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000458A8C: 020274FF 83DCD12D
	v_and_or_b32 v47, 0xffff, v47, v53                         // 000000458A94: D657002F 04D65EFF 0000FFFF
	v_and_b32_e32 v53, 0xffff, v54                             // 000000458AA0: 366A6CFF 0000FFFF
	v_sad_u8 v54, v57, 0, 0x6400                               // 000000458AA8: D6220036 03FD0139 00006400
	v_pk_fma_f16 v49, v49, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000458AB4: CC0E0031 0BFC0D31 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000458AC0: BF870224
	v_pk_fma_f16 v47, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000458AC4: CC0E002F 0BFC0D2F 0000C931
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000458AD0: D6220030 03FD0130 00006400
	v_lshl_or_b32 v53, v54, 16, v53                            // 000000458ADC: D6560035 04D52136
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000458AE4: BF8701B4
	v_dot2acc_f32_f16 v15, v49, v5                             // 000000458AE8: 041E0B31
	v_dot2acc_f32_f16 v36, v49, v1                             // 000000458AEC: 04480331
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000458AF0: D6220033 03FD0133 00006400
	v_dual_dot2acc_f32_f16 v15, v47, v6 :: v_dual_lshlrev_b32 v48, 16, v48// 000000458AFC: CB220D2F 0F306090
	v_dot2acc_f32_f16 v34, v55, v1                             // 000000458B04: 04440337
	v_pk_fma_f16 v1, v53, s6, 0xc931 op_sel_hi:[1,0,0]         // 000000458B08: CC0E0001 0BFC0D35 0000C931
	v_dot2acc_f32_f16 v36, v47, v2                             // 000000458B14: 0448052F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000458B18: BF870194
	v_and_or_b32 v5, 0xffff, v51, v48                          // 000000458B1C: D6570005 04C266FF 0000FFFF
	v_dual_dot2acc_f32_f16 v15, v1, v7 :: v_dual_dot2acc_f32_f16 v34, v52, v2// 000000458B28: CB180F01 0F220534
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000458B30: BF870193
	v_dual_dot2acc_f32_f16 v36, v1, v3 :: v_dual_add_nc_u32 v1, v40, v41// 000000458B34: CB200701 24005328
	v_pk_fma_f16 v2, v5, s6, 0xc931 op_sel_hi:[1,0,0]          // 000000458B3C: CC0E0002 0BFC0D05 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000458B48: BF870193
	v_dot2acc_f32_f16 v34, v50, v3                             // 000000458B4C: 04440732
	v_cmp_eq_u32_e32 vcc_lo, 1, v1                             // 000000458B50: 7C940281
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000458B54: BF870223
	v_dot2acc_f32_f16 v36, v2, v4                              // 000000458B58: 04480902
	v_dot2acc_f32_f16 v15, v2, v8                              // 000000458B5C: 041E1102
	v_dot2acc_f32_f16 v34, v56, v4                             // 000000458B60: 04440938
	s_or_b32 s5, vcc_lo, s5                                    // 000000458B64: 8C05056A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000458B68: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000458B6C: 917E057E
	s_cbranch_execz 27                                         // 000000458B70: BFA5001B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ae0>
	s_mov_b32 s0, exec_lo                                      // 000000458B74: BE80007E
	s_waitcnt vmcnt(4)                                         // 000000458B78: BF8913F7
	ds_store_2addr_b32 v42, v17, v18 offset1:32                // 000000458B7C: D8382000 0012112A
	s_waitcnt vmcnt(2)                                         // 000000458B84: BF890BF7
	ds_store_2addr_b32 v42, v19, v20 offset0:64 offset1:96     // 000000458B88: D8386040 0014132A
	s_waitcnt vmcnt(0)                                         // 000000458B90: BF8903F7
	ds_store_2addr_b32 v42, v21, v25 offset0:128 offset1:160   // 000000458B94: D838A080 0019152A
	.long 0xd4c1007e                                           // 000000458B9C: D4C1007E
	v_cndmask_b32_e32 v1, v41, v16, vcc_lo                     // 000000458BA0: 02022129
	s_cbranch_execz 64559                                      // 000000458BA4: BFA5FC2F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb64>
	s_clause 0x5                                               // 000000458BA8: BF850005
	global_load_b32 v17, v[9:10], off                          // 000000458BAC: DC520000 117C0009
	global_load_b32 v18, v[9:10], off offset:128               // 000000458BB4: DC520080 127C0009
	global_load_b32 v19, v[9:10], off offset:256               // 000000458BBC: DC520100 137C0009
	global_load_b32 v20, v[9:10], off offset:384               // 000000458BC4: DC520180 147C0009
	global_load_b32 v21, v[9:10], off offset:512               // 000000458BCC: DC520200 157C0009
	global_load_b32 v25, v[9:10], off offset:640               // 000000458BD4: DC520280 197C0009
	s_branch 64545                                             // 000000458BDC: BFA0FC21 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb64>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000458BE0: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000458BE4: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000458BE8: 8C7E017E
	v_dual_mov_b32 v1, v14 :: v_dual_mov_b32 v6, v28           // 000000458BEC: CA10010E 0106011C
	v_dual_mov_b32 v2, v26 :: v_dual_mov_b32 v3, v27           // 000000458BF4: CA10011A 0202011B
	v_dual_mov_b32 v4, v24 :: v_dual_mov_b32 v5, v23           // 000000458BFC: CA100118 04040117
	v_dual_mov_b32 v8, v29 :: v_dual_mov_b32 v9, v30           // 000000458C04: CA10011D 0808011E
	v_dual_mov_b32 v7, v22 :: v_dual_mov_b32 v10, v31          // 000000458C0C: CA100116 070A011F
	s_waitcnt vmcnt(5)                                         // 000000458C14: BF8917F7
	v_dual_mov_b32 v16, v32 :: v_dual_mov_b32 v17, v33         // 000000458C18: CA100120 10100121
	s_waitcnt vmcnt(3)                                         // 000000458C20: BF890FF7
	v_dual_mov_b32 v18, v34 :: v_dual_mov_b32 v19, v35         // 000000458C24: CA100122 12120123
	s_waitcnt vmcnt(1)                                         // 000000458C2C: BF8907F7
	v_dual_mov_b32 v20, v36 :: v_dual_mov_b32 v21, v15         // 000000458C30: CA100124 1414010F
	s_mov_b32 s0, 0x76543210                                   // 000000458C38: BE8000FF 76543210
	s_waitcnt vmcnt(0)                                         // 000000458C40: BF8903F7
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000458C44: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000458C50: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000458C5C: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000458C68: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000458C74: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000458C80: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000458C8C: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000458C98: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000458CA4: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000458CB0: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000458CBC: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000458CC8: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 000000458CD4: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 000000458CE0: D65C0013 03FC0113 FEDCBA98
	v_permlanex16_b32 v20, v20, s0, 0xfedcba98                 // 000000458CEC: D65C0014 03FC0114 FEDCBA98
	v_permlanex16_b32 v21, v21, s0, 0xfedcba98                 // 000000458CF8: D65C0015 03FC0115 FEDCBA98
	.long 0xd44c0000                                           // 000000458D04: D44C0000
	v_cndmask_b32_e32 v1, 16, v13, vcc_lo                      // 000000458D08: 02021A90
	s_barrier                                                  // 000000458D0C: BFBD0000
	buffer_gl0_inv                                             // 000000458D10: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000458D18: BE812000
	s_cbranch_execz 34                                         // 000000458D1C: BFA50022 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ca8>
	v_dual_add_f32 v3, v27, v3 :: v_dual_add_f32 v2, v26, v2   // 000000458D20: C908071B 0302051A
	v_dual_add_f32 v1, v14, v1 :: v_dual_add_f32 v4, v24, v4   // 000000458D28: C908030E 01040918
	v_lshl_or_b32 v12, v11, 10, v12                            // 000000458D30: D656000C 0431150B
	v_dual_add_f32 v17, v33, v17 :: v_dual_add_f32 v6, v28, v6 // 000000458D38: C9082321 11060D1C
	v_dual_add_f32 v9, v30, v9 :: v_dual_add_f32 v8, v29, v8   // 000000458D40: C908131E 0908111D
	v_add_f32_e32 v5, v23, v5                                  // 000000458D48: 060A0B17
	v_dual_add_f32 v19, v35, v19 :: v_dual_add_f32 v16, v32, v16// 000000458D4C: C9082723 13102120
	v_add_f32_e32 v7, v22, v7                                  // 000000458D54: 060E0F16
	v_dual_add_f32 v13, v15, v21 :: v_dual_add_f32 v18, v34, v18// 000000458D58: C9082B0F 0D122522
	v_dual_add_f32 v15, v36, v20 :: v_dual_add_f32 v10, v31, v10// 000000458D60: C9082924 0F0A151F
	ds_store_2addr_b32 v12, v1, v3 offset1:16                  // 000000458D68: D8381000 0003010C
	ds_store_2addr_b32 v12, v2, v6 offset0:128 offset1:144     // 000000458D70: D8389080 0006020C
	ds_store_2addr_b32 v12, v4, v8 offset0:32 offset1:48       // 000000458D78: D8383020 0008040C
	ds_store_2addr_b32 v12, v5, v9 offset0:160 offset1:176     // 000000458D80: D838B0A0 0009050C
	ds_store_2addr_b32 v12, v7, v16 offset0:64 offset1:80      // 000000458D88: D8385040 0010070C
	ds_store_2addr_b32 v12, v10, v17 offset0:192 offset1:208   // 000000458D90: D838D0C0 00110A0C
	ds_store_2addr_b32 v12, v18, v15 offset0:96 offset1:112    // 000000458D98: D8387060 000F120C
	ds_store_2addr_b32 v12, v19, v13 offset0:224 offset1:240   // 000000458DA0: D838F0E0 000D130C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000458DA8: 8C7E017E
	.long 0xd44c0001                                           // 000000458DAC: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000458DB0: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000458DB8: BF89FC07
	s_barrier                                                  // 000000458DBC: BFBD0000
	buffer_gl0_inv                                             // 000000458DC0: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000458DC8: BE852001
	s_cbranch_execnz 7                                         // 000000458DCC: BFA60007 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1cec>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000458DD0: 8C7E057E
	s_cmp_lt_i32 s27, 2                                        // 000000458DD4: BF04821B
	s_mov_b32 s5, -1                                           // 000000458DD8: BE8500C1
	s_cbranch_scc0 33                                          // 000000458DDC: BFA10021 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d64>
	s_and_b32 vcc_lo, exec_lo, s5                              // 000000458DE0: 8B6A057E
	s_cbranch_vccnz 202                                        // 000000458DE4: BFA400CA <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2010>
	s_endpgm                                                   // 000000458DE8: BFB00000
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000458DEC: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 000000458DF0: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 000000458DF8: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 000000458E00: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000458E08: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000458E0C: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000458E10: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000458E14: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000458E18: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000458E1C: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 000000458E20: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000458E28: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000458E2C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000458E30: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000458E34: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000458E38: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000458E3C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000458E40: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000458E44: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000458E48: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 000000458E4C: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 000000458E54: 8C7E057E
	s_cmp_lt_i32 s27, 2                                        // 000000458E58: BF04821B
	s_mov_b32 s5, -1                                           // 000000458E5C: BE8500C1
	s_cbranch_scc1 65503                                       // 000000458E60: BFA2FFDF <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ce0>
	s_waitcnt lgkmcnt(0)                                       // 000000458E64: BF89FC07
	s_barrier                                                  // 000000458E68: BFBD0000
	buffer_gl0_inv                                             // 000000458E6C: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000458E74: BE852001
	s_cbranch_execz 41                                         // 000000458E78: BFA50029 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e20>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000458E7C: 32020087
	s_ashr_i32 s6, s26, 31                                     // 000000458E80: 86069F1A
	v_lshlrev_b32_e32 v4, 2, v0                                // 000000458E84: 30080082
	s_delay_alu instid0(VALU_DEP_2)                            // 000000458E88: BF870002
	v_lshl_or_b32 v1, s4, 1, v1                                // 000000458E8C: D6560001 04050204
	s_ashr_i32 s4, s4, 31                                      // 000000458E94: 86049F04
	ds_load_b32 v4, v4 offset:8192                             // 000000458E98: D8D82000 04000004
	s_mul_i32 s4, s4, s26                                      // 000000458EA0: 96041A04
	.long 0xd72c0003                                           // 000000458EA4: D72C0003
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000458EA8: 02000D01
	v_mad_u64_u32 v[1:2], null, v1, s26, 0                     // 000000458EAC: D6FE7C01 02003501
	s_lshl_b32 s6, s2, 7                                       // 000000458EB4: 84068702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000458EB8: BF870499
	s_ashr_i32 s7, s6, 31                                      // 000000458EBC: 86079F06
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000458EC0: 84868206
	v_add3_u32 v2, v2, v3, s4                                  // 000000458EC4: D6550002 00120702
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000458ECC: 360600FF 0000007F
	s_add_u32 s4, s16, s6                                      // 000000458ED4: 80040610
	s_addc_u32 s6, s17, s7                                     // 000000458ED8: 82060711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000458EDC: BF870112
	.long 0xd73c0001                                           // 000000458EE0: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000458EE4: 02020282
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000458EE8: 30060682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000458EEC: BF870092
	.long 0xd7006a01                                           // 000000458EF0: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000458EF4: 02020204
	v_add_co_ci_u32_e64 v2, null, s6, v2, vcc_lo               // 000000458EF8: D5207C02 01AA0406
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000458F00: BF870092
	.long 0xd7006a01                                           // 000000458F04: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000458F08: 02020701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000458F0C: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 000000458F14: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 000000458F18: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s5                              // 000000458F20: 8C7E057E
	.long 0xd44a0004                                           // 000000458F24: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000458F28: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000458F2C: BC7C0000
	buffer_gl1_inv                                             // 000000458F30: E0B00000 00000000
	buffer_gl0_inv                                             // 000000458F38: E0AC0000 00000000
	s_barrier                                                  // 000000458F40: BFBD0000
	buffer_gl0_inv                                             // 000000458F44: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000458F4C: BE852004
	s_cbranch_execz 29                                         // 000000458F50: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ec8>
	s_mov_b32 s7, exec_lo                                      // 000000458F54: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000458F58: BE86007E
	.long 0xd71f0001                                           // 000000458F5C: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 000000458F60: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000458F64: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000458F68: 7D940280
	s_cbranch_execz 9                                          // 000000458F6C: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e94>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 000000458F70: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000458F74: BF8704B9
	s_add_u32 s8, s18, s8                                      // 000000458F78: 80080812
	s_addc_u32 s9, s19, s9                                     // 000000458F7C: 82090913
	s_bcnt1_i32_b32 s7, s7                                     // 000000458F80: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 000000458F84: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 000000458F8C: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 000000458F94: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000458F98: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 000000458F9C: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000458FA0: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 000000458FA4: CA200080 02000206
	s_add_i32 s6, s27, -1                                      // 000000458FAC: 8106C11B
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000458FB0: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 000000458FB4: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000458FB8: D5010001 01A90280
	ds_store_b32 v2, v1 offset:16640                           // 000000458FC0: D8344100 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 000000458FC8: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 000000458FCC: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000458FD0: BF89FC07
	s_barrier                                                  // 000000458FD4: BFBD0000
	buffer_gl0_inv                                             // 000000458FD8: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:16640                            // 000000458FE0: D8D84100 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000458FE8: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000458FEC: 7C940280
	s_cbranch_vccnz 70                                         // 000000458FF0: BFA40046 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x200c>
	buffer_gl1_inv                                             // 000000458FF4: E0B00000 00000000
	buffer_gl0_inv                                             // 000000458FFC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000459004: BE852001
	s_cbranch_execz 52                                         // 000000459008: BFA50034 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1fdc>
	v_and_b32_e32 v2, 0x7f, v0                                 // 00000045900C: 360400FF 0000007F
	s_lshl_b32 s6, s2, 7                                       // 000000459014: 84068702
	s_ashr_i32 s1, s26, 31                                     // 000000459018: 86019F1A
	s_ashr_i32 s7, s6, 31                                      // 00000045901C: 86079F06
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000459020: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 000000459024: CA220080 02020482
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000045902C: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000459030: BF8700A9
	s_add_u32 s6, s16, s6                                      // 000000459034: 80060610
	s_addc_u32 s7, s17, s7                                     // 000000459038: 82070711
	.long 0xd7000603                                           // 00000045903C: D7000603
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 000000459040: 02020606
	s_delay_alu instid0(VALU_DEP_1)                            // 000000459044: BF870001
	v_add_co_ci_u32_e64 v4, null, s7, 0, s6                    // 000000459048: D5207C04 00190007
	s_nop 0                                                    // 000000459050: BF800000
	s_nop 0                                                    // 000000459054: BF800000
	s_nop 0                                                    // 000000459058: BF800000
	s_nop 0                                                    // 00000045905C: BF800000
	s_nop 0                                                    // 000000459060: BF800000
	s_nop 0                                                    // 000000459064: BF800000
	s_nop 0                                                    // 000000459068: BF800000
	s_nop 0                                                    // 00000045906C: BF800000
	s_nop 0                                                    // 000000459070: BF800000
	s_nop 0                                                    // 000000459074: BF800000
	s_nop 0                                                    // 000000459078: BF800000
	s_nop 0                                                    // 00000045907C: BF800000
	v_mad_u64_u32 v[5:6], null, v1, s26, 0                     // 000000459080: D6FE7C05 02003501
	s_add_i32 s27, s27, -1                                     // 000000459088: 811BC11B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000045908C: BF870139
	s_cmp_eq_u32 s27, 0                                        // 000000459090: BF06801B
	v_mad_u64_u32 v[6:7], null, v1, s1, v[6:7]                 // 000000459094: D6FE7C06 04180301
	v_add_nc_u32_e32 v1, 2, v1                                 // 00000045909C: 4A020282
	.long 0xd73c0005                                           // 0000004590A0: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000004590A4: 02020A82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004590A8: BF870091
	.long 0xd7006a05                                           // 0000004590AC: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000004590B0: 02020B03
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 0000004590B4: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 0000004590BC: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000004590C4: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 0000004590C8: 06040B02
	s_cbranch_scc0 65516                                       // 0000004590CC: BFA1FFEC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f80>
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000004590D0: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 0000004590D4: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s5                              // 0000004590DC: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 0000004590E0: BE812004
	s_cbranch_execz 6                                          // 0000004590E4: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2000>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 0000004590E8: 84848202
	v_mov_b32_e32 v1, 0                                        // 0000004590EC: 7E020280
	s_add_u32 s4, s18, s4                                      // 0000004590F0: 80040412
	s_addc_u32 s5, s19, s5                                     // 0000004590F4: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 0000004590F8: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000459100: 8C7E017E
	s_cbranch_execz 65336                                      // 000000459104: BFA5FF38 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ce8>
	s_branch 1                                                 // 000000459108: BFA00001 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2010>
	s_branch 65334                                             // 00000045910C: BFA0FF36 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ce8>
	v_cmp_gt_i32_e32 vcc_lo, s24, v11                          // 000000459110: 7C881618
	.long 0xd44c0001                                           // 000000459114: D44C0001
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 000000459118: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 00000045911C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000459120: BC7C0000
	s_barrier                                                  // 000000459124: BFBD0000
	buffer_gl0_inv                                             // 000000459128: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 000000459130: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000459134: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000459138: BE832001
	s_cbranch_execz 65322                                      // 00000045913C: BFA5FF2A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ce8>
	v_and_b32_e32 v1, 15, v0                                   // 000000459140: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000459144: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000459148: 30040282
	v_lshl_or_b32 v2, v11, 9, v2                               // 00000045914C: D6560002 0409130B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000459154: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 000000459158: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 000000459160: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000459168: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 000000459170: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000459178: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000459180: 36140081
	s_waitcnt lgkmcnt(3)                                       // 000000459184: BF89FC37
	v_dual_add_f32 v14, v2, v3 :: v_dual_and_b32 v13, 4, v0    // 000000459188: C9240702 0E0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000459190: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000459194: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000045919C: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000004591A0: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000004591A8: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 0000004591AC: C9480F06 06061308
	v_sub_f32_e32 v8, v8, v9                                   // 0000004591B4: 08101308
	v_dual_add_f32 v9, v14, v3 :: v_dual_and_b32 v12, 2, v0    // 0000004591B8: C924070E 090C0082
	v_sub_f32_e32 v3, v14, v3                                  // 0000004591C0: 0806070E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004591C4: BF8701B4
	v_dual_add_f32 v14, v2, v4 :: v_dual_add_f32 v15, v5, v7   // 0000004591C8: C9080902 0E0E0F05
	v_sub_f32_e32 v2, v2, v4                                   // 0000004591D0: 08040902
	v_dual_add_f32 v4, v6, v8 :: v_dual_sub_f32 v5, v5, v7     // 0000004591D4: C90A1106 04040F05
	v_dual_sub_f32 v6, v6, v8 :: v_dual_add_f32 v7, v9, v15    // 0000004591DC: C9481106 06061F09
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004591E4: BF870222
	v_dual_sub_f32 v8, v9, v15 :: v_dual_add_f32 v9, v14, v4   // 0000004591E8: C9481F09 0808090E
	v_sub_f32_e32 v4, v14, v4                                  // 0000004591F0: 0808090E
	v_add_f32_e32 v14, v3, v5                                  // 0000004591F4: 061C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 0000004591F8: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 0000004591FC: 060A0D02
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000459200: 7C941480
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000459204: 7E1402FA FF016109
	v_mov_b32_dpp v18, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000045920C: 7E2402FA FF016104
	v_mov_b32_dpp v15, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000459214: 7E1E02FA FF01610E
	v_mov_b32_dpp v16, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000045921C: 7E2002FA FF016105
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000459224: D5010009 21AA1309
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000045922C: D5010005 21AA0B05
	v_sub_f32_e32 v2, v2, v6                                   // 000000459234: 08040D02
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000459238: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000459240: D501000E 21AA1D0E
	v_mov_b32_dpp v17, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000459248: 7E2202FA FF016108
	v_add_f32_e32 v5, v5, v16                                  // 000000459250: 060A2105
	v_mov_b32_dpp v21, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000459254: 7E2A02FA FF016102
	v_cndmask_b32_e64 v22, -v2, v2, vcc_lo                     // 00000045925C: D5010016 21AA0502
	v_add_f32_e32 v2, v9, v10                                  // 000000459264: 06041509
	v_add_f32_e32 v9, v4, v18                                  // 000000459268: 06122504
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000045926C: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000459274: D5010007 21AA0F07
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000045927C: D5010008 21AA1108
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000459284: 7E2602FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 00000045928C: D5010014 21AA0703
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 000000459294: 7C941880
	v_add_f32_e32 v3, v7, v6                                   // 000000459298: 06060D07
	.long 0xd44a0001                                           // 00000045929C: D44A0001
	v_cndmask_b32_e32 v1, 0, v13, vcc_lo                       // 0000004592A0: 02021A80
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004592A4: 7E1802FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004592AC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004592B4: BF8700A4
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004592B8: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000004592C0: D5010003 21AA0703
	v_add_f32_e32 v3, v3, v4                                   // 0000004592C8: 06060903
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004592CC: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000004592D4: D5010002 21AA0502
	v_add_f32_e32 v4, v5, v12                                  // 0000004592DC: 06081905
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004592E0: BF8700A4
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004592E4: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000004592EC: D5010003 20060703
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v3, v3, v5     // 0000004592F4: C9080F02 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004592FC: BF870001
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 000000459300: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000459308: 7E0402FA FF016402
	v_add_f32_e32 v6, v14, v15                                 // 000000459310: 060C1F0E
	v_add_f32_e32 v14, v22, v21                                // 000000459314: 061C2B16
	v_mov_b32_dpp v15, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000459318: 7E1E02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000459320: D5010009 21AA1309
	v_add_f32_e32 v7, v7, v2                                   // 000000459328: 060E0507
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000045932C: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000459334: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000045933C: BF870234
	v_dual_add_f32 v8, v8, v17 :: v_dual_add_f32 v9, v9, v15   // 000000459340: C9082308 08081F09
	v_mov_b32_dpp v16, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000459348: 7E2002FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000459350: D501000E 21AA1D0E
	v_add_f32_e32 v6, v6, v10                                  // 000000459358: 060C1506
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000045935C: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000459364: D5010004 20060904
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000045936C: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000459374: D5010008 21AA1108
	v_mov_b32_dpp v12, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000045937C: 7E1802FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000459384: D5010006 20060D06
	v_add_f32_e32 v4, v4, v10                                  // 00000045938C: 06081504
	v_add_f32_e32 v10, v20, v19                                // 000000459390: 06142714
	v_add_f32_e32 v8, v8, v13                                  // 000000459394: 06101B08
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000459398: 7E0402FA FF016803
	v_add_f32_e32 v6, v6, v12                                  // 0000004593A0: 060C1906
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004593A4: 7E0A02FA FF016807
	v_mov_b32_dpp v13, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004593AC: 7E1A02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000004593B4: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004593BC: 7E1802FA FF016408
	v_cndmask_b32_e64 v15, -v8, v8, s1                         // 0000004593C4: D501000F 20061108
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004593CC: 7E1002FA FF016806
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004593D4: BF870004
	v_add_f32_e32 v10, v10, v13                                // 0000004593D8: 06141B0A
	v_add_f32_e32 v13, v14, v16                                // 0000004593DC: 061A210E
	v_mov_b32_dpp v14, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004593E0: 7E1C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000004593E8: D5010009 20061309
	v_add_f32_e32 v15, v15, v12                                // 0000004593F0: 061E190F
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004593F4: 7E2002FA FF01640A
	v_mov_b32_dpp v18, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004593FC: 7E2402FA FF01640D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000459404: D501000A 2006150A
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 00000045940C: D501000D 20061B0D
	v_add_f32_e32 v17, v9, v14                                 // 000000459414: 06221D09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000459418: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000459420: BF870214
	v_add_f32_e32 v16, v10, v16                                // 000000459424: 0620210A
	v_add_f32_e32 v18, v13, v18                                // 000000459428: 0624250D
	v_mov_b32_dpp v10, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000045942C: 7E1402FA FF01680F
	v_mov_b32_dpp v12, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000459434: 7E1802FA FF016811
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045943C: BF870214
	v_mov_b32_dpp v13, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000459440: 7E1A02FA FF016810
	v_mov_b32_dpp v14, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000459448: 7E1C02FA FF016812
	s_and_b32 exec_lo, exec_lo, s0                             // 000000459450: 8B7E007E
	s_cbranch_execz 65124                                      // 000000459454: BFA5FE64 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ce8>
	v_lshl_or_b32 v19, s2, 7, v1                               // 000000459458: D6560013 04050E02
	.long 0x7f2e3880                                           // 000000459460: 7F2E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000459464: BF870112
	v_ashrrev_i32_e32 v20, 31, v19                             // 000000459468: 3428269F
	.long 0x7f303997                                           // 00000045946C: 7F303997
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000459470: BF870092
	.long 0xd73c0013                                           // 000000459474: D73C0013
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000459478: 02022681
	.long 0xd7006a15                                           // 00000045947C: D7006A15
	v_cndmask_b32_e32 v1, s14, v19, vcc_lo                     // 000000459480: 0202260E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000459484: BF870001
	v_add_co_ci_u32_e64 v22, null, s15, v20, vcc_lo            // 000000459488: D5207C16 01AA280F
	s_clause 0x7                                               // 000000459490: BF850007
	global_load_d16_b16 v23, v[21:22], off offset:32           // 000000459494: DC820020 177C0015
	global_load_d16_b16 v24, v[21:22], off                     // 00000045949C: DC820000 187C0015
	global_load_d16_b16 v25, v[21:22], off offset:64           // 0000004594A4: DC820040 197C0015
	global_load_d16_b16 v26, v[21:22], off offset:96           // 0000004594AC: DC820060 1A7C0015
	global_load_d16_b16 v27, v[21:22], off offset:128          // 0000004594B4: DC820080 1B7C0015
	global_load_d16_b16 v28, v[21:22], off offset:160          // 0000004594BC: DC8200A0 1C7C0015
	global_load_d16_b16 v29, v[21:22], off offset:192          // 0000004594C4: DC8200C0 1D7C0015
	global_load_d16_b16 v21, v[21:22], off offset:224          // 0000004594CC: DC8200E0 157C0015
	v_and_b32_e32 v22, 8, v0                                   // 0000004594D4: 362C0088
	v_mad_i64_i32 v[0:1], null, s26, v11, 0                    // 0000004594D8: D6FF7C00 0202161A
	s_waitcnt vmcnt(7)                                         // 0000004594E0: BF891FF7
	.long 0x7f163997                                           // 0000004594E4: 7F163997
	s_waitcnt vmcnt(0)                                         // 0000004594E8: BF8903F7
	.long 0x7f2a3997                                           // 0000004594EC: 7F2A3997
	v_cmp_eq_u32_e32 vcc_lo, 0, v22                            // 0000004594F0: 7C942C80
	.long 0x7f2c3997                                           // 0000004594F4: 7F2C3997
	.long 0xd73c0000                                           // 0000004594F8: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000004594FC: 02020081
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000459500: D5010007 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000459508: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000459510: D5010004 21AA0904
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000459518: D5010006 21AA0D06
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 000000459520: D5010010 21AA2110
	v_add_f32_e32 v5, v7, v5                                   // 000000459528: 060A0B07
	v_cndmask_b32_e64 v7, -v17, v17, vcc_lo                    // 00000045952C: D5010007 21AA2311
	v_cndmask_b32_e64 v17, -v18, v18, vcc_lo                   // 000000459534: D5010011 21AA2512
	v_add_f32_e32 v2, v3, v2                                   // 00000045953C: 06040503
	v_add_f32_e32 v4, v4, v9                                   // 000000459540: 06081304
	v_mul_f32_e32 v3, 0x3db504f3, v5                           // 000000459544: 10060AFF 3DB504F3
	v_add_f32_e32 v5, v6, v8                                   // 00000045954C: 060A1106
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000459550: D501000F 21AA1F0F
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v8, v16, v13  // 000000459558: C9081907 07081B10
	v_dual_add_f32 v9, v17, v14 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000459560: C9061D11 090408FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045956C: BF870212
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 000000459570: C8C604FF 02060EFF 3DB504F3
	v_dual_add_f32 v6, v15, v10 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 00000045957C: C906150F 06040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000459588: BF8701A3
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 00000045958C: 101212FF 3DB504F3
	.long 0xd7006a00                                           // 000000459594: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 000000459598: 02020014
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 00000045959C: 100C0CFF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 0000004595A4: D5207C01 01AA0215
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004595AC: BF870093
	.long 0xd7006a00                                           // 0000004595B0: D7006A00
	v_cndmask_b32_e32 v1, v0, v19, vcc_lo                      // 0000004595B4: 02022700
	v_add_co_ci_u32_e64 v1, null, v1, v20, vcc_lo              // 0000004595B8: D5207C01 01AA2901
	v_fma_mix_f32 v3, v23, v3, neg(0) op_sel_hi:[1,0,0]        // 0000004595C0: CC200003 8A020717
	v_fma_mix_f32 v2, v24, v2, neg(0) op_sel_hi:[1,0,0]        // 0000004595C8: CC200002 8A020518
	v_fma_mix_f32 v5, v25, v5, neg(0) op_sel_hi:[1,0,0]        // 0000004595D0: CC200005 8A020B19
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 0000004595D8: CC200004 8A02091A
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 0000004595E0: CC200006 8A020D1B
	.long 0x7e2e3983                                           // 0000004595E8: 7E2E3983
	v_fma_mix_f32 v7, v28, v7, neg(0) op_sel_hi:[1,0,0]        // 0000004595EC: CC200007 8A020F1C
	.long 0x7e163982                                           // 0000004595F4: 7E163982
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 0000004595F8: 101010FF 3DB504F3
	v_fma_mix_f32 v9, v21, v9, neg(0) op_sel_hi:[1,0,0]        // 000000459600: CC200009 8A021315
	v_and_b32_e32 v10, 1, v23                                  // 000000459608: 36142E81
	.long 0x7e2e3984                                           // 00000045960C: 7E2E3984
	v_and_b32_e32 v11, 1, v11                                  // 000000459610: 36161681
	v_fma_mix_f32 v8, v29, v8, neg(0) op_sel_hi:[1,0,0]        // 000000459614: CC200008 8A02111D
	.long 0x7e2a3985                                           // 00000045961C: 7E2A3985
	.long 0x7e2c3986                                           // 000000459620: 7E2C3986
	v_and_b32_e32 v12, 1, v23                                  // 000000459624: 36182E81
	.long 0x7e2e3987                                           // 000000459628: 7E2E3987
	.long 0x7e303988                                           // 00000045962C: 7E303988
	v_and_b32_e32 v13, 1, v21                                  // 000000459630: 361A2A81
	v_and_b32_e32 v14, 1, v22                                  // 000000459634: 361C2C81
	v_add3_u32 v3, v3, v10, 0x7fff                             // 000000459638: D6550003 03FE1503 00007FFF
	v_and_b32_e32 v15, 1, v23                                  // 000000459644: 361E2E81
	.long 0x7e2e3989                                           // 000000459648: 7E2E3989
	v_and_b32_e32 v16, 1, v24                                  // 00000045964C: 36203081
	v_add3_u32 v2, v2, v11, 0x7fff                             // 000000459650: D6550002 03FE1702 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 00000045965C: D6550005 03FE1B05 00007FFF
	v_add3_u32 v4, v4, v12, 0x7fff                             // 000000459668: D6550004 03FE1904 00007FFF
	v_and_b32_e32 v10, 1, v23                                  // 000000459674: 36142E81
	v_add3_u32 v6, v6, v14, 0x7fff                             // 000000459678: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 000000459684: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000459690: D6550007 03FE1F07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000045969C: BF870004
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000004596A0: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 0000004596AC: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000004596B0: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 0000004596B8: DC960020 007C0300
	global_store_d16_hi_b16 v[0:1], v5, off offset:64          // 0000004596C0: DC960040 007C0500
	global_store_d16_hi_b16 v[0:1], v4, off offset:96          // 0000004596C8: DC960060 007C0400
	global_store_d16_hi_b16 v[0:1], v6, off offset:128         // 0000004596D0: DC960080 007C0600
	global_store_d16_hi_b16 v[0:1], v7, off offset:160         // 0000004596D8: DC9600A0 007C0700
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 0000004596E0: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:224         // 0000004596E8: DC9600E0 007C0900
	s_endpgm                                                   // 0000004596F0: BFB00000
		...

