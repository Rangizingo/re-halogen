0000000000567300 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000567300: F4100100 F8000000
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v1, 15, v0          // 000000567308: CA240080 0600008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000567310: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000567314: 86039F02
	v_mov_b32_e32 v5, 0                                        // 000000567318: 7E0A0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000056731C: BF870193
	v_dual_mov_b32 v8, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 000000567320: CA220080 08000282
	v_and_b32_e32 v2, 60, v2                                   // 000000567328: 360404BC
	v_lshrrev_b32_e32 v15, 5, v0                               // 00000056732C: 321E0085
	v_dual_mov_b32 v29, 0 :: v_dual_and_b32 v16, 31, v0        // 000000567330: CA240080 1D10009F
	.long 0x7f263880                                           // 000000567338: 7F263880
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v14, 2, v0     // 00000056733C: CA220080 110E0082
	s_waitcnt lgkmcnt(0)                                       // 000000567344: BF89FC07
	s_clause 0x1                                               // 000000567348: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 00000056734C: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 000000567354: DC520000 0D040002
	.long 0xd4510000                                           // 00000056735C: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000567360: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 000000567364: 8B007E00
	s_cselect_b32 s22, s3, 0                                   // 000000567368: 98168003
	s_cselect_b32 s23, s2, 0                                   // 00000056736C: 98178002
	s_add_u32 s0, s4, s14                                      // 000000567370: 80000E04
	s_addc_u32 s1, s5, s15                                     // 000000567374: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 000000567378: 850E9F0B
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v2, s1              // 00000056737C: CA100080 07020001
	s_add_u32 s14, s10, s14                                    // 000000567384: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000567388: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000056738C: 86149F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000567390: 868E810E
	s_lshr_b32 s20, s20, 27                                    // 000000567394: 85149B14
	v_mov_b32_e32 v1, s0                                       // 000000567398: 7E020200
	s_add_u32 s20, s10, s20                                    // 00000056739C: 8014140A
	s_addc_u32 s21, s11, 0                                     // 0000005673A0: 8215800B
	s_mul_i32 s19, s19, s23                                    // 0000005673A4: 96131713
	s_lshr_b64 s[20:21], s[20:21], 5                           // 0000005673A8: 85948514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000005673AC: BF870499
	s_add_i32 s21, s20, 7                                      // 0000005673B0: 81158714
	s_ashr_i32 s24, s21, 31                                    // 0000005673B4: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000005673B8: BF870499
	s_lshr_b32 s24, s24, 29                                    // 0000005673BC: 85189D18
	s_add_i32 s21, s21, s24                                    // 0000005673C0: 81151815
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005673C4: BF870009
	s_ashr_i32 s21, s21, 3                                     // 0000005673C8: 86158315
	s_add_u32 s0, s4, s16                                      // 0000005673CC: 80001004
	s_addc_u32 s1, s5, s17                                     // 0000005673D0: 82011105
	.long 0xd72c0012                                           // 0000005673D4: D72C0012
	v_cndmask_b32_e32 v1, s21, v15, vcc_lo                     // 0000005673D8: 02021E15
	v_mov_b32_e32 v4, s1                                       // 0000005673DC: 7E080201
	v_mad_u64_u32 v[9:10], null, s23, s14, v[1:2]              // 0000005673E0: D6FE7C09 04041C17
	v_mov_b32_e32 v3, s0                                       // 0000005673E8: 7E060200
	s_mul_i32 s0, s22, s14                                     // 0000005673EC: 96000E16
	s_waitcnt vmcnt(1)                                         // 0000005673F0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 0000005673F4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 0000005673FC: BF8903F7
	v_bfe_u32 v1, v13, 16, 1                                   // 000000567400: D6100001 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000567408: BF870112
	v_add3_u32 v2, v11, v12, 0x7fff                            // 00000056740C: D6550002 03FE190B 00007FFF
	v_add3_u32 v1, v13, v1, 0x7fff                             // 000000567418: D6550001 03FE030D 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000567424: BF870002
	.long 0x7e263982                                           // 000000567428: 7E263982
	v_add_nc_u32_e32 v2, s0, v10                               // 00000056742C: 4A041400
	v_mad_u64_u32 v[11:12], null, s18, s23, v[3:4]             // 000000567430: D6FE7C0B 040C2E12
	v_add_nc_u32_e32 v3, s21, v18                              // 000000567438: 4A062415
	v_add_nc_u32_e32 v10, v18, v16                             // 00000056743C: 4A142112
	s_mul_i32 s23, s23, s15                                    // 000000567440: 96170F17
	s_mul_i32 s0, s18, s22                                     // 000000567444: 96001612
	v_and_or_b32 v1, 0xffff0000, v1, v19                       // 000000567448: D6570001 044E02FF FFFF0000
	v_min_i32_e32 v18, s20, v3                                 // 000000567454: 22240614
	v_add_nc_u32_e32 v19, s23, v2                              // 000000567458: 4A260417
	v_add_nc_u32_e32 v3, s19, v12                              // 00000056745C: 4A061813
	ds_store_b32 v14, v1                                       // 000000567460: D8340000 0000010E
	v_cmp_lt_i32_e32 vcc_lo, v10, v18                          // 000000567468: 7C82250A
	v_add_nc_u32_e32 v20, s0, v3                               // 00000056746C: 4A280600
	s_waitcnt lgkmcnt(0)                                       // 000000567470: BF89FC07
	s_barrier                                                  // 000000567474: BFBD0000
	buffer_gl0_inv                                             // 000000567478: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000567480: BE81206A
	s_cbranch_execz 21                                         // 000000567484: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v1, 1, v10                               // 000000567488: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 00000056748C: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000567490: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000567494: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000567498: 3408069F
	.long 0xd7000001                                           // 00000056749C: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000005674A0: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005674A4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 0000005674A8: D5207C02 00020514
	.long 0xd7000003                                           // 0000005674B0: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000005674B4: 02020709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 0000005674B8: D5207C04 00020913
	s_clause 0x1                                               // 0000005674C0: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 0000005674C4: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 0000005674CC: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 0000005674D4: BF8907F7
	v_cvt_f32_f16_e32 v29, v1                                  // 0000005674D8: 7E3A1701
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005674DC: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000005674E0: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 0000005674E8: CA100080 18180080
	v_mov_b32_e32 v21, 0                                       // 0000005674F0: 7E2A0280
	s_and_saveexec_b32 s1, vcc_lo                              // 0000005674F4: BE81206A
	s_cbranch_execz 519                                        // 0000005674F8: BFA50207 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xa18>
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v1, 32, v10     // 0000005674FC: CA200080 180014A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 000000567504: CA220080 150C1485
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v28, v29           // 00000056750C: CA100080 171C011D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000567514: BF870003
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v26, 4, v1     // 000000567518: CA220080 191A0284
	v_dual_mov_b32 v22, 0 :: v_dual_lshlrev_b32 v27, 1, v1     // 000000567520: CA220080 161A0281
	v_mov_b32_e32 v17, 0                                       // 000000567528: 7E220280
	s_mul_i32 s0, s11, 6                                       // 00000056752C: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000567530: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000567534: 8484820A
	s_add_i32 s14, s14, s0                                     // 000000567538: 810E000E
	s_mul_i32 s16, s10, 6                                      // 00000056753C: 9610860A
	s_mov_b32 s15, 0                                           // 000000567540: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000567544: 848A810A
	s_branch 467                                               // 000000567548: BFA001D3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x998>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000056754C: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 000000567550: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000567558: 8B006A7E
	v_add_nc_u32_e32 v26, 0x200, v26                           // 00000056755C: 4A3434FF 00000200
	s_or_b32 s15, s0, s15                                      // 000000567564: 8C0F0F00
	v_add_nc_u32_e32 v27, 64, v27                              // 000000567568: 4A3636C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000056756C: 301A1A82
	ds_load_b32 v46, v13                                       // 000000567570: D8D80000 2E00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 000000567578: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000056757C: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000567580: 361A1AFF 000003FC
	ds_load_b32 v47, v13                                       // 000000567588: D8D80000 2F00000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 000000567590: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 000000567594: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000567598: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000005675A0: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005675A4: 360A0AFF 000003FC
	ds_load_b32 v48, v13                                       // 0000005675AC: D8D80000 3000000D
	ds_load_b32 v49, v5                                        // 0000005675B4: D8D80000 31000005
	v_and_b32_e32 v5, 0xff, v6                                 // 0000005675BC: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000005675C4: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000005675C8: 300A0A82
	ds_load_b32 v50, v5                                        // 0000005675CC: D8D80000 32000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 0000005675D4: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005675D8: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005675DC: 360A0AFF 000003FC
	ds_load_b32 v51, v5                                        // 0000005675E4: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 0000005675EC: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005675F0: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 0000005675F8: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 000000567600: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000567604: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000567608: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 000000567610: D8D80000 35000005
	v_and_b32_e32 v5, 0xff, v7                                 // 000000567618: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000567620: 300A0A82
	ds_load_b32 v54, v5                                        // 000000567624: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 00000056762C: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000567630: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000567634: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 00000056763C: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 000000567644: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000567648: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 000000567650: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 000000567658: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056765C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000567660: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 000000567668: D8D80000 39000005
	v_and_b32_e32 v5, 0xff, v8                                 // 000000567670: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000567678: 300A0A82
	ds_load_b32 v58, v5                                        // 00000056767C: D8D80000 3A000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 000000567684: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000567688: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000056768C: 360A0AFF 000003FC
	ds_load_b32 v59, v5                                        // 000000567694: D8D80000 3B000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 00000056769C: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005676A0: 360A0AFF 000003FC
	ds_load_b32 v60, v5                                        // 0000005676A8: D8D80000 3C000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 0000005676B0: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000005676B4: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005676B8: 360A0AFF 000003FC
	ds_load_b32 v61, v5                                        // 0000005676C0: D8D80000 3D000005
	.long 0xd73c0005                                           // 0000005676C8: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000005676CC: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000005676D0: 4A1818FF 00000400
	.long 0xd7006a2a                                           // 0000005676D8: D7006A2A
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000005676DC: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005676E0: BF870001
	v_add_co_ci_u32_e64 v43, null, s7, v6, vcc_lo              // 0000005676E4: D5207C2B 01AA0C07
	s_clause 0x3                                               // 0000005676EC: BF850003
	global_load_b128 v[5:8], v[42:43], off                     // 0000005676F0: DC5E0000 057C002A
	global_load_b128 v[30:33], v[42:43], off offset:16         // 0000005676F8: DC5E0010 1E7C002A
	global_load_b128 v[34:37], v[42:43], off offset:32         // 000000567700: DC5E0020 227C002A
	global_load_b128 v[38:41], v[42:43], off offset:48         // 000000567708: DC5E0030 267C002A
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000567710: BF890CF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 000000567714: CC1A4005 1A025D05
	s_waitcnt lgkmcnt(14)                                      // 00000056771C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567720: BF8700A1
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 000000567724: CC1A4005 1C165F06
	s_waitcnt lgkmcnt(13)                                      // 00000056772C: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 000000567730: CC1A4005 1C166107
	s_waitcnt lgkmcnt(12)                                      // 000000567738: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056773C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 000000567740: CC1A4005 1C166308
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000567748: BF8908B7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 00000056774C: CC1A4005 1C16651E
	s_waitcnt lgkmcnt(10)                                      // 000000567754: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567758: BF8700A1
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000056775C: CC1A4005 1C16671F
	s_waitcnt lgkmcnt(9)                                       // 000000567764: BF89FC97
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000567768: CC1A4005 1C166920
	s_waitcnt lgkmcnt(8)                                       // 000000567770: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567774: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000567778: CC1A4005 1C166B21
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000567780: BF890477
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000567784: CC1A4005 1C166D22
	s_waitcnt lgkmcnt(6)                                       // 00000056778C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567790: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000567794: CC1A4005 1C166F23
	s_waitcnt lgkmcnt(5)                                       // 00000056779C: BF89FC57
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000005677A0: CC1A4005 1C167124
	s_waitcnt lgkmcnt(4)                                       // 0000005677A8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005677AC: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000005677B0: CC1A4005 1C167325
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000005677B8: BF890037
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000005677BC: CC1A4005 1C167526
	.long 0xd7006a26                                           // 0000005677C4: D7006A26
	v_cndmask_b32_e32 v0, v42, v10, vcc_lo                     // 0000005677C8: 0200152A
	s_waitcnt lgkmcnt(2)                                       // 0000005677CC: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000005677D0: BF8701C2
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000005677D4: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v39, null, s11, v43, vcc_lo            // 0000005677DC: D5207C27 01AA560B
	.long 0xd7006a2c                                           // 0000005677E4: D7006A2C
	v_cndmask_b32_e32 v0, v42, v4, vcc_lo                      // 0000005677E8: 0200092A
	s_waitcnt lgkmcnt(1)                                       // 0000005677EC: BF89FC17
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000005677F0: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v45, null, s5, v43, vcc_lo             // 0000005677F8: D5207C2D 01AA5605
	.long 0xd7006a2a                                           // 000000567800: D7006A2A
	v_cndmask_b32_e32 v0, v42, v16, vcc_lo                     // 000000567804: 0200212A
	s_waitcnt lgkmcnt(0)                                       // 000000567808: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000056780C: BF870123
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000567810: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v43, null, s14, v43, vcc_lo            // 000000567818: D5207C2B 01AA560E
	v_fmac_f32_e32 v21, v29, v5                                // 000000567820: 562A0B1D
	s_clause 0x3                                               // 000000567824: BF850003
	global_load_b128 v[5:8], v[38:39], off                     // 000000567828: DC5E0000 057C0026
	global_load_b128 v[30:33], v[38:39], off offset:16         // 000000567830: DC5E0010 1E7C0026
	global_load_b128 v[34:37], v[38:39], off offset:32         // 000000567838: DC5E0020 227C0026
	global_load_b128 v[38:41], v[38:39], off offset:48         // 000000567840: DC5E0030 267C0026
	s_waitcnt vmcnt(3)                                         // 000000567848: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 00000056784C: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567854: BF870091
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 000000567858: CC1A4005 1C165F06
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 000000567860: CC1A4005 1C166107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567868: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 00000056786C: CC1A4005 1C166308
	s_waitcnt vmcnt(2)                                         // 000000567874: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000567878: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567880: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000567884: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000056788C: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567894: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000567898: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 0000005678A0: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000005678A4: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005678AC: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000005678B0: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000005678B8: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005678C0: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000005678C4: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 0000005678CC: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000005678D0: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005678D8: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000005678DC: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000005678E4: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005678EC: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000005678F0: CC1A4005 1C167B29
	v_fmac_f32_e32 v25, v29, v5                                // 0000005678F8: 56320B1D
	s_clause 0x3                                               // 0000005678FC: BF850003
	global_load_b128 v[5:8], v[44:45], off                     // 000000567900: DC5E0000 057C002C
	global_load_b128 v[30:33], v[44:45], off offset:16         // 000000567908: DC5E0010 1E7C002C
	global_load_b128 v[34:37], v[44:45], off offset:32         // 000000567910: DC5E0020 227C002C
	global_load_b128 v[38:41], v[44:45], off offset:48         // 000000567918: DC5E0030 267C002C
	s_waitcnt vmcnt(3)                                         // 000000567920: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 000000567924: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056792C: BF870091
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 000000567930: CC1A4005 1C165F06
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 000000567938: CC1A4005 1C166107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567940: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 000000567944: CC1A4005 1C166308
	s_waitcnt vmcnt(2)                                         // 00000056794C: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000567950: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567958: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000056795C: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000567964: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056796C: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000567970: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 000000567978: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000056797C: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567984: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000567988: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000567990: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567998: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000056799C: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 0000005679A4: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000005679A8: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005679B0: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000005679B4: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000005679BC: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005679C4: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000005679C8: CC1A4005 1C167B29
	v_fmac_f32_e32 v24, v29, v5                                // 0000005679D0: 56300B1D
	s_clause 0x3                                               // 0000005679D4: BF850003
	global_load_b128 v[5:8], v[42:43], off                     // 0000005679D8: DC5E0000 057C002A
	global_load_b128 v[30:33], v[42:43], off offset:16         // 0000005679E0: DC5E0010 1E7C002A
	global_load_b128 v[34:37], v[42:43], off offset:32         // 0000005679E8: DC5E0020 227C002A
	global_load_b128 v[38:41], v[42:43], off offset:48         // 0000005679F0: DC5E0030 267C002A
	s_waitcnt vmcnt(3)                                         // 0000005679F8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 0000005679FC: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567A04: BF870091
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 000000567A08: CC1A4005 1C165F06
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 000000567A10: CC1A4005 1C166107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567A18: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 000000567A1C: CC1A4005 1C166308
	s_waitcnt vmcnt(2)                                         // 000000567A24: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000567A28: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567A30: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000567A34: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000567A3C: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567A44: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000567A48: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 000000567A50: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000567A54: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567A5C: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000567A60: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000567A68: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567A70: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000567A74: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 000000567A7C: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000567A80: CC1A4005 1C167526
	.long 0xd7006a26                                           // 000000567A88: D7006A26
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 000000567A8C: 0200092C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000567A90: BF870122
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000567A94: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v39, null, s5, v45, vcc_lo             // 000000567A9C: D5207C27 01AA5A05
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000567AA4: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567AAC: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000567AB0: CC1A4005 1C167B29
	v_fmac_f32_e32 v23, v29, v5                                // 000000567AB8: 562E0B1D
	s_clause 0x3                                               // 000000567ABC: BF850003
	global_load_b128 v[5:8], v[38:39], off                     // 000000567AC0: DC5E0000 057C0026
	global_load_b128 v[30:33], v[38:39], off offset:16         // 000000567AC8: DC5E0010 1E7C0026
	global_load_b128 v[34:37], v[38:39], off offset:32         // 000000567AD0: DC5E0020 227C0026
	global_load_b128 v[38:41], v[38:39], off offset:48         // 000000567AD8: DC5E0030 267C0026
	s_waitcnt vmcnt(3)                                         // 000000567AE0: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 000000567AE4: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567AEC: BF870091
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 000000567AF0: CC1A4005 1C165F06
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 000000567AF8: CC1A4005 1C166107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567B00: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 000000567B04: CC1A4005 1C166308
	s_waitcnt vmcnt(2)                                         // 000000567B0C: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000567B10: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567B18: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000567B1C: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000567B24: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567B2C: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000567B30: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 000000567B38: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000567B3C: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567B44: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000567B48: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000567B50: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567B58: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000567B5C: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 000000567B64: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000567B68: CC1A4005 1C167526
	.long 0xd7006a26                                           // 000000567B70: D7006A26
	v_cndmask_b32_e32 v0, v42, v4, vcc_lo                      // 000000567B74: 0200092A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000567B78: BF870122
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000567B7C: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v39, null, s5, v43, vcc_lo             // 000000567B84: D5207C27 01AA5605
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000567B8C: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567B94: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000567B98: CC1A4005 1C167B29
	v_fmac_f32_e32 v22, v29, v5                                // 000000567BA0: 562C0B1D
	s_clause 0x3                                               // 000000567BA4: BF850003
	global_load_b128 v[5:8], v[38:39], off                     // 000000567BA8: DC5E0000 057C0026
	global_load_b128 v[30:33], v[38:39], off offset:16         // 000000567BB0: DC5E0010 1E7C0026
	global_load_b128 v[34:37], v[38:39], off offset:32         // 000000567BB8: DC5E0020 227C0026
	global_load_b128 v[38:41], v[38:39], off offset:48         // 000000567BC0: DC5E0030 267C0026
	s_waitcnt vmcnt(3)                                         // 000000567BC8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 000000567BCC: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000567BD4: BF870121
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 000000567BD8: CC1A4005 1C165F06
	v_mov_b32_e32 v6, v2                                       // 000000567BE0: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 000000567BE4: CC1A4005 1C166107
	v_mov_b32_e32 v7, v3                                       // 000000567BEC: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000567BF0: BF870132
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 000000567BF4: CC1A4005 1C166308
	v_mov_b32_e32 v8, v4                                       // 000000567BFC: 7E100304
	s_waitcnt vmcnt(2)                                         // 000000567C00: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000567C04: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567C0C: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000567C10: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000567C18: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567C20: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000567C24: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 000000567C2C: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000567C30: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567C38: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000567C3C: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000567C44: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567C4C: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000567C50: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 000000567C58: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000567C5C: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567C64: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000567C68: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000567C70: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567C78: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000567C7C: CC1A4005 1C167B29
	v_fmac_f32_e32 v17, v29, v5                                // 000000567C84: 56220B1D
	v_mov_b32_e32 v5, v1                                       // 000000567C88: 7E0A0301
	v_mov_b32_e32 v29, v28                                     // 000000567C8C: 7E3A031C
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000567C90: 917E0F7E
	s_cbranch_execz 31                                         // 000000567C94: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xa14>
	s_waitcnt vmcnt(0)                                         // 000000567C98: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v10, 32, v10    // 000000567C9C: CA200105 010A14A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 000000567CA4: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 000000567CAC: 7E080308
	s_mov_b32 s17, exec_lo                                     // 000000567CB0: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000567CB4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v10, v18                          // 000000567CB8: 7C8C250A
	.long 0xd4c1007e                                           // 000000567CBC: D4C1007E
	v_cndmask_b32_e32 v1, v10, v18, vcc_lo                     // 000000567CC0: 0202250A
	s_cbranch_execz 65057                                      // 000000567CC4: BFA5FE21 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x24c>
	v_ashrrev_i32_e32 v2, 31, v27                              // 000000567CC8: 3404369F
	v_ashrrev_i32_e32 v4, 31, v26                              // 000000567CCC: 3408349F
	.long 0xd7000001                                           // 000000567CD0: D7000001
	v_cndmask_b32_e32 v1, v11, v27, vcc_lo                     // 000000567CD4: 0202370B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567CD8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 000000567CDC: D5207C02 00020514
	.long 0xd7000003                                           // 000000567CE4: D7000003
	v_cndmask_b32_e32 v1, v9, v26, vcc_lo                      // 000000567CE8: 02023509
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 000000567CEC: D5207C04 00020913
	s_clause 0x1                                               // 000000567CF4: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 000000567CF8: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000567D00: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000567D08: BF8907F7
	v_cvt_f32_f16_e32 v28, v13                                 // 000000567D0C: 7E38170D
	s_branch 65038                                             // 000000567D10: BFA0FE0E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x24c>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000567D14: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000567D18: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000567D1C: 8C7E017E
	.long 0xd71f0001                                           // 000000567D20: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000567D24: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000567D28: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000567D2C: 3A040290
	s_waitcnt vmcnt(0)                                         // 000000567D30: BF8903F7
	v_xor_b32_e32 v8, 8, v1                                    // 000000567D34: 3A100288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000567D38: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000567D3C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000567D40: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000567D44: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000567D48: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000567D4C: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 000000567D50: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 000000567D58: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 000000567D5C: 06060715
	ds_bpermute_b32 v4, v2, v25                                // 000000567D60: DACC0000 04001902
	ds_bpermute_b32 v5, v2, v24                                // 000000567D68: DACC0000 05001802
	ds_bpermute_b32 v6, v2, v23                                // 000000567D70: DACC0000 06001702
	ds_bpermute_b32 v7, v2, v22                                // 000000567D78: DACC0000 07001602
	ds_bpermute_b32 v2, v2, v17                                // 000000567D80: DACC0000 02001102
	s_waitcnt lgkmcnt(3)                                       // 000000567D88: BF89FC37
	v_dual_cndmask_b32 v8, v1, v8 :: v_dual_add_f32 v5, v24, v5// 000000567D8C: CA481101 08040B18
	s_waitcnt lgkmcnt(0)                                       // 000000567D94: BF89FC07
	v_dual_add_f32 v7, v22, v7 :: v_dual_add_f32 v2, v17, v2   // 000000567D98: C9080F16 07020511
	v_xor_b32_e32 v17, 4, v1                                   // 000000567DA0: 3A220284
	s_delay_alu instid0(VALU_DEP_1)                            // 000000567DA4: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 000000567DA8: 7C9822A0
	v_dual_cndmask_b32 v17, v1, v17 :: v_dual_lshlrev_b32 v8, 2, v8// 000000567DAC: CA622301 11081082
	ds_bpermute_b32 v9, v8, v3                                 // 000000567DB4: DACC0000 09000308
	ds_bpermute_b32 v11, v8, v5                                // 000000567DBC: DACC0000 0B000508
	v_add_f32_e32 v4, v25, v4                                  // 000000567DC4: 06080919
	v_add_f32_e32 v6, v23, v6                                  // 000000567DC8: 060C0D17
	ds_bpermute_b32 v13, v8, v7                                // 000000567DCC: DACC0000 0D000708
	v_lshlrev_b32_e32 v17, 2, v17                              // 000000567DD4: 30222282
	ds_bpermute_b32 v10, v8, v4                                // 000000567DD8: DACC0000 0A000408
	s_waitcnt lgkmcnt(3)                                       // 000000567DE0: BF89FC37
	v_add_f32_e32 v3, v3, v9                                   // 000000567DE4: 06061303
	s_waitcnt lgkmcnt(2)                                       // 000000567DE8: BF89FC27
	v_add_f32_e32 v5, v5, v11                                  // 000000567DEC: 060A1705
	ds_bpermute_b32 v12, v8, v6                                // 000000567DF0: DACC0000 0C000608
	ds_bpermute_b32 v8, v8, v2                                 // 000000567DF8: DACC0000 08000208
	s_waitcnt lgkmcnt(2)                                       // 000000567E00: BF89FC27
	v_dual_add_f32 v7, v7, v13 :: v_dual_add_f32 v4, v4, v10   // 000000567E04: C9081B07 07041504
	ds_bpermute_b32 v10, v17, v5                               // 000000567E0C: DACC0000 0A000511
	ds_bpermute_b32 v9, v17, v4                                // 000000567E14: DACC0000 09000411
	s_waitcnt lgkmcnt(3)                                       // 000000567E1C: BF89FC37
	v_add_f32_e32 v6, v6, v12                                  // 000000567E20: 060C1906
	s_waitcnt lgkmcnt(2)                                       // 000000567E24: BF89FC27
	v_add_f32_e32 v2, v2, v8                                   // 000000567E28: 06041102
	ds_bpermute_b32 v8, v17, v3                                // 000000567E2C: DACC0000 08000311
	ds_bpermute_b32 v12, v17, v7                               // 000000567E34: DACC0000 0C000711
	ds_bpermute_b32 v11, v17, v6                               // 000000567E3C: DACC0000 0B000611
	ds_bpermute_b32 v13, v17, v2                               // 000000567E44: DACC0000 0D000211
	v_xor_b32_e32 v17, 2, v1                                   // 000000567E4C: 3A220282
	s_waitcnt lgkmcnt(4)                                       // 000000567E50: BF89FC47
	v_add_f32_e32 v4, v4, v9                                   // 000000567E54: 06081304
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000567E58: BF870132
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 000000567E5C: 7C9822A0
	v_cndmask_b32_e32 v17, v1, v17, vcc_lo                     // 000000567E60: 02222301
	v_add_f32_e32 v5, v5, v10                                  // 000000567E64: 060A1505
	v_lshlrev_b32_e32 v17, 2, v17                              // 000000567E68: 30222282
	s_waitcnt lgkmcnt(3)                                       // 000000567E6C: BF89FC37
	v_add_f32_e32 v3, v3, v8                                   // 000000567E70: 06061103
	s_waitcnt lgkmcnt(1)                                       // 000000567E74: BF89FC17
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v6, v6, v11   // 000000567E78: C9081907 07061706
	s_waitcnt lgkmcnt(0)                                       // 000000567E80: BF89FC07
	v_add_f32_e32 v8, v2, v13                                  // 000000567E84: 06101B02
	ds_bpermute_b32 v9, v17, v4                                // 000000567E88: DACC0000 09000411
	ds_bpermute_b32 v2, v17, v3                                // 000000567E90: DACC0000 02000311
	ds_bpermute_b32 v10, v17, v5                               // 000000567E98: DACC0000 0A000511
	ds_bpermute_b32 v11, v17, v6                               // 000000567EA0: DACC0000 0B000611
	ds_bpermute_b32 v12, v17, v7                               // 000000567EA8: DACC0000 0C000711
	ds_bpermute_b32 v13, v17, v8                               // 000000567EB0: DACC0000 0D000811
	v_xor_b32_e32 v17, 1, v1                                   // 000000567EB8: 3A220281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567EBC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 000000567EC0: 7C9822A0
	v_cndmask_b32_e32 v1, v1, v17, vcc_lo                      // 000000567EC4: 02022301
	v_lshlrev_b32_e32 v17, 2, v1                               // 000000567EC8: 30220282
	s_waitcnt lgkmcnt(4)                                       // 000000567ECC: BF89FC47
	v_dual_add_f32 v1, v3, v2 :: v_dual_add_f32 v2, v4, v9     // 000000567ED0: C9080503 01021304
	s_waitcnt lgkmcnt(2)                                       // 000000567ED8: BF89FC27
	v_dual_add_f32 v4, v5, v10 :: v_dual_add_f32 v5, v6, v11   // 000000567EDC: C9081505 04041706
	s_waitcnt lgkmcnt(1)                                       // 000000567EE4: BF89FC17
	v_add_f32_e32 v3, v7, v12                                  // 000000567EE8: 06061907
	s_waitcnt lgkmcnt(0)                                       // 000000567EEC: BF89FC07
	v_add_f32_e32 v9, v8, v13                                  // 000000567EF0: 06121B08
	ds_bpermute_b32 v6, v17, v1                                // 000000567EF4: DACC0000 06000111
	ds_bpermute_b32 v7, v17, v2                                // 000000567EFC: DACC0000 07000211
	ds_bpermute_b32 v10, v17, v4                               // 000000567F04: DACC0000 0A000411
	ds_bpermute_b32 v11, v17, v5                               // 000000567F0C: DACC0000 0B000511
	ds_bpermute_b32 v8, v17, v3                                // 000000567F14: DACC0000 08000311
	ds_bpermute_b32 v12, v17, v9                               // 000000567F1C: DACC0000 0C000911
	v_cmpx_eq_u32_e32 0, v16                                   // 000000567F24: 7D942080
	s_cbranch_execz 12                                         // 000000567F28: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xc5c>
	s_waitcnt lgkmcnt(0)                                       // 000000567F2C: BF89FC07
	v_dual_add_f32 v9, v9, v12 :: v_dual_add_f32 v4, v4, v10   // 000000567F30: C9081909 09041504
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v8, v3, v8    // 000000567F38: C9081705 05081103
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v1, v1, v6     // 000000567F40: C9080F02 02000D01
	v_mul_u32_u24_e32 v6, 24, v15                              // 000000567F48: 160C1E98
	ds_store_2addr_b64 v6, v[1:2], v[4:5] offset0:128 offset1:129// 000000567F4C: D9388180 00040106
	ds_store_b64 v6, v[8:9] offset:1040                        // 000000567F54: D9340410 00000806
	s_or_b32 exec_lo, exec_lo, s0                              // 000000567F5C: 8C7E007E
	.long 0xd4510000                                           // 000000567F60: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000567F64: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 6, v0                             // 000000567F68: 7C980086
	s_waitcnt lgkmcnt(0)                                       // 000000567F6C: BF89FC07
	s_barrier                                                  // 000000567F70: BFBD0000
	buffer_gl0_inv                                             // 000000567F74: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000567F7C: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000567F80: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000567F84: BE812000
	s_cbranch_execz 52                                         // 000000567F88: BFA50034 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xd5c>
	v_add_nc_u32_e32 v7, 0x400, v14                            // 000000567F8C: 4A0E1CFF 00000400
	s_lshl_b64 s[0:1], s[2:3], 1                               // 000000567F94: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:6                     // 000000567F98: D8DC0600 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:12 offset1:18         // 000000567FA0: D8DC120C 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:24 offset1:30         // 000000567FA8: D8DC1E18 05000007
	ds_load_2addr_b32 v[7:8], v7 offset0:36 offset1:42         // 000000567FB0: D8DC2A24 07000007
	s_waitcnt lgkmcnt(3)                                       // 000000567FB8: BF89FC37
	v_add_f32_e32 v1, 0, v1                                    // 000000567FBC: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000567FC0: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000567FC4: 06020501
	s_waitcnt lgkmcnt(2)                                       // 000000567FC8: BF89FC27
	v_add_f32_e32 v1, v1, v3                                   // 000000567FCC: 06020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000567FD0: BF870131
	v_add_f32_e32 v3, v1, v4                                   // 000000567FD4: 06060901
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000567FD8: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(1)                                       // 000000567FE0: BF89FC17
	v_add_f32_e32 v3, v3, v5                                   // 000000567FE4: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000567FE8: BF870191
	v_add_f32_e32 v4, v3, v6                                   // 000000567FEC: 06080D03
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000567FF0: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 000000567FF8: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000567FFC: BF870092
	v_add_f32_e32 v0, v4, v7                                   // 000000568000: 06000F04
	v_add_f32_e32 v3, v0, v8                                   // 000000568004: 06061100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000568008: BF870113
	.long 0xd73c0000                                           // 00000056800C: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000568010: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 000000568014: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056801C: BF870092
	.long 0xd7006a00                                           // 000000568020: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000568024: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000568028: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000568030: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000568034: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 000000568040: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000568044: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000568048: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000056804C: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000568054: DC960000 007C0200
	s_endpgm                                                   // 00000056805C: BFB00000
		...

