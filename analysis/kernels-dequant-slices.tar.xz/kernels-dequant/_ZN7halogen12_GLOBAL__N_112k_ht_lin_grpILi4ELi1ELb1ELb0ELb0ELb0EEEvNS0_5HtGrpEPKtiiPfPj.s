0000000000419200 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj>:
; _ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj():
	s_clause 0x1                                               // 000000419200: BF850001
	s_load_b64 s[4:5], s[0:1], 0x130                           // 000000419204: F4040100 F8000130
	s_load_b128 s[16:19], s[0:1], 0x198                        // 00000041920C: F4080400 F8000198
	s_waitcnt lgkmcnt(0)                                       // 000000419214: BF89FC07
	s_cmp_eq_u64 s[4:5], 0                                     // 000000419218: BF108004
	s_cbranch_scc1 244                                         // 00000041921C: BFA200F4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f0>
	s_load_b32 s6, s[0:1], 0x138                               // 000000419220: F4000180 F8000138
	s_waitcnt lgkmcnt(0)                                       // 000000419228: BF89FC07
	s_cmp_lt_i32 s2, s6                                        // 00000041922C: BF040602
	s_cselect_b32 s3, -1, 0                                    // 000000419230: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000419234: BF030602
	s_cbranch_scc0 233                                         // 000000419238: BFA100E9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3e0>
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000041923C: 32020085
	s_sub_i32 s6, s2, s6                                       // 000000419240: 81860602
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000419244: BF870481
	v_lshl_or_b32 v1, s6, 3, v1                                // 000000419248: D6560001 04050606
	s_mul_i32 s6, s18, 20                                      // 000000419250: 96069412
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000419254: BF870481
	v_cmp_gt_i32_e32 vcc_lo, s6, v1                            // 000000419258: 7C880206
	s_and_saveexec_b32 s6, vcc_lo                              // 00000041925C: BE86206A
	s_cbranch_execz 222                                        // 000000419260: BFA500DE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3dc>
	.long 0xd72e0002                                           // 000000419264: D72E0002
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 000000419268: 020202FF 66666667
	v_and_b32_e32 v9, 31, v0                                   // 000000419270: 3612009F
	s_load_b64 s[8:9], s[0:1], 0x128                           // 000000419274: F4040200 F8000128
	s_mov_b32 s7, 0x76543210                                   // 00000041927C: BE8700FF 76543210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000419284: BF8700A2
	v_lshrrev_b32_e32 v3, 31, v2                               // 000000419288: 3206049F
	v_ashrrev_i32_e32 v2, 3, v2                                // 00000041928C: 34040483
	v_add_nc_u32_e32 v8, v2, v3                                // 000000419290: 4A100702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000419294: BF870121
	.long 0xd72c0002                                           // 000000419298: D72C0002
	v_cndmask_b32_e32 v1, 0xffffffec, v8, vcc_lo               // 00000041929C: 020210FF FFFFFFEC
	v_mad_i64_i32 v[4:5], null, 0x1400, v8, s[16:17]           // 0000004192A4: D6FF7C04 004210FF 00001400
	v_add_lshl_u32 v1, v2, v1, 7                               // 0000004192B0: D6470001 021E0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004192B8: BF870091
	v_lshl_or_b32 v2, v9, 2, v1                                // 0000004192BC: D6560002 04050509
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000004192C4: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004192C8: BF870091
	.long 0xd73c0002                                           // 0000004192CC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000004192D0: 02020481
	.long 0xd7006a04                                           // 0000004192D4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000004192D8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000004192DC: BF8700B1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000004192E0: D5207C05 01AA0705
	s_waitcnt lgkmcnt(0)                                       // 0000004192E8: BF89FC07
	.long 0xd7006a02                                           // 0000004192EC: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000004192F0: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 0000004192F4: D5207C03 01AA0609
	global_load_b64 v[4:5], v[4:5], off                        // 0000004192FC: DC560000 047C0004
	s_mov_b32 s8, 0x3db504f3                                   // 000000419304: BE8800FF 3DB504F3
	global_load_b64 v[6:7], v[2:3], off                        // 00000041930C: DC560000 067C0002
	s_waitcnt vmcnt(1)                                         // 000000419314: BF8907F7
	.long 0x7e043904                                           // 000000419318: 7E043904
	v_and_b32_e32 v3, 0xffff0000, v4                           // 00000041931C: 360608FF FFFF0000
	.long 0x7e083905                                           // 000000419324: 7E083905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000419328: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000419330: BF870004
	v_lshlrev_b32_e32 v14, 16, v2                              // 000000419334: 301C0490
	s_waitcnt vmcnt(0)                                         // 000000419338: BF8903F7
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000041933C: CC200803 8A020706
	v_lshlrev_b32_e32 v4, 16, v4                               // 000000419344: 30080890
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000419348: CC200805 8A020B07
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000419350: 3404029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000419354: BF870224
	v_fma_mix_f32 v15, v6, v14, v3 op_sel_hi:[1,0,0]           // 000000419358: CC20000F 0C0E1D06
	v_fma_mix_f32 v6, v6, v14, -v3 op_sel_hi:[1,0,0]           // 000000419360: CC200006 8C0E1D06
	v_fma_mix_f32 v14, v7, v4, v5 op_sel_hi:[1,0,0]            // 000000419368: CC20000E 0C160907
	v_fma_mix_f32 v5, v7, v4, -v5 op_sel_hi:[1,0,0]            // 000000419370: CC200005 8C160907
	v_and_b32_e32 v10, 1, v0                                   // 000000419378: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000041937C: 36160082
	v_and_b32_e32 v13, 8, v0                                   // 000000419380: 361A0088
	.long 0xd73c0001                                           // 000000419384: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000419388: 02020281
	v_add_f32_e32 v16, v6, v5                                  // 00000041938C: 06200B06
	v_sub_f32_e32 v5, v6, v5                                   // 000000419390: 080A0B06
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000419394: 7C941480
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000419398: BF870193
	v_mov_b32_dpp v10, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041939C: 7E1402FA FF016110
	v_mov_b32_dpp v17, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004193A4: 7E2202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004193AC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000004193B4: BF8701D1
	v_add_f32_e32 v5, v5, v17                                  // 0000004193B8: 060A2305
	v_mad_i64_i32 v[3:4], null, 0x1400, v8, s[4:5]             // 0000004193BC: D6FF7C03 001210FF 00001400
	v_add_f32_e32 v8, v15, v14                                 // 0000004193C8: 06101D0F
	v_sub_f32_e32 v14, v15, v14                                // 0000004193CC: 081C1D0F
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 0000004193D0: D501000F 21AA2110
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004193D8: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000004193E0: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004193E8: BF870234
	v_mov_b32_dpp v16, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004193EC: 7E2002FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000004193F4: D501000E 21AA1D0E
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000004193FC: 7C941680
	v_dual_add_f32 v6, v8, v6 :: v_dual_lshlrev_b32 v7, 3, v9  // 000000419400: C9220D08 06061283
	v_add_f32_e32 v8, v15, v10                                 // 000000419408: 0610150F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041940C: BF870004
	v_add_f32_e32 v10, v14, v16                                // 000000419410: 0614210E
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000419414: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000041941C: D5010005 21AA0B05
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000419424: 7E1602FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000041942C: D5010006 21AA0D06
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000419434: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000041943C: D501000A 21AA150A
	v_add_f32_e32 v5, v5, v16                                  // 000000419444: 060A2105
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000419448: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000419450: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 000000419458: 060C1706
	v_add_f32_e32 v10, v10, v15                                // 00000041945C: 06141F0A
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000419460: 7E1E02FA FF016405
	v_and_b32_e32 v12, 4, v0                                   // 000000419468: 36180084
	v_add_f32_e32 v8, v8, v14                                  // 00000041946C: 06101D08
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000419470: 7E1602FA FF016406
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000419478: 7E1C02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000419480: BF8701C4
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 000000419484: 7C941880
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000419488: D5010006 21AA0D06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000419490: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000419498: D501000A 21AA150A
	v_add_f32_e32 v6, v6, v11                                  // 0000004194A0: 060C1706
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004194A4: BF870003
	v_add_f32_e32 v5, v5, v15                                  // 0000004194A8: 060A1F05
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004194AC: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000004194B4: D5010008 21AA1108
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 0000004194BC: 7C941A80
	v_add_f32_e32 v10, v10, v14                                // 0000004194C0: 06141D0A
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004194C4: 7E1602FA FF016806
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004194CC: 7E1C02FA FF016805
	v_add_f32_e32 v8, v8, v12                                  // 0000004194D4: 06101908
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000004194D8: D5010006 21AA0D06
	v_mov_b32_dpp v13, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004194E0: 7E1A02FA FF01680A
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004194E8: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000004194F0: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004194F8: 7E1802FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000419500: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 000000419508: 060C1706
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 00000041950C: 7C981290
	v_add_f32_e32 v5, v5, v14                                  // 000000419510: 060A1D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000419514: BF870214
	v_dual_add_f32 v9, v10, v13 :: v_dual_add_f32 v8, v8, v12  // 000000419518: C9081B0A 09081908
	v_mov_b32_e32 v10, v6                                      // 000000419520: 7E140306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000419524: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041952C: BF870214
	v_mov_b32_e32 v13, v5                                      // 000000419530: 7E1A0305
	v_mov_b32_e32 v12, v9                                      // 000000419534: 7E180309
	v_cndmask_b32_e64 v11, -v8, v8, vcc_lo                     // 000000419538: D501000B 21AA1108
	v_permlanex16_b32 v8, v8, s7, 0xfedcba98                   // 000000419540: D65C0008 03FC0F08 FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000041954C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000419554: D5010009 21AA1309
	v_permlanex16_b32 v10, v10, s7, 0xfedcba98                 // 00000041955C: D65C000A 03FC0F0A FEDCBA98
	v_permlanex16_b32 v12, v12, s7, 0xfedcba98                 // 000000419568: D65C000C 03FC0F0C FEDCBA98
	v_permlanex16_b32 v13, v13, s7, 0xfedcba98                 // 000000419574: D65C000D 03FC0F0D FEDCBA98
	.long 0xd7006a01                                           // 000000419580: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 000000419584: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000419588: BF8700D1
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 00000041958C: D5207C02 01AA0504
	v_dual_add_f32 v3, v11, v8 :: v_dual_add_f32 v4, v6, v10   // 000000419594: C908110B 03041506
	v_add_f32_e32 v6, v9, v12                                  // 00000041959C: 060C1909
	v_add_f32_e32 v5, v5, v13                                  // 0000004195A0: 060A1B05
	.long 0xd7006a01                                           // 0000004195A4: D7006A01
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 0000004195A8: 02020F01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000004195AC: D5207C02 01AA0480
	v_fma_mixhi_f16 v3, v3, s8, 0                              // 0000004195B4: CC220003 02001103
	v_fma_mixlo_f16 v3, v4, s8, 0                              // 0000004195BC: CC210003 02001104
	v_fma_mixhi_f16 v4, v5, s8, 0                              // 0000004195C4: CC220004 02001105
	v_fma_mixlo_f16 v4, v6, s8, 0                              // 0000004195CC: CC210004 02001106
	global_store_b64 v[1:2], v[3:4], off                       // 0000004195D4: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 0000004195DC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004195E0: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000004195E4: 8B6A037E
	s_cbranch_vccnz 2                                          // 0000004195E8: BFA40002 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f4>
	s_endpgm                                                   // 0000004195EC: BFB00000
	s_cbranch_execz 65534                                      // 0000004195F0: BFA5FFFE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_clause 0x3                                               // 0000004195F4: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000004195F8: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x7c                                // 000000419600: F4000100 F800007C
	s_load_b32 s5, s[0:1], 0xc4                                // 000000419608: F4000140 F80000C4
	s_load_b32 s6, s[0:1], 0x10c                               // 000000419610: F4000180 F800010C
	v_lshrrev_b32_e32 v7, 5, v0                                // 000000419618: 320E0085
	v_and_b32_e32 v8, 31, v0                                   // 00000041961C: 3610009F
	s_mov_b32 s33, 0                                           // 000000419620: BEA10080
	s_waitcnt lgkmcnt(0)                                       // 000000419624: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 000000419628: BF028103
	s_cselect_b32 s7, -1, 0                                    // 00000041962C: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 000000419630: BF030402
	s_cselect_b32 s4, -1, 0                                    // 000000419634: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000419638: BF870009
	s_and_b32 s4, s7, s4                                       // 00000041963C: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 000000419640: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 000000419644: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 00000041964C: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 000000419650: BF030502
	s_cselect_b32 s5, -1, 0                                    // 000000419654: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000419658: BF870009
	s_and_b32 s4, s7, s5                                       // 00000041965C: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 000000419660: BF028303
	v_readfirstlane_b32 s5, v1                                 // 000000419664: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 000000419668: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 00000041966C: BF030602
	s_cselect_b32 s6, -1, 0                                    // 000000419670: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000419674: BF8704D9
	s_and_b32 s3, s3, s6                                       // 000000419678: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 00000041967C: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 000000419680: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 000000419684: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 000000419688: 98030483
	s_mulk_i32 s3, 0x48                                        // 00000041968C: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000419690: BF870009
	s_add_u32 s4, s0, s3                                       // 000000419694: 80040300
	s_addc_u32 s5, s1, 0                                       // 000000419698: 82058001
	s_clause 0x3                                               // 00000041969C: BF850003
	s_load_b32 s28, s[4:5], 0x38                               // 0000004196A0: F4000702 F8000038
	s_load_b64 s[30:31], s[4:5], 0x40                          // 0000004196A8: F4040782 F8000040
	s_load_b128 s[20:23], s[4:5], 0x28                         // 0000004196B0: F4080502 F8000028
	s_load_b64 s[24:25], s[4:5], 0x20                          // 0000004196B8: F4040602 F8000020
	s_waitcnt lgkmcnt(0)                                       // 0000004196C0: BF89FC07
	s_abs_i32 s3, s21                                          // 0000004196C4: BE831515
	s_sub_i32 s2, s2, s23                                      // 0000004196C8: 81821702
	s_cvt_f32_u32 s6, s3                                       // 0000004196CC: BE866503
	s_sub_i32 s7, 0, s3                                        // 0000004196D0: 81870380
	s_abs_i32 s8, s2                                           // 0000004196D4: BE881502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000004196D8: BF870299
	v_rcp_iflag_f32_e32 v1, s6                                 // 0000004196DC: 7E025606
	v_readfirstlane_b32 s6, v1                                 // 0000004196E0: 7E0C0501
	s_mul_f32 s6, s6, 0x4f7ffffe                               // 0000004196E4: A206FF06 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000004196EC: BF87059B
	s_cvt_u32_f32 s6, s6                                       // 0000004196F0: BE866706
	s_mul_i32 s7, s7, s6                                       // 0000004196F4: 96070607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000004196F8: BF870499
	s_mul_hi_u32 s7, s6, s7                                    // 0000004196FC: 96870706
	s_add_i32 s6, s6, s7                                       // 000000419700: 81060706
	s_xor_b32 s7, s2, s21                                      // 000000419704: 8D071502
	s_mul_hi_u32 s6, s8, s6                                    // 000000419708: 96860608
	s_ashr_i32 s7, s7, 31                                      // 00000041970C: 86079F07
	s_mul_i32 s9, s6, s3                                       // 000000419710: 96090306
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000419714: BF870009
	s_sub_i32 s8, s8, s9                                       // 000000419718: 81880908
	s_add_i32 s9, s6, 1                                        // 00000041971C: 81098106
	s_sub_i32 s10, s8, s3                                      // 000000419720: 818A0308
	s_cmp_ge_u32 s8, s3                                        // 000000419724: BF090308
	s_cselect_b32 s6, s9, s6                                   // 000000419728: 98060609
	s_cselect_b32 s8, s10, s8                                  // 00000041972C: 9808080A
	s_add_i32 s9, s6, 1                                        // 000000419730: 81098106
	s_cmp_ge_u32 s8, s3                                        // 000000419734: BF090308
	s_cselect_b32 s3, s9, s6                                   // 000000419738: 98030609
	s_load_b256 s[8:15], s[4:5], null                          // 00000041973C: F40C0202 F8000000
	s_xor_b32 s3, s3, s7                                       // 000000419744: 8D030703
	s_ashr_i32 s27, s19, 31                                    // 000000419748: 861B9F13
	s_sub_i32 s26, s3, s7                                      // 00000041974C: 819A0703
	s_lshr_b32 s4, s27, 25                                     // 000000419750: 8504991B
	s_mul_i32 s3, s26, s21                                     // 000000419754: 9603151A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000419758: BF870009
	s_sub_i32 s23, s2, s3                                      // 00000041975C: 81970302
	s_add_i32 s2, s19, s4                                      // 000000419760: 81020413
	s_mul_i32 s29, s22, s23                                    // 000000419764: 961D1716
	s_ashr_i32 s2, s2, 7                                       // 000000419768: 86028702
	s_add_i32 s3, s29, s22                                     // 00000041976C: 8103161D
	s_mov_b32 s22, exec_lo                                     // 000000419770: BE96007E
	s_min_i32 s2, s2, s3                                       // 000000419774: 89020302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000419778: BF870499
	s_sub_i32 s7, s2, s29                                      // 00000041977C: 81871D02
	.long 0xd4c4007e                                           // 000000419780: D4C4007E
	v_cndmask_b32_e32 v1, s7, v7, vcc_lo                       // 000000419784: 02020E07
	s_cbranch_execz 289                                        // 000000419788: BFA50121 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xa10>
	s_abs_i32 s34, s7                                          // 00000041978C: BEA21507
	v_lshlrev_b32_e32 v9, 3, v8                                // 000000419790: 30121083
	s_cvt_f32_u32 s2, s34                                      // 000000419794: BE826522
	v_lshlrev_b32_e32 v10, 7, v7                               // 000000419798: 30140E87
	v_and_b32_e32 v3, 2, v0                                    // 00000041979C: 36060082
	v_and_b32_e32 v5, 8, v0                                    // 0000004197A0: 360A0088
	v_rcp_iflag_f32_e32 v1, s2                                 // 0000004197A4: 7E025602
	s_sub_i32 s2, 0, s34                                       // 0000004197A8: 81822280
	s_ashr_i32 s37, s7, 31                                     // 0000004197AC: 86259F07
	.long 0xd44a0003                                           // 0000004197B0: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 0000004197B4: 02020680
	s_mul_i32 s39, s37, 0x1400                                 // 0000004197B8: 9627FF25 00001400
	.long 0xd44a0005                                           // 0000004197C0: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000004197C4: 02020A80
	s_lshl_b32 s6, s7, 7                                       // 0000004197C8: 84068707
	s_add_i32 s35, s18, -1                                     // 0000004197CC: 8123C112
	s_mov_b32 s36, s19                                         // 0000004197D0: BEA40013
	s_lshl_b32 s38, s7, 8                                      // 0000004197D4: 84268807
	v_dual_mul_f32 v1, 0x4f7ffffe, v1 :: v_dual_and_b32 v2, 1, v0// 0000004197D8: C8E402FF 01020081 4F7FFFFE
	s_mov_b32 s40, 0x76543210                                  // 0000004197E4: BEA800FF 76543210
	s_mov_b32 s41, 0x3db504f3                                  // 0000004197EC: BEA900FF 3DB504F3
	v_cmp_gt_u32_e32 vcc_lo, 16, v8                            // 0000004197F4: 7C981090
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004197F8: BF870122
	v_cvt_u32_f32_e32 v4, v1                                   // 0000004197FC: 7E080F01
	v_and_b32_e32 v1, 4, v0                                    // 000000419800: 36020084
	.long 0xd72c0006                                           // 000000419804: D72C0006
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 000000419808: 02020802
	.long 0xd44a0002                                           // 00000041980C: D44A0002
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000419810: 02020480
	v_lshl_or_b32 v2, v7, 8, v9                                // 000000419814: D6560002 04251107
	v_lshl_add_u32 v9, s29, 7, v10                             // 00000041981C: D6460009 04290E1D
	.long 0xd44a0004                                           // 000000419824: D44A0004
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000419828: 02020280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000041982C: BF870223
	v_subrev_nc_u32_e32 v2, s39, v2                            // 000000419830: 4E040427
	.long 0xd72d0006                                           // 000000419834: D72D0006
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000419838: 02020D04
	v_lshl_or_b32 v1, v8, 2, v9                                // 00000041983C: D6560001 04250508
	s_sub_i32 s39, 0, s6                                       // 000000419844: 81A70680
	s_delay_alu instid0(VALU_DEP_2)                            // 000000419848: BF870002
	v_dual_mov_b32 v4, v7 :: v_dual_add_nc_u32 v3, v4, v6      // 00000041984C: CA200107 04020D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000419854: BF870091
	.long 0xd72d0005                                           // 000000419858: D72D0005
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 00000041985C: 02020704
	.long 0xd72c0006                                           // 000000419860: D72C0006
	v_cndmask_b32_e32 v0, v5, v34, vcc_lo                      // 000000419864: 02004505
	v_add_nc_u32_e32 v9, 1, v5                                 // 000000419868: 4A120A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041986C: BF870092
	v_sub_nc_u32_e32 v6, v4, v6                                // 000000419870: 4C0C0D04
	v_subrev_nc_u32_e32 v10, s34, v6                           // 000000419874: 4E140C22
	.long 0xd44b0006                                           // 000000419878: D44B0006
	v_cndmask_b32_e32 v1, s34, v6, vcc_lo                      // 00000041987C: 02020C22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000419880: BF870191
	v_cndmask_b32_e64 v5, v5, v9, s6                           // 000000419884: D5010005 001A1305
	v_cndmask_b32_e64 v6, v6, v10, s6                          // 00000041988C: D5010006 001A1506
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000419894: BF870112
	v_add_nc_u32_e32 v9, 1, v5                                 // 000000419898: 4A120A81
	.long 0xd44b0006                                           // 00000041989C: D44B0006
	v_cndmask_b32_e32 v1, s34, v6, vcc_lo                      // 0000004198A0: 02020C22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004198A4: BF870091
	v_cndmask_b32_e64 v5, v5, v9, s6                           // 0000004198A8: D5010005 001A1305
	v_xor_b32_e32 v11, s37, v5                                 // 0000004198B0: 3A160A25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004198B4: BF870121
	v_subrev_nc_u32_e32 v12, s37, v11                          // 0000004198B8: 4E181625
	.long 0xd72c000b                                           // 0000004198BC: D72C000B
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 0000004198C0: 020216FF 00001400
	v_min_i32_e32 v9, s35, v12                                 // 0000004198C8: 22121823
	v_mad_u64_u32 v[5:6], null, s39, v12, v[1:2]               // 0000004198CC: D6FE7C05 04061827
	.long 0xd72c000c                                           // 0000004198D4: D72C000C
	v_cndmask_b32_e32 v1, s38, v12, vcc_lo                     // 0000004198D8: 02021826
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004198DC: BF870193
	v_mad_i64_i32 v[9:10], null, v9, s36, 0                    // 0000004198E0: D6FF7C09 02004909
	v_ashrrev_i32_e32 v6, 31, v5                               // 0000004198E8: 340C0A9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004198EC: BF870193
	v_sub_nc_u32_e32 v11, v11, v12                             // 0000004198F0: 4C16190B
	.long 0xd73c0009                                           // 0000004198F4: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000004198F8: 02021281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004198FC: BF870193
	.long 0xd73c0005                                           // 000000419900: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 000000419904: 02020A81
	v_add_nc_u32_e32 v11, v2, v11                              // 000000419908: 4A161702
	v_add_nc_u32_e32 v2, 0x800, v2                             // 00000041990C: 4A0404FF 00000800
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000419914: BF870094
	.long 0xd700060d                                           // 000000419918: D700060D
	v_cndmask_b32_e32 v1, s16, v9, vcc_lo                      // 00000041991C: 02021210
	v_add_co_ci_u32_e64 v14, null, s17, v10, s6                // 000000419920: D5207C0E 001A1411
	s_waitcnt lgkmcnt(0)                                       // 000000419928: BF89FC07
	.long 0xd7000609                                           // 00000041992C: D7000609
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000419930: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000419934: BF8700A1
	v_add_co_ci_u32_e64 v10, null, s11, v6, s6                 // 000000419938: D5207C0A 001A0C0B
	.long 0xd7000605                                           // 000000419940: D7000605
	v_cndmask_b32_e32 v1, v13, v5, vcc_lo                      // 000000419944: 02020B0D
	v_add_co_ci_u32_e64 v6, null, v14, v6, s6                  // 000000419948: D5207C06 001A0D0E
	global_load_b64 v[5:6], v[5:6], off                        // 000000419950: DC560000 057C0005
	global_load_b64 v[9:10], v[9:10], off                      // 000000419958: DC560000 097C0009
	s_waitcnt vmcnt(1)                                         // 000000419960: BF8907F7
	.long 0x7e1a3905                                           // 000000419964: 7E1A3905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000419968: 360A0AFF FFFF0000
	.long 0x7e1c3906                                           // 000000419970: 7E1C3906
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000419974: BF8701A3
	v_lshlrev_b32_e32 v13, 16, v13                             // 000000419978: 301A1A90
	s_waitcnt vmcnt(0)                                         // 00000041997C: BF8903F7
	v_fma_mix_f32 v5, v9, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000419980: CC200805 8A020B09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000419988: BF870113
	v_lshlrev_b32_e32 v14, 16, v14                             // 00000041998C: 301C1C90
	v_fma_mix_f32 v16, v9, v13, v5 op_sel_hi:[1,0,0]           // 000000419990: CC200010 0C161B09
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000419998: 360C0CFF FFFF0000
	v_fma_mix_f32 v5, v9, v13, -v5 op_sel_hi:[1,0,0]           // 0000004199A0: CC200005 8C161B09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004199A8: BF870092
	v_fma_mix_f32 v6, v10, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000004199AC: CC200806 8A020D0A
	v_fma_mix_f32 v15, v10, v14, v6 op_sel_hi:[1,0,0]          // 0000004199B4: CC20000F 0C1A1D0A
	v_fma_mix_f32 v6, v10, v14, -v6 op_sel_hi:[1,0,0]          // 0000004199BC: CC200006 8C1A1D0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004199C4: BF870112
	v_dual_add_f32 v9, v16, v15 :: v_dual_add_nc_u32 v4, 8, v4 // 0000004199C8: C9201F10 09040888
	v_dual_add_f32 v10, v6, v5 :: v_dual_sub_f32 v5, v5, v6    // 0000004199D0: C90A0B06 0A040D05
	v_sub_f32_e32 v13, v16, v15                                // 0000004199D8: 081A1F10
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004199DC: BF870213
	.long 0xd4430006                                           // 0000004199E0: D4430006
	v_cndmask_b32_e32 v1, s7, v4, vcc_lo                       // 0000004199E4: 02020807
	v_mov_b32_dpp v6, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004199E8: 7E0C02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 0000004199F0: D5010009 200A1309
	v_mov_b32_dpp v16, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004199F8: 7E2002FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000419A00: D5010005 200A0B05
	v_mov_b32_dpp v15, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000419A08: 7E1E02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000419A10: D501000D 200A1B0D
	v_dual_add_f32 v6, v9, v6 :: v_dual_add_nc_u32 v1, 0x400, v1// 000000419A18: C9200D09 060002FF 00000400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000419A24: BF8701C4
	v_add_f32_e32 v5, v5, v16                                  // 000000419A28: 060A2105
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000419A2C: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000419A34: D501000A 200A150A
	s_or_b32 s33, s6, s33                                      // 000000419A3C: 8C212106
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000419A40: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000419A48: D5010005 200E0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000419A50: BF870091
	v_add_f32_e32 v5, v5, v16                                  // 000000419A54: 060A2105
	v_mov_b32_dpp v16, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000419A58: 7E2002FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000419A60: D5010005 20120B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000419A68: BF870091
	v_add_f32_e32 v5, v5, v16                                  // 000000419A6C: 060A2105
	v_mov_b32_dpp v16, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000419A70: 7E2002FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000419A78: D5010005 20160B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000419A80: BF870241
	v_add_f32_e32 v5, v5, v16                                  // 000000419A84: 060A2105
	v_dual_add_f32 v9, v10, v14 :: v_dual_add_f32 v10, v13, v15// 000000419A88: C9081D0A 090A1F0D
	v_mov_b32_dpp v13, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000419A90: 7E1A02FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000419A98: D5010006 200E0D06
	v_mov_b32_e32 v16, v5                                      // 000000419AA0: 7E200305
	s_delay_alu instid0(VALU_DEP_4)                            // 000000419AA4: BF870004
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000419AA8: 7E1C02FA FF016209
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000419AB0: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000419AB8: D501000A 200E150A
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000419AC0: D5010009 200E1309
	v_add_f32_e32 v6, v6, v13                                  // 000000419AC8: 060C1B06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000419ACC: D5010005 21AA0B05
	v_permlanex16_b32 v16, v16, s40, 0xfedcba98                // 000000419AD4: D65C0010 03FC5110 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000419AE0: BF870214
	v_dual_add_f32 v10, v10, v15 :: v_dual_add_f32 v9, v9, v14 // 000000419AE4: C9081F0A 0A081D09
	v_mov_b32_dpp v13, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000419AEC: 7E1A02FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 000000419AF4: D5010006 20120D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000419AFC: BF870214
	v_add_f32_e32 v12, v5, v16                                 // 000000419B00: 06182105
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000419B04: 7E1E02FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 000000419B0C: D501000A 2012150A
	v_mov_b32_dpp v14, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000419B14: 7E1C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000419B1C: D5010009 20121309
	v_add_f32_e32 v6, v6, v13                                  // 000000419B24: 060C1B06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000419B28: BF870114
	v_add_f32_e32 v10, v10, v15                                // 000000419B2C: 06141F0A
	v_mov_b32_dpp v13, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000419B30: 7E1A02FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 000000419B38: D5010006 20160D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000419B40: BF8701A3
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000419B44: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s5                       // 000000419B4C: D501000A 2016150A
	v_dual_add_f32 v9, v9, v14 :: v_dual_add_f32 v6, v6, v13   // 000000419B54: C9081D09 09061B06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000419B5C: BF870112
	v_add_f32_e32 v10, v10, v15                                // 000000419B60: 06141F0A
	v_mov_b32_dpp v14, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000419B64: 7E1C02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 000000419B6C: D5010009 20161309
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000419B74: BF870123
	v_mov_b32_e32 v15, v10                                     // 000000419B78: 7E1E030A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000419B7C: D501000A 21AA150A
	v_permlanex16_b32 v15, v15, s40, 0xfedcba98                // 000000419B84: D65C000F 03FC510F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000419B90: BF870091
	v_dual_add_f32 v9, v9, v14 :: v_dual_add_f32 v10, v10, v15 // 000000419B94: C9081D09 090A1F0A
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v14, v9           // 000000419B9C: CA100106 0D0E0109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000419BA4: D5010009 21AA1309
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000419BAC: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000419BB4: BF870213
	v_permlanex16_b32 v13, v13, s40, 0xfedcba98                // 000000419BB8: D65C000D 03FC510D FEDCBA98
	v_permlanex16_b32 v14, v14, s40, 0xfedcba98                // 000000419BC4: D65C000E 03FC510E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000419BD0: BF870091
	v_dual_add_f32 v6, v6, v13 :: v_dual_add_f32 v9, v9, v14   // 000000419BD4: C9081B06 06081D09
	v_fma_mixlo_f16 v5, v6, s41, 0                             // 000000419BDC: CC210005 02005306
	s_delay_alu instid0(VALU_DEP_2)                            // 000000419BE4: BF870002
	v_fma_mixhi_f16 v5, v9, s41, 0                             // 000000419BE8: CC220005 02005309
	v_fma_mixhi_f16 v6, v12, s41, 0                            // 000000419BF0: CC220006 0200530C
	v_fma_mixlo_f16 v6, v10, s41, 0                            // 000000419BF8: CC210006 0200530A
	ds_store_b64 v11, v[5:6]                                   // 000000419C00: D9340000 0000050B
	s_and_not1_b32 exec_lo, exec_lo, s33                       // 000000419C08: 917E217E
	s_cbranch_execnz 65297                                     // 000000419C0C: BFA6FF11 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x654>
	s_or_b32 exec_lo, exec_lo, s22                             // 000000419C10: 8C7E167E
	s_bfe_i32 s6, s7, 0x1001c                                  // 000000419C14: 9386FF07 0001001C
	s_lshr_b32 s4, s27, 28                                     // 000000419C1C: 85049C1B
	s_lshr_b64 s[2:3], s[6:7], 29                              // 000000419C20: 85829D06
	s_add_i32 s4, s19, s4                                      // 000000419C24: 81040413
	s_add_i32 s2, s2, 7                                        // 000000419C28: 81028702
	s_lshl_b32 s3, s7, 3                                       // 000000419C2C: 84038307
	s_ashr_i32 s2, s2, 3                                       // 000000419C30: 86028302
	s_lshl_b32 s5, s29, 3                                      // 000000419C34: 8405831D
	.long 0xd72c0001                                           // 000000419C38: D72C0001
	v_cndmask_b32_e32 v1, s2, v7, vcc_lo                       // 000000419C3C: 02020E02
	v_lshlrev_b32_e32 v9, 2, v8                                // 000000419C40: 30121082
	s_waitcnt lgkmcnt(0)                                       // 000000419C44: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000419C48: BC7C0000
	s_barrier                                                  // 000000419C4C: BFBD0000
	buffer_gl0_inv                                             // 000000419C50: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s2, v1                                // 000000419C58: 4A040202
	s_ashr_i32 s2, s4, 4                                       // 000000419C5C: 86028404
	s_ashr_i32 s4, s5, 31                                      // 000000419C60: 86049F05
	s_mul_hi_i32 s6, s26, s2                                   // 000000419C64: 9706021A
	s_mul_i32 s2, s26, s2                                      // 000000419C68: 9602021A
	v_min_i32_e32 v10, s3, v2                                  // 000000419C6C: 22140403
	s_add_u32 s2, s2, s5                                       // 000000419C70: 80020502
	s_addc_u32 s3, s6, s4                                      // 000000419C74: 82030406
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000419C78: BF870099
	s_lshl_b64 s[4:5], s[2:3], 10                              // 000000419C7C: 84848A02
	v_cmp_lt_i32_e32 vcc_lo, v1, v10                           // 000000419C80: 7C821501
	s_add_u32 s3, s8, s4                                       // 000000419C84: 80030408
	s_addc_u32 s4, s9, s5                                      // 000000419C88: 82040509
	s_and_saveexec_b32 s5, vcc_lo                              // 000000419C8C: BE85206A
	s_cbranch_execz 93                                         // 000000419C90: BFA5005D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xc08>
	.long 0xd7010202                                           // 000000419C94: D7010202
	v_cndmask_b32_e32 v0, v8, v129, vcc_lo                     // 000000419C98: 02010308
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000419C9C: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s2                           // 000000419CA0: D5010003 00093F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000419CA8: 3404029F
	.long 0xd44c0002                                           // 000000419CAC: D44C0002
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000419CB0: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000419CB4: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s2                          // 000000419CB8: D5010005 000902FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v11, v5, v3      // 000000419CC4: CA200080 040A0705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000419CCC: BF870114
	.long 0xd73c0005                                           // 000000419CD0: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000419CD4: 0202028A
	.long 0xd73c0002                                           // 000000419CD8: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000419CDC: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000419CE0: BF870223
	v_lshlrev_b32_e32 v4, 24, v11                              // 000000419CE4: 30081698
	v_bfe_i32 v12, v11, 7, 1                                   // 000000419CE8: D611000C 02050F0B
	.long 0xd700020d                                           // 000000419CF0: D700020D
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 000000419CF4: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000419CF8: BF870211
	v_add_co_ci_u32_e64 v6, null, s4, v6, s2                   // 000000419CFC: D5207C06 000A0C04
	v_ashrrev_i32_e32 v11, 22, v4                              // 000000419D04: 34160896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000419D08: BF870093
	.long 0xd7000204                                           // 000000419D0C: D7000204
	v_cndmask_b32_e32 v1, v13, v2, vcc_lo                      // 000000419D10: 0202050D
	v_add_co_ci_u32_e64 v5, null, v6, v3, s2                   // 000000419D14: D5207C05 000A0706
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000419D1C: BF870093
	.long 0xd700020b                                           // 000000419D20: D700020B
	v_cndmask_b32_e32 v1, v13, v11, vcc_lo                     // 000000419D24: 0202170D
	v_add_co_ci_u32_e64 v12, null, v6, v12, s2                 // 000000419D28: D5207C0C 000A1906
	.long 0xd700020d                                           // 000000419D30: D700020D
	v_cndmask_b32_e32 v1, v13, v9, vcc_lo                      // 000000419D34: 0202130D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000419D38: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v6, s2                   // 000000419D3C: D5207C0E 000A0C80
	s_clause 0x17                                              // 000000419D44: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000419D48: DC520000 027C0004
	global_load_b32 v56, v[4:5], off offset:128                // 000000419D50: DC520080 387C0004
	global_load_b32 v53, v[4:5], off offset:256                // 000000419D58: DC520100 357C0004
	global_load_b32 v50, v[4:5], off offset:384                // 000000419D60: DC520180 327C0004
	global_load_b32 v47, v[4:5], off offset:512                // 000000419D68: DC520200 2F7C0004
	global_load_b32 v44, v[4:5], off offset:640                // 000000419D70: DC520280 2C7C0004
	global_load_b32 v26, v[4:5], off offset:768                // 000000419D78: DC520300 1A7C0004
	global_load_b32 v20, v[4:5], off offset:896                // 000000419D80: DC520380 147C0004
	global_load_b32 v4, v[11:12], off                          // 000000419D88: DC520000 047C000B
	global_load_b32 v57, v[11:12], off offset:128              // 000000419D90: DC520080 397C000B
	global_load_b32 v54, v[11:12], off offset:256              // 000000419D98: DC520100 367C000B
	global_load_b32 v51, v[11:12], off offset:384              // 000000419DA0: DC520180 337C000B
	global_load_b32 v48, v[11:12], off offset:512              // 000000419DA8: DC520200 307C000B
	global_load_b32 v45, v[11:12], off offset:640              // 000000419DB0: DC520280 2D7C000B
	global_load_b32 v27, v[11:12], off offset:768              // 000000419DB8: DC520300 1B7C000B
	global_load_b32 v21, v[11:12], off offset:896              // 000000419DC0: DC520380 157C000B
	global_load_b32 v3, v[13:14], off                          // 000000419DC8: DC520000 037C000D
	global_load_b32 v55, v[13:14], off offset:128              // 000000419DD0: DC520080 377C000D
	global_load_b32 v52, v[13:14], off offset:256              // 000000419DD8: DC520100 347C000D
	global_load_b32 v49, v[13:14], off offset:384              // 000000419DE0: DC520180 317C000D
	global_load_b32 v46, v[13:14], off offset:512              // 000000419DE8: DC520200 2E7C000D
	global_load_b32 v43, v[13:14], off offset:640              // 000000419DF0: DC520280 2B7C000D
	global_load_b32 v25, v[13:14], off offset:768              // 000000419DF8: DC520300 197C000D
	global_load_b32 v19, v[13:14], off offset:896              // 000000419E00: DC520380 137C000D
	s_or_b32 exec_lo, exec_lo, s5                              // 000000419E08: 8C7E057E
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 000000419E0C: CA100080 0B0C0080
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v14, 0             // 000000419E14: CA100080 0D0E0080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 000000419E1C: CA100080 0F100080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v18, 0             // 000000419E24: CA100080 11120080
	s_ashr_i32 s27, s26, 31                                    // 000000419E2C: 861B9F1A
	s_and_saveexec_b32 s2, vcc_lo                              // 000000419E30: BE82206A
	s_cbranch_execz 936                                        // 000000419E34: BFA503A8 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1ad8>
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v5, -1, v0      // 000000419E38: CA200080 0C0400C1
	v_dual_mov_b32 v11, 0 :: v_dual_and_b32 v22, 16, v0        // 000000419E40: CA240080 0B160090
	v_dual_mov_b32 v14, 0 :: v_dual_lshlrev_b32 v23, 2, v8     // 000000419E48: CA220080 0E161082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000419E50: BF8701B3
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v5, 31, v5         // 000000419E54: CA240080 10040A9F
	v_mov_b32_e32 v13, 0                                       // 000000419E5C: 7E1A0280
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v18, 0             // 000000419E60: CA100080 0F120080
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v24, 2, v5     // 000000419E68: CA220080 11180A82
	s_mov_b32 s5, 0                                            // 000000419E70: BE850080
	s_movk_i32 s6, 0x1eee                                      // 000000419E74: B0061EEE
	s_branch 860                                               // 000000419E78: BFA0035C <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x19ec>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000419E7C: 8C7E077E
	s_waitcnt vmcnt(15)                                        // 000000419E80: BF893FF7
	v_alignbit_b32 v58, v2, v4, 16                             // 000000419E84: D616003A 02420902
	s_waitcnt vmcnt(7)                                         // 000000419E8C: BF891FF7
	v_bfe_u32 v59, v3, 12, 16                                  // 000000419E90: D610003B 02411903
	v_bfe_u32 v60, v3, 8, 16                                   // 000000419E98: D610003C 02411103
	v_lshl_or_b32 v1, v1, 5, v22                               // 000000419EA0: D6560001 04590B01
	v_bfe_u32 v61, v3, 4, 16                                   // 000000419EA8: D610003D 02410903
	v_bfe_u32 v62, v58, 12, 16                                 // 000000419EB0: D610003E 0241193A
	v_bfe_u32 v65, v58, 8, 16                                  // 000000419EB8: D6100041 0241113A
	.long 0xd72c003b                                           // 000000419EC0: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000419EC4: 020276FF 83DCD12D
	.long 0xd72c003c                                           // 000000419ECC: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000419ED0: 020278FF 83DCD12D
	.long 0xd72c003d                                           // 000000419ED8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000419EDC: 02027AFF 83DCD12D
	.long 0xd72c003e                                           // 000000419EE4: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000419EE8: 02027CFF 83DCD12D
	.long 0xd72c0041                                           // 000000419EF0: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000419EF4: 020282FF 83DCD12D
	v_alignbit_b32 v56, v56, v57, 16                           // 000000419EFC: D6160038 02427338
	v_alignbit_b32 v53, v53, v54, 16                           // 000000419F04: D6160035 02426D35
	v_alignbit_b32 v50, v50, v51, 16                           // 000000419F0C: D6160032 02426732
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000419F14: D622003B 03FD013B 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000419F20: D622003C 03FD013C 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000419F2C: D622003D 03FD013D 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000419F38: D622003E 03FD013E 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000419F44: D6220041 03FD0141 00006400
	v_and_b32_e32 v59, 0xffff, v59                             // 000000419F50: 367676FF 0000FFFF
	v_bfe_u32 v51, v50, 12, 16                                 // 000000419F58: D6100033 02411932
	v_alignbit_b32 v47, v47, v48, 16                           // 000000419F60: D616002F 0242612F
	v_and_b32_e32 v62, 0xffff, v62                             // 000000419F68: 367C7CFF 0000FFFF
	v_alignbit_b32 v44, v44, v45, 16                           // 000000419F70: D616002C 02425B2C
	v_lshl_or_b32 v59, v60, 16, v59                            // 000000419F78: D656003B 04ED213C
	.long 0xd72c0033                                           // 000000419F80: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000419F84: 020266FF 83DCD12D
	v_alignbit_b32 v26, v26, v27, 16                           // 000000419F8C: D616001A 0242371A
	v_lshl_or_b32 v62, v65, 16, v62                            // 000000419F94: D656003E 04F92141
	s_waitcnt vmcnt(5)                                         // 000000419F9C: BF8917F7
	v_bfe_u32 v65, v52, 4, 16                                  // 000000419FA0: D6100041 02410934
	v_pk_fma_f16 v59, v59, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000419FA8: CC0E003B 0BFC0D3B 0000C931
	v_alignbit_b32 v20, v20, v21, 16                           // 000000419FB4: D6160014 02422B14
	v_cmp_eq_u32_e32 vcc_lo, v5, v10                           // 000000419FBC: 7C941505
	v_pk_fma_f16 v60, v62, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000419FC0: CC0E003C 0BFC0D3E 0000C931
	v_and_b32_e32 v63, 0xffff, v3                              // 000000419FCC: 367E06FF 0000FFFF
	ds_load_b128 v[1:4], v1                                    // 000000419FD4: DBFC0000 01000001
	v_bfe_u32 v62, v55, 12, 16                                 // 000000419FDC: D610003E 02411937
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000419FE4: D6220033 03FD0133 00006400
	s_or_b32 s5, vcc_lo, s5                                    // 000000419FF0: 8C05056A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000419FF4: BF870112
	.long 0xd72c003e                                           // 000000419FF8: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000419FFC: 02027CFF 83DCD12D
	v_and_b32_e32 v51, 0xffff, v51                             // 00000041A004: 366666FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041A00C: BF870092
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000041A010: D622003E 03FD013E 00006400
	v_and_b32_e32 v62, 0xffff, v62                             // 00000041A01C: 367C7CFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 00000041A024: BF89FC07
	v_dot2acc_f32_f16 v18, v60, v1                             // 00000041A028: 0424033C
	.long 0xd72c003f                                           // 00000041A02C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 00000041A030: 02027EFF 83DCD12D
	v_and_b32_e32 v60, 0xffff, v56                             // 00000041A038: 367870FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041A040: BF870191
	.long 0xd72c003c                                           // 00000041A044: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 00000041A048: 020278FF 83DCD12D
	v_sad_u8 v63, v63, 0, 0x6400                               // 00000041A050: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041A05C: BF870191
	v_lshlrev_b32_e32 v63, 16, v63                             // 00000041A060: 307E7E90
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000041A064: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 00000041A070: BF870002
	v_and_or_b32 v57, 0xffff, v61, v63                         // 00000041A074: D6570039 04FE7AFF 0000FFFF
	v_bfe_u32 v61, v56, 12, 16                                 // 00000041A080: D610003D 02411938
	v_bfe_u32 v63, v56, 8, 16                                  // 00000041A088: D610003F 02411138
	v_bfe_u32 v56, v56, 4, 16                                  // 00000041A090: D6100038 02410938
	v_lshlrev_b32_e32 v60, 16, v60                             // 00000041A098: 30787890
	v_pk_fma_f16 v57, v57, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A09C: CC0E0039 0BFC0D39 0000C931
	.long 0xd72c003d                                           // 00000041A0A8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 00000041A0AC: 02027AFF 83DCD12D
	.long 0xd72c003f                                           // 00000041A0B4: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 00000041A0B8: 02027EFF 83DCD12D
	.long 0xd72c0038                                           // 00000041A0C0: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 00000041A0C4: 020270FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041A0CC: BF870193
	v_sad_u8 v61, v61, 0, 0x6400                               // 00000041A0D0: D622003D 03FD013D 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 00000041A0DC: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041A0E8: BF870193
	v_sad_u8 v56, v56, 0, 0x6400                               // 00000041A0EC: D6220038 03FD0138 00006400
	v_and_b32_e32 v61, 0xffff, v61                             // 00000041A0F8: 367A7AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041A100: BF870112
	v_and_or_b32 v56, 0xffff, v56, v60                         // 00000041A104: D6570038 04F270FF 0000FFFF
	v_lshl_or_b32 v61, v63, 16, v61                            // 00000041A110: D656003D 04F5213F
	v_bfe_u32 v63, v52, 12, 16                                 // 00000041A118: D610003F 02411934
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041A120: BF870193
	v_pk_fma_f16 v56, v56, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A124: CC0E0038 0BFC0D38 0000C931
	v_pk_fma_f16 v54, v61, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A130: CC0E0036 0BFC0D3D 0000C931
	v_and_b32_e32 v64, 0xffff, v58                             // 00000041A13C: 368074FF 0000FFFF
	v_bfe_u32 v58, v58, 4, 16                                  // 00000041A144: D610003A 0241093A
	v_and_b32_e32 v61, 0xffff, v53                             // 00000041A14C: 367A6AFF 0000FFFF
	.long 0xd72c003f                                           // 00000041A154: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 00000041A158: 02027EFF 83DCD12D
	v_dot2acc_f32_f16 v17, v54, v1                             // 00000041A160: 04220336
	.long 0xd72c0040                                           // 00000041A164: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 00000041A168: 020280FF 83DCD12D
	.long 0xd72c003a                                           // 00000041A170: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 00000041A174: 020274FF 83DCD12D
	.long 0xd72c0036                                           // 00000041A17C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 00000041A180: 020282FF 83DCD12D
	.long 0xd72c003d                                           // 00000041A188: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 00000041A18C: 02027AFF 83DCD12D
	v_dot2acc_f32_f16 v17, v56, v2                             // 00000041A194: 04220538
	s_waitcnt vmcnt(4)                                         // 00000041A198: BF8913F7
	v_bfe_u32 v56, v49, 4, 16                                  // 00000041A19C: D6100038 02410931
	v_sad_u8 v63, v63, 0, 0x6400                               // 00000041A1A4: D622003F 03FD013F 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 00000041A1B0: D6220040 03FD0140 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000041A1BC: D622003A 03FD013A 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 00000041A1C8: D6220036 03FD0136 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 00000041A1D4: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041A1E0: BF870114
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000041A1E4: 30808090
	v_lshlrev_b32_e32 v61, 16, v61                             // 00000041A1E8: 307A7A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000041A1EC: BF870122
	v_and_or_b32 v58, 0xffff, v58, v64                         // 00000041A1F0: D657003A 050274FF 0000FFFF
	v_bfe_u32 v64, v55, 8, 16                                  // 00000041A1FC: D6100040 02411137
	v_pk_fma_f16 v58, v58, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A204: CC0E003A 0BFC0D3A 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041A210: BF870191
	v_dot2acc_f32_f16 v18, v58, v2                             // 00000041A214: 0424053A
	.long 0xd72c003a                                           // 00000041A218: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 00000041A21C: 020280FF 83DCD12D
	v_bfe_u32 v64, v55, 4, 16                                  // 00000041A224: D6100040 02410937
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000041A22C: BF8701A3
	v_dot2acc_f32_f16 v18, v59, v3                             // 00000041A230: 0424073B
	v_bfe_u32 v59, v53, 12, 16                                 // 00000041A234: D610003B 02411935
	.long 0xd72c003c                                           // 00000041A23C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 00000041A240: 020280FF 83DCD12D
	v_bfe_u32 v64, v52, 8, 16                                  // 00000041A248: D6100040 02411134
	v_and_b32_e32 v52, 0xffff, v52                             // 00000041A250: 366868FF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000041A258: D622003A 03FD013A 00006400
	.long 0xd72c003b                                           // 00000041A264: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 00000041A268: 020276FF 83DCD12D
	v_dot2acc_f32_f16 v18, v57, v4                             // 00000041A270: 04240939
	.long 0xd72c0040                                           // 00000041A274: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 00000041A278: 020280FF 83DCD12D
	.long 0xd72c0034                                           // 00000041A280: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 00000041A284: 020268FF 83DCD12D
	v_lshl_or_b32 v58, v58, 16, v62                            // 00000041A28C: D656003A 04F9213A
	v_bfe_u32 v62, v53, 8, 16                                  // 00000041A294: D610003E 02411135
	v_bfe_u32 v53, v53, 4, 16                                  // 00000041A29C: D6100035 02410935
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000041A2A4: D622003C 03FD013C 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000041A2B0: D622003B 03FD013B 00006400
	v_pk_fma_f16 v58, v58, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A2BC: CC0E003A 0BFC0D3A 0000C931
	.long 0xd72c003e                                           // 00000041A2C8: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 00000041A2CC: 02027CFF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 00000041A2D4: D6220034 03FD0134 00006400
	.long 0xd72c0035                                           // 00000041A2E0: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 00000041A2E4: 02026AFF 83DCD12D
	s_waitcnt vmcnt(3)                                         // 00000041A2EC: BF890FF7
	v_bfe_u32 v57, v46, 8, 16                                  // 00000041A2F0: D6100039 0241112E
	v_dot2acc_f32_f16 v17, v58, v3                             // 00000041A2F8: 0422073A
	v_bfe_u32 v58, v46, 4, 16                                  // 00000041A2FC: D610003A 0241092E
	v_lshlrev_b32_e32 v52, 16, v52                             // 00000041A304: 30686890
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000041A308: D622003E 03FD013E 00006400
	.long 0xd72c0039                                           // 00000041A314: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 00000041A318: 020272FF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 00000041A320: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041A32C: BF870114
	v_and_or_b32 v52, 0xffff, v54, v52                         // 00000041A330: D6570034 04D26CFF 0000FFFF
	v_and_or_b32 v53, 0xffff, v53, v61                         // 00000041A33C: D6570035 04F66AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000041A348: BF870232
	v_pk_fma_f16 v52, v52, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A34C: CC0E0034 0BFC0D34 0000C931
	v_and_b32_e32 v59, 0xffff, v59                             // 00000041A358: 367676FF 0000FFFF
	v_and_b32_e32 v61, 0xffff, v63                             // 00000041A360: 367A7EFF 0000FFFF
	v_pk_fma_f16 v53, v53, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A368: CC0E0035 0BFC0D35 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000041A374: BF870123
	v_lshl_or_b32 v59, v62, 16, v59                            // 00000041A378: D656003B 04ED213E
	v_sad_u8 v62, v64, 0, 0x6400                               // 00000041A380: D622003E 03FD0140 00006400
	v_pk_fma_f16 v59, v59, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A38C: CC0E003B 0BFC0D3B 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041A398: BF870112
	v_lshl_or_b32 v61, v62, 16, v61                            // 00000041A39C: D656003D 04F5213E
	v_dual_dot2acc_f32_f16 v16, v59, v1 :: v_dual_and_b32 v55, 0xffff, v55// 00000041A3A4: CB24033B 10366EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041A3B0: BF870112
	v_pk_fma_f16 v54, v61, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A3B4: CC0E0036 0BFC0D3D 0000C931
	v_dot2acc_f32_f16 v16, v53, v2                             // 00000041A3C0: 04200535
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041A3C4: BF870113
	.long 0xd72c0037                                           // 00000041A3C8: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 00000041A3CC: 02026EFF 83DCD12D
	v_dot2acc_f32_f16 v16, v54, v3                             // 00000041A3D4: 04200736
	v_bfe_u32 v54, v49, 12, 16                                 // 00000041A3D8: D6100036 02411931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041A3E0: BF870193
	v_sad_u8 v55, v55, 0, 0x6400                               // 00000041A3E4: D6220037 03FD0137 00006400
	v_dot2acc_f32_f16 v16, v52, v4                             // 00000041A3F0: 04200934
	v_bfe_u32 v52, v50, 8, 16                                  // 00000041A3F4: D6100034 02411132
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041A3FC: BF870214
	.long 0xd72c0036                                           // 00000041A400: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 00000041A404: 02026CFF 83DCD12D
	v_lshlrev_b32_e32 v55, 16, v55                             // 00000041A40C: 306E6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041A410: BF870113
	.long 0xd72c0034                                           // 00000041A414: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 00000041A418: 020268FF 83DCD12D
	v_and_or_b32 v55, 0xffff, v60, v55                         // 00000041A420: D6570037 04DE78FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041A42C: BF870114
	v_sad_u8 v54, v54, 0, 0x6400                               // 00000041A430: D6220036 03FD0136 00006400
	v_pk_fma_f16 v53, v55, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A43C: CC0E0035 0BFC0D37 0000C931
	v_bfe_u32 v55, v49, 8, 16                                  // 00000041A448: D6100037 02411131
	s_delay_alu instid0(VALU_DEP_3)                            // 00000041A450: BF870003
	v_and_b32_e32 v54, 0xffff, v54                             // 00000041A454: 366C6CFF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v49                             // 00000041A45C: 366262FF 0000FFFF
	v_sad_u8 v52, v52, 0, 0x6400                               // 00000041A464: D6220034 03FD0134 00006400
	v_dot2acc_f32_f16 v17, v53, v4                             // 00000041A470: 04220935
	v_and_b32_e32 v53, 0xffff, v50                             // 00000041A474: 366A64FF 0000FFFF
	v_bfe_u32 v50, v50, 4, 16                                  // 00000041A47C: D6100032 02410932
	.long 0xd72c0037                                           // 00000041A484: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 00000041A488: 02026EFF 83DCD12D
	.long 0xd72c0031                                           // 00000041A490: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 00000041A494: 020262FF 83DCD12D
	v_lshl_or_b32 v51, v52, 16, v51                            // 00000041A49C: D6560033 04CD2134
	.long 0xd72c0035                                           // 00000041A4A4: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 00000041A4A8: 02026AFF 83DCD12D
	.long 0xd72c0032                                           // 00000041A4B0: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 00000041A4B4: 020264FF 83DCD12D
	.long 0xd72c0034                                           // 00000041A4BC: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 00000041A4C0: 020270FF 83DCD12D
	v_bfe_u32 v56, v46, 12, 16                                 // 00000041A4C8: D6100038 0241192E
	v_pk_fma_f16 v51, v51, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A4D0: CC0E0033 0BFC0D33 0000C931
	v_sad_u8 v55, v55, 0, 0x6400                               // 00000041A4DC: D6220037 03FD0137 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 00000041A4E8: D6220031 03FD0131 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 00000041A4F4: D6220035 03FD0135 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 00000041A500: D6220032 03FD0132 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041A50C: BF870004
	v_lshl_or_b32 v48, v55, 16, v54                            // 00000041A510: D6560030 04D92137
	v_and_b32_e32 v54, 0xffff, v47                             // 00000041A518: 366C5EFF 0000FFFF
	v_bfe_u32 v55, v47, 8, 16                                  // 00000041A520: D6100037 0241112F
	v_lshlrev_b32_e32 v53, 16, v53                             // 00000041A528: 306A6A90
	.long 0xd72c0038                                           // 00000041A52C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 00000041A530: 020270FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 00000041A538: D6220034 03FD0134 00006400
	.long 0xd72c0036                                           // 00000041A544: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 00000041A548: 02026CFF 83DCD12D
	.long 0xd72c0037                                           // 00000041A550: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 00000041A554: 02026EFF 83DCD12D
	v_and_or_b32 v50, 0xffff, v50, v53                         // 00000041A55C: D6570032 04D664FF 0000FFFF
	v_bfe_u32 v53, v47, 12, 16                                 // 00000041A568: D6100035 0241192F
	v_bfe_u32 v47, v47, 4, 16                                  // 00000041A570: D610002F 0241092F
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000041A578: 30626290
	v_sad_u8 v56, v56, 0, 0x6400                               // 00000041A57C: D6220038 03FD0138 00006400
	v_pk_fma_f16 v50, v50, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A588: CC0E0032 0BFC0D32 0000C931
	.long 0xd72c0035                                           // 00000041A594: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 00000041A598: 02026AFF 83DCD12D
	.long 0xd72c002f                                           // 00000041A5A0: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 00000041A5A4: 02025EFF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 00000041A5AC: D6220036 03FD0136 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 00000041A5B8: D6220037 03FD0137 00006400
	v_and_or_b32 v49, 0xffff, v52, v49                         // 00000041A5C4: D6570031 04C668FF 0000FFFF
	v_dot2acc_f32_f16 v15, v51, v1                             // 00000041A5D0: 041E0333
	v_pk_fma_f16 v48, v48, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A5D4: CC0E0030 0BFC0D30 0000C931
	v_lshlrev_b32_e32 v54, 16, v54                             // 00000041A5E0: 306C6C90
	v_sad_u8 v53, v53, 0, 0x6400                               // 00000041A5E4: D6220035 03FD0135 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 00000041A5F0: D622002F 03FD012F 00006400
	v_dot2acc_f32_f16 v15, v50, v2                             // 00000041A5FC: 041E0532
	s_waitcnt vmcnt(2)                                         // 00000041A600: BF890BF7
	v_bfe_u32 v50, v43, 12, 16                                 // 00000041A604: D6100032 0241192B
	v_and_b32_e32 v53, 0xffff, v53                             // 00000041A60C: 366A6AFF 0000FFFF
	v_and_or_b32 v47, 0xffff, v47, v54                         // 00000041A614: D657002F 04DA5EFF 0000FFFF
	v_dual_dot2acc_f32_f16 v15, v48, v3 :: v_dual_and_b32 v54, 0xffff, v56// 00000041A620: CB240730 0F3670FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041A62C: BF870214
	.long 0xd72c0032                                           // 00000041A630: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 00000041A634: 020264FF 83DCD12D
	v_lshl_or_b32 v52, v55, 16, v53                            // 00000041A63C: D6560034 04D52137
	v_sad_u8 v55, v57, 0, 0x6400                               // 00000041A644: D6220037 03FD0139 00006400
	v_pk_fma_f16 v47, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A650: CC0E002F 0BFC0D2F 0000C931
	.long 0xd72c0035                                           // 00000041A65C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 00000041A660: 020274FF 83DCD12D
	v_mov_b32_e32 v57, v41                                     // 00000041A668: 7E720329
	v_pk_fma_f16 v51, v52, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A66C: CC0E0033 0BFC0D34 0000C931
	v_lshl_or_b32 v52, v55, 16, v54                            // 00000041A678: D6560034 04D92137
	v_sad_u8 v50, v50, 0, 0x6400                               // 00000041A680: D6220032 03FD0132 00006400
	v_dual_mov_b32 v55, v41 :: v_dual_mov_b32 v56, v35         // 00000041A68C: CA100129 37380123
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041A694: BF870214
	v_dot2acc_f32_f16 v14, v51, v1                             // 00000041A698: 041C0333
	v_pk_fma_f16 v45, v52, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A69C: CC0E002D 0BFC0D34 0000C931
	v_bfe_u32 v51, v43, 8, 16                                  // 00000041A6A8: D6100033 0241112B
	v_bfe_u32 v52, v43, 4, 16                                  // 00000041A6B0: D6100034 0241092B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000041A6B8: BF870234
	v_dual_dot2acc_f32_f16 v14, v47, v2 :: v_dual_and_b32 v43, 0xffff, v43// 00000041A6BC: CB24052F 0E2A56FF 0000FFFF
	v_pk_fma_f16 v47, v49, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A6C8: CC0E002F 0BFC0D31 0000C931
	v_bfe_u32 v49, v44, 12, 16                                 // 00000041A6D4: D6100031 0241192C
	.long 0xd72c0034                                           // 00000041A6DC: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 00000041A6E0: 020268FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041A6E8: BF870004
	.long 0xd72c002b                                           // 00000041A6EC: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 00000041A6F0: 020256FF 83DCD12D
	v_dot2acc_f32_f16 v14, v45, v3                             // 00000041A6F8: 041C072D
	v_bfe_u32 v45, v44, 8, 16                                  // 00000041A6FC: D610002D 0241112C
	.long 0xd72c0030                                           // 00000041A704: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 00000041A708: 020262FF 83DCD12D
	v_and_b32_e32 v49, 0xffff, v44                             // 00000041A710: 366258FF 0000FFFF
	v_bfe_u32 v44, v44, 4, 16                                  // 00000041A718: D610002C 0241092C
	.long 0xd72c0033                                           // 00000041A720: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 00000041A724: 020266FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 00000041A72C: D6220034 03FD0134 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 00000041A738: D622002B 03FD012B 00006400
	.long 0xd72c0031                                           // 00000041A744: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 00000041A748: 020262FF 83DCD12D
	.long 0xd72c002d                                           // 00000041A750: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 00000041A754: 02025AFF 83DCD12D
	v_sad_u8 v48, v48, 0, 0x6400                               // 00000041A75C: D6220030 03FD0130 00006400
	.long 0xd72c002c                                           // 00000041A768: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 00000041A76C: 020258FF 83DCD12D
	v_lshlrev_b32_e32 v43, 16, v43                             // 00000041A774: 30565690
	v_sad_u8 v51, v51, 0, 0x6400                               // 00000041A778: D6220033 03FD0133 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 00000041A784: D6220035 03FD0135 00006400
	v_and_b32_e32 v48, 0xffff, v48                             // 00000041A790: 366060FF 0000FFFF
	v_sad_u8 v49, v49, 0, 0x6400                               // 00000041A798: D6220031 03FD0131 00006400
	v_and_or_b32 v43, 0xffff, v52, v43                         // 00000041A7A4: D657002B 04AE68FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 00000041A7B0: D622002D 03FD012D 00006400
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000041A7BC: D622002C 03FD012C 00006400
	s_waitcnt vmcnt(1)                                         // 00000041A7C8: BF8907F7
	v_bfe_u32 v52, v25, 8, 16                                  // 00000041A7CC: D6100034 02411119
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000041A7D4: 30626290
	v_pk_fma_f16 v43, v43, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A7D8: CC0E002B 0BFC0D2B 0000C931
	v_and_b32_e32 v50, 0xffff, v50                             // 00000041A7E4: 366464FF 0000FFFF
	v_lshl_or_b32 v45, v45, 16, v48                            // 00000041A7EC: D656002D 04C1212D
	v_bfe_u32 v48, v26, 12, 16                                 // 00000041A7F4: D6100030 0241191A
	v_and_or_b32 v44, 0xffff, v44, v49                         // 00000041A7FC: D657002C 04C658FF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v26                             // 00000041A808: 366234FF 0000FFFF
	v_lshl_or_b32 v27, v51, 16, v50                            // 00000041A810: D656001B 04C92133
	v_bfe_u32 v50, v25, 12, 16                                 // 00000041A818: D6100032 02411919
	v_pk_fma_f16 v45, v45, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A820: CC0E002D 0BFC0D2D 0000C931
	.long 0xd72c0030                                           // 00000041A82C: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 00000041A830: 020260FF 83DCD12D
	v_bfe_u32 v51, v26, 8, 16                                  // 00000041A838: D6100033 0241111A
	v_bfe_u32 v26, v26, 4, 16                                  // 00000041A840: D610001A 0241091A
	.long 0xd72c0032                                           // 00000041A848: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 00000041A84C: 020264FF 83DCD12D
	.long 0xd72c0031                                           // 00000041A854: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 00000041A858: 020262FF 83DCD12D
	v_dot2acc_f32_f16 v13, v45, v1                             // 00000041A860: 041A032D
	.long 0xd72c0033                                           // 00000041A864: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 00000041A868: 020266FF 83DCD12D
	.long 0xd72c002d                                           // 00000041A870: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 00000041A874: 020268FF 83DCD12D
	v_pk_fma_f16 v44, v44, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A87C: CC0E002C 0BFC0D2C 0000C931
	v_sad_u8 v48, v48, 0, 0x6400                               // 00000041A888: D6220030 03FD0130 00006400
	.long 0xd72c001a                                           // 00000041A894: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 00000041A898: 020234FF 83DCD12D
	v_sad_u8 v50, v50, 0, 0x6400                               // 00000041A8A0: D6220032 03FD0132 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 00000041A8AC: D6220031 03FD0131 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000041A8B8: BF870224
	v_dual_dot2acc_f32_f16 v13, v44, v2 :: v_dual_and_b32 v48, 0xffff, v48// 00000041A8BC: CB24052C 0D3060FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 00000041A8C8: D6220033 03FD0133 00006400
	v_and_b32_e32 v50, 0xffff, v50                             // 00000041A8D4: 366464FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 00000041A8DC: D622002D 03FD012D 00006400
	v_bfe_u32 v44, v20, 12, 16                                 // 00000041A8E8: D610002C 02411914
	v_sad_u8 v26, v26, 0, 0x6400                               // 00000041A8F0: D622001A 03FD011A 00006400
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000041A8FC: 30626290
	v_bfe_u32 v52, v25, 4, 16                                  // 00000041A900: D6100034 02410919
	v_lshl_or_b32 v48, v51, 16, v48                            // 00000041A908: D6560030 04C12133
	v_lshl_or_b32 v45, v45, 16, v50                            // 00000041A910: D656002D 04C9212D
	.long 0xd72c002c                                           // 00000041A918: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 00000041A91C: 020258FF 83DCD12D
	v_bfe_u32 v50, v20, 8, 16                                  // 00000041A924: D6100032 02411114
	s_waitcnt vmcnt(0)                                         // 00000041A92C: BF8903F7
	v_bfe_u32 v51, v19, 12, 16                                 // 00000041A930: D6100033 02411913
	v_and_or_b32 v26, 0xffff, v26, v49                         // 00000041A938: D657001A 04C634FF 0000FFFF
	.long 0xd72c0031                                           // 00000041A944: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 00000041A948: 020268FF 83DCD12D
	v_bfe_u32 v52, v19, 8, 16                                  // 00000041A950: D6100034 02411113
	.long 0xd72c0032                                           // 00000041A958: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 00000041A95C: 020264FF 83DCD12D
	.long 0xd72c0033                                           // 00000041A964: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 00000041A968: 020266FF 83DCD12D
	v_pk_fma_f16 v27, v27, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A970: CC0E001B 0BFC0D1B 0000C931
	v_and_b32_e32 v46, 0xffff, v46                             // 00000041A97C: 365C5CFF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000041A984: D622002C 03FD012C 00006400
	.long 0xd72c0034                                           // 00000041A990: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 00000041A994: 020268FF 83DCD12D
	v_and_b32_e32 v25, 0xffff, v25                             // 00000041A99C: 363232FF 0000FFFF
	v_dot2acc_f32_f16 v13, v27, v3                             // 00000041A9A4: 041A071B
	.long 0xd72c002e                                           // 00000041A9A8: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 00000041A9AC: 02025CFF 83DCD12D
	v_and_b32_e32 v44, 0xffff, v44                             // 00000041A9B4: 365858FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 00000041A9BC: D6220032 03FD0132 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 00000041A9C8: D6220033 03FD0133 00006400
	v_dual_mov_b32 v54, v40 :: v_dual_dot2acc_f32_f16 v15, v47, v4// 00000041A9D4: CA180128 360E092F
	v_pk_fma_f16 v26, v26, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041A9DC: CC0E001A 0BFC0D1A 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041A9E8: BF870214
	v_lshl_or_b32 v44, v50, 16, v44                            // 00000041A9EC: D656002C 04B12132
	v_dual_mov_b32 v27, v36 :: v_dual_and_b32 v50, 0xffff, v51 // 00000041A9F4: CA240124 1B3266FF 0000FFFF
	v_sad_u8 v51, v52, 0, 0x6400                               // 00000041AA00: D6220033 03FD0134 00006400
	v_mov_b32_e32 v52, v40                                     // 00000041AA0C: 7E680328
	.long 0xd72c0015                                           // 00000041AA10: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 00000041AA14: 020232FF 83DCD12D
	v_pk_fma_f16 v25, v48, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041AA1C: CC0E0019 0BFC0D30 0000C931
	v_sad_u8 v48, v49, 0, 0x6400                               // 00000041AA28: D6220030 03FD0131 00006400
	v_and_b32_e32 v49, 0xffff, v20                             // 00000041AA34: 366228FF 0000FFFF
	v_sad_u8 v46, v46, 0, 0x6400                               // 00000041AA3C: D622002E 03FD012E 00006400
	v_bfe_u32 v20, v20, 4, 16                                  // 00000041AA48: D6100014 02410914
	v_dot2acc_f32_f16 v12, v25, v1                             // 00000041AA50: 04180319
	v_pk_fma_f16 v25, v44, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041AA54: CC0E0019 0BFC0D2C 0000C931
	.long 0xd72c0031                                           // 00000041AA60: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 00000041AA64: 020262FF 83DCD12D
	v_lshlrev_b32_e32 v46, 16, v46                             // 00000041AA6C: 305C5C90
	.long 0xd72c0014                                           // 00000041AA70: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v20, vcc_lo              // 00000041AA74: 020228FF 83DCD12D
	v_sad_u8 v21, v21, 0, 0x6400                               // 00000041AA7C: D6220015 03FD0115 00006400
	v_lshl_or_b32 v44, v51, 16, v50                            // 00000041AA88: D656002C 04C92133
	v_dot2acc_f32_f16 v11, v25, v1                             // 00000041AA90: 04160319
	v_and_or_b32 v46, 0xffff, v53, v46                         // 00000041AA94: D657002E 04BA6AFF 0000FFFF
	v_bfe_u32 v53, v19, 4, 16                                  // 00000041AAA0: D6100035 02410913
	v_sad_u8 v49, v49, 0, 0x6400                               // 00000041AAA8: D6220031 03FD0131 00006400
	v_and_b32_e32 v19, 0xffff, v19                             // 00000041AAB4: 362626FF 0000FFFF
	v_sad_u8 v20, v20, 0, 0x6400                               // 00000041AABC: D6220014 03FD0114 00006400
	v_lshlrev_b32_e32 v21, 16, v21                             // 00000041AAC8: 302A2A90
	v_pk_fma_f16 v45, v45, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041AACC: CC0E002D 0BFC0D2D 0000C931
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000041AAD8: 30626290
	.long 0xd72c0013                                           // 00000041AADC: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 00000041AAE0: 020226FF 83DCD12D
	v_dot2acc_f32_f16 v12, v26, v2                             // 00000041AAE8: 0418051A
	v_and_or_b32 v1, 0xffff, v48, v21                          // 00000041AAEC: D6570001 045660FF 0000FFFF
	v_pk_fma_f16 v21, v44, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041AAF8: CC0E0015 0BFC0D2C 0000C931
	v_and_or_b32 v20, 0xffff, v20, v49                         // 00000041AB04: D6570014 04C628FF 0000FFFF
	.long 0xd72c0031                                           // 00000041AB10: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 00000041AB14: 02026AFF 83DCD12D
	v_pk_fma_f16 v46, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041AB1C: CC0E002E 0BFC0D2E 0000C931
	v_pk_fma_f16 v1, v1, s6, 0xc931 op_sel_hi:[1,0,0]          // 00000041AB28: CC0E0001 0BFC0D01 0000C931
	v_sad_u8 v19, v19, 0, 0x6400                               // 00000041AB34: D6220013 03FD0113 00006400
	v_pk_fma_f16 v20, v20, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000041AB40: CC0E0014 0BFC0D14 0000C931
	v_dot2acc_f32_f16 v12, v45, v3                             // 00000041AB4C: 0418072D
	v_dot2acc_f32_f16 v14, v46, v4                             // 00000041AB50: 041C092E
	v_dot2acc_f32_f16 v13, v43, v4                             // 00000041AB54: 041A092B
	v_sad_u8 v49, v49, 0, 0x6400                               // 00000041AB58: D6220031 03FD0131 00006400
	v_lshlrev_b32_e32 v19, 16, v19                             // 00000041AB64: 30262690
	v_dual_dot2acc_f32_f16 v11, v20, v2 :: v_dual_dot2acc_f32_f16 v12, v1, v4// 00000041AB68: CB180514 0B0C0901
	v_dual_mov_b32 v20, v6 :: v_dual_mov_b32 v25, v36          // 00000041AB70: CA100106 14180124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041AB78: BF870193
	v_and_or_b32 v19, 0xffff, v49, v19                         // 00000041AB7C: D6570013 044E62FF 0000FFFF
	v_dot2acc_f32_f16 v11, v21, v3                             // 00000041AB88: 04160715
	v_dual_mov_b32 v21, v34 :: v_dual_mov_b32 v26, v28         // 00000041AB8C: CA100122 151A011C
	v_mov_b32_e32 v43, v37                                     // 00000041AB94: 7E560325
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041AB98: BF870004
	v_pk_fma_f16 v2, v19, s6, 0xc931 op_sel_hi:[1,0,0]         // 00000041AB9C: CC0E0002 0BFC0D13 0000C931
	v_mov_b32_e32 v19, v34                                     // 00000041ABA8: 7E260322
	v_mov_b32_e32 v45, v37                                     // 00000041ABAC: 7E5A0325
	v_mov_b32_e32 v44, v29                                     // 00000041ABB0: 7E58031D
	v_mov_b32_e32 v46, v38                                     // 00000041ABB4: 7E5C0326
	v_dot2acc_f32_f16 v11, v2, v4                              // 00000041ABB8: 04160902
	v_mov_b32_e32 v48, v38                                     // 00000041ABBC: 7E600326
	v_mov_b32_e32 v47, v30                                     // 00000041ABC0: 7E5E031E
	v_mov_b32_e32 v49, v39                                     // 00000041ABC4: 7E620327
	v_mov_b32_e32 v51, v39                                     // 00000041ABC8: 7E660327
	v_dual_mov_b32 v50, v31 :: v_dual_mov_b32 v53, v32         // 00000041ABCC: CA10011F 32340120
	v_mov_b32_e32 v3, v42                                      // 00000041ABD4: 7E06032A
	v_mov_b32_e32 v4, v42                                      // 00000041ABD8: 7E08032A
	v_mov_b32_e32 v2, v33                                      // 00000041ABDC: 7E040321
	v_mov_b32_e32 v1, v5                                       // 00000041ABE0: 7E020305
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000041ABE4: 917E057E
	s_cbranch_execz 58                                         // 00000041ABE8: BFA5003A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1ad4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041ABEC: BF8700A1
	v_add_nc_u32_e32 v5, 1, v1                                 // 00000041ABF0: 4A0A0281
	s_mov_b32 s7, exec_lo                                      // 00000041ABF4: BE87007E
	.long 0xd4c1007e                                           // 00000041ABF8: D4C1007E
	v_cndmask_b32_e32 v1, v5, v10, vcc_lo                      // 00000041ABFC: 02021505
	s_cbranch_execz 64670                                      // 00000041AC00: BFA5FC9E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xc7c>
	v_ashrrev_i32_e32 v6, 31, v5                               // 00000041AC04: 340C0A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041AC08: BF870091
	.long 0xd73c001c                                           // 00000041AC0C: D73C001C
	v_cndmask_b32_e32 v1, 10, v5, vcc_lo                       // 00000041AC10: 02020A8A
	.long 0xd7006a06                                           // 00000041AC14: D7006A06
	v_cndmask_b32_e32 v1, s3, v28, vcc_lo                      // 00000041AC18: 02023803
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041AC1C: BF870111
	v_add_co_ci_u32_e64 v28, null, s4, v29, vcc_lo             // 00000041AC20: D5207C1C 01AA3A04
	.long 0xd7006a24                                           // 00000041AC28: D7006A24
	v_cndmask_b32_e32 v1, v6, v24, vcc_lo                      // 00000041AC2C: 02023106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041AC30: BF8700A1
	v_add_co_ci_u32_e64 v37, null, 0, v28, vcc_lo              // 00000041AC34: D5207C25 01AA3880
	.long 0xd7006a3a                                           // 00000041AC3C: D7006A3A
	v_cndmask_b32_e32 v1, v6, v23, vcc_lo                      // 00000041AC40: 02022F06
	v_add_co_ci_u32_e64 v59, null, 0, v28, vcc_lo              // 00000041AC44: D5207C3B 01AA3880
	s_clause 0xf                                               // 00000041AC4C: BF85000F
	global_load_b32 v33, v[36:37], off                         // 00000041AC50: DC520000 217C0024
	global_load_b32 v35, v[36:37], off offset:128              // 00000041AC58: DC520080 237C0024
	global_load_b32 v32, v[36:37], off offset:256              // 00000041AC60: DC520100 207C0024
	global_load_b32 v31, v[36:37], off offset:384              // 00000041AC68: DC520180 1F7C0024
	global_load_b32 v30, v[36:37], off offset:512              // 00000041AC70: DC520200 1E7C0024
	global_load_b32 v29, v[36:37], off offset:640              // 00000041AC78: DC520280 1D7C0024
	global_load_b32 v28, v[36:37], off offset:768              // 00000041AC80: DC520300 1C7C0024
	global_load_b32 v6, v[36:37], off offset:896               // 00000041AC88: DC520380 067C0024
	global_load_b32 v42, v[58:59], off                         // 00000041AC90: DC520000 2A7C003A
	global_load_b32 v41, v[58:59], off offset:128              // 00000041AC98: DC520080 297C003A
	global_load_b32 v40, v[58:59], off offset:256              // 00000041ACA0: DC520100 287C003A
	global_load_b32 v39, v[58:59], off offset:384              // 00000041ACA8: DC520180 277C003A
	global_load_b32 v38, v[58:59], off offset:512              // 00000041ACB0: DC520200 267C003A
	global_load_b32 v37, v[58:59], off offset:640              // 00000041ACB8: DC520280 257C003A
	global_load_b32 v36, v[58:59], off offset:768              // 00000041ACC0: DC520300 247C003A
	global_load_b32 v34, v[58:59], off offset:896              // 00000041ACC8: DC520380 227C003A
	s_branch 64618                                             // 00000041ACD0: BFA0FC6A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xc7c>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000041ACD4: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000041ACD8: BF870009
	s_or_b32 exec_lo, exec_lo, s2                              // 00000041ACDC: 8C7E027E
	s_waitcnt vmcnt(23)                                        // 00000041ACE0: BF895FF7
	v_dual_mov_b32 v1, v18 :: v_dual_mov_b32 v2, v17           // 00000041ACE4: CA100112 01020111
	s_waitcnt vmcnt(7)                                         // 00000041ACEC: BF891FF7
	v_dual_mov_b32 v3, v16 :: v_dual_mov_b32 v10, v15          // 00000041ACF0: CA100110 030A010F
	v_dual_mov_b32 v4, v14 :: v_dual_mov_b32 v5, v13           // 00000041ACF8: CA10010E 0404010D
	s_waitcnt vmcnt(0)                                         // 00000041AD00: BF8903F7
	v_dual_mov_b32 v6, v12 :: v_dual_mov_b32 v19, v11          // 00000041AD04: CA10010C 0612010B
	s_mov_b32 s2, 0x76543210                                   // 00000041AD0C: BE8200FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000041AD14: BF870009
	v_permlanex16_b32 v1, v1, s2, 0xfedcba98                   // 00000041AD18: D65C0001 03FC0501 FEDCBA98
	v_permlanex16_b32 v2, v2, s2, 0xfedcba98                   // 00000041AD24: D65C0002 03FC0502 FEDCBA98
	v_permlanex16_b32 v3, v3, s2, 0xfedcba98                   // 00000041AD30: D65C0003 03FC0503 FEDCBA98
	v_permlanex16_b32 v10, v10, s2, 0xfedcba98                 // 00000041AD3C: D65C000A 03FC050A FEDCBA98
	v_permlanex16_b32 v4, v4, s2, 0xfedcba98                   // 00000041AD48: D65C0004 03FC0504 FEDCBA98
	v_permlanex16_b32 v5, v5, s2, 0xfedcba98                   // 00000041AD54: D65C0005 03FC0505 FEDCBA98
	v_permlanex16_b32 v6, v6, s2, 0xfedcba98                   // 00000041AD60: D65C0006 03FC0506 FEDCBA98
	v_permlanex16_b32 v19, v19, s2, 0xfedcba98                 // 00000041AD6C: D65C0013 03FC0513 FEDCBA98
	.long 0xd44c0002                                           // 00000041AD78: D44C0002
	v_cndmask_b32_e32 v1, 16, v8, vcc_lo                       // 00000041AD7C: 02021090
	s_barrier                                                  // 00000041AD80: BFBD0000
	buffer_gl0_inv                                             // 00000041AD84: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 00000041AD8C: BE832002
	s_cbranch_execz 18                                         // 00000041AD90: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1bdc>
	v_dual_add_f32 v8, v11, v19 :: v_dual_add_f32 v1, v18, v1  // 00000041AD94: C908270B 08000312
	v_dual_add_f32 v2, v17, v2 :: v_dual_add_f32 v3, v16, v3   // 00000041AD9C: C9080511 02020710
	v_lshl_or_b32 v9, v7, 9, v9                                // 00000041ADA4: D6560009 04251307
	v_dual_add_f32 v10, v15, v10 :: v_dual_add_f32 v5, v13, v5 // 00000041ADAC: C908150F 0A040B0D
	v_add_f32_e32 v4, v14, v4                                  // 00000041ADB4: 0608090E
	v_add_f32_e32 v6, v12, v6                                  // 00000041ADB8: 060C0D0C
	ds_store_2addr_b32 v9, v1, v2 offset1:16                   // 00000041ADBC: D8381000 00020109
	ds_store_2addr_b32 v9, v3, v10 offset0:32 offset1:48       // 00000041ADC4: D8383020 000A0309
	ds_store_2addr_b32 v9, v4, v5 offset0:64 offset1:80        // 00000041ADCC: D8385040 00050409
	ds_store_2addr_b32 v9, v6, v8 offset0:96 offset1:112       // 00000041ADD4: D8387060 00080609
	s_or_b32 exec_lo, exec_lo, s3                              // 00000041ADDC: 8C7E037E
	.long 0xd44c0003                                           // 00000041ADE0: D44C0003
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000041ADE4: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 00000041ADEC: BF89FC07
	s_barrier                                                  // 00000041ADF0: BFBD0000
	buffer_gl0_inv                                             // 00000041ADF4: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 00000041ADFC: BE842003
	s_cbranch_execnz 7                                         // 00000041AE00: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1c20>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000041AE04: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 00000041AE08: BF048215
	s_mov_b32 s4, -1                                           // 00000041AE0C: BE8400C1
	s_cbranch_scc0 33                                          // 00000041AE10: BFA10021 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1c98>
	s_and_b32 vcc_lo, exec_lo, s4                              // 00000041AE14: 8B6A047E
	s_cbranch_vccz 63988                                       // 00000041AE18: BFA3F9F4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 164                                               // 00000041AE1C: BFA000A4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1eb0>
	v_lshlrev_b32_e32 v8, 2, v0                                // 00000041AE20: 30100082
	ds_load_2addr_stride64_b32 v[1:2], v8 offset1:2            // 00000041AE24: D8E00200 01000008
	ds_load_2addr_stride64_b32 v[3:4], v8 offset0:4 offset1:6  // 00000041AE2C: D8E00604 03000008
	s_waitcnt lgkmcnt(1)                                       // 00000041AE34: BF89FC17
	v_add_f32_e32 v1, 0, v1                                    // 00000041AE38: 06020280
	ds_load_2addr_stride64_b32 v[5:6], v8 offset0:8 offset1:10 // 00000041AE3C: D8E00A08 05000008
	v_add_f32_e32 v1, v1, v2                                   // 00000041AE44: 06020501
	s_waitcnt lgkmcnt(1)                                       // 00000041AE48: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000041AE4C: BF8700C1
	v_add_f32_e32 v3, v1, v3                                   // 00000041AE50: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v8 offset0:12 offset1:14// 00000041AE54: D8E00E0C 01000008
	v_add_f32_e32 v3, v3, v4                                   // 00000041AE5C: 06060903
	s_waitcnt lgkmcnt(1)                                       // 00000041AE60: BF89FC17
	v_add_f32_e32 v3, v3, v5                                   // 00000041AE64: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041AE68: BF8700A1
	v_add_f32_e32 v3, v3, v6                                   // 00000041AE6C: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 00000041AE70: BF89FC07
	v_add_f32_e32 v1, v3, v1                                   // 00000041AE74: 06020303
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041AE78: BF870001
	v_add_f32_e32 v1, v1, v2                                   // 00000041AE7C: 06020501
	ds_store_b32 v8, v1 offset:4096                            // 00000041AE80: D8341000 00000108
	s_or_b32 exec_lo, exec_lo, s4                              // 00000041AE88: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 00000041AE8C: BF048215
	s_mov_b32 s4, -1                                           // 00000041AE90: BE8400C1
	s_cbranch_scc1 65503                                       // 00000041AE94: BFA2FFDF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1c14>
	s_load_b128 s[4:7], s[0:1], 0x1a8                          // 00000041AE98: F4080100 F80001A8
	s_lshl_b64 s[8:9], s[30:31], 2                             // 00000041AEA0: 8488821E
	s_waitcnt lgkmcnt(0)                                       // 00000041AEA4: BF89FC07
	s_barrier                                                  // 00000041AEA8: BFBD0000
	buffer_gl0_inv                                             // 00000041AEAC: E0AC0000 00000000
	s_add_u32 s1, s4, s8                                       // 00000041AEB4: 80010804
	s_addc_u32 s4, s5, s9                                      // 00000041AEB8: 82040905
	s_and_saveexec_b32 s0, s3                                  // 00000041AEBC: BE802003
	s_cbranch_execz 17                                         // 00000041AEC0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1d08>
	v_lshlrev_b32_e32 v1, 2, v0                                // 00000041AEC4: 30020082
	s_mul_hi_i32 s9, s23, s20                                  // 00000041AEC8: 97091417
	s_mul_i32 s8, s23, s20                                     // 00000041AECC: 96081417
	s_lshl_b32 s10, s26, 7                                     // 00000041AED0: 840A871A
	s_lshl_b64 s[8:9], s[8:9], 2                               // 00000041AED4: 84888208
	ds_load_b32 v2, v1 offset:4096                             // 00000041AED8: D8D81000 02000001
	s_ashr_i32 s11, s10, 31                                    // 00000041AEE0: 860B9F0A
	s_add_u32 s5, s1, s8                                       // 00000041AEE4: 80050801
	s_addc_u32 s16, s4, s9                                     // 00000041AEE8: 82100904
	s_lshl_b64 s[8:9], s[10:11], 2                             // 00000041AEEC: 8488820A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000041AEF0: BF870009
	s_add_u32 s8, s5, s8                                       // 00000041AEF4: 80080805
	s_addc_u32 s9, s16, s9                                     // 00000041AEF8: 82090910
	s_waitcnt lgkmcnt(0)                                       // 00000041AEFC: BF89FC07
	global_store_b32 v1, v2, s[8:9]                            // 00000041AF00: DC6A0000 00080201
	s_or_b32 exec_lo, exec_lo, s0                              // 00000041AF08: 8C7E007E
	s_ashr_i32 s29, s28, 31                                    // 00000041AF0C: 861D9F1C
	.long 0xd44a0000                                           // 00000041AF10: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000041AF14: 02020080
	s_lshl_b64 s[8:9], s[28:29], 2                             // 00000041AF18: 8488821C
	s_waitcnt_vscnt null, 0x0                                  // 00000041AF1C: BC7C0000
	buffer_gl1_inv                                             // 00000041AF20: E0B00000 00000000
	buffer_gl0_inv                                             // 00000041AF28: E0AC0000 00000000
	s_add_u32 s6, s6, s8                                       // 00000041AF30: 80060806
	s_addc_u32 s7, s7, s9                                      // 00000041AF34: 82070907
	s_barrier                                                  // 00000041AF38: BFBD0000
	buffer_gl0_inv                                             // 00000041AF3C: E0AC0000 00000000
	s_and_saveexec_b32 s5, s0                                  // 00000041AF44: BE852000
	s_cbranch_execz 29                                         // 00000041AF48: BFA5001D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1dc0>
	s_mov_b32 s9, exec_lo                                      // 00000041AF4C: BE89007E
	s_mov_b32 s8, exec_lo                                      // 00000041AF50: BE88007E
	.long 0xd71f0001                                           // 00000041AF54: D71F0001
	v_cndmask_b32_e32 v0, s9, v128, vcc_lo                     // 00000041AF58: 02010009
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041AF5C: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 00000041AF60: 7D940280
	s_cbranch_execz 9                                          // 00000041AF64: BFA50009 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1d8c>
	s_lshl_b64 s[10:11], s[26:27], 2                           // 00000041AF68: 848A821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000041AF6C: BF8704B9
	s_add_u32 s10, s6, s10                                     // 00000041AF70: 800A0A06
	s_addc_u32 s11, s7, s11                                    // 00000041AF74: 820B0B07
	s_bcnt1_i32_b32 s9, s9                                     // 00000041AF78: BE891809
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s9              // 00000041AF7C: CA100080 02020009
	global_atomic_add_u32 v2, v2, v3, s[10:11] glc             // 00000041AF84: DCD64000 020A0302
	s_or_b32 exec_lo, exec_lo, s8                              // 00000041AF8C: 8C7E087E
	s_waitcnt vmcnt(0)                                         // 00000041AF90: BF8903F7
	v_readfirstlane_b32 s8, v2                                 // 00000041AF94: 7E100502
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041AF98: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s8, v1       // 00000041AF9C: CA200080 02000208
	s_add_i32 s8, s21, -1                                      // 00000041AFA4: 8108C115
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000041AFA8: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s8, v1                            // 00000041AFAC: 7C940208
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 00000041AFB0: D5010001 01A90280
	ds_store_b32 v2, v1 offset:5120                            // 00000041AFB8: D8341400 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 00000041AFC0: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 00000041AFC4: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 00000041AFC8: BF89FC07
	s_barrier                                                  // 00000041AFCC: BFBD0000
	buffer_gl0_inv                                             // 00000041AFD0: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:5120                             // 00000041AFD8: D8D81400 01000001
	s_waitcnt lgkmcnt(0)                                       // 00000041AFE0: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000041AFE4: 7C940280
	s_cbranch_vccnz 48                                         // 00000041AFE8: BFA40030 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1eac>
	buffer_gl1_inv                                             // 00000041AFEC: E0B00000 00000000
	buffer_gl0_inv                                             // 00000041AFF4: E0AC0000 00000000
	s_and_saveexec_b32 s8, s3                                  // 00000041AFFC: BE882003
	s_cbranch_execz 30                                         // 00000041B000: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1e7c>
	s_lshl_b32 s10, s26, 7                                     // 00000041B004: 840A871A
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 00000041B008: CA220080 04020082
	s_ashr_i32 s11, s10, 31                                    // 00000041B010: 860B9F0A
	s_ashr_i32 s5, s20, 31                                     // 00000041B014: 86059F14
	s_lshl_b64 s[10:11], s[10:11], 2                           // 00000041B018: 848A820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000041B01C: BF8700B9
	s_add_u32 s1, s1, s10                                      // 00000041B020: 80010A01
	s_addc_u32 s3, s4, s11                                     // 00000041B024: 82030B04
	.long 0xd7000101                                           // 00000041B028: D7000101
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 00000041B02C: 02020601
	v_add_co_ci_u32_e64 v2, null, s3, 0, s1                    // 00000041B030: D5207C02 00050003
	s_mov_b32 s4, s20                                          // 00000041B038: BE840014
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000041B03C: BF870009
	s_lshl_b64 s[4:5], s[4:5], 2                               // 00000041B040: 84848204
	global_load_b32 v5, v[1:2], off glc                        // 00000041B044: DC524000 057C0001
	.long 0xd7006a01                                           // 00000041B04C: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000041B050: 02000901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000041B054: BF8704A1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000041B058: D5207C02 01AA0405
	s_add_i32 s21, s21, -1                                     // 00000041B060: 8115C115
	s_cmp_eq_u32 s21, 0                                        // 00000041B064: BF068015
	s_waitcnt vmcnt(0)                                         // 00000041B068: BF8903F7
	v_add_f32_e32 v4, v4, v5                                   // 00000041B06C: 06080B04
	s_cbranch_scc0 65524                                       // 00000041B070: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1e44>
	ds_store_b32 v3, v4 offset:4096                            // 00000041B074: D8341000 00000403
	s_or_b32 exec_lo, exec_lo, s8                              // 00000041B07C: 8C7E087E
	s_and_saveexec_b32 s1, s0                                  // 00000041B080: BE812000
	s_cbranch_execz 6                                          // 00000041B084: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1ea0>
	s_lshl_b64 s[4:5], s[26:27], 2                             // 00000041B088: 8484821A
	v_mov_b32_e32 v1, 0                                        // 00000041B08C: 7E020280
	s_add_u32 s4, s6, s4                                       // 00000041B090: 80040406
	s_addc_u32 s5, s7, s5                                      // 00000041B094: 82050507
	global_store_b32 v1, v1, s[4:5]                            // 00000041B098: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 00000041B0A0: 8C7E017E
	s_cbranch_execz 63825                                      // 00000041B0A4: BFA5F951 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 1                                                 // 00000041B0A8: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1eb0>
	s_branch 63823                                             // 00000041B0AC: BFA0F94F <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_cmp_eq_u32_e32 vcc_lo, 0, v7                             // 00000041B0B0: 7C940E80
	s_cmp_gt_i32 s18, 0                                        // 00000041B0B4: BF028012
	s_waitcnt lgkmcnt(0)                                       // 00000041B0B8: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000041B0BC: BC7C0000
	s_cselect_b32 s0, -1, 0                                    // 00000041B0C0: 980080C1
	s_barrier                                                  // 00000041B0C4: BFBD0000
	s_and_b32 s0, vcc_lo, s0                                   // 00000041B0C8: 8B00006A
	buffer_gl0_inv                                             // 00000041B0CC: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000041B0D4: BE812000
	s_cbranch_execz 63812                                      // 00000041B0D8: BFA5F944 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_and_b32_e32 v1, 15, v0                                   // 00000041B0DC: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B0E0: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 00000041B0E4: 30040282
	v_add_nc_u32_e32 v8, 0x1000, v2                            // 00000041B0E8: 4A1004FF 00001000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000041B0F0: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 00000041B0F8: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000041B100: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 00000041B108: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 00000041B110: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000041B114: 36160082
	s_waitcnt lgkmcnt(3)                                       // 00000041B118: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 00000041B11C: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 00000041B124: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 00000041B128: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000041B130: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000041B134: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 00000041B13C: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 00000041B140: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 00000041B148: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 00000041B150: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000041B154: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 00000041B158: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 00000041B160: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000041B168: 7C941480
	.long 0xd44a0000                                           // 00000041B16C: D44A0000
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 00000041B170: 02021680
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 00000041B174: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 00000041B17C: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 00000041B180: 08101D09
	.long 0xd44a0001                                           // 00000041B184: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 00000041B188: 02021880
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041B18C: BF870004
	v_add_f32_e32 v9, v13, v4                                  // 00000041B190: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 00000041B194: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000041B19C: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 00000041B1A0: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 00000041B1A4: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041B1A8: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000041B1B0: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041B1B8: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000041B1C0: D5010009 21AA1309
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041B1C8: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000041B1D0: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041B1D8: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000041B1E0: D5010008 21AA1108
	v_add_f32_e32 v6, v7, v6                                   // 00000041B1E8: 060C0D07
	v_add_f32_e32 v7, v9, v10                                  // 00000041B1EC: 060E1509
	v_add_f32_e32 v5, v5, v15                                  // 00000041B1F0: 060A1F05
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041B1F4: 7E1C02FA FF01610D
	v_add_f32_e32 v8, v8, v16                                  // 00000041B1FC: 06102108
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041B200: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 00000041B208: D5010006 20020D06
	v_mov_b32_dpp v11, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041B210: 7E1602FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 00000041B218: D5010007 20020F07
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000041B220: D501000D 21AA1B0D
	v_mov_b32_dpp v22, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041B228: 7E2C02FA FF016104
	v_add_f32_e32 v6, v6, v10                                  // 00000041B230: 060C1506
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000041B234: D5010004 21AA0904
	v_add_f32_e32 v7, v7, v11                                  // 00000041B23C: 060E1707
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000041B240: BF8701A3
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041B244: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000041B24C: D5010006 20060D06
	v_mov_b32_dpp v11, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041B254: 7E1602FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 00000041B25C: D5010007 20060F07
	v_add_f32_e32 v9, v13, v14                                 // 00000041B264: 06121D0D
	v_add_f32_e32 v4, v4, v22                                  // 00000041B268: 06082D04
	v_add_f32_e32 v20, v6, v10                                 // 00000041B26C: 06281506
	v_cndmask_b32_e64 v6, -v8, v8, s0                          // 00000041B270: D5010006 20021108
	v_add_f32_e32 v10, v7, v11                                 // 00000041B278: 06141707
	v_mov_b32_dpp v13, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041B27C: 7E1A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 00000041B284: D5010009 20021309
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041B28C: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 00000041B294: D5010005 20020B05
	v_mov_b32_dpp v19, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041B29C: 7E2602FA FF01680A
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041B2A4: BF870004
	v_add_f32_e32 v9, v9, v13                                  // 00000041B2A8: 06121B09
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041B2AC: 7E1A02FA FF016208
	v_mov_b32_dpp v8, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041B2B4: 7E1002FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000041B2BC: D5010003 21AA0703
	v_add_f32_e32 v5, v5, v14                                  // 00000041B2C4: 060A1D05
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041B2C8: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 00000041B2D0: D5010009 20061309
	v_add_f32_e32 v6, v6, v13                                  // 00000041B2D8: 060C1B06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000041B2DC: BF870224
	v_mov_b32_dpp v7, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041B2E0: 7E0E02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 00000041B2E8: D5010005 20060B05
	v_add_f32_e32 v17, v9, v12                                 // 00000041B2F0: 06221909
	v_mov_b32_dpp v9, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041B2F4: 7E1202FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000041B2FC: D5010002 21AA0502
	v_add_f32_e32 v3, v3, v8                                   // 00000041B304: 06061103
	v_mov_b32_dpp v8, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041B308: 7E1002FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 00000041B310: D5010004 20020904
	v_mov_b32_dpp v21, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041B318: 7E2A02FA FF016814
	v_add_f32_e32 v2, v2, v9                                   // 00000041B320: 06041302
	v_mov_b32_dpp v9, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041B324: 7E1202FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 00000041B32C: D5010003 20020703
	v_add_f32_e32 v4, v4, v8                                   // 00000041B334: 06081104
	v_mov_b32_dpp v8, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041B338: 7E1002FA FF016406
	v_mov_b32_dpp v11, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041B340: 7E1602FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 00000041B348: D5010002 20020502
	v_add_f32_e32 v3, v3, v9                                   // 00000041B350: 06061303
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041B354: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 00000041B35C: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000041B364: D5010006 20060D06
	v_add_f32_e32 v2, v2, v11                                  // 00000041B36C: 06041702
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041B370: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000041B378: D5010003 20060703
	v_add_f32_e32 v11, v4, v9                                  // 00000041B380: 06161304
	v_add_f32_e32 v15, v5, v7                                  // 00000041B384: 061E0F05
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041B388: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 00000041B390: D5010002 20060502
	v_add_f32_e32 v13, v6, v8                                  // 00000041B398: 061A1106
	v_add_f32_e32 v8, v3, v12                                  // 00000041B39C: 06101903
	v_mov_b32_dpp v18, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041B3A0: 7E2402FA FF016811
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041B3A8: 7E2002FA FF01680F
	v_add_f32_e32 v6, v2, v14                                  // 00000041B3B0: 060C1D02
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041B3B4: 7E1C02FA FF01680D
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041B3BC: 7E1802FA FF01680B
	v_mov_b32_dpp v9, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041B3C4: 7E1202FA FF016808
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041B3CC: BF870004
	v_mov_b32_dpp v7, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041B3D0: 7E0E02FA FF016806
	s_and_b32 exec_lo, exec_lo, s2                             // 00000041B3D8: 8B7E027E
	s_cbranch_execz 63619                                      // 00000041B3DC: BFA5F883 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_lshl_or_b32 v3, s26, 7, v1                               // 00000041B3E0: D6560003 04050E1A
	v_and_b32_e32 v0, 8, v0                                    // 00000041B3E8: 36000088
	s_cmp_lg_u64 s[24:25], 0                                   // 00000041B3EC: BF118018
	s_mov_b32 s2, 0                                            // 00000041B3F0: BE820080
	s_cselect_b32 s1, -1, 0                                    // 00000041B3F4: 980180C1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000041B3F8: 3408069F
	.long 0xd44a0000                                           // 00000041B3FC: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000041B400: 02020080
	s_cmp_eq_u64 s[24:25], 0                                   // 00000041B404: BF108018
	.long 0xd73c0001                                           // 00000041B408: D73C0001
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000041B40C: 02020681
	v_cndmask_b32_e64 v0, -v20, v20, s0                        // 00000041B410: D5010000 20022914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041B418: BF870191
	v_add_f32_e32 v0, v0, v21                                  // 00000041B41C: 06002B00
	.long 0xd7006a04                                           // 00000041B420: D7006A04
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 00000041B424: 0202020C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041B428: BF870191
	v_add_co_ci_u32_e64 v5, null, s13, v2, vcc_lo              // 00000041B42C: D5207C05 01AA040D
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 00000041B434: 100000FF 3DB504F3
	global_load_d16_b16 v22, v[4:5], off                       // 00000041B43C: DC820000 167C0004
	s_waitcnt vmcnt(0)                                         // 00000041B444: BF8903F7
	v_fma_mix_f32 v20, v22, v0, neg(0) op_sel_hi:[1,0,0]       // 00000041B448: CC200014 8A020116
	v_ashrrev_i32_e32 v0, 31, v3                               // 00000041B450: 3400069F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B454: BF870092
	v_bfe_u32 v21, v20, 16, 1                                  // 00000041B458: D6100015 02052114
	v_add3_u32 v20, v20, v21, 0x7fff                           // 00000041B460: D6550014 03FE2B14 00007FFF
	s_cbranch_scc1 537                                         // 00000041B46C: BFA20219 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ad4>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000041B470: BF870123
	v_lshrrev_b32_e32 v21, 23, v0                              // 00000041B474: 322A0097
	v_dual_mov_b32 v26, s14 :: v_dual_mov_b32 v23, s15         // 00000041B478: CA10000E 1A16000F
	v_add_nc_u32_e32 v21, v3, v21                              // 00000041B480: 4A2A2B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000041B484: BF870121
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 00000041B488: 362C2AFF FFFFFE00
	v_ashrrev_i32_e32 v21, 9, v21                              // 00000041B490: 342A2A89
	v_sub_nc_u32_e32 v22, v3, v22                              // 00000041B494: 4C2C2D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000041B498: BF870221
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 00000041B49C: 7C882CFF 00000100
	v_add_nc_u32_e32 v24, 0xffffff00, v22                      // 00000041B4A4: 4A302CFF FFFFFF00
	v_dual_cndmask_b32 v26, s24, v26 :: v_dual_lshlrev_b32 v21, 8, v21// 00000041B4AC: CA623418 1A142A88
	v_cndmask_b32_e32 v25, s25, v23, vcc_lo                    // 00000041B4B4: 02322E19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041B4B8: BF870193
	v_cndmask_b32_e32 v23, v24, v22, vcc_lo                    // 00000041B4BC: 022E2D18
	v_ashrrev_i32_e32 v22, 31, v21                             // 00000041B4C0: 342C2A9F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041B4C4: BF870112
	v_ashrrev_i32_e32 v24, 31, v23                             // 00000041B4C8: 34302E9F
	.long 0xd73c0015                                           // 00000041B4CC: D73C0015
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 00000041B4D0: 02022A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041B4D4: BF870112
	.long 0xd73c0017                                           // 00000041B4D8: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 00000041B4DC: 02022E81
	.long 0xd7006a15                                           // 00000041B4E0: D7006A15
	v_cndmask_b32_e32 v1, v26, v21, vcc_lo                     // 00000041B4E4: 02022B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041B4E8: BF870111
	v_add_co_ci_u32_e64 v22, null, v25, v22, vcc_lo            // 00000041B4EC: D5207C16 01AA2D19
	.long 0xd7006a15                                           // 00000041B4F4: D7006A15
	v_cndmask_b32_e32 v1, v21, v23, vcc_lo                     // 00000041B4F8: 02022F15
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041B4FC: BF870001
	v_add_co_ci_u32_e64 v22, null, v22, v24, vcc_lo            // 00000041B500: D5207C16 01AA3116
	global_store_d16_hi_b16 v[21:22], v20, off                 // 00000041B508: DC960000 007C1415
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 00000041B510: 916A027E
	s_cbranch_vccnz 7                                          // 00000041B514: BFA40007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2334>
	.long 0xd7006a15                                           // 00000041B518: D7006A15
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000041B51C: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041B520: BF870001
	v_add_co_ci_u32_e64 v22, null, s15, v2, vcc_lo             // 00000041B524: D5207C16 01AA040F
	global_store_d16_hi_b16 v[21:22], v20, off                 // 00000041B52C: DC960000 007C1415
	global_load_d16_b16 v20, v[4:5], off offset:32             // 00000041B534: DC820020 147C0004
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 00000041B53C: D501000A 2002150A
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000041B544: 916A017E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B548: BF870091
	v_add_f32_e32 v10, v10, v19                                // 00000041B54C: 0614270A
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 00000041B550: 101414FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000041B558: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000041B55C: BF870121
	v_fma_mix_f32 v19, v20, v10, neg(0) op_sel_hi:[1,0,0]      // 00000041B560: CC200013 8A021514
	v_cndmask_b32_e64 v10, 0, 1, s1                            // 00000041B568: D501000A 00050280
	v_bfe_u32 v20, v19, 16, 1                                  // 00000041B570: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041B578: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000041B57C: D6550013 03FE2913 00007FFF
	s_cbranch_vccnz 467                                        // 00000041B588: BFA401D3 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ad8>
	v_or_b32_e32 v20, 16, v3                                   // 00000041B58C: 38280690
	v_lshrrev_b32_e32 v21, 23, v0                              // 00000041B590: 322A0097
	v_mov_b32_e32 v25, s14                                     // 00000041B594: 7E32020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B598: BF870092
	v_add_nc_u32_e32 v21, v20, v21                             // 00000041B59C: 4A2A2B14
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 00000041B5A0: 362C2AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B5A8: BF870091
	v_sub_nc_u32_e32 v22, v20, v22                             // 00000041B5AC: 4C2C2D14
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 00000041B5B0: 7C882CFF 00000100
	v_add_nc_u32_e32 v23, 0xffffff00, v22                      // 00000041B5B8: 4A2E2CFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000041B5C0: BF8701B1
	v_dual_cndmask_b32 v25, s24, v25 :: v_dual_cndmask_b32 v22, v23, v22// 00000041B5C4: CA523218 19162D17
	v_ashrrev_i32_e32 v20, 9, v21                              // 00000041B5CC: 34282A89
	v_mov_b32_e32 v21, s15                                     // 00000041B5D0: 7E2A020F
	v_ashrrev_i32_e32 v23, 31, v22                             // 00000041B5D4: 342E2C9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041B5D8: BF870193
	v_lshlrev_b32_e32 v20, 8, v20                              // 00000041B5DC: 30282888
	v_cndmask_b32_e32 v24, s25, v21, vcc_lo                    // 00000041B5E0: 02302A19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041B5E4: BF870193
	.long 0xd73c0016                                           // 00000041B5E8: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 00000041B5EC: 02022C81
	v_ashrrev_i32_e32 v21, 31, v20                             // 00000041B5F0: 342A289F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B5F4: BF870091
	.long 0xd73c0014                                           // 00000041B5F8: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 00000041B5FC: 02022881
	.long 0xd7006a14                                           // 00000041B600: D7006A14
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 00000041B604: 02022919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041B608: BF870111
	v_add_co_ci_u32_e64 v21, null, v24, v21, vcc_lo            // 00000041B60C: D5207C15 01AA2B18
	.long 0xd7006a14                                           // 00000041B614: D7006A14
	v_cndmask_b32_e32 v1, v20, v22, vcc_lo                     // 00000041B618: 02022D14
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041B61C: BF870001
	v_add_co_ci_u32_e64 v21, null, v21, v23, vcc_lo            // 00000041B620: D5207C15 01AA2F15
	global_store_d16_hi_b16 v[20:21], v19, off                 // 00000041B628: DC960000 007C1314
	s_cbranch_execnz 7                                         // 00000041B630: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2450>
	.long 0xd7006a14                                           // 00000041B634: D7006A14
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000041B638: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041B63C: BF870001
	v_add_co_ci_u32_e64 v21, null, s15, v2, vcc_lo             // 00000041B640: D5207C15 01AA040F
	global_store_d16_hi_b16 v[20:21], v19, off offset:32       // 00000041B648: DC960020 007C1314
	global_load_d16_b16 v19, v[4:5], off offset:64             // 00000041B650: DC820040 137C0004
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 00000041B658: D5010011 20022311
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 00000041B660: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041B664: BF8700A2
	v_add_f32_e32 v17, v17, v18                                // 00000041B668: 06222511
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000041B66C: 8B6A6A7E
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 00000041B670: 102222FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000041B678: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B67C: BF870091
	v_fma_mix_f32 v17, v19, v17, neg(0) op_sel_hi:[1,0,0]      // 00000041B680: CC200011 8A022313
	v_bfe_u32 v18, v17, 16, 1                                  // 00000041B688: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041B690: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 00000041B694: D6550011 03FE2511 00007FFF
	s_cbranch_vccnz 398                                        // 00000041B6A0: BFA4018E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2adc>
	v_or_b32_e32 v18, 32, v3                                   // 00000041B6A4: 382406A0
	v_lshrrev_b32_e32 v19, 23, v0                              // 00000041B6A8: 32260097
	v_mov_b32_e32 v23, s14                                     // 00000041B6AC: 7E2E020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B6B0: BF870092
	v_add_nc_u32_e32 v19, v18, v19                             // 00000041B6B4: 4A262712
	v_and_b32_e32 v20, 0xfffffe00, v19                         // 00000041B6B8: 362826FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B6C0: BF870091
	v_sub_nc_u32_e32 v20, v18, v20                             // 00000041B6C4: 4C282912
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v20                        // 00000041B6C8: 7C8828FF 00000100
	v_add_nc_u32_e32 v21, 0xffffff00, v20                      // 00000041B6D0: 4A2A28FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000041B6D8: BF8701B1
	v_dual_cndmask_b32 v23, s24, v23 :: v_dual_cndmask_b32 v20, v21, v20// 00000041B6DC: CA522E18 17142915
	v_ashrrev_i32_e32 v18, 9, v19                              // 00000041B6E4: 34242689
	v_mov_b32_e32 v19, s15                                     // 00000041B6E8: 7E26020F
	v_ashrrev_i32_e32 v21, 31, v20                             // 00000041B6EC: 342A289F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041B6F0: BF870193
	v_lshlrev_b32_e32 v18, 8, v18                              // 00000041B6F4: 30242488
	v_cndmask_b32_e32 v22, s25, v19, vcc_lo                    // 00000041B6F8: 022C2619
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041B6FC: BF870193
	.long 0xd73c0014                                           // 00000041B700: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 00000041B704: 02022881
	v_ashrrev_i32_e32 v19, 31, v18                             // 00000041B708: 3426249F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B70C: BF870091
	.long 0xd73c0012                                           // 00000041B710: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000041B714: 02022481
	.long 0xd7006a12                                           // 00000041B718: D7006A12
	v_cndmask_b32_e32 v1, v23, v18, vcc_lo                     // 00000041B71C: 02022517
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041B720: BF870111
	v_add_co_ci_u32_e64 v19, null, v22, v19, vcc_lo            // 00000041B724: D5207C13 01AA2716
	.long 0xd7006a12                                           // 00000041B72C: D7006A12
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 00000041B730: 02022912
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041B734: BF870001
	v_add_co_ci_u32_e64 v19, null, v19, v21, vcc_lo            // 00000041B738: D5207C13 01AA2B13
	global_store_d16_hi_b16 v[18:19], v17, off                 // 00000041B740: DC960000 007C1112
	s_cbranch_execnz 7                                         // 00000041B748: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2568>
	.long 0xd7006a12                                           // 00000041B74C: D7006A12
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000041B750: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041B754: BF870001
	v_add_co_ci_u32_e64 v19, null, s15, v2, vcc_lo             // 00000041B758: D5207C13 01AA040F
	global_store_d16_hi_b16 v[18:19], v17, off offset:64       // 00000041B760: DC960040 007C1112
	global_load_d16_b16 v17, v[4:5], off offset:96             // 00000041B768: DC820060 117C0004
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 00000041B770: D501000F 20021F0F
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 00000041B778: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041B77C: BF8700A2
	v_add_f32_e32 v15, v15, v16                                // 00000041B780: 061E210F
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000041B784: 8B6A6A7E
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 00000041B788: 101E1EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000041B790: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B794: BF870091
	v_fma_mix_f32 v15, v17, v15, neg(0) op_sel_hi:[1,0,0]      // 00000041B798: CC20000F 8A021F11
	v_bfe_u32 v16, v15, 16, 1                                  // 00000041B7A0: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041B7A8: BF870001
	v_add3_u32 v15, v15, v16, 0x7fff                           // 00000041B7AC: D655000F 03FE210F 00007FFF
	s_cbranch_vccnz 329                                        // 00000041B7B8: BFA40149 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ae0>
	v_or_b32_e32 v16, 48, v3                                   // 00000041B7BC: 382006B0
	v_lshrrev_b32_e32 v17, 23, v0                              // 00000041B7C0: 32220097
	v_mov_b32_e32 v21, s14                                     // 00000041B7C4: 7E2A020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B7C8: BF870092
	v_add_nc_u32_e32 v17, v16, v17                             // 00000041B7CC: 4A222310
	v_and_b32_e32 v18, 0xfffffe00, v17                         // 00000041B7D0: 362422FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B7D8: BF870091
	v_sub_nc_u32_e32 v18, v16, v18                             // 00000041B7DC: 4C242510
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v18                        // 00000041B7E0: 7C8824FF 00000100
	v_add_nc_u32_e32 v19, 0xffffff00, v18                      // 00000041B7E8: 4A2624FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000041B7F0: BF8701B1
	v_dual_cndmask_b32 v21, s24, v21 :: v_dual_cndmask_b32 v18, v19, v18// 00000041B7F4: CA522A18 15122513
	v_ashrrev_i32_e32 v16, 9, v17                              // 00000041B7FC: 34202289
	v_mov_b32_e32 v17, s15                                     // 00000041B800: 7E22020F
	v_ashrrev_i32_e32 v19, 31, v18                             // 00000041B804: 3426249F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041B808: BF870193
	v_lshlrev_b32_e32 v16, 8, v16                              // 00000041B80C: 30202088
	v_cndmask_b32_e32 v20, s25, v17, vcc_lo                    // 00000041B810: 02282219
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041B814: BF870193
	.long 0xd73c0012                                           // 00000041B818: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000041B81C: 02022481
	v_ashrrev_i32_e32 v17, 31, v16                             // 00000041B820: 3422209F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B824: BF870091
	.long 0xd73c0010                                           // 00000041B828: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 00000041B82C: 02022081
	.long 0xd7006a10                                           // 00000041B830: D7006A10
	v_cndmask_b32_e32 v1, v21, v16, vcc_lo                     // 00000041B834: 02022115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041B838: BF870111
	v_add_co_ci_u32_e64 v17, null, v20, v17, vcc_lo            // 00000041B83C: D5207C11 01AA2314
	.long 0xd7006a10                                           // 00000041B844: D7006A10
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 00000041B848: 02022510
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041B84C: BF870001
	v_add_co_ci_u32_e64 v17, null, v17, v19, vcc_lo            // 00000041B850: D5207C11 01AA2711
	global_store_d16_hi_b16 v[16:17], v15, off                 // 00000041B858: DC960000 007C0F10
	s_cbranch_execnz 7                                         // 00000041B860: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2680>
	.long 0xd7006a10                                           // 00000041B864: D7006A10
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000041B868: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041B86C: BF870001
	v_add_co_ci_u32_e64 v17, null, s15, v2, vcc_lo             // 00000041B870: D5207C11 01AA040F
	global_store_d16_hi_b16 v[16:17], v15, off offset:96       // 00000041B878: DC960060 007C0F10
	global_load_d16_b16 v15, v[4:5], off offset:128            // 00000041B880: DC820080 0F7C0004
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 00000041B888: D501000D 20021B0D
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 00000041B890: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041B894: BF8700A2
	v_add_f32_e32 v13, v13, v14                                // 00000041B898: 061A1D0D
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000041B89C: 8B6A6A7E
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 00000041B8A0: 101A1AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000041B8A8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B8AC: BF870091
	v_fma_mix_f32 v13, v15, v13, neg(0) op_sel_hi:[1,0,0]      // 00000041B8B0: CC20000D 8A021B0F
	v_bfe_u32 v14, v13, 16, 1                                  // 00000041B8B8: D610000E 0205210D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041B8C0: BF870001
	v_add3_u32 v13, v13, v14, 0x7fff                           // 00000041B8C4: D655000D 03FE1D0D 00007FFF
	s_cbranch_vccnz 260                                        // 00000041B8D0: BFA40104 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ae4>
	v_or_b32_e32 v14, 64, v3                                   // 00000041B8D4: 381C06C0
	v_lshrrev_b32_e32 v15, 23, v0                              // 00000041B8D8: 321E0097
	v_mov_b32_e32 v19, s14                                     // 00000041B8DC: 7E26020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B8E0: BF870092
	v_add_nc_u32_e32 v15, v14, v15                             // 00000041B8E4: 4A1E1F0E
	v_and_b32_e32 v16, 0xfffffe00, v15                         // 00000041B8E8: 36201EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B8F0: BF870091
	v_sub_nc_u32_e32 v16, v14, v16                             // 00000041B8F4: 4C20210E
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v16                        // 00000041B8F8: 7C8820FF 00000100
	v_add_nc_u32_e32 v17, 0xffffff00, v16                      // 00000041B900: 4A2220FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000041B908: BF8701B1
	v_dual_cndmask_b32 v19, s24, v19 :: v_dual_cndmask_b32 v16, v17, v16// 00000041B90C: CA522618 13102111
	v_ashrrev_i32_e32 v14, 9, v15                              // 00000041B914: 341C1E89
	v_mov_b32_e32 v15, s15                                     // 00000041B918: 7E1E020F
	v_ashrrev_i32_e32 v17, 31, v16                             // 00000041B91C: 3422209F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041B920: BF870193
	v_lshlrev_b32_e32 v14, 8, v14                              // 00000041B924: 301C1C88
	v_cndmask_b32_e32 v18, s25, v15, vcc_lo                    // 00000041B928: 02241E19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041B92C: BF870193
	.long 0xd73c0010                                           // 00000041B930: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 00000041B934: 02022081
	v_ashrrev_i32_e32 v15, 31, v14                             // 00000041B938: 341E1C9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B93C: BF870091
	.long 0xd73c000e                                           // 00000041B940: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 00000041B944: 02021C81
	.long 0xd7006a0e                                           // 00000041B948: D7006A0E
	v_cndmask_b32_e32 v1, v19, v14, vcc_lo                     // 00000041B94C: 02021D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041B950: BF870111
	v_add_co_ci_u32_e64 v15, null, v18, v15, vcc_lo            // 00000041B954: D5207C0F 01AA1F12
	.long 0xd7006a0e                                           // 00000041B95C: D7006A0E
	v_cndmask_b32_e32 v1, v14, v16, vcc_lo                     // 00000041B960: 0202210E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041B964: BF870001
	v_add_co_ci_u32_e64 v15, null, v15, v17, vcc_lo            // 00000041B968: D5207C0F 01AA230F
	global_store_d16_hi_b16 v[14:15], v13, off                 // 00000041B970: DC960000 007C0D0E
	s_cbranch_execnz 7                                         // 00000041B978: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2798>
	.long 0xd7006a0e                                           // 00000041B97C: D7006A0E
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000041B980: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041B984: BF870001
	v_add_co_ci_u32_e64 v15, null, s15, v2, vcc_lo             // 00000041B988: D5207C0F 01AA040F
	global_store_d16_hi_b16 v[14:15], v13, off offset:128      // 00000041B990: DC960080 007C0D0E
	global_load_d16_b16 v13, v[4:5], off offset:160            // 00000041B998: DC8200A0 0D7C0004
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 00000041B9A0: D501000B 2002170B
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 00000041B9A8: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041B9AC: BF8700A2
	v_add_f32_e32 v11, v11, v12                                // 00000041B9B0: 0616190B
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000041B9B4: 8B6A6A7E
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 00000041B9B8: 101616FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000041B9C0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B9C4: BF870091
	v_fma_mix_f32 v11, v13, v11, neg(0) op_sel_hi:[1,0,0]      // 00000041B9C8: CC20000B 8A02170D
	v_bfe_u32 v12, v11, 16, 1                                  // 00000041B9D0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041B9D8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000041B9DC: D655000B 03FE190B 00007FFF
	s_cbranch_vccnz 191                                        // 00000041B9E8: BFA400BF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ae8>
	v_or_b32_e32 v12, 0x50, v3                                 // 00000041B9EC: 381806FF 00000050
	v_lshrrev_b32_e32 v13, 23, v0                              // 00000041B9F4: 321A0097
	v_mov_b32_e32 v17, s14                                     // 00000041B9F8: 7E22020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041B9FC: BF870092
	v_add_nc_u32_e32 v13, v12, v13                             // 00000041BA00: 4A1A1B0C
	v_and_b32_e32 v14, 0xfffffe00, v13                         // 00000041BA04: 361C1AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041BA0C: BF870091
	v_sub_nc_u32_e32 v14, v12, v14                             // 00000041BA10: 4C1C1D0C
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v14                        // 00000041BA14: 7C881CFF 00000100
	v_add_nc_u32_e32 v15, 0xffffff00, v14                      // 00000041BA1C: 4A1E1CFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000041BA24: BF8701B1
	v_dual_cndmask_b32 v17, s24, v17 :: v_dual_cndmask_b32 v14, v15, v14// 00000041BA28: CA522218 110E1D0F
	v_ashrrev_i32_e32 v12, 9, v13                              // 00000041BA30: 34181A89
	v_mov_b32_e32 v13, s15                                     // 00000041BA34: 7E1A020F
	v_ashrrev_i32_e32 v15, 31, v14                             // 00000041BA38: 341E1C9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041BA3C: BF870193
	v_lshlrev_b32_e32 v12, 8, v12                              // 00000041BA40: 30181888
	v_cndmask_b32_e32 v16, s25, v13, vcc_lo                    // 00000041BA44: 02201A19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041BA48: BF870193
	.long 0xd73c000e                                           // 00000041BA4C: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 00000041BA50: 02021C81
	v_ashrrev_i32_e32 v13, 31, v12                             // 00000041BA54: 341A189F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041BA58: BF870091
	.long 0xd73c000c                                           // 00000041BA5C: D73C000C
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000041BA60: 02021881
	.long 0xd7006a0c                                           // 00000041BA64: D7006A0C
	v_cndmask_b32_e32 v1, v17, v12, vcc_lo                     // 00000041BA68: 02021911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041BA6C: BF870111
	v_add_co_ci_u32_e64 v13, null, v16, v13, vcc_lo            // 00000041BA70: D5207C0D 01AA1B10
	.long 0xd7006a0c                                           // 00000041BA78: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 00000041BA7C: 02021D0C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041BA80: BF870001
	v_add_co_ci_u32_e64 v13, null, v13, v15, vcc_lo            // 00000041BA84: D5207C0D 01AA1F0D
	global_store_d16_hi_b16 v[12:13], v11, off                 // 00000041BA8C: DC960000 007C0B0C
	s_cbranch_execnz 7                                         // 00000041BA94: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x28b4>
	.long 0xd7006a0c                                           // 00000041BA98: D7006A0C
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000041BA9C: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041BAA0: BF870001
	v_add_co_ci_u32_e64 v13, null, s15, v2, vcc_lo             // 00000041BAA4: D5207C0D 01AA040F
	global_store_d16_hi_b16 v[12:13], v11, off offset:160      // 00000041BAAC: DC9600A0 007C0B0C
	global_load_d16_b16 v11, v[4:5], off offset:192            // 00000041BAB4: DC8200C0 0B7C0004
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 00000041BABC: D5010008 20021108
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 00000041BAC4: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041BAC8: BF8700A2
	v_add_f32_e32 v8, v8, v9                                   // 00000041BACC: 06101308
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000041BAD0: 8B6A6A7E
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 00000041BAD4: 101010FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000041BADC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041BAE0: BF870091
	v_fma_mix_f32 v8, v11, v8, neg(0) op_sel_hi:[1,0,0]        // 00000041BAE4: CC200008 8A02110B
	v_bfe_u32 v9, v8, 16, 1                                    // 00000041BAEC: D6100009 02052108
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041BAF4: BF870001
	v_add3_u32 v8, v8, v9, 0x7fff                              // 00000041BAF8: D6550008 03FE1308 00007FFF
	s_cbranch_vccnz 121                                        // 00000041BB04: BFA40079 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2aec>
	v_or_b32_e32 v9, 0x60, v3                                  // 00000041BB08: 381206FF 00000060
	v_lshrrev_b32_e32 v11, 23, v0                              // 00000041BB10: 32160097
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041BB14: BF870091
	v_add_nc_u32_e32 v11, v9, v11                              // 00000041BB18: 4A161709
	v_and_b32_e32 v12, 0xfffffe00, v11                         // 00000041BB1C: 361816FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000041BB24: BF8701B1
	v_sub_nc_u32_e32 v9, v9, v12                               // 00000041BB28: 4C121909
	v_mov_b32_e32 v12, s15                                     // 00000041BB2C: 7E18020F
	v_ashrrev_i32_e32 v11, 9, v11                              // 00000041BB30: 34161689
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v9                         // 00000041BB34: 7C8812FF 00000100
	v_add_nc_u32_e32 v13, 0xffffff00, v9                       // 00000041BB3C: 4A1A12FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000041BB44: BF8701A3
	v_lshlrev_b32_e32 v11, 8, v11                              // 00000041BB48: 30161688
	v_cndmask_b32_e32 v15, s25, v12, vcc_lo                    // 00000041BB4C: 021E1819
	v_cndmask_b32_e32 v13, v13, v9, vcc_lo                     // 00000041BB50: 021A130D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000041BB54: BF8701A3
	v_ashrrev_i32_e32 v12, 31, v11                             // 00000041BB58: 3418169F
	v_mov_b32_e32 v9, s14                                      // 00000041BB5C: 7E12020E
	v_ashrrev_i32_e32 v14, 31, v13                             // 00000041BB60: 341C1A9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041BB64: BF870193
	.long 0xd73c000b                                           // 00000041BB68: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000041BB6C: 02021681
	v_cndmask_b32_e32 v9, s24, v9, vcc_lo                      // 00000041BB70: 02121218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041BB74: BF870113
	.long 0xd73c000d                                           // 00000041BB78: D73C000D
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 00000041BB7C: 02021A81
	.long 0xd7006a09                                           // 00000041BB80: D7006A09
	v_cndmask_b32_e32 v1, v9, v11, vcc_lo                      // 00000041BB84: 02021709
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041BB88: BF870111
	v_add_co_ci_u32_e64 v12, null, v15, v12, vcc_lo            // 00000041BB8C: D5207C0C 01AA190F
	.long 0xd7006a0b                                           // 00000041BB94: D7006A0B
	v_cndmask_b32_e32 v1, v9, v13, vcc_lo                      // 00000041BB98: 02021B09
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041BB9C: BF870001
	v_add_co_ci_u32_e64 v12, null, v12, v14, vcc_lo            // 00000041BBA0: D5207C0C 01AA1D0C
	global_store_d16_hi_b16 v[11:12], v8, off                  // 00000041BBA8: DC960000 007C080B
	s_cbranch_execnz 7                                         // 00000041BBB0: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x29d0>
	.long 0xd7006a0b                                           // 00000041BBB4: D7006A0B
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000041BBB8: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041BBBC: BF870001
	v_add_co_ci_u32_e64 v12, null, s15, v2, vcc_lo             // 00000041BBC0: D5207C0C 01AA040F
	global_store_d16_hi_b16 v[11:12], v8, off offset:192       // 00000041BBC8: DC9600C0 007C080B
	global_load_d16_b16 v4, v[4:5], off offset:224             // 00000041BBD0: DC8200E0 047C0004
	v_cndmask_b32_e64 v5, -v6, v6, s0                          // 00000041BBD8: D5010005 20020D06
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 00000041BBE0: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041BBE4: BF8700A2
	v_add_f32_e32 v5, v5, v7                                   // 00000041BBE8: 060A0F05
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000041BBEC: 8B6A6A7E
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 00000041BBF0: 100A0AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000041BBF8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041BBFC: BF870091
	v_fma_mix_f32 v4, v4, v5, neg(0) op_sel_hi:[1,0,0]         // 00000041BC00: CC200004 8A020B04
	v_bfe_u32 v5, v4, 16, 1                                    // 00000041BC08: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041BC10: BF870001
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000041BC14: D6550004 03FE0B04 00007FFF
	s_cbranch_vccnz 51                                         // 00000041BC20: BFA40033 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2af0>
	v_or_b32_e32 v3, 0x70, v3                                  // 00000041BC24: 380606FF 00000070
	v_lshrrev_b32_e32 v0, 23, v0                               // 00000041BC2C: 32000097
	v_mov_b32_e32 v6, s15                                      // 00000041BC30: 7E0C020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041BC34: BF870092
	v_add_nc_u32_e32 v0, v3, v0                                // 00000041BC38: 4A000103
	v_and_b32_e32 v5, 0xfffffe00, v0                           // 00000041BC3C: 360A00FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041BC44: BF870091
	v_sub_nc_u32_e32 v3, v3, v5                                // 00000041BC48: 4C060B03
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v3                         // 00000041BC4C: 7C8806FF 00000100
	v_add_nc_u32_e32 v7, 0xffffff00, v3                        // 00000041BC54: 4A0E06FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000041BC5C: BF8701B1
	v_cndmask_b32_e32 v7, v7, v3, vcc_lo                       // 00000041BC60: 020E0707
	v_mov_b32_e32 v3, s14                                      // 00000041BC64: 7E06020E
	v_ashrrev_i32_e32 v0, 9, v0                                // 00000041BC68: 34000089
	v_ashrrev_i32_e32 v8, 31, v7                               // 00000041BC6C: 34100E9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041BC70: BF870193
	v_cndmask_b32_e32 v3, s24, v3, vcc_lo                      // 00000041BC74: 02060618
	v_dual_cndmask_b32 v0, s25, v6 :: v_dual_lshlrev_b32 v5, 8, v0// 00000041BC78: CA620C19 00040088
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041BC80: BF870113
	.long 0xd73c0007                                           // 00000041BC84: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000041BC88: 02020E81
	v_ashrrev_i32_e32 v6, 31, v5                               // 00000041BC8C: 340C0A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041BC90: BF870091
	.long 0xd73c0005                                           // 00000041BC94: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000041BC98: 02020A81
	.long 0xd7006a03                                           // 00000041BC9C: D7006A03
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 00000041BCA0: 02020B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041BCA4: BF870111
	v_add_co_ci_u32_e64 v0, null, v0, v6, vcc_lo               // 00000041BCA8: D5207C00 01AA0D00
	.long 0xd7006a05                                           // 00000041BCB0: D7006A05
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 00000041BCB4: 02020F03
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041BCB8: BF870001
	v_add_co_ci_u32_e64 v6, null, v0, v8, vcc_lo               // 00000041BCBC: D5207C06 01AA1100
	global_store_d16_hi_b16 v[5:6], v4, off                    // 00000041BCC4: DC960000 007C0405
	s_cbranch_execnz 63047                                     // 00000041BCCC: BFA6F647 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 7                                                 // 00000041BCD0: BFA00007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2af0>
	s_branch 65040                                             // 00000041BCD4: BFA0FE10 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2318>
	s_branch 65110                                             // 00000041BCD8: BFA0FE56 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2434>
	s_branch 65179                                             // 00000041BCDC: BFA0FE9B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x254c>
	s_branch 65248                                             // 00000041BCE0: BFA0FEE0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2664>
	s_branch 65317                                             // 00000041BCE4: BFA0FF25 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x277c>
	s_branch 65387                                             // 00000041BCE8: BFA0FF6B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2898>
	s_branch 65457                                             // 00000041BCEC: BFA0FFB1 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x29b4>
	.long 0xd7006a00                                           // 00000041BCF0: D7006A00
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000041BCF4: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041BCF8: BF870001
	v_add_co_ci_u32_e64 v1, null, s15, v2, vcc_lo              // 00000041BCFC: D5207C01 01AA040F
	global_store_d16_hi_b16 v[0:1], v4, off offset:224         // 00000041BD04: DC9600E0 007C0400
	s_endpgm                                                   // 00000041BD0C: BFB00000
		...

