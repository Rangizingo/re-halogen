0000000000464a00 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x2                                               // 000000464A00: BF850002
	s_load_b128 s[24:27], s[0:1], 0x10                         // 000000464A04: F4080600 F8000010
	s_load_b256 s[12:19], s[0:1], 0x20                         // 000000464A0C: F40C0300 F8000020
	s_load_b128 s[20:23], s[0:1], 0x40                         // 000000464A14: F4080500 F8000040
	s_mov_b32 s10, s3                                          // 000000464A1C: BE8A0003
	v_lshrrev_b32_e32 v66, 5, v0                               // 000000464A20: 32840085
	v_and_b32_e32 v67, 31, v0                                  // 000000464A24: 3686009F
	s_waitcnt lgkmcnt(0)                                       // 000000464A28: BF89FC07
	s_ashr_i32 s34, s25, 31                                    // 000000464A2C: 86229F19
	s_mul_i32 s11, s27, s10                                    // 000000464A30: 960B0A1B
	s_lshr_b32 s3, s34, 25                                     // 000000464A34: 85039922
	s_add_i32 s4, s11, s27                                     // 000000464A38: 81041B0B
	s_add_i32 s3, s25, s3                                      // 000000464A3C: 81030319
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000464A40: BF870499
	s_ashr_i32 s3, s3, 7                                       // 000000464A44: 86038703
	s_min_i32 s3, s3, s4                                       // 000000464A48: 89030403
	s_mov_b32 s4, exec_lo                                      // 000000464A4C: BE84007E
	s_sub_i32 s3, s3, s11                                      // 000000464A50: 81830B03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000464A54: BF870499
	s_lshl_b32 s9, s3, 3                                       // 000000464A58: 84098303
	.long 0xd4c3007e                                           // 000000464A5C: D4C3007E
	v_cndmask_b32_e32 v1, s9, v66, vcc_lo                      // 000000464A60: 02028409
	s_xor_b32 s4, exec_lo, s4                                  // 000000464A64: 8D04047E
	v_lshlrev_b32_e32 v8, 3, v67                               // 000000464A68: 30108683
	s_or_saveexec_b32 s27, s4                                  // 000000464A6C: BE9B2204
	s_clause 0x1                                               // 000000464A70: BF850001
	s_load_b32 s33, s[0:1], 0x54                               // 000000464A74: F4000840 F8000054
	s_load_b128 s[28:31], s[0:1], null                         // 000000464A7C: F4080700 F8000000
	s_xor_b32 exec_lo, exec_lo, s27                            // 000000464A84: 8D7E1B7E
	s_cbranch_execz 503                                        // 000000464A88: BFA501F7 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x868>
	s_add_i32 s35, s24, -1                                     // 000000464A8C: 8123C118
	s_cmp_lg_u64 s[22:23], 0                                   // 000000464A90: BF118016
	v_dual_mov_b32 v9, v66 :: v_dual_and_b32 v2, 1, v0         // 000000464A94: CA240142 09020081
	s_cselect_b32 s36, -1, 0                                   // 000000464A9C: 982480C1
	s_abs_i32 s37, s3                                          // 000000464AA0: BEA51503
	v_lshlrev_b32_e32 v8, 3, v67                               // 000000464AA4: 30108683
	s_cvt_f32_u32 s0, s37                                      // 000000464AA8: BE806525
	v_lshlrev_b32_e32 v1, 2, v67                               // 000000464AAC: 30028682
	v_and_b32_e32 v4, 2, v0                                    // 000000464AB0: 36080082
	v_and_b32_e32 v5, 4, v0                                    // 000000464AB4: 360A0084
	v_rcp_iflag_f32_e32 v3, s0                                 // 000000464AB8: 7E065600
	v_and_b32_e32 v6, 8, v0                                    // 000000464ABC: 360C0088
	v_add_nc_u32_e32 v7, s11, v66                              // 000000464AC0: 4A0E840B
	.long 0xd44a0001                                           // 000000464AC4: D44A0001
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000464AC8: 02020480
	v_lshl_or_b32 v2, v66, 8, v8                               // 000000464ACC: D6560002 04211142
	s_ashr_i32 s40, s3, 31                                     // 000000464AD4: 86289F03
	s_sub_i32 s8, 0, s37                                       // 000000464AD8: 81882580
	s_mul_i32 s43, s40, 0x1400                                 // 000000464ADC: 962BFF28 00001400
	s_lshl_b32 s6, s3, 7                                       // 000000464AE4: 84068703
	.long 0xd44c0000                                           // 000000464AE8: D44C0000
	v_cndmask_b32_e32 v1, 16, v67, vcc_lo                      // 000000464AEC: 02028690
	v_readfirstlane_b32 s4, v3                                 // 000000464AF0: 7E080503
	s_lshl_b32 s41, s3, 8                                      // 000000464AF4: 84298803
	.long 0xd44a0003                                           // 000000464AF8: D44A0003
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000464AFC: 02020880
	.long 0xd44a0005                                           // 000000464B00: D44A0005
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 000000464B04: 02020C80
	v_lshl_or_b32 v1, v7, 7, v1                                // 000000464B08: D6560001 04050F07
	s_mul_f32 s7, s4, 0x4f7ffffe                               // 000000464B10: A207FF04 4F7FFFFE
	.long 0xd44a0004                                           // 000000464B18: D44A0004
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000464B1C: 02020A80
	v_subrev_nc_u32_e32 v10, s43, v2                           // 000000464B20: 4E14042B
	s_sub_i32 s42, 0, s6                                       // 000000464B24: 81AA0680
	s_cvt_u32_f32 s7, s7                                       // 000000464B28: BE876707
	s_mov_b32 s38, s25                                         // 000000464B2C: BEA60019
	s_mov_b32 s39, 0                                           // 000000464B30: BEA70080
	s_mov_b32 s44, 0x76543210                                  // 000000464B34: BEAC00FF 76543210
	s_mul_i32 s8, s8, s7                                       // 000000464B3C: 96080708
	s_mov_b32 s45, 0x3db504f3                                  // 000000464B40: BEAD00FF 3DB504F3
	s_mul_hi_u32 s6, s7, s8                                    // 000000464B48: 96860807
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000464B4C: BF870009
	s_add_i32 s43, s7, s6                                      // 000000464B50: 812B0607
	s_branch 161                                               // 000000464B54: BFA000A1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3dc>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000464B58: BF870091
	.long 0xd7006a02                                           // 000000464B5C: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000464B60: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000464B64: D5207C03 01AA060D
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000464B6C: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000464B74: DC820006 027C0002
	v_add_f32_e32 v3, v16, v14                                 // 000000464B7C: 06061D10
	s_waitcnt vmcnt(0)                                         // 000000464B80: BF8903F7
	v_fma_mix_f32 v5, v15, v2, v13 op_sel_hi:[0,1,0]           // 000000464B84: CC200005 1436050F
	v_sub_f32_e32 v4, v16, v14                                 // 000000464B8C: 08081D10
	v_fma_mix_f32 v2, -v15, v2, v13 op_sel_hi:[0,1,0]          // 000000464B90: CC200002 3436050F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000464B98: BF870121
	v_dual_add_f32 v6, v3, v5 :: v_dual_add_f32 v7, v4, v2     // 000000464B9C: C9080B03 06060504
	v_sub_f32_e32 v2, v4, v2                                   // 000000464BA4: 08040504
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000464BA8: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000464BB0: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000464BB8: BF870241
	v_dual_add_f32 v4, v6, v4 :: v_dual_sub_f32 v3, v3, v5     // 000000464BBC: C90A0906 04020B03
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000464BC4: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000464BCC: D5010007 20060F07
	.long 0xd72c0006                                           // 000000464BD4: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v12, vcc_lo                  // 000000464BD8: 020218FF 00001400
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000464BE0: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000464BE8: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4)                            // 000000464BF0: BF870004
	v_add_f32_e32 v5, v7, v5                                   // 000000464BF4: 060A0B07
	v_mov_b32_dpp v14, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000464BF8: 7E1C02FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000464C00: D5010002 20060502
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000464C08: 7E0E02FA FF016204
	v_add_f32_e32 v3, v3, v13                                  // 000000464C10: 06061B03
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000464C14: D5010004 200E0904
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000464C1C: 7E1802FA FF016205
	v_add_f32_e32 v2, v2, v14                                  // 000000464C24: 06041D02
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000464C28: D5010005 200E0B05
	v_mov_b32_dpp v13, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000464C30: 7E1A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000464C38: D5010003 200E0703
	v_add_f32_e32 v4, v4, v7                                   // 000000464C40: 06080F04
	v_mov_b32_dpp v14, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000464C44: 7E1C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000464C4C: D5010002 200E0502
	v_add_f32_e32 v5, v5, v12                                  // 000000464C54: 060A1905
	.long 0xd72c0007                                           // 000000464C58: D72C0007
	v_cndmask_b32_e32 v1, s41, v11, vcc_lo                     // 000000464C5C: 02021629
	v_add_f32_e32 v3, v3, v13                                  // 000000464C60: 06061B03
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000464C64: 7E1602FA FF016404
	v_add_f32_e32 v2, v2, v14                                  // 000000464C6C: 06041D02
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000464C70: D5010004 20120904
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000464C78: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000464C80: D5010005 20120B05
	v_mov_b32_dpp v13, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000464C88: 7E1A02FA FF016403
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000464C90: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000464C98: D5010002 20120502
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000464CA0: D5010003 20120703
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v5, v5, v12   // 000000464CA8: C9081704 04041905
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000464CB0: BF8701A3
	v_dual_add_f32 v2, v2, v14 :: v_dual_add_nc_u32 v9, 8, v9  // 000000464CB4: C9201D02 02081288
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000464CBC: 4C0C0F06
	v_mov_b32_dpp v11, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000464CC0: 7E1602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000464CC8: D5010004 20160904
	v_add_f32_e32 v3, v3, v13                                  // 000000464CD0: 06061B03
	v_mov_b32_dpp v12, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000464CD4: 7E1802FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000464CDC: D5010005 20160B05
	v_mov_b32_dpp v14, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000464CE4: 7E1C02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000464CEC: D5010002 20160502
	v_add_f32_e32 v4, v4, v11                                  // 000000464CF4: 06081704
	v_mov_b32_dpp v13, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000464CF8: 7E1A02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000464D00: D5010003 20160703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000464D08: BF870214
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v2, v2, v14   // 000000464D0C: C9081905 05021D02
	v_mov_b32_e32 v11, v4                                      // 000000464D14: 7E160304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000464D18: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000464D20: BF870213
	v_dual_add_f32 v3, v3, v13 :: v_dual_mov_b32 v12, v5       // 000000464D24: C9101B03 030C0105
	v_mov_b32_e32 v14, v2                                      // 000000464D2C: 7E1C0302
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000464D30: BF870224
	v_permlanex16_b32 v11, v11, s44, 0xfedcba98                // 000000464D34: D65C000B 03FC590B FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000464D40: D5010005 20020B05
	v_mov_b32_e32 v13, v3                                      // 000000464D48: 7E1A0303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000464D4C: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000464D54: D5010003 20020703
	v_permlanex16_b32 v12, v12, s44, 0xfedcba98                // 000000464D5C: D65C000C 03FC590C FEDCBA98
	v_permlanex16_b32 v14, v14, s44, 0xfedcba98                // 000000464D68: D65C000E 03FC590E FEDCBA98
	v_add_f32_e32 v4, v4, v11                                  // 000000464D74: 06081704
	v_permlanex16_b32 v13, v13, s44, 0xfedcba98                // 000000464D78: D65C000D 03FC590D FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s9, v9                            // 000000464D84: 7C861209
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_nc_u32 v6, v10, v6// 000000464D88: C9201905 05060D0A
	v_add_f32_e32 v7, v2, v14                                  // 000000464D90: 060E1D02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000464D94: BF870194
	v_dual_add_f32 v11, v3, v13 :: v_dual_add_nc_u32 v10, 0x800, v10// 000000464D98: C9201B03 0B0A14FF 00000800
	v_fma_mixhi_f16 v2, v5, s45, 0                             // 000000464DA4: CC220002 02005B05
	v_fma_mixlo_f16 v2, v4, s45, 0                             // 000000464DAC: CC210002 02005B04
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000464DB4: BF870214
	v_fma_mixhi_f16 v3, v7, s45, 0                             // 000000464DB8: CC220003 02005B07
	v_fma_mixlo_f16 v3, v11, s45, 0                            // 000000464DC0: CC210003 02005B0B
	s_or_b32 s39, vcc_lo, s39                                  // 000000464DC8: 8C27276A
	ds_store_b64 v6, v[2:3]                                    // 000000464DCC: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s39                       // 000000464DD4: 917E277E
	s_cbranch_execz 290                                        // 000000464DD8: BFA50122 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x864>
	.long 0xd72d0002                                           // 000000464DDC: D72D0002
	v_cndmask_b32_e32 v0, v9, v43, vcc_lo                      // 000000464DE0: 02005709
	s_mov_b32 s6, -1                                           // 000000464DE4: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000464DE8: BF870091
	.long 0xd72c0003                                           // 000000464DEC: D72C0003
	v_cndmask_b32_e32 v0, v2, v37, vcc_lo                      // 000000464DF0: 02004B02
	v_sub_nc_u32_e32 v3, v9, v3                                // 000000464DF4: 4C060709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000464DF8: BF870121
	v_subrev_nc_u32_e32 v5, s37, v3                            // 000000464DFC: 4E0A0625
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000464E00: 7C960625
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000464E04: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000464E0C: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000464E10: 02040902
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000464E14: 7C960625
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000464E18: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000464E1C: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000464E20: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s36                        // 000000464E24: 916A247E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000464E28: BF870091
	v_xor_b32_e32 v12, s40, v2                                 // 000000464E2C: 3A180428
	v_subrev_nc_u32_e32 v11, s40, v12                          // 000000464E30: 4E161828
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000464E34: BF8700A1
	v_mad_u64_u32 v[6:7], null, s42, v11, v[1:2]               // 000000464E38: D6FE7C06 0406162A
	v_min_i32_e32 v2, s35, v11                                 // 000000464E40: 22041623
	v_mad_i64_i32 v[4:5], null, v2, s38, 0                     // 000000464E44: D6FF7C04 02004D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000464E4C: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000464E50: 340E0C9F
	.long 0xd73c0002                                           // 000000464E54: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000464E58: 02020C81
	s_cbranch_vccnz 212                                        // 000000464E5C: BFA400D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7b0>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000464E60: BF870093
	.long 0xd7006a06                                           // 000000464E64: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000464E68: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000464E6C: D5207C07 01AA0F05
	.long 0x7f3a3880                                           // 000000464E74: 7F3A3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000464E78: BF870112
	.long 0xd73c0006                                           // 000000464E7C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000464E80: 02020C81
	.long 0x7f40399d                                           // 000000464E84: 7F40399D
	s_waitcnt lgkmcnt(0)                                       // 000000464E88: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000464E8C: BF870092
	.long 0xd7006a0d                                           // 000000464E90: D7006A0D
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000464E94: 02020C1E
	v_add_co_ci_u32_e64 v14, null, s31, v7, vcc_lo             // 000000464E98: D5207C0E 01AA0E1F
	.long 0xd7006a06                                           // 000000464EA0: D7006A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 000000464EA4: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 000000464EA8: BF870001
	v_add_co_ci_u32_e64 v7, null, s23, v7, vcc_lo              // 000000464EAC: D5207C07 01AA0E17
	global_load_b64 v[13:14], v[13:14], off                    // 000000464EB4: DC560000 0D7C000D
	.long 0xd7006a0f                                           // 000000464EBC: D7006A0F
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000464EC0: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 000000464EC4: DC560000 067C0006
	v_add_co_ci_u32_e64 v16, null, s13, v3, vcc_lo             // 000000464ECC: D5207C10 01AA060D
	s_clause 0x1                                               // 000000464ED4: BF850001
	global_load_b32 v17, v[15:16], off                         // 000000464ED8: DC520000 117C000F
	global_load_d16_b16 v15, v[15:16], off offset:4            // 000000464EE0: DC820004 0F7C000F
	s_waitcnt vmcnt(3)                                         // 000000464EE8: BF890FF7
	.long 0x7e20390d                                           // 000000464EEC: 7E20390D
	s_waitcnt vmcnt(2)                                         // 000000464EF0: BF890BF7
	v_and_b32_e32 v39, 0xffff0000, v6                          // 000000464EF4: 364E0CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000464EFC: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000464F00: BF870093
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000464F04: 30202090
	v_mul_f32_e32 v20, 0xbfb8aa3b, v16                         // 000000464F08: 102820FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000464F10: BF870291
	v_exp_f32_e32 v20, v20                                     // 000000464F14: 7E284B14
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_and_b32 v13, 0xffff0000, v13// 000000464F18: C92428F2 140C1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000464F24: BF870111
	v_mul_f32_e32 v19, 0xbfb8aa3b, v13                         // 000000464F28: 10261AFF BFB8AA3B
	v_div_scale_f32 v24, null, v20, v20, v16                   // 000000464F30: D6FC7C18 04422914
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000464F38: BF8701B2
	v_exp_f32_e32 v19, v19                                     // 000000464F3C: 7E264B13
	v_lshlrev_b32_e32 v18, 16, v14                             // 000000464F40: 30241C90
	v_div_scale_f32 v37, s7, v16, v20, v16                     // 000000464F44: D6FC0725 04422910
	v_rcp_f32_e32 v28, v24                                     // 000000464F4C: 7E385518
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000464F50: BF870196
	v_add_f32_e32 v19, 1.0, v19                                // 000000464F54: 062626F2
	v_mul_f32_e32 v21, 0xbfb8aa3b, v18                         // 000000464F58: 102A24FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000464F60: BF870195
	v_fma_f32 v36, -v24, v28, 1.0                              // 000000464F64: D6130024 23CA3918
	v_div_scale_f32 v23, null, v19, v19, v13                   // 000000464F6C: D6FC7C17 04362713
	s_delay_alu instid0(VALU_DEP_3)                            // 000000464F74: BF870003
	v_exp_f32_e32 v21, v21                                     // 000000464F78: 7E2A4B15
	v_and_b32_e32 v14, 0xffff0000, v14                         // 000000464F7C: 361C1CFF FFFF0000
	v_div_scale_f32 v33, vcc_lo, v13, v19, v13                 // 000000464F84: D6FC6A21 0436270D
	v_fmac_f32_e32 v28, v36, v28                               // 000000464F8C: 56383924
	v_rcp_f32_e32 v26, v23                                     // 000000464F90: 7E345517
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000464F94: BF870186
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_mul_f32 v22, 0xbfb8aa3b, v14// 000000464F98: C9062AF2 15161CFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000464FA4: BF870115
	v_fma_f32 v34, -v23, v26, 1.0                              // 000000464FA8: D6130022 23CA3517
	v_div_scale_f32 v25, null, v21, v21, v18                   // 000000464FB0: D6FC7C19 044A2B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000464FB8: BF8701A3
	v_exp_f32_e32 v22, v22                                     // 000000464FBC: 7E2C4B16
	v_div_scale_f32 v35, s6, v18, v21, v18                     // 000000464FC0: D6FC0623 044A2B12
	v_fmac_f32_e32 v26, v34, v26                               // 000000464FC8: 56343522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000464FCC: BF870293
	v_rcp_f32_e32 v30, v25                                     // 000000464FD0: 7E3C5519
	v_fma_f32 v38, -v25, v30, 1.0                              // 000000464FD4: D6130026 23CA3D19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000464FDC: BF870191
	v_fmac_f32_e32 v30, v38, v30                               // 000000464FE0: 563C3D26
	v_mul_f32_e32 v38, v33, v26                                // 000000464FE4: 104C3521
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000464FE8: BF870112
	v_mul_f32_e32 v40, v35, v30                                // 000000464FEC: 10503D23
	v_fma_f32 v41, -v23, v38, v33                              // 000000464FF0: D6130029 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000464FF8: BF870112
	v_fma_f32 v44, -v25, v40, v35                              // 000000464FFC: D613002C 248E5119
	v_fmac_f32_e32 v38, v41, v26                               // 000000465004: 564C3529
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000465008: BF870112
	v_fmac_f32_e32 v40, v44, v30                               // 00000046500C: 56503D2C
	v_fma_f32 v23, -v23, v38, v33                              // 000000465010: D6130017 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000465018: BF870112
	v_fma_f32 v25, -v25, v40, v35                              // 00000046501C: D6130019 248E5119
	v_div_fmas_f32 v23, v23, v26, v38                          // 000000465024: D6370017 049A3517
	s_mov_b32 vcc_lo, s7                                       // 00000046502C: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000465030: BF870091
	v_div_fixup_f32 v13, v23, v19, v13                         // 000000465034: D627000D 04362717
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_mul_f32 v13, v13, v39// 00000046503C: C9062CF2 160C4F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000465044: BF8701A1
	v_div_scale_f32 v27, null, v22, v22, v14                   // 000000465048: D6FC7C1B 043A2D16
	v_div_scale_f32 v36, s8, v14, v22, v14                     // 000000465050: D6FC0824 043A2D0E
	.long 0x7e3a398d                                           // 000000465058: 7E3A398D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000046505C: BF870293
	v_rcp_f32_e32 v31, v27                                     // 000000465060: 7E3E551B
	v_fma_f32 v34, -v27, v31, 1.0                              // 000000465064: D6130022 23CA3F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000046506C: BF870091
	v_dual_fmac_f32 v31, v34, v31 :: v_dual_mul_f32 v34, v37, v28// 000000465070: C8063F22 1F223925
	v_mul_f32_e32 v42, v36, v31                                // 000000465078: 10543F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000046507C: BF870112
	v_fma_f32 v43, -v24, v34, v37                              // 000000465080: D613002B 24964518
	v_fma_f32 v41, -v27, v42, v36                              // 000000465088: D6130029 2492551B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000465090: BF870112
	v_fmac_f32_e32 v34, v43, v28                               // 000000465094: 5644392B
	v_fmac_f32_e32 v42, v41, v31                               // 000000465098: 56543F29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000046509C: BF870112
	v_fma_f32 v24, -v24, v34, v37                              // 0000004650A0: D6130018 24964518
	v_fma_f32 v23, -v27, v42, v36                              // 0000004650A8: D6130017 2492551B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004650B0: BF870002
	v_div_fmas_f32 v24, v24, v28, v34                          // 0000004650B4: D6370018 048A3918
	s_mov_b32 vcc_lo, s6                                       // 0000004650BC: BEEA0006
	s_mov_b32 s6, 0                                            // 0000004650C0: BE860080
	v_div_fmas_f32 v19, v25, v30, v40                          // 0000004650C4: D6370013 04A23D19
	s_mov_b32 vcc_lo, s8                                       // 0000004650CC: BEEA0008
	v_div_fixup_f32 v16, v24, v20, v16                         // 0000004650D0: D6270010 04422918
	v_lshlrev_b32_e32 v20, 16, v7                              // 0000004650D8: 30280E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000004650DC: 360E0EFF FFFF0000
	v_div_fixup_f32 v18, v19, v21, v18                         // 0000004650E4: D6270012 044A2B13
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004650EC: BF8701A4
	v_mul_f32_e32 v6, v16, v6                                  // 0000004650F0: 100C0D10
	v_div_fmas_f32 v16, v23, v31, v42                          // 0000004650F4: D6370010 04AA3F17
	v_mul_f32_e32 v18, v18, v20                                // 0000004650FC: 10242912
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000465100: BF870193
	.long 0x7e403986                                           // 000000465104: 7E403986
	v_div_fixup_f32 v14, v16, v22, v14                         // 000000465108: D627000E 043A2D10
	v_and_b32_e32 v16, 1, v29                                  // 000000465110: 36203A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000465114: BF870194
	v_bfe_u32 v19, v18, 16, 1                                  // 000000465118: D6100013 02052112
	v_dual_mul_f32 v7, v14, v7 :: v_dual_and_b32 v20, 1, v32   // 000000465120: C8E40F0E 07144081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000465128: BF870193
	v_add3_u32 v13, v13, v16, 0x7fff                           // 00000046512C: D655000D 03FE210D 00007FFF
	v_add3_u32 v14, v18, v19, 0x7fff                           // 000000465138: D655000E 03FE2712 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000465144: BF870213
	v_add3_u32 v6, v6, v20, 0x7fff                             // 000000465148: D6550006 03FE2906 00007FFF
	v_bfe_u32 v16, v7, 16, 1                                   // 000000465154: D6100010 02052107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000046515C: BF870214
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000465160: 361A1AFF FFFF0000
	v_and_b32_e32 v18, 0xffff0000, v14                         // 000000465168: 36241CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000465170: BF870214
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000465174: 360C0CFF FFFF0000
	v_add3_u32 v7, v7, v16, 0x7fff                             // 00000046517C: D6550007 03FE2107 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000465188: BF8907F7
	v_fma_mix_f32 v14, v17, v13, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000046518C: CC20080E 8A021B11
	s_waitcnt vmcnt(0)                                         // 000000465194: BF8903F7
	v_fma_mix_f32 v13, v15, v18, neg(0) op_sel_hi:[1,0,0]      // 000000465198: CC20000D 8A02250F
	v_fma_mix_f32 v16, v17, v6, neg(0) op_sel_hi:[1,0,0]       // 0000004651A0: CC200010 8A020D11
	v_and_b32_e32 v15, 0xffff0000, v7                          // 0000004651A8: 361E0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 0000004651B0: 916A067E
	s_cbranch_vccnz 65128                                      // 0000004651B4: BFA4FE68 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x158>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004651B8: BF8700A3
	.long 0xd73c0004                                           // 0000004651BC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000004651C0: 02020881
	s_waitcnt lgkmcnt(0)                                       // 0000004651C4: BF89FC07
	.long 0xd7006a04                                           // 0000004651C8: D7006A04
	v_cndmask_b32_e32 v1, s30, v4, vcc_lo                      // 0000004651CC: 0202081E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004651D0: BF870111
	v_add_co_ci_u32_e64 v5, null, s31, v5, vcc_lo              // 0000004651D4: D5207C05 01AA0A1F
	.long 0xd7006a04                                           // 0000004651DC: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000004651E0: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004651E4: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000004651E8: D5207C05 01AA0705
	.long 0xd7006a06                                           // 0000004651F0: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000004651F4: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 0000004651F8: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 000000465200: DC560000 047C0004
	s_clause 0x1                                               // 000000465208: BF850001
	global_load_b32 v15, v[6:7], off                           // 00000046520C: DC520000 0F7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000465214: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 00000046521C: BF890BF7
	.long 0x7e0e3904                                           // 000000465220: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000465224: 360808FF FFFF0000
	v_lshlrev_b32_e32 v13, 16, v5                              // 00000046522C: 301A0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000465230: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000465234: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000465238: BF8907F7
	v_fma_mix_f32 v14, v15, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000046523C: CC20080E 8A02090F
	s_waitcnt vmcnt(0)                                         // 000000465244: BF8903F7
	v_fma_mix_f32 v13, v6, v13, neg(0) op_sel_hi:[1,0,0]       // 000000465248: CC20000D 8A021B06
	v_fma_mix_f32 v16, v15, v7, neg(0) op_sel_hi:[1,0,0]       // 000000465250: CC200010 8A020F0F
	v_and_b32_e32 v15, 0xffff0000, v5                          // 000000465258: 361E0AFF FFFF0000
	s_branch 65085                                             // 000000465260: BFA0FE3D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x158>
	s_or_b32 exec_lo, exec_lo, s39                             // 000000465264: 8C7E277E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000465268: BF870009
	s_or_b32 exec_lo, exec_lo, s27                             // 00000046526C: 8C7E1B7E
	s_ashr_i32 s0, s9, 31                                      // 000000465270: 86009F09
	v_mad_u32_u24 v9, v67, 24, 0x2f0                           // 000000465274: D60B0009 03FD3143 000002F0
	s_lshr_b32 s0, s0, 29                                      // 000000465280: 85009D00
	s_lshr_b32 s1, s34, 28                                     // 000000465284: 85019C22
	s_add_i32 s0, s0, s9                                       // 000000465288: 81000900
	s_add_i32 s1, s25, s1                                      // 00000046528C: 81010119
	s_add_i32 s0, s0, 7                                        // 000000465290: 81008700
	v_lshrrev_b32_e32 v1, 5, v9                                // 000000465294: 32021285
	s_ashr_i32 s0, s0, 3                                       // 000000465298: 86008300
	s_ashr_i32 s1, s1, 4                                       // 00000046529C: 86018401
	.long 0xd72c0007                                           // 0000004652A0: D72C0007
	v_cndmask_b32_e32 v1, s0, v66, vcc_lo                      // 0000004652A4: 02028400
	s_lshl_b32 s3, s11, 3                                      // 0000004652A8: 8403830B
	s_mul_hi_i32 s5, s1, s2                                    // 0000004652AC: 97050201
	s_mul_i32 s1, s1, s2                                       // 0000004652B0: 96010201
	s_ashr_i32 s4, s3, 31                                      // 0000004652B4: 86049F03
	v_subrev_nc_u32_e32 v3, 24, v1                             // 0000004652B8: 4E060298
	v_cmp_eq_u32_e32 vcc_lo, 0, v67                            // 0000004652BC: 7C948680
	s_waitcnt lgkmcnt(0)                                       // 0000004652C0: BF89FC07
	v_add_nc_u32_e32 v2, s0, v7                                // 0000004652C4: 4A040E00
	v_add_nc_u32_e32 v1, 1, v7                                 // 0000004652C8: 4A020E81
	s_add_u32 s0, s1, s3                                       // 0000004652CC: 80000301
	s_addc_u32 s1, s5, s4                                      // 0000004652D0: 82010405
	s_mul_hi_u32 s3, s0, 0x300                                 // 0000004652D4: 9683FF00 00000300
	v_min_i32_e32 v68, s9, v2                                  // 0000004652DC: 22880409
	s_mulk_i32 s1, 0x300                                       // 0000004652E0: B8010300
	s_mul_i32 s4, s0, 0x300                                    // 0000004652E4: 9604FF00 00000300
	v_cndmask_b32_e64 v5, v3, 23, vcc_lo                       // 0000004652EC: D5010005 01A92F03
	s_add_i32 s3, s3, s1                                       // 0000004652F4: 81030103
	.long 0xd4410000                                           // 0000004652F8: D4410000
	v_cndmask_b32_e32 v1, v1, v68, vcc_lo                      // 0000004652FC: 02028901
	s_add_u32 s4, s28, s4                                      // 000000465300: 8004041C
	s_addc_u32 s5, s29, s3                                     // 000000465304: 8205031D
	s_barrier                                                  // 000000465308: BFBD0000
	buffer_gl0_inv                                             // 00000046530C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000465314: BE812000
	s_cbranch_execz 124                                        // 000000465318: BFA5007C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb0c>
	.long 0xd4440000                                           // 00000046531C: D4440000
	v_cndmask_b32_e32 v1, 23, v5, vcc_lo                       // 000000465320: 02020A97
	v_mad_i64_i32 v[10:11], null, 0x300, v1, s[4:5]            // 000000465324: D6FF7C0A 001202FF 00000300
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000465330: BF870092
	v_cndmask_b32_e64 v3, 0xe9, 1, s0                          // 000000465334: D5010003 000102FF 000000E9
	v_add_nc_u32_e32 v4, v3, v5                                // 000000465340: 4A080B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000465344: BF870091
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v1, 24, v4      // 000000465348: CA220080 06000898
	v_dual_mov_b32 v3, v6 :: v_dual_add_nc_u32 v2, 8, v9       // 000000465350: CA200106 03021288
	.long 0xd73c000c                                           // 000000465358: D73C000C
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000046535C: 02020A82
	v_bfe_i32 v4, v4, 7, 1                                     // 000000465360: D6110004 02050F04
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000465368: BF870214
	v_ashrrev_i32_e32 v6, 22, v1                               // 00000046536C: 340C0296
	v_lshrrev_b32_e32 v2, 5, v2                                // 000000465370: 32040485
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000465374: BF870091
	v_subrev_nc_u32_e32 v2, 24, v2                             // 000000465378: 4E040498
	v_cndmask_b32_e64 v2, v2, 23, vcc_lo                       // 00000046537C: D5010002 01A92F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000465384: BF870091
	.long 0xd4440000                                           // 000000465388: D4440000
	v_cndmask_b32_e32 v1, 23, v2, vcc_lo                       // 00000046538C: 02020497
	v_cndmask_b32_e64 v14, 0xe9, 1, s0                         // 000000465390: D501000E 000102FF 000000E9
	.long 0xd700000c                                           // 00000046539C: D700000C
	v_cndmask_b32_e32 v1, v10, v12, vcc_lo                     // 0000004653A0: 0202190A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004653A4: BF870191
	v_add_co_ci_u32_e64 v13, null, v11, v13, s0                // 0000004653A8: D5207C0D 00021B0B
	v_add_nc_u32_e32 v14, v14, v2                              // 0000004653B0: 4A1C050E
	.long 0xd73c0001                                           // 0000004653B4: D73C0001
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 0000004653B8: 02020482
	.long 0xd7000003                                           // 0000004653BC: D7000003
	v_cndmask_b32_e32 v1, v10, v6, vcc_lo                      // 0000004653C0: 02020D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004653C4: BF870211
	v_add_co_ci_u32_e64 v4, null, v11, v4, s0                  // 0000004653C8: D5207C04 0002090B
	v_lshlrev_b32_e32 v15, 24, v14                             // 0000004653D0: 301E1C98
	v_bfe_i32 v6, v14, 7, 1                                    // 0000004653D4: D6110006 02050F0E
	.long 0xd7000001                                           // 0000004653DC: D7000001
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 0000004653E0: 0202030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004653E4: BF870211
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 0000004653E8: D5207C02 0002050B
	v_ashrrev_i32_e32 v14, 22, v15                             // 0000004653F0: 341C1E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004653F4: BF870091
	.long 0xd700000a                                           // 0000004653F8: D700000A
	v_cndmask_b32_e32 v1, v10, v14, vcc_lo                     // 0000004653FC: 02021D0A
	v_add_co_ci_u32_e64 v11, null, v11, v6, s0                 // 000000465400: D5207C0B 00020D0B
	s_clause 0x1f                                              // 000000465408: BF85001F
	global_load_b32 v69, v[12:13], off                         // 00000046540C: DC520000 457C000C
	global_load_b32 v70, v[12:13], off offset:96               // 000000465414: DC520060 467C000C
	global_load_b32 v71, v[12:13], off offset:192              // 00000046541C: DC5200C0 477C000C
	global_load_b32 v72, v[12:13], off offset:288              // 000000465424: DC520120 487C000C
	global_load_b32 v73, v[12:13], off offset:384              // 00000046542C: DC520180 497C000C
	global_load_b32 v74, v[12:13], off offset:480              // 000000465434: DC5201E0 4A7C000C
	global_load_b32 v75, v[12:13], off offset:576              // 00000046543C: DC520240 4B7C000C
	global_load_b32 v76, v[12:13], off offset:672              // 000000465444: DC5202A0 4C7C000C
	global_load_b32 v84, v[3:4], off                           // 00000046544C: DC520000 547C0003
	global_load_b32 v83, v[3:4], off offset:96                 // 000000465454: DC520060 537C0003
	global_load_b32 v82, v[3:4], off offset:192                // 00000046545C: DC5200C0 527C0003
	global_load_b32 v81, v[3:4], off offset:288                // 000000465464: DC520120 517C0003
	global_load_b32 v80, v[3:4], off offset:384                // 00000046546C: DC520180 507C0003
	global_load_b32 v79, v[3:4], off offset:480                // 000000465474: DC5201E0 4F7C0003
	global_load_b32 v78, v[3:4], off offset:576                // 00000046547C: DC520240 4E7C0003
	global_load_b32 v77, v[3:4], off offset:672                // 000000465484: DC5202A0 4D7C0003
	global_load_b32 v100, v[1:2], off                          // 00000046548C: DC520000 647C0001
	global_load_b32 v99, v[1:2], off offset:96                 // 000000465494: DC520060 637C0001
	global_load_b32 v96, v[1:2], off offset:192                // 00000046549C: DC5200C0 607C0001
	global_load_b32 v94, v[1:2], off offset:288                // 0000004654A4: DC520120 5E7C0001
	global_load_b32 v93, v[1:2], off offset:384                // 0000004654AC: DC520180 5D7C0001
	global_load_b32 v90, v[1:2], off offset:480                // 0000004654B4: DC5201E0 5A7C0001
	global_load_b32 v88, v[1:2], off offset:576                // 0000004654BC: DC520240 587C0001
	global_load_b32 v85, v[1:2], off offset:672                // 0000004654C4: DC5202A0 557C0001
	global_load_b32 v116, v[10:11], off                        // 0000004654CC: DC520000 747C000A
	global_load_b32 v113, v[10:11], off offset:96              // 0000004654D4: DC520060 717C000A
	global_load_b32 v110, v[10:11], off offset:192             // 0000004654DC: DC5200C0 6E7C000A
	global_load_b32 v108, v[10:11], off offset:288             // 0000004654E4: DC520120 6C7C000A
	global_load_b32 v107, v[10:11], off offset:384             // 0000004654EC: DC520180 6B7C000A
	global_load_b32 v105, v[10:11], off offset:480             // 0000004654F4: DC5201E0 697C000A
	global_load_b32 v104, v[10:11], off offset:576             // 0000004654FC: DC520240 687C000A
	global_load_b32 v102, v[10:11], off offset:672             // 000000465504: DC5202A0 667C000A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000046550C: 8C7E017E
	.long 0xd4410000                                           // 000000465510: D4410000
	v_cndmask_b32_e32 v1, v7, v68, vcc_lo                      // 000000465514: 02028907
	s_and_saveexec_b32 s3, s0                                  // 000000465518: BE832000
	s_cbranch_execz 124                                        // 00000046551C: BFA5007C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xd10>
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v1, 8, v9        // 000000465520: CA200080 06001288
	.long 0xd4440001                                           // 000000465528: D4440001
	v_cndmask_b32_e32 v1, 23, v5, vcc_lo                       // 00000046552C: 02020A97
	v_mad_i64_i32 v[3:4], null, 0x300, v7, s[4:5]              // 000000465530: D6FF7C03 00120EFF 00000300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000046553C: BF870213
	v_lshrrev_b32_e32 v1, 5, v1                                // 000000465540: 32020285
	.long 0xd73c000a                                           // 000000465544: D73C000A
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000465548: 02020A82
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000046554C: BF870194
	v_cndmask_b32_e64 v2, 0xe9, 1, s1                          // 000000465550: D5010002 000502FF 000000E9
	v_subrev_nc_u32_e32 v1, 24, v1                             // 00000046555C: 4E020298
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000465560: BF8701A2
	v_add_nc_u32_e32 v12, v2, v5                               // 000000465564: 4A180B02
	v_mov_b32_e32 v2, v6                                       // 000000465568: 7E040306
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 00000046556C: D5010001 01A92F01
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000465574: BF8701A3
	v_lshlrev_b32_e32 v13, 24, v12                             // 000000465578: 301A1898
	v_bfe_i32 v6, v12, 7, 1                                    // 00000046557C: D6110006 02050F0C
	.long 0xd4440001                                           // 000000465584: D4440001
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 000000465588: 02020297
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000046558C: BF870113
	v_ashrrev_i32_e32 v12, 22, v13                             // 000000465590: 34181A96
	v_cndmask_b32_e64 v14, 0xe9, 1, s1                         // 000000465594: D501000E 000502FF 000000E9
	.long 0xd700010a                                           // 0000004655A0: D700010A
	v_cndmask_b32_e32 v1, v3, v10, vcc_lo                      // 0000004655A4: 02021503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004655A8: BF870191
	v_add_co_ci_u32_e64 v11, null, v4, v11, s1                 // 0000004655AC: D5207C0B 00061704
	v_add_nc_u32_e32 v14, v14, v1                              // 0000004655B4: 4A1C030E
	.long 0xd73c0001                                           // 0000004655B8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000004655BC: 02020282
	.long 0xd700010c                                           // 0000004655C0: D700010C
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 0000004655C4: 02021903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004655C8: BF870211
	v_add_co_ci_u32_e64 v13, null, v4, v6, s1                  // 0000004655CC: D5207C0D 00060D04
	v_lshlrev_b32_e32 v15, 24, v14                             // 0000004655D4: 301E1C98
	v_bfe_i32 v6, v14, 7, 1                                    // 0000004655D8: D6110006 02050F0E
	.long 0xd700010e                                           // 0000004655E0: D700010E
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 0000004655E4: 02020303
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004655E8: BF870123
	v_ashrrev_i32_e32 v16, 22, v15                             // 0000004655EC: 34201E96
	v_add_co_ci_u32_e64 v15, null, v4, v2, s1                  // 0000004655F0: D5207C0F 00060504
	.long 0xd7000110                                           // 0000004655F8: D7000110
	v_cndmask_b32_e32 v1, v3, v16, vcc_lo                      // 0000004655FC: 02022103
	s_delay_alu instid0(VALU_DEP_1)                            // 000000465600: BF870001
	v_add_co_ci_u32_e64 v17, null, v4, v6, s1                  // 000000465604: D5207C11 00060D04
	s_clause 0x1f                                              // 00000046560C: BF85001F
	global_load_b32 v2, v[10:11], off                          // 000000465610: DC520000 027C000A
	global_load_b32 v63, v[10:11], off offset:96               // 000000465618: DC520060 3F7C000A
	global_load_b32 v59, v[10:11], off offset:192              // 000000465620: DC5200C0 3B7C000A
	global_load_b32 v55, v[10:11], off offset:288              // 000000465628: DC520120 377C000A
	global_load_b32 v51, v[10:11], off offset:384              // 000000465630: DC520180 337C000A
	global_load_b32 v47, v[10:11], off offset:480              // 000000465638: DC5201E0 2F7C000A
	global_load_b32 v43, v[10:11], off offset:576              // 000000465640: DC520240 2B7C000A
	global_load_b32 v39, v[10:11], off offset:672              // 000000465648: DC5202A0 277C000A
	global_load_b32 v1, v[12:13], off                          // 000000465650: DC520000 017C000C
	global_load_b32 v62, v[12:13], off offset:96               // 000000465658: DC520060 3E7C000C
	global_load_b32 v58, v[12:13], off offset:192              // 000000465660: DC5200C0 3A7C000C
	global_load_b32 v54, v[12:13], off offset:288              // 000000465668: DC520120 367C000C
	global_load_b32 v50, v[12:13], off offset:384              // 000000465670: DC520180 327C000C
	global_load_b32 v46, v[12:13], off offset:480              // 000000465678: DC5201E0 2E7C000C
	global_load_b32 v42, v[12:13], off offset:576              // 000000465680: DC520240 2A7C000C
	global_load_b32 v38, v[12:13], off offset:672              // 000000465688: DC5202A0 267C000C
	global_load_b32 v4, v[14:15], off                          // 000000465690: DC520000 047C000E
	global_load_b32 v65, v[14:15], off offset:96               // 000000465698: DC520060 417C000E
	global_load_b32 v61, v[14:15], off offset:192              // 0000004656A0: DC5200C0 3D7C000E
	global_load_b32 v57, v[14:15], off offset:288              // 0000004656A8: DC520120 397C000E
	global_load_b32 v53, v[14:15], off offset:384              // 0000004656B0: DC520180 357C000E
	global_load_b32 v49, v[14:15], off offset:480              // 0000004656B8: DC5201E0 317C000E
	global_load_b32 v45, v[14:15], off offset:576              // 0000004656C0: DC520240 2D7C000E
	global_load_b32 v41, v[14:15], off offset:672              // 0000004656C8: DC5202A0 297C000E
	global_load_b32 v3, v[16:17], off                          // 0000004656D0: DC520000 037C0010
	global_load_b32 v64, v[16:17], off offset:96               // 0000004656D8: DC520060 407C0010
	global_load_b32 v60, v[16:17], off offset:192              // 0000004656E0: DC5200C0 3C7C0010
	global_load_b32 v56, v[16:17], off offset:288              // 0000004656E8: DC520120 387C0010
	global_load_b32 v52, v[16:17], off offset:384              // 0000004656F0: DC520180 347C0010
	global_load_b32 v48, v[16:17], off offset:480              // 0000004656F8: DC5201E0 307C0010
	global_load_b32 v44, v[16:17], off offset:576              // 000000465700: DC520240 2C7C0010
	global_load_b32 v40, v[16:17], off offset:672              // 000000465708: DC5202A0 287C0010
	s_or_b32 exec_lo, exec_lo, s3                              // 000000465710: 8C7E037E
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v86, 0             // 000000465714: CA100080 21560080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v92, 0             // 00000046571C: CA100080 575C0080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v98, 0             // 000000465724: CA100080 59620080
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v106, 0            // 00000046572C: CA100080 5B6A0080
	v_dual_mov_b32 v95, 0 :: v_dual_mov_b32 v112, 0            // 000000465734: CA100080 5F700080
	v_dual_mov_b32 v97, 0 :: v_dual_mov_b32 v114, 0            // 00000046573C: CA100080 61720080
	v_dual_mov_b32 v101, 0 :: v_dual_mov_b32 v118, 0           // 000000465744: CA100080 65760080
	v_dual_mov_b32 v103, 0 :: v_dual_mov_b32 v120, 0           // 00000046574C: CA100080 67780080
	v_dual_mov_b32 v109, 0 :: v_dual_mov_b32 v122, 0           // 000000465754: CA100080 6D7A0080
	v_dual_mov_b32 v111, 0 :: v_dual_mov_b32 v124, 0           // 00000046575C: CA100080 6F7C0080
	v_dual_mov_b32 v115, 0 :: v_dual_mov_b32 v126, 0           // 000000465764: CA100080 737E0080
	v_dual_mov_b32 v117, 0 :: v_dual_mov_b32 v128, 0           // 00000046576C: CA100080 75800080
	v_dual_mov_b32 v119, 0 :: v_dual_mov_b32 v130, 0           // 000000465774: CA100080 77820080
	v_dual_mov_b32 v121, 0 :: v_dual_mov_b32 v132, 0           // 00000046577C: CA100080 79840080
	v_dual_mov_b32 v123, 0 :: v_dual_mov_b32 v134, 0           // 000000465784: CA100080 7B860080
	v_dual_mov_b32 v125, 0 :: v_dual_mov_b32 v136, 0           // 00000046578C: CA100080 7D880080
	v_dual_mov_b32 v127, 0 :: v_dual_mov_b32 v138, 0           // 000000465794: CA100080 7F8A0080
	v_dual_mov_b32 v129, 0 :: v_dual_mov_b32 v140, 0           // 00000046579C: CA100080 818C0080
	v_dual_mov_b32 v131, 0 :: v_dual_mov_b32 v142, 0           // 0000004657A4: CA100080 838E0080
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v144, 0           // 0000004657AC: CA100080 85900080
	v_dual_mov_b32 v135, 0 :: v_dual_mov_b32 v146, 0           // 0000004657B4: CA100080 87920080
	v_dual_mov_b32 v137, 0 :: v_dual_mov_b32 v158, 0           // 0000004657BC: CA100080 899E0080
	v_dual_mov_b32 v139, 0 :: v_dual_mov_b32 v160, 0           // 0000004657C4: CA100080 8BA00080
	v_dual_mov_b32 v141, 0 :: v_dual_mov_b32 v162, 0           // 0000004657CC: CA100080 8DA20080
	v_dual_mov_b32 v143, 0 :: v_dual_mov_b32 v148, 0           // 0000004657D4: CA100080 8F940080
	v_dual_mov_b32 v145, 0 :: v_dual_mov_b32 v150, 0           // 0000004657DC: CA100080 91960080
	v_dual_mov_b32 v147, 0 :: v_dual_mov_b32 v152, 0           // 0000004657E4: CA100080 93980080
	v_dual_mov_b32 v149, 0 :: v_dual_mov_b32 v156, 0           // 0000004657EC: CA100080 959C0080
	v_dual_mov_b32 v151, 0 :: v_dual_mov_b32 v154, 0           // 0000004657F4: CA100080 979A0080
	v_mov_b32_e32 v155, 0                                      // 0000004657FC: 7F360280
	v_mov_b32_e32 v157, 0                                      // 000000465800: 7F3A0280
	v_mov_b32_e32 v161, 0                                      // 000000465804: 7F420280
	v_mov_b32_e32 v153, 0                                      // 000000465808: 7F320280
	v_mov_b32_e32 v159, 0                                      // 00000046580C: 7F3E0280
	v_mov_b32_e32 v163, 0                                      // 000000465810: 7F460280
	s_ashr_i32 s3, s2, 31                                      // 000000465814: 86039F02
	s_and_saveexec_b32 s1, s0                                  // 000000465818: BE812000
	s_cbranch_execz 1403                                       // 00000046581C: BFA5057B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x240c>
	v_dual_mov_b32 v33, 0 :: v_dual_add_nc_u32 v6, 8, v9       // 000000465820: CA200080 21061288
	v_and_b32_e32 v14, 16, v0                                  // 000000465828: 361C0090
	v_mul_i32_i24_e32 v10, 0xffffffe8, v67                     // 00000046582C: 121486FF FFFFFFE8
	v_dual_mov_b32 v12, 23 :: v_dual_and_b32 v9, 0x7e0, v9     // 000000465834: CA240097 0C0812FF 000007E0
	s_delay_alu instid0(VALU_DEP_4)                            // 000000465840: BF870004
	v_lshrrev_b32_e32 v13, 5, v6                               // 000000465844: 321A0C85
	v_or_b32_e32 v11, 4, v8                                    // 000000465848: 38161084
	.long 0xd7030008                                           // 00000046584C: D7030008
	v_cndmask_b32_e32 v0, v5, v129, vcc_lo                     // 000000465850: 02010305
	v_ashrrev_i32_e32 v6, 31, v5                               // 000000465854: 340C0A9F
	v_dual_mov_b32 v86, v33 :: v_dual_add_nc_u32 v165, 2, v7   // 000000465858: CA200121 56A40E82
	v_subrev_nc_u32_e32 v13, 24, v13                           // 000000465860: 4E1A1A98
	v_mov_b32_e32 v87, v33                                     // 000000465864: 7EAE0321
	v_lshl_or_b32 v167, v7, 5, v14                             // 000000465868: D65600A7 04390B07
	v_add3_u32 v166, v10, v9, 0xfffffd34                       // 000000465870: D65500A6 03FE130A FFFFFD34
	.long 0xd7624008                                           // 00000046587C: D7624008
	v_cndmask_b32_e32 v1, 0xff, v8, vcc_lo                     // 000000465880: 020210FF 000000FF
	v_cndmask_b32_e64 v32, v13, 23, vcc_lo                     // 000000465888: D5010020 01A92F0D
	.long 0x7e12390c                                           // 000000465890: 7E12390C
	.long 0xd73c0022                                           // 000000465894: D73C0022
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000465898: 02020A82
	v_mad_u32_u24 v10, v11, 3, 0x2f0                           // 00000046589C: D60B000A 03FD070B 000002F0
	v_cmp_gt_u16_e32 vcc_lo, 24, v136/*Invalid register, operand has 'VGPR_32_Lo128' register class*/// 0000004658A8: 7C791098
	.long 0xd7030007                                           // 0000004658AC: D7030007
	v_cndmask_b32_e32 v0, v32, v129, vcc_lo                    // 0000004658B0: 02010320
	.long 0xd7040005                                           // 0000004658B4: D7040005
	v_cndmask_b32_e32 v1, v5, v9, vcc_lo                       // 0000004658B8: 02021305
	v_mul_i32_i24_e32 v11, -3, v11                             // 0000004658BC: 121616C3
	v_mov_b32_e32 v92, v33                                     // 0000004658C0: 7EB80321
	.long 0xd73c0024                                           // 0000004658C4: D73C0024
	v_cndmask_b32_e32 v1, 2, v32, vcc_lo                       // 0000004658C8: 02024082
	.long 0xd7624005                                           // 0000004658CC: D7624005
	v_cndmask_b32_e32 v1, 0xff, v7, vcc_lo                     // 0000004658D0: 02020EFF 000000FF
	v_cndmask_b16 v5, v5, v8, vcc_lo                           // 0000004658D8: D65D0005 01AA1105
	v_mov_b32_e32 v98, v33                                     // 0000004658E0: 7EC40321
	v_sub_nc_u32_e32 v164, 0, v68                              // 0000004658E4: 4D488880
	v_mov_b32_e32 v95, v33                                     // 0000004658E8: 7EBE0321
	.long 0xd43d1000                                           // 0000004658EC: D43D1000
	v_cndmask_b32_e32 v1, 24, v5, vcc_lo                       // 0000004658F0: 02020A98
	v_and_b32_e32 v5, 0xff, v5                                 // 0000004658F4: 360A0AFF 000000FF
	v_mov_b32_e32 v97, v33                                     // 0000004658FC: 7EC20321
	v_mov_b32_e32 v101, v33                                    // 000000465900: 7ECA0321
	v_mov_b32_e32 v103, v33                                    // 000000465904: 7ECE0321
	v_cndmask_b16 v6, 0, v7, s0                                // 000000465908: D65D0006 00020E80
	v_mov_b32_e32 v89, v33                                     // 000000465910: 7EB20321
	v_dual_mov_b32 v106, v33 :: v_dual_and_b32 v7, 0x7e0, v10  // 000000465914: CA240121 6A0614FF 000007E0
	v_lshlrev_b32_e32 v169, 2, v5                              // 000000465920: 31520A82
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000465924: BF870194
	v_dual_mov_b32 v91, v33 :: v_dual_and_b32 v6, 0xff, v6     // 000000465928: CA240121 5B060CFF 000000FF
	v_add3_u32 v168, v11, v7, 0xfffffd34                       // 000000465934: D65500A8 03FE0F0B FFFFFD34
	v_mov_b32_e32 v109, v33                                    // 000000465940: 7EDA0321
	s_delay_alu instid0(VALU_DEP_3)                            // 000000465944: BF870003
	v_dual_mov_b32 v111, v33 :: v_dual_lshlrev_b32 v170, 2, v6 // 000000465948: CA220121 6FAA0C82
	v_mov_b32_e32 v112, v33                                    // 000000465950: 7EE00321
	v_mov_b32_e32 v114, v33                                    // 000000465954: 7EE40321
	v_mov_b32_e32 v115, v33                                    // 000000465958: 7EE60321
	v_mov_b32_e32 v117, v33                                    // 00000046595C: 7EEA0321
	v_mov_b32_e32 v118, v33                                    // 000000465960: 7EEC0321
	v_mov_b32_e32 v119, v33                                    // 000000465964: 7EEE0321
	v_mov_b32_e32 v120, v33                                    // 000000465968: 7EF00321
	v_mov_b32_e32 v121, v33                                    // 00000046596C: 7EF20321
	v_mov_b32_e32 v122, v33                                    // 000000465970: 7EF40321
	v_mov_b32_e32 v123, v33                                    // 000000465974: 7EF60321
	v_mov_b32_e32 v124, v33                                    // 000000465978: 7EF80321
	v_mov_b32_e32 v125, v33                                    // 00000046597C: 7EFA0321
	v_mov_b32_e32 v126, v33                                    // 000000465980: 7EFC0321
	v_mov_b32_e32 v127, v33                                    // 000000465984: 7EFE0321
	v_mov_b32_e32 v128, v33                                    // 000000465988: 7F000321
	v_mov_b32_e32 v129, v33                                    // 00000046598C: 7F020321
	v_mov_b32_e32 v130, v33                                    // 000000465990: 7F040321
	v_mov_b32_e32 v131, v33                                    // 000000465994: 7F060321
	v_mov_b32_e32 v132, v33                                    // 000000465998: 7F080321
	v_mov_b32_e32 v133, v33                                    // 00000046599C: 7F0A0321
	v_mov_b32_e32 v134, v33                                    // 0000004659A0: 7F0C0321
	v_mov_b32_e32 v135, v33                                    // 0000004659A4: 7F0E0321
	v_mov_b32_e32 v136, v33                                    // 0000004659A8: 7F100321
	v_mov_b32_e32 v137, v33                                    // 0000004659AC: 7F120321
	v_mov_b32_e32 v138, v33                                    // 0000004659B0: 7F140321
	v_mov_b32_e32 v139, v33                                    // 0000004659B4: 7F160321
	v_mov_b32_e32 v140, v33                                    // 0000004659B8: 7F180321
	v_mov_b32_e32 v141, v33                                    // 0000004659BC: 7F1A0321
	v_mov_b32_e32 v142, v33                                    // 0000004659C0: 7F1C0321
	v_mov_b32_e32 v143, v33                                    // 0000004659C4: 7F1E0321
	v_mov_b32_e32 v144, v33                                    // 0000004659C8: 7F200321
	v_mov_b32_e32 v145, v33                                    // 0000004659CC: 7F220321
	v_mov_b32_e32 v146, v33                                    // 0000004659D0: 7F240321
	v_mov_b32_e32 v147, v33                                    // 0000004659D4: 7F260321
	v_mov_b32_e32 v149, v33                                    // 0000004659D8: 7F2A0321
	v_mov_b32_e32 v151, v33                                    // 0000004659DC: 7F2E0321
	v_mov_b32_e32 v155, v33                                    // 0000004659E0: 7F360321
	v_mov_b32_e32 v157, v33                                    // 0000004659E4: 7F3A0321
	v_mov_b32_e32 v158, v33                                    // 0000004659E8: 7F3C0321
	v_mov_b32_e32 v160, v33                                    // 0000004659EC: 7F400321
	v_mov_b32_e32 v161, v33                                    // 0000004659F0: 7F420321
	v_mov_b32_e32 v162, v33                                    // 0000004659F4: 7F440321
	v_mov_b32_e32 v148, v33                                    // 0000004659F8: 7F280321
	v_mov_b32_e32 v150, v33                                    // 0000004659FC: 7F2C0321
	v_mov_b32_e32 v152, v33                                    // 000000465A00: 7F300321
	v_mov_b32_e32 v156, v33                                    // 000000465A04: 7F380321
	v_mov_b32_e32 v153, v33                                    // 000000465A08: 7F320321
	v_mov_b32_e32 v154, v33                                    // 000000465A0C: 7F340321
	v_mov_b32_e32 v159, v33                                    // 000000465A10: 7F3E0321
	v_mov_b32_e32 v163, v33                                    // 000000465A14: 7F460321
	s_mov_b32 s0, 0                                            // 000000465A18: BE800080
	s_movk_i32 s6, 0x1eee                                      // 000000465A1C: B0061EEE
	s_branch 1139                                              // 000000465A20: BFA00473 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x21f0>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000465A24: 8C7E077E
	.long 0xd73d0015                                           // 000000465A28: D73D0015
	v_cndmask_b32_e32 v1, v166, v1, vcc_lo                     // 000000465A2C: 020203A6
	.long 0xd73d0016                                           // 000000465A30: D73D0016
	v_cndmask_b32_e32 v1, v168, v3, vcc_lo                     // 000000465A34: 020207A8
	ds_load_b128 v[9:12], v167                                 // 000000465A38: DBFC0000 090000A7
	ds_load_b128 v[13:16], v167 offset:5120                    // 000000465A40: DBFC1400 0D0000A7
	ds_load_b128 v[17:20], v167 offset:10240                   // 000000465A48: DBFC2800 110000A7
	ds_load_b128 v[5:8], v167 offset:15360                     // 000000465A50: DBFC3C00 050000A7
	ds_load_b128 v[1:4], v167 offset:20480                     // 000000465A58: DBFC5000 010000A7
	.long 0xd73d003e                                           // 000000465A60: D73D003E
	v_cndmask_b32_e32 v1, v166, v62, vcc_lo                    // 000000465A64: 02027DA6
	.long 0xd73d003f                                           // 000000465A68: D73D003F
	v_cndmask_b32_e32 v1, v168, v64, vcc_lo                    // 000000465A6C: 020281A8
	v_bfe_u32 v23, v21, 9, 16                                  // 000000465A70: D6100017 02411315
	v_bfe_u32 v25, v21, 6, 16                                  // 000000465A78: D6100019 02410D15
	v_bfe_u32 v26, v22, 9, 16                                  // 000000465A80: D610001A 02411316
	v_bfe_u32 v27, v22, 6, 16                                  // 000000465A88: D610001B 02410D16
	v_bfe_u32 v28, v22, 3, 16                                  // 000000465A90: D610001C 02410716
	.long 0xd72c0017                                           // 000000465A98: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 000000465A9C: 02022EFF 83DCD12D
	.long 0xd72c0019                                           // 000000465AA4: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000465AA8: 020232FF 83DCD12D
	.long 0xd72c001a                                           // 000000465AB0: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 000000465AB4: 020234FF 83DCD12D
	.long 0xd72c001b                                           // 000000465ABC: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 000000465AC0: 020236FF 83DCD12D
	v_bfe_u32 v64, v62, 6, 16                                  // 000000465AC8: D6100040 02410D3E
	v_bfe_u32 v208, v63, 3, 16                                 // 000000465AD0: D61000D0 0241073F
	.long 0xd73d003a                                           // 000000465AD8: D73D003A
	v_cndmask_b32_e32 v1, v166, v58, vcc_lo                    // 000000465ADC: 020275A6
	.long 0xd73d003b                                           // 000000465AE0: D73D003B
	v_cndmask_b32_e32 v1, v168, v60, vcc_lo                    // 000000465AE4: 020279A8
	v_sad_u8 v23, v23, 0, 0x6400                               // 000000465AE8: D6220017 03FD0117 00006400
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000465AF4: D6220019 03FD0119 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000465B00: D622001A 03FD011A 00006400
	v_sad_u8 v204, v27, 0, 0x6400                              // 000000465B0C: D62200CC 03FD011B 00006400
	.long 0xd72c0040                                           // 000000465B18: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000465B1C: 020280FF 83DCD12D
	v_and_b32_e32 v30, 0xffff, v23                             // 000000465B24: 363C2EFF 0000FFFF
	v_bfe_u32 v61, v58, 6, 16                                  // 000000465B2C: D610003D 02410D3A
	.long 0xd73d0036                                           // 000000465B34: D73D0036
	v_cndmask_b32_e32 v1, v166, v54, vcc_lo                    // 000000465B38: 02026DA6
	.long 0xd73d0037                                           // 000000465B3C: D73D0037
	v_cndmask_b32_e32 v1, v168, v56, vcc_lo                    // 000000465B40: 020271A8
	.long 0xd73d0032                                           // 000000465B44: D73D0032
	v_cndmask_b32_e32 v1, v166, v50, vcc_lo                    // 000000465B48: 020265A6
	v_lshl_or_b32 v30, v25, 16, v30                            // 000000465B4C: D656001E 04792119
	.long 0xd72c003d                                           // 000000465B54: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000465B58: 02027AFF 83DCD12D
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000465B60: D6220040 03FD0140 00006400
	v_bfe_u32 v56, v54, 6, 16                                  // 000000465B6C: D6100038 02410D36
	.long 0xd73d0033                                           // 000000465B74: D73D0033
	v_cndmask_b32_e32 v1, v168, v52, vcc_lo                    // 000000465B78: 020269A8
	v_pk_fma_f16 v205, v30, s6, 0xc931 op_sel_hi:[1,0,0]       // 000000465B7C: CC0E00CD 0BFC0D1E 0000C931
	v_and_b32_e32 v22, 0xffff, v22                             // 000000465B88: 362C2CFF 0000FFFF
	v_and_b32_e32 v203, 0xffff, v26                            // 000000465B90: 379634FF 0000FFFF
	.long 0xd72c0038                                           // 000000465B98: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000465B9C: 020270FF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000465BA4: D622003D 03FD013D 00006400
	s_waitcnt lgkmcnt(4)                                       // 000000465BB0: BF89FC47
	v_dot2acc_f32_f16 v163, v205, v9                           // 000000465BB4: 054613CD
	v_and_b32_e32 v24, 0xffff, v21                             // 000000465BB8: 36302AFF 0000FFFF
	v_bfe_u32 v21, v21, 3, 16                                  // 000000465BC0: D6100015 02410715
	.long 0xd72c0020                                           // 000000465BC8: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 000000465BCC: 02022CFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000465BD4: BF89FC07
	v_dot2acc_f32_f16 v156, v205, v1                           // 000000465BD8: 053803CD
	v_lshl_or_b32 v203, v204, 16, v203                         // 000000465BDC: D65600CB 072D21CC
	.long 0xd72c0018                                           // 000000465BE4: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 000000465BE8: 020230FF 83DCD12D
	.long 0xd72c0015                                           // 000000465BF0: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 000000465BF4: 02022AFF 83DCD12D
	v_dot2acc_f32_f16 v159, v205, v13                          // 000000465BFC: 053E1BCD
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000465C00: D6220038 03FD0138 00006400
	v_pk_fma_f16 v203, v203, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000465C0C: CC0E00CB 0BFC0DCB 0000C931
	v_sad_u8 v32, v32, 0, 0x6400                               // 000000465C18: D6220020 03FD0120 00006400
	v_bfe_u32 v53, v50, 6, 16                                  // 000000465C24: D6100035 02410D32
	.long 0xd73d002e                                           // 000000465C2C: D73D002E
	v_cndmask_b32_e32 v1, v166, v46, vcc_lo                    // 000000465C30: 02025DA6
	v_sad_u8 v24, v24, 0, 0x6400                               // 000000465C34: D6220018 03FD0118 00006400
	v_sad_u8 v29, v21, 0, 0x6400                               // 000000465C40: D622001D 03FD0115 00006400
	.long 0xd73d002f                                           // 000000465C4C: D73D002F
	v_cndmask_b32_e32 v1, v168, v48, vcc_lo                    // 000000465C50: 020261A8
	.long 0xd72c0035                                           // 000000465C54: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000465C58: 02026AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000465C60: BF870004
	v_dual_dot2acc_f32_f16 v154, v205, v17 :: v_dual_lshlrev_b32 v31, 16, v24// 000000465C64: CB2223CD 9A1E3090
	ds_load_b128 v[21:24], v167 offset:25600                   // 000000465C6C: DBFC6400 150000A7
	.long 0xd73d002a                                           // 000000465C74: D73D002A
	v_cndmask_b32_e32 v1, v166, v42, vcc_lo                    // 000000465C78: 020255A6
	.long 0xd73d002b                                           // 000000465C7C: D73D002B
	v_cndmask_b32_e32 v1, v168, v44, vcc_lo                    // 000000465C80: 020259A8
	.long 0xd73d0026                                           // 000000465C84: D73D0026
	v_cndmask_b32_e32 v1, v166, v38, vcc_lo                    // 000000465C88: 02024DA6
	v_and_or_b32 v29, 0xffff, v29, v31                         // 000000465C8C: D657001D 047E3AFF 0000FFFF
	.long 0xd72c001f                                           // 000000465C98: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 000000465C9C: 020238FF 83DCD12D
	ds_load_b128 v[25:28], v167 offset:35840                   // 000000465CA4: DBFC8C00 190000A7
	v_lshlrev_b32_e32 v207, 16, v32                            // 000000465CAC: 319E4090
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000465CB0: D6220035 03FD0135 00006400
	v_pk_fma_f16 v206, v29, s6, 0xc931 op_sel_hi:[1,0,0]       // 000000465CBC: CC0E00CE 0BFC0D1D 0000C931
	v_bfe_u32 v45, v42, 6, 16                                  // 000000465CC8: D610002D 02410D2A
	.long 0xd73d0027                                           // 000000465CD0: D73D0027
	v_cndmask_b32_e32 v1, v168, v40, vcc_lo                    // 000000465CD4: 020251A8
	v_bfe_u32 v40, v38, 6, 16                                  // 000000465CD8: D6100028 02410D26
	v_sad_u8 v204, v31, 0, 0x6400                              // 000000465CE0: D62200CC 03FD011F 00006400
	ds_load_b128 v[29:32], v167 offset:30720                   // 000000465CEC: DBFC7800 1D0000A7
	v_dot2acc_f32_f16 v163, v206, v10                          // 000000465CF4: 054615CE
	v_dot2acc_f32_f16 v159, v206, v14                          // 000000465CF8: 053E1DCE
	.long 0xd72c002d                                           // 000000465CFC: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000465D00: 02025AFF 83DCD12D
	v_dot2acc_f32_f16 v154, v206, v18                          // 000000465D08: 053425CE
	.long 0xd72c0028                                           // 000000465D0C: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000465D10: 020250FF 83DCD12D
	s_waitcnt lgkmcnt(2)                                       // 000000465D18: BF89FC27
	v_dot2acc_f32_f16 v152, v205, v21                          // 000000465D1C: 05302BCD
	v_and_or_b32 v204, 0xffff, v204, v207                      // 000000465D20: D65700CC 073F98FF 0000FFFF
	v_dot2acc_f32_f16 v163, v203, v11                          // 000000465D2C: 054617CB
	v_bfe_u32 v207, v62, 9, 16                                 // 000000465D30: D61000CF 0241133E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000465D38: BF870214
	v_dual_dot2acc_f32_f16 v153, v205, v5 :: v_dual_dot2acc_f32_f16 v152, v206, v22// 000000465D3C: CB180BCD 99982DCE
	v_pk_fma_f16 v204, v204, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000465D44: CC0E00CC 0BFC0DCC 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000465D50: BF89FC17
	v_dot2acc_f32_f16 v148, v205, v25                          // 000000465D54: 052833CD
	v_dot2acc_f32_f16 v154, v203, v19                          // 000000465D58: 053427CB
	.long 0xd72c0041                                           // 000000465D5C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v207, vcc_lo             // 000000465D60: 02039EFF 83DCD12D
	v_dual_dot2acc_f32_f16 v153, v206, v6 :: v_dual_dot2acc_f32_f16 v152, v203, v23// 000000465D68: CB180DCE 99982FCB
	v_dot2acc_f32_f16 v163, v204, v12                          // 000000465D70: 054619CC
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000465D74: BF8701D4
	v_dot2acc_f32_f16 v154, v204, v20                          // 000000465D78: 053429CC
	s_waitcnt lgkmcnt(0)                                       // 000000465D7C: BF89FC07
	v_dual_dot2acc_f32_f16 v150, v205, v29 :: v_dual_and_b32 v205, 0xffff, v62// 000000465D80: CB243BCD 96CC7CFF 0000FFFF
	v_dual_dot2acc_f32_f16 v159, v203, v15 :: v_dual_dot2acc_f32_f16 v156, v206, v2// 000000465D8C: CB181FCB 9F9C05CE
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000465D94: D6220041 03FD0141 00006400
	v_dual_dot2acc_f32_f16 v153, v203, v7 :: v_dual_dot2acc_f32_f16 v150, v206, v30// 000000465DA0: CB180FCB 99963DCE
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000465DA8: BF870214
	.long 0xd72c00cd                                           // 000000465DAC: D72C00CD
	v_cndmask_b32_e32 v1, 0x83dcd12d, v205, vcc_lo             // 000000465DB0: 02039AFF 83DCD12D
	v_dual_dot2acc_f32_f16 v159, v204, v16 :: v_dual_dot2acc_f32_f16 v156, v203, v3// 000000465DB8: CB1821CC 9F9C07CB
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000465DC0: BF870234
	v_dual_dot2acc_f32_f16 v152, v204, v24 :: v_dual_and_b32 v65, 0xffff, v65// 000000465DC4: CB2431CC 984082FF 0000FFFF
	v_bfe_u32 v207, v63, 6, 16                                 // 000000465DD0: D61000CF 02410D3F
	v_bfe_u32 v62, v62, 3, 16                                  // 000000465DD8: D610003E 0241073E
	v_dot2acc_f32_f16 v156, v204, v4                           // 000000465DE0: 053809CC
	v_sad_u8 v205, v205, 0, 0x6400                             // 000000465DE4: D62200CD 03FD01CD 00006400
	v_dot2acc_f32_f16 v148, v206, v26                          // 000000465DF0: 052835CE
	v_bfe_u32 v206, v63, 9, 16                                 // 000000465DF4: D61000CE 0241133F
	v_and_b32_e32 v63, 0xffff, v63                             // 000000465DFC: 367E7EFF 0000FFFF
	v_lshl_or_b32 v64, v64, 16, v65                            // 000000465E04: D6560040 05052140
	.long 0xd72c003e                                           // 000000465E0C: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000465E10: 02027CFF 83DCD12D
	v_dual_dot2acc_f32_f16 v153, v204, v8 :: v_dual_dot2acc_f32_f16 v150, v203, v31// 000000465E18: CB1811CC 99963FCB
	s_delay_alu instid0(VALU_DEP_4)                            // 000000465E20: BF870004
	.long 0xd72c003f                                           // 000000465E24: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000465E28: 02027EFF 83DCD12D
	.long 0xd72c00ce                                           // 000000465E30: D72C00CE
	v_cndmask_b32_e32 v1, 0x83dcd12d, v206, vcc_lo             // 000000465E34: 02039CFF 83DCD12D
	v_lshlrev_b32_e32 v205, 16, v205                           // 000000465E3C: 319B9A90
	v_pk_fma_f16 v64, v64, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000465E40: CC0E0040 0BFC0D40 0000C931
	v_dot2acc_f32_f16 v148, v203, v27                          // 000000465E4C: 052837CB
	.long 0xd72c00cb                                           // 000000465E50: D72C00CB
	v_cndmask_b32_e32 v1, 0x83dcd12d, v208, vcc_lo             // 000000465E54: 0203A0FF 83DCD12D
	.long 0xd72c00cf                                           // 000000465E5C: D72C00CF
	v_cndmask_b32_e32 v1, 0x83dcd12d, v207, vcc_lo             // 000000465E60: 02039EFF 83DCD12D
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000465E68: D622003E 03FD013E 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000465E74: D622003F 03FD013F 00006400
	v_sad_u8 v206, v206, 0, 0x6400                             // 000000465E80: D62200CE 03FD01CE 00006400
	v_dot2acc_f32_f16 v162, v64, v9                            // 000000465E8C: 05441340
	v_dot2acc_f32_f16 v161, v64, v13                           // 000000465E90: 05421B40
	v_and_or_b32 v62, 0xffff, v62, v205                        // 000000465E94: D657003E 07367CFF 0000FFFF
	v_sad_u8 v203, v203, 0, 0x6400                             // 000000465EA0: D62200CB 03FD01CB 00006400
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000465EAC: 307E7E90
	v_and_b32_e32 v65, 0xffff, v206                            // 000000465EB0: 36839CFF 0000FFFF
	v_sad_u8 v205, v207, 0, 0x6400                             // 000000465EB8: D62200CD 03FD01CF 00006400
	v_pk_fma_f16 v62, v62, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000465EC4: CC0E003E 0BFC0D3E 0000C931
	v_dot2acc_f32_f16 v157, v64, v1                            // 000000465ED0: 053A0340
	v_and_or_b32 v63, 0xffff, v203, v63                        // 000000465ED4: D657003F 04FF96FF 0000FFFF
	v_bfe_u32 v203, v58, 9, 16                                 // 000000465EE0: D61000CB 0241133A
	v_lshl_or_b32 v65, v205, 16, v65                           // 000000465EE8: D6560041 050521CD
	v_dot2acc_f32_f16 v162, v62, v10                           // 000000465EF0: 0544153E
	v_dual_dot2acc_f32_f16 v160, v64, v17 :: v_dual_dot2acc_f32_f16 v157, v62, v2// 000000465EF4: CB182340 A09C053E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000465EFC: BF8701D4
	.long 0xd72c003c                                           // 000000465F00: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v203, vcc_lo             // 000000465F04: 020396FF 83DCD12D
	v_dual_dot2acc_f32_f16 v150, v204, v32 :: v_dual_dot2acc_f32_f16 v161, v62, v14// 000000465F0C: CB1841CC 96A01D3E
	v_pk_fma_f16 v65, v65, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000465F14: CC0E0041 0BFC0D41 0000C931
	v_dot2acc_f32_f16 v148, v204, v28                          // 000000465F20: 052839CC
	v_dual_dot2acc_f32_f16 v149, v64, v25 :: v_dual_and_b32 v204, 0xffff, v58// 000000465F24: CB243340 95CC74FF 0000FFFF
	v_dual_dot2acc_f32_f16 v160, v62, v18 :: v_dual_dot2acc_f32_f16 v157, v65, v3// 000000465F30: CB18253E A09C0741
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000465F38: D622003C 03FD013C 00006400
	v_bfe_u32 v58, v58, 3, 16                                  // 000000465F44: D610003A 0241073A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000465F4C: BF870004
	.long 0xd72c00cb                                           // 000000465F50: D72C00CB
	v_cndmask_b32_e32 v1, 0x83dcd12d, v204, vcc_lo             // 000000465F54: 020398FF 83DCD12D
	v_bfe_u32 v204, v59, 9, 16                                 // 000000465F5C: D61000CC 0241133B
	v_pk_fma_f16 v63, v63, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000465F64: CC0E003F 0BFC0D3F 0000C931
	v_dual_dot2acc_f32_f16 v161, v65, v15 :: v_dual_dot2acc_f32_f16 v158, v64, v5// 000000465F70: CB181F41 A19E0B40
	v_dual_dot2acc_f32_f16 v160, v65, v19 :: v_dual_dot2acc_f32_f16 v151, v64, v29// 000000465F78: CB182741 A0963B40
	v_and_b32_e32 v60, 0xffff, v60                             // 000000465F80: 367878FF 0000FFFF
	.long 0xd72c003a                                           // 000000465F88: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000465F8C: 020274FF 83DCD12D
	.long 0xd72c00cc                                           // 000000465F94: D72C00CC
	v_cndmask_b32_e32 v1, 0x83dcd12d, v204, vcc_lo             // 000000465F98: 020398FF 83DCD12D
	v_dual_dot2acc_f32_f16 v161, v63, v16 :: v_dual_dot2acc_f32_f16 v158, v62, v6// 000000465FA0: CB18213F A19E0D3E
	v_dot2acc_f32_f16 v157, v63, v4                            // 000000465FA8: 053A093F
	v_sad_u8 v203, v203, 0, 0x6400                             // 000000465FAC: D62200CB 03FD01CB 00006400
	v_dot2acc_f32_f16 v151, v62, v30                           // 000000465FB8: 052E3D3E
	v_lshl_or_b32 v60, v61, 16, v60                            // 000000465FBC: D656003C 04F1213D
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000465FC4: D622003A 03FD013A 00006400
	v_sad_u8 v204, v204, 0, 0x6400                             // 000000465FD0: D62200CC 03FD01CC 00006400
	v_dot2acc_f32_f16 v158, v65, v7                            // 000000465FDC: 053C0F41
	v_bfe_u32 v205, v59, 6, 16                                 // 000000465FE0: D61000CD 02410D3B
	v_pk_fma_f16 v60, v60, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000465FE8: CC0E003C 0BFC0D3C 0000C931
	v_lshlrev_b32_e32 v203, 16, v203                           // 000000465FF4: 31979690
	v_bfe_u32 v206, v59, 3, 16                                 // 000000465FF8: D61000CE 0241073B
	v_and_b32_e32 v59, 0xffff, v59                             // 000000466000: 367676FF 0000FFFF
	.long 0xd72c00cd                                           // 000000466008: D72C00CD
	v_cndmask_b32_e32 v1, 0x83dcd12d, v205, vcc_lo             // 00000046600C: 02039AFF 83DCD12D
	v_dot2acc_f32_f16 v146, v60, v13                           // 000000466014: 05241B3C
	v_and_or_b32 v58, 0xffff, v58, v203                        // 000000466018: D657003A 072E74FF 0000FFFF
	v_and_b32_e32 v203, 0xffff, v204                           // 000000466024: 379798FF 0000FFFF
	v_dot2acc_f32_f16 v158, v63, v8                            // 00000046602C: 053C113F
	.long 0xd72c003b                                           // 000000466030: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000466034: 020276FF 83DCD12D
	.long 0xd72c003d                                           // 00000046603C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v206, vcc_lo             // 000000466040: 02039CFF 83DCD12D
	v_dual_dot2acc_f32_f16 v162, v65, v11 :: v_dual_dot2acc_f32_f16 v155, v64, v21// 000000466048: CB181741 A29A2B40
	v_sad_u8 v204, v205, 0, 0x6400                             // 000000466050: D62200CC 03FD01CD 00006400
	v_pk_fma_f16 v58, v58, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000046605C: CC0E003A 0BFC0D3A 0000C931
	v_dual_dot2acc_f32_f16 v149, v62, v26 :: v_dual_dot2acc_f32_f16 v144, v60, v5// 000000466068: CB18353E 95900B3C
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000466070: D622003B 03FD013B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000046607C: BF870234
	v_lshl_or_b32 v64, v204, 16, v203                          // 000000466080: D6560040 072D21CC
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000466088: D622003D 03FD013D 00006400
	v_dual_dot2acc_f32_f16 v162, v63, v12 :: v_dual_dot2acc_f32_f16 v155, v62, v22// 000000466094: CB18193F A29A2D3E
	v_dual_dot2acc_f32_f16 v146, v58, v14 :: v_dual_lshlrev_b32 v59, 16, v59// 00000046609C: CB221D3A 923A7690
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004660A4: BF870224
	v_pk_fma_f16 v62, v64, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004660A8: CC0E003E 0BFC0D40 0000C931
	v_dual_dot2acc_f32_f16 v147, v60, v9 :: v_dual_dot2acc_f32_f16 v160, v63, v20// 0000004660B4: CB18133C 93A0293F
	v_dot2acc_f32_f16 v155, v65, v23                           // 0000004660BC: 05362F41
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004660C0: BF870244
	v_and_or_b32 v59, 0xffff, v61, v59                         // 0000004660C4: D657003B 04EE7AFF 0000FFFF
	v_dual_dot2acc_f32_f16 v149, v65, v27 :: v_dual_dot2acc_f32_f16 v144, v58, v6// 0000004660D0: CB183741 95900D3A
	v_dot2acc_f32_f16 v146, v62, v15                           // 0000004660D8: 05241F3E
	v_dual_dot2acc_f32_f16 v147, v58, v10 :: v_dual_dot2acc_f32_f16 v142, v60, v21// 0000004660DC: CB18153A 938E2B3C
	v_pk_fma_f16 v59, v59, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004660E4: CC0E003B 0BFC0D3B 0000C931
	v_dot2acc_f32_f16 v151, v65, v31                           // 0000004660F0: 052E3F41
	v_bfe_u32 v61, v54, 9, 16                                  // 0000004660F4: D610003D 02411336
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004660FC: BF870214
	v_dual_dot2acc_f32_f16 v155, v63, v24 :: v_dual_dot2acc_f32_f16 v142, v58, v22// 000000466100: CB18313F 9B8E2D3A
	v_dot2acc_f32_f16 v146, v59, v16                           // 000000466108: 0524213B
	s_delay_alu instid0(VALU_DEP_4)                            // 00000046610C: BF870004
	v_dual_dot2acc_f32_f16 v151, v63, v32 :: v_dual_dot2acc_f32_f16 v144, v62, v7// 000000466110: CB18413F 97900F3E
	v_dot2acc_f32_f16 v147, v62, v11                           // 000000466118: 0526173E
	.long 0xd72c0039                                           // 00000046611C: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000466120: 02027AFF 83DCD12D
	v_dual_dot2acc_f32_f16 v149, v63, v28 :: v_dual_dot2acc_f32_f16 v142, v62, v23// 000000466128: CB18393F 958E2F3E
	v_dot2acc_f32_f16 v145, v60, v17                           // 000000466130: 0522233C
	v_dual_dot2acc_f32_f16 v143, v60, v1 :: v_dual_dot2acc_f32_f16 v144, v59, v8// 000000466134: CB18033C 8F90113B
	v_dual_dot2acc_f32_f16 v147, v59, v12 :: v_dual_dot2acc_f32_f16 v140, v60, v25// 00000046613C: CB18193B 938C333C
	v_dual_dot2acc_f32_f16 v141, v60, v29 :: v_dual_and_b32 v60, 0xffff, v54// 000000466144: CB243B3C 8D3C6CFF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000466150: D6220039 03FD0139 00006400
	v_bfe_u32 v54, v54, 3, 16                                  // 00000046615C: D6100036 02410736
	v_dot2acc_f32_f16 v142, v59, v24                           // 000000466164: 051C313B
	v_dot2acc_f32_f16 v140, v58, v26                           // 000000466168: 0518353A
	.long 0xd72c003c                                           // 00000046616C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000466170: 020278FF 83DCD12D
	v_and_b32_e32 v57, 0xffff, v57                             // 000000466178: 367272FF 0000FFFF
	.long 0xd72c0036                                           // 000000466180: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000466184: 02026CFF 83DCD12D
	v_bfe_u32 v61, v55, 6, 16                                  // 00000046618C: D610003D 02410D37
	v_dot2acc_f32_f16 v140, v62, v27                           // 000000466194: 0518373E
	v_dot2acc_f32_f16 v143, v58, v2                            // 000000466198: 051E053A
	v_lshl_or_b32 v56, v56, 16, v57                            // 00000046619C: D6560038 04E52138
	v_bfe_u32 v63, v55, 3, 16                                  // 0000004661A4: D610003F 02410737
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000004661AC: D622003C 03FD013C 00006400
	v_dot2acc_f32_f16 v145, v58, v18                           // 0000004661B8: 0522253A
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000004661BC: D6220036 03FD0136 00006400
	v_pk_fma_f16 v56, v56, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004661C8: CC0E0038 0BFC0D38 0000C931
	v_dot2acc_f32_f16 v140, v59, v28                           // 0000004661D4: 0518393B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004661D8: BF870194
	v_dual_dot2acc_f32_f16 v145, v62, v19 :: v_dual_lshlrev_b32 v60, 16, v60// 0000004661DC: CB22273E 913C7890
	v_dual_dot2acc_f32_f16 v143, v62, v3 :: v_dual_dot2acc_f32_f16 v136, v56, v5// 0000004661E4: CB18073E 8F880B38
	v_dot2acc_f32_f16 v138, v56, v13                           // 0000004661EC: 05141B38
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004661F0: BF870213
	v_and_or_b32 v54, 0xffff, v54, v60                         // 0000004661F4: D6570036 04F26CFF 0000FFFF
	v_dot2acc_f32_f16 v145, v59, v20                           // 000000466200: 0522293B
	.long 0xd72c003d                                           // 000000466204: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000466208: 02027AFF 83DCD12D
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000466210: D622002D 03FD012D 00006400
	v_sad_u8 v40, v40, 0, 0x6400                               // 00000046621C: D6220028 03FD0128 00006400
	v_pk_fma_f16 v54, v54, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000466228: CC0E0036 0BFC0D36 0000C931
	v_dot2acc_f32_f16 v143, v59, v4                            // 000000466234: 051E093B
	v_add_nc_u32_e32 v165, 1, v165                             // 000000466238: 4B4B4A81
	v_add_nc_u32_e32 v167, 32, v167                            // 00000046623C: 4B4F4EA0
	s_delay_alu instid0(VALU_DEP_4)                            // 000000466240: BF870004
	v_dual_mov_b32 v65, v196 :: v_dual_dot2acc_f32_f16 v138, v54, v14// 000000466244: CA1801C4 418A1D36
	v_dot2acc_f32_f16 v141, v58, v30                           // 00000046624C: 051A3D3A
	v_bfe_u32 v58, v55, 9, 16                                  // 000000466250: D610003A 02411337
	v_dual_dot2acc_f32_f16 v136, v54, v6 :: v_dual_and_b32 v55, 0xffff, v55// 000000466258: CB240D36 88366EFF 0000FFFF
	v_dot2acc_f32_f16 v134, v56, v21                           // 000000466264: 050C2B38
	v_dot2acc_f32_f16 v132, v56, v25                           // 000000466268: 05083338
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000046626C: BF870214
	.long 0xd72c003a                                           // 000000466270: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000466274: 020274FF 83DCD12D
	.long 0xd72c0037                                           // 00000046627C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000466280: 02026EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000466288: BF870214
	v_dual_dot2acc_f32_f16 v135, v56, v1 :: v_dual_dot2acc_f32_f16 v134, v54, v22// 00000046628C: CB180338 87862D36
	v_dot2acc_f32_f16 v132, v54, v26                           // 000000466294: 05083536
	v_and_b32_e32 v48, 0xffff, v46                             // 000000466298: 36605CFF 0000FFFF
	v_mov_b32_e32 v64, v195                                    // 0000004662A0: 7E8003C3
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000004662A4: D622003A 03FD013A 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000004662B0: D6220037 03FD0137 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004662BC: BF870194
	.long 0xd72c0030                                           // 0000004662C0: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 0000004662C4: 020260FF 83DCD12D
	v_and_b32_e32 v57, 0xffff, v58                             // 0000004662CC: 367274FF 0000FFFF
	v_sad_u8 v58, v61, 0, 0x6400                               // 0000004662D4: D622003A 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004662E0: BF870234
	v_lshlrev_b32_e32 v55, 16, v55                             // 0000004662E4: 306E6E90
	v_bfe_u32 v61, v51, 3, 16                                  // 0000004662E8: D610003D 02410733
	v_sad_u8 v48, v48, 0, 0x6400                               // 0000004662F0: D6220030 03FD0130 00006400
	v_lshl_or_b32 v57, v58, 16, v57                            // 0000004662FC: D6560039 04E5213A
	v_bfe_u32 v58, v50, 9, 16                                  // 000000466304: D610003A 02411332
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000046630C: BF870193
	v_lshlrev_b32_e32 v48, 16, v48                             // 000000466310: 30606090
	v_pk_fma_f16 v57, v57, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000466314: CC0E0039 0BFC0D39 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000466320: BF870113
	.long 0xd72c0034                                           // 000000466324: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000466328: 020274FF 83DCD12D
	v_dual_dot2acc_f32_f16 v139, v56, v9 :: v_dual_dot2acc_f32_f16 v136, v57, v7// 000000466330: CB181338 8B880F39
	v_dot2acc_f32_f16 v138, v57, v15                           // 000000466338: 05141F39
	v_dot2acc_f32_f16 v141, v62, v31                           // 00000046633C: 051A3F3E
	.long 0xd72c003e                                           // 000000466340: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000466344: 02027EFF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 00000046634C: D6220034 03FD0134 00006400
	v_dual_dot2acc_f32_f16 v139, v54, v10 :: v_dual_dot2acc_f32_f16 v132, v57, v27// 000000466358: CB181536 8B843739
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000466360: BF870114
	v_dual_dot2acc_f32_f16 v141, v59, v32 :: v_dual_dot2acc_f32_f16 v134, v57, v23// 000000466364: CB18413B 8D862F39
	v_dual_dot2acc_f32_f16 v139, v57, v11 :: v_dual_and_b32 v52, 0xffff, v52// 00000046636C: CB241739 8B3468FF 0000FFFF
	v_sad_u8 v60, v62, 0, 0x6400                               // 000000466378: D622003C 03FD013E 00006400
	v_dual_mov_b32 v63, v198 :: v_dual_mov_b32 v62, v197       // 000000466384: CA1001C6 3F3E01C5
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000046638C: BF870223
	v_lshl_or_b32 v52, v53, 16, v52                            // 000000466390: D6560034 04D12135
	.long 0xd72c0035                                           // 000000466398: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 00000046639C: 02027AFF 83DCD12D
	v_and_or_b32 v55, 0xffff, v60, v55                         // 0000004663A4: D6570037 04DE78FF 0000FFFF
	v_bfe_u32 v60, v51, 6, 16                                  // 0000004663B0: D610003C 02410D33
	v_mov_b32_e32 v61, v192                                    // 0000004663B8: 7E7A03C0
	v_pk_fma_f16 v52, v52, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004663BC: CC0E0034 0BFC0D34 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004663C8: BF870234
	v_pk_fma_f16 v55, v55, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004663CC: CC0E0037 0BFC0D37 0000C931
	v_and_b32_e32 v59, 0xffff, v50                             // 0000004663D8: 367664FF 0000FFFF
	v_bfe_u32 v50, v50, 3, 16                                  // 0000004663E0: D6100032 02410732
	v_dot2acc_f32_f16 v126, v52, v21                           // 0000004663E8: 04FC2B34
	.long 0xd72c003c                                           // 0000004663EC: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000004663F0: 020278FF 83DCD12D
	v_dot2acc_f32_f16 v139, v55, v12                           // 0000004663F8: 05161937
	v_dot2acc_f32_f16 v132, v55, v28                           // 0000004663FC: 05083937
	.long 0xd72c003a                                           // 000000466400: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000466404: 020276FF 83DCD12D
	v_bfe_u32 v59, v51, 9, 16                                  // 00000046640C: D610003B 02411333
	.long 0xd72c0032                                           // 000000466414: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000466418: 020264FF 83DCD12D
	v_and_b32_e32 v51, 0xffff, v51                             // 000000466420: 366666FF 0000FFFF
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000466428: D6220035 03FD0135 00006400
	v_dot2acc_f32_f16 v130, v52, v13                           // 000000466434: 05041B34
	.long 0xd72c003b                                           // 000000466438: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 00000046643C: 020276FF 83DCD12D
	v_dot2acc_f32_f16 v128, v52, v5                            // 000000466444: 05000B34
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000466448: D622003A 03FD013A 00006400
	.long 0xd72c0033                                           // 000000466454: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000466458: 020266FF 83DCD12D
	v_dot2acc_f32_f16 v137, v56, v17                           // 000000466460: 05122338
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000466464: D6220032 03FD0132 00006400
	v_dual_dot2acc_f32_f16 v135, v54, v2 :: v_dual_dot2acc_f32_f16 v134, v55, v24// 000000466470: CB180536 87863137
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000466478: 30747490
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000046647C: D622003B 03FD013B 00006400
	v_dot2acc_f32_f16 v137, v54, v18                           // 000000466488: 05122536
	v_sad_u8 v51, v51, 0, 0x6400                               // 00000046648C: D6220033 03FD0133 00006400
	v_dot2acc_f32_f16 v124, v52, v25                           // 000000466498: 04F83334
	v_and_or_b32 v50, 0xffff, v50, v58                         // 00000046649C: D6570032 04EA64FF 0000FFFF
	v_and_b32_e32 v58, 0xffff, v59                             // 0000004664A8: 367476FF 0000FFFF
	v_dot2acc_f32_f16 v137, v57, v19                           // 0000004664B0: 05122739
	v_sad_u8 v59, v60, 0, 0x6400                               // 0000004664B4: D622003B 03FD013C 00006400
	v_dot2acc_f32_f16 v127, v52, v1                            // 0000004664C0: 04FE0334
	v_pk_fma_f16 v50, v50, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004664C4: CC0E0032 0BFC0D32 0000C931
	v_lshlrev_b32_e32 v51, 16, v51                             // 0000004664D0: 30666690
	v_dot2acc_f32_f16 v137, v55, v20                           // 0000004664D4: 05122937
	v_dot2acc_f32_f16 v133, v56, v29                           // 0000004664D8: 050A3B38
	v_lshl_or_b32 v56, v59, 16, v58                            // 0000004664DC: D6560038 04E9213B
	v_dot2acc_f32_f16 v126, v50, v22                           // 0000004664E4: 04FC2D32
	v_and_or_b32 v51, 0xffff, v53, v51                         // 0000004664E8: D6570033 04CE6AFF 0000FFFF
	v_dual_dot2acc_f32_f16 v128, v50, v6 :: v_dual_dot2acc_f32_f16 v135, v57, v3// 0000004664F4: CB180D32 80860739
	v_dot2acc_f32_f16 v130, v50, v14                           // 0000004664FC: 05041D32
	v_bfe_u32 v53, v46, 9, 16                                  // 000000466500: D6100035 0241132E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000466508: BF870004
	v_pk_fma_f16 v51, v51, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000046650C: CC0E0033 0BFC0D33 0000C931
	v_dot2acc_f32_f16 v133, v54, v30                           // 000000466518: 050A3D36
	v_pk_fma_f16 v54, v56, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000046651C: CC0E0036 0BFC0D38 0000C931
	v_dot2acc_f32_f16 v129, v52, v17                           // 000000466528: 05022334
	v_dot2acc_f32_f16 v135, v55, v4                            // 00000046652C: 050E0937
	.long 0xd72c0031                                           // 000000466530: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000466534: 02026AFF 83DCD12D
	v_dot2acc_f32_f16 v124, v50, v26                           // 00000046653C: 04F83532
	v_dot2acc_f32_f16 v128, v54, v7                            // 000000466540: 05000F36
	v_dual_dot2acc_f32_f16 v130, v54, v15 :: v_dual_dot2acc_f32_f16 v131, v52, v9// 000000466544: CB181F36 82821334
	v_dual_dot2acc_f32_f16 v126, v54, v23 :: v_dual_dot2acc_f32_f16 v125, v52, v29// 00000046654C: CB182F36 7E7C3B34
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000466554: BF870214
	v_dot2acc_f32_f16 v124, v54, v27                           // 000000466558: 04F83736
	v_dual_dot2acc_f32_f16 v128, v51, v8 :: v_dual_dot2acc_f32_f16 v133, v57, v31// 00000046655C: CB181133 80843F39
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000466564: BF870214
	v_dual_dot2acc_f32_f16 v130, v51, v16 :: v_dual_dot2acc_f32_f16 v131, v50, v10// 000000466568: CB182133 82821532
	v_dot2acc_f32_f16 v126, v51, v24                           // 000000466570: 04FC3133
	v_bfe_u32 v52, v46, 6, 16                                  // 000000466574: D6100034 02410D2E
	s_delay_alu instid0(VALU_DEP_4)                            // 00000046657C: BF870004
	v_dot2acc_f32_f16 v133, v55, v32                           // 000000466580: 050A4137
	v_bfe_u32 v46, v46, 3, 16                                  // 000000466584: D610002E 0241072E
	v_dot2acc_f32_f16 v131, v54, v11                           // 00000046658C: 05061736
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000466590: D6220031 03FD0131 00006400
	.long 0xd72c0034                                           // 00000046659C: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000004665A0: 020268FF 83DCD12D
	v_bfe_u32 v53, v47, 9, 16                                  // 0000004665A8: D6100035 0241132F
	.long 0xd72c002e                                           // 0000004665B0: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000004665B4: 02025CFF 83DCD12D
	v_dot2acc_f32_f16 v131, v51, v12                           // 0000004665BC: 05061933
	v_dual_dot2acc_f32_f16 v138, v55, v16 :: v_dual_and_b32 v49, 0xffff, v49// 0000004665C0: CB242137 8A3062FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004665CC: BF870004
	.long 0xd72c0035                                           // 0000004665D0: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000004665D4: 02026AFF 83DCD12D
	v_dot2acc_f32_f16 v136, v55, v8                            // 0000004665DC: 05101137
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000004665E0: D6220034 03FD0134 00006400
	v_bfe_u32 v55, v47, 6, 16                                  // 0000004665EC: D6100037 02410D2F
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000004665F4: D622002E 03FD012E 00006400
	v_dual_dot2acc_f32_f16 v127, v50, v2 :: v_dual_dot2acc_f32_f16 v124, v51, v28// 000000466600: CB180532 7F7C3933
	s_delay_alu instid0(VALU_DEP_4)                            // 000000466608: BF870004
	v_lshl_or_b32 v49, v52, 16, v49                            // 00000046660C: D6560031 04C52134
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000466614: D6220035 03FD0135 00006400
	v_dot2acc_f32_f16 v129, v50, v18                           // 000000466620: 05022532
	v_and_or_b32 v46, 0xffff, v46, v48                         // 000000466624: D657002E 04C25CFF 0000FFFF
	.long 0xd72c0037                                           // 000000466630: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000466634: 02026EFF 83DCD12D
	v_pk_fma_f16 v49, v49, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000046663C: CC0E0031 0BFC0D31 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000466648: BF870214
	v_dual_dot2acc_f32_f16 v129, v54, v19 :: v_dual_and_b32 v48, 0xffff, v53// 00000046664C: CB242736 81306AFF 0000FFFF
	v_pk_fma_f16 v46, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000466658: CC0E002E 0BFC0D2E 0000C931
	v_bfe_u32 v56, v47, 3, 16                                  // 000000466664: D6100038 0241072F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000046666C: BF870214
	v_dot2acc_f32_f16 v122, v49, v13                           // 000000466670: 04F41B31
	v_dual_dot2acc_f32_f16 v118, v49, v21 :: v_dual_dot2acc_f32_f16 v129, v51, v20// 000000466674: CB182B31 76802933
	v_and_b32_e32 v47, 0xffff, v47                             // 00000046667C: 365E5EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000466684: BF870214
	.long 0xd72c0038                                           // 000000466688: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 00000046668C: 020270FF 83DCD12D
	v_dot2acc_f32_f16 v122, v46, v14                           // 000000466694: 04F41D2E
	v_dot2acc_f32_f16 v125, v50, v30                           // 000000466698: 04FA3D32
	v_sad_u8 v50, v55, 0, 0x6400                               // 00000046669C: D6220032 03FD0137 00006400
	v_dot2acc_f32_f16 v118, v46, v22                           // 0000004666A8: 04EC2D2E
	.long 0xd72c002f                                           // 0000004666AC: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000004666B0: 02025EFF 83DCD12D
	v_dual_dot2acc_f32_f16 v127, v54, v3 :: v_dual_dot2acc_f32_f16 v120, v49, v5// 0000004666B8: CB180736 7F780B31
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004666C0: BF870234
	v_lshl_or_b32 v48, v50, 16, v48                            // 0000004666C4: D6560030 04C12132
	v_bfe_u32 v50, v42, 9, 16                                  // 0000004666CC: D6100032 0241132A
	v_sad_u8 v52, v56, 0, 0x6400                               // 0000004666D4: D6220034 03FD0138 00006400
	v_dual_dot2acc_f32_f16 v127, v51, v4 :: v_dual_dot2acc_f32_f16 v120, v46, v6// 0000004666E0: CB180933 7F780D2E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004666E8: BF870214
	v_pk_fma_f16 v48, v48, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004666EC: CC0E0030 0BFC0D30 0000C931
	.long 0xd72c002c                                           // 0000004666F8: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000004666FC: 020264FF 83DCD12D
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000466704: D622002F 03FD012F 00006400
	v_bfe_u32 v53, v43, 3, 16                                  // 000000466710: D6100035 0241072B
	v_mov_b32_e32 v56, v187                                    // 000000466718: 7E7003BB
	v_dot2acc_f32_f16 v122, v48, v15                           // 00000046671C: 04F41F30
	v_dot2acc_f32_f16 v125, v54, v31                           // 000000466720: 04FA3F36
	v_dot2acc_f32_f16 v120, v48, v7                            // 000000466724: 04F00F30
	v_dot2acc_f32_f16 v118, v48, v23                           // 000000466728: 04EC2F30
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000046672C: D622002C 03FD012C 00006400
	v_dot2acc_f32_f16 v121, v49, v17                           // 000000466738: 04F22331
	v_dot2acc_f32_f16 v125, v51, v32                           // 00000046673C: 04FA4133
	v_and_b32_e32 v51, 0xffff, v42                             // 000000466740: 366654FF 0000FFFF
	v_bfe_u32 v42, v42, 3, 16                                  // 000000466748: D610002A 0241072A
	v_and_b32_e32 v44, 0xffff, v44                             // 000000466750: 365858FF 0000FFFF
	v_dual_mov_b32 v60, v191 :: v_dual_mov_b32 v59, v194       // 000000466758: CA1001BF 3C3A01C2
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000466760: BF870224
	.long 0xd72c0032                                           // 000000466764: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000466768: 020266FF 83DCD12D
	v_bfe_u32 v51, v43, 9, 16                                  // 000000466770: D6100033 0241132B
	v_lshl_or_b32 v44, v45, 16, v44                            // 000000466778: D656002C 04B1212D
	.long 0xd72c002d                                           // 000000466780: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000466784: 02026AFF 83DCD12D
	.long 0xd72c002a                                           // 00000046678C: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000466790: 020254FF 83DCD12D
	v_mov_b32_e32 v58, v193                                    // 000000466798: 7E7403C1
	.long 0xd72c0033                                           // 00000046679C: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000004667A0: 020266FF 83DCD12D
	v_pk_fma_f16 v44, v44, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004667A8: CC0E002C 0BFC0D2C 0000C931
	v_lshlrev_b32_e32 v47, 16, v47                             // 0000004667B4: 305E5E90
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000004667B8: D6220032 03FD0132 00006400
	v_dot2acc_f32_f16 v121, v46, v18                           // 0000004667C4: 04F2252E
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000004667C8: D622002D 03FD012D 00006400
	v_dot2acc_f32_f16 v114, v44, v9                            // 0000004667D4: 04E4132C
	v_and_or_b32 v47, 0xffff, v52, v47                         // 0000004667D8: D657002F 04BE68FF 0000FFFF
	v_bfe_u32 v52, v43, 6, 16                                  // 0000004667E4: D6100034 02410D2B
	v_dual_dot2acc_f32_f16 v106, v44, v1 :: v_dual_and_b32 v43, 0xffff, v43// 0000004667EC: CB24032C 6A2A56FF 0000FFFF
	v_dot2acc_f32_f16 v98, v44, v25                            // 0000004667F8: 04C4332C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004667FC: BF870224
	v_pk_fma_f16 v47, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000466800: CC0E002F 0BFC0D2F 0000C931
	v_dot2acc_f32_f16 v123, v49, v9                            // 00000046680C: 04F61331
	.long 0xd72c002b                                           // 000000466810: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000466814: 020256FF 83DCD12D
	v_sad_u8 v42, v42, 0, 0x6400                               // 00000046681C: D622002A 03FD012A 00006400
	v_lshlrev_b32_e32 v50, 16, v50                             // 000000466828: 30646490
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000046682C: BF870234
	v_dual_dot2acc_f32_f16 v122, v47, v16 :: v_dual_dot2acc_f32_f16 v123, v46, v10// 000000466830: CB18212F 7A7A152E
	v_dot2acc_f32_f16 v120, v47, v8                            // 000000466838: 04F0112F
	.long 0xd72c0034                                           // 00000046683C: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000466840: 020268FF 83DCD12D
	v_and_or_b32 v42, 0xffff, v42, v50                         // 000000466848: D657002A 04CA54FF 0000FFFF
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000466854: D622002B 03FD012B 00006400
	v_dot2acc_f32_f16 v123, v48, v11                           // 000000466860: 04F61730
	v_dot2acc_f32_f16 v103, v44, v21                           // 000000466864: 04CE2B2C
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000466868: D6220033 03FD0133 00006400
	v_pk_fma_f16 v42, v42, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000466874: CC0E002A 0BFC0D2A 0000C931
	v_dual_dot2acc_f32_f16 v112, v44, v13 :: v_dual_lshlrev_b32 v43, 16, v43// 000000466880: CB221B2C 702A5690
	v_dot2acc_f32_f16 v111, v44, v17                           // 000000466888: 04DE232C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000046688C: BF870194
	v_dual_dot2acc_f32_f16 v119, v49, v1 :: v_dual_and_b32 v50, 0xffff, v51// 000000466890: CB240331 773266FF 0000FFFF
	v_and_or_b32 v43, 0xffff, v45, v43                         // 00000046689C: D657002B 04AE5AFF 0000FFFF
	v_bfe_u32 v45, v38, 9, 16                                  // 0000004668A8: D610002D 02411326
	v_sad_u8 v51, v52, 0, 0x6400                               // 0000004668B0: D6220033 03FD0134 00006400
	v_dual_dot2acc_f32_f16 v117, v49, v29 :: v_dual_dot2acc_f32_f16 v106, v42, v2// 0000004668BC: CB183B31 756A052A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004668C4: BF870214
	v_pk_fma_f16 v43, v43, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004668C8: CC0E002B 0BFC0D2B 0000C931
	.long 0xd72c0029                                           // 0000004668D4: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000004668D8: 02025AFF 83DCD12D
	v_dot2acc_f32_f16 v109, v44, v5                            // 0000004668E0: 04DA0B2C
	v_dot2acc_f32_f16 v115, v49, v25                           // 0000004668E4: 04E63331
	v_lshl_or_b32 v49, v51, 16, v50                            // 0000004668E8: D6560031 04C92133
	v_dual_dot2acc_f32_f16 v119, v46, v2 :: v_dual_dot2acc_f32_f16 v118, v47, v24// 0000004668F0: CB18052E 7776312F
	v_dot2acc_f32_f16 v117, v46, v30                           // 0000004668F8: 04EA3D2E
	v_dot2acc_f32_f16 v98, v42, v26                            // 0000004668FC: 04C4352A
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000466900: D6220029 03FD0129 00006400
	v_dual_dot2acc_f32_f16 v123, v47, v12 :: v_dual_dot2acc_f32_f16 v114, v42, v10// 00000046690C: CB18192F 7B72152A
	v_dual_dot2acc_f32_f16 v121, v48, v19 :: v_dual_dot2acc_f32_f16 v112, v42, v14// 000000466914: CB182730 79701D2A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000046691C: BF870243
	v_and_b32_e32 v41, 0xffff, v41                             // 000000466920: 365252FF 0000FFFF
	v_bfe_u32 v45, v39, 6, 16                                  // 000000466928: D610002D 02410D27
	v_dual_mov_b32 v52, v183 :: v_dual_mov_b32 v55, v190       // 000000466930: CA1001B7 343601BE
	v_mov_b32_e32 v57, v188                                    // 000000466938: 7E7203BC
	v_lshl_or_b32 v40, v40, 16, v41                            // 00000046693C: D6560028 04A52128
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000466944: BF870234
	.long 0xd72c002d                                           // 000000466948: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 00000046694C: 02025AFF 83DCD12D
	v_dual_mov_b32 v51, v186 :: v_dual_mov_b32 v50, v185       // 000000466954: CA1001BA 333201B9
	v_mov_b32_e32 v53, v184                                    // 00000046695C: 7E6A03B8
	v_pk_fma_f16 v40, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000466960: CC0E0028 0BFC0D28 0000C931
	v_dual_dot2acc_f32_f16 v103, v42, v22 :: v_dual_mov_b32 v54, v189// 00000046696C: CB102D2A 673601BD
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000466974: BF870252
	v_dot2acc_f32_f16 v86, v40, v29                            // 000000466978: 04AC3B28
	v_dual_dot2acc_f32_f16 v101, v44, v29 :: v_dual_and_b32 v44, 0xffff, v38// 00000046697C: CB243B2C 652C4CFF 0000FFFF
	v_bfe_u32 v38, v38, 3, 16                                  // 000000466988: D6100026 02410726
	v_dual_dot2acc_f32_f16 v111, v42, v18 :: v_dual_dot2acc_f32_f16 v92, v40, v17// 000000466990: CB18252A 6F5C2328
	v_dot2acc_f32_f16 v95, v40, v13                            // 000000466998: 04BE1B28
	.long 0xd72c002c                                           // 00000046699C: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000004669A0: 020258FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004669A8: BF870004
	.long 0xd72c0026                                           // 0000004669AC: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 0000004669B0: 02024CFF 83DCD12D
	v_dot2acc_f32_f16 v97, v40, v9                             // 0000004669B8: 04C21328
	v_dot2acc_f32_f16 v91, v40, v5                             // 0000004669BC: 04B60B28
	v_dot2acc_f32_f16 v89, v40, v1                             // 0000004669C0: 04B20328
	v_dot2acc_f32_f16 v87, v40, v21                            // 0000004669C4: 04AE2B28
	v_dot2acc_f32_f16 v33, v40, v25                            // 0000004669C8: 04423328
	v_add_nc_u32_e32 v1, v164, v165                            // 0000004669CC: 4A034BA4
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000004669D0: D622002C 03FD012C 00006400
	v_dot2acc_f32_f16 v115, v46, v26                           // 0000004669DC: 04E6352E
	v_pk_fma_f16 v46, v49, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004669E0: CC0E002E 0BFC0D31 0000C931
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000004669EC: D6220026 03FD0126 00006400
	v_dot2acc_f32_f16 v121, v47, v20                           // 0000004669F8: 04F2292F
	v_lshlrev_b32_e32 v44, 16, v44                             // 0000004669FC: 30585890
	v_cmp_eq_u32_e32 vcc_lo, 2, v1                             // 000000466A00: 7C940282
	v_dot2acc_f32_f16 v106, v46, v3                            // 000000466A04: 04D4072E
	v_dot2acc_f32_f16 v98, v46, v27                            // 000000466A08: 04C4372E
	v_dot2acc_f32_f16 v114, v46, v11                           // 000000466A0C: 04E4172E
	v_and_or_b32 v38, 0xffff, v38, v44                         // 000000466A10: D6570026 04B24CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000466A1C: BF870214
	v_dual_dot2acc_f32_f16 v119, v48, v3 :: v_dual_dot2acc_f32_f16 v106, v43, v4// 000000466A20: CB180730 776A092B
	v_dual_dot2acc_f32_f16 v117, v48, v31 :: v_dual_dot2acc_f32_f16 v98, v43, v28// 000000466A28: CB183F30 7562392B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000466A30: BF8701A3
	v_pk_fma_f16 v38, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000466A34: CC0E0026 0BFC0D26 0000C931
	v_dual_dot2acc_f32_f16 v115, v48, v27 :: v_dual_dot2acc_f32_f16 v114, v43, v12// 000000466A40: CB183730 7372192B
	v_dot2acc_f32_f16 v117, v47, v32                           // 000000466A48: 04EA412F
	v_dual_dot2acc_f32_f16 v119, v47, v4 :: v_dual_dot2acc_f32_f16 v112, v46, v15// 000000466A4C: CB18092F 77701F2E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000466A54: BF870004
	v_dot2acc_f32_f16 v86, v38, v30                            // 000000466A58: 04AC3D26
	v_dot2acc_f32_f16 v109, v42, v6                            // 000000466A5C: 04DA0D2A
	v_dot2acc_f32_f16 v101, v42, v30                           // 000000466A60: 04CA3D2A
	v_bfe_u32 v42, v39, 9, 16                                  // 000000466A64: D610002A 02411327
	v_dot2acc_f32_f16 v92, v38, v18                            // 000000466A6C: 04B82526
	v_dot2acc_f32_f16 v111, v46, v19                           // 000000466A70: 04DE272E
	v_dot2acc_f32_f16 v103, v46, v23                           // 000000466A74: 04CE2F2E
	v_dot2acc_f32_f16 v101, v46, v31                           // 000000466A78: 04CA3F2E
	.long 0xd72c002a                                           // 000000466A7C: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000466A80: 020254FF 83DCD12D
	v_dot2acc_f32_f16 v91, v38, v6                             // 000000466A88: 04B60D26
	v_dot2acc_f32_f16 v89, v38, v2                             // 000000466A8C: 04B20526
	v_dot2acc_f32_f16 v87, v38, v22                            // 000000466A90: 04AE2D26
	v_dual_dot2acc_f32_f16 v33, v38, v26 :: v_dual_dot2acc_f32_f16 v112, v43, v16// 000000466A94: CB183526 2170212B
	v_dot2acc_f32_f16 v103, v43, v24                           // 000000466A9C: 04CE312B
	v_dot2acc_f32_f16 v101, v43, v32                           // 000000466AA0: 04CA412B
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000466AA4: D622002A 03FD012A 00006400
	v_mov_b32_e32 v1, v201                                     // 000000466AB0: 7E0203C9
	v_mov_b32_e32 v49, v180                                    // 000000466AB4: 7E6203B4
	s_or_b32 s0, vcc_lo, s0                                    // 000000466AB8: 8C00006A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000466ABC: BF8701C3
	v_dual_mov_b32 v48, v179 :: v_dual_and_b32 v41, 0xffff, v42// 000000466AC0: CA2401B3 302854FF 0000FFFF
	v_sad_u8 v42, v45, 0, 0x6400                               // 000000466ACC: D622002A 03FD012D 00006400
	v_dual_mov_b32 v45, v176 :: v_dual_mov_b32 v40, v171       // 000000466AD8: CA1001B0 2D2801AB
	v_mov_b32_e32 v2, v202                                     // 000000466AE0: 7E0403CA
	v_lshl_or_b32 v41, v42, 16, v41                            // 000000466AE4: D6560029 04A5212A
	v_dual_mov_b32 v42, v177 :: v_dual_dot2acc_f32_f16 v97, v38, v10// 000000466AEC: CA1801B1 2A601526
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000466AF4: BF870242
	v_pk_fma_f16 v13, v41, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000466AF8: CC0E000D 0BFC0D29 0000C931
	v_dot2acc_f32_f16 v115, v47, v28                           // 000000466B04: 04E6392F
	v_bfe_u32 v47, v39, 3, 16                                  // 000000466B08: D610002F 02410727
	v_and_b32_e32 v39, 0xffff, v39                             // 000000466B10: 364E4EFF 0000FFFF
	v_dual_mov_b32 v41, v172 :: v_dual_dot2acc_f32_f16 v86, v13, v31// 000000466B18: CA1801AC 29563F0D
	v_dot2acc_f32_f16 v109, v46, v7                            // 000000466B20: 04DA0F2E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000466B24: BF870214
	.long 0xd72c002e                                           // 000000466B28: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000466B2C: 02025EFF 83DCD12D
	.long 0xd72c0027                                           // 000000466B34: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000466B38: 02024EFF 83DCD12D
	v_dot2acc_f32_f16 v92, v13, v19                            // 000000466B40: 04B8270D
	v_dot2acc_f32_f16 v91, v13, v7                             // 000000466B44: 04B60F0D
	v_dot2acc_f32_f16 v89, v13, v3                             // 000000466B48: 04B2070D
	v_dot2acc_f32_f16 v87, v13, v23                            // 000000466B4C: 04AE2F0D
	v_dot2acc_f32_f16 v33, v13, v27                            // 000000466B50: 0442370D
	v_dot2acc_f32_f16 v109, v43, v8                            // 000000466B54: 04DA112B
	v_sad_u8 v44, v46, 0, 0x6400                               // 000000466B58: D622002C 03FD012E 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000466B64: D6220027 03FD0127 00006400
	v_mov_b32_e32 v3, v199                                     // 000000466B70: 7E0603C7
	v_dual_mov_b32 v47, v182 :: v_dual_mov_b32 v46, v181       // 000000466B74: CA1001B6 2F2E01B5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000466B7C: BF870093
	v_lshlrev_b32_e32 v39, 16, v39                             // 000000466B80: 304E4E90
	v_and_or_b32 v9, 0xffff, v44, v39                          // 000000466B84: D6570009 049E58FF 0000FFFF
	v_dual_mov_b32 v44, v175 :: v_dual_dot2acc_f32_f16 v95, v38, v14// 000000466B90: CA1801AF 2C5E1D26
	v_mov_b32_e32 v38, v173                                    // 000000466B98: 7E4C03AD
	v_dot2acc_f32_f16 v97, v13, v11                            // 000000466B9C: 04C2170D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000466BA0: BF8701B4
	v_pk_fma_f16 v9, v9, s6, 0xc931 op_sel_hi:[1,0,0]          // 000000466BA4: CC0E0009 0BFC0D09 0000C931
	v_mov_b32_e32 v39, v174                                    // 000000466BB0: 7E4E03AE
	v_dot2acc_f32_f16 v95, v13, v15                            // 000000466BB4: 04BE1F0D
	v_dot2acc_f32_f16 v97, v9, v12                             // 000000466BB8: 04C21909
	v_dot2acc_f32_f16 v92, v9, v20                             // 000000466BBC: 04B82909
	s_delay_alu instid0(VALU_DEP_3)                            // 000000466BC0: BF870003
	v_dot2acc_f32_f16 v95, v9, v16                             // 000000466BC4: 04BE2109
	v_dot2acc_f32_f16 v91, v9, v8                              // 000000466BC8: 04B61109
	v_dot2acc_f32_f16 v89, v9, v4                              // 000000466BCC: 04B20909
	v_dot2acc_f32_f16 v87, v9, v24                             // 000000466BD0: 04AE3109
	v_dot2acc_f32_f16 v86, v9, v32                             // 000000466BD4: 04AC4109
	v_dual_dot2acc_f32_f16 v33, v9, v28 :: v_dual_mov_b32 v4, v200// 000000466BD8: CB103909 210401C8
	v_dot2acc_f32_f16 v111, v43, v20                           // 000000466BE0: 04DE292B
	v_mov_b32_e32 v43, v178                                    // 000000466BE4: 7E5603B2
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 000000466BE8: 917E007E
	s_cbranch_execz 134                                        // 000000466BEC: BFA50086 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2408>
	s_waitcnt vmcnt(23)                                        // 000000466BF0: BF895FF7
	v_dual_mov_b32 v202, v69 :: v_dual_mov_b32 v201, v84       // 000000466BF4: CA100145 CAC80154
	s_waitcnt vmcnt(15)                                        // 000000466BFC: BF893FF7
	v_dual_mov_b32 v200, v100 :: v_dual_mov_b32 v197, v83      // 000000466C00: CA100164 C8C40153
	s_waitcnt vmcnt(7)                                         // 000000466C08: BF891FF7
	v_dual_mov_b32 v199, v116 :: v_dual_mov_b32 v198, v70      // 000000466C0C: CA100174 C7C60146
	s_waitcnt vmcnt(6)                                         // 000000466C14: BF891BF7
	v_dual_mov_b32 v196, v99 :: v_dual_mov_b32 v195, v113      // 000000466C18: CA100163 C4C20171
	v_dual_mov_b32 v194, v71 :: v_dual_mov_b32 v193, v82       // 000000466C20: CA100147 C2C00152
	s_waitcnt vmcnt(5)                                         // 000000466C28: BF8917F7
	v_dual_mov_b32 v192, v96 :: v_dual_mov_b32 v191, v110      // 000000466C2C: CA100160 C0BE016E
	v_dual_mov_b32 v190, v72 :: v_dual_mov_b32 v189, v81       // 000000466C34: CA100148 BEBC0151
	s_waitcnt vmcnt(4)                                         // 000000466C3C: BF8913F7
	v_dual_mov_b32 v188, v94 :: v_dual_mov_b32 v187, v108      // 000000466C40: CA10015E BCBA016C
	v_dual_mov_b32 v186, v73 :: v_dual_mov_b32 v185, v80       // 000000466C48: CA100149 BAB80150
	s_waitcnt vmcnt(3)                                         // 000000466C50: BF890FF7
	v_dual_mov_b32 v184, v93 :: v_dual_mov_b32 v183, v107      // 000000466C54: CA10015D B8B6016B
	v_dual_mov_b32 v182, v74 :: v_dual_mov_b32 v181, v79       // 000000466C5C: CA10014A B6B4014F
	s_waitcnt vmcnt(2)                                         // 000000466C64: BF890BF7
	v_dual_mov_b32 v180, v90 :: v_dual_mov_b32 v179, v105      // 000000466C68: CA10015A B4B20169
	v_dual_mov_b32 v178, v75 :: v_dual_mov_b32 v177, v78       // 000000466C70: CA10014B B2B0014E
	v_dual_mov_b32 v176, v88 :: v_dual_mov_b32 v173, v77       // 000000466C78: CA100158 B0AC014D
	s_waitcnt vmcnt(1)                                         // 000000466C80: BF8907F7
	v_dual_mov_b32 v175, v104 :: v_dual_mov_b32 v172, v85      // 000000466C84: CA100168 AFAC0155
	s_waitcnt vmcnt(0)                                         // 000000466C8C: BF8903F7
	v_dual_mov_b32 v174, v76 :: v_dual_mov_b32 v171, v102      // 000000466C90: CA10014C AEAA0166
	s_mov_b32 s7, exec_lo                                      // 000000466C98: BE87007E
	.long 0xd4c1007e                                           // 000000466C9C: D4C1007E
	v_cndmask_b32_e32 v1, v165, v68, vcc_lo                    // 000000466CA0: 020289A5
	s_cbranch_execz 64351                                      // 000000466CA4: BFA5FB5F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1024>
	v_mad_i64_i32 v[5:6], null, 0x300, v165, s[4:5]            // 000000466CA8: D6FF7C05 00134AFF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000466CB4: BF870091
	.long 0xd7006a07                                           // 000000466CB8: D7006A07
	v_cndmask_b32_e32 v1, v5, v34, vcc_lo                      // 000000466CBC: 02024505
	v_add_co_ci_u32_e64 v8, null, v6, v35, vcc_lo              // 000000466CC0: D5207C08 01AA4706
	.long 0xd7006a09                                           // 000000466CC8: D7006A09
	v_cndmask_b32_e32 v1, v5, v169, vcc_lo                     // 000000466CCC: 02035305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000466CD0: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 000000466CD4: D5207C0A 01AA0C80
	.long 0xd7006a0b                                           // 000000466CDC: D7006A0B
	v_cndmask_b32_e32 v1, v5, v36, vcc_lo                      // 000000466CE0: 02024905
	v_add_co_ci_u32_e64 v12, null, v6, v37, vcc_lo             // 000000466CE4: D5207C0C 01AA4B06
	.long 0xd7006a05                                           // 000000466CEC: D7006A05
	v_cndmask_b32_e32 v1, v5, v170, vcc_lo                     // 000000466CF0: 02035505
	s_delay_alu instid0(VALU_DEP_1)                            // 000000466CF4: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v6, vcc_lo                // 000000466CF8: D5207C06 01AA0C80
	s_clause 0x1f                                              // 000000466D00: BF85001F
	global_load_b32 v69, v[7:8], off                           // 000000466D04: DC520000 457C0007
	global_load_b32 v70, v[7:8], off offset:96                 // 000000466D0C: DC520060 467C0007
	global_load_b32 v71, v[7:8], off offset:192                // 000000466D14: DC5200C0 477C0007
	global_load_b32 v72, v[7:8], off offset:288                // 000000466D1C: DC520120 487C0007
	global_load_b32 v73, v[7:8], off offset:384                // 000000466D24: DC520180 497C0007
	global_load_b32 v74, v[7:8], off offset:480                // 000000466D2C: DC5201E0 4A7C0007
	global_load_b32 v75, v[7:8], off offset:576                // 000000466D34: DC520240 4B7C0007
	global_load_b32 v76, v[7:8], off offset:672                // 000000466D3C: DC5202A0 4C7C0007
	global_load_b32 v84, v[9:10], off                          // 000000466D44: DC520000 547C0009
	global_load_b32 v83, v[9:10], off offset:96                // 000000466D4C: DC520060 537C0009
	global_load_b32 v82, v[9:10], off offset:192               // 000000466D54: DC5200C0 527C0009
	global_load_b32 v81, v[9:10], off offset:288               // 000000466D5C: DC520120 517C0009
	global_load_b32 v80, v[9:10], off offset:384               // 000000466D64: DC520180 507C0009
	global_load_b32 v79, v[9:10], off offset:480               // 000000466D6C: DC5201E0 4F7C0009
	global_load_b32 v78, v[9:10], off offset:576               // 000000466D74: DC520240 4E7C0009
	global_load_b32 v77, v[9:10], off offset:672               // 000000466D7C: DC5202A0 4D7C0009
	global_load_b32 v100, v[11:12], off                        // 000000466D84: DC520000 647C000B
	global_load_b32 v99, v[11:12], off offset:96               // 000000466D8C: DC520060 637C000B
	global_load_b32 v96, v[11:12], off offset:192              // 000000466D94: DC5200C0 607C000B
	global_load_b32 v94, v[11:12], off offset:288              // 000000466D9C: DC520120 5E7C000B
	global_load_b32 v93, v[11:12], off offset:384              // 000000466DA4: DC520180 5D7C000B
	global_load_b32 v90, v[11:12], off offset:480              // 000000466DAC: DC5201E0 5A7C000B
	global_load_b32 v88, v[11:12], off offset:576              // 000000466DB4: DC520240 587C000B
	global_load_b32 v85, v[11:12], off offset:672              // 000000466DBC: DC5202A0 557C000B
	global_load_b32 v116, v[5:6], off                          // 000000466DC4: DC520000 747C0005
	global_load_b32 v113, v[5:6], off offset:96                // 000000466DCC: DC520060 717C0005
	global_load_b32 v110, v[5:6], off offset:192               // 000000466DD4: DC5200C0 6E7C0005
	global_load_b32 v108, v[5:6], off offset:288               // 000000466DDC: DC520120 6C7C0005
	global_load_b32 v107, v[5:6], off offset:384               // 000000466DE4: DC520180 6B7C0005
	global_load_b32 v105, v[5:6], off offset:480               // 000000466DEC: DC5201E0 697C0005
	global_load_b32 v104, v[5:6], off offset:576               // 000000466DF4: DC520240 687C0005
	global_load_b32 v102, v[5:6], off offset:672               // 000000466DFC: DC5202A0 667C0005
	s_branch 64263                                             // 000000466E04: BFA0FB07 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1024>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000466E08: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000466E0C: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000466E10: 8C7E017E
	s_waitcnt vmcnt(15)                                        // 000000466E14: BF893FF7
	v_dual_mov_b32 v1, v163 :: v_dual_mov_b32 v4, v153         // 000000466E18: CA1001A3 01040199
	s_waitcnt vmcnt(7)                                         // 000000466E20: BF891FF7
	v_dual_mov_b32 v2, v159 :: v_dual_mov_b32 v3, v154         // 000000466E24: CA10019F 0202019A
	v_dual_mov_b32 v5, v156 :: v_dual_mov_b32 v10, v161        // 000000466E2C: CA10019C 050A01A1
	v_dual_mov_b32 v6, v152 :: v_dual_mov_b32 v7, v150         // 000000466E34: CA100198 06060196
	v_dual_mov_b32 v8, v148 :: v_dual_mov_b32 v9, v162         // 000000466E3C: CA100194 080801A2
	v_dual_mov_b32 v11, v160 :: v_dual_mov_b32 v12, v158       // 000000466E44: CA1001A0 0B0C019E
	v_dual_mov_b32 v13, v157 :: v_dual_mov_b32 v14, v155       // 000000466E4C: CA10019D 0D0E019B
	v_dual_mov_b32 v15, v151 :: v_dual_mov_b32 v16, v149       // 000000466E54: CA100197 0F100195
	v_dual_mov_b32 v17, v147 :: v_dual_mov_b32 v18, v146       // 000000466E5C: CA100193 11120192
	v_dual_mov_b32 v19, v145 :: v_dual_mov_b32 v20, v144       // 000000466E64: CA100191 13140190
	v_dual_mov_b32 v21, v143 :: v_dual_mov_b32 v22, v142       // 000000466E6C: CA10018F 1516018E
	v_dual_mov_b32 v23, v141 :: v_dual_mov_b32 v24, v140       // 000000466E74: CA10018D 1718018C
	v_dual_mov_b32 v25, v139 :: v_dual_mov_b32 v26, v138       // 000000466E7C: CA10018B 191A018A
	v_dual_mov_b32 v27, v137 :: v_dual_mov_b32 v28, v136       // 000000466E84: CA100189 1B1C0188
	v_dual_mov_b32 v29, v135 :: v_dual_mov_b32 v30, v134       // 000000466E8C: CA100187 1D1E0186
	v_dual_mov_b32 v31, v133 :: v_dual_mov_b32 v32, v132       // 000000466E94: CA100185 1F200184
	v_dual_mov_b32 v34, v131 :: v_dual_mov_b32 v35, v130       // 000000466E9C: CA100183 22220182
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v37, v128       // 000000466EA4: CA100181 24240180
	v_dual_mov_b32 v38, v127 :: v_dual_mov_b32 v39, v126       // 000000466EAC: CA10017F 2626017E
	s_waitcnt vmcnt(0)                                         // 000000466EB4: BF8903F7
	v_dual_mov_b32 v40, v125 :: v_dual_mov_b32 v41, v124       // 000000466EB8: CA10017D 2828017C
	v_dual_mov_b32 v42, v123 :: v_dual_mov_b32 v43, v122       // 000000466EC0: CA10017B 2A2A017A
	v_dual_mov_b32 v44, v121 :: v_dual_mov_b32 v45, v120       // 000000466EC8: CA100179 2C2C0178
	v_dual_mov_b32 v46, v119 :: v_dual_mov_b32 v47, v118       // 000000466ED0: CA100177 2E2E0176
	v_dual_mov_b32 v48, v117 :: v_dual_mov_b32 v49, v115       // 000000466ED8: CA100175 30300173
	v_dual_mov_b32 v50, v114 :: v_dual_mov_b32 v51, v112       // 000000466EE0: CA100172 32320170
	v_dual_mov_b32 v52, v111 :: v_dual_mov_b32 v53, v109       // 000000466EE8: CA10016F 3434016D
	v_dual_mov_b32 v54, v106 :: v_dual_mov_b32 v55, v103       // 000000466EF0: CA10016A 36360167
	v_dual_mov_b32 v56, v101 :: v_dual_mov_b32 v57, v98        // 000000466EF8: CA100165 38380162
	v_dual_mov_b32 v58, v97 :: v_dual_mov_b32 v59, v95         // 000000466F00: CA100161 3A3A015F
	v_dual_mov_b32 v60, v92 :: v_dual_mov_b32 v61, v91         // 000000466F08: CA10015C 3C3C015B
	v_dual_mov_b32 v62, v89 :: v_dual_mov_b32 v63, v87         // 000000466F10: CA100159 3E3E0157
	v_dual_mov_b32 v64, v86 :: v_dual_mov_b32 v65, v33         // 000000466F18: CA100156 40400121
	s_mov_b32 s0, 0x76543210                                   // 000000466F20: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000466F28: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000466F2C: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000466F38: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000466F44: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000466F50: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000466F5C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000466F68: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000466F74: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000466F80: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000466F8C: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000466F98: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000466FA4: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000466FB0: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000466FBC: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000466FC8: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000466FD4: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000466FE0: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000466FEC: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 000000466FF8: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 000000467004: D65C0013 03FC0113 FEDCBA98
	v_permlanex16_b32 v20, v20, s0, 0xfedcba98                 // 000000467010: D65C0014 03FC0114 FEDCBA98
	v_permlanex16_b32 v21, v21, s0, 0xfedcba98                 // 00000046701C: D65C0015 03FC0115 FEDCBA98
	v_permlanex16_b32 v22, v22, s0, 0xfedcba98                 // 000000467028: D65C0016 03FC0116 FEDCBA98
	v_permlanex16_b32 v23, v23, s0, 0xfedcba98                 // 000000467034: D65C0017 03FC0117 FEDCBA98
	v_permlanex16_b32 v24, v24, s0, 0xfedcba98                 // 000000467040: D65C0018 03FC0118 FEDCBA98
	v_permlanex16_b32 v25, v25, s0, 0xfedcba98                 // 00000046704C: D65C0019 03FC0119 FEDCBA98
	v_permlanex16_b32 v26, v26, s0, 0xfedcba98                 // 000000467058: D65C001A 03FC011A FEDCBA98
	v_permlanex16_b32 v27, v27, s0, 0xfedcba98                 // 000000467064: D65C001B 03FC011B FEDCBA98
	v_permlanex16_b32 v28, v28, s0, 0xfedcba98                 // 000000467070: D65C001C 03FC011C FEDCBA98
	v_permlanex16_b32 v29, v29, s0, 0xfedcba98                 // 00000046707C: D65C001D 03FC011D FEDCBA98
	v_permlanex16_b32 v30, v30, s0, 0xfedcba98                 // 000000467088: D65C001E 03FC011E FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 000000467094: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 0000004670A0: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v34, v34, s0, 0xfedcba98                 // 0000004670AC: D65C0022 03FC0122 FEDCBA98
	v_permlanex16_b32 v35, v35, s0, 0xfedcba98                 // 0000004670B8: D65C0023 03FC0123 FEDCBA98
	v_permlanex16_b32 v36, v36, s0, 0xfedcba98                 // 0000004670C4: D65C0024 03FC0124 FEDCBA98
	v_permlanex16_b32 v37, v37, s0, 0xfedcba98                 // 0000004670D0: D65C0025 03FC0125 FEDCBA98
	v_permlanex16_b32 v38, v38, s0, 0xfedcba98                 // 0000004670DC: D65C0026 03FC0126 FEDCBA98
	v_permlanex16_b32 v39, v39, s0, 0xfedcba98                 // 0000004670E8: D65C0027 03FC0127 FEDCBA98
	v_permlanex16_b32 v40, v40, s0, 0xfedcba98                 // 0000004670F4: D65C0028 03FC0128 FEDCBA98
	v_permlanex16_b32 v41, v41, s0, 0xfedcba98                 // 000000467100: D65C0029 03FC0129 FEDCBA98
	v_permlanex16_b32 v42, v42, s0, 0xfedcba98                 // 00000046710C: D65C002A 03FC012A FEDCBA98
	v_permlanex16_b32 v43, v43, s0, 0xfedcba98                 // 000000467118: D65C002B 03FC012B FEDCBA98
	v_permlanex16_b32 v44, v44, s0, 0xfedcba98                 // 000000467124: D65C002C 03FC012C FEDCBA98
	v_permlanex16_b32 v45, v45, s0, 0xfedcba98                 // 000000467130: D65C002D 03FC012D FEDCBA98
	v_permlanex16_b32 v46, v46, s0, 0xfedcba98                 // 00000046713C: D65C002E 03FC012E FEDCBA98
	v_permlanex16_b32 v47, v47, s0, 0xfedcba98                 // 000000467148: D65C002F 03FC012F FEDCBA98
	v_permlanex16_b32 v48, v48, s0, 0xfedcba98                 // 000000467154: D65C0030 03FC0130 FEDCBA98
	v_permlanex16_b32 v49, v49, s0, 0xfedcba98                 // 000000467160: D65C0031 03FC0131 FEDCBA98
	v_permlanex16_b32 v50, v50, s0, 0xfedcba98                 // 00000046716C: D65C0032 03FC0132 FEDCBA98
	v_permlanex16_b32 v51, v51, s0, 0xfedcba98                 // 000000467178: D65C0033 03FC0133 FEDCBA98
	v_permlanex16_b32 v52, v52, s0, 0xfedcba98                 // 000000467184: D65C0034 03FC0134 FEDCBA98
	v_permlanex16_b32 v53, v53, s0, 0xfedcba98                 // 000000467190: D65C0035 03FC0135 FEDCBA98
	v_permlanex16_b32 v54, v54, s0, 0xfedcba98                 // 00000046719C: D65C0036 03FC0136 FEDCBA98
	v_permlanex16_b32 v55, v55, s0, 0xfedcba98                 // 0000004671A8: D65C0037 03FC0137 FEDCBA98
	v_permlanex16_b32 v56, v56, s0, 0xfedcba98                 // 0000004671B4: D65C0038 03FC0138 FEDCBA98
	v_permlanex16_b32 v57, v57, s0, 0xfedcba98                 // 0000004671C0: D65C0039 03FC0139 FEDCBA98
	v_permlanex16_b32 v58, v58, s0, 0xfedcba98                 // 0000004671CC: D65C003A 03FC013A FEDCBA98
	v_permlanex16_b32 v59, v59, s0, 0xfedcba98                 // 0000004671D8: D65C003B 03FC013B FEDCBA98
	v_permlanex16_b32 v60, v60, s0, 0xfedcba98                 // 0000004671E4: D65C003C 03FC013C FEDCBA98
	v_permlanex16_b32 v61, v61, s0, 0xfedcba98                 // 0000004671F0: D65C003D 03FC013D FEDCBA98
	v_permlanex16_b32 v62, v62, s0, 0xfedcba98                 // 0000004671FC: D65C003E 03FC013E FEDCBA98
	v_permlanex16_b32 v63, v63, s0, 0xfedcba98                 // 000000467208: D65C003F 03FC013F FEDCBA98
	v_permlanex16_b32 v64, v64, s0, 0xfedcba98                 // 000000467214: D65C0040 03FC0140 FEDCBA98
	v_permlanex16_b32 v65, v65, s0, 0xfedcba98                 // 000000467220: D65C0041 03FC0141 FEDCBA98
	.long 0xd44c0000                                           // 00000046722C: D44C0000
	v_cndmask_b32_e32 v1, 16, v67, vcc_lo                      // 000000467230: 02028690
	s_barrier                                                  // 000000467234: BFBD0000
	buffer_gl0_inv                                             // 000000467238: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000467240: BE812000
	s_cbranch_execz 138                                        // 000000467244: BFA5008A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2a70>
	v_dual_add_f32 v33, v33, v65 :: v_dual_add_f32 v64, v86, v64// 000000467248: C9088321 21408156
	v_dual_add_f32 v8, v148, v8 :: v_dual_lshlrev_b32 v65, 2, v67// 000000467250: C9221194 08408682
	v_dual_add_f32 v10, v161, v10 :: v_dual_add_f32 v9, v162, v9// 000000467258: C90815A1 0A0813A2
	v_add_f32_e32 v1, v163, v1                                 // 000000467260: 060203A3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000467264: BF8701B3
	v_lshl_or_b32 v65, v66, 12, v65                            // 000000467268: D6560041 05051942
	v_dual_add_f32 v2, v159, v2 :: v_dual_add_f32 v3, v154, v3 // 000000467270: C908059F 0202079A
	v_dual_add_f32 v12, v158, v12 :: v_dual_add_f32 v11, v160, v11// 000000467278: C908199E 0C0A17A0
	v_add_nc_u32_e32 v67, 0x400, v65                           // 000000467280: 4A8682FF 00000400
	v_dual_add_f32 v5, v156, v5 :: v_dual_add_f32 v4, v153, v4 // 000000467288: C9080B9C 05040999
	v_dual_add_f32 v14, v155, v14 :: v_dual_add_f32 v13, v157, v13// 000000467290: C9081D9B 0E0C1B9D
	ds_store_2addr_b32 v65, v1, v9 offset1:16                  // 000000467298: D8381000 00090141
	v_add_nc_u32_e32 v1, 0x800, v65                            // 0000004672A0: 4A0282FF 00000800
	v_dual_add_f32 v7, v150, v7 :: v_dual_add_f32 v6, v152, v6 // 0000004672A8: C9080F96 07060D98
	v_dual_add_f32 v16, v149, v16 :: v_dual_add_f32 v15, v151, v15// 0000004672B0: C9082195 100E1F97
	ds_store_2addr_b32 v65, v2, v10 offset0:128 offset1:144    // 0000004672B8: D8389080 000A0241
	v_dual_add_f32 v63, v87, v63 :: v_dual_add_nc_u32 v2, 0xc00, v65// 0000004672C0: C9207F57 3F0282FF 00000C00
	v_dual_add_f32 v62, v89, v62 :: v_dual_add_f32 v61, v91, v61// 0000004672CC: C9087D59 3E3C7B5B
	v_dual_add_f32 v60, v92, v60 :: v_dual_add_f32 v59, v95, v59// 0000004672D4: C908795C 3C3A775F
	v_dual_add_f32 v58, v97, v58 :: v_dual_add_f32 v57, v98, v57// 0000004672DC: C9087561 3A387362
	v_dual_add_f32 v56, v101, v56 :: v_dual_add_f32 v55, v103, v55// 0000004672E4: C9087165 38366F67
	v_dual_add_f32 v54, v106, v54 :: v_dual_add_f32 v53, v109, v53// 0000004672EC: C9086D6A 36346B6D
	v_dual_add_f32 v52, v111, v52 :: v_dual_add_f32 v51, v112, v51// 0000004672F4: C908696F 34326770
	v_dual_add_f32 v50, v114, v50 :: v_dual_add_f32 v49, v115, v49// 0000004672FC: C9086572 32306373
	v_dual_add_f32 v48, v117, v48 :: v_dual_add_f32 v47, v118, v47// 000000467304: C9086175 302E5F76
	v_dual_add_f32 v46, v119, v46 :: v_dual_add_f32 v45, v120, v45// 00000046730C: C9085D77 2E2C5B78
	v_dual_add_f32 v44, v121, v44 :: v_dual_add_f32 v43, v122, v43// 000000467314: C9085979 2C2A577A
	v_dual_add_f32 v42, v123, v42 :: v_dual_add_f32 v41, v124, v41// 00000046731C: C908557B 2A28537C
	v_dual_add_f32 v40, v125, v40 :: v_dual_add_f32 v39, v126, v39// 000000467324: C908517D 28264F7E
	v_dual_add_f32 v38, v127, v38 :: v_dual_add_f32 v37, v128, v37// 00000046732C: C9084D7F 26244B80
	v_dual_add_f32 v36, v129, v36 :: v_dual_add_f32 v35, v130, v35// 000000467334: C9084981 24224782
	v_add_f32_e32 v34, v131, v34                               // 00000046733C: 06444583
	v_dual_add_f32 v32, v132, v32 :: v_dual_add_f32 v31, v133, v31// 000000467340: C9084184 201E3F85
	v_dual_add_f32 v30, v134, v30 :: v_dual_add_f32 v29, v135, v29// 000000467348: C9083D86 1E1C3B87
	v_dual_add_f32 v28, v136, v28 :: v_dual_add_f32 v27, v137, v27// 000000467350: C9083988 1C1A3789
	v_dual_add_f32 v26, v138, v26 :: v_dual_add_f32 v25, v139, v25// 000000467358: C908358A 1A18338B
	v_dual_add_f32 v24, v140, v24 :: v_dual_add_f32 v23, v141, v23// 000000467360: C908318C 18162F8D
	v_dual_add_f32 v22, v142, v22 :: v_dual_add_f32 v21, v143, v21// 000000467368: C9082D8E 16142B8F
	v_dual_add_f32 v20, v144, v20 :: v_dual_add_f32 v19, v145, v19// 000000467370: C9082990 14122791
	v_dual_add_f32 v18, v146, v18 :: v_dual_add_f32 v17, v147, v17// 000000467378: C9082592 12102393
	ds_store_2addr_b32 v67, v3, v11 offset1:16                 // 000000467380: D8381000 000B0343
	ds_store_2addr_b32 v67, v4, v12 offset0:128 offset1:144    // 000000467388: D8389080 000C0443
	ds_store_2addr_b32 v1, v5, v13 offset1:16                  // 000000467390: D8381000 000D0501
	ds_store_2addr_b32 v1, v6, v14 offset0:128 offset1:144     // 000000467398: D8389080 000E0601
	ds_store_2addr_b32 v2, v7, v15 offset1:16                  // 0000004673A0: D8381000 000F0702
	ds_store_2addr_b32 v2, v8, v16 offset0:128 offset1:144     // 0000004673A8: D8389080 00100802
	ds_store_2addr_b32 v65, v17, v25 offset0:32 offset1:48     // 0000004673B0: D8383020 00191141
	ds_store_2addr_b32 v65, v18, v26 offset0:160 offset1:176   // 0000004673B8: D838B0A0 001A1241
	ds_store_2addr_b32 v67, v19, v27 offset0:32 offset1:48     // 0000004673C0: D8383020 001B1343
	ds_store_2addr_b32 v67, v20, v28 offset0:160 offset1:176   // 0000004673C8: D838B0A0 001C1443
	ds_store_2addr_b32 v1, v21, v29 offset0:32 offset1:48      // 0000004673D0: D8383020 001D1501
	ds_store_2addr_b32 v1, v22, v30 offset0:160 offset1:176    // 0000004673D8: D838B0A0 001E1601
	ds_store_2addr_b32 v2, v23, v31 offset0:32 offset1:48      // 0000004673E0: D8383020 001F1702
	ds_store_2addr_b32 v2, v24, v32 offset0:160 offset1:176    // 0000004673E8: D838B0A0 00201802
	ds_store_2addr_b32 v65, v34, v42 offset0:64 offset1:80     // 0000004673F0: D8385040 002A2241
	ds_store_2addr_b32 v65, v35, v43 offset0:192 offset1:208   // 0000004673F8: D838D0C0 002B2341
	ds_store_2addr_b32 v67, v36, v44 offset0:64 offset1:80     // 000000467400: D8385040 002C2443
	ds_store_2addr_b32 v67, v37, v45 offset0:192 offset1:208   // 000000467408: D838D0C0 002D2543
	ds_store_2addr_b32 v1, v38, v46 offset0:64 offset1:80      // 000000467410: D8385040 002E2601
	ds_store_2addr_b32 v1, v39, v47 offset0:192 offset1:208    // 000000467418: D838D0C0 002F2701
	ds_store_2addr_b32 v2, v40, v48 offset0:64 offset1:80      // 000000467420: D8385040 00302802
	ds_store_2addr_b32 v2, v41, v49 offset0:192 offset1:208    // 000000467428: D838D0C0 00312902
	ds_store_2addr_b32 v65, v50, v58 offset0:96 offset1:112    // 000000467430: D8387060 003A3241
	ds_store_2addr_b32 v65, v51, v59 offset0:224 offset1:240   // 000000467438: D838F0E0 003B3341
	ds_store_2addr_b32 v67, v52, v60 offset0:96 offset1:112    // 000000467440: D8387060 003C3443
	ds_store_2addr_b32 v67, v53, v61 offset0:224 offset1:240   // 000000467448: D838F0E0 003D3543
	ds_store_2addr_b32 v1, v54, v62 offset0:96 offset1:112     // 000000467450: D8387060 003E3601
	ds_store_2addr_b32 v1, v55, v63 offset0:224 offset1:240    // 000000467458: D838F0E0 003F3701
	ds_store_2addr_b32 v2, v56, v64 offset0:96 offset1:112     // 000000467460: D8387060 00403802
	ds_store_2addr_b32 v2, v57, v33 offset0:224 offset1:240    // 000000467468: D838F0E0 00213902
	s_or_b32 exec_lo, exec_lo, s1                              // 000000467470: 8C7E017E
	v_mov_b32_e32 v1, v0                                       // 000000467474: 7E020300
	s_mov_b32 s1, 0                                            // 000000467478: BE810080
	s_waitcnt lgkmcnt(0)                                       // 00000046747C: BF89FC07
	s_barrier                                                  // 000000467480: BFBD0000
	buffer_gl0_inv                                             // 000000467484: E0AC0000 00000000
	s_nop 0                                                    // 00000046748C: BF800000
	s_nop 0                                                    // 000000467490: BF800000
	s_nop 0                                                    // 000000467494: BF800000
	s_nop 0                                                    // 000000467498: BF800000
	s_nop 0                                                    // 00000046749C: BF800000
	s_nop 0                                                    // 0000004674A0: BF800000
	s_nop 0                                                    // 0000004674A4: BF800000
	s_nop 0                                                    // 0000004674A8: BF800000
	s_nop 0                                                    // 0000004674AC: BF800000
	s_nop 0                                                    // 0000004674B0: BF800000
	s_nop 0                                                    // 0000004674B4: BF800000
	s_nop 0                                                    // 0000004674B8: BF800000
	s_nop 0                                                    // 0000004674BC: BF800000
	v_lshlrev_b32_e32 v8, 2, v1                                // 0000004674C0: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v1                         // 0000004674C4: 7C9202FF 000002FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:16           // 0000004674CC: D8E01000 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:32 offset1:48// 0000004674D4: D8E03020 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:64 offset1:80// 0000004674DC: D8E05040 06000008
	s_or_b32 s1, vcc_lo, s1                                    // 0000004674E4: 8C01016A
	s_waitcnt lgkmcnt(2)                                       // 0000004674E8: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 0000004674EC: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000004674F0: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 0000004674F4: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:96 offset1:112// 0000004674F8: D8E07060 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000467500: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000467504: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 000000467508: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 00000046750C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000467510: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000467514: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 000000467518: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 00000046751C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000467520: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 000000467524: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 000000467528: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 000000467530: C9100702 02000104
	ds_store_b32 v8, v2 offset:32768                           // 000000467538: D8348000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000467540: 917E017E
	s_cbranch_execnz 65502                                     // 000000467544: BFA6FFDE <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2ac0>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000467548: 8C7E017E
	s_cmp_lt_i32 s33, 2                                        // 00000046754C: BF048221
	s_mov_b32 s1, -1                                           // 000000467550: BE8100C1
	s_cbranch_scc1 197                                         // 000000467554: BFA200C5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2e6c>
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v1, 0x7f, v0       // 000000467558: CA240100 040000FF 0000007F
	s_lshl_b32 s4, s2, 7                                       // 000000467564: 84048702
	s_ashr_i32 s11, s10, 31                                    // 000000467568: 860B9F0A
	s_ashr_i32 s5, s4, 31                                      // 00000046756C: 86059F04
	s_delay_alu instid0(VALU_DEP_1)                            // 000000467570: BF870001
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000467574: 30040282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000467578: 84848204
	s_lshl_b64 s[6:7], s[10:11], 3                             // 00000046757C: 8486830A
	s_ashr_i32 s27, s26, 31                                    // 000000467580: 861B9F1A
	s_add_u32 s1, s16, s4                                      // 000000467584: 80010410
	s_addc_u32 s8, s17, s5                                     // 000000467588: 82080511
	.long 0xd7000102                                           // 00000046758C: D7000102
	v_cndmask_b32_e32 v1, s1, v2, vcc_lo                       // 000000467590: 02020401
	s_delay_alu instid0(VALU_DEP_1)                            // 000000467594: BF870001
	v_add_co_ci_u32_e64 v3, null, s8, 0, s1                    // 000000467598: D5207C03 00050008
	s_mov_b32 s8, 0                                            // 0000004675A0: BE880080
	s_waitcnt lgkmcnt(0)                                       // 0000004675A4: BF89FC07
	s_barrier                                                  // 0000004675A8: BFBD0000
	buffer_gl0_inv                                             // 0000004675AC: E0AC0000 00000000
	s_nop 0                                                    // 0000004675B4: BF800000
	s_nop 0                                                    // 0000004675B8: BF800000
	s_nop 0                                                    // 0000004675BC: BF800000
	v_lshrrev_b32_e32 v5, 7, v4                                // 0000004675C0: 320A0887
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v4                         // 0000004675C4: 7C9208FF 000002FF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004675CC: BF870092
	.long 0xd7000105                                           // 0000004675D0: D7000105
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000004675D4: 02020A06
	v_add_co_ci_u32_e64 v6, null, s7, 0, s1                    // 0000004675D8: D5207C06 00050007
	s_or_b32 s8, vcc_lo, s8                                    // 0000004675E0: 8C08086A
	.long 0xd72c0009                                           // 0000004675E4: D72C0009
	v_cndmask_b32_e32 v0, v5, v27, vcc_lo                      // 0000004675E8: 02003705
	.long 0xd72c0008                                           // 0000004675EC: D72C0008
	v_cndmask_b32_e32 v0, v6, v26, vcc_lo                      // 0000004675F0: 02003506
	v_mad_u64_u32 v[5:6], null, v5, s26, 0                     // 0000004675F4: D6FE7C05 02003505
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004675FC: BF8701B1
	v_add3_u32 v6, v6, v9, v8                                  // 000000467600: D6550006 04221306
	v_add_nc_u32_e32 v8, 0x100, v4                             // 000000467608: 4A1008FF 00000100
	v_lshlrev_b32_e32 v7, 2, v4                                // 000000467610: 300E0882
	.long 0xd73c0005                                           // 000000467614: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000467618: 02020A82
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000046761C: BF8700B3
	v_mov_b32_e32 v4, v8                                       // 000000467620: 7E080308
	ds_load_b32 v7, v7 offset:32768                            // 000000467624: D8D88000 07000007
	.long 0xd7000105                                           // 00000046762C: D7000105
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 000000467630: 02020B02
	v_add_co_ci_u32_e64 v6, null, v3, v6, s1                   // 000000467634: D5207C06 00060D03
	s_waitcnt lgkmcnt(0)                                       // 00000046763C: BF89FC07
	global_store_b32 v[5:6], v7, off                           // 000000467640: DC6A0000 007C0705
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 000000467648: 917E087E
	s_cbranch_execnz 65500                                     // 00000046764C: BFA6FFDC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2bc0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000467650: 8C7E087E
	.long 0xd44a0001                                           // 000000467654: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000467658: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 00000046765C: BC7C0000
	buffer_gl1_inv                                             // 000000467660: E0B00000 00000000
	buffer_gl0_inv                                             // 000000467668: E0AC0000 00000000
	s_barrier                                                  // 000000467670: BFBD0000
	buffer_gl0_inv                                             // 000000467674: E0AC0000 00000000
	s_and_saveexec_b32 s6, s1                                  // 00000046767C: BE862001
	s_cbranch_execz 29                                         // 000000467680: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2cf8>
	s_mov_b32 s8, exec_lo                                      // 000000467684: BE88007E
	s_mov_b32 s7, exec_lo                                      // 000000467688: BE87007E
	.long 0xd71f0002                                           // 00000046768C: D71F0002
	v_cndmask_b32_e32 v0, s8, v128, vcc_lo                     // 000000467690: 02010008
	s_delay_alu instid0(VALU_DEP_1)                            // 000000467694: BF870001
	v_cmpx_eq_u32_e32 0, v2                                    // 000000467698: 7D940480
	s_cbranch_execz 9                                          // 00000046769C: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2cc4>
	s_lshl_b64 s[10:11], s[2:3], 2                             // 0000004676A0: 848A8202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000004676A4: BF8704B9
	s_add_u32 s10, s18, s10                                    // 0000004676A8: 800A0A12
	s_addc_u32 s11, s19, s11                                   // 0000004676AC: 820B0B13
	s_bcnt1_i32_b32 s8, s8                                     // 0000004676B0: BE881808
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v4, s8              // 0000004676B4: CA100080 03040008
	global_atomic_add_u32 v3, v3, v4, s[10:11] glc             // 0000004676BC: DCD64000 030A0403
	s_or_b32 exec_lo, exec_lo, s7                              // 0000004676C4: 8C7E077E
	s_waitcnt vmcnt(0)                                         // 0000004676C8: BF8903F7
	v_readfirstlane_b32 s7, v3                                 // 0000004676CC: 7E0E0503
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004676D0: BF870001
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v2, s7, v2       // 0000004676D4: CA200080 03020407
	s_add_i32 s7, s33, -1                                      // 0000004676DC: 8107C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000004676E0: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s7, v2                            // 0000004676E4: 7C940407
	v_cndmask_b32_e64 v2, 0, 1, vcc_lo                         // 0000004676E8: D5010002 01A90280
	ds_store_b32 v3, v2 offset:40960                           // 0000004676F0: D834A000 00000203
	s_or_b32 exec_lo, exec_lo, s6                              // 0000004676F8: 8C7E067E
	v_mov_b32_e32 v2, 0                                        // 0000004676FC: 7E040280
	s_waitcnt lgkmcnt(0)                                       // 000000467700: BF89FC07
	s_barrier                                                  // 000000467704: BFBD0000
	buffer_gl0_inv                                             // 000000467708: E0AC0000 00000000
	s_mov_b32 s10, 0                                           // 000000467710: BE8A0080
	ds_load_b32 v2, v2 offset:40960                            // 000000467714: D8D8A000 02000002
	s_waitcnt lgkmcnt(0)                                       // 00000046771C: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v2                             // 000000467720: 7C940480
	s_cbranch_vccnz 465                                        // 000000467724: BFA401D1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x346c>
	v_lshrrev_b32_e32 v2, 7, v0                                // 000000467728: 32040087
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000046772C: 30020282
	v_mov_b32_e32 v5, v0                                       // 000000467730: 7E0A0300
	s_lshl_b64 s[6:7], s[26:27], 3                             // 000000467734: 8486831A
	s_lshl_b64 s[8:9], s[26:27], 5                             // 000000467738: 8488851A
	v_mad_i64_i32 v[2:3], null, v2, s26, 0                     // 00000046773C: D6FF7C02 02003502
	buffer_gl1_inv                                             // 000000467744: E0B00000 00000000
	buffer_gl0_inv                                             // 00000046774C: E0AC0000 00000000
	.long 0xd73c0002                                           // 000000467754: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000467758: 02020482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000046775C: BF870091
	.long 0xd7006a02                                           // 000000467760: D7006A02
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 000000467764: 02000902
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 000000467768: D5207C03 01AA0605
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000467770: BF870092
	.long 0xd7006a01                                           // 000000467774: D7006A01
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000467778: 02020302
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo                // 00000046777C: D5207C02 01AA0680
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000467784: BF870092
	.long 0xd7006a01                                           // 000000467788: D7006A01
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000046778C: 02020210
	v_add_co_ci_u32_e64 v2, null, s17, v2, vcc_lo              // 000000467790: D5207C02 01AA0411
	s_nop 0                                                    // 000000467798: BF800000
	s_nop 0                                                    // 00000046779C: BF800000
	s_nop 0                                                    // 0000004677A0: BF800000
	s_nop 0                                                    // 0000004677A4: BF800000
	s_nop 0                                                    // 0000004677A8: BF800000
	s_nop 0                                                    // 0000004677AC: BF800000
	s_nop 0                                                    // 0000004677B0: BF800000
	s_nop 0                                                    // 0000004677B4: BF800000
	s_nop 0                                                    // 0000004677B8: BF800000
	s_nop 0                                                    // 0000004677BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004677C0: BF870191
	v_mov_b32_e32 v4, v2                                       // 0000004677C4: 7E080302
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v3, v1              // 0000004677C8: CA100080 06020101
	s_mov_b32 s4, s33                                          // 0000004677D0: BE840021
	global_load_b32 v7, v[3:4], off glc                        // 0000004677D4: DC524000 077C0003
	.long 0xd7006a03                                           // 0000004677DC: D7006A03
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000004677E0: 02001103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000004677E4: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000004677E8: D5207C04 01AA0809
	s_add_i32 s4, s4, -1                                       // 0000004677F0: 8104C104
	s_cmp_eq_u32 s4, 0                                         // 0000004677F4: BF068004
	s_waitcnt vmcnt(0)                                         // 0000004677F8: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 0000004677FC: 060C0F06
	s_cbranch_scc0 65524                                       // 000000467800: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2dd4>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 000000467804: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v5                         // 00000046780C: 7C920AFF 000002FF
	.long 0xd7000401                                           // 000000467814: D7000401
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000467818: 02000D01
	v_lshlrev_b32_e32 v3, 2, v5                                // 00000046781C: 30060A82
	v_add_co_ci_u32_e64 v2, null, s7, v2, s4                   // 000000467820: D5207C02 00120407
	v_mov_b32_e32 v5, v4                                       // 000000467828: 7E0A0304
	s_or_b32 s10, vcc_lo, s10                                  // 00000046782C: 8C0A0A6A
	ds_store_b32 v3, v6 offset:32768                           // 000000467830: D8348000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000467838: 917E0A7E
	s_cbranch_execnz 65504                                     // 00000046783C: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2dc0>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000467840: 8C7E0A7E
	s_and_saveexec_b32 s4, s1                                  // 000000467844: BE842001
	s_cbranch_execz 6                                          // 000000467848: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2e64>
	s_lshl_b64 s[6:7], s[2:3], 2                               // 00000046784C: 84868202
	v_mov_b32_e32 v1, 0                                        // 000000467850: 7E020280
	s_add_u32 s6, s18, s6                                      // 000000467854: 80060612
	s_addc_u32 s7, s19, s7                                     // 000000467858: 82070713
	global_store_b32 v1, v1, s[6:7]                            // 00000046785C: DC6A0000 00060101
	s_or_b32 exec_lo, exec_lo, s4                              // 000000467864: 8C7E047E
	s_mov_b32 s1, -1                                           // 000000467868: BE8100C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000046786C: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000467870: 8B6A017E
	s_cbranch_vccz 381                                         // 000000467874: BFA3017D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x346c>
	v_cmp_gt_i32_e32 vcc_lo, s24, v66                          // 000000467878: 7C888418
	.long 0xd44c0001                                           // 00000046787C: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000467880: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000467888: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000046788C: BC7C0000
	s_barrier                                                  // 000000467890: BFBD0000
	buffer_gl0_inv                                             // 000000467894: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000046789C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004678A0: BF870009
	s_and_saveexec_b32 s3, s1                                  // 0000004678A4: BE832001
	s_cbranch_execz 368                                        // 0000004678A8: BFA50170 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x346c>
	v_and_b32_e32 v1, 15, v0                                   // 0000004678AC: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004678B0: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000004678B4: 30040282
	v_lshl_or_b32 v2, v66, 9, v2                               // 0000004678B8: D6560002 04091342
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004678C0: BF870001
	v_add_nc_u32_e32 v8, 0x8000, v2                            // 0000004678C4: 4A1004FF 00008000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000004678CC: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000004678D4: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000004678DC: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000004678E4: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000004678EC: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000004678F0: 36160082
	s_waitcnt lgkmcnt(3)                                       // 0000004678F4: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 0000004678F8: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000467900: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000467904: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000046790C: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000467910: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000467918: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 00000046791C: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000467924: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 00000046792C: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000467930: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000467934: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 00000046793C: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000467944: 7C941480
	.long 0xd44a0001                                           // 000000467948: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 00000046794C: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000467950: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000467958: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 00000046795C: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 000000467960: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 000000467964: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000467968: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000467970: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000467974: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000467978: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000046797C: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000467984: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000046798C: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000467994: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000046799C: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000004679A4: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004679AC: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004679B4: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004679BC: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000004679C4: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004679CC: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000004679D4: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004679DC: 7E2402FA FF016103
	v_cndmask_b32_e64 v19, -v3, v3, vcc_lo                     // 0000004679E4: D5010013 21AA0703
	v_cndmask_b32_e64 v21, -v2, v2, vcc_lo                     // 0000004679EC: D5010015 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000004679F4: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 0000004679F8: C9080D07 03082108
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000467A00: 7E2802FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 000000467A08: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000467A10: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000467A14: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000467A1C: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 000000467A24: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000467A28: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000467A30: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000467A38: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 000000467A40: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000467A44: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000467A4C: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 000000467A54: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000467A58: D5010008 21AA1108
	v_add_f32_e32 v13, v21, v20                                // 000000467A60: 061A2915
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000467A64: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 000000467A6C: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000467A70: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000467A78: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000467A80: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 000000467A88: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000467A8C: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000467A94: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 000000467A9C: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000467AA0: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000467AA8: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 000000467AB0: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000467AB4: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000467ABC: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 000000467AC4: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 000000467AC8: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 000000467ACC: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000467AD4: 7E0402FA FF016402
	v_add_f32_e32 v6, v6, v11                                  // 000000467ADC: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000467AE0: 7E1602FA FF016408
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 000000467AE8: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000467AF0: BF870234
	v_add_f32_e32 v7, v7, v2                                   // 000000467AF4: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000467AF8: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000467B00: D5010004 20060904
	v_add_f32_e32 v14, v14, v11                                // 000000467B08: 061C170E
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000467B0C: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000467B14: 7E0A02FA FF016807
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000467B1C: 7E1002FA FF016806
	v_add_f32_e32 v4, v4, v10                                  // 000000467B24: 06081504
	v_add_f32_e32 v10, v19, v18                                // 000000467B28: 06142513
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000467B2C: BF8700A1
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000467B30: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000467B38: D501000A 21AA150A
	v_add_f32_e32 v10, v10, v12                                // 000000467B40: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 000000467B44: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000467B48: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000467B50: D5010009 20061309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000467B58: BF870214
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000467B5C: 7E1E02FA FF01640A
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000467B64: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000467B6C: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000467B74: D501000C 2006190C
	v_add_f32_e32 v16, v9, v13                                 // 000000467B7C: 06201B09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000467B80: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000467B88: BF870214
	v_add_f32_e32 v15, v10, v15                                // 000000467B8C: 061E1F0A
	v_add_f32_e32 v17, v12, v17                                // 000000467B90: 0622230C
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000467B94: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000467B9C: 7E1602FA FF016810
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000467BA4: BF870214
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000467BA8: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000467BB0: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 000000467BB8: 8B7E007E
	s_cbranch_execz 171                                        // 000000467BBC: BFA500AB <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x346c>
	v_lshl_or_b32 v18, s2, 7, v1                               // 000000467BC0: D6560012 04050E02
	.long 0x7f2c3880                                           // 000000467BC8: 7F2C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000467BCC: BF870112
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000467BD0: 3426249F
	.long 0x7f2e3996                                           // 000000467BD4: 7F2E3996
	.long 0x7f303996                                           // 000000467BD8: 7F303996
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000467BDC: BF870093
	.long 0xd73c0012                                           // 000000467BE0: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000467BE4: 02022481
	.long 0xd7006a14                                           // 000000467BE8: D7006A14
	v_cndmask_b32_e32 v1, s14, v18, vcc_lo                     // 000000467BEC: 0202240E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000467BF0: BF870001
	v_add_co_ci_u32_e64 v21, null, s15, v19, vcc_lo            // 000000467BF4: D5207C15 01AA260F
	s_clause 0x7                                               // 000000467BFC: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000467C00: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000467C08: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 000000467C10: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 000000467C18: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 000000467C20: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 000000467C28: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 000000467C30: DC8200C0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:224          // 000000467C38: DC8200E0 147C0014
	v_and_b32_e32 v21, 8, v0                                   // 000000467C40: 362A0088
	v_mad_i64_i32 v[0:1], null, s26, v66, 0                    // 000000467C44: D6FF7C00 0202841A
	s_waitcnt vmcnt(0)                                         // 000000467C4C: BF8903F7
	.long 0x7f283996                                           // 000000467C50: 7F283996
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000467C54: BF870223
	v_cmp_eq_u32_e32 vcc_lo, 0, v21                            // 000000467C58: 7C942A80
	.long 0x7f2a3996                                           // 000000467C5C: 7F2A3996
	.long 0xd73c0000                                           // 000000467C60: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000467C64: 02020081
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000467C68: D5010007 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000467C70: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000467C78: D5010004 21AA0904
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000467C80: D5010006 21AA0D06
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000467C88: D501000E 21AA1D0E
	v_add_f32_e32 v5, v7, v5                                   // 000000467C90: 060A0B07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 000000467C94: D5010007 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000467C9C: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000467CA4: D501000F 21AA1F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000467CAC: BF870124
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 000000467CB0: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v8 :: v_dual_add_f32 v4, v4, v9     // 000000467CBC: C9081106 05041304
	v_dual_add_f32 v7, v7, v11 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 000000467CC4: C9061707 070204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000467CD0: BF870194
	v_dual_add_f32 v8, v15, v12 :: v_dual_add_f32 v9, v16, v13 // 000000467CD4: C908190F 08081B10
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000467CDC: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000467CE4: BF870193
	v_dual_add_f32 v6, v14, v10 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 000000467CE8: C906150E 06060EFF 3DB504F3
	v_dual_mul_f32 v8, 0x3db504f3, v8 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000467CF4: C8C610FF 08040AFF 3DB504F3
	.long 0xd7006a00                                           // 000000467D00: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 000000467D04: 02020014
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000467D08: BF8701A3
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000467D0C: 100C0CFF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 000000467D14: D5207C01 01AA0215
	.long 0xd7006a00                                           // 000000467D1C: D7006A00
	v_cndmask_b32_e32 v1, v0, v18, vcc_lo                      // 000000467D20: 02022500
	s_delay_alu instid0(VALU_DEP_1)                            // 000000467D24: BF870001
	v_add_co_ci_u32_e64 v1, null, v1, v19, vcc_lo              // 000000467D28: D5207C01 01AA2701
	v_fma_mix_f32 v3, v22, v3, neg(0) op_sel_hi:[1,0,0]        // 000000467D30: CC200003 8A020716
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 000000467D38: CC200002 8A020517
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 000000467D40: CC200005 8A020B18
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 000000467D48: CC200004 8A020919
	v_fma_mix_f32 v6, v26, v6, neg(0) op_sel_hi:[1,0,0]        // 000000467D50: CC200006 8A020D1A
	.long 0x7e2c3983                                           // 000000467D58: 7E2C3983
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000467D5C: 101212FF 3DB504F3
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 000000467D64: CC200007 8A020F1B
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000467D6C: CC200008 8A02111C
	.long 0x7e2a3985                                           // 000000467D74: 7E2A3985
	v_and_b32_e32 v10, 1, v22                                  // 000000467D78: 36142C81
	.long 0x7e2c3984                                           // 000000467D7C: 7E2C3984
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 000000467D80: CC200009 8A021314
	.long 0x7e283982                                           // 000000467D88: 7E283982
	.long 0x7e2e3986                                           // 000000467D8C: 7E2E3986
	.long 0x7e303988                                           // 000000467D90: 7E303988
	v_and_b32_e32 v11, 1, v22                                  // 000000467D94: 36162C81
	.long 0x7e2c3987                                           // 000000467D98: 7E2C3987
	v_and_b32_e32 v12, 1, v20                                  // 000000467D9C: 36182881
	v_and_b32_e32 v13, 1, v21                                  // 000000467DA0: 361A2A81
	v_and_b32_e32 v14, 1, v23                                  // 000000467DA4: 361C2E81
	v_and_b32_e32 v16, 1, v24                                  // 000000467DA8: 36203081
	v_and_b32_e32 v15, 1, v22                                  // 000000467DAC: 361E2C81
	.long 0x7e2c3989                                           // 000000467DB0: 7E2C3989
	v_add3_u32 v3, v3, v10, 0x7fff                             // 000000467DB4: D6550003 03FE1503 00007FFF
	v_add3_u32 v2, v2, v12, 0x7fff                             // 000000467DC0: D6550002 03FE1902 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 000000467DCC: D6550005 03FE1B05 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 000000467DD8: D6550004 03FE1704 00007FFF
	v_and_b32_e32 v10, 1, v22                                  // 000000467DE4: 36142C81
	v_add3_u32 v6, v6, v14, 0x7fff                             // 000000467DE8: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 000000467DF4: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000467E00: D6550007 03FE1F07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000467E0C: BF870004
	v_add3_u32 v9, v9, v10, 0x7fff                             // 000000467E10: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 000000467E1C: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000467E20: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 000000467E28: DC960020 007C0300
	global_store_d16_hi_b16 v[0:1], v5, off offset:64          // 000000467E30: DC960040 007C0500
	global_store_d16_hi_b16 v[0:1], v4, off offset:96          // 000000467E38: DC960060 007C0400
	global_store_d16_hi_b16 v[0:1], v6, off offset:128         // 000000467E40: DC960080 007C0600
	global_store_d16_hi_b16 v[0:1], v7, off offset:160         // 000000467E48: DC9600A0 007C0700
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 000000467E50: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:224         // 000000467E58: DC9600E0 007C0900
	s_nop 0                                                    // 000000467E60: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000467E64: BFB60003
	s_endpgm                                                   // 000000467E68: BFB00000
	s_nop 0                                                    // 000000467E6C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000467E70: BFB60003
	s_endpgm                                                   // 000000467E74: BFB00000
		...

