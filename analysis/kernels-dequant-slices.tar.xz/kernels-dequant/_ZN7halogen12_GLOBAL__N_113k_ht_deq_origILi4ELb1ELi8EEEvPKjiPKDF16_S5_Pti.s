00000000004ac400 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi4ELb1ELi8EEEvPKjiPKDF16_S5_Pti>:
; _ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi4ELb1ELi8EEEvPKjiPKDF16_S5_Pti():
	s_clause 0x1                                               // 0000004AC400: BF850001
	s_load_b32 s7, s[0:1], 0x28                                // 0000004AC404: F40001C0 F8000028
	s_load_b32 s6, s[0:1], 0x8                                 // 0000004AC40C: F4000180 F8000008
	v_bfe_u32 v3, v0, 4, 1                                     // 0000004AC414: D6100003 02050900
	v_and_b32_e32 v19, 15, v0                                  // 0000004AC41C: 3626008F
	v_lshrrev_b32_e32 v16, 7, v0                               // 0000004AC420: 32200087
	s_clause 0x2                                               // 0000004AC424: BF850002
	s_load_b64 s[12:13], s[0:1], null                          // 0000004AC428: F4040300 F8000000
	s_load_b128 s[8:11], s[0:1], 0x10                          // 0000004AC430: F4080200 F8000010
	s_load_b64 s[4:5], s[0:1], 0x20                            // 0000004AC438: F4040100 F8000020
	v_lshlrev_b32_e32 v1, 6, v3                                // 0000004AC440: 30020686
	v_lshlrev_b32_e32 v2, 1, v19                               // 0000004AC444: 30042681
	v_lshrrev_b32_e32 v18, 5, v0                               // 0000004AC448: 32240085
	v_and_b32_e32 v17, 31, v0                                  // 0000004AC44C: 3622009F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004AC450: BF870113
	v_or3_b32 v2, v2, v16, v1                                  // 0000004AC454: D6580002 04062102
	v_lshlrev_b32_e32 v20, 5, v17                              // 0000004AC45C: 30282285
	v_lshlrev_b32_e32 v24, 2, v17                              // 0000004AC460: 30302282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004AC464: BF870002
	v_add_nc_u32_e32 v21, 0x3f0, v20                           // 0000004AC468: 4A2A28FF 000003F0
	s_waitcnt lgkmcnt(0)                                       // 0000004AC470: BF89FC07
	s_cmp_eq_u32 s7, 0                                         // 0000004AC474: BF068007
	s_cselect_b32 s0, s3, s2                                   // 0000004AC478: 98000203
	s_cselect_b32 s3, s2, s3                                   // 0000004AC47C: 98030302
	s_lshl_b32 s2, s0, 7                                       // 0000004AC480: 84028700
	s_lshl_b32 s1, s3, 7                                       // 0000004AC484: 84018703
	v_or_b32_e32 v1, s2, v2                                    // 0000004AC488: 38020402
	v_or_b32_e32 v6, s1, v2                                    // 0000004AC48C: 380C0401
	v_lshl_or_b32 v4, s0, 3, v18                               // 0000004AC490: D6560004 04490600
	s_ashr_i32 s7, s6, 31                                      // 0000004AC498: 86079F06
	v_lshrrev_b32_e32 v10, 5, v21                              // 0000004AC49C: 32142A85
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000004AC4A0: 3404029F
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000004AC4A4: 340E0C9F
	s_lshr_b32 s0, s7, 28                                      // 0000004AC4A8: 85009C07
	v_ashrrev_i32_e32 v5, 31, v4                               // 0000004AC4AC: 340A089F
	s_add_i32 s0, s6, s0                                       // 0000004AC4B0: 81000006
	.long 0xd73c0001                                           // 0000004AC4B4: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000004AC4B8: 02020281
	s_ashr_i32 s0, s0, 4                                       // 0000004AC4BC: 86008400
	.long 0xd73c0006                                           // 0000004AC4C0: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000004AC4C4: 02020C81
	v_mad_i64_i32 v[4:5], null, s3, s0, v[4:5]                 // 0000004AC4C8: D6FF7C04 04100003
	v_add_nc_u32_e32 v10, 1, v10                               // 0000004AC4D0: 4A141481
	v_lshrrev_b32_e32 v11, 3, v21                              // 0000004AC4D4: 32162A83
	.long 0xd7006a08                                           // 0000004AC4D8: D7006A08
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000004AC4DC: 02020208
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004AC4E0: BF8700A1
	v_add_co_ci_u32_e64 v9, null, s9, v2, vcc_lo               // 0000004AC4E4: D5207C09 01AA0409
	.long 0xd7006a06                                           // 0000004AC4EC: D7006A06
	v_cndmask_b32_e32 v1, s10, v6, vcc_lo                      // 0000004AC4F0: 02020C0A
	v_add_co_ci_u32_e64 v7, null, s11, v7, vcc_lo              // 0000004AC4F4: D5207C07 01AA0E0B
	.long 0xd73c0004                                           // 0000004AC4FC: D73C0004
	v_cndmask_b32_e32 v1, 10, v4, vcc_lo                       // 0000004AC500: 0202088A
	s_clause 0x1                                               // 0000004AC504: BF850001
	global_load_d16_hi_b16 v1, v[6:7], off                     // 0000004AC508: DC8E0000 017C0006
	global_load_d16_b16 v1, v[6:7], off offset:64              // 0000004AC510: DC820040 017C0006
	v_and_b32_e32 v7, 31, v10                                  // 0000004AC518: 360E149F
	v_and_b32_e32 v22, 0x7c, v11                               // 0000004AC51C: 362C16FF 0000007C
	.long 0xd7006a06                                           // 0000004AC524: D7006A06
	v_cndmask_b32_e32 v1, s12, v4, vcc_lo                      // 0000004AC528: 0202080C
	s_clause 0x1                                               // 0000004AC52C: BF850001
	global_load_d16_hi_b16 v2, v[8:9], off                     // 0000004AC530: DC8E0000 027C0008
	global_load_d16_b16 v2, v[8:9], off offset:64              // 0000004AC538: DC820040 027C0008
	v_add_co_ci_u32_e64 v8, null, s13, v5, vcc_lo              // 0000004AC540: D5207C08 01AA0A0D
	v_lshlrev_b32_e32 v23, 2, v7                               // 0000004AC548: 302E0E82
	.long 0xd7006a19                                           // 0000004AC54C: D7006A19
	v_cndmask_b32_e32 v1, v6, v22, vcc_lo                      // 0000004AC550: 02022D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004AC554: BF870191
	v_add_co_ci_u32_e64 v26, null, 0, v8, vcc_lo               // 0000004AC558: D5207C1A 01AA1080
	.long 0xd7006a0e                                           // 0000004AC560: D7006A0E
	v_cndmask_b32_e32 v1, v6, v23, vcc_lo                      // 0000004AC564: 02022F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004AC568: BF8700A1
	v_add_co_ci_u32_e64 v15, null, 0, v8, vcc_lo               // 0000004AC56C: D5207C0F 01AA1080
	.long 0xd7006a0a                                           // 0000004AC574: D7006A0A
	v_cndmask_b32_e32 v1, v6, v24, vcc_lo                      // 0000004AC578: 02023106
	v_add_co_ci_u32_e64 v11, null, 0, v8, vcc_lo               // 0000004AC57C: D5207C0B 01AA1080
	s_clause 0x7                                               // 0000004AC584: BF850007
	global_load_b32 v5, v[25:26], off                          // 0000004AC588: DC520000 057C0019
	global_load_b32 v4, v[14:15], off                          // 0000004AC590: DC520000 047C000E
	global_load_b32 v7, v[25:26], off offset:128               // 0000004AC598: DC520080 077C0019
	global_load_b32 v9, v[25:26], off offset:256               // 0000004AC5A0: DC520100 097C0019
	global_load_b32 v13, v[25:26], off offset:384              // 0000004AC5A8: DC520180 0D7C0019
	global_load_b32 v27, v[25:26], off offset:512              // 0000004AC5B0: DC520200 1B7C0019
	global_load_b32 v29, v[25:26], off offset:640              // 0000004AC5B8: DC520280 1D7C0019
	global_load_b32 v31, v[25:26], off offset:768              // 0000004AC5C0: DC520300 1F7C0019
	.long 0xd7006a19                                           // 0000004AC5C8: D7006A19
	v_cndmask_b32_e32 v1, 0x380, v6, vcc_lo                    // 0000004AC5CC: 02020CFF 00000380
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004AC5D4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v8, vcc_lo               // 0000004AC5D8: D5207C20 01AA1080
	s_clause 0x7                                               // 0000004AC5E0: BF850007
	global_load_b32 v33, v[10:11], off                         // 0000004AC5E4: DC520000 217C000A
	global_load_b32 v6, v[14:15], off offset:128               // 0000004AC5EC: DC520080 067C000E
	global_load_b32 v34, v[10:11], off offset:128              // 0000004AC5F4: DC520080 227C000A
	global_load_b32 v8, v[14:15], off offset:256               // 0000004AC5FC: DC520100 087C000E
	global_load_b32 v12, v[14:15], off offset:384              // 0000004AC604: DC520180 0C7C000E
	global_load_b32 v26, v[14:15], off offset:512              // 0000004AC60C: DC520200 1A7C000E
	global_load_b32 v28, v[14:15], off offset:640              // 0000004AC614: DC520280 1C7C000E
	global_load_b32 v30, v[14:15], off offset:768              // 0000004AC61C: DC520300 1E7C000E
	.long 0xd7006a0e                                           // 0000004AC624: D7006A0E
	v_cndmask_b32_e32 v1, v25, v22, vcc_lo                     // 0000004AC628: 02022D19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004AC62C: BF8700A1
	v_add_co_ci_u32_e64 v15, null, 0, v32, vcc_lo              // 0000004AC630: D5207C0F 01AA4080
	.long 0xd7006a16                                           // 0000004AC638: D7006A16
	v_cndmask_b32_e32 v1, v25, v23, vcc_lo                     // 0000004AC63C: 02022F19
	v_add_co_ci_u32_e64 v23, null, 0, v32, vcc_lo              // 0000004AC640: D5207C17 01AA4080
	.long 0xd7006a18                                           // 0000004AC648: D7006A18
	v_cndmask_b32_e32 v1, v25, v24, vcc_lo                     // 0000004AC64C: 02023119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004AC650: BF870001
	v_add_co_ci_u32_e64 v25, null, 0, v32, vcc_lo              // 0000004AC654: D5207C19 01AA4080
	s_clause 0x7                                               // 0000004AC65C: BF850007
	global_load_b32 v35, v[10:11], off offset:256              // 0000004AC660: DC520100 237C000A
	global_load_b32 v37, v[10:11], off offset:384              // 0000004AC668: DC520180 257C000A
	global_load_b32 v39, v[10:11], off offset:512              // 0000004AC670: DC520200 277C000A
	global_load_b32 v41, v[10:11], off offset:640              // 0000004AC678: DC520280 297C000A
	global_load_b32 v43, v[10:11], off offset:768              // 0000004AC680: DC520300 2B7C000A
	global_load_b32 v15, v[14:15], off                         // 0000004AC688: DC520000 0F7C000E
	global_load_b32 v14, v[22:23], off                         // 0000004AC690: DC520000 0E7C0016
	global_load_b32 v45, v[24:25], off                         // 0000004AC698: DC520000 2D7C0018
	v_lshlrev_b32_e32 v10, 3, v3                               // 0000004AC6A0: 30140683
	v_or_b32_e32 v23, 0x70, v19                                // 0000004AC6A4: 382E26FF 00000070
	v_and_b32_e32 v21, 0x7e0, v21                              // 0000004AC6AC: 362A2AFF 000007E0
	v_or_b32_e32 v11, 16, v19                                  // 0000004AC6B4: 38162690
	v_lshlrev_b32_e32 v22, 9, v19                              // 0000004AC6B8: 302C2689
	v_lshl_or_b32 v10, v18, 4, v10                             // 0000004AC6BC: D656000A 04290912
	v_and_b32_e32 v38, 31, v23                                 // 0000004AC6C4: 364C2E9F
	v_sub_nc_u32_e32 v20, v21, v20                             // 0000004AC6C8: 4C282915
	v_lshlrev_b32_e32 v24, 9, v11                              // 0000004AC6CC: 30301689
	v_or_b32_e32 v25, 0x4000, v22                              // 0000004AC6D0: 38322CFF 00004000
	v_xor_b32_e32 v40, v10, v19                                // 0000004AC6D8: 3A50270A
	v_or_b32_e32 v42, 1, v10                                   // 0000004AC6DC: 38541481
	v_or_b32_e32 v44, 2, v10                                   // 0000004AC6E0: 38581482
	v_or_b32_e32 v46, 3, v10                                   // 0000004AC6E4: 385C1483
	v_or_b32_e32 v47, 4, v10                                   // 0000004AC6E8: 385E1484
	v_or_b32_e32 v48, 5, v10                                   // 0000004AC6EC: 38601485
	v_or_b32_e32 v49, 6, v10                                   // 0000004AC6F0: 38621486
	v_or_b32_e32 v50, 7, v10                                   // 0000004AC6F4: 38641487
	v_lshlrev_b32_e32 v21, 2, v40                              // 0000004AC6F8: 302A5082
	v_xor_b32_e32 v40, v42, v19                                // 0000004AC6FC: 3A50272A
	v_xor_b32_e32 v54, v44, v19                                // 0000004AC700: 3A6C272C
	v_xor_b32_e32 v55, v46, v19                                // 0000004AC704: 3A6E272E
	v_xor_b32_e32 v56, v47, v19                                // 0000004AC708: 3A70272F
	v_xor_b32_e32 v57, v48, v19                                // 0000004AC70C: 3A722730
	v_xor_b32_e32 v58, v49, v19                                // 0000004AC710: 3A742731
	v_xor_b32_e32 v19, v50, v19                                // 0000004AC714: 3A262732
	v_xor_b32_e32 v51, v10, v11                                // 0000004AC718: 3A66170A
	v_xor_b32_e32 v59, v42, v11                                // 0000004AC71C: 3A76172A
	v_xor_b32_e32 v60, v44, v11                                // 0000004AC720: 3A78172C
	v_xor_b32_e32 v61, v46, v11                                // 0000004AC724: 3A7A172E
	v_xor_b32_e32 v62, v47, v11                                // 0000004AC728: 3A7C172F
	v_xor_b32_e32 v63, v48, v11                                // 0000004AC72C: 3A7E1730
	v_xor_b32_e32 v64, v49, v11                                // 0000004AC730: 3A801731
	v_xor_b32_e32 v11, v50, v11                                // 0000004AC734: 3A161732
	v_or_b32_e32 v32, 0x8000, v22                              // 0000004AC738: 38402CFF 00008000
	v_or_b32_e32 v36, 0xc000, v22                              // 0000004AC740: 38482CFF 0000C000
	v_xor_b32_e32 v10, v10, v38                                // 0000004AC748: 3A144D0A
	v_xor_b32_e32 v42, v42, v38                                // 0000004AC74C: 3A544D2A
	v_xor_b32_e32 v44, v44, v38                                // 0000004AC750: 3A584D2C
	v_xor_b32_e32 v46, v46, v38                                // 0000004AC754: 3A5C4D2E
	v_xor_b32_e32 v47, v47, v38                                // 0000004AC758: 3A5E4D2F
	v_xor_b32_e32 v48, v48, v38                                // 0000004AC75C: 3A604D30
	v_xor_b32_e32 v49, v49, v38                                // 0000004AC760: 3A624D31
	v_xor_b32_e32 v38, v50, v38                                // 0000004AC764: 3A4C4D32
	v_add_nc_u32_e32 v50, 0xfffffc3c, v20                      // 0000004AC768: 4A6428FF FFFFFC3C
	v_add_nc_u32_e32 v65, 0xfffffc38, v20                      // 0000004AC770: 4A8228FF FFFFFC38
	v_add_nc_u32_e32 v66, 0xfffffc34, v20                      // 0000004AC778: 4A8428FF FFFFFC34
	v_add_nc_u32_e32 v67, 0xfffffc30, v20                      // 0000004AC780: 4A8628FF FFFFFC30
	v_lshlrev_b32_e32 v20, 2, v40                              // 0000004AC788: 30285082
	v_lshlrev_b32_e32 v19, 2, v19                              // 0000004AC78C: 30262682
	v_lshlrev_b32_e32 v40, 2, v54                              // 0000004AC790: 30506C82
	v_lshlrev_b32_e32 v54, 2, v55                              // 0000004AC794: 306C6E82
	v_lshlrev_b32_e32 v55, 2, v56                              // 0000004AC798: 306E7082
	v_lshlrev_b32_e32 v56, 2, v57                              // 0000004AC79C: 30707282
	v_lshlrev_b32_e32 v57, 2, v58                              // 0000004AC7A0: 30727482
	v_lshlrev_b32_e32 v23, 9, v23                              // 0000004AC7A4: 302E2E89
	v_lshlrev_b32_e32 v51, 2, v51                              // 0000004AC7A8: 30666682
	v_lshlrev_b32_e32 v59, 2, v59                              // 0000004AC7AC: 30767682
	v_lshlrev_b32_e32 v60, 2, v60                              // 0000004AC7B0: 30787882
	v_lshlrev_b32_e32 v61, 2, v61                              // 0000004AC7B4: 307A7A82
	v_lshlrev_b32_e32 v62, 2, v62                              // 0000004AC7B8: 307C7C82
	v_lshlrev_b32_e32 v63, 2, v63                              // 0000004AC7BC: 307E7E82
	v_lshlrev_b32_e32 v64, 2, v64                              // 0000004AC7C0: 30808082
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000004AC7C4: 30161682
	v_add_nc_u32_e32 v76, v22, v20                             // 0000004AC7C8: 4A982916
	v_add_nc_u32_e32 v82, v22, v19                             // 0000004AC7CC: 4AA42716
	v_add_nc_u32_e32 v90, v25, v20                             // 0000004AC7D0: 4AB42919
	v_add_nc_u32_e32 v96, v25, v19                             // 0000004AC7D4: 4AC02719
	v_add_nc_u32_e32 v103, v32, v20                            // 0000004AC7D8: 4ACE2920
	v_add_nc_u32_e32 v109, v32, v19                            // 0000004AC7DC: 4ADA2720
	v_add_nc_u32_e32 v110, v36, v20                            // 0000004AC7E0: 4ADC2924
	v_add_nc_u32_e32 v112, v36, v19                            // 0000004AC7E4: 4AE02724
	v_add_nc_u32_e32 v68, v22, v21                             // 0000004AC7E8: 4A882B16
	v_add_nc_u32_e32 v69, v25, v21                             // 0000004AC7EC: 4A8A2B19
	v_add_nc_u32_e32 v71, v32, v21                             // 0000004AC7F0: 4A8E2B20
	v_add_nc_u32_e32 v72, v36, v21                             // 0000004AC7F4: 4A902B24
	v_add_nc_u32_e32 v77, v22, v40                             // 0000004AC7F8: 4A9A5116
	v_add_nc_u32_e32 v78, v22, v54                             // 0000004AC7FC: 4A9C6D16
	v_add_nc_u32_e32 v79, v22, v55                             // 0000004AC800: 4A9E6F16
	v_add_nc_u32_e32 v80, v22, v56                             // 0000004AC804: 4AA07116
	v_add_nc_u32_e32 v81, v22, v57                             // 0000004AC808: 4AA27316
	v_lshl_add_u32 v10, v10, 2, v23                            // 0000004AC80C: D646000A 045D050A
	v_lshl_add_u32 v73, v42, 2, v23                            // 0000004AC814: D6460049 045D052A
	v_lshl_add_u32 v74, v44, 2, v23                            // 0000004AC81C: D646004A 045D052C
	v_lshl_add_u32 v46, v46, 2, v23                            // 0000004AC824: D646002E 045D052E
	v_lshl_add_u32 v47, v47, 2, v23                            // 0000004AC82C: D646002F 045D052F
	v_lshl_add_u32 v48, v48, 2, v23                            // 0000004AC834: D6460030 045D0530
	v_lshl_add_u32 v49, v49, 2, v23                            // 0000004AC83C: D6460031 045D0531
	v_lshl_add_u32 v75, v38, 2, v23                            // 0000004AC844: D646004B 045D0526
	v_or_b32_e32 v52, 0x4000, v24                              // 0000004AC84C: 386830FF 00004000
	v_or_b32_e32 v53, 0x8000, v24                              // 0000004AC854: 386A30FF 00008000
	v_add_nc_u32_e32 v58, v24, v51                             // 0000004AC85C: 4A746718
	v_add_nc_u32_e32 v83, v24, v59                             // 0000004AC860: 4AA67718
	v_add_nc_u32_e32 v84, v24, v60                             // 0000004AC864: 4AA87918
	v_add_nc_u32_e32 v85, v24, v61                             // 0000004AC868: 4AAA7B18
	v_add_nc_u32_e32 v86, v24, v62                             // 0000004AC86C: 4AAC7D18
	v_add_nc_u32_e32 v87, v24, v63                             // 0000004AC870: 4AAE7F18
	v_add_nc_u32_e32 v88, v24, v64                             // 0000004AC874: 4AB08118
	v_add_nc_u32_e32 v89, v24, v11                             // 0000004AC878: 4AB21718
	v_add_nc_u32_e32 v91, v25, v40                             // 0000004AC87C: 4AB65119
	v_add_nc_u32_e32 v92, v25, v54                             // 0000004AC880: 4AB86D19
	v_add_nc_u32_e32 v93, v25, v55                             // 0000004AC884: 4ABA6F19
	v_add_nc_u32_e32 v94, v25, v56                             // 0000004AC888: 4ABC7119
	v_add_nc_u32_e32 v95, v25, v57                             // 0000004AC88C: 4ABE7319
	v_add_nc_u32_e32 v104, v32, v40                            // 0000004AC890: 4AD05120
	v_add_nc_u32_e32 v105, v32, v54                            // 0000004AC894: 4AD26D20
	v_add_nc_u32_e32 v106, v32, v55                            // 0000004AC898: 4AD46F20
	v_add_nc_u32_e32 v107, v32, v56                            // 0000004AC89C: 4AD67120
	v_add_nc_u32_e32 v108, v32, v57                            // 0000004AC8A0: 4AD87320
	v_add_nc_u32_e32 v111, v36, v40                            // 0000004AC8A4: 4ADE5124
	v_add_nc_u32_e32 v54, v36, v54                             // 0000004AC8A8: 4A6C6D24
	v_add_nc_u32_e32 v55, v36, v55                             // 0000004AC8AC: 4A6E6F24
	v_add_nc_u32_e32 v56, v36, v56                             // 0000004AC8B0: 4A707124
	v_add_nc_u32_e32 v57, v36, v57                             // 0000004AC8B4: 4A727324
	v_add_nc_u32_e32 v70, v52, v51                             // 0000004AC8B8: 4A8C6734
	v_add_nc_u32_e32 v51, v53, v51                             // 0000004AC8BC: 4A666735
	v_add_nc_u32_e32 v97, v52, v59                             // 0000004AC8C0: 4AC27734
	v_add_nc_u32_e32 v98, v52, v60                             // 0000004AC8C4: 4AC47934
	v_add_nc_u32_e32 v99, v52, v61                             // 0000004AC8C8: 4AC67B34
	v_add_nc_u32_e32 v100, v52, v62                            // 0000004AC8CC: 4AC87D34
	v_add_nc_u32_e32 v101, v52, v63                            // 0000004AC8D0: 4ACA7F34
	v_add_nc_u32_e32 v102, v52, v64                            // 0000004AC8D4: 4ACC8134
	v_add_nc_u32_e32 v52, v52, v11                             // 0000004AC8D8: 4A681734
	v_add_nc_u32_e32 v59, v53, v59                             // 0000004AC8DC: 4A767735
	v_add_nc_u32_e32 v60, v53, v60                             // 0000004AC8E0: 4A787935
	v_add_nc_u32_e32 v61, v53, v61                             // 0000004AC8E4: 4A7A7B35
	v_add_nc_u32_e32 v62, v53, v62                             // 0000004AC8E8: 4A7C7D35
	v_add_nc_u32_e32 v63, v53, v63                             // 0000004AC8EC: 4A7E7F35
	v_add_nc_u32_e32 v64, v53, v64                             // 0000004AC8F0: 4A808135
	v_add_nc_u32_e32 v53, v53, v11                             // 0000004AC8F4: 4A6A1735
	s_movk_i32 s3, 0x1eee                                      // 0000004AC8F8: B0031EEE
	.long 0xd4490000                                           // 0000004AC8FC: D4490000
	v_cndmask_b32_e32 v1, 0x1ff, v0, vcc_lo                    // 0000004AC900: 020200FF 000001FF
	v_and_b32_e32 v3, 0x7f, v0                                 // 0000004AC908: 360600FF 0000007F
	v_cmp_gt_u32_e32 vcc_lo, 0x200, v0                         // 0000004AC910: 7C9800FF 00000200
	s_waitcnt vmcnt(22)                                        // 0000004AC918: BF895BF7
	.long 0xd73d0013                                           // 0000004AC91C: D73D0013
	v_cndmask_b32_e32 v1, v50, v4, vcc_lo                      // 0000004AC920: 02020932
	.long 0xd73d0014                                           // 0000004AC924: D73D0014
	v_cndmask_b32_e32 v1, v65, v4, vcc_lo                      // 0000004AC928: 02020941
	.long 0xd73d0015                                           // 0000004AC92C: D73D0015
	v_cndmask_b32_e32 v1, v66, v4, vcc_lo                      // 0000004AC930: 02020942
	.long 0xd73d0004                                           // 0000004AC934: D73D0004
	v_cndmask_b32_e32 v1, v67, v4, vcc_lo                      // 0000004AC938: 02020943
	s_waitcnt vmcnt(15)                                        // 0000004AC93C: BF893FF7
	v_bfe_u32 v44, v33, 12, 16                                 // 0000004AC940: D610002C 02411921
	s_waitcnt vmcnt(14)                                        // 0000004AC948: BF893BF7
	.long 0xd73d0016                                           // 0000004AC94C: D73D0016
	v_cndmask_b32_e32 v1, v50, v6, vcc_lo                      // 0000004AC950: 02020D32
	.long 0xd73d0017                                           // 0000004AC954: D73D0017
	v_cndmask_b32_e32 v1, v65, v6, vcc_lo                      // 0000004AC958: 02020D41
	v_bfe_u32 v113, v33, 8, 16                                 // 0000004AC95C: D6100071 02411121
	v_bfe_u32 v114, v33, 4, 16                                 // 0000004AC964: D6100072 02410921
	v_and_b32_e32 v115, 0xffff, v33                            // 0000004AC96C: 36E642FF 0000FFFF
	.long 0xd73d0018                                           // 0000004AC974: D73D0018
	v_cndmask_b32_e32 v1, v66, v6, vcc_lo                      // 0000004AC978: 02020D42
	.long 0xd73d0005                                           // 0000004AC97C: D73D0005
	v_cndmask_b32_e32 v1, v67, v6, vcc_lo                      // 0000004AC980: 02020D43
	s_waitcnt vmcnt(12)                                        // 0000004AC984: BF8933F7
	.long 0xd73d0020                                           // 0000004AC988: D73D0020
	v_cndmask_b32_e32 v1, v65, v8, vcc_lo                      // 0000004AC98C: 02021141
	v_bfe_u32 v116, v34, 12, 16                                // 0000004AC990: D6100074 02411922
	v_bfe_u32 v117, v34, 8, 16                                 // 0000004AC998: D6100075 02411122
	v_bfe_u32 v118, v34, 4, 16                                 // 0000004AC9A0: D6100076 02410922
	v_and_b32_e32 v119, 0xffff, v34                            // 0000004AC9A8: 36EE44FF 0000FFFF
	.long 0xd73d0006                                           // 0000004AC9B0: D73D0006
	v_cndmask_b32_e32 v1, v50, v8, vcc_lo                      // 0000004AC9B4: 02021132
	.long 0xd73d0021                                           // 0000004AC9B8: D73D0021
	v_cndmask_b32_e32 v1, v66, v8, vcc_lo                      // 0000004AC9BC: 02021142
	.long 0xd73d0007                                           // 0000004AC9C0: D73D0007
	v_cndmask_b32_e32 v1, v67, v8, vcc_lo                      // 0000004AC9C4: 02021143
	s_waitcnt vmcnt(7)                                         // 0000004AC9C8: BF891FF7
	v_bfe_u32 v120, v35, 12, 16                                // 0000004AC9CC: D6100078 02411923
	v_bfe_u32 v121, v35, 8, 16                                 // 0000004AC9D4: D6100079 02411123
	v_bfe_u32 v122, v35, 4, 16                                 // 0000004AC9DC: D610007A 02410923
	v_and_b32_e32 v123, 0xffff, v35                            // 0000004AC9E4: 36F646FF 0000FFFF
	.long 0xd73d0022                                           // 0000004AC9EC: D73D0022
	v_cndmask_b32_e32 v1, v65, v12, vcc_lo                     // 0000004AC9F0: 02021941
	.long 0xd73d0008                                           // 0000004AC9F4: D73D0008
	v_cndmask_b32_e32 v1, v50, v12, vcc_lo                     // 0000004AC9F8: 02021932
	.long 0xd73d0023                                           // 0000004AC9FC: D73D0023
	v_cndmask_b32_e32 v1, v66, v12, vcc_lo                     // 0000004ACA00: 02021942
	.long 0xd73d000b                                           // 0000004ACA04: D73D000B
	v_cndmask_b32_e32 v1, v67, v12, vcc_lo                     // 0000004ACA08: 02021943
	s_waitcnt vmcnt(6)                                         // 0000004ACA0C: BF891BF7
	v_bfe_u32 v9, v37, 12, 16                                  // 0000004ACA10: D6100009 02411925
	v_bfe_u32 v124, v37, 8, 16                                 // 0000004ACA18: D610007C 02411125
	v_bfe_u32 v125, v37, 4, 16                                 // 0000004ACA20: D610007D 02410925
	v_and_b32_e32 v126, 0xffff, v37                            // 0000004ACA28: 36FC4AFF 0000FFFF
	.long 0xd73d0024                                           // 0000004ACA30: D73D0024
	v_cndmask_b32_e32 v1, v65, v26, vcc_lo                     // 0000004ACA34: 02023541
	.long 0xd73d000c                                           // 0000004ACA38: D73D000C
	v_cndmask_b32_e32 v1, v50, v26, vcc_lo                     // 0000004ACA3C: 02023532
	.long 0xd73d0025                                           // 0000004ACA40: D73D0025
	v_cndmask_b32_e32 v1, v66, v26, vcc_lo                     // 0000004ACA44: 02023542
	.long 0xd73d0019                                           // 0000004ACA48: D73D0019
	v_cndmask_b32_e32 v1, v67, v26, vcc_lo                     // 0000004ACA4C: 02023543
	s_waitcnt vmcnt(5)                                         // 0000004ACA50: BF8917F7
	v_bfe_u32 v13, v39, 12, 16                                 // 0000004ACA54: D610000D 02411927
	v_bfe_u32 v127, v39, 8, 16                                 // 0000004ACA5C: D610007F 02411127
	v_bfe_u32 v128, v39, 4, 16                                 // 0000004ACA64: D6100080 02410927
	v_and_b32_e32 v129, 0xffff, v39                            // 0000004ACA6C: 37024EFF 0000FFFF
	.long 0xd73d001a                                           // 0000004ACA74: D73D001A
	v_cndmask_b32_e32 v1, v50, v28, vcc_lo                     // 0000004ACA78: 02023932
	.long 0xd73d0026                                           // 0000004ACA7C: D73D0026
	v_cndmask_b32_e32 v1, v65, v28, vcc_lo                     // 0000004ACA80: 02023941
	.long 0xd73d0027                                           // 0000004ACA84: D73D0027
	v_cndmask_b32_e32 v1, v66, v28, vcc_lo                     // 0000004ACA88: 02023942
	.long 0xd73d001b                                           // 0000004ACA8C: D73D001B
	v_cndmask_b32_e32 v1, v67, v28, vcc_lo                     // 0000004ACA90: 02023943
	s_waitcnt vmcnt(4)                                         // 0000004ACA94: BF8913F7
	v_bfe_u32 v130, v41, 12, 16                                // 0000004ACA98: D6100082 02411929
	v_bfe_u32 v131, v41, 8, 16                                 // 0000004ACAA0: D6100083 02411129
	v_bfe_u32 v132, v41, 4, 16                                 // 0000004ACAA8: D6100084 02410929
	v_and_b32_e32 v133, 0xffff, v41                            // 0000004ACAB0: 370A52FF 0000FFFF
	.long 0xd73d001c                                           // 0000004ACAB8: D73D001C
	v_cndmask_b32_e32 v1, v50, v30, vcc_lo                     // 0000004ACABC: 02023D32
	.long 0xd73d0028                                           // 0000004ACAC0: D73D0028
	v_cndmask_b32_e32 v1, v65, v30, vcc_lo                     // 0000004ACAC4: 02023D41
	.long 0xd73d0029                                           // 0000004ACAC8: D73D0029
	v_cndmask_b32_e32 v1, v66, v30, vcc_lo                     // 0000004ACACC: 02023D42
	.long 0xd73d001d                                           // 0000004ACAD0: D73D001D
	v_cndmask_b32_e32 v1, v67, v30, vcc_lo                     // 0000004ACAD4: 02023D43
	s_waitcnt vmcnt(3)                                         // 0000004ACAD8: BF890FF7
	v_bfe_u32 v30, v43, 12, 16                                 // 0000004ACADC: D610001E 0241192B
	v_bfe_u32 v31, v43, 8, 16                                  // 0000004ACAE4: D610001F 0241112B
	v_bfe_u32 v42, v43, 4, 16                                  // 0000004ACAEC: D610002A 0241092B
	v_and_b32_e32 v43, 0xffff, v43                             // 0000004ACAF4: 365656FF 0000FFFF
	.long 0xd72c0086                                           // 0000004ACAFC: D72C0086
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000004ACB00: 020258FF 83DCD12D
	.long 0xd72c0088                                           // 0000004ACB08: D72C0088
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 0000004ACB0C: 02023CFF 83DCD12D
	.long 0xd72c0089                                           // 0000004ACB14: D72C0089
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 0000004ACB18: 02023EFF 83DCD12D
	.long 0xd72c008a                                           // 0000004ACB20: D72C008A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 0000004ACB24: 020254FF 83DCD12D
	.long 0xd72c008b                                           // 0000004ACB2C: D72C008B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 0000004ACB30: 020256FF 83DCD12D
	s_waitcnt vmcnt(1)                                         // 0000004ACB38: BF8907F7
	.long 0xd73d002a                                           // 0000004ACB3C: D73D002A
	v_cndmask_b32_e32 v1, v65, v14, vcc_lo                     // 0000004ACB40: 02021D41
	.long 0xd73d001e                                           // 0000004ACB44: D73D001E
	v_cndmask_b32_e32 v1, v50, v14, vcc_lo                     // 0000004ACB48: 02021D32
	.long 0xd73d002b                                           // 0000004ACB4C: D73D002B
	v_cndmask_b32_e32 v1, v66, v14, vcc_lo                     // 0000004ACB50: 02021D42
	v_and_b32_e32 v19, 0xffff, v19                             // 0000004ACB54: 362626FF 0000FFFF
	v_and_b32_e32 v22, 0xffff, v22                             // 0000004ACB5C: 362C2CFF 0000FFFF
	v_and_b32_e32 v24, 0xffff, v24                             // 0000004ACB64: 363030FF 0000FFFF
	v_and_b32_e32 v26, 0xffff, v26                             // 0000004ACB6C: 363434FF 0000FFFF
	v_and_b32_e32 v39, 0xffff, v39                             // 0000004ACB74: 364E4EFF 0000FFFF
	v_and_b32_e32 v28, 0xffff, v28                             // 0000004ACB7C: 363838FF 0000FFFF
	v_and_b32_e32 v21, 0xffff, v21                             // 0000004ACB84: 362A2AFF 0000FFFF
	v_and_b32_e32 v37, 0xffff, v37                             // 0000004ACB8C: 364A4AFF 0000FFFF
	v_and_b32_e32 v41, 0xffff, v41                             // 0000004ACB94: 365252FF 0000FFFF
	.long 0xd72c0087                                           // 0000004ACB9C: D72C0087
	v_cndmask_b32_e32 v1, 0x83dcd12d, v13, vcc_lo              // 0000004ACBA0: 02021AFF 83DCD12D
	.long 0xd73d000d                                           // 0000004ACBA8: D73D000D
	v_cndmask_b32_e32 v1, v67, v14, vcc_lo                     // 0000004ACBAC: 02021D43
	v_and_b32_e32 v6, 0xffff, v6                               // 0000004ACBB0: 360C0CFF 0000FFFF
	v_and_b32_e32 v33, 0xffff, v33                             // 0000004ACBB8: 364242FF 0000FFFF
	.long 0xd72c0071                                           // 0000004ACBC0: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 0000004ACBC4: 0202E2FF 83DCD12D
	.long 0xd72c0072                                           // 0000004ACBCC: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 0000004ACBD0: 0202E4FF 83DCD12D
	.long 0xd72c0073                                           // 0000004ACBD8: D72C0073
	v_cndmask_b32_e32 v1, 0x83dcd12d, v115, vcc_lo             // 0000004ACBDC: 0202E6FF 83DCD12D
	.long 0xd72c0074                                           // 0000004ACBE4: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 0000004ACBE8: 0202E8FF 83DCD12D
	.long 0xd72c0075                                           // 0000004ACBF0: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 0000004ACBF4: 0202EAFF 83DCD12D
	.long 0xd72c0076                                           // 0000004ACBFC: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 0000004ACC00: 0202ECFF 83DCD12D
	.long 0xd72c0077                                           // 0000004ACC08: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 0000004ACC0C: 0202EEFF 83DCD12D
	.long 0xd72c0078                                           // 0000004ACC14: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 0000004ACC18: 0202F0FF 83DCD12D
	.long 0xd72c0079                                           // 0000004ACC20: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 0000004ACC24: 0202F2FF 83DCD12D
	.long 0xd72c007a                                           // 0000004ACC2C: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 0000004ACC30: 0202F4FF 83DCD12D
	.long 0xd72c007b                                           // 0000004ACC38: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 0000004ACC3C: 0202F6FF 83DCD12D
	.long 0xd72c007d                                           // 0000004ACC44: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 0000004ACC48: 0202FAFF 83DCD12D
	.long 0xd72c0080                                           // 0000004ACC50: D72C0080
	v_cndmask_b32_e32 v1, 0x83dcd12d, v128, vcc_lo             // 0000004ACC54: 020300FF 83DCD12D
	.long 0xd72c0083                                           // 0000004ACC5C: D72C0083
	v_cndmask_b32_e32 v1, 0x83dcd12d, v131, vcc_lo             // 0000004ACC60: 020306FF 83DCD12D
	s_waitcnt vmcnt(0)                                         // 0000004ACC68: BF8903F7
	v_bfe_u32 v14, v45, 12, 16                                 // 0000004ACC6C: D610000E 0241192D
	v_bfe_u32 v31, v45, 4, 16                                  // 0000004ACC74: D610001F 0241092D
	v_and_b32_e32 v20, 0xffff, v20                             // 0000004ACC7C: 362828FF 0000FFFF
	v_and_b32_e32 v23, 0xffff, v23                             // 0000004ACC84: 362E2EFF 0000FFFF
	v_and_b32_e32 v5, 0xffff, v5                               // 0000004ACC8C: 360A0AFF 0000FFFF
	v_and_b32_e32 v8, 0xffff, v8                               // 0000004ACC94: 361010FF 0000FFFF
	v_and_b32_e32 v35, 0xffff, v35                             // 0000004ACC9C: 364646FF 0000FFFF
	v_and_b32_e32 v12, 0xffff, v12                             // 0000004ACCA4: 361818FF 0000FFFF
	v_and_b32_e32 v38, 0xffff, v38                             // 0000004ACCAC: 364C4CFF 0000FFFF
	v_and_b32_e32 v27, 0xffff, v27                             // 0000004ACCB4: 363636FF 0000FFFF
	v_and_b32_e32 v40, 0xffff, v40                             // 0000004ACCBC: 365050FF 0000FFFF
	.long 0xd72c0013                                           // 0000004ACCC4: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 0000004ACCC8: 020226FF 83DCD12D
	.long 0xd72c0016                                           // 0000004ACCD0: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 0000004ACCD4: 02022CFF 83DCD12D
	.long 0xd72c0018                                           // 0000004ACCDC: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 0000004ACCE0: 020230FF 83DCD12D
	.long 0xd72c001a                                           // 0000004ACCE8: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 0000004ACCEC: 020234FF 83DCD12D
	.long 0xd72c0027                                           // 0000004ACCF4: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000004ACCF8: 02024EFF 83DCD12D
	.long 0xd72c001c                                           // 0000004ACD00: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 0000004ACD04: 020238FF 83DCD12D
	v_and_b32_e32 v30, 0xffff, v30                             // 0000004ACD0C: 363C3CFF 0000FFFF
	v_and_b32_e32 v43, 0xffff, v43                             // 0000004ACD14: 365656FF 0000FFFF
	.long 0xd72c0009                                           // 0000004ACD1C: D72C0009
	v_cndmask_b32_e32 v1, 0x83dcd12d, v9, vcc_lo               // 0000004ACD20: 020212FF 83DCD12D
	.long 0xd72c007c                                           // 0000004ACD28: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 0000004ACD2C: 0202F8FF 83DCD12D
	.long 0xd72c007e                                           // 0000004ACD34: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 0000004ACD38: 0202FCFF 83DCD12D
	.long 0xd72c007f                                           // 0000004ACD40: D72C007F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 0000004ACD44: 0202FEFF 83DCD12D
	.long 0xd72c0081                                           // 0000004ACD4C: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 0000004ACD50: 020302FF 83DCD12D
	.long 0xd72c0082                                           // 0000004ACD58: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 0000004ACD5C: 020304FF 83DCD12D
	.long 0xd72c0084                                           // 0000004ACD64: D72C0084
	v_cndmask_b32_e32 v1, 0x83dcd12d, v132, vcc_lo             // 0000004ACD68: 020308FF 83DCD12D
	.long 0xd72c0085                                           // 0000004ACD70: D72C0085
	v_cndmask_b32_e32 v1, 0x83dcd12d, v133, vcc_lo             // 0000004ACD74: 02030AFF 83DCD12D
	v_and_b32_e32 v4, 0xffff, v4                               // 0000004ACD7C: 360808FF 0000FFFF
	v_and_b32_e32 v25, 0xffff, v25                             // 0000004ACD84: 363232FF 0000FFFF
	v_and_b32_e32 v29, 0xffff, v29                             // 0000004ACD8C: 363A3AFF 0000FFFF
	.long 0xd72c0015                                           // 0000004ACD94: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 0000004ACD98: 02022AFF 83DCD12D
	.long 0xd72c0025                                           // 0000004ACDA0: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 0000004ACDA4: 02024AFF 83DCD12D
	.long 0xd72c0029                                           // 0000004ACDAC: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 0000004ACDB0: 020252FF 83DCD12D
	v_and_b32_e32 v32, 0xffff, v32                             // 0000004ACDB8: 364040FF 0000FFFF
	v_and_b32_e32 v7, 0xffff, v7                               // 0000004ACDC0: 360E0EFF 0000FFFF
	.long 0xd72c0006                                           // 0000004ACDC8: D72C0006
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 0000004ACDCC: 02020CFF 83DCD12D
	.long 0xd72c0021                                           // 0000004ACDD4: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 0000004ACDD8: 020242FF 83DCD12D
	v_bfe_u32 v15, v45, 8, 16                                  // 0000004ACDE0: D610000F 0241112D
	v_and_b32_e32 v44, 0xffff, v45                             // 0000004ACDE8: 36585AFF 0000FFFF
	v_and_b32_e32 v34, 0xffff, v34                             // 0000004ACDF0: 364444FF 0000FFFF
	v_and_b32_e32 v11, 0xffff, v11                             // 0000004ACDF8: 361616FF 0000FFFF
	v_and_b32_e32 v36, 0xffff, v36                             // 0000004ACE00: 364848FF 0000FFFF
	.long 0xd72c000e                                           // 0000004ACE08: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 0000004ACE0C: 02021CFF 83DCD12D
	.long 0xd72c001f                                           // 0000004ACE14: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 0000004ACE18: 02023EFF 83DCD12D
	.long 0xd72c0014                                           // 0000004ACE20: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v20, vcc_lo              // 0000004ACE24: 020228FF 83DCD12D
	.long 0xd72c0017                                           // 0000004ACE2C: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 0000004ACE30: 02022EFF 83DCD12D
	.long 0xd72c0005                                           // 0000004ACE38: D72C0005
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 0000004ACE3C: 02020AFF 83DCD12D
	.long 0xd72c0008                                           // 0000004ACE44: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v8, vcc_lo               // 0000004ACE48: 020210FF 83DCD12D
	.long 0xd72c0023                                           // 0000004ACE50: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 0000004ACE54: 020246FF 83DCD12D
	.long 0xd72c000c                                           // 0000004ACE5C: D72C000C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v12, vcc_lo              // 0000004ACE60: 020218FF 83DCD12D
	.long 0xd72c0026                                           // 0000004ACE68: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 0000004ACE6C: 02024CFF 83DCD12D
	.long 0xd72c001b                                           // 0000004ACE74: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 0000004ACE78: 020236FF 83DCD12D
	.long 0xd72c0028                                           // 0000004ACE80: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 0000004ACE84: 020250FF 83DCD12D
	v_and_b32_e32 v42, 0xffff, v42                             // 0000004ACE8C: 365454FF 0000FFFF
	v_and_b32_e32 v13, 0xffff, v13                             // 0000004ACE94: 361A1AFF 0000FFFF
	.long 0xd72c001e                                           // 0000004ACE9C: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 0000004ACEA0: 02023CFF 83DCD12D
	.long 0xd72c002b                                           // 0000004ACEA8: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 0000004ACEAC: 020256FF 83DCD12D
	.long 0xd72c0004                                           // 0000004ACEB4: D72C0004
	v_cndmask_b32_e32 v1, 0x83dcd12d, v4, vcc_lo               // 0000004ACEB8: 020208FF 83DCD12D
	.long 0xd72c0019                                           // 0000004ACEC0: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 0000004ACEC4: 020232FF 83DCD12D
	.long 0xd72c001d                                           // 0000004ACECC: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 0000004ACED0: 02023AFF 83DCD12D
	v_sad_u8 v45, v134, 0, 0x6400                              // 0000004ACED8: D622002D 03FD0186 00006400
	v_sad_u8 v50, v113, 0, 0x6400                              // 0000004ACEE4: D6220032 03FD0171 00006400
	v_sad_u8 v65, v114, 0, 0x6400                              // 0000004ACEF0: D6220041 03FD0172 00006400
	v_sad_u8 v66, v115, 0, 0x6400                              // 0000004ACEFC: D6220042 03FD0173 00006400
	v_sad_u8 v67, v116, 0, 0x6400                              // 0000004ACF08: D6220043 03FD0174 00006400
	v_sad_u8 v113, v117, 0, 0x6400                             // 0000004ACF14: D6220071 03FD0175 00006400
	v_sad_u8 v114, v118, 0, 0x6400                             // 0000004ACF20: D6220072 03FD0176 00006400
	v_sad_u8 v115, v119, 0, 0x6400                             // 0000004ACF2C: D6220073 03FD0177 00006400
	v_sad_u8 v116, v120, 0, 0x6400                             // 0000004ACF38: D6220074 03FD0178 00006400
	v_sad_u8 v117, v121, 0, 0x6400                             // 0000004ACF44: D6220075 03FD0179 00006400
	v_sad_u8 v118, v122, 0, 0x6400                             // 0000004ACF50: D6220076 03FD017A 00006400
	v_sad_u8 v119, v123, 0, 0x6400                             // 0000004ACF5C: D6220077 03FD017B 00006400
	v_sad_u8 v121, v125, 0, 0x6400                             // 0000004ACF68: D6220079 03FD017D 00006400
	v_sad_u8 v123, v135, 0, 0x6400                             // 0000004ACF74: D622007B 03FD0187 00006400
	v_sad_u8 v125, v128, 0, 0x6400                             // 0000004ACF80: D622007D 03FD0180 00006400
	v_sad_u8 v128, v131, 0, 0x6400                             // 0000004ACF8C: D6220080 03FD0183 00006400
	v_sad_u8 v131, v136, 0, 0x6400                             // 0000004ACF98: D6220083 03FD0188 00006400
	v_sad_u8 v19, v19, 0, 0x6400                               // 0000004ACFA4: D6220013 03FD0113 00006400
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000004ACFB0: D6220016 03FD0116 00006400
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000004ACFBC: D6220018 03FD0118 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000004ACFC8: D622001A 03FD011A 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000004ACFD4: D6220027 03FD0127 00006400
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000004ACFE0: D622001C 03FD011C 00006400
	.long 0xd72c0020                                           // 0000004ACFEC: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 0000004ACFF0: 020240FF 83DCD12D
	.long 0xd72c0007                                           // 0000004ACFF8: D72C0007
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 0000004ACFFC: 02020EFF 83DCD12D
	.long 0xd72c000f                                           // 0000004AD004: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 0000004AD008: 02021EFF 83DCD12D
	.long 0xd72c002c                                           // 0000004AD010: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000004AD014: 020258FF 83DCD12D
	.long 0xd72c0022                                           // 0000004AD01C: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 0000004AD020: 020244FF 83DCD12D
	.long 0xd72c000b                                           // 0000004AD028: D72C000B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v11, vcc_lo              // 0000004AD02C: 020216FF 83DCD12D
	.long 0xd72c0024                                           // 0000004AD034: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 0000004AD038: 020248FF 83DCD12D
	v_sad_u8 v9, v9, 0, 0x6400                                 // 0000004AD040: D6220009 03FD0109 00006400
	v_sad_u8 v120, v124, 0, 0x6400                             // 0000004AD04C: D6220078 03FD017C 00006400
	v_sad_u8 v122, v126, 0, 0x6400                             // 0000004AD058: D622007A 03FD017E 00006400
	v_sad_u8 v124, v127, 0, 0x6400                             // 0000004AD064: D622007C 03FD017F 00006400
	v_sad_u8 v126, v129, 0, 0x6400                             // 0000004AD070: D622007E 03FD0181 00006400
	v_sad_u8 v127, v130, 0, 0x6400                             // 0000004AD07C: D622007F 03FD0182 00006400
	v_sad_u8 v129, v132, 0, 0x6400                             // 0000004AD088: D6220081 03FD0184 00006400
	v_sad_u8 v130, v133, 0, 0x6400                             // 0000004AD094: D6220082 03FD0185 00006400
	v_sad_u8 v133, v138, 0, 0x6400                             // 0000004AD0A0: D6220085 03FD018A 00006400
	.long 0xd72c002a                                           // 0000004AD0AC: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 0000004AD0B0: 020254FF 83DCD12D
	.long 0xd72c000d                                           // 0000004AD0B8: D72C000D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v13, vcc_lo              // 0000004AD0BC: 02021AFF 83DCD12D
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000004AD0C4: D6220015 03FD0115 00006400
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000004AD0D0: D6220025 03FD0125 00006400
	v_sad_u8 v41, v41, 0, 0x6400                               // 0000004AD0DC: D6220029 03FD0129 00006400
	v_sad_u8 v6, v6, 0, 0x6400                                 // 0000004AD0E8: D6220006 03FD0106 00006400
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000004AD0F4: D6220021 03FD0121 00006400
	v_sad_u8 v132, v137, 0, 0x6400                             // 0000004AD100: D6220084 03FD0189 00006400
	v_and_b32_e32 v45, 0xffff, v45                             // 0000004AD10C: 365A5AFF 0000FFFF
	v_and_b32_e32 v65, 0xffff, v65                             // 0000004AD114: 368282FF 0000FFFF
	v_and_b32_e32 v67, 0xffff, v67                             // 0000004AD11C: 368686FF 0000FFFF
	v_and_b32_e32 v114, 0xffff, v114                           // 0000004AD124: 36E4E4FF 0000FFFF
	v_and_b32_e32 v116, 0xffff, v116                           // 0000004AD12C: 36E8E8FF 0000FFFF
	v_and_b32_e32 v118, 0xffff, v118                           // 0000004AD134: 36ECECFF 0000FFFF
	v_and_b32_e32 v123, 0xffff, v123                           // 0000004AD13C: 36F6F6FF 0000FFFF
	v_and_b32_e32 v125, 0xffff, v125                           // 0000004AD144: 36FAFAFF 0000FFFF
	v_and_b32_e32 v131, 0xffff, v131                           // 0000004AD14C: 370706FF 0000FFFF
	v_sad_u8 v14, v14, 0, 0x6400                               // 0000004AD154: D622000E 03FD010E 00006400
	v_sad_u8 v31, v31, 0, 0x6400                               // 0000004AD160: D622001F 03FD011F 00006400
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000004AD16C: D6220014 03FD0114 00006400
	v_sad_u8 v23, v23, 0, 0x6400                               // 0000004AD178: D6220017 03FD0117 00006400
	v_sad_u8 v5, v5, 0, 0x6400                                 // 0000004AD184: D6220005 03FD0105 00006400
	v_sad_u8 v8, v8, 0, 0x6400                                 // 0000004AD190: D6220008 03FD0108 00006400
	v_sad_u8 v35, v35, 0, 0x6400                               // 0000004AD19C: D6220023 03FD0123 00006400
	v_sad_u8 v12, v12, 0, 0x6400                               // 0000004AD1A8: D622000C 03FD010C 00006400
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000004AD1B4: D6220026 03FD0126 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000004AD1C0: D622001B 03FD011B 00006400
	v_sad_u8 v40, v40, 0, 0x6400                               // 0000004AD1CC: D6220028 03FD0128 00006400
	v_and_b32_e32 v19, 0xffff, v19                             // 0000004AD1D8: 362626FF 0000FFFF
	v_and_b32_e32 v22, 0xffff, v22                             // 0000004AD1E0: 362C2CFF 0000FFFF
	v_and_b32_e32 v24, 0xffff, v24                             // 0000004AD1E8: 363030FF 0000FFFF
	v_and_b32_e32 v26, 0xffff, v26                             // 0000004AD1F0: 363434FF 0000FFFF
	v_and_b32_e32 v39, 0xffff, v39                             // 0000004AD1F8: 364E4EFF 0000FFFF
	v_and_b32_e32 v28, 0xffff, v28                             // 0000004AD200: 363838FF 0000FFFF
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000004AD208: D622001E 03FD011E 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000004AD214: D622002B 03FD012B 00006400
	v_sad_u8 v134, v139, 0, 0x6400                             // 0000004AD220: D6220086 03FD018B 00006400
	v_and_b32_e32 v9, 0xffff, v9                               // 0000004AD22C: 361212FF 0000FFFF
	v_and_b32_e32 v121, 0xffff, v121                           // 0000004AD234: 36F2F2FF 0000FFFF
	v_and_b32_e32 v127, 0xffff, v127                           // 0000004AD23C: 36FEFEFF 0000FFFF
	v_and_b32_e32 v129, 0xffff, v129                           // 0000004AD244: 370302FF 0000FFFF
	v_and_b32_e32 v133, 0xffff, v133                           // 0000004AD24C: 370B0AFF 0000FFFF
	v_sad_u8 v4, v4, 0, 0x6400                                 // 0000004AD254: D6220004 03FD0104 00006400
	v_sad_u8 v25, v25, 0, 0x6400                               // 0000004AD260: D6220019 03FD0119 00006400
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000004AD26C: D622001D 03FD011D 00006400
	v_and_b32_e32 v21, 0xffff, v21                             // 0000004AD278: 362A2AFF 0000FFFF
	v_and_b32_e32 v37, 0xffff, v37                             // 0000004AD280: 364A4AFF 0000FFFF
	v_and_b32_e32 v41, 0xffff, v41                             // 0000004AD288: 365252FF 0000FFFF
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000004AD290: D6220020 03FD0120 00006400
	v_sad_u8 v7, v7, 0, 0x6400                                 // 0000004AD29C: D6220007 03FD0107 00006400
	v_and_b32_e32 v6, 0xffff, v6                               // 0000004AD2A8: 360C0CFF 0000FFFF
	v_and_b32_e32 v33, 0xffff, v33                             // 0000004AD2B0: 364242FF 0000FFFF
	v_sad_u8 v15, v15, 0, 0x6400                               // 0000004AD2B8: D622000F 03FD010F 00006400
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000004AD2C4: D622002C 03FD012C 00006400
	v_sad_u8 v34, v34, 0, 0x6400                               // 0000004AD2D0: D6220022 03FD0122 00006400
	v_sad_u8 v11, v11, 0, 0x6400                               // 0000004AD2DC: D622000B 03FD010B 00006400
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000004AD2E8: D6220024 03FD0124 00006400
	v_lshl_or_b32 v45, v50, 16, v45                            // 0000004AD2F4: D656002D 04B52132
	v_lshl_or_b32 v50, v66, 16, v65                            // 0000004AD2FC: D6560032 05052142
	v_lshl_or_b32 v65, v113, 16, v67                           // 0000004AD304: D6560041 050D2171
	v_lshl_or_b32 v66, v115, 16, v114                          // 0000004AD30C: D6560042 05C92173
	v_lshl_or_b32 v67, v117, 16, v116                          // 0000004AD314: D6560043 05D12175
	v_lshl_or_b32 v113, v119, 16, v118                         // 0000004AD31C: D6560071 05D92177
	v_lshl_or_b32 v115, v124, 16, v123                         // 0000004AD324: D6560073 05ED217C
	v_lshl_or_b32 v116, v126, 16, v125                         // 0000004AD32C: D6560074 05F5217E
	v_lshl_or_b32 v119, v132, 16, v131                         // 0000004AD334: D6560077 060D2184
	v_and_b32_e32 v14, 0xffff, v14                             // 0000004AD33C: 361C1CFF 0000FFFF
	v_and_b32_e32 v31, 0xffff, v31                             // 0000004AD344: 363E3EFF 0000FFFF
	v_and_b32_e32 v8, 0xffff, v8                               // 0000004AD34C: 361010FF 0000FFFF
	v_and_b32_e32 v35, 0xffff, v35                             // 0000004AD354: 364646FF 0000FFFF
	v_and_b32_e32 v12, 0xffff, v12                             // 0000004AD35C: 361818FF 0000FFFF
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000004AD364: D622002A 03FD012A 00006400
	v_sad_u8 v13, v13, 0, 0x6400                               // 0000004AD370: D622000D 03FD010D 00006400
	v_lshl_or_b32 v19, v20, 16, v19                            // 0000004AD37C: D6560013 044D2114
	v_lshl_or_b32 v20, v23, 16, v22                            // 0000004AD384: D6560014 04592117
	v_lshl_or_b32 v5, v5, 16, v24                              // 0000004AD38C: D6560005 04612105
	v_lshl_or_b32 v22, v38, 16, v26                            // 0000004AD394: D6560016 04692126
	v_lshl_or_b32 v23, v27, 16, v39                            // 0000004AD39C: D6560017 049D211B
	v_lshl_or_b32 v24, v40, 16, v28                            // 0000004AD3A4: D6560018 04712128
	v_and_b32_e32 v26, 0xffff, v30                             // 0000004AD3AC: 36343CFF 0000FFFF
	v_and_b32_e32 v27, 0xffff, v43                             // 0000004AD3B4: 363656FF 0000FFFF
	v_lshl_or_b32 v9, v120, 16, v9                             // 0000004AD3BC: D6560009 04252178
	v_lshl_or_b32 v114, v122, 16, v121                         // 0000004AD3C4: D6560072 05E5217A
	v_lshl_or_b32 v117, v128, 16, v127                         // 0000004AD3CC: D6560075 05FD2180
	v_lshl_or_b32 v118, v130, 16, v129                         // 0000004AD3D4: D6560076 06052182
	v_lshl_or_b32 v120, v134, 16, v133                         // 0000004AD3DC: D6560078 06152186
	v_lshl_or_b32 v4, v4, 16, v21                              // 0000004AD3E4: D6560004 04552104
	v_lshl_or_b32 v21, v25, 16, v37                            // 0000004AD3EC: D6560015 04952119
	v_lshl_or_b32 v25, v29, 16, v41                            // 0000004AD3F4: D6560019 04A5211D
	v_lshl_or_b32 v6, v32, 16, v6                              // 0000004AD3FC: D6560006 04192120
	v_lshl_or_b32 v7, v7, 16, v33                              // 0000004AD404: D6560007 04852107
	v_pk_fma_f16 v45, v45, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD40C: CC0E002D 0BFC072D 0000C931
	v_pk_fma_f16 v50, v50, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD418: CC0E0032 0BFC0732 0000C931
	v_pk_fma_f16 v65, v65, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD424: CC0E0041 0BFC0741 0000C931
	v_pk_fma_f16 v115, v115, s3, 0xc931 op_sel_hi:[1,0,0]      // 0000004AD430: CC0E0073 0BFC0773 0000C931
	v_pk_fma_f16 v116, v116, s3, 0xc931 op_sel_hi:[1,0,0]      // 0000004AD43C: CC0E0074 0BFC0774 0000C931
	v_pk_fma_f16 v119, v119, s3, 0xc931 op_sel_hi:[1,0,0]      // 0000004AD448: CC0E0077 0BFC0777 0000C931
	v_lshl_or_b32 v14, v15, 16, v14                            // 0000004AD454: D656000E 0439210F
	v_lshl_or_b32 v15, v44, 16, v31                            // 0000004AD45C: D656000F 047D212C
	v_lshl_or_b32 v8, v34, 16, v8                              // 0000004AD464: D6560008 04212122
	v_lshl_or_b32 v11, v11, 16, v35                            // 0000004AD46C: D656000B 048D210B
	v_lshl_or_b32 v12, v36, 16, v12                            // 0000004AD474: D656000C 04312124
	v_pk_fma_f16 v19, v19, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD47C: CC0E0013 0BFC0713 0000C931
	v_pk_fma_f16 v24, v24, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD488: CC0E0018 0BFC0718 0000C931
	v_lshl_or_b32 v26, v42, 16, v26                            // 0000004AD494: D656001A 0469212A
	v_lshl_or_b32 v13, v13, 16, v27                            // 0000004AD49C: D656000D 046D210D
	v_pk_fma_f16 v66, v66, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD4A4: CC0E0042 0BFC0742 0000C931
	v_pk_fma_f16 v67, v67, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD4B0: CC0E0043 0BFC0743 0000C931
	v_pk_fma_f16 v113, v113, s3, 0xc931 op_sel_hi:[1,0,0]      // 0000004AD4BC: CC0E0071 0BFC0771 0000C931
	v_pk_fma_f16 v114, v114, s3, 0xc931 op_sel_hi:[1,0,0]      // 0000004AD4C8: CC0E0072 0BFC0772 0000C931
	v_pk_fma_f16 v117, v117, s3, 0xc931 op_sel_hi:[1,0,0]      // 0000004AD4D4: CC0E0075 0BFC0775 0000C931
	v_pk_fma_f16 v118, v118, s3, 0xc931 op_sel_hi:[1,0,0]      // 0000004AD4E0: CC0E0076 0BFC0776 0000C931
	v_pk_fma_f16 v120, v120, s3, 0xc931 op_sel_hi:[1,0,0]      // 0000004AD4EC: CC0E0078 0BFC0778 0000C931
	v_pk_fma_f16 v4, v4, s3, 0xc931 op_sel_hi:[1,0,0]          // 0000004AD4F8: CC0E0004 0BFC0704 0000C931
	v_pk_fma_f16 v25, v25, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD504: CC0E0019 0BFC0719 0000C931
	v_pk_fma_f16 v5, v5, s3, 0xc931 op_sel_hi:[1,0,0]          // 0000004AD510: CC0E0005 0BFC0705 0000C931
	v_pk_fma_f16 v6, v6, s3, 0xc931 op_sel_hi:[1,0,0]          // 0000004AD51C: CC0E0006 0BFC0706 0000C931
	v_pk_fma_f16 v7, v7, s3, 0xc931 op_sel_hi:[1,0,0]          // 0000004AD528: CC0E0007 0BFC0707 0000C931
	v_pk_fma_f16 v9, v9, s3, 0xc931 op_sel_hi:[1,0,0]          // 0000004AD534: CC0E0009 0BFC0709 0000C931
	v_cvt_f32_f16_e32 v28, v173/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD540: 7E3817AD
	v_cvt_f32_f16_e32 v29, v45                                 // 0000004AD544: 7E3A172D
	v_cvt_f32_f16_e32 v30, v178/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD548: 7E3C17B2
	v_cvt_f32_f16_e32 v31, v50                                 // 0000004AD54C: 7E3E1732
	v_cvt_f32_f16_e32 v32, v193/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD550: 7E4017C1
	v_cvt_f32_f16_e32 v33, v65                                 // 0000004AD554: 7E421741
	v_cvt_f32_f16_e32 v44, v243/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD558: 7E5817F3
	v_cvt_f32_f16_e32 v45, v115                                // 0000004AD55C: 7E5A1773
	v_cvt_f32_f16_e32 v50, v244/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD560: 7E6417F4
	v_cvt_f32_f16_e32 v65, v116                                // 0000004AD564: 7E821774
	v_cvt_f32_f16_e32 v115, v247/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD568: 7EE617F7
	v_cvt_f32_f16_e32 v116, v119                               // 0000004AD56C: 7EE81777
	v_pk_fma_f16 v14, v14, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD570: CC0E000E 0BFC070E 0000C931
	v_pk_fma_f16 v15, v15, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD57C: CC0E000F 0BFC070F 0000C931
	v_pk_fma_f16 v20, v20, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD588: CC0E0014 0BFC0714 0000C931
	v_pk_fma_f16 v8, v8, s3, 0xc931 op_sel_hi:[1,0,0]          // 0000004AD594: CC0E0008 0BFC0708 0000C931
	v_pk_fma_f16 v11, v11, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD5A0: CC0E000B 0BFC070B 0000C931
	v_pk_fma_f16 v12, v12, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD5AC: CC0E000C 0BFC070C 0000C931
	v_pk_fma_f16 v21, v21, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD5B8: CC0E0015 0BFC0715 0000C931
	v_pk_fma_f16 v22, v22, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD5C4: CC0E0016 0BFC0716 0000C931
	v_pk_fma_f16 v23, v23, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD5D0: CC0E0017 0BFC0717 0000C931
	v_cvt_f32_f16_e32 v119, v147/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD5DC: 7EEE1793
	v_cvt_f32_f16_e32 v19, v19                                 // 0000004AD5E0: 7E261713
	.long 0xd58b0883                                           // 0000004AD5E4: D58B0883
	v_cndmask_b32_e32 v0, v24, v128, vcc_lo                    // 0000004AD5E8: 02010118
	v_cvt_f32_f16_e32 v24, v24                                 // 0000004AD5EC: 7E301718
	v_pk_fma_f16 v26, v26, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD5F0: CC0E001A 0BFC071A 0000C931
	v_pk_fma_f16 v13, v13, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004AD5FC: CC0E000D 0BFC070D 0000C931
	v_cvt_f32_f16_e32 v34, v194/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD608: 7E4417C2
	v_cvt_f32_f16_e32 v35, v66                                 // 0000004AD60C: 7E461742
	v_cvt_f32_f16_e32 v36, v195/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD610: 7E4817C3
	v_cvt_f32_f16_e32 v37, v67                                 // 0000004AD614: 7E4A1743
	v_cvt_f32_f16_e32 v38, v241/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD618: 7E4C17F1
	v_cvt_f32_f16_e32 v39, v113                                // 0000004AD61C: 7E4E1771
	v_cvt_f32_f16_e32 v41, v242/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD620: 7E5217F2
	v_cvt_f32_f16_e32 v43, v114                                // 0000004AD624: 7E561772
	v_cvt_f32_f16_e32 v66, v245/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD628: 7E8417F5
	v_cvt_f32_f16_e32 v67, v117                                // 0000004AD62C: 7E861775
	v_cvt_f32_f16_e32 v113, v246/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD630: 7EE217F6
	v_cvt_f32_f16_e32 v114, v118                               // 0000004AD634: 7EE41776
	v_cvt_f32_f16_e32 v117, v248/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD638: 7EEA17F8
	v_cvt_f32_f16_e32 v118, v120                               // 0000004AD63C: 7EEC1778
	v_cvt_f32_f16_e32 v120, v132/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD640: 7EF01784
	v_cvt_f32_f16_e32 v4, v4                                   // 0000004AD644: 7E081704
	.long 0xd58b0884                                           // 0000004AD648: D58B0884
	v_cndmask_b32_e32 v0, v25, v128, vcc_lo                    // 0000004AD64C: 02010119
	v_cvt_f32_f16_e32 v25, v25                                 // 0000004AD650: 7E321719
	v_cvt_f32_f16_e32 v122, v133/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD654: 7EF41785
	v_cvt_f32_f16_e32 v5, v5                                   // 0000004AD658: 7E0A1705
	v_cvt_f32_f16_e32 v123, v134/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD65C: 7EF61786
	v_cvt_f32_f16_e32 v6, v6                                   // 0000004AD660: 7E0C1706
	v_cvt_f32_f16_e32 v124, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD664: 7EF81787
	v_cvt_f32_f16_e32 v7, v7                                   // 0000004AD668: 7E0E1707
	v_cvt_f32_f16_e32 v40, v137/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD66C: 7E501789
	v_cvt_f32_f16_e32 v9, v9                                   // 0000004AD670: 7E121709
	v_cvt_f32_f16_e32 v27, v142/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD674: 7E36178E
	v_cvt_f32_f16_e32 v14, v14                                 // 0000004AD678: 7E1C170E
	v_cvt_f32_f16_e32 v42, v143/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD67C: 7E54178F
	v_cvt_f32_f16_e32 v15, v15                                 // 0000004AD680: 7E1E170F
	v_cvt_f32_f16_e32 v121, v148/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD684: 7EF21794
	v_cvt_f32_f16_e32 v20, v20                                 // 0000004AD688: 7E281714
	v_cvt_f32_f16_e32 v125, v136/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD68C: 7EFA1788
	v_cvt_f32_f16_e32 v8, v8                                   // 0000004AD690: 7E101708
	v_cvt_f32_f16_e32 v126, v139/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD694: 7EFC178B
	v_cvt_f32_f16_e32 v11, v11                                 // 0000004AD698: 7E16170B
	v_cvt_f32_f16_e32 v127, v140/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD69C: 7EFE178C
	v_cvt_f32_f16_e32 v12, v12                                 // 0000004AD6A0: 7E18170C
	.long 0xd58b0880                                           // 0000004AD6A4: D58B0880
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                    // 0000004AD6A8: 02010115
	v_cvt_f32_f16_e32 v21, v21                                 // 0000004AD6AC: 7E2A1715
	.long 0xd58b0881                                           // 0000004AD6B0: D58B0881
	v_cndmask_b32_e32 v0, v22, v128, vcc_lo                    // 0000004AD6B4: 02010116
	v_cvt_f32_f16_e32 v22, v22                                 // 0000004AD6B8: 7E2C1716
	.long 0xd58b0882                                           // 0000004AD6BC: D58B0882
	v_cndmask_b32_e32 v0, v23, v128, vcc_lo                    // 0000004AD6C0: 02010117
	v_cvt_f32_f16_e32 v23, v23                                 // 0000004AD6C4: 7E2E1717
	ds_store_b32 v68, v19                                      // 0000004AD6C8: D8340000 00001344
	ds_store_b32 v76, v119                                     // 0000004AD6D0: D8340000 0000774C
	ds_store_b32 v77, v4                                       // 0000004AD6D8: D8340000 0000044D
	ds_store_b32 v78, v120                                     // 0000004AD6E0: D8340000 0000784E
	ds_store_b32 v79, v29                                      // 0000004AD6E8: D8340000 00001D4F
	ds_store_b32 v80, v28                                      // 0000004AD6F0: D8340000 00001C50
	ds_store_b32 v81, v31                                      // 0000004AD6F8: D8340000 00001F51
	ds_store_b32 v82, v30                                      // 0000004AD700: D8340000 00001E52
	ds_store_b32 v58, v20                                      // 0000004AD708: D8340000 0000143A
	ds_store_b32 v83, v121                                     // 0000004AD710: D8340000 00007953
	ds_store_b32 v84, v5                                       // 0000004AD718: D8340000 00000554
	ds_store_b32 v85, v122                                     // 0000004AD720: D8340000 00007A55
	ds_store_b32 v86, v33                                      // 0000004AD728: D8340000 00002156
	ds_store_b32 v87, v32                                      // 0000004AD730: D8340000 00002057
	ds_store_b32 v88, v35                                      // 0000004AD738: D8340000 00002358
	ds_store_b32 v89, v34                                      // 0000004AD740: D8340000 00002259
	ds_store_b32 v69, v6                                       // 0000004AD748: D8340000 00000645
	ds_store_b32 v90, v123                                     // 0000004AD750: D8340000 00007B5A
	ds_store_b32 v91, v7                                       // 0000004AD758: D8340000 0000075B
	ds_store_b32 v92, v124                                     // 0000004AD760: D8340000 00007C5C
	ds_store_b32 v93, v37                                      // 0000004AD768: D8340000 0000255D
	ds_store_b32 v94, v36                                      // 0000004AD770: D8340000 0000245E
	ds_store_b32 v95, v39                                      // 0000004AD778: D8340000 0000275F
	ds_store_b32 v96, v38                                      // 0000004AD780: D8340000 00002660
	ds_store_b32 v70, v8                                       // 0000004AD788: D8340000 00000846
	ds_store_b32 v97, v125                                     // 0000004AD790: D8340000 00007D61
	ds_store_b32 v98, v11                                      // 0000004AD798: D8340000 00000B62
	ds_store_b32 v99, v126                                     // 0000004AD7A0: D8340000 00007E63
	ds_store_b32 v100, v9                                      // 0000004AD7A8: D8340000 00000964
	ds_store_b32 v101, v40                                     // 0000004AD7B0: D8340000 00002865
	ds_store_b32 v102, v43                                     // 0000004AD7B8: D8340000 00002B66
	ds_store_b32 v52, v41                                      // 0000004AD7C0: D8340000 00002934
	ds_store_b32 v71, v12                                      // 0000004AD7C8: D8340000 00000C47
	ds_store_b32 v103, v127                                    // 0000004AD7D0: D8340000 00007F67
	ds_store_b32 v104, v21                                     // 0000004AD7D8: D8340000 00001568
	ds_store_b32 v105, v128                                    // 0000004AD7E0: D8340000 00008069
	ds_store_b32 v106, v45                                     // 0000004AD7E8: D8340000 00002D6A
	ds_store_b32 v107, v44                                     // 0000004AD7F0: D8340000 00002C6B
	ds_store_b32 v108, v65                                     // 0000004AD7F8: D8340000 0000416C
	ds_store_b32 v109, v50                                     // 0000004AD800: D8340000 0000326D
	ds_store_b32 v51, v22                                      // 0000004AD808: D8340000 00001633
	ds_store_b32 v59, v129                                     // 0000004AD810: D8340000 0000813B
	ds_store_b32 v60, v23                                      // 0000004AD818: D8340000 0000173C
	ds_store_b32 v61, v130                                     // 0000004AD820: D8340000 0000823D
	ds_store_b32 v62, v67                                      // 0000004AD828: D8340000 0000433E
	ds_store_b32 v63, v66                                      // 0000004AD830: D8340000 0000423F
	ds_store_b32 v64, v114                                     // 0000004AD838: D8340000 00007240
	ds_store_b32 v53, v113                                     // 0000004AD840: D8340000 00007135
	v_cvt_f32_f16_e32 v4, v154/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD848: 7E08179A
	v_cvt_f32_f16_e32 v5, v26                                  // 0000004AD84C: 7E0A171A
	v_cvt_f32_f16_e32 v6, v141/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AD850: 7E0C178D
	v_cvt_f32_f16_e32 v7, v13                                  // 0000004AD854: 7E0E170D
	ds_store_b32 v72, v24                                      // 0000004AD858: D8340000 00001848
	ds_store_b32 v110, v131                                    // 0000004AD860: D8340000 0000836E
	ds_store_b32 v111, v25                                     // 0000004AD868: D8340000 0000196F
	ds_store_b32 v54, v132                                     // 0000004AD870: D8340000 00008436
	ds_store_b32 v55, v116                                     // 0000004AD878: D8340000 00007437
	ds_store_b32 v56, v115                                     // 0000004AD880: D8340000 00007338
	ds_store_b32 v57, v118                                     // 0000004AD888: D8340000 00007639
	ds_store_b32 v112, v117                                    // 0000004AD890: D8340000 00007570
	ds_store_b32 v10, v5                                       // 0000004AD898: D8340000 0000050A
	ds_store_b32 v73, v4                                       // 0000004AD8A0: D8340000 00000449
	ds_store_b32 v74, v7                                       // 0000004AD8A8: D8340000 0000074A
	ds_store_b32 v46, v6                                       // 0000004AD8B0: D8340000 0000062E
	ds_store_b32 v47, v14                                      // 0000004AD8B8: D8340000 00000E2F
	ds_store_b32 v48, v27                                      // 0000004AD8C0: D8340000 00001B30
	ds_store_b32 v49, v15                                      // 0000004AD8C8: D8340000 00000F31
	ds_store_b32 v75, v42                                      // 0000004AD8D0: D8340000 00002A4B
	s_waitcnt lgkmcnt(0)                                       // 0000004AD8D8: BF89FC07
	s_barrier                                                  // 0000004AD8DC: BFBD0000
	buffer_gl0_inv                                             // 0000004AD8E0: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 0000004AD8E8: BE832000
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004AD8EC: BF870009
	s_xor_b32 s0, exec_lo, s3                                  // 0000004AD8F0: 8D00037E
	v_and_b32_e32 v3, 0x7f, v0                                 // 0000004AD8F4: 360600FF 0000007F
	s_or_saveexec_b32 s0, s0                                   // 0000004AD8FC: BE802200
	v_or_b32_e32 v4, -8, v18                                   // 0000004AD900: 380824C8
	v_lshlrev_b32_e32 v8, 3, v18                               // 0000004AD904: 30102483
	s_xor_b32 exec_lo, exec_lo, s0                             // 0000004AD908: 8D7E007E
	s_cbranch_execz 451                                        // 0000004AD90C: BFA501C3 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi4ELb1ELi8EEEvPKjiPKDF16_S5_Pti+0x1c1c>
	v_and_b32_e32 v34, 0x60, v0                                // 0000004AD910: 364400FF 00000060
	v_lshlrev_b32_e32 v40, 3, v18                              // 0000004AD918: 30502483
	s_mov_b32 s3, 0                                            // 0000004AD91C: BE830080
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004AD920: BF870002
	v_or_b32_e32 v0, 1, v34                                    // 0000004AD924: 38004481
	v_or_b32_e32 v5, 2, v34                                    // 0000004AD928: 380A4482
	v_or_b32_e32 v6, 3, v34                                    // 0000004AD92C: 380C4483
	v_or_b32_e32 v7, 4, v34                                    // 0000004AD930: 380E4484
	v_or_b32_e32 v9, 5, v34                                    // 0000004AD934: 38124485
	v_or_b32_e32 v10, 6, v34                                   // 0000004AD938: 38144486
	v_or_b32_e32 v11, 7, v34                                   // 0000004AD93C: 38164487
	v_or_b32_e32 v12, 8, v34                                   // 0000004AD940: 38184488
	v_or_b32_e32 v13, 9, v34                                   // 0000004AD944: 381A4489
	v_or_b32_e32 v14, 10, v34                                  // 0000004AD948: 381C448A
	v_or_b32_e32 v15, 11, v34                                  // 0000004AD94C: 381E448B
	v_or_b32_e32 v19, 12, v34                                  // 0000004AD950: 3826448C
	v_or_b32_e32 v20, 13, v34                                  // 0000004AD954: 3828448D
	v_or_b32_e32 v21, 14, v34                                  // 0000004AD958: 382A448E
	v_or_b32_e32 v22, 15, v34                                  // 0000004AD95C: 382C448F
	v_or_b32_e32 v23, 16, v34                                  // 0000004AD960: 382E4490
	v_or_b32_e32 v24, 17, v34                                  // 0000004AD964: 38304491
	v_or_b32_e32 v25, 18, v34                                  // 0000004AD968: 38324492
	v_or_b32_e32 v26, 19, v34                                  // 0000004AD96C: 38344493
	v_or_b32_e32 v27, 20, v34                                  // 0000004AD970: 38364494
	v_or_b32_e32 v28, 21, v34                                  // 0000004AD974: 38384495
	v_or_b32_e32 v29, 22, v34                                  // 0000004AD978: 383A4496
	v_or_b32_e32 v30, 23, v34                                  // 0000004AD97C: 383C4497
	v_or_b32_e32 v31, 24, v34                                  // 0000004AD980: 383E4498
	v_or_b32_e32 v32, 25, v34                                  // 0000004AD984: 38404499
	v_or_b32_e32 v33, 26, v34                                  // 0000004AD988: 3842449A
	v_or_b32_e32 v35, 27, v34                                  // 0000004AD98C: 3846449B
	v_or_b32_e32 v36, 28, v34                                  // 0000004AD990: 3848449C
	v_or_b32_e32 v37, 29, v34                                  // 0000004AD994: 384A449D
	v_or_b32_e32 v38, 30, v34                                  // 0000004AD998: 384C449E
	v_or_b32_e32 v39, 31, v34                                  // 0000004AD99C: 384E449F
	v_xor_b32_e32 v0, v0, v17                                  // 0000004AD9A0: 3A002300
	v_xor_b32_e32 v5, v5, v17                                  // 0000004AD9A4: 3A0A2305
	v_xor_b32_e32 v6, v6, v17                                  // 0000004AD9A8: 3A0C2306
	v_xor_b32_e32 v7, v7, v17                                  // 0000004AD9AC: 3A0E2307
	v_xor_b32_e32 v9, v9, v17                                  // 0000004AD9B0: 3A122309
	v_xor_b32_e32 v10, v10, v17                                // 0000004AD9B4: 3A14230A
	v_xor_b32_e32 v11, v11, v17                                // 0000004AD9B8: 3A16230B
	v_xor_b32_e32 v12, v12, v17                                // 0000004AD9BC: 3A18230C
	v_xor_b32_e32 v13, v13, v17                                // 0000004AD9C0: 3A1A230D
	v_xor_b32_e32 v14, v14, v17                                // 0000004AD9C4: 3A1C230E
	v_xor_b32_e32 v15, v15, v17                                // 0000004AD9C8: 3A1E230F
	v_xor_b32_e32 v19, v19, v17                                // 0000004AD9CC: 3A262313
	v_xor_b32_e32 v20, v20, v17                                // 0000004AD9D0: 3A282314
	v_xor_b32_e32 v21, v21, v17                                // 0000004AD9D4: 3A2A2315
	v_xor_b32_e32 v22, v22, v17                                // 0000004AD9D8: 3A2C2316
	v_xor_b32_e32 v23, v23, v17                                // 0000004AD9DC: 3A2E2317
	v_xor_b32_e32 v24, v24, v17                                // 0000004AD9E0: 3A302318
	v_xor_b32_e32 v25, v25, v17                                // 0000004AD9E4: 3A322319
	v_xor_b32_e32 v26, v26, v17                                // 0000004AD9E8: 3A34231A
	v_xor_b32_e32 v27, v27, v17                                // 0000004AD9EC: 3A36231B
	v_xor_b32_e32 v28, v28, v17                                // 0000004AD9F0: 3A38231C
	v_xor_b32_e32 v29, v29, v17                                // 0000004AD9F4: 3A3A231D
	v_xor_b32_e32 v30, v30, v17                                // 0000004AD9F8: 3A3C231E
	v_xor_b32_e32 v31, v31, v17                                // 0000004AD9FC: 3A3E231F
	v_xor_b32_e32 v32, v32, v17                                // 0000004ADA00: 3A402320
	v_xor_b32_e32 v33, v33, v17                                // 0000004ADA04: 3A422321
	v_xor_b32_e32 v34, v35, v17                                // 0000004ADA08: 3A442323
	v_xor_b32_e32 v35, v36, v17                                // 0000004ADA0C: 3A462324
	v_xor_b32_e32 v36, v37, v17                                // 0000004ADA10: 3A482325
	v_xor_b32_e32 v37, v38, v17                                // 0000004ADA14: 3A4A2326
	v_xor_b32_e32 v38, v39, v17                                // 0000004ADA18: 3A4C2327
	v_or_b32_e32 v39, -8, v18                                  // 0000004ADA1C: 384E24C8
	v_and_or_b32 v41, 0x60, v40, v17                           // 0000004ADA20: D6570029 044650FF 00000060
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000004ADA2C: BF8704A2
	.long 0xd7000727                                           // 0000004ADA30: D7000727
	v_cndmask_b32_e32 v0, v39, v136, vcc_lo                    // 0000004ADA34: 02011127
	s_xor_b32 s7, s7, -1                                       // 0000004ADA38: 8D07C107
	s_and_b32 s7, exec_lo, s7                                  // 0000004ADA3C: 8B07077E
	v_lshlrev_b32_e32 v41, 9, v41                              // 0000004ADA40: 30525289
	s_or_b32 s3, s7, s3                                        // 0000004ADA44: 8C030307
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004ADA48: BF870001
	v_lshl_or_b32 v42, v3, 2, v41                              // 0000004ADA4C: D656002A 04A50503
	v_lshl_or_b32 v43, v0, 2, v41                              // 0000004ADA54: D656002B 04A50500
	v_lshl_or_b32 v44, v5, 2, v41                              // 0000004ADA5C: D656002C 04A50505
	v_lshl_or_b32 v45, v6, 2, v41                              // 0000004ADA64: D656002D 04A50506
	v_lshl_or_b32 v46, v7, 2, v41                              // 0000004ADA6C: D656002E 04A50507
	v_lshl_or_b32 v47, v9, 2, v41                              // 0000004ADA74: D656002F 04A50509
	v_lshl_or_b32 v48, v10, 2, v41                             // 0000004ADA7C: D6560030 04A5050A
	v_lshl_or_b32 v49, v11, 2, v41                             // 0000004ADA84: D6560031 04A5050B
	v_lshl_or_b32 v50, v12, 2, v41                             // 0000004ADA8C: D6560032 04A5050C
	v_lshl_or_b32 v51, v13, 2, v41                             // 0000004ADA94: D6560033 04A5050D
	v_lshl_or_b32 v52, v14, 2, v41                             // 0000004ADA9C: D6560034 04A5050E
	v_lshl_or_b32 v53, v15, 2, v41                             // 0000004ADAA4: D6560035 04A5050F
	v_lshl_or_b32 v54, v19, 2, v41                             // 0000004ADAAC: D6560036 04A50513
	v_lshl_or_b32 v55, v20, 2, v41                             // 0000004ADAB4: D6560037 04A50514
	v_lshl_or_b32 v56, v21, 2, v41                             // 0000004ADABC: D6560038 04A50515
	v_lshl_or_b32 v57, v22, 2, v41                             // 0000004ADAC4: D6560039 04A50516
	v_lshl_or_b32 v58, v23, 2, v41                             // 0000004ADACC: D656003A 04A50517
	v_lshl_or_b32 v59, v24, 2, v41                             // 0000004ADAD4: D656003B 04A50518
	v_lshl_or_b32 v60, v25, 2, v41                             // 0000004ADADC: D656003C 04A50519
	v_lshl_or_b32 v61, v26, 2, v41                             // 0000004ADAE4: D656003D 04A5051A
	v_lshl_or_b32 v62, v27, 2, v41                             // 0000004ADAEC: D656003E 04A5051B
	v_lshl_or_b32 v63, v28, 2, v41                             // 0000004ADAF4: D656003F 04A5051C
	v_lshl_or_b32 v64, v29, 2, v41                             // 0000004ADAFC: D6560040 04A5051D
	v_lshl_or_b32 v65, v30, 2, v41                             // 0000004ADB04: D6560041 04A5051E
	v_lshl_or_b32 v66, v31, 2, v41                             // 0000004ADB0C: D6560042 04A5051F
	v_lshl_or_b32 v67, v32, 2, v41                             // 0000004ADB14: D6560043 04A50520
	v_lshl_or_b32 v68, v33, 2, v41                             // 0000004ADB1C: D6560044 04A50521
	v_lshl_or_b32 v69, v34, 2, v41                             // 0000004ADB24: D6560045 04A50522
	v_lshl_or_b32 v70, v35, 2, v41                             // 0000004ADB2C: D6560046 04A50523
	v_lshl_or_b32 v71, v36, 2, v41                             // 0000004ADB34: D6560047 04A50524
	v_lshl_or_b32 v72, v37, 2, v41                             // 0000004ADB3C: D6560048 04A50525
	v_lshl_or_b32 v41, v38, 2, v41                             // 0000004ADB44: D6560029 04A50526
	ds_load_b32 v73, v42                                       // 0000004ADB4C: D8D80000 4900002A
	ds_load_b32 v74, v43                                       // 0000004ADB54: D8D80000 4A00002B
	ds_load_b32 v75, v44                                       // 0000004ADB5C: D8D80000 4B00002C
	ds_load_b32 v76, v45                                       // 0000004ADB64: D8D80000 4C00002D
	ds_load_b32 v77, v46                                       // 0000004ADB6C: D8D80000 4D00002E
	ds_load_b32 v78, v47                                       // 0000004ADB74: D8D80000 4E00002F
	ds_load_b32 v79, v48                                       // 0000004ADB7C: D8D80000 4F000030
	ds_load_b32 v80, v49                                       // 0000004ADB84: D8D80000 50000031
	ds_load_b32 v81, v50                                       // 0000004ADB8C: D8D80000 51000032
	ds_load_b32 v82, v51                                       // 0000004ADB94: D8D80000 52000033
	ds_load_b32 v83, v52                                       // 0000004ADB9C: D8D80000 53000034
	ds_load_b32 v84, v53                                       // 0000004ADBA4: D8D80000 54000035
	ds_load_b32 v85, v54                                       // 0000004ADBAC: D8D80000 55000036
	ds_load_b32 v86, v55                                       // 0000004ADBB4: D8D80000 56000037
	ds_load_b32 v87, v56                                       // 0000004ADBBC: D8D80000 57000038
	ds_load_b32 v88, v57                                       // 0000004ADBC4: D8D80000 58000039
	ds_load_b32 v89, v58                                       // 0000004ADBCC: D8D80000 5900003A
	ds_load_b32 v90, v59                                       // 0000004ADBD4: D8D80000 5A00003B
	ds_load_b32 v91, v60                                       // 0000004ADBDC: D8D80000 5B00003C
	ds_load_b32 v92, v61                                       // 0000004ADBE4: D8D80000 5C00003D
	ds_load_b32 v93, v62                                       // 0000004ADBEC: D8D80000 5D00003E
	ds_load_b32 v94, v63                                       // 0000004ADBF4: D8D80000 5E00003F
	ds_load_b32 v95, v64                                       // 0000004ADBFC: D8D80000 5F000040
	ds_load_b32 v96, v65                                       // 0000004ADC04: D8D80000 60000041
	ds_load_b32 v97, v66                                       // 0000004ADC0C: D8D80000 61000042
	ds_load_b32 v98, v67                                       // 0000004ADC14: D8D80000 62000043
	ds_load_b32 v99, v68                                       // 0000004ADC1C: D8D80000 63000044
	ds_load_b32 v100, v69                                      // 0000004ADC24: D8D80000 64000045
	ds_load_b32 v101, v70                                      // 0000004ADC2C: D8D80000 65000046
	ds_load_b32 v102, v71                                      // 0000004ADC34: D8D80000 66000047
	ds_load_b32 v103, v72                                      // 0000004ADC3C: D8D80000 67000048
	ds_load_b32 v104, v41                                      // 0000004ADC44: D8D80000 68000029
	s_waitcnt lgkmcnt(30)                                      // 0000004ADC4C: BF89FDE7
	v_dual_add_f32 v105, v73, v74 :: v_dual_add_nc_u32 v40, 64, v40// 0000004ADC50: C9209549 692850C0
	s_waitcnt lgkmcnt(28)                                      // 0000004ADC58: BF89FDC7
	v_dual_sub_f32 v73, v73, v74 :: v_dual_add_f32 v74, v75, v76// 0000004ADC5C: C9489549 494A994B
	s_waitcnt lgkmcnt(26)                                      // 0000004ADC64: BF89FDA7
	v_dual_sub_f32 v75, v75, v76 :: v_dual_add_f32 v76, v77, v78// 0000004ADC68: C948994B 4B4C9D4D
	s_waitcnt lgkmcnt(24)                                      // 0000004ADC70: BF89FD87
	v_dual_sub_f32 v77, v77, v78 :: v_dual_add_f32 v78, v79, v80// 0000004ADC74: C9489D4D 4D4EA14F
	s_waitcnt lgkmcnt(22)                                      // 0000004ADC7C: BF89FD67
	v_dual_sub_f32 v79, v79, v80 :: v_dual_add_f32 v80, v81, v82// 0000004ADC80: C948A14F 4F50A551
	s_waitcnt lgkmcnt(20)                                      // 0000004ADC88: BF89FD47
	v_dual_sub_f32 v81, v81, v82 :: v_dual_add_f32 v82, v83, v84// 0000004ADC8C: C948A551 5152A953
	s_waitcnt lgkmcnt(18)                                      // 0000004ADC94: BF89FD27
	v_dual_sub_f32 v83, v83, v84 :: v_dual_add_f32 v84, v85, v86// 0000004ADC98: C948A953 5354AD55
	s_waitcnt lgkmcnt(16)                                      // 0000004ADCA0: BF89FD07
	v_dual_sub_f32 v85, v85, v86 :: v_dual_add_f32 v86, v87, v88// 0000004ADCA4: C948AD55 5556B157
	s_waitcnt lgkmcnt(14)                                      // 0000004ADCAC: BF89FCE7
	v_dual_sub_f32 v87, v87, v88 :: v_dual_add_f32 v88, v89, v90// 0000004ADCB0: C948B157 5758B559
	s_waitcnt lgkmcnt(12)                                      // 0000004ADCB8: BF89FCC7
	v_dual_sub_f32 v89, v89, v90 :: v_dual_add_f32 v90, v91, v92// 0000004ADCBC: C948B559 595AB95B
	s_waitcnt lgkmcnt(10)                                      // 0000004ADCC4: BF89FCA7
	v_dual_sub_f32 v91, v91, v92 :: v_dual_add_f32 v92, v93, v94// 0000004ADCC8: C948B95B 5B5CBD5D
	s_waitcnt lgkmcnt(8)                                       // 0000004ADCD0: BF89FC87
	v_dual_sub_f32 v93, v93, v94 :: v_dual_add_f32 v94, v95, v96// 0000004ADCD4: C948BD5D 5D5EC15F
	s_waitcnt lgkmcnt(6)                                       // 0000004ADCDC: BF89FC67
	v_dual_sub_f32 v95, v95, v96 :: v_dual_add_f32 v96, v97, v98// 0000004ADCE0: C948C15F 5F60C561
	s_waitcnt lgkmcnt(4)                                       // 0000004ADCE8: BF89FC47
	v_dual_sub_f32 v97, v97, v98 :: v_dual_add_f32 v98, v99, v100// 0000004ADCEC: C948C561 6162C963
	s_waitcnt lgkmcnt(2)                                       // 0000004ADCF4: BF89FC27
	v_dual_sub_f32 v99, v99, v100 :: v_dual_add_f32 v100, v101, v102// 0000004ADCF8: C948C963 6364CD65
	s_waitcnt lgkmcnt(0)                                       // 0000004ADD00: BF89FC07
	v_dual_sub_f32 v101, v101, v102 :: v_dual_add_f32 v102, v103, v104// 0000004ADD04: C948CD65 6566D167
	v_dual_sub_f32 v103, v103, v104 :: v_dual_add_f32 v104, v105, v74// 0000004ADD0C: C948D167 67689569
	v_sub_f32_e32 v74, v105, v74                               // 0000004ADD14: 08949569
	v_add_f32_e32 v105, v73, v75                               // 0000004ADD18: 06D29749
	v_sub_f32_e32 v73, v73, v75                                // 0000004ADD1C: 08929749
	v_add_f32_e32 v75, v76, v78                                // 0000004ADD20: 06969D4C
	v_sub_f32_e32 v76, v76, v78                                // 0000004ADD24: 08989D4C
	v_add_f32_e32 v78, v77, v79                                // 0000004ADD28: 069C9F4D
	v_sub_f32_e32 v77, v77, v79                                // 0000004ADD2C: 089A9F4D
	v_add_f32_e32 v79, v80, v82                                // 0000004ADD30: 069EA550
	v_sub_f32_e32 v80, v80, v82                                // 0000004ADD34: 08A0A550
	v_add_f32_e32 v82, v81, v83                                // 0000004ADD38: 06A4A751
	v_sub_f32_e32 v81, v81, v83                                // 0000004ADD3C: 08A2A751
	v_add_f32_e32 v83, v84, v86                                // 0000004ADD40: 06A6AD54
	v_sub_f32_e32 v84, v84, v86                                // 0000004ADD44: 08A8AD54
	v_add_f32_e32 v86, v85, v87                                // 0000004ADD48: 06ACAF55
	v_sub_f32_e32 v85, v85, v87                                // 0000004ADD4C: 08AAAF55
	v_add_f32_e32 v87, v88, v90                                // 0000004ADD50: 06AEB558
	v_sub_f32_e32 v88, v88, v90                                // 0000004ADD54: 08B0B558
	v_add_f32_e32 v90, v89, v91                                // 0000004ADD58: 06B4B759
	v_sub_f32_e32 v89, v89, v91                                // 0000004ADD5C: 08B2B759
	v_add_f32_e32 v91, v92, v94                                // 0000004ADD60: 06B6BD5C
	v_sub_f32_e32 v92, v92, v94                                // 0000004ADD64: 08B8BD5C
	v_add_f32_e32 v94, v93, v95                                // 0000004ADD68: 06BCBF5D
	v_sub_f32_e32 v93, v93, v95                                // 0000004ADD6C: 08BABF5D
	v_add_f32_e32 v95, v96, v98                                // 0000004ADD70: 06BEC560
	v_sub_f32_e32 v96, v96, v98                                // 0000004ADD74: 08C0C560
	v_add_f32_e32 v98, v97, v99                                // 0000004ADD78: 06C4C761
	v_sub_f32_e32 v97, v97, v99                                // 0000004ADD7C: 08C2C761
	v_add_f32_e32 v99, v100, v102                              // 0000004ADD80: 06C6CD64
	v_sub_f32_e32 v100, v100, v102                             // 0000004ADD84: 08C8CD64
	v_add_f32_e32 v102, v101, v103                             // 0000004ADD88: 06CCCF65
	v_sub_f32_e32 v101, v101, v103                             // 0000004ADD8C: 08CACF65
	v_add_f32_e32 v103, v104, v75                              // 0000004ADD90: 06CE9768
	v_dual_sub_f32 v75, v104, v75 :: v_dual_add_f32 v104, v105, v78// 0000004ADD94: C9489768 4B689D69
	v_dual_sub_f32 v78, v105, v78 :: v_dual_add_f32 v105, v74, v76// 0000004ADD9C: C9489D69 4E68994A
	v_sub_f32_e32 v74, v74, v76                                // 0000004ADDA4: 0894994A
	v_add_f32_e32 v76, v73, v77                                // 0000004ADDA8: 06989B49
	v_sub_f32_e32 v73, v73, v77                                // 0000004ADDAC: 08929B49
	v_add_f32_e32 v77, v79, v83                                // 0000004ADDB0: 069AA74F
	v_sub_f32_e32 v79, v79, v83                                // 0000004ADDB4: 089EA74F
	v_add_f32_e32 v83, v82, v86                                // 0000004ADDB8: 06A6AD52
	v_sub_f32_e32 v82, v82, v86                                // 0000004ADDBC: 08A4AD52
	v_add_f32_e32 v86, v80, v84                                // 0000004ADDC0: 06ACA950
	v_sub_f32_e32 v80, v80, v84                                // 0000004ADDC4: 08A0A950
	v_add_f32_e32 v84, v81, v85                                // 0000004ADDC8: 06A8AB51
	v_sub_f32_e32 v81, v81, v85                                // 0000004ADDCC: 08A2AB51
	v_add_f32_e32 v85, v87, v91                                // 0000004ADDD0: 06AAB757
	v_sub_f32_e32 v87, v87, v91                                // 0000004ADDD4: 08AEB757
	v_add_f32_e32 v91, v90, v94                                // 0000004ADDD8: 06B6BD5A
	v_sub_f32_e32 v90, v90, v94                                // 0000004ADDDC: 08B4BD5A
	v_add_f32_e32 v94, v88, v92                                // 0000004ADDE0: 06BCB958
	v_sub_f32_e32 v88, v88, v92                                // 0000004ADDE4: 08B0B958
	v_add_f32_e32 v92, v89, v93                                // 0000004ADDE8: 06B8BB59
	v_sub_f32_e32 v89, v89, v93                                // 0000004ADDEC: 08B2BB59
	v_add_f32_e32 v93, v95, v99                                // 0000004ADDF0: 06BAC75F
	v_sub_f32_e32 v95, v95, v99                                // 0000004ADDF4: 08BEC75F
	v_add_f32_e32 v99, v98, v102                               // 0000004ADDF8: 06C6CD62
	v_sub_f32_e32 v98, v98, v102                               // 0000004ADDFC: 08C4CD62
	v_add_f32_e32 v102, v96, v100                              // 0000004ADE00: 06CCC960
	v_sub_f32_e32 v96, v96, v100                               // 0000004ADE04: 08C0C960
	v_add_f32_e32 v100, v97, v101                              // 0000004ADE08: 06C8CB61
	v_sub_f32_e32 v97, v97, v101                               // 0000004ADE0C: 08C2CB61
	v_add_f32_e32 v101, v103, v77                              // 0000004ADE10: 06CA9B67
	v_sub_f32_e32 v77, v103, v77                               // 0000004ADE14: 089A9B67
	v_add_f32_e32 v103, v104, v83                              // 0000004ADE18: 06CEA768
	v_dual_sub_f32 v83, v104, v83 :: v_dual_add_f32 v104, v105, v86// 0000004ADE1C: C948A768 5368AD69
	v_dual_sub_f32 v86, v105, v86 :: v_dual_add_f32 v105, v76, v84// 0000004ADE24: C948AD69 5668A94C
	v_sub_f32_e32 v76, v76, v84                                // 0000004ADE2C: 0898A94C
	v_add_f32_e32 v84, v75, v79                                // 0000004ADE30: 06A89F4B
	v_sub_f32_e32 v75, v75, v79                                // 0000004ADE34: 08969F4B
	v_add_f32_e32 v79, v78, v82                                // 0000004ADE38: 069EA54E
	v_sub_f32_e32 v78, v78, v82                                // 0000004ADE3C: 089CA54E
	v_add_f32_e32 v82, v74, v80                                // 0000004ADE40: 06A4A14A
	v_sub_f32_e32 v74, v74, v80                                // 0000004ADE44: 0894A14A
	v_add_f32_e32 v80, v73, v81                                // 0000004ADE48: 06A0A349
	v_sub_f32_e32 v73, v73, v81                                // 0000004ADE4C: 0892A349
	v_add_f32_e32 v81, v85, v93                                // 0000004ADE50: 06A2BB55
	v_sub_f32_e32 v85, v85, v93                                // 0000004ADE54: 08AABB55
	v_add_f32_e32 v93, v91, v99                                // 0000004ADE58: 06BAC75B
	v_sub_f32_e32 v91, v91, v99                                // 0000004ADE5C: 08B6C75B
	v_add_f32_e32 v99, v94, v102                               // 0000004ADE60: 06C6CD5E
	v_sub_f32_e32 v94, v94, v102                               // 0000004ADE64: 08BCCD5E
	v_add_f32_e32 v102, v92, v100                              // 0000004ADE68: 06CCC95C
	v_sub_f32_e32 v92, v92, v100                               // 0000004ADE6C: 08B8C95C
	v_add_f32_e32 v100, v87, v95                               // 0000004ADE70: 06C8BF57
	v_sub_f32_e32 v87, v87, v95                                // 0000004ADE74: 08AEBF57
	v_add_f32_e32 v95, v90, v98                                // 0000004ADE78: 06BEC55A
	v_sub_f32_e32 v90, v90, v98                                // 0000004ADE7C: 08B4C55A
	v_add_f32_e32 v98, v88, v96                                // 0000004ADE80: 06C4C158
	v_sub_f32_e32 v88, v88, v96                                // 0000004ADE84: 08B0C158
	v_add_f32_e32 v96, v89, v97                                // 0000004ADE88: 06C0C359
	v_sub_f32_e32 v89, v89, v97                                // 0000004ADE8C: 08B2C359
	v_add_f32_e32 v97, v101, v81                               // 0000004ADE90: 06C2A365
	v_sub_f32_e32 v81, v101, v81                               // 0000004ADE94: 08A2A365
	v_add_f32_e32 v101, v103, v93                              // 0000004ADE98: 06CABB67
	v_sub_f32_e32 v93, v103, v93                               // 0000004ADE9C: 08BABB67
	v_add_f32_e32 v103, v104, v99                              // 0000004ADEA0: 06CEC768
	v_dual_sub_f32 v99, v104, v99 :: v_dual_add_f32 v104, v105, v102// 0000004ADEA4: C948C768 6368CD69
	v_dual_sub_f32 v102, v105, v102 :: v_dual_add_f32 v105, v84, v100// 0000004ADEAC: C948CD69 6668C954
	v_sub_f32_e32 v84, v84, v100                               // 0000004ADEB4: 08A8C954
	v_add_f32_e32 v100, v79, v95                               // 0000004ADEB8: 06C8BF4F
	v_sub_f32_e32 v79, v79, v95                                // 0000004ADEBC: 089EBF4F
	v_add_f32_e32 v95, v82, v98                                // 0000004ADEC0: 06BEC552
	v_sub_f32_e32 v82, v82, v98                                // 0000004ADEC4: 08A4C552
	v_add_f32_e32 v98, v80, v96                                // 0000004ADEC8: 06C4C150
	v_sub_f32_e32 v80, v80, v96                                // 0000004ADECC: 08A0C150
	v_add_f32_e32 v96, v77, v85                                // 0000004ADED0: 06C0AB4D
	v_sub_f32_e32 v77, v77, v85                                // 0000004ADED4: 089AAB4D
	v_add_f32_e32 v85, v83, v91                                // 0000004ADED8: 06AAB753
	v_sub_f32_e32 v83, v83, v91                                // 0000004ADEDC: 08A6B753
	v_add_f32_e32 v91, v86, v94                                // 0000004ADEE0: 06B6BD56
	v_sub_f32_e32 v86, v86, v94                                // 0000004ADEE4: 08ACBD56
	v_add_f32_e32 v94, v76, v92                                // 0000004ADEE8: 06BCB94C
	v_sub_f32_e32 v76, v76, v92                                // 0000004ADEEC: 0898B94C
	v_add_f32_e32 v92, v75, v87                                // 0000004ADEF0: 06B8AF4B
	v_sub_f32_e32 v75, v75, v87                                // 0000004ADEF4: 0896AF4B
	v_add_f32_e32 v87, v78, v90                                // 0000004ADEF8: 06AEB54E
	v_sub_f32_e32 v78, v78, v90                                // 0000004ADEFC: 089CB54E
	v_add_f32_e32 v90, v74, v88                                // 0000004ADF00: 06B4B14A
	v_sub_f32_e32 v74, v74, v88                                // 0000004ADF04: 0894B14A
	v_add_f32_e32 v88, v73, v89                                // 0000004ADF08: 06B0B349
	v_sub_f32_e32 v73, v73, v89                                // 0000004ADF0C: 0892B349
	ds_store_b32 v42, v97                                      // 0000004ADF10: D8340000 0000612A
	ds_store_b32 v43, v101                                     // 0000004ADF18: D8340000 0000652B
	ds_store_b32 v44, v103                                     // 0000004ADF20: D8340000 0000672C
	ds_store_b32 v45, v104                                     // 0000004ADF28: D8340000 0000682D
	ds_store_b32 v46, v105                                     // 0000004ADF30: D8340000 0000692E
	ds_store_b32 v47, v100                                     // 0000004ADF38: D8340000 0000642F
	ds_store_b32 v48, v95                                      // 0000004ADF40: D8340000 00005F30
	ds_store_b32 v49, v98                                      // 0000004ADF48: D8340000 00006231
	ds_store_b32 v50, v96                                      // 0000004ADF50: D8340000 00006032
	ds_store_b32 v51, v85                                      // 0000004ADF58: D8340000 00005533
	ds_store_b32 v52, v91                                      // 0000004ADF60: D8340000 00005B34
	ds_store_b32 v53, v94                                      // 0000004ADF68: D8340000 00005E35
	ds_store_b32 v54, v92                                      // 0000004ADF70: D8340000 00005C36
	ds_store_b32 v55, v87                                      // 0000004ADF78: D8340000 00005737
	ds_store_b32 v56, v90                                      // 0000004ADF80: D8340000 00005A38
	ds_store_b32 v57, v88                                      // 0000004ADF88: D8340000 00005839
	ds_store_b32 v58, v81                                      // 0000004ADF90: D8340000 0000513A
	ds_store_b32 v59, v93                                      // 0000004ADF98: D8340000 00005D3B
	ds_store_b32 v60, v99                                      // 0000004ADFA0: D8340000 0000633C
	ds_store_b32 v61, v102                                     // 0000004ADFA8: D8340000 0000663D
	ds_store_b32 v62, v84                                      // 0000004ADFB0: D8340000 0000543E
	ds_store_b32 v63, v79                                      // 0000004ADFB8: D8340000 00004F3F
	ds_store_b32 v64, v82                                      // 0000004ADFC0: D8340000 00005240
	ds_store_b32 v65, v80                                      // 0000004ADFC8: D8340000 00005041
	ds_store_b32 v66, v77                                      // 0000004ADFD0: D8340000 00004D42
	ds_store_b32 v67, v83                                      // 0000004ADFD8: D8340000 00005343
	ds_store_b32 v68, v86                                      // 0000004ADFE0: D8340000 00005644
	ds_store_b32 v69, v76                                      // 0000004ADFE8: D8340000 00004C45
	ds_store_b32 v70, v75                                      // 0000004ADFF0: D8340000 00004B46
	ds_store_b32 v71, v78                                      // 0000004ADFF8: D8340000 00004E47
	ds_store_b32 v72, v74                                      // 0000004AE000: D8340000 00004A48
	ds_store_b32 v41, v73                                      // 0000004AE008: D8340000 00004929
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 0000004AE010: 917E037E
	s_cbranch_execnz 65154                                     // 0000004AE014: BFA6FE82 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi4ELb1ELi8EEEvPKjiPKDF16_S5_Pti+0x1620>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000004AE018: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004AE01C: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 0000004AE020: 8C7E007E
	v_or_b32_e32 v0, 32, v16                                   // 0000004AE024: 380020A0
	v_or_b32_e32 v5, 64, v16                                   // 0000004AE028: 380A20C0
	v_or_b32_e32 v6, 0x60, v16                                 // 0000004AE02C: 380C20FF 00000060
	v_lshlrev_b32_e32 v23, 9, v3                               // 0000004AE034: 302E0689
	v_xor_b32_e32 v7, v16, v17                                 // 0000004AE038: 3A0E2310
	v_xor_b32_e32 v0, v0, v17                                  // 0000004AE03C: 3A002300
	v_xor_b32_e32 v5, v5, v17                                  // 0000004AE040: 3A0A2305
	v_xor_b32_e32 v6, v6, v17                                  // 0000004AE044: 3A0C2306
	s_waitcnt lgkmcnt(0)                                       // 0000004AE048: BF89FC07
	v_lshl_or_b32 v22, v7, 2, v23                              // 0000004AE04C: D6560016 045D0507
	v_lshl_or_b32 v0, v0, 2, v23                               // 0000004AE054: D6560000 045D0500
	v_lshl_or_b32 v5, v5, 2, v23                               // 0000004AE05C: D6560005 045D0505
	v_lshl_or_b32 v6, v6, 2, v23                               // 0000004AE064: D6560006 045D0506
	s_barrier                                                  // 0000004AE06C: BFBD0000
	buffer_gl0_inv                                             // 0000004AE070: E0AC0000 00000000
	ds_load_b32 v7, v22                                        // 0000004AE078: D8D80000 07000016
	ds_load_b32 v9, v0                                         // 0000004AE080: D8D80000 09000000
	ds_load_b32 v10, v5                                        // 0000004AE088: D8D80000 0A000005
	ds_load_b32 v11, v6                                        // 0000004AE090: D8D80000 0B000006
	v_or_b32_e32 v21, 2, v16                                   // 0000004AE098: 382A2082
	v_or_b32_e32 v20, 4, v16                                   // 0000004AE09C: 38282084
	v_or_b32_e32 v15, 6, v16                                   // 0000004AE0A0: 381E2086
	v_cvt_f32_f16_e32 v24, v130/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AE0A4: 7E301782
	v_cvt_f32_f16_e32 v25, v2                                  // 0000004AE0A8: 7E321702
	v_xor_b32_e32 v12, v21, v17                                // 0000004AE0AC: 3A182315
	v_xor_b32_e32 v13, v20, v17                                // 0000004AE0B0: 3A1A2314
	v_xor_b32_e32 v14, v15, v17                                // 0000004AE0B4: 3A1C230F
	.long 0xd7600003                                           // 0000004AE0B8: D7600003
	v_cndmask_b32_e32 v0, v24, v144, vcc_lo                    // 0000004AE0BC: 02012118
	v_or_b32_e32 v2, 34, v16                                   // 0000004AE0C0: 380420A2
	v_or_b32_e32 v32, 0x42, v16                                // 0000004AE0C4: 384020FF 00000042
	.long 0xd7600000                                           // 0000004AE0CC: D7600000
	v_cndmask_b32_e32 v0, v25, v128, vcc_lo                    // 0000004AE0D0: 02010119
	.long 0xd7600007                                           // 0000004AE0D4: D7600007
	v_cndmask_b32_e32 v0, v25, v144, vcc_lo                    // 0000004AE0D8: 02012119
	v_or_b32_e32 v40, 0x66, v16                                // 0000004AE0DC: 385020FF 00000066
	v_xor_b32_e32 v2, v2, v17                                  // 0000004AE0E4: 3A042302
	.long 0xd760000c                                           // 0000004AE0E8: D760000C
	v_cndmask_b32_e32 v0, v24, v158, vcc_lo                    // 0000004AE0EC: 02013D18
	.long 0xd760000e                                           // 0000004AE0F0: D760000E
	v_cndmask_b32_e32 v0, v24, v143, vcc_lo                    // 0000004AE0F4: 02011F18
	s_waitcnt lgkmcnt(2)                                       // 0000004AE0F8: BF89FC27
	v_sub_f32_e32 v30, v7, v9                                  // 0000004AE0FC: 083C1307
	s_waitcnt lgkmcnt(0)                                       // 0000004AE100: BF89FC07
	v_dual_add_f32 v26, v7, v9 :: v_dual_sub_f32 v31, v10, v11 // 0000004AE104: C90A1307 1A1E170A
	v_add_f32_e32 v27, v10, v11                                // 0000004AE10C: 0636170A
	v_lshl_or_b32 v12, v12, 2, v23                             // 0000004AE110: D656000C 045D050C
	v_lshl_or_b32 v13, v13, 2, v23                             // 0000004AE118: D656000D 045D050D
	v_lshl_or_b32 v14, v14, 2, v23                             // 0000004AE120: D656000E 045D050E
	ds_load_b32 v19, v12                                       // 0000004AE128: D8D80000 1300000C
	ds_load_b32 v28, v13                                       // 0000004AE130: D8D80000 1C00000D
	ds_load_b32 v29, v14                                       // 0000004AE138: D8D80000 1D00000E
	v_sub_f32_e32 v10, v26, v27                                // 0000004AE140: 0814371A
	v_sub_f32_e32 v11, v30, v31                                // 0000004AE144: 08163F1E
	v_or_b32_e32 v7, 0x62, v16                                 // 0000004AE148: 380E20FF 00000062
	v_lshl_or_b32 v2, v2, 2, v23                               // 0000004AE150: D6560002 045D0502
	.long 0xd7600011                                           // 0000004AE158: D7600011
	v_cndmask_b32_e32 v0, v25, v159, vcc_lo                    // 0000004AE15C: 02013F19
	v_dual_mul_f32 v10, 0x3db504f3, v10 :: v_dual_add_f32 v9, v30, v31// 0000004AE160: C8C814FF 0A083F1E 3DB504F3
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 0000004AE16C: 101616FF 3DB504F3
	v_xor_b32_e32 v30, v32, v17                                // 0000004AE174: 3A3C2320
	v_xor_b32_e32 v7, v7, v17                                  // 0000004AE178: 3A0E2307
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AE17C: BF870214
	v_dual_mul_f32 v10, s3, v10 :: v_dual_mul_f32 v9, 0x3db504f3, v9// 0000004AE180: C8C61403 0A0812FF 3DB504F3
	v_mul_f32_e32 v11, s7, v11                                 // 0000004AE18C: 10161607
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AE190: BF870214
	v_lshl_or_b32 v30, v30, 2, v23                             // 0000004AE194: D656001E 045D051E
	v_lshl_or_b32 v7, v7, 2, v23                               // 0000004AE19C: D6560007 045D0507
	v_or_b32_e32 v31, 38, v16                                  // 0000004AE1A4: 383E20A6
	v_mul_f32_e32 v9, s0, v9                                   // 0000004AE1A8: 10121200
	ds_store_b32 v0, v9                                        // 0000004AE1AC: D8340000 00000900
	ds_store_b32 v5, v10                                       // 0000004AE1B4: D8340000 00000A05
	ds_store_b32 v6, v11                                       // 0000004AE1BC: D8340000 00000B06
	v_or_b32_e32 v9, 36, v16                                   // 0000004AE1C4: 381220A4
	v_or_b32_e32 v10, 0x44, v16                                // 0000004AE1C8: 381420FF 00000044
	v_or_b32_e32 v11, 0x64, v16                                // 0000004AE1D0: 381620FF 00000064
	ds_load_b32 v0, v2                                         // 0000004AE1D8: D8D80000 00000002
	ds_load_b32 v5, v30                                        // 0000004AE1E0: D8D80000 0500001E
	ds_load_b32 v6, v7                                         // 0000004AE1E8: D8D80000 06000007
	v_or_b32_e32 v32, 0x46, v16                                // 0000004AE1F0: 384020FF 00000046
	v_xor_b32_e32 v9, v9, v17                                  // 0000004AE1F8: 3A122309
	v_xor_b32_e32 v10, v10, v17                                // 0000004AE1FC: 3A14230A
	v_xor_b32_e32 v11, v11, v17                                // 0000004AE200: 3A16230B
	v_xor_b32_e32 v31, v31, v17                                // 0000004AE204: 3A3E231F
	v_xor_b32_e32 v32, v32, v17                                // 0000004AE208: 3A402320
	v_lshl_or_b32 v9, v9, 2, v23                               // 0000004AE20C: D6560009 045D0509
	v_lshl_or_b32 v10, v10, 2, v23                             // 0000004AE214: D656000A 045D050A
	v_lshl_or_b32 v11, v11, 2, v23                             // 0000004AE21C: D656000B 045D050B
	v_lshl_or_b32 v31, v31, 2, v23                             // 0000004AE224: D656001F 045D051F
	v_lshl_or_b32 v32, v32, 2, v23                             // 0000004AE22C: D6560020 045D0520
	ds_load_b32 v33, v9                                        // 0000004AE234: D8D80000 21000009
	ds_load_b32 v34, v10                                       // 0000004AE23C: D8D80000 2200000A
	ds_load_b32 v35, v11                                       // 0000004AE244: D8D80000 2300000B
	ds_load_b32 v36, v31                                       // 0000004AE24C: D8D80000 2400001F
	ds_load_b32 v37, v32                                       // 0000004AE254: D8D80000 25000020
	.long 0xd7600000                                           // 0000004AE25C: D7600000
	v_cndmask_b32_e32 v0, v24, v129, vcc_lo                    // 0000004AE260: 02010318
	.long 0xd7600003                                           // 0000004AE264: D7600003
	v_cndmask_b32_e32 v0, v25, v129, vcc_lo                    // 0000004AE268: 02010319
	.long 0xd7600007                                           // 0000004AE26C: D7600007
	v_cndmask_b32_e32 v0, v25, v146, vcc_lo                    // 0000004AE270: 02012519
	v_add_f32_e32 v26, v26, v27                                // 0000004AE274: 0634371A
	.long 0xd7600009                                           // 0000004AE278: D7600009
	v_cndmask_b32_e32 v0, v25, v157, vcc_lo                    // 0000004AE27C: 02013B19
	s_waitcnt lgkmcnt(7)                                       // 0000004AE280: BF89FC77
	v_add_f32_e32 v38, v19, v0                                 // 0000004AE284: 064C0113
	s_waitcnt lgkmcnt(5)                                       // 0000004AE288: BF89FC57
	v_dual_sub_f32 v0, v19, v0 :: v_dual_add_f32 v39, v5, v6   // 0000004AE28C: C9480113 00260D05
	v_sub_f32_e32 v5, v5, v6                                   // 0000004AE294: 080A0D05
	v_mul_f32_e32 v26, 0x3db504f3, v26                         // 0000004AE298: 103434FF 3DB504F3
	.long 0xd760000b                                           // 0000004AE2A0: D760000B
	v_cndmask_b32_e32 v0, v25, v142, vcc_lo                    // 0000004AE2A4: 02011D19
	.long 0xd760000d                                           // 0000004AE2A8: D760000D
	v_cndmask_b32_e32 v0, v25, v158, vcc_lo                    // 0000004AE2AC: 02013D19
	.long 0xd760000f                                           // 0000004AE2B0: D760000F
	v_cndmask_b32_e32 v0, v25, v143, vcc_lo                    // 0000004AE2B4: 02011F19
	v_add_f32_e32 v19, v0, v5                                  // 0000004AE2B8: 06260B00
	v_sub_f32_e32 v0, v0, v5                                   // 0000004AE2BC: 08000B00
	v_add_f32_e32 v6, v38, v39                                 // 0000004AE2C0: 060C4F26
	v_sub_f32_e32 v38, v38, v39                                // 0000004AE2C4: 084C4F26
	v_xor_b32_e32 v39, v40, v17                                // 0000004AE2C8: 3A4E2328
	s_waitcnt lgkmcnt(2)                                       // 0000004AE2CC: BF89FC27
	v_add_f32_e32 v40, v34, v35                                // 0000004AE2D0: 06504722
	v_dual_mul_f32 v19, 0x3db504f3, v19 :: v_dual_mul_f32 v6, 0x3db504f3, v6// 0000004AE2D4: C8C626FF 13060CFF 3DB504F3
	v_mul_f32_e32 v38, 0x3db504f3, v38                         // 0000004AE2E0: 104C4CFF 3DB504F3
	v_lshl_or_b32 v39, v39, 2, v23                             // 0000004AE2E8: D6560027 045D0527
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000004AE2F0: 100000FF 3DB504F3
	.long 0xd7600008                                           // 0000004AE2F8: D7600008
	v_cndmask_b32_e32 v0, v24, v157, vcc_lo                    // 0000004AE2FC: 02013B18
	v_dual_mul_f32 v5, s0, v6 :: v_dual_mul_f32 v6, s3, v19    // 0000004AE300: C8C60C00 05062603
	v_add_f32_e32 v19, v28, v33                                // 0000004AE308: 0626431C
	ds_load_b32 v41, v39                                       // 0000004AE30C: D8D80000 29000027
	.long 0xd7600000                                           // 0000004AE314: D7600000
	v_cndmask_b32_e32 v0, v24, v145, vcc_lo                    // 0000004AE318: 02012318
	.long 0xd7600003                                           // 0000004AE31C: D7600003
	v_cndmask_b32_e32 v0, v25, v145, vcc_lo                    // 0000004AE320: 02012319
	.long 0xd760000a                                           // 0000004AE324: D760000A
	v_cndmask_b32_e32 v0, v24, v142, vcc_lo                    // 0000004AE328: 02011D18
	v_add_f32_e32 v42, v19, v40                                // 0000004AE32C: 06545113
	v_dual_sub_f32 v28, v28, v33 :: v_dual_sub_f32 v33, v34, v35// 0000004AE330: C94A431C 1C204722
	v_dual_mul_f32 v34, s0, v38 :: v_dual_sub_f32 v19, v19, v40// 0000004AE338: C8CA4C00 22125113
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004AE340: BF870223
	v_mul_f32_e32 v35, 0x3db504f3, v42                         // 0000004AE344: 104654FF 3DB504F3
	.long 0xd7600000                                           // 0000004AE34C: D7600000
	v_cndmask_b32_e32 v0, v24, v130, vcc_lo                    // 0000004AE350: 02010518
	v_add_f32_e32 v38, v28, v33                                // 0000004AE354: 064C431C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004AE358: BF870194
	v_dual_sub_f32 v28, v28, v33 :: v_dual_mul_f32 v19, 0x3db504f3, v19// 0000004AE35C: C946431C 1C1226FF 3DB504F3
	v_dual_mul_f32 v0, s3, v0 :: v_dual_mul_f32 v33, s0, v35   // 0000004AE368: C8C60003 00204600
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004AE370: BF870003
	v_mul_f32_e32 v35, 0x3db504f3, v38                         // 0000004AE374: 10464CFF 3DB504F3
	.long 0xd7600000                                           // 0000004AE37C: D7600000
	v_cndmask_b32_e32 v0, v25, v130, vcc_lo                    // 0000004AE380: 02010519
	.long 0xd7600003                                           // 0000004AE384: D7600003
	v_cndmask_b32_e32 v0, v24, v146, vcc_lo                    // 0000004AE388: 02012518
	v_mul_f32_e32 v28, 0x3db504f3, v28                         // 0000004AE38C: 103838FF 3DB504F3
	s_waitcnt lgkmcnt(2)                                       // 0000004AE394: BF89FC27
	v_add_f32_e32 v38, v29, v36                                // 0000004AE398: 064C491D
	v_sub_f32_e32 v29, v29, v36                                // 0000004AE39C: 083A491D
	v_mul_f32_e32 v35, s0, v35                                 // 0000004AE3A0: 10464600
	v_dual_mul_f32 v19, s3, v19 :: v_dual_mul_f32 v28, s7, v28 // 0000004AE3A4: C8C62603 131C3807
	.long 0xd7600007                                           // 0000004AE3AC: D7600007
	v_cndmask_b32_e32 v0, v24, v147, vcc_lo                    // 0000004AE3B0: 02012718
	s_waitcnt lgkmcnt(0)                                       // 0000004AE3B4: BF89FC07
	v_add_f32_e32 v40, v37, v41                                // 0000004AE3B8: 06505325
	v_sub_f32_e32 v36, v37, v41                                // 0000004AE3BC: 08485325
	.long 0xd7600003                                           // 0000004AE3C0: D7600003
	v_cndmask_b32_e32 v0, v25, v131, vcc_lo                    // 0000004AE3C4: 02010719
	.long 0xd7600000                                           // 0000004AE3C8: D7600000
	v_cndmask_b32_e32 v0, v24, v131, vcc_lo                    // 0000004AE3CC: 02010718
	.long 0xd7600010                                           // 0000004AE3D0: D7600010
	v_cndmask_b32_e32 v0, v24, v159, vcc_lo                    // 0000004AE3D4: 02013F18
	v_add_f32_e32 v37, v38, v40                                // 0000004AE3D8: 064A5126
	v_sub_f32_e32 v38, v38, v40                                // 0000004AE3DC: 084C5126
	v_add_f32_e32 v41, v29, v36                                // 0000004AE3E0: 0652491D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004AE3E4: BF870113
	v_dual_sub_f32 v29, v29, v36 :: v_dual_mul_f32 v36, 0x3db504f3, v37// 0000004AE3E8: C946491D 1D244AFF 3DB504F3
	v_dual_mul_f32 v38, 0x3db504f3, v38 :: v_dual_mul_f32 v37, 0x3db504f3, v41// 0000004AE3F4: C8C64CFF 262452FF 3DB504F3
	ds_store_b32 v12, v5                                       // 0000004AE400: D8340000 0000050C
	ds_store_b32 v2, v6                                        // 0000004AE408: D8340000 00000602
	ds_store_b32 v30, v34                                      // 0000004AE410: D8340000 0000221E
	ds_store_b32 v7, v0                                        // 0000004AE418: D8340000 00000007
	ds_store_b32 v13, v33                                      // 0000004AE420: D8340000 0000210D
	ds_store_b32 v9, v35                                       // 0000004AE428: D8340000 00002309
	ds_store_b32 v10, v19                                      // 0000004AE430: D8340000 0000130A
	ds_store_b32 v11, v28                                      // 0000004AE438: D8340000 00001C0B
	v_or_b32_e32 v19, 8, v16                                   // 0000004AE440: 38262088
	v_or_b32_e32 v7, 40, v16                                   // 0000004AE444: 380E20A8
	v_or_b32_e32 v9, 0x48, v16                                 // 0000004AE448: 381220FF 00000048
	v_or_b32_e32 v10, 0x68, v16                                // 0000004AE450: 381420FF 00000068
	v_mul_f32_e32 v0, s0, v36                                  // 0000004AE458: 10004800
	v_xor_b32_e32 v11, v19, v17                                // 0000004AE45C: 3A162313
	v_xor_b32_e32 v7, v7, v17                                  // 0000004AE460: 3A0E2307
	v_mul_f32_e32 v2, s3, v37                                  // 0000004AE464: 10044A03
	v_mul_f32_e32 v6, 0x3db504f3, v29                          // 0000004AE468: 100C3AFF 3DB504F3
	.long 0xd7600000                                           // 0000004AE470: D7600000
	v_cndmask_b32_e32 v0, v25, v147, vcc_lo                    // 0000004AE474: 02012719
	v_xor_b32_e32 v9, v9, v17                                  // 0000004AE478: 3A122309
	v_xor_b32_e32 v10, v10, v17                                // 0000004AE47C: 3A14230A
	v_lshl_or_b32 v11, v11, 2, v23                             // 0000004AE480: D656000B 045D050B
	v_mul_f32_e32 v5, s7, v38                                  // 0000004AE488: 100A4C07
	v_lshl_or_b32 v7, v7, 2, v23                               // 0000004AE48C: D6560007 045D0507
	v_mul_f32_e32 v6, s0, v6                                   // 0000004AE494: 100C0C00
	v_lshl_or_b32 v9, v9, 2, v23                               // 0000004AE498: D6560009 045D0509
	v_lshl_or_b32 v10, v10, 2, v23                             // 0000004AE4A0: D656000A 045D050A
	ds_store_b32 v14, v0                                       // 0000004AE4A8: D8340000 0000000E
	ds_store_b32 v31, v2                                       // 0000004AE4B0: D8340000 0000021F
	ds_store_b32 v32, v5                                       // 0000004AE4B8: D8340000 00000520
	ds_store_b32 v39, v6                                       // 0000004AE4C0: D8340000 00000627
	ds_load_b32 v0, v11                                        // 0000004AE4C8: D8D80000 0000000B
	ds_load_b32 v2, v7                                         // 0000004AE4D0: D8D80000 02000007
	ds_load_b32 v5, v9                                         // 0000004AE4D8: D8D80000 05000009
	ds_load_b32 v6, v10                                        // 0000004AE4E0: D8D80000 0600000A
	.long 0xd7600000                                           // 0000004AE4E8: D7600000
	v_cndmask_b32_e32 v0, v24, v132, vcc_lo                    // 0000004AE4EC: 02010918
	.long 0xd7600003                                           // 0000004AE4F0: D7600003
	v_cndmask_b32_e32 v0, v25, v132, vcc_lo                    // 0000004AE4F4: 02010919
	.long 0xd7600007                                           // 0000004AE4F8: D7600007
	v_cndmask_b32_e32 v0, v24, v148, vcc_lo                    // 0000004AE4FC: 02012918
	v_or_b32_e32 v14, 10, v16                                  // 0000004AE500: 381C208A
	v_or_b32_e32 v28, 0x6a, v16                                // 0000004AE504: 383820FF 0000006A
	v_or_b32_e32 v37, 0x4e, v16                                // 0000004AE50C: 384A20FF 0000004E
	v_or_b32_e32 v38, 0x6e, v16                                // 0000004AE514: 384C20FF 0000006E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AE51C: BF870214
	v_xor_b32_e32 v29, v14, v17                                // 0000004AE520: 3A3A230E
	v_xor_b32_e32 v28, v28, v17                                // 0000004AE524: 3A38231C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AE528: BF870214
	v_xor_b32_e32 v37, v37, v17                                // 0000004AE52C: 3A4A2325
	v_xor_b32_e32 v38, v38, v17                                // 0000004AE530: 3A4C2326
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AE534: BF870214
	v_lshl_or_b32 v29, v29, 2, v23                             // 0000004AE538: D656001D 045D051D
	v_lshl_or_b32 v28, v28, 2, v23                             // 0000004AE540: D656001C 045D051C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AE548: BF870214
	v_lshl_or_b32 v37, v37, 2, v23                             // 0000004AE54C: D6560025 045D0525
	v_lshl_or_b32 v38, v38, 2, v23                             // 0000004AE554: D6560026 045D0526
	s_waitcnt lgkmcnt(2)                                       // 0000004AE55C: BF89FC27
	v_add_f32_e32 v12, v0, v2                                  // 0000004AE560: 06180500
	v_sub_f32_e32 v0, v0, v2                                   // 0000004AE564: 08000500
	s_waitcnt lgkmcnt(0)                                       // 0000004AE568: BF89FC07
	v_add_f32_e32 v13, v5, v6                                  // 0000004AE56C: 061A0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004AE570: BF870091
	v_dual_sub_f32 v2, v5, v6 :: v_dual_add_f32 v5, v12, v13   // 0000004AE574: C9480D05 02041B0C
	v_add_f32_e32 v6, v0, v2                                   // 0000004AE57C: 060C0500
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004AE580: BF870112
	v_dual_sub_f32 v0, v0, v2 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 0000004AE584: C9460500 00040AFF 3DB504F3
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 0000004AE590: 100C0CFF 3DB504F3
	v_sub_f32_e32 v12, v12, v13                                // 0000004AE598: 08181B0C
	v_or_b32_e32 v13, 0x4a, v16                                // 0000004AE59C: 381A20FF 0000004A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AE5A4: BF870214
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000004AE5A8: 100000FF 3DB504F3
	v_dual_mul_f32 v2, s0, v5 :: v_dual_mul_f32 v5, s3, v6     // 0000004AE5B0: C8C60A00 02040C03
	.long 0xd7600003                                           // 0000004AE5B8: D7600003
	v_cndmask_b32_e32 v0, v25, v133, vcc_lo                    // 0000004AE5BC: 02010B19
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 0000004AE5C0: 101818FF 3DB504F3
	.long 0xd7600000                                           // 0000004AE5C8: D7600000
	v_cndmask_b32_e32 v0, v25, v148, vcc_lo                    // 0000004AE5CC: 02012919
	v_xor_b32_e32 v13, v13, v17                                // 0000004AE5D0: 3A1A230D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004AE5D4: BF870193
	v_mul_f32_e32 v6, s7, v12                                  // 0000004AE5D8: 100C1807
	v_mul_f32_e32 v0, s0, v0                                   // 0000004AE5DC: 10000000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004AE5E0: BF870003
	v_lshl_or_b32 v31, v13, 2, v23                             // 0000004AE5E4: D656001F 045D050D
	v_or_b32_e32 v13, 12, v16                                  // 0000004AE5EC: 381A208C
	ds_store_b32 v11, v2                                       // 0000004AE5F0: D8340000 0000020B
	ds_store_b32 v7, v5                                        // 0000004AE5F8: D8340000 00000507
	ds_store_b32 v9, v6                                        // 0000004AE600: D8340000 00000609
	ds_store_b32 v10, v0                                       // 0000004AE608: D8340000 0000000A
	v_or_b32_e32 v7, 44, v16                                   // 0000004AE610: 380E20AC
	v_or_b32_e32 v9, 0x4c, v16                                 // 0000004AE614: 381220FF 0000004C
	v_or_b32_e32 v10, 0x6c, v16                                // 0000004AE61C: 381420FF 0000006C
	v_xor_b32_e32 v11, v13, v17                                // 0000004AE624: 3A16230D
	v_or_b32_e32 v12, 42, v16                                  // 0000004AE628: 381820AA
	v_xor_b32_e32 v7, v7, v17                                  // 0000004AE62C: 3A0E2307
	v_xor_b32_e32 v9, v9, v17                                  // 0000004AE630: 3A122309
	v_xor_b32_e32 v10, v10, v17                                // 0000004AE634: 3A14230A
	v_lshl_or_b32 v11, v11, 2, v23                             // 0000004AE638: D656000B 045D050B
	v_xor_b32_e32 v12, v12, v17                                // 0000004AE640: 3A18230C
	v_lshl_or_b32 v7, v7, 2, v23                               // 0000004AE644: D6560007 045D0507
	v_lshl_or_b32 v9, v9, 2, v23                               // 0000004AE64C: D6560009 045D0509
	v_lshl_or_b32 v10, v10, 2, v23                             // 0000004AE654: D656000A 045D050A
	ds_load_b32 v32, v11                                       // 0000004AE65C: D8D80000 2000000B
	ds_load_b32 v33, v7                                        // 0000004AE664: D8D80000 21000007
	ds_load_b32 v34, v9                                        // 0000004AE66C: D8D80000 22000009
	ds_load_b32 v35, v10                                       // 0000004AE674: D8D80000 2300000A
	v_lshl_or_b32 v30, v12, 2, v23                             // 0000004AE67C: D656001E 045D050C
	ds_load_b32 v0, v29                                        // 0000004AE684: D8D80000 0000001D
	ds_load_b32 v2, v30                                        // 0000004AE68C: D8D80000 0200001E
	ds_load_b32 v5, v31                                        // 0000004AE694: D8D80000 0500001F
	ds_load_b32 v6, v28                                        // 0000004AE69C: D8D80000 0600001C
	.long 0xd7600007                                           // 0000004AE6A4: D7600007
	v_cndmask_b32_e32 v0, v25, v150, vcc_lo                    // 0000004AE6A8: 02012D19
	.long 0xd7600000                                           // 0000004AE6AC: D7600000
	v_cndmask_b32_e32 v0, v24, v133, vcc_lo                    // 0000004AE6B0: 02010B18
	s_waitcnt lgkmcnt(6)                                       // 0000004AE6B4: BF89FC67
	v_add_f32_e32 v40, v32, v33                                // 0000004AE6B8: 06504320
	s_waitcnt lgkmcnt(4)                                       // 0000004AE6BC: BF89FC47
	v_dual_sub_f32 v32, v32, v33 :: v_dual_sub_f32 v33, v34, v35// 0000004AE6C0: C94A4320 20204722
	s_waitcnt lgkmcnt(2)                                       // 0000004AE6C8: BF89FC27
	v_dual_add_f32 v41, v34, v35 :: v_dual_add_f32 v12, v0, v2 // 0000004AE6CC: C9084722 290C0500
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004AE6D4: BF870002
	v_add_f32_e32 v35, v32, v33                                // 0000004AE6D8: 06464320
	v_sub_f32_e32 v32, v32, v33                                // 0000004AE6DC: 08404320
	s_waitcnt lgkmcnt(0)                                       // 0000004AE6E0: BF89FC07
	v_add_f32_e32 v36, v5, v6                                  // 0000004AE6E4: 06480D05
	v_add_f32_e32 v46, v40, v41                                // 0000004AE6E8: 065C5328
	v_sub_f32_e32 v40, v40, v41                                // 0000004AE6EC: 08505328
	v_mul_f32_e32 v32, 0x3db504f3, v32                         // 0000004AE6F0: 104040FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004AE6F8: BF870113
	v_mul_f32_e32 v34, 0x3db504f3, v46                         // 0000004AE6FC: 10445CFF 3DB504F3
	v_mul_f32_e32 v32, s7, v32                                 // 0000004AE704: 10404007
	.long 0xd7600007                                           // 0000004AE708: D7600007
	v_cndmask_b32_e32 v0, v24, v151, vcc_lo                    // 0000004AE70C: 02012F18
	v_sub_f32_e32 v0, v0, v2                                   // 0000004AE710: 08000500
	v_dual_sub_f32 v2, v5, v6 :: v_dual_add_f32 v5, v12, v36   // 0000004AE714: C9480D05 0204490C
	v_sub_f32_e32 v12, v12, v36                                // 0000004AE71C: 0818490C
	v_or_b32_e32 v36, 46, v16                                  // 0000004AE720: 384820AE
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004AE724: BF8701A3
	v_dual_add_f32 v6, v0, v2 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 0000004AE728: C9060500 06040AFF 3DB504F3
	v_sub_f32_e32 v0, v0, v2                                   // 0000004AE734: 08000500
	v_xor_b32_e32 v36, v36, v17                                // 0000004AE738: 3A482324
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AE73C: BF870213
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 0000004AE740: 100C0CFF 3DB504F3
	v_mul_f32_e32 v2, s0, v5                                   // 0000004AE748: 10040A00
	.long 0xd7600000                                           // 0000004AE74C: D7600000
	v_cndmask_b32_e32 v0, v24, v149, vcc_lo                    // 0000004AE750: 02012B18
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AE754: BF870214
	v_lshl_or_b32 v36, v36, 2, v23                             // 0000004AE758: D6560024 045D0524
	v_dual_mul_f32 v0, 0x3db504f3, v0 :: v_dual_mul_f32 v5, s3, v6// 0000004AE760: C8C600FF 00040C03 3DB504F3
	v_mul_f32_e32 v6, 0x3db504f3, v12                          // 0000004AE76C: 100C18FF 3DB504F3
	v_or_b32_e32 v12, 14, v16                                  // 0000004AE774: 3818208E
	.long 0xd7600003                                           // 0000004AE778: D7600003
	v_cndmask_b32_e32 v0, v25, v149, vcc_lo                    // 0000004AE77C: 02012B19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004AE780: BF870193
	v_mul_f32_e32 v6, s0, v6                                   // 0000004AE784: 100C0C00
	v_xor_b32_e32 v39, v12, v17                                // 0000004AE788: 3A4E230C
	.long 0xd7600000                                           // 0000004AE78C: D7600000
	v_cndmask_b32_e32 v0, v24, v134, vcc_lo                    // 0000004AE790: 02010D18
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004AE794: BF870224
	v_mul_f32_e32 v0, s3, v0                                   // 0000004AE798: 10000003
	.long 0xd7600003                                           // 0000004AE79C: D7600003
	v_cndmask_b32_e32 v0, v24, v150, vcc_lo                    // 0000004AE7A0: 02012D18
	v_lshl_or_b32 v39, v39, 2, v23                             // 0000004AE7A4: D6560027 045D0527
	ds_load_b32 v42, v39                                       // 0000004AE7AC: D8D80000 2A000027
	ds_load_b32 v43, v36                                       // 0000004AE7B4: D8D80000 2B000024
	ds_load_b32 v44, v37                                       // 0000004AE7BC: D8D80000 2C000025
	ds_load_b32 v45, v38                                       // 0000004AE7C4: D8D80000 2D000026
	v_dual_mul_f32 v33, s0, v34 :: v_dual_mul_f32 v34, 0x3db504f3, v35// 0000004AE7CC: C8C64400 212246FF 3DB504F3
	v_mul_f32_e32 v35, 0x3db504f3, v40                         // 0000004AE7D8: 104650FF 3DB504F3
	.long 0xd7600000                                           // 0000004AE7E0: D7600000
	v_cndmask_b32_e32 v0, v25, v134, vcc_lo                    // 0000004AE7E4: 02010D19
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004AE7E8: BF870001
	v_dual_mul_f32 v35, s3, v35 :: v_dual_mul_f32 v34, s0, v34 // 0000004AE7EC: C8C64603 23224400
	ds_store_b32 v29, v2                                       // 0000004AE7F4: D8340000 0000021D
	ds_store_b32 v30, v5                                       // 0000004AE7FC: D8340000 0000051E
	ds_store_b32 v31, v6                                       // 0000004AE804: D8340000 0000061F
	ds_store_b32 v28, v0                                       // 0000004AE80C: D8340000 0000001C
	ds_store_b32 v11, v33                                      // 0000004AE814: D8340000 0000210B
	ds_store_b32 v7, v34                                       // 0000004AE81C: D8340000 00002207
	ds_store_b32 v9, v35                                       // 0000004AE824: D8340000 00002309
	ds_store_b32 v10, v32                                      // 0000004AE82C: D8340000 0000200A
	v_or_b32_e32 v11, 16, v16                                  // 0000004AE834: 38162090
	v_or_b32_e32 v7, 48, v16                                   // 0000004AE838: 380E20B0
	.long 0xd7600000                                           // 0000004AE83C: D7600000
	v_cndmask_b32_e32 v0, v24, v135, vcc_lo                    // 0000004AE840: 02010F18
	v_or_b32_e32 v9, 0x50, v16                                 // 0000004AE844: 381220FF 00000050
	v_or_b32_e32 v10, 0x70, v16                                // 0000004AE84C: 381420FF 00000070
	.long 0xd7600003                                           // 0000004AE854: D7600003
	v_cndmask_b32_e32 v0, v25, v135, vcc_lo                    // 0000004AE858: 02010F19
	v_xor_b32_e32 v28, v11, v17                                // 0000004AE85C: 3A38230B
	s_waitcnt lgkmcnt(10)                                      // 0000004AE860: BF89FCA7
	v_add_f32_e32 v40, v42, v43                                // 0000004AE864: 0650572A
	s_waitcnt lgkmcnt(8)                                       // 0000004AE868: BF89FC87
	v_dual_sub_f32 v42, v42, v43 :: v_dual_add_f32 v41, v44, v45// 0000004AE86C: C948572A 2A285B2C
	v_sub_f32_e32 v43, v44, v45                                // 0000004AE874: 08565B2C
	v_xor_b32_e32 v7, v7, v17                                  // 0000004AE878: 3A0E2307
	v_xor_b32_e32 v9, v9, v17                                  // 0000004AE87C: 3A122309
	v_xor_b32_e32 v10, v10, v17                                // 0000004AE880: 3A14230A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004AE884: BF8701B4
	v_dual_add_f32 v44, v40, v41 :: v_dual_add_f32 v45, v42, v43// 0000004AE888: C9085328 2C2C572A
	v_dual_sub_f32 v40, v40, v41 :: v_dual_sub_f32 v41, v42, v43// 0000004AE890: C94A5328 2828572A
	v_lshl_or_b32 v28, v28, 2, v23                             // 0000004AE898: D656001C 045D051C
	v_dual_mul_f32 v42, 0x3db504f3, v44 :: v_dual_mul_f32 v43, 0x3db504f3, v45// 0000004AE8A0: C8C658FF 2A2A5AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AE8AC: BF870213
	v_mul_f32_e32 v40, 0x3db504f3, v40                         // 0000004AE8B0: 105050FF 3DB504F3
	v_mul_f32_e32 v6, 0x3db504f3, v41                          // 0000004AE8B8: 100C52FF 3DB504F3
	v_lshl_or_b32 v7, v7, 2, v23                               // 0000004AE8C0: D6560007 045D0507
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000004AE8C8: BF870254
	v_mul_f32_e32 v0, s0, v42                                  // 0000004AE8CC: 10005400
	.long 0xd7600000                                           // 0000004AE8D0: D7600000
	v_cndmask_b32_e32 v0, v25, v151, vcc_lo                    // 0000004AE8D4: 02012F19
	v_dual_mul_f32 v2, s3, v43 :: v_dual_mul_f32 v5, s7, v40   // 0000004AE8D8: C8C65603 02045007
	v_lshl_or_b32 v9, v9, 2, v23                               // 0000004AE8E0: D6560009 045D0509
	v_lshl_or_b32 v29, v10, 2, v23                             // 0000004AE8E8: D656001D 045D050A
	v_mul_f32_e32 v6, s0, v6                                   // 0000004AE8F0: 100C0C00
	ds_store_b32 v39, v0                                       // 0000004AE8F4: D8340000 00000027
	ds_store_b32 v36, v2                                       // 0000004AE8FC: D8340000 00000224
	ds_store_b32 v37, v5                                       // 0000004AE904: D8340000 00000525
	ds_store_b32 v38, v6                                       // 0000004AE90C: D8340000 00000626
	ds_load_b32 v0, v28                                        // 0000004AE914: D8D80000 0000001C
	ds_load_b32 v2, v7                                         // 0000004AE91C: D8D80000 02000007
	ds_load_b32 v5, v9                                         // 0000004AE924: D8D80000 05000009
	ds_load_b32 v6, v29                                        // 0000004AE92C: D8D80000 0600001D
	.long 0xd7600000                                           // 0000004AE934: D7600000
	v_cndmask_b32_e32 v0, v24, v136, vcc_lo                    // 0000004AE938: 02011118
	.long 0xd7600003                                           // 0000004AE93C: D7600003
	v_cndmask_b32_e32 v0, v25, v136, vcc_lo                    // 0000004AE940: 02011119
	.long 0xd7600007                                           // 0000004AE944: D7600007
	v_cndmask_b32_e32 v0, v24, v152, vcc_lo                    // 0000004AE948: 02013118
	v_or_b32_e32 v31, 0x52, v16                                // 0000004AE94C: 383E20FF 00000052
	v_or_b32_e32 v32, 0x72, v16                                // 0000004AE954: 384020FF 00000072
	v_or_b32_e32 v41, 0x56, v16                                // 0000004AE95C: 385220FF 00000056
	v_or_b32_e32 v42, 0x76, v16                                // 0000004AE964: 385420FF 00000076
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AE96C: BF870214
	v_xor_b32_e32 v31, v31, v17                                // 0000004AE970: 3A3E231F
	v_xor_b32_e32 v32, v32, v17                                // 0000004AE974: 3A402320
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AE978: BF870214
	v_xor_b32_e32 v41, v41, v17                                // 0000004AE97C: 3A522329
	v_xor_b32_e32 v42, v42, v17                                // 0000004AE980: 3A54232A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AE984: BF870214
	v_lshl_or_b32 v31, v31, 2, v23                             // 0000004AE988: D656001F 045D051F
	v_lshl_or_b32 v32, v32, 2, v23                             // 0000004AE990: D6560020 045D0520
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AE998: BF870214
	v_lshl_or_b32 v41, v41, 2, v23                             // 0000004AE99C: D6560029 045D0529
	v_lshl_or_b32 v42, v42, 2, v23                             // 0000004AE9A4: D656002A 045D052A
	s_waitcnt lgkmcnt(2)                                       // 0000004AE9AC: BF89FC27
	v_add_f32_e32 v10, v0, v2                                  // 0000004AE9B0: 06140500
	v_sub_f32_e32 v0, v0, v2                                   // 0000004AE9B4: 08000500
	s_waitcnt lgkmcnt(0)                                       // 0000004AE9B8: BF89FC07
	v_add_f32_e32 v30, v5, v6                                  // 0000004AE9BC: 063C0D05
	v_sub_f32_e32 v2, v5, v6                                   // 0000004AE9C0: 08040D05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004AE9C4: BF870112
	v_add_f32_e32 v5, v10, v30                                 // 0000004AE9C8: 060A3D0A
	v_add_f32_e32 v6, v0, v2                                   // 0000004AE9CC: 060C0500
	v_sub_f32_e32 v10, v10, v30                                // 0000004AE9D0: 08143D0A
	v_sub_f32_e32 v0, v0, v2                                   // 0000004AE9D4: 08000500
	v_or_b32_e32 v30, 50, v16                                  // 0000004AE9D8: 383C20B2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AE9DC: BF870214
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v6, 0x3db504f3, v6// 0000004AE9E0: C8C60AFF 05060CFF 3DB504F3
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 0000004AE9EC: 101414FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AE9F4: BF870214
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000004AE9F8: 100000FF 3DB504F3
	v_xor_b32_e32 v30, v30, v17                                // 0000004AEA00: 3A3C231E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AEA04: BF870214
	v_dual_mul_f32 v2, s0, v5 :: v_dual_mul_f32 v5, s3, v6     // 0000004AEA08: C8C60A00 02040C03
	v_mul_f32_e32 v6, s7, v10                                  // 0000004AEA10: 100C1407
	v_or_b32_e32 v10, 18, v16                                  // 0000004AEA14: 38142092
	.long 0xd7600000                                           // 0000004AEA18: D7600000
	v_cndmask_b32_e32 v0, v25, v152, vcc_lo                    // 0000004AEA1C: 02013119
	v_lshl_or_b32 v30, v30, 2, v23                             // 0000004AEA20: D656001E 045D051E
	.long 0xd7600003                                           // 0000004AEA28: D7600003
	v_cndmask_b32_e32 v0, v25, v137, vcc_lo                    // 0000004AEA2C: 02011319
	.long 0xd7600007                                           // 0000004AEA30: D7600007
	v_cndmask_b32_e32 v0, v25, v154, vcc_lo                    // 0000004AEA34: 02013519
	v_xor_b32_e32 v33, v10, v17                                // 0000004AEA38: 3A42230A
	v_mul_f32_e32 v0, s0, v0                                   // 0000004AEA3C: 10000000
	ds_store_b32 v28, v2                                       // 0000004AEA40: D8340000 0000021C
	ds_store_b32 v7, v5                                        // 0000004AEA48: D8340000 00000507
	ds_store_b32 v9, v6                                        // 0000004AEA50: D8340000 00000609
	ds_store_b32 v29, v0                                       // 0000004AEA58: D8340000 0000001D
	v_or_b32_e32 v7, 52, v16                                   // 0000004AEA60: 380E20B4
	v_lshl_or_b32 v33, v33, 2, v23                             // 0000004AEA64: D6560021 045D0521
	ds_load_b32 v0, v33                                        // 0000004AEA6C: D8D80000 00000021
	ds_load_b32 v2, v30                                        // 0000004AEA74: D8D80000 0200001E
	ds_load_b32 v5, v31                                        // 0000004AEA7C: D8D80000 0500001F
	ds_load_b32 v6, v32                                        // 0000004AEA84: D8D80000 06000020
	v_xor_b32_e32 v7, v7, v17                                  // 0000004AEA8C: 3A0E2307
	v_or_b32_e32 v9, 20, v16                                   // 0000004AEA90: 38122094
	v_or_b32_e32 v28, 0x54, v16                                // 0000004AEA94: 383820FF 00000054
	v_or_b32_e32 v29, 0x74, v16                                // 0000004AEA9C: 383A20FF 00000074
	.long 0xd7600000                                           // 0000004AEAA4: D7600000
	v_cndmask_b32_e32 v0, v24, v137, vcc_lo                    // 0000004AEAA8: 02011318
	v_lshl_or_b32 v35, v7, 2, v23                              // 0000004AEAAC: D6560023 045D0507
	v_xor_b32_e32 v34, v9, v17                                 // 0000004AEAB4: 3A442309
	v_xor_b32_e32 v28, v28, v17                                // 0000004AEAB8: 3A38231C
	v_xor_b32_e32 v29, v29, v17                                // 0000004AEABC: 3A3A231D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004AEAC0: BF870193
	v_lshl_or_b32 v34, v34, 2, v23                             // 0000004AEAC4: D6560022 045D0522
	v_lshl_or_b32 v28, v28, 2, v23                             // 0000004AEACC: D656001C 045D051C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004AEAD4: BF870003
	v_lshl_or_b32 v29, v29, 2, v23                             // 0000004AEAD8: D656001D 045D051D
	ds_load_b32 v36, v34                                       // 0000004AEAE0: D8D80000 24000022
	ds_load_b32 v37, v35                                       // 0000004AEAE8: D8D80000 25000023
	ds_load_b32 v38, v28                                       // 0000004AEAF0: D8D80000 2600001C
	ds_load_b32 v39, v29                                       // 0000004AEAF8: D8D80000 2700001D
	s_waitcnt lgkmcnt(6)                                       // 0000004AEB00: BF89FC67
	v_add_f32_e32 v7, v0, v2                                   // 0000004AEB04: 060E0500
	v_sub_f32_e32 v0, v0, v2                                   // 0000004AEB08: 08000500
	s_waitcnt lgkmcnt(4)                                       // 0000004AEB0C: BF89FC47
	v_add_f32_e32 v40, v5, v6                                  // 0000004AEB10: 06500D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004AEB14: BF870091
	v_dual_sub_f32 v2, v5, v6 :: v_dual_add_f32 v5, v7, v40    // 0000004AEB18: C9480D05 02045107
	v_dual_add_f32 v6, v0, v2 :: v_dual_sub_f32 v7, v7, v40    // 0000004AEB20: C90A0500 06065107
	v_sub_f32_e32 v0, v0, v2                                   // 0000004AEB28: 08000500
	v_or_b32_e32 v40, 54, v16                                  // 0000004AEB2C: 385020B6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004AEB30: BF870193
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v6, 0x3db504f3, v6// 0000004AEB34: C8C60AFF 05060CFF 3DB504F3
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000004AEB40: 100000FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004AEB48: BF870193
	v_xor_b32_e32 v40, v40, v17                                // 0000004AEB4C: 3A502328
	v_dual_mul_f32 v2, s0, v5 :: v_dual_mul_f32 v5, s3, v6     // 0000004AEB50: C8C60A00 02040C03
	v_mul_f32_e32 v6, 0x3db504f3, v7                           // 0000004AEB58: 100C0EFF 3DB504F3
	v_or_b32_e32 v7, 22, v16                                   // 0000004AEB60: 380E2096
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004AEB64: BF870004
	v_lshl_or_b32 v40, v40, 2, v23                             // 0000004AEB68: D6560028 045D0528
	s_waitcnt lgkmcnt(0)                                       // 0000004AEB70: BF89FC07
	v_dual_add_f32 v44, v36, v37 :: v_dual_add_f32 v45, v38, v39// 0000004AEB74: C9084B24 2C2C4F26
	.long 0xd7600000                                           // 0000004AEB7C: D7600000
	v_cndmask_b32_e32 v0, v24, v153, vcc_lo                    // 0000004AEB80: 02013318
	v_xor_b32_e32 v43, v7, v17                                 // 0000004AEB84: 3A562307
	v_dual_sub_f32 v36, v36, v37 :: v_dual_sub_f32 v37, v38, v39// 0000004AEB88: C94A4B24 24244F26
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AEB90: BF870214
	v_add_f32_e32 v50, v44, v45                                // 0000004AEB94: 06645B2C
	v_mul_f32_e32 v6, s0, v6                                   // 0000004AEB98: 100C0C00
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004AEB9C: BF870004
	v_lshl_or_b32 v43, v43, 2, v23                             // 0000004AEBA0: D656002B 045D052B
	ds_load_b32 v46, v43                                       // 0000004AEBA8: D8D80000 2E00002B
	ds_load_b32 v47, v40                                       // 0000004AEBB0: D8D80000 2F000028
	ds_load_b32 v48, v41                                       // 0000004AEBB8: D8D80000 30000029
	ds_load_b32 v49, v42                                       // 0000004AEBC0: D8D80000 3100002A
	v_mul_f32_e32 v38, 0x3db504f3, v50                         // 0000004AEBC8: 104C64FF 3DB504F3
	.long 0xd7600000                                           // 0000004AEBD0: D7600000
	v_cndmask_b32_e32 v0, v24, v138, vcc_lo                    // 0000004AEBD4: 02011518
	v_add_f32_e32 v39, v36, v37                                // 0000004AEBD8: 064E4B24
	v_sub_f32_e32 v44, v44, v45                                // 0000004AEBDC: 08585B2C
	.long 0xd7600003                                           // 0000004AEBE0: D7600003
	v_cndmask_b32_e32 v0, v25, v153, vcc_lo                    // 0000004AEBE4: 02013319
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004AEBE8: BF870194
	v_dual_sub_f32 v36, v36, v37 :: v_dual_mul_f32 v37, s0, v38// 0000004AEBEC: C9464B24 24244C00
	v_dual_mul_f32 v38, 0x3db504f3, v39 :: v_dual_mul_f32 v39, 0x3db504f3, v44// 0000004AEBF4: C8C64EFF 262658FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000004AEC00: BF870143
	v_mul_f32_e32 v0, s3, v0                                   // 0000004AEC04: 10000003
	.long 0xd7600000                                           // 0000004AEC08: D7600000
	v_cndmask_b32_e32 v0, v25, v138, vcc_lo                    // 0000004AEC0C: 02011519
	.long 0xd7600003                                           // 0000004AEC10: D7600003
	v_cndmask_b32_e32 v0, v24, v154, vcc_lo                    // 0000004AEC14: 02013518
	v_mul_f32_e32 v36, 0x3db504f3, v36                         // 0000004AEC18: 104848FF 3DB504F3
	v_dual_mul_f32 v38, s0, v38 :: v_dual_mul_f32 v39, s3, v39 // 0000004AEC20: C8C64C00 26264E03
	s_waitcnt lgkmcnt(2)                                       // 0000004AEC28: BF89FC27
	v_add_f32_e32 v44, v46, v47                                // 0000004AEC2C: 06585F2E
	s_waitcnt lgkmcnt(0)                                       // 0000004AEC30: BF89FC07
	v_dual_sub_f32 v46, v46, v47 :: v_dual_add_f32 v45, v48, v49// 0000004AEC34: C9485F2E 2E2C6330
	v_dual_sub_f32 v47, v48, v49 :: v_dual_mul_f32 v36, s7, v36// 0000004AEC3C: C9466330 2F244807
	ds_store_b32 v33, v2                                       // 0000004AEC44: D8340000 00000221
	ds_store_b32 v30, v5                                       // 0000004AEC4C: D8340000 0000051E
	ds_store_b32 v31, v6                                       // 0000004AEC54: D8340000 0000061F
	ds_store_b32 v32, v0                                       // 0000004AEC5C: D8340000 00000020
	ds_store_b32 v34, v37                                      // 0000004AEC64: D8340000 00002522
	ds_store_b32 v35, v38                                      // 0000004AEC6C: D8340000 00002623
	ds_store_b32 v28, v39                                      // 0000004AEC74: D8340000 0000271C
	ds_store_b32 v29, v36                                      // 0000004AEC7C: D8340000 0000241D
	v_or_b32_e32 v6, 24, v16                                   // 0000004AEC84: 380C2098
	v_dual_add_f32 v48, v44, v45 :: v_dual_add_f32 v49, v46, v47// 0000004AEC88: C9085B2C 30305F2E
	v_sub_f32_e32 v44, v44, v45                                // 0000004AEC90: 08585B2C
	v_or_b32_e32 v29, 56, v16                                  // 0000004AEC94: 383A20B8
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004AEC98: BF870003
	v_dual_sub_f32 v45, v46, v47 :: v_dual_mul_f32 v46, 0x3db504f3, v48// 0000004AEC9C: C9465F2E 2D2E60FF 3DB504F3
	.long 0xd7600000                                           // 0000004AECA8: D7600000
	v_cndmask_b32_e32 v0, v24, v139, vcc_lo                    // 0000004AECAC: 02011718
	v_or_b32_e32 v30, 0x58, v16                                // 0000004AECB0: 383C20FF 00000058
	v_or_b32_e32 v31, 0x78, v16                                // 0000004AECB8: 383E20FF 00000078
	v_mul_f32_e32 v47, 0x3db504f3, v49                         // 0000004AECC0: 105E62FF 3DB504F3
	.long 0xd7600003                                           // 0000004AECC8: D7600003
	v_cndmask_b32_e32 v0, v25, v139, vcc_lo                    // 0000004AECCC: 02011719
	v_xor_b32_e32 v32, v6, v17                                 // 0000004AECD0: 3A402306
	v_mul_f32_e32 v44, 0x3db504f3, v44                         // 0000004AECD4: 105858FF 3DB504F3
	.long 0xd7600007                                           // 0000004AECDC: D7600007
	v_cndmask_b32_e32 v0, v24, v155, vcc_lo                    // 0000004AECE0: 02013718
	v_xor_b32_e32 v29, v29, v17                                // 0000004AECE4: 3A3A231D
	v_mul_f32_e32 v0, s0, v46                                  // 0000004AECE8: 10005C00
	v_mul_f32_e32 v28, 0x3db504f3, v45                         // 0000004AECEC: 10385AFF 3DB504F3
	.long 0xd7600000                                           // 0000004AECF4: D7600000
	v_cndmask_b32_e32 v0, v25, v155, vcc_lo                    // 0000004AECF8: 02013719
	v_xor_b32_e32 v30, v30, v17                                // 0000004AECFC: 3A3C231E
	v_xor_b32_e32 v31, v31, v17                                // 0000004AED00: 3A3E231F
	v_mul_f32_e32 v2, s3, v47                                  // 0000004AED04: 10045E03
	v_lshl_or_b32 v32, v32, 2, v23                             // 0000004AED08: D6560020 045D0520
	v_mul_f32_e32 v5, s7, v44                                  // 0000004AED10: 100A5807
	v_lshl_or_b32 v29, v29, 2, v23                             // 0000004AED14: D656001D 045D051D
	v_mul_f32_e32 v28, s0, v28                                 // 0000004AED1C: 10383800
	v_lshl_or_b32 v30, v30, 2, v23                             // 0000004AED20: D656001E 045D051E
	v_lshl_or_b32 v31, v31, 2, v23                             // 0000004AED28: D656001F 045D051F
	ds_store_b32 v43, v0                                       // 0000004AED30: D8340000 0000002B
	ds_store_b32 v40, v2                                       // 0000004AED38: D8340000 00000228
	ds_store_b32 v41, v5                                       // 0000004AED40: D8340000 00000529
	ds_store_b32 v42, v28                                      // 0000004AED48: D8340000 00001C2A
	ds_load_b32 v0, v32                                        // 0000004AED50: D8D80000 00000020
	ds_load_b32 v2, v29                                        // 0000004AED58: D8D80000 0200001D
	ds_load_b32 v5, v30                                        // 0000004AED60: D8D80000 0500001E
	ds_load_b32 v28, v31                                       // 0000004AED68: D8D80000 1C00001F
	.long 0xd7600000                                           // 0000004AED70: D7600000
	v_cndmask_b32_e32 v0, v24, v140, vcc_lo                    // 0000004AED74: 02011918
	.long 0xd7600003                                           // 0000004AED78: D7600003
	v_cndmask_b32_e32 v0, v24, v156, vcc_lo                    // 0000004AED7C: 02013918
	.long 0xd7600007                                           // 0000004AED80: D7600007
	v_cndmask_b32_e32 v0, v25, v156, vcc_lo                    // 0000004AED84: 02013919
	v_or_b32_e32 v36, 62, v16                                  // 0000004AED88: 384820BE
	v_or_b32_e32 v37, 0x5e, v16                                // 0000004AED8C: 384A20FF 0000005E
	v_or_b32_e32 v38, 0x7e, v16                                // 0000004AED94: 384C20FF 0000007E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004AED9C: BF870193
	v_xor_b32_e32 v36, v36, v17                                // 0000004AEDA0: 3A482324
	v_xor_b32_e32 v37, v37, v17                                // 0000004AEDA4: 3A4A2325
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004AEDA8: BF870193
	v_xor_b32_e32 v38, v38, v17                                // 0000004AEDAC: 3A4C2326
	v_lshl_or_b32 v36, v36, 2, v23                             // 0000004AEDB0: D6560024 045D0524
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004AEDB8: BF870003
	v_lshl_or_b32 v37, v37, 2, v23                             // 0000004AEDBC: D6560025 045D0525
	s_waitcnt lgkmcnt(2)                                       // 0000004AEDC4: BF89FC27
	v_add_f32_e32 v33, v0, v2                                  // 0000004AEDC8: 06420500
	v_sub_f32_e32 v0, v0, v2                                   // 0000004AEDCC: 08000500
	s_waitcnt lgkmcnt(0)                                       // 0000004AEDD0: BF89FC07
	v_add_f32_e32 v34, v5, v28                                 // 0000004AEDD4: 06443905
	v_sub_f32_e32 v2, v5, v28                                  // 0000004AEDD8: 08043905
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004AEDDC: BF870112
	v_add_f32_e32 v35, v33, v34                                // 0000004AEDE0: 06464521
	v_add_f32_e32 v28, v0, v2                                  // 0000004AEDE4: 06380500
	v_sub_f32_e32 v33, v33, v34                                // 0000004AEDE8: 08424521
	v_sub_f32_e32 v0, v0, v2                                   // 0000004AEDEC: 08000500
	v_or_b32_e32 v34, 58, v16                                  // 0000004AEDF0: 384420BA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004AEDF4: BF870194
	v_dual_mul_f32 v5, 0x3db504f3, v35 :: v_dual_mul_f32 v28, 0x3db504f3, v28// 0000004AEDF8: C8C646FF 051C38FF 3DB504F3
	v_dual_mul_f32 v33, 0x3db504f3, v33 :: v_dual_mul_f32 v0, 0x3db504f3, v0// 0000004AEE04: C8C642FF 210000FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004AEE10: BF870193
	v_xor_b32_e32 v34, v34, v17                                // 0000004AEE14: 3A442322
	v_mul_f32_e32 v2, s0, v5                                   // 0000004AEE18: 10040A00
	.long 0xd7600000                                           // 0000004AEE1C: D7600000
	v_cndmask_b32_e32 v0, v25, v140, vcc_lo                    // 0000004AEE20: 02011919
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004AEE24: BF870234
	v_dual_mul_f32 v33, s3, v33 :: v_dual_mul_f32 v0, s7, v0   // 0000004AEE28: C8C64203 21000007
	v_or_b32_e32 v5, 26, v16                                   // 0000004AEE30: 380A209A
	.long 0xd7600007                                           // 0000004AEE34: D7600007
	v_cndmask_b32_e32 v0, v25, v141, vcc_lo                    // 0000004AEE38: 02011B19
	v_mul_f32_e32 v28, s0, v28                                 // 0000004AEE3C: 10383800
	ds_store_b32 v32, v2                                       // 0000004AEE40: D8340000 00000220
	ds_store_b32 v29, v28                                      // 0000004AEE48: D8340000 00001C1D
	ds_store_b32 v30, v33                                      // 0000004AEE50: D8340000 0000211E
	ds_store_b32 v31, v0                                       // 0000004AEE58: D8340000 0000001F
	v_or_b32_e32 v0, 0x5a, v16                                 // 0000004AEE60: 380020FF 0000005A
	v_xor_b32_e32 v35, v5, v17                                 // 0000004AEE68: 3A462305
	v_or_b32_e32 v30, 0x7a, v16                                // 0000004AEE6C: 383C20FF 0000007A
	v_or_b32_e32 v2, 28, v16                                   // 0000004AEE74: 3804209C
	v_lshl_or_b32 v29, v34, 2, v23                             // 0000004AEE78: D656001D 045D0522
	v_xor_b32_e32 v0, v0, v17                                  // 0000004AEE80: 3A002300
	v_lshl_or_b32 v28, v35, 2, v23                             // 0000004AEE84: D656001C 045D0523
	v_or_b32_e32 v31, 60, v16                                  // 0000004AEE8C: 383E20BC
	v_or_b32_e32 v32, 0x5c, v16                                // 0000004AEE90: 384020FF 0000005C
	v_or_b32_e32 v35, 0x7c, v16                                // 0000004AEE98: 384620FF 0000007C
	v_lshl_or_b32 v34, v0, 2, v23                              // 0000004AEEA0: D6560022 045D0500
	v_or_b32_e32 v0, 30, v16                                   // 0000004AEEA8: 3800209E
	v_xor_b32_e32 v30, v30, v17                                // 0000004AEEAC: 3A3C231E
	v_xor_b32_e32 v33, v2, v17                                 // 0000004AEEB0: 3A422302
	v_xor_b32_e32 v31, v31, v17                                // 0000004AEEB4: 3A3E231F
	v_xor_b32_e32 v32, v32, v17                                // 0000004AEEB8: 3A402320
	v_xor_b32_e32 v35, v35, v17                                // 0000004AEEBC: 3A462323
	v_xor_b32_e32 v39, v0, v17                                 // 0000004AEEC0: 3A4E2300
	v_lshl_or_b32 v30, v30, 2, v23                             // 0000004AEEC4: D656001E 045D051E
	v_lshl_or_b32 v33, v33, 2, v23                             // 0000004AEECC: D6560021 045D0521
	v_lshl_or_b32 v31, v31, 2, v23                             // 0000004AEED4: D656001F 045D051F
	v_lshl_or_b32 v32, v32, 2, v23                             // 0000004AEEDC: D6560020 045D0520
	v_lshl_or_b32 v35, v35, 2, v23                             // 0000004AEEE4: D6560023 045D0523
	v_lshl_or_b32 v39, v39, 2, v23                             // 0000004AEEEC: D6560027 045D0527
	v_lshl_or_b32 v23, v38, 2, v23                             // 0000004AEEF4: D6560017 045D0526
	ds_load_b32 v38, v28                                       // 0000004AEEFC: D8D80000 2600001C
	ds_load_b32 v40, v29                                       // 0000004AEF04: D8D80000 2800001D
	ds_load_b32 v41, v34                                       // 0000004AEF0C: D8D80000 29000022
	ds_load_b32 v42, v30                                       // 0000004AEF14: D8D80000 2A00001E
	ds_load_b32 v43, v33                                       // 0000004AEF1C: D8D80000 2B000021
	ds_load_b32 v44, v31                                       // 0000004AEF24: D8D80000 2C00001F
	ds_load_b32 v45, v32                                       // 0000004AEF2C: D8D80000 2D000020
	ds_load_b32 v46, v35                                       // 0000004AEF34: D8D80000 2E000023
	ds_load_b32 v47, v39                                       // 0000004AEF3C: D8D80000 2F000027
	ds_load_b32 v48, v36                                       // 0000004AEF44: D8D80000 30000024
	ds_load_b32 v49, v37                                       // 0000004AEF4C: D8D80000 31000025
	ds_load_b32 v50, v23                                       // 0000004AEF54: D8D80000 32000017
	.long 0xd7600000                                           // 0000004AEF5C: D7600000
	v_cndmask_b32_e32 v0, v24, v128, vcc_lo                    // 0000004AEF60: 02010118
	.long 0xd7600003                                           // 0000004AEF64: D7600003
	v_cndmask_b32_e32 v0, v24, v141, vcc_lo                    // 0000004AEF68: 02011B18
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004AEF6C: BF870002
	v_mul_f32_e32 v26, s0, v26                                 // 0000004AEF70: 10343400
	s_mov_b32 s0, 0                                            // 0000004AEF74: BE800080
	s_waitcnt lgkmcnt(10)                                      // 0000004AEF78: BF89FCA7
	v_sub_f32_e32 v24, v38, v40                                // 0000004AEF7C: 08305126
	ds_store_b32 v22, v26                                      // 0000004AEF80: D8340000 00001A16
	s_waitcnt lgkmcnt(9)                                       // 0000004AEF88: BF89FC97
	v_dual_add_f32 v22, v38, v40 :: v_dual_add_f32 v25, v41, v42// 0000004AEF8C: C9085126 16185529
	s_waitcnt lgkmcnt(7)                                       // 0000004AEF94: BF89FC77
	v_dual_sub_f32 v26, v41, v42 :: v_dual_add_f32 v27, v43, v44// 0000004AEF98: C9485529 1A1A592B
	s_waitcnt lgkmcnt(5)                                       // 0000004AEFA0: BF89FC57
	v_add_f32_e32 v40, v45, v46                                // 0000004AEFA4: 06505D2D
	v_dual_sub_f32 v38, v43, v44 :: v_dual_sub_f32 v41, v45, v46// 0000004AEFA8: C94A592B 26285D2D
	s_waitcnt lgkmcnt(3)                                       // 0000004AEFB0: BF89FC37
	v_add_f32_e32 v42, v47, v48                                // 0000004AEFB4: 0654612F
	s_waitcnt lgkmcnt(1)                                       // 0000004AEFB8: BF89FC17
	v_dual_sub_f32 v43, v47, v48 :: v_dual_add_f32 v44, v49, v50// 0000004AEFBC: C948612F 2B2C6531
	v_dual_sub_f32 v45, v49, v50 :: v_dual_add_f32 v46, v22, v25// 0000004AEFC4: C9486531 2D2E3316
	v_dual_sub_f32 v22, v22, v25 :: v_dual_add_f32 v25, v24, v26// 0000004AEFCC: C9483316 16183518
	v_sub_f32_e32 v24, v24, v26                                // 0000004AEFD4: 08303518
	v_add_f32_e32 v26, v27, v40                                // 0000004AEFD8: 0634511B
	v_dual_sub_f32 v27, v27, v40 :: v_dual_add_f32 v40, v38, v41// 0000004AEFDC: C948511B 1B285326
	v_sub_f32_e32 v38, v38, v41                                // 0000004AEFE4: 084C5326
	v_add_f32_e32 v41, v42, v44                                // 0000004AEFE8: 0652592A
	v_sub_f32_e32 v42, v42, v44                                // 0000004AEFEC: 0854592A
	v_add_f32_e32 v44, v43, v45                                // 0000004AEFF0: 06585B2B
	v_sub_f32_e32 v43, v43, v45                                // 0000004AEFF4: 08565B2B
	v_mul_f32_e32 v45, 0x3db504f3, v46                         // 0000004AEFF8: 105A5CFF 3DB504F3
	v_dual_mul_f32 v25, 0x3db504f3, v25 :: v_dual_mul_f32 v22, 0x3db504f3, v22// 0000004AF000: C8C632FF 19162CFF 3DB504F3
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 0000004AF00C: 103030FF 3DB504F3
	v_mul_f32_e32 v26, 0x3db504f3, v26                         // 0000004AF014: 103434FF 3DB504F3
	v_dual_mul_f32 v40, 0x3db504f3, v40 :: v_dual_mul_f32 v27, 0x3db504f3, v27// 0000004AF01C: C8C650FF 281A36FF 3DB504F3
	v_dual_mul_f32 v38, 0x3db504f3, v38 :: v_dual_mul_f32 v41, 0x3db504f3, v41// 0000004AF028: C8C64CFF 262852FF 3DB504F3
	v_mul_f32_e32 v44, 0x3db504f3, v44                         // 0000004AF034: 105858FF 3DB504F3
	v_dual_mul_f32 v42, 0x3db504f3, v42 :: v_dual_mul_f32 v43, 0x3db504f3, v43// 0000004AF03C: C8C654FF 2A2A56FF 3DB504F3
	v_mul_f32_e32 v45, s3, v45                                 // 0000004AF048: 105A5A03
	v_dual_mul_f32 v25, s7, v25 :: v_dual_mul_f32 v22, s8, v22 // 0000004AF04C: C8C63207 19162C08
	v_mul_f32_e32 v24, s9, v24                                 // 0000004AF054: 10303009
	v_mul_f32_e32 v26, s10, v26                                // 0000004AF058: 1034340A
	v_dual_mul_f32 v40, s11, v40 :: v_dual_mul_f32 v27, s12, v27// 0000004AF05C: C8C6500B 281A360C
	v_dual_mul_f32 v38, s13, v38 :: v_dual_mul_f32 v41, s14, v41// 0000004AF064: C8C64C0D 2628520E
	v_mul_f32_e32 v44, s15, v44                                // 0000004AF06C: 1058580F
	v_dual_mul_f32 v42, s16, v42 :: v_dual_mul_f32 v43, s17, v43// 0000004AF070: C8C65410 2A2A5611
	ds_store_b32 v28, v45                                      // 0000004AF078: D8340000 00002D1C
	ds_store_b32 v29, v25                                      // 0000004AF080: D8340000 0000191D
	ds_store_b32 v34, v22                                      // 0000004AF088: D8340000 00001622
	ds_store_b32 v30, v24                                      // 0000004AF090: D8340000 0000181E
	ds_store_b32 v33, v26                                      // 0000004AF098: D8340000 00001A21
	ds_store_b32 v31, v40                                      // 0000004AF0A0: D8340000 0000281F
	ds_store_b32 v32, v27                                      // 0000004AF0A8: D8340000 00001B20
	ds_store_b32 v35, v38                                      // 0000004AF0B0: D8340000 00002623
	ds_store_b32 v39, v41                                      // 0000004AF0B8: D8340000 00002927
	ds_store_b32 v36, v44                                      // 0000004AF0C0: D8340000 00002C24
	ds_store_b32 v37, v42                                      // 0000004AF0C8: D8340000 00002A25
	ds_store_b32 v23, v43                                      // 0000004AF0D0: D8340000 00002B17
	s_waitcnt lgkmcnt(0)                                       // 0000004AF0D8: BF89FC07
	s_barrier                                                  // 0000004AF0DC: BFBD0000
	buffer_gl0_inv                                             // 0000004AF0E0: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 0000004AF0E8: BE83206A
	s_cbranch_execz 415                                        // 0000004AF0EC: BFA5019F <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi4ELb1ELi8EEEvPKjiPKDF16_S5_Pti+0x336c>
	v_lshlrev_b32_e32 v18, 14, v18                             // 0000004AF0F0: 3024248E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004AF0F4: BF870001
	v_and_b32_e32 v18, 0xc000, v18                             // 0000004AF0F8: 362424FF 0000C000
	v_and_or_b32 v22, 0x60, v8, v17                            // 0000004AF100: D6570016 044610FF 00000060
	.long 0xd7000704                                           // 0000004AF10C: D7000704
	v_cndmask_b32_e32 v0, v4, v136, vcc_lo                     // 0000004AF110: 02011104
	s_xor_b32 s7, s7, -1                                       // 0000004AF114: 8D07C107
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004AF118: BF870009
	s_and_b32 s7, exec_lo, s7                                  // 0000004AF11C: 8B07077E
	v_xor_b32_e32 v24, 1, v22                                  // 0000004AF120: 3A302C81
	v_xor_b32_e32 v25, 2, v22                                  // 0000004AF124: 3A322C82
	v_xor_b32_e32 v26, 3, v22                                  // 0000004AF128: 3A342C83
	v_xor_b32_e32 v27, 4, v22                                  // 0000004AF12C: 3A362C84
	v_lshl_add_u32 v23, v22, 2, v18                            // 0000004AF130: D6460017 04490516
	v_xor_b32_e32 v28, 5, v22                                  // 0000004AF138: 3A382C85
	v_xor_b32_e32 v29, 6, v22                                  // 0000004AF13C: 3A3A2C86
	v_xor_b32_e32 v30, 7, v22                                  // 0000004AF140: 3A3C2C87
	v_xor_b32_e32 v31, 8, v22                                  // 0000004AF144: 3A3E2C88
	v_xor_b32_e32 v32, 9, v22                                  // 0000004AF148: 3A402C89
	v_xor_b32_e32 v33, 10, v22                                 // 0000004AF14C: 3A422C8A
	v_xor_b32_e32 v34, 11, v22                                 // 0000004AF150: 3A442C8B
	v_xor_b32_e32 v35, 12, v22                                 // 0000004AF154: 3A462C8C
	v_xor_b32_e32 v36, 13, v22                                 // 0000004AF158: 3A482C8D
	v_xor_b32_e32 v37, 14, v22                                 // 0000004AF15C: 3A4A2C8E
	v_xor_b32_e32 v38, 15, v22                                 // 0000004AF160: 3A4C2C8F
	v_xor_b32_e32 v39, 16, v22                                 // 0000004AF164: 3A4E2C90
	v_xor_b32_e32 v40, 17, v22                                 // 0000004AF168: 3A502C91
	v_xor_b32_e32 v41, 18, v22                                 // 0000004AF16C: 3A522C92
	v_xor_b32_e32 v42, 19, v22                                 // 0000004AF170: 3A542C93
	v_xor_b32_e32 v43, 20, v22                                 // 0000004AF174: 3A562C94
	v_xor_b32_e32 v44, 21, v22                                 // 0000004AF178: 3A582C95
	v_xor_b32_e32 v45, 22, v22                                 // 0000004AF17C: 3A5A2C96
	v_xor_b32_e32 v46, 23, v22                                 // 0000004AF180: 3A5C2C97
	v_xor_b32_e32 v47, 24, v22                                 // 0000004AF184: 3A5E2C98
	v_xor_b32_e32 v48, 25, v22                                 // 0000004AF188: 3A602C99
	v_xor_b32_e32 v49, 26, v22                                 // 0000004AF18C: 3A622C9A
	v_xor_b32_e32 v50, 27, v22                                 // 0000004AF190: 3A642C9B
	v_xor_b32_e32 v51, 28, v22                                 // 0000004AF194: 3A662C9C
	v_xor_b32_e32 v52, 29, v22                                 // 0000004AF198: 3A682C9D
	v_xor_b32_e32 v53, 30, v22                                 // 0000004AF19C: 3A6A2C9E
	v_xor_b32_e32 v22, 31, v22                                 // 0000004AF1A0: 3A2C2C9F
	v_lshl_add_u32 v24, v24, 2, v18                            // 0000004AF1A4: D6460018 04490518
	v_lshl_add_u32 v25, v25, 2, v18                            // 0000004AF1AC: D6460019 04490519
	v_lshl_add_u32 v26, v26, 2, v18                            // 0000004AF1B4: D646001A 0449051A
	v_lshl_add_u32 v27, v27, 2, v18                            // 0000004AF1BC: D646001B 0449051B
	v_lshl_add_u32 v28, v28, 2, v18                            // 0000004AF1C4: D646001C 0449051C
	v_lshl_add_u32 v29, v29, 2, v18                            // 0000004AF1CC: D646001D 0449051D
	v_lshl_add_u32 v30, v30, 2, v18                            // 0000004AF1D4: D646001E 0449051E
	v_lshl_add_u32 v31, v31, 2, v18                            // 0000004AF1DC: D646001F 0449051F
	v_lshl_add_u32 v32, v32, 2, v18                            // 0000004AF1E4: D6460020 04490520
	v_lshl_add_u32 v33, v33, 2, v18                            // 0000004AF1EC: D6460021 04490521
	v_lshl_add_u32 v34, v34, 2, v18                            // 0000004AF1F4: D6460022 04490522
	v_lshl_add_u32 v35, v35, 2, v18                            // 0000004AF1FC: D6460023 04490523
	v_lshl_add_u32 v36, v36, 2, v18                            // 0000004AF204: D6460024 04490524
	v_lshl_add_u32 v37, v37, 2, v18                            // 0000004AF20C: D6460025 04490525
	v_lshl_add_u32 v38, v38, 2, v18                            // 0000004AF214: D6460026 04490526
	v_lshl_add_u32 v39, v39, 2, v18                            // 0000004AF21C: D6460027 04490527
	v_lshl_add_u32 v40, v40, 2, v18                            // 0000004AF224: D6460028 04490528
	v_lshl_add_u32 v41, v41, 2, v18                            // 0000004AF22C: D6460029 04490529
	v_lshl_add_u32 v42, v42, 2, v18                            // 0000004AF234: D646002A 0449052A
	v_lshl_add_u32 v43, v43, 2, v18                            // 0000004AF23C: D646002B 0449052B
	v_lshl_add_u32 v44, v44, 2, v18                            // 0000004AF244: D646002C 0449052C
	v_lshl_add_u32 v45, v45, 2, v18                            // 0000004AF24C: D646002D 0449052D
	v_lshl_add_u32 v46, v46, 2, v18                            // 0000004AF254: D646002E 0449052E
	v_lshl_add_u32 v47, v47, 2, v18                            // 0000004AF25C: D646002F 0449052F
	v_lshl_add_u32 v48, v48, 2, v18                            // 0000004AF264: D6460030 04490530
	v_lshl_add_u32 v49, v49, 2, v18                            // 0000004AF26C: D6460031 04490531
	v_lshl_add_u32 v50, v50, 2, v18                            // 0000004AF274: D6460032 04490532
	v_lshl_add_u32 v51, v51, 2, v18                            // 0000004AF27C: D6460033 04490533
	v_lshl_add_u32 v52, v52, 2, v18                            // 0000004AF284: D6460034 04490534
	v_lshl_add_u32 v53, v53, 2, v18                            // 0000004AF28C: D6460035 04490535
	v_lshl_add_u32 v22, v22, 2, v18                            // 0000004AF294: D6460016 04490516
	ds_load_b32 v54, v23                                       // 0000004AF29C: D8D80000 36000017
	ds_load_b32 v55, v24 offset:512                            // 0000004AF2A4: D8D80200 37000018
	ds_load_b32 v56, v25 offset:1024                           // 0000004AF2AC: D8D80400 38000019
	ds_load_b32 v57, v26 offset:1536                           // 0000004AF2B4: D8D80600 3900001A
	ds_load_b32 v58, v27 offset:2048                           // 0000004AF2BC: D8D80800 3A00001B
	ds_load_b32 v59, v28 offset:2560                           // 0000004AF2C4: D8D80A00 3B00001C
	ds_load_b32 v60, v29 offset:3072                           // 0000004AF2CC: D8D80C00 3C00001D
	ds_load_b32 v61, v30 offset:3584                           // 0000004AF2D4: D8D80E00 3D00001E
	ds_load_b32 v62, v31 offset:4096                           // 0000004AF2DC: D8D81000 3E00001F
	ds_load_b32 v63, v32 offset:4608                           // 0000004AF2E4: D8D81200 3F000020
	ds_load_b32 v64, v33 offset:5120                           // 0000004AF2EC: D8D81400 40000021
	ds_load_b32 v65, v34 offset:5632                           // 0000004AF2F4: D8D81600 41000022
	ds_load_b32 v66, v35 offset:6144                           // 0000004AF2FC: D8D81800 42000023
	ds_load_b32 v67, v36 offset:6656                           // 0000004AF304: D8D81A00 43000024
	ds_load_b32 v68, v37 offset:7168                           // 0000004AF30C: D8D81C00 44000025
	ds_load_b32 v69, v38 offset:7680                           // 0000004AF314: D8D81E00 45000026
	ds_load_b32 v70, v39 offset:8192                           // 0000004AF31C: D8D82000 46000027
	ds_load_b32 v71, v40 offset:8704                           // 0000004AF324: D8D82200 47000028
	ds_load_b32 v72, v41 offset:9216                           // 0000004AF32C: D8D82400 48000029
	ds_load_b32 v73, v42 offset:9728                           // 0000004AF334: D8D82600 4900002A
	ds_load_b32 v74, v43 offset:10240                          // 0000004AF33C: D8D82800 4A00002B
	ds_load_b32 v75, v44 offset:10752                          // 0000004AF344: D8D82A00 4B00002C
	ds_load_b32 v76, v45 offset:11264                          // 0000004AF34C: D8D82C00 4C00002D
	ds_load_b32 v77, v46 offset:11776                          // 0000004AF354: D8D82E00 4D00002E
	ds_load_b32 v78, v47 offset:12288                          // 0000004AF35C: D8D83000 4E00002F
	ds_load_b32 v79, v48 offset:12800                          // 0000004AF364: D8D83200 4F000030
	ds_load_b32 v80, v49 offset:13312                          // 0000004AF36C: D8D83400 50000031
	ds_load_b32 v81, v50 offset:13824                          // 0000004AF374: D8D83600 51000032
	ds_load_b32 v82, v51 offset:14336                          // 0000004AF37C: D8D83800 52000033
	ds_load_b32 v83, v52 offset:14848                          // 0000004AF384: D8D83A00 53000034
	ds_load_b32 v84, v53 offset:15360                          // 0000004AF38C: D8D83C00 54000035
	ds_load_b32 v85, v22 offset:15872                          // 0000004AF394: D8D83E00 55000016
	v_add_nc_u32_e32 v8, 64, v8                                // 0000004AF39C: 4A1010C0
	s_waitcnt lgkmcnt(30)                                      // 0000004AF3A0: BF89FDE7
	v_add_f32_e32 v86, v54, v55                                // 0000004AF3A4: 06AC6F36
	s_waitcnt lgkmcnt(28)                                      // 0000004AF3A8: BF89FDC7
	v_dual_sub_f32 v54, v54, v55 :: v_dual_add_f32 v55, v56, v57// 0000004AF3AC: C9486F36 36367338
	s_waitcnt lgkmcnt(26)                                      // 0000004AF3B4: BF89FDA7
	v_dual_sub_f32 v56, v56, v57 :: v_dual_add_f32 v57, v58, v59// 0000004AF3B8: C9487338 3838773A
	s_waitcnt lgkmcnt(24)                                      // 0000004AF3C0: BF89FD87
	v_dual_sub_f32 v58, v58, v59 :: v_dual_add_f32 v59, v60, v61// 0000004AF3C4: C948773A 3A3A7B3C
	s_waitcnt lgkmcnt(22)                                      // 0000004AF3CC: BF89FD67
	v_dual_sub_f32 v60, v60, v61 :: v_dual_add_f32 v61, v62, v63// 0000004AF3D0: C9487B3C 3C3C7F3E
	s_waitcnt lgkmcnt(20)                                      // 0000004AF3D8: BF89FD47
	v_dual_sub_f32 v62, v62, v63 :: v_dual_add_f32 v63, v64, v65// 0000004AF3DC: C9487F3E 3E3E8340
	s_waitcnt lgkmcnt(18)                                      // 0000004AF3E4: BF89FD27
	v_dual_sub_f32 v64, v64, v65 :: v_dual_add_f32 v65, v66, v67// 0000004AF3E8: C9488340 40408742
	s_waitcnt lgkmcnt(16)                                      // 0000004AF3F0: BF89FD07
	v_dual_sub_f32 v66, v66, v67 :: v_dual_add_f32 v67, v68, v69// 0000004AF3F4: C9488742 42428B44
	s_waitcnt lgkmcnt(14)                                      // 0000004AF3FC: BF89FCE7
	v_dual_sub_f32 v68, v68, v69 :: v_dual_add_f32 v69, v70, v71// 0000004AF400: C9488B44 44448F46
	s_waitcnt lgkmcnt(12)                                      // 0000004AF408: BF89FCC7
	v_dual_sub_f32 v70, v70, v71 :: v_dual_add_f32 v71, v72, v73// 0000004AF40C: C9488F46 46469348
	s_waitcnt lgkmcnt(10)                                      // 0000004AF414: BF89FCA7
	v_dual_sub_f32 v72, v72, v73 :: v_dual_add_f32 v73, v74, v75// 0000004AF418: C9489348 4848974A
	s_waitcnt lgkmcnt(8)                                       // 0000004AF420: BF89FC87
	v_dual_sub_f32 v74, v74, v75 :: v_dual_add_f32 v75, v76, v77// 0000004AF424: C948974A 4A4A9B4C
	s_waitcnt lgkmcnt(6)                                       // 0000004AF42C: BF89FC67
	v_dual_sub_f32 v76, v76, v77 :: v_dual_add_f32 v77, v78, v79// 0000004AF430: C9489B4C 4C4C9F4E
	s_waitcnt lgkmcnt(4)                                       // 0000004AF438: BF89FC47
	v_dual_sub_f32 v78, v78, v79 :: v_dual_add_f32 v79, v80, v81// 0000004AF43C: C9489F4E 4E4EA350
	s_waitcnt lgkmcnt(2)                                       // 0000004AF444: BF89FC27
	v_dual_sub_f32 v80, v80, v81 :: v_dual_add_f32 v81, v82, v83// 0000004AF448: C948A350 5050A752
	s_waitcnt lgkmcnt(0)                                       // 0000004AF450: BF89FC07
	v_dual_sub_f32 v82, v82, v83 :: v_dual_add_f32 v83, v84, v85// 0000004AF454: C948A752 5252AB54
	v_dual_sub_f32 v84, v84, v85 :: v_dual_add_f32 v85, v86, v55// 0000004AF45C: C948AB54 54546F56
	v_sub_f32_e32 v55, v86, v55                                // 0000004AF464: 086E6F56
	v_add_f32_e32 v86, v54, v56                                // 0000004AF468: 06AC7136
	v_sub_f32_e32 v54, v54, v56                                // 0000004AF46C: 086C7136
	v_add_f32_e32 v56, v57, v59                                // 0000004AF470: 06707739
	v_sub_f32_e32 v57, v57, v59                                // 0000004AF474: 08727739
	v_add_f32_e32 v59, v58, v60                                // 0000004AF478: 0676793A
	v_sub_f32_e32 v58, v58, v60                                // 0000004AF47C: 0874793A
	v_add_f32_e32 v60, v61, v63                                // 0000004AF480: 06787F3D
	v_sub_f32_e32 v61, v61, v63                                // 0000004AF484: 087A7F3D
	v_add_f32_e32 v63, v62, v64                                // 0000004AF488: 067E813E
	v_sub_f32_e32 v62, v62, v64                                // 0000004AF48C: 087C813E
	v_add_f32_e32 v64, v65, v67                                // 0000004AF490: 06808741
	v_sub_f32_e32 v65, v65, v67                                // 0000004AF494: 08828741
	v_add_f32_e32 v67, v66, v68                                // 0000004AF498: 06868942
	v_sub_f32_e32 v66, v66, v68                                // 0000004AF49C: 08848942
	v_add_f32_e32 v68, v69, v71                                // 0000004AF4A0: 06888F45
	v_sub_f32_e32 v69, v69, v71                                // 0000004AF4A4: 088A8F45
	v_add_f32_e32 v71, v70, v72                                // 0000004AF4A8: 068E9146
	v_sub_f32_e32 v70, v70, v72                                // 0000004AF4AC: 088C9146
	v_add_f32_e32 v72, v73, v75                                // 0000004AF4B0: 06909749
	v_sub_f32_e32 v73, v73, v75                                // 0000004AF4B4: 08929749
	v_add_f32_e32 v75, v74, v76                                // 0000004AF4B8: 0696994A
	v_sub_f32_e32 v74, v74, v76                                // 0000004AF4BC: 0894994A
	v_add_f32_e32 v76, v77, v79                                // 0000004AF4C0: 06989F4D
	v_sub_f32_e32 v77, v77, v79                                // 0000004AF4C4: 089A9F4D
	v_add_f32_e32 v79, v78, v80                                // 0000004AF4C8: 069EA14E
	v_sub_f32_e32 v78, v78, v80                                // 0000004AF4CC: 089CA14E
	v_add_f32_e32 v80, v81, v83                                // 0000004AF4D0: 06A0A751
	v_sub_f32_e32 v81, v81, v83                                // 0000004AF4D4: 08A2A751
	v_add_f32_e32 v83, v82, v84                                // 0000004AF4D8: 06A6A952
	v_sub_f32_e32 v82, v82, v84                                // 0000004AF4DC: 08A4A952
	v_add_f32_e32 v84, v85, v56                                // 0000004AF4E0: 06A87155
	v_dual_sub_f32 v56, v85, v56 :: v_dual_add_f32 v85, v86, v59// 0000004AF4E4: C9487155 38547756
	v_dual_sub_f32 v59, v86, v59 :: v_dual_add_f32 v86, v55, v57// 0000004AF4EC: C9487756 3B567337
	v_sub_f32_e32 v55, v55, v57                                // 0000004AF4F4: 086E7337
	v_add_f32_e32 v57, v54, v58                                // 0000004AF4F8: 06727536
	v_sub_f32_e32 v54, v54, v58                                // 0000004AF4FC: 086C7536
	v_add_f32_e32 v58, v60, v64                                // 0000004AF500: 0674813C
	v_sub_f32_e32 v60, v60, v64                                // 0000004AF504: 0878813C
	v_add_f32_e32 v64, v63, v67                                // 0000004AF508: 0680873F
	v_sub_f32_e32 v63, v63, v67                                // 0000004AF50C: 087E873F
	v_add_f32_e32 v67, v61, v65                                // 0000004AF510: 0686833D
	v_sub_f32_e32 v61, v61, v65                                // 0000004AF514: 087A833D
	v_add_f32_e32 v65, v62, v66                                // 0000004AF518: 0682853E
	v_sub_f32_e32 v62, v62, v66                                // 0000004AF51C: 087C853E
	v_add_f32_e32 v66, v68, v72                                // 0000004AF520: 06849144
	v_sub_f32_e32 v68, v68, v72                                // 0000004AF524: 08889144
	v_add_f32_e32 v72, v71, v75                                // 0000004AF528: 06909747
	v_sub_f32_e32 v71, v71, v75                                // 0000004AF52C: 088E9747
	v_add_f32_e32 v75, v69, v73                                // 0000004AF530: 06969345
	v_sub_f32_e32 v69, v69, v73                                // 0000004AF534: 088A9345
	v_add_f32_e32 v73, v70, v74                                // 0000004AF538: 06929546
	v_sub_f32_e32 v70, v70, v74                                // 0000004AF53C: 088C9546
	v_add_f32_e32 v74, v76, v80                                // 0000004AF540: 0694A14C
	v_sub_f32_e32 v76, v76, v80                                // 0000004AF544: 0898A14C
	v_add_f32_e32 v80, v79, v83                                // 0000004AF548: 06A0A74F
	v_sub_f32_e32 v79, v79, v83                                // 0000004AF54C: 089EA74F
	v_add_f32_e32 v83, v77, v81                                // 0000004AF550: 06A6A34D
	v_sub_f32_e32 v77, v77, v81                                // 0000004AF554: 089AA34D
	v_add_f32_e32 v81, v78, v82                                // 0000004AF558: 06A2A54E
	v_sub_f32_e32 v78, v78, v82                                // 0000004AF55C: 089CA54E
	v_add_f32_e32 v82, v84, v58                                // 0000004AF560: 06A47554
	v_sub_f32_e32 v58, v84, v58                                // 0000004AF564: 08747554
	v_add_f32_e32 v84, v85, v64                                // 0000004AF568: 06A88155
	v_dual_sub_f32 v64, v85, v64 :: v_dual_add_f32 v85, v86, v67// 0000004AF56C: C9488155 40548756
	v_dual_sub_f32 v67, v86, v67 :: v_dual_add_f32 v86, v57, v65// 0000004AF574: C9488756 43568339
	v_sub_f32_e32 v57, v57, v65                                // 0000004AF57C: 08728339
	v_add_f32_e32 v65, v56, v60                                // 0000004AF580: 06827938
	v_sub_f32_e32 v56, v56, v60                                // 0000004AF584: 08707938
	v_add_f32_e32 v60, v59, v63                                // 0000004AF588: 06787F3B
	v_sub_f32_e32 v59, v59, v63                                // 0000004AF58C: 08767F3B
	v_add_f32_e32 v63, v55, v61                                // 0000004AF590: 067E7B37
	v_sub_f32_e32 v55, v55, v61                                // 0000004AF594: 086E7B37
	v_add_f32_e32 v61, v54, v62                                // 0000004AF598: 067A7D36
	v_sub_f32_e32 v54, v54, v62                                // 0000004AF59C: 086C7D36
	v_add_f32_e32 v62, v66, v74                                // 0000004AF5A0: 067C9542
	v_sub_f32_e32 v66, v66, v74                                // 0000004AF5A4: 08849542
	v_add_f32_e32 v74, v72, v80                                // 0000004AF5A8: 0694A148
	v_sub_f32_e32 v72, v72, v80                                // 0000004AF5AC: 0890A148
	v_add_f32_e32 v80, v75, v83                                // 0000004AF5B0: 06A0A74B
	v_sub_f32_e32 v75, v75, v83                                // 0000004AF5B4: 0896A74B
	v_add_f32_e32 v83, v73, v81                                // 0000004AF5B8: 06A6A349
	v_sub_f32_e32 v73, v73, v81                                // 0000004AF5BC: 0892A349
	v_add_f32_e32 v81, v68, v76                                // 0000004AF5C0: 06A29944
	v_sub_f32_e32 v68, v68, v76                                // 0000004AF5C4: 08889944
	v_add_f32_e32 v76, v71, v79                                // 0000004AF5C8: 06989F47
	v_sub_f32_e32 v71, v71, v79                                // 0000004AF5CC: 088E9F47
	v_add_f32_e32 v79, v69, v77                                // 0000004AF5D0: 069E9B45
	v_sub_f32_e32 v69, v69, v77                                // 0000004AF5D4: 088A9B45
	v_add_f32_e32 v77, v70, v78                                // 0000004AF5D8: 069A9D46
	v_sub_f32_e32 v70, v70, v78                                // 0000004AF5DC: 088C9D46
	v_add_f32_e32 v78, v82, v62                                // 0000004AF5E0: 069C7D52
	v_sub_f32_e32 v62, v82, v62                                // 0000004AF5E4: 087C7D52
	v_add_f32_e32 v82, v84, v74                                // 0000004AF5E8: 06A49554
	v_sub_f32_e32 v74, v84, v74                                // 0000004AF5EC: 08949554
	v_add_f32_e32 v84, v85, v80                                // 0000004AF5F0: 06A8A155
	s_or_b32 s0, s7, s0                                        // 0000004AF5F4: 8C000007
	v_dual_sub_f32 v80, v85, v80 :: v_dual_add_f32 v85, v86, v83// 0000004AF5F8: C948A155 5054A756
	v_dual_sub_f32 v83, v86, v83 :: v_dual_add_f32 v86, v65, v81// 0000004AF600: C948A756 5356A341
	v_sub_f32_e32 v65, v65, v81                                // 0000004AF608: 0882A341
	v_add_f32_e32 v81, v60, v76                                // 0000004AF60C: 06A2993C
	v_sub_f32_e32 v60, v60, v76                                // 0000004AF610: 0878993C
	v_add_f32_e32 v76, v63, v79                                // 0000004AF614: 06989F3F
	v_sub_f32_e32 v63, v63, v79                                // 0000004AF618: 087E9F3F
	v_add_f32_e32 v79, v61, v77                                // 0000004AF61C: 069E9B3D
	v_sub_f32_e32 v61, v61, v77                                // 0000004AF620: 087A9B3D
	v_add_f32_e32 v77, v58, v66                                // 0000004AF624: 069A853A
	v_sub_f32_e32 v58, v58, v66                                // 0000004AF628: 0874853A
	v_add_f32_e32 v66, v64, v72                                // 0000004AF62C: 06849140
	v_sub_f32_e32 v64, v64, v72                                // 0000004AF630: 08809140
	v_add_f32_e32 v72, v67, v75                                // 0000004AF634: 06909743
	v_sub_f32_e32 v67, v67, v75                                // 0000004AF638: 08869743
	v_add_f32_e32 v75, v57, v73                                // 0000004AF63C: 06969339
	v_sub_f32_e32 v57, v57, v73                                // 0000004AF640: 08729339
	v_add_f32_e32 v73, v56, v68                                // 0000004AF644: 06928938
	v_sub_f32_e32 v56, v56, v68                                // 0000004AF648: 08708938
	v_add_f32_e32 v68, v59, v71                                // 0000004AF64C: 06888F3B
	v_sub_f32_e32 v59, v59, v71                                // 0000004AF650: 08768F3B
	v_add_f32_e32 v71, v55, v69                                // 0000004AF654: 068E8B37
	v_sub_f32_e32 v55, v55, v69                                // 0000004AF658: 086E8B37
	v_add_f32_e32 v69, v54, v70                                // 0000004AF65C: 068A8D36
	v_sub_f32_e32 v54, v54, v70                                // 0000004AF660: 086C8D36
	ds_store_b32 v23, v78                                      // 0000004AF664: D8340000 00004E17
	ds_store_b32 v24, v82 offset:512                           // 0000004AF66C: D8340200 00005218
	ds_store_b32 v25, v84 offset:1024                          // 0000004AF674: D8340400 00005419
	ds_store_b32 v26, v85 offset:1536                          // 0000004AF67C: D8340600 0000551A
	ds_store_b32 v27, v86 offset:2048                          // 0000004AF684: D8340800 0000561B
	ds_store_b32 v28, v81 offset:2560                          // 0000004AF68C: D8340A00 0000511C
	ds_store_b32 v29, v76 offset:3072                          // 0000004AF694: D8340C00 00004C1D
	ds_store_b32 v30, v79 offset:3584                          // 0000004AF69C: D8340E00 00004F1E
	ds_store_b32 v31, v77 offset:4096                          // 0000004AF6A4: D8341000 00004D1F
	ds_store_b32 v32, v66 offset:4608                          // 0000004AF6AC: D8341200 00004220
	ds_store_b32 v33, v72 offset:5120                          // 0000004AF6B4: D8341400 00004821
	ds_store_b32 v34, v75 offset:5632                          // 0000004AF6BC: D8341600 00004B22
	ds_store_b32 v35, v73 offset:6144                          // 0000004AF6C4: D8341800 00004923
	ds_store_b32 v36, v68 offset:6656                          // 0000004AF6CC: D8341A00 00004424
	ds_store_b32 v37, v71 offset:7168                          // 0000004AF6D4: D8341C00 00004725
	ds_store_b32 v38, v69 offset:7680                          // 0000004AF6DC: D8341E00 00004526
	ds_store_b32 v39, v62 offset:8192                          // 0000004AF6E4: D8342000 00003E27
	ds_store_b32 v40, v74 offset:8704                          // 0000004AF6EC: D8342200 00004A28
	ds_store_b32 v41, v80 offset:9216                          // 0000004AF6F4: D8342400 00005029
	ds_store_b32 v42, v83 offset:9728                          // 0000004AF6FC: D8342600 0000532A
	ds_store_b32 v43, v65 offset:10240                         // 0000004AF704: D8342800 0000412B
	ds_store_b32 v44, v60 offset:10752                         // 0000004AF70C: D8342A00 00003C2C
	ds_store_b32 v45, v63 offset:11264                         // 0000004AF714: D8342C00 00003F2D
	ds_store_b32 v46, v61 offset:11776                         // 0000004AF71C: D8342E00 00003D2E
	ds_store_b32 v47, v58 offset:12288                         // 0000004AF724: D8343000 00003A2F
	ds_store_b32 v48, v64 offset:12800                         // 0000004AF72C: D8343200 00004030
	ds_store_b32 v49, v67 offset:13312                         // 0000004AF734: D8343400 00004331
	ds_store_b32 v50, v57 offset:13824                         // 0000004AF73C: D8343600 00003932
	ds_store_b32 v51, v56 offset:14336                         // 0000004AF744: D8343800 00003833
	ds_store_b32 v52, v59 offset:14848                         // 0000004AF74C: D8343A00 00003B34
	ds_store_b32 v53, v55 offset:15360                         // 0000004AF754: D8343C00 00003735
	ds_store_b32 v22, v54 offset:15872                         // 0000004AF75C: D8343E00 00003616
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 0000004AF764: 917E007E
	s_cbranch_execnz 65125                                     // 0000004AF768: BFA6FE65 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi4ELb1ELi8EEEvPKjiPKDF16_S5_Pti+0x2d00>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000004AF76C: 8C7E037E
	v_xor_b32_e32 v8, v16, v3                                  // 0000004AF770: 3A100710
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v17, 9, v16     // 0000004AF774: CA220080 04102089
	s_waitcnt lgkmcnt(0)                                       // 0000004AF77C: BF89FC07
	s_barrier                                                  // 0000004AF780: BFBD0000
	buffer_gl0_inv                                             // 0000004AF784: E0AC0000 00000000
	v_lshl_add_u32 v8, v8, 2, v17                              // 0000004AF78C: D6460008 04450508
	s_ashr_i32 s3, s2, 31                                      // 0000004AF794: 86039F02
	.long 0xd73c0011                                           // 0000004AF798: D73C0011
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000004AF79C: 02020681
	s_lshl_b64 s[2:3], s[2:3], 1                               // 0000004AF7A0: 84828102
	ds_load_2addr_stride64_b32 v[22:23], v8 offset1:64         // 0000004AF7A4: D8E04000 16000008
	ds_load_2addr_stride64_b32 v[24:25], v8 offset0:128 offset1:192// 0000004AF7AC: D8E0C080 18000008
	v_or_b32_e32 v32, s1, v16                                  // 0000004AF7B4: 38402001
	s_add_u32 s0, s4, s2                                       // 0000004AF7B8: 80000204
	s_addc_u32 s2, s5, s3                                      // 0000004AF7BC: 82020305
	.long 0xd7006a04                                           // 0000004AF7C0: D7006A04
	v_cndmask_b32_e32 v1, s0, v17, vcc_lo                      // 0000004AF7C4: 02022200
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004AF7C8: BF870001
	v_add_co_ci_u32_e64 v8, null, s2, v18, vcc_lo              // 0000004AF7CC: D5207C08 01AA2402
	v_or_b32_e32 v18, 32, v32                                  // 0000004AF7D4: 382440A0
	v_mad_i64_i32 v[26:27], null, v32, s6, 0                   // 0000004AF7D8: D6FF7C1A 02000D20
	v_or_b32_e32 v30, 64, v32                                  // 0000004AF7E0: 383C40C0
	v_cvt_f32_f16_e32 v16, v129/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004AF7E4: 7E201781
	v_cvt_f32_f16_e32 v17, v1                                  // 0000004AF7E8: 7E221701
	v_mad_i64_i32 v[28:29], null, v18, s6, 0                   // 0000004AF7EC: D6FF7C1C 02000D12
	v_lshlrev_b32_e32 v36, 9, v21                              // 0000004AF7F4: 30482A89
	v_mad_i64_i32 v[30:31], null, v30, s6, 0                   // 0000004AF7F8: D6FF7C1E 02000D1E
	.long 0xd7600000                                           // 0000004AF800: D7600000
	v_cndmask_b32_e32 v0, v16, v128, vcc_lo                    // 0000004AF804: 02010110
	.long 0xd73c001a                                           // 0000004AF808: D73C001A
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000004AF80C: 02023481
	.long 0xd7600002                                           // 0000004AF810: D7600002
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                    // 0000004AF814: 02010111
	s_waitcnt lgkmcnt(0)                                       // 0000004AF818: BF89FC07
	v_dual_sub_f32 v1, v22, v23 :: v_dual_sub_f32 v18, v24, v25// 0000004AF81C: C94A2F16 01123318
	.long 0xd73c001c                                           // 0000004AF824: D73C001C
	v_cndmask_b32_e32 v1, 1, v28, vcc_lo                       // 0000004AF828: 02023881
	v_dual_add_f32 v33, v22, v23 :: v_dual_add_f32 v34, v24, v25// 0000004AF82C: C9082F16 21223318
	.long 0xd7006a1a                                           // 0000004AF834: D7006A1A
	v_cndmask_b32_e32 v1, v4, v26, vcc_lo                      // 0000004AF838: 02023504
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004AF83C: BF870004
	v_add_f32_e32 v24, v1, v18                                 // 0000004AF840: 06302501
	v_add_co_ci_u32_e64 v27, null, v8, v27, vcc_lo             // 0000004AF844: D5207C1B 01AA3708
	.long 0xd7006a16                                           // 0000004AF84C: D7006A16
	v_cndmask_b32_e32 v1, v4, v28, vcc_lo                      // 0000004AF850: 02023904
	.long 0xd73c001e                                           // 0000004AF854: D73C001E
	v_cndmask_b32_e32 v1, 1, v30, vcc_lo                       // 0000004AF858: 02023C81
	v_add_co_ci_u32_e64 v23, null, v8, v29, vcc_lo             // 0000004AF85C: D5207C17 01AA3B08
	v_dual_add_f32 v28, v33, v34 :: v_dual_mul_f32 v29, 0x3db504f3, v24// 0000004AF864: C9064521 1C1C30FF 3DB504F3
	.long 0xd7600003                                           // 0000004AF870: D7600003
	v_cndmask_b32_e32 v0, v16, v144, vcc_lo                    // 0000004AF874: 02012110
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004AF878: BF870194
	.long 0xd7006a18                                           // 0000004AF87C: D7006A18
	v_cndmask_b32_e32 v1, v4, v30, vcc_lo                      // 0000004AF880: 02023D04
	v_mul_f32_e32 v28, 0x3db504f3, v28                         // 0000004AF884: 103838FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004AF88C: BF870004
	v_mul_f32_e32 v30, s2, v29                                 // 0000004AF890: 103C3A02
	v_sub_f32_e32 v18, v1, v18                                 // 0000004AF894: 08242501
	v_sub_f32_e32 v29, v33, v34                                // 0000004AF898: 083A4521
	.long 0x7f023880                                           // 0000004AF89C: 7F023880
	v_add_co_ci_u32_e64 v25, null, v8, v31, vcc_lo             // 0000004AF8A0: D5207C19 01AA3F08
	.long 0xd7600004                                           // 0000004AF8A8: D7600004
	v_cndmask_b32_e32 v0, v17, v144, vcc_lo                    // 0000004AF8AC: 02012111
	v_or_b32_e32 v40, s1, v21                                  // 0000004AF8B0: 38502A01
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004AF8B4: BF870004
	.long 0x7f4a3981                                           // 0000004AF8B8: 7F4A3981
	v_mul_f32_e32 v34, s0, v28                                 // 0000004AF8BC: 10443800
	v_mul_f32_e32 v28, 0x3db504f3, v29                         // 0000004AF8C0: 10383AFF 3DB504F3
	.long 0x7f3e3981                                           // 0000004AF8C8: 7F3E3981
	.long 0xd7600002                                           // 0000004AF8CC: D7600002
	v_cndmask_b32_e32 v0, v17, v129, vcc_lo                    // 0000004AF8D0: 02010311
	.long 0xd7600000                                           // 0000004AF8D4: D7600000
	v_cndmask_b32_e32 v0, v16, v129, vcc_lo                    // 0000004AF8D8: 02010310
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004AF8DC: BF870004
	v_mul_f32_e32 v35, s3, v28                                 // 0000004AF8E0: 10463803
	.long 0x7e02399e                                           // 0000004AF8E4: 7E02399E
	v_or_b32_e32 v28, 0x60, v32                                // 0000004AF8E8: 383840FF 00000060
	v_xor_b32_e32 v32, v21, v3                                 // 0000004AF8F0: 3A400715
	.long 0xd7600003                                           // 0000004AF8F4: D7600003
	v_cndmask_b32_e32 v0, v16, v145, vcc_lo                    // 0000004AF8F8: 02012310
	.long 0x7e4a39a3                                           // 0000004AF8FC: 7E4A39A3
	v_and_b32_e32 v33, 1, v1                                   // 0000004AF900: 36420281
	v_mad_i64_i32 v[28:29], null, v28, s6, 0                   // 0000004AF904: D6FF7C1C 02000D1C
	v_lshl_add_u32 v32, v32, 2, v36                            // 0000004AF90C: D6460020 04910520
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000004AF914: BF8701C4
	v_and_b32_e32 v37, 1, v37                                  // 0000004AF918: 364A4A81
	.long 0x7e3e39a2                                           // 0000004AF91C: 7E3E39A2
	v_add3_u32 v38, v30, v33, 0x7fff                           // 0000004AF920: D6550026 03FE431E 00007FFF
	.long 0xd73c001c                                           // 0000004AF92C: D73C001C
	v_cndmask_b32_e32 v1, 1, v28, vcc_lo                       // 0000004AF930: 02023881
	v_and_b32_e32 v36, 1, v31                                  // 0000004AF934: 36483E81
	ds_load_2addr_stride64_b32 v[30:31], v32 offset1:64        // 0000004AF938: D8E04000 1E000020
	ds_load_2addr_stride64_b32 v[32:33], v32 offset0:128 offset1:192// 0000004AF940: D8E0C080 20000020
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 0000004AF948: 102424FF 3DB504F3
	v_add3_u32 v21, v34, v36, 0x7fff                           // 0000004AF950: D6550015 03FE4922 00007FFF
	s_clause 0x1                                               // 0000004AF95C: BF850001
	global_store_d16_hi_b16 v[26:27], v21, off                 // 0000004AF960: DC960000 007C151A
	global_store_d16_hi_b16 v[22:23], v38, off                 // 0000004AF968: DC960000 007C2616
	.long 0xd7006a1c                                           // 0000004AF970: D7006A1C
	v_cndmask_b32_e32 v1, v4, v28, vcc_lo                      // 0000004AF974: 02023904
	v_add3_u32 v36, v35, v37, 0x7fff                           // 0000004AF978: D6550024 03FE4B23 00007FFF
	v_add_co_ci_u32_e64 v29, null, v8, v29, vcc_lo             // 0000004AF984: D5207C1D 01AA3B08
	v_or_b32_e32 v23, 32, v40                                  // 0000004AF98C: 382E50A0
	v_mad_i64_i32 v[34:35], null, v40, s6, 0                   // 0000004AF990: D6FF7C22 02000D28
	s_waitcnt lgkmcnt(1)                                       // 0000004AF998: BF89FC17
	v_dual_add_f32 v27, v30, v31 :: v_dual_mul_f32 v18, s4, v18// 0000004AF99C: C9063F1E 1B122404
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004AF9A4: BF870112
	.long 0xd73c0015                                           // 0000004AF9A8: D73C0015
	v_cndmask_b32_e32 v1, 1, v34, vcc_lo                       // 0000004AF9AC: 02024481
	.long 0x7e023992                                           // 0000004AF9B0: 7E023992
	v_lshlrev_b32_e32 v34, 9, v20                              // 0000004AF9B4: 30442889
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AF9B8: BF870212
	v_and_b32_e32 v39, 1, v1                                   // 0000004AF9BC: 364E0281
	.long 0xd7006a15                                           // 0000004AF9C0: D7006A15
	v_cndmask_b32_e32 v1, v4, v21, vcc_lo                      // 0000004AF9C4: 02022B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004AF9C8: BF870191
	v_add_co_ci_u32_e64 v22, null, v8, v22, vcc_lo             // 0000004AF9CC: D5207C16 01AA2D08
	v_add3_u32 v18, v18, v39, 0x7fff                           // 0000004AF9D4: D6550012 03FE4F12 00007FFF
	s_clause 0x1                                               // 0000004AF9E0: BF850001
	global_store_d16_hi_b16 v[24:25], v36, off                 // 0000004AF9E4: DC960000 007C2418
	global_store_d16_hi_b16 v[28:29], v18, off                 // 0000004AF9EC: DC960000 007C121C
	v_sub_f32_e32 v18, v30, v31                                // 0000004AF9F4: 08243F1E
	s_waitcnt lgkmcnt(0)                                       // 0000004AF9F8: BF89FC07
	v_sub_f32_e32 v28, v32, v33                                // 0000004AF9FC: 08384320
	v_add_f32_e32 v29, v32, v33                                // 0000004AFA00: 063A4320
	v_mad_i64_i32 v[23:24], null, v23, s6, 0                   // 0000004AFA04: D6FF7C17 02000D17
	v_or_b32_e32 v30, 64, v40                                  // 0000004AFA0C: 383C50C0
	v_xor_b32_e32 v33, v20, v3                                 // 0000004AFA10: 3A420714
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004AFA14: BF870124
	v_dual_add_f32 v25, v18, v28 :: v_dual_add_f32 v26, v27, v29// 0000004AFA18: C9083912 191A3B1B
	v_sub_f32_e32 v27, v27, v29                                // 0000004AFA20: 08363B1B
	v_dual_mul_f32 v25, 0x3db504f3, v25 :: v_dual_mul_f32 v26, 0x3db504f3, v26// 0000004AFA24: C8C632FF 191A34FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004AFA30: BF8701A2
	v_mul_f32_e32 v27, 0x3db504f3, v27                         // 0000004AFA34: 103636FF 3DB504F3
	.long 0xd73c0017                                           // 0000004AFA3C: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000004AFA40: 02022E81
	v_dual_mul_f32 v31, s2, v25 :: v_dual_sub_f32 v18, v18, v28// 0000004AFA44: C8CA3202 1F123912
	.long 0x7f383981                                           // 0000004AFA4C: 7F383981
	.long 0xd7600002                                           // 0000004AFA50: D7600002
	v_cndmask_b32_e32 v0, v17, v130, vcc_lo                    // 0000004AFA54: 02010511
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AFA58: BF870214
	.long 0xd7006a17                                           // 0000004AFA5C: D7006A17
	v_cndmask_b32_e32 v1, v4, v23, vcc_lo                      // 0000004AFA60: 02022F04
	.long 0x7e02399f                                           // 0000004AFA64: 7E02399F
	v_mul_f32_e32 v32, s0, v26                                 // 0000004AFA68: 10403400
	v_mad_i64_i32 v[25:26], null, v30, s6, 0                   // 0000004AFA6C: D6FF7C19 02000D1E
	v_mul_f32_e32 v30, s3, v27                                 // 0000004AFA74: 103C3603
	v_or_b32_e32 v27, 0x60, v40                                // 0000004AFA78: 383650FF 00000060
	v_and_b32_e32 v29, 1, v1                                   // 0000004AFA80: 363A0281
	.long 0x7e3839a0                                           // 0000004AFA84: 7E3839A0
	v_add_co_ci_u32_e64 v24, null, v8, v24, vcc_lo             // 0000004AFA88: D5207C18 01AA3108
	.long 0xd7600000                                           // 0000004AFA90: D7600000
	v_cndmask_b32_e32 v0, v17, v145, vcc_lo                    // 0000004AFA94: 02012311
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AFA98: BF870214
	v_add3_u32 v29, v31, v29, 0x7fff                           // 0000004AFA9C: D655001D 03FE3B1F 00007FFF
	v_and_b32_e32 v28, 1, v28                                  // 0000004AFAA8: 36383881
	.long 0xd73c0019                                           // 0000004AFAAC: D73C0019
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 0000004AFAB0: 02023281
	.long 0xd7600003                                           // 0000004AFAB4: D7600003
	v_cndmask_b32_e32 v0, v16, v146, vcc_lo                    // 0000004AFAB8: 02012510
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004AFABC: BF870003
	v_add3_u32 v31, v32, v28, 0x7fff                           // 0000004AFAC0: D655001F 03FE3920 00007FFF
	v_mad_i64_i32 v[27:28], null, v27, s6, 0                   // 0000004AFACC: D6FF7C1B 02000D1B
	s_clause 0x1                                               // 0000004AFAD4: BF850001
	global_store_d16_hi_b16 v[21:22], v31, off                 // 0000004AFAD8: DC960000 007C1F15
	global_store_d16_hi_b16 v[23:24], v29, off                 // 0000004AFAE0: DC960000 007C1D17
	v_lshl_add_u32 v24, v33, 2, v34                            // 0000004AFAE8: D6460018 04890521
	.long 0x7e40399e                                           // 0000004AFAF0: 7E40399E
	.long 0x7f403981                                           // 0000004AFAF4: 7F403981
	v_or_b32_e32 v31, s1, v20                                  // 0000004AFAF8: 383E2801
	.long 0xd73c0014                                           // 0000004AFAFC: D73C0014
	v_cndmask_b32_e32 v1, 1, v27, vcc_lo                       // 0000004AFB00: 02023681
	ds_load_2addr_stride64_b32 v[27:28], v24 offset0:128 offset1:192// 0000004AFB04: D8E0C080 1B000018
	.long 0xd7006a19                                           // 0000004AFB0C: D7006A19
	v_cndmask_b32_e32 v1, v4, v25, vcc_lo                      // 0000004AFB10: 02023304
	v_and_b32_e32 v29, 1, v32                                  // 0000004AFB14: 363A4081
	v_add_co_ci_u32_e64 v26, null, v8, v26, vcc_lo             // 0000004AFB18: D5207C1A 01AA3508
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 0000004AFB20: 102424FF 3DB504F3
	ds_load_2addr_stride64_b32 v[22:23], v24 offset1:64        // 0000004AFB28: D8E04000 16000018
	v_add3_u32 v32, v30, v29, 0x7fff                           // 0000004AFB30: D6550020 03FE3B1E 00007FFF
	v_mad_i64_i32 v[29:30], null, v31, s6, 0                   // 0000004AFB3C: D6FF7C1D 02000D1F
	.long 0xd7006a14                                           // 0000004AFB44: D7006A14
	v_cndmask_b32_e32 v1, v4, v20, vcc_lo                      // 0000004AFB48: 02022904
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004AFB4C: BF870001
	v_add_co_ci_u32_e64 v21, null, v8, v21, vcc_lo             // 0000004AFB50: D5207C15 01AA2B08
	global_store_d16_hi_b16 v[25:26], v32, off                 // 0000004AFB58: DC960000 007C2019
	v_or_b32_e32 v32, 64, v31                                  // 0000004AFB60: 38403EC0
	v_or_b32_e32 v26, 32, v31                                  // 0000004AFB64: 38343EA0
	.long 0xd73c0018                                           // 0000004AFB68: D73C0018
	v_cndmask_b32_e32 v1, 1, v29, vcc_lo                       // 0000004AFB6C: 02023A81
	v_lshlrev_b32_e32 v34, 9, v15                              // 0000004AFB70: 30441E89
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004AFB74: BF870004
	v_mad_i64_i32 v[29:30], null, v32, s6, 0                   // 0000004AFB78: D6FF7C1D 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000004AFB80: BF89FC17
	v_sub_f32_e32 v32, v27, v28                                // 0000004AFB84: 0840391B
	v_dual_add_f32 v27, v27, v28 :: v_dual_mul_f32 v18, s0, v18// 0000004AFB88: C906391B 1B122400
	.long 0xd7600000                                           // 0000004AFB90: D7600000
	v_cndmask_b32_e32 v0, v16, v130, vcc_lo                    // 0000004AFB94: 02010510
	.long 0xd7006a18                                           // 0000004AFB98: D7006A18
	v_cndmask_b32_e32 v1, v4, v24, vcc_lo                      // 0000004AFB9C: 02023104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AFBA0: BF870211
	v_add_co_ci_u32_e64 v25, null, v8, v25, vcc_lo             // 0000004AFBA4: D5207C19 01AA3308
	.long 0x7e023992                                           // 0000004AFBAC: 7E023992
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004AFBB0: BF870091
	v_and_b32_e32 v35, 1, v1                                   // 0000004AFBB4: 36460281
	v_add3_u32 v18, v18, v35, 0x7fff                           // 0000004AFBB8: D6550012 03FE4712 00007FFF
	.long 0x7f463981                                           // 0000004AFBC4: 7F463981
	global_store_d16_hi_b16 v[20:21], v18, off                 // 0000004AFBC8: DC960000 007C1214
	v_mad_i64_i32 v[20:21], null, v26, s6, 0                   // 0000004AFBD0: D6FF7C14 02000D1A
	s_waitcnt lgkmcnt(0)                                       // 0000004AFBD8: BF89FC07
	v_add_f32_e32 v26, v22, v23                                // 0000004AFBDC: 06342F16
	v_sub_f32_e32 v18, v22, v23                                // 0000004AFBE0: 08242F16
	.long 0xd73c0016                                           // 0000004AFBE4: D73C0016
	v_cndmask_b32_e32 v1, 1, v29, vcc_lo                       // 0000004AFBE8: 02023A81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004AFBEC: BF870223
	v_add_f32_e32 v29, v26, v27                                // 0000004AFBF0: 063A371A
	v_sub_f32_e32 v26, v26, v27                                // 0000004AFBF4: 0834371A
	v_add_f32_e32 v28, v18, v32                                // 0000004AFBF8: 06384112
	v_sub_f32_e32 v18, v18, v32                                // 0000004AFBFC: 08244112
	.long 0xd73c0014                                           // 0000004AFC00: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000004AFC04: 02022881
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004AFC08: BF870194
	v_dual_mul_f32 v29, 0x3db504f3, v29 :: v_dual_mul_f32 v26, 0x3db504f3, v26// 0000004AFC0C: C8C63AFF 1D1A34FF 3DB504F3
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 0000004AFC18: 102424FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004AFC20: BF870002
	v_dual_mul_f32 v32, s0, v29 :: v_dual_mul_f32 v33, s3, v26 // 0000004AFC24: C8C63A00 20203403
	.long 0xd7600003                                           // 0000004AFC2C: D7600003
	v_cndmask_b32_e32 v0, v16, v147, vcc_lo                    // 0000004AFC30: 02012710
	v_mul_f32_e32 v28, 0x3db504f3, v28                         // 0000004AFC34: 103838FF 3DB504F3
	v_or_b32_e32 v26, 0x60, v31                                // 0000004AFC3C: 38343EFF 00000060
	v_xor_b32_e32 v31, v15, v3                                 // 0000004AFC44: 3A3E070F
	.long 0x7e3a39a0                                           // 0000004AFC48: 7E3A39A0
	.long 0x7f3a3981                                           // 0000004AFC4C: 7F3A3981
	v_mul_f32_e32 v28, s2, v28                                 // 0000004AFC50: 10383802
	.long 0xd7600000                                           // 0000004AFC54: D7600000
	v_cndmask_b32_e32 v0, v17, v146, vcc_lo                    // 0000004AFC58: 02012511
	v_lshl_add_u32 v31, v31, 2, v34                            // 0000004AFC5C: D646001F 0489051F
	v_mad_i64_i32 v[26:27], null, v26, s6, 0                   // 0000004AFC64: D6FF7C1A 02000D1A
	v_and_b32_e32 v34, 1, v29                                  // 0000004AFC6C: 36443A81
	.long 0x7e02399c                                           // 0000004AFC70: 7E02399C
	v_mul_f32_e32 v18, s0, v18                                 // 0000004AFC74: 10242400
	.long 0x7e4639a1                                           // 0000004AFC78: 7E4639A1
	.long 0xd7006a14                                           // 0000004AFC7C: D7006A14
	v_cndmask_b32_e32 v1, v4, v20, vcc_lo                      // 0000004AFC80: 02022904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AFC84: BF870214
	v_and_b32_e32 v30, 1, v1                                   // 0000004AFC88: 363C0281
	.long 0x7e023992                                           // 0000004AFC8C: 7E023992
	.long 0xd73c001a                                           // 0000004AFC90: D73C001A
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000004AFC94: 02023481
	v_and_b32_e32 v35, 1, v35                                  // 0000004AFC98: 36464681
	v_add_co_ci_u32_e64 v21, null, v8, v21, vcc_lo             // 0000004AFC9C: D5207C15 01AA2B08
	v_add3_u32 v36, v28, v30, 0x7fff                           // 0000004AFCA4: D6550024 03FE3D1C 00007FFF
	ds_load_2addr_stride64_b32 v[28:29], v31 offset1:64        // 0000004AFCB0: D8E04000 1C00001F
	ds_load_2addr_stride64_b32 v[30:31], v31 offset0:128 offset1:192// 0000004AFCB8: D8E0C080 1E00001F
	v_and_b32_e32 v37, 1, v1                                   // 0000004AFCC0: 364A0281
	.long 0xd7006a16                                           // 0000004AFCC4: D7006A16
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 0000004AFCC8: 02022D04
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004AFCCC: BF870001
	v_add_co_ci_u32_e64 v23, null, v8, v23, vcc_lo             // 0000004AFCD0: D5207C17 01AA2F08
	.long 0xd7006a1a                                           // 0000004AFCD8: D7006A1A
	v_cndmask_b32_e32 v1, v4, v26, vcc_lo                      // 0000004AFCDC: 02023504
	v_or_b32_e32 v15, s1, v15                                  // 0000004AFCE0: 381E1E01
	v_add3_u32 v34, v32, v34, 0x7fff                           // 0000004AFCE4: D6550022 03FE4520 00007FFF
	v_add3_u32 v35, v33, v35, 0x7fff                           // 0000004AFCF0: D6550023 03FE4721 00007FFF
	v_add3_u32 v18, v18, v37, 0x7fff                           // 0000004AFCFC: D6550012 03FE4B12 00007FFF
	v_add_co_ci_u32_e64 v27, null, v8, v27, vcc_lo             // 0000004AFD08: D5207C1B 01AA3708
	s_clause 0x1                                               // 0000004AFD10: BF850001
	global_store_d16_hi_b16 v[24:25], v34, off                 // 0000004AFD14: DC960000 007C2218
	global_store_d16_hi_b16 v[20:21], v36, off                 // 0000004AFD1C: DC960000 007C2414
	v_or_b32_e32 v24, 32, v15                                  // 0000004AFD24: 38301EA0
	s_clause 0x1                                               // 0000004AFD28: BF850001
	global_store_d16_hi_b16 v[22:23], v35, off                 // 0000004AFD2C: DC960000 007C2316
	global_store_d16_hi_b16 v[26:27], v18, off                 // 0000004AFD34: DC960000 007C121A
	.long 0xd7600000                                           // 0000004AFD3C: D7600000
	v_cndmask_b32_e32 v0, v16, v131, vcc_lo                    // 0000004AFD40: 02010710
	.long 0xd7600002                                           // 0000004AFD44: D7600002
	v_cndmask_b32_e32 v0, v17, v131, vcc_lo                    // 0000004AFD48: 02010711
	s_waitcnt lgkmcnt(1)                                       // 0000004AFD4C: BF89FC17
	v_sub_f32_e32 v18, v28, v29                                // 0000004AFD50: 08243B1C
	s_waitcnt lgkmcnt(0)                                       // 0000004AFD54: BF89FC07
	v_dual_add_f32 v26, v28, v29 :: v_dual_sub_f32 v27, v30, v31// 0000004AFD58: C90A3B1C 1A1A3F1E
	v_add_f32_e32 v28, v30, v31                                // 0000004AFD60: 06383F1E
	v_mad_i64_i32 v[22:23], null, v24, s6, 0                   // 0000004AFD64: D6FF7C16 02000D18
	v_mad_i64_i32 v[32:33], null, v15, s6, 0                   // 0000004AFD6C: D6FF7C20 02000D0F
	v_or_b32_e32 v29, 64, v15                                  // 0000004AFD74: 383A1EC0
	v_add_f32_e32 v24, v18, v27                                // 0000004AFD78: 06303712
	v_add_f32_e32 v25, v26, v28                                // 0000004AFD7C: 0632391A
	v_sub_f32_e32 v26, v26, v28                                // 0000004AFD80: 0834391A
	v_sub_f32_e32 v18, v18, v27                                // 0000004AFD84: 08243712
	.long 0x7f363981                                           // 0000004AFD88: 7F363981
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AFD8C: BF870214
	v_dual_mul_f32 v24, 0x3db504f3, v24 :: v_dual_mul_f32 v25, 0x3db504f3, v25// 0000004AFD90: C8C630FF 181832FF 3DB504F3
	v_mul_f32_e32 v26, 0x3db504f3, v26                         // 0000004AFD9C: 103434FF 3DB504F3
	.long 0xd73c0014                                           // 0000004AFDA4: D73C0014
	v_cndmask_b32_e32 v1, 1, v32, vcc_lo                       // 0000004AFDA8: 02024081
	.long 0xd73c0016                                           // 0000004AFDAC: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000004AFDB0: 02022C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004AFDB4: BF870244
	v_dual_mul_f32 v30, s2, v24 :: v_dual_mul_f32 v31, s0, v25 // 0000004AFDB8: C8C63002 1E1E3200
	v_mad_i64_i32 v[24:25], null, v29, s6, 0                   // 0000004AFDC0: D6FF7C18 02000D1D
	v_mul_f32_e32 v29, s3, v26                                 // 0000004AFDC8: 103A3403
	.long 0xd7006a14                                           // 0000004AFDCC: D7006A14
	v_cndmask_b32_e32 v1, v4, v20, vcc_lo                      // 0000004AFDD0: 02022904
	.long 0x7e02399e                                           // 0000004AFDD4: 7E02399E
	.long 0x7e36399f                                           // 0000004AFDD8: 7E36399F
	.long 0xd7600000                                           // 0000004AFDDC: D7600000
	v_cndmask_b32_e32 v0, v17, v147, vcc_lo                    // 0000004AFDE0: 02012711
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 0000004AFDE4: 102424FF 3DB504F3
	v_add_co_ci_u32_e64 v21, null, v8, v21, vcc_lo             // 0000004AFDEC: D5207C15 01AA2B08
	v_and_b32_e32 v28, 1, v1                                   // 0000004AFDF4: 36380281
	v_and_b32_e32 v27, 1, v27                                  // 0000004AFDF8: 36363681
	.long 0xd7006a16                                           // 0000004AFDFC: D7006A16
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 0000004AFE00: 02022D04
	v_xor_b32_e32 v32, v19, v3                                 // 0000004AFE04: 3A400713
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AFE08: BF870214
	v_add3_u32 v28, v30, v28, 0x7fff                           // 0000004AFE0C: D655001C 03FE391E 00007FFF
	v_add3_u32 v30, v31, v27, 0x7fff                           // 0000004AFE18: D655001E 03FE371F 00007FFF
	.long 0x7e3e399d                                           // 0000004AFE24: 7E3E399D
	.long 0x7f3e3981                                           // 0000004AFE28: 7F3E3981
	v_lshlrev_b32_e32 v33, 9, v19                              // 0000004AFE2C: 30422689
	v_add_co_ci_u32_e64 v23, null, v8, v23, vcc_lo             // 0000004AFE30: D5207C17 01AA2F08
	v_mul_f32_e32 v18, s0, v18                                 // 0000004AFE38: 10242400
	v_or_b32_e32 v15, 0x60, v15                                // 0000004AFE3C: 381E1EFF 00000060
	s_clause 0x1                                               // 0000004AFE44: BF850001
	global_store_d16_hi_b16 v[20:21], v30, off                 // 0000004AFE48: DC960000 007C1E14
	global_store_d16_hi_b16 v[22:23], v28, off                 // 0000004AFE50: DC960000 007C1C16
	v_lshl_add_u32 v22, v32, 2, v33                            // 0000004AFE58: D6460016 04850520
	v_and_b32_e32 v23, 1, v31                                  // 0000004AFE60: 362E3E81
	.long 0x7e023992                                           // 0000004AFE64: 7E023992
	v_mad_i64_i32 v[26:27], null, v15, s6, 0                   // 0000004AFE68: D6FF7C1A 02000D0F
	.long 0xd73c0018                                           // 0000004AFE70: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000004AFE74: 02023081
	ds_load_2addr_stride64_b32 v[20:21], v22 offset1:64        // 0000004AFE78: D8E04000 14000016
	v_add3_u32 v29, v29, v23, 0x7fff                           // 0000004AFE80: D655001D 03FE2F1D 00007FFF
	ds_load_2addr_stride64_b32 v[22:23], v22 offset0:128 offset1:192// 0000004AFE8C: D8E0C080 16000016
	v_and_b32_e32 v15, 1, v1                                   // 0000004AFE94: 361E0281
	v_or_b32_e32 v28, s1, v19                                  // 0000004AFE98: 38382601
	.long 0xd7006a18                                           // 0000004AFE9C: D7006A18
	v_cndmask_b32_e32 v1, v4, v24, vcc_lo                      // 0000004AFEA0: 02023104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AFEA4: BF870211
	v_add_co_ci_u32_e64 v25, null, v8, v25, vcc_lo             // 0000004AFEA8: D5207C19 01AA3308
	v_add3_u32 v15, v18, v15, 0x7fff                           // 0000004AFEB0: D655000F 03FE1F12 00007FFF
	.long 0xd73c0012                                           // 0000004AFEBC: D73C0012
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000004AFEC0: 02023481
	v_mad_i64_i32 v[26:27], null, v28, s6, 0                   // 0000004AFEC4: D6FF7C1A 02000D1C
	v_or_b32_e32 v30, 64, v28                                  // 0000004AFECC: 383C38C0
	global_store_d16_hi_b16 v[24:25], v29, off                 // 0000004AFED0: DC960000 007C1D18
	v_or_b32_e32 v29, 32, v28                                  // 0000004AFED8: 383A38A0
	.long 0xd7600003                                           // 0000004AFEDC: D7600003
	v_cndmask_b32_e32 v0, v16, v148, vcc_lo                    // 0000004AFEE0: 02012910
	.long 0xd7006a12                                           // 0000004AFEE4: D7006A12
	v_cndmask_b32_e32 v1, v4, v18, vcc_lo                      // 0000004AFEE8: 02022504
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004AFEEC: BF870001
	v_add_co_ci_u32_e64 v19, null, v8, v19, vcc_lo             // 0000004AFEF0: D5207C13 01AA2708
	.long 0xd73c0018                                           // 0000004AFEF8: D73C0018
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000004AFEFC: 02023481
	v_mad_i64_i32 v[26:27], null, v30, s6, 0                   // 0000004AFF00: D6FF7C1A 02000D1E
	s_waitcnt lgkmcnt(0)                                       // 0000004AFF08: BF89FC07
	v_sub_f32_e32 v30, v22, v23                                // 0000004AFF0C: 083C2F16
	global_store_d16_hi_b16 v[18:19], v15, off                 // 0000004AFF10: DC960000 007C0F12
	v_mad_i64_i32 v[18:19], null, v29, s6, 0                   // 0000004AFF18: D6FF7C12 02000D1D
	v_dual_add_f32 v29, v20, v21 :: v_dual_add_f32 v22, v22, v23// 0000004AFF20: C9082B14 1D162F16
	v_sub_f32_e32 v15, v20, v21                                // 0000004AFF28: 081E2B14
	.long 0xd7600000                                           // 0000004AFF2C: D7600000
	v_cndmask_b32_e32 v0, v16, v132, vcc_lo                    // 0000004AFF30: 02010910
	.long 0xd73c0014                                           // 0000004AFF34: D73C0014
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000004AFF38: 02023481
	.long 0xd7600002                                           // 0000004AFF3C: D7600002
	v_cndmask_b32_e32 v0, v17, v132, vcc_lo                    // 0000004AFF40: 02010911
	v_add_f32_e32 v26, v29, v22                                // 0000004AFF44: 06342D1D
	v_sub_f32_e32 v22, v29, v22                                // 0000004AFF48: 082C2D1D
	v_add_f32_e32 v23, v15, v30                                // 0000004AFF4C: 062E3D0F
	v_sub_f32_e32 v15, v15, v30                                // 0000004AFF50: 081E3D0F
	v_lshlrev_b32_e32 v33, 9, v14                              // 0000004AFF54: 30421C89
	.long 0xd73c0012                                           // 0000004AFF58: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004AFF5C: 02022481
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AFF60: BF870214
	v_dual_mul_f32 v22, 0x3db504f3, v22 :: v_dual_mul_f32 v23, 0x3db504f3, v23// 0000004AFF64: C8C62CFF 16162EFF 3DB504F3
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 0000004AFF70: 101E1EFF 3DB504F3
	.long 0x7f443981                                           // 0000004AFF78: 7F443981
	v_or_b32_e32 v37, s1, v14                                  // 0000004AFF7C: 384A1C01
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004AFF80: BF870244
	v_mul_f32_e32 v32, s3, v22                                 // 0000004AFF84: 10402C03
	.long 0xd7600003                                           // 0000004AFF88: D7600003
	v_cndmask_b32_e32 v0, v16, v149, vcc_lo                    // 0000004AFF8C: 02012B10
	v_dual_mul_f32 v26, 0x3db504f3, v26 :: v_dual_mul_f32 v27, s2, v23// 0000004AFF90: C8C634FF 1A1A2E02 3DB504F3
	.long 0xd7006a18                                           // 0000004AFF9C: D7006A18
	v_cndmask_b32_e32 v1, v4, v24, vcc_lo                      // 0000004AFFA0: 02023104
	.long 0x7e4439a0                                           // 0000004AFFA4: 7E4439A0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000004AFFA8: BF870253
	v_mul_f32_e32 v30, s0, v26                                 // 0000004AFFAC: 103C3400
	.long 0xd7600000                                           // 0000004AFFB0: D7600000
	v_cndmask_b32_e32 v0, v17, v148, vcc_lo                    // 0000004AFFB4: 02012911
	.long 0x7e02399b                                           // 0000004AFFB8: 7E02399B
	.long 0x7f343981                                           // 0000004AFFBC: 7F343981
	v_add_co_ci_u32_e64 v25, null, v8, v25, vcc_lo             // 0000004AFFC0: D5207C19 01AA3308
	v_mul_f32_e32 v31, s0, v15                                 // 0000004AFFC8: 103E1E00
	v_or_b32_e32 v15, 0x60, v28                                // 0000004AFFCC: 381E38FF 00000060
	v_xor_b32_e32 v28, v14, v3                                 // 0000004AFFD4: 3A38070E
	.long 0x7e34399e                                           // 0000004AFFD8: 7E34399E
	v_and_b32_e32 v29, 1, v1                                   // 0000004AFFDC: 363A0281
	.long 0x7e02399f                                           // 0000004AFFE0: 7E02399F
	v_mad_i64_i32 v[22:23], null, v15, s6, 0                   // 0000004AFFE4: D6FF7C16 02000D0F
	v_lshl_add_u32 v15, v28, 2, v33                            // 0000004AFFEC: D646000F 0485051C
	v_and_b32_e32 v33, 1, v26                                  // 0000004AFFF4: 36423481
	v_add3_u32 v35, v27, v29, 0x7fff                           // 0000004AFFF8: D6550023 03FE3B1B 00007FFF
	ds_load_2addr_stride64_b32 v[26:27], v15 offset1:64        // 0000004B0004: D8E04000 1A00000F
	ds_load_2addr_stride64_b32 v[28:29], v15 offset0:128 offset1:192// 0000004B000C: D8E0C080 1C00000F
	.long 0xd7006a12                                           // 0000004B0014: D7006A12
	v_cndmask_b32_e32 v1, v4, v18, vcc_lo                      // 0000004B0018: 02022504
	.long 0xd73c000e                                           // 0000004B001C: D73C000E
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000004B0020: 02022C81
	v_and_b32_e32 v34, 1, v34                                  // 0000004B0024: 36444481
	v_and_b32_e32 v36, 1, v1                                   // 0000004B0028: 36480281
	v_add_co_ci_u32_e64 v19, null, v8, v19, vcc_lo             // 0000004B002C: D5207C13 01AA2708
	.long 0xd7006a14                                           // 0000004B0034: D7006A14
	v_cndmask_b32_e32 v1, v4, v20, vcc_lo                      // 0000004B0038: 02022904
	v_mad_i64_i32 v[22:23], null, v37, s6, 0                   // 0000004B003C: D6FF7C16 02000D25
	v_add_co_ci_u32_e64 v21, null, v8, v21, vcc_lo             // 0000004B0044: D5207C15 01AA2B08
	.long 0xd7006a0e                                           // 0000004B004C: D7006A0E
	v_cndmask_b32_e32 v1, v4, v14, vcc_lo                      // 0000004B0050: 02021D04
	v_add3_u32 v30, v30, v33, 0x7fff                           // 0000004B0054: D655001E 03FE431E 00007FFF
	v_add3_u32 v32, v32, v34, 0x7fff                           // 0000004B0060: D6550020 03FE4520 00007FFF
	v_add3_u32 v31, v31, v36, 0x7fff                           // 0000004B006C: D655001F 03FE491F 00007FFF
	v_add_co_ci_u32_e64 v15, null, v8, v15, vcc_lo             // 0000004B0078: D5207C0F 01AA1F08
	s_clause 0x3                                               // 0000004B0080: BF850003
	global_store_d16_hi_b16 v[24:25], v30, off                 // 0000004B0084: DC960000 007C1E18
	global_store_d16_hi_b16 v[18:19], v35, off                 // 0000004B008C: DC960000 007C2312
	global_store_d16_hi_b16 v[20:21], v32, off                 // 0000004B0094: DC960000 007C2014
	global_store_d16_hi_b16 v[14:15], v31, off                 // 0000004B009C: DC960000 007C1F0E
	.long 0xd73c000e                                           // 0000004B00A4: D73C000E
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000004B00A8: 02022C81
	s_waitcnt lgkmcnt(1)                                       // 0000004B00AC: BF89FC17
	v_add_f32_e32 v23, v26, v27                                // 0000004B00B0: 062E371A
	s_waitcnt lgkmcnt(0)                                       // 0000004B00B4: BF89FC07
	v_dual_add_f32 v25, v28, v29 :: v_dual_sub_f32 v22, v26, v27// 0000004B00B8: C90A3B1C 1916371A
	v_sub_f32_e32 v24, v28, v29                                // 0000004B00C0: 08303B1C
	v_or_b32_e32 v18, 32, v37                                  // 0000004B00C4: 38244AA0
	.long 0xd7600000                                           // 0000004B00C8: D7600000
	v_cndmask_b32_e32 v0, v16, v133, vcc_lo                    // 0000004B00CC: 02010B10
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004B00D0: BF870244
	v_add_f32_e32 v21, v23, v25                                // 0000004B00D4: 062A3317
	.long 0xd7600002                                           // 0000004B00D8: D7600002
	v_cndmask_b32_e32 v0, v17, v133, vcc_lo                    // 0000004B00DC: 02010B11
	v_add_f32_e32 v20, v22, v24                                // 0000004B00E0: 06283116
	v_mad_i64_i32 v[18:19], null, v18, s6, 0                   // 0000004B00E4: D6FF7C12 02000D12
	v_dual_sub_f32 v22, v22, v24 :: v_dual_mul_f32 v21, 0x3db504f3, v21// 0000004B00EC: C9463116 16142AFF 3DB504F3
	.long 0x7f303981                                           // 0000004B00F8: 7F303981
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004B00FC: BF870224
	v_dual_mul_f32 v20, 0x3db504f3, v20 :: v_dual_sub_f32 v23, v23, v25// 0000004B0100: C8CA28FF 14163317 3DB504F3
	v_or_b32_e32 v26, 64, v37                                  // 0000004B010C: 38344AC0
	v_mul_f32_e32 v28, s0, v21                                 // 0000004B0110: 10382A00
	.long 0xd7600000                                           // 0000004B0114: D7600000
	v_cndmask_b32_e32 v0, v17, v149, vcc_lo                    // 0000004B0118: 02012B11
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004B011C: BF870224
	v_dual_mul_f32 v27, s2, v20 :: v_dual_mul_f32 v22, 0x3db504f3, v22// 0000004B0120: C8C62802 1B162CFF 3DB504F3
	.long 0xd73c0012                                           // 0000004B012C: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004B0130: 02022481
	.long 0x7e30399c                                           // 0000004B0134: 7E30399C
	v_mul_f32_e32 v23, 0x3db504f3, v23                         // 0000004B0138: 102E2EFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004B0140: BF870224
	.long 0x7e02399b                                           // 0000004B0144: 7E02399B
	.long 0xd7006a0e                                           // 0000004B0148: D7006A0E
	v_cndmask_b32_e32 v1, v4, v14, vcc_lo                      // 0000004B014C: 02021D04
	v_and_b32_e32 v24, 1, v24                                  // 0000004B0150: 36303081
	v_mad_i64_i32 v[20:21], null, v26, s6, 0                   // 0000004B0154: D6FF7C14 02000D1A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004B015C: BF870004
	v_dual_mul_f32 v26, s0, v22 :: v_dual_and_b32 v25, 1, v1   // 0000004B0160: C8E42C00 1A180281
	v_or_b32_e32 v22, 0x60, v37                                // 0000004B0168: 382C4AFF 00000060
	v_add_co_ci_u32_e64 v15, null, v8, v15, vcc_lo             // 0000004B0170: D5207C0F 01AA1F08
	.long 0xd7006a12                                           // 0000004B0178: D7006A12
	v_cndmask_b32_e32 v1, v4, v18, vcc_lo                      // 0000004B017C: 02022504
	v_mul_f32_e32 v29, s3, v23                                 // 0000004B0180: 103A2E03
	v_add3_u32 v24, v28, v24, 0x7fff                           // 0000004B0184: D6550018 03FE311C 00007FFF
	v_xor_b32_e32 v28, v13, v3                                 // 0000004B0190: 3A38070D
	v_lshlrev_b32_e32 v30, 9, v13                              // 0000004B0194: 303C1A89
	v_add_co_ci_u32_e64 v19, null, v8, v19, vcc_lo             // 0000004B0198: D5207C13 01AA2708
	v_add3_u32 v25, v27, v25, 0x7fff                           // 0000004B01A0: D6550019 03FE331B 00007FFF
	v_mad_i64_i32 v[22:23], null, v22, s6, 0                   // 0000004B01AC: D6FF7C16 02000D16
	.long 0x7e36399d                                           // 0000004B01B4: 7E36399D
	.long 0x7f363981                                           // 0000004B01B8: 7F363981
	s_clause 0x1                                               // 0000004B01BC: BF850001
	global_store_d16_hi_b16 v[14:15], v24, off                 // 0000004B01C0: DC960000 007C180E
	global_store_d16_hi_b16 v[18:19], v25, off                 // 0000004B01C8: DC960000 007C1912
	v_lshl_add_u32 v15, v28, 2, v30                            // 0000004B01D0: D646000F 0479051C
	.long 0xd73c0014                                           // 0000004B01D8: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000004B01DC: 02022881
	.long 0x7e02399a                                           // 0000004B01E0: 7E02399A
	v_and_b32_e32 v24, 1, v27                                  // 0000004B01E4: 36303681
	v_or_b32_e32 v27, s1, v13                                  // 0000004B01E8: 38361A01
	.long 0xd73c000d                                           // 0000004B01EC: D73C000D
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000004B01F0: 02022C81
	ds_load_2addr_stride64_b32 v[18:19], v15 offset1:64        // 0000004B01F4: D8E04000 1200000F
	ds_load_2addr_stride64_b32 v[22:23], v15 offset0:128 offset1:192// 0000004B01FC: D8E0C080 1600000F
	.long 0xd7006a14                                           // 0000004B0204: D7006A14
	v_cndmask_b32_e32 v1, v4, v20, vcc_lo                      // 0000004B0208: 02022904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000004B020C: BF870251
	v_add_co_ci_u32_e64 v21, null, v8, v21, vcc_lo             // 0000004B0210: D5207C15 01AA2B08
	v_and_b32_e32 v31, 1, v1                                   // 0000004B0218: 363E0281
	v_add3_u32 v28, v29, v24, 0x7fff                           // 0000004B021C: D655001C 03FE311D 00007FFF
	v_mad_i64_i32 v[24:25], null, v27, s6, 0                   // 0000004B0228: D6FF7C18 02000D1B
	.long 0xd7006a0d                                           // 0000004B0230: D7006A0D
	v_cndmask_b32_e32 v1, v4, v13, vcc_lo                      // 0000004B0234: 02021B04
	v_add3_u32 v26, v26, v31, 0x7fff                           // 0000004B0238: D655001A 03FE3F1A 00007FFF
	v_add_co_ci_u32_e64 v14, null, v8, v14, vcc_lo             // 0000004B0244: D5207C0E 01AA1D08
	global_store_d16_hi_b16 v[20:21], v28, off                 // 0000004B024C: DC960000 007C1C14
	v_or_b32_e32 v15, 32, v27                                  // 0000004B0254: 381E36A0
	v_or_b32_e32 v28, 64, v27                                  // 0000004B0258: 383836C0
	.long 0xd73c0014                                           // 0000004B025C: D73C0014
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000004B0260: 02023081
	global_store_d16_hi_b16 v[13:14], v26, off                 // 0000004B0264: DC960000 007C1A0D
	.long 0xd7600002                                           // 0000004B026C: D7600002
	v_cndmask_b32_e32 v0, v17, v134, vcc_lo                    // 0000004B0270: 02010D11
	v_mad_i64_i32 v[13:14], null, v15, s6, 0                   // 0000004B0274: D6FF7C0D 02000D0F
	v_mad_i64_i32 v[24:25], null, v28, s6, 0                   // 0000004B027C: D6FF7C18 02000D1C
	s_waitcnt lgkmcnt(1)                                       // 0000004B0284: BF89FC17
	v_sub_f32_e32 v15, v18, v19                                // 0000004B0288: 081E2712
	s_waitcnt lgkmcnt(0)                                       // 0000004B028C: BF89FC07
	v_sub_f32_e32 v28, v22, v23                                // 0000004B0290: 08382F16
	v_add_f32_e32 v26, v18, v19                                // 0000004B0294: 06342712
	v_add_f32_e32 v22, v22, v23                                // 0000004B0298: 062C2F16
	.long 0xd7600000                                           // 0000004B029C: D7600000
	v_cndmask_b32_e32 v0, v16, v134, vcc_lo                    // 0000004B02A0: 02010D10
	.long 0xd7600003                                           // 0000004B02A4: D7600003
	v_cndmask_b32_e32 v0, v16, v150, vcc_lo                    // 0000004B02A8: 02012D10
	v_add_f32_e32 v23, v15, v28                                // 0000004B02AC: 062E390F
	.long 0xd73c0012                                           // 0000004B02B0: D73C0012
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000004B02B4: 02023081
	v_add_f32_e32 v24, v26, v22                                // 0000004B02B8: 06302D1A
	v_dual_sub_f32 v22, v26, v22 :: v_dual_sub_f32 v15, v15, v28// 0000004B02BC: C94A2D1A 160E390F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004B02C4: BF870194
	v_dual_mul_f32 v23, 0x3db504f3, v23 :: v_dual_lshlrev_b32 v30, 9, v12// 0000004B02C8: C8E22EFF 171E1889 3DB504F3
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 0000004B02D4: 103030FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004B02DC: BF870193
	v_dual_mul_f32 v22, 0x3db504f3, v22 :: v_dual_mul_f32 v15, 0x3db504f3, v15// 0000004B02E0: C8C62CFF 160E1EFF 3DB504F3
	v_mul_f32_e32 v25, s2, v23                                 // 0000004B02EC: 10322E02
	.long 0xd73c000d                                           // 0000004B02F0: D73C000D
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000004B02F4: 02021A81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004B02F8: BF870223
	v_dual_mul_f32 v28, s0, v24 :: v_dual_mul_f32 v29, s3, v22 // 0000004B02FC: C8C63000 1C1C2C03
	v_or_b32_e32 v22, 0x60, v27                                // 0000004B0304: 382C36FF 00000060
	.long 0x7e023999                                           // 0000004B030C: 7E023999
	v_xor_b32_e32 v27, v12, v3                                 // 0000004B0310: 3A36070C
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004B0314: BF870004
	.long 0x7e30399c                                           // 0000004B0318: 7E30399C
	.long 0x7f303981                                           // 0000004B031C: 7F303981
	.long 0xd7600000                                           // 0000004B0320: D7600000
	v_cndmask_b32_e32 v0, v17, v150, vcc_lo                    // 0000004B0324: 02012D11
	v_and_b32_e32 v26, 1, v1                                   // 0000004B0328: 36340281
	v_lshl_add_u32 v27, v27, 2, v30                            // 0000004B032C: D646001B 0479051B
	v_mad_i64_i32 v[22:23], null, v22, s6, 0                   // 0000004B0334: D6FF7C16 02000D16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004B033C: BF870214
	v_dual_mul_f32 v15, s0, v15 :: v_dual_and_b32 v30, 1, v24  // 0000004B0340: C8E41E00 0F1E3081
	v_add3_u32 v32, v25, v26, 0x7fff                           // 0000004B0348: D6550020 03FE3519 00007FFF
	ds_load_2addr_stride64_b32 v[24:25], v27 offset1:64        // 0000004B0354: D8E04000 1800001B
	ds_load_2addr_stride64_b32 v[26:27], v27 offset0:128 offset1:192// 0000004B035C: D8E0C080 1A00001B
	.long 0x7e3e399d                                           // 0000004B0364: 7E3E399D
	.long 0x7f3e3981                                           // 0000004B0368: 7F3E3981
	.long 0x7e02398f                                           // 0000004B036C: 7E02398F
	.long 0xd7006a14                                           // 0000004B0370: D7006A14
	v_cndmask_b32_e32 v1, v4, v20, vcc_lo                      // 0000004B0374: 02022904
	.long 0xd73c0016                                           // 0000004B0378: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000004B037C: 02022C81
	v_add_co_ci_u32_e64 v21, null, v8, v21, vcc_lo             // 0000004B0380: D5207C15 01AA2B08
	.long 0xd7006a0d                                           // 0000004B0388: D7006A0D
	v_cndmask_b32_e32 v1, v4, v13, vcc_lo                      // 0000004B038C: 02021B04
	v_and_b32_e32 v31, 1, v31                                  // 0000004B0390: 363E3E81
	v_and_b32_e32 v33, 1, v1                                   // 0000004B0394: 36420281
	v_add_co_ci_u32_e64 v14, null, v8, v14, vcc_lo             // 0000004B0398: D5207C0E 01AA1D08
	.long 0xd7006a12                                           // 0000004B03A0: D7006A12
	v_cndmask_b32_e32 v1, v4, v18, vcc_lo                      // 0000004B03A4: 02022504
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004B03A8: BF870001
	v_add_co_ci_u32_e64 v19, null, v8, v19, vcc_lo             // 0000004B03AC: D5207C13 01AA2708
	.long 0xd7006a16                                           // 0000004B03B4: D7006A16
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 0000004B03B8: 02022D04
	v_or_b32_e32 v34, s1, v12                                  // 0000004B03BC: 38441801
	v_add3_u32 v12, v28, v30, 0x7fff                           // 0000004B03C0: D655000C 03FE3D1C 00007FFF
	v_add3_u32 v30, v29, v31, 0x7fff                           // 0000004B03CC: D655001E 03FE3F1D 00007FFF
	v_add3_u32 v15, v15, v33, 0x7fff                           // 0000004B03D8: D655000F 03FE430F 00007FFF
	v_add_co_ci_u32_e64 v23, null, v8, v23, vcc_lo             // 0000004B03E4: D5207C17 01AA2F08
	s_clause 0x3                                               // 0000004B03EC: BF850003
	global_store_d16_hi_b16 v[20:21], v12, off                 // 0000004B03F0: DC960000 007C0C14
	global_store_d16_hi_b16 v[13:14], v32, off                 // 0000004B03F8: DC960000 007C200D
	global_store_d16_hi_b16 v[18:19], v30, off                 // 0000004B0400: DC960000 007C1E12
	global_store_d16_hi_b16 v[22:23], v15, off                 // 0000004B0408: DC960000 007C0F16
	s_waitcnt lgkmcnt(1)                                       // 0000004B0410: BF89FC17
	v_add_f32_e32 v21, v24, v25                                // 0000004B0414: 062A3318
	s_waitcnt lgkmcnt(0)                                       // 0000004B0418: BF89FC07
	v_dual_add_f32 v23, v26, v27 :: v_dual_sub_f32 v20, v24, v25// 0000004B041C: C90A371A 17143318
	v_sub_f32_e32 v22, v26, v27                                // 0000004B0424: 082C371A
	v_or_b32_e32 v14, 32, v34                                  // 0000004B0428: 381C44A0
	.long 0xd7600000                                           // 0000004B042C: D7600000
	v_cndmask_b32_e32 v0, v16, v135, vcc_lo                    // 0000004B0430: 02010F10
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004B0434: BF870004
	v_add_f32_e32 v19, v21, v23                                // 0000004B0438: 06262F15
	.long 0xd7600002                                           // 0000004B043C: D7600002
	v_cndmask_b32_e32 v0, v17, v135, vcc_lo                    // 0000004B0440: 02010F11
	v_add_f32_e32 v18, v20, v22                                // 0000004B0444: 06242D14
	v_mad_i64_i32 v[28:29], null, v34, s6, 0                   // 0000004B0448: D6FF7C1C 02000D22
	v_mad_i64_i32 v[14:15], null, v14, s6, 0                   // 0000004B0450: D6FF7C0E 02000D0E
	v_dual_mul_f32 v19, 0x3db504f3, v19 :: v_dual_sub_f32 v20, v20, v22// 0000004B0458: C8CA26FF 13142D14 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004B0464: BF870234
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 0000004B0468: 102424FF 3DB504F3
	.long 0x7f2c3981                                           // 0000004B0470: 7F2C3981
	v_sub_f32_e32 v21, v21, v23                                // 0000004B0474: 082A2F15
	v_mul_f32_e32 v26, s0, v19                                 // 0000004B0478: 10342600
	.long 0xd73c000c                                           // 0000004B047C: D73C000C
	v_cndmask_b32_e32 v1, 1, v28, vcc_lo                       // 0000004B0480: 02023881
	v_mul_f32_e32 v25, s2, v18                                 // 0000004B0484: 10322402
	v_or_b32_e32 v24, 64, v34                                  // 0000004B0488: 383044C0
	.long 0xd7600000                                           // 0000004B048C: D7600000
	v_cndmask_b32_e32 v0, v17, v151, vcc_lo                    // 0000004B0490: 02012F11
	.long 0x7e2c399a                                           // 0000004B0494: 7E2C399A
	v_mul_f32_e32 v20, 0x3db504f3, v20                         // 0000004B0498: 102828FF 3DB504F3
	.long 0x7e023999                                           // 0000004B04A0: 7E023999
	.long 0xd73c000e                                           // 0000004B04A4: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000004B04A8: 02021C81
	.long 0xd7600003                                           // 0000004B04AC: D7600003
	v_cndmask_b32_e32 v0, v16, v151, vcc_lo                    // 0000004B04B0: 02012F10
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_and_b32 v22, 1, v22// 0000004B04B4: C8E42AFF 15162C81 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004B04C0: BF870004
	v_and_b32_e32 v23, 1, v1                                   // 0000004B04C4: 362E0281
	.long 0xd7006a0c                                           // 0000004B04C8: D7006A0C
	v_cndmask_b32_e32 v1, v4, v12, vcc_lo                      // 0000004B04CC: 02021904
	v_mad_i64_i32 v[18:19], null, v24, s6, 0                   // 0000004B04D0: D6FF7C12 02000D18
	v_mul_f32_e32 v24, s0, v20                                 // 0000004B04D8: 10302800
	v_or_b32_e32 v20, 0x60, v34                                // 0000004B04DC: 382844FF 00000060
	v_add_co_ci_u32_e64 v13, null, v8, v13, vcc_lo             // 0000004B04E4: D5207C0D 01AA1B08
	.long 0xd7006a0e                                           // 0000004B04EC: D7006A0E
	v_cndmask_b32_e32 v1, v4, v14, vcc_lo                      // 0000004B04F0: 02021D04
	v_mul_f32_e32 v27, s3, v21                                 // 0000004B04F4: 10362A03
	v_add3_u32 v22, v26, v22, 0x7fff                           // 0000004B04F8: D6550016 03FE2D1A 00007FFF
	v_xor_b32_e32 v26, v11, v3                                 // 0000004B0504: 3A34070B
	v_lshlrev_b32_e32 v28, 9, v11                              // 0000004B0508: 30381689
	v_add_co_ci_u32_e64 v15, null, v8, v15, vcc_lo             // 0000004B050C: D5207C0F 01AA1F08
	v_add3_u32 v23, v25, v23, 0x7fff                           // 0000004B0514: D6550017 03FE2F19 00007FFF
	v_mad_i64_i32 v[20:21], null, v20, s6, 0                   // 0000004B0520: D6FF7C14 02000D14
	.long 0x7e32399b                                           // 0000004B0528: 7E32399B
	.long 0x7f323981                                           // 0000004B052C: 7F323981
	s_clause 0x1                                               // 0000004B0530: BF850001
	global_store_d16_hi_b16 v[12:13], v22, off                 // 0000004B0534: DC960000 007C160C
	global_store_d16_hi_b16 v[14:15], v23, off                 // 0000004B053C: DC960000 007C170E
	v_lshl_add_u32 v15, v26, 2, v28                            // 0000004B0544: D646000F 0471051A
	.long 0xd73c0012                                           // 0000004B054C: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004B0550: 02022481
	.long 0x7e023998                                           // 0000004B0554: 7E023998
	v_and_b32_e32 v22, 1, v25                                  // 0000004B0558: 362C3281
	v_or_b32_e32 v25, s1, v11                                  // 0000004B055C: 38321601
	.long 0xd73c000b                                           // 0000004B0560: D73C000B
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000004B0564: 02022881
	ds_load_2addr_stride64_b32 v[13:14], v15 offset1:64        // 0000004B0568: D8E04000 0D00000F
	ds_load_2addr_stride64_b32 v[20:21], v15 offset0:128 offset1:192// 0000004B0570: D8E0C080 1400000F
	.long 0xd7006a12                                           // 0000004B0578: D7006A12
	v_cndmask_b32_e32 v1, v4, v18, vcc_lo                      // 0000004B057C: 02022504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000004B0580: BF870251
	v_add_co_ci_u32_e64 v19, null, v8, v19, vcc_lo             // 0000004B0584: D5207C13 01AA2708
	v_and_b32_e32 v29, 1, v1                                   // 0000004B058C: 363A0281
	v_add3_u32 v26, v27, v22, 0x7fff                           // 0000004B0590: D655001A 03FE2D1B 00007FFF
	v_mad_i64_i32 v[22:23], null, v25, s6, 0                   // 0000004B059C: D6FF7C16 02000D19
	.long 0xd7006a0b                                           // 0000004B05A4: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000004B05A8: 02021704
	v_add3_u32 v24, v24, v29, 0x7fff                           // 0000004B05AC: D6550018 03FE3B18 00007FFF
	v_add_co_ci_u32_e64 v12, null, v8, v12, vcc_lo             // 0000004B05B8: D5207C0C 01AA1908
	global_store_d16_hi_b16 v[18:19], v26, off                 // 0000004B05C0: DC960000 007C1A12
	v_or_b32_e32 v15, 32, v25                                  // 0000004B05C8: 381E32A0
	v_or_b32_e32 v26, 64, v25                                  // 0000004B05CC: 383432C0
	.long 0xd73c0012                                           // 0000004B05D0: D73C0012
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000004B05D4: 02022C81
	global_store_d16_hi_b16 v[11:12], v24, off                 // 0000004B05D8: DC960000 007C180B
	.long 0xd7600002                                           // 0000004B05E0: D7600002
	v_cndmask_b32_e32 v0, v17, v136, vcc_lo                    // 0000004B05E4: 02011111
	v_mad_i64_i32 v[11:12], null, v15, s6, 0                   // 0000004B05E8: D6FF7C0B 02000D0F
	v_mad_i64_i32 v[22:23], null, v26, s6, 0                   // 0000004B05F0: D6FF7C16 02000D1A
	s_waitcnt lgkmcnt(0)                                       // 0000004B05F8: BF89FC07
	v_dual_sub_f32 v15, v13, v14 :: v_dual_sub_f32 v26, v20, v21// 0000004B05FC: C94A1D0D 0F1A2B14
	v_add_f32_e32 v24, v13, v14                                // 0000004B0604: 06301D0D
	v_add_f32_e32 v20, v20, v21                                // 0000004B0608: 06282B14
	.long 0xd7600000                                           // 0000004B060C: D7600000
	v_cndmask_b32_e32 v0, v16, v136, vcc_lo                    // 0000004B0610: 02011110
	.long 0xd7600003                                           // 0000004B0614: D7600003
	v_cndmask_b32_e32 v0, v16, v152, vcc_lo                    // 0000004B0618: 02013110
	v_add_f32_e32 v21, v15, v26                                // 0000004B061C: 062A350F
	.long 0xd73c000d                                           // 0000004B0620: D73C000D
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000004B0624: 02022C81
	v_add_f32_e32 v22, v24, v20                                // 0000004B0628: 062C2918
	v_dual_sub_f32 v20, v24, v20 :: v_dual_sub_f32 v15, v15, v26// 0000004B062C: C94A2918 140E350F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004B0634: BF870194
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_lshlrev_b32 v28, 9, v10// 0000004B0638: C8E22AFF 151C1489 3DB504F3
	v_mul_f32_e32 v22, 0x3db504f3, v22                         // 0000004B0644: 102C2CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004B064C: BF870193
	v_dual_mul_f32 v20, 0x3db504f3, v20 :: v_dual_mul_f32 v15, 0x3db504f3, v15// 0000004B0650: C8C628FF 140E1EFF 3DB504F3
	v_mul_f32_e32 v23, s2, v21                                 // 0000004B065C: 102E2A02
	.long 0xd73c000b                                           // 0000004B0660: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000004B0664: 02021681
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004B0668: BF870223
	v_dual_mul_f32 v26, s0, v22 :: v_dual_mul_f32 v27, s3, v20 // 0000004B066C: C8C62C00 1A1A2803
	v_or_b32_e32 v20, 0x60, v25                                // 0000004B0674: 382832FF 00000060
	.long 0x7e023997                                           // 0000004B067C: 7E023997
	v_xor_b32_e32 v25, v10, v3                                 // 0000004B0680: 3A32070A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004B0684: BF870004
	.long 0x7e2c399a                                           // 0000004B0688: 7E2C399A
	.long 0x7f2c3981                                           // 0000004B068C: 7F2C3981
	.long 0xd7600000                                           // 0000004B0690: D7600000
	v_cndmask_b32_e32 v0, v17, v152, vcc_lo                    // 0000004B0694: 02013111
	v_and_b32_e32 v24, 1, v1                                   // 0000004B0698: 36300281
	v_lshl_add_u32 v25, v25, 2, v28                            // 0000004B069C: D6460019 04710519
	v_mad_i64_i32 v[20:21], null, v20, s6, 0                   // 0000004B06A4: D6FF7C14 02000D14
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004B06AC: BF870214
	v_dual_mul_f32 v15, s0, v15 :: v_dual_and_b32 v28, 1, v22  // 0000004B06B0: C8E41E00 0F1C2C81
	v_add3_u32 v30, v23, v24, 0x7fff                           // 0000004B06B8: D655001E 03FE3117 00007FFF
	ds_load_2addr_stride64_b32 v[22:23], v25 offset1:64        // 0000004B06C4: D8E04000 16000019
	ds_load_2addr_stride64_b32 v[24:25], v25 offset0:128 offset1:192// 0000004B06CC: D8E0C080 18000019
	.long 0x7e3a399b                                           // 0000004B06D4: 7E3A399B
	.long 0x7f3a3981                                           // 0000004B06D8: 7F3A3981
	.long 0x7e02398f                                           // 0000004B06DC: 7E02398F
	.long 0xd7006a12                                           // 0000004B06E0: D7006A12
	v_cndmask_b32_e32 v1, v4, v18, vcc_lo                      // 0000004B06E4: 02022504
	.long 0xd73c0014                                           // 0000004B06E8: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000004B06EC: 02022881
	v_add_co_ci_u32_e64 v19, null, v8, v19, vcc_lo             // 0000004B06F0: D5207C13 01AA2708
	.long 0xd7006a0b                                           // 0000004B06F8: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000004B06FC: 02021704
	v_and_b32_e32 v29, 1, v29                                  // 0000004B0700: 363A3A81
	v_and_b32_e32 v31, 1, v1                                   // 0000004B0704: 363E0281
	v_add_co_ci_u32_e64 v12, null, v8, v12, vcc_lo             // 0000004B0708: D5207C0C 01AA1908
	.long 0xd7006a0d                                           // 0000004B0710: D7006A0D
	v_cndmask_b32_e32 v1, v4, v13, vcc_lo                      // 0000004B0714: 02021B04
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004B0718: BF870001
	v_add_co_ci_u32_e64 v14, null, v8, v14, vcc_lo             // 0000004B071C: D5207C0E 01AA1D08
	.long 0xd7006a14                                           // 0000004B0724: D7006A14
	v_cndmask_b32_e32 v1, v4, v20, vcc_lo                      // 0000004B0728: 02022904
	v_or_b32_e32 v32, s1, v10                                  // 0000004B072C: 38401401
	v_add3_u32 v10, v26, v28, 0x7fff                           // 0000004B0730: D655000A 03FE391A 00007FFF
	v_add3_u32 v28, v27, v29, 0x7fff                           // 0000004B073C: D655001C 03FE3B1B 00007FFF
	v_add3_u32 v15, v15, v31, 0x7fff                           // 0000004B0748: D655000F 03FE3F0F 00007FFF
	v_add_co_ci_u32_e64 v21, null, v8, v21, vcc_lo             // 0000004B0754: D5207C15 01AA2B08
	s_clause 0x3                                               // 0000004B075C: BF850003
	global_store_d16_hi_b16 v[18:19], v10, off                 // 0000004B0760: DC960000 007C0A12
	global_store_d16_hi_b16 v[11:12], v30, off                 // 0000004B0768: DC960000 007C1E0B
	global_store_d16_hi_b16 v[13:14], v28, off                 // 0000004B0770: DC960000 007C1C0D
	global_store_d16_hi_b16 v[20:21], v15, off                 // 0000004B0778: DC960000 007C0F14
	s_waitcnt lgkmcnt(1)                                       // 0000004B0780: BF89FC17
	v_add_f32_e32 v19, v22, v23                                // 0000004B0784: 06262F16
	s_waitcnt lgkmcnt(0)                                       // 0000004B0788: BF89FC07
	v_dual_add_f32 v21, v24, v25 :: v_dual_sub_f32 v18, v22, v23// 0000004B078C: C90A3318 15122F16
	v_sub_f32_e32 v20, v24, v25                                // 0000004B0794: 08283318
	v_or_b32_e32 v12, 32, v32                                  // 0000004B0798: 381840A0
	.long 0xd7600000                                           // 0000004B079C: D7600000
	v_cndmask_b32_e32 v0, v16, v137, vcc_lo                    // 0000004B07A0: 02011310
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004B07A4: BF870004
	v_add_f32_e32 v15, v19, v21                                // 0000004B07A8: 061E2B13
	.long 0xd7600002                                           // 0000004B07AC: D7600002
	v_cndmask_b32_e32 v0, v17, v137, vcc_lo                    // 0000004B07B0: 02011311
	v_add_f32_e32 v14, v18, v20                                // 0000004B07B4: 061C2912
	v_mad_i64_i32 v[26:27], null, v32, s6, 0                   // 0000004B07B8: D6FF7C1A 02000D20
	v_mad_i64_i32 v[12:13], null, v12, s6, 0                   // 0000004B07C0: D6FF7C0C 02000D0C
	v_dual_mul_f32 v15, 0x3db504f3, v15 :: v_dual_sub_f32 v18, v18, v20// 0000004B07C8: C8CA1EFF 0F122912 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004B07D4: BF8701A4
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 0000004B07D8: 101C1CFF 3DB504F3
	.long 0x7f283981                                           // 0000004B07E0: 7F283981
	v_dual_sub_f32 v19, v19, v21 :: v_dual_mul_f32 v24, s0, v15// 0000004B07E4: C9462B13 13181E00
	.long 0xd73c000a                                           // 0000004B07EC: D73C000A
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000004B07F0: 02023481
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004B07F4: BF870004
	v_mul_f32_e32 v23, s2, v14                                 // 0000004B07F8: 102E1C02
	v_or_b32_e32 v22, 64, v32                                  // 0000004B07FC: 382C40C0
	.long 0xd7600000                                           // 0000004B0800: D7600000
	v_cndmask_b32_e32 v0, v17, v153, vcc_lo                    // 0000004B0804: 02013311
	.long 0x7e283998                                           // 0000004B0808: 7E283998
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 0000004B080C: 102424FF 3DB504F3
	.long 0x7e023997                                           // 0000004B0814: 7E023997
	.long 0xd73c000c                                           // 0000004B0818: D73C000C
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000004B081C: 02021881
	.long 0xd7600003                                           // 0000004B0820: D7600003
	v_cndmask_b32_e32 v0, v16, v153, vcc_lo                    // 0000004B0824: 02013310
	v_dual_mul_f32 v19, 0x3db504f3, v19 :: v_dual_and_b32 v20, 1, v20// 0000004B0828: C8E426FF 13142881 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004B0834: BF870004
	v_and_b32_e32 v21, 1, v1                                   // 0000004B0838: 362A0281
	.long 0xd7006a0a                                           // 0000004B083C: D7006A0A
	v_cndmask_b32_e32 v1, v4, v10, vcc_lo                      // 0000004B0840: 02021504
	v_mad_i64_i32 v[14:15], null, v22, s6, 0                   // 0000004B0844: D6FF7C0E 02000D16
	v_mul_f32_e32 v22, s0, v18                                 // 0000004B084C: 102C2400
	v_or_b32_e32 v18, 0x60, v32                                // 0000004B0850: 382440FF 00000060
	v_add_co_ci_u32_e64 v11, null, v8, v11, vcc_lo             // 0000004B0858: D5207C0B 01AA1708
	.long 0xd7006a0c                                           // 0000004B0860: D7006A0C
	v_cndmask_b32_e32 v1, v4, v12, vcc_lo                      // 0000004B0864: 02021904
	v_mul_f32_e32 v25, s3, v19                                 // 0000004B0868: 10322603
	v_add3_u32 v20, v24, v20, 0x7fff                           // 0000004B086C: D6550014 03FE2918 00007FFF
	v_xor_b32_e32 v24, v9, v3                                  // 0000004B0878: 3A300709
	v_lshlrev_b32_e32 v26, 9, v9                               // 0000004B087C: 30341289
	v_add_co_ci_u32_e64 v13, null, v8, v13, vcc_lo             // 0000004B0880: D5207C0D 01AA1B08
	v_add3_u32 v21, v23, v21, 0x7fff                           // 0000004B0888: D6550015 03FE2B17 00007FFF
	v_mad_i64_i32 v[18:19], null, v18, s6, 0                   // 0000004B0894: D6FF7C12 02000D12
	.long 0x7e2e3999                                           // 0000004B089C: 7E2E3999
	.long 0x7f2e3981                                           // 0000004B08A0: 7F2E3981
	s_clause 0x1                                               // 0000004B08A4: BF850001
	global_store_d16_hi_b16 v[10:11], v20, off                 // 0000004B08A8: DC960000 007C140A
	global_store_d16_hi_b16 v[12:13], v21, off                 // 0000004B08B0: DC960000 007C150C
	v_lshl_add_u32 v13, v24, 2, v26                            // 0000004B08B8: D646000D 04690518
	.long 0xd73c000e                                           // 0000004B08C0: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000004B08C4: 02021C81
	.long 0x7e023996                                           // 0000004B08C8: 7E023996
	v_and_b32_e32 v20, 1, v23                                  // 0000004B08CC: 36282E81
	v_or_b32_e32 v23, s1, v9                                   // 0000004B08D0: 382E1201
	.long 0xd73c0009                                           // 0000004B08D4: D73C0009
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004B08D8: 02022481
	ds_load_2addr_stride64_b32 v[11:12], v13 offset1:64        // 0000004B08DC: D8E04000 0B00000D
	ds_load_2addr_stride64_b32 v[18:19], v13 offset0:128 offset1:192// 0000004B08E4: D8E0C080 1200000D
	.long 0xd7006a0e                                           // 0000004B08EC: D7006A0E
	v_cndmask_b32_e32 v1, v4, v14, vcc_lo                      // 0000004B08F0: 02021D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000004B08F4: BF870251
	v_add_co_ci_u32_e64 v15, null, v8, v15, vcc_lo             // 0000004B08F8: D5207C0F 01AA1F08
	v_and_b32_e32 v27, 1, v1                                   // 0000004B0900: 36360281
	v_add3_u32 v24, v25, v20, 0x7fff                           // 0000004B0904: D6550018 03FE2919 00007FFF
	v_mad_i64_i32 v[20:21], null, v23, s6, 0                   // 0000004B0910: D6FF7C14 02000D17
	.long 0xd7006a09                                           // 0000004B0918: D7006A09
	v_cndmask_b32_e32 v1, v4, v9, vcc_lo                       // 0000004B091C: 02021304
	v_add3_u32 v22, v22, v27, 0x7fff                           // 0000004B0920: D6550016 03FE3716 00007FFF
	v_add_co_ci_u32_e64 v10, null, v8, v10, vcc_lo             // 0000004B092C: D5207C0A 01AA1508
	global_store_d16_hi_b16 v[14:15], v24, off                 // 0000004B0934: DC960000 007C180E
	v_or_b32_e32 v15, 32, v23                                  // 0000004B093C: 381E2EA0
	v_or_b32_e32 v24, 64, v23                                  // 0000004B0940: 38302EC0
	.long 0xd73c000d                                           // 0000004B0944: D73C000D
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000004B0948: 02022881
	global_store_d16_hi_b16 v[9:10], v22, off                  // 0000004B094C: DC960000 007C1609
	.long 0xd7600002                                           // 0000004B0954: D7600002
	v_cndmask_b32_e32 v0, v17, v138, vcc_lo                    // 0000004B0958: 02011511
	v_mad_i64_i32 v[9:10], null, v15, s6, 0                    // 0000004B095C: D6FF7C09 02000D0F
	v_mad_i64_i32 v[20:21], null, v24, s6, 0                   // 0000004B0964: D6FF7C14 02000D18
	s_waitcnt lgkmcnt(0)                                       // 0000004B096C: BF89FC07
	v_dual_sub_f32 v15, v11, v12 :: v_dual_sub_f32 v24, v18, v19// 0000004B0970: C94A190B 0F182712
	v_add_f32_e32 v22, v11, v12                                // 0000004B0978: 062C190B
	v_add_f32_e32 v18, v18, v19                                // 0000004B097C: 06242712
	.long 0xd7600000                                           // 0000004B0980: D7600000
	v_cndmask_b32_e32 v0, v16, v138, vcc_lo                    // 0000004B0984: 02011510
	.long 0xd7600003                                           // 0000004B0988: D7600003
	v_cndmask_b32_e32 v0, v16, v154, vcc_lo                    // 0000004B098C: 02013510
	v_add_f32_e32 v19, v15, v24                                // 0000004B0990: 0626310F
	.long 0xd73c000b                                           // 0000004B0994: D73C000B
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000004B0998: 02022881
	v_add_f32_e32 v20, v22, v18                                // 0000004B099C: 06282516
	v_dual_sub_f32 v18, v22, v18 :: v_dual_sub_f32 v15, v15, v24// 0000004B09A0: C94A2516 120E310F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004B09A8: BF870224
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 0000004B09AC: 102626FF 3DB504F3
	v_lshlrev_b32_e32 v26, 9, v7                               // 0000004B09B4: 30340E89
	v_mul_f32_e32 v20, 0x3db504f3, v20                         // 0000004B09B8: 102828FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004B09C0: BF870214
	v_dual_mul_f32 v18, 0x3db504f3, v18 :: v_dual_mul_f32 v15, 0x3db504f3, v15// 0000004B09C4: C8C624FF 120E1EFF 3DB504F3
	v_mul_f32_e32 v21, s2, v19                                 // 0000004B09D0: 102A2602
	.long 0xd73c0009                                           // 0000004B09D4: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000004B09D8: 02021281
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004B09DC: BF870223
	v_dual_mul_f32 v24, s0, v20 :: v_dual_mul_f32 v25, s3, v18 // 0000004B09E0: C8C62800 18182403
	v_or_b32_e32 v18, 0x60, v23                                // 0000004B09E8: 38242EFF 00000060
	.long 0x7e023995                                           // 0000004B09F0: 7E023995
	v_xor_b32_e32 v23, v7, v3                                  // 0000004B09F4: 3A2E0707
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004B09F8: BF870004
	.long 0x7e283998                                           // 0000004B09FC: 7E283998
	.long 0x7f283981                                           // 0000004B0A00: 7F283981
	.long 0xd7600000                                           // 0000004B0A04: D7600000
	v_cndmask_b32_e32 v0, v17, v154, vcc_lo                    // 0000004B0A08: 02013511
	v_and_b32_e32 v22, 1, v1                                   // 0000004B0A0C: 362C0281
	v_lshl_add_u32 v23, v23, 2, v26                            // 0000004B0A10: D6460017 04690517
	v_mad_i64_i32 v[18:19], null, v18, s6, 0                   // 0000004B0A18: D6FF7C12 02000D12
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004B0A20: BF870214
	v_dual_mul_f32 v15, s0, v15 :: v_dual_and_b32 v26, 1, v20  // 0000004B0A24: C8E41E00 0F1A2881
	v_add3_u32 v28, v21, v22, 0x7fff                           // 0000004B0A2C: D655001C 03FE2D15 00007FFF
	ds_load_2addr_stride64_b32 v[20:21], v23 offset1:64        // 0000004B0A38: D8E04000 14000017
	ds_load_2addr_stride64_b32 v[22:23], v23 offset0:128 offset1:192// 0000004B0A40: D8E0C080 16000017
	.long 0x7e363999                                           // 0000004B0A48: 7E363999
	.long 0x7f363981                                           // 0000004B0A4C: 7F363981
	.long 0x7e02398f                                           // 0000004B0A50: 7E02398F
	.long 0xd7006a0d                                           // 0000004B0A54: D7006A0D
	v_cndmask_b32_e32 v1, v4, v13, vcc_lo                      // 0000004B0A58: 02021B04
	.long 0xd73c0012                                           // 0000004B0A5C: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004B0A60: 02022481
	v_add_co_ci_u32_e64 v14, null, v8, v14, vcc_lo             // 0000004B0A64: D5207C0E 01AA1D08
	.long 0xd7006a09                                           // 0000004B0A6C: D7006A09
	v_cndmask_b32_e32 v1, v4, v9, vcc_lo                       // 0000004B0A70: 02021304
	v_and_b32_e32 v27, 1, v27                                  // 0000004B0A74: 36363681
	v_and_b32_e32 v29, 1, v1                                   // 0000004B0A78: 363A0281
	v_add_co_ci_u32_e64 v10, null, v8, v10, vcc_lo             // 0000004B0A7C: D5207C0A 01AA1508
	.long 0xd7006a0b                                           // 0000004B0A84: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000004B0A88: 02021704
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004B0A8C: BF870001
	v_add_co_ci_u32_e64 v12, null, v8, v12, vcc_lo             // 0000004B0A90: D5207C0C 01AA1908
	.long 0xd7006a12                                           // 0000004B0A98: D7006A12
	v_cndmask_b32_e32 v1, v4, v18, vcc_lo                      // 0000004B0A9C: 02022504
	v_or_b32_e32 v7, s1, v7                                    // 0000004B0AA0: 380E0E01
	v_add3_u32 v26, v24, v26, 0x7fff                           // 0000004B0AA4: D655001A 03FE3518 00007FFF
	v_add3_u32 v27, v25, v27, 0x7fff                           // 0000004B0AB0: D655001B 03FE3719 00007FFF
	v_add3_u32 v15, v15, v29, 0x7fff                           // 0000004B0ABC: D655000F 03FE3B0F 00007FFF
	v_add_co_ci_u32_e64 v19, null, v8, v19, vcc_lo             // 0000004B0AC8: D5207C13 01AA2708
	s_clause 0x1                                               // 0000004B0AD0: BF850001
	global_store_d16_hi_b16 v[13:14], v26, off                 // 0000004B0AD4: DC960000 007C1A0D
	global_store_d16_hi_b16 v[9:10], v28, off                  // 0000004B0ADC: DC960000 007C1C09
	v_or_b32_e32 v13, 32, v7                                   // 0000004B0AE4: 381A0EA0
	s_clause 0x1                                               // 0000004B0AE8: BF850001
	global_store_d16_hi_b16 v[11:12], v27, off                 // 0000004B0AEC: DC960000 007C1B0B
	global_store_d16_hi_b16 v[18:19], v15, off                 // 0000004B0AF4: DC960000 007C0F12
	s_waitcnt lgkmcnt(1)                                       // 0000004B0AFC: BF89FC17
	v_sub_f32_e32 v15, v20, v21                                // 0000004B0B00: 081E2B14
	s_waitcnt lgkmcnt(0)                                       // 0000004B0B04: BF89FC07
	v_sub_f32_e32 v19, v22, v23                                // 0000004B0B08: 08262F16
	v_or_b32_e32 v28, s1, v5                                   // 0000004B0B0C: 38380A01
	v_add_f32_e32 v18, v20, v21                                // 0000004B0B10: 06242B14
	v_add_f32_e32 v20, v22, v23                                // 0000004B0B14: 06282F16
	v_mad_i64_i32 v[11:12], null, v13, s6, 0                   // 0000004B0B18: D6FF7C0B 02000D0D
	v_add_f32_e32 v13, v15, v19                                // 0000004B0B20: 061A270F
	.long 0xd7600000                                           // 0000004B0B24: D7600000
	v_cndmask_b32_e32 v0, v16, v139, vcc_lo                    // 0000004B0B28: 02011710
	.long 0xd7600002                                           // 0000004B0B2C: D7600002
	v_cndmask_b32_e32 v0, v17, v139, vcc_lo                    // 0000004B0B30: 02011711
	v_add_f32_e32 v14, v18, v20                                // 0000004B0B34: 061C2912
	v_mad_i64_i32 v[24:25], null, v7, s6, 0                    // 0000004B0B38: D6FF7C18 02000D07
	v_dual_mul_f32 v13, 0x3db504f3, v13 :: v_dual_sub_f32 v18, v18, v20// 0000004B0B40: C8CA1AFF 0D122912 3DB504F3
	v_or_b32_e32 v21, 64, v7                                   // 0000004B0B4C: 382A0EC0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004B0B50: BF870224
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 0000004B0B54: 101C1CFF 3DB504F3
	.long 0xd7600003                                           // 0000004B0B5C: D7600003
	v_cndmask_b32_e32 v0, v16, v155, vcc_lo                    // 0000004B0B60: 02013710
	v_dual_mul_f32 v22, s2, v13 :: v_dual_sub_f32 v15, v15, v19// 0000004B0B64: C8CA1A02 160E270F
	.long 0x7f263981                                           // 0000004B0B6C: 7F263981
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004B0B70: BF870224
	v_mul_f32_e32 v23, s0, v14                                 // 0000004B0B74: 102E1C00
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 0000004B0B78: 102424FF 3DB504F3
	.long 0x7e023996                                           // 0000004B0B80: 7E023996
	.long 0xd73c0009                                           // 0000004B0B84: D73C0009
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000004B0B88: 02023081
	.long 0xd73c000b                                           // 0000004B0B8C: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000004B0B90: 02021681
	.long 0x7e263997                                           // 0000004B0B94: 7E263997
	v_mad_i64_i32 v[13:14], null, v21, s6, 0                   // 0000004B0B98: D6FF7C0D 02000D15
	v_dual_mul_f32 v21, s3, v18 :: v_dual_and_b32 v20, 1, v1   // 0000004B0BA0: C8E42403 15140281
	.long 0xd7006a09                                           // 0000004B0BA8: D7006A09
	v_cndmask_b32_e32 v1, v4, v9, vcc_lo                       // 0000004B0BAC: 02021304
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004B0BB0: BF870004
	v_and_b32_e32 v19, 1, v19                                  // 0000004B0BB4: 36262681
	.long 0xd7600000                                           // 0000004B0BB8: D7600000
	v_cndmask_b32_e32 v0, v17, v155, vcc_lo                    // 0000004B0BBC: 02013711
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 0000004B0BC0: 101E1EFF 3DB504F3
	v_add_co_ci_u32_e64 v10, null, v8, v10, vcc_lo             // 0000004B0BC8: D5207C0A 01AA1508
	.long 0xd7006a0b                                           // 0000004B0BD0: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000004B0BD4: 02021704
	v_add3_u32 v20, v22, v20, 0x7fff                           // 0000004B0BD8: D6550014 03FE2916 00007FFF
	v_add3_u32 v22, v23, v19, 0x7fff                           // 0000004B0BE4: D6550016 03FE2717 00007FFF
	.long 0x7e2e3995                                           // 0000004B0BF0: 7E2E3995
	.long 0x7f2e3981                                           // 0000004B0BF4: 7F2E3981
	v_xor_b32_e32 v24, v6, v3                                  // 0000004B0BF8: 3A300706
	v_lshlrev_b32_e32 v25, 9, v6                               // 0000004B0BFC: 30320C89
	v_add_co_ci_u32_e64 v12, null, v8, v12, vcc_lo             // 0000004B0C00: D5207C0C 01AA1908
	v_mul_f32_e32 v15, s0, v15                                 // 0000004B0C08: 101E1E00
	v_or_b32_e32 v7, 0x60, v7                                  // 0000004B0C0C: 380E0EFF 00000060
	s_clause 0x1                                               // 0000004B0C14: BF850001
	global_store_d16_hi_b16 v[9:10], v22, off                  // 0000004B0C18: DC960000 007C1609
	global_store_d16_hi_b16 v[11:12], v20, off                 // 0000004B0C20: DC960000 007C140B
	v_lshl_add_u32 v11, v24, 2, v25                            // 0000004B0C28: D646000B 04650518
	v_and_b32_e32 v12, 1, v23                                  // 0000004B0C30: 36182E81
	.long 0x7e02398f                                           // 0000004B0C34: 7E02398F
	v_mad_i64_i32 v[18:19], null, v7, s6, 0                    // 0000004B0C38: D6FF7C12 02000D07
	.long 0xd73c000d                                           // 0000004B0C40: D73C000D
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000004B0C44: 02021A81
	ds_load_2addr_stride64_b32 v[9:10], v11 offset1:64         // 0000004B0C48: D8E04000 0900000B
	v_add3_u32 v21, v21, v12, 0x7fff                           // 0000004B0C50: D6550015 03FE1915 00007FFF
	ds_load_2addr_stride64_b32 v[11:12], v11 offset0:128 offset1:192// 0000004B0C5C: D8E0C080 0B00000B
	v_and_b32_e32 v7, 1, v1                                    // 0000004B0C64: 360E0281
	v_or_b32_e32 v20, s1, v6                                   // 0000004B0C68: 38280C01
	.long 0xd7006a0d                                           // 0000004B0C6C: D7006A0D
	v_cndmask_b32_e32 v1, v4, v13, vcc_lo                      // 0000004B0C70: 02021B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004B0C74: BF870211
	v_add_co_ci_u32_e64 v14, null, v8, v14, vcc_lo             // 0000004B0C78: D5207C0E 01AA1D08
	v_add3_u32 v15, v15, v7, 0x7fff                            // 0000004B0C80: D655000F 03FE0F0F 00007FFF
	.long 0xd73c0006                                           // 0000004B0C8C: D73C0006
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004B0C90: 02022481
	v_mad_i64_i32 v[18:19], null, v20, s6, 0                   // 0000004B0C94: D6FF7C12 02000D14
	v_or_b32_e32 v22, 64, v20                                  // 0000004B0C9C: 382C28C0
	global_store_d16_hi_b16 v[13:14], v21, off                 // 0000004B0CA0: DC960000 007C150D
	v_or_b32_e32 v21, 32, v20                                  // 0000004B0CA8: 382A28A0
	.long 0xd7600002                                           // 0000004B0CAC: D7600002
	v_cndmask_b32_e32 v0, v17, v140, vcc_lo                    // 0000004B0CB0: 02011911
	.long 0xd7006a06                                           // 0000004B0CB4: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000004B0CB8: 02020D04
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004B0CBC: BF870001
	v_add_co_ci_u32_e64 v7, null, v8, v7, vcc_lo               // 0000004B0CC0: D5207C07 01AA0F08
	.long 0xd73c000d                                           // 0000004B0CC8: D73C000D
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004B0CCC: 02022481
	v_mad_i64_i32 v[18:19], null, v22, s6, 0                   // 0000004B0CD0: D6FF7C12 02000D16
	s_waitcnt lgkmcnt(0)                                       // 0000004B0CD8: BF89FC07
	v_sub_f32_e32 v22, v11, v12                                // 0000004B0CDC: 082C190B
	global_store_d16_hi_b16 v[6:7], v15, off                   // 0000004B0CE0: DC960000 007C0F06
	v_sub_f32_e32 v15, v9, v10                                 // 0000004B0CE8: 081E1509
	v_mad_i64_i32 v[6:7], null, v21, s6, 0                     // 0000004B0CEC: D6FF7C06 02000D15
	v_add_f32_e32 v21, v9, v10                                 // 0000004B0CF4: 062A1509
	v_add_f32_e32 v11, v11, v12                                // 0000004B0CF8: 0616190B
	.long 0xd7600000                                           // 0000004B0CFC: D7600000
	v_cndmask_b32_e32 v0, v16, v140, vcc_lo                    // 0000004B0D00: 02011910
	v_add_f32_e32 v12, v15, v22                                // 0000004B0D04: 06182D0F
	.long 0xd73c0009                                           // 0000004B0D08: D73C0009
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004B0D0C: 02022481
	.long 0xd7600003                                           // 0000004B0D10: D7600003
	v_cndmask_b32_e32 v0, v16, v156, vcc_lo                    // 0000004B0D14: 02013910
	v_add_f32_e32 v18, v21, v11                                // 0000004B0D18: 06241715
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004B0D1C: BF8701B4
	v_dual_sub_f32 v11, v21, v11 :: v_dual_mul_f32 v12, 0x3db504f3, v12// 0000004B0D20: C9461715 0B0C18FF 3DB504F3
	v_lshlrev_b32_e32 v24, 9, v5                               // 0000004B0D2C: 30300A89
	.long 0xd73c0006                                           // 0000004B0D30: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000004B0D34: 02020C81
	v_dual_mul_f32 v18, 0x3db504f3, v18 :: v_dual_mul_f32 v11, 0x3db504f3, v11// 0000004B0D38: C8C624FF 120A16FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004B0D44: BF8701A4
	v_dual_mul_f32 v19, s2, v12 :: v_dual_sub_f32 v12, v15, v22// 0000004B0D48: C8CA1802 130C2D0F
	.long 0x7f323981                                           // 0000004B0D50: 7F323981
	v_mul_f32_e32 v15, s0, v18                                 // 0000004B0D54: 101E2400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004B0D58: BF870214
	v_mul_f32_e32 v23, s3, v11                                 // 0000004B0D5C: 102E1603
	.long 0x7e023993                                           // 0000004B0D60: 7E023993
	v_or_b32_e32 v11, 0x60, v20                                // 0000004B0D64: 381628FF 00000060
	v_xor_b32_e32 v20, v5, v3                                  // 0000004B0D6C: 3A280705
	.long 0xd7600000                                           // 0000004B0D70: D7600000
	v_cndmask_b32_e32 v0, v17, v156, vcc_lo                    // 0000004B0D74: 02013911
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 0000004B0D78: 101818FF 3DB504F3
	.long 0x7e24398f                                           // 0000004B0D80: 7E24398F
	.long 0x7f243981                                           // 0000004B0D84: 7F243981
	v_and_b32_e32 v21, 1, v1                                   // 0000004B0D88: 362A0281
	v_lshl_add_u32 v20, v20, 2, v24                            // 0000004B0D8C: D6460014 04610514
	v_mul_f32_e32 v22, s0, v12                                 // 0000004B0D94: 102C1800
	v_mad_i64_i32 v[11:12], null, v11, s6, 0                   // 0000004B0D98: D6FF7C0B 02000D0B
	v_and_b32_e32 v24, 1, v18                                  // 0000004B0DA0: 36302481
	v_add3_u32 v26, v19, v21, 0x7fff                           // 0000004B0DA4: D655001A 03FE2B13 00007FFF
	ds_load_2addr_stride64_b32 v[18:19], v20 offset1:64        // 0000004B0DB0: D8E04000 12000014
	ds_load_2addr_stride64_b32 v[20:21], v20 offset0:128 offset1:192// 0000004B0DB8: D8E0C080 14000014
	.long 0x7e323997                                           // 0000004B0DC0: 7E323997
	.long 0x7e023996                                           // 0000004B0DC4: 7E023996
	.long 0xd7006a0d                                           // 0000004B0DC8: D7006A0D
	v_cndmask_b32_e32 v1, v4, v13, vcc_lo                      // 0000004B0DCC: 02021B04
	.long 0xd73c000b                                           // 0000004B0DD0: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000004B0DD4: 02021681
	v_add_co_ci_u32_e64 v14, null, v8, v14, vcc_lo             // 0000004B0DD8: D5207C0E 01AA1D08
	.long 0xd7006a06                                           // 0000004B0DE0: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000004B0DE4: 02020D04
	v_and_b32_e32 v25, 1, v25                                  // 0000004B0DE8: 36323281
	v_add3_u32 v5, v15, v24, 0x7fff                            // 0000004B0DEC: D6550005 03FE310F 00007FFF
	v_add_co_ci_u32_e64 v7, null, v8, v7, vcc_lo               // 0000004B0DF8: D5207C07 01AA0F08
	v_and_b32_e32 v27, 1, v1                                   // 0000004B0E00: 36360281
	.long 0xd7006a09                                           // 0000004B0E04: D7006A09
	v_cndmask_b32_e32 v1, v4, v9, vcc_lo                       // 0000004B0E08: 02021304
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004B0E0C: BF870001
	v_add_co_ci_u32_e64 v10, null, v8, v10, vcc_lo             // 0000004B0E10: D5207C0A 01AA1508
	.long 0xd7006a0b                                           // 0000004B0E18: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000004B0E1C: 02021704
	v_add3_u32 v24, v23, v25, 0x7fff                           // 0000004B0E20: D6550018 03FE3317 00007FFF
	s_clause 0x1                                               // 0000004B0E2C: BF850001
	global_store_d16_hi_b16 v[13:14], v5, off                  // 0000004B0E30: DC960000 007C050D
	global_store_d16_hi_b16 v[6:7], v26, off                   // 0000004B0E38: DC960000 007C1A06
	v_add_nc_u32_e32 v7, 32, v28                               // 0000004B0E40: 4A0E38A0
	v_add3_u32 v15, v22, v27, 0x7fff                           // 0000004B0E44: D655000F 03FE3716 00007FFF
	v_add_co_ci_u32_e64 v12, null, v8, v12, vcc_lo             // 0000004B0E50: D5207C0C 01AA1908
	s_clause 0x1                                               // 0000004B0E58: BF850001
	global_store_d16_hi_b16 v[9:10], v24, off                  // 0000004B0E5C: DC960000 007C1809
	global_store_d16_hi_b16 v[11:12], v15, off                 // 0000004B0E64: DC960000 007C0F0B
	v_mad_i64_i32 v[9:10], null, v7, s6, 0                     // 0000004B0E6C: D6FF7C09 02000D07
	s_waitcnt lgkmcnt(1)                                       // 0000004B0E74: BF89FC17
	v_sub_f32_e32 v7, v18, v19                                 // 0000004B0E78: 080E2712
	s_waitcnt lgkmcnt(0)                                       // 0000004B0E7C: BF89FC07
	v_dual_add_f32 v13, v18, v19 :: v_dual_sub_f32 v14, v20, v21// 0000004B0E80: C90A2712 0D0E2B14
	v_add_f32_e32 v15, v20, v21                                // 0000004B0E88: 061E2B14
	v_mad_i64_i32 v[22:23], null, v28, s6, 0                   // 0000004B0E8C: D6FF7C16 02000D1C
	.long 0xd7600000                                           // 0000004B0E94: D7600000
	v_cndmask_b32_e32 v0, v16, v141, vcc_lo                    // 0000004B0E98: 02011B10
	.long 0xd7600002                                           // 0000004B0E9C: D7600002
	v_cndmask_b32_e32 v0, v17, v141, vcc_lo                    // 0000004B0EA0: 02011B11
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004B0EA4: BF870244
	v_dual_add_f32 v18, v7, v14 :: v_dual_add_f32 v19, v13, v15// 0000004B0EA8: C9081D07 12121F0D
	v_sub_f32_e32 v13, v13, v15                                // 0000004B0EB0: 081A1F0D
	.long 0xd7600003                                           // 0000004B0EB4: D7600003
	v_cndmask_b32_e32 v0, v16, v157, vcc_lo                    // 0000004B0EB8: 02013B10
	v_sub_f32_e32 v7, v7, v14                                  // 0000004B0EBC: 080E1D07
	v_dual_mul_f32 v18, 0x3db504f3, v18 :: v_dual_mul_f32 v19, 0x3db504f3, v19// 0000004B0EC0: C8C624FF 121226FF 3DB504F3
	.long 0xd73c0005                                           // 0000004B0ECC: D73C0005
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000004B0ED0: 02022C81
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 0000004B0ED4: 101A1AFF 3DB504F3
	.long 0x7f1c3981                                           // 0000004B0EDC: 7F1C3981
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004B0EE0: BF870224
	v_mul_f32_e32 v22, s2, v18                                 // 0000004B0EE4: 102C2402
	v_dual_mul_f32 v18, s0, v19 :: v_dual_lshlrev_b32 v19, 9, v2// 0000004B0EE8: C8E22600 12120489
	v_mul_f32_e32 v23, s3, v13                                 // 0000004B0EF0: 102E1A03
	.long 0x7f283981                                           // 0000004B0EF4: 7F283981
	v_add_nc_u32_e32 v21, 0x60, v28                            // 0000004B0EF8: 4A2A38FF 00000060
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004B0F00: BF870244
	.long 0x7e1c3992                                           // 0000004B0F04: 7E1C3992
	.long 0xd7006a05                                           // 0000004B0F08: D7006A05
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 0000004B0F0C: 02020B04
	.long 0x7e283997                                           // 0000004B0F10: 7E283997
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 0000004B0F14: D5207C06 01AA0D08
	v_and_b32_e32 v13, 1, v14                                  // 0000004B0F1C: 361A1C81
	v_xor_b32_e32 v14, v2, v3                                  // 0000004B0F20: 3A1C0702
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004B0F24: BF870004
	v_and_b32_e32 v26, 1, v20                                  // 0000004B0F28: 36342881
	.long 0xd7600000                                           // 0000004B0F2C: D7600000
	v_cndmask_b32_e32 v0, v17, v157, vcc_lo                    // 0000004B0F30: 02013B11
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 0000004B0F34: 100E0EFF 3DB504F3
	v_add3_u32 v25, v18, v13, 0x7fff                           // 0000004B0F3C: D6550019 03FE1B12 00007FFF
	v_lshl_add_u32 v24, v14, 2, v19                            // 0000004B0F48: D6460018 044D050E
	v_mad_i64_i32 v[13:14], null, v21, s6, 0                   // 0000004B0F50: D6FF7C0D 02000D15
	ds_load_2addr_stride64_b32 v[18:19], v24 offset1:64        // 0000004B0F58: D8E04000 12000018
	ds_load_2addr_stride64_b32 v[20:21], v24 offset0:128 offset1:192// 0000004B0F60: D8E0C080 14000018
	global_store_d16_hi_b16 v[5:6], v25, off                   // 0000004B0F68: DC960000 007C1905
	v_or_b32_e32 v11, 64, v28                                  // 0000004B0F70: 381638C0
	v_mul_f32_e32 v7, s0, v7                                   // 0000004B0F74: 100E0E00
	.long 0xd73c0005                                           // 0000004B0F78: D73C0005
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000004B0F7C: 02021A81
	.long 0xd7600000                                           // 0000004B0F80: D7600000
	v_cndmask_b32_e32 v0, v16, v142, vcc_lo                    // 0000004B0F84: 02011D10
	.long 0xd73c0009                                           // 0000004B0F88: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000004B0F8C: 02021281
	v_mad_i64_i32 v[11:12], null, v11, s6, 0                   // 0000004B0F90: D6FF7C0B 02000D0B
	.long 0xd7600002                                           // 0000004B0F98: D7600002
	v_cndmask_b32_e32 v0, v17, v142, vcc_lo                    // 0000004B0F9C: 02011D11
	v_or_b32_e32 v2, s1, v2                                    // 0000004B0FA0: 38040401
	v_xor_b32_e32 v3, v0, v3                                   // 0000004B0FA4: 3A060700
	.long 0xd7600003                                           // 0000004B0FA8: D7600003
	v_cndmask_b32_e32 v0, v17, v159, vcc_lo                    // 0000004B0FAC: 02013F11
	.long 0xd7006a09                                           // 0000004B0FB0: D7006A09
	v_cndmask_b32_e32 v1, v4, v9, vcc_lo                       // 0000004B0FB4: 02021304
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004B0FB8: BF870001
	v_add_co_ci_u32_e64 v10, null, v8, v10, vcc_lo             // 0000004B0FBC: D5207C0A 01AA1508
	.long 0xd73c000b                                           // 0000004B0FC4: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000004B0FC8: 02021681
	s_waitcnt lgkmcnt(1)                                       // 0000004B0FCC: BF89FC17
	v_sub_f32_e32 v13, v18, v19                                // 0000004B0FD0: 081A2712
	v_add_f32_e32 v14, v18, v19                                // 0000004B0FD4: 061C2712
	s_waitcnt lgkmcnt(0)                                       // 0000004B0FD8: BF89FC07
	v_add_f32_e32 v18, v20, v21                                // 0000004B0FDC: 06242B14
	.long 0xd7006a0b                                           // 0000004B0FE0: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000004B0FE4: 02021704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004B0FE8: BF870191
	v_add_co_ci_u32_e64 v12, null, v8, v12, vcc_lo             // 0000004B0FEC: D5207C0C 01AA1908
	v_add_f32_e32 v19, v14, v18                                // 0000004B0FF4: 0626250E
	.long 0xd7006a05                                           // 0000004B0FF8: D7006A05
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 0000004B0FFC: 02020B04
	v_add3_u32 v23, v23, v26, 0x7fff                           // 0000004B1000: D6550017 03FE3517 00007FFF
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 0000004B100C: D5207C06 01AA0D08
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004B1014: BF870094
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 0000004B1018: 102626FF 3DB504F3
	v_mul_f32_e32 v19, s0, v19                                 // 0000004B1020: 10262600
	.long 0x7e023996                                           // 0000004B1024: 7E023996
	.long 0xd7600000                                           // 0000004B1028: D7600000
	v_cndmask_b32_e32 v0, v16, v158, vcc_lo                    // 0000004B102C: 02013D10
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004B1030: BF870122
	v_and_b32_e32 v15, 1, v1                                   // 0000004B1034: 361E0281
	.long 0x7e023987                                           // 0000004B1038: 7E023987
	v_add3_u32 v15, v22, v15, 0x7fff                           // 0000004B103C: D655000F 03FE1F16 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004B1048: BF870002
	v_and_b32_e32 v22, 1, v1                                   // 0000004B104C: 362C0281
	global_store_d16_hi_b16 v[9:10], v15, off                  // 0000004B1050: DC960000 007C0F09
	v_add3_u32 v7, v7, v22, 0x7fff                             // 0000004B1058: D6550007 03FE2D07 00007FFF
	v_sub_f32_e32 v15, v20, v21                                // 0000004B1064: 081E2B14
	global_store_d16_hi_b16 v[11:12], v23, off                 // 0000004B1068: DC960000 007C170B
	.long 0x7e283993                                           // 0000004B1070: 7E283993
	.long 0x7f283981                                           // 0000004B1074: 7F283981
	global_store_d16_hi_b16 v[5:6], v7, off                    // 0000004B1078: DC960000 007C0705
	v_add_f32_e32 v7, v13, v15                                 // 0000004B1080: 060E1F0D
	v_sub_f32_e32 v13, v13, v15                                // 0000004B1084: 081A1F0D
	v_add_nc_u32_e32 v11, 32, v2                               // 0000004B1088: 4A1604A0
	v_mad_i64_i32 v[9:10], null, v2, s6, 0                     // 0000004B108C: D6FF7C09 02000D02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004B1094: BF870214
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 0000004B1098: 100E0EFF 3DB504F3
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 0000004B10A0: 101A1AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004B10A8: BF870194
	v_mad_i64_i32 v[11:12], null, v11, s6, 0                   // 0000004B10AC: D6FF7C0B 02000D0B
	v_mul_f32_e32 v7, s2, v7                                   // 0000004B10B4: 100E0E02
	.long 0xd7600002                                           // 0000004B10B8: D7600002
	v_cndmask_b32_e32 v0, v17, v158, vcc_lo                    // 0000004B10BC: 02013D11
	v_sub_f32_e32 v14, v14, v18                                // 0000004B10C0: 081C250E
	.long 0xd73c0005                                           // 0000004B10C4: D73C0005
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000004B10C8: 02021281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004B10CC: BF870194
	.long 0x7e023987                                           // 0000004B10D0: 7E023987
	v_dual_mul_f32 v23, s2, v13 :: v_dual_mul_f32 v14, 0x3db504f3, v14// 0000004B10D4: C8C61A02 170E1CFF 3DB504F3
	v_lshlrev_b32_e32 v13, 9, v0                               // 0000004B10E0: 301A0089
	v_and_b32_e32 v18, 1, v20                                  // 0000004B10E4: 36242881
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004B10E8: BF870004
	v_and_b32_e32 v15, 1, v1                                   // 0000004B10EC: 361E0281
	.long 0xd73c0009                                           // 0000004B10F0: D73C0009
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000004B10F4: 02021681
	v_or_b32_e32 v11, 64, v2                                   // 0000004B10F8: 381604C0
	v_lshl_add_u32 v20, v3, 2, v13                             // 0000004B10FC: D6460014 04350503
	v_or_b32_e32 v0, s1, v0                                    // 0000004B1104: 38000001
	v_add3_u32 v7, v7, v15, 0x7fff                             // 0000004B1108: D6550007 03FE1F07 00007FFF
	v_mul_f32_e32 v15, s0, v14                                 // 0000004B1114: 101E1C00
	.long 0x7f1c3981                                           // 0000004B1118: 7F1C3981
	v_mad_i64_i32 v[11:12], null, v11, s6, 0                   // 0000004B111C: D6FF7C0B 02000D0B
	.long 0xd7006a05                                           // 0000004B1124: D7006A05
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 0000004B1128: 02020B04
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004B112C: BF8701B4
	.long 0x7e1c398f                                           // 0000004B1130: 7E1C398F
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 0000004B1134: D5207C06 01AA0D08
	.long 0xd7006a09                                           // 0000004B113C: D7006A09
	v_cndmask_b32_e32 v1, v4, v9, vcc_lo                       // 0000004B1140: 02021304
	v_and_b32_e32 v21, 1, v14                                  // 0000004B1144: 362A1C81
	ds_load_2addr_stride64_b32 v[13:14], v20 offset1:64        // 0000004B1148: D8E04000 0D000014
	.long 0xd73c000b                                           // 0000004B1150: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000004B1154: 02021681
	v_add_co_ci_u32_e64 v10, null, v8, v10, vcc_lo             // 0000004B1158: D5207C0A 01AA1508
	v_add3_u32 v15, v15, v21, 0x7fff                           // 0000004B1160: D655000F 03FE2B0F 00007FFF
	ds_load_2addr_stride64_b32 v[20:21], v20 offset0:128 offset1:192// 0000004B116C: D8E0C080 14000014
	v_add3_u32 v22, v19, v18, 0x7fff                           // 0000004B1174: D6550016 03FE2513 00007FFF
	.long 0xd7006a0b                                           // 0000004B1180: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000004B1184: 02021704
	v_mad_i64_i32 v[18:19], null, v0, s6, 0                    // 0000004B1188: D6FF7C12 02000D00
	v_add_co_ci_u32_e64 v12, null, v8, v12, vcc_lo             // 0000004B1190: D5207C0C 01AA1908
	.long 0x7e023997                                           // 0000004B1198: 7E023997
	s_clause 0x1                                               // 0000004B119C: BF850001
	global_store_d16_hi_b16 v[5:6], v22, off                   // 0000004B11A0: DC960000 007C1605
	global_store_d16_hi_b16 v[9:10], v7, off                   // 0000004B11A8: DC960000 007C0709
	v_add_nc_u32_e32 v9, 32, v0                                // 0000004B11B0: 4A1200A0
	global_store_d16_hi_b16 v[11:12], v15, off                 // 0000004B11B4: DC960000 007C0F0B
	.long 0xd7600000                                           // 0000004B11BC: D7600000
	v_cndmask_b32_e32 v0, v16, v143, vcc_lo                    // 0000004B11C0: 02011F10
	v_and_b32_e32 v24, 1, v1                                   // 0000004B11C4: 36300281
	.long 0xd73c0005                                           // 0000004B11C8: D73C0005
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004B11CC: 02022481
	.long 0xd7600001                                           // 0000004B11D0: D7600001
	v_cndmask_b32_e32 v0, v17, v143, vcc_lo                    // 0000004B11D4: 02011F11
	s_waitcnt lgkmcnt(1)                                       // 0000004B11D8: BF89FC17
	v_sub_f32_e32 v15, v13, v14                                // 0000004B11DC: 081E1D0D
	v_add_f32_e32 v13, v13, v14                                // 0000004B11E0: 061A1D0D
	v_or_b32_e32 v11, 64, v0                                   // 0000004B11E4: 381600C0
	.long 0xd7600002                                           // 0000004B11E8: D7600002
	v_cndmask_b32_e32 v0, v16, v159, vcc_lo                    // 0000004B11EC: 02013F10
	v_add_nc_u32_e32 v0, 0x60, v0                              // 0000004B11F0: 4A0000FF 00000060
	s_waitcnt lgkmcnt(0)                                       // 0000004B11F8: BF89FC07
	v_sub_f32_e32 v14, v20, v21                                // 0000004B11FC: 081C2B14
	v_add_f32_e32 v18, v20, v21                                // 0000004B1200: 06242B14
	v_mad_i64_i32 v[9:10], null, v9, s6, 0                     // 0000004B1204: D6FF7C09 02000D09
	v_mad_i64_i32 v[11:12], null, v11, s6, 0                   // 0000004B120C: D6FF7C0B 02000D0B
	.long 0x7f223981                                           // 0000004B1214: 7F223981
	v_add_f32_e32 v19, v15, v14                                // 0000004B1218: 06261D0F
	v_add_f32_e32 v20, v13, v18                                // 0000004B121C: 0628250D
	v_sub_f32_e32 v13, v13, v18                                // 0000004B1220: 081A250D
	v_sub_f32_e32 v14, v15, v14                                // 0000004B1224: 081C1D0F
	.long 0x7f2a3981                                           // 0000004B1228: 7F2A3981
	v_mul_f32_e32 v16, 0x3db504f3, v19                         // 0000004B122C: 102026FF 3DB504F3
	v_add_nc_u32_e32 v2, 0x60, v2                              // 0000004B1234: 4A0404FF 00000060
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 0000004B123C: 101A1AFF 3DB504F3
	v_dual_mul_f32 v19, 0x3db504f3, v20 :: v_dual_mul_f32 v14, 0x3db504f3, v14// 0000004B1244: C8C628FF 130E1CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004B1250: BF870214
	v_mul_f32_e32 v15, s1, v16                                 // 0000004B1254: 101E2001
	v_mad_i64_i32 v[2:3], null, v2, s6, 0                      // 0000004B1258: D6FF7C02 02000D02
	.long 0xd73c0009                                           // 0000004B1260: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000004B1264: 02021281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004B1268: BF870214
	v_dual_mul_f32 v16, s0, v19 :: v_dual_mul_f32 v19, s2, v13 // 0000004B126C: C8C62600 10121A02
	.long 0x7e02398f                                           // 0000004B1274: 7E02398F
	.long 0xd73c000b                                           // 0000004B1278: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000004B127C: 02021681
	v_add3_u32 v7, v23, v24, 0x7fff                            // 0000004B1280: D6550007 03FE3117 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004B128C: BF870004
	.long 0x7e223990                                           // 0000004B1290: 7E223990
	v_mul_f32_e32 v18, s3, v14                                 // 0000004B1294: 10241C03
	.long 0xd73c0002                                           // 0000004B1298: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000004B129C: 02020481
	v_mad_i64_i32 v[13:14], null, v0, s6, 0                    // 0000004B12A0: D6FF7C0D 02000D00
	v_and_b32_e32 v20, 1, v1                                   // 0000004B12A8: 36280281
	v_and_b32_e32 v17, 1, v17                                  // 0000004B12AC: 36222281
	.long 0x7e023992                                           // 0000004B12B0: 7E023992
	.long 0x7e2a3993                                           // 0000004B12B4: 7E2A3993
	.long 0xd7006a02                                           // 0000004B12B8: D7006A02
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000004B12BC: 02020504
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004B12C0: BF870001
	v_add_co_ci_u32_e64 v3, null, v8, v3, vcc_lo               // 0000004B12C4: D5207C03 01AA0708
	.long 0xd7006a05                                           // 0000004B12CC: D7006A05
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 0000004B12D0: 02020B04
	v_and_b32_e32 v22, 1, v1                                   // 0000004B12D4: 362C0281
	.long 0xd73c0000                                           // 0000004B12D8: D73C0000
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000004B12DC: 02021A81
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 0000004B12E0: D5207C06 01AA0D08
	.long 0xd7006a09                                           // 0000004B12E8: D7006A09
	v_cndmask_b32_e32 v1, v4, v9, vcc_lo                       // 0000004B12EC: 02021304
	v_and_b32_e32 v21, 1, v21                                  // 0000004B12F0: 362A2A81
	v_add_co_ci_u32_e64 v10, null, v8, v10, vcc_lo             // 0000004B12F4: D5207C0A 01AA1508
	.long 0xd7006a0b                                           // 0000004B12FC: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000004B1300: 02021704
	v_add3_u32 v14, v16, v17, 0x7fff                           // 0000004B1304: D655000E 03FE2310 00007FFF
	v_add_co_ci_u32_e64 v12, null, v8, v12, vcc_lo             // 0000004B1310: D5207C0C 01AA1908
	v_add3_u32 v13, v15, v20, 0x7fff                           // 0000004B1318: D655000D 03FE290F 00007FFF
	.long 0xd7006a00                                           // 0000004B1324: D7006A00
	v_cndmask_b32_e32 v1, v4, v0, vcc_lo                       // 0000004B1328: 02020104
	v_add3_u32 v16, v19, v21, 0x7fff                           // 0000004B132C: D6550010 03FE2B13 00007FFF
	v_add3_u32 v15, v18, v22, 0x7fff                           // 0000004B1338: D655000F 03FE2D12 00007FFF
	v_add_co_ci_u32_e64 v1, null, v8, v1, vcc_lo               // 0000004B1344: D5207C01 01AA0308
	s_clause 0x4                                               // 0000004B134C: BF850004
	global_store_d16_hi_b16 v[2:3], v7, off                    // 0000004B1350: DC960000 007C0702
	global_store_d16_hi_b16 v[5:6], v14, off                   // 0000004B1358: DC960000 007C0E05
	global_store_d16_hi_b16 v[9:10], v13, off                  // 0000004B1360: DC960000 007C0D09
	global_store_d16_hi_b16 v[11:12], v16, off                 // 0000004B1368: DC960000 007C100B
	global_store_d16_hi_b16 v[0:1], v15, off                   // 0000004B1370: DC960000 007C0F00
	s_nop 0                                                    // 0000004B1378: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000004B137C: BFB60003
	s_endpgm                                                   // 0000004B1380: BFB00000
		...

