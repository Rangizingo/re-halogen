00000000002bc400 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 0000002BC400: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000002BC404: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 0000002BC40C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 0000002BC414: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 0000002BC41C: F4000180 F8000118
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000002BC424: 32040082
	v_and_b32_e32 v15, 31, v0                                  // 0000002BC428: 361E009F
	v_mov_b32_e32 v17, 0                                       // 0000002BC42C: 7E220280
	s_load_b128 s[12:15], s[0:1], 0x128                        // 0000002BC430: F4080300 F8000128
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002BC438: BF870003
	v_and_b32_e32 v2, 60, v2                                   // 0000002BC43C: 360404BC
	s_waitcnt lgkmcnt(0)                                       // 0000002BC440: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000002BC444: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000002BC448: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 0000002BC44C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 0000002BC450: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BC454: BF870009
	s_and_b32 s4, s7, s4                                       // 0000002BC458: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000002BC45C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000002BC460: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000002BC468: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 0000002BC46C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 0000002BC470: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BC474: BF870009
	s_and_b32 s4, s7, s5                                       // 0000002BC478: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000002BC47C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000002BC480: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000002BC484: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000002BC488: BF030602
	v_and_b32_e32 v1, 15, v0                                   // 0000002BC48C: 3602008F
	s_cselect_b32 s6, -1, 0                                    // 0000002BC490: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BC494: BF870009
	s_and_b32 s3, s3, s6                                       // 0000002BC498: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000002BC49C: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000002BC4A0: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000002BC4A4: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000002BC4A8: 98030483
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002BC4AC: 30020282
	s_mulk_i32 s3, 0x48                                        // 0000002BC4B0: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BC4B4: BF870009
	s_add_u32 s16, s0, s3                                      // 0000002BC4B8: 80100300
	s_addc_u32 s17, s1, 0                                      // 0000002BC4BC: 82118001
	s_clause 0x1                                               // 0000002BC4C0: BF850001
	s_load_b64 s[18:19], s[16:17], null                        // 0000002BC4C4: F4040488 F8000000
	s_load_b256 s[4:11], s[16:17], 0x18                        // 0000002BC4CC: F40C0108 F8000018
	s_waitcnt lgkmcnt(0)                                       // 0000002BC4D4: BF89FC07
	s_clause 0x1                                               // 0000002BC4D8: BF850001
	global_load_b32 v1, v1, s[18:19]                           // 0000002BC4DC: DC520000 01120001
	global_load_b32 v2, v2, s[18:19]                           // 0000002BC4E4: DC520000 02120002
	.long 0xd4510014                                           // 0000002BC4EC: D4510014
	v_cndmask_b32_e32 v0, s10, v137, vcc_lo                    // 0000002BC4F0: 0201120A
	s_and_b32 s3, s20, exec_lo                                 // 0000002BC4F4: 8B037E14
	s_cselect_b32 s3, 8, 2                                     // 0000002BC4F8: 98038288
	s_cselect_b32 s1, 3, 1                                     // 0000002BC4FC: 98018183
	s_add_i32 s28, s3, -1                                      // 0000002BC500: 811CC103
	s_waitcnt vmcnt(1)                                         // 0000002BC504: BF8907F7
	v_bfe_u32 v3, v1, 16, 1                                    // 0000002BC508: D6100003 02052101
	s_waitcnt vmcnt(0)                                         // 0000002BC510: BF8903F7
	v_bfe_u32 v4, v2, 16, 1                                    // 0000002BC514: D6100004 02052102
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002BC51C: BF8701A2
	v_add3_u32 v1, v1, v3, 0x7fff                              // 0000002BC520: D6550001 03FE0701 00007FFF
	.long 0x7f063880                                           // 0000002BC52C: 7F063880
	v_add3_u32 v2, v2, v4, 0x7fff                              // 0000002BC530: D6550002 03FE0902 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BC53C: BF870123
	.long 0x7e063981                                           // 0000002BC540: 7E063981
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000002BC544: 30020082
	v_and_or_b32 v2, 0xffff0000, v2, v3                        // 0000002BC548: D6570002 040E04FF FFFF0000
	v_lshrrev_b32_e32 v3, 5, v0                                // 0000002BC554: 32060085
	ds_store_b32 v1, v2                                        // 0000002BC558: D8340000 00000201
	v_cvt_f32_ubyte0_e32 v1, s3                                // 0000002BC560: 7E022203
	v_lshrrev_b32_e32 v14, s1, v3                              // 0000002BC564: 321C0601
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BC568: BF870292
	v_rcp_iflag_f32_e32 v1, v1                                 // 0000002BC56C: 7E025701
	v_readfirstlane_b32 s0, v1                                 // 0000002BC570: 7E000501
	s_mul_f32 s0, s0, 0x4f7ffffe                               // 0000002BC574: A200FF00 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3)                          // 0000002BC57C: BF87000B
	s_cvt_u32_f32 s0, s0                                       // 0000002BC580: BE806700
	s_waitcnt lgkmcnt(0)                                       // 0000002BC584: BF89FC07
	s_barrier                                                  // 0000002BC588: BFBD0000
	buffer_gl0_inv                                             // 0000002BC58C: E0AC0000 00000000
	s_load_b32 s21, s[16:17], 0x40                             // 0000002BC594: F4000548 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002BC59C: BF89FC07
	s_sub_i32 s22, s2, s21                                     // 0000002BC5A0: 81961502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BC5A4: BF870009
	s_ashr_i32 s23, s22, 31                                    // 0000002BC5A8: 86179F16
	s_and_b32 s21, s20, exec_lo                                // 0000002BC5AC: 8B157E14
	s_cselect_b32 s21, 0, 2                                    // 0000002BC5B0: 98158280
	s_lshr_b32 s24, s15, 31                                    // 0000002BC5B4: 85189F0F
	s_lshl_b64 s[22:23], s[22:23], s21                         // 0000002BC5B8: 84961516
	s_add_u32 s24, s14, s24                                    // 0000002BC5BC: 8018180E
	s_addc_u32 s25, s15, 0                                     // 0000002BC5C0: 8219800F
	s_ashr_i32 s26, s15, 31                                    // 0000002BC5C4: 861A9F0F
	s_ashr_i64 s[24:25], s[24:25], 1                           // 0000002BC5C8: 86988118
	s_lshr_b32 s26, s26, 27                                    // 0000002BC5CC: 851A9B1A
	.long 0xd7001601                                           // 0000002BC5D0: D7001601
	v_cndmask_b32_e32 v1, s22, v14, vcc_lo                     // 0000002BC5D4: 02021C16
	s_add_u32 s26, s14, s26                                    // 0000002BC5D8: 801A1A0E
	s_addc_u32 s27, s15, 0                                     // 0000002BC5DC: 821B800F
	s_sub_i32 s29, 0, s3                                       // 0000002BC5E0: 819D0380
	s_lshr_b64 s[26:27], s[26:27], 5                           // 0000002BC5E4: 859A851A
	s_mul_i32 s29, s29, s0                                     // 0000002BC5E8: 961D001D
	s_add_i32 s27, s28, s26                                    // 0000002BC5EC: 811B1A1C
	s_mul_hi_u32 s29, s0, s29                                  // 0000002BC5F0: 969D1D00
	s_abs_i32 s30, s27                                         // 0000002BC5F4: BE9E151B
	s_add_i32 s0, s0, s29                                      // 0000002BC5F8: 81001D00
	v_add_co_ci_u32_e64 v2, null, s23, 0, s22                  // 0000002BC5FC: D5207C02 00590017
	s_mul_hi_u32 s0, s30, s0                                   // 0000002BC604: 9680001E
	s_ashr_i32 s23, s27, 31                                    // 0000002BC608: 86179F1B
	s_mul_i32 s22, s0, s3                                      // 0000002BC60C: 96160300
	s_add_i32 s27, s0, 1                                       // 0000002BC610: 811B8100
	s_sub_i32 s22, s30, s22                                    // 0000002BC614: 8196161E
	v_cmp_gt_i64_e32 vcc_lo, s[10:11], v[1:2]                  // 0000002BC618: 7CA8020A
	s_sub_i32 s29, s22, s3                                     // 0000002BC61C: 819D0316
	s_cmp_ge_u32 s22, s3                                       // 0000002BC620: BF090316
	v_and_b32_e32 v16, s28, v3                                 // 0000002BC624: 3620061C
	s_cselect_b32 s0, s27, s0                                  // 0000002BC628: 9800001B
	s_cselect_b32 s22, s29, s22                                // 0000002BC62C: 9816161D
	s_add_i32 s27, s0, 1                                       // 0000002BC630: 811B8100
	s_cmp_ge_u32 s22, s3                                       // 0000002BC634: BF090316
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000002BC638: 02020280
	s_cselect_b32 s0, s27, s0                                  // 0000002BC63C: 9800001B
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 0000002BC640: 02040480
	s_xor_b32 s0, s0, s23                                      // 0000002BC644: 8D001700
	v_mov_b32_e32 v3, 0                                        // 0000002BC648: 7E060280
	s_sub_i32 s0, s0, s23                                      // 0000002BC64C: 81801700
	s_add_u32 s4, s18, s4                                      // 0000002BC650: 80040412
	.long 0xd72c0005                                           // 0000002BC654: D72C0005
	v_cndmask_b32_e32 v1, s0, v16, vcc_lo                      // 0000002BC658: 02022000
	s_addc_u32 s5, s19, s5                                     // 0000002BC65C: 82050513
	s_add_u32 s6, s18, s6                                      // 0000002BC660: 80060612
	.long 0xd72c0004                                           // 0000002BC664: D72C0004
	v_cndmask_b32_e32 v0, v2, v24, vcc_lo                      // 0000002BC668: 02003102
	.long 0xd72c0006                                           // 0000002BC66C: D72C0006
	v_cndmask_b32_e32 v0, v2, v8, vcc_lo                       // 0000002BC670: 02001102
	s_addc_u32 s7, s19, s7                                     // 0000002BC674: 82070713
	.long 0xd72c0007                                           // 0000002BC678: D72C0007
	v_cndmask_b32_e32 v0, v1, v25, vcc_lo                      // 0000002BC67C: 02003301
	.long 0xd72c0008                                           // 0000002BC680: D72C0008
	v_cndmask_b32_e32 v0, v1, v9, vcc_lo                       // 0000002BC684: 02001301
	v_add_nc_u32_e32 v2, s0, v5                                // 0000002BC688: 4A040A00
	v_mad_u64_u32 v[9:10], null, v1, s24, s[4:5]               // 0000002BC68C: D6FE7C09 00103101
	v_mad_u64_u32 v[11:12], null, v1, s8, s[6:7]               // 0000002BC694: D6FE7C0B 00181101
	v_mov_b32_e32 v1, 0                                        // 0000002BC69C: 7E020280
	v_dual_mov_b32 v21, 0 :: v_dual_add_nc_u32 v18, v5, v15    // 0000002BC6A0: CA200080 15121F05
	v_min_i32_e32 v19, s26, v2                                 // 0000002BC6A8: 2226041A
	v_mov_b32_e32 v2, 0                                        // 0000002BC6AC: 7E040280
	v_add3_u32 v10, v4, v10, v7                                // 0000002BC6B0: D655000A 041E1504
	v_add3_u32 v20, v6, v12, v8                                // 0000002BC6B8: D6550014 04221906
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002BC6C0: BF870004
	v_cmp_lt_i32_e32 vcc_lo, v18, v19                          // 0000002BC6C4: 7C822712
	v_mov_b32_e32 v4, 0                                        // 0000002BC6C8: 7E080280
	s_and_saveexec_b32 s4, vcc_lo                              // 0000002BC6CC: BE84206A
	s_cbranch_execz 21                                         // 0000002BC6D0: BFA50015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x328>
	v_lshlrev_b32_e32 v1, 1, v18                               // 0000002BC6D4: 30022481
	v_lshlrev_b32_e32 v3, 4, v18                               // 0000002BC6D8: 30062484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BC6DC: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002BC6E0: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002BC6E4: 3408069F
	.long 0xd7000001                                           // 0000002BC6E8: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000002BC6EC: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BC6F0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 0000002BC6F4: D5207C02 00020514
	.long 0xd7000003                                           // 0000002BC6FC: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000002BC700: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 0000002BC704: D5207C04 0002090A
	s_clause 0x1                                               // 0000002BC70C: BF850001
	global_load_d16_b16 v6, v[1:2], off                        // 0000002BC710: DC820000 067C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000002BC718: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000002BC720: BF8907F7
	v_cvt_f32_f16_e32 v21, v6                                  // 0000002BC724: 7E2A1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000002BC728: 8C7E047E
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 0000002BC72C: CA100080 17180080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v26, 0             // 0000002BC734: CA100080 191A0080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v22, 0             // 0000002BC73C: CA100080 1B160080
	s_and_saveexec_b32 s8, vcc_lo                              // 0000002BC744: BE88206A
	s_cbranch_execz 520                                        // 0000002BC748: BFA50208 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0xb6c>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v6, 5, v15     // 0000002BC74C: CA220080 1B061E85
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v7, 32, v18     // 0000002BC754: CA200080 160624A0
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v23, 0             // 0000002BC75C: CA100080 18160080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BC764: BF870193
	v_lshl_add_u32 v12, v5, 5, v6                              // 0000002BC768: D646000C 04190B05
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v28, 4, v7     // 0000002BC770: CA220080 191C0E84
	v_dual_mov_b32 v26, 0 :: v_dual_lshlrev_b32 v29, 1, v7     // 0000002BC778: CA220080 1A1C0E81
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v30, v21           // 0000002BC780: CA100080 111E0115
	s_mul_i32 s0, s15, 6                                       // 0000002BC788: 9600860F
	s_mul_hi_u32 s6, s14, 6                                    // 0000002BC78C: 9686860E
	s_lshl_b64 s[4:5], s[14:15], 2                             // 0000002BC790: 8484820E
	s_add_i32 s9, s6, s0                                       // 0000002BC794: 81090006
	s_mul_i32 s19, s14, 6                                      // 0000002BC798: 9613860E
	s_mov_b32 s18, 0                                           // 0000002BC79C: BE920080
	s_lshl_b64 s[6:7], s[14:15], 1                             // 0000002BC7A0: 8486810E
	s_branch 465                                               // 0000002BC7A4: BFA001D1 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0xaec>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000002BC7A8: 8C7E0E7E
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000002BC7AC: 341A189F
	v_lshrrev_b32_e32 v43, 6, v1                               // 0000002BC7B0: 32560286
	v_lshrrev_b32_e32 v55, 14, v1                              // 0000002BC7B4: 326E028E
	v_and_b32_e32 v59, 0xff, v2                                // 0000002BC7B8: 367604FF 000000FF
	v_lshrrev_b32_e32 v60, 6, v2                               // 0000002BC7C0: 32780486
	.long 0xd73c001f                                           // 0000002BC7C4: D73C001F
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000002BC7C8: 02021881
	v_and_b32_e32 v56, 0x3fc, v43                              // 0000002BC7CC: 367056FF 000003FC
	v_and_b32_e32 v13, 0xff, v1                                // 0000002BC7D4: 361A02FF 000000FF
	v_and_b32_e32 v62, 0x3fc, v55                              // 0000002BC7DC: 367C6EFF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000002BC7E4: 32020296
	v_lshrrev_b32_e32 v61, 14, v2                              // 0000002BC7E8: 327A048E
	.long 0xd700004b                                           // 0000002BC7EC: D700004B
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 0000002BC7F0: 02023E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002BC7F4: BF8701A1
	v_add_co_ci_u32_e64 v76, null, s13, v32, s0                // 0000002BC7F8: D5207C4C 0002400D
	v_lshlrev_b32_e32 v13, 2, v13                              // 0000002BC800: 301A1A82
	.long 0xd700004f                                           // 0000002BC804: D700004F
	v_cndmask_b32_e32 v0, v75, v6, vcc_lo                      // 0000002BC808: 02000D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BC80C: BF8700A1
	v_add_co_ci_u32_e64 v80, null, s7, v76, s0                 // 0000002BC810: D5207C50 00029807
	.long 0xd7000051                                           // 0000002BC818: D7000051
	v_cndmask_b32_e32 v0, v75, v4, vcc_lo                      // 0000002BC81C: 0200094B
	v_add_co_ci_u32_e64 v82, null, s5, v76, s0                 // 0000002BC820: D5207C52 00029805
	.long 0xd7000053                                           // 0000002BC828: D7000053
	v_cndmask_b32_e32 v0, v75, v19, vcc_lo                     // 0000002BC82C: 0200274B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002BC830: BF870211
	v_add_co_ci_u32_e64 v84, null, s9, v76, s0                 // 0000002BC834: D5207C54 00029809
	.long 0xd7000055                                           // 0000002BC83C: D7000055
	v_cndmask_b32_e32 v0, v81, v4, vcc_lo                      // 0000002BC840: 02000951
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002BC844: BF8700D1
	v_add_co_ci_u32_e64 v86, null, s5, v82, s0                 // 0000002BC848: D5207C56 0002A405
	s_clause 0x1                                               // 0000002BC850: BF850001
	global_load_b128 v[43:46], v[83:84], off                   // 0000002BC854: DC5E0000 2B7C0053
	global_load_b128 v[71:74], v[83:84], off offset:16         // 0000002BC85C: DC5E0010 477C0053
	.long 0xd7000057                                           // 0000002BC864: D7000057
	v_cndmask_b32_e32 v0, v83, v4, vcc_lo                      // 0000002BC868: 02000953
	v_add_co_ci_u32_e64 v88, null, s5, v84, s0                 // 0000002BC86C: D5207C58 0002A805
	s_clause 0x4                                               // 0000002BC874: BF850004
	global_load_b128 v[47:50], v[85:86], off                   // 0000002BC878: DC5E0000 2F7C0055
	global_load_b128 v[31:34], v[75:76], off                   // 0000002BC880: DC5E0000 1F7C004B
	global_load_b128 v[35:38], v[79:80], off                   // 0000002BC888: DC5E0000 237C004F
	global_load_b128 v[39:42], v[81:82], off                   // 0000002BC890: DC5E0000 277C0051
	global_load_b128 v[51:54], v[87:88], off                   // 0000002BC898: DC5E0000 337C0057
	ds_load_b32 v13, v13                                       // 0000002BC8A0: D8D80000 0D00000D
	ds_load_b32 v77, v56                                       // 0000002BC8A8: D8D80000 4D000038
	ds_load_b32 v78, v62                                       // 0000002BC8B0: D8D80000 4E00003E
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000002BC8B8: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000002BC8BC: 360202FF 000003FC
	v_lshlrev_b32_e32 v67, 2, v59                              // 0000002BC8C4: 30867682
	v_and_b32_e32 v68, 0x3fc, v60                              // 0000002BC8C8: 368878FF 000003FC
	v_and_b32_e32 v69, 0x3fc, v61                              // 0000002BC8D0: 368A7AFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000002BC8D8: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000002BC8E0: D8D80000 01000001
	ds_load_b32 v91, v67                                       // 0000002BC8E8: D8D80000 5B000043
	ds_load_b32 v92, v68                                       // 0000002BC8F0: D8D80000 5C000044
	ds_load_b32 v93, v69                                       // 0000002BC8F8: D8D80000 5D000045
	ds_load_b32 v2, v2                                         // 0000002BC900: D8D80000 02000002
	.long 0xd7000059                                           // 0000002BC908: D7000059
	v_cndmask_b32_e32 v0, v85, v4, vcc_lo                      // 0000002BC90C: 02000955
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BC910: BF870001
	v_add_co_ci_u32_e64 v90, null, s5, v86, s0                 // 0000002BC914: D5207C5A 0002AC05
	s_clause 0x2                                               // 0000002BC91C: BF850002
	global_load_b128 v[59:62], v[75:76], off offset:16         // 0000002BC920: DC5E0010 3B7C004B
	global_load_b128 v[63:66], v[79:80], off offset:16         // 0000002BC928: DC5E0010 3F7C004F
	global_load_b128 v[67:70], v[81:82], off offset:16         // 0000002BC930: DC5E0010 437C0051
	v_add_nc_u32_e32 v28, 0x200, v28                           // 0000002BC938: 4A3838FF 00000200
	global_load_b128 v[55:58], v[89:90], off                   // 0000002BC940: DC5E0000 377C0059
	v_add_nc_u32_e32 v29, 64, v29                              // 0000002BC948: 4A3A3AC0
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000002BC94C: 4A1818FF 00000400
	s_and_b32 s0, exec_lo, vcc_lo                              // 0000002BC954: 8B006A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002BC958: BF8700C9
	s_or_b32 s18, s0, s18                                      // 0000002BC95C: 8C121200
	s_waitcnt vmcnt(10) lgkmcnt(7)                             // 0000002BC960: BF892877
	v_dot2_f32_bf16 v43, v43, v13, 0                           // 0000002BC964: CC1A402B 1A021B2B
	s_waitcnt lgkmcnt(6)                                       // 0000002BC96C: BF89FC67
	v_dot2_f32_bf16 v43, v44, v77, v43                         // 0000002BC970: CC1A402B 1CAE9B2C
	s_waitcnt vmcnt(8)                                         // 0000002BC978: BF8923F7
	v_dot2_f32_bf16 v44, v47, v13, 0                           // 0000002BC97C: CC1A402C 1A021B2F
	s_waitcnt vmcnt(5)                                         // 0000002BC984: BF8917F7
	v_dot2_f32_bf16 v39, v39, v13, 0                           // 0000002BC988: CC1A4027 1A021B27
	s_waitcnt lgkmcnt(5)                                       // 0000002BC990: BF89FC57
	v_dot2_f32_bf16 v43, v45, v78, v43                         // 0000002BC994: CC1A402B 1CAE9D2D
	v_dot2_f32_bf16 v44, v48, v77, v44                         // 0000002BC99C: CC1A402C 1CB29B30
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002BC9A4: BF8701A3
	v_dot2_f32_bf16 v39, v40, v77, v39                         // 0000002BC9A8: CC1A4027 1C9E9B28
	s_waitcnt lgkmcnt(4)                                       // 0000002BC9B0: BF89FC47
	v_dot2_f32_bf16 v97, v46, v1, v43                          // 0000002BC9B4: CC1A4061 1CAE032E
	s_waitcnt vmcnt(4)                                         // 0000002BC9BC: BF8913F7
	v_dot2_f32_bf16 v43, v51, v13, 0                           // 0000002BC9C0: CC1A402B 1A021B33
	v_dot2_f32_bf16 v48, v49, v78, v44                         // 0000002BC9C8: CC1A4030 1CB29D31
	v_dot2_f32_bf16 v39, v41, v78, v39                         // 0000002BC9D0: CC1A4027 1C9E9D29
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002BC9D8: BF870003
	v_dot2_f32_bf16 v47, v52, v77, v43                         // 0000002BC9DC: CC1A402F 1CAE9B34
	global_load_b128 v[43:46], v[75:76], off offset:32         // 0000002BC9E4: DC5E0020 2B7C004B
	v_dot2_f32_bf16 v31, v31, v13, 0                           // 0000002BC9EC: CC1A401F 1A021B1F
	v_dot2_f32_bf16 v96, v42, v1, v39                          // 0000002BC9F4: CC1A4060 1C9E032A
	global_load_b128 v[39:42], v[89:90], off offset:16         // 0000002BC9FC: DC5E0010 277C0059
	v_dot2_f32_bf16 v51, v53, v78, v47                         // 0000002BCA04: CC1A4033 1CBE9D35
	v_dot2_f32_bf16 v31, v32, v77, v31                         // 0000002BCA0C: CC1A401F 1C7E9B20
	v_dot2_f32_bf16 v32, v35, v13, 0                           // 0000002BCA14: CC1A4020 1A021B23
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BCA1C: BF870112
	v_dot2_f32_bf16 v31, v33, v78, v31                         // 0000002BCA20: CC1A401F 1C7E9D21
	v_dot2_f32_bf16 v35, v36, v77, v32                         // 0000002BCA28: CC1A4023 1C829B24
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002BCA30: BF870002
	v_dot2_f32_bf16 v94, v34, v1, v31                          // 0000002BCA34: CC1A405E 1C7E0322
	global_load_b128 v[31:34], v[85:86], off offset:16         // 0000002BCA3C: DC5E0010 1F7C0055
	v_dot2_f32_bf16 v35, v37, v78, v35                         // 0000002BCA44: CC1A4023 1C8E9D25
	s_waitcnt vmcnt(6) lgkmcnt(3)                              // 0000002BCA4C: BF891837
	v_dot2_f32_bf16 v52, v59, v91, v94                         // 0000002BCA50: CC1A4034 1D7AB73B
	v_dot2_f32_bf16 v94, v54, v1, v51                          // 0000002BCA58: CC1A405E 1CCE0336
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000002BCA60: BF870153
	v_dot2_f32_bf16 v95, v38, v1, v35                          // 0000002BCA64: CC1A405F 1C8E0326
	global_load_b128 v[35:38], v[87:88], off offset:16         // 0000002BCA6C: DC5E0010 237C0057
	s_waitcnt vmcnt(4)                                         // 0000002BCA74: BF8913F7
	v_dot2_f32_bf16 v13, v55, v13, 0                           // 0000002BCA78: CC1A400D 1A021B37
	v_dot2_f32_bf16 v55, v63, v91, v95                         // 0000002BCA80: CC1A4037 1D7EB73F
	v_dot2_f32_bf16 v13, v56, v77, v13                         // 0000002BCA88: CC1A400D 1C369B38
	s_waitcnt lgkmcnt(2)                                       // 0000002BCA90: BF89FC27
	v_dot2_f32_bf16 v56, v60, v92, v52                         // 0000002BCA94: CC1A4038 1CD2B93C
	global_load_b128 v[51:54], v[81:82], off offset:32         // 0000002BCA9C: DC5E0020 337C0051
	v_dot2_f32_bf16 v60, v67, v91, v96                         // 0000002BCAA4: CC1A403C 1D82B743
	v_dot2_f32_bf16 v59, v64, v92, v55                         // 0000002BCAAC: CC1A403B 1CDEB940
	v_dot2_f32_bf16 v13, v57, v78, v13                         // 0000002BCAB4: CC1A400D 1C369D39
	v_dot2_f32_bf16 v77, v50, v1, v48                          // 0000002BCABC: CC1A404D 1CC20332
	global_load_b128 v[47:50], v[79:80], off offset:32         // 0000002BCAC4: DC5E0020 2F7C004F
	v_dot2_f32_bf16 v67, v68, v92, v60                         // 0000002BCACC: CC1A4043 1CF2B944
	s_waitcnt lgkmcnt(1)                                       // 0000002BCAD4: BF89FC17
	v_dot2_f32_bf16 v61, v61, v93, v56                         // 0000002BCAD8: CC1A403D 1CE2BB3D
	v_dot2_f32_bf16 v1, v58, v1, v13                           // 0000002BCAE0: CC1A4001 1C36033A
	global_load_b128 v[55:58], v[83:84], off offset:32         // 0000002BCAE8: DC5E0020 377C0053
	v_dot2_f32_bf16 v13, v65, v93, v59                         // 0000002BCAF0: CC1A400D 1CEEBB41
	v_dot2_f32_bf16 v68, v71, v91, v97                         // 0000002BCAF8: CC1A4044 1D86B747
	v_dot2_f32_bf16 v67, v69, v93, v67                         // 0000002BCB00: CC1A4043 1D0EBB45
	s_waitcnt lgkmcnt(0)                                       // 0000002BCB08: BF89FC07
	v_dot2_f32_bf16 v95, v62, v2, v61                          // 0000002BCB0C: CC1A405F 1CF6053E
	global_load_b128 v[59:62], v[85:86], off offset:32         // 0000002BCB14: DC5E0020 3B7C0055
	v_dot2_f32_bf16 v13, v66, v2, v13                          // 0000002BCB1C: CC1A400D 1C360542
	global_load_b128 v[63:66], v[87:88], off offset:32         // 0000002BCB24: DC5E0020 3F7C0057
	v_dot2_f32_bf16 v71, v72, v92, v68                         // 0000002BCB2C: CC1A4047 1D12B948
	v_dot2_f32_bf16 v96, v70, v2, v67                          // 0000002BCB34: CC1A4060 1D0E0546
	global_load_b128 v[67:70], v[89:90], off offset:32         // 0000002BCB3C: DC5E0020 437C0059
	s_waitcnt vmcnt(8)                                         // 0000002BCB44: BF8923F7
	v_dot2_f32_bf16 v1, v39, v91, v1                           // 0000002BCB48: CC1A4001 1C06B727
	v_and_b32_e32 v39, 0xff, v3                                // 0000002BCB50: 364E06FF 000000FF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002BCB58: BF8701A2
	v_dot2_f32_bf16 v1, v40, v92, v1                           // 0000002BCB5C: CC1A4001 1C06B928
	v_lshrrev_b32_e32 v40, 6, v3                               // 0000002BCB64: 32500686
	v_lshlrev_b32_e32 v39, 2, v39                              // 0000002BCB68: 304E4E82
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002BCB6C: BF870003
	v_dot2_f32_bf16 v1, v41, v93, v1                           // 0000002BCB70: CC1A4001 1C06BB29
	v_lshrrev_b32_e32 v41, 14, v3                              // 0000002BCB78: 3252068E
	ds_load_b32 v39, v39                                       // 0000002BCB7C: D8D80000 27000027
	s_waitcnt vmcnt(7)                                         // 0000002BCB84: BF891FF7
	v_dot2_f32_bf16 v31, v31, v91, v77                         // 0000002BCB88: CC1A401F 1D36B71F
	global_load_b128 v[75:78], v[75:76], off offset:48         // 0000002BCB90: DC5E0030 4B7C004B
	v_dot2_f32_bf16 v42, v42, v2, v1                           // 0000002BCB98: CC1A402A 1C06052A
	v_and_b32_e32 v41, 0x3fc, v41                              // 0000002BCBA0: 365252FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v3                               // 0000002BCBA8: 32020696
	v_dot2_f32_bf16 v31, v32, v92, v31                         // 0000002BCBAC: CC1A401F 1C7EB920
	v_dot2_f32_bf16 v32, v73, v93, v71                         // 0000002BCBB4: CC1A4020 1D1EBB49
	s_waitcnt vmcnt(7)                                         // 0000002BCBBC: BF891FF7
	v_dot2_f32_bf16 v35, v35, v91, v94                         // 0000002BCBC0: CC1A4023 1D7AB723
	v_and_b32_e32 v91, 0xff, v4                                // 0000002BCBC8: 36B608FF 000000FF
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000002BCBD0: 360202FF 000003FC
	v_dot2_f32_bf16 v31, v33, v93, v31                         // 0000002BCBD8: CC1A401F 1C7EBB21
	v_dot2_f32_bf16 v94, v74, v2, v32                          // 0000002BCBE0: CC1A405E 1C82054A
	v_dot2_f32_bf16 v35, v36, v92, v35                         // 0000002BCBE8: CC1A4023 1C8EB924
	s_clause 0x1                                               // 0000002BCBF0: BF850001
	global_load_b128 v[71:74], v[79:80], off offset:48         // 0000002BCBF4: DC5E0030 477C004F
	global_load_b128 v[79:82], v[81:82], off offset:48         // 0000002BCBFC: DC5E0030 4F7C0051
	v_lshrrev_b32_e32 v92, 14, v4                              // 0000002BCC04: 32B8088E
	v_dot2_f32_bf16 v97, v34, v2, v31                          // 0000002BCC08: CC1A4061 1C7E0522
	global_load_b128 v[31:34], v[83:84], off offset:48         // 0000002BCC10: DC5E0030 1F7C0053
	v_dot2_f32_bf16 v35, v37, v93, v35                         // 0000002BCC18: CC1A4023 1C8EBB25
	global_load_b128 v[83:86], v[85:86], off offset:48         // 0000002BCC20: DC5E0030 537C0055
	v_lshrrev_b32_e32 v93, 22, v4                              // 0000002BCC28: 32BA0896
	v_mov_b32_e32 v3, v7                                       // 0000002BCC2C: 7E060307
	v_lshlrev_b32_e32 v7, 2, v91                               // 0000002BCC30: 300EB682
	v_dot2_f32_bf16 v98, v38, v2, v35                          // 0000002BCC34: CC1A4062 1C8E0526
	s_clause 0x1                                               // 0000002BCC3C: BF850001
	global_load_b128 v[35:38], v[87:88], off offset:48         // 0000002BCC40: DC5E0030 237C0057
	global_load_b128 v[87:90], v[89:90], off offset:48         // 0000002BCC48: DC5E0030 577C0059
	v_and_b32_e32 v2, 0x3fc, v40                               // 0000002BCC50: 360450FF 000003FC
	v_lshrrev_b32_e32 v40, 6, v4                               // 0000002BCC58: 32500886
	v_mov_b32_e32 v4, v8                                       // 0000002BCC5C: 7E080308
	ds_load_b32 v99, v2                                        // 0000002BCC60: D8D80000 63000002
	v_mov_b32_e32 v2, v6                                       // 0000002BCC68: 7E040306
	ds_load_b32 v6, v41                                        // 0000002BCC6C: D8D80000 06000029
	v_and_b32_e32 v8, 0x3fc, v40                               // 0000002BCC74: 361050FF 000003FC
	v_and_b32_e32 v40, 0x3fc, v92                              // 0000002BCC7C: 3650B8FF 000003FC
	v_and_b32_e32 v41, 0x3fc, v93                              // 0000002BCC84: 3652BAFF 000003FC
	ds_load_b32 v91, v1                                        // 0000002BCC8C: D8D80000 5B000001
	ds_load_b32 v7, v7                                         // 0000002BCC94: D8D80000 07000007
	ds_load_b32 v8, v8                                         // 0000002BCC9C: D8D80000 08000008
	ds_load_b32 v40, v40                                       // 0000002BCCA4: D8D80000 28000028
	ds_load_b32 v41, v41                                       // 0000002BCCAC: D8D80000 29000029
	s_waitcnt lgkmcnt(7)                                       // 0000002BCCB4: BF89FC77
	v_dot2_f32_bf16 v43, v43, v39, v95                         // 0000002BCCB8: CC1A402B 1D7E4F2B
	v_mov_b32_e32 v1, v5                                       // 0000002BCCC0: 7E020305
	s_waitcnt vmcnt(11)                                        // 0000002BCCC4: BF892FF7
	v_dot2_f32_bf16 v13, v47, v39, v13                         // 0000002BCCC8: CC1A400D 1C364F2F
	s_waitcnt vmcnt(8)                                         // 0000002BCCD0: BF8923F7
	v_dot2_f32_bf16 v47, v63, v39, v98                         // 0000002BCCD4: CC1A402F 1D8A4F3F
	s_waitcnt lgkmcnt(6)                                       // 0000002BCCDC: BF89FC67
	v_dot2_f32_bf16 v5, v44, v99, v43                          // 0000002BCCE0: CC1A4005 1CAEC72C
	v_dot2_f32_bf16 v43, v51, v39, v96                         // 0000002BCCE8: CC1A402B 1D824F33
	v_dot2_f32_bf16 v44, v55, v39, v94                         // 0000002BCCF0: CC1A402C 1D7A4F37
	v_dot2_f32_bf16 v13, v48, v99, v13                         // 0000002BCCF8: CC1A400D 1C36C730
	s_waitcnt lgkmcnt(5)                                       // 0000002BCD00: BF89FC57
	v_dot2_f32_bf16 v5, v45, v6, v5                            // 0000002BCD04: CC1A4005 1C160D2D
	v_dot2_f32_bf16 v43, v52, v99, v43                         // 0000002BCD0C: CC1A402B 1CAEC734
	v_dot2_f32_bf16 v44, v56, v99, v44                         // 0000002BCD14: CC1A402C 1CB2C738
	v_dot2_f32_bf16 v45, v59, v39, v97                         // 0000002BCD1C: CC1A402D 1D864F3B
	s_waitcnt vmcnt(7)                                         // 0000002BCD24: BF891FF7
	v_dot2_f32_bf16 v39, v67, v39, v42                         // 0000002BCD28: CC1A4027 1CAA4F43
	s_waitcnt lgkmcnt(4)                                       // 0000002BCD30: BF89FC47
	v_dot2_f32_bf16 v5, v46, v91, v5                           // 0000002BCD34: CC1A4005 1C16B72E
	v_dot2_f32_bf16 v13, v49, v6, v13                          // 0000002BCD3C: CC1A400D 1C360D31
	v_dot2_f32_bf16 v43, v53, v6, v43                          // 0000002BCD44: CC1A402B 1CAE0D35
	v_dot2_f32_bf16 v44, v57, v6, v44                          // 0000002BCD4C: CC1A402C 1CB20D39
	v_dot2_f32_bf16 v45, v60, v99, v45                         // 0000002BCD54: CC1A402D 1CB6C73C
	v_dot2_f32_bf16 v46, v64, v99, v47                         // 0000002BCD5C: CC1A402E 1CBEC740
	v_dot2_f32_bf16 v39, v68, v99, v39                         // 0000002BCD64: CC1A4027 1C9EC744
	v_dot2_f32_bf16 v13, v50, v91, v13                         // 0000002BCD6C: CC1A400D 1C36B732
	v_dot2_f32_bf16 v42, v54, v91, v43                         // 0000002BCD74: CC1A402A 1CAEB736
	v_dot2_f32_bf16 v43, v58, v91, v44                         // 0000002BCD7C: CC1A402B 1CB2B73A
	v_dot2_f32_bf16 v44, v61, v6, v45                          // 0000002BCD84: CC1A402C 1CB60D3D
	v_dot2_f32_bf16 v45, v65, v6, v46                          // 0000002BCD8C: CC1A402D 1CBA0D41
	v_dot2_f32_bf16 v6, v69, v6, v39                           // 0000002BCD94: CC1A4006 1C9E0D45
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002BCD9C: BF8700C1
	v_dot2_f32_bf16 v6, v70, v91, v6                           // 0000002BCDA0: CC1A4006 1C1AB746
	s_waitcnt vmcnt(6) lgkmcnt(3)                              // 0000002BCDA8: BF891837
	v_dot2_f32_bf16 v5, v75, v7, v5                            // 0000002BCDAC: CC1A4005 1C160F4B
	s_waitcnt lgkmcnt(2)                                       // 0000002BCDB4: BF89FC27
	v_dot2_f32_bf16 v5, v76, v8, v5                            // 0000002BCDB8: CC1A4005 1C16114C
	s_waitcnt lgkmcnt(1)                                       // 0000002BCDC0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BCDC4: BF870001
	v_dot2_f32_bf16 v5, v77, v40, v5                           // 0000002BCDC8: CC1A4005 1C16514D
	s_waitcnt vmcnt(5)                                         // 0000002BCDD0: BF8917F7
	v_dot2_f32_bf16 v13, v71, v7, v13                          // 0000002BCDD4: CC1A400D 1C360F47
	s_waitcnt vmcnt(4)                                         // 0000002BCDDC: BF8913F7
	v_dot2_f32_bf16 v42, v79, v7, v42                          // 0000002BCDE0: CC1A402A 1CAA0F4F
	s_waitcnt vmcnt(3)                                         // 0000002BCDE8: BF890FF7
	v_dot2_f32_bf16 v31, v31, v7, v43                          // 0000002BCDEC: CC1A401F 1CAE0F1F
	v_dot2_f32_bf16 v43, v62, v91, v44                         // 0000002BCDF4: CC1A402B 1CB2B73E
	v_dot2_f32_bf16 v44, v66, v91, v45                         // 0000002BCDFC: CC1A402C 1CB6B742
	v_dot2_f32_bf16 v13, v72, v8, v13                          // 0000002BCE04: CC1A400D 1C361148
	s_waitcnt lgkmcnt(0)                                       // 0000002BCE0C: BF89FC07
	v_dot2_f32_bf16 v5, v78, v41, v5                           // 0000002BCE10: CC1A4005 1C16534E
	v_dot2_f32_bf16 v31, v32, v8, v31                          // 0000002BCE18: CC1A401F 1C7E1120
	s_waitcnt vmcnt(2)                                         // 0000002BCE20: BF890BF7
	v_dot2_f32_bf16 v32, v83, v7, v43                          // 0000002BCE24: CC1A4020 1CAE0F53
	s_waitcnt vmcnt(1)                                         // 0000002BCE2C: BF8907F7
	v_dot2_f32_bf16 v35, v35, v7, v44                          // 0000002BCE30: CC1A4023 1CB20F23
	s_waitcnt vmcnt(0)                                         // 0000002BCE38: BF8903F7
	v_dot2_f32_bf16 v6, v87, v7, v6                            // 0000002BCE3C: CC1A4006 1C1A0F57
	v_dot2_f32_bf16 v39, v80, v8, v42                          // 0000002BCE44: CC1A4027 1CAA1150
	v_dot2_f32_bf16 v13, v73, v40, v13                         // 0000002BCE4C: CC1A400D 1C365149
	v_dot2_f32_bf16 v7, v33, v40, v31                          // 0000002BCE54: CC1A4007 1C7E5121
	v_dot2_f32_bf16 v31, v84, v8, v32                          // 0000002BCE5C: CC1A401F 1C821154
	v_dot2_f32_bf16 v32, v36, v8, v35                          // 0000002BCE64: CC1A4020 1C8E1124
	v_fmac_f32_e32 v22, v21, v5                                // 0000002BCE6C: 562C0B15
	v_dot2_f32_bf16 v5, v88, v8, v6                            // 0000002BCE70: CC1A4005 1C1A1158
	v_dot2_f32_bf16 v39, v81, v40, v39                         // 0000002BCE78: CC1A4027 1C9E5151
	v_dot2_f32_bf16 v6, v74, v41, v13                          // 0000002BCE80: CC1A4006 1C36534A
	v_dot2_f32_bf16 v13, v85, v40, v31                         // 0000002BCE88: CC1A400D 1C7E5155
	v_dot2_f32_bf16 v31, v37, v40, v32                         // 0000002BCE90: CC1A401F 1C825125
	v_dot2_f32_bf16 v5, v89, v40, v5                           // 0000002BCE98: CC1A4005 1C165159
	v_dot2_f32_bf16 v8, v82, v41, v39                          // 0000002BCEA0: CC1A4008 1C9E5352
	v_dot2_f32_bf16 v7, v34, v41, v7                           // 0000002BCEA8: CC1A4007 1C1E5322
	v_fmac_f32_e32 v27, v21, v6                                // 0000002BCEB0: 56360D15
	v_dot2_f32_bf16 v6, v86, v41, v13                          // 0000002BCEB4: CC1A4006 1C365356
	v_dot2_f32_bf16 v13, v38, v41, v31                         // 0000002BCEBC: CC1A400D 1C7E5326
	v_dot2_f32_bf16 v5, v90, v41, v5                           // 0000002BCEC4: CC1A4005 1C16535A
	v_fmac_f32_e32 v26, v21, v8                                // 0000002BCECC: 56341115
	v_fmac_f32_e32 v25, v21, v7                                // 0000002BCED0: 56320F15
	v_fmac_f32_e32 v24, v21, v6                                // 0000002BCED4: 56300D15
	v_fmac_f32_e32 v23, v21, v13                               // 0000002BCED8: 562E1B15
	v_fmac_f32_e32 v17, v21, v5                                // 0000002BCEDC: 56220B15
	v_mov_b32_e32 v21, v30                                     // 0000002BCEE0: 7E2A031E
	s_and_not1_b32 exec_lo, exec_lo, s18                       // 0000002BCEE4: 917E127E
	s_cbranch_execz 31                                         // 0000002BCEE8: BFA5001F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0xb68>
	s_waitcnt vmcnt(0)                                         // 0000002BCEEC: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v18, 32, v18    // 0000002BCEF0: CA200101 051224A0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 0000002BCEF8: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 0000002BCF00: 7E100304
	s_mov_b32 s14, exec_lo                                     // 0000002BCF04: BE8E007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002BCF08: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v18, v19                          // 0000002BCF0C: 7C8C2712
	.long 0xd4c1007e                                           // 0000002BCF10: D4C1007E
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000002BCF14: 02022712
	s_cbranch_execz 65059                                      // 0000002BCF18: BFA5FE23 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x3a8>
	v_ashrrev_i32_e32 v6, 31, v29                              // 0000002BCF1C: 340C3A9F
	v_ashrrev_i32_e32 v8, 31, v28                              // 0000002BCF20: 3410389F
	.long 0xd7000005                                           // 0000002BCF24: D7000005
	v_cndmask_b32_e32 v1, v11, v29, vcc_lo                     // 0000002BCF28: 02023B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BCF2C: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v20, v6, s0                  // 0000002BCF30: D5207C06 00020D14
	.long 0xd7000007                                           // 0000002BCF38: D7000007
	v_cndmask_b32_e32 v1, v9, v28, vcc_lo                      // 0000002BCF3C: 02023909
	v_add_co_ci_u32_e64 v8, null, v10, v8, s0                  // 0000002BCF40: D5207C08 0002110A
	s_clause 0x1                                               // 0000002BCF48: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 0000002BCF4C: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 0000002BCF54: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 0000002BCF5C: BF8907F7
	v_cvt_f32_f16_e32 v30, v13                                 // 0000002BCF60: 7E3C170D
	s_branch 65040                                             // 0000002BCF64: BFA0FE10 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x3a8>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000002BCF68: 8C7E127E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002BCF6C: BF8700C9
	s_or_b32 exec_lo, exec_lo, s8                              // 0000002BCF70: 8C7E087E
	s_waitcnt vmcnt(0)                                         // 0000002BCF74: BF8903F7
	.long 0xd71f0001                                           // 0000002BCF78: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002BCF7C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000002BCF80: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000002BCF84: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 0000002BCF88: 3A120288
	v_xor_b32_e32 v19, 4, v1                                   // 0000002BCF8C: 3A260284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002BCF90: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000002BCF94: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000002BCF98: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000002BCF9C: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 0000002BCFA0: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 0000002BCFA4: 7C9826A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002BCFA8: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000002BCFAC: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000002BCFB0: 30040482
	ds_bpermute_b32 v3, v2, v22                                // 0000002BCFB4: DACC0000 03001602
	s_waitcnt lgkmcnt(0)                                       // 0000002BCFBC: BF89FC07
	v_add_f32_e32 v3, v22, v3                                  // 0000002BCFC0: 06060716
	ds_bpermute_b32 v4, v2, v27                                // 0000002BCFC4: DACC0000 04001B02
	ds_bpermute_b32 v5, v2, v26                                // 0000002BCFCC: DACC0000 05001A02
	ds_bpermute_b32 v6, v2, v25                                // 0000002BCFD4: DACC0000 06001902
	ds_bpermute_b32 v7, v2, v24                                // 0000002BCFDC: DACC0000 07001802
	ds_bpermute_b32 v8, v2, v23                                // 0000002BCFE4: DACC0000 08001702
	ds_bpermute_b32 v2, v2, v17                                // 0000002BCFEC: DACC0000 02001102
	ds_bpermute_b32 v10, v9, v3                                // 0000002BCFF4: DACC0000 0A000309
	s_waitcnt lgkmcnt(5)                                       // 0000002BCFFC: BF89FC57
	v_dual_add_f32 v4, v27, v4 :: v_dual_add_f32 v5, v26, v5   // 0000002BD000: C908091B 04040B1A
	s_waitcnt lgkmcnt(3)                                       // 0000002BD008: BF89FC37
	v_dual_add_f32 v6, v25, v6 :: v_dual_add_f32 v7, v24, v7   // 0000002BD00C: C9080D19 06060F18
	s_waitcnt lgkmcnt(2)                                       // 0000002BD014: BF89FC27
	v_add_f32_e32 v8, v23, v8                                  // 0000002BD018: 06101117
	ds_bpermute_b32 v11, v9, v4                                // 0000002BD01C: DACC0000 0B000409
	s_waitcnt lgkmcnt(1)                                       // 0000002BD024: BF89FC17
	v_add_f32_e32 v3, v3, v10                                  // 0000002BD028: 06061503
	ds_bpermute_b32 v13, v9, v6                                // 0000002BD02C: DACC0000 0D000609
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 0000002BD034: 02262701
	ds_bpermute_b32 v12, v9, v5                                // 0000002BD038: DACC0000 0C000509
	ds_bpermute_b32 v18, v9, v8                                // 0000002BD040: DACC0000 12000809
	s_waitcnt lgkmcnt(3)                                       // 0000002BD048: BF89FC37
	v_add_f32_e32 v4, v4, v11                                  // 0000002BD04C: 06081704
	s_waitcnt lgkmcnt(2)                                       // 0000002BD050: BF89FC27
	v_add_f32_e32 v6, v6, v13                                  // 0000002BD054: 060C1B06
	v_dual_add_f32 v2, v17, v2 :: v_dual_lshlrev_b32 v19, 2, v19// 0000002BD058: C9220511 02122682
	ds_bpermute_b32 v17, v9, v7                                // 0000002BD060: DACC0000 11000709
	s_waitcnt lgkmcnt(1)                                       // 0000002BD068: BF89FC17
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v8, v8, v18   // 0000002BD06C: C9081905 05082508
	ds_bpermute_b32 v9, v9, v2                                 // 0000002BD074: DACC0000 09000209
	ds_bpermute_b32 v10, v19, v4                               // 0000002BD07C: DACC0000 0A000413
	ds_bpermute_b32 v12, v19, v6                               // 0000002BD084: DACC0000 0C000613
	ds_bpermute_b32 v11, v19, v5                               // 0000002BD08C: DACC0000 0B000513
	s_waitcnt lgkmcnt(4)                                       // 0000002BD094: BF89FC47
	v_add_f32_e32 v7, v7, v17                                  // 0000002BD098: 060E2307
	ds_bpermute_b32 v17, v19, v8                               // 0000002BD09C: DACC0000 11000813
	s_waitcnt lgkmcnt(4)                                       // 0000002BD0A4: BF89FC47
	v_add_f32_e32 v2, v2, v9                                   // 0000002BD0A8: 06041302
	s_waitcnt lgkmcnt(3)                                       // 0000002BD0AC: BF89FC37
	v_add_f32_e32 v4, v4, v10                                  // 0000002BD0B0: 06081504
	ds_bpermute_b32 v13, v19, v7                               // 0000002BD0B4: DACC0000 0D000713
	ds_bpermute_b32 v9, v19, v3                                // 0000002BD0BC: DACC0000 09000313
	s_waitcnt lgkmcnt(4)                                       // 0000002BD0C4: BF89FC47
	v_add_f32_e32 v6, v6, v12                                  // 0000002BD0C8: 060C1906
	ds_bpermute_b32 v18, v19, v2                               // 0000002BD0CC: DACC0000 12000213
	v_xor_b32_e32 v19, 2, v1                                   // 0000002BD0D4: 3A260282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BD0D8: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 0000002BD0DC: 7C9826A0
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 0000002BD0E0: 02262701
	v_lshlrev_b32_e32 v19, 2, v19                              // 0000002BD0E4: 30262682
	s_waitcnt lgkmcnt(2)                                       // 0000002BD0E8: BF89FC27
	v_add_f32_e32 v7, v7, v13                                  // 0000002BD0EC: 060E1B07
	s_waitcnt lgkmcnt(1)                                       // 0000002BD0F0: BF89FC17
	v_add_f32_e32 v3, v3, v9                                   // 0000002BD0F4: 06061303
	v_add_f32_e32 v9, v8, v17                                  // 0000002BD0F8: 06122308
	ds_bpermute_b32 v12, v19, v6                               // 0000002BD0FC: DACC0000 0C000613
	v_add_f32_e32 v5, v5, v11                                  // 0000002BD104: 060A1705
	ds_bpermute_b32 v13, v19, v7                               // 0000002BD108: DACC0000 0D000713
	s_waitcnt lgkmcnt(2)                                       // 0000002BD110: BF89FC27
	v_add_f32_e32 v11, v2, v18                                 // 0000002BD114: 06162502
	ds_bpermute_b32 v2, v19, v3                                // 0000002BD118: DACC0000 02000313
	ds_bpermute_b32 v8, v19, v4                                // 0000002BD120: DACC0000 08000413
	ds_bpermute_b32 v10, v19, v5                               // 0000002BD128: DACC0000 0A000513
	ds_bpermute_b32 v17, v19, v9                               // 0000002BD130: DACC0000 11000913
	ds_bpermute_b32 v18, v19, v11                              // 0000002BD138: DACC0000 12000B13
	v_xor_b32_e32 v19, 1, v1                                   // 0000002BD140: 3A260281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002BD144: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 0000002BD148: 7C9826A0
	v_cndmask_b32_e32 v1, v1, v19, vcc_lo                      // 0000002BD14C: 02022701
	v_lshlrev_b32_e32 v19, 2, v1                               // 0000002BD150: 30260282
	s_waitcnt lgkmcnt(3)                                       // 0000002BD154: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_add_f32 v2, v4, v8     // 0000002BD158: C9080503 01021104
	s_waitcnt lgkmcnt(2)                                       // 0000002BD160: BF89FC27
	v_dual_add_f32 v4, v6, v12 :: v_dual_add_f32 v3, v5, v10   // 0000002BD164: C9081906 04021505
	v_add_f32_e32 v8, v7, v13                                  // 0000002BD16C: 06101B07
	s_waitcnt lgkmcnt(0)                                       // 0000002BD170: BF89FC07
	v_dual_add_f32 v10, v9, v17 :: v_dual_add_f32 v11, v11, v18// 0000002BD174: C9082309 0A0A250B
	ds_bpermute_b32 v5, v19, v1                                // 0000002BD17C: DACC0000 05000113
	ds_bpermute_b32 v6, v19, v2                                // 0000002BD184: DACC0000 06000213
	ds_bpermute_b32 v7, v19, v3                                // 0000002BD18C: DACC0000 07000313
	ds_bpermute_b32 v9, v19, v4                                // 0000002BD194: DACC0000 09000413
	ds_bpermute_b32 v12, v19, v8                               // 0000002BD19C: DACC0000 0C000813
	ds_bpermute_b32 v13, v19, v10                              // 0000002BD1A4: DACC0000 0D000A13
	ds_bpermute_b32 v17, v19, v11                              // 0000002BD1AC: DACC0000 11000B13
	v_cmpx_eq_u32_e32 0, v15                                   // 0000002BD1B4: 7D941E80
	s_cbranch_execz 29                                         // 0000002BD1B8: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0xe30>
	s_waitcnt lgkmcnt(0)                                       // 0000002BD1BC: BF89FC07
	v_dual_add_f32 v11, v11, v17 :: v_dual_add_f32 v8, v8, v12 // 0000002BD1C0: C908230B 0B081908
	v_lshl_add_u32 v12, v14, s1, v16                           // 0000002BD1C8: D646000C 0440030E
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v1, v1, v5     // 0000002BD1D0: C9080D02 02000B01
	v_dual_add_f32 v10, v10, v13 :: v_dual_add_f32 v3, v3, v7  // 0000002BD1D8: C9081B0A 0A020F03
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002BD1E0: BF870003
	v_mad_u32_u24 v5, v12, 28, 0x400                           // 0000002BD1E4: D60B0005 03FD390C 00000400
	v_add_f32_e32 v4, v4, v9                                   // 0000002BD1F0: 06081304
	v_mad_u32_u24 v6, v12, 28, 0x408                           // 0000002BD1F4: D60B0006 03FD390C 00000408
	v_mad_u32_u24 v7, v12, 28, 0x410                           // 0000002BD200: D60B0007 03FD390C 00000410
	v_mul_u32_u24_e32 v9, 28, v12                              // 0000002BD20C: 1612189C
	ds_store_2addr_b32 v5, v1, v2 offset1:1                    // 0000002BD210: D8380100 00020105
	ds_store_2addr_b32 v6, v3, v4 offset1:1                    // 0000002BD218: D8380100 00040306
	ds_store_2addr_b32 v7, v8, v10 offset1:1                   // 0000002BD220: D8380100 000A0807
	ds_store_b32 v9, v11 offset:1048                           // 0000002BD228: D8340418 00000B09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002BD230: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BD234: BF870009
	s_and_b32 s0, s20, exec_lo                                 // 0000002BD238: 8B007E14
	s_cselect_b32 s0, 7, 28                                    // 0000002BD23C: 98009C87
	s_waitcnt lgkmcnt(0)                                       // 0000002BD240: BF89FC07
	v_cmp_gt_u32_e32 vcc_lo, s0, v0                            // 0000002BD244: 7C980000
	s_barrier                                                  // 0000002BD248: BFBD0000
	buffer_gl0_inv                                             // 0000002BD24C: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 0000002BD254: BE80206A
	s_cbranch_execz 425                                        // 0000002BD258: BFA501A9 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x1500>
	.long 0xd7054000                                           // 0000002BD25C: D7054000
	v_cndmask_b32_e32 v0, v0, v165, vcc_lo                     // 0000002BD260: 02014B00
	s_load_b32 s0, s[16:17], 0x40                              // 0000002BD264: F4000008 F8000040
	.long 0x7f063880                                           // 0000002BD26C: 7F063880
	v_mov_b32_e32 v4, 0                                        // 0000002BD270: 7E080280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD274: BF870093
	.long 0xd7395000                                           // 0000002BD278: D7395000
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 0000002BD27C: 02020088
	.long 0xd7041001                                           // 0000002BD280: D7041001
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000002BD284: 02020100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD288: BF870091
	.long 0xd7390001                                           // 0000002BD28C: D7390001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002BD290: 02020281
	.long 0xd7620001                                           // 0000002BD294: D7620001
	v_cndmask_b32_e32 v1, 0x7f, v1, vcc_lo                     // 0000002BD298: 020202FF 0000007F
	s_waitcnt lgkmcnt(0)                                       // 0000002BD2A0: BF89FC07
	s_sub_i32 s4, s2, s0                                       // 0000002BD2A4: 81840002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002BD2A8: BF870499
	s_ashr_i32 s5, s4, 31                                      // 0000002BD2AC: 86059F04
	s_lshl_b64 s[4:5], s[4:5], s21                             // 0000002BD2B0: 84841504
	.long 0xd7035000                                           // 0000002BD2B4: D7035000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002BD2B8: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD2BC: BF870091
	.long 0xd7391003                                           // 0000002BD2C0: D7391003
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000002BD2C4: 02020082
	.long 0xd7000001                                           // 0000002BD2C8: D7000001
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000002BD2CC: 02020604
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD2D0: BF870091
	v_add_co_ci_u32_e64 v2, null, s5, 0, s0                    // 0000002BD2D4: D5207C02 00010005
	v_cmp_gt_i64_e32 vcc_lo, s[10:11], v[1:2]                  // 0000002BD2DC: 7CA8020A
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000002BD2E0: 8B7E6A7E
	s_cbranch_execz 390                                        // 0000002BD2E4: BFA50186 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x1500>
	.long 0xd7054000                                           // 0000002BD2E8: D7054000
	v_cndmask_b32_e32 v0, v3, v135, vcc_lo                     // 0000002BD2EC: 02010F03
	v_lshlrev_b32_e32 v3, s1, v3                               // 0000002BD2F0: 30060601
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BD2F4: BF870112
	.long 0xd7041000                                           // 0000002BD2F8: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000002BD2FC: 02020100
	v_mul_u32_u24_e32 v3, 28, v3                               // 0000002BD300: 1606069C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD304: BF870092
	v_and_b32_e32 v5, 0xff, v0                                 // 0000002BD308: 360A00FF 000000FF
	v_lshl_add_u32 v3, v5, 2, v3                               // 0000002BD310: D6460003 040D0505
	ds_load_b32 v5, v3 offset:1024                             // 0000002BD318: D8D80400 05000003
	v_add_nc_u32_e32 v3, 28, v3                                // 0000002BD320: 4A06069C
	s_add_i32 s3, s3, -1                                       // 0000002BD324: 8103C103
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BD328: BF870009
	s_cmp_eq_u32 s3, 0                                         // 0000002BD32C: BF068003
	s_waitcnt lgkmcnt(0)                                       // 0000002BD330: BF89FC07
	v_add_f32_e32 v4, v4, v5                                   // 0000002BD334: 06080B04
	s_cbranch_scc0 65527                                       // 0000002BD338: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0xf18>
	s_clause 0x1                                               // 0000002BD33C: BF850001
	s_load_b64 s[4:5], s[16:17], 0x38                          // 0000002BD340: F4040108 F8000038
	s_load_b64 s[2:3], s[16:17], 0x8                           // 0000002BD348: F4040088 F8000008
	v_and_b32_e32 v3, 0xff, v0                                 // 0000002BD350: 360600FF 000000FF
	s_mov_b32 s6, -1                                           // 0000002BD358: BE8600C1
	s_mov_b32 s1, 0                                            // 0000002BD35C: BE810080
	s_mov_b32 s0, 0                                            // 0000002BD360: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000002BD364: BF89FC07
	s_cmp_lt_i32 s5, 3                                         // 0000002BD368: BF048305
	s_cbranch_scc1 191                                         // 0000002BD36C: BFA200BF <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x126c>
	s_cmp_gt_i32 s5, 3                                         // 0000002BD370: BF028305
	s_cbranch_scc0 125                                         // 0000002BD374: BFA1007D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x116c>
	s_cmp_gt_i32 s5, 4                                         // 0000002BD378: BF028405
	s_cbranch_scc0 70                                          // 0000002BD37C: BFA10046 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x1098>
	s_cmp_eq_u32 s5, 5                                         // 0000002BD380: BF068505
	s_mov_b32 s0, -1                                           // 0000002BD384: BE8000C1
	s_cbranch_scc0 66                                          // 0000002BD388: BFA10042 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x1094>
	v_lshrrev_b32_e32 v0, 23, v2                               // 0000002BD38C: 32000497
	s_lshr_b32 s0, s11, 31                                     // 0000002BD390: 85009F0B
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002BD394: F4040208 F8000010
	s_add_u32 s6, s10, s0                                      // 0000002BD39C: 8006000A
	s_addc_u32 s7, s11, 0                                      // 0000002BD3A0: 8207800B
	.long 0xd7006a00                                           // 0000002BD3A4: D7006A00
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002BD3A8: 02020101
	s_ashr_i64 s[6:7], s[6:7], 1                               // 0000002BD3AC: 86868106
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000002BD3B0: D5207C0A 01AA0480
	v_dual_mov_b32 v11, s3 :: v_dual_and_b32 v0, 0xfffffe00, v0// 0000002BD3B8: CA240003 0B0000FF FFFFFE00
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 0000002BD3C4: D6FE7C05 02020606
	v_bfe_u32 v14, v4, 16, 1                                   // 0000002BD3CC: D610000E 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD3D4: BF870093
	.long 0xd7016a08                                           // 0000002BD3D8: D7016A08
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002BD3DC: 02020101
	v_sub_co_ci_u32_e64 v9, null, v2, v10, vcc_lo              // 0000002BD3E0: D5217C09 01AA1502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BD3E8: BF870194
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 0000002BD3EC: D6FE7C06 041A0607
	.long 0xd700000c                                           // 0000002BD3F4: D700000C
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 0000002BD3F8: 020210FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002BD400: BF870003
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 0000002BD404: 7CA810FF 00000100
	v_mov_b32_e32 v7, s2                                       // 0000002BD40C: 7E0E0202
	v_add_co_ci_u32_e64 v13, null, -1, v9, s0                  // 0000002BD410: D5207C0D 000212C1
	s_mov_b32 s0, 0                                            // 0000002BD418: BE800080
	.long 0xd73c0005                                           // 0000002BD41C: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000002BD420: 02020A81
	s_waitcnt lgkmcnt(0)                                       // 0000002BD424: BF89FC07
	v_dual_cndmask_b32 v8, v12, v8 :: v_dual_cndmask_b32 v7, s8, v7// 0000002BD428: CA52110C 08060E08
	v_cndmask_b32_e32 v11, s9, v11, vcc_lo                     // 0000002BD430: 02161609
	v_cndmask_b32_e32 v9, v13, v9, vcc_lo                      // 0000002BD434: 0212130D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD438: BF870093
	.long 0xd7006a07                                           // 0000002BD43C: D7006A07
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 0000002BD440: 02020B07
	v_add_co_ci_u32_e64 v11, null, v11, v6, vcc_lo             // 0000002BD444: D5207C0B 01AA0D0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BD44C: BF870193
	.long 0xd73c0005                                           // 0000002BD450: D73C0005
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000002BD454: 02021081
	.long 0xd7006a00                                           // 0000002BD458: D7006A00
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000002BD45C: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002BD460: BF8701A1
	v_add_co_ci_u32_e64 v7, null, v11, v10, vcc_lo             // 0000002BD464: D5207C07 01AA150B
	v_add3_u32 v8, v4, v14, 0x7fff                             // 0000002BD46C: D6550008 03FE1D04 00007FFF
	.long 0xd7006a05                                           // 0000002BD478: D7006A05
	v_cndmask_b32_e32 v1, v0, v5, vcc_lo                       // 0000002BD47C: 02020B00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BD480: BF870001
	v_add_co_ci_u32_e64 v6, null, v7, v6, vcc_lo               // 0000002BD484: D5207C06 01AA0D07
	global_store_d16_hi_b16 v[5:6], v8, off                    // 0000002BD48C: DC960000 007C0805
	s_mov_b32 s6, 0                                            // 0000002BD494: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BD498: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002BD49C: 8B6A067E
	s_cbranch_vccz 49                                          // 0000002BD4A0: BFA30031 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x1168>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v4                           // 0000002BD4A4: 100008FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BD4AC: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002BD4B0: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002BD4B4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BD4B8: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 0000002BD4BC: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 0000002BD4C4: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 0000002BD4CC: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD4D0: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 0000002BD4D4: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 0000002BD4DC: 56121305
	v_mad_u64_u32 v[5:6], null, s10, v3, 0                     // 0000002BD4E0: D6FE7C05 0202060A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BD4E8: BF870112
	v_mul_f32_e32 v11, v10, v9                                 // 0000002BD4EC: 1016130A
	v_mad_u64_u32 v[6:7], null, s11, v3, v[6:7]                // 0000002BD4F0: D6FE7C06 041A060B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD4F8: BF870092
	v_fma_f32 v12, -v8, v11, v10                               // 0000002BD4FC: D613000C 242A1708
	v_fmac_f32_e32 v11, v12, v9                                // 0000002BD504: 5616130C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BD508: BF870113
	.long 0xd73c0005                                           // 0000002BD50C: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000002BD510: 02020A82
	v_fma_f32 v10, -v8, v11, v10                               // 0000002BD514: D613000A 242A1708
	.long 0xd73c0007                                           // 0000002BD51C: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000002BD520: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002BD524: BF870212
	v_div_fmas_f32 v9, v10, v9, v11                            // 0000002BD528: D6370009 042E130A
	.long 0xd7006a05                                           // 0000002BD530: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000002BD534: 02020A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BD538: BF870191
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002BD53C: D5207C06 01AA0C03
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 0000002BD544: D6270000 03CA0109
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD54C: BF870093
	.long 0xd7006a05                                           // 0000002BD550: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002BD554: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002BD558: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 0000002BD560: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 0000002BD568: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BD56C: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002BD570: 8B6A067E
	s_cbranch_vccz 60                                          // 0000002BD574: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x1268>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002BD578: D6100000 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD580: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002BD584: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002BD590: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD598: BF870091
	v_mul_f32_e32 v0, s4, v0                                   // 0000002BD59C: 10000004
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002BD5A0: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BD5A8: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002BD5AC: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002BD5B0: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BD5B4: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 0000002BD5B8: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 0000002BD5C0: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 0000002BD5C8: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD5CC: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 0000002BD5D0: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 0000002BD5D8: 56121305
	v_mad_u64_u32 v[5:6], null, s10, v3, 0                     // 0000002BD5DC: D6FE7C05 0202060A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD5E4: BF870092
	v_mul_f32_e32 v11, v10, v9                                 // 0000002BD5E8: 1016130A
	v_fma_f32 v7, -v8, v11, v10                                // 0000002BD5EC: D6130007 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002BD5F4: BF870211
	v_fmac_f32_e32 v11, v7, v9                                 // 0000002BD5F8: 56161307
	v_mad_u64_u32 v[6:7], null, s11, v3, v[6:7]                // 0000002BD5FC: D6FE7C06 041A060B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BD604: BF870112
	v_fma_f32 v7, -v8, v11, v10                                // 0000002BD608: D6130007 242A1708
	.long 0xd73c0005                                           // 0000002BD610: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000002BD614: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002BD618: BF8701A2
	v_div_fmas_f32 v9, v7, v9, v11                             // 0000002BD61C: D6370009 042E1307
	.long 0xd73c0007                                           // 0000002BD624: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000002BD628: 02020282
	.long 0xd7006a05                                           // 0000002BD62C: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000002BD630: 02020A02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002BD634: BF8701A3
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 0000002BD638: D6270000 03CA0109
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002BD640: D5207C06 01AA0C03
	.long 0xd7006a05                                           // 0000002BD648: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002BD64C: 02020F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BD650: BF870193
	v_add_f32_e32 v0, v0, v0                                   // 0000002BD654: 06000100
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002BD658: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 0000002BD660: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 0000002BD668: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002BD66C: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002BD670: 8B6A067E
	s_cbranch_vccz 73                                          // 0000002BD674: BFA30049 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x139c>
	s_cmp_gt_i32 s5, 1                                         // 0000002BD678: BF028105
	s_mov_b32 s1, -1                                           // 0000002BD67C: BE8100C1
	s_cbranch_scc0 64                                          // 0000002BD680: BFA10040 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x1384>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002BD684: D6100000 02052104
	s_mov_b32 s1, 0                                            // 0000002BD68C: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD690: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002BD694: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002BD6A0: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD6A8: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002BD6AC: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000002BD6B4: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD6B8: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002BD6BC: 060000F2
	v_div_scale_f32 v7, null, v0, v0, 1.0                      // 0000002BD6C0: D6FC7C07 03CA0100
	v_div_scale_f32 v9, vcc_lo, 1.0, v0, 1.0                   // 0000002BD6C8: D6FC6A09 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BD6D0: BF870292
	v_rcp_f32_e32 v8, v7                                       // 0000002BD6D4: 7E105507
	v_fma_f32 v5, -v7, v8, 1.0                                 // 0000002BD6D8: D6130005 23CA1107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BD6E0: BF870121
	v_fmac_f32_e32 v8, v5, v8                                  // 0000002BD6E4: 56101105
	v_mad_u64_u32 v[5:6], null, s10, v3, 0                     // 0000002BD6E8: D6FE7C05 0202060A
	v_mul_f32_e32 v10, v9, v8                                  // 0000002BD6F0: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD6F4: BF870091
	v_fma_f32 v11, -v7, v10, v9                                // 0000002BD6F8: D613000B 24261507
	v_fmac_f32_e32 v10, v11, v8                                // 0000002BD700: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BD704: BF870121
	v_fma_f32 v9, -v7, v10, v9                                 // 0000002BD708: D6130009 24261507
	v_mad_u64_u32 v[6:7], null, s11, v3, v[6:7]                // 0000002BD710: D6FE7C06 041A060B
	v_div_fmas_f32 v7, v9, v8, v10                             // 0000002BD718: D6370007 042A1109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BD720: BF870112
	.long 0xd73c0005                                           // 0000002BD724: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000002BD728: 02020A81
	v_div_fixup_f32 v0, v7, v0, 1.0                            // 0000002BD72C: D6270000 03CA0107
	.long 0xd73c0007                                           // 0000002BD734: D73C0007
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002BD738: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BD73C: BF870193
	.long 0xd7006a05                                           // 0000002BD740: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000002BD744: 02020A02
	v_bfe_u32 v9, v0, 16, 1                                    // 0000002BD748: D6100009 02052100
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002BD750: D5207C06 01AA0C03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BD758: BF870193
	.long 0xd7006a05                                           // 0000002BD75C: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002BD760: 02020F05
	v_add3_u32 v0, v0, v9, 0x7fff                              // 0000002BD764: D6550000 03FE1300 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002BD770: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002BD774: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v0, off                    // 0000002BD77C: DC960000 007C0005
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002BD784: 916A017E
	s_mov_b32 s1, 0                                            // 0000002BD788: BE810080
	s_cbranch_vccnz 3                                          // 0000002BD78C: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x139c>
	s_cmp_lg_u32 s5, 1                                         // 0000002BD790: BF078105
	s_mov_b32 s1, -1                                           // 0000002BD794: BE8100C1
	s_cselect_b32 s0, -1, 0                                    // 0000002BD798: 980080C1
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002BD79C: D6100005 02052104
	.long 0xd73c0000                                           // 0000002BD7A4: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002BD7A8: 02020281
	s_and_b32 vcc_lo, exec_lo, s0                              // 0000002BD7AC: 8B6A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002BD7B0: BF870002
	v_add3_u32 v2, v4, v5, 0x7fff                              // 0000002BD7B4: D6550002 03FE0B04 00007FFF
	s_cbranch_vccz 20                                          // 0000002BD7C0: BFA30014 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x1414>
	v_mad_u64_u32 v[4:5], null, s10, v3, 0                     // 0000002BD7C4: D6FE7C04 0202060A
	s_mov_b32 s1, 0                                            // 0000002BD7CC: BE810080
	v_mad_u64_u32 v[5:6], null, s11, v3, v[5:6]                // 0000002BD7D0: D6FE7C05 0416060B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD7D8: BF870091
	.long 0xd73c0004                                           // 0000002BD7DC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002BD7E0: 02020881
	.long 0xd7006a04                                           // 0000002BD7E4: D7006A04
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 0000002BD7E8: 02020802
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BD7EC: BF870111
	v_add_co_ci_u32_e64 v5, null, s3, v5, vcc_lo               // 0000002BD7F0: D5207C05 01AA0A03
	.long 0xd7006a04                                           // 0000002BD7F8: D7006A04
	v_cndmask_b32_e32 v1, v4, v0, vcc_lo                       // 0000002BD7FC: 02020104
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002BD800: BF870001
	v_add_co_ci_u32_e64 v5, null, v5, v1, vcc_lo               // 0000002BD804: D5207C05 01AA0305
	global_store_d16_hi_b16 v[4:5], v2, off                    // 0000002BD80C: DC960000 007C0204
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002BD814: 916A017E
	s_cbranch_vccnz 57                                         // 0000002BD818: BFA40039 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x1500>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD81C: BF870091
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000002BD820: 360404FF FFFF0000
	v_mul_f32_e32 v2, s4, v2                                   // 0000002BD828: 10040404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD82C: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v2                           // 0000002BD830: 100804FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 0000002BD838: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD83C: BF870095
	v_add_f32_e32 v7, 1.0, v4                                  // 0000002BD840: 060E08F2
	v_div_scale_f32 v6, null, v7, v7, v2                       // 0000002BD844: D6FC7C06 040A0F07
	v_div_scale_f32 v9, vcc_lo, v2, v7, v2                     // 0000002BD84C: D6FC6A09 040A0F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002BD854: BF870292
	v_rcp_f32_e32 v8, v6                                       // 0000002BD858: 7E105506
	v_fma_f32 v4, -v6, v8, 1.0                                 // 0000002BD85C: D6130004 23CA1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BD864: BF870121
	v_fmac_f32_e32 v8, v4, v8                                  // 0000002BD868: 56101104
	v_mad_u64_u32 v[4:5], null, s10, v3, 0                     // 0000002BD86C: D6FE7C04 0202060A
	v_mul_f32_e32 v10, v9, v8                                  // 0000002BD874: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD878: BF870091
	v_fma_f32 v11, -v6, v10, v9                                // 0000002BD87C: D613000B 24261506
	v_fmac_f32_e32 v10, v11, v8                                // 0000002BD884: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002BD888: BF870121
	v_fma_f32 v9, -v6, v10, v9                                 // 0000002BD88C: D6130009 24261506
	v_mad_u64_u32 v[5:6], null, s11, v3, v[5:6]                // 0000002BD894: D6FE7C05 0416060B
	v_div_fmas_f32 v3, v9, v8, v10                             // 0000002BD89C: D6370003 042A1109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BD8A4: BF870191
	v_div_fixup_f32 v6, v3, v7, v2                             // 0000002BD8A8: D6270006 040A0F03
	.long 0xd73c0002                                           // 0000002BD8B0: D73C0002
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002BD8B4: 02020881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002BD8B8: BF870112
	v_bfe_u32 v4, v6, 16, 1                                    // 0000002BD8BC: D6100004 02052106
	.long 0xd7006a02                                           // 0000002BD8C4: D7006A02
	v_cndmask_b32_e32 v1, s2, v2, vcc_lo                       // 0000002BD8C8: 02020402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002BD8CC: BF870191
	v_add_co_ci_u32_e64 v3, null, s3, v3, vcc_lo               // 0000002BD8D0: D5207C03 01AA0603
	v_add3_u32 v4, v6, v4, 0x7fff                              // 0000002BD8D8: D6550004 03FE0906 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002BD8E4: BF870093
	.long 0xd7006a00                                           // 0000002BD8E8: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 0000002BD8EC: 02020102
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 0000002BD8F0: D5207C01 01AA0303
	global_store_d16_hi_b16 v[0:1], v4, off                    // 0000002BD8F8: DC960000 007C0400
	s_nop 0                                                    // 0000002BD900: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000002BD904: BFB60003
	s_endpgm                                                   // 0000002BD908: BFB00000
		...

