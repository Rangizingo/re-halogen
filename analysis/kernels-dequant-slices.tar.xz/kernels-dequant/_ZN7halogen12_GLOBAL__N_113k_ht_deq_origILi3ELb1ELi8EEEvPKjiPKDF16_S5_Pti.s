000000000049fa00 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi3ELb1ELi8EEEvPKjiPKDF16_S5_Pti>:
; _ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi3ELb1ELi8EEEvPKjiPKDF16_S5_Pti():
	v_and_b32_e32 v18, 31, v0                                  // 00000049FA00: 3624009F
	s_clause 0x1                                               // 00000049FA04: BF850001
	s_load_b32 s13, s[0:1], 0x28                               // 00000049FA08: F4000340 F8000028
	s_load_b32 s12, s[0:1], 0x8                                // 00000049FA10: F4000300 F8000008
	v_bfe_u32 v21, v0, 4, 1                                    // 00000049FA18: D6100015 02050900
	v_lshrrev_b32_e32 v17, 7, v0                               // 00000049FA20: 32220087
	s_load_b64 s[10:11], s[0:1], null                          // 00000049FA24: F4040280 F8000000
	v_lshl_or_b32 v22, v18, 3, 4                               // 00000049FA2C: D6560016 02110712
	s_delay_alu instid0(VALU_DEP_3)                            // 00000049FA34: BF870003
	v_dual_mov_b32 v14, 0 :: v_dual_lshlrev_b32 v1, 6, v21     // 00000049FA38: CA220080 0E002A86
	s_clause 0x1                                               // 00000049FA40: BF850001
	s_load_b128 s[4:7], s[0:1], 0x10                           // 00000049FA44: F4080100 F8000010
	s_load_b64 s[8:9], s[0:1], 0x20                            // 00000049FA4C: F4040200 F8000020
	v_lshrrev_b32_e32 v19, 5, v0                               // 00000049FA54: 32260085
	v_mad_u32_u24 v23, v22, 3, 0x2f0                           // 00000049FA58: D60B0017 03FD0716 000002F0
	v_mad_u32_u24 v24, v18, 24, 0x2f0                          // 00000049FA64: D60B0018 03FD3112 000002F0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000049FA70: BF8700B2
	v_lshrrev_b32_e32 v15, 5, v23                              // 00000049FA74: 321E2E85
	s_waitcnt lgkmcnt(0)                                       // 00000049FA78: BF89FC07
	s_cmp_eq_u32 s13, 0                                        // 00000049FA7C: BF06800D
	.long 0xd7030007                                           // 00000049FA80: D7030007
	v_cndmask_b32_e32 v0, v15, v129, vcc_lo                    // 00000049FA84: 0201030F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000049FA88: BF870002
	v_subrev_nc_u32_e32 v15, 24, v15                           // 00000049FA8C: 4E1E1E98
	v_and_b32_e32 v20, 15, v0                                  // 00000049FA90: 3628008F
	s_cselect_b32 s0, s3, s2                                   // 00000049FA94: 98000203
	s_cselect_b32 s3, s2, s3                                   // 00000049FA98: 98030302
	s_lshl_b32 s2, s0, 7                                       // 00000049FA9C: 84028700
	s_lshl_b32 s1, s3, 7                                       // 00000049FAA0: 84018703
	v_lshlrev_b32_e32 v2, 1, v20                               // 00000049FAA4: 30042881
	v_lshl_or_b32 v3, s0, 3, v19                               // 00000049FAA8: D6560003 044D0600
	s_ashr_i32 s13, s12, 31                                    // 00000049FAB0: 860D9F0C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000049FAB4: BF870119
	s_lshr_b32 s0, s13, 28                                     // 00000049FAB8: 85009C0D
	v_or3_b32 v2, v2, v17, v1                                  // 00000049FABC: D6580002 04062302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000049FAC4: BF8704A2
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000049FAC8: 3408069F
	s_add_i32 s0, s12, s0                                      // 00000049FACC: 8100000C
	s_ashr_i32 s0, s0, 4                                       // 00000049FAD0: 86008400
	s_delay_alu instid0(VALU_DEP_2)                            // 00000049FAD4: BF870002
	v_or_b32_e32 v1, s2, v2                                    // 00000049FAD8: 38020402
	v_or_b32_e32 v5, s1, v2                                    // 00000049FADC: 380A0401
	v_mad_i64_i32 v[11:12], null, s3, s0, v[3:4]               // 00000049FAE0: D6FF7C0B 040C0003
	s_movk_i32 s3, 0x1eee                                      // 00000049FAE8: B0031EEE
	.long 0xd4490000                                           // 00000049FAEC: D4490000
	v_cndmask_b32_e32 v1, 0x1ff, v0, vcc_lo                    // 00000049FAF0: 020200FF 000001FF
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000049FAF8: 3404029F
	v_ashrrev_i32_e32 v6, 31, v5                               // 00000049FAFC: 340C0A9F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000049FB00: BF870112
	.long 0xd73c0001                                           // 00000049FB04: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000049FB08: 02020281
	.long 0xd73c0003                                           // 00000049FB0C: D73C0003
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000049FB10: 02020A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000049FB14: BF870092
	.long 0xd7006a05                                           // 00000049FB18: D7006A05
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000049FB1C: 02020204
	v_add_co_ci_u32_e64 v6, null, s5, v2, vcc_lo               // 00000049FB20: D5207C06 01AA0405
	s_delay_alu instid0(VALU_DEP_3)                            // 00000049FB28: BF870003
	.long 0xd7006a08                                           // 00000049FB2C: D7006A08
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 00000049FB30: 02020606
	s_clause 0x1                                               // 00000049FB34: BF850001
	global_load_d16_hi_b16 v2, v[5:6], off                     // 00000049FB38: DC8E0000 027C0005
	global_load_d16_b16 v2, v[5:6], off offset:64              // 00000049FB40: DC820040 027C0005
	.long 0xd7620005                                           // 00000049FB48: D7620005
	v_cndmask_b32_e32 v1, 0xff, v7, vcc_lo                     // 00000049FB4C: 02020EFF 000000FF
	v_add_co_ci_u32_e64 v9, null, s7, v4, vcc_lo               // 00000049FB54: D5207C09 01AA0807
	v_lshrrev_b32_e32 v6, 5, v24                               // 00000049FB5C: 320C3085
	.long 0xd73c0003                                           // 00000049FB60: D73C0003
	v_cndmask_b32_e32 v1, 3, v11, vcc_lo                       // 00000049FB64: 02021683
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049FB68: BF870004
	.long 0xd7050005                                           // 00000049FB6C: D7050005
	v_cndmask_b32_e32 v1, 0xab, v5, vcc_lo                     // 00000049FB70: 02020AFF 000000AB
	s_clause 0x1                                               // 00000049FB78: BF850001
	global_load_d16_hi_b16 v1, v[8:9], off                     // 00000049FB7C: DC8E0000 017C0008
	global_load_d16_b16 v1, v[8:9], off offset:64              // 00000049FB84: DC820040 017C0008
	v_cmp_ne_u32_e32 vcc_lo, 0, v18                            // 00000049FB8C: 7C9A2480
	v_subrev_nc_u32_e32 v8, 24, v6                             // 00000049FB90: 4E100C98
	v_add_nc_u32_e32 v6, 0xe9, v6                              // 00000049FB94: 4A0C0CFF 000000E9
	v_mad_u64_u32 v[9:10], null, 0x60, v3, s[10:11]            // 00000049FB9C: D6FE7C09 002A06FF 00000060
	.long 0xd7390005                                           // 00000049FBA8: D7390005
	v_cndmask_b32_e32 v1, 12, v5, vcc_lo                       // 00000049FBAC: 02020A8C
	v_or_b32_e32 v3, 7, v3                                     // 00000049FBB0: 38060687
	v_cndmask_b32_e32 v13, 23, v8, vcc_lo                      // 00000049FBB4: 021A1097
	v_alignbit_b32 v8, v12, v11, 29                            // 00000049FBB8: D6160008 0276170C
	v_and_b32_e32 v12, 0xff, v6                                // 00000049FBC0: 36180CFF 000000FF
	.long 0xd7054007                                           // 00000049FBC8: D7054007
	v_cndmask_b32_e32 v0, v5, v152, vcc_lo                     // 00000049FBCC: 02013105
	v_cmp_lt_u32_e32 vcc_lo, 5, v22                            // 00000049FBD0: 7C922C85
	.long 0xd73c0005                                           // 00000049FBD4: D73C0005
	v_cndmask_b32_e32 v1, 2, v13, vcc_lo                       // 00000049FBD8: 02021A82
	v_mad_u64_u32 v[10:11], null, 0x60, v8, v[10:11]           // 00000049FBDC: D6FE7C0A 042A10FF 00000060
	v_lshlrev_b32_e32 v25, 2, v12                              // 00000049FBE8: 30321882
	v_cndmask_b32_e32 v13, 23, v15, vcc_lo                     // 00000049FBEC: 021A1E97
	.long 0xd704100f                                           // 00000049FBF0: D704100F
	v_cndmask_b32_e32 v1, v7, v7, vcc_lo                       // 00000049FBF4: 02020F07
	.long 0xd7006a0b                                           // 00000049FBF8: D7006A0B
	v_cndmask_b32_e32 v1, v9, v5, vcc_lo                       // 00000049FBFC: 02020B09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049FC00: BF870211
	v_add_co_ci_u32_e64 v12, null, v10, v6, vcc_lo             // 00000049FC04: D5207C0C 01AA0D0A
	.long 0xd73c0007                                           // 00000049FC0C: D73C0007
	v_cndmask_b32_e32 v1, 2, v13, vcc_lo                       // 00000049FC10: 02021A82
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000049FC14: BF8700A4
	v_and_b32_e32 v13, 0xff, v15                               // 00000049FC18: 361A1EFF 000000FF
	.long 0xd7006a0f                                           // 00000049FC20: D7006A0F
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 00000049FC24: 02023309
	v_add_co_ci_u32_e64 v16, null, 0, v10, vcc_lo              // 00000049FC28: D5207C10 01AA1480
	s_clause 0x7                                               // 00000049FC30: BF850007
	global_load_b32 v28, v[11:12], off                         // 00000049FC34: DC520000 1C7C000B
	global_load_b32 v27, v[15:16], off                         // 00000049FC3C: DC520000 1B7C000F
	global_load_b32 v30, v[11:12], off offset:96               // 00000049FC44: DC520060 1E7C000B
	global_load_b32 v32, v[11:12], off offset:192              // 00000049FC4C: DC5200C0 207C000B
	global_load_b32 v34, v[11:12], off offset:288              // 00000049FC54: DC520120 227C000B
	global_load_b32 v36, v[11:12], off offset:384              // 00000049FC5C: DC520180 247C000B
	global_load_b32 v38, v[11:12], off offset:480              // 00000049FC64: DC5201E0 267C000B
	global_load_b32 v40, v[11:12], off offset:576              // 00000049FC6C: DC520240 287C000B
	v_mad_u64_u32 v[11:12], null, 0x60, v3, s[10:11]           // 00000049FC74: D6FE7C0B 002A06FF 00000060
	v_lshlrev_b32_e32 v26, 2, v13                              // 00000049FC80: 30341A82
	.long 0xd7006a0d                                           // 00000049FC84: D7006A0D
	v_cndmask_b32_e32 v1, v9, v7, vcc_lo                       // 00000049FC88: 02020F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049FC8C: BF870191
	v_add_co_ci_u32_e64 v14, null, v10, v8, vcc_lo             // 00000049FC90: D5207C0E 01AA110A
	.long 0xd7006a09                                           // 00000049FC98: D7006A09
	v_cndmask_b32_e32 v1, v9, v26, vcc_lo                      // 00000049FC9C: 02023509
	s_delay_alu instid0(VALU_DEP_3)                            // 00000049FCA0: BF870003
	v_mad_u64_u32 v[3:4], null, 0x60, v4, v[12:13]             // 00000049FCA4: D6FE7C03 043208FF 00000060
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo              // 00000049FCB0: D5207C0A 01AA1480
	.long 0xd7006a04                                           // 00000049FCB8: D7006A04
	v_cndmask_b32_e32 v1, v11, v5, vcc_lo                      // 00000049FCBC: 02020B0B
	s_clause 0xf                                               // 00000049FCC0: BF85000F
	global_load_b32 v42, v[13:14], off                         // 00000049FCC4: DC520000 2A7C000D
	global_load_b32 v29, v[15:16], off offset:96               // 00000049FCCC: DC520060 1D7C000F
	global_load_b32 v44, v[13:14], off offset:96               // 00000049FCD4: DC520060 2C7C000D
	global_load_b32 v31, v[15:16], off offset:192              // 00000049FCDC: DC5200C0 1F7C000F
	global_load_b32 v33, v[15:16], off offset:288              // 00000049FCE4: DC520120 217C000F
	global_load_b32 v35, v[15:16], off offset:384              // 00000049FCEC: DC520180 237C000F
	global_load_b32 v37, v[15:16], off offset:480              // 00000049FCF4: DC5201E0 257C000F
	global_load_b32 v39, v[15:16], off offset:576              // 00000049FCFC: DC520240 277C000F
	global_load_b32 v41, v[9:10], off                          // 00000049FD04: DC520000 297C0009
	global_load_b32 v43, v[9:10], off offset:96                // 00000049FD0C: DC520060 2B7C0009
	global_load_b32 v16, v[13:14], off offset:192              // 00000049FD14: DC5200C0 107C000D
	global_load_b32 v15, v[9:10], off offset:192               // 00000049FD1C: DC5200C0 0F7C0009
	global_load_b32 v46, v[13:14], off offset:288              // 00000049FD24: DC520120 2E7C000D
	global_load_b32 v48, v[13:14], off offset:384              // 00000049FD2C: DC520180 307C000D
	global_load_b32 v50, v[13:14], off offset:480              // 00000049FD34: DC5201E0 327C000D
	global_load_b32 v14, v[13:14], off offset:576              // 00000049FD3C: DC520240 0E7C000D
	v_add_co_ci_u32_e64 v5, null, v3, v6, vcc_lo               // 00000049FD44: D5207C05 01AA0D03
	.long 0xd7006a33                                           // 00000049FD4C: D7006A33
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 00000049FD50: 0202330B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000049FD54: BF8700A1
	v_add_co_ci_u32_e64 v52, null, 0, v3, vcc_lo               // 00000049FD58: D5207C34 01AA0680
	.long 0xd7006a06                                           // 00000049FD60: D7006A06
	v_cndmask_b32_e32 v1, v11, v7, vcc_lo                      // 00000049FD64: 02020F0B
	v_add_co_ci_u32_e64 v7, null, v3, v8, vcc_lo               // 00000049FD68: D5207C07 01AA1103
	.long 0xd7006a0b                                           // 00000049FD70: D7006A0B
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 00000049FD74: 0202350B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049FD78: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v3, vcc_lo               // 00000049FD7C: D5207C0C 01AA0680
	s_clause 0x7                                               // 00000049FD84: BF850007
	global_load_b32 v45, v[9:10], off offset:288               // 00000049FD88: DC520120 2D7C0009
	global_load_b32 v47, v[9:10], off offset:384               // 00000049FD90: DC520180 2F7C0009
	global_load_b32 v49, v[9:10], off offset:480               // 00000049FD98: DC5201E0 317C0009
	global_load_b32 v13, v[9:10], off offset:576               // 00000049FDA0: DC520240 0D7C0009
	global_load_b32 v26, v[4:5], off                           // 00000049FDA8: DC520000 1A7C0004
	global_load_b32 v25, v[51:52], off                         // 00000049FDB0: DC520000 197C0033
	global_load_b32 v52, v[6:7], off                           // 00000049FDB8: DC520000 347C0006
	global_load_b32 v51, v[11:12], off                         // 00000049FDC0: DC520000 337C000B
	v_lshlrev_b32_e32 v4, 3, v21                               // 00000049FDC8: 30082A83
	v_or_b32_e32 v6, 0x70, v20                                 // 00000049FDCC: 380C28FF 00000070
	v_and_b32_e32 v7, 0x7e0, v24                               // 00000049FDD4: 360E30FF 000007E0
	v_or_b32_e32 v5, 16, v20                                   // 00000049FDDC: 380A2890
	v_lshlrev_b32_e32 v21, 9, v20                              // 00000049FDE0: 302A2889
	v_lshl_or_b32 v4, v19, 4, v4                               // 00000049FDE4: D6560004 04110913
	v_and_b32_e32 v8, 31, v6                                   // 00000049FDEC: 36100C9F
	v_lshlrev_b32_e32 v56, 9, v6                               // 00000049FDF0: 30700C89
	v_mad_i32_i24 v6, 0xffffffe8, v18, v7                      // 00000049FDF4: D60A0006 041E24FF FFFFFFE8
	v_and_b32_e32 v7, 0x7e0, v23                               // 00000049FE00: 360E2EFF 000007E0
	v_xor_b32_e32 v9, v4, v20                                  // 00000049FE08: 3A122904
	v_or_b32_e32 v10, 1, v4                                    // 00000049FE0C: 38140881
	v_or_b32_e32 v11, 2, v4                                    // 00000049FE10: 38160882
	v_or_b32_e32 v12, 3, v4                                    // 00000049FE14: 38180883
	v_or_b32_e32 v23, 4, v4                                    // 00000049FE18: 382E0884
	v_or_b32_e32 v57, 5, v4                                    // 00000049FE1C: 38720885
	v_or_b32_e32 v58, 6, v4                                    // 00000049FE20: 38740886
	v_or_b32_e32 v59, 7, v4                                    // 00000049FE24: 38760887
	v_add_nc_u32_e32 v82, 0xfffffd3d, v6                       // 00000049FE28: 4AA40CFF FFFFFD3D
	v_add_nc_u32_e32 v83, 0xfffffd3a, v6                       // 00000049FE30: 4AA60CFF FFFFFD3A
	v_add_nc_u32_e32 v84, 0xfffffd37, v6                       // 00000049FE38: 4AA80CFF FFFFFD37
	v_add_nc_u32_e32 v85, 0xfffffd34, v6                       // 00000049FE40: 4AAA0CFF FFFFFD34
	v_mad_i32_i24 v6, v22, -3, v7                              // 00000049FE48: D60A0006 041D8716
	v_lshlrev_b32_e32 v7, 2, v9                                // 00000049FE50: 300E1282
	v_xor_b32_e32 v9, v10, v20                                 // 00000049FE54: 3A12290A
	v_xor_b32_e32 v22, v11, v20                                // 00000049FE58: 3A2C290B
	v_xor_b32_e32 v63, v12, v20                                // 00000049FE5C: 3A7E290C
	v_xor_b32_e32 v64, v23, v20                                // 00000049FE60: 3A802917
	v_xor_b32_e32 v65, v57, v20                                // 00000049FE64: 3A822939
	v_xor_b32_e32 v66, v58, v20                                // 00000049FE68: 3A84293A
	v_xor_b32_e32 v20, v59, v20                                // 00000049FE6C: 3A28293B
	v_or_b32_e32 v53, 0x4000, v21                              // 00000049FE70: 386A2AFF 00004000
	v_or_b32_e32 v54, 0x8000, v21                              // 00000049FE78: 386C2AFF 00008000
	v_add_nc_u32_e32 v87, 0xfffffd3a, v6                       // 00000049FE80: 4AAE0CFF FFFFFD3A
	v_lshlrev_b32_e32 v75, 2, v9                               // 00000049FE88: 30961282
	v_lshlrev_b32_e32 v22, 2, v22                              // 00000049FE8C: 302C2C82
	v_lshlrev_b32_e32 v63, 2, v63                              // 00000049FE90: 307E7E82
	v_lshlrev_b32_e32 v64, 2, v64                              // 00000049FE94: 30808082
	v_lshlrev_b32_e32 v65, 2, v65                              // 00000049FE98: 30828282
	v_lshlrev_b32_e32 v66, 2, v66                              // 00000049FE9C: 30848482
	v_lshlrev_b32_e32 v20, 2, v20                              // 00000049FEA0: 30282882
	v_lshlrev_b32_e32 v24, 9, v5                               // 00000049FEA4: 30300A89
	v_or_b32_e32 v55, 0xc000, v21                              // 00000049FEA8: 386E2AFF 0000C000
	v_xor_b32_e32 v60, v4, v5                                  // 00000049FEB0: 3A780B04
	v_add_nc_u32_e32 v88, 0xfffffd37, v6                       // 00000049FEB4: 4AB00CFF FFFFFD37
	v_xor_b32_e32 v4, v4, v8                                   // 00000049FEBC: 3A081104
	v_xor_b32_e32 v67, v10, v5                                 // 00000049FEC0: 3A860B0A
	v_xor_b32_e32 v68, v11, v5                                 // 00000049FEC4: 3A880B0B
	v_xor_b32_e32 v69, v12, v5                                 // 00000049FEC8: 3A8A0B0C
	v_xor_b32_e32 v70, v23, v5                                 // 00000049FECC: 3A8C0B17
	v_xor_b32_e32 v71, v57, v5                                 // 00000049FED0: 3A8E0B39
	v_xor_b32_e32 v72, v58, v5                                 // 00000049FED4: 3A900B3A
	v_xor_b32_e32 v5, v59, v5                                  // 00000049FED8: 3A0A0B3B
	v_xor_b32_e32 v10, v10, v8                                 // 00000049FEDC: 3A14110A
	v_xor_b32_e32 v73, v11, v8                                 // 00000049FEE0: 3A92110B
	v_xor_b32_e32 v74, v12, v8                                 // 00000049FEE4: 3A94110C
	v_xor_b32_e32 v23, v23, v8                                 // 00000049FEE8: 3A2E1117
	v_xor_b32_e32 v57, v57, v8                                 // 00000049FEEC: 3A721139
	v_xor_b32_e32 v58, v58, v8                                 // 00000049FEF0: 3A74113A
	v_xor_b32_e32 v59, v59, v8                                 // 00000049FEF4: 3A76113B
	v_add_nc_u32_e32 v92, v53, v7                              // 00000049FEF8: 4AB80F35
	v_add_nc_u32_e32 v94, v54, v7                              // 00000049FEFC: 4ABC0F36
	v_add_nc_u32_e32 v110, v53, v75                            // 00000049FF00: 4ADC9735
	v_add_nc_u32_e32 v111, v53, v22                            // 00000049FF04: 4ADE2D35
	v_add_nc_u32_e32 v112, v53, v63                            // 00000049FF08: 4AE07F35
	v_add_nc_u32_e32 v113, v53, v64                            // 00000049FF0C: 4AE28135
	v_add_nc_u32_e32 v114, v53, v65                            // 00000049FF10: 4AE48335
	v_add_nc_u32_e32 v115, v53, v66                            // 00000049FF14: 4AE68535
	v_add_nc_u32_e32 v116, v53, v20                            // 00000049FF18: 4AE82935
	v_add_nc_u32_e32 v124, v54, v75                            // 00000049FF1C: 4AF89736
	v_add_nc_u32_e32 v125, v54, v22                            // 00000049FF20: 4AFA2D36
	v_add_nc_u32_e32 v126, v54, v63                            // 00000049FF24: 4AFC7F36
	v_add_nc_u32_e32 v127, v54, v64                            // 00000049FF28: 4AFE8136
	v_add_nc_u32_e32 v128, v54, v65                            // 00000049FF2C: 4B008336
	v_add_nc_u32_e32 v129, v54, v66                            // 00000049FF30: 4B028536
	v_add_nc_u32_e32 v130, v54, v20                            // 00000049FF34: 4B042936
	v_or_b32_e32 v61, 0x4000, v24                              // 00000049FF38: 387A30FF 00004000
	v_or_b32_e32 v62, 0x8000, v24                              // 00000049FF40: 387C30FF 00008000
	v_lshlrev_b32_e32 v60, 2, v60                              // 00000049FF48: 30787882
	v_add_nc_u32_e32 v12, v55, v7                              // 00000049FF4C: 4A180F37
	v_add_nc_u32_e32 v138, v55, v75                            // 00000049FF50: 4B149737
	v_add_nc_u32_e32 v139, v55, v22                            // 00000049FF54: 4B162D37
	v_add_nc_u32_e32 v140, v55, v63                            // 00000049FF58: 4B187F37
	v_add_nc_u32_e32 v141, v55, v64                            // 00000049FF5C: 4B1A8137
	v_add_nc_u32_e32 v142, v55, v65                            // 00000049FF60: 4B1C8337
	v_add_nc_u32_e32 v143, v55, v66                            // 00000049FF64: 4B1E8537
	v_add_nc_u32_e32 v144, v55, v20                            // 00000049FF68: 4B202937
	v_lshl_add_u32 v4, v4, 2, v56                              // 00000049FF6C: D6460004 04E10504
	v_add_nc_u32_e32 v86, 0xfffffd3d, v6                       // 00000049FF74: 4AAC0CFF FFFFFD3D
	v_add_nc_u32_e32 v89, 0xfffffd34, v6                       // 00000049FF7C: 4AB20CFF FFFFFD34
	v_add_nc_u32_e32 v90, v21, v7                              // 00000049FF84: 4AB40F15
	v_lshlrev_b32_e32 v67, 2, v67                              // 00000049FF88: 30868682
	v_lshlrev_b32_e32 v68, 2, v68                              // 00000049FF8C: 30888882
	v_lshlrev_b32_e32 v69, 2, v69                              // 00000049FF90: 308A8A82
	v_lshlrev_b32_e32 v70, 2, v70                              // 00000049FF94: 308C8C82
	v_lshlrev_b32_e32 v71, 2, v71                              // 00000049FF98: 308E8E82
	v_lshlrev_b32_e32 v72, 2, v72                              // 00000049FF9C: 30909082
	v_lshlrev_b32_e32 v76, 2, v5                               // 00000049FFA0: 30980A82
	v_lshl_add_u32 v11, v10, 2, v56                            // 00000049FFA4: D646000B 04E1050A
	v_lshl_add_u32 v10, v73, 2, v56                            // 00000049FFAC: D646000A 04E10549
	v_lshl_add_u32 v9, v74, 2, v56                             // 00000049FFB4: D6460009 04E1054A
	v_lshl_add_u32 v8, v23, 2, v56                             // 00000049FFBC: D6460008 04E10517
	v_lshl_add_u32 v7, v57, 2, v56                             // 00000049FFC4: D6460007 04E10539
	v_lshl_add_u32 v6, v58, 2, v56                             // 00000049FFCC: D6460006 04E1053A
	v_lshl_add_u32 v5, v59, 2, v56                             // 00000049FFD4: D6460005 04E1053B
	v_add_nc_u32_e32 v91, v24, v60                             // 00000049FFDC: 4AB67918
	v_add_nc_u32_e32 v93, v61, v60                             // 00000049FFE0: 4ABA793D
	v_add_nc_u32_e32 v95, v62, v60                             // 00000049FFE4: 4ABE793E
	v_add_nc_u32_e32 v117, v61, v67                            // 00000049FFE8: 4AEA873D
	v_add_nc_u32_e32 v118, v61, v68                            // 00000049FFEC: 4AEC893D
	v_add_nc_u32_e32 v119, v61, v69                            // 00000049FFF0: 4AEE8B3D
	v_add_nc_u32_e32 v120, v61, v70                            // 00000049FFF4: 4AF08D3D
	v_add_nc_u32_e32 v121, v61, v71                            // 00000049FFF8: 4AF28F3D
	v_add_nc_u32_e32 v122, v61, v72                            // 00000049FFFC: 4AF4913D
	v_add_nc_u32_e32 v123, v61, v76                            // 0000004A0000: 4AF6993D
	v_add_nc_u32_e32 v131, v62, v67                            // 0000004A0004: 4B06873E
	v_add_nc_u32_e32 v132, v62, v68                            // 0000004A0008: 4B08893E
	v_add_nc_u32_e32 v133, v62, v69                            // 0000004A000C: 4B0A8B3E
	v_add_nc_u32_e32 v134, v62, v70                            // 0000004A0010: 4B0C8D3E
	v_add_nc_u32_e32 v135, v62, v71                            // 0000004A0014: 4B0E8F3E
	v_add_nc_u32_e32 v136, v62, v72                            // 0000004A0018: 4B10913E
	v_add_nc_u32_e32 v137, v62, v76                            // 0000004A001C: 4B12993E
	v_add_nc_u32_e32 v98, v21, v63                             // 0000004A0020: 4AC47F15
	v_add_nc_u32_e32 v99, v21, v64                             // 0000004A0024: 4AC68115
	v_add_nc_u32_e32 v100, v21, v65                            // 0000004A0028: 4AC88315
	v_add_nc_u32_e32 v101, v21, v66                            // 0000004A002C: 4ACA8515
	v_add_nc_u32_e32 v103, v24, v67                            // 0000004A0030: 4ACE8718
	v_add_nc_u32_e32 v96, v21, v75                             // 0000004A0034: 4AC09715
	v_add_nc_u32_e32 v97, v21, v22                             // 0000004A0038: 4AC22D15
	v_add_nc_u32_e32 v102, v21, v20                            // 0000004A003C: 4ACC2915
	v_add_nc_u32_e32 v104, v24, v68                            // 0000004A0040: 4AD08918
	v_add_nc_u32_e32 v105, v24, v69                            // 0000004A0044: 4AD28B18
	v_add_nc_u32_e32 v106, v24, v70                            // 0000004A0048: 4AD48D18
	v_add_nc_u32_e32 v107, v24, v71                            // 0000004A004C: 4AD68F18
	v_add_nc_u32_e32 v108, v24, v72                            // 0000004A0050: 4AD89118
	v_add_nc_u32_e32 v109, v24, v76                            // 0000004A0054: 4ADA9918
	v_and_b32_e32 v3, 0x7f, v0                                 // 0000004A0058: 360600FF 0000007F
	v_cmp_gt_u32_e32 vcc_lo, 0x200, v0                         // 0000004A0060: 7C9800FF 00000200
	s_waitcnt vmcnt(30)                                        // 0000004A0068: BF897BF7
	.long 0xd73d0014                                           // 0000004A006C: D73D0014
	v_cndmask_b32_e32 v1, v82, v27, vcc_lo                     // 0000004A0070: 02023752
	.long 0xd73d0015                                           // 0000004A0074: D73D0015
	v_cndmask_b32_e32 v1, v83, v27, vcc_lo                     // 0000004A0078: 02023753
	.long 0xd73d0016                                           // 0000004A007C: D73D0016
	v_cndmask_b32_e32 v1, v84, v27, vcc_lo                     // 0000004A0080: 02023754
	.long 0xd73d0017                                           // 0000004A0084: D73D0017
	v_cndmask_b32_e32 v1, v85, v27, vcc_lo                     // 0000004A0088: 02023755
	s_waitcnt vmcnt(15)                                        // 0000004A008C: BF893FF7
	.long 0xd73d0035                                           // 0000004A0090: D73D0035
	v_cndmask_b32_e32 v1, v87, v41, vcc_lo                     // 0000004A0094: 02025357
	.long 0xd73d0036                                           // 0000004A0098: D73D0036
	v_cndmask_b32_e32 v1, v88, v41, vcc_lo                     // 0000004A009C: 02025358
	.long 0xd73d0037                                           // 0000004A00A0: D73D0037
	v_cndmask_b32_e32 v1, v82, v29, vcc_lo                     // 0000004A00A4: 02023B52
	.long 0xd73d0038                                           // 0000004A00A8: D73D0038
	v_cndmask_b32_e32 v1, v83, v29, vcc_lo                     // 0000004A00AC: 02023B53
	.long 0xd73d0039                                           // 0000004A00B0: D73D0039
	v_cndmask_b32_e32 v1, v84, v29, vcc_lo                     // 0000004A00B4: 02023B54
	s_waitcnt vmcnt(14)                                        // 0000004A00B8: BF893BF7
	.long 0xd73d003a                                           // 0000004A00BC: D73D003A
	v_cndmask_b32_e32 v1, v87, v43, vcc_lo                     // 0000004A00C0: 02025757
	.long 0xd73d003b                                           // 0000004A00C4: D73D003B
	v_cndmask_b32_e32 v1, v88, v43, vcc_lo                     // 0000004A00C8: 02025758
	.long 0xd73d003c                                           // 0000004A00CC: D73D003C
	v_cndmask_b32_e32 v1, v83, v31, vcc_lo                     // 0000004A00D0: 02023F53
	.long 0xd73d003d                                           // 0000004A00D4: D73D003D
	v_cndmask_b32_e32 v1, v84, v31, vcc_lo                     // 0000004A00D8: 02023F54
	s_waitcnt vmcnt(12)                                        // 0000004A00DC: BF8933F7
	.long 0xd73d003e                                           // 0000004A00E0: D73D003E
	v_cndmask_b32_e32 v1, v87, v15, vcc_lo                     // 0000004A00E4: 02021F57
	.long 0xd73d003f                                           // 0000004A00E8: D73D003F
	v_cndmask_b32_e32 v1, v88, v15, vcc_lo                     // 0000004A00EC: 02021F58
	.long 0xd73d0040                                           // 0000004A00F0: D73D0040
	v_cndmask_b32_e32 v1, v82, v33, vcc_lo                     // 0000004A00F4: 02024352
	.long 0xd73d0041                                           // 0000004A00F8: D73D0041
	v_cndmask_b32_e32 v1, v83, v33, vcc_lo                     // 0000004A00FC: 02024353
	.long 0xd73d0042                                           // 0000004A0100: D73D0042
	v_cndmask_b32_e32 v1, v84, v33, vcc_lo                     // 0000004A0104: 02024354
	.long 0xd73d001b                                           // 0000004A0108: D73D001B
	v_cndmask_b32_e32 v1, v86, v41, vcc_lo                     // 0000004A010C: 02025356
	.long 0xd73d0029                                           // 0000004A0110: D73D0029
	v_cndmask_b32_e32 v1, v89, v41, vcc_lo                     // 0000004A0114: 02025359
	s_waitcnt vmcnt(7)                                         // 0000004A0118: BF891FF7
	.long 0xd73d0043                                           // 0000004A011C: D73D0043
	v_cndmask_b32_e32 v1, v87, v45, vcc_lo                     // 0000004A0120: 02025B57
	.long 0xd73d0044                                           // 0000004A0124: D73D0044
	v_cndmask_b32_e32 v1, v88, v45, vcc_lo                     // 0000004A0128: 02025B58
	.long 0xd73d0045                                           // 0000004A012C: D73D0045
	v_cndmask_b32_e32 v1, v83, v35, vcc_lo                     // 0000004A0130: 02024753
	.long 0xd73d0046                                           // 0000004A0134: D73D0046
	v_cndmask_b32_e32 v1, v84, v35, vcc_lo                     // 0000004A0138: 02024754
	.long 0xd73d001c                                           // 0000004A013C: D73D001C
	v_cndmask_b32_e32 v1, v85, v29, vcc_lo                     // 0000004A0140: 02023B55
	s_waitcnt vmcnt(6)                                         // 0000004A0144: BF891BF7
	.long 0xd73d0047                                           // 0000004A0148: D73D0047
	v_cndmask_b32_e32 v1, v87, v47, vcc_lo                     // 0000004A014C: 02025F57
	.long 0xd73d001d                                           // 0000004A0150: D73D001D
	v_cndmask_b32_e32 v1, v86, v43, vcc_lo                     // 0000004A0154: 02025756
	.long 0xd73d002a                                           // 0000004A0158: D73D002A
	v_cndmask_b32_e32 v1, v89, v43, vcc_lo                     // 0000004A015C: 02025759
	.long 0xd73d0048                                           // 0000004A0160: D73D0048
	v_cndmask_b32_e32 v1, v88, v47, vcc_lo                     // 0000004A0164: 02025F58
	.long 0xd73d002b                                           // 0000004A0168: D73D002B
	v_cndmask_b32_e32 v1, v82, v31, vcc_lo                     // 0000004A016C: 02023F52
	.long 0xd73d001e                                           // 0000004A0170: D73D001E
	v_cndmask_b32_e32 v1, v85, v31, vcc_lo                     // 0000004A0174: 02023F55
	.long 0xd73d0049                                           // 0000004A0178: D73D0049
	v_cndmask_b32_e32 v1, v83, v37, vcc_lo                     // 0000004A017C: 02024B53
	.long 0xd73d001f                                           // 0000004A0180: D73D001F
	v_cndmask_b32_e32 v1, v86, v15, vcc_lo                     // 0000004A0184: 02021F56
	.long 0xd73d004a                                           // 0000004A0188: D73D004A
	v_cndmask_b32_e32 v1, v84, v37, vcc_lo                     // 0000004A018C: 02024B54
	.long 0xd73d0020                                           // 0000004A0190: D73D0020
	v_cndmask_b32_e32 v1, v85, v33, vcc_lo                     // 0000004A0194: 02024355
	s_waitcnt vmcnt(5)                                         // 0000004A0198: BF8917F7
	.long 0xd73d004b                                           // 0000004A019C: D73D004B
	v_cndmask_b32_e32 v1, v87, v49, vcc_lo                     // 0000004A01A0: 02026357
	.long 0xd73d0021                                           // 0000004A01A4: D73D0021
	v_cndmask_b32_e32 v1, v86, v45, vcc_lo                     // 0000004A01A8: 02025B56
	.long 0xd73d002c                                           // 0000004A01AC: D73D002C
	v_cndmask_b32_e32 v1, v89, v45, vcc_lo                     // 0000004A01B0: 02025B59
	.long 0xd73d004c                                           // 0000004A01B4: D73D004C
	v_cndmask_b32_e32 v1, v88, v49, vcc_lo                     // 0000004A01B8: 02026358
	.long 0xd73d002d                                           // 0000004A01BC: D73D002D
	v_cndmask_b32_e32 v1, v82, v35, vcc_lo                     // 0000004A01C0: 02024752
	.long 0xd73d0022                                           // 0000004A01C4: D73D0022
	v_cndmask_b32_e32 v1, v85, v35, vcc_lo                     // 0000004A01C8: 02024755
	.long 0xd73d004d                                           // 0000004A01CC: D73D004D
	v_cndmask_b32_e32 v1, v83, v39, vcc_lo                     // 0000004A01D0: 02024F53
	.long 0xd73d0023                                           // 0000004A01D4: D73D0023
	v_cndmask_b32_e32 v1, v86, v47, vcc_lo                     // 0000004A01D8: 02025F56
	.long 0xd73d002e                                           // 0000004A01DC: D73D002E
	v_cndmask_b32_e32 v1, v89, v47, vcc_lo                     // 0000004A01E0: 02025F59
	.long 0xd73d004e                                           // 0000004A01E4: D73D004E
	v_cndmask_b32_e32 v1, v84, v39, vcc_lo                     // 0000004A01E8: 02024F54
	.long 0xd73d002f                                           // 0000004A01EC: D73D002F
	v_cndmask_b32_e32 v1, v82, v37, vcc_lo                     // 0000004A01F0: 02024B52
	.long 0xd73d0024                                           // 0000004A01F4: D73D0024
	v_cndmask_b32_e32 v1, v85, v37, vcc_lo                     // 0000004A01F8: 02024B55
	s_waitcnt vmcnt(4)                                         // 0000004A01FC: BF8913F7
	.long 0xd73d004f                                           // 0000004A0200: D73D004F
	v_cndmask_b32_e32 v1, v87, v13, vcc_lo                     // 0000004A0204: 02021B57
	.long 0xd73d0025                                           // 0000004A0208: D73D0025
	v_cndmask_b32_e32 v1, v86, v49, vcc_lo                     // 0000004A020C: 02026356
	.long 0xd73d0030                                           // 0000004A0210: D73D0030
	v_cndmask_b32_e32 v1, v89, v49, vcc_lo                     // 0000004A0214: 02026359
	.long 0xd73d0050                                           // 0000004A0218: D73D0050
	v_cndmask_b32_e32 v1, v88, v13, vcc_lo                     // 0000004A021C: 02021B58
	.long 0xd73d0031                                           // 0000004A0220: D73D0031
	v_cndmask_b32_e32 v1, v82, v39, vcc_lo                     // 0000004A0224: 02024F52
	s_waitcnt vmcnt(2)                                         // 0000004A0228: BF890BF7
	.long 0xd73d0051                                           // 0000004A022C: D73D0051
	v_cndmask_b32_e32 v1, v82, v25, vcc_lo                     // 0000004A0230: 02023352
	.long 0xd73d0052                                           // 0000004A0234: D73D0052
	v_cndmask_b32_e32 v1, v83, v25, vcc_lo                     // 0000004A0238: 02023353
	.long 0xd73d0026                                           // 0000004A023C: D73D0026
	v_cndmask_b32_e32 v1, v85, v39, vcc_lo                     // 0000004A0240: 02024F55
	.long 0xd73d0053                                           // 0000004A0244: D73D0053
	v_cndmask_b32_e32 v1, v84, v25, vcc_lo                     // 0000004A0248: 02023354
	.long 0xd73d0018                                           // 0000004A024C: D73D0018
	v_cndmask_b32_e32 v1, v85, v25, vcc_lo                     // 0000004A0250: 02023355
	.long 0xd73d000f                                           // 0000004A0254: D73D000F
	v_cndmask_b32_e32 v1, v89, v15, vcc_lo                     // 0000004A0258: 02021F59
	.long 0xd73d0027                                           // 0000004A025C: D73D0027
	v_cndmask_b32_e32 v1, v86, v13, vcc_lo                     // 0000004A0260: 02021B56
	.long 0xd73d000d                                           // 0000004A0264: D73D000D
	v_cndmask_b32_e32 v1, v89, v13, vcc_lo                     // 0000004A0268: 02021B59
	s_waitcnt vmcnt(0)                                         // 0000004A026C: BF8903F7
	.long 0xd73d0019                                           // 0000004A0270: D73D0019
	v_cndmask_b32_e32 v1, v86, v51, vcc_lo                     // 0000004A0274: 02026756
	.long 0xd73d0054                                           // 0000004A0278: D73D0054
	v_cndmask_b32_e32 v1, v87, v51, vcc_lo                     // 0000004A027C: 02026757
	v_and_b32_e32 v14, 0xffff, v20                             // 0000004A0280: 361C28FF 0000FFFF
	v_and_b32_e32 v16, 0xffff, v21                             // 0000004A0288: 36202AFF 0000FFFF
	v_and_b32_e32 v20, 0xffff, v22                             // 0000004A0290: 36282CFF 0000FFFF
	v_and_b32_e32 v21, 0xffff, v23                             // 0000004A0298: 362A2EFF 0000FFFF
	v_and_b32_e32 v23, 0xffff, v53                             // 0000004A02A0: 362E6AFF 0000FFFF
	v_and_b32_e32 v26, 0xffff, v54                             // 0000004A02A8: 36346CFF 0000FFFF
	v_and_b32_e32 v53, 0xffff, v59                             // 0000004A02B0: 366A76FF 0000FFFF
	v_and_b32_e32 v54, 0xffff, v60                             // 0000004A02B8: 366C78FF 0000FFFF
	v_and_b32_e32 v60, 0xffff, v66                             // 0000004A02C0: 367884FF 0000FFFF
	v_and_b32_e32 v66, 0xffff, v72                             // 0000004A02C8: 368490FF 0000FFFF
	.long 0xd73d0055                                           // 0000004A02D0: D73D0055
	v_cndmask_b32_e32 v1, v88, v51, vcc_lo                     // 0000004A02D4: 02026758
	.long 0xd73d0032                                           // 0000004A02D8: D73D0032
	v_cndmask_b32_e32 v1, v89, v51, vcc_lo                     // 0000004A02DC: 02026759
	v_and_b32_e32 v22, 0xffff, v27                             // 0000004A02E0: 362C36FF 0000FFFF
	v_and_b32_e32 v51, 0xffff, v57                             // 0000004A02E8: 366672FF 0000FFFF
	v_and_b32_e32 v43, 0xffff, v43                             // 0000004A02F0: 365656FF 0000FFFF
	v_and_b32_e32 v47, 0xffff, v47                             // 0000004A02F8: 365E5EFF 0000FFFF
	v_and_b32_e32 v27, 0xffff, v41                             // 0000004A0300: 363652FF 0000FFFF
	v_and_b32_e32 v41, 0xffff, v56                             // 0000004A0308: 365270FF 0000FFFF
	v_and_b32_e32 v56, 0xffff, v62                             // 0000004A0310: 36707CFF 0000FFFF
	v_and_b32_e32 v62, 0xffff, v68                             // 0000004A0318: 367C88FF 0000FFFF
	v_and_b32_e32 v68, 0xffff, v74                             // 0000004A0320: 368894FF 0000FFFF
	v_and_b32_e32 v74, 0xffff, v80                             // 0000004A0328: 3694A0FF 0000FFFF
	v_and_b32_e32 v40, 0xffff, v55                             // 0000004A0330: 36506EFF 0000FFFF
	v_and_b32_e32 v29, 0xffff, v29                             // 0000004A0338: 363A3AFF 0000FFFF
	v_and_b32_e32 v52, 0xffff, v58                             // 0000004A0340: 366874FF 0000FFFF
	v_and_b32_e32 v42, 0xffff, v42                             // 0000004A0348: 365454FF 0000FFFF
	v_and_b32_e32 v55, 0xffff, v61                             // 0000004A0350: 366E7AFF 0000FFFF
	v_and_b32_e32 v31, 0xffff, v31                             // 0000004A0358: 363E3EFF 0000FFFF
	v_and_b32_e32 v57, 0xffff, v63                             // 0000004A0360: 36727EFF 0000FFFF
	v_and_b32_e32 v58, 0xffff, v64                             // 0000004A0368: 367480FF 0000FFFF
	v_and_b32_e32 v33, 0xffff, v33                             // 0000004A0370: 364242FF 0000FFFF
	v_and_b32_e32 v45, 0xffff, v45                             // 0000004A0378: 365A5AFF 0000FFFF
	v_and_b32_e32 v63, 0xffff, v69                             // 0000004A0380: 367E8AFF 0000FFFF
	v_and_b32_e32 v64, 0xffff, v70                             // 0000004A0388: 36808CFF 0000FFFF
	v_and_b32_e32 v35, 0xffff, v35                             // 0000004A0390: 364646FF 0000FFFF
	v_and_b32_e32 v46, 0xffff, v46                             // 0000004A0398: 365C5CFF 0000FFFF
	v_and_b32_e32 v37, 0xffff, v37                             // 0000004A03A0: 364A4AFF 0000FFFF
	v_and_b32_e32 v69, 0xffff, v75                             // 0000004A03A8: 368A96FF 0000FFFF
	v_and_b32_e32 v70, 0xffff, v76                             // 0000004A03B0: 368C98FF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v49                             // 0000004A03B8: 366262FF 0000FFFF
	v_and_b32_e32 v72, 0xffff, v78                             // 0000004A03C0: 36909CFF 0000FFFF
	v_and_b32_e32 v39, 0xffff, v39                             // 0000004A03C8: 364E4EFF 0000FFFF
	.long 0xd72c000e                                           // 0000004A03D0: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 0000004A03D4: 02021CFF 83DCD12D
	.long 0xd72c0014                                           // 0000004A03DC: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v20, vcc_lo              // 0000004A03E0: 020228FF 83DCD12D
	.long 0xd72c001a                                           // 0000004A03E8: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 0000004A03EC: 020234FF 83DCD12D
	.long 0xd72c0035                                           // 0000004A03F4: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000004A03F8: 02026AFF 83DCD12D
	.long 0xd72c0042                                           // 0000004A0400: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 0000004A0404: 020284FF 83DCD12D
	v_and_b32_e32 v75, 0xffff, v81                             // 0000004A040C: 3696A2FF 0000FFFF
	v_and_b32_e32 v28, 0xffff, v28                             // 0000004A0414: 363838FF 0000FFFF
	v_and_b32_e32 v59, 0xffff, v65                             // 0000004A041C: 367682FF 0000FFFF
	v_and_b32_e32 v61, 0xffff, v67                             // 0000004A0424: 367A86FF 0000FFFF
	v_and_b32_e32 v65, 0xffff, v71                             // 0000004A042C: 36828EFF 0000FFFF
	v_and_b32_e32 v67, 0xffff, v73                             // 0000004A0434: 368692FF 0000FFFF
	v_and_b32_e32 v71, 0xffff, v77                             // 0000004A043C: 368E9AFF 0000FFFF
	.long 0xd72c0016                                           // 0000004A0444: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 0000004A0448: 02022CFF 83DCD12D
	.long 0xd72c0033                                           // 0000004A0450: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000004A0454: 020266FF 83DCD12D
	.long 0xd72c002b                                           // 0000004A045C: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 0000004A0460: 020256FF 83DCD12D
	.long 0xd72c002f                                           // 0000004A0468: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000004A046C: 02025EFF 83DCD12D
	v_and_b32_e32 v77, 0xffff, v83                             // 0000004A0474: 369AA6FF 0000FFFF
	v_and_b32_e32 v13, 0xffff, v13                             // 0000004A047C: 361A1AFF 0000FFFF
	.long 0xd72c004a                                           // 0000004A0484: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 0000004A0488: 020294FF 83DCD12D
	v_and_b32_e32 v25, 0xffff, v25                             // 0000004A0490: 363232FF 0000FFFF
	v_and_b32_e32 v30, 0xffff, v30                             // 0000004A0498: 363C3CFF 0000FFFF
	v_and_b32_e32 v15, 0xffff, v15                             // 0000004A04A0: 361E1EFF 0000FFFF
	v_and_b32_e32 v32, 0xffff, v32                             // 0000004A04A8: 364040FF 0000FFFF
	v_and_b32_e32 v44, 0xffff, v44                             // 0000004A04B0: 365858FF 0000FFFF
	v_and_b32_e32 v34, 0xffff, v34                             // 0000004A04B8: 364444FF 0000FFFF
	v_and_b32_e32 v36, 0xffff, v36                             // 0000004A04C0: 364848FF 0000FFFF
	v_and_b32_e32 v48, 0xffff, v48                             // 0000004A04C8: 366060FF 0000FFFF
	v_and_b32_e32 v38, 0xffff, v38                             // 0000004A04D0: 364C4CFF 0000FFFF
	v_and_b32_e32 v73, 0xffff, v79                             // 0000004A04D8: 36929EFF 0000FFFF
	.long 0xd72c0010                                           // 0000004A04E0: D72C0010
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 0000004A04E4: 020220FF 83DCD12D
	.long 0xd72c0015                                           // 0000004A04EC: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 0000004A04F0: 02022AFF 83DCD12D
	.long 0xd72c001b                                           // 0000004A04F8: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 0000004A04FC: 020236FF 83DCD12D
	.long 0xd72c0028                                           // 0000004A0504: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 0000004A0508: 020250FF 83DCD12D
	.long 0xd72c001d                                           // 0000004A0510: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 0000004A0514: 02023AFF 83DCD12D
	.long 0xd72c002a                                           // 0000004A051C: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 0000004A0520: 020254FF 83DCD12D
	.long 0xd72c0037                                           // 0000004A0528: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000004A052C: 02026EFF 83DCD12D
	.long 0xd72c001f                                           // 0000004A0534: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 0000004A0538: 02023EFF 83DCD12D
	.long 0xd72c0039                                           // 0000004A0540: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000004A0544: 020272FF 83DCD12D
	.long 0xd72c003a                                           // 0000004A054C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000004A0550: 020274FF 83DCD12D
	.long 0xd72c003c                                           // 0000004A0558: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000004A055C: 020278FF 83DCD12D
	.long 0xd72c0021                                           // 0000004A0564: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 0000004A0568: 020242FF 83DCD12D
	.long 0xd72c003e                                           // 0000004A0570: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000004A0574: 02027CFF 83DCD12D
	.long 0xd72c002d                                           // 0000004A057C: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000004A0580: 02025AFF 83DCD12D
	.long 0xd72c0040                                           // 0000004A0588: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 0000004A058C: 020280FF 83DCD12D
	.long 0xd72c0023                                           // 0000004A0594: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 0000004A0598: 020246FF 83DCD12D
	.long 0xd72c002e                                           // 0000004A05A0: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000004A05A4: 02025CFF 83DCD12D
	.long 0xd72c0044                                           // 0000004A05AC: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 0000004A05B0: 020288FF 83DCD12D
	.long 0xd72c0025                                           // 0000004A05B8: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 0000004A05BC: 02024AFF 83DCD12D
	.long 0xd72c0046                                           // 0000004A05C4: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 0000004A05C8: 02028CFF 83DCD12D
	.long 0xd72c0031                                           // 0000004A05D0: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 0000004A05D4: 020262FF 83DCD12D
	.long 0xd72c0048                                           // 0000004A05DC: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 0000004A05E0: 020290FF 83DCD12D
	.long 0xd72c0027                                           // 0000004A05E8: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000004A05EC: 02024EFF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v82                             // 0000004A05F4: 3698A4FF 0000FFFF
	v_and_b32_e32 v79, 0xffff, v85                             // 0000004A05FC: 369EAAFF 0000FFFF
	.long 0xd72c004b                                           // 0000004A0604: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 0000004A0608: 020296FF 83DCD12D
	.long 0xd72c0017                                           // 0000004A0610: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 0000004A0614: 02022EFF 83DCD12D
	.long 0xd72c001c                                           // 0000004A061C: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 0000004A0620: 020238FF 83DCD12D
	.long 0xd72c0036                                           // 0000004A0628: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000004A062C: 02026CFF 83DCD12D
	.long 0xd72c0043                                           // 0000004A0634: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 0000004A0638: 020286FF 83DCD12D
	v_and_b32_e32 v24, 0xffff, v24                             // 0000004A0640: 363030FF 0000FFFF
	.long 0xd72c004d                                           // 0000004A0648: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 0000004A064C: 02029AFF 83DCD12D
	v_sad_u8 v14, v14, 0, 0x6400                               // 0000004A0654: D622000E 03FD010E 00006400
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000004A0660: D6220014 03FD0114 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000004A066C: D622001A 03FD011A 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000004A0678: D6220035 03FD0135 00006400
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000004A0684: D6220042 03FD0142 00006400
	.long 0xd72c000d                                           // 0000004A0690: D72C000D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v13, vcc_lo              // 0000004A0694: 02021AFF 83DCD12D
	v_and_b32_e32 v78, 0xffff, v84                             // 0000004A069C: 369CA8FF 0000FFFF
	.long 0xd72c0019                                           // 0000004A06A4: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 0000004A06A8: 020232FF 83DCD12D
	.long 0xd72c0029                                           // 0000004A06B0: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 0000004A06B4: 020252FF 83DCD12D
	.long 0xd72c0034                                           // 0000004A06BC: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000004A06C0: 020268FF 83DCD12D
	.long 0xd72c001e                                           // 0000004A06C8: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 0000004A06CC: 02023CFF 83DCD12D
	.long 0xd72c0038                                           // 0000004A06D4: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000004A06D8: 020270FF 83DCD12D
	.long 0xd72c000f                                           // 0000004A06E0: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 0000004A06E4: 02021EFF 83DCD12D
	.long 0xd72c003b                                           // 0000004A06EC: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000004A06F0: 020276FF 83DCD12D
	.long 0xd72c0020                                           // 0000004A06F8: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 0000004A06FC: 020240FF 83DCD12D
	.long 0xd72c003d                                           // 0000004A0704: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000004A0708: 02027AFF 83DCD12D
	.long 0xd72c002c                                           // 0000004A0710: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000004A0714: 020258FF 83DCD12D
	.long 0xd72c003f                                           // 0000004A071C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 0000004A0720: 02027EFF 83DCD12D
	.long 0xd72c0022                                           // 0000004A0728: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 0000004A072C: 020244FF 83DCD12D
	.long 0xd72c0041                                           // 0000004A0734: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 0000004A0738: 020282FF 83DCD12D
	.long 0xd72c0024                                           // 0000004A0740: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 0000004A0744: 020248FF 83DCD12D
	.long 0xd72c0045                                           // 0000004A074C: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 0000004A0750: 02028AFF 83DCD12D
	.long 0xd72c0030                                           // 0000004A0758: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 0000004A075C: 020260FF 83DCD12D
	.long 0xd72c0047                                           // 0000004A0764: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 0000004A0768: 02028EFF 83DCD12D
	.long 0xd72c0026                                           // 0000004A0770: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 0000004A0774: 02024CFF 83DCD12D
	.long 0xd72c0049                                           // 0000004A077C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 0000004A0780: 020292FF 83DCD12D
	v_and_b32_e32 v50, 0xffff, v50                             // 0000004A0788: 366464FF 0000FFFF
	.long 0xd72c004c                                           // 0000004A0790: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000004A0794: 020298FF 83DCD12D
	.long 0xd72c004f                                           // 0000004A079C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 0000004A07A0: 02029EFF 83DCD12D
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000004A07A8: D6220016 03FD0116 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000004A07B4: D6220033 03FD0133 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000004A07C0: D622002B 03FD012B 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000004A07CC: D622002F 03FD012F 00006400
	.long 0xd72c0018                                           // 0000004A07D8: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 0000004A07DC: 020230FF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 0000004A07E4: D622004A 03FD014A 00006400
	v_sad_u8 v16, v16, 0, 0x6400                               // 0000004A07F0: D6220010 03FD0110 00006400
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000004A07FC: D6220015 03FD0115 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000004A0808: D622001B 03FD011B 00006400
	v_sad_u8 v40, v40, 0, 0x6400                               // 0000004A0814: D6220028 03FD0128 00006400
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000004A0820: D622001D 03FD011D 00006400
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000004A082C: D622002A 03FD012A 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000004A0838: D6220037 03FD0137 00006400
	v_sad_u8 v31, v31, 0, 0x6400                               // 0000004A0844: D622001F 03FD011F 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000004A0850: D6220039 03FD0139 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000004A085C: D622003A 03FD013A 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000004A0868: D622003C 03FD013C 00006400
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000004A0874: D6220021 03FD0121 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000004A0880: D622003E 03FD013E 00006400
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000004A088C: D622002D 03FD012D 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000004A0898: D6220040 03FD0140 00006400
	v_sad_u8 v35, v35, 0, 0x6400                               // 0000004A08A4: D6220023 03FD0123 00006400
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000004A08B0: D622002E 03FD012E 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 0000004A08BC: D6220044 03FD0144 00006400
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000004A08C8: D6220025 03FD0125 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 0000004A08D4: D6220046 03FD0146 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000004A08E0: D6220031 03FD0131 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 0000004A08EC: D6220048 03FD0148 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000004A08F8: D6220027 03FD0127 00006400
	v_and_b32_e32 v14, 0xffff, v14                             // 0000004A0904: 361C1CFF 0000FFFF
	v_and_b32_e32 v20, 0xffff, v20                             // 0000004A090C: 362828FF 0000FFFF
	v_and_b32_e32 v26, 0xffff, v26                             // 0000004A0914: 363434FF 0000FFFF
	v_and_b32_e32 v53, 0xffff, v53                             // 0000004A091C: 366A6AFF 0000FFFF
	v_and_b32_e32 v66, 0xffff, v66                             // 0000004A0924: 368484FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 0000004A092C: D622004B 03FD014B 00006400
	.long 0xd72c004e                                           // 0000004A0938: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000004A093C: 02029CFF 83DCD12D
	.long 0xd72c0032                                           // 0000004A0944: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000004A0948: 020264FF 83DCD12D
	v_sad_u8 v23, v23, 0, 0x6400                               // 0000004A0950: D6220017 03FD0117 00006400
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000004A095C: D622001C 03FD011C 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000004A0968: D6220036 03FD0136 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 0000004A0974: D6220043 03FD0143 00006400
	v_and_b32_e32 v22, 0xffff, v22                             // 0000004A0980: 362C2CFF 0000FFFF
	v_and_b32_e32 v51, 0xffff, v51                             // 0000004A0988: 366666FF 0000FFFF
	v_and_b32_e32 v43, 0xffff, v43                             // 0000004A0990: 365656FF 0000FFFF
	v_and_b32_e32 v47, 0xffff, v47                             // 0000004A0998: 365E5EFF 0000FFFF
	v_sad_u8 v77, v77, 0, 0x6400                               // 0000004A09A0: D622004D 03FD014D 00006400
	v_sad_u8 v13, v13, 0, 0x6400                               // 0000004A09AC: D622000D 03FD010D 00006400
	v_and_b32_e32 v74, 0xffff, v74                             // 0000004A09B8: 369494FF 0000FFFF
	v_sad_u8 v25, v25, 0, 0x6400                               // 0000004A09C0: D6220019 03FD0119 00006400
	v_sad_u8 v41, v41, 0, 0x6400                               // 0000004A09CC: D6220029 03FD0129 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000004A09D8: D6220034 03FD0134 00006400
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000004A09E4: D622001E 03FD011E 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000004A09F0: D6220038 03FD0138 00006400
	v_sad_u8 v15, v15, 0, 0x6400                               // 0000004A09FC: D622000F 03FD010F 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000004A0A08: D622003B 03FD013B 00006400
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000004A0A14: D6220020 03FD0120 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000004A0A20: D622003D 03FD013D 00006400
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000004A0A2C: D622002C 03FD012C 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 0000004A0A38: D622003F 03FD013F 00006400
	v_sad_u8 v34, v34, 0, 0x6400                               // 0000004A0A44: D6220022 03FD0122 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000004A0A50: D6220041 03FD0141 00006400
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000004A0A5C: D6220024 03FD0124 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 0000004A0A68: D6220045 03FD0145 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 0000004A0A74: D6220030 03FD0130 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 0000004A0A80: D6220047 03FD0147 00006400
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000004A0A8C: D6220026 03FD0126 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000004A0A98: D6220049 03FD0149 00006400
	v_and_b32_e32 v40, 0xffff, v40                             // 0000004A0AA4: 365050FF 0000FFFF
	v_and_b32_e32 v29, 0xffff, v29                             // 0000004A0AAC: 363A3AFF 0000FFFF
	v_and_b32_e32 v55, 0xffff, v55                             // 0000004A0AB4: 366E6EFF 0000FFFF
	v_and_b32_e32 v31, 0xffff, v31                             // 0000004A0ABC: 363E3EFF 0000FFFF
	v_and_b32_e32 v57, 0xffff, v57                             // 0000004A0AC4: 367272FF 0000FFFF
	v_and_b32_e32 v58, 0xffff, v58                             // 0000004A0ACC: 367474FF 0000FFFF
	v_and_b32_e32 v60, 0xffff, v60                             // 0000004A0AD4: 367878FF 0000FFFF
	v_and_b32_e32 v33, 0xffff, v33                             // 0000004A0ADC: 364242FF 0000FFFF
	v_and_b32_e32 v62, 0xffff, v62                             // 0000004A0AE4: 367C7CFF 0000FFFF
	v_and_b32_e32 v45, 0xffff, v45                             // 0000004A0AEC: 365A5AFF 0000FFFF
	v_and_b32_e32 v64, 0xffff, v64                             // 0000004A0AF4: 368080FF 0000FFFF
	v_and_b32_e32 v35, 0xffff, v35                             // 0000004A0AFC: 364646FF 0000FFFF
	v_and_b32_e32 v68, 0xffff, v68                             // 0000004A0B04: 368888FF 0000FFFF
	v_and_b32_e32 v37, 0xffff, v37                             // 0000004A0B0C: 364A4AFF 0000FFFF
	v_and_b32_e32 v70, 0xffff, v70                             // 0000004A0B14: 368C8CFF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v49                             // 0000004A0B1C: 366262FF 0000FFFF
	v_and_b32_e32 v72, 0xffff, v72                             // 0000004A0B24: 369090FF 0000FFFF
	v_and_b32_e32 v39, 0xffff, v39                             // 0000004A0B2C: 364E4EFF 0000FFFF
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000004A0B34: D622004C 03FD014C 00006400
	v_sad_u8 v79, v79, 0, 0x6400                               // 0000004A0B40: D622004F 03FD014F 00006400
	v_lshl_or_b32 v14, v16, 16, v14                            // 0000004A0B4C: D656000E 04392110
	v_lshl_or_b32 v16, v21, 16, v20                            // 0000004A0B54: D6560010 04512115
	v_lshl_or_b32 v21, v27, 16, v26                            // 0000004A0B5C: D6560015 0469211B
	v_lshl_or_b32 v27, v42, 16, v53                            // 0000004A0B64: D656001B 04D5212A
	v_lshl_or_b32 v42, v46, 16, v66                            // 0000004A0B6C: D656002A 0509212E
	v_and_b32_e32 v46, 0xffff, v75                             // 0000004A0B74: 365C96FF 0000FFFF
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000004A0B7C: D6220018 03FD0118 00006400
	v_lshl_or_b32 v20, v23, 16, v22                            // 0000004A0B88: D6560014 04592117
	v_lshl_or_b32 v23, v28, 16, v51                            // 0000004A0B90: D6560017 04CD211C
	v_lshl_or_b32 v28, v54, 16, v43                            // 0000004A0B98: D656001C 04AD2136
	v_lshl_or_b32 v43, v67, 16, v47                            // 0000004A0BA0: D656002B 04BD2143
	v_and_b32_e32 v47, 0xffff, v77                             // 0000004A0BA8: 365E9AFF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000004A0BB0: D622004E 03FD014E 00006400
	v_lshl_or_b32 v13, v13, 16, v74                            // 0000004A0BBC: D656000D 0529210D
	v_and_b32_e32 v25, 0xffff, v25                             // 0000004A0BC4: 363232FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000004A0BCC: D6220032 03FD0132 00006400
	v_lshl_or_b32 v22, v41, 16, v40                            // 0000004A0BD8: D6560016 04A12129
	v_lshl_or_b32 v26, v52, 16, v29                            // 0000004A0BE0: D656001A 04752134
	v_lshl_or_b32 v29, v30, 16, v55                            // 0000004A0BE8: D656001D 04DD211E
	v_lshl_or_b32 v30, v56, 16, v31                            // 0000004A0BF0: D656001E 047D2138
	v_lshl_or_b32 v15, v15, 16, v57                            // 0000004A0BF8: D656000F 04E5210F
	v_lshl_or_b32 v31, v59, 16, v58                            // 0000004A0C00: D656001F 04E9213B
	v_lshl_or_b32 v32, v32, 16, v60                            // 0000004A0C08: D6560020 04F12120
	v_lshl_or_b32 v33, v61, 16, v33                            // 0000004A0C10: D6560021 0485213D
	v_lshl_or_b32 v40, v44, 16, v62                            // 0000004A0C18: D6560028 04F9212C
	v_lshl_or_b32 v41, v63, 16, v45                            // 0000004A0C20: D6560029 04B5213F
	v_lshl_or_b32 v34, v34, 16, v64                            // 0000004A0C28: D6560022 05012122
	v_lshl_or_b32 v35, v65, 16, v35                            // 0000004A0C30: D6560023 048D2141
	v_lshl_or_b32 v36, v36, 16, v68                            // 0000004A0C38: D6560024 05112124
	v_lshl_or_b32 v37, v69, 16, v37                            // 0000004A0C40: D6560025 04952145
	v_lshl_or_b32 v44, v48, 16, v70                            // 0000004A0C48: D656002C 05192130
	v_lshl_or_b32 v45, v71, 16, v49                            // 0000004A0C50: D656002D 04C52147
	v_lshl_or_b32 v38, v38, 16, v72                            // 0000004A0C58: D6560026 05212126
	v_lshl_or_b32 v39, v73, 16, v39                            // 0000004A0C60: D6560027 049D2149
	v_and_b32_e32 v48, 0xffff, v79                             // 0000004A0C68: 36609EFF 0000FFFF
	v_pk_fma_f16 v14, v14, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0C70: CC0E000E 0BFC070E 0000C931
	v_lshl_or_b32 v46, v76, 16, v46                            // 0000004A0C7C: D656002E 04B9214C
	v_pk_fma_f16 v16, v16, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0C84: CC0E0010 0BFC0710 0000C931
	v_lshl_or_b32 v24, v24, 16, v47                            // 0000004A0C90: D6560018 04BD2118
	v_pk_fma_f16 v20, v20, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0C98: CC0E0014 0BFC0714 0000C931
	v_pk_fma_f16 v13, v13, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0CA4: CC0E000D 0BFC070D 0000C931
	v_lshl_or_b32 v25, v78, 16, v25                            // 0000004A0CB0: D6560019 0465214E
	v_pk_fma_f16 v21, v21, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0CB8: CC0E0015 0BFC0715 0000C931
	v_pk_fma_f16 v22, v22, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0CC4: CC0E0016 0BFC0716 0000C931
	v_pk_fma_f16 v23, v23, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0CD0: CC0E0017 0BFC0717 0000C931
	v_pk_fma_f16 v26, v26, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0CDC: CC0E001A 0BFC071A 0000C931
	v_pk_fma_f16 v27, v27, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0CE8: CC0E001B 0BFC071B 0000C931
	v_pk_fma_f16 v28, v28, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0CF4: CC0E001C 0BFC071C 0000C931
	v_pk_fma_f16 v29, v29, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0D00: CC0E001D 0BFC071D 0000C931
	v_pk_fma_f16 v30, v30, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0D0C: CC0E001E 0BFC071E 0000C931
	v_pk_fma_f16 v15, v15, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0D18: CC0E000F 0BFC070F 0000C931
	v_pk_fma_f16 v31, v31, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0D24: CC0E001F 0BFC071F 0000C931
	v_pk_fma_f16 v32, v32, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0D30: CC0E0020 0BFC0720 0000C931
	v_pk_fma_f16 v33, v33, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0D3C: CC0E0021 0BFC0721 0000C931
	v_pk_fma_f16 v40, v40, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0D48: CC0E0028 0BFC0728 0000C931
	v_pk_fma_f16 v41, v41, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0D54: CC0E0029 0BFC0729 0000C931
	v_pk_fma_f16 v34, v34, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0D60: CC0E0022 0BFC0722 0000C931
	v_pk_fma_f16 v35, v35, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0D6C: CC0E0023 0BFC0723 0000C931
	v_pk_fma_f16 v42, v42, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0D78: CC0E002A 0BFC072A 0000C931
	v_pk_fma_f16 v43, v43, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0D84: CC0E002B 0BFC072B 0000C931
	v_pk_fma_f16 v36, v36, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0D90: CC0E0024 0BFC0724 0000C931
	v_pk_fma_f16 v37, v37, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0D9C: CC0E0025 0BFC0725 0000C931
	v_pk_fma_f16 v44, v44, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0DA8: CC0E002C 0BFC072C 0000C931
	v_pk_fma_f16 v45, v45, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0DB4: CC0E002D 0BFC072D 0000C931
	v_pk_fma_f16 v38, v38, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0DC0: CC0E0026 0BFC0726 0000C931
	v_pk_fma_f16 v39, v39, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0DCC: CC0E0027 0BFC0727 0000C931
	v_lshl_or_b32 v47, v50, 16, v48                            // 0000004A0DD8: D656002F 04C12132
	v_cvt_f32_f16_e32 v48, v142/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0DE0: 7E60178E
	v_cvt_f32_f16_e32 v14, v14                                 // 0000004A0DE4: 7E1C170E
	v_pk_fma_f16 v46, v46, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0DE8: CC0E002E 0BFC072E 0000C931
	v_cvt_f32_f16_e32 v49, v144/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0DF4: 7E621790
	v_cvt_f32_f16_e32 v16, v16                                 // 0000004A0DF8: 7E201710
	v_pk_fma_f16 v24, v24, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0DFC: CC0E0018 0BFC0718 0000C931
	v_cvt_f32_f16_e32 v50, v148/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E08: 7E641794
	v_cvt_f32_f16_e32 v20, v20                                 // 0000004A0E0C: 7E281714
	v_cvt_f32_f16_e32 v75, v141/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E10: 7E96178D
	v_cvt_f32_f16_e32 v13, v13                                 // 0000004A0E14: 7E1A170D
	v_pk_fma_f16 v25, v25, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0E18: CC0E0019 0BFC0719 0000C931
	v_cvt_f32_f16_e32 v51, v149/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E24: 7E661795
	v_cvt_f32_f16_e32 v21, v21                                 // 0000004A0E28: 7E2A1715
	v_cvt_f32_f16_e32 v52, v150/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E2C: 7E681796
	v_cvt_f32_f16_e32 v22, v22                                 // 0000004A0E30: 7E2C1716
	v_cvt_f32_f16_e32 v53, v151/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E34: 7E6A1797
	v_cvt_f32_f16_e32 v23, v23                                 // 0000004A0E38: 7E2E1717
	v_cvt_f32_f16_e32 v54, v154/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E3C: 7E6C179A
	v_cvt_f32_f16_e32 v26, v26                                 // 0000004A0E40: 7E34171A
	v_cvt_f32_f16_e32 v55, v155/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E44: 7E6E179B
	v_cvt_f32_f16_e32 v27, v27                                 // 0000004A0E48: 7E36171B
	v_cvt_f32_f16_e32 v56, v156/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E4C: 7E70179C
	v_cvt_f32_f16_e32 v28, v28                                 // 0000004A0E50: 7E38171C
	v_cvt_f32_f16_e32 v57, v157/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E54: 7E72179D
	v_cvt_f32_f16_e32 v29, v29                                 // 0000004A0E58: 7E3A171D
	v_cvt_f32_f16_e32 v58, v158/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E5C: 7E74179E
	v_cvt_f32_f16_e32 v30, v30                                 // 0000004A0E60: 7E3C171E
	v_cvt_f32_f16_e32 v59, v143/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E64: 7E76178F
	v_cvt_f32_f16_e32 v15, v15                                 // 0000004A0E68: 7E1E170F
	v_cvt_f32_f16_e32 v60, v159/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E6C: 7E78179F
	v_cvt_f32_f16_e32 v31, v31                                 // 0000004A0E70: 7E3E171F
	v_cvt_f32_f16_e32 v61, v160/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E74: 7E7A17A0
	v_cvt_f32_f16_e32 v32, v32                                 // 0000004A0E78: 7E401720
	v_cvt_f32_f16_e32 v62, v161/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E7C: 7E7C17A1
	v_cvt_f32_f16_e32 v33, v33                                 // 0000004A0E80: 7E421721
	v_cvt_f32_f16_e32 v63, v168/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E84: 7E7E17A8
	v_cvt_f32_f16_e32 v40, v40                                 // 0000004A0E88: 7E501728
	v_cvt_f32_f16_e32 v64, v169/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E8C: 7E8017A9
	v_cvt_f32_f16_e32 v41, v41                                 // 0000004A0E90: 7E521729
	v_cvt_f32_f16_e32 v65, v162/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E94: 7E8217A2
	v_cvt_f32_f16_e32 v34, v34                                 // 0000004A0E98: 7E441722
	v_cvt_f32_f16_e32 v66, v163/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0E9C: 7E8417A3
	v_cvt_f32_f16_e32 v35, v35                                 // 0000004A0EA0: 7E461723
	v_cvt_f32_f16_e32 v67, v170/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0EA4: 7E8617AA
	v_cvt_f32_f16_e32 v42, v42                                 // 0000004A0EA8: 7E54172A
	v_cvt_f32_f16_e32 v68, v171/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0EAC: 7E8817AB
	v_cvt_f32_f16_e32 v43, v43                                 // 0000004A0EB0: 7E56172B
	v_cvt_f32_f16_e32 v69, v164/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0EB4: 7E8A17A4
	v_cvt_f32_f16_e32 v36, v36                                 // 0000004A0EB8: 7E481724
	v_cvt_f32_f16_e32 v70, v165/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0EBC: 7E8C17A5
	v_cvt_f32_f16_e32 v37, v37                                 // 0000004A0EC0: 7E4A1725
	v_cvt_f32_f16_e32 v71, v172/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0EC4: 7E8E17AC
	v_cvt_f32_f16_e32 v44, v44                                 // 0000004A0EC8: 7E58172C
	v_cvt_f32_f16_e32 v72, v173/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0ECC: 7E9017AD
	v_cvt_f32_f16_e32 v45, v45                                 // 0000004A0ED0: 7E5A172D
	v_cvt_f32_f16_e32 v73, v166/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0ED4: 7E9217A6
	v_cvt_f32_f16_e32 v38, v38                                 // 0000004A0ED8: 7E4C1726
	v_cvt_f32_f16_e32 v74, v167/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A0EDC: 7E9417A7
	v_cvt_f32_f16_e32 v39, v39                                 // 0000004A0EE0: 7E4E1727
	v_pk_fma_f16 v47, v47, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A0EE4: CC0E002F 0BFC072F 0000C931
	ds_store_b32 v90, v14                                      // 0000004A0EF0: D8340000 00000E5A
	ds_store_b32 v96, v48                                      // 0000004A0EF8: D8340000 00003060
	ds_store_b32 v97, v16                                      // 0000004A0F00: D8340000 00001061
	ds_store_b32 v98, v49                                      // 0000004A0F08: D8340000 00003162
	ds_store_b32 v99, v20                                      // 0000004A0F10: D8340000 00001463
	ds_store_b32 v100, v50                                     // 0000004A0F18: D8340000 00003264
	ds_store_b32 v101, v21                                     // 0000004A0F20: D8340000 00001565
	ds_store_b32 v102, v51                                     // 0000004A0F28: D8340000 00003366
	ds_store_b32 v91, v22                                      // 0000004A0F30: D8340000 0000165B
	ds_store_b32 v103, v52                                     // 0000004A0F38: D8340000 00003467
	ds_store_b32 v104, v23                                     // 0000004A0F40: D8340000 00001768
	ds_store_b32 v105, v53                                     // 0000004A0F48: D8340000 00003569
	ds_store_b32 v106, v26                                     // 0000004A0F50: D8340000 00001A6A
	ds_store_b32 v107, v54                                     // 0000004A0F58: D8340000 0000366B
	ds_store_b32 v108, v27                                     // 0000004A0F60: D8340000 00001B6C
	ds_store_b32 v109, v55                                     // 0000004A0F68: D8340000 0000376D
	ds_store_b32 v92, v28                                      // 0000004A0F70: D8340000 00001C5C
	ds_store_b32 v110, v56                                     // 0000004A0F78: D8340000 0000386E
	ds_store_b32 v111, v29                                     // 0000004A0F80: D8340000 00001D6F
	ds_store_b32 v112, v57                                     // 0000004A0F88: D8340000 00003970
	ds_store_b32 v113, v30                                     // 0000004A0F90: D8340000 00001E71
	ds_store_b32 v114, v58                                     // 0000004A0F98: D8340000 00003A72
	ds_store_b32 v115, v15                                     // 0000004A0FA0: D8340000 00000F73
	ds_store_b32 v116, v59                                     // 0000004A0FA8: D8340000 00003B74
	ds_store_b32 v93, v31                                      // 0000004A0FB0: D8340000 00001F5D
	ds_store_b32 v117, v60                                     // 0000004A0FB8: D8340000 00003C75
	ds_store_b32 v118, v32                                     // 0000004A0FC0: D8340000 00002076
	ds_store_b32 v119, v61                                     // 0000004A0FC8: D8340000 00003D77
	ds_store_b32 v120, v33                                     // 0000004A0FD0: D8340000 00002178
	ds_store_b32 v121, v62                                     // 0000004A0FD8: D8340000 00003E79
	ds_store_b32 v122, v40                                     // 0000004A0FE0: D8340000 0000287A
	ds_store_b32 v123, v63                                     // 0000004A0FE8: D8340000 00003F7B
	ds_store_b32 v94, v41                                      // 0000004A0FF0: D8340000 0000295E
	ds_store_b32 v124, v64                                     // 0000004A0FF8: D8340000 0000407C
	ds_store_b32 v125, v34                                     // 0000004A1000: D8340000 0000227D
	ds_store_b32 v126, v65                                     // 0000004A1008: D8340000 0000417E
	ds_store_b32 v127, v35                                     // 0000004A1010: D8340000 0000237F
	ds_store_b32 v128, v66                                     // 0000004A1018: D8340000 00004280
	ds_store_b32 v129, v42                                     // 0000004A1020: D8340000 00002A81
	ds_store_b32 v130, v67                                     // 0000004A1028: D8340000 00004382
	ds_store_b32 v95, v43                                      // 0000004A1030: D8340000 00002B5F
	ds_store_b32 v131, v68                                     // 0000004A1038: D8340000 00004483
	ds_store_b32 v132, v36                                     // 0000004A1040: D8340000 00002484
	ds_store_b32 v133, v69                                     // 0000004A1048: D8340000 00004585
	ds_store_b32 v134, v37                                     // 0000004A1050: D8340000 00002586
	ds_store_b32 v135, v70                                     // 0000004A1058: D8340000 00004687
	ds_store_b32 v136, v44                                     // 0000004A1060: D8340000 00002C88
	ds_store_b32 v137, v71                                     // 0000004A1068: D8340000 00004789
	ds_store_b32 v12, v45                                      // 0000004A1070: D8340000 00002D0C
	ds_store_b32 v138, v72                                     // 0000004A1078: D8340000 0000488A
	ds_store_b32 v139, v38                                     // 0000004A1080: D8340000 0000268B
	ds_store_b32 v140, v73                                     // 0000004A1088: D8340000 0000498C
	ds_store_b32 v141, v39                                     // 0000004A1090: D8340000 0000278D
	ds_store_b32 v142, v74                                     // 0000004A1098: D8340000 00004A8E
	ds_store_b32 v143, v13                                     // 0000004A10A0: D8340000 00000D8F
	ds_store_b32 v144, v75                                     // 0000004A10A8: D8340000 00004B90
	v_cvt_f32_f16_e32 v13, v46                                 // 0000004A10B0: 7E1A172E
	v_cvt_f32_f16_e32 v12, v174/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A10B4: 7E1817AE
	v_cvt_f32_f16_e32 v15, v24                                 // 0000004A10B8: 7E1E1718
	v_cvt_f32_f16_e32 v14, v152/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A10BC: 7E1C1798
	v_cvt_f32_f16_e32 v20, v25                                 // 0000004A10C0: 7E281719
	v_cvt_f32_f16_e32 v16, v153/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A10C4: 7E201799
	v_cvt_f32_f16_e32 v21, v175/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A10C8: 7E2A17AF
	v_cvt_f32_f16_e32 v22, v47                                 // 0000004A10CC: 7E2C172F
	ds_store_b32 v4, v13                                       // 0000004A10D0: D8340000 00000D04
	ds_store_b32 v11, v12                                      // 0000004A10D8: D8340000 00000C0B
	ds_store_b32 v10, v15                                      // 0000004A10E0: D8340000 00000F0A
	ds_store_b32 v9, v14                                       // 0000004A10E8: D8340000 00000E09
	ds_store_b32 v8, v20                                       // 0000004A10F0: D8340000 00001408
	ds_store_b32 v7, v16                                       // 0000004A10F8: D8340000 00001007
	ds_store_b32 v6, v22                                       // 0000004A1100: D8340000 00001606
	ds_store_b32 v5, v21                                       // 0000004A1108: D8340000 00001505
	s_waitcnt lgkmcnt(0)                                       // 0000004A1110: BF89FC07
	s_barrier                                                  // 0000004A1114: BFBD0000
	buffer_gl0_inv                                             // 0000004A1118: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 0000004A1120: BE832000
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004A1124: BF870009
	s_xor_b32 s0, exec_lo, s3                                  // 0000004A1128: 8D00037E
	v_and_b32_e32 v3, 0x7f, v0                                 // 0000004A112C: 360600FF 0000007F
	s_or_saveexec_b32 s0, s0                                   // 0000004A1134: BE802200
	v_or_b32_e32 v4, -8, v19                                   // 0000004A1138: 380826C8
	v_lshlrev_b32_e32 v8, 3, v19                               // 0000004A113C: 30102683
	s_xor_b32 exec_lo, exec_lo, s0                             // 0000004A1140: 8D7E007E
	s_cbranch_execz 451                                        // 0000004A1144: BFA501C3 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi3ELb1ELi8EEEvPKjiPKDF16_S5_Pti+0x1e54>
	v_and_b32_e32 v34, 0x60, v0                                // 0000004A1148: 364400FF 00000060
	v_lshlrev_b32_e32 v40, 3, v19                              // 0000004A1150: 30502683
	s_mov_b32 s3, 0                                            // 0000004A1154: BE830080
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004A1158: BF870002
	v_or_b32_e32 v0, 1, v34                                    // 0000004A115C: 38004481
	v_or_b32_e32 v5, 2, v34                                    // 0000004A1160: 380A4482
	v_or_b32_e32 v6, 3, v34                                    // 0000004A1164: 380C4483
	v_or_b32_e32 v7, 4, v34                                    // 0000004A1168: 380E4484
	v_or_b32_e32 v9, 5, v34                                    // 0000004A116C: 38124485
	v_or_b32_e32 v10, 6, v34                                   // 0000004A1170: 38144486
	v_or_b32_e32 v11, 7, v34                                   // 0000004A1174: 38164487
	v_or_b32_e32 v12, 8, v34                                   // 0000004A1178: 38184488
	v_or_b32_e32 v13, 9, v34                                   // 0000004A117C: 381A4489
	v_or_b32_e32 v14, 10, v34                                  // 0000004A1180: 381C448A
	v_or_b32_e32 v15, 11, v34                                  // 0000004A1184: 381E448B
	v_or_b32_e32 v16, 12, v34                                  // 0000004A1188: 3820448C
	v_or_b32_e32 v20, 13, v34                                  // 0000004A118C: 3828448D
	v_or_b32_e32 v21, 14, v34                                  // 0000004A1190: 382A448E
	v_or_b32_e32 v22, 15, v34                                  // 0000004A1194: 382C448F
	v_or_b32_e32 v23, 16, v34                                  // 0000004A1198: 382E4490
	v_or_b32_e32 v24, 17, v34                                  // 0000004A119C: 38304491
	v_or_b32_e32 v25, 18, v34                                  // 0000004A11A0: 38324492
	v_or_b32_e32 v26, 19, v34                                  // 0000004A11A4: 38344493
	v_or_b32_e32 v27, 20, v34                                  // 0000004A11A8: 38364494
	v_or_b32_e32 v28, 21, v34                                  // 0000004A11AC: 38384495
	v_or_b32_e32 v29, 22, v34                                  // 0000004A11B0: 383A4496
	v_or_b32_e32 v30, 23, v34                                  // 0000004A11B4: 383C4497
	v_or_b32_e32 v31, 24, v34                                  // 0000004A11B8: 383E4498
	v_or_b32_e32 v32, 25, v34                                  // 0000004A11BC: 38404499
	v_or_b32_e32 v33, 26, v34                                  // 0000004A11C0: 3842449A
	v_or_b32_e32 v35, 27, v34                                  // 0000004A11C4: 3846449B
	v_or_b32_e32 v36, 28, v34                                  // 0000004A11C8: 3848449C
	v_or_b32_e32 v37, 29, v34                                  // 0000004A11CC: 384A449D
	v_or_b32_e32 v38, 30, v34                                  // 0000004A11D0: 384C449E
	v_or_b32_e32 v39, 31, v34                                  // 0000004A11D4: 384E449F
	v_xor_b32_e32 v0, v0, v18                                  // 0000004A11D8: 3A002500
	v_xor_b32_e32 v5, v5, v18                                  // 0000004A11DC: 3A0A2505
	v_xor_b32_e32 v6, v6, v18                                  // 0000004A11E0: 3A0C2506
	v_xor_b32_e32 v7, v7, v18                                  // 0000004A11E4: 3A0E2507
	v_xor_b32_e32 v9, v9, v18                                  // 0000004A11E8: 3A122509
	v_xor_b32_e32 v10, v10, v18                                // 0000004A11EC: 3A14250A
	v_xor_b32_e32 v11, v11, v18                                // 0000004A11F0: 3A16250B
	v_xor_b32_e32 v12, v12, v18                                // 0000004A11F4: 3A18250C
	v_xor_b32_e32 v13, v13, v18                                // 0000004A11F8: 3A1A250D
	v_xor_b32_e32 v14, v14, v18                                // 0000004A11FC: 3A1C250E
	v_xor_b32_e32 v15, v15, v18                                // 0000004A1200: 3A1E250F
	v_xor_b32_e32 v16, v16, v18                                // 0000004A1204: 3A202510
	v_xor_b32_e32 v20, v20, v18                                // 0000004A1208: 3A282514
	v_xor_b32_e32 v21, v21, v18                                // 0000004A120C: 3A2A2515
	v_xor_b32_e32 v22, v22, v18                                // 0000004A1210: 3A2C2516
	v_xor_b32_e32 v23, v23, v18                                // 0000004A1214: 3A2E2517
	v_xor_b32_e32 v24, v24, v18                                // 0000004A1218: 3A302518
	v_xor_b32_e32 v25, v25, v18                                // 0000004A121C: 3A322519
	v_xor_b32_e32 v26, v26, v18                                // 0000004A1220: 3A34251A
	v_xor_b32_e32 v27, v27, v18                                // 0000004A1224: 3A36251B
	v_xor_b32_e32 v28, v28, v18                                // 0000004A1228: 3A38251C
	v_xor_b32_e32 v29, v29, v18                                // 0000004A122C: 3A3A251D
	v_xor_b32_e32 v30, v30, v18                                // 0000004A1230: 3A3C251E
	v_xor_b32_e32 v31, v31, v18                                // 0000004A1234: 3A3E251F
	v_xor_b32_e32 v32, v32, v18                                // 0000004A1238: 3A402520
	v_xor_b32_e32 v33, v33, v18                                // 0000004A123C: 3A422521
	v_xor_b32_e32 v34, v35, v18                                // 0000004A1240: 3A442523
	v_xor_b32_e32 v35, v36, v18                                // 0000004A1244: 3A462524
	v_xor_b32_e32 v36, v37, v18                                // 0000004A1248: 3A482525
	v_xor_b32_e32 v37, v38, v18                                // 0000004A124C: 3A4A2526
	v_xor_b32_e32 v38, v39, v18                                // 0000004A1250: 3A4C2527
	v_or_b32_e32 v39, -8, v19                                  // 0000004A1254: 384E26C8
	v_and_or_b32 v41, 0x60, v40, v18                           // 0000004A1258: D6570029 044A50FF 00000060
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000004A1264: BF8704A2
	.long 0xd7000427                                           // 0000004A1268: D7000427
	v_cndmask_b32_e32 v0, v39, v136, vcc_lo                    // 0000004A126C: 02011127
	s_xor_b32 s4, s4, -1                                       // 0000004A1270: 8D04C104
	s_and_b32 s4, exec_lo, s4                                  // 0000004A1274: 8B04047E
	v_lshlrev_b32_e32 v41, 9, v41                              // 0000004A1278: 30525289
	s_or_b32 s3, s4, s3                                        // 0000004A127C: 8C030304
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004A1280: BF870001
	v_lshl_or_b32 v42, v3, 2, v41                              // 0000004A1284: D656002A 04A50503
	v_lshl_or_b32 v43, v0, 2, v41                              // 0000004A128C: D656002B 04A50500
	v_lshl_or_b32 v44, v5, 2, v41                              // 0000004A1294: D656002C 04A50505
	v_lshl_or_b32 v45, v6, 2, v41                              // 0000004A129C: D656002D 04A50506
	v_lshl_or_b32 v46, v7, 2, v41                              // 0000004A12A4: D656002E 04A50507
	v_lshl_or_b32 v47, v9, 2, v41                              // 0000004A12AC: D656002F 04A50509
	v_lshl_or_b32 v48, v10, 2, v41                             // 0000004A12B4: D6560030 04A5050A
	v_lshl_or_b32 v49, v11, 2, v41                             // 0000004A12BC: D6560031 04A5050B
	v_lshl_or_b32 v50, v12, 2, v41                             // 0000004A12C4: D6560032 04A5050C
	v_lshl_or_b32 v51, v13, 2, v41                             // 0000004A12CC: D6560033 04A5050D
	v_lshl_or_b32 v52, v14, 2, v41                             // 0000004A12D4: D6560034 04A5050E
	v_lshl_or_b32 v53, v15, 2, v41                             // 0000004A12DC: D6560035 04A5050F
	v_lshl_or_b32 v54, v16, 2, v41                             // 0000004A12E4: D6560036 04A50510
	v_lshl_or_b32 v55, v20, 2, v41                             // 0000004A12EC: D6560037 04A50514
	v_lshl_or_b32 v56, v21, 2, v41                             // 0000004A12F4: D6560038 04A50515
	v_lshl_or_b32 v57, v22, 2, v41                             // 0000004A12FC: D6560039 04A50516
	v_lshl_or_b32 v58, v23, 2, v41                             // 0000004A1304: D656003A 04A50517
	v_lshl_or_b32 v59, v24, 2, v41                             // 0000004A130C: D656003B 04A50518
	v_lshl_or_b32 v60, v25, 2, v41                             // 0000004A1314: D656003C 04A50519
	v_lshl_or_b32 v61, v26, 2, v41                             // 0000004A131C: D656003D 04A5051A
	v_lshl_or_b32 v62, v27, 2, v41                             // 0000004A1324: D656003E 04A5051B
	v_lshl_or_b32 v63, v28, 2, v41                             // 0000004A132C: D656003F 04A5051C
	v_lshl_or_b32 v64, v29, 2, v41                             // 0000004A1334: D6560040 04A5051D
	v_lshl_or_b32 v65, v30, 2, v41                             // 0000004A133C: D6560041 04A5051E
	v_lshl_or_b32 v66, v31, 2, v41                             // 0000004A1344: D6560042 04A5051F
	v_lshl_or_b32 v67, v32, 2, v41                             // 0000004A134C: D6560043 04A50520
	v_lshl_or_b32 v68, v33, 2, v41                             // 0000004A1354: D6560044 04A50521
	v_lshl_or_b32 v69, v34, 2, v41                             // 0000004A135C: D6560045 04A50522
	v_lshl_or_b32 v70, v35, 2, v41                             // 0000004A1364: D6560046 04A50523
	v_lshl_or_b32 v71, v36, 2, v41                             // 0000004A136C: D6560047 04A50524
	v_lshl_or_b32 v72, v37, 2, v41                             // 0000004A1374: D6560048 04A50525
	v_lshl_or_b32 v41, v38, 2, v41                             // 0000004A137C: D6560029 04A50526
	ds_load_b32 v73, v42                                       // 0000004A1384: D8D80000 4900002A
	ds_load_b32 v74, v43                                       // 0000004A138C: D8D80000 4A00002B
	ds_load_b32 v75, v44                                       // 0000004A1394: D8D80000 4B00002C
	ds_load_b32 v76, v45                                       // 0000004A139C: D8D80000 4C00002D
	ds_load_b32 v77, v46                                       // 0000004A13A4: D8D80000 4D00002E
	ds_load_b32 v78, v47                                       // 0000004A13AC: D8D80000 4E00002F
	ds_load_b32 v79, v48                                       // 0000004A13B4: D8D80000 4F000030
	ds_load_b32 v80, v49                                       // 0000004A13BC: D8D80000 50000031
	ds_load_b32 v81, v50                                       // 0000004A13C4: D8D80000 51000032
	ds_load_b32 v82, v51                                       // 0000004A13CC: D8D80000 52000033
	ds_load_b32 v83, v52                                       // 0000004A13D4: D8D80000 53000034
	ds_load_b32 v84, v53                                       // 0000004A13DC: D8D80000 54000035
	ds_load_b32 v85, v54                                       // 0000004A13E4: D8D80000 55000036
	ds_load_b32 v86, v55                                       // 0000004A13EC: D8D80000 56000037
	ds_load_b32 v87, v56                                       // 0000004A13F4: D8D80000 57000038
	ds_load_b32 v88, v57                                       // 0000004A13FC: D8D80000 58000039
	ds_load_b32 v89, v58                                       // 0000004A1404: D8D80000 5900003A
	ds_load_b32 v90, v59                                       // 0000004A140C: D8D80000 5A00003B
	ds_load_b32 v91, v60                                       // 0000004A1414: D8D80000 5B00003C
	ds_load_b32 v92, v61                                       // 0000004A141C: D8D80000 5C00003D
	ds_load_b32 v93, v62                                       // 0000004A1424: D8D80000 5D00003E
	ds_load_b32 v94, v63                                       // 0000004A142C: D8D80000 5E00003F
	ds_load_b32 v95, v64                                       // 0000004A1434: D8D80000 5F000040
	ds_load_b32 v96, v65                                       // 0000004A143C: D8D80000 60000041
	ds_load_b32 v97, v66                                       // 0000004A1444: D8D80000 61000042
	ds_load_b32 v98, v67                                       // 0000004A144C: D8D80000 62000043
	ds_load_b32 v99, v68                                       // 0000004A1454: D8D80000 63000044
	ds_load_b32 v100, v69                                      // 0000004A145C: D8D80000 64000045
	ds_load_b32 v101, v70                                      // 0000004A1464: D8D80000 65000046
	ds_load_b32 v102, v71                                      // 0000004A146C: D8D80000 66000047
	ds_load_b32 v103, v72                                      // 0000004A1474: D8D80000 67000048
	ds_load_b32 v104, v41                                      // 0000004A147C: D8D80000 68000029
	s_waitcnt lgkmcnt(30)                                      // 0000004A1484: BF89FDE7
	v_dual_add_f32 v105, v73, v74 :: v_dual_add_nc_u32 v40, 64, v40// 0000004A1488: C9209549 692850C0
	s_waitcnt lgkmcnt(28)                                      // 0000004A1490: BF89FDC7
	v_dual_sub_f32 v73, v73, v74 :: v_dual_add_f32 v74, v75, v76// 0000004A1494: C9489549 494A994B
	s_waitcnt lgkmcnt(26)                                      // 0000004A149C: BF89FDA7
	v_dual_sub_f32 v75, v75, v76 :: v_dual_add_f32 v76, v77, v78// 0000004A14A0: C948994B 4B4C9D4D
	s_waitcnt lgkmcnt(24)                                      // 0000004A14A8: BF89FD87
	v_dual_sub_f32 v77, v77, v78 :: v_dual_add_f32 v78, v79, v80// 0000004A14AC: C9489D4D 4D4EA14F
	s_waitcnt lgkmcnt(22)                                      // 0000004A14B4: BF89FD67
	v_dual_sub_f32 v79, v79, v80 :: v_dual_add_f32 v80, v81, v82// 0000004A14B8: C948A14F 4F50A551
	s_waitcnt lgkmcnt(20)                                      // 0000004A14C0: BF89FD47
	v_dual_sub_f32 v81, v81, v82 :: v_dual_add_f32 v82, v83, v84// 0000004A14C4: C948A551 5152A953
	s_waitcnt lgkmcnt(18)                                      // 0000004A14CC: BF89FD27
	v_dual_sub_f32 v83, v83, v84 :: v_dual_add_f32 v84, v85, v86// 0000004A14D0: C948A953 5354AD55
	s_waitcnt lgkmcnt(16)                                      // 0000004A14D8: BF89FD07
	v_dual_sub_f32 v85, v85, v86 :: v_dual_add_f32 v86, v87, v88// 0000004A14DC: C948AD55 5556B157
	s_waitcnt lgkmcnt(14)                                      // 0000004A14E4: BF89FCE7
	v_dual_sub_f32 v87, v87, v88 :: v_dual_add_f32 v88, v89, v90// 0000004A14E8: C948B157 5758B559
	s_waitcnt lgkmcnt(12)                                      // 0000004A14F0: BF89FCC7
	v_dual_sub_f32 v89, v89, v90 :: v_dual_add_f32 v90, v91, v92// 0000004A14F4: C948B559 595AB95B
	s_waitcnt lgkmcnt(10)                                      // 0000004A14FC: BF89FCA7
	v_dual_sub_f32 v91, v91, v92 :: v_dual_add_f32 v92, v93, v94// 0000004A1500: C948B95B 5B5CBD5D
	s_waitcnt lgkmcnt(8)                                       // 0000004A1508: BF89FC87
	v_dual_sub_f32 v93, v93, v94 :: v_dual_add_f32 v94, v95, v96// 0000004A150C: C948BD5D 5D5EC15F
	s_waitcnt lgkmcnt(6)                                       // 0000004A1514: BF89FC67
	v_dual_sub_f32 v95, v95, v96 :: v_dual_add_f32 v96, v97, v98// 0000004A1518: C948C15F 5F60C561
	s_waitcnt lgkmcnt(4)                                       // 0000004A1520: BF89FC47
	v_dual_sub_f32 v97, v97, v98 :: v_dual_add_f32 v98, v99, v100// 0000004A1524: C948C561 6162C963
	s_waitcnt lgkmcnt(2)                                       // 0000004A152C: BF89FC27
	v_dual_sub_f32 v99, v99, v100 :: v_dual_add_f32 v100, v101, v102// 0000004A1530: C948C963 6364CD65
	s_waitcnt lgkmcnt(0)                                       // 0000004A1538: BF89FC07
	v_dual_sub_f32 v101, v101, v102 :: v_dual_add_f32 v102, v103, v104// 0000004A153C: C948CD65 6566D167
	v_dual_sub_f32 v103, v103, v104 :: v_dual_add_f32 v104, v105, v74// 0000004A1544: C948D167 67689569
	v_sub_f32_e32 v74, v105, v74                               // 0000004A154C: 08949569
	v_add_f32_e32 v105, v73, v75                               // 0000004A1550: 06D29749
	v_sub_f32_e32 v73, v73, v75                                // 0000004A1554: 08929749
	v_add_f32_e32 v75, v76, v78                                // 0000004A1558: 06969D4C
	v_sub_f32_e32 v76, v76, v78                                // 0000004A155C: 08989D4C
	v_add_f32_e32 v78, v77, v79                                // 0000004A1560: 069C9F4D
	v_sub_f32_e32 v77, v77, v79                                // 0000004A1564: 089A9F4D
	v_add_f32_e32 v79, v80, v82                                // 0000004A1568: 069EA550
	v_sub_f32_e32 v80, v80, v82                                // 0000004A156C: 08A0A550
	v_add_f32_e32 v82, v81, v83                                // 0000004A1570: 06A4A751
	v_sub_f32_e32 v81, v81, v83                                // 0000004A1574: 08A2A751
	v_add_f32_e32 v83, v84, v86                                // 0000004A1578: 06A6AD54
	v_sub_f32_e32 v84, v84, v86                                // 0000004A157C: 08A8AD54
	v_add_f32_e32 v86, v85, v87                                // 0000004A1580: 06ACAF55
	v_sub_f32_e32 v85, v85, v87                                // 0000004A1584: 08AAAF55
	v_add_f32_e32 v87, v88, v90                                // 0000004A1588: 06AEB558
	v_sub_f32_e32 v88, v88, v90                                // 0000004A158C: 08B0B558
	v_add_f32_e32 v90, v89, v91                                // 0000004A1590: 06B4B759
	v_sub_f32_e32 v89, v89, v91                                // 0000004A1594: 08B2B759
	v_add_f32_e32 v91, v92, v94                                // 0000004A1598: 06B6BD5C
	v_sub_f32_e32 v92, v92, v94                                // 0000004A159C: 08B8BD5C
	v_add_f32_e32 v94, v93, v95                                // 0000004A15A0: 06BCBF5D
	v_sub_f32_e32 v93, v93, v95                                // 0000004A15A4: 08BABF5D
	v_add_f32_e32 v95, v96, v98                                // 0000004A15A8: 06BEC560
	v_sub_f32_e32 v96, v96, v98                                // 0000004A15AC: 08C0C560
	v_add_f32_e32 v98, v97, v99                                // 0000004A15B0: 06C4C761
	v_sub_f32_e32 v97, v97, v99                                // 0000004A15B4: 08C2C761
	v_add_f32_e32 v99, v100, v102                              // 0000004A15B8: 06C6CD64
	v_sub_f32_e32 v100, v100, v102                             // 0000004A15BC: 08C8CD64
	v_add_f32_e32 v102, v101, v103                             // 0000004A15C0: 06CCCF65
	v_sub_f32_e32 v101, v101, v103                             // 0000004A15C4: 08CACF65
	v_add_f32_e32 v103, v104, v75                              // 0000004A15C8: 06CE9768
	v_dual_sub_f32 v75, v104, v75 :: v_dual_add_f32 v104, v105, v78// 0000004A15CC: C9489768 4B689D69
	v_dual_sub_f32 v78, v105, v78 :: v_dual_add_f32 v105, v74, v76// 0000004A15D4: C9489D69 4E68994A
	v_sub_f32_e32 v74, v74, v76                                // 0000004A15DC: 0894994A
	v_add_f32_e32 v76, v73, v77                                // 0000004A15E0: 06989B49
	v_sub_f32_e32 v73, v73, v77                                // 0000004A15E4: 08929B49
	v_add_f32_e32 v77, v79, v83                                // 0000004A15E8: 069AA74F
	v_sub_f32_e32 v79, v79, v83                                // 0000004A15EC: 089EA74F
	v_add_f32_e32 v83, v82, v86                                // 0000004A15F0: 06A6AD52
	v_sub_f32_e32 v82, v82, v86                                // 0000004A15F4: 08A4AD52
	v_add_f32_e32 v86, v80, v84                                // 0000004A15F8: 06ACA950
	v_sub_f32_e32 v80, v80, v84                                // 0000004A15FC: 08A0A950
	v_add_f32_e32 v84, v81, v85                                // 0000004A1600: 06A8AB51
	v_sub_f32_e32 v81, v81, v85                                // 0000004A1604: 08A2AB51
	v_add_f32_e32 v85, v87, v91                                // 0000004A1608: 06AAB757
	v_sub_f32_e32 v87, v87, v91                                // 0000004A160C: 08AEB757
	v_add_f32_e32 v91, v90, v94                                // 0000004A1610: 06B6BD5A
	v_sub_f32_e32 v90, v90, v94                                // 0000004A1614: 08B4BD5A
	v_add_f32_e32 v94, v88, v92                                // 0000004A1618: 06BCB958
	v_sub_f32_e32 v88, v88, v92                                // 0000004A161C: 08B0B958
	v_add_f32_e32 v92, v89, v93                                // 0000004A1620: 06B8BB59
	v_sub_f32_e32 v89, v89, v93                                // 0000004A1624: 08B2BB59
	v_add_f32_e32 v93, v95, v99                                // 0000004A1628: 06BAC75F
	v_sub_f32_e32 v95, v95, v99                                // 0000004A162C: 08BEC75F
	v_add_f32_e32 v99, v98, v102                               // 0000004A1630: 06C6CD62
	v_sub_f32_e32 v98, v98, v102                               // 0000004A1634: 08C4CD62
	v_add_f32_e32 v102, v96, v100                              // 0000004A1638: 06CCC960
	v_sub_f32_e32 v96, v96, v100                               // 0000004A163C: 08C0C960
	v_add_f32_e32 v100, v97, v101                              // 0000004A1640: 06C8CB61
	v_sub_f32_e32 v97, v97, v101                               // 0000004A1644: 08C2CB61
	v_add_f32_e32 v101, v103, v77                              // 0000004A1648: 06CA9B67
	v_sub_f32_e32 v77, v103, v77                               // 0000004A164C: 089A9B67
	v_add_f32_e32 v103, v104, v83                              // 0000004A1650: 06CEA768
	v_dual_sub_f32 v83, v104, v83 :: v_dual_add_f32 v104, v105, v86// 0000004A1654: C948A768 5368AD69
	v_dual_sub_f32 v86, v105, v86 :: v_dual_add_f32 v105, v76, v84// 0000004A165C: C948AD69 5668A94C
	v_sub_f32_e32 v76, v76, v84                                // 0000004A1664: 0898A94C
	v_add_f32_e32 v84, v75, v79                                // 0000004A1668: 06A89F4B
	v_sub_f32_e32 v75, v75, v79                                // 0000004A166C: 08969F4B
	v_add_f32_e32 v79, v78, v82                                // 0000004A1670: 069EA54E
	v_sub_f32_e32 v78, v78, v82                                // 0000004A1674: 089CA54E
	v_add_f32_e32 v82, v74, v80                                // 0000004A1678: 06A4A14A
	v_sub_f32_e32 v74, v74, v80                                // 0000004A167C: 0894A14A
	v_add_f32_e32 v80, v73, v81                                // 0000004A1680: 06A0A349
	v_sub_f32_e32 v73, v73, v81                                // 0000004A1684: 0892A349
	v_add_f32_e32 v81, v85, v93                                // 0000004A1688: 06A2BB55
	v_sub_f32_e32 v85, v85, v93                                // 0000004A168C: 08AABB55
	v_add_f32_e32 v93, v91, v99                                // 0000004A1690: 06BAC75B
	v_sub_f32_e32 v91, v91, v99                                // 0000004A1694: 08B6C75B
	v_add_f32_e32 v99, v94, v102                               // 0000004A1698: 06C6CD5E
	v_sub_f32_e32 v94, v94, v102                               // 0000004A169C: 08BCCD5E
	v_add_f32_e32 v102, v92, v100                              // 0000004A16A0: 06CCC95C
	v_sub_f32_e32 v92, v92, v100                               // 0000004A16A4: 08B8C95C
	v_add_f32_e32 v100, v87, v95                               // 0000004A16A8: 06C8BF57
	v_sub_f32_e32 v87, v87, v95                                // 0000004A16AC: 08AEBF57
	v_add_f32_e32 v95, v90, v98                                // 0000004A16B0: 06BEC55A
	v_sub_f32_e32 v90, v90, v98                                // 0000004A16B4: 08B4C55A
	v_add_f32_e32 v98, v88, v96                                // 0000004A16B8: 06C4C158
	v_sub_f32_e32 v88, v88, v96                                // 0000004A16BC: 08B0C158
	v_add_f32_e32 v96, v89, v97                                // 0000004A16C0: 06C0C359
	v_sub_f32_e32 v89, v89, v97                                // 0000004A16C4: 08B2C359
	v_add_f32_e32 v97, v101, v81                               // 0000004A16C8: 06C2A365
	v_sub_f32_e32 v81, v101, v81                               // 0000004A16CC: 08A2A365
	v_add_f32_e32 v101, v103, v93                              // 0000004A16D0: 06CABB67
	v_sub_f32_e32 v93, v103, v93                               // 0000004A16D4: 08BABB67
	v_add_f32_e32 v103, v104, v99                              // 0000004A16D8: 06CEC768
	v_dual_sub_f32 v99, v104, v99 :: v_dual_add_f32 v104, v105, v102// 0000004A16DC: C948C768 6368CD69
	v_dual_sub_f32 v102, v105, v102 :: v_dual_add_f32 v105, v84, v100// 0000004A16E4: C948CD69 6668C954
	v_sub_f32_e32 v84, v84, v100                               // 0000004A16EC: 08A8C954
	v_add_f32_e32 v100, v79, v95                               // 0000004A16F0: 06C8BF4F
	v_sub_f32_e32 v79, v79, v95                                // 0000004A16F4: 089EBF4F
	v_add_f32_e32 v95, v82, v98                                // 0000004A16F8: 06BEC552
	v_sub_f32_e32 v82, v82, v98                                // 0000004A16FC: 08A4C552
	v_add_f32_e32 v98, v80, v96                                // 0000004A1700: 06C4C150
	v_sub_f32_e32 v80, v80, v96                                // 0000004A1704: 08A0C150
	v_add_f32_e32 v96, v77, v85                                // 0000004A1708: 06C0AB4D
	v_sub_f32_e32 v77, v77, v85                                // 0000004A170C: 089AAB4D
	v_add_f32_e32 v85, v83, v91                                // 0000004A1710: 06AAB753
	v_sub_f32_e32 v83, v83, v91                                // 0000004A1714: 08A6B753
	v_add_f32_e32 v91, v86, v94                                // 0000004A1718: 06B6BD56
	v_sub_f32_e32 v86, v86, v94                                // 0000004A171C: 08ACBD56
	v_add_f32_e32 v94, v76, v92                                // 0000004A1720: 06BCB94C
	v_sub_f32_e32 v76, v76, v92                                // 0000004A1724: 0898B94C
	v_add_f32_e32 v92, v75, v87                                // 0000004A1728: 06B8AF4B
	v_sub_f32_e32 v75, v75, v87                                // 0000004A172C: 0896AF4B
	v_add_f32_e32 v87, v78, v90                                // 0000004A1730: 06AEB54E
	v_sub_f32_e32 v78, v78, v90                                // 0000004A1734: 089CB54E
	v_add_f32_e32 v90, v74, v88                                // 0000004A1738: 06B4B14A
	v_sub_f32_e32 v74, v74, v88                                // 0000004A173C: 0894B14A
	v_add_f32_e32 v88, v73, v89                                // 0000004A1740: 06B0B349
	v_sub_f32_e32 v73, v73, v89                                // 0000004A1744: 0892B349
	ds_store_b32 v42, v97                                      // 0000004A1748: D8340000 0000612A
	ds_store_b32 v43, v101                                     // 0000004A1750: D8340000 0000652B
	ds_store_b32 v44, v103                                     // 0000004A1758: D8340000 0000672C
	ds_store_b32 v45, v104                                     // 0000004A1760: D8340000 0000682D
	ds_store_b32 v46, v105                                     // 0000004A1768: D8340000 0000692E
	ds_store_b32 v47, v100                                     // 0000004A1770: D8340000 0000642F
	ds_store_b32 v48, v95                                      // 0000004A1778: D8340000 00005F30
	ds_store_b32 v49, v98                                      // 0000004A1780: D8340000 00006231
	ds_store_b32 v50, v96                                      // 0000004A1788: D8340000 00006032
	ds_store_b32 v51, v85                                      // 0000004A1790: D8340000 00005533
	ds_store_b32 v52, v91                                      // 0000004A1798: D8340000 00005B34
	ds_store_b32 v53, v94                                      // 0000004A17A0: D8340000 00005E35
	ds_store_b32 v54, v92                                      // 0000004A17A8: D8340000 00005C36
	ds_store_b32 v55, v87                                      // 0000004A17B0: D8340000 00005737
	ds_store_b32 v56, v90                                      // 0000004A17B8: D8340000 00005A38
	ds_store_b32 v57, v88                                      // 0000004A17C0: D8340000 00005839
	ds_store_b32 v58, v81                                      // 0000004A17C8: D8340000 0000513A
	ds_store_b32 v59, v93                                      // 0000004A17D0: D8340000 00005D3B
	ds_store_b32 v60, v99                                      // 0000004A17D8: D8340000 0000633C
	ds_store_b32 v61, v102                                     // 0000004A17E0: D8340000 0000663D
	ds_store_b32 v62, v84                                      // 0000004A17E8: D8340000 0000543E
	ds_store_b32 v63, v79                                      // 0000004A17F0: D8340000 00004F3F
	ds_store_b32 v64, v82                                      // 0000004A17F8: D8340000 00005240
	ds_store_b32 v65, v80                                      // 0000004A1800: D8340000 00005041
	ds_store_b32 v66, v77                                      // 0000004A1808: D8340000 00004D42
	ds_store_b32 v67, v83                                      // 0000004A1810: D8340000 00005343
	ds_store_b32 v68, v86                                      // 0000004A1818: D8340000 00005644
	ds_store_b32 v69, v76                                      // 0000004A1820: D8340000 00004C45
	ds_store_b32 v70, v75                                      // 0000004A1828: D8340000 00004B46
	ds_store_b32 v71, v78                                      // 0000004A1830: D8340000 00004E47
	ds_store_b32 v72, v74                                      // 0000004A1838: D8340000 00004A48
	ds_store_b32 v41, v73                                      // 0000004A1840: D8340000 00004929
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 0000004A1848: 917E037E
	s_cbranch_execnz 65154                                     // 0000004A184C: BFA6FE82 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi3ELb1ELi8EEEvPKjiPKDF16_S5_Pti+0x1858>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000004A1850: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004A1854: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 0000004A1858: 8C7E007E
	v_or_b32_e32 v0, 32, v17                                   // 0000004A185C: 380022A0
	v_or_b32_e32 v5, 64, v17                                   // 0000004A1860: 380A22C0
	v_or_b32_e32 v6, 0x60, v17                                 // 0000004A1864: 380C22FF 00000060
	v_lshlrev_b32_e32 v23, 9, v3                               // 0000004A186C: 302E0689
	v_xor_b32_e32 v7, v17, v18                                 // 0000004A1870: 3A0E2511
	v_xor_b32_e32 v0, v0, v18                                  // 0000004A1874: 3A002500
	v_xor_b32_e32 v5, v5, v18                                  // 0000004A1878: 3A0A2505
	v_xor_b32_e32 v6, v6, v18                                  // 0000004A187C: 3A0C2506
	s_waitcnt lgkmcnt(0)                                       // 0000004A1880: BF89FC07
	v_lshl_or_b32 v22, v7, 2, v23                              // 0000004A1884: D6560016 045D0507
	v_lshl_or_b32 v0, v0, 2, v23                               // 0000004A188C: D6560000 045D0500
	v_lshl_or_b32 v5, v5, 2, v23                               // 0000004A1894: D6560005 045D0505
	v_lshl_or_b32 v6, v6, 2, v23                               // 0000004A189C: D6560006 045D0506
	s_barrier                                                  // 0000004A18A4: BFBD0000
	buffer_gl0_inv                                             // 0000004A18A8: E0AC0000 00000000
	ds_load_b32 v7, v22                                        // 0000004A18B0: D8D80000 07000016
	ds_load_b32 v9, v0                                         // 0000004A18B8: D8D80000 09000000
	ds_load_b32 v10, v5                                        // 0000004A18C0: D8D80000 0A000005
	ds_load_b32 v11, v6                                        // 0000004A18C8: D8D80000 0B000006
	v_or_b32_e32 v21, 2, v17                                   // 0000004A18D0: 382A2282
	v_or_b32_e32 v20, 4, v17                                   // 0000004A18D4: 38282284
	v_or_b32_e32 v15, 6, v17                                   // 0000004A18D8: 381E2286
	v_cvt_f32_f16_e32 v24, v130/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A18DC: 7E301782
	v_cvt_f32_f16_e32 v25, v2                                  // 0000004A18E0: 7E321702
	v_xor_b32_e32 v12, v21, v18                                // 0000004A18E4: 3A182515
	v_xor_b32_e32 v13, v20, v18                                // 0000004A18E8: 3A1A2514
	v_xor_b32_e32 v14, v15, v18                                // 0000004A18EC: 3A1C250F
	.long 0xd7600003                                           // 0000004A18F0: D7600003
	v_cndmask_b32_e32 v0, v24, v144, vcc_lo                    // 0000004A18F4: 02012118
	v_or_b32_e32 v2, 34, v17                                   // 0000004A18F8: 380422A2
	v_or_b32_e32 v32, 0x42, v17                                // 0000004A18FC: 384022FF 00000042
	.long 0xd7600000                                           // 0000004A1904: D7600000
	v_cndmask_b32_e32 v0, v25, v128, vcc_lo                    // 0000004A1908: 02010119
	.long 0xd7600004                                           // 0000004A190C: D7600004
	v_cndmask_b32_e32 v0, v25, v144, vcc_lo                    // 0000004A1910: 02012119
	v_or_b32_e32 v40, 0x66, v17                                // 0000004A1914: 385022FF 00000066
	v_xor_b32_e32 v2, v2, v18                                  // 0000004A191C: 3A042502
	.long 0xd760000b                                           // 0000004A1920: D760000B
	v_cndmask_b32_e32 v0, v24, v158, vcc_lo                    // 0000004A1924: 02013D18
	.long 0xd760000e                                           // 0000004A1928: D760000E
	v_cndmask_b32_e32 v0, v24, v143, vcc_lo                    // 0000004A192C: 02011F18
	s_waitcnt lgkmcnt(2)                                       // 0000004A1930: BF89FC27
	v_sub_f32_e32 v30, v7, v9                                  // 0000004A1934: 083C1307
	s_waitcnt lgkmcnt(0)                                       // 0000004A1938: BF89FC07
	v_dual_add_f32 v26, v7, v9 :: v_dual_sub_f32 v31, v10, v11 // 0000004A193C: C90A1307 1A1E170A
	v_add_f32_e32 v27, v10, v11                                // 0000004A1944: 0636170A
	v_lshl_or_b32 v12, v12, 2, v23                             // 0000004A1948: D656000C 045D050C
	v_lshl_or_b32 v13, v13, 2, v23                             // 0000004A1950: D656000D 045D050D
	v_lshl_or_b32 v14, v14, 2, v23                             // 0000004A1958: D656000E 045D050E
	ds_load_b32 v16, v12                                       // 0000004A1960: D8D80000 1000000C
	ds_load_b32 v28, v13                                       // 0000004A1968: D8D80000 1C00000D
	ds_load_b32 v29, v14                                       // 0000004A1970: D8D80000 1D00000E
	v_sub_f32_e32 v10, v26, v27                                // 0000004A1978: 0814371A
	v_sub_f32_e32 v11, v30, v31                                // 0000004A197C: 08163F1E
	v_or_b32_e32 v7, 0x62, v17                                 // 0000004A1980: 380E22FF 00000062
	v_lshl_or_b32 v2, v2, 2, v23                               // 0000004A1988: D6560002 045D0502
	.long 0xd7600011                                           // 0000004A1990: D7600011
	v_cndmask_b32_e32 v0, v25, v159, vcc_lo                    // 0000004A1994: 02013F19
	v_dual_mul_f32 v10, 0x3db504f3, v10 :: v_dual_add_f32 v9, v30, v31// 0000004A1998: C8C814FF 0A083F1E 3DB504F3
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 0000004A19A4: 101616FF 3DB504F3
	v_xor_b32_e32 v30, v32, v18                                // 0000004A19AC: 3A3C2520
	v_xor_b32_e32 v7, v7, v18                                  // 0000004A19B0: 3A0E2507
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A19B4: BF870214
	v_dual_mul_f32 v10, s3, v10 :: v_dual_mul_f32 v9, 0x3db504f3, v9// 0000004A19B8: C8C61403 0A0812FF 3DB504F3
	v_mul_f32_e32 v11, s4, v11                                 // 0000004A19C4: 10161604
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A19C8: BF870214
	v_lshl_or_b32 v30, v30, 2, v23                             // 0000004A19CC: D656001E 045D051E
	v_lshl_or_b32 v7, v7, 2, v23                               // 0000004A19D4: D6560007 045D0507
	v_or_b32_e32 v31, 38, v17                                  // 0000004A19DC: 383E22A6
	v_mul_f32_e32 v9, s0, v9                                   // 0000004A19E0: 10121200
	ds_store_b32 v0, v9                                        // 0000004A19E4: D8340000 00000900
	ds_store_b32 v5, v10                                       // 0000004A19EC: D8340000 00000A05
	ds_store_b32 v6, v11                                       // 0000004A19F4: D8340000 00000B06
	ds_load_b32 v0, v2                                         // 0000004A19FC: D8D80000 00000002
	ds_load_b32 v5, v30                                        // 0000004A1A04: D8D80000 0500001E
	ds_load_b32 v6, v7                                         // 0000004A1A0C: D8D80000 06000007
	v_or_b32_e32 v9, 36, v17                                   // 0000004A1A14: 381222A4
	v_or_b32_e32 v10, 0x44, v17                                // 0000004A1A18: 381422FF 00000044
	v_or_b32_e32 v11, 0x64, v17                                // 0000004A1A20: 381622FF 00000064
	v_or_b32_e32 v32, 0x46, v17                                // 0000004A1A28: 384022FF 00000046
	v_xor_b32_e32 v31, v31, v18                                // 0000004A1A30: 3A3E251F
	v_xor_b32_e32 v9, v9, v18                                  // 0000004A1A34: 3A122509
	v_xor_b32_e32 v10, v10, v18                                // 0000004A1A38: 3A14250A
	v_xor_b32_e32 v11, v11, v18                                // 0000004A1A3C: 3A16250B
	v_xor_b32_e32 v32, v32, v18                                // 0000004A1A40: 3A402520
	v_lshl_or_b32 v31, v31, 2, v23                             // 0000004A1A44: D656001F 045D051F
	v_lshl_or_b32 v9, v9, 2, v23                               // 0000004A1A4C: D6560009 045D0509
	v_lshl_or_b32 v10, v10, 2, v23                             // 0000004A1A54: D656000A 045D050A
	v_lshl_or_b32 v11, v11, 2, v23                             // 0000004A1A5C: D656000B 045D050B
	v_lshl_or_b32 v32, v32, 2, v23                             // 0000004A1A64: D6560020 045D0520
	ds_load_b32 v33, v9                                        // 0000004A1A6C: D8D80000 21000009
	ds_load_b32 v34, v10                                       // 0000004A1A74: D8D80000 2200000A
	ds_load_b32 v35, v11                                       // 0000004A1A7C: D8D80000 2300000B
	ds_load_b32 v36, v31                                       // 0000004A1A84: D8D80000 2400001F
	ds_load_b32 v37, v32                                       // 0000004A1A8C: D8D80000 25000020
	.long 0xd7600000                                           // 0000004A1A94: D7600000
	v_cndmask_b32_e32 v0, v24, v129, vcc_lo                    // 0000004A1A98: 02010318
	s_waitcnt lgkmcnt(7)                                       // 0000004A1A9C: BF89FC77
	v_add_f32_e32 v38, v16, v0                                 // 0000004A1AA0: 064C0110
	s_waitcnt lgkmcnt(5)                                       // 0000004A1AA4: BF89FC57
	v_dual_sub_f32 v0, v16, v0 :: v_dual_add_f32 v39, v5, v6   // 0000004A1AA8: C9480110 00260D05
	v_sub_f32_e32 v5, v5, v6                                   // 0000004A1AB0: 080A0D05
	.long 0xd7600003                                           // 0000004A1AB4: D7600003
	v_cndmask_b32_e32 v0, v25, v129, vcc_lo                    // 0000004A1AB8: 02010319
	.long 0xd7600004                                           // 0000004A1ABC: D7600004
	v_cndmask_b32_e32 v0, v25, v146, vcc_lo                    // 0000004A1AC0: 02012519
	v_add_f32_e32 v26, v26, v27                                // 0000004A1AC4: 0634371A
	.long 0xd7600006                                           // 0000004A1AC8: D7600006
	v_cndmask_b32_e32 v0, v25, v157, vcc_lo                    // 0000004A1ACC: 02013B19
	v_add_f32_e32 v16, v0, v5                                  // 0000004A1AD0: 06200B00
	.long 0xd760000a                                           // 0000004A1AD4: D760000A
	v_cndmask_b32_e32 v0, v25, v142, vcc_lo                    // 0000004A1AD8: 02011D19
	.long 0xd760000d                                           // 0000004A1ADC: D760000D
	v_cndmask_b32_e32 v0, v25, v158, vcc_lo                    // 0000004A1AE0: 02013D19
	v_mul_f32_e32 v26, 0x3db504f3, v26                         // 0000004A1AE4: 103434FF 3DB504F3
	.long 0xd760000f                                           // 0000004A1AEC: D760000F
	v_cndmask_b32_e32 v0, v25, v143, vcc_lo                    // 0000004A1AF0: 02011F19
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 0000004A1AF4: 102020FF 3DB504F3
	v_add_f32_e32 v6, v38, v39                                 // 0000004A1AFC: 060C4F26
	v_sub_f32_e32 v38, v38, v39                                // 0000004A1B00: 084C4F26
	v_xor_b32_e32 v39, v40, v18                                // 0000004A1B04: 3A4E2528
	s_waitcnt lgkmcnt(2)                                       // 0000004A1B08: BF89FC27
	v_add_f32_e32 v40, v34, v35                                // 0000004A1B0C: 06504722
	.long 0xd7600005                                           // 0000004A1B10: D7600005
	v_cndmask_b32_e32 v0, v24, v157, vcc_lo                    // 0000004A1B14: 02013B18
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 0000004A1B18: 100C0CFF 3DB504F3
	v_sub_f32_e32 v0, v0, v5                                   // 0000004A1B20: 08000B00
	v_lshl_or_b32 v39, v39, 2, v23                             // 0000004A1B24: D6560027 045D0527
	v_mul_f32_e32 v38, 0x3db504f3, v38                         // 0000004A1B2C: 104C4CFF 3DB504F3
	.long 0xd7600007                                           // 0000004A1B34: D7600007
	v_cndmask_b32_e32 v0, v24, v142, vcc_lo                    // 0000004A1B38: 02011D18
	v_dual_mul_f32 v5, s0, v6 :: v_dual_mul_f32 v6, s3, v16    // 0000004A1B3C: C8C60C00 05062003
	ds_load_b32 v41, v39                                       // 0000004A1B44: D8D80000 29000027
	v_add_f32_e32 v16, v28, v33                                // 0000004A1B4C: 0620431C
	.long 0xd7600000                                           // 0000004A1B50: D7600000
	v_cndmask_b32_e32 v0, v24, v145, vcc_lo                    // 0000004A1B54: 02012318
	v_dual_sub_f32 v28, v28, v33 :: v_dual_sub_f32 v33, v34, v35// 0000004A1B58: C94A431C 1C204722
	.long 0xd7600003                                           // 0000004A1B60: D7600003
	v_cndmask_b32_e32 v0, v25, v145, vcc_lo                    // 0000004A1B64: 02012319
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A1B68: BF870214
	v_add_f32_e32 v42, v16, v40                                // 0000004A1B6C: 06545110
	v_mul_f32_e32 v34, s0, v38                                 // 0000004A1B70: 10444C00
	.long 0xd7600000                                           // 0000004A1B74: D7600000
	v_cndmask_b32_e32 v0, v24, v130, vcc_lo                    // 0000004A1B78: 02010518
	v_add_f32_e32 v38, v28, v33                                // 0000004A1B7C: 064C431C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004A1B80: BF870124
	v_dual_sub_f32 v28, v28, v33 :: v_dual_mul_f32 v35, 0x3db504f3, v42// 0000004A1B84: C946431C 1C2254FF 3DB504F3
	.long 0xd7600010                                           // 0000004A1B90: D7600010
	v_cndmask_b32_e32 v0, v24, v159, vcc_lo                    // 0000004A1B94: 02013F18
	v_dual_mul_f32 v28, 0x3db504f3, v28 :: v_dual_mul_f32 v33, s0, v35// 0000004A1B98: C8C638FF 1C204600 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A1BA4: BF870004
	v_dual_mul_f32 v35, 0x3db504f3, v38 :: v_dual_sub_f32 v16, v16, v40// 0000004A1BA8: C8CA4CFF 23105110 3DB504F3
	s_waitcnt lgkmcnt(2)                                       // 0000004A1BB4: BF89FC27
	v_add_f32_e32 v38, v29, v36                                // 0000004A1BB8: 064C491D
	s_waitcnt lgkmcnt(0)                                       // 0000004A1BBC: BF89FC07
	v_add_f32_e32 v40, v37, v41                                // 0000004A1BC0: 06505325
	.long 0xd7600000                                           // 0000004A1BC4: D7600000
	v_cndmask_b32_e32 v0, v25, v130, vcc_lo                    // 0000004A1BC8: 02010519
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000004A1BCC: 100000FF 3DB504F3
	v_sub_f32_e32 v29, v29, v36                                // 0000004A1BD4: 083A491D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000004A1BD8: BF870254
	v_dual_sub_f32 v36, v37, v41 :: v_dual_add_f32 v37, v38, v40// 0000004A1BDC: C9485325 24245126
	v_sub_f32_e32 v38, v38, v40                                // 0000004A1BE4: 084C5126
	v_dual_mul_f32 v16, 0x3db504f3, v16 :: v_dual_mul_f32 v35, s0, v35// 0000004A1BE8: C8C620FF 10224600 3DB504F3
	v_mul_f32_e32 v28, s4, v28                                 // 0000004A1BF4: 10383804
	.long 0xd7600004                                           // 0000004A1BF8: D7600004
	v_cndmask_b32_e32 v0, v24, v147, vcc_lo                    // 0000004A1BFC: 02012718
	v_mul_f32_e32 v38, 0x3db504f3, v38                         // 0000004A1C00: 104C4CFF 3DB504F3
	v_mul_f32_e32 v0, s3, v0                                   // 0000004A1C08: 10000003
	.long 0xd7600003                                           // 0000004A1C0C: D7600003
	v_cndmask_b32_e32 v0, v24, v146, vcc_lo                    // 0000004A1C10: 02012518
	v_add_f32_e32 v41, v29, v36                                // 0000004A1C14: 0652491D
	v_dual_sub_f32 v29, v29, v36 :: v_dual_mul_f32 v36, 0x3db504f3, v37// 0000004A1C18: C946491D 1D244AFF 3DB504F3
	.long 0xd7600000                                           // 0000004A1C24: D7600000
	v_cndmask_b32_e32 v0, v24, v131, vcc_lo                    // 0000004A1C28: 02010718
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A1C2C: BF870004
	v_mul_f32_e32 v16, s3, v16                                 // 0000004A1C30: 10202003
	ds_store_b32 v12, v5                                       // 0000004A1C34: D8340000 0000050C
	ds_store_b32 v2, v6                                        // 0000004A1C3C: D8340000 00000602
	ds_store_b32 v30, v34                                      // 0000004A1C44: D8340000 0000221E
	ds_store_b32 v7, v0                                        // 0000004A1C4C: D8340000 00000007
	ds_store_b32 v13, v33                                      // 0000004A1C54: D8340000 0000210D
	ds_store_b32 v9, v35                                       // 0000004A1C5C: D8340000 00002309
	ds_store_b32 v10, v16                                      // 0000004A1C64: D8340000 0000100A
	ds_store_b32 v11, v28                                      // 0000004A1C6C: D8340000 00001C0B
	v_or_b32_e32 v16, 8, v17                                   // 0000004A1C74: 38202288
	v_or_b32_e32 v7, 40, v17                                   // 0000004A1C78: 380E22A8
	v_or_b32_e32 v9, 0x48, v17                                 // 0000004A1C7C: 381222FF 00000048
	v_or_b32_e32 v10, 0x68, v17                                // 0000004A1C84: 381422FF 00000068
	v_mul_f32_e32 v37, 0x3db504f3, v41                         // 0000004A1C8C: 104A52FF 3DB504F3
	.long 0xd7600003                                           // 0000004A1C94: D7600003
	v_cndmask_b32_e32 v0, v25, v131, vcc_lo                    // 0000004A1C98: 02010719
	v_xor_b32_e32 v11, v16, v18                                // 0000004A1C9C: 3A162510
	v_xor_b32_e32 v7, v7, v18                                  // 0000004A1CA0: 3A0E2507
	v_mul_f32_e32 v0, s0, v36                                  // 0000004A1CA4: 10004800
	v_mul_f32_e32 v6, 0x3db504f3, v29                          // 0000004A1CA8: 100C3AFF 3DB504F3
	.long 0xd7600000                                           // 0000004A1CB0: D7600000
	v_cndmask_b32_e32 v0, v25, v147, vcc_lo                    // 0000004A1CB4: 02012719
	v_xor_b32_e32 v9, v9, v18                                  // 0000004A1CB8: 3A122509
	v_xor_b32_e32 v10, v10, v18                                // 0000004A1CBC: 3A14250A
	v_mul_f32_e32 v2, s3, v37                                  // 0000004A1CC0: 10044A03
	v_lshl_or_b32 v11, v11, 2, v23                             // 0000004A1CC4: D656000B 045D050B
	v_mul_f32_e32 v5, s4, v38                                  // 0000004A1CCC: 100A4C04
	v_lshl_or_b32 v7, v7, 2, v23                               // 0000004A1CD0: D6560007 045D0507
	v_mul_f32_e32 v6, s0, v6                                   // 0000004A1CD8: 100C0C00
	v_lshl_or_b32 v9, v9, 2, v23                               // 0000004A1CDC: D6560009 045D0509
	v_lshl_or_b32 v10, v10, 2, v23                             // 0000004A1CE4: D656000A 045D050A
	ds_store_b32 v14, v0                                       // 0000004A1CEC: D8340000 0000000E
	ds_store_b32 v31, v2                                       // 0000004A1CF4: D8340000 0000021F
	ds_store_b32 v32, v5                                       // 0000004A1CFC: D8340000 00000520
	ds_store_b32 v39, v6                                       // 0000004A1D04: D8340000 00000627
	ds_load_b32 v0, v11                                        // 0000004A1D0C: D8D80000 0000000B
	ds_load_b32 v2, v7                                         // 0000004A1D14: D8D80000 02000007
	ds_load_b32 v5, v9                                         // 0000004A1D1C: D8D80000 05000009
	ds_load_b32 v6, v10                                        // 0000004A1D24: D8D80000 0600000A
	.long 0xd7600000                                           // 0000004A1D2C: D7600000
	v_cndmask_b32_e32 v0, v24, v132, vcc_lo                    // 0000004A1D30: 02010918
	.long 0xd7600003                                           // 0000004A1D34: D7600003
	v_cndmask_b32_e32 v0, v25, v132, vcc_lo                    // 0000004A1D38: 02010919
	.long 0xd7600004                                           // 0000004A1D3C: D7600004
	v_cndmask_b32_e32 v0, v24, v148, vcc_lo                    // 0000004A1D40: 02012918
	v_or_b32_e32 v14, 10, v17                                  // 0000004A1D44: 381C228A
	v_or_b32_e32 v28, 0x6a, v17                                // 0000004A1D48: 383822FF 0000006A
	v_or_b32_e32 v37, 0x4e, v17                                // 0000004A1D50: 384A22FF 0000004E
	v_or_b32_e32 v38, 0x6e, v17                                // 0000004A1D58: 384C22FF 0000006E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A1D60: BF870214
	v_xor_b32_e32 v29, v14, v18                                // 0000004A1D64: 3A3A250E
	v_xor_b32_e32 v28, v28, v18                                // 0000004A1D68: 3A38251C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A1D6C: BF870214
	v_xor_b32_e32 v37, v37, v18                                // 0000004A1D70: 3A4A2525
	v_xor_b32_e32 v38, v38, v18                                // 0000004A1D74: 3A4C2526
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A1D78: BF870214
	v_lshl_or_b32 v29, v29, 2, v23                             // 0000004A1D7C: D656001D 045D051D
	v_lshl_or_b32 v28, v28, 2, v23                             // 0000004A1D84: D656001C 045D051C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A1D8C: BF870214
	v_lshl_or_b32 v37, v37, 2, v23                             // 0000004A1D90: D6560025 045D0525
	v_lshl_or_b32 v38, v38, 2, v23                             // 0000004A1D98: D6560026 045D0526
	s_waitcnt lgkmcnt(2)                                       // 0000004A1DA0: BF89FC27
	v_add_f32_e32 v12, v0, v2                                  // 0000004A1DA4: 06180500
	v_sub_f32_e32 v0, v0, v2                                   // 0000004A1DA8: 08000500
	s_waitcnt lgkmcnt(0)                                       // 0000004A1DAC: BF89FC07
	v_add_f32_e32 v13, v5, v6                                  // 0000004A1DB0: 061A0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004A1DB4: BF870091
	v_dual_sub_f32 v2, v5, v6 :: v_dual_add_f32 v5, v12, v13   // 0000004A1DB8: C9480D05 02041B0C
	v_add_f32_e32 v6, v0, v2                                   // 0000004A1DC0: 060C0500
	v_sub_f32_e32 v12, v12, v13                                // 0000004A1DC4: 08181B0C
	v_sub_f32_e32 v0, v0, v2                                   // 0000004A1DC8: 08000500
	v_or_b32_e32 v13, 0x4a, v17                                // 0000004A1DCC: 381A22FF 0000004A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A1DD4: BF870214
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v6, 0x3db504f3, v6// 0000004A1DD8: C8C60AFF 05060CFF 3DB504F3
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 0000004A1DE4: 101818FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A1DEC: BF870214
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000004A1DF0: 100000FF 3DB504F3
	v_xor_b32_e32 v13, v13, v18                                // 0000004A1DF8: 3A1A250D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A1DFC: BF870214
	v_dual_mul_f32 v2, s0, v5 :: v_dual_mul_f32 v5, s3, v6     // 0000004A1E00: C8C60A00 02040C03
	v_mul_f32_e32 v6, s4, v12                                  // 0000004A1E08: 100C1804
	v_or_b32_e32 v12, 42, v17                                  // 0000004A1E0C: 381822AA
	.long 0xd7600000                                           // 0000004A1E10: D7600000
	v_cndmask_b32_e32 v0, v25, v148, vcc_lo                    // 0000004A1E14: 02012919
	v_lshl_or_b32 v31, v13, 2, v23                             // 0000004A1E18: D656001F 045D050D
	v_or_b32_e32 v13, 12, v17                                  // 0000004A1E20: 381A228C
	.long 0xd7600003                                           // 0000004A1E24: D7600003
	v_cndmask_b32_e32 v0, v25, v133, vcc_lo                    // 0000004A1E28: 02010B19
	v_xor_b32_e32 v12, v12, v18                                // 0000004A1E2C: 3A18250C
	v_mul_f32_e32 v0, s0, v0                                   // 0000004A1E30: 10000000
	ds_store_b32 v11, v2                                       // 0000004A1E34: D8340000 0000020B
	ds_store_b32 v7, v5                                        // 0000004A1E3C: D8340000 00000507
	ds_store_b32 v9, v6                                        // 0000004A1E44: D8340000 00000609
	ds_store_b32 v10, v0                                       // 0000004A1E4C: D8340000 0000000A
	v_or_b32_e32 v7, 44, v17                                   // 0000004A1E54: 380E22AC
	v_lshl_or_b32 v30, v12, 2, v23                             // 0000004A1E58: D656001E 045D050C
	ds_load_b32 v0, v29                                        // 0000004A1E60: D8D80000 0000001D
	ds_load_b32 v2, v30                                        // 0000004A1E68: D8D80000 0200001E
	ds_load_b32 v5, v31                                        // 0000004A1E70: D8D80000 0500001F
	ds_load_b32 v6, v28                                        // 0000004A1E78: D8D80000 0600001C
	v_or_b32_e32 v9, 0x4c, v17                                 // 0000004A1E80: 381222FF 0000004C
	v_or_b32_e32 v10, 0x6c, v17                                // 0000004A1E88: 381422FF 0000006C
	v_xor_b32_e32 v11, v13, v18                                // 0000004A1E90: 3A16250D
	v_xor_b32_e32 v7, v7, v18                                  // 0000004A1E94: 3A0E2507
	.long 0xd7600000                                           // 0000004A1E98: D7600000
	v_cndmask_b32_e32 v0, v24, v133, vcc_lo                    // 0000004A1E9C: 02010B18
	v_xor_b32_e32 v9, v9, v18                                  // 0000004A1EA0: 3A122509
	v_xor_b32_e32 v10, v10, v18                                // 0000004A1EA4: 3A14250A
	v_lshl_or_b32 v11, v11, 2, v23                             // 0000004A1EA8: D656000B 045D050B
	v_lshl_or_b32 v7, v7, 2, v23                               // 0000004A1EB0: D6560007 045D0507
	.long 0xd7600004                                           // 0000004A1EB8: D7600004
	v_cndmask_b32_e32 v0, v25, v150, vcc_lo                    // 0000004A1EBC: 02012D19
	v_lshl_or_b32 v9, v9, 2, v23                               // 0000004A1EC0: D6560009 045D0509
	v_lshl_or_b32 v10, v10, 2, v23                             // 0000004A1EC8: D656000A 045D050A
	ds_load_b32 v32, v11                                       // 0000004A1ED0: D8D80000 2000000B
	ds_load_b32 v33, v7                                        // 0000004A1ED8: D8D80000 21000007
	ds_load_b32 v34, v9                                        // 0000004A1EE0: D8D80000 22000009
	ds_load_b32 v35, v10                                       // 0000004A1EE8: D8D80000 2300000A
	s_waitcnt lgkmcnt(6)                                       // 0000004A1EF0: BF89FC67
	v_add_f32_e32 v12, v0, v2                                  // 0000004A1EF4: 06180500
	v_sub_f32_e32 v0, v0, v2                                   // 0000004A1EF8: 08000500
	s_waitcnt lgkmcnt(4)                                       // 0000004A1EFC: BF89FC47
	v_add_f32_e32 v36, v5, v6                                  // 0000004A1F00: 06480D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004A1F04: BF870091
	v_dual_sub_f32 v2, v5, v6 :: v_dual_add_f32 v5, v12, v36   // 0000004A1F08: C9480D05 0204490C
	v_add_f32_e32 v6, v0, v2                                   // 0000004A1F10: 060C0500
	v_sub_f32_e32 v12, v12, v36                                // 0000004A1F14: 0818490C
	v_sub_f32_e32 v0, v0, v2                                   // 0000004A1F18: 08000500
	v_or_b32_e32 v36, 46, v17                                  // 0000004A1F1C: 384822AE
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A1F20: BF870004
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v6, 0x3db504f3, v6// 0000004A1F24: C8C60AFF 05060CFF 3DB504F3
	s_waitcnt lgkmcnt(2)                                       // 0000004A1F30: BF89FC27
	v_add_f32_e32 v40, v32, v33                                // 0000004A1F34: 06504320
	v_sub_f32_e32 v32, v32, v33                                // 0000004A1F38: 08404320
	v_xor_b32_e32 v36, v36, v18                                // 0000004A1F3C: 3A482524
	v_dual_mul_f32 v2, s0, v5 :: v_dual_mul_f32 v5, s3, v6     // 0000004A1F40: C8C60A00 02040C03
	v_mul_f32_e32 v6, 0x3db504f3, v12                          // 0000004A1F48: 100C18FF 3DB504F3
	v_or_b32_e32 v12, 14, v17                                  // 0000004A1F50: 3818228E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A1F54: BF870004
	v_lshl_or_b32 v36, v36, 2, v23                             // 0000004A1F58: D6560024 045D0524
	s_waitcnt lgkmcnt(0)                                       // 0000004A1F60: BF89FC07
	v_add_f32_e32 v41, v34, v35                                // 0000004A1F64: 06524722
	.long 0xd7600000                                           // 0000004A1F68: D7600000
	v_cndmask_b32_e32 v0, v24, v149, vcc_lo                    // 0000004A1F6C: 02012B18
	v_sub_f32_e32 v33, v34, v35                                // 0000004A1F70: 08424722
	v_xor_b32_e32 v39, v12, v18                                // 0000004A1F74: 3A4E250C
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000004A1F78: 100000FF 3DB504F3
	v_add_f32_e32 v46, v40, v41                                // 0000004A1F80: 065C5328
	v_mul_f32_e32 v6, s0, v6                                   // 0000004A1F84: 100C0C00
	.long 0xd7600000                                           // 0000004A1F88: D7600000
	v_cndmask_b32_e32 v0, v24, v134, vcc_lo                    // 0000004A1F8C: 02010D18
	v_lshl_or_b32 v39, v39, 2, v23                             // 0000004A1F90: D6560027 045D0527
	ds_load_b32 v42, v39                                       // 0000004A1F98: D8D80000 2A000027
	ds_load_b32 v43, v36                                       // 0000004A1FA0: D8D80000 2B000024
	ds_load_b32 v44, v37                                       // 0000004A1FA8: D8D80000 2C000025
	ds_load_b32 v45, v38                                       // 0000004A1FB0: D8D80000 2D000026
	v_dual_mul_f32 v34, 0x3db504f3, v46 :: v_dual_add_f32 v35, v32, v33// 0000004A1FB8: C8C85CFF 22224320 3DB504F3
	v_sub_f32_e32 v40, v40, v41                                // 0000004A1FC4: 08505328
	.long 0xd7600003                                           // 0000004A1FC8: D7600003
	v_cndmask_b32_e32 v0, v25, v149, vcc_lo                    // 0000004A1FCC: 02012B19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A1FD0: BF870193
	v_dual_sub_f32 v32, v32, v33 :: v_dual_mul_f32 v33, s0, v34// 0000004A1FD4: C9464320 20204400
	v_dual_mul_f32 v34, 0x3db504f3, v35 :: v_dual_mul_f32 v35, 0x3db504f3, v40// 0000004A1FDC: C8C646FF 222250FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000004A1FE8: BF870143
	v_mul_f32_e32 v0, s3, v0                                   // 0000004A1FEC: 10000003
	.long 0xd7600000                                           // 0000004A1FF0: D7600000
	v_cndmask_b32_e32 v0, v25, v134, vcc_lo                    // 0000004A1FF4: 02010D19
	.long 0xd7600003                                           // 0000004A1FF8: D7600003
	v_cndmask_b32_e32 v0, v24, v150, vcc_lo                    // 0000004A1FFC: 02012D18
	v_mul_f32_e32 v32, 0x3db504f3, v32                         // 0000004A2000: 104040FF 3DB504F3
	v_dual_mul_f32 v34, s0, v34 :: v_dual_mul_f32 v35, s3, v35 // 0000004A2008: C8C64400 22224603
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004A2010: BF870002
	v_mul_f32_e32 v32, s4, v32                                 // 0000004A2014: 10404004
	s_waitcnt lgkmcnt(2)                                       // 0000004A2018: BF89FC27
	v_add_f32_e32 v40, v42, v43                                // 0000004A201C: 0650572A
	s_waitcnt lgkmcnt(0)                                       // 0000004A2020: BF89FC07
	v_dual_sub_f32 v42, v42, v43 :: v_dual_add_f32 v41, v44, v45// 0000004A2024: C948572A 2A285B2C
	v_sub_f32_e32 v43, v44, v45                                // 0000004A202C: 08565B2C
	ds_store_b32 v29, v2                                       // 0000004A2030: D8340000 0000021D
	ds_store_b32 v30, v5                                       // 0000004A2038: D8340000 0000051E
	ds_store_b32 v31, v6                                       // 0000004A2040: D8340000 0000061F
	ds_store_b32 v28, v0                                       // 0000004A2048: D8340000 0000001C
	ds_store_b32 v11, v33                                      // 0000004A2050: D8340000 0000210B
	ds_store_b32 v7, v34                                       // 0000004A2058: D8340000 00002207
	ds_store_b32 v9, v35                                       // 0000004A2060: D8340000 00002309
	ds_store_b32 v10, v32                                      // 0000004A2068: D8340000 0000200A
	v_or_b32_e32 v11, 16, v17                                  // 0000004A2070: 38162290
	v_or_b32_e32 v7, 48, v17                                   // 0000004A2074: 380E22B0
	v_dual_add_f32 v44, v40, v41 :: v_dual_add_f32 v45, v42, v43// 0000004A2078: C9085328 2C2C572A
	v_dual_sub_f32 v40, v40, v41 :: v_dual_sub_f32 v41, v42, v43// 0000004A2080: C94A5328 2828572A
	.long 0xd7600000                                           // 0000004A2088: D7600000
	v_cndmask_b32_e32 v0, v24, v135, vcc_lo                    // 0000004A208C: 02010F18
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004A2090: BF870003
	v_mul_f32_e32 v42, 0x3db504f3, v44                         // 0000004A2094: 105458FF 3DB504F3
	v_or_b32_e32 v9, 0x50, v17                                 // 0000004A209C: 381222FF 00000050
	v_or_b32_e32 v10, 0x70, v17                                // 0000004A20A4: 381422FF 00000070
	v_mul_f32_e32 v43, 0x3db504f3, v45                         // 0000004A20AC: 10565AFF 3DB504F3
	.long 0xd7600003                                           // 0000004A20B4: D7600003
	v_cndmask_b32_e32 v0, v25, v135, vcc_lo                    // 0000004A20B8: 02010F19
	v_xor_b32_e32 v28, v11, v18                                // 0000004A20BC: 3A38250B
	v_mul_f32_e32 v40, 0x3db504f3, v40                         // 0000004A20C0: 105050FF 3DB504F3
	.long 0xd7600004                                           // 0000004A20C8: D7600004
	v_cndmask_b32_e32 v0, v24, v151, vcc_lo                    // 0000004A20CC: 02012F18
	v_xor_b32_e32 v7, v7, v18                                  // 0000004A20D0: 3A0E2507
	v_mul_f32_e32 v0, s0, v42                                  // 0000004A20D4: 10005400
	v_mul_f32_e32 v6, 0x3db504f3, v41                          // 0000004A20D8: 100C52FF 3DB504F3
	.long 0xd7600000                                           // 0000004A20E0: D7600000
	v_cndmask_b32_e32 v0, v25, v151, vcc_lo                    // 0000004A20E4: 02012F19
	v_xor_b32_e32 v9, v9, v18                                  // 0000004A20E8: 3A122509
	v_xor_b32_e32 v10, v10, v18                                // 0000004A20EC: 3A14250A
	v_mul_f32_e32 v2, s3, v43                                  // 0000004A20F0: 10045603
	v_lshl_or_b32 v28, v28, 2, v23                             // 0000004A20F4: D656001C 045D051C
	v_mul_f32_e32 v5, s4, v40                                  // 0000004A20FC: 100A5004
	v_lshl_or_b32 v7, v7, 2, v23                               // 0000004A2100: D6560007 045D0507
	v_mul_f32_e32 v6, s0, v6                                   // 0000004A2108: 100C0C00
	v_lshl_or_b32 v9, v9, 2, v23                               // 0000004A210C: D6560009 045D0509
	v_lshl_or_b32 v29, v10, 2, v23                             // 0000004A2114: D656001D 045D050A
	ds_store_b32 v39, v0                                       // 0000004A211C: D8340000 00000027
	ds_store_b32 v36, v2                                       // 0000004A2124: D8340000 00000224
	ds_store_b32 v37, v5                                       // 0000004A212C: D8340000 00000525
	ds_store_b32 v38, v6                                       // 0000004A2134: D8340000 00000626
	ds_load_b32 v0, v28                                        // 0000004A213C: D8D80000 0000001C
	ds_load_b32 v2, v7                                         // 0000004A2144: D8D80000 02000007
	ds_load_b32 v5, v9                                         // 0000004A214C: D8D80000 05000009
	ds_load_b32 v6, v29                                        // 0000004A2154: D8D80000 0600001D
	.long 0xd7600000                                           // 0000004A215C: D7600000
	v_cndmask_b32_e32 v0, v24, v136, vcc_lo                    // 0000004A2160: 02011118
	.long 0xd7600003                                           // 0000004A2164: D7600003
	v_cndmask_b32_e32 v0, v25, v136, vcc_lo                    // 0000004A2168: 02011119
	.long 0xd7600004                                           // 0000004A216C: D7600004
	v_cndmask_b32_e32 v0, v24, v152, vcc_lo                    // 0000004A2170: 02013118
	v_or_b32_e32 v31, 0x52, v17                                // 0000004A2174: 383E22FF 00000052
	v_or_b32_e32 v32, 0x72, v17                                // 0000004A217C: 384022FF 00000072
	v_or_b32_e32 v41, 0x56, v17                                // 0000004A2184: 385222FF 00000056
	v_or_b32_e32 v42, 0x76, v17                                // 0000004A218C: 385422FF 00000076
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A2194: BF870214
	v_xor_b32_e32 v31, v31, v18                                // 0000004A2198: 3A3E251F
	v_xor_b32_e32 v32, v32, v18                                // 0000004A219C: 3A402520
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A21A0: BF870214
	v_xor_b32_e32 v41, v41, v18                                // 0000004A21A4: 3A522529
	v_xor_b32_e32 v42, v42, v18                                // 0000004A21A8: 3A54252A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A21AC: BF870214
	v_lshl_or_b32 v31, v31, 2, v23                             // 0000004A21B0: D656001F 045D051F
	v_lshl_or_b32 v32, v32, 2, v23                             // 0000004A21B8: D6560020 045D0520
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A21C0: BF870214
	v_lshl_or_b32 v41, v41, 2, v23                             // 0000004A21C4: D6560029 045D0529
	v_lshl_or_b32 v42, v42, 2, v23                             // 0000004A21CC: D656002A 045D052A
	s_waitcnt lgkmcnt(2)                                       // 0000004A21D4: BF89FC27
	v_add_f32_e32 v10, v0, v2                                  // 0000004A21D8: 06140500
	v_sub_f32_e32 v0, v0, v2                                   // 0000004A21DC: 08000500
	s_waitcnt lgkmcnt(0)                                       // 0000004A21E0: BF89FC07
	v_add_f32_e32 v30, v5, v6                                  // 0000004A21E4: 063C0D05
	v_sub_f32_e32 v2, v5, v6                                   // 0000004A21E8: 08040D05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004A21EC: BF870112
	v_add_f32_e32 v5, v10, v30                                 // 0000004A21F0: 060A3D0A
	v_add_f32_e32 v6, v0, v2                                   // 0000004A21F4: 060C0500
	v_sub_f32_e32 v10, v10, v30                                // 0000004A21F8: 08143D0A
	v_sub_f32_e32 v0, v0, v2                                   // 0000004A21FC: 08000500
	v_or_b32_e32 v30, 50, v17                                  // 0000004A2200: 383C22B2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A2204: BF870214
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v6, 0x3db504f3, v6// 0000004A2208: C8C60AFF 05060CFF 3DB504F3
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 0000004A2214: 101414FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A221C: BF870214
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000004A2220: 100000FF 3DB504F3
	v_xor_b32_e32 v30, v30, v18                                // 0000004A2228: 3A3C251E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A222C: BF870214
	v_dual_mul_f32 v2, s0, v5 :: v_dual_mul_f32 v5, s3, v6     // 0000004A2230: C8C60A00 02040C03
	v_mul_f32_e32 v6, s4, v10                                  // 0000004A2238: 100C1404
	v_or_b32_e32 v10, 18, v17                                  // 0000004A223C: 38142292
	.long 0xd7600000                                           // 0000004A2240: D7600000
	v_cndmask_b32_e32 v0, v25, v152, vcc_lo                    // 0000004A2244: 02013119
	v_lshl_or_b32 v30, v30, 2, v23                             // 0000004A2248: D656001E 045D051E
	.long 0xd7600003                                           // 0000004A2250: D7600003
	v_cndmask_b32_e32 v0, v25, v137, vcc_lo                    // 0000004A2254: 02011319
	.long 0xd7600004                                           // 0000004A2258: D7600004
	v_cndmask_b32_e32 v0, v25, v154, vcc_lo                    // 0000004A225C: 02013519
	v_xor_b32_e32 v33, v10, v18                                // 0000004A2260: 3A42250A
	v_mul_f32_e32 v0, s0, v0                                   // 0000004A2264: 10000000
	ds_store_b32 v28, v2                                       // 0000004A2268: D8340000 0000021C
	ds_store_b32 v7, v5                                        // 0000004A2270: D8340000 00000507
	ds_store_b32 v9, v6                                        // 0000004A2278: D8340000 00000609
	ds_store_b32 v29, v0                                       // 0000004A2280: D8340000 0000001D
	v_or_b32_e32 v7, 52, v17                                   // 0000004A2288: 380E22B4
	v_lshl_or_b32 v33, v33, 2, v23                             // 0000004A228C: D6560021 045D0521
	ds_load_b32 v0, v33                                        // 0000004A2294: D8D80000 00000021
	ds_load_b32 v2, v30                                        // 0000004A229C: D8D80000 0200001E
	ds_load_b32 v5, v31                                        // 0000004A22A4: D8D80000 0500001F
	ds_load_b32 v6, v32                                        // 0000004A22AC: D8D80000 06000020
	v_xor_b32_e32 v7, v7, v18                                  // 0000004A22B4: 3A0E2507
	v_or_b32_e32 v9, 20, v17                                   // 0000004A22B8: 38122294
	v_or_b32_e32 v28, 0x54, v17                                // 0000004A22BC: 383822FF 00000054
	v_or_b32_e32 v29, 0x74, v17                                // 0000004A22C4: 383A22FF 00000074
	.long 0xd7600000                                           // 0000004A22CC: D7600000
	v_cndmask_b32_e32 v0, v24, v137, vcc_lo                    // 0000004A22D0: 02011318
	v_lshl_or_b32 v35, v7, 2, v23                              // 0000004A22D4: D6560023 045D0507
	v_xor_b32_e32 v34, v9, v18                                 // 0000004A22DC: 3A442509
	v_xor_b32_e32 v28, v28, v18                                // 0000004A22E0: 3A38251C
	v_xor_b32_e32 v29, v29, v18                                // 0000004A22E4: 3A3A251D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A22E8: BF870193
	v_lshl_or_b32 v34, v34, 2, v23                             // 0000004A22EC: D6560022 045D0522
	v_lshl_or_b32 v28, v28, 2, v23                             // 0000004A22F4: D656001C 045D051C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004A22FC: BF870003
	v_lshl_or_b32 v29, v29, 2, v23                             // 0000004A2300: D656001D 045D051D
	ds_load_b32 v36, v34                                       // 0000004A2308: D8D80000 24000022
	ds_load_b32 v37, v35                                       // 0000004A2310: D8D80000 25000023
	ds_load_b32 v38, v28                                       // 0000004A2318: D8D80000 2600001C
	ds_load_b32 v39, v29                                       // 0000004A2320: D8D80000 2700001D
	s_waitcnt lgkmcnt(6)                                       // 0000004A2328: BF89FC67
	v_add_f32_e32 v7, v0, v2                                   // 0000004A232C: 060E0500
	v_sub_f32_e32 v0, v0, v2                                   // 0000004A2330: 08000500
	s_waitcnt lgkmcnt(4)                                       // 0000004A2334: BF89FC47
	v_add_f32_e32 v40, v5, v6                                  // 0000004A2338: 06500D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004A233C: BF870091
	v_dual_sub_f32 v2, v5, v6 :: v_dual_add_f32 v5, v7, v40    // 0000004A2340: C9480D05 02045107
	v_dual_add_f32 v6, v0, v2 :: v_dual_sub_f32 v7, v7, v40    // 0000004A2348: C90A0500 06065107
	v_sub_f32_e32 v0, v0, v2                                   // 0000004A2350: 08000500
	v_or_b32_e32 v40, 54, v17                                  // 0000004A2354: 385022B6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A2358: BF870193
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v6, 0x3db504f3, v6// 0000004A235C: C8C60AFF 05060CFF 3DB504F3
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000004A2368: 100000FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A2370: BF870193
	v_xor_b32_e32 v40, v40, v18                                // 0000004A2374: 3A502528
	v_dual_mul_f32 v2, s0, v5 :: v_dual_mul_f32 v5, s3, v6     // 0000004A2378: C8C60A00 02040C03
	v_mul_f32_e32 v6, 0x3db504f3, v7                           // 0000004A2380: 100C0EFF 3DB504F3
	v_or_b32_e32 v7, 22, v17                                   // 0000004A2388: 380E2296
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A238C: BF870004
	v_lshl_or_b32 v40, v40, 2, v23                             // 0000004A2390: D6560028 045D0528
	s_waitcnt lgkmcnt(0)                                       // 0000004A2398: BF89FC07
	v_dual_add_f32 v44, v36, v37 :: v_dual_add_f32 v45, v38, v39// 0000004A239C: C9084B24 2C2C4F26
	.long 0xd7600000                                           // 0000004A23A4: D7600000
	v_cndmask_b32_e32 v0, v24, v153, vcc_lo                    // 0000004A23A8: 02013318
	v_xor_b32_e32 v43, v7, v18                                 // 0000004A23AC: 3A562507
	v_dual_sub_f32 v36, v36, v37 :: v_dual_sub_f32 v37, v38, v39// 0000004A23B0: C94A4B24 24244F26
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A23B8: BF870214
	v_add_f32_e32 v50, v44, v45                                // 0000004A23BC: 06645B2C
	v_mul_f32_e32 v6, s0, v6                                   // 0000004A23C0: 100C0C00
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A23C4: BF870004
	v_lshl_or_b32 v43, v43, 2, v23                             // 0000004A23C8: D656002B 045D052B
	ds_load_b32 v46, v43                                       // 0000004A23D0: D8D80000 2E00002B
	ds_load_b32 v47, v40                                       // 0000004A23D8: D8D80000 2F000028
	ds_load_b32 v48, v41                                       // 0000004A23E0: D8D80000 30000029
	ds_load_b32 v49, v42                                       // 0000004A23E8: D8D80000 3100002A
	v_mul_f32_e32 v38, 0x3db504f3, v50                         // 0000004A23F0: 104C64FF 3DB504F3
	.long 0xd7600000                                           // 0000004A23F8: D7600000
	v_cndmask_b32_e32 v0, v24, v138, vcc_lo                    // 0000004A23FC: 02011518
	v_add_f32_e32 v39, v36, v37                                // 0000004A2400: 064E4B24
	v_sub_f32_e32 v44, v44, v45                                // 0000004A2404: 08585B2C
	.long 0xd7600003                                           // 0000004A2408: D7600003
	v_cndmask_b32_e32 v0, v25, v153, vcc_lo                    // 0000004A240C: 02013319
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A2410: BF870194
	v_dual_sub_f32 v36, v36, v37 :: v_dual_mul_f32 v37, s0, v38// 0000004A2414: C9464B24 24244C00
	v_dual_mul_f32 v38, 0x3db504f3, v39 :: v_dual_mul_f32 v39, 0x3db504f3, v44// 0000004A241C: C8C64EFF 262658FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000004A2428: BF870143
	v_mul_f32_e32 v0, s3, v0                                   // 0000004A242C: 10000003
	.long 0xd7600000                                           // 0000004A2430: D7600000
	v_cndmask_b32_e32 v0, v25, v138, vcc_lo                    // 0000004A2434: 02011519
	.long 0xd7600003                                           // 0000004A2438: D7600003
	v_cndmask_b32_e32 v0, v24, v154, vcc_lo                    // 0000004A243C: 02013518
	v_mul_f32_e32 v36, 0x3db504f3, v36                         // 0000004A2440: 104848FF 3DB504F3
	v_dual_mul_f32 v38, s0, v38 :: v_dual_mul_f32 v39, s3, v39 // 0000004A2448: C8C64C00 26264E03
	s_waitcnt lgkmcnt(2)                                       // 0000004A2450: BF89FC27
	v_add_f32_e32 v44, v46, v47                                // 0000004A2454: 06585F2E
	s_waitcnt lgkmcnt(0)                                       // 0000004A2458: BF89FC07
	v_dual_sub_f32 v46, v46, v47 :: v_dual_add_f32 v45, v48, v49// 0000004A245C: C9485F2E 2E2C6330
	v_dual_sub_f32 v47, v48, v49 :: v_dual_mul_f32 v36, s4, v36// 0000004A2464: C9466330 2F244804
	ds_store_b32 v33, v2                                       // 0000004A246C: D8340000 00000221
	ds_store_b32 v30, v5                                       // 0000004A2474: D8340000 0000051E
	ds_store_b32 v31, v6                                       // 0000004A247C: D8340000 0000061F
	ds_store_b32 v32, v0                                       // 0000004A2484: D8340000 00000020
	ds_store_b32 v34, v37                                      // 0000004A248C: D8340000 00002522
	ds_store_b32 v35, v38                                      // 0000004A2494: D8340000 00002623
	ds_store_b32 v28, v39                                      // 0000004A249C: D8340000 0000271C
	ds_store_b32 v29, v36                                      // 0000004A24A4: D8340000 0000241D
	v_or_b32_e32 v6, 24, v17                                   // 0000004A24AC: 380C2298
	v_dual_add_f32 v48, v44, v45 :: v_dual_add_f32 v49, v46, v47// 0000004A24B0: C9085B2C 30305F2E
	v_sub_f32_e32 v44, v44, v45                                // 0000004A24B8: 08585B2C
	v_or_b32_e32 v29, 56, v17                                  // 0000004A24BC: 383A22B8
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004A24C0: BF870003
	v_dual_sub_f32 v45, v46, v47 :: v_dual_mul_f32 v46, 0x3db504f3, v48// 0000004A24C4: C9465F2E 2D2E60FF 3DB504F3
	.long 0xd7600000                                           // 0000004A24D0: D7600000
	v_cndmask_b32_e32 v0, v24, v139, vcc_lo                    // 0000004A24D4: 02011718
	v_or_b32_e32 v30, 0x58, v17                                // 0000004A24D8: 383C22FF 00000058
	v_or_b32_e32 v31, 0x78, v17                                // 0000004A24E0: 383E22FF 00000078
	v_mul_f32_e32 v47, 0x3db504f3, v49                         // 0000004A24E8: 105E62FF 3DB504F3
	.long 0xd7600003                                           // 0000004A24F0: D7600003
	v_cndmask_b32_e32 v0, v25, v139, vcc_lo                    // 0000004A24F4: 02011719
	v_xor_b32_e32 v32, v6, v18                                 // 0000004A24F8: 3A402506
	v_mul_f32_e32 v44, 0x3db504f3, v44                         // 0000004A24FC: 105858FF 3DB504F3
	.long 0xd7600004                                           // 0000004A2504: D7600004
	v_cndmask_b32_e32 v0, v24, v155, vcc_lo                    // 0000004A2508: 02013718
	v_xor_b32_e32 v29, v29, v18                                // 0000004A250C: 3A3A251D
	v_mul_f32_e32 v0, s0, v46                                  // 0000004A2510: 10005C00
	v_mul_f32_e32 v28, 0x3db504f3, v45                         // 0000004A2514: 10385AFF 3DB504F3
	.long 0xd7600000                                           // 0000004A251C: D7600000
	v_cndmask_b32_e32 v0, v25, v155, vcc_lo                    // 0000004A2520: 02013719
	v_xor_b32_e32 v30, v30, v18                                // 0000004A2524: 3A3C251E
	v_xor_b32_e32 v31, v31, v18                                // 0000004A2528: 3A3E251F
	v_mul_f32_e32 v2, s3, v47                                  // 0000004A252C: 10045E03
	v_lshl_or_b32 v32, v32, 2, v23                             // 0000004A2530: D6560020 045D0520
	v_mul_f32_e32 v5, s4, v44                                  // 0000004A2538: 100A5804
	v_lshl_or_b32 v29, v29, 2, v23                             // 0000004A253C: D656001D 045D051D
	v_mul_f32_e32 v28, s0, v28                                 // 0000004A2544: 10383800
	v_lshl_or_b32 v30, v30, 2, v23                             // 0000004A2548: D656001E 045D051E
	v_lshl_or_b32 v31, v31, 2, v23                             // 0000004A2550: D656001F 045D051F
	ds_store_b32 v43, v0                                       // 0000004A2558: D8340000 0000002B
	ds_store_b32 v40, v2                                       // 0000004A2560: D8340000 00000228
	ds_store_b32 v41, v5                                       // 0000004A2568: D8340000 00000529
	ds_store_b32 v42, v28                                      // 0000004A2570: D8340000 00001C2A
	ds_load_b32 v0, v32                                        // 0000004A2578: D8D80000 00000020
	ds_load_b32 v2, v29                                        // 0000004A2580: D8D80000 0200001D
	ds_load_b32 v5, v30                                        // 0000004A2588: D8D80000 0500001E
	ds_load_b32 v28, v31                                       // 0000004A2590: D8D80000 1C00001F
	.long 0xd7600000                                           // 0000004A2598: D7600000
	v_cndmask_b32_e32 v0, v24, v140, vcc_lo                    // 0000004A259C: 02011918
	.long 0xd7600003                                           // 0000004A25A0: D7600003
	v_cndmask_b32_e32 v0, v24, v156, vcc_lo                    // 0000004A25A4: 02013918
	.long 0xd7600004                                           // 0000004A25A8: D7600004
	v_cndmask_b32_e32 v0, v25, v156, vcc_lo                    // 0000004A25AC: 02013919
	v_or_b32_e32 v36, 62, v17                                  // 0000004A25B0: 384822BE
	v_or_b32_e32 v37, 0x5e, v17                                // 0000004A25B4: 384A22FF 0000005E
	v_or_b32_e32 v38, 0x7e, v17                                // 0000004A25BC: 384C22FF 0000007E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A25C4: BF870193
	v_xor_b32_e32 v36, v36, v18                                // 0000004A25C8: 3A482524
	v_xor_b32_e32 v37, v37, v18                                // 0000004A25CC: 3A4A2525
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A25D0: BF870193
	v_xor_b32_e32 v38, v38, v18                                // 0000004A25D4: 3A4C2526
	v_lshl_or_b32 v36, v36, 2, v23                             // 0000004A25D8: D6560024 045D0524
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004A25E0: BF870003
	v_lshl_or_b32 v37, v37, 2, v23                             // 0000004A25E4: D6560025 045D0525
	s_waitcnt lgkmcnt(2)                                       // 0000004A25EC: BF89FC27
	v_add_f32_e32 v33, v0, v2                                  // 0000004A25F0: 06420500
	v_sub_f32_e32 v0, v0, v2                                   // 0000004A25F4: 08000500
	s_waitcnt lgkmcnt(0)                                       // 0000004A25F8: BF89FC07
	v_add_f32_e32 v34, v5, v28                                 // 0000004A25FC: 06443905
	v_sub_f32_e32 v2, v5, v28                                  // 0000004A2600: 08043905
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004A2604: BF870112
	v_add_f32_e32 v35, v33, v34                                // 0000004A2608: 06464521
	v_add_f32_e32 v28, v0, v2                                  // 0000004A260C: 06380500
	v_sub_f32_e32 v33, v33, v34                                // 0000004A2610: 08424521
	v_sub_f32_e32 v0, v0, v2                                   // 0000004A2614: 08000500
	v_or_b32_e32 v34, 58, v17                                  // 0000004A2618: 384422BA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A261C: BF870194
	v_dual_mul_f32 v5, 0x3db504f3, v35 :: v_dual_mul_f32 v28, 0x3db504f3, v28// 0000004A2620: C8C646FF 051C38FF 3DB504F3
	v_dual_mul_f32 v33, 0x3db504f3, v33 :: v_dual_mul_f32 v0, 0x3db504f3, v0// 0000004A262C: C8C642FF 210000FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A2638: BF870193
	v_xor_b32_e32 v34, v34, v18                                // 0000004A263C: 3A442522
	v_mul_f32_e32 v2, s0, v5                                   // 0000004A2640: 10040A00
	.long 0xd7600000                                           // 0000004A2644: D7600000
	v_cndmask_b32_e32 v0, v25, v140, vcc_lo                    // 0000004A2648: 02011919
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004A264C: BF870234
	v_dual_mul_f32 v33, s3, v33 :: v_dual_mul_f32 v0, s4, v0   // 0000004A2650: C8C64203 21000004
	v_or_b32_e32 v5, 26, v17                                   // 0000004A2658: 380A229A
	.long 0xd7600004                                           // 0000004A265C: D7600004
	v_cndmask_b32_e32 v0, v25, v141, vcc_lo                    // 0000004A2660: 02011B19
	v_mul_f32_e32 v28, s0, v28                                 // 0000004A2664: 10383800
	ds_store_b32 v32, v2                                       // 0000004A2668: D8340000 00000220
	ds_store_b32 v29, v28                                      // 0000004A2670: D8340000 00001C1D
	ds_store_b32 v30, v33                                      // 0000004A2678: D8340000 0000211E
	ds_store_b32 v31, v0                                       // 0000004A2680: D8340000 0000001F
	v_or_b32_e32 v0, 0x5a, v17                                 // 0000004A2688: 380022FF 0000005A
	v_xor_b32_e32 v35, v5, v18                                 // 0000004A2690: 3A462505
	v_or_b32_e32 v30, 0x7a, v17                                // 0000004A2694: 383C22FF 0000007A
	v_or_b32_e32 v2, 28, v17                                   // 0000004A269C: 3804229C
	v_lshl_or_b32 v29, v34, 2, v23                             // 0000004A26A0: D656001D 045D0522
	v_xor_b32_e32 v0, v0, v18                                  // 0000004A26A8: 3A002500
	v_lshl_or_b32 v28, v35, 2, v23                             // 0000004A26AC: D656001C 045D0523
	v_or_b32_e32 v31, 60, v17                                  // 0000004A26B4: 383E22BC
	v_or_b32_e32 v32, 0x5c, v17                                // 0000004A26B8: 384022FF 0000005C
	v_or_b32_e32 v35, 0x7c, v17                                // 0000004A26C0: 384622FF 0000007C
	v_lshl_or_b32 v34, v0, 2, v23                              // 0000004A26C8: D6560022 045D0500
	v_or_b32_e32 v0, 30, v17                                   // 0000004A26D0: 3800229E
	v_xor_b32_e32 v30, v30, v18                                // 0000004A26D4: 3A3C251E
	v_xor_b32_e32 v33, v2, v18                                 // 0000004A26D8: 3A422502
	v_xor_b32_e32 v31, v31, v18                                // 0000004A26DC: 3A3E251F
	v_xor_b32_e32 v32, v32, v18                                // 0000004A26E0: 3A402520
	v_xor_b32_e32 v35, v35, v18                                // 0000004A26E4: 3A462523
	v_xor_b32_e32 v39, v0, v18                                 // 0000004A26E8: 3A4E2500
	v_lshl_or_b32 v30, v30, 2, v23                             // 0000004A26EC: D656001E 045D051E
	v_lshl_or_b32 v33, v33, 2, v23                             // 0000004A26F4: D6560021 045D0521
	v_lshl_or_b32 v31, v31, 2, v23                             // 0000004A26FC: D656001F 045D051F
	v_lshl_or_b32 v32, v32, 2, v23                             // 0000004A2704: D6560020 045D0520
	v_lshl_or_b32 v35, v35, 2, v23                             // 0000004A270C: D6560023 045D0523
	v_lshl_or_b32 v39, v39, 2, v23                             // 0000004A2714: D6560027 045D0527
	v_lshl_or_b32 v23, v38, 2, v23                             // 0000004A271C: D6560017 045D0526
	ds_load_b32 v38, v28                                       // 0000004A2724: D8D80000 2600001C
	ds_load_b32 v40, v29                                       // 0000004A272C: D8D80000 2800001D
	ds_load_b32 v41, v34                                       // 0000004A2734: D8D80000 29000022
	ds_load_b32 v42, v30                                       // 0000004A273C: D8D80000 2A00001E
	ds_load_b32 v43, v33                                       // 0000004A2744: D8D80000 2B000021
	ds_load_b32 v44, v31                                       // 0000004A274C: D8D80000 2C00001F
	ds_load_b32 v45, v32                                       // 0000004A2754: D8D80000 2D000020
	ds_load_b32 v46, v35                                       // 0000004A275C: D8D80000 2E000023
	ds_load_b32 v47, v39                                       // 0000004A2764: D8D80000 2F000027
	ds_load_b32 v48, v36                                       // 0000004A276C: D8D80000 30000024
	ds_load_b32 v49, v37                                       // 0000004A2774: D8D80000 31000025
	ds_load_b32 v50, v23                                       // 0000004A277C: D8D80000 32000017
	.long 0xd7600000                                           // 0000004A2784: D7600000
	v_cndmask_b32_e32 v0, v24, v128, vcc_lo                    // 0000004A2788: 02010118
	.long 0xd7600003                                           // 0000004A278C: D7600003
	v_cndmask_b32_e32 v0, v24, v141, vcc_lo                    // 0000004A2790: 02011B18
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004A2794: BF870002
	v_mul_f32_e32 v26, s0, v26                                 // 0000004A2798: 10343400
	s_mov_b32 s0, 0                                            // 0000004A279C: BE800080
	s_waitcnt lgkmcnt(10)                                      // 0000004A27A0: BF89FCA7
	v_sub_f32_e32 v24, v38, v40                                // 0000004A27A4: 08305126
	ds_store_b32 v22, v26                                      // 0000004A27A8: D8340000 00001A16
	s_waitcnt lgkmcnt(9)                                       // 0000004A27B0: BF89FC97
	v_dual_add_f32 v22, v38, v40 :: v_dual_add_f32 v25, v41, v42// 0000004A27B4: C9085126 16185529
	s_waitcnt lgkmcnt(7)                                       // 0000004A27BC: BF89FC77
	v_dual_sub_f32 v26, v41, v42 :: v_dual_add_f32 v27, v43, v44// 0000004A27C0: C9485529 1A1A592B
	s_waitcnt lgkmcnt(5)                                       // 0000004A27C8: BF89FC57
	v_add_f32_e32 v40, v45, v46                                // 0000004A27CC: 06505D2D
	v_dual_sub_f32 v38, v43, v44 :: v_dual_sub_f32 v41, v45, v46// 0000004A27D0: C94A592B 26285D2D
	s_waitcnt lgkmcnt(3)                                       // 0000004A27D8: BF89FC37
	v_add_f32_e32 v42, v47, v48                                // 0000004A27DC: 0654612F
	s_waitcnt lgkmcnt(1)                                       // 0000004A27E0: BF89FC17
	v_dual_sub_f32 v43, v47, v48 :: v_dual_add_f32 v44, v49, v50// 0000004A27E4: C948612F 2B2C6531
	v_dual_sub_f32 v45, v49, v50 :: v_dual_add_f32 v46, v22, v25// 0000004A27EC: C9486531 2D2E3316
	v_dual_sub_f32 v22, v22, v25 :: v_dual_add_f32 v25, v24, v26// 0000004A27F4: C9483316 16183518
	v_sub_f32_e32 v24, v24, v26                                // 0000004A27FC: 08303518
	v_add_f32_e32 v26, v27, v40                                // 0000004A2800: 0634511B
	v_dual_sub_f32 v27, v27, v40 :: v_dual_add_f32 v40, v38, v41// 0000004A2804: C948511B 1B285326
	v_sub_f32_e32 v38, v38, v41                                // 0000004A280C: 084C5326
	v_add_f32_e32 v41, v42, v44                                // 0000004A2810: 0652592A
	v_sub_f32_e32 v42, v42, v44                                // 0000004A2814: 0854592A
	v_add_f32_e32 v44, v43, v45                                // 0000004A2818: 06585B2B
	v_sub_f32_e32 v43, v43, v45                                // 0000004A281C: 08565B2B
	v_mul_f32_e32 v45, 0x3db504f3, v46                         // 0000004A2820: 105A5CFF 3DB504F3
	v_dual_mul_f32 v25, 0x3db504f3, v25 :: v_dual_mul_f32 v22, 0x3db504f3, v22// 0000004A2828: C8C632FF 19162CFF 3DB504F3
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 0000004A2834: 103030FF 3DB504F3
	v_mul_f32_e32 v26, 0x3db504f3, v26                         // 0000004A283C: 103434FF 3DB504F3
	v_dual_mul_f32 v40, 0x3db504f3, v40 :: v_dual_mul_f32 v27, 0x3db504f3, v27// 0000004A2844: C8C650FF 281A36FF 3DB504F3
	v_dual_mul_f32 v38, 0x3db504f3, v38 :: v_dual_mul_f32 v41, 0x3db504f3, v41// 0000004A2850: C8C64CFF 262852FF 3DB504F3
	v_mul_f32_e32 v44, 0x3db504f3, v44                         // 0000004A285C: 105858FF 3DB504F3
	v_dual_mul_f32 v42, 0x3db504f3, v42 :: v_dual_mul_f32 v43, 0x3db504f3, v43// 0000004A2864: C8C654FF 2A2A56FF 3DB504F3
	v_mul_f32_e32 v45, s3, v45                                 // 0000004A2870: 105A5A03
	v_dual_mul_f32 v25, s4, v25 :: v_dual_mul_f32 v22, s5, v22 // 0000004A2874: C8C63204 19162C05
	v_mul_f32_e32 v24, s6, v24                                 // 0000004A287C: 10303006
	v_mul_f32_e32 v26, s7, v26                                 // 0000004A2880: 10343407
	v_dual_mul_f32 v40, s10, v40 :: v_dual_mul_f32 v27, s11, v27// 0000004A2884: C8C6500A 281A360B
	v_dual_mul_f32 v38, s13, v38 :: v_dual_mul_f32 v41, s14, v41// 0000004A288C: C8C64C0D 2628520E
	v_mul_f32_e32 v44, s15, v44                                // 0000004A2894: 1058580F
	v_dual_mul_f32 v42, s16, v42 :: v_dual_mul_f32 v43, s17, v43// 0000004A2898: C8C65410 2A2A5611
	ds_store_b32 v28, v45                                      // 0000004A28A0: D8340000 00002D1C
	ds_store_b32 v29, v25                                      // 0000004A28A8: D8340000 0000191D
	ds_store_b32 v34, v22                                      // 0000004A28B0: D8340000 00001622
	ds_store_b32 v30, v24                                      // 0000004A28B8: D8340000 0000181E
	ds_store_b32 v33, v26                                      // 0000004A28C0: D8340000 00001A21
	ds_store_b32 v31, v40                                      // 0000004A28C8: D8340000 0000281F
	ds_store_b32 v32, v27                                      // 0000004A28D0: D8340000 00001B20
	ds_store_b32 v35, v38                                      // 0000004A28D8: D8340000 00002623
	ds_store_b32 v39, v41                                      // 0000004A28E0: D8340000 00002927
	ds_store_b32 v36, v44                                      // 0000004A28E8: D8340000 00002C24
	ds_store_b32 v37, v42                                      // 0000004A28F0: D8340000 00002A25
	ds_store_b32 v23, v43                                      // 0000004A28F8: D8340000 00002B17
	s_waitcnt lgkmcnt(0)                                       // 0000004A2900: BF89FC07
	s_barrier                                                  // 0000004A2904: BFBD0000
	buffer_gl0_inv                                             // 0000004A2908: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 0000004A2910: BE83206A
	s_cbranch_execz 415                                        // 0000004A2914: BFA5019F <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi3ELb1ELi8EEEvPKjiPKDF16_S5_Pti+0x3594>
	v_lshlrev_b32_e32 v19, 14, v19                             // 0000004A2918: 3026268E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004A291C: BF870001
	v_and_b32_e32 v19, 0xc000, v19                             // 0000004A2920: 362626FF 0000C000
	v_and_or_b32 v22, 0x60, v8, v18                            // 0000004A2928: D6570016 044A10FF 00000060
	.long 0xd7000404                                           // 0000004A2934: D7000404
	v_cndmask_b32_e32 v0, v4, v136, vcc_lo                     // 0000004A2938: 02011104
	s_xor_b32 s4, s4, -1                                       // 0000004A293C: 8D04C104
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004A2940: BF870009
	s_and_b32 s4, exec_lo, s4                                  // 0000004A2944: 8B04047E
	v_xor_b32_e32 v24, 1, v22                                  // 0000004A2948: 3A302C81
	v_xor_b32_e32 v25, 2, v22                                  // 0000004A294C: 3A322C82
	v_xor_b32_e32 v26, 3, v22                                  // 0000004A2950: 3A342C83
	v_xor_b32_e32 v27, 4, v22                                  // 0000004A2954: 3A362C84
	v_lshl_add_u32 v23, v22, 2, v19                            // 0000004A2958: D6460017 044D0516
	v_xor_b32_e32 v28, 5, v22                                  // 0000004A2960: 3A382C85
	v_xor_b32_e32 v29, 6, v22                                  // 0000004A2964: 3A3A2C86
	v_xor_b32_e32 v30, 7, v22                                  // 0000004A2968: 3A3C2C87
	v_xor_b32_e32 v31, 8, v22                                  // 0000004A296C: 3A3E2C88
	v_xor_b32_e32 v32, 9, v22                                  // 0000004A2970: 3A402C89
	v_xor_b32_e32 v33, 10, v22                                 // 0000004A2974: 3A422C8A
	v_xor_b32_e32 v34, 11, v22                                 // 0000004A2978: 3A442C8B
	v_xor_b32_e32 v35, 12, v22                                 // 0000004A297C: 3A462C8C
	v_xor_b32_e32 v36, 13, v22                                 // 0000004A2980: 3A482C8D
	v_xor_b32_e32 v37, 14, v22                                 // 0000004A2984: 3A4A2C8E
	v_xor_b32_e32 v38, 15, v22                                 // 0000004A2988: 3A4C2C8F
	v_xor_b32_e32 v39, 16, v22                                 // 0000004A298C: 3A4E2C90
	v_xor_b32_e32 v40, 17, v22                                 // 0000004A2990: 3A502C91
	v_xor_b32_e32 v41, 18, v22                                 // 0000004A2994: 3A522C92
	v_xor_b32_e32 v42, 19, v22                                 // 0000004A2998: 3A542C93
	v_xor_b32_e32 v43, 20, v22                                 // 0000004A299C: 3A562C94
	v_xor_b32_e32 v44, 21, v22                                 // 0000004A29A0: 3A582C95
	v_xor_b32_e32 v45, 22, v22                                 // 0000004A29A4: 3A5A2C96
	v_xor_b32_e32 v46, 23, v22                                 // 0000004A29A8: 3A5C2C97
	v_xor_b32_e32 v47, 24, v22                                 // 0000004A29AC: 3A5E2C98
	v_xor_b32_e32 v48, 25, v22                                 // 0000004A29B0: 3A602C99
	v_xor_b32_e32 v49, 26, v22                                 // 0000004A29B4: 3A622C9A
	v_xor_b32_e32 v50, 27, v22                                 // 0000004A29B8: 3A642C9B
	v_xor_b32_e32 v51, 28, v22                                 // 0000004A29BC: 3A662C9C
	v_xor_b32_e32 v52, 29, v22                                 // 0000004A29C0: 3A682C9D
	v_xor_b32_e32 v53, 30, v22                                 // 0000004A29C4: 3A6A2C9E
	v_xor_b32_e32 v22, 31, v22                                 // 0000004A29C8: 3A2C2C9F
	v_lshl_add_u32 v24, v24, 2, v19                            // 0000004A29CC: D6460018 044D0518
	v_lshl_add_u32 v25, v25, 2, v19                            // 0000004A29D4: D6460019 044D0519
	v_lshl_add_u32 v26, v26, 2, v19                            // 0000004A29DC: D646001A 044D051A
	v_lshl_add_u32 v27, v27, 2, v19                            // 0000004A29E4: D646001B 044D051B
	v_lshl_add_u32 v28, v28, 2, v19                            // 0000004A29EC: D646001C 044D051C
	v_lshl_add_u32 v29, v29, 2, v19                            // 0000004A29F4: D646001D 044D051D
	v_lshl_add_u32 v30, v30, 2, v19                            // 0000004A29FC: D646001E 044D051E
	v_lshl_add_u32 v31, v31, 2, v19                            // 0000004A2A04: D646001F 044D051F
	v_lshl_add_u32 v32, v32, 2, v19                            // 0000004A2A0C: D6460020 044D0520
	v_lshl_add_u32 v33, v33, 2, v19                            // 0000004A2A14: D6460021 044D0521
	v_lshl_add_u32 v34, v34, 2, v19                            // 0000004A2A1C: D6460022 044D0522
	v_lshl_add_u32 v35, v35, 2, v19                            // 0000004A2A24: D6460023 044D0523
	v_lshl_add_u32 v36, v36, 2, v19                            // 0000004A2A2C: D6460024 044D0524
	v_lshl_add_u32 v37, v37, 2, v19                            // 0000004A2A34: D6460025 044D0525
	v_lshl_add_u32 v38, v38, 2, v19                            // 0000004A2A3C: D6460026 044D0526
	v_lshl_add_u32 v39, v39, 2, v19                            // 0000004A2A44: D6460027 044D0527
	v_lshl_add_u32 v40, v40, 2, v19                            // 0000004A2A4C: D6460028 044D0528
	v_lshl_add_u32 v41, v41, 2, v19                            // 0000004A2A54: D6460029 044D0529
	v_lshl_add_u32 v42, v42, 2, v19                            // 0000004A2A5C: D646002A 044D052A
	v_lshl_add_u32 v43, v43, 2, v19                            // 0000004A2A64: D646002B 044D052B
	v_lshl_add_u32 v44, v44, 2, v19                            // 0000004A2A6C: D646002C 044D052C
	v_lshl_add_u32 v45, v45, 2, v19                            // 0000004A2A74: D646002D 044D052D
	v_lshl_add_u32 v46, v46, 2, v19                            // 0000004A2A7C: D646002E 044D052E
	v_lshl_add_u32 v47, v47, 2, v19                            // 0000004A2A84: D646002F 044D052F
	v_lshl_add_u32 v48, v48, 2, v19                            // 0000004A2A8C: D6460030 044D0530
	v_lshl_add_u32 v49, v49, 2, v19                            // 0000004A2A94: D6460031 044D0531
	v_lshl_add_u32 v50, v50, 2, v19                            // 0000004A2A9C: D6460032 044D0532
	v_lshl_add_u32 v51, v51, 2, v19                            // 0000004A2AA4: D6460033 044D0533
	v_lshl_add_u32 v52, v52, 2, v19                            // 0000004A2AAC: D6460034 044D0534
	v_lshl_add_u32 v53, v53, 2, v19                            // 0000004A2AB4: D6460035 044D0535
	v_lshl_add_u32 v22, v22, 2, v19                            // 0000004A2ABC: D6460016 044D0516
	ds_load_b32 v54, v23                                       // 0000004A2AC4: D8D80000 36000017
	ds_load_b32 v55, v24 offset:512                            // 0000004A2ACC: D8D80200 37000018
	ds_load_b32 v56, v25 offset:1024                           // 0000004A2AD4: D8D80400 38000019
	ds_load_b32 v57, v26 offset:1536                           // 0000004A2ADC: D8D80600 3900001A
	ds_load_b32 v58, v27 offset:2048                           // 0000004A2AE4: D8D80800 3A00001B
	ds_load_b32 v59, v28 offset:2560                           // 0000004A2AEC: D8D80A00 3B00001C
	ds_load_b32 v60, v29 offset:3072                           // 0000004A2AF4: D8D80C00 3C00001D
	ds_load_b32 v61, v30 offset:3584                           // 0000004A2AFC: D8D80E00 3D00001E
	ds_load_b32 v62, v31 offset:4096                           // 0000004A2B04: D8D81000 3E00001F
	ds_load_b32 v63, v32 offset:4608                           // 0000004A2B0C: D8D81200 3F000020
	ds_load_b32 v64, v33 offset:5120                           // 0000004A2B14: D8D81400 40000021
	ds_load_b32 v65, v34 offset:5632                           // 0000004A2B1C: D8D81600 41000022
	ds_load_b32 v66, v35 offset:6144                           // 0000004A2B24: D8D81800 42000023
	ds_load_b32 v67, v36 offset:6656                           // 0000004A2B2C: D8D81A00 43000024
	ds_load_b32 v68, v37 offset:7168                           // 0000004A2B34: D8D81C00 44000025
	ds_load_b32 v69, v38 offset:7680                           // 0000004A2B3C: D8D81E00 45000026
	ds_load_b32 v70, v39 offset:8192                           // 0000004A2B44: D8D82000 46000027
	ds_load_b32 v71, v40 offset:8704                           // 0000004A2B4C: D8D82200 47000028
	ds_load_b32 v72, v41 offset:9216                           // 0000004A2B54: D8D82400 48000029
	ds_load_b32 v73, v42 offset:9728                           // 0000004A2B5C: D8D82600 4900002A
	ds_load_b32 v74, v43 offset:10240                          // 0000004A2B64: D8D82800 4A00002B
	ds_load_b32 v75, v44 offset:10752                          // 0000004A2B6C: D8D82A00 4B00002C
	ds_load_b32 v76, v45 offset:11264                          // 0000004A2B74: D8D82C00 4C00002D
	ds_load_b32 v77, v46 offset:11776                          // 0000004A2B7C: D8D82E00 4D00002E
	ds_load_b32 v78, v47 offset:12288                          // 0000004A2B84: D8D83000 4E00002F
	ds_load_b32 v79, v48 offset:12800                          // 0000004A2B8C: D8D83200 4F000030
	ds_load_b32 v80, v49 offset:13312                          // 0000004A2B94: D8D83400 50000031
	ds_load_b32 v81, v50 offset:13824                          // 0000004A2B9C: D8D83600 51000032
	ds_load_b32 v82, v51 offset:14336                          // 0000004A2BA4: D8D83800 52000033
	ds_load_b32 v83, v52 offset:14848                          // 0000004A2BAC: D8D83A00 53000034
	ds_load_b32 v84, v53 offset:15360                          // 0000004A2BB4: D8D83C00 54000035
	ds_load_b32 v85, v22 offset:15872                          // 0000004A2BBC: D8D83E00 55000016
	v_add_nc_u32_e32 v8, 64, v8                                // 0000004A2BC4: 4A1010C0
	s_waitcnt lgkmcnt(30)                                      // 0000004A2BC8: BF89FDE7
	v_add_f32_e32 v86, v54, v55                                // 0000004A2BCC: 06AC6F36
	s_waitcnt lgkmcnt(28)                                      // 0000004A2BD0: BF89FDC7
	v_dual_sub_f32 v54, v54, v55 :: v_dual_add_f32 v55, v56, v57// 0000004A2BD4: C9486F36 36367338
	s_waitcnt lgkmcnt(26)                                      // 0000004A2BDC: BF89FDA7
	v_dual_sub_f32 v56, v56, v57 :: v_dual_add_f32 v57, v58, v59// 0000004A2BE0: C9487338 3838773A
	s_waitcnt lgkmcnt(24)                                      // 0000004A2BE8: BF89FD87
	v_dual_sub_f32 v58, v58, v59 :: v_dual_add_f32 v59, v60, v61// 0000004A2BEC: C948773A 3A3A7B3C
	s_waitcnt lgkmcnt(22)                                      // 0000004A2BF4: BF89FD67
	v_dual_sub_f32 v60, v60, v61 :: v_dual_add_f32 v61, v62, v63// 0000004A2BF8: C9487B3C 3C3C7F3E
	s_waitcnt lgkmcnt(20)                                      // 0000004A2C00: BF89FD47
	v_dual_sub_f32 v62, v62, v63 :: v_dual_add_f32 v63, v64, v65// 0000004A2C04: C9487F3E 3E3E8340
	s_waitcnt lgkmcnt(18)                                      // 0000004A2C0C: BF89FD27
	v_dual_sub_f32 v64, v64, v65 :: v_dual_add_f32 v65, v66, v67// 0000004A2C10: C9488340 40408742
	s_waitcnt lgkmcnt(16)                                      // 0000004A2C18: BF89FD07
	v_dual_sub_f32 v66, v66, v67 :: v_dual_add_f32 v67, v68, v69// 0000004A2C1C: C9488742 42428B44
	s_waitcnt lgkmcnt(14)                                      // 0000004A2C24: BF89FCE7
	v_dual_sub_f32 v68, v68, v69 :: v_dual_add_f32 v69, v70, v71// 0000004A2C28: C9488B44 44448F46
	s_waitcnt lgkmcnt(12)                                      // 0000004A2C30: BF89FCC7
	v_dual_sub_f32 v70, v70, v71 :: v_dual_add_f32 v71, v72, v73// 0000004A2C34: C9488F46 46469348
	s_waitcnt lgkmcnt(10)                                      // 0000004A2C3C: BF89FCA7
	v_dual_sub_f32 v72, v72, v73 :: v_dual_add_f32 v73, v74, v75// 0000004A2C40: C9489348 4848974A
	s_waitcnt lgkmcnt(8)                                       // 0000004A2C48: BF89FC87
	v_dual_sub_f32 v74, v74, v75 :: v_dual_add_f32 v75, v76, v77// 0000004A2C4C: C948974A 4A4A9B4C
	s_waitcnt lgkmcnt(6)                                       // 0000004A2C54: BF89FC67
	v_dual_sub_f32 v76, v76, v77 :: v_dual_add_f32 v77, v78, v79// 0000004A2C58: C9489B4C 4C4C9F4E
	s_waitcnt lgkmcnt(4)                                       // 0000004A2C60: BF89FC47
	v_dual_sub_f32 v78, v78, v79 :: v_dual_add_f32 v79, v80, v81// 0000004A2C64: C9489F4E 4E4EA350
	s_waitcnt lgkmcnt(2)                                       // 0000004A2C6C: BF89FC27
	v_dual_sub_f32 v80, v80, v81 :: v_dual_add_f32 v81, v82, v83// 0000004A2C70: C948A350 5050A752
	s_waitcnt lgkmcnt(0)                                       // 0000004A2C78: BF89FC07
	v_dual_sub_f32 v82, v82, v83 :: v_dual_add_f32 v83, v84, v85// 0000004A2C7C: C948A752 5252AB54
	v_dual_sub_f32 v84, v84, v85 :: v_dual_add_f32 v85, v86, v55// 0000004A2C84: C948AB54 54546F56
	v_sub_f32_e32 v55, v86, v55                                // 0000004A2C8C: 086E6F56
	v_add_f32_e32 v86, v54, v56                                // 0000004A2C90: 06AC7136
	v_sub_f32_e32 v54, v54, v56                                // 0000004A2C94: 086C7136
	v_add_f32_e32 v56, v57, v59                                // 0000004A2C98: 06707739
	v_sub_f32_e32 v57, v57, v59                                // 0000004A2C9C: 08727739
	v_add_f32_e32 v59, v58, v60                                // 0000004A2CA0: 0676793A
	v_sub_f32_e32 v58, v58, v60                                // 0000004A2CA4: 0874793A
	v_add_f32_e32 v60, v61, v63                                // 0000004A2CA8: 06787F3D
	v_sub_f32_e32 v61, v61, v63                                // 0000004A2CAC: 087A7F3D
	v_add_f32_e32 v63, v62, v64                                // 0000004A2CB0: 067E813E
	v_sub_f32_e32 v62, v62, v64                                // 0000004A2CB4: 087C813E
	v_add_f32_e32 v64, v65, v67                                // 0000004A2CB8: 06808741
	v_sub_f32_e32 v65, v65, v67                                // 0000004A2CBC: 08828741
	v_add_f32_e32 v67, v66, v68                                // 0000004A2CC0: 06868942
	v_sub_f32_e32 v66, v66, v68                                // 0000004A2CC4: 08848942
	v_add_f32_e32 v68, v69, v71                                // 0000004A2CC8: 06888F45
	v_sub_f32_e32 v69, v69, v71                                // 0000004A2CCC: 088A8F45
	v_add_f32_e32 v71, v70, v72                                // 0000004A2CD0: 068E9146
	v_sub_f32_e32 v70, v70, v72                                // 0000004A2CD4: 088C9146
	v_add_f32_e32 v72, v73, v75                                // 0000004A2CD8: 06909749
	v_sub_f32_e32 v73, v73, v75                                // 0000004A2CDC: 08929749
	v_add_f32_e32 v75, v74, v76                                // 0000004A2CE0: 0696994A
	v_sub_f32_e32 v74, v74, v76                                // 0000004A2CE4: 0894994A
	v_add_f32_e32 v76, v77, v79                                // 0000004A2CE8: 06989F4D
	v_sub_f32_e32 v77, v77, v79                                // 0000004A2CEC: 089A9F4D
	v_add_f32_e32 v79, v78, v80                                // 0000004A2CF0: 069EA14E
	v_sub_f32_e32 v78, v78, v80                                // 0000004A2CF4: 089CA14E
	v_add_f32_e32 v80, v81, v83                                // 0000004A2CF8: 06A0A751
	v_sub_f32_e32 v81, v81, v83                                // 0000004A2CFC: 08A2A751
	v_add_f32_e32 v83, v82, v84                                // 0000004A2D00: 06A6A952
	v_sub_f32_e32 v82, v82, v84                                // 0000004A2D04: 08A4A952
	v_add_f32_e32 v84, v85, v56                                // 0000004A2D08: 06A87155
	v_dual_sub_f32 v56, v85, v56 :: v_dual_add_f32 v85, v86, v59// 0000004A2D0C: C9487155 38547756
	v_dual_sub_f32 v59, v86, v59 :: v_dual_add_f32 v86, v55, v57// 0000004A2D14: C9487756 3B567337
	v_sub_f32_e32 v55, v55, v57                                // 0000004A2D1C: 086E7337
	v_add_f32_e32 v57, v54, v58                                // 0000004A2D20: 06727536
	v_sub_f32_e32 v54, v54, v58                                // 0000004A2D24: 086C7536
	v_add_f32_e32 v58, v60, v64                                // 0000004A2D28: 0674813C
	v_sub_f32_e32 v60, v60, v64                                // 0000004A2D2C: 0878813C
	v_add_f32_e32 v64, v63, v67                                // 0000004A2D30: 0680873F
	v_sub_f32_e32 v63, v63, v67                                // 0000004A2D34: 087E873F
	v_add_f32_e32 v67, v61, v65                                // 0000004A2D38: 0686833D
	v_sub_f32_e32 v61, v61, v65                                // 0000004A2D3C: 087A833D
	v_add_f32_e32 v65, v62, v66                                // 0000004A2D40: 0682853E
	v_sub_f32_e32 v62, v62, v66                                // 0000004A2D44: 087C853E
	v_add_f32_e32 v66, v68, v72                                // 0000004A2D48: 06849144
	v_sub_f32_e32 v68, v68, v72                                // 0000004A2D4C: 08889144
	v_add_f32_e32 v72, v71, v75                                // 0000004A2D50: 06909747
	v_sub_f32_e32 v71, v71, v75                                // 0000004A2D54: 088E9747
	v_add_f32_e32 v75, v69, v73                                // 0000004A2D58: 06969345
	v_sub_f32_e32 v69, v69, v73                                // 0000004A2D5C: 088A9345
	v_add_f32_e32 v73, v70, v74                                // 0000004A2D60: 06929546
	v_sub_f32_e32 v70, v70, v74                                // 0000004A2D64: 088C9546
	v_add_f32_e32 v74, v76, v80                                // 0000004A2D68: 0694A14C
	v_sub_f32_e32 v76, v76, v80                                // 0000004A2D6C: 0898A14C
	v_add_f32_e32 v80, v79, v83                                // 0000004A2D70: 06A0A74F
	v_sub_f32_e32 v79, v79, v83                                // 0000004A2D74: 089EA74F
	v_add_f32_e32 v83, v77, v81                                // 0000004A2D78: 06A6A34D
	v_sub_f32_e32 v77, v77, v81                                // 0000004A2D7C: 089AA34D
	v_add_f32_e32 v81, v78, v82                                // 0000004A2D80: 06A2A54E
	v_sub_f32_e32 v78, v78, v82                                // 0000004A2D84: 089CA54E
	v_add_f32_e32 v82, v84, v58                                // 0000004A2D88: 06A47554
	v_sub_f32_e32 v58, v84, v58                                // 0000004A2D8C: 08747554
	v_add_f32_e32 v84, v85, v64                                // 0000004A2D90: 06A88155
	v_dual_sub_f32 v64, v85, v64 :: v_dual_add_f32 v85, v86, v67// 0000004A2D94: C9488155 40548756
	v_dual_sub_f32 v67, v86, v67 :: v_dual_add_f32 v86, v57, v65// 0000004A2D9C: C9488756 43568339
	v_sub_f32_e32 v57, v57, v65                                // 0000004A2DA4: 08728339
	v_add_f32_e32 v65, v56, v60                                // 0000004A2DA8: 06827938
	v_sub_f32_e32 v56, v56, v60                                // 0000004A2DAC: 08707938
	v_add_f32_e32 v60, v59, v63                                // 0000004A2DB0: 06787F3B
	v_sub_f32_e32 v59, v59, v63                                // 0000004A2DB4: 08767F3B
	v_add_f32_e32 v63, v55, v61                                // 0000004A2DB8: 067E7B37
	v_sub_f32_e32 v55, v55, v61                                // 0000004A2DBC: 086E7B37
	v_add_f32_e32 v61, v54, v62                                // 0000004A2DC0: 067A7D36
	v_sub_f32_e32 v54, v54, v62                                // 0000004A2DC4: 086C7D36
	v_add_f32_e32 v62, v66, v74                                // 0000004A2DC8: 067C9542
	v_sub_f32_e32 v66, v66, v74                                // 0000004A2DCC: 08849542
	v_add_f32_e32 v74, v72, v80                                // 0000004A2DD0: 0694A148
	v_sub_f32_e32 v72, v72, v80                                // 0000004A2DD4: 0890A148
	v_add_f32_e32 v80, v75, v83                                // 0000004A2DD8: 06A0A74B
	v_sub_f32_e32 v75, v75, v83                                // 0000004A2DDC: 0896A74B
	v_add_f32_e32 v83, v73, v81                                // 0000004A2DE0: 06A6A349
	v_sub_f32_e32 v73, v73, v81                                // 0000004A2DE4: 0892A349
	v_add_f32_e32 v81, v68, v76                                // 0000004A2DE8: 06A29944
	v_sub_f32_e32 v68, v68, v76                                // 0000004A2DEC: 08889944
	v_add_f32_e32 v76, v71, v79                                // 0000004A2DF0: 06989F47
	v_sub_f32_e32 v71, v71, v79                                // 0000004A2DF4: 088E9F47
	v_add_f32_e32 v79, v69, v77                                // 0000004A2DF8: 069E9B45
	v_sub_f32_e32 v69, v69, v77                                // 0000004A2DFC: 088A9B45
	v_add_f32_e32 v77, v70, v78                                // 0000004A2E00: 069A9D46
	v_sub_f32_e32 v70, v70, v78                                // 0000004A2E04: 088C9D46
	v_add_f32_e32 v78, v82, v62                                // 0000004A2E08: 069C7D52
	v_sub_f32_e32 v62, v82, v62                                // 0000004A2E0C: 087C7D52
	v_add_f32_e32 v82, v84, v74                                // 0000004A2E10: 06A49554
	v_sub_f32_e32 v74, v84, v74                                // 0000004A2E14: 08949554
	v_add_f32_e32 v84, v85, v80                                // 0000004A2E18: 06A8A155
	s_or_b32 s0, s4, s0                                        // 0000004A2E1C: 8C000004
	v_dual_sub_f32 v80, v85, v80 :: v_dual_add_f32 v85, v86, v83// 0000004A2E20: C948A155 5054A756
	v_dual_sub_f32 v83, v86, v83 :: v_dual_add_f32 v86, v65, v81// 0000004A2E28: C948A756 5356A341
	v_sub_f32_e32 v65, v65, v81                                // 0000004A2E30: 0882A341
	v_add_f32_e32 v81, v60, v76                                // 0000004A2E34: 06A2993C
	v_sub_f32_e32 v60, v60, v76                                // 0000004A2E38: 0878993C
	v_add_f32_e32 v76, v63, v79                                // 0000004A2E3C: 06989F3F
	v_sub_f32_e32 v63, v63, v79                                // 0000004A2E40: 087E9F3F
	v_add_f32_e32 v79, v61, v77                                // 0000004A2E44: 069E9B3D
	v_sub_f32_e32 v61, v61, v77                                // 0000004A2E48: 087A9B3D
	v_add_f32_e32 v77, v58, v66                                // 0000004A2E4C: 069A853A
	v_sub_f32_e32 v58, v58, v66                                // 0000004A2E50: 0874853A
	v_add_f32_e32 v66, v64, v72                                // 0000004A2E54: 06849140
	v_sub_f32_e32 v64, v64, v72                                // 0000004A2E58: 08809140
	v_add_f32_e32 v72, v67, v75                                // 0000004A2E5C: 06909743
	v_sub_f32_e32 v67, v67, v75                                // 0000004A2E60: 08869743
	v_add_f32_e32 v75, v57, v73                                // 0000004A2E64: 06969339
	v_sub_f32_e32 v57, v57, v73                                // 0000004A2E68: 08729339
	v_add_f32_e32 v73, v56, v68                                // 0000004A2E6C: 06928938
	v_sub_f32_e32 v56, v56, v68                                // 0000004A2E70: 08708938
	v_add_f32_e32 v68, v59, v71                                // 0000004A2E74: 06888F3B
	v_sub_f32_e32 v59, v59, v71                                // 0000004A2E78: 08768F3B
	v_add_f32_e32 v71, v55, v69                                // 0000004A2E7C: 068E8B37
	v_sub_f32_e32 v55, v55, v69                                // 0000004A2E80: 086E8B37
	v_add_f32_e32 v69, v54, v70                                // 0000004A2E84: 068A8D36
	v_sub_f32_e32 v54, v54, v70                                // 0000004A2E88: 086C8D36
	ds_store_b32 v23, v78                                      // 0000004A2E8C: D8340000 00004E17
	ds_store_b32 v24, v82 offset:512                           // 0000004A2E94: D8340200 00005218
	ds_store_b32 v25, v84 offset:1024                          // 0000004A2E9C: D8340400 00005419
	ds_store_b32 v26, v85 offset:1536                          // 0000004A2EA4: D8340600 0000551A
	ds_store_b32 v27, v86 offset:2048                          // 0000004A2EAC: D8340800 0000561B
	ds_store_b32 v28, v81 offset:2560                          // 0000004A2EB4: D8340A00 0000511C
	ds_store_b32 v29, v76 offset:3072                          // 0000004A2EBC: D8340C00 00004C1D
	ds_store_b32 v30, v79 offset:3584                          // 0000004A2EC4: D8340E00 00004F1E
	ds_store_b32 v31, v77 offset:4096                          // 0000004A2ECC: D8341000 00004D1F
	ds_store_b32 v32, v66 offset:4608                          // 0000004A2ED4: D8341200 00004220
	ds_store_b32 v33, v72 offset:5120                          // 0000004A2EDC: D8341400 00004821
	ds_store_b32 v34, v75 offset:5632                          // 0000004A2EE4: D8341600 00004B22
	ds_store_b32 v35, v73 offset:6144                          // 0000004A2EEC: D8341800 00004923
	ds_store_b32 v36, v68 offset:6656                          // 0000004A2EF4: D8341A00 00004424
	ds_store_b32 v37, v71 offset:7168                          // 0000004A2EFC: D8341C00 00004725
	ds_store_b32 v38, v69 offset:7680                          // 0000004A2F04: D8341E00 00004526
	ds_store_b32 v39, v62 offset:8192                          // 0000004A2F0C: D8342000 00003E27
	ds_store_b32 v40, v74 offset:8704                          // 0000004A2F14: D8342200 00004A28
	ds_store_b32 v41, v80 offset:9216                          // 0000004A2F1C: D8342400 00005029
	ds_store_b32 v42, v83 offset:9728                          // 0000004A2F24: D8342600 0000532A
	ds_store_b32 v43, v65 offset:10240                         // 0000004A2F2C: D8342800 0000412B
	ds_store_b32 v44, v60 offset:10752                         // 0000004A2F34: D8342A00 00003C2C
	ds_store_b32 v45, v63 offset:11264                         // 0000004A2F3C: D8342C00 00003F2D
	ds_store_b32 v46, v61 offset:11776                         // 0000004A2F44: D8342E00 00003D2E
	ds_store_b32 v47, v58 offset:12288                         // 0000004A2F4C: D8343000 00003A2F
	ds_store_b32 v48, v64 offset:12800                         // 0000004A2F54: D8343200 00004030
	ds_store_b32 v49, v67 offset:13312                         // 0000004A2F5C: D8343400 00004331
	ds_store_b32 v50, v57 offset:13824                         // 0000004A2F64: D8343600 00003932
	ds_store_b32 v51, v56 offset:14336                         // 0000004A2F6C: D8343800 00003833
	ds_store_b32 v52, v59 offset:14848                         // 0000004A2F74: D8343A00 00003B34
	ds_store_b32 v53, v55 offset:15360                         // 0000004A2F7C: D8343C00 00003735
	ds_store_b32 v22, v54 offset:15872                         // 0000004A2F84: D8343E00 00003616
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 0000004A2F8C: 917E007E
	s_cbranch_execnz 65125                                     // 0000004A2F90: BFA6FE65 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi3ELb1ELi8EEEvPKjiPKDF16_S5_Pti+0x2f28>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000004A2F94: 8C7E037E
	v_xor_b32_e32 v8, v17, v3                                  // 0000004A2F98: 3A100711
	v_lshlrev_b32_e32 v18, 9, v17                              // 0000004A2F9C: 30242289
	s_waitcnt lgkmcnt(0)                                       // 0000004A2FA0: BF89FC07
	s_barrier                                                  // 0000004A2FA4: BFBD0000
	buffer_gl0_inv                                             // 0000004A2FA8: E0AC0000 00000000
	s_ashr_i32 s3, s2, 31                                      // 0000004A2FB0: 86039F02
	v_lshl_add_u32 v8, v8, 2, v18                              // 0000004A2FB4: D6460008 04490508
	s_lshl_b64 s[2:3], s[2:3], 1                               // 0000004A2FBC: 84828102
	v_or_b32_e32 v32, s1, v17                                  // 0000004A2FC0: 38402201
	s_add_u32 s0, s8, s2                                       // 0000004A2FC4: 80000208
	ds_load_2addr_stride64_b32 v[22:23], v8 offset1:64         // 0000004A2FC8: D8E04000 16000008
	ds_load_2addr_stride64_b32 v[24:25], v8 offset0:128 offset1:192// 0000004A2FD0: D8E0C080 18000008
	v_mov_b32_e32 v4, 0                                        // 0000004A2FD8: 7E080280
	s_addc_u32 s2, s9, s3                                      // 0000004A2FDC: 82020309
	v_mad_i64_i32 v[26:27], null, v32, s12, 0                  // 0000004A2FE0: D6FF7C1A 02001920
	v_or_b32_e32 v30, 64, v32                                  // 0000004A2FE8: 383C40C0
	v_cvt_f32_f16_e32 v17, v129/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A2FEC: 7E221781
	.long 0xd73c0012                                           // 0000004A2FF0: D73C0012
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000004A2FF4: 02020681
	v_or_b32_e32 v40, s1, v21                                  // 0000004A2FF8: 38502A01
	v_lshlrev_b32_e32 v36, 9, v21                              // 0000004A2FFC: 30482A89
	v_mad_i64_i32 v[30:31], null, v30, s12, 0                  // 0000004A3000: D6FF7C1E 0200191E
	.long 0xd7600003                                           // 0000004A3008: D7600003
	v_cndmask_b32_e32 v0, v17, v144, vcc_lo                    // 0000004A300C: 02012111
	.long 0xd73c001a                                           // 0000004A3010: D73C001A
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000004A3014: 02023481
	.long 0xd7006a04                                           // 0000004A3018: D7006A04
	v_cndmask_b32_e32 v1, s0, v18, vcc_lo                      // 0000004A301C: 02022400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004A3020: BF870231
	v_add_co_ci_u32_e64 v8, null, s2, v19, vcc_lo              // 0000004A3024: D5207C08 01AA2602
	v_or_b32_e32 v19, 32, v32                                  // 0000004A302C: 382640A0
	v_cvt_f32_f16_e32 v18, v1                                  // 0000004A3030: 7E241701
	.long 0xd7006a1a                                           // 0000004A3034: D7006A1A
	v_cndmask_b32_e32 v1, v4, v26, vcc_lo                      // 0000004A3038: 02023504
	s_waitcnt lgkmcnt(1)                                       // 0000004A303C: BF89FC17
	v_sub_f32_e32 v1, v22, v23                                 // 0000004A3040: 08022F16
	v_mad_i64_i32 v[28:29], null, v19, s12, 0                  // 0000004A3044: D6FF7C1C 02001913
	s_waitcnt lgkmcnt(0)                                       // 0000004A304C: BF89FC07
	v_sub_f32_e32 v19, v24, v25                                // 0000004A3050: 08263318
	v_dual_add_f32 v33, v22, v23 :: v_dual_add_f32 v34, v24, v25// 0000004A3054: C9082F16 21223318
	v_add_co_ci_u32_e64 v27, null, v8, v27, vcc_lo             // 0000004A305C: D5207C1B 01AA3708
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004A3064: BF870003
	v_add_f32_e32 v24, v1, v19                                 // 0000004A3068: 06302701
	.long 0xd73c001e                                           // 0000004A306C: D73C001E
	v_cndmask_b32_e32 v1, 1, v30, vcc_lo                       // 0000004A3070: 02023C81
	.long 0xd73c001c                                           // 0000004A3074: D73C001C
	v_cndmask_b32_e32 v1, 1, v28, vcc_lo                       // 0000004A3078: 02023881
	.long 0xd7600002                                           // 0000004A307C: D7600002
	v_cndmask_b32_e32 v0, v18, v128, vcc_lo                    // 0000004A3080: 02010112
	.long 0xd7600000                                           // 0000004A3084: D7600000
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                    // 0000004A3088: 02010111
	v_sub_f32_e32 v19, v1, v19                                 // 0000004A308C: 08262701
	.long 0xd7600004                                           // 0000004A3090: D7600004
	v_cndmask_b32_e32 v0, v18, v144, vcc_lo                    // 0000004A3094: 02012112
	.long 0x7f023880                                           // 0000004A3098: 7F023880
	.long 0xd7006a16                                           // 0000004A309C: D7006A16
	v_cndmask_b32_e32 v1, v4, v28, vcc_lo                      // 0000004A30A0: 02023904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000004A30A4: BF870131
	v_add_co_ci_u32_e64 v23, null, v8, v29, vcc_lo             // 0000004A30A8: D5207C17 01AA3B08
	v_dual_add_f32 v28, v33, v34 :: v_dual_mul_f32 v29, 0x3db504f3, v24// 0000004A30B0: C9064521 1C1C30FF 3DB504F3
	.long 0xd7006a18                                           // 0000004A30BC: D7006A18
	v_cndmask_b32_e32 v1, v4, v30, vcc_lo                      // 0000004A30C0: 02023D04
	v_dual_mul_f32 v19, 0x3db504f3, v19 :: v_dual_mul_f32 v28, 0x3db504f3, v28// 0000004A30C4: C8C626FF 131C38FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004A30D0: BF8701A3
	v_dual_mul_f32 v30, s2, v29 :: v_dual_sub_f32 v29, v33, v34// 0000004A30D4: C8CA3A02 1E1C4521
	v_add_co_ci_u32_e64 v25, null, v8, v31, vcc_lo             // 0000004A30DC: D5207C19 01AA3F08
	v_mul_f32_e32 v34, s0, v28                                 // 0000004A30E4: 10443800
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A30E8: BF870213
	.long 0x7e02399e                                           // 0000004A30EC: 7E02399E
	v_dual_mul_f32 v28, 0x3db504f3, v29 :: v_dual_mul_f32 v19, s4, v19// 0000004A30F0: C8C63AFF 1C122604 3DB504F3
	.long 0x7f3e3981                                           // 0000004A30FC: 7F3E3981
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A3100: BF870214
	.long 0x7e3e39a2                                           // 0000004A3104: 7E3E39A2
	v_and_b32_e32 v33, 1, v1                                   // 0000004A3108: 36420281
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A310C: BF870004
	v_mul_f32_e32 v35, s3, v28                                 // 0000004A3110: 10463803
	v_or_b32_e32 v28, 0x60, v32                                // 0000004A3114: 383840FF 00000060
	v_xor_b32_e32 v32, v21, v3                                 // 0000004A311C: 3A400715
	.long 0x7f4a3981                                           // 0000004A3120: 7F4A3981
	v_add3_u32 v38, v30, v33, 0x7fff                           // 0000004A3124: D6550026 03FE431E 00007FFF
	.long 0x7e4a39a3                                           // 0000004A3130: 7E4A39A3
	v_mad_i64_i32 v[28:29], null, v28, s12, 0                  // 0000004A3134: D6FF7C1C 0200191C
	v_lshl_add_u32 v32, v32, 2, v36                            // 0000004A313C: D6460020 04910520
	v_and_b32_e32 v36, 1, v31                                  // 0000004A3144: 36483E81
	ds_load_2addr_stride64_b32 v[30:31], v32 offset1:64        // 0000004A3148: D8E04000 1E000020
	ds_load_2addr_stride64_b32 v[32:33], v32 offset0:128 offset1:192// 0000004A3150: D8E0C080 20000020
	.long 0x7e023993                                           // 0000004A3158: 7E023993
	.long 0xd73c001c                                           // 0000004A315C: D73C001C
	v_cndmask_b32_e32 v1, 1, v28, vcc_lo                       // 0000004A3160: 02023881
	.long 0xd7600000                                           // 0000004A3164: D7600000
	v_cndmask_b32_e32 v0, v17, v129, vcc_lo                    // 0000004A3168: 02010311
	v_and_b32_e32 v37, 1, v37                                  // 0000004A316C: 364A4A81
	v_add3_u32 v21, v34, v36, 0x7fff                           // 0000004A3170: D6550015 03FE4922 00007FFF
	v_and_b32_e32 v39, 1, v1                                   // 0000004A317C: 364E0281
	s_clause 0x1                                               // 0000004A3180: BF850001
	global_store_d16_hi_b16 v[26:27], v21, off                 // 0000004A3184: DC960000 007C151A
	global_store_d16_hi_b16 v[22:23], v38, off                 // 0000004A318C: DC960000 007C2616
	.long 0xd7006a1c                                           // 0000004A3194: D7006A1C
	v_cndmask_b32_e32 v1, v4, v28, vcc_lo                      // 0000004A3198: 02023904
	v_add3_u32 v36, v35, v37, 0x7fff                           // 0000004A319C: D6550024 03FE4B23 00007FFF
	v_add3_u32 v19, v19, v39, 0x7fff                           // 0000004A31A8: D6550013 03FE4F13 00007FFF
	v_add_co_ci_u32_e64 v29, null, v8, v29, vcc_lo             // 0000004A31B4: D5207C1D 01AA3B08
	s_clause 0x1                                               // 0000004A31BC: BF850001
	global_store_d16_hi_b16 v[24:25], v36, off                 // 0000004A31C0: DC960000 007C2418
	global_store_d16_hi_b16 v[28:29], v19, off                 // 0000004A31C8: DC960000 007C131C
	s_waitcnt lgkmcnt(0)                                       // 0000004A31D0: BF89FC07
	v_dual_sub_f32 v19, v30, v31 :: v_dual_sub_f32 v28, v32, v33// 0000004A31D4: C94A3F1E 131C4320
	v_add_f32_e32 v29, v32, v33                                // 0000004A31DC: 063A4320
	.long 0xd7600003                                           // 0000004A31E0: D7600003
	v_cndmask_b32_e32 v0, v17, v145, vcc_lo                    // 0000004A31E4: 02012311
	v_mad_i64_i32 v[34:35], null, v40, s12, 0                  // 0000004A31E8: D6FF7C22 02001928
	v_or_b32_e32 v23, 32, v40                                  // 0000004A31F0: 382E50A0
	v_add_f32_e32 v25, v19, v28                                // 0000004A31F4: 06323913
	v_sub_f32_e32 v19, v19, v28                                // 0000004A31F8: 08263913
	.long 0x7f383981                                           // 0000004A31FC: 7F383981
	v_add_f32_e32 v27, v30, v31                                // 0000004A3200: 06363F1E
	.long 0xd7600002                                           // 0000004A3204: D7600002
	v_cndmask_b32_e32 v0, v18, v129, vcc_lo                    // 0000004A3208: 02010312
	v_mul_f32_e32 v25, 0x3db504f3, v25                         // 0000004A320C: 103232FF 3DB504F3
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 0000004A3214: 102626FF 3DB504F3
	.long 0xd73c0015                                           // 0000004A321C: D73C0015
	v_cndmask_b32_e32 v1, 1, v34, vcc_lo                       // 0000004A3220: 02024481
	v_add_f32_e32 v26, v27, v29                                // 0000004A3224: 06343B1B
	v_mad_i64_i32 v[23:24], null, v23, s12, 0                  // 0000004A3228: D6FF7C17 02001917
	v_dual_mul_f32 v31, s2, v25 :: v_dual_lshlrev_b32 v34, 9, v20// 0000004A3230: C8E23202 1F222889
	v_or_b32_e32 v30, 64, v40                                  // 0000004A3238: 383C50C0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004A323C: BF870224
	v_mul_f32_e32 v26, 0x3db504f3, v26                         // 0000004A3240: 103434FF 3DB504F3
	.long 0xd7006a15                                           // 0000004A3248: D7006A15
	v_cndmask_b32_e32 v1, v4, v21, vcc_lo                      // 0000004A324C: 02022B04
	.long 0x7e02399f                                           // 0000004A3250: 7E02399F
	.long 0xd73c0017                                           // 0000004A3254: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000004A3258: 02022E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004A325C: BF870244
	v_mul_f32_e32 v32, s0, v26                                 // 0000004A3260: 10403400
	v_mad_i64_i32 v[25:26], null, v30, s12, 0                  // 0000004A3264: D6FF7C19 0200191E
	.long 0xd7600000                                           // 0000004A326C: D7600000
	v_cndmask_b32_e32 v0, v18, v145, vcc_lo                    // 0000004A3270: 02012312
	v_add_co_ci_u32_e64 v22, null, v8, v22, vcc_lo             // 0000004A3274: D5207C16 01AA2D08
	.long 0x7e3839a0                                           // 0000004A327C: 7E3839A0
	.long 0xd7006a17                                           // 0000004A3280: D7006A17
	v_cndmask_b32_e32 v1, v4, v23, vcc_lo                      // 0000004A3284: 02022F04
	v_xor_b32_e32 v33, v20, v3                                 // 0000004A3288: 3A420714
	v_add_co_ci_u32_e64 v24, null, v8, v24, vcc_lo             // 0000004A328C: D5207C18 01AA3108
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A3294: BF870004
	v_dual_sub_f32 v27, v27, v29 :: v_dual_and_b32 v28, 1, v28 // 0000004A3298: C9643B1B 1B1C3881
	v_and_b32_e32 v29, 1, v1                                   // 0000004A32A0: 363A0281
	.long 0xd7600002                                           // 0000004A32A4: D7600002
	v_cndmask_b32_e32 v0, v18, v130, vcc_lo                    // 0000004A32A8: 02010512
	v_mul_f32_e32 v19, s0, v19                                 // 0000004A32AC: 10262600
	.long 0xd73c0019                                           // 0000004A32B0: D73C0019
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 0000004A32B4: 02023281
	v_mul_f32_e32 v27, 0x3db504f3, v27                         // 0000004A32B8: 103636FF 3DB504F3
	v_add3_u32 v29, v31, v29, 0x7fff                           // 0000004A32C0: D655001D 03FE3B1F 00007FFF
	v_add3_u32 v31, v32, v28, 0x7fff                           // 0000004A32CC: D655001F 03FE3920 00007FFF
	.long 0x7f403981                                           // 0000004A32D8: 7F403981
	s_clause 0x1                                               // 0000004A32DC: BF850001
	global_store_d16_hi_b16 v[21:22], v31, off                 // 0000004A32E0: DC960000 007C1F15
	global_store_d16_hi_b16 v[23:24], v29, off                 // 0000004A32E8: DC960000 007C1D17
	v_mul_f32_e32 v30, s3, v27                                 // 0000004A32F0: 103C3603
	v_or_b32_e32 v27, 0x60, v40                                // 0000004A32F4: 383650FF 00000060
	v_lshl_add_u32 v23, v33, 2, v34                            // 0000004A32FC: D6460017 04890521
	.long 0x7e023993                                           // 0000004A3304: 7E023993
	v_or_b32_e32 v31, s1, v20                                  // 0000004A3308: 383E2801
	.long 0x7e40399e                                           // 0000004A330C: 7E40399E
	v_mad_i64_i32 v[27:28], null, v27, s12, 0                  // 0000004A3310: D6FF7C1B 0200191B
	ds_load_2addr_stride64_b32 v[21:22], v23 offset1:64        // 0000004A3318: D8E04000 15000017
	v_and_b32_e32 v35, 1, v1                                   // 0000004A3320: 36460281
	.long 0xd7006a19                                           // 0000004A3324: D7006A19
	v_cndmask_b32_e32 v1, v4, v25, vcc_lo                      // 0000004A3328: 02023304
	v_and_b32_e32 v24, 1, v32                                  // 0000004A332C: 36304081
	v_add_co_ci_u32_e64 v26, null, v8, v26, vcc_lo             // 0000004A3330: D5207C1A 01AA3508
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004A3338: BF870224
	v_add3_u32 v29, v19, v35, 0x7fff                           // 0000004A333C: D655001D 03FE4713 00007FFF
	.long 0xd73c0013                                           // 0000004A3348: D73C0013
	v_cndmask_b32_e32 v1, 1, v27, vcc_lo                       // 0000004A334C: 02023681
	v_add3_u32 v30, v30, v24, 0x7fff                           // 0000004A3350: D655001E 03FE311E 00007FFF
	ds_load_2addr_stride64_b32 v[23:24], v23 offset0:128 offset1:192// 0000004A335C: D8E0C080 17000017
	v_mad_i64_i32 v[27:28], null, v31, s12, 0                  // 0000004A3364: D6FF7C1B 0200191F
	v_or_b32_e32 v32, 64, v31                                  // 0000004A336C: 38403EC0
	.long 0xd7600000                                           // 0000004A3370: D7600000
	v_cndmask_b32_e32 v0, v17, v130, vcc_lo                    // 0000004A3374: 02010511
	.long 0xd7006a13                                           // 0000004A3378: D7006A13
	v_cndmask_b32_e32 v1, v4, v19, vcc_lo                      // 0000004A337C: 02022704
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004A3380: BF870001
	v_add_co_ci_u32_e64 v20, null, v8, v20, vcc_lo             // 0000004A3384: D5207C14 01AA2908
	global_store_d16_hi_b16 v[25:26], v30, off                 // 0000004A338C: DC960000 007C1E19
	.long 0xd73c0019                                           // 0000004A3394: D73C0019
	v_cndmask_b32_e32 v1, 1, v27, vcc_lo                       // 0000004A3398: 02023681
	v_mad_i64_i32 v[27:28], null, v32, s12, 0                  // 0000004A339C: D6FF7C1B 02001920
	global_store_d16_hi_b16 v[19:20], v29, off                 // 0000004A33A4: DC960000 007C1D13
	s_waitcnt lgkmcnt(1)                                       // 0000004A33AC: BF89FC17
	v_sub_f32_e32 v29, v21, v22                                // 0000004A33B0: 083A2D15
	v_or_b32_e32 v30, 32, v31                                  // 0000004A33B4: 383C3EA0
	.long 0xd7600003                                           // 0000004A33B8: D7600003
	v_cndmask_b32_e32 v0, v17, v146, vcc_lo                    // 0000004A33BC: 02012511
	.long 0x7f463981                                           // 0000004A33C0: 7F463981
	.long 0xd7006a19                                           // 0000004A33C4: D7006A19
	v_cndmask_b32_e32 v1, v4, v25, vcc_lo                      // 0000004A33C8: 02023304
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A33CC: BF870004
	v_mad_i64_i32 v[19:20], null, v30, s12, 0                  // 0000004A33D0: D6FF7C13 0200191E
	v_add_f32_e32 v30, v21, v22                                // 0000004A33D8: 063C2D15
	s_waitcnt lgkmcnt(0)                                       // 0000004A33DC: BF89FC07
	v_sub_f32_e32 v32, v23, v24                                // 0000004A33E0: 08403117
	v_add_f32_e32 v23, v23, v24                                // 0000004A33E4: 062E3117
	.long 0xd73c0015                                           // 0000004A33E8: D73C0015
	v_cndmask_b32_e32 v1, 1, v27, vcc_lo                       // 0000004A33EC: 02023681
	v_add_co_ci_u32_e64 v26, null, v8, v26, vcc_lo             // 0000004A33F0: D5207C1A 01AA3508
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004A33F8: BF870124
	v_add_f32_e32 v24, v29, v32                                // 0000004A33FC: 0630411D
	.long 0xd73c0013                                           // 0000004A3400: D73C0013
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000004A3404: 02022681
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 0000004A3408: 103030FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004A3410: BF870092
	.long 0xd7006a13                                           // 0000004A3414: D7006A13
	v_cndmask_b32_e32 v1, v4, v19, vcc_lo                      // 0000004A3418: 02022704
	v_add_co_ci_u32_e64 v20, null, v8, v20, vcc_lo             // 0000004A341C: D5207C14 01AA2908
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004A3424: BF870243
	v_mul_f32_e32 v28, s2, v24                                 // 0000004A3428: 10383002
	v_dual_sub_f32 v24, v29, v32 :: v_dual_add_f32 v27, v30, v23// 0000004A342C: C948411D 181A2F1E
	v_sub_f32_e32 v23, v30, v23                                // 0000004A3434: 082E2F1E
	v_xor_b32_e32 v30, v15, v3                                 // 0000004A3438: 3A3C070F
	.long 0x7e02399c                                           // 0000004A343C: 7E02399C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A3440: BF870214
	v_dual_mul_f32 v24, 0x3db504f3, v24 :: v_dual_mul_f32 v27, 0x3db504f3, v27// 0000004A3444: C8C630FF 181A36FF 3DB504F3
	v_mul_f32_e32 v23, 0x3db504f3, v23                         // 0000004A3450: 102E2EFF 3DB504F3
	.long 0xd7600002                                           // 0000004A3458: D7600002
	v_cndmask_b32_e32 v0, v18, v131, vcc_lo                    // 0000004A345C: 02010712
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A3460: BF870004
	v_and_b32_e32 v29, 1, v1                                   // 0000004A3464: 363A0281
	.long 0xd7006a15                                           // 0000004A3468: D7006A15
	v_cndmask_b32_e32 v1, v4, v21, vcc_lo                      // 0000004A346C: 02022B04
	v_mul_f32_e32 v32, s0, v27                                 // 0000004A3470: 10403600
	v_mul_f32_e32 v34, s3, v23                                 // 0000004A3474: 10442E03
	v_or_b32_e32 v23, 0x60, v31                                // 0000004A3478: 382E3EFF 00000060
	v_lshlrev_b32_e32 v31, 9, v15                              // 0000004A3480: 303E1E89
	.long 0xd7600000                                           // 0000004A3484: D7600000
	v_cndmask_b32_e32 v0, v18, v146, vcc_lo                    // 0000004A3488: 02012512
	.long 0x7e3639a0                                           // 0000004A348C: 7E3639A0
	.long 0x7f363981                                           // 0000004A3490: 7F363981
	v_add3_u32 v36, v28, v29, 0x7fff                           // 0000004A3494: D6550024 03FE3B1C 00007FFF
	v_lshl_add_u32 v30, v30, 2, v31                            // 0000004A34A0: D646001E 047D051E
	v_mul_f32_e32 v33, s0, v24                                 // 0000004A34A8: 10423000
	v_mad_i64_i32 v[23:24], null, v23, s12, 0                  // 0000004A34AC: D6FF7C17 02001917
	v_and_b32_e32 v31, 1, v27                                  // 0000004A34B4: 363E3681
	ds_load_2addr_stride64_b32 v[27:28], v30 offset1:64        // 0000004A34B8: D8E04000 1B00001E
	ds_load_2addr_stride64_b32 v[29:30], v30 offset0:128 offset1:192// 0000004A34C0: D8E0C080 1D00001E
	.long 0x7e4639a2                                           // 0000004A34C8: 7E4639A2
	.long 0x7e0239a1                                           // 0000004A34CC: 7E0239A1
	v_or_b32_e32 v15, s1, v15                                  // 0000004A34D0: 381E1E01
	v_add3_u32 v38, v32, v31, 0x7fff                           // 0000004A34D4: D6550026 03FE3F20 00007FFF
	.long 0xd73c0017                                           // 0000004A34E0: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000004A34E4: 02022E81
	v_and_b32_e32 v35, 1, v35                                  // 0000004A34E8: 36464681
	.long 0xd7600003                                           // 0000004A34EC: D7600003
	v_cndmask_b32_e32 v0, v17, v147, vcc_lo                    // 0000004A34F0: 02012711
	v_and_b32_e32 v37, 1, v1                                   // 0000004A34F4: 364A0281
	v_add_co_ci_u32_e64 v22, null, v8, v22, vcc_lo             // 0000004A34F8: D5207C16 01AA2D08
	.long 0xd7006a17                                           // 0000004A3500: D7006A17
	v_cndmask_b32_e32 v1, v4, v23, vcc_lo                      // 0000004A3504: 02022F04
	v_add3_u32 v34, v34, v35, 0x7fff                           // 0000004A3508: D6550022 03FE4722 00007FFF
	s_clause 0x1                                               // 0000004A3514: BF850001
	global_store_d16_hi_b16 v[25:26], v38, off                 // 0000004A3518: DC960000 007C2619
	global_store_d16_hi_b16 v[19:20], v36, off                 // 0000004A3520: DC960000 007C2413
	v_or_b32_e32 v25, 32, v15                                  // 0000004A3528: 38321EA0
	v_add3_u32 v33, v33, v37, 0x7fff                           // 0000004A352C: D6550021 03FE4B21 00007FFF
	v_add_co_ci_u32_e64 v24, null, v8, v24, vcc_lo             // 0000004A3538: D5207C18 01AA3108
	s_clause 0x1                                               // 0000004A3540: BF850001
	global_store_d16_hi_b16 v[21:22], v34, off                 // 0000004A3544: DC960000 007C2215
	global_store_d16_hi_b16 v[23:24], v33, off                 // 0000004A354C: DC960000 007C2117
	v_mad_i64_i32 v[21:22], null, v25, s12, 0                  // 0000004A3554: D6FF7C15 02001919
	s_waitcnt lgkmcnt(1)                                       // 0000004A355C: BF89FC17
	v_sub_f32_e32 v25, v27, v28                                // 0000004A3560: 0832391B
	s_waitcnt lgkmcnt(0)                                       // 0000004A3564: BF89FC07
	v_dual_add_f32 v26, v27, v28 :: v_dual_sub_f32 v27, v29, v30// 0000004A3568: C90A391B 1A1A3D1D
	v_add_f32_e32 v28, v29, v30                                // 0000004A3570: 06383D1D
	v_mad_i64_i32 v[31:32], null, v15, s12, 0                  // 0000004A3574: D6FF7C1F 0200190F
	.long 0xd7600000                                           // 0000004A357C: D7600000
	v_cndmask_b32_e32 v0, v17, v131, vcc_lo                    // 0000004A3580: 02010711
	v_or_b32_e32 v29, 64, v15                                  // 0000004A3584: 383A1EC0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004A3588: BF870244
	v_dual_add_f32 v23, v25, v27 :: v_dual_add_f32 v24, v26, v28// 0000004A358C: C9083719 1718391A
	v_sub_f32_e32 v26, v26, v28                                // 0000004A3594: 0834391A
	.long 0xd73c0015                                           // 0000004A3598: D73C0015
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 0000004A359C: 02022A81
	v_or_b32_e32 v15, 0x60, v15                                // 0000004A35A0: 381E1EFF 00000060
	v_dual_mul_f32 v23, 0x3db504f3, v23 :: v_dual_mul_f32 v24, 0x3db504f3, v24// 0000004A35A8: C8C62EFF 171830FF 3DB504F3
	.long 0xd73c0013                                           // 0000004A35B4: D73C0013
	v_cndmask_b32_e32 v1, 1, v31, vcc_lo                       // 0000004A35B8: 02023E81
	v_dual_mul_f32 v26, 0x3db504f3, v26 :: v_dual_lshlrev_b32 v33, 9, v16// 0000004A35BC: C8E234FF 1A202089 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004A35C8: BF870243
	v_dual_mul_f32 v30, s2, v23 :: v_dual_mul_f32 v31, s0, v24 // 0000004A35CC: C8C62E02 1E1E3000
	.long 0xd7600002                                           // 0000004A35D4: D7600002
	v_cndmask_b32_e32 v0, v18, v132, vcc_lo                    // 0000004A35D8: 02010912
	.long 0xd7600000                                           // 0000004A35DC: D7600000
	v_cndmask_b32_e32 v0, v18, v147, vcc_lo                    // 0000004A35E0: 02012712
	v_mad_i64_i32 v[23:24], null, v29, s12, 0                  // 0000004A35E4: D6FF7C17 0200191D
	.long 0x7e02399e                                           // 0000004A35EC: 7E02399E
	v_mul_f32_e32 v32, s3, v26                                 // 0000004A35F0: 10403403
	.long 0xd7006a13                                           // 0000004A35F4: D7006A13
	v_cndmask_b32_e32 v1, v4, v19, vcc_lo                      // 0000004A35F8: 02022704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A35FC: BF870211
	v_add_co_ci_u32_e64 v20, null, v8, v20, vcc_lo             // 0000004A3600: D5207C14 01AA2908
	v_dual_sub_f32 v25, v25, v27 :: v_dual_and_b32 v28, 1, v1  // 0000004A3608: C9643719 191C0281
	.long 0x7e36399f                                           // 0000004A3610: 7E36399F
	.long 0x7f363981                                           // 0000004A3614: 7F363981
	.long 0xd7006a15                                           // 0000004A3618: D7006A15
	v_cndmask_b32_e32 v1, v4, v21, vcc_lo                      // 0000004A361C: 02022B04
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004A3620: BF870224
	v_mul_f32_e32 v25, 0x3db504f3, v25                         // 0000004A3624: 103232FF 3DB504F3
	v_add3_u32 v28, v30, v28, 0x7fff                           // 0000004A362C: D655001C 03FE391E 00007FFF
	v_and_b32_e32 v27, 1, v27                                  // 0000004A3638: 36363681
	.long 0x7e3c39a0                                           // 0000004A363C: 7E3C39A0
	.long 0x7f3c3981                                           // 0000004A3640: 7F3C3981
	v_mul_f32_e32 v29, s0, v25                                 // 0000004A3644: 103A3200
	v_add_co_ci_u32_e64 v22, null, v8, v22, vcc_lo             // 0000004A3648: D5207C16 01AA2D08
	v_add3_u32 v27, v31, v27, 0x7fff                           // 0000004A3650: D655001B 03FE371F 00007FFF
	v_xor_b32_e32 v31, v16, v3                                 // 0000004A365C: 3A3E0710
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A3660: BF870004
	.long 0x7e02399d                                           // 0000004A3664: 7E02399D
	v_mad_i64_i32 v[25:26], null, v15, s12, 0                  // 0000004A3668: D6FF7C19 0200190F
	s_clause 0x1                                               // 0000004A3670: BF850001
	global_store_d16_hi_b16 v[19:20], v27, off                 // 0000004A3674: DC960000 007C1B13
	global_store_d16_hi_b16 v[21:22], v28, off                 // 0000004A367C: DC960000 007C1C15
	v_lshl_add_u32 v21, v31, 2, v33                            // 0000004A3684: D6460015 0485051F
	v_and_b32_e32 v15, 1, v1                                   // 0000004A368C: 361E0281
	v_and_b32_e32 v22, 1, v30                                  // 0000004A3690: 362C3C81
	.long 0xd73c0017                                           // 0000004A3694: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000004A3698: 02022E81
	v_or_b32_e32 v28, s1, v16                                  // 0000004A369C: 38382001
	ds_load_2addr_stride64_b32 v[19:20], v21 offset1:64        // 0000004A36A0: D8E04000 13000015
	v_add3_u32 v27, v29, v15, 0x7fff                           // 0000004A36A8: D655001B 03FE1F1D 00007FFF
	v_add3_u32 v29, v32, v22, 0x7fff                           // 0000004A36B4: D655001D 03FE2D20 00007FFF
	ds_load_2addr_stride64_b32 v[21:22], v21 offset0:128 offset1:192// 0000004A36C0: D8E0C080 15000015
	.long 0xd73c000f                                           // 0000004A36C8: D73C000F
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 0000004A36CC: 02023281
	.long 0xd7006a17                                           // 0000004A36D0: D7006A17
	v_cndmask_b32_e32 v1, v4, v23, vcc_lo                      // 0000004A36D4: 02022F04
	v_mad_i64_i32 v[25:26], null, v28, s12, 0                  // 0000004A36D8: D6FF7C19 0200191C
	v_add_co_ci_u32_e64 v24, null, v8, v24, vcc_lo             // 0000004A36E0: D5207C18 01AA3108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004A36E8: BF870094
	.long 0xd7006a0f                                           // 0000004A36EC: D7006A0F
	v_cndmask_b32_e32 v1, v4, v15, vcc_lo                      // 0000004A36F0: 02021F04
	v_add_co_ci_u32_e64 v16, null, v8, v16, vcc_lo             // 0000004A36F4: D5207C10 01AA2108
	v_or_b32_e32 v30, 64, v28                                  // 0000004A36FC: 383C38C0
	global_store_d16_hi_b16 v[23:24], v29, off                 // 0000004A3700: DC960000 007C1D17
	v_or_b32_e32 v29, 32, v28                                  // 0000004A3708: 383A38A0
	.long 0xd73c0017                                           // 0000004A370C: D73C0017
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 0000004A3710: 02023281
	global_store_d16_hi_b16 v[15:16], v27, off                 // 0000004A3714: DC960000 007C1B0F
	v_mad_i64_i32 v[25:26], null, v30, s12, 0                  // 0000004A371C: D6FF7C19 0200191E
	s_waitcnt lgkmcnt(1)                                       // 0000004A3724: BF89FC17
	v_dual_sub_f32 v27, v19, v20 :: v_dual_lshlrev_b32 v32, 9, v14// 0000004A3728: C9622913 1B201C89
	v_mad_i64_i32 v[15:16], null, v29, s12, 0                  // 0000004A3730: D6FF7C0F 0200191D
	s_waitcnt lgkmcnt(0)                                       // 0000004A3738: BF89FC07
	v_dual_sub_f32 v30, v21, v22 :: v_dual_add_f32 v29, v19, v20// 0000004A373C: C9482D15 1E1C2913
	v_add_f32_e32 v21, v21, v22                                // 0000004A3744: 062A2D15
	.long 0xd7600000                                           // 0000004A3748: D7600000
	v_cndmask_b32_e32 v0, v17, v132, vcc_lo                    // 0000004A374C: 02010911
	.long 0xd73c0013                                           // 0000004A3750: D73C0013
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 0000004A3754: 02023281
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A3758: BF870004
	v_add_f32_e32 v22, v27, v30                                // 0000004A375C: 062C3D1B
	.long 0xd7600003                                           // 0000004A3760: D7600003
	v_cndmask_b32_e32 v0, v17, v148, vcc_lo                    // 0000004A3764: 02012911
	v_add_f32_e32 v25, v29, v21                                // 0000004A3768: 06322B1D
	v_sub_f32_e32 v21, v29, v21                                // 0000004A376C: 082A2B1D
	.long 0xd73c000f                                           // 0000004A3770: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000004A3774: 02021E81
	v_mul_f32_e32 v22, 0x3db504f3, v22                         // 0000004A3778: 102C2CFF 3DB504F3
	.long 0x7f423981                                           // 0000004A3780: 7F423981
	v_mul_f32_e32 v25, 0x3db504f3, v25                         // 0000004A3784: 103232FF 3DB504F3
	v_mul_f32_e32 v21, 0x3db504f3, v21                         // 0000004A378C: 102A2AFF 3DB504F3
	.long 0xd7006a17                                           // 0000004A3794: D7006A17
	v_cndmask_b32_e32 v1, v4, v23, vcc_lo                      // 0000004A3798: 02022F04
	v_mul_f32_e32 v26, s2, v22                                 // 0000004A379C: 10342C02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A37A0: BF870214
	v_dual_sub_f32 v22, v27, v30 :: v_dual_mul_f32 v29, s0, v25// 0000004A37A4: C9463D1B 161C3200
	v_mul_f32_e32 v31, s3, v21                                 // 0000004A37AC: 103E2A03
	v_or_b32_e32 v21, 0x60, v28                                // 0000004A37B0: 382A38FF 00000060
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A37B8: BF870004
	.long 0x7e02399a                                           // 0000004A37BC: 7E02399A
	v_xor_b32_e32 v28, v14, v3                                 // 0000004A37C0: 3A38070E
	.long 0xd7600000                                           // 0000004A37C4: D7600000
	v_cndmask_b32_e32 v0, v18, v148, vcc_lo                    // 0000004A37C8: 02012912
	v_mul_f32_e32 v22, 0x3db504f3, v22                         // 0000004A37CC: 102C2CFF 3DB504F3
	.long 0x7e32399d                                           // 0000004A37D4: 7E32399D
	.long 0x7f323981                                           // 0000004A37D8: 7F323981
	v_lshl_add_u32 v28, v28, 2, v32                            // 0000004A37DC: D646001C 0481051C
	.long 0xd7600003                                           // 0000004A37E4: D7600003
	v_cndmask_b32_e32 v0, v17, v149, vcc_lo                    // 0000004A37E8: 02012B11
	v_dual_mul_f32 v30, s0, v22 :: v_dual_and_b32 v27, 1, v1   // 0000004A37EC: C8E42C00 1E1A0281
	v_mad_i64_i32 v[21:22], null, v21, s12, 0                  // 0000004A37F4: D6FF7C15 02001915
	v_and_b32_e32 v32, 1, v25                                  // 0000004A37FC: 36403281
	.long 0x7e42399f                                           // 0000004A3800: 7E42399F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A3804: BF870004
	v_add3_u32 v34, v26, v27, 0x7fff                           // 0000004A3808: D6550022 03FE371A 00007FFF
	ds_load_2addr_stride64_b32 v[25:26], v28 offset1:64        // 0000004A3814: D8E04000 1900001C
	ds_load_2addr_stride64_b32 v[27:28], v28 offset0:128 offset1:192// 0000004A381C: D8E0C080 1B00001C
	.long 0x7e02399e                                           // 0000004A3824: 7E02399E
	v_add_co_ci_u32_e64 v24, null, v8, v24, vcc_lo             // 0000004A3828: D5207C18 01AA3108
	.long 0xd73c0015                                           // 0000004A3830: D73C0015
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 0000004A3834: 02022A81
	.long 0xd7006a0f                                           // 0000004A3838: D7006A0F
	v_cndmask_b32_e32 v1, v4, v15, vcc_lo                      // 0000004A383C: 02021F04
	v_and_b32_e32 v33, 1, v33                                  // 0000004A3840: 36424281
	v_or_b32_e32 v36, s1, v14                                  // 0000004A3844: 38481C01
	v_add3_u32 v14, v29, v32, 0x7fff                           // 0000004A3848: D655000E 03FE411D 00007FFF
	v_add_co_ci_u32_e64 v16, null, v8, v16, vcc_lo             // 0000004A3854: D5207C10 01AA2108
	v_and_b32_e32 v35, 1, v1                                   // 0000004A385C: 36460281
	.long 0xd7006a13                                           // 0000004A3860: D7006A13
	v_cndmask_b32_e32 v1, v4, v19, vcc_lo                      // 0000004A3864: 02022704
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004A3868: BF870001
	v_add_co_ci_u32_e64 v20, null, v8, v20, vcc_lo             // 0000004A386C: D5207C14 01AA2908
	.long 0xd7006a15                                           // 0000004A3874: D7006A15
	v_cndmask_b32_e32 v1, v4, v21, vcc_lo                      // 0000004A3878: 02022B04
	v_add3_u32 v31, v31, v33, 0x7fff                           // 0000004A387C: D655001F 03FE431F 00007FFF
	s_clause 0x1                                               // 0000004A3888: BF850001
	global_store_d16_hi_b16 v[23:24], v14, off                 // 0000004A388C: DC960000 007C0E17
	global_store_d16_hi_b16 v[15:16], v34, off                 // 0000004A3894: DC960000 007C220F
	v_or_b32_e32 v16, 32, v36                                  // 0000004A389C: 382048A0
	v_add3_u32 v32, v30, v35, 0x7fff                           // 0000004A38A0: D6550020 03FE471E 00007FFF
	v_add_co_ci_u32_e64 v22, null, v8, v22, vcc_lo             // 0000004A38AC: D5207C16 01AA2D08
	v_mad_i64_i32 v[29:30], null, v36, s12, 0                  // 0000004A38B4: D6FF7C1D 02001924
	s_clause 0x1                                               // 0000004A38BC: BF850001
	global_store_d16_hi_b16 v[19:20], v31, off                 // 0000004A38C0: DC960000 007C1F13
	global_store_d16_hi_b16 v[21:22], v32, off                 // 0000004A38C8: DC960000 007C2015
	v_mad_i64_i32 v[19:20], null, v16, s12, 0                  // 0000004A38D0: D6FF7C13 02001910
	s_waitcnt lgkmcnt(1)                                       // 0000004A38D8: BF89FC17
	v_sub_f32_e32 v16, v25, v26                                // 0000004A38DC: 08203519
	s_waitcnt lgkmcnt(0)                                       // 0000004A38E0: BF89FC07
	v_dual_add_f32 v23, v25, v26 :: v_dual_sub_f32 v24, v27, v28// 0000004A38E4: C90A3519 1718391B
	v_add_f32_e32 v25, v27, v28                                // 0000004A38EC: 0632391B
	.long 0xd73c000e                                           // 0000004A38F0: D73C000E
	v_cndmask_b32_e32 v1, 1, v29, vcc_lo                       // 0000004A38F4: 02023A81
	v_lshlrev_b32_e32 v30, 9, v13                              // 0000004A38F8: 303C1A89
	.long 0xd7600000                                           // 0000004A38FC: D7600000
	v_cndmask_b32_e32 v0, v17, v133, vcc_lo                    // 0000004A3900: 02010B11
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004A3904: BF870244
	v_dual_add_f32 v21, v16, v24 :: v_dual_add_f32 v22, v23, v25// 0000004A3908: C9083110 15163317
	.long 0xd7600002                                           // 0000004A3910: D7600002
	v_cndmask_b32_e32 v0, v18, v133, vcc_lo                    // 0000004A3914: 02010B12
	v_sub_f32_e32 v16, v16, v24                                // 0000004A3918: 08203110
	v_or_b32_e32 v26, 64, v36                                  // 0000004A391C: 383448C0
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_mul_f32 v22, 0x3db504f3, v22// 0000004A3920: C8C62AFF 15162CFF 3DB504F3
	.long 0x7f303981                                           // 0000004A392C: 7F303981
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004A3930: BF870224
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 0000004A3934: 102020FF 3DB504F3
	.long 0xd73c0013                                           // 0000004A393C: D73C0013
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000004A3940: 02022681
	v_dual_mul_f32 v27, s2, v21 :: v_dual_mul_f32 v28, s0, v22 // 0000004A3944: C8C62A02 1B1C2C00
	.long 0xd7600002                                           // 0000004A394C: D7600002
	v_cndmask_b32_e32 v0, v18, v134, vcc_lo                    // 0000004A3950: 02010D12
	v_sub_f32_e32 v23, v23, v25                                // 0000004A3954: 082E3317
	.long 0xd7600000                                           // 0000004A3958: D7600000
	v_cndmask_b32_e32 v0, v18, v149, vcc_lo                    // 0000004A395C: 02012B12
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004A3960: BF870234
	.long 0x7e02399b                                           // 0000004A3964: 7E02399B
	.long 0x7e30399c                                           // 0000004A3968: 7E30399C
	v_mad_i64_i32 v[21:22], null, v26, s12, 0                  // 0000004A396C: D6FF7C15 0200191A
	v_dual_mul_f32 v23, 0x3db504f3, v23 :: v_dual_mul_f32 v16, s0, v16// 0000004A3974: C8C62EFF 17102000 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A3980: BF870214
	v_and_b32_e32 v25, 1, v1                                   // 0000004A3984: 36320281
	v_and_b32_e32 v24, 1, v24                                  // 0000004A3988: 36303081
	.long 0xd7006a0e                                           // 0000004A398C: D7006A0E
	v_cndmask_b32_e32 v1, v4, v14, vcc_lo                      // 0000004A3990: 02021D04
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A3994: BF870004
	v_mul_f32_e32 v26, s3, v23                                 // 0000004A3998: 10342E03
	v_add_co_ci_u32_e64 v15, null, v8, v15, vcc_lo             // 0000004A399C: D5207C0F 01AA1F08
	.long 0xd7006a13                                           // 0000004A39A4: D7006A13
	v_cndmask_b32_e32 v1, v4, v19, vcc_lo                      // 0000004A39A8: 02022704
	v_add3_u32 v25, v27, v25, 0x7fff                           // 0000004A39AC: D6550019 03FE331B 00007FFF
	v_add3_u32 v27, v28, v24, 0x7fff                           // 0000004A39B8: D655001B 03FE311C 00007FFF
	.long 0x7e023990                                           // 0000004A39C4: 7E023990
	.long 0x7e38399a                                           // 0000004A39C8: 7E38399A
	.long 0x7f383981                                           // 0000004A39CC: 7F383981
	v_xor_b32_e32 v29, v13, v3                                 // 0000004A39D0: 3A3A070D
	v_add_co_ci_u32_e64 v20, null, v8, v20, vcc_lo             // 0000004A39D4: D5207C14 01AA2908
	v_or_b32_e32 v23, 0x60, v36                                // 0000004A39DC: 382E48FF 00000060
	v_and_b32_e32 v31, 1, v1                                   // 0000004A39E4: 363E0281
	s_clause 0x1                                               // 0000004A39E8: BF850001
	global_store_d16_hi_b16 v[14:15], v27, off                 // 0000004A39EC: DC960000 007C1B0E
	global_store_d16_hi_b16 v[19:20], v25, off                 // 0000004A39F4: DC960000 007C1913
	v_lshl_add_u32 v19, v29, 2, v30                            // 0000004A39FC: D6460013 0479051D
	v_and_b32_e32 v20, 1, v28                                  // 0000004A3A04: 36283881
	v_mad_i64_i32 v[23:24], null, v23, s12, 0                  // 0000004A3A08: D6FF7C17 02001917
	v_add3_u32 v25, v16, v31, 0x7fff                           // 0000004A3A10: D6550019 03FE3F10 00007FFF
	.long 0xd73c0015                                           // 0000004A3A1C: D73C0015
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 0000004A3A20: 02022A81
	ds_load_2addr_stride64_b32 v[15:16], v19 offset1:64        // 0000004A3A24: D8E04000 0F000013
	v_add3_u32 v26, v26, v20, 0x7fff                           // 0000004A3A2C: D655001A 03FE291A 00007FFF
	ds_load_2addr_stride64_b32 v[19:20], v19 offset0:128 offset1:192// 0000004A3A38: D8E0C080 13000013
	v_or_b32_e32 v27, s1, v13                                  // 0000004A3A40: 38361A01
	.long 0xd7600000                                           // 0000004A3A44: D7600000
	v_cndmask_b32_e32 v0, v17, v134, vcc_lo                    // 0000004A3A48: 02010D11
	.long 0xd73c000d                                           // 0000004A3A4C: D73C000D
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000004A3A50: 02022E81
	.long 0xd7006a15                                           // 0000004A3A54: D7006A15
	v_cndmask_b32_e32 v1, v4, v21, vcc_lo                      // 0000004A3A58: 02022B04
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004A3A5C: BF870224
	v_mad_i64_i32 v[23:24], null, v27, s12, 0                  // 0000004A3A60: D6FF7C17 0200191B
	v_add_co_ci_u32_e64 v22, null, v8, v22, vcc_lo             // 0000004A3A68: D5207C16 01AA2D08
	.long 0xd7006a0d                                           // 0000004A3A70: D7006A0D
	v_cndmask_b32_e32 v1, v4, v13, vcc_lo                      // 0000004A3A74: 02021B04
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004A3A78: BF870001
	v_add_co_ci_u32_e64 v14, null, v8, v14, vcc_lo             // 0000004A3A7C: D5207C0E 01AA1D08
	v_or_b32_e32 v28, 64, v27                                  // 0000004A3A84: 383836C0
	global_store_d16_hi_b16 v[21:22], v26, off                 // 0000004A3A88: DC960000 007C1A15
	v_or_b32_e32 v26, 32, v27                                  // 0000004A3A90: 383436A0
	.long 0xd73c0015                                           // 0000004A3A94: D73C0015
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000004A3A98: 02022E81
	global_store_d16_hi_b16 v[13:14], v25, off                 // 0000004A3A9C: DC960000 007C190D
	v_mad_i64_i32 v[23:24], null, v28, s12, 0                  // 0000004A3AA4: D6FF7C17 0200191C
	s_waitcnt lgkmcnt(1)                                       // 0000004A3AAC: BF89FC17
	v_sub_f32_e32 v25, v15, v16                                // 0000004A3AB0: 0832210F
	s_waitcnt lgkmcnt(0)                                       // 0000004A3AB4: BF89FC07
	v_sub_f32_e32 v28, v19, v20                                // 0000004A3AB8: 08382913
	v_mad_i64_i32 v[13:14], null, v26, s12, 0                  // 0000004A3ABC: D6FF7C0D 0200191A
	v_add_f32_e32 v26, v15, v16                                // 0000004A3AC4: 0634210F
	v_add_f32_e32 v19, v19, v20                                // 0000004A3AC8: 06262913
	.long 0xd7600003                                           // 0000004A3ACC: D7600003
	v_cndmask_b32_e32 v0, v17, v150, vcc_lo                    // 0000004A3AD0: 02012D11
	v_add_f32_e32 v20, v25, v28                                // 0000004A3AD4: 06283919
	.long 0xd73c000f                                           // 0000004A3AD8: D73C000F
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000004A3ADC: 02022E81
	.long 0x7f3e3981                                           // 0000004A3AE0: 7F3E3981
	v_add_f32_e32 v23, v26, v19                                // 0000004A3AE4: 062E271A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004A3AE8: BF870234
	v_dual_sub_f32 v19, v26, v19 :: v_dual_mul_f32 v20, 0x3db504f3, v20// 0000004A3AEC: C946271A 131428FF 3DB504F3
	v_xor_b32_e32 v26, v12, v3                                 // 0000004A3AF8: 3A34070C
	.long 0xd73c000d                                           // 0000004A3AFC: D73C000D
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000004A3B00: 02021A81
	v_mul_f32_e32 v23, 0x3db504f3, v23                         // 0000004A3B04: 102E2EFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004A3B0C: BF870234
	v_dual_mul_f32 v19, 0x3db504f3, v19 :: v_dual_mul_f32 v24, s2, v20// 0000004A3B10: C8C626FF 13182802 3DB504F3
	v_sub_f32_e32 v20, v25, v28                                // 0000004A3B1C: 08283919
	.long 0xd7006a15                                           // 0000004A3B20: D7006A15
	v_cndmask_b32_e32 v1, v4, v21, vcc_lo                      // 0000004A3B24: 02022B04
	v_mul_f32_e32 v28, s0, v23                                 // 0000004A3B28: 10382E00
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A3B2C: BF870004
	.long 0x7e023998                                           // 0000004A3B30: 7E023998
	v_mul_f32_e32 v30, s3, v19                                 // 0000004A3B34: 103C2603
	v_or_b32_e32 v19, 0x60, v27                                // 0000004A3B38: 382636FF 00000060
	.long 0xd7600003                                           // 0000004A3B40: D7600003
	v_cndmask_b32_e32 v0, v17, v151, vcc_lo                    // 0000004A3B44: 02012F11
	v_lshlrev_b32_e32 v27, 9, v12                              // 0000004A3B48: 30361889
	.long 0xd7600000                                           // 0000004A3B4C: D7600000
	v_cndmask_b32_e32 v0, v18, v150, vcc_lo                    // 0000004A3B50: 02012D12
	v_mul_f32_e32 v20, 0x3db504f3, v20                         // 0000004A3B54: 102828FF 3DB504F3
	.long 0x7e2e399c                                           // 0000004A3B5C: 7E2E399C
	.long 0x7f2e3981                                           // 0000004A3B60: 7F2E3981
	v_and_b32_e32 v25, 1, v1                                   // 0000004A3B64: 36320281
	v_lshl_add_u32 v26, v26, 2, v27                            // 0000004A3B68: D646001A 046D051A
	v_mul_f32_e32 v29, s0, v20                                 // 0000004A3B70: 103A2800
	v_mad_i64_i32 v[19:20], null, v19, s12, 0                  // 0000004A3B74: D6FF7C13 02001913
	v_and_b32_e32 v27, 1, v23                                  // 0000004A3B7C: 36362E81
	v_add3_u32 v32, v24, v25, 0x7fff                           // 0000004A3B80: D6550020 03FE3318 00007FFF
	ds_load_2addr_stride64_b32 v[23:24], v26 offset1:64        // 0000004A3B8C: D8E04000 1700001A
	ds_load_2addr_stride64_b32 v[25:26], v26 offset0:128 offset1:192// 0000004A3B94: D8E0C080 1900001A
	.long 0x7e3e399e                                           // 0000004A3B9C: 7E3E399E
	.long 0x7e02399d                                           // 0000004A3BA0: 7E02399D
	v_add_co_ci_u32_e64 v22, null, v8, v22, vcc_lo             // 0000004A3BA4: D5207C16 01AA2D08
	.long 0xd73c0013                                           // 0000004A3BAC: D73C0013
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000004A3BB0: 02022681
	.long 0xd7006a0d                                           // 0000004A3BB4: D7006A0D
	v_cndmask_b32_e32 v1, v4, v13, vcc_lo                      // 0000004A3BB8: 02021B04
	v_and_b32_e32 v31, 1, v31                                  // 0000004A3BBC: 363E3E81
	v_and_b32_e32 v33, 1, v1                                   // 0000004A3BC0: 36420281
	v_add_co_ci_u32_e64 v14, null, v8, v14, vcc_lo             // 0000004A3BC4: D5207C0E 01AA1D08
	.long 0xd7006a0f                                           // 0000004A3BCC: D7006A0F
	v_cndmask_b32_e32 v1, v4, v15, vcc_lo                      // 0000004A3BD0: 02021F04
	v_or_b32_e32 v34, s1, v12                                  // 0000004A3BD4: 38441801
	v_add_co_ci_u32_e64 v16, null, v8, v16, vcc_lo             // 0000004A3BD8: D5207C10 01AA2108
	.long 0xd7006a13                                           // 0000004A3BE0: D7006A13
	v_cndmask_b32_e32 v1, v4, v19, vcc_lo                      // 0000004A3BE4: 02022704
	v_add3_u32 v12, v28, v27, 0x7fff                           // 0000004A3BE8: D655000C 03FE371C 00007FFF
	v_add3_u32 v30, v30, v31, 0x7fff                           // 0000004A3BF4: D655001E 03FE3F1E 00007FFF
	v_add3_u32 v29, v29, v33, 0x7fff                           // 0000004A3C00: D655001D 03FE431D 00007FFF
	v_add_co_ci_u32_e64 v20, null, v8, v20, vcc_lo             // 0000004A3C0C: D5207C14 01AA2908
	v_mad_i64_i32 v[27:28], null, v34, s12, 0                  // 0000004A3C14: D6FF7C1B 02001922
	s_clause 0x3                                               // 0000004A3C1C: BF850003
	global_store_d16_hi_b16 v[21:22], v12, off                 // 0000004A3C20: DC960000 007C0C15
	global_store_d16_hi_b16 v[13:14], v32, off                 // 0000004A3C28: DC960000 007C200D
	global_store_d16_hi_b16 v[15:16], v30, off                 // 0000004A3C30: DC960000 007C1E0F
	global_store_d16_hi_b16 v[19:20], v29, off                 // 0000004A3C38: DC960000 007C1D13
	s_waitcnt lgkmcnt(1)                                       // 0000004A3C40: BF89FC17
	v_sub_f32_e32 v16, v23, v24                                // 0000004A3C44: 08203117
	s_waitcnt lgkmcnt(0)                                       // 0000004A3C48: BF89FC07
	v_dual_add_f32 v21, v23, v24 :: v_dual_sub_f32 v22, v25, v26// 0000004A3C4C: C90A3117 15163519
	v_add_f32_e32 v23, v25, v26                                // 0000004A3C54: 062E3519
	v_or_b32_e32 v14, 32, v34                                  // 0000004A3C58: 381C44A0
	.long 0xd73c000c                                           // 0000004A3C5C: D73C000C
	v_cndmask_b32_e32 v1, 1, v27, vcc_lo                       // 0000004A3C60: 02023681
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A3C64: BF870214
	v_dual_add_f32 v19, v16, v22 :: v_dual_lshlrev_b32 v28, 9, v11// 0000004A3C68: C9222D10 131C1689
	v_add_f32_e32 v20, v21, v23                                // 0000004A3C70: 06282F15
	.long 0xd7600000                                           // 0000004A3C74: D7600000
	v_cndmask_b32_e32 v0, v17, v135, vcc_lo                    // 0000004A3C78: 02010F11
	.long 0xd7600002                                           // 0000004A3C7C: D7600002
	v_cndmask_b32_e32 v0, v18, v135, vcc_lo                    // 0000004A3C80: 02010F12
	v_mad_i64_i32 v[14:15], null, v14, s12, 0                  // 0000004A3C84: D6FF7C0E 0200190E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004A3C8C: BF8701B4
	v_dual_mul_f32 v19, 0x3db504f3, v19 :: v_dual_mul_f32 v20, 0x3db504f3, v20// 0000004A3C90: C8C626FF 131428FF 3DB504F3
	v_dual_sub_f32 v16, v16, v22 :: v_dual_sub_f32 v21, v21, v23// 0000004A3C9C: C94A2D10 10142F15
	v_or_b32_e32 v24, 64, v34                                  // 0000004A3CA4: 383044C0
	v_dual_mul_f32 v25, s2, v19 :: v_dual_mul_f32 v26, s0, v20 // 0000004A3CA8: C8C62602 191A2800
	.long 0xd7600000                                           // 0000004A3CB0: D7600000
	v_cndmask_b32_e32 v0, v18, v151, vcc_lo                    // 0000004A3CB4: 02012F12
	.long 0x7f2c3981                                           // 0000004A3CB8: 7F2C3981
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 0000004A3CBC: 102020FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A3CC4: BF870004
	.long 0x7e023999                                           // 0000004A3CC8: 7E023999
	.long 0x7e2c399a                                           // 0000004A3CCC: 7E2C399A
	v_mul_f32_e32 v21, 0x3db504f3, v21                         // 0000004A3CD0: 102A2AFF 3DB504F3
	.long 0xd73c000e                                           // 0000004A3CD8: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000004A3CDC: 02021C81
	v_mad_i64_i32 v[19:20], null, v24, s12, 0                  // 0000004A3CE0: D6FF7C13 02001918
	v_mul_f32_e32 v16, s0, v16                                 // 0000004A3CE8: 10202000
	v_and_b32_e32 v22, 1, v22                                  // 0000004A3CEC: 362C2C81
	v_mul_f32_e32 v24, s3, v21                                 // 0000004A3CF0: 10302A03
	.long 0xd7600003                                           // 0000004A3CF4: D7600003
	v_cndmask_b32_e32 v0, v17, v152, vcc_lo                    // 0000004A3CF8: 02013111
	v_and_b32_e32 v23, 1, v1                                   // 0000004A3CFC: 362E0281
	.long 0xd7006a0c                                           // 0000004A3D00: D7006A0C
	v_cndmask_b32_e32 v1, v4, v12, vcc_lo                      // 0000004A3D04: 02021904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004A3D08: BF870221
	v_add_co_ci_u32_e64 v13, null, v8, v13, vcc_lo             // 0000004A3D0C: D5207C0D 01AA1B08
	.long 0xd7006a0e                                           // 0000004A3D14: D7006A0E
	v_cndmask_b32_e32 v1, v4, v14, vcc_lo                      // 0000004A3D18: 02021D04
	v_add3_u32 v23, v25, v23, 0x7fff                           // 0000004A3D1C: D6550017 03FE2F19 00007FFF
	v_add3_u32 v25, v26, v22, 0x7fff                           // 0000004A3D28: D6550019 03FE2D1A 00007FFF
	.long 0x7e023990                                           // 0000004A3D34: 7E023990
	v_xor_b32_e32 v27, v11, v3                                 // 0000004A3D38: 3A36070B
	v_add_co_ci_u32_e64 v15, null, v8, v15, vcc_lo             // 0000004A3D3C: D5207C0F 01AA1F08
	v_or_b32_e32 v21, 0x60, v34                                // 0000004A3D44: 382A44FF 00000060
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A3D4C: BF870004
	v_and_b32_e32 v29, 1, v1                                   // 0000004A3D50: 363A0281
	s_clause 0x1                                               // 0000004A3D54: BF850001
	global_store_d16_hi_b16 v[12:13], v25, off                 // 0000004A3D58: DC960000 007C190C
	global_store_d16_hi_b16 v[14:15], v23, off                 // 0000004A3D60: DC960000 007C170E
	v_lshl_add_u32 v15, v27, 2, v28                            // 0000004A3D68: D646000F 0471051B
	.long 0x7e343998                                           // 0000004A3D70: 7E343998
	v_mad_i64_i32 v[21:22], null, v21, s12, 0                  // 0000004A3D74: D6FF7C15 02001915
	.long 0x7f343981                                           // 0000004A3D7C: 7F343981
	v_add3_u32 v25, v16, v29, 0x7fff                           // 0000004A3D80: D6550019 03FE3B10 00007FFF
	ds_load_2addr_stride64_b32 v[13:14], v15 offset1:64        // 0000004A3D8C: D8E04000 0D00000F
	ds_load_2addr_stride64_b32 v[15:16], v15 offset0:128 offset1:192// 0000004A3D94: D8E0C080 0F00000F
	.long 0xd73c0013                                           // 0000004A3D9C: D73C0013
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000004A3DA0: 02022681
	v_and_b32_e32 v23, 1, v26                                  // 0000004A3DA4: 362E3481
	v_or_b32_e32 v26, s1, v11                                  // 0000004A3DA8: 38341601
	.long 0xd73c000b                                           // 0000004A3DAC: D73C000B
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 0000004A3DB0: 02022A81
	.long 0xd7600002                                           // 0000004A3DB4: D7600002
	v_cndmask_b32_e32 v0, v18, v136, vcc_lo                    // 0000004A3DB8: 02011112
	.long 0xd7600000                                           // 0000004A3DBC: D7600000
	v_cndmask_b32_e32 v0, v17, v136, vcc_lo                    // 0000004A3DC0: 02011111
	.long 0xd7006a13                                           // 0000004A3DC4: D7006A13
	v_cndmask_b32_e32 v1, v4, v19, vcc_lo                      // 0000004A3DC8: 02022704
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004A3DCC: BF870001
	v_add_co_ci_u32_e64 v20, null, v8, v20, vcc_lo             // 0000004A3DD0: D5207C14 01AA2908
	v_add3_u32 v23, v24, v23, 0x7fff                           // 0000004A3DD8: D6550017 03FE2F18 00007FFF
	.long 0xd7006a0b                                           // 0000004A3DE4: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000004A3DE8: 02021704
	v_mad_i64_i32 v[21:22], null, v26, s12, 0                  // 0000004A3DEC: D6FF7C15 0200191A
	v_add_co_ci_u32_e64 v12, null, v8, v12, vcc_lo             // 0000004A3DF4: D5207C0C 01AA1908
	global_store_d16_hi_b16 v[19:20], v23, off                 // 0000004A3DFC: DC960000 007C1713
	v_or_b32_e32 v23, 32, v26                                  // 0000004A3E04: 382E34A0
	v_or_b32_e32 v24, 64, v26                                  // 0000004A3E08: 383034C0
	global_store_d16_hi_b16 v[11:12], v25, off                 // 0000004A3E0C: DC960000 007C190B
	s_waitcnt lgkmcnt(0)                                       // 0000004A3E14: BF89FC07
	v_sub_f32_e32 v25, v15, v16                                // 0000004A3E18: 0832210F
	.long 0xd73c0013                                           // 0000004A3E1C: D73C0013
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 0000004A3E20: 02022A81
	v_mad_i64_i32 v[11:12], null, v23, s12, 0                  // 0000004A3E24: D6FF7C0B 02001917
	v_sub_f32_e32 v23, v13, v14                                // 0000004A3E2C: 082E1D0D
	v_mad_i64_i32 v[21:22], null, v24, s12, 0                  // 0000004A3E30: D6FF7C15 02001918
	v_dual_add_f32 v24, v13, v14 :: v_dual_add_f32 v15, v15, v16// 0000004A3E38: C9081D0D 180E210F
	.long 0x7f3a3981                                           // 0000004A3E40: 7F3A3981
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004A3E44: BF870244
	v_add_f32_e32 v16, v23, v25                                // 0000004A3E48: 06203317
	.long 0xd7006a13                                           // 0000004A3E4C: D7006A13
	v_cndmask_b32_e32 v1, v4, v19, vcc_lo                      // 0000004A3E50: 02022704
	.long 0xd73c000b                                           // 0000004A3E54: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000004A3E58: 02021681
	.long 0xd73c000d                                           // 0000004A3E5C: D73C000D
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 0000004A3E60: 02022A81
	v_dual_add_f32 v21, v24, v15 :: v_dual_mul_f32 v16, 0x3db504f3, v16// 0000004A3E64: C9061F18 151020FF 3DB504F3
	v_sub_f32_e32 v15, v24, v15                                // 0000004A3E70: 081E1F18
	v_xor_b32_e32 v24, v10, v3                                 // 0000004A3E74: 3A30070A
	v_add_co_ci_u32_e64 v20, null, v8, v20, vcc_lo             // 0000004A3E78: D5207C14 01AA2908
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A3E80: BF870214
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_mul_f32 v22, s2, v16// 0000004A3E84: C8C62AFF 15162002 3DB504F3
	v_dual_mul_f32 v15, 0x3db504f3, v15 :: v_dual_sub_f32 v16, v23, v25// 0000004A3E90: C8CA1EFF 0F103317 3DB504F3
	.long 0xd7006a0b                                           // 0000004A3E9C: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000004A3EA0: 02021704
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A3EA4: BF870213
	v_mul_f32_e32 v25, s0, v21                                 // 0000004A3EA8: 10322A00
	.long 0x7e023996                                           // 0000004A3EAC: 7E023996
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A3EB0: BF870004
	v_mul_f32_e32 v28, s3, v15                                 // 0000004A3EB4: 10381E03
	v_or_b32_e32 v15, 0x60, v26                                // 0000004A3EB8: 381E34FF 00000060
	v_lshlrev_b32_e32 v26, 9, v10                              // 0000004A3EC0: 30341489
	.long 0xd7600000                                           // 0000004A3EC4: D7600000
	v_cndmask_b32_e32 v0, v18, v152, vcc_lo                    // 0000004A3EC8: 02013112
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 0000004A3ECC: 102020FF 3DB504F3
	.long 0x7e2a3999                                           // 0000004A3ED4: 7E2A3999
	.long 0x7f2a3981                                           // 0000004A3ED8: 7F2A3981
	v_and_b32_e32 v23, 1, v1                                   // 0000004A3EDC: 362E0281
	v_lshl_add_u32 v24, v24, 2, v26                            // 0000004A3EE0: D6460018 04690518
	v_mul_f32_e32 v27, s0, v16                                 // 0000004A3EE8: 10362000
	v_mad_i64_i32 v[15:16], null, v15, s12, 0                  // 0000004A3EEC: D6FF7C0F 0200190F
	v_and_b32_e32 v26, 1, v21                                  // 0000004A3EF4: 36342A81
	v_add3_u32 v30, v22, v23, 0x7fff                           // 0000004A3EF8: D655001E 03FE2F16 00007FFF
	ds_load_2addr_stride64_b32 v[21:22], v24 offset1:64        // 0000004A3F04: D8E04000 15000018
	ds_load_2addr_stride64_b32 v[23:24], v24 offset0:128 offset1:192// 0000004A3F0C: D8E0C080 17000018
	.long 0x7e3a399c                                           // 0000004A3F14: 7E3A399C
	.long 0x7e02399b                                           // 0000004A3F18: 7E02399B
	v_add_co_ci_u32_e64 v12, null, v8, v12, vcc_lo             // 0000004A3F1C: D5207C0C 01AA1908
	.long 0xd73c000f                                           // 0000004A3F24: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000004A3F28: 02021E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A3F2C: BF870214
	v_and_b32_e32 v29, 1, v29                                  // 0000004A3F30: 363A3A81
	v_and_b32_e32 v31, 1, v1                                   // 0000004A3F34: 363E0281
	.long 0xd7006a0d                                           // 0000004A3F38: D7006A0D
	v_cndmask_b32_e32 v1, v4, v13, vcc_lo                      // 0000004A3F3C: 02021B04
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004A3F40: BF870001
	v_add_co_ci_u32_e64 v14, null, v8, v14, vcc_lo             // 0000004A3F44: D5207C0E 01AA1D08
	.long 0xd7006a0f                                           // 0000004A3F4C: D7006A0F
	v_cndmask_b32_e32 v1, v4, v15, vcc_lo                      // 0000004A3F50: 02021F04
	v_or_b32_e32 v32, s1, v10                                  // 0000004A3F54: 38401401
	v_add3_u32 v10, v25, v26, 0x7fff                           // 0000004A3F58: D655000A 03FE3519 00007FFF
	v_add3_u32 v28, v28, v29, 0x7fff                           // 0000004A3F64: D655001C 03FE3B1C 00007FFF
	v_add3_u32 v27, v27, v31, 0x7fff                           // 0000004A3F70: D655001B 03FE3F1B 00007FFF
	v_add_co_ci_u32_e64 v16, null, v8, v16, vcc_lo             // 0000004A3F7C: D5207C10 01AA2108
	s_clause 0x3                                               // 0000004A3F84: BF850003
	global_store_d16_hi_b16 v[19:20], v10, off                 // 0000004A3F88: DC960000 007C0A13
	global_store_d16_hi_b16 v[11:12], v30, off                 // 0000004A3F90: DC960000 007C1E0B
	global_store_d16_hi_b16 v[13:14], v28, off                 // 0000004A3F98: DC960000 007C1C0D
	global_store_d16_hi_b16 v[15:16], v27, off                 // 0000004A3FA0: DC960000 007C1B0F
	s_waitcnt lgkmcnt(1)                                       // 0000004A3FA8: BF89FC17
	v_sub_f32_e32 v16, v21, v22                                // 0000004A3FAC: 08202D15
	s_waitcnt lgkmcnt(0)                                       // 0000004A3FB0: BF89FC07
	v_dual_add_f32 v19, v21, v22 :: v_dual_sub_f32 v20, v23, v24// 0000004A3FB4: C90A2D15 13143117
	v_add_f32_e32 v21, v23, v24                                // 0000004A3FBC: 062A3117
	v_or_b32_e32 v12, 32, v32                                  // 0000004A3FC0: 381840A0
	.long 0xd7600000                                           // 0000004A3FC4: D7600000
	v_cndmask_b32_e32 v0, v17, v137, vcc_lo                    // 0000004A3FC8: 02011311
	.long 0xd7600002                                           // 0000004A3FCC: D7600002
	v_cndmask_b32_e32 v0, v18, v137, vcc_lo                    // 0000004A3FD0: 02011312
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004A3FD4: BF8701B4
	v_dual_add_f32 v14, v16, v20 :: v_dual_add_f32 v15, v19, v21// 0000004A3FD8: C9082910 0E0E2B13
	v_mad_i64_i32 v[25:26], null, v32, s12, 0                  // 0000004A3FE0: D6FF7C19 02001920
	v_mad_i64_i32 v[12:13], null, v12, s12, 0                  // 0000004A3FE8: D6FF7C0C 0200190C
	v_dual_sub_f32 v19, v19, v21 :: v_dual_mul_f32 v14, 0x3db504f3, v14// 0000004A3FF0: C9462B13 130E1CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004A3FFC: BF8701B4
	v_dual_mul_f32 v15, 0x3db504f3, v15 :: v_dual_sub_f32 v16, v16, v20// 0000004A4000: C8CA1EFF 0F102910 3DB504F3
	.long 0x7f283981                                           // 0000004A400C: 7F283981
	v_or_b32_e32 v22, 64, v32                                  // 0000004A4010: 382C40C0
	v_dual_mul_f32 v23, s2, v14 :: v_dual_mul_f32 v24, s0, v15 // 0000004A4014: C8C61C02 17181E00
	.long 0xd73c000a                                           // 0000004A401C: D73C000A
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 0000004A4020: 02023281
	.long 0xd7600003                                           // 0000004A4024: D7600003
	v_cndmask_b32_e32 v0, v17, v153, vcc_lo                    // 0000004A4028: 02013311
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 0000004A402C: 102626FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004A4034: BF870244
	.long 0x7e023997                                           // 0000004A4038: 7E023997
	.long 0x7e283998                                           // 0000004A403C: 7E283998
	.long 0xd73c000c                                           // 0000004A4040: D73C000C
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000004A4044: 02021881
	.long 0xd7006a0a                                           // 0000004A4048: D7006A0A
	v_cndmask_b32_e32 v1, v4, v10, vcc_lo                      // 0000004A404C: 02021504
	v_and_b32_e32 v21, 1, v1                                   // 0000004A4050: 362A0281
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A4054: BF870004
	v_and_b32_e32 v20, 1, v20                                  // 0000004A4058: 36282881
	v_mad_i64_i32 v[14:15], null, v22, s12, 0                  // 0000004A405C: D6FF7C0E 02001916
	v_mul_f32_e32 v22, s3, v19                                 // 0000004A4064: 102C2603
	v_or_b32_e32 v19, 0x60, v32                                // 0000004A4068: 382640FF 00000060
	v_add_co_ci_u32_e64 v11, null, v8, v11, vcc_lo             // 0000004A4070: D5207C0B 01AA1708
	.long 0xd7006a0c                                           // 0000004A4078: D7006A0C
	v_cndmask_b32_e32 v1, v4, v12, vcc_lo                      // 0000004A407C: 02021904
	v_add3_u32 v21, v23, v21, 0x7fff                           // 0000004A4080: D6550015 03FE2B17 00007FFF
	v_add3_u32 v23, v24, v20, 0x7fff                           // 0000004A408C: D6550017 03FE2918 00007FFF
	v_xor_b32_e32 v25, v9, v3                                  // 0000004A4098: 3A320709
	v_lshlrev_b32_e32 v26, 9, v9                               // 0000004A409C: 30341289
	v_add_co_ci_u32_e64 v13, null, v8, v13, vcc_lo             // 0000004A40A0: D5207C0D 01AA1B08
	.long 0xd7600000                                           // 0000004A40A8: D7600000
	v_cndmask_b32_e32 v0, v18, v153, vcc_lo                    // 0000004A40AC: 02013312
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 0000004A40B0: 102020FF 3DB504F3
	v_mad_i64_i32 v[19:20], null, v19, s12, 0                  // 0000004A40B8: D6FF7C13 02001913
	s_clause 0x1                                               // 0000004A40C0: BF850001
	global_store_d16_hi_b16 v[10:11], v23, off                 // 0000004A40C4: DC960000 007C170A
	global_store_d16_hi_b16 v[12:13], v21, off                 // 0000004A40CC: DC960000 007C150C
	v_lshl_add_u32 v13, v25, 2, v26                            // 0000004A40D4: D646000D 04690519
	.long 0x7e303996                                           // 0000004A40DC: 7E303996
	v_mul_f32_e32 v16, s0, v16                                 // 0000004A40E0: 10202000
	.long 0x7f303981                                           // 0000004A40E4: 7F303981
	.long 0xd73c000e                                           // 0000004A40E8: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000004A40EC: 02021C81
	v_or_b32_e32 v23, s1, v9                                   // 0000004A40F0: 382E1201
	.long 0xd73c0009                                           // 0000004A40F4: D73C0009
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000004A40F8: 02022681
	ds_load_2addr_stride64_b32 v[11:12], v13 offset1:64        // 0000004A40FC: D8E04000 0B00000D
	ds_load_2addr_stride64_b32 v[19:20], v13 offset0:128 offset1:192// 0000004A4104: D8E0C080 1300000D
	.long 0x7e023990                                           // 0000004A410C: 7E023990
	v_and_b32_e32 v21, 1, v24                                  // 0000004A4110: 362A3081
	.long 0xd7006a0e                                           // 0000004A4114: D7006A0E
	v_cndmask_b32_e32 v1, v4, v14, vcc_lo                      // 0000004A4118: 02021D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A411C: BF870211
	v_add_co_ci_u32_e64 v15, null, v8, v15, vcc_lo             // 0000004A4120: D5207C0F 01AA1F08
	v_and_b32_e32 v27, 1, v1                                   // 0000004A4128: 36360281
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004A412C: BF870234
	v_add3_u32 v24, v22, v21, 0x7fff                           // 0000004A4130: D6550018 03FE2B16 00007FFF
	.long 0xd7006a09                                           // 0000004A413C: D7006A09
	v_cndmask_b32_e32 v1, v4, v9, vcc_lo                       // 0000004A4140: 02021304
	v_mad_i64_i32 v[21:22], null, v23, s12, 0                  // 0000004A4144: D6FF7C15 02001917
	v_add3_u32 v16, v16, v27, 0x7fff                           // 0000004A414C: D6550010 03FE3710 00007FFF
	v_add_co_ci_u32_e64 v10, null, v8, v10, vcc_lo             // 0000004A4158: D5207C0A 01AA1508
	global_store_d16_hi_b16 v[14:15], v24, off                 // 0000004A4160: DC960000 007C180E
	v_or_b32_e32 v15, 32, v23                                  // 0000004A4168: 381E2EA0
	v_or_b32_e32 v24, 64, v23                                  // 0000004A416C: 38302EC0
	global_store_d16_hi_b16 v[9:10], v16, off                  // 0000004A4170: DC960000 007C1009
	.long 0xd73c000d                                           // 0000004A4178: D73C000D
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 0000004A417C: 02022A81
	s_waitcnt lgkmcnt(1)                                       // 0000004A4180: BF89FC17
	v_sub_f32_e32 v21, v11, v12                                // 0000004A4184: 082A190B
	v_mad_i64_i32 v[9:10], null, v15, s12, 0                   // 0000004A4188: D6FF7C09 0200190F
	v_mad_i64_i32 v[15:16], null, v24, s12, 0                  // 0000004A4190: D6FF7C0F 02001918
	s_waitcnt lgkmcnt(0)                                       // 0000004A4198: BF89FC07
	v_sub_f32_e32 v24, v19, v20                                // 0000004A419C: 08302913
	v_add_f32_e32 v22, v11, v12                                // 0000004A41A0: 062C190B
	v_add_f32_e32 v19, v19, v20                                // 0000004A41A4: 06262913
	.long 0xd7600002                                           // 0000004A41A8: D7600002
	v_cndmask_b32_e32 v0, v18, v138, vcc_lo                    // 0000004A41AC: 02011512
	.long 0xd7600000                                           // 0000004A41B0: D7600000
	v_cndmask_b32_e32 v0, v17, v138, vcc_lo                    // 0000004A41B4: 02011511
	.long 0xd7600003                                           // 0000004A41B8: D7600003
	v_cndmask_b32_e32 v0, v17, v154, vcc_lo                    // 0000004A41BC: 02013511
	.long 0xd73c0009                                           // 0000004A41C0: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000004A41C4: 02021281
	.long 0xd73c000b                                           // 0000004A41C8: D73C000B
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000004A41CC: 02021E81
	v_dual_add_f32 v15, v21, v24 :: v_dual_add_f32 v16, v22, v19// 0000004A41D0: C9083115 0F102716
	v_sub_f32_e32 v19, v22, v19                                // 0000004A41D8: 08262716
	v_xor_b32_e32 v22, v7, v3                                  // 0000004A41DC: 3A2C0707
	.long 0x7f363981                                           // 0000004A41E0: 7F363981
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004A41E4: BF8700A4
	v_dual_mul_f32 v15, 0x3db504f3, v15 :: v_dual_mul_f32 v16, 0x3db504f3, v16// 0000004A41E8: C8C61EFF 0F1020FF 3DB504F3
	.long 0xd7006a0d                                           // 0000004A41F4: D7006A0D
	v_cndmask_b32_e32 v1, v4, v13, vcc_lo                      // 0000004A41F8: 02021B04
	v_add_co_ci_u32_e64 v14, null, v8, v14, vcc_lo             // 0000004A41FC: D5207C0E 01AA1D08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A4204: BF870213
	v_dual_mul_f32 v20, s2, v15 :: v_dual_sub_f32 v15, v21, v24// 0000004A4208: C8CA1E02 140E3115
	v_mul_f32_e32 v24, s0, v16                                 // 0000004A4210: 10302000
	.long 0xd7600000                                           // 0000004A4214: D7600000
	v_cndmask_b32_e32 v0, v18, v154, vcc_lo                    // 0000004A4218: 02013512
	v_mul_f32_e32 v16, 0x3db504f3, v19                         // 0000004A421C: 102026FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004A4224: BF870244
	.long 0x7e023994                                           // 0000004A4228: 7E023994
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 0000004A422C: 101E1EFF 3DB504F3
	.long 0x7e263998                                           // 0000004A4234: 7E263998
	.long 0x7f263981                                           // 0000004A4238: 7F263981
	v_dual_mul_f32 v26, s3, v16 :: v_dual_and_b32 v21, 1, v1   // 0000004A423C: C8E42003 1A140281
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004A4244: BF870234
	v_mul_f32_e32 v25, s0, v15                                 // 0000004A4248: 10321E00
	v_or_b32_e32 v15, 0x60, v23                                // 0000004A424C: 381E2EFF 00000060
	v_lshlrev_b32_e32 v23, 9, v7                               // 0000004A4254: 302E0E89
	.long 0x7e36399a                                           // 0000004A4258: 7E36399A
	v_add3_u32 v28, v20, v21, 0x7fff                           // 0000004A425C: D655001C 03FE2B14 00007FFF
	.long 0x7e023999                                           // 0000004A4268: 7E023999
	v_mad_i64_i32 v[15:16], null, v15, s12, 0                  // 0000004A426C: D6FF7C0F 0200190F
	v_lshl_add_u32 v22, v22, 2, v23                            // 0000004A4274: D6460016 045D0516
	v_and_b32_e32 v23, 1, v19                                  // 0000004A427C: 362E2681
	ds_load_2addr_stride64_b32 v[19:20], v22 offset1:64        // 0000004A4280: D8E04000 13000016
	ds_load_2addr_stride64_b32 v[21:22], v22 offset0:128 offset1:192// 0000004A4288: D8E0C080 15000016
	.long 0xd7006a09                                           // 0000004A4290: D7006A09
	v_cndmask_b32_e32 v1, v4, v9, vcc_lo                       // 0000004A4294: 02021304
	.long 0xd73c000f                                           // 0000004A4298: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000004A429C: 02021E81
	v_and_b32_e32 v27, 1, v27                                  // 0000004A42A0: 36363681
	v_and_b32_e32 v29, 1, v1                                   // 0000004A42A4: 363A0281
	v_add_co_ci_u32_e64 v10, null, v8, v10, vcc_lo             // 0000004A42A8: D5207C0A 01AA1508
	.long 0xd7006a0b                                           // 0000004A42B0: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000004A42B4: 02021704
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004A42B8: BF870001
	v_add_co_ci_u32_e64 v12, null, v8, v12, vcc_lo             // 0000004A42BC: D5207C0C 01AA1908
	.long 0xd7006a0f                                           // 0000004A42C4: D7006A0F
	v_cndmask_b32_e32 v1, v4, v15, vcc_lo                      // 0000004A42C8: 02021F04
	v_or_b32_e32 v7, s1, v7                                    // 0000004A42CC: 380E0E01
	v_add3_u32 v30, v24, v23, 0x7fff                           // 0000004A42D0: D655001E 03FE2F18 00007FFF
	v_add3_u32 v26, v26, v27, 0x7fff                           // 0000004A42DC: D655001A 03FE371A 00007FFF
	v_add3_u32 v25, v25, v29, 0x7fff                           // 0000004A42E8: D6550019 03FE3B19 00007FFF
	v_add_co_ci_u32_e64 v16, null, v8, v16, vcc_lo             // 0000004A42F4: D5207C10 01AA2108
	s_clause 0x1                                               // 0000004A42FC: BF850001
	global_store_d16_hi_b16 v[13:14], v30, off                 // 0000004A4300: DC960000 007C1E0D
	global_store_d16_hi_b16 v[9:10], v28, off                  // 0000004A4308: DC960000 007C1C09
	v_or_b32_e32 v13, 32, v7                                   // 0000004A4310: 381A0EA0
	s_clause 0x1                                               // 0000004A4314: BF850001
	global_store_d16_hi_b16 v[11:12], v26, off                 // 0000004A4318: DC960000 007C1A0B
	global_store_d16_hi_b16 v[15:16], v25, off                 // 0000004A4320: DC960000 007C190F
	s_waitcnt lgkmcnt(1)                                       // 0000004A4328: BF89FC17
	v_sub_f32_e32 v15, v19, v20                                // 0000004A432C: 081E2913
	s_waitcnt lgkmcnt(0)                                       // 0000004A4330: BF89FC07
	v_dual_add_f32 v16, v19, v20 :: v_dual_sub_f32 v19, v21, v22// 0000004A4334: C90A2913 10122D15
	v_add_f32_e32 v20, v21, v22                                // 0000004A433C: 06282D15
	v_mad_i64_i32 v[11:12], null, v13, s12, 0                  // 0000004A4340: D6FF7C0B 0200190D
	v_mad_i64_i32 v[23:24], null, v7, s12, 0                   // 0000004A4348: D6FF7C17 02001907
	.long 0xd7600000                                           // 0000004A4350: D7600000
	v_cndmask_b32_e32 v0, v17, v139, vcc_lo                    // 0000004A4354: 02011711
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004A4358: BF870244
	v_dual_add_f32 v13, v15, v19 :: v_dual_add_f32 v14, v16, v20// 0000004A435C: C908270F 0D0E2910
	.long 0xd7600002                                           // 0000004A4364: D7600002
	v_cndmask_b32_e32 v0, v18, v139, vcc_lo                    // 0000004A4368: 02011712
	v_sub_f32_e32 v16, v16, v20                                // 0000004A436C: 08202910
	v_or_b32_e32 v28, s1, v5                                   // 0000004A4370: 38380A01
	v_dual_mul_f32 v13, 0x3db504f3, v13 :: v_dual_mul_f32 v14, 0x3db504f3, v14// 0000004A4374: C8C61AFF 0D0E1CFF 3DB504F3
	.long 0xd73c0009                                           // 0000004A4380: D73C0009
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000004A4384: 02022E81
	v_sub_f32_e32 v15, v15, v19                                // 0000004A4388: 081E270F
	v_or_b32_e32 v21, 64, v7                                   // 0000004A438C: 382A0EC0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004A4390: BF870244
	v_dual_mul_f32 v22, s2, v13 :: v_dual_mul_f32 v23, s0, v14 // 0000004A4394: C8C61A02 16161C00
	.long 0xd7600003                                           // 0000004A439C: D7600003
	v_cndmask_b32_e32 v0, v17, v155, vcc_lo                    // 0000004A43A0: 02013711
	.long 0xd7600000                                           // 0000004A43A4: D7600000
	v_cndmask_b32_e32 v0, v18, v155, vcc_lo                    // 0000004A43A8: 02013712
	.long 0x7f263981                                           // 0000004A43AC: 7F263981
	.long 0x7e023996                                           // 0000004A43B0: 7E023996
	.long 0x7e263997                                           // 0000004A43B4: 7E263997
	v_dual_mul_f32 v15, 0x3db504f3, v15 :: v_dual_mul_f32 v16, 0x3db504f3, v16// 0000004A43B8: C8C61EFF 0F1020FF 3DB504F3
	.long 0xd73c000b                                           // 0000004A43C4: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000004A43C8: 02021681
	v_mad_i64_i32 v[13:14], null, v21, s12, 0                  // 0000004A43CC: D6FF7C0D 02001915
	v_and_b32_e32 v20, 1, v1                                   // 0000004A43D4: 36280281
	v_and_b32_e32 v19, 1, v19                                  // 0000004A43D8: 36262681
	v_dual_mul_f32 v21, s0, v15 :: v_dual_mul_f32 v24, s3, v16 // 0000004A43DC: C8C61E00 15182003
	.long 0xd7006a09                                           // 0000004A43E4: D7006A09
	v_cndmask_b32_e32 v1, v4, v9, vcc_lo                       // 0000004A43E8: 02021304
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004A43EC: BF870001
	v_add_co_ci_u32_e64 v10, null, v8, v10, vcc_lo             // 0000004A43F0: D5207C0A 01AA1508
	.long 0xd7006a0b                                           // 0000004A43F8: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000004A43FC: 02021704
	v_add3_u32 v20, v22, v20, 0x7fff                           // 0000004A4400: D6550014 03FE2916 00007FFF
	v_add3_u32 v19, v23, v19, 0x7fff                           // 0000004A440C: D6550013 03FE2717 00007FFF
	.long 0x7e023995                                           // 0000004A4418: 7E023995
	v_or_b32_e32 v7, 0x60, v7                                  // 0000004A441C: 380E0EFF 00000060
	.long 0x7e2c3998                                           // 0000004A4424: 7E2C3998
	.long 0x7f2c3981                                           // 0000004A4428: 7F2C3981
	v_xor_b32_e32 v23, v6, v3                                  // 0000004A442C: 3A2E0706
	v_lshlrev_b32_e32 v25, 9, v6                               // 0000004A4430: 30320C89
	v_add_co_ci_u32_e64 v12, null, v8, v12, vcc_lo             // 0000004A4434: D5207C0C 01AA1908
	v_mad_i64_i32 v[15:16], null, v7, s12, 0                   // 0000004A443C: D6FF7C0F 02001907
	v_and_b32_e32 v7, 1, v1                                    // 0000004A4444: 360E0281
	s_clause 0x1                                               // 0000004A4448: BF850001
	global_store_d16_hi_b16 v[9:10], v19, off                  // 0000004A444C: DC960000 007C1309
	global_store_d16_hi_b16 v[11:12], v20, off                 // 0000004A4454: DC960000 007C140B
	v_lshl_add_u32 v11, v23, 2, v25                            // 0000004A445C: D646000B 04650517
	v_and_b32_e32 v12, 1, v22                                  // 0000004A4464: 36182C81
	.long 0xd73c000d                                           // 0000004A4468: D73C000D
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000004A446C: 02021A81
	v_add3_u32 v19, v21, v7, 0x7fff                            // 0000004A4470: D6550013 03FE0F15 00007FFF
	v_or_b32_e32 v20, s1, v6                                   // 0000004A447C: 38280C01
	ds_load_2addr_stride64_b32 v[9:10], v11 offset1:64         // 0000004A4480: D8E04000 0900000B
	v_add3_u32 v21, v24, v12, 0x7fff                           // 0000004A4488: D6550015 03FE1918 00007FFF
	ds_load_2addr_stride64_b32 v[11:12], v11 offset0:128 offset1:192// 0000004A4494: D8E0C080 0B00000B
	.long 0xd73c0006                                           // 0000004A449C: D73C0006
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000004A44A0: 02021E81
	.long 0xd7006a0d                                           // 0000004A44A4: D7006A0D
	v_cndmask_b32_e32 v1, v4, v13, vcc_lo                      // 0000004A44A8: 02021B04
	v_mad_i64_i32 v[15:16], null, v20, s12, 0                  // 0000004A44AC: D6FF7C0F 02001914
	v_add_co_ci_u32_e64 v14, null, v8, v14, vcc_lo             // 0000004A44B4: D5207C0E 01AA1D08
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004A44BC: BF870094
	.long 0xd7006a06                                           // 0000004A44C0: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000004A44C4: 02020D04
	v_add_co_ci_u32_e64 v7, null, v8, v7, vcc_lo               // 0000004A44C8: D5207C07 01AA0F08
	v_or_b32_e32 v22, 64, v20                                  // 0000004A44D0: 382C28C0
	global_store_d16_hi_b16 v[13:14], v21, off                 // 0000004A44D4: DC960000 007C150D
	v_or_b32_e32 v21, 32, v20                                  // 0000004A44DC: 382A28A0
	.long 0xd73c000d                                           // 0000004A44E0: D73C000D
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000004A44E4: 02021E81
	global_store_d16_hi_b16 v[6:7], v19, off                   // 0000004A44E8: DC960000 007C1306
	v_mad_i64_i32 v[15:16], null, v22, s12, 0                  // 0000004A44F0: D6FF7C0F 02001916
	.long 0xd7600002                                           // 0000004A44F8: D7600002
	v_cndmask_b32_e32 v0, v18, v140, vcc_lo                    // 0000004A44FC: 02011912
	s_waitcnt lgkmcnt(1)                                       // 0000004A4500: BF89FC17
	v_sub_f32_e32 v19, v9, v10                                 // 0000004A4504: 08261509
	v_mad_i64_i32 v[6:7], null, v21, s12, 0                    // 0000004A4508: D6FF7C06 02001915
	s_waitcnt lgkmcnt(0)                                       // 0000004A4510: BF89FC07
	v_dual_sub_f32 v22, v11, v12 :: v_dual_add_f32 v21, v9, v10// 0000004A4514: C948190B 16141509
	v_add_f32_e32 v11, v11, v12                                // 0000004A451C: 0616190B
	.long 0xd7600000                                           // 0000004A4520: D7600000
	v_cndmask_b32_e32 v0, v17, v140, vcc_lo                    // 0000004A4524: 02011911
	.long 0xd73c0009                                           // 0000004A4528: D73C0009
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000004A452C: 02021E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004A4530: BF870244
	v_add_f32_e32 v12, v19, v22                                // 0000004A4534: 06182D13
	.long 0xd7600003                                           // 0000004A4538: D7600003
	v_cndmask_b32_e32 v0, v17, v156, vcc_lo                    // 0000004A453C: 02013911
	v_add_f32_e32 v15, v21, v11                                // 0000004A4540: 061E1715
	v_dual_sub_f32 v11, v21, v11 :: v_dual_lshlrev_b32 v24, 9, v5// 0000004A4544: C9621715 0B180A89
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 0000004A454C: 101818FF 3DB504F3
	.long 0xd73c0006                                           // 0000004A4554: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000004A4558: 02020C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A455C: BF870214
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 0000004A4560: 101E1EFF 3DB504F3
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 0000004A4568: 101616FF 3DB504F3
	.long 0x7f323981                                           // 0000004A4570: 7F323981
	v_mul_f32_e32 v16, s2, v12                                 // 0000004A4574: 10201802
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A4578: BF870214
	v_dual_sub_f32 v12, v19, v22 :: v_dual_mul_f32 v21, s0, v15// 0000004A457C: C9462D13 0C141E00
	v_mul_f32_e32 v23, s3, v11                                 // 0000004A4584: 102E1603
	v_or_b32_e32 v11, 0x60, v20                                // 0000004A4588: 381628FF 00000060
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A4590: BF870004
	.long 0x7e023990                                           // 0000004A4594: 7E023990
	v_xor_b32_e32 v20, v5, v3                                  // 0000004A4598: 3A280705
	.long 0xd7600000                                           // 0000004A459C: D7600000
	v_cndmask_b32_e32 v0, v18, v156, vcc_lo                    // 0000004A45A0: 02013912
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 0000004A45A4: 101818FF 3DB504F3
	.long 0x7e1e3995                                           // 0000004A45AC: 7E1E3995
	.long 0x7f1e3981                                           // 0000004A45B0: 7F1E3981
	v_and_b32_e32 v19, 1, v1                                   // 0000004A45B4: 36260281
	v_lshl_add_u32 v20, v20, 2, v24                            // 0000004A45B8: D6460014 04610514
	v_mul_f32_e32 v22, s0, v12                                 // 0000004A45C0: 102C1800
	v_mad_i64_i32 v[11:12], null, v11, s12, 0                  // 0000004A45C4: D6FF7C0B 0200190B
	v_and_b32_e32 v24, 1, v15                                  // 0000004A45CC: 36301E81
	v_add3_u32 v26, v16, v19, 0x7fff                           // 0000004A45D0: D655001A 03FE2710 00007FFF
	ds_load_2addr_stride64_b32 v[15:16], v20 offset1:64        // 0000004A45DC: D8E04000 0F000014
	ds_load_2addr_stride64_b32 v[19:20], v20 offset0:128 offset1:192// 0000004A45E4: D8E0C080 13000014
	.long 0x7e323997                                           // 0000004A45EC: 7E323997
	.long 0x7e023996                                           // 0000004A45F0: 7E023996
	.long 0xd7006a0d                                           // 0000004A45F4: D7006A0D
	v_cndmask_b32_e32 v1, v4, v13, vcc_lo                      // 0000004A45F8: 02021B04
	.long 0xd73c000b                                           // 0000004A45FC: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000004A4600: 02021681
	v_add_co_ci_u32_e64 v14, null, v8, v14, vcc_lo             // 0000004A4604: D5207C0E 01AA1D08
	.long 0xd7006a06                                           // 0000004A460C: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000004A4610: 02020D04
	v_and_b32_e32 v25, 1, v25                                  // 0000004A4614: 36323281
	v_add3_u32 v5, v21, v24, 0x7fff                            // 0000004A4618: D6550005 03FE3115 00007FFF
	v_add_co_ci_u32_e64 v7, null, v8, v7, vcc_lo               // 0000004A4624: D5207C07 01AA0F08
	v_and_b32_e32 v27, 1, v1                                   // 0000004A462C: 36360281
	.long 0xd7006a09                                           // 0000004A4630: D7006A09
	v_cndmask_b32_e32 v1, v4, v9, vcc_lo                       // 0000004A4634: 02021304
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004A4638: BF870001
	v_add_co_ci_u32_e64 v10, null, v8, v10, vcc_lo             // 0000004A463C: D5207C0A 01AA1508
	.long 0xd7006a0b                                           // 0000004A4644: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000004A4648: 02021704
	v_add3_u32 v23, v23, v25, 0x7fff                           // 0000004A464C: D6550017 03FE3317 00007FFF
	s_clause 0x1                                               // 0000004A4658: BF850001
	global_store_d16_hi_b16 v[13:14], v5, off                  // 0000004A465C: DC960000 007C050D
	global_store_d16_hi_b16 v[6:7], v26, off                   // 0000004A4664: DC960000 007C1A06
	v_add_nc_u32_e32 v7, 32, v28                               // 0000004A466C: 4A0E38A0
	v_add3_u32 v24, v22, v27, 0x7fff                           // 0000004A4670: D6550018 03FE3716 00007FFF
	v_add_co_ci_u32_e64 v12, null, v8, v12, vcc_lo             // 0000004A467C: D5207C0C 01AA1908
	s_clause 0x1                                               // 0000004A4684: BF850001
	global_store_d16_hi_b16 v[9:10], v23, off                  // 0000004A4688: DC960000 007C1709
	global_store_d16_hi_b16 v[11:12], v24, off                 // 0000004A4690: DC960000 007C180B
	v_mad_i64_i32 v[9:10], null, v7, s12, 0                    // 0000004A4698: D6FF7C09 02001907
	s_waitcnt lgkmcnt(1)                                       // 0000004A46A0: BF89FC17
	v_sub_f32_e32 v7, v15, v16                                 // 0000004A46A4: 080E210F
	v_add_f32_e32 v13, v15, v16                                // 0000004A46A8: 061A210F
	s_waitcnt lgkmcnt(0)                                       // 0000004A46AC: BF89FC07
	v_sub_f32_e32 v14, v19, v20                                // 0000004A46B0: 081C2913
	v_add_f32_e32 v15, v19, v20                                // 0000004A46B4: 061E2913
	v_mad_i64_i32 v[21:22], null, v28, s12, 0                  // 0000004A46B8: D6FF7C15 0200191C
	.long 0xd7600000                                           // 0000004A46C0: D7600000
	v_cndmask_b32_e32 v0, v17, v141, vcc_lo                    // 0000004A46C4: 02011B11
	.long 0xd7600002                                           // 0000004A46C8: D7600002
	v_cndmask_b32_e32 v0, v18, v141, vcc_lo                    // 0000004A46CC: 02011B12
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004A46D0: BF8701B4
	v_dual_add_f32 v16, v7, v14 :: v_dual_add_f32 v19, v13, v15// 0000004A46D4: C9081D07 10121F0D
	v_sub_f32_e32 v13, v13, v15                                // 0000004A46DC: 081A1F0D
	.long 0xd7600003                                           // 0000004A46E0: D7600003
	v_cndmask_b32_e32 v0, v17, v157, vcc_lo                    // 0000004A46E4: 02013B11
	v_dual_sub_f32 v7, v7, v14 :: v_dual_mul_f32 v16, 0x3db504f3, v16// 0000004A46E8: C9461D07 071020FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004A46F4: BF870244
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 0000004A46F8: 102626FF 3DB504F3
	.long 0xd73c0005                                           // 0000004A4700: D73C0005
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 0000004A4704: 02022A81
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 0000004A4708: 101A1AFF 3DB504F3
	.long 0x7f1c3981                                           // 0000004A4710: 7F1C3981
	v_dual_mul_f32 v21, s2, v16 :: v_dual_mul_f32 v16, s0, v19 // 0000004A4714: C8C62002 15102600
	v_lshlrev_b32_e32 v15, 9, v2                               // 0000004A471C: 301E0489
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A4720: BF870004
	v_mul_f32_e32 v23, s3, v13                                 // 0000004A4724: 102E1A03
	.long 0x7f263981                                           // 0000004A4728: 7F263981
	v_add_nc_u32_e32 v20, 0x60, v28                            // 0000004A472C: 4A2838FF 00000060
	.long 0x7e1c3990                                           // 0000004A4734: 7E1C3990
	v_or_b32_e32 v11, 64, v28                                  // 0000004A4738: 381638C0
	.long 0x7e263997                                           // 0000004A473C: 7E263997
	.long 0xd7600000                                           // 0000004A4740: D7600000
	v_cndmask_b32_e32 v0, v18, v157, vcc_lo                    // 0000004A4744: 02013B12
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 0000004A4748: 100E0EFF 3DB504F3
	v_and_b32_e32 v13, 1, v14                                  // 0000004A4750: 361A1C81
	v_xor_b32_e32 v14, v2, v3                                  // 0000004A4754: 3A1C0702
	v_and_b32_e32 v26, 1, v19                                  // 0000004A4758: 36342681
	v_mad_i64_i32 v[11:12], null, v11, s12, 0                  // 0000004A475C: D6FF7C0B 0200190B
	.long 0xd7006a05                                           // 0000004A4764: D7006A05
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 0000004A4768: 02020B04
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A476C: BF870004
	v_lshl_add_u32 v24, v14, 2, v15                            // 0000004A4770: D6460018 043D050E
	v_add3_u32 v25, v16, v13, 0x7fff                           // 0000004A4778: D6550019 03FE1B10 00007FFF
	v_mad_i64_i32 v[13:14], null, v20, s12, 0                  // 0000004A4784: D6FF7C0D 02001914
	ds_load_2addr_stride64_b32 v[15:16], v24 offset1:64        // 0000004A478C: D8E04000 0F000018
	ds_load_2addr_stride64_b32 v[19:20], v24 offset0:128 offset1:192// 0000004A4794: D8E0C080 13000018
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 0000004A479C: D5207C06 01AA0D08
	.long 0x7e023995                                           // 0000004A47A4: 7E023995
	v_mul_f32_e32 v7, s0, v7                                   // 0000004A47A8: 100E0E00
	.long 0xd73c0009                                           // 0000004A47AC: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000004A47B0: 02021281
	.long 0xd73c000b                                           // 0000004A47B4: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000004A47B8: 02021681
	global_store_d16_hi_b16 v[5:6], v25, off                   // 0000004A47BC: DC960000 007C1905
	v_and_b32_e32 v22, 1, v1                                   // 0000004A47C4: 362C0281
	.long 0x7e023987                                           // 0000004A47C8: 7E023987
	.long 0xd73c0005                                           // 0000004A47CC: D73C0005
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000004A47D0: 02021A81
	.long 0xd7006a09                                           // 0000004A47D4: D7006A09
	v_cndmask_b32_e32 v1, v4, v9, vcc_lo                       // 0000004A47D8: 02021304
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A47DC: BF870214
	v_add3_u32 v21, v21, v22, 0x7fff                           // 0000004A47E0: D6550015 03FE2D15 00007FFF
	v_and_b32_e32 v22, 1, v1                                   // 0000004A47EC: 362C0281
	v_add_co_ci_u32_e64 v10, null, v8, v10, vcc_lo             // 0000004A47F0: D5207C0A 01AA1508
	.long 0xd7006a0b                                           // 0000004A47F8: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000004A47FC: 02021704
	s_waitcnt lgkmcnt(1)                                       // 0000004A4800: BF89FC17
	v_sub_f32_e32 v13, v15, v16                                // 0000004A4804: 081A210F
	v_add_f32_e32 v14, v15, v16                                // 0000004A4808: 061C210F
	s_waitcnt lgkmcnt(0)                                       // 0000004A480C: BF89FC07
	v_add_f32_e32 v16, v19, v20                                // 0000004A4810: 06202913
	v_sub_f32_e32 v15, v19, v20                                // 0000004A4814: 081E2913
	v_add_co_ci_u32_e64 v12, null, v8, v12, vcc_lo             // 0000004A4818: D5207C0C 01AA1908
	.long 0xd7006a05                                           // 0000004A4820: D7006A05
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 0000004A4824: 02020B04
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A4828: BF870004
	v_add_f32_e32 v19, v14, v16                                // 0000004A482C: 0626210E
	v_add3_u32 v23, v23, v26, 0x7fff                           // 0000004A4830: D6550017 03FE3517 00007FFF
	v_add3_u32 v7, v7, v22, 0x7fff                             // 0000004A483C: D6550007 03FE2D07 00007FFF
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 0000004A4848: D5207C06 01AA0D08
	.long 0xd7600000                                           // 0000004A4850: D7600000
	v_cndmask_b32_e32 v0, v17, v142, vcc_lo                    // 0000004A4854: 02011D11
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 0000004A4858: 102626FF 3DB504F3
	s_clause 0x2                                               // 0000004A4860: BF850002
	global_store_d16_hi_b16 v[9:10], v21, off                  // 0000004A4864: DC960000 007C1509
	global_store_d16_hi_b16 v[11:12], v23, off                 // 0000004A486C: DC960000 007C170B
	global_store_d16_hi_b16 v[5:6], v7, off                    // 0000004A4874: DC960000 007C0705
	v_add_f32_e32 v7, v13, v15                                 // 0000004A487C: 060E1F0D
	v_dual_mul_f32 v19, s0, v19 :: v_dual_sub_f32 v14, v14, v16// 0000004A4880: C8CA2600 130E210E
	.long 0xd7600002                                           // 0000004A4888: D7600002
	v_cndmask_b32_e32 v0, v18, v142, vcc_lo                    // 0000004A488C: 02011D12
	.long 0xd7600000                                           // 0000004A4890: D7600000
	v_cndmask_b32_e32 v0, v17, v158, vcc_lo                    // 0000004A4894: 02013D11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A4898: BF870214
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 0000004A489C: 100E0EFF 3DB504F3
	.long 0x7e283993                                           // 0000004A48A4: 7E283993
	.long 0x7f283981                                           // 0000004A48A8: 7F283981
	v_dual_sub_f32 v13, v13, v15 :: v_dual_mul_f32 v14, 0x3db504f3, v14// 0000004A48AC: C9461F0D 0D0E1CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004A48B8: BF8701A4
	v_mul_f32_e32 v7, s2, v7                                   // 0000004A48BC: 100E0E02
	.long 0xd7600002                                           // 0000004A48C0: D7600002
	v_cndmask_b32_e32 v0, v18, v158, vcc_lo                    // 0000004A48C4: 02013D12
	v_dual_mul_f32 v13, 0x3db504f3, v13 :: v_dual_and_b32 v16, 1, v20// 0000004A48C8: C8E41AFF 0D102881 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A48D4: BF870004
	v_mul_f32_e32 v20, s0, v14                                 // 0000004A48D8: 10281C00
	v_or_b32_e32 v2, s1, v2                                    // 0000004A48DC: 38040401
	v_xor_b32_e32 v3, v0, v3                                   // 0000004A48E0: 3A060700
	.long 0x7f1c3981                                           // 0000004A48E4: 7F1C3981
	v_dual_mul_f32 v22, s2, v13 :: v_dual_lshlrev_b32 v13, 9, v0// 0000004A48E8: C8E21A02 160C0089
	.long 0x7e1c3994                                           // 0000004A48F0: 7E1C3994
	v_add_nc_u32_e32 v11, 32, v2                               // 0000004A48F4: 4A1604A0
	v_add3_u32 v21, v19, v16, 0x7fff                           // 0000004A48F8: D6550015 03FE2113 00007FFF
	v_mad_i64_i32 v[9:10], null, v2, s12, 0                    // 0000004A4904: D6FF7C09 02001902
	v_lshl_add_u32 v19, v3, 2, v13                             // 0000004A490C: D6460013 04350503
	v_and_b32_e32 v23, 1, v14                                  // 0000004A4914: 362E1C81
	v_mad_i64_i32 v[11:12], null, v11, s12, 0                  // 0000004A4918: D6FF7C0B 0200190B
	.long 0x7e023987                                           // 0000004A4920: 7E023987
	v_or_b32_e32 v0, s1, v0                                    // 0000004A4924: 38000001
	ds_load_2addr_stride64_b32 v[13:14], v19 offset1:64        // 0000004A4928: D8E04000 0D000013
	v_add3_u32 v23, v20, v23, 0x7fff                           // 0000004A4930: D6550017 03FE2F14 00007FFF
	ds_load_2addr_stride64_b32 v[19:20], v19 offset0:128 offset1:192// 0000004A493C: D8E0C080 13000013
	.long 0xd73c0005                                           // 0000004A4944: D73C0005
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000004A4948: 02021281
	v_and_b32_e32 v15, 1, v1                                   // 0000004A494C: 361E0281
	.long 0xd73c0009                                           // 0000004A4950: D73C0009
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000004A4954: 02021681
	v_or_b32_e32 v11, 64, v2                                   // 0000004A4958: 381604C0
	v_add_nc_u32_e32 v2, 0x60, v2                              // 0000004A495C: 4A0404FF 00000060
	.long 0xd7600000                                           // 0000004A4964: D7600000
	v_cndmask_b32_e32 v0, v17, v143, vcc_lo                    // 0000004A4968: 02011F11
	.long 0xd7006a05                                           // 0000004A496C: D7006A05
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 0000004A4970: 02020B04
	v_add3_u32 v7, v7, v15, 0x7fff                             // 0000004A4974: D6550007 03FE1F07 00007FFF
	v_mad_i64_i32 v[15:16], null, v0, s12, 0                   // 0000004A4980: D6FF7C0F 02001900
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 0000004A4988: D5207C06 01AA0D08
	v_mad_i64_i32 v[11:12], null, v11, s12, 0                  // 0000004A4990: D6FF7C0B 0200190B
	.long 0xd7006a09                                           // 0000004A4998: D7006A09
	v_cndmask_b32_e32 v1, v4, v9, vcc_lo                       // 0000004A499C: 02021304
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004A49A0: BF870001
	v_add_co_ci_u32_e64 v10, null, v8, v10, vcc_lo             // 0000004A49A4: D5207C0A 01AA1508
	s_clause 0x1                                               // 0000004A49AC: BF850001
	global_store_d16_hi_b16 v[5:6], v21, off                   // 0000004A49B0: DC960000 007C1505
	global_store_d16_hi_b16 v[9:10], v7, off                   // 0000004A49B8: DC960000 007C0709
	.long 0xd73c0005                                           // 0000004A49C0: D73C0005
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000004A49C4: 02021E81
	s_waitcnt lgkmcnt(1)                                       // 0000004A49C8: BF89FC17
	v_sub_f32_e32 v15, v13, v14                                // 0000004A49CC: 081E1D0D
	s_waitcnt lgkmcnt(0)                                       // 0000004A49D0: BF89FC07
	v_dual_add_f32 v13, v13, v14 :: v_dual_sub_f32 v14, v19, v20// 0000004A49D4: C90A1D0D 0D0E2913
	.long 0xd73c000b                                           // 0000004A49DC: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000004A49E0: 02021681
	v_add_f32_e32 v16, v19, v20                                // 0000004A49E4: 06202913
	.long 0xd7600001                                           // 0000004A49E8: D7600001
	v_cndmask_b32_e32 v0, v18, v143, vcc_lo                    // 0000004A49EC: 02011F12
	.long 0xd7600002                                           // 0000004A49F0: D7600002
	v_cndmask_b32_e32 v0, v17, v159, vcc_lo                    // 0000004A49F4: 02013F11
	v_add_f32_e32 v19, v15, v14                                // 0000004A49F8: 06261D0F
	v_sub_f32_e32 v14, v15, v14                                // 0000004A49FC: 081C1D0F
	.long 0xd7006a0b                                           // 0000004A4A00: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000004A4A04: 02021704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A4A08: BF870211
	v_add_co_ci_u32_e64 v12, null, v8, v12, vcc_lo             // 0000004A4A0C: D5207C0C 01AA1908
	v_dual_add_f32 v20, v13, v16 :: v_dual_mul_f32 v17, 0x3db504f3, v19// 0000004A4A14: C906210D 141026FF 3DB504F3
	v_sub_f32_e32 v13, v13, v16                                // 0000004A4A20: 081A210D
	v_add_nc_u32_e32 v9, 32, v0                                // 0000004A4A24: 4A1200A0
	v_mad_i64_i32 v[2:3], null, v2, s12, 0                     // 0000004A4A28: D6FF7C02 02001902
	.long 0x7e023996                                           // 0000004A4A30: 7E023996
	global_store_d16_hi_b16 v[11:12], v23, off                 // 0000004A4A34: DC960000 007C170B
	v_or_b32_e32 v11, 64, v0                                   // 0000004A4A3C: 381600C0
	v_mul_f32_e32 v19, 0x3db504f3, v20                         // 0000004A4A40: 102628FF 3DB504F3
	.long 0xd7600003                                           // 0000004A4A48: D7600003
	v_cndmask_b32_e32 v0, v18, v159, vcc_lo                    // 0000004A4A4C: 02013F12
	v_dual_mul_f32 v15, s1, v17 :: v_dual_mul_f32 v14, 0x3db504f3, v14// 0000004A4A50: C8C62201 0F0E1CFF 3DB504F3
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 0000004A4A5C: 101A1AFF 3DB504F3
	v_add_nc_u32_e32 v0, 0x60, v0                              // 0000004A4A64: 4A0000FF 00000060
	v_mad_i64_i32 v[9:10], null, v9, s12, 0                    // 0000004A4A6C: D6FF7C09 02001909
	v_and_b32_e32 v24, 1, v1                                   // 0000004A4A74: 36300281
	v_mad_i64_i32 v[11:12], null, v11, s12, 0                  // 0000004A4A78: D6FF7C0B 0200190B
	v_mul_f32_e32 v16, s0, v19                                 // 0000004A4A80: 10202600
	.long 0x7e02398f                                           // 0000004A4A84: 7E02398F
	v_mul_f32_e32 v18, s3, v14                                 // 0000004A4A88: 10241C03
	.long 0xd73c0002                                           // 0000004A4A8C: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000004A4A90: 02020481
	v_mul_f32_e32 v19, s2, v13                                 // 0000004A4A94: 10261A02
	v_mad_i64_i32 v[13:14], null, v0, s12, 0                   // 0000004A4A98: D6FF7C0D 02001900
	.long 0x7e223990                                           // 0000004A4AA0: 7E223990
	.long 0x7f223981                                           // 0000004A4AA4: 7F223981
	v_and_b32_e32 v20, 1, v1                                   // 0000004A4AA8: 36280281
	.long 0x7e023992                                           // 0000004A4AAC: 7E023992
	.long 0xd73c0009                                           // 0000004A4AB0: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000004A4AB4: 02021281
	.long 0x7e2a3993                                           // 0000004A4AB8: 7E2A3993
	.long 0x7f2a3981                                           // 0000004A4ABC: 7F2A3981
	.long 0xd7006a02                                           // 0000004A4AC0: D7006A02
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000004A4AC4: 02020504
	.long 0xd73c000b                                           // 0000004A4AC8: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000004A4ACC: 02021681
	v_add3_u32 v7, v22, v24, 0x7fff                            // 0000004A4AD0: D6550007 03FE3116 00007FFF
	v_add_co_ci_u32_e64 v3, null, v8, v3, vcc_lo               // 0000004A4ADC: D5207C03 01AA0708
	.long 0xd7006a05                                           // 0000004A4AE4: D7006A05
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 0000004A4AE8: 02020B04
	v_and_b32_e32 v17, 1, v17                                  // 0000004A4AEC: 36222281
	v_and_b32_e32 v22, 1, v1                                   // 0000004A4AF0: 362C0281
	.long 0xd73c0000                                           // 0000004A4AF4: D73C0000
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000004A4AF8: 02021A81
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 0000004A4AFC: D5207C06 01AA0D08
	.long 0xd7006a09                                           // 0000004A4B04: D7006A09
	v_cndmask_b32_e32 v1, v4, v9, vcc_lo                       // 0000004A4B08: 02021304
	v_and_b32_e32 v21, 1, v21                                  // 0000004A4B0C: 362A2A81
	v_add_co_ci_u32_e64 v10, null, v8, v10, vcc_lo             // 0000004A4B10: D5207C0A 01AA1508
	.long 0xd7006a0b                                           // 0000004A4B18: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000004A4B1C: 02021704
	v_add3_u32 v14, v16, v17, 0x7fff                           // 0000004A4B20: D655000E 03FE2310 00007FFF
	v_add_co_ci_u32_e64 v12, null, v8, v12, vcc_lo             // 0000004A4B2C: D5207C0C 01AA1908
	v_add3_u32 v13, v15, v20, 0x7fff                           // 0000004A4B34: D655000D 03FE290F 00007FFF
	.long 0xd7006a00                                           // 0000004A4B40: D7006A00
	v_cndmask_b32_e32 v1, v4, v0, vcc_lo                       // 0000004A4B44: 02020104
	v_add3_u32 v16, v19, v21, 0x7fff                           // 0000004A4B48: D6550010 03FE2B13 00007FFF
	v_add3_u32 v15, v18, v22, 0x7fff                           // 0000004A4B54: D655000F 03FE2D12 00007FFF
	v_add_co_ci_u32_e64 v1, null, v8, v1, vcc_lo               // 0000004A4B60: D5207C01 01AA0308
	s_clause 0x4                                               // 0000004A4B68: BF850004
	global_store_d16_hi_b16 v[2:3], v7, off                    // 0000004A4B6C: DC960000 007C0702
	global_store_d16_hi_b16 v[5:6], v14, off                   // 0000004A4B74: DC960000 007C0E05
	global_store_d16_hi_b16 v[9:10], v13, off                  // 0000004A4B7C: DC960000 007C0D09
	global_store_d16_hi_b16 v[11:12], v16, off                 // 0000004A4B84: DC960000 007C100B
	global_store_d16_hi_b16 v[0:1], v15, off                   // 0000004A4B8C: DC960000 007C0F00
	s_nop 0                                                    // 0000004A4B94: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000004A4B98: BFB60003
	s_endpgm                                                   // 0000004A4B9C: BFB00000
		...

