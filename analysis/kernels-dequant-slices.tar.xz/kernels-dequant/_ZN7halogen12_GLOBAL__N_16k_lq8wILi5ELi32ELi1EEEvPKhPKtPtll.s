00000000002e9800 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi32ELi1EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi32ELi1EEEvPKhPKtPtll():
	s_clause 0x1                                               // 0000002E9800: BF850001
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000002E9804: F4040300 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 0000002E980C: F40C0100 F8000000
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000002E9814: 32020085
	s_mov_b32 s3, 0                                            // 0000002E9818: BE830080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v6, 0              // 0000002E981C: CA100080 0F060080
	s_lshl_b64 s[0:1], s[2:3], 3                               // 0000002E9824: 84808302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002E9828: BF8701B9
	v_dual_mov_b32 v9, s1 :: v_dual_and_b32 v14, 31, v0        // 0000002E982C: CA240001 090E009F
	v_or_b32_e32 v8, s0, v1                                    // 0000002E9834: 38100200
	v_mov_b32_e32 v25, 0                                       // 0000002E9838: 7E320280
	v_dual_mov_b32 v5, 0 :: v_dual_lshlrev_b32 v10, 4, v14     // 0000002E983C: CA220080 050A1C84
	v_mov_b32_e32 v4, 0                                        // 0000002E9844: 7E080280
	s_waitcnt lgkmcnt(0)                                       // 0000002E9848: BF89FC07
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 0000002E984C: 7CA8100C
	s_ashr_i32 s0, s11, 31                                     // 0000002E9850: 86009F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002E9854: BF870499
	s_lshr_b32 s0, s0, 28                                      // 0000002E9858: 85009C00
	s_add_u32 s2, s10, s0                                      // 0000002E985C: 8002000A
	s_addc_u32 s3, s11, 0                                      // 0000002E9860: 8203800B
	v_cndmask_b32_e32 v3, 0, v8, vcc_lo                        // 0000002E9864: 02061080
	v_cndmask_b32_e64 v1, 0, s1, vcc_lo                        // 0000002E9868: D5010001 01A80280
	s_ashr_i64 s[2:3], s[2:3], 4                               // 0000002E9870: 86828402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E9874: BF8700A9
	s_add_u32 s0, s2, s10                                      // 0000002E9878: 80000A02
	s_addc_u32 s1, s3, s11                                     // 0000002E987C: 82010B03
	.long 0xd72c0007                                           // 0000002E9880: D72C0007
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 0000002E9884: 02000101
	v_mad_u64_u32 v[1:2], null, v3, s0, 0                      // 0000002E9888: D6FE7C01 02000103
	.long 0xd72c0003                                           // 0000002E9890: D72C0003
	v_cndmask_b32_e32 v0, v3, v1, vcc_lo                       // 0000002E9894: 02000303
	.long 0xd4440000                                           // 0000002E9898: D4440000
	v_cndmask_b32_e32 v1, s2, v14, vcc_lo                      // 0000002E989C: 02021C02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E98A0: BF870193
	.long 0xd7000110                                           // 0000002E98A4: D7000110
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000002E98A8: 02020204
	v_add3_u32 v2, v2, v3, v7                                  // 0000002E98AC: D6550002 041E0702
	v_mov_b32_e32 v7, 0                                        // 0000002E98B4: 7E0E0280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002E98B8: BF870002
	v_add_co_ci_u32_e64 v17, null, s5, v2, s1                  // 0000002E98BC: D5207C11 00060405
	s_and_saveexec_b32 s3, s0                                  // 0000002E98C4: BE832000
	s_cbranch_execz 21                                         // 0000002E98C8: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi32ELi1EEEvPKhPKtPtll+0x120>
	v_lshlrev_b32_e32 v3, 4, v14                               // 0000002E98CC: 30061C84
	.long 0xd7000105                                           // 0000002E98D0: D7000105
	v_cndmask_b32_e32 v0, v16, v10, vcc_lo                     // 0000002E98D4: 02001510
	v_and_b32_e32 v7, 28, v0                                   // 0000002E98D8: 360E009C
	v_add_co_ci_u32_e64 v6, null, s11, v17, s1                 // 0000002E98DC: D5207C06 0006220B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E98E4: BF870094
	.long 0xd7000103                                           // 0000002E98E8: D7000103
	v_cndmask_b32_e32 v1, v16, v3, vcc_lo                      // 0000002E98EC: 02020710
	v_add_co_ci_u32_e64 v4, null, 0, v17, s1                   // 0000002E98F0: D5207C04 00062280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E98F8: BF870094
	.long 0xd700010b                                           // 0000002E98FC: D700010B
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002E9900: 02020F05
	v_add_co_ci_u32_e64 v12, null, 0, v6, s1                   // 0000002E9904: D5207C0C 00060C80
	s_clause 0x1                                               // 0000002E990C: BF850001
	global_load_b128 v[4:7], v[3:4], off                       // 0000002E9910: DC5E0000 047C0003
	global_load_b32 v25, v[11:12], off                         // 0000002E9918: DC520000 197C000B
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002E9920: 8C7E037E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 0000002E9924: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 0000002E992C: CA100080 14140080
	s_and_saveexec_b32 s3, s0                                  // 0000002E9934: BE832000
	s_cbranch_execz 436                                        // 0000002E9938: BFA501B4 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi32ELi1EEEvPKhPKtPtll+0x80c>
	v_and_or_b32 v0, v0, 28, 32                                // 0000002E993C: D6570000 02813900
	.long 0xd7000001                                           // 0000002E9944: D7000001
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 0000002E9948: 0202020A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E994C: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s11, v2, s0                  // 0000002E9950: D5207C02 0002040B
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v22, v14           // 0000002E9958: CA100080 0B16010E
	.long 0xd7000000                                           // 0000002E9960: D7000000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002E9964: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E9968: BF870191
	v_add_co_ci_u32_e64 v1, null, 0, v2, s0                    // 0000002E996C: D5207C01 00020480
	v_mov_b32_e32 v21, v11                                     // 0000002E9974: 7E2A030B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9978: BF870093
	.long 0xd700000c                                           // 0000002E997C: D700000C
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002E9980: 02020004
	v_add_co_ci_u32_e64 v13, null, s5, v1, s0                  // 0000002E9984: D5207C0D 00020205
	v_mov_b32_e32 v20, v11                                     // 0000002E998C: 7E28030B
	v_mov_b32_e32 v19, v11                                     // 0000002E9990: 7E26030B
	v_mov_b32_e32 v18, v11                                     // 0000002E9994: 7E24030B
	v_mov_b32_e32 v15, v11                                     // 0000002E9998: 7E1E030B
	s_mul_i32 s1, s11, 6                                       // 0000002E999C: 9601860B
	s_mul_hi_u32 s16, s10, 6                                   // 0000002E99A0: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 0000002E99A4: 848E820A
	s_add_i32 s16, s16, s1                                     // 0000002E99A8: 81100110
	s_mul_i32 s18, s10, 6                                      // 0000002E99AC: 9612860A
	s_mov_b32 s17, 0                                           // 0000002E99B0: BE910080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000002E99B4: 8484810A
	s_branch 374                                               // 0000002E99B8: BFA00176 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi32ELi1EEEvPKhPKtPtll+0x794>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000002E99BC: 8C7E0A7E
	v_cvt_f32_ubyte0_e32 v26, v4                               // 0000002E99C0: 7E342304
	s_and_b32 s0, exec_lo, s0                                  // 0000002E99C4: 8B00007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E99C8: BF870099
	s_or_b32 s17, s0, s17                                      // 0000002E99CC: 8C111100
	v_fma_mix_f32 v26, v26, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E99D0: CC20601A 1466331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E99D8: BF870091
	v_bfe_u32 v27, v26, 16, 1                                  // 0000002E99DC: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 0000002E99E4: D655001A 03FE371A 00007FFF
	.long 0x7f363880                                           // 0000002E99F0: 7F363880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E99F4: BF8700A2
	.long 0x7e36399a                                           // 0000002E99F8: 7E36399A
	v_cvt_f32_ubyte1_e32 v26, v4                               // 0000002E99FC: 7E342504
	v_fma_mix_f32 v26, v26, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9A00: CC20601A 1466331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9A08: BF870091
	v_bfe_u32 v28, v26, 16, 1                                  // 0000002E9A0C: D610001C 0205211A
	v_add3_u32 v26, v26, v28, 0x7fff                           // 0000002E9A14: D655001A 03FE391A 00007FFF
	v_cvt_f32_ubyte2_e32 v28, v4                               // 0000002E9A20: 7E382704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 0000002E9A24: 7E082904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E9A28: BF870193
	v_and_or_b32 v33, 0xffff0000, v26, v27                     // 0000002E9A2C: D6570021 046E34FF FFFF0000
	v_fma_mix_f32 v28, v28, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9A38: CC20601C 1466331C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E9A40: BF870113
	v_fma_mix_f32 v4, v4, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9A44: CC206004 14663304
	v_bfe_u32 v29, v28, 16, 1                                  // 0000002E9A4C: D610001D 0205211C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E9A54: BF870191
	v_add3_u32 v28, v28, v29, 0x7fff                           // 0000002E9A58: D655001C 03FE3B1C 00007FFF
	v_bfe_u32 v29, v4, 16, 1                                   // 0000002E9A64: D610001D 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E9A6C: BF8701A2
	.long 0x7e38399c                                           // 0000002E9A70: 7E38399C
	.long 0x7f38399b                                           // 0000002E9A74: 7F38399B
	v_add3_u32 v4, v4, v29, 0x7fff                             // 0000002E9A78: D6550004 03FE3B04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E9A84: BF8700A1
	v_and_or_b32 v34, 0xffff0000, v4, v28                      // 0000002E9A88: D6570022 047208FF FFFF0000
	v_cvt_f32_ubyte0_e32 v4, v5                                // 0000002E9A94: 7E082305
	v_fma_mix_f32 v4, v4, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9A98: CC206004 14663304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9AA0: BF870091
	v_bfe_u32 v26, v4, 16, 1                                   // 0000002E9AA4: D610001A 02052104
	v_add3_u32 v4, v4, v26, 0x7fff                             // 0000002E9AAC: D6550004 03FE3504 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E9AB8: BF8700A1
	.long 0x7e363984                                           // 0000002E9ABC: 7E363984
	v_cvt_f32_ubyte1_e32 v4, v5                                // 0000002E9AC0: 7E082505
	v_fma_mix_f32 v4, v4, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9AC4: CC206004 14663304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9ACC: BF870091
	v_bfe_u32 v26, v4, 16, 1                                   // 0000002E9AD0: D610001A 02052104
	v_add3_u32 v4, v4, v26, 0x7fff                             // 0000002E9AD8: D6550004 03FE3504 00007FFF
	v_cvt_f32_ubyte2_e32 v26, v5                               // 0000002E9AE4: 7E342705
	v_cvt_f32_ubyte3_e32 v5, v5                                // 0000002E9AE8: 7E0A2905
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E9AEC: BF870193
	v_and_or_b32 v35, 0xffff0000, v4, v27                      // 0000002E9AF0: D6570023 046E08FF FFFF0000
	v_fma_mix_f32 v26, v26, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9AFC: CC20601A 1466331A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E9B04: BF8701A3
	v_fma_mix_f32 v5, v5, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9B08: CC206005 14663305
	v_cvt_f32_ubyte0_e32 v4, v6                                // 0000002E9B10: 7E082306
	v_bfe_u32 v28, v26, 16, 1                                  // 0000002E9B14: D610001C 0205211A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E9B1C: BF870112
	v_fma_mix_f32 v4, v4, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9B20: CC206004 14663304
	v_add3_u32 v26, v26, v28, 0x7fff                           // 0000002E9B28: D655001A 03FE391A 00007FFF
	v_bfe_u32 v28, v5, 16, 1                                   // 0000002E9B34: D610001C 02052105
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E9B3C: BF8701A2
	.long 0x7e34399a                                           // 0000002E9B40: 7E34399A
	.long 0x7f34399b                                           // 0000002E9B44: 7F34399B
	v_add3_u32 v5, v5, v28, 0x7fff                             // 0000002E9B48: D6550005 03FE3905 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E9B54: BF8700A1
	v_and_or_b32 v36, 0xffff0000, v5, v26                      // 0000002E9B58: D6570024 046A0AFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002E9B64: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002E9B6C: D6550004 03FE0B04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E9B78: BF8700A1
	.long 0x7e363984                                           // 0000002E9B7C: 7E363984
	v_cvt_f32_ubyte1_e32 v4, v6                                // 0000002E9B80: 7E082506
	v_fma_mix_f32 v4, v4, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9B84: CC206004 14663304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9B8C: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002E9B90: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002E9B98: D6550004 03FE0B04 00007FFF
	v_cvt_f32_ubyte2_e32 v5, v6                                // 0000002E9BA4: 7E0A2706
	v_cvt_f32_ubyte3_e32 v6, v6                                // 0000002E9BA8: 7E0C2906
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E9BAC: BF870193
	v_and_or_b32 v37, 0xffff0000, v4, v27                      // 0000002E9BB0: D6570025 046E08FF FFFF0000
	v_fma_mix_f32 v5, v5, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9BBC: CC206005 14663305
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E9BC4: BF8701A3
	v_fma_mix_f32 v6, v6, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9BC8: CC206006 14663306
	v_cvt_f32_ubyte0_e32 v4, v7                                // 0000002E9BD0: 7E082307
	v_bfe_u32 v26, v5, 16, 1                                   // 0000002E9BD4: D610001A 02052105
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E9BDC: BF870112
	v_fma_mix_f32 v4, v4, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9BE0: CC206004 14663304
	v_add3_u32 v5, v5, v26, 0x7fff                             // 0000002E9BE8: D6550005 03FE3505 00007FFF
	v_bfe_u32 v26, v6, 16, 1                                   // 0000002E9BF4: D610001A 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E9BFC: BF8701A2
	.long 0x7e0a3985                                           // 0000002E9C00: 7E0A3985
	.long 0x7f0a399b                                           // 0000002E9C04: 7F0A399B
	v_add3_u32 v6, v6, v26, 0x7fff                             // 0000002E9C08: D6550006 03FE3506 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E9C14: BF8700A1
	v_and_or_b32 v38, 0xffff0000, v6, v5                       // 0000002E9C18: D6570026 04160CFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002E9C24: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002E9C2C: D6550004 03FE0B04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E9C38: BF8700A1
	.long 0x7e363984                                           // 0000002E9C3C: 7E363984
	v_cvt_f32_ubyte1_e32 v4, v7                                // 0000002E9C40: 7E082507
	v_fma_mix_f32 v4, v4, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9C44: CC206004 14663304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9C4C: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002E9C50: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002E9C58: D6550004 03FE0B04 00007FFF
	v_cvt_f32_ubyte2_e32 v5, v7                                // 0000002E9C64: 7E0A2707
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E9C68: BF870112
	v_and_or_b32 v39, 0xffff0000, v4, v27                      // 0000002E9C6C: D6570027 046E08FF FFFF0000
	v_fma_mix_f32 v5, v5, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9C78: CC206005 14663305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9C80: BF870091
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002E9C84: D6100006 02052105
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000002E9C8C: D6550005 03FE0D05 00007FFF
	v_cvt_f32_ubyte3_e32 v6, v7                                // 0000002E9C98: 7E0C2907
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E9C9C: BF870112
	.long 0x7e0a3985                                           // 0000002E9CA0: 7E0A3985
	v_fma_mix_f32 v6, v6, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9CA4: CC206006 14663306
	.long 0x7f0a399b                                           // 0000002E9CAC: 7F0A399B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9CB0: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 0000002E9CB4: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000002E9CBC: D6550006 03FE0F06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002E9CC8: BF870131
	v_and_or_b32 v40, 0xffff0000, v6, v5                       // 0000002E9CCC: D6570028 04160CFF FFFF0000
	.long 0xd73c0004                                           // 0000002E9CD8: D73C0004
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 0000002E9CDC: 02021481
	v_mov_b32_e32 v10, v24                                     // 0000002E9CE0: 7E140318
	.long 0xd700001d                                           // 0000002E9CE4: D700001D
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000002E9CE8: 02020806
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002E9CEC: BF870001
	v_add_co_ci_u32_e64 v30, null, s7, v5, s0                  // 0000002E9CF0: D5207C1E 00020A07
	s_clause 0x1                                               // 0000002E9CF8: BF850001
	global_load_b128 v[4:7], v[29:30], off                     // 0000002E9CFC: DC5E0000 047C001D
	global_load_b128 v[25:28], v[29:30], off offset:16         // 0000002E9D04: DC5E0010 197C001D
	s_waitcnt vmcnt(1)                                         // 0000002E9D0C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 0000002E9D10: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9D18: BF870091
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 0000002E9D1C: CC1A4004 1C124505
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 0000002E9D24: CC1A4004 1C124706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E9D2C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 0000002E9D30: CC1A4004 1C124907
	s_waitcnt vmcnt(0)                                         // 0000002E9D38: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 0000002E9D3C: CC1A4004 1C124B19
	.long 0xd7000019                                           // 0000002E9D44: D7000019
	v_cndmask_b32_e32 v0, v29, v4, vcc_lo                      // 0000002E9D48: 0200091D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002E9D4C: BF8701B2
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 0000002E9D50: CC1A4004 1C124D1A
	v_add_co_ci_u32_e64 v26, null, s5, v30, s0                 // 0000002E9D58: D5207C1A 00023C05
	.long 0xd700001f                                           // 0000002E9D60: D700001F
	v_cndmask_b32_e32 v0, v29, v14, vcc_lo                     // 0000002E9D64: 02001D1D
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002E9D68: CC1A4004 1C124F1B
	v_add_co_ci_u32_e64 v32, null, s15, v30, s0                // 0000002E9D70: D5207C20 00023C0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9D78: BF870092
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002E9D7C: CC1A4004 1C12511C
	v_add_f32_e32 v21, v21, v4                                 // 0000002E9D84: 062A0915
	s_clause 0x1                                               // 0000002E9D88: BF850001
	global_load_b128 v[4:7], v[25:26], off                     // 0000002E9D8C: DC5E0000 047C0019
	global_load_b128 v[25:28], v[25:26], off offset:16         // 0000002E9D94: DC5E0010 197C0019
	s_waitcnt vmcnt(1)                                         // 0000002E9D9C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 0000002E9DA0: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9DA8: BF870091
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 0000002E9DAC: CC1A4004 1C124505
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 0000002E9DB4: CC1A4004 1C124706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E9DBC: BF8700A1
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 0000002E9DC0: CC1A4004 1C124907
	s_waitcnt vmcnt(0)                                         // 0000002E9DC8: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 0000002E9DCC: CC1A4004 1C124B19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9DD4: BF870091
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 0000002E9DD8: CC1A4004 1C124D1A
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002E9DE0: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9DE8: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002E9DEC: CC1A4004 1C12511C
	v_add_f32_e32 v20, v20, v4                                 // 0000002E9DF4: 06280914
	s_clause 0x1                                               // 0000002E9DF8: BF850001
	global_load_b128 v[4:7], v[31:32], off                     // 0000002E9DFC: DC5E0000 047C001F
	global_load_b128 v[25:28], v[31:32], off offset:16         // 0000002E9E04: DC5E0010 197C001F
	s_waitcnt vmcnt(1)                                         // 0000002E9E0C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 0000002E9E10: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9E18: BF870091
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 0000002E9E1C: CC1A4004 1C124505
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 0000002E9E24: CC1A4004 1C124706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E9E2C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 0000002E9E30: CC1A4004 1C124907
	s_waitcnt vmcnt(0)                                         // 0000002E9E38: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 0000002E9E3C: CC1A4004 1C124B19
	.long 0xd7000019                                           // 0000002E9E44: D7000019
	v_cndmask_b32_e32 v0, v29, v18, vcc_lo                     // 0000002E9E48: 0200251D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002E9E4C: BF870122
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 0000002E9E50: CC1A4004 1C124D1A
	v_add_co_ci_u32_e64 v26, null, s16, v30, s0                // 0000002E9E58: D5207C1A 00023C10
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002E9E60: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9E68: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002E9E6C: CC1A4004 1C12511C
	v_add_f32_e32 v19, v19, v4                                 // 0000002E9E74: 06260913
	s_clause 0x1                                               // 0000002E9E78: BF850001
	global_load_b128 v[4:7], v[25:26], off                     // 0000002E9E7C: DC5E0000 047C0019
	global_load_b128 v[25:28], v[25:26], off offset:16         // 0000002E9E84: DC5E0010 197C0019
	s_waitcnt vmcnt(1)                                         // 0000002E9E8C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 0000002E9E90: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9E98: BF870091
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 0000002E9E9C: CC1A4004 1C124505
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 0000002E9EA4: CC1A4004 1C124706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E9EAC: BF8700A1
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 0000002E9EB0: CC1A4004 1C124907
	s_waitcnt vmcnt(0)                                         // 0000002E9EB8: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 0000002E9EBC: CC1A4004 1C124B19
	.long 0xd7000019                                           // 0000002E9EC4: D7000019
	v_cndmask_b32_e32 v0, v31, v14, vcc_lo                     // 0000002E9EC8: 02001D1F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002E9ECC: BF8701B2
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 0000002E9ED0: CC1A4004 1C124D1A
	v_add_co_ci_u32_e64 v26, null, s15, v32, s0                // 0000002E9ED8: D5207C1A 0002400F
	.long 0xd700000c                                           // 0000002E9EE0: D700000C
	v_cndmask_b32_e32 v0, v12, v160, vcc_lo                    // 0000002E9EE4: 0201410C
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002E9EE8: CC1A4004 1C124F1B
	v_add_co_ci_u32_e64 v13, null, 0, v13, s0                  // 0000002E9EF0: D5207C0D 00021A80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9EF8: BF870092
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002E9EFC: CC1A4004 1C12511C
	v_add_f32_e32 v18, v18, v4                                 // 0000002E9F04: 06240912
	s_clause 0x1                                               // 0000002E9F08: BF850001
	global_load_b128 v[4:7], v[25:26], off                     // 0000002E9F0C: DC5E0000 047C0019
	global_load_b128 v[25:28], v[25:26], off offset:16         // 0000002E9F14: DC5E0010 197C0019
	s_waitcnt vmcnt(1)                                         // 0000002E9F1C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 0000002E9F20: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002E9F28: BF870121
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 0000002E9F2C: CC1A4004 1C124505
	v_mov_b32_e32 v5, v1                                       // 0000002E9F34: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 0000002E9F38: CC1A4004 1C124706
	v_mov_b32_e32 v6, v2                                       // 0000002E9F40: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002E9F44: BF870132
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 0000002E9F48: CC1A4004 1C124907
	v_mov_b32_e32 v7, v3                                       // 0000002E9F50: 7E0E0303
	s_waitcnt vmcnt(0)                                         // 0000002E9F54: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 0000002E9F58: CC1A4004 1C124B19
	v_mov_b32_e32 v25, v23                                     // 0000002E9F60: 7E320317
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9F64: BF870092
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 0000002E9F68: CC1A4004 1C124D1A
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002E9F70: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9F78: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002E9F7C: CC1A4004 1C12511C
	v_dual_add_f32 v15, v15, v4 :: v_dual_mov_b32 v4, v0       // 0000002E9F84: C910090F 0F040100
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 0000002E9F8C: 917E117E
	s_cbranch_execz 29                                         // 0000002E9F90: BFA5001D <_ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi32ELi1EEEvPKhPKtPtll+0x808>
	v_add_nc_u32_e32 v22, 32, v22                              // 0000002E9F94: 4A2C2CA0
	v_add_nc_u32_e32 v24, 0x200, v10                           // 0000002E9F98: 4A3014FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002E9FA0: BF8704A2
	.long 0xd4430000                                           // 0000002E9FA4: D4430000
	v_cndmask_b32_e32 v1, s2, v22, vcc_lo                      // 0000002E9FA8: 02022C02
	s_and_saveexec_b32 s1, s0                                  // 0000002E9FAC: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 0000002E9FB0: 8D01017E
	v_add_nc_u32_e32 v24, 0x200, v10                           // 0000002E9FB4: 4A3014FF 00000200
	s_or_saveexec_b32 s10, s1                                  // 0000002E9FBC: BE8A2201
	s_waitcnt vmcnt(0)                                         // 0000002E9FC0: BF8903F7
	v_dual_mov_b32 v23, v25 :: v_dual_mov_b32 v0, v4           // 0000002E9FC4: CA100119 17000104
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 0000002E9FCC: CA100105 01020106
	v_mov_b32_e32 v3, v7                                       // 0000002E9FD4: 7E060307
	s_xor_b32 exec_lo, exec_lo, s10                            // 0000002E9FD8: 8D7E0A7E
	s_cbranch_execz 65143                                      // 0000002E9FDC: BFA5FE77 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi32ELi1EEEvPKhPKtPtll+0x1bc>
	.long 0xd7000100                                           // 0000002E9FE0: D7000100
	v_cndmask_b32_e32 v1, v16, v24, vcc_lo                     // 0000002E9FE4: 02023110
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002E9FE8: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s1                   // 0000002E9FEC: D5207C01 00062280
	global_load_b128 v[0:3], v[0:1], off                       // 0000002E9FF4: DC5E0000 007C0000
	global_load_b32 v23, v[12:13], off                         // 0000002E9FFC: DC520000 177C000C
	s_branch 65133                                             // 0000002EA004: BFA0FE6D <_ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi32ELi1EEEvPKhPKtPtll+0x1bc>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000002EA008: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EA00C: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002EA010: 8C7E037E
	.long 0xd71f0000                                           // 0000002EA014: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002EA018: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 0000002EA01C: 3A020090
	s_waitcnt vmcnt(1)                                         // 0000002EA020: BF8907F7
	v_xor_b32_e32 v6, 8, v0                                    // 0000002EA024: 3A0C0088
	v_xor_b32_e32 v13, 4, v0                                   // 0000002EA028: 3A1A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA02C: BF870093
	.long 0xd44c0000                                           // 0000002EA030: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000002EA034: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 0000002EA038: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EA040: BF870114
	.long 0xd44c0000                                           // 0000002EA044: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 0000002EA048: 02020CA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002EA04C: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002EA050: BF870002
	v_cndmask_b32_e64 v6, v0, v6, s0                           // 0000002EA054: D5010006 00020D00
	.long 0xd44c0000                                           // 0000002EA05C: D44C0000
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 0000002EA060: 02021AA0
	ds_bpermute_b32 v2, v1, v21                                // 0000002EA064: DACC0000 02001501
	v_cndmask_b32_e64 v13, v0, v13, s0                         // 0000002EA06C: D501000D 00021B00
	s_waitcnt lgkmcnt(0)                                       // 0000002EA074: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 0000002EA078: 06040515
	ds_bpermute_b32 v3, v1, v20                                // 0000002EA07C: DACC0000 03001401
	ds_bpermute_b32 v4, v1, v19                                // 0000002EA084: DACC0000 04001301
	ds_bpermute_b32 v5, v1, v18                                // 0000002EA08C: DACC0000 05001201
	ds_bpermute_b32 v1, v1, v15                                // 0000002EA094: DACC0000 01000F01
	s_waitcnt lgkmcnt(3)                                       // 0000002EA09C: BF89FC37
	v_dual_add_f32 v3, v20, v3 :: v_dual_lshlrev_b32 v6, 2, v6 // 0000002EA0A0: C9220714 03060C82
	ds_bpermute_b32 v7, v6, v2                                 // 0000002EA0A8: DACC0000 07000206
	s_waitcnt lgkmcnt(2)                                       // 0000002EA0B0: BF89FC27
	v_dual_add_f32 v4, v19, v4 :: v_dual_add_f32 v5, v18, v5   // 0000002EA0B4: C9080913 04040B12
	s_waitcnt lgkmcnt(1)                                       // 0000002EA0BC: BF89FC17
	v_add_f32_e32 v1, v15, v1                                  // 0000002EA0C0: 0602030F
	ds_bpermute_b32 v10, v6, v3                                // 0000002EA0C4: DACC0000 0A000306
	ds_bpermute_b32 v11, v6, v4                                // 0000002EA0CC: DACC0000 0B000406
	ds_bpermute_b32 v12, v6, v5                                // 0000002EA0D4: DACC0000 0C000506
	s_waitcnt lgkmcnt(3)                                       // 0000002EA0DC: BF89FC37
	v_dual_add_f32 v2, v2, v7 :: v_dual_lshlrev_b32 v13, 2, v13// 0000002EA0E0: C9220F02 020C1A82
	ds_bpermute_b32 v6, v6, v1                                 // 0000002EA0E8: DACC0000 06000106
	s_waitcnt lgkmcnt(0)                                       // 0000002EA0F0: BF89FC07
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v1, v1, v6    // 0000002EA0F4: C9081704 04000D01
	ds_bpermute_b32 v6, v13, v2                                // 0000002EA0FC: DACC0000 0600020D
	v_add_f32_e32 v5, v5, v12                                  // 0000002EA104: 060A1905
	ds_bpermute_b32 v12, v13, v1                               // 0000002EA108: DACC0000 0C00010D
	v_add_f32_e32 v3, v3, v10                                  // 0000002EA110: 06061503
	ds_bpermute_b32 v10, v13, v4                               // 0000002EA114: DACC0000 0A00040D
	s_waitcnt lgkmcnt(2)                                       // 0000002EA11C: BF89FC27
	v_add_f32_e32 v2, v2, v6                                   // 0000002EA120: 06040D02
	ds_bpermute_b32 v11, v13, v5                               // 0000002EA124: DACC0000 0B00050D
	v_xor_b32_e32 v6, 1, v0                                    // 0000002EA12C: 3A0C0081
	s_waitcnt lgkmcnt(1)                                       // 0000002EA130: BF89FC17
	v_add_f32_e32 v4, v4, v10                                  // 0000002EA134: 06081504
	v_add_f32_e32 v10, v1, v12                                 // 0000002EA138: 06141901
	ds_bpermute_b32 v7, v13, v3                                // 0000002EA13C: DACC0000 0700030D
	v_xor_b32_e32 v13, 2, v0                                   // 0000002EA144: 3A1A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA148: BF870091
	.long 0xd44c0000                                           // 0000002EA14C: D44C0000
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 0000002EA150: 02021AA0
	v_cndmask_b32_e64 v13, v0, v13, s0                         // 0000002EA154: D501000D 00021B00
	.long 0xd44c0000                                           // 0000002EA15C: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 0000002EA160: 02020CA0
	s_waitcnt lgkmcnt(1)                                       // 0000002EA164: BF89FC17
	v_add_f32_e32 v5, v5, v11                                  // 0000002EA168: 060A1705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EA16C: BF870193
	v_lshlrev_b32_e32 v13, 2, v13                              // 0000002EA170: 301A1A82
	v_cndmask_b32_e64 v0, v0, v6, s0                           // 0000002EA174: D5010000 00020D00
	.long 0xd44a0000                                           // 0000002EA17C: D44A0000
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 0000002EA180: 02021C80
	ds_bpermute_b32 v1, v13, v2                                // 0000002EA184: DACC0000 0100020D
	s_waitcnt lgkmcnt(1)                                       // 0000002EA18C: BF89FC17
	v_add_f32_e32 v3, v3, v7                                   // 0000002EA190: 06060F03
	ds_bpermute_b32 v11, v13, v4                               // 0000002EA194: DACC0000 0B00040D
	ds_bpermute_b32 v12, v13, v5                               // 0000002EA19C: DACC0000 0C00050D
	s_and_b32 s0, s0, vcc_lo                                   // 0000002EA1A4: 8B006A00
	s_waitcnt lgkmcnt(2)                                       // 0000002EA1A8: BF89FC27
	v_add_f32_e32 v6, v2, v1                                   // 0000002EA1AC: 060C0302
	ds_bpermute_b32 v7, v13, v3                                // 0000002EA1B0: DACC0000 0700030D
	ds_bpermute_b32 v13, v13, v10                              // 0000002EA1B8: DACC0000 0D000A0D
	s_waitcnt lgkmcnt(3)                                       // 0000002EA1C0: BF89FC37
	v_dual_add_f32 v0, v4, v11 :: v_dual_lshlrev_b32 v15, 2, v0// 0000002EA1C4: C9221704 000E0082
	s_waitcnt lgkmcnt(2)                                       // 0000002EA1CC: BF89FC27
	v_add_f32_e32 v1, v5, v12                                  // 0000002EA1D0: 06021905
	s_waitcnt lgkmcnt(0)                                       // 0000002EA1D4: BF89FC07
	v_dual_add_f32 v7, v3, v7 :: v_dual_add_f32 v4, v10, v13   // 0000002EA1D8: C9080F03 07041B0A
	ds_bpermute_b32 v10, v15, v6                               // 0000002EA1E0: DACC0000 0A00060F
	ds_bpermute_b32 v2, v15, v0                                // 0000002EA1E8: DACC0000 0200000F
	ds_bpermute_b32 v3, v15, v1                                // 0000002EA1F0: DACC0000 0300010F
	ds_bpermute_b32 v11, v15, v7                               // 0000002EA1F8: DACC0000 0B00070F
	ds_bpermute_b32 v5, v15, v4                                // 0000002EA200: DACC0000 0500040F
	s_and_saveexec_b32 s1, s0                                  // 0000002EA208: BE812000
	s_cbranch_execz 71                                         // 0000002EA20C: BFA50047 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi32ELi1EEEvPKhPKtPtll+0xb2c>
	s_waitcnt lgkmcnt(1)                                       // 0000002EA210: BF89FC17
	v_dual_add_f32 v11, v7, v11 :: v_dual_add_f32 v10, v6, v10 // 0000002EA214: C9081707 0B0A1506
	.long 0x7f183880                                           // 0000002EA21C: 7F183880
	.long 0xd73c0006                                           // 0000002EA220: D73C0006
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000002EA224: 02021081
	s_waitcnt lgkmcnt(0)                                       // 0000002EA228: BF89FC07
	v_dual_add_f32 v14, v4, v5 :: v_dual_add_f32 v3, v1, v3    // 0000002EA22C: C9080B04 0E020701
	.long 0x7e1a398a                                           // 0000002EA234: 7E1A398A
	.long 0x7f1a398c                                           // 0000002EA238: 7F1A398C
	.long 0x7e18398b                                           // 0000002EA23C: 7E18398B
	.long 0xd7006a04                                           // 0000002EA240: D7006A04
	v_cndmask_b32_e32 v1, s8, v6, vcc_lo                       // 0000002EA244: 02020C08
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002EA248: BF8701B3
	v_dual_add_f32 v2, v0, v2 :: v_dual_and_b32 v9, 1, v13     // 0000002EA24C: C9240500 02081A81
	v_add_co_ci_u32_e64 v5, null, s9, v7, vcc_lo               // 0000002EA254: D5207C05 01AA0E09
	.long 0x7f00398c                                           // 0000002EA25C: 7F00398C
	.long 0x7e003982                                           // 0000002EA260: 7E003982
	s_lshl_b64 s[0:1], s[12:13], 1                             // 0000002EA264: 8480810C
	v_and_b32_e32 v8, 1, v12                                   // 0000002EA268: 36101881
	.long 0x7e183983                                           // 0000002EA26C: 7E183983
	.long 0xd7006a06                                           // 0000002EA270: D7006A06
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 0000002EA274: 02000104
	v_and_b32_e32 v13, 1, v0                                   // 0000002EA278: 361A0081
	v_mad_u64_u32 v[0:1], null, s12, 6, v[4:5]                 // 0000002EA27C: D6FE7C00 04110C0C
	v_add_co_ci_u32_e64 v7, null, s1, v5, vcc_lo               // 0000002EA284: D5207C07 01AA0A01
	s_lshl_b64 s[0:1], s[12:13], 2                             // 0000002EA28C: 8480820C
	v_add3_u32 v11, v11, v8, 0x7fff                            // 0000002EA290: D655000B 03FE110B 00007FFF
	.long 0xd7006a08                                           // 0000002EA29C: D7006A08
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 0000002EA2A0: 02000104
	v_and_b32_e32 v12, 1, v12                                  // 0000002EA2A4: 36181881
	v_add3_u32 v10, v10, v9, 0x7fff                            // 0000002EA2A8: D655000A 03FE130A 00007FFF
	v_bfe_u32 v15, v14, 16, 1                                  // 0000002EA2B4: D610000F 0205210E
	v_add_co_ci_u32_e64 v9, null, s1, v5, vcc_lo               // 0000002EA2BC: D5207C09 01AA0A01
	v_add3_u32 v13, v2, v13, 0x7fff                            // 0000002EA2C4: D655000D 03FE1B02 00007FFF
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 0000002EA2D0: D6FE7C01 04050C0D
	.long 0xd7006a02                                           // 0000002EA2D8: D7006A02
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 0000002EA2DC: 02000108
	v_add3_u32 v12, v3, v12, 0x7fff                            // 0000002EA2E0: D655000C 03FE1903 00007FFF
	v_add3_u32 v14, v14, v15, 0x7fff                           // 0000002EA2EC: D655000E 03FE1F0E 00007FFF
	v_add_co_ci_u32_e64 v3, null, s1, v9, vcc_lo               // 0000002EA2F8: D5207C03 01AA1201
	s_clause 0x4                                               // 0000002EA300: BF850004
	global_store_d16_hi_b16 v[4:5], v10, off                   // 0000002EA304: DC960000 007C0A04
	global_store_d16_hi_b16 v[6:7], v11, off                   // 0000002EA30C: DC960000 007C0B06
	global_store_d16_hi_b16 v[8:9], v13, off                   // 0000002EA314: DC960000 007C0D08
	global_store_d16_hi_b16 v[0:1], v12, off                   // 0000002EA31C: DC960000 007C0C00
	global_store_d16_hi_b16 v[2:3], v14, off                   // 0000002EA324: DC960000 007C0E02
	s_endpgm                                                   // 0000002EA32C: BFB00000
		...

