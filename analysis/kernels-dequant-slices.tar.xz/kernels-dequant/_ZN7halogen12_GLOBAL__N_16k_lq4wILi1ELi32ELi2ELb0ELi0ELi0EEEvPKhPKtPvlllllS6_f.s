000000000054b400 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000054B400: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 00000054B408: CA240080 1200008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000054B410: 32040082
	s_ashr_i32 s3, s2, 31                                      // 00000054B414: 86039F02
	v_lshrrev_b32_e32 v14, 6, v0                               // 00000054B418: 321C0086
	s_lshl_b64 s[2:3], s[2:3], 2                               // 00000054B41C: 84828202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054B420: BF8701A9
	v_dual_mov_b32 v4, s3 :: v_dual_lshlrev_b32 v1, 2, v1      // 00000054B424: CA220003 04000282
	v_and_b32_e32 v2, 60, v2                                   // 00000054B42C: 360404BC
	v_or_b32_e32 v3, s2, v14                                   // 00000054B430: 38061C02
	v_bfe_u32 v15, v0, 5, 1                                    // 00000054B434: D610000F 02050B00
	.long 0x7f0e3880                                           // 00000054B43C: 7F0E3880
	v_mov_b32_e32 v17, 0                                       // 00000054B440: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 00000054B444: BF89FC07
	s_clause 0x1                                               // 00000054B448: BF850001
	global_load_b32 v5, v1, s[4:5]                             // 00000054B44C: DC520000 05040001
	global_load_b32 v6, v2, s[4:5]                             // 00000054B454: DC520000 06040002
	s_add_u32 s0, s4, s14                                      // 00000054B45C: 80000E04
	s_addc_u32 s1, s5, s15                                     // 00000054B460: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 00000054B464: 850E9F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[3:4]                  // 00000054B468: 7CA8060C
	s_add_u32 s14, s10, s14                                    // 00000054B46C: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000054B470: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000054B474: 86149F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000054B478: 868E810E
	s_lshr_b32 s20, s20, 27                                    // 00000054B47C: 85149B14
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_and_b32 v16, 31, v0 // 00000054B480: CA640680 0310009F
	s_add_u32 s10, s10, s20                                    // 00000054B488: 800A140A
	s_addc_u32 s11, s11, 0                                     // 00000054B48C: 820B800B
	v_cndmask_b32_e64 v4, 0, s3, vcc_lo                        // 00000054B490: D5010004 01A80680
	s_lshr_b64 s[10:11], s[10:11], 5                           // 00000054B498: 858A850A
	.long 0xd72c0008                                           // 00000054B49C: D72C0008
	v_cndmask_b32_e32 v1, s19, v3, vcc_lo                      // 00000054B4A0: 02020613
	s_add_i32 s11, s10, 1                                      // 00000054B4A4: 810B810A
	v_mad_u64_u32 v[9:10], null, v3, s14, s[0:1]               // 00000054B4A8: D6FE7C09 00001D03
	s_lshr_b32 s19, s11, 31                                    // 00000054B4B0: 85139F0B
	.long 0xd72c0015                                           // 00000054B4B4: D72C0015
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 00000054B4B8: 02001D04
	s_add_i32 s11, s11, s19                                    // 00000054B4BC: 810B130B
	.long 0xd72c0016                                           // 00000054B4C0: D72C0016
	v_cndmask_b32_e32 v1, s18, v4, vcc_lo                      // 00000054B4C4: 02020812
	s_ashr_i32 s11, s11, 1                                     // 00000054B4C8: 860B810B
	s_add_u32 s0, s4, s16                                      // 00000054B4CC: 80001004
	.long 0xd72c0013                                           // 00000054B4D0: D72C0013
	v_cndmask_b32_e32 v1, s11, v15, vcc_lo                     // 00000054B4D4: 02021E0B
	s_addc_u32 s1, s5, s17                                     // 00000054B4D8: 82011105
	.long 0xd72c000d                                           // 00000054B4DC: D72C000D
	v_cndmask_b32_e32 v0, v3, v15, vcc_lo                      // 00000054B4E0: 02001F03
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 00000054B4E4: CA100080 01020080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000054B4EC: BF870223
	v_add_nc_u32_e32 v4, s11, v19                              // 00000054B4F0: 4A08260B
	v_add_nc_u32_e32 v19, v19, v16                             // 00000054B4F4: 4A262113
	v_add3_u32 v10, v21, v10, v13                              // 00000054B4F8: D655000A 04361515
	s_waitcnt vmcnt(1)                                         // 00000054B500: BF8907F7
	v_bfe_u32 v11, v5, 16, 1                                   // 00000054B504: D610000B 02052105
	s_waitcnt vmcnt(0)                                         // 00000054B50C: BF8903F7
	v_bfe_u32 v20, v6, 16, 1                                   // 00000054B510: D6100014 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054B518: BF8701A2
	v_add3_u32 v5, v5, v11, 0x7fff                             // 00000054B51C: D6550005 03FE1705 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v3, s[0:1]              // 00000054B528: D6FE7C0B 00020612
	v_add3_u32 v6, v6, v20, 0x7fff                             // 00000054B530: D6550006 03FE2906 00007FFF
	v_mov_b32_e32 v3, 0                                        // 00000054B53C: 7E060280
	v_min_i32_e32 v20, s10, v4                                 // 00000054B540: 2228080A
	.long 0x7e0e3985                                           // 00000054B544: 7E0E3985
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v5, 2, v0       // 00000054B548: CA220080 04040082
	v_add3_u32 v21, v8, v12, v22                               // 00000054B550: D6550015 045A1908
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054B558: BF870003
	v_and_or_b32 v6, 0xffff0000, v6, v7                        // 00000054B55C: D6570006 041E0CFF FFFF0000
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 00000054B568: 7C822913
	ds_store_b32 v5, v6                                        // 00000054B56C: D8340000 00000605
	s_waitcnt lgkmcnt(0)                                       // 00000054B574: BF89FC07
	s_barrier                                                  // 00000054B578: BFBD0000
	buffer_gl0_inv                                             // 00000054B57C: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 00000054B584: BE81206A
	s_cbranch_execz 21                                         // 00000054B588: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1e0>
	v_lshlrev_b32_e32 v1, 1, v19                               // 00000054B58C: 30022681
	v_lshlrev_b32_e32 v3, 4, v19                               // 00000054B590: 30062684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054B594: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000054B598: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000054B59C: 3408069F
	.long 0xd7000001                                           // 00000054B5A0: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 00000054B5A4: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054B5A8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s0                  // 00000054B5AC: D5207C02 00020515
	.long 0xd7000003                                           // 00000054B5B4: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 00000054B5B8: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 00000054B5BC: D5207C04 0002090A
	s_clause 0x1                                               // 00000054B5C4: BF850001
	global_load_d16_b16 v5, v[1:2], off                        // 00000054B5C8: DC820000 057C0001
	global_load_b128 v[1:4], v[3:4], off                       // 00000054B5D0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000054B5D8: BF8907F7
	v_cvt_f32_f16_e32 v18, v5                                  // 00000054B5DC: 7E241705
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054B5E0: 8C7E017E
	s_and_saveexec_b32 s1, vcc_lo                              // 00000054B5E4: BE81206A
	s_cbranch_execz 207                                        // 00000054B5E8: BFA500CF <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x528>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000054B5EC: BF870131
	v_dual_mov_b32 v24, v18 :: v_dual_add_nc_u32 v5, 32, v19   // 00000054B5F0: CA200112 180426A0
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v12, 5, v19    // 00000054B5F8: CA220080 110C2685
	s_mov_b32 s4, 0                                            // 00000054B600: BE840080
	v_lshlrev_b32_e32 v22, 4, v5                               // 00000054B604: 302C0A84
	v_lshlrev_b32_e32 v23, 1, v5                               // 00000054B608: 302E0A81
	s_branch 166                                               // 00000054B60C: BFA000A6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x4a8>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000054B610: 8C7E057E
	v_ashrrev_i32_e32 v13, 31, v12                             // 00000054B614: 341A189F
	v_lshrrev_b32_e32 v41, 6, v1                               // 00000054B618: 32520286
	v_lshrrev_b32_e32 v42, 14, v1                              // 00000054B61C: 3254028E
	v_and_b32_e32 v43, 0xff, v2                                // 00000054B620: 365604FF 000000FF
	v_lshrrev_b32_e32 v44, 6, v2                               // 00000054B628: 32580486
	.long 0xd73c0019                                           // 00000054B62C: D73C0019
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000054B630: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 00000054B634: 361A02FF 000000FF
	v_and_b32_e32 v41, 0x3fc, v41                              // 00000054B63C: 365252FF 000003FC
	v_and_b32_e32 v42, 0x3fc, v42                              // 00000054B644: 365454FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 00000054B64C: 32020296
	v_lshrrev_b32_e32 v45, 14, v2                              // 00000054B650: 325A048E
	.long 0xd7000025                                           // 00000054B654: D7000025
	v_cndmask_b32_e32 v1, s6, v25, vcc_lo                      // 00000054B658: 02023206
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054B65C: BF870001
	v_add_co_ci_u32_e64 v38, null, s7, v26, s0                 // 00000054B660: D5207C26 00023407
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000054B668: 301A1A82
	ds_load_b32 v41, v41                                       // 00000054B66C: D8D80000 29000029
	ds_load_b32 v42, v42                                       // 00000054B674: D8D80000 2A00002A
	s_clause 0x3                                               // 00000054B67C: BF850003
	global_load_b128 v[25:28], v[37:38], off                   // 00000054B680: DC5E0000 197C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 00000054B688: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 00000054B690: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 00000054B698: DC5E0030 257C0025
	v_lshrrev_b32_e32 v2, 22, v2                               // 00000054B6A0: 32040496
	ds_load_b32 v13, v13                                       // 00000054B6A4: D8D80000 0D00000D
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000054B6AC: 360202FF 000003FC
	v_lshlrev_b32_e32 v43, 2, v43                              // 00000054B6B4: 30565682
	v_and_b32_e32 v44, 0x3fc, v44                              // 00000054B6B8: 365858FF 000003FC
	v_and_b32_e32 v45, 0x3fc, v45                              // 00000054B6C0: 365A5AFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 00000054B6C8: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 00000054B6D0: D8D80000 01000001
	ds_load_b32 v43, v43                                       // 00000054B6D8: D8D80000 2B00002B
	ds_load_b32 v44, v44                                       // 00000054B6E0: D8D80000 2C00002C
	ds_load_b32 v45, v45                                       // 00000054B6E8: D8D80000 2D00002D
	ds_load_b32 v2, v2                                         // 00000054B6F0: D8D80000 02000002
	v_add_nc_u32_e32 v22, 0x200, v22                           // 00000054B6F8: 4A2C2CFF 00000200
	v_add_nc_u32_e32 v23, 64, v23                              // 00000054B700: 4A2E2EC0
	v_add_nc_u32_e32 v12, 0x400, v12                           // 00000054B704: 4A1818FF 00000400
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000054B70C: 8B006A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000054B710: BF870149
	s_or_b32 s4, s0, s4                                        // 00000054B714: 8C040400
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 00000054B718: BF890C57
	v_dot2_f32_bf16 v13, v25, v13, 0                           // 00000054B71C: CC1A400D 1A021B19
	v_and_b32_e32 v25, 0xff, v3                                // 00000054B724: 363206FF 000000FF
	v_dot2_f32_bf16 v13, v26, v41, v13                         // 00000054B72C: CC1A400D 1C36531A
	v_lshrrev_b32_e32 v26, 6, v3                               // 00000054B734: 32340686
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054B738: BF8701A2
	v_dot2_f32_bf16 v13, v27, v42, v13                         // 00000054B73C: CC1A400D 1C36551B
	v_lshrrev_b32_e32 v27, 14, v3                              // 00000054B744: 3236068E
	v_and_b32_e32 v26, 0x3fc, v26                              // 00000054B748: 363434FF 000003FC
	v_lshrrev_b32_e32 v3, 22, v3                               // 00000054B750: 32060696
	s_waitcnt lgkmcnt(4)                                       // 00000054B754: BF89FC47
	v_dot2_f32_bf16 v1, v28, v1, v13                           // 00000054B758: CC1A4001 1C36031C
	v_lshlrev_b32_e32 v13, 2, v25                              // 00000054B760: 301A3282
	v_and_b32_e32 v27, 0x3fc, v27                              // 00000054B764: 363636FF 000003FC
	v_and_b32_e32 v25, 0xff, v4                                // 00000054B76C: 363208FF 000000FF
	v_lshrrev_b32_e32 v28, 6, v4                               // 00000054B774: 32380886
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 00000054B778: BF890837
	v_dot2_f32_bf16 v1, v29, v43, v1                           // 00000054B77C: CC1A4001 1C06571D
	ds_load_b32 v13, v13                                       // 00000054B784: D8D80000 0D00000D
	ds_load_b32 v26, v26                                       // 00000054B78C: D8D80000 1A00001A
	ds_load_b32 v27, v27                                       // 00000054B794: D8D80000 1B00001B
	v_lshrrev_b32_e32 v29, 14, v4                              // 00000054B79C: 323A088E
	s_waitcnt lgkmcnt(5)                                       // 00000054B7A0: BF89FC57
	v_dot2_f32_bf16 v1, v30, v44, v1                           // 00000054B7A4: CC1A4001 1C06591E
	v_lshrrev_b32_e32 v4, 22, v4                               // 00000054B7AC: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 00000054B7B0: 360606FF 000003FC
	v_lshlrev_b32_e32 v25, 2, v25                              // 00000054B7B8: 30323282
	v_and_b32_e32 v28, 0x3fc, v28                              // 00000054B7BC: 363838FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 00000054B7C4: BF89FC47
	v_dot2_f32_bf16 v1, v31, v45, v1                           // 00000054B7C8: CC1A4001 1C065B1F
	v_and_b32_e32 v29, 0x3fc, v29                              // 00000054B7D0: 363A3AFF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000054B7D8: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 00000054B7E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054B7E4: BF870003
	v_dot2_f32_bf16 v1, v32, v2, v1                            // 00000054B7E8: CC1A4001 1C060520
	ds_load_b32 v2, v3                                         // 00000054B7F0: D8D80000 02000003
	ds_load_b32 v3, v25                                        // 00000054B7F8: D8D80000 03000019
	ds_load_b32 v25, v28                                       // 00000054B800: D8D80000 1900001C
	ds_load_b32 v28, v29                                       // 00000054B808: D8D80000 1C00001D
	ds_load_b32 v29, v4                                        // 00000054B810: D8D80000 1D000004
	v_mov_b32_e32 v4, v8                                       // 00000054B818: 7E080308
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000054B81C: BF890477
	v_dot2_f32_bf16 v1, v33, v13, v1                           // 00000054B820: CC1A4001 1C061B21
	s_waitcnt lgkmcnt(6)                                       // 00000054B828: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054B82C: BF8700A1
	v_dot2_f32_bf16 v1, v34, v26, v1                           // 00000054B830: CC1A4001 1C063522
	s_waitcnt lgkmcnt(5)                                       // 00000054B838: BF89FC57
	v_dot2_f32_bf16 v1, v35, v27, v1                           // 00000054B83C: CC1A4001 1C063723
	s_waitcnt lgkmcnt(4)                                       // 00000054B844: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000054B848: BF870131
	v_dot2_f32_bf16 v1, v36, v2, v1                            // 00000054B84C: CC1A4001 1C060524
	v_mov_b32_e32 v2, v6                                       // 00000054B854: 7E040306
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000054B858: BF890037
	v_dot2_f32_bf16 v1, v37, v3, v1                            // 00000054B85C: CC1A4001 1C060725
	v_mov_b32_e32 v3, v7                                       // 00000054B864: 7E060307
	s_waitcnt lgkmcnt(2)                                       // 00000054B868: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054B86C: BF8700A2
	v_dot2_f32_bf16 v1, v38, v25, v1                           // 00000054B870: CC1A4001 1C063326
	s_waitcnt lgkmcnt(1)                                       // 00000054B878: BF89FC17
	v_dot2_f32_bf16 v1, v39, v28, v1                           // 00000054B87C: CC1A4001 1C063927
	s_waitcnt lgkmcnt(0)                                       // 00000054B884: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000054B888: BF870121
	v_dot2_f32_bf16 v8, v40, v29, v1                           // 00000054B88C: CC1A4008 1C063B28
	v_mov_b32_e32 v1, v5                                       // 00000054B894: 7E020305
	v_dual_fmac_f32 v17, v18, v8 :: v_dual_mov_b32 v18, v24    // 00000054B898: C8101112 11120118
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000054B8A0: 917E047E
	s_cbranch_execz 31                                         // 00000054B8A4: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x524>
	s_waitcnt vmcnt(0)                                         // 00000054B8A8: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v19, 32, v19    // 00000054B8AC: CA200102 061226A0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 00000054B8B4: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 00000054B8BC: 7E0E0303
	s_mov_b32 s5, exec_lo                                      // 00000054B8C0: BE85007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054B8C4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 00000054B8C8: 7C8C2913
	.long 0xd4c1007e                                           // 00000054B8CC: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 00000054B8D0: 02022913
	s_cbranch_execz 65358                                      // 00000054B8D4: BFA5FF4E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x210>
	v_ashrrev_i32_e32 v6, 31, v23                              // 00000054B8D8: 340C2E9F
	v_ashrrev_i32_e32 v8, 31, v22                              // 00000054B8DC: 34102C9F
	.long 0xd7000005                                           // 00000054B8E0: D7000005
	v_cndmask_b32_e32 v1, v11, v23, vcc_lo                     // 00000054B8E4: 02022F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054B8E8: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v21, v6, s0                  // 00000054B8EC: D5207C06 00020D15
	.long 0xd7000007                                           // 00000054B8F4: D7000007
	v_cndmask_b32_e32 v1, v9, v22, vcc_lo                      // 00000054B8F8: 02022D09
	v_add_co_ci_u32_e64 v8, null, v10, v8, s0                  // 00000054B8FC: D5207C08 0002110A
	s_clause 0x1                                               // 00000054B904: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 00000054B908: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 00000054B910: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 00000054B918: BF8907F7
	v_cvt_f32_f16_e32 v24, v13                                 // 00000054B91C: 7E30170D
	s_branch 65339                                             // 00000054B920: BFA0FF3B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x210>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000054B924: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000054B928: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054B92C: 8C7E017E
	s_waitcnt vmcnt(0)                                         // 00000054B930: BF8903F7
	.long 0xd71f0001                                           // 00000054B934: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000054B938: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000054B93C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000054B940: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 00000054B944: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 00000054B948: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000054B94C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000054B950: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000054B954: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 00000054B958: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 00000054B95C: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000054B960: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000054B964: 02080901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000054B968: BF870211
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000054B96C: 30080882
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000054B970: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000054B974: 30040482
	ds_bpermute_b32 v2, v2, v17                                // 00000054B978: DACC0000 02001102
	s_waitcnt lgkmcnt(0)                                       // 00000054B980: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 00000054B984: 06040511
	ds_bpermute_b32 v3, v3, v2                                 // 00000054B988: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 00000054B990: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 00000054B994: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 00000054B998: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 00000054B9A0: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054B9A4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000054B9A8: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000054B9AC: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000054B9B0: 30080882
	s_waitcnt lgkmcnt(0)                                       // 00000054B9B4: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 00000054B9B8: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 00000054B9BC: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 00000054B9C4: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000054B9C8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000054B9CC: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 00000054B9D0: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 00000054B9D4: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 00000054B9DC: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 00000054B9E0: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v16                                   // 00000054B9E8: 7D942080
	s_cbranch_execz 8                                          // 00000054B9EC: BFA50008 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x610>
	v_lshlrev_b32_e32 v3, 2, v15                               // 00000054B9F0: 30061E82
	s_waitcnt lgkmcnt(0)                                       // 00000054B9F4: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 00000054B9F8: 06020501
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054B9FC: BF870002
	v_lshl_or_b32 v3, v14, 3, v3                               // 00000054BA00: D6560003 040D070E
	ds_store_b32 v3, v1 offset:1024                            // 00000054BA08: D8340400 00000103
	s_or_b32 exec_lo, exec_lo, s0                              // 00000054BA10: 8C7E007E
	v_or_b32_e32 v1, s2, v0                                    // 00000054BA14: 38020002
	s_waitcnt lgkmcnt(0)                                       // 00000054BA18: BF89FC07
	v_mov_b32_e32 v2, s3                                       // 00000054BA1C: 7E040203
	.long 0xd44c0000                                           // 00000054BA20: D44C0000
	v_cndmask_b32_e32 v1, 4, v0, vcc_lo                        // 00000054BA24: 02020084
	s_barrier                                                  // 00000054BA28: BFBD0000
	buffer_gl0_inv                                             // 00000054BA2C: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000054BA34: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 00000054BA38: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000054BA3C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000054BA40: BE812000
	s_cbranch_execz 22                                         // 00000054BA44: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x6a0>
	v_lshlrev_b32_e32 v0, 3, v0                                // 00000054BA48: 30000083
	ds_load_b64 v[3:4], v0 offset:1024                         // 00000054BA4C: D9D80400 03000000
	s_waitcnt lgkmcnt(0)                                       // 00000054BA54: BF89FC07
	v_add_f32_e32 v0, 0, v3                                    // 00000054BA58: 06000680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000054BA5C: BF870121
	v_add_f32_e32 v3, v0, v4                                   // 00000054BA60: 06060900
	.long 0xd73c0000                                           // 00000054BA64: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000054BA68: 02020281
	v_bfe_u32 v4, v3, 16, 1                                    // 00000054BA6C: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054BA74: BF870092
	.long 0xd7006a00                                           // 00000054BA78: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000054BA7C: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000054BA80: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054BA88: BF870003
	v_add3_u32 v2, v3, v4, 0x7fff                              // 00000054BA8C: D6550002 03FE0903 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000054BA98: DC960000 007C0200
	s_endpgm                                                   // 00000054BAA0: BFB00000
		...

