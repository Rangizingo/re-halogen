0000000000516a00 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x2                                               // 000000516A00: BF850002
	s_load_b128 s[24:27], s[0:1], 0x10                         // 000000516A04: F4080600 F8000010
	s_load_b256 s[12:19], s[0:1], 0x20                         // 000000516A0C: F40C0300 F8000020
	s_load_b128 s[20:23], s[0:1], 0x40                         // 000000516A14: F4080500 F8000040
	s_mov_b32 s10, s3                                          // 000000516A1C: BE8A0003
	v_lshrrev_b32_e32 v66, 5, v0                               // 000000516A20: 32840085
	v_and_b32_e32 v67, 31, v0                                  // 000000516A24: 3686009F
	s_waitcnt lgkmcnt(0)                                       // 000000516A28: BF89FC07
	s_ashr_i32 s34, s25, 31                                    // 000000516A2C: 86229F19
	s_mul_i32 s11, s27, s10                                    // 000000516A30: 960B0A1B
	s_lshr_b32 s3, s34, 25                                     // 000000516A34: 85039922
	s_add_i32 s4, s11, s27                                     // 000000516A38: 81041B0B
	s_add_i32 s3, s25, s3                                      // 000000516A3C: 81030319
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000516A40: BF870499
	s_ashr_i32 s3, s3, 7                                       // 000000516A44: 86038703
	s_min_i32 s3, s3, s4                                       // 000000516A48: 89030403
	s_mov_b32 s4, exec_lo                                      // 000000516A4C: BE84007E
	s_sub_i32 s3, s3, s11                                      // 000000516A50: 81830B03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000516A54: BF870499
	s_lshl_b32 s9, s3, 3                                       // 000000516A58: 84098303
	.long 0xd4c3007e                                           // 000000516A5C: D4C3007E
	v_cndmask_b32_e32 v1, s9, v66, vcc_lo                      // 000000516A60: 02028409
	s_xor_b32 s4, exec_lo, s4                                  // 000000516A64: 8D04047E
	v_lshlrev_b32_e32 v8, 3, v67                               // 000000516A68: 30108683
	s_or_saveexec_b32 s27, s4                                  // 000000516A6C: BE9B2204
	s_clause 0x1                                               // 000000516A70: BF850001
	s_load_b32 s33, s[0:1], 0x54                               // 000000516A74: F4000840 F8000054
	s_load_b128 s[28:31], s[0:1], null                         // 000000516A7C: F4080700 F8000000
	s_xor_b32 exec_lo, exec_lo, s27                            // 000000516A84: 8D7E1B7E
	s_cbranch_execz 503                                        // 000000516A88: BFA501F7 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x868>
	s_add_i32 s35, s24, -1                                     // 000000516A8C: 8123C118
	s_cmp_lg_u64 s[22:23], 0                                   // 000000516A90: BF118016
	v_dual_mov_b32 v9, v66 :: v_dual_and_b32 v2, 1, v0         // 000000516A94: CA240142 09020081
	s_cselect_b32 s36, -1, 0                                   // 000000516A9C: 982480C1
	s_abs_i32 s37, s3                                          // 000000516AA0: BEA51503
	v_lshlrev_b32_e32 v8, 3, v67                               // 000000516AA4: 30108683
	s_cvt_f32_u32 s0, s37                                      // 000000516AA8: BE806525
	v_lshlrev_b32_e32 v1, 2, v67                               // 000000516AAC: 30028682
	v_and_b32_e32 v4, 2, v0                                    // 000000516AB0: 36080082
	v_and_b32_e32 v5, 4, v0                                    // 000000516AB4: 360A0084
	v_rcp_iflag_f32_e32 v3, s0                                 // 000000516AB8: 7E065600
	v_and_b32_e32 v6, 8, v0                                    // 000000516ABC: 360C0088
	v_add_nc_u32_e32 v7, s11, v66                              // 000000516AC0: 4A0E840B
	.long 0xd44a0001                                           // 000000516AC4: D44A0001
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000516AC8: 02020480
	v_lshl_or_b32 v2, v66, 8, v8                               // 000000516ACC: D6560002 04211142
	s_ashr_i32 s40, s3, 31                                     // 000000516AD4: 86289F03
	s_sub_i32 s8, 0, s37                                       // 000000516AD8: 81882580
	s_mul_i32 s43, s40, 0x1400                                 // 000000516ADC: 962BFF28 00001400
	s_lshl_b32 s6, s3, 7                                       // 000000516AE4: 84068703
	.long 0xd44c0000                                           // 000000516AE8: D44C0000
	v_cndmask_b32_e32 v1, 16, v67, vcc_lo                      // 000000516AEC: 02028690
	v_readfirstlane_b32 s4, v3                                 // 000000516AF0: 7E080503
	s_lshl_b32 s41, s3, 8                                      // 000000516AF4: 84298803
	.long 0xd44a0003                                           // 000000516AF8: D44A0003
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000516AFC: 02020880
	.long 0xd44a0005                                           // 000000516B00: D44A0005
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 000000516B04: 02020C80
	v_lshl_or_b32 v1, v7, 7, v1                                // 000000516B08: D6560001 04050F07
	s_mul_f32 s7, s4, 0x4f7ffffe                               // 000000516B10: A207FF04 4F7FFFFE
	.long 0xd44a0004                                           // 000000516B18: D44A0004
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000516B1C: 02020A80
	v_subrev_nc_u32_e32 v10, s43, v2                           // 000000516B20: 4E14042B
	s_sub_i32 s42, 0, s6                                       // 000000516B24: 81AA0680
	s_cvt_u32_f32 s7, s7                                       // 000000516B28: BE876707
	s_mov_b32 s38, s25                                         // 000000516B2C: BEA60019
	s_mov_b32 s39, 0                                           // 000000516B30: BEA70080
	s_mov_b32 s44, 0x76543210                                  // 000000516B34: BEAC00FF 76543210
	s_mul_i32 s8, s8, s7                                       // 000000516B3C: 96080708
	s_mov_b32 s45, 0x3db504f3                                  // 000000516B40: BEAD00FF 3DB504F3
	s_mul_hi_u32 s6, s7, s8                                    // 000000516B48: 96860807
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000516B4C: BF870009
	s_add_i32 s43, s7, s6                                      // 000000516B50: 812B0607
	s_branch 161                                               // 000000516B54: BFA000A1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3dc>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000516B58: BF870091
	.long 0xd7006a02                                           // 000000516B5C: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000516B60: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000516B64: D5207C03 01AA060D
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000516B6C: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000516B74: DC820006 027C0002
	v_add_f32_e32 v3, v16, v14                                 // 000000516B7C: 06061D10
	s_waitcnt vmcnt(0)                                         // 000000516B80: BF8903F7
	v_fma_mix_f32 v5, v15, v2, v13 op_sel_hi:[0,1,0]           // 000000516B84: CC200005 1436050F
	v_sub_f32_e32 v4, v16, v14                                 // 000000516B8C: 08081D10
	v_fma_mix_f32 v2, -v15, v2, v13 op_sel_hi:[0,1,0]          // 000000516B90: CC200002 3436050F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000516B98: BF870121
	v_dual_add_f32 v6, v3, v5 :: v_dual_add_f32 v7, v4, v2     // 000000516B9C: C9080B03 06060504
	v_sub_f32_e32 v2, v4, v2                                   // 000000516BA4: 08040504
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000516BA8: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000516BB0: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000516BB8: BF870241
	v_dual_add_f32 v4, v6, v4 :: v_dual_sub_f32 v3, v3, v5     // 000000516BBC: C90A0906 04020B03
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000516BC4: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000516BCC: D5010007 20060F07
	.long 0xd72c0006                                           // 000000516BD4: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v12, vcc_lo                  // 000000516BD8: 020218FF 00001400
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000516BE0: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000516BE8: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4)                            // 000000516BF0: BF870004
	v_add_f32_e32 v5, v7, v5                                   // 000000516BF4: 060A0B07
	v_mov_b32_dpp v14, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000516BF8: 7E1C02FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000516C00: D5010002 20060502
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000516C08: 7E0E02FA FF016204
	v_add_f32_e32 v3, v3, v13                                  // 000000516C10: 06061B03
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000516C14: D5010004 200E0904
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000516C1C: 7E1802FA FF016205
	v_add_f32_e32 v2, v2, v14                                  // 000000516C24: 06041D02
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000516C28: D5010005 200E0B05
	v_mov_b32_dpp v13, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000516C30: 7E1A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000516C38: D5010003 200E0703
	v_add_f32_e32 v4, v4, v7                                   // 000000516C40: 06080F04
	v_mov_b32_dpp v14, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000516C44: 7E1C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000516C4C: D5010002 200E0502
	v_add_f32_e32 v5, v5, v12                                  // 000000516C54: 060A1905
	.long 0xd72c0007                                           // 000000516C58: D72C0007
	v_cndmask_b32_e32 v1, s41, v11, vcc_lo                     // 000000516C5C: 02021629
	v_add_f32_e32 v3, v3, v13                                  // 000000516C60: 06061B03
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000516C64: 7E1602FA FF016404
	v_add_f32_e32 v2, v2, v14                                  // 000000516C6C: 06041D02
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000516C70: D5010004 20120904
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000516C78: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000516C80: D5010005 20120B05
	v_mov_b32_dpp v13, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000516C88: 7E1A02FA FF016403
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000516C90: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000516C98: D5010002 20120502
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000516CA0: D5010003 20120703
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v5, v5, v12   // 000000516CA8: C9081704 04041905
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000516CB0: BF8701A3
	v_dual_add_f32 v2, v2, v14 :: v_dual_add_nc_u32 v9, 8, v9  // 000000516CB4: C9201D02 02081288
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000516CBC: 4C0C0F06
	v_mov_b32_dpp v11, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000516CC0: 7E1602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000516CC8: D5010004 20160904
	v_add_f32_e32 v3, v3, v13                                  // 000000516CD0: 06061B03
	v_mov_b32_dpp v12, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000516CD4: 7E1802FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000516CDC: D5010005 20160B05
	v_mov_b32_dpp v14, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000516CE4: 7E1C02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000516CEC: D5010002 20160502
	v_add_f32_e32 v4, v4, v11                                  // 000000516CF4: 06081704
	v_mov_b32_dpp v13, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000516CF8: 7E1A02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000516D00: D5010003 20160703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000516D08: BF870214
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v2, v2, v14   // 000000516D0C: C9081905 05021D02
	v_mov_b32_e32 v11, v4                                      // 000000516D14: 7E160304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000516D18: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000516D20: BF870213
	v_dual_add_f32 v3, v3, v13 :: v_dual_mov_b32 v12, v5       // 000000516D24: C9101B03 030C0105
	v_mov_b32_e32 v14, v2                                      // 000000516D2C: 7E1C0302
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000516D30: BF870224
	v_permlanex16_b32 v11, v11, s44, 0xfedcba98                // 000000516D34: D65C000B 03FC590B FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000516D40: D5010005 20020B05
	v_mov_b32_e32 v13, v3                                      // 000000516D48: 7E1A0303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000516D4C: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000516D54: D5010003 20020703
	v_permlanex16_b32 v12, v12, s44, 0xfedcba98                // 000000516D5C: D65C000C 03FC590C FEDCBA98
	v_permlanex16_b32 v14, v14, s44, 0xfedcba98                // 000000516D68: D65C000E 03FC590E FEDCBA98
	v_add_f32_e32 v4, v4, v11                                  // 000000516D74: 06081704
	v_permlanex16_b32 v13, v13, s44, 0xfedcba98                // 000000516D78: D65C000D 03FC590D FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s9, v9                            // 000000516D84: 7C861209
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_nc_u32 v6, v10, v6// 000000516D88: C9201905 05060D0A
	v_add_f32_e32 v7, v2, v14                                  // 000000516D90: 060E1D02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000516D94: BF870194
	v_dual_add_f32 v11, v3, v13 :: v_dual_add_nc_u32 v10, 0x800, v10// 000000516D98: C9201B03 0B0A14FF 00000800
	v_fma_mixhi_f16 v2, v5, s45, 0                             // 000000516DA4: CC220002 02005B05
	v_fma_mixlo_f16 v2, v4, s45, 0                             // 000000516DAC: CC210002 02005B04
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000516DB4: BF870214
	v_fma_mixhi_f16 v3, v7, s45, 0                             // 000000516DB8: CC220003 02005B07
	v_fma_mixlo_f16 v3, v11, s45, 0                            // 000000516DC0: CC210003 02005B0B
	s_or_b32 s39, vcc_lo, s39                                  // 000000516DC8: 8C27276A
	ds_store_b64 v6, v[2:3]                                    // 000000516DCC: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s39                       // 000000516DD4: 917E277E
	s_cbranch_execz 290                                        // 000000516DD8: BFA50122 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x864>
	.long 0xd72d0002                                           // 000000516DDC: D72D0002
	v_cndmask_b32_e32 v0, v9, v43, vcc_lo                      // 000000516DE0: 02005709
	s_mov_b32 s6, -1                                           // 000000516DE4: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000516DE8: BF870091
	.long 0xd72c0003                                           // 000000516DEC: D72C0003
	v_cndmask_b32_e32 v0, v2, v37, vcc_lo                      // 000000516DF0: 02004B02
	v_sub_nc_u32_e32 v3, v9, v3                                // 000000516DF4: 4C060709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000516DF8: BF870121
	v_subrev_nc_u32_e32 v5, s37, v3                            // 000000516DFC: 4E0A0625
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000516E00: 7C960625
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000516E04: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000516E0C: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000516E10: 02040902
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000516E14: 7C960625
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000516E18: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000516E1C: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000516E20: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s36                        // 000000516E24: 916A247E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000516E28: BF870091
	v_xor_b32_e32 v12, s40, v2                                 // 000000516E2C: 3A180428
	v_subrev_nc_u32_e32 v11, s40, v12                          // 000000516E30: 4E161828
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000516E34: BF8700A1
	v_mad_u64_u32 v[6:7], null, s42, v11, v[1:2]               // 000000516E38: D6FE7C06 0406162A
	v_min_i32_e32 v2, s35, v11                                 // 000000516E40: 22041623
	v_mad_i64_i32 v[4:5], null, v2, s38, 0                     // 000000516E44: D6FF7C04 02004D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000516E4C: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000516E50: 340E0C9F
	.long 0xd73c0002                                           // 000000516E54: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000516E58: 02020C81
	s_cbranch_vccnz 212                                        // 000000516E5C: BFA400D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7b0>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000516E60: BF870093
	.long 0xd7006a06                                           // 000000516E64: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000516E68: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000516E6C: D5207C07 01AA0F05
	.long 0x7f3a3880                                           // 000000516E74: 7F3A3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000516E78: BF870112
	.long 0xd73c0006                                           // 000000516E7C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000516E80: 02020C81
	.long 0x7f40399d                                           // 000000516E84: 7F40399D
	s_waitcnt lgkmcnt(0)                                       // 000000516E88: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000516E8C: BF870092
	.long 0xd7006a0d                                           // 000000516E90: D7006A0D
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000516E94: 02020C1E
	v_add_co_ci_u32_e64 v14, null, s31, v7, vcc_lo             // 000000516E98: D5207C0E 01AA0E1F
	.long 0xd7006a06                                           // 000000516EA0: D7006A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 000000516EA4: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 000000516EA8: BF870001
	v_add_co_ci_u32_e64 v7, null, s23, v7, vcc_lo              // 000000516EAC: D5207C07 01AA0E17
	global_load_b64 v[13:14], v[13:14], off                    // 000000516EB4: DC560000 0D7C000D
	.long 0xd7006a0f                                           // 000000516EBC: D7006A0F
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000516EC0: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 000000516EC4: DC560000 067C0006
	v_add_co_ci_u32_e64 v16, null, s13, v3, vcc_lo             // 000000516ECC: D5207C10 01AA060D
	s_clause 0x1                                               // 000000516ED4: BF850001
	global_load_b32 v17, v[15:16], off                         // 000000516ED8: DC520000 117C000F
	global_load_d16_b16 v15, v[15:16], off offset:4            // 000000516EE0: DC820004 0F7C000F
	s_waitcnt vmcnt(3)                                         // 000000516EE8: BF890FF7
	.long 0x7e20390d                                           // 000000516EEC: 7E20390D
	s_waitcnt vmcnt(2)                                         // 000000516EF0: BF890BF7
	v_and_b32_e32 v39, 0xffff0000, v6                          // 000000516EF4: 364E0CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000516EFC: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000516F00: BF870093
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000516F04: 30202090
	v_mul_f32_e32 v20, 0xbfb8aa3b, v16                         // 000000516F08: 102820FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000516F10: BF870291
	v_exp_f32_e32 v20, v20                                     // 000000516F14: 7E284B14
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_and_b32 v13, 0xffff0000, v13// 000000516F18: C92428F2 140C1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000516F24: BF870111
	v_mul_f32_e32 v19, 0xbfb8aa3b, v13                         // 000000516F28: 10261AFF BFB8AA3B
	v_div_scale_f32 v24, null, v20, v20, v16                   // 000000516F30: D6FC7C18 04422914
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000516F38: BF8701B2
	v_exp_f32_e32 v19, v19                                     // 000000516F3C: 7E264B13
	v_lshlrev_b32_e32 v18, 16, v14                             // 000000516F40: 30241C90
	v_div_scale_f32 v37, s7, v16, v20, v16                     // 000000516F44: D6FC0725 04422910
	v_rcp_f32_e32 v28, v24                                     // 000000516F4C: 7E385518
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000516F50: BF870196
	v_add_f32_e32 v19, 1.0, v19                                // 000000516F54: 062626F2
	v_mul_f32_e32 v21, 0xbfb8aa3b, v18                         // 000000516F58: 102A24FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000516F60: BF870195
	v_fma_f32 v36, -v24, v28, 1.0                              // 000000516F64: D6130024 23CA3918
	v_div_scale_f32 v23, null, v19, v19, v13                   // 000000516F6C: D6FC7C17 04362713
	s_delay_alu instid0(VALU_DEP_3)                            // 000000516F74: BF870003
	v_exp_f32_e32 v21, v21                                     // 000000516F78: 7E2A4B15
	v_and_b32_e32 v14, 0xffff0000, v14                         // 000000516F7C: 361C1CFF FFFF0000
	v_div_scale_f32 v33, vcc_lo, v13, v19, v13                 // 000000516F84: D6FC6A21 0436270D
	v_fmac_f32_e32 v28, v36, v28                               // 000000516F8C: 56383924
	v_rcp_f32_e32 v26, v23                                     // 000000516F90: 7E345517
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000516F94: BF870186
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_mul_f32 v22, 0xbfb8aa3b, v14// 000000516F98: C9062AF2 15161CFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000516FA4: BF870115
	v_fma_f32 v34, -v23, v26, 1.0                              // 000000516FA8: D6130022 23CA3517
	v_div_scale_f32 v25, null, v21, v21, v18                   // 000000516FB0: D6FC7C19 044A2B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000516FB8: BF8701A3
	v_exp_f32_e32 v22, v22                                     // 000000516FBC: 7E2C4B16
	v_div_scale_f32 v35, s6, v18, v21, v18                     // 000000516FC0: D6FC0623 044A2B12
	v_fmac_f32_e32 v26, v34, v26                               // 000000516FC8: 56343522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000516FCC: BF870293
	v_rcp_f32_e32 v30, v25                                     // 000000516FD0: 7E3C5519
	v_fma_f32 v38, -v25, v30, 1.0                              // 000000516FD4: D6130026 23CA3D19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000516FDC: BF870191
	v_fmac_f32_e32 v30, v38, v30                               // 000000516FE0: 563C3D26
	v_mul_f32_e32 v38, v33, v26                                // 000000516FE4: 104C3521
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000516FE8: BF870112
	v_mul_f32_e32 v40, v35, v30                                // 000000516FEC: 10503D23
	v_fma_f32 v41, -v23, v38, v33                              // 000000516FF0: D6130029 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000516FF8: BF870112
	v_fma_f32 v44, -v25, v40, v35                              // 000000516FFC: D613002C 248E5119
	v_fmac_f32_e32 v38, v41, v26                               // 000000517004: 564C3529
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000517008: BF870112
	v_fmac_f32_e32 v40, v44, v30                               // 00000051700C: 56503D2C
	v_fma_f32 v23, -v23, v38, v33                              // 000000517010: D6130017 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000517018: BF870112
	v_fma_f32 v25, -v25, v40, v35                              // 00000051701C: D6130019 248E5119
	v_div_fmas_f32 v23, v23, v26, v38                          // 000000517024: D6370017 049A3517
	s_mov_b32 vcc_lo, s7                                       // 00000051702C: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000517030: BF870091
	v_div_fixup_f32 v13, v23, v19, v13                         // 000000517034: D627000D 04362717
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_mul_f32 v13, v13, v39// 00000051703C: C9062CF2 160C4F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000517044: BF8701A1
	v_div_scale_f32 v27, null, v22, v22, v14                   // 000000517048: D6FC7C1B 043A2D16
	v_div_scale_f32 v36, s8, v14, v22, v14                     // 000000517050: D6FC0824 043A2D0E
	.long 0x7e3a398d                                           // 000000517058: 7E3A398D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000051705C: BF870293
	v_rcp_f32_e32 v31, v27                                     // 000000517060: 7E3E551B
	v_fma_f32 v34, -v27, v31, 1.0                              // 000000517064: D6130022 23CA3F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000051706C: BF870091
	v_dual_fmac_f32 v31, v34, v31 :: v_dual_mul_f32 v34, v37, v28// 000000517070: C8063F22 1F223925
	v_mul_f32_e32 v42, v36, v31                                // 000000517078: 10543F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000051707C: BF870112
	v_fma_f32 v43, -v24, v34, v37                              // 000000517080: D613002B 24964518
	v_fma_f32 v41, -v27, v42, v36                              // 000000517088: D6130029 2492551B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000517090: BF870112
	v_fmac_f32_e32 v34, v43, v28                               // 000000517094: 5644392B
	v_fmac_f32_e32 v42, v41, v31                               // 000000517098: 56543F29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000051709C: BF870112
	v_fma_f32 v24, -v24, v34, v37                              // 0000005170A0: D6130018 24964518
	v_fma_f32 v23, -v27, v42, v36                              // 0000005170A8: D6130017 2492551B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005170B0: BF870002
	v_div_fmas_f32 v24, v24, v28, v34                          // 0000005170B4: D6370018 048A3918
	s_mov_b32 vcc_lo, s6                                       // 0000005170BC: BEEA0006
	s_mov_b32 s6, 0                                            // 0000005170C0: BE860080
	v_div_fmas_f32 v19, v25, v30, v40                          // 0000005170C4: D6370013 04A23D19
	s_mov_b32 vcc_lo, s8                                       // 0000005170CC: BEEA0008
	v_div_fixup_f32 v16, v24, v20, v16                         // 0000005170D0: D6270010 04422918
	v_lshlrev_b32_e32 v20, 16, v7                              // 0000005170D8: 30280E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000005170DC: 360E0EFF FFFF0000
	v_div_fixup_f32 v18, v19, v21, v18                         // 0000005170E4: D6270012 044A2B13
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005170EC: BF8701A4
	v_mul_f32_e32 v6, v16, v6                                  // 0000005170F0: 100C0D10
	v_div_fmas_f32 v16, v23, v31, v42                          // 0000005170F4: D6370010 04AA3F17
	v_mul_f32_e32 v18, v18, v20                                // 0000005170FC: 10242912
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000517100: BF870193
	.long 0x7e403986                                           // 000000517104: 7E403986
	v_div_fixup_f32 v14, v16, v22, v14                         // 000000517108: D627000E 043A2D10
	v_and_b32_e32 v16, 1, v29                                  // 000000517110: 36203A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000517114: BF870194
	v_bfe_u32 v19, v18, 16, 1                                  // 000000517118: D6100013 02052112
	v_dual_mul_f32 v7, v14, v7 :: v_dual_and_b32 v20, 1, v32   // 000000517120: C8E40F0E 07144081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000517128: BF870193
	v_add3_u32 v13, v13, v16, 0x7fff                           // 00000051712C: D655000D 03FE210D 00007FFF
	v_add3_u32 v14, v18, v19, 0x7fff                           // 000000517138: D655000E 03FE2712 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000517144: BF870213
	v_add3_u32 v6, v6, v20, 0x7fff                             // 000000517148: D6550006 03FE2906 00007FFF
	v_bfe_u32 v16, v7, 16, 1                                   // 000000517154: D6100010 02052107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000051715C: BF870214
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000517160: 361A1AFF FFFF0000
	v_and_b32_e32 v18, 0xffff0000, v14                         // 000000517168: 36241CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000517170: BF870214
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000517174: 360C0CFF FFFF0000
	v_add3_u32 v7, v7, v16, 0x7fff                             // 00000051717C: D6550007 03FE2107 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000517188: BF8907F7
	v_fma_mix_f32 v14, v17, v13, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000051718C: CC20080E 8A021B11
	s_waitcnt vmcnt(0)                                         // 000000517194: BF8903F7
	v_fma_mix_f32 v13, v15, v18, neg(0) op_sel_hi:[1,0,0]      // 000000517198: CC20000D 8A02250F
	v_fma_mix_f32 v16, v17, v6, neg(0) op_sel_hi:[1,0,0]       // 0000005171A0: CC200010 8A020D11
	v_and_b32_e32 v15, 0xffff0000, v7                          // 0000005171A8: 361E0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 0000005171B0: 916A067E
	s_cbranch_vccnz 65128                                      // 0000005171B4: BFA4FE68 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x158>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005171B8: BF8700A3
	.long 0xd73c0004                                           // 0000005171BC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000005171C0: 02020881
	s_waitcnt lgkmcnt(0)                                       // 0000005171C4: BF89FC07
	.long 0xd7006a04                                           // 0000005171C8: D7006A04
	v_cndmask_b32_e32 v1, s30, v4, vcc_lo                      // 0000005171CC: 0202081E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005171D0: BF870111
	v_add_co_ci_u32_e64 v5, null, s31, v5, vcc_lo              // 0000005171D4: D5207C05 01AA0A1F
	.long 0xd7006a04                                           // 0000005171DC: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000005171E0: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005171E4: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000005171E8: D5207C05 01AA0705
	.long 0xd7006a06                                           // 0000005171F0: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000005171F4: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 0000005171F8: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 000000517200: DC560000 047C0004
	s_clause 0x1                                               // 000000517208: BF850001
	global_load_b32 v15, v[6:7], off                           // 00000051720C: DC520000 0F7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000517214: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 00000051721C: BF890BF7
	.long 0x7e0e3904                                           // 000000517220: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000517224: 360808FF FFFF0000
	v_lshlrev_b32_e32 v13, 16, v5                              // 00000051722C: 301A0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000517230: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000517234: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000517238: BF8907F7
	v_fma_mix_f32 v14, v15, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000051723C: CC20080E 8A02090F
	s_waitcnt vmcnt(0)                                         // 000000517244: BF8903F7
	v_fma_mix_f32 v13, v6, v13, neg(0) op_sel_hi:[1,0,0]       // 000000517248: CC20000D 8A021B06
	v_fma_mix_f32 v16, v15, v7, neg(0) op_sel_hi:[1,0,0]       // 000000517250: CC200010 8A020F0F
	v_and_b32_e32 v15, 0xffff0000, v5                          // 000000517258: 361E0AFF FFFF0000
	s_branch 65085                                             // 000000517260: BFA0FE3D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x158>
	s_or_b32 exec_lo, exec_lo, s39                             // 000000517264: 8C7E277E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000517268: BF870009
	s_or_b32 exec_lo, exec_lo, s27                             // 00000051726C: 8C7E1B7E
	s_ashr_i32 s0, s9, 31                                      // 000000517270: 86009F09
	v_mad_u32_u24 v9, v67, 24, 0x2f0                           // 000000517274: D60B0009 03FD3143 000002F0
	s_lshr_b32 s0, s0, 29                                      // 000000517280: 85009D00
	s_lshr_b32 s1, s34, 28                                     // 000000517284: 85019C22
	s_add_i32 s0, s0, s9                                       // 000000517288: 81000900
	s_add_i32 s1, s25, s1                                      // 00000051728C: 81010119
	s_add_i32 s0, s0, 7                                        // 000000517290: 81008700
	v_lshrrev_b32_e32 v1, 5, v9                                // 000000517294: 32021285
	s_ashr_i32 s0, s0, 3                                       // 000000517298: 86008300
	s_ashr_i32 s1, s1, 4                                       // 00000051729C: 86018401
	.long 0xd72c0007                                           // 0000005172A0: D72C0007
	v_cndmask_b32_e32 v1, s0, v66, vcc_lo                      // 0000005172A4: 02028400
	s_lshl_b32 s3, s11, 3                                      // 0000005172A8: 8403830B
	s_mul_i32 s5, s1, s2                                       // 0000005172AC: 96050201
	s_ashr_i32 s4, s3, 31                                      // 0000005172B0: 86049F03
	v_subrev_nc_u32_e32 v1, 24, v1                             // 0000005172B4: 4E020298
	v_cmp_eq_u32_e32 vcc_lo, 0, v67                            // 0000005172B8: 7C948680
	s_waitcnt lgkmcnt(0)                                       // 0000005172BC: BF89FC07
	s_barrier                                                  // 0000005172C0: BFBD0000
	v_add_nc_u32_e32 v2, s0, v7                                // 0000005172C4: 4A040E00
	s_mul_hi_i32 s0, s1, s2                                    // 0000005172C8: 97000201
	s_add_u32 s1, s5, s3                                       // 0000005172CC: 80010305
	s_addc_u32 s0, s0, s4                                      // 0000005172D0: 82000400
	s_mul_hi_u32 s4, s1, 0x300                                 // 0000005172D4: 9684FF01 00000300
	v_min_i32_e32 v89, s9, v2                                  // 0000005172DC: 22B20409
	s_mul_i32 s3, s0, 0x300                                    // 0000005172E0: 9603FF00 00000300
	s_mulk_i32 s1, 0x300                                       // 0000005172E8: B8010300
	v_cndmask_b32_e64 v3, v1, 23, vcc_lo                       // 0000005172EC: D5010003 01A92F01
	s_add_i32 s3, s4, s3                                       // 0000005172F4: 81030304
	.long 0xd4410000                                           // 0000005172F8: D4410000
	v_cndmask_b32_e32 v1, v7, v89, vcc_lo                      // 0000005172FC: 0202B307
	s_add_u32 s4, s28, s1                                      // 000000517300: 8004011C
	s_addc_u32 s5, s29, s3                                     // 000000517304: 8205031D
	buffer_gl0_inv                                             // 000000517308: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000517310: BE832000
	s_cbranch_execz 124                                        // 000000517314: BFA5007C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb08>
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v1, 8, v9        // 000000517318: CA200080 04001288
	.long 0xd4440001                                           // 000000517320: D4440001
	v_cndmask_b32_e32 v1, 23, v3, vcc_lo                       // 000000517324: 02020697
	v_mad_i64_i32 v[5:6], null, 0x300, v7, s[4:5]              // 000000517328: D6FF7C05 00120EFF 00000300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000517334: BF870213
	v_lshrrev_b32_e32 v1, 5, v1                                // 000000517338: 32020285
	.long 0xd73c000a                                           // 00000051733C: D73C000A
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000517340: 02020682
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000517344: BF870194
	v_cndmask_b32_e64 v2, 0xe9, 1, s1                          // 000000517348: D5010002 000502FF 000000E9
	v_subrev_nc_u32_e32 v1, 24, v1                             // 000000517354: 4E020298
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000517358: BF8701A2
	v_add_nc_u32_e32 v12, v2, v3                               // 00000051735C: 4A180702
	v_mov_b32_e32 v2, v4                                       // 000000517360: 7E040304
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 000000517364: D5010001 01A92F01
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000051736C: BF8701A3
	v_lshlrev_b32_e32 v13, 24, v12                             // 000000517370: 301A1898
	v_bfe_i32 v4, v12, 7, 1                                    // 000000517374: D6110004 02050F0C
	.long 0xd4440001                                           // 00000051737C: D4440001
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 000000517380: 02020297
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000517384: BF870113
	v_ashrrev_i32_e32 v12, 22, v13                             // 000000517388: 34181A96
	v_cndmask_b32_e64 v14, 0xe9, 1, s1                         // 00000051738C: D501000E 000502FF 000000E9
	.long 0xd700010a                                           // 000000517398: D700010A
	v_cndmask_b32_e32 v1, v5, v10, vcc_lo                      // 00000051739C: 02021505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005173A0: BF870191
	v_add_co_ci_u32_e64 v11, null, v6, v11, s1                 // 0000005173A4: D5207C0B 00061706
	v_add_nc_u32_e32 v14, v14, v1                              // 0000005173AC: 4A1C030E
	.long 0xd73c0001                                           // 0000005173B0: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000005173B4: 02020282
	.long 0xd700010c                                           // 0000005173B8: D700010C
	v_cndmask_b32_e32 v1, v5, v12, vcc_lo                      // 0000005173BC: 02021905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005173C0: BF870211
	v_add_co_ci_u32_e64 v13, null, v6, v4, s1                  // 0000005173C4: D5207C0D 00060906
	v_lshlrev_b32_e32 v15, 24, v14                             // 0000005173CC: 301E1C98
	v_bfe_i32 v4, v14, 7, 1                                    // 0000005173D0: D6110004 02050F0E
	.long 0xd700010e                                           // 0000005173D8: D700010E
	v_cndmask_b32_e32 v1, v5, v1, vcc_lo                       // 0000005173DC: 02020305
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005173E0: BF870123
	v_ashrrev_i32_e32 v16, 22, v15                             // 0000005173E4: 34201E96
	v_add_co_ci_u32_e64 v15, null, v6, v2, s1                  // 0000005173E8: D5207C0F 00060506
	.long 0xd7000110                                           // 0000005173F0: D7000110
	v_cndmask_b32_e32 v1, v5, v16, vcc_lo                      // 0000005173F4: 02022105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005173F8: BF870001
	v_add_co_ci_u32_e64 v17, null, v6, v4, s1                  // 0000005173FC: D5207C11 00060906
	s_clause 0x1f                                              // 000000517404: BF85001F
	global_load_b32 v2, v[10:11], off                          // 000000517408: DC520000 027C000A
	global_load_b32 v63, v[10:11], off offset:96               // 000000517410: DC520060 3F7C000A
	global_load_b32 v59, v[10:11], off offset:192              // 000000517418: DC5200C0 3B7C000A
	global_load_b32 v55, v[10:11], off offset:288              // 000000517420: DC520120 377C000A
	global_load_b32 v51, v[10:11], off offset:384              // 000000517428: DC520180 337C000A
	global_load_b32 v47, v[10:11], off offset:480              // 000000517430: DC5201E0 2F7C000A
	global_load_b32 v43, v[10:11], off offset:576              // 000000517438: DC520240 2B7C000A
	global_load_b32 v41, v[10:11], off offset:672              // 000000517440: DC5202A0 297C000A
	global_load_b32 v1, v[12:13], off                          // 000000517448: DC520000 017C000C
	global_load_b32 v62, v[12:13], off offset:96               // 000000517450: DC520060 3E7C000C
	global_load_b32 v58, v[12:13], off offset:192              // 000000517458: DC5200C0 3A7C000C
	global_load_b32 v54, v[12:13], off offset:288              // 000000517460: DC520120 367C000C
	global_load_b32 v50, v[12:13], off offset:384              // 000000517468: DC520180 327C000C
	global_load_b32 v46, v[12:13], off offset:480              // 000000517470: DC5201E0 2E7C000C
	global_load_b32 v42, v[12:13], off offset:576              // 000000517478: DC520240 2A7C000C
	global_load_b32 v40, v[12:13], off offset:672              // 000000517480: DC5202A0 287C000C
	global_load_b32 v6, v[14:15], off                          // 000000517488: DC520000 067C000E
	global_load_b32 v65, v[14:15], off offset:96               // 000000517490: DC520060 417C000E
	global_load_b32 v61, v[14:15], off offset:192              // 000000517498: DC5200C0 3D7C000E
	global_load_b32 v57, v[14:15], off offset:288              // 0000005174A0: DC520120 397C000E
	global_load_b32 v53, v[14:15], off offset:384              // 0000005174A8: DC520180 357C000E
	global_load_b32 v49, v[14:15], off offset:480              // 0000005174B0: DC5201E0 317C000E
	global_load_b32 v45, v[14:15], off offset:576              // 0000005174B8: DC520240 2D7C000E
	global_load_b32 v39, v[14:15], off offset:672              // 0000005174C0: DC5202A0 277C000E
	global_load_b32 v5, v[16:17], off                          // 0000005174C8: DC520000 057C0010
	global_load_b32 v64, v[16:17], off offset:96               // 0000005174D0: DC520060 407C0010
	global_load_b32 v60, v[16:17], off offset:192              // 0000005174D8: DC5200C0 3C7C0010
	global_load_b32 v56, v[16:17], off offset:288              // 0000005174E0: DC520120 387C0010
	global_load_b32 v52, v[16:17], off offset:384              // 0000005174E8: DC520180 347C0010
	global_load_b32 v48, v[16:17], off offset:480              // 0000005174F0: DC5201E0 307C0010
	global_load_b32 v44, v[16:17], off offset:576              // 0000005174F8: DC520240 2C7C0010
	global_load_b32 v38, v[16:17], off offset:672              // 000000517500: DC5202A0 267C0010
	s_or_b32 exec_lo, exec_lo, s3                              // 000000517508: 8C7E037E
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v68, 0             // 00000051750C: CA100080 21440080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v70, 0             // 000000517514: CA100080 45460080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v72, 0             // 00000051751C: CA100080 47480080
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v74, 0             // 000000517524: CA100080 494A0080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v76, 0             // 00000051752C: CA100080 4B4C0080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v78, 0             // 000000517534: CA100080 4D4E0080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v80, 0             // 00000051753C: CA100080 4F500080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v82, 0             // 000000517544: CA100080 51520080
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v84, 0             // 00000051754C: CA100080 53540080
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v86, 0             // 000000517554: CA100080 55560080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v88, 0             // 00000051755C: CA100080 57580080
	v_dual_mov_b32 v90, 0 :: v_dual_mov_b32 v91, 0             // 000000517564: CA100080 5A5A0080
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v93, 0             // 00000051756C: CA100080 5C5C0080
	v_dual_mov_b32 v94, 0 :: v_dual_mov_b32 v95, 0             // 000000517574: CA100080 5E5E0080
	v_dual_mov_b32 v96, 0 :: v_dual_mov_b32 v97, 0             // 00000051757C: CA100080 60600080
	v_dual_mov_b32 v98, 0 :: v_dual_mov_b32 v99, 0             // 000000517584: CA100080 62620080
	v_dual_mov_b32 v100, 0 :: v_dual_mov_b32 v101, 0           // 00000051758C: CA100080 64640080
	v_dual_mov_b32 v102, 0 :: v_dual_mov_b32 v103, 0           // 000000517594: CA100080 66660080
	v_dual_mov_b32 v104, 0 :: v_dual_mov_b32 v105, 0           // 00000051759C: CA100080 68680080
	v_dual_mov_b32 v106, 0 :: v_dual_mov_b32 v107, 0           // 0000005175A4: CA100080 6A6A0080
	v_dual_mov_b32 v108, 0 :: v_dual_mov_b32 v109, 0           // 0000005175AC: CA100080 6C6C0080
	v_dual_mov_b32 v110, 0 :: v_dual_mov_b32 v111, 0           // 0000005175B4: CA100080 6E6E0080
	v_dual_mov_b32 v112, 0 :: v_dual_mov_b32 v113, 0           // 0000005175BC: CA100080 70700080
	v_dual_mov_b32 v114, 0 :: v_dual_mov_b32 v115, 0           // 0000005175C4: CA100080 72720080
	v_dual_mov_b32 v117, 0 :: v_dual_mov_b32 v126, 0           // 0000005175CC: CA100080 757E0080
	v_dual_mov_b32 v119, 0 :: v_dual_mov_b32 v128, 0           // 0000005175D4: CA100080 77800080
	v_dual_mov_b32 v123, 0 :: v_dual_mov_b32 v130, 0           // 0000005175DC: CA100080 7B820080
	v_dual_mov_b32 v125, 0 :: v_dual_mov_b32 v116, 0           // 0000005175E4: CA100080 7D740080
	v_dual_mov_b32 v129, 0 :: v_dual_mov_b32 v118, 0           // 0000005175EC: CA100080 81760080
	v_dual_mov_b32 v120, 0 :: v_dual_mov_b32 v121, 0           // 0000005175F4: CA100080 78780080
	v_dual_mov_b32 v124, 0 :: v_dual_mov_b32 v127, 0           // 0000005175FC: CA100080 7C7E0080
	v_dual_mov_b32 v122, 0 :: v_dual_mov_b32 v131, 0           // 000000517604: CA100080 7A820080
	s_ashr_i32 s3, s2, 31                                      // 00000051760C: 86039F02
	s_and_saveexec_b32 s1, s0                                  // 000000517610: BE812000
	s_cbranch_execz 1438                                       // 000000517614: BFA5059E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2290>
	v_dual_mov_b32 v33, 0 :: v_dual_add_nc_u32 v4, 8, v9       // 000000517618: CA200080 21041288
	v_mul_i32_i24_e32 v10, 0xffffffe8, v67                     // 000000517620: 121486FF FFFFFFE8
	v_dual_mov_b32 v12, 23 :: v_dual_and_b32 v9, 0x7e0, v9     // 000000517628: CA240097 0C0812FF 000007E0
	s_delay_alu instid0(VALU_DEP_3)                            // 000000517634: BF870003
	v_lshrrev_b32_e32 v13, 5, v4                               // 000000517638: 321A0885
	v_or_b32_e32 v11, 4, v8                                    // 00000051763C: 38161084
	.long 0xd7030008                                           // 000000517640: D7030008
	v_cndmask_b32_e32 v0, v3, v129, vcc_lo                     // 000000517644: 02010303
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000517648: 3408069F
	v_add3_u32 v134, v10, v9, 0xfffffd34                       // 00000051764C: D6550086 03FE130A FFFFFD34
	v_subrev_nc_u32_e32 v13, 24, v13                           // 000000517658: 4E1A1A98
	.long 0x7e12390c                                           // 00000051765C: 7E12390C
	.long 0xd7624008                                           // 000000517660: D7624008
	v_cndmask_b32_e32 v1, 0xff, v8, vcc_lo                     // 000000517664: 020210FF 000000FF
	.long 0xd73c0022                                           // 00000051766C: D73C0022
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000517670: 02020682
	v_dual_mov_b32 v69, v33 :: v_dual_and_b32 v14, 16, v0      // 000000517674: CA240121 450E0090
	v_cndmask_b32_e64 v32, v13, 23, vcc_lo                     // 00000051767C: D5010020 01A92F0D
	.long 0xd7040003                                           // 000000517684: D7040003
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 000000517688: 02021303
	v_cmp_gt_u16_e32 vcc_lo, 24, v136/*Invalid register, operand has 'VGPR_32_Lo128' register class*/// 00000051768C: 7C791098
	v_mad_u32_u24 v10, v11, 3, 0x2f0                           // 000000517690: D60B000A 03FD070B 000002F0
	v_dual_mov_b32 v71, v33 :: v_dual_add_nc_u32 v132, 1, v7   // 00000051769C: CA200121 47840E81
	.long 0xd7034009                                           // 0000005176A4: D7034009
	v_cndmask_b32_e32 v0, v32, v129, vcc_lo                    // 0000005176A8: 02010320
	v_cndmask_b16 v3, v3, v8, vcc_lo                           // 0000005176AC: D65D0003 01AA1103
	v_mul_i32_i24_e32 v11, -3, v11                             // 0000005176B4: 121616C3
	v_lshl_or_b32 v135, v7, 5, v14                             // 0000005176B8: D6560087 04390B07
	v_dual_mov_b32 v68, v33 :: v_dual_and_b32 v7, 0x7e0, v10   // 0000005176C0: CA240121 440614FF 000007E0
	.long 0xd7625003                                           // 0000005176CC: D7625003
	v_cndmask_b32_e32 v1, 0xff, v9, vcc_lo                     // 0000005176D0: 020212FF 000000FF
	v_mov_b32_e32 v70, v33                                     // 0000005176D8: 7E8C0321
	.long 0xd73c0024                                           // 0000005176DC: D73C0024
	v_cndmask_b32_e32 v1, 2, v32, vcc_lo                       // 0000005176E0: 02024082
	v_sub_nc_u32_e32 v133, 0, v89                              // 0000005176E4: 4D0AB280
	v_mov_b32_e32 v74, v33                                     // 0000005176E8: 7E940321
	.long 0xd43d1000                                           // 0000005176EC: D43D1000
	v_cndmask_b32_e32 v1, 24, v3, vcc_lo                       // 0000005176F0: 02020698
	v_dual_mov_b32 v72, v33 :: v_dual_and_b32 v3, 0xff, v3     // 0000005176F4: CA240121 480206FF 000000FF
	v_mov_b32_e32 v76, v33                                     // 000000517700: 7E980321
	v_mov_b32_e32 v77, v33                                     // 000000517704: 7E9A0321
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000517708: BF870244
	v_cndmask_b16 v4, 0, v9, s0                                // 00000051770C: D65D1004 00021280
	v_mov_b32_e32 v73, v33                                     // 000000517714: 7E920321
	v_add3_u32 v136, v11, v7, 0xfffffd34                       // 000000517718: D6550088 03FE0F0B FFFFFD34
	v_dual_mov_b32 v78, v33 :: v_dual_lshlrev_b32 v137, 2, v3  // 000000517724: CA220121 4E880682
	v_dual_mov_b32 v75, v33 :: v_dual_and_b32 v4, 0xff, v4     // 00000051772C: CA240121 4B0408FF 000000FF
	v_mov_b32_e32 v79, v33                                     // 000000517738: 7E9E0321
	v_mov_b32_e32 v80, v33                                     // 00000051773C: 7EA00321
	s_delay_alu instid0(VALU_DEP_3)                            // 000000517740: BF870003
	v_dual_mov_b32 v81, v33 :: v_dual_lshlrev_b32 v138, 2, v4  // 000000517744: CA220121 518A0882
	v_mov_b32_e32 v82, v33                                     // 00000051774C: 7EA40321
	v_mov_b32_e32 v83, v33                                     // 000000517750: 7EA60321
	v_mov_b32_e32 v84, v33                                     // 000000517754: 7EA80321
	v_mov_b32_e32 v85, v33                                     // 000000517758: 7EAA0321
	v_mov_b32_e32 v86, v33                                     // 00000051775C: 7EAC0321
	v_mov_b32_e32 v87, v33                                     // 000000517760: 7EAE0321
	v_mov_b32_e32 v88, v33                                     // 000000517764: 7EB00321
	v_mov_b32_e32 v90, v33                                     // 000000517768: 7EB40321
	v_mov_b32_e32 v91, v33                                     // 00000051776C: 7EB60321
	v_mov_b32_e32 v92, v33                                     // 000000517770: 7EB80321
	v_mov_b32_e32 v93, v33                                     // 000000517774: 7EBA0321
	v_mov_b32_e32 v94, v33                                     // 000000517778: 7EBC0321
	v_mov_b32_e32 v95, v33                                     // 00000051777C: 7EBE0321
	v_mov_b32_e32 v96, v33                                     // 000000517780: 7EC00321
	v_mov_b32_e32 v97, v33                                     // 000000517784: 7EC20321
	v_mov_b32_e32 v98, v33                                     // 000000517788: 7EC40321
	v_mov_b32_e32 v99, v33                                     // 00000051778C: 7EC60321
	v_mov_b32_e32 v100, v33                                    // 000000517790: 7EC80321
	v_mov_b32_e32 v101, v33                                    // 000000517794: 7ECA0321
	v_mov_b32_e32 v102, v33                                    // 000000517798: 7ECC0321
	v_mov_b32_e32 v103, v33                                    // 00000051779C: 7ECE0321
	v_mov_b32_e32 v104, v33                                    // 0000005177A0: 7ED00321
	v_mov_b32_e32 v105, v33                                    // 0000005177A4: 7ED20321
	v_mov_b32_e32 v106, v33                                    // 0000005177A8: 7ED40321
	v_mov_b32_e32 v107, v33                                    // 0000005177AC: 7ED60321
	v_mov_b32_e32 v108, v33                                    // 0000005177B0: 7ED80321
	v_mov_b32_e32 v109, v33                                    // 0000005177B4: 7EDA0321
	v_mov_b32_e32 v110, v33                                    // 0000005177B8: 7EDC0321
	v_mov_b32_e32 v111, v33                                    // 0000005177BC: 7EDE0321
	v_mov_b32_e32 v112, v33                                    // 0000005177C0: 7EE00321
	v_mov_b32_e32 v113, v33                                    // 0000005177C4: 7EE20321
	v_mov_b32_e32 v114, v33                                    // 0000005177C8: 7EE40321
	v_mov_b32_e32 v115, v33                                    // 0000005177CC: 7EE60321
	v_mov_b32_e32 v117, v33                                    // 0000005177D0: 7EEA0321
	v_mov_b32_e32 v119, v33                                    // 0000005177D4: 7EEE0321
	v_mov_b32_e32 v123, v33                                    // 0000005177D8: 7EF60321
	v_mov_b32_e32 v125, v33                                    // 0000005177DC: 7EFA0321
	v_mov_b32_e32 v126, v33                                    // 0000005177E0: 7EFC0321
	v_mov_b32_e32 v128, v33                                    // 0000005177E4: 7F000321
	v_mov_b32_e32 v129, v33                                    // 0000005177E8: 7F020321
	v_mov_b32_e32 v130, v33                                    // 0000005177EC: 7F040321
	v_mov_b32_e32 v116, v33                                    // 0000005177F0: 7EE80321
	v_mov_b32_e32 v118, v33                                    // 0000005177F4: 7EEC0321
	v_mov_b32_e32 v120, v33                                    // 0000005177F8: 7EF00321
	v_mov_b32_e32 v124, v33                                    // 0000005177FC: 7EF80321
	v_mov_b32_e32 v121, v33                                    // 000000517800: 7EF20321
	v_mov_b32_e32 v122, v33                                    // 000000517804: 7EF40321
	v_mov_b32_e32 v127, v33                                    // 000000517808: 7EFE0321
	v_mov_b32_e32 v131, v33                                    // 00000051780C: 7F060321
	s_mov_b32 s6, 0                                            // 000000517810: BE860080
	s_mov_b32 s0, 0xdcd12d                                     // 000000517814: BE8000FF 00DCD12D
	s_movk_i32 s7, 0x83                                        // 00000051781C: B0070083
	s_movk_i32 s8, 0x1eee                                      // 000000517820: B0081EEE
	s_branch 1213                                              // 000000517824: BFA004BD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x211c>
	s_or_b32 exec_lo, exec_lo, s9                              // 000000517828: 8C7E097E
	s_waitcnt vmcnt(23)                                        // 00000051782C: BF895FF7
	.long 0xd73d0019                                           // 000000517830: D73D0019
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 000000517834: 02020386
	s_waitcnt vmcnt(7)                                         // 000000517838: BF891FF7
	.long 0xd73d001a                                           // 00000051783C: D73D001A
	v_cndmask_b32_e32 v1, v136, v5, vcc_lo                     // 000000517840: 02020B88
	ds_load_b128 v[21:24], v135                                // 000000517844: DBFC0000 15000087
	ds_load_b128 v[5:8], v135 offset:35840                     // 00000051784C: DBFC8C00 05000087
	ds_load_b128 v[13:16], v135 offset:5120                    // 000000517854: DBFC1400 0D000087
	ds_load_b128 v[17:20], v135 offset:10240                   // 00000051785C: DBFC2800 11000087
	ds_load_b128 v[9:12], v135 offset:15360                    // 000000517864: DBFC3C00 09000087
	ds_load_b128 v[1:4], v135 offset:20480                     // 00000051786C: DBFC5000 01000087
	.long 0xd73d003e                                           // 000000517874: D73D003E
	v_cndmask_b32_e32 v1, v134, v62, vcc_lo                    // 000000517878: 02027D86
	v_bfe_u32 v27, v25, 9, 16                                  // 00000051787C: D610001B 02411319
	v_mul_u32_u24_e32 v171, s0, v27                            // 000000517884: 17563600
	v_mul_u32_u24_e32 v27, s7, v27                             // 000000517888: 16363607
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000051788C: BF870151
	v_lshl_add_u32 v27, v27, 24, v171                          // 000000517890: D646001B 06AD311B
	v_bfe_u32 v29, v25, 3, 16                                  // 000000517898: D610001D 02410719
	v_bfe_u32 v28, v25, 6, 16                                  // 0000005178A0: D610001C 02410D19
	v_mul_u32_u24_e32 v171, s0, v29                            // 0000005178A8: 17563A00
	v_mul_u32_u24_e32 v29, s7, v29                             // 0000005178AC: 163A3A07
	v_lshl_add_u32 v29, v29, 24, v171                          // 0000005178B0: D646001D 06AD311D
	v_mul_u32_u24_e32 v171, s0, v28                            // 0000005178B8: 17563800
	v_mul_u32_u24_e32 v28, s7, v28                             // 0000005178BC: 16383807
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000005178C0: D622001B 03FD011B 00006400
	v_lshl_add_u32 v28, v28, 24, v171                          // 0000005178CC: D646001C 06AD311C
	v_and_b32_e32 v25, 0xffff, v25                             // 0000005178D4: 363232FF 0000FFFF
	v_bfe_u32 v30, v26, 9, 16                                  // 0000005178DC: D610001E 0241131A
	v_mul_u32_u24_e32 v171, s0, v25                            // 0000005178E4: 17563200
	v_mul_u32_u24_e32 v25, s7, v25                             // 0000005178E8: 16323207
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005178EC: BF870002
	v_lshl_add_u32 v25, v25, 24, v171                          // 0000005178F0: D6460019 06AD3119
	v_mul_u32_u24_e32 v171, s0, v30                            // 0000005178F8: 17563C00
	v_mul_u32_u24_e32 v30, s7, v30                             // 0000005178FC: 163C3C07
	v_and_b32_e32 v27, 0xffff, v27                             // 000000517900: 363636FF 0000FFFF
	v_sad_u8 v28, v28, 0, 0x6400                               // 000000517908: D622001C 03FD011C 00006400
	v_sad_u8 v29, v29, 0, 0x6400                               // 000000517914: D622001D 03FD011D 00006400
	v_lshl_add_u32 v30, v30, 24, v171                          // 000000517920: D646001E 06AD311E
	v_bfe_u32 v31, v26, 6, 16                                  // 000000517928: D610001F 02410D1A
	v_mul_u32_u24_e32 v171, s0, v31                            // 000000517930: 17563E00
	v_mul_u32_u24_e32 v31, s7, v31                             // 000000517934: 163E3E07
	v_lshl_or_b32 v27, v28, 16, v27                            // 000000517938: D656001B 046D211C
	v_and_b32_e32 v29, 0xffff, v29                             // 000000517940: 363A3AFF 0000FFFF
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000517948: D6220019 03FD0119 00006400
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000517954: D622001E 03FD011E 00006400
	v_lshl_add_u32 v31, v31, 24, v171                          // 000000517960: D646001F 06AD311F
	v_bfe_u32 v32, v26, 3, 16                                  // 000000517968: D6100020 0241071A
	v_mul_u32_u24_e32 v171, s0, v32                            // 000000517970: 17564000
	v_mul_u32_u24_e32 v32, s7, v32                             // 000000517974: 16404007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000517978: BF870001
	v_lshl_add_u32 v32, v32, 24, v171                          // 00000051797C: D6460020 06AD3120
	v_pk_fma_f16 v171, v27, s8, 0xc931 op_sel_hi:[1,0,0]       // 000000517984: CC0E00AB 0BFC111B 0000C931
	v_lshl_or_b32 v25, v25, 16, v29                            // 000000517990: D6560019 04752119
	v_and_b32_e32 v28, 0xffff, v30                             // 000000517998: 36383CFF 0000FFFF
	v_sad_u8 v29, v31, 0, 0x6400                               // 0000005179A0: D622001D 03FD011F 00006400
	s_waitcnt lgkmcnt(5)                                       // 0000005179AC: BF89FC57
	v_dual_dot2acc_f32_f16 v131, v171, v21 :: v_dual_and_b32 v26, 0xffff, v26// 0000005179B0: CB242BAB 831A34FF 0000FFFF
	v_mul_u32_u24_e32 v31, s0, v26                             // 0000005179BC: 163E3400
	v_mul_u32_u24_e32 v26, s7, v26                             // 0000005179C0: 16343407
	v_sad_u8 v30, v32, 0, 0x6400                               // 0000005179C4: D622001E 03FD0120 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005179D0: BF870002
	v_lshl_add_u32 v26, v26, 24, v31                           // 0000005179D4: D646001A 047D311A
	v_pk_fma_f16 v172, v25, s8, 0xc931 op_sel_hi:[1,0,0]       // 0000005179DC: CC0E00AC 0BFC1119 0000C931
	s_waitcnt lgkmcnt(3)                                       // 0000005179E8: BF89FC37
	v_dot2acc_f32_f16 v127, v171, v13                          // 0000005179EC: 04FE1BAB
	v_lshl_or_b32 v173, v29, 16, v28                           // 0000005179F0: D65600AD 0471211D
	s_waitcnt lgkmcnt(0)                                       // 0000005179F8: BF89FC07
	v_dot2acc_f32_f16 v124, v171, v1                           // 0000005179FC: 04F803AB
	v_sad_u8 v175, v26, 0, 0x6400                              // 000000517A00: D62200AF 03FD011A 00006400
	v_dot2acc_f32_f16 v131, v172, v22                          // 000000517A0C: 05062DAC
	s_waitcnt vmcnt(6)                                         // 000000517A10: BF891BF7
	.long 0xd73d003f                                           // 000000517A14: D73D003F
	v_cndmask_b32_e32 v1, v136, v64, vcc_lo                    // 000000517A18: 02028188
	v_pk_fma_f16 v173, v173, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000517A1C: CC0E00AD 0BFC11AD 0000C931
	v_and_b32_e32 v174, 0xffff, v30                            // 000000517A28: 375C3CFF 0000FFFF
	ds_load_b128 v[25:28], v135 offset:25600                   // 000000517A30: DBFC6400 19000087
	ds_load_b128 v[29:32], v135 offset:30720                   // 000000517A38: DBFC7800 1D000087
	v_dot2acc_f32_f16 v127, v172, v14                          // 000000517A40: 04FE1DAC
	v_bfe_u32 v64, v62, 9, 16                                  // 000000517A44: D6100040 0241133E
	v_mul_u32_u24_e32 v177, s0, v64                            // 000000517A4C: 17628000
	v_mul_u32_u24_e32 v64, s7, v64                             // 000000517A50: 16808007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000517A54: BF870001
	v_lshl_add_u32 v64, v64, 24, v177                          // 000000517A58: D6460040 06C53140
	v_dot2acc_f32_f16 v122, v171, v17                          // 000000517A60: 04F423AB
	v_dual_dot2acc_f32_f16 v121, v171, v9 :: v_dual_dot2acc_f32_f16 v124, v172, v2// 000000517A64: CB1813AB 797C05AC
	v_dot2acc_f32_f16 v116, v171, v5                           // 000000517A6C: 04E80BAB
	v_bfe_u32 v65, v62, 6, 16                                  // 000000517A70: D6100041 02410D3E
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000517A78: D6220040 03FD0140 00006400
	v_dot2acc_f32_f16 v131, v173, v23                          // 000000517A84: 05062FAD
	v_lshl_or_b32 v174, v175, 16, v174                         // 000000517A88: D65600AE 06B921AF
	v_dot2acc_f32_f16 v122, v172, v18                          // 000000517A90: 04F425AC
	v_dot2acc_f32_f16 v116, v172, v6                           // 000000517A94: 04E80DAC
	v_and_b32_e32 v64, 0xffff, v64                             // 000000517A98: 368080FF 0000FFFF
	v_dot2acc_f32_f16 v124, v173, v3                           // 000000517AA0: 04F807AD
	v_pk_fma_f16 v174, v174, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000517AA4: CC0E00AE 0BFC11AE 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000517AB0: BF89FC17
	v_dual_dot2acc_f32_f16 v120, v171, v25 :: v_dual_dot2acc_f32_f16 v127, v173, v15// 000000517AB4: CB1833AB 787E1FAD
	s_waitcnt lgkmcnt(0)                                       // 000000517ABC: BF89FC07
	v_dot2acc_f32_f16 v118, v171, v29                          // 000000517AC0: 04EC3BAB
	v_bfe_u32 v171, v62, 3, 16                                 // 000000517AC4: D61000AB 0241073E
	v_mul_u32_u24_e32 v177, s0, v171                           // 000000517ACC: 17635600
	v_mul_u32_u24_e32 v171, s7, v171                           // 000000517AD0: 17575607
	s_delay_alu instid0(VALU_DEP_1)                            // 000000517AD4: BF870001
	v_lshl_add_u32 v171, v171, 24, v177                        // 000000517AD8: D64600AB 06C531AB
	v_mul_u32_u24_e32 v177, s0, v65                            // 000000517AE0: 17628200
	v_mul_u32_u24_e32 v65, s7, v65                             // 000000517AE4: 16828207
	v_lshl_add_u32 v65, v65, 24, v177                          // 000000517AE8: D6460041 06C53141
	v_dual_dot2acc_f32_f16 v122, v173, v19 :: v_dual_dot2acc_f32_f16 v121, v172, v10// 000000517AF0: CB1827AD 7A7815AC
	v_dual_dot2acc_f32_f16 v131, v174, v24 :: v_dual_dot2acc_f32_f16 v120, v172, v26// 000000517AF8: CB1831AE 837835AC
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000517B00: BF870193
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000517B04: D6220041 03FD0141 00006400
	v_dual_dot2acc_f32_f16 v122, v174, v20 :: v_dual_dot2acc_f32_f16 v121, v173, v11// 000000517B10: CB1829AE 7A7817AD
	v_dot2acc_f32_f16 v118, v172, v30                          // 000000517B18: 04EC3DAC
	v_bfe_u32 v172, v63, 9, 16                                 // 000000517B1C: D61000AC 0241133F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000517B24: BF870004
	v_lshl_or_b32 v64, v65, 16, v64                            // 000000517B28: D6560040 05012141
	v_dot2acc_f32_f16 v127, v174, v16                          // 000000517B30: 04FE21AE
	v_sad_u8 v171, v171, 0, 0x6400                             // 000000517B34: D62200AB 03FD01AB 00006400
	v_bfe_u32 v175, v63, 6, 16                                 // 000000517B40: D61000AF 02410D3F
	v_bfe_u32 v176, v63, 3, 16                                 // 000000517B48: D61000B0 0241073F
	v_pk_fma_f16 v64, v64, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000517B50: CC0E0040 0BFC1140 0000C931
	v_and_b32_e32 v62, 0xffff, v62                             // 000000517B5C: 367C7CFF 0000FFFF
	v_dual_dot2acc_f32_f16 v124, v174, v4 :: v_dual_and_b32 v171, 0xffff, v171// 000000517B64: CB2409AE 7CAB56FF 0000FFFF
	v_and_b32_e32 v63, 0xffff, v63                             // 000000517B70: 367E7EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000517B78: BF870004
	v_dot2acc_f32_f16 v125, v64, v1                            // 000000517B7C: 04FA0340
	v_mul_u32_u24_e32 v177, s0, v62                            // 000000517B80: 17627C00
	v_mul_u32_u24_e32 v62, s7, v62                             // 000000517B84: 167C7C07
	v_lshl_add_u32 v62, v62, 24, v177                          // 000000517B88: D646003E 06C5313E
	v_mul_u32_u24_e32 v177, s0, v172                           // 000000517B90: 17635800
	v_mul_u32_u24_e32 v172, s7, v172                           // 000000517B94: 17595807
	v_lshl_add_u32 v172, v172, 24, v177                        // 000000517B98: D64600AC 06C531AC
	v_mul_u32_u24_e32 v177, s0, v175                           // 000000517BA0: 17635E00
	v_mul_u32_u24_e32 v175, s7, v175                           // 000000517BA4: 175F5E07
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000517BA8: D622003E 03FD013E 00006400
	v_lshl_add_u32 v175, v175, 24, v177                        // 000000517BB4: D64600AF 06C531AF
	v_mul_u32_u24_e32 v177, s0, v176                           // 000000517BBC: 17636000
	v_mul_u32_u24_e32 v176, s7, v176                           // 000000517BC0: 17616007
	v_sad_u8 v172, v172, 0, 0x6400                             // 000000517BC4: D62200AC 03FD01AC 00006400
	v_lshl_add_u32 v176, v176, 24, v177                        // 000000517BD0: D64600B0 06C531B0
	v_lshl_or_b32 v62, v62, 16, v171                           // 000000517BD8: D656003E 06AD213E
	v_sad_u8 v171, v175, 0, 0x6400                             // 000000517BE0: D62200AB 03FD01AF 00006400
	v_mul_u32_u24_e32 v175, s0, v63                            // 000000517BEC: 175E7E00
	v_mul_u32_u24_e32 v63, s7, v63                             // 000000517BF0: 167E7E07
	v_dual_dot2acc_f32_f16 v121, v174, v12 :: v_dual_dot2acc_f32_f16 v120, v173, v27// 000000517BF4: CB1819AE 797837AD
	v_dual_dot2acc_f32_f16 v118, v173, v31 :: v_dual_and_b32 v65, 0xffff, v172// 000000517BFC: CB243FAD 764158FF 0000FFFF
	v_sad_u8 v172, v176, 0, 0x6400                             // 000000517C08: D62200AC 03FD01B0 00006400
	v_lshl_add_u32 v63, v63, 24, v175                          // 000000517C14: D646003F 06BD313F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000517C1C: BF870254
	v_dual_dot2acc_f32_f16 v120, v174, v28 :: v_dual_dot2acc_f32_f16 v129, v64, v13// 000000517C20: CB1839AE 78801B40
	v_pk_fma_f16 v62, v62, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000517C28: CC0E003E 0BFC113E 0000C931
	v_lshl_or_b32 v65, v171, 16, v65                           // 000000517C34: D6560041 050521AB
	v_and_b32_e32 v171, 0xffff, v172                           // 000000517C3C: 375758FF 0000FFFF
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000517C44: D622003F 03FD013F 00006400
	v_dual_dot2acc_f32_f16 v116, v173, v7 :: v_dual_dot2acc_f32_f16 v125, v62, v2// 000000517C50: CB180FAD 747C053E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000517C58: BF870224
	v_pk_fma_f16 v65, v65, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000517C5C: CC0E0041 0BFC1141 0000C931
	v_dual_dot2acc_f32_f16 v129, v62, v14 :: v_dual_dot2acc_f32_f16 v130, v64, v21// 000000517C68: CB181D3E 81822B40
	v_lshl_or_b32 v63, v63, 16, v171                           // 000000517C70: D656003F 06AD213F
	.long 0xd73d003a                                           // 000000517C78: D73D003A
	v_cndmask_b32_e32 v1, v134, v58, vcc_lo                    // 000000517C7C: 02027586
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000517C80: BF870214
	v_dual_dot2acc_f32_f16 v116, v174, v8 :: v_dual_dot2acc_f32_f16 v125, v65, v3// 000000517C84: CB1811AE 747C0741
	v_dot2acc_f32_f16 v129, v65, v15                           // 000000517C8C: 05021F41
	s_delay_alu instid0(VALU_DEP_4)                            // 000000517C90: BF870004
	v_pk_fma_f16 v63, v63, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000517C94: CC0E003F 0BFC113F 0000C931
	v_dot2acc_f32_f16 v130, v62, v22                           // 000000517CA0: 05042D3E
	v_dot2acc_f32_f16 v126, v64, v9                            // 000000517CA4: 04FC1340
	v_dot2acc_f32_f16 v119, v64, v29                           // 000000517CA8: 04EE3B40
	s_waitcnt vmcnt(5)                                         // 000000517CAC: BF8917F7
	.long 0xd73d003b                                           // 000000517CB0: D73D003B
	v_cndmask_b32_e32 v1, v136, v60, vcc_lo                    // 000000517CB4: 02027988
	v_dual_dot2acc_f32_f16 v129, v63, v16 :: v_dual_dot2acc_f32_f16 v130, v65, v23// 000000517CB8: CB18213F 81822F41
	v_bfe_u32 v60, v58, 9, 16                                  // 000000517CC0: D610003C 0241133A
	v_dual_dot2acc_f32_f16 v118, v174, v32 :: v_dual_dot2acc_f32_f16 v123, v64, v25// 000000517CC8: CB1841AE 767A3340
	v_dual_dot2acc_f32_f16 v128, v64, v17 :: v_dual_dot2acc_f32_f16 v125, v63, v4// 000000517CD0: CB182340 807C093F
	v_dual_dot2acc_f32_f16 v126, v62, v10 :: v_dual_dot2acc_f32_f16 v117, v64, v5// 000000517CD8: CB18153E 7E740B40
	v_bfe_u32 v64, v58, 3, 16                                  // 000000517CE0: D6100040 0241073A
	v_mul_u32_u24_e32 v174, s0, v60                            // 000000517CE8: 175C7800
	v_mul_u32_u24_e32 v60, s7, v60                             // 000000517CEC: 16787807
	v_dual_dot2acc_f32_f16 v130, v63, v24 :: v_dual_dot2acc_f32_f16 v119, v62, v30// 000000517CF0: CB18313F 82763D3E
	v_lshl_add_u32 v60, v60, 24, v174                          // 000000517CF8: D646003C 06B9313C
	v_mul_u32_u24_e32 v174, s0, v64                            // 000000517D00: 175C8000
	v_mul_u32_u24_e32 v64, s7, v64                             // 000000517D04: 16808007
	v_lshl_add_u32 v64, v64, 24, v174                          // 000000517D08: D6460040 06B93140
	v_bfe_u32 v61, v58, 6, 16                                  // 000000517D10: D610003D 02410D3A
	v_dual_dot2acc_f32_f16 v119, v65, v31 :: v_dual_and_b32 v58, 0xffff, v58// 000000517D18: CB243F41 773A74FF 0000FFFF
	v_mul_u32_u24_e32 v174, s0, v61                            // 000000517D24: 175C7A00
	v_mul_u32_u24_e32 v61, s7, v61                             // 000000517D28: 167A7A07
	s_delay_alu instid0(VALU_DEP_2)                            // 000000517D2C: BF870002
	v_lshl_add_u32 v61, v61, 24, v174                          // 000000517D30: D646003D 06B9313D
	v_mul_u32_u24_e32 v174, s0, v58                            // 000000517D38: 175C7400
	v_mul_u32_u24_e32 v58, s7, v58                             // 000000517D3C: 16747407
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000517D40: D6220040 03FD0140 00006400
	v_lshl_add_u32 v58, v58, 24, v174                          // 000000517D4C: D646003A 06B9313A
	v_dual_dot2acc_f32_f16 v126, v65, v11 :: v_dual_dot2acc_f32_f16 v117, v62, v6// 000000517D54: CB181741 7E740D3E
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000517D5C: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000517D68: BF870214
	v_and_b32_e32 v64, 0xffff, v64                             // 000000517D6C: 368080FF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000517D74: D622003A 03FD013A 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000517D80: D622003D 03FD013D 00006400
	v_dot2acc_f32_f16 v117, v65, v7                            // 000000517D8C: 04EA0F41
	v_dot2acc_f32_f16 v123, v62, v26                           // 000000517D90: 04F6353E
	v_dot2acc_f32_f16 v128, v62, v18                           // 000000517D94: 0500253E
	v_lshl_or_b32 v58, v58, 16, v64                            // 000000517D98: D656003A 0501213A
	v_bfe_u32 v171, v59, 9, 16                                 // 000000517DA0: D61000AB 0241133B
	v_mul_u32_u24_e32 v174, s0, v171                           // 000000517DA8: 175D5600
	v_mul_u32_u24_e32 v171, s7, v171                           // 000000517DAC: 17575607
	s_delay_alu instid0(VALU_DEP_1)                            // 000000517DB0: BF870001
	v_lshl_add_u32 v171, v171, 24, v174                        // 000000517DB4: D64600AB 06B931AB
	v_pk_fma_f16 v58, v58, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000517DBC: CC0E003A 0BFC113A 0000C931
	v_and_b32_e32 v60, 0xffff, v60                             // 000000517DC8: 367878FF 0000FFFF
	v_bfe_u32 v172, v59, 6, 16                                 // 000000517DD0: D61000AC 02410D3B
	v_dot2acc_f32_f16 v123, v65, v27                           // 000000517DD8: 04F63741
	v_bfe_u32 v173, v59, 3, 16                                 // 000000517DDC: D61000AD 0241073B
	v_mul_u32_u24_e32 v174, s0, v172                           // 000000517DE4: 175D5800
	v_lshl_or_b32 v60, v61, 16, v60                            // 000000517DE8: D656003C 04F1213D
	v_mul_u32_u24_e32 v172, s7, v172                           // 000000517DF0: 17595807
	v_lshl_add_u32 v172, v172, 24, v174                        // 000000517DF4: D64600AC 06B931AC
	v_mul_u32_u24_e32 v174, s0, v173                           // 000000517DFC: 175D5A00
	v_mul_u32_u24_e32 v173, s7, v173                           // 000000517E00: 175B5A07
	v_pk_fma_f16 v60, v60, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000517E04: CC0E003C 0BFC113C 0000C931
	v_dot2acc_f32_f16 v128, v65, v19                           // 000000517E10: 05002741
	v_sad_u8 v171, v171, 0, 0x6400                             // 000000517E14: D62200AB 03FD01AB 00006400
	v_lshl_add_u32 v173, v173, 24, v174                        // 000000517E20: D64600AD 06B931AD
	v_and_b32_e32 v59, 0xffff, v59                             // 000000517E28: 367676FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000517E30: BF870004
	v_dual_dot2acc_f32_f16 v115, v60, v21 :: v_dual_dot2acc_f32_f16 v128, v63, v20// 000000517E34: CB182B3C 7380293F
	v_sad_u8 v64, v172, 0, 0x6400                              // 000000517E3C: D6220040 03FD01AC 00006400
	v_mul_u32_u24_e32 v172, s0, v59                            // 000000517E48: 17587600
	v_mul_u32_u24_e32 v59, s7, v59                             // 000000517E4C: 16767607
	v_dual_dot2acc_f32_f16 v126, v63, v12 :: v_dual_and_b32 v61, 0xffff, v171// 000000517E50: CB24193F 7E3D56FF 0000FFFF
	v_sad_u8 v171, v173, 0, 0x6400                             // 000000517E5C: D62200AB 03FD01AD 00006400
	v_lshl_add_u32 v59, v59, 24, v172                          // 000000517E68: D646003B 06B1313B
	v_dot2acc_f32_f16 v115, v58, v22                           // 000000517E70: 04E62D3A
	v_dot2acc_f32_f16 v123, v63, v28                           // 000000517E74: 04F6393F
	v_lshl_or_b32 v61, v64, 16, v61                            // 000000517E78: D656003D 04F52140
	v_and_b32_e32 v64, 0xffff, v171                            // 000000517E80: 368156FF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000517E88: D622003B 03FD013B 00006400
	v_dual_dot2acc_f32_f16 v119, v63, v32 :: v_dual_dot2acc_f32_f16 v114, v60, v13// 000000517E94: CB18413F 77721B3C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000517E9C: BF870224
	v_pk_fma_f16 v61, v61, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000517EA0: CC0E003D 0BFC113D 0000C931
	v_dot2acc_f32_f16 v113, v60, v17                           // 000000517EAC: 04E2233C
	v_lshl_or_b32 v59, v59, 16, v64                            // 000000517EB0: D656003B 0501213B
	v_dual_dot2acc_f32_f16 v112, v60, v9 :: v_dual_dot2acc_f32_f16 v117, v63, v8// 000000517EB8: CB18133C 7074113F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000517EC0: BF870194
	v_dual_dot2acc_f32_f16 v115, v61, v23 :: v_dual_dot2acc_f32_f16 v114, v58, v14// 000000517EC4: CB182F3D 73721D3A
	v_pk_fma_f16 v59, v59, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000517ECC: CC0E003B 0BFC113B 0000C931
	v_dot2acc_f32_f16 v113, v58, v18                           // 000000517ED8: 04E2253A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000517EDC: BF870194
	v_dual_dot2acc_f32_f16 v112, v58, v10 :: v_dual_dot2acc_f32_f16 v111, v60, v1// 000000517EE0: CB18153A 706E033C
	v_dual_dot2acc_f32_f16 v110, v60, v25 :: v_dual_dot2acc_f32_f16 v115, v59, v24// 000000517EE8: CB18333C 6E72313B
	.long 0xd73d0036                                           // 000000517EF0: D73D0036
	v_cndmask_b32_e32 v1, v134, v54, vcc_lo                    // 000000517EF4: 02026D86
	v_dot2acc_f32_f16 v114, v61, v15                           // 000000517EF8: 04E41F3D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000517EFC: BF8701A3
	v_dual_dot2acc_f32_f16 v113, v61, v19 :: v_dual_dot2acc_f32_f16 v110, v58, v26// 000000517F00: CB18273D 716E353A
	v_dual_dot2acc_f32_f16 v112, v61, v11 :: v_dual_dot2acc_f32_f16 v111, v58, v2// 000000517F08: CB18173D 706E053A
	v_dot2acc_f32_f16 v114, v59, v16                           // 000000517F10: 04E4213B
	s_waitcnt vmcnt(4)                                         // 000000517F14: BF8913F7
	.long 0xd73d0037                                           // 000000517F18: D73D0037
	v_cndmask_b32_e32 v1, v136, v56, vcc_lo                    // 000000517F1C: 02027188
	v_bfe_u32 v56, v54, 9, 16                                  // 000000517F20: D6100038 02411336
	v_mul_u32_u24_e32 v64, s0, v56                             // 000000517F28: 16807000
	v_mul_u32_u24_e32 v56, s7, v56                             // 000000517F2C: 16707007
	v_dual_dot2acc_f32_f16 v113, v59, v20 :: v_dual_dot2acc_f32_f16 v110, v61, v27// 000000517F30: CB18293B 716E373D
	v_dual_dot2acc_f32_f16 v112, v59, v12 :: v_dual_dot2acc_f32_f16 v111, v61, v3// 000000517F38: CB18193B 706E073D
	v_dot2acc_f32_f16 v109, v60, v29                           // 000000517F40: 04DA3B3C
	v_dot2acc_f32_f16 v108, v60, v5                            // 000000517F44: 04D80B3C
	v_lshl_add_u32 v56, v56, 24, v64                           // 000000517F48: D6460038 05013138
	v_dot2acc_f32_f16 v110, v59, v28                           // 000000517F50: 04DC393B
	v_dot2acc_f32_f16 v111, v59, v4                            // 000000517F54: 04DE093B
	v_bfe_u32 v57, v54, 6, 16                                  // 000000517F58: D6100039 02410D36
	v_dot2acc_f32_f16 v108, v58, v6                            // 000000517F60: 04D80D3A
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000517F64: D6220038 03FD0138 00006400
	v_dot2acc_f32_f16 v109, v58, v30                           // 000000517F70: 04DA3D3A
	v_bfe_u32 v58, v54, 3, 16                                  // 000000517F74: D610003A 02410736
	v_mul_u32_u24_e32 v64, s0, v58                             // 000000517F7C: 16807400
	v_mul_u32_u24_e32 v58, s7, v58                             // 000000517F80: 16747407
	s_delay_alu instid0(VALU_DEP_1)                            // 000000517F84: BF870001
	v_lshl_add_u32 v58, v58, 24, v64                           // 000000517F88: D646003A 0501313A
	v_mul_u32_u24_e32 v64, s0, v57                             // 000000517F90: 16807200
	v_mul_u32_u24_e32 v57, s7, v57                             // 000000517F94: 16727207
	v_lshl_add_u32 v57, v57, 24, v64                           // 000000517F98: D6460039 05013139
	v_and_b32_e32 v56, 0xffff, v56                             // 000000517FA0: 367070FF 0000FFFF
	v_bfe_u32 v60, v55, 9, 16                                  // 000000517FA8: D610003C 02411337
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000517FB0: D622003A 03FD013A 00006400
	v_bfe_u32 v62, v55, 6, 16                                  // 000000517FBC: D610003E 02410D37
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000517FC4: D6220039 03FD0139 00006400
	v_bfe_u32 v63, v55, 3, 16                                  // 000000517FD0: D610003F 02410737
	v_and_b32_e32 v55, 0xffff, v55                             // 000000517FD8: 366E6EFF 0000FFFF
	v_dual_dot2acc_f32_f16 v109, v61, v31 :: v_dual_and_b32 v58, 0xffff, v58// 000000517FE0: CB243F3D 6D3A74FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000517FEC: BF870004
	v_lshl_or_b32 v56, v57, 16, v56                            // 000000517FF0: D6560038 04E12139
	v_dot2acc_f32_f16 v108, v61, v7                            // 000000517FF8: 04D80F3D
	.long 0xd73d0032                                           // 000000517FFC: D73D0032
	v_cndmask_b32_e32 v1, v134, v50, vcc_lo                    // 000000518000: 02026586
	s_waitcnt vmcnt(3)                                         // 000000518004: BF890FF7
	.long 0xd73d0033                                           // 000000518008: D73D0033
	v_cndmask_b32_e32 v1, v136, v52, vcc_lo                    // 00000051800C: 02026988
	.long 0xd73d002e                                           // 000000518010: D73D002E
	v_cndmask_b32_e32 v1, v134, v46, vcc_lo                    // 000000518014: 02025D86
	v_pk_fma_f16 v56, v56, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000518018: CC0E0038 0BFC1138 0000C931
	v_dual_dot2acc_f32_f16 v109, v59, v32 :: v_dual_and_b32 v54, 0xffff, v54// 000000518024: CB24413B 6D366CFF 0000FFFF
	v_bfe_u32 v52, v50, 9, 16                                  // 000000518030: D6100034 02411332
	v_mul_u32_u24_e32 v61, s0, v52                             // 000000518038: 167A6800
	s_delay_alu instid0(VALU_DEP_3)                            // 00000051803C: BF870003
	v_dot2acc_f32_f16 v107, v56, v21                           // 000000518040: 04D62B38
	v_mul_u32_u24_e32 v64, s0, v54                             // 000000518044: 16806C00
	v_mul_u32_u24_e32 v54, s7, v54                             // 000000518048: 166C6C07
	v_lshl_add_u32 v54, v54, 24, v64                           // 00000051804C: D6460036 05013136
	v_mul_u32_u24_e32 v64, s0, v60                             // 000000518054: 16807800
	v_mul_u32_u24_e32 v60, s7, v60                             // 000000518058: 16787807
	v_lshl_add_u32 v60, v60, 24, v64                           // 00000051805C: D646003C 0501313C
	v_mul_u32_u24_e32 v64, s0, v62                             // 000000518064: 16807C00
	v_mul_u32_u24_e32 v62, s7, v62                             // 000000518068: 167C7C07
	v_sad_u8 v54, v54, 0, 0x6400                               // 00000051806C: D6220036 03FD0136 00006400
	v_lshl_add_u32 v62, v62, 24, v64                           // 000000518078: D646003E 0501313E
	v_mul_u32_u24_e32 v64, s0, v63                             // 000000518080: 16807E00
	v_mul_u32_u24_e32 v63, s7, v63                             // 000000518084: 167E7E07
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000518088: D622003C 03FD013C 00006400
	v_lshl_add_u32 v63, v63, 24, v64                           // 000000518094: D646003F 0501313F
	v_lshl_or_b32 v54, v54, 16, v58                            // 00000051809C: D6560036 04E92136
	v_sad_u8 v58, v62, 0, 0x6400                               // 0000005180A4: D622003A 03FD013E 00006400
	v_mul_u32_u24_e32 v62, s0, v55                             // 0000005180B0: 167C6E00
	v_mul_u32_u24_e32 v55, s7, v55                             // 0000005180B4: 166E6E07
	v_and_b32_e32 v57, 0xffff, v60                             // 0000005180B8: 367278FF 0000FFFF
	v_sad_u8 v60, v63, 0, 0x6400                               // 0000005180C0: D622003C 03FD013F 00006400
	v_lshl_add_u32 v55, v55, 24, v62                           // 0000005180CC: D6460037 04F93137
	v_pk_fma_f16 v54, v54, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000005180D4: CC0E0036 0BFC1136 0000C931
	v_dot2acc_f32_f16 v106, v56, v13                           // 0000005180E0: 04D41B38
	v_lshl_or_b32 v57, v58, 16, v57                            // 0000005180E4: D6560039 04E5213A
	v_and_b32_e32 v58, 0xffff, v60                             // 0000005180EC: 367478FF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000005180F4: D6220037 03FD0137 00006400
	v_dot2acc_f32_f16 v107, v54, v22                           // 000000518100: 04D62D36
	v_dual_dot2acc_f32_f16 v105, v56, v17 :: v_dual_dot2acc_f32_f16 v106, v54, v14// 000000518104: CB182338 696A1D36
	v_pk_fma_f16 v57, v57, s8, 0xc931 op_sel_hi:[1,0,0]        // 00000051810C: CC0E0039 0BFC1139 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000518118: BF870194
	v_lshl_or_b32 v55, v55, 16, v58                            // 00000051811C: D6560037 04E92137
	v_dual_dot2acc_f32_f16 v108, v59, v8 :: v_dual_dot2acc_f32_f16 v105, v54, v18// 000000518124: CB18113B 6C682536
	v_mul_u32_u24_e32 v52, s7, v52                             // 00000051812C: 16686807
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000518130: BF870193
	v_dot2acc_f32_f16 v107, v57, v23                           // 000000518134: 04D62F39
	v_pk_fma_f16 v55, v55, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000518138: CC0E0037 0BFC1137 0000C931
	v_dot2acc_f32_f16 v104, v56, v9                            // 000000518144: 04D01338
	v_dot2acc_f32_f16 v106, v57, v15                           // 000000518148: 04D41F39
	v_dot2acc_f32_f16 v105, v57, v19                           // 00000051814C: 04D22739
	v_lshl_add_u32 v52, v52, 24, v61                           // 000000518150: D6460034 04F53134
	v_dot2acc_f32_f16 v107, v55, v24                           // 000000518158: 04D63137
	v_dual_dot2acc_f32_f16 v103, v56, v1 :: v_dual_dot2acc_f32_f16 v104, v54, v10// 00000051815C: CB180338 67681536
	v_dot2acc_f32_f16 v106, v55, v16                           // 000000518164: 04D42137
	v_dual_dot2acc_f32_f16 v102, v56, v25 :: v_dual_dot2acc_f32_f16 v105, v55, v20// 000000518168: CB183338 66682937
	s_delay_alu instid0(VALU_DEP_3)                            // 000000518170: BF870003
	v_dual_dot2acc_f32_f16 v103, v54, v2 :: v_dual_dot2acc_f32_f16 v104, v57, v11// 000000518174: CB180536 67681739
	v_dot2acc_f32_f16 v101, v56, v29                           // 00000051817C: 04CA3B38
	v_dot2acc_f32_f16 v100, v56, v5                            // 000000518180: 04C80B38
	v_bfe_u32 v56, v50, 3, 16                                  // 000000518184: D6100038 02410732
	v_bfe_u32 v53, v50, 6, 16                                  // 00000051818C: D6100035 02410D32
	v_dot2acc_f32_f16 v104, v55, v12                           // 000000518194: 04D01937
	v_mul_u32_u24_e32 v61, s0, v56                             // 000000518198: 167A7000
	v_mul_u32_u24_e32 v56, s7, v56                             // 00000051819C: 16707007
	v_lshl_add_u32 v56, v56, 24, v61                           // 0000005181A0: D6460038 04F53138
	v_mul_u32_u24_e32 v61, s0, v53                             // 0000005181A8: 167A6A00
	v_mul_u32_u24_e32 v53, s7, v53                             // 0000005181AC: 166A6A07
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000005181B0: D6220034 03FD0134 00006400
	v_lshl_add_u32 v53, v53, 24, v61                           // 0000005181BC: D6460035 04F53135
	v_dot2acc_f32_f16 v101, v54, v30                           // 0000005181C4: 04CA3D36
	v_bfe_u32 v58, v51, 9, 16                                  // 0000005181C8: D610003A 02411333
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000005181D0: D6220038 03FD0138 00006400
	v_and_b32_e32 v52, 0xffff, v52                             // 0000005181DC: 366868FF 0000FFFF
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000005181E4: D6220035 03FD0135 00006400
	v_bfe_u32 v59, v51, 6, 16                                  // 0000005181F0: D610003B 02410D33
	v_bfe_u32 v60, v51, 3, 16                                  // 0000005181F8: D610003C 02410733
	v_dual_dot2acc_f32_f16 v103, v57, v3 :: v_dual_dot2acc_f32_f16 v102, v54, v26// 000000518200: CB180739 67663536
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000518208: BF870234
	v_lshl_or_b32 v52, v53, 16, v52                            // 00000051820C: D6560034 04D12135
	v_and_b32_e32 v51, 0xffff, v51                             // 000000518214: 366666FF 0000FFFF
	v_dot2acc_f32_f16 v101, v57, v31                           // 00000051821C: 04CA3F39
	v_dual_dot2acc_f32_f16 v103, v55, v4 :: v_dual_dot2acc_f32_f16 v102, v57, v27// 000000518220: CB180937 67663739
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000518228: BF870194
	v_pk_fma_f16 v52, v52, s8, 0xc931 op_sel_hi:[1,0,0]        // 00000051822C: CC0E0034 0BFC1134 0000C931
	v_dual_dot2acc_f32_f16 v101, v55, v32 :: v_dual_and_b32 v50, 0xffff, v50// 000000518238: CB244137 653264FF 0000FFFF
	s_waitcnt vmcnt(2)                                         // 000000518244: BF890BF7
	.long 0xd73d002f                                           // 000000518248: D73D002F
	v_cndmask_b32_e32 v1, v136, v48, vcc_lo                    // 00000051824C: 02026188
	s_delay_alu instid0(VALU_DEP_3)                            // 000000518250: BF870003
	v_dual_dot2acc_f32_f16 v102, v55, v28 :: v_dual_dot2acc_f32_f16 v99, v52, v21// 000000518254: CB183937 66622B34
	v_mul_u32_u24_e32 v61, s0, v50                             // 00000051825C: 167A6400
	v_mul_u32_u24_e32 v50, s7, v50                             // 000000518260: 16646407
	v_lshl_add_u32 v50, v50, 24, v61                           // 000000518264: D6460032 04F53132
	v_mul_u32_u24_e32 v61, s0, v58                             // 00000051826C: 167A7400
	v_mul_u32_u24_e32 v58, s7, v58                             // 000000518270: 16747407
	v_lshl_add_u32 v58, v58, 24, v61                           // 000000518274: D646003A 04F5313A
	v_mul_u32_u24_e32 v61, s0, v59                             // 00000051827C: 167A7600
	v_mul_u32_u24_e32 v59, s7, v59                             // 000000518280: 16767607
	v_and_b32_e32 v56, 0xffff, v56                             // 000000518284: 367070FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 00000051828C: D6220032 03FD0132 00006400
	v_lshl_add_u32 v59, v59, 24, v61                           // 000000518298: D646003B 04F5313B
	v_mul_u32_u24_e32 v61, s0, v60                             // 0000005182A0: 167A7800
	v_mul_u32_u24_e32 v60, s7, v60                             // 0000005182A4: 16787807
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000005182A8: D622003A 03FD013A 00006400
	v_lshl_add_u32 v60, v60, 24, v61                           // 0000005182B4: D646003C 04F5313C
	v_lshl_or_b32 v50, v50, 16, v56                            // 0000005182BC: D6560032 04E12132
	v_sad_u8 v56, v59, 0, 0x6400                               // 0000005182C4: D6220038 03FD013B 00006400
	v_mul_u32_u24_e32 v59, s0, v51                             // 0000005182D0: 16766600
	v_mul_u32_u24_e32 v51, s7, v51                             // 0000005182D4: 16666607
	v_and_b32_e32 v53, 0xffff, v58                             // 0000005182D8: 366A74FF 0000FFFF
	v_sad_u8 v58, v60, 0, 0x6400                               // 0000005182E0: D622003A 03FD013C 00006400
	v_lshl_add_u32 v51, v51, 24, v59                           // 0000005182EC: D6460033 04ED3133
	v_pk_fma_f16 v50, v50, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000005182F4: CC0E0032 0BFC1132 0000C931
	v_dot2acc_f32_f16 v95, v52, v1                             // 000000518300: 04BE0334
	v_lshl_or_b32 v53, v56, 16, v53                            // 000000518304: D6560035 04D52138
	v_and_b32_e32 v56, 0xffff, v58                             // 00000051830C: 367074FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000518314: D6220033 03FD0133 00006400
	v_dot2acc_f32_f16 v99, v50, v22                            // 000000518320: 04C62D32
	v_bfe_u32 v48, v46, 9, 16                                  // 000000518324: D6100030 0241132E
	v_pk_fma_f16 v53, v53, s8, 0xc931 op_sel_hi:[1,0,0]        // 00000051832C: CC0E0035 0BFC1135 0000C931
	v_dot2acc_f32_f16 v100, v54, v6                            // 000000518338: 04C80D36
	v_lshl_or_b32 v51, v51, 16, v56                            // 00000051833C: D6560033 04E12133
	v_dot2acc_f32_f16 v95, v50, v2                             // 000000518344: 04BE0532
	v_dot2acc_f32_f16 v93, v52, v29                            // 000000518348: 04BA3B34
	v_dot2acc_f32_f16 v99, v53, v23                            // 00000051834C: 04C62F35
	v_dot2acc_f32_f16 v100, v57, v7                            // 000000518350: 04C80F39
	v_pk_fma_f16 v51, v51, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000518354: CC0E0033 0BFC1133 0000C931
	v_dot2acc_f32_f16 v98, v52, v13                            // 000000518360: 04C41B34
	v_dot2acc_f32_f16 v97, v52, v17                            // 000000518364: 04C22334
	v_mul_u32_u24_e32 v57, s0, v48                             // 000000518368: 16726000
	v_mul_u32_u24_e32 v48, s7, v48                             // 00000051836C: 16606007
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000518370: BF870242
	v_dual_dot2acc_f32_f16 v99, v51, v24 :: v_dual_dot2acc_f32_f16 v98, v50, v14// 000000518374: CB183133 63621D32
	v_dot2acc_f32_f16 v100, v55, v8                            // 00000051837C: 04C81137
	v_dual_dot2acc_f32_f16 v96, v52, v9 :: v_dual_dot2acc_f32_f16 v97, v50, v18// 000000518380: CB181334 60602532
	v_dot2acc_f32_f16 v94, v52, v25                            // 000000518388: 04BC3334
	v_dot2acc_f32_f16 v98, v53, v15                            // 00000051838C: 04C41F35
	v_lshl_add_u32 v48, v48, 24, v57                           // 000000518390: D6460030 04E53130
	v_dot2acc_f32_f16 v92, v52, v5                             // 000000518398: 04B80B34
	v_bfe_u32 v52, v46, 3, 16                                  // 00000051839C: D6100034 0241072E
	v_bfe_u32 v49, v46, 6, 16                                  // 0000005183A4: D6100031 02410D2E
	v_dot2acc_f32_f16 v98, v51, v16                            // 0000005183AC: 04C42133
	v_mul_u32_u24_e32 v57, s0, v52                             // 0000005183B0: 16726800
	v_mul_u32_u24_e32 v52, s7, v52                             // 0000005183B4: 16686807
	v_lshl_add_u32 v52, v52, 24, v57                           // 0000005183B8: D6460034 04E53134
	v_mul_u32_u24_e32 v57, s0, v49                             // 0000005183C0: 16726200
	v_mul_u32_u24_e32 v49, s7, v49                             // 0000005183C4: 16626207
	v_dual_dot2acc_f32_f16 v97, v53, v19 :: v_dual_dot2acc_f32_f16 v94, v50, v26// 0000005183C8: CB182735 615E3532
	v_dot2acc_f32_f16 v95, v53, v3                             // 0000005183D0: 04BE0735
	v_sad_u8 v48, v48, 0, 0x6400                               // 0000005183D4: D6220030 03FD0130 00006400
	v_lshl_add_u32 v49, v49, 24, v57                           // 0000005183E0: D6460031 04E53131
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005183E8: BF870124
	v_dual_dot2acc_f32_f16 v93, v50, v30 :: v_dual_dot2acc_f32_f16 v94, v53, v27// 0000005183EC: CB183D32 5D5E3735
	v_dual_dot2acc_f32_f16 v96, v50, v10 :: v_dual_dot2acc_f32_f16 v97, v51, v20// 0000005183F4: CB181532 60602933
	v_dual_dot2acc_f32_f16 v93, v53, v31 :: v_dual_and_b32 v48, 0xffff, v48// 0000005183FC: CB243F35 5D3060FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000518408: BF870004
	v_sad_u8 v49, v49, 0, 0x6400                               // 00000051840C: D6220031 03FD0131 00006400
	v_bfe_u32 v54, v47, 9, 16                                  // 000000518418: D6100036 0241132F
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000518420: D6220034 03FD0134 00006400
	v_bfe_u32 v55, v47, 6, 16                                  // 00000051842C: D6100037 02410D2F
	v_dual_dot2acc_f32_f16 v96, v53, v11 :: v_dual_dot2acc_f32_f16 v95, v51, v4// 000000518434: CB181735 605E0933
	v_lshl_or_b32 v48, v49, 16, v48                            // 00000051843C: D6560030 04C12131
	v_bfe_u32 v56, v47, 3, 16                                  // 000000518444: D6100038 0241072F
	v_and_b32_e32 v52, 0xffff, v52                             // 00000051844C: 366868FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000518454: BF870214
	v_dual_dot2acc_f32_f16 v96, v51, v12 :: v_dual_and_b32 v47, 0xffff, v47// 000000518458: CB241933 602E5EFF 0000FFFF
	v_pk_fma_f16 v48, v48, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000518464: CC0E0030 0BFC1130 0000C931
	v_dual_dot2acc_f32_f16 v93, v51, v32 :: v_dual_and_b32 v46, 0xffff, v46// 000000518470: CB244133 5D2E5CFF 0000FFFF
	.long 0xd73d002a                                           // 00000051847C: D73D002A
	v_cndmask_b32_e32 v1, v134, v42, vcc_lo                    // 000000518480: 02025586
	s_waitcnt vmcnt(1)                                         // 000000518484: BF8907F7
	.long 0xd73d002b                                           // 000000518488: D73D002B
	v_cndmask_b32_e32 v1, v136, v44, vcc_lo                    // 00000051848C: 02025988
	v_dot2acc_f32_f16 v91, v48, v21                            // 000000518490: 04B62B30
	v_mul_u32_u24_e32 v57, s0, v46                             // 000000518494: 16725C00
	v_mul_u32_u24_e32 v46, s7, v46                             // 000000518498: 165C5C07
	v_lshl_add_u32 v46, v46, 24, v57                           // 00000051849C: D646002E 04E5312E
	v_mul_u32_u24_e32 v57, s0, v54                             // 0000005184A4: 16726C00
	v_mul_u32_u24_e32 v54, s7, v54                             // 0000005184A8: 166C6C07
	v_lshl_add_u32 v54, v54, 24, v57                           // 0000005184AC: D6460036 04E53136
	v_mul_u32_u24_e32 v57, s0, v55                             // 0000005184B4: 16726E00
	v_mul_u32_u24_e32 v55, s7, v55                             // 0000005184B8: 166E6E07
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000005184BC: D622002E 03FD012E 00006400
	v_lshl_add_u32 v55, v55, 24, v57                           // 0000005184C8: D6460037 04E53137
	v_mul_u32_u24_e32 v57, s0, v56                             // 0000005184D0: 16727000
	v_mul_u32_u24_e32 v56, s7, v56                             // 0000005184D4: 16707007
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000005184D8: D6220036 03FD0136 00006400
	v_lshl_add_u32 v56, v56, 24, v57                           // 0000005184E4: D6460038 04E53138
	v_lshl_or_b32 v46, v46, 16, v52                            // 0000005184EC: D656002E 04D1212E
	v_sad_u8 v52, v55, 0, 0x6400                               // 0000005184F4: D6220034 03FD0137 00006400
	v_mul_u32_u24_e32 v55, s0, v47                             // 000000518500: 166E5E00
	v_mul_u32_u24_e32 v47, s7, v47                             // 000000518504: 165E5E07
	v_dual_dot2acc_f32_f16 v94, v51, v28 :: v_dual_and_b32 v49, 0xffff, v54// 000000518508: CB243933 5E306CFF 0000FFFF
	v_sad_u8 v54, v56, 0, 0x6400                               // 000000518514: D6220036 03FD0138 00006400
	v_lshl_add_u32 v47, v47, 24, v55                           // 000000518520: D646002F 04DD312F
	v_pk_fma_f16 v46, v46, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000518528: CC0E002E 0BFC112E 0000C931
	v_dot2acc_f32_f16 v85, v48, v25                            // 000000518534: 04AA3330
	v_lshl_or_b32 v49, v52, 16, v49                            // 000000518538: D6560031 04C52134
	v_and_b32_e32 v52, 0xffff, v54                             // 000000518540: 36686CFF 0000FFFF
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000518548: D622002F 03FD012F 00006400
	v_dot2acc_f32_f16 v91, v46, v22                            // 000000518554: 04B62D2E
	v_dual_dot2acc_f32_f16 v92, v50, v6 :: v_dual_dot2acc_f32_f16 v87, v48, v9// 000000518558: CB180D32 5C561330
	v_pk_fma_f16 v49, v49, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000518560: CC0E0031 0BFC1131 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000051856C: BF870194
	v_lshl_or_b32 v47, v47, 16, v52                            // 000000518570: D656002F 04D1212F
	v_dual_dot2acc_f32_f16 v85, v46, v26 :: v_dual_dot2acc_f32_f16 v92, v53, v7// 000000518578: CB18352E 555C0F35
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000518580: BF870214
	v_dot2acc_f32_f16 v87, v46, v10                            // 000000518584: 04AE152E
	v_dot2acc_f32_f16 v91, v49, v23                            // 000000518588: 04B62F31
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000051858C: BF870154
	v_pk_fma_f16 v47, v47, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000518590: CC0E002F 0BFC112F 0000C931
	v_dot2acc_f32_f16 v90, v48, v13                            // 00000051859C: 04B41B30
	v_bfe_u32 v44, v42, 9, 16                                  // 0000005185A0: D610002C 0241132A
	v_mul_u32_u24_e32 v53, s0, v44                             // 0000005185A8: 166A5800
	v_mul_u32_u24_e32 v44, s7, v44                             // 0000005185AC: 16585807
	v_dual_dot2acc_f32_f16 v91, v47, v24 :: v_dual_dot2acc_f32_f16 v90, v46, v14// 0000005185B0: CB18312F 5B5A1D2E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000005185B8: BF870232
	v_lshl_add_u32 v44, v44, 24, v53                           // 0000005185BC: D646002C 04D5312C
	v_dual_dot2acc_f32_f16 v88, v48, v17 :: v_dual_dot2acc_f32_f16 v87, v49, v11// 0000005185C4: CB182330 58561731
	v_dual_dot2acc_f32_f16 v92, v51, v8 :: v_dual_dot2acc_f32_f16 v85, v49, v27// 0000005185CC: CB181133 5C543731
	v_dot2acc_f32_f16 v90, v49, v15                            // 0000005185D4: 04B41F31
	v_dot2acc_f32_f16 v86, v48, v1                             // 0000005185D8: 04AC0330
	v_dot2acc_f32_f16 v84, v48, v29                            // 0000005185DC: 04A83B30
	v_dot2acc_f32_f16 v83, v48, v5                             // 0000005185E0: 04A60B30
	v_bfe_u32 v48, v42, 3, 16                                  // 0000005185E4: D6100030 0241072A
	v_dot2acc_f32_f16 v90, v47, v16                            // 0000005185EC: 04B4212F
	v_bfe_u32 v45, v42, 6, 16                                  // 0000005185F0: D610002D 02410D2A
	v_mul_u32_u24_e32 v53, s0, v48                             // 0000005185F8: 166A6000
	v_mul_u32_u24_e32 v48, s7, v48                             // 0000005185FC: 16606007
	v_lshl_add_u32 v48, v48, 24, v53                           // 000000518600: D6460030 04D53130
	v_mul_u32_u24_e32 v53, s0, v45                             // 000000518608: 166A5A00
	v_mul_u32_u24_e32 v45, s7, v45                             // 00000051860C: 165A5A07
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000518610: D622002C 03FD012C 00006400
	v_lshl_add_u32 v45, v45, 24, v53                           // 00000051861C: D646002D 04D5312D
	v_and_b32_e32 v42, 0xffff, v42                             // 000000518624: 365454FF 0000FFFF
	v_bfe_u32 v50, v43, 9, 16                                  // 00000051862C: D6100032 0241132B
	v_mul_u32_u24_e32 v53, s0, v42                             // 000000518634: 166A5400
	v_and_b32_e32 v44, 0xffff, v44                             // 000000518638: 365858FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000518640: D622002D 03FD012D 00006400
	v_mul_u32_u24_e32 v42, s7, v42                             // 00000051864C: 16545407
	v_lshl_add_u32 v42, v42, 24, v53                           // 000000518650: D646002A 04D5312A
	v_mul_u32_u24_e32 v53, s0, v50                             // 000000518658: 166A6400
	v_mul_u32_u24_e32 v50, s7, v50                             // 00000051865C: 16646407
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000518660: D6220030 03FD0130 00006400
	v_lshl_add_u32 v50, v50, 24, v53                           // 00000051866C: D6460032 04D53132
	v_lshl_or_b32 v44, v45, 16, v44                            // 000000518674: D656002C 04B1212D
	v_bfe_u32 v51, v43, 6, 16                                  // 00000051867C: D6100033 02410D2B
	v_mul_u32_u24_e32 v53, s0, v51                             // 000000518684: 166A6600
	v_mul_u32_u24_e32 v51, s7, v51                             // 000000518688: 16666607
	v_dual_dot2acc_f32_f16 v88, v46, v18 :: v_dual_dot2acc_f32_f16 v87, v47, v12// 00000051868C: CB18252E 5856192F
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000518694: D622002A 03FD012A 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000005186A0: D6220032 03FD0132 00006400
	v_lshl_add_u32 v51, v51, 24, v53                           // 0000005186AC: D6460033 04D53133
	v_pk_fma_f16 v44, v44, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000005186B4: CC0E002C 0BFC112C 0000C931
	v_and_b32_e32 v48, 0xffff, v48                             // 0000005186C0: 366060FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005186C8: BF870224
	v_dual_dot2acc_f32_f16 v88, v49, v19 :: v_dual_and_b32 v45, 0xffff, v50// 0000005186CC: CB242731 582C64FF 0000FFFF
	v_bfe_u32 v52, v43, 3, 16                                  // 0000005186D8: D6100034 0241072B
	v_dot2acc_f32_f16 v77, v44, v25                            // 0000005186E0: 049A332C
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005186E4: BF870004
	v_lshl_or_b32 v42, v42, 16, v48                            // 0000005186E8: D656002A 04C1212A
	v_sad_u8 v48, v51, 0, 0x6400                               // 0000005186F0: D6220030 03FD0133 00006400
	v_mul_u32_u24_e32 v53, s0, v52                             // 0000005186FC: 166A6800
	v_mul_u32_u24_e32 v52, s7, v52                             // 000000518700: 16686807
	v_dual_dot2acc_f32_f16 v85, v47, v28 :: v_dual_dot2acc_f32_f16 v86, v46, v2// 000000518704: CB18392F 5556052E
	v_dot2acc_f32_f16 v81, v44, v13                            // 00000051870C: 04A21B2C
	v_lshl_add_u32 v52, v52, 24, v53                           // 000000518710: D6460034 04D53134
	v_pk_fma_f16 v42, v42, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000518718: CC0E002A 0BFC112A 0000C931
	v_lshl_or_b32 v45, v48, 16, v45                            // 000000518724: D656002D 04B52130
	v_and_b32_e32 v43, 0xffff, v43                             // 00000051872C: 365656FF 0000FFFF
	v_mul_u32_u24_e32 v51, s0, v43                             // 000000518734: 16665600
	v_mul_u32_u24_e32 v43, s7, v43                             // 000000518738: 16565607
	v_dual_dot2acc_f32_f16 v88, v47, v20 :: v_dual_dot2acc_f32_f16 v83, v46, v6// 00000051873C: CB18292F 58520D2E
	v_dot2acc_f32_f16 v84, v46, v30                            // 000000518744: 04A83D2E
	v_dual_dot2acc_f32_f16 v86, v49, v3 :: v_dual_dot2acc_f32_f16 v81, v42, v14// 000000518748: CB180731 56501D2A
	v_sad_u8 v50, v52, 0, 0x6400                               // 000000518750: D6220032 03FD0134 00006400
	v_lshl_add_u32 v43, v43, 24, v51                           // 00000051875C: D646002B 04CD312B
	v_pk_fma_f16 v45, v45, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000518764: CC0E002D 0BFC112D 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000518770: BF870224
	v_dual_dot2acc_f32_f16 v86, v47, v4 :: v_dual_dot2acc_f32_f16 v83, v49, v7// 000000518774: CB18092F 56520F31
	v_dual_dot2acc_f32_f16 v84, v49, v31 :: v_dual_dot2acc_f32_f16 v79, v44, v9// 00000051877C: CB183F31 544E132C
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000518784: D622002B 03FD012B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000518790: BF870194
	v_dual_dot2acc_f32_f16 v81, v45, v15 :: v_dual_and_b32 v48, 0xffff, v50// 000000518794: CB241F2D 513064FF 0000FFFF
	v_dual_dot2acc_f32_f16 v84, v47, v32 :: v_dual_dot2acc_f32_f16 v79, v42, v10// 0000005187A0: CB18412F 544E152A
	v_dual_dot2acc_f32_f16 v82, v44, v21 :: v_dual_dot2acc_f32_f16 v77, v42, v26// 0000005187A8: CB182B2C 524C352A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000005187B0: BF870233
	v_lshl_or_b32 v43, v43, 16, v48                            // 0000005187B4: D656002B 04C1212B
	.long 0xd73d0028                                           // 0000005187BC: D73D0028
	v_cndmask_b32_e32 v1, v134, v40, vcc_lo                    // 0000005187C0: 02025186
	v_dot2acc_f32_f16 v78, v44, v1                             // 0000005187C4: 049C032C
	v_dual_dot2acc_f32_f16 v82, v42, v22 :: v_dual_dot2acc_f32_f16 v75, v44, v5// 0000005187C8: CB182D2A 524A0B2C
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005187D0: BF870004
	v_pk_fma_f16 v43, v43, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000005187D4: CC0E002B 0BFC112B 0000C931
	v_dual_dot2acc_f32_f16 v76, v44, v29 :: v_dual_dot2acc_f32_f16 v79, v45, v11// 0000005187E0: CB183B2C 4C4E172D
	v_dot2acc_f32_f16 v80, v44, v17                            // 0000005187E8: 04A0232C
	v_bfe_u32 v41, v40, 9, 16                                  // 0000005187EC: D6100029 02411328
	v_dual_dot2acc_f32_f16 v82, v45, v23 :: v_dual_dot2acc_f32_f16 v75, v42, v6// 0000005187F4: CB182F2D 524A0D2A
	v_dot2acc_f32_f16 v78, v42, v2                             // 0000005187FC: 049C052A
	v_dual_dot2acc_f32_f16 v76, v42, v30 :: v_dual_dot2acc_f32_f16 v79, v43, v12// 000000518800: CB183D2A 4C4E192B
	v_dual_dot2acc_f32_f16 v80, v42, v18 :: v_dual_dot2acc_f32_f16 v77, v45, v27// 000000518808: CB18252A 504C372D
	v_mul_u32_u24_e32 v42, s0, v41                             // 000000518810: 16545200
	v_mul_u32_u24_e32 v41, s7, v41                             // 000000518814: 16525207
	v_lshl_add_u32 v41, v41, 24, v42                           // 000000518818: D6460029 04A93129
	s_waitcnt vmcnt(0)                                         // 000000518820: BF8903F7
	.long 0xd73d0026                                           // 000000518824: D73D0026
	v_cndmask_b32_e32 v1, v136, v38, vcc_lo                    // 000000518828: 02024D88
	v_bfe_u32 v42, v40, 6, 16                                  // 00000051882C: D610002A 02410D28
	v_bfe_u32 v44, v40, 3, 16                                  // 000000518834: D610002C 02410728
	v_dual_dot2acc_f32_f16 v82, v43, v24 :: v_dual_dot2acc_f32_f16 v75, v45, v7// 00000051883C: CB18312B 524A0F2D
	v_sad_u8 v39, v41, 0, 0x6400                               // 000000518844: D6220027 03FD0129 00006400
	v_mul_u32_u24_e32 v41, s0, v42                             // 000000518850: 16525400
	v_mul_u32_u24_e32 v42, s7, v42                             // 000000518854: 16545407
	v_lshl_add_u32 v41, v42, 24, v41                           // 000000518858: D6460029 04A5312A
	v_dual_dot2acc_f32_f16 v80, v45, v19 :: v_dual_dot2acc_f32_f16 v77, v43, v28// 000000518860: CB18272D 504C392B
	v_and_b32_e32 v39, 0xffff, v39                             // 000000518868: 364E4EFF 0000FFFF
	v_bfe_u32 v42, v38, 9, 16                                  // 000000518870: D610002A 02411326
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000518878: BF870244
	v_sad_u8 v41, v41, 0, 0x6400                               // 00000051887C: D6220029 03FD0129 00006400
	v_dot2acc_f32_f16 v75, v43, v8                             // 000000518888: 0496112B
	v_dual_mov_b32 v65, v165 :: v_dual_add_nc_u32 v132, 1, v132// 00000051888C: CA2001A5 41850881
	v_mov_b32_e32 v63, v145                                    // 000000518894: 7E7E0391
	v_lshl_or_b32 v39, v41, 16, v39                            // 000000518898: D6560027 049D2129
	v_dot2acc_f32_f16 v83, v47, v8                             // 0000005188A0: 04A6112F
	v_dot2acc_f32_f16 v81, v43, v16                            // 0000005188A4: 04A2212B
	v_dual_mov_b32 v62, v159 :: v_dual_add_nc_u32 v135, 32, v135// 0000005188A8: CA20019F 3E870EA0
	v_mov_b32_e32 v49, v154                                    // 0000005188B0: 7E62039A
	v_pk_fma_f16 v39, v39, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000005188B4: CC0E0027 0BFC1127 0000C931
	v_and_b32_e32 v40, 0xffff, v40                             // 0000005188C0: 365050FF 0000FFFF
	v_dual_mov_b32 v64, v169 :: v_dual_mov_b32 v59, v144       // 0000005188C8: CA1001A9 403A0190
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005188D0: BF870003
	v_dual_mov_b32 v58, v156 :: v_dual_dot2acc_f32_f16 v73, v39, v13// 0000005188D4: CA18019C 3A481B27
	v_dual_dot2acc_f32_f16 v78, v45, v3 :: v_dual_dot2acc_f32_f16 v71, v39, v9// 0000005188DC: CB18072D 4E461327
	v_dot2acc_f32_f16 v76, v45, v31                            // 0000005188E4: 04983F2D
	v_mul_u32_u24_e32 v45, s0, v44                             // 0000005188E8: 165A5800
	v_mul_u32_u24_e32 v44, s7, v44                             // 0000005188EC: 16585807
	v_lshl_add_u32 v44, v44, 24, v45                           // 0000005188F0: D646002C 04B5312C
	v_dot2acc_f32_f16 v69, v39, v25                            // 0000005188F8: 048A3327
	v_mul_u32_u24_e32 v46, s0, v40                             // 0000005188FC: 165C5000
	v_mul_u32_u24_e32 v40, s7, v40                             // 000000518900: 16505007
	v_lshl_add_u32 v40, v40, 24, v46                           // 000000518904: D6460028 04B93128
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000051890C: D622002C 03FD012C 00006400
	v_mul_u32_u24_e32 v46, s0, v42                             // 000000518918: 165C5400
	v_mul_u32_u24_e32 v42, s7, v42                             // 00000051891C: 16545407
	v_lshl_add_u32 v42, v42, 24, v46                           // 000000518920: D646002A 04B9312A
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000518928: D6220028 03FD0128 00006400
	v_dual_dot2acc_f32_f16 v33, v39, v5 :: v_dual_and_b32 v44, 0xffff, v44// 000000518934: CB240B27 212C58FF 0000FFFF
	v_bfe_u32 v46, v38, 3, 16                                  // 000000518940: D610002E 02410726
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000518948: BF8701A4
	v_sad_u8 v41, v42, 0, 0x6400                               // 00000051894C: D6220029 03FD012A 00006400
	v_mul_u32_u24_e32 v42, s0, v46                             // 000000518958: 16545C00
	v_lshl_or_b32 v40, v40, 16, v44                            // 00000051895C: D6560028 04B12128
	v_mul_u32_u24_e32 v44, s7, v46                             // 000000518964: 16585C07
	v_bfe_u32 v45, v38, 6, 16                                  // 000000518968: D610002D 02410D26
	v_lshl_add_u32 v42, v44, 24, v42                           // 000000518970: D646002A 04A9312C
	v_mul_u32_u24_e32 v44, s0, v45                             // 000000518978: 16585A00
	v_mul_u32_u24_e32 v45, s7, v45                             // 00000051897C: 165A5A07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000518980: BF870242
	v_lshl_add_u32 v44, v45, 24, v44                           // 000000518984: D646002C 04B1312D
	v_dual_dot2acc_f32_f16 v80, v43, v20 :: v_dual_and_b32 v41, 0xffff, v41// 00000051898C: CB24292B 502852FF 0000FFFF
	v_pk_fma_f16 v40, v40, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000518998: CC0E0028 0BFC1128 0000C931
	v_dot2acc_f32_f16 v72, v39, v17                            // 0000005189A4: 04902327
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000005189A8: D622002C 03FD012C 00006400
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000005189B4: D622002A 03FD012A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005189C0: BF870224
	v_dual_dot2acc_f32_f16 v74, v39, v21 :: v_dual_dot2acc_f32_f16 v69, v40, v26// 0000005189C4: CB182B27 4A443528
	v_dot2acc_f32_f16 v73, v40, v14                            // 0000005189CC: 04921D28
	v_lshl_or_b32 v41, v44, 16, v41                            // 0000005189D0: D6560029 04A5212C
	v_dual_dot2acc_f32_f16 v78, v43, v4 :: v_dual_dot2acc_f32_f16 v71, v40, v10// 0000005189D8: CB18092B 4E461528
	v_dual_dot2acc_f32_f16 v70, v39, v1 :: v_dual_add_nc_u32 v1, v133, v132// 0000005189E0: CB200327 46010985
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000005189E8: BF870243
	v_pk_fma_f16 v17, v41, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000005189EC: CC0E0011 0BFC1129 0000C931
	v_dot2acc_f32_f16 v76, v43, v32                            // 0000005189F8: 0498412B
	v_dot2acc_f32_f16 v74, v40, v22                            // 0000005189FC: 04942D28
	v_dot2acc_f32_f16 v33, v40, v6                             // 000000518A00: 04420D28
	v_dual_dot2acc_f32_f16 v72, v40, v18 :: v_dual_dot2acc_f32_f16 v73, v17, v15// 000000518A04: CB182528 48481F11
	v_and_b32_e32 v38, 0xffff, v38                             // 000000518A0C: 364C4CFF 0000FFFF
	v_mul_u32_u24_e32 v45, s0, v38                             // 000000518A14: 165A4C00
	v_mul_u32_u24_e32 v38, s7, v38                             // 000000518A18: 164C4C07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000518A1C: BF870241
	v_lshl_add_u32 v38, v38, 24, v45                           // 000000518A20: D6460026 04B53126
	v_dual_dot2acc_f32_f16 v71, v17, v11 :: v_dual_and_b32 v42, 0xffff, v42// 000000518A28: CB241711 472A54FF 0000FFFF
	v_dot2acc_f32_f16 v69, v17, v27                            // 000000518A34: 048A3711
	v_dot2acc_f32_f16 v33, v17, v7                             // 000000518A38: 04420F11
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000518A3C: D6220026 03FD0126 00006400
	v_dot2acc_f32_f16 v74, v17, v23                            // 000000518A48: 04942F11
	v_dual_dot2acc_f32_f16 v72, v17, v19 :: v_dual_mov_b32 v5, v170// 000000518A4C: CB102711 480401AA
	v_cmp_eq_u32_e32 vcc_lo, 1, v1                             // 000000518A54: 7C940281
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000518A58: BF870244
	v_lshl_or_b32 v13, v38, 16, v42                            // 000000518A5C: D656000D 04A92126
	v_dual_mov_b32 v1, v162 :: v_dual_mov_b32 v6, v167         // 000000518A64: CA1001A2 010601A7
	v_mov_b32_e32 v47, v141                                    // 000000518A6C: 7E5E038D
	v_mov_b32_e32 v61, v163                                    // 000000518A70: 7E7A03A3
	v_pk_fma_f16 v13, v13, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000518A74: CC0E000D 0BFC110D 0000C931
	v_dot2acc_f32_f16 v68, v39, v29                            // 000000518A80: 04883B27
	v_dot2acc_f32_f16 v70, v40, v2                             // 000000518A84: 048C0528
	v_dual_mov_b32 v2, v146 :: v_dual_mov_b32 v53, v157        // 000000518A88: CA100192 0234019D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000518A90: BF870223
	v_dual_dot2acc_f32_f16 v69, v13, v28 :: v_dual_dot2acc_f32_f16 v68, v40, v30// 000000518A94: CB18390D 45443D28
	v_dot2acc_f32_f16 v33, v13, v8                             // 000000518A9C: 0442110D
	v_dot2acc_f32_f16 v70, v17, v3                             // 000000518AA0: 048C0711
	v_dot2acc_f32_f16 v74, v13, v24                            // 000000518AA4: 0494310D
	v_dot2acc_f32_f16 v73, v13, v16                            // 000000518AA8: 0492210D
	v_dual_dot2acc_f32_f16 v68, v17, v31 :: v_dual_mov_b32 v55, v143// 000000518AAC: CB103F11 4436018F
	v_dot2acc_f32_f16 v72, v13, v20                            // 000000518AB4: 0490290D
	v_dot2acc_f32_f16 v71, v13, v12                            // 000000518AB8: 048E190D
	v_dual_dot2acc_f32_f16 v70, v13, v4 :: v_dual_mov_b32 v57, v160// 000000518ABC: CB10090D 463801A0
	s_delay_alu instid0(VALU_DEP_4)                            // 000000518AC4: BF870004
	v_dual_dot2acc_f32_f16 v68, v13, v32 :: v_dual_mov_b32 v51, v142// 000000518AC8: CB10410D 4432018E
	v_dual_mov_b32 v60, v168 :: v_dual_mov_b32 v39, v150       // 000000518AD0: CA1001A8 3C260196
	v_dual_mov_b32 v54, v153 :: v_dual_mov_b32 v45, v152       // 000000518AD8: CA100199 362C0198
	v_mov_b32_e32 v56, v166                                    // 000000518AE0: 7E7003A6
	v_mov_b32_e32 v50, v151                                    // 000000518AE4: 7E640397
	v_mov_b32_e32 v52, v164                                    // 000000518AE8: 7E6803A4
	v_mov_b32_e32 v46, v149                                    // 000000518AEC: 7E5C0395
	v_dual_mov_b32 v48, v161 :: v_dual_mov_b32 v43, v140       // 000000518AF0: CA1001A1 302A018C
	v_mov_b32_e32 v42, v148                                    // 000000518AF8: 7E540394
	v_dual_mov_b32 v44, v158 :: v_dual_mov_b32 v41, v139       // 000000518AFC: CA10019E 2C28018B
	v_mov_b32_e32 v40, v147                                    // 000000518B04: 7E500393
	v_mov_b32_e32 v38, v155                                    // 000000518B08: 7E4C039B
	s_or_b32 s6, vcc_lo, s6                                    // 000000518B0C: 8C06066A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000518B10: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000518B14: 917E067E
	s_cbranch_execz 92                                         // 000000518B18: BFA5005C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x228c>
	s_mov_b32 s9, exec_lo                                      // 000000518B1C: BE89007E
	.long 0xd4c1007e                                           // 000000518B20: D4C1007E
	v_cndmask_b32_e32 v1, v132, v89, vcc_lo                    // 000000518B24: 0202B384
	s_cbranch_execz 64319                                      // 000000518B28: BFA5FB3F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xe28>
	v_mad_i64_i32 v[3:4], null, 0x300, v132, s[4:5]            // 000000518B2C: D6FF7C03 001308FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000518B38: BF870091
	.long 0xd7006a07                                           // 000000518B3C: D7006A07
	v_cndmask_b32_e32 v1, v3, v34, vcc_lo                      // 000000518B40: 02024503
	v_add_co_ci_u32_e64 v8, null, v4, v35, vcc_lo              // 000000518B44: D5207C08 01AA4704
	.long 0xd7006a09                                           // 000000518B4C: D7006A09
	v_cndmask_b32_e32 v1, v3, v137, vcc_lo                     // 000000518B50: 02031303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000518B54: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v4, vcc_lo               // 000000518B58: D5207C0A 01AA0880
	.long 0xd7006a0b                                           // 000000518B60: D7006A0B
	v_cndmask_b32_e32 v1, v3, v36, vcc_lo                      // 000000518B64: 02024903
	v_add_co_ci_u32_e64 v12, null, v4, v37, vcc_lo             // 000000518B68: D5207C0C 01AA4B04
	.long 0xd7006a03                                           // 000000518B70: D7006A03
	v_cndmask_b32_e32 v1, v3, v138, vcc_lo                     // 000000518B74: 02031503
	s_delay_alu instid0(VALU_DEP_1)                            // 000000518B78: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000518B7C: D5207C04 01AA0880
	s_clause 0x1f                                              // 000000518B84: BF85001F
	global_load_b32 v146, v[7:8], off                          // 000000518B88: DC520000 927C0007
	global_load_b32 v145, v[7:8], off offset:96                // 000000518B90: DC520060 917C0007
	global_load_b32 v144, v[7:8], off offset:192               // 000000518B98: DC5200C0 907C0007
	global_load_b32 v143, v[7:8], off offset:288               // 000000518BA0: DC520120 8F7C0007
	global_load_b32 v142, v[7:8], off offset:384               // 000000518BA8: DC520180 8E7C0007
	global_load_b32 v141, v[7:8], off offset:480               // 000000518BB0: DC5201E0 8D7C0007
	global_load_b32 v140, v[7:8], off offset:576               // 000000518BB8: DC520240 8C7C0007
	global_load_b32 v139, v[7:8], off offset:672               // 000000518BC0: DC5202A0 8B7C0007
	global_load_b32 v162, v[9:10], off                         // 000000518BC8: DC520000 A27C0009
	global_load_b32 v159, v[9:10], off offset:96               // 000000518BD0: DC520060 9F7C0009
	global_load_b32 v156, v[9:10], off offset:192              // 000000518BD8: DC5200C0 9C7C0009
	global_load_b32 v153, v[9:10], off offset:288              // 000000518BE0: DC520120 997C0009
	global_load_b32 v151, v[9:10], off offset:384              // 000000518BE8: DC520180 977C0009
	global_load_b32 v149, v[9:10], off offset:480              // 000000518BF0: DC5201E0 957C0009
	global_load_b32 v148, v[9:10], off offset:576              // 000000518BF8: DC520240 947C0009
	global_load_b32 v147, v[9:10], off offset:672              // 000000518C00: DC5202A0 937C0009
	global_load_b32 v167, v[11:12], off                        // 000000518C08: DC520000 A77C000B
	global_load_b32 v165, v[11:12], off offset:96              // 000000518C10: DC520060 A57C000B
	global_load_b32 v163, v[11:12], off offset:192             // 000000518C18: DC5200C0 A37C000B
	global_load_b32 v160, v[11:12], off offset:288             // 000000518C20: DC520120 A07C000B
	global_load_b32 v157, v[11:12], off offset:384             // 000000518C28: DC520180 9D7C000B
	global_load_b32 v154, v[11:12], off offset:480             // 000000518C30: DC5201E0 9A7C000B
	global_load_b32 v152, v[11:12], off offset:576             // 000000518C38: DC520240 987C000B
	global_load_b32 v150, v[11:12], off offset:672             // 000000518C40: DC5202A0 967C000B
	global_load_b32 v170, v[3:4], off                          // 000000518C48: DC520000 AA7C0003
	global_load_b32 v169, v[3:4], off offset:96                // 000000518C50: DC520060 A97C0003
	global_load_b32 v168, v[3:4], off offset:192               // 000000518C58: DC5200C0 A87C0003
	global_load_b32 v166, v[3:4], off offset:288               // 000000518C60: DC520120 A67C0003
	global_load_b32 v164, v[3:4], off offset:384               // 000000518C68: DC520180 A47C0003
	global_load_b32 v161, v[3:4], off offset:480               // 000000518C70: DC5201E0 A17C0003
	global_load_b32 v158, v[3:4], off offset:576               // 000000518C78: DC520240 9E7C0003
	global_load_b32 v155, v[3:4], off offset:672               // 000000518C80: DC5202A0 9B7C0003
	s_branch 64231                                             // 000000518C88: BFA0FAE7 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xe28>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000518C8C: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000518C90: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000518C94: 8C7E017E
	s_waitcnt vmcnt(23)                                        // 000000518C98: BF895FF7
	v_dual_mov_b32 v1, v131 :: v_dual_mov_b32 v4, v121         // 000000518C9C: CA100183 01040179
	v_dual_mov_b32 v2, v127 :: v_dual_mov_b32 v3, v122         // 000000518CA4: CA10017F 0202017A
	s_waitcnt vmcnt(7)                                         // 000000518CAC: BF891FF7
	v_dual_mov_b32 v5, v124 :: v_dual_mov_b32 v10, v129        // 000000518CB0: CA10017C 050A0181
	v_dual_mov_b32 v6, v120 :: v_dual_mov_b32 v7, v118         // 000000518CB8: CA100178 06060176
	v_dual_mov_b32 v8, v116 :: v_dual_mov_b32 v9, v130         // 000000518CC0: CA100174 08080182
	v_dual_mov_b32 v11, v128 :: v_dual_mov_b32 v12, v126       // 000000518CC8: CA100180 0B0C017E
	v_dual_mov_b32 v13, v125 :: v_dual_mov_b32 v14, v123       // 000000518CD0: CA10017D 0D0E017B
	v_dual_mov_b32 v15, v119 :: v_dual_mov_b32 v16, v117       // 000000518CD8: CA100177 0F100175
	v_dual_mov_b32 v17, v115 :: v_dual_mov_b32 v18, v114       // 000000518CE0: CA100173 11120172
	v_dual_mov_b32 v19, v113 :: v_dual_mov_b32 v20, v112       // 000000518CE8: CA100171 13140170
	v_dual_mov_b32 v21, v111 :: v_dual_mov_b32 v22, v110       // 000000518CF0: CA10016F 1516016E
	v_dual_mov_b32 v23, v109 :: v_dual_mov_b32 v24, v108       // 000000518CF8: CA10016D 1718016C
	v_dual_mov_b32 v25, v107 :: v_dual_mov_b32 v26, v106       // 000000518D00: CA10016B 191A016A
	v_dual_mov_b32 v27, v105 :: v_dual_mov_b32 v28, v104       // 000000518D08: CA100169 1B1C0168
	v_dual_mov_b32 v29, v103 :: v_dual_mov_b32 v30, v102       // 000000518D10: CA100167 1D1E0166
	v_dual_mov_b32 v31, v101 :: v_dual_mov_b32 v32, v100       // 000000518D18: CA100165 1F200164
	v_dual_mov_b32 v34, v99 :: v_dual_mov_b32 v35, v98         // 000000518D20: CA100163 22220162
	v_dual_mov_b32 v36, v97 :: v_dual_mov_b32 v37, v96         // 000000518D28: CA100161 24240160
	s_waitcnt vmcnt(0)                                         // 000000518D30: BF8903F7
	v_dual_mov_b32 v38, v95 :: v_dual_mov_b32 v39, v94         // 000000518D34: CA10015F 2626015E
	v_dual_mov_b32 v40, v93 :: v_dual_mov_b32 v41, v92         // 000000518D3C: CA10015D 2828015C
	v_dual_mov_b32 v42, v91 :: v_dual_mov_b32 v43, v90         // 000000518D44: CA10015B 2A2A015A
	v_dual_mov_b32 v44, v88 :: v_dual_mov_b32 v45, v87         // 000000518D4C: CA100158 2C2C0157
	v_dual_mov_b32 v46, v86 :: v_dual_mov_b32 v47, v85         // 000000518D54: CA100156 2E2E0155
	v_dual_mov_b32 v48, v84 :: v_dual_mov_b32 v49, v83         // 000000518D5C: CA100154 30300153
	v_dual_mov_b32 v50, v82 :: v_dual_mov_b32 v51, v81         // 000000518D64: CA100152 32320151
	v_dual_mov_b32 v52, v80 :: v_dual_mov_b32 v53, v79         // 000000518D6C: CA100150 3434014F
	v_dual_mov_b32 v54, v78 :: v_dual_mov_b32 v55, v77         // 000000518D74: CA10014E 3636014D
	v_dual_mov_b32 v56, v76 :: v_dual_mov_b32 v57, v75         // 000000518D7C: CA10014C 3838014B
	v_dual_mov_b32 v58, v74 :: v_dual_mov_b32 v59, v73         // 000000518D84: CA10014A 3A3A0149
	v_dual_mov_b32 v60, v72 :: v_dual_mov_b32 v61, v71         // 000000518D8C: CA100148 3C3C0147
	v_dual_mov_b32 v62, v70 :: v_dual_mov_b32 v63, v69         // 000000518D94: CA100146 3E3E0145
	v_dual_mov_b32 v64, v68 :: v_dual_mov_b32 v65, v33         // 000000518D9C: CA100144 40400121
	s_mov_b32 s0, 0x76543210                                   // 000000518DA4: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000518DAC: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000518DB0: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000518DBC: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000518DC8: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000518DD4: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000518DE0: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000518DEC: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000518DF8: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000518E04: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000518E10: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000518E1C: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000518E28: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000518E34: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000518E40: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000518E4C: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000518E58: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000518E64: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000518E70: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 000000518E7C: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 000000518E88: D65C0013 03FC0113 FEDCBA98
	v_permlanex16_b32 v20, v20, s0, 0xfedcba98                 // 000000518E94: D65C0014 03FC0114 FEDCBA98
	v_permlanex16_b32 v21, v21, s0, 0xfedcba98                 // 000000518EA0: D65C0015 03FC0115 FEDCBA98
	v_permlanex16_b32 v22, v22, s0, 0xfedcba98                 // 000000518EAC: D65C0016 03FC0116 FEDCBA98
	v_permlanex16_b32 v23, v23, s0, 0xfedcba98                 // 000000518EB8: D65C0017 03FC0117 FEDCBA98
	v_permlanex16_b32 v24, v24, s0, 0xfedcba98                 // 000000518EC4: D65C0018 03FC0118 FEDCBA98
	v_permlanex16_b32 v25, v25, s0, 0xfedcba98                 // 000000518ED0: D65C0019 03FC0119 FEDCBA98
	v_permlanex16_b32 v26, v26, s0, 0xfedcba98                 // 000000518EDC: D65C001A 03FC011A FEDCBA98
	v_permlanex16_b32 v27, v27, s0, 0xfedcba98                 // 000000518EE8: D65C001B 03FC011B FEDCBA98
	v_permlanex16_b32 v28, v28, s0, 0xfedcba98                 // 000000518EF4: D65C001C 03FC011C FEDCBA98
	v_permlanex16_b32 v29, v29, s0, 0xfedcba98                 // 000000518F00: D65C001D 03FC011D FEDCBA98
	v_permlanex16_b32 v30, v30, s0, 0xfedcba98                 // 000000518F0C: D65C001E 03FC011E FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 000000518F18: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 000000518F24: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v34, v34, s0, 0xfedcba98                 // 000000518F30: D65C0022 03FC0122 FEDCBA98
	v_permlanex16_b32 v35, v35, s0, 0xfedcba98                 // 000000518F3C: D65C0023 03FC0123 FEDCBA98
	v_permlanex16_b32 v36, v36, s0, 0xfedcba98                 // 000000518F48: D65C0024 03FC0124 FEDCBA98
	v_permlanex16_b32 v37, v37, s0, 0xfedcba98                 // 000000518F54: D65C0025 03FC0125 FEDCBA98
	v_permlanex16_b32 v38, v38, s0, 0xfedcba98                 // 000000518F60: D65C0026 03FC0126 FEDCBA98
	v_permlanex16_b32 v39, v39, s0, 0xfedcba98                 // 000000518F6C: D65C0027 03FC0127 FEDCBA98
	v_permlanex16_b32 v40, v40, s0, 0xfedcba98                 // 000000518F78: D65C0028 03FC0128 FEDCBA98
	v_permlanex16_b32 v41, v41, s0, 0xfedcba98                 // 000000518F84: D65C0029 03FC0129 FEDCBA98
	v_permlanex16_b32 v42, v42, s0, 0xfedcba98                 // 000000518F90: D65C002A 03FC012A FEDCBA98
	v_permlanex16_b32 v43, v43, s0, 0xfedcba98                 // 000000518F9C: D65C002B 03FC012B FEDCBA98
	v_permlanex16_b32 v44, v44, s0, 0xfedcba98                 // 000000518FA8: D65C002C 03FC012C FEDCBA98
	v_permlanex16_b32 v45, v45, s0, 0xfedcba98                 // 000000518FB4: D65C002D 03FC012D FEDCBA98
	v_permlanex16_b32 v46, v46, s0, 0xfedcba98                 // 000000518FC0: D65C002E 03FC012E FEDCBA98
	v_permlanex16_b32 v47, v47, s0, 0xfedcba98                 // 000000518FCC: D65C002F 03FC012F FEDCBA98
	v_permlanex16_b32 v48, v48, s0, 0xfedcba98                 // 000000518FD8: D65C0030 03FC0130 FEDCBA98
	v_permlanex16_b32 v49, v49, s0, 0xfedcba98                 // 000000518FE4: D65C0031 03FC0131 FEDCBA98
	v_permlanex16_b32 v50, v50, s0, 0xfedcba98                 // 000000518FF0: D65C0032 03FC0132 FEDCBA98
	v_permlanex16_b32 v51, v51, s0, 0xfedcba98                 // 000000518FFC: D65C0033 03FC0133 FEDCBA98
	v_permlanex16_b32 v52, v52, s0, 0xfedcba98                 // 000000519008: D65C0034 03FC0134 FEDCBA98
	v_permlanex16_b32 v53, v53, s0, 0xfedcba98                 // 000000519014: D65C0035 03FC0135 FEDCBA98
	v_permlanex16_b32 v54, v54, s0, 0xfedcba98                 // 000000519020: D65C0036 03FC0136 FEDCBA98
	v_permlanex16_b32 v55, v55, s0, 0xfedcba98                 // 00000051902C: D65C0037 03FC0137 FEDCBA98
	v_permlanex16_b32 v56, v56, s0, 0xfedcba98                 // 000000519038: D65C0038 03FC0138 FEDCBA98
	v_permlanex16_b32 v57, v57, s0, 0xfedcba98                 // 000000519044: D65C0039 03FC0139 FEDCBA98
	v_permlanex16_b32 v58, v58, s0, 0xfedcba98                 // 000000519050: D65C003A 03FC013A FEDCBA98
	v_permlanex16_b32 v59, v59, s0, 0xfedcba98                 // 00000051905C: D65C003B 03FC013B FEDCBA98
	v_permlanex16_b32 v60, v60, s0, 0xfedcba98                 // 000000519068: D65C003C 03FC013C FEDCBA98
	v_permlanex16_b32 v61, v61, s0, 0xfedcba98                 // 000000519074: D65C003D 03FC013D FEDCBA98
	v_permlanex16_b32 v62, v62, s0, 0xfedcba98                 // 000000519080: D65C003E 03FC013E FEDCBA98
	v_permlanex16_b32 v63, v63, s0, 0xfedcba98                 // 00000051908C: D65C003F 03FC013F FEDCBA98
	v_permlanex16_b32 v64, v64, s0, 0xfedcba98                 // 000000519098: D65C0040 03FC0140 FEDCBA98
	v_permlanex16_b32 v65, v65, s0, 0xfedcba98                 // 0000005190A4: D65C0041 03FC0141 FEDCBA98
	.long 0xd44c0000                                           // 0000005190B0: D44C0000
	v_cndmask_b32_e32 v1, 16, v67, vcc_lo                      // 0000005190B4: 02028690
	s_barrier                                                  // 0000005190B8: BFBD0000
	buffer_gl0_inv                                             // 0000005190BC: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000005190C4: BE812000
	s_cbranch_execz 138                                        // 0000005190C8: BFA5008A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x28f4>
	v_dual_add_f32 v33, v33, v65 :: v_dual_add_f32 v64, v68, v64// 0000005190CC: C9088321 21408144
	v_dual_add_f32 v8, v116, v8 :: v_dual_lshlrev_b32 v65, 2, v67// 0000005190D4: C9221174 08408682
	v_dual_add_f32 v10, v129, v10 :: v_dual_add_f32 v9, v130, v9// 0000005190DC: C9081581 0A081382
	v_add_f32_e32 v1, v131, v1                                 // 0000005190E4: 06020383
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000005190E8: BF8701B3
	v_lshl_or_b32 v65, v66, 12, v65                            // 0000005190EC: D6560041 05051942
	v_dual_add_f32 v2, v127, v2 :: v_dual_add_f32 v3, v122, v3 // 0000005190F4: C908057F 0202077A
	v_dual_add_f32 v12, v126, v12 :: v_dual_add_f32 v11, v128, v11// 0000005190FC: C908197E 0C0A1780
	v_add_nc_u32_e32 v67, 0x400, v65                           // 000000519104: 4A8682FF 00000400
	v_dual_add_f32 v5, v124, v5 :: v_dual_add_f32 v4, v121, v4 // 00000051910C: C9080B7C 05040979
	v_dual_add_f32 v14, v123, v14 :: v_dual_add_f32 v13, v125, v13// 000000519114: C9081D7B 0E0C1B7D
	ds_store_2addr_b32 v65, v1, v9 offset1:16                  // 00000051911C: D8381000 00090141
	v_add_nc_u32_e32 v1, 0x800, v65                            // 000000519124: 4A0282FF 00000800
	v_dual_add_f32 v7, v118, v7 :: v_dual_add_f32 v6, v120, v6 // 00000051912C: C9080F76 07060D78
	v_dual_add_f32 v16, v117, v16 :: v_dual_add_f32 v15, v119, v15// 000000519134: C9082175 100E1F77
	ds_store_2addr_b32 v65, v2, v10 offset0:128 offset1:144    // 00000051913C: D8389080 000A0241
	v_dual_add_f32 v63, v69, v63 :: v_dual_add_nc_u32 v2, 0xc00, v65// 000000519144: C9207F45 3F0282FF 00000C00
	v_dual_add_f32 v62, v70, v62 :: v_dual_add_f32 v61, v71, v61// 000000519150: C9087D46 3E3C7B47
	v_dual_add_f32 v60, v72, v60 :: v_dual_add_f32 v59, v73, v59// 000000519158: C9087948 3C3A7749
	v_dual_add_f32 v58, v74, v58 :: v_dual_add_f32 v57, v75, v57// 000000519160: C908754A 3A38734B
	v_dual_add_f32 v56, v76, v56 :: v_dual_add_f32 v55, v77, v55// 000000519168: C908714C 38366F4D
	v_dual_add_f32 v54, v78, v54 :: v_dual_add_f32 v53, v79, v53// 000000519170: C9086D4E 36346B4F
	v_dual_add_f32 v52, v80, v52 :: v_dual_add_f32 v51, v81, v51// 000000519178: C9086950 34326751
	v_dual_add_f32 v50, v82, v50 :: v_dual_add_f32 v49, v83, v49// 000000519180: C9086552 32306353
	v_dual_add_f32 v48, v84, v48 :: v_dual_add_f32 v47, v85, v47// 000000519188: C9086154 302E5F55
	v_dual_add_f32 v46, v86, v46 :: v_dual_add_f32 v45, v87, v45// 000000519190: C9085D56 2E2C5B57
	v_dual_add_f32 v44, v88, v44 :: v_dual_add_f32 v43, v90, v43// 000000519198: C9085958 2C2A575A
	v_dual_add_f32 v42, v91, v42 :: v_dual_add_f32 v41, v92, v41// 0000005191A0: C908555B 2A28535C
	v_dual_add_f32 v40, v93, v40 :: v_dual_add_f32 v39, v94, v39// 0000005191A8: C908515D 28264F5E
	v_dual_add_f32 v38, v95, v38 :: v_dual_add_f32 v37, v96, v37// 0000005191B0: C9084D5F 26244B60
	v_dual_add_f32 v36, v97, v36 :: v_dual_add_f32 v35, v98, v35// 0000005191B8: C9084961 24224762
	v_add_f32_e32 v34, v99, v34                                // 0000005191C0: 06444563
	v_dual_add_f32 v32, v100, v32 :: v_dual_add_f32 v31, v101, v31// 0000005191C4: C9084164 201E3F65
	v_dual_add_f32 v30, v102, v30 :: v_dual_add_f32 v29, v103, v29// 0000005191CC: C9083D66 1E1C3B67
	v_dual_add_f32 v28, v104, v28 :: v_dual_add_f32 v27, v105, v27// 0000005191D4: C9083968 1C1A3769
	v_dual_add_f32 v26, v106, v26 :: v_dual_add_f32 v25, v107, v25// 0000005191DC: C908356A 1A18336B
	v_dual_add_f32 v24, v108, v24 :: v_dual_add_f32 v23, v109, v23// 0000005191E4: C908316C 18162F6D
	v_dual_add_f32 v22, v110, v22 :: v_dual_add_f32 v21, v111, v21// 0000005191EC: C9082D6E 16142B6F
	v_dual_add_f32 v20, v112, v20 :: v_dual_add_f32 v19, v113, v19// 0000005191F4: C9082970 14122771
	v_dual_add_f32 v18, v114, v18 :: v_dual_add_f32 v17, v115, v17// 0000005191FC: C9082572 12102373
	ds_store_2addr_b32 v67, v3, v11 offset1:16                 // 000000519204: D8381000 000B0343
	ds_store_2addr_b32 v67, v4, v12 offset0:128 offset1:144    // 00000051920C: D8389080 000C0443
	ds_store_2addr_b32 v1, v5, v13 offset1:16                  // 000000519214: D8381000 000D0501
	ds_store_2addr_b32 v1, v6, v14 offset0:128 offset1:144     // 00000051921C: D8389080 000E0601
	ds_store_2addr_b32 v2, v7, v15 offset1:16                  // 000000519224: D8381000 000F0702
	ds_store_2addr_b32 v2, v8, v16 offset0:128 offset1:144     // 00000051922C: D8389080 00100802
	ds_store_2addr_b32 v65, v17, v25 offset0:32 offset1:48     // 000000519234: D8383020 00191141
	ds_store_2addr_b32 v65, v18, v26 offset0:160 offset1:176   // 00000051923C: D838B0A0 001A1241
	ds_store_2addr_b32 v67, v19, v27 offset0:32 offset1:48     // 000000519244: D8383020 001B1343
	ds_store_2addr_b32 v67, v20, v28 offset0:160 offset1:176   // 00000051924C: D838B0A0 001C1443
	ds_store_2addr_b32 v1, v21, v29 offset0:32 offset1:48      // 000000519254: D8383020 001D1501
	ds_store_2addr_b32 v1, v22, v30 offset0:160 offset1:176    // 00000051925C: D838B0A0 001E1601
	ds_store_2addr_b32 v2, v23, v31 offset0:32 offset1:48      // 000000519264: D8383020 001F1702
	ds_store_2addr_b32 v2, v24, v32 offset0:160 offset1:176    // 00000051926C: D838B0A0 00201802
	ds_store_2addr_b32 v65, v34, v42 offset0:64 offset1:80     // 000000519274: D8385040 002A2241
	ds_store_2addr_b32 v65, v35, v43 offset0:192 offset1:208   // 00000051927C: D838D0C0 002B2341
	ds_store_2addr_b32 v67, v36, v44 offset0:64 offset1:80     // 000000519284: D8385040 002C2443
	ds_store_2addr_b32 v67, v37, v45 offset0:192 offset1:208   // 00000051928C: D838D0C0 002D2543
	ds_store_2addr_b32 v1, v38, v46 offset0:64 offset1:80      // 000000519294: D8385040 002E2601
	ds_store_2addr_b32 v1, v39, v47 offset0:192 offset1:208    // 00000051929C: D838D0C0 002F2701
	ds_store_2addr_b32 v2, v40, v48 offset0:64 offset1:80      // 0000005192A4: D8385040 00302802
	ds_store_2addr_b32 v2, v41, v49 offset0:192 offset1:208    // 0000005192AC: D838D0C0 00312902
	ds_store_2addr_b32 v65, v50, v58 offset0:96 offset1:112    // 0000005192B4: D8387060 003A3241
	ds_store_2addr_b32 v65, v51, v59 offset0:224 offset1:240   // 0000005192BC: D838F0E0 003B3341
	ds_store_2addr_b32 v67, v52, v60 offset0:96 offset1:112    // 0000005192C4: D8387060 003C3443
	ds_store_2addr_b32 v67, v53, v61 offset0:224 offset1:240   // 0000005192CC: D838F0E0 003D3543
	ds_store_2addr_b32 v1, v54, v62 offset0:96 offset1:112     // 0000005192D4: D8387060 003E3601
	ds_store_2addr_b32 v1, v55, v63 offset0:224 offset1:240    // 0000005192DC: D838F0E0 003F3701
	ds_store_2addr_b32 v2, v56, v64 offset0:96 offset1:112     // 0000005192E4: D8387060 00403802
	ds_store_2addr_b32 v2, v57, v33 offset0:224 offset1:240    // 0000005192EC: D838F0E0 00213902
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005192F4: 8C7E017E
	v_mov_b32_e32 v1, v0                                       // 0000005192F8: 7E020300
	s_mov_b32 s1, 0                                            // 0000005192FC: BE810080
	s_waitcnt lgkmcnt(0)                                       // 000000519300: BF89FC07
	s_barrier                                                  // 000000519304: BFBD0000
	buffer_gl0_inv                                             // 000000519308: E0AC0000 00000000
	s_nop 0                                                    // 000000519310: BF800000
	s_nop 0                                                    // 000000519314: BF800000
	s_nop 0                                                    // 000000519318: BF800000
	s_nop 0                                                    // 00000051931C: BF800000
	s_nop 0                                                    // 000000519320: BF800000
	s_nop 0                                                    // 000000519324: BF800000
	s_nop 0                                                    // 000000519328: BF800000
	s_nop 0                                                    // 00000051932C: BF800000
	s_nop 0                                                    // 000000519330: BF800000
	s_nop 0                                                    // 000000519334: BF800000
	s_nop 0                                                    // 000000519338: BF800000
	s_nop 0                                                    // 00000051933C: BF800000
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000519340: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v1                         // 000000519344: 7C9202FF 000002FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:16           // 00000051934C: D8E01000 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:32 offset1:48// 000000519354: D8E03020 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:64 offset1:80// 00000051935C: D8E05040 06000008
	s_or_b32 s1, vcc_lo, s1                                    // 000000519364: 8C01016A
	s_waitcnt lgkmcnt(2)                                       // 000000519368: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 00000051936C: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000519370: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000519374: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:96 offset1:112// 000000519378: D8E07060 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000519380: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000519384: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 000000519388: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 00000051938C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000519390: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000519394: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 000000519398: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 00000051939C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005193A0: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 0000005193A4: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 0000005193A8: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 0000005193B0: C9100702 02000104
	ds_store_b32 v8, v2 offset:32768                           // 0000005193B8: D8348000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000005193C0: 917E017E
	s_cbranch_execnz 65502                                     // 0000005193C4: BFA6FFDE <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2940>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005193C8: 8C7E017E
	s_cmp_lt_i32 s33, 2                                        // 0000005193CC: BF048221
	s_mov_b32 s1, -1                                           // 0000005193D0: BE8100C1
	s_cbranch_scc1 197                                         // 0000005193D4: BFA200C5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2cec>
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v1, 0x7f, v0       // 0000005193D8: CA240100 040000FF 0000007F
	s_lshl_b32 s4, s2, 7                                       // 0000005193E4: 84048702
	s_ashr_i32 s11, s10, 31                                    // 0000005193E8: 860B9F0A
	s_ashr_i32 s5, s4, 31                                      // 0000005193EC: 86059F04
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005193F0: BF870001
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000005193F4: 30040282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 0000005193F8: 84848204
	s_lshl_b64 s[6:7], s[10:11], 3                             // 0000005193FC: 8486830A
	s_ashr_i32 s27, s26, 31                                    // 000000519400: 861B9F1A
	s_add_u32 s1, s16, s4                                      // 000000519404: 80010410
	s_addc_u32 s8, s17, s5                                     // 000000519408: 82080511
	.long 0xd7000102                                           // 00000051940C: D7000102
	v_cndmask_b32_e32 v1, s1, v2, vcc_lo                       // 000000519410: 02020401
	s_delay_alu instid0(VALU_DEP_1)                            // 000000519414: BF870001
	v_add_co_ci_u32_e64 v3, null, s8, 0, s1                    // 000000519418: D5207C03 00050008
	s_mov_b32 s8, 0                                            // 000000519420: BE880080
	s_waitcnt lgkmcnt(0)                                       // 000000519424: BF89FC07
	s_barrier                                                  // 000000519428: BFBD0000
	buffer_gl0_inv                                             // 00000051942C: E0AC0000 00000000
	s_nop 0                                                    // 000000519434: BF800000
	s_nop 0                                                    // 000000519438: BF800000
	s_nop 0                                                    // 00000051943C: BF800000
	v_lshrrev_b32_e32 v5, 7, v4                                // 000000519440: 320A0887
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v4                         // 000000519444: 7C9208FF 000002FF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000051944C: BF870092
	.long 0xd7000105                                           // 000000519450: D7000105
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000519454: 02020A06
	v_add_co_ci_u32_e64 v6, null, s7, 0, s1                    // 000000519458: D5207C06 00050007
	s_or_b32 s8, vcc_lo, s8                                    // 000000519460: 8C08086A
	.long 0xd72c0009                                           // 000000519464: D72C0009
	v_cndmask_b32_e32 v0, v5, v27, vcc_lo                      // 000000519468: 02003705
	.long 0xd72c0008                                           // 00000051946C: D72C0008
	v_cndmask_b32_e32 v0, v6, v26, vcc_lo                      // 000000519470: 02003506
	v_mad_u64_u32 v[5:6], null, v5, s26, 0                     // 000000519474: D6FE7C05 02003505
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000051947C: BF8701B1
	v_add3_u32 v6, v6, v9, v8                                  // 000000519480: D6550006 04221306
	v_add_nc_u32_e32 v8, 0x100, v4                             // 000000519488: 4A1008FF 00000100
	v_lshlrev_b32_e32 v7, 2, v4                                // 000000519490: 300E0882
	.long 0xd73c0005                                           // 000000519494: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000519498: 02020A82
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000051949C: BF8700B3
	v_mov_b32_e32 v4, v8                                       // 0000005194A0: 7E080308
	ds_load_b32 v7, v7 offset:32768                            // 0000005194A4: D8D88000 07000007
	.long 0xd7000105                                           // 0000005194AC: D7000105
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 0000005194B0: 02020B02
	v_add_co_ci_u32_e64 v6, null, v3, v6, s1                   // 0000005194B4: D5207C06 00060D03
	s_waitcnt lgkmcnt(0)                                       // 0000005194BC: BF89FC07
	global_store_b32 v[5:6], v7, off                           // 0000005194C0: DC6A0000 007C0705
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 0000005194C8: 917E087E
	s_cbranch_execnz 65500                                     // 0000005194CC: BFA6FFDC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2a40>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000005194D0: 8C7E087E
	.long 0xd44a0001                                           // 0000005194D4: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000005194D8: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 0000005194DC: BC7C0000
	buffer_gl1_inv                                             // 0000005194E0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000005194E8: E0AC0000 00000000
	s_barrier                                                  // 0000005194F0: BFBD0000
	buffer_gl0_inv                                             // 0000005194F4: E0AC0000 00000000
	s_and_saveexec_b32 s6, s1                                  // 0000005194FC: BE862001
	s_cbranch_execz 29                                         // 000000519500: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2b78>
	s_mov_b32 s8, exec_lo                                      // 000000519504: BE88007E
	s_mov_b32 s7, exec_lo                                      // 000000519508: BE87007E
	.long 0xd71f0002                                           // 00000051950C: D71F0002
	v_cndmask_b32_e32 v0, s8, v128, vcc_lo                     // 000000519510: 02010008
	s_delay_alu instid0(VALU_DEP_1)                            // 000000519514: BF870001
	v_cmpx_eq_u32_e32 0, v2                                    // 000000519518: 7D940480
	s_cbranch_execz 9                                          // 00000051951C: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2b44>
	s_lshl_b64 s[10:11], s[2:3], 2                             // 000000519520: 848A8202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000519524: BF8704B9
	s_add_u32 s10, s18, s10                                    // 000000519528: 800A0A12
	s_addc_u32 s11, s19, s11                                   // 00000051952C: 820B0B13
	s_bcnt1_i32_b32 s8, s8                                     // 000000519530: BE881808
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v4, s8              // 000000519534: CA100080 03040008
	global_atomic_add_u32 v3, v3, v4, s[10:11] glc             // 00000051953C: DCD64000 030A0403
	s_or_b32 exec_lo, exec_lo, s7                              // 000000519544: 8C7E077E
	s_waitcnt vmcnt(0)                                         // 000000519548: BF8903F7
	v_readfirstlane_b32 s7, v3                                 // 00000051954C: 7E0E0503
	s_delay_alu instid0(VALU_DEP_1)                            // 000000519550: BF870001
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v2, s7, v2       // 000000519554: CA200080 03020407
	s_add_i32 s7, s33, -1                                      // 00000051955C: 8107C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000519560: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s7, v2                            // 000000519564: 7C940407
	v_cndmask_b32_e64 v2, 0, 1, vcc_lo                         // 000000519568: D5010002 01A90280
	ds_store_b32 v3, v2 offset:40960                           // 000000519570: D834A000 00000203
	s_or_b32 exec_lo, exec_lo, s6                              // 000000519578: 8C7E067E
	v_mov_b32_e32 v2, 0                                        // 00000051957C: 7E040280
	s_waitcnt lgkmcnt(0)                                       // 000000519580: BF89FC07
	s_barrier                                                  // 000000519584: BFBD0000
	buffer_gl0_inv                                             // 000000519588: E0AC0000 00000000
	s_mov_b32 s10, 0                                           // 000000519590: BE8A0080
	ds_load_b32 v2, v2 offset:40960                            // 000000519594: D8D8A000 02000002
	s_waitcnt lgkmcnt(0)                                       // 00000051959C: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v2                             // 0000005195A0: 7C940480
	s_cbranch_vccnz 423                                        // 0000005195A4: BFA401A7 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3244>
	v_lshrrev_b32_e32 v2, 7, v0                                // 0000005195A8: 32040087
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000005195AC: 30020282
	v_mov_b32_e32 v5, v0                                       // 0000005195B0: 7E0A0300
	s_lshl_b64 s[6:7], s[26:27], 3                             // 0000005195B4: 8486831A
	s_lshl_b64 s[8:9], s[26:27], 5                             // 0000005195B8: 8488851A
	v_mad_i64_i32 v[2:3], null, v2, s26, 0                     // 0000005195BC: D6FF7C02 02003502
	buffer_gl1_inv                                             // 0000005195C4: E0B00000 00000000
	buffer_gl0_inv                                             // 0000005195CC: E0AC0000 00000000
	.long 0xd73c0002                                           // 0000005195D4: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 0000005195D8: 02020482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005195DC: BF870091
	.long 0xd7006a02                                           // 0000005195E0: D7006A02
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 0000005195E4: 02000902
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 0000005195E8: D5207C03 01AA0605
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005195F0: BF870092
	.long 0xd7006a01                                           // 0000005195F4: D7006A01
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000005195F8: 02020302
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo                // 0000005195FC: D5207C02 01AA0680
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000519604: BF870092
	.long 0xd7006a01                                           // 000000519608: D7006A01
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000051960C: 02020210
	v_add_co_ci_u32_e64 v2, null, s17, v2, vcc_lo              // 000000519610: D5207C02 01AA0411
	s_nop 0                                                    // 000000519618: BF800000
	s_nop 0                                                    // 00000051961C: BF800000
	s_nop 0                                                    // 000000519620: BF800000
	s_nop 0                                                    // 000000519624: BF800000
	s_nop 0                                                    // 000000519628: BF800000
	s_nop 0                                                    // 00000051962C: BF800000
	s_nop 0                                                    // 000000519630: BF800000
	s_nop 0                                                    // 000000519634: BF800000
	s_nop 0                                                    // 000000519638: BF800000
	s_nop 0                                                    // 00000051963C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000519640: BF870191
	v_mov_b32_e32 v4, v2                                       // 000000519644: 7E080302
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v3, v1              // 000000519648: CA100080 06020101
	s_mov_b32 s4, s33                                          // 000000519650: BE840021
	global_load_b32 v7, v[3:4], off glc                        // 000000519654: DC524000 077C0003
	.long 0xd7006a03                                           // 00000051965C: D7006A03
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 000000519660: 02001103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000519664: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000519668: D5207C04 01AA0809
	s_add_i32 s4, s4, -1                                       // 000000519670: 8104C104
	s_cmp_eq_u32 s4, 0                                         // 000000519674: BF068004
	s_waitcnt vmcnt(0)                                         // 000000519678: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 00000051967C: 060C0F06
	s_cbranch_scc0 65524                                       // 000000519680: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2c54>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 000000519684: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v5                         // 00000051968C: 7C920AFF 000002FF
	.long 0xd7000401                                           // 000000519694: D7000401
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000519698: 02000D01
	v_lshlrev_b32_e32 v3, 2, v5                                // 00000051969C: 30060A82
	v_add_co_ci_u32_e64 v2, null, s7, v2, s4                   // 0000005196A0: D5207C02 00120407
	v_mov_b32_e32 v5, v4                                       // 0000005196A8: 7E0A0304
	s_or_b32 s10, vcc_lo, s10                                  // 0000005196AC: 8C0A0A6A
	ds_store_b32 v3, v6 offset:32768                           // 0000005196B0: D8348000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000005196B8: 917E0A7E
	s_cbranch_execnz 65504                                     // 0000005196BC: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2c40>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000005196C0: 8C7E0A7E
	s_and_saveexec_b32 s4, s1                                  // 0000005196C4: BE842001
	s_cbranch_execz 6                                          // 0000005196C8: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2ce4>
	s_lshl_b64 s[6:7], s[2:3], 2                               // 0000005196CC: 84868202
	v_mov_b32_e32 v1, 0                                        // 0000005196D0: 7E020280
	s_add_u32 s6, s18, s6                                      // 0000005196D4: 80060612
	s_addc_u32 s7, s19, s7                                     // 0000005196D8: 82070713
	global_store_b32 v1, v1, s[6:7]                            // 0000005196DC: DC6A0000 00060101
	s_or_b32 exec_lo, exec_lo, s4                              // 0000005196E4: 8C7E047E
	s_mov_b32 s1, -1                                           // 0000005196E8: BE8100C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005196EC: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 0000005196F0: 8B6A017E
	s_cbranch_vccz 339                                         // 0000005196F4: BFA30153 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3244>
	v_cmp_gt_i32_e32 vcc_lo, s24, v66                          // 0000005196F8: 7C888418
	.long 0xd44c0001                                           // 0000005196FC: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000519700: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000519708: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000051970C: BC7C0000
	s_barrier                                                  // 000000519710: BFBD0000
	buffer_gl0_inv                                             // 000000519714: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000051971C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000519720: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000519724: BE832001
	s_cbranch_execz 326                                        // 000000519728: BFA50146 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3244>
	v_and_b32_e32 v1, 15, v0                                   // 00000051972C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000519730: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000519734: 30040282
	v_lshl_or_b32 v2, v66, 9, v2                               // 000000519738: D6560002 04091342
	s_delay_alu instid0(VALU_DEP_1)                            // 000000519740: BF870001
	v_add_nc_u32_e32 v8, 0x8000, v2                            // 000000519744: 4A1004FF 00008000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000051974C: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000519754: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000051975C: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000519764: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 00000051976C: 36140081
	s_waitcnt lgkmcnt(3)                                       // 000000519770: BF89FC37
	v_dual_add_f32 v12, v2, v3 :: v_dual_and_b32 v11, 2, v0    // 000000519774: C9240702 0C0A0082
	s_waitcnt lgkmcnt(2)                                       // 00000051977C: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000519780: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000519788: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000051978C: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000519794: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_sub_f32 v7, v8, v9     // 000000519798: C94A0F06 06061308
	v_dual_add_f32 v8, v8, v9 :: v_dual_and_b32 v9, 4, v0      // 0000005197A0: C9241308 08080084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005197A8: BF8701A3
	v_add_f32_e32 v13, v2, v4                                  // 0000005197AC: 061A0902
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000005197B0: 7C941480
	v_add_f32_e32 v16, v5, v8                                  // 0000005197B4: 06201105
	v_dual_sub_f32 v5, v5, v8 :: v_dual_add_f32 v14, v12, v3   // 0000005197B8: C9481105 050E070C
	v_add_f32_e32 v15, v6, v7                                  // 0000005197C0: 061E0F06
	v_dual_sub_f32 v3, v12, v3 :: v_dual_sub_f32 v2, v2, v4    // 0000005197C4: C94A070C 03020902
	v_sub_f32_e32 v4, v6, v7                                   // 0000005197CC: 08080F06
	.long 0xd44a0001                                           // 0000005197D0: D44A0001
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 0000005197D4: 02021280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005197D8: BF870214
	v_add_f32_e32 v6, v13, v15                                 // 0000005197DC: 060C1F0D
	v_dual_sub_f32 v8, v13, v15 :: v_dual_add_f32 v13, v3, v5  // 0000005197E0: C9481F0D 080C0B03
	v_add_f32_e32 v7, v14, v16                                 // 0000005197E8: 060E210E
	v_dual_sub_f32 v3, v3, v5 :: v_dual_add_f32 v12, v2, v4    // 0000005197EC: C9480B03 030C0902
	v_sub_f32_e32 v2, v2, v4                                   // 0000005197F4: 08040902
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005197F8: 7E0A02FA FF016106
	s_delay_alu instid0(VALU_DEP_4)                            // 000000519800: BF870004
	v_mov_b32_dpp v4, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000519804: 7E0802FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000051980C: D5010007 21AA0F07
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000519814: D5010006 21AA0D06
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000051981C: 7E2402FA FF016103
	v_cndmask_b32_e64 v21, -v3, v3, vcc_lo                     // 000000519824: D5010015 21AA0703
	v_mov_b32_dpp v19, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000051982C: 7E2602FA FF016102
	v_add_f32_e32 v3, v7, v4                                   // 000000519834: 06060907
	v_mov_b32_dpp v15, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000519838: 7E1E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000519840: D5010008 21AA1108
	v_cndmask_b32_e64 v20, -v2, v2, vcc_lo                     // 000000519848: D5010014 21AA0502
	v_add_f32_e32 v2, v6, v5                                   // 000000519850: 06040B06
	v_mov_b32_dpp v6, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000519854: 7E0C02FA FF016203
	v_sub_f32_e32 v10, v14, v16                                // 00000051985C: 0814210E
	v_mov_b32_dpp v16, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000519860: 7E2002FA FF01610D
	v_mov_b32_dpp v17, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000519868: 7E2202FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000519870: D501000C 21AA190C
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000519878: D501000D 21AA1B0D
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000519880: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000519888: D501000A 21AA150A
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 000000519890: 7C941680
	v_add_f32_e32 v4, v8, v15                                  // 000000519894: 06081F08
	v_dual_add_f32 v7, v12, v17 :: v_dual_add_f32 v8, v13, v16 // 000000519898: C908230C 0708210D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005198A0: BF870224
	v_add_f32_e32 v5, v10, v14                                 // 0000005198A4: 060A1D0A
	v_add_f32_e32 v13, v20, v19                                // 0000005198A8: 061A2714
	v_mov_b32_dpp v12, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005198AC: 7E1802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000005198B4: D5010004 21AA0904
	v_mov_b32_dpp v10, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005198BC: 7E1402FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000005198C4: D5010002 21AA0502
	v_mov_b32_dpp v9, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005198CC: 7E1202FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000005198D4: D5010008 21AA1108
	v_add_f32_e32 v4, v4, v12                                  // 0000005198DC: 06081904
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005198E0: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000005198E8: D5010005 21AA0B05
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005198F0: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000005198F8: D501000D 21AA1B0D
	v_mov_b32_dpp v12, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000519900: 7E1802FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000519908: D5010004 20060904
	v_dual_add_f32 v8, v8, v9 :: v_dual_add_f32 v11, v5, v11   // 000000519910: C9081308 080A1705
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000519918: D5010003 21AA0703
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000519920: 7E1C02FA FF016207
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000519928: BF8701C4
	v_add_f32_e32 v4, v4, v12                                  // 00000051992C: 06081904
	v_add_f32_e32 v12, v21, v18                                // 000000519930: 06182515
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000519934: D5010007 21AA0F07
	v_add_f32_e32 v3, v3, v6                                   // 00000051993C: 06060D03
	v_mov_b32_dpp v9, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000519940: 7E1202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000519948: D501000C 21AA190C
	v_add_f32_e32 v2, v2, v10                                  // 000000519950: 06041502
	v_add_f32_e32 v14, v7, v14                                 // 000000519954: 061C1D07
	v_mov_b32_dpp v6, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000519958: 7E0C02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000519960: D5010003 20060703
	v_add_f32_e32 v9, v12, v9                                  // 000000519968: 0612130C
	v_cndmask_b32_e64 v10, -v2, v2, s1                         // 00000051996C: D501000A 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000519974: 7E0402FA FF016402
	v_mov_b32_dpp v12, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000051997C: 7E1802FA FF01640E
	v_add_f32_e32 v3, v3, v6                                   // 000000519984: 06060D03
	v_mov_b32_dpp v16, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000519988: 7E2002FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000519990: D5010009 20061309
	v_add_f32_e32 v5, v10, v2                                  // 000000519998: 060A050A
	v_mov_b32_dpp v10, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000051999C: 7E1402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 0000005199A4: D501000B 2006170B
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005199AC: 7E0402FA FF016803
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005199B4: BF870194
	v_mov_b32_dpp v6, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005199B8: 7E0C02FA FF016805
	v_add_f32_e32 v7, v11, v10                                 // 0000005199C0: 060E150B
	v_add_f32_e32 v11, v13, v15                                // 0000005199C4: 06161F0D
	v_mov_b32_dpp v10, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005199C8: 7E1402FA FF016408
	v_cndmask_b32_e64 v13, -v14, v14, s1                       // 0000005199D0: D501000D 20061D0E
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 0000005199D8: D501000E 20061108
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005199E0: 7E1002FA FF016807
	v_mov_b32_dpp v18, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005199E8: 7E2402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 0000005199F0: D501000B 2006170B
	v_add_f32_e32 v17, v13, v12                                // 0000005199F8: 0622190D
	v_dual_add_f32 v15, v14, v10 :: v_dual_add_f32 v14, v9, v16// 0000005199FC: C908150E 0F0E2109
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000519A04: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000519A0C: BF870214
	v_add_f32_e32 v16, v11, v18                                // 000000519A10: 0620250B
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000519A14: 7E1A02FA FF016811
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000519A1C: BF870224
	v_mov_b32_dpp v11, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000519A20: 7E1602FA FF01680F
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000519A28: 7E1402FA FF01680E
	v_mov_b32_dpp v12, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000519A30: 7E1802FA FF016810
	s_and_b32 exec_lo, exec_lo, s0                             // 000000519A38: 8B7E007E
	s_cbranch_execz 129                                        // 000000519A3C: BFA50081 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi8ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3244>
	v_lshl_or_b32 v18, s2, 7, v1                               // 000000519A40: D6560012 04050E02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000519A48: BF870091
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000519A4C: 3426249F
	.long 0xd73c0014                                           // 000000519A50: D73C0014
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000519A54: 02022481
	.long 0xd73c0012                                           // 000000519A58: D73C0012
	v_cndmask_b32_e32 v1, 2, v18, vcc_lo                       // 000000519A5C: 02022482
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000519A60: BF870092
	.long 0xd7006a14                                           // 000000519A64: D7006A14
	v_cndmask_b32_e32 v1, s14, v20, vcc_lo                     // 000000519A68: 0202280E
	v_add_co_ci_u32_e64 v21, null, s15, v21, vcc_lo            // 000000519A6C: D5207C15 01AA2A0F
	s_clause 0x7                                               // 000000519A74: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000519A78: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000519A80: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:96           // 000000519A88: DC820060 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:64           // 000000519A90: DC820040 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:160          // 000000519A98: DC8200A0 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:128          // 000000519AA0: DC820080 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:224          // 000000519AA8: DC8200E0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:192          // 000000519AB0: DC8200C0 147C0014
	v_and_b32_e32 v21, 8, v0                                   // 000000519AB8: 362A0088
	v_mad_i64_i32 v[0:1], null, s26, v66, 0                    // 000000519ABC: D6FF7C00 0202841A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000519AC4: BF870112
	v_cmp_eq_u32_e32 vcc_lo, 0, v21                            // 000000519AC8: 7C942A80
	.long 0xd73c0000                                           // 000000519ACC: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000519AD0: 02020082
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000519AD4: D5010005 21AA0B05
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000519ADC: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000519AE4: D501000F 21AA1F0F
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000519AEC: D5010004 21AA0904
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000519AF4: D5010007 21AA0F07
	v_add_f32_e32 v5, v5, v6                                   // 000000519AFC: 060A0D05
	v_cndmask_b32_e64 v6, -v17, v17, vcc_lo                    // 000000519B00: D5010006 21AA2311
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 000000519B08: D5010010 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000519B10: D501000E 21AA1D0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000519B18: BF870214
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 000000519B1C: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v13 :: v_dual_add_f32 v6, v15, v11  // 000000519B28: C9081B06 0506170F
	.long 0xd7006a00                                           // 000000519B30: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 000000519B34: 02020014
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v7, v7, v8     // 000000519B38: C9081304 04061107
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 000000519B40: D5207C01 01AA0215
	v_dual_add_f32 v8, v16, v12 :: v_dual_add_f32 v9, v14, v10 // 000000519B48: C9081910 0808150E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000519B50: BF870003
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000519B54: 100808FF 3DB504F3
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000519B5C: 100404FF 3DB504F3
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000519B64: C8C60CFF 06040AFF 3DB504F3
	.long 0xd7006a00                                           // 000000519B70: D7006A00
	v_cndmask_b32_e32 v1, v0, v18, vcc_lo                      // 000000519B74: 02022500
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000519B78: C8C60EFF 070810FF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, v1, v19, vcc_lo              // 000000519B84: D5207C01 01AA2701
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000519B8C: 101212FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 000000519B94: BF891FF7
	v_fma_mix_f32 v3, v22, v3, neg(0) op_sel_hi:[1,0,0]        // 000000519B98: CC200003 8A020716
	s_waitcnt vmcnt(6)                                         // 000000519BA0: BF891BF7
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 000000519BA4: CC200002 8A020517
	s_waitcnt vmcnt(5)                                         // 000000519BAC: BF8917F7
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 000000519BB0: CC200005 8A020B18
	s_waitcnt vmcnt(4)                                         // 000000519BB8: BF8913F7
	v_fma_mix_f32 v6, v25, v6, neg(0) op_sel_hi:[1,0,0]        // 000000519BBC: CC200006 8A020D19
	s_waitcnt vmcnt(3)                                         // 000000519BC4: BF890FF7
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000519BC8: CC200004 8A02091A
	s_waitcnt vmcnt(2)                                         // 000000519BD0: BF890BF7
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 000000519BD4: CC200007 8A020F1B
	s_waitcnt vmcnt(1)                                         // 000000519BDC: BF8907F7
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000519BE0: CC200008 8A02111C
	s_waitcnt vmcnt(0)                                         // 000000519BE8: BF8903F7
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 000000519BEC: CC200009 8A021314
	s_clause 0x7                                               // 000000519BF4: BF850007
	global_store_b32 v[0:1], v2, off                           // 000000519BF8: DC6A0000 007C0200
	global_store_b32 v[0:1], v3, off offset:64                 // 000000519C00: DC6A0040 007C0300
	global_store_b32 v[0:1], v6, off offset:128                // 000000519C08: DC6A0080 007C0600
	global_store_b32 v[0:1], v5, off offset:192                // 000000519C10: DC6A00C0 007C0500
	global_store_b32 v[0:1], v7, off offset:256                // 000000519C18: DC6A0100 007C0700
	global_store_b32 v[0:1], v4, off offset:320                // 000000519C20: DC6A0140 007C0400
	global_store_b32 v[0:1], v9, off offset:384                // 000000519C28: DC6A0180 007C0900
	global_store_b32 v[0:1], v8, off offset:448                // 000000519C30: DC6A01C0 007C0800
	s_nop 0                                                    // 000000519C38: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000519C3C: BFB60003
	s_endpgm                                                   // 000000519C40: BFB00000
	s_nop 0                                                    // 000000519C44: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000519C48: BFB60003
	s_endpgm                                                   // 000000519C4C: BFB00000
		...

