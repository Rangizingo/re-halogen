0000000000b5c900 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt>:
; _ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt():
	s_load_b256 s[8:15], s[0:1], null                          // 000000B5C900: F40C0200 F8000000
	s_mov_b32 s3, 0                                            // 000000B5C908: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000B5C90C: BF870009
	s_lshl_b64 s[4:5], s[2:3], 4                               // 000000B5C910: 84848402
	s_waitcnt lgkmcnt(0)                                       // 000000B5C914: BF89FC07
	s_add_u32 s4, s12, s4                                      // 000000B5C918: 8004040C
	s_addc_u32 s5, s13, s5                                     // 000000B5C91C: 8205050D
	s_load_b128 s[16:19], s[4:5], null                         // 000000B5C920: F4080402 F8000000
	s_load_b64 s[6:7], s[0:1], 0x20                            // 000000B5C928: F4040180 F8000020
	s_waitcnt lgkmcnt(0)                                       // 000000B5C930: BF89FC07
	s_sub_i32 s0, s19, s18                                     // 000000B5C934: 81801213
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000B5C938: BF870499
	s_min_i32 s19, s0, 64                                      // 000000B5C93C: 8913C000
	s_add_i32 s0, s19, 15                                      // 000000B5C940: 81008F13
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000B5C944: BF870009
	s_ashr_i32 s20, s0, 4                                      // 000000B5C948: 86148400
	s_mov_b32 s0, -1                                           // 000000B5C94C: BE8000C1
	s_cmp_lt_i32 s20, 3                                        // 000000B5C950: BF048314
	s_cbranch_scc1 6975                                        // 000000B5C954: BFA21B3F <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6d54>
	v_or_b32_e32 v57, 0x200, v0                                // 000000B5C958: 387200FF 00000200
	.long 0xd44c0000                                           // 000000B5C960: D44C0000
	v_cndmask_b32_e32 v1, 0x300, v0, vcc_lo                    // 000000B5C964: 020200FF 00000300
	s_cmp_gt_i32 s20, 3                                        // 000000B5C96C: BF028314
	s_mov_b32 s1, -1                                           // 000000B5C970: BE8100C1
	s_cbranch_scc0 3795                                        // 000000B5C974: BFA10ED3 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3bc4>
	v_lshrrev_b32_e32 v19, 4, v0                               // 000000B5C978: 32260084
	v_or_b32_e32 v1, 0x100, v0                                 // 000000B5C97C: 380200FF 00000100
	s_add_i32 s1, s19, -1                                      // 000000B5C984: 8101C113
	v_or_b32_e32 v4, 0x300, v0                                 // 000000B5C988: 380800FF 00000300
	v_lshlrev_b32_e32 v2, 3, v0                                // 000000B5C990: 30040083
	v_min_i32_e32 v3, s1, v19                                  // 000000B5C994: 22062601
	v_lshrrev_b32_e32 v9, 4, v1                                // 000000B5C998: 32120284
	v_lshrrev_b32_e32 v1, 4, v57                               // 000000B5C99C: 32027284
	v_lshrrev_b32_e32 v4, 4, v4                                // 000000B5C9A0: 32080884
	v_and_b32_e32 v59, 0x78, v2                                // 000000B5C9A4: 367604FF 00000078
	v_add_nc_u32_e32 v2, s18, v3                               // 000000B5C9AC: 4A040612
	v_min_i32_e32 v3, s1, v9                                   // 000000B5C9B0: 22061201
	v_min_i32_e32 v5, s1, v1                                   // 000000B5C9B4: 220A0201
	v_min_i32_e32 v7, s1, v4                                   // 000000B5C9B8: 220E0801
	v_lshlrev_b32_e32 v10, 1, v59                              // 000000B5C9BC: 30147681
	v_mad_i64_i32 v[1:2], null, 0x500, v2, 0                   // 000000B5C9C0: D6FF7C01 020204FF 00000500
	v_add_nc_u32_e32 v3, s18, v3                               // 000000B5C9CC: 4A060612
	v_add_nc_u32_e32 v5, s18, v5                               // 000000B5C9D0: 4A0A0A12
	v_add_nc_u32_e32 v7, s18, v7                               // 000000B5C9D4: 4A0E0E12
	.long 0xd7000111                                           // 000000B5C9D8: D7000111
	v_cndmask_b32_e32 v1, s10, v10, vcc_lo                     // 000000B5C9DC: 0202140A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5C9E0: BF870214
	v_mad_i64_i32 v[3:4], null, 0x500, v3, 0                   // 000000B5C9E4: D6FF7C03 020206FF 00000500
	v_mad_i64_i32 v[5:6], null, 0x500, v5, 0                   // 000000B5C9F0: D6FF7C05 02020AFF 00000500
	v_add_co_ci_u32_e64 v18, null, s11, 0, s1                  // 000000B5C9FC: D5207C12 0005000B
	v_mad_i64_i32 v[7:8], null, 0x500, v7, 0                   // 000000B5CA04: D6FF7C07 02020EFF 00000500
	.long 0xd7006a0b                                           // 000000B5CA10: D7006A0B
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000B5CA14: 02020311
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5CA18: BF8700A1
	v_add_co_ci_u32_e64 v12, null, v18, v2, vcc_lo             // 000000B5CA1C: D5207C0C 01AA0512
	.long 0xd7006a0d                                           // 000000B5CA24: D7006A0D
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 000000B5CA28: 02020711
	v_add_co_ci_u32_e64 v14, null, v18, v4, vcc_lo             // 000000B5CA2C: D5207C0E 01AA0912
	.long 0xd7006a0f                                           // 000000B5CA34: D7006A0F
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 000000B5CA38: 02020B11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5CA3C: BF8700A1
	v_add_co_ci_u32_e64 v16, null, v18, v6, vcc_lo             // 000000B5CA40: D5207C10 01AA0D12
	.long 0xd7006a11                                           // 000000B5CA48: D7006A11
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 000000B5CA4C: 02020F11
	v_add_co_ci_u32_e64 v18, null, v18, v8, vcc_lo             // 000000B5CA50: D5207C12 01AA1112
	s_clause 0x3                                               // 000000B5CA58: BF850003
	global_load_b128 v[33:36], v[11:12], off                   // 000000B5CA5C: DC5E0000 217C000B
	global_load_b128 v[37:40], v[13:14], off                   // 000000B5CA64: DC5E0000 257C000D
	global_load_b128 v[41:44], v[15:16], off                   // 000000B5CA6C: DC5E0000 297C000F
	global_load_b128 v[45:48], v[17:18], off                   // 000000B5CA74: DC5E0000 2D7C0011
	v_mul_u32_u24_e32 v62, 0x88, v19                           // 000000B5CA7C: 167C26FF 00000088
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B5CA84: BF870001
	v_lshl_add_u32 v11, v62, 1, v10                            // 000000B5CA88: D646000B 0429033E
	s_waitcnt vmcnt(3)                                         // 000000B5CA90: BF890FF7
	ds_store_b128 v11, v[33:36]                                // 000000B5CA94: DB7C0000 0000210B
	s_and_saveexec_b32 s1, s0                                  // 000000B5CA9C: BE812000
	s_cbranch_execnz 11061                                     // 000000B5CAA0: BFA62B35 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xae78>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000B5CAA4: 8C7E017E
	.long 0xd44c0001                                           // 000000B5CAA8: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000B5CAAC: 020200FF 00000200
	s_and_saveexec_b32 s2, s1                                  // 000000B5CAB4: BE822001
	s_cbranch_execnz 11067                                     // 000000B5CAB8: BFA62B3B <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xaea8>
	s_or_b32 exec_lo, exec_lo, s2                              // 000000B5CABC: 8C7E027E
	.long 0xd44c0002                                           // 000000B5CAC0: D44C0002
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000B5CAC4: 020200FF 00000100
	s_and_saveexec_b32 s3, s2                                  // 000000B5CACC: BE832002
	s_cbranch_execz 3                                          // 000000B5CAD0: BFA50003 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1e0>
	s_waitcnt vmcnt(0)                                         // 000000B5CAD4: BF8903F7
	ds_store_b128 v11, v[45:48] offset:13056                   // 000000B5CAD8: DB7C3300 00002D0B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000B5CAE0: 8C7E037E
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v61, 15, v0        // 000000B5CAE4: CA240080 1A3C008F
	v_and_b32_e32 v60, 31, v0                                  // 000000B5CAEC: 3678009F
	v_mul_u32_u24_e32 v63, 0x110, v9                           // 000000B5CAF0: 167E12FF 00000110
	v_lshrrev_b32_e32 v58, 5, v0                               // 000000B5CAF8: 32740085
	s_mul_i32 s5, s16, 0x96000                                 // 000000B5CAFC: 9605FF10 00096000
	v_mov_b32_e32 v11, v26                                     // 000000B5CB04: 7E16031A
	v_lshl_or_b32 v10, v60, 3, 4                               // 000000B5CB08: D656000A 0211073C
	v_mad_u32_u24 v13, v60, 24, 0x2f0                          // 000000B5CB10: D60B000D 03FD313C 000002F0
	v_cmp_ne_u32_e32 vcc_lo, 0, v60                            // 000000B5CB1C: 7C9A7880
	s_mul_i32 s13, s17, 0x7800                                 // 000000B5CB20: 960DFF11 00007800
	s_mul_hi_i32 s4, s16, 0x96000                              // 000000B5CB28: 9704FF10 00096000
	v_mad_u32_u24 v12, v10, 3, 0x2f0                           // 000000B5CB30: D60B000C 03FD070A 000002F0
	v_lshrrev_b32_e32 v15, 5, v13                              // 000000B5CB3C: 321E1A85
	s_add_u32 s5, s5, s13                                      // 000000B5CB40: 80050D05
	s_mul_hi_i32 s21, s17, 0x7800                              // 000000B5CB44: 9715FF11 00007800
	v_mov_b32_e32 v28, v26                                     // 000000B5CB4C: 7E38031A
	v_lshrrev_b32_e32 v14, 5, v12                              // 000000B5CB50: 321C1885
	v_subrev_nc_u32_e32 v17, 24, v15                           // 000000B5CB54: 4E221E98
	v_and_b32_e32 v12, 0x7e0, v12                              // 000000B5CB58: 361818FF 000007E0
	s_addc_u32 s4, s4, s21                                     // 000000B5CB60: 82041504
	v_add_nc_u32_e32 v15, 0xe9, v15                            // 000000B5CB64: 4A1E1EFF 000000E9
	.long 0xd7030009                                           // 000000B5CB6C: D7030009
	v_cndmask_b32_e32 v0, v14, v129, vcc_lo                    // 000000B5CB70: 0201030E
	v_cndmask_b32_e32 v25, 23, v17, vcc_lo                     // 000000B5CB74: 02322297
	v_subrev_nc_u32_e32 v14, 24, v14                           // 000000B5CB78: 4E1C1C98
	v_cmp_lt_u32_e32 vcc_lo, 5, v10                            // 000000B5CB7C: 7C921485
	v_and_b32_e32 v13, 0x7e0, v13                              // 000000B5CB80: 361A1AFF 000007E0
	.long 0xd7624009                                           // 000000B5CB88: D7624009
	v_cndmask_b32_e32 v1, 0xff, v9, vcc_lo                     // 000000B5CB8C: 020212FF 000000FF
	v_mad_i32_i24 v12, v10, -3, v12                            // 000000B5CB94: D60A000C 0431870A
	v_dual_mov_b32 v30, v26 :: v_dual_and_b32 v15, 0xff, v15   // 000000B5CB9C: CA24011A 1E0E1EFF 000000FF
	v_cndmask_b32_e32 v10, 23, v14, vcc_lo                     // 000000B5CBA8: 02141C97
	.long 0xd7006a07                                           // 000000B5CBAC: D7006A07
	v_cndmask_b32_e32 v1, s10, v7, vcc_lo                      // 000000B5CBB0: 02020E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B5CBB4: BF8701A1
	v_add_co_ci_u32_e64 v8, null, s11, v8, vcc_lo              // 000000B5CBB8: D5207C08 01AA100B
	.long 0xd7055009                                           // 000000B5CBC0: D7055009
	v_cndmask_b32_e32 v1, 0xab, v9, vcc_lo                     // 000000B5CBC4: 020212FF 000000AB
	.long 0xd7006a49                                           // 000000B5CBCC: D7006A49
	v_cndmask_b32_e32 v1, 0x100, v7, vcc_lo                    // 000000B5CBD0: 02020EFF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B5CBD8: BF870221
	v_add_co_ci_u32_e64 v74, null, 0, v8, vcc_lo               // 000000B5CBDC: D5207C4A 01AA1080
	.long 0xd7006a05                                           // 000000B5CBE4: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000B5CBE8: 02020A0A
	.long 0xd7395009                                           // 000000B5CBEC: D7395009
	v_cndmask_b32_e32 v1, 12, v9, vcc_lo                       // 000000B5CBF0: 0202128C
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 000000B5CBF4: D5207C06 01AA0C0B
	.long 0xd7006a03                                           // 000000B5CBFC: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 000000B5CC00: 0202060A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000B5CC04: BF8700D1
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 000000B5CC08: D5207C04 01AA080B
	.long 0xd7006a4b                                           // 000000B5CC10: D7006A4B
	v_cndmask_b32_e32 v1, 0x100, v5, vcc_lo                    // 000000B5CC14: 02020AFF 00000100
	.long 0xd7054809                                           // 000000B5CC1C: D7054809
	v_cndmask_b32_e32 v0, v9, v152, vcc_lo                     // 000000B5CC20: 02013109
	v_add_co_ci_u32_e64 v76, null, 0, v6, vcc_lo               // 000000B5CC24: D5207C4C 01AA0C80
	.long 0xd7006a4d                                           // 000000B5CC2C: D7006A4D
	v_cndmask_b32_e32 v1, 0x100, v3, vcc_lo                    // 000000B5CC30: 020206FF 00000100
	v_add_co_ci_u32_e64 v78, null, 0, v4, vcc_lo               // 000000B5CC38: D5207C4E 01AA0880
	.long 0xd7006a03                                           // 000000B5CC40: D7006A03
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 000000B5CC44: 0202020A
	v_mul_u32_u24_e32 v1, 0x60, v58                            // 000000B5CC48: 160274FF 00000060
	.long 0xd7041009                                           // 000000B5CC50: D7041009
	v_cndmask_b32_e32 v1, v9, v9, vcc_lo                       // 000000B5CC54: 02021309
	v_add_co_ci_u32_e64 v4, null, s11, v2, vcc_lo              // 000000B5CC58: D5207C04 01AA040B
	v_mul_hi_u32_u24_e32 v5, 0x60, v58                         // 000000B5CC60: 180A74FF 00000060
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B5CC68: BF8700B4
	v_or_b32_e32 v6, s5, v1                                    // 000000B5CC6C: 380C0205
	.long 0xd73c0001                                           // 000000B5CC70: D73C0001
	v_cndmask_b32_e32 v1, 2, v25, vcc_lo                       // 000000B5CC74: 02023282
	.long 0xd7006a4f                                           // 000000B5CC78: D7006A4F
	v_cndmask_b32_e32 v1, 0x100, v3, vcc_lo                    // 000000B5CC7C: 020206FF 00000100
	v_add_co_ci_u32_e64 v80, null, 0, v4, vcc_lo               // 000000B5CC84: D5207C50 01AA0880
	v_or_b32_e32 v3, s4, v5                                    // 000000B5CC8C: 38060A04
	v_dual_mov_b32 v19, v26 :: v_dual_and_b32 v4, 0xff, v9     // 000000B5CC90: CA24011A 130412FF 000000FF
	.long 0xd7006a01                                           // 000000B5CC9C: D7006A01
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                       // 000000B5CCA0: 02020306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5CCA4: BF870191
	v_add_co_ci_u32_e64 v2, null, v3, v2, vcc_lo               // 000000B5CCA8: D5207C02 01AA0503
	v_dual_mov_b32 v21, v26 :: v_dual_lshlrev_b32 v4, 2, v4    // 000000B5CCB0: CA22011A 15040882
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5CCB8: BF870093
	.long 0xd7006a51                                           // 000000B5CCBC: D7006A51
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000B5CCC0: 02020208
	v_add_co_ci_u32_e64 v82, null, s9, v2, vcc_lo              // 000000B5CCC4: D5207C52 01AA0409
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5CCCC: BF870093
	.long 0xd7006a01                                           // 000000B5CCD0: D7006A01
	v_cndmask_b32_e32 v1, v6, v4, vcc_lo                       // 000000B5CCD4: 02020906
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo                // 000000B5CCD8: D5207C02 01AA0680
	v_dual_mov_b32 v23, v26 :: v_dual_lshlrev_b32 v4, 2, v15   // 000000B5CCE0: CA22011A 17041E82
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5CCE8: BF870093
	.long 0xd7006a53                                           // 000000B5CCEC: D7006A53
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000B5CCF0: 02020208
	v_add_co_ci_u32_e64 v84, null, s9, v2, vcc_lo              // 000000B5CCF4: D5207C54 01AA0409
	.long 0xd73c0001                                           // 000000B5CCFC: D73C0001
	v_cndmask_b32_e32 v1, 2, v10, vcc_lo                       // 000000B5CD00: 02021482
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5CD04: BF870094
	.long 0xd7006a04                                           // 000000B5CD08: D7006A04
	v_cndmask_b32_e32 v1, v6, v4, vcc_lo                       // 000000B5CD0C: 02020906
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 000000B5CD10: D5207C05 01AA0680
	v_mul_u32_u24_e32 v16, 0x88, v61                           // 000000B5CD18: 16207AFF 00000088
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000B5CD20: BF8700C4
	.long 0xd7006a01                                           // 000000B5CD24: D7006A01
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                       // 000000B5CD28: 02020306
	v_mad_i32_i24 v13, 0xffffffe8, v60, v13                    // 000000B5CD2C: D60A000D 043678FF FFFFFFE8
	v_add_co_ci_u32_e64 v2, null, v3, v2, vcc_lo               // 000000B5CD38: D5207C02 01AA0503
	.long 0xd7006a55                                           // 000000B5CD40: D7006A55
	v_cndmask_b32_e32 v1, s8, v4, vcc_lo                       // 000000B5CD44: 02020808
	v_add_co_ci_u32_e64 v86, null, s9, v5, vcc_lo              // 000000B5CD48: D5207C56 01AA0A09
	.long 0xd7006a57                                           // 000000B5CD50: D7006A57
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000B5CD54: 02020208
	.long 0xd44c0003                                           // 000000B5CD58: D44C0003
	v_cndmask_b32_e32 v1, 16, v60, vcc_lo                      // 000000B5CD5C: 02027890
	v_dual_mov_b32 v25, v26 :: v_dual_add_nc_u32 v64, 0xfffffd3d, v13// 000000B5CD60: CA20011A 19401AFF FFFFFD3D
	v_dual_mov_b32 v32, v26 :: v_dual_add_nc_u32 v65, 0xfffffd3a, v13// 000000B5CD6C: CA20011A 20401AFF FFFFFD3A
	v_dual_mov_b32 v27, v26 :: v_dual_add_nc_u32 v66, 0xfffffd37, v13// 000000B5CD78: CA20011A 1B421AFF FFFFFD37
	v_dual_mov_b32 v18, v26 :: v_dual_add_nc_u32 v67, 0xfffffd34, v13// 000000B5CD84: CA20011A 12421AFF FFFFFD34
	v_dual_mov_b32 v29, v26 :: v_dual_add_nc_u32 v68, 0xfffffd3d, v12// 000000B5CD90: CA20011A 1D4418FF FFFFFD3D
	v_dual_mov_b32 v20, v26 :: v_dual_add_nc_u32 v69, 0xfffffd3a, v12// 000000B5CD9C: CA20011A 144418FF FFFFFD3A
	v_dual_mov_b32 v31, v26 :: v_dual_add_nc_u32 v70, 0xfffffd37, v12// 000000B5CDA8: CA20011A 1F4618FF FFFFFD37
	v_dual_mov_b32 v22, v26 :: v_dual_add_nc_u32 v71, 0xfffffd34, v12// 000000B5CDB4: CA20011A 164618FF FFFFFD34
	v_dual_mov_b32 v17, v26 :: v_dual_lshlrev_b32 v72, 4, v61  // 000000B5CDC0: CA22011A 11487A84
	v_add_co_ci_u32_e64 v88, null, s9, v2, vcc_lo              // 000000B5CDC8: D5207C58 01AA0409
	v_dual_mov_b32 v24, v26 :: v_dual_lshlrev_b32 v89, 1, v16  // 000000B5CDD0: CA22011A 18582081
	v_mov_b32_e32 v9, v26                                      // 000000B5CDD8: 7E12031A
	v_mov_b32_e32 v10, v26                                     // 000000B5CDDC: 7E14031A
	v_mov_b32_e32 v12, v26                                     // 000000B5CDE0: 7E18031A
	v_mov_b32_e32 v13, v26                                     // 000000B5CDE4: 7E1A031A
	v_mov_b32_e32 v14, v26                                     // 000000B5CDE8: 7E1C031A
	v_mov_b32_e32 v15, v26                                     // 000000B5CDEC: 7E1E031A
	v_mov_b32_e32 v16, v26                                     // 000000B5CDF0: 7E20031A
	v_mov_b32_e32 v1, v26                                      // 000000B5CDF4: 7E02031A
	v_mov_b32_e32 v2, v26                                      // 000000B5CDF8: 7E04031A
	v_mov_b32_e32 v3, v26                                      // 000000B5CDFC: 7E06031A
	v_mov_b32_e32 v4, v26                                      // 000000B5CE00: 7E08031A
	v_mov_b32_e32 v5, v26                                      // 000000B5CE04: 7E0A031A
	v_mov_b32_e32 v6, v26                                      // 000000B5CE08: 7E0C031A
	v_mov_b32_e32 v7, v26                                      // 000000B5CE0C: 7E0E031A
	v_mov_b32_e32 v8, v26                                      // 000000B5CE10: 7E10031A
	s_mov_b32 s12, 0                                           // 000000B5CE14: BE8C0080
	s_mov_b64 s[4:5], 0                                        // 000000B5CE18: BE840180
	s_movk_i32 s13, 0x1eee                                     // 000000B5CE1C: B00D1EEE
	s_mov_b32 s21, 0x76543210                                  // 000000B5CE20: BE9500FF 76543210
	s_movk_i32 s22, 0x4460                                     // 000000B5CE28: B0164460
	s_movk_i32 s23, 0x80                                       // 000000B5CE2C: B0170080
	s_movk_i32 s24, 0xa0                                       // 000000B5CE30: B01800A0
	s_movk_i32 s25, 0xc0                                       // 000000B5CE34: B01900C0
	s_movk_i32 s26, 0xe0                                       // 000000B5CE38: B01A00E0
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000B5CE3C: BF890007
	s_barrier                                                  // 000000B5CE40: BFBD0000
	buffer_gl0_inv                                             // 000000B5CE44: E0AC0000 00000000
	s_branch 33                                                // 000000B5CE4C: BFA00021 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5d4>
	s_or_b32 exec_lo, exec_lo, s27                             // 000000B5CE50: 8C7E1B7E
	.long 0xd7006a49                                           // 000000B5CE54: D7006A49
	v_cndmask_b32_e32 v1, 0x100, v73, vcc_lo                   // 000000B5CE58: 020292FF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5CE60: BF8700A1
	v_add_co_ci_u32_e64 v74, null, 0, v74, vcc_lo              // 000000B5CE64: D5207C4A 01AA9480
	.long 0xd7006a4b                                           // 000000B5CE6C: D7006A4B
	v_cndmask_b32_e32 v1, 0x100, v75, vcc_lo                   // 000000B5CE70: 020296FF 00000100
	v_add_co_ci_u32_e64 v76, null, 0, v76, vcc_lo              // 000000B5CE78: D5207C4C 01AA9880
	.long 0xd7006a4d                                           // 000000B5CE80: D7006A4D
	v_cndmask_b32_e32 v1, 0x100, v77, vcc_lo                   // 000000B5CE84: 02029AFF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5CE8C: BF8700A1
	v_add_co_ci_u32_e64 v78, null, 0, v78, vcc_lo              // 000000B5CE90: D5207C4E 01AA9C80
	.long 0xd7006a4f                                           // 000000B5CE98: D7006A4F
	v_cndmask_b32_e32 v1, 0x100, v79, vcc_lo                   // 000000B5CE9C: 02029EFF 00000100
	v_add_co_ci_u32_e64 v80, null, 0, v80, vcc_lo              // 000000B5CEA4: D5207C50 01AAA080
	s_add_u32 s4, s4, 0x1800                                   // 000000B5CEAC: 8004FF04 00001800
	s_addc_u32 s5, s5, 0                                       // 000000B5CEB4: 82058005
	s_add_i32 s12, s12, 1                                      // 000000B5CEB8: 810C810C
	s_cmpk_eq_i32 s4, 0x7800                                   // 000000B5CEBC: B1847800
	s_waitcnt lgkmcnt(0)                                       // 000000B5CEC0: BF89FC07
	s_barrier                                                  // 000000B5CEC4: BFBD0000
	buffer_gl0_inv                                             // 000000B5CEC8: E0AC0000 00000000
	s_cbranch_scc1 1679                                        // 000000B5CED0: BFA2068F <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x2010>
	s_cmpk_lg_i32 s4, 0x6000                                   // 000000B5CED4: B2046000
	s_cselect_b32 s27, -1, 0                                   // 000000B5CED8: 981B80C1
	s_cmpk_eq_i32 s4, 0x6000                                   // 000000B5CEDC: B1846000
	s_cbranch_scc1 26                                          // 000000B5CEE0: BFA2001A <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x64c>
	.long 0xd7006a21                                           // 000000B5CEE4: D7006A21
	v_cndmask_b32_e32 v1, v79, v72, vcc_lo                     // 000000B5CEE8: 0202914F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5CEEC: BF8700A1
	v_add_co_ci_u32_e64 v34, null, 0, v80, vcc_lo              // 000000B5CEF0: D5207C22 01AAA080
	.long 0xd7006a25                                           // 000000B5CEF8: D7006A25
	v_cndmask_b32_e32 v1, v77, v72, vcc_lo                     // 000000B5CEFC: 0202914D
	v_add_co_ci_u32_e64 v38, null, 0, v78, vcc_lo              // 000000B5CF00: D5207C26 01AA9C80
	.long 0xd7006a29                                           // 000000B5CF08: D7006A29
	v_cndmask_b32_e32 v1, v75, v72, vcc_lo                     // 000000B5CF0C: 0202914B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5CF10: BF8700A1
	v_add_co_ci_u32_e64 v42, null, 0, v76, vcc_lo              // 000000B5CF14: D5207C2A 01AA9880
	.long 0xd7006a2d                                           // 000000B5CF1C: D7006A2D
	v_cndmask_b32_e32 v1, v73, v72, vcc_lo                     // 000000B5CF20: 02029149
	v_add_co_ci_u32_e64 v46, null, 0, v74, vcc_lo              // 000000B5CF24: D5207C2E 01AA9480
	global_load_b128 v[33:36], v[33:34], off                   // 000000B5CF2C: DC5E0000 217C0021
	global_load_b128 v[37:40], v[37:38], off                   // 000000B5CF34: DC5E0000 257C0025
	global_load_b128 v[41:44], v[41:42], off                   // 000000B5CF3C: DC5E0000 297C0029
	global_load_b128 v[45:48], v[45:46], off                   // 000000B5CF44: DC5E0000 2D7C002D
	.long 0xd7006a35                                           // 000000B5CF4C: D7006A35
	v_cndmask_b32_e32 v0, v81, v4, vcc_lo                      // 000000B5CF50: 02000951
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5CF54: BF8700A1
	v_add_co_ci_u32_e64 v54, null, s5, v82, vcc_lo             // 000000B5CF58: D5207C36 01AAA405
	.long 0xd7006a37                                           // 000000B5CF60: D7006A37
	v_cndmask_b32_e32 v0, v85, v4, vcc_lo                      // 000000B5CF64: 02000955
	v_add_co_ci_u32_e64 v56, null, s5, v86, vcc_lo             // 000000B5CF68: D5207C38 01AAAC05
	global_load_b32 v50, v[53:54], off                         // 000000B5CF70: DC520000 327C0035
	s_bfe_i32 s29, s12, 0x10000                                // 000000B5CF78: 939DFF0C 00010000
	s_and_b32 s28, s12, 1                                      // 000000B5CF80: 8B1C810C
	global_load_b32 v49, v[55:56], off                         // 000000B5CF84: DC520000 317C0037
	s_and_b32 s29, s29, 0x4400                                 // 000000B5CF8C: 8B1DFF1D 00004400
	s_cmp_eq_u32 s28, 0                                        // 000000B5CF94: BF06801C
	v_add_nc_u32_e32 v106, s29, v89                            // 000000B5CF98: 4AD4B21D
	s_cselect_b32 s28, -1, 0                                   // 000000B5CF9C: 981C80C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000B5CFA0: BF8700C9
	s_and_b32 s29, s28, exec_lo                                // 000000B5CFA4: 8B1D7E1C
	s_cselect_b32 s29, 32, 0x4420                              // 000000B5CFA8: 981DFFA0 00004420
	s_waitcnt vmcnt(0)                                         // 000000B5CFB0: BF8903F7
	.long 0xd73d0033                                           // 000000B5CFB4: D73D0033
	v_cndmask_b32_e32 v1, v64, v49, vcc_lo                     // 000000B5CFB8: 02026340
	v_and_b32_e32 v94, 0xffff, v51                             // 000000B5CFBC: 36BC66FF 0000FFFF
	.long 0xd73d0033                                           // 000000B5CFC4: D73D0033
	v_cndmask_b32_e32 v1, v65, v49, vcc_lo                     // 000000B5CFC8: 02026341
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000B5CFCC: BF870131
	v_and_b32_e32 v95, 0xffff, v51                             // 000000B5CFD0: 36BE66FF 0000FFFF
	.long 0xd73d0033                                           // 000000B5CFD8: D73D0033
	v_cndmask_b32_e32 v1, v66, v49, vcc_lo                     // 000000B5CFDC: 02026342
	.long 0xd73d0031                                           // 000000B5CFE0: D73D0031
	v_cndmask_b32_e32 v1, v67, v49, vcc_lo                     // 000000B5CFE4: 02026343
	v_and_b32_e32 v96, 0xffff, v51                             // 000000B5CFE8: 36C066FF 0000FFFF
	.long 0xd7006a33                                           // 000000B5CFF0: D7006A33
	v_cndmask_b32_e32 v0, v87, v4, vcc_lo                      // 000000B5CFF4: 02000957
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B5CFF8: BF8700B3
	v_and_b32_e32 v97, 0xffff, v49                             // 000000B5CFFC: 36C262FF 0000FFFF
	v_add_co_ci_u32_e64 v52, null, s5, v88, vcc_lo             // 000000B5D004: D5207C34 01AAB005
	.long 0xd7006a31                                           // 000000B5D00C: D7006A31
	v_cndmask_b32_e32 v0, v83, v4, vcc_lo                      // 000000B5D010: 02000953
	v_add_co_ci_u32_e64 v50, null, s5, v84, vcc_lo             // 000000B5D014: D5207C32 01AAA805
	s_clause 0x1                                               // 000000B5D01C: BF850001
	global_load_b32 v91, v[51:52], off                         // 000000B5D020: DC520000 5B7C0033
	global_load_b32 v90, v[49:50], off                         // 000000B5D028: DC520000 5A7C0031
	s_waitcnt vmcnt(0)                                         // 000000B5D030: BF8903F7
	.long 0xd73d005c                                           // 000000B5D034: D73D005C
	v_cndmask_b32_e32 v1, v68, v90, vcc_lo                     // 000000B5D038: 0202B544
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5D03C: BF8700A1
	v_and_b32_e32 v98, 0xffff, v92                             // 000000B5D040: 36C4B8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5D048: D73D005C
	v_cndmask_b32_e32 v1, v69, v90, vcc_lo                     // 000000B5D04C: 0202B545
	v_and_b32_e32 v99, 0xffff, v92                             // 000000B5D050: 36C6B8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5D058: D73D005C
	v_cndmask_b32_e32 v1, v70, v90, vcc_lo                     // 000000B5D05C: 0202B546
	.long 0xd73d005a                                           // 000000B5D060: D73D005A
	v_cndmask_b32_e32 v1, v71, v90, vcc_lo                     // 000000B5D064: 0202B547
	.long 0xd72c005b                                           // 000000B5D068: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000B5D06C: 0202BCFF 83DCD12D
	.long 0xd72c005d                                           // 000000B5D074: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000B5D078: 0202BEFF 83DCD12D
	.long 0xd72c005e                                           // 000000B5D080: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000B5D084: 0202C2FF 83DCD12D
	.long 0xd72c005f                                           // 000000B5D08C: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000B5D090: 0202C6FF 83DCD12D
	v_and_b32_e32 v92, 0xffff, v92                             // 000000B5D098: 36B8B8FF 0000FFFF
	v_and_b32_e32 v90, 0xffff, v90                             // 000000B5D0A0: 36B4B4FF 0000FFFF
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000B5D0A8: D622005B 03FD015B 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5D0B4: BF870193
	.long 0xd72c005c                                           // 000000B5D0B8: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000B5D0BC: 0202B8FF 83DCD12D
	.long 0xd72c005a                                           // 000000B5D0C4: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000B5D0C8: 0202B4FF 83DCD12D
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000B5D0D0: D622005D 03FD015D 00006400
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000B5D0DC: D622005E 03FD015E 00006400
	v_and_b32_e32 v91, 0xffff, v91                             // 000000B5D0E8: 36B6B6FF 0000FFFF
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000B5D0F0: D622005F 03FD015F 00006400
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000B5D0FC: D622005C 03FD015C 00006400
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000B5D108: D622005A 03FD015A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5D114: BF870194
	v_lshl_or_b32 v91, v93, 16, v91                            // 000000B5D118: D656005B 056D215D
	v_and_b32_e32 v92, 0xffff, v92                             // 000000B5D120: 36B8B8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5D128: BF870112
	v_pk_fma_f16 v91, v91, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5D12C: CC0E005B 0BFC1B5B 0000C931
	v_lshl_or_b32 v90, v90, 16, v92                            // 000000B5D138: D656005A 0571215A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5D140: BF870112
	v_mov_b32_e32 v92, v91                                     // 000000B5D144: 7EB8035B
	v_pk_fma_f16 v97, v90, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5D148: CC0E0061 0BFC1B5A 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5D154: BF870112
	v_permlanex16_b32 v92, v92, s21, 0xfedcba98                // 000000B5D158: D65C005C 03FC2B5C FEDCBA98
	v_mov_b32_e32 v99, v97                                     // 000000B5D164: 7EC60361
	.long 0xd72c005d                                           // 000000B5D168: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000B5D16C: 0202C0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5D174: BF870193
	v_cndmask_b32_e64 v90, v92, v91, s3                        // 000000B5D178: D501005A 000EB75C
	v_permlanex16_b32 v99, v99, s21, 0xfedcba98                // 000000B5D180: D65C0063 03FC2B63 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5D18C: BF870093
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000B5D190: D622005D 03FD015D 00006400
	v_and_b32_e32 v93, 0xffff, v93                             // 000000B5D19C: 36BABAFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B5D1A4: BF870121
	v_lshl_or_b32 v93, v94, 16, v93                            // 000000B5D1A8: D656005D 0575215E
	.long 0xd72c005e                                           // 000000B5D1B0: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000B5D1B4: 0202C4FF 83DCD12D
	v_pk_fma_f16 v93, v93, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5D1BC: CC0E005D 0BFC1B5D 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5D1C8: BF870092
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000B5D1CC: D622005E 03FD015E 00006400
	v_and_b32_e32 v94, 0xffff, v94                             // 000000B5D1D8: 36BCBCFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5D1E0: BF870211
	v_lshl_or_b32 v94, v95, 16, v94                            // 000000B5D1E4: D656005E 0579215F
	v_mov_b32_e32 v95, v93                                     // 000000B5D1EC: 7EBE035D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5D1F0: BF870112
	v_pk_fma_f16 v96, v94, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5D1F4: CC0E0060 0BFC1B5E 0000C931
	v_permlanex16_b32 v95, v95, s21, 0xfedcba98                // 000000B5D200: D65C005F 03FC2B5F FEDCBA98
	v_cndmask_b32_e64 v94, v91, v92, s3                        // 000000B5D20C: D501005E 000EB95B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5D214: BF870193
	v_mov_b32_e32 v98, v96                                     // 000000B5D218: 7EC40360
	v_cndmask_b32_e64 v91, v95, v93, s3                        // 000000B5D21C: D501005B 000EBB5F
	v_cndmask_b32_e64 v95, v93, v95, s3                        // 000000B5D224: D501005F 000EBF5D
	v_cndmask_b32_e64 v93, v99, v97, s3                        // 000000B5D22C: D501005D 000EC363
	v_cndmask_b32_e64 v97, v97, v99, s3                        // 000000B5D234: D5010061 000EC761
	v_permlanex16_b32 v98, v98, s21, 0xfedcba98                // 000000B5D23C: D65C0062 03FC2B62 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B5D248: BF870001
	v_cndmask_b32_e64 v92, v98, v96, s3                        // 000000B5D24C: D501005C 000EC162
	v_cndmask_b32_e64 v96, v96, v98, s3                        // 000000B5D254: D5010060 000EC560
	ds_load_b128 v[98:101], v106                               // 000000B5D25C: DBFC0000 6200006A
	ds_load_b128 v[102:105], v106 offset:16                    // 000000B5D264: DBFC0010 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5D26C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[90:97], v[98:105], v[25:32]// 000000B5D270: CC404019 1C66C55A
	ds_load_b128 v[98:101], v106 offset:4352                   // 000000B5D278: DBFC1100 6200006A
	ds_load_b128 v[102:105], v106 offset:4368                  // 000000B5D280: DBFC1110 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5D288: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[90:97], v[98:105], v[17:24]// 000000B5D28C: CC404011 1C46C55A
	ds_load_b128 v[98:101], v106 offset:8704                   // 000000B5D294: DBFC2200 6200006A
	ds_load_b128 v[102:105], v106 offset:8720                  // 000000B5D29C: DBFC2210 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5D2A4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[90:97], v[98:105], v[9:16]// 000000B5D2A8: CC404009 1C26C55A
	ds_load_b128 v[98:101], v106 offset:13056                  // 000000B5D2B0: DBFC3300 6200006A
	ds_load_b128 v[102:105], v106 offset:13072                 // 000000B5D2B8: DBFC3310 6600006A
	v_add_nc_u32_e32 v106, s29, v89                            // 000000B5D2C0: 4AD4B21D
	s_cselect_b32 s29, 64, 0x4440                              // 000000B5D2C4: 981DFFC0 00004440
	s_waitcnt lgkmcnt(0)                                       // 000000B5D2CC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[90:97], v[98:105], v[1:8]// 000000B5D2D0: CC404001 1C06C55A
	s_clause 0x1                                               // 000000B5D2D8: BF850001
	global_load_b32 v91, v[53:54], off offset:768              // 000000B5D2DC: DC520300 5B7C0035
	global_load_b32 v90, v[55:56], off offset:768              // 000000B5D2E4: DC520300 5A7C0037
	s_waitcnt vmcnt(0)                                         // 000000B5D2EC: BF8903F7
	.long 0xd73d005c                                           // 000000B5D2F0: D73D005C
	v_cndmask_b32_e32 v1, v64, v90, vcc_lo                     // 000000B5D2F4: 0202B540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5D2F8: BF8700A1
	v_and_b32_e32 v94, 0xffff, v92                             // 000000B5D2FC: 36BCB8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5D304: D73D005C
	v_cndmask_b32_e32 v1, v65, v90, vcc_lo                     // 000000B5D308: 0202B541
	v_and_b32_e32 v95, 0xffff, v92                             // 000000B5D30C: 36BEB8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5D314: D73D005C
	v_cndmask_b32_e32 v1, v66, v90, vcc_lo                     // 000000B5D318: 0202B542
	.long 0xd73d005a                                           // 000000B5D31C: D73D005A
	v_cndmask_b32_e32 v1, v67, v90, vcc_lo                     // 000000B5D320: 0202B543
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5D324: BF870112
	v_and_b32_e32 v96, 0xffff, v92                             // 000000B5D328: 36C0B8FF 0000FFFF
	v_and_b32_e32 v97, 0xffff, v90                             // 000000B5D330: 36C2B4FF 0000FFFF
	s_clause 0x1                                               // 000000B5D338: BF850001
	global_load_b32 v91, v[51:52], off offset:768              // 000000B5D33C: DC520300 5B7C0033
	global_load_b32 v90, v[49:50], off offset:768              // 000000B5D344: DC520300 5A7C0031
	s_waitcnt vmcnt(0)                                         // 000000B5D34C: BF8903F7
	.long 0xd73d005c                                           // 000000B5D350: D73D005C
	v_cndmask_b32_e32 v1, v68, v90, vcc_lo                     // 000000B5D354: 0202B544
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5D358: BF8700A1
	v_and_b32_e32 v98, 0xffff, v92                             // 000000B5D35C: 36C4B8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5D364: D73D005C
	v_cndmask_b32_e32 v1, v69, v90, vcc_lo                     // 000000B5D368: 0202B545
	v_and_b32_e32 v99, 0xffff, v92                             // 000000B5D36C: 36C6B8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5D374: D73D005C
	v_cndmask_b32_e32 v1, v70, v90, vcc_lo                     // 000000B5D378: 0202B546
	.long 0xd73d005a                                           // 000000B5D37C: D73D005A
	v_cndmask_b32_e32 v1, v71, v90, vcc_lo                     // 000000B5D380: 0202B547
	.long 0xd72c005b                                           // 000000B5D384: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000B5D388: 0202BCFF 83DCD12D
	.long 0xd72c005d                                           // 000000B5D390: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000B5D394: 0202BEFF 83DCD12D
	.long 0xd72c005e                                           // 000000B5D39C: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000B5D3A0: 0202C2FF 83DCD12D
	.long 0xd72c005f                                           // 000000B5D3A8: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000B5D3AC: 0202C6FF 83DCD12D
	v_and_b32_e32 v92, 0xffff, v92                             // 000000B5D3B4: 36B8B8FF 0000FFFF
	v_and_b32_e32 v90, 0xffff, v90                             // 000000B5D3BC: 36B4B4FF 0000FFFF
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000B5D3C4: D622005B 03FD015B 00006400
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000B5D3D0: D622005D 03FD015D 00006400
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000B5D3DC: D622005E 03FD015E 00006400
	.long 0xd72c005c                                           // 000000B5D3E8: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000B5D3EC: 0202B8FF 83DCD12D
	.long 0xd72c005a                                           // 000000B5D3F4: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000B5D3F8: 0202B4FF 83DCD12D
	v_and_b32_e32 v91, 0xffff, v91                             // 000000B5D400: 36B6B6FF 0000FFFF
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000B5D408: D622005F 03FD015F 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B5D414: BF870242
	v_lshl_or_b32 v91, v93, 16, v91                            // 000000B5D418: D656005B 056D215D
	.long 0xd72c005d                                           // 000000B5D420: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000B5D424: 0202C0FF 83DCD12D
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000B5D42C: D622005C 03FD015C 00006400
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000B5D438: D622005A 03FD015A 00006400
	v_pk_fma_f16 v91, v91, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5D444: CC0E005B 0BFC1B5B 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B5D450: BF870123
	v_and_b32_e32 v92, 0xffff, v92                             // 000000B5D454: 36B8B8FF 0000FFFF
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000B5D45C: D622005D 03FD015D 00006400
	v_lshl_or_b32 v90, v90, 16, v92                            // 000000B5D468: D656005A 0571215A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5D470: BF870112
	v_dual_mov_b32 v92, v91 :: v_dual_and_b32 v93, 0xffff, v93 // 000000B5D474: CA24015B 5C5CBAFF 0000FFFF
	v_pk_fma_f16 v97, v90, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5D480: CC0E0061 0BFC1B5A 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5D48C: BF870192
	v_permlanex16_b32 v92, v92, s21, 0xfedcba98                // 000000B5D490: D65C005C 03FC2B5C FEDCBA98
	v_lshl_or_b32 v93, v94, 16, v93                            // 000000B5D49C: D656005D 0575215E
	.long 0xd72c005e                                           // 000000B5D4A4: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000B5D4A8: 0202C4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5D4B0: BF870214
	v_mov_b32_e32 v99, v97                                     // 000000B5D4B4: 7EC60361
	v_cndmask_b32_e64 v90, v92, v91, s3                        // 000000B5D4B8: D501005A 000EB75C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5D4C0: BF870194
	v_pk_fma_f16 v93, v93, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5D4C4: CC0E005D 0BFC1B5D 0000C931
	v_permlanex16_b32 v99, v99, s21, 0xfedcba98                // 000000B5D4D0: D65C0063 03FC2B63 FEDCBA98
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000B5D4DC: D622005E 03FD015E 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5D4E8: BF870091
	v_and_b32_e32 v94, 0xffff, v94                             // 000000B5D4EC: 36BCBCFF 0000FFFF
	v_lshl_or_b32 v94, v95, 16, v94                            // 000000B5D4F4: D656005E 0579215F
	v_mov_b32_e32 v95, v93                                     // 000000B5D4FC: 7EBE035D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5D500: BF870112
	v_pk_fma_f16 v96, v94, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5D504: CC0E0060 0BFC1B5E 0000C931
	v_permlanex16_b32 v95, v95, s21, 0xfedcba98                // 000000B5D510: D65C005F 03FC2B5F FEDCBA98
	v_cndmask_b32_e64 v94, v91, v92, s3                        // 000000B5D51C: D501005E 000EB95B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5D524: BF870193
	v_mov_b32_e32 v98, v96                                     // 000000B5D528: 7EC40360
	v_cndmask_b32_e64 v91, v95, v93, s3                        // 000000B5D52C: D501005B 000EBB5F
	v_cndmask_b32_e64 v95, v93, v95, s3                        // 000000B5D534: D501005F 000EBF5D
	v_cndmask_b32_e64 v93, v99, v97, s3                        // 000000B5D53C: D501005D 000EC363
	v_cndmask_b32_e64 v97, v97, v99, s3                        // 000000B5D544: D5010061 000EC761
	v_permlanex16_b32 v98, v98, s21, 0xfedcba98                // 000000B5D54C: D65C0062 03FC2B62 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B5D558: BF870001
	v_cndmask_b32_e64 v92, v98, v96, s3                        // 000000B5D55C: D501005C 000EC162
	v_cndmask_b32_e64 v96, v96, v98, s3                        // 000000B5D564: D5010060 000EC560
	ds_load_b128 v[98:101], v106                               // 000000B5D56C: DBFC0000 6200006A
	ds_load_b128 v[102:105], v106 offset:16                    // 000000B5D574: DBFC0010 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5D57C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[90:97], v[98:105], v[25:32]// 000000B5D580: CC404019 1C66C55A
	ds_load_b128 v[98:101], v106 offset:4352                   // 000000B5D588: DBFC1100 6200006A
	ds_load_b128 v[102:105], v106 offset:4368                  // 000000B5D590: DBFC1110 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5D598: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[90:97], v[98:105], v[17:24]// 000000B5D59C: CC404011 1C46C55A
	ds_load_b128 v[98:101], v106 offset:8704                   // 000000B5D5A4: DBFC2200 6200006A
	ds_load_b128 v[102:105], v106 offset:8720                  // 000000B5D5AC: DBFC2210 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5D5B4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[90:97], v[98:105], v[9:16]// 000000B5D5B8: CC404009 1C26C55A
	ds_load_b128 v[98:101], v106 offset:13056                  // 000000B5D5C0: DBFC3300 6200006A
	ds_load_b128 v[102:105], v106 offset:13072                 // 000000B5D5C8: DBFC3310 6600006A
	v_add_nc_u32_e32 v106, s29, v89                            // 000000B5D5D0: 4AD4B21D
	s_cselect_b32 s29, 0x60, s22                               // 000000B5D5D4: 981D16FF 00000060
	s_waitcnt lgkmcnt(0)                                       // 000000B5D5DC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[90:97], v[98:105], v[1:8]// 000000B5D5E0: CC404001 1C06C55A
	s_clause 0x1                                               // 000000B5D5E8: BF850001
	global_load_b32 v91, v[53:54], off offset:1536             // 000000B5D5EC: DC520600 5B7C0035
	global_load_b32 v90, v[55:56], off offset:1536             // 000000B5D5F4: DC520600 5A7C0037
	s_waitcnt vmcnt(0)                                         // 000000B5D5FC: BF8903F7
	.long 0xd73d005c                                           // 000000B5D600: D73D005C
	v_cndmask_b32_e32 v1, v64, v90, vcc_lo                     // 000000B5D604: 0202B540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5D608: BF8700A1
	v_and_b32_e32 v94, 0xffff, v92                             // 000000B5D60C: 36BCB8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5D614: D73D005C
	v_cndmask_b32_e32 v1, v65, v90, vcc_lo                     // 000000B5D618: 0202B541
	v_and_b32_e32 v95, 0xffff, v92                             // 000000B5D61C: 36BEB8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5D624: D73D005C
	v_cndmask_b32_e32 v1, v66, v90, vcc_lo                     // 000000B5D628: 0202B542
	.long 0xd73d005a                                           // 000000B5D62C: D73D005A
	v_cndmask_b32_e32 v1, v67, v90, vcc_lo                     // 000000B5D630: 0202B543
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5D634: BF870112
	v_and_b32_e32 v96, 0xffff, v92                             // 000000B5D638: 36C0B8FF 0000FFFF
	v_and_b32_e32 v97, 0xffff, v90                             // 000000B5D640: 36C2B4FF 0000FFFF
	s_clause 0x1                                               // 000000B5D648: BF850001
	global_load_b32 v91, v[51:52], off offset:1536             // 000000B5D64C: DC520600 5B7C0033
	global_load_b32 v90, v[49:50], off offset:1536             // 000000B5D654: DC520600 5A7C0031
	s_waitcnt vmcnt(0)                                         // 000000B5D65C: BF8903F7
	.long 0xd73d005c                                           // 000000B5D660: D73D005C
	v_cndmask_b32_e32 v1, v68, v90, vcc_lo                     // 000000B5D664: 0202B544
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5D668: BF8700A1
	v_and_b32_e32 v98, 0xffff, v92                             // 000000B5D66C: 36C4B8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5D674: D73D005C
	v_cndmask_b32_e32 v1, v69, v90, vcc_lo                     // 000000B5D678: 0202B545
	v_and_b32_e32 v99, 0xffff, v92                             // 000000B5D67C: 36C6B8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5D684: D73D005C
	v_cndmask_b32_e32 v1, v70, v90, vcc_lo                     // 000000B5D688: 0202B546
	.long 0xd73d005a                                           // 000000B5D68C: D73D005A
	v_cndmask_b32_e32 v1, v71, v90, vcc_lo                     // 000000B5D690: 0202B547
	.long 0xd72c005b                                           // 000000B5D694: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000B5D698: 0202BCFF 83DCD12D
	.long 0xd72c005d                                           // 000000B5D6A0: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000B5D6A4: 0202BEFF 83DCD12D
	.long 0xd72c005e                                           // 000000B5D6AC: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000B5D6B0: 0202C2FF 83DCD12D
	.long 0xd72c005f                                           // 000000B5D6B8: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000B5D6BC: 0202C6FF 83DCD12D
	v_and_b32_e32 v92, 0xffff, v92                             // 000000B5D6C4: 36B8B8FF 0000FFFF
	v_and_b32_e32 v90, 0xffff, v90                             // 000000B5D6CC: 36B4B4FF 0000FFFF
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000B5D6D4: D622005B 03FD015B 00006400
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000B5D6E0: D622005D 03FD015D 00006400
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000B5D6EC: D622005E 03FD015E 00006400
	.long 0xd72c005c                                           // 000000B5D6F8: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000B5D6FC: 0202B8FF 83DCD12D
	.long 0xd72c005a                                           // 000000B5D704: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000B5D708: 0202B4FF 83DCD12D
	v_and_b32_e32 v91, 0xffff, v91                             // 000000B5D710: 36B6B6FF 0000FFFF
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000B5D718: D622005F 03FD015F 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B5D724: BF870242
	v_lshl_or_b32 v91, v93, 16, v91                            // 000000B5D728: D656005B 056D215D
	.long 0xd72c005d                                           // 000000B5D730: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000B5D734: 0202C0FF 83DCD12D
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000B5D73C: D622005C 03FD015C 00006400
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000B5D748: D622005A 03FD015A 00006400
	v_pk_fma_f16 v91, v91, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5D754: CC0E005B 0BFC1B5B 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B5D760: BF870123
	v_and_b32_e32 v92, 0xffff, v92                             // 000000B5D764: 36B8B8FF 0000FFFF
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000B5D76C: D622005D 03FD015D 00006400
	v_lshl_or_b32 v90, v90, 16, v92                            // 000000B5D778: D656005A 0571215A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5D780: BF870112
	v_dual_mov_b32 v92, v91 :: v_dual_and_b32 v93, 0xffff, v93 // 000000B5D784: CA24015B 5C5CBAFF 0000FFFF
	v_pk_fma_f16 v97, v90, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5D790: CC0E0061 0BFC1B5A 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5D79C: BF870192
	v_permlanex16_b32 v92, v92, s21, 0xfedcba98                // 000000B5D7A0: D65C005C 03FC2B5C FEDCBA98
	v_lshl_or_b32 v93, v94, 16, v93                            // 000000B5D7AC: D656005D 0575215E
	.long 0xd72c005e                                           // 000000B5D7B4: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000B5D7B8: 0202C4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5D7C0: BF870214
	v_mov_b32_e32 v99, v97                                     // 000000B5D7C4: 7EC60361
	v_cndmask_b32_e64 v90, v92, v91, s3                        // 000000B5D7C8: D501005A 000EB75C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5D7D0: BF870194
	v_pk_fma_f16 v93, v93, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5D7D4: CC0E005D 0BFC1B5D 0000C931
	v_permlanex16_b32 v99, v99, s21, 0xfedcba98                // 000000B5D7E0: D65C0063 03FC2B63 FEDCBA98
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000B5D7EC: D622005E 03FD015E 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5D7F8: BF870091
	v_and_b32_e32 v94, 0xffff, v94                             // 000000B5D7FC: 36BCBCFF 0000FFFF
	v_lshl_or_b32 v94, v95, 16, v94                            // 000000B5D804: D656005E 0579215F
	v_mov_b32_e32 v95, v93                                     // 000000B5D80C: 7EBE035D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5D810: BF870112
	v_pk_fma_f16 v96, v94, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5D814: CC0E0060 0BFC1B5E 0000C931
	v_permlanex16_b32 v95, v95, s21, 0xfedcba98                // 000000B5D820: D65C005F 03FC2B5F FEDCBA98
	v_cndmask_b32_e64 v94, v91, v92, s3                        // 000000B5D82C: D501005E 000EB95B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5D834: BF870193
	v_mov_b32_e32 v98, v96                                     // 000000B5D838: 7EC40360
	v_cndmask_b32_e64 v91, v95, v93, s3                        // 000000B5D83C: D501005B 000EBB5F
	v_cndmask_b32_e64 v95, v93, v95, s3                        // 000000B5D844: D501005F 000EBF5D
	v_cndmask_b32_e64 v93, v99, v97, s3                        // 000000B5D84C: D501005D 000EC363
	v_cndmask_b32_e64 v97, v97, v99, s3                        // 000000B5D854: D5010061 000EC761
	v_permlanex16_b32 v98, v98, s21, 0xfedcba98                // 000000B5D85C: D65C0062 03FC2B62 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B5D868: BF870001
	v_cndmask_b32_e64 v92, v98, v96, s3                        // 000000B5D86C: D501005C 000EC162
	v_cndmask_b32_e64 v96, v96, v98, s3                        // 000000B5D874: D5010060 000EC560
	ds_load_b128 v[98:101], v106                               // 000000B5D87C: DBFC0000 6200006A
	ds_load_b128 v[102:105], v106 offset:16                    // 000000B5D884: DBFC0010 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5D88C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[90:97], v[98:105], v[25:32]// 000000B5D890: CC404019 1C66C55A
	ds_load_b128 v[98:101], v106 offset:4352                   // 000000B5D898: DBFC1100 6200006A
	ds_load_b128 v[102:105], v106 offset:4368                  // 000000B5D8A0: DBFC1110 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5D8A8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[90:97], v[98:105], v[17:24]// 000000B5D8AC: CC404011 1C46C55A
	ds_load_b128 v[98:101], v106 offset:8704                   // 000000B5D8B4: DBFC2200 6200006A
	ds_load_b128 v[102:105], v106 offset:8720                  // 000000B5D8BC: DBFC2210 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5D8C4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[90:97], v[98:105], v[9:16]// 000000B5D8C8: CC404009 1C26C55A
	ds_load_b128 v[98:101], v106 offset:13056                  // 000000B5D8D0: DBFC3300 6200006A
	ds_load_b128 v[102:105], v106 offset:13072                 // 000000B5D8D8: DBFC3310 6600006A
	v_add_nc_u32_e32 v106, s29, v89                            // 000000B5D8E0: 4AD4B21D
	s_cselect_b32 s29, s23, 0x4480                             // 000000B5D8E4: 981DFF17 00004480
	s_waitcnt lgkmcnt(0)                                       // 000000B5D8EC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[90:97], v[98:105], v[1:8]// 000000B5D8F0: CC404001 1C06C55A
	s_clause 0x1                                               // 000000B5D8F8: BF850001
	global_load_b32 v91, v[53:54], off offset:2304             // 000000B5D8FC: DC520900 5B7C0035
	global_load_b32 v90, v[55:56], off offset:2304             // 000000B5D904: DC520900 5A7C0037
	s_waitcnt vmcnt(0)                                         // 000000B5D90C: BF8903F7
	.long 0xd73d005c                                           // 000000B5D910: D73D005C
	v_cndmask_b32_e32 v1, v64, v90, vcc_lo                     // 000000B5D914: 0202B540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5D918: BF8700A1
	v_and_b32_e32 v94, 0xffff, v92                             // 000000B5D91C: 36BCB8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5D924: D73D005C
	v_cndmask_b32_e32 v1, v65, v90, vcc_lo                     // 000000B5D928: 0202B541
	v_and_b32_e32 v95, 0xffff, v92                             // 000000B5D92C: 36BEB8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5D934: D73D005C
	v_cndmask_b32_e32 v1, v66, v90, vcc_lo                     // 000000B5D938: 0202B542
	.long 0xd73d005a                                           // 000000B5D93C: D73D005A
	v_cndmask_b32_e32 v1, v67, v90, vcc_lo                     // 000000B5D940: 0202B543
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5D944: BF870112
	v_and_b32_e32 v96, 0xffff, v92                             // 000000B5D948: 36C0B8FF 0000FFFF
	v_and_b32_e32 v97, 0xffff, v90                             // 000000B5D950: 36C2B4FF 0000FFFF
	s_clause 0x1                                               // 000000B5D958: BF850001
	global_load_b32 v91, v[51:52], off offset:2304             // 000000B5D95C: DC520900 5B7C0033
	global_load_b32 v90, v[49:50], off offset:2304             // 000000B5D964: DC520900 5A7C0031
	s_waitcnt vmcnt(0)                                         // 000000B5D96C: BF8903F7
	.long 0xd73d005c                                           // 000000B5D970: D73D005C
	v_cndmask_b32_e32 v1, v68, v90, vcc_lo                     // 000000B5D974: 0202B544
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5D978: BF8700A1
	v_and_b32_e32 v98, 0xffff, v92                             // 000000B5D97C: 36C4B8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5D984: D73D005C
	v_cndmask_b32_e32 v1, v69, v90, vcc_lo                     // 000000B5D988: 0202B545
	v_and_b32_e32 v99, 0xffff, v92                             // 000000B5D98C: 36C6B8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5D994: D73D005C
	v_cndmask_b32_e32 v1, v70, v90, vcc_lo                     // 000000B5D998: 0202B546
	.long 0xd73d005a                                           // 000000B5D99C: D73D005A
	v_cndmask_b32_e32 v1, v71, v90, vcc_lo                     // 000000B5D9A0: 0202B547
	.long 0xd72c005b                                           // 000000B5D9A4: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000B5D9A8: 0202BCFF 83DCD12D
	.long 0xd72c005d                                           // 000000B5D9B0: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000B5D9B4: 0202BEFF 83DCD12D
	.long 0xd72c005e                                           // 000000B5D9BC: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000B5D9C0: 0202C2FF 83DCD12D
	.long 0xd72c005f                                           // 000000B5D9C8: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000B5D9CC: 0202C6FF 83DCD12D
	v_and_b32_e32 v92, 0xffff, v92                             // 000000B5D9D4: 36B8B8FF 0000FFFF
	v_and_b32_e32 v90, 0xffff, v90                             // 000000B5D9DC: 36B4B4FF 0000FFFF
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000B5D9E4: D622005B 03FD015B 00006400
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000B5D9F0: D622005D 03FD015D 00006400
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000B5D9FC: D622005E 03FD015E 00006400
	.long 0xd72c005c                                           // 000000B5DA08: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000B5DA0C: 0202B8FF 83DCD12D
	.long 0xd72c005a                                           // 000000B5DA14: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000B5DA18: 0202B4FF 83DCD12D
	v_and_b32_e32 v91, 0xffff, v91                             // 000000B5DA20: 36B6B6FF 0000FFFF
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000B5DA28: D622005F 03FD015F 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B5DA34: BF870242
	v_lshl_or_b32 v91, v93, 16, v91                            // 000000B5DA38: D656005B 056D215D
	.long 0xd72c005d                                           // 000000B5DA40: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000B5DA44: 0202C0FF 83DCD12D
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000B5DA4C: D622005C 03FD015C 00006400
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000B5DA58: D622005A 03FD015A 00006400
	v_pk_fma_f16 v91, v91, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5DA64: CC0E005B 0BFC1B5B 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B5DA70: BF870123
	v_and_b32_e32 v92, 0xffff, v92                             // 000000B5DA74: 36B8B8FF 0000FFFF
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000B5DA7C: D622005D 03FD015D 00006400
	v_lshl_or_b32 v90, v90, 16, v92                            // 000000B5DA88: D656005A 0571215A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5DA90: BF870112
	v_dual_mov_b32 v92, v91 :: v_dual_and_b32 v93, 0xffff, v93 // 000000B5DA94: CA24015B 5C5CBAFF 0000FFFF
	v_pk_fma_f16 v97, v90, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5DAA0: CC0E0061 0BFC1B5A 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5DAAC: BF870192
	v_permlanex16_b32 v92, v92, s21, 0xfedcba98                // 000000B5DAB0: D65C005C 03FC2B5C FEDCBA98
	v_lshl_or_b32 v93, v94, 16, v93                            // 000000B5DABC: D656005D 0575215E
	.long 0xd72c005e                                           // 000000B5DAC4: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000B5DAC8: 0202C4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5DAD0: BF870214
	v_mov_b32_e32 v99, v97                                     // 000000B5DAD4: 7EC60361
	v_cndmask_b32_e64 v90, v92, v91, s3                        // 000000B5DAD8: D501005A 000EB75C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5DAE0: BF870194
	v_pk_fma_f16 v93, v93, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5DAE4: CC0E005D 0BFC1B5D 0000C931
	v_permlanex16_b32 v99, v99, s21, 0xfedcba98                // 000000B5DAF0: D65C0063 03FC2B63 FEDCBA98
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000B5DAFC: D622005E 03FD015E 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5DB08: BF870091
	v_and_b32_e32 v94, 0xffff, v94                             // 000000B5DB0C: 36BCBCFF 0000FFFF
	v_lshl_or_b32 v94, v95, 16, v94                            // 000000B5DB14: D656005E 0579215F
	v_mov_b32_e32 v95, v93                                     // 000000B5DB1C: 7EBE035D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5DB20: BF870112
	v_pk_fma_f16 v96, v94, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5DB24: CC0E0060 0BFC1B5E 0000C931
	v_permlanex16_b32 v95, v95, s21, 0xfedcba98                // 000000B5DB30: D65C005F 03FC2B5F FEDCBA98
	v_cndmask_b32_e64 v94, v91, v92, s3                        // 000000B5DB3C: D501005E 000EB95B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5DB44: BF870193
	v_mov_b32_e32 v98, v96                                     // 000000B5DB48: 7EC40360
	v_cndmask_b32_e64 v91, v95, v93, s3                        // 000000B5DB4C: D501005B 000EBB5F
	v_cndmask_b32_e64 v95, v93, v95, s3                        // 000000B5DB54: D501005F 000EBF5D
	v_cndmask_b32_e64 v93, v99, v97, s3                        // 000000B5DB5C: D501005D 000EC363
	v_cndmask_b32_e64 v97, v97, v99, s3                        // 000000B5DB64: D5010061 000EC761
	v_permlanex16_b32 v98, v98, s21, 0xfedcba98                // 000000B5DB6C: D65C0062 03FC2B62 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B5DB78: BF870001
	v_cndmask_b32_e64 v92, v98, v96, s3                        // 000000B5DB7C: D501005C 000EC162
	v_cndmask_b32_e64 v96, v96, v98, s3                        // 000000B5DB84: D5010060 000EC560
	ds_load_b128 v[98:101], v106                               // 000000B5DB8C: DBFC0000 6200006A
	ds_load_b128 v[102:105], v106 offset:16                    // 000000B5DB94: DBFC0010 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5DB9C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[90:97], v[98:105], v[25:32]// 000000B5DBA0: CC404019 1C66C55A
	ds_load_b128 v[98:101], v106 offset:4352                   // 000000B5DBA8: DBFC1100 6200006A
	ds_load_b128 v[102:105], v106 offset:4368                  // 000000B5DBB0: DBFC1110 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5DBB8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[90:97], v[98:105], v[17:24]// 000000B5DBBC: CC404011 1C46C55A
	ds_load_b128 v[98:101], v106 offset:8704                   // 000000B5DBC4: DBFC2200 6200006A
	ds_load_b128 v[102:105], v106 offset:8720                  // 000000B5DBCC: DBFC2210 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5DBD4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[90:97], v[98:105], v[9:16]// 000000B5DBD8: CC404009 1C26C55A
	ds_load_b128 v[98:101], v106 offset:13056                  // 000000B5DBE0: DBFC3300 6200006A
	ds_load_b128 v[102:105], v106 offset:13072                 // 000000B5DBE8: DBFC3310 6600006A
	v_add_nc_u32_e32 v106, s29, v89                            // 000000B5DBF0: 4AD4B21D
	s_cselect_b32 s29, s24, 0x44a0                             // 000000B5DBF4: 981DFF18 000044A0
	s_waitcnt lgkmcnt(0)                                       // 000000B5DBFC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[90:97], v[98:105], v[1:8]// 000000B5DC00: CC404001 1C06C55A
	s_clause 0x1                                               // 000000B5DC08: BF850001
	global_load_b32 v91, v[53:54], off offset:3072             // 000000B5DC0C: DC520C00 5B7C0035
	global_load_b32 v90, v[55:56], off offset:3072             // 000000B5DC14: DC520C00 5A7C0037
	s_waitcnt vmcnt(0)                                         // 000000B5DC1C: BF8903F7
	.long 0xd73d005c                                           // 000000B5DC20: D73D005C
	v_cndmask_b32_e32 v1, v64, v90, vcc_lo                     // 000000B5DC24: 0202B540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5DC28: BF8700A1
	v_and_b32_e32 v94, 0xffff, v92                             // 000000B5DC2C: 36BCB8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5DC34: D73D005C
	v_cndmask_b32_e32 v1, v65, v90, vcc_lo                     // 000000B5DC38: 0202B541
	v_and_b32_e32 v95, 0xffff, v92                             // 000000B5DC3C: 36BEB8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5DC44: D73D005C
	v_cndmask_b32_e32 v1, v66, v90, vcc_lo                     // 000000B5DC48: 0202B542
	.long 0xd73d005a                                           // 000000B5DC4C: D73D005A
	v_cndmask_b32_e32 v1, v67, v90, vcc_lo                     // 000000B5DC50: 0202B543
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5DC54: BF870112
	v_and_b32_e32 v96, 0xffff, v92                             // 000000B5DC58: 36C0B8FF 0000FFFF
	v_and_b32_e32 v97, 0xffff, v90                             // 000000B5DC60: 36C2B4FF 0000FFFF
	s_clause 0x1                                               // 000000B5DC68: BF850001
	global_load_b32 v91, v[51:52], off offset:3072             // 000000B5DC6C: DC520C00 5B7C0033
	global_load_b32 v90, v[49:50], off offset:3072             // 000000B5DC74: DC520C00 5A7C0031
	s_waitcnt vmcnt(0)                                         // 000000B5DC7C: BF8903F7
	.long 0xd73d005c                                           // 000000B5DC80: D73D005C
	v_cndmask_b32_e32 v1, v68, v90, vcc_lo                     // 000000B5DC84: 0202B544
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5DC88: BF8700A1
	v_and_b32_e32 v98, 0xffff, v92                             // 000000B5DC8C: 36C4B8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5DC94: D73D005C
	v_cndmask_b32_e32 v1, v69, v90, vcc_lo                     // 000000B5DC98: 0202B545
	v_and_b32_e32 v99, 0xffff, v92                             // 000000B5DC9C: 36C6B8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5DCA4: D73D005C
	v_cndmask_b32_e32 v1, v70, v90, vcc_lo                     // 000000B5DCA8: 0202B546
	.long 0xd73d005a                                           // 000000B5DCAC: D73D005A
	v_cndmask_b32_e32 v1, v71, v90, vcc_lo                     // 000000B5DCB0: 0202B547
	.long 0xd72c005b                                           // 000000B5DCB4: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000B5DCB8: 0202BCFF 83DCD12D
	.long 0xd72c005d                                           // 000000B5DCC0: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000B5DCC4: 0202BEFF 83DCD12D
	.long 0xd72c005e                                           // 000000B5DCCC: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000B5DCD0: 0202C2FF 83DCD12D
	.long 0xd72c005f                                           // 000000B5DCD8: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000B5DCDC: 0202C6FF 83DCD12D
	v_and_b32_e32 v92, 0xffff, v92                             // 000000B5DCE4: 36B8B8FF 0000FFFF
	v_and_b32_e32 v90, 0xffff, v90                             // 000000B5DCEC: 36B4B4FF 0000FFFF
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000B5DCF4: D622005B 03FD015B 00006400
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000B5DD00: D622005D 03FD015D 00006400
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000B5DD0C: D622005E 03FD015E 00006400
	.long 0xd72c005c                                           // 000000B5DD18: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000B5DD1C: 0202B8FF 83DCD12D
	.long 0xd72c005a                                           // 000000B5DD24: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000B5DD28: 0202B4FF 83DCD12D
	v_and_b32_e32 v91, 0xffff, v91                             // 000000B5DD30: 36B6B6FF 0000FFFF
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000B5DD38: D622005F 03FD015F 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B5DD44: BF870242
	v_lshl_or_b32 v91, v93, 16, v91                            // 000000B5DD48: D656005B 056D215D
	.long 0xd72c005d                                           // 000000B5DD50: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000B5DD54: 0202C0FF 83DCD12D
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000B5DD5C: D622005C 03FD015C 00006400
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000B5DD68: D622005A 03FD015A 00006400
	v_pk_fma_f16 v91, v91, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5DD74: CC0E005B 0BFC1B5B 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B5DD80: BF870123
	v_and_b32_e32 v92, 0xffff, v92                             // 000000B5DD84: 36B8B8FF 0000FFFF
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000B5DD8C: D622005D 03FD015D 00006400
	v_lshl_or_b32 v90, v90, 16, v92                            // 000000B5DD98: D656005A 0571215A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5DDA0: BF870112
	v_dual_mov_b32 v92, v91 :: v_dual_and_b32 v93, 0xffff, v93 // 000000B5DDA4: CA24015B 5C5CBAFF 0000FFFF
	v_pk_fma_f16 v97, v90, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5DDB0: CC0E0061 0BFC1B5A 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5DDBC: BF870192
	v_permlanex16_b32 v92, v92, s21, 0xfedcba98                // 000000B5DDC0: D65C005C 03FC2B5C FEDCBA98
	v_lshl_or_b32 v93, v94, 16, v93                            // 000000B5DDCC: D656005D 0575215E
	.long 0xd72c005e                                           // 000000B5DDD4: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000B5DDD8: 0202C4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5DDE0: BF870214
	v_mov_b32_e32 v99, v97                                     // 000000B5DDE4: 7EC60361
	v_cndmask_b32_e64 v90, v92, v91, s3                        // 000000B5DDE8: D501005A 000EB75C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5DDF0: BF870194
	v_pk_fma_f16 v93, v93, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5DDF4: CC0E005D 0BFC1B5D 0000C931
	v_permlanex16_b32 v99, v99, s21, 0xfedcba98                // 000000B5DE00: D65C0063 03FC2B63 FEDCBA98
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000B5DE0C: D622005E 03FD015E 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5DE18: BF870091
	v_and_b32_e32 v94, 0xffff, v94                             // 000000B5DE1C: 36BCBCFF 0000FFFF
	v_lshl_or_b32 v94, v95, 16, v94                            // 000000B5DE24: D656005E 0579215F
	v_mov_b32_e32 v95, v93                                     // 000000B5DE2C: 7EBE035D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5DE30: BF870112
	v_pk_fma_f16 v96, v94, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5DE34: CC0E0060 0BFC1B5E 0000C931
	v_permlanex16_b32 v95, v95, s21, 0xfedcba98                // 000000B5DE40: D65C005F 03FC2B5F FEDCBA98
	v_cndmask_b32_e64 v94, v91, v92, s3                        // 000000B5DE4C: D501005E 000EB95B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5DE54: BF870193
	v_mov_b32_e32 v98, v96                                     // 000000B5DE58: 7EC40360
	v_cndmask_b32_e64 v91, v95, v93, s3                        // 000000B5DE5C: D501005B 000EBB5F
	v_cndmask_b32_e64 v95, v93, v95, s3                        // 000000B5DE64: D501005F 000EBF5D
	v_cndmask_b32_e64 v93, v99, v97, s3                        // 000000B5DE6C: D501005D 000EC363
	v_cndmask_b32_e64 v97, v97, v99, s3                        // 000000B5DE74: D5010061 000EC761
	v_permlanex16_b32 v98, v98, s21, 0xfedcba98                // 000000B5DE7C: D65C0062 03FC2B62 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B5DE88: BF870001
	v_cndmask_b32_e64 v92, v98, v96, s3                        // 000000B5DE8C: D501005C 000EC162
	v_cndmask_b32_e64 v96, v96, v98, s3                        // 000000B5DE94: D5010060 000EC560
	ds_load_b128 v[98:101], v106                               // 000000B5DE9C: DBFC0000 6200006A
	ds_load_b128 v[102:105], v106 offset:16                    // 000000B5DEA4: DBFC0010 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5DEAC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[90:97], v[98:105], v[25:32]// 000000B5DEB0: CC404019 1C66C55A
	ds_load_b128 v[98:101], v106 offset:4352                   // 000000B5DEB8: DBFC1100 6200006A
	ds_load_b128 v[102:105], v106 offset:4368                  // 000000B5DEC0: DBFC1110 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5DEC8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[90:97], v[98:105], v[17:24]// 000000B5DECC: CC404011 1C46C55A
	ds_load_b128 v[98:101], v106 offset:8704                   // 000000B5DED4: DBFC2200 6200006A
	ds_load_b128 v[102:105], v106 offset:8720                  // 000000B5DEDC: DBFC2210 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5DEE4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[90:97], v[98:105], v[9:16]// 000000B5DEE8: CC404009 1C26C55A
	ds_load_b128 v[98:101], v106 offset:13056                  // 000000B5DEF0: DBFC3300 6200006A
	ds_load_b128 v[102:105], v106 offset:13072                 // 000000B5DEF8: DBFC3310 6600006A
	v_add_nc_u32_e32 v106, s29, v89                            // 000000B5DF00: 4AD4B21D
	s_cselect_b32 s29, s25, 0x44c0                             // 000000B5DF04: 981DFF19 000044C0
	s_waitcnt lgkmcnt(0)                                       // 000000B5DF0C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[90:97], v[98:105], v[1:8]// 000000B5DF10: CC404001 1C06C55A
	s_clause 0x1                                               // 000000B5DF18: BF850001
	global_load_b32 v91, v[53:54], off offset:3840             // 000000B5DF1C: DC520F00 5B7C0035
	global_load_b32 v90, v[55:56], off offset:3840             // 000000B5DF24: DC520F00 5A7C0037
	s_waitcnt vmcnt(0)                                         // 000000B5DF2C: BF8903F7
	.long 0xd73d005c                                           // 000000B5DF30: D73D005C
	v_cndmask_b32_e32 v1, v64, v90, vcc_lo                     // 000000B5DF34: 0202B540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5DF38: BF8700A1
	v_and_b32_e32 v94, 0xffff, v92                             // 000000B5DF3C: 36BCB8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5DF44: D73D005C
	v_cndmask_b32_e32 v1, v65, v90, vcc_lo                     // 000000B5DF48: 0202B541
	v_and_b32_e32 v95, 0xffff, v92                             // 000000B5DF4C: 36BEB8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5DF54: D73D005C
	v_cndmask_b32_e32 v1, v66, v90, vcc_lo                     // 000000B5DF58: 0202B542
	.long 0xd73d005a                                           // 000000B5DF5C: D73D005A
	v_cndmask_b32_e32 v1, v67, v90, vcc_lo                     // 000000B5DF60: 0202B543
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5DF64: BF870112
	v_and_b32_e32 v96, 0xffff, v92                             // 000000B5DF68: 36C0B8FF 0000FFFF
	v_and_b32_e32 v97, 0xffff, v90                             // 000000B5DF70: 36C2B4FF 0000FFFF
	s_clause 0x1                                               // 000000B5DF78: BF850001
	global_load_b32 v91, v[51:52], off offset:3840             // 000000B5DF7C: DC520F00 5B7C0033
	global_load_b32 v90, v[49:50], off offset:3840             // 000000B5DF84: DC520F00 5A7C0031
	s_waitcnt vmcnt(0)                                         // 000000B5DF8C: BF8903F7
	.long 0xd73d005c                                           // 000000B5DF90: D73D005C
	v_cndmask_b32_e32 v1, v68, v90, vcc_lo                     // 000000B5DF94: 0202B544
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5DF98: BF8700A1
	v_and_b32_e32 v98, 0xffff, v92                             // 000000B5DF9C: 36C4B8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5DFA4: D73D005C
	v_cndmask_b32_e32 v1, v69, v90, vcc_lo                     // 000000B5DFA8: 0202B545
	v_and_b32_e32 v99, 0xffff, v92                             // 000000B5DFAC: 36C6B8FF 0000FFFF
	.long 0xd73d005c                                           // 000000B5DFB4: D73D005C
	v_cndmask_b32_e32 v1, v70, v90, vcc_lo                     // 000000B5DFB8: 0202B546
	.long 0xd73d005a                                           // 000000B5DFBC: D73D005A
	v_cndmask_b32_e32 v1, v71, v90, vcc_lo                     // 000000B5DFC0: 0202B547
	.long 0xd72c005b                                           // 000000B5DFC4: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000B5DFC8: 0202BCFF 83DCD12D
	.long 0xd72c005d                                           // 000000B5DFD0: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000B5DFD4: 0202BEFF 83DCD12D
	.long 0xd72c005e                                           // 000000B5DFDC: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000B5DFE0: 0202C2FF 83DCD12D
	.long 0xd72c005f                                           // 000000B5DFE8: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000B5DFEC: 0202C6FF 83DCD12D
	v_and_b32_e32 v92, 0xffff, v92                             // 000000B5DFF4: 36B8B8FF 0000FFFF
	v_and_b32_e32 v90, 0xffff, v90                             // 000000B5DFFC: 36B4B4FF 0000FFFF
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000B5E004: D622005B 03FD015B 00006400
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000B5E010: D622005D 03FD015D 00006400
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000B5E01C: D622005E 03FD015E 00006400
	.long 0xd72c005c                                           // 000000B5E028: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000B5E02C: 0202B8FF 83DCD12D
	.long 0xd72c005a                                           // 000000B5E034: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000B5E038: 0202B4FF 83DCD12D
	v_and_b32_e32 v91, 0xffff, v91                             // 000000B5E040: 36B6B6FF 0000FFFF
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000B5E048: D622005F 03FD015F 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B5E054: BF870242
	v_lshl_or_b32 v91, v93, 16, v91                            // 000000B5E058: D656005B 056D215D
	.long 0xd72c005d                                           // 000000B5E060: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000B5E064: 0202C0FF 83DCD12D
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000B5E06C: D622005C 03FD015C 00006400
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000B5E078: D622005A 03FD015A 00006400
	v_pk_fma_f16 v91, v91, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5E084: CC0E005B 0BFC1B5B 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B5E090: BF870123
	v_and_b32_e32 v92, 0xffff, v92                             // 000000B5E094: 36B8B8FF 0000FFFF
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000B5E09C: D622005D 03FD015D 00006400
	v_lshl_or_b32 v90, v90, 16, v92                            // 000000B5E0A8: D656005A 0571215A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5E0B0: BF870112
	v_dual_mov_b32 v92, v91 :: v_dual_and_b32 v93, 0xffff, v93 // 000000B5E0B4: CA24015B 5C5CBAFF 0000FFFF
	v_pk_fma_f16 v97, v90, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5E0C0: CC0E0061 0BFC1B5A 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5E0CC: BF870192
	v_permlanex16_b32 v92, v92, s21, 0xfedcba98                // 000000B5E0D0: D65C005C 03FC2B5C FEDCBA98
	v_lshl_or_b32 v93, v94, 16, v93                            // 000000B5E0DC: D656005D 0575215E
	.long 0xd72c005e                                           // 000000B5E0E4: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000B5E0E8: 0202C4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5E0F0: BF870214
	v_mov_b32_e32 v99, v97                                     // 000000B5E0F4: 7EC60361
	v_cndmask_b32_e64 v90, v92, v91, s3                        // 000000B5E0F8: D501005A 000EB75C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5E100: BF870194
	v_pk_fma_f16 v93, v93, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5E104: CC0E005D 0BFC1B5D 0000C931
	v_permlanex16_b32 v99, v99, s21, 0xfedcba98                // 000000B5E110: D65C0063 03FC2B63 FEDCBA98
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000B5E11C: D622005E 03FD015E 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5E128: BF870091
	v_and_b32_e32 v94, 0xffff, v94                             // 000000B5E12C: 36BCBCFF 0000FFFF
	v_lshl_or_b32 v94, v95, 16, v94                            // 000000B5E134: D656005E 0579215F
	v_mov_b32_e32 v95, v93                                     // 000000B5E13C: 7EBE035D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5E140: BF870112
	v_pk_fma_f16 v96, v94, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5E144: CC0E0060 0BFC1B5E 0000C931
	v_permlanex16_b32 v95, v95, s21, 0xfedcba98                // 000000B5E150: D65C005F 03FC2B5F FEDCBA98
	v_cndmask_b32_e64 v94, v91, v92, s3                        // 000000B5E15C: D501005E 000EB95B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5E164: BF870193
	v_mov_b32_e32 v98, v96                                     // 000000B5E168: 7EC40360
	v_cndmask_b32_e64 v91, v95, v93, s3                        // 000000B5E16C: D501005B 000EBB5F
	v_cndmask_b32_e64 v95, v93, v95, s3                        // 000000B5E174: D501005F 000EBF5D
	v_cndmask_b32_e64 v93, v99, v97, s3                        // 000000B5E17C: D501005D 000EC363
	v_cndmask_b32_e64 v97, v97, v99, s3                        // 000000B5E184: D5010061 000EC761
	v_permlanex16_b32 v98, v98, s21, 0xfedcba98                // 000000B5E18C: D65C0062 03FC2B62 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B5E198: BF870001
	v_cndmask_b32_e64 v92, v98, v96, s3                        // 000000B5E19C: D501005C 000EC162
	v_cndmask_b32_e64 v96, v96, v98, s3                        // 000000B5E1A4: D5010060 000EC560
	ds_load_b128 v[98:101], v106                               // 000000B5E1AC: DBFC0000 6200006A
	ds_load_b128 v[102:105], v106 offset:16                    // 000000B5E1B4: DBFC0010 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5E1BC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[90:97], v[98:105], v[25:32]// 000000B5E1C0: CC404019 1C66C55A
	ds_load_b128 v[98:101], v106 offset:4352                   // 000000B5E1C8: DBFC1100 6200006A
	ds_load_b128 v[102:105], v106 offset:4368                  // 000000B5E1D0: DBFC1110 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5E1D8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[90:97], v[98:105], v[17:24]// 000000B5E1DC: CC404011 1C46C55A
	ds_load_b128 v[98:101], v106 offset:8704                   // 000000B5E1E4: DBFC2200 6200006A
	ds_load_b128 v[102:105], v106 offset:8720                  // 000000B5E1EC: DBFC2210 6600006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5E1F4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[90:97], v[98:105], v[9:16]// 000000B5E1F8: CC404009 1C26C55A
	ds_load_b128 v[98:101], v106 offset:13056                  // 000000B5E200: DBFC3300 6200006A
	ds_load_b128 v[102:105], v106 offset:13072                 // 000000B5E208: DBFC3310 6600006A
	v_add_nc_u32_e32 v106, s29, v89                            // 000000B5E210: 4AD4B21D
	s_and_b32 s29, s28, exec_lo                                // 000000B5E214: 8B1D7E1C
	s_cselect_b32 s29, s26, 0x44e0                             // 000000B5E218: 981DFF1A 000044E0
	s_waitcnt lgkmcnt(0)                                       // 000000B5E220: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[90:97], v[98:105], v[1:8]// 000000B5E224: CC404001 1C06C55A
	.long 0xd7006a62                                           // 000000B5E22C: D7006A62
	v_cndmask_b32_e32 v1, 0x1000, v53, vcc_lo                  // 000000B5E230: 02026AFF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5E238: BF8700A1
	v_add_co_ci_u32_e64 v99, null, 0, v54, vcc_lo              // 000000B5E23C: D5207C63 01AA6C80
	.long 0xd7006a64                                           // 000000B5E244: D7006A64
	v_cndmask_b32_e32 v1, 0x1000, v55, vcc_lo                  // 000000B5E248: 02026EFF 00001000
	v_add_co_ci_u32_e64 v101, null, 0, v56, vcc_lo             // 000000B5E250: D5207C65 01AA7080
	global_load_b32 v54, v[98:99], off offset:512              // 000000B5E258: DC520200 367C0062
	.long 0xd7006a66                                           // 000000B5E260: D7006A66
	v_cndmask_b32_e32 v1, 0x1000, v51, vcc_lo                  // 000000B5E264: 020266FF 00001000
	global_load_b32 v53, v[100:101], off offset:512            // 000000B5E26C: DC520200 357C0064
	v_add_co_ci_u32_e64 v103, null, 0, v52, vcc_lo             // 000000B5E274: D5207C67 01AA6880
	.long 0xd7006a68                                           // 000000B5E27C: D7006A68
	v_cndmask_b32_e32 v1, 0x1000, v49, vcc_lo                  // 000000B5E280: 020262FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B5E288: BF870001
	v_add_co_ci_u32_e64 v105, null, 0, v50, vcc_lo             // 000000B5E28C: D5207C69 01AA6480
	global_load_b32 v51, v[102:103], off offset:512            // 000000B5E294: DC520200 337C0066
	s_and_not1_b32 vcc_lo, exec_lo, s27                        // 000000B5E29C: 916A1B7E
	global_load_b32 v50, v[104:105], off offset:512            // 000000B5E2A0: DC520200 327C0068
	s_waitcnt vmcnt(2)                                         // 000000B5E2A8: BF890BF7
	.long 0xd73d0037                                           // 000000B5E2AC: D73D0037
	v_cndmask_b32_e32 v1, v64, v53, vcc_lo                     // 000000B5E2B0: 02026B40
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5E2B4: BF8700A1
	v_and_b32_e32 v90, 0xffff, v55                             // 000000B5E2B8: 36B46EFF 0000FFFF
	.long 0xd73d0037                                           // 000000B5E2C0: D73D0037
	v_cndmask_b32_e32 v1, v65, v53, vcc_lo                     // 000000B5E2C4: 02026B41
	v_and_b32_e32 v91, 0xffff, v55                             // 000000B5E2C8: 36B66EFF 0000FFFF
	.long 0xd73d0037                                           // 000000B5E2D0: D73D0037
	v_cndmask_b32_e32 v1, v66, v53, vcc_lo                     // 000000B5E2D4: 02026B42
	.long 0xd73d0035                                           // 000000B5E2D8: D73D0035
	v_cndmask_b32_e32 v1, v67, v53, vcc_lo                     // 000000B5E2DC: 02026B43
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5E2E0: BF870112
	v_and_b32_e32 v55, 0xffff, v55                             // 000000B5E2E4: 366E6EFF 0000FFFF
	v_and_b32_e32 v54, 0xffff, v53                             // 000000B5E2EC: 366C6AFF 0000FFFF
	s_waitcnt vmcnt(0)                                         // 000000B5E2F4: BF8903F7
	.long 0xd73d0034                                           // 000000B5E2F8: D73D0034
	v_cndmask_b32_e32 v1, v68, v50, vcc_lo                     // 000000B5E2FC: 02026544
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5E300: BF8700A1
	v_and_b32_e32 v56, 0xffff, v52                             // 000000B5E304: 367068FF 0000FFFF
	.long 0xd73d0034                                           // 000000B5E30C: D73D0034
	v_cndmask_b32_e32 v1, v69, v50, vcc_lo                     // 000000B5E310: 02026545
	v_and_b32_e32 v92, 0xffff, v52                             // 000000B5E314: 36B868FF 0000FFFF
	.long 0xd73d0034                                           // 000000B5E31C: D73D0034
	v_cndmask_b32_e32 v1, v70, v50, vcc_lo                     // 000000B5E320: 02026546
	.long 0xd73d0031                                           // 000000B5E324: D73D0031
	v_cndmask_b32_e32 v1, v71, v50, vcc_lo                     // 000000B5E328: 02026547
	.long 0xd72c0032                                           // 000000B5E32C: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000B5E330: 0202B4FF 83DCD12D
	.long 0xd72c0033                                           // 000000B5E338: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000B5E33C: 0202B6FF 83DCD12D
	.long 0xd72c0035                                           // 000000B5E344: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000B5E348: 02026CFF 83DCD12D
	.long 0xd72c0036                                           // 000000B5E350: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000B5E354: 0202B8FF 83DCD12D
	v_and_b32_e32 v52, 0xffff, v52                             // 000000B5E35C: 366868FF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v49                             // 000000B5E364: 366262FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000B5E36C: D6220032 03FD0132 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000B5E378: D6220033 03FD0133 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000B5E384: D6220035 03FD0135 00006400
	.long 0xd72c0034                                           // 000000B5E390: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000B5E394: 020268FF 83DCD12D
	.long 0xd72c0031                                           // 000000B5E39C: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000B5E3A0: 020262FF 83DCD12D
	v_and_b32_e32 v50, 0xffff, v50                             // 000000B5E3A8: 366464FF 0000FFFF
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000B5E3B0: D6220036 03FD0136 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B5E3BC: BF870242
	v_lshl_or_b32 v50, v51, 16, v50                            // 000000B5E3C0: D6560032 04C92133
	.long 0xd72c0033                                           // 000000B5E3C8: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000B5E3CC: 02026EFF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000B5E3D4: D6220034 03FD0134 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000B5E3E0: D6220031 03FD0131 00006400
	v_pk_fma_f16 v50, v50, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5E3EC: CC0E0032 0BFC1B32 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B5E3F8: BF870123
	v_and_b32_e32 v52, 0xffff, v52                             // 000000B5E3FC: 366868FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000B5E404: D6220033 03FD0133 00006400
	v_lshl_or_b32 v49, v49, 16, v52                            // 000000B5E410: D6560031 04D12131
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5E418: BF870092
	v_dual_mov_b32 v52, v50 :: v_dual_and_b32 v51, 0xffff, v51 // 000000B5E41C: CA240132 343266FF 0000FFFF
	v_permlanex16_b32 v52, v52, s21, 0xfedcba98                // 000000B5E428: D65C0034 03FC2B34 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B5E434: BF870232
	v_lshl_or_b32 v51, v53, 16, v51                            // 000000B5E438: D6560033 04CD2135
	.long 0xd72c0035                                           // 000000B5E440: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000B5E444: 020270FF 83DCD12D
	v_pk_fma_f16 v56, v49, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5E44C: CC0E0038 0BFC1B31 0000C931
	v_cndmask_b32_e64 v49, v52, v50, s3                        // 000000B5E458: D5010031 000E6534
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5E460: BF870194
	v_pk_fma_f16 v51, v51, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5E464: CC0E0033 0BFC1B33 0000C931
	v_mov_b32_e32 v91, v56                                     // 000000B5E470: 7EB60338
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000B5E474: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5E480: BF870112
	v_permlanex16_b32 v91, v91, s21, 0xfedcba98                // 000000B5E484: D65C005B 03FC2B5B FEDCBA98
	v_and_b32_e32 v53, 0xffff, v53                             // 000000B5E490: 366A6AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B5E498: BF870121
	v_lshl_or_b32 v53, v54, 16, v53                            // 000000B5E49C: D6560035 04D52136
	v_mov_b32_e32 v54, v51                                     // 000000B5E4A4: 7E6C0333
	v_pk_fma_f16 v55, v53, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5E4A8: CC0E0037 0BFC1B35 0000C931
	s_delay_alu instid0(VALU_DEP_2)                            // 000000B5E4B4: BF870002
	v_permlanex16_b32 v54, v54, s21, 0xfedcba98                // 000000B5E4B8: D65C0036 03FC2B36 FEDCBA98
	v_cndmask_b32_e64 v53, v50, v52, s3                        // 000000B5E4C4: D5010035 000E6932
	v_cndmask_b32_e64 v52, v91, v56, s3                        // 000000B5E4CC: D5010034 000E715B
	v_cndmask_b32_e64 v56, v56, v91, s3                        // 000000B5E4D4: D5010038 000EB738
	v_mov_b32_e32 v90, v55                                     // 000000B5E4DC: 7EB40337
	v_cndmask_b32_e64 v50, v54, v51, s3                        // 000000B5E4E0: D5010032 000E6736
	v_cndmask_b32_e64 v54, v51, v54, s3                        // 000000B5E4E8: D5010036 000E6D33
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5E4F0: BF870093
	v_permlanex16_b32 v90, v90, s21, 0xfedcba98                // 000000B5E4F4: D65C005A 03FC2B5A FEDCBA98
	v_cndmask_b32_e64 v51, v90, v55, s3                        // 000000B5E500: D5010033 000E6F5A
	v_cndmask_b32_e64 v55, v55, v90, s3                        // 000000B5E508: D5010037 000EB537
	ds_load_b128 v[90:93], v106                                // 000000B5E510: DBFC0000 5A00006A
	ds_load_b128 v[94:97], v106 offset:16                      // 000000B5E518: DBFC0010 5E00006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5E520: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[90:97], v[25:32]// 000000B5E524: CC404019 1C66B531
	ds_load_b128 v[90:93], v106 offset:4352                    // 000000B5E52C: DBFC1100 5A00006A
	ds_load_b128 v[94:97], v106 offset:4368                    // 000000B5E534: DBFC1110 5E00006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5E53C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[90:97], v[17:24]// 000000B5E540: CC404011 1C46B531
	ds_load_b128 v[90:93], v106 offset:8704                    // 000000B5E548: DBFC2200 5A00006A
	ds_load_b128 v[94:97], v106 offset:8720                    // 000000B5E550: DBFC2210 5E00006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5E558: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[90:97], v[9:16]// 000000B5E55C: CC404009 1C26B531
	ds_load_b128 v[90:93], v106 offset:13056                   // 000000B5E564: DBFC3300 5A00006A
	ds_load_b128 v[94:97], v106 offset:13072                   // 000000B5E56C: DBFC3310 5E00006A
	s_waitcnt lgkmcnt(0)                                       // 000000B5E574: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[49:56], v[90:97], v[1:8] // 000000B5E578: CC404001 1C06B531
	s_clause 0x3                                               // 000000B5E580: BF850003
	global_load_b32 v54, v[98:99], off offset:1280             // 000000B5E584: DC520500 367C0062
	global_load_b32 v53, v[100:101], off offset:1280           // 000000B5E58C: DC520500 357C0064
	global_load_b32 v91, v[102:103], off offset:1280           // 000000B5E594: DC520500 5B7C0066
	global_load_b32 v90, v[104:105], off offset:1280           // 000000B5E59C: DC520500 5A7C0068
	v_add_nc_u32_e32 v98, s29, v89                             // 000000B5E5A4: 4AC4B21D
	s_waitcnt vmcnt(2)                                         // 000000B5E5A8: BF890BF7
	.long 0xd73d0031                                           // 000000B5E5AC: D73D0031
	v_cndmask_b32_e32 v1, v64, v53, vcc_lo                     // 000000B5E5B0: 02026B40
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B5E5B4: BF870121
	v_and_b32_e32 v52, 0xffff, v49                             // 000000B5E5B8: 366862FF 0000FFFF
	.long 0xd73d0031                                           // 000000B5E5C0: D73D0031
	v_cndmask_b32_e32 v1, v65, v53, vcc_lo                     // 000000B5E5C4: 02026B41
	.long 0xd72c0034                                           // 000000B5E5C8: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000B5E5CC: 020268FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B5E5D4: BF8701B2
	v_and_b32_e32 v51, 0xffff, v49                             // 000000B5E5D8: 366662FF 0000FFFF
	.long 0xd73d0031                                           // 000000B5E5E0: D73D0031
	v_cndmask_b32_e32 v1, v66, v53, vcc_lo                     // 000000B5E5E4: 02026B42
	.long 0xd73d0035                                           // 000000B5E5E8: D73D0035
	v_cndmask_b32_e32 v1, v67, v53, vcc_lo                     // 000000B5E5EC: 02026B43
	.long 0xd72c0033                                           // 000000B5E5F0: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000B5E5F4: 020266FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000B5E5FC: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5E608: BF870214
	v_and_b32_e32 v50, 0xffff, v49                             // 000000B5E60C: 366462FF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v53                             // 000000B5E614: 36626AFF 0000FFFF
	s_waitcnt vmcnt(0)                                         // 000000B5E61C: BF8903F7
	.long 0xd73d0035                                           // 000000B5E620: D73D0035
	v_cndmask_b32_e32 v1, v68, v90, vcc_lo                     // 000000B5E624: 0202B544
	v_and_b32_e32 v52, 0xffff, v52                             // 000000B5E628: 366868FF 0000FFFF
	.long 0xd72c0032                                           // 000000B5E630: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000B5E634: 020264FF 83DCD12D
	.long 0xd72c0031                                           // 000000B5E63C: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000B5E640: 020262FF 83DCD12D
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000B5E648: D6220033 03FD0133 00006400
	v_and_b32_e32 v56, 0xffff, v53                             // 000000B5E654: 36706AFF 0000FFFF
	.long 0xd73d0035                                           // 000000B5E65C: D73D0035
	v_cndmask_b32_e32 v1, v69, v90, vcc_lo                     // 000000B5E660: 0202B545
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B5E664: BF870233
	v_lshl_or_b32 v51, v51, 16, v52                            // 000000B5E668: D6560033 04D12133
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000B5E670: D6220032 03FD0132 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000B5E67C: D6220031 03FD0131 00006400
	v_and_b32_e32 v55, 0xffff, v53                             // 000000B5E688: 366E6AFF 0000FFFF
	.long 0xd73d0035                                           // 000000B5E690: D73D0035
	v_cndmask_b32_e32 v1, v70, v90, vcc_lo                     // 000000B5E694: 0202B546
	.long 0xd73d005a                                           // 000000B5E698: D73D005A
	v_cndmask_b32_e32 v1, v71, v90, vcc_lo                     // 000000B5E69C: 0202B547
	v_and_b32_e32 v50, 0xffff, v50                             // 000000B5E6A0: 366464FF 0000FFFF
	v_pk_fma_f16 v51, v51, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5E6A8: CC0E0033 0BFC1B33 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5E6B4: BF870194
	v_and_b32_e32 v54, 0xffff, v53                             // 000000B5E6B8: 366C6AFF 0000FFFF
	v_lshl_or_b32 v49, v49, 16, v50                            // 000000B5E6C0: D6560031 04C92131
	.long 0xd72c0032                                           // 000000B5E6C8: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000B5E6CC: 02026EFF 83DCD12D
	v_and_b32_e32 v53, 0xffff, v90                             // 000000B5E6D4: 366AB4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B5E6DC: BF870223
	v_pk_fma_f16 v52, v49, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5E6E0: CC0E0034 0BFC1B31 0000C931
	.long 0xd72c0031                                           // 000000B5E6EC: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000B5E6F0: 020270FF 83DCD12D
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000B5E6F8: D6220032 03FD0132 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5E704: BF870092
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000B5E708: D6220031 03FD0131 00006400
	v_and_b32_e32 v49, 0xffff, v49                             // 000000B5E714: 366262FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B5E71C: BF870121
	v_lshl_or_b32 v49, v50, 16, v49                            // 000000B5E720: D6560031 04C52132
	.long 0xd72c0032                                           // 000000B5E728: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000B5E72C: 02026AFF 83DCD12D
	v_pk_fma_f16 v55, v49, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5E734: CC0E0037 0BFC1B31 0000C931
	.long 0xd72c0031                                           // 000000B5E740: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000B5E744: 02026CFF 83DCD12D
	v_mov_b32_e32 v54, v52                                     // 000000B5E74C: 7E6C0334
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5E750: BF870214
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000B5E754: D6220032 03FD0132 00006400
	v_mov_b32_e32 v90, v55                                     // 000000B5E760: 7EB40337
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B5E764: BF8701A3
	v_permlanex16_b32 v54, v54, s21, 0xfedcba98                // 000000B5E768: D65C0036 03FC2B36 FEDCBA98
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000B5E774: D6220031 03FD0131 00006400
	v_permlanex16_b32 v90, v90, s21, 0xfedcba98                // 000000B5E780: D65C005A 03FC2B5A FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5E78C: BF870092
	v_and_b32_e32 v49, 0xffff, v49                             // 000000B5E790: 366262FF 0000FFFF
	v_lshl_or_b32 v49, v50, 16, v49                            // 000000B5E798: D6560031 04C52132
	v_mov_b32_e32 v50, v51                                     // 000000B5E7A0: 7E640333
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5E7A4: BF870112
	v_pk_fma_f16 v56, v49, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B5E7A8: CC0E0038 0BFC1B31 0000C931
	v_permlanex16_b32 v50, v50, s21, 0xfedcba98                // 000000B5E7B4: D65C0032 03FC2B32 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5E7C0: BF870112
	v_mov_b32_e32 v91, v56                                     // 000000B5E7C4: 7EB60338
	v_cndmask_b32_e64 v49, v50, v51, s3                        // 000000B5E7C8: D5010031 000E6732
	v_cndmask_b32_e64 v53, v51, v50, s3                        // 000000B5E7D0: D5010035 000E6533
	v_cndmask_b32_e64 v50, v54, v52, s3                        // 000000B5E7D8: D5010032 000E6936
	v_cndmask_b32_e64 v54, v52, v54, s3                        // 000000B5E7E0: D5010036 000E6D34
	v_permlanex16_b32 v91, v91, s21, 0xfedcba98                // 000000B5E7E8: D65C005B 03FC2B5B FEDCBA98
	v_cndmask_b32_e64 v51, v90, v55, s3                        // 000000B5E7F4: D5010033 000E6F5A
	v_cndmask_b32_e64 v55, v55, v90, s3                        // 000000B5E7FC: D5010037 000EB537
	s_delay_alu instid0(VALU_DEP_3)                            // 000000B5E804: BF870003
	v_cndmask_b32_e64 v52, v91, v56, s3                        // 000000B5E808: D5010034 000E715B
	v_cndmask_b32_e64 v56, v56, v91, s3                        // 000000B5E810: D5010038 000EB738
	ds_load_b128 v[90:93], v98                                 // 000000B5E818: DBFC0000 5A000062
	ds_load_b128 v[94:97], v98 offset:16                       // 000000B5E820: DBFC0010 5E000062
	s_waitcnt lgkmcnt(0)                                       // 000000B5E828: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[90:97], v[25:32]// 000000B5E82C: CC404019 1C66B531
	ds_load_b128 v[90:93], v98 offset:4352                     // 000000B5E834: DBFC1100 5A000062
	ds_load_b128 v[94:97], v98 offset:4368                     // 000000B5E83C: DBFC1110 5E000062
	s_waitcnt lgkmcnt(0)                                       // 000000B5E844: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[90:97], v[17:24]// 000000B5E848: CC404011 1C46B531
	ds_load_b128 v[90:93], v98 offset:8704                     // 000000B5E850: DBFC2200 5A000062
	ds_load_b128 v[94:97], v98 offset:8720                     // 000000B5E858: DBFC2210 5E000062
	s_waitcnt lgkmcnt(0)                                       // 000000B5E860: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[90:97], v[9:16]// 000000B5E864: CC404009 1C26B531
	ds_load_b128 v[90:93], v98 offset:13056                    // 000000B5E86C: DBFC3300 5A000062
	ds_load_b128 v[94:97], v98 offset:13072                    // 000000B5E874: DBFC3310 5E000062
	s_waitcnt lgkmcnt(0)                                       // 000000B5E87C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[49:56], v[90:97], v[1:8] // 000000B5E880: CC404001 1C06B531
	s_cbranch_vccnz 63858                                      // 000000B5E888: BFA4F972 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x554>
	s_and_b32 s27, s28, exec_lo                                // 000000B5E88C: 8B1B7E1C
	s_cselect_b32 s27, 0x4400, 0                               // 000000B5E890: 981B80FF 00004400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5E898: BF870099
	v_lshl_or_b32 v50, v59, 1, s27                             // 000000B5E89C: D6560032 006D033B
	v_lshl_add_u32 v49, v62, 1, v50                            // 000000B5E8A4: D6460031 04C9033E
	ds_store_b128 v49, v[33:36]                                // 000000B5E8AC: DB7C0000 00002131
	s_and_saveexec_b32 s27, s0                                 // 000000B5E8B4: BE9B2000
	s_cbranch_execnz 7                                         // 000000B5E8B8: BFA60007 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1fd8>
	s_or_b32 exec_lo, exec_lo, s27                             // 000000B5E8BC: 8C7E1B7E
	s_and_saveexec_b32 s27, s1                                 // 000000B5E8C0: BE9B2001
	s_cbranch_execnz 10                                        // 000000B5E8C4: BFA6000A <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1ff0>
	s_or_b32 exec_lo, exec_lo, s27                             // 000000B5E8C8: 8C7E1B7E
	s_and_saveexec_b32 s27, s2                                 // 000000B5E8CC: BE9B2002
	s_cbranch_execz 63839                                      // 000000B5E8D0: BFA5F95F <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x550>
	s_branch 11                                                // 000000B5E8D4: BFA0000B <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x2004>
	v_add_nc_u32_e32 v50, v50, v63                             // 000000B5E8D8: 4A647F32
	ds_store_b128 v50, v[37:40]                                // 000000B5E8DC: DB7C0000 00002532
	s_or_b32 exec_lo, exec_lo, s27                             // 000000B5E8E4: 8C7E1B7E
	s_and_saveexec_b32 s27, s1                                 // 000000B5E8E8: BE9B2001
	s_cbranch_execz 65526                                      // 000000B5E8EC: BFA5FFF6 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1fc8>
	ds_store_b128 v49, v[41:44] offset:8704                    // 000000B5E8F0: DB7C2200 00002931
	s_or_b32 exec_lo, exec_lo, s27                             // 000000B5E8F8: 8C7E1B7E
	s_and_saveexec_b32 s27, s2                                 // 000000B5E8FC: BE9B2002
	s_cbranch_execz 63827                                      // 000000B5E900: BFA5F953 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x550>
	ds_store_b128 v49, v[45:48] offset:13056                   // 000000B5E904: DB7C3300 00002D31
	s_branch 63824                                             // 000000B5E90C: BFA0F950 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x550>
	s_mul_i32 s0, s16, 0x1400                                  // 000000B5E910: 9600FF10 00001400
	s_mul_hi_i32 s1, s16, 0x1400                               // 000000B5E918: 9701FF10 00001400
	s_add_u32 s2, s14, s0                                      // 000000B5E920: 8002000E
	s_addc_u32 s3, s15, s1                                     // 000000B5E924: 8203010F
	s_lshl_b32 s0, s17, 7                                      // 000000B5E928: 84008711
	v_and_b32_e32 v34, 1, v0                                   // 000000B5E92C: 36440081
	s_ashr_i32 s1, s0, 31                                      // 000000B5E930: 86019F00
	v_and_b32_e32 v35, 2, v0                                   // 000000B5E934: 36460082
	s_lshl_b64 s[4:5], s[0:1], 1                               // 000000B5E938: 84848100
	v_lshrrev_b32_e32 v38, 2, v60                              // 000000B5E93C: 324C7882
	s_add_u32 s12, s2, s4                                      // 000000B5E940: 800C0402
	s_addc_u32 s13, s3, s5                                     // 000000B5E944: 820D0503
	.long 0xd44a0003                                           // 000000B5E948: D44A0003
	v_cndmask_b32_e32 v1, 0, v34, vcc_lo                       // 000000B5E94C: 02024480
	v_lshlrev_b32_e32 v34, 6, v58                              // 000000B5E950: 30447486
	.long 0xd44a0002                                           // 000000B5E954: D44A0002
	v_cndmask_b32_e32 v1, 0, v35, vcc_lo                       // 000000B5E958: 02024680
	v_and_b32_e32 v35, 4, v0                                   // 000000B5E95C: 36460084
	v_and_b32_e32 v36, 8, v0                                   // 000000B5E960: 36480088
	v_lshlrev_b32_e32 v33, 2, v60                              // 000000B5E964: 30427882
	v_mad_u32_u24 v34, 0x210, v61, v34                         // 000000B5E968: D60B0022 048A7AFF 00000210
	v_and_b32_e32 v37, 16, v0                                  // 000000B5E974: 364A0090
	.long 0xd44a0001                                           // 000000B5E978: D44A0001
	v_cndmask_b32_e32 v1, 0, v35, vcc_lo                       // 000000B5E97C: 02024680
	v_lshlrev_b32_e32 v35, 3, v60                              // 000000B5E980: 30467883
	.long 0xd44a0000                                           // 000000B5E984: D44A0000
	v_cndmask_b32_e32 v1, 0, v36, vcc_lo                       // 000000B5E988: 02024880
	v_and_or_b32 v34, v38, 4, v34                              // 000000B5E98C: D6570022 04890926
	v_cmp_eq_u32_e32 vcc_lo, 0, v37                            // 000000B5E994: 7C944A80
	ds_store_2addr_b32 v34, v25, v26 offset1:2                 // 000000B5E998: D8380200 001A1922
	ds_store_2addr_b32 v34, v27, v28 offset0:4 offset1:6       // 000000B5E9A0: D8380604 001C1B22
	ds_store_2addr_b32 v34, v29, v30 offset0:8 offset1:10      // 000000B5E9A8: D8380A08 001E1D22
	.long 0xd7001523                                           // 000000B5E9B0: D7001523
	v_cndmask_b32_e32 v1, s6, v35, vcc_lo                      // 000000B5E9B4: 02024606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B5E9B8: BF8701A1
	v_add_co_ci_u32_e64 v36, null, s7, 0, s21                  // 000000B5E9BC: D5207C24 00550007
	v_mul_u32_u24_e32 v28, 0x210, v58                          // 000000B5E9C4: 163874FF 00000210
	.long 0xd7000419                                           // 000000B5E9CC: D7000419
	v_cndmask_b32_e32 v0, v35, v4, vcc_lo                      // 000000B5E9D0: 02000923
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B5E9D4: BF870001
	v_add_co_ci_u32_e64 v26, null, s5, v36, s4                 // 000000B5E9D8: D5207C1A 00124805
	v_lshlrev_b32_e32 v27, 1, v33                              // 000000B5E9E0: 30364281
	s_mov_b32 s5, exec_lo                                      // 000000B5E9E4: BE85007E
	ds_store_2addr_b32 v34, v31, v32 offset0:12 offset1:14     // 000000B5E9E8: D8380E0C 00201F22
	s_waitcnt lgkmcnt(0)                                       // 000000B5E9F0: BF89FC07
	s_barrier                                                  // 000000B5E9F4: BFBD0000
	buffer_gl0_inv                                             // 000000B5E9F8: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000B5EA00: D4C4007E
	v_cndmask_b32_e32 v1, s19, v58, vcc_lo                     // 000000B5EA04: 02027413
	s_cbranch_execz 201                                        // 000000B5EA08: BFA500C9 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x2430>
	global_load_b64 v[35:36], v27, s[12:13]                    // 000000B5EA0C: DC560000 230C001B
	v_lshl_add_u32 v29, v33, 2, v28                            // 000000B5EA14: D646001D 04710521
	s_mov_b32 s4, 0x76543210                                   // 000000B5EA1C: BE8400FF 76543210
	ds_load_b128 v[29:32], v29                                 // 000000B5EA24: DBFC0000 1D00001D
	s_waitcnt lgkmcnt(0)                                       // 000000B5EA2C: BF89FC07
	v_dual_add_f32 v37, v29, v30 :: v_dual_add_f32 v38, v31, v32// 000000B5EA30: C9083D1D 2526411F
	v_dual_sub_f32 v29, v29, v30 :: v_dual_sub_f32 v30, v31, v32// 000000B5EA38: C94A3D1D 1D1E411F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B5EA40: BF8701A2
	v_sub_f32_e32 v32, v37, v38                                // 000000B5EA44: 08404D25
	v_add_f32_e32 v31, v37, v38                                // 000000B5EA48: 063E4D25
	v_add_f32_e32 v37, v29, v30                                // 000000B5EA4C: 064A3D1D
	v_sub_f32_e32 v29, v29, v30                                // 000000B5EA50: 083A3D1D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000B5EA54: BF870004
	v_mov_b32_dpp v38, v32 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5EA58: 7E4C02FA FF016120
	v_cndmask_b32_e64 v32, -v32, v32, s3                       // 000000B5EA60: D5010020 200E4120
	v_mov_b32_dpp v30, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5EA68: 7E3C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000B5EA70: D501001F 200E3F1F
	v_mov_b32_dpp v39, v37 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5EA78: 7E4E02FA FF016125
	v_mov_b32_dpp v40, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5EA80: 7E5002FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s3                       // 000000B5EA88: D501001D 200E3B1D
	v_cndmask_b32_e64 v37, -v37, v37, s3                       // 000000B5EA90: D5010025 200E4B25
	v_add_f32_e32 v32, v32, v38                                // 000000B5EA98: 06404D20
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5EA9C: BF870193
	v_dual_add_f32 v30, v31, v30 :: v_dual_add_f32 v29, v29, v40// 000000B5EAA0: C9083D1F 1E1C511D
	v_add_f32_e32 v31, v37, v39                                // 000000B5EAA8: 063E4F25
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B5EAAC: BF870223
	v_mov_b32_dpp v37, v32 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5EAB0: 7E4A02FA FF016220
	v_cndmask_b32_e64 v32, -v32, v32, s2                       // 000000B5EAB8: D5010020 200A4120
	v_mov_b32_dpp v38, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5EAC0: 7E4C02FA FF01621E
	v_mov_b32_dpp v39, v29 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5EAC8: 7E4E02FA FF01621D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000B5EAD0: D501001D 200A3B1D
	v_cndmask_b32_e64 v30, -v30, v30, s2                       // 000000B5EAD8: D501001E 200A3D1E
	v_add_f32_e32 v32, v32, v37                                // 000000B5EAE0: 06404B20
	v_mov_b32_dpp v37, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5EAE4: 7E4A02FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000B5EAEC: D501001F 200A3F1F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5EAF4: BF870214
	v_dual_add_f32 v29, v29, v39 :: v_dual_add_f32 v30, v30, v38// 000000B5EAF8: C9084F1D 1D1E4D1E
	v_mov_b32_dpp v38, v32 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5EB00: 7E4C02FA FF016420
	v_cndmask_b32_e64 v32, -v32, v32, s1                       // 000000B5EB08: D5010020 20064120
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5EB10: BF870214
	v_add_f32_e32 v31, v31, v37                                // 000000B5EB14: 063E4B1F
	v_mov_b32_dpp v37, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5EB18: 7E4A02FA FF01641D
	v_cndmask_b32_e64 v29, -v29, v29, s1                       // 000000B5EB20: D501001D 20063B1D
	v_mov_b32_dpp v39, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5EB28: 7E4E02FA FF01641E
	v_add_f32_e32 v32, v32, v38                                // 000000B5EB30: 06404D20
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000B5EB34: D501001E 20063D1E
	v_mov_b32_dpp v38, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5EB3C: 7E4C02FA FF01641F
	v_add_f32_e32 v29, v29, v37                                // 000000B5EB44: 063A4B1D
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000B5EB48: D501001F 20063F1F
	v_mov_b32_dpp v37, v32 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5EB50: 7E4A02FA FF016820
	v_cndmask_b32_e64 v32, -v32, v32, s0                       // 000000B5EB58: D5010020 20024120
	v_add_f32_e32 v30, v30, v39                                // 000000B5EB60: 063C4F1E
	v_mov_b32_dpp v39, v29 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5EB64: 7E4E02FA FF01681D
	v_cndmask_b32_e64 v29, -v29, v29, s0                       // 000000B5EB6C: D501001D 20023B1D
	.long 0x7f503880                                           // 000000B5EB74: 7F503880
	v_dual_add_f32 v32, v32, v37 :: v_dual_add_f32 v31, v31, v38// 000000B5EB78: C9084B20 201E4D1F
	v_mov_b32_dpp v37, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5EB80: 7E4A02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s0                       // 000000B5EB88: D501001E 20023D1E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000B5EB90: BF870003
	v_dual_add_f32 v29, v29, v39 :: v_dual_mov_b32 v38, v32    // 000000B5EB94: C9104F1D 1D260120
	v_cndmask_b32_e64 v32, -v32, v32, vcc_lo                   // 000000B5EB9C: D5010020 21AA4120
	v_mov_b32_dpp v39, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5EBA4: 7E4E02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s0                       // 000000B5EBAC: D501001F 20023F1F
	v_add_f32_e32 v30, v30, v37                                // 000000B5EBB4: 063C4B1E
	v_permlanex16_b32 v38, v38, s4, 0xfedcba98                 // 000000B5EBB8: D65C0026 03FC0926 FEDCBA98
	v_mov_b32_e32 v41, v29                                     // 000000B5EBC4: 7E52031D
	v_cndmask_b32_e64 v29, -v29, v29, vcc_lo                   // 000000B5EBC8: D501001D 21AA3B1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5EBD0: BF870193
	v_dual_add_f32 v32, v32, v38 :: v_dual_add_f32 v31, v31, v39// 000000B5EBD4: C9084D20 201E4F1F
	v_permlanex16_b32 v41, v41, s4, 0xfedcba98                 // 000000B5EBDC: D65C0029 03FC0929 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5EBE8: BF870192
	v_dual_mul_f32 v32, 0x3db504f3, v32 :: v_dual_mov_b32 v37, v30// 000000B5EBEC: C8D040FF 2024011E 3DB504F3
	v_mov_b32_e32 v38, v31                                     // 000000B5EBF8: 7E4C031F
	v_cndmask_b32_e64 v30, -v30, v30, vcc_lo                   // 000000B5EBFC: D501001E 21AA3D1E
	v_cndmask_b32_e64 v31, -v31, v31, vcc_lo                   // 000000B5EC04: D501001F 21AA3F1F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5EC0C: BF870214
	v_permlanex16_b32 v37, v37, s4, 0xfedcba98                 // 000000B5EC10: D65C0025 03FC0925 FEDCBA98
	v_permlanex16_b32 v38, v38, s4, 0xfedcba98                 // 000000B5EC1C: D65C0026 03FC0926 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B5EC28: BF870121
	v_dual_add_f32 v30, v30, v37 :: v_dual_add_f32 v31, v31, v38// 000000B5EC2C: C9084B1E 1E1E4D1F
	.long 0x7f4a39a8                                           // 000000B5EC34: 7F4A39A8
	v_dual_add_f32 v29, v29, v41 :: v_dual_mul_f32 v30, 0x3db504f3, v30// 000000B5EC38: C906531D 1D1E3CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5EC44: BF870113
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 000000B5EC48: 103E3EFF 3DB504F3
	v_mul_f32_e32 v29, 0x3db504f3, v29                         // 000000B5EC50: 103A3AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B5EC58: BF8903F7
	v_fma_mix_f32 v32, v36, v32, neg(0) op_sel_hi:[1,0,0]      // 000000B5EC5C: CC200020 8A024124
	v_fma_mix_f32 v30, v35, v30, neg(0) op_sel_hi:[1,0,0]      // 000000B5EC64: CC20001E 8A023D23
	v_fma_mix_f32 v31, v35, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B5EC6C: CC20081F 8A023F23
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5EC74: BF870113
	.long 0x7e4a39a0                                           // 000000B5EC78: 7E4A39A0
	v_bfe_u32 v38, v31, 16, 1                                  // 000000B5EC7C: D6100026 0205211F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5EC84: BF870112
	v_and_b32_e32 v37, 1, v37                                  // 000000B5EC88: 364A4A81
	v_add3_u32 v31, v31, v38, 0x7fff                           // 000000B5EC8C: D655001F 03FE4D1F 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B5EC98: BF870122
	v_add3_u32 v32, v32, v37, 0x7fff                           // 000000B5EC9C: D6550020 03FE4B20 00007FFF
	.long 0x7f4a39a8                                           // 000000B5ECA8: 7F4A39A8
	.long 0x7e4a39a0                                           // 000000B5ECAC: 7E4A39A0
	v_add_nc_u32_e32 v32, s18, v58                             // 000000B5ECB0: 4A407412
	v_fma_mix_f32 v29, v36, v29, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B5ECB4: CC20081D 8A023B24
	.long 0x7f4839a8                                           // 000000B5ECBC: 7F4839A8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5ECC0: BF870092
	.long 0x7e48399d                                           // 000000B5ECC4: 7E48399D
	v_and_b32_e32 v35, 1, v36                                  // 000000B5ECC8: 36464881
	v_bfe_u32 v36, v30, 16, 1                                  // 000000B5ECCC: D6100024 0205211E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5ECD4: BF870112
	v_add3_u32 v29, v29, v35, 0x7fff                           // 000000B5ECD8: D655001D 03FE471D 00007FFF
	v_add3_u32 v30, v30, v36, 0x7fff                           // 000000B5ECE4: D655001E 03FE491E 00007FFF
	v_and_b32_e32 v36, 0xffff, v37                             // 000000B5ECF0: 36484AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5ECF8: BF870193
	v_and_b32_e32 v35, 0xffff0000, v29                         // 000000B5ECFC: 36463AFF FFFF0000
	.long 0x7e50399e                                           // 000000B5ED04: 7E50399E
	v_mad_i64_i32 v[29:30], null, 0x1400, v32, v[25:26]        // 000000B5ED08: D6FF7C1D 046640FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5ED14: BF870193
	v_or_b32_e32 v32, v35, v36                                 // 000000B5ED18: 38404923
	v_and_or_b32 v31, 0xffff0000, v31, v40                     // 000000B5ED1C: D657001F 04A23EFF FFFF0000
	global_store_b64 v[29:30], v[31:32], off                   // 000000B5ED28: DC6E0000 007C1F1D
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B5ED30: 8C7E057E
	v_or_b32_e32 v30, 8, v58                                   // 000000B5ED34: 383C7488
	s_mov_b32 s5, exec_lo                                      // 000000B5ED38: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B5ED3C: BF870001
	v_mul_u32_u24_e32 v29, 0x210, v30                          // 000000B5ED40: 163A3CFF 00000210
	.long 0xd4c4007e                                           // 000000B5ED48: D4C4007E
	v_cndmask_b32_e32 v1, s19, v30, vcc_lo                     // 000000B5ED4C: 02023C13
	s_cbranch_execz 199                                        // 000000B5ED50: BFA500C7 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x2770>
	global_load_b64 v[31:32], v27, s[12:13]                    // 000000B5ED54: DC560000 1F0C001B
	v_lshl_add_u32 v35, v33, 2, v29                            // 000000B5ED5C: D6460023 04750521
	s_mov_b32 s4, 0x76543210                                   // 000000B5ED64: BE8400FF 76543210
	v_add_nc_u32_e32 v30, s18, v30                             // 000000B5ED6C: 4A3C3C12
	ds_load_b128 v[35:38], v35                                 // 000000B5ED70: DBFC0000 23000023
	s_waitcnt lgkmcnt(0)                                       // 000000B5ED78: BF89FC07
	v_dual_add_f32 v39, v35, v36 :: v_dual_add_f32 v40, v37, v38// 000000B5ED7C: C9084923 27284D25
	v_dual_sub_f32 v35, v35, v36 :: v_dual_sub_f32 v36, v37, v38// 000000B5ED84: C94A4923 23244D25
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B5ED8C: BF8701A2
	v_sub_f32_e32 v38, v39, v40                                // 000000B5ED90: 084C5127
	v_add_f32_e32 v37, v39, v40                                // 000000B5ED94: 064A5127
	v_add_f32_e32 v39, v35, v36                                // 000000B5ED98: 064E4923
	v_sub_f32_e32 v35, v35, v36                                // 000000B5ED9C: 08464923
	s_delay_alu instid0(VALU_DEP_4)                            // 000000B5EDA0: BF870004
	v_mov_b32_dpp v40, v38 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5EDA4: 7E5002FA FF016126
	v_cndmask_b32_e64 v38, -v38, v38, s3                       // 000000B5EDAC: D5010026 200E4D26
	v_mov_b32_dpp v36, v37 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5EDB4: 7E4802FA FF016125
	v_cndmask_b32_e64 v37, -v37, v37, s3                       // 000000B5EDBC: D5010025 200E4B25
	v_mov_b32_dpp v41, v39 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5EDC4: 7E5202FA FF016127
	v_mov_b32_dpp v42, v35 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5EDCC: 7E5402FA FF016123
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000B5EDD4: D5010023 200E4723
	v_cndmask_b32_e64 v39, -v39, v39, s3                       // 000000B5EDDC: D5010027 200E4F27
	v_add_f32_e32 v38, v38, v40                                // 000000B5EDE4: 064C5126
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5EDE8: BF870193
	v_dual_add_f32 v36, v37, v36 :: v_dual_add_f32 v35, v35, v42// 000000B5EDEC: C9084925 24225523
	v_add_f32_e32 v37, v39, v41                                // 000000B5EDF4: 064A5327
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B5EDF8: BF870223
	v_mov_b32_dpp v39, v38 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5EDFC: 7E4E02FA FF016226
	v_cndmask_b32_e64 v38, -v38, v38, s2                       // 000000B5EE04: D5010026 200A4D26
	v_mov_b32_dpp v40, v36 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5EE0C: 7E5002FA FF016224
	v_mov_b32_dpp v41, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5EE14: 7E5202FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s2                       // 000000B5EE1C: D5010023 200A4723
	v_cndmask_b32_e64 v36, -v36, v36, s2                       // 000000B5EE24: D5010024 200A4924
	v_add_f32_e32 v38, v38, v39                                // 000000B5EE2C: 064C4F26
	v_mov_b32_dpp v39, v37 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5EE30: 7E4E02FA FF016225
	v_cndmask_b32_e64 v37, -v37, v37, s2                       // 000000B5EE38: D5010025 200A4B25
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5EE40: BF870214
	v_dual_add_f32 v35, v35, v41 :: v_dual_add_f32 v36, v36, v40// 000000B5EE44: C9085323 23245124
	v_mov_b32_dpp v40, v38 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5EE4C: 7E5002FA FF016426
	v_cndmask_b32_e64 v38, -v38, v38, s1                       // 000000B5EE54: D5010026 20064D26
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5EE5C: BF870214
	v_add_f32_e32 v37, v37, v39                                // 000000B5EE60: 064A4F25
	v_mov_b32_dpp v39, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5EE64: 7E4E02FA FF016423
	v_cndmask_b32_e64 v35, -v35, v35, s1                       // 000000B5EE6C: D5010023 20064723
	v_mov_b32_dpp v41, v36 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5EE74: 7E5202FA FF016424
	v_add_f32_e32 v38, v38, v40                                // 000000B5EE7C: 064C5126
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 000000B5EE80: D5010024 20064924
	v_mov_b32_dpp v40, v37 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5EE88: 7E5002FA FF016425
	v_add_f32_e32 v35, v35, v39                                // 000000B5EE90: 06464F23
	v_cndmask_b32_e64 v37, -v37, v37, s1                       // 000000B5EE94: D5010025 20064B25
	v_mov_b32_dpp v39, v38 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5EE9C: 7E4E02FA FF016826
	v_cndmask_b32_e64 v38, -v38, v38, s0                       // 000000B5EEA4: D5010026 20024D26
	v_add_f32_e32 v36, v36, v41                                // 000000B5EEAC: 06485324
	v_mov_b32_dpp v41, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5EEB0: 7E5202FA FF016823
	v_cndmask_b32_e64 v35, -v35, v35, s0                       // 000000B5EEB8: D5010023 20024723
	.long 0x7f543880                                           // 000000B5EEC0: 7F543880
	v_dual_add_f32 v38, v38, v39 :: v_dual_add_f32 v37, v37, v40// 000000B5EEC4: C9084F26 26245125
	v_mov_b32_dpp v39, v36 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5EECC: 7E4E02FA FF016824
	v_cndmask_b32_e64 v36, -v36, v36, s0                       // 000000B5EED4: D5010024 20024924
	s_delay_alu instid0(VALU_DEP_3)                            // 000000B5EEDC: BF870003
	v_dual_add_f32 v35, v35, v41 :: v_dual_mov_b32 v40, v38    // 000000B5EEE0: C9105323 23280126
	v_cndmask_b32_e64 v38, -v38, v38, vcc_lo                   // 000000B5EEE8: D5010026 21AA4D26
	v_mov_b32_dpp v41, v37 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5EEF0: 7E5202FA FF016825
	v_cndmask_b32_e64 v37, -v37, v37, s0                       // 000000B5EEF8: D5010025 20024B25
	v_add_f32_e32 v36, v36, v39                                // 000000B5EF00: 06484F24
	v_permlanex16_b32 v40, v40, s4, 0xfedcba98                 // 000000B5EF04: D65C0028 03FC0928 FEDCBA98
	v_mov_b32_e32 v43, v35                                     // 000000B5EF10: 7E560323
	v_cndmask_b32_e64 v35, -v35, v35, vcc_lo                   // 000000B5EF14: D5010023 21AA4723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5EF1C: BF870193
	v_dual_add_f32 v38, v38, v40 :: v_dual_add_f32 v37, v37, v41// 000000B5EF20: C9085126 26245325
	v_permlanex16_b32 v43, v43, s4, 0xfedcba98                 // 000000B5EF28: D65C002B 03FC092B FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5EF34: BF870192
	v_dual_mul_f32 v38, 0x3db504f3, v38 :: v_dual_mov_b32 v39, v36// 000000B5EF38: C8D04CFF 26260124 3DB504F3
	v_mov_b32_e32 v40, v37                                     // 000000B5EF44: 7E500325
	v_cndmask_b32_e64 v36, -v36, v36, vcc_lo                   // 000000B5EF48: D5010024 21AA4924
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B5EF50: BF870244
	v_add_f32_e32 v35, v35, v43                                // 000000B5EF54: 06465723
	v_cndmask_b32_e64 v37, -v37, v37, vcc_lo                   // 000000B5EF58: D5010025 21AA4B25
	v_permlanex16_b32 v39, v39, s4, 0xfedcba98                 // 000000B5EF60: D65C0027 03FC0927 FEDCBA98
	v_permlanex16_b32 v40, v40, s4, 0xfedcba98                 // 000000B5EF6C: D65C0028 03FC0928 FEDCBA98
	v_mul_f32_e32 v35, 0x3db504f3, v35                         // 000000B5EF78: 104646FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B5EF80: BF870122
	v_dual_add_f32 v36, v36, v39 :: v_dual_add_f32 v37, v37, v40// 000000B5EF84: C9084F24 24245125
	.long 0x7f4e39aa                                           // 000000B5EF8C: 7F4E39AA
	v_mul_f32_e32 v37, 0x3db504f3, v37                         // 000000B5EF90: 104A4AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B5EF98: BF8903F7
	v_fma_mix_f32 v38, v32, v38, neg(0) op_sel_hi:[1,0,0]      // 000000B5EF9C: CC200026 8A024D20
	v_fma_mix_f32 v32, v32, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B5EFA4: CC200820 8A024720
	v_mul_f32_e32 v35, 0x3db504f3, v36                         // 000000B5EFAC: 104648FF 3DB504F3
	.long 0x7f4839aa                                           // 000000B5EFB4: 7F4839AA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5EFB8: BF870214
	.long 0x7e4e39a6                                           // 000000B5EFBC: 7E4E39A6
	.long 0x7e4839a0                                           // 000000B5EFC0: 7E4839A0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B5EFC4: BF870224
	v_fma_mix_f32 v35, v31, v35, neg(0) op_sel_hi:[1,0,0]      // 000000B5EFC8: CC200023 8A02471F
	v_fma_mix_f32 v31, v31, v37, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B5EFD0: CC20081F 8A024B1F
	v_and_b32_e32 v39, 1, v39                                  // 000000B5EFD8: 364E4E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5EFDC: BF870194
	v_and_b32_e32 v36, 1, v36                                  // 000000B5EFE0: 36484881
	v_bfe_u32 v40, v31, 16, 1                                  // 000000B5EFE4: D6100028 0205211F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B5EFEC: BF870243
	v_add3_u32 v37, v38, v39, 0x7fff                           // 000000B5EFF0: D6550025 03FE4F26 00007FFF
	v_bfe_u32 v38, v35, 16, 1                                  // 000000B5EFFC: D6100026 02052123
	.long 0x7f4e39aa                                           // 000000B5F004: 7F4E39AA
	v_add3_u32 v32, v32, v36, 0x7fff                           // 000000B5F008: D6550020 03FE4920 00007FFF
	.long 0x7e4e39a5                                           // 000000B5F014: 7E4E39A5
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B5F018: BF870224
	v_add3_u32 v35, v35, v38, 0x7fff                           // 000000B5F01C: D6550023 03FE4D23 00007FFF
	v_add3_u32 v37, v31, v40, 0x7fff                           // 000000B5F028: D6550025 03FE511F 00007FFF
	v_and_b32_e32 v32, 0xffff0000, v32                         // 000000B5F034: 364040FF FFFF0000
	v_mad_i64_i32 v[30:31], null, 0x1400, v30, v[25:26]        // 000000B5F03C: D6FF7C1E 04663CFF 00001400
	v_and_b32_e32 v36, 0xffff, v39                             // 000000B5F048: 36484EFF 0000FFFF
	.long 0x7e5439a3                                           // 000000B5F050: 7E5439A3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5F054: BF870112
	v_or_b32_e32 v36, v32, v36                                 // 000000B5F058: 38484920
	v_and_or_b32 v35, 0xffff0000, v37, v42                     // 000000B5F05C: D6570023 04AA4AFF FFFF0000
	global_store_b64 v[30:31], v[35:36], off                   // 000000B5F068: DC6E0000 007C231E
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B5F070: 8C7E057E
	v_or_b32_e32 v30, 16, v58                                  // 000000B5F074: 383C7490
	s_mov_b32 s5, exec_lo                                      // 000000B5F078: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000B5F07C: BC7C0000
	s_barrier                                                  // 000000B5F080: BFBD0000
	buffer_gl0_inv                                             // 000000B5F084: E0AC0000 00000000
	ds_store_2addr_b32 v34, v17, v18 offset1:2                 // 000000B5F08C: D8380200 00121122
	ds_store_2addr_b32 v34, v19, v20 offset0:4 offset1:6       // 000000B5F094: D8380604 00141322
	ds_store_2addr_b32 v34, v21, v22 offset0:8 offset1:10      // 000000B5F09C: D8380A08 00161522
	ds_store_2addr_b32 v34, v23, v24 offset0:12 offset1:14     // 000000B5F0A4: D8380E0C 00181722
	s_waitcnt lgkmcnt(0)                                       // 000000B5F0AC: BF89FC07
	s_barrier                                                  // 000000B5F0B0: BFBD0000
	buffer_gl0_inv                                             // 000000B5F0B4: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000B5F0BC: D4C4007E
	v_cndmask_b32_e32 v1, s19, v30, vcc_lo                     // 000000B5F0C0: 02023C13
	s_cbranch_execz 201                                        // 000000B5F0C4: BFA500C9 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x2aec>
	global_load_b64 v[21:22], v27, s[12:13]                    // 000000B5F0C8: DC560000 150C001B
	v_lshl_add_u32 v17, v33, 2, v28                            // 000000B5F0D0: D6460011 04710521
	s_mov_b32 s4, 0x76543210                                   // 000000B5F0D8: BE8400FF 76543210
	ds_load_b128 v[17:20], v17                                 // 000000B5F0E0: DBFC0000 11000011
	s_waitcnt lgkmcnt(0)                                       // 000000B5F0E8: BF89FC07
	v_dual_add_f32 v23, v17, v18 :: v_dual_add_f32 v24, v19, v20// 000000B5F0EC: C9082511 17182913
	v_dual_sub_f32 v17, v17, v18 :: v_dual_sub_f32 v18, v19, v20// 000000B5F0F4: C94A2511 11122913
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5F0FC: BF870112
	v_add_f32_e32 v19, v23, v24                                // 000000B5F100: 06263117
	v_dual_sub_f32 v20, v23, v24 :: v_dual_add_f32 v23, v17, v18// 000000B5F104: C9483117 14162511
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B5F10C: BF870001
	v_mov_b32_dpp v24, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5F110: 7E3002FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s3                       // 000000B5F118: D5010014 200E2914
	v_sub_f32_e32 v17, v17, v18                                // 000000B5F120: 08222511
	v_mov_b32_dpp v18, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5F124: 7E2402FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s3                       // 000000B5F12C: D5010013 200E2713
	v_mov_b32_dpp v31, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5F134: 7E3E02FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s3                       // 000000B5F13C: D5010017 200E2F17
	v_add_f32_e32 v20, v20, v24                                // 000000B5F144: 06283114
	v_mov_b32_dpp v32, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5F148: 7E4002FA FF016111
	v_cndmask_b32_e64 v17, -v17, v17, s3                       // 000000B5F150: D5010011 200E2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5F158: BF870091
	v_dual_add_f32 v18, v19, v18 :: v_dual_add_f32 v17, v17, v32// 000000B5F15C: C9082513 12104111
	v_mov_b32_dpp v24, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5F164: 7E3002FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000B5F16C: D5010012 200A2512
	v_add_f32_e32 v19, v23, v31                                // 000000B5F174: 06263F17
	v_mov_b32_dpp v23, v20 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5F178: 7E2E02FA FF016214
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000B5F180: D5010014 200A2914
	v_mov_b32_dpp v31, v17 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5F188: 7E3E02FA FF016211
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000B5F190: D5010011 200A2311
	v_add_f32_e32 v18, v18, v24                                // 000000B5F198: 06243112
	.long 0x7f403880                                           // 000000B5F19C: 7F403880
	v_add_f32_e32 v20, v20, v23                                // 000000B5F1A0: 06282F14
	v_mov_b32_dpp v23, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5F1A4: 7E2E02FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000B5F1AC: D5010013 200A2713
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B5F1B4: BF870233
	v_mov_b32_dpp v24, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5F1B8: 7E3002FA FF016414
	v_cndmask_b32_e64 v20, -v20, v20, s1                       // 000000B5F1C0: D5010014 20062914
	v_add_f32_e32 v17, v17, v31                                // 000000B5F1C8: 06223F11
	v_add_f32_e32 v19, v19, v23                                // 000000B5F1CC: 06262F13
	v_mov_b32_dpp v31, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5F1D0: 7E3E02FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000B5F1D8: D5010012 20062512
	v_add_f32_e32 v20, v20, v24                                // 000000B5F1E0: 06283114
	v_mov_b32_dpp v23, v17 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5F1E4: 7E2E02FA FF016411
	v_cndmask_b32_e64 v17, -v17, v17, s1                       // 000000B5F1EC: D5010011 20062311
	v_mov_b32_dpp v24, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5F1F4: 7E3002FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000B5F1FC: D5010013 20062713
	v_add_f32_e32 v18, v18, v31                                // 000000B5F204: 06243F12
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B5F208: BF8700B4
	v_add_f32_e32 v17, v17, v23                                // 000000B5F20C: 06222F11
	v_mov_b32_dpp v23, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5F210: 7E2E02FA FF016814
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000B5F218: D5010014 20022914
	v_dual_add_f32 v19, v19, v24 :: v_dual_add_f32 v20, v20, v23// 000000B5F220: C9083113 13142F14
	v_mov_b32_dpp v23, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5F228: 7E2E02FA FF016812
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000B5F230: D5010012 20022512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B5F238: BF870123
	v_mov_b32_e32 v24, v20                                     // 000000B5F23C: 7E300314
	v_cndmask_b32_e64 v20, -v20, v20, vcc_lo                   // 000000B5F240: D5010014 21AA2914
	v_permlanex16_b32 v24, v24, s4, 0xfedcba98                 // 000000B5F248: D65C0018 03FC0918 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B5F254: BF8700B1
	v_add_f32_e32 v20, v20, v24                                // 000000B5F258: 06283114
	v_mov_b32_dpp v31, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5F25C: 7E3E02FA FF016811
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 000000B5F264: D5010011 20022311
	v_dual_mul_f32 v20, 0x3db504f3, v20 :: v_dual_add_f32 v17, v17, v31// 000000B5F26C: C8C828FF 14103F11 3DB504F3
	v_mov_b32_dpp v31, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5F278: 7E3E02FA FF016813
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000B5F280: D5010013 20022713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5F288: BF870091
	v_add_f32_e32 v19, v19, v31                                // 000000B5F28C: 06263F13
	v_dual_mov_b32 v24, v19 :: v_dual_mov_b32 v35, v17         // 000000B5F290: CA100113 18220111
	v_cndmask_b32_e64 v17, -v17, v17, vcc_lo                   // 000000B5F298: D5010011 21AA2311
	v_cndmask_b32_e64 v19, -v19, v19, vcc_lo                   // 000000B5F2A0: D5010013 21AA2713
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5F2A8: BF870213
	v_permlanex16_b32 v24, v24, s4, 0xfedcba98                 // 000000B5F2AC: D65C0018 03FC0918 FEDCBA98
	v_permlanex16_b32 v35, v35, s4, 0xfedcba98                 // 000000B5F2B8: D65C0023 03FC0923 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5F2C4: BF870112
	v_add_f32_e32 v19, v19, v24                                // 000000B5F2C8: 06263113
	v_add_f32_e32 v17, v17, v35                                // 000000B5F2CC: 06224711
	v_add_f32_e32 v18, v18, v23                                // 000000B5F2D0: 06242F12
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5F2D4: BF870193
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 000000B5F2D8: 102626FF 3DB504F3
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 000000B5F2E0: 102222FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B5F2E8: BF870123
	v_mov_b32_e32 v23, v18                                     // 000000B5F2EC: 7E2E0312
	v_cndmask_b32_e64 v18, -v18, v18, vcc_lo                   // 000000B5F2F0: D5010012 21AA2512
	v_permlanex16_b32 v23, v23, s4, 0xfedcba98                 // 000000B5F2F8: D65C0017 03FC0917 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B5F304: BF870121
	v_add_f32_e32 v18, v18, v23                                // 000000B5F308: 06242F12
	.long 0x7f2e39a0                                           // 000000B5F30C: 7F2E39A0
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 000000B5F310: 102424FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B5F318: BF8903F7
	v_fma_mix_f32 v20, v22, v20, neg(0) op_sel_hi:[1,0,0]      // 000000B5F31C: CC200014 8A022916
	v_fma_mix_f32 v17, v22, v17, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B5F324: CC200811 8A022316
	.long 0x7f2c39a0                                           // 000000B5F32C: 7F2C39A0
	v_fma_mix_f32 v18, v21, v18, neg(0) op_sel_hi:[1,0,0]      // 000000B5F330: CC200012 8A022515
	v_fma_mix_f32 v19, v21, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B5F338: CC200813 8A022715
	.long 0x7e2e3994                                           // 000000B5F340: 7E2E3994
	.long 0x7e2c3991                                           // 000000B5F344: 7E2C3991
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5F348: BF870193
	v_bfe_u32 v24, v19, 16, 1                                  // 000000B5F34C: D6100018 02052113
	v_and_b32_e32 v23, 1, v23                                  // 000000B5F354: 362E2E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B5F358: BF870223
	v_and_b32_e32 v21, 1, v22                                  // 000000B5F35C: 362A2C81
	v_bfe_u32 v22, v18, 16, 1                                  // 000000B5F360: D6100016 02052112
	v_add3_u32 v19, v19, v24, 0x7fff                           // 000000B5F368: D6550013 03FE3113 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B5F374: BF870244
	v_add3_u32 v20, v20, v23, 0x7fff                           // 000000B5F378: D6550014 03FE2F14 00007FFF
	.long 0x7f2e39a0                                           // 000000B5F384: 7F2E39A0
	v_add3_u32 v17, v17, v21, 0x7fff                           // 000000B5F388: D6550011 03FE2B11 00007FFF
	v_add3_u32 v18, v18, v22, 0x7fff                           // 000000B5F394: D6550012 03FE2D12 00007FFF
	.long 0x7e2e3994                                           // 000000B5F3A0: 7E2E3994
	v_add_nc_u32_e32 v20, s18, v30                             // 000000B5F3A4: 4A283C12
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5F3A8: BF870214
	v_and_b32_e32 v21, 0xffff0000, v17                         // 000000B5F3AC: 362A22FF FFFF0000
	.long 0x7e403992                                           // 000000B5F3B4: 7E403992
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5F3B8: BF870214
	v_and_b32_e32 v22, 0xffff, v23                             // 000000B5F3BC: 362C2EFF 0000FFFF
	v_mad_i64_i32 v[17:18], null, 0x1400, v20, v[25:26]        // 000000B5F3C4: D6FF7C11 046628FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5F3D0: BF870193
	v_and_or_b32 v19, 0xffff0000, v19, v32                     // 000000B5F3D4: D6570013 048226FF FFFF0000
	v_or_b32_e32 v20, v21, v22                                 // 000000B5F3E0: 38282D15
	global_store_b64 v[17:18], v[19:20], off                   // 000000B5F3E4: DC6E0000 007C1311
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B5F3EC: 8C7E057E
	v_or_b32_e32 v17, 24, v58                                  // 000000B5F3F0: 38227498
	s_mov_b32 s5, exec_lo                                      // 000000B5F3F4: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B5F3F8: BF870001
	.long 0xd4c4007e                                           // 000000B5F3FC: D4C4007E
	v_cndmask_b32_e32 v1, s19, v17, vcc_lo                     // 000000B5F400: 02022213
	s_cbranch_execz 205                                        // 000000B5F404: BFA500CD <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x2e3c>
	global_load_b64 v[22:23], v27, s[12:13]                    // 000000B5F408: DC560000 160C001B
	v_lshl_add_u32 v18, v33, 2, v29                            // 000000B5F410: D6460012 04750521
	s_mov_b32 s4, 0x76543210                                   // 000000B5F418: BE8400FF 76543210
	v_add_nc_u32_e32 v17, s18, v17                             // 000000B5F420: 4A222212
	ds_load_b128 v[18:21], v18                                 // 000000B5F424: DBFC0000 12000012
	s_waitcnt lgkmcnt(0)                                       // 000000B5F42C: BF89FC07
	v_add_f32_e32 v24, v18, v19                                // 000000B5F430: 06302712
	v_add_f32_e32 v30, v20, v21                                // 000000B5F434: 063C2B14
	v_dual_sub_f32 v18, v18, v19 :: v_dual_sub_f32 v19, v20, v21// 000000B5F438: C94A2712 12122B14
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B5F440: BF8700A2
	v_add_f32_e32 v20, v24, v30                                // 000000B5F444: 06283D18
	v_sub_f32_e32 v21, v24, v30                                // 000000B5F448: 082A3D18
	v_mov_b32_dpp v30, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5F44C: 7E3C02FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000B5F454: D5010015 200E2B15
	v_add_f32_e32 v24, v18, v19                                // 000000B5F45C: 06302712
	v_sub_f32_e32 v18, v18, v19                                // 000000B5F460: 08242712
	v_mov_b32_dpp v19, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5F464: 7E2602FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s3                       // 000000B5F46C: D5010014 200E2914
	v_add_f32_e32 v21, v21, v30                                // 000000B5F474: 062A3D15
	v_mov_b32_dpp v31, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5F478: 7E3E02FA FF016118
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000B5F480: D5010018 200E3118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5F488: BF870114
	v_add_f32_e32 v19, v20, v19                                // 000000B5F48C: 06262714
	v_add_f32_e32 v20, v24, v31                                // 000000B5F490: 06283F18
	v_mov_b32_dpp v24, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5F494: 7E3002FA FF016215
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000B5F49C: BF870133
	v_mov_b32_dpp v30, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5F4A0: 7E3C02FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000B5F4A8: D5010013 200A2713
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000B5F4B0: D5010015 200A2B15
	v_add_f32_e32 v19, v19, v30                                // 000000B5F4B8: 06263D13
	v_mov_b32_dpp v32, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5F4BC: 7E4002FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000B5F4C4: D5010012 200E2512
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5F4CC: BF870114
	v_add_f32_e32 v21, v21, v24                                // 000000B5F4D0: 062A3115
	v_add_f32_e32 v18, v18, v32                                // 000000B5F4D4: 06244112
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B5F4D8: BF870232
	v_mov_b32_dpp v30, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5F4DC: 7E3C02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000B5F4E4: D5010015 20062B15
	.long 0x7f403880                                           // 000000B5F4EC: 7F403880
	v_mov_b32_dpp v31, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5F4F0: 7E3E02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000B5F4F8: D5010012 200A2512
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B5F500: BF870234
	v_add_f32_e32 v21, v21, v30                                // 000000B5F504: 062A3D15
	v_mov_b32_dpp v24, v20 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5F508: 7E3002FA FF016214
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000B5F510: D5010014 200A2914
	v_add_f32_e32 v18, v18, v31                                // 000000B5F518: 06243F12
	v_mov_b32_dpp v31, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5F51C: 7E3E02FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000B5F524: D5010013 20062713
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5F52C: BF870214
	v_add_f32_e32 v20, v20, v24                                // 000000B5F530: 06283114
	v_mov_b32_dpp v24, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5F534: 7E3002FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000B5F53C: D5010012 20062512
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B5F544: BF8701B1
	v_dual_add_f32 v19, v19, v31 :: v_dual_add_f32 v18, v18, v24// 000000B5F548: C9083F13 13123112
	v_mov_b32_dpp v24, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5F550: 7E3002FA FF016815
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000B5F558: D5010015 20022B15
	v_mov_b32_dpp v31, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5F560: 7E3E02FA FF016812
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000B5F568: D5010012 20022512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B5F570: BF8700B3
	v_add_f32_e32 v21, v21, v24                                // 000000B5F574: 062A3115
	v_mov_b32_dpp v24, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5F578: 7E3002FA FF016813
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000B5F580: D5010013 20022713
	v_dual_add_f32 v18, v18, v31 :: v_dual_add_f32 v19, v19, v24// 000000B5F588: C9083F12 12123113
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B5F590: BF870231
	v_mov_b32_e32 v35, v18                                     // 000000B5F594: 7E460312
	v_mov_b32_dpp v30, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5F598: 7E3C02FA FF016414
	v_cndmask_b32_e64 v20, -v20, v20, s1                       // 000000B5F5A0: D5010014 20062914
	v_mov_b32_e32 v24, v19                                     // 000000B5F5A8: 7E300313
	v_cndmask_b32_e64 v19, -v19, v19, vcc_lo                   // 000000B5F5AC: D5010013 21AA2713
	v_permlanex16_b32 v35, v35, s4, 0xfedcba98                 // 000000B5F5B4: D65C0023 03FC0923 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5F5C0: BF870214
	v_add_f32_e32 v20, v20, v30                                // 000000B5F5C4: 06283D14
	v_permlanex16_b32 v24, v24, s4, 0xfedcba98                 // 000000B5F5C8: D65C0018 03FC0918 FEDCBA98
	v_mov_b32_e32 v30, v21                                     // 000000B5F5D4: 7E3C0315
	v_cndmask_b32_e64 v21, -v21, v21, vcc_lo                   // 000000B5F5D8: D5010015 21AA2B15
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5F5E0: BF870214
	v_mov_b32_dpp v31, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5F5E4: 7E3E02FA FF016814
	v_add_f32_e32 v19, v19, v24                                // 000000B5F5EC: 06263113
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B5F5F0: BF870234
	v_permlanex16_b32 v30, v30, s4, 0xfedcba98                 // 000000B5F5F4: D65C001E 03FC091E FEDCBA98
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000B5F600: D5010014 20022914
	.long 0x7f3039a0                                           // 000000B5F608: 7F3039A0
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 000000B5F60C: 102626FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5F614: BF870093
	v_dual_add_f32 v21, v21, v30 :: v_dual_add_f32 v20, v20, v31// 000000B5F618: C9083D15 15143F14
	v_mul_f32_e32 v21, 0x3db504f3, v21                         // 000000B5F620: 102A2AFF 3DB504F3
	v_cndmask_b32_e64 v18, -v18, v18, vcc_lo                   // 000000B5F628: D5010012 21AA2512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B5F630: BF8701A3
	v_mov_b32_e32 v30, v20                                     // 000000B5F634: 7E3C0314
	v_cndmask_b32_e64 v20, -v20, v20, vcc_lo                   // 000000B5F638: D5010014 21AA2914
	v_add_f32_e32 v18, v18, v35                                // 000000B5F640: 06244712
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5F644: BF870113
	v_permlanex16_b32 v30, v30, s4, 0xfedcba98                 // 000000B5F648: D65C001E 03FC091E FEDCBA98
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 000000B5F654: 102424FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5F65C: BF870092
	v_add_f32_e32 v20, v20, v30                                // 000000B5F660: 06283D14
	v_mul_f32_e32 v20, 0x3db504f3, v20                         // 000000B5F664: 102828FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B5F66C: BF8903F7
	v_fma_mix_f32 v21, v23, v21, neg(0) op_sel_hi:[1,0,0]      // 000000B5F670: CC200015 8A022B17
	v_fma_mix_f32 v18, v23, v18, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B5F678: CC200812 8A022517
	.long 0x7f2e39a0                                           // 000000B5F680: 7F2E39A0
	v_fma_mix_f32 v19, v22, v19, neg(0) op_sel_hi:[1,0,0]      // 000000B5F684: CC200013 8A022716
	v_fma_mix_f32 v20, v22, v20, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B5F68C: CC200814 8A022916
	.long 0x7e303995                                           // 000000B5F694: 7E303995
	.long 0x7e2e3992                                           // 000000B5F698: 7E2E3992
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5F69C: BF870193
	v_bfe_u32 v30, v20, 16, 1                                  // 000000B5F6A0: D610001E 02052114
	v_and_b32_e32 v24, 1, v24                                  // 000000B5F6A8: 36303081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B5F6AC: BF8701A3
	v_and_b32_e32 v22, 1, v23                                  // 000000B5F6B0: 362C2E81
	v_bfe_u32 v23, v19, 16, 1                                  // 000000B5F6B4: D6100017 02052113
	v_add3_u32 v21, v21, v24, 0x7fff                           // 000000B5F6BC: D6550015 03FE3115 00007FFF
	.long 0x7f3039a0                                           // 000000B5F6C8: 7F3039A0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5F6CC: BF870214
	v_add3_u32 v18, v18, v22, 0x7fff                           // 000000B5F6D0: D6550012 03FE2D12 00007FFF
	v_add3_u32 v19, v19, v23, 0x7fff                           // 000000B5F6DC: D6550013 03FE2F13 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B5F6E8: BF870224
	.long 0x7e303995                                           // 000000B5F6EC: 7E303995
	v_add3_u32 v21, v20, v30, 0x7fff                           // 000000B5F6F0: D6550015 03FE3D14 00007FFF
	v_and_b32_e32 v20, 0xffff0000, v18                         // 000000B5F6FC: 362824FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B5F704: BF8701B4
	.long 0x7e403993                                           // 000000B5F708: 7E403993
	v_mad_i64_i32 v[17:18], null, 0x1400, v17, v[25:26]        // 000000B5F70C: D6FF7C11 046622FF 00001400
	v_and_b32_e32 v22, 0xffff, v24                             // 000000B5F718: 362C30FF 0000FFFF
	v_and_or_b32 v19, 0xffff0000, v21, v32                     // 000000B5F720: D6570013 04822AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000B5F72C: BF870002
	v_or_b32_e32 v20, v20, v22                                 // 000000B5F730: 38282D14
	global_store_b64 v[17:18], v[19:20], off                   // 000000B5F734: DC6E0000 007C1311
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B5F73C: 8C7E057E
	v_or_b32_e32 v17, 32, v58                                  // 000000B5F740: 382274A0
	s_mov_b32 s5, exec_lo                                      // 000000B5F744: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000B5F748: BC7C0000
	s_barrier                                                  // 000000B5F74C: BFBD0000
	buffer_gl0_inv                                             // 000000B5F750: E0AC0000 00000000
	ds_store_2addr_b32 v34, v9, v10 offset1:2                  // 000000B5F758: D8380200 000A0922
	ds_store_2addr_b32 v34, v11, v12 offset0:4 offset1:6       // 000000B5F760: D8380604 000C0B22
	ds_store_2addr_b32 v34, v13, v14 offset0:8 offset1:10      // 000000B5F768: D8380A08 000E0D22
	ds_store_2addr_b32 v34, v15, v16 offset0:12 offset1:14     // 000000B5F770: D8380E0C 00100F22
	s_waitcnt lgkmcnt(0)                                       // 000000B5F778: BF89FC07
	s_barrier                                                  // 000000B5F77C: BFBD0000
	buffer_gl0_inv                                             // 000000B5F780: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000B5F788: D4C4007E
	v_cndmask_b32_e32 v1, s19, v17, vcc_lo                     // 000000B5F78C: 02022213
	s_cbranch_execz 200                                        // 000000B5F790: BFA500C8 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x31b4>
	global_load_b64 v[13:14], v27, s[12:13]                    // 000000B5F794: DC560000 0D0C001B
	v_lshl_add_u32 v9, v33, 2, v28                             // 000000B5F79C: D6460009 04710521
	s_mov_b32 s4, 0x76543210                                   // 000000B5F7A4: BE8400FF 76543210
	ds_load_b128 v[9:12], v9                                   // 000000B5F7AC: DBFC0000 09000009
	s_waitcnt lgkmcnt(0)                                       // 000000B5F7B4: BF89FC07
	v_dual_add_f32 v15, v9, v10 :: v_dual_add_f32 v16, v11, v12// 000000B5F7B8: C9081509 0F10190B
	v_dual_sub_f32 v9, v9, v10 :: v_dual_sub_f32 v10, v11, v12 // 000000B5F7C0: C94A1509 090A190B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5F7C8: BF870112
	v_add_f32_e32 v11, v15, v16                                // 000000B5F7CC: 0616210F
	v_dual_sub_f32 v12, v15, v16 :: v_dual_add_f32 v15, v9, v10// 000000B5F7D0: C948210F 0C0E1509
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B5F7D8: BF870001
	v_mov_b32_dpp v16, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5F7DC: 7E2002FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000B5F7E4: D501000C 200E190C
	v_sub_f32_e32 v9, v9, v10                                  // 000000B5F7EC: 08121509
	v_mov_b32_dpp v10, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5F7F0: 7E1402FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000B5F7F8: D501000B 200E170B
	v_mov_b32_dpp v18, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5F800: 7E2402FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 000000B5F808: D501000F 200E1F0F
	v_add_f32_e32 v12, v12, v16                                // 000000B5F810: 0618210C
	v_mov_b32_dpp v19, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5F814: 7E2602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000B5F81C: D5010009 200E1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5F824: BF870091
	v_dual_add_f32 v10, v11, v10 :: v_dual_add_f32 v9, v9, v19 // 000000B5F828: C908150B 0A082709
	v_mov_b32_dpp v16, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5F830: 7E2002FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000B5F838: D501000A 200A150A
	v_add_f32_e32 v11, v15, v18                                // 000000B5F840: 0616250F
	v_mov_b32_dpp v15, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5F844: 7E1E02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000B5F84C: D501000C 200A190C
	v_mov_b32_dpp v18, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5F854: 7E2402FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000B5F85C: D5010009 200A1309
	v_add_f32_e32 v10, v10, v16                                // 000000B5F864: 0614210A
	.long 0x7f263880                                           // 000000B5F868: 7F263880
	v_add_f32_e32 v12, v12, v15                                // 000000B5F86C: 06181F0C
	v_mov_b32_dpp v15, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5F870: 7E1E02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000B5F878: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000B5F880: BF870253
	v_mov_b32_dpp v16, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5F884: 7E2002FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000B5F88C: D501000C 2006190C
	v_add_f32_e32 v9, v9, v18                                  // 000000B5F894: 06122509
	v_mov_b32_dpp v18, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5F898: 7E2402FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000B5F8A0: D501000A 2006150A
	v_dual_add_f32 v11, v11, v15 :: v_dual_add_f32 v12, v12, v16// 000000B5F8A8: C9081F0B 0B0C210C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B5F8B0: BF870224
	v_mov_b32_dpp v15, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5F8B4: 7E1E02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000B5F8BC: D5010009 20061309
	v_add_f32_e32 v10, v10, v18                                // 000000B5F8C4: 0614250A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B5F8C8: BF870224
	v_mov_b32_dpp v16, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5F8CC: 7E2002FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000B5F8D4: D501000B 2006170B
	v_add_f32_e32 v9, v9, v15                                  // 000000B5F8DC: 06121F09
	v_mov_b32_dpp v15, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5F8E0: 7E1E02FA FF01680C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000B5F8E8: D501000C 2002190C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B5F8F0: BF8701B1
	v_dual_add_f32 v11, v11, v16 :: v_dual_add_f32 v12, v12, v15// 000000B5F8F4: C908210B 0B0C1F0C
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5F8FC: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000B5F904: D501000A 2002150A
	v_mov_b32_e32 v16, v12                                     // 000000B5F90C: 7E20030C
	v_mov_b32_dpp v18, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5F910: 7E2402FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000B5F918: D5010009 20021309
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000B5F920: D501000C 21AA190C
	v_add_f32_e32 v10, v10, v15                                // 000000B5F928: 06141F0A
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000B5F92C: D65C0010 03FC0910 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B5F938: BF870234
	v_add_f32_e32 v9, v9, v18                                  // 000000B5F93C: 06122509
	v_mov_b32_dpp v18, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5F940: 7E2402FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000B5F948: D501000B 2002170B
	v_dual_add_f32 v12, v12, v16 :: v_dual_mov_b32 v15, v10    // 000000B5F950: C910210C 0C0E010A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B5F958: BF870224
	v_mov_b32_e32 v20, v9                                      // 000000B5F95C: 7E280309
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000B5F960: D5010009 21AA1309
	v_add_f32_e32 v11, v11, v18                                // 000000B5F968: 0616250B
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000B5F96C: D501000A 21AA150A
	v_permlanex16_b32 v15, v15, s4, 0xfedcba98                 // 000000B5F974: D65C000F 03FC090F FEDCBA98
	v_permlanex16_b32 v20, v20, s4, 0xfedcba98                 // 000000B5F980: D65C0014 03FC0914 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B5F98C: BF8701A4
	v_mov_b32_e32 v16, v11                                     // 000000B5F990: 7E20030B
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000B5F994: D501000B 21AA170B
	v_add_f32_e32 v9, v9, v20                                  // 000000B5F99C: 06122909
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000B5F9A0: 101818FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000B5F9A8: BF8701C4
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000B5F9AC: D65C0010 03FC0910 FEDCBA98
	v_add_f32_e32 v10, v10, v15                                // 000000B5F9B8: 06141F0A
	.long 0x7f1e3993                                           // 000000B5F9BC: 7F1E3993
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000B5F9C0: 101212FF 3DB504F3
	v_dual_add_f32 v11, v11, v16 :: v_dual_mul_f32 v10, 0x3db504f3, v10// 000000B5F9C8: C906210B 0B0A14FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B5F9D4: BF870001
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000B5F9D8: 101616FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B5F9E0: BF8903F7
	v_fma_mix_f32 v12, v14, v12, neg(0) op_sel_hi:[1,0,0]      // 000000B5F9E4: CC20000C 8A02190E
	v_fma_mix_f32 v9, v14, v9, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B5F9EC: CC200809 8A02130E
	.long 0x7f1c3993                                           // 000000B5F9F4: 7F1C3993
	v_fma_mix_f32 v10, v13, v10, neg(0) op_sel_hi:[1,0,0]      // 000000B5F9F8: CC20000A 8A02150D
	v_fma_mix_f32 v11, v13, v11, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B5FA00: CC20080B 8A02170D
	.long 0x7e1e398c                                           // 000000B5FA08: 7E1E398C
	.long 0x7e1c3989                                           // 000000B5FA0C: 7E1C3989
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5FA10: BF870193
	v_bfe_u32 v16, v11, 16, 1                                  // 000000B5FA14: D6100010 0205210B
	v_and_b32_e32 v15, 1, v15                                  // 000000B5FA1C: 361E1E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B5FA20: BF870223
	v_and_b32_e32 v13, 1, v14                                  // 000000B5FA24: 361A1C81
	v_bfe_u32 v14, v10, 16, 1                                  // 000000B5FA28: D610000E 0205210A
	v_add3_u32 v11, v11, v16, 0x7fff                           // 000000B5FA30: D655000B 03FE210B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B5FA3C: BF870244
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000B5FA40: D655000C 03FE1F0C 00007FFF
	.long 0x7f1e3993                                           // 000000B5FA4C: 7F1E3993
	v_add3_u32 v9, v9, v13, 0x7fff                             // 000000B5FA50: D6550009 03FE1B09 00007FFF
	v_add3_u32 v10, v10, v14, 0x7fff                           // 000000B5FA5C: D655000A 03FE1D0A 00007FFF
	.long 0x7e1e398c                                           // 000000B5FA68: 7E1E398C
	v_add_nc_u32_e32 v12, s18, v17                             // 000000B5FA6C: 4A182212
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5FA70: BF870214
	v_and_b32_e32 v13, 0xffff0000, v9                          // 000000B5FA74: 361A12FF FFFF0000
	.long 0x7e26398a                                           // 000000B5FA7C: 7E26398A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5FA80: BF870214
	v_and_b32_e32 v14, 0xffff, v15                             // 000000B5FA84: 361C1EFF 0000FFFF
	v_mad_i64_i32 v[9:10], null, 0x1400, v12, v[25:26]         // 000000B5FA8C: D6FF7C09 046618FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5FA98: BF870193
	v_and_or_b32 v11, 0xffff0000, v11, v19                     // 000000B5FA9C: D657000B 044E16FF FFFF0000
	v_or_b32_e32 v12, v13, v14                                 // 000000B5FAA8: 38181D0D
	global_store_b64 v[9:10], v[11:12], off                    // 000000B5FAAC: DC6E0000 007C0B09
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B5FAB4: 8C7E057E
	v_or_b32_e32 v9, 40, v58                                   // 000000B5FAB8: 381274A8
	s_mov_b32 s5, exec_lo                                      // 000000B5FABC: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B5FAC0: BF870001
	.long 0xd4c4007e                                           // 000000B5FAC4: D4C4007E
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 000000B5FAC8: 02021213
	s_cbranch_execz 202                                        // 000000B5FACC: BFA500CA <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x34f8>
	global_load_b64 v[14:15], v27, s[12:13]                    // 000000B5FAD0: DC560000 0E0C001B
	v_lshl_add_u32 v10, v33, 2, v29                            // 000000B5FAD8: D646000A 04750521
	s_mov_b32 s4, 0x76543210                                   // 000000B5FAE0: BE8400FF 76543210
	v_add_nc_u32_e32 v9, s18, v9                               // 000000B5FAE8: 4A121212
	ds_load_b128 v[10:13], v10                                 // 000000B5FAEC: DBFC0000 0A00000A
	s_waitcnt lgkmcnt(0)                                       // 000000B5FAF4: BF89FC07
	v_dual_add_f32 v16, v10, v11 :: v_dual_add_f32 v17, v12, v13// 000000B5FAF8: C908170A 10101B0C
	v_dual_sub_f32 v10, v10, v11 :: v_dual_sub_f32 v11, v12, v13// 000000B5FB00: C94A170A 0A0A1B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B5FB08: BF8701A2
	v_sub_f32_e32 v13, v16, v17                                // 000000B5FB0C: 081A2310
	v_add_f32_e32 v12, v16, v17                                // 000000B5FB10: 06182310
	v_add_f32_e32 v16, v10, v11                                // 000000B5FB14: 0620170A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000B5FB18: BF870003
	v_mov_b32_dpp v17, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5FB1C: 7E2202FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000B5FB24: D501000D 200E1B0D
	v_sub_f32_e32 v10, v10, v11                                // 000000B5FB2C: 0814170A
	v_mov_b32_dpp v11, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5FB30: 7E1602FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000B5FB38: D501000C 200E190C
	v_mov_b32_dpp v18, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5FB40: 7E2402FA FF016110
	v_add_f32_e32 v13, v13, v17                                // 000000B5FB48: 061A230D
	v_mov_b32_dpp v19, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5FB4C: 7E2602FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000B5FB54: D501000A 200E150A
	v_cndmask_b32_e64 v16, -v16, v16, s3                       // 000000B5FB5C: D5010010 200E2110
	v_add_f32_e32 v11, v12, v11                                // 000000B5FB64: 0616170C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5FB68: BF870193
	v_add_f32_e32 v10, v10, v19                                // 000000B5FB6C: 0614270A
	v_add_f32_e32 v12, v16, v18                                // 000000B5FB70: 06182510
	v_mov_b32_dpp v16, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5FB74: 7E2002FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000B5FB7C: D501000D 200A1B0D
	.long 0x7f263880                                           // 000000B5FB84: 7F263880
	v_mov_b32_dpp v18, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5FB88: 7E2402FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000B5FB90: D501000A 200A150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B5FB98: BF8700B1
	v_dual_add_f32 v13, v13, v16 :: v_dual_add_f32 v10, v10, v18// 000000B5FB9C: C908210D 0D0A250A
	v_mov_b32_dpp v17, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5FBA4: 7E2202FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000B5FBAC: D501000B 200A170B
	v_add_f32_e32 v11, v11, v17                                // 000000B5FBB4: 0616230B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B5FBB8: BF8701A4
	v_mov_b32_dpp v17, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5FBBC: 7E2202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000B5FBC4: D501000D 20061B0D
	v_mov_b32_dpp v18, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5FBCC: 7E2402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000B5FBD4: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B5FBDC: BF8700B3
	v_add_f32_e32 v13, v13, v17                                // 000000B5FBE0: 061A230D
	v_mov_b32_dpp v16, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5FBE4: 7E2002FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000B5FBEC: D501000C 200A190C
	v_dual_add_f32 v11, v11, v18 :: v_dual_add_f32 v12, v12, v16// 000000B5FBF4: C908250B 0B0C210C
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5FBFC: 7E2002FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000B5FC04: D501000A 2006150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B5FC0C: BF8701A3
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5FC10: 7E2202FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000B5FC18: D501000C 2006190C
	v_add_f32_e32 v10, v10, v16                                // 000000B5FC20: 0614210A
	v_mov_b32_dpp v16, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5FC24: 7E2002FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000B5FC2C: D501000D 20021B0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B5FC34: BF8701B1
	v_dual_add_f32 v12, v12, v17 :: v_dual_add_f32 v13, v13, v16// 000000B5FC38: C908230C 0C0C210D
	v_mov_b32_dpp v16, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5FC40: 7E2002FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000B5FC48: D501000B 2002170B
	v_mov_b32_e32 v17, v13                                     // 000000B5FC50: 7E22030D
	v_mov_b32_dpp v18, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5FC54: 7E2402FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000B5FC5C: D501000A 2002150A
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000B5FC64: D501000D 21AA1B0D
	v_add_f32_e32 v11, v11, v16                                // 000000B5FC6C: 0616210B
	v_permlanex16_b32 v17, v17, s4, 0xfedcba98                 // 000000B5FC70: D65C0011 03FC0911 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B5FC7C: BF8701B4
	v_add_f32_e32 v10, v10, v18                                // 000000B5FC80: 0614250A
	v_mov_b32_dpp v18, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5FC84: 7E2402FA FF01680C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000B5FC8C: D501000C 2002190C
	v_dual_add_f32 v13, v13, v17 :: v_dual_mov_b32 v20, v10    // 000000B5FC94: C910230D 0D14010A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000B5FC9C: D501000A 21AA150A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B5FCA4: BF870222
	v_dual_add_f32 v12, v12, v18 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 000000B5FCA8: C906250C 0C0C1AFF 3DB504F3
	v_mov_b32_e32 v16, v11                                     // 000000B5FCB4: 7E20030B
	v_permlanex16_b32 v20, v20, s4, 0xfedcba98                 // 000000B5FCB8: D65C0014 03FC0914 FEDCBA98
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000B5FCC4: D501000B 21AA170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B5FCCC: BF8701B4
	v_mov_b32_e32 v17, v12                                     // 000000B5FCD0: 7E22030C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000B5FCD4: D501000C 21AA190C
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000B5FCDC: D65C0010 03FC0910 FEDCBA98
	v_permlanex16_b32 v17, v17, s4, 0xfedcba98                 // 000000B5FCE8: D65C0011 03FC0911 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B5FCF4: BF8701A2
	v_add_f32_e32 v11, v11, v16                                // 000000B5FCF8: 0616210B
	.long 0x7f203993                                           // 000000B5FCFC: 7F203993
	v_add_f32_e32 v12, v12, v17                                // 000000B5FD00: 0618230C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5FD04: BF870113
	v_dual_add_f32 v10, v10, v20 :: v_dual_mul_f32 v11, 0x3db504f3, v11// 000000B5FD08: C906290A 0A0A16FF 3DB504F3
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000B5FD14: 101818FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000B5FD1C: BF870132
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000B5FD20: 101414FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B5FD28: BF8903F7
	v_fma_mix_f32 v13, v15, v13, neg(0) op_sel_hi:[1,0,0]      // 000000B5FD2C: CC20000D 8A021B0F
	v_fma_mix_f32 v10, v15, v10, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B5FD34: CC20080A 8A02150F
	.long 0x7f1e3993                                           // 000000B5FD3C: 7F1E3993
	v_fma_mix_f32 v11, v14, v11, neg(0) op_sel_hi:[1,0,0]      // 000000B5FD40: CC20000B 8A02170E
	v_fma_mix_f32 v12, v14, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B5FD48: CC20080C 8A02190E
	.long 0x7e20398d                                           // 000000B5FD50: 7E20398D
	.long 0x7e1e398a                                           // 000000B5FD54: 7E1E398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B5FD58: BF870193
	v_bfe_u32 v17, v12, 16, 1                                  // 000000B5FD5C: D6100011 0205210C
	v_and_b32_e32 v16, 1, v16                                  // 000000B5FD64: 36202081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B5FD68: BF8701A3
	v_and_b32_e32 v14, 1, v15                                  // 000000B5FD6C: 361C1E81
	v_bfe_u32 v15, v11, 16, 1                                  // 000000B5FD70: D610000F 0205210B
	v_add3_u32 v13, v13, v16, 0x7fff                           // 000000B5FD78: D655000D 03FE210D 00007FFF
	.long 0x7f203993                                           // 000000B5FD84: 7F203993
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B5FD88: BF870214
	v_add3_u32 v10, v10, v14, 0x7fff                           // 000000B5FD8C: D655000A 03FE1D0A 00007FFF
	v_add3_u32 v11, v11, v15, 0x7fff                           // 000000B5FD98: D655000B 03FE1F0B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B5FDA4: BF870224
	.long 0x7e20398d                                           // 000000B5FDA8: 7E20398D
	v_add3_u32 v13, v12, v17, 0x7fff                           // 000000B5FDAC: D655000D 03FE230C 00007FFF
	v_and_b32_e32 v12, 0xffff0000, v10                         // 000000B5FDB8: 361814FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B5FDC0: BF8701B4
	.long 0x7e26398b                                           // 000000B5FDC4: 7E26398B
	v_mad_i64_i32 v[9:10], null, 0x1400, v9, v[25:26]          // 000000B5FDC8: D6FF7C09 046612FF 00001400
	v_and_b32_e32 v14, 0xffff, v16                             // 000000B5FDD4: 361C20FF 0000FFFF
	v_and_or_b32 v11, 0xffff0000, v13, v19                     // 000000B5FDDC: D657000B 044E1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000B5FDE8: BF870002
	v_or_b32_e32 v12, v12, v14                                 // 000000B5FDEC: 38181D0C
	global_store_b64 v[9:10], v[11:12], off                    // 000000B5FDF0: DC6E0000 007C0B09
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B5FDF8: 8C7E057E
	v_or_b32_e32 v9, 48, v58                                   // 000000B5FDFC: 381274B0
	s_mov_b32 s5, exec_lo                                      // 000000B5FE00: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000B5FE04: BC7C0000
	s_barrier                                                  // 000000B5FE08: BFBD0000
	buffer_gl0_inv                                             // 000000B5FE0C: E0AC0000 00000000
	ds_store_2addr_b32 v34, v1, v2 offset1:2                   // 000000B5FE14: D8380200 00020122
	ds_store_2addr_b32 v34, v3, v4 offset0:4 offset1:6         // 000000B5FE1C: D8380604 00040322
	ds_store_2addr_b32 v34, v5, v6 offset0:8 offset1:10        // 000000B5FE24: D8380A08 00060522
	ds_store_2addr_b32 v34, v7, v8 offset0:12 offset1:14       // 000000B5FE2C: D8380E0C 00080722
	s_waitcnt lgkmcnt(0)                                       // 000000B5FE34: BF89FC07
	s_barrier                                                  // 000000B5FE38: BFBD0000
	buffer_gl0_inv                                             // 000000B5FE3C: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000B5FE44: D4C4007E
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 000000B5FE48: 02021213
	s_cbranch_execz 200                                        // 000000B5FE4C: BFA500C8 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3870>
	global_load_b64 v[5:6], v27, s[12:13]                      // 000000B5FE50: DC560000 050C001B
	v_lshl_add_u32 v1, v33, 2, v28                             // 000000B5FE58: D6460001 04710521
	s_mov_b32 s4, 0x76543210                                   // 000000B5FE60: BE8400FF 76543210
	ds_load_b128 v[1:4], v1                                    // 000000B5FE68: DBFC0000 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000B5FE70: BF89FC07
	v_dual_add_f32 v7, v1, v2 :: v_dual_add_f32 v8, v3, v4     // 000000B5FE74: C9080501 07080903
	v_dual_sub_f32 v1, v1, v2 :: v_dual_sub_f32 v2, v3, v4     // 000000B5FE7C: C94A0501 01020903
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B5FE84: BF870112
	v_add_f32_e32 v3, v7, v8                                   // 000000B5FE88: 06061107
	v_dual_sub_f32 v4, v7, v8 :: v_dual_add_f32 v7, v1, v2     // 000000B5FE8C: C9481107 04060501
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B5FE94: BF870001
	v_mov_b32_dpp v8, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5FE98: 7E1002FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000B5FEA0: D5010004 200E0904
	v_sub_f32_e32 v1, v1, v2                                   // 000000B5FEA8: 08020501
	v_mov_b32_dpp v2, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5FEAC: 7E0402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000B5FEB4: D5010003 200E0703
	v_mov_b32_dpp v10, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5FEBC: 7E1402FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000B5FEC4: D5010007 200E0F07
	v_add_f32_e32 v4, v4, v8                                   // 000000B5FECC: 06081104
	v_mov_b32_dpp v11, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B5FED0: 7E1602FA FF016101
	v_cndmask_b32_e64 v1, -v1, v1, s3                          // 000000B5FED8: D5010001 200E0301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B5FEE0: BF870091
	v_dual_add_f32 v2, v3, v2 :: v_dual_add_f32 v1, v1, v11    // 000000B5FEE4: C9080503 02001701
	v_mov_b32_dpp v8, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5FEEC: 7E1002FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000B5FEF4: D5010002 200A0502
	v_add_f32_e32 v3, v7, v10                                  // 000000B5FEFC: 06061507
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5FF00: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000B5FF08: D5010004 200A0904
	v_mov_b32_dpp v10, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5FF10: 7E1402FA FF016201
	v_cndmask_b32_e64 v1, -v1, v1, s2                          // 000000B5FF18: D5010001 200A0301
	v_add_f32_e32 v2, v2, v8                                   // 000000B5FF20: 06041102
	.long 0x7f163880                                           // 000000B5FF24: 7F163880
	v_add_f32_e32 v4, v4, v7                                   // 000000B5FF28: 06080F04
	v_mov_b32_dpp v7, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B5FF2C: 7E0E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000B5FF34: D5010003 200A0703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000B5FF3C: BF870253
	v_mov_b32_dpp v8, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5FF40: 7E1002FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000B5FF48: D5010004 20060904
	v_add_f32_e32 v1, v1, v10                                  // 000000B5FF50: 06021501
	v_mov_b32_dpp v10, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5FF54: 7E1402FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000B5FF5C: D5010002 20060502
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v4, v8     // 000000B5FF64: C9080F03 03041104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B5FF6C: BF870224
	v_mov_b32_dpp v7, v1 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5FF70: 7E0E02FA FF016401
	v_cndmask_b32_e64 v1, -v1, v1, s1                          // 000000B5FF78: D5010001 20060301
	v_add_f32_e32 v2, v2, v10                                  // 000000B5FF80: 06041502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B5FF84: BF870224
	v_mov_b32_dpp v8, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B5FF88: 7E1002FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000B5FF90: D5010003 20060703
	v_add_f32_e32 v1, v1, v7                                   // 000000B5FF98: 06020F01
	v_mov_b32_dpp v7, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5FF9C: 7E0E02FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000B5FFA4: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B5FFAC: BF8701B1
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v4, v4, v7     // 000000B5FFB0: C9081103 03040F04
	v_mov_b32_dpp v7, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5FFB8: 7E0E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000B5FFC0: D5010002 20020502
	v_mov_b32_e32 v8, v4                                       // 000000B5FFC8: 7E100304
	v_mov_b32_dpp v10, v1 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5FFCC: 7E1402FA FF016801
	v_cndmask_b32_e64 v1, -v1, v1, s0                          // 000000B5FFD4: D5010001 20020301
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000B5FFDC: D5010004 21AA0904
	v_add_f32_e32 v2, v2, v7                                   // 000000B5FFE4: 06040F02
	v_permlanex16_b32 v8, v8, s4, 0xfedcba98                   // 000000B5FFE8: D65C0008 03FC0908 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B5FFF4: BF870234
	v_add_f32_e32 v1, v1, v10                                  // 000000B5FFF8: 06021501
	v_mov_b32_dpp v10, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B5FFFC: 7E1402FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000B60004: D5010003 20020703
	v_dual_add_f32 v4, v4, v8 :: v_dual_mov_b32 v7, v2         // 000000B6000C: C9101104 04060102
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B60014: BF870224
	v_mov_b32_e32 v12, v1                                      // 000000B60018: 7E180301
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 000000B6001C: D5010001 21AA0301
	v_add_f32_e32 v3, v3, v10                                  // 000000B60024: 06061503
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000B60028: D5010002 21AA0502
	v_permlanex16_b32 v7, v7, s4, 0xfedcba98                   // 000000B60030: D65C0007 03FC0907 FEDCBA98
	v_permlanex16_b32 v12, v12, s4, 0xfedcba98                 // 000000B6003C: D65C000C 03FC090C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B60048: BF8701A4
	v_mov_b32_e32 v8, v3                                       // 000000B6004C: 7E100303
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000B60050: D5010003 21AA0703
	v_add_f32_e32 v1, v1, v12                                  // 000000B60058: 06021901
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000B6005C: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000B60064: BF8701C4
	v_permlanex16_b32 v8, v8, s4, 0xfedcba98                   // 000000B60068: D65C0008 03FC0908 FEDCBA98
	v_add_f32_e32 v2, v2, v7                                   // 000000B60074: 06040F02
	.long 0x7f0e398b                                           // 000000B60078: 7F0E398B
	v_mul_f32_e32 v1, 0x3db504f3, v1                           // 000000B6007C: 100202FF 3DB504F3
	v_dual_add_f32 v3, v3, v8 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 000000B60084: C9061103 030204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B60090: BF870001
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 000000B60094: 100606FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B6009C: BF8903F7
	v_fma_mix_f32 v4, v6, v4, neg(0) op_sel_hi:[1,0,0]         // 000000B600A0: CC200004 8A020906
	v_fma_mix_f32 v1, v6, v1, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B600A8: CC200801 8A020306
	.long 0x7f0c398b                                           // 000000B600B0: 7F0C398B
	v_fma_mix_f32 v2, v5, v2, neg(0) op_sel_hi:[1,0,0]         // 000000B600B4: CC200002 8A020505
	v_fma_mix_f32 v3, v5, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B600BC: CC200803 8A020705
	.long 0x7e0e3984                                           // 000000B600C4: 7E0E3984
	.long 0x7e0c3981                                           // 000000B600C8: 7E0C3981
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B600CC: BF870193
	v_bfe_u32 v8, v3, 16, 1                                    // 000000B600D0: D6100008 02052103
	v_and_b32_e32 v7, 1, v7                                    // 000000B600D8: 360E0E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B600DC: BF870223
	v_and_b32_e32 v5, 1, v6                                    // 000000B600E0: 360A0C81
	v_bfe_u32 v6, v2, 16, 1                                    // 000000B600E4: D6100006 02052102
	v_add3_u32 v3, v3, v8, 0x7fff                              // 000000B600EC: D6550003 03FE1103 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B600F8: BF870244
	v_add3_u32 v4, v4, v7, 0x7fff                              // 000000B600FC: D6550004 03FE0F04 00007FFF
	.long 0x7f0e398b                                           // 000000B60108: 7F0E398B
	v_add3_u32 v1, v1, v5, 0x7fff                              // 000000B6010C: D6550001 03FE0B01 00007FFF
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000B60118: D6550002 03FE0D02 00007FFF
	.long 0x7e0e3984                                           // 000000B60124: 7E0E3984
	v_add_nc_u32_e32 v4, s18, v9                               // 000000B60128: 4A081212
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B6012C: BF870214
	v_and_b32_e32 v5, 0xffff0000, v1                           // 000000B60130: 360A02FF FFFF0000
	.long 0x7e163982                                           // 000000B60138: 7E163982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B6013C: BF870214
	v_and_b32_e32 v6, 0xffff, v7                               // 000000B60140: 360C0EFF 0000FFFF
	v_mad_i64_i32 v[1:2], null, 0x1400, v4, v[25:26]           // 000000B60148: D6FF7C01 046608FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B60154: BF870193
	v_and_or_b32 v3, 0xffff0000, v3, v11                       // 000000B60158: D6570003 042E06FF FFFF0000
	v_or_b32_e32 v4, v5, v6                                    // 000000B60164: 38080D05
	global_store_b64 v[1:2], v[3:4], off                       // 000000B60168: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B60170: 8C7E057E
	v_or_b32_e32 v1, 56, v58                                   // 000000B60174: 380274B8
	s_mov_b32 s5, exec_lo                                      // 000000B60178: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B6017C: BF870001
	.long 0xd4c4007e                                           // 000000B60180: D4C4007E
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 000000B60184: 02020213
	s_cbranch_execz 202                                        // 000000B60188: BFA500CA <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3bb4>
	global_load_b64 v[6:7], v27, s[12:13]                      // 000000B6018C: DC560000 060C001B
	v_lshl_add_u32 v2, v33, 2, v29                             // 000000B60194: D6460002 04750521
	v_add_nc_u32_e32 v1, s18, v1                               // 000000B6019C: 4A020212
	ds_load_b128 v[2:5], v2                                    // 000000B601A0: DBFC0000 02000002
	s_waitcnt lgkmcnt(0)                                       // 000000B601A8: BF89FC07
	v_dual_add_f32 v8, v2, v3 :: v_dual_add_f32 v9, v4, v5     // 000000B601AC: C9080702 08080B04
	v_dual_sub_f32 v2, v2, v3 :: v_dual_sub_f32 v3, v4, v5     // 000000B601B4: C94A0702 02020B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B601BC: BF8701A2
	v_sub_f32_e32 v5, v8, v9                                   // 000000B601C0: 080A1308
	v_add_f32_e32 v4, v8, v9                                   // 000000B601C4: 06081308
	v_add_f32_e32 v8, v2, v3                                   // 000000B601C8: 06100702
	s_delay_alu instid0(VALU_DEP_3)                            // 000000B601CC: BF870003
	v_mov_b32_dpp v9, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B601D0: 7E1202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000B601D8: D5010005 200E0B05
	v_sub_f32_e32 v2, v2, v3                                   // 000000B601E0: 08040702
	v_mov_b32_dpp v3, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B601E4: 7E0602FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000B601EC: D5010004 200E0904
	v_mov_b32_dpp v10, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B601F4: 7E1402FA FF016108
	v_add_f32_e32 v5, v5, v9                                   // 000000B601FC: 060A1305
	v_mov_b32_dpp v11, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B60200: 7E1602FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000B60208: D5010002 200E0502
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000B60210: D5010008 200E1108
	v_add_f32_e32 v3, v4, v3                                   // 000000B60218: 06060704
	s_mov_b32 s3, 0x76543210                                   // 000000B6021C: BE8300FF 76543210
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B60224: BF870193
	v_add_f32_e32 v2, v2, v11                                  // 000000B60228: 06041702
	v_add_f32_e32 v4, v8, v10                                  // 000000B6022C: 06081508
	v_mov_b32_dpp v8, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B60230: 7E1002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000B60238: D5010005 200A0B05
	.long 0x7f163880                                           // 000000B60240: 7F163880
	v_mov_b32_dpp v10, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B60244: 7E1402FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000B6024C: D5010002 200A0502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B60254: BF8700B1
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v2, v2, v10    // 000000B60258: C9081105 05021502
	v_mov_b32_dpp v9, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B60260: 7E1202FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000B60268: D5010003 200A0703
	v_add_f32_e32 v3, v3, v9                                   // 000000B60270: 06061303
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B60274: BF8701A4
	v_mov_b32_dpp v9, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B60278: 7E1202FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000B60280: D5010005 20060B05
	v_mov_b32_dpp v10, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B60288: 7E1402FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000B60290: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B60298: BF8700B3
	v_add_f32_e32 v5, v5, v9                                   // 000000B6029C: 060A1305
	v_mov_b32_dpp v8, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B602A0: 7E1002FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000B602A8: D5010004 200A0904
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v4, v4, v8    // 000000B602B0: C9081503 03041104
	v_mov_b32_dpp v8, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B602B8: 7E1002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000B602C0: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B602C8: BF8701A3
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B602CC: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000B602D4: D5010004 20060904
	v_add_f32_e32 v2, v2, v8                                   // 000000B602DC: 06041102
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B602E0: 7E1002FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000B602E8: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B602F0: BF8701B1
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v8     // 000000B602F4: C9081304 04041105
	v_mov_b32_dpp v8, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B602FC: 7E1002FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000B60304: D5010003 20020703
	v_mov_b32_e32 v9, v5                                       // 000000B6030C: 7E120305
	v_mov_b32_dpp v10, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B60310: 7E1402FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000B60318: D5010002 20020502
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000B60320: D5010005 21AA0B05
	v_add_f32_e32 v3, v3, v8                                   // 000000B60328: 06061103
	v_permlanex16_b32 v9, v9, s3, 0xfedcba98                   // 000000B6032C: D65C0009 03FC0709 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B60338: BF8701B4
	v_add_f32_e32 v2, v2, v10                                  // 000000B6033C: 06041502
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B60340: 7E1402FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000B60348: D5010004 20020904
	v_dual_add_f32 v5, v5, v9 :: v_dual_mov_b32 v12, v2        // 000000B60350: C9101305 050C0102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000B60358: D5010002 21AA0502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B60360: BF870222
	v_dual_add_f32 v4, v4, v10 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000B60364: C9061504 04040AFF 3DB504F3
	v_mov_b32_e32 v8, v3                                       // 000000B60370: 7E100303
	v_permlanex16_b32 v12, v12, s3, 0xfedcba98                 // 000000B60374: D65C000C 03FC070C FEDCBA98
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000B60380: D5010003 21AA0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B60388: BF8701B4
	v_mov_b32_e32 v9, v4                                       // 000000B6038C: 7E120304
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000B60390: D5010004 21AA0904
	v_permlanex16_b32 v8, v8, s3, 0xfedcba98                   // 000000B60398: D65C0008 03FC0708 FEDCBA98
	v_permlanex16_b32 v9, v9, s3, 0xfedcba98                   // 000000B603A4: D65C0009 03FC0709 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B603B0: BF8701A2
	v_add_f32_e32 v3, v3, v8                                   // 000000B603B4: 06061103
	.long 0x7f10398b                                           // 000000B603B8: 7F10398B
	v_add_f32_e32 v4, v4, v9                                   // 000000B603BC: 06081304
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B603C0: BF870113
	v_dual_add_f32 v2, v2, v12 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 000000B603C4: C9061902 020206FF 3DB504F3
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000B603D0: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000B603D8: BF870132
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000B603DC: 100404FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B603E4: BF8903F7
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel_hi:[1,0,0]         // 000000B603E8: CC200005 8A020B07
	v_fma_mix_f32 v2, v7, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B603F0: CC200802 8A020507
	.long 0x7f0e398b                                           // 000000B603F8: 7F0E398B
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel_hi:[1,0,0]         // 000000B603FC: CC200003 8A020706
	v_fma_mix_f32 v4, v6, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B60404: CC200804 8A020906
	.long 0x7e103985                                           // 000000B6040C: 7E103985
	.long 0x7e0e3982                                           // 000000B60410: 7E0E3982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B60414: BF870193
	v_bfe_u32 v9, v4, 16, 1                                    // 000000B60418: D6100009 02052104
	v_and_b32_e32 v8, 1, v8                                    // 000000B60420: 36101081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B60424: BF8701A3
	v_and_b32_e32 v6, 1, v7                                    // 000000B60428: 360C0E81
	v_bfe_u32 v7, v3, 16, 1                                    // 000000B6042C: D6100007 02052103
	v_add3_u32 v5, v5, v8, 0x7fff                              // 000000B60434: D6550005 03FE1105 00007FFF
	.long 0x7f10398b                                           // 000000B60440: 7F10398B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B60444: BF870214
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000B60448: D6550002 03FE0D02 00007FFF
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000B60454: D6550003 03FE0F03 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B60460: BF870224
	.long 0x7e103985                                           // 000000B60464: 7E103985
	v_add3_u32 v5, v4, v9, 0x7fff                              // 000000B60468: D6550005 03FE1304 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v2                           // 000000B60474: 360804FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B6047C: BF8701B4
	.long 0x7e163983                                           // 000000B60480: 7E163983
	v_mad_i64_i32 v[1:2], null, 0x1400, v1, v[25:26]           // 000000B60484: D6FF7C01 046602FF 00001400
	v_and_b32_e32 v6, 0xffff, v8                               // 000000B60490: 360C10FF 0000FFFF
	v_and_or_b32 v3, 0xffff0000, v5, v11                       // 000000B60498: D6570003 042E0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000B604A4: BF870002
	v_or_b32_e32 v4, v4, v6                                    // 000000B604A8: 38080D04
	global_store_b64 v[1:2], v[3:4], off                       // 000000B604AC: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B604B4: 8C7E057E
	s_mov_b32 s1, 0                                            // 000000B604B8: BE810080
	s_waitcnt_vscnt null, 0x0                                  // 000000B604BC: BC7C0000
	s_barrier                                                  // 000000B604C0: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000B604C4: 8B6A017E
	s_cbranch_vccz 3168                                        // 000000B604C8: BFA30C60 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6d4c>
	v_or_b32_e32 v1, 0x100, v0                                 // 000000B604CC: 380200FF 00000100
	v_lshrrev_b32_e32 v8, 4, v0                                // 000000B604D4: 32100084
	s_add_i32 s0, s19, -1                                      // 000000B604D8: 8100C113
	v_lshrrev_b32_e32 v9, 4, v57                               // 000000B604DC: 32127284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B604E0: BF8701B3
	v_lshrrev_b32_e32 v7, 4, v1                                // 000000B604E4: 320E0284
	v_lshlrev_b32_e32 v1, 3, v0                                // 000000B604E8: 30020083
	v_min_i32_e32 v2, s0, v8                                   // 000000B604EC: 22041000
	v_min_i32_e32 v3, s0, v7                                   // 000000B604F0: 22060E00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B604F4: BF870223
	v_and_b32_e32 v76, 0x78, v1                                // 000000B604F8: 369802FF 00000078
	v_min_i32_e32 v1, s0, v9                                   // 000000B60500: 22021200
	v_add_nc_u32_e32 v2, s18, v2                               // 000000B60504: 4A040412
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B60508: BF870214
	v_add_nc_u32_e32 v3, s18, v3                               // 000000B6050C: 4A060612
	v_lshlrev_b32_e32 v10, 1, v76                              // 000000B60510: 30149881
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B60514: BF870214
	v_add_nc_u32_e32 v5, s18, v1                               // 000000B60518: 4A0A0212
	v_mad_i64_i32 v[1:2], null, 0x500, v2, 0                   // 000000B6051C: D6FF7C01 020204FF 00000500
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B60528: BF870214
	v_mad_i64_i32 v[3:4], null, 0x500, v3, 0                   // 000000B6052C: D6FF7C03 020206FF 00000500
	.long 0xd700000f                                           // 000000B60538: D700000F
	v_cndmask_b32_e32 v1, s10, v10, vcc_lo                     // 000000B6053C: 0202140A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B60540: BF8701A4
	v_mad_i64_i32 v[5:6], null, 0x500, v5, 0                   // 000000B60544: D6FF7C05 02020AFF 00000500
	v_add_co_ci_u32_e64 v16, null, s11, 0, s0                  // 000000B60550: D5207C10 0001000B
	.long 0xd7006a0b                                           // 000000B60558: D7006A0B
	v_cndmask_b32_e32 v1, v15, v1, vcc_lo                      // 000000B6055C: 0202030F
	.long 0xd44c0000                                           // 000000B60560: D44C0000
	v_cndmask_b32_e32 v1, 0x300, v0, vcc_lo                    // 000000B60564: 020200FF 00000300
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B6056C: BF8700A3
	v_add_co_ci_u32_e64 v12, null, v16, v2, vcc_lo             // 000000B60570: D5207C0C 01AA0510
	.long 0xd7006a0d                                           // 000000B60578: D7006A0D
	v_cndmask_b32_e32 v1, v15, v3, vcc_lo                      // 000000B6057C: 0202070F
	v_add_co_ci_u32_e64 v14, null, v16, v4, vcc_lo             // 000000B60580: D5207C0E 01AA0910
	.long 0xd7006a0f                                           // 000000B60588: D7006A0F
	v_cndmask_b32_e32 v1, v15, v5, vcc_lo                      // 000000B6058C: 02020B0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B60590: BF870001
	v_add_co_ci_u32_e64 v16, null, v16, v6, vcc_lo             // 000000B60594: D5207C10 01AA0D10
	s_clause 0x2                                               // 000000B6059C: BF850002
	global_load_b128 v[25:28], v[11:12], off                   // 000000B605A0: DC5E0000 197C000B
	global_load_b128 v[29:32], v[13:14], off                   // 000000B605A8: DC5E0000 1D7C000D
	global_load_b128 v[33:36], v[15:16], off                   // 000000B605B0: DC5E0000 217C000F
	s_and_saveexec_b32 s1, s0                                  // 000000B605B8: BE812000
	s_cbranch_execz 6                                          // 000000B605BC: BFA50006 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3cd8>
	v_mad_u32_u24 v11, 0x110, v8, v10                          // 000000B605C0: D60B000B 042A10FF 00000110
	s_waitcnt vmcnt(2)                                         // 000000B605CC: BF890BF7
	ds_store_b128 v11, v[25:28]                                // 000000B605D0: DB7C0000 0000190B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000B605D8: 8C7E017E
	.long 0xd44c0001                                           // 000000B605DC: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000B605E0: 020200FF 00000200
	s_and_saveexec_b32 s2, s1                                  // 000000B605E8: BE822001
	s_cbranch_execz 6                                          // 000000B605EC: BFA50006 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3d08>
	v_mad_u32_u24 v11, 0x110, v7, v10                          // 000000B605F0: D60B000B 042A0EFF 00000110
	s_waitcnt vmcnt(1)                                         // 000000B605FC: BF8907F7
	ds_store_b128 v11, v[29:32]                                // 000000B60600: DB7C0000 00001D0B
	s_or_b32 exec_lo, exec_lo, s2                              // 000000B60608: 8C7E027E
	.long 0xd44c0002                                           // 000000B6060C: D44C0002
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000B60610: 020200FF 00000100
	v_mul_u32_u24_e32 v79, 0x88, v9                            // 000000B60618: 169E12FF 00000088
	s_and_saveexec_b32 s3, s2                                  // 000000B60620: BE832002
	s_cbranch_execz 6                                          // 000000B60624: BFA50006 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3d40>
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B60628: BF870001
	v_lshl_add_u32 v9, v79, 1, v10                             // 000000B6062C: D6460009 0429034F
	s_waitcnt vmcnt(0)                                         // 000000B60634: BF8903F7
	ds_store_b128 v9, v[33:36]                                 // 000000B60638: DB7C0000 00002109
	s_or_b32 exec_lo, exec_lo, s3                              // 000000B60640: 8C7E037E
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v77, 31, v0        // 000000B60644: CA240080 124C009F
	v_mul_u32_u24_e32 v80, 0x110, v8                           // 000000B6064C: 16A010FF 00000110
	v_lshrrev_b32_e32 v75, 5, v0                               // 000000B60654: 32960085
	s_mul_i32 s5, s16, 0x96000                                 // 000000B60658: 9605FF10 00096000
	s_delay_alu instid0(VALU_DEP_3)                            // 000000B60660: BF870003
	v_lshl_or_b32 v9, v77, 3, 4                                // 000000B60664: D6560009 0211074D
	v_mad_u32_u24 v12, v77, 24, 0x2f0                          // 000000B6066C: D60B000C 03FD314D 000002F0
	v_cmp_ne_u32_e32 vcc_lo, 0, v77                            // 000000B60678: 7C9A9A80
	s_mul_i32 s13, s17, 0x7800                                 // 000000B6067C: 960DFF11 00007800
	s_mul_hi_i32 s4, s16, 0x96000                              // 000000B60684: 9704FF10 00096000
	v_mad_u32_u24 v11, v9, 3, 0x2f0                            // 000000B6068C: D60B000B 03FD0709 000002F0
	v_lshrrev_b32_e32 v14, 5, v12                              // 000000B60698: 321C1885
	v_mov_b32_e32 v10, v18                                     // 000000B6069C: 7E140312
	s_add_u32 s5, s5, s13                                      // 000000B606A0: 80050D05
	s_mul_hi_i32 s21, s17, 0x7800                              // 000000B606A4: 9715FF11 00007800
	v_lshrrev_b32_e32 v13, 5, v11                              // 000000B606AC: 321A1685
	v_subrev_nc_u32_e32 v17, 24, v14                           // 000000B606B0: 4E221C98
	v_and_b32_e32 v78, 15, v0                                  // 000000B606B4: 369C008F
	v_and_b32_e32 v11, 0x7e0, v11                              // 000000B606B8: 361616FF 000007E0
	s_addc_u32 s4, s4, s21                                     // 000000B606C0: 82041504
	.long 0xd7030008                                           // 000000B606C4: D7030008
	v_cndmask_b32_e32 v0, v13, v129, vcc_lo                    // 000000B606C8: 0201030D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000B606CC: BF870003
	v_dual_cndmask_b32 v17, 23, v17 :: v_dual_lshlrev_b32 v16, 4, v78// 000000B606D0: CA622297 11109C84
	v_subrev_nc_u32_e32 v13, 24, v13                           // 000000B606D8: 4E1A1A98
	v_cmp_lt_u32_e32 vcc_lo, 5, v9                             // 000000B606DC: 7C921285
	v_and_b32_e32 v12, 0x7e0, v12                              // 000000B606E0: 361818FF 000007E0
	v_mad_i32_i24 v11, v9, -3, v11                             // 000000B606E8: D60A000B 042D8709
	.long 0xd7624008                                           // 000000B606F0: D7624008
	v_cndmask_b32_e32 v1, 0xff, v8, vcc_lo                     // 000000B606F4: 020210FF 000000FF
	v_mul_u32_u24_e32 v15, 0x88, v78                           // 000000B606FC: 161E9CFF 00000088
	v_cndmask_b32_e32 v9, 23, v13, vcc_lo                      // 000000B60704: 02121A97
	.long 0xd7006a05                                           // 000000B60708: D7006A05
	v_cndmask_b32_e32 v1, v5, v16, vcc_lo                      // 000000B6070C: 02022105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B60710: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, vcc_lo                // 000000B60714: D5207C06 01AA0C80
	.long 0xd7055008                                           // 000000B6071C: D7055008
	v_cndmask_b32_e32 v1, 0xab, v8, vcc_lo                     // 000000B60720: 020210FF 000000AB
	.long 0xd7006a05                                           // 000000B60728: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000B6072C: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B60730: BF8700A1
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 000000B60734: D5207C06 01AA0C0B
	.long 0xd7006a03                                           // 000000B6073C: D7006A03
	v_cndmask_b32_e32 v1, v3, v16, vcc_lo                      // 000000B60740: 02022103
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000B60744: D5207C04 01AA0880
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000B6074C: BF8700C4
	.long 0xd7006a25                                           // 000000B60750: D7006A25
	v_cndmask_b32_e32 v1, 0x100, v5, vcc_lo                    // 000000B60754: 02020AFF 00000100
	.long 0xd7395008                                           // 000000B6075C: D7395008
	v_cndmask_b32_e32 v1, 12, v8, vcc_lo                       // 000000B60760: 0202108C
	v_add_co_ci_u32_e64 v38, null, 0, v6, vcc_lo               // 000000B60764: D5207C26 01AA0C80
	.long 0xd7006a03                                           // 000000B6076C: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 000000B60770: 0202060A
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 000000B60774: D5207C04 01AA080B
	.long 0xd7006a01                                           // 000000B6077C: D7006A01
	v_cndmask_b32_e32 v1, v1, v16, vcc_lo                      // 000000B60780: 02022101
	.long 0xd7054808                                           // 000000B60784: D7054808
	v_cndmask_b32_e32 v0, v8, v152, vcc_lo                     // 000000B60788: 02013108
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000B6078C: D5207C02 01AA0480
	.long 0xd7006a27                                           // 000000B60794: D7006A27
	v_cndmask_b32_e32 v1, 0x100, v3, vcc_lo                    // 000000B60798: 020206FF 00000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B607A0: BF870001
	v_add_co_ci_u32_e64 v40, null, 0, v4, vcc_lo               // 000000B607A4: D5207C28 01AA0880
	.long 0xd7006a03                                           // 000000B607AC: D7006A03
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 000000B607B0: 0202020A
	v_mul_u32_u24_e32 v1, 0x60, v75                            // 000000B607B4: 160296FF 00000060
	.long 0xd7041008                                           // 000000B607BC: D7041008
	v_cndmask_b32_e32 v1, v8, v8, vcc_lo                       // 000000B607C0: 02021108
	v_add_co_ci_u32_e64 v4, null, s11, v2, vcc_lo              // 000000B607C4: D5207C04 01AA040B
	v_mul_hi_u32_u24_e32 v5, 0x60, v75                         // 000000B607CC: 180A96FF 00000060
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B607D4: BF8700B4
	v_or_b32_e32 v6, s5, v1                                    // 000000B607D8: 380C0205
	.long 0xd73c0001                                           // 000000B607DC: D73C0001
	v_cndmask_b32_e32 v1, 2, v17, vcc_lo                       // 000000B607E0: 02022282
	.long 0xd7006a29                                           // 000000B607E4: D7006A29
	v_cndmask_b32_e32 v1, 0x100, v3, vcc_lo                    // 000000B607E8: 020206FF 00000100
	v_add_co_ci_u32_e64 v42, null, 0, v4, vcc_lo               // 000000B607F0: D5207C2A 01AA0880
	v_or_b32_e32 v3, s4, v5                                    // 000000B607F8: 38060A04
	v_and_b32_e32 v4, 0xff, v8                                 // 000000B607FC: 360810FF 000000FF
	.long 0xd7006a01                                           // 000000B60804: D7006A01
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                       // 000000B60808: 02020306
	v_lshlrev_b32_e32 v98, 1, v15                              // 000000B6080C: 30C41E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B60810: BF870214
	v_add_co_ci_u32_e64 v2, null, v3, v2, vcc_lo               // 000000B60814: D5207C02 01AA0503
	v_dual_mov_b32 v15, v18 :: v_dual_lshlrev_b32 v4, 2, v4    // 000000B6081C: CA220112 0F040882
	v_dual_mov_b32 v19, v18 :: v_dual_add_nc_u32 v14, 0xe9, v14// 000000B60824: CA200112 130E1CFF 000000E9
	.long 0xd7006a5a                                           // 000000B60830: D7006A5A
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000B60834: 02020208
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B60838: BF870211
	v_add_co_ci_u32_e64 v91, null, s9, v2, vcc_lo              // 000000B6083C: D5207C5B 01AA0409
	.long 0xd7006a01                                           // 000000B60844: D7006A01
	v_cndmask_b32_e32 v1, v6, v4, vcc_lo                       // 000000B60848: 02020906
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B6084C: BF8701A4
	v_dual_mov_b32 v21, v18 :: v_dual_and_b32 v14, 0xff, v14   // 000000B60850: CA240112 150E1CFF 000000FF
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo                // 000000B6085C: D5207C02 01AA0680
	.long 0xd7006a5c                                           // 000000B60864: D7006A5C
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000B60868: 02020208
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B6086C: BF870193
	v_lshlrev_b32_e32 v4, 2, v14                               // 000000B60870: 30081C82
	v_add_co_ci_u32_e64 v93, null, s9, v2, vcc_lo              // 000000B60874: D5207C5D 01AA0409
	.long 0xd73c0001                                           // 000000B6087C: D73C0001
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000B60880: 02021282
	v_mad_i32_i24 v12, 0xffffffe8, v77, v12                    // 000000B60884: D60A000C 04329AFF FFFFFFE8
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B60890: BF870094
	.long 0xd7006a04                                           // 000000B60894: D7006A04
	v_cndmask_b32_e32 v1, v6, v4, vcc_lo                       // 000000B60898: 02020906
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 000000B6089C: D5207C05 01AA0680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B608A4: BF870094
	.long 0xd7006a01                                           // 000000B608A8: D7006A01
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                       // 000000B608AC: 02020306
	v_add_co_ci_u32_e64 v2, null, v3, v2, vcc_lo               // 000000B608B0: D5207C02 01AA0503
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B608B8: BF870094
	.long 0xd7006a5e                                           // 000000B608BC: D7006A5E
	v_cndmask_b32_e32 v1, s8, v4, vcc_lo                       // 000000B608C0: 02020808
	v_add_co_ci_u32_e64 v95, null, s9, v5, vcc_lo              // 000000B608C4: D5207C5F 01AA0A09
	s_delay_alu instid0(VALU_DEP_4)                            // 000000B608CC: BF870004
	.long 0xd7006a60                                           // 000000B608D0: D7006A60
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000B608D4: 02020208
	.long 0xd44c0003                                           // 000000B608D8: D44C0003
	v_cndmask_b32_e32 v1, 16, v77, vcc_lo                      // 000000B608DC: 02029A90
	v_dual_mov_b32 v20, v18 :: v_dual_add_nc_u32 v81, 0xfffffd3d, v12// 000000B608E0: CA200112 145018FF FFFFFD3D
	v_dual_mov_b32 v23, v18 :: v_dual_add_nc_u32 v82, 0xfffffd3a, v12// 000000B608EC: CA200112 175218FF FFFFFD3A
	v_dual_mov_b32 v22, v18 :: v_dual_add_nc_u32 v83, 0xfffffd37, v12// 000000B608F8: CA200112 165218FF FFFFFD37
	v_dual_mov_b32 v9, v18 :: v_dual_add_nc_u32 v84, 0xfffffd34, v12// 000000B60904: CA200112 095418FF FFFFFD34
	v_dual_mov_b32 v24, v18 :: v_dual_add_nc_u32 v85, 0xfffffd3d, v11// 000000B60910: CA200112 185416FF FFFFFD3D
	v_add_nc_u32_e32 v86, 0xfffffd3a, v11                      // 000000B6091C: 4AAC16FF FFFFFD3A
	v_dual_mov_b32 v12, v18 :: v_dual_add_nc_u32 v87, 0xfffffd37, v11// 000000B60924: CA200112 0C5616FF FFFFFD37
	v_dual_mov_b32 v13, v18 :: v_dual_add_nc_u32 v88, 0xfffffd34, v11// 000000B60930: CA200112 0D5816FF FFFFFD34
	v_mul_u32_u24_e32 v89, 0x110, v7                           // 000000B6093C: 16B20EFF 00000110
	v_add_co_ci_u32_e64 v97, null, s9, v2, vcc_lo              // 000000B60944: D5207C61 01AA0409
	v_mov_b32_e32 v17, v18                                     // 000000B6094C: 7E220312
	v_mov_b32_e32 v11, v18                                     // 000000B60950: 7E160312
	v_mov_b32_e32 v14, v18                                     // 000000B60954: 7E1C0312
	v_mov_b32_e32 v16, v18                                     // 000000B60958: 7E200312
	v_mov_b32_e32 v1, v18                                      // 000000B6095C: 7E020312
	v_mov_b32_e32 v2, v18                                      // 000000B60960: 7E040312
	v_mov_b32_e32 v3, v18                                      // 000000B60964: 7E060312
	v_mov_b32_e32 v4, v18                                      // 000000B60968: 7E080312
	v_mov_b32_e32 v5, v18                                      // 000000B6096C: 7E0A0312
	v_mov_b32_e32 v6, v18                                      // 000000B60970: 7E0C0312
	v_mov_b32_e32 v7, v18                                      // 000000B60974: 7E0E0312
	v_mov_b32_e32 v8, v18                                      // 000000B60978: 7E100312
	s_mov_b32 s12, 0                                           // 000000B6097C: BE8C0080
	s_mov_b64 s[4:5], 0                                        // 000000B60980: BE840180
	s_movk_i32 s13, 0x1eee                                     // 000000B60984: B00D1EEE
	s_mov_b32 s21, 0x76543210                                  // 000000B60988: BE9500FF 76543210
	s_movk_i32 s22, 0x4460                                     // 000000B60990: B0164460
	s_movk_i32 s23, 0x80                                       // 000000B60994: B0170080
	s_movk_i32 s24, 0xa0                                       // 000000B60998: B01800A0
	s_movk_i32 s25, 0xc0                                       // 000000B6099C: B01900C0
	s_movk_i32 s26, 0xe0                                       // 000000B609A0: B01A00E0
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000B609A4: BF890007
	s_barrier                                                  // 000000B609A8: BFBD0000
	buffer_gl0_inv                                             // 000000B609AC: E0AC0000 00000000
	s_branch 28                                                // 000000B609B4: BFA0001C <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x4128>
	s_or_b32 exec_lo, exec_lo, s27                             // 000000B609B8: 8C7E1B7E
	.long 0xd7006a25                                           // 000000B609BC: D7006A25
	v_cndmask_b32_e32 v1, 0x100, v37, vcc_lo                   // 000000B609C0: 02024AFF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B609C8: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v38, vcc_lo              // 000000B609CC: D5207C26 01AA4C80
	.long 0xd7006a27                                           // 000000B609D4: D7006A27
	v_cndmask_b32_e32 v1, 0x100, v39, vcc_lo                   // 000000B609D8: 02024EFF 00000100
	v_add_co_ci_u32_e64 v40, null, 0, v40, vcc_lo              // 000000B609E0: D5207C28 01AA5080
	.long 0xd7006a29                                           // 000000B609E8: D7006A29
	v_cndmask_b32_e32 v1, 0x100, v41, vcc_lo                   // 000000B609EC: 020252FF 00000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B609F4: BF870001
	v_add_co_ci_u32_e64 v42, null, 0, v42, vcc_lo              // 000000B609F8: D5207C2A 01AA5480
	s_add_u32 s4, s4, 0x1800                                   // 000000B60A00: 8004FF04 00001800
	s_addc_u32 s5, s5, 0                                       // 000000B60A08: 82058005
	s_add_i32 s12, s12, 1                                      // 000000B60A0C: 810C810C
	s_cmpk_eq_i32 s4, 0x7800                                   // 000000B60A10: B1847800
	s_waitcnt lgkmcnt(0)                                       // 000000B60A14: BF89FC07
	s_barrier                                                  // 000000B60A18: BFBD0000
	buffer_gl0_inv                                             // 000000B60A1C: E0AC0000 00000000
	s_cbranch_scc1 1484                                        // 000000B60A24: BFA205CC <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5858>
	s_cmpk_lg_i32 s4, 0x6000                                   // 000000B60A28: B2046000
	s_cselect_b32 s27, -1, 0                                   // 000000B60A2C: 981B80C1
	s_cmpk_eq_i32 s4, 0x6000                                   // 000000B60A30: B1846000
	s_cbranch_scc1 6                                           // 000000B60A34: BFA20006 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x4150>
	global_load_b128 v[25:28], v[41:42], off                   // 000000B60A38: DC5E0000 197C0029
	global_load_b128 v[29:32], v[39:40], off                   // 000000B60A40: DC5E0000 1D7C0027
	global_load_b128 v[33:36], v[37:38], off                   // 000000B60A48: DC5E0000 217C0025
	.long 0xd7006a33                                           // 000000B60A50: D7006A33
	v_cndmask_b32_e32 v0, v90, v4, vcc_lo                      // 000000B60A54: 0200095A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B60A58: BF8700A1
	v_add_co_ci_u32_e64 v52, null, s5, v91, vcc_lo             // 000000B60A5C: D5207C34 01AAB605
	.long 0xd7006a35                                           // 000000B60A64: D7006A35
	v_cndmask_b32_e32 v0, v94, v4, vcc_lo                      // 000000B60A68: 0200095E
	v_add_co_ci_u32_e64 v54, null, s5, v95, vcc_lo             // 000000B60A6C: D5207C36 01AABE05
	.long 0xd7006a37                                           // 000000B60A74: D7006A37
	v_cndmask_b32_e32 v0, v96, v4, vcc_lo                      // 000000B60A78: 02000960
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B60A7C: BF8700A1
	v_add_co_ci_u32_e64 v56, null, s5, v97, vcc_lo             // 000000B60A80: D5207C38 01AAC205
	.long 0xd7006a39                                           // 000000B60A88: D7006A39
	v_cndmask_b32_e32 v0, v92, v4, vcc_lo                      // 000000B60A8C: 0200095C
	v_add_co_ci_u32_e64 v58, null, s5, v93, vcc_lo             // 000000B60A90: D5207C3A 01AABA05
	s_clause 0x17                                              // 000000B60A98: BF850017
	global_load_b32 v46, v[51:52], off                         // 000000B60A9C: DC520000 2E7C0033
	global_load_b32 v45, v[53:54], off                         // 000000B60AA4: DC520000 2D7C0035
	global_load_b32 v44, v[55:56], off                         // 000000B60AAC: DC520000 2C7C0037
	global_load_b32 v43, v[57:58], off                         // 000000B60AB4: DC520000 2B7C0039
	global_load_b32 v48, v[51:52], off offset:768              // 000000B60ABC: DC520300 307C0033
	global_load_b32 v47, v[53:54], off offset:768              // 000000B60AC4: DC520300 2F7C0035
	global_load_b32 v50, v[55:56], off offset:768              // 000000B60ACC: DC520300 327C0037
	global_load_b32 v49, v[57:58], off offset:768              // 000000B60AD4: DC520300 317C0039
	global_load_b32 v60, v[51:52], off offset:1536             // 000000B60ADC: DC520600 3C7C0033
	global_load_b32 v59, v[53:54], off offset:1536             // 000000B60AE4: DC520600 3B7C0035
	global_load_b32 v62, v[55:56], off offset:1536             // 000000B60AEC: DC520600 3E7C0037
	global_load_b32 v61, v[57:58], off offset:1536             // 000000B60AF4: DC520600 3D7C0039
	global_load_b32 v64, v[51:52], off offset:2304             // 000000B60AFC: DC520900 407C0033
	global_load_b32 v63, v[53:54], off offset:2304             // 000000B60B04: DC520900 3F7C0035
	global_load_b32 v66, v[55:56], off offset:2304             // 000000B60B0C: DC520900 427C0037
	global_load_b32 v65, v[57:58], off offset:2304             // 000000B60B14: DC520900 417C0039
	global_load_b32 v72, v[51:52], off offset:3072             // 000000B60B1C: DC520C00 487C0033
	global_load_b32 v71, v[53:54], off offset:3072             // 000000B60B24: DC520C00 477C0035
	global_load_b32 v74, v[55:56], off offset:3072             // 000000B60B2C: DC520C00 4A7C0037
	global_load_b32 v73, v[57:58], off offset:3072             // 000000B60B34: DC520C00 497C0039
	global_load_b32 v68, v[51:52], off offset:3840             // 000000B60B3C: DC520F00 447C0033
	global_load_b32 v67, v[53:54], off offset:3840             // 000000B60B44: DC520F00 437C0035
	global_load_b32 v69, v[57:58], off offset:3840             // 000000B60B4C: DC520F00 457C0039
	global_load_b32 v70, v[55:56], off offset:3840             // 000000B60B54: DC520F00 467C0037
	.long 0xd7006a7b                                           // 000000B60B5C: D7006A7B
	v_cndmask_b32_e32 v1, 0x1000, v51, vcc_lo                  // 000000B60B60: 020266FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B60B68: BF8700A1
	v_add_co_ci_u32_e64 v124, null, 0, v52, vcc_lo             // 000000B60B6C: D5207C7C 01AA6880
	.long 0xd7006a7d                                           // 000000B60B74: D7006A7D
	v_cndmask_b32_e32 v1, 0x1000, v53, vcc_lo                  // 000000B60B78: 02026AFF 00001000
	v_add_co_ci_u32_e64 v126, null, 0, v54, vcc_lo             // 000000B60B80: D5207C7E 01AA6C80
	.long 0xd7006a7f                                           // 000000B60B88: D7006A7F
	v_cndmask_b32_e32 v1, 0x1000, v55, vcc_lo                  // 000000B60B8C: 02026EFF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B60B94: BF8700A1
	v_add_co_ci_u32_e64 v128, null, 0, v56, vcc_lo             // 000000B60B98: D5207C80 01AA7080
	.long 0xd7006a37                                           // 000000B60BA0: D7006A37
	v_cndmask_b32_e32 v1, 0x1000, v57, vcc_lo                  // 000000B60BA4: 020272FF 00001000
	v_add_co_ci_u32_e64 v56, null, 0, v58, vcc_lo              // 000000B60BAC: D5207C38 01AA7480
	s_clause 0x7                                               // 000000B60BB4: BF850007
	global_load_b32 v54, v[123:124], off offset:512            // 000000B60BB8: DC520200 367C007B
	global_load_b32 v53, v[125:126], off offset:512            // 000000B60BC0: DC520200 357C007D
	global_load_b32 v52, v[127:128], off offset:512            // 000000B60BC8: DC520200 347C007F
	global_load_b32 v51, v[55:56], off offset:512              // 000000B60BD0: DC520200 337C0037
	global_load_b32 v55, v[55:56], off offset:1280             // 000000B60BD8: DC520500 377C0037
	global_load_b32 v56, v[127:128], off offset:1280           // 000000B60BE0: DC520500 387C007F
	global_load_b32 v57, v[125:126], off offset:1280           // 000000B60BE8: DC520500 397C007D
	global_load_b32 v58, v[123:124], off offset:1280           // 000000B60BF0: DC520500 3A7C007B
	s_bfe_i32 s28, s12, 0x10000                                // 000000B60BF8: 939CFF0C 00010000
	s_and_b32 s29, s12, 1                                      // 000000B60C00: 8B1D810C
	s_and_b32 s28, s28, 0x4400                                 // 000000B60C04: 8B1CFF1C 00004400
	s_cmp_eq_u32 s29, 0                                        // 000000B60C0C: BF06801D
	s_waitcnt vmcnt(30)                                        // 000000B60C10: BF897BF7
	.long 0xd73d00c3                                           // 000000B60C14: D73D00C3
	v_cndmask_b32_e32 v1, v81, v45, vcc_lo                     // 000000B60C18: 02025B51
	.long 0xd73d00c4                                           // 000000B60C1C: D73D00C4
	v_cndmask_b32_e32 v1, v82, v45, vcc_lo                     // 000000B60C20: 02025B52
	.long 0xd73d00c5                                           // 000000B60C24: D73D00C5
	v_cndmask_b32_e32 v1, v83, v45, vcc_lo                     // 000000B60C28: 02025B53
	s_waitcnt vmcnt(28)                                        // 000000B60C2C: BF8973F7
	.long 0xd73d00c6                                           // 000000B60C30: D73D00C6
	v_cndmask_b32_e32 v1, v85, v43, vcc_lo                     // 000000B60C34: 02025755
	.long 0xd73d00c7                                           // 000000B60C38: D73D00C7
	v_cndmask_b32_e32 v1, v86, v43, vcc_lo                     // 000000B60C3C: 02025756
	.long 0xd73d00c8                                           // 000000B60C40: D73D00C8
	v_cndmask_b32_e32 v1, v87, v43, vcc_lo                     // 000000B60C44: 02025757
	.long 0xd73d002b                                           // 000000B60C48: D73D002B
	v_cndmask_b32_e32 v1, v88, v43, vcc_lo                     // 000000B60C4C: 02025758
	v_and_b32_e32 v44, 0xffff, v195                            // 000000B60C50: 365986FF 0000FFFF
	s_waitcnt vmcnt(26)                                        // 000000B60C58: BF896BF7
	.long 0xd73d00c9                                           // 000000B60C5C: D73D00C9
	v_cndmask_b32_e32 v1, v81, v47, vcc_lo                     // 000000B60C60: 02025F51
	.long 0xd73d00ca                                           // 000000B60C64: D73D00CA
	v_cndmask_b32_e32 v1, v82, v47, vcc_lo                     // 000000B60C68: 02025F52
	.long 0xd73d00cb                                           // 000000B60C6C: D73D00CB
	v_cndmask_b32_e32 v1, v83, v47, vcc_lo                     // 000000B60C70: 02025F53
	v_and_b32_e32 v195, 0xffff, v200                           // 000000B60C74: 378790FF 0000FFFF
	v_and_b32_e32 v43, 0xffff, v43                             // 000000B60C7C: 365656FF 0000FFFF
	s_waitcnt vmcnt(24)                                        // 000000B60C84: BF8963F7
	.long 0xd73d00cc                                           // 000000B60C88: D73D00CC
	v_cndmask_b32_e32 v1, v86, v49, vcc_lo                     // 000000B60C8C: 02026356
	.long 0xd73d00cd                                           // 000000B60C90: D73D00CD
	v_cndmask_b32_e32 v1, v87, v49, vcc_lo                     // 000000B60C94: 02026357
	s_waitcnt vmcnt(22)                                        // 000000B60C98: BF895BF7
	.long 0xd73d00ce                                           // 000000B60C9C: D73D00CE
	v_cndmask_b32_e32 v1, v82, v59, vcc_lo                     // 000000B60CA0: 02027752
	.long 0xd72c00c3                                           // 000000B60CA4: D72C00C3
	v_cndmask_b32_e32 v1, 0x83dcd12d, v195, vcc_lo             // 000000B60CA8: 020386FF 83DCD12D
	.long 0xd72c002b                                           // 000000B60CB0: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000B60CB4: 020256FF 83DCD12D
	.long 0xd73d00cf                                           // 000000B60CBC: D73D00CF
	v_cndmask_b32_e32 v1, v83, v59, vcc_lo                     // 000000B60CC0: 02027753
	s_waitcnt vmcnt(20)                                        // 000000B60CC4: BF8953F7
	.long 0xd73d00d0                                           // 000000B60CC8: D73D00D0
	v_cndmask_b32_e32 v1, v85, v61, vcc_lo                     // 000000B60CCC: 02027B55
	.long 0xd73d00d1                                           // 000000B60CD0: D73D00D1
	v_cndmask_b32_e32 v1, v86, v61, vcc_lo                     // 000000B60CD4: 02027B56
	.long 0xd73d00d2                                           // 000000B60CD8: D73D00D2
	v_cndmask_b32_e32 v1, v87, v61, vcc_lo                     // 000000B60CDC: 02027B57
	.long 0xd73d002d                                           // 000000B60CE0: D73D002D
	v_cndmask_b32_e32 v1, v84, v45, vcc_lo                     // 000000B60CE4: 02025B54
	s_waitcnt vmcnt(18)                                        // 000000B60CE8: BF894BF7
	.long 0xd73d00d3                                           // 000000B60CEC: D73D00D3
	v_cndmask_b32_e32 v1, v82, v63, vcc_lo                     // 000000B60CF0: 02027F52
	v_sad_u8 v195, v195, 0, 0x6400                             // 000000B60CF4: D62200C3 03FD01C3 00006400
	.long 0xd73d002e                                           // 000000B60D00: D73D002E
	v_cndmask_b32_e32 v1, v84, v47, vcc_lo                     // 000000B60D04: 02025F54
	.long 0xd73d00d4                                           // 000000B60D08: D73D00D4
	v_cndmask_b32_e32 v1, v83, v63, vcc_lo                     // 000000B60D0C: 02027F53
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000B60D10: D622002B 03FD012B 00006400
	.long 0xd73d002f                                           // 000000B60D1C: D73D002F
	v_cndmask_b32_e32 v1, v85, v49, vcc_lo                     // 000000B60D20: 02026355
	v_and_b32_e32 v195, 0xffff, v195                           // 000000B60D24: 378786FF 0000FFFF
	s_waitcnt vmcnt(16)                                        // 000000B60D2C: BF8943F7
	.long 0xd73d00d5                                           // 000000B60D30: D73D00D5
	v_cndmask_b32_e32 v1, v86, v65, vcc_lo                     // 000000B60D34: 02028356
	.long 0xd73d0030                                           // 000000B60D38: D73D0030
	v_cndmask_b32_e32 v1, v88, v49, vcc_lo                     // 000000B60D3C: 02026358
	.long 0xd73d00d6                                           // 000000B60D40: D73D00D6
	v_cndmask_b32_e32 v1, v87, v65, vcc_lo                     // 000000B60D44: 02028357
	.long 0xd73d0031                                           // 000000B60D48: D73D0031
	v_cndmask_b32_e32 v1, v81, v59, vcc_lo                     // 000000B60D4C: 02027751
	.long 0xd73d003b                                           // 000000B60D50: D73D003B
	v_cndmask_b32_e32 v1, v84, v59, vcc_lo                     // 000000B60D54: 02027754
	s_waitcnt vmcnt(14)                                        // 000000B60D58: BF893BF7
	.long 0xd73d00d7                                           // 000000B60D5C: D73D00D7
	v_cndmask_b32_e32 v1, v82, v71, vcc_lo                     // 000000B60D60: 02028F52
	.long 0xd73d003c                                           // 000000B60D64: D73D003C
	v_cndmask_b32_e32 v1, v88, v61, vcc_lo                     // 000000B60D68: 02027B58
	.long 0xd73d00d8                                           // 000000B60D6C: D73D00D8
	v_cndmask_b32_e32 v1, v83, v71, vcc_lo                     // 000000B60D70: 02028F53
	.long 0xd73d003d                                           // 000000B60D74: D73D003D
	v_cndmask_b32_e32 v1, v81, v63, vcc_lo                     // 000000B60D78: 02027F51
	v_lshl_or_b32 v43, v43, 16, v195                           // 000000B60D7C: D656002B 070D212B
	.long 0xd73d003e                                           // 000000B60D84: D73D003E
	v_cndmask_b32_e32 v1, v84, v63, vcc_lo                     // 000000B60D88: 02027F54
	.long 0xd73d003f                                           // 000000B60D8C: D73D003F
	v_cndmask_b32_e32 v1, v85, v65, vcc_lo                     // 000000B60D90: 02028355
	.long 0xd73d0040                                           // 000000B60D94: D73D0040
	v_cndmask_b32_e32 v1, v88, v65, vcc_lo                     // 000000B60D98: 02028358
	.long 0xd73d0041                                           // 000000B60D9C: D73D0041
	v_cndmask_b32_e32 v1, v81, v71, vcc_lo                     // 000000B60DA0: 02028F51
	.long 0xd73d0047                                           // 000000B60DA4: D73D0047
	v_cndmask_b32_e32 v1, v84, v71, vcc_lo                     // 000000B60DA8: 02028F54
	v_pk_fma_f16 v195, v43, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000B60DAC: CC0E00C3 0BFC1B2B 0000C931
	v_and_b32_e32 v50, 0xffff, v196                            // 000000B60DB8: 366588FF 0000FFFF
	v_and_b32_e32 v196, 0xffff, v201                           // 000000B60DC0: 378992FF 0000FFFF
	v_and_b32_e32 v201, 0xffff, v206                           // 000000B60DC8: 37939CFF 0000FFFF
	v_and_b32_e32 v206, 0xffff, v211                           // 000000B60DD0: 379DA6FF 0000FFFF
	v_and_b32_e32 v211, 0xffff, v216                           // 000000B60DD8: 37A7B0FF 0000FFFF
	v_and_b32_e32 v71, 0xffff, v71                             // 000000B60DE0: 368E8EFF 0000FFFF
	v_and_b32_e32 v66, 0xffff, v197                            // 000000B60DE8: 36858AFF 0000FFFF
	v_and_b32_e32 v197, 0xffff, v202                           // 000000B60DF0: 378B94FF 0000FFFF
	v_and_b32_e32 v200, 0xffff, v205                           // 000000B60DF8: 37919AFF 0000FFFF
	.long 0xd72c00d3                                           // 000000B60E00: D72C00D3
	v_cndmask_b32_e32 v1, 0x83dcd12d, v211, vcc_lo             // 000000B60E04: 0203A6FF 83DCD12D
	.long 0xd72c0047                                           // 000000B60E0C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000B60E10: 02028EFF 83DCD12D
	v_and_b32_e32 v59, 0xffff, v59                             // 000000B60E18: 367676FF 0000FFFF
	v_and_b32_e32 v205, 0xffff, v210                           // 000000B60E20: 379BA4FF 0000FFFF
	v_and_b32_e32 v48, 0xffff, v48                             // 000000B60E28: 366060FF 0000FFFF
	v_and_b32_e32 v60, 0xffff, v60                             // 000000B60E30: 367878FF 0000FFFF
	.long 0xd72c00c8                                           // 000000B60E38: D72C00C8
	v_cndmask_b32_e32 v1, 0x83dcd12d, v200, vcc_lo             // 000000B60E3C: 020390FF 83DCD12D
	.long 0xd72c003b                                           // 000000B60E44: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000B60E48: 020276FF 83DCD12D
	v_sad_u8 v211, v211, 0, 0x6400                             // 000000B60E50: D62200D3 03FD01D3 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000B60E5C: D6220047 03FD0147 00006400
	.long 0xd72c00cd                                           // 000000B60E68: D72C00CD
	v_cndmask_b32_e32 v1, 0x83dcd12d, v205, vcc_lo             // 000000B60E6C: 02039AFF 83DCD12D
	v_and_b32_e32 v62, 0xffff, v62                             // 000000B60E74: 367C7CFF 0000FFFF
	.long 0xd72c0030                                           // 000000B60E7C: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000B60E80: 020260FF 83DCD12D
	v_and_b32_e32 v211, 0xffff, v211                           // 000000B60E88: 37A7A6FF 0000FFFF
	.long 0xd72c003c                                           // 000000B60E90: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000B60E94: 020278FF 83DCD12D
	v_sad_u8 v200, v200, 0, 0x6400                             // 000000B60E9C: D62200C8 03FD01C8 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000B60EA8: D622003B 03FD013B 00006400
	.long 0xd72c003e                                           // 000000B60EB4: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000B60EB8: 02027CFF 83DCD12D
	v_lshl_or_b32 v71, v71, 16, v211                           // 000000B60EC0: D6560047 074D2147
	v_sad_u8 v205, v205, 0, 0x6400                             // 000000B60EC8: D62200CD 03FD01CD 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000B60ED4: D6220030 03FD0130 00006400
	v_and_b32_e32 v200, 0xffff, v200                           // 000000B60EE0: 379190FF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000B60EE8: D622003C 03FD013C 00006400
	v_pk_fma_f16 v71, v71, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B60EF4: CC0E0047 0BFC1B47 0000C931
	v_and_b32_e32 v202, 0xffff, v207                           // 000000B60F00: 37959EFF 0000FFFF
	v_and_b32_e32 v207, 0xffff, v212                           // 000000B60F08: 379FA8FF 0000FFFF
	v_and_b32_e32 v205, 0xffff, v205                           // 000000B60F10: 379B9AFF 0000FFFF
	s_waitcnt vmcnt(12)                                        // 000000B60F18: BF8933F7
	.long 0xd73d00d9                                           // 000000B60F1C: D73D00D9
	v_cndmask_b32_e32 v1, v85, v73, vcc_lo                     // 000000B60F20: 02029355
	.long 0xd73d00da                                           // 000000B60F24: D73D00DA
	v_cndmask_b32_e32 v1, v86, v73, vcc_lo                     // 000000B60F28: 02029356
	.long 0xd72c00ca                                           // 000000B60F2C: D72C00CA
	v_cndmask_b32_e32 v1, 0x83dcd12d, v202, vcc_lo             // 000000B60F30: 020394FF 83DCD12D
	.long 0xd72c00cf                                           // 000000B60F38: D72C00CF
	v_cndmask_b32_e32 v1, 0x83dcd12d, v207, vcc_lo             // 000000B60F3C: 02039EFF 83DCD12D
	.long 0xd73d00db                                           // 000000B60F44: D73D00DB
	v_cndmask_b32_e32 v1, v87, v73, vcc_lo                     // 000000B60F48: 02029357
	.long 0xd73d0048                                           // 000000B60F4C: D73D0048
	v_cndmask_b32_e32 v1, v88, v73, vcc_lo                     // 000000B60F50: 02029358
	v_and_b32_e32 v73, 0xffff, v198                            // 000000B60F54: 36938CFF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000B60F5C: D622003E 03FD013E 00006400
	v_lshl_or_b32 v48, v48, 16, v200                           // 000000B60F68: D6560030 07212130
	v_lshl_or_b32 v60, v60, 16, v205                           // 000000B60F70: D656003C 0735213C
	v_sad_u8 v202, v202, 0, 0x6400                             // 000000B60F78: D62200CA 03FD01CA 00006400
	v_sad_u8 v207, v207, 0, 0x6400                             // 000000B60F84: D62200CF 03FD01CF 00006400
	v_and_b32_e32 v49, 0xffff, v49                             // 000000B60F90: 366262FF 0000FFFF
	.long 0xd72c00c9                                           // 000000B60F98: D72C00C9
	v_cndmask_b32_e32 v1, 0x83dcd12d, v201, vcc_lo             // 000000B60F9C: 020392FF 83DCD12D
	v_and_b32_e32 v47, 0xffff, v47                             // 000000B60FA4: 365E5EFF 0000FFFF
	v_and_b32_e32 v202, 0xffff, v202                           // 000000B60FAC: 379594FF 0000FFFF
	v_and_b32_e32 v207, 0xffff, v207                           // 000000B60FB4: 379F9EFF 0000FFFF
	.long 0xd72c0031                                           // 000000B60FBC: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000B60FC0: 020262FF 83DCD12D
	.long 0xd72c002c                                           // 000000B60FC8: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000B60FCC: 020258FF 83DCD12D
	.long 0xd72c0049                                           // 000000B60FD4: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000B60FD8: 020292FF 83DCD12D
	v_lshl_or_b32 v59, v59, 16, v202                           // 000000B60FE0: D656003B 0729213B
	v_lshl_or_b32 v62, v62, 16, v207                           // 000000B60FE8: D656003E 073D213E
	v_pk_fma_f16 v202, v60, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000B60FF0: CC0E00CA 0BFC1B3C 0000C931
	v_and_b32_e32 v46, 0xffff, v46                             // 000000B60FFC: 365C5CFF 0000FFFF
	v_sad_u8 v201, v201, 0, 0x6400                             // 000000B61004: D62200C9 03FD01C9 00006400
	v_pk_fma_f16 v200, v59, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000B61010: CC0E00C8 0BFC1B3B 0000C931
	v_and_b32_e32 v198, 0xffff, v203                           // 000000B6101C: 378D96FF 0000FFFF
	v_and_b32_e32 v203, 0xffff, v208                           // 000000B61024: 3797A0FF 0000FFFF
	.long 0xd72c002e                                           // 000000B6102C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000B61030: 02025CFF 83DCD12D
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000B61038: D6220031 03FD0131 00006400
	v_mov_b32_e32 v207, v200                                   // 000000B61044: 7F9E03C8
	.long 0xd72c00c6                                           // 000000B61048: D72C00C6
	v_cndmask_b32_e32 v1, 0x83dcd12d, v198, vcc_lo             // 000000B6104C: 02038CFF 83DCD12D
	.long 0xd72c00cb                                           // 000000B61054: D72C00CB
	v_cndmask_b32_e32 v1, 0x83dcd12d, v203, vcc_lo             // 000000B61058: 020396FF 83DCD12D
	v_and_b32_e32 v63, 0xffff, v63                             // 000000B61060: 367E7EFF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v49                             // 000000B61068: 366262FF 0000FFFF
	.long 0xd72c002f                                           // 000000B61070: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000B61074: 02025EFF 83DCD12D
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000B6107C: D622002E 03FD012E 00006400
	v_mov_b32_e32 v59, v195                                    // 000000B61088: 7E7603C3
	.long 0xd72c0032                                           // 000000B6108C: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000B61090: 020264FF 83DCD12D
	v_sad_u8 v198, v198, 0, 0x6400                             // 000000B61098: D62200C6 03FD01C6 00006400
	v_lshl_or_b32 v49, v201, 16, v49                           // 000000B610A4: D6560031 04C521C9
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000B610AC: D622002C 03FD012C 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000B610B8: D6220049 03FD0149 00006400
	v_sad_u8 v203, v203, 0, 0x6400                             // 000000B610C4: D62200CB 03FD01CB 00006400
	v_and_b32_e32 v198, 0xffff, v198                           // 000000B610D0: 378D8CFF 0000FFFF
	v_and_b32_e32 v208, 0xffff, v213                           // 000000B610D8: 37A1AAFF 0000FFFF
	.long 0xd72c003f                                           // 000000B610E0: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000B610E4: 02027EFF 83DCD12D
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000B610EC: D6220032 03FD0132 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000B610F8: D622002F 03FD012F 00006400
	v_lshl_or_b32 v46, v46, 16, v198                           // 000000B61104: D656002E 0719212E
	v_pk_fma_f16 v198, v48, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000B6110C: CC0E00C6 0BFC1B30 0000C931
	v_and_b32_e32 v74, 0xffff, v199                            // 000000B61118: 36958EFF 0000FFFF
	v_and_b32_e32 v199, 0xffff, v204                           // 000000B61120: 378F98FF 0000FFFF
	v_and_b32_e32 v204, 0xffff, v209                           // 000000B61128: 3799A2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B61130: BF870214
	v_dual_mov_b32 v201, v198 :: v_dual_and_b32 v44, 0xffff, v44// 000000B61134: CA2401C6 C92C58FF 0000FFFF
	.long 0xd72c004a                                           // 000000B61140: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000B61144: 020294FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B6114C: BF870214
	.long 0xd72c00c7                                           // 000000B61150: D72C00C7
	v_cndmask_b32_e32 v1, 0x83dcd12d, v199, vcc_lo             // 000000B61154: 02038EFF 83DCD12D
	.long 0xd72c00cc                                           // 000000B6115C: D72C00CC
	v_cndmask_b32_e32 v1, 0x83dcd12d, v204, vcc_lo             // 000000B61160: 020398FF 83DCD12D
	v_and_b32_e32 v73, 0xffff, v73                             // 000000B61168: 369292FF 0000FFFF
	v_and_b32_e32 v203, 0xffff, v203                           // 000000B61170: 379796FF 0000FFFF
	.long 0xd72c00d0                                           // 000000B61178: D72C00D0
	v_cndmask_b32_e32 v1, 0x83dcd12d, v208, vcc_lo             // 000000B6117C: 0203A0FF 83DCD12D
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000B61184: D622003F 03FD013F 00006400
	v_and_b32_e32 v47, 0xffff, v47                             // 000000B61190: 365E5EFF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000B61198: D622004A 03FD014A 00006400
	v_sad_u8 v199, v199, 0, 0x6400                             // 000000B611A4: D62200C7 03FD01C7 00006400
	v_sad_u8 v204, v204, 0, 0x6400                             // 000000B611B0: D62200CC 03FD01CC 00006400
	v_lshl_or_b32 v44, v50, 16, v44                            // 000000B611BC: D656002C 04B12132
	.long 0xd72c0042                                           // 000000B611C4: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000B611C8: 020284FF 83DCD12D
	v_lshl_or_b32 v50, v74, 16, v73                            // 000000B611D0: D6560032 0525214A
	v_sad_u8 v208, v208, 0, 0x6400                             // 000000B611D8: D62200D0 03FD01D0 00006400
	v_lshl_or_b32 v73, v204, 16, v203                          // 000000B611E4: D6560049 072D21CC
	v_and_b32_e32 v63, 0xffff, v63                             // 000000B611EC: 367E7EFF 0000FFFF
	v_lshl_or_b32 v47, v199, 16, v47                           // 000000B611F4: D656002F 04BD21C7
	v_pk_fma_f16 v199, v49, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000B611FC: CC0E00C7 0BFC1B31 0000C931
	v_and_b32_e32 v65, 0xffff, v65                             // 000000B61208: 368282FF 0000FFFF
	v_pk_fma_f16 v73, v73, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B61210: CC0E0049 0BFC1B49 0000C931
	v_and_b32_e32 v45, 0xffff, v45                             // 000000B6121C: 365A5AFF 0000FFFF
	v_lshl_or_b32 v63, v208, 16, v63                           // 000000B61224: D656003F 04FD21D0
	v_mov_b32_e32 v203, v199                                   // 000000B6122C: 7F9603C7
	.long 0xd72c00c4                                           // 000000B61230: D72C00C4
	v_cndmask_b32_e32 v1, 0x83dcd12d, v196, vcc_lo             // 000000B61234: 020388FF 83DCD12D
	v_mov_b32_e32 v208, v73                                    // 000000B6123C: 7FA00349
	.long 0xd72c002d                                           // 000000B61240: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000B61244: 02025AFF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000B6124C: D6220042 03FD0142 00006400
	.long 0xd72c00c5                                           // 000000B61258: D72C00C5
	v_cndmask_b32_e32 v1, 0x83dcd12d, v197, vcc_lo             // 000000B6125C: 02038AFF 83DCD12D
	v_and_b32_e32 v210, 0xffff, v215                           // 000000B61264: 37A5AEFF 0000FFFF
	.long 0xd72c0041                                           // 000000B6126C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000B61270: 020282FF 83DCD12D
	v_and_b32_e32 v61, 0xffff, v61                             // 000000B61278: 367A7AFF 0000FFFF
	v_sad_u8 v196, v196, 0, 0x6400                             // 000000B61280: D62200C4 03FD01C4 00006400
	v_and_b32_e32 v66, 0xffff, v66                             // 000000B6128C: 368484FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000B61294: D622002D 03FD012D 00006400
	v_pk_fma_f16 v44, v44, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B612A0: CC0E002C 0BFC1B2C 0000C931
	v_add_nc_u32_e32 v119, s28, v98                            // 000000B612AC: 4AEEC41C
	v_sad_u8 v197, v197, 0, 0x6400                             // 000000B612B0: D62200C5 03FD01C5 00006400
	v_and_b32_e32 v196, 0xffff, v196                           // 000000B612BC: 378988FF 0000FFFF
	v_lshl_or_b32 v45, v45, 16, v66                            // 000000B612C4: D656002D 0509212D
	.long 0xd72c00d2                                           // 000000B612CC: D72C00D2
	v_cndmask_b32_e32 v1, 0x83dcd12d, v210, vcc_lo             // 000000B612D0: 0203A4FF 83DCD12D
	.long 0xd72c003d                                           // 000000B612D8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000B612DC: 02027AFF 83DCD12D
	s_cselect_b32 s28, -1, 0                                   // 000000B612E4: 981C80C1
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000B612E8: D6220041 03FD0141 00006400
	v_lshl_or_b32 v66, v197, 16, v196                          // 000000B612F4: D6560042 071121C5
	v_pk_fma_f16 v45, v45, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B612FC: CC0E002D 0BFC1B2D 0000C931
	v_pk_fma_f16 v50, v50, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B61308: CC0E0032 0BFC1B32 0000C931
	v_pk_fma_f16 v196, v46, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000B61314: CC0E00C4 0BFC1B2E 0000C931
	v_mov_b32_e32 v46, v44                                     // 000000B61320: 7E5C032C
	ds_load_b128 v[99:102], v119                               // 000000B61324: DBFC0000 63000077
	ds_load_b128 v[103:106], v119 offset:16                    // 000000B6132C: DBFC0010 67000077
	ds_load_b128 v[107:110], v119 offset:4352                  // 000000B61334: DBFC1100 6B000077
	ds_load_b128 v[111:114], v119 offset:4368                  // 000000B6133C: DBFC1110 6F000077
	ds_load_b128 v[115:118], v119 offset:8704                  // 000000B61344: DBFC2200 73000077
	ds_load_b128 v[119:122], v119 offset:8720                  // 000000B6134C: DBFC2210 77000077
	s_and_b32 s29, s28, exec_lo                                // 000000B61354: 8B1D7E1C
	v_and_b32_e32 v209, 0xffff, v214                           // 000000B61358: 37A3ACFF 0000FFFF
	v_and_b32_e32 v214, 0xffff, v219                           // 000000B61360: 37ADB6FF 0000FFFF
	s_cselect_b32 s29, 32, 0x4420                              // 000000B61368: 981DFFA0 00004420
	.long 0xd72c00ce                                           // 000000B61370: D72C00CE
	v_cndmask_b32_e32 v1, 0x83dcd12d, v206, vcc_lo             // 000000B61374: 02039CFF 83DCD12D
	v_dual_mov_b32 v48, v45 :: v_dual_add_nc_u32 v143, s29, v98// 000000B6137C: CA20012D 308EC41D
	v_sad_u8 v210, v210, 0, 0x6400                             // 000000B61384: D62200D2 03FD01D2 00006400
	v_and_b32_e32 v65, 0xffff, v65                             // 000000B61390: 368282FF 0000FFFF
	v_mov_b32_e32 v49, v50                                     // 000000B61398: 7E620332
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000B6139C: D622003D 03FD013D 00006400
	v_and_b32_e32 v72, 0xffff, v72                             // 000000B613A8: 369090FF 0000FFFF
	.long 0xd72c00d6                                           // 000000B613B0: D72C00D6
	v_cndmask_b32_e32 v1, 0x83dcd12d, v214, vcc_lo             // 000000B613B4: 0203ACFF 83DCD12D
	v_and_b32_e32 v64, 0xffff, v64                             // 000000B613BC: 368080FF 0000FFFF
	.long 0xd72c00d1                                           // 000000B613C4: D72C00D1
	v_cndmask_b32_e32 v1, 0x83dcd12d, v209, vcc_lo             // 000000B613C8: 0203A2FF 83DCD12D
	v_and_b32_e32 v212, 0xffff, v217                           // 000000B613D0: 37A9B2FF 0000FFFF
	v_lshl_or_b32 v65, v210, 16, v65                           // 000000B613D8: D6560041 050521D2
	v_permlanex16_b32 v46, v46, s21, 0xfedcba98                // 000000B613E0: D65C002E 03FC2B2E FEDCBA98
	v_permlanex16_b32 v48, v48, s21, 0xfedcba98                // 000000B613EC: D65C0030 03FC2B30 FEDCBA98
	v_permlanex16_b32 v49, v49, s21, 0xfedcba98                // 000000B613F8: D65C0031 03FC2B31 FEDCBA98
	v_permlanex16_b32 v59, v59, s21, 0xfedcba98                // 000000B61404: D65C003B 03FC2B3B FEDCBA98
	v_sad_u8 v206, v206, 0, 0x6400                             // 000000B61410: D62200CE 03FD01CE 00006400
	v_and_b32_e32 v61, 0xffff, v61                             // 000000B6141C: 367A7AFF 0000FFFF
	.long 0xd72c0048                                           // 000000B61424: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000B61428: 020290FF 83DCD12D
	.long 0xd72c0040                                           // 000000B61430: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000B61434: 020280FF 83DCD12D
	v_and_b32_e32 v213, 0xffff, v218                           // 000000B6143C: 37ABB4FF 0000FFFF
	.long 0xd72c00d4                                           // 000000B61444: D72C00D4
	v_cndmask_b32_e32 v1, 0x83dcd12d, v212, vcc_lo             // 000000B61448: 0203A8FF 83DCD12D
	v_sad_u8 v214, v214, 0, 0x6400                             // 000000B61450: D62200D6 03FD01D6 00006400
	v_pk_fma_f16 v197, v47, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000B6145C: CC0E00C5 0BFC1B2F 0000C931
	v_pk_fma_f16 v211, v65, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000B61468: CC0E00D3 0BFC1B41 0000C931
	v_cndmask_b32_e64 v43, v46, v44, s3                        // 000000B61474: D501002B 000E592E
	v_cndmask_b32_e64 v47, v44, v46, s3                        // 000000B6147C: D501002F 000E5D2C
	v_cndmask_b32_e64 v44, v48, v45, s3                        // 000000B61484: D501002C 000E5B30
	v_cndmask_b32_e64 v48, v45, v48, s3                        // 000000B6148C: D5010030 000E612D
	v_cndmask_b32_e64 v45, v49, v50, s3                        // 000000B61494: D501002D 000E6531
	v_cndmask_b32_e64 v49, v50, v49, s3                        // 000000B6149C: D5010031 000E6332
	v_cndmask_b32_e64 v46, v59, v195, s3                       // 000000B614A4: D501002E 000F873B
	v_cndmask_b32_e64 v50, v195, v59, s3                       // 000000B614AC: D5010032 000E77C3
	v_sad_u8 v209, v209, 0, 0x6400                             // 000000B614B4: D62200D1 03FD01D1 00006400
	v_lshl_or_b32 v61, v206, 16, v61                           // 000000B614C0: D656003D 04F521CE
	v_pk_fma_f16 v66, v66, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B614C8: CC0E0042 0BFC1B42 0000C931
	s_cselect_b32 s30, 64, 0x4440                              // 000000B614D4: 981EFFC0 00004440
	s_cselect_b32 s31, 0x60, s22                               // 000000B614DC: 981F16FF 00000060
	.long 0xd72c00d5                                           // 000000B614E4: D72C00D5
	v_cndmask_b32_e32 v1, 0x83dcd12d, v213, vcc_lo             // 000000B614E8: 0203AAFF 83DCD12D
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000B614F0: D6220048 03FD0148 00006400
	v_and_b32_e32 v214, 0xffff, v214                           // 000000B614FC: 37ADACFF 0000FFFF
	s_waitcnt lgkmcnt(4)                                       // 000000B61504: BF89FC47
	v_wmma_f32_16x16x16_f16 v[17:24], v[43:50], v[99:106], v[17:24]// 000000B61508: CC404011 1C46C72B
	s_waitcnt lgkmcnt(2)                                       // 000000B61510: BF89FC27
	v_wmma_f32_16x16x16_f16 v[9:16], v[43:50], v[107:114], v[9:16]// 000000B61514: CC404009 1C26D72B
	s_waitcnt lgkmcnt(0)                                       // 000000B6151C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[43:50], v[115:122], v[1:8]// 000000B61520: CC404001 1C06E72B
	v_mov_b32_e32 v44, v211                                    // 000000B61528: 7E5803D3
	v_mov_b32_e32 v45, v71                                     // 000000B6152C: 7E5A0347
	v_dual_mov_b32 v60, v66 :: v_dual_add_nc_u32 v167, s30, v98// 000000B61530: CA200142 3CA6C41E
	v_add_nc_u32_e32 v191, s31, v98                            // 000000B61538: 4B7EC41F
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000B6153C: D6220040 03FD0140 00006400
	v_and_b32_e32 v209, 0xffff, v209                           // 000000B61548: 37A3A2FF 0000FFFF
	v_pk_fma_f16 v204, v61, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000B61550: CC0E00CC 0BFC1B3D 0000C931
	v_pk_fma_f16 v205, v62, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000B6155C: CC0E00CD 0BFC1B3E 0000C931
	v_dual_mov_b32 v61, v196 :: v_dual_mov_b32 v62, v197       // 000000B61568: CA1001C4 3D3E01C5
	v_sad_u8 v212, v212, 0, 0x6400                             // 000000B61570: D62200D4 03FD01D4 00006400
	v_lshl_or_b32 v72, v72, 16, v214                           // 000000B6157C: D6560048 07592148
	v_permlanex16_b32 v44, v44, s21, 0xfedcba98                // 000000B61584: D65C002C 03FC2B2C FEDCBA98
	v_permlanex16_b32 v45, v45, s21, 0xfedcba98                // 000000B61590: D65C002D 03FC2B2D FEDCBA98
	v_lshl_or_b32 v64, v64, 16, v209                           // 000000B6159C: D6560040 07452140
	v_permlanex16_b32 v60, v60, s21, 0xfedcba98                // 000000B615A4: D65C003C 03FC2B3C FEDCBA98
	v_permlanex16_b32 v61, v61, s21, 0xfedcba98                // 000000B615B0: D65C003D 03FC2B3D FEDCBA98
	v_permlanex16_b32 v62, v62, s21, 0xfedcba98                // 000000B615BC: D65C003E 03FC2B3E FEDCBA98
	v_permlanex16_b32 v201, v201, s21, 0xfedcba98              // 000000B615C8: D65C00C9 03FC2BC9 FEDCBA98
	v_permlanex16_b32 v208, v208, s21, 0xfedcba98              // 000000B615D4: D65C00D0 03FC2BD0 FEDCBA98
	v_sad_u8 v213, v213, 0, 0x6400                             // 000000B615E0: D62200D5 03FD01D5 00006400
	v_and_b32_e32 v212, 0xffff, v212                           // 000000B615EC: 37A9A8FF 0000FFFF
	v_pk_fma_f16 v50, v72, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B615F4: CC0E0032 0BFC1B48 0000C931
	v_cndmask_b32_e64 v43, v44, v211, s3                       // 000000B61600: D501002B 000FA72C
	v_cndmask_b32_e64 v47, v211, v44, s3                       // 000000B61608: D501002F 000E59D3
	v_cndmask_b32_e64 v44, v45, v71, s3                        // 000000B61610: D501002C 000E8F2D
	v_cndmask_b32_e64 v48, v71, v45, s3                        // 000000B61618: D5010030 000E5B47
	s_waitcnt vmcnt(10)                                        // 000000B61620: BF892BF7
	.long 0xd73d0047                                           // 000000B61624: D73D0047
	v_cndmask_b32_e32 v1, v81, v67, vcc_lo                     // 000000B61628: 02028751
	v_pk_fma_f16 v206, v63, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000B6162C: CC0E00CE 0BFC1B3F 0000C931
	v_pk_fma_f16 v210, v64, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000B61638: CC0E00D2 0BFC1B40 0000C931
	v_cndmask_b32_e64 v59, v60, v66, s3                        // 000000B61644: D501003B 000E853C
	v_cndmask_b32_e64 v63, v66, v60, s3                        // 000000B6164C: D501003F 000E7942
	v_cndmask_b32_e64 v60, v61, v196, s3                       // 000000B61654: D501003C 000F893D
	v_cndmask_b32_e64 v64, v196, v61, s3                       // 000000B6165C: D5010040 000E7BC4
	v_cndmask_b32_e64 v61, v62, v197, s3                       // 000000B61664: D501003D 000F8B3E
	v_cndmask_b32_e64 v65, v197, v62, s3                       // 000000B6166C: D5010041 000E7DC5
	v_cndmask_b32_e64 v62, v201, v198, s3                      // 000000B61674: D501003E 000F8DC9
	v_cndmask_b32_e64 v66, v198, v201, s3                      // 000000B6167C: D5010042 000F93C6
	v_cndmask_b32_e64 v197, v208, v73, s3                      // 000000B61684: D50100C5 000E93D0
	v_cndmask_b32_e64 v201, v73, v208, s3                      // 000000B6168C: D50100C9 000FA149
	.long 0xd73d0048                                           // 000000B61694: D73D0048
	v_cndmask_b32_e32 v1, v82, v67, vcc_lo                     // 000000B61698: 02028752
	v_lshl_or_b32 v74, v213, 16, v212                          // 000000B6169C: D656004A 075121D5
	ds_load_b128 v[123:126], v143                              // 000000B616A4: DBFC0000 7B00008F
	ds_load_b128 v[127:130], v143 offset:16                    // 000000B616AC: DBFC0010 7F00008F
	ds_load_b128 v[131:134], v143 offset:4352                  // 000000B616B4: DBFC1100 8300008F
	ds_load_b128 v[135:138], v143 offset:4368                  // 000000B616BC: DBFC1110 8700008F
	ds_load_b128 v[139:142], v143 offset:8704                  // 000000B616C4: DBFC2200 8B00008F
	ds_load_b128 v[143:146], v143 offset:8720                  // 000000B616CC: DBFC2210 8F00008F
	ds_load_b128 v[147:150], v167                              // 000000B616D4: DBFC0000 930000A7
	ds_load_b128 v[151:154], v167 offset:16                    // 000000B616DC: DBFC0010 970000A7
	ds_load_b128 v[155:158], v167 offset:4352                  // 000000B616E4: DBFC1100 9B0000A7
	ds_load_b128 v[159:162], v167 offset:4368                  // 000000B616EC: DBFC1110 9F0000A7
	ds_load_b128 v[163:166], v167 offset:8704                  // 000000B616F4: DBFC2200 A30000A7
	ds_load_b128 v[167:170], v167 offset:8720                  // 000000B616FC: DBFC2210 A70000A7
	ds_load_b128 v[171:174], v191                              // 000000B61704: DBFC0000 AB0000BF
	ds_load_b128 v[175:178], v191 offset:16                    // 000000B6170C: DBFC0010 AF0000BF
	ds_load_b128 v[179:182], v191 offset:4352                  // 000000B61714: DBFC1100 B30000BF
	ds_load_b128 v[183:186], v191 offset:4368                  // 000000B6171C: DBFC1110 B70000BF
	ds_load_b128 v[187:190], v191 offset:8704                  // 000000B61724: DBFC2200 BB0000BF
	ds_load_b128 v[191:194], v191 offset:8720                  // 000000B6172C: DBFC2210 BF0000BF
	s_cselect_b32 s29, s23, 0x4480                             // 000000B61734: 981DFF17 00004480
	v_and_b32_e32 v118, 0xffff, v71                            // 000000B6173C: 36EC8EFF 0000FFFF
	s_waitcnt vmcnt(8)                                         // 000000B61744: BF8923F7
	.long 0xd73d0073                                           // 000000B61748: D73D0073
	v_cndmask_b32_e32 v1, v87, v69, vcc_lo                     // 000000B6174C: 02028B57
	v_and_b32_e32 v119, 0xffff, v72                            // 000000B61750: 36EE90FF 0000FFFF
	.long 0xd73d0047                                           // 000000B61758: D73D0047
	v_cndmask_b32_e32 v1, v83, v67, vcc_lo                     // 000000B6175C: 02028753
	v_pk_fma_f16 v46, v74, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B61760: CC0E002E 0BFC1B4A 0000C931
	v_add_nc_u32_e32 v74, s29, v98                             // 000000B6176C: 4A94C41D
	.long 0xd73d0048                                           // 000000B61770: D73D0048
	v_cndmask_b32_e32 v1, v85, v69, vcc_lo                     // 000000B61774: 02028B55
	.long 0xd73d0043                                           // 000000B61778: D73D0043
	v_cndmask_b32_e32 v1, v84, v67, vcc_lo                     // 000000B6177C: 02028754
	s_waitcnt lgkmcnt(16)                                      // 000000B61780: BF89FD07
	v_wmma_f32_16x16x16_f16 v[17:24], v[59:66], v[123:130], v[17:24]// 000000B61784: CC404011 1C46F73B
	s_waitcnt lgkmcnt(14)                                      // 000000B6178C: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[9:16], v[59:66], v[131:138], v[9:16]// 000000B61790: CC404009 1C27073B
	s_waitcnt lgkmcnt(12)                                      // 000000B61798: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[1:8], v[59:66], v[139:146], v[1:8]// 000000B6179C: CC404001 1C07173B
	ds_load_b128 v[59:62], v74                                 // 000000B617A4: DBFC0000 3B00004A
	ds_load_b128 v[63:66], v74 offset:16                       // 000000B617AC: DBFC0010 3F00004A
	ds_load_b128 v[99:102], v74 offset:4352                    // 000000B617B4: DBFC1100 6300004A
	ds_load_b128 v[103:106], v74 offset:4368                   // 000000B617BC: DBFC1110 6700004A
	ds_load_b128 v[107:110], v74 offset:8704                   // 000000B617C4: DBFC2200 6B00004A
	ds_load_b128 v[111:114], v74 offset:8720                   // 000000B617CC: DBFC2210 6F00004A
	.long 0xd73d0049                                           // 000000B617D4: D73D0049
	v_cndmask_b32_e32 v1, v86, v69, vcc_lo                     // 000000B617D8: 02028B56
	v_and_b32_e32 v71, 0xffff, v71                             // 000000B617DC: 368E8EFF 0000FFFF
	v_and_b32_e32 v72, 0xffff, v72                             // 000000B617E4: 369090FF 0000FFFF
	.long 0xd72c004a                                           // 000000B617EC: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000B617F0: 0202ECFF 83DCD12D
	v_dual_mov_b32 v209, v202 :: v_dual_and_b32 v116, 0xffff, v67// 000000B617F8: CA2401CA D17486FF 0000FFFF
	.long 0xd73d0043                                           // 000000B61804: D73D0043
	v_cndmask_b32_e32 v1, v88, v69, vcc_lo                     // 000000B61808: 02028B58
	v_and_b32_e32 v68, 0xffff, v73                             // 000000B6180C: 368892FF 0000FFFF
	v_and_b32_e32 v69, 0xffff, v115                            // 000000B61814: 368AE6FF 0000FFFF
	.long 0xd72c0046                                           // 000000B6181C: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000B61820: 02028EFF 83DCD12D
	.long 0xd72c0048                                           // 000000B61828: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000B6182C: 020290FF 83DCD12D
	v_dual_mov_b32 v212, v204 :: v_dual_mov_b32 v213, v205     // 000000B61834: CA1001CC D4D401CD
	v_mov_b32_e32 v214, v206                                   // 000000B6183C: 7FAC03CE
	v_mov_b32_e32 v215, v210                                   // 000000B61840: 7FAE03D2
	v_permlanex16_b32 v203, v203, s21, 0xfedcba98              // 000000B61844: D65C00CB 03FC2BCB FEDCBA98
	v_permlanex16_b32 v207, v207, s21, 0xfedcba98              // 000000B61850: D65C00CF 03FC2BCF FEDCBA98
	v_permlanex16_b32 v209, v209, s21, 0xfedcba98              // 000000B6185C: D65C00D1 03FC2BD1 FEDCBA98
	v_sad_u8 v71, v74, 0, 0x6400                               // 000000B61868: D6220047 03FD014A 00006400
	v_and_b32_e32 v67, 0xffff, v67                             // 000000B61874: 368686FF 0000FFFF
	.long 0xd72c0049                                           // 000000B6187C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000B61880: 0202EEFF 83DCD12D
	.long 0xd72c0045                                           // 000000B61888: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000B6188C: 02028AFF 83DCD12D
	.long 0xd72c004a                                           // 000000B61894: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 000000B61898: 0202E8FF 83DCD12D
	.long 0xd72c0044                                           // 000000B618A0: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000B618A4: 020288FF 83DCD12D
	v_permlanex16_b32 v212, v212, s21, 0xfedcba98              // 000000B618AC: D65C00D4 03FC2BD4 FEDCBA98
	v_permlanex16_b32 v213, v213, s21, 0xfedcba98              // 000000B618B8: D65C00D5 03FC2BD5 FEDCBA98
	v_permlanex16_b32 v214, v214, s21, 0xfedcba98              // 000000B618C4: D65C00D6 03FC2BD6 FEDCBA98
	v_permlanex16_b32 v215, v215, s21, 0xfedcba98              // 000000B618D0: D65C00D7 03FC2BD7 FEDCBA98
	v_cndmask_b32_e64 v195, v203, v199, s3                     // 000000B618DC: D50100C3 000F8FCB
	v_cndmask_b32_e64 v199, v199, v203, s3                     // 000000B618E4: D50100C7 000F97C7
	v_cndmask_b32_e64 v196, v207, v200, s3                     // 000000B618EC: D50100C4 000F91CF
	v_cndmask_b32_e64 v200, v200, v207, s3                     // 000000B618F4: D50100C8 000F9FC8
	v_cndmask_b32_e64 v198, v209, v202, s3                     // 000000B618FC: D50100C6 000F95D1
	v_cndmask_b32_e64 v202, v202, v209, s3                     // 000000B61904: D50100CA 000FA3CA
	v_mov_b32_e32 v49, v46                                     // 000000B6190C: 7E62032E
	v_mov_b32_e32 v117, v50                                    // 000000B61910: 7EEA0332
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000B61914: D6220046 03FD0146 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000B61920: D6220048 03FD0148 00006400
	.long 0xd72c0043                                           // 000000B6192C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000B61930: 020286FF 83DCD12D
	v_cndmask_b32_e64 v203, v212, v204, s3                     // 000000B61938: D50100CB 000F99D4
	v_cndmask_b32_e64 v207, v204, v212, s3                     // 000000B61940: D50100CF 000FA9CC
	v_cndmask_b32_e64 v204, v213, v205, s3                     // 000000B61948: D50100CC 000F9BD5
	v_cndmask_b32_e64 v208, v205, v213, s3                     // 000000B61950: D50100D0 000FABCD
	v_cndmask_b32_e64 v205, v214, v206, s3                     // 000000B61958: D50100CD 000F9DD6
	v_cndmask_b32_e64 v209, v206, v214, s3                     // 000000B61960: D50100D1 000FADCE
	v_cndmask_b32_e64 v206, v215, v210, s3                     // 000000B61968: D50100CE 000FA5D7
	v_cndmask_b32_e64 v210, v210, v215, s3                     // 000000B61970: D50100D2 000FAFD2
	s_waitcnt lgkmcnt(16)                                      // 000000B61978: BF89FD07
	v_wmma_f32_16x16x16_f16 v[17:24], v[195:202], v[147:154], v[17:24]// 000000B6197C: CC404011 1C4727C3
	v_permlanex16_b32 v49, v49, s21, 0xfedcba98                // 000000B61984: D65C0031 03FC2B31 FEDCBA98
	v_permlanex16_b32 v117, v117, s21, 0xfedcba98              // 000000B61990: D65C0075 03FC2B75 FEDCBA98
	v_and_b32_e32 v71, 0xffff, v71                             // 000000B6199C: 368E8EFF 0000FFFF
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000B619A4: D6220049 03FD0149 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000B619B0: D6220045 03FD0145 00006400
	v_and_b32_e32 v70, 0xffff, v70                             // 000000B619BC: 368C8CFF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000B619C4: D622004A 03FD014A 00006400
	v_and_b32_e32 v72, 0xffff, v72                             // 000000B619D0: 369090FF 0000FFFF
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000B619D8: D6220044 03FD0144 00006400
	s_waitcnt lgkmcnt(10)                                      // 000000B619E4: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[17:24], v[203:210], v[171:178], v[17:24]// 000000B619E8: CC404011 1C4757CB
	v_cndmask_b32_e64 v45, v49, v46, s3                        // 000000B619F0: D501002D 000E5D31
	v_cndmask_b32_e64 v49, v46, v49, s3                        // 000000B619F8: D5010031 000E632E
	v_cndmask_b32_e64 v46, v117, v50, s3                       // 000000B61A00: D501002E 000E6575
	v_and_b32_e32 v69, 0xffff, v69                             // 000000B61A08: 368A8AFF 0000FFFF
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000B61A10: D6220043 03FD0143 00006400
	v_lshl_or_b32 v71, v73, 16, v71                            // 000000B61A1C: D6560047 051D2149
	v_cndmask_b32_e64 v50, v50, v117, s3                       // 000000B61A24: D5010032 000EEB32
	v_lshl_or_b32 v70, v74, 16, v70                            // 000000B61A2C: D6560046 0519214A
	v_lshl_or_b32 v68, v68, 16, v72                            // 000000B61A34: D6560044 05212144
	v_wmma_f32_16x16x16_f16 v[1:8], v[195:202], v[163:170], v[1:8]// 000000B61A3C: CC404001 1C0747C3
	v_wmma_f32_16x16x16_f16 v[9:16], v[195:202], v[155:162], v[9:16]// 000000B61A44: CC404009 1C2737C3
	v_lshl_or_b32 v67, v67, 16, v69                            // 000000B61A4C: D6560043 05152143
	v_pk_fma_f16 v69, v71, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B61A54: CC0E0045 0BFC1B47 0000C931
	s_waitcnt lgkmcnt(4)                                       // 000000B61A60: BF89FC47
	v_wmma_f32_16x16x16_f16 v[17:24], v[43:50], v[59:66], v[17:24]// 000000B61A64: CC404011 1C46772B
	v_pk_fma_f16 v59, v70, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B61A6C: CC0E003B 0BFC1B46 0000C931
	v_pk_fma_f16 v60, v68, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B61A78: CC0E003C 0BFC1B44 0000C931
	v_wmma_f32_16x16x16_f16 v[1:8], v[203:210], v[187:194], v[1:8]// 000000B61A84: CC404001 1C0777CB
	v_wmma_f32_16x16x16_f16 v[9:16], v[203:210], v[179:186], v[9:16]// 000000B61A8C: CC404009 1C2767CB
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B61A94: BF870214
	v_dual_mov_b32 v61, v69 :: v_dual_mov_b32 v62, v59         // 000000B61A98: CA100145 3D3E013B
	v_mov_b32_e32 v63, v60                                     // 000000B61AA0: 7E7E033C
	s_waitcnt lgkmcnt(0)                                       // 000000B61AA4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[43:50], v[107:114], v[1:8]// 000000B61AA8: CC404001 1C06D72B
	s_cselect_b32 s29, s24, 0x44a0                             // 000000B61AB0: 981DFF18 000044A0
	s_waitcnt vmcnt(6)                                         // 000000B61AB8: BF891BF7
	.long 0xd73d006b                                           // 000000B61ABC: D73D006B
	v_cndmask_b32_e32 v1, v81, v53, vcc_lo                     // 000000B61AC0: 02026B51
	.long 0xd73d006c                                           // 000000B61AC4: D73D006C
	v_cndmask_b32_e32 v1, v82, v53, vcc_lo                     // 000000B61AC8: 02026B52
	v_wmma_f32_16x16x16_f16 v[9:16], v[43:50], v[99:106], v[9:16]// 000000B61ACC: CC404009 1C26C72B
	v_permlanex16_b32 v61, v61, s21, 0xfedcba98                // 000000B61AD4: D65C003D 03FC2B3D FEDCBA98
	v_permlanex16_b32 v62, v62, s21, 0xfedcba98                // 000000B61AE0: D65C003E 03FC2B3E FEDCBA98
	v_permlanex16_b32 v63, v63, s21, 0xfedcba98                // 000000B61AEC: D65C003F 03FC2B3F FEDCBA98
	v_add_nc_u32_e32 v50, s29, v98                             // 000000B61AF8: 4A64C41D
	v_pk_fma_f16 v115, v67, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000B61AFC: CC0E0073 0BFC1B43 0000C931
	v_cndmask_b32_e64 v43, v61, v69, s3                        // 000000B61B08: D501002B 000E8B3D
	v_cndmask_b32_e64 v47, v69, v61, s3                        // 000000B61B10: D501002F 000E7B45
	v_cndmask_b32_e64 v44, v62, v59, s3                        // 000000B61B18: D501002C 000E773E
	v_cndmask_b32_e64 v48, v59, v62, s3                        // 000000B61B20: D5010030 000E7D3B
	v_cndmask_b32_e64 v45, v63, v60, s3                        // 000000B61B28: D501002D 000E793F
	v_cndmask_b32_e64 v49, v60, v63, s3                        // 000000B61B30: D5010031 000E7F3C
	ds_load_b128 v[59:62], v50                                 // 000000B61B38: DBFC0000 3B000032
	ds_load_b128 v[63:66], v50 offset:16                       // 000000B61B40: DBFC0010 3F000032
	ds_load_b128 v[67:70], v50 offset:4352                     // 000000B61B48: DBFC1100 43000032
	ds_load_b128 v[71:74], v50 offset:4368                     // 000000B61B50: DBFC1110 47000032
	ds_load_b128 v[99:102], v50 offset:8704                    // 000000B61B58: DBFC2200 63000032
	ds_load_b128 v[103:106], v50 offset:8720                   // 000000B61B60: DBFC2210 67000032
	v_and_b32_e32 v50, 0xffff, v107                            // 000000B61B68: 3664D6FF 0000FFFF
	v_and_b32_e32 v112, 0xffff, v108                           // 000000B61B70: 36E0D8FF 0000FFFF
	.long 0xd73d006b                                           // 000000B61B78: D73D006B
	v_cndmask_b32_e32 v1, v83, v53, vcc_lo                     // 000000B61B7C: 02026B53
	s_waitcnt vmcnt(4)                                         // 000000B61B80: BF8913F7
	.long 0xd73d006c                                           // 000000B61B84: D73D006C
	v_cndmask_b32_e32 v1, v85, v51, vcc_lo                     // 000000B61B88: 02026755
	.long 0xd73d006d                                           // 000000B61B8C: D73D006D
	v_cndmask_b32_e32 v1, v86, v51, vcc_lo                     // 000000B61B90: 02026756
	.long 0xd73d0035                                           // 000000B61B94: D73D0035
	v_cndmask_b32_e32 v1, v84, v53, vcc_lo                     // 000000B61B98: 02026B54
	.long 0xd73d006e                                           // 000000B61B9C: D73D006E
	v_cndmask_b32_e32 v1, v87, v51, vcc_lo                     // 000000B61BA0: 02026757
	.long 0xd72c0036                                           // 000000B61BA4: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000B61BA8: 020264FF 83DCD12D
	v_and_b32_e32 v107, 0xffff, v107                           // 000000B61BB0: 36D6D6FF 0000FFFF
	.long 0xd73d0032                                           // 000000B61BB8: D73D0032
	v_cndmask_b32_e32 v1, v88, v51, vcc_lo                     // 000000B61BBC: 02026758
	v_and_b32_e32 v108, 0xffff, v108                           // 000000B61BC0: 36D8D8FF 0000FFFF
	v_and_b32_e32 v53, 0xffff, v53                             // 000000B61BC8: 366A6AFF 0000FFFF
	v_and_b32_e32 v52, 0xffff, v110                            // 000000B61BD0: 3668DCFF 0000FFFF
	.long 0xd72c006b                                           // 000000B61BD8: D72C006B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v107, vcc_lo             // 000000B61BDC: 0202D6FF 83DCD12D
	v_and_b32_e32 v51, 0xffff, v109                            // 000000B61BE4: 3666DAFF 0000FFFF
	.long 0xd72c006c                                           // 000000B61BEC: D72C006C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v108, vcc_lo             // 000000B61BF0: 0202D8FF 83DCD12D
	v_and_b32_e32 v50, 0xffff, v50                             // 000000B61BF8: 366464FF 0000FFFF
	.long 0xd72c006d                                           // 000000B61C00: D72C006D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v112, vcc_lo             // 000000B61C04: 0202E0FF 83DCD12D
	.long 0xd72c0034                                           // 000000B61C0C: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000B61C10: 020268FF 83DCD12D
	.long 0xd72c0035                                           // 000000B61C18: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000B61C1C: 02026AFF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000B61C24: D6220036 03FD0136 00006400
	v_sad_u8 v107, v107, 0, 0x6400                             // 000000B61C30: D622006B 03FD016B 00006400
	.long 0xd72c0033                                           // 000000B61C3C: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000B61C40: 020266FF 83DCD12D
	.long 0xd72c0032                                           // 000000B61C48: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000B61C4C: 020264FF 83DCD12D
	v_mov_b32_e32 v116, v115                                   // 000000B61C54: 7EE80373
	v_and_b32_e32 v54, 0xffff, v54                             // 000000B61C58: 366C6CFF 0000FFFF
	v_sad_u8 v108, v108, 0, 0x6400                             // 000000B61C60: D622006C 03FD016C 00006400
	v_sad_u8 v109, v109, 0, 0x6400                             // 000000B61C6C: D622006D 03FD016D 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000B61C78: D6220034 03FD0134 00006400
	v_and_b32_e32 v107, 0xffff, v107                           // 000000B61C84: 36D6D6FF 0000FFFF
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000B61C8C: D6220035 03FD0135 00006400
	v_permlanex16_b32 v116, v116, s21, 0xfedcba98              // 000000B61C98: D65C0074 03FC2B74 FEDCBA98
	v_and_b32_e32 v108, 0xffff, v108                           // 000000B61CA4: 36D8D8FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000B61CAC: D6220033 03FD0133 00006400
	v_and_b32_e32 v52, 0xffff, v52                             // 000000B61CB8: 366868FF 0000FFFF
	v_sad_u8 v110, v50, 0, 0x6400                              // 000000B61CC0: D622006E 03FD0132 00006400
	v_lshl_or_b32 v54, v109, 16, v54                           // 000000B61CCC: D6560036 04D9216D
	v_lshl_or_b32 v53, v53, 16, v107                           // 000000B61CD4: D6560035 05AD2135
	v_cndmask_b32_e64 v46, v116, v115, s3                      // 000000B61CDC: D501002E 000EE774
	v_cndmask_b32_e64 v50, v115, v116, s3                      // 000000B61CE4: D5010032 000EE973
	v_lshl_or_b32 v51, v51, 16, v108                           // 000000B61CEC: D6560033 05B12133
	v_lshl_or_b32 v52, v110, 16, v52                           // 000000B61CF4: D6560034 04D1216E
	v_pk_fma_f16 v54, v54, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B61CFC: CC0E0036 0BFC1B36 0000C931
	v_pk_fma_f16 v53, v53, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B61D08: CC0E0035 0BFC1B35 0000C931
	s_waitcnt lgkmcnt(4)                                       // 000000B61D14: BF89FC47
	v_wmma_f32_16x16x16_f16 v[17:24], v[43:50], v[59:66], v[17:24]// 000000B61D18: CC404011 1C46772B
	v_pk_fma_f16 v59, v51, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B61D20: CC0E003B 0BFC1B33 0000C931
	v_pk_fma_f16 v60, v52, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000B61D2C: CC0E003C 0BFC1B34 0000C931
	v_dual_mov_b32 v51, v54 :: v_dual_mov_b32 v52, v53         // 000000B61D38: CA100136 33340135
	s_waitcnt lgkmcnt(2)                                       // 000000B61D40: BF89FC27
	v_wmma_f32_16x16x16_f16 v[9:16], v[43:50], v[67:74], v[9:16]// 000000B61D44: CC404009 1C26872B
	s_waitcnt lgkmcnt(0)                                       // 000000B61D4C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[43:50], v[99:106], v[1:8]// 000000B61D50: CC404001 1C06C72B
	v_mov_b32_e32 v61, v59                                     // 000000B61D58: 7E7A033B
	v_permlanex16_b32 v51, v51, s21, 0xfedcba98                // 000000B61D5C: D65C0033 03FC2B33 FEDCBA98
	v_permlanex16_b32 v52, v52, s21, 0xfedcba98                // 000000B61D68: D65C0034 03FC2B34 FEDCBA98
	v_mov_b32_e32 v62, v60                                     // 000000B61D74: 7E7C033C
	s_cselect_b32 s29, s25, 0x44c0                             // 000000B61D78: 981DFF19 000044C0
	v_permlanex16_b32 v61, v61, s21, 0xfedcba98                // 000000B61D80: D65C003D 03FC2B3D FEDCBA98
	v_cndmask_b32_e64 v43, v51, v54, s3                        // 000000B61D8C: D501002B 000E6D33
	v_cndmask_b32_e64 v47, v54, v51, s3                        // 000000B61D94: D501002F 000E6736
	v_cndmask_b32_e64 v44, v52, v53, s3                        // 000000B61D9C: D501002C 000E6B34
	v_cndmask_b32_e64 v48, v53, v52, s3                        // 000000B61DA4: D5010030 000E6935
	s_waitcnt vmcnt(0)                                         // 000000B61DAC: BF8903F7
	.long 0xd73d0033                                           // 000000B61DB0: D73D0033
	v_cndmask_b32_e32 v1, v81, v57, vcc_lo                     // 000000B61DB4: 02027351
	v_permlanex16_b32 v62, v62, s21, 0xfedcba98                // 000000B61DB8: D65C003E 03FC2B3E FEDCBA98
	v_add_nc_u32_e32 v99, s29, v98                             // 000000B61DC4: 4AC6C41D
	s_and_b32 s29, s28, exec_lo                                // 000000B61DC8: 8B1D7E1C
	s_cselect_b32 s29, s26, 0x44e0                             // 000000B61DCC: 981DFF1A 000044E0
	v_cndmask_b32_e64 v45, v61, v59, s3                        // 000000B61DD4: D501002D 000E773D
	v_and_b32_e32 v67, 0xffff, v51                             // 000000B61DDC: 368666FF 0000FFFF
	.long 0xd73d0033                                           // 000000B61DE4: D73D0033
	v_cndmask_b32_e32 v1, v82, v57, vcc_lo                     // 000000B61DE8: 02027352
	.long 0xd73d0034                                           // 000000B61DEC: D73D0034
	v_cndmask_b32_e32 v1, v83, v57, vcc_lo                     // 000000B61DF0: 02027353
	.long 0xd73d0035                                           // 000000B61DF4: D73D0035
	v_cndmask_b32_e32 v1, v84, v57, vcc_lo                     // 000000B61DF8: 02027354
	v_cndmask_b32_e64 v49, v59, v61, s3                        // 000000B61DFC: D5010031 000E7B3B
	.long 0xd72c0039                                           // 000000B61E04: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000B61E08: 020286FF 83DCD12D
	v_cndmask_b32_e64 v46, v62, v60, s3                        // 000000B61E10: D501002E 000E793E
	v_and_b32_e32 v58, 0xffff, v51                             // 000000B61E18: 367466FF 0000FFFF
	v_and_b32_e32 v100, 0xffff, v52                            // 000000B61E20: 36C868FF 0000FFFF
	.long 0xd73d0033                                           // 000000B61E28: D73D0033
	v_cndmask_b32_e32 v1, v85, v55, vcc_lo                     // 000000B61E2C: 02026F55
	v_and_b32_e32 v101, 0xffff, v53                            // 000000B61E30: 36CA6AFF 0000FFFF
	.long 0xd73d0034                                           // 000000B61E38: D73D0034
	v_cndmask_b32_e32 v1, v86, v55, vcc_lo                     // 000000B61E3C: 02026F56
	.long 0xd73d0035                                           // 000000B61E40: D73D0035
	v_cndmask_b32_e32 v1, v87, v55, vcc_lo                     // 000000B61E44: 02026F57
	v_sad_u8 v54, v57, 0, 0x6400                               // 000000B61E48: D6220036 03FD0139 00006400
	.long 0xd72c0039                                           // 000000B61E54: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000B61E58: 020274FF 83DCD12D
	.long 0xd72c003a                                           // 000000B61E60: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 000000B61E64: 0202C8FF 83DCD12D
	v_and_b32_e32 v100, 0xffff, v51                            // 000000B61E6C: 36C866FF 0000FFFF
	v_and_b32_e32 v102, 0xffff, v52                            // 000000B61E74: 36CC68FF 0000FFFF
	.long 0xd73d0033                                           // 000000B61E7C: D73D0033
	v_cndmask_b32_e32 v1, v88, v55, vcc_lo                     // 000000B61E80: 02026F58
	v_and_b32_e32 v53, 0xffff, v53                             // 000000B61E84: 366A6AFF 0000FFFF
	v_and_b32_e32 v52, 0xffff, v54                             // 000000B61E8C: 36686CFF 0000FFFF
	.long 0xd72c0036                                           // 000000B61E94: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 000000B61E98: 0202C8FF 83DCD12D
	v_sad_u8 v55, v57, 0, 0x6400                               // 000000B61EA0: D6220037 03FD0139 00006400
	v_sad_u8 v56, v58, 0, 0x6400                               // 000000B61EAC: D6220038 03FD013A 00006400
	.long 0xd72c0035                                           // 000000B61EB8: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000B61EBC: 02026AFF 83DCD12D
	v_and_b32_e32 v51, 0xffff, v51                             // 000000B61EC4: 366666FF 0000FFFF
	.long 0xd72c0039                                           // 000000B61ECC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v101, vcc_lo             // 000000B61ED0: 0202CAFF 83DCD12D
	.long 0xd72c003a                                           // 000000B61ED8: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v102, vcc_lo             // 000000B61EDC: 0202CCFF 83DCD12D
	v_lshl_or_b32 v52, v55, 16, v52                            // 000000B61EE4: D6560034 04D12137
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000B61EEC: D6220036 03FD0136 00006400
	.long 0xd72c0033                                           // 000000B61EF8: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000B61EFC: 020266FF 83DCD12D
	v_and_b32_e32 v55, 0xffff, v56                             // 000000B61F04: 366E70FF 0000FFFF
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000B61F0C: D6220035 03FD0135 00006400
	v_cndmask_b32_e64 v50, v60, v62, s3                        // 000000B61F18: D5010032 000E7D3C
	v_sad_u8 v56, v57, 0, 0x6400                               // 000000B61F20: D6220038 03FD0139 00006400
	v_and_b32_e32 v54, 0xffff, v54                             // 000000B61F2C: 366C6CFF 0000FFFF
	v_sad_u8 v57, v58, 0, 0x6400                               // 000000B61F34: D6220039 03FD013A 00006400
	v_and_b32_e32 v101, 0xffff, v53                            // 000000B61F40: 36CA6AFF 0000FFFF
	v_sad_u8 v102, v51, 0, 0x6400                              // 000000B61F48: D6220066 03FD0133 00006400
	ds_load_b128 v[59:62], v99                                 // 000000B61F54: DBFC0000 3B000063
	ds_load_b128 v[63:66], v99 offset:16                       // 000000B61F5C: DBFC0010 3F000063
	ds_load_b128 v[67:70], v99 offset:4352                     // 000000B61F64: DBFC1100 43000063
	ds_load_b128 v[71:74], v99 offset:4368                     // 000000B61F6C: DBFC1110 47000063
	v_pk_fma_f16 v123, v52, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000B61F74: CC0E007B 0BFC1B34 0000C931
	v_lshl_or_b32 v100, v56, 16, v55                           // 000000B61F80: D6560064 04DD2138
	v_lshl_or_b32 v103, v57, 16, v54                           // 000000B61F88: D6560067 04D92139
	ds_load_b128 v[51:54], v99 offset:8704                     // 000000B61F90: DBFC2200 33000063
	ds_load_b128 v[55:58], v99 offset:8720                     // 000000B61F98: DBFC2210 37000063
	v_lshl_or_b32 v99, v102, 16, v101                          // 000000B61FA0: D6560063 05952166
	v_add_nc_u32_e32 v119, s29, v98                            // 000000B61FA8: 4AEEC41D
	v_pk_fma_f16 v124, v100, s13, 0xc931 op_sel_hi:[1,0,0]     // 000000B61FAC: CC0E007C 0BFC1B64 0000C931
	v_pk_fma_f16 v125, v103, s13, 0xc931 op_sel_hi:[1,0,0]     // 000000B61FB8: CC0E007D 0BFC1B67 0000C931
	v_mov_b32_e32 v126, v123                                   // 000000B61FC4: 7EFC037B
	v_pk_fma_f16 v127, v99, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000B61FC8: CC0E007F 0BFC1B63 0000C931
	ds_load_b128 v[99:102], v119                               // 000000B61FD4: DBFC0000 63000077
	ds_load_b128 v[103:106], v119 offset:16                    // 000000B61FDC: DBFC0010 67000077
	ds_load_b128 v[107:110], v119 offset:4352                  // 000000B61FE4: DBFC1100 6B000077
	ds_load_b128 v[111:114], v119 offset:4368                  // 000000B61FEC: DBFC1110 6F000077
	ds_load_b128 v[115:118], v119 offset:8704                  // 000000B61FF4: DBFC2200 73000077
	ds_load_b128 v[119:122], v119 offset:8720                  // 000000B61FFC: DBFC2210 77000077
	v_dual_mov_b32 v128, v124 :: v_dual_mov_b32 v129, v125     // 000000B62004: CA10017C 8080017D
	v_permlanex16_b32 v126, v126, s21, 0xfedcba98              // 000000B6200C: D65C007E 03FC2B7E FEDCBA98
	v_mov_b32_e32 v130, v127                                   // 000000B62018: 7F04037F
	s_and_not1_b32 vcc_lo, exec_lo, s27                        // 000000B6201C: 916A1B7E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000B62020: BF870003
	v_permlanex16_b32 v128, v128, s21, 0xfedcba98              // 000000B62024: D65C0080 03FC2B80 FEDCBA98
	v_permlanex16_b32 v129, v129, s21, 0xfedcba98              // 000000B62030: D65C0081 03FC2B81 FEDCBA98
	s_waitcnt lgkmcnt(10)                                      // 000000B6203C: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[17:24], v[43:50], v[59:66], v[17:24]// 000000B62040: CC404011 1C46772B
	v_permlanex16_b32 v130, v130, s21, 0xfedcba98              // 000000B62048: D65C0082 03FC2B82 FEDCBA98
	v_cndmask_b32_e64 v59, v126, v123, s3                      // 000000B62054: D501003B 000EF77E
	v_cndmask_b32_e64 v63, v123, v126, s3                      // 000000B6205C: D501003F 000EFD7B
	v_cndmask_b32_e64 v60, v128, v124, s3                      // 000000B62064: D501003C 000EF980
	v_cndmask_b32_e64 v64, v124, v128, s3                      // 000000B6206C: D5010040 000F017C
	v_cndmask_b32_e64 v61, v129, v125, s3                      // 000000B62074: D501003D 000EFB81
	v_cndmask_b32_e64 v65, v125, v129, s3                      // 000000B6207C: D5010041 000F037D
	v_cndmask_b32_e64 v62, v130, v127, s3                      // 000000B62084: D501003E 000EFF82
	v_cndmask_b32_e64 v66, v127, v130, s3                      // 000000B6208C: D5010042 000F057F
	s_waitcnt lgkmcnt(8)                                       // 000000B62094: BF89FC87
	v_wmma_f32_16x16x16_f16 v[9:16], v[43:50], v[67:74], v[9:16]// 000000B62098: CC404009 1C26872B
	s_waitcnt lgkmcnt(6)                                       // 000000B620A0: BF89FC67
	v_wmma_f32_16x16x16_f16 v[1:8], v[43:50], v[51:58], v[1:8] // 000000B620A4: CC404001 1C06672B
	s_waitcnt lgkmcnt(4)                                       // 000000B620AC: BF89FC47
	v_wmma_f32_16x16x16_f16 v[17:24], v[59:66], v[99:106], v[17:24]// 000000B620B0: CC404011 1C46C73B
	s_waitcnt lgkmcnt(2)                                       // 000000B620B8: BF89FC27
	v_wmma_f32_16x16x16_f16 v[9:16], v[59:66], v[107:114], v[9:16]// 000000B620BC: CC404009 1C26D73B
	s_waitcnt lgkmcnt(0)                                       // 000000B620C4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[59:66], v[115:122], v[1:8]// 000000B620C8: CC404001 1C06E73B
	s_cbranch_vccnz 64058                                      // 000000B620D0: BFA4FA3A <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x40bc>
	s_and_b32 s27, s28, exec_lo                                // 000000B620D4: 8B1B7E1C
	s_cselect_b32 s27, 0x4400, 0                               // 000000B620D8: 981B80FF 00004400
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000B620E0: BF870009
	v_lshl_or_b32 v43, v76, 1, s27                             // 000000B620E4: D656002B 006D034C
	s_and_saveexec_b32 s27, s0                                 // 000000B620EC: BE9B2000
	s_cbranch_execnz 7                                         // 000000B620F0: BFA60007 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5810>
	s_or_b32 exec_lo, exec_lo, s27                             // 000000B620F4: 8C7E1B7E
	s_and_saveexec_b32 s27, s1                                 // 000000B620F8: BE9B2001
	s_cbranch_execnz 11                                        // 000000B620FC: BFA6000B <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x582c>
	s_or_b32 exec_lo, exec_lo, s27                             // 000000B62100: 8C7E1B7E
	s_and_saveexec_b32 s27, s2                                 // 000000B62104: BE9B2002
	s_cbranch_execz 64043                                      // 000000B62108: BFA5FA2B <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x40b8>
	s_branch 13                                                // 000000B6210C: BFA0000D <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5844>
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B62110: BF870001
	v_add_nc_u32_e32 v44, v43, v80                             // 000000B62114: 4A58A12B
	ds_store_b128 v44, v[25:28]                                // 000000B62118: DB7C0000 0000192C
	s_or_b32 exec_lo, exec_lo, s27                             // 000000B62120: 8C7E1B7E
	s_and_saveexec_b32 s27, s1                                 // 000000B62124: BE9B2001
	s_cbranch_execz 65525                                      // 000000B62128: BFA5FFF5 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5800>
	v_add_nc_u32_e32 v44, v43, v89                             // 000000B6212C: 4A58B32B
	ds_store_b128 v44, v[29:32]                                // 000000B62130: DB7C0000 00001D2C
	s_or_b32 exec_lo, exec_lo, s27                             // 000000B62138: 8C7E1B7E
	s_and_saveexec_b32 s27, s2                                 // 000000B6213C: BE9B2002
	s_cbranch_execz 64029                                      // 000000B62140: BFA5FA1D <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x40b8>
	v_lshl_add_u32 v43, v79, 1, v43                            // 000000B62144: D646002B 04AD034F
	ds_store_b128 v43, v[33:36]                                // 000000B6214C: DB7C0000 0000212B
	s_branch 64024                                             // 000000B62154: BFA0FA18 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x40b8>
	s_mul_i32 s0, s16, 0x1400                                  // 000000B62158: 9600FF10 00001400
	s_mul_hi_i32 s1, s16, 0x1400                               // 000000B62160: 9701FF10 00001400
	s_add_u32 s2, s14, s0                                      // 000000B62168: 8002000E
	s_addc_u32 s3, s15, s1                                     // 000000B6216C: 8203010F
	s_lshl_b32 s0, s17, 7                                      // 000000B62170: 84008711
	v_and_b32_e32 v26, 1, v0                                   // 000000B62174: 36340081
	s_ashr_i32 s1, s0, 31                                      // 000000B62178: 86019F00
	v_and_b32_e32 v27, 2, v0                                   // 000000B6217C: 36360082
	s_lshl_b64 s[4:5], s[0:1], 1                               // 000000B62180: 84848100
	v_lshrrev_b32_e32 v30, 2, v77                              // 000000B62184: 323C9A82
	s_add_u32 s12, s2, s4                                      // 000000B62188: 800C0402
	s_addc_u32 s13, s3, s5                                     // 000000B6218C: 820D0503
	.long 0xd44a0003                                           // 000000B62190: D44A0003
	v_cndmask_b32_e32 v1, 0, v26, vcc_lo                       // 000000B62194: 02023480
	v_lshlrev_b32_e32 v26, 6, v75                              // 000000B62198: 30349686
	.long 0xd44a0002                                           // 000000B6219C: D44A0002
	v_cndmask_b32_e32 v1, 0, v27, vcc_lo                       // 000000B621A0: 02023680
	v_and_b32_e32 v27, 4, v0                                   // 000000B621A4: 36360084
	v_and_b32_e32 v28, 8, v0                                   // 000000B621A8: 36380088
	v_lshlrev_b32_e32 v25, 2, v77                              // 000000B621AC: 30329A82
	v_mad_u32_u24 v26, 0x210, v78, v26                         // 000000B621B0: D60B001A 046A9CFF 00000210
	v_and_b32_e32 v29, 16, v0                                  // 000000B621BC: 363A0090
	.long 0xd44a0001                                           // 000000B621C0: D44A0001
	v_cndmask_b32_e32 v1, 0, v27, vcc_lo                       // 000000B621C4: 02023680
	v_lshlrev_b32_e32 v27, 3, v77                              // 000000B621C8: 30369A83
	.long 0xd44a0000                                           // 000000B621CC: D44A0000
	v_cndmask_b32_e32 v1, 0, v28, vcc_lo                       // 000000B621D0: 02023880
	v_and_or_b32 v26, v30, 4, v26                              // 000000B621D4: D657001A 0469091E
	v_cmp_eq_u32_e32 vcc_lo, 0, v29                            // 000000B621DC: 7C943A80
	ds_store_2addr_b32 v26, v17, v18 offset1:2                 // 000000B621E0: D8380200 0012111A
	ds_store_2addr_b32 v26, v19, v20 offset0:4 offset1:6       // 000000B621E8: D8380604 0014131A
	ds_store_2addr_b32 v26, v21, v22 offset0:8 offset1:10      // 000000B621F0: D8380A08 0016151A
	.long 0xd700151b                                           // 000000B621F8: D700151B
	v_cndmask_b32_e32 v1, s6, v27, vcc_lo                      // 000000B621FC: 02023606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B62200: BF8701A1
	v_add_co_ci_u32_e64 v28, null, s7, 0, s21                  // 000000B62204: D5207C1C 00550007
	v_mul_u32_u24_e32 v20, 0x210, v75                          // 000000B6220C: 162896FF 00000210
	.long 0xd7000411                                           // 000000B62214: D7000411
	v_cndmask_b32_e32 v0, v27, v4, vcc_lo                      // 000000B62218: 0200091B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B6221C: BF870001
	v_add_co_ci_u32_e64 v18, null, s5, v28, s4                 // 000000B62220: D5207C12 00123805
	v_lshlrev_b32_e32 v19, 1, v25                              // 000000B62228: 30263281
	s_mov_b32 s5, exec_lo                                      // 000000B6222C: BE85007E
	ds_store_2addr_b32 v26, v23, v24 offset0:12 offset1:14     // 000000B62230: D8380E0C 0018171A
	s_waitcnt lgkmcnt(0)                                       // 000000B62238: BF89FC07
	s_barrier                                                  // 000000B6223C: BFBD0000
	buffer_gl0_inv                                             // 000000B62240: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000B62248: D4C4007E
	v_cndmask_b32_e32 v1, s19, v75, vcc_lo                     // 000000B6224C: 02029613
	s_cbranch_execz 201                                        // 000000B62250: BFA500C9 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5c78>
	global_load_b64 v[27:28], v19, s[12:13]                    // 000000B62254: DC560000 1B0C0013
	v_lshl_add_u32 v21, v25, 2, v20                            // 000000B6225C: D6460015 04510519
	s_mov_b32 s4, 0x76543210                                   // 000000B62264: BE8400FF 76543210
	ds_load_b128 v[21:24], v21                                 // 000000B6226C: DBFC0000 15000015
	s_waitcnt lgkmcnt(0)                                       // 000000B62274: BF89FC07
	v_dual_add_f32 v29, v21, v22 :: v_dual_add_f32 v30, v23, v24// 000000B62278: C9082D15 1D1E3117
	v_dual_sub_f32 v21, v21, v22 :: v_dual_sub_f32 v22, v23, v24// 000000B62280: C94A2D15 15163117
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B62288: BF8701A2
	v_sub_f32_e32 v24, v29, v30                                // 000000B6228C: 08303D1D
	v_add_f32_e32 v23, v29, v30                                // 000000B62290: 062E3D1D
	v_add_f32_e32 v29, v21, v22                                // 000000B62294: 063A2D15
	v_sub_f32_e32 v21, v21, v22                                // 000000B62298: 082A2D15
	s_delay_alu instid0(VALU_DEP_4)                            // 000000B6229C: BF870004
	v_mov_b32_dpp v30, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B622A0: 7E3C02FA FF016118
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000B622A8: D5010018 200E3118
	v_mov_b32_dpp v22, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B622B0: 7E2C02FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s3                       // 000000B622B8: D5010017 200E2F17
	v_mov_b32_dpp v31, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B622C0: 7E3E02FA FF01611D
	v_mov_b32_dpp v32, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B622C8: 7E4002FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000B622D0: D5010015 200E2B15
	v_cndmask_b32_e64 v29, -v29, v29, s3                       // 000000B622D8: D501001D 200E3B1D
	v_add_f32_e32 v24, v24, v30                                // 000000B622E0: 06303D18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B622E4: BF870193
	v_dual_add_f32 v22, v23, v22 :: v_dual_add_f32 v21, v21, v32// 000000B622E8: C9082D17 16144115
	v_add_f32_e32 v23, v29, v31                                // 000000B622F0: 062E3F1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B622F4: BF870223
	v_mov_b32_dpp v29, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B622F8: 7E3A02FA FF016218
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 000000B62300: D5010018 200A3118
	v_mov_b32_dpp v30, v22 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B62308: 7E3C02FA FF016216
	v_mov_b32_dpp v31, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B62310: 7E3E02FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000B62318: D5010015 200A2B15
	v_cndmask_b32_e64 v22, -v22, v22, s2                       // 000000B62320: D5010016 200A2D16
	v_add_f32_e32 v24, v24, v29                                // 000000B62328: 06303B18
	v_mov_b32_dpp v29, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B6232C: 7E3A02FA FF016217
	v_cndmask_b32_e64 v23, -v23, v23, s2                       // 000000B62334: D5010017 200A2F17
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B6233C: BF870214
	v_dual_add_f32 v21, v21, v31 :: v_dual_add_f32 v22, v22, v30// 000000B62340: C9083F15 15163D16
	v_mov_b32_dpp v30, v24 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B62348: 7E3C02FA FF016418
	v_cndmask_b32_e64 v24, -v24, v24, s1                       // 000000B62350: D5010018 20063118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B62358: BF870214
	v_add_f32_e32 v23, v23, v29                                // 000000B6235C: 062E3B17
	v_mov_b32_dpp v29, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B62360: 7E3A02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000B62368: D5010015 20062B15
	v_mov_b32_dpp v31, v22 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B62370: 7E3E02FA FF016416
	v_add_f32_e32 v24, v24, v30                                // 000000B62378: 06303D18
	v_cndmask_b32_e64 v22, -v22, v22, s1                       // 000000B6237C: D5010016 20062D16
	v_mov_b32_dpp v30, v23 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B62384: 7E3C02FA FF016417
	v_add_f32_e32 v21, v21, v29                                // 000000B6238C: 062A3B15
	v_cndmask_b32_e64 v23, -v23, v23, s1                       // 000000B62390: D5010017 20062F17
	v_mov_b32_dpp v29, v24 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B62398: 7E3A02FA FF016818
	v_cndmask_b32_e64 v24, -v24, v24, s0                       // 000000B623A0: D5010018 20023118
	v_add_f32_e32 v22, v22, v31                                // 000000B623A8: 062C3F16
	v_mov_b32_dpp v31, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B623AC: 7E3E02FA FF016815
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000B623B4: D5010015 20022B15
	.long 0x7f403880                                           // 000000B623BC: 7F403880
	v_dual_add_f32 v24, v24, v29 :: v_dual_add_f32 v23, v23, v30// 000000B623C0: C9083B18 18163D17
	v_mov_b32_dpp v29, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B623C8: 7E3A02FA FF016816
	v_cndmask_b32_e64 v22, -v22, v22, s0                       // 000000B623D0: D5010016 20022D16
	s_delay_alu instid0(VALU_DEP_3)                            // 000000B623D8: BF870003
	v_dual_add_f32 v21, v21, v31 :: v_dual_mov_b32 v30, v24    // 000000B623DC: C9103F15 151E0118
	v_cndmask_b32_e64 v24, -v24, v24, vcc_lo                   // 000000B623E4: D5010018 21AA3118
	v_mov_b32_dpp v31, v23 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B623EC: 7E3E02FA FF016817
	v_cndmask_b32_e64 v23, -v23, v23, s0                       // 000000B623F4: D5010017 20022F17
	v_add_f32_e32 v22, v22, v29                                // 000000B623FC: 062C3B16
	v_permlanex16_b32 v30, v30, s4, 0xfedcba98                 // 000000B62400: D65C001E 03FC091E FEDCBA98
	v_mov_b32_e32 v33, v21                                     // 000000B6240C: 7E420315
	v_cndmask_b32_e64 v21, -v21, v21, vcc_lo                   // 000000B62410: D5010015 21AA2B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B62418: BF870193
	v_dual_add_f32 v24, v24, v30 :: v_dual_add_f32 v23, v23, v31// 000000B6241C: C9083D18 18163F17
	v_permlanex16_b32 v33, v33, s4, 0xfedcba98                 // 000000B62424: D65C0021 03FC0921 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B62430: BF870192
	v_dual_mul_f32 v24, 0x3db504f3, v24 :: v_dual_mov_b32 v29, v22// 000000B62434: C8D030FF 181C0116 3DB504F3
	v_mov_b32_e32 v30, v23                                     // 000000B62440: 7E3C0317
	v_cndmask_b32_e64 v22, -v22, v22, vcc_lo                   // 000000B62444: D5010016 21AA2D16
	v_cndmask_b32_e64 v23, -v23, v23, vcc_lo                   // 000000B6244C: D5010017 21AA2F17
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B62454: BF870214
	v_permlanex16_b32 v29, v29, s4, 0xfedcba98                 // 000000B62458: D65C001D 03FC091D FEDCBA98
	v_permlanex16_b32 v30, v30, s4, 0xfedcba98                 // 000000B62464: D65C001E 03FC091E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B62470: BF870121
	v_dual_add_f32 v22, v22, v29 :: v_dual_add_f32 v23, v23, v30// 000000B62474: C9083B16 16163D17
	.long 0x7f3a39a0                                           // 000000B6247C: 7F3A39A0
	v_dual_add_f32 v21, v21, v33 :: v_dual_mul_f32 v22, 0x3db504f3, v22// 000000B62480: C9064315 15162CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B6248C: BF870113
	v_mul_f32_e32 v23, 0x3db504f3, v23                         // 000000B62490: 102E2EFF 3DB504F3
	v_mul_f32_e32 v21, 0x3db504f3, v21                         // 000000B62498: 102A2AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B624A0: BF8903F7
	v_fma_mix_f32 v24, v28, v24, neg(0) op_sel_hi:[1,0,0]      // 000000B624A4: CC200018 8A02311C
	v_fma_mix_f32 v22, v27, v22, neg(0) op_sel_hi:[1,0,0]      // 000000B624AC: CC200016 8A022D1B
	v_fma_mix_f32 v23, v27, v23, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B624B4: CC200817 8A022F1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B624BC: BF870113
	.long 0x7e3a3998                                           // 000000B624C0: 7E3A3998
	v_bfe_u32 v30, v23, 16, 1                                  // 000000B624C4: D610001E 02052117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B624CC: BF870112
	v_and_b32_e32 v29, 1, v29                                  // 000000B624D0: 363A3A81
	v_add3_u32 v23, v23, v30, 0x7fff                           // 000000B624D4: D6550017 03FE3D17 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B624E0: BF870122
	v_add3_u32 v24, v24, v29, 0x7fff                           // 000000B624E4: D6550018 03FE3B18 00007FFF
	.long 0x7f3a39a0                                           // 000000B624F0: 7F3A39A0
	.long 0x7e3a3998                                           // 000000B624F4: 7E3A3998
	v_add_nc_u32_e32 v24, s18, v75                             // 000000B624F8: 4A309612
	v_fma_mix_f32 v21, v28, v21, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B624FC: CC200815 8A022B1C
	.long 0x7f3839a0                                           // 000000B62504: 7F3839A0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B62508: BF870092
	.long 0x7e383995                                           // 000000B6250C: 7E383995
	v_and_b32_e32 v27, 1, v28                                  // 000000B62510: 36363881
	v_bfe_u32 v28, v22, 16, 1                                  // 000000B62514: D610001C 02052116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B6251C: BF870112
	v_add3_u32 v21, v21, v27, 0x7fff                           // 000000B62520: D6550015 03FE3715 00007FFF
	v_add3_u32 v22, v22, v28, 0x7fff                           // 000000B6252C: D6550016 03FE3916 00007FFF
	v_and_b32_e32 v28, 0xffff, v29                             // 000000B62538: 36383AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B62540: BF870193
	v_and_b32_e32 v27, 0xffff0000, v21                         // 000000B62544: 36362AFF FFFF0000
	.long 0x7e403996                                           // 000000B6254C: 7E403996
	v_mad_i64_i32 v[21:22], null, 0x1400, v24, v[17:18]        // 000000B62550: D6FF7C15 044630FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B6255C: BF870193
	v_or_b32_e32 v24, v27, v28                                 // 000000B62560: 3830391B
	v_and_or_b32 v23, 0xffff0000, v23, v32                     // 000000B62564: D6570017 04822EFF FFFF0000
	global_store_b64 v[21:22], v[23:24], off                   // 000000B62570: DC6E0000 007C1715
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B62578: 8C7E057E
	v_or_b32_e32 v22, 8, v75                                   // 000000B6257C: 382C9688
	s_mov_b32 s5, exec_lo                                      // 000000B62580: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B62584: BF870001
	v_mul_u32_u24_e32 v21, 0x210, v22                          // 000000B62588: 162A2CFF 00000210
	.long 0xd4c4007e                                           // 000000B62590: D4C4007E
	v_cndmask_b32_e32 v1, s19, v22, vcc_lo                     // 000000B62594: 02022C13
	s_cbranch_execz 199                                        // 000000B62598: BFA500C7 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5fb8>
	global_load_b64 v[23:24], v19, s[12:13]                    // 000000B6259C: DC560000 170C0013
	v_lshl_add_u32 v27, v25, 2, v21                            // 000000B625A4: D646001B 04550519
	s_mov_b32 s4, 0x76543210                                   // 000000B625AC: BE8400FF 76543210
	v_add_nc_u32_e32 v22, s18, v22                             // 000000B625B4: 4A2C2C12
	ds_load_b128 v[27:30], v27                                 // 000000B625B8: DBFC0000 1B00001B
	s_waitcnt lgkmcnt(0)                                       // 000000B625C0: BF89FC07
	v_dual_add_f32 v31, v27, v28 :: v_dual_add_f32 v32, v29, v30// 000000B625C4: C908391B 1F203D1D
	v_dual_sub_f32 v27, v27, v28 :: v_dual_sub_f32 v28, v29, v30// 000000B625CC: C94A391B 1B1C3D1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B625D4: BF8701A2
	v_sub_f32_e32 v30, v31, v32                                // 000000B625D8: 083C411F
	v_add_f32_e32 v29, v31, v32                                // 000000B625DC: 063A411F
	v_add_f32_e32 v31, v27, v28                                // 000000B625E0: 063E391B
	v_sub_f32_e32 v27, v27, v28                                // 000000B625E4: 0836391B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000B625E8: BF870004
	v_mov_b32_dpp v32, v30 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B625EC: 7E4002FA FF01611E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000B625F4: D501001E 200E3D1E
	v_mov_b32_dpp v28, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B625FC: 7E3802FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s3                       // 000000B62604: D501001D 200E3B1D
	v_mov_b32_dpp v33, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B6260C: 7E4202FA FF01611F
	v_mov_b32_dpp v34, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B62614: 7E4402FA FF01611B
	v_cndmask_b32_e64 v27, -v27, v27, s3                       // 000000B6261C: D501001B 200E371B
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000B62624: D501001F 200E3F1F
	v_add_f32_e32 v30, v30, v32                                // 000000B6262C: 063C411E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B62630: BF870193
	v_dual_add_f32 v28, v29, v28 :: v_dual_add_f32 v27, v27, v34// 000000B62634: C908391D 1C1A451B
	v_add_f32_e32 v29, v31, v33                                // 000000B6263C: 063A431F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B62640: BF870223
	v_mov_b32_dpp v31, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B62644: 7E3E02FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s2                       // 000000B6264C: D501001E 200A3D1E
	v_mov_b32_dpp v32, v28 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B62654: 7E4002FA FF01621C
	v_mov_b32_dpp v33, v27 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B6265C: 7E4202FA FF01621B
	v_cndmask_b32_e64 v27, -v27, v27, s2                       // 000000B62664: D501001B 200A371B
	v_cndmask_b32_e64 v28, -v28, v28, s2                       // 000000B6266C: D501001C 200A391C
	v_add_f32_e32 v30, v30, v31                                // 000000B62674: 063C3F1E
	v_mov_b32_dpp v31, v29 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B62678: 7E3E02FA FF01621D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000B62680: D501001D 200A3B1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B62688: BF870214
	v_dual_add_f32 v27, v27, v33 :: v_dual_add_f32 v28, v28, v32// 000000B6268C: C908431B 1B1C411C
	v_mov_b32_dpp v32, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B62694: 7E4002FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000B6269C: D501001E 20063D1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B626A4: BF870214
	v_add_f32_e32 v29, v29, v31                                // 000000B626A8: 063A3F1D
	v_mov_b32_dpp v31, v27 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B626AC: 7E3E02FA FF01641B
	v_cndmask_b32_e64 v27, -v27, v27, s1                       // 000000B626B4: D501001B 2006371B
	v_mov_b32_dpp v33, v28 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B626BC: 7E4202FA FF01641C
	v_add_f32_e32 v30, v30, v32                                // 000000B626C4: 063C411E
	v_cndmask_b32_e64 v28, -v28, v28, s1                       // 000000B626C8: D501001C 2006391C
	v_mov_b32_dpp v32, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B626D0: 7E4002FA FF01641D
	v_add_f32_e32 v27, v27, v31                                // 000000B626D8: 06363F1B
	v_cndmask_b32_e64 v29, -v29, v29, s1                       // 000000B626DC: D501001D 20063B1D
	v_mov_b32_dpp v31, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B626E4: 7E3E02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s0                       // 000000B626EC: D501001E 20023D1E
	v_add_f32_e32 v28, v28, v33                                // 000000B626F4: 0638431C
	v_mov_b32_dpp v33, v27 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B626F8: 7E4202FA FF01681B
	v_cndmask_b32_e64 v27, -v27, v27, s0                       // 000000B62700: D501001B 2002371B
	.long 0x7f443880                                           // 000000B62708: 7F443880
	v_dual_add_f32 v30, v30, v31 :: v_dual_add_f32 v29, v29, v32// 000000B6270C: C9083F1E 1E1C411D
	v_mov_b32_dpp v31, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B62714: 7E3E02FA FF01681C
	v_cndmask_b32_e64 v28, -v28, v28, s0                       // 000000B6271C: D501001C 2002391C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000B62724: BF870003
	v_dual_add_f32 v27, v27, v33 :: v_dual_mov_b32 v32, v30    // 000000B62728: C910431B 1B20011E
	v_cndmask_b32_e64 v30, -v30, v30, vcc_lo                   // 000000B62730: D501001E 21AA3D1E
	v_mov_b32_dpp v33, v29 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B62738: 7E4202FA FF01681D
	v_cndmask_b32_e64 v29, -v29, v29, s0                       // 000000B62740: D501001D 20023B1D
	v_add_f32_e32 v28, v28, v31                                // 000000B62748: 06383F1C
	v_permlanex16_b32 v32, v32, s4, 0xfedcba98                 // 000000B6274C: D65C0020 03FC0920 FEDCBA98
	v_mov_b32_e32 v35, v27                                     // 000000B62758: 7E46031B
	v_cndmask_b32_e64 v27, -v27, v27, vcc_lo                   // 000000B6275C: D501001B 21AA371B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B62764: BF870193
	v_dual_add_f32 v30, v30, v32 :: v_dual_add_f32 v29, v29, v33// 000000B62768: C908411E 1E1C431D
	v_permlanex16_b32 v35, v35, s4, 0xfedcba98                 // 000000B62770: D65C0023 03FC0923 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B6277C: BF870192
	v_dual_mul_f32 v30, 0x3db504f3, v30 :: v_dual_mov_b32 v31, v28// 000000B62780: C8D03CFF 1E1E011C 3DB504F3
	v_mov_b32_e32 v32, v29                                     // 000000B6278C: 7E40031D
	v_cndmask_b32_e64 v28, -v28, v28, vcc_lo                   // 000000B62790: D501001C 21AA391C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B62798: BF870244
	v_add_f32_e32 v27, v27, v35                                // 000000B6279C: 0636471B
	v_cndmask_b32_e64 v29, -v29, v29, vcc_lo                   // 000000B627A0: D501001D 21AA3B1D
	v_permlanex16_b32 v31, v31, s4, 0xfedcba98                 // 000000B627A8: D65C001F 03FC091F FEDCBA98
	v_permlanex16_b32 v32, v32, s4, 0xfedcba98                 // 000000B627B4: D65C0020 03FC0920 FEDCBA98
	v_mul_f32_e32 v27, 0x3db504f3, v27                         // 000000B627C0: 103636FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B627C8: BF870122
	v_dual_add_f32 v28, v28, v31 :: v_dual_add_f32 v29, v29, v32// 000000B627CC: C9083F1C 1C1C411D
	.long 0x7f3e39a2                                           // 000000B627D4: 7F3E39A2
	v_mul_f32_e32 v29, 0x3db504f3, v29                         // 000000B627D8: 103A3AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B627E0: BF8903F7
	v_fma_mix_f32 v30, v24, v30, neg(0) op_sel_hi:[1,0,0]      // 000000B627E4: CC20001E 8A023D18
	v_fma_mix_f32 v24, v24, v27, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B627EC: CC200818 8A023718
	v_mul_f32_e32 v27, 0x3db504f3, v28                         // 000000B627F4: 103638FF 3DB504F3
	.long 0x7f3839a2                                           // 000000B627FC: 7F3839A2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B62800: BF870214
	.long 0x7e3e399e                                           // 000000B62804: 7E3E399E
	.long 0x7e383998                                           // 000000B62808: 7E383998
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B6280C: BF870224
	v_fma_mix_f32 v27, v23, v27, neg(0) op_sel_hi:[1,0,0]      // 000000B62810: CC20001B 8A023717
	v_fma_mix_f32 v23, v23, v29, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B62818: CC200817 8A023B17
	v_and_b32_e32 v31, 1, v31                                  // 000000B62820: 363E3E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B62824: BF870194
	v_and_b32_e32 v28, 1, v28                                  // 000000B62828: 36383881
	v_bfe_u32 v32, v23, 16, 1                                  // 000000B6282C: D6100020 02052117
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B62834: BF870243
	v_add3_u32 v29, v30, v31, 0x7fff                           // 000000B62838: D655001D 03FE3F1E 00007FFF
	v_bfe_u32 v30, v27, 16, 1                                  // 000000B62844: D610001E 0205211B
	.long 0x7f3e39a2                                           // 000000B6284C: 7F3E39A2
	v_add3_u32 v24, v24, v28, 0x7fff                           // 000000B62850: D6550018 03FE3918 00007FFF
	.long 0x7e3e399d                                           // 000000B6285C: 7E3E399D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B62860: BF870224
	v_add3_u32 v27, v27, v30, 0x7fff                           // 000000B62864: D655001B 03FE3D1B 00007FFF
	v_add3_u32 v29, v23, v32, 0x7fff                           // 000000B62870: D655001D 03FE4117 00007FFF
	v_and_b32_e32 v24, 0xffff0000, v24                         // 000000B6287C: 363030FF FFFF0000
	v_mad_i64_i32 v[22:23], null, 0x1400, v22, v[17:18]        // 000000B62884: D6FF7C16 04462CFF 00001400
	v_and_b32_e32 v28, 0xffff, v31                             // 000000B62890: 36383EFF 0000FFFF
	.long 0x7e44399b                                           // 000000B62898: 7E44399B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B6289C: BF870112
	v_or_b32_e32 v28, v24, v28                                 // 000000B628A0: 38383918
	v_and_or_b32 v27, 0xffff0000, v29, v34                     // 000000B628A4: D657001B 048A3AFF FFFF0000
	global_store_b64 v[22:23], v[27:28], off                   // 000000B628B0: DC6E0000 007C1B16
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B628B8: 8C7E057E
	v_or_b32_e32 v22, 16, v75                                  // 000000B628BC: 382C9690
	s_mov_b32 s5, exec_lo                                      // 000000B628C0: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000B628C4: BC7C0000
	s_barrier                                                  // 000000B628C8: BFBD0000
	buffer_gl0_inv                                             // 000000B628CC: E0AC0000 00000000
	ds_store_2addr_b32 v26, v9, v10 offset1:2                  // 000000B628D4: D8380200 000A091A
	ds_store_2addr_b32 v26, v11, v12 offset0:4 offset1:6       // 000000B628DC: D8380604 000C0B1A
	ds_store_2addr_b32 v26, v13, v14 offset0:8 offset1:10      // 000000B628E4: D8380A08 000E0D1A
	ds_store_2addr_b32 v26, v15, v16 offset0:12 offset1:14     // 000000B628EC: D8380E0C 00100F1A
	s_waitcnt lgkmcnt(0)                                       // 000000B628F4: BF89FC07
	s_barrier                                                  // 000000B628F8: BFBD0000
	buffer_gl0_inv                                             // 000000B628FC: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000B62904: D4C4007E
	v_cndmask_b32_e32 v1, s19, v22, vcc_lo                     // 000000B62908: 02022C13
	s_cbranch_execz 201                                        // 000000B6290C: BFA500C9 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6334>
	global_load_b64 v[13:14], v19, s[12:13]                    // 000000B62910: DC560000 0D0C0013
	v_lshl_add_u32 v9, v25, 2, v20                             // 000000B62918: D6460009 04510519
	s_mov_b32 s4, 0x76543210                                   // 000000B62920: BE8400FF 76543210
	ds_load_b128 v[9:12], v9                                   // 000000B62928: DBFC0000 09000009
	s_waitcnt lgkmcnt(0)                                       // 000000B62930: BF89FC07
	v_dual_add_f32 v15, v9, v10 :: v_dual_add_f32 v16, v11, v12// 000000B62934: C9081509 0F10190B
	v_dual_sub_f32 v9, v9, v10 :: v_dual_sub_f32 v10, v11, v12 // 000000B6293C: C94A1509 090A190B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B62944: BF870112
	v_add_f32_e32 v11, v15, v16                                // 000000B62948: 0616210F
	v_dual_sub_f32 v12, v15, v16 :: v_dual_add_f32 v15, v9, v10// 000000B6294C: C948210F 0C0E1509
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B62954: BF870001
	v_mov_b32_dpp v16, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B62958: 7E2002FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000B62960: D501000C 200E190C
	v_sub_f32_e32 v9, v9, v10                                  // 000000B62968: 08121509
	v_mov_b32_dpp v10, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B6296C: 7E1402FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000B62974: D501000B 200E170B
	v_mov_b32_dpp v23, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B6297C: 7E2E02FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 000000B62984: D501000F 200E1F0F
	v_add_f32_e32 v12, v12, v16                                // 000000B6298C: 0618210C
	v_mov_b32_dpp v24, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B62990: 7E3002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000B62998: D5010009 200E1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B629A0: BF870091
	v_dual_add_f32 v10, v11, v10 :: v_dual_add_f32 v9, v9, v24 // 000000B629A4: C908150B 0A083109
	v_mov_b32_dpp v16, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B629AC: 7E2002FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000B629B4: D501000A 200A150A
	v_add_f32_e32 v11, v15, v23                                // 000000B629BC: 06162F0F
	v_mov_b32_dpp v15, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B629C0: 7E1E02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000B629C8: D501000C 200A190C
	v_mov_b32_dpp v23, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B629D0: 7E2E02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000B629D8: D5010009 200A1309
	v_add_f32_e32 v10, v10, v16                                // 000000B629E0: 0614210A
	.long 0x7f303880                                           // 000000B629E4: 7F303880
	v_add_f32_e32 v12, v12, v15                                // 000000B629E8: 06181F0C
	v_mov_b32_dpp v15, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B629EC: 7E1E02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000B629F4: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B629FC: BF870233
	v_mov_b32_dpp v16, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B62A00: 7E2002FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000B62A08: D501000C 2006190C
	v_add_f32_e32 v9, v9, v23                                  // 000000B62A10: 06122F09
	v_add_f32_e32 v11, v11, v15                                // 000000B62A14: 06161F0B
	v_mov_b32_dpp v23, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B62A18: 7E2E02FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000B62A20: D501000A 2006150A
	v_add_f32_e32 v12, v12, v16                                // 000000B62A28: 0618210C
	v_mov_b32_dpp v15, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B62A2C: 7E1E02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000B62A34: D5010009 20061309
	v_mov_b32_dpp v16, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B62A3C: 7E2002FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000B62A44: D501000B 2006170B
	v_add_f32_e32 v10, v10, v23                                // 000000B62A4C: 06142F0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B62A50: BF8700B4
	v_add_f32_e32 v9, v9, v15                                  // 000000B62A54: 06121F09
	v_mov_b32_dpp v15, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B62A58: 7E1E02FA FF01680C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000B62A60: D501000C 2002190C
	v_dual_add_f32 v11, v11, v16 :: v_dual_add_f32 v12, v12, v15// 000000B62A68: C908210B 0B0C1F0C
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B62A70: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000B62A78: D501000A 2002150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B62A80: BF870123
	v_mov_b32_e32 v16, v12                                     // 000000B62A84: 7E20030C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000B62A88: D501000C 21AA190C
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000B62A90: D65C0010 03FC0910 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B62A9C: BF8700B1
	v_add_f32_e32 v12, v12, v16                                // 000000B62AA0: 0618210C
	v_mov_b32_dpp v23, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B62AA4: 7E2E02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000B62AAC: D5010009 20021309
	v_dual_mul_f32 v12, 0x3db504f3, v12 :: v_dual_add_f32 v9, v9, v23// 000000B62AB4: C8C818FF 0C082F09 3DB504F3
	v_mov_b32_dpp v23, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B62AC0: 7E2E02FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000B62AC8: D501000B 2002170B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B62AD0: BF870091
	v_add_f32_e32 v11, v11, v23                                // 000000B62AD4: 06162F0B
	v_dual_mov_b32 v16, v11 :: v_dual_mov_b32 v27, v9          // 000000B62AD8: CA10010B 101A0109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000B62AE0: D5010009 21AA1309
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000B62AE8: D501000B 21AA170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B62AF0: BF870213
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000B62AF4: D65C0010 03FC0910 FEDCBA98
	v_permlanex16_b32 v27, v27, s4, 0xfedcba98                 // 000000B62B00: D65C001B 03FC091B FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B62B0C: BF870112
	v_add_f32_e32 v11, v11, v16                                // 000000B62B10: 0616210B
	v_add_f32_e32 v9, v9, v27                                  // 000000B62B14: 06123709
	v_add_f32_e32 v10, v10, v15                                // 000000B62B18: 06141F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B62B1C: BF870193
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000B62B20: 101616FF 3DB504F3
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000B62B28: 101212FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B62B30: BF870123
	v_mov_b32_e32 v15, v10                                     // 000000B62B34: 7E1E030A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000B62B38: D501000A 21AA150A
	v_permlanex16_b32 v15, v15, s4, 0xfedcba98                 // 000000B62B40: D65C000F 03FC090F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B62B4C: BF870121
	v_add_f32_e32 v10, v10, v15                                // 000000B62B50: 06141F0A
	.long 0x7f1e3998                                           // 000000B62B54: 7F1E3998
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000B62B58: 101414FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B62B60: BF8903F7
	v_fma_mix_f32 v12, v14, v12, neg(0) op_sel_hi:[1,0,0]      // 000000B62B64: CC20000C 8A02190E
	v_fma_mix_f32 v9, v14, v9, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B62B6C: CC200809 8A02130E
	.long 0x7f1c3998                                           // 000000B62B74: 7F1C3998
	v_fma_mix_f32 v10, v13, v10, neg(0) op_sel_hi:[1,0,0]      // 000000B62B78: CC20000A 8A02150D
	v_fma_mix_f32 v11, v13, v11, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B62B80: CC20080B 8A02170D
	.long 0x7e1e398c                                           // 000000B62B88: 7E1E398C
	.long 0x7e1c3989                                           // 000000B62B8C: 7E1C3989
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B62B90: BF870193
	v_bfe_u32 v16, v11, 16, 1                                  // 000000B62B94: D6100010 0205210B
	v_and_b32_e32 v15, 1, v15                                  // 000000B62B9C: 361E1E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B62BA0: BF870223
	v_and_b32_e32 v13, 1, v14                                  // 000000B62BA4: 361A1C81
	v_bfe_u32 v14, v10, 16, 1                                  // 000000B62BA8: D610000E 0205210A
	v_add3_u32 v11, v11, v16, 0x7fff                           // 000000B62BB0: D655000B 03FE210B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B62BBC: BF870244
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000B62BC0: D655000C 03FE1F0C 00007FFF
	.long 0x7f1e3998                                           // 000000B62BCC: 7F1E3998
	v_add3_u32 v9, v9, v13, 0x7fff                             // 000000B62BD0: D6550009 03FE1B09 00007FFF
	v_add3_u32 v10, v10, v14, 0x7fff                           // 000000B62BDC: D655000A 03FE1D0A 00007FFF
	.long 0x7e1e398c                                           // 000000B62BE8: 7E1E398C
	v_add_nc_u32_e32 v12, s18, v22                             // 000000B62BEC: 4A182C12
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B62BF0: BF870214
	v_and_b32_e32 v13, 0xffff0000, v9                          // 000000B62BF4: 361A12FF FFFF0000
	.long 0x7e30398a                                           // 000000B62BFC: 7E30398A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B62C00: BF870214
	v_and_b32_e32 v14, 0xffff, v15                             // 000000B62C04: 361C1EFF 0000FFFF
	v_mad_i64_i32 v[9:10], null, 0x1400, v12, v[17:18]         // 000000B62C0C: D6FF7C09 044618FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B62C18: BF870193
	v_and_or_b32 v11, 0xffff0000, v11, v24                     // 000000B62C1C: D657000B 046216FF FFFF0000
	v_or_b32_e32 v12, v13, v14                                 // 000000B62C28: 38181D0D
	global_store_b64 v[9:10], v[11:12], off                    // 000000B62C2C: DC6E0000 007C0B09
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B62C34: 8C7E057E
	v_or_b32_e32 v9, 24, v75                                   // 000000B62C38: 38129698
	s_mov_b32 s5, exec_lo                                      // 000000B62C3C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B62C40: BF870001
	.long 0xd4c4007e                                           // 000000B62C44: D4C4007E
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 000000B62C48: 02021213
	s_cbranch_execz 205                                        // 000000B62C4C: BFA500CD <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6684>
	global_load_b64 v[14:15], v19, s[12:13]                    // 000000B62C50: DC560000 0E0C0013
	v_lshl_add_u32 v10, v25, 2, v21                            // 000000B62C58: D646000A 04550519
	s_mov_b32 s4, 0x76543210                                   // 000000B62C60: BE8400FF 76543210
	v_add_nc_u32_e32 v9, s18, v9                               // 000000B62C68: 4A121212
	ds_load_b128 v[10:13], v10                                 // 000000B62C6C: DBFC0000 0A00000A
	s_waitcnt lgkmcnt(0)                                       // 000000B62C74: BF89FC07
	v_add_f32_e32 v16, v10, v11                                // 000000B62C78: 0620170A
	v_add_f32_e32 v22, v12, v13                                // 000000B62C7C: 062C1B0C
	v_dual_sub_f32 v10, v10, v11 :: v_dual_sub_f32 v11, v12, v13// 000000B62C80: C94A170A 0A0A1B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B62C88: BF8700A2
	v_add_f32_e32 v12, v16, v22                                // 000000B62C8C: 06182D10
	v_sub_f32_e32 v13, v16, v22                                // 000000B62C90: 081A2D10
	v_mov_b32_dpp v22, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B62C94: 7E2C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000B62C9C: D501000D 200E1B0D
	v_add_f32_e32 v16, v10, v11                                // 000000B62CA4: 0620170A
	v_sub_f32_e32 v10, v10, v11                                // 000000B62CA8: 0814170A
	v_mov_b32_dpp v11, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B62CAC: 7E1602FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000B62CB4: D501000C 200E190C
	v_add_f32_e32 v13, v13, v22                                // 000000B62CBC: 061A2D0D
	v_mov_b32_dpp v23, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B62CC0: 7E2E02FA FF016110
	v_cndmask_b32_e64 v16, -v16, v16, s3                       // 000000B62CC8: D5010010 200E2110
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B62CD0: BF870114
	v_add_f32_e32 v11, v12, v11                                // 000000B62CD4: 0616170C
	v_add_f32_e32 v12, v16, v23                                // 000000B62CD8: 06182F10
	v_mov_b32_dpp v16, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B62CDC: 7E2002FA FF01620D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000B62CE4: BF870133
	v_mov_b32_dpp v22, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B62CE8: 7E2C02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000B62CF0: D501000B 200A170B
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000B62CF8: D501000D 200A1B0D
	v_add_f32_e32 v11, v11, v22                                // 000000B62D00: 06162D0B
	v_mov_b32_dpp v24, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B62D04: 7E3002FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000B62D0C: D501000A 200E150A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B62D14: BF870114
	v_add_f32_e32 v13, v13, v16                                // 000000B62D18: 061A210D
	v_add_f32_e32 v10, v10, v24                                // 000000B62D1C: 0614310A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B62D20: BF870232
	v_mov_b32_dpp v22, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B62D24: 7E2C02FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000B62D2C: D501000D 20061B0D
	.long 0x7f303880                                           // 000000B62D34: 7F303880
	v_mov_b32_dpp v23, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B62D38: 7E2E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000B62D40: D501000A 200A150A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B62D48: BF870234
	v_add_f32_e32 v13, v13, v22                                // 000000B62D4C: 061A2D0D
	v_mov_b32_dpp v16, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B62D50: 7E2002FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000B62D58: D501000C 200A190C
	v_add_f32_e32 v10, v10, v23                                // 000000B62D60: 06142F0A
	v_mov_b32_dpp v23, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B62D64: 7E2E02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000B62D6C: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B62D74: BF870214
	v_add_f32_e32 v12, v12, v16                                // 000000B62D78: 0618210C
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B62D7C: 7E2002FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000B62D84: D501000A 2006150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B62D8C: BF8701B1
	v_dual_add_f32 v11, v11, v23 :: v_dual_add_f32 v10, v10, v16// 000000B62D90: C9082F0B 0B0A210A
	v_mov_b32_dpp v16, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B62D98: 7E2002FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000B62DA0: D501000D 20021B0D
	v_mov_b32_dpp v23, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B62DA8: 7E2E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000B62DB0: D501000A 2002150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B62DB8: BF8700B3
	v_add_f32_e32 v13, v13, v16                                // 000000B62DBC: 061A210D
	v_mov_b32_dpp v16, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B62DC0: 7E2002FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000B62DC8: D501000B 2002170B
	v_dual_add_f32 v10, v10, v23 :: v_dual_add_f32 v11, v11, v16// 000000B62DD0: C9082F0A 0A0A210B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B62DD8: BF870231
	v_mov_b32_e32 v27, v10                                     // 000000B62DDC: 7E36030A
	v_mov_b32_dpp v22, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B62DE0: 7E2C02FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000B62DE8: D501000C 2006190C
	v_mov_b32_e32 v16, v11                                     // 000000B62DF0: 7E20030B
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000B62DF4: D501000B 21AA170B
	v_permlanex16_b32 v27, v27, s4, 0xfedcba98                 // 000000B62DFC: D65C001B 03FC091B FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B62E08: BF870214
	v_add_f32_e32 v12, v12, v22                                // 000000B62E0C: 06182D0C
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000B62E10: D65C0010 03FC0910 FEDCBA98
	v_mov_b32_e32 v22, v13                                     // 000000B62E1C: 7E2C030D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000B62E20: D501000D 21AA1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B62E28: BF870214
	v_mov_b32_dpp v23, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B62E2C: 7E2E02FA FF01680C
	v_add_f32_e32 v11, v11, v16                                // 000000B62E34: 0616210B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B62E38: BF870234
	v_permlanex16_b32 v22, v22, s4, 0xfedcba98                 // 000000B62E3C: D65C0016 03FC0916 FEDCBA98
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000B62E48: D501000C 2002190C
	.long 0x7f203998                                           // 000000B62E50: 7F203998
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000B62E54: 101616FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B62E5C: BF870093
	v_dual_add_f32 v13, v13, v22 :: v_dual_add_f32 v12, v12, v23// 000000B62E60: C9082D0D 0D0C2F0C
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 000000B62E68: 101A1AFF 3DB504F3
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000B62E70: D501000A 21AA150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B62E78: BF8701A3
	v_mov_b32_e32 v22, v12                                     // 000000B62E7C: 7E2C030C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000B62E80: D501000C 21AA190C
	v_add_f32_e32 v10, v10, v27                                // 000000B62E88: 0614370A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B62E8C: BF870113
	v_permlanex16_b32 v22, v22, s4, 0xfedcba98                 // 000000B62E90: D65C0016 03FC0916 FEDCBA98
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000B62E9C: 101414FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B62EA4: BF870092
	v_add_f32_e32 v12, v12, v22                                // 000000B62EA8: 06182D0C
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000B62EAC: 101818FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B62EB4: BF8903F7
	v_fma_mix_f32 v13, v15, v13, neg(0) op_sel_hi:[1,0,0]      // 000000B62EB8: CC20000D 8A021B0F
	v_fma_mix_f32 v10, v15, v10, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B62EC0: CC20080A 8A02150F
	.long 0x7f1e3998                                           // 000000B62EC8: 7F1E3998
	v_fma_mix_f32 v11, v14, v11, neg(0) op_sel_hi:[1,0,0]      // 000000B62ECC: CC20000B 8A02170E
	v_fma_mix_f32 v12, v14, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B62ED4: CC20080C 8A02190E
	.long 0x7e20398d                                           // 000000B62EDC: 7E20398D
	.long 0x7e1e398a                                           // 000000B62EE0: 7E1E398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B62EE4: BF870193
	v_bfe_u32 v22, v12, 16, 1                                  // 000000B62EE8: D6100016 0205210C
	v_and_b32_e32 v16, 1, v16                                  // 000000B62EF0: 36202081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B62EF4: BF8701A3
	v_and_b32_e32 v14, 1, v15                                  // 000000B62EF8: 361C1E81
	v_bfe_u32 v15, v11, 16, 1                                  // 000000B62EFC: D610000F 0205210B
	v_add3_u32 v13, v13, v16, 0x7fff                           // 000000B62F04: D655000D 03FE210D 00007FFF
	.long 0x7f203998                                           // 000000B62F10: 7F203998
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B62F14: BF870214
	v_add3_u32 v10, v10, v14, 0x7fff                           // 000000B62F18: D655000A 03FE1D0A 00007FFF
	v_add3_u32 v11, v11, v15, 0x7fff                           // 000000B62F24: D655000B 03FE1F0B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B62F30: BF870224
	.long 0x7e20398d                                           // 000000B62F34: 7E20398D
	v_add3_u32 v13, v12, v22, 0x7fff                           // 000000B62F38: D655000D 03FE2D0C 00007FFF
	v_and_b32_e32 v12, 0xffff0000, v10                         // 000000B62F44: 361814FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B62F4C: BF8701B4
	.long 0x7e30398b                                           // 000000B62F50: 7E30398B
	v_mad_i64_i32 v[9:10], null, 0x1400, v9, v[17:18]          // 000000B62F54: D6FF7C09 044612FF 00001400
	v_and_b32_e32 v14, 0xffff, v16                             // 000000B62F60: 361C20FF 0000FFFF
	v_and_or_b32 v11, 0xffff0000, v13, v24                     // 000000B62F68: D657000B 04621AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000B62F74: BF870002
	v_or_b32_e32 v12, v12, v14                                 // 000000B62F78: 38181D0C
	global_store_b64 v[9:10], v[11:12], off                    // 000000B62F7C: DC6E0000 007C0B09
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B62F84: 8C7E057E
	v_or_b32_e32 v9, 32, v75                                   // 000000B62F88: 381296A0
	s_mov_b32 s5, exec_lo                                      // 000000B62F8C: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000B62F90: BC7C0000
	s_barrier                                                  // 000000B62F94: BFBD0000
	buffer_gl0_inv                                             // 000000B62F98: E0AC0000 00000000
	ds_store_2addr_b32 v26, v1, v2 offset1:2                   // 000000B62FA0: D8380200 0002011A
	ds_store_2addr_b32 v26, v3, v4 offset0:4 offset1:6         // 000000B62FA8: D8380604 0004031A
	ds_store_2addr_b32 v26, v5, v6 offset0:8 offset1:10        // 000000B62FB0: D8380A08 0006051A
	ds_store_2addr_b32 v26, v7, v8 offset0:12 offset1:14       // 000000B62FB8: D8380E0C 0008071A
	s_waitcnt lgkmcnt(0)                                       // 000000B62FC0: BF89FC07
	s_barrier                                                  // 000000B62FC4: BFBD0000
	buffer_gl0_inv                                             // 000000B62FC8: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000B62FD0: D4C4007E
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 000000B62FD4: 02021213
	s_cbranch_execz 200                                        // 000000B62FD8: BFA500C8 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x69fc>
	global_load_b64 v[5:6], v19, s[12:13]                      // 000000B62FDC: DC560000 050C0013
	v_lshl_add_u32 v1, v25, 2, v20                             // 000000B62FE4: D6460001 04510519
	s_mov_b32 s4, 0x76543210                                   // 000000B62FEC: BE8400FF 76543210
	ds_load_b128 v[1:4], v1                                    // 000000B62FF4: DBFC0000 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000B62FFC: BF89FC07
	v_dual_add_f32 v7, v1, v2 :: v_dual_add_f32 v8, v3, v4     // 000000B63000: C9080501 07080903
	v_dual_sub_f32 v1, v1, v2 :: v_dual_sub_f32 v2, v3, v4     // 000000B63008: C94A0501 01020903
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B63010: BF870112
	v_add_f32_e32 v3, v7, v8                                   // 000000B63014: 06061107
	v_dual_sub_f32 v4, v7, v8 :: v_dual_add_f32 v7, v1, v2     // 000000B63018: C9481107 04060501
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B63020: BF870001
	v_mov_b32_dpp v8, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B63024: 7E1002FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000B6302C: D5010004 200E0904
	v_sub_f32_e32 v1, v1, v2                                   // 000000B63034: 08020501
	v_mov_b32_dpp v2, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B63038: 7E0402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000B63040: D5010003 200E0703
	v_mov_b32_dpp v10, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B63048: 7E1402FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000B63050: D5010007 200E0F07
	v_add_f32_e32 v4, v4, v8                                   // 000000B63058: 06081104
	v_mov_b32_dpp v11, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B6305C: 7E1602FA FF016101
	v_cndmask_b32_e64 v1, -v1, v1, s3                          // 000000B63064: D5010001 200E0301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B6306C: BF870091
	v_dual_add_f32 v2, v3, v2 :: v_dual_add_f32 v1, v1, v11    // 000000B63070: C9080503 02001701
	v_mov_b32_dpp v8, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B63078: 7E1002FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000B63080: D5010002 200A0502
	v_add_f32_e32 v3, v7, v10                                  // 000000B63088: 06061507
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B6308C: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000B63094: D5010004 200A0904
	v_mov_b32_dpp v10, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B6309C: 7E1402FA FF016201
	v_cndmask_b32_e64 v1, -v1, v1, s2                          // 000000B630A4: D5010001 200A0301
	v_add_f32_e32 v2, v2, v8                                   // 000000B630AC: 06041102
	.long 0x7f163880                                           // 000000B630B0: 7F163880
	v_add_f32_e32 v4, v4, v7                                   // 000000B630B4: 06080F04
	v_mov_b32_dpp v7, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B630B8: 7E0E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000B630C0: D5010003 200A0703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000B630C8: BF870253
	v_mov_b32_dpp v8, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B630CC: 7E1002FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000B630D4: D5010004 20060904
	v_add_f32_e32 v1, v1, v10                                  // 000000B630DC: 06021501
	v_mov_b32_dpp v10, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B630E0: 7E1402FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000B630E8: D5010002 20060502
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v4, v8     // 000000B630F0: C9080F03 03041104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B630F8: BF870224
	v_mov_b32_dpp v7, v1 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B630FC: 7E0E02FA FF016401
	v_cndmask_b32_e64 v1, -v1, v1, s1                          // 000000B63104: D5010001 20060301
	v_add_f32_e32 v2, v2, v10                                  // 000000B6310C: 06041502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B63110: BF870224
	v_mov_b32_dpp v8, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B63114: 7E1002FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000B6311C: D5010003 20060703
	v_add_f32_e32 v1, v1, v7                                   // 000000B63124: 06020F01
	v_mov_b32_dpp v7, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B63128: 7E0E02FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000B63130: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B63138: BF8701B1
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v4, v4, v7     // 000000B6313C: C9081103 03040F04
	v_mov_b32_dpp v7, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B63144: 7E0E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000B6314C: D5010002 20020502
	v_mov_b32_e32 v8, v4                                       // 000000B63154: 7E100304
	v_mov_b32_dpp v10, v1 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B63158: 7E1402FA FF016801
	v_cndmask_b32_e64 v1, -v1, v1, s0                          // 000000B63160: D5010001 20020301
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000B63168: D5010004 21AA0904
	v_add_f32_e32 v2, v2, v7                                   // 000000B63170: 06040F02
	v_permlanex16_b32 v8, v8, s4, 0xfedcba98                   // 000000B63174: D65C0008 03FC0908 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B63180: BF870234
	v_add_f32_e32 v1, v1, v10                                  // 000000B63184: 06021501
	v_mov_b32_dpp v10, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B63188: 7E1402FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000B63190: D5010003 20020703
	v_dual_add_f32 v4, v4, v8 :: v_dual_mov_b32 v7, v2         // 000000B63198: C9101104 04060102
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B631A0: BF870224
	v_mov_b32_e32 v12, v1                                      // 000000B631A4: 7E180301
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 000000B631A8: D5010001 21AA0301
	v_add_f32_e32 v3, v3, v10                                  // 000000B631B0: 06061503
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000B631B4: D5010002 21AA0502
	v_permlanex16_b32 v7, v7, s4, 0xfedcba98                   // 000000B631BC: D65C0007 03FC0907 FEDCBA98
	v_permlanex16_b32 v12, v12, s4, 0xfedcba98                 // 000000B631C8: D65C000C 03FC090C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B631D4: BF8701A4
	v_mov_b32_e32 v8, v3                                       // 000000B631D8: 7E100303
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000B631DC: D5010003 21AA0703
	v_add_f32_e32 v1, v1, v12                                  // 000000B631E4: 06021901
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000B631E8: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000B631F0: BF8701C4
	v_permlanex16_b32 v8, v8, s4, 0xfedcba98                   // 000000B631F4: D65C0008 03FC0908 FEDCBA98
	v_add_f32_e32 v2, v2, v7                                   // 000000B63200: 06040F02
	.long 0x7f0e398b                                           // 000000B63204: 7F0E398B
	v_mul_f32_e32 v1, 0x3db504f3, v1                           // 000000B63208: 100202FF 3DB504F3
	v_dual_add_f32 v3, v3, v8 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 000000B63210: C9061103 030204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B6321C: BF870001
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 000000B63220: 100606FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B63228: BF8903F7
	v_fma_mix_f32 v4, v6, v4, neg(0) op_sel_hi:[1,0,0]         // 000000B6322C: CC200004 8A020906
	v_fma_mix_f32 v1, v6, v1, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B63234: CC200801 8A020306
	.long 0x7f0c398b                                           // 000000B6323C: 7F0C398B
	v_fma_mix_f32 v2, v5, v2, neg(0) op_sel_hi:[1,0,0]         // 000000B63240: CC200002 8A020505
	v_fma_mix_f32 v3, v5, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B63248: CC200803 8A020705
	.long 0x7e0e3984                                           // 000000B63250: 7E0E3984
	.long 0x7e0c3981                                           // 000000B63254: 7E0C3981
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B63258: BF870193
	v_bfe_u32 v8, v3, 16, 1                                    // 000000B6325C: D6100008 02052103
	v_and_b32_e32 v7, 1, v7                                    // 000000B63264: 360E0E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B63268: BF870223
	v_and_b32_e32 v5, 1, v6                                    // 000000B6326C: 360A0C81
	v_bfe_u32 v6, v2, 16, 1                                    // 000000B63270: D6100006 02052102
	v_add3_u32 v3, v3, v8, 0x7fff                              // 000000B63278: D6550003 03FE1103 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B63284: BF870244
	v_add3_u32 v4, v4, v7, 0x7fff                              // 000000B63288: D6550004 03FE0F04 00007FFF
	.long 0x7f0e398b                                           // 000000B63294: 7F0E398B
	v_add3_u32 v1, v1, v5, 0x7fff                              // 000000B63298: D6550001 03FE0B01 00007FFF
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000B632A4: D6550002 03FE0D02 00007FFF
	.long 0x7e0e3984                                           // 000000B632B0: 7E0E3984
	v_add_nc_u32_e32 v4, s18, v9                               // 000000B632B4: 4A081212
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B632B8: BF870214
	v_and_b32_e32 v5, 0xffff0000, v1                           // 000000B632BC: 360A02FF FFFF0000
	.long 0x7e163982                                           // 000000B632C4: 7E163982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B632C8: BF870214
	v_and_b32_e32 v6, 0xffff, v7                               // 000000B632CC: 360C0EFF 0000FFFF
	v_mad_i64_i32 v[1:2], null, 0x1400, v4, v[17:18]           // 000000B632D4: D6FF7C01 044608FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B632E0: BF870193
	v_and_or_b32 v3, 0xffff0000, v3, v11                       // 000000B632E4: D6570003 042E06FF FFFF0000
	v_or_b32_e32 v4, v5, v6                                    // 000000B632F0: 38080D05
	global_store_b64 v[1:2], v[3:4], off                       // 000000B632F4: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B632FC: 8C7E057E
	v_or_b32_e32 v1, 40, v75                                   // 000000B63300: 380296A8
	s_mov_b32 s5, exec_lo                                      // 000000B63304: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B63308: BF870001
	.long 0xd4c4007e                                           // 000000B6330C: D4C4007E
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 000000B63310: 02020213
	s_cbranch_execz 202                                        // 000000B63314: BFA500CA <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6d40>
	global_load_b64 v[6:7], v19, s[12:13]                      // 000000B63318: DC560000 060C0013
	v_lshl_add_u32 v2, v25, 2, v21                             // 000000B63320: D6460002 04550519
	v_add_nc_u32_e32 v1, s18, v1                               // 000000B63328: 4A020212
	ds_load_b128 v[2:5], v2                                    // 000000B6332C: DBFC0000 02000002
	s_waitcnt lgkmcnt(0)                                       // 000000B63334: BF89FC07
	v_dual_add_f32 v8, v2, v3 :: v_dual_add_f32 v9, v4, v5     // 000000B63338: C9080702 08080B04
	v_dual_sub_f32 v2, v2, v3 :: v_dual_sub_f32 v3, v4, v5     // 000000B63340: C94A0702 02020B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B63348: BF8701A2
	v_sub_f32_e32 v5, v8, v9                                   // 000000B6334C: 080A1308
	v_add_f32_e32 v4, v8, v9                                   // 000000B63350: 06081308
	v_add_f32_e32 v8, v2, v3                                   // 000000B63354: 06100702
	s_delay_alu instid0(VALU_DEP_3)                            // 000000B63358: BF870003
	v_mov_b32_dpp v9, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B6335C: 7E1202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000B63364: D5010005 200E0B05
	v_sub_f32_e32 v2, v2, v3                                   // 000000B6336C: 08040702
	v_mov_b32_dpp v3, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B63370: 7E0602FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000B63378: D5010004 200E0904
	v_mov_b32_dpp v10, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B63380: 7E1402FA FF016108
	v_add_f32_e32 v5, v5, v9                                   // 000000B63388: 060A1305
	v_mov_b32_dpp v11, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B6338C: 7E1602FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000B63394: D5010002 200E0502
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000B6339C: D5010008 200E1108
	v_add_f32_e32 v3, v4, v3                                   // 000000B633A4: 06060704
	s_mov_b32 s3, 0x76543210                                   // 000000B633A8: BE8300FF 76543210
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B633B0: BF870193
	v_add_f32_e32 v2, v2, v11                                  // 000000B633B4: 06041702
	v_add_f32_e32 v4, v8, v10                                  // 000000B633B8: 06081508
	v_mov_b32_dpp v8, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B633BC: 7E1002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000B633C4: D5010005 200A0B05
	.long 0x7f163880                                           // 000000B633CC: 7F163880
	v_mov_b32_dpp v10, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B633D0: 7E1402FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000B633D8: D5010002 200A0502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B633E0: BF8700B1
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v2, v2, v10    // 000000B633E4: C9081105 05021502
	v_mov_b32_dpp v9, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B633EC: 7E1202FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000B633F4: D5010003 200A0703
	v_add_f32_e32 v3, v3, v9                                   // 000000B633FC: 06061303
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B63400: BF8701A4
	v_mov_b32_dpp v9, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B63404: 7E1202FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000B6340C: D5010005 20060B05
	v_mov_b32_dpp v10, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B63414: 7E1402FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000B6341C: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B63424: BF8700B3
	v_add_f32_e32 v5, v5, v9                                   // 000000B63428: 060A1305
	v_mov_b32_dpp v8, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B6342C: 7E1002FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000B63434: D5010004 200A0904
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v4, v4, v8    // 000000B6343C: C9081503 03041104
	v_mov_b32_dpp v8, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B63444: 7E1002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000B6344C: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B63454: BF8701A3
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B63458: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000B63460: D5010004 20060904
	v_add_f32_e32 v2, v2, v8                                   // 000000B63468: 06041102
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B6346C: 7E1002FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000B63474: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B6347C: BF8701B1
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v8     // 000000B63480: C9081304 04041105
	v_mov_b32_dpp v8, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B63488: 7E1002FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000B63490: D5010003 20020703
	v_mov_b32_e32 v9, v5                                       // 000000B63498: 7E120305
	v_mov_b32_dpp v10, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B6349C: 7E1402FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000B634A4: D5010002 20020502
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000B634AC: D5010005 21AA0B05
	v_add_f32_e32 v3, v3, v8                                   // 000000B634B4: 06061103
	v_permlanex16_b32 v9, v9, s3, 0xfedcba98                   // 000000B634B8: D65C0009 03FC0709 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B634C4: BF8701B4
	v_add_f32_e32 v2, v2, v10                                  // 000000B634C8: 06041502
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B634CC: 7E1402FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000B634D4: D5010004 20020904
	v_dual_add_f32 v5, v5, v9 :: v_dual_mov_b32 v12, v2        // 000000B634DC: C9101305 050C0102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000B634E4: D5010002 21AA0502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B634EC: BF870222
	v_dual_add_f32 v4, v4, v10 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000B634F0: C9061504 04040AFF 3DB504F3
	v_mov_b32_e32 v8, v3                                       // 000000B634FC: 7E100303
	v_permlanex16_b32 v12, v12, s3, 0xfedcba98                 // 000000B63500: D65C000C 03FC070C FEDCBA98
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000B6350C: D5010003 21AA0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B63514: BF8701B4
	v_mov_b32_e32 v9, v4                                       // 000000B63518: 7E120304
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000B6351C: D5010004 21AA0904
	v_permlanex16_b32 v8, v8, s3, 0xfedcba98                   // 000000B63524: D65C0008 03FC0708 FEDCBA98
	v_permlanex16_b32 v9, v9, s3, 0xfedcba98                   // 000000B63530: D65C0009 03FC0709 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B6353C: BF8701A2
	v_add_f32_e32 v3, v3, v8                                   // 000000B63540: 06061103
	.long 0x7f10398b                                           // 000000B63544: 7F10398B
	v_add_f32_e32 v4, v4, v9                                   // 000000B63548: 06081304
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B6354C: BF870113
	v_dual_add_f32 v2, v2, v12 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 000000B63550: C9061902 020206FF 3DB504F3
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000B6355C: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000B63564: BF870132
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000B63568: 100404FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B63570: BF8903F7
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel_hi:[1,0,0]         // 000000B63574: CC200005 8A020B07
	v_fma_mix_f32 v2, v7, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B6357C: CC200802 8A020507
	.long 0x7f0e398b                                           // 000000B63584: 7F0E398B
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel_hi:[1,0,0]         // 000000B63588: CC200003 8A020706
	v_fma_mix_f32 v4, v6, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B63590: CC200804 8A020906
	.long 0x7e103985                                           // 000000B63598: 7E103985
	.long 0x7e0e3982                                           // 000000B6359C: 7E0E3982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B635A0: BF870193
	v_bfe_u32 v9, v4, 16, 1                                    // 000000B635A4: D6100009 02052104
	v_and_b32_e32 v8, 1, v8                                    // 000000B635AC: 36101081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B635B0: BF8701A3
	v_and_b32_e32 v6, 1, v7                                    // 000000B635B4: 360C0E81
	v_bfe_u32 v7, v3, 16, 1                                    // 000000B635B8: D6100007 02052103
	v_add3_u32 v5, v5, v8, 0x7fff                              // 000000B635C0: D6550005 03FE1105 00007FFF
	.long 0x7f10398b                                           // 000000B635CC: 7F10398B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B635D0: BF870214
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000B635D4: D6550002 03FE0D02 00007FFF
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000B635E0: D6550003 03FE0F03 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B635EC: BF870224
	.long 0x7e103985                                           // 000000B635F0: 7E103985
	v_add3_u32 v5, v4, v9, 0x7fff                              // 000000B635F4: D6550005 03FE1304 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v2                           // 000000B63600: 360804FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B63608: BF8701B4
	.long 0x7e163983                                           // 000000B6360C: 7E163983
	v_mad_i64_i32 v[1:2], null, 0x1400, v1, v[17:18]           // 000000B63610: D6FF7C01 044602FF 00001400
	v_and_b32_e32 v6, 0xffff, v8                               // 000000B6361C: 360C10FF 0000FFFF
	v_and_or_b32 v3, 0xffff0000, v5, v11                       // 000000B63624: D6570003 042E0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000B63630: BF870002
	v_or_b32_e32 v4, v4, v6                                    // 000000B63634: 38080D04
	global_store_b64 v[1:2], v[3:4], off                       // 000000B63638: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B63640: 8C7E057E
	s_waitcnt_vscnt null, 0x0                                  // 000000B63644: BC7C0000
	s_barrier                                                  // 000000B63648: BFBD0000
	s_mov_b32 s0, 0                                            // 000000B6364C: BE800080
	s_mov_b32 s3, -1                                           // 000000B63650: BE8300C1
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000B63654: 916A007E
	s_cbranch_vccnz 4673                                       // 000000B63658: BFA41241 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xb660>
	s_cmp_gt_i32 s20, 1                                        // 000000B6365C: BF028114
	s_mov_b32 s0, -1                                           // 000000B63660: BE8000C1
	s_cbranch_scc0 2608                                        // 000000B63664: BFA10A30 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x9628>
	v_or_b32_e32 v1, 0x100, v0                                 // 000000B63668: 380200FF 00000100
	v_lshrrev_b32_e32 v7, 4, v0                                // 000000B63670: 320E0084
	v_lshlrev_b32_e32 v2, 3, v0                                // 000000B63674: 30040083
	s_add_i32 s0, s19, -1                                      // 000000B63678: 8100C113
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B6367C: BF870193
	v_lshrrev_b32_e32 v1, 4, v1                                // 000000B63680: 32020284
	v_min_i32_e32 v3, s0, v7                                   // 000000B63684: 22060E00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B63688: BF870193
	v_and_b32_e32 v61, 0x78, v2                                // 000000B6368C: 367A04FF 00000078
	v_min_i32_e32 v4, s0, v1                                   // 000000B63694: 22080200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B63698: BF870193
	v_add_nc_u32_e32 v3, s18, v3                               // 000000B6369C: 4A060612
	v_lshlrev_b32_e32 v2, 1, v61                               // 000000B636A0: 30047A81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B636A4: BF870193
	v_add_nc_u32_e32 v5, s18, v4                               // 000000B636A8: 4A0A0812
	v_mad_i64_i32 v[3:4], null, 0x500, v3, 0                   // 000000B636AC: D6FF7C03 020206FF 00000500
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B636B8: BF870093
	.long 0xd700000a                                           // 000000B636BC: D700000A
	v_cndmask_b32_e32 v1, s10, v2, vcc_lo                      // 000000B636C0: 0202040A
	v_add_co_ci_u32_e64 v11, null, s11, 0, s0                  // 000000B636C4: D5207C0B 0001000B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B636CC: BF870224
	v_mad_i64_i32 v[5:6], null, 0x500, v5, 0                   // 000000B636D0: D6FF7C05 02020AFF 00000500
	.long 0xd44c0000                                           // 000000B636DC: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000B636E0: 020200FF 00000200
	.long 0xd7006a08                                           // 000000B636E8: D7006A08
	v_cndmask_b32_e32 v1, v10, v3, vcc_lo                      // 000000B636EC: 0202070A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B636F0: BF870211
	v_add_co_ci_u32_e64 v9, null, v11, v4, vcc_lo              // 000000B636F4: D5207C09 01AA090B
	.long 0xd7006a0a                                           // 000000B636FC: D7006A0A
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 000000B63700: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B63704: BF870001
	v_add_co_ci_u32_e64 v11, null, v11, v6, vcc_lo             // 000000B63708: D5207C0B 01AA0D0B
	s_clause 0x1                                               // 000000B63710: BF850001
	global_load_b128 v[18:21], v[8:9], off                     // 000000B63714: DC5E0000 127C0008
	global_load_b128 v[22:25], v[10:11], off                   // 000000B6371C: DC5E0000 167C000A
	s_and_saveexec_b32 s1, s0                                  // 000000B63724: BE812000
	s_cbranch_execz 6                                          // 000000B63728: BFA50006 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6e44>
	v_mad_u32_u24 v8, 0x110, v7, v2                            // 000000B6372C: D60B0008 040A0EFF 00000110
	s_waitcnt vmcnt(1)                                         // 000000B63738: BF8907F7
	ds_store_b128 v8, v[18:21]                                 // 000000B6373C: DB7C0000 00001208
	s_or_b32 exec_lo, exec_lo, s1                              // 000000B63744: 8C7E017E
	.long 0xd44c0001                                           // 000000B63748: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000B6374C: 020200FF 00000100
	v_mul_u32_u24_e32 v62, 0x88, v1                            // 000000B63754: 167C02FF 00000088
	s_and_saveexec_b32 s2, s1                                  // 000000B6375C: BE822001
	s_cbranch_execz 6                                          // 000000B63760: BFA50006 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6e7c>
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B63764: BF870001
	v_lshl_add_u32 v1, v62, 1, v2                              // 000000B63768: D6460001 0409033E
	s_waitcnt vmcnt(0)                                         // 000000B63770: BF8903F7
	ds_store_b128 v1, v[22:25]                                 // 000000B63774: DB7C0000 00001601
	s_or_b32 exec_lo, exec_lo, s2                              // 000000B6377C: 8C7E027E
	v_dual_mov_b32 v2, 0 :: v_dual_and_b32 v59, 31, v0         // 000000B63780: CA240080 023A009F
	v_lshrrev_b32_e32 v58, 5, v0                               // 000000B63788: 32740085
	s_mul_i32 s5, s16, 0x96000                                 // 000000B6378C: 9605FF10 00096000
	s_mul_i32 s12, s17, 0x7800                                 // 000000B63794: 960CFF11 00007800
	s_delay_alu instid0(VALU_DEP_2)                            // 000000B6379C: BF870002
	v_lshl_or_b32 v9, v59, 3, 4                                // 000000B637A0: D6560009 0211073B
	v_mad_u32_u24 v8, v59, 24, 0x2f0                           // 000000B637A8: D60B0008 03FD313B 000002F0
	v_cmp_ne_u32_e32 vcc_lo, 0, v59                            // 000000B637B4: 7C9A7680
	v_mul_u32_u24_e32 v71, 0x110, v7                           // 000000B637B8: 168E0EFF 00000110
	s_add_u32 s5, s5, s12                                      // 000000B637C0: 80050C05
	v_mad_u32_u24 v1, v9, 3, 0x2f0                             // 000000B637C4: D60B0001 03FD0709 000002F0
	v_lshrrev_b32_e32 v12, 5, v8                               // 000000B637D0: 32181085
	v_and_b32_e32 v14, 0x7e0, v8                               // 000000B637D4: 361C10FF 000007E0
	v_mul_hi_u32_u24_e32 v7, 0x60, v58                         // 000000B637DC: 180E74FF 00000060
	s_mul_hi_i32 s4, s16, 0x96000                              // 000000B637E4: 9704FF10 00096000
	v_lshrrev_b32_e32 v11, 5, v1                               // 000000B637EC: 32160285
	v_subrev_nc_u32_e32 v16, 24, v12                           // 000000B637F0: 4E201898
	v_and_b32_e32 v17, 0x7e0, v1                               // 000000B637F4: 362202FF 000007E0
	s_mul_hi_i32 s13, s17, 0x7800                              // 000000B637FC: 970DFF11 00007800
	v_add_nc_u32_e32 v12, 0xe9, v12                            // 000000B63804: 4A1818FF 000000E9
	.long 0xd7030008                                           // 000000B6380C: D7030008
	v_cndmask_b32_e32 v0, v11, v129, vcc_lo                    // 000000B63810: 0201030B
	v_cndmask_b32_e32 v1, 23, v16, vcc_lo                      // 000000B63814: 02022097
	v_subrev_nc_u32_e32 v11, 24, v11                           // 000000B63818: 4E161698
	v_cmp_lt_u32_e32 vcc_lo, 5, v9                             // 000000B6381C: 7C921285
	v_and_b32_e32 v60, 15, v0                                  // 000000B63820: 3678008F
	.long 0xd7624008                                           // 000000B63824: D7624008
	v_cndmask_b32_e32 v1, 0xff, v8, vcc_lo                     // 000000B63828: 020210FF 000000FF
	v_mad_i32_i24 v16, v9, -3, v17                             // 000000B63830: D60A0010 04458709
	s_addc_u32 s4, s4, s13                                     // 000000B63838: 82040D04
	v_dual_cndmask_b32 v9, 23, v11 :: v_dual_mov_b32 v10, v2   // 000000B6383C: CA501697 090A0102
	v_lshlrev_b32_e32 v15, 4, v60                              // 000000B63844: 301E7884
	.long 0xd7055008                                           // 000000B63848: D7055008
	v_cndmask_b32_e32 v1, 0xab, v8, vcc_lo                     // 000000B6384C: 020210FF 000000AB
	v_add_nc_u32_e32 v67, 0xfffffd3d, v16                      // 000000B63854: 4A8620FF FFFFFD3D
	v_add_nc_u32_e32 v68, 0xfffffd3a, v16                      // 000000B6385C: 4A8820FF FFFFFD3A
	v_add_nc_u32_e32 v69, 0xfffffd37, v16                      // 000000B63864: 4A8A20FF FFFFFD37
	.long 0xd7006a05                                           // 000000B6386C: D7006A05
	v_cndmask_b32_e32 v1, v5, v15, vcc_lo                      // 000000B63870: 02021F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B63874: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, vcc_lo                // 000000B63878: D5207C06 01AA0C80
	.long 0xd7395008                                           // 000000B63880: D7395008
	v_cndmask_b32_e32 v1, 12, v8, vcc_lo                       // 000000B63884: 0202108C
	.long 0xd7006a05                                           // 000000B63888: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000B6388C: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B63890: BF870221
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 000000B63894: D5207C06 01AA0C0B
	.long 0xd7006a03                                           // 000000B6389C: D7006A03
	v_cndmask_b32_e32 v1, v3, v15, vcc_lo                      // 000000B638A0: 02021F03
	.long 0xd7054808                                           // 000000B638A4: D7054808
	v_cndmask_b32_e32 v0, v8, v152, vcc_lo                     // 000000B638A8: 02013108
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000B638AC: D5207C04 01AA0880
	.long 0xd7006a1a                                           // 000000B638B4: D7006A1A
	v_cndmask_b32_e32 v1, 0x100, v5, vcc_lo                    // 000000B638B8: 02020AFF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000B638C0: BF870251
	v_add_co_ci_u32_e64 v27, null, 0, v6, vcc_lo               // 000000B638C4: D5207C1B 01AA0C80
	.long 0xd7006a05                                           // 000000B638CC: D7006A05
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 000000B638D0: 0202060A
	v_mul_u32_u24_e32 v3, 0x60, v58                            // 000000B638D4: 160674FF 00000060
	.long 0xd7041008                                           // 000000B638DC: D7041008
	v_cndmask_b32_e32 v1, v8, v8, vcc_lo                       // 000000B638E0: 02021108
	v_add_co_ci_u32_e64 v6, null, s11, v4, vcc_lo              // 000000B638E4: D5207C06 01AA080B
	.long 0xd7006a1c                                           // 000000B638EC: D7006A1C
	v_cndmask_b32_e32 v1, 0x100, v5, vcc_lo                    // 000000B638F0: 02020AFF 00000100
	s_delay_alu instid0(VALU_DEP_4)                            // 000000B638F8: BF870004
	v_or_b32_e32 v11, s5, v3                                   // 000000B638FC: 38160605
	.long 0xd73c0003                                           // 000000B63900: D73C0003
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000B63904: 02020282
	v_or_b32_e32 v5, s4, v7                                    // 000000B63908: 380A0E04
	v_and_b32_e32 v1, 0xff, v8                                 // 000000B6390C: 360210FF 000000FF
	v_add_co_ci_u32_e64 v29, null, 0, v6, vcc_lo               // 000000B63914: D5207C1D 01AA0C80
	v_add_nc_u32_e32 v70, 0xfffffd34, v16                      // 000000B6391C: 4A8C20FF FFFFFD34
	.long 0xd7006a03                                           // 000000B63924: D7006A03
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 000000B63928: 0202070B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B6392C: BF870231
	v_add_co_ci_u32_e64 v4, null, v5, v4, vcc_lo               // 000000B63930: D5207C04 01AA0905
	v_mov_b32_e32 v16, v2                                      // 000000B63938: 7E200302
	v_dual_mov_b32 v15, v2 :: v_dual_lshlrev_b32 v6, 2, v1     // 000000B6393C: CA220102 0F060282
	.long 0xd7006a01                                           // 000000B63944: D7006A01
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000B63948: 02020608
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B6394C: BF870191
	v_add_co_ci_u32_e64 v72, null, s9, v4, vcc_lo              // 000000B63950: D5207C48 01AA0809
	.long 0xd7006a03                                           // 000000B63958: D7006A03
	v_cndmask_b32_e32 v1, v11, v6, vcc_lo                      // 000000B6395C: 02020D0B
	v_and_b32_e32 v12, 0xff, v12                               // 000000B63960: 361818FF 000000FF
	v_add_co_ci_u32_e64 v4, null, 0, v5, vcc_lo                // 000000B63968: D5207C04 01AA0A80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B63970: BF870193
	.long 0xd7006a49                                           // 000000B63974: D7006A49
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000B63978: 02020608
	v_dual_mov_b32 v17, v2 :: v_dual_lshlrev_b32 v6, 2, v12    // 000000B6397C: CA220102 11061882
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B63984: BF8701A3
	v_add_co_ci_u32_e64 v74, null, s9, v4, vcc_lo              // 000000B63988: D5207C4A 01AA0809
	.long 0xd73c0003                                           // 000000B63990: D73C0003
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000B63994: 02021282
	.long 0xd7006a06                                           // 000000B63998: D7006A06
	v_cndmask_b32_e32 v1, v11, v6, vcc_lo                      // 000000B6399C: 02020D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B639A0: BF870221
	v_add_co_ci_u32_e64 v7, null, 0, v5, vcc_lo                // 000000B639A4: D5207C07 01AA0A80
	v_mul_u32_u24_e32 v13, 0x88, v60                           // 000000B639AC: 161A78FF 00000088
	.long 0xd7006a03                                           // 000000B639B4: D7006A03
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 000000B639B8: 0202070B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B639BC: BF8700A1
	v_add_co_ci_u32_e64 v4, null, v5, v4, vcc_lo               // 000000B639C0: D5207C04 01AA0905
	.long 0xd7006a4b                                           // 000000B639C8: D7006A4B
	v_cndmask_b32_e32 v1, s8, v6, vcc_lo                       // 000000B639CC: 02020C08
	v_add_co_ci_u32_e64 v76, null, s9, v7, vcc_lo              // 000000B639D0: D5207C4C 01AA0E09
	s_delay_alu instid0(VALU_DEP_4)                            // 000000B639D8: BF870004
	.long 0xd7006a4d                                           // 000000B639DC: D7006A4D
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000B639E0: 02020608
	v_mov_b32_e32 v3, v2                                       // 000000B639E4: 7E060302
	v_mad_i32_i24 v14, 0xffffffe8, v59, v14                    // 000000B639E8: D60A000E 043A76FF FFFFFFE8
	.long 0xd44c0002                                           // 000000B639F4: D44C0002
	v_cndmask_b32_e32 v1, 16, v59, vcc_lo                      // 000000B639F8: 02027690
	v_add_co_ci_u32_e64 v78, null, s9, v4, vcc_lo              // 000000B639FC: D5207C4E 01AA0809
	v_lshlrev_b32_e32 v79, 1, v13                              // 000000B63A04: 309E1A81
	s_delay_alu instid0(VALU_DEP_4)                            // 000000B63A08: BF870004
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v63, 0xfffffd3d, v14// 000000B63A0C: CA200102 063E1CFF FFFFFD3D
	v_add_nc_u32_e32 v64, 0xfffffd3a, v14                      // 000000B63A18: 4A801CFF FFFFFD3A
	v_dual_mov_b32 v8, v2 :: v_dual_add_nc_u32 v65, 0xfffffd37, v14// 000000B63A20: CA200102 08401CFF FFFFFD37
	v_dual_mov_b32 v9, v2 :: v_dual_add_nc_u32 v66, 0xfffffd34, v14// 000000B63A2C: CA200102 09421CFF FFFFFD34
	v_mov_b32_e32 v4, v2                                       // 000000B63A38: 7E080302
	v_mov_b32_e32 v5, v2                                       // 000000B63A3C: 7E0A0302
	v_mov_b32_e32 v7, v2                                       // 000000B63A40: 7E0E0302
	v_mov_b32_e32 v11, v2                                      // 000000B63A44: 7E160302
	v_mov_b32_e32 v12, v2                                      // 000000B63A48: 7E180302
	v_mov_b32_e32 v13, v2                                      // 000000B63A4C: 7E1A0302
	v_mov_b32_e32 v14, v2                                      // 000000B63A50: 7E1C0302
	s_mov_b32 s3, 0                                            // 000000B63A54: BE830080
	s_mov_b64 s[4:5], 0                                        // 000000B63A58: BE840180
	s_movk_i32 s12, 0x1eee                                     // 000000B63A5C: B00C1EEE
	s_mov_b32 s13, 0x76543210                                  // 000000B63A60: BE8D00FF 76543210
	s_movk_i32 s21, 0x4460                                     // 000000B63A68: B0154460
	s_movk_i32 s22, 0x80                                       // 000000B63A6C: B0160080
	s_movk_i32 s23, 0xa0                                       // 000000B63A70: B01700A0
	s_movk_i32 s24, 0xc0                                       // 000000B63A74: B01800C0
	s_movk_i32 s25, 0xe0                                       // 000000B63A78: B01900E0
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000B63A7C: BF890007
	s_barrier                                                  // 000000B63A80: BFBD0000
	buffer_gl0_inv                                             // 000000B63A84: E0AC0000 00000000
	s_branch 22                                                // 000000B63A8C: BFA00016 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x71e8>
	s_or_b32 exec_lo, exec_lo, s26                             // 000000B63A90: 8C7E1A7E
	.long 0xd7006a1a                                           // 000000B63A94: D7006A1A
	v_cndmask_b32_e32 v1, 0x100, v26, vcc_lo                   // 000000B63A98: 020234FF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B63AA0: BF8700A1
	v_add_co_ci_u32_e64 v27, null, 0, v27, vcc_lo              // 000000B63AA4: D5207C1B 01AA3680
	.long 0xd7006a1c                                           // 000000B63AAC: D7006A1C
	v_cndmask_b32_e32 v1, 0x100, v28, vcc_lo                   // 000000B63AB0: 020238FF 00000100
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 000000B63AB8: D5207C1D 01AA3A80
	s_add_u32 s4, s4, 0x1800                                   // 000000B63AC0: 8004FF04 00001800
	s_addc_u32 s5, s5, 0                                       // 000000B63AC8: 82058005
	s_add_i32 s3, s3, 1                                        // 000000B63ACC: 81038103
	s_cmpk_eq_i32 s4, 0x7800                                   // 000000B63AD0: B1847800
	s_waitcnt lgkmcnt(0)                                       // 000000B63AD4: BF89FC07
	s_barrier                                                  // 000000B63AD8: BFBD0000
	buffer_gl0_inv                                             // 000000B63ADC: E0AC0000 00000000
	s_cbranch_scc1 1413                                        // 000000B63AE4: BFA20585 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x87fc>
	s_cmpk_lg_i32 s4, 0x6000                                   // 000000B63AE8: B2046000
	s_cselect_b32 s26, -1, 0                                   // 000000B63AEC: 981A80C1
	s_cmpk_eq_i32 s4, 0x6000                                   // 000000B63AF0: B1846000
	s_cbranch_scc1 4                                           // 000000B63AF4: BFA20004 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x7208>
	global_load_b128 v[18:21], v[28:29], off                   // 000000B63AF8: DC5E0000 127C001C
	global_load_b128 v[22:25], v[26:27], off                   // 000000B63B00: DC5E0000 167C001A
	.long 0xd7006a26                                           // 000000B63B08: D7006A26
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000B63B0C: 02000901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B63B10: BF8700A1
	v_add_co_ci_u32_e64 v39, null, s5, v72, vcc_lo             // 000000B63B14: D5207C27 01AA9005
	.long 0xd7006a28                                           // 000000B63B1C: D7006A28
	v_cndmask_b32_e32 v0, v75, v4, vcc_lo                      // 000000B63B20: 0200094B
	v_add_co_ci_u32_e64 v41, null, s5, v76, vcc_lo             // 000000B63B24: D5207C29 01AA9805
	.long 0xd7006a2a                                           // 000000B63B2C: D7006A2A
	v_cndmask_b32_e32 v0, v77, v4, vcc_lo                      // 000000B63B30: 0200094D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B63B34: BF8700A1
	v_add_co_ci_u32_e64 v43, null, s5, v78, vcc_lo             // 000000B63B38: D5207C2B 01AA9C05
	.long 0xd7006a2c                                           // 000000B63B40: D7006A2C
	v_cndmask_b32_e32 v0, v73, v4, vcc_lo                      // 000000B63B44: 02000949
	v_add_co_ci_u32_e64 v45, null, s5, v74, vcc_lo             // 000000B63B48: D5207C2D 01AA9405
	s_clause 0x17                                              // 000000B63B50: BF850017
	global_load_b32 v33, v[38:39], off                         // 000000B63B54: DC520000 217C0026
	global_load_b32 v32, v[40:41], off                         // 000000B63B5C: DC520000 207C0028
	global_load_b32 v31, v[42:43], off                         // 000000B63B64: DC520000 1F7C002A
	global_load_b32 v30, v[44:45], off                         // 000000B63B6C: DC520000 1E7C002C
	global_load_b32 v35, v[38:39], off offset:768              // 000000B63B74: DC520300 237C0026
	global_load_b32 v34, v[40:41], off offset:768              // 000000B63B7C: DC520300 227C0028
	global_load_b32 v37, v[42:43], off offset:768              // 000000B63B84: DC520300 257C002A
	global_load_b32 v36, v[44:45], off offset:768              // 000000B63B8C: DC520300 247C002C
	global_load_b32 v47, v[38:39], off offset:1536             // 000000B63B94: DC520600 2F7C0026
	global_load_b32 v46, v[40:41], off offset:1536             // 000000B63B9C: DC520600 2E7C0028
	global_load_b32 v49, v[42:43], off offset:1536             // 000000B63BA4: DC520600 317C002A
	global_load_b32 v48, v[44:45], off offset:1536             // 000000B63BAC: DC520600 307C002C
	global_load_b32 v55, v[38:39], off offset:2304             // 000000B63BB4: DC520900 377C0026
	global_load_b32 v54, v[40:41], off offset:2304             // 000000B63BBC: DC520900 367C0028
	global_load_b32 v57, v[42:43], off offset:2304             // 000000B63BC4: DC520900 397C002A
	global_load_b32 v56, v[44:45], off offset:2304             // 000000B63BCC: DC520900 387C002C
	global_load_b32 v145, v[38:39], off offset:3072            // 000000B63BD4: DC520C00 917C0026
	global_load_b32 v144, v[40:41], off offset:3072            // 000000B63BDC: DC520C00 907C0028
	global_load_b32 v147, v[42:43], off offset:3072            // 000000B63BE4: DC520C00 937C002A
	global_load_b32 v146, v[44:45], off offset:3072            // 000000B63BEC: DC520C00 927C002C
	global_load_b32 v51, v[38:39], off offset:3840             // 000000B63BF4: DC520F00 337C0026
	global_load_b32 v50, v[40:41], off offset:3840             // 000000B63BFC: DC520F00 327C0028
	global_load_b32 v52, v[44:45], off offset:3840             // 000000B63C04: DC520F00 347C002C
	global_load_b32 v53, v[42:43], off offset:3840             // 000000B63C0C: DC520F00 357C002A
	.long 0xd7006a60                                           // 000000B63C14: D7006A60
	v_cndmask_b32_e32 v1, 0x1000, v38, vcc_lo                  // 000000B63C18: 02024CFF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B63C20: BF8700A1
	v_add_co_ci_u32_e64 v97, null, 0, v39, vcc_lo              // 000000B63C24: D5207C61 01AA4E80
	.long 0xd7006a62                                           // 000000B63C2C: D7006A62
	v_cndmask_b32_e32 v1, 0x1000, v40, vcc_lo                  // 000000B63C30: 020250FF 00001000
	v_add_co_ci_u32_e64 v99, null, 0, v41, vcc_lo              // 000000B63C38: D5207C63 01AA5280
	.long 0xd7006a64                                           // 000000B63C40: D7006A64
	v_cndmask_b32_e32 v1, 0x1000, v42, vcc_lo                  // 000000B63C44: 020254FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B63C4C: BF8700A1
	v_add_co_ci_u32_e64 v101, null, 0, v43, vcc_lo             // 000000B63C50: D5207C65 01AA5680
	.long 0xd7006a2a                                           // 000000B63C58: D7006A2A
	v_cndmask_b32_e32 v1, 0x1000, v44, vcc_lo                  // 000000B63C5C: 020258FF 00001000
	v_add_co_ci_u32_e64 v43, null, 0, v45, vcc_lo              // 000000B63C64: D5207C2B 01AA5A80
	s_clause 0x7                                               // 000000B63C6C: BF850007
	global_load_b32 v41, v[96:97], off offset:512              // 000000B63C70: DC520200 297C0060
	global_load_b32 v40, v[98:99], off offset:512              // 000000B63C78: DC520200 287C0062
	global_load_b32 v39, v[100:101], off offset:512            // 000000B63C80: DC520200 277C0064
	global_load_b32 v38, v[42:43], off offset:512              // 000000B63C88: DC520200 267C002A
	global_load_b32 v42, v[42:43], off offset:1280             // 000000B63C90: DC520500 2A7C002A
	global_load_b32 v43, v[100:101], off offset:1280           // 000000B63C98: DC520500 2B7C0064
	global_load_b32 v168, v[98:99], off offset:1280            // 000000B63CA0: DC520500 A87C0062
	global_load_b32 v169, v[96:97], off offset:1280            // 000000B63CA8: DC520500 A97C0060
	s_bfe_i32 s27, s3, 0x10000                                 // 000000B63CB0: 939BFF03 00010000
	s_and_b32 s28, s3, 1                                       // 000000B63CB8: 8B1C8103
	s_and_b32 s27, s27, 0x4400                                 // 000000B63CBC: 8B1BFF1B 00004400
	s_cmp_eq_u32 s28, 0                                        // 000000B63CC4: BF06801C
	v_add_nc_u32_e32 v92, s27, v79                             // 000000B63CC8: 4AB89E1B
	s_cselect_b32 s27, -1, 0                                   // 000000B63CCC: 981B80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000B63CD0: BF870009
	s_and_b32 s28, s27, exec_lo                                // 000000B63CD4: 8B1C7E1B
	s_cselect_b32 s28, 32, 0x4420                              // 000000B63CD8: 981CFFA0 00004420
	s_cselect_b32 s29, 64, 0x4440                              // 000000B63CE0: 981DFFC0 00004440
	v_add_nc_u32_e32 v44, s28, v79                             // 000000B63CE8: 4A589E1C
	s_cselect_b32 s30, 0x60, s21                               // 000000B63CEC: 981E15FF 00000060
	v_add_nc_u32_e32 v45, s29, v79                             // 000000B63CF4: 4A5A9E1D
	v_add_nc_u32_e32 v140, s30, v79                            // 000000B63CF8: 4B189E1E
	ds_load_b128 v[96:99], v44                                 // 000000B63CFC: DBFC0000 6000002C
	ds_load_b128 v[100:103], v44 offset:16                     // 000000B63D04: DBFC0010 6400002C
	ds_load_b128 v[104:107], v44 offset:4352                   // 000000B63D0C: DBFC1100 6800002C
	ds_load_b128 v[108:111], v44 offset:4368                   // 000000B63D14: DBFC1110 6C00002C
	ds_load_b128 v[112:115], v45                               // 000000B63D1C: DBFC0000 7000002D
	ds_load_b128 v[116:119], v45 offset:16                     // 000000B63D24: DBFC0010 7400002D
	ds_load_b128 v[120:123], v45 offset:4352                   // 000000B63D2C: DBFC1100 7800002D
	ds_load_b128 v[124:127], v45 offset:4368                   // 000000B63D34: DBFC1110 7C00002D
	ds_load_b128 v[128:131], v140                              // 000000B63D3C: DBFC0000 8000008C
	ds_load_b128 v[132:135], v140 offset:16                    // 000000B63D44: DBFC0010 8400008C
	ds_load_b128 v[136:139], v140 offset:4352                  // 000000B63D4C: DBFC1100 8800008C
	ds_load_b128 v[140:143], v140 offset:4368                  // 000000B63D54: DBFC1110 8C00008C
	s_cselect_b32 s28, s22, 0x4480                             // 000000B63D5C: 981CFF16 00004480
	s_waitcnt vmcnt(30)                                        // 000000B63D64: BF897BF7
	.long 0xd73d0094                                           // 000000B63D68: D73D0094
	v_cndmask_b32_e32 v1, v64, v32, vcc_lo                     // 000000B63D6C: 02024140
	.long 0xd73d0095                                           // 000000B63D70: D73D0095
	v_cndmask_b32_e32 v1, v65, v32, vcc_lo                     // 000000B63D74: 02024141
	s_waitcnt vmcnt(28)                                        // 000000B63D78: BF8973F7
	.long 0xd73d0096                                           // 000000B63D7C: D73D0096
	v_cndmask_b32_e32 v1, v67, v30, vcc_lo                     // 000000B63D80: 02023D43
	.long 0xd73d0097                                           // 000000B63D84: D73D0097
	v_cndmask_b32_e32 v1, v68, v30, vcc_lo                     // 000000B63D88: 02023D44
	.long 0xd73d0098                                           // 000000B63D8C: D73D0098
	v_cndmask_b32_e32 v1, v69, v30, vcc_lo                     // 000000B63D90: 02023D45
	s_waitcnt vmcnt(26)                                        // 000000B63D94: BF896BF7
	.long 0xd73d0099                                           // 000000B63D98: D73D0099
	v_cndmask_b32_e32 v1, v63, v34, vcc_lo                     // 000000B63D9C: 0202453F
	.long 0xd73d009a                                           // 000000B63DA0: D73D009A
	v_cndmask_b32_e32 v1, v64, v34, vcc_lo                     // 000000B63DA4: 02024540
	.long 0xd73d009b                                           // 000000B63DA8: D73D009B
	v_cndmask_b32_e32 v1, v65, v34, vcc_lo                     // 000000B63DAC: 02024541
	s_waitcnt vmcnt(24)                                        // 000000B63DB0: BF8963F7
	.long 0xd73d009c                                           // 000000B63DB4: D73D009C
	v_cndmask_b32_e32 v1, v68, v36, vcc_lo                     // 000000B63DB8: 02024944
	.long 0xd73d009d                                           // 000000B63DBC: D73D009D
	v_cndmask_b32_e32 v1, v69, v36, vcc_lo                     // 000000B63DC0: 02024945
	.long 0xd73d002c                                           // 000000B63DC4: D73D002C
	v_cndmask_b32_e32 v1, v63, v32, vcc_lo                     // 000000B63DC8: 0202413F
	.long 0xd73d0020                                           // 000000B63DCC: D73D0020
	v_cndmask_b32_e32 v1, v66, v32, vcc_lo                     // 000000B63DD0: 02024142
	s_waitcnt vmcnt(22)                                        // 000000B63DD4: BF895BF7
	.long 0xd73d009e                                           // 000000B63DD8: D73D009E
	v_cndmask_b32_e32 v1, v64, v46, vcc_lo                     // 000000B63DDC: 02025D40
	.long 0xd73d0021                                           // 000000B63DE0: D73D0021
	v_cndmask_b32_e32 v1, v66, v34, vcc_lo                     // 000000B63DE4: 02024542
	.long 0xd73d009f                                           // 000000B63DE8: D73D009F
	v_cndmask_b32_e32 v1, v65, v46, vcc_lo                     // 000000B63DEC: 02025D41
	.long 0xd73d0022                                           // 000000B63DF0: D73D0022
	v_cndmask_b32_e32 v1, v67, v36, vcc_lo                     // 000000B63DF4: 02024943
	s_waitcnt vmcnt(20)                                        // 000000B63DF8: BF8953F7
	.long 0xd73d00a0                                           // 000000B63DFC: D73D00A0
	v_cndmask_b32_e32 v1, v68, v48, vcc_lo                     // 000000B63E00: 02026144
	.long 0xd73d0023                                           // 000000B63E04: D73D0023
	v_cndmask_b32_e32 v1, v70, v36, vcc_lo                     // 000000B63E08: 02024946
	.long 0xd73d00a1                                           // 000000B63E0C: D73D00A1
	v_cndmask_b32_e32 v1, v69, v48, vcc_lo                     // 000000B63E10: 02026145
	.long 0xd73d0024                                           // 000000B63E14: D73D0024
	v_cndmask_b32_e32 v1, v63, v46, vcc_lo                     // 000000B63E18: 02025D3F
	.long 0xd73d002d                                           // 000000B63E1C: D73D002D
	v_cndmask_b32_e32 v1, v66, v46, vcc_lo                     // 000000B63E20: 02025D42
	s_waitcnt vmcnt(18)                                        // 000000B63E24: BF894BF7
	.long 0xd73d00a2                                           // 000000B63E28: D73D00A2
	v_cndmask_b32_e32 v1, v64, v54, vcc_lo                     // 000000B63E2C: 02026D40
	.long 0xd73d002e                                           // 000000B63E30: D73D002E
	v_cndmask_b32_e32 v1, v67, v48, vcc_lo                     // 000000B63E34: 02026143
	.long 0xd73d00a3                                           // 000000B63E38: D73D00A3
	v_cndmask_b32_e32 v1, v65, v54, vcc_lo                     // 000000B63E3C: 02026D41
	.long 0xd73d002f                                           // 000000B63E40: D73D002F
	v_cndmask_b32_e32 v1, v70, v48, vcc_lo                     // 000000B63E44: 02026146
	s_waitcnt vmcnt(16)                                        // 000000B63E48: BF8943F7
	.long 0xd73d00a4                                           // 000000B63E4C: D73D00A4
	v_cndmask_b32_e32 v1, v67, v56, vcc_lo                     // 000000B63E50: 02027143
	.long 0xd73d0030                                           // 000000B63E54: D73D0030
	v_cndmask_b32_e32 v1, v63, v54, vcc_lo                     // 000000B63E58: 02026D3F
	.long 0xd73d0036                                           // 000000B63E5C: D73D0036
	v_cndmask_b32_e32 v1, v66, v54, vcc_lo                     // 000000B63E60: 02026D42
	.long 0xd73d00a5                                           // 000000B63E64: D73D00A5
	v_cndmask_b32_e32 v1, v68, v56, vcc_lo                     // 000000B63E68: 02027144
	.long 0xd73d00a6                                           // 000000B63E6C: D73D00A6
	v_cndmask_b32_e32 v1, v69, v56, vcc_lo                     // 000000B63E70: 02027145
	.long 0xd73d0037                                           // 000000B63E74: D73D0037
	v_cndmask_b32_e32 v1, v70, v56, vcc_lo                     // 000000B63E78: 02027146
	s_waitcnt vmcnt(14)                                        // 000000B63E7C: BF893BF7
	.long 0xd73d0038                                           // 000000B63E80: D73D0038
	v_cndmask_b32_e32 v1, v63, v144, vcc_lo                    // 000000B63E84: 0203213F
	v_and_b32_e32 v57, 0xffff, v151                            // 000000B63E88: 36732EFF 0000FFFF
	v_and_b32_e32 v151, 0xffff, v157                           // 000000B63E90: 372F3AFF 0000FFFF
	.long 0xd73d00aa                                           // 000000B63E98: D73D00AA
	v_cndmask_b32_e32 v1, v64, v144, vcc_lo                    // 000000B63E9C: 02032140
	.long 0xd73d00ab                                           // 000000B63EA0: D73D00AB
	v_cndmask_b32_e32 v1, v65, v144, vcc_lo                    // 000000B63EA4: 02032141
	v_and_b32_e32 v35, 0xffff, v35                             // 000000B63EA8: 364646FF 0000FFFF
	s_waitcnt vmcnt(12)                                        // 000000B63EB0: BF8933F7
	.long 0xd73d00ac                                           // 000000B63EB4: D73D00AC
	v_cndmask_b32_e32 v1, v67, v146, vcc_lo                    // 000000B63EB8: 02032543
	.long 0xd72c0097                                           // 000000B63EBC: D72C0097
	v_cndmask_b32_e32 v1, 0x83dcd12d, v151, vcc_lo             // 000000B63EC0: 02032EFF 83DCD12D
	.long 0xd73d0090                                           // 000000B63EC8: D73D0090
	v_cndmask_b32_e32 v1, v66, v144, vcc_lo                    // 000000B63ECC: 02032142
	.long 0xd73d00ad                                           // 000000B63ED0: D73D00AD
	v_cndmask_b32_e32 v1, v68, v146, vcc_lo                    // 000000B63ED4: 02032544
	.long 0xd73d00ae                                           // 000000B63ED8: D73D00AE
	v_cndmask_b32_e32 v1, v69, v146, vcc_lo                    // 000000B63EDC: 02032545
	.long 0xd73d0091                                           // 000000B63EE0: D73D0091
	v_cndmask_b32_e32 v1, v70, v146, vcc_lo                    // 000000B63EE4: 02032546
	v_and_b32_e32 v147, 0xffff, v153                           // 000000B63EE8: 372732FF 0000FFFF
	v_and_b32_e32 v153, 0xffff, v159                           // 000000B63EF0: 37333EFF 0000FFFF
	.long 0xd72c0023                                           // 000000B63EF8: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000B63EFC: 020246FF 83DCD12D
	v_and_b32_e32 v45, 0xffff, v45                             // 000000B63F04: 365A5AFF 0000FFFF
	v_sad_u8 v151, v151, 0, 0x6400                             // 000000B63F0C: D6220097 03FD0197 00006400
	v_and_b32_e32 v34, 0xffff, v34                             // 000000B63F18: 364444FF 0000FFFF
	.long 0xd72c0099                                           // 000000B63F20: D72C0099
	v_cndmask_b32_e32 v1, 0x83dcd12d, v153, vcc_lo             // 000000B63F24: 020332FF 83DCD12D
	v_and_b32_e32 v48, 0xffff, v48                             // 000000B63F2C: 366060FF 0000FFFF
	.long 0xd72c002d                                           // 000000B63F34: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000B63F38: 02025AFF 83DCD12D
	v_and_b32_e32 v151, 0xffff, v151                           // 000000B63F40: 372F2EFF 0000FFFF
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000B63F48: D6220023 03FD0123 00006400
	v_and_b32_e32 v159, 0xffff, v165                           // 000000B63F54: 373F4AFF 0000FFFF
	v_and_b32_e32 v165, 0xffff, v174                           // 000000B63F5C: 374B5CFF 0000FFFF
	.long 0xd72c0022                                           // 000000B63F64: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000B63F68: 020244FF 83DCD12D
	v_sad_u8 v153, v153, 0, 0x6400                             // 000000B63F70: D6220099 03FD0199 00006400
	v_lshl_or_b32 v35, v35, 16, v151                           // 000000B63F7C: D6560023 065D2123
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000B63F84: D622002D 03FD012D 00006400
	.long 0xd72c0030                                           // 000000B63F90: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000B63F94: 020260FF 83DCD12D
	v_and_b32_e32 v145, 0xffff, v145                           // 000000B63F9C: 372322FF 0000FFFF
	v_and_b32_e32 v153, 0xffff, v153                           // 000000B63FA4: 373332FF 0000FFFF
	v_pk_fma_f16 v151, v35, s12, 0xc931 op_sel_hi:[1,0,0]      // 000000B63FAC: CC0E0097 0BFC1923 0000C931
	v_and_b32_e32 v49, 0xffff, v150                            // 000000B63FB8: 36632CFF 0000FFFF
	v_and_b32_e32 v150, 0xffff, v156                           // 000000B63FC0: 372D38FF 0000FFFF
	v_and_b32_e32 v156, 0xffff, v162                           // 000000B63FC8: 373944FF 0000FFFF
	v_lshl_or_b32 v45, v45, 16, v153                           // 000000B63FD0: D656002D 0665212D
	.long 0xd72c00a5                                           // 000000B63FD8: D72C00A5
	v_cndmask_b32_e32 v1, 0x83dcd12d, v165, vcc_lo             // 000000B63FDC: 02034AFF 83DCD12D
	.long 0xd73d001e                                           // 000000B63FE4: D73D001E
	v_cndmask_b32_e32 v1, v70, v30, vcc_lo                     // 000000B63FE8: 02023D46
	.long 0xd72c0096                                           // 000000B63FEC: D72C0096
	v_cndmask_b32_e32 v1, 0x83dcd12d, v150, vcc_lo             // 000000B63FF0: 02032CFF 83DCD12D
	.long 0xd72c009c                                           // 000000B63FF8: D72C009C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v156, vcc_lo             // 000000B63FFC: 020338FF 83DCD12D
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000B64004: D6220022 03FD0122 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000B64010: D6220030 03FD0130 00006400
	v_pk_fma_f16 v45, v45, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B6401C: CC0E002D 0BFC192D 0000C931
	v_and_b32_e32 v146, 0xffff, v152                           // 000000B64028: 372530FF 0000FFFF
	.long 0xd72c0091                                           // 000000B64030: D72C0091
	v_cndmask_b32_e32 v1, 0x83dcd12d, v145, vcc_lo             // 000000B64034: 020322FF 83DCD12D
	v_and_b32_e32 v30, 0xffff, v30                             // 000000B6403C: 363C3CFF 0000FFFF
	v_sad_u8 v150, v150, 0, 0x6400                             // 000000B64044: D6220096 03FD0196 00006400
	v_sad_u8 v156, v156, 0, 0x6400                             // 000000B64050: D622009C 03FD019C 00006400
	.long 0xd72c0092                                           // 000000B6405C: D72C0092
	v_cndmask_b32_e32 v1, 0x83dcd12d, v146, vcc_lo             // 000000B64060: 020324FF 83DCD12D
	v_sad_u8 v165, v165, 0, 0x6400                             // 000000B64068: D62200A5 03FD01A5 00006400
	v_and_b32_e32 v34, 0xffff, v34                             // 000000B64074: 364444FF 0000FFFF
	v_and_b32_e32 v48, 0xffff, v48                             // 000000B6407C: 366060FF 0000FFFF
	v_and_b32_e32 v46, 0xffff, v46                             // 000000B64084: 365C5CFF 0000FFFF
	.long 0xd72c001e                                           // 000000B6408C: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 000000B64090: 02023CFF 83DCD12D
	v_sad_u8 v145, v145, 0, 0x6400                             // 000000B64098: D6220091 03FD0191 00006400
	v_and_b32_e32 v165, 0xffff, v165                           // 000000B640A4: 374B4AFF 0000FFFF
	v_lshl_or_b32 v34, v150, 16, v34                           // 000000B640AC: D6560022 04892196
	v_lshl_or_b32 v48, v156, 16, v48                           // 000000B640B4: D6560030 04C1219C
	v_sad_u8 v146, v146, 0, 0x6400                             // 000000B640BC: D6220092 03FD0192 00006400
	v_and_b32_e32 v36, 0xffff, v36                             // 000000B640C8: 364848FF 0000FFFF
	.long 0xd72c002e                                           // 000000B640D0: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000B640D4: 02025CFF 83DCD12D
	v_lshl_or_b32 v145, v145, 16, v165                         // 000000B640DC: D6560091 06952191
	v_pk_fma_f16 v150, v34, s12, 0xc931 op_sel_hi:[1,0,0]      // 000000B640E4: CC0E0096 0BFC1922 0000C931
	v_and_b32_e32 v37, 0xffff, v148                            // 000000B640F0: 364B28FF 0000FFFF
	v_pk_fma_f16 v48, v48, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B640F8: CC0E0030 0BFC1930 0000C931
	v_and_b32_e32 v148, 0xffff, v154                           // 000000B64104: 372934FF 0000FFFF
	v_and_b32_e32 v154, 0xffff, v160                           // 000000B6410C: 373540FF 0000FFFF
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000B64114: D622001E 03FD011E 00006400
	v_and_b32_e32 v146, 0xffff, v146                           // 000000B64120: 372524FF 0000FFFF
	v_and_b32_e32 v162, 0xffff, v171                           // 000000B64128: 374556FF 0000FFFF
	.long 0xd72c0024                                           // 000000B64130: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 000000B64134: 020248FF 83DCD12D
	.long 0xd72c009a                                           // 000000B6413C: D72C009A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v154, vcc_lo             // 000000B64140: 020334FF 83DCD12D
	v_pk_fma_f16 v171, v145, s12, 0xc931 op_sel_hi:[1,0,0]     // 000000B64148: CC0E00AB 0BFC1991 0000C931
	v_and_b32_e32 v152, 0xffff, v158                           // 000000B64154: 37313CFF 0000FFFF
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000B6415C: D622002E 03FD012E 00006400
	v_lshl_or_b32 v30, v30, 16, v146                           // 000000B64168: D656001E 0649211E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B64170: BF870214
	v_dual_mov_b32 v175, v171 :: v_dual_and_b32 v56, 0xffff, v56// 000000B64174: CA2401AB AF3870FF 0000FFFF
	.long 0xd72c0098                                           // 000000B64180: D72C0098
	v_cndmask_b32_e32 v1, 0x83dcd12d, v152, vcc_lo             // 000000B64184: 020330FF 83DCD12D
	v_and_b32_e32 v157, 0xffff, v163                           // 000000B6418C: 373B46FF 0000FFFF
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000B64194: D6220024 03FD0124 00006400
	v_sad_u8 v154, v154, 0, 0x6400                             // 000000B641A0: D622009A 03FD019A 00006400
	v_and_b32_e32 v46, 0xffff, v46                             // 000000B641AC: 365C5CFF 0000FFFF
	v_pk_fma_f16 v146, v30, s12, 0xc931 op_sel_hi:[1,0,0]      // 000000B641B4: CC0E0092 0BFC191E 0000C931
	v_and_b32_e32 v31, 0xffff, v44                             // 000000B641C0: 363E58FF 0000FFFF
	v_and_b32_e32 v44, 0xffff, v149                            // 000000B641C8: 36592AFF 0000FFFF
	v_and_b32_e32 v149, 0xffff, v155                           // 000000B641D0: 372B36FF 0000FFFF
	v_and_b32_e32 v155, 0xffff, v161                           // 000000B641D8: 373742FF 0000FFFF
	v_and_b32_e32 v161, 0xffff, v170                           // 000000B641E0: 374354FF 0000FFFF
	v_and_b32_e32 v163, 0xffff, v172                           // 000000B641E8: 374758FF 0000FFFF
	.long 0xd72c0038                                           // 000000B641F0: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000B641F4: 020270FF 83DCD12D
	v_and_b32_e32 v54, 0xffff, v54                             // 000000B641FC: 366C6CFF 0000FFFF
	.long 0xd72c001f                                           // 000000B64204: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000B64208: 02023EFF 83DCD12D
	.long 0xd72c009d                                           // 000000B64210: D72C009D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v157, vcc_lo             // 000000B64214: 02033AFF 83DCD12D
	v_sad_u8 v152, v152, 0, 0x6400                             // 000000B6421C: D6220098 03FD0198 00006400
	v_and_b32_e32 v36, 0xffff, v36                             // 000000B64228: 364848FF 0000FFFF
	v_lshl_or_b32 v46, v154, 16, v46                           // 000000B64230: D656002E 04B9219A
	v_mov_b32_e32 v154, v151                                   // 000000B64238: 7F340397
	.long 0xd72c0031                                           // 000000B6423C: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000B64240: 020262FF 83DCD12D
	v_and_b32_e32 v158, 0xffff, v164                           // 000000B64248: 373D48FF 0000FFFF
	v_and_b32_e32 v144, 0xffff, v144                           // 000000B64250: 372120FF 0000FFFF
	v_and_b32_e32 v164, 0xffff, v173                           // 000000B64258: 37495AFF 0000FFFF
	.long 0xd72c00a1                                           // 000000B64260: D72C00A1
	v_cndmask_b32_e32 v1, 0x83dcd12d, v161, vcc_lo             // 000000B64264: 020342FF 83DCD12D
	.long 0xd72c00a2                                           // 000000B6426C: D72C00A2
	v_cndmask_b32_e32 v1, 0x83dcd12d, v162, vcc_lo             // 000000B64270: 020344FF 83DCD12D
	.long 0xd72c00a3                                           // 000000B64278: D72C00A3
	v_cndmask_b32_e32 v1, 0x83dcd12d, v163, vcc_lo             // 000000B6427C: 020346FF 83DCD12D
	.long 0xd72c0039                                           // 000000B64284: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000B64288: 020272FF 83DCD12D
	.long 0xd72c0036                                           // 000000B64290: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000B64294: 02026CFF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000B6429C: D6220038 03FD0138 00006400
	v_lshl_or_b32 v36, v152, 16, v36                           // 000000B642A8: D6560024 04912198
	v_mov_b32_e32 v152, v150                                   // 000000B642B0: 7F300396
	.long 0xd72c0025                                           // 000000B642B4: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000B642B8: 02024AFF 83DCD12D
	.long 0xd72c0090                                           // 000000B642C0: D72C0090
	v_cndmask_b32_e32 v1, 0x83dcd12d, v144, vcc_lo             // 000000B642C4: 020320FF 83DCD12D
	.long 0xd72c00a4                                           // 000000B642CC: D72C00A4
	v_cndmask_b32_e32 v1, 0x83dcd12d, v164, vcc_lo             // 000000B642D0: 020348FF 83DCD12D
	v_sad_u8 v31, v31, 0, 0x6400                               // 000000B642D8: D622001F 03FD011F 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000B642E4: D6220031 03FD0131 00006400
	v_sad_u8 v157, v157, 0, 0x6400                             // 000000B642F0: D622009D 03FD019D 00006400
	v_sad_u8 v161, v161, 0, 0x6400                             // 000000B642FC: D62200A1 03FD01A1 00006400
	v_sad_u8 v162, v162, 0, 0x6400                             // 000000B64308: D62200A2 03FD01A2 00006400
	v_sad_u8 v163, v163, 0, 0x6400                             // 000000B64314: D62200A3 03FD01A3 00006400
	v_and_b32_e32 v56, 0xffff, v56                             // 000000B64320: 367070FF 0000FFFF
	v_and_b32_e32 v47, 0xffff, v47                             // 000000B64328: 365E5EFF 0000FFFF
	.long 0xd72c009b                                           // 000000B64330: D72C009B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v155, vcc_lo             // 000000B64334: 020336FF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000B6433C: D6220025 03FD0125 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000B64348: D6220039 03FD0139 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000B64354: D6220036 03FD0136 00006400
	v_and_b32_e32 v31, 0xffff, v31                             // 000000B64360: 363E3EFF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v49                             // 000000B64368: 366262FF 0000FFFF
	v_and_b32_e32 v157, 0xffff, v157                           // 000000B64370: 373B3AFF 0000FFFF
	v_sad_u8 v144, v144, 0, 0x6400                             // 000000B64378: D6220090 03FD0190 00006400
	v_sad_u8 v164, v164, 0, 0x6400                             // 000000B64384: D62200A4 03FD01A4 00006400
	v_and_b32_e32 v162, 0xffff, v162                           // 000000B64390: 374544FF 0000FFFF
	v_and_b32_e32 v163, 0xffff, v163                           // 000000B64398: 374746FF 0000FFFF
	v_lshl_or_b32 v56, v161, 16, v56                           // 000000B643A0: D6560038 04E121A1
	.long 0xd72c002f                                           // 000000B643A8: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000B643AC: 02025EFF 83DCD12D
	v_lshl_or_b32 v31, v37, 16, v31                            // 000000B643B4: D656001F 047D2125
	v_lshl_or_b32 v37, v57, 16, v49                            // 000000B643BC: D6560025 04C52139
	v_lshl_or_b32 v49, v54, 16, v157                           // 000000B643C4: D6560031 06752136
	v_sad_u8 v155, v155, 0, 0x6400                             // 000000B643CC: D622009B 03FD019B 00006400
	v_lshl_or_b32 v57, v144, 16, v162                          // 000000B643D8: D6560039 06892190
	v_lshl_or_b32 v144, v164, 16, v163                         // 000000B643E0: D6560090 068D21A4
	v_pk_fma_f16 v56, v56, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B643E8: CC0E0038 0BFC1938 0000C931
	v_pk_fma_f16 v49, v49, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B643F4: CC0E0031 0BFC1931 0000C931
	.long 0xd72c002c                                           // 000000B64400: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000B64404: 020258FF 83DCD12D
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000B6440C: D622002F 03FD012F 00006400
	v_and_b32_e32 v155, 0xffff, v155                           // 000000B64418: 373736FF 0000FFFF
	v_pk_fma_f16 v153, v36, s12, 0xc931 op_sel_hi:[1,0,0]      // 000000B64420: CC0E0099 0BFC1924 0000C931
	v_and_b32_e32 v32, 0xffff, v32                             // 000000B6442C: 364040FF 0000FFFF
	v_pk_fma_f16 v170, v144, s12, 0xc931 op_sel_hi:[1,0,0]     // 000000B64434: CC0E00AA 0BFC1990 0000C931
	v_dual_mov_b32 v172, v56 :: v_dual_and_b32 v33, 0xffff, v33// 000000B64440: CA240138 AC2042FF 0000FFFF
	.long 0xd72c0095                                           // 000000B6444C: D72C0095
	v_cndmask_b32_e32 v1, 0x83dcd12d, v149, vcc_lo             // 000000B64450: 02032AFF 83DCD12D
	v_mov_b32_e32 v162, v49                                    // 000000B64458: 7F440331
	.long 0xd72c0093                                           // 000000B6445C: D72C0093
	v_cndmask_b32_e32 v1, 0x83dcd12d, v147, vcc_lo             // 000000B64460: 020326FF 83DCD12D
	v_lshl_or_b32 v47, v47, 16, v155                           // 000000B64468: D656002F 066D212F
	v_mov_b32_e32 v155, v153                                   // 000000B64470: 7F360399
	.long 0xd72c0020                                           // 000000B64474: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 000000B64478: 020240FF 83DCD12D
	v_mov_b32_e32 v174, v170                                   // 000000B64480: 7F5C03AA
	.long 0xd72c0021                                           // 000000B64484: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000B64488: 020242FF 83DCD12D
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000B64490: D622002C 03FD012C 00006400
	v_sad_u8 v149, v149, 0, 0x6400                             // 000000B6449C: D6220095 03FD0195 00006400
	v_mov_b32_e32 v161, v48                                    // 000000B644A8: 7F420330
	.long 0xd72c0094                                           // 000000B644AC: D72C0094
	v_cndmask_b32_e32 v1, 0x83dcd12d, v148, vcc_lo             // 000000B644B0: 020328FF 83DCD12D
	v_sad_u8 v147, v147, 0, 0x6400                             // 000000B644B8: D6220093 03FD0193 00006400
	v_sad_u8 v32, v32, 0, 0x6400                               // 000000B644C4: D6220020 03FD0120 00006400
	v_and_b32_e32 v44, 0xffff, v44                             // 000000B644D0: 365858FF 0000FFFF
	v_sad_u8 v33, v33, 0, 0x6400                               // 000000B644D8: D6220021 03FD0121 00006400
	v_and_b32_e32 v149, 0xffff, v149                           // 000000B644E4: 372B2AFF 0000FFFF
	.long 0xd72c009e                                           // 000000B644EC: D72C009E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v158, vcc_lo             // 000000B644F0: 02033CFF 83DCD12D
	v_and_b32_e32 v147, 0xffff, v147                           // 000000B644F8: 372726FF 0000FFFF
	v_sad_u8 v148, v148, 0, 0x6400                             // 000000B64500: D6220094 03FD0194 00006400
	v_lshl_or_b32 v32, v32, 16, v44                            // 000000B6450C: D6560020 04B12120
	v_lshl_or_b32 v33, v33, 16, v149                           // 000000B64514: D6560021 06552121
	v_pk_fma_f16 v31, v31, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B6451C: CC0E001F 0BFC191F 0000C931
	.long 0xd72c009f                                           // 000000B64528: D72C009F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v159, vcc_lo             // 000000B6452C: 02033EFF 83DCD12D
	v_lshl_or_b32 v44, v148, 16, v147                          // 000000B64534: D656002C 064D2194
	v_sad_u8 v158, v158, 0, 0x6400                             // 000000B6453C: D622009E 03FD019E 00006400
	v_pk_fma_f16 v32, v32, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64548: CC0E0020 0BFC1920 0000C931
	v_pk_fma_f16 v37, v37, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64554: CC0E0025 0BFC1925 0000C931
	v_pk_fma_f16 v147, v33, s12, 0xc931 op_sel_hi:[1,0,0]      // 000000B64560: CC0E0093 0BFC1921 0000C931
	v_mov_b32_e32 v33, v31                                     // 000000B6456C: 7E42031F
	ds_load_b128 v[80:83], v92                                 // 000000B64570: DBFC0000 5000005C
	ds_load_b128 v[84:87], v92 offset:16                       // 000000B64578: DBFC0010 5400005C
	ds_load_b128 v[88:91], v92 offset:4352                     // 000000B64580: DBFC1100 5800005C
	ds_load_b128 v[92:95], v92 offset:4368                     // 000000B64588: DBFC1110 5C00005C
	v_pk_fma_f16 v44, v44, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64590: CC0E002C 0BFC192C 0000C931
	v_sad_u8 v159, v159, 0, 0x6400                             // 000000B6459C: D622009F 03FD019F 00006400
	v_and_b32_e32 v158, 0xffff, v158                           // 000000B645A8: 373D3CFF 0000FFFF
	v_pk_fma_f16 v46, v46, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B645B0: CC0E002E 0BFC192E 0000C931
	v_dual_mov_b32 v35, v32 :: v_dual_mov_b32 v36, v37         // 000000B645BC: CA100120 23240125
	v_mov_b32_e32 v144, v146                                   // 000000B645C4: 7F200392
	v_dual_mov_b32 v145, v44 :: v_dual_and_b32 v160, 0xffff, v166// 000000B645C8: CA24012C 91A14CFF 0000FFFF
	v_mov_b32_e32 v157, v45                                    // 000000B645D4: 7F3A032D
	v_lshl_or_b32 v54, v159, 16, v158                          // 000000B645D8: D6560036 0679219F
	v_dual_mov_b32 v149, v147 :: v_dual_mov_b32 v158, v46      // 000000B645E0: CA100193 959E012E
	v_permlanex16_b32 v33, v33, s13, 0xfedcba98                // 000000B645E8: D65C0021 03FC1B21 FEDCBA98
	v_permlanex16_b32 v35, v35, s13, 0xfedcba98                // 000000B645F4: D65C0023 03FC1B23 FEDCBA98
	v_permlanex16_b32 v36, v36, s13, 0xfedcba98                // 000000B64600: D65C0024 03FC1B24 FEDCBA98
	v_permlanex16_b32 v144, v144, s13, 0xfedcba98              // 000000B6460C: D65C0090 03FC1B90 FEDCBA98
	v_pk_fma_f16 v47, v47, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64618: CC0E002F 0BFC192F 0000C931
	v_and_b32_e32 v55, 0xffff, v55                             // 000000B64624: 366E6EFF 0000FFFF
	.long 0xd72c00a0                                           // 000000B6462C: D72C00A0
	v_cndmask_b32_e32 v1, 0x83dcd12d, v160, vcc_lo             // 000000B64630: 020340FF 83DCD12D
	v_permlanex16_b32 v145, v145, s13, 0xfedcba98              // 000000B64638: D65C0091 03FC1B91 FEDCBA98
	v_permlanex16_b32 v152, v152, s13, 0xfedcba98              // 000000B64644: D65C0098 03FC1B98 FEDCBA98
	v_permlanex16_b32 v155, v155, s13, 0xfedcba98              // 000000B64650: D65C009B 03FC1B9B FEDCBA98
	v_permlanex16_b32 v157, v157, s13, 0xfedcba98              // 000000B6465C: D65C009D 03FC1B9D FEDCBA98
	v_permlanex16_b32 v149, v149, s13, 0xfedcba98              // 000000B64668: D65C0095 03FC1B95 FEDCBA98
	v_permlanex16_b32 v154, v154, s13, 0xfedcba98              // 000000B64674: D65C009A 03FC1B9A FEDCBA98
	v_permlanex16_b32 v158, v158, s13, 0xfedcba98              // 000000B64680: D65C009E 03FC1B9E FEDCBA98
	v_cndmask_b32_e64 v30, v33, v31, s2                        // 000000B6468C: D501001E 000A3F21
	v_cndmask_b32_e64 v34, v31, v33, s2                        // 000000B64694: D5010022 000A431F
	v_cndmask_b32_e64 v31, v35, v32, s2                        // 000000B6469C: D501001F 000A4123
	v_cndmask_b32_e64 v35, v32, v35, s2                        // 000000B646A4: D5010023 000A4720
	v_cndmask_b32_e64 v32, v36, v37, s2                        // 000000B646AC: D5010020 000A4B24
	v_cndmask_b32_e64 v36, v37, v36, s2                        // 000000B646B4: D5010024 000A4925
	v_cndmask_b32_e64 v33, v144, v146, s2                      // 000000B646BC: D5010021 000B2590
	v_cndmask_b32_e64 v37, v146, v144, s2                      // 000000B646C4: D5010025 000B2192
	v_mov_b32_e32 v159, v47                                    // 000000B646CC: 7F3E032F
	.long 0xd72c0037                                           // 000000B646D0: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000B646D4: 02026EFF 83DCD12D
	v_cndmask_b32_e64 v144, v145, v44, s2                      // 000000B646DC: D5010090 000A5991
	v_cndmask_b32_e64 v148, v44, v145, s2                      // 000000B646E4: D5010094 000B232C
	v_cndmask_b32_e64 v146, v152, v150, s2                     // 000000B646EC: D5010092 000B2D98
	v_cndmask_b32_e64 v150, v150, v152, s2                     // 000000B646F4: D5010096 000B3196
	v_cndmask_b32_e64 v152, v155, v153, s2                     // 000000B646FC: D5010098 000B339B
	v_cndmask_b32_e64 v156, v153, v155, s2                     // 000000B64704: D501009C 000B3799
	v_cndmask_b32_e64 v153, v157, v45, s2                      // 000000B6470C: D5010099 000A5B9D
	v_cndmask_b32_e64 v157, v45, v157, s2                      // 000000B64714: D501009D 000B3B2D
	s_waitcnt vmcnt(10)                                        // 000000B6471C: BF892BF7
	.long 0xd73d002c                                           // 000000B64720: D73D002C
	v_cndmask_b32_e32 v1, v63, v50, vcc_lo                     // 000000B64724: 0202653F
	v_cndmask_b32_e64 v145, v149, v147, s2                     // 000000B64728: D5010091 000B2795
	v_cndmask_b32_e64 v149, v147, v149, s2                     // 000000B64730: D5010095 000B2B93
	v_cndmask_b32_e64 v147, v154, v151, s2                     // 000000B64738: D5010093 000B2F9A
	v_cndmask_b32_e64 v151, v151, v154, s2                     // 000000B64740: D5010097 000B3597
	v_cndmask_b32_e64 v154, v158, v46, s2                      // 000000B64748: D501009A 000A5D9E
	v_cndmask_b32_e64 v158, v46, v158, s2                      // 000000B64750: D501009E 000B3D2E
	.long 0xd73d002d                                           // 000000B64758: D73D002D
	v_cndmask_b32_e32 v1, v64, v50, vcc_lo                     // 000000B6475C: 02026540
	s_waitcnt lgkmcnt(2)                                       // 000000B64760: BF89FC27
	v_wmma_f32_16x16x16_f16 v[2:9], v[30:37], v[80:87], v[2:9] // 000000B64764: CC404002 1C0AA11E
	s_waitcnt lgkmcnt(0)                                       // 000000B6476C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[30:37], v[88:95], v[10:17]// 000000B64770: CC40400A 1C2AB11E
	v_add_nc_u32_e32 v33, s28, v79                             // 000000B64778: 4A429E1C
	v_sad_u8 v160, v160, 0, 0x6400                             // 000000B6477C: D62200A0 03FD01A0 00006400
	v_permlanex16_b32 v159, v159, s13, 0xfedcba98              // 000000B64788: D65C009F 03FC1B9F FEDCBA98
	ds_load_b128 v[80:83], v33                                 // 000000B64794: DBFC0000 50000021
	ds_load_b128 v[84:87], v33 offset:16                       // 000000B6479C: DBFC0010 54000021
	ds_load_b128 v[88:91], v33 offset:4352                     // 000000B647A4: DBFC1100 58000021
	ds_load_b128 v[92:95], v33 offset:4368                     // 000000B647AC: DBFC1110 5C000021
	v_and_b32_e32 v33, 0xffff, v44                             // 000000B647B4: 364258FF 0000FFFF
	v_and_b32_e32 v37, 0xffff, v45                             // 000000B647BC: 364A5AFF 0000FFFF
	.long 0xd73d002c                                           // 000000B647C4: D73D002C
	v_cndmask_b32_e32 v1, v65, v50, vcc_lo                     // 000000B647C8: 02026541
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000B647CC: D6220037 03FD0137 00006400
	v_and_b32_e32 v160, 0xffff, v160                           // 000000B647D8: 374140FF 0000FFFF
	v_permlanex16_b32 v161, v161, s13, 0xfedcba98              // 000000B647E0: D65C00A1 03FC1BA1 FEDCBA98
	.long 0xd73d002d                                           // 000000B647EC: D73D002D
	v_cndmask_b32_e32 v1, v66, v50, vcc_lo                     // 000000B647F0: 02026542
	v_permlanex16_b32 v162, v162, s13, 0xfedcba98              // 000000B647F4: D65C00A2 03FC1BA2 FEDCBA98
	v_cndmask_b32_e64 v155, v159, v47, s2                      // 000000B64800: D501009B 000A5F9F
	v_cndmask_b32_e64 v159, v47, v159, s2                      // 000000B64808: D501009F 000B3F2F
	s_waitcnt vmcnt(8)                                         // 000000B64810: BF8923F7
	.long 0xd73d002e                                           // 000000B64814: D73D002E
	v_cndmask_b32_e32 v1, v67, v52, vcc_lo                     // 000000B64818: 02026943
	v_lshl_or_b32 v55, v55, 16, v160                           // 000000B6481C: D6560037 06812137
	v_cndmask_b32_e64 v160, v161, v48, s2                      // 000000B64824: D50100A0 000A61A1
	v_cndmask_b32_e64 v164, v48, v161, s2                      // 000000B6482C: D50100A4 000B4330
	.long 0xd73d002f                                           // 000000B64834: D73D002F
	v_cndmask_b32_e32 v1, v68, v52, vcc_lo                     // 000000B64838: 02026944
	v_cndmask_b32_e64 v161, v162, v49, s2                      // 000000B6483C: D50100A1 000A63A2
	v_cndmask_b32_e64 v165, v49, v162, s2                      // 000000B64844: D50100A5 000B4531
	.long 0xd73d0030                                           // 000000B6484C: D73D0030
	v_cndmask_b32_e32 v1, v69, v52, vcc_lo                     // 000000B64850: 02026945
	v_and_b32_e32 v49, 0xffff, v44                             // 000000B64854: 366258FF 0000FFFF
	v_and_b32_e32 v46, 0xffff, v46                             // 000000B6485C: 365C5CFF 0000FFFF
	v_and_b32_e32 v50, 0xffff, v45                             // 000000B64864: 36645AFF 0000FFFF
	.long 0xd73d002c                                           // 000000B6486C: D73D002C
	v_cndmask_b32_e32 v1, v70, v52, vcc_lo                     // 000000B64870: 02026946
	.long 0xd72c0021                                           // 000000B64874: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000B64878: 020242FF 83DCD12D
	v_and_b32_e32 v45, 0xffff, v47                             // 000000B64880: 365A5EFF 0000FFFF
	v_and_b32_e32 v47, 0xffff, v48                             // 000000B64888: 365E60FF 0000FFFF
	.long 0xd72c0030                                           // 000000B64890: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000B64894: 020262FF 83DCD12D
	.long 0xd72c002e                                           // 000000B6489C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000B648A0: 02025CFF 83DCD12D
	v_and_b32_e32 v44, 0xffff, v44                             // 000000B648A8: 365858FF 0000FFFF
	.long 0xd72c0025                                           // 000000B648B0: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000B648B4: 02024AFF 83DCD12D
	.long 0xd72c002f                                           // 000000B648BC: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000B648C0: 02025EFF 83DCD12D
	.long 0xd72c0031                                           // 000000B648C8: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000B648CC: 020264FF 83DCD12D
	.long 0xd72c002d                                           // 000000B648D4: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000B648D8: 02025AFF 83DCD12D
	v_pk_fma_f16 v54, v54, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B648E0: CC0E0036 0BFC1936 0000C931
	v_pk_fma_f16 v55, v55, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B648EC: CC0E0037 0BFC1937 0000C931
	v_sad_u8 v33, v33, 0, 0x6400                               // 000000B648F8: D6220021 03FD0121 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000B64904: D6220030 03FD0130 00006400
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000B64910: D622002E 03FD012E 00006400
	.long 0xd72c002c                                           // 000000B6491C: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000B64920: 020258FF 83DCD12D
	v_pk_fma_f16 v57, v57, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64928: CC0E0039 0BFC1939 0000C931
	v_mov_b32_e32 v163, v54                                    // 000000B64934: 7F460336
	v_mov_b32_e32 v167, v55                                    // 000000B64938: 7F4E0337
	v_and_b32_e32 v33, 0xffff, v33                             // 000000B6493C: 364242FF 0000FFFF
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000B64944: D6220025 03FD0125 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000B64950: D622002F 03FD012F 00006400
	v_and_b32_e32 v48, 0xffff, v48                             // 000000B6495C: 366060FF 0000FFFF
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000B64964: D6220031 03FD0131 00006400
	v_and_b32_e32 v46, 0xffff, v46                             // 000000B64970: 365C5CFF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000B64978: D622002D 03FD012D 00006400
	v_mov_b32_e32 v173, v57                                    // 000000B64984: 7F5A0339
	v_permlanex16_b32 v163, v163, s13, 0xfedcba98              // 000000B64988: D65C00A3 03FC1BA3 FEDCBA98
	v_permlanex16_b32 v167, v167, s13, 0xfedcba98              // 000000B64994: D65C00A7 03FC1BA7 FEDCBA98
	v_wmma_f32_16x16x16_f16 v[2:9], v[144:151], v[96:103], v[2:9]// 000000B649A0: CC404002 1C0AC190
	v_wmma_f32_16x16x16_f16 v[10:17], v[144:151], v[104:111], v[10:17]// 000000B649A8: CC40400A 1C2AD190
	v_and_b32_e32 v47, 0xffff, v47                             // 000000B649B0: 365E5EFF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000B649B8: D622002C 03FD012C 00006400
	v_lshl_or_b32 v37, v37, 16, v33                            // 000000B649C4: D6560025 04852125
	v_lshl_or_b32 v48, v49, 16, v48                            // 000000B649CC: D6560030 04C12131
	v_lshl_or_b32 v45, v45, 16, v46                            // 000000B649D4: D656002D 04B9212D
	v_permlanex16_b32 v172, v172, s13, 0xfedcba98              // 000000B649DC: D65C00AC 03FC1BAC FEDCBA98
	v_permlanex16_b32 v173, v173, s13, 0xfedcba98              // 000000B649E8: D65C00AD 03FC1BAD FEDCBA98
	v_permlanex16_b32 v174, v174, s13, 0xfedcba98              // 000000B649F4: D65C00AE 03FC1BAE FEDCBA98
	v_cndmask_b32_e64 v162, v163, v54, s2                      // 000000B64A00: D50100A2 000A6DA3
	v_cndmask_b32_e64 v166, v54, v163, s2                      // 000000B64A08: D50100A6 000B4736
	v_cndmask_b32_e64 v163, v167, v55, s2                      // 000000B64A10: D50100A3 000A6FA7
	v_cndmask_b32_e64 v167, v55, v167, s2                      // 000000B64A18: D50100A7 000B4F37
	v_wmma_f32_16x16x16_f16 v[2:9], v[152:159], v[112:119], v[2:9]// 000000B64A20: CC404002 1C0AE198
	v_wmma_f32_16x16x16_f16 v[10:17], v[152:159], v[120:127], v[10:17]// 000000B64A28: CC40400A 1C2AF198
	v_permlanex16_b32 v175, v175, s13, 0xfedcba98              // 000000B64A30: D65C00AF 03FC1BAF FEDCBA98
	v_lshl_or_b32 v44, v44, 16, v47                            // 000000B64A3C: D656002C 04BD212C
	v_pk_fma_f16 v46, v37, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64A44: CC0E002E 0BFC1925 0000C931
	v_pk_fma_f16 v47, v48, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64A50: CC0E002F 0BFC1930 0000C931
	v_pk_fma_f16 v45, v45, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64A5C: CC0E002D 0BFC192D 0000C931
	v_cndmask_b32_e64 v30, v172, v56, s2                       // 000000B64A68: D501001E 000A71AC
	v_cndmask_b32_e64 v34, v56, v172, s2                       // 000000B64A70: D5010022 000B5938
	v_wmma_f32_16x16x16_f16 v[2:9], v[160:167], v[128:135], v[2:9]// 000000B64A78: CC404002 1C0B01A0
	v_wmma_f32_16x16x16_f16 v[10:17], v[160:167], v[136:143], v[10:17]// 000000B64A80: CC40400A 1C2B11A0
	v_cndmask_b32_e64 v31, v173, v57, s2                       // 000000B64A88: D501001F 000A73AD
	v_cndmask_b32_e64 v35, v57, v173, s2                       // 000000B64A90: D5010023 000B5B39
	v_cndmask_b32_e64 v32, v174, v170, s2                      // 000000B64A98: D5010020 000B55AE
	v_cndmask_b32_e64 v36, v170, v174, s2                      // 000000B64AA0: D5010024 000B5DAA
	v_cndmask_b32_e64 v33, v175, v171, s2                      // 000000B64AA8: D5010021 000B57AF
	v_cndmask_b32_e64 v37, v171, v175, s2                      // 000000B64AB0: D5010025 000B5FAB
	v_pk_fma_f16 v57, v44, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64AB8: CC0E0039 0BFC192C 0000C931
	v_mov_b32_e32 v44, v46                                     // 000000B64AC4: 7E58032E
	v_dual_mov_b32 v48, v47 :: v_dual_mov_b32 v49, v45         // 000000B64AC8: CA10012F 3030012D
	s_cselect_b32 s28, s23, 0x44a0                             // 000000B64AD0: 981CFF17 000044A0
	s_waitcnt vmcnt(6)                                         // 000000B64AD8: BF891BF7
	.long 0xd73d0034                                           // 000000B64ADC: D73D0034
	v_cndmask_b32_e32 v1, v63, v40, vcc_lo                     // 000000B64AE0: 0202513F
	.long 0xd73d0035                                           // 000000B64AE4: D73D0035
	v_cndmask_b32_e32 v1, v64, v40, vcc_lo                     // 000000B64AE8: 02025140
	s_waitcnt lgkmcnt(2)                                       // 000000B64AEC: BF89FC27
	v_wmma_f32_16x16x16_f16 v[2:9], v[30:37], v[80:87], v[2:9] // 000000B64AF0: CC404002 1C0AA11E
	v_permlanex16_b32 v44, v44, s13, 0xfedcba98                // 000000B64AF8: D65C002C 03FC1B2C FEDCBA98
	s_waitcnt lgkmcnt(0)                                       // 000000B64B04: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[30:37], v[88:95], v[10:17]// 000000B64B08: CC40400A 1C2AB11E
	v_permlanex16_b32 v48, v48, s13, 0xfedcba98                // 000000B64B10: D65C0030 03FC1B30 FEDCBA98
	v_permlanex16_b32 v49, v49, s13, 0xfedcba98                // 000000B64B1C: D65C0031 03FC1B31 FEDCBA98
	v_add_nc_u32_e32 v33, s28, v79                             // 000000B64B28: 4A429E1C
	v_cndmask_b32_e64 v30, v44, v46, s2                        // 000000B64B2C: D501001E 000A5D2C
	v_cndmask_b32_e64 v34, v46, v44, s2                        // 000000B64B34: D5010022 000A592E
	v_cndmask_b32_e64 v31, v48, v47, s2                        // 000000B64B3C: D501001F 000A5F30
	v_cndmask_b32_e64 v35, v47, v48, s2                        // 000000B64B44: D5010023 000A612F
	v_cndmask_b32_e64 v32, v49, v45, s2                        // 000000B64B4C: D5010020 000A5B31
	v_cndmask_b32_e64 v36, v45, v49, s2                        // 000000B64B54: D5010024 000A632D
	ds_load_b128 v[44:47], v33                                 // 000000B64B5C: DBFC0000 2C000021
	ds_load_b128 v[48:51], v33 offset:16                       // 000000B64B64: DBFC0010 30000021
	ds_load_b128 v[80:83], v33 offset:4352                     // 000000B64B6C: DBFC1100 50000021
	ds_load_b128 v[84:87], v33 offset:4368                     // 000000B64B74: DBFC1110 54000021
	v_and_b32_e32 v33, 0xffff, v52                             // 000000B64B7C: 364268FF 0000FFFF
	v_and_b32_e32 v88, 0xffff, v53                             // 000000B64B84: 36B06AFF 0000FFFF
	.long 0xd73d0034                                           // 000000B64B8C: D73D0034
	v_cndmask_b32_e32 v1, v65, v40, vcc_lo                     // 000000B64B90: 02025141
	s_waitcnt vmcnt(4)                                         // 000000B64B94: BF8913F7
	.long 0xd73d0035                                           // 000000B64B98: D73D0035
	v_cndmask_b32_e32 v1, v67, v38, vcc_lo                     // 000000B64B9C: 02024D43
	.long 0xd73d0036                                           // 000000B64BA0: D73D0036
	v_cndmask_b32_e32 v1, v68, v38, vcc_lo                     // 000000B64BA4: 02024D44
	.long 0xd73d0028                                           // 000000B64BA8: D73D0028
	v_cndmask_b32_e32 v1, v66, v40, vcc_lo                     // 000000B64BAC: 02025142
	.long 0xd73d0037                                           // 000000B64BB0: D73D0037
	v_cndmask_b32_e32 v1, v69, v38, vcc_lo                     // 000000B64BB4: 02024D45
	.long 0xd73d0025                                           // 000000B64BB8: D73D0025
	v_cndmask_b32_e32 v1, v70, v38, vcc_lo                     // 000000B64BBC: 02024D46
	v_and_b32_e32 v41, 0xffff, v52                             // 000000B64BC0: 365268FF 0000FFFF
	.long 0xd72c0021                                           // 000000B64BC8: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000B64BCC: 020242FF 83DCD12D
	v_and_b32_e32 v52, 0xffff, v53                             // 000000B64BD4: 36686AFF 0000FFFF
	v_and_b32_e32 v40, 0xffff, v40                             // 000000B64BDC: 365050FF 0000FFFF
	v_and_b32_e32 v39, 0xffff, v55                             // 000000B64BE4: 364E6EFF 0000FFFF
	.long 0xd72c0029                                           // 000000B64BEC: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 000000B64BF0: 020252FF 83DCD12D
	v_and_b32_e32 v38, 0xffff, v54                             // 000000B64BF8: 364C6CFF 0000FFFF
	.long 0xd72c0034                                           // 000000B64C00: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000B64C04: 020268FF 83DCD12D
	v_and_b32_e32 v37, 0xffff, v37                             // 000000B64C0C: 364A4AFF 0000FFFF
	.long 0xd72c0035                                           // 000000B64C14: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000B64C18: 0202B0FF 83DCD12D
	.long 0xd72c0027                                           // 000000B64C20: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000B64C24: 02024EFF 83DCD12D
	.long 0xd72c0028                                           // 000000B64C2C: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000B64C30: 020250FF 83DCD12D
	v_sad_u8 v33, v33, 0, 0x6400                               // 000000B64C38: D6220021 03FD0121 00006400
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000B64C44: D6220029 03FD0129 00006400
	.long 0xd72c0026                                           // 000000B64C50: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000B64C54: 02024CFF 83DCD12D
	.long 0xd72c0025                                           // 000000B64C5C: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000B64C60: 02024AFF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000B64C68: D6220034 03FD0134 00006400
	v_and_b32_e32 v33, 0xffff, v33                             // 000000B64C74: 364242FF 0000FFFF
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000B64C7C: D6220035 03FD0135 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000B64C88: D6220027 03FD0127 00006400
	v_and_b32_e32 v41, 0xffff, v41                             // 000000B64C94: 365252FF 0000FFFF
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000B64C9C: D6220028 03FD0128 00006400
	v_and_b32_e32 v52, 0xffff, v52                             // 000000B64CA8: 366868FF 0000FFFF
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000B64CB0: D6220026 03FD0126 00006400
	v_and_b32_e32 v39, 0xffff, v39                             // 000000B64CBC: 364E4EFF 0000FFFF
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000B64CC4: D6220025 03FD0125 00006400
	v_lshl_or_b32 v53, v53, 16, v33                            // 000000B64CD0: D6560035 04852135
	v_lshl_or_b32 v40, v40, 16, v41                            // 000000B64CD8: D6560028 04A52128
	v_mov_b32_e32 v96, v57                                     // 000000B64CE0: 7EC00339
	v_lshl_or_b32 v38, v38, 16, v52                            // 000000B64CE4: D6560026 04D12126
	v_lshl_or_b32 v39, v37, 16, v39                            // 000000B64CEC: D6560027 049D2125
	v_pk_fma_f16 v41, v53, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64CF4: CC0E0029 0BFC1935 0000C931
	v_pk_fma_f16 v40, v40, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64D00: CC0E0028 0BFC1928 0000C931
	v_permlanex16_b32 v96, v96, s13, 0xfedcba98                // 000000B64D0C: D65C0060 03FC1B60 FEDCBA98
	v_pk_fma_f16 v52, v38, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64D18: CC0E0034 0BFC1926 0000C931
	v_pk_fma_f16 v53, v39, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64D24: CC0E0035 0BFC1927 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B64D30: BF870214
	v_dual_mov_b32 v38, v41 :: v_dual_mov_b32 v39, v40         // 000000B64D34: CA100129 26260128
	v_cndmask_b32_e64 v33, v96, v57, s2                        // 000000B64D3C: D5010021 000A7360
	v_cndmask_b32_e64 v37, v57, v96, s2                        // 000000B64D44: D5010025 000AC139
	s_cselect_b32 s28, s24, 0x44c0                             // 000000B64D4C: 981CFF18 000044C0
	s_delay_alu instid0(VALU_DEP_3)                            // 000000B64D54: BF870003
	v_permlanex16_b32 v38, v38, s13, 0xfedcba98                // 000000B64D58: D65C0026 03FC1B26 FEDCBA98
	v_permlanex16_b32 v39, v39, s13, 0xfedcba98                // 000000B64D64: D65C0027 03FC1B27 FEDCBA98
	v_add_nc_u32_e32 v55, s28, v79                             // 000000B64D70: 4A6E9E1C
	s_waitcnt lgkmcnt(2)                                       // 000000B64D74: BF89FC27
	v_wmma_f32_16x16x16_f16 v[2:9], v[30:37], v[44:51], v[2:9] // 000000B64D78: CC404002 1C0A591E
	s_waitcnt lgkmcnt(0)                                       // 000000B64D80: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[30:37], v[80:87], v[10:17]// 000000B64D84: CC40400A 1C2AA11E
	v_cndmask_b32_e64 v30, v38, v41, s2                        // 000000B64D8C: D501001E 000A5326
	v_cndmask_b32_e64 v34, v41, v38, s2                        // 000000B64D94: D5010022 000A4D29
	v_cndmask_b32_e64 v31, v39, v40, s2                        // 000000B64D9C: D501001F 000A5127
	v_cndmask_b32_e64 v35, v40, v39, s2                        // 000000B64DA4: D5010023 000A4F28
	s_waitcnt vmcnt(0)                                         // 000000B64DAC: BF8903F7
	.long 0xd73d0026                                           // 000000B64DB0: D73D0026
	v_cndmask_b32_e32 v1, v63, v168, vcc_lo                    // 000000B64DB4: 0203513F
	v_dual_mov_b32 v44, v52 :: v_dual_mov_b32 v45, v53         // 000000B64DB8: CA100134 2C2C0135
	s_cselect_b32 s28, s25, 0x44e0                             // 000000B64DC0: 981CFF19 000044E0
	ds_load_b128 v[80:83], v55 offset:4352                     // 000000B64DC8: DBFC1100 50000037
	ds_load_b128 v[84:87], v55 offset:4368                     // 000000B64DD0: DBFC1110 54000037
	s_and_not1_b32 vcc_lo, exec_lo, s26                        // 000000B64DD8: 916A1A7E
	v_permlanex16_b32 v44, v44, s13, 0xfedcba98                // 000000B64DDC: D65C002C 03FC1B2C FEDCBA98
	v_permlanex16_b32 v45, v45, s13, 0xfedcba98                // 000000B64DE8: D65C002D 03FC1B2D FEDCBA98
	v_and_b32_e32 v56, 0xffff, v38                             // 000000B64DF4: 36704CFF 0000FFFF
	.long 0xd73d0026                                           // 000000B64DFC: D73D0026
	v_cndmask_b32_e32 v1, v64, v168, vcc_lo                    // 000000B64E00: 02035140
	.long 0xd73d0027                                           // 000000B64E04: D73D0027
	v_cndmask_b32_e32 v1, v65, v168, vcc_lo                    // 000000B64E08: 02035141
	v_cndmask_b32_e64 v32, v44, v52, s2                        // 000000B64E0C: D5010020 000A692C
	v_cndmask_b32_e64 v36, v52, v44, s2                        // 000000B64E14: D5010024 000A5934
	v_cndmask_b32_e64 v33, v45, v53, s2                        // 000000B64E1C: D5010021 000A6B2D
	v_cndmask_b32_e64 v37, v53, v45, s2                        // 000000B64E24: D5010025 000A5B35
	.long 0xd73d0034                                           // 000000B64E2C: D73D0034
	v_cndmask_b32_e32 v1, v67, v42, vcc_lo                     // 000000B64E30: 02025543
	.long 0xd73d0028                                           // 000000B64E34: D73D0028
	v_cndmask_b32_e32 v1, v66, v168, vcc_lo                    // 000000B64E38: 02035142
	.long 0xd73d0035                                           // 000000B64E3C: D73D0035
	v_cndmask_b32_e32 v1, v68, v42, vcc_lo                     // 000000B64E40: 02025544
	.long 0xd72c0029                                           // 000000B64E44: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000B64E48: 020270FF 83DCD12D
	v_and_b32_e32 v54, 0xffff, v38                             // 000000B64E50: 366C4CFF 0000FFFF
	v_and_b32_e32 v56, 0xffff, v39                             // 000000B64E58: 36704EFF 0000FFFF
	.long 0xd73d0026                                           // 000000B64E60: D73D0026
	v_cndmask_b32_e32 v1, v69, v42, vcc_lo                     // 000000B64E64: 02025545
	v_and_b32_e32 v57, 0xffff, v40                             // 000000B64E68: 367250FF 0000FFFF
	.long 0xd73d0027                                           // 000000B64E70: D73D0027
	v_cndmask_b32_e32 v1, v70, v42, vcc_lo                     // 000000B64E74: 02025546
	v_and_b32_e32 v52, 0xffff, v52                             // 000000B64E78: 366868FF 0000FFFF
	v_and_b32_e32 v53, 0xffff, v53                             // 000000B64E80: 366A6AFF 0000FFFF
	v_sad_u8 v40, v41, 0, 0x6400                               // 000000B64E88: D6220028 03FD0129 00006400
	v_and_b32_e32 v38, 0xffff, v38                             // 000000B64E94: 364C4CFF 0000FFFF
	.long 0xd72c0029                                           // 000000B64E9C: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000B64EA0: 020270FF 83DCD12D
	v_and_b32_e32 v39, 0xffff, v39                             // 000000B64EA8: 364E4EFF 0000FFFF
	.long 0xd72c002b                                           // 000000B64EB0: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000B64EB4: 020268FF 83DCD12D
	.long 0xd72c002a                                           // 000000B64EBC: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000B64EC0: 02026CFF 83DCD12D
	.long 0xd72c0026                                           // 000000B64EC8: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000B64ECC: 02024CFF 83DCD12D
	.long 0xd72c0034                                           // 000000B64ED4: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000B64ED8: 020272FF 83DCD12D
	.long 0xd72c0027                                           // 000000B64EE0: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000B64EE4: 02024EFF 83DCD12D
	.long 0xd72c0035                                           // 000000B64EEC: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000B64EF0: 02026AFF 83DCD12D
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000B64EF8: D6220029 03FD0129 00006400
	v_and_b32_e32 v40, 0xffff, v40                             // 000000B64F04: 365050FF 0000FFFF
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000B64F0C: D622002B 03FD012B 00006400
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000B64F18: D622002A 03FD012A 00006400
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000B64F24: D6220026 03FD0126 00006400
	v_and_b32_e32 v41, 0xffff, v41                             // 000000B64F30: 365252FF 0000FFFF
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000B64F38: D6220027 03FD0127 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000B64F44: D6220034 03FD0134 00006400
	v_and_b32_e32 v43, 0xffff, v43                             // 000000B64F50: 365656FF 0000FFFF
	v_and_b32_e32 v38, 0xffff, v38                             // 000000B64F58: 364C4CFF 0000FFFF
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000B64F60: D6220035 03FD0135 00006400
	ds_load_b128 v[44:47], v55                                 // 000000B64F6C: DBFC0000 2C000037
	ds_load_b128 v[48:51], v55 offset:16                       // 000000B64F74: DBFC0010 30000037
	v_lshl_or_b32 v40, v42, 16, v40                            // 000000B64F7C: D6560028 04A1212A
	v_lshl_or_b32 v41, v52, 16, v41                            // 000000B64F84: D6560029 04A52134
	v_lshl_or_b32 v38, v39, 16, v38                            // 000000B64F8C: D6560026 04992127
	v_lshl_or_b32 v42, v53, 16, v43                            // 000000B64F94: D656002A 04AD2135
	s_waitcnt lgkmcnt(2)                                       // 000000B64F9C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[10:17], v[30:37], v[80:87], v[10:17]// 000000B64FA0: CC40400A 1C2AA11E
	v_pk_fma_f16 v39, v40, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64FA8: CC0E0027 0BFC1928 0000C931
	v_pk_fma_f16 v40, v41, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64FB4: CC0E0028 0BFC1929 0000C931
	v_pk_fma_f16 v52, v38, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64FC0: CC0E0034 0BFC1926 0000C931
	v_add_nc_u32_e32 v38, s28, v79                             // 000000B64FCC: 4A4C9E1C
	v_pk_fma_f16 v41, v42, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000B64FD0: CC0E0029 0BFC192A 0000C931
	ds_load_b128 v[88:91], v38                                 // 000000B64FDC: DBFC0000 58000026
	ds_load_b128 v[92:95], v38 offset:16                       // 000000B64FE4: DBFC0010 5C000026
	ds_load_b128 v[96:99], v38 offset:4352                     // 000000B64FEC: DBFC1100 60000026
	ds_load_b128 v[100:103], v38 offset:4368                   // 000000B64FF4: DBFC1110 64000026
	v_dual_mov_b32 v42, v39 :: v_dual_mov_b32 v43, v40         // 000000B64FFC: CA100127 2A2A0128
	v_dual_mov_b32 v53, v41 :: v_dual_mov_b32 v54, v52         // 000000B65004: CA100129 35360134
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B6500C: BF870192
	v_permlanex16_b32 v42, v42, s13, 0xfedcba98                // 000000B65010: D65C002A 03FC1B2A FEDCBA98
	v_permlanex16_b32 v43, v43, s13, 0xfedcba98                // 000000B6501C: D65C002B 03FC1B2B FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B65028: BF870213
	v_permlanex16_b32 v53, v53, s13, 0xfedcba98                // 000000B6502C: D65C0035 03FC1B35 FEDCBA98
	v_permlanex16_b32 v54, v54, s13, 0xfedcba98                // 000000B65038: D65C0036 03FC1B36 FEDCBA98
	s_waitcnt lgkmcnt(4)                                       // 000000B65044: BF89FC47
	v_wmma_f32_16x16x16_f16 v[2:9], v[30:37], v[44:51], v[2:9] // 000000B65048: CC404002 1C0A591E
	v_cndmask_b32_e64 v38, v42, v39, s2                        // 000000B65050: D5010026 000A4F2A
	v_cndmask_b32_e64 v42, v39, v42, s2                        // 000000B65058: D501002A 000A5527
	v_cndmask_b32_e64 v39, v43, v40, s2                        // 000000B65060: D5010027 000A512B
	v_cndmask_b32_e64 v43, v40, v43, s2                        // 000000B65068: D501002B 000A5728
	v_cndmask_b32_e64 v40, v53, v41, s2                        // 000000B65070: D5010028 000A5335
	v_cndmask_b32_e64 v44, v41, v53, s2                        // 000000B65078: D501002C 000A6B29
	v_cndmask_b32_e64 v41, v54, v52, s2                        // 000000B65080: D5010029 000A6936
	v_cndmask_b32_e64 v45, v52, v54, s2                        // 000000B65088: D501002D 000A6D34
	s_waitcnt lgkmcnt(2)                                       // 000000B65090: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B65094: BF870001
	v_wmma_f32_16x16x16_f16 v[2:9], v[38:45], v[88:95], v[2:9] // 000000B65098: CC404002 1C0AB126
	s_waitcnt lgkmcnt(0)                                       // 000000B650A0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[38:45], v[96:103], v[10:17]// 000000B650A4: CC40400A 1C2AC126
	s_cbranch_vccnz 64121                                      // 000000B650AC: BFA4FA79 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x7194>
	s_and_b32 s26, s27, exec_lo                                // 000000B650B0: 8B1A7E1B
	s_cselect_b32 s26, 0x4400, 0                               // 000000B650B4: 981A80FF 00004400
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000B650BC: BF870009
	v_lshl_or_b32 v30, v61, 1, s26                             // 000000B650C0: D656001E 0069033D
	s_and_saveexec_b32 s26, s0                                 // 000000B650C8: BE9A2000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B650CC: BF870001
	v_add_nc_u32_e32 v31, v30, v71                             // 000000B650D0: 4A3E8F1E
	ds_store_b128 v31, v[18:21]                                // 000000B650D4: DB7C0000 0000121F
	s_or_b32 exec_lo, exec_lo, s26                             // 000000B650DC: 8C7E1A7E
	s_and_saveexec_b32 s26, s1                                 // 000000B650E0: BE9A2001
	s_cbranch_execz 64106                                      // 000000B650E4: BFA5FA6A <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x7190>
	v_lshl_add_u32 v30, v62, 1, v30                            // 000000B650E8: D646001E 0479033E
	ds_store_b128 v30, v[22:25]                                // 000000B650F0: DB7C0000 0000161E
	s_branch 64101                                             // 000000B650F8: BFA0FA65 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x7190>
	s_mul_i32 s0, s16, 0x1400                                  // 000000B650FC: 9600FF10 00001400
	s_mul_hi_i32 s1, s16, 0x1400                               // 000000B65104: 9701FF10 00001400
	s_add_u32 s2, s14, s0                                      // 000000B6510C: 8002000E
	s_addc_u32 s3, s15, s1                                     // 000000B65110: 8203010F
	s_lshl_b32 s0, s17, 7                                      // 000000B65114: 84008711
	v_and_b32_e32 v1, 1, v0                                    // 000000B65118: 36020081
	s_ashr_i32 s1, s0, 31                                      // 000000B6511C: 86019F00
	v_and_b32_e32 v19, 2, v0                                   // 000000B65120: 36260082
	s_lshl_b64 s[4:5], s[0:1], 1                               // 000000B65124: 84848100
	v_lshrrev_b32_e32 v22, 2, v59                              // 000000B65128: 322C7682
	s_add_u32 s12, s2, s4                                      // 000000B6512C: 800C0402
	s_addc_u32 s13, s3, s5                                     // 000000B65130: 820D0503
	.long 0xd44a0003                                           // 000000B65134: D44A0003
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000B65138: 02020280
	v_lshlrev_b32_e32 v1, 6, v58                               // 000000B6513C: 30027486
	.long 0xd44a0002                                           // 000000B65140: D44A0002
	v_cndmask_b32_e32 v1, 0, v19, vcc_lo                       // 000000B65144: 02022680
	v_and_b32_e32 v19, 4, v0                                   // 000000B65148: 36260084
	v_lshlrev_b32_e32 v23, 3, v59                              // 000000B6514C: 302E7683
	v_and_b32_e32 v20, 8, v0                                   // 000000B65150: 36280088
	v_mad_u32_u24 v1, 0x210, v60, v1                           // 000000B65154: D60B0001 040678FF 00000210
	v_lshlrev_b32_e32 v18, 2, v59                              // 000000B65160: 30247682
	.long 0xd44a0001                                           // 000000B65164: D44A0001
	v_cndmask_b32_e32 v1, 0, v19, vcc_lo                       // 000000B65168: 02022680
	v_and_b32_e32 v21, 16, v0                                  // 000000B6516C: 362A0090
	.long 0xd44a0000                                           // 000000B65170: D44A0000
	v_cndmask_b32_e32 v1, 0, v20, vcc_lo                       // 000000B65174: 02022880
	v_and_or_b32 v19, v22, 4, v1                               // 000000B65178: D6570013 04050916
	.long 0xd7001501                                           // 000000B65180: D7001501
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 000000B65184: 02022E06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000B65188: BF8700D1
	v_add_co_ci_u32_e64 v20, null, s7, 0, s21                  // 000000B6518C: D5207C14 00550007
	ds_store_2addr_b32 v19, v2, v3 offset1:2                   // 000000B65194: D8380200 00030213
	ds_store_2addr_b32 v19, v4, v5 offset0:4 offset1:6         // 000000B6519C: D8380604 00050413
	ds_store_2addr_b32 v19, v6, v7 offset0:8 offset1:10        // 000000B651A4: D8380A08 00070613
	.long 0xd7000401                                           // 000000B651AC: D7000401
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000B651B0: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v20, s4                  // 000000B651B4: D5207C02 00122805
	v_mul_u32_u24_e32 v4, 0x210, v58                           // 000000B651BC: 160874FF 00000210
	v_lshlrev_b32_e32 v3, 1, v18                               // 000000B651C4: 30062481
	s_mov_b32 s5, exec_lo                                      // 000000B651C8: BE85007E
	v_cmp_eq_u32_e32 vcc_lo, 0, v21                            // 000000B651CC: 7C942A80
	ds_store_2addr_b32 v19, v8, v9 offset0:12 offset1:14       // 000000B651D0: D8380E0C 00090813
	s_waitcnt lgkmcnt(0)                                       // 000000B651D8: BF89FC07
	s_barrier                                                  // 000000B651DC: BFBD0000
	buffer_gl0_inv                                             // 000000B651E0: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000B651E8: D4C4007E
	v_cndmask_b32_e32 v1, s19, v58, vcc_lo                     // 000000B651EC: 02027413
	s_cbranch_execz 198                                        // 000000B651F0: BFA500C6 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x8c0c>
	global_load_b64 v[20:21], v3, s[12:13]                     // 000000B651F4: DC560000 140C0003
	v_lshl_add_u32 v5, v18, 2, v4                              // 000000B651FC: D6460005 04110512
	s_mov_b32 s4, 0x76543210                                   // 000000B65204: BE8400FF 76543210
	ds_load_b128 v[5:8], v5                                    // 000000B6520C: DBFC0000 05000005
	s_waitcnt lgkmcnt(0)                                       // 000000B65214: BF89FC07
	v_dual_add_f32 v9, v5, v6 :: v_dual_add_f32 v22, v7, v8    // 000000B65218: C9080D05 09161107
	v_dual_sub_f32 v5, v5, v6 :: v_dual_sub_f32 v6, v7, v8     // 000000B65220: C94A0D05 05061107
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B65228: BF8701A2
	v_sub_f32_e32 v8, v9, v22                                  // 000000B6522C: 08102D09
	v_add_f32_e32 v7, v9, v22                                  // 000000B65230: 060E2D09
	v_add_f32_e32 v9, v5, v6                                   // 000000B65234: 06120D05
	v_sub_f32_e32 v5, v5, v6                                   // 000000B65238: 080A0D05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000B6523C: BF870004
	v_mov_b32_dpp v22, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B65240: 7E2C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000B65248: D5010008 200E1108
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B65250: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000B65258: D5010007 200E0F07
	v_mov_b32_dpp v23, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B65260: 7E2E02FA FF016109
	v_mov_b32_dpp v24, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B65268: 7E3002FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000B65270: D5010005 200E0B05
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000B65278: D5010009 200E1309
	v_add_f32_e32 v8, v8, v22                                  // 000000B65280: 06102D08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B65284: BF870193
	v_dual_add_f32 v6, v7, v6 :: v_dual_add_f32 v5, v5, v24    // 000000B65288: C9080D07 06043105
	v_add_f32_e32 v7, v9, v23                                  // 000000B65290: 060E2F09
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B65294: BF870223
	v_mov_b32_dpp v9, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B65298: 7E1202FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000B652A0: D5010008 200A1108
	v_mov_b32_dpp v22, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B652A8: 7E2C02FA FF016206
	v_mov_b32_dpp v23, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B652B0: 7E2E02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000B652B8: D5010005 200A0B05
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000B652C0: D5010006 200A0D06
	v_add_f32_e32 v8, v8, v9                                   // 000000B652C8: 06101308
	v_mov_b32_dpp v9, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B652CC: 7E1202FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000B652D4: D5010007 200A0F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B652DC: BF870214
	v_dual_add_f32 v5, v5, v23 :: v_dual_add_f32 v6, v6, v22   // 000000B652E0: C9082F05 05062D06
	v_mov_b32_dpp v22, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B652E8: 7E2C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000B652F0: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B652F8: BF870214
	v_add_f32_e32 v7, v7, v9                                   // 000000B652FC: 060E1307
	v_mov_b32_dpp v9, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B65300: 7E1202FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000B65308: D5010005 20060B05
	v_mov_b32_dpp v23, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B65310: 7E2E02FA FF016406
	v_add_f32_e32 v8, v8, v22                                  // 000000B65318: 06102D08
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000B6531C: D5010006 20060D06
	v_mov_b32_dpp v22, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B65324: 7E2C02FA FF016407
	v_add_f32_e32 v5, v5, v9                                   // 000000B6532C: 060A1305
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000B65330: D5010007 20060F07
	v_mov_b32_dpp v9, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B65338: 7E1202FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000B65340: D5010008 20021108
	v_add_f32_e32 v6, v6, v23                                  // 000000B65348: 060C2F06
	v_mov_b32_dpp v23, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B6534C: 7E2E02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000B65354: D5010005 20020B05
	.long 0x7f303880                                           // 000000B6535C: 7F303880
	v_dual_add_f32 v8, v8, v9 :: v_dual_add_f32 v7, v7, v22    // 000000B65360: C9081308 08062D07
	v_mov_b32_dpp v9, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B65368: 7E1202FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000B65370: D5010006 20020D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B65378: BF870213
	v_dual_add_f32 v5, v5, v23 :: v_dual_mov_b32 v22, v8       // 000000B6537C: C9102F05 05160108
	v_mov_b32_dpp v23, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B65384: 7E2E02FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000B6538C: D5010007 20020F07
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000B65394: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v9                                   // 000000B6539C: 060C1306
	v_permlanex16_b32 v22, v22, s4, 0xfedcba98                 // 000000B653A0: D65C0016 03FC0916 FEDCBA98
	v_mov_b32_e32 v25, v5                                      // 000000B653AC: 7E320305
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000B653B0: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B653B8: BF870193
	v_dual_add_f32 v8, v8, v22 :: v_dual_add_f32 v7, v7, v23   // 000000B653BC: C9082D08 08062F07
	v_permlanex16_b32 v25, v25, s4, 0xfedcba98                 // 000000B653C4: D65C0019 03FC0919 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B653D0: BF870192
	v_dual_mul_f32 v8, 0x3db504f3, v8 :: v_dual_mov_b32 v9, v6 // 000000B653D4: C8D010FF 08080106 3DB504F3
	v_mov_b32_e32 v22, v7                                      // 000000B653E0: 7E2C0307
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000B653E4: D5010006 21AA0D06
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000B653EC: D5010007 21AA0F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B653F4: BF870214
	v_permlanex16_b32 v9, v9, s4, 0xfedcba98                   // 000000B653F8: D65C0009 03FC0909 FEDCBA98
	v_permlanex16_b32 v22, v22, s4, 0xfedcba98                 // 000000B65404: D65C0016 03FC0916 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000B65410: BF870131
	v_dual_add_f32 v6, v6, v9 :: v_dual_add_f32 v7, v7, v22    // 000000B65414: C9081306 06062D07
	v_add_f32_e32 v5, v5, v25                                  // 000000B6541C: 060A3305
	.long 0x7f123998                                           // 000000B65420: 7F123998
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000B65424: C8C60CFF 06040AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B65430: BF8903F7
	v_fma_mix_f32 v8, v21, v8, neg(0) op_sel_hi:[1,0,0]        // 000000B65434: CC200008 8A021115
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B6543C: BF870232
	v_fma_mix_f32 v5, v21, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B65440: CC200805 8A020B15
	.long 0x7f2a3998                                           // 000000B65448: 7F2A3998
	v_fma_mix_f32 v6, v20, v6, neg(0) op_sel_hi:[1,0,0]        // 000000B6544C: CC200006 8A020D14
	.long 0x7e123988                                           // 000000B65454: 7E123988
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B65458: BF8701A4
	.long 0x7e2a3985                                           // 000000B6545C: 7E2A3985
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 000000B65460: 100E0EFF 3DB504F3
	v_and_b32_e32 v9, 1, v9                                    // 000000B65468: 36121281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B6546C: BF870212
	v_fma_mix_f32 v7, v20, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B65470: CC200807 8A020F14
	v_and_b32_e32 v20, 1, v21                                  // 000000B65478: 36282A81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B6547C: BF870223
	v_add3_u32 v8, v8, v9, 0x7fff                              // 000000B65480: D6550008 03FE1308 00007FFF
	v_bfe_u32 v9, v6, 16, 1                                    // 000000B6548C: D6100009 02052106
	v_bfe_u32 v22, v7, 16, 1                                   // 000000B65494: D6100016 02052107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B6549C: BF870214
	v_add3_u32 v5, v5, v20, 0x7fff                             // 000000B654A0: D6550005 03FE2905 00007FFF
	.long 0x7e2a3988                                           // 000000B654AC: 7E2A3988
	s_delay_alu instid0(VALU_DEP_4)                            // 000000B654B0: BF870004
	v_add3_u32 v6, v6, v9, 0x7fff                              // 000000B654B4: D6550006 03FE1306 00007FFF
	v_add_nc_u32_e32 v8, s18, v58                              // 000000B654C0: 4A107412
	v_add3_u32 v7, v7, v22, 0x7fff                             // 000000B654C4: D6550007 03FE2D07 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v5                           // 000000B654D0: 36120AFF FFFF0000
	v_and_b32_e32 v20, 0xffff, v21                             // 000000B654D8: 36282AFF 0000FFFF
	.long 0x7e303986                                           // 000000B654E0: 7E303986
	v_mad_i64_i32 v[5:6], null, 0x1400, v8, v[1:2]             // 000000B654E4: D6FF7C05 040610FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B654F0: BF870193
	v_or_b32_e32 v8, v9, v20                                   // 000000B654F4: 38102909
	v_and_or_b32 v7, 0xffff0000, v7, v24                       // 000000B654F8: D6570007 04620EFF FFFF0000
	global_store_b64 v[5:6], v[7:8], off                       // 000000B65504: DC6E0000 007C0705
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B6550C: 8C7E057E
	v_or_b32_e32 v6, 8, v58                                    // 000000B65510: 380C7488
	s_mov_b32 s5, exec_lo                                      // 000000B65514: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B65518: BF870001
	v_mul_u32_u24_e32 v5, 0x210, v6                            // 000000B6551C: 160A0CFF 00000210
	.long 0xd4c4007e                                           // 000000B65524: D4C4007E
	v_cndmask_b32_e32 v1, s19, v6, vcc_lo                      // 000000B65528: 02020C13
	s_cbranch_execz 203                                        // 000000B6552C: BFA500CB <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x8f5c>
	global_load_b64 v[7:8], v3, s[12:13]                       // 000000B65530: DC560000 070C0003
	v_lshl_add_u32 v9, v18, 2, v5                              // 000000B65538: D6460009 04150512
	s_mov_b32 s4, 0x76543210                                   // 000000B65540: BE8400FF 76543210
	v_add_nc_u32_e32 v6, s18, v6                               // 000000B65548: 4A0C0C12
	ds_load_b128 v[20:23], v9                                  // 000000B6554C: DBFC0000 14000009
	s_waitcnt lgkmcnt(0)                                       // 000000B65554: BF89FC07
	v_dual_add_f32 v9, v20, v21 :: v_dual_add_f32 v24, v22, v23// 000000B65558: C9082B14 09182F16
	v_dual_sub_f32 v20, v20, v21 :: v_dual_sub_f32 v21, v22, v23// 000000B65560: C94A2B14 14142F16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B65568: BF8701A2
	v_add_f32_e32 v22, v9, v24                                 // 000000B6556C: 062C3109
	v_sub_f32_e32 v9, v9, v24                                  // 000000B65570: 08123109
	v_add_f32_e32 v23, v20, v21                                // 000000B65574: 062E2B14
	v_sub_f32_e32 v20, v20, v21                                // 000000B65578: 08282B14
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B6557C: BF870214
	v_mov_b32_dpp v21, v22 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B65580: 7E2A02FA FF016116
	v_mov_b32_dpp v24, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B65588: 7E3002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000B65590: D5010009 200E1309
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000B65598: BF870254
	v_mov_b32_dpp v26, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B6559C: 7E3402FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s3                       // 000000B655A4: D5010014 200E2914
	v_cndmask_b32_e64 v22, -v22, v22, s3                       // 000000B655AC: D5010016 200E2D16
	v_mov_b32_dpp v25, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B655B4: 7E3202FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s3                       // 000000B655BC: D5010017 200E2F17
	v_dual_add_f32 v9, v9, v24 :: v_dual_add_f32 v20, v20, v26 // 000000B655C4: C9083109 09143514
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B655CC: BF870224
	v_add_f32_e32 v21, v22, v21                                // 000000B655D0: 062A2B16
	.long 0x7f343880                                           // 000000B655D4: 7F343880
	v_add_f32_e32 v22, v23, v25                                // 000000B655D8: 062C3317
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000B655DC: BF8701C4
	v_mov_b32_dpp v23, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B655E0: 7E2E02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000B655E8: D5010009 200A1309
	v_mov_b32_dpp v25, v20 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B655F0: 7E3202FA FF016214
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000B655F8: D5010014 200A2914
	v_add_f32_e32 v9, v9, v23                                  // 000000B65600: 06122F09
	v_mov_b32_dpp v23, v22 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B65604: 7E2E02FA FF016216
	v_cndmask_b32_e64 v22, -v22, v22, s2                       // 000000B6560C: D5010016 200A2D16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B65614: BF870114
	v_add_f32_e32 v20, v20, v25                                // 000000B65618: 06283314
	v_add_f32_e32 v22, v22, v23                                // 000000B6561C: 062C2F16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B65620: BF8700A2
	v_mov_b32_dpp v23, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B65624: 7E2E02FA FF016414
	v_cndmask_b32_e64 v20, -v20, v20, s1                       // 000000B6562C: D5010014 20062914
	v_add_f32_e32 v20, v20, v23                                // 000000B65634: 06282F14
	v_mov_b32_dpp v24, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B65638: 7E3002FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000B65640: D5010015 200A2B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B65648: BF8701B1
	v_add_f32_e32 v21, v21, v24                                // 000000B6564C: 062A3115
	v_mov_b32_dpp v24, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B65650: 7E3002FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000B65658: D5010009 20061309
	v_mov_b32_dpp v25, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B65660: 7E3202FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000B65668: D5010015 20062B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B65670: BF870233
	v_add_f32_e32 v9, v9, v24                                  // 000000B65674: 06123109
	v_mov_b32_dpp v24, v22 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B65678: 7E3002FA FF016416
	v_cndmask_b32_e64 v22, -v22, v22, s1                       // 000000B65680: D5010016 20062D16
	v_add_f32_e32 v21, v21, v25                                // 000000B65688: 062A3315
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000B6568C: BF8701C4
	v_mov_b32_dpp v23, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B65690: 7E2E02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000B65698: D5010009 20021309
	v_mov_b32_dpp v25, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B656A0: 7E3202FA FF016814
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000B656A8: D5010014 20022914
	v_dual_add_f32 v22, v22, v24 :: v_dual_add_f32 v9, v9, v23 // 000000B656B0: C9083116 16082F09
	v_mov_b32_dpp v23, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B656B8: 7E2E02FA FF016815
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B656C0: BF870223
	v_add_f32_e32 v20, v20, v25                                // 000000B656C4: 06283314
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000B656C8: D5010015 20022B15
	v_mov_b32_dpp v25, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B656D0: 7E3202FA FF016816
	v_mov_b32_e32 v24, v9                                      // 000000B656D8: 7E300309
	v_cndmask_b32_e64 v22, -v22, v22, s0                       // 000000B656DC: D5010016 20022D16
	v_mov_b32_e32 v27, v20                                     // 000000B656E4: 7E360314
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000B656E8: D5010009 21AA1309
	v_add_f32_e32 v21, v21, v23                                // 000000B656F0: 062A2F15
	v_permlanex16_b32 v24, v24, s4, 0xfedcba98                 // 000000B656F4: D65C0018 03FC0918 FEDCBA98
	v_add_f32_e32 v22, v22, v25                                // 000000B65700: 062C3316
	v_cndmask_b32_e64 v20, -v20, v20, vcc_lo                   // 000000B65704: D5010014 21AA2914
	v_permlanex16_b32 v27, v27, s4, 0xfedcba98                 // 000000B6570C: D65C001B 03FC091B FEDCBA98
	v_mov_b32_e32 v23, v21                                     // 000000B65718: 7E2E0315
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B6571C: BF870224
	v_dual_add_f32 v9, v9, v24 :: v_dual_mov_b32 v24, v22      // 000000B65720: C9103109 09180116
	v_cndmask_b32_e64 v21, -v21, v21, vcc_lo                   // 000000B65728: D5010015 21AA2B15
	v_add_f32_e32 v20, v20, v27                                // 000000B65730: 06283714
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B65734: BF870214
	v_permlanex16_b32 v23, v23, s4, 0xfedcba98                 // 000000B65738: D65C0017 03FC0917 FEDCBA98
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000B65744: 101212FF 3DB504F3
	v_cndmask_b32_e64 v22, -v22, v22, vcc_lo                   // 000000B6574C: D5010016 21AA2D16
	v_permlanex16_b32 v24, v24, s4, 0xfedcba98                 // 000000B65754: D65C0018 03FC0918 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B65760: BF8701A4
	v_dual_mul_f32 v20, 0x3db504f3, v20 :: v_dual_add_f32 v21, v21, v23// 000000B65764: C8C828FF 14142F15 3DB504F3
	.long 0x7f2e399a                                           // 000000B65770: 7F2E399A
	v_add_f32_e32 v22, v22, v24                                // 000000B65774: 062C3116
	s_waitcnt vmcnt(0)                                         // 000000B65778: BF8903F7
	v_fma_mix_f32 v9, v8, v9, neg(0) op_sel_hi:[1,0,0]         // 000000B6577C: CC200009 8A021308
	v_fma_mix_f32 v8, v8, v20, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B65784: CC200808 8A022908
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B6578C: BF870232
	.long 0x7e2e3989                                           // 000000B65790: 7E2E3989
	v_mul_f32_e32 v20, 0x3db504f3, v21                         // 000000B65794: 10282AFF 3DB504F3
	.long 0x7f2a399a                                           // 000000B6579C: 7F2A399A
	.long 0x7e2a3988                                           // 000000B657A0: 7E2A3988
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B657A4: BF870214
	v_dual_mul_f32 v22, 0x3db504f3, v22 :: v_dual_and_b32 v23, 1, v23// 000000B657A8: C8E42CFF 16162E81 3DB504F3
	v_fma_mix_f32 v20, v7, v20, neg(0) op_sel_hi:[1,0,0]       // 000000B657B4: CC200014 8A022907
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B657BC: BF870193
	v_and_b32_e32 v21, 1, v21                                  // 000000B657C0: 362A2A81
	v_fma_mix_f32 v7, v7, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B657C4: CC200807 8A022D07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B657CC: BF870214
	v_add3_u32 v9, v9, v23, 0x7fff                             // 000000B657D0: D6550009 03FE2F09 00007FFF
	v_bfe_u32 v22, v20, 16, 1                                  // 000000B657DC: D6100016 02052114
	.long 0x7f2e399a                                           // 000000B657E4: 7F2E399A
	v_add3_u32 v8, v8, v21, 0x7fff                             // 000000B657E8: D6550008 03FE2B08 00007FFF
	v_bfe_u32 v24, v7, 16, 1                                   // 000000B657F4: D6100018 02052107
	.long 0x7e2e3989                                           // 000000B657FC: 7E2E3989
	v_add3_u32 v9, v20, v22, 0x7fff                            // 000000B65800: D6550009 03FE2D14 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B6580C: BF870214
	v_and_b32_e32 v8, 0xffff0000, v8                           // 000000B65810: 361010FF FFFF0000
	v_add3_u32 v20, v7, v24, 0x7fff                            // 000000B65818: D6550014 03FE3107 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B65824: BF870214
	v_and_b32_e32 v21, 0xffff, v23                             // 000000B65828: 362A2EFF 0000FFFF
	.long 0x7e343989                                           // 000000B65830: 7E343989
	v_mad_i64_i32 v[6:7], null, 0x1400, v6, v[1:2]             // 000000B65834: D6FF7C06 04060CFF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B65840: BF870193
	v_or_b32_e32 v9, v8, v21                                   // 000000B65844: 38122B08
	v_and_or_b32 v8, 0xffff0000, v20, v26                      // 000000B65848: D6570008 046A28FF FFFF0000
	global_store_b64 v[6:7], v[8:9], off                       // 000000B65854: DC6E0000 007C0806
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B6585C: 8C7E057E
	v_or_b32_e32 v6, 16, v58                                   // 000000B65860: 380C7490
	s_mov_b32 s5, exec_lo                                      // 000000B65864: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000B65868: BC7C0000
	s_barrier                                                  // 000000B6586C: BFBD0000
	buffer_gl0_inv                                             // 000000B65870: E0AC0000 00000000
	ds_store_2addr_b32 v19, v10, v11 offset1:2                 // 000000B65878: D8380200 000B0A13
	ds_store_2addr_b32 v19, v12, v13 offset0:4 offset1:6       // 000000B65880: D8380604 000D0C13
	ds_store_2addr_b32 v19, v14, v15 offset0:8 offset1:10      // 000000B65888: D8380A08 000F0E13
	ds_store_2addr_b32 v19, v16, v17 offset0:12 offset1:14     // 000000B65890: D8380E0C 00111013
	s_waitcnt lgkmcnt(0)                                       // 000000B65898: BF89FC07
	s_barrier                                                  // 000000B6589C: BFBD0000
	buffer_gl0_inv                                             // 000000B658A0: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000B658A8: D4C4007E
	v_cndmask_b32_e32 v1, s19, v6, vcc_lo                      // 000000B658AC: 02020C13
	s_cbranch_execz 201                                        // 000000B658B0: BFA500C9 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x92d8>
	global_load_b64 v[11:12], v3, s[12:13]                     // 000000B658B4: DC560000 0B0C0003
	v_lshl_add_u32 v4, v18, 2, v4                              // 000000B658BC: D6460004 04110512
	s_mov_b32 s4, 0x76543210                                   // 000000B658C4: BE8400FF 76543210
	v_add_nc_u32_e32 v6, s18, v6                               // 000000B658CC: 4A0C0C12
	ds_load_b128 v[7:10], v4                                   // 000000B658D0: DBFC0000 07000004
	s_waitcnt lgkmcnt(0)                                       // 000000B658D8: BF89FC07
	v_dual_add_f32 v4, v7, v8 :: v_dual_add_f32 v13, v9, v10   // 000000B658DC: C9081107 040C1509
	v_dual_sub_f32 v7, v7, v8 :: v_dual_sub_f32 v8, v9, v10    // 000000B658E4: C94A1107 07081509
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B658EC: BF8701A2
	v_add_f32_e32 v9, v4, v13                                  // 000000B658F0: 06121B04
	v_sub_f32_e32 v4, v4, v13                                  // 000000B658F4: 08081B04
	v_add_f32_e32 v10, v7, v8                                  // 000000B658F8: 06141107
	v_sub_f32_e32 v7, v7, v8                                   // 000000B658FC: 080E1107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B65900: BF870214
	v_mov_b32_dpp v8, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B65904: 7E1002FA FF016109
	v_mov_b32_dpp v13, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B6590C: 7E1A02FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000B65914: D5010004 200E0904
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000B6591C: D5010009 200E1309
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B65924: 7E1C02FA FF01610A
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B6592C: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000B65934: D5010007 200E0F07
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000B6593C: D501000A 200E150A
	v_add_f32_e32 v4, v4, v13                                  // 000000B65944: 06081B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B65948: BF870193
	v_dual_add_f32 v8, v9, v8 :: v_dual_add_f32 v7, v7, v15    // 000000B6594C: C9081109 08061F07
	v_add_f32_e32 v9, v10, v14                                 // 000000B65954: 06121D0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B65958: BF870223
	v_mov_b32_dpp v10, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B6595C: 7E1402FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000B65964: D5010004 200A0904
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B6596C: 7E1A02FA FF016208
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B65974: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000B6597C: D5010007 200A0F07
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000B65984: D5010008 200A1108
	v_add_f32_e32 v4, v4, v10                                  // 000000B6598C: 06081504
	v_mov_b32_dpp v10, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B65990: 7E1402FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000B65998: D5010009 200A1309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B659A0: BF870214
	v_dual_add_f32 v7, v7, v14 :: v_dual_add_f32 v8, v8, v13   // 000000B659A4: C9081D07 07081B08
	v_mov_b32_dpp v13, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B659AC: 7E1A02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000B659B4: D5010004 20060904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B659BC: BF870214
	v_add_f32_e32 v9, v9, v10                                  // 000000B659C0: 06121509
	v_mov_b32_dpp v10, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B659C4: 7E1402FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000B659CC: D5010007 20060F07
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B659D4: 7E1C02FA FF016408
	v_add_f32_e32 v4, v4, v13                                  // 000000B659DC: 06081B04
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B659E0: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000B659E8: D5010009 20061309
	v_add_f32_e32 v7, v7, v10                                  // 000000B659F0: 060E1507
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000B659F4: D5010008 20061108
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B659FC: 7E1402FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000B65A04: D5010004 20020904
	v_add_f32_e32 v9, v9, v13                                  // 000000B65A0C: 06121B09
	.long 0x7f1e3880                                           // 000000B65A10: 7F1E3880
	v_add_f32_e32 v8, v8, v14                                  // 000000B65A14: 06101D08
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B65A18: BF870094
	v_add_f32_e32 v4, v4, v10                                  // 000000B65A1C: 06081504
	v_mov_b32_e32 v13, v4                                      // 000000B65A20: 7E1A0304
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000B65A24: D5010004 21AA0904
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B65A2C: BF870092
	v_permlanex16_b32 v13, v13, s4, 0xfedcba98                 // 000000B65A30: D65C000D 03FC090D FEDCBA98
	v_add_f32_e32 v4, v4, v13                                  // 000000B65A3C: 06081B04
	v_mov_b32_dpp v14, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B65A40: 7E1C02FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000B65A48: D5010007 20020F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B65A50: BF8700B1
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_add_f32 v7, v7, v14// 000000B65A54: C8C808FF 04061D07 3DB504F3
	v_mov_b32_dpp v14, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B65A60: 7E1C02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000B65A68: D5010009 20021309
	v_add_f32_e32 v9, v9, v14                                  // 000000B65A70: 06121D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B65A74: BF870241
	v_mov_b32_e32 v13, v9                                      // 000000B65A78: 7E1A0309
	v_mov_b32_dpp v10, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B65A7C: 7E1402FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000B65A84: D5010008 20021108
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000B65A8C: D5010009 21AA1309
	v_permlanex16_b32 v13, v13, s4, 0xfedcba98                 // 000000B65A94: D65C000D 03FC090D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B65AA0: BF870091
	v_dual_add_f32 v8, v8, v10 :: v_dual_add_f32 v9, v9, v13   // 000000B65AA4: C9081508 08081B09
	v_mov_b32_e32 v10, v8                                      // 000000B65AAC: 7E140308
	v_mov_b32_e32 v16, v7                                      // 000000B65AB0: 7E200307
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000B65AB4: D5010007 21AA0F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B65ABC: BF870214
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000B65AC0: 101212FF 3DB504F3
	v_permlanex16_b32 v10, v10, s4, 0xfedcba98                 // 000000B65AC8: D65C000A 03FC090A FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B65AD4: BF870094
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000B65AD8: D65C0010 03FC0910 FEDCBA98
	v_add_f32_e32 v7, v7, v16                                  // 000000B65AE4: 060E2107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B65AE8: BF8700A1
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 000000B65AEC: 100E0EFF 3DB504F3
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000B65AF4: D5010008 21AA1108
	v_add_f32_e32 v8, v8, v10                                  // 000000B65AFC: 06101508
	.long 0x7f14398f                                           // 000000B65B00: 7F14398F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000B65B04: BF870002
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000B65B08: 101010FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B65B10: BF8903F7
	v_fma_mix_f32 v4, v12, v4, neg(0) op_sel_hi:[1,0,0]        // 000000B65B14: CC200004 8A02090C
	v_fma_mix_f32 v7, v12, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B65B1C: CC200807 8A020F0C
	.long 0x7f18398f                                           // 000000B65B24: 7F18398F
	v_fma_mix_f32 v8, v11, v8, neg(0) op_sel_hi:[1,0,0]        // 000000B65B28: CC200008 8A02110B
	v_fma_mix_f32 v9, v11, v9, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B65B30: CC200809 8A02130B
	.long 0x7e143984                                           // 000000B65B38: 7E143984
	.long 0x7e183987                                           // 000000B65B3C: 7E183987
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B65B40: BF870193
	v_bfe_u32 v13, v9, 16, 1                                   // 000000B65B44: D610000D 02052109
	v_and_b32_e32 v10, 1, v10                                  // 000000B65B4C: 36141481
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B65B50: BF870113
	v_and_b32_e32 v11, 1, v12                                  // 000000B65B54: 36161881
	v_add3_u32 v4, v4, v10, 0x7fff                             // 000000B65B58: D6550004 03FE1504 00007FFF
	v_bfe_u32 v10, v8, 16, 1                                   // 000000B65B64: D610000A 02052108
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B65B6C: BF870193
	v_add3_u32 v7, v7, v11, 0x7fff                             // 000000B65B70: D6550007 03FE1707 00007FFF
	.long 0x7e183984                                           // 000000B65B7C: 7E183984
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B65B80: BF870223
	v_add3_u32 v4, v8, v10, 0x7fff                             // 000000B65B84: D6550004 03FE1508 00007FFF
	v_add3_u32 v8, v9, v13, 0x7fff                             // 000000B65B90: D6550008 03FE1B09 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v7                           // 000000B65B9C: 36120EFF FFFF0000
	v_mad_i64_i32 v[6:7], null, 0x1400, v6, v[1:2]             // 000000B65BA4: D6FF7C06 04060CFF 00001400
	v_and_b32_e32 v10, 0xffff, v12                             // 000000B65BB0: 361418FF 0000FFFF
	.long 0x7e1e3984                                           // 000000B65BB8: 7E1E3984
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B65BBC: BF870112
	v_or_b32_e32 v9, v9, v10                                   // 000000B65BC0: 38121509
	v_and_or_b32 v8, 0xffff0000, v8, v15                       // 000000B65BC4: D6570008 043E10FF FFFF0000
	global_store_b64 v[6:7], v[8:9], off                       // 000000B65BD0: DC6E0000 007C0806
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B65BD8: 8C7E057E
	v_or_b32_e32 v4, 24, v58                                   // 000000B65BDC: 38087498
	s_mov_b32 s5, exec_lo                                      // 000000B65BE0: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B65BE4: BF870001
	.long 0xd4c4007e                                           // 000000B65BE8: D4C4007E
	v_cndmask_b32_e32 v1, s19, v4, vcc_lo                      // 000000B65BEC: 02020813
	s_cbranch_execz 200                                        // 000000B65BF0: BFA500C8 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x9614>
	global_load_b64 v[9:10], v3, s[12:13]                      // 000000B65BF4: DC560000 090C0003
	v_lshl_add_u32 v3, v18, 2, v5                              // 000000B65BFC: D6460003 04150512
	v_add_nc_u32_e32 v4, s18, v4                               // 000000B65C04: 4A080812
	ds_load_b128 v[5:8], v3                                    // 000000B65C08: DBFC0000 05000003
	v_mad_i64_i32 v[1:2], null, 0x1400, v4, v[1:2]             // 000000B65C10: D6FF7C01 040608FF 00001400
	s_waitcnt lgkmcnt(0)                                       // 000000B65C1C: BF89FC07
	v_add_f32_e32 v3, v5, v6                                   // 000000B65C20: 06060D05
	v_dual_sub_f32 v5, v5, v6 :: v_dual_sub_f32 v6, v7, v8     // 000000B65C24: C94A0D05 05061107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B65C2C: BF870091
	v_dual_add_f32 v11, v7, v8 :: v_dual_add_f32 v8, v5, v6    // 000000B65C30: C9081107 0B080D05
	v_add_f32_e32 v7, v3, v11                                  // 000000B65C38: 060E1703
	v_sub_f32_e32 v3, v3, v11                                  // 000000B65C3C: 08061703
	v_sub_f32_e32 v5, v5, v6                                   // 000000B65C40: 080A0D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B65C44: BF870214
	v_mov_b32_dpp v12, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B65C48: 7E1802FA FF016108
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B65C50: 7E0C02FA FF016107
	s_delay_alu instid0(VALU_DEP_4)                            // 000000B65C58: BF870004
	v_mov_b32_dpp v11, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B65C5C: 7E1602FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000B65C64: D5010003 200E0703
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000B65C6C: D5010007 200E0F07
	v_mov_b32_dpp v13, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B65C74: 7E1A02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000B65C7C: D5010005 200E0B05
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000B65C84: D5010008 200E1108
	v_add_f32_e32 v3, v3, v11                                  // 000000B65C8C: 06061703
	v_add_f32_e32 v6, v7, v6                                   // 000000B65C90: 060C0D07
	s_mov_b32 s3, 0x76543210                                   // 000000B65C94: BE8300FF 76543210
	v_add_f32_e32 v5, v5, v13                                  // 000000B65C9C: 060A1B05
	v_add_f32_e32 v7, v8, v12                                  // 000000B65CA0: 060E1908
	v_mov_b32_dpp v8, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B65CA4: 7E1002FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000B65CAC: D5010003 200A0703
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B65CB4: 7E1602FA FF016206
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B65CBC: 7E1802FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000B65CC4: D5010005 200A0B05
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000B65CCC: D5010006 200A0D06
	v_add_f32_e32 v3, v3, v8                                   // 000000B65CD4: 06061103
	v_mov_b32_dpp v8, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B65CD8: 7E1002FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000B65CE0: D5010007 200A0F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B65CE8: BF870214
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v6, v11   // 000000B65CEC: C9081905 05061706
	v_mov_b32_dpp v11, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B65CF4: 7E1602FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000B65CFC: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B65D04: BF870214
	v_add_f32_e32 v7, v7, v8                                   // 000000B65D08: 060E1107
	v_mov_b32_dpp v8, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B65D0C: 7E1002FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000B65D14: D5010005 20060B05
	v_mov_b32_dpp v12, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B65D1C: 7E1802FA FF016406
	v_add_f32_e32 v3, v3, v11                                  // 000000B65D24: 06061703
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000B65D28: D5010006 20060D06
	v_mov_b32_dpp v11, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B65D30: 7E1602FA FF016407
	v_add_f32_e32 v5, v5, v8                                   // 000000B65D38: 060A1105
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000B65D3C: D5010007 20060F07
	v_mov_b32_dpp v8, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B65D44: 7E1002FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000B65D4C: D5010003 20020703
	v_add_f32_e32 v6, v6, v12                                  // 000000B65D54: 060C1906
	.long 0x7f1a3880                                           // 000000B65D58: 7F1A3880
	v_mov_b32_dpp v12, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B65D5C: 7E1802FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000B65D64: D5010005 20020B05
	v_add_f32_e32 v3, v3, v8                                   // 000000B65D6C: 06061103
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B65D70: 7E1002FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000B65D78: D5010006 20020D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B65D80: BF870114
	v_add_f32_e32 v5, v5, v12                                  // 000000B65D84: 060A1905
	v_add_f32_e32 v6, v6, v8                                   // 000000B65D88: 060C1106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B65D8C: BF8701A2
	v_mov_b32_e32 v14, v5                                      // 000000B65D90: 7E1C0305
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000B65D94: D5010005 21AA0B05
	v_mov_b32_e32 v8, v6                                       // 000000B65D9C: 7E100306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000B65DA0: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B65DA8: BF870194
	v_permlanex16_b32 v14, v14, s3, 0xfedcba98                 // 000000B65DAC: D65C000E 03FC070E FEDCBA98
	v_permlanex16_b32 v8, v8, s3, 0xfedcba98                   // 000000B65DB8: D65C0008 03FC0708 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B65DC4: BF870001
	v_dual_add_f32 v5, v5, v14 :: v_dual_add_f32 v6, v6, v8    // 000000B65DC8: C9081D05 05061106
	.long 0x7f10398d                                           // 000000B65DD0: 7F10398D
	v_add_f32_e32 v7, v7, v11                                  // 000000B65DD4: 060E1707
	v_mov_b32_e32 v11, v3                                      // 000000B65DD8: 7E160303
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000B65DDC: D5010003 21AA0703
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v6, 0x3db504f3, v6// 000000B65DE4: C8C60AFF 05060CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B65DF0: BF870093
	v_permlanex16_b32 v11, v11, s3, 0xfedcba98                 // 000000B65DF4: D65C000B 03FC070B FEDCBA98
	v_add_f32_e32 v3, v3, v11                                  // 000000B65E00: 06061703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B65E04: BF8700A1
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 000000B65E08: 100606FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B65E10: BF8903F7
	v_fma_mix_f32 v3, v10, v3, neg(0) op_sel_hi:[1,0,0]        // 000000B65E14: CC200003 8A02070A
	v_fma_mix_f32 v5, v10, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B65E1C: CC200805 8A020B0A
	.long 0x7f14398d                                           // 000000B65E24: 7F14398D
	v_fma_mix_f32 v6, v9, v6, neg(0) op_sel_hi:[1,0,0]         // 000000B65E28: CC200006 8A020D09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B65E30: BF870214
	.long 0x7e103983                                           // 000000B65E34: 7E103983
	.long 0x7e143985                                           // 000000B65E38: 7E143985
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B65E3C: BF8701B2
	v_and_b32_e32 v8, 1, v8                                    // 000000B65E40: 36101081
	v_mov_b32_dpp v12, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B65E44: 7E1802FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000B65E4C: D5010007 20020F07
	v_add3_u32 v3, v3, v8, 0x7fff                              // 000000B65E54: D6550003 03FE1103 00007FFF
	v_bfe_u32 v8, v6, 16, 1                                    // 000000B65E60: D6100008 02052106
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B65E68: BF870093
	v_add_f32_e32 v7, v7, v12                                  // 000000B65E6C: 060E1907
	v_mov_b32_e32 v11, v7                                      // 000000B65E70: 7E160307
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000B65E74: D5010007 21AA0F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B65E7C: BF870092
	v_permlanex16_b32 v11, v11, s3, 0xfedcba98                 // 000000B65E80: D65C000B 03FC070B FEDCBA98
	v_add_f32_e32 v7, v7, v11                                  // 000000B65E8C: 060E1707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B65E90: BF870091
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 000000B65E94: 100E0EFF 3DB504F3
	v_fma_mix_f32 v7, v9, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B65E9C: CC200807 8A020F09
	v_and_b32_e32 v9, 1, v10                                   // 000000B65EA4: 36121481
	.long 0x7e143983                                           // 000000B65EA8: 7E143983
	v_add3_u32 v3, v6, v8, 0x7fff                              // 000000B65EAC: D6550003 03FE1106 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B65EB8: BF870214
	v_bfe_u32 v11, v7, 16, 1                                   // 000000B65EBC: D610000B 02052107
	v_add3_u32 v5, v5, v9, 0x7fff                              // 000000B65EC4: D6550005 03FE1305 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B65ED0: BF870193
	.long 0x7e1a3983                                           // 000000B65ED4: 7E1A3983
	v_add3_u32 v6, v7, v11, 0x7fff                             // 000000B65ED8: D6550006 03FE1707 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B65EE4: BF8701A3
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000B65EE8: 360A0AFF FFFF0000
	v_and_b32_e32 v7, 0xffff, v10                              // 000000B65EF0: 360E14FF 0000FFFF
	v_and_or_b32 v3, 0xffff0000, v6, v13                       // 000000B65EF8: D6570003 04360CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000B65F04: BF870002
	v_or_b32_e32 v4, v5, v7                                    // 000000B65F08: 38080F05
	global_store_b64 v[1:2], v[3:4], off                       // 000000B65F0C: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B65F14: 8C7E057E
	s_mov_b32 s0, 0                                            // 000000B65F18: BE800080
	s_mov_b32 s3, -1                                           // 000000B65F1C: BE8300C1
	s_waitcnt_vscnt null, 0x0                                  // 000000B65F20: BC7C0000
	s_barrier                                                  // 000000B65F24: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s0                              // 000000B65F28: 8B6A007E
	s_cbranch_vccz 2060                                        // 000000B65F2C: BFA3080C <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xb660>
	s_cmp_eq_u32 s20, 1                                        // 000000B65F30: BF068114
	s_cbranch_scc0 2058                                        // 000000B65F34: BFA1080A <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xb660>
	v_lshrrev_b32_e32 v7, 4, v0                                // 000000B65F38: 320E0084
	v_lshlrev_b32_e32 v1, 3, v0                                // 000000B65F3C: 30020083
	s_add_i32 s0, s19, -1                                      // 000000B65F40: 8100C113
	s_mov_b32 s1, exec_lo                                      // 000000B65F44: BE81007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B65F48: BF870112
	v_min_i32_e32 v2, s0, v7                                   // 000000B65F4C: 22040E00
	v_and_b32_e32 v38, 0x78, v1                                // 000000B65F50: 364C02FF 00000078
	v_mul_u32_u24_e32 v39, 0x88, v7                            // 000000B65F58: 164E0EFF 00000088
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B65F60: BF870193
	v_add_nc_u32_e32 v2, s18, v2                               // 000000B65F64: 4A040412
	v_lshlrev_b32_e32 v1, 1, v38                               // 000000B65F68: 30024C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B65F6C: BF870112
	v_mad_i64_i32 v[3:4], null, 0x500, v2, 0                   // 000000B65F70: D6FF7C03 020204FF 00000500
	.long 0xd7000002                                           // 000000B65F7C: D7000002
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 000000B65F80: 0202020A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B65F84: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s11, 0, s0                   // 000000B65F88: D5207C06 0001000B
	.long 0xd4490000                                           // 000000B65F90: D4490000
	v_cndmask_b32_e32 v1, 0xff, v0, vcc_lo                     // 000000B65F94: 020200FF 000000FF
	.long 0xd7006a05                                           // 000000B65F9C: D7006A05
	v_cndmask_b32_e32 v1, v2, v3, vcc_lo                       // 000000B65FA0: 02020702
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B65FA4: BF870001
	v_add_co_ci_u32_e64 v6, null, v6, v4, vcc_lo               // 000000B65FA8: D5207C06 01AA0906
	v_mov_b32_e32 v2, 0                                        // 000000B65FB0: 7E040280
	global_load_b128 v[10:13], v[5:6], off                     // 000000B65FB4: DC5E0000 0A7C0005
	v_cmpx_gt_u32_e32 0x100, v0                                // 000000B65FBC: 7D9800FF 00000100
	s_cbranch_execz 5                                          // 000000B65FC4: BFA50005 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x96dc>
	v_lshl_add_u32 v1, v39, 1, v1                              // 000000B65FC8: D6460001 04050327
	s_waitcnt vmcnt(0)                                         // 000000B65FD0: BF8903F7
	ds_store_b128 v1, v[10:13]                                 // 000000B65FD4: DB7C0000 00000A01
	s_or_b32 exec_lo, exec_lo, s1                              // 000000B65FDC: 8C7E017E
	v_and_b32_e32 v37, 31, v0                                  // 000000B65FE0: 364A009F
	v_dual_mov_b32 v7, v2 :: v_dual_and_b32 v40, 15, v0        // 000000B65FE4: CA240102 0728008F
	v_lshrrev_b32_e32 v36, 5, v0                               // 000000B65FEC: 32480085
	s_mul_i32 s3, s16, 0x96000                                 // 000000B65FF0: 9603FF10 00096000
	s_delay_alu instid0(VALU_DEP_3)                            // 000000B65FF8: BF870003
	v_lshl_or_b32 v6, v37, 3, 4                                // 000000B65FFC: D6560006 02110725
	v_mad_u32_u24 v5, v37, 24, 0x2f0                           // 000000B66004: D60B0005 03FD3125 000002F0
	v_cmp_ne_u32_e32 vcc_lo, 0, v37                            // 000000B66010: 7C9A4A80
	v_lshlrev_b32_e32 v15, 4, v40                              // 000000B66014: 301E5084
	s_mul_i32 s5, s17, 0x7800                                  // 000000B66018: 9605FF11 00007800
	v_mad_u32_u24 v1, v6, 3, 0x2f0                             // 000000B66020: D60B0001 03FD0706 000002F0
	v_lshrrev_b32_e32 v9, 5, v5                                // 000000B6602C: 32120A85
	s_mul_hi_i32 s2, s16, 0x96000                              // 000000B66030: 9702FF10 00096000
	s_mul_hi_i32 s12, s17, 0x7800                              // 000000B66038: 970CFF11 00007800
	s_add_u32 s3, s3, s5                                       // 000000B66040: 80030503
	v_lshrrev_b32_e32 v8, 5, v1                                // 000000B66044: 32100285
	v_subrev_nc_u32_e32 v16, 24, v9                            // 000000B66048: 4E201298
	v_and_b32_e32 v14, 0x7e0, v5                               // 000000B6604C: 361C0AFF 000007E0
	v_and_b32_e32 v17, 0x7e0, v1                               // 000000B66054: 362202FF 000007E0
	s_addc_u32 s2, s2, s12                                     // 000000B6605C: 82020C02
	.long 0xd7030005                                           // 000000B66060: D7030005
	v_cndmask_b32_e32 v0, v8, v129, vcc_lo                     // 000000B66064: 02010308
	v_cndmask_b32_e32 v1, 23, v16, vcc_lo                      // 000000B66068: 02022097
	v_subrev_nc_u32_e32 v8, 24, v8                             // 000000B6606C: 4E101098
	v_cmp_lt_u32_e32 vcc_lo, 5, v6                             // 000000B66070: 7C920C85
	v_mad_i32_i24 v14, 0xffffffe8, v37, v14                    // 000000B66074: D60A000E 043A4AFF FFFFFFE8
	.long 0xd7624005                                           // 000000B66080: D7624005
	v_cndmask_b32_e32 v1, 0xff, v5, vcc_lo                     // 000000B66084: 02020AFF 000000FF
	v_add_nc_u32_e32 v9, 0xe9, v9                              // 000000B6608C: 4A1212FF 000000E9
	v_mad_i32_i24 v16, v6, -3, v17                             // 000000B66094: D60A0010 04458706
	v_cndmask_b32_e32 v6, 23, v8, vcc_lo                       // 000000B6609C: 020C1097
	.long 0xd7006a03                                           // 000000B660A0: D7006A03
	v_cndmask_b32_e32 v1, v3, v15, vcc_lo                      // 000000B660A4: 02021F03
	.long 0xd7055005                                           // 000000B660A8: D7055005
	v_cndmask_b32_e32 v1, 0xab, v5, vcc_lo                     // 000000B660AC: 02020AFF 000000AB
	v_add_nc_u32_e32 v42, 0xfffffd3d, v14                      // 000000B660B4: 4A541CFF FFFFFD3D
	v_add_nc_u32_e32 v43, 0xfffffd3a, v14                      // 000000B660BC: 4A561CFF FFFFFD3A
	v_add_nc_u32_e32 v44, 0xfffffd37, v14                      // 000000B660C4: 4A581CFF FFFFFD37
	v_add_nc_u32_e32 v45, 0xfffffd34, v14                      // 000000B660CC: 4A5A1CFF FFFFFD34
	.long 0xd7395005                                           // 000000B660D4: D7395005
	v_cndmask_b32_e32 v1, 12, v5, vcc_lo                       // 000000B660D8: 02020A8C
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000B660DC: D5207C04 01AA0880
	v_mul_u32_u24_e32 v14, 0x60, v36                           // 000000B660E4: 161C48FF 00000060
	v_mul_hi_u32_u24_e32 v8, 0x60, v36                         // 000000B660EC: 181048FF 00000060
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B660F4: BF870244
	.long 0xd7054805                                           // 000000B660F8: D7054805
	v_cndmask_b32_e32 v0, v5, v152, vcc_lo                     // 000000B660FC: 02013105
	.long 0xd7006a03                                           // 000000B66100: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 000000B66104: 0202060A
	v_add_nc_u32_e32 v46, 0xfffffd3d, v16                      // 000000B66108: 4A5C20FF FFFFFD3D
	v_add_nc_u32_e32 v47, 0xfffffd3a, v16                      // 000000B66110: 4A5E20FF FFFFFD3A
	.long 0xd7041005                                           // 000000B66118: D7041005
	v_cndmask_b32_e32 v1, v5, v5, vcc_lo                       // 000000B6611C: 02020B05
	v_add_nc_u32_e32 v48, 0xfffffd37, v16                      // 000000B66120: 4A6020FF FFFFFD37
	v_add_nc_u32_e32 v49, 0xfffffd34, v16                      // 000000B66128: 4A6220FF FFFFFD34
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 000000B66130: D5207C04 01AA080B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000B66138: BF870244
	v_and_b32_e32 v5, 0xff, v5                                 // 000000B6613C: 360A0AFF 000000FF
	v_or_b32_e32 v16, s3, v14                                  // 000000B66144: 38201C03
	v_or_b32_e32 v8, s2, v8                                    // 000000B66148: 38101002
	.long 0xd7006a0e                                           // 000000B6614C: D7006A0E
	v_cndmask_b32_e32 v1, 0x100, v3, vcc_lo                    // 000000B66150: 020206FF 00000100
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000B66158: 300A0A82
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 000000B6615C: D5207C0F 01AA0880
	.long 0xd73c0003                                           // 000000B66164: D73C0003
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000B66168: 02020282
	v_and_b32_e32 v9, 0xff, v9                                 // 000000B6616C: 361212FF 000000FF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B66174: BF870094
	.long 0xd7006a05                                           // 000000B66178: D7006A05
	v_cndmask_b32_e32 v1, v16, v5, vcc_lo                      // 000000B6617C: 02020B10
	v_add_co_ci_u32_e64 v17, null, 0, v8, vcc_lo               // 000000B66180: D5207C11 01AA1080
	v_mul_u32_u24_e32 v41, 0x110, v40                          // 000000B66188: 165250FF 00000110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B66190: BF870093
	.long 0xd7006a01                                           // 000000B66194: D7006A01
	v_cndmask_b32_e32 v1, s8, v5, vcc_lo                       // 000000B66198: 02020A08
	v_add_co_ci_u32_e64 v50, null, s9, v17, vcc_lo             // 000000B6619C: D5207C32 01AA2209
	.long 0xd7006a03                                           // 000000B661A4: D7006A03
	v_cndmask_b32_e32 v1, v16, v3, vcc_lo                      // 000000B661A8: 02020710
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B661AC: BF8701A1
	v_add_co_ci_u32_e64 v4, null, v8, v4, vcc_lo               // 000000B661B0: D5207C04 01AA0908
	v_lshlrev_b32_e32 v5, 2, v9                                // 000000B661B8: 300A1282
	.long 0xd7006a33                                           // 000000B661BC: D7006A33
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000B661C0: 02020608
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B661C4: BF870221
	v_add_co_ci_u32_e64 v52, null, s9, v4, vcc_lo              // 000000B661C8: D5207C34 01AA0809
	.long 0xd73c0003                                           // 000000B661D0: D73C0003
	v_cndmask_b32_e32 v1, 2, v6, vcc_lo                        // 000000B661D4: 02020C82
	.long 0xd7006a05                                           // 000000B661D8: D7006A05
	v_cndmask_b32_e32 v1, v16, v5, vcc_lo                      // 000000B661DC: 02020B10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000B661E0: BF870221
	v_add_co_ci_u32_e64 v6, null, 0, v8, vcc_lo                // 000000B661E4: D5207C06 01AA1080
	v_mov_b32_e32 v9, v2                                       // 000000B661EC: 7E120302
	.long 0xd7006a03                                           // 000000B661F0: D7006A03
	v_cndmask_b32_e32 v1, v16, v3, vcc_lo                      // 000000B661F4: 02020710
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B661F8: BF8700A1
	v_add_co_ci_u32_e64 v4, null, v8, v4, vcc_lo               // 000000B661FC: D5207C04 01AA0908
	.long 0xd7006a35                                           // 000000B66204: D7006A35
	v_cndmask_b32_e32 v1, s8, v5, vcc_lo                       // 000000B66208: 02020A08
	v_add_co_ci_u32_e64 v54, null, s9, v6, vcc_lo              // 000000B6620C: D5207C36 01AA0C09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B66214: BF870094
	.long 0xd7006a37                                           // 000000B66218: D7006A37
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000B6621C: 02020608
	v_add_co_ci_u32_e64 v56, null, s9, v4, vcc_lo              // 000000B66220: D5207C38 01AA0809
	v_mov_b32_e32 v3, v2                                       // 000000B66228: 7E060302
	v_mov_b32_e32 v4, v2                                       // 000000B6622C: 7E080302
	.long 0xd44c0001                                           // 000000B66230: D44C0001
	v_cndmask_b32_e32 v1, 16, v37, vcc_lo                      // 000000B66234: 02024A90
	v_mov_b32_e32 v5, v2                                       // 000000B66238: 7E0A0302
	v_mov_b32_e32 v6, v2                                       // 000000B6623C: 7E0C0302
	v_mov_b32_e32 v8, v2                                       // 000000B66240: 7E100302
	s_mov_b32 s4, 0                                            // 000000B66244: BE840080
	s_mov_b64 s[2:3], 0                                        // 000000B66248: BE820180
	s_movk_i32 s5, 0x1eee                                      // 000000B6624C: B0051EEE
	s_mov_b32 s8, 0x76543210                                   // 000000B66250: BE8800FF 76543210
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000B66258: BF890007
	s_barrier                                                  // 000000B6625C: BFBD0000
	buffer_gl0_inv                                             // 000000B66260: E0AC0000 00000000
	s_branch 17                                                // 000000B66268: BFA00011 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x99b0>
	s_or_b32 exec_lo, exec_lo, s9                              // 000000B6626C: 8C7E097E
	.long 0xd7006a0e                                           // 000000B66270: D7006A0E
	v_cndmask_b32_e32 v1, 0x100, v14, vcc_lo                   // 000000B66274: 02021CFF 00000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B6627C: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 000000B66280: D5207C0F 01AA1E80
	s_add_u32 s2, s2, 0x1800                                   // 000000B66288: 8002FF02 00001800
	s_addc_u32 s3, s3, 0                                       // 000000B66290: 82038003
	s_add_i32 s4, s4, 1                                        // 000000B66294: 81048104
	s_cmpk_eq_i32 s2, 0x7800                                   // 000000B66298: B1827800
	s_waitcnt lgkmcnt(0)                                       // 000000B6629C: BF89FC07
	s_barrier                                                  // 000000B662A0: BFBD0000
	buffer_gl0_inv                                             // 000000B662A4: E0AC0000 00000000
	s_cbranch_scc1 1352                                        // 000000B662AC: BFA20548 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xaed0>
	s_cmpk_eq_i32 s2, 0x6000                                   // 000000B662B0: B1826000
	s_cselect_b32 s9, -1, 0                                    // 000000B662B4: 980980C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000B662B8: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 000000B662BC: 8B6A097E
	s_cbranch_vccnz 2                                          // 000000B662C0: BFA40002 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x99cc>
	global_load_b128 v[10:13], v[14:15], off                   // 000000B662C4: DC5E0000 0A7C000E
	.long 0xd7006a18                                           // 000000B662CC: D7006A18
	v_cndmask_b32_e32 v0, v51, v2, vcc_lo                      // 000000B662D0: 02000533
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B662D4: BF8700A1
	v_add_co_ci_u32_e64 v25, null, s3, v52, vcc_lo             // 000000B662D8: D5207C19 01AA6803
	.long 0xd7006a1a                                           // 000000B662E0: D7006A1A
	v_cndmask_b32_e32 v0, v53, v2, vcc_lo                      // 000000B662E4: 02000535
	v_add_co_ci_u32_e64 v27, null, s3, v54, vcc_lo             // 000000B662E8: D5207C1B 01AA6C03
	.long 0xd7006a1c                                           // 000000B662F0: D7006A1C
	v_cndmask_b32_e32 v0, v55, v2, vcc_lo                      // 000000B662F4: 02000537
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B662F8: BF8700A1
	v_add_co_ci_u32_e64 v29, null, s3, v56, vcc_lo             // 000000B662FC: D5207C1D 01AA7003
	.long 0xd7006a1e                                           // 000000B66304: D7006A1E
	v_cndmask_b32_e32 v0, v1, v2, vcc_lo                       // 000000B66308: 02000501
	v_add_co_ci_u32_e64 v31, null, s3, v50, vcc_lo             // 000000B6630C: D5207C1F 01AA6403
	s_clause 0x17                                              // 000000B66314: BF850017
	global_load_b32 v19, v[24:25], off                         // 000000B66318: DC520000 137C0018
	global_load_b32 v18, v[26:27], off                         // 000000B66320: DC520000 127C001A
	global_load_b32 v17, v[28:29], off                         // 000000B66328: DC520000 117C001C
	global_load_b32 v16, v[30:31], off                         // 000000B66330: DC520000 107C001E
	global_load_b32 v21, v[24:25], off offset:768              // 000000B66338: DC520300 157C0018
	global_load_b32 v20, v[26:27], off offset:768              // 000000B66340: DC520300 147C001A
	global_load_b32 v23, v[28:29], off offset:768              // 000000B66348: DC520300 177C001C
	global_load_b32 v22, v[30:31], off offset:768              // 000000B66350: DC520300 167C001E
	global_load_b32 v33, v[24:25], off offset:1536             // 000000B66358: DC520600 217C0018
	global_load_b32 v32, v[26:27], off offset:1536             // 000000B66360: DC520600 207C001A
	global_load_b32 v35, v[28:29], off offset:1536             // 000000B66368: DC520600 237C001C
	global_load_b32 v34, v[30:31], off offset:1536             // 000000B66370: DC520600 227C001E
	global_load_b32 v98, v[24:25], off offset:2304             // 000000B66378: DC520900 627C0018
	global_load_b32 v97, v[26:27], off offset:2304             // 000000B66380: DC520900 617C001A
	global_load_b32 v100, v[28:29], off offset:2304            // 000000B66388: DC520900 647C001C
	global_load_b32 v99, v[30:31], off offset:2304             // 000000B66390: DC520900 637C001E
	global_load_b32 v102, v[24:25], off offset:3072            // 000000B66398: DC520C00 667C0018
	global_load_b32 v101, v[26:27], off offset:3072            // 000000B663A0: DC520C00 657C001A
	global_load_b32 v104, v[28:29], off offset:3072            // 000000B663A8: DC520C00 687C001C
	global_load_b32 v103, v[30:31], off offset:3072            // 000000B663B0: DC520C00 677C001E
	global_load_b32 v106, v[24:25], off offset:3840            // 000000B663B8: DC520F00 6A7C0018
	global_load_b32 v105, v[26:27], off offset:3840            // 000000B663C0: DC520F00 697C001A
	global_load_b32 v107, v[30:31], off offset:3840            // 000000B663C8: DC520F00 6B7C001E
	global_load_b32 v108, v[28:29], off offset:3840            // 000000B663D0: DC520F00 6C7C001C
	.long 0xd7006a39                                           // 000000B663D8: D7006A39
	v_cndmask_b32_e32 v1, 0x1000, v24, vcc_lo                  // 000000B663DC: 020230FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B663E4: BF8700A1
	v_add_co_ci_u32_e64 v58, null, 0, v25, vcc_lo              // 000000B663E8: D5207C3A 01AA3280
	.long 0xd7006a3b                                           // 000000B663F0: D7006A3B
	v_cndmask_b32_e32 v1, 0x1000, v26, vcc_lo                  // 000000B663F4: 020234FF 00001000
	v_add_co_ci_u32_e64 v60, null, 0, v27, vcc_lo              // 000000B663FC: D5207C3C 01AA3680
	.long 0xd7006a1b                                           // 000000B66404: D7006A1B
	v_cndmask_b32_e32 v1, 0x1000, v28, vcc_lo                  // 000000B66408: 020238FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B66410: BF8700A1
	v_add_co_ci_u32_e64 v28, null, 0, v29, vcc_lo              // 000000B66414: D5207C1C 01AA3A80
	.long 0xd7006a1d                                           // 000000B6641C: D7006A1D
	v_cndmask_b32_e32 v1, 0x1000, v30, vcc_lo                  // 000000B66420: 02023CFF 00001000
	v_add_co_ci_u32_e64 v30, null, 0, v31, vcc_lo              // 000000B66428: D5207C1E 01AA3E80
	s_clause 0x7                                               // 000000B66430: BF850007
	global_load_b32 v114, v[57:58], off offset:512             // 000000B66434: DC520200 727C0039
	global_load_b32 v113, v[59:60], off offset:512             // 000000B6643C: DC520200 717C003B
	global_load_b32 v25, v[27:28], off offset:512              // 000000B66444: DC520200 197C001B
	global_load_b32 v24, v[29:30], off offset:512              // 000000B6644C: DC520200 187C001D
	global_load_b32 v115, v[29:30], off offset:1280            // 000000B66454: DC520500 737C001D
	global_load_b32 v116, v[27:28], off offset:1280            // 000000B6645C: DC520500 747C001B
	global_load_b32 v117, v[59:60], off offset:1280            // 000000B66464: DC520500 757C003B
	global_load_b32 v118, v[57:58], off offset:1280            // 000000B6646C: DC520500 767C0039
	s_and_b32 s10, s4, 1                                       // 000000B66474: 8B0A8104
	s_bfe_i32 s11, s4, 0x10000                                 // 000000B66478: 938BFF04 00010000
	s_cmp_eq_u32 s10, 0                                        // 000000B66480: BF06800A
	s_cselect_b32 s10, -1, 0                                   // 000000B66484: 980A80C1
	s_and_b32 s11, s11, 0x4400                                 // 000000B66488: 8B0BFF0B 00004400
	s_waitcnt vmcnt(30)                                        // 000000B66490: BF897BF7
	.long 0xd73d001b                                           // 000000B66494: D73D001B
	v_cndmask_b32_e32 v1, v42, v18, vcc_lo                     // 000000B66498: 0202252A
	.long 0xd73d001c                                           // 000000B6649C: D73D001C
	v_cndmask_b32_e32 v1, v43, v18, vcc_lo                     // 000000B664A0: 0202252B
	s_waitcnt vmcnt(28)                                        // 000000B664A4: BF8973F7
	.long 0xd73d006d                                           // 000000B664A8: D73D006D
	v_cndmask_b32_e32 v1, v47, v16, vcc_lo                     // 000000B664AC: 0202212F
	.long 0xd73d001d                                           // 000000B664B0: D73D001D
	v_cndmask_b32_e32 v1, v44, v18, vcc_lo                     // 000000B664B4: 0202252C
	s_waitcnt vmcnt(26)                                        // 000000B664B8: BF896BF7
	.long 0xd73d0077                                           // 000000B664BC: D73D0077
	v_cndmask_b32_e32 v1, v43, v20, vcc_lo                     // 000000B664C0: 0202292B
	.long 0xd73d0078                                           // 000000B664C4: D73D0078
	v_cndmask_b32_e32 v1, v44, v20, vcc_lo                     // 000000B664C8: 0202292C
	s_waitcnt vmcnt(24)                                        // 000000B664CC: BF8963F7
	.long 0xd73d0079                                           // 000000B664D0: D73D0079
	v_cndmask_b32_e32 v1, v47, v22, vcc_lo                     // 000000B664D4: 02022D2F
	.long 0xd73d007a                                           // 000000B664D8: D73D007A
	v_cndmask_b32_e32 v1, v48, v22, vcc_lo                     // 000000B664DC: 02022D30
	s_waitcnt vmcnt(22)                                        // 000000B664E0: BF895BF7
	.long 0xd73d007b                                           // 000000B664E4: D73D007B
	v_cndmask_b32_e32 v1, v43, v32, vcc_lo                     // 000000B664E8: 0202412B
	.long 0xd73d0012                                           // 000000B664EC: D73D0012
	v_cndmask_b32_e32 v1, v45, v18, vcc_lo                     // 000000B664F0: 0202252D
	.long 0xd73d006e                                           // 000000B664F4: D73D006E
	v_cndmask_b32_e32 v1, v48, v16, vcc_lo                     // 000000B664F8: 02022130
	.long 0xd73d007c                                           // 000000B664FC: D73D007C
	v_cndmask_b32_e32 v1, v44, v32, vcc_lo                     // 000000B66500: 0202412C
	.long 0xd73d006f                                           // 000000B66504: D73D006F
	v_cndmask_b32_e32 v1, v42, v20, vcc_lo                     // 000000B66508: 0202292A
	.long 0xd73d0013                                           // 000000B6650C: D73D0013
	v_cndmask_b32_e32 v1, v45, v20, vcc_lo                     // 000000B66510: 0202292D
	s_waitcnt vmcnt(20)                                        // 000000B66514: BF8953F7
	.long 0xd73d007d                                           // 000000B66518: D73D007D
	v_cndmask_b32_e32 v1, v47, v34, vcc_lo                     // 000000B6651C: 0202452F
	.long 0xd73d0014                                           // 000000B66520: D73D0014
	v_cndmask_b32_e32 v1, v46, v22, vcc_lo                     // 000000B66524: 02022D2E
	.long 0xd73d007e                                           // 000000B66528: D73D007E
	v_cndmask_b32_e32 v1, v48, v34, vcc_lo                     // 000000B6652C: 02024530
	.long 0xd73d001e                                           // 000000B66530: D73D001E
	v_cndmask_b32_e32 v1, v46, v16, vcc_lo                     // 000000B66534: 0202212E
	.long 0xd73d0015                                           // 000000B66538: D73D0015
	v_cndmask_b32_e32 v1, v49, v22, vcc_lo                     // 000000B6653C: 02022D31
	s_waitcnt vmcnt(18)                                        // 000000B66540: BF894BF7
	.long 0xd73d007f                                           // 000000B66544: D73D007F
	v_cndmask_b32_e32 v1, v43, v97, vcc_lo                     // 000000B66548: 0202C32B
	.long 0xd73d0016                                           // 000000B6654C: D73D0016
	v_cndmask_b32_e32 v1, v42, v32, vcc_lo                     // 000000B66550: 0202412A
	.long 0xd73d001f                                           // 000000B66554: D73D001F
	v_cndmask_b32_e32 v1, v45, v32, vcc_lo                     // 000000B66558: 0202412D
	.long 0xd73d0080                                           // 000000B6655C: D73D0080
	v_cndmask_b32_e32 v1, v44, v97, vcc_lo                     // 000000B66560: 0202C32C
	.long 0xd73d0020                                           // 000000B66564: D73D0020
	v_cndmask_b32_e32 v1, v46, v34, vcc_lo                     // 000000B66568: 0202452E
	s_waitcnt vmcnt(16)                                        // 000000B6656C: BF8943F7
	.long 0xd73d0081                                           // 000000B66570: D73D0081
	v_cndmask_b32_e32 v1, v46, v99, vcc_lo                     // 000000B66574: 0202C72E
	.long 0xd73d0021                                           // 000000B66578: D73D0021
	v_cndmask_b32_e32 v1, v49, v34, vcc_lo                     // 000000B6657C: 02024531
	.long 0xd73d0082                                           // 000000B66580: D73D0082
	v_cndmask_b32_e32 v1, v47, v99, vcc_lo                     // 000000B66584: 0202C72F
	.long 0xd73d0022                                           // 000000B66588: D73D0022
	v_cndmask_b32_e32 v1, v42, v97, vcc_lo                     // 000000B6658C: 0202C32A
	.long 0xd73d0061                                           // 000000B66590: D73D0061
	v_cndmask_b32_e32 v1, v45, v97, vcc_lo                     // 000000B66594: 0202C32D
	.long 0xd73d0083                                           // 000000B66598: D73D0083
	v_cndmask_b32_e32 v1, v48, v99, vcc_lo                     // 000000B6659C: 0202C730
	.long 0xd73d0062                                           // 000000B665A0: D73D0062
	v_cndmask_b32_e32 v1, v49, v99, vcc_lo                     // 000000B665A4: 0202C731
	s_waitcnt vmcnt(14)                                        // 000000B665A8: BF893BF7
	.long 0xd73d0084                                           // 000000B665AC: D73D0084
	v_cndmask_b32_e32 v1, v43, v101, vcc_lo                    // 000000B665B0: 0202CB2B
	.long 0xd73d0063                                           // 000000B665B4: D73D0063
	v_cndmask_b32_e32 v1, v42, v101, vcc_lo                    // 000000B665B8: 0202CB2A
	.long 0xd73d0085                                           // 000000B665BC: D73D0085
	v_cndmask_b32_e32 v1, v44, v101, vcc_lo                    // 000000B665C0: 0202CB2C
	.long 0xd73d0064                                           // 000000B665C4: D73D0064
	v_cndmask_b32_e32 v1, v45, v101, vcc_lo                    // 000000B665C8: 0202CB2D
	s_waitcnt vmcnt(12)                                        // 000000B665CC: BF8933F7
	.long 0xd73d0086                                           // 000000B665D0: D73D0086
	v_cndmask_b32_e32 v1, v47, v103, vcc_lo                    // 000000B665D4: 0202CF2F
	.long 0xd73d0065                                           // 000000B665D8: D73D0065
	v_cndmask_b32_e32 v1, v46, v103, vcc_lo                    // 000000B665DC: 0202CF2E
	.long 0xd73d0087                                           // 000000B665E0: D73D0087
	v_cndmask_b32_e32 v1, v48, v103, vcc_lo                    // 000000B665E4: 0202CF30
	.long 0xd73d0066                                           // 000000B665E8: D73D0066
	v_cndmask_b32_e32 v1, v49, v103, vcc_lo                    // 000000B665EC: 0202CF31
	s_waitcnt vmcnt(10)                                        // 000000B665F0: BF892BF7
	.long 0xd73d0088                                           // 000000B665F4: D73D0088
	v_cndmask_b32_e32 v1, v43, v105, vcc_lo                    // 000000B665F8: 0202D32B
	.long 0xd73d0067                                           // 000000B665FC: D73D0067
	v_cndmask_b32_e32 v1, v42, v105, vcc_lo                    // 000000B66600: 0202D32A
	.long 0xd73d0089                                           // 000000B66604: D73D0089
	v_cndmask_b32_e32 v1, v44, v105, vcc_lo                    // 000000B66608: 0202D32C
	.long 0xd73d0068                                           // 000000B6660C: D73D0068
	v_cndmask_b32_e32 v1, v45, v105, vcc_lo                    // 000000B66610: 0202D32D
	s_waitcnt vmcnt(8)                                         // 000000B66614: BF8923F7
	.long 0xd73d008a                                           // 000000B66618: D73D008A
	v_cndmask_b32_e32 v1, v47, v107, vcc_lo                    // 000000B6661C: 0202D72F
	.long 0xd73d0010                                           // 000000B66620: D73D0010
	v_cndmask_b32_e32 v1, v49, v16, vcc_lo                     // 000000B66624: 02022131
	.long 0xd73d0069                                           // 000000B66628: D73D0069
	v_cndmask_b32_e32 v1, v46, v107, vcc_lo                    // 000000B6662C: 0202D72E
	.long 0xd73d008b                                           // 000000B66630: D73D008B
	v_cndmask_b32_e32 v1, v48, v107, vcc_lo                    // 000000B66634: 0202D730
	.long 0xd73d008c                                           // 000000B66638: D73D008C
	v_cndmask_b32_e32 v1, v49, v107, vcc_lo                    // 000000B6663C: 0202D731
	v_and_b32_e32 v17, 0xffff, v27                             // 000000B66640: 362236FF 0000FFFF
	v_and_b32_e32 v23, 0xffff, v28                             // 000000B66648: 362E38FF 0000FFFF
	v_and_b32_e32 v27, 0xffff, v29                             // 000000B66650: 36363AFF 0000FFFF
	v_and_b32_e32 v28, 0xffff, v30                             // 000000B66658: 36383CFF 0000FFFF
	v_and_b32_e32 v29, 0xffff, v109                            // 000000B66660: 363ADAFF 0000FFFF
	v_and_b32_e32 v30, 0xffff, v110                            // 000000B66668: 363CDCFF 0000FFFF
	v_and_b32_e32 v35, 0xffff, v111                            // 000000B66670: 3646DEFF 0000FFFF
	v_and_b32_e32 v106, 0xffff, v119                           // 000000B66678: 36D4EEFF 0000FFFF
	v_and_b32_e32 v107, 0xffff, v120                           // 000000B66680: 36D6F0FF 0000FFFF
	v_and_b32_e32 v108, 0xffff, v121                           // 000000B66688: 36D8F2FF 0000FFFF
	v_and_b32_e32 v109, 0xffff, v122                           // 000000B66690: 36DAF4FF 0000FFFF
	v_and_b32_e32 v110, 0xffff, v123                           // 000000B66698: 36DCF6FF 0000FFFF
	v_and_b32_e32 v111, 0xffff, v124                           // 000000B666A0: 36DEF8FF 0000FFFF
	v_and_b32_e32 v112, 0xffff, v125                           // 000000B666A8: 36E0FAFF 0000FFFF
	v_and_b32_e32 v119, 0xffff, v126                           // 000000B666B0: 36EEFCFF 0000FFFF
	v_and_b32_e32 v34, 0xffff, v34                             // 000000B666B8: 364444FF 0000FFFF
	v_and_b32_e32 v120, 0xffff, v127                           // 000000B666C0: 36F0FEFF 0000FFFF
	v_and_b32_e32 v121, 0xffff, v128                           // 000000B666C8: 36F300FF 0000FFFF
	v_and_b32_e32 v122, 0xffff, v129                           // 000000B666D0: 36F502FF 0000FFFF
	v_and_b32_e32 v123, 0xffff, v130                           // 000000B666D8: 36F704FF 0000FFFF
	v_and_b32_e32 v124, 0xffff, v131                           // 000000B666E0: 36F906FF 0000FFFF
	v_and_b32_e32 v31, 0xffff, v31                             // 000000B666E8: 363E3EFF 0000FFFF
	v_and_b32_e32 v32, 0xffff, v32                             // 000000B666F0: 364040FF 0000FFFF
	v_and_b32_e32 v98, 0xffff, v98                             // 000000B666F8: 36C4C4FF 0000FFFF
	v_and_b32_e32 v125, 0xffff, v132                           // 000000B66700: 36FB08FF 0000FFFF
	v_and_b32_e32 v131, 0xffff, v104                           // 000000B66708: 3706D0FF 0000FFFF
	v_and_b32_e32 v132, 0xffff, v105                           // 000000B66710: 3708D2FF 0000FFFF
	.long 0xd72c0011                                           // 000000B66718: D72C0011
	v_cndmask_b32_e32 v1, 0x83dcd12d, v17, vcc_lo              // 000000B6671C: 020222FF 83DCD12D
	.long 0xd72c001c                                           // 000000B66724: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 000000B66728: 020238FF 83DCD12D
	.long 0xd72c0068                                           // 000000B66730: D72C0068
	v_cndmask_b32_e32 v1, 0x83dcd12d, v106, vcc_lo             // 000000B66734: 0202D4FF 83DCD12D
	.long 0xd72c0069                                           // 000000B6673C: D72C0069
	v_cndmask_b32_e32 v1, 0x83dcd12d, v107, vcc_lo             // 000000B66740: 0202D6FF 83DCD12D
	.long 0xd72c006a                                           // 000000B66748: D72C006A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v108, vcc_lo             // 000000B6674C: 0202D8FF 83DCD12D
	.long 0xd72c006b                                           // 000000B66754: D72C006B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v109, vcc_lo             // 000000B66758: 0202DAFF 83DCD12D
	.long 0xd72c006c                                           // 000000B66760: D72C006C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v110, vcc_lo             // 000000B66764: 0202DCFF 83DCD12D
	.long 0xd72c006d                                           // 000000B6676C: D72C006D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 000000B66770: 0202DEFF 83DCD12D
	.long 0xd72c006e                                           // 000000B66778: D72C006E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v112, vcc_lo             // 000000B6677C: 0202E0FF 83DCD12D
	.long 0xd72c006f                                           // 000000B66784: D72C006F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000B66788: 0202EEFF 83DCD12D
	.long 0xd72c0022                                           // 000000B66790: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000B66794: 020244FF 83DCD12D
	.long 0xd72c0070                                           // 000000B6679C: D72C0070
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000B667A0: 0202F0FF 83DCD12D
	.long 0xd72c0077                                           // 000000B667A8: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000B667AC: 0202F2FF 83DCD12D
	.long 0xd72c0078                                           // 000000B667B4: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 000000B667B8: 0202F4FF 83DCD12D
	.long 0xd72c0079                                           // 000000B667C0: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000B667C4: 0202F6FF 83DCD12D
	.long 0xd72c007a                                           // 000000B667CC: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 000000B667D0: 0202F8FF 83DCD12D
	v_and_b32_e32 v127, 0xffff, v134                           // 000000B667D8: 36FF0CFF 0000FFFF
	v_and_b32_e32 v103, 0xffff, v103                           // 000000B667E0: 36CECEFF 0000FFFF
	v_and_b32_e32 v97, 0xffff, v97                             // 000000B667E8: 36C2C2FF 0000FFFF
	.long 0xd72c0017                                           // 000000B667F0: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 000000B667F4: 02022EFF 83DCD12D
	.long 0xd72c001d                                           // 000000B667FC: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 000000B66800: 02023AFF 83DCD12D
	.long 0xd72c001f                                           // 000000B66808: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000B6680C: 02023EFF 83DCD12D
	.long 0xd72c0020                                           // 000000B66814: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 000000B66818: 020240FF 83DCD12D
	.long 0xd72c0062                                           // 000000B66820: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000B66824: 0202C4FF 83DCD12D
	.long 0xd72c007b                                           // 000000B6682C: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000B66830: 0202FAFF 83DCD12D
	.long 0xd72c007d                                           // 000000B66838: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 000000B6683C: 0202FEFF 83DCD12D
	.long 0xd72c007f                                           // 000000B66844: D72C007F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v103, vcc_lo             // 000000B66848: 0202CEFF 83DCD12D
	v_sad_u8 v17, v17, 0, 0x6400                               // 000000B66850: D6220011 03FD0111 00006400
	v_sad_u8 v28, v28, 0, 0x6400                               // 000000B6685C: D622001C 03FD011C 00006400
	v_sad_u8 v103, v104, 0, 0x6400                             // 000000B66868: D6220067 03FD0168 00006400
	v_sad_u8 v104, v105, 0, 0x6400                             // 000000B66874: D6220068 03FD0169 00006400
	v_sad_u8 v105, v106, 0, 0x6400                             // 000000B66880: D6220069 03FD016A 00006400
	v_sad_u8 v106, v107, 0, 0x6400                             // 000000B6688C: D622006A 03FD016B 00006400
	v_sad_u8 v107, v108, 0, 0x6400                             // 000000B66898: D622006B 03FD016C 00006400
	v_sad_u8 v108, v109, 0, 0x6400                             // 000000B668A4: D622006C 03FD016D 00006400
	v_sad_u8 v109, v110, 0, 0x6400                             // 000000B668B0: D622006D 03FD016E 00006400
	v_sad_u8 v110, v111, 0, 0x6400                             // 000000B668BC: D622006E 03FD016F 00006400
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000B668C8: D6220022 03FD0122 00006400
	v_sad_u8 v111, v112, 0, 0x6400                             // 000000B668D4: D622006F 03FD0170 00006400
	v_sad_u8 v112, v119, 0, 0x6400                             // 000000B668E0: D6220070 03FD0177 00006400
	v_sad_u8 v119, v120, 0, 0x6400                             // 000000B668EC: D6220077 03FD0178 00006400
	v_sad_u8 v120, v121, 0, 0x6400                             // 000000B668F8: D6220078 03FD0179 00006400
	v_sad_u8 v121, v122, 0, 0x6400                             // 000000B66904: D6220079 03FD017A 00006400
	.long 0xd72c0061                                           // 000000B66910: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000B66914: 0202C2FF 83DCD12D
	v_sad_u8 v23, v23, 0, 0x6400                               // 000000B6691C: D6220017 03FD0117 00006400
	v_sad_u8 v29, v29, 0, 0x6400                               // 000000B66928: D622001D 03FD011D 00006400
	v_sad_u8 v31, v31, 0, 0x6400                               // 000000B66934: D622001F 03FD011F 00006400
	v_sad_u8 v32, v32, 0, 0x6400                               // 000000B66940: D6220020 03FD0120 00006400
	v_sad_u8 v98, v98, 0, 0x6400                               // 000000B6694C: D6220062 03FD0162 00006400
	v_and_b32_e32 v17, 0xffff, v17                             // 000000B66958: 362222FF 0000FFFF
	v_and_b32_e32 v28, 0xffff, v28                             // 000000B66960: 363838FF 0000FFFF
	v_and_b32_e32 v108, 0xffff, v108                           // 000000B66968: 36D8D8FF 0000FFFF
	v_and_b32_e32 v34, 0xffff, v34                             // 000000B66970: 364444FF 0000FFFF
	v_and_b32_e32 v121, 0xffff, v121                           // 000000B66978: 36F2F2FF 0000FFFF
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000B66980: D6220061 03FD0161 00006400
	v_and_b32_e32 v32, 0xffff, v32                             // 000000B6698C: 364040FF 0000FFFF
	v_and_b32_e32 v112, 0xffff, v112                           // 000000B66994: 36E0E0FF 0000FFFF
	v_lshl_or_b32 v17, v23, 16, v17                            // 000000B6699C: D6560011 04452117
	v_lshl_or_b32 v23, v29, 16, v28                            // 000000B669A4: D6560017 0471211D
	v_lshl_or_b32 v28, v31, 16, v108                           // 000000B669AC: D656001C 05B1211F
	v_lshl_or_b32 v31, v111, 16, v34                           // 000000B669B4: D656001F 0489216F
	v_lshl_or_b32 v34, v98, 16, v121                           // 000000B669BC: D6560022 05E52162
	v_and_b32_e32 v126, 0xffff, v133                           // 000000B669C4: 36FD0AFF 0000FFFF
	v_and_b32_e32 v128, 0xffff, v135                           // 000000B669CC: 37010EFF 0000FFFF
	v_lshl_or_b32 v29, v109, 16, v32                           // 000000B669D4: D656001D 0481216D
	v_lshl_or_b32 v32, v97, 16, v112                           // 000000B669DC: D6560020 05C12161
	v_pk_fma_f16 v112, v34, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000B669E4: CC0E0070 0BFC0B22 0000C931
	v_and_b32_e32 v21, 0xffff, v21                             // 000000B669F0: 362A2AFF 0000FFFF
	.long 0xd72c007c                                           // 000000B669F8: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000B669FC: 0202FCFF 83DCD12D
	.long 0xd72c007e                                           // 000000B66A04: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v128, vcc_lo             // 000000B66A08: 020300FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B66A10: BF870214
	v_dual_mov_b32 v128, v112 :: v_dual_and_b32 v101, 0xffff, v101// 000000B66A14: CA240170 8064CAFF 0000FFFF
	.long 0xd72c0015                                           // 000000B66A20: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 000000B66A24: 02022AFF 83DCD12D
	v_and_b32_e32 v106, 0xffff, v106                           // 000000B66A2C: 36D4D4FF 0000FFFF
	v_and_b32_e32 v33, 0xffff, v33                             // 000000B66A34: 364242FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000B66A3C: BF870004
	.long 0xd72c0065                                           // 000000B66A40: D72C0065
	v_cndmask_b32_e32 v1, 0x83dcd12d, v101, vcc_lo             // 000000B66A44: 0202CAFF 83DCD12D
	.long 0xd72c001e                                           // 000000B66A4C: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 000000B66A50: 02023CFF 83DCD12D
	v_sad_u8 v122, v123, 0, 0x6400                             // 000000B66A58: D622007A 03FD017B 00006400
	v_sad_u8 v123, v124, 0, 0x6400                             // 000000B66A64: D622007B 03FD017C 00006400
	.long 0xd72c0021                                           // 000000B66A70: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000B66A74: 020242FF 83DCD12D
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000B66A7C: D6220015 03FD0115 00006400
	v_sad_u8 v124, v125, 0, 0x6400                             // 000000B66A88: D622007C 03FD017D 00006400
	v_and_b32_e32 v110, 0xffff, v110                           // 000000B66A94: 36DCDCFF 0000FFFF
	v_sad_u8 v101, v101, 0, 0x6400                             // 000000B66A9C: D6220065 03FD0165 00006400
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000B66AA8: D622001E 03FD011E 00006400
	v_lshl_or_b32 v21, v21, 16, v106                           // 000000B66AB4: D6560015 05A92115
	v_pk_fma_f16 v106, v28, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000B66ABC: CC0E006A 0BFC0B1C 0000C931
	v_and_b32_e32 v16, 0xffff, v16                             // 000000B66AC8: 362020FF 0000FFFF
	v_and_b32_e32 v101, 0xffff, v101                           // 000000B66AD0: 36CACAFF 0000FFFF
	v_sad_u8 v33, v33, 0, 0x6400                               // 000000B66AD8: D6220021 03FD0121 00006400
	v_and_b32_e32 v30, 0xffff, v30                             // 000000B66AE4: 363C3CFF 0000FFFF
	v_and_b32_e32 v119, 0xffff, v119                           // 000000B66AEC: 36EEEEFF 0000FFFF
	.long 0xd72c0010                                           // 000000B66AF4: D72C0010
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 000000B66AF8: 020220FF 83DCD12D
	v_lshl_or_b32 v98, v124, 16, v101                          // 000000B66B00: D6560062 0595217C
	v_and_b32_e32 v100, 0xffff, v100                           // 000000B66B08: 36C8C8FF 0000FFFF
	v_and_b32_e32 v99, 0xffff, v99                             // 000000B66B10: 36C6C6FF 0000FFFF
	v_and_b32_e32 v123, 0xffff, v123                           // 000000B66B18: 36F6F6FF 0000FFFF
	.long 0xd72c001b                                           // 000000B66B20: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 000000B66B24: 020236FF 83DCD12D
	v_and_b32_e32 v102, 0xffff, v102                           // 000000B66B2C: 36CCCCFF 0000FFFF
	.long 0xd72c0064                                           // 000000B66B34: D72C0064
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 000000B66B38: 0202C8FF 83DCD12D
	v_sad_u8 v16, v16, 0, 0x6400                               // 000000B66B40: D6220010 03FD0110 00006400
	.long 0xd72c0063                                           // 000000B66B4C: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000B66B50: 0202C6FF 83DCD12D
	v_sad_u8 v125, v126, 0, 0x6400                             // 000000B66B58: D622007D 03FD017E 00006400
	.long 0xd72c0066                                           // 000000B66B64: D72C0066
	v_cndmask_b32_e32 v1, 0x83dcd12d, v102, vcc_lo             // 000000B66B68: 0202CCFF 83DCD12D
	v_and_b32_e32 v104, 0xffff, v104                           // 000000B66B70: 36D0D0FF 0000FFFF
	v_lshl_or_b32 v16, v16, 16, v30                            // 000000B66B78: D6560010 04792110
	v_lshl_or_b32 v30, v33, 16, v110                           // 000000B66B80: D656001E 05B92121
	v_lshl_or_b32 v33, v120, 16, v119                          // 000000B66B88: D6560021 05DD2178
	v_pk_fma_f16 v120, v98, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000B66B90: CC0E0078 0BFC0B62 0000C931
	v_and_b32_e32 v22, 0xffff, v22                             // 000000B66B9C: 362C2CFF 0000FFFF
	v_pk_fma_f16 v110, v32, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000B66BA4: CC0E006E 0BFC0B20 0000C931
	v_and_b32_e32 v20, 0xffff, v20                             // 000000B66BB0: 362828FF 0000FFFF
	v_sad_u8 v100, v100, 0, 0x6400                             // 000000B66BB8: D6220064 03FD0164 00006400
	v_mov_b32_e32 v135, v120                                   // 000000B66BC4: 7F0E0378
	.long 0xd72c0016                                           // 000000B66BC8: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 000000B66BCC: 02022CFF 83DCD12D
	v_sad_u8 v27, v27, 0, 0x6400                               // 000000B66BD4: D622001B 03FD011B 00006400
	.long 0xd72c0014                                           // 000000B66BE0: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v20, vcc_lo              // 000000B66BE4: 020228FF 83DCD12D
	v_lshl_or_b32 v97, v100, 16, v123                          // 000000B66BEC: D6560061 05ED2164
	v_pk_fma_f16 v100, v16, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000B66BF4: CC0E0064 0BFC0B10 0000C931
	v_and_b32_e32 v18, 0xffff, v18                             // 000000B66C00: 362424FF 0000FFFF
	v_sad_u8 v99, v99, 0, 0x6400                               // 000000B66C08: D6220063 03FD0163 00006400
	v_and_b32_e32 v27, 0xffff, v27                             // 000000B66C14: 363636FF 0000FFFF
	v_sad_u8 v22, v22, 0, 0x6400                               // 000000B66C1C: D6220016 03FD0116 00006400
	v_sad_u8 v102, v102, 0, 0x6400                             // 000000B66C28: D6220066 03FD0166 00006400
	v_sad_u8 v20, v20, 0, 0x6400                               // 000000B66C34: D6220014 03FD0114 00006400
	.long 0xd72c0012                                           // 000000B66C40: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 000000B66C44: 020224FF 83DCD12D
	v_and_b32_e32 v99, 0xffff, v99                             // 000000B66C4C: 36C6C6FF 0000FFFF
	v_and_b32_e32 v22, 0xffff, v22                             // 000000B66C54: 362C2CFF 0000FFFF
	v_and_b32_e32 v125, 0xffff, v125                           // 000000B66C5C: 36FAFAFF 0000FFFF
	v_and_b32_e32 v20, 0xffff, v20                             // 000000B66C64: 362828FF 0000FFFF
	v_pk_fma_f16 v17, v17, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000B66C6C: CC0E0011 0BFC0B11 0000C931
	v_pk_fma_f16 v23, v23, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000B66C78: CC0E0017 0BFC0B17 0000C931
	v_lshl_or_b32 v22, v107, 16, v22                           // 000000B66C84: D6560016 0459216B
	v_sad_u8 v18, v18, 0, 0x6400                               // 000000B66C8C: D6220012 03FD0112 00006400
	v_lshl_or_b32 v20, v105, 16, v20                           // 000000B66C98: D6560014 04512169
	v_pk_fma_f16 v107, v29, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000B66CA0: CC0E006B 0BFC0B1D 0000C931
	v_and_b32_e32 v19, 0xffff, v19                             // 000000B66CAC: 362626FF 0000FFFF
	v_pk_fma_f16 v105, v22, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000B66CB4: CC0E0069 0BFC0B16 0000C931
	v_lshl_or_b32 v18, v18, 16, v27                            // 000000B66CC0: D6560012 046D2112
	v_add_nc_u32_e32 v26, s11, v41                             // 000000B66CC8: 4A34520B
	v_mov_b32_e32 v22, v23                                     // 000000B66CCC: 7E2C0317
	v_pk_fma_f16 v108, v30, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000B66CD0: CC0E006C 0BFC0B1E 0000C931
	v_mov_b32_e32 v98, v105                                    // 000000B66CDC: 7EC40369
	.long 0xd72c0023                                           // 000000B66CE0: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000B66CE4: 020246FF 83DCD12D
	v_pk_fma_f16 v18, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000B66CEC: CC0E0012 0BFC0B12 0000C931
	v_permlanex16_b32 v22, v22, s8, 0xfedcba98                 // 000000B66CF8: D65C0016 03FC1116 FEDCBA98
	v_and_b32_e32 v130, 0xffff, v137                           // 000000B66D04: 370512FF 0000FFFF
	v_pk_fma_f16 v109, v31, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000B66D0C: CC0E006D 0BFC0B1F 0000C931
	v_pk_fma_f16 v111, v33, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000B66D18: CC0E006F 0BFC0B21 0000C931
	v_mov_b32_e32 v123, v108                                   // 000000B66D24: 7EF6036C
	v_and_b32_e32 v129, 0xffff, v136                           // 000000B66D28: 370310FF 0000FFFF
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000B66D30: D6220023 03FD0123 00006400
	v_pk_fma_f16 v119, v97, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000B66D3C: CC0E0077 0BFC0B61 0000C931
	v_mov_b32_e32 v124, v109                                   // 000000B66D48: 7EF8036D
	v_mov_b32_e32 v126, v111                                   // 000000B66D4C: 7EFC036F
	v_permlanex16_b32 v98, v98, s8, 0xfedcba98                 // 000000B66D50: D65C0062 03FC1162 FEDCBA98
	v_and_b32_e32 v35, 0xffff, v35                             // 000000B66D5C: 364646FF 0000FFFF
	v_permlanex16_b32 v123, v123, s8, 0xfedcba98               // 000000B66D64: D65C007B 03FC117B FEDCBA98
	v_mov_b32_e32 v134, v119                                   // 000000B66D70: 7F0C0377
	v_permlanex16_b32 v124, v124, s8, 0xfedcba98               // 000000B66D74: D65C007C 03FC117C FEDCBA98
	v_permlanex16_b32 v126, v126, s8, 0xfedcba98               // 000000B66D80: D65C007E 03FC117E FEDCBA98
	v_lshl_or_b32 v27, v103, 16, v35                           // 000000B66D8C: D656001B 048D2167
	v_lshl_or_b32 v35, v122, 16, v99                           // 000000B66D94: D6560023 058D217A
	v_mov_b32_e32 v122, v107                                   // 000000B66D9C: 7EF4036B
	.long 0xd72c0013                                           // 000000B66DA0: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 000000B66DA4: 020226FF 83DCD12D
	v_lshl_or_b32 v99, v102, 16, v125                          // 000000B66DAC: D6560063 05F52166
	v_pk_fma_f16 v101, v27, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000B66DB4: CC0E0065 0BFC0B1B 0000C931
	v_pk_fma_f16 v103, v20, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000B66DC0: CC0E0067 0BFC0B14 0000C931
	v_mov_b32_e32 v27, v100                                    // 000000B66DCC: 7E360364
	v_pk_fma_f16 v35, v35, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000B66DD0: CC0E0023 0BFC0B23 0000C931
	v_pk_fma_f16 v121, v99, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000B66DDC: CC0E0079 0BFC0B63 0000C931
	v_mov_b32_e32 v28, v101                                    // 000000B66DE8: 7E380365
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000B66DEC: D6220013 03FD0113 00006400
	v_mov_b32_e32 v30, v103                                    // 000000B66DF8: 7E3C0367
	v_permlanex16_b32 v27, v27, s8, 0xfedcba98                 // 000000B66DFC: D65C001B 03FC111B FEDCBA98
	v_mov_b32_e32 v99, v106                                    // 000000B66E08: 7EC6036A
	v_permlanex16_b32 v28, v28, s8, 0xfedcba98                 // 000000B66E0C: D65C001C 03FC111C FEDCBA98
	v_lshl_or_b32 v19, v19, 16, v104                           // 000000B66E18: D6560013 05A12113
	v_pk_fma_f16 v104, v21, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000B66E20: CC0E0068 0BFC0B15 0000C931
	v_mov_b32_e32 v21, v18                                     // 000000B66E2C: 7E2A0312
	v_permlanex16_b32 v30, v30, s8, 0xfedcba98                 // 000000B66E30: D65C001E 03FC111E FEDCBA98
	v_cndmask_b32_e64 v31, v101, v28, s1                       // 000000B66E3C: D501001F 00063965
	v_pk_fma_f16 v102, v19, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000B66E44: CC0E0066 0BFC0B13 0000C931
	v_mov_b32_e32 v19, v17                                     // 000000B66E50: 7E260311
	ds_load_b128 v[57:60], v26                                 // 000000B66E54: DBFC0000 3900001A
	ds_load_b128 v[61:64], v26 offset:16                       // 000000B66E5C: DBFC0010 3D00001A
	ds_load_b128 v[65:68], v26 offset:32                       // 000000B66E64: DBFC0020 4100001A
	ds_load_b128 v[69:72], v26 offset:48                       // 000000B66E6C: DBFC0030 4500001A
	ds_load_b128 v[73:76], v26 offset:64                       // 000000B66E74: DBFC0040 4900001A
	ds_load_b128 v[77:80], v26 offset:80                       // 000000B66E7C: DBFC0050 4D00001A
	ds_load_b128 v[81:84], v26 offset:96                       // 000000B66E84: DBFC0060 5100001A
	ds_load_b128 v[85:88], v26 offset:112                      // 000000B66E8C: DBFC0070 5500001A
	ds_load_b128 v[89:92], v26 offset:128                      // 000000B66E94: DBFC0080 5900001A
	ds_load_b128 v[93:96], v26 offset:144                      // 000000B66E9C: DBFC0090 5D00001A
	v_mov_b32_e32 v34, v104                                    // 000000B66EA4: 7E440368
	v_permlanex16_b32 v21, v21, s8, 0xfedcba98                 // 000000B66EA8: D65C0015 03FC1115 FEDCBA98
	v_mov_b32_e32 v29, v102                                    // 000000B66EB4: 7E3A0366
	v_permlanex16_b32 v19, v19, s8, 0xfedcba98                 // 000000B66EB8: D65C0013 03FC1113 FEDCBA98
	v_cndmask_b32_e64 v33, v103, v30, s1                       // 000000B66EC4: D5010021 00063D67
	v_permlanex16_b32 v34, v34, s8, 0xfedcba98                 // 000000B66ECC: D65C0022 03FC1122 FEDCBA98
	v_mov_b32_e32 v125, v110                                   // 000000B66ED8: 7EFA036E
	v_permlanex16_b32 v29, v29, s8, 0xfedcba98                 // 000000B66EDC: D65C001D 03FC111D FEDCBA98
	v_cndmask_b32_e64 v16, v19, v17, s1                        // 000000B66EE8: D5010010 00062313
	v_cndmask_b32_e64 v20, v17, v19, s1                        // 000000B66EF0: D5010014 00062711
	v_cndmask_b32_e64 v17, v21, v18, s1                        // 000000B66EF8: D5010011 00062515
	v_cndmask_b32_e64 v21, v18, v21, s1                        // 000000B66F00: D5010015 00062B12
	v_cndmask_b32_e64 v18, v22, v23, s1                        // 000000B66F08: D5010012 00062F16
	v_cndmask_b32_e64 v22, v23, v22, s1                        // 000000B66F10: D5010016 00062D17
	v_cndmask_b32_e64 v19, v27, v100, s1                       // 000000B66F18: D5010013 0006C91B
	v_cndmask_b32_e64 v23, v100, v27, s1                       // 000000B66F20: D5010017 00063764
	v_cndmask_b32_e64 v27, v28, v101, s1                       // 000000B66F28: D501001B 0006CB1C
	v_cndmask_b32_e64 v28, v29, v102, s1                       // 000000B66F30: D501001C 0006CD1D
	v_cndmask_b32_e64 v32, v102, v29, s1                       // 000000B66F38: D5010020 00063B66
	v_cndmask_b32_e64 v29, v30, v103, s1                       // 000000B66F40: D501001D 0006CF1E
	v_cndmask_b32_e64 v30, v34, v104, s1                       // 000000B66F48: D501001E 0006D122
	v_cndmask_b32_e64 v34, v104, v34, s1                       // 000000B66F50: D5010022 00064568
	s_waitcnt lgkmcnt(8)                                       // 000000B66F58: BF89FC87
	v_wmma_f32_16x16x16_f16 v[2:9], v[16:23], v[57:64], v[2:9] // 000000B66F5C: CC404002 1C0A7310
	.long 0xd72c0017                                           // 000000B66F64: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 000000B66F68: 020304FF 83DCD12D
	v_and_b32_e32 v19, 0xffff, v138                            // 000000B66F70: 362714FF 0000FFFF
	v_and_b32_e32 v22, 0xffff, v139                            // 000000B66F78: 362D16FF 0000FFFF
	v_permlanex16_b32 v99, v99, s8, 0xfedcba98                 // 000000B66F80: D65C0063 03FC1163 FEDCBA98
	s_waitcnt lgkmcnt(6)                                       // 000000B66F8C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[2:9], v[27:34], v[65:72], v[2:9] // 000000B66F90: CC404002 1C0A831B
	.long 0xd72c001c                                           // 000000B66F98: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v132, vcc_lo             // 000000B66F9C: 020308FF 83DCD12D
	.long 0xd72c001f                                           // 000000B66FA4: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v131, vcc_lo             // 000000B66FA8: 020306FF 83DCD12D
	v_permlanex16_b32 v122, v122, s8, 0xfedcba98               // 000000B66FB0: D65C007A 03FC117A FEDCBA98
	v_sad_u8 v23, v23, 0, 0x6400                               // 000000B66FBC: D6220017 03FD0117 00006400
	.long 0xd72c001e                                           // 000000B66FC8: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 000000B66FCC: 020302FF 83DCD12D
	.long 0xd72c0016                                           // 000000B66FD4: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 000000B66FD8: 02022CFF 83DCD12D
	.long 0xd72c0013                                           // 000000B66FE0: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 000000B66FE4: 020226FF 83DCD12D
	v_dual_mov_b32 v133, v35 :: v_dual_mov_b32 v136, v121      // 000000B66FEC: CA100123 85880179
	v_permlanex16_b32 v125, v125, s8, 0xfedcba98               // 000000B66FF4: D65C007D 03FC117D FEDCBA98
	v_permlanex16_b32 v128, v128, s8, 0xfedcba98               // 000000B67000: D65C0080 03FC1180 FEDCBA98
	v_cndmask_b32_e64 v97, v98, v105, s1                       // 000000B6700C: D5010061 0006D362
	v_cndmask_b32_e64 v101, v105, v98, s1                      // 000000B67014: D5010065 0006C569
	v_cndmask_b32_e64 v98, v99, v106, s1                       // 000000B6701C: D5010062 0006D563
	v_cndmask_b32_e64 v102, v106, v99, s1                      // 000000B67024: D5010066 0006C76A
	v_cndmask_b32_e64 v99, v122, v107, s1                      // 000000B6702C: D5010063 0006D77A
	v_cndmask_b32_e64 v103, v107, v122, s1                     // 000000B67034: D5010067 0006F56B
	v_cndmask_b32_e64 v100, v123, v108, s1                     // 000000B6703C: D5010064 0006D97B
	v_cndmask_b32_e64 v104, v108, v123, s1                     // 000000B67044: D5010068 0006F76C
	v_sad_u8 v27, v127, 0, 0x6400                              // 000000B6704C: D622001B 03FD017F 00006400
	v_sad_u8 v28, v28, 0, 0x6400                               // 000000B67058: D622001C 03FD011C 00006400
	v_and_b32_e32 v23, 0xffff, v23                             // 000000B67064: 362E2EFF 0000FFFF
	v_sad_u8 v31, v31, 0, 0x6400                               // 000000B6706C: D622001F 03FD011F 00006400
	v_permlanex16_b32 v133, v133, s8, 0xfedcba98               // 000000B67078: D65C0085 03FC1185 FEDCBA98
	v_permlanex16_b32 v134, v134, s8, 0xfedcba98               // 000000B67084: D65C0086 03FC1186 FEDCBA98
	v_permlanex16_b32 v135, v135, s8, 0xfedcba98               // 000000B67090: D65C0087 03FC1187 FEDCBA98
	v_permlanex16_b32 v136, v136, s8, 0xfedcba98               // 000000B6709C: D65C0088 03FC1188 FEDCBA98
	v_cndmask_b32_e64 v105, v124, v109, s1                     // 000000B670A8: D5010069 0006DB7C
	v_cndmask_b32_e64 v109, v109, v124, s1                     // 000000B670B0: D501006D 0006F96D
	v_cndmask_b32_e64 v106, v125, v110, s1                     // 000000B670B8: D501006A 0006DD7D
	v_cndmask_b32_e64 v110, v110, v125, s1                     // 000000B670C0: D501006E 0006FB6E
	v_cndmask_b32_e64 v107, v126, v111, s1                     // 000000B670C8: D501006B 0006DF7E
	v_cndmask_b32_e64 v111, v111, v126, s1                     // 000000B670D0: D501006F 0006FD6F
	v_cndmask_b32_e64 v108, v128, v112, s1                     // 000000B670D8: D501006C 0006E180
	v_cndmask_b32_e64 v112, v112, v128, s1                     // 000000B670E0: D5010070 00070170
	s_waitcnt lgkmcnt(4)                                       // 000000B670E8: BF89FC47
	v_wmma_f32_16x16x16_f16 v[2:9], v[97:104], v[73:80], v[2:9]// 000000B670EC: CC404002 1C0A9361
	v_and_b32_e32 v27, 0xffff, v27                             // 000000B670F4: 363636FF 0000FFFF
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000B670FC: D622001E 03FD011E 00006400
	v_sad_u8 v22, v22, 0, 0x6400                               // 000000B67108: D6220016 03FD0116 00006400
	v_and_b32_e32 v28, 0xffff, v28                             // 000000B67114: 363838FF 0000FFFF
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000B6711C: D6220013 03FD0113 00006400
	v_lshl_or_b32 v23, v31, 16, v23                            // 000000B67128: D6560017 045D211F
	v_cndmask_b32_e64 v16, v133, v35, s1                       // 000000B67130: D5010010 00064785
	v_cndmask_b32_e64 v20, v35, v133, s1                       // 000000B67138: D5010014 00070B23
	v_cndmask_b32_e64 v17, v134, v119, s1                      // 000000B67140: D5010011 0006EF86
	v_cndmask_b32_e64 v21, v119, v134, s1                      // 000000B67148: D5010015 00070D77
	v_cndmask_b32_e64 v18, v135, v120, s1                      // 000000B67150: D5010012 0006F187
	s_waitcnt lgkmcnt(2)                                       // 000000B67158: BF89FC27
	v_wmma_f32_16x16x16_f16 v[2:9], v[105:112], v[81:88], v[2:9]// 000000B6715C: CC404002 1C0AA369
	v_and_b32_e32 v32, 0xffff, v22                             // 000000B67164: 36402CFF 0000FFFF
	v_lshl_or_b32 v27, v30, 16, v27                            // 000000B6716C: D656001B 046D211E
	v_cndmask_b32_e64 v22, v120, v135, s1                      // 000000B67174: D5010016 00070F78
	v_lshl_or_b32 v28, v19, 16, v28                            // 000000B6717C: D656001C 04712113
	v_cndmask_b32_e64 v19, v136, v121, s1                      // 000000B67184: D5010013 0006F388
	v_pk_fma_f16 v30, v23, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000B6718C: CC0E001E 0BFC0B17 0000C931
	v_cndmask_b32_e64 v23, v121, v136, s1                      // 000000B67198: D5010017 00071179
	v_and_b32_e32 v29, 0xffff, v140                            // 000000B671A0: 363B18FF 0000FFFF
	s_waitcnt vmcnt(6)                                         // 000000B671A8: BF891BF7
	.long 0xd73d0039                                           // 000000B671AC: D73D0039
	v_cndmask_b32_e32 v1, v43, v113, vcc_lo                    // 000000B671B0: 0202E32B
	v_pk_fma_f16 v27, v27, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000B671B4: CC0E001B 0BFC0B1B 0000C931
	v_pk_fma_f16 v35, v28, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000B671C0: CC0E0023 0BFC0B1C 0000C931
	s_waitcnt lgkmcnt(0)                                       // 000000B671CC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[16:23], v[89:96], v[2:9] // 000000B671D0: CC404002 1C0AB310
	.long 0xd73d0016                                           // 000000B671D8: D73D0016
	v_cndmask_b32_e32 v1, v42, v113, vcc_lo                    // 000000B671DC: 0202E32A
	.long 0xd72c001d                                           // 000000B671E0: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 000000B671E4: 02023AFF 83DCD12D
	v_and_b32_e32 v65, 0xffff, v57                             // 000000B671EC: 368272FF 0000FFFF
	.long 0xd73d0039                                           // 000000B671F4: D73D0039
	v_cndmask_b32_e32 v1, v45, v113, vcc_lo                    // 000000B671F8: 0202E32D
	s_waitcnt vmcnt(4)                                         // 000000B671FC: BF8913F7
	.long 0xd73d003a                                           // 000000B67200: D73D003A
	v_cndmask_b32_e32 v1, v46, v24, vcc_lo                     // 000000B67204: 0202312E
	.long 0xd73d003b                                           // 000000B67208: D73D003B
	v_cndmask_b32_e32 v1, v47, v24, vcc_lo                     // 000000B6720C: 0202312F
	v_and_b32_e32 v19, 0xffff, v22                             // 000000B67210: 36262CFF 0000FFFF
	.long 0xd73d0016                                           // 000000B67218: D73D0016
	v_cndmask_b32_e32 v1, v44, v113, vcc_lo                    // 000000B6721C: 0202E32C
	.long 0xd73d003c                                           // 000000B67220: D73D003C
	v_cndmask_b32_e32 v1, v48, v24, vcc_lo                     // 000000B67224: 02023130
	v_sad_u8 v29, v29, 0, 0x6400                               // 000000B67228: D622001D 03FD011D 00006400
	v_and_b32_e32 v57, 0xffff, v57                             // 000000B67234: 367272FF 0000FFFF
	.long 0xd72c0013                                           // 000000B6723C: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 000000B67240: 020226FF 83DCD12D
	v_and_b32_e32 v58, 0xffff, v58                             // 000000B67248: 367474FF 0000FFFF
	v_and_b32_e32 v61, 0xffff, v22                             // 000000B67250: 367A2CFF 0000FFFF
	.long 0xd73d0016                                           // 000000B67258: D73D0016
	v_cndmask_b32_e32 v1, v49, v24, vcc_lo                     // 000000B6725C: 02023131
	v_and_b32_e32 v24, 0xffff, v60                             // 000000B67260: 363078FF 0000FFFF
	v_lshl_or_b32 v29, v29, 16, v32                            // 000000B67268: D656001D 0481211D
	v_and_b32_e32 v23, 0xffff, v59                             // 000000B67270: 362E76FF 0000FFFF
	.long 0xd72c0019                                           // 000000B67278: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000B6727C: 02027AFF 83DCD12D
	.long 0xd72c003b                                           // 000000B67284: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000B67288: 020282FF 83DCD12D
	v_and_b32_e32 v22, 0xffff, v22                             // 000000B67290: 362C2CFF 0000FFFF
	.long 0xd72c0018                                           // 000000B67298: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 000000B6729C: 020230FF 83DCD12D
	.long 0xd72c0039                                           // 000000B672A4: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000B672A8: 020272FF 83DCD12D
	.long 0xd72c003a                                           // 000000B672B0: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000B672B4: 020274FF 83DCD12D
	v_pk_fma_f16 v62, v29, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000B672BC: CC0E003E 0BFC0B1D 0000C931
	v_dual_mov_b32 v28, v27 :: v_dual_mov_b32 v29, v30         // 000000B672C8: CA10011B 1C1C011E
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000B672D0: D6220013 03FD0113 00006400
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000B672DC: D6220019 03FD0119 00006400
	.long 0xd72c0016                                           // 000000B672E8: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 000000B672EC: 02022CFF 83DCD12D
	.long 0xd72c0017                                           // 000000B672F4: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 000000B672F8: 02022EFF 83DCD12D
	v_mov_b32_e32 v63, v35                                     // 000000B67300: 7E7E0323
	v_permlanex16_b32 v28, v28, s8, 0xfedcba98                 // 000000B67304: D65C001C 03FC111C FEDCBA98
	v_permlanex16_b32 v29, v29, s8, 0xfedcba98                 // 000000B67310: D65C001D 03FC111D FEDCBA98
	v_and_b32_e32 v19, 0xffff, v19                             // 000000B6731C: 362626FF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000B67324: D622003B 03FD013B 00006400
	v_sad_u8 v24, v24, 0, 0x6400                               // 000000B67330: D6220018 03FD0118 00006400
	v_and_b32_e32 v25, 0xffff, v25                             // 000000B6733C: 363232FF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000B67344: D6220039 03FD0139 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000B67350: D622003A 03FD013A 00006400
	v_permlanex16_b32 v63, v63, s8, 0xfedcba98                 // 000000B6735C: D65C003F 03FC113F FEDCBA98
	v_cndmask_b32_e64 v16, v28, v27, s1                        // 000000B67368: D5010010 0006371C
	v_cndmask_b32_e64 v20, v27, v28, s1                        // 000000B67370: D5010014 0006391B
	v_cndmask_b32_e64 v17, v29, v30, s1                        // 000000B67378: D5010011 00063D1D
	v_cndmask_b32_e64 v21, v30, v29, s1                        // 000000B67380: D5010015 00063B1E
	ds_load_b128 v[27:30], v26 offset:160                      // 000000B67388: DBFC00A0 1B00001A
	ds_load_b128 v[31:34], v26 offset:176                      // 000000B67390: DBFC00B0 1F00001A
	v_and_b32_e32 v24, 0xffff, v24                             // 000000B67398: 363030FF 0000FFFF
	v_sad_u8 v60, v22, 0, 0x6400                               // 000000B673A0: D622003C 03FD0116 00006400
	v_lshl_or_b32 v19, v59, 16, v19                            // 000000B673AC: D6560013 044D213B
	v_lshl_or_b32 v25, v57, 16, v25                            // 000000B673B4: D6560019 04652139
	v_and_b32_e32 v58, 0xffff, v58                             // 000000B673BC: 367474FF 0000FFFF
	v_sad_u8 v23, v23, 0, 0x6400                               // 000000B673C4: D6220017 03FD0117 00006400
	v_mov_b32_e32 v64, v62                                     // 000000B673D0: 7E80033E
	v_cndmask_b32_e64 v18, v63, v35, s1                        // 000000B673D4: D5010012 0006473F
	v_cndmask_b32_e64 v22, v35, v63, s1                        // 000000B673DC: D5010016 00067F23
	v_lshl_or_b32 v24, v60, 16, v24                            // 000000B673E4: D6560018 0461213C
	v_pk_fma_f16 v35, v19, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000B673EC: CC0E0023 0BFC0B13 0000C931
	v_pk_fma_f16 v25, v25, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000B673F8: CC0E0019 0BFC0B19 0000C931
	v_lshl_or_b32 v23, v23, 16, v58                            // 000000B67404: D6560017 04E92117
	v_permlanex16_b32 v64, v64, s8, 0xfedcba98                 // 000000B6740C: D65C0040 03FC1140 FEDCBA98
	v_pk_fma_f16 v61, v24, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000B67418: CC0E003D 0BFC0B18 0000C931
	v_mov_b32_e32 v24, v35                                     // 000000B67424: 7E300323
	v_mov_b32_e32 v58, v25                                     // 000000B67428: 7E740319
	v_pk_fma_f16 v57, v23, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000B6742C: CC0E0039 0BFC0B17 0000C931
	v_cndmask_b32_e64 v19, v64, v62, s1                        // 000000B67438: D5010013 00067D40
	v_cndmask_b32_e64 v23, v62, v64, s1                        // 000000B67440: D5010017 0006813E
	v_permlanex16_b32 v24, v24, s8, 0xfedcba98                 // 000000B67448: D65C0018 03FC1118 FEDCBA98
	v_permlanex16_b32 v58, v58, s8, 0xfedcba98                 // 000000B67454: D65C003A 03FC113A FEDCBA98
	v_mov_b32_e32 v59, v57                                     // 000000B67460: 7E760339
	v_mov_b32_e32 v62, v61                                     // 000000B67464: 7E7C033D
	s_waitcnt lgkmcnt(0)                                       // 000000B67468: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[16:23], v[27:34], v[2:9] // 000000B6746C: CC404002 1C0A3710
	v_cndmask_b32_e64 v16, v24, v35, s1                        // 000000B67474: D5010010 00064718
	v_cndmask_b32_e64 v20, v35, v24, s1                        // 000000B6747C: D5010014 00063123
	s_waitcnt vmcnt(0)                                         // 000000B67484: BF8903F7
	.long 0xd73d0017                                           // 000000B67488: D73D0017
	v_cndmask_b32_e32 v1, v42, v117, vcc_lo                    // 000000B6748C: 0202EB2A
	v_cndmask_b32_e64 v17, v58, v25, s1                        // 000000B67490: D5010011 0006333A
	v_cndmask_b32_e64 v21, v25, v58, s1                        // 000000B67498: D5010015 00067519
	.long 0xd73d0018                                           // 000000B674A0: D73D0018
	v_cndmask_b32_e32 v1, v43, v117, vcc_lo                    // 000000B674A4: 0202EB2B
	v_permlanex16_b32 v59, v59, s8, 0xfedcba98                 // 000000B674A8: D65C003B 03FC113B FEDCBA98
	v_permlanex16_b32 v62, v62, s8, 0xfedcba98                 // 000000B674B4: D65C003E 03FC113E FEDCBA98
	v_and_b32_e32 v19, 0xffff, v23                             // 000000B674C0: 36262EFF 0000FFFF
	ds_load_b128 v[27:30], v26 offset:192                      // 000000B674C8: DBFC00C0 1B00001A
	ds_load_b128 v[31:34], v26 offset:208                      // 000000B674D0: DBFC00D0 1F00001A
	s_nor_b32 s11, s0, s9                                      // 000000B674D8: 8F0B0900
	v_cndmask_b32_e64 v18, v59, v57, s1                        // 000000B674DC: D5010012 0006733B
	v_cndmask_b32_e64 v22, v57, v59, s1                        // 000000B674E4: D5010016 00067739
	v_and_b32_e32 v35, 0xffff, v24                             // 000000B674EC: 364630FF 0000FFFF
	.long 0xd73d0017                                           // 000000B674F4: D73D0017
	v_cndmask_b32_e32 v1, v44, v117, vcc_lo                    // 000000B674F8: 0202EB2C
	.long 0xd73d0039                                           // 000000B674FC: D73D0039
	v_cndmask_b32_e32 v1, v46, v115, vcc_lo                    // 000000B67500: 0202E72E
	.long 0xd73d0018                                           // 000000B67504: D73D0018
	v_cndmask_b32_e32 v1, v45, v117, vcc_lo                    // 000000B67508: 0202EB2D
	.long 0xd73d003a                                           // 000000B6750C: D73D003A
	v_cndmask_b32_e32 v1, v47, v115, vcc_lo                    // 000000B67510: 0202E72F
	.long 0xd73d003b                                           // 000000B67514: D73D003B
	v_cndmask_b32_e32 v1, v48, v115, vcc_lo                    // 000000B67518: 0202E730
	.long 0xd72c0013                                           // 000000B6751C: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 000000B67520: 020226FF 83DCD12D
	v_and_b32_e32 v25, 0xffff, v23                             // 000000B67528: 36322EFF 0000FFFF
	v_and_b32_e32 v57, 0xffff, v57                             // 000000B67530: 367272FF 0000FFFF
	v_and_b32_e32 v60, 0xffff, v24                             // 000000B67538: 367830FF 0000FFFF
	.long 0xd73d0017                                           // 000000B67540: D73D0017
	v_cndmask_b32_e32 v1, v49, v115, vcc_lo                    // 000000B67544: 0202E731
	v_and_b32_e32 v24, 0xffff, v58                             // 000000B67548: 363074FF 0000FFFF
	v_and_b32_e32 v58, 0xffff, v59                             // 000000B67550: 367476FF 0000FFFF
	.long 0xd72c0019                                           // 000000B67558: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000B6755C: 020232FF 83DCD12D
	.long 0xd72c0039                                           // 000000B67564: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000B67568: 020272FF 83DCD12D
	.long 0xd72c0023                                           // 000000B67570: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000B67574: 020246FF 83DCD12D
	v_and_b32_e32 v23, 0xffff, v23                             // 000000B6757C: 362E2EFF 0000FFFF
	.long 0xd72c003a                                           // 000000B67584: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000B67588: 020274FF 83DCD12D
	.long 0xd72c003b                                           // 000000B67590: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000B67594: 020278FF 83DCD12D
	.long 0xd72c0018                                           // 000000B6759C: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 000000B675A0: 020230FF 83DCD12D
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000B675A8: D6220013 03FD0113 00006400
	.long 0xd72c0017                                           // 000000B675B4: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 000000B675B8: 02022EFF 83DCD12D
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000B675C0: D6220019 03FD0119 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000B675CC: D6220039 03FD0139 00006400
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000B675D8: D6220023 03FD0123 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000B675E4: D622003A 03FD013A 00006400
	v_and_b32_e32 v19, 0xffff, v19                             // 000000B675F0: 362626FF 0000FFFF
	v_and_b32_e32 v25, 0xffff, v25                             // 000000B675F8: 363232FF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000B67600: D622003B 03FD013B 00006400
	v_and_b32_e32 v57, 0xffff, v57                             // 000000B6760C: 367272FF 0000FFFF
	v_sad_u8 v24, v24, 0, 0x6400                               // 000000B67614: D6220018 03FD0118 00006400
	v_and_b32_e32 v58, 0xffff, v58                             // 000000B67620: 367474FF 0000FFFF
	v_sad_u8 v23, v23, 0, 0x6400                               // 000000B67628: D6220017 03FD0117 00006400
	v_lshl_or_b32 v35, v35, 16, v19                            // 000000B67634: D6560023 044D2123
	v_lshl_or_b32 v25, v59, 16, v25                            // 000000B6763C: D6560019 0465213B
	v_lshl_or_b32 v24, v24, 16, v57                            // 000000B67644: D6560018 04E52118
	v_cndmask_b32_e64 v19, v62, v61, s1                        // 000000B6764C: D5010013 00067B3E
	v_lshl_or_b32 v57, v23, 16, v58                            // 000000B67654: D6560039 04E92117
	v_pk_fma_f16 v35, v35, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000B6765C: CC0E0023 0BFC0B23 0000C931
	v_pk_fma_f16 v25, v25, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000B67668: CC0E0019 0BFC0B19 0000C931
	v_cndmask_b32_e64 v23, v61, v62, s1                        // 000000B67674: D5010017 00067D3D
	v_pk_fma_f16 v24, v24, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000B6767C: CC0E0018 0BFC0B18 0000C931
	v_pk_fma_f16 v65, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000B67688: CC0E0041 0BFC0B39 0000C931
	ds_load_b128 v[57:60], v26 offset:224                      // 000000B67694: DBFC00E0 3900001A
	ds_load_b128 v[61:64], v26 offset:240                      // 000000B6769C: DBFC00F0 3D00001A
	v_dual_mov_b32 v66, v35 :: v_dual_mov_b32 v67, v25         // 000000B676A4: CA100123 42420119
	v_mov_b32_e32 v26, v24                                     // 000000B676AC: 7E340318
	v_mov_b32_e32 v68, v65                                     // 000000B676B0: 7E880341
	s_waitcnt lgkmcnt(2)                                       // 000000B676B4: BF89FC27
	v_wmma_f32_16x16x16_f16 v[2:9], v[16:23], v[27:34], v[2:9] // 000000B676B8: CC404002 1C0A3710
	v_permlanex16_b32 v66, v66, s8, 0xfedcba98                 // 000000B676C0: D65C0042 03FC1142 FEDCBA98
	v_permlanex16_b32 v67, v67, s8, 0xfedcba98                 // 000000B676CC: D65C0043 03FC1143 FEDCBA98
	v_permlanex16_b32 v26, v26, s8, 0xfedcba98                 // 000000B676D8: D65C001A 03FC111A FEDCBA98
	v_permlanex16_b32 v68, v68, s8, 0xfedcba98                 // 000000B676E4: D65C0044 03FC1144 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4)                            // 000000B676F0: BF870004
	v_cndmask_b32_e64 v16, v66, v35, s1                        // 000000B676F4: D5010010 00064742
	v_cndmask_b32_e64 v20, v35, v66, s1                        // 000000B676FC: D5010014 00068523
	v_cndmask_b32_e64 v17, v67, v25, s1                        // 000000B67704: D5010011 00063343
	v_cndmask_b32_e64 v21, v25, v67, s1                        // 000000B6770C: D5010015 00068719
	v_cndmask_b32_e64 v18, v26, v24, s1                        // 000000B67714: D5010012 0006311A
	v_cndmask_b32_e64 v22, v24, v26, s1                        // 000000B6771C: D5010016 00063518
	v_cndmask_b32_e64 v19, v68, v65, s1                        // 000000B67724: D5010013 00068344
	v_cndmask_b32_e64 v23, v65, v68, s1                        // 000000B6772C: D5010017 00068941
	s_waitcnt lgkmcnt(0)                                       // 000000B67734: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B67738: BF870001
	v_wmma_f32_16x16x16_f16 v[2:9], v[16:23], v[57:64], v[2:9] // 000000B6773C: CC404002 1C0A7310
	s_and_saveexec_b32 s9, s11                                 // 000000B67744: BE89200B
	s_cbranch_execz 64200                                      // 000000B67748: BFA5FAC8 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x996c>
	s_and_b32 s10, s10, exec_lo                                // 000000B6774C: 8B0A7E0A
	s_cselect_b32 s10, 0x4400, 0                               // 000000B67750: 980A80FF 00004400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B67758: BF870099
	v_lshl_add_u32 v16, v39, 1, s10                            // 000000B6775C: D6460010 00290327
	v_lshl_add_u32 v16, v38, 1, v16                            // 000000B67764: D6460010 04410326
	ds_store_b128 v16, v[10:13]                                // 000000B6776C: DB7C0000 00000A10
	s_branch 64189                                             // 000000B67774: BFA0FABD <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x996c>
	v_mad_u32_u24 v10, 0x110, v9, v10                          // 000000B67778: D60B000A 042A12FF 00000110
	s_waitcnt vmcnt(2)                                         // 000000B67784: BF890BF7
	ds_store_b128 v10, v[37:40]                                // 000000B67788: DB7C0000 0000250A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000B67790: 8C7E017E
	.long 0xd44c0001                                           // 000000B67794: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000B67798: 020200FF 00000200
	s_and_saveexec_b32 s2, s1                                  // 000000B677A0: BE822001
	s_cbranch_execz 54469                                      // 000000B677A4: BFA5D4C5 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1bc>
	s_waitcnt vmcnt(1)                                         // 000000B677A8: BF8907F7
	ds_store_b128 v11, v[41:44] offset:8704                    // 000000B677AC: DB7C2200 0000290B
	s_or_b32 exec_lo, exec_lo, s2                              // 000000B677B4: 8C7E027E
	.long 0xd44c0002                                           // 000000B677B8: D44C0002
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000B677BC: 020200FF 00000100
	s_and_saveexec_b32 s3, s2                                  // 000000B677C4: BE832002
	s_cbranch_execnz 54466                                     // 000000B677C8: BFA6D4C2 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1d4>
	s_branch 54468                                             // 000000B677CC: BFA0D4C4 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1e0>
	v_lshlrev_b32_e32 v1, 6, v36                               // 000000B677D0: 30024886
	v_lshrrev_b32_e32 v10, 2, v37                              // 000000B677D4: 32144A82
	s_lshl_b32 s0, s17, 7                                      // 000000B677D8: 84008711
	s_mul_i32 s3, s16, 0x1400                                  // 000000B677DC: 9603FF10 00001400
	s_mul_hi_i32 s2, s16, 0x1400                               // 000000B677E4: 9702FF10 00001400
	v_mad_u32_u24 v1, 0x210, v40, v1                           // 000000B677EC: D60B0001 040650FF 00000210
	s_ashr_i32 s1, s0, 31                                      // 000000B677F8: 86019F00
	s_add_u32 s3, s14, s3                                      // 000000B677FC: 8003030E
	v_and_b32_e32 v11, 1, v0                                   // 000000B67800: 36160081
	v_and_b32_e32 v12, 2, v0                                   // 000000B67804: 36180082
	v_and_or_b32 v1, v10, 4, v1                                // 000000B67808: D6570001 0405090A
	v_and_b32_e32 v13, 4, v0                                   // 000000B67810: 361A0084
	v_and_b32_e32 v14, 16, v0                                  // 000000B67814: 361C0090
	v_and_b32_e32 v0, 8, v0                                    // 000000B67818: 36000088
	s_addc_u32 s9, s15, s2                                     // 000000B6781C: 8209020F
	ds_store_2addr_b32 v1, v2, v3 offset1:2                    // 000000B67820: D8380200 00030201
	ds_store_2addr_b32 v1, v4, v5 offset0:4 offset1:6          // 000000B67828: D8380604 00050401
	ds_store_2addr_b32 v1, v6, v7 offset0:8 offset1:10         // 000000B67830: D8380A08 00070601
	ds_store_2addr_b32 v1, v8, v9 offset0:12 offset1:14        // 000000B67838: D8380E0C 00090801
	v_lshlrev_b32_e32 v1, 3, v37                               // 000000B67840: 30024A83
	s_lshl_b64 s[4:5], s[0:1], 1                               // 000000B67844: 84848100
	v_lshlrev_b32_e32 v10, 2, v37                              // 000000B67848: 30144A82
	s_add_u32 s8, s3, s4                                       // 000000B6784C: 80080403
	.long 0xd44a0003                                           // 000000B67850: D44A0003
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 000000B67854: 02021680
	.long 0xd7000001                                           // 000000B67858: D7000001
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 000000B6785C: 02020206
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B67860: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s7, 0, s0                    // 000000B67864: D5207C02 00010007
	.long 0xd44a0000                                           // 000000B6786C: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000B67870: 02020080
	.long 0xd7000400                                           // 000000B67874: D7000400
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000B67878: 02000901
	.long 0xd44a0002                                           // 000000B6787C: D44A0002
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000B67880: 02021880
	.long 0xd44a0001                                           // 000000B67884: D44A0001
	v_cndmask_b32_e32 v1, 0, v13, vcc_lo                       // 000000B67888: 02021A80
	v_add_co_ci_u32_e64 v1, null, s5, v2, s4                   // 000000B6788C: D5207C01 00120405
	v_lshlrev_b32_e32 v2, 1, v10                               // 000000B67894: 30041481
	s_addc_u32 s9, s9, s5                                      // 000000B67898: 82090509
	s_mov_b32 s5, exec_lo                                      // 000000B6789C: BE85007E
	v_cmp_eq_u32_e32 vcc_lo, 0, v14                            // 000000B678A0: 7C941C80
	s_waitcnt lgkmcnt(0)                                       // 000000B678A4: BF89FC07
	s_barrier                                                  // 000000B678A8: BFBD0000
	buffer_gl0_inv                                             // 000000B678AC: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000B678B4: D4C4007E
	v_cndmask_b32_e32 v1, s19, v36, vcc_lo                     // 000000B678B8: 02024813
	s_cbranch_execz 210                                        // 000000B678BC: BFA500D2 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xb308>
	global_load_b64 v[7:8], v2, s[8:9]                         // 000000B678C0: DC560000 07080002
	v_mul_u32_u24_e32 v3, 0x210, v36                           // 000000B678C8: 160648FF 00000210
	s_mov_b32 s4, 0x76543210                                   // 000000B678D0: BE8400FF 76543210
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B678D8: BF870001
	v_lshl_add_u32 v3, v10, 2, v3                              // 000000B678DC: D6460003 040D050A
	ds_load_b128 v[3:6], v3                                    // 000000B678E4: DBFC0000 03000003
	s_waitcnt lgkmcnt(0)                                       // 000000B678EC: BF89FC07
	v_add_f32_e32 v9, v3, v4                                   // 000000B678F0: 06120903
	v_add_f32_e32 v11, v5, v6                                  // 000000B678F4: 06160D05
	v_dual_sub_f32 v3, v3, v4 :: v_dual_sub_f32 v4, v5, v6     // 000000B678F8: C94A0903 03040D05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B67900: BF8700A2
	v_add_f32_e32 v5, v9, v11                                  // 000000B67904: 060A1709
	v_sub_f32_e32 v6, v9, v11                                  // 000000B67908: 080C1709
	v_mov_b32_dpp v11, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B6790C: 7E1602FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000B67914: D5010006 200E0D06
	v_add_f32_e32 v9, v3, v4                                   // 000000B6791C: 06120903
	v_sub_f32_e32 v3, v3, v4                                   // 000000B67920: 08060903
	v_mov_b32_dpp v4, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B67924: 7E0802FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000B6792C: D5010005 200E0B05
	v_add_f32_e32 v6, v6, v11                                  // 000000B67934: 060C1706
	v_mov_b32_dpp v12, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B67938: 7E1802FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000B67940: D5010009 200E1309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B67948: BF870114
	v_add_f32_e32 v4, v5, v4                                   // 000000B6794C: 06080905
	v_add_f32_e32 v5, v9, v12                                  // 000000B67950: 060A1909
	v_mov_b32_dpp v9, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B67954: 7E1202FA FF016206
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000B6795C: BF870133
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B67960: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000B67968: D5010004 200A0904
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000B67970: D5010006 200A0D06
	v_add_f32_e32 v4, v4, v11                                  // 000000B67978: 06081704
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B6797C: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000B67984: D5010003 200E0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B6798C: BF870114
	v_add_f32_e32 v6, v6, v9                                   // 000000B67990: 060C1306
	v_add_f32_e32 v3, v3, v13                                  // 000000B67994: 06061B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B67998: BF870232
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B6799C: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000B679A4: D5010006 20060D06
	.long 0x7f1a3880                                           // 000000B679AC: 7F1A3880
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B679B0: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000B679B8: D5010003 200A0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B679C0: BF870234
	v_add_f32_e32 v6, v6, v11                                  // 000000B679C4: 060C1706
	v_mov_b32_dpp v9, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B679C8: 7E1202FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000B679D0: D5010005 200A0B05
	v_add_f32_e32 v3, v3, v12                                  // 000000B679D8: 06061903
	v_mov_b32_dpp v12, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B679DC: 7E1802FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000B679E4: D5010004 20060904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B679EC: BF870214
	v_add_f32_e32 v5, v5, v9                                   // 000000B679F0: 060A1305
	v_mov_b32_dpp v9, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B679F4: 7E1202FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000B679FC: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B67A04: BF8701B1
	v_dual_add_f32 v4, v4, v12 :: v_dual_add_f32 v3, v3, v9    // 000000B67A08: C9081904 04021303
	v_mov_b32_dpp v9, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B67A10: 7E1202FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000B67A18: D5010006 20020D06
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B67A20: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000B67A28: D5010003 20020703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000B67A30: BF8700B3
	v_add_f32_e32 v6, v6, v9                                   // 000000B67A34: 060C1306
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B67A38: 7E1202FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000B67A40: D5010004 20020904
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_f32 v4, v4, v9    // 000000B67A48: C9081903 03041304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B67A50: BF870231
	v_mov_b32_e32 v14, v3                                      // 000000B67A54: 7E1C0303
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B67A58: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000B67A60: D5010005 20060B05
	v_mov_b32_e32 v9, v4                                       // 000000B67A68: 7E120304
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000B67A6C: D5010004 21AA0904
	v_permlanex16_b32 v14, v14, s4, 0xfedcba98                 // 000000B67A74: D65C000E 03FC090E FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B67A80: BF870214
	v_add_f32_e32 v5, v5, v11                                  // 000000B67A84: 060A1705
	v_permlanex16_b32 v9, v9, s4, 0xfedcba98                   // 000000B67A88: D65C0009 03FC0909 FEDCBA98
	v_mov_b32_e32 v11, v6                                      // 000000B67A94: 7E160306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000B67A98: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B67AA0: BF870214
	v_mov_b32_dpp v12, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B67AA4: 7E1802FA FF016805
	v_add_f32_e32 v4, v4, v9                                   // 000000B67AAC: 06081304
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B67AB0: BF870234
	v_permlanex16_b32 v11, v11, s4, 0xfedcba98                 // 000000B67AB4: D65C000B 03FC090B FEDCBA98
	.long 0x7f12398d                                           // 000000B67AC0: 7F12398D
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000B67AC4: D5010005 20020B05
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000B67ACC: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B67AD4: BF870094
	v_add_f32_e32 v6, v6, v11                                  // 000000B67AD8: 060C1706
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000B67ADC: 100C0CFF 3DB504F3
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000B67AE4: D5010003 21AA0703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B67AEC: BF870091
	v_add_f32_e32 v3, v3, v14                                  // 000000B67AF0: 06061D03
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 000000B67AF4: 100606FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B67AFC: BF8903F7
	v_fma_mix_f32 v6, v8, v6, neg(0) op_sel_hi:[1,0,0]         // 000000B67B00: CC200006 8A020D08
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000B67B08: BF870232
	v_fma_mix_f32 v3, v8, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B67B0C: CC200803 8A020708
	.long 0x7f10398d                                           // 000000B67B14: 7F10398D
	v_fma_mix_f32 v4, v7, v4, neg(0) op_sel_hi:[1,0,0]         // 000000B67B18: CC200004 8A020907
	.long 0x7e123986                                           // 000000B67B20: 7E123986
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B67B24: BF870114
	.long 0x7e103983                                           // 000000B67B28: 7E103983
	v_and_b32_e32 v9, 1, v9                                    // 000000B67B2C: 36121281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B67B30: BF870121
	v_add3_u32 v6, v6, v9, 0x7fff                              // 000000B67B34: D6550006 03FE1306 00007FFF
	.long 0x7f12398d                                           // 000000B67B40: 7F12398D
	.long 0x7e123986                                           // 000000B67B44: 7E123986
	v_add_f32_e32 v5, v5, v12                                  // 000000B67B48: 060A1905
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000B67B4C: BF870121
	v_dual_mov_b32 v11, v5 :: v_dual_add_nc_u32 v6, s18, v36   // 000000B67B50: CA200105 0B064812
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000B67B58: D5010005 21AA0B05
	v_permlanex16_b32 v11, v11, s4, 0xfedcba98                 // 000000B67B60: D65C000B 03FC090B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B67B6C: BF870091
	v_add_f32_e32 v5, v5, v11                                  // 000000B67B70: 060A1705
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000B67B74: 100A0AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B67B7C: BF8701B1
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B67B80: CC200805 8A020B07
	v_and_b32_e32 v7, 1, v8                                    // 000000B67B88: 360E1081
	v_bfe_u32 v8, v4, 16, 1                                    // 000000B67B8C: D6100008 02052104
	v_bfe_u32 v11, v5, 16, 1                                   // 000000B67B94: D610000B 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B67B9C: BF870193
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000B67BA0: D6550003 03FE0F03 00007FFF
	v_add3_u32 v4, v4, v8, 0x7fff                              // 000000B67BAC: D6550004 03FE1104 00007FFF
	v_and_b32_e32 v8, 0xffff, v9                               // 000000B67BB8: 361012FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B67BC0: BF870214
	v_add3_u32 v5, v5, v11, 0x7fff                             // 000000B67BC4: D6550005 03FE1705 00007FFF
	v_and_b32_e32 v7, 0xffff0000, v3                           // 000000B67BD0: 360E06FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B67BD8: BF8701A4
	.long 0x7e1a3984                                           // 000000B67BDC: 7E1A3984
	v_mad_i64_i32 v[3:4], null, 0x1400, v6, v[0:1]             // 000000B67BE0: D6FF7C03 04020CFF 00001400
	v_or_b32_e32 v6, v7, v8                                    // 000000B67BEC: 380C1107
	s_delay_alu instid0(VALU_DEP_3)                            // 000000B67BF0: BF870003
	v_and_or_b32 v5, 0xffff0000, v5, v13                       // 000000B67BF4: D6570005 04360AFF FFFF0000
	global_store_b64 v[3:4], v[5:6], off                       // 000000B67C00: DC6E0000 007C0503
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B67C08: 8C7E057E
	v_or_b32_e32 v3, 8, v36                                    // 000000B67C0C: 38064888
	s_mov_b32 s5, exec_lo                                      // 000000B67C10: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B67C14: BF870001
	.long 0xd4c4007e                                           // 000000B67C18: D4C4007E
	v_cndmask_b32_e32 v1, s19, v3, vcc_lo                      // 000000B67C1C: 02020613
	s_cbranch_execz 203                                        // 000000B67C20: BFA500CB <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xb650>
	global_load_b64 v[8:9], v2, s[8:9]                         // 000000B67C24: DC560000 08080002
	v_mul_u32_u24_e32 v2, 0x210, v3                            // 000000B67C2C: 160406FF 00000210
	v_add_nc_u32_e32 v3, s18, v3                               // 000000B67C34: 4A060612
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B67C38: BF870112
	v_lshl_add_u32 v2, v10, 2, v2                              // 000000B67C3C: D6460002 0409050A
	v_mad_i64_i32 v[0:1], null, 0x1400, v3, v[0:1]             // 000000B67C44: D6FF7C00 040206FF 00001400
	ds_load_b128 v[4:7], v2                                    // 000000B67C50: DBFC0000 04000002
	s_waitcnt lgkmcnt(0)                                       // 000000B67C58: BF89FC07
	v_add_f32_e32 v2, v4, v5                                   // 000000B67C5C: 06040B04
	v_dual_sub_f32 v4, v4, v5 :: v_dual_sub_f32 v5, v6, v7     // 000000B67C60: C94A0B04 04040F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B67C68: BF870091
	v_dual_add_f32 v10, v6, v7 :: v_dual_add_f32 v7, v4, v5    // 000000B67C6C: C9080F06 0A060B04
	v_add_f32_e32 v6, v2, v10                                  // 000000B67C74: 060C1502
	v_sub_f32_e32 v2, v2, v10                                  // 000000B67C78: 08041502
	v_sub_f32_e32 v4, v4, v5                                   // 000000B67C7C: 08080B04
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B67C80: BF870214
	v_mov_b32_dpp v11, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B67C84: 7E1602FA FF016107
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B67C8C: 7E0A02FA FF016106
	s_delay_alu instid0(VALU_DEP_4)                            // 000000B67C94: BF870004
	v_mov_b32_dpp v10, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B67C98: 7E1402FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000B67CA0: D5010002 200E0502
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000B67CA8: D5010006 200E0D06
	v_mov_b32_dpp v12, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000B67CB0: 7E1802FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000B67CB8: D5010004 200E0904
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000B67CC0: D5010007 200E0F07
	v_add_f32_e32 v2, v2, v10                                  // 000000B67CC8: 06041502
	v_add_f32_e32 v5, v6, v5                                   // 000000B67CCC: 060A0B06
	s_mov_b32 s3, 0x76543210                                   // 000000B67CD0: BE8300FF 76543210
	v_add_f32_e32 v4, v4, v12                                  // 000000B67CD8: 06081904
	v_add_f32_e32 v6, v7, v11                                  // 000000B67CDC: 060C1707
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B67CE0: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000B67CE8: D5010002 200A0502
	v_mov_b32_dpp v10, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B67CF0: 7E1402FA FF016205
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B67CF8: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000B67D00: D5010004 200A0904
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000B67D08: D5010005 200A0B05
	v_add_f32_e32 v2, v2, v7                                   // 000000B67D10: 06040F02
	v_mov_b32_dpp v7, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000B67D14: 7E0E02FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000B67D1C: D5010006 200A0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B67D24: BF870214
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v5, v5, v10   // 000000B67D28: C9081704 04041505
	v_mov_b32_dpp v10, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B67D30: 7E1402FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000B67D38: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B67D40: BF870214
	v_add_f32_e32 v6, v6, v7                                   // 000000B67D44: 060C0F06
	v_mov_b32_dpp v7, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B67D48: 7E0E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000B67D50: D5010004 20060904
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B67D58: 7E1602FA FF016405
	v_add_f32_e32 v2, v2, v10                                  // 000000B67D60: 06041502
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000B67D64: D5010005 20060B05
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000B67D6C: 7E1402FA FF016406
	v_add_f32_e32 v4, v4, v7                                   // 000000B67D74: 06080F04
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000B67D78: D5010006 20060D06
	v_mov_b32_dpp v7, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B67D80: 7E0E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000B67D88: D5010002 20020502
	v_add_f32_e32 v5, v5, v11                                  // 000000B67D90: 060A1705
	.long 0x7f183880                                           // 000000B67D94: 7F183880
	v_mov_b32_dpp v11, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B67D98: 7E1602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000B67DA0: D5010004 20020904
	v_add_f32_e32 v2, v2, v7                                   // 000000B67DA8: 06040F02
	v_mov_b32_dpp v7, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B67DAC: 7E0E02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000B67DB4: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000B67DBC: BF870114
	v_add_f32_e32 v4, v4, v11                                  // 000000B67DC0: 06081704
	v_add_f32_e32 v5, v5, v7                                   // 000000B67DC4: 060A0F05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B67DC8: BF8701A2
	v_mov_b32_e32 v13, v4                                      // 000000B67DCC: 7E1A0304
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000B67DD0: D5010004 21AA0904
	v_mov_b32_e32 v7, v5                                       // 000000B67DD8: 7E0E0305
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000B67DDC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B67DE4: BF870194
	v_permlanex16_b32 v13, v13, s3, 0xfedcba98                 // 000000B67DE8: D65C000D 03FC070D FEDCBA98
	v_permlanex16_b32 v7, v7, s3, 0xfedcba98                   // 000000B67DF4: D65C0007 03FC0707 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000B67E00: BF870001
	v_dual_add_f32 v4, v4, v13 :: v_dual_add_f32 v5, v5, v7    // 000000B67E04: C9081B04 04040F05
	.long 0x7f0e398c                                           // 000000B67E0C: 7F0E398C
	v_add_f32_e32 v6, v6, v10                                  // 000000B67E10: 060C1506
	v_mov_b32_e32 v10, v2                                      // 000000B67E14: 7E140302
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000B67E18: D5010002 21AA0502
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000B67E20: C8C608FF 04040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B67E2C: BF870093
	v_permlanex16_b32 v10, v10, s3, 0xfedcba98                 // 000000B67E30: D65C000A 03FC070A FEDCBA98
	v_add_f32_e32 v2, v2, v10                                  // 000000B67E3C: 06041502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000B67E40: BF8700A1
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000B67E44: 100404FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000B67E4C: BF8903F7
	v_fma_mix_f32 v2, v9, v2, neg(0) op_sel_hi:[1,0,0]         // 000000B67E50: CC200002 8A020509
	v_fma_mix_f32 v4, v9, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B67E58: CC200804 8A020909
	.long 0x7f12398c                                           // 000000B67E60: 7F12398C
	v_fma_mix_f32 v5, v8, v5, neg(0) op_sel_hi:[1,0,0]         // 000000B67E64: CC200005 8A020B08
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B67E6C: BF870214
	.long 0x7e0e3982                                           // 000000B67E70: 7E0E3982
	.long 0x7e123984                                           // 000000B67E74: 7E123984
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000B67E78: BF8701B2
	v_and_b32_e32 v7, 1, v7                                    // 000000B67E7C: 360E0E81
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000B67E80: 7E1602FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000B67E88: D5010006 20020D06
	v_add3_u32 v2, v2, v7, 0x7fff                              // 000000B67E90: D6550002 03FE0F02 00007FFF
	v_bfe_u32 v7, v5, 16, 1                                    // 000000B67E9C: D6100007 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B67EA4: BF870093
	v_add_f32_e32 v6, v6, v11                                  // 000000B67EA8: 060C1706
	v_mov_b32_e32 v10, v6                                      // 000000B67EAC: 7E140306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000B67EB0: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B67EB8: BF870092
	v_permlanex16_b32 v10, v10, s3, 0xfedcba98                 // 000000B67EBC: D65C000A 03FC070A FEDCBA98
	v_add_f32_e32 v6, v6, v10                                  // 000000B67EC8: 060C1506
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000B67ECC: BF870091
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000B67ED0: 100C0CFF 3DB504F3
	v_fma_mix_f32 v6, v8, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000B67ED8: CC200806 8A020D08
	v_and_b32_e32 v8, 1, v9                                    // 000000B67EE0: 36101281
	.long 0x7e123982                                           // 000000B67EE4: 7E123982
	v_add3_u32 v2, v5, v7, 0x7fff                              // 000000B67EE8: D6550002 03FE0F05 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000B67EF4: BF870214
	v_bfe_u32 v10, v6, 16, 1                                   // 000000B67EF8: D610000A 02052106
	v_add3_u32 v4, v4, v8, 0x7fff                              // 000000B67F00: D6550004 03FE1104 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000B67F0C: BF870193
	.long 0x7e183982                                           // 000000B67F10: 7E183982
	v_add3_u32 v5, v6, v10, 0x7fff                             // 000000B67F14: D6550005 03FE1506 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000B67F20: BF8701A3
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000B67F24: 360808FF FFFF0000
	v_and_b32_e32 v6, 0xffff, v9                               // 000000B67F2C: 360C12FF 0000FFFF
	v_and_or_b32 v2, 0xffff0000, v5, v12                       // 000000B67F34: D6570002 04320AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000B67F40: BF870002
	v_or_b32_e32 v3, v4, v6                                    // 000000B67F44: 38060D04
	global_store_b64 v[0:1], v[2:3], off                       // 000000B67F48: DC6E0000 007C0200
	s_or_b32 exec_lo, exec_lo, s5                              // 000000B67F50: 8C7E057E
	s_mov_b32 s3, -1                                           // 000000B67F54: BE8300C1
	s_waitcnt_vscnt null, 0x0                                  // 000000B67F58: BC7C0000
	s_barrier                                                  // 000000B67F5C: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000B67F60: 8B6A037E
	s_cbranch_vccz 2                                           // 000000B67F64: BFA30002 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi3ELi64ELi6ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xb670>
	buffer_gl0_inv                                             // 000000B67F68: E0AC0000 00000000
	s_endpgm                                                   // 000000B67F70: BFB00000
		...

