0000000000473900 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x3                                               // 000000473900: BF850003
	s_load_b256 s[20:27], s[0:1], null                         // 000000473904: F40C0500 F8000000
	s_load_b256 s[12:19], s[0:1], 0x20                         // 00000047390C: F40C0300 F8000020
	s_load_b128 s[28:31], s[0:1], 0x40                         // 000000473914: F4080700 F8000040
	s_load_b32 s33, s[0:1], 0x54                               // 00000047391C: F4000840 F8000054
	v_and_b32_e32 v10, 31, v0                                  // 000000473924: 3614009F
	v_lshrrev_b32_e32 v8, 5, v0                                // 000000473928: 32100085
	s_mov_b32 s4, s3                                           // 00000047392C: BE840003
	s_mov_b32 s10, exec_lo                                     // 000000473930: BE8A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000473934: BF870002
	v_lshlrev_b32_e32 v9, 2, v10                               // 000000473938: 30121482
	s_waitcnt lgkmcnt(0)                                       // 00000047393C: BF89FC07
	s_ashr_i32 s35, s25, 31                                    // 000000473940: 86239F19
	s_mul_i32 s34, s27, s3                                     // 000000473944: 9622031B
	s_lshr_b32 s0, s35, 25                                     // 000000473948: 85009923
	s_add_i32 s1, s34, s27                                     // 00000047394C: 81011B22
	s_add_i32 s0, s25, s0                                      // 000000473950: 81000019
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000473954: BF870499
	s_ashr_i32 s0, s0, 7                                       // 000000473958: 86008700
	s_min_i32 s0, s0, s1                                       // 00000047395C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000473960: BF870499
	s_sub_i32 s11, s0, s34                                     // 000000473964: 818B2200
	.long 0xd4c4007e                                           // 000000473968: D4C4007E
	v_cndmask_b32_e32 v1, s11, v8, vcc_lo                      // 00000047396C: 0202100B
	s_cbranch_execz 501                                        // 000000473970: BFA501F5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x848>
	s_add_i32 s27, s24, -1                                     // 000000473974: 811BC118
	s_cmp_lg_u64 s[30:31], 0                                   // 000000473978: BF11801E
	v_dual_mov_b32 v11, v8 :: v_dual_and_b32 v2, 2, v0         // 00000047397C: CA240108 0B020082
	s_cselect_b32 s36, -1, 0                                   // 000000473984: 982480C1
	s_abs_i32 s37, s11                                         // 000000473988: BEA5150B
	v_lshlrev_b32_e32 v6, 3, v10                               // 00000047398C: 300C1483
	s_cvt_f32_u32 s0, s37                                      // 000000473990: BE806525
	v_and_b32_e32 v1, 1, v0                                    // 000000473994: 36020081
	v_and_b32_e32 v4, 4, v0                                    // 000000473998: 36080084
	v_and_b32_e32 v5, 8, v0                                    // 00000047399C: 360A0088
	v_rcp_iflag_f32_e32 v3, s0                                 // 0000004739A0: 7E065600
	v_add_nc_u32_e32 v7, s34, v8                               // 0000004739A4: 4A0E1022
	.long 0xd44a0003                                           // 0000004739A8: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000004739AC: 02020480
	v_lshl_or_b32 v2, v8, 8, v6                                // 0000004739B0: D6560002 04191108
	s_ashr_i32 s41, s11, 31                                    // 0000004739B8: 86299F0B
	s_sub_i32 s9, 0, s37                                       // 0000004739BC: 81892580
	s_mul_i32 s43, s41, 0x1400                                 // 0000004739C0: 962BFF29 00001400
	.long 0xd44c0000                                           // 0000004739C8: D44C0000
	v_cndmask_b32_e32 v1, 16, v10, vcc_lo                      // 0000004739CC: 02021490
	.long 0xd44a0001                                           // 0000004739D0: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000004739D4: 02020280
	.long 0xd44a0006                                           // 0000004739D8: D44A0006
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000004739DC: 02020A80
	v_readfirstlane_b32 s5, v3                                 // 0000004739E0: 7E0A0503
	v_lshl_or_b32 v1, v7, 7, v9                                // 0000004739E4: D6560001 04250F07
	v_subrev_nc_u32_e32 v12, s43, v2                           // 0000004739EC: 4E18042B
	s_lshl_b32 s7, s11, 7                                      // 0000004739F0: 8407870B
	s_mov_b32 s38, s25                                         // 0000004739F4: BEA60019
	s_mul_f32 s8, s5, 0x4f7ffffe                               // 0000004739F8: A208FF05 4F7FFFFE
	.long 0xd44a0005                                           // 000000473A00: D44A0005
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000473A04: 02020880
	s_mov_b32 s39, 0                                           // 000000473A08: BEA70080
	s_mov_b32 s40, 0x76543210                                  // 000000473A0C: BEA800FF 76543210
	s_cvt_u32_f32 s8, s8                                       // 000000473A14: BE886708
	s_lshl_b32 s42, s11, 8                                     // 000000473A18: 842A880B
	s_sub_i32 s43, 0, s7                                       // 000000473A1C: 81AB0780
	s_mov_b32 s45, 0x3db504f3                                  // 000000473A20: BEAD00FF 3DB504F3
	s_mul_i32 s9, s9, s8                                       // 000000473A28: 96090809
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000473A2C: BF870499
	s_mul_hi_u32 s9, s8, s9                                    // 000000473A30: 96890908
	s_add_i32 s44, s8, s9                                      // 000000473A34: 812C0908
	s_branch 164                                               // 000000473A38: BFA000A4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3cc>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000473A3C: BF870091
	.long 0xd7006a02                                           // 000000473A40: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000473A44: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000473A48: D5207C03 01AA060D
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000473A50: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000473A58: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000473A60: BF8903F7
	v_fma_mix_f32 v5, v17, v2, v15 op_sel_hi:[0,1,0]           // 000000473A64: CC200005 143E0511
	v_sub_f32_e32 v4, v18, v16                                 // 000000473A6C: 08082112
	v_fma_mix_f32 v2, -v17, v2, v15 op_sel_hi:[0,1,0]          // 000000473A70: CC200002 343E0511
	v_add_f32_e32 v3, v18, v16                                 // 000000473A78: 06062112
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000473A7C: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000473A80: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000473A84: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000473A88: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000473A8C: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000473A90: BF870193
	v_mov_b32_dpp v16, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000473A94: 7E2002FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000473A9C: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000473AA4: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000473AAC: D5010002 20060502
	v_mov_b32_dpp v15, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000473AB4: 7E1E02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000473ABC: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000473AC4: BF870144
	v_add_f32_e32 v4, v6, v4                                   // 000000473AC8: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000473ACC: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000473AD4: D5010007 20060F07
	.long 0xd72c0006                                           // 000000473ADC: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v14, vcc_lo                  // 000000473AE0: 02021CFF 00001400
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v5, v7, v5    // 000000473AE8: C9082102 02040B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000473AF0: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000473AF8: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000473B00: BF8701C3
	v_mov_b32_dpp v16, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000473B04: 7E2002FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000473B0C: D5010002 200E0502
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000473B14: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000473B1C: D5010005 200E0B05
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 000000473B24: C9081F03 03022102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000473B2C: BF870112
	v_add_f32_e32 v5, v5, v14                                  // 000000473B30: 060A1D05
	v_mov_b32_dpp v15, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000473B34: 7E1E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000473B3C: D5010003 200E0703
	s_delay_alu instid0(VALU_DEP_4)                            // 000000473B44: BF870004
	v_mov_b32_dpp v16, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000473B48: 7E2002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000473B50: D5010002 20160502
	v_mov_b32_dpp v14, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000473B58: 7E1C02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000473B60: D5010005 20160B05
	v_add_f32_e32 v4, v4, v7                                   // 000000473B68: 06080F04
	.long 0xd72c0007                                           // 000000473B6C: D72C0007
	v_cndmask_b32_e32 v1, s42, v13, vcc_lo                     // 000000473B70: 02021A2A
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_nc_u32 v11, 8, v11// 000000473B74: C9202102 020A1688
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000473B7C: BF870214
	v_add_f32_e32 v5, v5, v14                                  // 000000473B80: 060A1D05
	v_mov_b32_dpp v13, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000473B84: 7E1A02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000473B8C: D5010004 20160904
	v_add_f32_e32 v3, v3, v15                                  // 000000473B94: 06061F03
	v_mov_b32_dpp v16, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000473B98: 7E2002FA FF016802
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000473BA0: 7E1C02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 000000473BA8: D5010005 201A0B05
	v_add_f32_e32 v4, v4, v13                                  // 000000473BB0: 06081B04
	v_mov_b32_dpp v15, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000473BB4: 7E1E02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000473BBC: D5010003 20160703
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 000000473BC4: D5010002 201A0502
	v_add_f32_e32 v5, v5, v14                                  // 000000473BCC: 060A1D05
	v_mov_b32_dpp v13, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000473BD0: 7E1A02FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 000000473BD8: D5010004 201A0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000473BE0: BF870214
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 000000473BE4: C9081F03 03022102
	v_mov_b32_e32 v14, v5                                      // 000000473BEC: 7E1C0305
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000473BF0: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000473BF8: BF870214
	v_add_f32_e32 v4, v4, v13                                  // 000000473BFC: 06081B04
	v_mov_b32_dpp v15, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000473C00: 7E1E02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000473C08: D5010003 201A0703
	v_mov_b32_e32 v16, v2                                      // 000000473C10: 7E200302
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000473C14: D5010002 20020502
	v_mov_b32_e32 v13, v4                                      // 000000473C1C: 7E1A0304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000473C20: D5010004 20020904
	v_add_f32_e32 v3, v3, v15                                  // 000000473C28: 06061F03
	v_permlanex16_b32 v14, v14, s40, 0xfedcba98                // 000000473C2C: D65C000E 03FC510E FEDCBA98
	v_permlanex16_b32 v16, v16, s40, 0xfedcba98                // 000000473C38: D65C0010 03FC5110 FEDCBA98
	v_permlanex16_b32 v13, v13, s40, 0xfedcba98                // 000000473C44: D65C000D 03FC510D FEDCBA98
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000473C50: 4C0C0F06
	v_mov_b32_e32 v15, v3                                      // 000000473C54: 7E1E0303
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000473C58: D5010003 20020703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000473C60: BF870214
	v_dual_add_f32 v5, v5, v14 :: v_dual_add_f32 v4, v4, v13   // 000000473C64: C9081D05 05041B04
	v_dual_add_f32 v7, v2, v16 :: v_dual_add_nc_u32 v6, v12, v6// 000000473C6C: C9202102 07060D0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000473C74: BF870224
	v_permlanex16_b32 v15, v15, s40, 0xfedcba98                // 000000473C78: D65C000F 03FC510F FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s11, v11                          // 000000473C84: 7C86160B
	v_fma_mixlo_f16 v2, v4, s45, 0                             // 000000473C88: CC210002 02005B04
	v_add_nc_u32_e32 v12, 0x800, v12                           // 000000473C90: 4A1818FF 00000800
	v_fma_mixhi_f16 v2, v5, s45, 0                             // 000000473C98: CC220002 02005B05
	v_add_f32_e32 v13, v3, v15                                 // 000000473CA0: 061A1F03
	v_fma_mixhi_f16 v3, v7, s45, 0                             // 000000473CA4: CC220003 02005B07
	s_or_b32 s39, vcc_lo, s39                                  // 000000473CAC: 8C27276A
	s_delay_alu instid0(VALU_DEP_2)                            // 000000473CB0: BF870002
	v_fma_mixlo_f16 v3, v13, s45, 0                            // 000000473CB4: CC210003 02005B0D
	ds_store_b64 v6, v[2:3]                                    // 000000473CBC: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s39                       // 000000473CC4: 917E277E
	s_cbranch_execz 287                                        // 000000473CC8: BFA5011F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x848>
	.long 0xd72d0002                                           // 000000473CCC: D72D0002
	v_cndmask_b32_e32 v0, v11, v44, vcc_lo                     // 000000473CD0: 0200590B
	s_mov_b32 s7, -1                                           // 000000473CD4: BE8700C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000473CD8: BF870091
	.long 0xd72c0003                                           // 000000473CDC: D72C0003
	v_cndmask_b32_e32 v0, v2, v37, vcc_lo                      // 000000473CE0: 02004B02
	v_sub_nc_u32_e32 v3, v11, v3                               // 000000473CE4: 4C06070B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000473CE8: BF870121
	v_subrev_nc_u32_e32 v5, s37, v3                            // 000000473CEC: 4E0A0625
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000473CF0: 7C960625
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000473CF4: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000473CFC: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000473D00: 02040902
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000473D04: 7C960625
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000473D08: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000473D0C: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000473D10: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s36                        // 000000473D14: 916A247E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000473D18: BF870091
	v_xor_b32_e32 v14, s41, v2                                 // 000000473D1C: 3A1C0429
	v_subrev_nc_u32_e32 v13, s41, v14                          // 000000473D20: 4E1A1C29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000473D24: BF8700A1
	v_mad_u64_u32 v[6:7], null, s43, v13, v[1:2]               // 000000473D28: D6FE7C06 04061A2B
	v_min_i32_e32 v2, s27, v13                                 // 000000473D30: 22041A1B
	v_mad_i64_i32 v[4:5], null, v2, s38, 0                     // 000000473D34: D6FF7C04 02004D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000473D3C: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000473D40: 340E0C9F
	.long 0xd73c0002                                           // 000000473D44: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000473D48: 02020C81
	s_cbranch_vccnz 210                                        // 000000473D4C: BFA400D2 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x798>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000473D50: BF870093
	.long 0xd7006a06                                           // 000000473D54: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000473D58: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000473D5C: D5207C07 01AA0F05
	.long 0x7f3e3880                                           // 000000473D64: 7F3E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000473D68: BF870112
	.long 0xd73c0006                                           // 000000473D6C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000473D70: 02020C81
	.long 0x7f44399f                                           // 000000473D74: 7F44399F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000473D78: BF870092
	.long 0xd7006a0f                                           // 000000473D7C: D7006A0F
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 000000473D80: 02020C16
	v_add_co_ci_u32_e64 v16, null, s23, v7, vcc_lo             // 000000473D84: D5207C10 01AA0E17
	.long 0xd7006a06                                           // 000000473D8C: D7006A06
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000473D90: 02020C1E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000473D94: BF870001
	v_add_co_ci_u32_e64 v7, null, s31, v7, vcc_lo              // 000000473D98: D5207C07 01AA0E1F
	global_load_b64 v[15:16], v[15:16], off                    // 000000473DA0: DC560000 0F7C000F
	.long 0xd7006a11                                           // 000000473DA8: D7006A11
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000473DAC: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 000000473DB0: DC560000 067C0006
	v_add_co_ci_u32_e64 v18, null, s13, v3, vcc_lo             // 000000473DB8: D5207C12 01AA060D
	s_clause 0x1                                               // 000000473DC0: BF850001
	global_load_b32 v19, v[17:18], off                         // 000000473DC4: DC520000 137C0011
	global_load_d16_b16 v17, v[17:18], off offset:4            // 000000473DCC: DC820004 117C0011
	s_waitcnt vmcnt(3)                                         // 000000473DD4: BF890FF7
	.long 0x7e24390f                                           // 000000473DD8: 7E24390F
	s_waitcnt vmcnt(2)                                         // 000000473DDC: BF890BF7
	v_and_b32_e32 v41, 0xffff0000, v6                          // 000000473DE0: 36520CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000473DE8: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000473DEC: BF870093
	v_lshlrev_b32_e32 v18, 16, v18                             // 000000473DF0: 30242490
	v_mul_f32_e32 v22, 0xbfb8aa3b, v18                         // 000000473DF4: 102C24FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000473DFC: BF870291
	v_exp_f32_e32 v22, v22                                     // 000000473E00: 7E2C4B16
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_and_b32 v15, 0xffff0000, v15// 000000473E04: C9242CF2 160E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000473E10: BF870111
	v_mul_f32_e32 v21, 0xbfb8aa3b, v15                         // 000000473E14: 102A1EFF BFB8AA3B
	v_div_scale_f32 v26, null, v22, v22, v18                   // 000000473E1C: D6FC7C1A 044A2D16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000473E24: BF8701B2
	v_exp_f32_e32 v21, v21                                     // 000000473E28: 7E2A4B15
	v_lshlrev_b32_e32 v20, 16, v16                             // 000000473E2C: 30282090
	v_div_scale_f32 v39, s8, v18, v22, v18                     // 000000473E30: D6FC0827 044A2D12
	v_rcp_f32_e32 v30, v26                                     // 000000473E38: 7E3C551A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000473E3C: BF870196
	v_add_f32_e32 v21, 1.0, v21                                // 000000473E40: 062A2AF2
	v_mul_f32_e32 v23, 0xbfb8aa3b, v20                         // 000000473E44: 102E28FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000473E4C: BF870195
	v_fma_f32 v38, -v26, v30, 1.0                              // 000000473E50: D6130026 23CA3D1A
	v_div_scale_f32 v25, null, v21, v21, v15                   // 000000473E58: D6FC7C19 043E2B15
	s_delay_alu instid0(VALU_DEP_3)                            // 000000473E60: BF870003
	v_exp_f32_e32 v23, v23                                     // 000000473E64: 7E2E4B17
	v_and_b32_e32 v16, 0xffff0000, v16                         // 000000473E68: 362020FF FFFF0000
	v_div_scale_f32 v35, vcc_lo, v15, v21, v15                 // 000000473E70: D6FC6A23 043E2B0F
	v_fmac_f32_e32 v30, v38, v30                               // 000000473E78: 563C3D26
	v_rcp_f32_e32 v28, v25                                     // 000000473E7C: 7E385519
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000473E80: BF870186
	v_dual_add_f32 v23, 1.0, v23 :: v_dual_mul_f32 v24, 0xbfb8aa3b, v16// 000000473E84: C9062EF2 171820FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000473E90: BF870115
	v_fma_f32 v36, -v25, v28, 1.0                              // 000000473E94: D6130024 23CA3919
	v_div_scale_f32 v27, null, v23, v23, v20                   // 000000473E9C: D6FC7C1B 04522F17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000473EA4: BF8701A3
	v_exp_f32_e32 v24, v24                                     // 000000473EA8: 7E304B18
	v_div_scale_f32 v37, s7, v20, v23, v20                     // 000000473EAC: D6FC0725 04522F14
	v_fmac_f32_e32 v28, v36, v28                               // 000000473EB4: 56383924
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000473EB8: BF870313
	v_rcp_f32_e32 v32, v27                                     // 000000473EBC: 7E40551B
	v_add_f32_e32 v24, 1.0, v24                                // 000000473EC0: 063030F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000473EC4: BF870115
	v_fma_f32 v40, -v27, v32, 1.0                              // 000000473EC8: D6130028 23CA411B
	v_div_scale_f32 v29, null, v24, v24, v16                   // 000000473ED0: D6FC7C1D 04423118
	v_div_scale_f32 v38, s9, v16, v24, v16                     // 000000473ED8: D6FC0926 04423110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000473EE0: BF870193
	v_fmac_f32_e32 v32, v40, v32                               // 000000473EE4: 56404128
	v_rcp_f32_e32 v33, v29                                     // 000000473EE8: 7E42551D
	v_mul_f32_e32 v40, v35, v28                                // 000000473EEC: 10503923
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000473EF0: BF870112
	v_mul_f32_e32 v42, v37, v32                                // 000000473EF4: 10544125
	v_fma_f32 v43, -v25, v40, v35                              // 000000473EF8: D613002B 248E5119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000473F00: BF870292
	v_fma_f32 v46, -v27, v42, v37                              // 000000473F04: D613002E 2496551B
	v_fma_f32 v36, -v29, v33, 1.0                              // 000000473F0C: D6130024 23CA431D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000473F14: BF870113
	v_fmac_f32_e32 v40, v43, v28                               // 000000473F18: 5650392B
	v_dual_fmac_f32 v42, v46, v32 :: v_dual_fmac_f32 v33, v36, v33// 000000473F1C: C800412E 2A204324
	v_mul_f32_e32 v36, v39, v30                                // 000000473F24: 10483D27
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000473F28: BF870193
	v_fma_f32 v25, -v25, v40, v35                              // 000000473F2C: D6130019 248E5119
	v_fma_f32 v27, -v27, v42, v37                              // 000000473F34: D613001B 2496551B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000473F3C: BF870214
	v_mul_f32_e32 v44, v38, v33                                // 000000473F40: 10584326
	v_fma_f32 v45, -v26, v36, v39                              // 000000473F44: D613002D 249E491A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000473F4C: BF8701A4
	v_div_fmas_f32 v25, v25, v28, v40                          // 000000473F50: D6370019 04A23919
	s_mov_b32 vcc_lo, s8                                       // 000000473F58: BEEA0008
	v_fma_f32 v43, -v29, v44, v38                              // 000000473F5C: D613002B 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000473F64: BF870193
	v_fmac_f32_e32 v36, v45, v30                               // 000000473F68: 56483D2D
	v_div_fixup_f32 v15, v25, v21, v15                         // 000000473F6C: D627000F 043E2B19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000473F74: BF870193
	v_fmac_f32_e32 v44, v43, v33                               // 000000473F78: 5658432B
	v_fma_f32 v26, -v26, v36, v39                              // 000000473F7C: D613001A 249E491A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000473F84: BF870193
	v_mul_f32_e32 v15, v15, v41                                // 000000473F88: 101E530F
	v_fma_f32 v25, -v29, v44, v38                              // 000000473F8C: D6130019 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000473F94: BF8701A3
	v_div_fmas_f32 v26, v26, v30, v36                          // 000000473F98: D637001A 04923D1A
	s_mov_b32 vcc_lo, s7                                       // 000000473FA0: BEEA0007
	.long 0x7e3e398f                                           // 000000473FA4: 7E3E398F
	v_div_fmas_f32 v21, v27, v32, v42                          // 000000473FA8: D6370015 04AA411B
	s_mov_b32 vcc_lo, s9                                       // 000000473FB0: BEEA0009
	v_div_fixup_f32 v18, v26, v22, v18                         // 000000473FB4: D6270012 044A2D1A
	v_lshlrev_b32_e32 v22, 16, v7                              // 000000473FBC: 302C0E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000473FC0: 360E0EFF FFFF0000
	v_div_fixup_f32 v20, v21, v23, v20                         // 000000473FC8: D6270014 04522F15
	s_mov_b32 s7, 0                                            // 000000473FD0: BE870080
	v_mul_f32_e32 v6, v18, v6                                  // 000000473FD4: 100C0D12
	v_div_fmas_f32 v18, v25, v33, v44                          // 000000473FD8: D6370012 04B24319
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000473FE0: BF870193
	v_mul_f32_e32 v20, v20, v22                                // 000000473FE4: 10282D14
	.long 0x7e443986                                           // 000000473FE8: 7E443986
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000473FEC: BF870223
	v_div_fixup_f32 v16, v18, v24, v16                         // 000000473FF0: D6270010 04423112
	v_and_b32_e32 v18, 1, v31                                  // 000000473FF8: 36243E81
	v_bfe_u32 v21, v20, 16, 1                                  // 000000473FFC: D6100015 02052114
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000474004: BF870193
	v_dual_mul_f32 v7, v16, v7 :: v_dual_and_b32 v22, 1, v34   // 000000474008: C8E40F10 07164481
	v_add3_u32 v15, v15, v18, 0x7fff                           // 000000474010: D655000F 03FE250F 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047401C: BF870193
	v_add3_u32 v16, v20, v21, 0x7fff                           // 000000474020: D6550010 03FE2B14 00007FFF
	v_add3_u32 v6, v6, v22, 0x7fff                             // 00000047402C: D6550006 03FE2D06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000474038: BF870214
	v_bfe_u32 v18, v7, 16, 1                                   // 00000047403C: D6100012 02052107
	v_and_b32_e32 v15, 0xffff0000, v15                         // 000000474044: 361E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047404C: BF870214
	v_and_b32_e32 v20, 0xffff0000, v16                         // 000000474050: 362820FF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000474058: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000474060: BF870004
	v_add3_u32 v7, v7, v18, 0x7fff                             // 000000474064: D6550007 03FE2507 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000474070: BF8907F7
	v_fma_mix_f32 v16, v19, v15, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000474074: CC200810 8A021F13
	s_waitcnt vmcnt(0)                                         // 00000047407C: BF8903F7
	v_fma_mix_f32 v15, v17, v20, neg(0) op_sel_hi:[1,0,0]      // 000000474080: CC20000F 8A022911
	v_fma_mix_f32 v18, v19, v6, neg(0) op_sel_hi:[1,0,0]       // 000000474088: CC200012 8A020D13
	v_and_b32_e32 v17, 0xffff0000, v7                          // 000000474090: 36220EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 000000474098: 916A077E
	s_cbranch_vccnz 65127                                      // 00000047409C: BFA4FE67 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x13c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004740A0: BF870093
	.long 0xd73c0004                                           // 0000004740A4: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000004740A8: 02020881
	.long 0xd7006a04                                           // 0000004740AC: D7006A04
	v_cndmask_b32_e32 v1, s22, v4, vcc_lo                      // 0000004740B0: 02020816
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004740B4: BF870111
	v_add_co_ci_u32_e64 v5, null, s23, v5, vcc_lo              // 0000004740B8: D5207C05 01AA0A17
	.long 0xd7006a04                                           // 0000004740C0: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000004740C4: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004740C8: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000004740CC: D5207C05 01AA0705
	.long 0xd7006a06                                           // 0000004740D4: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000004740D8: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 0000004740DC: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 0000004740E4: DC560000 047C0004
	s_clause 0x1                                               // 0000004740EC: BF850001
	global_load_b32 v17, v[6:7], off                           // 0000004740F0: DC520000 117C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 0000004740F8: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000474100: BF890BF7
	.long 0x7e0e3904                                           // 000000474104: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000474108: 360808FF FFFF0000
	v_lshlrev_b32_e32 v15, 16, v5                              // 000000474110: 301E0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000474114: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000474118: 300E0E90
	s_waitcnt vmcnt(1)                                         // 00000047411C: BF8907F7
	v_fma_mix_f32 v16, v17, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000474120: CC200810 8A020911
	s_waitcnt vmcnt(0)                                         // 000000474128: BF8903F7
	v_fma_mix_f32 v15, v6, v15, neg(0) op_sel_hi:[1,0,0]       // 00000047412C: CC20000F 8A021F06
	v_fma_mix_f32 v18, v17, v7, neg(0) op_sel_hi:[1,0,0]       // 000000474134: CC200012 8A020F11
	v_and_b32_e32 v17, 0xffff0000, v5                          // 00000047413C: 36220AFF FFFF0000
	s_branch 65085                                             // 000000474144: BFA0FE3D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x13c>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000474148: 8C7E0A7E
	s_bfe_i32 s10, s11, 0x1001c                                // 00000047414C: 938AFF0B 0001001C
	s_lshl_b32 s3, s11, 3                                      // 000000474154: 8403830B
	s_lshr_b64 s[0:1], s[10:11], 29                            // 000000474158: 85809D0A
	s_lshr_b32 s1, s35, 28                                     // 00000047415C: 85019C23
	s_add_i32 s0, s0, 7                                        // 000000474160: 81008700
	s_add_i32 s1, s25, s1                                      // 000000474164: 81010119
	s_ashr_i32 s0, s0, 3                                       // 000000474168: 86008300
	s_waitcnt lgkmcnt(0)                                       // 00000047416C: BF89FC07
	.long 0xd72c0001                                           // 000000474170: D72C0001
	v_cndmask_b32_e32 v1, s0, v8, vcc_lo                       // 000000474174: 02021000
	s_barrier                                                  // 000000474178: BFBD0000
	buffer_gl0_inv                                             // 00000047417C: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 000000474184: 4A040200
	s_ashr_i32 s0, s1, 4                                       // 000000474188: 86008401
	s_lshl_b32 s1, s34, 3                                      // 00000047418C: 84018322
	s_mul_hi_i32 s5, s0, s2                                    // 000000474190: 97050200
	s_mul_i32 s0, s0, s2                                       // 000000474194: 96000200
	v_min_i32_e32 v7, s3, v2                                   // 000000474198: 220E0403
	s_ashr_i32 s3, s1, 31                                      // 00000047419C: 86039F01
	s_add_u32 s0, s0, s1                                       // 0000004741A0: 80000100
	s_addc_u32 s1, s5, s3                                      // 0000004741A4: 82010305
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004741A8: BF870009
	s_lshl_b64 s[6:7], s[0:1], 10                              // 0000004741AC: 84868A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v7                            // 0000004741B0: 7C820F01
	s_add_u32 s1, s20, s6                                      // 0000004741B4: 80010614
	s_addc_u32 s5, s21, s7                                     // 0000004741B8: 82050715
	s_and_saveexec_b32 s3, vcc_lo                              // 0000004741BC: BE83206A
	s_cbranch_execz 93                                         // 0000004741C0: BFA5005D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xa38>
	.long 0xd7010002                                           // 0000004741C4: D7010002
	v_cndmask_b32_e32 v0, v10, v129, vcc_lo                    // 0000004741C8: 0201030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004741CC: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 0000004741D0: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000004741D8: 3404029F
	.long 0xd44c0000                                           // 0000004741DC: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 0000004741E0: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004741E4: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 0000004741E8: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v11, v5, v3      // 0000004741F4: CA200080 040A0705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004741FC: BF870114
	.long 0xd73c0005                                           // 000000474200: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000474204: 0202028A
	.long 0xd73c0002                                           // 000000474208: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000047420C: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000474210: BF870223
	v_lshlrev_b32_e32 v4, 24, v11                              // 000000474214: 30081698
	v_bfe_i32 v12, v11, 7, 1                                   // 000000474218: D611000C 02050F0B
	.long 0xd700000d                                           // 000000474220: D700000D
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000474224: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000474228: BF870211
	v_add_co_ci_u32_e64 v6, null, s5, v6, s0                   // 00000047422C: D5207C06 00020C05
	v_ashrrev_i32_e32 v11, 22, v4                              // 000000474234: 34160896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000474238: BF870093
	.long 0xd7000004                                           // 00000047423C: D7000004
	v_cndmask_b32_e32 v1, v13, v2, vcc_lo                      // 000000474240: 0202050D
	v_add_co_ci_u32_e64 v5, null, v6, v3, s0                   // 000000474244: D5207C05 00020706
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047424C: BF870093
	.long 0xd700000b                                           // 000000474250: D700000B
	v_cndmask_b32_e32 v1, v13, v11, vcc_lo                     // 000000474254: 0202170D
	v_add_co_ci_u32_e64 v12, null, v6, v12, s0                 // 000000474258: D5207C0C 00021906
	.long 0xd700000d                                           // 000000474260: D700000D
	v_cndmask_b32_e32 v1, v13, v9, vcc_lo                      // 000000474264: 0202130D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000474268: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v6, s0                   // 00000047426C: D5207C0E 00020C80
	s_clause 0x17                                              // 000000474274: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000474278: DC520000 027C0004
	global_load_b32 v56, v[4:5], off offset:128                // 000000474280: DC520080 387C0004
	global_load_b32 v54, v[4:5], off offset:256                // 000000474288: DC520100 367C0004
	global_load_b32 v50, v[4:5], off offset:384                // 000000474290: DC520180 327C0004
	global_load_b32 v48, v[4:5], off offset:512                // 000000474298: DC520200 307C0004
	global_load_b32 v45, v[4:5], off offset:640                // 0000004742A0: DC520280 2D7C0004
	global_load_b32 v42, v[4:5], off offset:768                // 0000004742A8: DC520300 2A7C0004
	global_load_b32 v21, v[4:5], off offset:896                // 0000004742B0: DC520380 157C0004
	global_load_b32 v3, v[11:12], off                          // 0000004742B8: DC520000 037C000B
	global_load_b32 v58, v[11:12], off offset:128              // 0000004742C0: DC520080 3A7C000B
	global_load_b32 v55, v[11:12], off offset:256              // 0000004742C8: DC520100 377C000B
	global_load_b32 v52, v[11:12], off offset:384              // 0000004742D0: DC520180 347C000B
	global_load_b32 v49, v[11:12], off offset:512              // 0000004742D8: DC520200 317C000B
	global_load_b32 v46, v[11:12], off offset:640              // 0000004742E0: DC520280 2E7C000B
	global_load_b32 v43, v[11:12], off offset:768              // 0000004742E8: DC520300 2B7C000B
	global_load_b32 v23, v[11:12], off offset:896              // 0000004742F0: DC520380 177C000B
	global_load_b32 v59, v[13:14], off                         // 0000004742F8: DC520000 3B7C000D
	global_load_b32 v57, v[13:14], off offset:128              // 000000474300: DC520080 397C000D
	global_load_b32 v53, v[13:14], off offset:256              // 000000474308: DC520100 357C000D
	global_load_b32 v51, v[13:14], off offset:384              // 000000474310: DC520180 337C000D
	global_load_b32 v47, v[13:14], off offset:512              // 000000474318: DC520200 2F7C000D
	global_load_b32 v44, v[13:14], off offset:640              // 000000474320: DC520280 2C7C000D
	global_load_b32 v26, v[13:14], off offset:768              // 000000474328: DC520300 1A7C000D
	global_load_b32 v19, v[13:14], off offset:896              // 000000474330: DC520380 137C000D
	s_or_b32 exec_lo, exec_lo, s3                              // 000000474338: 8C7E037E
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 00000047433C: CA100080 0B0C0080
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v14, 0             // 000000474344: CA100080 0D0E0080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 00000047434C: CA100080 0F100080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v18, 0             // 000000474354: CA100080 11120080
	s_ashr_i32 s3, s2, 31                                      // 00000047435C: 86039F02
	s_and_saveexec_b32 s0, vcc_lo                              // 000000474360: BE80206A
	s_cbranch_execz 997                                        // 000000474364: BFA503E5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x19fc>
	v_dual_mov_b32 v11, 0 :: v_dual_add_nc_u32 v4, -1, v0      // 000000474368: CA200080 0B0400C1
	v_dual_mov_b32 v13, 0 :: v_dual_and_b32 v6, 16, v0         // 000000474370: CA240080 0D060090
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v5, 1, v1       // 000000474378: CA200080 0C040281
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000474380: BF870243
	v_dual_mov_b32 v15, 0 :: v_dual_and_b32 v4, 31, v4         // 000000474384: CA240080 0F04089F
	v_sub_nc_u32_e32 v20, 0, v7                                // 00000047438C: 4C280E80
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v22, 2, v10    // 000000474390: CA220080 11161482
	v_lshl_or_b32 v24, v1, 5, v6                               // 000000474398: D6560018 04190B01
	v_dual_mov_b32 v14, 0 :: v_dual_lshlrev_b32 v25, 2, v4     // 0000004743A0: CA220080 0E180882
	v_mov_b32_e32 v16, 0                                       // 0000004743A8: 7E200280
	v_mov_b32_e32 v18, 0                                       // 0000004743AC: 7E240280
	s_mov_b32 s6, 0                                            // 0000004743B0: BE860080
	s_mov_b32 s7, 0xdcd12d                                     // 0000004743B4: BE8700FF 00DCD12D
	s_movk_i32 s8, 0x83                                        // 0000004743BC: B0080083
	s_movk_i32 s9, 0x1eee                                      // 0000004743C0: B0091EEE
	s_branch 916                                               // 0000004743C4: BFA00394 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1918>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000004743C8: 8C7E0A7E
	s_waitcnt vmcnt(15)                                        // 0000004743CC: BF893FF7
	v_alignbit_b32 v60, v2, v3, 16                             // 0000004743D0: D616003C 02420702
	s_waitcnt vmcnt(7)                                         // 0000004743D8: BF891FF7
	v_bfe_u32 v61, v59, 12, 16                                 // 0000004743DC: D610003D 0241193B
	ds_load_b128 v[1:4], v24                                   // 0000004743E4: DBFC0000 01000018
	v_alignbit_b32 v56, v56, v58, 16                           // 0000004743EC: D6160038 02427538
	v_bfe_u32 v62, v59, 8, 16                                  // 0000004743F4: D610003E 0241113B
	v_bfe_u32 v63, v60, 12, 16                                 // 0000004743FC: D610003F 0241193C
	v_bfe_u32 v65, v60, 8, 16                                  // 000000474404: D6100041 0241113C
	v_mul_u32_u24_e32 v67, s7, v63                             // 00000047440C: 16867E07
	v_mul_u32_u24_e32 v63, s8, v63                             // 000000474410: 167E7E08
	v_bfe_u32 v66, v60, 4, 16                                  // 000000474414: D6100042 0241093C
	v_lshl_add_u32 v63, v63, 24, v67                           // 00000047441C: D646003F 050D313F
	v_mul_u32_u24_e32 v67, s7, v65                             // 000000474424: 16868207
	v_mul_u32_u24_e32 v65, s8, v65                             // 000000474428: 16828208
	v_lshl_add_u32 v65, v65, 24, v67                           // 00000047442C: D6460041 050D3141
	v_mul_u32_u24_e32 v67, s7, v66                             // 000000474434: 16868407
	v_mul_u32_u24_e32 v66, s8, v66                             // 000000474438: 16848408
	v_lshl_add_u32 v66, v66, 24, v67                           // 00000047443C: D6460042 050D3142
	v_and_b32_e32 v60, 0xffff, v60                             // 000000474444: 367878FF 0000FFFF
	v_mul_u32_u24_e32 v67, s7, v61                             // 00000047444C: 16867A07
	v_mul_u32_u24_e32 v61, s8, v61                             // 000000474450: 167A7A08
	v_lshl_add_u32 v61, v61, 24, v67                           // 000000474454: D646003D 050D313D
	v_mul_u32_u24_e32 v67, s7, v60                             // 00000047445C: 16867807
	v_mul_u32_u24_e32 v60, s8, v60                             // 000000474460: 16787808
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000474464: D6220042 03FD0142 00006400
	v_lshl_add_u32 v60, v60, 24, v67                           // 000000474470: D646003C 050D313C
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000474478: D622003F 03FD013F 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000474484: D6220041 03FD0141 00006400
	v_mul_u32_u24_e32 v67, s7, v62                             // 000000474490: 16867C07
	v_and_b32_e32 v66, 0xffff, v66                             // 000000474494: 368484FF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000047449C: D622003C 03FD013C 00006400
	v_mul_u32_u24_e32 v62, s8, v62                             // 0000004744A8: 167C7C08
	v_bfe_u32 v64, v59, 4, 16                                  // 0000004744AC: D6100040 0241093B
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000004744B4: D622003D 03FD013D 00006400
	v_lshl_add_u32 v62, v62, 24, v67                           // 0000004744C0: D646003E 050D313E
	v_lshl_or_b32 v60, v60, 16, v66                            // 0000004744C8: D656003C 0509213C
	v_mul_u32_u24_e32 v67, s7, v64                             // 0000004744D0: 16868007
	v_mul_u32_u24_e32 v64, s8, v64                             // 0000004744D4: 16808008
	v_lshl_add_u32 v64, v64, 24, v67                           // 0000004744D8: D6460040 050D3140
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000004744E0: D622003E 03FD013E 00006400
	v_pk_fma_f16 v58, v60, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004744EC: CC0E003A 0BFC133C 0000C931
	v_and_b32_e32 v63, 0xffff, v63                             // 0000004744F8: 367E7EFF 0000FFFF
	s_waitcnt vmcnt(6)                                         // 000000474500: BF891BF7
	v_bfe_u32 v66, v57, 4, 16                                  // 000000474504: D6100042 02410939
	v_sad_u8 v64, v64, 0, 0x6400                               // 00000047450C: D6220040 03FD0140 00006400
	v_alignbit_b32 v54, v54, v55, 16                           // 000000474518: D6160036 02426F36
	v_alignbit_b32 v50, v50, v52, 16                           // 000000474520: D6160032 02426932
	v_lshl_or_b32 v63, v65, 16, v63                            // 000000474528: D656003F 04FD2141
	v_bfe_u32 v65, v57, 8, 16                                  // 000000474530: D6100041 02411139
	v_alignbit_b32 v48, v48, v49, 16                           // 000000474538: D6160030 02426330
	v_alignbit_b32 v45, v45, v46, 16                           // 000000474540: D616002D 02425D2D
	v_alignbit_b32 v42, v42, v43, 16                           // 000000474548: D616002A 0242572A
	v_pk_fma_f16 v63, v63, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474550: CC0E003F 0BFC133F 0000C931
	v_and_b32_e32 v59, 0xffff, v59                             // 00000047455C: 367676FF 0000FFFF
	v_alignbit_b32 v21, v21, v23, 16                           // 000000474564: D6160015 02422F15
	v_add_nc_u32_e32 v5, 1, v5                                 // 00000047456C: 4A0A0A81
	v_add_nc_u32_e32 v24, 32, v24                              // 000000474570: 4A3030A0
	s_waitcnt lgkmcnt(0)                                       // 000000474574: BF89FC07
	v_dot2acc_f32_f16 v18, v63, v1                             // 000000474578: 0424033F
	v_mul_u32_u24_e32 v67, s7, v59                             // 00000047457C: 16867607
	v_mul_u32_u24_e32 v59, s8, v59                             // 000000474580: 16767608
	v_lshl_add_u32 v59, v59, 24, v67                           // 000000474584: D646003B 050D313B
	v_bfe_u32 v63, v56, 4, 16                                  // 00000047458C: D610003F 02410938
	v_dual_dot2acc_f32_f16 v18, v58, v2 :: v_dual_and_b32 v61, 0xffff, v61// 000000474594: CB24053A 123C7AFF 0000FFFF
	v_bfe_u32 v58, v54, 12, 16                                 // 0000004745A0: D610003A 02411936
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004745A8: BF870194
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000004745AC: D622003B 03FD013B 00006400
	v_lshl_or_b32 v61, v62, 16, v61                            // 0000004745B8: D656003D 04F5213E
	v_and_b32_e32 v62, 0xffff, v64                             // 0000004745C0: 367C80FF 0000FFFF
	v_bfe_u32 v64, v57, 12, 16                                 // 0000004745C8: D6100040 02411939
	v_and_b32_e32 v57, 0xffff, v57                             // 0000004745D0: 367272FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000004745D8: BF8700C4
	v_pk_fma_f16 v60, v61, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004745DC: CC0E003C 0BFC133D 0000C931
	v_bfe_u32 v61, v56, 12, 16                                 // 0000004745E8: D610003D 02411938
	v_mul_u32_u24_e32 v67, s7, v61                             // 0000004745F0: 16867A07
	v_mul_u32_u24_e32 v61, s8, v61                             // 0000004745F4: 167A7A08
	v_lshl_add_u32 v61, v61, 24, v67                           // 0000004745F8: D646003D 050D313D
	v_lshl_or_b32 v59, v59, 16, v62                            // 000000474600: D656003B 04F9213B
	v_bfe_u32 v62, v56, 8, 16                                  // 000000474608: D610003E 02411138
	v_mul_u32_u24_e32 v67, s7, v63                             // 000000474610: 16867E07
	v_mul_u32_u24_e32 v63, s8, v63                             // 000000474614: 167E7E08
	v_lshl_add_u32 v63, v63, 24, v67                           // 000000474618: D646003F 050D313F
	v_mul_u32_u24_e32 v67, s7, v62                             // 000000474620: 16867C07
	v_mul_u32_u24_e32 v62, s8, v62                             // 000000474624: 167C7C08
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000474628: D622003D 03FD013D 00006400
	v_lshl_add_u32 v62, v62, 24, v67                           // 000000474634: D646003E 050D313E
	v_and_b32_e32 v56, 0xffff, v56                             // 00000047463C: 367070FF 0000FFFF
	v_mul_u32_u24_e32 v67, s7, v56                             // 000000474644: 16867007
	v_mul_u32_u24_e32 v56, s8, v56                             // 000000474648: 16707008
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047464C: BF870001
	v_lshl_add_u32 v56, v56, 24, v67                           // 000000474650: D6460038 050D3138
	v_mul_u32_u24_e32 v67, s7, v64                             // 000000474658: 16868007
	v_mul_u32_u24_e32 v64, s8, v64                             // 00000047465C: 16808008
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000474660: D622003F 03FD013F 00006400
	v_lshl_add_u32 v64, v64, 24, v67                           // 00000047466C: D6460040 050D3140
	v_and_b32_e32 v61, 0xffff, v61                             // 000000474674: 367A7AFF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000047467C: D622003E 03FD013E 00006400
	v_mul_u32_u24_e32 v67, s7, v65                             // 000000474688: 16868207
	v_mul_u32_u24_e32 v65, s8, v65                             // 00000047468C: 16828208
	v_and_b32_e32 v63, 0xffff, v63                             // 000000474690: 367E7EFF 0000FFFF
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000474698: D6220038 03FD0138 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000004746A4: D6220040 03FD0140 00006400
	v_lshl_add_u32 v65, v65, 24, v67                           // 0000004746B0: D6460041 050D3141
	v_lshl_or_b32 v61, v62, 16, v61                            // 0000004746B8: D656003D 04F5213E
	v_mul_u32_u24_e32 v67, s7, v66                             // 0000004746C0: 16868407
	v_mul_u32_u24_e32 v66, s8, v66                             // 0000004746C4: 16848408
	v_lshl_add_u32 v66, v66, 24, v67                           // 0000004746C8: D6460042 050D3142
	v_lshl_or_b32 v56, v56, 16, v63                            // 0000004746D0: D6560038 04FD2138
	v_and_b32_e32 v62, 0xffff, v64                             // 0000004746D8: 367C80FF 0000FFFF
	v_sad_u8 v63, v65, 0, 0x6400                               // 0000004746E0: D622003F 03FD0141 00006400
	v_pk_fma_f16 v61, v61, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004746EC: CC0E003D 0BFC133D 0000C931
	v_mul_u32_u24_e32 v65, s7, v57                             // 0000004746F8: 16827207
	v_mul_u32_u24_e32 v57, s8, v57                             // 0000004746FC: 16727208
	v_sad_u8 v64, v66, 0, 0x6400                               // 000000474700: D6220040 03FD0142 00006400
	v_lshl_add_u32 v57, v57, 24, v65                           // 00000047470C: D6460039 05053139
	v_pk_fma_f16 v56, v56, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474714: CC0E0038 0BFC1338 0000C931
	v_lshl_or_b32 v62, v63, 16, v62                            // 000000474720: D656003E 04F9213F
	v_dot2acc_f32_f16 v17, v61, v1                             // 000000474728: 0422033D
	v_and_b32_e32 v63, 0xffff, v64                             // 00000047472C: 367E80FF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000474734: D6220039 03FD0139 00006400
	v_dot2acc_f32_f16 v18, v60, v3                             // 000000474740: 0424073C
	v_pk_fma_f16 v55, v62, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474744: CC0E0037 0BFC133E 0000C931
	v_dot2acc_f32_f16 v17, v56, v2                             // 000000474750: 04220538
	v_pk_fma_f16 v56, v59, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474754: CC0E0038 0BFC133B 0000C931
	v_mul_u32_u24_e32 v59, s7, v58                             // 000000474760: 16767407
	v_mul_u32_u24_e32 v58, s8, v58                             // 000000474764: 16747408
	v_lshl_add_u32 v58, v58, 24, v59                           // 000000474768: D646003A 04ED313A
	v_lshl_or_b32 v57, v57, 16, v63                            // 000000474770: D6560039 04FD2139
	v_dot2acc_f32_f16 v17, v55, v3                             // 000000474778: 04220737
	v_bfe_u32 v55, v54, 8, 16                                  // 00000047477C: D6100037 02411136
	v_mul_u32_u24_e32 v63, s7, v55                             // 000000474784: 167E6E07
	v_mul_u32_u24_e32 v55, s8, v55                             // 000000474788: 166E6E08
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000047478C: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000474798: BF870002
	v_lshl_add_u32 v55, v55, 24, v63                           // 00000047479C: D6460037 04FD3137
	v_bfe_u32 v59, v54, 4, 16                                  // 0000004747A4: D610003B 02410936
	v_pk_fma_f16 v57, v57, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004747AC: CC0E0039 0BFC1339 0000C931
	s_waitcnt vmcnt(5)                                         // 0000004747B8: BF8917F7
	v_bfe_u32 v60, v53, 12, 16                                 // 0000004747BC: D610003C 02411935
	v_mul_u32_u24_e32 v63, s7, v59                             // 0000004747C4: 167E7607
	v_mul_u32_u24_e32 v59, s8, v59                             // 0000004747C8: 16767608
	v_lshl_add_u32 v59, v59, 24, v63                           // 0000004747CC: D646003B 04FD313B
	v_mul_u32_u24_e32 v63, s7, v60                             // 0000004747D4: 167E7807
	v_mul_u32_u24_e32 v60, s8, v60                             // 0000004747D8: 16787808
	v_lshl_add_u32 v60, v60, 24, v63                           // 0000004747DC: D646003C 04FD313C
	v_and_b32_e32 v58, 0xffff, v58                             // 0000004747E4: 367474FF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000004747EC: D6220037 03FD0137 00006400
	v_dual_dot2acc_f32_f16 v17, v57, v4 :: v_dual_and_b32 v54, 0xffff, v54// 0000004747F8: CB240939 11366CFF 0000FFFF
	v_bfe_u32 v61, v53, 8, 16                                  // 000000474804: D610003D 02411135
	v_mul_u32_u24_e32 v63, s7, v54                             // 00000047480C: 167E6C07
	v_mul_u32_u24_e32 v54, s8, v54                             // 000000474810: 166C6C08
	s_delay_alu instid0(VALU_DEP_2)                            // 000000474814: BF870002
	v_lshl_add_u32 v54, v54, 24, v63                           // 000000474818: D6460036 04FD3136
	v_mul_u32_u24_e32 v63, s7, v61                             // 000000474820: 167E7A07
	v_mul_u32_u24_e32 v61, s8, v61                             // 000000474824: 167A7A08
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000474828: D622003B 03FD013B 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000474834: D622003C 03FD013C 00006400
	v_lshl_add_u32 v61, v61, 24, v63                           // 000000474840: D646003D 04FD313D
	v_lshl_or_b32 v55, v55, 16, v58                            // 000000474848: D6560037 04E92137
	v_bfe_u32 v62, v53, 4, 16                                  // 000000474850: D610003E 02410935
	v_and_b32_e32 v58, 0xffff, v59                             // 000000474858: 367476FF 0000FFFF
	v_and_b32_e32 v59, 0xffff, v60                             // 000000474860: 367678FF 0000FFFF
	v_sad_u8 v60, v61, 0, 0x6400                               // 000000474868: D622003C 03FD013D 00006400
	v_mul_u32_u24_e32 v61, s7, v62                             // 000000474874: 167A7C07
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000474878: D6220036 03FD0136 00006400
	v_mul_u32_u24_e32 v62, s8, v62                             // 000000474884: 167C7C08
	v_lshl_add_u32 v61, v62, 24, v61                           // 000000474888: D646003D 04F5313E
	v_pk_fma_f16 v55, v55, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474890: CC0E0037 0BFC1337 0000C931
	v_dual_dot2acc_f32_f16 v18, v56, v4 :: v_dual_and_b32 v53, 0xffff, v53// 00000047489C: CB240938 12346AFF 0000FFFF
	v_lshl_or_b32 v54, v54, 16, v58                            // 0000004748A8: D6560036 04E92136
	v_lshl_or_b32 v58, v60, 16, v59                            // 0000004748B0: D656003A 04ED213C
	v_sad_u8 v59, v61, 0, 0x6400                               // 0000004748B8: D622003B 03FD013D 00006400
	v_dot2acc_f32_f16 v16, v55, v1                             // 0000004748C4: 04200337
	v_bfe_u32 v55, v50, 12, 16                                 // 0000004748C8: D6100037 02411932
	v_mul_u32_u24_e32 v64, s7, v55                             // 0000004748D0: 16806E07
	v_mul_u32_u24_e32 v55, s8, v55                             // 0000004748D4: 166E6E08
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004748D8: BF870001
	v_lshl_add_u32 v55, v55, 24, v64                           // 0000004748DC: D6460037 05013137
	v_mul_u32_u24_e32 v60, s7, v53                             // 0000004748E4: 16786A07
	v_mul_u32_u24_e32 v53, s8, v53                             // 0000004748E8: 166A6A08
	v_lshl_add_u32 v53, v53, 24, v60                           // 0000004748EC: D6460035 04F13135
	v_bfe_u32 v60, v50, 4, 16                                  // 0000004748F4: D610003C 02410932
	v_pk_fma_f16 v52, v58, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004748FC: CC0E0034 0BFC133A 0000C931
	v_and_b32_e32 v58, 0xffff, v59                             // 000000474908: 367476FF 0000FFFF
	v_bfe_u32 v59, v50, 8, 16                                  // 000000474910: D610003B 02411132
	v_mul_u32_u24_e32 v64, s7, v60                             // 000000474918: 16807807
	v_mul_u32_u24_e32 v60, s8, v60                             // 00000047491C: 16787808
	v_lshl_add_u32 v60, v60, 24, v64                           // 000000474920: D646003C 0501313C
	v_mul_u32_u24_e32 v64, s7, v59                             // 000000474928: 16807607
	v_mul_u32_u24_e32 v59, s8, v59                             // 00000047492C: 16767608
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000474930: D6220037 03FD0137 00006400
	v_lshl_add_u32 v59, v59, 24, v64                           // 00000047493C: D646003B 0501313B
	v_and_b32_e32 v50, 0xffff, v50                             // 000000474944: 366464FF 0000FFFF
	v_mul_u32_u24_e32 v64, s7, v50                             // 00000047494C: 16806407
	v_mul_u32_u24_e32 v50, s8, v50                             // 000000474950: 16646408
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000474954: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000474960: BF870002
	v_lshl_add_u32 v50, v50, 24, v64                           // 000000474964: D6460032 05013132
	v_and_b32_e32 v55, 0xffff, v55                             // 00000047496C: 366E6EFF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000474974: D622003B 03FD013B 00006400
	v_pk_fma_f16 v54, v54, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474980: CC0E0036 0BFC1336 0000C931
	v_and_b32_e32 v60, 0xffff, v60                             // 00000047498C: 367878FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000474994: D6220032 03FD0132 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000004749A0: D6220035 03FD0135 00006400
	v_lshl_or_b32 v55, v59, 16, v55                            // 0000004749AC: D6560037 04DD213B
	s_waitcnt vmcnt(4)                                         // 0000004749B4: BF8913F7
	v_bfe_u32 v61, v51, 12, 16                                 // 0000004749B8: D610003D 02411933
	v_mul_u32_u24_e32 v64, s7, v61                             // 0000004749C0: 16807A07
	v_lshl_or_b32 v50, v50, 16, v60                            // 0000004749C4: D6560032 04F12132
	v_mul_u32_u24_e32 v61, s8, v61                             // 0000004749CC: 167A7A08
	v_pk_fma_f16 v55, v55, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004749D0: CC0E0037 0BFC1337 0000C931
	v_lshl_or_b32 v53, v53, 16, v58                            // 0000004749DC: D6560035 04E92135
	v_dot2acc_f32_f16 v16, v54, v2                             // 0000004749E4: 04200536
	v_pk_fma_f16 v50, v50, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004749E8: CC0E0032 0BFC1332 0000C931
	v_lshl_add_u32 v61, v61, 24, v64                           // 0000004749F4: D646003D 0501313D
	v_dot2acc_f32_f16 v15, v55, v1                             // 0000004749FC: 041E0337
	v_bfe_u32 v62, v51, 8, 16                                  // 000000474A00: D610003E 02411133
	v_bfe_u32 v63, v51, 4, 16                                  // 000000474A08: D610003F 02410933
	v_mul_u32_u24_e32 v64, s7, v62                             // 000000474A10: 16807C07
	v_mul_u32_u24_e32 v62, s8, v62                             // 000000474A14: 167C7C08
	s_delay_alu instid0(VALU_DEP_2)                            // 000000474A18: BF870002
	v_lshl_add_u32 v62, v62, 24, v64                           // 000000474A1C: D646003E 0501313E
	v_mul_u32_u24_e32 v64, s7, v63                             // 000000474A24: 16807E07
	v_mul_u32_u24_e32 v63, s8, v63                             // 000000474A28: 167E7E08
	v_dot2acc_f32_f16 v15, v50, v2                             // 000000474A2C: 041E0532
	v_pk_fma_f16 v50, v53, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474A30: CC0E0032 0BFC1335 0000C931
	v_dot2acc_f32_f16 v16, v52, v3                             // 000000474A3C: 04200734
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000474A40: D622003D 03FD013D 00006400
	v_lshl_add_u32 v63, v63, 24, v64                           // 000000474A4C: D646003F 0501313F
	v_and_b32_e32 v51, 0xffff, v51                             // 000000474A54: 366666FF 0000FFFF
	v_sad_u8 v60, v62, 0, 0x6400                               // 000000474A5C: D622003C 03FD013E 00006400
	v_dot2acc_f32_f16 v16, v50, v4                             // 000000474A68: 04200932
	v_mul_u32_u24_e32 v62, s7, v51                             // 000000474A6C: 167C6607
	v_mul_u32_u24_e32 v51, s8, v51                             // 000000474A70: 16666608
	v_and_b32_e32 v59, 0xffff, v61                             // 000000474A74: 36767AFF 0000FFFF
	v_sad_u8 v61, v63, 0, 0x6400                               // 000000474A7C: D622003D 03FD013F 00006400
	v_lshl_add_u32 v51, v51, 24, v62                           // 000000474A88: D6460033 04F93133
	v_bfe_u32 v50, v48, 4, 16                                  // 000000474A90: D6100032 02410930
	s_waitcnt vmcnt(3)                                         // 000000474A98: BF890FF7
	v_bfe_u32 v53, v47, 8, 16                                  // 000000474A9C: D6100035 0241112F
	v_lshl_or_b32 v59, v60, 16, v59                            // 000000474AA4: D656003B 04ED213C
	v_and_b32_e32 v60, 0xffff, v61                             // 000000474AAC: 36787AFF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000474AB4: D6220033 03FD0133 00006400
	v_mov_b32_e32 v58, v40                                     // 000000474AC0: 7E740328
	v_mov_b32_e32 v57, v40                                     // 000000474AC4: 7E720328
	v_pk_fma_f16 v54, v59, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474AC8: CC0E0036 0BFC133B 0000C931
	v_mov_b32_e32 v59, v41                                     // 000000474AD4: 7E760329
	v_lshl_or_b32 v51, v51, 16, v60                            // 000000474AD8: D6560033 04F12133
	v_mov_b32_e32 v56, v34                                     // 000000474AE0: 7E700322
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000474AE4: BF870224
	v_dot2acc_f32_f16 v15, v54, v3                             // 000000474AE8: 041E0736
	v_bfe_u32 v54, v47, 4, 16                                  // 000000474AEC: D6100036 0241092F
	v_pk_fma_f16 v49, v51, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474AF4: CC0E0031 0BFC1333 0000C931
	v_bfe_u32 v51, v48, 12, 16                                 // 000000474B00: D6100033 02411930
	v_mul_u32_u24_e32 v52, s7, v51                             // 000000474B08: 16686607
	v_mul_u32_u24_e32 v51, s8, v51                             // 000000474B0C: 16666608
	s_delay_alu instid0(VALU_DEP_1)                            // 000000474B10: BF870001
	v_lshl_add_u32 v51, v51, 24, v52                           // 000000474B14: D6460033 04D13133
	v_dot2acc_f32_f16 v15, v49, v4                             // 000000474B1C: 041E0931
	v_bfe_u32 v49, v48, 8, 16                                  // 000000474B20: D6100031 02411130
	v_mul_u32_u24_e32 v55, s7, v49                             // 000000474B28: 166E6207
	v_mul_u32_u24_e32 v49, s8, v49                             // 000000474B2C: 16626208
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000474B30: D6220033 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000474B3C: BF870002
	v_lshl_add_u32 v49, v49, 24, v55                           // 000000474B40: D6460031 04DD3131
	v_bfe_u32 v52, v47, 12, 16                                 // 000000474B48: D6100034 0241192F
	v_mul_u32_u24_e32 v55, s7, v50                             // 000000474B50: 166E6407
	v_mul_u32_u24_e32 v50, s8, v50                             // 000000474B54: 16646408
	v_lshl_add_u32 v50, v50, 24, v55                           // 000000474B58: D6460032 04DD3132
	v_mul_u32_u24_e32 v55, s7, v52                             // 000000474B60: 166E6807
	v_mul_u32_u24_e32 v52, s8, v52                             // 000000474B64: 16686808
	v_and_b32_e32 v48, 0xffff, v48                             // 000000474B68: 366060FF 0000FFFF
	v_and_b32_e32 v51, 0xffff, v51                             // 000000474B70: 366666FF 0000FFFF
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000474B78: D6220031 03FD0131 00006400
	v_lshl_add_u32 v52, v52, 24, v55                           // 000000474B84: D6460034 04DD3134
	v_mul_u32_u24_e32 v55, s7, v48                             // 000000474B8C: 166E6007
	v_mul_u32_u24_e32 v48, s8, v48                             // 000000474B90: 16606008
	v_lshl_add_u32 v48, v48, 24, v55                           // 000000474B94: D6460030 04DD3130
	v_mul_u32_u24_e32 v55, s7, v53                             // 000000474B9C: 166E6A07
	v_mul_u32_u24_e32 v53, s8, v53                             // 000000474BA0: 166A6A08
	v_lshl_add_u32 v53, v53, 24, v55                           // 000000474BA4: D6460035 04DD3135
	v_mul_u32_u24_e32 v55, s7, v54                             // 000000474BAC: 166E6C07
	v_mul_u32_u24_e32 v54, s8, v54                             // 000000474BB0: 166C6C08
	v_lshl_add_u32 v54, v54, 24, v55                           // 000000474BB4: D6460036 04DD3136
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000474BBC: D6220032 03FD0132 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000474BC8: D6220034 03FD0134 00006400
	v_lshl_or_b32 v49, v49, 16, v51                            // 000000474BD4: D6560031 04CD2131
	v_and_b32_e32 v47, 0xffff, v47                             // 000000474BDC: 365E5EFF 0000FFFF
	v_mul_u32_u24_e32 v55, s7, v47                             // 000000474BE4: 166E5E07
	v_mul_u32_u24_e32 v47, s8, v47                             // 000000474BE8: 165E5E08
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000474BEC: D6220036 03FD0136 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000474BF8: BF870002
	v_lshl_add_u32 v47, v47, 24, v55                           // 000000474BFC: D646002F 04DD312F
	v_and_b32_e32 v50, 0xffff, v50                             // 000000474C04: 366464FF 0000FFFF
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000474C0C: D6220030 03FD0130 00006400
	v_and_b32_e32 v52, 0xffff, v52                             // 000000474C18: 366868FF 0000FFFF
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000474C20: D6220035 03FD0135 00006400
	v_pk_fma_f16 v49, v49, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474C2C: CC0E0031 0BFC1331 0000C931
	v_and_b32_e32 v51, 0xffff, v54                             // 000000474C38: 36666CFF 0000FFFF
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000474C40: D622002F 03FD012F 00006400
	v_lshl_or_b32 v48, v48, 16, v50                            // 000000474C4C: D6560030 04C92130
	v_lshl_or_b32 v50, v53, 16, v52                            // 000000474C54: D6560032 04D12135
	v_dot2acc_f32_f16 v14, v49, v1                             // 000000474C5C: 041C0331
	v_bfe_u32 v49, v45, 12, 16                                 // 000000474C60: D6100031 0241192D
	v_mul_u32_u24_e32 v55, s7, v49                             // 000000474C68: 166E6207
	v_mul_u32_u24_e32 v49, s8, v49                             // 000000474C6C: 16626208
	s_delay_alu instid0(VALU_DEP_1)                            // 000000474C70: BF870001
	v_lshl_add_u32 v49, v49, 24, v55                           // 000000474C74: D6460031 04DD3131
	v_lshl_or_b32 v47, v47, 16, v51                            // 000000474C7C: D656002F 04CD212F
	v_bfe_u32 v51, v45, 4, 16                                  // 000000474C84: D6100033 0241092D
	v_pk_fma_f16 v46, v48, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474C8C: CC0E002E 0BFC1330 0000C931
	v_pk_fma_f16 v48, v50, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474C98: CC0E0030 0BFC1332 0000C931
	v_bfe_u32 v50, v45, 8, 16                                  // 000000474CA4: D6100032 0241112D
	v_mul_u32_u24_e32 v55, s7, v51                             // 000000474CAC: 166E6607
	v_mul_u32_u24_e32 v51, s8, v51                             // 000000474CB0: 16666608
	v_lshl_add_u32 v51, v51, 24, v55                           // 000000474CB4: D6460033 04DD3133
	v_mul_u32_u24_e32 v55, s7, v50                             // 000000474CBC: 166E6407
	v_mul_u32_u24_e32 v50, s8, v50                             // 000000474CC0: 16646408
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000474CC4: D6220031 03FD0131 00006400
	v_lshl_add_u32 v50, v50, 24, v55                           // 000000474CD0: D6460032 04DD3132
	v_and_b32_e32 v45, 0xffff, v45                             // 000000474CD8: 365A5AFF 0000FFFF
	s_waitcnt vmcnt(2)                                         // 000000474CE0: BF890BF7
	v_bfe_u32 v52, v44, 12, 16                                 // 000000474CE4: D6100034 0241192C
	v_mul_u32_u24_e32 v55, s7, v45                             // 000000474CEC: 166E5A07
	v_mul_u32_u24_e32 v45, s8, v45                             // 000000474CF0: 165A5A08
	v_lshl_add_u32 v45, v45, 24, v55                           // 000000474CF4: D646002D 04DD312D
	v_mul_u32_u24_e32 v55, s7, v52                             // 000000474CFC: 166E6807
	v_mul_u32_u24_e32 v52, s8, v52                             // 000000474D00: 16686808
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000474D04: D6220033 03FD0133 00006400
	v_lshl_add_u32 v52, v52, 24, v55                           // 000000474D10: D6460034 04DD3134
	v_and_b32_e32 v49, 0xffff, v49                             // 000000474D18: 366262FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000474D20: D6220032 03FD0132 00006400
	v_bfe_u32 v53, v44, 8, 16                                  // 000000474D2C: D6100035 0241112C
	v_mul_u32_u24_e32 v55, s7, v53                             // 000000474D34: 166E6A07
	v_mul_u32_u24_e32 v53, s8, v53                             // 000000474D38: 166A6A08
	v_and_b32_e32 v51, 0xffff, v51                             // 000000474D3C: 366666FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000474D44: D622002D 03FD012D 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000474D50: D6220034 03FD0134 00006400
	v_lshl_add_u32 v53, v53, 24, v55                           // 000000474D5C: D6460035 04DD3135
	v_lshl_or_b32 v49, v50, 16, v49                            // 000000474D64: D6560031 04C52132
	v_bfe_u32 v54, v44, 4, 16                                  // 000000474D6C: D6100036 0241092C
	v_mul_u32_u24_e32 v55, s7, v54                             // 000000474D74: 166E6C07
	v_mul_u32_u24_e32 v54, s8, v54                             // 000000474D78: 166C6C08
	s_delay_alu instid0(VALU_DEP_1)                            // 000000474D7C: BF870001
	v_lshl_add_u32 v54, v54, 24, v55                           // 000000474D80: D6460036 04DD3136
	v_lshl_or_b32 v45, v45, 16, v51                            // 000000474D88: D656002D 04CD212D
	v_and_b32_e32 v50, 0xffff, v52                             // 000000474D90: 366468FF 0000FFFF
	v_sad_u8 v51, v53, 0, 0x6400                               // 000000474D98: D6220033 03FD0135 00006400
	v_pk_fma_f16 v49, v49, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474DA4: CC0E0031 0BFC1331 0000C931
	v_and_b32_e32 v44, 0xffff, v44                             // 000000474DB0: 365858FF 0000FFFF
	v_mul_u32_u24_e32 v53, s7, v44                             // 000000474DB8: 166A5807
	v_mul_u32_u24_e32 v44, s8, v44                             // 000000474DBC: 16585808
	v_sad_u8 v52, v54, 0, 0x6400                               // 000000474DC0: D6220034 03FD0136 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000474DCC: BF870002
	v_lshl_add_u32 v44, v44, 24, v53                           // 000000474DD0: D646002C 04D5312C
	v_pk_fma_f16 v45, v45, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474DD8: CC0E002D 0BFC132D 0000C931
	v_lshl_or_b32 v50, v51, 16, v50                            // 000000474DE4: D6560032 04C92133
	v_dot2acc_f32_f16 v13, v49, v1                             // 000000474DEC: 041A0331
	v_and_b32_e32 v51, 0xffff, v52                             // 000000474DF0: 366668FF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000474DF8: D622002C 03FD012C 00006400
	v_dot2acc_f32_f16 v14, v46, v2                             // 000000474E04: 041C052E
	v_pk_fma_f16 v43, v50, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474E08: CC0E002B 0BFC1332 0000C931
	v_dot2acc_f32_f16 v13, v45, v2                             // 000000474E14: 041A052D
	v_bfe_u32 v46, v42, 12, 16                                 // 000000474E18: D610002E 0241192A
	v_pk_fma_f16 v45, v47, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474E20: CC0E002D 0BFC132F 0000C931
	v_mul_u32_u24_e32 v47, s7, v46                             // 000000474E2C: 165E5C07
	v_mul_u32_u24_e32 v46, s8, v46                             // 000000474E30: 165C5C08
	s_delay_alu instid0(VALU_DEP_2)                            // 000000474E34: BF870002
	v_lshl_add_u32 v46, v46, 24, v47                           // 000000474E38: D646002E 04BD312E
	v_lshl_or_b32 v44, v44, 16, v51                            // 000000474E40: D656002C 04CD212C
	v_dot2acc_f32_f16 v13, v43, v3                             // 000000474E48: 041A072B
	v_bfe_u32 v43, v42, 8, 16                                  // 000000474E4C: D610002B 0241112A
	v_mul_u32_u24_e32 v51, s7, v43                             // 000000474E54: 16665607
	v_mul_u32_u24_e32 v43, s8, v43                             // 000000474E58: 16565608
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000474E5C: D622002E 03FD012E 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000474E68: BF870002
	v_lshl_add_u32 v43, v43, 24, v51                           // 000000474E6C: D646002B 04CD312B
	v_bfe_u32 v47, v42, 4, 16                                  // 000000474E74: D610002F 0241092A
	v_dot2acc_f32_f16 v14, v48, v3                             // 000000474E7C: 041C0730
	v_pk_fma_f16 v44, v44, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474E80: CC0E002C 0BFC132C 0000C931
	s_waitcnt vmcnt(1)                                         // 000000474E8C: BF8907F7
	v_bfe_u32 v48, v26, 12, 16                                 // 000000474E90: D6100030 0241191A
	v_mul_u32_u24_e32 v51, s7, v47                             // 000000474E98: 16665E07
	v_mul_u32_u24_e32 v47, s8, v47                             // 000000474E9C: 165E5E08
	v_lshl_add_u32 v47, v47, 24, v51                           // 000000474EA0: D646002F 04CD312F
	v_mul_u32_u24_e32 v51, s7, v48                             // 000000474EA8: 16666007
	v_mul_u32_u24_e32 v48, s8, v48                             // 000000474EAC: 16606008
	v_lshl_add_u32 v48, v48, 24, v51                           // 000000474EB0: D6460030 04CD3130
	v_and_b32_e32 v46, 0xffff, v46                             // 000000474EB8: 365C5CFF 0000FFFF
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000474EC0: D622002B 03FD012B 00006400
	v_dual_dot2acc_f32_f16 v13, v44, v4 :: v_dual_and_b32 v42, 0xffff, v42// 000000474ECC: CB24092C 0D2A54FF 0000FFFF
	v_bfe_u32 v49, v26, 8, 16                                  // 000000474ED8: D6100031 0241111A
	v_mul_u32_u24_e32 v51, s7, v42                             // 000000474EE0: 16665407
	v_mul_u32_u24_e32 v42, s8, v42                             // 000000474EE4: 16545408
	s_delay_alu instid0(VALU_DEP_2)                            // 000000474EE8: BF870002
	v_lshl_add_u32 v42, v42, 24, v51                           // 000000474EEC: D646002A 04CD312A
	v_mul_u32_u24_e32 v51, s7, v49                             // 000000474EF4: 16666207
	v_mul_u32_u24_e32 v49, s8, v49                             // 000000474EF8: 16626208
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000474EFC: D622002F 03FD012F 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000474F08: D6220030 03FD0130 00006400
	v_lshl_add_u32 v49, v49, 24, v51                           // 000000474F14: D6460031 04CD3131
	v_lshl_or_b32 v43, v43, 16, v46                            // 000000474F1C: D656002B 04B9212B
	v_bfe_u32 v50, v26, 4, 16                                  // 000000474F24: D6100032 0241091A
	v_and_b32_e32 v46, 0xffff, v47                             // 000000474F2C: 365C5EFF 0000FFFF
	v_and_b32_e32 v47, 0xffff, v48                             // 000000474F34: 365E60FF 0000FFFF
	v_sad_u8 v48, v49, 0, 0x6400                               // 000000474F3C: D6220030 03FD0131 00006400
	v_mul_u32_u24_e32 v49, s7, v50                             // 000000474F48: 16626407
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000474F4C: D622002A 03FD012A 00006400
	v_mul_u32_u24_e32 v50, s8, v50                             // 000000474F58: 16646408
	v_lshl_add_u32 v49, v50, 24, v49                           // 000000474F5C: D6460031 04C53132
	v_pk_fma_f16 v43, v43, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474F64: CC0E002B 0BFC132B 0000C931
	v_and_b32_e32 v26, 0xffff, v26                             // 000000474F70: 363434FF 0000FFFF
	v_lshl_or_b32 v42, v42, 16, v46                            // 000000474F78: D656002A 04B9212A
	v_lshl_or_b32 v46, v48, 16, v47                            // 000000474F80: D656002E 04BD2130
	v_sad_u8 v47, v49, 0, 0x6400                               // 000000474F88: D622002F 03FD0131 00006400
	v_dot2acc_f32_f16 v12, v43, v1                             // 000000474F94: 0418032B
	v_bfe_u32 v43, v21, 12, 16                                 // 000000474F98: D610002B 02411915
	v_dual_dot2acc_f32_f16 v14, v45, v4 :: v_dual_mov_b32 v45, v28// 000000474FA0: CB10092D 0E2C011C
	v_mul_u32_u24_e32 v48, s7, v26                             // 000000474FA8: 16603407
	v_mul_u32_u24_e32 v26, s8, v26                             // 000000474FAC: 16343408
	v_lshl_add_u32 v26, v26, 24, v48                           // 000000474FB0: D646001A 04C1311A
	v_bfe_u32 v48, v21, 4, 16                                  // 000000474FB8: D6100030 02410915
	v_mul_u32_u24_e32 v52, s7, v43                             // 000000474FC0: 16685607
	v_mul_u32_u24_e32 v43, s8, v43                             // 000000474FC4: 16565608
	v_lshl_add_u32 v43, v43, 24, v52                           // 000000474FC8: D646002B 04D1312B
	v_mul_u32_u24_e32 v52, s7, v48                             // 000000474FD0: 16686007
	v_mul_u32_u24_e32 v48, s8, v48                             // 000000474FD4: 16606008
	v_lshl_add_u32 v48, v48, 24, v52                           // 000000474FD8: D6460030 04D13130
	v_pk_fma_f16 v23, v46, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000474FE0: CC0E0017 0BFC132E 0000C931
	v_and_b32_e32 v46, 0xffff, v47                             // 000000474FEC: 365C5EFF 0000FFFF
	v_bfe_u32 v47, v21, 8, 16                                  // 000000474FF4: D610002F 02411115
	v_and_b32_e32 v21, 0xffff, v21                             // 000000474FFC: 362A2AFF 0000FFFF
	v_mul_u32_u24_e32 v52, s7, v47                             // 000000475004: 16685E07
	v_mul_u32_u24_e32 v47, s8, v47                             // 000000475008: 165E5E08
	s_delay_alu instid0(VALU_DEP_2)                            // 00000047500C: BF870002
	v_lshl_add_u32 v47, v47, 24, v52                           // 000000475010: D646002F 04D1312F
	v_mul_u32_u24_e32 v52, s7, v21                             // 000000475018: 16682A07
	v_mul_u32_u24_e32 v21, s8, v21                             // 00000047501C: 162A2A08
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000475020: D6220030 03FD0130 00006400
	v_lshl_add_u32 v21, v21, 24, v52                           // 00000047502C: D6460015 04D13115
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000475034: D622002B 03FD012B 00006400
	s_waitcnt vmcnt(0)                                         // 000000475040: BF8903F7
	v_bfe_u32 v49, v19, 12, 16                                 // 000000475044: D6100031 02411913
	v_bfe_u32 v50, v19, 8, 16                                  // 00000047504C: D6100032 02411113
	v_mul_u32_u24_e32 v52, s7, v49                             // 000000475054: 16686207
	v_mul_u32_u24_e32 v49, s8, v49                             // 000000475058: 16626208
	s_delay_alu instid0(VALU_DEP_2)                            // 00000047505C: BF870002
	v_lshl_add_u32 v49, v49, 24, v52                           // 000000475060: D6460031 04D13131
	v_mul_u32_u24_e32 v52, s7, v50                             // 000000475068: 16686407
	v_mul_u32_u24_e32 v50, s8, v50                             // 00000047506C: 16646408
	v_and_b32_e32 v48, 0xffff, v48                             // 000000475070: 366060FF 0000FFFF
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000475078: D6220015 03FD0115 00006400
	v_lshl_add_u32 v50, v50, 24, v52                           // 000000475084: D6460032 04D13132
	v_and_b32_e32 v43, 0xffff, v43                             // 00000047508C: 365656FF 0000FFFF
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000475094: D622002F 03FD012F 00006400
	v_bfe_u32 v51, v19, 4, 16                                  // 0000004750A0: D6100033 02410913
	v_and_b32_e32 v19, 0xffff, v19                             // 0000004750A8: 362626FF 0000FFFF
	v_mul_u32_u24_e32 v52, s7, v51                             // 0000004750B0: 16686607
	v_mul_u32_u24_e32 v51, s8, v51                             // 0000004750B4: 16666608
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004750B8: BF870002
	v_lshl_add_u32 v51, v51, 24, v52                           // 0000004750BC: D6460033 04D13133
	v_lshl_or_b32 v21, v21, 16, v48                            // 0000004750C4: D6560015 04C12115
	v_sad_u8 v48, v50, 0, 0x6400                               // 0000004750CC: D6220030 03FD0132 00006400
	v_mov_b32_e32 v52, v38                                     // 0000004750D8: 7E680326
	v_mul_u32_u24_e32 v50, s7, v19                             // 0000004750DC: 16642607
	v_mul_u32_u24_e32 v19, s8, v19                             // 0000004750E0: 16262608
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000004750E4: D6220031 03FD0131 00006400
	v_lshl_add_u32 v19, v19, 24, v50                           // 0000004750F0: D6460013 04C93113
	v_mov_b32_e32 v50, v30                                     // 0000004750F8: 7E64031E
	v_lshl_or_b32 v43, v47, 16, v43                            // 0000004750FC: D656002B 04AD212F
	v_pk_fma_f16 v42, v42, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000475104: CC0E002A 0BFC132A 0000C931
	v_dual_mov_b32 v54, v31 :: v_dual_and_b32 v47, 0xffff, v49 // 000000475110: CA24011F 362E62FF 0000FFFF
	v_sad_u8 v49, v51, 0, 0x6400                               // 00000047511C: D6220031 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000475128: BF870004
	v_pk_fma_f16 v43, v43, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047512C: CC0E002B 0BFC132B 0000C931
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000475138: D622001A 03FD011A 00006400
	v_pk_fma_f16 v21, v21, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000475144: CC0E0015 0BFC1315 0000C931
	v_lshl_or_b32 v47, v48, 16, v47                            // 000000475150: D656002F 04BD2130
	v_dual_mov_b32 v51, v38 :: v_dual_and_b32 v48, 0xffff, v49 // 000000475158: CA240126 333062FF 0000FFFF
	v_dot2acc_f32_f16 v11, v43, v1                             // 000000475164: 0416032B
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000475168: D6220013 03FD0113 00006400
	v_lshl_or_b32 v1, v26, 16, v46                             // 000000475174: D6560001 04B9211A
	v_dot2acc_f32_f16 v12, v42, v2                             // 00000047517C: 0418052A
	v_pk_fma_f16 v26, v47, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000475180: CC0E001A 0BFC132F 0000C931
	v_dot2acc_f32_f16 v11, v21, v2                             // 00000047518C: 04160515
	v_lshl_or_b32 v19, v19, 16, v48                            // 000000475190: D6560013 04C12113
	v_pk_fma_f16 v1, v1, s9, 0xc931 op_sel_hi:[1,0,0]          // 000000475198: CC0E0001 0BFC1301 0000C931
	v_dual_dot2acc_f32_f16 v12, v23, v3 :: v_dual_mov_b32 v23, v33// 0000004751A4: CB100717 0C160121
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004751AC: BF870234
	v_dot2acc_f32_f16 v11, v26, v3                             // 0000004751B0: 0416071A
	v_add_nc_u32_e32 v3, v20, v5                               // 0000004751B4: 4A060B14
	v_pk_fma_f16 v2, v19, s9, 0xc931 op_sel_hi:[1,0,0]         // 0000004751B8: CC0E0002 0BFC1313 0000C931
	v_dot2acc_f32_f16 v12, v1, v4                              // 0000004751C4: 04180901
	v_mov_b32_e32 v19, v33                                     // 0000004751C8: 7E260321
	v_mov_b32_e32 v21, v6                                      // 0000004751CC: 7E2A0306
	v_cmp_eq_u32_e32 vcc_lo, 1, v3                             // 0000004751D0: 7C940681
	v_dual_dot2acc_f32_f16 v11, v2, v4 :: v_dual_mov_b32 v26, v35// 0000004751D4: CB100902 0B1A0123
	v_mov_b32_e32 v43, v35                                     // 0000004751DC: 7E560323
	v_mov_b32_e32 v42, v27                                     // 0000004751E0: 7E54031B
	v_mov_b32_e32 v44, v36                                     // 0000004751E4: 7E580324
	v_dual_mov_b32 v46, v36 :: v_dual_mov_b32 v47, v37         // 0000004751E8: CA100124 2E2E0125
	v_mov_b32_e32 v49, v37                                     // 0000004751F0: 7E620325
	v_dual_mov_b32 v48, v29 :: v_dual_mov_b32 v53, v39         // 0000004751F4: CA10011D 30340127
	v_dual_mov_b32 v55, v39 :: v_dual_mov_b32 v2, v32          // 0000004751FC: CA100127 37020120
	v_mov_b32_e32 v3, v41                                      // 000000475204: 7E060329
	s_or_b32 s6, vcc_lo, s6                                    // 000000475208: 8C06066A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000047520C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000475210: 917E067E
	s_cbranch_execz 56                                         // 000000475214: BFA50038 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x19f8>
	s_mov_b32 s10, exec_lo                                     // 000000475218: BE8A007E
	.long 0xd4c1007e                                           // 00000047521C: D4C1007E
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000475220: 02020F05
	s_cbranch_execz 64616                                      // 000000475224: BFA5FC68 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xac8>
	v_ashrrev_i32_e32 v6, 31, v5                               // 000000475228: 340C0A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047522C: BF870091
	.long 0xd73c001b                                           // 000000475230: D73C001B
	v_cndmask_b32_e32 v1, 10, v5, vcc_lo                       // 000000475234: 02020A8A
	.long 0xd7006a01                                           // 000000475238: D7006A01
	v_cndmask_b32_e32 v1, s1, v27, vcc_lo                      // 00000047523C: 02023601
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000475240: BF870111
	v_add_co_ci_u32_e64 v4, null, s5, v28, vcc_lo              // 000000475244: D5207C04 01AA3805
	.long 0xd7006a23                                           // 00000047524C: D7006A23
	v_cndmask_b32_e32 v1, v1, v25, vcc_lo                      // 000000475250: 02023301
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000475254: BF8700A1
	v_add_co_ci_u32_e64 v36, null, 0, v4, vcc_lo               // 000000475258: D5207C24 01AA0880
	.long 0xd7006a3c                                           // 000000475260: D7006A3C
	v_cndmask_b32_e32 v1, v1, v22, vcc_lo                      // 000000475264: 02022D01
	v_add_co_ci_u32_e64 v61, null, 0, v4, vcc_lo               // 000000475268: D5207C3D 01AA0880
	s_clause 0xf                                               // 000000475270: BF85000F
	global_load_b32 v32, v[35:36], off                         // 000000475274: DC520000 207C0023
	global_load_b32 v34, v[35:36], off offset:128              // 00000047527C: DC520080 227C0023
	global_load_b32 v31, v[35:36], off offset:256              // 000000475284: DC520100 1F7C0023
	global_load_b32 v30, v[35:36], off offset:384              // 00000047528C: DC520180 1E7C0023
	global_load_b32 v29, v[35:36], off offset:512              // 000000475294: DC520200 1D7C0023
	global_load_b32 v28, v[35:36], off offset:640              // 00000047529C: DC520280 1C7C0023
	global_load_b32 v27, v[35:36], off offset:768              // 0000004752A4: DC520300 1B7C0023
	global_load_b32 v6, v[35:36], off offset:896               // 0000004752AC: DC520380 067C0023
	global_load_b32 v41, v[60:61], off                         // 0000004752B4: DC520000 297C003C
	global_load_b32 v40, v[60:61], off offset:128              // 0000004752BC: DC520080 287C003C
	global_load_b32 v39, v[60:61], off offset:256              // 0000004752C4: DC520100 277C003C
	global_load_b32 v38, v[60:61], off offset:384              // 0000004752CC: DC520180 267C003C
	global_load_b32 v37, v[60:61], off offset:512              // 0000004752D4: DC520200 257C003C
	global_load_b32 v36, v[60:61], off offset:640              // 0000004752DC: DC520280 247C003C
	global_load_b32 v35, v[60:61], off offset:768              // 0000004752E4: DC520300 237C003C
	global_load_b32 v33, v[60:61], off offset:896              // 0000004752EC: DC520380 217C003C
	s_branch 64564                                             // 0000004752F4: BFA0FC34 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xac8>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000004752F8: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004752FC: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000475300: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 000000475304: BF895FF7
	v_dual_mov_b32 v1, v18 :: v_dual_mov_b32 v2, v17           // 000000475308: CA100112 01020111
	s_waitcnt vmcnt(15)                                        // 000000475310: BF893FF7
	v_dual_mov_b32 v3, v16 :: v_dual_mov_b32 v4, v14           // 000000475314: CA100110 0304010E
	v_dual_mov_b32 v7, v15 :: v_dual_mov_b32 v6, v12           // 00000047531C: CA10010F 0706010C
	v_mov_b32_e32 v5, v13                                      // 000000475324: 7E0A030D
	s_waitcnt vmcnt(0)                                         // 000000475328: BF8903F7
	v_mov_b32_e32 v19, v11                                     // 00000047532C: 7E26030B
	s_mov_b32 s0, 0x76543210                                   // 000000475330: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000475338: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 00000047533C: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000475348: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000475354: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000475360: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 00000047536C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000475378: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000475384: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 000000475390: D65C0013 03FC0113 FEDCBA98
	.long 0xd44c0000                                           // 00000047539C: D44C0000
	v_cndmask_b32_e32 v1, 16, v10, vcc_lo                      // 0000004753A0: 02021490
	s_barrier                                                  // 0000004753A4: BFBD0000
	buffer_gl0_inv                                             // 0000004753A8: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000004753B0: BE812000
	s_cbranch_execz 18                                         // 0000004753B4: BFA50012 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b00>
	v_dual_add_f32 v10, v11, v19 :: v_dual_add_f32 v1, v18, v1 // 0000004753B8: C908270B 0A000312
	v_dual_add_f32 v2, v17, v2 :: v_dual_add_f32 v3, v16, v3   // 0000004753C0: C9080511 02020710
	v_lshl_or_b32 v9, v8, 9, v9                                // 0000004753C8: D6560009 04251308
	v_dual_add_f32 v7, v15, v7 :: v_dual_add_f32 v4, v14, v4   // 0000004753D0: C9080F0F 0704090E
	v_dual_add_f32 v5, v13, v5 :: v_dual_add_f32 v6, v12, v6   // 0000004753D8: C9080B0D 05060D0C
	ds_store_2addr_b32 v9, v1, v2 offset1:16                   // 0000004753E0: D8381000 00020109
	ds_store_2addr_b32 v9, v3, v7 offset0:32 offset1:48        // 0000004753E8: D8383020 00070309
	ds_store_2addr_b32 v9, v4, v5 offset0:64 offset1:80        // 0000004753F0: D8385040 00050409
	ds_store_2addr_b32 v9, v6, v10 offset0:96 offset1:112      // 0000004753F8: D8387060 000A0609
	s_or_b32 exec_lo, exec_lo, s1                              // 000000475400: 8C7E017E
	.long 0xd44c0001                                           // 000000475404: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000475408: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000475410: BF89FC07
	s_barrier                                                  // 000000475414: BFBD0000
	buffer_gl0_inv                                             // 000000475418: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000475420: BE852001
	s_cbranch_execnz 7                                         // 000000475424: BFA60007 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b44>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000475428: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 00000047542C: BF048221
	s_mov_b32 s5, -1                                           // 000000475430: BE8500C1
	s_cbranch_scc0 33                                          // 000000475434: BFA10021 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1bbc>
	s_and_b32 vcc_lo, exec_lo, s5                              // 000000475438: 8B6A057E
	s_cbranch_vccnz 154                                        // 00000047543C: BFA4009A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1da8>
	s_endpgm                                                   // 000000475440: BFB00000
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000475444: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:2            // 000000475448: D8E00200 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:4 offset1:6  // 000000475450: D8E00604 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:8 offset1:10 // 000000475458: D8E00A08 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000475460: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000475464: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000475468: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 00000047546C: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000475470: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000475474: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:12 offset1:14// 000000475478: D8E00E0C 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000475480: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000475484: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000475488: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 00000047548C: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000475490: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000475494: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000475498: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 00000047549C: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 0000004754A0: 06020501
	ds_store_b32 v7, v1 offset:4096                            // 0000004754A4: D8341000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 0000004754AC: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 0000004754B0: BF048221
	s_mov_b32 s5, -1                                           // 0000004754B4: BE8500C1
	s_cbranch_scc1 65503                                       // 0000004754B8: BFA2FFDF <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b38>
	s_waitcnt lgkmcnt(0)                                       // 0000004754BC: BF89FC07
	s_barrier                                                  // 0000004754C0: BFBD0000
	buffer_gl0_inv                                             // 0000004754C4: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 0000004754CC: BE852001
	s_cbranch_execz 17                                         // 0000004754D0: BFA50011 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c18>
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000004754D4: 30020082
	s_mul_hi_i32 s7, s26, s4                                   // 0000004754D8: 9707041A
	s_mul_i32 s6, s26, s4                                      // 0000004754DC: 9606041A
	s_lshl_b32 s8, s2, 7                                       // 0000004754E0: 84088702
	s_lshl_b64 s[6:7], s[6:7], 2                               // 0000004754E4: 84868206
	ds_load_b32 v2, v1 offset:4096                             // 0000004754E8: D8D81000 02000001
	s_ashr_i32 s9, s8, 31                                      // 0000004754F0: 86099F08
	s_add_u32 s4, s16, s6                                      // 0000004754F4: 80040610
	s_addc_u32 s10, s17, s7                                    // 0000004754F8: 820A0711
	s_lshl_b64 s[6:7], s[8:9], 2                               // 0000004754FC: 84868208
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000475500: BF870009
	s_add_u32 s6, s4, s6                                       // 000000475504: 80060604
	s_addc_u32 s7, s10, s7                                     // 000000475508: 8207070A
	s_waitcnt lgkmcnt(0)                                       // 00000047550C: BF89FC07
	global_store_b32 v1, v2, s[6:7]                            // 000000475510: DC6A0000 00060201
	s_or_b32 exec_lo, exec_lo, s5                              // 000000475518: 8C7E057E
	.long 0xd44a0004                                           // 00000047551C: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000475520: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000475524: BC7C0000
	buffer_gl1_inv                                             // 000000475528: E0B00000 00000000
	buffer_gl0_inv                                             // 000000475530: E0AC0000 00000000
	s_barrier                                                  // 000000475538: BFBD0000
	buffer_gl0_inv                                             // 00000047553C: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000475544: BE852004
	s_cbranch_execz 29                                         // 000000475548: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1cc0>
	s_mov_b32 s7, exec_lo                                      // 00000047554C: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000475550: BE86007E
	.long 0xd71f0001                                           // 000000475554: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 000000475558: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047555C: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000475560: 7D940280
	s_cbranch_execz 9                                          // 000000475564: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c8c>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 000000475568: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000047556C: BF8704B9
	s_add_u32 s8, s18, s8                                      // 000000475570: 80080812
	s_addc_u32 s9, s19, s9                                     // 000000475574: 82090913
	s_bcnt1_i32_b32 s7, s7                                     // 000000475578: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 00000047557C: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 000000475584: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 00000047558C: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000475590: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 000000475594: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000475598: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 00000047559C: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 0000004755A4: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000004755A8: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 0000004755AC: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000004755B0: D5010001 01A90280
	ds_store_b32 v2, v1 offset:5120                            // 0000004755B8: D8341400 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 0000004755C0: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 0000004755C4: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000004755C8: BF89FC07
	s_barrier                                                  // 0000004755CC: BFBD0000
	buffer_gl0_inv                                             // 0000004755D0: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:5120                             // 0000004755D8: D8D81400 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000004755E0: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000004755E4: 7C940280
	s_cbranch_vccnz 46                                         // 0000004755E8: BFA4002E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1da4>
	buffer_gl1_inv                                             // 0000004755EC: E0B00000 00000000
	buffer_gl0_inv                                             // 0000004755F4: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 0000004755FC: BE852001
	s_cbranch_execz 28                                         // 000000475600: BFA5001C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d74>
	s_lshl_b32 s6, s2, 7                                       // 000000475604: 84068702
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 000000475608: CA220080 04020082
	s_ashr_i32 s7, s6, 31                                      // 000000475610: 86079F06
	s_ashr_i32 s27, s26, 31                                    // 000000475614: 861B9F1A
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000475618: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000047561C: BF8700B9
	s_add_u32 s1, s16, s6                                      // 000000475620: 80010610
	s_addc_u32 s6, s17, s7                                     // 000000475624: 82060711
	.long 0xd7000101                                           // 000000475628: D7000101
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 00000047562C: 02020601
	v_add_co_ci_u32_e64 v2, null, s6, 0, s1                    // 000000475630: D5207C02 00050006
	s_lshl_b64 s[6:7], s[26:27], 2                             // 000000475638: 8486821A
	global_load_b32 v5, v[1:2], off glc                        // 00000047563C: DC524000 057C0001
	.long 0xd7006a01                                           // 000000475644: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000475648: 02000D01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000047564C: BF8704A1
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000475650: D5207C02 01AA0407
	s_add_i32 s33, s33, -1                                     // 000000475658: 8121C121
	s_cmp_eq_u32 s33, 0                                        // 00000047565C: BF068021
	s_waitcnt vmcnt(0)                                         // 000000475660: BF8903F7
	v_add_f32_e32 v4, v4, v5                                   // 000000475664: 06080B04
	s_cbranch_scc0 65524                                       // 000000475668: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d3c>
	ds_store_b32 v3, v4 offset:4096                            // 00000047566C: D8341000 00000403
	s_or_b32 exec_lo, exec_lo, s5                              // 000000475674: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 000000475678: BE812004
	s_cbranch_execz 6                                          // 00000047567C: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d98>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 000000475680: 84848202
	v_mov_b32_e32 v1, 0                                        // 000000475684: 7E020280
	s_add_u32 s4, s18, s4                                      // 000000475688: 80040412
	s_addc_u32 s5, s19, s5                                     // 00000047568C: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 000000475690: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000475698: 8C7E017E
	s_cbranch_execz 65384                                      // 00000047569C: BFA5FF68 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b40>
	s_branch 1                                                 // 0000004756A0: BFA00001 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1da8>
	s_branch 65382                                             // 0000004756A4: BFA0FF66 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b40>
	v_cmp_eq_u32_e32 vcc_lo, 0, v8                             // 0000004756A8: 7C941080
	s_cmp_gt_i32 s24, 0                                        // 0000004756AC: BF028018
	s_waitcnt lgkmcnt(0)                                       // 0000004756B0: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000004756B4: BC7C0000
	s_cselect_b32 s1, -1, 0                                    // 0000004756B8: 980180C1
	s_barrier                                                  // 0000004756BC: BFBD0000
	s_and_b32 s1, vcc_lo, s1                                   // 0000004756C0: 8B01016A
	buffer_gl0_inv                                             // 0000004756C4: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 0000004756CC: BE832001
	s_cbranch_execz 65371                                      // 0000004756D0: BFA5FF5B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b40>
	v_and_b32_e32 v1, 15, v0                                   // 0000004756D4: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004756D8: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000004756DC: 30040282
	v_add_nc_u32_e32 v8, 0x1000, v2                            // 0000004756E0: 4A1004FF 00001000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000004756E8: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000004756F0: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000004756F8: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000475700: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000475708: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000047570C: 36160082
	s_waitcnt lgkmcnt(3)                                       // 000000475710: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 000000475714: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 00000047571C: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000475720: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000475728: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000047572C: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000475734: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000475738: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000475740: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000475748: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000047574C: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000475750: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 000000475758: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000475760: 7C941480
	.long 0xd44a0001                                           // 000000475764: D44A0001
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 000000475768: 02021680
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 00000047576C: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000475774: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000475778: 08101D09
	.long 0xd44a0003                                           // 00000047577C: D44A0003
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000475780: 02021880
	s_delay_alu instid0(VALU_DEP_3)                            // 000000475784: BF870003
	v_dual_add_f32 v9, v13, v4 :: v_dual_sub_f32 v10, v2, v6   // 000000475788: C90A090D 090A0D02
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000475790: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000475798: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 00000047579C: 060A0D02
	v_mov_b32_dpp v2, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004757A0: 7E0402FA FF016107
	v_cndmask_b32_e64 v6, -v7, v7, vcc_lo                      // 0000004757A8: D5010006 21AA0F07
	v_mov_b32_dpp v7, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004757B0: 7E0E02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000004757B8: D5010009 21AA1309
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004757C0: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004757C8: D5010005 21AA0B05
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004757D0: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000004757D8: D501000D 21AA1B0D
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004757E0: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000004757E8: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004757F0: 7E2202FA FF016104
	v_cndmask_b32_e64 v18, -v4, v4, vcc_lo                     // 0000004757F8: D5010012 21AA0904
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000475800: 7E2602FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 000000475808: D5010014 21AA0703
	v_dual_add_f32 v3, v9, v7 :: v_dual_add_f32 v2, v6, v2     // 000000475810: C9080F09 03020506
	v_dual_add_f32 v4, v5, v15 :: v_dual_add_f32 v7, v8, v16   // 000000475818: C9081F05 04062108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000475820: BF870192
	v_cndmask_b32_e64 v8, -v3, v3, s1                          // 000000475824: D5010008 20060703
	v_mov_b32_dpp v6, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047582C: 7E0C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000475834: D5010002 20060502
	v_mov_b32_dpp v3, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047583C: 7E0602FA FF016203
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000475844: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 00000047584C: D5010004 20060904
	v_add_f32_e32 v5, v13, v14                                 // 000000475854: 060A1D0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000475858: BF870224
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v8, v3     // 00000047585C: C9080D02 02020708
	v_mov_b32_dpp v13, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000475864: 7E1A02FA FF016207
	v_add_f32_e32 v4, v4, v11                                  // 00000047586C: 06081704
	s_delay_alu instid0(VALU_DEP_4)                            // 000000475870: BF870004
	v_mov_b32_dpp v9, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000475874: 7E1202FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 00000047587C: D5010005 20060B05
	v_mov_b32_dpp v6, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000475884: 7E0C02FA FF016402
	v_cndmask_b32_e64 v8, -v3, v3, s3                          // 00000047588C: D5010008 200E0703
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000475894: D5010002 200E0502
	v_mov_b32_dpp v11, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047589C: 7E1602FA FF016403
	v_add_f32_e32 v5, v5, v9                                   // 0000004758A4: 060A1305
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004758A8: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000004758B0: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004758B8: BF870214
	v_dual_add_f32 v3, v2, v6 :: v_dual_add_f32 v6, v8, v11    // 0000004758BC: C9080D02 03061708
	v_mov_b32_dpp v8, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004758C4: 7E1002FA FF016405
	v_cndmask_b32_e64 v11, -v5, v5, s3                         // 0000004758CC: D501000B 200E0B05
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004758D4: BF870004
	v_add_f32_e32 v4, v4, v9                                   // 0000004758D8: 06081304
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004758DC: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000004758E4: D501000A 21AA150A
	v_add_f32_e32 v12, v18, v17                                // 0000004758EC: 06182312
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000004758F0: D5010007 20060F07
	v_add_f32_e32 v14, v20, v19                                // 0000004758F8: 061C2714
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004758FC: 7E0402FA FF016803
	v_add_f32_e32 v9, v10, v9                                  // 000000475904: 0612130A
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000475908: 7E0A02FA FF016806
	v_add_f32_e32 v13, v7, v13                                 // 000000475910: 061A1B07
	v_mov_b32_dpp v15, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000475914: 7E1E02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 00000047591C: D501000E 20061D0E
	v_mov_b32_dpp v16, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000475924: 7E2002FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 00000047592C: D5010009 20061309
	v_add_f32_e32 v7, v11, v8                                  // 000000475934: 060E110B
	v_mov_b32_dpp v10, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000475938: 7E1402FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000475940: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000475948: BF870114
	v_dual_add_f32 v8, v14, v15 :: v_dual_add_f32 v9, v9, v16  // 00000047594C: C9081F0E 08082109
	v_add_f32_e32 v10, v12, v10                                // 000000475954: 0614150C
	v_mov_b32_dpp v11, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000475958: 7E1602FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000475960: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000475968: BF870004
	v_mov_b32_dpp v15, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047596C: 7E1E02FA FF016408
	v_mov_b32_dpp v17, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000475974: 7E2202FA FF016409
	v_mov_b32_dpp v12, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047597C: 7E1802FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000475984: D501000A 200E150A
	v_cndmask_b32_e64 v18, -v8, v8, s3                         // 00000047598C: D5010012 200E1108
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000475994: D5010009 200E1309
	v_add_f32_e32 v14, v13, v11                                // 00000047599C: 061C170D
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004759A0: 7E1002FA FF016807
	v_add_f32_e32 v16, v10, v12                                // 0000004759A8: 0620190A
	v_add_f32_e32 v15, v18, v15                                // 0000004759AC: 061E1F12
	v_add_f32_e32 v17, v9, v17                                 // 0000004759B0: 06222309
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004759B4: 7E1202FA FF016804
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004759BC: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004759C4: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004759CC: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004759D4: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 0000004759DC: 8B7E007E
	s_cbranch_execz 65175                                      // 0000004759E0: BFA5FE97 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b40>
	v_lshl_or_b32 v18, s2, 7, v1                               // 0000004759E4: D6560012 04050E02
	v_and_b32_e32 v0, 8, v0                                    // 0000004759EC: 36000088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004759F0: BF870092
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000004759F4: 3426249F
	.long 0xd73c0012                                           // 0000004759F8: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004759FC: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000475A00: BF870091
	.long 0xd7006a14                                           // 000000475A04: D7006A14
	v_cndmask_b32_e32 v1, s14, v18, vcc_lo                     // 000000475A08: 0202240E
	v_add_co_ci_u32_e64 v21, null, s15, v19, vcc_lo            // 000000475A0C: D5207C15 01AA260F
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000475A14: 7C940080
	s_clause 0x7                                               // 000000475A18: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000475A1C: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000475A24: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 000000475A2C: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 000000475A34: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 000000475A3C: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 000000475A44: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 000000475A4C: DC8200C0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:224          // 000000475A54: DC8200E0 147C0014
	.long 0x7f2a3880                                           // 000000475A5C: 7F2A3880
	v_cndmask_b32_e64 v0, -v6, v6, vcc_lo                      // 000000475A60: D5010000 21AA0D06
	v_cndmask_b32_e64 v1, -v3, v3, vcc_lo                      // 000000475A68: D5010001 21AA0703
	v_cndmask_b32_e64 v3, -v4, v4, vcc_lo                      // 000000475A70: D5010003 21AA0904
	v_cndmask_b32_e64 v4, -v7, v7, vcc_lo                      // 000000475A78: D5010004 21AA0F07
	v_cndmask_b32_e64 v7, -v14, v14, vcc_lo                    // 000000475A80: D5010007 21AA1D0E
	v_add_f32_e32 v0, v0, v5                                   // 000000475A88: 06000B00
	v_cndmask_b32_e64 v5, -v16, v16, vcc_lo                    // 000000475A8C: D5010005 21AA2110
	v_add_f32_e32 v3, v3, v9                                   // 000000475A94: 06061303
	s_waitcnt vmcnt(7)                                         // 000000475A98: BF891FF7
	.long 0x7f2c3995                                           // 000000475A9C: 7F2C3995
	v_dual_add_f32 v7, v7, v10 :: v_dual_mul_f32 v16, 0x3db504f3, v0// 000000475AA0: C9061507 071000FF 3DB504F3
	v_add_f32_e32 v5, v5, v11                                  // 000000475AAC: 060A1705
	v_cndmask_b32_e64 v14, -v17, v17, vcc_lo                   // 000000475AB0: D501000E 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000475AB8: D501000F 21AA1F0F
	v_add_f32_e32 v2, v1, v2                                   // 000000475AC0: 06040501
	v_dual_add_f32 v4, v4, v8 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 000000475AC4: C9061104 040206FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000475AD0: BF870193
	v_dual_add_f32 v9, v14, v13 :: v_dual_add_f32 v8, v15, v12 // 000000475AD4: C9081B0E 0908190F
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 000000475ADC: C8C60AFF 050204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000475AE8: BF870193
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000475AEC: C8C60EFF 070408FF 3DB504F3
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000475AF8: 101212FF 3DB504F3
	s_waitcnt vmcnt(6)                                         // 000000475B00: BF891BF7
	.long 0x7f2e3995                                           // 000000475B04: 7F2E3995
	.long 0x7f0c3995                                           // 000000475B08: 7F0C3995
	s_waitcnt vmcnt(0)                                         // 000000475B0C: BF8903F7
	.long 0x7f283995                                           // 000000475B10: 7F283995
	.long 0xd7006a00                                           // 000000475B14: D7006A00
	v_cndmask_b32_e32 v1, s28, v18, vcc_lo                     // 000000475B18: 0202241C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000475B1C: BF870001
	v_add_co_ci_u32_e64 v1, null, s29, v19, vcc_lo             // 000000475B20: D5207C01 01AA261D
	v_fma_mix_f32 v10, v22, v16, neg(0) op_sel_hi:[1,0,0]      // 000000475B28: CC20000A 8A022116
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 000000475B30: CC200002 8A020517
	v_fma_mix_f32 v4, v24, v4, neg(0) op_sel_hi:[1,0,0]        // 000000475B38: CC200004 8A020918
	v_fma_mix_f32 v3, v25, v3, neg(0) op_sel_hi:[1,0,0]        // 000000475B40: CC200003 8A020719
	v_fma_mix_f32 v7, v26, v7, neg(0) op_sel_hi:[1,0,0]        // 000000475B48: CC200007 8A020F1A
	.long 0x7e2a398a                                           // 000000475B50: 7E2A398A
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000475B54: 101010FF 3DB504F3
	v_fma_mix_f32 v5, v27, v5, neg(0) op_sel_hi:[1,0,0]        // 000000475B5C: CC200005 8A020B1B
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 000000475B64: CC200009 8A021314
	.long 0x7e0c3982                                           // 000000475B6C: 7E0C3982
	v_and_b32_e32 v11, 1, v21                                  // 000000475B70: 36162A81
	.long 0x7e2a3983                                           // 000000475B74: 7E2A3983
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000475B78: CC200008 8A02111C
	.long 0x7e283984                                           // 000000475B80: 7E283984
	.long 0x7e2c3987                                           // 000000475B84: 7E2C3987
	v_and_b32_e32 v6, 1, v6                                    // 000000475B88: 360C0C81
	v_and_b32_e32 v12, 1, v21                                  // 000000475B8C: 36182A81
	.long 0x7e2a3985                                           // 000000475B90: 7E2A3985
	.long 0x7e2e3988                                           // 000000475B94: 7E2E3988
	v_and_b32_e32 v13, 1, v20                                  // 000000475B98: 361A2881
	v_and_b32_e32 v14, 1, v22                                  // 000000475B9C: 361C2C81
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000475BA0: D6550002 03FE0D02 00007FFF
	v_and_b32_e32 v15, 1, v21                                  // 000000475BAC: 361E2A81
	.long 0x7e2a3989                                           // 000000475BB0: 7E2A3989
	v_and_b32_e32 v16, 1, v23                                  // 000000475BB4: 36202E81
	v_add3_u32 v10, v10, v11, 0x7fff                           // 000000475BB8: D655000A 03FE170A 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 000000475BC4: D6550004 03FE1B04 00007FFF
	v_add3_u32 v3, v3, v12, 0x7fff                             // 000000475BD0: D6550003 03FE1903 00007FFF
	v_and_b32_e32 v6, 1, v21                                   // 000000475BDC: 360C2A81
	v_add3_u32 v7, v7, v14, 0x7fff                             // 000000475BE0: D6550007 03FE1D07 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 000000475BEC: D6550008 03FE2108 00007FFF
	v_add3_u32 v5, v5, v15, 0x7fff                             // 000000475BF8: D6550005 03FE1F05 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000475C04: BF870004
	v_add3_u32 v6, v9, v6, 0x7fff                              // 000000475C08: D6550006 03FE0D09 00007FFF
	s_clause 0x7                                               // 000000475C14: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000475C18: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v10, off offset:32         // 000000475C20: DC960020 007C0A00
	global_store_d16_hi_b16 v[0:1], v4, off offset:64          // 000000475C28: DC960040 007C0400
	global_store_d16_hi_b16 v[0:1], v3, off offset:96          // 000000475C30: DC960060 007C0300
	global_store_d16_hi_b16 v[0:1], v7, off offset:128         // 000000475C38: DC960080 007C0700
	global_store_d16_hi_b16 v[0:1], v5, off offset:160         // 000000475C40: DC9600A0 007C0500
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 000000475C48: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v6, off offset:224         // 000000475C50: DC9600E0 007C0600
	s_endpgm                                                   // 000000475C58: BFB00000
		...

