000000000035be00 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 00000035BE00: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 00000035BE04: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 00000035BE0C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 00000035BE14: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 00000035BE1C: F4000180 F8000118
	v_lshrrev_b32_e32 v50, 5, v0                               // 00000035BE24: 32640085
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v51, 31, v0         // 00000035BE28: CA240080 0632009F
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v5, 0              // 00000035BE30: CA100080 34040080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 00000035BE38: CA100080 24240080
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v8, 0               // 00000035BE40: CA100080 07080080
	v_mov_b32_e32 v68, 0                                       // 00000035BE48: 7E880280
	s_waitcnt lgkmcnt(0)                                       // 00000035BE4C: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 00000035BE50: BF028103
	s_cselect_b32 s7, -1, 0                                    // 00000035BE54: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000035BE58: BF030402
	s_cselect_b32 s4, -1, 0                                    // 00000035BE5C: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035BE60: BF870009
	s_and_b32 s4, s7, s4                                       // 00000035BE64: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000035BE68: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 00000035BE6C: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 00000035BE74: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000035BE78: BF030502
	s_cselect_b32 s5, -1, 0                                    // 00000035BE7C: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035BE80: BF870009
	s_and_b32 s4, s7, s5                                       // 00000035BE84: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000035BE88: BF028303
	v_readfirstlane_b32 s5, v1                                 // 00000035BE8C: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 00000035BE90: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 00000035BE94: BF030602
	s_cselect_b32 s6, -1, 0                                    // 00000035BE98: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035BE9C: BF870009
	s_and_b32 s3, s3, s6                                       // 00000035BEA0: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 00000035BEA4: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 00000035BEA8: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 00000035BEAC: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 00000035BEB0: 98030483
	s_load_b128 s[4:7], s[0:1], 0x128                          // 00000035BEB4: F4080100 F8000128
	s_mulk_i32 s3, 0x48                                        // 00000035BEBC: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035BEC0: BF870009
	s_add_u32 s10, s0, s3                                      // 00000035BEC4: 800A0300
	s_addc_u32 s11, s1, 0                                      // 00000035BEC8: 820B8001
	s_clause 0x2                                               // 00000035BECC: BF850002
	s_load_b32 s12, s[10:11], 0x40                             // 00000035BED0: F4000305 F8000040
	s_load_b64 s[0:1], s[10:11], null                          // 00000035BED8: F4040005 F8000000
	s_load_b64 s[8:9], s[10:11], 0x30                          // 00000035BEE0: F4040205 F8000030
	s_mov_b32 s3, 0                                            // 00000035BEE8: BE830080
	s_waitcnt lgkmcnt(0)                                       // 00000035BEEC: BF89FC07
	s_ashr_i32 s18, s7, 31                                     // 00000035BEF0: 86129F07
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035BEF4: BF870009
	s_lshr_b32 s13, s18, 27                                    // 00000035BEF8: 850D9B12
	s_sub_i32 s2, s2, s12                                      // 00000035BEFC: 81820C02
	s_add_u32 s12, s6, s13                                     // 00000035BF00: 800C0D06
	s_addc_u32 s13, s7, 0                                      // 00000035BF04: 820D8007
	v_dual_mov_b32 v2, s1 :: v_dual_mov_b32 v1, s0             // 00000035BF08: CA100001 02000000
	s_lshr_b64 s[16:17], s[12:13], 5                           // 00000035BF10: 8590850C
	.long 0xd4510001                                           // 00000035BF14: D4510001
	v_cndmask_b32_e32 v0, s2, v8, vcc_lo                       // 00000035BF18: 02001002
	s_add_i32 s12, s16, 7                                      // 00000035BF1C: 810C8710
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000035BF20: BF870499
	s_ashr_i32 s13, s12, 31                                    // 00000035BF24: 860D9F0C
	s_lshr_b32 s13, s13, 29                                    // 00000035BF28: 850D9D0D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035BF2C: BF870009
	s_add_i32 s12, s12, s13                                    // 00000035BF30: 810C0D0C
	s_lshr_b32 s13, s7, 31                                     // 00000035BF34: 850D9F07
	s_ashr_i32 s17, s12, 3                                     // 00000035BF38: 8611830C
	s_add_u32 s12, s6, s13                                     // 00000035BF3C: 800C0D06
	s_addc_u32 s13, s7, 0                                      // 00000035BF40: 820D8007
	s_lshr_b32 s14, s18, 30                                    // 00000035BF44: 850E9E12
	s_ashr_i64 s[12:13], s[12:13], 1                           // 00000035BF48: 868C810C
	s_add_u32 s14, s6, s14                                     // 00000035BF4C: 800E0E06
	s_addc_u32 s15, s7, 0                                      // 00000035BF50: 820F8007
	s_lshr_b32 s18, s18, 28                                    // 00000035BF54: 85129C12
	s_ashr_i64 s[14:15], s[14:15], 2                           // 00000035BF58: 868E820E
	s_add_u32 s18, s6, s18                                     // 00000035BF5C: 80121206
	s_addc_u32 s19, s7, 0                                      // 00000035BF60: 82138007
	.long 0xd72c0003                                           // 00000035BF64: D72C0003
	v_cndmask_b32_e32 v1, s17, v50, vcc_lo                     // 00000035BF68: 02026411
	s_ashr_i64 s[18:19], s[18:19], 4                           // 00000035BF6C: 86928412
	s_add_u32 s20, s14, s12                                    // 00000035BF70: 80140C0E
	s_addc_u32 s21, s15, s13                                   // 00000035BF74: 82150D0F
	s_add_u32 s18, s20, s18                                    // 00000035BF78: 80121214
	s_addc_u32 s19, s21, s19                                   // 00000035BF7C: 82131315
	s_add_u32 s18, s18, 15                                     // 00000035BF80: 80128F12
	s_addc_u32 s19, s19, 0                                     // 00000035BF84: 82138013
	v_add_nc_u32_e32 v4, s17, v3                               // 00000035BF88: 4A080611
	s_ashr_i32 s0, s19, 31                                     // 00000035BF8C: 86009F13
	v_add_nc_u32_e32 v53, v3, v51                              // 00000035BF90: 4A6A6703
	s_lshr_b32 s0, s0, 28                                      // 00000035BF94: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035BF98: BF870009
	s_add_u32 s0, s18, s0                                      // 00000035BF9C: 80000012
	s_addc_u32 s17, s19, 0                                     // 00000035BFA0: 82118013
	s_and_b32 s0, s0, -16                                      // 00000035BFA4: 8B00D000
	s_and_b32 s1, s1, exec_lo                                  // 00000035BFA8: 8B017E01
	s_cselect_b32 s1, s2, 0                                    // 00000035BFAC: 98018002
	v_min_i32_e32 v54, s16, v4                                 // 00000035BFB0: 226C0810
	v_mad_u64_u32 v[33:34], null, s0, s1, v[1:2]               // 00000035BFB4: D6FE7C21 04040200
	s_mul_i32 s17, s17, s1                                     // 00000035BFBC: 96110111
	v_cmp_lt_i32_e32 vcc_lo, v53, v54                          // 00000035BFC0: 7C826D35
	v_add_nc_u32_e32 v55, s17, v34                             // 00000035BFC4: 4A6E4411
	s_and_saveexec_b32 s1, vcc_lo                              // 00000035BFC8: BE81206A
	s_cbranch_execz 39                                         // 00000035BFCC: BFA50027 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x26c>
	v_lshlrev_b32_e32 v1, 4, v53                               // 00000035BFD0: 30026A84
	v_lshlrev_b32_e32 v4, 1, v53                               // 00000035BFD4: 30086A81
	v_lshlrev_b32_e32 v3, 3, v53                               // 00000035BFD8: 30066A83
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000035BFDC: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000035BFE0: 3404029F
	.long 0xd7000001                                           // 00000035BFE4: D7000001
	v_cndmask_b32_e32 v1, v33, v1, vcc_lo                      // 00000035BFE8: 02020321
	v_and_b32_e32 v8, -4, v4                                   // 00000035BFEC: 361008C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000035BFF0: BF870214
	v_ashrrev_i32_e32 v7, 31, v3                               // 00000035BFF4: 340E069F
	v_add_co_ci_u32_e64 v2, null, v55, v2, s0                  // 00000035BFF8: D5207C02 00020537
	.long 0xd7000005                                           // 00000035C000: D7000005
	v_cndmask_b32_e32 v0, v33, v12, vcc_lo                     // 00000035C004: 02001921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000035C008: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s13, v55, s0                 // 00000035C00C: D5207C06 00026E0D
	v_ashrrev_i32_e32 v11, 31, v8                              // 00000035C014: 3416109F
	.long 0xd7000009                                           // 00000035C018: D7000009
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 00000035C01C: 02001D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000035C020: BF8700A1
	v_add_co_ci_u32_e64 v10, null, s15, v6, s0                 // 00000035C024: D5207C0A 00020C0F
	.long 0xd7000003                                           // 00000035C02C: D7000003
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 00000035C030: 02020705
	v_add_co_ci_u32_e64 v4, null, v6, v7, s0                   // 00000035C034: D5207C04 00020F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035C03C: BF870094
	.long 0xd7000009                                           // 00000035C040: D7000009
	v_cndmask_b32_e32 v1, v9, v8, vcc_lo                       // 00000035C044: 02021109
	v_add_co_ci_u32_e64 v10, null, v10, v11, s0                // 00000035C048: D5207C0A 0002170A
	s_clause 0x2                                               // 00000035C050: BF850002
	global_load_b128 v[5:8], v[1:2], off                       // 00000035C054: DC5E0000 057C0001
	global_load_b64 v[36:37], v[3:4], off                      // 00000035C05C: DC560000 247C0003
	global_load_b32 v68, v[9:10], off                          // 00000035C064: DC520000 447C0009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000035C06C: 8C7E017E
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v57, 0             // 00000035C070: CA100080 38380080
	v_dual_mov_b32 v58, 0 :: v_dual_mov_b32 v59, 0             // 00000035C078: CA100080 3A3A0080
	s_and_saveexec_b32 s1, vcc_lo                              // 00000035C080: BE81206A
	s_cbranch_execz 831                                        // 00000035C084: BFA5033F <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0xf84>
	.long 0xd7006a3c                                           // 00000035C088: D7006A3C
	v_cndmask_b32_e32 v0, v33, v12, vcc_lo                     // 00000035C08C: 02001921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000035C090: BF8701A1
	v_add_co_ci_u32_e64 v61, null, s13, v55, vcc_lo            // 00000035C094: D5207C3D 01AA6E0D
	v_dual_mov_b32 v52, 0 :: v_dual_add_nc_u32 v1, 32, v53     // 00000035C09C: CA200080 34006AA0
	.long 0xd7006a3e                                           // 00000035C0A4: D7006A3E
	v_cndmask_b32_e32 v0, v60, v14, vcc_lo                     // 00000035C0A8: 02001D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000035C0AC: BF870221
	v_add_co_ci_u32_e64 v63, null, s15, v61, vcc_lo            // 00000035C0B0: D5207C3F 01AA7A0F
	v_dual_mov_b32 v57, 0 :: v_dual_lshlrev_b32 v34, 5, v53    // 00000035C0B8: CA220080 39226A85
	v_dual_mov_b32 v59, 0 :: v_dual_lshlrev_b32 v64, 4, v1     // 00000035C0C0: CA220080 3B400284
	v_dual_mov_b32 v56, 0 :: v_dual_lshlrev_b32 v65, 3, v1     // 00000035C0C8: CA220080 38400283
	s_waitcnt vmcnt(0)                                         // 00000035C0D0: BF8903F7
	v_dual_mov_b32 v67, v68 :: v_dual_lshlrev_b32 v66, 1, v1   // 00000035C0D4: CA220144 43420281
	v_mov_b32_e32 v58, 0                                       // 00000035C0DC: 7E740280
	s_mul_i32 s0, s7, 6                                        // 00000035C0E0: 96008607
	s_mul_hi_u32 s14, s6, 6                                    // 00000035C0E4: 968E8606
	s_lshl_b64 s[12:13], s[6:7], 2                             // 00000035C0E8: 848C8206
	s_add_i32 s14, s14, s0                                     // 00000035C0EC: 810E000E
	s_mul_i32 s16, s6, 6                                       // 00000035C0F0: 96108606
	s_mov_b32 s15, 0                                           // 00000035C0F4: BE8F0080
	s_lshl_b64 s[6:7], s[6:7], 1                               // 00000035C0F8: 84868106
	s_branch 761                                               // 00000035C0FC: BFA002F9 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0xee4>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000035C100: 8C7E117E
	v_lshlrev_b32_e32 v11, 4, v36                              // 00000035C104: 30164884
	v_lshlrev_b32_e32 v13, 2, v36                              // 00000035C108: 301A4882
	v_lshrrev_b32_e32 v15, 4, v5                               // 00000035C10C: 321E0A84
	v_lshrrev_b32_e32 v16, 8, v5                               // 00000035C110: 32200A88
	v_lshrrev_b32_e32 v17, 2, v36                              // 00000035C114: 32224882
	v_and_b32_e32 v14, 48, v11                                 // 00000035C118: 361C16B0
	v_and_b32_e32 v13, 48, v13                                 // 00000035C11C: 361A1AB0
	v_and_b32_e32 v18, 48, v36                                 // 00000035C120: 362448B0
	v_lshrrev_b32_e32 v19, 12, v5                              // 00000035C124: 32260A8C
	v_and_b32_e32 v17, 48, v17                                 // 00000035C128: 362222B0
	v_and_or_b32 v14, v5, 15, v14                              // 00000035C12C: D657000E 04391F05
	v_and_or_b32 v20, v15, 15, v13                             // 00000035C134: D6570014 04351F0F
	v_and_or_b32 v18, v16, 15, v18                             // 00000035C13C: D6570012 04491F10
	v_ashrrev_i32_e32 v35, 31, v34                             // 00000035C144: 3446449F
	v_and_or_b32 v17, v19, 15, v17                             // 00000035C148: D6570011 04451F13
	v_cvt_f32_ubyte0_e32 v21, v14                              // 00000035C150: 7E2A230E
	v_cvt_f32_ubyte0_e32 v19, v20                              // 00000035C154: 7E262314
	v_cvt_f32_ubyte0_e32 v18, v18                              // 00000035C158: 7E242312
	.long 0xd73c0009                                           // 00000035C15C: D73C0009
	v_cndmask_b32_e32 v1, 1, v34, vcc_lo                       // 00000035C160: 02024481
	v_cvt_f32_ubyte0_e32 v17, v17                              // 00000035C164: 7E222311
	v_fma_mix_f32 v20, v21, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C168: CC206014 15128915
	v_fma_mix_f32 v19, v19, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C170: CC206013 15128913
	v_fma_mix_f32 v18, v18, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C178: CC206012 15128912
	.long 0x7f463880                                           // 00000035C180: 7F463880
	v_fma_mix_f32 v17, v17, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C184: CC206011 15128911
	v_bfe_u32 v25, v20, 16, 1                                  // 00000035C18C: D6100019 02052114
	v_bfe_u32 v26, v19, 16, 1                                  // 00000035C194: D610001A 02052113
	v_lshrrev_b32_e32 v69, 4, v36                              // 00000035C19C: 328A4884
	v_lshrrev_b32_e32 v72, 6, v36                              // 00000035C1A0: 32904886
	v_bfe_u32 v29, v17, 16, 1                                  // 00000035C1A4: D610001D 02052111
	v_add3_u32 v20, v20, v25, 0x7fff                           // 00000035C1AC: D6550014 03FE3314 00007FFF
	v_bfe_u32 v25, v18, 16, 1                                  // 00000035C1B8: D6100019 02052112
	v_add3_u32 v19, v19, v26, 0x7fff                           // 00000035C1C0: D6550013 03FE3513 00007FFF
	v_and_b32_e32 v73, 48, v69                                 // 00000035C1CC: 36928AB0
	v_add3_u32 v70, v17, v29, 0x7fff                           // 00000035C1D0: D6550046 03FE3B11 00007FFF
	.long 0x7e463994                                           // 00000035C1DC: 7E463994
	v_add3_u32 v18, v18, v25, 0x7fff                           // 00000035C1E0: D6550012 03FE3312 00007FFF
	v_lshrrev_b32_e32 v74, 20, v5                              // 00000035C1EC: 32940A94
	v_lshrrev_b32_e32 v75, 24, v5                              // 00000035C1F0: 32960A98
	v_and_b32_e32 v72, 48, v72                                 // 00000035C1F4: 369090B0
	v_and_or_b32 v71, 0xffff0000, v19, v35                     // 00000035C1F8: D6570047 048E26FF FFFF0000
	.long 0x7e463992                                           // 00000035C204: 7E463992
	v_lshrrev_b32_e32 v76, 10, v36                             // 00000035C208: 3298488A
	v_lshrrev_b32_e32 v81, 22, v36                             // 00000035C20C: 32A24896
	v_and_or_b32 v72, v74, 15, v72                             // 00000035C210: D6570048 05211F4A
	v_lshrrev_b32_e32 v82, 24, v6                              // 00000035C218: 32A40C98
	v_and_or_b32 v69, 0xffff0000, v70, v35                     // 00000035C21C: D6570045 048E8CFF FFFF0000
	.long 0x7e463985                                           // 00000035C228: 7E463985
	v_lshrrev_b32_e32 v70, 8, v36                              // 00000035C22C: 328C4888
	v_lshrrev_b32_e32 v5, 28, v5                               // 00000035C230: 320A0A9C
	v_cvt_f32_ubyte0_e32 v72, v72                              // 00000035C234: 7E902348
	v_lshlrev_b32_e32 v84, 4, v37                              // 00000035C238: 30A84A84
	v_and_or_b32 v73, v35, 15, v73                             // 00000035C23C: D6570049 05251F23
	v_and_b32_e32 v70, 48, v70                                 // 00000035C244: 368C8CB0
	v_and_or_b32 v5, v76, 48, v5                               // 00000035C248: D6570005 0415614C
	v_fma_mix_f32 v72, v72, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C250: CC206048 15128948
	v_lshrrev_b32_e32 v76, 8, v6                               // 00000035C258: 32980C88
	v_cvt_f32_ubyte0_e32 v73, v73                              // 00000035C25C: 7E922349
	v_and_or_b32 v70, v75, 15, v70                             // 00000035C260: D6570046 05191F4B
	v_cvt_f32_ubyte0_e32 v5, v5                                // 00000035C268: 7E0A2305
	v_bfe_u32 v75, v72, 16, 1                                  // 00000035C26C: D610004B 02052148
	v_lshrrev_b32_e32 v88, 8, v7                               // 00000035C274: 32B00E88
	v_fma_mix_f32 v73, v73, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C278: CC206049 15128949
	v_cvt_f32_ubyte0_e32 v70, v70                              // 00000035C280: 7E8C2346
	v_fma_mix_f32 v5, v5, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C284: CC206005 15128905
	v_add3_u32 v72, v72, v75, 0x7fff                           // 00000035C28C: D6550048 03FE9748 00007FFF
	v_lshrrev_b32_e32 v75, 12, v6                              // 00000035C298: 32960C8C
	v_bfe_u32 v74, v73, 16, 1                                  // 00000035C29C: D610004A 02052149
	v_fma_mix_f32 v70, v70, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C2A4: CC206046 15128946
	v_bfe_u32 v80, v5, 16, 1                                   // 00000035C2AC: D6100050 02052105
	v_and_b32_e32 v81, 48, v81                                 // 00000035C2B4: 36A2A2B0
	v_lshrrev_b32_e32 v77, 12, v36                             // 00000035C2B8: 329A488C
	v_add3_u32 v73, v73, v74, 0x7fff                           // 00000035C2BC: D6550049 03FE9549 00007FFF
	v_bfe_u32 v74, v70, 16, 1                                  // 00000035C2C8: D610004A 02052146
	v_add3_u32 v5, v5, v80, 0x7fff                             // 00000035C2D0: D6550005 03FEA105 00007FFF
	v_lshrrev_b32_e32 v80, 20, v6                              // 00000035C2DC: 32A00C94
	v_lshrrev_b32_e32 v79, 14, v36                             // 00000035C2E0: 329E488E
	.long 0x7e4639c9                                           // 00000035C2E4: 7E4639C9
	v_add3_u32 v73, v70, v74, 0x7fff                           // 00000035C2E8: D6550049 03FE9546 00007FFF
	v_lshrrev_b32_e32 v74, 20, v36                             // 00000035C2F4: 32944894
	v_lshrrev_b32_e32 v83, 28, v6                              // 00000035C2F8: 32A60C9C
	v_lshlrev_b32_e32 v87, 2, v37                              // 00000035C2FC: 30AE4A82
	v_and_or_b32 v70, 0xffff0000, v72, v35                     // 00000035C300: D6570046 048E90FF FFFF0000
	.long 0x7e4639c9                                           // 00000035C30C: 7E4639C9
	v_lshrrev_b32_e32 v72, 18, v36                             // 00000035C310: 32904892
	v_lshrrev_b32_e32 v73, 24, v36                             // 00000035C314: 32924898
	v_lshrrev_b32_e32 v90, 2, v37                              // 00000035C318: 32B44A82
	v_and_b32_e32 v84, 48, v84                                 // 00000035C31C: 36A8A8B0
	v_and_or_b32 v5, 0xffff0000, v5, v35                       // 00000035C320: D6570005 048E0AFF FFFF0000
	.long 0x7e4639a4                                           // 00000035C32C: 7E4639A4
	v_and_b32_e32 v72, 48, v72                                 // 00000035C330: 369090B0
	v_and_b32_e32 v73, 48, v73                                 // 00000035C334: 369292B0
	v_lshrrev_b32_e32 v36, 26, v36                             // 00000035C338: 3248489A
	v_and_or_b32 v80, v80, 15, v81                             // 00000035C33C: D6570050 05451F50
	v_and_b32_e32 v85, 48, v35                                 // 00000035C344: 36AA46B0
	v_and_or_b32 v72, v75, 15, v72                             // 00000035C348: D6570048 05211F4B
	v_and_or_b32 v73, v82, 15, v73                             // 00000035C350: D6570049 05251F52
	v_lshrrev_b32_e32 v86, 4, v7                               // 00000035C358: 32AC0E84
	v_lshrrev_b32_e32 v89, 12, v7                              // 00000035C35C: 32B20E8C
	v_and_or_b32 v76, v76, 15, v85                             // 00000035C360: D657004C 05551F4C
	v_cvt_f32_ubyte0_e32 v72, v72                              // 00000035C368: 7E902348
	v_and_b32_e32 v85, 48, v37                                 // 00000035C36C: 36AA4AB0
	v_and_or_b32 v36, v36, 48, v83                             // 00000035C370: D6570024 054D6124
	v_and_or_b32 v81, v7, 15, v84                              // 00000035C378: D6570051 05511F07
	v_cvt_f32_ubyte0_e32 v75, v76                              // 00000035C380: 7E96234C
	v_fma_mix_f32 v72, v72, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C384: CC206048 15128948
	v_cvt_f32_ubyte0_e32 v80, v80                              // 00000035C38C: 7EA02350
	v_cvt_f32_ubyte0_e32 v73, v73                              // 00000035C390: 7E922349
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000035C394: 7E482324
	v_fma_mix_f32 v75, v75, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C398: CC20604B 1512894B
	v_bfe_u32 v100, v72, 16, 1                                 // 00000035C3A0: D6100064 02052148
	v_cvt_f32_ubyte0_e32 v81, v81                              // 00000035C3A8: 7EA22351
	v_fma_mix_f32 v73, v73, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C3AC: CC206049 15128949
	v_fma_mix_f32 v36, v36, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C3B4: CC206024 15128924
	v_bfe_u32 v76, v75, 16, 1                                  // 00000035C3BC: D610004C 0205214B
	v_add3_u32 v72, v72, v100, 0x7fff                          // 00000035C3C4: D6550048 03FEC948 00007FFF
	v_fma_mix_f32 v81, v81, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C3D0: CC206051 15128951
	v_lshrrev_b32_e32 v92, 4, v37                              // 00000035C3D8: 32B84A84
	v_lshrrev_b32_e32 v91, 8, v37                              // 00000035C3DC: 32B64A88
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000035C3E0: D655004B 03FE994B 00007FFF
	v_and_or_b32 v76, v88, 15, v85                             // 00000035C3EC: D657004C 05551F58
	v_and_b32_e32 v85, 48, v87                                 // 00000035C3F4: 36AAAEB0
	v_lshrrev_b32_e32 v94, 6, v37                              // 00000035C3F8: 32BC4A86
	v_lshrrev_b32_e32 v93, 20, v7                              // 00000035C3FC: 32BA0E94
	.long 0x7e4639cb                                           // 00000035C400: 7E4639CB
	v_and_b32_e32 v75, 48, v74                                 // 00000035C404: 369694B0
	v_cvt_f32_ubyte0_e32 v76, v76                              // 00000035C408: 7E98234C
	v_and_or_b32 v82, v86, 15, v85                             // 00000035C40C: D6570052 05551F56
	v_bfe_u32 v85, v36, 16, 1                                  // 00000035C414: D6100055 02052124
	v_and_or_b32 v74, 0xffff0000, v72, v35                     // 00000035C41C: D657004A 048E90FF FFFF0000
	.long 0x7e463986                                           // 00000035C428: 7E463986
	v_and_b32_e32 v72, 48, v90                                 // 00000035C42C: 3690B4B0
	v_fma_mix_f32 v84, v76, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C430: CC206054 1512894C
	v_fma_mix_f32 v76, v80, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C438: CC20604C 15128950
	v_cvt_f32_ubyte0_e32 v82, v82                              // 00000035C440: 7EA42352
	v_and_or_b32 v75, v35, 15, v75                             // 00000035C444: D657004B 052D1F23
	v_and_or_b32 v72, v89, 15, v72                             // 00000035C44C: D6570048 05211F59
	v_add3_u32 v36, v36, v85, 0x7fff                           // 00000035C454: D6550024 03FEAB24 00007FFF
	v_bfe_u32 v86, v76, 16, 1                                  // 00000035C460: D6100056 0205214C
	v_fma_mix_f32 v82, v82, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C468: CC206052 15128952
	v_cvt_f32_ubyte0_e32 v75, v75                              // 00000035C470: 7E96234B
	v_cvt_f32_ubyte0_e32 v72, v72                              // 00000035C474: 7E902348
	v_and_b32_e32 v85, 48, v92                                 // 00000035C478: 36AAB8B0
	v_lshrrev_b32_e32 v95, 24, v7                              // 00000035C47C: 32BE0E98
	v_and_b32_e32 v89, 48, v91                                 // 00000035C480: 36B2B6B0
	v_fma_mix_f32 v75, v75, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C484: CC20604B 1512894B
	v_fma_mix_f32 v87, v72, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C48C: CC206057 15128948
	v_add3_u32 v72, v76, v86, 0x7fff                           // 00000035C494: D6550048 03FEAD4C 00007FFF
	v_lshrrev_b32_e32 v97, 28, v7                              // 00000035C4A0: 32C20E9C
	v_lshrrev_b32_e32 v98, 10, v37                             // 00000035C4A4: 32C44A8A
	v_bfe_u32 v80, v75, 16, 1                                  // 00000035C4A8: D6100050 0205214B
	v_and_or_b32 v89, v95, 15, v89                             // 00000035C4B0: D6570059 05651F5F
	.long 0xd7000030                                           // 00000035C4B8: D7000030
	v_cndmask_b32_e32 v1, s4, v9, vcc_lo                       // 00000035C4BC: 02021204
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000035C4C0: BF870211
	v_add_co_ci_u32_e64 v49, null, s5, v10, s0                 // 00000035C4C4: D5207C31 00021405
	v_add3_u32 v75, v75, v80, 0x7fff                           // 00000035C4CC: D655004B 03FEA14B 00007FFF
	v_bfe_u32 v80, v73, 16, 1                                  // 00000035C4D8: D6100050 02052149
	v_cvt_f32_ubyte0_e32 v89, v89                              // 00000035C4E0: 7EB22359
	.long 0xd700002c                                           // 00000035C4E4: D700002C
	v_cndmask_b32_e32 v0, v48, v6, vcc_lo                      // 00000035C4E8: 02000D30
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000035C4EC: BF870214
	.long 0x7e4639cb                                           // 00000035C4F0: 7E4639CB
	v_add3_u32 v73, v73, v80, 0x7fff                           // 00000035C4F4: D6550049 03FEA149 00007FFF
	v_bfe_u32 v75, v81, 16, 1                                  // 00000035C500: D610004B 02052151
	v_bfe_u32 v80, v82, 16, 1                                  // 00000035C508: D6100050 02052152
	v_fma_mix_f32 v89, v89, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C510: CC206059 15128959
	v_and_or_b32 v76, 0xffff0000, v72, v35                     // 00000035C518: D657004C 048E90FF FFFF0000
	.long 0x7e4639c9                                           // 00000035C524: 7E4639C9
	v_add3_u32 v73, v81, v75, 0x7fff                           // 00000035C528: D6550049 03FE9751 00007FFF
	v_bfe_u32 v75, v84, 16, 1                                  // 00000035C534: D610004B 02052154
	v_bfe_u32 v81, v87, 16, 1                                  // 00000035C53C: D6100051 02052157
	v_add3_u32 v80, v82, v80, 0x7fff                           // 00000035C544: D6550050 03FEA152 00007FFF
	v_and_or_b32 v72, 0xffff0000, v36, v35                     // 00000035C550: D6570048 048E48FF FFFF0000
	.long 0x7e4639c9                                           // 00000035C55C: 7E4639C9
	v_add3_u32 v36, v84, v75, 0x7fff                           // 00000035C560: D6550024 03FE9754 00007FFF
	v_add3_u32 v75, v87, v81, 0x7fff                           // 00000035C56C: D655004B 03FEA357 00007FFF
	v_and_b32_e32 v87, 48, v94                                 // 00000035C578: 36AEBCB0
	s_clause 0x1                                               // 00000035C57C: BF850001
	global_load_b128 v[29:32], v[48:49], off                   // 00000035C580: DC5E0000 1D7C0030
	global_load_b128 v[17:20], v[48:49], off offset:16         // 00000035C588: DC5E0010 117C0030
	v_and_or_b32 v73, 0xffff0000, v80, v35                     // 00000035C590: D6570049 048EA0FF FFFF0000
	.long 0x7e4639a4                                           // 00000035C59C: 7E4639A4
	v_add_co_ci_u32_e64 v45, null, s7, v49, s0                 // 00000035C5A0: D5207C2D 00026207
	v_and_or_b32 v87, v93, 15, v87                             // 00000035C5A8: D6570057 055D1F5D
	v_and_or_b32 v93, v98, 48, v97                             // 00000035C5B0: D657005D 05856162
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000035C5B8: BF870254
	v_and_or_b32 v75, 0xffff0000, v75, v35                     // 00000035C5BC: D657004B 048E96FF FFFF0000
	.long 0x7e463987                                           // 00000035C5C8: 7E463987
	.long 0xd700002a                                           // 00000035C5CC: D700002A
	v_cndmask_b32_e32 v0, v48, v12, vcc_lo                     // 00000035C5D0: 02001930
	v_cvt_f32_ubyte0_e32 v87, v87                              // 00000035C5D4: 7EAE2357
	v_cvt_f32_ubyte0_e32 v93, v93                              // 00000035C5D8: 7EBA235D
	v_and_or_b32 v85, v35, 15, v85                             // 00000035C5DC: D6570055 05551F23
	v_add_co_ci_u32_e64 v43, null, s13, v49, s0                // 00000035C5E4: D5207C2B 0002620D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000035C5EC: BF870214
	v_fma_mix_f32 v87, v87, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C5F0: CC206057 15128957
	v_fma_mix_f32 v93, v93, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C5F8: CC20605D 1512895D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000035C600: BF870004
	v_cvt_f32_ubyte0_e32 v85, v85                              // 00000035C604: 7EAA2355
	v_lshrrev_b32_e32 v78, 4, v6                               // 00000035C608: 329C0C84
	v_and_b32_e32 v77, 48, v77                                 // 00000035C60C: 369A9AB0
	v_bfe_u32 v95, v87, 16, 1                                  // 00000035C610: D610005F 02052157
	v_and_b32_e32 v79, 48, v79                                 // 00000035C618: 369E9EB0
	v_fma_mix_f32 v85, v85, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C61C: CC206055 15128955
	.long 0xd7000028                                           // 00000035C624: D7000028
	v_cndmask_b32_e32 v0, v48, v16, vcc_lo                     // 00000035C628: 02002130
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000035C62C: BF870224
	v_add3_u32 v87, v87, v95, 0x7fff                           // 00000035C630: D6550057 03FEBF57 00007FFF
	v_bfe_u32 v95, v93, 16, 1                                  // 00000035C63C: D610005F 0205215D
	v_bfe_u32 v94, v85, 16, 1                                  // 00000035C644: D610005E 02052155
	v_add_co_ci_u32_e64 v41, null, s14, v49, s0                // 00000035C64C: D5207C29 0002620E
	.long 0xd700002e                                           // 00000035C654: D700002E
	v_cndmask_b32_e32 v0, v42, v12, vcc_lo                     // 00000035C658: 0200192A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000035C65C: BF870243
	v_add3_u32 v85, v85, v94, 0x7fff                           // 00000035C660: D6550055 03FEBD55 00007FFF
	v_bfe_u32 v94, v89, 16, 1                                  // 00000035C66C: D610005E 02052159
	v_add3_u32 v93, v93, v95, 0x7fff                           // 00000035C674: D655005D 03FEBF5D 00007FFF
	v_add_co_ci_u32_e64 v47, null, s13, v43, s0                // 00000035C680: D5207C2F 0002560D
	.long 0x7e4639d5                                           // 00000035C688: 7E4639D5
	s_delay_alu instid0(VALU_DEP_4)                            // 00000035C68C: BF870004
	v_add3_u32 v85, v89, v94, 0x7fff                           // 00000035C690: D6550055 03FEBD59 00007FFF
	v_lshrrev_b32_e32 v84, 8, v8                               // 00000035C69C: 32A81088
	v_and_or_b32 v6, v6, 15, v77                               // 00000035C6A0: D6570006 05351F06
	v_and_or_b32 v77, v78, 15, v79                             // 00000035C6A8: D657004D 053D1F4E
	v_and_or_b32 v121, 0xffff0000, v87, v35                    // 00000035C6B0: D6570079 048EAEFF FFFF0000
	.long 0x7e4639d5                                           // 00000035C6BC: 7E4639D5
	s_clause 0x3                                               // 00000035C6C0: BF850003
	global_load_b128 v[9:12], v[44:45], off                    // 00000035C6C4: DC5E0000 097C002C
	global_load_b128 v[117:120], v[44:45], off offset:48       // 00000035C6CC: DC5E0030 757C002C
	global_load_b128 v[13:16], v[42:43], off                   // 00000035C6D4: DC5E0000 0D7C002A
	global_load_b128 v[21:24], v[40:41], off                   // 00000035C6DC: DC5E0000 157C0028
	v_and_or_b32 v123, 0xffff0000, v93, v35                    // 00000035C6E4: D657007B 048EBAFF FFFF0000
	.long 0x7e4639a5                                           // 00000035C6F0: 7E4639A5
	s_clause 0x1                                               // 00000035C6F4: BF850001
	global_load_b128 v[25:28], v[46:47], off                   // 00000035C6F8: DC5E0000 197C002E
	global_load_b128 v[113:116], v[46:47], off offset:32       // 00000035C700: DC5E0020 717C002E
	v_lshrrev_b32_e32 v82, 14, v37                             // 00000035C708: 32A44A8E
	v_lshrrev_b32_e32 v81, 18, v37                             // 00000035C70C: 32A24A92
	v_and_b32_e32 v78, 48, v35                                 // 00000035C710: 369C46B0
	v_lshrrev_b32_e32 v96, 12, v37                             // 00000035C714: 32C04A8C
	v_and_b32_e32 v99, 15, v8                                  // 00000035C718: 36C6108F
	v_lshrrev_b32_e32 v83, 4, v8                               // 00000035C71C: 32A61084
	v_lshrrev_b32_e32 v80, 12, v8                              // 00000035C720: 32A0108C
	v_and_or_b32 v78, v84, 15, v78                             // 00000035C724: D657004E 05391F54
	v_lshrrev_b32_e32 v88, 22, v37                             // 00000035C72C: 32B04A96
	v_and_b32_e32 v82, 48, v82                                 // 00000035C730: 36A4A4B0
	v_and_b32_e32 v81, 48, v81                                 // 00000035C734: 36A2A2B0
	v_lshrrev_b32_e32 v7, 24, v37                              // 00000035C738: 320E4A98
	v_cvt_f32_ubyte0_e32 v78, v78                              // 00000035C73C: 7E9C234E
	v_lshrrev_b32_e32 v86, 20, v8                              // 00000035C740: 32AC1094
	v_and_or_b32 v89, v96, 48, v99                             // 00000035C744: D6570059 058D6160
	v_and_b32_e32 v85, 48, v88                                 // 00000035C74C: 36AAB0B0
	v_and_or_b32 v79, v83, 15, v82                             // 00000035C750: D657004F 05491F53
	v_and_or_b32 v80, v80, 15, v81                             // 00000035C758: D6570050 05451F50
	v_cvt_f32_ubyte0_e32 v77, v77                              // 00000035C760: 7E9A234D
	v_fma_mix_f32 v78, v78, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C764: CC20604E 1512894E
	v_lshrrev_b32_e32 v90, 24, v8                              // 00000035C76C: 32B41098
	v_lshrrev_b32_e32 v91, 28, v8                              // 00000035C770: 32B6109C
	v_lshrrev_b32_e32 v92, 26, v37                             // 00000035C774: 32B84A9A
	v_and_b32_e32 v7, 48, v7                                   // 00000035C778: 360E0EB0
	v_cvt_f32_ubyte0_e32 v82, v89                              // 00000035C77C: 7EA42359
	v_and_or_b32 v81, v86, 15, v85                             // 00000035C780: D6570051 05551F56
	v_cvt_f32_ubyte0_e32 v6, v6                                // 00000035C788: 7E0C2306
	v_cvt_f32_ubyte0_e32 v102, v79                             // 00000035C78C: 7ECC234F
	v_cvt_f32_ubyte0_e32 v79, v80                              // 00000035C790: 7E9E2350
	v_fma_mix_f32 v104, v77, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C794: CC206068 1512894D
	v_bfe_u32 v77, v78, 16, 1                                  // 00000035C79C: D610004D 0205214E
	v_lshrrev_b32_e32 v36, 20, v37                             // 00000035C7A4: 32484A94
	v_and_or_b32 v37, v92, 48, v91                             // 00000035C7A8: D6570025 056D615C
	v_and_or_b32 v7, v90, 15, v7                               // 00000035C7B0: D6570007 041D1F5A
	v_fma_mix_f32 v124, v82, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C7B8: CC20607C 15128952
	v_cvt_f32_ubyte0_e32 v103, v81                             // 00000035C7C0: 7ECE2351
	v_fma_mix_f32 v6, v6, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C7C4: CC206006 15128906
	v_fma_mix_f32 v93, v79, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C7CC: CC20605D 1512894F
	v_add3_u32 v96, v78, v77, 0x7fff                           // 00000035C7D4: D6550060 03FE9B4E 00007FFF
	s_clause 0x3                                               // 00000035C7E0: BF850003
	global_load_b128 v[77:80], v[44:45], off offset:16         // 00000035C7E4: DC5E0010 4D7C002C
	global_load_b128 v[81:84], v[42:43], off offset:16         // 00000035C7EC: DC5E0010 517C002A
	global_load_b128 v[85:88], v[40:41], off offset:16         // 00000035C7F4: DC5E0010 557C0028
	global_load_b128 v[89:92], v[46:47], off offset:16         // 00000035C7FC: DC5E0010 597C002E
	v_bfe_u32 v105, v104, 16, 1                                // 00000035C804: D6100069 02052168
	v_bfe_u32 v94, v6, 16, 1                                   // 00000035C80C: D610005E 02052106
	v_bfe_u32 v95, v93, 16, 1                                  // 00000035C814: D610005F 0205215D
	.long 0x7e4639e0                                           // 00000035C81C: 7E4639E0
	.long 0x7fca39a3                                           // 00000035C820: 7FCA39A3
	v_and_b32_e32 v36, 48, v36                                 // 00000035C824: 364848B0
	v_add3_u32 v6, v6, v94, 0x7fff                             // 00000035C828: D6550006 03FEBD06 00007FFF
	v_add3_u32 v106, v93, v95, 0x7fff                          // 00000035C834: D655006A 03FEBF5D 00007FFF
	s_clause 0x1                                               // 00000035C840: BF850001
	global_load_b128 v[93:96], v[48:49], off offset:32         // 00000035C844: DC5E0020 5D7C0030
	global_load_b128 v[97:100], v[48:49], off offset:48        // 00000035C84C: DC5E0030 617C0030
	v_add3_u32 v48, v104, v105, 0x7fff                         // 00000035C854: D6550030 03FED368 00007FFF
	v_cvt_f32_ubyte0_e32 v37, v37                              // 00000035C860: 7E4A2325
	.long 0x7eca3986                                           // 00000035C864: 7ECA3986
	v_and_or_b32 v125, 0xffff0000, v106, v35                   // 00000035C868: D657007D 048ED4FF FFFF0000
	.long 0x7e463988                                           // 00000035C874: 7E463988
	v_fma_mix_f32 v8, v102, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C878: CC206008 15128966
	v_cvt_f32_ubyte0_e32 v7, v7                                // 00000035C880: 7E0E2307
	v_and_or_b32 v126, 0xffff0000, v48, v101                   // 00000035C884: D657007E 059660FF FFFF0000
	v_fma_mix_f32 v48, v103, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C890: CC206030 15128967
	v_and_or_b32 v36, v35, 15, v36                             // 00000035C898: D6570024 04911F23
	s_clause 0x2                                               // 00000035C8A0: BF850002
	global_load_b128 v[101:104], v[44:45], off offset:32       // 00000035C8A4: DC5E0020 657C002C
	global_load_b128 v[105:108], v[42:43], off offset:32       // 00000035C8AC: DC5E0020 697C002A
	global_load_b128 v[109:112], v[40:41], off offset:32       // 00000035C8B4: DC5E0020 6D7C0028
	v_fma_mix_f32 v37, v37, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C8BC: CC206025 15128925
	v_bfe_u32 v6, v124, 16, 1                                  // 00000035C8C4: D6100006 0205217C
	v_fma_mix_f32 v7, v7, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C8CC: CC206007 15128907
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000035C8D4: 7E482324
	v_bfe_u32 v44, v8, 16, 1                                   // 00000035C8D8: D610002C 02052108
	v_bfe_u32 v49, v37, 16, 1                                  // 00000035C8E0: D6100031 02052125
	v_add3_u32 v6, v124, v6, 0x7fff                            // 00000035C8E8: D6550006 03FE0D7C 00007FFF
	v_bfe_u32 v45, v48, 16, 1                                  // 00000035C8F4: D610002D 02052130
	v_fma_mix_f32 v36, v36, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035C8FC: CC206024 15128924
	v_add3_u32 v8, v8, v44, 0x7fff                             // 00000035C904: D6550008 03FE5908 00007FFF
	v_add3_u32 v68, v37, v49, 0x7fff                           // 00000035C910: D6550044 03FE6325 00007FFF
	v_bfe_u32 v37, v7, 16, 1                                   // 00000035C91C: D6100025 02052107
	.long 0x7ef43986                                           // 00000035C924: 7EF43986
	v_bfe_u32 v6, v36, 16, 1                                   // 00000035C928: D6100006 02052124
	v_add3_u32 v124, v48, v45, 0x7fff                          // 00000035C930: D655007C 03FE5B30 00007FFF
	global_load_b128 v[42:45], v[42:43], off offset:48         // 00000035C93C: DC5E0030 2A7C002A
	v_add3_u32 v7, v7, v37, 0x7fff                             // 00000035C944: D6550007 03FE4B07 00007FFF
	s_waitcnt vmcnt(19)                                        // 00000035C950: BF894FF7
	v_mov_b32_e32 v37, v39                                     // 00000035C954: 7E4A0327
	v_add3_u32 v6, v36, v6, 0x7fff                             // 00000035C958: D6550006 03FE0D24 00007FFF
	v_mov_b32_e32 v36, v38                                     // 00000035C964: 7E480326
	s_clause 0x1                                               // 00000035C968: BF850001
	global_load_b128 v[38:41], v[40:41], off offset:48         // 00000035C96C: DC5E0030 267C0028
	global_load_b128 v[46:49], v[46:47], off offset:48         // 00000035C974: DC5E0030 2E7C002E
	.long 0x7ff439a3                                           // 00000035C97C: 7FF439A3
	.long 0x7e463986                                           // 00000035C980: 7E463986
	v_add_nc_u32_e32 v64, 0x200, v64                           // 00000035C984: 4A8080FF 00000200
	v_add_nc_u32_e32 v65, 0x100, v65                           // 00000035C98C: 4A8282FF 00000100
	v_add_nc_u32_e32 v66, 64, v66                              // 00000035C994: 4A8484C0
	v_and_or_b32 v122, 0xffff0000, v8, v122                    // 00000035C998: D657007A 05EA10FF FFFF0000
	v_add_nc_u32_e32 v34, 0x400, v34                           // 00000035C9A4: 4A4444FF 00000400
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000035C9AC: 8B006A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000035C9B0: BF8701D9
	s_or_b32 s15, s0, s15                                      // 00000035C9B4: 8C0F0F00
	s_waitcnt vmcnt(19)                                        // 00000035C9B8: BF894FF7
	v_dot2_f32_bf16 v6, v29, v71, 0                            // 00000035C9BC: CC1A4006 1A028F1D
	v_and_or_b32 v29, 0xffff0000, v124, v35                    // 00000035C9C4: D657001D 048EF8FF FFFF0000
	.long 0x7e463987                                           // 00000035C9D0: 7E463987
	v_dot2_f32_bf16 v6, v30, v69, v6                           // 00000035C9D4: CC1A4006 1C1A8B1E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000035C9DC: BF870131
	v_dot2_f32_bf16 v6, v31, v70, v6                           // 00000035C9E0: CC1A4006 1C1A8D1F
	s_waitcnt vmcnt(17)                                        // 00000035C9E8: BF8947F7
	v_dot2_f32_bf16 v7, v9, v71, 0                             // 00000035C9EC: CC1A4007 1A028F09
	v_dot2_f32_bf16 v9, v32, v5, v6                            // 00000035C9F4: CC1A4009 1C1A0B20
	s_waitcnt vmcnt(15)                                        // 00000035C9FC: BF893FF7
	v_dot2_f32_bf16 v6, v13, v71, 0                            // 00000035CA00: CC1A4006 1A028F0D
	s_waitcnt vmcnt(14)                                        // 00000035CA08: BF893BF7
	v_dot2_f32_bf16 v8, v21, v71, 0                            // 00000035CA0C: CC1A4008 1A028F15
	v_and_or_b32 v21, 0xffff0000, v68, v35                     // 00000035CA14: D6570015 048E88FF FFFF0000
	v_dot2_f32_bf16 v10, v10, v69, v7                          // 00000035CA20: CC1A400A 1C1E8B0A
	s_waitcnt vmcnt(13)                                        // 00000035CA28: BF8937F7
	v_dot2_f32_bf16 v13, v25, v71, 0                           // 00000035CA2C: CC1A400D 1A028F19
	v_dot2_f32_bf16 v14, v14, v69, v6                          // 00000035CA34: CC1A400E 1C1A8B0E
	v_dot2_f32_bf16 v22, v22, v69, v8                          // 00000035CA3C: CC1A4016 1C228B16
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 00000035CA44: CA100102 06060103
	s_delay_alu instid0(VALU_DEP_4)                            // 00000035CA4C: BF870004
	v_dot2_f32_bf16 v13, v26, v69, v13                         // 00000035CA50: CC1A400D 1C368B1A
	v_mov_b32_e32 v8, v4                                       // 00000035CA58: 7E100304
	v_dot2_f32_bf16 v2, v11, v70, v10                          // 00000035CA5C: CC1A4002 1C2A8D0B
	v_dot2_f32_bf16 v3, v15, v70, v14                          // 00000035CA64: CC1A4003 1C3A8D0F
	v_dot2_f32_bf16 v4, v23, v70, v22                          // 00000035CA6C: CC1A4004 1C5A8D17
	v_dot2_f32_bf16 v10, v27, v70, v13                         // 00000035CA74: CC1A400A 1C368D1B
	v_dot2_f32_bf16 v9, v17, v126, v9                          // 00000035CA7C: CC1A4009 1C26FD11
	v_dot2_f32_bf16 v2, v12, v5, v2                            // 00000035CA84: CC1A4002 1C0A0B0C
	v_dot2_f32_bf16 v3, v16, v5, v3                            // 00000035CA8C: CC1A4003 1C0E0B10
	v_dot2_f32_bf16 v4, v24, v5, v4                            // 00000035CA94: CC1A4004 1C120B18
	v_dot2_f32_bf16 v5, v28, v5, v10                           // 00000035CA9C: CC1A4005 1C2A0B1C
	v_dot2_f32_bf16 v9, v18, v74, v9                           // 00000035CAA4: CC1A4009 1C269512
	v_mov_b32_e32 v68, v67                                     // 00000035CAAC: 7E880343
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035CAB0: BF870092
	v_dot2_f32_bf16 v9, v19, v76, v9                           // 00000035CAB4: CC1A4009 1C269913
	v_dot2_f32_bf16 v9, v20, v72, v9                           // 00000035CABC: CC1A4009 1C269114
	s_waitcnt vmcnt(11)                                        // 00000035CAC4: BF892FF7
	v_dot2_f32_bf16 v2, v77, v126, v2                          // 00000035CAC8: CC1A4002 1C0AFD4D
	s_waitcnt vmcnt(10)                                        // 00000035CAD0: BF892BF7
	v_dot2_f32_bf16 v3, v81, v126, v3                          // 00000035CAD4: CC1A4003 1C0EFD51
	s_waitcnt vmcnt(9)                                         // 00000035CADC: BF8927F7
	v_dot2_f32_bf16 v4, v85, v126, v4                          // 00000035CAE0: CC1A4004 1C12FD55
	s_waitcnt vmcnt(8)                                         // 00000035CAE8: BF8923F7
	v_dot2_f32_bf16 v5, v89, v126, v5                          // 00000035CAEC: CC1A4005 1C16FD59
	v_dot2_f32_bf16 v2, v78, v74, v2                           // 00000035CAF4: CC1A4002 1C0A954E
	v_dot2_f32_bf16 v3, v82, v74, v3                           // 00000035CAFC: CC1A4003 1C0E9552
	v_dot2_f32_bf16 v4, v86, v74, v4                           // 00000035CB04: CC1A4004 1C129556
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000035CB0C: BF870214
	v_dot2_f32_bf16 v5, v90, v74, v5                           // 00000035CB10: CC1A4005 1C16955A
	v_dot2_f32_bf16 v2, v79, v76, v2                           // 00000035CB18: CC1A4002 1C0A994F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000035CB20: BF870214
	v_dot2_f32_bf16 v3, v83, v76, v3                           // 00000035CB24: CC1A4003 1C0E9953
	v_dot2_f32_bf16 v4, v87, v76, v4                           // 00000035CB2C: CC1A4004 1C129957
	s_delay_alu instid0(VALU_DEP_4)                            // 00000035CB34: BF870004
	v_dot2_f32_bf16 v5, v91, v76, v5                           // 00000035CB38: CC1A4005 1C16995B
	s_waitcnt vmcnt(7)                                         // 00000035CB40: BF891FF7
	v_dot2_f32_bf16 v9, v93, v73, v9                           // 00000035CB44: CC1A4009 1C26935D
	v_dot2_f32_bf16 v2, v80, v72, v2                           // 00000035CB4C: CC1A4002 1C0A9150
	v_dot2_f32_bf16 v3, v84, v72, v3                           // 00000035CB54: CC1A4003 1C0E9154
	v_dot2_f32_bf16 v4, v88, v72, v4                           // 00000035CB5C: CC1A4004 1C129158
	v_dot2_f32_bf16 v5, v92, v72, v5                           // 00000035CB64: CC1A4005 1C16915C
	v_dot2_f32_bf16 v9, v94, v75, v9                           // 00000035CB6C: CC1A4009 1C26975E
	s_waitcnt vmcnt(5)                                         // 00000035CB74: BF8917F7
	v_dot2_f32_bf16 v2, v101, v73, v2                          // 00000035CB78: CC1A4002 1C0A9365
	s_waitcnt vmcnt(4)                                         // 00000035CB80: BF8913F7
	v_dot2_f32_bf16 v3, v105, v73, v3                          // 00000035CB84: CC1A4003 1C0E9369
	s_waitcnt vmcnt(3)                                         // 00000035CB8C: BF890FF7
	v_dot2_f32_bf16 v4, v109, v73, v4                          // 00000035CB90: CC1A4004 1C12936D
	v_dot2_f32_bf16 v5, v113, v73, v5                          // 00000035CB98: CC1A4005 1C169371
	v_dot2_f32_bf16 v9, v95, v121, v9                          // 00000035CBA0: CC1A4009 1C26F35F
	v_dot2_f32_bf16 v2, v102, v75, v2                          // 00000035CBA8: CC1A4002 1C0A9766
	v_dot2_f32_bf16 v3, v106, v75, v3                          // 00000035CBB0: CC1A4003 1C0E976A
	v_dot2_f32_bf16 v4, v110, v75, v4                          // 00000035CBB8: CC1A4004 1C12976E
	v_dot2_f32_bf16 v5, v114, v75, v5                          // 00000035CBC0: CC1A4005 1C169772
	v_dot2_f32_bf16 v9, v96, v123, v9                          // 00000035CBC8: CC1A4009 1C26F760
	v_dot2_f32_bf16 v2, v103, v121, v2                         // 00000035CBD0: CC1A4002 1C0AF367
	v_dot2_f32_bf16 v3, v107, v121, v3                         // 00000035CBD8: CC1A4003 1C0EF36B
	v_dot2_f32_bf16 v4, v111, v121, v4                         // 00000035CBE0: CC1A4004 1C12F36F
	v_dot2_f32_bf16 v5, v115, v121, v5                         // 00000035CBE8: CC1A4005 1C16F373
	v_dot2_f32_bf16 v9, v97, v122, v9                          // 00000035CBF0: CC1A4009 1C26F561
	v_dot2_f32_bf16 v2, v104, v123, v2                         // 00000035CBF8: CC1A4002 1C0AF768
	v_dot2_f32_bf16 v3, v108, v123, v3                         // 00000035CC00: CC1A4003 1C0EF76C
	v_dot2_f32_bf16 v4, v112, v123, v4                         // 00000035CC08: CC1A4004 1C12F770
	v_dot2_f32_bf16 v5, v116, v123, v5                         // 00000035CC10: CC1A4005 1C16F774
	v_dot2_f32_bf16 v9, v98, v125, v9                          // 00000035CC18: CC1A4009 1C26FB62
	v_dot2_f32_bf16 v2, v117, v122, v2                         // 00000035CC20: CC1A4002 1C0AF575
	s_waitcnt vmcnt(2)                                         // 00000035CC28: BF890BF7
	v_dot2_f32_bf16 v3, v42, v122, v3                          // 00000035CC2C: CC1A4003 1C0EF52A
	s_waitcnt vmcnt(1)                                         // 00000035CC34: BF8907F7
	v_dot2_f32_bf16 v4, v38, v122, v4                          // 00000035CC38: CC1A4004 1C12F526
	s_waitcnt vmcnt(0)                                         // 00000035CC40: BF8903F7
	v_dot2_f32_bf16 v5, v46, v122, v5                          // 00000035CC44: CC1A4005 1C16F52E
	v_dot2_f32_bf16 v2, v118, v125, v2                         // 00000035CC4C: CC1A4002 1C0AFB76
	v_dot2_f32_bf16 v3, v43, v125, v3                          // 00000035CC54: CC1A4003 1C0EFB2B
	v_dot2_f32_bf16 v9, v99, v29, v9                           // 00000035CC5C: CC1A4009 1C263B63
	v_dot2_f32_bf16 v4, v39, v125, v4                          // 00000035CC64: CC1A4004 1C12FB27
	v_dot2_f32_bf16 v5, v47, v125, v5                          // 00000035CC6C: CC1A4005 1C16FB2F
	v_dot2_f32_bf16 v2, v119, v29, v2                          // 00000035CC74: CC1A4002 1C0A3B77
	v_dot2_f32_bf16 v3, v44, v29, v3                           // 00000035CC7C: CC1A4003 1C0E3B2C
	v_dot2_f32_bf16 v9, v100, v21, v9                          // 00000035CC84: CC1A4009 1C262B64
	v_dot2_f32_bf16 v4, v40, v29, v4                           // 00000035CC8C: CC1A4004 1C123B28
	v_dot2_f32_bf16 v5, v48, v29, v5                           // 00000035CC94: CC1A4005 1C163B30
	v_dot2_f32_bf16 v2, v120, v21, v2                          // 00000035CC9C: CC1A4002 1C0A2B78
	v_dot2_f32_bf16 v3, v45, v21, v3                           // 00000035CCA4: CC1A4003 1C0E2B2D
	v_add_f32_e32 v59, v59, v9                                 // 00000035CCAC: 0676133B
	v_dot2_f32_bf16 v4, v41, v21, v4                           // 00000035CCB0: CC1A4004 1C122B29
	v_dot2_f32_bf16 v5, v49, v21, v5                           // 00000035CCB8: CC1A4005 1C162B31
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000035CCC0: BF870194
	v_dual_add_f32 v58, v58, v2 :: v_dual_add_f32 v57, v57, v3 // 00000035CCC4: C908053A 3A380739
	v_add_f32_e32 v56, v56, v4                                 // 00000035CCCC: 06700938
	s_delay_alu instid0(VALU_DEP_3)                            // 00000035CCD0: BF870003
	v_dual_add_f32 v52, v52, v5 :: v_dual_mov_b32 v5, v1       // 00000035CCD4: C9100B34 34040101
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000035CCDC: 917E0F7E
	s_cbranch_execz 39                                         // 00000035CCE0: BFA50027 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0xf80>
	v_dual_mov_b32 v2, v6 :: v_dual_add_nc_u32 v53, 32, v53    // 00000035CCE4: CA200106 02346AA0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000035CCEC: BF870002
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v4, v8             // 00000035CCF0: CA100105 01040108
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v38, v36           // 00000035CCF8: CA100107 03260124
	v_mov_b32_e32 v39, v37                                     // 00000035CD00: 7E4E0325
	s_mov_b32 s17, exec_lo                                     // 00000035CD04: BE91007E
	v_cmp_ge_i32_e32 vcc_lo, v53, v54                          // 00000035CD08: 7C8C6D35
	.long 0xd4c1007e                                           // 00000035CD0C: D4C1007E
	v_cndmask_b32_e32 v1, v53, v54, vcc_lo                     // 00000035CD10: 02026D35
	s_cbranch_execz 64762                                      // 00000035CD14: BFA5FCFA <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x300>
	v_and_b32_e32 v3, -4, v66                                  // 00000035CD18: 360684C4
	v_ashrrev_i32_e32 v2, 31, v64                              // 00000035CD1C: 3404809F
	v_ashrrev_i32_e32 v4, 31, v65                              // 00000035CD20: 3408829F
	.long 0xd7000001                                           // 00000035CD24: D7000001
	v_cndmask_b32_e32 v1, v33, v64, vcc_lo                     // 00000035CD28: 02028121
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000035CD2C: BF870214
	v_ashrrev_i32_e32 v12, 31, v3                              // 00000035CD30: 3418069F
	v_add_co_ci_u32_e64 v2, null, v55, v2, s0                  // 00000035CD34: D5207C02 00020537
	.long 0xd7000009                                           // 00000035CD3C: D7000009
	v_cndmask_b32_e32 v1, v60, v65, vcc_lo                     // 00000035CD40: 0202833C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000035CD44: BF8700A1
	v_add_co_ci_u32_e64 v10, null, v61, v4, s0                 // 00000035CD48: D5207C0A 0002093D
	.long 0xd700000b                                           // 00000035CD50: D700000B
	v_cndmask_b32_e32 v1, v62, v3, vcc_lo                      // 00000035CD54: 0202073E
	v_add_co_ci_u32_e64 v12, null, v63, v12, s0                // 00000035CD58: D5207C0C 0002193F
	s_clause 0x2                                               // 00000035CD60: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 00000035CD64: DC5E0000 017C0001
	global_load_b64 v[38:39], v[9:10], off                     // 00000035CD6C: DC560000 267C0009
	global_load_b32 v67, v[11:12], off                         // 00000035CD74: DC520000 437C000B
	s_branch 64736                                             // 00000035CD7C: BFA0FCE0 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x300>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000035CD80: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000035CD84: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000035CD88: 8C7E017E
	.long 0xd71f0001                                           // 00000035CD8C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000035CD90: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000035CD94: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000035CD98: 3A040290
	s_waitcnt vmcnt(2)                                         // 00000035CD9C: BF890BF7
	v_xor_b32_e32 v7, 8, v1                                    // 00000035CDA0: 3A0E0288
	v_xor_b32_e32 v12, 4, v1                                   // 00000035CDA4: 3A180284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000035CDA8: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000035CDAC: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000035CDB0: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 00000035CDB4: 7C980EA0
	v_cndmask_b32_e32 v7, v1, v7, vcc_lo                       // 00000035CDB8: 020E0F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 00000035CDBC: 7C9818A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000035CDC0: BF870002
	v_lshlrev_b32_e32 v7, 2, v7                                // 00000035CDC4: 300E0E82
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000035CDC8: 30040482
	ds_bpermute_b32 v3, v2, v59                                // 00000035CDCC: DACC0000 03003B02
	s_waitcnt lgkmcnt(0)                                       // 00000035CDD4: BF89FC07
	v_add_f32_e32 v3, v59, v3                                  // 00000035CDD8: 0606073B
	ds_bpermute_b32 v5, v2, v57                                // 00000035CDDC: DACC0000 05003902
	ds_bpermute_b32 v4, v2, v58                                // 00000035CDE4: DACC0000 04003A02
	ds_bpermute_b32 v6, v2, v56                                // 00000035CDEC: DACC0000 06003802
	ds_bpermute_b32 v2, v2, v52                                // 00000035CDF4: DACC0000 02003402
	ds_bpermute_b32 v8, v7, v3                                 // 00000035CDFC: DACC0000 08000307
	s_waitcnt lgkmcnt(3)                                       // 00000035CE04: BF89FC37
	v_dual_add_f32 v5, v57, v5 :: v_dual_add_f32 v4, v58, v4   // 00000035CE08: C9080B39 0504093A
	s_waitcnt lgkmcnt(2)                                       // 00000035CE10: BF89FC27
	v_add_f32_e32 v6, v56, v6                                  // 00000035CE14: 060C0D38
	s_waitcnt lgkmcnt(0)                                       // 00000035CE18: BF89FC07
	v_dual_add_f32 v2, v52, v2 :: v_dual_add_f32 v3, v3, v8    // 00000035CE1C: C9080534 02021103
	ds_bpermute_b32 v10, v7, v5                                // 00000035CE24: DACC0000 0A000507
	ds_bpermute_b32 v9, v7, v4                                 // 00000035CE2C: DACC0000 09000407
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 00000035CE34: 02181901
	ds_bpermute_b32 v11, v7, v6                                // 00000035CE38: DACC0000 0B000607
	ds_bpermute_b32 v7, v7, v2                                 // 00000035CE40: DACC0000 07000207
	s_waitcnt lgkmcnt(3)                                       // 00000035CE48: BF89FC37
	v_dual_add_f32 v5, v5, v10 :: v_dual_lshlrev_b32 v12, 2, v12// 00000035CE4C: C9221505 050C1882
	s_waitcnt lgkmcnt(2)                                       // 00000035CE54: BF89FC27
	v_add_f32_e32 v4, v4, v9                                   // 00000035CE58: 06081304
	s_waitcnt lgkmcnt(0)                                       // 00000035CE5C: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 00000035CE60: 06040F02
	ds_bpermute_b32 v9, v12, v5                                // 00000035CE64: DACC0000 0900050C
	v_add_f32_e32 v6, v6, v11                                  // 00000035CE6C: 060C1706
	ds_bpermute_b32 v7, v12, v3                                // 00000035CE70: DACC0000 0700030C
	ds_bpermute_b32 v8, v12, v4                                // 00000035CE78: DACC0000 0800040C
	ds_bpermute_b32 v11, v12, v2                               // 00000035CE80: DACC0000 0B00020C
	s_waitcnt lgkmcnt(3)                                       // 00000035CE88: BF89FC37
	v_add_f32_e32 v5, v5, v9                                   // 00000035CE8C: 060A1305
	ds_bpermute_b32 v10, v12, v6                               // 00000035CE90: DACC0000 0A00060C
	v_xor_b32_e32 v12, 2, v1                                   // 00000035CE98: 3A180282
	s_waitcnt lgkmcnt(2)                                       // 00000035CE9C: BF89FC27
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v4, v8     // 00000035CEA0: C9080F03 03041104
	s_waitcnt lgkmcnt(1)                                       // 00000035CEA8: BF89FC17
	v_add_f32_e32 v8, v2, v11                                  // 00000035CEAC: 06101702
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 00000035CEB0: 7C9818A0
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 00000035CEB4: 02181901
	s_waitcnt lgkmcnt(0)                                       // 00000035CEB8: BF89FC07
	v_add_f32_e32 v6, v6, v10                                  // 00000035CEBC: 060C1506
	s_delay_alu instid0(VALU_DEP_2)                            // 00000035CEC0: BF870002
	v_lshlrev_b32_e32 v12, 2, v12                              // 00000035CEC4: 30181882
	ds_bpermute_b32 v7, v12, v4                                // 00000035CEC8: DACC0000 0700040C
	ds_bpermute_b32 v10, v12, v6                               // 00000035CED0: DACC0000 0A00060C
	s_waitcnt lgkmcnt(0)                                       // 00000035CED8: BF89FC07
	v_dual_add_f32 v4, v4, v7 :: v_dual_add_f32 v7, v6, v10    // 00000035CEDC: C9080F04 04061506
	ds_bpermute_b32 v2, v12, v3                                // 00000035CEE4: DACC0000 0200030C
	ds_bpermute_b32 v9, v12, v5                                // 00000035CEEC: DACC0000 0900050C
	ds_bpermute_b32 v11, v12, v8                               // 00000035CEF4: DACC0000 0B00080C
	v_xor_b32_e32 v12, 1, v1                                   // 00000035CEFC: 3A180281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000035CF00: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 00000035CF04: 7C9818A0
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 00000035CF08: 02021901
	s_waitcnt lgkmcnt(2)                                       // 00000035CF0C: BF89FC27
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v12, 2, v1 // 00000035CF10: C9220503 010C0282
	s_waitcnt lgkmcnt(0)                                       // 00000035CF18: BF89FC07
	v_dual_add_f32 v2, v5, v9 :: v_dual_add_f32 v3, v8, v11    // 00000035CF1C: C9081305 02021708
	ds_bpermute_b32 v9, v12, v4                                // 00000035CF24: DACC0000 0900040C
	ds_bpermute_b32 v10, v12, v7                               // 00000035CF2C: DACC0000 0A00070C
	ds_bpermute_b32 v5, v12, v1                                // 00000035CF34: DACC0000 0500010C
	ds_bpermute_b32 v6, v12, v2                                // 00000035CF3C: DACC0000 0600020C
	ds_bpermute_b32 v8, v12, v3                                // 00000035CF44: DACC0000 0800030C
	v_cmpx_eq_u32_e32 0, v51                                   // 00000035CF4C: 7D946680
	s_cbranch_execz 15                                         // 00000035CF50: BFA5000F <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x1190>
	s_waitcnt lgkmcnt(3)                                       // 00000035CF54: BF89FC37
	v_dual_add_f32 v7, v7, v10 :: v_dual_add_f32 v4, v4, v9    // 00000035CF58: C9081507 07041304
	s_waitcnt lgkmcnt(1)                                       // 00000035CF60: BF89FC17
	v_dual_add_f32 v1, v1, v5 :: v_dual_add_f32 v2, v2, v6     // 00000035CF64: C9080B01 01020D02
	v_mul_u32_u24_e32 v5, 20, v50                              // 00000035CF6C: 160A6494
	s_waitcnt lgkmcnt(0)                                       // 00000035CF70: BF89FC07
	v_add_f32_e32 v3, v3, v8                                   // 00000035CF74: 06061103
	ds_store_2addr_b32 v5, v1, v4 offset1:1                    // 00000035CF78: D8380100 00040105
	ds_store_2addr_b32 v5, v2, v7 offset0:2 offset1:3          // 00000035CF80: D8380302 00070205
	ds_store_b32 v5, v3 offset:16                              // 00000035CF88: D8340010 00000305
	s_or_b32 exec_lo, exec_lo, s0                              // 00000035CF90: 8C7E007E
	.long 0xd4510000                                           // 00000035CF94: D4510000
	v_cndmask_b32_e32 v0, s2, v8, vcc_lo                       // 00000035CF98: 02001002
	v_cmp_gt_u32_e32 vcc_lo, 5, v0                             // 00000035CF9C: 7C980085
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000035CFA0: BF890007
	s_barrier                                                  // 00000035CFA4: BFBD0000
	buffer_gl0_inv                                             // 00000035CFA8: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 00000035CFB0: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035CFB4: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000035CFB8: BE812000
	s_cbranch_execz 371                                        // 00000035CFBC: BFA50173 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x178c>
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000035CFC0: 300E0082
	s_clause 0x1                                               // 00000035CFC4: BF850001
	s_load_b64 s[4:5], s[10:11], 0x38                          // 00000035CFC8: F4040105 F8000038
	s_load_b64 s[0:1], s[10:11], 0x8                           // 00000035CFD0: F4040005 F8000008
	s_mov_b32 s12, 0                                           // 00000035CFD8: BE8C0080
	s_mov_b32 s6, -1                                           // 00000035CFDC: BE8600C1
	s_mov_b32 s7, 0                                            // 00000035CFE0: BE870080
	ds_load_2addr_b32 v[1:2], v7 offset1:5                     // 00000035CFE4: D8DC0500 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:10 offset1:15         // 00000035CFEC: D8DC0F0A 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:20 offset1:25         // 00000035CFF4: D8DC1914 05000007
	s_waitcnt lgkmcnt(0)                                       // 00000035CFFC: BF89FC07
	s_cmp_lt_i32 s5, 3                                         // 00000035D000: BF048305
	v_add_f32_e32 v1, 0, v1                                    // 00000035D004: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D008: BF870091
	v_add_f32_e32 v1, v1, v2                                   // 00000035D00C: 06020501
	v_add_f32_e32 v3, v1, v3                                   // 00000035D010: 06060701
	ds_load_2addr_b32 v[1:2], v7 offset0:30 offset1:35         // 00000035D014: D8DC231E 01000007
	v_add_f32_e32 v3, v3, v4                                   // 00000035D01C: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D020: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 00000035D024: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 00000035D028: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 00000035D02C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D030: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 00000035D034: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 00000035D038: 06020501
	s_cbranch_scc1 176                                         // 00000035D03C: BFA200B0 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x1500>
	s_cmp_gt_i32 s5, 3                                         // 00000035D040: BF028305
	s_cbranch_scc0 110                                         // 00000035D044: BFA1006E <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x1400>
	s_cmp_gt_i32 s5, 4                                         // 00000035D048: BF028405
	s_cbranch_scc0 56                                          // 00000035D04C: BFA10038 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x1330>
	s_cmp_eq_u32 s5, 5                                         // 00000035D050: BF068505
	s_mov_b32 s7, -1                                           // 00000035D054: BE8700C1
	s_cbranch_scc0 52                                          // 00000035D058: BFA10034 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x132c>
	s_load_b64 s[10:11], s[10:11], 0x10                        // 00000035D05C: F4040285 F8000010
	s_mov_b32 s7, 0                                            // 00000035D064: BE870080
	s_and_b32 s6, s2, 0x1ff                                    // 00000035D068: 8B06FF02 000001FF
	s_lshr_b64 s[14:15], s[8:9], 1                             // 00000035D070: 858E8108
	.long 0xd45c000d                                           // 00000035D074: D45C000D
	v_cndmask_b32_e32 v0, 0x100, v6, vcc_lo                    // 00000035D078: 02000CFF 00000100
	v_mad_u64_u32 v[2:3], null, s14, v0, 0                     // 00000035D080: D6FE7C02 0202000E
	s_and_b32 s14, s2, 0xfffffe00                              // 00000035D088: 8B0EFF02 FFFFFE00
	s_and_b32 s15, s13, exec_lo                                // 00000035D090: 8B0F7E0D
	s_waitcnt lgkmcnt(0)                                       // 00000035D094: BF89FC07
	s_cselect_b32 s11, s1, s11                                 // 00000035D098: 980B0B01
	s_cselect_b32 s15, s0, s10                                 // 00000035D09C: 980F0A00
	s_lshr_b32 s10, s9, 1                                      // 00000035D0A0: 850A8109
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035D0A4: BF870009
	v_mad_u64_u32 v[3:4], null, s10, v0, v[3:4]                // 00000035D0A8: D6FE7C03 040E000A
	s_add_u32 s10, s6, 0xffffff00                              // 00000035D0B0: 800AFF06 FFFFFF00
	s_addc_u32 s16, 0, -1                                      // 00000035D0B8: 8210C180
	s_and_b32 s13, s13, exec_lo                                // 00000035D0BC: 8B0D7E0D
	s_cselect_b32 s10, s6, s10                                 // 00000035D0C0: 980A0A06
	v_bfe_u32 v4, v1, 16, 1                                    // 00000035D0C4: D6100004 02052101
	.long 0xd73c0002                                           // 00000035D0CC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 00000035D0D0: 02020481
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035D0D4: BF870112
	v_add3_u32 v4, v1, v4, 0x7fff                              // 00000035D0D8: D6550004 03FE0901 00007FFF
	.long 0xd7006a02                                           // 00000035D0E4: D7006A02
	v_cndmask_b32_e32 v1, s15, v2, vcc_lo                      // 00000035D0E8: 0202040F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000035D0EC: BF8700B1
	v_add_co_ci_u32_e64 v3, null, s11, v3, vcc_lo              // 00000035D0F0: D5207C03 01AA060B
	s_cselect_b32 s11, 0, s16                                  // 00000035D0F8: 980B1080
	.long 0xd7006a02                                           // 00000035D0FC: D7006A02
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 00000035D100: 02001D02
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000035D104: D5207C03 01AA0680
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000035D10C: 848A810A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D110: BF870099
	.long 0xd7006a02                                           // 00000035D114: D7006A02
	v_cndmask_b32_e32 v0, v2, v10, vcc_lo                      // 00000035D118: 02001502
	v_add_co_ci_u32_e64 v3, null, s11, v3, vcc_lo              // 00000035D11C: D5207C03 01AA060B
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000035D124: DC960000 007C0402
	s_mov_b32 s6, 0                                            // 00000035D12C: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035D130: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000035D134: 8B6A067E
	s_cbranch_vccz 48                                          // 00000035D138: BFA30030 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x13fc>
	v_mul_f32_e32 v2, 0xbfb8aa3b, v1                           // 00000035D13C: 100402FF BFB8AA3B
	s_lshl_b64 s[10:11], s[2:3], 2                             // 00000035D144: 848A8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000035D148: BF870291
	v_exp_f32_e32 v2, v2                                       // 00000035D14C: 7E044B02
	v_add_f32_e32 v5, 1.0, v2                                  // 00000035D150: 060A04F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000035D154: BF870121
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 00000035D158: D6FC7C06 03CA0B05
	v_div_scale_f32 v8, vcc_lo, 1.0, v5, 1.0                   // 00000035D160: D6FC6A08 03CA0AF2
	v_rcp_f32_e32 v7, v6                                       // 00000035D168: 7E0E5506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D16C: BF870095
	v_fma_f32 v2, -v6, v7, 1.0                                 // 00000035D170: D6130002 23CA0F06
	v_fmac_f32_e32 v7, v2, v7                                  // 00000035D178: 560E0F02
	v_mad_u64_u32 v[2:3], null, s8, v0, 0                      // 00000035D17C: D6FE7C02 02020008
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035D184: BF870112
	v_mul_f32_e32 v9, v8, v7                                   // 00000035D188: 10120F08
	v_mad_u64_u32 v[3:4], null, s9, v0, v[3:4]                 // 00000035D18C: D6FE7C03 040E0009
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D194: BF870092
	v_fma_f32 v10, -v6, v9, v8                                 // 00000035D198: D613000A 24221306
	v_fmac_f32_e32 v9, v10, v7                                 // 00000035D1A0: 56120F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035D1A4: BF870113
	.long 0xd73c0002                                           // 00000035D1A8: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 00000035D1AC: 02020482
	v_fma_f32 v4, -v6, v9, v8                                  // 00000035D1B0: D6130004 24221306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000035D1B8: BF870191
	v_div_fmas_f32 v4, v4, v7, v9                              // 00000035D1BC: D6370004 04260F04
	.long 0xd7006a02                                           // 00000035D1C4: D7006A02
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 00000035D1C8: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000035D1CC: BF870191
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 00000035D1D0: D5207C03 01AA0601
	v_div_fixup_f32 v4, v4, v5, 1.0                            // 00000035D1D8: D6270004 03CA0B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D1E0: BF870093
	.long 0xd7006a02                                           // 00000035D1E4: D7006A02
	v_cndmask_b32_e32 v0, v2, v10, vcc_lo                      // 00000035D1E8: 02001502
	v_add_co_ci_u32_e64 v3, null, s11, v3, vcc_lo              // 00000035D1EC: D5207C03 01AA060B
	global_store_b32 v[2:3], v4, off                           // 00000035D1F4: DC6A0000 007C0402
	s_mov_b32 s6, 0                                            // 00000035D1FC: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035D200: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000035D204: 8B6A067E
	s_cbranch_vccz 60                                          // 00000035D208: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x14fc>
	v_bfe_u32 v2, v1, 16, 1                                    // 00000035D20C: D6100002 02052101
	s_lshl_b64 s[10:11], s[2:3], 2                             // 00000035D214: 848A8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D218: BF870091
	v_add3_u32 v2, v1, v2, 0x7fff                              // 00000035D21C: D6550002 03FE0501 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000035D228: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D230: BF870091
	v_mul_f32_e32 v2, s4, v2                                   // 00000035D234: 10040404
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 00000035D238: 100404FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000035D240: BF870291
	v_exp_f32_e32 v2, v2                                       // 00000035D244: 7E044B02
	v_add_f32_e32 v5, 1.0, v2                                  // 00000035D248: 060A04F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000035D24C: BF870121
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 00000035D250: D6FC7C06 03CA0B05
	v_div_scale_f32 v8, vcc_lo, 1.0, v5, 1.0                   // 00000035D258: D6FC6A08 03CA0AF2
	v_rcp_f32_e32 v7, v6                                       // 00000035D260: 7E0E5506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D264: BF870095
	v_fma_f32 v2, -v6, v7, 1.0                                 // 00000035D268: D6130002 23CA0F06
	v_fmac_f32_e32 v7, v2, v7                                  // 00000035D270: 560E0F02
	v_mad_u64_u32 v[2:3], null, s8, v0, 0                      // 00000035D274: D6FE7C02 02020008
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D27C: BF870092
	v_mul_f32_e32 v9, v8, v7                                   // 00000035D280: 10120F08
	v_fma_f32 v4, -v6, v9, v8                                  // 00000035D284: D6130004 24221306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000035D28C: BF870211
	v_fmac_f32_e32 v9, v4, v7                                  // 00000035D290: 56120F04
	v_mad_u64_u32 v[3:4], null, s9, v0, v[3:4]                 // 00000035D294: D6FE7C03 040E0009
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035D29C: BF870112
	v_fma_f32 v4, -v6, v9, v8                                  // 00000035D2A0: D6130004 24221306
	.long 0xd73c0002                                           // 00000035D2A8: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 00000035D2AC: 02020482
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035D2B0: BF870112
	v_div_fmas_f32 v4, v4, v7, v9                              // 00000035D2B4: D6370004 04260F04
	.long 0xd7006a02                                           // 00000035D2BC: D7006A02
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 00000035D2C0: 02020400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000035D2C4: BF870212
	v_div_fixup_f32 v4, v4, v5, 1.0                            // 00000035D2C8: D6270004 03CA0B04
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 00000035D2D0: D5207C03 01AA0601
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000035D2D8: BF870193
	.long 0xd7006a02                                           // 00000035D2DC: D7006A02
	v_cndmask_b32_e32 v0, v2, v10, vcc_lo                      // 00000035D2E0: 02001502
	v_add_f32_e32 v4, v4, v4                                   // 00000035D2E4: 06080904
	s_delay_alu instid0(VALU_DEP_3)                            // 00000035D2E8: BF870003
	v_add_co_ci_u32_e64 v3, null, s11, v3, vcc_lo              // 00000035D2EC: D5207C03 01AA060B
	global_store_b32 v[2:3], v4, off                           // 00000035D2F4: DC6A0000 007C0402
	s_mov_b32 s6, 0                                            // 00000035D2FC: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035D300: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000035D304: 8B6A067E
	s_cbranch_vccz 71                                          // 00000035D308: BFA30047 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x1628>
	s_cmp_gt_i32 s5, 1                                         // 00000035D30C: BF028105
	s_mov_b32 s6, -1                                           // 00000035D310: BE8600C1
	s_cbranch_scc0 63                                          // 00000035D314: BFA1003F <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x1614>
	v_bfe_u32 v2, v1, 16, 1                                    // 00000035D318: D6100002 02052101
	s_lshl_b64 s[10:11], s[2:3], 1                             // 00000035D320: 848A8102
	s_mov_b32 s6, 0                                            // 00000035D324: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D328: BF870091
	v_add3_u32 v2, v1, v2, 0x7fff                              // 00000035D32C: D6550002 03FE0501 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000035D338: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D340: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 00000035D344: 100404FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 00000035D34C: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D350: BF870095
	v_add_f32_e32 v5, 1.0, v2                                  // 00000035D354: 060A04F2
	v_div_scale_f32 v4, null, v5, v5, 1.0                      // 00000035D358: D6FC7C04 03CA0B05
	v_div_scale_f32 v7, vcc_lo, 1.0, v5, 1.0                   // 00000035D360: D6FC6A07 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000035D368: BF870292
	v_rcp_f32_e32 v6, v4                                       // 00000035D36C: 7E0C5504
	v_fma_f32 v2, -v4, v6, 1.0                                 // 00000035D370: D6130002 23CA0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000035D378: BF870121
	v_fmac_f32_e32 v6, v2, v6                                  // 00000035D37C: 560C0D02
	v_mad_u64_u32 v[2:3], null, s8, v0, 0                      // 00000035D380: D6FE7C02 02020008
	v_mul_f32_e32 v8, v7, v6                                   // 00000035D388: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D38C: BF870091
	v_fma_f32 v9, -v4, v8, v7                                  // 00000035D390: D6130009 241E1104
	v_fmac_f32_e32 v8, v9, v6                                  // 00000035D398: 56100D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000035D39C: BF870121
	v_fma_f32 v7, -v4, v8, v7                                  // 00000035D3A0: D6130007 241E1104
	v_mad_u64_u32 v[3:4], null, s9, v0, v[3:4]                 // 00000035D3A8: D6FE7C03 040E0009
	v_div_fmas_f32 v4, v7, v6, v8                              // 00000035D3B0: D6370004 04220D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035D3B8: BF870112
	.long 0xd73c0002                                           // 00000035D3BC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 00000035D3C0: 02020481
	v_div_fixup_f32 v4, v4, v5, 1.0                            // 00000035D3C4: D6270004 03CA0B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035D3CC: BF870112
	.long 0xd7006a02                                           // 00000035D3D0: D7006A02
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 00000035D3D4: 02020400
	v_bfe_u32 v5, v4, 16, 1                                    // 00000035D3D8: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000035D3E0: BF870194
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 00000035D3E4: D5207C03 01AA0601
	.long 0xd7006a02                                           // 00000035D3EC: D7006A02
	v_cndmask_b32_e32 v0, v2, v10, vcc_lo                      // 00000035D3F0: 02001502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000035D3F4: BF870193
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000035D3F8: D6550004 03FE0B04 00007FFF
	v_add_co_ci_u32_e64 v3, null, s11, v3, vcc_lo              // 00000035D404: D5207C03 01AA060B
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000035D40C: DC960000 007C0402
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 00000035D414: 916A067E
	s_cbranch_vccnz 3                                          // 00000035D418: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x1628>
	s_cmp_lg_u32 s5, 1                                         // 00000035D41C: BF078105
	s_mov_b32 s12, -1                                          // 00000035D420: BE8C00C1
	s_cselect_b32 s7, -1, 0                                    // 00000035D424: 980780C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000035D428: BF8700A1
	v_bfe_u32 v2, v1, 16, 1                                    // 00000035D42C: D6100002 02052101
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000035D434: 8B6A077E
	v_add3_u32 v1, v1, v2, 0x7fff                              // 00000035D438: D6550001 03FE0501 00007FFF
	s_cbranch_vccz 21                                          // 00000035D444: BFA30015 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x169c>
	v_mad_u64_u32 v[2:3], null, s8, v0, 0                      // 00000035D448: D6FE7C02 02020008
	s_lshl_b64 s[6:7], s[2:3], 1                               // 00000035D450: 84868102
	s_mov_b32 s12, 0                                           // 00000035D454: BE8C0080
	v_mad_u64_u32 v[3:4], null, s9, v0, v[3:4]                 // 00000035D458: D6FE7C03 040E0009
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D460: BF870091
	.long 0xd73c0002                                           // 00000035D464: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 00000035D468: 02020481
	.long 0xd7006a02                                           // 00000035D46C: D7006A02
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 00000035D470: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035D474: BF870111
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 00000035D478: D5207C03 01AA0601
	.long 0xd7006a02                                           // 00000035D480: D7006A02
	v_cndmask_b32_e32 v0, v2, v6, vcc_lo                       // 00000035D484: 02000D02
	s_delay_alu instid0(VALU_DEP_1)                            // 00000035D488: BF870001
	v_add_co_ci_u32_e64 v3, null, s7, v3, vcc_lo               // 00000035D48C: D5207C03 01AA0607
	global_store_d16_hi_b16 v[2:3], v1, off                    // 00000035D494: DC960000 007C0102
	s_and_not1_b32 vcc_lo, exec_lo, s12                        // 00000035D49C: 916A0C7E
	s_cbranch_vccnz 58                                         // 00000035D4A0: BFA4003A <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi5ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x178c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000035D4A4: BF8700A1
	v_and_b32_e32 v1, 0xffff0000, v1                           // 00000035D4A8: 360202FF FFFF0000
	s_lshl_b64 s[2:3], s[2:3], 1                               // 00000035D4B0: 84828102
	v_mul_f32_e32 v4, s4, v1                                   // 00000035D4B4: 10080204
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D4B8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v4                           // 00000035D4BC: 100208FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 00000035D4C4: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D4C8: BF870095
	v_add_f32_e32 v5, 1.0, v1                                  // 00000035D4CC: 060A02F2
	v_div_scale_f32 v3, null, v5, v5, v4                       // 00000035D4D0: D6FC7C03 04120B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000035D4D8: BF870291
	v_rcp_f32_e32 v6, v3                                       // 00000035D4DC: 7E0C5503
	v_fma_f32 v1, -v3, v6, 1.0                                 // 00000035D4E0: D6130001 23CA0D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000035D4E8: BF870131
	v_fmac_f32_e32 v6, v1, v6                                  // 00000035D4EC: 560C0D01
	v_div_scale_f32 v7, vcc_lo, v4, v5, v4                     // 00000035D4F0: D6FC6A07 04120B04
	v_mad_u64_u32 v[1:2], null, s8, v0, 0                      // 00000035D4F8: D6FE7C01 02020008
	v_mul_f32_e32 v8, v7, v6                                   // 00000035D500: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D504: BF870091
	v_fma_f32 v9, -v3, v8, v7                                  // 00000035D508: D6130009 241E1103
	v_fmac_f32_e32 v8, v9, v6                                  // 00000035D510: 56100D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000035D514: BF870121
	v_fma_f32 v7, -v3, v8, v7                                  // 00000035D518: D6130007 241E1103
	v_mad_u64_u32 v[2:3], null, s9, v0, v[2:3]                 // 00000035D520: D6FE7C02 040A0009
	v_div_fmas_f32 v0, v7, v6, v8                              // 00000035D528: D6370000 04220D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000035D530: BF870191
	v_div_fixup_f32 v3, v0, v5, v4                             // 00000035D534: D6270003 04120B00
	.long 0xd73c0000                                           // 00000035D53C: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000035D540: 02020281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035D544: BF870112
	v_bfe_u32 v2, v3, 16, 1                                    // 00000035D548: D6100002 02052103
	.long 0xd7006a00                                           // 00000035D550: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000035D554: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000035D558: BF870191
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000035D55C: D5207C01 01AA0201
	v_add3_u32 v2, v3, v2, 0x7fff                              // 00000035D564: D6550002 03FE0503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035D570: BF870093
	.long 0xd7006a00                                           // 00000035D574: D7006A00
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 00000035D578: 02000500
	v_add_co_ci_u32_e64 v1, null, s3, v1, vcc_lo               // 00000035D57C: D5207C01 01AA0203
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000035D584: DC960000 007C0200
	s_nop 0                                                    // 00000035D58C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000035D590: BFB60003
	s_endpgm                                                   // 00000035D594: BFB00000
		...

