0000000000907600 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj>:
; _ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj():
	s_load_b512 s[4:19], s[0:1], null                          // 000000907600: F4100100 F8000000
	s_waitcnt lgkmcnt(0)                                       // 000000907608: BF89FC07
	s_load_b32 s3, s[10:11], null                              // 00000090760C: F40000C5 F8000000
	s_ashr_i32 s10, s2, 31                                     // 000000907614: 860A9F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000907618: BF870499
	s_lshr_b32 s10, s10, 29                                    // 00000090761C: 850A9D0A
	s_add_i32 s10, s2, s10                                     // 000000907620: 810A0A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000907624: BF8704B9
	s_ashr_i32 s24, s10, 3                                     // 000000907628: 8618830A
	s_waitcnt lgkmcnt(0)                                       // 00000090762C: BF89FC07
	s_mul_i32 s3, s3, 5                                        // 000000907630: 96038503
	s_cmp_ge_i32 s24, s3                                       // 000000907634: BF030318
	s_cbranch_scc1 4634                                        // 000000907638: BFA2121A <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x48a4>
	s_ashr_i32 s25, s24, 31                                    // 00000090763C: 86199F18
	v_mov_b32_e32 v1, v0                                       // 000000907640: 7E020300
	s_lshl_b64 s[10:11], s[24:25], 4                           // 000000907644: 848A8418
	s_mov_b32 s21, 0                                           // 000000907648: BE950080
	s_add_u32 s8, s8, s10                                      // 00000090764C: 80080A08
	s_addc_u32 s9, s9, s11                                     // 000000907650: 82090B09
	s_load_b128 s[8:11], s[8:9], null                          // 000000907654: F4080204 F8000000
	s_waitcnt lgkmcnt(0)                                       // 00000090765C: BF89FC07
	s_add_i32 s3, s11, -1                                      // 000000907660: 8103C10B
	s_and_saveexec_b32 s20, s21                                // 000000907664: BE942015
	s_cbranch_execz 58                                         // 000000907668: BFA5003A <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x154>
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v2, 4, v0       // 00000090766C: CA220080 03020084
	v_mov_b32_e32 v1, v0                                       // 000000907674: 7E020300
	s_set_inst_prefetch_distance 0x1                           // 000000907678: BF840001
	s_nop 0                                                    // 00000090767C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000907680: BF870191
	v_and_b32_e32 v4, 0xffff, v1                               // 000000907684: 360802FF 0000FFFF
	v_add_nc_u32_e32 v3, -16, v3                               // 00000090768C: 4A0606D0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000907690: BF870092
	v_mul_u32_u24_e32 v4, 0xcccd, v4                           // 000000907694: 160808FF 0000CCCD
	v_lshrrev_b32_e32 v6, 24, v4                               // 00000090769C: 320C0898
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009076A0: BF870121
	v_add_nc_u32_e32 v4, s10, v6                               // 0000009076A4: 4A080C0A
	.long 0x7f0c3880                                           // 0000009076A8: 7F0C3880
	v_min_i32_e32 v4, s3, v4                                   // 0000009076AC: 22080803
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009076B0: BF870091
	v_ashrrev_i32_e32 v5, 31, v4                               // 0000009076B4: 340A089F
	.long 0xd73c0004                                           // 0000009076B8: D73C0004
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 0000009076BC: 02020882
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009076C0: BF870091
	.long 0xd7006a04                                           // 0000009076C4: D7006A04
	v_cndmask_b32_e32 v1, s12, v4, vcc_lo                      // 0000009076C8: 0202080C
	v_add_co_ci_u32_e64 v5, null, s13, v5, vcc_lo              // 0000009076CC: D5207C05 01AA0A0D
	global_load_b32 v5, v[4:5], off                            // 0000009076D4: DC520000 057C0004
	.long 0xd7050004                                           // 0000009076DC: D7050004
	v_cndmask_b32_e32 v1, 0x140, v6, vcc_lo                    // 0000009076E0: 02020CFF 00000140
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009076E8: BF870121
	.long 0xd7040006                                           // 0000009076EC: D7040006
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 0000009076F0: 02020901
	v_add_nc_u32_e32 v1, 32, v1                                // 0000009076F4: 4A0202A0
	v_lshlrev_b32_e32 v6, 4, v6                                // 0000009076F8: 300C0C84
	s_waitcnt vmcnt(0)                                         // 0000009076FC: BF8903F7
	v_mad_i64_i32 v[4:5], null, 0x1400, v5, s[6:7]             // 000000907700: D6FF7C04 001A0AFF 00001400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000090770C: BF870091
	.long 0xd7006a04                                           // 000000907710: D7006A04
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000907714: 02020D04
	v_add_co_ci_u32_e64 v5, null, 0, v5, vcc_lo                // 000000907718: D5207C05 01AA0A80
	v_cmp_eq_u32_e32 vcc_lo, 0, v3                             // 000000907720: 7C940680
	global_load_b128 v[4:7], v[4:5], off                       // 000000907724: DC5E0000 047C0004
	s_or_b32 s21, vcc_lo, s21                                  // 00000090772C: 8C15156A
	s_waitcnt vmcnt(0)                                         // 000000907730: BF8903F7
	ds_store_b128 v2, v[4:7]                                   // 000000907734: DB7C0000 00000402
	v_add_nc_u32_e32 v2, 0x200, v2                             // 00000090773C: 4A0404FF 00000200
	s_and_not1_b32 exec_lo, exec_lo, s21                       // 000000907744: 917E157E
	s_cbranch_execnz 65485                                     // 000000907748: BFA6FFCD <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x80>
	s_set_inst_prefetch_distance 0x2                           // 00000090774C: BF840002
	s_or_b32 exec_lo, exec_lo, s21                             // 000000907750: 8C7E157E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000907754: BF870009
	s_or_b32 exec_lo, exec_lo, s20                             // 000000907758: 8C7E147E
	v_lshlrev_b32_e32 v2, 4, v1                                // 00000090775C: 30040284
	s_mov_b32 s20, 0                                           // 000000907760: BE940080
	v_add_nc_u32_e32 v11, 32, v1                               // 000000907764: 4A1602A0
	v_and_b32_e32 v3, 0xffff, v1                               // 000000907768: 360602FF 0000FFFF
	v_add_nc_u32_e32 v12, 64, v1                               // 000000907770: 4A1802C0
	v_add_nc_u32_e32 v13, 0x60, v1                             // 000000907774: 4A1A02FF 00000060
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000090777C: BF870214
	v_and_b32_e32 v4, 0xffff, v11                              // 000000907780: 360816FF 0000FFFF
	v_mul_u32_u24_e32 v3, 0xcccd, v3                           // 000000907788: 160606FF 0000CCCD
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000907790: BF870214
	v_and_b32_e32 v5, 0xffff, v12                              // 000000907794: 360A18FF 0000FFFF
	v_and_b32_e32 v6, 0xffff, v13                              // 00000090779C: 360C1AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009077A4: BF870214
	v_mul_u32_u24_e32 v4, 0xcccd, v4                           // 0000009077A8: 160808FF 0000CCCD
	v_lshrrev_b32_e32 v14, 24, v3                              // 0000009077B0: 321C0698
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009077B4: BF870214
	v_mul_u32_u24_e32 v5, 0xcccd, v5                           // 0000009077B8: 160A0AFF 0000CCCD
	v_mul_u32_u24_e32 v6, 0xcccd, v6                           // 0000009077C0: 160C0CFF 0000CCCD
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009077C8: BF870214
	v_lshrrev_b32_e32 v15, 24, v4                              // 0000009077CC: 321E0898
	v_add_nc_u32_e32 v3, s10, v14                              // 0000009077D0: 4A061C0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009077D4: BF870214
	v_lshrrev_b32_e32 v16, 24, v5                              // 0000009077D8: 32200A98
	v_lshrrev_b32_e32 v17, 24, v6                              // 0000009077DC: 32220C98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009077E0: BF870214
	v_add_nc_u32_e32 v4, s10, v15                              // 0000009077E4: 4A081E0A
	v_min_i32_e32 v3, s3, v3                                   // 0000009077E8: 22060603
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009077EC: BF870214
	v_add_nc_u32_e32 v6, s10, v16                              // 0000009077F0: 4A0C200A
	v_add_nc_u32_e32 v8, s10, v17                              // 0000009077F4: 4A10220A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009077F8: BF870214
	v_min_i32_e32 v5, s3, v4                                   // 0000009077FC: 220A0803
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000907800: 3408069F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000907804: BF870214
	v_min_i32_e32 v7, s3, v6                                   // 000000907808: 220E0C03
	v_min_i32_e32 v9, s3, v8                                   // 00000090780C: 22121003
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000907810: BF870214
	v_ashrrev_i32_e32 v6, 31, v5                               // 000000907814: 340C0A9F
	.long 0xd73c0003                                           // 000000907818: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000090781C: 02020682
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000907820: BF870214
	v_ashrrev_i32_e32 v8, 31, v7                               // 000000907824: 34100E9F
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000907828: 3414129F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000090782C: BF870214
	.long 0xd73c0005                                           // 000000907830: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000907834: 02020A82
	.long 0xd7006a03                                           // 000000907838: D7006A03
	v_cndmask_b32_e32 v1, s12, v3, vcc_lo                      // 00000090783C: 0202060C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000907840: BF8700D1
	v_add_co_ci_u32_e64 v4, null, s13, v4, vcc_lo              // 000000907844: D5207C04 01AA080D
	.long 0xd73c0007                                           // 00000090784C: D73C0007
	v_cndmask_b32_e32 v1, 2, v7, vcc_lo                        // 000000907850: 02020E82
	.long 0xd73c0009                                           // 000000907854: D73C0009
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000907858: 02021282
	global_load_b32 v18, v[3:4], off                           // 00000090785C: DC520000 127C0003
	.long 0xd7006a03                                           // 000000907864: D7006A03
	v_cndmask_b32_e32 v1, s12, v5, vcc_lo                      // 000000907868: 02020A0C
	v_add_co_ci_u32_e64 v4, null, s13, v6, vcc_lo              // 00000090786C: D5207C04 01AA0C0D
	.long 0xd7006a05                                           // 000000907874: D7006A05
	v_cndmask_b32_e32 v1, s12, v7, vcc_lo                      // 000000907878: 02020E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000090787C: BF8700A1
	v_add_co_ci_u32_e64 v6, null, s13, v8, vcc_lo              // 000000907880: D5207C06 01AA100D
	.long 0xd7006a07                                           // 000000907888: D7006A07
	v_cndmask_b32_e32 v1, s12, v9, vcc_lo                      // 00000090788C: 0202120C
	v_add_co_ci_u32_e64 v8, null, s13, v10, vcc_lo             // 000000907890: D5207C08 01AA140D
	s_clause 0x2                                               // 000000907898: BF850002
	global_load_b32 v9, v[3:4], off                            // 00000090789C: DC520000 097C0003
	global_load_b32 v10, v[5:6], off                           // 0000009078A4: DC520000 0A7C0005
	global_load_b32 v19, v[7:8], off                           // 0000009078AC: DC520000 137C0007
	.long 0xd7050003                                           // 0000009078B4: D7050003
	v_cndmask_b32_e32 v1, 0x140, v14, vcc_lo                   // 0000009078B8: 02021CFF 00000140
	.long 0x7f0a3880                                           // 0000009078C0: 7F0A3880
	.long 0xd7054003                                           // 0000009078C4: D7054003
	v_cndmask_b32_e32 v1, 0x140, v16, vcc_lo                   // 0000009078C8: 020220FF 00000140
	.long 0xd7050004                                           // 0000009078D0: D7050004
	v_cndmask_b32_e32 v1, 0x140, v17, vcc_lo                   // 0000009078D4: 020222FF 00000140
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009078DC: BF870124
	.long 0xd7040005                                           // 0000009078E0: D7040005
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000009078E4: 02020701
	.long 0xd7050003                                           // 0000009078E8: D7050003
	v_cndmask_b32_e32 v1, 0x140, v15, vcc_lo                   // 0000009078EC: 02021EFF 00000140
	v_lshlrev_b32_e32 v14, 4, v5                               // 0000009078F4: 301C0A84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009078F8: BF870092
	.long 0xd7040005                                           // 0000009078FC: D7040005
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 000000907900: 0202070B
	v_lshlrev_b32_e32 v11, 4, v5                               // 000000907904: 30160A84
	.long 0xd7041005                                           // 000000907908: D7041005
	v_cndmask_b32_e32 v1, v12, v3, vcc_lo                      // 00000090790C: 0202070C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000907910: BF8700A1
	v_lshlrev_b32_e32 v15, 4, v5                               // 000000907914: 301E0A84
	.long 0xd7040005                                           // 000000907918: D7040005
	v_cndmask_b32_e32 v1, v13, v4, vcc_lo                      // 00000090791C: 0202090D
	v_lshlrev_b32_e32 v16, 4, v5                               // 000000907920: 30200A84
	s_waitcnt vmcnt(3)                                         // 000000907924: BF890FF7
	v_mad_i64_i32 v[3:4], null, 0x1400, v18, s[6:7]            // 000000907928: D6FF7C03 001A24FF 00001400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000907934: BF870091
	.long 0xd7006a03                                           // 000000907938: D7006A03
	v_cndmask_b32_e32 v1, v3, v14, vcc_lo                      // 00000090793C: 02021D03
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000907940: D5207C04 01AA0880
	s_waitcnt vmcnt(2)                                         // 000000907948: BF890BF7
	v_mad_i64_i32 v[5:6], null, 0x1400, v9, s[6:7]             // 00000090794C: D6FF7C05 001A12FF 00001400
	s_waitcnt vmcnt(1)                                         // 000000907958: BF8907F7
	v_mad_i64_i32 v[7:8], null, 0x1400, v10, s[6:7]            // 00000090795C: D6FF7C07 001A14FF 00001400
	s_waitcnt vmcnt(0)                                         // 000000907968: BF8903F7
	v_mad_i64_i32 v[9:10], null, 0x1400, v19, s[6:7]           // 00000090796C: D6FF7C09 001A26FF 00001400
	v_add_nc_u32_e32 v19, 0x80, v1                             // 000000907978: 4A2602FF 00000080
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000907980: BF870094
	.long 0xd7006a0b                                           // 000000907984: D7006A0B
	v_cndmask_b32_e32 v1, v5, v11, vcc_lo                      // 000000907988: 02021705
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 00000090798C: D5207C0C 01AA0C80
	.long 0xd7006a0d                                           // 000000907994: D7006A0D
	v_cndmask_b32_e32 v1, v7, v15, vcc_lo                      // 000000907998: 02021F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000090799C: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v8, vcc_lo               // 0000009079A0: D5207C0E 01AA1080
	.long 0xd7006a0f                                           // 0000009079A8: D7006A0F
	v_cndmask_b32_e32 v1, v9, v16, vcc_lo                      // 0000009079AC: 02022109
	v_add_co_ci_u32_e64 v16, null, 0, v10, vcc_lo              // 0000009079B0: D5207C10 01AA1480
	s_clause 0x3                                               // 0000009079B8: BF850003
	global_load_b128 v[3:6], v[3:4], off                       // 0000009079BC: DC5E0000 037C0003
	global_load_b128 v[7:10], v[11:12], off                    // 0000009079C4: DC5E0000 077C000B
	global_load_b128 v[11:14], v[13:14], off                   // 0000009079CC: DC5E0000 0B7C000D
	global_load_b128 v[15:18], v[15:16], off                   // 0000009079D4: DC5E0000 0F7C000F
	v_cmp_lt_u32_e32 vcc_lo, 0x47f, v1                         // 0000009079DC: 7C9202FF 0000047F
	v_mov_b32_e32 v1, v19                                      // 0000009079E4: 7E020313
	s_waitcnt vmcnt(3)                                         // 0000009079E8: BF890FF7
	ds_store_b128 v2, v[3:6]                                   // 0000009079EC: DB7C0000 00000302
	s_waitcnt vmcnt(2)                                         // 0000009079F4: BF890BF7
	ds_store_b128 v2, v[7:10] offset:512                       // 0000009079F8: DB7C0200 00000702
	s_waitcnt vmcnt(1)                                         // 000000907A00: BF8907F7
	ds_store_b128 v2, v[11:14] offset:1024                     // 000000907A04: DB7C0400 00000B02
	s_waitcnt vmcnt(0)                                         // 000000907A0C: BF8903F7
	ds_store_b128 v2, v[15:18] offset:1536                     // 000000907A10: DB7C0600 00000F02
	v_add_nc_u32_e32 v2, 0x800, v2                             // 000000907A18: 4A0404FF 00000800
	s_or_b32 s20, vcc_lo, s20                                  // 000000907A20: 8C14146A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000907A24: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 000000907A28: 917E147E
	s_cbranch_execnz 65357                                     // 000000907A2C: BFA6FF4D <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x164>
	s_or_b32 exec_lo, exec_lo, s20                             // 000000907A30: 8C7E147E
	s_lshl_b32 s3, s24, 3                                      // 000000907A34: 84038318
	s_ashr_i32 s7, s9, 31                                      // 000000907A38: 86079F09
	s_sub_i32 s12, s2, s3                                      // 000000907A3C: 818C0302
	s_mov_b32 s6, s9                                           // 000000907A40: BE860009
	s_mul_i32 s3, s12, 20                                      // 000000907A44: 9603940C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000907A48: BF870149
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v18, s3             // 000000907A4C: CA100080 01120003
	s_min_i32 s21, s3, 0x8c                                    // 000000907A54: 8915FF03 0000008C
	.long 0xd51a0013                                           // 000000907A5C: D51A0013
	v_cndmask_b32_e32 v0, 31, v3, vcc_lo                       // 000000907A60: 0200069F
	s_add_i32 s13, s21, 20                                     // 000000907A64: 810D9415
	v_mov_b32_e32 v16, v1                                      // 000000907A68: 7E200301
	v_mov_b32_e32 v2, v1                                       // 000000907A6C: 7E040301
	v_dual_mov_b32 v3, v1 :: v_dual_lshlrev_b32 v52, 2, v0     // 000000907A70: CA220101 03340082
	v_mov_b32_e32 v4, v1                                       // 000000907A78: 7E080301
	v_mov_b32_e32 v5, v1                                       // 000000907A7C: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000907A80: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000907A84: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 000000907A88: 7E100301
	v_mov_b32_e32 v9, v1                                       // 000000907A8C: 7E120301
	v_mov_b32_e32 v10, v1                                      // 000000907A90: 7E140301
	v_mov_b32_e32 v11, v1                                      // 000000907A94: 7E160301
	v_mov_b32_e32 v12, v1                                      // 000000907A98: 7E180301
	v_mov_b32_e32 v13, v1                                      // 000000907A9C: 7E1A0301
	v_mov_b32_e32 v14, v1                                      // 000000907AA0: 7E1C0301
	v_mov_b32_e32 v15, v1                                      // 000000907AA4: 7E1E0301
	v_mov_b32_e32 v17, v16                                     // 000000907AA8: 7E220310
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000907AAC: BF870212
	v_mov_b32_e32 v16, v15                                     // 000000907AB0: 7E20030F
	v_mov_b32_e32 v15, v14                                     // 000000907AB4: 7E1E030E
	v_mov_b32_e32 v14, v13                                     // 000000907AB8: 7E1C030D
	v_mov_b32_e32 v13, v12                                     // 000000907ABC: 7E1A030C
	v_mov_b32_e32 v12, v11                                     // 000000907AC0: 7E18030B
	v_mov_b32_e32 v11, v10                                     // 000000907AC4: 7E16030A
	v_mov_b32_e32 v10, v9                                      // 000000907AC8: 7E140309
	v_mov_b32_e32 v9, v8                                       // 000000907ACC: 7E120308
	v_mov_b32_e32 v8, v7                                       // 000000907AD0: 7E100307
	v_mov_b32_e32 v7, v6                                       // 000000907AD4: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 000000907AD8: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000907ADC: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000907AE0: 7E080303
	v_mov_b32_e32 v3, v2                                       // 000000907AE4: 7E060302
	v_mov_b32_e32 v2, v1                                       // 000000907AE8: 7E040301
	s_cmp_lt_i32 s3, s13                                       // 000000907AEC: BF040D03
	s_mul_hi_i32 s22, s8, 0x190000                             // 000000907AF0: 9716FF08 00190000
	s_mul_i32 s23, s8, 0x190000                                // 000000907AF8: 9617FF08 00190000
	s_mul_hi_i32 s26, s9, 0x50000                              // 000000907B00: 971AFF09 00050000
	s_mul_i32 s27, s9, 0x50000                                 // 000000907B08: 961BFF09 00050000
	s_cselect_b32 s28, -1, 0                                   // 000000907B10: 981C80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000907B14: BF870009
	s_and_saveexec_b32 s2, s28                                 // 000000907B18: BE82201C
	s_cbranch_execz 49                                         // 000000907B1C: BFA50031 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x5e4>
	.long 0xd73c0002                                           // 000000907B20: D73C0002
	v_cndmask_b32_e32 v1, 11, v18, vcc_lo                      // 000000907B24: 0202248B
	s_add_u32 s20, s4, s23                                     // 000000907B28: 80141704
	s_addc_u32 s29, s5, s22                                    // 000000907B2C: 821D1605
	s_add_u32 s20, s20, s27                                    // 000000907B30: 80141B14
	s_addc_u32 s29, s29, s26                                   // 000000907B34: 821D1A1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000907B38: BF870091
	.long 0xd7006a02                                           // 000000907B3C: D7006A02
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000907B40: 02020414
	v_add_co_ci_u32_e64 v3, null, s29, v3, vcc_lo              // 000000907B44: D5207C03 01AA061D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000907B4C: BF870092
	.long 0xd7006a14                                           // 000000907B50: D7006A14
	v_cndmask_b32_e32 v1, v2, v52, vcc_lo                      // 000000907B54: 02026902
	v_add_co_ci_u32_e64 v21, null, 0, v3, vcc_lo               // 000000907B58: D5207C15 01AA0680
	s_clause 0xf                                               // 000000907B60: BF85000F
	global_load_b32 v2, v[20:21], off                          // 000000907B64: DC520000 027C0014
	global_load_b32 v3, v[20:21], off offset:128               // 000000907B6C: DC520080 037C0014
	global_load_b32 v4, v[20:21], off offset:256               // 000000907B74: DC520100 047C0014
	global_load_b32 v5, v[20:21], off offset:384               // 000000907B7C: DC520180 057C0014
	global_load_b32 v6, v[20:21], off offset:512               // 000000907B84: DC520200 067C0014
	global_load_b32 v7, v[20:21], off offset:640               // 000000907B8C: DC520280 077C0014
	global_load_b32 v8, v[20:21], off offset:768               // 000000907B94: DC520300 087C0014
	global_load_b32 v9, v[20:21], off offset:896               // 000000907B9C: DC520380 097C0014
	global_load_b32 v10, v[20:21], off offset:1024             // 000000907BA4: DC520400 0A7C0014
	global_load_b32 v11, v[20:21], off offset:1152             // 000000907BAC: DC520480 0B7C0014
	global_load_b32 v12, v[20:21], off offset:1280             // 000000907BB4: DC520500 0C7C0014
	global_load_b32 v13, v[20:21], off offset:1408             // 000000907BBC: DC520580 0D7C0014
	global_load_b32 v14, v[20:21], off offset:1536             // 000000907BC4: DC520600 0E7C0014
	global_load_b32 v15, v[20:21], off offset:1664             // 000000907BCC: DC520680 0F7C0014
	global_load_b32 v16, v[20:21], off offset:1792             // 000000907BD4: DC520700 107C0014
	global_load_b32 v17, v[20:21], off offset:1920             // 000000907BDC: DC520780 117C0014
	s_or_b32 exec_lo, exec_lo, s2                              // 000000907BE4: 8C7E027E
	v_dual_mov_b32 v34, s12 :: v_dual_mov_b32 v53, 0           // 000000907BE8: CA10000C 22340080
	.long 0xd44a0002                                           // 000000907BF0: D44A0002
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000907BF4: 02020080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v86, 0             // 000000907BF8: CA100080 45560080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v54, 0             // 000000907C00: CA100080 25360080
	v_dual_mov_b32 v70, 0 :: v_dual_mov_b32 v87, 0             // 000000907C08: CA100080 46560080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v55, 0             // 000000907C10: CA100080 26360080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v88, 0             // 000000907C18: CA100080 47580080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v56, 0             // 000000907C20: CA100080 27380080
	v_dual_mov_b32 v72, 0 :: v_dual_mov_b32 v89, 0             // 000000907C28: CA100080 48580080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v57, 0             // 000000907C30: CA100080 28380080
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v90, 0             // 000000907C38: CA100080 495A0080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v58, 0             // 000000907C40: CA100080 293A0080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v91, 0             // 000000907C48: CA100080 4A5A0080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v59, 0             // 000000907C50: CA100080 2A3A0080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v92, 0             // 000000907C58: CA100080 4B5C0080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v60, 0             // 000000907C60: CA100080 2B3C0080
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v93, 0             // 000000907C68: CA100080 4C5C0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v61, 0             // 000000907C70: CA100080 2C3C0080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v94, 0             // 000000907C78: CA100080 4D5E0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v62, 0             // 000000907C80: CA100080 2D3E0080
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v95, 0             // 000000907C88: CA100080 4E5E0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v63, 0             // 000000907C90: CA100080 2E3E0080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v96, 0             // 000000907C98: CA100080 4F600080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v64, 0             // 000000907CA0: CA100080 2F400080
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v97, 0             // 000000907CA8: CA100080 50600080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v65, 0             // 000000907CB0: CA100080 30400080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v98, 0             // 000000907CB8: CA100080 51620080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v66, 0             // 000000907CC0: CA100080 31420080
	v_dual_mov_b32 v82, 0 :: v_dual_mov_b32 v99, 0             // 000000907CC8: CA100080 52620080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v67, 0             // 000000907CD0: CA100080 32420080
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v100, 0            // 000000907CD8: CA100080 53640080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v68, 0             // 000000907CE0: CA100080 33440080
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v85, 0             // 000000907CE8: CA100080 54540080
	s_sub_i32 s11, s11, s10                                    // 000000907CF0: 818B0A0B
	s_and_saveexec_b32 s20, s28                                // 000000907CF4: BE94201C
	s_cbranch_execz 2190                                       // 000000907CF8: BFA5088E <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2934>
	v_dual_mov_b32 v84, 0 :: v_dual_lshlrev_b32 v1, 5, v0      // 000000907CFC: CA220080 54000085
	.long 0xd72c0016                                           // 000000907D04: D72C0016
	v_cndmask_b32_e32 v0, 0x280, v12, vcc_lo                   // 000000907D08: 020018FF 00000280
	.long 0xd73c0012                                           // 000000907D10: D73C0012
	v_cndmask_b32_e32 v1, 11, v18, vcc_lo                      // 000000907D14: 0202248B
	s_add_u32 s23, s23, s27                                    // 000000907D18: 80171B17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000907D1C: BF8701B3
	v_dual_mov_b32 v85, 0 :: v_dual_add_nc_u32 v20, 0x3f0, v1  // 000000907D20: CA200080 551402FF 000003F0
	s_addc_u32 s22, s22, s26                                   // 000000907D2C: 82161A16
	.long 0xd50b0015                                           // 000000907D30: D50B0015
	v_cndmask_b32_e32 v0, 0x840, v128, vcc_lo                  // 000000907D34: 020100FF 00000840
	.long 0xd7006a12                                           // 000000907D3C: D7006A12
	v_cndmask_b32_e32 v1, s23, v18, vcc_lo                     // 000000907D40: 02022417
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000907D44: BF870243
	v_lshrrev_b32_e32 v23, 5, v20                              // 000000907D48: 322E2885
	v_and_or_b32 v101, v0, 16, v22                             // 000000907D4C: D6570065 04592100
	v_dual_mov_b32 v51, 0 :: v_dual_and_b32 v20, 0x7e0, v20    // 000000907D54: CA240080 331428FF 000007E0
	v_add_co_ci_u32_e64 v19, null, s22, v19, vcc_lo            // 000000907D60: D5207C13 01AA2616
	v_subrev_nc_u32_e32 v23, 32, v23                           // 000000907D68: 4E2E2EA0
	.long 0xd7006a12                                           // 000000907D6C: D7006A12
	v_cndmask_b32_e32 v1, v18, v52, vcc_lo                     // 000000907D70: 02026912
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000907D74: BF870214
	v_sub_nc_u32_e32 v1, v20, v1                               // 000000907D78: 4C020314
	v_add_co_ci_u32_e64 v19, null, 0, v19, vcc_lo              // 000000907D7C: D5207C13 01AA2680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000907D84: BF870214
	v_cndmask_b32_e64 v22, v23, 31, s2                         // 000000907D88: D5010016 00093F17
	.long 0xd7006a12                                           // 000000907D90: D7006A12
	v_cndmask_b32_e32 v1, s4, v18, vcc_lo                      // 000000907D94: 02022404
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000907D98: BF870194
	v_dual_mov_b32 v67, 0 :: v_dual_add_nc_u32 v102, 0xfffffc30, v1// 000000907D9C: CA200080 436602FF FFFFFC30
	v_dual_mov_b32 v83, 0 :: v_dual_add_nc_u32 v20, 1, v22     // 000000907DA8: CA200080 53142C81
	v_or_b32_e32 v24, v21, v52                                 // 000000907DB0: 38306915
	v_add_co_ci_u32_e64 v19, null, s5, v19, vcc_lo             // 000000907DB4: D5207C13 01AA2605
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000907DBC: BF8701B3
	v_dual_mov_b32 v68, 0 :: v_dual_and_b32 v1, 31, v20        // 000000907DC0: CA240080 4400289F
	.long 0xd7006a23                                           // 000000907DC8: D7006A23
	v_cndmask_b32_e32 v1, 0x800, v18, vcc_lo                   // 000000907DCC: 020224FF 00000800
	v_lshl_or_b32 v18, v22, 2, v21                             // 000000907DD4: D6560012 04550516
	v_lshl_or_b32 v1, v1, 2, v21                               // 000000907DDC: D6560001 04550501
	v_add_co_ci_u32_e64 v36, null, 0, v19, vcc_lo              // 000000907DE4: D5207C24 01AA2680
	.long 0xd5260067                                           // 000000907DEC: D5260067
	v_cndmask_b32_e32 v0, 0, v21, vcc_lo                       // 000000907DF0: 02002A80
	.long 0xd5250068                                           // 000000907DF4: D5250068
	v_cndmask_b32_e32 v0, s3, v129, vcc_lo                     // 000000907DF8: 02010203
	v_dual_mov_b32 v100, 0 :: v_dual_add_nc_u32 v105, 0x5000, v24// 000000907DFC: CA200080 646830FF 00005000
	v_dual_mov_b32 v99, 0 :: v_dual_add_nc_u32 v106, 0x5400, v24// 000000907E08: CA200080 636A30FF 00005400
	v_dual_mov_b32 v50, 0 :: v_dual_add_nc_u32 v107, 0x5000, v18// 000000907E14: CA200080 326A24FF 00005000
	v_dual_mov_b32 v49, 0 :: v_dual_add_nc_u32 v108, 0x5000, v1// 000000907E20: CA200080 316C02FF 00005000
	v_dual_mov_b32 v82, 0 :: v_dual_add_nc_u32 v109, 0x5400, v18// 000000907E2C: CA200080 526C24FF 00005400
	v_dual_mov_b32 v81, 0 :: v_dual_add_nc_u32 v110, 0x5400, v1// 000000907E38: CA200080 516E02FF 00005400
	v_dual_mov_b32 v66, 0 :: v_dual_mov_b32 v65, 0             // 000000907E44: CA100080 42400080
	v_dual_mov_b32 v98, 0 :: v_dual_mov_b32 v97, 0             // 000000907E4C: CA100080 62600080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v47, 0             // 000000907E54: CA100080 302E0080
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v79, 0             // 000000907E5C: CA100080 504E0080
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v63, 0             // 000000907E64: CA100080 403E0080
	v_dual_mov_b32 v96, 0 :: v_dual_mov_b32 v95, 0             // 000000907E6C: CA100080 605E0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v45, 0             // 000000907E74: CA100080 2E2C0080
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v77, 0             // 000000907E7C: CA100080 4E4C0080
	v_dual_mov_b32 v62, 0 :: v_dual_mov_b32 v61, 0             // 000000907E84: CA100080 3E3C0080
	v_dual_mov_b32 v94, 0 :: v_dual_mov_b32 v93, 0             // 000000907E8C: CA100080 5E5C0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v43, 0             // 000000907E94: CA100080 2C2A0080
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v75, 0             // 000000907E9C: CA100080 4C4A0080
	v_dual_mov_b32 v60, 0 :: v_dual_mov_b32 v59, 0             // 000000907EA4: CA100080 3C3A0080
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v91, 0             // 000000907EAC: CA100080 5C5A0080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v41, 0             // 000000907EB4: CA100080 2A280080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v73, 0             // 000000907EBC: CA100080 4A480080
	v_dual_mov_b32 v58, 0 :: v_dual_mov_b32 v57, 0             // 000000907EC4: CA100080 3A380080
	v_dual_mov_b32 v90, 0 :: v_dual_mov_b32 v89, 0             // 000000907ECC: CA100080 5A580080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v39, 0             // 000000907ED4: CA100080 28260080
	v_dual_mov_b32 v72, 0 :: v_dual_mov_b32 v71, 0             // 000000907EDC: CA100080 48460080
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v55, 0             // 000000907EE4: CA100080 38360080
	v_dual_mov_b32 v88, 0 :: v_dual_mov_b32 v87, 0             // 000000907EEC: CA100080 58560080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v37, 0             // 000000907EF4: CA100080 26240080
	v_dual_mov_b32 v70, 0 :: v_dual_mov_b32 v69, 0             // 000000907EFC: CA100080 46440080
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v53, 0             // 000000907F04: CA100080 36340080
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v1, 0              // 000000907F0C: CA100080 56000080
	s_mov_b32 s4, 0                                            // 000000907F14: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000907F18: B0051EEE
	s_branch 1990                                              // 000000907F1C: BFA007C6 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2838>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000907F20: 8C7E037E
	ds_load_2addr_b32 v[111:112], v108 offset1:32              // 000000907F24: D8DC2000 6F00006C
	ds_load_2addr_b32 v[117:118], v105 offset1:32              // 000000907F2C: D8DC2000 75000069
	ds_load_2addr_b32 v[115:116], v107 offset1:32              // 000000907F34: D8DC2000 7300006B
	ds_load_b128 v[30:33], v101                                // 000000907F3C: DBFC0000 1E000065
	ds_load_b128 v[18:21], v101 offset:5120                    // 000000907F44: DBFC1400 12000065
	ds_load_b128 v[22:25], v101 offset:10240                   // 000000907F4C: DBFC2800 16000065
	ds_load_b128 v[26:29], v101 offset:15360                   // 000000907F54: DBFC3C00 1A000065
	.long 0xd7000323                                           // 000000907F5C: D7000323
	v_cndmask_b32_e32 v1, 0x800, v35, vcc_lo                   // 000000907F60: 020246FF 00000800
	v_add_nc_u32_e32 v101, 32, v101                            // 000000907F68: 4ACACAA0
	v_add_co_ci_u32_e64 v36, null, 0, v36, s3                  // 000000907F6C: D5207C24 000E4880
	v_add_nc_u32_e32 v104, 1, v104                             // 000000907F74: 4AD0D081
	s_waitcnt lgkmcnt(6)                                       // 000000907F78: BF89FC67
	v_mov_b32_e32 v114, v111                                   // 000000907F7C: 7EE4036F
	s_waitcnt lgkmcnt(5)                                       // 000000907F80: BF89FC57
	v_bfe_u32 v111, v117, 12, 16                               // 000000907F84: D610006F 02411975
	v_bfe_u32 v119, v117, 8, 16                                // 000000907F8C: D6100077 02411175
	v_bfe_u32 v120, v117, 4, 16                                // 000000907F94: D6100078 02410975
	v_and_b32_e32 v117, 0xffff, v117                           // 000000907F9C: 36EAEAFF 0000FFFF
	s_waitcnt lgkmcnt(4)                                       // 000000907FA4: BF89FC47
	.long 0xd73d0072                                           // 000000907FA8: D73D0072
	v_cndmask_b32_e32 v1, v102, v114, vcc_lo                   // 000000907FAC: 0202E566
	.long 0xd72c0073                                           // 000000907FB0: D72C0073
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 000000907FB4: 0202DEFF 83DCD12D
	.long 0xd72c0077                                           // 000000907FBC: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000907FC0: 0202EEFF 83DCD12D
	v_mov_b32_e32 v113, v116                                   // 000000907FC8: 7EE20374
	v_bfe_u32 v116, v118, 12, 16                               // 000000907FCC: D6100074 02411976
	v_bfe_u32 v121, v118, 8, 16                                // 000000907FD4: D6100079 02411176
	v_bfe_u32 v122, v118, 4, 16                                // 000000907FDC: D610007A 02410976
	v_and_b32_e32 v118, 0xffff, v118                           // 000000907FE4: 36ECECFF 0000FFFF
	.long 0xd73d006f                                           // 000000907FEC: D73D006F
	v_cndmask_b32_e32 v1, v102, v112, vcc_lo                   // 000000907FF0: 0202E166
	v_sad_u8 v115, v115, 0, 0x6400                             // 000000907FF4: D6220073 03FD0173 00006400
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000908000: D6220077 03FD0177 00006400
	.long 0xd72c0070                                           // 00000090800C: D72C0070
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 000000908010: 0202E8FF 83DCD12D
	.long 0xd72c0071                                           // 000000908018: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 00000090801C: 0202F2FF 83DCD12D
	v_bfe_u32 v116, v114, 12, 16                               // 000000908024: D6100074 02411972
	v_and_b32_e32 v115, 0xffff, v115                           // 00000090802C: 36E6E6FF 0000FFFF
	v_bfe_u32 v121, v114, 8, 16                                // 000000908034: D6100079 02411172
	v_bfe_u32 v123, v114, 4, 16                                // 00000090803C: D610007B 02410972
	.long 0xd72c0075                                           // 000000908044: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000908048: 0202EAFF 83DCD12D
	.long 0xd72c0074                                           // 000000908050: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 000000908054: 0202E8FF 83DCD12D
	v_lshl_or_b32 v115, v119, 16, v115                         // 00000090805C: D6560073 05CD2177
	.long 0xd72c0079                                           // 000000908064: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000908068: 0202F2FF 83DCD12D
	.long 0xd72c007b                                           // 000000908070: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000908074: 0202F6FF 83DCD12D
	.long 0xd72c0078                                           // 00000090807C: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000908080: 0202F0FF 83DCD12D
	v_bfe_u32 v124, v111, 12, 16                               // 000000908088: D610007C 0241196F
	v_pk_fma_f16 v115, v115, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908090: CC0E0073 0BFC0B73 0000C931
	v_and_b32_e32 v114, 0xffff, v114                           // 00000090809C: 36E4E4FF 0000FFFF
	v_sad_u8 v116, v116, 0, 0x6400                             // 0000009080A4: D6220074 03FD0174 00006400
	v_sad_u8 v117, v117, 0, 0x6400                             // 0000009080B0: D6220075 03FD0175 00006400
	v_sad_u8 v121, v121, 0, 0x6400                             // 0000009080BC: D6220079 03FD0179 00006400
	v_sad_u8 v123, v123, 0, 0x6400                             // 0000009080C8: D622007B 03FD017B 00006400
	.long 0xd72c0072                                           // 0000009080D4: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 0000009080D8: 0202E4FF 83DCD12D
	v_bfe_u32 v125, v111, 8, 16                                // 0000009080E0: D610007D 0241116F
	v_bfe_u32 v126, v111, 4, 16                                // 0000009080E8: D610007E 0241096F
	v_sad_u8 v120, v120, 0, 0x6400                             // 0000009080F0: D6220078 03FD0178 00006400
	.long 0xd72c007c                                           // 0000009080FC: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 000000908100: 0202F8FF 83DCD12D
	v_sad_u8 v112, v112, 0, 0x6400                             // 000000908108: D6220070 03FD0170 00006400
	.long 0xd72c007d                                           // 000000908114: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000908118: 0202FAFF 83DCD12D
	.long 0xd72c0076                                           // 000000908120: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000908124: 0202ECFF 83DCD12D
	v_sad_u8 v114, v114, 0, 0x6400                             // 00000090812C: D6220072 03FD0172 00006400
	v_sad_u8 v113, v113, 0, 0x6400                             // 000000908138: D6220071 03FD0171 00006400
	.long 0xd72c007a                                           // 000000908144: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 000000908148: 0202F4FF 83DCD12D
	v_sad_u8 v119, v124, 0, 0x6400                             // 000000908150: D6220077 03FD017C 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000090815C: BF870094
	v_lshlrev_b32_e32 v114, 16, v114                           // 000000908160: 30E4E490
	v_and_or_b32 v114, 0xffff, v123, v114                      // 000000908164: D6570072 05CAF6FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000908170: BF8700A1
	v_pk_fma_f16 v114, v114, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908174: CC0E0072 0BFC0B72 0000C931
	v_and_b32_e32 v116, 0xffff, v116                           // 000000908180: 36E8E8FF 0000FFFF
	v_lshl_or_b32 v116, v121, 16, v116                         // 000000908188: D6560074 05D12179
	.long 0xd72c0079                                           // 000000908190: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000908194: 0202FCFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000090819C: BF8700A2
	v_pk_fma_f16 v116, v116, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009081A0: CC0E0074 0BFC0B74 0000C931
	s_waitcnt lgkmcnt(2)                                       // 0000009081AC: BF89FC27
	v_dual_dot2acc_f32_f16 v84, v116, v18 :: v_dual_and_b32 v111, 0xffff, v111// 0000009081B0: CB242574 546EDEFF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 0000009081BC: BF89FC17
	v_dual_dot2acc_f32_f16 v68, v116, v22 :: v_dual_lshlrev_b32 v117, 16, v117// 0000009081C0: CB222D74 4474EA90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009081C8: BF870192
	.long 0xd72c006f                                           // 0000009081CC: D72C006F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 0000009081D0: 0202DEFF 83DCD12D
	v_dual_dot2acc_f32_f16 v85, v116, v30 :: v_dual_dot2acc_f32_f16 v84, v114, v19// 0000009081D8: CB183D74 55542772
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009081E0: BF8701B3
	v_and_or_b32 v117, 0xffff, v120, v117                      // 0000009081E4: D6570075 05D6F0FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 0000009081F0: BF89FC07
	v_dual_dot2acc_f32_f16 v51, v116, v26 :: v_dual_dot2acc_f32_f16 v68, v114, v23// 0000009081F4: CB183574 33442F72
	v_dual_dot2acc_f32_f16 v85, v114, v31 :: v_dual_dot2acc_f32_f16 v84, v115, v20// 0000009081FC: CB183F72 55542973
	v_sad_u8 v111, v111, 0, 0x6400                             // 000000908204: D622006F 03FD016F 00006400
	v_pk_fma_f16 v120, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908210: CC0E0078 0BFC0B75 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000090821C: BF870214
	v_dual_dot2acc_f32_f16 v51, v114, v27 :: v_dual_dot2acc_f32_f16 v68, v115, v24// 000000908220: CB183772 33443173
	v_dual_dot2acc_f32_f16 v85, v115, v32 :: v_dual_and_b32 v114, 0xffff, v119// 000000908228: CB244173 5572EEFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000908234: BF870193
	v_dual_dot2acc_f32_f16 v84, v120, v21 :: v_dual_lshlrev_b32 v117, 16, v111// 000000908238: CB222B78 5474DE90
	v_dual_dot2acc_f32_f16 v51, v115, v28 :: v_dual_dot2acc_f32_f16 v68, v120, v25// 000000908240: CB183973 33443378
	v_and_b32_e32 v119, 0xffff, v112                           // 000000908248: 36EEE0FF 0000FFFF
	v_sad_u8 v115, v125, 0, 0x6400                             // 000000908250: D6220073 03FD017D 00006400
	ds_load_2addr_b32 v[111:112], v108 offset0:64 offset1:96   // 00000090825C: D8DC6040 6F00006C
	v_dot2acc_f32_f16 v85, v120, v33                           // 000000908264: 04AA4378
	v_sad_u8 v116, v121, 0, 0x6400                             // 000000908268: D6220074 03FD0179 00006400
	v_lshl_or_b32 v113, v113, 16, v119                         // 000000908274: D6560071 05DD2171
	v_lshl_or_b32 v121, v115, 16, v114                         // 00000090827C: D6560079 05C92173
	ds_load_2addr_b32 v[114:115], v107 offset0:64 offset1:96   // 000000908284: D8DC6040 7200006B
	v_and_or_b32 v116, 0xffff, v116, v117                      // 00000090828C: D6570074 05D6E8FF 0000FFFF
	v_sad_u8 v117, v118, 0, 0x6400                             // 000000908298: D6220075 03FD0176 00006400
	v_pk_fma_f16 v118, v121, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009082A4: CC0E0076 0BFC0B79 0000C931
	v_pk_fma_f16 v121, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009082B0: CC0E0079 0BFC0B71 0000C931
	v_sad_u8 v113, v122, 0, 0x6400                             // 0000009082BC: D6220071 03FD017A 00006400
	v_pk_fma_f16 v119, v116, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009082C8: CC0E0077 0BFC0B74 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009082D4: BF870004
	v_dual_dot2acc_f32_f16 v83, v118, v18 :: v_dual_lshlrev_b32 v122, 16, v117// 0000009082D8: CB222576 537AEA90
	v_dot2acc_f32_f16 v50, v118, v26                           // 0000009082E0: 04643576
	v_dot2acc_f32_f16 v100, v118, v30                          // 0000009082E4: 04C83D76
	ds_load_2addr_b32 v[116:117], v105 offset0:64 offset1:96   // 0000009082E8: D8DC6040 74000069
	v_and_or_b32 v122, 0xffff, v113, v122                      // 0000009082F0: D657007A 05EAE2FF 0000FFFF
	v_dot2acc_f32_f16 v83, v119, v19                           // 0000009082FC: 04A62777
	s_waitcnt lgkmcnt(2)                                       // 000000908300: BF89FC27
	v_mov_b32_e32 v113, v111                                   // 000000908304: 7EE2036F
	v_dual_dot2acc_f32_f16 v67, v118, v22 :: v_dual_dot2acc_f32_f16 v100, v119, v31// 000000908308: CB182D76 43643F77
	v_dot2acc_f32_f16 v50, v119, v27                           // 000000908310: 04643777
	v_pk_fma_f16 v111, v122, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908314: CC0E006F 0BFC0B7A 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000908320: BF89FC17
	.long 0xd73d0071                                           // 000000908324: D73D0071
	v_cndmask_b32_e32 v1, v102, v113, vcc_lo                   // 000000908328: 0202E366
	v_dual_dot2acc_f32_f16 v67, v119, v23 :: v_dual_dot2acc_f32_f16 v100, v121, v32// 00000090832C: CB182F77 43644179
	v_dot2acc_f32_f16 v83, v121, v20                           // 000000908334: 04A62979
	v_dual_dot2acc_f32_f16 v51, v120, v29 :: v_dual_dot2acc_f32_f16 v50, v121, v28// 000000908338: CB183B78 33323979
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000908340: BF870214
	v_bfe_u32 v114, v113, 12, 16                               // 000000908344: D6100072 02411971
	v_dot2acc_f32_f16 v67, v121, v24                           // 00000090834C: 04863179
	v_bfe_u32 v119, v113, 8, 16                                // 000000908350: D6100077 02411171
	v_dot2acc_f32_f16 v100, v111, v33                          // 000000908358: 04C8436F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000090835C: BF870004
	.long 0xd72c0072                                           // 000000908360: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 000000908364: 0202E4FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 00000090836C: BF89FC07
	v_bfe_u32 v120, v116, 12, 16                               // 000000908370: D6100078 02411974
	.long 0xd72c0077                                           // 000000908378: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 00000090837C: 0202EEFF 83DCD12D
	v_bfe_u32 v122, v116, 8, 16                                // 000000908384: D610007A 02411174
	v_bfe_u32 v123, v116, 4, 16                                // 00000090838C: D610007B 02410974
	v_and_b32_e32 v116, 0xffff, v116                           // 000000908394: 36E8E8FF 0000FFFF
	.long 0xd72c0078                                           // 00000090839C: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 0000009083A0: 0202F0FF 83DCD12D
	v_sad_u8 v114, v114, 0, 0x6400                             // 0000009083A8: D6220072 03FD0172 00006400
	v_dot2acc_f32_f16 v83, v111, v21                           // 0000009083B4: 04A62B6F
	v_sad_u8 v119, v119, 0, 0x6400                             // 0000009083B8: D6220077 03FD0177 00006400
	.long 0xd72c0074                                           // 0000009083C4: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 0000009083C8: 0202E8FF 83DCD12D
	.long 0xd72c007a                                           // 0000009083D0: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 0000009083D4: 0202F4FF 83DCD12D
	v_and_b32_e32 v114, 0xffff, v114                           // 0000009083DC: 36E4E4FF 0000FFFF
	v_sad_u8 v120, v120, 0, 0x6400                             // 0000009083E4: D6220078 03FD0178 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009083F0: BF8701A2
	v_lshl_or_b32 v114, v119, 16, v114                         // 0000009083F4: D6560072 05C92177
	.long 0xd72c0077                                           // 0000009083FC: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000908400: 0202F6FF 83DCD12D
	v_and_b32_e32 v120, 0xffff, v120                           // 000000908408: 36F0F0FF 0000FFFF
	v_sad_u8 v122, v122, 0, 0x6400                             // 000000908410: D622007A 03FD017A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000090841C: BF870244
	v_pk_fma_f16 v114, v114, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908420: CC0E0072 0BFC0B72 0000C931
	v_and_b32_e32 v118, 0xffff, v113                           // 00000090842C: 36ECE2FF 0000FFFF
	v_bfe_u32 v113, v113, 4, 16                                // 000000908434: D6100071 02410971
	v_sad_u8 v119, v119, 0, 0x6400                             // 00000090843C: D6220077 03FD0177 00006400
	v_dot2acc_f32_f16 v99, v114, v30                           // 000000908448: 04C63D72
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000090844C: BF870214
	.long 0xd72c0076                                           // 000000908450: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000908454: 0202ECFF 83DCD12D
	.long 0xd72c0071                                           // 00000090845C: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 000000908460: 0202E2FF 83DCD12D
	v_dual_dot2acc_f32_f16 v50, v111, v29 :: v_dual_dot2acc_f32_f16 v49, v114, v26// 000000908468: CB183B6F 32303572
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000908470: BF870223
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000908474: D6220076 03FD0176 00006400
	v_dot2acc_f32_f16 v67, v111, v25                           // 000000908480: 0486336F
	v_sad_u8 v113, v113, 0, 0x6400                             // 000000908484: D6220071 03FD0171 00006400
	v_sad_u8 v111, v116, 0, 0x6400                             // 000000908490: D622006F 03FD0174 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000090849C: BF870114
	v_lshlrev_b32_e32 v118, 16, v118                           // 0000009084A0: 30ECEC90
	v_lshlrev_b32_e32 v111, 16, v111                           // 0000009084A4: 30DEDE90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009084A8: BF870092
	v_and_or_b32 v113, 0xffff, v113, v118                      // 0000009084AC: D6570071 05DAE2FF 0000FFFF
	v_pk_fma_f16 v116, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009084B8: CC0E0074 0BFC0B71 0000C931
	v_mov_b32_e32 v113, v115                                   // 0000009084C4: 7EE20373
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009084C8: BF870224
	v_and_or_b32 v115, 0xffff, v119, v111                      // 0000009084CC: D6570073 05BEEEFF 0000FFFF
	v_lshl_or_b32 v118, v122, 16, v120                         // 0000009084D8: D6560076 05E1217A
	v_dual_dot2acc_f32_f16 v66, v114, v22 :: v_dual_dot2acc_f32_f16 v49, v116, v27// 0000009084E0: CB182D72 42303774
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009084E8: BF870224
	.long 0xd73d006f                                           // 0000009084EC: D73D006F
	v_cndmask_b32_e32 v1, v102, v112, vcc_lo                   // 0000009084F0: 0202E166
	v_dot2acc_f32_f16 v99, v116, v31                           // 0000009084F4: 04C63F74
	v_pk_fma_f16 v118, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009084F8: CC0E0076 0BFC0B76 0000C931
	v_pk_fma_f16 v119, v115, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908504: CC0E0077 0BFC0B73 0000C931
	v_bfe_u32 v115, v117, 12, 16                               // 000000908510: D6100073 02411975
	v_dot2acc_f32_f16 v66, v116, v23                           // 000000908518: 04842F74
	v_bfe_u32 v112, v111, 12, 16                               // 00000090851C: D6100070 0241196F
	v_dot2acc_f32_f16 v99, v118, v32                           // 000000908524: 04C64176
	v_dot2acc_f32_f16 v82, v114, v18                           // 000000908528: 04A42572
	v_and_b32_e32 v114, 0xffff, v111                           // 00000090852C: 36E4DEFF 0000FFFF
	v_bfe_u32 v113, v111, 8, 16                                // 000000908534: D6100071 0241116F
	.long 0xd72c0070                                           // 00000090853C: D72C0070
	v_cndmask_b32_e32 v1, 0x83dcd12d, v112, vcc_lo             // 000000908540: 0202E0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000908548: BF870004
	v_dual_dot2acc_f32_f16 v99, v119, v33 :: v_dual_dot2acc_f32_f16 v82, v116, v19// 00000090854C: CB184377 63522774
	v_bfe_u32 v111, v111, 4, 16                                // 000000908554: D610006F 0241096F
	.long 0xd72c0072                                           // 00000090855C: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 000000908560: 0202E4FF 83DCD12D
	.long 0xd72c0073                                           // 000000908568: D72C0073
	v_cndmask_b32_e32 v1, 0x83dcd12d, v115, vcc_lo             // 00000090856C: 0202E6FF 83DCD12D
	v_bfe_u32 v116, v117, 8, 16                                // 000000908574: D6100074 02411175
	.long 0xd72c0071                                           // 00000090857C: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 000000908580: 0202E2FF 83DCD12D
	v_sad_u8 v112, v112, 0, 0x6400                             // 000000908588: D6220070 03FD0170 00006400
	.long 0xd72c0079                                           // 000000908594: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 000000908598: 0202DEFF 83DCD12D
	v_bfe_u32 v120, v117, 4, 16                                // 0000009085A0: D6100078 02410975
	v_and_b32_e32 v117, 0xffff, v117                           // 0000009085A8: 36EAEAFF 0000FFFF
	v_sad_u8 v123, v114, 0, 0x6400                             // 0000009085B0: D622007B 03FD0172 00006400
	v_and_b32_e32 v122, 0xffff, v112                           // 0000009085BC: 36F4E0FF 0000FFFF
	ds_load_2addr_b32 v[111:112], v108 offset0:128 offset1:160 // 0000009085C4: D8DCA080 6F00006C
	v_sad_u8 v124, v115, 0, 0x6400                             // 0000009085CC: D622007C 03FD0173 00006400
	ds_load_2addr_b32 v[114:115], v107 offset0:128 offset1:160 // 0000009085D8: D8DCA080 7200006B
	.long 0xd72c0075                                           // 0000009085E0: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 0000009085E4: 0202EAFF 83DCD12D
	v_sad_u8 v113, v113, 0, 0x6400                             // 0000009085EC: D6220071 03FD0171 00006400
	.long 0xd72c0074                                           // 0000009085F8: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 0000009085FC: 0202E8FF 83DCD12D
	.long 0xd72c0078                                           // 000000908604: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000908608: 0202F0FF 83DCD12D
	v_dual_dot2acc_f32_f16 v82, v118, v20 :: v_dual_lshlrev_b32 v123, 16, v123// 000000908610: CB222976 527AF690
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000908618: D6220079 03FD0179 00006400
	v_lshl_or_b32 v113, v113, 16, v122                         // 000000908624: D6560071 05E92171
	v_sad_u8 v117, v117, 0, 0x6400                             // 00000090862C: D6220075 03FD0175 00006400
	v_dot2acc_f32_f16 v66, v118, v24                           // 000000908638: 04843176
	v_sad_u8 v116, v116, 0, 0x6400                             // 00000090863C: D6220074 03FD0174 00006400
	v_dot2acc_f32_f16 v49, v118, v28                           // 000000908648: 04623976
	v_and_or_b32 v118, 0xffff, v121, v123                      // 00000090864C: D6570076 05EEF2FF 0000FFFF
	v_pk_fma_f16 v121, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908658: CC0E0079 0BFC0B71 0000C931
	v_and_b32_e32 v124, 0xffff, v124                           // 000000908664: 36F8F8FF 0000FFFF
	v_lshlrev_b32_e32 v117, 16, v117                           // 00000090866C: 30EAEA90
	v_dot2acc_f32_f16 v66, v119, v25                           // 000000908670: 04843377
	s_waitcnt lgkmcnt(1)                                       // 000000908674: BF89FC17
	v_mov_b32_e32 v113, v111                                   // 000000908678: 7EE2036F
	v_sad_u8 v120, v120, 0, 0x6400                             // 00000090867C: D6220078 03FD0178 00006400
	v_dot2acc_f32_f16 v65, v121, v22                           // 000000908688: 04822D79
	v_lshl_or_b32 v116, v116, 16, v124                         // 00000090868C: D6560074 05F12174
	v_pk_fma_f16 v118, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908694: CC0E0076 0BFC0B76 0000C931
	s_waitcnt lgkmcnt(0)                                       // 0000009086A0: BF89FC07
	.long 0xd73d0071                                           // 0000009086A4: D73D0071
	v_cndmask_b32_e32 v1, v102, v113, vcc_lo                   // 0000009086A8: 0202E366
	v_and_or_b32 v111, 0xffff, v120, v117                      // 0000009086AC: D657006F 05D6F0FF 0000FFFF
	v_dot2acc_f32_f16 v81, v121, v18                           // 0000009086B8: 04A22579
	v_pk_fma_f16 v122, v116, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009086BC: CC0E007A 0BFC0B74 0000C931
	ds_load_2addr_b32 v[116:117], v105 offset0:128 offset1:160 // 0000009086C8: D8DCA080 74000069
	v_dot2acc_f32_f16 v98, v121, v30                           // 0000009086D0: 04C43D79
	v_pk_fma_f16 v114, v111, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009086D4: CC0E0072 0BFC0B6F 0000C931
	v_bfe_u32 v111, v113, 12, 16                               // 0000009086E0: D610006F 02411971
	v_dual_dot2acc_f32_f16 v82, v119, v21 :: v_dual_dot2acc_f32_f16 v81, v118, v19// 0000009086E8: CB182B77 52502776
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009086F0: BF870194
	v_dual_dot2acc_f32_f16 v98, v118, v31 :: v_dual_dot2acc_f32_f16 v49, v119, v29// 0000009086F4: CB183F76 62303B77
	.long 0xd72c006f                                           // 0000009086FC: D72C006F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 000000908700: 0202DEFF 83DCD12D
	v_bfe_u32 v119, v113, 8, 16                                // 000000908708: D6100077 02411171
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000908710: BF8701A4
	v_dual_dot2acc_f32_f16 v81, v122, v20 :: v_dual_dot2acc_f32_f16 v48, v121, v26// 000000908714: CB18297A 51303579
	v_dual_dot2acc_f32_f16 v65, v118, v23 :: v_dual_and_b32 v120, 0xffff, v113// 00000090871C: CB242F76 4178E2FF 0000FFFF
	.long 0xd72c0077                                           // 000000908728: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 00000090872C: 0202EEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000908734: BF870003
	v_dot2acc_f32_f16 v81, v114, v21                           // 000000908738: 04A22B72
	v_sad_u8 v111, v111, 0, 0x6400                             // 00000090873C: D622006F 03FD016F 00006400
	v_dot2acc_f32_f16 v98, v122, v32                           // 000000908748: 04C4417A
	v_bfe_u32 v113, v113, 4, 16                                // 00000090874C: D6100071 02410971
	.long 0xd72c0078                                           // 000000908754: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000908758: 0202F0FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000908760: BF89FC07
	v_bfe_u32 v121, v116, 12, 16                               // 000000908764: D6100079 02411974
	v_and_b32_e32 v111, 0xffff, v111                           // 00000090876C: 36DEDEFF 0000FFFF
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000908774: D6220077 03FD0177 00006400
	v_and_b32_e32 v124, 0xffff, v116                           // 000000908780: 36F8E8FF 0000FFFF
	v_bfe_u32 v123, v116, 8, 16                                // 000000908788: D610007B 02411174
	.long 0xd72c0079                                           // 000000908790: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000908794: 0202F2FF 83DCD12D
	.long 0xd72c0071                                           // 00000090879C: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 0000009087A0: 0202E2FF 83DCD12D
	v_lshl_or_b32 v111, v119, 16, v111                         // 0000009087A8: D656006F 05BD2177
	.long 0xd72c0077                                           // 0000009087B0: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 0000009087B4: 0202F8FF 83DCD12D
	v_sad_u8 v120, v120, 0, 0x6400                             // 0000009087BC: D6220078 03FD0178 00006400
	v_bfe_u32 v116, v116, 4, 16                                // 0000009087C8: D6100074 02410974
	.long 0xd72c007b                                           // 0000009087D0: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 0000009087D4: 0202F6FF 83DCD12D
	v_pk_fma_f16 v111, v111, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009087DC: CC0E006F 0BFC0B6F 0000C931
	v_sad_u8 v121, v121, 0, 0x6400                             // 0000009087E8: D6220079 03FD0179 00006400
	v_dot2acc_f32_f16 v48, v118, v27                           // 0000009087F4: 04603776
	v_sad_u8 v113, v113, 0, 0x6400                             // 0000009087F8: D6220071 03FD0171 00006400
	v_sad_u8 v118, v119, 0, 0x6400                             // 000000908804: D6220076 03FD0177 00006400
	v_dot2acc_f32_f16 v65, v122, v24                           // 000000908810: 0482317A
	v_lshlrev_b32_e32 v120, 16, v120                           // 000000908814: 30F0F090
	.long 0xd72c0074                                           // 000000908818: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 00000090881C: 0202E8FF 83DCD12D
	v_and_b32_e32 v119, 0xffff, v121                           // 000000908824: 36EEF2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000090882C: BF870214
	v_dual_dot2acc_f32_f16 v65, v114, v25 :: v_dual_lshlrev_b32 v118, 16, v118// 000000908830: CB223372 4176EC90
	v_and_or_b32 v113, 0xffff, v113, v120                      // 000000908838: D6570071 05E2E2FF 0000FFFF
	v_sad_u8 v120, v123, 0, 0x6400                             // 000000908844: D6220078 03FD017B 00006400
	v_dual_dot2acc_f32_f16 v98, v114, v33 :: v_dual_dot2acc_f32_f16 v97, v111, v30// 000000908850: CB184372 62603D6F
	v_sad_u8 v116, v116, 0, 0x6400                             // 000000908858: D6220074 03FD0174 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000908864: BF870214
	v_pk_fma_f16 v121, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908868: CC0E0079 0BFC0B71 0000C931
	v_lshl_or_b32 v113, v120, 16, v119                         // 000000908874: D6560071 05DD2178
	v_dot2acc_f32_f16 v48, v122, v28                           // 00000090887C: 0460397A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000908880: BF870214
	v_and_or_b32 v116, 0xffff, v116, v118                      // 000000908884: D6570074 05DAE8FF 0000FFFF
	v_dot2acc_f32_f16 v97, v121, v31                           // 000000908890: 04C23F79
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000908894: BF870254
	v_pk_fma_f16 v118, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908898: CC0E0076 0BFC0B71 0000C931
	v_dot2acc_f32_f16 v80, v111, v18                           // 0000009088A4: 04A0256F
	v_mov_b32_e32 v113, v115                                   // 0000009088A8: 7EE20373
	v_bfe_u32 v115, v117, 12, 16                               // 0000009088AC: D6100073 02411975
	v_pk_fma_f16 v119, v116, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009088B4: CC0E0077 0BFC0B74 0000C931
	v_dual_dot2acc_f32_f16 v97, v118, v32 :: v_dual_dot2acc_f32_f16 v80, v121, v19// 0000009088C0: CB184176 61502779
	v_dot2acc_f32_f16 v47, v111, v26                           // 0000009088C8: 045E356F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009088CC: BF870224
	.long 0xd72c0073                                           // 0000009088D0: D72C0073
	v_cndmask_b32_e32 v1, 0x83dcd12d, v115, vcc_lo             // 0000009088D4: 0202E6FF 83DCD12D
	v_bfe_u32 v116, v117, 8, 16                                // 0000009088DC: D6100074 02411175
	v_dual_dot2acc_f32_f16 v97, v119, v33 :: v_dual_dot2acc_f32_f16 v80, v118, v20// 0000009088E4: CB184377 61502976
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009088EC: BF870224
	v_dual_dot2acc_f32_f16 v64, v111, v22 :: v_dual_dot2acc_f32_f16 v47, v121, v27// 0000009088F0: CB182D6F 402E3779
	.long 0xd73d006f                                           // 0000009088F8: D73D006F
	v_cndmask_b32_e32 v1, v102, v112, vcc_lo                   // 0000009088FC: 0202E166
	.long 0xd72c0074                                           // 000000908900: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 000000908904: 0202E8FF 83DCD12D
	v_sad_u8 v115, v115, 0, 0x6400                             // 00000090890C: D6220073 03FD0173 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000908918: BF8701B4
	v_dot2acc_f32_f16 v64, v121, v23                           // 00000090891C: 04802F79
	v_dot2acc_f32_f16 v48, v114, v29                           // 000000908920: 04603B72
	v_dual_dot2acc_f32_f16 v80, v119, v21 :: v_dual_dot2acc_f32_f16 v47, v118, v28// 000000908924: CB182B77 502E3976
	v_dual_dot2acc_f32_f16 v64, v118, v24 :: v_dual_and_b32 v113, 0xffff, v111// 00000090892C: CB243176 4070DEFF 0000FFFF
	v_bfe_u32 v112, v111, 12, 16                               // 000000908938: D6100070 0241196F
	v_bfe_u32 v114, v111, 8, 16                                // 000000908940: D6100072 0241116F
	v_bfe_u32 v111, v111, 4, 16                                // 000000908948: D610006F 0241096F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000908950: BF870004
	.long 0xd72c0071                                           // 000000908954: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 000000908958: 0202E2FF 83DCD12D
	v_bfe_u32 v118, v117, 4, 16                                // 000000908960: D6100076 02410975
	.long 0xd72c0070                                           // 000000908968: D72C0070
	v_cndmask_b32_e32 v1, 0x83dcd12d, v112, vcc_lo             // 00000090896C: 0202E0FF 83DCD12D
	.long 0xd72c0072                                           // 000000908974: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 000000908978: 0202E4FF 83DCD12D
	.long 0xd72c006f                                           // 000000908980: D72C006F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 000000908984: 0202DEFF 83DCD12D
	v_and_b32_e32 v115, 0xffff, v115                           // 00000090898C: 36E6E6FF 0000FFFF
	v_sad_u8 v116, v116, 0, 0x6400                             // 000000908994: D6220074 03FD0174 00006400
	.long 0xd72c0076                                           // 0000009089A0: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 0000009089A4: 0202ECFF 83DCD12D
	v_sad_u8 v113, v113, 0, 0x6400                             // 0000009089AC: D6220071 03FD0171 00006400
	v_sad_u8 v112, v112, 0, 0x6400                             // 0000009089B8: D6220070 03FD0170 00006400
	v_sad_u8 v114, v114, 0, 0x6400                             // 0000009089C4: D6220072 03FD0172 00006400
	v_sad_u8 v121, v111, 0, 0x6400                             // 0000009089D0: D6220079 03FD016F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009089DC: BF870124
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000009089E0: 30E2E290
	v_lshl_or_b32 v116, v116, 16, v115                         // 0000009089E4: D6560074 05CD2174
	v_and_or_b32 v113, 0xffff, v121, v113                      // 0000009089EC: D6570071 05C6F2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009089F8: BF870112
	v_pk_fma_f16 v122, v116, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009089FC: CC0E007A 0BFC0B74 0000C931
	v_pk_fma_f16 v121, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908A08: CC0E0079 0BFC0B71 0000C931
	v_and_b32_e32 v120, 0xffff, v112                           // 000000908A14: 36F0E0FF 0000FFFF
	ds_load_2addr_b32 v[111:112], v108 offset0:192 offset1:224 // 000000908A1C: D8DCE0C0 6F00006C
	v_sad_u8 v113, v118, 0, 0x6400                             // 000000908A24: D6220071 03FD0176 00006400
	v_lshl_or_b32 v120, v114, 16, v120                         // 000000908A30: D6560078 05E12172
	ds_load_2addr_b32 v[114:115], v107 offset0:192 offset1:224 // 000000908A38: D8DCE0C0 7200006B
	v_pk_fma_f16 v120, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908A40: CC0E0078 0BFC0B78 0000C931
	v_and_b32_e32 v117, 0xffff, v117                           // 000000908A4C: 36EAEAFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000908A54: BF8701A2
	v_dual_dot2acc_f32_f16 v64, v119, v25 :: v_dual_dot2acc_f32_f16 v79, v120, v18// 000000908A58: CB183377 404E2578
	v_dot2acc_f32_f16 v96, v120, v30                           // 000000908A60: 04C03D78
	.long 0xd72c0075                                           // 000000908A64: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000908A68: 0202EAFF 83DCD12D
	v_dot2acc_f32_f16 v63, v120, v22                           // 000000908A70: 047E2D78
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000908A74: BF870214
	v_dual_dot2acc_f32_f16 v46, v120, v26 :: v_dual_dot2acc_f32_f16 v79, v121, v19// 000000908A78: CB183578 2E4E2779
	v_dot2acc_f32_f16 v96, v121, v31                           // 000000908A80: 04C03F79
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000908A84: BF870193
	v_dot2acc_f32_f16 v63, v121, v23                           // 000000908A88: 047E2F79
	v_dot2acc_f32_f16 v46, v121, v27                           // 000000908A8C: 045C3779
	v_sad_u8 v117, v117, 0, 0x6400                             // 000000908A90: D6220075 03FD0175 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000908A9C: BF870214
	v_dot2acc_f32_f16 v96, v122, v32                           // 000000908AA0: 04C0417A
	v_dot2acc_f32_f16 v63, v122, v24                           // 000000908AA4: 047E317A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000908AA8: BF870214
	v_dot2acc_f32_f16 v46, v122, v28                           // 000000908AAC: 045C397A
	v_lshlrev_b32_e32 v118, 16, v117                           // 000000908AB0: 30ECEA90
	ds_load_2addr_b32 v[116:117], v105 offset0:192 offset1:224 // 000000908AB4: D8DCE0C0 74000069
	v_dot2acc_f32_f16 v47, v119, v29                           // 000000908ABC: 045E3B77
	v_and_or_b32 v118, 0xffff, v113, v118                      // 000000908AC0: D6570076 05DAE2FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 000000908ACC: BF89FC27
	v_mov_b32_e32 v113, v111                                   // 000000908AD0: 7EE2036F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000908AD4: BF870122
	v_pk_fma_f16 v111, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908AD8: CC0E006F 0BFC0B76 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000908AE4: BF89FC17
	.long 0xd73d0071                                           // 000000908AE8: D73D0071
	v_cndmask_b32_e32 v1, v102, v113, vcc_lo                   // 000000908AEC: 0202E366
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000908AF0: BF870112
	v_dual_dot2acc_f32_f16 v79, v122, v20 :: v_dual_dot2acc_f32_f16 v96, v111, v33// 000000908AF4: CB18297A 4F60436F
	v_bfe_u32 v114, v113, 12, 16                               // 000000908AFC: D6100072 02411971
	v_bfe_u32 v119, v113, 8, 16                                // 000000908B04: D6100077 02411171
	s_waitcnt lgkmcnt(0)                                       // 000000908B0C: BF89FC07
	v_bfe_u32 v120, v116, 12, 16                               // 000000908B10: D6100078 02411974
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000908B18: BF870193
	.long 0xd72c0072                                           // 000000908B1C: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 000000908B20: 0202E4FF 83DCD12D
	.long 0xd72c0077                                           // 000000908B28: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000908B2C: 0202EEFF 83DCD12D
	v_bfe_u32 v121, v116, 8, 16                                // 000000908B34: D6100079 02411174
	v_bfe_u32 v123, v116, 4, 16                                // 000000908B3C: D610007B 02410974
	v_and_b32_e32 v116, 0xffff, v116                           // 000000908B44: 36E8E8FF 0000FFFF
	.long 0xd72c0078                                           // 000000908B4C: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000908B50: 0202F0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000908B58: BF870254
	.long 0xd72c0079                                           // 000000908B5C: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000908B60: 0202F2FF 83DCD12D
	v_sad_u8 v114, v114, 0, 0x6400                             // 000000908B68: D6220072 03FD0172 00006400
	v_dot2acc_f32_f16 v79, v111, v21                           // 000000908B74: 049E2B6F
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000908B78: D6220077 03FD0177 00006400
	.long 0xd72c0074                                           // 000000908B84: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 000000908B88: 0202E8FF 83DCD12D
	v_and_b32_e32 v114, 0xffff, v114                           // 000000908B90: 36E4E4FF 0000FFFF
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000908B98: D6220078 03FD0178 00006400
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000908BA4: D6220079 03FD0179 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000908BB0: BF870223
	v_lshl_or_b32 v114, v119, 16, v114                         // 000000908BB4: D6560072 05C92177
	.long 0xd72c0077                                           // 000000908BBC: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000908BC0: 0202F6FF 83DCD12D
	v_and_b32_e32 v120, 0xffff, v120                           // 000000908BC8: 36F0F0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000908BD0: BF870243
	v_pk_fma_f16 v114, v114, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908BD4: CC0E0072 0BFC0B72 0000C931
	v_and_b32_e32 v118, 0xffff, v113                           // 000000908BE0: 36ECE2FF 0000FFFF
	v_bfe_u32 v113, v113, 4, 16                                // 000000908BE8: D6100071 02410971
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000908BF0: D6220077 03FD0177 00006400
	v_dot2acc_f32_f16 v95, v114, v30                           // 000000908BFC: 04BE3D72
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000908C00: BF870214
	.long 0xd72c0076                                           // 000000908C04: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000908C08: 0202ECFF 83DCD12D
	.long 0xd72c0071                                           // 000000908C10: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 000000908C14: 0202E2FF 83DCD12D
	v_dual_dot2acc_f32_f16 v46, v111, v29 :: v_dual_dot2acc_f32_f16 v45, v114, v26// 000000908C1C: CB183B6F 2E2C3572
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000908C24: BF870223
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000908C28: D6220076 03FD0176 00006400
	v_dot2acc_f32_f16 v63, v111, v25                           // 000000908C34: 047E336F
	v_sad_u8 v113, v113, 0, 0x6400                             // 000000908C38: D6220071 03FD0171 00006400
	v_sad_u8 v111, v116, 0, 0x6400                             // 000000908C44: D622006F 03FD0174 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000908C50: BF870114
	v_lshlrev_b32_e32 v118, 16, v118                           // 000000908C54: 30ECEC90
	v_lshlrev_b32_e32 v111, 16, v111                           // 000000908C58: 30DEDE90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000908C5C: BF870092
	v_and_or_b32 v113, 0xffff, v113, v118                      // 000000908C60: D6570071 05DAE2FF 0000FFFF
	v_pk_fma_f16 v116, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908C6C: CC0E0074 0BFC0B71 0000C931
	v_mov_b32_e32 v113, v115                                   // 000000908C78: 7EE20373
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000908C7C: BF870224
	v_and_or_b32 v115, 0xffff, v119, v111                      // 000000908C80: D6570073 05BEEEFF 0000FFFF
	v_lshl_or_b32 v118, v121, 16, v120                         // 000000908C8C: D6560076 05E12179
	v_dual_dot2acc_f32_f16 v62, v114, v22 :: v_dual_dot2acc_f32_f16 v45, v116, v27// 000000908C94: CB182D72 3E2C3774
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000908C9C: BF870224
	.long 0xd73d006f                                           // 000000908CA0: D73D006F
	v_cndmask_b32_e32 v1, v102, v112, vcc_lo                   // 000000908CA4: 0202E166
	v_dot2acc_f32_f16 v95, v116, v31                           // 000000908CA8: 04BE3F74
	v_pk_fma_f16 v118, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908CAC: CC0E0076 0BFC0B76 0000C931
	v_pk_fma_f16 v119, v115, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908CB8: CC0E0077 0BFC0B73 0000C931
	v_bfe_u32 v115, v117, 12, 16                               // 000000908CC4: D6100073 02411975
	v_dot2acc_f32_f16 v62, v116, v23                           // 000000908CCC: 047C2F74
	v_bfe_u32 v112, v111, 12, 16                               // 000000908CD0: D6100070 0241196F
	v_dot2acc_f32_f16 v95, v118, v32                           // 000000908CD8: 04BE4176
	v_dot2acc_f32_f16 v78, v114, v18                           // 000000908CDC: 049C2572
	v_and_b32_e32 v114, 0xffff, v111                           // 000000908CE0: 36E4DEFF 0000FFFF
	v_bfe_u32 v113, v111, 8, 16                                // 000000908CE8: D6100071 0241116F
	.long 0xd72c0070                                           // 000000908CF0: D72C0070
	v_cndmask_b32_e32 v1, 0x83dcd12d, v112, vcc_lo             // 000000908CF4: 0202E0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000908CFC: BF870004
	v_dual_dot2acc_f32_f16 v95, v119, v33 :: v_dual_dot2acc_f32_f16 v78, v116, v19// 000000908D00: CB184377 5F4E2774
	v_bfe_u32 v111, v111, 4, 16                                // 000000908D08: D610006F 0241096F
	.long 0xd72c0072                                           // 000000908D10: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 000000908D14: 0202E4FF 83DCD12D
	.long 0xd72c0073                                           // 000000908D1C: D72C0073
	v_cndmask_b32_e32 v1, 0x83dcd12d, v115, vcc_lo             // 000000908D20: 0202E6FF 83DCD12D
	v_bfe_u32 v116, v117, 8, 16                                // 000000908D28: D6100074 02411175
	.long 0xd72c0071                                           // 000000908D30: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 000000908D34: 0202E2FF 83DCD12D
	v_sad_u8 v112, v112, 0, 0x6400                             // 000000908D3C: D6220070 03FD0170 00006400
	.long 0xd72c0079                                           // 000000908D48: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 000000908D4C: 0202DEFF 83DCD12D
	v_bfe_u32 v120, v117, 4, 16                                // 000000908D54: D6100078 02410975
	v_and_b32_e32 v117, 0xffff, v117                           // 000000908D5C: 36EAEAFF 0000FFFF
	v_sad_u8 v123, v114, 0, 0x6400                             // 000000908D64: D622007B 03FD0172 00006400
	v_and_b32_e32 v122, 0xffff, v112                           // 000000908D70: 36F4E0FF 0000FFFF
	ds_load_2addr_b32 v[111:112], v110 offset1:32              // 000000908D78: D8DC2000 6F00006E
	v_sad_u8 v124, v115, 0, 0x6400                             // 000000908D80: D622007C 03FD0173 00006400
	ds_load_2addr_b32 v[114:115], v109 offset1:32              // 000000908D8C: D8DC2000 7200006D
	.long 0xd72c0075                                           // 000000908D94: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000908D98: 0202EAFF 83DCD12D
	v_sad_u8 v113, v113, 0, 0x6400                             // 000000908DA0: D6220071 03FD0171 00006400
	.long 0xd72c0074                                           // 000000908DAC: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 000000908DB0: 0202E8FF 83DCD12D
	.long 0xd72c0078                                           // 000000908DB8: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000908DBC: 0202F0FF 83DCD12D
	v_dual_dot2acc_f32_f16 v78, v118, v20 :: v_dual_lshlrev_b32 v123, 16, v123// 000000908DC4: CB222976 4E7AF690
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000908DCC: D6220079 03FD0179 00006400
	v_lshl_or_b32 v113, v113, 16, v122                         // 000000908DD8: D6560071 05E92171
	v_sad_u8 v117, v117, 0, 0x6400                             // 000000908DE0: D6220075 03FD0175 00006400
	v_dot2acc_f32_f16 v62, v118, v24                           // 000000908DEC: 047C3176
	v_sad_u8 v116, v116, 0, 0x6400                             // 000000908DF0: D6220074 03FD0174 00006400
	v_dot2acc_f32_f16 v45, v118, v28                           // 000000908DFC: 045A3976
	v_and_or_b32 v118, 0xffff, v121, v123                      // 000000908E00: D6570076 05EEF2FF 0000FFFF
	v_pk_fma_f16 v121, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908E0C: CC0E0079 0BFC0B71 0000C931
	v_and_b32_e32 v124, 0xffff, v124                           // 000000908E18: 36F8F8FF 0000FFFF
	v_lshlrev_b32_e32 v117, 16, v117                           // 000000908E20: 30EAEA90
	v_dot2acc_f32_f16 v62, v119, v25                           // 000000908E24: 047C3377
	s_waitcnt lgkmcnt(1)                                       // 000000908E28: BF89FC17
	v_mov_b32_e32 v113, v111                                   // 000000908E2C: 7EE2036F
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000908E30: D6220078 03FD0178 00006400
	v_dot2acc_f32_f16 v61, v121, v22                           // 000000908E3C: 047A2D79
	v_lshl_or_b32 v116, v116, 16, v124                         // 000000908E40: D6560074 05F12174
	v_pk_fma_f16 v118, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908E48: CC0E0076 0BFC0B76 0000C931
	s_waitcnt lgkmcnt(0)                                       // 000000908E54: BF89FC07
	.long 0xd73d0071                                           // 000000908E58: D73D0071
	v_cndmask_b32_e32 v1, v102, v113, vcc_lo                   // 000000908E5C: 0202E366
	v_and_or_b32 v111, 0xffff, v120, v117                      // 000000908E60: D657006F 05D6F0FF 0000FFFF
	v_dot2acc_f32_f16 v77, v121, v18                           // 000000908E6C: 049A2579
	v_pk_fma_f16 v122, v116, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908E70: CC0E007A 0BFC0B74 0000C931
	ds_load_2addr_b32 v[116:117], v106 offset1:32              // 000000908E7C: D8DC2000 7400006A
	v_dot2acc_f32_f16 v94, v121, v30                           // 000000908E84: 04BC3D79
	v_pk_fma_f16 v114, v111, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908E88: CC0E0072 0BFC0B6F 0000C931
	v_bfe_u32 v111, v113, 12, 16                               // 000000908E94: D610006F 02411971
	v_dual_dot2acc_f32_f16 v78, v119, v21 :: v_dual_dot2acc_f32_f16 v77, v118, v19// 000000908E9C: CB182B77 4E4C2776
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000908EA4: BF870194
	v_dual_dot2acc_f32_f16 v94, v118, v31 :: v_dual_dot2acc_f32_f16 v45, v119, v29// 000000908EA8: CB183F76 5E2C3B77
	.long 0xd72c006f                                           // 000000908EB0: D72C006F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 000000908EB4: 0202DEFF 83DCD12D
	v_bfe_u32 v119, v113, 8, 16                                // 000000908EBC: D6100077 02411171
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000908EC4: BF8701A4
	v_dual_dot2acc_f32_f16 v77, v122, v20 :: v_dual_dot2acc_f32_f16 v44, v121, v26// 000000908EC8: CB18297A 4D2C3579
	v_dual_dot2acc_f32_f16 v61, v118, v23 :: v_dual_and_b32 v120, 0xffff, v113// 000000908ED0: CB242F76 3D78E2FF 0000FFFF
	.long 0xd72c0077                                           // 000000908EDC: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000908EE0: 0202EEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000908EE8: BF870003
	v_dot2acc_f32_f16 v77, v114, v21                           // 000000908EEC: 049A2B72
	v_sad_u8 v111, v111, 0, 0x6400                             // 000000908EF0: D622006F 03FD016F 00006400
	v_dot2acc_f32_f16 v94, v122, v32                           // 000000908EFC: 04BC417A
	v_bfe_u32 v113, v113, 4, 16                                // 000000908F00: D6100071 02410971
	.long 0xd72c0078                                           // 000000908F08: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000908F0C: 0202F0FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000908F14: BF89FC07
	v_bfe_u32 v121, v116, 12, 16                               // 000000908F18: D6100079 02411974
	v_and_b32_e32 v111, 0xffff, v111                           // 000000908F20: 36DEDEFF 0000FFFF
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000908F28: D6220077 03FD0177 00006400
	v_and_b32_e32 v124, 0xffff, v116                           // 000000908F34: 36F8E8FF 0000FFFF
	v_bfe_u32 v123, v116, 8, 16                                // 000000908F3C: D610007B 02411174
	.long 0xd72c0079                                           // 000000908F44: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000908F48: 0202F2FF 83DCD12D
	.long 0xd72c0071                                           // 000000908F50: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 000000908F54: 0202E2FF 83DCD12D
	v_lshl_or_b32 v111, v119, 16, v111                         // 000000908F5C: D656006F 05BD2177
	.long 0xd72c0077                                           // 000000908F64: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 000000908F68: 0202F8FF 83DCD12D
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000908F70: D6220078 03FD0178 00006400
	v_bfe_u32 v116, v116, 4, 16                                // 000000908F7C: D6100074 02410974
	.long 0xd72c007b                                           // 000000908F84: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000908F88: 0202F6FF 83DCD12D
	v_pk_fma_f16 v111, v111, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000908F90: CC0E006F 0BFC0B6F 0000C931
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000908F9C: D6220079 03FD0179 00006400
	v_dot2acc_f32_f16 v44, v118, v27                           // 000000908FA8: 04583776
	v_sad_u8 v113, v113, 0, 0x6400                             // 000000908FAC: D6220071 03FD0171 00006400
	v_sad_u8 v118, v119, 0, 0x6400                             // 000000908FB8: D6220076 03FD0177 00006400
	v_dot2acc_f32_f16 v61, v122, v24                           // 000000908FC4: 047A317A
	v_lshlrev_b32_e32 v120, 16, v120                           // 000000908FC8: 30F0F090
	.long 0xd72c0074                                           // 000000908FCC: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 000000908FD0: 0202E8FF 83DCD12D
	v_and_b32_e32 v119, 0xffff, v121                           // 000000908FD8: 36EEF2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000908FE0: BF870214
	v_dual_dot2acc_f32_f16 v61, v114, v25 :: v_dual_lshlrev_b32 v118, 16, v118// 000000908FE4: CB223372 3D76EC90
	v_and_or_b32 v113, 0xffff, v113, v120                      // 000000908FEC: D6570071 05E2E2FF 0000FFFF
	v_sad_u8 v120, v123, 0, 0x6400                             // 000000908FF8: D6220078 03FD017B 00006400
	v_dual_dot2acc_f32_f16 v94, v114, v33 :: v_dual_dot2acc_f32_f16 v93, v111, v30// 000000909004: CB184372 5E5C3D6F
	v_sad_u8 v116, v116, 0, 0x6400                             // 00000090900C: D6220074 03FD0174 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000909018: BF870214
	v_pk_fma_f16 v121, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000090901C: CC0E0079 0BFC0B71 0000C931
	v_lshl_or_b32 v113, v120, 16, v119                         // 000000909028: D6560071 05DD2178
	v_dot2acc_f32_f16 v44, v122, v28                           // 000000909030: 0458397A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000909034: BF870214
	v_and_or_b32 v116, 0xffff, v116, v118                      // 000000909038: D6570074 05DAE8FF 0000FFFF
	v_dot2acc_f32_f16 v93, v121, v31                           // 000000909044: 04BA3F79
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000909048: BF870254
	v_pk_fma_f16 v118, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000090904C: CC0E0076 0BFC0B71 0000C931
	v_dot2acc_f32_f16 v76, v111, v18                           // 000000909058: 0498256F
	v_mov_b32_e32 v113, v115                                   // 00000090905C: 7EE20373
	v_bfe_u32 v115, v117, 12, 16                               // 000000909060: D6100073 02411975
	v_pk_fma_f16 v119, v116, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909068: CC0E0077 0BFC0B74 0000C931
	v_dual_dot2acc_f32_f16 v93, v118, v32 :: v_dual_dot2acc_f32_f16 v76, v121, v19// 000000909074: CB184176 5D4C2779
	v_dot2acc_f32_f16 v43, v111, v26                           // 00000090907C: 0456356F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000909080: BF870224
	.long 0xd72c0073                                           // 000000909084: D72C0073
	v_cndmask_b32_e32 v1, 0x83dcd12d, v115, vcc_lo             // 000000909088: 0202E6FF 83DCD12D
	v_bfe_u32 v116, v117, 8, 16                                // 000000909090: D6100074 02411175
	v_dual_dot2acc_f32_f16 v93, v119, v33 :: v_dual_dot2acc_f32_f16 v76, v118, v20// 000000909098: CB184377 5D4C2976
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009090A0: BF870224
	v_dual_dot2acc_f32_f16 v60, v111, v22 :: v_dual_dot2acc_f32_f16 v43, v121, v27// 0000009090A4: CB182D6F 3C2A3779
	.long 0xd73d006f                                           // 0000009090AC: D73D006F
	v_cndmask_b32_e32 v1, v102, v112, vcc_lo                   // 0000009090B0: 0202E166
	.long 0xd72c0074                                           // 0000009090B4: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 0000009090B8: 0202E8FF 83DCD12D
	v_sad_u8 v115, v115, 0, 0x6400                             // 0000009090C0: D6220073 03FD0173 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009090CC: BF8701B4
	v_dot2acc_f32_f16 v60, v121, v23                           // 0000009090D0: 04782F79
	v_dot2acc_f32_f16 v44, v114, v29                           // 0000009090D4: 04583B72
	v_dual_dot2acc_f32_f16 v76, v119, v21 :: v_dual_dot2acc_f32_f16 v43, v118, v28// 0000009090D8: CB182B77 4C2A3976
	v_dual_dot2acc_f32_f16 v60, v118, v24 :: v_dual_and_b32 v113, 0xffff, v111// 0000009090E0: CB243176 3C70DEFF 0000FFFF
	v_bfe_u32 v112, v111, 12, 16                               // 0000009090EC: D6100070 0241196F
	v_bfe_u32 v114, v111, 8, 16                                // 0000009090F4: D6100072 0241116F
	v_bfe_u32 v111, v111, 4, 16                                // 0000009090FC: D610006F 0241096F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000909104: BF870004
	.long 0xd72c0071                                           // 000000909108: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 00000090910C: 0202E2FF 83DCD12D
	v_bfe_u32 v118, v117, 4, 16                                // 000000909114: D6100076 02410975
	.long 0xd72c0070                                           // 00000090911C: D72C0070
	v_cndmask_b32_e32 v1, 0x83dcd12d, v112, vcc_lo             // 000000909120: 0202E0FF 83DCD12D
	.long 0xd72c0072                                           // 000000909128: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 00000090912C: 0202E4FF 83DCD12D
	.long 0xd72c006f                                           // 000000909134: D72C006F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 000000909138: 0202DEFF 83DCD12D
	v_and_b32_e32 v115, 0xffff, v115                           // 000000909140: 36E6E6FF 0000FFFF
	v_sad_u8 v116, v116, 0, 0x6400                             // 000000909148: D6220074 03FD0174 00006400
	.long 0xd72c0076                                           // 000000909154: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000909158: 0202ECFF 83DCD12D
	v_sad_u8 v113, v113, 0, 0x6400                             // 000000909160: D6220071 03FD0171 00006400
	v_sad_u8 v112, v112, 0, 0x6400                             // 00000090916C: D6220070 03FD0170 00006400
	v_sad_u8 v114, v114, 0, 0x6400                             // 000000909178: D6220072 03FD0172 00006400
	v_sad_u8 v121, v111, 0, 0x6400                             // 000000909184: D6220079 03FD016F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000909190: BF870124
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000909194: 30E2E290
	v_lshl_or_b32 v116, v116, 16, v115                         // 000000909198: D6560074 05CD2174
	v_and_or_b32 v113, 0xffff, v121, v113                      // 0000009091A0: D6570071 05C6F2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009091AC: BF870112
	v_pk_fma_f16 v122, v116, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009091B0: CC0E007A 0BFC0B74 0000C931
	v_pk_fma_f16 v121, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009091BC: CC0E0079 0BFC0B71 0000C931
	v_and_b32_e32 v120, 0xffff, v112                           // 0000009091C8: 36F0E0FF 0000FFFF
	ds_load_2addr_b32 v[111:112], v110 offset0:64 offset1:96   // 0000009091D0: D8DC6040 6F00006E
	v_sad_u8 v113, v118, 0, 0x6400                             // 0000009091D8: D6220071 03FD0176 00006400
	v_lshl_or_b32 v120, v114, 16, v120                         // 0000009091E4: D6560078 05E12172
	ds_load_2addr_b32 v[114:115], v109 offset0:64 offset1:96   // 0000009091EC: D8DC6040 7200006D
	v_pk_fma_f16 v120, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009091F4: CC0E0078 0BFC0B78 0000C931
	v_and_b32_e32 v117, 0xffff, v117                           // 000000909200: 36EAEAFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000909208: BF8701A2
	v_dual_dot2acc_f32_f16 v60, v119, v25 :: v_dual_dot2acc_f32_f16 v75, v120, v18// 00000090920C: CB183377 3C4A2578
	v_dot2acc_f32_f16 v92, v120, v30                           // 000000909214: 04B83D78
	.long 0xd72c0075                                           // 000000909218: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 00000090921C: 0202EAFF 83DCD12D
	v_dot2acc_f32_f16 v59, v120, v22                           // 000000909224: 04762D78
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000909228: BF870214
	v_dual_dot2acc_f32_f16 v42, v120, v26 :: v_dual_dot2acc_f32_f16 v75, v121, v19// 00000090922C: CB183578 2A4A2779
	v_dot2acc_f32_f16 v92, v121, v31                           // 000000909234: 04B83F79
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000909238: BF870193
	v_dot2acc_f32_f16 v59, v121, v23                           // 00000090923C: 04762F79
	v_dot2acc_f32_f16 v42, v121, v27                           // 000000909240: 04543779
	v_sad_u8 v117, v117, 0, 0x6400                             // 000000909244: D6220075 03FD0175 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000909250: BF870214
	v_dot2acc_f32_f16 v92, v122, v32                           // 000000909254: 04B8417A
	v_dot2acc_f32_f16 v59, v122, v24                           // 000000909258: 0476317A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000090925C: BF870214
	v_dot2acc_f32_f16 v42, v122, v28                           // 000000909260: 0454397A
	v_lshlrev_b32_e32 v118, 16, v117                           // 000000909264: 30ECEA90
	ds_load_2addr_b32 v[116:117], v106 offset0:64 offset1:96   // 000000909268: D8DC6040 7400006A
	v_dot2acc_f32_f16 v43, v119, v29                           // 000000909270: 04563B77
	v_and_or_b32 v118, 0xffff, v113, v118                      // 000000909274: D6570076 05DAE2FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 000000909280: BF89FC27
	v_mov_b32_e32 v113, v111                                   // 000000909284: 7EE2036F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000909288: BF870122
	v_pk_fma_f16 v111, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000090928C: CC0E006F 0BFC0B76 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000909298: BF89FC17
	.long 0xd73d0071                                           // 00000090929C: D73D0071
	v_cndmask_b32_e32 v1, v102, v113, vcc_lo                   // 0000009092A0: 0202E366
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009092A4: BF870112
	v_dual_dot2acc_f32_f16 v75, v122, v20 :: v_dual_dot2acc_f32_f16 v92, v111, v33// 0000009092A8: CB18297A 4B5C436F
	v_bfe_u32 v114, v113, 12, 16                               // 0000009092B0: D6100072 02411971
	v_bfe_u32 v119, v113, 8, 16                                // 0000009092B8: D6100077 02411171
	s_waitcnt lgkmcnt(0)                                       // 0000009092C0: BF89FC07
	v_bfe_u32 v120, v116, 12, 16                               // 0000009092C4: D6100078 02411974
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009092CC: BF870193
	.long 0xd72c0072                                           // 0000009092D0: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 0000009092D4: 0202E4FF 83DCD12D
	.long 0xd72c0077                                           // 0000009092DC: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 0000009092E0: 0202EEFF 83DCD12D
	v_bfe_u32 v121, v116, 8, 16                                // 0000009092E8: D6100079 02411174
	v_bfe_u32 v123, v116, 4, 16                                // 0000009092F0: D610007B 02410974
	v_and_b32_e32 v116, 0xffff, v116                           // 0000009092F8: 36E8E8FF 0000FFFF
	.long 0xd72c0078                                           // 000000909300: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000909304: 0202F0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000090930C: BF870254
	.long 0xd72c0079                                           // 000000909310: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000909314: 0202F2FF 83DCD12D
	v_sad_u8 v114, v114, 0, 0x6400                             // 00000090931C: D6220072 03FD0172 00006400
	v_dot2acc_f32_f16 v75, v111, v21                           // 000000909328: 04962B6F
	v_sad_u8 v119, v119, 0, 0x6400                             // 00000090932C: D6220077 03FD0177 00006400
	.long 0xd72c0074                                           // 000000909338: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 00000090933C: 0202E8FF 83DCD12D
	v_and_b32_e32 v114, 0xffff, v114                           // 000000909344: 36E4E4FF 0000FFFF
	v_sad_u8 v120, v120, 0, 0x6400                             // 00000090934C: D6220078 03FD0178 00006400
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000909358: D6220079 03FD0179 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000909364: BF870223
	v_lshl_or_b32 v114, v119, 16, v114                         // 000000909368: D6560072 05C92177
	.long 0xd72c0077                                           // 000000909370: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000909374: 0202F6FF 83DCD12D
	v_and_b32_e32 v120, 0xffff, v120                           // 00000090937C: 36F0F0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000909384: BF870243
	v_pk_fma_f16 v114, v114, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909388: CC0E0072 0BFC0B72 0000C931
	v_and_b32_e32 v118, 0xffff, v113                           // 000000909394: 36ECE2FF 0000FFFF
	v_bfe_u32 v113, v113, 4, 16                                // 00000090939C: D6100071 02410971
	v_sad_u8 v119, v119, 0, 0x6400                             // 0000009093A4: D6220077 03FD0177 00006400
	v_dot2acc_f32_f16 v91, v114, v30                           // 0000009093B0: 04B63D72
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009093B4: BF870214
	.long 0xd72c0076                                           // 0000009093B8: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 0000009093BC: 0202ECFF 83DCD12D
	.long 0xd72c0071                                           // 0000009093C4: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 0000009093C8: 0202E2FF 83DCD12D
	v_dual_dot2acc_f32_f16 v42, v111, v29 :: v_dual_dot2acc_f32_f16 v41, v114, v26// 0000009093D0: CB183B6F 2A283572
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009093D8: BF870223
	v_sad_u8 v118, v118, 0, 0x6400                             // 0000009093DC: D6220076 03FD0176 00006400
	v_dot2acc_f32_f16 v59, v111, v25                           // 0000009093E8: 0476336F
	v_sad_u8 v113, v113, 0, 0x6400                             // 0000009093EC: D6220071 03FD0171 00006400
	v_sad_u8 v111, v116, 0, 0x6400                             // 0000009093F8: D622006F 03FD0174 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000909404: BF870114
	v_lshlrev_b32_e32 v118, 16, v118                           // 000000909408: 30ECEC90
	v_lshlrev_b32_e32 v111, 16, v111                           // 00000090940C: 30DEDE90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000909410: BF870092
	v_and_or_b32 v113, 0xffff, v113, v118                      // 000000909414: D6570071 05DAE2FF 0000FFFF
	v_pk_fma_f16 v116, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909420: CC0E0074 0BFC0B71 0000C931
	v_mov_b32_e32 v113, v115                                   // 00000090942C: 7EE20373
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000909430: BF870224
	v_and_or_b32 v115, 0xffff, v119, v111                      // 000000909434: D6570073 05BEEEFF 0000FFFF
	v_lshl_or_b32 v118, v121, 16, v120                         // 000000909440: D6560076 05E12179
	v_dual_dot2acc_f32_f16 v58, v114, v22 :: v_dual_dot2acc_f32_f16 v41, v116, v27// 000000909448: CB182D72 3A283774
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000909450: BF870224
	.long 0xd73d006f                                           // 000000909454: D73D006F
	v_cndmask_b32_e32 v1, v102, v112, vcc_lo                   // 000000909458: 0202E166
	v_dot2acc_f32_f16 v91, v116, v31                           // 00000090945C: 04B63F74
	v_pk_fma_f16 v118, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909460: CC0E0076 0BFC0B76 0000C931
	v_pk_fma_f16 v119, v115, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000090946C: CC0E0077 0BFC0B73 0000C931
	v_bfe_u32 v115, v117, 12, 16                               // 000000909478: D6100073 02411975
	v_dot2acc_f32_f16 v58, v116, v23                           // 000000909480: 04742F74
	v_bfe_u32 v112, v111, 12, 16                               // 000000909484: D6100070 0241196F
	v_dot2acc_f32_f16 v91, v118, v32                           // 00000090948C: 04B64176
	v_dot2acc_f32_f16 v74, v114, v18                           // 000000909490: 04942572
	v_and_b32_e32 v114, 0xffff, v111                           // 000000909494: 36E4DEFF 0000FFFF
	v_bfe_u32 v113, v111, 8, 16                                // 00000090949C: D6100071 0241116F
	.long 0xd72c0070                                           // 0000009094A4: D72C0070
	v_cndmask_b32_e32 v1, 0x83dcd12d, v112, vcc_lo             // 0000009094A8: 0202E0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009094B0: BF870004
	v_dual_dot2acc_f32_f16 v91, v119, v33 :: v_dual_dot2acc_f32_f16 v74, v116, v19// 0000009094B4: CB184377 5B4A2774
	v_bfe_u32 v111, v111, 4, 16                                // 0000009094BC: D610006F 0241096F
	.long 0xd72c0072                                           // 0000009094C4: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 0000009094C8: 0202E4FF 83DCD12D
	.long 0xd72c0073                                           // 0000009094D0: D72C0073
	v_cndmask_b32_e32 v1, 0x83dcd12d, v115, vcc_lo             // 0000009094D4: 0202E6FF 83DCD12D
	v_bfe_u32 v116, v117, 8, 16                                // 0000009094DC: D6100074 02411175
	.long 0xd72c0071                                           // 0000009094E4: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 0000009094E8: 0202E2FF 83DCD12D
	v_sad_u8 v112, v112, 0, 0x6400                             // 0000009094F0: D6220070 03FD0170 00006400
	.long 0xd72c0079                                           // 0000009094FC: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 000000909500: 0202DEFF 83DCD12D
	v_bfe_u32 v120, v117, 4, 16                                // 000000909508: D6100078 02410975
	v_and_b32_e32 v117, 0xffff, v117                           // 000000909510: 36EAEAFF 0000FFFF
	v_sad_u8 v123, v114, 0, 0x6400                             // 000000909518: D622007B 03FD0172 00006400
	v_and_b32_e32 v122, 0xffff, v112                           // 000000909524: 36F4E0FF 0000FFFF
	ds_load_2addr_b32 v[111:112], v110 offset0:128 offset1:160 // 00000090952C: D8DCA080 6F00006E
	v_sad_u8 v124, v115, 0, 0x6400                             // 000000909534: D622007C 03FD0173 00006400
	ds_load_2addr_b32 v[114:115], v109 offset0:128 offset1:160 // 000000909540: D8DCA080 7200006D
	.long 0xd72c0075                                           // 000000909548: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 00000090954C: 0202EAFF 83DCD12D
	v_sad_u8 v113, v113, 0, 0x6400                             // 000000909554: D6220071 03FD0171 00006400
	.long 0xd72c0074                                           // 000000909560: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 000000909564: 0202E8FF 83DCD12D
	.long 0xd72c0078                                           // 00000090956C: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000909570: 0202F0FF 83DCD12D
	v_dual_dot2acc_f32_f16 v74, v118, v20 :: v_dual_lshlrev_b32 v123, 16, v123// 000000909578: CB222976 4A7AF690
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000909580: D6220079 03FD0179 00006400
	v_lshl_or_b32 v113, v113, 16, v122                         // 00000090958C: D6560071 05E92171
	v_sad_u8 v117, v117, 0, 0x6400                             // 000000909594: D6220075 03FD0175 00006400
	v_dot2acc_f32_f16 v58, v118, v24                           // 0000009095A0: 04743176
	v_sad_u8 v116, v116, 0, 0x6400                             // 0000009095A4: D6220074 03FD0174 00006400
	v_dot2acc_f32_f16 v41, v118, v28                           // 0000009095B0: 04523976
	v_and_or_b32 v118, 0xffff, v121, v123                      // 0000009095B4: D6570076 05EEF2FF 0000FFFF
	v_pk_fma_f16 v121, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009095C0: CC0E0079 0BFC0B71 0000C931
	v_and_b32_e32 v124, 0xffff, v124                           // 0000009095CC: 36F8F8FF 0000FFFF
	v_lshlrev_b32_e32 v117, 16, v117                           // 0000009095D4: 30EAEA90
	v_dot2acc_f32_f16 v58, v119, v25                           // 0000009095D8: 04743377
	s_waitcnt lgkmcnt(1)                                       // 0000009095DC: BF89FC17
	v_mov_b32_e32 v113, v111                                   // 0000009095E0: 7EE2036F
	v_sad_u8 v120, v120, 0, 0x6400                             // 0000009095E4: D6220078 03FD0178 00006400
	v_dot2acc_f32_f16 v57, v121, v22                           // 0000009095F0: 04722D79
	v_lshl_or_b32 v116, v116, 16, v124                         // 0000009095F4: D6560074 05F12174
	v_pk_fma_f16 v118, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009095FC: CC0E0076 0BFC0B76 0000C931
	s_waitcnt lgkmcnt(0)                                       // 000000909608: BF89FC07
	.long 0xd73d0071                                           // 00000090960C: D73D0071
	v_cndmask_b32_e32 v1, v102, v113, vcc_lo                   // 000000909610: 0202E366
	v_and_or_b32 v111, 0xffff, v120, v117                      // 000000909614: D657006F 05D6F0FF 0000FFFF
	v_dot2acc_f32_f16 v73, v121, v18                           // 000000909620: 04922579
	v_pk_fma_f16 v122, v116, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909624: CC0E007A 0BFC0B74 0000C931
	ds_load_2addr_b32 v[116:117], v106 offset0:128 offset1:160 // 000000909630: D8DCA080 7400006A
	v_dot2acc_f32_f16 v90, v121, v30                           // 000000909638: 04B43D79
	v_pk_fma_f16 v114, v111, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000090963C: CC0E0072 0BFC0B6F 0000C931
	v_bfe_u32 v111, v113, 12, 16                               // 000000909648: D610006F 02411971
	v_dual_dot2acc_f32_f16 v74, v119, v21 :: v_dual_dot2acc_f32_f16 v73, v118, v19// 000000909650: CB182B77 4A482776
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000909658: BF870194
	v_dual_dot2acc_f32_f16 v90, v118, v31 :: v_dual_dot2acc_f32_f16 v41, v119, v29// 00000090965C: CB183F76 5A283B77
	.long 0xd72c006f                                           // 000000909664: D72C006F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 000000909668: 0202DEFF 83DCD12D
	v_bfe_u32 v119, v113, 8, 16                                // 000000909670: D6100077 02411171
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000909678: BF8701A4
	v_dual_dot2acc_f32_f16 v73, v122, v20 :: v_dual_dot2acc_f32_f16 v40, v121, v26// 00000090967C: CB18297A 49283579
	v_dual_dot2acc_f32_f16 v57, v118, v23 :: v_dual_and_b32 v120, 0xffff, v113// 000000909684: CB242F76 3978E2FF 0000FFFF
	.long 0xd72c0077                                           // 000000909690: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000909694: 0202EEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 00000090969C: BF870003
	v_dot2acc_f32_f16 v73, v114, v21                           // 0000009096A0: 04922B72
	v_sad_u8 v111, v111, 0, 0x6400                             // 0000009096A4: D622006F 03FD016F 00006400
	v_dot2acc_f32_f16 v90, v122, v32                           // 0000009096B0: 04B4417A
	v_bfe_u32 v113, v113, 4, 16                                // 0000009096B4: D6100071 02410971
	.long 0xd72c0078                                           // 0000009096BC: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 0000009096C0: 0202F0FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 0000009096C8: BF89FC07
	v_bfe_u32 v121, v116, 12, 16                               // 0000009096CC: D6100079 02411974
	v_and_b32_e32 v111, 0xffff, v111                           // 0000009096D4: 36DEDEFF 0000FFFF
	v_sad_u8 v119, v119, 0, 0x6400                             // 0000009096DC: D6220077 03FD0177 00006400
	v_and_b32_e32 v124, 0xffff, v116                           // 0000009096E8: 36F8E8FF 0000FFFF
	v_bfe_u32 v123, v116, 8, 16                                // 0000009096F0: D610007B 02411174
	.long 0xd72c0079                                           // 0000009096F8: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 0000009096FC: 0202F2FF 83DCD12D
	.long 0xd72c0071                                           // 000000909704: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 000000909708: 0202E2FF 83DCD12D
	v_lshl_or_b32 v111, v119, 16, v111                         // 000000909710: D656006F 05BD2177
	.long 0xd72c0077                                           // 000000909718: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 00000090971C: 0202F8FF 83DCD12D
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000909724: D6220078 03FD0178 00006400
	v_bfe_u32 v116, v116, 4, 16                                // 000000909730: D6100074 02410974
	.long 0xd72c007b                                           // 000000909738: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 00000090973C: 0202F6FF 83DCD12D
	v_pk_fma_f16 v111, v111, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909744: CC0E006F 0BFC0B6F 0000C931
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000909750: D6220079 03FD0179 00006400
	v_dot2acc_f32_f16 v40, v118, v27                           // 00000090975C: 04503776
	v_sad_u8 v113, v113, 0, 0x6400                             // 000000909760: D6220071 03FD0171 00006400
	v_sad_u8 v118, v119, 0, 0x6400                             // 00000090976C: D6220076 03FD0177 00006400
	v_dot2acc_f32_f16 v57, v122, v24                           // 000000909778: 0472317A
	v_lshlrev_b32_e32 v120, 16, v120                           // 00000090977C: 30F0F090
	.long 0xd72c0074                                           // 000000909780: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 000000909784: 0202E8FF 83DCD12D
	v_and_b32_e32 v119, 0xffff, v121                           // 00000090978C: 36EEF2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000909794: BF870214
	v_dual_dot2acc_f32_f16 v57, v114, v25 :: v_dual_lshlrev_b32 v118, 16, v118// 000000909798: CB223372 3976EC90
	v_and_or_b32 v113, 0xffff, v113, v120                      // 0000009097A0: D6570071 05E2E2FF 0000FFFF
	v_sad_u8 v120, v123, 0, 0x6400                             // 0000009097AC: D6220078 03FD017B 00006400
	v_dual_dot2acc_f32_f16 v90, v114, v33 :: v_dual_dot2acc_f32_f16 v89, v111, v30// 0000009097B8: CB184372 5A583D6F
	v_sad_u8 v116, v116, 0, 0x6400                             // 0000009097C0: D6220074 03FD0174 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009097CC: BF870214
	v_pk_fma_f16 v121, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009097D0: CC0E0079 0BFC0B71 0000C931
	v_lshl_or_b32 v113, v120, 16, v119                         // 0000009097DC: D6560071 05DD2178
	v_dot2acc_f32_f16 v40, v122, v28                           // 0000009097E4: 0450397A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009097E8: BF870214
	v_and_or_b32 v116, 0xffff, v116, v118                      // 0000009097EC: D6570074 05DAE8FF 0000FFFF
	v_dot2acc_f32_f16 v89, v121, v31                           // 0000009097F8: 04B23F79
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000009097FC: BF870254
	v_pk_fma_f16 v118, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909800: CC0E0076 0BFC0B71 0000C931
	v_dot2acc_f32_f16 v72, v111, v18                           // 00000090980C: 0490256F
	v_mov_b32_e32 v113, v115                                   // 000000909810: 7EE20373
	v_bfe_u32 v115, v117, 12, 16                               // 000000909814: D6100073 02411975
	v_pk_fma_f16 v119, v116, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000090981C: CC0E0077 0BFC0B74 0000C931
	v_dual_dot2acc_f32_f16 v89, v118, v32 :: v_dual_dot2acc_f32_f16 v72, v121, v19// 000000909828: CB184176 59482779
	v_dot2acc_f32_f16 v39, v111, v26                           // 000000909830: 044E356F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000909834: BF870224
	.long 0xd72c0073                                           // 000000909838: D72C0073
	v_cndmask_b32_e32 v1, 0x83dcd12d, v115, vcc_lo             // 00000090983C: 0202E6FF 83DCD12D
	v_bfe_u32 v116, v117, 8, 16                                // 000000909844: D6100074 02411175
	v_dual_dot2acc_f32_f16 v89, v119, v33 :: v_dual_dot2acc_f32_f16 v72, v118, v20// 00000090984C: CB184377 59482976
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000909854: BF870224
	v_dual_dot2acc_f32_f16 v56, v111, v22 :: v_dual_dot2acc_f32_f16 v39, v121, v27// 000000909858: CB182D6F 38263779
	.long 0xd73d006f                                           // 000000909860: D73D006F
	v_cndmask_b32_e32 v1, v102, v112, vcc_lo                   // 000000909864: 0202E166
	.long 0xd72c0074                                           // 000000909868: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 00000090986C: 0202E8FF 83DCD12D
	v_sad_u8 v115, v115, 0, 0x6400                             // 000000909874: D6220073 03FD0173 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000909880: BF8701B4
	v_dot2acc_f32_f16 v56, v121, v23                           // 000000909884: 04702F79
	v_dot2acc_f32_f16 v40, v114, v29                           // 000000909888: 04503B72
	v_dual_dot2acc_f32_f16 v72, v119, v21 :: v_dual_dot2acc_f32_f16 v39, v118, v28// 00000090988C: CB182B77 48263976
	v_dual_dot2acc_f32_f16 v56, v118, v24 :: v_dual_and_b32 v113, 0xffff, v111// 000000909894: CB243176 3870DEFF 0000FFFF
	v_bfe_u32 v112, v111, 12, 16                               // 0000009098A0: D6100070 0241196F
	v_bfe_u32 v114, v111, 8, 16                                // 0000009098A8: D6100072 0241116F
	v_bfe_u32 v111, v111, 4, 16                                // 0000009098B0: D610006F 0241096F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009098B8: BF870004
	.long 0xd72c0071                                           // 0000009098BC: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 0000009098C0: 0202E2FF 83DCD12D
	v_bfe_u32 v118, v117, 4, 16                                // 0000009098C8: D6100076 02410975
	.long 0xd72c0070                                           // 0000009098D0: D72C0070
	v_cndmask_b32_e32 v1, 0x83dcd12d, v112, vcc_lo             // 0000009098D4: 0202E0FF 83DCD12D
	.long 0xd72c0072                                           // 0000009098DC: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 0000009098E0: 0202E4FF 83DCD12D
	.long 0xd72c006f                                           // 0000009098E8: D72C006F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 0000009098EC: 0202DEFF 83DCD12D
	v_and_b32_e32 v115, 0xffff, v115                           // 0000009098F4: 36E6E6FF 0000FFFF
	v_sad_u8 v116, v116, 0, 0x6400                             // 0000009098FC: D6220074 03FD0174 00006400
	.long 0xd72c0076                                           // 000000909908: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 00000090990C: 0202ECFF 83DCD12D
	v_sad_u8 v113, v113, 0, 0x6400                             // 000000909914: D6220071 03FD0171 00006400
	v_sad_u8 v112, v112, 0, 0x6400                             // 000000909920: D6220070 03FD0170 00006400
	v_sad_u8 v114, v114, 0, 0x6400                             // 00000090992C: D6220072 03FD0172 00006400
	v_sad_u8 v121, v111, 0, 0x6400                             // 000000909938: D6220079 03FD016F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000909944: BF870124
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000909948: 30E2E290
	v_lshl_or_b32 v116, v116, 16, v115                         // 00000090994C: D6560074 05CD2174
	v_and_or_b32 v113, 0xffff, v121, v113                      // 000000909954: D6570071 05C6F2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000909960: BF870112
	v_pk_fma_f16 v122, v116, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909964: CC0E007A 0BFC0B74 0000C931
	v_pk_fma_f16 v121, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909970: CC0E0079 0BFC0B71 0000C931
	v_and_b32_e32 v120, 0xffff, v112                           // 00000090997C: 36F0E0FF 0000FFFF
	ds_load_2addr_b32 v[111:112], v110 offset0:192 offset1:224 // 000000909984: D8DCE0C0 6F00006E
	v_sad_u8 v113, v118, 0, 0x6400                             // 00000090998C: D6220071 03FD0176 00006400
	v_lshl_or_b32 v120, v114, 16, v120                         // 000000909998: D6560078 05E12172
	ds_load_2addr_b32 v[114:115], v109 offset0:192 offset1:224 // 0000009099A0: D8DCE0C0 7200006D
	v_pk_fma_f16 v120, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000009099A8: CC0E0078 0BFC0B78 0000C931
	v_and_b32_e32 v117, 0xffff, v117                           // 0000009099B4: 36EAEAFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009099BC: BF8701A2
	v_dual_dot2acc_f32_f16 v56, v119, v25 :: v_dual_dot2acc_f32_f16 v71, v120, v18// 0000009099C0: CB183377 38462578
	v_dot2acc_f32_f16 v88, v120, v30                           // 0000009099C8: 04B03D78
	.long 0xd72c0075                                           // 0000009099CC: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 0000009099D0: 0202EAFF 83DCD12D
	v_dot2acc_f32_f16 v55, v120, v22                           // 0000009099D8: 046E2D78
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009099DC: BF870214
	v_dual_dot2acc_f32_f16 v38, v120, v26 :: v_dual_dot2acc_f32_f16 v71, v121, v19// 0000009099E0: CB183578 26462779
	v_dot2acc_f32_f16 v88, v121, v31                           // 0000009099E8: 04B03F79
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009099EC: BF870193
	v_dot2acc_f32_f16 v55, v121, v23                           // 0000009099F0: 046E2F79
	v_dot2acc_f32_f16 v38, v121, v27                           // 0000009099F4: 044C3779
	v_sad_u8 v117, v117, 0, 0x6400                             // 0000009099F8: D6220075 03FD0175 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000909A04: BF870214
	v_dot2acc_f32_f16 v88, v122, v32                           // 000000909A08: 04B0417A
	v_dot2acc_f32_f16 v55, v122, v24                           // 000000909A0C: 046E317A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000909A10: BF870214
	v_dot2acc_f32_f16 v38, v122, v28                           // 000000909A14: 044C397A
	v_lshlrev_b32_e32 v118, 16, v117                           // 000000909A18: 30ECEA90
	ds_load_2addr_b32 v[116:117], v106 offset0:192 offset1:224 // 000000909A1C: D8DCE0C0 7400006A
	v_dot2acc_f32_f16 v39, v119, v29                           // 000000909A24: 044E3B77
	v_and_or_b32 v118, 0xffff, v113, v118                      // 000000909A28: D6570076 05DAE2FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 000000909A34: BF89FC27
	v_mov_b32_e32 v113, v111                                   // 000000909A38: 7EE2036F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000909A3C: BF870122
	v_pk_fma_f16 v111, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909A40: CC0E006F 0BFC0B76 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000909A4C: BF89FC17
	.long 0xd73d0071                                           // 000000909A50: D73D0071
	v_cndmask_b32_e32 v1, v102, v113, vcc_lo                   // 000000909A54: 0202E366
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000909A58: BF870112
	v_dual_dot2acc_f32_f16 v71, v122, v20 :: v_dual_dot2acc_f32_f16 v88, v111, v33// 000000909A5C: CB18297A 4758436F
	v_bfe_u32 v114, v113, 12, 16                               // 000000909A64: D6100072 02411971
	v_bfe_u32 v119, v113, 8, 16                                // 000000909A6C: D6100077 02411171
	s_waitcnt lgkmcnt(0)                                       // 000000909A74: BF89FC07
	v_bfe_u32 v120, v116, 12, 16                               // 000000909A78: D6100078 02411974
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000909A80: BF870193
	.long 0xd72c0072                                           // 000000909A84: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 000000909A88: 0202E4FF 83DCD12D
	.long 0xd72c0077                                           // 000000909A90: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000909A94: 0202EEFF 83DCD12D
	v_bfe_u32 v121, v116, 8, 16                                // 000000909A9C: D6100079 02411174
	v_bfe_u32 v123, v116, 4, 16                                // 000000909AA4: D610007B 02410974
	.long 0xd72c0078                                           // 000000909AAC: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000909AB0: 0202F0FF 83DCD12D
	v_and_b32_e32 v116, 0xffff, v116                           // 000000909AB8: 36E8E8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000909AC0: BF870004
	.long 0xd72c0079                                           // 000000909AC4: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000909AC8: 0202F2FF 83DCD12D
	v_sad_u8 v114, v114, 0, 0x6400                             // 000000909AD0: D6220072 03FD0172 00006400
	v_dot2acc_f32_f16 v71, v111, v21                           // 000000909ADC: 048E2B6F
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000909AE0: D6220077 03FD0177 00006400
	.long 0xd72c0074                                           // 000000909AEC: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 000000909AF0: 0202E8FF 83DCD12D
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000909AF8: D6220078 03FD0178 00006400
	v_and_b32_e32 v114, 0xffff, v114                           // 000000909B04: 36E4E4FF 0000FFFF
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000909B0C: D6220079 03FD0179 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000909B18: BF870193
	v_and_b32_e32 v120, 0xffff, v120                           // 000000909B1C: 36F0F0FF 0000FFFF
	v_lshl_or_b32 v114, v119, 16, v114                         // 000000909B24: D6560072 05C92177
	.long 0xd72c0077                                           // 000000909B2C: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000909B30: 0202F6FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000909B38: BF870232
	v_pk_fma_f16 v114, v114, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909B3C: CC0E0072 0BFC0B72 0000C931
	v_and_b32_e32 v118, 0xffff, v113                           // 000000909B48: 36ECE2FF 0000FFFF
	v_bfe_u32 v113, v113, 4, 16                                // 000000909B50: D6100071 02410971
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000909B58: D6220077 03FD0177 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000909B64: BF870214
	v_dot2acc_f32_f16 v87, v114, v30                           // 000000909B68: 04AE3D72
	.long 0xd72c0076                                           // 000000909B6C: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000909B70: 0202ECFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000909B78: BF8701A4
	.long 0xd72c0071                                           // 000000909B7C: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 000000909B80: 0202E2FF 83DCD12D
	v_dual_dot2acc_f32_f16 v38, v111, v29 :: v_dual_dot2acc_f32_f16 v37, v114, v26// 000000909B88: CB183B6F 26243572
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000909B90: D6220076 03FD0176 00006400
	v_dot2acc_f32_f16 v55, v111, v25                           // 000000909B9C: 046E336F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000909BA0: BF870224
	v_sad_u8 v113, v113, 0, 0x6400                             // 000000909BA4: D6220071 03FD0171 00006400
	v_sad_u8 v111, v116, 0, 0x6400                             // 000000909BB0: D622006F 03FD0174 00006400
	v_lshlrev_b32_e32 v118, 16, v118                           // 000000909BBC: 30ECEC90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000909BC0: BF870112
	v_lshlrev_b32_e32 v111, 16, v111                           // 000000909BC4: 30DEDE90
	v_and_or_b32 v113, 0xffff, v113, v118                      // 000000909BC8: D6570071 05DAE2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000909BD4: BF870241
	v_pk_fma_f16 v116, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909BD8: CC0E0074 0BFC0B71 0000C931
	v_mov_b32_e32 v113, v115                                   // 000000909BE4: 7EE20373
	v_lshl_or_b32 v118, v121, 16, v120                         // 000000909BE8: D6560076 05E12179
	v_and_or_b32 v115, 0xffff, v119, v111                      // 000000909BF0: D6570073 05BEEEFF 0000FFFF
	v_dual_dot2acc_f32_f16 v54, v114, v22 :: v_dual_dot2acc_f32_f16 v37, v116, v27// 000000909BFC: CB182D72 36243774
	v_dot2acc_f32_f16 v87, v116, v31                           // 000000909C04: 04AE3F74
	s_delay_alu instid0(VALU_DEP_4)                            // 000000909C08: BF870004
	v_pk_fma_f16 v118, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909C0C: CC0E0076 0BFC0B76 0000C931
	.long 0xd73d006f                                           // 000000909C18: D73D006F
	v_cndmask_b32_e32 v1, v102, v112, vcc_lo                   // 000000909C1C: 0202E166
	v_pk_fma_f16 v112, v115, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909C20: CC0E0070 0BFC0B73 0000C931
	v_dot2acc_f32_f16 v54, v116, v23                           // 000000909C2C: 046C2F74
	v_bfe_u32 v119, v117, 8, 16                                // 000000909C30: D6100077 02411175
	v_dot2acc_f32_f16 v87, v118, v32                           // 000000909C38: 04AE4176
	v_dot2acc_f32_f16 v70, v114, v18                           // 000000909C3C: 048C2572
	v_bfe_u32 v113, v111, 12, 16                               // 000000909C40: D6100071 0241196F
	v_bfe_u32 v114, v111, 8, 16                                // 000000909C48: D6100072 0241116F
	v_and_b32_e32 v115, 0xffff, v111                           // 000000909C50: 36E6DEFF 0000FFFF
	v_dot2acc_f32_f16 v87, v112, v33                           // 000000909C58: 04AE4370
	v_dot2acc_f32_f16 v70, v116, v19                           // 000000909C5C: 048C2774
	.long 0xd72c0071                                           // 000000909C60: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 000000909C64: 0202E2FF 83DCD12D
	v_bfe_u32 v111, v111, 4, 16                                // 000000909C6C: D610006F 0241096F
	.long 0xd72c0072                                           // 000000909C74: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 000000909C78: 0202E4FF 83DCD12D
	.long 0xd72c0073                                           // 000000909C80: D72C0073
	v_cndmask_b32_e32 v1, 0x83dcd12d, v115, vcc_lo             // 000000909C84: 0202E6FF 83DCD12D
	v_dot2acc_f32_f16 v70, v118, v20                           // 000000909C8C: 048C2976
	v_bfe_u32 v116, v117, 12, 16                               // 000000909C90: D6100074 02411975
	.long 0xd72c006f                                           // 000000909C98: D72C006F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 000000909C9C: 0202DEFF 83DCD12D
	v_bfe_u32 v120, v117, 4, 16                                // 000000909CA4: D6100078 02410975
	v_sad_u8 v113, v113, 0, 0x6400                             // 000000909CAC: D6220071 03FD0171 00006400
	v_dual_dot2acc_f32_f16 v54, v118, v24 :: v_dual_and_b32 v117, 0xffff, v117// 000000909CB8: CB243176 3674EAFF 0000FFFF
	v_sad_u8 v114, v114, 0, 0x6400                             // 000000909CC4: D6220072 03FD0172 00006400
	v_sad_u8 v115, v115, 0, 0x6400                             // 000000909CD0: D6220073 03FD0173 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000909CDC: BF870244
	v_and_b32_e32 v113, 0xffff, v113                           // 000000909CE0: 36E2E2FF 0000FFFF
	.long 0xd72c0074                                           // 000000909CE8: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 000000909CEC: 0202E8FF 83DCD12D
	v_dual_dot2acc_f32_f16 v54, v112, v25 :: v_dual_dot2acc_f32_f16 v37, v118, v28// 000000909CF4: CB183370 36243976
	v_sad_u8 v111, v111, 0, 0x6400                             // 000000909CFC: D622006F 03FD016F 00006400
	v_lshl_or_b32 v113, v114, 16, v113                         // 000000909D08: D6560071 05C52172
	v_lshlrev_b32_e32 v114, 16, v115                           // 000000909D10: 30E4E690
	.long 0xd72c0077                                           // 000000909D14: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000909D18: 0202EEFF 83DCD12D
	.long 0xd72c0075                                           // 000000909D20: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000909D24: 0202EAFF 83DCD12D
	v_sad_u8 v116, v116, 0, 0x6400                             // 000000909D2C: D6220074 03FD0174 00006400
	v_pk_fma_f16 v113, v113, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909D38: CC0E0071 0BFC0B71 0000C931
	v_dot2acc_f32_f16 v37, v112, v29                           // 000000909D44: 044A3B70
	v_and_or_b32 v111, 0xffff, v111, v114                      // 000000909D48: D657006F 05CADEFF 0000FFFF
	.long 0xd72c0073                                           // 000000909D54: D72C0073
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000909D58: 0202F0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000909D60: BF870224
	v_dual_dot2acc_f32_f16 v69, v113, v18 :: v_dual_and_b32 v116, 0xffff, v116// 000000909D64: CB242571 4574E8FF 0000FFFF
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000909D70: D6220077 03FD0177 00006400
	v_pk_fma_f16 v111, v111, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909D7C: CC0E006F 0BFC0B6F 0000C931
	v_sad_u8 v117, v117, 0, 0x6400                             // 000000909D88: D6220075 03FD0175 00006400
	v_dot2acc_f32_f16 v86, v113, v30                           // 000000909D94: 04AC3D71
	v_dot2acc_f32_f16 v53, v113, v22                           // 000000909D98: 046A2D71
	v_lshl_or_b32 v114, v119, 16, v116                         // 000000909D9C: D6560072 05D12177
	v_dot2acc_f32_f16 v69, v111, v19                           // 000000909DA4: 048A276F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000909DA8: BF8701B4
	v_dual_dot2acc_f32_f16 v1, v113, v26 :: v_dual_dot2acc_f32_f16 v86, v111, v31// 000000909DAC: CB183571 01563F6F
	v_sad_u8 v115, v115, 0, 0x6400                             // 000000909DB4: D6220073 03FD0173 00006400
	v_lshlrev_b32_e32 v116, 16, v117                           // 000000909DC0: 30E8EA90
	v_dual_dot2acc_f32_f16 v70, v112, v21 :: v_dual_dot2acc_f32_f16 v1, v111, v27// 000000909DC4: CB182B70 4600376F
	v_pk_fma_f16 v112, v114, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000909DCC: CC0E0070 0BFC0B72 0000C931
	v_dot2acc_f32_f16 v53, v111, v23                           // 000000909DD8: 046A2F6F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000909DDC: BF870224
	v_and_or_b32 v30, 0xffff, v115, v116                       // 000000909DE0: D657001E 05D2E6FF 0000FFFF
	v_add_nc_u32_e32 v19, v103, v104                           // 000000909DEC: 4A26D167
	v_dot2acc_f32_f16 v86, v112, v32                           // 000000909DF0: 04AC4170
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000909DF4: BF870214
	v_dot2acc_f32_f16 v53, v112, v24                           // 000000909DF8: 046A3170
	v_pk_fma_f16 v18, v30, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000909DFC: CC0E0012 0BFC0B1E 0000C931
	v_dot2acc_f32_f16 v69, v112, v20                           // 000000909E08: 048A2970
	v_dot2acc_f32_f16 v1, v112, v28                            // 000000909E0C: 04023970
	v_cmp_eq_u32_e32 vcc_lo, 21, v19                           // 000000909E10: 7C942695
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000909E14: BF870214
	v_dot2acc_f32_f16 v86, v18, v33                            // 000000909E18: 04AC4312
	v_dot2acc_f32_f16 v69, v18, v21                            // 000000909E1C: 048A2B12
	v_dot2acc_f32_f16 v53, v18, v25                            // 000000909E20: 046A3312
	v_dot2acc_f32_f16 v1, v18, v29                             // 000000909E24: 04023B12
	s_or_b32 s4, vcc_lo, s4                                    // 000000909E28: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000909E2C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000909E30: 917E047E
	s_cbranch_execz 62                                         // 000000909E34: BFA5003E <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2930>
	s_mov_b32 s3, exec_lo                                      // 000000909E38: BE83007E
	s_waitcnt vmcnt(14)                                        // 000000909E3C: BF893BF7
	ds_store_2addr_b32 v105, v2, v3 offset1:32                 // 000000909E40: D8382000 00030269
	s_waitcnt vmcnt(12)                                        // 000000909E48: BF8933F7
	ds_store_2addr_b32 v105, v4, v5 offset0:64 offset1:96      // 000000909E4C: D8386040 00050469
	s_waitcnt vmcnt(10)                                        // 000000909E54: BF892BF7
	ds_store_2addr_b32 v105, v6, v7 offset0:128 offset1:160    // 000000909E58: D838A080 00070669
	s_waitcnt vmcnt(8)                                         // 000000909E60: BF8923F7
	ds_store_2addr_b32 v105, v8, v9 offset0:192 offset1:224    // 000000909E64: D838E0C0 00090869
	s_waitcnt vmcnt(6)                                         // 000000909E6C: BF891BF7
	ds_store_2addr_b32 v106, v10, v11 offset1:32               // 000000909E70: D8382000 000B0A6A
	s_waitcnt vmcnt(4)                                         // 000000909E78: BF8913F7
	ds_store_2addr_b32 v106, v12, v13 offset0:64 offset1:96    // 000000909E7C: D8386040 000D0C6A
	s_waitcnt vmcnt(2)                                         // 000000909E84: BF890BF7
	ds_store_2addr_b32 v106, v14, v15 offset0:128 offset1:160  // 000000909E88: D838A080 000F0E6A
	s_waitcnt vmcnt(0)                                         // 000000909E90: BF8903F7
	ds_store_2addr_b32 v106, v16, v17 offset0:192 offset1:224  // 000000909E94: D838E0C0 0011106A
	.long 0xd4c4007e                                           // 000000909E9C: D4C4007E
	v_cndmask_b32_e32 v1, s13, v104, vcc_lo                    // 000000909EA0: 0202D00D
	s_cbranch_execz 63518                                      // 000000909EA4: BFA5F81E <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x920>
	s_clause 0xf                                               // 000000909EA8: BF85000F
	global_load_b32 v2, v[35:36], off                          // 000000909EAC: DC520000 027C0023
	global_load_b32 v3, v[35:36], off offset:128               // 000000909EB4: DC520080 037C0023
	global_load_b32 v4, v[35:36], off offset:256               // 000000909EBC: DC520100 047C0023
	global_load_b32 v5, v[35:36], off offset:384               // 000000909EC4: DC520180 057C0023
	global_load_b32 v6, v[35:36], off offset:512               // 000000909ECC: DC520200 067C0023
	global_load_b32 v7, v[35:36], off offset:640               // 000000909ED4: DC520280 077C0023
	global_load_b32 v8, v[35:36], off offset:768               // 000000909EDC: DC520300 087C0023
	global_load_b32 v9, v[35:36], off offset:896               // 000000909EE4: DC520380 097C0023
	global_load_b32 v10, v[35:36], off offset:1024             // 000000909EEC: DC520400 0A7C0023
	global_load_b32 v11, v[35:36], off offset:1152             // 000000909EF4: DC520480 0B7C0023
	global_load_b32 v12, v[35:36], off offset:1280             // 000000909EFC: DC520500 0C7C0023
	global_load_b32 v13, v[35:36], off offset:1408             // 000000909F04: DC520580 0D7C0023
	global_load_b32 v14, v[35:36], off offset:1536             // 000000909F0C: DC520600 0E7C0023
	global_load_b32 v15, v[35:36], off offset:1664             // 000000909F14: DC520680 0F7C0023
	global_load_b32 v16, v[35:36], off offset:1792             // 000000909F1C: DC520700 107C0023
	global_load_b32 v17, v[35:36], off offset:1920             // 000000909F24: DC520780 117C0023
	s_branch 63484                                             // 000000909F2C: BFA0F7FC <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x920>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000909F30: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000909F34: BF870009
	s_or_b32 exec_lo, exec_lo, s20                             // 000000909F38: 8C7E147E
	s_load_b128 s[20:23], s[0:1], 0x40                         // 000000909F3C: F4080500 F8000040
	s_waitcnt vmcnt(4)                                         // 000000909F44: BF8913F7
	v_dual_mov_b32 v112, v85 :: v_dual_mov_b32 v13, v68        // 000000909F48: CA100155 700C0144
	s_waitcnt vmcnt(0)                                         // 000000909F50: BF8903F7
	v_dual_mov_b32 v30, v84 :: v_dual_mov_b32 v17, v67         // 000000909F54: CA100154 1E100143
	v_dual_mov_b32 v4, v51 :: v_dual_mov_b32 v31, v82          // 000000909F5C: CA100133 041E0152
	v_dual_mov_b32 v114, v100 :: v_dual_mov_b32 v117, v99      // 000000909F64: CA100164 72740163
	v_dual_mov_b32 v36, v83 :: v_dual_mov_b32 v15, v66         // 000000909F6C: CA100153 240E0142
	v_dual_mov_b32 v6, v50 :: v_dual_mov_b32 v5, v49           // 000000909F74: CA100132 06040131
	v_dual_mov_b32 v115, v98 :: v_dual_mov_b32 v18, v65        // 000000909F7C: CA100162 73120141
	v_dual_mov_b32 v33, v81 :: v_dual_mov_b32 v8, v47          // 000000909F84: CA100151 2108012F
	v_dual_mov_b32 v7, v48 :: v_dual_mov_b32 v116, v97         // 000000909F8C: CA100130 07740161
	v_dual_mov_b32 v101, v80 :: v_dual_mov_b32 v122, v95       // 000000909F94: CA100150 657A015F
	v_dual_mov_b32 v19, v64 :: v_dual_mov_b32 v10, v45         // 000000909F9C: CA100140 130A012D
	v_dual_mov_b32 v119, v96 :: v_dual_mov_b32 v108, v77       // 000000909FA4: CA100160 776C014D
	v_dual_mov_b32 v103, v79 :: v_dual_mov_b32 v14, v42        // 000000909FAC: CA10014F 670E012A
	v_dual_mov_b32 v21, v63 :: v_dual_mov_b32 v32, v58         // 000000909FB4: CA10013F 1520013A
	v_dual_mov_b32 v9, v46 :: v_dual_mov_b32 v12, v43          // 000000909FBC: CA10012E 090C012B
	v_dual_mov_b32 v105, v78 :: v_dual_mov_b32 v128, v91       // 000000909FC4: CA10014E 6980015B
	v_dual_mov_b32 v23, v62 :: v_dual_mov_b32 v16, v41         // 000000909FCC: CA10013E 17100129
	v_dual_mov_b32 v123, v94 :: v_dual_mov_b32 v118, v73       // 000000909FD4: CA10015E 7B760149
	v_dual_mov_b32 v25, v61 :: v_dual_mov_b32 v20, v40         // 000000909FDC: CA10013D 19140128
	v_dual_mov_b32 v11, v44 :: v_dual_mov_b32 v102, v57        // 000000909FE4: CA10012C 0B660139
	v_dual_mov_b32 v125, v93 :: v_dual_mov_b32 v120, v72       // 000000909FEC: CA10015D 7D780148
	v_dual_mov_b32 v109, v76 :: v_dual_mov_b32 v130, v89       // 000000909FF4: CA10014C 6D820159
	v_dual_mov_b32 v27, v60 :: v_dual_mov_b32 v22, v39         // 000000909FFC: CA10013C 1B160127
	v_dual_mov_b32 v127, v92 :: v_dual_mov_b32 v106, v55       // 00000090A004: CA10015C 7F6A0137
	v_dual_mov_b32 v111, v75 :: v_dual_mov_b32 v104, v56       // 00000090A00C: CA10014B 6F680138
	v_dual_mov_b32 v29, v59 :: v_dual_mov_b32 v24, v38         // 00000090A014: CA10013B 1D180126
	v_dual_mov_b32 v113, v74 :: v_dual_mov_b32 v132, v87       // 00000090A01C: CA10014A 71840157
	v_dual_mov_b32 v129, v90 :: v_dual_mov_b32 v26, v37        // 00000090A024: CA10015A 811A0125
	v_dual_mov_b32 v131, v88 :: v_dual_mov_b32 v124, v70       // 00000090A02C: CA100158 837C0146
	v_dual_mov_b32 v121, v71 :: v_dual_mov_b32 v126, v69       // 00000090A034: CA100147 797E0145
	v_dual_mov_b32 v107, v54 :: v_dual_mov_b32 v110, v53       // 00000090A03C: CA100136 6B6E0135
	v_dual_mov_b32 v133, v86 :: v_dual_mov_b32 v28, v1         // 00000090A044: CA100156 851C0101
	s_mov_b32 s3, 0x76543210                                   // 00000090A04C: BE8300FF 76543210
	.long 0xd44c0000                                           // 00000090A054: D44C0000
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 00000090A058: 02020090
	v_permlanex16_b32 v112, v112, s3, 0xfedcba98               // 00000090A05C: D65C0070 03FC0770 FEDCBA98
	v_permlanex16_b32 v30, v30, s3, 0xfedcba98                 // 00000090A068: D65C001E 03FC071E FEDCBA98
	v_permlanex16_b32 v13, v13, s3, 0xfedcba98                 // 00000090A074: D65C000D 03FC070D FEDCBA98
	v_permlanex16_b32 v4, v4, s3, 0xfedcba98                   // 00000090A080: D65C0004 03FC0704 FEDCBA98
	v_permlanex16_b32 v114, v114, s3, 0xfedcba98               // 00000090A08C: D65C0072 03FC0772 FEDCBA98
	v_permlanex16_b32 v36, v36, s3, 0xfedcba98                 // 00000090A098: D65C0024 03FC0724 FEDCBA98
	v_permlanex16_b32 v17, v17, s3, 0xfedcba98                 // 00000090A0A4: D65C0011 03FC0711 FEDCBA98
	v_permlanex16_b32 v6, v6, s3, 0xfedcba98                   // 00000090A0B0: D65C0006 03FC0706 FEDCBA98
	v_permlanex16_b32 v117, v117, s3, 0xfedcba98               // 00000090A0BC: D65C0075 03FC0775 FEDCBA98
	v_permlanex16_b32 v31, v31, s3, 0xfedcba98                 // 00000090A0C8: D65C001F 03FC071F FEDCBA98
	v_permlanex16_b32 v15, v15, s3, 0xfedcba98                 // 00000090A0D4: D65C000F 03FC070F FEDCBA98
	v_permlanex16_b32 v5, v5, s3, 0xfedcba98                   // 00000090A0E0: D65C0005 03FC0705 FEDCBA98
	v_permlanex16_b32 v115, v115, s3, 0xfedcba98               // 00000090A0EC: D65C0073 03FC0773 FEDCBA98
	v_permlanex16_b32 v33, v33, s3, 0xfedcba98                 // 00000090A0F8: D65C0021 03FC0721 FEDCBA98
	v_permlanex16_b32 v18, v18, s3, 0xfedcba98                 // 00000090A104: D65C0012 03FC0712 FEDCBA98
	v_permlanex16_b32 v7, v7, s3, 0xfedcba98                   // 00000090A110: D65C0007 03FC0707 FEDCBA98
	v_permlanex16_b32 v116, v116, s3, 0xfedcba98               // 00000090A11C: D65C0074 03FC0774 FEDCBA98
	v_permlanex16_b32 v101, v101, s3, 0xfedcba98               // 00000090A128: D65C0065 03FC0765 FEDCBA98
	v_permlanex16_b32 v19, v19, s3, 0xfedcba98                 // 00000090A134: D65C0013 03FC0713 FEDCBA98
	v_permlanex16_b32 v8, v8, s3, 0xfedcba98                   // 00000090A140: D65C0008 03FC0708 FEDCBA98
	v_permlanex16_b32 v119, v119, s3, 0xfedcba98               // 00000090A14C: D65C0077 03FC0777 FEDCBA98
	v_permlanex16_b32 v103, v103, s3, 0xfedcba98               // 00000090A158: D65C0067 03FC0767 FEDCBA98
	v_permlanex16_b32 v21, v21, s3, 0xfedcba98                 // 00000090A164: D65C0015 03FC0715 FEDCBA98
	v_permlanex16_b32 v9, v9, s3, 0xfedcba98                   // 00000090A170: D65C0009 03FC0709 FEDCBA98
	v_permlanex16_b32 v122, v122, s3, 0xfedcba98               // 00000090A17C: D65C007A 03FC077A FEDCBA98
	v_permlanex16_b32 v105, v105, s3, 0xfedcba98               // 00000090A188: D65C0069 03FC0769 FEDCBA98
	v_permlanex16_b32 v23, v23, s3, 0xfedcba98                 // 00000090A194: D65C0017 03FC0717 FEDCBA98
	v_permlanex16_b32 v10, v10, s3, 0xfedcba98                 // 00000090A1A0: D65C000A 03FC070A FEDCBA98
	v_permlanex16_b32 v123, v123, s3, 0xfedcba98               // 00000090A1AC: D65C007B 03FC077B FEDCBA98
	v_permlanex16_b32 v108, v108, s3, 0xfedcba98               // 00000090A1B8: D65C006C 03FC076C FEDCBA98
	v_permlanex16_b32 v25, v25, s3, 0xfedcba98                 // 00000090A1C4: D65C0019 03FC0719 FEDCBA98
	v_permlanex16_b32 v11, v11, s3, 0xfedcba98                 // 00000090A1D0: D65C000B 03FC070B FEDCBA98
	v_permlanex16_b32 v125, v125, s3, 0xfedcba98               // 00000090A1DC: D65C007D 03FC077D FEDCBA98
	v_permlanex16_b32 v109, v109, s3, 0xfedcba98               // 00000090A1E8: D65C006D 03FC076D FEDCBA98
	v_permlanex16_b32 v27, v27, s3, 0xfedcba98                 // 00000090A1F4: D65C001B 03FC071B FEDCBA98
	v_permlanex16_b32 v12, v12, s3, 0xfedcba98                 // 00000090A200: D65C000C 03FC070C FEDCBA98
	v_permlanex16_b32 v127, v127, s3, 0xfedcba98               // 00000090A20C: D65C007F 03FC077F FEDCBA98
	v_permlanex16_b32 v111, v111, s3, 0xfedcba98               // 00000090A218: D65C006F 03FC076F FEDCBA98
	v_permlanex16_b32 v29, v29, s3, 0xfedcba98                 // 00000090A224: D65C001D 03FC071D FEDCBA98
	v_permlanex16_b32 v14, v14, s3, 0xfedcba98                 // 00000090A230: D65C000E 03FC070E FEDCBA98
	v_permlanex16_b32 v128, v128, s3, 0xfedcba98               // 00000090A23C: D65C0080 03FC0780 FEDCBA98
	v_permlanex16_b32 v113, v113, s3, 0xfedcba98               // 00000090A248: D65C0071 03FC0771 FEDCBA98
	v_permlanex16_b32 v32, v32, s3, 0xfedcba98                 // 00000090A254: D65C0020 03FC0720 FEDCBA98
	v_permlanex16_b32 v16, v16, s3, 0xfedcba98                 // 00000090A260: D65C0010 03FC0710 FEDCBA98
	v_permlanex16_b32 v129, v129, s3, 0xfedcba98               // 00000090A26C: D65C0081 03FC0781 FEDCBA98
	v_permlanex16_b32 v118, v118, s3, 0xfedcba98               // 00000090A278: D65C0076 03FC0776 FEDCBA98
	v_permlanex16_b32 v102, v102, s3, 0xfedcba98               // 00000090A284: D65C0066 03FC0766 FEDCBA98
	v_permlanex16_b32 v20, v20, s3, 0xfedcba98                 // 00000090A290: D65C0014 03FC0714 FEDCBA98
	v_permlanex16_b32 v130, v130, s3, 0xfedcba98               // 00000090A29C: D65C0082 03FC0782 FEDCBA98
	v_permlanex16_b32 v120, v120, s3, 0xfedcba98               // 00000090A2A8: D65C0078 03FC0778 FEDCBA98
	v_permlanex16_b32 v104, v104, s3, 0xfedcba98               // 00000090A2B4: D65C0068 03FC0768 FEDCBA98
	v_permlanex16_b32 v22, v22, s3, 0xfedcba98                 // 00000090A2C0: D65C0016 03FC0716 FEDCBA98
	v_permlanex16_b32 v131, v131, s3, 0xfedcba98               // 00000090A2CC: D65C0083 03FC0783 FEDCBA98
	v_permlanex16_b32 v121, v121, s3, 0xfedcba98               // 00000090A2D8: D65C0079 03FC0779 FEDCBA98
	v_permlanex16_b32 v106, v106, s3, 0xfedcba98               // 00000090A2E4: D65C006A 03FC076A FEDCBA98
	v_permlanex16_b32 v24, v24, s3, 0xfedcba98                 // 00000090A2F0: D65C0018 03FC0718 FEDCBA98
	v_permlanex16_b32 v132, v132, s3, 0xfedcba98               // 00000090A2FC: D65C0084 03FC0784 FEDCBA98
	v_permlanex16_b32 v124, v124, s3, 0xfedcba98               // 00000090A308: D65C007C 03FC077C FEDCBA98
	v_permlanex16_b32 v107, v107, s3, 0xfedcba98               // 00000090A314: D65C006B 03FC076B FEDCBA98
	v_permlanex16_b32 v26, v26, s3, 0xfedcba98                 // 00000090A320: D65C001A 03FC071A FEDCBA98
	v_permlanex16_b32 v133, v133, s3, 0xfedcba98               // 00000090A32C: D65C0085 03FC0785 FEDCBA98
	v_permlanex16_b32 v126, v126, s3, 0xfedcba98               // 00000090A338: D65C007E 03FC077E FEDCBA98
	v_permlanex16_b32 v110, v110, s3, 0xfedcba98               // 00000090A344: D65C006E 03FC076E FEDCBA98
	v_permlanex16_b32 v28, v28, s3, 0xfedcba98                 // 00000090A350: D65C001C 03FC071C FEDCBA98
	s_min_i32 s26, s11, 4                                      // 00000090A35C: 891A840B
	s_and_saveexec_b32 s1, s0                                  // 00000090A360: BE812000
	s_cbranch_execz 151                                        // 00000090A364: BFA50097 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2fc4>
	.long 0xd51a0023                                           // 00000090A368: D51A0023
	v_cndmask_b32_e32 v0, 31, v12, vcc_lo                      // 00000090A36C: 0200189F
	s_cmp_lt_i32 s11, 1                                        // 00000090A370: BF04810B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000090A374: BF8700B1
	.long 0xd73c0002                                           // 00000090A378: D73C0002
	v_cndmask_b32_e32 v1, 4, v34, vcc_lo                       // 00000090A37C: 02024484
	s_waitcnt lgkmcnt(0)                                       // 00000090A380: BF89FC07
	.long 0xd7000322                                           // 00000090A384: D7000322
	v_cndmask_b32_e32 v1, s20, v52, vcc_lo                     // 00000090A388: 02026814
	v_add_co_ci_u32_e64 v35, null, s21, 0, s3                  // 00000090A38C: D5207C23 000D0015
	s_cbranch_scc1 66                                          // 00000090A394: BFA20042 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2ea0>
	s_mul_i32 s3, s10, 5                                       // 00000090A398: 9603850A
	s_mul_hi_i32 s5, s10, 5                                    // 00000090A39C: 9705850A
	s_add_u32 s4, s3, s6                                       // 00000090A3A0: 80040603
	s_addc_u32 s5, s5, s7                                      // 00000090A3A4: 82050705
	v_dual_add_f32 v52, v85, v112 :: v_dual_add_f32 v85, v100, v114// 00000090A3A8: C908E155 3454E564
	s_lshl_b64 s[4:5], s[4:5], 7                               // 00000090A3B0: 84848704
	v_dual_add_f32 v112, v98, v115 :: v_dual_add_f32 v93, v93, v125// 00000090A3B4: C908E762 705CFB5D
	.long 0xd7006a62                                           // 00000090A3BC: D7006A62
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000090A3C0: 02020404
	v_dual_add_f32 v100, v99, v117 :: v_dual_add_f32 v97, v97, v116// 00000090A3C4: C908EB63 6460E961
	v_add_co_ci_u32_e64 v99, null, s5, v3, vcc_lo              // 00000090A3CC: D5207C63 01AA0605
	v_dual_add_f32 v114, v95, v122 :: v_dual_add_f32 v115, v94, v123// 00000090A3D4: C908F55F 7272F75E
	v_add_f32_e32 v96, v96, v119                               // 00000090A3DC: 06C0EF60
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000090A3E0: BF870243
	.long 0xd73c005e                                           // 00000090A3E4: D73C005E
	v_cndmask_b32_e32 v1, 6, v98, vcc_lo                       // 00000090A3E8: 0202C486
	v_dual_add_f32 v99, v90, v129 :: v_dual_add_f32 v98, v91, v128// 00000090A3EC: C909035A 6363015B
	v_dual_add_f32 v92, v92, v127 :: v_dual_add_f32 v89, v89, v130// 00000090A3F4: C908FF5C 5C590559
	v_dual_add_f32 v88, v88, v131 :: v_dual_add_f32 v87, v87, v132// 00000090A3FC: C9090758 58570957
	.long 0xd7006a5a                                           // 00000090A404: D7006A5A
	v_cndmask_b32_e32 v1, v34, v94, vcc_lo                     // 00000090A408: 0202BD22
	s_delay_alu instid0(VALU_DEP_1)                            // 00000090A40C: BF870001
	v_add_co_ci_u32_e64 v91, null, v35, v95, vcc_lo            // 00000090A410: D5207C5B 01AABF23
	v_add_f32_e32 v86, v86, v133                               // 00000090A418: 06AD0B56
	s_clause 0xf                                               // 00000090A41C: BF85000F
	global_store_b32 v[90:91], v52, off                        // 00000090A420: DC6A0000 007C345A
	global_store_b32 v[90:91], v85, off offset:64              // 00000090A428: DC6A0040 007C555A
	global_store_b32 v[90:91], v100, off offset:128            // 00000090A430: DC6A0080 007C645A
	global_store_b32 v[90:91], v112, off offset:192            // 00000090A438: DC6A00C0 007C705A
	global_store_b32 v[90:91], v97, off offset:256             // 00000090A440: DC6A0100 007C615A
	global_store_b32 v[90:91], v96, off offset:320             // 00000090A448: DC6A0140 007C605A
	global_store_b32 v[90:91], v114, off offset:384            // 00000090A450: DC6A0180 007C725A
	global_store_b32 v[90:91], v115, off offset:448            // 00000090A458: DC6A01C0 007C735A
	global_store_b32 v[90:91], v93, off offset:512             // 00000090A460: DC6A0200 007C5D5A
	global_store_b32 v[90:91], v92, off offset:576             // 00000090A468: DC6A0240 007C5C5A
	global_store_b32 v[90:91], v98, off offset:640             // 00000090A470: DC6A0280 007C625A
	global_store_b32 v[90:91], v99, off offset:704             // 00000090A478: DC6A02C0 007C635A
	global_store_b32 v[90:91], v89, off offset:768             // 00000090A480: DC6A0300 007C595A
	global_store_b32 v[90:91], v88, off offset:832             // 00000090A488: DC6A0340 007C585A
	global_store_b32 v[90:91], v87, off offset:896             // 00000090A490: DC6A0380 007C575A
	global_store_b32 v[90:91], v86, off offset:960             // 00000090A498: DC6A03C0 007C565A
	s_cmp_lt_i32 s11, 2                                        // 00000090A4A0: BF04820B
	s_cbranch_scc0 1666                                        // 00000090A4A4: BFA10682 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x48b0>
	s_cmp_lt_i32 s11, 3                                        // 00000090A4A8: BF04830B
	s_cbranch_scc0 1733                                        // 00000090A4AC: BFA106C5 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x49c4>
	s_cmp_lt_i32 s11, 4                                        // 00000090A4B0: BF04840B
	s_cbranch_scc1 67                                          // 00000090A4B4: BFA20043 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2fc4>
	s_add_i32 s3, s10, 3                                       // 00000090A4B8: 8103830A
	v_dual_add_f32 v4, v51, v4 :: v_dual_add_f32 v5, v49, v5   // 00000090A4BC: C9080933 04040B31
	s_mul_i32 s4, s3, 5                                        // 00000090A4C4: 96048503
	s_mul_hi_i32 s3, s3, 5                                     // 00000090A4C8: 97038503
	s_add_u32 s4, s4, s6                                       // 00000090A4CC: 80040604
	s_addc_u32 s5, s3, s7                                      // 00000090A4D0: 82050703
	v_dual_add_f32 v6, v50, v6 :: v_dual_add_f32 v7, v48, v7   // 00000090A4D4: C9080D32 06060F30
	s_lshl_b64 s[4:5], s[4:5], 7                               // 00000090A4DC: 84848704
	v_dual_add_f32 v8, v47, v8 :: v_dual_add_f32 v9, v46, v9   // 00000090A4E0: C908112F 0808132E
	.long 0xd7006a02                                           // 00000090A4E8: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000090A4EC: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000090A4F0: BF8701B1
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000090A4F4: D5207C03 01AA0605
	v_dual_add_f32 v10, v45, v10 :: v_dual_add_f32 v11, v44, v11// 00000090A4FC: C908152D 0A0A172C
	v_dual_add_f32 v12, v43, v12 :: v_dual_add_f32 v13, v42, v14// 00000090A504: C908192B 0C0C1D2A
	.long 0xd73c0002                                           // 00000090A50C: D73C0002
	v_cndmask_b32_e32 v1, 6, v2, vcc_lo                        // 00000090A510: 02020486
	v_add_f32_e32 v14, v41, v16                                // 00000090A514: 061C2129
	v_dual_add_f32 v15, v40, v20 :: v_dual_add_f32 v16, v39, v22// 00000090A518: C9082928 0F102D27
	v_dual_add_f32 v17, v38, v24 :: v_dual_add_f32 v18, v37, v26// 00000090A520: C9083126 11123525
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000090A528: BF870094
	.long 0xd7006a02                                           // 00000090A52C: D7006A02
	v_cndmask_b32_e32 v1, v34, v2, vcc_lo                      // 00000090A530: 02020522
	v_add_co_ci_u32_e64 v3, null, v35, v3, vcc_lo              // 00000090A534: D5207C03 01AA0723
	v_add_f32_e32 v1, v1, v28                                  // 00000090A53C: 06023901
	s_clause 0xf                                               // 00000090A540: BF85000F
	global_store_b32 v[2:3], v4, off                           // 00000090A544: DC6A0000 007C0402
	global_store_b32 v[2:3], v6, off offset:64                 // 00000090A54C: DC6A0040 007C0602
	global_store_b32 v[2:3], v5, off offset:128                // 00000090A554: DC6A0080 007C0502
	global_store_b32 v[2:3], v7, off offset:192                // 00000090A55C: DC6A00C0 007C0702
	global_store_b32 v[2:3], v8, off offset:256                // 00000090A564: DC6A0100 007C0802
	global_store_b32 v[2:3], v9, off offset:320                // 00000090A56C: DC6A0140 007C0902
	global_store_b32 v[2:3], v10, off offset:384               // 00000090A574: DC6A0180 007C0A02
	global_store_b32 v[2:3], v11, off offset:448               // 00000090A57C: DC6A01C0 007C0B02
	global_store_b32 v[2:3], v12, off offset:512               // 00000090A584: DC6A0200 007C0C02
	global_store_b32 v[2:3], v13, off offset:576               // 00000090A58C: DC6A0240 007C0D02
	global_store_b32 v[2:3], v14, off offset:640               // 00000090A594: DC6A0280 007C0E02
	global_store_b32 v[2:3], v15, off offset:704               // 00000090A59C: DC6A02C0 007C0F02
	global_store_b32 v[2:3], v16, off offset:768               // 00000090A5A4: DC6A0300 007C1002
	global_store_b32 v[2:3], v17, off offset:832               // 00000090A5AC: DC6A0340 007C1102
	global_store_b32 v[2:3], v18, off offset:896               // 00000090A5B4: DC6A0380 007C1202
	global_store_b32 v[2:3], v1, off offset:960                // 00000090A5BC: DC6A03C0 007C0102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000090A5C4: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000090A5C8: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000090A5CC: BE81007E
	s_waitcnt lgkmcnt(0)                                       // 00000090A5D0: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000090A5D4: BC7C0000
	buffer_gl1_inv                                             // 00000090A5D8: E0B00000 00000000
	buffer_gl0_inv                                             // 00000090A5E0: E0AC0000 00000000
	v_cmpx_eq_u32_e32 0, v0                                    // 00000090A5E8: 7D940080
	s_cbranch_execz 27                                         // 00000090A5EC: BFA5001B <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x305c>
	s_mov_b32 s4, exec_lo                                      // 00000090A5F0: BE84007E
	s_mov_b32 s3, exec_lo                                      // 00000090A5F4: BE83007E
	.long 0xd71f0001                                           // 00000090A5F8: D71F0001
	v_cndmask_b32_e32 v0, s4, v128, vcc_lo                     // 00000090A5FC: 02010004
	s_delay_alu instid0(VALU_DEP_1)                            // 00000090A600: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 00000090A604: 7D940280
	s_cbranch_execz 9                                          // 00000090A608: BFA50009 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x3030>
	s_lshl_b64 s[12:13], s[24:25], 2                           // 00000090A60C: 848C8218
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000090A610: BF8704B9
	s_add_u32 s12, s22, s12                                    // 00000090A614: 800C0C16
	s_addc_u32 s13, s23, s13                                   // 00000090A618: 820D0D17
	s_bcnt1_i32_b32 s4, s4                                     // 00000090A61C: BE841804
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s4              // 00000090A620: CA100080 02020004
	global_atomic_add_u32 v2, v2, v3, s[12:13] glc             // 00000090A628: DCD64000 020C0302
	s_or_b32 exec_lo, exec_lo, s3                              // 00000090A630: 8C7E037E
	s_waitcnt vmcnt(0)                                         // 00000090A634: BF8903F7
	v_readfirstlane_b32 s3, v2                                 // 00000090A638: 7E060502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000090A63C: BF870091
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s3, v1       // 00000090A640: CA200080 02000203
	v_cmp_eq_u32_e32 vcc_lo, 7, v1                             // 00000090A648: 7C940287
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 00000090A64C: D5010001 01A90280
	ds_store_b32 v2, v1 offset:22592                           // 00000090A654: D8345840 00000102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000090A65C: 8C7E017E
	v_mov_b32_e32 v1, 0                                        // 00000090A660: 7E020280
	ds_load_b32 v1, v1 offset:22592                            // 00000090A664: D8D85840 01000001
	s_waitcnt lgkmcnt(0)                                       // 00000090A66C: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000090A670: 7C940280
	s_cbranch_vccnz 1547                                       // 00000090A674: BFA4060B <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x48a4>
	s_mov_b32 s1, -1                                           // 00000090A678: BE8100C1
	buffer_gl1_inv                                             // 00000090A67C: E0B00000 00000000
	buffer_gl0_inv                                             // 00000090A684: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 00000090A68C: BE832001
	s_cbranch_execz 1540                                       // 00000090A690: BFA50604 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x48a4>
	s_cmp_lt_i32 s11, 1                                        // 00000090A694: BF04810B
	s_cbranch_scc1 1530                                        // 00000090A698: BFA205FA <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x4884>
	s_mul_i32 s1, s8, 0x500                                    // 00000090A69C: 9601FF08 00000500
	s_mul_hi_i32 s3, s8, 0x500                                 // 00000090A6A4: 9703FF08 00000500
	s_add_u32 s1, s16, s1                                      // 00000090A6AC: 80010110
	s_addc_u32 s3, s17, s3                                     // 00000090A6B0: 82030311
	s_lshl_b32 s4, s9, 7                                       // 00000090A6B4: 84048709
	v_and_b32_e32 v1, 15, v0                                   // 00000090A6B8: 3602008F
	s_ashr_i32 s5, s4, 31                                      // 00000090A6BC: 86059F04
	s_mul_hi_i32 s9, s8, 0xa00                                 // 00000090A6C0: 9709FF08 00000A00
	s_lshl_b64 s[12:13], s[4:5], 1                             // 00000090A6C8: 848C8104
	s_mulk_i32 s8, 0xa00                                       // 00000090A6CC: B8080A00
	s_add_u32 s4, s1, s12                                      // 00000090A6D0: 80040C01
	v_lshlrev_b32_e32 v2, 1, v0                                // 00000090A6D4: 30040081
	v_lshlrev_b32_e32 v28, 1, v1                               // 00000090A6D8: 30380281
	s_addc_u32 s5, s3, s13                                     // 00000090A6DC: 82050D03
	s_add_u32 s1, s14, s8                                      // 00000090A6E0: 8001080E
	s_addc_u32 s3, s15, s9                                     // 00000090A6E4: 8203090F
	s_add_u32 s8, s1, s12                                      // 00000090A6E8: 80080C01
	s_addc_u32 s9, s3, s13                                     // 00000090A6EC: 82090D03
	v_or_b32_e32 v4, 32, v2                                    // 00000090A6F0: 380804A0
	v_or_b32_e32 v5, 0x60, v2                                  // 00000090A6F4: 380A04FF 00000060
	v_or_b32_e32 v6, 0xa0, v2                                  // 00000090A6FC: 380C04FF 000000A0
	v_or_b32_e32 v7, 0xe0, v2                                  // 00000090A704: 380E04FF 000000E0
	s_clause 0x8                                               // 00000090A70C: BF850008
	global_load_d16_b16 v2, v28, s[4:5]                        // 00000090A710: DC820000 0204001C
	global_load_d16_hi_b16 v2, v28, s[4:5] offset:128          // 00000090A718: DC8E0080 0204001C
	global_load_d16_b16 v3, v28, s[4:5] offset:64              // 00000090A720: DC820040 0304001C
	global_load_d16_hi_b16 v3, v28, s[8:9] offset:128          // 00000090A728: DC8E0080 0308001C
	global_load_d16_b16 v8, v28, s[8:9] offset:192             // 00000090A730: DC8200C0 0808001C
	global_load_d16_b16 v9, v28, s[8:9] offset:1408            // 00000090A738: DC820580 0908001C
	global_load_d16_b16 v10, v28, s[8:9] offset:1472           // 00000090A740: DC8205C0 0A08001C
	global_load_d16_b16 v18, v28, s[8:9] offset:64             // 00000090A748: DC820040 1208001C
	global_load_d16_b16 v11, v28, s[4:5] offset:192            // 00000090A750: DC8200C0 0B04001C
	s_clause 0x3                                               // 00000090A758: BF850003
	global_load_d16_b16 v12, v6, s[8:9]                        // 00000090A75C: DC820000 0C080006
	global_load_d16_b16 v13, v7, s[8:9]                        // 00000090A764: DC820000 0D080007
	global_load_d16_b16 v14, v6, s[8:9] offset:1280            // 00000090A76C: DC820500 0E080006
	global_load_d16_b16 v15, v7, s[8:9] offset:1280            // 00000090A774: DC820500 0F080007
	s_clause 0x1                                               // 00000090A77C: BF850001
	global_load_d16_b16 v16, v6, s[4:5]                        // 00000090A780: DC820000 10040006
	global_load_d16_b16 v17, v7, s[4:5]                        // 00000090A788: DC820000 11040007
	s_clause 0x6                                               // 00000090A790: BF850006
	global_load_d16_b16 v19, v28, s[8:9]                       // 00000090A794: DC820000 1308001C
	global_load_d16_b16 v20, v5, s[8:9]                        // 00000090A79C: DC820000 14080005
	global_load_d16_b16 v21, v4, s[8:9]                        // 00000090A7A4: DC820000 15080004
	global_load_d16_b16 v22, v28, s[8:9] offset:1344           // 00000090A7AC: DC820540 1608001C
	global_load_d16_b16 v23, v28, s[8:9] offset:1280           // 00000090A7B4: DC820500 1708001C
	global_load_d16_b16 v24, v5, s[8:9] offset:1280            // 00000090A7BC: DC820500 18080005
	global_load_d16_b16 v25, v4, s[8:9] offset:1280            // 00000090A7C4: DC820500 19080004
	s_clause 0x1                                               // 00000090A7CC: BF850001
	global_load_d16_b16 v26, v5, s[4:5]                        // 00000090A7D0: DC820000 1A040005
	global_load_d16_b16 v27, v4, s[4:5]                        // 00000090A7D8: DC820000 1B040004
	v_and_b32_e32 v4, 1, v0                                    // 00000090A7E0: 36080081
	v_and_b32_e32 v5, 2, v0                                    // 00000090A7E4: 360A0082
	v_and_b32_e32 v6, 4, v0                                    // 00000090A7E8: 360C0084
	v_and_b32_e32 v0, 8, v0                                    // 00000090A7EC: 36000088
	s_mul_i32 s9, s10, 0xa000                                  // 00000090A7F0: 9609FF0A 0000A000
	s_lshl_b64 s[6:7], s[6:7], 13                              // 00000090A7F8: 84868D06
	s_mul_hi_i32 s8, s10, 0xa000                               // 00000090A7FC: 9708FF0A 0000A000
	s_add_u32 s6, s9, s6                                       // 00000090A804: 80060609
	.long 0xd44a0005                                           // 00000090A808: D44A0005
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000090A80C: 02020080
	v_lshlrev_b32_e32 v0, 2, v1                                // 00000090A810: 30000282
	s_addc_u32 s7, s8, s7                                      // 00000090A814: 82070708
	s_add_u32 s6, s20, s6                                      // 00000090A818: 80060614
	s_mul_hi_i32 s11, s10, 0x500                               // 00000090A81C: 970BFF0A 00000500
	s_mulk_i32 s10, 0x500                                      // 00000090A824: B80A0500
	s_addc_u32 s7, s21, s7                                     // 00000090A828: 82070715
	.long 0xd7000600                                           // 00000090A82C: D7000600
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 00000090A830: 02020006
	s_add_u32 s8, s10, s12                                     // 00000090A834: 80080C0A
	v_add_co_ci_u32_e64 v1, null, s7, 0, s6                    // 00000090A838: D5207C01 00190007
	s_addc_u32 s6, s11, s13                                    // 00000090A840: 82060D0B
	s_add_u32 s7, s18, s8                                      // 00000090A844: 80070812
	.long 0xd44a0001                                           // 00000090A848: D44A0001
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 00000090A84C: 02020880
	.long 0xd44a0004                                           // 00000090A850: D44A0004
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 00000090A854: 02020C80
	s_addc_u32 s6, s19, s6                                     // 00000090A858: 82060613
	.long 0xd7006a00                                           // 00000090A85C: D7006A00
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 00000090A860: 020200FF 00001000
	.long 0xd44a0003                                           // 00000090A868: D44A0003
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 00000090A86C: 02020A80
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000090A870: D5207C01 01AA0280
	s_mov_b32 s9, 0x3db504f3                                   // 00000090A878: BE8900FF 3DB504F3
	s_waitcnt vmcnt(22)                                        // 00000090A880: BF895BF7
	v_cvt_f32_f16_e32 v6, v2                                   // 00000090A884: 7E0C1702
	v_cvt_f32_f16_e32 v4, v130/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000090A888: 7E081782
	.long 0xd7000702                                           // 00000090A88C: D7000702
	v_cndmask_b32_e32 v1, s7, v28, vcc_lo                      // 00000090A890: 02023807
	s_waitcnt vmcnt(20)                                        // 00000090A894: BF8953F7
	v_cvt_f32_f16_e32 v5, v3                                   // 00000090A898: 7E0A1703
	v_cvt_f32_f16_e32 v7, v131/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000090A89C: 7E0E1783
	s_waitcnt vmcnt(19)                                        // 00000090A8A0: BF894FF7
	v_cvt_f32_f16_e32 v8, v8                                   // 00000090A8A4: 7E101708
	s_waitcnt vmcnt(18)                                        // 00000090A8A8: BF894BF7
	v_cvt_f32_f16_e32 v9, v9                                   // 00000090A8AC: 7E121709
	s_waitcnt vmcnt(17)                                        // 00000090A8B0: BF8947F7
	v_cvt_f32_f16_e32 v10, v10                                 // 00000090A8B4: 7E14170A
	s_waitcnt vmcnt(15)                                        // 00000090A8B8: BF893FF7
	v_cvt_f32_f16_e32 v11, v11                                 // 00000090A8BC: 7E16170B
	s_waitcnt vmcnt(14)                                        // 00000090A8C0: BF893BF7
	v_cvt_f32_f16_e32 v12, v12                                 // 00000090A8C4: 7E18170C
	s_waitcnt vmcnt(13)                                        // 00000090A8C8: BF8937F7
	v_cvt_f32_f16_e32 v13, v13                                 // 00000090A8CC: 7E1A170D
	s_waitcnt vmcnt(12)                                        // 00000090A8D0: BF8933F7
	v_cvt_f32_f16_e32 v14, v14                                 // 00000090A8D4: 7E1C170E
	s_waitcnt vmcnt(11)                                        // 00000090A8D8: BF892FF7
	v_cvt_f32_f16_e32 v15, v15                                 // 00000090A8DC: 7E1E170F
	s_waitcnt vmcnt(10)                                        // 00000090A8E0: BF892BF7
	v_cvt_f32_f16_e32 v16, v16                                 // 00000090A8E4: 7E201710
	s_waitcnt vmcnt(9)                                         // 00000090A8E8: BF8927F7
	v_cvt_f32_f16_e32 v17, v17                                 // 00000090A8EC: 7E221711
	v_cvt_f32_f16_e32 v18, v18                                 // 00000090A8F0: 7E241712
	s_waitcnt vmcnt(8)                                         // 00000090A8F4: BF8923F7
	v_cvt_f32_f16_e32 v19, v19                                 // 00000090A8F8: 7E261713
	s_waitcnt vmcnt(7)                                         // 00000090A8FC: BF891FF7
	v_cvt_f32_f16_e32 v20, v20                                 // 00000090A900: 7E281714
	s_waitcnt vmcnt(6)                                         // 00000090A904: BF891BF7
	v_cvt_f32_f16_e32 v21, v21                                 // 00000090A908: 7E2A1715
	s_waitcnt vmcnt(5)                                         // 00000090A90C: BF8917F7
	v_cvt_f32_f16_e32 v22, v22                                 // 00000090A910: 7E2C1716
	s_waitcnt vmcnt(4)                                         // 00000090A914: BF8913F7
	v_cvt_f32_f16_e32 v23, v23                                 // 00000090A918: 7E2E1717
	s_waitcnt vmcnt(3)                                         // 00000090A91C: BF890FF7
	v_cvt_f32_f16_e32 v24, v24                                 // 00000090A920: 7E301718
	s_waitcnt vmcnt(2)                                         // 00000090A924: BF890BF7
	v_cvt_f32_f16_e32 v25, v25                                 // 00000090A928: 7E321719
	s_waitcnt vmcnt(1)                                         // 00000090A92C: BF8907F7
	v_cvt_f32_f16_e32 v26, v26                                 // 00000090A930: 7E34171A
	s_waitcnt vmcnt(0)                                         // 00000090A934: BF8903F7
	v_cvt_f32_f16_e32 v27, v27                                 // 00000090A938: 7E36171B
	v_add_co_ci_u32_e64 v3, null, s6, 0, s7                    // 00000090A93C: D5207C03 001D0006
	s_branch 16                                                // 00000090A944: BFA00010 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x3388>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000090A948: 8C7E067E
	.long 0xd7006a00                                           // 00000090A94C: D7006A00
	v_cndmask_b32_e32 v1, 0xa000, v0, vcc_lo                   // 00000090A950: 020200FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000090A958: BF8700A1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000090A95C: D5207C01 01AA0280
	.long 0xd7006a02                                           // 00000090A964: D7006A02
	v_cndmask_b32_e32 v1, 0x500, v2, vcc_lo                    // 00000090A968: 020204FF 00000500
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000090A970: D5207C03 01AA0680
	s_add_i32 s26, s26, -1                                     // 00000090A978: 811AC11A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000090A97C: BF870009
	s_cmp_eq_u32 s26, 0                                        // 00000090A980: BF06801A
	s_cbranch_scc1 1343                                        // 00000090A984: BFA2053F <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x4884>
	s_clause 0x1f                                              // 00000090A988: BF85001F
	global_load_b32 v28, v[0:1], off offset:-4096 glc          // 00000090A98C: DC525000 1C7C0000
	global_load_b32 v29, v[0:1], off offset:-3584 glc          // 00000090A994: DC525200 1D7C0000
	global_load_b32 v30, v[0:1], off offset:-3072 glc          // 00000090A99C: DC525400 1E7C0000
	global_load_b32 v31, v[0:1], off offset:-2560 glc          // 00000090A9A4: DC525600 1F7C0000
	global_load_b32 v32, v[0:1], off offset:-2048 glc          // 00000090A9AC: DC525800 207C0000
	global_load_b32 v33, v[0:1], off offset:-1536 glc          // 00000090A9B4: DC525A00 217C0000
	global_load_b32 v34, v[0:1], off offset:-1024 glc          // 00000090A9BC: DC525C00 227C0000
	global_load_b32 v35, v[0:1], off offset:-512 glc           // 00000090A9C4: DC525E00 237C0000
	global_load_b32 v36, v[0:1], off glc                       // 00000090A9CC: DC524000 247C0000
	global_load_b32 v37, v[0:1], off offset:512 glc            // 00000090A9D4: DC524200 257C0000
	global_load_b32 v38, v[0:1], off offset:1024 glc           // 00000090A9DC: DC524400 267C0000
	global_load_b32 v39, v[0:1], off offset:1536 glc           // 00000090A9E4: DC524600 277C0000
	global_load_b32 v40, v[0:1], off offset:2048 glc           // 00000090A9EC: DC524800 287C0000
	global_load_b32 v41, v[0:1], off offset:2560 glc           // 00000090A9F4: DC524A00 297C0000
	global_load_b32 v42, v[0:1], off offset:3072 glc           // 00000090A9FC: DC524C00 2A7C0000
	global_load_b32 v43, v[0:1], off offset:3584 glc           // 00000090AA04: DC524E00 2B7C0000
	global_load_b32 v44, v[0:1], off offset:-4032 glc          // 00000090AA0C: DC525040 2C7C0000
	global_load_b32 v45, v[0:1], off offset:-3520 glc          // 00000090AA14: DC525240 2D7C0000
	global_load_b32 v46, v[0:1], off offset:-3008 glc          // 00000090AA1C: DC525440 2E7C0000
	global_load_b32 v47, v[0:1], off offset:-2496 glc          // 00000090AA24: DC525640 2F7C0000
	global_load_b32 v48, v[0:1], off offset:-1984 glc          // 00000090AA2C: DC525840 307C0000
	global_load_b32 v49, v[0:1], off offset:-1472 glc          // 00000090AA34: DC525A40 317C0000
	global_load_b32 v50, v[0:1], off offset:-960 glc           // 00000090AA3C: DC525C40 327C0000
	global_load_b32 v51, v[0:1], off offset:-448 glc           // 00000090AA44: DC525E40 337C0000
	global_load_b32 v52, v[0:1], off offset:64 glc             // 00000090AA4C: DC524040 347C0000
	global_load_b32 v53, v[0:1], off offset:576 glc            // 00000090AA54: DC524240 357C0000
	global_load_b32 v54, v[0:1], off offset:1088 glc           // 00000090AA5C: DC524440 367C0000
	global_load_b32 v55, v[0:1], off offset:1600 glc           // 00000090AA64: DC524640 377C0000
	global_load_b32 v56, v[0:1], off offset:2112 glc           // 00000090AA6C: DC524840 387C0000
	global_load_b32 v57, v[0:1], off offset:2624 glc           // 00000090AA74: DC524A40 397C0000
	global_load_b32 v58, v[0:1], off offset:3136 glc           // 00000090AA7C: DC524C40 3A7C0000
	global_load_b32 v59, v[0:1], off offset:3648 glc           // 00000090AA84: DC524E40 3B7C0000
	s_clause 0x1f                                              // 00000090AA8C: BF85001F
	global_load_b32 v60, v[0:1], off offset:-3968 glc          // 00000090AA90: DC525080 3C7C0000
	global_load_b32 v61, v[0:1], off offset:-3456 glc          // 00000090AA98: DC525280 3D7C0000
	global_load_b32 v62, v[0:1], off offset:-2944 glc          // 00000090AAA0: DC525480 3E7C0000
	global_load_b32 v63, v[0:1], off offset:-2432 glc          // 00000090AAA8: DC525680 3F7C0000
	global_load_b32 v64, v[0:1], off offset:-1920 glc          // 00000090AAB0: DC525880 407C0000
	global_load_b32 v65, v[0:1], off offset:-1408 glc          // 00000090AAB8: DC525A80 417C0000
	global_load_b32 v66, v[0:1], off offset:-896 glc           // 00000090AAC0: DC525C80 427C0000
	global_load_b32 v67, v[0:1], off offset:-384 glc           // 00000090AAC8: DC525E80 437C0000
	global_load_b32 v68, v[0:1], off offset:128 glc            // 00000090AAD0: DC524080 447C0000
	global_load_b32 v69, v[0:1], off offset:640 glc            // 00000090AAD8: DC524280 457C0000
	global_load_b32 v70, v[0:1], off offset:1152 glc           // 00000090AAE0: DC524480 467C0000
	global_load_b32 v71, v[0:1], off offset:1664 glc           // 00000090AAE8: DC524680 477C0000
	global_load_b32 v72, v[0:1], off offset:2176 glc           // 00000090AAF0: DC524880 487C0000
	global_load_b32 v73, v[0:1], off offset:2688 glc           // 00000090AAF8: DC524A80 497C0000
	global_load_b32 v74, v[0:1], off offset:3200 glc           // 00000090AB00: DC524C80 4A7C0000
	global_load_b32 v75, v[0:1], off offset:3712 glc           // 00000090AB08: DC524E80 4B7C0000
	global_load_b32 v76, v[0:1], off offset:-3904 glc          // 00000090AB10: DC5250C0 4C7C0000
	global_load_b32 v77, v[0:1], off offset:-3392 glc          // 00000090AB18: DC5252C0 4D7C0000
	global_load_b32 v78, v[0:1], off offset:-2880 glc          // 00000090AB20: DC5254C0 4E7C0000
	global_load_b32 v79, v[0:1], off offset:-2368 glc          // 00000090AB28: DC5256C0 4F7C0000
	global_load_b32 v80, v[0:1], off offset:-1856 glc          // 00000090AB30: DC5258C0 507C0000
	global_load_b32 v81, v[0:1], off offset:-1344 glc          // 00000090AB38: DC525AC0 517C0000
	global_load_b32 v82, v[0:1], off offset:-832 glc           // 00000090AB40: DC525CC0 527C0000
	global_load_b32 v83, v[0:1], off offset:-320 glc           // 00000090AB48: DC525EC0 537C0000
	global_load_b32 v84, v[0:1], off offset:192 glc            // 00000090AB50: DC5240C0 547C0000
	global_load_b32 v85, v[0:1], off offset:704 glc            // 00000090AB58: DC5242C0 557C0000
	global_load_b32 v86, v[0:1], off offset:1216 glc           // 00000090AB60: DC5244C0 567C0000
	global_load_b32 v87, v[0:1], off offset:1728 glc           // 00000090AB68: DC5246C0 577C0000
	global_load_b32 v88, v[0:1], off offset:2240 glc           // 00000090AB70: DC5248C0 587C0000
	global_load_b32 v89, v[0:1], off offset:2752 glc           // 00000090AB78: DC524AC0 597C0000
	global_load_b32 v90, v[0:1], off offset:3264 glc           // 00000090AB80: DC524CC0 5A7C0000
	global_load_b32 v91, v[0:1], off offset:3776 glc           // 00000090AB88: DC524EC0 5B7C0000
	s_clause 0x1f                                              // 00000090AB90: BF85001F
	global_load_b32 v92, v[0:1], off offset:-3840 glc          // 00000090AB94: DC525100 5C7C0000
	global_load_b32 v93, v[0:1], off offset:-3328 glc          // 00000090AB9C: DC525300 5D7C0000
	global_load_b32 v94, v[0:1], off offset:-2816 glc          // 00000090ABA4: DC525500 5E7C0000
	global_load_b32 v95, v[0:1], off offset:-2304 glc          // 00000090ABAC: DC525700 5F7C0000
	global_load_b32 v96, v[0:1], off offset:-1792 glc          // 00000090ABB4: DC525900 607C0000
	global_load_b32 v97, v[0:1], off offset:-1280 glc          // 00000090ABBC: DC525B00 617C0000
	global_load_b32 v98, v[0:1], off offset:-768 glc           // 00000090ABC4: DC525D00 627C0000
	global_load_b32 v99, v[0:1], off offset:-256 glc           // 00000090ABCC: DC525F00 637C0000
	global_load_b32 v100, v[0:1], off offset:256 glc           // 00000090ABD4: DC524100 647C0000
	global_load_b32 v101, v[0:1], off offset:768 glc           // 00000090ABDC: DC524300 657C0000
	global_load_b32 v102, v[0:1], off offset:1280 glc          // 00000090ABE4: DC524500 667C0000
	global_load_b32 v103, v[0:1], off offset:1792 glc          // 00000090ABEC: DC524700 677C0000
	global_load_b32 v104, v[0:1], off offset:2304 glc          // 00000090ABF4: DC524900 687C0000
	global_load_b32 v105, v[0:1], off offset:2816 glc          // 00000090ABFC: DC524B00 697C0000
	global_load_b32 v106, v[0:1], off offset:3328 glc          // 00000090AC04: DC524D00 6A7C0000
	global_load_b32 v107, v[0:1], off offset:3840 glc          // 00000090AC0C: DC524F00 6B7C0000
	global_load_b32 v108, v[0:1], off offset:-3776 glc         // 00000090AC14: DC525140 6C7C0000
	global_load_b32 v109, v[0:1], off offset:-3264 glc         // 00000090AC1C: DC525340 6D7C0000
	global_load_b32 v110, v[0:1], off offset:-2752 glc         // 00000090AC24: DC525540 6E7C0000
	global_load_b32 v111, v[0:1], off offset:-2240 glc         // 00000090AC2C: DC525740 6F7C0000
	global_load_b32 v112, v[0:1], off offset:-1728 glc         // 00000090AC34: DC525940 707C0000
	global_load_b32 v113, v[0:1], off offset:-1216 glc         // 00000090AC3C: DC525B40 717C0000
	global_load_b32 v114, v[0:1], off offset:-704 glc          // 00000090AC44: DC525D40 727C0000
	global_load_b32 v115, v[0:1], off offset:-192 glc          // 00000090AC4C: DC525F40 737C0000
	global_load_b32 v116, v[0:1], off offset:320 glc           // 00000090AC54: DC524140 747C0000
	global_load_b32 v117, v[0:1], off offset:832 glc           // 00000090AC5C: DC524340 757C0000
	global_load_b32 v118, v[0:1], off offset:1344 glc          // 00000090AC64: DC524540 767C0000
	global_load_b32 v119, v[0:1], off offset:1856 glc          // 00000090AC6C: DC524740 777C0000
	global_load_b32 v120, v[0:1], off offset:2368 glc          // 00000090AC74: DC524940 787C0000
	global_load_b32 v121, v[0:1], off offset:2880 glc          // 00000090AC7C: DC524B40 797C0000
	global_load_b32 v122, v[0:1], off offset:3392 glc          // 00000090AC84: DC524D40 7A7C0000
	global_load_b32 v123, v[0:1], off offset:3904 glc          // 00000090AC8C: DC524F40 7B7C0000
	s_clause 0x1f                                              // 00000090AC94: BF85001F
	global_load_b32 v124, v[0:1], off offset:-3712 glc         // 00000090AC98: DC525180 7C7C0000
	global_load_b32 v125, v[0:1], off offset:-3200 glc         // 00000090ACA0: DC525380 7D7C0000
	global_load_b32 v126, v[0:1], off offset:-2688 glc         // 00000090ACA8: DC525580 7E7C0000
	global_load_b32 v127, v[0:1], off offset:-2176 glc         // 00000090ACB0: DC525780 7F7C0000
	global_load_b32 v128, v[0:1], off offset:-1664 glc         // 00000090ACB8: DC525980 807C0000
	global_load_b32 v129, v[0:1], off offset:-1152 glc         // 00000090ACC0: DC525B80 817C0000
	global_load_b32 v130, v[0:1], off offset:-640 glc          // 00000090ACC8: DC525D80 827C0000
	global_load_b32 v131, v[0:1], off offset:-128 glc          // 00000090ACD0: DC525F80 837C0000
	global_load_b32 v132, v[0:1], off offset:384 glc           // 00000090ACD8: DC524180 847C0000
	global_load_b32 v133, v[0:1], off offset:896 glc           // 00000090ACE0: DC524380 857C0000
	global_load_b32 v134, v[0:1], off offset:1408 glc          // 00000090ACE8: DC524580 867C0000
	global_load_b32 v135, v[0:1], off offset:1920 glc          // 00000090ACF0: DC524780 877C0000
	global_load_b32 v136, v[0:1], off offset:2432 glc          // 00000090ACF8: DC524980 887C0000
	global_load_b32 v137, v[0:1], off offset:2944 glc          // 00000090AD00: DC524B80 897C0000
	global_load_b32 v138, v[0:1], off offset:3456 glc          // 00000090AD08: DC524D80 8A7C0000
	global_load_b32 v139, v[0:1], off offset:3968 glc          // 00000090AD10: DC524F80 8B7C0000
	global_load_b32 v140, v[0:1], off offset:-3648 glc         // 00000090AD18: DC5251C0 8C7C0000
	global_load_b32 v141, v[0:1], off offset:-3136 glc         // 00000090AD20: DC5253C0 8D7C0000
	global_load_b32 v142, v[0:1], off offset:-2624 glc         // 00000090AD28: DC5255C0 8E7C0000
	global_load_b32 v143, v[0:1], off offset:-2112 glc         // 00000090AD30: DC5257C0 8F7C0000
	global_load_b32 v144, v[0:1], off offset:-1600 glc         // 00000090AD38: DC5259C0 907C0000
	global_load_b32 v145, v[0:1], off offset:-1088 glc         // 00000090AD40: DC525BC0 917C0000
	global_load_b32 v146, v[0:1], off offset:-576 glc          // 00000090AD48: DC525DC0 927C0000
	global_load_b32 v147, v[0:1], off offset:-64 glc           // 00000090AD50: DC525FC0 937C0000
	global_load_b32 v148, v[0:1], off offset:448 glc           // 00000090AD58: DC5241C0 947C0000
	global_load_b32 v149, v[0:1], off offset:960 glc           // 00000090AD60: DC5243C0 957C0000
	global_load_b32 v150, v[0:1], off offset:1472 glc          // 00000090AD68: DC5245C0 967C0000
	global_load_b32 v151, v[0:1], off offset:1984 glc          // 00000090AD70: DC5247C0 977C0000
	global_load_b32 v152, v[0:1], off offset:2496 glc          // 00000090AD78: DC5249C0 987C0000
	global_load_b32 v153, v[0:1], off offset:3008 glc          // 00000090AD80: DC524BC0 997C0000
	global_load_b32 v154, v[0:1], off offset:3520 glc          // 00000090AD88: DC524DC0 9A7C0000
	global_load_b32 v155, v[0:1], off offset:4032 glc          // 00000090AD90: DC524FC0 9B7C0000
	s_waitcnt vmcnt(62)                                        // 00000090AD98: BF89FBF7
	v_dual_add_f32 v28, 0, v28 :: v_dual_add_f32 v29, 0, v29   // 00000090AD9C: C9083880 1C1C3A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000090ADA4: BF870091
	v_dual_add_f32 v28, v28, v30 :: v_dual_add_f32 v29, v29, v31// 00000090ADA8: C9083D1C 1C1C3F1D
	v_dual_add_f32 v28, v28, v32 :: v_dual_add_f32 v29, v29, v33// 00000090ADB0: C908411C 1C1C431D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000090ADB8: BF870121
	v_dual_add_f32 v28, v28, v34 :: v_dual_add_f32 v29, v29, v35// 00000090ADBC: C908451C 1C1C471D
	v_dual_add_f32 v44, 0, v44 :: v_dual_add_f32 v45, 0, v45   // 00000090ADC4: C9085880 2C2C5A80
	v_dual_add_f32 v28, v28, v36 :: v_dual_add_f32 v29, v29, v37// 00000090ADCC: C908491C 1C1C4B1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000090ADD4: BF870112
	v_dual_add_f32 v30, v44, v46 :: v_dual_add_f32 v31, v45, v47// 00000090ADD8: C9085D2C 1E1E5F2D
	v_dual_add_f32 v28, v28, v38 :: v_dual_add_f32 v29, v29, v39// 00000090ADE0: C9084D1C 1C1C4F1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000090ADE8: BF870112
	v_dual_add_f32 v30, v30, v48 :: v_dual_add_f32 v31, v31, v49// 00000090ADEC: C908611E 1E1E631F
	v_dual_add_f32 v28, v28, v40 :: v_dual_add_f32 v29, v29, v41// 00000090ADF4: C908511C 1C1C531D
	v_dual_add_f32 v60, 0, v60 :: v_dual_add_f32 v61, 0, v61   // 00000090ADFC: C9087880 3C3C7A80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090AE04: BF870193
	v_dual_add_f32 v30, v30, v50 :: v_dual_add_f32 v31, v31, v51// 00000090AE08: C908651E 1E1E671F
	v_dual_add_f32 v28, v28, v42 :: v_dual_add_f32 v29, v29, v43// 00000090AE10: C908551C 1C1C571D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090AE18: BF870193
	v_dual_add_f32 v44, v60, v62 :: v_dual_add_f32 v45, v61, v63// 00000090AE1C: C9087D3C 2C2C7F3D
	v_dual_add_f32 v30, v30, v52 :: v_dual_add_f32 v31, v31, v53// 00000090AE24: C908691E 1E1E6B1F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000090AE2C: BF870112
	v_dual_add_f32 v32, v44, v64 :: v_dual_add_f32 v33, v45, v65// 00000090AE30: C908812C 2020832D
	v_dual_add_f32 v30, v30, v54 :: v_dual_add_f32 v31, v31, v55// 00000090AE38: C9086D1E 1E1E6F1F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000090AE40: BF8701A2
	v_dual_add_f32 v32, v32, v66 :: v_dual_add_f32 v33, v33, v67// 00000090AE44: C9088520 20208721
	v_dual_add_f32 v76, 0, v76 :: v_dual_add_f32 v77, 0, v77   // 00000090AE4C: C9089880 4C4C9A80
	v_dual_add_f32 v30, v30, v56 :: v_dual_add_f32 v31, v31, v57// 00000090AE54: C908711E 1E1E731F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090AE5C: BF870193
	v_dual_add_f32 v32, v32, v68 :: v_dual_add_f32 v33, v33, v69// 00000090AE60: C9088920 20208B21
	v_dual_add_f32 v46, v76, v78 :: v_dual_add_f32 v47, v77, v79// 00000090AE68: C9089D4C 2E2E9F4D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090AE70: BF870193
	v_dual_add_f32 v30, v30, v58 :: v_dual_add_f32 v31, v31, v59// 00000090AE74: C908751E 1E1E771F
	v_dual_add_f32 v32, v32, v70 :: v_dual_add_f32 v33, v33, v71// 00000090AE7C: C9088D20 20208F21
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000090AE84: BF8701A3
	v_dual_add_f32 v44, v46, v80 :: v_dual_add_f32 v45, v47, v81// 00000090AE88: C908A12E 2C2CA32F
	v_dual_add_f32 v92, 0, v92 :: v_dual_add_f32 v93, 0, v93   // 00000090AE90: C908B880 5C5CBA80
	v_dual_add_f32 v32, v32, v72 :: v_dual_add_f32 v33, v33, v73// 00000090AE98: C9089120 20209321
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000090AEA0: BF8701A3
	v_dual_add_f32 v34, v44, v82 :: v_dual_add_f32 v35, v45, v83// 00000090AEA4: C908A52C 2222A72D
	s_waitcnt vmcnt(60)                                        // 00000090AEAC: BF89F3F7
	v_dual_add_f32 v60, v92, v94 :: v_dual_add_f32 v61, v93, v95// 00000090AEB0: C908BD5C 3C3CBF5D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090AEB8: BF870193
	v_dual_add_f32 v32, v32, v74 :: v_dual_add_f32 v33, v33, v75// 00000090AEBC: C9089520 20209721
	v_dual_add_f32 v34, v34, v84 :: v_dual_add_f32 v35, v35, v85// 00000090AEC4: C908A922 2222AB23
	s_waitcnt vmcnt(58)                                        // 00000090AECC: BF89EBF7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000090AED0: BF870113
	v_dual_add_f32 v46, v60, v96 :: v_dual_add_f32 v47, v61, v97// 00000090AED4: C908C13C 2E2EC33D
	v_dual_add_f32 v34, v34, v86 :: v_dual_add_f32 v35, v35, v87// 00000090AEDC: C908AD22 2222AF23
	s_waitcnt vmcnt(46)                                        // 00000090AEE4: BF89BBF7
	v_dual_add_f32 v108, 0, v108 :: v_dual_add_f32 v109, 0, v109// 00000090AEE8: C908D880 6C6CDA80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090AEF0: BF870193
	v_dual_add_f32 v44, v46, v98 :: v_dual_add_f32 v45, v47, v99// 00000090AEF4: C908C52E 2C2CC72F
	v_dual_add_f32 v34, v34, v88 :: v_dual_add_f32 v35, v35, v89// 00000090AEFC: C908B122 2222B323
	s_waitcnt vmcnt(44)                                        // 00000090AF04: BF89B3F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090AF08: BF870193
	v_dual_add_f32 v62, v108, v110 :: v_dual_add_f32 v63, v109, v111// 00000090AF0C: C908DD6C 3E3EDF6D
	v_dual_add_f32 v36, v44, v100 :: v_dual_add_f32 v37, v45, v101// 00000090AF14: C908C92C 2424CB2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000090AF1C: BF8701A3
	v_dual_add_f32 v34, v34, v90 :: v_dual_add_f32 v35, v35, v91// 00000090AF20: C908B522 2222B723
	s_waitcnt vmcnt(42)                                        // 00000090AF28: BF89ABF7
	v_dual_add_f32 v48, v62, v112 :: v_dual_add_f32 v49, v63, v113// 00000090AF2C: C908E13E 3030E33F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000090AF34: BF8701B3
	v_dual_add_f32 v36, v36, v102 :: v_dual_add_f32 v37, v37, v103// 00000090AF38: C908CD24 2424CF25
	s_waitcnt vmcnt(30)                                        // 00000090AF40: BF897BF7
	v_dual_add_f32 v124, 0, v124 :: v_dual_add_f32 v125, 0, v125// 00000090AF44: C908F880 7C7CFA80
	v_dual_add_f32 v46, v48, v114 :: v_dual_add_f32 v47, v49, v115// 00000090AF4C: C908E530 2E2EE731
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000090AF54: BF8701A3
	v_dual_add_f32 v36, v36, v104 :: v_dual_add_f32 v37, v37, v105// 00000090AF58: C908D124 2424D325
	s_waitcnt vmcnt(28)                                        // 00000090AF60: BF8973F7
	v_dual_add_f32 v76, v124, v126 :: v_dual_add_f32 v77, v125, v127// 00000090AF64: C908FD7C 4C4CFF7D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090AF6C: BF870193
	v_dual_add_f32 v44, v46, v116 :: v_dual_add_f32 v45, v47, v117// 00000090AF70: C908E92E 2C2CEB2F
	v_dual_add_f32 v36, v36, v106 :: v_dual_add_f32 v37, v37, v107// 00000090AF78: C908D524 2424D725
	s_waitcnt vmcnt(26)                                        // 00000090AF80: BF896BF7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090AF84: BF870193
	v_dual_add_f32 v60, v76, v128 :: v_dual_add_f32 v61, v77, v129// 00000090AF88: C909014C 3C3D034D
	v_dual_add_f32 v38, v44, v118 :: v_dual_add_f32 v39, v45, v119// 00000090AF90: C908ED2C 2626EF2D
	s_waitcnt vmcnt(14)                                        // 00000090AF98: BF893BF7
	v_dual_add_f32 v140, 0, v140 :: v_dual_add_f32 v141, 0, v141// 00000090AF9C: C9091880 8C8D1A80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090AFA4: BF870193
	v_dual_add_f32 v48, v60, v130 :: v_dual_add_f32 v49, v61, v131// 00000090AFA8: C909053C 3031073D
	v_dual_add_f32 v38, v38, v120 :: v_dual_add_f32 v39, v39, v121// 00000090AFB0: C908F126 2626F327
	s_waitcnt vmcnt(12)                                        // 00000090AFB8: BF8933F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090AFBC: BF870193
	v_dual_add_f32 v78, v140, v142 :: v_dual_add_f32 v79, v141, v143// 00000090AFC0: C9091D8C 4E4F1F8D
	v_dual_add_f32 v46, v48, v132 :: v_dual_add_f32 v47, v49, v133// 00000090AFC8: C9090930 2E2F0B31
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000090AFD0: BF8701A3
	v_dual_add_f32 v38, v38, v122 :: v_dual_add_f32 v39, v39, v123// 00000090AFD4: C908F526 2626F727
	s_waitcnt vmcnt(10)                                        // 00000090AFDC: BF892BF7
	v_dual_add_f32 v62, v78, v144 :: v_dual_add_f32 v63, v79, v145// 00000090AFE0: C909214E 3E3F234F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000090AFE8: BF870123
	v_dual_add_f32 v44, v46, v134 :: v_dual_add_f32 v45, v47, v135// 00000090AFEC: C9090D2E 2C2D0F2F
	s_waitcnt vmcnt(8)                                         // 00000090AFF4: BF8923F7
	v_dual_add_f32 v50, v62, v146 :: v_dual_add_f32 v51, v63, v147// 00000090AFF8: C909253E 3233273F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000090B000: BF870122
	v_dual_add_f32 v40, v44, v136 :: v_dual_add_f32 v41, v45, v137// 00000090B004: C909112C 2829132D
	s_waitcnt vmcnt(6)                                         // 00000090B00C: BF891BF7
	v_dual_add_f32 v48, v50, v148 :: v_dual_add_f32 v49, v51, v149// 00000090B010: C9092932 30312B33
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000090B018: BF870122
	v_dual_add_f32 v40, v40, v138 :: v_dual_add_f32 v41, v41, v139// 00000090B01C: C9091528 28291729
	s_waitcnt vmcnt(4)                                         // 00000090B024: BF8913F7
	v_dual_add_f32 v46, v48, v150 :: v_dual_add_f32 v47, v49, v151// 00000090B028: C9092D30 2E2F2F31
	s_waitcnt vmcnt(2)                                         // 00000090B030: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000090B034: BF8700A1
	v_dual_add_f32 v44, v46, v152 :: v_dual_add_f32 v45, v47, v153// 00000090B038: C909312E 2C2D332F
	s_waitcnt vmcnt(0)                                         // 00000090B040: BF8903F7
	v_dual_add_f32 v42, v44, v154 :: v_dual_add_f32 v43, v45, v155// 00000090B044: C909352C 2A2B372D
	v_add_f32_e32 v44, v28, v30                                // 00000090B04C: 06583D1C
	v_sub_f32_e32 v28, v28, v30                                // 00000090B050: 08383D1C
	v_add_f32_e32 v30, v32, v34                                // 00000090B054: 063C4520
	v_sub_f32_e32 v32, v32, v34                                // 00000090B058: 08404520
	v_add_f32_e32 v34, v36, v38                                // 00000090B05C: 06444D24
	v_sub_f32_e32 v36, v36, v38                                // 00000090B060: 08484D24
	v_add_f32_e32 v38, v40, v42                                // 00000090B064: 064C5528
	v_sub_f32_e32 v40, v40, v42                                // 00000090B068: 08505528
	v_add_f32_e32 v42, v29, v31                                // 00000090B06C: 06543F1D
	v_sub_f32_e32 v29, v29, v31                                // 00000090B070: 083A3F1D
	v_add_f32_e32 v31, v33, v35                                // 00000090B074: 063E4721
	v_sub_f32_e32 v33, v33, v35                                // 00000090B078: 08424721
	v_add_f32_e32 v35, v37, v39                                // 00000090B07C: 06464F25
	v_sub_f32_e32 v37, v37, v39                                // 00000090B080: 084A4F25
	v_add_f32_e32 v39, v41, v43                                // 00000090B084: 064E5729
	v_sub_f32_e32 v41, v41, v43                                // 00000090B088: 08525729
	v_add_f32_e32 v43, v44, v30                                // 00000090B08C: 06563D2C
	v_sub_f32_e32 v30, v44, v30                                // 00000090B090: 083C3D2C
	v_add_f32_e32 v44, v28, v32                                // 00000090B094: 0658411C
	v_sub_f32_e32 v28, v28, v32                                // 00000090B098: 0838411C
	v_add_f32_e32 v32, v34, v38                                // 00000090B09C: 06404D22
	v_sub_f32_e32 v34, v34, v38                                // 00000090B0A0: 08444D22
	v_add_f32_e32 v38, v36, v40                                // 00000090B0A4: 064C5124
	v_sub_f32_e32 v36, v36, v40                                // 00000090B0A8: 08485124
	v_add_f32_e32 v40, v42, v31                                // 00000090B0AC: 06503F2A
	v_dual_sub_f32 v31, v42, v31 :: v_dual_add_f32 v42, v29, v33// 00000090B0B0: C9483F2A 1F2A431D
	v_sub_f32_e32 v29, v29, v33                                // 00000090B0B8: 083A431D
	v_add_f32_e32 v33, v35, v39                                // 00000090B0BC: 06424F23
	v_sub_f32_e32 v35, v35, v39                                // 00000090B0C0: 08464F23
	v_add_f32_e32 v39, v37, v41                                // 00000090B0C4: 064E5325
	v_sub_f32_e32 v37, v37, v41                                // 00000090B0C8: 084A5325
	v_add_f32_e32 v41, v43, v32                                // 00000090B0CC: 0652412B
	v_dual_sub_f32 v32, v43, v32 :: v_dual_add_f32 v43, v44, v38// 00000090B0D0: C948412B 202A4D2C
	v_sub_f32_e32 v38, v44, v38                                // 00000090B0D8: 084C4D2C
	v_add_f32_e32 v44, v30, v34                                // 00000090B0DC: 0658451E
	v_sub_f32_e32 v30, v30, v34                                // 00000090B0E0: 083C451E
	s_delay_alu instid0(VALU_DEP_4)                            // 00000090B0E4: BF870004
	v_mov_b32_dpp v45, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090B0E8: 7E5A02FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s1                       // 00000090B0F0: D501002B 2006572B
	v_add_f32_e32 v34, v28, v36                                // 00000090B0F8: 0644491C
	v_sub_f32_e32 v28, v28, v36                                // 00000090B0FC: 0838491C
	v_add_f32_e32 v36, v40, v33                                // 00000090B100: 06484328
	v_dual_sub_f32 v33, v40, v33 :: v_dual_add_f32 v40, v42, v39// 00000090B104: C9484328 21284F2A
	v_sub_f32_e32 v39, v42, v39                                // 00000090B10C: 084E4F2A
	v_mov_b32_dpp v48, v32 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090B110: 7E6002FA FF016120
	v_cndmask_b32_e64 v32, -v32, v32, s1                       // 00000090B118: D5010020 20064120
	s_delay_alu instid0(VALU_DEP_4)                            // 00000090B120: BF870004
	v_mov_b32_dpp v56, v33 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090B124: 7E7002FA FF016121
	v_cndmask_b32_e64 v33, -v33, v33, s1                       // 00000090B12C: D5010021 20064321
	v_add_f32_e32 v42, v31, v35                                // 00000090B134: 0654471F
	v_sub_f32_e32 v31, v31, v35                                // 00000090B138: 083E471F
	v_add_f32_e32 v35, v29, v37                                // 00000090B13C: 06464B1D
	v_sub_f32_e32 v29, v29, v37                                // 00000090B140: 083A4B1D
	v_mov_b32_dpp v37, v41 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090B144: 7E4A02FA FF016129
	v_cndmask_b32_e64 v41, -v41, v41, s1                       // 00000090B14C: D5010029 20065329
	v_mov_b32_dpp v58, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090B154: 7E7402FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 00000090B15C: D501001F 20063F1F
	v_mov_b32_dpp v59, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090B164: 7E7602FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s1                       // 00000090B16C: D501001D 20063B1D
	v_mov_b32_dpp v57, v39 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090B174: 7E7202FA FF016127
	v_cndmask_b32_e64 v39, -v39, v39, s1                       // 00000090B17C: D5010027 20064F27
	v_add_f32_e32 v37, v41, v37                                // 00000090B184: 064A4B29
	v_mov_b32_dpp v50, v30 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090B188: 7E6402FA FF01611E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 00000090B190: D501001E 20063D1E
	v_add_f32_e32 v41, v43, v45                                // 00000090B198: 06525B2B
	v_mov_b32_dpp v47, v34 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090B19C: 7E5E02FA FF016122
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 00000090B1A4: D5010022 20064522
	v_dual_add_f32 v32, v32, v48 :: v_dual_add_f32 v29, v29, v59// 00000090B1AC: C9086120 201C771D
	v_add_f32_e32 v31, v31, v58                                // 00000090B1B4: 063E751F
	v_add_f32_e32 v33, v33, v56                                // 00000090B1B8: 06427121
	v_mov_b32_dpp v49, v38 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090B1BC: 7E6202FA FF016126
	v_cndmask_b32_e64 v38, -v38, v38, s1                       // 00000090B1C4: D5010026 20064D26
	v_mov_b32_dpp v52, v36 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090B1CC: 7E6802FA FF016124
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 00000090B1D4: D5010024 20064924
	v_mov_b32_dpp v55, v35 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090B1DC: 7E6E02FA FF016123
	v_cndmask_b32_e64 v35, -v35, v35, s1                       // 00000090B1E4: D5010023 20064723
	v_dual_add_f32 v34, v34, v47 :: v_dual_add_f32 v39, v39, v57// 00000090B1EC: C9085F22 22267327
	v_mov_b32_dpp v56, v33 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090B1F4: 7E7002FA FF016221
	v_mov_b32_dpp v57, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090B1FC: 7E7202FA FF01621F
	v_cndmask_b32_e64 v33, -v33, v33, s3                       // 00000090B204: D5010021 200E4321
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 00000090B20C: D501001F 200E3F1F
	v_add_f32_e32 v30, v30, v50                                // 00000090B214: 063C651E
	v_mov_b32_dpp v59, v29 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090B218: 7E7602FA FF01621D
	v_cndmask_b32_e64 v29, -v29, v29, s3                       // 00000090B220: D501001D 200E3B1D
	v_dual_add_f32 v38, v38, v49 :: v_dual_add_f32 v33, v33, v56// 00000090B228: C9086326 26207121
	v_dual_add_f32 v36, v36, v52 :: v_dual_add_f32 v35, v35, v55// 00000090B230: C9086924 24226F23
	v_mov_b32_dpp v51, v28 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090B238: 7E6602FA FF01611C
	v_cndmask_b32_e64 v28, -v28, v28, s1                       // 00000090B240: D501001C 2006391C
	v_add_f32_e32 v31, v31, v57                                // 00000090B248: 063E731F
	v_mov_b32_dpp v50, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090B24C: 7E6402FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 00000090B254: D501001E 200E3D1E
	v_add_f32_e32 v29, v29, v59                                // 00000090B25C: 063A771D
	v_mov_b32_dpp v48, v32 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090B260: 7E6002FA FF016220
	v_mov_b32_dpp v49, v38 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090B268: 7E6202FA FF016226
	v_cndmask_b32_e64 v32, -v32, v32, s3                       // 00000090B270: D5010020 200E4120
	v_cndmask_b32_e64 v38, -v38, v38, s3                       // 00000090B278: D5010026 200E4D26
	v_mov_b32_dpp v58, v39 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090B280: 7E7402FA FF016227
	v_cndmask_b32_e64 v39, -v39, v39, s3                       // 00000090B288: D5010027 200E4F27
	v_add_f32_e32 v28, v28, v51                                // 00000090B290: 0638671C
	v_mov_b32_dpp v59, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090B294: 7E7602FA FF01641D
	v_cndmask_b32_e64 v29, -v29, v29, s4                       // 00000090B29C: D501001D 20123B1D
	v_add_f32_e32 v30, v30, v50                                // 00000090B2A4: 063C651E
	v_mov_b32_dpp v50, v33 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090B2A8: 7E6402FA FF016421
	v_cndmask_b32_e64 v33, -v33, v33, s4                       // 00000090B2B0: D5010021 20124321
	v_add_f32_e32 v32, v32, v48                                // 00000090B2B8: 06406120
	v_dual_add_f32 v38, v38, v49 :: v_dual_add_f32 v39, v39, v58// 00000090B2BC: C9086326 26267527
	v_mov_b32_dpp v51, v28 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090B2C4: 7E6602FA FF01621C
	v_cndmask_b32_e64 v28, -v28, v28, s3                       // 00000090B2CC: D501001C 200E391C
	v_add_f32_e32 v33, v33, v50                                // 00000090B2D4: 06426521
	v_add_f32_e32 v29, v29, v59                                // 00000090B2D8: 063A771D
	v_mov_b32_dpp v49, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090B2DC: 7E6202FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s4                       // 00000090B2E4: D501001E 20123D1E
	v_mov_b32_dpp v48, v32 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090B2EC: 7E6002FA FF016420
	v_cndmask_b32_e64 v32, -v32, v32, s4                       // 00000090B2F4: D5010020 20124120
	v_mov_b32_dpp v56, v38 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090B2FC: 7E7002FA FF016426
	v_cndmask_b32_e64 v38, -v38, v38, s4                       // 00000090B304: D5010026 20124D26
	v_mov_b32_dpp v58, v39 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090B30C: 7E7402FA FF016427
	v_cndmask_b32_e64 v39, -v39, v39, s4                       // 00000090B314: D5010027 20124F27
	v_add_f32_e32 v28, v28, v51                                // 00000090B31C: 0638671C
	v_mov_b32_dpp v50, v33 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090B320: 7E6402FA FF016821
	v_cndmask_b32_e64 v33, -v33, v33, s5                       // 00000090B328: D5010021 20164321
	v_add_f32_e32 v30, v30, v49                                // 00000090B330: 063C631E
	v_mov_b32_dpp v54, v42 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090B334: 7E6C02FA FF01612A
	v_cndmask_b32_e64 v42, -v42, v42, s1                       // 00000090B33C: D501002A 2006552A
	v_mov_b32_dpp v51, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090B344: 7E6602FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 00000090B34C: D501001F 20123F1F
	v_add_f32_e32 v32, v32, v48                                // 00000090B354: 06406120
	v_dual_add_f32 v38, v38, v56 :: v_dual_add_f32 v39, v39, v58// 00000090B358: C9087126 26267527
	v_mov_b32_dpp v48, v28 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090B360: 7E6002FA FF01641C
	v_cndmask_b32_e64 v28, -v28, v28, s4                       // 00000090B368: D501001C 2012391C
	v_add_f32_e32 v33, v33, v50                                // 00000090B370: 06426521
	v_mov_b32_dpp v57, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090B374: 7E7202FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s5                       // 00000090B37C: D501001E 20163D1E
	v_dual_add_f32 v42, v42, v54 :: v_dual_add_f32 v31, v31, v51// 00000090B384: C9086D2A 2A1E671F
	v_add_f32_e32 v28, v28, v48                                // 00000090B38C: 0638611C
	v_mov_b32_dpp v48, v38 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090B390: 7E6002FA FF016826
	v_cndmask_b32_e64 v38, -v38, v38, s5                       // 00000090B398: D5010026 20164D26
	v_mov_b32_dpp v60, v39 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090B3A0: 7E7802FA FF016827
	v_cndmask_b32_e64 v39, -v39, v39, s5                       // 00000090B3A8: D5010027 20164F27
	v_add_f32_e32 v30, v30, v57                                // 00000090B3B0: 063C731E
	v_mov_b32_dpp v57, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090B3B4: 7E7202FA FF01681F
	v_add_f32_e32 v38, v38, v48                                // 00000090B3BC: 064C6126
	v_cndmask_b32_e64 v31, -v31, v31, s5                       // 00000090B3C0: D501001F 20163F1F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000090B3C8: BF870234
	v_dual_add_f32 v39, v39, v60 :: v_dual_mul_f32 v30, 0x3db504f3, v30// 00000090B3CC: C9067927 271E3CFF 3DB504F3
	v_mov_b32_dpp v45, v41 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090B3D8: 7E5A02FA FF016229
	v_cndmask_b32_e64 v41, -v41, v41, s3                       // 00000090B3E0: D5010029 200E5329
	v_dual_add_f32 v31, v31, v57 :: v_dual_mul_f32 v38, 0x3db504f3, v38// 00000090B3E8: C906731F 1F264CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000090B3F4: BF870234
	v_mul_f32_e32 v30, v30, v8                                 // 00000090B3F8: 103C111E
	v_mov_b32_dpp v63, v29 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090B3FC: 7E7E02FA FF01681D
	v_cndmask_b32_e64 v29, -v29, v29, s5                       // 00000090B404: D501001D 20163B1D
	v_dual_mul_f32 v31, 0x3db504f3, v31 :: v_dual_mul_f32 v38, v38, v12// 00000090B40C: C8C63EFF 1F261926 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000090B418: BF8701A4
	v_dual_mul_f32 v48, 0xbfb8aa3b, v30 :: v_dual_add_f32 v41, v41, v45// 00000090B41C: C8C83CFF 30285B29 BFB8AA3B
	v_mov_b32_dpp v46, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090B428: 7E5C02FA FF01612C
	v_mul_f32_e32 v31, v31, v10                                // 00000090B430: 103E151F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000090B434: BF870214
	v_mul_f32_e32 v51, 0xbfb8aa3b, v38                         // 00000090B438: 10664CFF BFB8AA3B
	v_exp_f32_e32 v48, v48                                     // 00000090B440: 7E604B30
	v_mov_b32_dpp v49, v32 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090B444: 7E6202FA FF016820
	v_cndmask_b32_e64 v32, -v32, v32, s5                       // 00000090B44C: D5010020 20164120
	v_cndmask_b32_e64 v44, -v44, v44, s1                       // 00000090B454: D501002C 2006592C
	v_exp_f32_e32 v51, v51                                     // 00000090B45C: 7E664B33
	v_add_f32_e32 v29, v29, v63                                // 00000090B460: 063A7F1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090B464: BF870193
	v_dual_mul_f32 v39, 0x3db504f3, v39 :: v_dual_add_f32 v32, v32, v49// 00000090B468: C8C84EFF 27206320 3DB504F3
	v_add_f32_e32 v43, v44, v46                                // 00000090B474: 06565D2C
	v_mov_b32_dpp v53, v40 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090B478: 7E6A02FA FF016128
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_4)   // 00000090B480: BF870206
	v_dual_add_f32 v48, 1.0, v48 :: v_dual_mul_f32 v29, 0x3db504f3, v29// 00000090B484: C90660F2 301C3AFF 3DB504F3
	v_cndmask_b32_e64 v40, -v40, v40, s1                       // 00000090B490: D5010028 20065128
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000090B498: BF870294
	v_mov_b32_dpp v46, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090B49C: 7E5C02FA FF01622B
	v_add_f32_e32 v51, 1.0, v51                                // 00000090B4A4: 066666F2
	s_delay_alu instid0(VALU_DEP_4)                            // 00000090B4A8: BF870004
	v_div_scale_f32 v58, null, v48, v48, v30                   // 00000090B4AC: D6FC7C3A 047A6130
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 00000090B4B4: D501002B 200E572B
	v_mul_f32_e32 v29, v29, v15                                // 00000090B4BC: 103A1F1D
	v_mul_f32_e32 v33, 0x3db504f3, v33                         // 00000090B4C0: 104242FF 3DB504F3
	v_div_scale_f32 v65, null, v51, v51, v38                   // 00000090B4C8: D6FC7C41 049A6733
	v_rcp_f32_e32 v61, v58                                     // 00000090B4D0: 7E7A553A
	v_div_scale_f32 v60, s7, v38, v51, v38                     // 00000090B4D4: D6FC073C 049A6726
	v_mov_b32_dpp v44, v37 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090B4DC: 7E5802FA FF016225
	v_cndmask_b32_e64 v37, -v37, v37, s3                       // 00000090B4E4: D5010025 200E4B25
	v_rcp_f32_e32 v70, v65                                     // 00000090B4EC: 7E8C5541
	v_mul_f32_e32 v33, v33, v9                                 // 00000090B4F0: 10421321
	v_mov_b32_dpp v47, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090B4F4: 7E5E02FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 00000090B4FC: D5010022 200E4522
	v_mov_b32_dpp v54, v42 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090B504: 7E6C02FA FF01622A
	v_cndmask_b32_e64 v42, -v42, v42, s3                       // 00000090B50C: D501002A 200E552A
	v_fma_f32 v67, -v58, v61, 1.0                              // 00000090B514: D6130043 23CA7B3A
	v_mov_b32_dpp v52, v36 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090B51C: 7E6802FA FF016224
	v_cndmask_b32_e64 v36, -v36, v36, s3                       // 00000090B524: D5010024 200E4924
	v_mov_b32_dpp v55, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090B52C: 7E6E02FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 00000090B534: D5010023 200E4723
	v_fmac_f32_e32 v61, v67, v61                               // 00000090B53C: 567A7B43
	v_fma_f32 v67, -v65, v70, 1.0                              // 00000090B540: D6130043 23CA8D41
	v_mov_b32_dpp v49, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090B548: 7E6202FA FF01681C
	v_cndmask_b32_e64 v28, -v28, v28, s5                       // 00000090B550: D501001C 2016391C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000090B558: BF870113
	v_dual_add_f32 v37, v37, v44 :: v_dual_fmac_f32 v70, v67, v70// 00000090B55C: C9005925 25468D43
	v_add_f32_e32 v28, v28, v49                                // 00000090B564: 0638631C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000090B568: BF870092
	v_mul_f32_e32 v67, v60, v70                                // 00000090B56C: 10868D3C
	v_fma_f32 v63, -v65, v67, v60                              // 00000090B570: D613003F 24F28741
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000090B578: BF870091
	v_dual_mul_f32 v28, 0x3db504f3, v28 :: v_dual_fmac_f32 v67, v63, v70// 00000090B57C: C8C038FF 1C428D3F 3DB504F3
	v_mul_f32_e32 v28, v28, v13                                // 00000090B588: 10381B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000090B58C: BF870091
	v_mul_f32_e32 v56, 0xbfb8aa3b, v28                         // 00000090B590: 107038FF BFB8AA3B
	v_exp_f32_e32 v56, v56                                     // 00000090B598: 7E704B38
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000090B59C: BF870095
	v_add_f32_e32 v56, 1.0, v56                                // 00000090B5A0: 067070F2
	v_div_scale_f32 v66, null, v56, v56, v28                   // 00000090B5A4: D6FC7C42 04727138
	v_div_scale_f32 v74, s8, v28, v56, v28                     // 00000090B5AC: D6FC084A 0472711C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000090B5B4: BF8700A2
	v_rcp_f32_e32 v71, v66                                     // 00000090B5B8: 7E8E5542
	v_mul_f32_e32 v32, 0x3db504f3, v32                         // 00000090B5BC: 104040FF 3DB504F3
	v_mul_f32_e32 v32, v32, v7                                 // 00000090B5C4: 10400F20
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000090B5C8: BF870091
	v_dual_add_f32 v40, v40, v53 :: v_dual_mul_f32 v49, 0xbfb8aa3b, v32// 00000090B5CC: C9066B28 283040FF BFB8AA3B
	v_mov_b32_dpp v53, v40 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090B5D8: 7E6A02FA FF016228
	v_cndmask_b32_e64 v40, -v40, v40, s3                       // 00000090B5E0: D5010028 200E5128
	v_add_f32_e32 v35, v35, v55                                // 00000090B5E8: 06466F23
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000090B5EC: BF870114
	v_exp_f32_e32 v49, v49                                     // 00000090B5F0: 7E624B31
	v_add_f32_e32 v40, v40, v53                                // 00000090B5F4: 06506B28
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000090B5F8: BF870095
	v_add_f32_e32 v49, 1.0, v49                                // 00000090B5FC: 066262F2
	v_div_scale_f32 v59, null, v49, v49, v32                   // 00000090B600: D6FC7C3B 04826331
	v_div_scale_f32 v69, s6, v32, v49, v32                     // 00000090B608: D6FC0645 04826320
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000090B610: BF870292
	v_rcp_f32_e32 v62, v59                                     // 00000090B614: 7E7C553B
	v_fma_f32 v68, -v59, v62, 1.0                              // 00000090B618: D6130044 23CA7D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000090B620: BF870121
	v_fmac_f32_e32 v62, v68, v62                               // 00000090B624: 567C7D44
	v_fma_f32 v68, -v66, v71, 1.0                              // 00000090B628: D6130044 23CA8F42
	v_mul_f32_e32 v57, v69, v62                                // 00000090B630: 10727D45
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000090B634: BF870112
	v_fmac_f32_e32 v71, v68, v71                               // 00000090B638: 568E8F44
	v_fma_f32 v73, -v59, v57, v69                              // 00000090B63C: D6130049 2516733B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000090B644: BF870121
	v_fmac_f32_e32 v57, v73, v62                               // 00000090B648: 56727D49
	v_div_scale_f32 v64, vcc_lo, v30, v48, v30                 // 00000090B64C: D6FC6A40 047A611E
	v_fma_f32 v59, -v59, v57, v69                              // 00000090B654: D613003B 2516733B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000090B65C: BF870092
	v_mul_f32_e32 v50, v64, v61                                // 00000090B660: 10647B40
	v_fma_f32 v72, -v58, v50, v64                              // 00000090B664: D6130048 2502653A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000090B66C: BF870091
	v_fmac_f32_e32 v50, v72, v61                               // 00000090B670: 56647B48
	v_fma_f32 v58, -v58, v50, v64                              // 00000090B674: D613003A 2502653A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000090B67C: BF870141
	v_div_fmas_f32 v50, v58, v61, v50                          // 00000090B680: D6370032 04CA7B3A
	s_mov_b32 vcc_lo, s6                                       // 00000090B688: BEEA0006
	v_div_fmas_f32 v57, v59, v62, v57                          // 00000090B68C: D6370039 04E67D3B
	s_mov_b32 vcc_lo, s7                                       // 00000090B694: BEEA0007
	v_div_fixup_f32 v30, v50, v48, v30                         // 00000090B698: D627001E 047A6132
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000090B6A0: BF8701A2
	v_div_fixup_f32 v32, v57, v49, v32                         // 00000090B6A4: D6270020 04826339
	v_fma_f32 v49, -v65, v67, v60                              // 00000090B6AC: D6130031 24F28741
	v_mul_f32_e32 v30, v31, v30                                // 00000090B6B4: 103C3D1F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090B6B8: BF870193
	v_mul_f32_e32 v32, v33, v32                                // 00000090B6BC: 10404121
	v_div_fmas_f32 v33, v49, v70, v67                          // 00000090B6C0: D6370021 050E8D31
	s_mov_b32 vcc_lo, s8                                       // 00000090B6C8: BEEA0008
	s_delay_alu instid0(VALU_DEP_1)                            // 00000090B6CC: BF870001
	v_div_fixup_f32 v33, v33, v51, v38                         // 00000090B6D0: D6270021 049A6721
	v_mul_f32_e32 v38, v39, v14                                // 00000090B6D8: 104C1D27
	v_add_f32_e32 v39, v43, v46                                // 00000090B6DC: 064E5D2B
	v_mov_b32_dpp v43, v37 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090B6E0: 7E5602FA FF016425
	v_cndmask_b32_e64 v37, -v37, v37, s4                       // 00000090B6E8: D5010025 20124B25
	v_mov_b32_dpp v46, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090B6F0: 7E5C02FA FF016423
	v_cndmask_b32_e64 v35, -v35, v35, s4                       // 00000090B6F8: D5010023 20124723
	v_mov_b32_dpp v44, v39 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090B700: 7E5802FA FF016427
	v_cndmask_b32_e64 v39, -v39, v39, s4                       // 00000090B708: D5010027 20124F27
	v_add_f32_e32 v37, v37, v43                                // 00000090B710: 064A5725
	v_mov_b32_dpp v43, v41 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090B714: 7E5602FA FF016429
	v_cndmask_b32_e64 v41, -v41, v41, s4                       // 00000090B71C: D5010029 20125329
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000090B724: BF870214
	v_add_f32_e32 v39, v39, v44                                // 00000090B728: 064E5927
	v_mov_b32_dpp v44, v37 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090B72C: 7E5802FA FF016825
	v_cndmask_b32_e64 v37, -v37, v37, s5                       // 00000090B734: D5010025 20164B25
	v_mul_f32_e32 v68, v74, v71                                // 00000090B73C: 10888F4A
	v_add_f32_e32 v41, v41, v43                                // 00000090B740: 06525729
	v_mov_b32_dpp v43, v39 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090B744: 7E5602FA FF016827
	v_cndmask_b32_e64 v39, -v39, v39, s5                       // 00000090B74C: D5010027 20164F27
	v_add_f32_e32 v37, v37, v44                                // 00000090B754: 064A5925
	v_fma_f32 v64, -v66, v68, v74                              // 00000090B758: D6130040 252A8942
	v_mov_b32_dpp v44, v40 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090B760: 7E5802FA FF016428
	v_cndmask_b32_e64 v40, -v40, v40, s4                       // 00000090B768: D5010028 20125128
	v_add_f32_e32 v39, v39, v43                                // 00000090B770: 064E5727
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000090B774: BF870114
	v_dual_mul_f32 v37, 0x3db504f3, v37 :: v_dual_fmac_f32 v68, v64, v71// 00000090B778: C8C04AFF 25448F40 3DB504F3
	v_dual_add_f32 v40, v40, v44 :: v_dual_mul_f32 v39, 0x3db504f3, v39// 00000090B784: C9065928 28264EFF 3DB504F3
	v_add_f32_e32 v36, v36, v52                                // 00000090B790: 06486924
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090B794: BF870193
	v_fma_f32 v57, -v66, v68, v74                              // 00000090B798: D6130039 252A8942
	v_mov_b32_dpp v53, v40 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090B7A0: 7E6A02FA FF016828
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000090B7A8: BF870224
	v_mul_f32_e32 v39, v39, v18                                // 00000090B7AC: 104E2527
	v_cndmask_b32_e64 v40, -v40, v40, s5                       // 00000090B7B0: D5010028 20165128
	v_div_fmas_f32 v48, v57, v71, v68                          // 00000090B7B8: D6370030 05128F39
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000090B7C0: BF870112
	v_add_f32_e32 v40, v40, v53                                // 00000090B7C4: 06506B28
	v_div_fixup_f32 v28, v48, v56, v28                         // 00000090B7C8: D627001C 04727130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000090B7D0: BF870112
	v_mul_f32_e32 v40, 0x3db504f3, v40                         // 00000090B7D4: 105050FF 3DB504F3
	v_mul_f32_e32 v28, v29, v28                                // 00000090B7DC: 1038391D
	v_mov_b32_dpp v29, v41 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090B7E0: 7E3A02FA FF016829
	v_cndmask_b32_e64 v41, -v41, v41, s5                       // 00000090B7E8: D5010029 20165329
	v_add_f32_e32 v34, v34, v47                                // 00000090B7F0: 06445F22
	v_mul_f32_e32 v40, v40, v25                                // 00000090B7F4: 10503328
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090B7F8: BF870193
	v_add_f32_e32 v29, v41, v29                                // 00000090B7FC: 063A3B29
	v_mov_b32_dpp v45, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090B800: 7E5A02FA FF016422
	v_cndmask_b32_e64 v34, -v34, v34, s4                       // 00000090B808: D5010022 20124522
	v_add_f32_e32 v41, v42, v54                                // 00000090B810: 06526D2A
	v_mov_b32_dpp v42, v36 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090B814: 7E5402FA FF016424
	v_mul_f32_e32 v29, 0x3db504f3, v29                         // 00000090B81C: 103A3AFF 3DB504F3
	v_cndmask_b32_e64 v36, -v36, v36, s4                       // 00000090B824: D5010024 20124924
	v_add_f32_e32 v34, v34, v45                                // 00000090B82C: 06445B22
	v_mul_f32_e32 v28, v28, v17                                // 00000090B830: 1038231C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090B834: BF870193
	v_add_f32_e32 v36, v36, v42                                // 00000090B838: 06485524
	v_mov_b32_dpp v43, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090B83C: 7E5602FA FF016822
	v_cndmask_b32_e64 v34, -v34, v34, s5                       // 00000090B844: D5010022 20164522
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000090B84C: BF8700B1
	v_add_f32_e32 v34, v34, v43                                // 00000090B850: 06445722
	v_mov_b32_dpp v43, v41 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090B854: 7E5602FA FF016429
	v_cndmask_b32_e64 v41, -v41, v41, s4                       // 00000090B85C: D5010029 20125329
	v_dual_mul_f32 v34, 0x3db504f3, v34 :: v_dual_add_f32 v41, v41, v43// 00000090B864: C8C844FF 22285729 3DB504F3
	v_mul_f32_e32 v43, 0xbfb8aa3b, v39                         // 00000090B870: 10564EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090B878: BF870192
	v_dual_mul_f32 v37, v37, v19 :: v_dual_mul_f32 v34, v34, v20// 00000090B87C: C8C62725 25222922
	v_mov_b32_dpp v49, v41 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090B884: 7E6202FA FF016829
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000090B88C: BF870113
	v_exp_f32_e32 v42, v43                                     // 00000090B890: 7E544B2B
	v_dual_mul_f32 v45, 0xbfb8aa3b, v37 :: v_dual_mul_f32 v48, 0xbfb8aa3b, v34// 00000090B894: C8C64AFF 2D3044FF BFB8AA3B
	v_mul_f32_e32 v29, v29, v21                                // 00000090B8A0: 103A2B1D
	v_mov_b32_dpp v43, v36 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090B8A4: 7E5602FA FF016824
	v_cndmask_b32_e64 v36, -v36, v36, s5                       // 00000090B8AC: D5010024 20164924
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(TRANS32_DEP_3)// 00000090B8B4: BF8703C4
	v_exp_f32_e32 v45, v45                                     // 00000090B8B8: 7E5A4B2D
	v_add_f32_e32 v35, v35, v46                                // 00000090B8BC: 06465D23
	v_exp_f32_e32 v48, v48                                     // 00000090B8C0: 7E604B30
	v_cndmask_b32_e64 v41, -v41, v41, s5                       // 00000090B8C4: D5010029 20165329
	v_dual_add_f32 v42, 1.0, v42 :: v_dual_mul_f32 v47, 0xbfb8aa3b, v29// 00000090B8CC: C90654F2 2A2E3AFF BFB8AA3B
	v_add_f32_e32 v36, v36, v43                                // 00000090B8D8: 06485724
	v_mov_b32_dpp v57, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090B8DC: 7E7202FA FF016823
	v_cndmask_b32_e64 v35, -v35, v35, s5                       // 00000090B8E4: D5010023 20164723
	s_delay_alu instid0(VALU_DEP_4)                            // 00000090B8EC: BF870004
	v_div_scale_f32 v46, null, v42, v42, v39                   // 00000090B8F0: D6FC7C2E 049E552A
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_4)   // 00000090B8F8: BF870206
	v_dual_add_f32 v45, 1.0, v45 :: v_dual_mul_f32 v36, 0x3db504f3, v36// 00000090B8FC: C9065AF2 2D2448FF 3DB504F3
	v_exp_f32_e32 v47, v47                                     // 00000090B908: 7E5E4B2F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090B90C: BF870196
	v_add_f32_e32 v43, 1.0, v48                                // 00000090B910: 065660F2
	v_rcp_f32_e32 v50, v46                                     // 00000090B914: 7E64552E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000090B918: BF8701A2
	v_div_scale_f32 v44, null, v45, v45, v37                   // 00000090B91C: D6FC7C2C 04965B2D
	v_dual_add_f32 v35, v35, v57 :: v_dual_mul_f32 v36, v36, v23// 00000090B924: C9067323 23242F24
	v_div_scale_f32 v54, null, v43, v43, v34                   // 00000090B92C: D6FC7C36 048A572B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000090B934: BF870113
	v_rcp_f32_e32 v48, v44                                     // 00000090B938: 7E60552C
	v_mul_f32_e32 v35, 0x3db504f3, v35                         // 00000090B93C: 104646FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 00000090B944: BF870392
	v_rcp_f32_e32 v55, v54                                     // 00000090B948: 7E6E5536
	v_fma_f32 v51, -v46, v50, 1.0                              // 00000090B94C: D6130033 23CA652E
	v_add_f32_e32 v47, 1.0, v47                                // 00000090B954: 065E5EF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090B958: BF870193
	v_mul_f32_e32 v35, v35, v24                                // 00000090B95C: 10463123
	v_fmac_f32_e32 v50, v51, v50                               // 00000090B960: 56646533
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 00000090B964: BF8702C6
	v_fma_f32 v56, -v44, v48, 1.0                              // 00000090B968: D6130038 23CA612C
	v_add_f32_e32 v41, v41, v49                                // 00000090B970: 06526329
	v_div_scale_f32 v49, null, v47, v47, v29                   // 00000090B974: D6FC7C31 04765F2F
	v_div_scale_f32 v51, vcc_lo, v39, v42, v39                 // 00000090B97C: D6FC6A33 049E5527
	v_fma_f32 v60, -v54, v55, 1.0                              // 00000090B984: D613003C 23CA6F36
	v_fmac_f32_e32 v48, v56, v48                               // 00000090B98C: 56606138
	v_div_scale_f32 v56, s6, v37, v45, v37                     // 00000090B990: D6FC0638 04965B25
	v_rcp_f32_e32 v52, v49                                     // 00000090B998: 7E685531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000090B99C: BF870091
	v_dual_mul_f32 v59, v51, v50 :: v_dual_mul_f32 v62, v56, v48// 00000090B9A0: C8C66533 3B3E6138
	v_fma_f32 v61, -v46, v59, v51                              // 00000090B9A8: D613003D 24CE772E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000090B9B0: BF870292
	v_fma_f32 v53, -v44, v62, v56                              // 00000090B9B4: D6130035 24E27D2C
	v_fma_f32 v58, -v49, v52, 1.0                              // 00000090B9BC: D613003A 23CA6931
	v_mul_f32_e32 v41, 0x3db504f3, v41                         // 00000090B9C4: 105252FF 3DB504F3
	v_fmac_f32_e32 v55, v60, v55                               // 00000090B9CC: 566E6F3C
	v_div_scale_f32 v60, s8, v34, v43, v34                     // 00000090B9D0: D6FC083C 048A5722
	v_fmac_f32_e32 v62, v53, v48                               // 00000090B9D8: 567C6135
	v_fmac_f32_e32 v52, v58, v52                               // 00000090B9DC: 5668693A
	v_div_scale_f32 v58, s7, v29, v47, v29                     // 00000090B9E0: D6FC073A 04765F1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000090B9E8: BF870234
	v_dual_mul_f32 v41, v41, v22 :: v_dual_mul_f32 v64, v60, v55// 00000090B9EC: C8C62D29 29406F3C
	v_fmac_f32_e32 v59, v61, v50                               // 00000090B9F4: 5676653D
	v_fma_f32 v44, -v44, v62, v56                              // 00000090B9F8: D613002C 24E27D2C
	v_mul_f32_e32 v63, v58, v52                                // 00000090BA00: 107E693A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000090BA04: BF8701A3
	v_fma_f32 v46, -v46, v59, v51                              // 00000090BA08: D613002E 24CE772E
	v_fma_f32 v51, -v54, v64, v60                              // 00000090BA10: D6130033 24F28136
	v_fma_f32 v61, -v49, v63, v58                              // 00000090BA18: D613003D 24EA7F31
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000090BA20: BF870211
	v_dual_fmac_f32 v64, v51, v55 :: v_dual_fmac_f32 v63, v61, v52// 00000090BA24: C8006F33 403E693D
	v_div_fmas_f32 v46, v46, v50, v59                          // 00000090BA2C: D637002E 04EE652E
	s_mov_b32 vcc_lo, s6                                       // 00000090BA34: BEEA0006
	v_div_fmas_f32 v44, v44, v48, v62                          // 00000090BA38: D637002C 04FA612C
	s_delay_alu instid0(VALU_DEP_3)                            // 00000090BA40: BF870003
	v_fma_f32 v49, -v49, v63, v58                              // 00000090BA44: D6130031 24EA7F31
	v_fma_f32 v48, -v54, v64, v60                              // 00000090BA4C: D6130030 24F28136
	s_mov_b32 vcc_lo, s7                                       // 00000090BA54: BEEA0007
	v_div_fixup_f32 v39, v46, v42, v39                         // 00000090BA58: D6270027 049E552E
	v_div_fixup_f32 v37, v44, v45, v37                         // 00000090BA60: D6270025 04965B2C
	v_div_fmas_f32 v49, v49, v52, v63                          // 00000090BA68: D6370031 04FE6931
	s_mov_b32 vcc_lo, s8                                       // 00000090BA70: BEEA0008
	v_mul_f32_e32 v33, v38, v33                                // 00000090BA74: 10424326
	v_div_fmas_f32 v48, v48, v55, v64                          // 00000090BA78: D6370030 05026F30
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000090BA80: BF870113
	v_div_fixup_f32 v29, v49, v47, v29                         // 00000090BA84: D627001D 04765F31
	v_div_fixup_f32 v34, v48, v43, v34                         // 00000090BA8C: D6270022 048A5730
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000090BA94: BF870121
	v_dual_mul_f32 v29, v40, v29 :: v_dual_mul_f32 v34, v35, v34// 00000090BA98: C8C63B28 1D224523
	v_dual_mul_f32 v35, v36, v37 :: v_dual_mul_f32 v36, v41, v39// 00000090BAA0: C8C64B24 23244F29
	v_dual_mul_f32 v29, v29, v27 :: v_dual_mul_f32 v34, v34, v26// 00000090BAA8: C8C6371D 1D223522
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000090BAB0: BF870231
	v_fma_f32 v37, v35, v6, v29                                // 00000090BAB4: D6130025 04760D23
	v_fma_f32 v29, v35, v6, -v29                               // 00000090BABC: D613001D 84760D23
	v_mul_f32_e32 v31, v33, v16                                // 00000090BAC4: 103E2121
	v_fma_f32 v33, v36, v5, v34                                // 00000090BAC8: D6130021 048A0B24
	v_fma_f32 v34, v36, v5, -v34                               // 00000090BAD0: D6130022 848A0B24
	v_fma_f32 v35, v30, v11, v28                               // 00000090BAD8: D6130023 0472171E
	v_fma_f32 v28, v30, v11, -v28                              // 00000090BAE0: D613001C 8472171E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000090BAE8: BF870143
	v_add_f32_e32 v30, v34, v29                                // 00000090BAEC: 063C3B22
	v_fma_f32 v36, v32, v4, -v31                               // 00000090BAF0: D6130024 847E0920
	v_dual_fmac_f32 v31, v32, v4 :: v_dual_add_f32 v32, v37, v33// 00000090BAF8: C8080920 1F204325
	v_sub_f32_e32 v29, v29, v34                                // 00000090BB00: 083A451D
	v_dual_add_f32 v39, v28, v36 :: v_dual_add_f32 v38, v31, v35// 00000090BB04: C908491C 2726471F
	v_dual_sub_f32 v33, v37, v33 :: v_dual_sub_f32 v28, v36, v28// 00000090BB0C: C94A4325 211C3924
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000090BB14: BF870122
	v_dual_add_f32 v41, v30, v39 :: v_dual_add_f32 v40, v32, v38// 00000090BB18: C9084F1E 29284D20
	v_sub_f32_e32 v32, v32, v38                                // 00000090BB20: 08404D20
	v_mov_b32_dpp v34, v40 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090BB24: 7E4402FA FF016128
	v_cndmask_b32_e64 v37, -v40, v40, s1                       // 00000090BB2C: D5010025 20065128
	v_sub_f32_e32 v31, v31, v35                                // 00000090BB34: 083E471F
	v_mov_b32_dpp v35, v41 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090BB38: 7E4602FA FF016129
	v_cndmask_b32_e64 v40, -v41, v41, s1                       // 00000090BB40: D5010028 20065329
	v_mov_b32_dpp v41, v32 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090BB48: 7E5202FA FF016120
	v_add_f32_e32 v34, v37, v34                                // 00000090BB50: 06444525
	v_cndmask_b32_e64 v42, -v32, v32, s1                       // 00000090BB54: D501002A 20064120
	v_add_f32_e32 v36, v33, v31                                // 00000090BB5C: 06483F21
	v_sub_f32_e32 v37, v30, v39                                // 00000090BB60: 084A4F1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000090BB64: BF870254
	v_mov_b32_dpp v38, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090BB68: 7E4C02FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 00000090BB70: D5010022 200E4522
	v_add_f32_e32 v35, v40, v35                                // 00000090BB78: 06464728
	v_mov_b32_dpp v30, v36 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090BB7C: 7E3C02FA FF016124
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 00000090BB84: D5010024 20064924
	v_add_f32_e32 v34, v34, v38                                // 00000090BB8C: 06444D22
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000090BB90: BF870224
	v_mov_b32_dpp v39, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090BB94: 7E4E02FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 00000090BB9C: D5010023 200E4723
	v_add_f32_e32 v30, v36, v30                                // 00000090BBA4: 063C3D24
	v_sub_f32_e32 v36, v33, v31                                // 00000090BBA8: 08483F21
	v_add_f32_e32 v31, v29, v28                                // 00000090BBAC: 063E391D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000090BBB0: BF870214
	v_add_f32_e32 v33, v35, v39                                // 00000090BBB4: 06424F23
	v_mov_b32_dpp v35, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090BBB8: 7E4602FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 00000090BBC0: D501001E 200E3D1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000090BBC8: BF8701C4
	v_mov_b32_dpp v38, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090BBCC: 7E4C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 00000090BBD4: D501001F 20063F1F
	v_sub_f32_e32 v39, v29, v28                                // 00000090BBDC: 084E391D
	v_mov_b32_dpp v28, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090BBE0: 7E3802FA FF016422
	v_dual_add_f32 v29, v30, v35 :: v_dual_add_f32 v30, v31, v38// 00000090BBE8: C908471E 1D1E4D1F
	v_cndmask_b32_e64 v31, -v34, v34, s4                       // 00000090BBF0: D501001F 20124522
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000090BBF8: BF870194
	v_mov_b32_dpp v43, v39 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090BBFC: 7E5602FA FF016127
	v_mov_b32_dpp v34, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090BC04: 7E4402FA FF01641D
	v_cndmask_b32_e64 v29, -v29, v29, s4                       // 00000090BC0C: D501001D 20123B1D
	v_mov_b32_dpp v38, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090BC14: 7E4C02FA FF01621E
	v_cndmask_b32_e64 v40, -v30, v30, s3                       // 00000090BC1C: D5010028 200E3D1E
	v_cndmask_b32_e64 v39, -v39, v39, s1                       // 00000090BC24: D5010027 20064F27
	v_add_f32_e32 v30, v31, v28                                // 00000090BC2C: 063C391F
	v_add_f32_e32 v32, v29, v34                                // 00000090BC30: 0640451D
	v_mov_b32_dpp v35, v33 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090BC34: 7E4602FA FF016421
	v_cndmask_b32_e64 v33, -v33, v33, s4                       // 00000090BC3C: D5010021 20124321
	v_dual_add_f32 v34, v40, v38 :: v_dual_add_f32 v39, v39, v43// 00000090BC44: C9084D28 22265727
	v_mov_b32_dpp v28, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090BC4C: 7E3802FA FF01681E
	v_mov_b32_dpp v29, v32 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090BC54: 7E3A02FA FF016820
	s_delay_alu instid0(VALU_DEP_4)                            // 00000090BC5C: BF870004
	v_add_f32_e32 v33, v33, v35                                // 00000090BC60: 06424721
	v_add_f32_e32 v35, v42, v41                                // 00000090BC64: 0646532A
	v_mov_b32_dpp v41, v37 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090BC68: 7E5202FA FF016125
	v_cndmask_b32_e64 v37, -v37, v37, s1                       // 00000090BC70: D5010025 20064B25
	v_mov_b32_dpp v38, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090BC78: 7E4C02FA FF016422
	v_cndmask_b32_e64 v34, -v34, v34, s4                       // 00000090BC80: D5010022 20124522
	v_mov_b32_dpp v40, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090BC88: 7E5002FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 00000090BC90: D5010023 200E4723
	v_add_f32_e32 v37, v37, v41                                // 00000090BC98: 064A5325
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000090BC9C: BF8700B2
	v_add_f32_e32 v35, v35, v40                                // 00000090BCA0: 06465123
	v_mov_b32_dpp v42, v36 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000090BCA4: 7E5402FA FF016124
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 00000090BCAC: D5010024 20064924
	v_add_f32_e32 v36, v36, v42                                // 00000090BCB4: 06485524
	v_mov_b32_dpp v42, v39 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090BCB8: 7E5402FA FF016227
	v_cndmask_b32_e64 v39, -v39, v39, s3                       // 00000090BCC0: D5010027 200E4F27
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000090BCC8: BF8700A3
	v_mov_b32_dpp v41, v36 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090BCCC: 7E5202FA FF016224
	v_cndmask_b32_e64 v36, -v36, v36, s3                       // 00000090BCD4: D5010024 200E4924
	v_dual_add_f32 v39, v39, v42 :: v_dual_add_f32 v36, v36, v41// 00000090BCDC: C9085527 27245324
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000090BCE4: BF870231
	v_mov_b32_dpp v45, v39 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090BCE8: 7E5A02FA FF016427
	v_cndmask_b32_e64 v39, -v39, v39, s4                       // 00000090BCF0: D5010027 20124F27
	v_mov_b32_dpp v31, v33 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090BCF8: 7E3E02FA FF016821
	v_mov_b32_dpp v43, v36 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090BD00: 7E5602FA FF016424
	v_cndmask_b32_e64 v44, -v36, v36, s4                       // 00000090BD08: D501002C 20124924
	v_add_f32_e32 v36, v34, v38                                // 00000090BD10: 06484D22
	v_mov_b32_dpp v40, v37 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000090BD14: 7E5002FA FF016225
	v_cndmask_b32_e64 v37, -v37, v37, s3                       // 00000090BD1C: D5010025 200E4B25
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000090BD24: BF870113
	v_mov_b32_dpp v34, v36 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090BD28: 7E4402FA FF016824
	v_add_f32_e32 v37, v37, v40                                // 00000090BD30: 064A5125
	v_mov_b32_dpp v40, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090BD34: 7E5002FA FF016423
	v_cndmask_b32_e64 v35, -v35, v35, s4                       // 00000090BD3C: D5010023 20124723
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000090BD44: BF8701A3
	v_mov_b32_dpp v41, v37 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000090BD48: 7E5202FA FF016425
	v_cndmask_b32_e64 v42, -v37, v37, s4                       // 00000090BD50: D501002A 20124B25
	v_dual_add_f32 v37, v35, v40 :: v_dual_add_f32 v40, v44, v43// 00000090BD58: C9085123 2528572C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000090BD60: BF8701A2
	v_add_f32_e32 v38, v42, v41                                // 00000090BD64: 064C532A
	v_add_f32_e32 v42, v39, v45                                // 00000090BD68: 06545B27
	v_mov_b32_dpp v35, v37 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090BD6C: 7E4602FA FF016825
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000090BD74: BF870214
	v_mov_b32_dpp v41, v40 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090BD78: 7E5202FA FF016828
	v_mov_b32_dpp v39, v38 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090BD80: 7E4E02FA FF016826
	s_delay_alu instid0(VALU_DEP_4)                            // 00000090BD88: BF870004
	v_mov_b32_dpp v43, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000090BD8C: 7E5602FA FF01682A
	s_and_saveexec_b32 s6, s0                                  // 00000090BD94: BE862000
	s_cbranch_execz 64235                                      // 00000090BD98: BFA5FAEB <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x3348>
	v_cndmask_b32_e64 v30, -v30, v30, s5                       // 00000090BD9C: D501001E 20163D1E
	v_cndmask_b32_e64 v40, -v40, v40, s5                       // 00000090BDA4: D5010028 20165128
	v_cndmask_b32_e64 v33, -v33, v33, s5                       // 00000090BDAC: D5010021 20164321
	v_cndmask_b32_e64 v42, -v42, v42, s5                       // 00000090BDB4: D501002A 2016552A
	v_cndmask_b32_e64 v32, -v32, v32, s5                       // 00000090BDBC: D5010020 20164120
	v_cndmask_b32_e64 v36, -v36, v36, s5                       // 00000090BDC4: D5010024 20164924
	v_cndmask_b32_e64 v37, -v37, v37, s5                       // 00000090BDCC: D5010025 20164B25
	v_cndmask_b32_e64 v38, -v38, v38, s5                       // 00000090BDD4: D5010026 20164D26
	v_add_f32_e32 v30, v30, v28                                // 00000090BDDC: 063C391E
	v_dual_add_f32 v40, v40, v41 :: v_dual_add_f32 v31, v33, v31// 00000090BDE0: C9085328 281E3F21
	v_dual_add_f32 v42, v42, v43 :: v_dual_add_f32 v29, v32, v29// 00000090BDE8: C908572A 2A1C3B20
	v_dual_add_f32 v32, v36, v34 :: v_dual_add_f32 v33, v37, v35// 00000090BDF0: C9084524 20204725
	v_add_f32_e32 v38, v38, v39                                // 00000090BDF8: 064C4F26
	v_fma_mixhi_f16 v28, v30, s9, 0                            // 00000090BDFC: CC22001C 0200131E
	v_fma_mixlo_f16 v28, v31, s9, 0                            // 00000090BE04: CC21001C 0200131F
	v_fma_mixlo_f16 v29, v29, s9, 0                            // 00000090BE0C: CC21001D 0200131D
	v_fma_mixhi_f16 v29, v32, s9, 0                            // 00000090BE14: CC22001D 02001320
	v_fma_mixlo_f16 v30, v33, s9, 0                            // 00000090BE1C: CC21001E 02001321
	v_fma_mixhi_f16 v30, v38, s9, 0                            // 00000090BE24: CC22001E 02001326
	v_fma_mixlo_f16 v31, v40, s9, 0                            // 00000090BE2C: CC21001F 02001328
	v_fma_mixhi_f16 v31, v42, s9, 0                            // 00000090BE34: CC22001F 0200132A
	s_clause 0x7                                               // 00000090BE3C: BF850007
	global_store_d16_hi_b16 v[2:3], v28, off                   // 00000090BE40: DC960000 007C1C02
	global_store_b16 v[2:3], v28, off offset:32                // 00000090BE48: DC660020 007C1C02
	global_store_b16 v[2:3], v29, off offset:64                // 00000090BE50: DC660040 007C1D02
	global_store_d16_hi_b16 v[2:3], v29, off offset:96         // 00000090BE58: DC960060 007C1D02
	global_store_b16 v[2:3], v30, off offset:128               // 00000090BE60: DC660080 007C1E02
	global_store_d16_hi_b16 v[2:3], v30, off offset:160        // 00000090BE68: DC9600A0 007C1E02
	global_store_b16 v[2:3], v31, off offset:192               // 00000090BE70: DC6600C0 007C1F02
	global_store_d16_hi_b16 v[2:3], v31, off offset:224        // 00000090BE78: DC9600E0 007C1F02
	s_branch 64177                                             // 00000090BE80: BFA0FAB1 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x3348>
	s_and_b32 exec_lo, exec_lo, s2                             // 00000090BE84: 8B7E027E
	s_cbranch_execz 6                                          // 00000090BE88: BFA50006 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x48a4>
	s_lshl_b64 s[0:1], s[24:25], 2                             // 00000090BE8C: 84808218
	v_mov_b32_e32 v0, 0                                        // 00000090BE90: 7E000280
	s_add_u32 s0, s22, s0                                      // 00000090BE94: 80000016
	s_addc_u32 s1, s23, s1                                     // 00000090BE98: 82010117
	global_store_b32 v0, v0, s[0:1]                            // 00000090BE9C: DC6A0000 00000000
	s_nop 0                                                    // 00000090BEA4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000090BEA8: BFB60003
	s_endpgm                                                   // 00000090BEAC: BFB00000
	s_add_i32 s3, s10, 1                                       // 00000090BEB0: 8103810A
	v_dual_add_f32 v52, v84, v30 :: v_dual_add_f32 v33, v81, v33// 00000090BEB4: C9083D54 34204351
	s_mul_i32 s4, s3, 5                                        // 00000090BEBC: 96048503
	s_mul_hi_i32 s3, s3, 5                                     // 00000090BEC0: 97038503
	s_add_u32 s4, s4, s6                                       // 00000090BEC4: 80040604
	s_addc_u32 s5, s3, s7                                      // 00000090BEC8: 82050703
	v_dual_add_f32 v82, v82, v31 :: v_dual_add_f32 v77, v77, v108// 00000090BECC: C9083F52 524CD94D
	s_lshl_b64 s[4:5], s[4:5], 7                               // 00000090BED4: 84848704
	v_dual_add_f32 v36, v83, v36 :: v_dual_add_f32 v73, v73, v118// 00000090BED8: C9084953 2448ED49
	.long 0xd7006a1e                                           // 00000090BEE0: D7006A1E
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000090BEE4: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000090BEE8: BF8701B1
	v_add_co_ci_u32_e64 v31, null, s5, v3, vcc_lo              // 00000090BEEC: D5207C1F 01AA0605
	v_dual_add_f32 v80, v80, v101 :: v_dual_add_f32 v79, v79, v103// 00000090BEF4: C908CB50 504ECF4F
	v_dual_add_f32 v78, v78, v105 :: v_dual_add_f32 v75, v75, v111// 00000090BEFC: C908D34E 4E4ADF4B
	.long 0xd73c001e                                           // 00000090BF04: D73C001E
	v_cndmask_b32_e32 v1, 6, v30, vcc_lo                       // 00000090BF08: 02023C86
	v_dual_add_f32 v76, v76, v109 :: v_dual_add_f32 v69, v69, v126// 00000090BF0C: C908DB4C 4C44FD45
	v_add_f32_e32 v74, v74, v113                               // 00000090BF14: 0694E34A
	v_dual_add_f32 v72, v72, v120 :: v_dual_add_f32 v71, v71, v121// 00000090BF18: C908F148 4846F347
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000090BF20: BF870094
	.long 0xd7006a1e                                           // 00000090BF24: D7006A1E
	v_cndmask_b32_e32 v1, v34, v30, vcc_lo                     // 00000090BF28: 02023D22
	v_add_co_ci_u32_e64 v31, null, v35, v31, vcc_lo            // 00000090BF2C: D5207C1F 01AA3F23
	v_add_f32_e32 v70, v70, v124                               // 00000090BF34: 068CF946
	s_clause 0xf                                               // 00000090BF38: BF85000F
	global_store_b32 v[30:31], v52, off                        // 00000090BF3C: DC6A0000 007C341E
	global_store_b32 v[30:31], v36, off offset:64              // 00000090BF44: DC6A0040 007C241E
	global_store_b32 v[30:31], v82, off offset:128             // 00000090BF4C: DC6A0080 007C521E
	global_store_b32 v[30:31], v33, off offset:192             // 00000090BF54: DC6A00C0 007C211E
	global_store_b32 v[30:31], v80, off offset:256             // 00000090BF5C: DC6A0100 007C501E
	global_store_b32 v[30:31], v79, off offset:320             // 00000090BF64: DC6A0140 007C4F1E
	global_store_b32 v[30:31], v78, off offset:384             // 00000090BF6C: DC6A0180 007C4E1E
	global_store_b32 v[30:31], v77, off offset:448             // 00000090BF74: DC6A01C0 007C4D1E
	global_store_b32 v[30:31], v76, off offset:512             // 00000090BF7C: DC6A0200 007C4C1E
	global_store_b32 v[30:31], v75, off offset:576             // 00000090BF84: DC6A0240 007C4B1E
	global_store_b32 v[30:31], v74, off offset:640             // 00000090BF8C: DC6A0280 007C4A1E
	global_store_b32 v[30:31], v73, off offset:704             // 00000090BF94: DC6A02C0 007C491E
	global_store_b32 v[30:31], v72, off offset:768             // 00000090BF9C: DC6A0300 007C481E
	global_store_b32 v[30:31], v71, off offset:832             // 00000090BFA4: DC6A0340 007C471E
	global_store_b32 v[30:31], v70, off offset:896             // 00000090BFAC: DC6A0380 007C461E
	global_store_b32 v[30:31], v69, off offset:960             // 00000090BFB4: DC6A03C0 007C451E
	s_cmp_lt_i32 s11, 3                                        // 00000090BFBC: BF04830B
	s_cbranch_scc1 63803                                       // 00000090BFC0: BFA2F93B <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2eb0>
	s_add_i32 s3, s10, 2                                       // 00000090BFC4: 8103820A
	v_dual_add_f32 v30, v67, v17 :: v_dual_add_f32 v15, v66, v15// 00000090BFC8: C9082343 1E0E1F42
	s_mul_i32 s4, s3, 5                                        // 00000090BFD0: 96048503
	s_mul_hi_i32 s3, s3, 5                                     // 00000090BFD4: 97038503
	s_add_u32 s4, s4, s6                                       // 00000090BFD8: 80040604
	s_addc_u32 s5, s3, s7                                      // 00000090BFDC: 82050703
	v_dual_add_f32 v31, v65, v18 :: v_dual_add_f32 v36, v56, v104// 00000090BFE0: C9082541 1F24D138
	s_lshl_b64 s[4:5], s[4:5], 7                               // 00000090BFE8: 84848704
	v_dual_add_f32 v13, v68, v13 :: v_dual_add_f32 v32, v58, v32// 00000090BFEC: C9081B44 0D20413A
	.long 0xd7006a11                                           // 00000090BFF4: D7006A11
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000090BFF8: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000090BFFC: BF8701B1
	v_add_co_ci_u32_e64 v18, null, s5, v3, vcc_lo              // 00000090C000: D5207C12 01AA0605
	v_dual_add_f32 v19, v64, v19 :: v_dual_add_f32 v52, v55, v106// 00000090C008: C9082740 1334D537
	v_dual_add_f32 v21, v63, v21 :: v_dual_add_f32 v54, v54, v107// 00000090C010: C9082B3F 1536D736
	.long 0xd73c0011                                           // 00000090C018: D73C0011
	v_cndmask_b32_e32 v1, 6, v17, vcc_lo                       // 00000090C01C: 02022286
	v_add_f32_e32 v23, v62, v23                                // 00000090C020: 062E2F3E
	v_add_f32_e32 v25, v61, v25                                // 00000090C024: 0632333D
	v_add_f32_e32 v27, v60, v27                                // 00000090C028: 0636373C
	v_add_f32_e32 v29, v59, v29                                // 00000090C02C: 063A3B3B
	v_add_f32_e32 v33, v57, v102                               // 00000090C030: 0642CD39
	.long 0xd7006a11                                           // 00000090C034: D7006A11
	v_cndmask_b32_e32 v1, v34, v17, vcc_lo                     // 00000090C038: 02022322
	s_delay_alu instid0(VALU_DEP_1)                            // 00000090C03C: BF870001
	v_add_co_ci_u32_e64 v18, null, v35, v18, vcc_lo            // 00000090C040: D5207C12 01AA2523
	v_add_f32_e32 v53, v53, v110                               // 00000090C048: 066ADD35
	s_clause 0xf                                               // 00000090C04C: BF85000F
	global_store_b32 v[17:18], v13, off                        // 00000090C050: DC6A0000 007C0D11
	global_store_b32 v[17:18], v30, off offset:64              // 00000090C058: DC6A0040 007C1E11
	global_store_b32 v[17:18], v15, off offset:128             // 00000090C060: DC6A0080 007C0F11
	global_store_b32 v[17:18], v31, off offset:192             // 00000090C068: DC6A00C0 007C1F11
	global_store_b32 v[17:18], v19, off offset:256             // 00000090C070: DC6A0100 007C1311
	global_store_b32 v[17:18], v21, off offset:320             // 00000090C078: DC6A0140 007C1511
	global_store_b32 v[17:18], v23, off offset:384             // 00000090C080: DC6A0180 007C1711
	global_store_b32 v[17:18], v25, off offset:448             // 00000090C088: DC6A01C0 007C1911
	global_store_b32 v[17:18], v27, off offset:512             // 00000090C090: DC6A0200 007C1B11
	global_store_b32 v[17:18], v29, off offset:576             // 00000090C098: DC6A0240 007C1D11
	global_store_b32 v[17:18], v32, off offset:640             // 00000090C0A0: DC6A0280 007C2011
	global_store_b32 v[17:18], v33, off offset:704             // 00000090C0A8: DC6A02C0 007C2111
	global_store_b32 v[17:18], v36, off offset:768             // 00000090C0B0: DC6A0300 007C2411
	global_store_b32 v[17:18], v52, off offset:832             // 00000090C0B8: DC6A0340 007C3411
	global_store_b32 v[17:18], v54, off offset:896             // 00000090C0C0: DC6A0380 007C3611
	global_store_b32 v[17:18], v53, off offset:960             // 00000090C0C8: DC6A03C0 007C3511
	s_cmp_lt_i32 s11, 4                                        // 00000090C0D0: BF04840B
	s_cbranch_scc0 63736                                       // 00000090C0D4: BFA1F8F8 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2eb8>
	s_branch 63802                                             // 00000090C0D8: BFA0F93A <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi4ELi8ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2fc4>
		...

