0000000000596900 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi1ELi32ELi2ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi1ELi32ELi2ELb0EEEvPKhPKtPvll():
	s_load_b256 s[4:11], s[0:1], null                          // 000000596900: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 000000596908: BE830080
	v_bfe_u32 v5, v0, 5, 1                                     // 00000059690C: D6100005 02050B00
	v_dual_mov_b32 v10, 0 :: v_dual_and_b32 v7, 31, v0         // 000000596914: CA240080 0A06009F
	v_lshrrev_b32_e32 v6, 6, v0                                // 00000059691C: 320C0086
	s_waitcnt lgkmcnt(0)                                       // 000000596920: BF89FC07
	s_ashr_i32 s12, s11, 31                                    // 000000596924: 860C9F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000596928: BF8704C9
	s_lshr_b32 s14, s12, 28                                    // 00000059692C: 850E9C0C
	s_lshl_b64 s[12:13], s[2:3], 2                             // 000000596930: 848C8202
	s_add_u32 s14, s10, s14                                    // 000000596934: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000596938: 820F800B
	s_lshr_b64 s[16:17], s[14:15], 4                           // 00000059693C: 8590840E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000596940: BF870499
	s_add_i32 s2, s16, 1                                       // 000000596944: 81028110
	s_lshr_b32 s14, s2, 31                                     // 000000596948: 850E9F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000059694C: BF8704B9
	s_add_i32 s2, s2, s14                                      // 000000596950: 81020E02
	s_load_b64 s[14:15], s[0:1], 0x20                          // 000000596954: F4040380 F8000020
	s_ashr_i32 s2, s2, 1                                       // 00000059695C: 86028102
	.long 0xd72c0001                                           // 000000596960: D72C0001
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 000000596964: 02020A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000596968: BF870131
	v_add_nc_u32_e32 v2, s2, v1                                // 00000059696C: 4A040202
	v_add_nc_u32_e32 v8, v1, v7                                // 000000596970: 4A100F01
	s_mov_b32 s2, exec_lo                                      // 000000596974: BE82007E
	v_min_i32_e32 v9, s16, v2                                  // 000000596978: 22120410
	s_delay_alu instid0(VALU_DEP_1)                            // 00000059697C: BF870001
	.long 0xd4c1007e                                           // 000000596980: D4C1007E
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 000000596984: 02021308
	s_cbranch_execz 374                                        // 000000596988: BFA50176 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi1ELi32ELi2ELb0EEEvPKhPKtPvll+0x664>
	.long 0xd7000001                                           // 00000059698C: D7000001
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 000000596990: 02020C0C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000596994: BF870001
	v_add_co_ci_u32_e64 v2, null, s13, 0, s0                   // 000000596998: D5207C02 0001000D
	s_ashr_i32 s0, s11, 31                                     // 0000005969A0: 86009F0B
	v_mov_b32_e32 v10, 0                                       // 0000005969A4: 7E140280
	s_lshr_b32 s0, s0, 24                                      // 0000005969A8: 85009800
	s_waitcnt lgkmcnt(0)                                       // 0000005969AC: BF89FC07
	v_cmp_gt_i64_e32 vcc_lo, s[14:15], v[1:2]                  // 0000005969B0: 7CA8020E
	s_add_u32 s0, s10, s0                                      // 0000005969B4: 8000000A
	s_addc_u32 s1, s11, 0                                      // 0000005969B8: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000005969BC: BF870499
	s_ashr_i64 s[0:1], s[0:1], 8                               // 0000005969C0: 86808800
	s_mulk_i32 s1, 0xd2                                        // 0000005969C4: B80100D2
	v_dual_cndmask_b32 v2, 0, v2 :: v_dual_cndmask_b32 v1, 0, v1// 0000005969C8: CA520480 02000280
	s_mul_hi_u32 s10, s0, 0xd2                                 // 0000005969D0: 968AFF00 000000D2
	s_mulk_i32 s0, 0xd2                                        // 0000005969D8: B80000D2
	s_add_i32 s10, s10, s1                                     // 0000005969DC: 810A010A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005969E0: BF8700B1
	.long 0xd72c0004                                           // 0000005969E4: D72C0004
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 0000005969E8: 02020400
	.long 0xd72c0003                                           // 0000005969EC: D72C0003
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 0000005969F0: 0202020A
	v_mad_u64_u32 v[1:2], null, s0, v1, s[4:5]                 // 0000005969F4: D6FE7C01 00120200
	v_add3_u32 v2, v3, v2, v4                                  // 0000005969FC: D6550002 04120503
	v_lshlrev_b32_e32 v3, 4, v8                                // 000000596A04: 30061084
	v_ashrrev_i32_e32 v4, 4, v8                                // 000000596A08: 34081084
	v_bfe_u32 v12, v8, 3, 1                                    // 000000596A0C: D610000C 02050708
	s_delay_alu instid0(VALU_DEP_3)                            // 000000596A14: BF870003
	v_and_b32_e32 v13, 32, v3                                  // 000000596A18: 361A06A0
	v_and_b32_e32 v11, 15, v8                                  // 000000596A1C: 3616108F
	v_and_b32_e32 v15, 16, v3                                  // 000000596A20: 361E0690
	.long 0xd72c0004                                           // 000000596A24: D72C0004
	v_cndmask_b32_e32 v1, 0xd2, v4, vcc_lo                     // 000000596A28: 020208FF 000000D2
	v_lshlrev_b32_e32 v14, 6, v12                              // 000000596A30: 301C1886
	v_lshlrev_b32_e32 v12, 5, v12                              // 000000596A34: 30181885
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000596A38: BF8700A3
	v_ashrrev_i32_e32 v16, 31, v4                              // 000000596A3C: 3420089F
	.long 0xd7006a13                                           // 000000596A40: D7006A13
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 000000596A44: 02020901
	v_add_co_ci_u32_e64 v20, null, v2, v16, vcc_lo             // 000000596A48: D5207C14 01AA2102
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000596A50: BF8701A2
	.long 0xd7006a04                                           // 000000596A54: D7006A04
	v_cndmask_b32_e32 v1, v19, v14, vcc_lo                     // 000000596A58: 02021D13
	.long 0xd700000e                                           // 000000596A5C: D700000E
	v_cndmask_b32_e32 v1, v19, v12, vcc_lo                     // 000000596A60: 02021913
	v_add_co_ci_u32_e64 v16, null, 0, v20, vcc_lo              // 000000596A64: D5207C10 01AA2880
	v_add_co_ci_u32_e64 v17, null, 0, v20, s0                  // 000000596A6C: D5207C11 00022880
	s_delay_alu instid0(VALU_DEP_4)                            // 000000596A74: BF870004
	.long 0xd7006a04                                           // 000000596A78: D7006A04
	v_cndmask_b32_e32 v1, v4, v13, vcc_lo                      // 000000596A7C: 02021B04
	.long 0xd700010b                                           // 000000596A80: D700010B
	v_cndmask_b32_e32 v1, v19, v11, vcc_lo                     // 000000596A84: 02021713
	.long 0xd700000d                                           // 000000596A88: D700000D
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                     // 000000596A8C: 02021F0E
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 000000596A90: D5207C10 01AA2080
	v_add_co_ci_u32_e64 v12, null, 0, v20, s1                  // 000000596A98: D5207C0C 00062880
	v_add_co_ci_u32_e64 v14, null, 0, v17, s0                  // 000000596AA0: D5207C0E 00022280
	.long 0xd7006a0f                                           // 000000596AA8: D7006A0F
	v_cndmask_b32_e32 v1, v4, v15, vcc_lo                      // 000000596AAC: 02021F04
	s_delay_alu instid0(VALU_DEP_1)                            // 000000596AB0: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 000000596AB4: D5207C10 01AA2080
	s_clause 0x3                                               // 000000596ABC: BF850003
	global_load_i8 v27, v[11:12], off offset:192               // 000000596AC0: DC4600C0 1B7C000B
	global_load_b128 v[11:14], v[13:14], off offset:128        // 000000596AC8: DC5E0080 0B7C000D
	global_load_b128 v[15:18], v[15:16], off                   // 000000596AD0: DC5E0000 0F7C000F
	global_load_d16_b16 v28, v[19:20], off offset:208          // 000000596AD8: DC8200D0 1C7C0013
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000596AE0: 3408069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000596AE4: BF870121
	.long 0xd73c0013                                           // 000000596AE8: D73C0013
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 000000596AEC: 02020681
	v_add_nc_u32_e32 v3, 0x200, v3                             // 000000596AF0: 4A0606FF 00000200
	.long 0xd7006a17                                           // 000000596AF8: D7006A17
	v_cndmask_b32_e32 v1, s6, v19, vcc_lo                      // 000000596AFC: 02022606
	s_delay_alu instid0(VALU_DEP_1)                            // 000000596B00: BF870001
	v_add_co_ci_u32_e64 v24, null, s7, v20, vcc_lo             // 000000596B04: D5207C18 01AA2807
	s_clause 0x1                                               // 000000596B0C: BF850001
	global_load_b128 v[19:22], v[23:24], off                   // 000000596B10: DC5E0000 137C0017
	global_load_b128 v[23:26], v[23:24], off offset:16         // 000000596B18: DC5E0010 177C0017
	s_waitcnt vmcnt(5)                                         // 000000596B20: BF8917F7
	v_cvt_f32_i32_e32 v27, v27                                 // 000000596B24: 7E360B1B
	s_waitcnt vmcnt(2)                                         // 000000596B28: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000596B2C: BF8701C1
	v_fma_mix_f32 v27, v28, v27, neg(0) op_sel_hi:[1,0,0]      // 000000596B30: CC20001B 8A02371C
	v_and_b32_e32 v29, 6, v8                                   // 000000596B38: 363A1086
	v_and_b32_e32 v4, 4, v8                                    // 000000596B3C: 36081084
	v_add_nc_u32_e32 v8, 32, v8                                // 000000596B40: 4A1010A0
	v_or_b32_e32 v31, 8, v29                                   // 000000596B44: 383E3A88
	v_or_b32_e32 v33, 16, v29                                  // 000000596B48: 38423A90
	v_or_b32_e32 v35, 24, v29                                  // 000000596B4C: 38463A98
	v_or_b32_e32 v30, 8, v4                                    // 000000596B50: 383C0888
	v_or_b32_e32 v32, 16, v4                                   // 000000596B54: 38400890
	v_or_b32_e32 v34, 24, v4                                   // 000000596B58: 38440898
	v_lshrrev_b32_e32 v36, v29, v11                            // 000000596B5C: 3248171D
	v_lshrrev_b32_e32 v37, v31, v11                            // 000000596B60: 324A171F
	v_lshrrev_b32_e32 v38, v33, v11                            // 000000596B64: 324C1721
	v_lshrrev_b32_e32 v39, v29, v12                            // 000000596B68: 324E191D
	v_lshrrev_b32_e32 v40, v31, v12                            // 000000596B6C: 3250191F
	v_lshrrev_b32_e32 v41, v33, v12                            // 000000596B70: 32521921
	v_lshrrev_b32_e32 v42, v29, v13                            // 000000596B74: 32541B1D
	v_lshrrev_b32_e32 v43, v31, v13                            // 000000596B78: 32561B1F
	v_lshrrev_b32_e32 v44, v33, v13                            // 000000596B7C: 32581B21
	v_lshrrev_b32_e32 v13, v35, v13                            // 000000596B80: 321A1B23
	v_lshrrev_b32_e32 v29, v29, v14                            // 000000596B84: 323A1D1D
	v_lshrrev_b32_e32 v31, v31, v14                            // 000000596B88: 323E1D1F
	v_lshrrev_b32_e32 v33, v33, v14                            // 000000596B8C: 32421D21
	v_lshrrev_b32_e32 v11, v35, v11                            // 000000596B90: 32161723
	v_lshrrev_b32_e32 v12, v35, v12                            // 000000596B94: 32181923
	v_lshrrev_b32_e32 v14, v35, v14                            // 000000596B98: 321C1D23
	v_bfe_u32 v28, v15, v4, 4                                  // 000000596B9C: D610001C 0212090F
	v_lshlrev_b32_e32 v35, 4, v36                              // 000000596BA4: 30464884
	v_bfe_u32 v36, v15, v30, 4                                 // 000000596BA8: D6100024 02123D0F
	v_bfe_u32 v45, v15, v32, 4                                 // 000000596BB0: D610002D 0212410F
	v_bfe_u32 v46, v16, v4, 4                                  // 000000596BB8: D610002E 02120910
	v_bfe_u32 v47, v16, v30, 4                                 // 000000596BC0: D610002F 02123D10
	v_bfe_u32 v48, v16, v32, 4                                 // 000000596BC8: D6100030 02124110
	v_bfe_u32 v49, v17, v4, 4                                  // 000000596BD0: D6100031 02120911
	v_bfe_u32 v50, v17, v30, 4                                 // 000000596BD8: D6100032 02123D11
	v_bfe_u32 v51, v17, v32, 4                                 // 000000596BE0: D6100033 02124111
	v_bfe_u32 v17, v17, v34, 4                                 // 000000596BE8: D6100011 02124511
	v_lshlrev_b32_e32 v13, 4, v13                              // 000000596BF0: 301A1A84
	v_bfe_u32 v4, v18, v4, 4                                   // 000000596BF4: D6100004 02120912
	v_lshlrev_b32_e32 v29, 4, v29                              // 000000596BFC: 303A3A84
	v_bfe_u32 v30, v18, v30, 4                                 // 000000596C00: D610001E 02123D12
	v_lshlrev_b32_e32 v31, 4, v31                              // 000000596C08: 303E3E84
	v_bfe_u32 v32, v18, v32, 4                                 // 000000596C0C: D6100020 02124112
	v_lshlrev_b32_e32 v33, 4, v33                              // 000000596C14: 30424284
	v_and_or_b32 v13, v13, 48, v17                             // 000000596C18: D657000D 0445610D
	v_and_or_b32 v4, v29, 48, v4                               // 000000596C20: D6570004 0411611D
	v_and_or_b32 v17, v31, 48, v30                             // 000000596C28: D6570011 0479611F
	v_bfe_u32 v18, v18, v34, 4                                 // 000000596C30: D6100012 02124512
	v_and_or_b32 v29, v33, 48, v32                             // 000000596C38: D657001D 04816121
	v_lshlrev_b32_e32 v14, 4, v14                              // 000000596C40: 301C1C84
	v_bfe_u32 v16, v16, v34, 4                                 // 000000596C44: D6100010 02124510
	v_subrev_nc_u32_e32 v17, 32, v17                           // 000000596C4C: 4E2222A0
	v_subrev_nc_u32_e32 v13, 32, v13                           // 000000596C50: 4E1A1AA0
	v_subrev_nc_u32_e32 v29, 32, v29                           // 000000596C54: 4E3A3AA0
	v_and_or_b32 v14, v14, 48, v18                             // 000000596C58: D657000E 0449610E
	v_subrev_nc_u32_e32 v4, 32, v4                             // 000000596C60: 4E0808A0
	v_cvt_f32_i32_e32 v17, v17                                 // 000000596C64: 7E220B11
	v_lshlrev_b32_e32 v12, 4, v12                              // 000000596C68: 30181884
	v_cvt_f32_i32_e32 v29, v29                                 // 000000596C6C: 7E3A0B1D
	v_lshlrev_b32_e32 v42, 4, v42                              // 000000596C70: 30545484
	v_subrev_nc_u32_e32 v14, 32, v14                           // 000000596C74: 4E1C1CA0
	v_mul_f32_e32 v17, v27, v17                                // 000000596C78: 1022231B
	v_and_or_b32 v12, v12, 48, v16                             // 000000596C7C: D657000C 0441610C
	v_mul_f32_e32 v29, v27, v29                                // 000000596C84: 103A3B1B
	v_and_or_b32 v16, v42, 48, v49                             // 000000596C88: D6570010 04C5612A
	v_cvt_f32_i32_e32 v14, v14                                 // 000000596C90: 7E1C0B0E
	v_lshlrev_b32_e32 v37, 4, v37                              // 000000596C94: 304A4A84
	v_subrev_nc_u32_e32 v12, 32, v12                           // 000000596C98: 4E1818A0
	v_lshlrev_b32_e32 v38, 4, v38                              // 000000596C9C: 304C4C84
	v_subrev_nc_u32_e32 v16, 32, v16                           // 000000596CA0: 4E2020A0
	v_bfe_u32 v15, v15, v34, 4                                 // 000000596CA4: D610000F 0212450F
	v_lshlrev_b32_e32 v43, 4, v43                              // 000000596CAC: 30565684
	v_lshlrev_b32_e32 v44, 4, v44                              // 000000596CB0: 30585884
	v_cvt_f32_i32_e32 v12, v12                                 // 000000596CB4: 7E180B0C
	v_lshlrev_b32_e32 v11, 4, v11                              // 000000596CB8: 30161684
	v_cvt_f32_i32_e32 v16, v16                                 // 000000596CBC: 7E200B10
	v_lshlrev_b32_e32 v39, 4, v39                              // 000000596CC0: 304E4E84
	v_cvt_f32_i32_e32 v13, v13                                 // 000000596CC4: 7E1A0B0D
	v_lshlrev_b32_e32 v40, 4, v40                              // 000000596CC8: 30505084
	v_cvt_f32_i32_e32 v4, v4                                   // 000000596CCC: 7E080B04
	v_dual_mul_f32 v14, v27, v14 :: v_dual_lshlrev_b32 v41, 4, v41// 000000596CD0: C8E21D1B 0E285284
	v_and_or_b32 v28, v35, 48, v28                             // 000000596CD8: D657001C 04716123
	v_and_or_b32 v34, v37, 48, v36                             // 000000596CE0: D6570022 04916125
	v_and_or_b32 v35, v38, 48, v45                             // 000000596CE8: D6570023 04B56126
	v_and_or_b32 v38, v43, 48, v50                             // 000000596CF0: D6570026 04C9612B
	v_mul_f32_e32 v12, v27, v12                                // 000000596CF8: 1018191B
	v_and_or_b32 v11, v11, 48, v15                             // 000000596CFC: D657000B 043D610B
	v_subrev_nc_u32_e32 v18, 32, v28                           // 000000596D04: 4E2438A0
	v_mul_f32_e32 v16, v27, v16                                // 000000596D08: 1020211B
	v_and_or_b32 v15, v39, 48, v46                             // 000000596D0C: D657000F 04B96127
	v_and_or_b32 v39, v44, 48, v51                             // 000000596D14: D6570027 04CD612C
	v_mul_f32_e32 v13, v27, v13                                // 000000596D1C: 101A1B1B
	v_and_or_b32 v36, v40, 48, v47                             // 000000596D20: D6570024 04BD6128
	v_mul_f32_e32 v4, v27, v4                                  // 000000596D28: 1008091B
	v_and_or_b32 v37, v41, 48, v48                             // 000000596D2C: D6570025 04C16129
	v_subrev_nc_u32_e32 v28, 32, v34                           // 000000596D34: 4E3844A0
	v_subrev_nc_u32_e32 v30, 32, v35                           // 000000596D38: 4E3C46A0
	v_subrev_nc_u32_e32 v11, 32, v11                           // 000000596D3C: 4E1616A0
	v_subrev_nc_u32_e32 v15, 32, v15                           // 000000596D40: 4E1E1EA0
	v_subrev_nc_u32_e32 v31, 32, v36                           // 000000596D44: 4E3E48A0
	v_subrev_nc_u32_e32 v32, 32, v37                           // 000000596D48: 4E404AA0
	v_subrev_nc_u32_e32 v33, 32, v38                           // 000000596D4C: 4E424CA0
	v_subrev_nc_u32_e32 v34, 32, v39                           // 000000596D50: 4E444EA0
	v_cvt_f32_i32_e32 v18, v18                                 // 000000596D54: 7E240B12
	v_cvt_f32_i32_e32 v28, v28                                 // 000000596D58: 7E380B1C
	v_cvt_f32_i32_e32 v30, v30                                 // 000000596D5C: 7E3C0B1E
	v_cvt_f32_i32_e32 v11, v11                                 // 000000596D60: 7E160B0B
	v_cvt_f32_i32_e32 v15, v15                                 // 000000596D64: 7E1E0B0F
	v_cvt_f32_i32_e32 v31, v31                                 // 000000596D68: 7E3E0B1F
	v_cvt_f32_i32_e32 v32, v32                                 // 000000596D6C: 7E400B20
	v_cvt_f32_i32_e32 v33, v33                                 // 000000596D70: 7E420B21
	v_cvt_f32_i32_e32 v34, v34                                 // 000000596D74: 7E440B22
	v_mul_f32_e32 v18, v27, v18                                // 000000596D78: 1024251B
	v_mul_f32_e32 v28, v27, v28                                // 000000596D7C: 1038391B
	v_mul_f32_e32 v30, v27, v30                                // 000000596D80: 103C3D1B
	v_mul_f32_e32 v11, v27, v11                                // 000000596D84: 1016171B
	v_mul_f32_e32 v15, v27, v15                                // 000000596D88: 101E1F1B
	v_mul_f32_e32 v31, v27, v31                                // 000000596D8C: 103E3F1B
	v_mul_f32_e32 v32, v27, v32                                // 000000596D90: 1040411B
	v_mul_f32_e32 v33, v27, v33                                // 000000596D94: 1042431B
	v_mul_f32_e32 v34, v27, v34                                // 000000596D98: 1044451B
	v_bfe_u32 v27, v18, 16, 1                                  // 000000596D9C: D610001B 02052112
	v_bfe_u32 v35, v28, 16, 1                                  // 000000596DA4: D6100023 0205211C
	v_bfe_u32 v36, v30, 16, 1                                  // 000000596DAC: D6100024 0205211E
	v_bfe_u32 v37, v11, 16, 1                                  // 000000596DB4: D6100025 0205210B
	v_bfe_u32 v38, v15, 16, 1                                  // 000000596DBC: D6100026 0205210F
	v_add3_u32 v18, v18, v27, 0x7fff                           // 000000596DC4: D6550012 03FE3712 00007FFF
	v_add3_u32 v28, v28, v35, 0x7fff                           // 000000596DD0: D655001C 03FE471C 00007FFF
	v_add3_u32 v30, v30, v36, 0x7fff                           // 000000596DDC: D655001E 03FE491E 00007FFF
	v_bfe_u32 v39, v31, 16, 1                                  // 000000596DE8: D6100027 0205211F
	v_add3_u32 v11, v11, v37, 0x7fff                           // 000000596DF0: D655000B 03FE4B0B 00007FFF
	.long 0x7e383992                                           // 000000596DFC: 7E383992
	v_bfe_u32 v40, v32, 16, 1                                  // 000000596E00: D6100028 02052120
	v_add3_u32 v15, v15, v38, 0x7fff                           // 000000596E08: D655000F 03FE4D0F 00007FFF
	.long 0x7e16399e                                           // 000000596E14: 7E16399E
	v_bfe_u32 v41, v12, 16, 1                                  // 000000596E18: D6100029 0205210C
	s_waitcnt vmcnt(1)                                         // 000000596E20: BF8907F7
	v_dot2_f32_bf16 v19, v19, v28, 0                           // 000000596E24: CC1A4013 1A023913
	v_add3_u32 v30, v31, v39, 0x7fff                           // 000000596E2C: D655001E 03FE4F1F 00007FFF
	v_bfe_u32 v27, v16, 16, 1                                  // 000000596E38: D610001B 02052110
	v_add3_u32 v31, v32, v40, 0x7fff                           // 000000596E40: D655001F 03FE5120 00007FFF
	.long 0x7e3c398f                                           // 000000596E4C: 7E3C398F
	v_dot2_f32_bf16 v11, v20, v11, v19                         // 000000596E50: CC1A400B 1C4E1714
	v_bfe_u32 v42, v33, 16, 1                                  // 000000596E58: D610002A 02052121
	v_add3_u32 v12, v12, v41, 0x7fff                           // 000000596E60: D655000C 03FE530C 00007FFF
	v_bfe_u32 v18, v34, 16, 1                                  // 000000596E6C: D6100012 02052122
	v_add3_u32 v16, v16, v27, 0x7fff                           // 000000596E74: D6550010 03FE3710 00007FFF
	.long 0x7e18399f                                           // 000000596E80: 7E18399F
	v_dot2_f32_bf16 v11, v21, v30, v11                         // 000000596E84: CC1A400B 1C2E3D15
	v_bfe_u32 v28, v13, 16, 1                                  // 000000596E8C: D610001C 0205210D
	v_add3_u32 v20, v33, v42, 0x7fff                           // 000000596E94: D6550014 03FE5521 00007FFF
	v_bfe_u32 v15, v4, 16, 1                                   // 000000596EA0: D610000F 02052104
	v_add3_u32 v18, v34, v18, 0x7fff                           // 000000596EA8: D6550012 03FE2522 00007FFF
	.long 0x7e283990                                           // 000000596EB4: 7E283990
	v_dot2_f32_bf16 v11, v22, v12, v11                         // 000000596EB8: CC1A400B 1C2E1916
	v_bfe_u32 v19, v17, 16, 1                                  // 000000596EC0: D6100013 02052111
	v_add3_u32 v13, v13, v28, 0x7fff                           // 000000596EC8: D655000D 03FE390D 00007FFF
	v_bfe_u32 v12, v29, 16, 1                                  // 000000596ED4: D610000C 0205211D
	v_add3_u32 v4, v4, v15, 0x7fff                             // 000000596EDC: D6550004 03FE1F04 00007FFF
	.long 0x7e1a3992                                           // 000000596EE8: 7E1A3992
	s_waitcnt vmcnt(0)                                         // 000000596EEC: BF8903F7
	v_dot2_f32_bf16 v11, v23, v20, v11                         // 000000596EF0: CC1A400B 1C2E2917
	v_bfe_u32 v15, v14, 16, 1                                  // 000000596EF8: D610000F 0205210E
	v_add3_u32 v16, v17, v19, 0x7fff                           // 000000596F00: D6550010 03FE2711 00007FFF
	v_add3_u32 v12, v29, v12, 0x7fff                           // 000000596F0C: D655000C 03FE191D 00007FFF
	.long 0x7e203984                                           // 000000596F18: 7E203984
	v_dot2_f32_bf16 v4, v24, v13, v11                          // 000000596F1C: CC1A4004 1C2E1B18
	v_add3_u32 v11, v14, v15, 0x7fff                           // 000000596F24: D655000B 03FE1F0E 00007FFF
	v_cmp_ge_i32_e32 vcc_lo, v8, v9                            // 000000596F30: 7C8C1308
	.long 0x7e16398c                                           // 000000596F34: 7E16398C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000596F38: BF8700A4
	v_dot2_f32_bf16 v4, v25, v16, v4                           // 000000596F3C: CC1A4004 1C122119
	s_or_b32 s3, vcc_lo, s3                                    // 000000596F44: 8C03036A
	v_dot2_f32_bf16 v4, v26, v11, v4                           // 000000596F48: CC1A4004 1C12171A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000596F50: BF870001
	v_add_f32_e32 v10, v10, v4                                 // 000000596F54: 0614090A
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000596F58: 917E037E
	s_cbranch_execnz 65194                                     // 000000596F5C: BFA6FEAA <_ZN7halogen12_GLOBAL__N_16k_lq6kILi1ELi32ELi2ELb0EEEvPKhPKtPvll+0x108>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000596F60: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000596F64: BF8700B9
	s_or_b32 exec_lo, exec_lo, s2                              // 000000596F68: 8C7E027E
	.long 0xd71f0001                                           // 000000596F6C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000596F70: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000596F74: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000596F78: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 000000596F7C: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 000000596F80: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000596F84: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000596F88: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000596F8C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 000000596F90: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 000000596F94: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000596F98: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000596F9C: BF870002
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000596FA0: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000596FA4: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000596FA8: 02080901
	ds_bpermute_b32 v2, v2, v10                                // 000000596FAC: DACC0000 02000A02
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000596FB4: 30080882
	s_waitcnt lgkmcnt(0)                                       // 000000596FB8: BF89FC07
	v_add_f32_e32 v2, v10, v2                                  // 000000596FBC: 0604050A
	ds_bpermute_b32 v3, v3, v2                                 // 000000596FC0: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 000000596FC8: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000596FCC: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 000000596FD0: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 000000596FD8: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000596FDC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000596FE0: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000596FE4: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000596FE8: 30080882
	s_waitcnt lgkmcnt(0)                                       // 000000596FEC: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000596FF0: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 000000596FF4: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 000000596FFC: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000597000: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000597004: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 000000597008: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 00000059700C: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 000000597014: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 000000597018: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v7                                    // 000000597020: 7D940E80
	s_cbranch_execz 8                                          // 000000597024: BFA50008 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi1ELi32ELi2ELb0EEEvPKhPKtPvll+0x748>
	v_lshlrev_b32_e32 v3, 2, v5                                // 000000597028: 30060A82
	s_waitcnt lgkmcnt(0)                                       // 00000059702C: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 000000597030: 06020501
	s_delay_alu instid0(VALU_DEP_2)                            // 000000597034: BF870002
	v_lshl_or_b32 v2, v6, 3, v3                                // 000000597038: D6560002 040D0706
	ds_store_b32 v2, v1                                        // 000000597040: D8340000 00000102
	s_or_b32 exec_lo, exec_lo, s0                              // 000000597048: 8C7E007E
	v_or_b32_e32 v1, s12, v0                                   // 00000059704C: 3802000C
	s_waitcnt lgkmcnt(0)                                       // 000000597050: BF89FC07
	v_mov_b32_e32 v2, s13                                      // 000000597054: 7E04020D
	.long 0xd44c0000                                           // 000000597058: D44C0000
	v_cndmask_b32_e32 v1, 4, v0, vcc_lo                        // 00000059705C: 02020084
	s_barrier                                                  // 000000597060: BFBD0000
	buffer_gl0_inv                                             // 000000597064: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[14:15], v[1:2]                  // 00000059706C: 7CA8020E
	s_and_b32 s0, s0, vcc_lo                                   // 000000597070: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000597074: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000597078: BE812000
	s_cbranch_execz 22                                         // 00000059707C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi1ELi32ELi2ELb0EEEvPKhPKtPvll+0x7d8>
	v_lshlrev_b32_e32 v0, 3, v0                                // 000000597080: 30000083
	ds_load_b64 v[3:4], v0                                     // 000000597084: D9D80000 03000000
	s_waitcnt lgkmcnt(0)                                       // 00000059708C: BF89FC07
	v_add_f32_e32 v0, 0, v3                                    // 000000597090: 06000680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000597094: BF870121
	v_add_f32_e32 v3, v0, v4                                   // 000000597098: 06060900
	.long 0xd73c0000                                           // 00000059709C: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000005970A0: 02020281
	v_bfe_u32 v4, v3, 16, 1                                    // 0000005970A4: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005970AC: BF870092
	.long 0xd7006a00                                           // 0000005970B0: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000005970B4: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000005970B8: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005970C0: BF870003
	v_add3_u32 v2, v3, v4, 0x7fff                              // 0000005970C4: D6550002 03FE0903 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000005970D0: DC960000 007C0200
	s_endpgm                                                   // 0000005970D8: BFB00000
		...

