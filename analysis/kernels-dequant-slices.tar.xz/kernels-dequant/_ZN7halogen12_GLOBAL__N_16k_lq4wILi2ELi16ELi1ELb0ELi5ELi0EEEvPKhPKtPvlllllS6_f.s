00000000008b9900 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008B9900: F4100100 F8000000
	v_and_b32_e32 v16, 15, v0                                  // 0000008B9908: 3620008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000008B990C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 0000008B9910: 86039F02
	.long 0x7f103880                                           // 0000008B9914: 7F103880
	s_lshl_b64 s[2:3], s[2:3], 4                               // 0000008B9918: 84828402
	v_mov_b32_e32 v17, 0                                       // 0000008B991C: 7E220280
	v_dual_mov_b32 v10, s3 :: v_dual_lshlrev_b32 v3, 2, v1     // 0000008B9920: CA220003 0A020282
	v_or_b32_e32 v9, s2, v1                                    // 0000008B9928: 38120202
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v2, 2, v16      // 0000008B992C: CA220080 01022082
	s_waitcnt lgkmcnt(0)                                       // 0000008B9934: BF89FC07
	s_clause 0x1                                               // 0000008B9938: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 0000008B993C: DC520000 04040002
	global_load_b32 v7, v3, s[4:5]                             // 0000008B9944: DC520000 07040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 0000008B994C: 7CA8120C
	s_add_u32 s14, s4, s14                                     // 0000008B9950: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000008B9954: 820F0F05
	s_lshr_b32 s2, s11, 31                                     // 0000008B9958: 85029F0B
	v_mov_b32_e32 v18, 0                                       // 0000008B995C: 7E240280
	s_add_u32 s20, s10, s2                                     // 0000008B9960: 8014020A
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 0000008B9964: 02161280
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 0000008B9968: D501000E 01A80680
	s_addc_u32 s21, s11, 0                                     // 0000008B9970: 8215800B
	s_ashr_i32 s22, s11, 31                                    // 0000008B9974: 86169F0B
	s_ashr_i64 s[2:3], s[20:21], 1                             // 0000008B9978: 86828114
	.long 0xd72c000d                                           // 0000008B997C: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 0000008B9980: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 0000008B9984: D6FE7C05 02021612
	.long 0xd72c000f                                           // 0000008B998C: D72C000F
	v_cndmask_b32_e32 v0, v11, v3, vcc_lo                      // 0000008B9990: 0200070B
	.long 0xd72c0014                                           // 0000008B9994: D72C0014
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 0000008B9998: 0200050E
	.long 0xd72c000e                                           // 0000008B999C: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000008B99A0: 02021C12
	s_lshr_b32 s19, s22, 27                                    // 0000008B99A4: 85139B16
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 0000008B99A8: CA100080 02020080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008B99B0: BF870152
	v_add3_u32 v6, v6, v14, v13                                // 0000008B99B4: D6550006 04361D06
	s_waitcnt vmcnt(1)                                         // 0000008B99BC: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 0000008B99C0: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 0000008B99C8: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 0000008B99CC: D6100013 02052107
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000008B99D4: D6550004 03FE1904 00007FFF
	v_mad_u64_u32 v[11:12], null, v11, s2, s[14:15]            // 0000008B99E0: D6FE7C0B 0038050B
	s_add_u32 s14, s10, s19                                    // 0000008B99E8: 800E130A
	v_add3_u32 v7, v7, v19, 0x7fff                             // 0000008B99EC: D6550007 03FE2707 00007FFF
	s_addc_u32 s15, s11, 0                                     // 0000008B99F8: 820F800B
	.long 0x7e103984                                           // 0000008B99FC: 7E103984
	s_lshr_b64 s[14:15], s[14:15], 5                           // 0000008B9A00: 858E850E
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v19, 2, v0      // 0000008B9A04: CA220080 04120082
	.long 0xd4440002                                           // 0000008B9A0C: D4440002
	v_cndmask_b32_e32 v1, s14, v16, vcc_lo                     // 0000008B9A10: 0202200E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008B9A14: BF870003
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 0000008B9A18: D6570007 04220EFF FFFF0000
	v_add3_u32 v0, v20, v12, v15                               // 0000008B9A24: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 0000008B9A2C: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 0000008B9A34: BF89FC07
	s_barrier                                                  // 0000008B9A38: BFBD0000
	buffer_gl0_inv                                             // 0000008B9A3C: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 0000008B9A44: BE8F2002
	s_cbranch_execz 26                                         // 0000008B9A48: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x1b4>
	s_add_u32 s3, s4, s16                                      // 0000008B9A4C: 80031004
	s_addc_u32 s18, s5, s17                                    // 0000008B9A50: 82121105
	v_lshlrev_b32_e32 v1, 1, v16                               // 0000008B9A54: 30022081
	.long 0xd7000302                                           // 0000008B9A58: D7000302
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 0000008B9A5C: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B9A60: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s18, v6, s3                  // 0000008B9A64: D5207C03 000E0C12
	v_lshlrev_b32_e32 v4, 4, v16                               // 0000008B9A6C: 30082084
	.long 0xd7000301                                           // 0000008B9A70: D7000301
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000008B9A74: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008B9A78: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s3                    // 0000008B9A7C: D5207C02 000E0680
	.long 0xd7000303                                           // 0000008B9A84: D7000303
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 0000008B9A88: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B9A8C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s3                    // 0000008B9A90: D5207C04 000E0080
	s_clause 0x1                                               // 0000008B9A98: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 0000008B9A9C: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000008B9AA4: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000008B9AAC: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 0000008B9AB0: 7E241707
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008B9AB4: 8C7E0F7E
	v_mov_b32_e32 v19, 0                                       // 0000008B9AB8: 7E260280
	s_and_saveexec_b32 s15, s2                                 // 0000008B9ABC: BE8F2002
	s_cbranch_execz 281                                        // 0000008B9AC0: BFA50119 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x628>
	v_dual_mov_b32 v22, v18 :: v_dual_lshlrev_b32 v7, 1, v16   // 0000008B9AC4: CA220112 16062081
	.long 0xd7000205                                           // 0000008B9ACC: D7000205
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 0000008B9AD0: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B9AD4: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s2                  // 0000008B9AD8: D5207C06 000A0C11
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 0000008B9AE0: CA220080 0D0C2085
	.long 0xd7000205                                           // 0000008B9AE8: D7000205
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000008B9AEC: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B9AF0: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s2                    // 0000008B9AF4: D5207C06 000A0C80
	v_lshl_or_b32 v20, v16, 4, 0x100                           // 0000008B9AFC: D6560014 03FD0910 00000100
	.long 0xd7000205                                           // 0000008B9B08: D7000205
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000008B9B0C: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B9B10: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s2                   // 0000008B9B14: D5207C06 000A0C05
	v_mov_b32_e32 v21, v16                                     // 0000008B9B1C: 7E2A0310
	.long 0xd700020e                                           // 0000008B9B20: D700020E
	v_cndmask_b32_e32 v0, v5, v160, vcc_lo                     // 0000008B9B24: 02014105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B9B28: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s2                   // 0000008B9B2C: D5207C0F 000A0C80
	v_mov_b32_e32 v19, v13                                     // 0000008B9B34: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 0000008B9B38: 7E22030D
	s_mov_b32 s16, 0                                           // 0000008B9B3C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000008B9B40: 8484810A
	s_branch 222                                               // 0000008B9B44: BFA000DE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x5c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000008B9B48: 8C7E0A7E
	.long 0xd73c0017                                           // 0000008B9B4C: D73C0017
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000008B9B50: 02021881
	v_and_b32_e32 v55, 0xff, v1                                // 0000008B9B54: 366E02FF 000000FF
	v_lshrrev_b32_e32 v56, 6, v1                               // 0000008B9B5C: 32700286
	v_lshrrev_b32_e32 v57, 14, v1                              // 0000008B9B60: 3272028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000008B9B64: 32020296
	v_and_b32_e32 v58, 0xff, v2                                // 0000008B9B68: 367404FF 000000FF
	.long 0xd700032f                                           // 0000008B9B70: D700032F
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008B9B74: 02022E06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B9B78: BF8701A1
	v_add_co_ci_u32_e64 v48, null, s7, v24, s3                 // 0000008B9B7C: D5207C30 000E3007
	v_lshlrev_b32_e32 v55, 2, v55                              // 0000008B9B84: 306E6E82
	.long 0xd7000333                                           // 0000008B9B88: D7000333
	v_cndmask_b32_e32 v0, v47, v4, vcc_lo                      // 0000008B9B8C: 0200092F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B9B90: BF870001
	v_add_co_ci_u32_e64 v52, null, s5, v48, s3                 // 0000008B9B94: D5207C34 000E6005
	v_and_b32_e32 v56, 0x3fc, v56                              // 0000008B9B9C: 367070FF 000003FC
	ds_load_b32 v55, v55                                       // 0000008B9BA4: D8D80000 37000037
	s_clause 0x7                                               // 0000008B9BAC: BF850007
	global_load_b128 v[23:26], v[47:48], off                   // 0000008B9BB0: DC5E0000 177C002F
	global_load_b128 v[27:30], v[51:52], off                   // 0000008B9BB8: DC5E0000 1B7C0033
	global_load_b128 v[31:34], v[47:48], off offset:16         // 0000008B9BC0: DC5E0010 1F7C002F
	global_load_b128 v[35:38], v[51:52], off offset:16         // 0000008B9BC8: DC5E0010 237C0033
	global_load_b128 v[39:42], v[47:48], off offset:32         // 0000008B9BD0: DC5E0020 277C002F
	global_load_b128 v[43:46], v[51:52], off offset:32         // 0000008B9BD8: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[47:48], off offset:48         // 0000008B9BE0: DC5E0030 2F7C002F
	global_load_b128 v[51:54], v[51:52], off offset:48         // 0000008B9BE8: DC5E0030 337C0033
	v_and_b32_e32 v57, 0x3fc, v57                              // 0000008B9BF0: 367272FF 000003FC
	v_lshrrev_b32_e32 v59, 6, v2                               // 0000008B9BF8: 32760486
	ds_load_b32 v56, v56                                       // 0000008B9BFC: D8D80000 38000038
	v_lshrrev_b32_e32 v60, 14, v2                              // 0000008B9C04: 3278048E
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000008B9C08: 32040496
	ds_load_b32 v57, v57                                       // 0000008B9C0C: D8D80000 39000039
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008B9C14: 360202FF 000003FC
	v_lshlrev_b32_e32 v58, 2, v58                              // 0000008B9C1C: 30747482
	v_and_b32_e32 v59, 0x3fc, v59                              // 0000008B9C20: 367676FF 000003FC
	v_and_b32_e32 v60, 0x3fc, v60                              // 0000008B9C28: 367878FF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000008B9C30: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000008B9C38: D8D80000 01000001
	ds_load_b32 v58, v58                                       // 0000008B9C40: D8D80000 3A00003A
	ds_load_b32 v59, v59                                       // 0000008B9C48: D8D80000 3B00003B
	ds_load_b32 v60, v60                                       // 0000008B9C50: D8D80000 3C00003C
	ds_load_b32 v2, v2                                         // 0000008B9C58: D8D80000 02000002
	s_and_b32 s3, exec_lo, s2                                  // 0000008B9C60: 8B03027E
	.long 0xd700020e                                           // 0000008B9C64: D700020E
	v_cndmask_b32_e32 v0, v14, v160, vcc_lo                    // 0000008B9C68: 0201410E
	v_add_nc_u32_e32 v12, 0x200, v12                           // 0000008B9C6C: 4A1818FF 00000200
	v_add_nc_u32_e32 v20, 0x100, v20                           // 0000008B9C74: 4A2828FF 00000100
	v_add_co_ci_u32_e64 v15, null, 0, v15, s2                  // 0000008B9C7C: D5207C0F 000A1E80
	s_or_b32 s16, s3, s16                                      // 0000008B9C84: 8C101003
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000008B9C88: BF891C77
	v_dot2_f32_bf16 v23, v23, v55, 0                           // 0000008B9C8C: CC1A4017 1A026F17
	s_waitcnt vmcnt(6)                                         // 0000008B9C94: BF891BF7
	v_dot2_f32_bf16 v27, v27, v55, 0                           // 0000008B9C98: CC1A401B 1A026F1B
	v_and_b32_e32 v55, 0xff, v3                                // 0000008B9CA0: 366E06FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 0000008B9CA8: BF89FC67
	v_dot2_f32_bf16 v23, v24, v56, v23                         // 0000008B9CAC: CC1A4017 1C5E7118
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008B9CB4: BF870003
	v_dot2_f32_bf16 v24, v28, v56, v27                         // 0000008B9CB8: CC1A4018 1C6E711C
	v_lshrrev_b32_e32 v27, 6, v3                               // 0000008B9CC0: 32360686
	v_lshrrev_b32_e32 v28, 14, v3                              // 0000008B9CC4: 3238068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000008B9CC8: 32060696
	s_waitcnt lgkmcnt(5)                                       // 0000008B9CCC: BF89FC57
	v_dot2_f32_bf16 v23, v25, v57, v23                         // 0000008B9CD0: CC1A4017 1C5E7319
	v_dot2_f32_bf16 v24, v29, v57, v24                         // 0000008B9CD8: CC1A4018 1C62731D
	v_and_b32_e32 v25, 0xff, v4                                // 0000008B9CE0: 363208FF 000000FF
	v_lshrrev_b32_e32 v29, 6, v4                               // 0000008B9CE8: 323A0886
	v_lshrrev_b32_e32 v56, 14, v4                              // 0000008B9CEC: 3270088E
	s_waitcnt lgkmcnt(4)                                       // 0000008B9CF0: BF89FC47
	v_dot2_f32_bf16 v23, v26, v1, v23                          // 0000008B9CF4: CC1A4017 1C5E031A
	v_dot2_f32_bf16 v1, v30, v1, v24                           // 0000008B9CFC: CC1A4001 1C62031E
	v_lshlrev_b32_e32 v24, 2, v55                              // 0000008B9D04: 30306E82
	v_and_b32_e32 v26, 0x3fc, v27                              // 0000008B9D08: 363436FF 000003FC
	v_and_b32_e32 v27, 0x3fc, v28                              // 0000008B9D10: 363638FF 000003FC
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000008B9D18: BF891437
	v_dot2_f32_bf16 v23, v31, v58, v23                         // 0000008B9D1C: CC1A4017 1C5E751F
	s_waitcnt vmcnt(4)                                         // 0000008B9D24: BF8913F7
	v_dot2_f32_bf16 v1, v35, v58, v1                           // 0000008B9D28: CC1A4001 1C067523
	ds_load_b32 v24, v24                                       // 0000008B9D30: D8D80000 18000018
	ds_load_b32 v26, v26                                       // 0000008B9D38: D8D80000 1A00001A
	ds_load_b32 v27, v27                                       // 0000008B9D40: D8D80000 1B00001B
	s_waitcnt lgkmcnt(5)                                       // 0000008B9D48: BF89FC57
	v_dot2_f32_bf16 v23, v32, v59, v23                         // 0000008B9D4C: CC1A4017 1C5E7720
	v_dot2_f32_bf16 v1, v36, v59, v1                           // 0000008B9D54: CC1A4001 1C067724
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000008B9D5C: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000008B9D60: 360606FF 000003FC
	v_lshlrev_b32_e32 v25, 2, v25                              // 0000008B9D68: 30323282
	s_waitcnt lgkmcnt(4)                                       // 0000008B9D6C: BF89FC47
	v_dot2_f32_bf16 v23, v33, v60, v23                         // 0000008B9D70: CC1A4017 1C5E7921
	v_dot2_f32_bf16 v1, v37, v60, v1                           // 0000008B9D78: CC1A4001 1C067925
	v_and_b32_e32 v28, 0x3fc, v29                              // 0000008B9D80: 36383AFF 000003FC
	v_and_b32_e32 v29, 0x3fc, v56                              // 0000008B9D88: 363A70FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008B9D90: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000008B9D98: BF89FC37
	v_dot2_f32_bf16 v23, v34, v2, v23                          // 0000008B9D9C: CC1A4017 1C5E0522
	v_dot2_f32_bf16 v1, v38, v2, v1                            // 0000008B9DA4: CC1A4001 1C060526
	ds_load_b32 v2, v3                                         // 0000008B9DAC: D8D80000 02000003
	ds_load_b32 v3, v25                                        // 0000008B9DB4: D8D80000 03000019
	ds_load_b32 v25, v28                                       // 0000008B9DBC: D8D80000 1900001C
	ds_load_b32 v28, v29                                       // 0000008B9DC4: D8D80000 1C00001D
	ds_load_b32 v29, v4                                        // 0000008B9DCC: D8D80000 1D000004
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 0000008B9DD4: BF890C77
	v_dot2_f32_bf16 v4, v39, v24, v23                          // 0000008B9DD8: CC1A4004 1C5E3127
	s_waitcnt vmcnt(2)                                         // 0000008B9DE0: BF890BF7
	v_dot2_f32_bf16 v1, v43, v24, v1                           // 0000008B9DE4: CC1A4001 1C06312B
	s_waitcnt lgkmcnt(6)                                       // 0000008B9DEC: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008B9DF0: BF870112
	v_dot2_f32_bf16 v4, v40, v26, v4                           // 0000008B9DF4: CC1A4004 1C123528
	v_dot2_f32_bf16 v1, v44, v26, v1                           // 0000008B9DFC: CC1A4001 1C06352C
	s_waitcnt lgkmcnt(5)                                       // 0000008B9E04: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008B9E08: BF870112
	v_dot2_f32_bf16 v4, v41, v27, v4                           // 0000008B9E0C: CC1A4004 1C123729
	v_dot2_f32_bf16 v1, v45, v27, v1                           // 0000008B9E14: CC1A4001 1C06372D
	s_waitcnt lgkmcnt(4)                                       // 0000008B9E1C: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008B9E20: BF870112
	v_dot2_f32_bf16 v4, v42, v2, v4                            // 0000008B9E24: CC1A4004 1C12052A
	v_dot2_f32_bf16 v1, v46, v2, v1                            // 0000008B9E2C: CC1A4001 1C06052E
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000008B9E34: BF890437
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008B9E38: BF870122
	v_dot2_f32_bf16 v2, v47, v3, v4                            // 0000008B9E3C: CC1A4002 1C12072F
	s_waitcnt vmcnt(0)                                         // 0000008B9E44: BF8903F7
	v_dot2_f32_bf16 v1, v51, v3, v1                            // 0000008B9E48: CC1A4001 1C060733
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 0000008B9E50: CA100108 04020107
	s_waitcnt lgkmcnt(2)                                       // 0000008B9E58: BF89FC27
	v_dot2_f32_bf16 v2, v48, v25, v2                           // 0000008B9E5C: CC1A4002 1C0A3330
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008B9E64: BF870123
	v_dot2_f32_bf16 v1, v52, v25, v1                           // 0000008B9E68: CC1A4001 1C063334
	s_waitcnt lgkmcnt(1)                                       // 0000008B9E70: BF89FC17
	v_dot2_f32_bf16 v2, v49, v28, v2                           // 0000008B9E74: CC1A4002 1C0A3931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008B9E7C: BF870122
	v_dot2_f32_bf16 v1, v53, v28, v1                           // 0000008B9E80: CC1A4001 1C063935
	s_waitcnt lgkmcnt(0)                                       // 0000008B9E88: BF89FC07
	v_dot2_f32_bf16 v8, v50, v29, v2                           // 0000008B9E8C: CC1A4008 1C0A3B32
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B9E94: BF8701A2
	v_dot2_f32_bf16 v23, v54, v29, v1                          // 0000008B9E98: CC1A4017 1C063B36
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 0000008B9EA0: CA100106 02000105
	v_fmac_f32_e32 v19, v18, v8                                // 0000008B9EA8: 56261112
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008B9EAC: BF870003
	v_fmac_f32_e32 v17, v18, v23                               // 0000008B9EB0: 56222F12
	v_mov_b32_e32 v18, v22                                     // 0000008B9EB4: 7E240316
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008B9EB8: 917E107E
	s_cbranch_execz 25                                         // 0000008B9EBC: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x624>
	s_waitcnt vmcnt(0)                                         // 0000008B9EC0: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v21, 16, v21    // 0000008B9EC4: CA200102 06142A90
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000008B9ECC: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000008B9ED4: 7E0E0303
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008B9ED8: BF870003
	.long 0xd4430002                                           // 0000008B9EDC: D4430002
	v_cndmask_b32_e32 v1, s14, v21, vcc_lo                     // 0000008B9EE0: 02022A0E
	s_mov_b32 s10, exec_lo                                     // 0000008B9EE4: BE8A007E
	.long 0xd4c4007e                                           // 0000008B9EE8: D4C4007E
	v_cndmask_b32_e32 v1, s14, v21, vcc_lo                     // 0000008B9EEC: 02022A0E
	s_cbranch_execz 65301                                      // 0000008B9EF0: BFA5FF15 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x248>
	.long 0xd7000305                                           // 0000008B9EF4: D7000305
	v_cndmask_b32_e32 v1, v11, v20, vcc_lo                     // 0000008B9EF8: 0202290B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B9EFC: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s3                    // 0000008B9F00: D5207C06 000E0080
	global_load_d16_b16 v22, v[14:15], off                     // 0000008B9F08: DC820000 167C000E
	global_load_b128 v[5:8], v[5:6], off                       // 0000008B9F10: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 0000008B9F18: BF8907F7
	v_cvt_f32_f16_e32 v22, v22                                 // 0000008B9F1C: 7E2C1716
	s_branch 65289                                             // 0000008B9F20: BFA0FF09 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x248>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000008B9F24: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008B9F28: BF8700B9
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008B9F2C: 8C7E0F7E
	.long 0xd71f0000                                           // 0000008B9F30: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008B9F34: 020100C1
	s_waitcnt vmcnt(0)                                         // 0000008B9F38: BF8903F7
	v_xor_b32_e32 v1, 8, v0                                    // 0000008B9F3C: 3A020088
	v_xor_b32_e32 v3, 4, v0                                    // 0000008B9F40: 3A060084
	v_xor_b32_e32 v5, 2, v0                                    // 0000008B9F44: 3A0A0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B9F48: BF870093
	.long 0xd44c0002                                           // 0000008B9F4C: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000008B9F50: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 0000008B9F54: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008B9F5C: BF870114
	.long 0xd44c0002                                           // 0000008B9F60: D44C0002
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000008B9F64: 020206A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008B9F68: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008B9F6C: BF870002
	v_cndmask_b32_e64 v3, v0, v3, s2                           // 0000008B9F70: D5010003 000A0700
	.long 0xd44c0002                                           // 0000008B9F78: D44C0002
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000008B9F7C: 02020AA0
	ds_bpermute_b32 v2, v1, v19                                // 0000008B9F80: DACC0000 02001301
	v_cndmask_b32_e64 v5, v0, v5, s2                           // 0000008B9F88: D5010005 000A0B00
	s_waitcnt lgkmcnt(0)                                       // 0000008B9F90: BF89FC07
	v_dual_add_f32 v2, v19, v2 :: v_dual_lshlrev_b32 v3, 2, v3 // 0000008B9F94: C9220513 02020682
	ds_bpermute_b32 v1, v1, v17                                // 0000008B9F9C: DACC0000 01001101
	ds_bpermute_b32 v4, v3, v2                                 // 0000008B9FA4: DACC0000 04000203
	s_waitcnt lgkmcnt(0)                                       // 0000008B9FAC: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v1, v17, v1    // 0000008B9FB0: C9080902 02000311
	ds_bpermute_b32 v3, v3, v1                                 // 0000008B9FB8: DACC0000 03000103
	s_waitcnt lgkmcnt(0)                                       // 0000008B9FC0: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 0000008B9FC4: 06020701
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008B9FC8: 300A0A82
	ds_bpermute_b32 v3, v5, v2                                 // 0000008B9FCC: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000008B9FD4: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 0000008B9FDC: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B9FE0: BF870091
	.long 0xd44c0002                                           // 0000008B9FE4: D44C0002
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000008B9FE8: 02020AA0
	v_cndmask_b32_e64 v0, v0, v5, s2                           // 0000008B9FEC: D5010000 000A0B00
	.long 0xd44a0002                                           // 0000008B9FF4: D44A0002
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 0000008B9FF8: 02022080
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008B9FFC: BF870002
	v_lshlrev_b32_e32 v5, 2, v0                                // 0000008BA000: 300A0082
	s_and_b32 s2, s2, vcc_lo                                   // 0000008BA004: 8B026A02
	s_waitcnt lgkmcnt(1)                                       // 0000008BA008: BF89FC17
	v_add_f32_e32 v2, v2, v3                                   // 0000008BA00C: 06040702
	s_waitcnt lgkmcnt(0)                                       // 0000008BA010: BF89FC07
	v_add_f32_e32 v0, v1, v4                                   // 0000008BA014: 06000901
	ds_bpermute_b32 v3, v5, v2                                 // 0000008BA018: DACC0000 03000205
	ds_bpermute_b32 v1, v5, v0                                 // 0000008BA020: DACC0000 01000005
	s_and_saveexec_b32 s3, s2                                  // 0000008BA028: BE832002
	s_cbranch_execz 74                                         // 0000008BA02C: BFA5004A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x858>
	v_ashrrev_i32_e32 v4, 31, v10                              // 0000008BA030: 3408149F
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008BA034: F4040080 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000008BA03C: BF89FC07
	v_add_f32_e32 v8, v2, v3                                   // 0000008BA040: 06100702
	v_mov_b32_e32 v6, s9                                       // 0000008BA044: 7E0C0209
	s_lshr_b32 s0, s13, 31                                     // 0000008BA048: 85009F0D
	v_lshrrev_b32_e32 v4, 23, v4                               // 0000008BA04C: 32080897
	s_add_u32 s1, s12, s0                                      // 0000008BA050: 8001000C
	s_addc_u32 s4, s13, 0                                      // 0000008BA054: 8204800D
	v_mov_b32_e32 v7, s8                                       // 0000008BA058: 7E0E0208
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BA05C: BF870092
	.long 0xd7006a04                                           // 0000008BA060: D7006A04
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 0000008BA064: 02020909
	v_add_co_ci_u32_e64 v5, null, 0, v10, vcc_lo               // 0000008BA068: D5207C05 01AA1480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BA070: BF870092
	v_and_b32_e32 v4, 0xfffffe00, v4                           // 0000008BA074: 360808FF FFFFFE00
	.long 0xd7016a02                                           // 0000008BA07C: D7016A02
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 0000008BA080: 02020909
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BA084: BF8701A1
	v_sub_co_ci_u32_e64 v3, null, v10, v5, vcc_lo              // 0000008BA088: D5217C03 01AA0B0A
	v_add_f32_e32 v9, v0, v1                                   // 0000008BA090: 06120300
	.long 0xd7000000                                           // 0000008BA094: D7000000
	v_cndmask_b32_e32 v1, 0xffffff00, v2, vcc_lo               // 0000008BA098: 020204FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000008BA0A0: BF8701D3
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[2:3]                     // 0000008BA0A4: 7CA804FF 00000100
	.long 0x7f143880                                           // 0000008BA0AC: 7F143880
	v_add_co_ci_u32_e64 v1, null, -1, v3, s0                   // 0000008BA0B0: D5207C01 000206C1
	.long 0x7e143989                                           // 0000008BA0B8: 7E143989
	s_and_b32 s0, s1, -2                                       // 0000008BA0BC: 8B00C201
	.long 0x7f16398a                                           // 0000008BA0C0: 7F16398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BA0C4: BF870193
	v_dual_cndmask_b32 v6, s3, v6 :: v_dual_cndmask_b32 v1, v1, v3// 0000008BA0C8: CA520C03 06000701
	v_and_b32_e32 v3, 1, v10                                   // 0000008BA0D0: 36061481
	.long 0x7e163988                                           // 0000008BA0D4: 7E163988
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 0000008BA0D8: 02000500
	v_cndmask_b32_e32 v2, s2, v7, vcc_lo                       // 0000008BA0DC: 02040E02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BA0E0: BF870193
	v_and_b32_e32 v7, 1, v11                                   // 0000008BA0E4: 360E1681
	.long 0xd73c0000                                           // 0000008BA0E8: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000008BA0EC: 02020081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BA0F0: BF870093
	.long 0xd7006a02                                           // 0000008BA0F4: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 0000008BA0F8: 02020902
	v_add_co_ci_u32_e64 v4, null, v6, v5, vcc_lo               // 0000008BA0FC: D5207C04 01AA0B06
	v_add3_u32 v5, v9, v3, 0x7fff                              // 0000008BA104: D6550005 03FE0709 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BA110: BF870093
	.long 0xd7006a00                                           // 0000008BA114: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 0000008BA118: 02020102
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000008BA11C: D5207C01 01AA0304
	v_add3_u32 v4, v8, v7, 0x7fff                              // 0000008BA124: D6550004 03FE0F08 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BA130: BF870093
	.long 0xd7006a02                                           // 0000008BA134: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000008BA138: 02000100
	v_add_co_ci_u32_e64 v3, null, s4, v1, vcc_lo               // 0000008BA13C: D5207C03 01AA0204
	s_clause 0x1                                               // 0000008BA144: BF850001
	global_store_d16_hi_b16 v[0:1], v4, off                    // 0000008BA148: DC960000 007C0400
	global_store_d16_hi_b16 v[2:3], v5, off                    // 0000008BA150: DC960000 007C0502
	s_endpgm                                                   // 0000008BA158: BFB00000
		...

