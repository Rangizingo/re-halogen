0000000000dd9700 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi>:
; _ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi():
	s_clause 0x1                                               // 000000DD9700: BF850001
	s_load_b32 s3, s[0:1], 0xb0                                // 000000DD9704: F40000C0 F80000B0
	s_load_b512 s[12:27], s[0:1], 0x40                         // 000000DD970C: F4100300 F8000040
	v_mov_b32_e32 v77, v0                                      // 000000DD9714: 7E9A0300
	s_mov_b32 s4, -1                                           // 000000DD9718: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 000000DD971C: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 000000DD9720: BF040302
	s_cbranch_scc1 2425                                        // 000000DD9724: BFA20979 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x260c>
	s_clause 0x1                                               // 000000DD9728: BF850001
	s_load_b64 s[10:11], s[0:1], 0xa4                          // 000000DD972C: F4040280 F80000A4
	s_load_b128 s[36:39], s[0:1], 0x98                         // 000000DD9734: F4080900 F8000098
	s_sub_i32 s3, s2, s3                                       // 000000DD973C: 81830302
	s_clause 0x1                                               // 000000DD9740: BF850001
	s_load_b128 s[28:31], s[0:1], 0x80                         // 000000DD9744: F4080700 F8000080
	s_load_b64 s[40:41], s[0:1], 0x90                          // 000000DD974C: F4040A00 F8000090
	v_lshrrev_b32_e32 v11, 5, v77                              // 000000DD9754: 32169A85
	v_and_b32_e32 v12, 31, v77                                 // 000000DD9758: 36189A9F
	s_mov_b32 s45, 0                                           // 000000DD975C: BEAD0080
	s_mov_b32 s44, exec_lo                                     // 000000DD9760: BEAC007E
	s_waitcnt lgkmcnt(0)                                       // 000000DD9764: BF89FC07
	s_abs_i32 s4, s11                                          // 000000DD9768: BE84150B
	s_ashr_i32 s7, s11, 31                                     // 000000DD976C: 86079F0B
	s_cvt_f32_u32 s5, s4                                       // 000000DD9770: BE856504
	s_sub_i32 s6, 0, s4                                        // 000000DD9774: 81860480
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DD9778: BF87029A
	v_rcp_iflag_f32_e32 v0, s5                                 // 000000DD977C: 7E005605
	v_readfirstlane_b32 s5, v0                                 // 000000DD9780: 7E0A0500
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 000000DD9784: A205FF05 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000DD978C: BF87059B
	s_cvt_u32_f32 s5, s5                                       // 000000DD9790: BE856705
	s_mul_i32 s6, s6, s5                                       // 000000DD9794: 96060506
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DD9798: BF870499
	s_mul_hi_u32 s6, s5, s6                                    // 000000DD979C: 96860605
	s_add_i32 s5, s5, s6                                       // 000000DD97A0: 81050605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DD97A4: BF870499
	s_mul_hi_u32 s5, s3, s5                                    // 000000DD97A8: 96850503
	s_mul_i32 s6, s5, s4                                       // 000000DD97AC: 96060405
	s_add_i32 s8, s5, 1                                        // 000000DD97B0: 81088105
	s_sub_i32 s6, s3, s6                                       // 000000DD97B4: 81860603
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DD97B8: BF870009
	s_sub_i32 s9, s6, s4                                       // 000000DD97BC: 81890406
	s_cmp_ge_u32 s6, s4                                        // 000000DD97C0: BF090406
	s_cselect_b32 s5, s8, s5                                   // 000000DD97C4: 98050508
	s_cselect_b32 s6, s9, s6                                   // 000000DD97C8: 98060609
	s_add_i32 s8, s5, 1                                        // 000000DD97CC: 81088105
	s_cmp_ge_u32 s6, s4                                        // 000000DD97D0: BF090406
	s_cselect_b32 s4, s8, s5                                   // 000000DD97D4: 98040508
	s_ashr_i32 s35, s38, 31                                    // 000000DD97D8: 86239F26
	s_xor_b32 s4, s4, s7                                       // 000000DD97DC: 8D040704
	s_lshr_b32 s5, s35, 25                                     // 000000DD97E0: 85059923
	s_sub_i32 s34, s4, s7                                      // 000000DD97E4: 81A20704
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DD97E8: BF870499
	s_mul_i32 s4, s34, s11                                     // 000000DD97EC: 96040B22
	s_sub_i32 s33, s3, s4                                      // 000000DD97F0: 81A10403
	s_add_i32 s3, s38, s5                                      // 000000DD97F4: 81030526
	s_mul_i32 s39, s33, s10                                    // 000000DD97F8: 96270A21
	s_ashr_i32 s3, s3, 7                                       // 000000DD97FC: 86038703
	s_add_i32 s4, s39, s10                                     // 000000DD9800: 81040A27
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DD9804: BF870499
	s_min_i32 s3, s3, s4                                       // 000000DD9808: 89030403
	s_sub_i32 s43, s3, s39                                     // 000000DD980C: 81AB2703
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DD9810: BF870499
	s_lshl_b32 s42, s43, 1                                     // 000000DD9814: 842A812B
	.long 0xd4c4007e                                           // 000000DD9818: D4C4007E
	v_cndmask_b32_e32 v1, s42, v11, vcc_lo                     // 000000DD981C: 0202162A
	s_cbranch_execz 500                                        // 000000DD9820: BFA501F4 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8f4>
	s_add_i32 s46, s36, -1                                     // 000000DD9824: 812EC124
	s_cmp_lg_u64 s[26:27], 0                                   // 000000DD9828: BF11801A
	v_dual_mov_b32 v0, v11 :: v_dual_and_b32 v1, 1, v77        // 000000DD982C: CA24010B 00009A81
	s_cselect_b32 s47, -1, 0                                   // 000000DD9834: 982F80C1
	s_abs_i32 s48, s43                                         // 000000DD9838: BEB0152B
	v_and_b32_e32 v2, 2, v77                                   // 000000DD983C: 36049A82
	s_cvt_f32_u32 s3, s48                                      // 000000DD9840: BE836530
	v_lshlrev_b32_e32 v6, 3, v12                               // 000000DD9844: 300C1883
	v_lshlrev_b32_e32 v7, 7, v11                               // 000000DD9848: 300E1687
	v_and_b32_e32 v3, 4, v77                                   // 000000DD984C: 36069A84
	v_rcp_iflag_f32_e32 v4, s3                                 // 000000DD9850: 7E085603
	v_and_b32_e32 v5, 8, v77                                   // 000000DD9854: 360A9A88
	.long 0xd44a0004                                           // 000000DD9858: D44A0004
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000DD985C: 02020280
	.long 0xd44a0005                                           // 000000DD9860: D44A0005
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000DD9864: 02020480
	v_lshl_or_b32 v1, v11, 8, v6                               // 000000DD9868: D6560001 0419110B
	v_lshl_add_u32 v2, s39, 7, v7                              // 000000DD9870: D6460002 041D0E27
	s_ashr_i32 s50, s43, 31                                    // 000000DD9878: 86329F2B
	s_sub_i32 s52, 0, s48                                      // 000000DD987C: 81B43080
	s_mul_i32 s10, s50, 0x1400                                 // 000000DD9880: 960AFF32 00001400
	.long 0xd44c0003                                           // 000000DD9888: D44C0003
	v_cndmask_b32_e32 v1, 16, v12, vcc_lo                      // 000000DD988C: 02021890
	v_readfirstlane_b32 s7, v4                                 // 000000DD9890: 7E0E0504
	.long 0xd44a0006                                           // 000000DD9894: D44A0006
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000DD9898: 02020680
	v_subrev_nc_u32_e32 v8, s10, v1                            // 000000DD989C: 4E10020A
	v_lshl_or_b32 v1, v12, 2, v2                               // 000000DD98A0: D6560001 0409050C
	s_lshl_b32 s8, s43, 7                                      // 000000DD98A8: 8408872B
	s_mul_f32 s9, s7, 0x4f7ffffe                               // 000000DD98AC: A209FF07 4F7FFFFE
	.long 0xd44a0007                                           // 000000DD98B4: D44A0007
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000DD98B8: 02020A80
	s_mov_b32 s49, 0x76543210                                  // 000000DD98BC: BEB100FF 76543210
	s_lshl_b32 s51, s43, 8                                     // 000000DD98C4: 8433882B
	s_cvt_u32_f32 s9, s9                                       // 000000DD98C8: BE896709
	s_mov_b32 s54, 0x3db504f3                                  // 000000DD98CC: BEB600FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DD98D4: BF87049A
	s_mul_i32 s52, s52, s9                                     // 000000DD98D8: 96340934
	s_mul_hi_u32 s10, s9, s52                                  // 000000DD98DC: 968A3409
	s_sub_i32 s52, 0, s8                                       // 000000DD98E0: 81B40880
	s_add_i32 s53, s9, s10                                     // 000000DD98E4: 81350A09
	s_branch 162                                               // 000000DD98E8: BFA000A2 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x474>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD98EC: BF870091
	.long 0xd7006a02                                           // 000000DD98F0: D7006A02
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000DD98F4: 02020414
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo              // 000000DD98F8: D5207C03 01AA0615
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000DD9900: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000DD9908: DC820006 027C0002
	v_add_f32_e32 v3, v16, v14                                 // 000000DD9910: 06061D10
	s_waitcnt vmcnt(0)                                         // 000000DD9914: BF8903F7
	v_fma_mix_f32 v5, v15, v2, v13 op_sel_hi:[0,1,0]           // 000000DD9918: CC200005 1436050F
	v_sub_f32_e32 v4, v16, v14                                 // 000000DD9920: 08081D10
	v_fma_mix_f32 v2, -v15, v2, v13 op_sel_hi:[0,1,0]          // 000000DD9924: CC200002 3436050F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DD992C: BF870121
	v_dual_add_f32 v6, v3, v5 :: v_dual_add_f32 v7, v4, v2     // 000000DD9930: C9080B03 06060504
	v_sub_f32_e32 v2, v4, v2                                   // 000000DD9938: 08040504
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD993C: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 000000DD9944: D5010006 20120D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DD994C: BF870241
	v_dual_add_f32 v4, v6, v4 :: v_dual_sub_f32 v3, v3, v5     // 000000DD9950: C90A0906 04020B03
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD9958: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000DD9960: D5010007 20120F07
	.long 0xd72c0006                                           // 000000DD9968: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v10, vcc_lo                  // 000000DD996C: 020214FF 00001400
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD9974: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000DD997C: D5010003 20120703
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD9984: BF870004
	v_add_f32_e32 v5, v7, v5                                   // 000000DD9988: 060A0B07
	v_mov_b32_dpp v14, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD998C: 7E1C02FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000DD9994: D5010002 20120502
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD999C: 7E0E02FA FF016204
	v_add_f32_e32 v3, v3, v13                                  // 000000DD99A4: 06061B03
	v_mov_b32_dpp v10, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD99A8: 7E1402FA FF016205
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000DD99B0: D5010004 20160904
	v_add_f32_e32 v2, v2, v14                                  // 000000DD99B8: 06041D02
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000DD99BC: D5010005 20160B05
	v_mov_b32_dpp v13, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD99C4: 7E1A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000DD99CC: D5010003 20160703
	v_add_f32_e32 v4, v4, v7                                   // 000000DD99D4: 06080F04
	v_mov_b32_dpp v14, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD99D8: 7E1C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000DD99E0: D5010002 20160502
	v_add_f32_e32 v5, v5, v10                                  // 000000DD99E8: 060A1505
	v_add_f32_e32 v3, v3, v13                                  // 000000DD99EC: 06061B03
	.long 0xd72c0007                                           // 000000DD99F0: D72C0007
	v_cndmask_b32_e32 v1, s51, v9, vcc_lo                      // 000000DD99F4: 02021233
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD99F8: 7E1202FA FF016404
	v_add_f32_e32 v2, v2, v14                                  // 000000DD9A00: 06041D02
	v_mov_b32_dpp v10, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD9A04: 7E1402FA FF016405
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 000000DD9A0C: D5010004 201A0904
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 000000DD9A14: D5010005 201A0B05
	v_mov_b32_dpp v13, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD9A1C: 7E1A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000DD9A24: D5010003 201A0703
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD9A2C: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 000000DD9A34: D5010002 201A0502
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v10    // 000000DD9A3C: C9081304 04041505
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD9A44: BF8701A4
	v_dual_add_f32 v3, v3, v13 :: v_dual_add_nc_u32 v0, 8, v0  // 000000DD9A48: C9201B03 03000088
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000DD9A50: 4C0C0F06
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD9A54: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD9A5C: BF870004
	v_mov_b32_dpp v10, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD9A60: 7E1402FA FF016805
	v_cndmask_b32_e64 v4, -v4, v4, s7                          // 000000DD9A68: D5010004 201E0904
	v_cndmask_b32_e64 v5, -v5, v5, s7                          // 000000DD9A70: D5010005 201E0B05
	v_mov_b32_dpp v13, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD9A78: 7E1A02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s7                          // 000000DD9A80: D5010003 201E0703
	v_add_f32_e32 v2, v2, v14                                  // 000000DD9A88: 06041D02
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DD9A8C: BF870224
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v10    // 000000DD9A90: C9081304 04041505
	v_cmp_le_i32_e32 vcc_lo, s42, v0                           // 000000DD9A98: 7C86002A
	v_add_f32_e32 v3, v3, v13                                  // 000000DD9A9C: 06061B03
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000DD9AA0: BF8701C4
	v_mov_b32_dpp v14, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD9AA4: 7E1C02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s7                          // 000000DD9AAC: D5010002 201E0502
	v_dual_mov_b32 v10, v5 :: v_dual_mov_b32 v9, v4            // 000000DD9AB4: CA100105 0A080104
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000DD9ABC: D5010005 200E0B05
	v_dual_mov_b32 v13, v3 :: v_dual_add_f32 v2, v2, v14       // 000000DD9AC4: CA080103 0D021D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DD9ACC: BF870243
	v_permlanex16_b32 v10, v10, s49, 0xfedcba98                // 000000DD9AD0: D65C000A 03FC630A FEDCBA98
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000DD9ADC: D5010004 200E0904
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000DD9AE4: D5010003 200E0703
	v_permlanex16_b32 v9, v9, s49, 0xfedcba98                  // 000000DD9AEC: D65C0009 03FC6309 FEDCBA98
	v_dual_mov_b32 v14, v2 :: v_dual_add_f32 v5, v5, v10       // 000000DD9AF8: CA080102 0E041505
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000DD9B00: D5010002 200E0502
	v_permlanex16_b32 v13, v13, s49, 0xfedcba98                // 000000DD9B08: D65C000D 03FC630D FEDCBA98
	v_add_nc_u32_e32 v6, v8, v6                                // 000000DD9B14: 4A0C0D08
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DD9B18: BF870224
	v_permlanex16_b32 v14, v14, s49, 0xfedcba98                // 000000DD9B1C: D65C000E 03FC630E FEDCBA98
	v_add_f32_e32 v4, v4, v9                                   // 000000DD9B28: 06081304
	v_dual_add_f32 v9, v3, v13 :: v_dual_add_nc_u32 v8, 0x800, v8// 000000DD9B2C: C9201B03 090810FF 00000800
	s_or_b32 s45, vcc_lo, s45                                  // 000000DD9B38: 8C2D2D6A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DD9B3C: BF870243
	v_add_f32_e32 v7, v2, v14                                  // 000000DD9B40: 060E1D02
	v_fma_mixhi_f16 v2, v5, s54, 0                             // 000000DD9B44: CC220002 02006D05
	v_fma_mixlo_f16 v2, v4, s54, 0                             // 000000DD9B4C: CC210002 02006D04
	v_fma_mixlo_f16 v3, v9, s54, 0                             // 000000DD9B54: CC210003 02006D09
	v_fma_mixhi_f16 v3, v7, s54, 0                             // 000000DD9B5C: CC220003 02006D07
	ds_store_b64 v6, v[2:3]                                    // 000000DD9B64: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s45                       // 000000DD9B6C: 917E2D7E
	s_cbranch_execz 288                                        // 000000DD9B70: BFA50120 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8f4>
	.long 0xd72d0002                                           // 000000DD9B74: D72D0002
	v_cndmask_b32_e32 v0, v0, v53, vcc_lo                      // 000000DD9B78: 02006B00
	s_mov_b32 s8, -1                                           // 000000DD9B7C: BE8800C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD9B80: BF870091
	.long 0xd72c0003                                           // 000000DD9B84: D72C0003
	v_cndmask_b32_e32 v0, v2, v48, vcc_lo                      // 000000DD9B88: 02006102
	v_sub_nc_u32_e32 v3, v0, v3                                // 000000DD9B8C: 4C060700
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DD9B90: BF870121
	v_subrev_nc_u32_e32 v5, s48, v3                            // 000000DD9B94: 4E0A0630
	v_cmp_le_u32_e32 vcc_lo, s48, v3                           // 000000DD9B98: 7C960630
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000DD9B9C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD9BA4: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000DD9BA8: 02040902
	v_cmp_le_u32_e32 vcc_lo, s48, v3                           // 000000DD9BAC: 7C960630
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD9BB0: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000DD9BB4: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000DD9BB8: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s47                        // 000000DD9BBC: 916A2F7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD9BC0: BF870091
	v_xor_b32_e32 v10, s50, v2                                 // 000000DD9BC4: 3A140432
	v_subrev_nc_u32_e32 v9, s50, v10                           // 000000DD9BC8: 4E121432
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD9BCC: BF8700A1
	v_mad_u64_u32 v[6:7], null, s52, v9, v[1:2]                // 000000DD9BD0: D6FE7C06 04061234
	v_min_i32_e32 v2, s46, v9                                  // 000000DD9BD8: 2204122E
	v_mad_i64_i32 v[4:5], null, v2, s38, 0                     // 000000DD9BDC: D6FF7C04 02004D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD9BE4: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000DD9BE8: 340E0C9F
	.long 0xd73c0002                                           // 000000DD9BEC: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000DD9BF0: 02020C81
	s_cbranch_vccnz 211                                        // 000000DD9BF4: BFA400D3 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x844>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD9BF8: BF870093
	.long 0xd7006a06                                           // 000000DD9BFC: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000DD9C00: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000DD9C04: D5207C07 01AA0F05
	.long 0x7f3a3880                                           // 000000DD9C0C: 7F3A3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD9C10: BF870112
	.long 0xd73c0006                                           // 000000DD9C14: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000DD9C18: 02020C81
	.long 0x7f40399d                                           // 000000DD9C1C: 7F40399D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD9C20: BF870092
	.long 0xd7006a0d                                           // 000000DD9C24: D7006A0D
	v_cndmask_b32_e32 v1, s24, v6, vcc_lo                      // 000000DD9C28: 02020C18
	v_add_co_ci_u32_e64 v14, null, s25, v7, vcc_lo             // 000000DD9C2C: D5207C0E 01AA0E19
	.long 0xd7006a06                                           // 000000DD9C34: D7006A06
	v_cndmask_b32_e32 v1, s26, v6, vcc_lo                      // 000000DD9C38: 02020C1A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD9C3C: BF870001
	v_add_co_ci_u32_e64 v7, null, s27, v7, vcc_lo              // 000000DD9C40: D5207C07 01AA0E1B
	global_load_b64 v[13:14], v[13:14], off                    // 000000DD9C48: DC560000 0D7C000D
	.long 0xd7006a0f                                           // 000000DD9C50: D7006A0F
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000DD9C54: 02020414
	global_load_b64 v[6:7], v[6:7], off                        // 000000DD9C58: DC560000 067C0006
	v_add_co_ci_u32_e64 v16, null, s21, v3, vcc_lo             // 000000DD9C60: D5207C10 01AA0615
	s_clause 0x1                                               // 000000DD9C68: BF850001
	global_load_b32 v17, v[15:16], off                         // 000000DD9C6C: DC520000 117C000F
	global_load_d16_b16 v15, v[15:16], off offset:4            // 000000DD9C74: DC820004 0F7C000F
	s_waitcnt vmcnt(3)                                         // 000000DD9C7C: BF890FF7
	.long 0x7e20390d                                           // 000000DD9C80: 7E20390D
	s_waitcnt vmcnt(2)                                         // 000000DD9C84: BF890BF7
	v_and_b32_e32 v39, 0xffff0000, v6                          // 000000DD9C88: 364E0CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000DD9C90: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD9C94: BF870093
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000DD9C98: 30202090
	v_mul_f32_e32 v20, 0xbfb8aa3b, v16                         // 000000DD9C9C: 102820FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DD9CA4: BF870291
	v_exp_f32_e32 v20, v20                                     // 000000DD9CA8: 7E284B14
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_and_b32 v13, 0xffff0000, v13// 000000DD9CAC: C92428F2 140C1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD9CB8: BF870111
	v_mul_f32_e32 v19, 0xbfb8aa3b, v13                         // 000000DD9CBC: 10261AFF BFB8AA3B
	v_div_scale_f32 v24, null, v20, v20, v16                   // 000000DD9CC4: D6FC7C18 04422914
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DD9CCC: BF8701B2
	v_exp_f32_e32 v19, v19                                     // 000000DD9CD0: 7E264B13
	v_lshlrev_b32_e32 v18, 16, v14                             // 000000DD9CD4: 30241C90
	v_div_scale_f32 v37, s9, v16, v20, v16                     // 000000DD9CD8: D6FC0925 04422910
	v_rcp_f32_e32 v28, v24                                     // 000000DD9CE0: 7E385518
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD9CE4: BF870196
	v_add_f32_e32 v19, 1.0, v19                                // 000000DD9CE8: 062626F2
	v_mul_f32_e32 v21, 0xbfb8aa3b, v18                         // 000000DD9CEC: 102A24FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD9CF4: BF870195
	v_fma_f32 v36, -v24, v28, 1.0                              // 000000DD9CF8: D6130024 23CA3918
	v_div_scale_f32 v23, null, v19, v19, v13                   // 000000DD9D00: D6FC7C17 04362713
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DD9D08: BF870003
	v_exp_f32_e32 v21, v21                                     // 000000DD9D0C: 7E2A4B15
	v_and_b32_e32 v14, 0xffff0000, v14                         // 000000DD9D10: 361C1CFF FFFF0000
	v_div_scale_f32 v33, vcc_lo, v13, v19, v13                 // 000000DD9D18: D6FC6A21 0436270D
	v_fmac_f32_e32 v28, v36, v28                               // 000000DD9D20: 56383924
	v_rcp_f32_e32 v26, v23                                     // 000000DD9D24: 7E345517
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000DD9D28: BF870186
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_mul_f32 v22, 0xbfb8aa3b, v14// 000000DD9D2C: C9062AF2 15161CFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD9D38: BF870115
	v_fma_f32 v34, -v23, v26, 1.0                              // 000000DD9D3C: D6130022 23CA3517
	v_div_scale_f32 v25, null, v21, v21, v18                   // 000000DD9D44: D6FC7C19 044A2B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD9D4C: BF8701A3
	v_exp_f32_e32 v22, v22                                     // 000000DD9D50: 7E2C4B16
	v_div_scale_f32 v35, s8, v18, v21, v18                     // 000000DD9D54: D6FC0823 044A2B12
	v_fmac_f32_e32 v26, v34, v26                               // 000000DD9D5C: 56343522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DD9D60: BF870293
	v_rcp_f32_e32 v30, v25                                     // 000000DD9D64: 7E3C5519
	v_fma_f32 v38, -v25, v30, 1.0                              // 000000DD9D68: D6130026 23CA3D19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD9D70: BF870191
	v_fmac_f32_e32 v30, v38, v30                               // 000000DD9D74: 563C3D26
	v_mul_f32_e32 v38, v33, v26                                // 000000DD9D78: 104C3521
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD9D7C: BF870112
	v_mul_f32_e32 v40, v35, v30                                // 000000DD9D80: 10503D23
	v_fma_f32 v41, -v23, v38, v33                              // 000000DD9D84: D6130029 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD9D8C: BF870112
	v_fma_f32 v44, -v25, v40, v35                              // 000000DD9D90: D613002C 248E5119
	v_fmac_f32_e32 v38, v41, v26                               // 000000DD9D98: 564C3529
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD9D9C: BF870112
	v_fmac_f32_e32 v40, v44, v30                               // 000000DD9DA0: 56503D2C
	v_fma_f32 v23, -v23, v38, v33                              // 000000DD9DA4: D6130017 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD9DAC: BF870112
	v_fma_f32 v25, -v25, v40, v35                              // 000000DD9DB0: D6130019 248E5119
	v_div_fmas_f32 v23, v23, v26, v38                          // 000000DD9DB8: D6370017 049A3517
	s_mov_b32 vcc_lo, s9                                       // 000000DD9DC0: BEEA0009
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD9DC4: BF870091
	v_div_fixup_f32 v13, v23, v19, v13                         // 000000DD9DC8: D627000D 04362717
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_mul_f32 v13, v13, v39// 000000DD9DD0: C9062CF2 160C4F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD9DD8: BF8701A1
	v_div_scale_f32 v27, null, v22, v22, v14                   // 000000DD9DDC: D6FC7C1B 043A2D16
	v_div_scale_f32 v36, s10, v14, v22, v14                    // 000000DD9DE4: D6FC0A24 043A2D0E
	.long 0x7e3a398d                                           // 000000DD9DEC: 7E3A398D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DD9DF0: BF870293
	v_rcp_f32_e32 v31, v27                                     // 000000DD9DF4: 7E3E551B
	v_fma_f32 v34, -v27, v31, 1.0                              // 000000DD9DF8: D6130022 23CA3F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD9E00: BF870091
	v_dual_fmac_f32 v31, v34, v31 :: v_dual_mul_f32 v34, v37, v28// 000000DD9E04: C8063F22 1F223925
	v_mul_f32_e32 v42, v36, v31                                // 000000DD9E0C: 10543F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD9E10: BF870112
	v_fma_f32 v43, -v24, v34, v37                              // 000000DD9E14: D613002B 24964518
	v_fma_f32 v41, -v27, v42, v36                              // 000000DD9E1C: D6130029 2492551B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD9E24: BF870112
	v_fmac_f32_e32 v34, v43, v28                               // 000000DD9E28: 5644392B
	v_fmac_f32_e32 v42, v41, v31                               // 000000DD9E2C: 56543F29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD9E30: BF870112
	v_fma_f32 v24, -v24, v34, v37                              // 000000DD9E34: D6130018 24964518
	v_fma_f32 v23, -v27, v42, v36                              // 000000DD9E3C: D6130017 2492551B
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DD9E44: BF870002
	v_div_fmas_f32 v24, v24, v28, v34                          // 000000DD9E48: D6370018 048A3918
	s_mov_b32 vcc_lo, s8                                       // 000000DD9E50: BEEA0008
	s_mov_b32 s8, 0                                            // 000000DD9E54: BE880080
	v_div_fmas_f32 v19, v25, v30, v40                          // 000000DD9E58: D6370013 04A23D19
	s_mov_b32 vcc_lo, s10                                      // 000000DD9E60: BEEA000A
	v_div_fixup_f32 v16, v24, v20, v16                         // 000000DD9E64: D6270010 04422918
	v_lshlrev_b32_e32 v20, 16, v7                              // 000000DD9E6C: 30280E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000DD9E70: 360E0EFF FFFF0000
	v_div_fixup_f32 v18, v19, v21, v18                         // 000000DD9E78: D6270012 044A2B13
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD9E80: BF8701A4
	v_mul_f32_e32 v6, v16, v6                                  // 000000DD9E84: 100C0D10
	v_div_fmas_f32 v16, v23, v31, v42                          // 000000DD9E88: D6370010 04AA3F17
	v_mul_f32_e32 v18, v18, v20                                // 000000DD9E90: 10242912
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD9E94: BF870193
	.long 0x7e403986                                           // 000000DD9E98: 7E403986
	v_div_fixup_f32 v14, v16, v22, v14                         // 000000DD9E9C: D627000E 043A2D10
	v_and_b32_e32 v16, 1, v29                                  // 000000DD9EA4: 36203A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD9EA8: BF870194
	v_bfe_u32 v19, v18, 16, 1                                  // 000000DD9EAC: D6100013 02052112
	v_dual_mul_f32 v7, v14, v7 :: v_dual_and_b32 v20, 1, v32   // 000000DD9EB4: C8E40F0E 07144081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD9EBC: BF870193
	v_add3_u32 v13, v13, v16, 0x7fff                           // 000000DD9EC0: D655000D 03FE210D 00007FFF
	v_add3_u32 v14, v18, v19, 0x7fff                           // 000000DD9ECC: D655000E 03FE2712 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD9ED8: BF870213
	v_add3_u32 v6, v6, v20, 0x7fff                             // 000000DD9EDC: D6550006 03FE2906 00007FFF
	v_bfe_u32 v16, v7, 16, 1                                   // 000000DD9EE8: D6100010 02052107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD9EF0: BF870214
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000DD9EF4: 361A1AFF FFFF0000
	v_and_b32_e32 v18, 0xffff0000, v14                         // 000000DD9EFC: 36241CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD9F04: BF870214
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000DD9F08: 360C0CFF FFFF0000
	v_add3_u32 v7, v7, v16, 0x7fff                             // 000000DD9F10: D6550007 03FE2107 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000DD9F1C: BF8907F7
	v_fma_mix_f32 v14, v17, v13, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DD9F20: CC20080E 8A021B11
	s_waitcnt vmcnt(0)                                         // 000000DD9F28: BF8903F7
	v_fma_mix_f32 v13, v15, v18, neg(0) op_sel_hi:[1,0,0]      // 000000DD9F2C: CC20000D 8A02250F
	v_fma_mix_f32 v16, v17, v6, neg(0) op_sel_hi:[1,0,0]       // 000000DD9F34: CC200010 8A020D11
	v_and_b32_e32 v15, 0xffff0000, v7                          // 000000DD9F3C: 361E0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s8                         // 000000DD9F44: 916A087E
	s_cbranch_vccnz 65128                                      // 000000DD9F48: BFA4FE68 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1ec>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD9F4C: BF870093
	.long 0xd73c0004                                           // 000000DD9F50: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000DD9F54: 02020881
	.long 0xd7006a04                                           // 000000DD9F58: D7006A04
	v_cndmask_b32_e32 v1, s24, v4, vcc_lo                      // 000000DD9F5C: 02020818
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD9F60: BF870111
	v_add_co_ci_u32_e64 v5, null, s25, v5, vcc_lo              // 000000DD9F64: D5207C05 01AA0A19
	.long 0xd7006a04                                           // 000000DD9F6C: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000DD9F70: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD9F74: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000DD9F78: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000DD9F80: D7006A06
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000DD9F84: 02020414
	v_add_co_ci_u32_e64 v7, null, s21, v3, vcc_lo              // 000000DD9F88: D5207C07 01AA0615
	global_load_b64 v[4:5], v[4:5], off                        // 000000DD9F90: DC560000 047C0004
	s_clause 0x1                                               // 000000DD9F98: BF850001
	global_load_b32 v15, v[6:7], off                           // 000000DD9F9C: DC520000 0F7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000DD9FA4: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000DD9FAC: BF890BF7
	.long 0x7e0e3904                                           // 000000DD9FB0: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000DD9FB4: 360808FF FFFF0000
	v_lshlrev_b32_e32 v13, 16, v5                              // 000000DD9FBC: 301A0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD9FC0: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000DD9FC4: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000DD9FC8: BF8907F7
	v_fma_mix_f32 v14, v15, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DD9FCC: CC20080E 8A02090F
	s_waitcnt vmcnt(0)                                         // 000000DD9FD4: BF8903F7
	v_fma_mix_f32 v13, v6, v13, neg(0) op_sel_hi:[1,0,0]       // 000000DD9FD8: CC20000D 8A021B06
	v_fma_mix_f32 v16, v15, v7, neg(0) op_sel_hi:[1,0,0]       // 000000DD9FE0: CC200010 8A020F0F
	v_and_b32_e32 v15, 0xffff0000, v5                          // 000000DD9FE8: 361E0AFF FFFF0000
	s_branch 65086                                             // 000000DD9FF0: BFA0FE3E <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1ec>
	s_or_b32 exec_lo, exec_lo, s44                             // 000000DD9FF4: 8C7E2C7E
	s_bfe_i32 s42, s43, 0x1001c                                // 000000DD9FF8: 93AAFF2B 0001001C
	s_lshl_b32 s6, s39, 3                                      // 000000DDA000: 84068327
	s_lshr_b64 s[4:5], s[42:43], 29                            // 000000DDA004: 85849D2A
	s_lshr_b32 s5, s35, 28                                     // 000000DDA008: 85059C23
	s_add_i32 s3, s4, 7                                        // 000000DDA00C: 81038704
	s_add_i32 s5, s38, s5                                      // 000000DDA010: 81050526
	s_ashr_i32 s3, s3, 3                                       // 000000DDA014: 86038303
	s_lshl_b32 s4, s43, 3                                      // 000000DDA018: 8404832B
	.long 0xd72c0001                                           // 000000DDA01C: D72C0001
	v_cndmask_b32_e32 v1, s3, v11, vcc_lo                      // 000000DDA020: 02021603
	s_waitcnt lgkmcnt(0)                                       // 000000DDA024: BF89FC07
	s_barrier                                                  // 000000DDA028: BFBD0000
	buffer_gl0_inv                                             // 000000DDA02C: E0AC0000 00000000
	v_add_nc_u32_e32 v0, s3, v1                                // 000000DDA034: 4A000203
	s_ashr_i32 s3, s5, 4                                       // 000000DDA038: 86038405
	s_ashr_i32 s5, s6, 31                                      // 000000DDA03C: 86059F06
	s_mul_hi_i32 s7, s34, s3                                   // 000000DDA040: 97070322
	s_mul_i32 s3, s34, s3                                      // 000000DDA044: 96030322
	v_min_i32_e32 v13, s4, v0                                  // 000000DDA048: 221A0004
	s_add_u32 s4, s3, s6                                       // 000000DDA04C: 80040603
	s_addc_u32 s5, s7, s5                                      // 000000DDA050: 82050507
	v_lshlrev_b32_e32 v0, 2, v12                               // 000000DDA054: 30001882
	s_lshl_b64 s[4:5], s[4:5], 10                              // 000000DDA058: 84848A04
	v_cmp_lt_i32_e32 vcc_lo, v1, v13                           // 000000DDA05C: 7C821B01
	s_add_u32 s4, s18, s4                                      // 000000DDA060: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000DDA064: 82050513
	s_and_saveexec_b32 s6, vcc_lo                              // 000000DDA068: BE86206A
	s_cbranch_execz 93                                         // 000000DDA06C: BFA5005D <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0xae4>
	.long 0xd7010302                                           // 000000DDA070: D7010302
	v_cndmask_b32_e32 v0, v12, v129, vcc_lo                    // 000000DDA074: 0201030C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DDA078: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s3                           // 000000DDA07C: D5010003 000D3F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000DDA084: 3404029F
	.long 0xd44c0003                                           // 000000DDA088: D44C0003
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000DDA08C: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDA090: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s3                          // 000000DDA094: D5010005 000D02FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 000000DDA0A0: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DDA0A8: BF870114
	.long 0xd73c0005                                           // 000000DDA0AC: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000DDA0B0: 0202028A
	.long 0xd73c0002                                           // 000000DDA0B4: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000DDA0B8: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DDA0BC: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 000000DDA0C0: 30080E98
	v_bfe_i32 v8, v7, 7, 1                                     // 000000DDA0C4: D6110008 02050F07
	.long 0xd7000309                                           // 000000DDA0CC: D7000309
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000DDA0D0: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DDA0D4: BF870211
	v_add_co_ci_u32_e64 v10, null, s5, v6, s3                  // 000000DDA0D8: D5207C0A 000E0C05
	v_ashrrev_i32_e32 v4, 22, v4                               // 000000DDA0E0: 34080896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDA0E4: BF870093
	.long 0xd7000305                                           // 000000DDA0E8: D7000305
	v_cndmask_b32_e32 v1, v9, v2, vcc_lo                       // 000000DDA0EC: 02020509
	v_add_co_ci_u32_e64 v6, null, v10, v3, s3                  // 000000DDA0F0: D5207C06 000E070A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDA0F8: BF870093
	.long 0xd7000307                                           // 000000DDA0FC: D7000307
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 000000DDA100: 02020909
	v_add_co_ci_u32_e64 v8, null, v10, v8, s3                  // 000000DDA104: D5207C08 000E110A
	.long 0xd7000309                                           // 000000DDA10C: D7000309
	v_cndmask_b32_e32 v1, v9, v0, vcc_lo                       // 000000DDA110: 02020109
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDA114: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v10, s3                  // 000000DDA118: D5207C0A 000E1480
	s_clause 0x17                                              // 000000DDA120: BF850017
	global_load_b32 v4, v[5:6], off                            // 000000DDA124: DC520000 047C0005
	global_load_b32 v2, v[5:6], off offset:128                 // 000000DDA12C: DC520080 027C0005
	global_load_b32 v64, v[5:6], off offset:256                // 000000DDA134: DC520100 407C0005
	global_load_b32 v61, v[5:6], off offset:384                // 000000DDA13C: DC520180 3D7C0005
	global_load_b32 v58, v[5:6], off offset:512                // 000000DDA144: DC520200 3A7C0005
	global_load_b32 v55, v[5:6], off offset:640                // 000000DDA14C: DC520280 377C0005
	global_load_b32 v52, v[5:6], off offset:768                // 000000DDA154: DC520300 347C0005
	global_load_b32 v34, v[5:6], off offset:896                // 000000DDA15C: DC520380 227C0005
	global_load_b32 v6, v[7:8], off                            // 000000DDA164: DC520000 067C0007
	global_load_b32 v3, v[7:8], off offset:128                 // 000000DDA16C: DC520080 037C0007
	global_load_b32 v65, v[7:8], off offset:256                // 000000DDA174: DC520100 417C0007
	global_load_b32 v62, v[7:8], off offset:384                // 000000DDA17C: DC520180 3E7C0007
	global_load_b32 v59, v[7:8], off offset:512                // 000000DDA184: DC520200 3B7C0007
	global_load_b32 v56, v[7:8], off offset:640                // 000000DDA18C: DC520280 387C0007
	global_load_b32 v54, v[7:8], off offset:768                // 000000DDA194: DC520300 367C0007
	global_load_b32 v35, v[7:8], off offset:896                // 000000DDA19C: DC520380 237C0007
	global_load_b32 v5, v[9:10], off                           // 000000DDA1A4: DC520000 057C0009
	global_load_b32 v66, v[9:10], off offset:128               // 000000DDA1AC: DC520080 427C0009
	global_load_b32 v63, v[9:10], off offset:256               // 000000DDA1B4: DC520100 3F7C0009
	global_load_b32 v60, v[9:10], off offset:384               // 000000DDA1BC: DC520180 3C7C0009
	global_load_b32 v57, v[9:10], off offset:512               // 000000DDA1C4: DC520200 397C0009
	global_load_b32 v53, v[9:10], off offset:640               // 000000DDA1CC: DC520280 357C0009
	global_load_b32 v51, v[9:10], off offset:768               // 000000DDA1D4: DC520300 337C0009
	global_load_b32 v33, v[9:10], off offset:896               // 000000DDA1DC: DC520380 217C0009
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DDA1E4: 8C7E067E
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v17, 0             // 000000DDA1E8: CA100080 0E100080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v19, 0             // 000000DDA1F0: CA100080 10120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 000000DDA1F8: CA100080 14140080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 000000DDA200: CA100080 17180080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v18, 0             // 000000DDA208: CA100080 0F120080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v22, 0             // 000000DDA210: CA100080 19160080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 000000DDA218: CA100080 1B1C0080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v29, 0             // 000000DDA220: CA100080 1A1C0080
	s_ashr_i32 s35, s34, 31                                    // 000000DDA228: 86239F22
	s_and_saveexec_b32 s3, vcc_lo                              // 000000DDA22C: BE83206A
	s_cbranch_execz 1012                                       // 000000DDA230: BFA503F4 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1b04>
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v7, -1, v77     // 000000DDA234: CA200080 0E069AC1
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v30, 16, v77       // 000000DDA23C: CA240080 111E9A90
	v_dual_mov_b32 v16, 0 :: v_dual_lshlrev_b32 v31, 2, v12    // 000000DDA244: CA220080 101E1882
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DDA24C: BF8701B3
	v_dual_mov_b32 v20, 0 :: v_dual_and_b32 v7, 31, v7         // 000000DDA250: CA240080 14060E9F
	v_mov_b32_e32 v19, 0                                       // 000000DDA258: 7E260280
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v24, 0             // 000000DDA25C: CA100080 15180080
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v32, 2, v7     // 000000DDA264: CA220080 17200E82
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v15, 0             // 000000DDA26C: CA100080 120E0080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v25, 0             // 000000DDA274: CA100080 16180080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v27, 0             // 000000DDA27C: CA100080 1C1A0080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v29, 0             // 000000DDA284: CA100080 1A1C0080
	s_mov_b32 s6, 0                                            // 000000DDA28C: BE860080
	s_movk_i32 s7, 0x1eee                                      // 000000DDA290: B0071EEE
	s_branch 928                                               // 000000DDA294: BFA003A0 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1a18>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000DDA298: 8C7E087E
	s_waitcnt vmcnt(15)                                        // 000000DDA29C: BF893FF7
	v_alignbit_b32 v4, v4, v6, 16                              // 000000DDA2A0: D6160004 02420D04
	s_waitcnt vmcnt(7)                                         // 000000DDA2A8: BF891FF7
	v_bfe_u32 v67, v5, 12, 16                                  // 000000DDA2AC: D6100043 02411905
	v_bfe_u32 v68, v5, 8, 16                                   // 000000DDA2B4: D6100044 02411105
	v_bfe_u32 v69, v5, 4, 16                                   // 000000DDA2BC: D6100045 02410905
	v_lshl_or_b32 v1, v1, 5, v30                               // 000000DDA2C4: D6560001 04790B01
	v_and_b32_e32 v7, 0xffff, v4                               // 000000DDA2CC: 360E08FF 0000FFFF
	v_bfe_u32 v73, v4, 4, 16                                   // 000000DDA2D4: D6100049 02410904
	.long 0xd72c0043                                           // 000000DDA2DC: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000DDA2E0: 020286FF 83DCD12D
	.long 0xd72c0044                                           // 000000DDA2E8: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000DDA2EC: 020288FF 83DCD12D
	v_bfe_u32 v6, v4, 12, 16                                   // 000000DDA2F4: D6100006 02411904
	.long 0xd72c004b                                           // 000000DDA2FC: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 000000DDA300: 02020EFF 83DCD12D
	.long 0xd72c0049                                           // 000000DDA308: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000DDA30C: 020292FF 83DCD12D
	v_alignbit_b32 v71, v2, v3, 16                             // 000000DDA314: D6160047 02420702
	.long 0xd72c0045                                           // 000000DDA31C: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000DDA320: 02028AFF 83DCD12D
	.long 0xd72c0048                                           // 000000DDA328: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 000000DDA32C: 02020CFF 83DCD12D
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000DDA334: D6220043 03FD0143 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000DDA340: D6220044 03FD0144 00006400
	s_waitcnt vmcnt(6)                                         // 000000DDA34C: BF891BF7
	v_bfe_u32 v76, v66, 4, 16                                  // 000000DDA350: D610004C 02410942
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000DDA358: D622004B 03FD014B 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000DDA364: D6220049 03FD0149 00006400
	v_and_b32_e32 v67, 0xffff, v67                             // 000000DDA370: 368686FF 0000FFFF
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000DDA378: D6220045 03FD0145 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000DDA384: D6220048 03FD0148 00006400
	v_lshlrev_b32_e32 v75, 16, v75                             // 000000DDA390: 30969690
	v_alignbit_b32 v64, v64, v65, 16                           // 000000DDA394: D6160040 02428340
	v_lshl_or_b32 v67, v68, 16, v67                            // 000000DDA39C: D6560043 050D2144
	v_alignbit_b32 v61, v61, v62, 16                           // 000000DDA3A4: D616003D 02427D3D
	v_alignbit_b32 v58, v58, v59, 16                           // 000000DDA3AC: D616003A 0242773A
	v_and_or_b32 v73, 0xffff, v73, v75                         // 000000DDA3B4: D6570049 052E92FF 0000FFFF
	v_bfe_u32 v75, v66, 8, 16                                  // 000000DDA3C0: D610004B 02411142
	v_pk_fma_f16 v67, v67, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDA3C8: CC0E0043 0BFC0F43 0000C931
	v_alignbit_b32 v55, v55, v56, 16                           // 000000DDA3D4: D6160037 02427137
	v_alignbit_b32 v52, v52, v54, 16                           // 000000DDA3DC: D6160034 02426D34
	v_pk_fma_f16 v68, v73, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDA3E4: CC0E0044 0BFC0F49 0000C931
	v_and_b32_e32 v70, 0xffff, v5                              // 000000DDA3F0: 368C0AFF 0000FFFF
	v_bfe_u32 v5, v4, 8, 16                                    // 000000DDA3F8: D6100005 02411104
	v_bfe_u32 v73, v71, 12, 16                                 // 000000DDA400: D6100049 02411947
	.long 0xd72c004b                                           // 000000DDA408: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000DDA40C: 020296FF 83DCD12D
	v_bfe_u32 v54, v52, 12, 16                                 // 000000DDA414: D6100036 02411934
	v_alignbit_b32 v34, v34, v35, 16                           // 000000DDA41C: D6160022 02424722
	.long 0xd72c004a                                           // 000000DDA424: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 000000DDA428: 02020AFF 83DCD12D
	ds_load_b128 v[5:8], v1                                    // 000000DDA430: DBFC0000 05000001
	ds_load_b128 v[1:4], v1 offset:5120                        // 000000DDA438: DBFC1400 01000001
	v_and_b32_e32 v72, 0xffff, v72                             // 000000DDA440: 369090FF 0000FFFF
	.long 0xd72c0049                                           // 000000DDA448: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000DDA44C: 020292FF 83DCD12D
	.long 0xd72c0036                                           // 000000DDA454: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000DDA458: 02026CFF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000DDA460: D622004B 03FD014B 00006400
	v_cmp_eq_u32_e32 vcc_lo, v9, v13                           // 000000DDA46C: 7C941B09
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000DDA470: D622004A 03FD014A 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000DDA47C: D6220049 03FD0149 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000DDA488: D6220036 03FD0136 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DDA494: BF870133
	v_lshl_or_b32 v72, v74, 16, v72                            // 000000DDA498: D6560048 0521214A
	v_bfe_u32 v74, v71, 8, 16                                  // 000000DDA4A0: D610004A 02411147
	s_or_b32 s6, vcc_lo, s6                                    // 000000DDA4A8: 8C06066A
	v_pk_fma_f16 v72, v72, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDA4AC: CC0E0048 0BFC0F48 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DDA4B8: BF870122
	.long 0xd72c004a                                           // 000000DDA4BC: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000DDA4C0: 020294FF 83DCD12D
	s_waitcnt lgkmcnt(1)                                       // 000000DDA4C8: BF89FC17
	v_dot2acc_f32_f16 v29, v72, v5                             // 000000DDA4CC: 043A0B48
	s_waitcnt lgkmcnt(0)                                       // 000000DDA4D0: BF89FC07
	v_dot2acc_f32_f16 v26, v72, v1                             // 000000DDA4D4: 04340348
	v_bfe_u32 v72, v66, 12, 16                                 // 000000DDA4D8: D6100048 02411942
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000DDA4E0: BF870254
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000DDA4E4: D622004A 03FD014A 00006400
	v_dot2acc_f32_f16 v29, v68, v6                             // 000000DDA4F0: 043A0D44
	.long 0xd72c0046                                           // 000000DDA4F4: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000DDA4F8: 02028CFF 83DCD12D
	v_dot2acc_f32_f16 v26, v68, v2                             // 000000DDA500: 04340544
	.long 0xd72c0048                                           // 000000DDA504: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000DDA508: 020290FF 83DCD12D
	v_dot2acc_f32_f16 v29, v67, v7                             // 000000DDA510: 043A0F43
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000DDA514: BF8701C3
	v_dot2acc_f32_f16 v26, v67, v3                             // 000000DDA518: 04340743
	v_bfe_u32 v67, v64, 4, 16                                  // 000000DDA51C: D6100043 02410940
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000DDA524: D6220046 03FD0146 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000DDA530: D6220048 03FD0148 00006400
	.long 0xd72c0043                                           // 000000DDA53C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000DDA540: 020286FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDA548: BF870093
	v_lshlrev_b32_e32 v70, 16, v70                             // 000000DDA54C: 308C8C90
	v_and_or_b32 v69, 0xffff, v69, v70                         // 000000DDA550: D6570045 051A8AFF 0000FFFF
	v_and_b32_e32 v70, 0xffff, v71                             // 000000DDA55C: 368C8EFF 0000FFFF
	v_bfe_u32 v71, v71, 4, 16                                  // 000000DDA564: D6100047 02410947
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDA56C: BF870193
	v_pk_fma_f16 v69, v69, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDA570: CC0E0045 0BFC0F45 0000C931
	.long 0xd72c0046                                           // 000000DDA57C: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000DDA580: 02028CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDA588: BF870193
	.long 0xd72c0047                                           // 000000DDA58C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000DDA590: 02028EFF 83DCD12D
	v_dot2acc_f32_f16 v29, v69, v8                             // 000000DDA598: 043A1145
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDA59C: BF870193
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000DDA5A0: D6220046 03FD0146 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000DDA5AC: D6220047 03FD0147 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDA5B8: BF870092
	v_lshlrev_b32_e32 v70, 16, v70                             // 000000DDA5BC: 308C8C90
	v_and_or_b32 v68, 0xffff, v71, v70                         // 000000DDA5C0: D6570044 051A8EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DDA5CC: BF8700A1
	v_pk_fma_f16 v68, v68, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDA5D0: CC0E0044 0BFC0F44 0000C931
	v_and_b32_e32 v73, 0xffff, v73                             // 000000DDA5DC: 369292FF 0000FFFF
	v_lshl_or_b32 v73, v74, 16, v73                            // 000000DDA5E4: D6560049 0525214A
	.long 0xd72c004a                                           // 000000DDA5EC: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000DDA5F0: 020298FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDA5F8: BF870092
	v_pk_fma_f16 v70, v73, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDA5FC: CC0E0046 0BFC0F49 0000C931
	v_dual_dot2acc_f32_f16 v27, v70, v1 :: v_dual_and_b32 v66, 0xffff, v66// 000000DDA608: CB240346 1B4284FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DDA614: BF8701A1
	.long 0xd72c0042                                           // 000000DDA618: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000DDA61C: 020284FF 83DCD12D
	v_and_b32_e32 v72, 0xffff, v72                             // 000000DDA624: 369090FF 0000FFFF
	v_dual_dot2acc_f32_f16 v28, v70, v5 :: v_dual_dot2acc_f32_f16 v27, v68, v2// 000000DDA62C: CB180B46 1C1A0544
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DDA634: BF870232
	v_lshl_or_b32 v71, v75, 16, v72                            // 000000DDA638: D6560047 0521214B
	v_sad_u8 v72, v74, 0, 0x6400                               // 000000DDA640: D6220048 03FD014A 00006400
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000DDA64C: D6220042 03FD0142 00006400
	v_dot2acc_f32_f16 v28, v68, v6                             // 000000DDA658: 04380D44
	s_waitcnt vmcnt(5)                                         // 000000DDA65C: BF8917F7
	v_bfe_u32 v68, v63, 12, 16                                 // 000000DDA660: D6100044 0241193F
	v_pk_fma_f16 v70, v71, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDA668: CC0E0046 0BFC0F47 0000C931
	s_waitcnt vmcnt(4)                                         // 000000DDA674: BF8913F7
	v_bfe_u32 v71, v60, 4, 16                                  // 000000DDA678: D6100047 0241093C
	v_lshlrev_b32_e32 v66, 16, v66                             // 000000DDA680: 30848490
	.long 0xd72c0044                                           // 000000DDA684: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000DDA688: 020288FF 83DCD12D
	v_dot2acc_f32_f16 v27, v70, v3                             // 000000DDA690: 04360746
	v_dot2acc_f32_f16 v28, v70, v7                             // 000000DDA694: 04380F46
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DDA698: BF870124
	v_and_or_b32 v66, 0xffff, v72, v66                         // 000000DDA69C: D6570042 050A90FF 0000FFFF
	v_and_b32_e32 v70, 0xffff, v63                             // 000000DDA6A8: 368C7EFF 0000FFFF
	v_pk_fma_f16 v65, v66, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDA6B0: CC0E0041 0BFC0F42 0000C931
	v_bfe_u32 v66, v64, 12, 16                                 // 000000DDA6BC: D6100042 02411940
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DDA6C4: BF870223
	.long 0xd72c0046                                           // 000000DDA6C8: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000DDA6CC: 02028CFF 83DCD12D
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000DDA6D4: D6220044 03FD0144 00006400
	v_dot2acc_f32_f16 v28, v65, v8                             // 000000DDA6E0: 04381141
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000DDA6E4: BF8701D4
	.long 0xd72c0042                                           // 000000DDA6E8: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000DDA6EC: 020284FF 83DCD12D
	v_dot2acc_f32_f16 v27, v65, v4                             // 000000DDA6F4: 04360941
	v_bfe_u32 v65, v64, 8, 16                                  // 000000DDA6F8: D6100041 02411140
	v_and_b32_e32 v64, 0xffff, v64                             // 000000DDA700: 368080FF 0000FFFF
	v_and_b32_e32 v68, 0xffff, v68                             // 000000DDA708: 368888FF 0000FFFF
	.long 0xd72c0041                                           // 000000DDA710: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000DDA714: 020282FF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000DDA71C: D6220042 03FD0142 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DDA728: BF870114
	.long 0xd72c0040                                           // 000000DDA72C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000DDA730: 020280FF 83DCD12D
	v_and_b32_e32 v66, 0xffff, v66                             // 000000DDA738: 368484FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDA740: BF870194
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000DDA744: D6220041 03FD0141 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000DDA750: D6220040 03FD0140 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DDA75C: BF870002
	v_lshl_or_b32 v65, v65, 16, v66                            // 000000DDA760: D6560041 05092141
	v_sad_u8 v66, v67, 0, 0x6400                               // 000000DDA768: D6220042 03FD0143 00006400
	v_sad_u8 v67, v70, 0, 0x6400                               // 000000DDA774: D6220043 03FD0146 00006400
	v_dot2acc_f32_f16 v26, v69, v4                             // 000000DDA780: 04340945
	v_bfe_u32 v69, v63, 8, 16                                  // 000000DDA784: D6100045 0241113F
	v_bfe_u32 v63, v63, 4, 16                                  // 000000DDA78C: D610003F 0241093F
	v_lshlrev_b32_e32 v64, 16, v64                             // 000000DDA794: 30808090
	v_lshlrev_b32_e32 v67, 16, v67                             // 000000DDA798: 30868690
	v_pk_fma_f16 v65, v65, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDA79C: CC0E0041 0BFC0F41 0000C931
	.long 0xd72c0045                                           // 000000DDA7A8: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000DDA7AC: 02028AFF 83DCD12D
	.long 0xd72c003f                                           // 000000DDA7B4: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000DDA7B8: 02027EFF 83DCD12D
	v_and_or_b32 v64, 0xffff, v66, v64                         // 000000DDA7C0: D6570040 050284FF 0000FFFF
	v_bfe_u32 v66, v61, 12, 16                                 // 000000DDA7CC: D6100042 0241193D
	v_dot2acc_f32_f16 v22, v65, v5                             // 000000DDA7D4: 042C0B41
	v_dot2acc_f32_f16 v18, v65, v1                             // 000000DDA7D8: 04240341
	v_bfe_u32 v70, v60, 8, 16                                  // 000000DDA7DC: D6100046 0241113C
	v_pk_fma_f16 v64, v64, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDA7E4: CC0E0040 0BFC0F40 0000C931
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000DDA7F0: D6220045 03FD0145 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000DDA7FC: D622003F 03FD013F 00006400
	.long 0xd72c0042                                           // 000000DDA808: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000DDA80C: 020284FF 83DCD12D
	.long 0xd72c0046                                           // 000000DDA814: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000DDA818: 02028CFF 83DCD12D
	v_dot2acc_f32_f16 v18, v64, v2                             // 000000DDA820: 04240540
	v_lshl_or_b32 v62, v69, 16, v68                            // 000000DDA824: D656003E 05112145
	v_and_or_b32 v63, 0xffff, v63, v67                         // 000000DDA82C: D657003F 050E7EFF 0000FFFF
	v_and_b32_e32 v67, 0xffff, v61                             // 000000DDA838: 36867AFF 0000FFFF
	v_bfe_u32 v68, v61, 8, 16                                  // 000000DDA840: D6100044 0241113D
	v_bfe_u32 v61, v61, 4, 16                                  // 000000DDA848: D610003D 0241093D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000DDA850: D6220042 03FD0142 00006400
	v_pk_fma_f16 v62, v62, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDA85C: CC0E003E 0BFC0F3E 0000C931
	.long 0xd72c0043                                           // 000000DDA868: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000DDA86C: 020286FF 83DCD12D
	.long 0xd72c0044                                           // 000000DDA874: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000DDA878: 020288FF 83DCD12D
	.long 0xd72c003d                                           // 000000DDA880: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000DDA884: 02027AFF 83DCD12D
	v_and_b32_e32 v66, 0xffff, v66                             // 000000DDA88C: 368484FF 0000FFFF
	v_pk_fma_f16 v63, v63, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDA894: CC0E003F 0BFC0F3F 0000C931
	v_dot2acc_f32_f16 v18, v62, v3                             // 000000DDA8A0: 0424073E
	v_bfe_u32 v69, v60, 12, 16                                 // 000000DDA8A4: D6100045 0241193C
	v_and_b32_e32 v60, 0xffff, v60                             // 000000DDA8AC: 367878FF 0000FFFF
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000DDA8B4: D6220043 03FD0143 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000DDA8C0: D6220044 03FD0144 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000DDA8CC: D622003D 03FD013D 00006400
	v_dot2acc_f32_f16 v18, v63, v4                             // 000000DDA8D8: 0424093F
	.long 0xd72c0045                                           // 000000DDA8DC: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000DDA8E0: 02028AFF 83DCD12D
	v_lshlrev_b32_e32 v67, 16, v67                             // 000000DDA8E8: 30868690
	v_lshl_or_b32 v66, v68, 16, v66                            // 000000DDA8EC: D6560042 05092144
	.long 0xd72c003c                                           // 000000DDA8F4: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000DDA8F8: 020278FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDA900: BF870193
	v_and_or_b32 v61, 0xffff, v61, v67                         // 000000DDA904: D657003D 050E7AFF 0000FFFF
	v_pk_fma_f16 v65, v66, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDA910: CC0E0041 0BFC0F42 0000C931
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000DDA91C: D6220045 03FD0145 00006400
	.long 0xd72c0043                                           // 000000DDA928: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000DDA92C: 02028EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DDA934: BF870214
	v_pk_fma_f16 v61, v61, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDA938: CC0E003D 0BFC0F3D 0000C931
	v_dot2acc_f32_f16 v25, v65, v5                             // 000000DDA944: 04320B41
	v_dot2acc_f32_f16 v24, v65, v1                             // 000000DDA948: 04300341
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000DDA94C: D622003C 03FD013C 00006400
	s_waitcnt vmcnt(2)                                         // 000000DDA958: BF890BF7
	v_bfe_u32 v65, v53, 4, 16                                  // 000000DDA95C: D6100041 02410935
	v_dot2acc_f32_f16 v25, v61, v6                             // 000000DDA964: 04320D3D
	v_dot2acc_f32_f16 v24, v61, v2                             // 000000DDA968: 0430053D
	v_and_b32_e32 v61, 0xffff, v58                             // 000000DDA96C: 367A74FF 0000FFFF
	v_dot2acc_f32_f16 v22, v64, v6                             // 000000DDA974: 042C0D40
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000DDA978: D6220043 03FD0143 00006400
	v_lshlrev_b32_e32 v60, 16, v60                             // 000000DDA984: 30787890
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DDA988: BF870114
	.long 0xd72c003d                                           // 000000DDA98C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000DDA990: 02027AFF 83DCD12D
	v_and_or_b32 v60, 0xffff, v67, v60                         // 000000DDA998: D657003C 04F286FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DDA9A4: BF870232
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000DDA9A8: D622003D 03FD013D 00006400
	v_dot2acc_f32_f16 v22, v62, v7                             // 000000DDA9B4: 042C0F3E
	v_bfe_u32 v62, v57, 12, 16                                 // 000000DDA9B8: D610003E 02411939
	v_pk_fma_f16 v59, v60, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDA9C0: CC0E003B 0BFC0F3C 0000C931
	v_bfe_u32 v60, v58, 12, 16                                 // 000000DDA9CC: D610003C 0241193A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DDA9D4: BF870234
	v_dual_dot2acc_f32_f16 v22, v63, v8 :: v_dual_lshlrev_b32 v61, 16, v61// 000000DDA9D8: CB22113F 163C7A90
	v_bfe_u32 v63, v57, 8, 16                                  // 000000DDA9E0: D610003F 02411139
	.long 0xd72c003e                                           // 000000DDA9E8: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000DDA9EC: 02027CFF 83DCD12D
	.long 0xd72c003c                                           // 000000DDA9F4: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000DDA9F8: 020278FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDAA00: BF870193
	.long 0xd72c003f                                           // 000000DDAA04: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000DDAA08: 02027EFF 83DCD12D
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000DDAA10: D622003E 03FD013E 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDAA1C: BF870193
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000DDAA20: D622003C 03FD013C 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000DDAA2C: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDAA38: BF870193
	v_and_b32_e32 v62, 0xffff, v62                             // 000000DDAA3C: 367C7CFF 0000FFFF
	v_and_b32_e32 v60, 0xffff, v60                             // 000000DDAA44: 367878FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DDAA4C: BF8701B2
	v_lshl_or_b32 v56, v63, 16, v62                            // 000000DDAA50: D6560038 04F9213F
	v_bfe_u32 v63, v53, 12, 16                                 // 000000DDAA58: D610003F 02411935
	v_bfe_u32 v62, v55, 8, 16                                  // 000000DDAA60: D610003E 02411137
	v_pk_fma_f16 v56, v56, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDAA68: CC0E0038 0BFC0F38 0000C931
	v_and_b32_e32 v68, 0xffff, v69                             // 000000DDAA74: 36888AFF 0000FFFF
	v_sad_u8 v69, v70, 0, 0x6400                               // 000000DDAA7C: D6220045 03FD0146 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DDAA88: BF8701A4
	.long 0xd72c003e                                           // 000000DDAA8C: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000DDAA90: 02027CFF 83DCD12D
	.long 0xd72c003f                                           // 000000DDAA98: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000DDAA9C: 02027EFF 83DCD12D
	v_lshl_or_b32 v66, v69, 16, v68                            // 000000DDAAA4: D6560042 05112145
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DDAAAC: BF870113
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000DDAAB0: D622003E 03FD013E 00006400
	v_pk_fma_f16 v64, v66, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDAABC: CC0E0040 0BFC0F42 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DDAAC8: BF870114
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000DDAACC: D622003F 03FD013F 00006400
	v_dual_mov_b32 v66, v49 :: v_dual_dot2acc_f32_f16 v25, v64, v7// 000000DDAAD8: CA180131 42180F40
	v_dot2acc_f32_f16 v24, v64, v3                             // 000000DDAAE0: 04300740
	v_bfe_u32 v64, v57, 4, 16                                  // 000000DDAAE4: D6100040 02410939
	v_and_b32_e32 v57, 0xffff, v57                             // 000000DDAAEC: 367272FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDAAF4: BF870194
	v_dot2acc_f32_f16 v25, v59, v8                             // 000000DDAAF8: 0432113B
	.long 0xd72c0040                                           // 000000DDAAFC: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000DDAB00: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DDAB08: BF870113
	.long 0xd72c0039                                           // 000000DDAB0C: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000DDAB10: 020272FF 83DCD12D
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000DDAB18: D6220040 03FD0140 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDAB24: BF870092
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000DDAB28: D6220039 03FD0139 00006400
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000DDAB34: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DDAB38: BF8701B1
	v_and_or_b32 v57, 0xffff, v64, v57                         // 000000DDAB3C: D6570039 04E680FF 0000FFFF
	v_bfe_u32 v64, v53, 8, 16                                  // 000000DDAB48: D6100040 02411135
	v_and_b32_e32 v53, 0xffff, v53                             // 000000DDAB50: 366A6AFF 0000FFFF
	v_pk_fma_f16 v57, v57, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDAB58: CC0E0039 0BFC0F39 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDAB64: BF870193
	.long 0xd72c0040                                           // 000000DDAB68: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000DDAB6C: 020280FF 83DCD12D
	.long 0xd72c0035                                           // 000000DDAB74: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000DDAB78: 02026AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDAB80: BF870091
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000DDAB84: D6220035 03FD0135 00006400
	v_dual_dot2acc_f32_f16 v24, v59, v4 :: v_dual_lshlrev_b32 v53, 16, v53// 000000DDAB90: CB22093B 18346A90
	v_bfe_u32 v59, v58, 8, 16                                  // 000000DDAB98: D610003B 0241113A
	v_bfe_u32 v58, v58, 4, 16                                  // 000000DDABA0: D610003A 0241093A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DDABA8: BF870112
	.long 0xd72c003b                                           // 000000DDABAC: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000DDABB0: 020276FF 83DCD12D
	.long 0xd72c003a                                           // 000000DDABB8: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000DDABBC: 020274FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DDABC4: BF870112
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000DDABC8: D622003B 03FD013B 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000DDABD4: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DDABE0: BF8701A2
	v_lshl_or_b32 v59, v59, 16, v60                            // 000000DDABE4: D656003B 04F1213B
	v_bfe_u32 v60, v55, 12, 16                                 // 000000DDABEC: D610003C 02411937
	v_and_or_b32 v58, 0xffff, v58, v61                         // 000000DDABF4: D657003A 04F674FF 0000FFFF
	v_and_b32_e32 v61, 0xffff, v55                             // 000000DDAC00: 367A6EFF 0000FFFF
	v_bfe_u32 v55, v55, 4, 16                                  // 000000DDAC08: D6100037 02410937
	v_pk_fma_f16 v59, v59, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDAC10: CC0E003B 0BFC0F3B 0000C931
	.long 0xd72c003c                                           // 000000DDAC1C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000DDAC20: 020278FF 83DCD12D
	v_pk_fma_f16 v58, v58, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDAC28: CC0E003A 0BFC0F3A 0000C931
	.long 0xd72c003d                                           // 000000DDAC34: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000DDAC38: 02027AFF 83DCD12D
	.long 0xd72c0037                                           // 000000DDAC40: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000DDAC44: 02026EFF 83DCD12D
	v_dot2acc_f32_f16 v23, v59, v1                             // 000000DDAC4C: 042E033B
	v_dot2acc_f32_f16 v15, v59, v5                             // 000000DDAC50: 041E0B3B
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000DDAC54: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DDAC60: BF870233
	v_dot2acc_f32_f16 v23, v58, v2                             // 000000DDAC64: 042E053A
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000DDAC68: D622003D 03FD013D 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000DDAC74: D6220037 03FD0137 00006400
	v_dual_dot2acc_f32_f16 v15, v58, v6 :: v_dual_and_b32 v60, 0xffff, v60// 000000DDAC80: CB240D3A 0F3C78FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DDAC8C: BF870214
	v_dot2acc_f32_f16 v23, v56, v3                             // 000000DDAC90: 042E0738
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000DDAC94: 307A7A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DDAC98: BF870213
	v_dot2acc_f32_f16 v15, v56, v7                             // 000000DDAC9C: 041E0F38
	v_lshl_or_b32 v60, v62, 16, v60                            // 000000DDACA0: D656003C 04F1213E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DDACA8: BF870214
	v_dual_dot2acc_f32_f16 v23, v57, v4 :: v_dual_and_b32 v62, 0xffff, v63// 000000DDACAC: CB240939 173E7EFF 0000FFFF
	v_and_or_b32 v55, 0xffff, v55, v61                         // 000000DDACB8: D6570037 04F66EFF 0000FFFF
	.long 0xd72c003d                                           // 000000DDACC4: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000DDACC8: 020282FF 83DCD12D
	v_sad_u8 v63, v64, 0, 0x6400                               // 000000DDACD0: D622003F 03FD0140 00006400
	v_pk_fma_f16 v59, v60, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDACDC: CC0E003B 0BFC0F3C 0000C931
	v_dot2acc_f32_f16 v15, v57, v8                             // 000000DDACE8: 041E1139
	v_pk_fma_f16 v55, v55, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDACEC: CC0E0037 0BFC0F37 0000C931
	s_waitcnt vmcnt(1)                                         // 000000DDACF8: BF8907F7
	v_bfe_u32 v57, v51, 12, 16                                 // 000000DDACFC: D6100039 02411933
	v_lshl_or_b32 v60, v63, 16, v62                            // 000000DDAD04: D656003C 04F9213F
	v_dot2acc_f32_f16 v21, v59, v5                             // 000000DDAD0C: 042A0B3B
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000DDAD10: D622003D 03FD013D 00006400
	v_mov_b32_e32 v62, v47                                     // 000000DDAD1C: 7E7C032F
	.long 0xd72c0039                                           // 000000DDAD20: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000DDAD24: 020272FF 83DCD12D
	v_pk_fma_f16 v58, v60, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDAD2C: CC0E003A 0BFC0F3C 0000C931
	v_dot2acc_f32_f16 v21, v55, v6                             // 000000DDAD38: 042A0D37
	v_and_or_b32 v53, 0xffff, v61, v53                         // 000000DDAD3C: D6570035 04D67AFF 0000FFFF
	s_waitcnt vmcnt(0)                                         // 000000DDAD48: BF8903F7
	v_bfe_u32 v60, v33, 4, 16                                  // 000000DDAD4C: D610003C 02410921
	v_mov_b32_e32 v64, v40                                     // 000000DDAD54: 7E800328
	v_mov_b32_e32 v65, v48                                     // 000000DDAD58: 7E820330
	v_dot2acc_f32_f16 v21, v58, v7                             // 000000DDAD5C: 042A0F3A
	v_pk_fma_f16 v53, v53, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDAD60: CC0E0035 0BFC0F35 0000C931
	v_dot2acc_f32_f16 v20, v59, v1                             // 000000DDAD6C: 0428033B
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000DDAD70: D6220039 03FD0139 00006400
	v_bfe_u32 v59, v51, 4, 16                                  // 000000DDAD7C: D610003B 02410933
	v_mov_b32_e32 v63, v48                                     // 000000DDAD84: 7E7E0330
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DDAD88: BF870214
	v_dual_dot2acc_f32_f16 v21, v53, v8 :: v_dual_dot2acc_f32_f16 v20, v55, v2// 000000DDAD8C: CB181135 15140537
	v_and_b32_e32 v57, 0xffff, v57                             // 000000DDAD94: 367272FF 0000FFFF
	v_bfe_u32 v55, v52, 8, 16                                  // 000000DDAD9C: D6100037 02411134
	.long 0xd72c003b                                           // 000000DDADA4: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000DDADA8: 020276FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DDADB0: BF870224
	v_dual_mov_b32 v61, v39 :: v_dual_dot2acc_f32_f16 v20, v58, v3// 000000DDADB4: CA180127 3D14073A
	v_bfe_u32 v58, v51, 8, 16                                  // 000000DDADBC: D610003A 02411133
	.long 0xd72c0037                                           // 000000DDADC4: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000DDADC8: 02026EFF 83DCD12D
	v_and_b32_e32 v51, 0xffff, v51                             // 000000DDADD0: 366666FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DDADD8: BF8701A3
	.long 0xd72c003a                                           // 000000DDADDC: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000DDADE0: 020274FF 83DCD12D
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000DDADE8: D622003B 03FD013B 00006400
	.long 0xd72c0033                                           // 000000DDADF4: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000DDADF8: 020266FF 83DCD12D
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000DDAE00: D6220037 03FD0137 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDAE0C: BF870194
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000DDAE10: D622003A 03FD013A 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000DDAE1C: D6220033 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DDAE28: BF8701B2
	v_lshl_or_b32 v35, v58, 16, v57                            // 000000DDAE2C: D6560023 04E5213A
	v_bfe_u32 v57, v34, 8, 16                                  // 000000DDAE34: D6100039 02411122
	v_bfe_u32 v58, v33, 12, 16                                 // 000000DDAE3C: D610003A 02411921
	v_pk_fma_f16 v35, v35, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDAE44: CC0E0023 0BFC0F23 0000C931
	v_and_b32_e32 v54, 0xffff, v54                             // 000000DDAE50: 366C6CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DDAE58: BF870214
	.long 0xd72c0039                                           // 000000DDAE5C: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000DDAE60: 020272FF 83DCD12D
	.long 0xd72c003a                                           // 000000DDAE68: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000DDAE6C: 020274FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DDAE74: BF870223
	v_lshl_or_b32 v54, v55, 16, v54                            // 000000DDAE78: D6560036 04D92137
	v_bfe_u32 v55, v34, 12, 16                                 // 000000DDAE80: D6100037 02411922
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000DDAE88: D6220039 03FD0139 00006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DDAE94: BF870003
	v_pk_fma_f16 v54, v54, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDAE98: CC0E0036 0BFC0F36 0000C931
	v_and_b32_e32 v56, 0xffff, v52                             // 000000DDAEA4: 367068FF 0000FFFF
	v_bfe_u32 v52, v52, 4, 16                                  // 000000DDAEAC: D6100034 02410934
	.long 0xd72c0037                                           // 000000DDAEB4: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000DDAEB8: 02026EFF 83DCD12D
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000DDAEC0: D622003A 03FD013A 00006400
	v_dot2acc_f32_f16 v17, v54, v1                             // 000000DDAECC: 04220336
	.long 0xd72c0038                                           // 000000DDAED0: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000DDAED4: 020270FF 83DCD12D
	.long 0xd72c0034                                           // 000000DDAEDC: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DDAEE0: 020268FF 83DCD12D
	v_dot2acc_f32_f16 v19, v54, v5                             // 000000DDAEE8: 04260B36
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000DDAEEC: D6220037 03FD0137 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DDAEF8: BF870214
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000DDAEFC: D6220038 03FD0138 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000DDAF08: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDAF14: BF870193
	v_and_b32_e32 v55, 0xffff, v55                             // 000000DDAF18: 366E6EFF 0000FFFF
	v_lshlrev_b32_e32 v56, 16, v56                             // 000000DDAF20: 30707090
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DDAF24: BF870112
	v_lshl_or_b32 v55, v57, 16, v55                            // 000000DDAF28: D6560037 04DD2139
	v_and_or_b32 v52, 0xffff, v52, v56                         // 000000DDAF30: D6570034 04E268FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DDAF3C: BF8701A2
	v_pk_fma_f16 v54, v55, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDAF40: CC0E0036 0BFC0F37 0000C931
	v_lshlrev_b32_e32 v51, 16, v51                             // 000000DDAF4C: 30666690
	v_pk_fma_f16 v52, v52, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDAF50: CC0E0034 0BFC0F34 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDAF5C: BF870193
	v_dot2acc_f32_f16 v16, v54, v5                             // 000000DDAF60: 04200B36
	v_and_or_b32 v51, 0xffff, v59, v51                         // 000000DDAF64: D6570033 04CE76FF 0000FFFF
	v_bfe_u32 v59, v33, 8, 16                                  // 000000DDAF70: D610003B 02411121
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DDAF78: BF870244
	v_dot2acc_f32_f16 v17, v52, v2                             // 000000DDAF7C: 04220534
	v_and_b32_e32 v56, 0xffff, v34                             // 000000DDAF80: 367044FF 0000FFFF
	v_bfe_u32 v34, v34, 4, 16                                  // 000000DDAF88: D6100022 02410922
	v_dual_dot2acc_f32_f16 v20, v53, v4 :: v_dual_and_b32 v33, 0xffff, v33// 000000DDAF90: CB240935 142042FF 0000FFFF
	v_dot2acc_f32_f16 v17, v35, v3                             // 000000DDAF9C: 04220723
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DDAFA0: BF870214
	.long 0xd72c0038                                           // 000000DDAFA4: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000DDAFA8: 020270FF 83DCD12D
	.long 0xd72c0022                                           // 000000DDAFB0: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000DDAFB4: 020244FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DDAFBC: BF870004
	.long 0xd72c0021                                           // 000000DDAFC0: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000DDAFC4: 020242FF 83DCD12D
	v_mov_b32_e32 v53, v45                                     // 000000DDAFCC: 7E6A032D
	.long 0xd72c003b                                           // 000000DDAFD0: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000DDAFD4: 020276FF 83DCD12D
	v_dual_dot2acc_f32_f16 v19, v52, v6 :: v_dual_dot2acc_f32_f16 v14, v54, v1// 000000DDAFDC: CB180D34 130E0336
	v_pk_fma_f16 v51, v51, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDAFE4: CC0E0033 0BFC0F33 0000C931
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000DDAFF0: D6220038 03FD0138 00006400
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000DDAFFC: D6220022 03FD0122 00006400
	v_sad_u8 v33, v33, 0, 0x6400                               // 000000DDB008: D6220021 03FD0121 00006400
	v_dot2acc_f32_f16 v19, v35, v7                             // 000000DDB014: 04260F23
	v_dot2acc_f32_f16 v17, v51, v4                             // 000000DDB018: 04220933
	v_lshlrev_b32_e32 v56, 16, v56                             // 000000DDB01C: 30707090
	v_mov_b32_e32 v52, v36                                     // 000000DDB020: 7E680324
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DDB024: BF870224
	v_dual_mov_b32 v54, v44 :: v_dual_dot2acc_f32_f16 v19, v51, v8// 000000DDB028: CA18012C 36121133
	v_mov_b32_e32 v51, v44                                     // 000000DDB030: 7E66032C
	v_and_or_b32 v34, 0xffff, v34, v56                         // 000000DDB034: D6570022 04E244FF 0000FFFF
	.long 0xd72c0038                                           // 000000DDB040: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000DDB044: 020278FF 83DCD12D
	v_dual_mov_b32 v60, v47 :: v_dual_mov_b32 v35, v42         // 000000DDB04C: CA10012F 3C22012A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DDB054: BF870223
	v_pk_fma_f16 v34, v34, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DDB058: CC0E0022 0BFC0F22 0000C931
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000DDB064: 30424290
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000DDB068: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DDB074: BF870003
	v_dot2acc_f32_f16 v16, v34, v6                             // 000000DDB078: 04200D22
	v_and_b32_e32 v57, 0xffff, v58                             // 000000DDB07C: 367274FF 0000FFFF
	v_sad_u8 v58, v59, 0, 0x6400                               // 000000DDB084: D622003A 03FD013B 00006400
	v_dot2acc_f32_f16 v14, v34, v2                             // 000000DDB090: 041C0522
	v_and_or_b32 v5, 0xffff, v56, v33                          // 000000DDB094: D6570005 048670FF 0000FFFF
	v_dual_mov_b32 v56, v45 :: v_dual_mov_b32 v59, v46         // 000000DDB0A0: CA10012D 383A012E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DDB0A8: BF870224
	v_lshl_or_b32 v55, v58, 16, v57                            // 000000DDB0AC: D6560037 04E5213A
	v_mov_b32_e32 v57, v46                                     // 000000DDB0B4: 7E72032E
	v_pk_fma_f16 v2, v5, s7, 0xc931 op_sel_hi:[1,0,0]          // 000000DDB0B8: CC0E0002 0BFC0F05 0000C931
	v_mov_b32_e32 v58, v38                                     // 000000DDB0C4: 7E740326
	v_mov_b32_e32 v5, v50                                      // 000000DDB0C8: 7E0A0332
	v_pk_fma_f16 v1, v55, s7, 0xc931 op_sel_hi:[1,0,0]         // 000000DDB0CC: CC0E0001 0BFC0F37 0000C931
	v_dual_mov_b32 v55, v37 :: v_dual_mov_b32 v6, v50          // 000000DDB0D8: CA100125 37060132
	v_mov_b32_e32 v34, v10                                     // 000000DDB0E0: 7E44030A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DDB0E4: BF8701B3
	v_dual_mov_b32 v33, v42 :: v_dual_dot2acc_f32_f16 v16, v1, v7// 000000DDB0E8: CA18012A 21100F01
	v_dot2acc_f32_f16 v14, v1, v3                              // 000000DDB0F0: 041C0701
	v_mov_b32_e32 v3, v49                                      // 000000DDB0F4: 7E060331
	v_dual_mov_b32 v1, v9 :: v_dual_dot2acc_f32_f16 v16, v2, v8// 000000DDB0F8: CA180109 01101102
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DDB100: BF870003
	v_dot2acc_f32_f16 v14, v2, v4                              // 000000DDB104: 041C0902
	v_mov_b32_e32 v2, v43                                      // 000000DDB108: 7E04032B
	v_mov_b32_e32 v4, v41                                      // 000000DDB10C: 7E080329
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000DDB110: 917E067E
	s_cbranch_execz 58                                         // 000000DDB114: BFA5003A <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1b00>
	v_add_nc_u32_e32 v9, 1, v1                                 // 000000DDB118: 4A120281
	s_mov_b32 s8, exec_lo                                      // 000000DDB11C: BE88007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDB120: BF870001
	.long 0xd4c1007e                                           // 000000DDB124: D4C1007E
	v_cndmask_b32_e32 v1, v9, v13, vcc_lo                      // 000000DDB128: 02021B09
	s_cbranch_execz 64602                                      // 000000DDB12C: BFA5FC5A <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0xb98>
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000DDB130: 3414129F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDB134: BF870091
	.long 0xd73c0007                                           // 000000DDB138: D73C0007
	v_cndmask_b32_e32 v1, 10, v9, vcc_lo                       // 000000DDB13C: 0202128A
	.long 0xd7006a0a                                           // 000000DDB140: D7006A0A
	v_cndmask_b32_e32 v1, s4, v7, vcc_lo                       // 000000DDB144: 02020E04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DDB148: BF870111
	v_add_co_ci_u32_e64 v36, null, s5, v8, vcc_lo              // 000000DDB14C: D5207C24 01AA1005
	.long 0xd7006a07                                           // 000000DDB154: D7006A07
	v_cndmask_b32_e32 v1, v10, v32, vcc_lo                     // 000000DDB158: 0202410A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DDB15C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v36, vcc_lo               // 000000DDB160: D5207C08 01AA4880
	.long 0xd7006a43                                           // 000000DDB168: D7006A43
	v_cndmask_b32_e32 v1, v10, v31, vcc_lo                     // 000000DDB16C: 02023F0A
	v_add_co_ci_u32_e64 v68, null, 0, v36, vcc_lo              // 000000DDB170: D5207C44 01AA4880
	s_clause 0xf                                               // 000000DDB178: BF85000F
	global_load_b32 v41, v[7:8], off                           // 000000DDB17C: DC520000 297C0007
	global_load_b32 v43, v[7:8], off offset:128                // 000000DDB184: DC520080 2B7C0007
	global_load_b32 v40, v[7:8], off offset:256                // 000000DDB18C: DC520100 287C0007
	global_load_b32 v39, v[7:8], off offset:384                // 000000DDB194: DC520180 277C0007
	global_load_b32 v38, v[7:8], off offset:512                // 000000DDB19C: DC520200 267C0007
	global_load_b32 v37, v[7:8], off offset:640                // 000000DDB1A4: DC520280 257C0007
	global_load_b32 v36, v[7:8], off offset:768                // 000000DDB1AC: DC520300 247C0007
	global_load_b32 v10, v[7:8], off offset:896                // 000000DDB1B4: DC520380 0A7C0007
	global_load_b32 v50, v[67:68], off                         // 000000DDB1BC: DC520000 327C0043
	global_load_b32 v49, v[67:68], off offset:128              // 000000DDB1C4: DC520080 317C0043
	global_load_b32 v48, v[67:68], off offset:256              // 000000DDB1CC: DC520100 307C0043
	global_load_b32 v47, v[67:68], off offset:384              // 000000DDB1D4: DC520180 2F7C0043
	global_load_b32 v46, v[67:68], off offset:512              // 000000DDB1DC: DC520200 2E7C0043
	global_load_b32 v45, v[67:68], off offset:640              // 000000DDB1E4: DC520280 2D7C0043
	global_load_b32 v44, v[67:68], off offset:768              // 000000DDB1EC: DC520300 2C7C0043
	global_load_b32 v42, v[67:68], off offset:896              // 000000DDB1F4: DC520380 2A7C0043
	s_branch 64550                                             // 000000DDB1FC: BFA0FC26 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0xb98>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DDB200: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DDB204: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 000000DDB208: 8C7E037E
	s_waitcnt vmcnt(22)                                        // 000000DDB20C: BF895BF7
	v_dual_mov_b32 v1, v29 :: v_dual_mov_b32 v2, v26           // 000000DDB210: CA10011D 0102011A
	s_waitcnt vmcnt(14)                                        // 000000DDB218: BF893BF7
	v_dual_mov_b32 v3, v28 :: v_dual_mov_b32 v6, v27           // 000000DDB21C: CA10011C 0306011B
	v_dual_mov_b32 v4, v22 :: v_dual_mov_b32 v9, v24           // 000000DDB224: CA100116 04080118
	s_waitcnt vmcnt(7)                                         // 000000DDB22C: BF891FF7
	v_dual_mov_b32 v5, v18 :: v_dual_mov_b32 v8, v25           // 000000DDB230: CA100112 05080119
	v_dual_mov_b32 v7, v15 :: v_dual_mov_b32 v30, v20          // 000000DDB238: CA10010F 071E0114
	v_dual_mov_b32 v10, v23 :: v_dual_mov_b32 v13, v21         // 000000DDB240: CA100117 0A0C0115
	v_dual_mov_b32 v31, v19 :: v_dual_mov_b32 v32, v17         // 000000DDB248: CA100113 1F200111
	s_waitcnt vmcnt(0)                                         // 000000DDB250: BF8903F7
	v_dual_mov_b32 v33, v16 :: v_dual_mov_b32 v34, v14         // 000000DDB254: CA100110 2122010E
	s_mov_b32 s3, 0x76543210                                   // 000000DDB25C: BE8300FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DDB264: BF870009
	v_permlanex16_b32 v1, v1, s3, 0xfedcba98                   // 000000DDB268: D65C0001 03FC0701 FEDCBA98
	v_permlanex16_b32 v2, v2, s3, 0xfedcba98                   // 000000DDB274: D65C0002 03FC0702 FEDCBA98
	v_permlanex16_b32 v3, v3, s3, 0xfedcba98                   // 000000DDB280: D65C0003 03FC0703 FEDCBA98
	v_permlanex16_b32 v6, v6, s3, 0xfedcba98                   // 000000DDB28C: D65C0006 03FC0706 FEDCBA98
	v_permlanex16_b32 v4, v4, s3, 0xfedcba98                   // 000000DDB298: D65C0004 03FC0704 FEDCBA98
	v_permlanex16_b32 v5, v5, s3, 0xfedcba98                   // 000000DDB2A4: D65C0005 03FC0705 FEDCBA98
	v_permlanex16_b32 v8, v8, s3, 0xfedcba98                   // 000000DDB2B0: D65C0008 03FC0708 FEDCBA98
	v_permlanex16_b32 v9, v9, s3, 0xfedcba98                   // 000000DDB2BC: D65C0009 03FC0709 FEDCBA98
	v_permlanex16_b32 v7, v7, s3, 0xfedcba98                   // 000000DDB2C8: D65C0007 03FC0707 FEDCBA98
	v_permlanex16_b32 v10, v10, s3, 0xfedcba98                 // 000000DDB2D4: D65C000A 03FC070A FEDCBA98
	v_permlanex16_b32 v13, v13, s3, 0xfedcba98                 // 000000DDB2E0: D65C000D 03FC070D FEDCBA98
	v_permlanex16_b32 v30, v30, s3, 0xfedcba98                 // 000000DDB2EC: D65C001E 03FC071E FEDCBA98
	v_permlanex16_b32 v31, v31, s3, 0xfedcba98                 // 000000DDB2F8: D65C001F 03FC071F FEDCBA98
	v_permlanex16_b32 v32, v32, s3, 0xfedcba98                 // 000000DDB304: D65C0020 03FC0720 FEDCBA98
	v_permlanex16_b32 v33, v33, s3, 0xfedcba98                 // 000000DDB310: D65C0021 03FC0721 FEDCBA98
	v_permlanex16_b32 v34, v34, s3, 0xfedcba98                 // 000000DDB31C: D65C0022 03FC0722 FEDCBA98
	.long 0xd44c0003                                           // 000000DDB328: D44C0003
	v_cndmask_b32_e32 v1, 16, v12, vcc_lo                      // 000000DDB32C: 02021890
	s_barrier                                                  // 000000DDB330: BFBD0000
	buffer_gl0_inv                                             // 000000DDB334: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 000000DDB33C: BE842003
	s_cbranch_execz 34                                         // 000000DDB340: BFA50022 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1ccc>
	v_dual_add_f32 v6, v27, v6 :: v_dual_add_f32 v3, v28, v3   // 000000DDB344: C9080D1B 0602071C
	v_dual_add_f32 v1, v29, v1 :: v_dual_add_f32 v2, v26, v2   // 000000DDB34C: C908031D 0102051A
	v_lshl_or_b32 v0, v11, 10, v0                              // 000000DDB354: D6560000 0401150B
	v_dual_add_f32 v9, v24, v9 :: v_dual_add_f32 v8, v25, v8   // 000000DDB35C: C9081318 09081119
	v_add_f32_e32 v4, v22, v4                                  // 000000DDB364: 06080916
	v_add_f32_e32 v5, v18, v5                                  // 000000DDB368: 060A0B12
	v_add_f32_e32 v12, v14, v34                                // 000000DDB36C: 0618450E
	v_dual_add_f32 v14, v16, v33 :: v_dual_add_f32 v7, v15, v7 // 000000DDB370: C9084310 0E060F0F
	v_dual_add_f32 v13, v21, v13 :: v_dual_add_f32 v10, v23, v10// 000000DDB378: C9081B15 0D0A1517
	v_dual_add_f32 v16, v17, v32 :: v_dual_add_f32 v17, v19, v31// 000000DDB380: C9084111 10103F13
	v_add_f32_e32 v19, v20, v30                                // 000000DDB388: 06263D14
	ds_store_2addr_b32 v0, v1, v3 offset1:16                   // 000000DDB38C: D8381000 00030100
	ds_store_2addr_b32 v0, v2, v6 offset0:128 offset1:144      // 000000DDB394: D8389080 00060200
	ds_store_2addr_b32 v0, v4, v8 offset0:32 offset1:48        // 000000DDB39C: D8383020 00080400
	ds_store_2addr_b32 v0, v5, v9 offset0:160 offset1:176      // 000000DDB3A4: D838B0A0 00090500
	ds_store_2addr_b32 v0, v7, v13 offset0:64 offset1:80       // 000000DDB3AC: D8385040 000D0700
	ds_store_2addr_b32 v0, v10, v19 offset0:192 offset1:208    // 000000DDB3B4: D838D0C0 00130A00
	ds_store_2addr_b32 v0, v17, v14 offset0:96 offset1:112     // 000000DDB3BC: D8387060 000E1100
	ds_store_2addr_b32 v0, v16, v12 offset0:224 offset1:240    // 000000DDB3C4: D838F0E0 000C1000
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DDB3CC: 8C7E047E
	.long 0xd44c0004                                           // 000000DDB3D0: D44C0004
	v_cndmask_b32_e32 v1, 0x100, v77, vcc_lo                   // 000000DDB3D4: 02029AFF 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000DDB3DC: BF89FC07
	s_barrier                                                  // 000000DDB3E0: BFBD0000
	buffer_gl0_inv                                             // 000000DDB3E4: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000DDB3EC: BE852004
	s_cbranch_execnz 7                                         // 000000DDB3F0: BFA60007 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1d10>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DDB3F4: 8C7E057E
	s_cmp_lt_i32 s11, 2                                        // 000000DDB3F8: BF04820B
	s_mov_b32 s5, -1                                           // 000000DDB3FC: BE8500C1
	s_cbranch_scc0 33                                          // 000000DDB400: BFA10021 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1d88>
	s_and_b32 vcc_lo, exec_lo, s5                              // 000000DDB404: 8B6A057E
	s_cbranch_vccnz 194                                        // 000000DDB408: BFA400C2 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2014>
	s_branch 574                                               // 000000DDB40C: BFA0023E <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2608>
	v_lshlrev_b32_e32 v6, 2, v77                               // 000000DDB410: 300C9A82
	ds_load_2addr_stride64_b32 v[0:1], v6 offset1:4            // 000000DDB414: D8E00400 00000006
	ds_load_2addr_stride64_b32 v[2:3], v6 offset0:8 offset1:12 // 000000DDB41C: D8E00C08 02000006
	ds_load_2addr_stride64_b32 v[4:5], v6 offset0:16 offset1:20// 000000DDB424: D8E01410 04000006
	s_waitcnt lgkmcnt(2)                                       // 000000DDB42C: BF89FC27
	v_add_f32_e32 v0, 0, v0                                    // 000000DDB430: 06000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DDB434: BF8700A1
	v_add_f32_e32 v0, v0, v1                                   // 000000DDB438: 06000300
	s_waitcnt lgkmcnt(1)                                       // 000000DDB43C: BF89FC17
	v_add_f32_e32 v2, v0, v2                                   // 000000DDB440: 06040500
	ds_load_2addr_stride64_b32 v[0:1], v6 offset0:24 offset1:28// 000000DDB444: D8E01C18 00000006
	v_add_f32_e32 v2, v2, v3                                   // 000000DDB44C: 06040702
	s_waitcnt lgkmcnt(1)                                       // 000000DDB450: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDB454: BF870091
	v_add_f32_e32 v2, v2, v4                                   // 000000DDB458: 06040902
	v_add_f32_e32 v2, v2, v5                                   // 000000DDB45C: 06040B02
	s_waitcnt lgkmcnt(0)                                       // 000000DDB460: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDB464: BF870091
	v_add_f32_e32 v0, v2, v0                                   // 000000DDB468: 06000102
	v_add_f32_e32 v0, v0, v1                                   // 000000DDB46C: 06000300
	ds_store_b32 v6, v0 offset:8192                            // 000000DDB470: D8342000 00000006
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DDB478: 8C7E057E
	s_cmp_lt_i32 s11, 2                                        // 000000DDB47C: BF04820B
	s_mov_b32 s5, -1                                           // 000000DDB480: BE8500C1
	s_cbranch_scc1 65503                                       // 000000DDB484: BFA2FFDF <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1d04>
	s_waitcnt lgkmcnt(0)                                       // 000000DDB488: BF89FC07
	s_barrier                                                  // 000000DDB48C: BFBD0000
	buffer_gl0_inv                                             // 000000DDB490: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000DDB498: BE852004
	s_cbranch_execz 41                                         // 000000DDB49C: BFA50029 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1e44>
	v_lshrrev_b32_e32 v0, 7, v77                               // 000000DDB4A0: 32009A87
	s_ashr_i32 s6, s37, 31                                     // 000000DDB4A4: 86069F25
	v_lshlrev_b32_e32 v3, 2, v77                               // 000000DDB4A8: 30069A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000DDB4AC: BF8704D2
	v_lshl_or_b32 v0, s33, 1, v0                               // 000000DDB4B0: D6560000 04010221
	ds_load_b32 v3, v3 offset:8192                             // 000000DDB4B8: D8D82000 03000003
	.long 0xd72c0002                                           // 000000DDB4C0: D72C0002
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo                       // 000000DDB4C4: 02000D00
	v_mad_u64_u32 v[0:1], null, v0, s37, 0                     // 000000DDB4C8: D6FE7C00 02004B00
	s_ashr_i32 s6, s33, 31                                     // 000000DDB4D0: 86069F21
	s_mul_i32 s6, s6, s37                                      // 000000DDB4D4: 96062506
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000DDB4D8: BF870149
	v_add3_u32 v1, v1, v2, s6                                  // 000000DDB4DC: D6550001 001A0501
	s_lshl_b32 s6, s34, 7                                      // 000000DDB4E4: 84068722
	v_and_b32_e32 v2, 0x7f, v77                                // 000000DDB4E8: 36049AFF 0000007F
	s_ashr_i32 s7, s6, 31                                      // 000000DDB4F0: 86079F06
	.long 0xd73c0000                                           // 000000DDB4F4: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000DDB4F8: 02020082
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000DDB4FC: 84868206
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DDB500: BF870132
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000DDB504: 30040482
	s_add_u32 s6, s30, s6                                      // 000000DDB508: 8006061E
	s_addc_u32 s7, s31, s7                                     // 000000DDB50C: 8207071F
	.long 0xd7006a00                                           // 000000DDB510: D7006A00
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 000000DDB514: 02020006
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DDB518: BF870111
	v_add_co_ci_u32_e64 v1, null, s7, v1, vcc_lo               // 000000DDB51C: D5207C01 01AA0207
	.long 0xd7006a00                                           // 000000DDB524: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 000000DDB528: 02020500
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDB52C: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000DDB530: D5207C01 01AA0280
	s_waitcnt lgkmcnt(0)                                       // 000000DDB538: BF89FC07
	global_store_b32 v[0:1], v3, off                           // 000000DDB53C: DC6A0000 007C0300
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DDB544: 8C7E057E
	.long 0xd44a0005                                           // 000000DDB548: D44A0005
	v_cndmask_b32_e32 v1, 0, v77, vcc_lo                       // 000000DDB54C: 02029A80
	s_waitcnt_vscnt null, 0x0                                  // 000000DDB550: BC7C0000
	buffer_gl1_inv                                             // 000000DDB554: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DDB55C: E0AC0000 00000000
	s_barrier                                                  // 000000DDB564: BFBD0000
	buffer_gl0_inv                                             // 000000DDB568: E0AC0000 00000000
	s_and_saveexec_b32 s6, s5                                  // 000000DDB570: BE862005
	s_cbranch_execz 29                                         // 000000DDB574: BFA5001D <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1eec>
	s_mov_b32 s8, exec_lo                                      // 000000DDB578: BE88007E
	s_mov_b32 s7, exec_lo                                      // 000000DDB57C: BE87007E
	.long 0xd71f0000                                           // 000000DDB580: D71F0000
	v_cndmask_b32_e32 v0, s8, v128, vcc_lo                     // 000000DDB584: 02010008
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDB588: BF870001
	v_cmpx_eq_u32_e32 0, v0                                    // 000000DDB58C: 7D940080
	s_cbranch_execz 9                                          // 000000DDB590: BFA50009 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1eb8>
	s_lshl_b64 s[18:19], s[34:35], 2                           // 000000DDB594: 84928222
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000DDB598: BF8704B9
	s_add_u32 s18, s40, s18                                    // 000000DDB59C: 80121228
	s_addc_u32 s19, s41, s19                                   // 000000DDB5A0: 82131329
	s_bcnt1_i32_b32 s8, s8                                     // 000000DDB5A4: BE881808
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, s8              // 000000DDB5A8: CA100080 01020008
	global_atomic_add_u32 v1, v1, v2, s[18:19] glc             // 000000DDB5B0: DCD64000 01120201
	s_or_b32 exec_lo, exec_lo, s7                              // 000000DDB5B8: 8C7E077E
	s_waitcnt vmcnt(0)                                         // 000000DDB5BC: BF8903F7
	v_readfirstlane_b32 s7, v1                                 // 000000DDB5C0: 7E0E0501
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDB5C4: BF870001
	v_dual_mov_b32 v1, 0 :: v_dual_add_nc_u32 v0, s7, v0       // 000000DDB5C8: CA200080 01000007
	s_add_i32 s7, s11, -1                                      // 000000DDB5D0: 8107C10B
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000DDB5D4: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s7, v0                            // 000000DDB5D8: 7C940007
	v_cndmask_b32_e64 v0, 0, 1, vcc_lo                         // 000000DDB5DC: D5010000 01A90280
	ds_store_b32 v1, v0 offset:20496                           // 000000DDB5E4: D8345010 00000001
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DDB5EC: 8C7E067E
	v_mov_b32_e32 v0, 0                                        // 000000DDB5F0: 7E000280
	s_waitcnt lgkmcnt(0)                                       // 000000DDB5F4: BF89FC07
	s_barrier                                                  // 000000DDB5F8: BFBD0000
	buffer_gl0_inv                                             // 000000DDB5FC: E0AC0000 00000000
	ds_load_b32 v0, v0 offset:20496                            // 000000DDB604: D8D85010 00000000
	s_waitcnt lgkmcnt(0)                                       // 000000DDB60C: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000DDB610: 7C940080
	s_cbranch_vccnz 62                                         // 000000DDB614: BFA4003E <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2010>
	buffer_gl1_inv                                             // 000000DDB618: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DDB620: E0AC0000 00000000
	s_and_saveexec_b32 s6, s4                                  // 000000DDB628: BE862004
	s_cbranch_execz 44                                         // 000000DDB62C: BFA5002C <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1fe0>
	v_and_b32_e32 v1, 0x7f, v77                                // 000000DDB630: 36029AFF 0000007F
	s_lshl_b32 s8, s34, 7                                      // 000000DDB638: 84088722
	s_ashr_i32 s4, s37, 31                                     // 000000DDB63C: 86049F25
	s_ashr_i32 s9, s8, 31                                      // 000000DDB640: 86099F08
	v_lshrrev_b32_e32 v0, 7, v77                               // 000000DDB644: 32009A87
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v2, 2, v1       // 000000DDB648: CA220080 01020282
	s_lshl_b64 s[8:9], s[8:9], 2                               // 000000DDB650: 84888208
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DDB654: BF8700A9
	s_add_u32 s7, s30, s8                                      // 000000DDB658: 8007081E
	s_addc_u32 s8, s31, s9                                     // 000000DDB65C: 8208091F
	.long 0xd7000702                                           // 000000DDB660: D7000702
	v_cndmask_b32_e32 v1, s7, v2, vcc_lo                       // 000000DDB664: 02020407
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDB668: BF870001
	v_add_co_ci_u32_e64 v3, null, s8, 0, s7                    // 000000DDB66C: D5207C03 001D0008
	s_mov_b32 s7, s37                                          // 000000DDB674: BE870025
	s_nop 0                                                    // 000000DDB678: BF800000
	s_nop 0                                                    // 000000DDB67C: BF800000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000DDB680: BF8704A9
	v_mad_u64_u32 v[4:5], null, v0, s7, 0                      // 000000DDB684: D6FE7C04 02000F00
	s_add_i32 s11, s11, -1                                     // 000000DDB68C: 810BC10B
	s_cmp_eq_u32 s11, 0                                        // 000000DDB690: BF06800B
	v_mad_u64_u32 v[5:6], null, v0, s4, v[5:6]                 // 000000DDB694: D6FE7C05 04140900
	v_add_nc_u32_e32 v0, 2, v0                                 // 000000DDB69C: 4A000082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDB6A0: BF870092
	.long 0xd73c0004                                           // 000000DDB6A4: D73C0004
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 000000DDB6A8: 02020882
	.long 0xd7006a04                                           // 000000DDB6AC: D7006A04
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000DDB6B0: 02020902
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDB6B4: BF870001
	v_add_co_ci_u32_e64 v5, null, v3, v5, vcc_lo               // 000000DDB6B8: D5207C05 01AA0B03
	global_load_b32 v4, v[4:5], off glc                        // 000000DDB6C0: DC524000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000DDB6C8: BF8903F7
	v_add_f32_e32 v1, v1, v4                                   // 000000DDB6CC: 06020901
	s_cbranch_scc0 65515                                       // 000000DDB6D0: BFA1FFEB <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1f80>
	v_lshlrev_b32_e32 v0, 2, v77                               // 000000DDB6D4: 30009A82
	ds_store_b32 v0, v1 offset:8192                            // 000000DDB6D8: D8342000 00000100
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DDB6E0: 8C7E067E
	s_and_saveexec_b32 s4, s5                                  // 000000DDB6E4: BE842005
	s_cbranch_execz 6                                          // 000000DDB6E8: BFA50006 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2004>
	s_lshl_b64 s[6:7], s[34:35], 2                             // 000000DDB6EC: 84868222
	v_mov_b32_e32 v0, 0                                        // 000000DDB6F0: 7E000280
	s_add_u32 s6, s40, s6                                      // 000000DDB6F4: 80060628
	s_addc_u32 s7, s41, s7                                     // 000000DDB6F8: 82070729
	global_store_b32 v0, v0, s[6:7]                            // 000000DDB6FC: DC6A0000 00060000
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DDB704: 8C7E047E
	s_cbranch_execnz 2                                         // 000000DDB708: BFA60002 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2014>
	s_branch 382                                               // 000000DDB70C: BFA0017E <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2608>
	s_branch 381                                               // 000000DDB710: BFA0017D <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2608>
	v_cmp_gt_i32_e32 vcc_lo, s36, v11                          // 000000DDB714: 7C881624
	.long 0xd44c0004                                           // 000000DDB718: D44C0004
	v_cndmask_b32_e32 v1, 64, v77, vcc_lo                      // 000000DDB71C: 02029AC0
	s_waitcnt lgkmcnt(0)                                       // 000000DDB720: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000DDB724: BC7C0000
	s_barrier                                                  // 000000DDB728: BFBD0000
	buffer_gl0_inv                                             // 000000DDB72C: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 000000DDB734: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DDB738: BF870009
	s_and_saveexec_b32 s5, s4                                  // 000000DDB73C: BE852004
	s_cbranch_execz 368                                        // 000000DDB740: BFA50170 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2604>
	v_and_b32_e32 v0, 15, v77                                  // 000000DDB744: 36009A8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDB748: BF870091
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000DDB74C: 30020082
	v_lshl_or_b32 v1, v11, 9, v1                               // 000000DDB750: D6560001 0405130B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDB758: BF870001
	v_add_nc_u32_e32 v7, 0x2000, v1                            // 000000DDB75C: 4A0E02FF 00002000
	ds_load_2addr_b32 v[1:2], v7 offset1:16                    // 000000DDB764: D8DC1000 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:32 offset1:48         // 000000DDB76C: D8DC3020 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:64 offset1:80         // 000000DDB774: D8DC5040 05000007
	ds_load_2addr_b32 v[7:8], v7 offset0:96 offset1:112        // 000000DDB77C: D8DC7060 07000007
	v_and_b32_e32 v9, 1, v77                                   // 000000DDB784: 36129A81
	v_and_b32_e32 v10, 2, v77                                  // 000000DDB788: 36149A82
	s_waitcnt lgkmcnt(3)                                       // 000000DDB78C: BF89FC37
	v_dual_add_f32 v13, v1, v2 :: v_dual_and_b32 v12, 4, v77   // 000000DDB790: C9240501 0D0C9A84
	s_waitcnt lgkmcnt(2)                                       // 000000DDB798: BF89FC27
	v_dual_sub_f32 v1, v1, v2 :: v_dual_add_f32 v2, v3, v4     // 000000DDB79C: C9480501 01020903
	s_waitcnt lgkmcnt(1)                                       // 000000DDB7A4: BF89FC17
	v_dual_sub_f32 v3, v3, v4 :: v_dual_add_f32 v4, v5, v6     // 000000DDB7A8: C9480903 03040D05
	s_waitcnt lgkmcnt(0)                                       // 000000DDB7B0: BF89FC07
	v_dual_sub_f32 v5, v5, v6 :: v_dual_add_f32 v6, v7, v8     // 000000DDB7B4: C9480D05 05061107
	v_dual_sub_f32 v7, v7, v8 :: v_dual_add_f32 v8, v13, v2    // 000000DDB7BC: C9481107 0708050D
	v_sub_f32_e32 v2, v13, v2                                  // 000000DDB7C4: 0804050D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DDB7C8: BF870223
	v_dual_add_f32 v13, v1, v3 :: v_dual_add_f32 v14, v4, v6   // 000000DDB7CC: C9080701 0D0E0D04
	v_dual_sub_f32 v1, v1, v3 :: v_dual_sub_f32 v4, v4, v6     // 000000DDB7D4: C94A0701 01040D04
	v_add_f32_e32 v3, v5, v7                                   // 000000DDB7DC: 06060F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DDB7E0: BF870233
	v_dual_sub_f32 v5, v5, v7 :: v_dual_add_f32 v6, v8, v14    // 000000DDB7E4: C9480F05 05061D08
	v_sub_f32_e32 v7, v8, v14                                  // 000000DDB7EC: 080E1D08
	v_cmp_eq_u32_e32 vcc_lo, 0, v9                             // 000000DDB7F0: 7C941280
	v_add_f32_e32 v8, v13, v3                                  // 000000DDB7F4: 0610070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000DDB7F8: 0806070D
	v_add_f32_e32 v13, v2, v4                                  // 000000DDB7FC: 061A0902
	v_sub_f32_e32 v2, v2, v4                                   // 000000DDB800: 08040902
	v_add_f32_e32 v4, v1, v5                                   // 000000DDB804: 06080B01
	v_mov_b32_dpp v9, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DDB808: 7E1202FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000DDB810: D5010008 21AA1108
	v_mov_b32_dpp v17, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DDB818: 7E2202FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000DDB820: D5010003 21AA0703
	v_mov_b32_dpp v15, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DDB828: 7E1E02FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000DDB830: D5010004 21AA0904
	v_sub_f32_e32 v1, v1, v5                                   // 000000DDB838: 08020B01
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DDB83C: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000DDB844: D501000D 21AA1B0D
	v_mov_b32_dpp v16, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DDB84C: 7E2002FA FF016107
	v_add_f32_e32 v4, v4, v15                                  // 000000DDB854: 06081F04
	v_mov_b32_dpp v20, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DDB858: 7E2802FA FF016101
	v_cndmask_b32_e64 v21, -v1, v1, vcc_lo                     // 000000DDB860: D5010015 21AA0301
	v_add_f32_e32 v1, v8, v9                                   // 000000DDB868: 06021308
	v_add_f32_e32 v8, v3, v17                                  // 000000DDB86C: 06102303
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DDB870: 7E0A02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000DDB878: D5010006 21AA0D06
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000DDB880: D5010007 21AA0F07
	v_mov_b32_dpp v18, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DDB888: 7E2402FA FF016102
	v_cndmask_b32_e64 v19, -v2, v2, vcc_lo                     // 000000DDB890: D5010013 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000DDB898: 7C941480
	v_add_f32_e32 v2, v6, v5                                   // 000000DDB89C: 06040B06
	v_mov_b32_dpp v6, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DDB8A0: 7E0C02FA FF016201
	v_mov_b32_dpp v10, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DDB8A8: 7E1402FA FF016204
	.long 0xd44a0004                                           // 000000DDB8B0: D44A0004
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000DDB8B4: 02021880
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 000000DDB8B8: D5010001 21AA0301
	v_mov_b32_dpp v3, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DDB8C0: 7E0602FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000DDB8C8: D5010002 21AA0502
	v_add_f32_e32 v5, v13, v14                                 // 000000DDB8D0: 060A1D0D
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000DDB8D4: D5010004 21AA0904
	v_add_f32_e32 v13, v21, v20                                // 000000DDB8DC: 061A2915
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DDB8E0: 7E1C02FA FF016208
	v_add_f32_e32 v2, v2, v3                                   // 000000DDB8E8: 06040702
	v_mov_b32_dpp v9, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DDB8EC: 7E1202FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000DDB8F4: D5010005 21AA0B05
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DDB8FC: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000DDB904: D501000D 21AA1B0D
	v_add_f32_e32 v3, v4, v10                                  // 000000DDB90C: 06061504
	v_mov_b32_dpp v4, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DDB910: 7E0802FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000DDB918: D5010002 20120502
	v_add_f32_e32 v1, v1, v6                                   // 000000DDB920: 06020D01
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000DDB924: D5010008 21AA1108
	v_add_f32_e32 v5, v5, v9                                   // 000000DDB92C: 060A1305
	v_mov_b32_dpp v9, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DDB930: 7E1202FA FF016403
	v_add_f32_e32 v2, v2, v4                                   // 000000DDB938: 06040902
	v_cndmask_b32_e64 v6, -v1, v1, s4                          // 000000DDB93C: D5010006 20120301
	v_mov_b32_dpp v1, v1 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DDB944: 7E0202FA FF016401
	v_add_f32_e32 v7, v7, v16                                  // 000000DDB94C: 060E2107
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000DDB950: D5010003 20120703
	v_add_f32_e32 v8, v8, v14                                  // 000000DDB958: 06101D08
	v_mov_b32_dpp v10, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DDB95C: 7E1402FA FF016405
	v_add_f32_e32 v6, v6, v1                                   // 000000DDB964: 060C0306
	v_mov_b32_dpp v12, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DDB968: 7E1802FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000DDB970: D5010007 21AA0F07
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000DDB978: D5010005 20120B05
	v_mov_b32_dpp v1, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DDB980: 7E0202FA FF016802
	v_mov_b32_dpp v4, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DDB988: 7E0802FA FF016806
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DDB990: BF870214
	v_add_f32_e32 v7, v7, v12                                  // 000000DDB994: 060E1907
	v_add_f32_e32 v5, v5, v10                                  // 000000DDB998: 060A1505
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000DDB99C: BF870252
	v_mov_b32_dpp v10, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DDB9A0: 7E1402FA FF016407
	v_cndmask_b32_e64 v14, -v7, v7, s4                         // 000000DDB9A8: D501000E 20120F07
	v_add_f32_e32 v3, v3, v9                                   // 000000DDB9B0: 06061303
	v_add_f32_e32 v9, v19, v18                                 // 000000DDB9B4: 06122513
	v_mov_b32_dpp v7, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DDB9B8: 7E0E02FA FF016805
	v_add_f32_e32 v14, v14, v10                                // 000000DDB9C0: 061C150E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DDB9C4: BF8700A3
	v_mov_b32_dpp v12, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DDB9C8: 7E1802FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000DDB9D0: D5010009 21AA1309
	v_add_f32_e32 v9, v9, v12                                  // 000000DDB9D8: 06121909
	v_add_f32_e32 v12, v13, v15                                // 000000DDB9DC: 06181F0D
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DDB9E0: 7E1A02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000DDB9E8: D5010008 20121108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DDB9F0: BF870214
	v_mov_b32_dpp v15, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DDB9F4: 7E1E02FA FF016409
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DDB9FC: 7E2202FA FF01640C
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000DDBA04: D5010009 20121309
	v_cndmask_b32_e64 v12, -v12, v12, s4                       // 000000DDBA0C: D501000C 2012190C
	v_add_f32_e32 v16, v8, v13                                 // 000000DDBA14: 06201B08
	v_mov_b32_dpp v8, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DDBA18: 7E1002FA FF016803
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DDBA20: BF870214
	v_add_f32_e32 v15, v9, v15                                 // 000000DDBA24: 061E1F09
	v_add_f32_e32 v17, v12, v17                                // 000000DDBA28: 0622230C
	v_mov_b32_dpp v9, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DDBA2C: 7E1202FA FF01680E
	v_mov_b32_dpp v10, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DDBA34: 7E1402FA FF016810
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DDBA3C: BF870214
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DDBA40: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DDBA48: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s3                             // 000000DDBA50: 8B7E037E
	s_cbranch_execz 171                                        // 000000DDBA54: BFA500AB <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2604>
	v_lshl_or_b32 v18, s34, 7, v0                              // 000000DDBA58: D6560012 04010E22
	v_and_b32_e32 v0, 8, v77                                   // 000000DDBA60: 36009A88
	.long 0x7f2c3880                                           // 000000DDBA64: 7F2C3880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DDBA68: BF870113
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000DDBA6C: 3426249F
	.long 0x7f2e3996                                           // 000000DDBA70: 7F2E3996
	.long 0x7f303996                                           // 000000DDBA74: 7F303996
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDBA78: BF870093
	.long 0xd73c0012                                           // 000000DDBA7C: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000DDBA80: 02022481
	.long 0xd7006a14                                           // 000000DDBA84: D7006A14
	v_cndmask_b32_e32 v1, s22, v18, vcc_lo                     // 000000DDBA88: 02022416
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDBA8C: BF870001
	v_add_co_ci_u32_e64 v21, null, s23, v19, vcc_lo            // 000000DDBA90: D5207C15 01AA2617
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000DDBA98: 7C940080
	s_clause 0x7                                               // 000000DDBA9C: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000DDBAA0: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000DDBAA8: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 000000DDBAB0: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 000000DDBAB8: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 000000DDBAC0: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 000000DDBAC8: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 000000DDBAD0: DC8200C0 1C7C0014
	global_load_d16_b16 v29, v[20:21], off offset:224          // 000000DDBAD8: DC8200E0 1D7C0014
	v_mad_i64_i32 v[20:21], null, s37, v11, 0                  // 000000DDBAE0: D6FF7C14 02021625
	v_cndmask_b32_e64 v0, -v6, v6, vcc_lo                      // 000000DDBAE8: D5010000 21AA0D06
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000DDBAF0: D5010002 21AA0502
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000DDBAF8: D5010003 21AA0703
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000DDBB00: D501000E 21AA1D0E
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000DDBB08: D501000F 21AA1F0F
	v_add_f32_e32 v0, v0, v4                                   // 000000DDBB10: 06000900
	v_cndmask_b32_e64 v4, -v5, v5, vcc_lo                      // 000000DDBB14: D5010004 21AA0B05
	.long 0xd73c0014                                           // 000000DDBB1C: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 000000DDBB20: 02022881
	v_cndmask_b32_e64 v5, -v16, v16, vcc_lo                    // 000000DDBB24: D5010005 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000DDBB2C: D5010010 21AA2311
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000DDBB34: BF8700B4
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v4, v4, v7     // 000000DDBB38: C9081103 03040F04
	v_add_f32_e32 v7, v14, v9                                  // 000000DDBB40: 060E130E
	.long 0xd7006a11                                           // 000000DDBB44: D7006A11
	v_cndmask_b32_e32 v1, s28, v20, vcc_lo                     // 000000DDBB48: 0202281C
	v_add_co_ci_u32_e64 v20, null, s29, v21, vcc_lo            // 000000DDBB4C: D5207C14 01AA2A1D
	v_dual_add_f32 v2, v2, v1 :: v_dual_mul_f32 v21, 0x3db504f3, v0// 000000DDBB54: C9060302 021400FF 3DB504F3
	v_add_f32_e32 v5, v5, v10                                  // 000000DDBB60: 060A1505
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_add_f32 v8, v15, v12// 000000DDBB64: C8C806FF 0308190F 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDBB70: BF870193
	v_dual_add_f32 v9, v16, v13 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 000000DDBB74: C9061B10 090204FF 3DB504F3
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000DDBB80: C8C608FF 04040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DDBB8C: BF8700D3
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000DDBB90: C8C60EFF 070810FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 000000DDBB9C: BF891FF7
	.long 0x7f0c3996                                           // 000000DDBBA0: 7F0C3996
	.long 0x7f163996                                           // 000000DDBBA4: 7F163996
	.long 0xd7006a00                                           // 000000DDBBA8: D7006A00
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000DDBBAC: 02022511
	v_add_co_ci_u32_e64 v1, null, v20, v19, vcc_lo             // 000000DDBBB0: D5207C01 01AA2714
	v_fma_mix_f32 v10, v22, v21, neg(0) op_sel_hi:[1,0,0]      // 000000DDBBB8: CC20000A 8A022B16
	s_waitcnt vmcnt(6)                                         // 000000DDBBC0: BF891BF7
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 000000DDBBC4: CC200002 8A020517
	s_waitcnt vmcnt(5)                                         // 000000DDBBCC: BF8917F7
	v_fma_mix_f32 v4, v24, v4, neg(0) op_sel_hi:[1,0,0]        // 000000DDBBD0: CC200004 8A020918
	s_waitcnt vmcnt(4)                                         // 000000DDBBD8: BF8913F7
	v_fma_mix_f32 v3, v25, v3, neg(0) op_sel_hi:[1,0,0]        // 000000DDBBDC: CC200003 8A020719
	s_waitcnt vmcnt(3)                                         // 000000DDBBE4: BF890FF7
	v_fma_mix_f32 v7, v26, v7, neg(0) op_sel_hi:[1,0,0]        // 000000DDBBE8: CC200007 8A020F1A
	.long 0x7e2c398a                                           // 000000DDBBF0: 7E2C398A
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000DDBBF4: 101212FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 000000DDBBFC: BF890BF7
	v_fma_mix_f32 v5, v27, v5, neg(0) op_sel_hi:[1,0,0]        // 000000DDBC00: CC200005 8A020B1B
	s_waitcnt vmcnt(1)                                         // 000000DDBC08: BF8907F7
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DDBC0C: CC200008 8A02111C
	.long 0x7e0c3982                                           // 000000DDBC14: 7E0C3982
	v_and_b32_e32 v12, 1, v22                                  // 000000DDBC18: 36182C81
	.long 0x7e2c3983                                           // 000000DDBC1C: 7E2C3983
	s_waitcnt vmcnt(0)                                         // 000000DDBC20: BF8903F7
	v_fma_mix_f32 v9, v29, v9, neg(0) op_sel_hi:[1,0,0]        // 000000DDBC24: CC200009 8A02131D
	.long 0x7e163984                                           // 000000DDBC2C: 7E163984
	.long 0x7e2e3987                                           // 000000DDBC30: 7E2E3987
	.long 0x7e303988                                           // 000000DDBC34: 7E303988
	v_and_b32_e32 v13, 1, v22                                  // 000000DDBC38: 361A2C81
	.long 0x7e2c3985                                           // 000000DDBC3C: 7E2C3985
	v_and_b32_e32 v6, 1, v6                                    // 000000DDBC40: 360C0C81
	v_and_b32_e32 v11, 1, v11                                  // 000000DDBC44: 36161681
	v_and_b32_e32 v14, 1, v23                                  // 000000DDBC48: 361C2E81
	v_and_b32_e32 v16, 1, v24                                  // 000000DDBC4C: 36203081
	v_and_b32_e32 v15, 1, v22                                  // 000000DDBC50: 361E2C81
	.long 0x7e2c3989                                           // 000000DDBC54: 7E2C3989
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000DDBC58: D6550002 03FE0D02 00007FFF
	v_add3_u32 v10, v10, v12, 0x7fff                           // 000000DDBC64: D655000A 03FE190A 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 000000DDBC70: D6550004 03FE1704 00007FFF
	v_add3_u32 v3, v3, v13, 0x7fff                             // 000000DDBC7C: D6550003 03FE1B03 00007FFF
	v_and_b32_e32 v6, 1, v22                                   // 000000DDBC88: 360C2C81
	v_add3_u32 v7, v7, v14, 0x7fff                             // 000000DDBC8C: D6550007 03FE1D07 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 000000DDBC98: D6550008 03FE2108 00007FFF
	v_add3_u32 v5, v5, v15, 0x7fff                             // 000000DDBCA4: D6550005 03FE1F05 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DDBCB0: BF870004
	v_add3_u32 v6, v9, v6, 0x7fff                              // 000000DDBCB4: D6550006 03FE0D09 00007FFF
	s_clause 0x7                                               // 000000DDBCC0: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000DDBCC4: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v10, off offset:32         // 000000DDBCCC: DC960020 007C0A00
	global_store_d16_hi_b16 v[0:1], v4, off offset:64          // 000000DDBCD4: DC960040 007C0400
	global_store_d16_hi_b16 v[0:1], v3, off offset:96          // 000000DDBCDC: DC960060 007C0300
	global_store_d16_hi_b16 v[0:1], v7, off offset:128         // 000000DDBCE4: DC960080 007C0700
	global_store_d16_hi_b16 v[0:1], v5, off offset:160         // 000000DDBCEC: DC9600A0 007C0500
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 000000DDBCF4: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v6, off offset:224         // 000000DDBCFC: DC9600E0 007C0600
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DDBD04: 8C7E057E
	s_mov_b32 s4, 0                                            // 000000DDBD08: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DDBD0C: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000DDBD10: 8B6A047E
	s_cbranch_vccz 6044                                        // 000000DDBD14: BFA3179C <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8488>
	s_load_b512 s[36:51], s[0:1], null                         // 000000DDBD18: F4100900 F8000000
	v_mov_b32_e32 v0, 0                                        // 000000DDBD20: 7E000280
	s_mul_hi_i32 s0, s2, 0x66666667                            // 000000DDBD24: 9700FF02 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000DDBD2C: BF8704A9
	s_lshr_b32 s1, s0, 31                                      // 000000DDBD30: 85019F00
	s_ashr_i32 s4, s0, 3                                       // 000000DDBD34: 86048300
	s_add_i32 s4, s4, s1                                       // 000000DDBD38: 81040104
	s_waitcnt lgkmcnt(0)                                       // 000000DDBD3C: BF89FC07
	global_load_b32 v1, v0, s[46:47]                           // 000000DDBD40: DC520000 012E0000
	s_waitcnt vmcnt(0)                                         // 000000DDBD48: BF8903F7
	v_cmp_ge_i32_e32 vcc_lo, s4, v1                            // 000000DDBD4C: 7C8C0204
	s_cbranch_vccnz 6029                                       // 000000DDBD50: BFA4178D <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8488>
	s_mul_i32 s0, s4, 5                                        // 000000DDBD54: 96008504
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DDBD58: BF870499
	s_ashr_i32 s1, s0, 31                                      // 000000DDBD5C: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 4                               // 000000DDBD60: 84808400
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DDBD64: BF870009
	s_add_u32 s0, s42, s0                                      // 000000DDBD68: 8000002A
	s_addc_u32 s1, s43, s1                                     // 000000DDBD6C: 8201012B
	s_clause 0x1                                               // 000000DDBD70: BF850001
	global_load_b64 v[1:2], v0, s[0:1] offset:8                // 000000DDBD74: DC560008 01000000
	global_load_b32 v0, v0, s[0:1]                             // 000000DDBD7C: DC520000 00000000
	s_waitcnt vmcnt(1)                                         // 000000DDBD84: BF8907F7
	v_readfirstlane_b32 s5, v1                                 // 000000DDBD88: 7E0A0501
	v_readfirstlane_b32 s0, v2                                 // 000000DDBD8C: 7E000502
	s_sub_i32 s1, s0, s5                                       // 000000DDBD90: 81810500
	s_mov_b32 s0, exec_lo                                      // 000000DDBD94: BE80007E
	s_min_i32 s3, s1, 2                                        // 000000DDBD98: 89038201
	v_cmpx_gt_u32_e32 2, v77                                   // 000000DDBD9C: 7D989A82
	s_cbranch_execz 22                                         // 000000DDBDA0: BFA50016 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x26fc>
	v_mov_b32_e32 v1, 0                                        // 000000DDBDA4: 7E020280
	s_mov_b32 s6, exec_lo                                      // 000000DDBDA8: BE86007E
	.long 0xd4cc007e                                           // 000000DDBDAC: D4CC007E
	v_cndmask_b32_e32 v1, s3, v77, vcc_lo                      // 000000DDBDB0: 02029A03
	s_cbranch_execz 12                                         // 000000DDBDB4: BFA5000C <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x26e8>
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s5, v77      // 000000DDBDB8: CA200080 02009A05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDBDC0: BF870091
	.long 0xd73c0001                                           // 000000DDBDC4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000DDBDC8: 02020282
	.long 0xd7006a01                                           // 000000DDBDCC: D7006A01
	v_cndmask_b32_e32 v1, s44, v1, vcc_lo                      // 000000DDBDD0: 0202022C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDBDD4: BF870001
	v_add_co_ci_u32_e64 v2, null, s45, v2, vcc_lo              // 000000DDBDD8: D5207C02 01AA042D
	global_load_b32 v1, v[1:2], off                            // 000000DDBDE0: DC520000 017C0001
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DDBDE8: 8C7E067E
	v_lshlrev_b32_e32 v2, 2, v77                               // 000000DDBDEC: 30049A82
	s_waitcnt vmcnt(0)                                         // 000000DDBDF0: BF8903F7
	ds_store_b32 v2, v1 offset:20480                           // 000000DDBDF4: D8345000 00000102
	s_or_b32 exec_lo, exec_lo, s0                              // 000000DDBDFC: 8C7E007E
	s_cmp_gt_i32 s1, 0                                         // 000000DDBE00: BF028001
	s_mov_b32 s6, 0                                            // 000000DDBE04: BE860080
	s_cselect_b32 s5, -1, 0                                    // 000000DDBE08: 980580C1
	s_cmp_lt_i32 s1, 1                                         // 000000DDBE0C: BF048101
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000DDBE10: BF890007
	s_waitcnt_vscnt null, 0x0                                  // 000000DDBE14: BC7C0000
	s_barrier                                                  // 000000DDBE18: BFBD0000
	buffer_gl0_inv                                             // 000000DDBE1C: E0AC0000 00000000
	s_cbranch_scc1 187                                         // 000000DDBE24: BFA200BB <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2a14>
	.long 0xd44c0000                                           // 000000DDBE28: D44C0000
	v_cndmask_b32_e32 v1, 0x140, v77, vcc_lo                   // 000000DDBE2C: 02029AFF 00000140
	s_cmp_eq_u32 s1, 1                                         // 000000DDBE34: BF068101
	s_mov_b32 s1, -1                                           // 000000DDBE38: BE8100C1
	s_cbranch_scc1 119                                         // 000000DDBE3C: BFA20077 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x291c>
	v_lshlrev_b32_e32 v5, 4, v77                               // 000000DDBE40: 300A9A84
	v_or_b32_e32 v6, 0xffffff00, v77                           // 000000DDBE44: 380C9AFF FFFFFF00
	s_and_b32 s6, s3, 2                                        // 000000DDBE4C: 8B068203
	s_mov_b32 s7, 0                                            // 000000DDBE50: BE870080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDBE54: BF870092
	.long 0xd7000101                                           // 000000DDBE58: D7000101
	v_cndmask_b32_e32 v1, s40, v5, vcc_lo                      // 000000DDBE5C: 02020A28
	v_add_co_ci_u32_e64 v2, null, s41, 0, s1                   // 000000DDBE60: D5207C02 00050029
	s_branch 7                                                 // 000000DDBE68: BFA00007 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2788>
	s_or_b32 exec_lo, exec_lo, s9                              // 000000DDBE6C: 8C7E097E
	v_add_nc_u32_e32 v5, 0x2800, v5                            // 000000DDBE70: 4A0A0AFF 00002800
	s_add_i32 s7, s7, 2                                        // 000000DDBE78: 81078207
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DDBE7C: BF870009
	s_cmp_eq_u32 s7, s6                                        // 000000DDBE80: BF060607
	s_cbranch_scc1 99                                          // 000000DDBE84: BFA20063 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2914>
	s_lshl2_add_u32 s8, s7, 0x5000                             // 000000DDBE88: 8788FF07 00005000
	s_and_saveexec_b32 s9, s0                                  // 000000DDBE90: BE892000
	s_cbranch_execz 46                                         // 000000DDBE94: BFA5002E <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2850>
	v_dual_mov_b32 v3, s8 :: v_dual_mov_b32 v8, v6             // 000000DDBE98: CA100008 03080106
	v_mov_b32_e32 v7, v5                                       // 000000DDBEA0: 7E0E0305
	ds_load_b32 v3, v3                                         // 000000DDBEA4: D8D80000 03000003
	s_waitcnt lgkmcnt(0)                                       // 000000DDBEAC: BF89FC07
	v_readfirstlane_b32 s1, v3                                 // 000000DDBEB0: 7E020503
	s_mul_hi_i32 s1, s1, 0x66666667                            // 000000DDBEB4: 9701FF01 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000DDBEBC: BF8704A9
	s_lshr_b32 s10, s1, 31                                     // 000000DDBEC0: 850A9F01
	s_ashr_i32 s1, s1, 2                                       // 000000DDBEC4: 86018201
	s_add_i32 s1, s1, s10                                      // 000000DDBEC8: 81010A01
	s_mov_b32 s10, 0                                           // 000000DDBECC: BE8A0080
	v_mad_i64_i32 v[3:4], null, 0x1400, s1, v[1:2]             // 000000DDBED0: D6FF7C03 040402FF 00001400
	s_nop 0                                                    // 000000DDBEDC: BF800000
	s_nop 0                                                    // 000000DDBEE0: BF800000
	s_nop 0                                                    // 000000DDBEE4: BF800000
	s_nop 0                                                    // 000000DDBEE8: BF800000
	s_nop 0                                                    // 000000DDBEEC: BF800000
	s_nop 0                                                    // 000000DDBEF0: BF800000
	s_nop 0                                                    // 000000DDBEF4: BF800000
	s_nop 0                                                    // 000000DDBEF8: BF800000
	s_nop 0                                                    // 000000DDBEFC: BF800000
	global_load_b128 v[9:12], v[3:4], off                      // 000000DDBF00: DC5E0000 097C0003
	v_add_nc_u32_e32 v8, 0x100, v8                             // 000000DDBF08: 4A1010FF 00000100
	.long 0xd7006a03                                           // 000000DDBF10: D7006A03
	v_cndmask_b32_e32 v1, 0x1000, v3, vcc_lo                   // 000000DDBF14: 020206FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDBF1C: BF870191
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000DDBF20: D5207C04 01AA0880
	.long 0xd4490001                                           // 000000DDBF28: D4490001
	v_cndmask_b32_e32 v1, 63, v8, vcc_lo                       // 000000DDBF2C: 020210BF
	s_or_b32 s10, s1, s10                                      // 000000DDBF30: 8C0A0A01
	s_waitcnt vmcnt(0)                                         // 000000DDBF34: BF8903F7
	ds_store_b128 v7, v[9:12] offset:10240                     // 000000DDBF38: DB7C2800 00000907
	v_add_nc_u32_e32 v7, 0x1000, v7                            // 000000DDBF40: 4A0E0EFF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000DDBF48: 917E0A7E
	s_cbranch_execnz 65516                                     // 000000DDBF4C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2800>
	s_or_b32 exec_lo, exec_lo, s9                              // 000000DDBF50: 8C7E097E
	s_and_saveexec_b32 s9, s0                                  // 000000DDBF54: BE892000
	s_cbranch_execz 65476                                      // 000000DDBF58: BFA5FFC4 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x276c>
	v_dual_mov_b32 v3, s8 :: v_dual_mov_b32 v8, v5             // 000000DDBF5C: CA100008 03080105
	v_mov_b32_e32 v7, v6                                       // 000000DDBF64: 7E0E0306
	ds_load_b32 v3, v3 offset:4                                // 000000DDBF68: D8D80004 03000003
	s_waitcnt lgkmcnt(0)                                       // 000000DDBF70: BF89FC07
	v_readfirstlane_b32 s1, v3                                 // 000000DDBF74: 7E020503
	s_mul_hi_i32 s1, s1, 0x66666667                            // 000000DDBF78: 9701FF01 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000DDBF80: BF8704A9
	s_lshr_b32 s8, s1, 31                                      // 000000DDBF84: 85089F01
	s_ashr_i32 s1, s1, 2                                       // 000000DDBF88: 86018201
	s_add_i32 s1, s1, s8                                       // 000000DDBF8C: 81010801
	s_mov_b32 s8, 0                                            // 000000DDBF90: BE880080
	v_mad_i64_i32 v[3:4], null, 0x1400, s1, v[1:2]             // 000000DDBF94: D6FF7C03 040402FF 00001400
	s_nop 0                                                    // 000000DDBFA0: BF800000
	s_nop 0                                                    // 000000DDBFA4: BF800000
	s_nop 0                                                    // 000000DDBFA8: BF800000
	s_nop 0                                                    // 000000DDBFAC: BF800000
	s_nop 0                                                    // 000000DDBFB0: BF800000
	s_nop 0                                                    // 000000DDBFB4: BF800000
	s_nop 0                                                    // 000000DDBFB8: BF800000
	s_nop 0                                                    // 000000DDBFBC: BF800000
	global_load_b128 v[9:12], v[3:4], off                      // 000000DDBFC0: DC5E0000 097C0003
	v_add_nc_u32_e32 v7, 0x100, v7                             // 000000DDBFC8: 4A0E0EFF 00000100
	.long 0xd7006a03                                           // 000000DDBFD0: D7006A03
	v_cndmask_b32_e32 v1, 0x1000, v3, vcc_lo                   // 000000DDBFD4: 020206FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDBFDC: BF870191
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000DDBFE0: D5207C04 01AA0880
	.long 0xd4490001                                           // 000000DDBFE8: D4490001
	v_cndmask_b32_e32 v1, 63, v7, vcc_lo                       // 000000DDBFEC: 02020EBF
	s_or_b32 s8, s1, s8                                        // 000000DDBFF0: 8C080801
	s_waitcnt vmcnt(0)                                         // 000000DDBFF4: BF8903F7
	ds_store_b128 v8, v[9:12] offset:15360                     // 000000DDBFF8: DB7C3C00 00000908
	v_add_nc_u32_e32 v8, 0x1000, v8                            // 000000DDC000: 4A1010FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 000000DDC008: 917E087E
	s_cbranch_execnz 65516                                     // 000000DDC00C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x28c0>
	s_branch 65430                                             // 000000DDC010: BFA0FF96 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x276c>
	s_bitcmp1_b32 s3, 0                                        // 000000DDC014: BF0D8003
	s_cselect_b32 s1, -1, 0                                    // 000000DDC018: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DDC01C: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000DDC020: 8B6A017E
	s_cbranch_vccz 59                                          // 000000DDC024: BFA3003B <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2a14>
	s_and_saveexec_b32 s1, s0                                  // 000000DDC028: BE812000
	s_cbranch_execz 56                                         // 000000DDC02C: BFA50038 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2a10>
	s_lshl_b32 s0, s6, 2                                       // 000000DDC030: 84008206
	v_lshlrev_b32_e32 v3, 4, v77                               // 000000DDC034: 30069A84
	v_mov_b32_e32 v1, s0                                       // 000000DDC038: 7E020200
	v_or_b32_e32 v4, 0xffffff00, v77                           // 000000DDC03C: 38089AFF FFFFFF00
	ds_load_b32 v1, v1 offset:20480                            // 000000DDC044: D8D85000 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000DDC04C: BF89FC07
	v_readfirstlane_b32 s0, v1                                 // 000000DDC050: 7E000501
	v_mad_u64_u32 v[1:2], null, 0x1400, s6, v[3:4]             // 000000DDC054: D6FE7C01 040C0CFF 00001400
	s_mul_hi_i32 s0, s0, 0x66666667                            // 000000DDC060: 9700FF00 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000DDC068: BF8704A9
	s_lshr_b32 s7, s0, 31                                      // 000000DDC06C: 85079F00
	s_ashr_i32 s0, s0, 2                                       // 000000DDC070: 86008200
	s_add_i32 s0, s0, s7                                       // 000000DDC074: 81000700
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DDC078: BF8700D9
	s_mul_i32 s6, s0, 0x1400                                   // 000000DDC07C: 9606FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 000000DDC084: 9700FF00 00001400
	s_add_u32 s6, s40, s6                                      // 000000DDC08C: 80060628
	s_addc_u32 s0, s41, s0                                     // 000000DDC090: 82000029
	.long 0xd7000602                                           // 000000DDC094: D7000602
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 000000DDC098: 02020606
	v_add_co_ci_u32_e64 v3, null, s0, 0, s6                    // 000000DDC09C: D5207C03 00190000
	s_mov_b32 s6, 0                                            // 000000DDC0A4: BE860080
	s_nop 0                                                    // 000000DDC0A8: BF800000
	s_nop 0                                                    // 000000DDC0AC: BF800000
	s_nop 0                                                    // 000000DDC0B0: BF800000
	s_nop 0                                                    // 000000DDC0B4: BF800000
	s_nop 0                                                    // 000000DDC0B8: BF800000
	s_nop 0                                                    // 000000DDC0BC: BF800000
	global_load_b128 v[5:8], v[2:3], off                       // 000000DDC0C0: DC5E0000 057C0002
	v_add_nc_u32_e32 v4, 0x100, v4                             // 000000DDC0C8: 4A0808FF 00000100
	.long 0xd7006a02                                           // 000000DDC0D0: D7006A02
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 000000DDC0D4: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDC0DC: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000DDC0E0: D5207C03 01AA0680
	.long 0xd4490000                                           // 000000DDC0E8: D4490000
	v_cndmask_b32_e32 v1, 63, v4, vcc_lo                       // 000000DDC0EC: 020208BF
	s_or_b32 s6, s0, s6                                        // 000000DDC0F0: 8C060600
	s_waitcnt vmcnt(0)                                         // 000000DDC0F4: BF8903F7
	ds_store_b128 v1, v[5:8] offset:10240                      // 000000DDC0F8: DB7C2800 00000501
	v_add_nc_u32_e32 v1, 0x1000, v1                            // 000000DDC100: 4A0202FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000DDC108: 917E067E
	s_cbranch_execnz 65516                                     // 000000DDC10C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x29c0>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000DDC110: 8C7E017E
	s_mul_i32 s0, s4, 0xffffffec                               // 000000DDC114: 9600FF04 FFFFFFEC
	s_and_not1_b32 vcc_lo, exec_lo, s5                         // 000000DDC11C: 916A057E
	s_add_i32 s0, s0, s2                                       // 000000DDC120: 81000200
	s_waitcnt lgkmcnt(0)                                       // 000000DDC124: BF89FC07
	s_barrier                                                  // 000000DDC128: BFBD0000
	buffer_gl0_inv                                             // 000000DDC12C: E0AC0000 00000000
	s_cbranch_vccnz 5051                                       // 000000DDC134: BFA413BB <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x7924>
	v_lshrrev_b32_e32 v1, 2, v77                               // 000000DDC138: 32029A82
	v_bfe_u32 v2, v77, 2, 3                                    // 000000DDC13C: D6100002 020D054D
	s_lshl_b32 s1, s0, 6                                       // 000000DDC144: 84018600
	s_add_u32 s4, s36, s38                                     // 000000DDC148: 80042624
	s_addc_u32 s5, s37, s39                                    // 000000DDC14C: 82052725
	v_and_b32_e32 v1, 56, v1                                   // 000000DDC150: 360202B8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DDC154: BF8700A1
	v_or3_b32 v21, s1, v1, v2                                  // 000000DDC158: D6580015 040A0201
	s_mov_b32 s1, 0                                            // 000000DDC160: BE810080
	v_ashrrev_i32_e32 v22, 31, v21                             // 000000DDC164: 342C2A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDC168: BF870091
	v_mad_i64_i32 v[0:1], null, 0x500, v0, v[21:22]            // 000000DDC16C: D6FF7C00 045600FF 00000500
	v_mad_u64_u32 v[25:26], null, v0, 40, s[4:5]               // 000000DDC178: D6FE7C19 00115100
	v_mad_u64_u32 v[9:10], null, 0x500, v0, s[36:37]           // 000000DDC180: D6FE7C09 009200FF 00000500
	v_and_b32_e32 v0, 3, v77                                   // 000000DDC18C: 36009A83
	scratch_store_b32 off, v0, off offset:484                  // 000000DDC190: DC6901E4 007C0000
	v_mad_i32_i24 v26, v1, 40, v26                             // 000000DDC198: D60A001A 04695101
	v_mad_i32_i24 v10, 0x500, v1, v10                          // 000000DDC1A0: D60A000A 042A02FF 00000500
	v_lshlrev_b32_e32 v0, 4, v0                                // 000000DDC1AC: 30000084
	s_clause 0x1                                               // 000000DDC1B0: BF850001
	global_load_b128 v[5:8], v[25:26], off                     // 000000DDC1B4: DC5E0000 057C0019
	global_load_b128 v[1:4], v[25:26], off offset:16           // 000000DDC1BC: DC5E0010 017C0019
	.long 0xd7006a17                                           // 000000DDC1C4: D7006A17
	v_cndmask_b32_e32 v1, v9, v0, vcc_lo                       // 000000DDC1C8: 02020109
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDC1CC: BF870001
	v_add_co_ci_u32_e64 v24, null, 0, v10, vcc_lo              // 000000DDC1D0: D5207C18 01AA1480
	s_clause 0x3                                               // 000000DDC1D8: BF850003
	global_load_b128 v[9:12], v[23:24], off                    // 000000DDC1DC: DC5E0000 097C0017
	global_load_b128 v[13:16], v[23:24], off offset:64         // 000000DDC1E4: DC5E0040 0D7C0017
	global_load_b128 v[17:20], v[23:24], off offset:128        // 000000DDC1EC: DC5E0080 117C0017
	global_load_b64 v[25:26], v[25:26], off offset:32          // 000000DDC1F4: DC560020 197C0019
	s_waitcnt vmcnt(5)                                         // 000000DDC1FC: BF8917F7
	v_cvt_f32_f16_e32 v0, v5                                   // 000000DDC200: 7E001705
	s_clause 0x1                                               // 000000DDC204: BF850001
	scratch_store_b32 off, v77, off offset:480                 // 000000DDC208: DC6901E0 007C4D00
	scratch_store_b32 off, v0, off                             // 000000DDC210: DC690000 007C0000
	v_cvt_f32_f16_e32 v0, v133/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DDC218: 7E001785
	s_waitcnt vmcnt(2)                                         // 000000DDC21C: BF890BF7
	v_and_b32_e32 v40, 0xf0f0f0f, v15                          // 000000DDC220: 36501EFF 0F0F0F0F
	v_lshrrev_b32_e32 v41, 4, v15                              // 000000DDC228: 32521E84
	v_and_b32_e32 v33, 0xf0f0f0f, v13                          // 000000DDC22C: 36421AFF 0F0F0F0F
	v_lshrrev_b32_e32 v34, 4, v13                              // 000000DDC234: 32441A84
	scratch_store_b32 off, v0, off offset:4                    // 000000DDC238: DC690004 007C0000
	v_cvt_f32_f16_e32 v0, v6                                   // 000000DDC240: 7E001706
	v_lshrrev_b32_e32 v27, 4, v9                               // 000000DDC244: 32361284
	v_lshrrev_b32_e32 v29, 4, v10                              // 000000DDC248: 323A1484
	v_and_b32_e32 v28, 0xf0f0f0f, v10                          // 000000DDC24C: 363814FF 0F0F0F0F
	v_and_b32_e32 v30, 0xf0f0f0f, v11                          // 000000DDC254: 363C16FF 0F0F0F0F
	scratch_store_b32 off, v0, off offset:8                    // 000000DDC25C: DC690008 007C0000
	v_cvt_f32_f16_e32 v0, v134/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DDC264: 7E001786
	v_lshrrev_b32_e32 v11, 4, v11                              // 000000DDC268: 32161684
	v_lshrrev_b32_e32 v32, 4, v12                              // 000000DDC26C: 32401884
	v_and_b32_e32 v31, 0xf0f0f0f, v12                          // 000000DDC270: 363E18FF 0F0F0F0F
	v_lshrrev_b32_e32 v39, 4, v14                              // 000000DDC278: 324E1C84
	scratch_store_b32 off, v0, off offset:12                   // 000000DDC27C: DC69000C 007C0000
	v_cvt_f32_f16_e32 v0, v7                                   // 000000DDC284: 7E001707
	v_and_b32_e32 v38, 0xf0f0f0f, v14                          // 000000DDC288: 364C1CFF 0F0F0F0F
	v_lshrrev_b32_e32 v43, 4, v16                              // 000000DDC290: 32562084
	v_and_b32_e32 v42, 0xf0f0f0f, v16                          // 000000DDC294: 365420FF 0F0F0F0F
	s_waitcnt vmcnt(1)                                         // 000000DDC29C: BF8907F7
	v_lshrrev_b32_e32 v45, 4, v17                              // 000000DDC2A0: 325A2284
	scratch_store_b32 off, v0, off offset:16                   // 000000DDC2A4: DC690010 007C0000
	v_cvt_f32_f16_e32 v0, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DDC2AC: 7E001787
	v_and_b32_e32 v44, 0xf0f0f0f, v17                          // 000000DDC2B0: 365822FF 0F0F0F0F
	v_and_b32_e32 v46, 0xf0f0f0f, v18                          // 000000DDC2B8: 365C24FF 0F0F0F0F
	v_lshrrev_b32_e32 v18, 4, v18                              // 000000DDC2C0: 32242484
	v_and_b32_e32 v48, 0xf0f0f0f, v20                          // 000000DDC2C4: 366028FF 0F0F0F0F
	scratch_store_b32 off, v0, off offset:20                   // 000000DDC2CC: DC690014 007C0000
	v_cvt_f32_f16_e32 v0, v8                                   // 000000DDC2D4: 7E001708
	v_lshrrev_b32_e32 v20, 4, v20                              // 000000DDC2D8: 32282884
	v_and_b32_e32 v47, 0xf0f0f0f, v19                          // 000000DDC2DC: 365E26FF 0F0F0F0F
	v_lshrrev_b32_e32 v19, 4, v19                              // 000000DDC2E4: 32262684
	scratch_store_b32 off, v0, off offset:24                   // 000000DDC2E8: DC690018 007C0000
	v_cvt_f32_f16_e32 v0, v136/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DDC2F0: 7E001788
	v_and_b32_e32 v8, 0xf0f0f0f, v9                            // 000000DDC2F4: 361012FF 0F0F0F0F
	scratch_store_b32 off, v0, off offset:28                   // 000000DDC2FC: DC69001C 007C0000
	v_cvt_f32_f16_e32 v0, v1                                   // 000000DDC304: 7E001701
	scratch_store_b32 off, v0, off offset:32                   // 000000DDC308: DC690020 007C0000
	v_cvt_f32_f16_e32 v0, v129/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DDC310: 7E001781
	scratch_store_b32 off, v0, off offset:36                   // 000000DDC314: DC690024 007C0000
	v_cvt_f32_f16_e32 v0, v2                                   // 000000DDC31C: 7E001702
	scratch_store_b32 off, v0, off offset:40                   // 000000DDC320: DC690028 007C0000
	v_cvt_f32_f16_e32 v0, v130/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DDC328: 7E001782
	scratch_store_b32 off, v0, off offset:44                   // 000000DDC32C: DC69002C 007C0000
	v_cvt_f32_f16_e32 v0, v3                                   // 000000DDC334: 7E001703
	scratch_store_b32 off, v0, off offset:48                   // 000000DDC338: DC690030 007C0000
	v_cvt_f32_f16_e32 v0, v131/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DDC340: 7E001783
	scratch_store_b32 off, v0, off offset:52                   // 000000DDC344: DC690034 007C0000
	v_cvt_f32_f16_e32 v0, v4                                   // 000000DDC34C: 7E001704
	scratch_store_b32 off, v0, off offset:56                   // 000000DDC350: DC690038 007C0000
	v_cvt_f32_f16_e32 v0, v132/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DDC358: 7E001784
	scratch_store_b32 off, v0, off offset:60                   // 000000DDC35C: DC69003C 007C0000
	s_clause 0x1                                               // 000000DDC364: BF850001
	global_load_b128 v[0:3], v[23:24], off offset:192          // 000000DDC368: DC5E00C0 007C0017
	global_load_b128 v[4:7], v[23:24], off offset:256          // 000000DDC370: DC5E0100 047C0017
	s_waitcnt vmcnt(1)                                         // 000000DDC378: BF8907F7
	v_and_b32_e32 v49, 0xf0f0f0f, v0                           // 000000DDC37C: 366200FF 0F0F0F0F
	v_lshrrev_b32_e32 v50, 4, v0                               // 000000DDC384: 32640084
	v_and_b32_e32 v51, 0xf0f0f0f, v1                           // 000000DDC388: 366602FF 0F0F0F0F
	v_lshrrev_b32_e32 v52, 4, v1                               // 000000DDC390: 32680284
	v_and_b32_e32 v53, 0xf0f0f0f, v2                           // 000000DDC394: 366A04FF 0F0F0F0F
	v_lshrrev_b32_e32 v54, 4, v2                               // 000000DDC39C: 326C0484
	v_and_b32_e32 v55, 0xf0f0f0f, v3                           // 000000DDC3A0: 366E06FF 0F0F0F0F
	v_lshrrev_b32_e32 v56, 4, v3                               // 000000DDC3A8: 32700684
	s_waitcnt vmcnt(0)                                         // 000000DDC3AC: BF8903F7
	v_and_b32_e32 v57, 0xf0f0f0f, v4                           // 000000DDC3B0: 367208FF 0F0F0F0F
	v_lshrrev_b32_e32 v58, 4, v4                               // 000000DDC3B8: 32740884
	v_and_b32_e32 v59, 0xf0f0f0f, v5                           // 000000DDC3BC: 36760AFF 0F0F0F0F
	v_lshrrev_b32_e32 v60, 4, v5                               // 000000DDC3C4: 32780A84
	v_and_b32_e32 v61, 0xf0f0f0f, v6                           // 000000DDC3C8: 367A0CFF 0F0F0F0F
	v_lshrrev_b32_e32 v62, 4, v6                               // 000000DDC3D0: 327C0C84
	v_and_b32_e32 v63, 0xf0f0f0f, v7                           // 000000DDC3D4: 367E0EFF 0F0F0F0F
	v_lshrrev_b32_e32 v64, 4, v7                               // 000000DDC3DC: 32800E84
	s_clause 0x1                                               // 000000DDC3E0: BF850001
	global_load_b128 v[0:3], v[23:24], off offset:320          // 000000DDC3E4: DC5E0140 007C0017
	global_load_b128 v[4:7], v[23:24], off offset:384          // 000000DDC3EC: DC5E0180 047C0017
	s_waitcnt vmcnt(1)                                         // 000000DDC3F4: BF8907F7
	v_and_b32_e32 v65, 0xf0f0f0f, v0                           // 000000DDC3F8: 368200FF 0F0F0F0F
	v_lshrrev_b32_e32 v68, 4, v0                               // 000000DDC400: 32880084
	v_and_b32_e32 v69, 0xf0f0f0f, v1                           // 000000DDC404: 368A02FF 0F0F0F0F
	v_lshrrev_b32_e32 v70, 4, v1                               // 000000DDC40C: 328C0284
	v_and_b32_e32 v71, 0xf0f0f0f, v2                           // 000000DDC410: 368E04FF 0F0F0F0F
	v_lshrrev_b32_e32 v72, 4, v2                               // 000000DDC418: 32900484
	v_and_b32_e32 v73, 0xf0f0f0f, v3                           // 000000DDC41C: 369206FF 0F0F0F0F
	v_lshrrev_b32_e32 v74, 4, v3                               // 000000DDC424: 32940684
	s_waitcnt vmcnt(0)                                         // 000000DDC428: BF8903F7
	v_and_b32_e32 v75, 0xf0f0f0f, v4                           // 000000DDC42C: 369608FF 0F0F0F0F
	v_lshrrev_b32_e32 v76, 4, v4                               // 000000DDC434: 32980884
	v_and_b32_e32 v77, 0xf0f0f0f, v5                           // 000000DDC438: 369A0AFF 0F0F0F0F
	v_lshrrev_b32_e32 v78, 4, v5                               // 000000DDC440: 329C0A84
	v_and_b32_e32 v79, 0xf0f0f0f, v6                           // 000000DDC444: 369E0CFF 0F0F0F0F
	v_lshrrev_b32_e32 v80, 4, v6                               // 000000DDC44C: 32A00C84
	v_and_b32_e32 v81, 0xf0f0f0f, v7                           // 000000DDC450: 36A20EFF 0F0F0F0F
	v_lshrrev_b32_e32 v82, 4, v7                               // 000000DDC458: 32A40E84
	s_clause 0x1                                               // 000000DDC45C: BF850001
	global_load_b128 v[0:3], v[23:24], off offset:448          // 000000DDC460: DC5E01C0 007C0017
	global_load_b128 v[4:7], v[23:24], off offset:512          // 000000DDC468: DC5E0200 047C0017
	s_waitcnt vmcnt(1)                                         // 000000DDC470: BF8907F7
	v_and_b32_e32 v83, 0xf0f0f0f, v0                           // 000000DDC474: 36A600FF 0F0F0F0F
	v_lshrrev_b32_e32 v84, 4, v0                               // 000000DDC47C: 32A80084
	v_and_b32_e32 v85, 0xf0f0f0f, v1                           // 000000DDC480: 36AA02FF 0F0F0F0F
	v_lshrrev_b32_e32 v86, 4, v1                               // 000000DDC488: 32AC0284
	v_and_b32_e32 v87, 0xf0f0f0f, v2                           // 000000DDC48C: 36AE04FF 0F0F0F0F
	v_lshrrev_b32_e32 v88, 4, v2                               // 000000DDC494: 32B00484
	v_and_b32_e32 v89, 0xf0f0f0f, v3                           // 000000DDC498: 36B206FF 0F0F0F0F
	v_lshrrev_b32_e32 v90, 4, v3                               // 000000DDC4A0: 32B40684
	s_waitcnt vmcnt(0)                                         // 000000DDC4A4: BF8903F7
	v_and_b32_e32 v91, 0xf0f0f0f, v4                           // 000000DDC4A8: 36B608FF 0F0F0F0F
	v_lshrrev_b32_e32 v92, 4, v4                               // 000000DDC4B0: 32B80884
	v_and_b32_e32 v93, 0xf0f0f0f, v5                           // 000000DDC4B4: 36BA0AFF 0F0F0F0F
	v_lshrrev_b32_e32 v94, 4, v5                               // 000000DDC4BC: 32BC0A84
	v_and_b32_e32 v101, 0xf0f0f0f, v6                          // 000000DDC4C0: 36CA0CFF 0F0F0F0F
	v_lshrrev_b32_e32 v98, 4, v6                               // 000000DDC4C8: 32C40C84
	v_and_b32_e32 v102, 0xf0f0f0f, v7                          // 000000DDC4CC: 36CC0EFF 0F0F0F0F
	v_lshrrev_b32_e32 v103, 4, v7                              // 000000DDC4D4: 32CE0E84
	s_clause 0x1                                               // 000000DDC4D8: BF850001
	global_load_b128 v[0:3], v[23:24], off offset:576          // 000000DDC4DC: DC5E0240 007C0017
	global_load_b128 v[4:7], v[23:24], off offset:640          // 000000DDC4E4: DC5E0280 047C0017
	s_waitcnt vmcnt(1)                                         // 000000DDC4EC: BF8907F7
	v_and_b32_e32 v104, 0xf0f0f0f, v0                          // 000000DDC4F0: 36D000FF 0F0F0F0F
	v_lshrrev_b32_e32 v105, 4, v0                              // 000000DDC4F8: 32D20084
	v_and_b32_e32 v109, 0xf0f0f0f, v1                          // 000000DDC4FC: 36DA02FF 0F0F0F0F
	v_lshrrev_b32_e32 v110, 4, v1                              // 000000DDC504: 32DC0284
	v_and_b32_e32 v111, 0xf0f0f0f, v2                          // 000000DDC508: 36DE04FF 0F0F0F0F
	v_lshrrev_b32_e32 v112, 4, v2                              // 000000DDC510: 32E00484
	v_and_b32_e32 v113, 0xf0f0f0f, v3                          // 000000DDC514: 36E206FF 0F0F0F0F
	v_lshrrev_b32_e32 v114, 4, v3                              // 000000DDC51C: 32E40684
	s_waitcnt vmcnt(0)                                         // 000000DDC520: BF8903F7
	v_and_b32_e32 v115, 0xf0f0f0f, v4                          // 000000DDC524: 36E608FF 0F0F0F0F
	v_lshrrev_b32_e32 v116, 4, v4                              // 000000DDC52C: 32E80884
	v_and_b32_e32 v117, 0xf0f0f0f, v5                          // 000000DDC530: 36EA0AFF 0F0F0F0F
	v_lshrrev_b32_e32 v118, 4, v5                              // 000000DDC538: 32EC0A84
	v_and_b32_e32 v119, 0xf0f0f0f, v6                          // 000000DDC53C: 36EE0CFF 0F0F0F0F
	v_lshrrev_b32_e32 v120, 4, v6                              // 000000DDC544: 32F00C84
	v_and_b32_e32 v121, 0xf0f0f0f, v7                          // 000000DDC548: 36F20EFF 0F0F0F0F
	v_lshrrev_b32_e32 v122, 4, v7                              // 000000DDC550: 32F40E84
	s_clause 0x1                                               // 000000DDC554: BF850001
	global_load_b128 v[0:3], v[23:24], off offset:704          // 000000DDC558: DC5E02C0 007C0017
	global_load_b128 v[4:7], v[23:24], off offset:768          // 000000DDC560: DC5E0300 047C0017
	s_waitcnt vmcnt(1)                                         // 000000DDC568: BF8907F7
	v_and_b32_e32 v123, 0xf0f0f0f, v0                          // 000000DDC56C: 36F600FF 0F0F0F0F
	v_lshrrev_b32_e32 v124, 4, v0                              // 000000DDC574: 32F80084
	v_and_b32_e32 v125, 0xf0f0f0f, v1                          // 000000DDC578: 36FA02FF 0F0F0F0F
	v_lshrrev_b32_e32 v126, 4, v1                              // 000000DDC580: 32FC0284
	v_and_b32_e32 v127, 0xf0f0f0f, v2                          // 000000DDC584: 36FE04FF 0F0F0F0F
	v_lshrrev_b32_e32 v128, 4, v2                              // 000000DDC58C: 33000484
	v_and_b32_e32 v129, 0xf0f0f0f, v3                          // 000000DDC590: 370206FF 0F0F0F0F
	v_lshrrev_b32_e32 v130, 4, v3                              // 000000DDC598: 33040684
	s_waitcnt vmcnt(0)                                         // 000000DDC59C: BF8903F7
	v_and_b32_e32 v131, 0xf0f0f0f, v4                          // 000000DDC5A0: 370608FF 0F0F0F0F
	v_lshrrev_b32_e32 v132, 4, v4                              // 000000DDC5A8: 33080884
	v_and_b32_e32 v133, 0xf0f0f0f, v5                          // 000000DDC5AC: 370A0AFF 0F0F0F0F
	v_lshrrev_b32_e32 v134, 4, v5                              // 000000DDC5B4: 330C0A84
	v_and_b32_e32 v135, 0xf0f0f0f, v6                          // 000000DDC5B8: 370E0CFF 0F0F0F0F
	v_lshrrev_b32_e32 v136, 4, v6                              // 000000DDC5C0: 33100C84
	v_and_b32_e32 v137, 0xf0f0f0f, v7                          // 000000DDC5C4: 37120EFF 0F0F0F0F
	v_lshrrev_b32_e32 v138, 4, v7                              // 000000DDC5CC: 33140E84
	s_clause 0x1                                               // 000000DDC5D0: BF850001
	global_load_b128 v[0:3], v[23:24], off offset:832          // 000000DDC5D4: DC5E0340 007C0017
	global_load_b128 v[4:7], v[23:24], off offset:896          // 000000DDC5DC: DC5E0380 047C0017
	s_waitcnt vmcnt(1)                                         // 000000DDC5E4: BF8907F7
	v_and_b32_e32 v139, 0xf0f0f0f, v0                          // 000000DDC5E8: 371600FF 0F0F0F0F
	v_lshrrev_b32_e32 v140, 4, v0                              // 000000DDC5F0: 33180084
	v_and_b32_e32 v141, 0xf0f0f0f, v1                          // 000000DDC5F4: 371A02FF 0F0F0F0F
	v_lshrrev_b32_e32 v142, 4, v1                              // 000000DDC5FC: 331C0284
	v_and_b32_e32 v143, 0xf0f0f0f, v2                          // 000000DDC600: 371E04FF 0F0F0F0F
	v_lshrrev_b32_e32 v144, 4, v2                              // 000000DDC608: 33200484
	v_and_b32_e32 v145, 0xf0f0f0f, v3                          // 000000DDC60C: 372206FF 0F0F0F0F
	v_lshrrev_b32_e32 v146, 4, v3                              // 000000DDC614: 33240684
	s_waitcnt vmcnt(0)                                         // 000000DDC618: BF8903F7
	v_and_b32_e32 v147, 0xf0f0f0f, v4                          // 000000DDC61C: 372608FF 0F0F0F0F
	v_lshrrev_b32_e32 v148, 4, v4                              // 000000DDC624: 33280884
	v_and_b32_e32 v149, 0xf0f0f0f, v5                          // 000000DDC628: 372A0AFF 0F0F0F0F
	v_lshrrev_b32_e32 v150, 4, v5                              // 000000DDC630: 332C0A84
	v_and_b32_e32 v151, 0xf0f0f0f, v6                          // 000000DDC634: 372E0CFF 0F0F0F0F
	v_lshrrev_b32_e32 v152, 4, v6                              // 000000DDC63C: 33300C84
	v_and_b32_e32 v153, 0xf0f0f0f, v7                          // 000000DDC640: 37320EFF 0F0F0F0F
	v_lshrrev_b32_e32 v154, 4, v7                              // 000000DDC648: 33340E84
	s_clause 0x1                                               // 000000DDC64C: BF850001
	global_load_b128 v[0:3], v[23:24], off offset:960          // 000000DDC650: DC5E03C0 007C0017
	global_load_b128 v[4:7], v[23:24], off offset:1024         // 000000DDC658: DC5E0400 047C0017
	s_waitcnt vmcnt(1)                                         // 000000DDC660: BF8907F7
	v_and_b32_e32 v155, 0xf0f0f0f, v0                          // 000000DDC664: 373600FF 0F0F0F0F
	v_lshrrev_b32_e32 v156, 4, v0                              // 000000DDC66C: 33380084
	v_and_b32_e32 v157, 0xf0f0f0f, v1                          // 000000DDC670: 373A02FF 0F0F0F0F
	v_lshrrev_b32_e32 v158, 4, v1                              // 000000DDC678: 333C0284
	v_and_b32_e32 v159, 0xf0f0f0f, v2                          // 000000DDC67C: 373E04FF 0F0F0F0F
	v_lshrrev_b32_e32 v160, 4, v2                              // 000000DDC684: 33400484
	v_and_b32_e32 v161, 0xf0f0f0f, v3                          // 000000DDC688: 374206FF 0F0F0F0F
	v_lshrrev_b32_e32 v162, 4, v3                              // 000000DDC690: 33440684
	s_waitcnt vmcnt(0)                                         // 000000DDC694: BF8903F7
	v_and_b32_e32 v163, 0xf0f0f0f, v4                          // 000000DDC698: 374608FF 0F0F0F0F
	v_lshrrev_b32_e32 v164, 4, v4                              // 000000DDC6A0: 33480884
	v_and_b32_e32 v165, 0xf0f0f0f, v5                          // 000000DDC6A4: 374A0AFF 0F0F0F0F
	v_lshrrev_b32_e32 v166, 4, v5                              // 000000DDC6AC: 334C0A84
	v_and_b32_e32 v167, 0xf0f0f0f, v6                          // 000000DDC6B0: 374E0CFF 0F0F0F0F
	v_lshrrev_b32_e32 v168, 4, v6                              // 000000DDC6B8: 33500C84
	v_and_b32_e32 v169, 0xf0f0f0f, v7                          // 000000DDC6BC: 37520EFF 0F0F0F0F
	v_lshrrev_b32_e32 v170, 4, v7                              // 000000DDC6C4: 33540E84
	s_clause 0x1                                               // 000000DDC6C8: BF850001
	global_load_b128 v[0:3], v[23:24], off offset:1088         // 000000DDC6CC: DC5E0440 007C0017
	global_load_b128 v[4:7], v[23:24], off offset:1152         // 000000DDC6D4: DC5E0480 047C0017
	s_waitcnt vmcnt(1)                                         // 000000DDC6DC: BF8907F7
	v_and_b32_e32 v171, 0xf0f0f0f, v0                          // 000000DDC6E0: 375600FF 0F0F0F0F
	v_lshrrev_b32_e32 v172, 4, v0                              // 000000DDC6E8: 33580084
	s_waitcnt vmcnt(0)                                         // 000000DDC6EC: BF8903F7
	v_lshrrev_b32_e32 v0, 4, v5                                // 000000DDC6F0: 32000A84
	v_and_b32_e32 v173, 0xf0f0f0f, v1                          // 000000DDC6F4: 375A02FF 0F0F0F0F
	v_lshrrev_b32_e32 v174, 4, v1                              // 000000DDC6FC: 335C0284
	v_and_b32_e32 v175, 0xf0f0f0f, v2                          // 000000DDC700: 375E04FF 0F0F0F0F
	v_lshrrev_b32_e32 v176, 4, v2                              // 000000DDC708: 33600484
	scratch_store_b32 off, v0, off offset:328                  // 000000DDC70C: DC690148 007C0000
	v_lshrrev_b32_e32 v0, 4, v6                                // 000000DDC714: 32000C84
	v_and_b32_e32 v177, 0xf0f0f0f, v3                          // 000000DDC718: 376206FF 0F0F0F0F
	v_lshrrev_b32_e32 v67, 4, v3                               // 000000DDC720: 32860684
	v_and_b32_e32 v96, 0xf0f0f0f, v4                           // 000000DDC724: 36C008FF 0F0F0F0F
	v_lshrrev_b32_e32 v244, 4, v4                              // 000000DDC72C: 33E80884
	scratch_store_b32 off, v0, off offset:336                  // 000000DDC730: DC690150 007C0000
	v_lshrrev_b32_e32 v0, 4, v7                                // 000000DDC738: 32000E84
	v_and_b32_e32 v66, 0xf0f0f0f, v5                           // 000000DDC73C: 36840AFF 0F0F0F0F
	v_and_b32_e32 v35, 0xf0f0f0f, v6                           // 000000DDC744: 36460CFF 0F0F0F0F
	v_and_b32_e32 v16, 0xf0f0f0f, v7                           // 000000DDC74C: 36200EFF 0F0F0F0F
	scratch_store_b32 off, v0, off offset:400                  // 000000DDC754: DC690190 007C0000
	global_load_b128 v[0:3], v[23:24], off offset:1216         // 000000DDC75C: DC5E04C0 007C0017
	s_waitcnt vmcnt(0)                                         // 000000DDC764: BF8903F7
	v_and_b32_e32 v15, 0xf0f0f0f, v0                           // 000000DDC768: 361E00FF 0F0F0F0F
	v_lshrrev_b32_e32 v0, 4, v0                                // 000000DDC770: 32000084
	v_and_b32_e32 v13, 0xf0f0f0f, v1                           // 000000DDC774: 361A02FF 0F0F0F0F
	v_and_b32_e32 v9, 0xf0f0f0f, v3                            // 000000DDC77C: 361206FF 0F0F0F0F
	v_and_b32_e32 v10, 0xf0f0f0f, v2                           // 000000DDC784: 361404FF 0F0F0F0F
	scratch_store_b32 off, v0, off offset:356                  // 000000DDC78C: DC690164 007C0000
	v_lshrrev_b32_e32 v0, 4, v1                                // 000000DDC794: 32000284
	scratch_store_b32 off, v0, off offset:352                  // 000000DDC798: DC690160 007C0000
	v_lshrrev_b32_e32 v0, 4, v2                                // 000000DDC7A0: 32000484
	scratch_store_b32 off, v0, off offset:348                  // 000000DDC7A4: DC69015C 007C0000
	v_lshrrev_b32_e32 v0, 4, v3                                // 000000DDC7AC: 32000684
	scratch_store_b32 off, v0, off offset:344                  // 000000DDC7B0: DC690158 007C0000
	.long 0xd73c0000                                           // 000000DDC7B8: D73C0000
	v_cndmask_b32_e32 v1, 2, v21, vcc_lo                       // 000000DDC7BC: 02022A82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DDC7C0: BF870091
	.long 0xd7006a00                                           // 000000DDC7C4: D7006A00
	v_cndmask_b32_e32 v1, s48, v0, vcc_lo                      // 000000DDC7C8: 02020030
	v_add_co_ci_u32_e64 v1, null, s49, v1, vcc_lo              // 000000DDC7CC: D5207C01 01AA0231
	scratch_store_b64 off, v[0:1], off offset:472              // 000000DDC7D4: DC6D01D8 007C0000
	v_and_b32_e32 v0, 0xf0f0f0f, v27                           // 000000DDC7DC: 360036FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDC7E4: BF870001
	v_perm_b32 v1, v0, v8, 0xc040c00                           // 000000DDC7E8: D6440001 03FE1100 0C040C00
	scratch_store_b32 off, v1, off offset:380                  // 000000DDC7F4: DC69017C 007C0100
	v_perm_b32 v1, v0, v8, 0xc050c01                           // 000000DDC7FC: D6440001 03FE1100 0C050C01
	scratch_store_b32 off, v1, off offset:384                  // 000000DDC808: DC690180 007C0100
	v_perm_b32 v1, v0, v8, 0xc060c02                           // 000000DDC810: D6440001 03FE1100 0C060C02
	v_perm_b32 v0, v0, v8, 0xc070c03                           // 000000DDC81C: D6440000 03FE1100 0C070C03
	s_clause 0x1                                               // 000000DDC828: BF850001
	scratch_store_b32 off, v1, off offset:388                  // 000000DDC82C: DC690184 007C0100
	scratch_store_b32 off, v0, off offset:392                  // 000000DDC834: DC690188 007C0000
	v_and_b32_e32 v0, 0xf0f0f0f, v29                           // 000000DDC83C: 36003AFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDC844: BF870001
	v_perm_b32 v1, v0, v28, 0xc040c00                          // 000000DDC848: D6440001 03FE3900 0C040C00
	scratch_store_b32 off, v1, off offset:364                  // 000000DDC854: DC69016C 007C0100
	v_perm_b32 v1, v0, v28, 0xc050c01                          // 000000DDC85C: D6440001 03FE3900 0C050C01
	scratch_store_b32 off, v1, off offset:368                  // 000000DDC868: DC690170 007C0100
	v_perm_b32 v1, v0, v28, 0xc060c02                          // 000000DDC870: D6440001 03FE3900 0C060C02
	v_perm_b32 v0, v0, v28, 0xc070c03                          // 000000DDC87C: D6440000 03FE3900 0C070C03
	s_clause 0x1                                               // 000000DDC888: BF850001
	scratch_store_b32 off, v1, off offset:372                  // 000000DDC88C: DC690174 007C0100
	scratch_store_b32 off, v0, off offset:360                  // 000000DDC894: DC690168 007C0000
	v_and_b32_e32 v0, 0xf0f0f0f, v11                           // 000000DDC89C: 360016FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDC8A4: BF870001
	v_perm_b32 v1, v0, v30, 0xc040c00                          // 000000DDC8A8: D6440001 03FE3D00 0C040C00
	v_perm_b32 v180, v0, v30, 0xc050c01                        // 000000DDC8B4: D64400B4 03FE3D00 0C050C01
	v_perm_b32 v181, v0, v30, 0xc070c03                        // 000000DDC8C0: D64400B5 03FE3D00 0C070C03
	scratch_store_b32 off, v1, off offset:376                  // 000000DDC8CC: DC690178 007C0100
	v_perm_b32 v1, v0, v30, 0xc060c02                          // 000000DDC8D4: D6440001 03FE3D00 0C060C02
	v_and_b32_e32 v0, 0xf0f0f0f, v32                           // 000000DDC8E0: 360040FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DDC8E8: BF8700D1
	v_perm_b32 v182, v0, v31, 0xc040c00                        // 000000DDC8EC: D64400B6 03FE3F00 0C040C00
	v_perm_b32 v183, v0, v31, 0xc050c01                        // 000000DDC8F8: D64400B7 03FE3F00 0C050C01
	v_perm_b32 v184, v0, v31, 0xc060c02                        // 000000DDC904: D64400B8 03FE3F00 0C060C02
	v_perm_b32 v185, v0, v31, 0xc070c03                        // 000000DDC910: D64400B9 03FE3F00 0C070C03
	v_and_b32_e32 v0, 0xf0f0f0f, v34                           // 000000DDC91C: 360044FF 0F0F0F0F
	v_perm_b32 v186, v0, v33, 0xc040c00                        // 000000DDC924: D64400BA 03FE4300 0C040C00
	v_perm_b32 v187, v0, v33, 0xc050c01                        // 000000DDC930: D64400BB 03FE4300 0C050C01
	v_perm_b32 v188, v0, v33, 0xc060c02                        // 000000DDC93C: D64400BC 03FE4300 0C060C02
	v_perm_b32 v189, v0, v33, 0xc070c03                        // 000000DDC948: D64400BD 03FE4300 0C070C03
	v_and_b32_e32 v0, 0xf0f0f0f, v39                           // 000000DDC954: 36004EFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDC95C: BF870001
	v_perm_b32 v190, v0, v38, 0xc040c00                        // 000000DDC960: D64400BE 03FE4D00 0C040C00
	v_perm_b32 v191, v0, v38, 0xc050c01                        // 000000DDC96C: D64400BF 03FE4D00 0C050C01
	v_perm_b32 v192, v0, v38, 0xc060c02                        // 000000DDC978: D64400C0 03FE4D00 0C060C02
	v_perm_b32 v193, v0, v38, 0xc070c03                        // 000000DDC984: D64400C1 03FE4D00 0C070C03
	v_and_b32_e32 v0, 0xf0f0f0f, v41                           // 000000DDC990: 360052FF 0F0F0F0F
	v_and_b32_e32 v38, 0xf0f0f0f, v84                          // 000000DDC998: 364CA8FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DDC9A0: BF870002
	v_perm_b32 v194, v0, v40, 0xc040c00                        // 000000DDC9A4: D64400C2 03FE5100 0C040C00
	v_perm_b32 v195, v0, v40, 0xc050c01                        // 000000DDC9B0: D64400C3 03FE5100 0C050C01
	v_perm_b32 v196, v0, v40, 0xc060c02                        // 000000DDC9BC: D64400C4 03FE5100 0C060C02
	v_perm_b32 v197, v0, v40, 0xc070c03                        // 000000DDC9C8: D64400C5 03FE5100 0C070C03
	v_and_b32_e32 v0, 0xf0f0f0f, v43                           // 000000DDC9D4: 360056FF 0F0F0F0F
	v_perm_b32 v37, v38, v83, 0xc070c03                        // 000000DDC9DC: D6440025 03FEA726 0C070C03
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DDC9E8: BF870002
	v_perm_b32 v198, v0, v42, 0xc040c00                        // 000000DDC9EC: D64400C6 03FE5500 0C040C00
	v_perm_b32 v199, v0, v42, 0xc050c01                        // 000000DDC9F8: D64400C7 03FE5500 0C050C01
	v_perm_b32 v200, v0, v42, 0xc060c02                        // 000000DDCA04: D64400C8 03FE5500 0C060C02
	v_perm_b32 v201, v0, v42, 0xc070c03                        // 000000DDCA10: D64400C9 03FE5500 0C070C03
	v_and_b32_e32 v0, 0xf0f0f0f, v45                           // 000000DDCA1C: 36005AFF 0F0F0F0F
	v_and_b32_e32 v42, 0xf0f0f0f, v90                          // 000000DDCA24: 3654B4FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DDCA2C: BF870002
	v_perm_b32 v202, v0, v44, 0xc040c00                        // 000000DDCA30: D64400CA 03FE5900 0C040C00
	v_perm_b32 v203, v0, v44, 0xc050c01                        // 000000DDCA3C: D64400CB 03FE5900 0C050C01
	v_perm_b32 v204, v0, v44, 0xc060c02                        // 000000DDCA48: D64400CC 03FE5900 0C060C02
	v_perm_b32 v205, v0, v44, 0xc070c03                        // 000000DDCA54: D64400CD 03FE5900 0C070C03
	v_and_b32_e32 v0, 0xf0f0f0f, v18                           // 000000DDCA60: 360024FF 0F0F0F0F
	v_and_b32_e32 v18, 0xf0f0f0f, v50                          // 000000DDCA68: 362464FF 0F0F0F0F
	v_perm_b32 v238, v42, v89, 0xc050c01                       // 000000DDCA70: D64400EE 03FEB32A 0C050C01
	v_perm_b32 v242, v42, v89, 0xc060c02                       // 000000DDCA7C: D64400F2 03FEB32A 0C060C02
	v_perm_b32 v243, v42, v89, 0xc070c03                       // 000000DDCA88: D64400F3 03FEB32A 0C070C03
	v_perm_b32 v206, v0, v46, 0xc040c00                        // 000000DDCA94: D64400CE 03FE5D00 0C040C00
	v_perm_b32 v215, v18, v49, 0xc040c00                       // 000000DDCAA0: D64400D7 03FE6312 0C040C00
	v_perm_b32 v216, v18, v49, 0xc050c01                       // 000000DDCAAC: D64400D8 03FE6312 0C050C01
	v_perm_b32 v217, v18, v49, 0xc060c02                       // 000000DDCAB8: D64400D9 03FE6312 0C060C02
	v_perm_b32 v218, v18, v49, 0xc070c03                       // 000000DDCAC4: D64400DA 03FE6312 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v52                          // 000000DDCAD0: 362468FF 0F0F0F0F
	v_perm_b32 v207, v0, v46, 0xc050c01                        // 000000DDCAD8: D64400CF 03FE5D00 0C050C01
	v_perm_b32 v208, v0, v46, 0xc060c02                        // 000000DDCAE4: D64400D0 03FE5D00 0C060C02
	v_perm_b32 v209, v0, v46, 0xc070c03                        // 000000DDCAF0: D64400D1 03FE5D00 0C070C03
	v_and_b32_e32 v0, 0xf0f0f0f, v19                           // 000000DDCAFC: 360026FF 0F0F0F0F
	v_perm_b32 v219, v18, v51, 0xc040c00                       // 000000DDCB04: D64400DB 03FE6712 0C040C00
	v_perm_b32 v220, v18, v51, 0xc050c01                       // 000000DDCB10: D64400DC 03FE6712 0C050C01
	v_perm_b32 v221, v18, v51, 0xc060c02                       // 000000DDCB1C: D64400DD 03FE6712 0C060C02
	v_perm_b32 v222, v18, v51, 0xc070c03                       // 000000DDCB28: D64400DE 03FE6712 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v54                          // 000000DDCB34: 36246CFF 0F0F0F0F
	v_perm_b32 v210, v0, v47, 0xc040c00                        // 000000DDCB3C: D64400D2 03FE5F00 0C040C00
	v_perm_b32 v3, v0, v47, 0xc050c01                          // 000000DDCB48: D6440003 03FE5F00 0C050C01
	v_perm_b32 v211, v0, v47, 0xc060c02                        // 000000DDCB54: D64400D3 03FE5F00 0C060C02
	v_perm_b32 v0, v0, v47, 0xc070c03                          // 000000DDCB60: D6440000 03FE5F00 0C070C03
	v_perm_b32 v223, v18, v53, 0xc040c00                       // 000000DDCB6C: D64400DF 03FE6B12 0C040C00
	v_perm_b32 v224, v18, v53, 0xc050c01                       // 000000DDCB78: D64400E0 03FE6B12 0C050C01
	v_perm_b32 v225, v18, v53, 0xc060c02                       // 000000DDCB84: D64400E1 03FE6B12 0C060C02
	v_perm_b32 v226, v18, v53, 0xc070c03                       // 000000DDCB90: D64400E2 03FE6B12 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v56                          // 000000DDCB9C: 362470FF 0F0F0F0F
	v_or_b32_e32 v0, 0x64006400, v0                            // 000000DDCBA4: 380000FF 64006400
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DDCBAC: 380606FF 64006400
	v_perm_b32 v47, v38, v83, 0xc040c00                        // 000000DDCBB4: D644002F 03FEA726 0C040C00
	v_perm_b32 v51, v38, v83, 0xc060c02                        // 000000DDCBC0: D6440033 03FEA726 0C060C02
	v_perm_b32 v227, v18, v55, 0xc040c00                       // 000000DDCBCC: D64400E3 03FE6F12 0C040C00
	v_perm_b32 v228, v18, v55, 0xc050c01                       // 000000DDCBD8: D64400E4 03FE6F12 0C050C01
	v_perm_b32 v229, v18, v55, 0xc060c02                       // 000000DDCBE4: D64400E5 03FE6F12 0C060C02
	v_perm_b32 v230, v18, v55, 0xc070c03                       // 000000DDCBF0: D64400E6 03FE6F12 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v58                          // 000000DDCBFC: 362474FF 0F0F0F0F
	.long 0xcc0f4000                                           // 000000DDCC04: CC0F4000
	v_mul_i32_i24_e32 v1, 0xe408, v0                           // 000000DDCC08: 120200FF 0000E408
	.long 0xcc0f4003                                           // 000000DDCC10: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DDCC14: 120206FF 0000E408
	v_or_b32_e32 v84, 0x64006400, v223                         // 000000DDCC1C: 38A9BEFF 64006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DDCC24: BF870004
	v_perm_b32 v231, v18, v57, 0xc040c00                       // 000000DDCC28: D64400E7 03FE7312 0C040C00
	v_perm_b32 v58, v18, v57, 0xc050c01                        // 000000DDCC34: D644003A 03FE7312 0C050C01
	v_perm_b32 v232, v18, v57, 0xc060c02                       // 000000DDCC40: D64400E8 03FE7312 0C060C02
	v_perm_b32 v53, v18, v57, 0xc070c03                        // 000000DDCC4C: D6440035 03FE7312 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v60                          // 000000DDCC58: 362478FF 0F0F0F0F
	s_clause 0x1                                               // 000000DDCC60: BF850001
	scratch_store_b32 off, v0, off offset:204                  // 000000DDCC64: DC6900CC 007C0000
	scratch_store_b32 off, v3, off offset:212                  // 000000DDCC6C: DC6900D4 007C0300
	v_perm_b32 v57, v18, v59, 0xc040c00                        // 000000DDCC74: D6440039 03FE7712 0C040C00
	v_perm_b32 v49, v18, v59, 0xc050c01                        // 000000DDCC80: D6440031 03FE7712 0C050C01
	v_perm_b32 v54, v18, v59, 0xc060c02                        // 000000DDCC8C: D6440036 03FE7712 0C060C02
	v_perm_b32 v34, v18, v59, 0xc070c03                        // 000000DDCC98: D6440022 03FE7712 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v62                          // 000000DDCCA4: 36247CFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DDCCAC: BF8700D1
	v_perm_b32 v50, v18, v61, 0xc040c00                        // 000000DDCCB0: D6440032 03FE7B12 0C040C00
	v_perm_b32 v32, v18, v61, 0xc050c01                        // 000000DDCCBC: D6440020 03FE7B12 0C050C01
	v_perm_b32 v46, v18, v61, 0xc060c02                        // 000000DDCCC8: D644002E 03FE7B12 0C060C02
	v_perm_b32 v29, v18, v61, 0xc070c03                        // 000000DDCCD4: D644001D 03FE7B12 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v64                          // 000000DDCCE0: 362480FF 0F0F0F0F
	v_perm_b32 v33, v18, v63, 0xc040c00                        // 000000DDCCE8: D6440021 03FE7F12 0C040C00
	v_perm_b32 v23, v18, v63, 0xc050c01                        // 000000DDCCF4: D6440017 03FE7F12 0C050C01
	v_perm_b32 v30, v18, v63, 0xc060c02                        // 000000DDCD00: D644001E 03FE7F12 0C060C02
	v_perm_b32 v24, v18, v63, 0xc070c03                        // 000000DDCD0C: D6440018 03FE7F12 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v68                          // 000000DDCD18: 362488FF 0F0F0F0F
	v_and_b32_e32 v63, 0xf0f0f0f, v92                          // 000000DDCD20: 367EB8FF 0F0F0F0F
	v_or_b32_e32 v23, 0x64006400, v23                          // 000000DDCD28: 382E2EFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DDCD30: BF870214
	v_or_b32_e32 v24, 0x64006400, v24                          // 000000DDCD34: 383030FF 64006400
	v_perm_b32 v233, v18, v65, 0xc040c00                       // 000000DDCD3C: D64400E9 03FE8312 0C040C00
	v_perm_b32 v234, v18, v65, 0xc050c01                       // 000000DDCD48: D64400EA 03FE8312 0C050C01
	v_perm_b32 v235, v18, v65, 0xc060c02                       // 000000DDCD54: D64400EB 03FE8312 0C060C02
	v_perm_b32 v236, v18, v65, 0xc070c03                       // 000000DDCD60: D64400EC 03FE8312 0C070C03
	v_and_b32_e32 v65, 0xf0f0f0f, v94                          // 000000DDCD6C: 3682BCFF 0F0F0F0F
	v_and_b32_e32 v18, 0xf0f0f0f, v70                          // 000000DDCD74: 36248CFF 0F0F0F0F
	v_and_b32_e32 v70, 0xf0f0f0f, v110                         // 000000DDCD7C: 368CDCFF 0F0F0F0F
	.long 0xcc0f4018                                           // 000000DDCD84: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000DDCD88: 120230FF 0000E408
	.long 0xcc0f4017                                           // 000000DDCD90: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DDCD94: 12022EFF 0000E408
	v_perm_b32 v245, v65, v93, 0xc040c00                       // 000000DDCD9C: D64400F5 03FEBB41 0C040C00
	v_perm_b32 v248, v65, v93, 0xc050c01                       // 000000DDCDA8: D64400F8 03FEBB41 0C050C01
	v_perm_b32 v247, v65, v93, 0xc060c02                       // 000000DDCDB4: D64400F7 03FEBB41 0C060C02
	v_perm_b32 v41, v65, v93, 0xc070c03                        // 000000DDCDC0: D6440029 03FEBB41 0C070C03
	v_and_b32_e32 v65, 0xf0f0f0f, v98                          // 000000DDCDCC: 3682C4FF 0F0F0F0F
	scratch_store_b32 off, v24, off offset:64                  // 000000DDCDD4: DC690040 007C1800
	v_or_b32_e32 v24, 0x64006400, v29                          // 000000DDCDDC: 38303AFF 64006400
	v_perm_b32 v239, v18, v69, 0xc040c00                       // 000000DDCDE4: D64400EF 03FE8B12 0C040C00
	scratch_store_b32 off, v41, off offset:752                 // 000000DDCDF0: DC6902F0 007C2900
	v_perm_b32 v41, v65, v101, 0xc040c00                       // 000000DDCDF8: D6440029 03FECB41 0C040C00
	v_perm_b32 v240, v18, v69, 0xc050c01                       // 000000DDCE04: D64400F0 03FE8B12 0C050C01
	v_perm_b32 v241, v18, v69, 0xc060c02                       // 000000DDCE10: D64400F1 03FE8B12 0C060C02
	v_perm_b32 v246, v18, v69, 0xc070c03                       // 000000DDCE1C: D64400F6 03FE8B12 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v72                          // 000000DDCE28: 362490FF 0F0F0F0F
	scratch_store_b32 off, v41, off offset:756                 // 000000DDCE30: DC6902F4 007C2900
	v_perm_b32 v41, v65, v101, 0xc050c01                       // 000000DDCE38: D6440029 03FECB41 0C050C01
	v_or_b32_e32 v72, 0x64006400, v231                         // 000000DDCE44: 3891CEFF 64006400
	v_perm_b32 v237, v63, v91, 0xc040c00                       // 000000DDCE4C: D64400ED 03FEB73F 0C040C00
	v_perm_b32 v2, v18, v71, 0xc060c02                         // 000000DDCE58: D6440002 03FE8F12 0C060C02
	v_perm_b32 v4, v18, v71, 0xc070c03                         // 000000DDCE64: D6440004 03FE8F12 0C070C03
	scratch_store_b32 off, v41, off offset:760                 // 000000DDCE70: DC6902F8 007C2900
	v_perm_b32 v41, v65, v101, 0xc060c02                       // 000000DDCE78: D6440029 03FECB41 0C060C02
	v_perm_b32 v251, v18, v71, 0xc040c00                       // 000000DDCE84: D64400FB 03FE8F12 0C040C00
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDCE90: 380404FF 64006400
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDCE98: 380808FF 64006400
	v_perm_b32 v255, v18, v71, 0xc050c01                       // 000000DDCEA0: D64400FF 03FE8F12 0C050C01
	scratch_store_b32 off, v41, off offset:764                 // 000000DDCEAC: DC6902FC 007C2900
	v_perm_b32 v41, v65, v101, 0xc070c03                       // 000000DDCEB4: D6440029 03FECB41 0C070C03
	v_and_b32_e32 v65, 0xf0f0f0f, v103                         // 000000DDCEC0: 3682CEFF 0F0F0F0F
	.long 0xcc0f4002                                           // 000000DDCEC8: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDCECC: 120204FF 0000E408
	v_and_b32_e32 v71, 0xf0f0f0f, v128                         // 000000DDCED4: 368F00FF 0F0F0F0F
	v_and_b32_e32 v18, 0xf0f0f0f, v74                          // 000000DDCEDC: 362494FF 0F0F0F0F
	scratch_store_b32 off, v41, off offset:768                 // 000000DDCEE4: DC690300 007C2900
	v_perm_b32 v41, v65, v102, 0xc040c00                       // 000000DDCEEC: D6440029 03FECD41 0C040C00
	scratch_store_b32 off, v2, off offset:440                  // 000000DDCEF8: DC6901B8 007C0200
	.long 0xcc0f4002                                           // 000000DDCF00: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDCF04: 120208FF 0000E408
	v_and_b32_e32 v74, 0xf0f0f0f, v130                         // 000000DDCF0C: 369504FF 0F0F0F0F
	v_perm_b32 v19, v18, v73, 0xc040c00                        // 000000DDCF14: D6440013 03FE9312 0C040C00
	scratch_store_b32 off, v41, off offset:732                 // 000000DDCF20: DC6902DC 007C2900
	v_perm_b32 v41, v65, v102, 0xc050c01                       // 000000DDCF28: D6440029 03FECD41 0C050C01
	v_perm_b32 v21, v18, v73, 0xc060c02                        // 000000DDCF34: D6440015 03FE9312 0C060C02
	v_perm_b32 v5, v18, v73, 0xc070c03                         // 000000DDCF40: D6440005 03FE9312 0C070C03
	v_perm_b32 v231, v74, v129, 0xc050c01                      // 000000DDCF4C: D64400E7 03FF034A 0C050C01
	v_perm_b32 v179, v63, v91, 0xc050c01                       // 000000DDCF58: D64400B3 03FEB73F 0C050C01
	scratch_store_b32 off, v41, off offset:736                 // 000000DDCF64: DC6902E0 007C2900
	v_perm_b32 v41, v65, v102, 0xc060c02                       // 000000DDCF6C: D6440029 03FECD41 0C060C02
	v_perm_b32 v249, v63, v91, 0xc060c02                       // 000000DDCF78: D64400F9 03FEB73F 0C060C02
	v_perm_b32 v250, v63, v91, 0xc070c03                       // 000000DDCF84: D64400FA 03FEB73F 0C070C03
	s_clause 0x1                                               // 000000DDCF90: BF850001
	scratch_store_b32 off, v2, off offset:444                  // 000000DDCF94: DC6901BC 007C0200
	scratch_store_b32 off, v41, off offset:740                 // 000000DDCF9C: DC6902E4 007C2900
	v_perm_b32 v41, v65, v102, 0xc070c03                       // 000000DDCFA4: D6440029 03FECD41 0C070C03
	v_and_b32_e32 v65, 0xf0f0f0f, v105                         // 000000DDCFB0: 3682D2FF 0F0F0F0F
	v_or_b32_e32 v105, 0x64006400, v220                        // 000000DDCFB8: 38D3B8FF 64006400
	scratch_store_b32 off, v41, off offset:744                 // 000000DDCFC0: DC6902E8 007C2900
	v_perm_b32 v41, v65, v104, 0xc040c00                       // 000000DDCFC8: D6440029 03FED141 0C040C00
	scratch_store_b32 off, v41, off offset:748                 // 000000DDCFD4: DC6902EC 007C2900
	v_perm_b32 v41, v65, v104, 0xc050c01                       // 000000DDCFDC: D6440029 03FED141 0C050C01
	scratch_store_b32 off, v41, off offset:648                 // 000000DDCFE8: DC690288 007C2900
	v_perm_b32 v41, v65, v104, 0xc060c02                       // 000000DDCFF0: D6440029 03FED141 0C060C02
	scratch_store_b32 off, v41, off offset:652                 // 000000DDCFFC: DC69028C 007C2900
	v_perm_b32 v41, v65, v104, 0xc070c03                       // 000000DDD004: D6440029 03FED141 0C070C03
	scratch_store_b32 off, v41, off offset:656                 // 000000DDD010: DC690290 007C2900
	v_perm_b32 v41, v70, v109, 0xc040c00                       // 000000DDD018: D6440029 03FEDB46 0C040C00
	scratch_store_b32 off, v41, off offset:660                 // 000000DDD024: DC690294 007C2900
	v_perm_b32 v41, v70, v109, 0xc050c01                       // 000000DDD02C: D6440029 03FEDB46 0C050C01
	scratch_store_b32 off, v41, off offset:664                 // 000000DDD038: DC690298 007C2900
	v_perm_b32 v41, v70, v109, 0xc060c02                       // 000000DDD040: D6440029 03FEDB46 0C060C02
	scratch_store_b32 off, v1, off offset:396                  // 000000DDD04C: DC69018C 007C0100
	v_and_b32_e32 v1, 0xf0f0f0f, v20                           // 000000DDD054: 360228FF 0F0F0F0F
	v_perm_b32 v20, v18, v73, 0xc050c01                        // 000000DDD05C: D6440014 03FE9312 0C050C01
	v_and_b32_e32 v18, 0xf0f0f0f, v76                          // 000000DDD068: 362498FF 0F0F0F0F
	scratch_store_b32 off, v41, off offset:548                 // 000000DDD070: DC690224 007C2900
	v_perm_b32 v41, v70, v109, 0xc070c03                       // 000000DDD078: D6440029 03FEDB46 0C070C03
	v_and_b32_e32 v70, 0xf0f0f0f, v112                         // 000000DDD084: 368CE0FF 0F0F0F0F
	v_perm_b32 v212, v1, v48, 0xc040c00                        // 000000DDD08C: D64400D4 03FE6101 0C040C00
	v_perm_b32 v213, v1, v48, 0xc050c01                        // 000000DDD098: D64400D5 03FE6101 0C050C01
	v_perm_b32 v214, v1, v48, 0xc060c02                        // 000000DDD0A4: D64400D6 03FE6101 0C060C02
	scratch_store_b32 off, v41, off offset:552                 // 000000DDD0B0: DC690228 007C2900
	v_perm_b32 v41, v70, v111, 0xc040c00                       // 000000DDD0B8: D6440029 03FEDF46 0C040C00
	v_perm_b32 v1, v1, v48, 0xc070c03                          // 000000DDD0C4: D6440001 03FE6101 0C070C03
	v_perm_b32 v22, v18, v75, 0xc040c00                        // 000000DDD0D0: D6440016 03FE9712 0C040C00
	v_perm_b32 v27, v18, v75, 0xc050c01                        // 000000DDD0DC: D644001B 03FE9712 0C050C01
	v_perm_b32 v28, v18, v75, 0xc060c02                        // 000000DDD0E8: D644001C 03FE9712 0C060C02
	scratch_store_b32 off, v41, off offset:556                 // 000000DDD0F4: DC69022C 007C2900
	v_perm_b32 v41, v70, v111, 0xc050c01                       // 000000DDD0FC: D6440029 03FEDF46 0C050C01
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DDD108: 380202FF 64006400
	v_perm_b32 v31, v18, v75, 0xc070c03                        // 000000DDD110: D644001F 03FE9712 0C070C03
	v_or_b32_e32 v75, 0x64006400, v230                         // 000000DDD11C: 3897CCFF 64006400
	v_and_b32_e32 v18, 0xf0f0f0f, v78                          // 000000DDD124: 36249CFF 0F0F0F0F
	scratch_store_b32 off, v41, off offset:560                 // 000000DDD12C: DC690230 007C2900
	v_perm_b32 v41, v70, v111, 0xc060c02                       // 000000DDD134: D6440029 03FEDF46 0C060C02
	.long 0xcc0f4001                                           // 000000DDD140: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DDD144: 120202FF 0000E408
	scratch_store_b32 off, v23, off offset:68                  // 000000DDD14C: DC690044 007C1700
	v_and_b32_e32 v78, 0xf0f0f0f, v132                         // 000000DDD154: 369D08FF 0F0F0F0F
	v_perm_b32 v6, v18, v77, 0xc040c00                         // 000000DDD15C: D6440006 03FE9B12 0C040C00
	scratch_store_b32 off, v41, off offset:564                 // 000000DDD168: DC690234 007C2900
	v_perm_b32 v41, v70, v111, 0xc070c03                       // 000000DDD170: D6440029 03FEDF46 0C070C03
	v_and_b32_e32 v70, 0xf0f0f0f, v114                         // 000000DDD17C: 368CE4FF 0F0F0F0F
	v_perm_b32 v7, v18, v77, 0xc050c01                         // 000000DDD184: D6440007 03FE9B12 0C050C01
	v_perm_b32 v8, v18, v77, 0xc060c02                         // 000000DDD190: D6440008 03FE9B12 0C060C02
	v_perm_b32 v11, v18, v77, 0xc070c03                        // 000000DDD19C: D644000B 03FE9B12 0C070C03
	s_clause 0x1                                               // 000000DDD1A8: BF850001
	scratch_store_b32 off, v41, off offset:488                 // 000000DDD1AC: DC6901E8 007C2900
	scratch_store_b32 off, v1, off offset:192                  // 000000DDD1B4: DC6900C0 007C0100
	v_perm_b32 v41, v70, v113, 0xc040c00                       // 000000DDD1BC: D6440029 03FEE346 0C040C00
	v_and_b32_e32 v18, 0xf0f0f0f, v80                          // 000000DDD1C8: 3624A0FF 0F0F0F0F
	v_perm_b32 v230, v78, v131, 0xc040c00                      // 000000DDD1D0: D64400E6 03FF074E 0C040C00
	v_and_b32_e32 v80, 0xf0f0f0f, v134                         // 000000DDD1DC: 36A10CFF 0F0F0F0F
	v_perm_b32 v48, v38, v83, 0xc050c01                        // 000000DDD1E4: D6440030 03FEA726 0C050C01
	scratch_store_b32 off, v41, off offset:492                 // 000000DDD1F0: DC6901EC 007C2900
	v_perm_b32 v41, v70, v113, 0xc050c01                       // 000000DDD1F8: D6440029 03FEE346 0C050C01
	v_perm_b32 v43, v18, v79, 0xc040c00                        // 000000DDD204: D644002B 03FE9F12 0C040C00
	v_perm_b32 v12, v18, v79, 0xc050c01                        // 000000DDD210: D644000C 03FE9F12 0C050C01
	v_perm_b32 v14, v18, v79, 0xc060c02                        // 000000DDD21C: D644000E 03FE9F12 0C060C02
	v_perm_b32 v17, v18, v79, 0xc070c03                        // 000000DDD228: D6440011 03FE9F12 0C070C03
	scratch_store_b32 off, v41, off offset:496                 // 000000DDD234: DC6901F0 007C2900
	v_perm_b32 v41, v70, v113, 0xc060c02                       // 000000DDD23C: D6440029 03FEE346 0C060C02
	v_or_b32_e32 v79, 0x64006400, v228                         // 000000DDD248: 389FC8FF 64006400
	v_and_b32_e32 v18, 0xf0f0f0f, v82                          // 000000DDD250: 3624A4FF 0F0F0F0F
	v_perm_b32 v228, v80, v133, 0xc050c01                      // 000000DDD258: D64400E4 03FF0B50 0C050C01
	v_and_b32_e32 v83, 0xf0f0f0f, v136                         // 000000DDD264: 36A710FF 0F0F0F0F
	scratch_store_b32 off, v41, off offset:500                 // 000000DDD26C: DC6901F4 007C2900
	v_perm_b32 v41, v70, v113, 0xc070c03                       // 000000DDD274: D6440029 03FEE346 0C070C03
	v_and_b32_e32 v70, 0xf0f0f0f, v116                         // 000000DDD280: 368CE8FF 0F0F0F0F
	v_perm_b32 v44, v18, v81, 0xc040c00                        // 000000DDD288: D644002C 03FEA312 0C040C00
	v_perm_b32 v45, v18, v81, 0xc050c01                        // 000000DDD294: D644002D 03FEA312 0C050C01
	v_perm_b32 v36, v18, v81, 0xc060c02                        // 000000DDD2A0: D6440024 03FEA312 0C060C02
	v_perm_b32 v18, v18, v81, 0xc070c03                        // 000000DDD2AC: D6440012 03FEA312 0C070C03
	v_perm_b32 v23, v70, v115, 0xc040c00                       // 000000DDD2B8: D6440017 03FEE746 0C040C00
	v_or_b32_e32 v81, 0x64006400, v226                         // 000000DDD2C4: 38A3C4FF 64006400
	v_and_b32_e32 v38, 0xf0f0f0f, v86                          // 000000DDD2CC: 364CACFF 0F0F0F0F
	v_and_b32_e32 v86, 0xf0f0f0f, v138                         // 000000DDD2D4: 36AD14FF 0F0F0F0F
	v_or_b32_e32 v4, 0x64006400, v22                           // 000000DDD2DC: 38082CFF 64006400
	scratch_store_b32 off, v23, off offset:508                 // 000000DDD2E4: DC6901FC 007C1700
	v_perm_b32 v23, v70, v115, 0xc050c01                       // 000000DDD2EC: D6440017 03FEE746 0C050C01
	v_perm_b32 v52, v38, v85, 0xc040c00                        // 000000DDD2F8: D6440034 03FEAB26 0C040C00
	v_perm_b32 v55, v38, v85, 0xc050c01                        // 000000DDD304: D6440037 03FEAB26 0C050C01
	v_perm_b32 v60, v38, v85, 0xc060c02                        // 000000DDD310: D644003C 03FEAB26 0C060C02
	v_perm_b32 v178, v38, v85, 0xc070c03                       // 000000DDD31C: D64400B2 03FEAB26 0C070C03
	scratch_store_b32 off, v23, off offset:512                 // 000000DDD328: DC690200 007C1700
	v_perm_b32 v23, v70, v115, 0xc060c02                       // 000000DDD330: D6440017 03FEE746 0C060C02
	v_or_b32_e32 v85, 0x64006400, v224                         // 000000DDD33C: 38ABC0FF 64006400
	v_and_b32_e32 v38, 0xf0f0f0f, v88                          // 000000DDD344: 364CB0FF 0F0F0F0F
	v_or_b32_e32 v88, 0x64006400, v222                         // 000000DDD34C: 38B1BCFF 64006400
	scratch_store_b32 off, v23, off offset:516                 // 000000DDD354: DC690204 007C1700
	v_perm_b32 v23, v70, v115, 0xc070c03                       // 000000DDD35C: D6440017 03FEE746 0C070C03
	v_and_b32_e32 v70, 0xf0f0f0f, v118                         // 000000DDD368: 368CECFF 0F0F0F0F
	v_perm_b32 v39, v38, v87, 0xc040c00                        // 000000DDD370: D6440027 03FEAF26 0C040C00
	v_perm_b32 v40, v38, v87, 0xc050c01                        // 000000DDD37C: D6440028 03FEAF26 0C050C01
	v_perm_b32 v95, v38, v87, 0xc060c02                        // 000000DDD388: D644005F 03FEAF26 0C060C02
	scratch_store_b32 off, v23, off offset:520                 // 000000DDD394: DC690208 007C1700
	v_or_b32_e32 v23, 0x64006400, v30                          // 000000DDD39C: 382E3CFF 64006400
	v_perm_b32 v97, v38, v87, 0xc070c03                        // 000000DDD3A4: D6440061 03FEAF26 0C070C03
	v_or_b32_e32 v87, 0x64006400, v221                         // 000000DDD3B0: 38AFBAFF 64006400
	v_perm_b32 v38, v42, v89, 0xc040c00                        // 000000DDD3B8: D6440026 03FEB32A 0C040C00
	v_and_b32_e32 v89, 0xf0f0f0f, v140                         // 000000DDD3C4: 36B318FF 0F0F0F0F
	.long 0xcc0f4017                                           // 000000DDD3CC: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DDD3D0: 12022EFF 0000E408
	scratch_store_b32 off, v23, off offset:72                  // 000000DDD3D8: DC690048 007C1700
	.long 0xcc0f4017                                           // 000000DDD3E0: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000DDD3E4: 120230FF 0000E408
	v_or_b32_e32 v24, 0x64006400, v32                          // 000000DDD3EC: 383040FF 64006400
	scratch_store_b32 off, v23, off offset:76                  // 000000DDD3F4: DC69004C 007C1700
	v_perm_b32 v23, v70, v117, 0xc040c00                       // 000000DDD3FC: D6440017 03FEEB46 0C040C00
	scratch_store_b32 off, v23, off offset:568                 // 000000DDD408: DC690238 007C1700
	v_perm_b32 v23, v70, v117, 0xc050c01                       // 000000DDD410: D6440017 03FEEB46 0C050C01
	scratch_store_b32 off, v23, off offset:524                 // 000000DDD41C: DC69020C 007C1700
	v_perm_b32 v23, v70, v117, 0xc060c02                       // 000000DDD424: D6440017 03FEEB46 0C060C02
	scratch_store_b32 off, v23, off offset:528                 // 000000DDD430: DC690210 007C1700
	v_perm_b32 v23, v70, v117, 0xc070c03                       // 000000DDD438: D6440017 03FEEB46 0C070C03
	v_and_b32_e32 v70, 0xf0f0f0f, v124                         // 000000DDD444: 368CF8FF 0F0F0F0F
	v_and_b32_e32 v124, 0xf0f0f0f, v142                        // 000000DDD44C: 36F91CFF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:532                 // 000000DDD454: DC690214 007C1700
	v_or_b32_e32 v23, 0x64006400, v33                          // 000000DDD45C: 382E42FF 64006400
	v_and_b32_e32 v33, 0xf0f0f0f, v120                         // 000000DDD464: 3642F0FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DDD46C: BF870002
	.long 0xcc0f4017                                           // 000000DDD470: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DDD474: 12022EFF 0000E408
	scratch_store_b32 off, v23, off offset:80                  // 000000DDD47C: DC690050 007C1700
	.long 0xcc0f4017                                           // 000000DDD484: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000DDD488: 120230FF 0000E408
	v_or_b32_e32 v24, 0x64006400, v34                          // 000000DDD490: 383044FF 64006400
	v_and_b32_e32 v34, 0xf0f0f0f, v122                         // 000000DDD498: 3644F4FF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:84                  // 000000DDD4A0: DC690054 007C1700
	v_perm_b32 v23, v33, v119, 0xc040c00                       // 000000DDD4A8: D6440017 03FEEF21 0C040C00
	scratch_store_b32 off, v23, off offset:572                 // 000000DDD4B4: DC69023C 007C1700
	v_perm_b32 v23, v33, v119, 0xc050c01                       // 000000DDD4BC: D6440017 03FEEF21 0C050C01
	scratch_store_b32 off, v23, off offset:576                 // 000000DDD4C8: DC690240 007C1700
	v_perm_b32 v23, v33, v119, 0xc060c02                       // 000000DDD4D0: D6440017 03FEEF21 0C060C02
	scratch_store_b32 off, v23, off offset:536                 // 000000DDD4DC: DC690218 007C1700
	v_perm_b32 v23, v33, v119, 0xc070c03                       // 000000DDD4E4: D6440017 03FEEF21 0C070C03
	scratch_store_b32 off, v23, off offset:540                 // 000000DDD4F0: DC69021C 007C1700
	v_or_b32_e32 v23, 0x64006400, v46                          // 000000DDD4F8: 382E5CFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDD500: BF870001
	.long 0xcc0f4017                                           // 000000DDD504: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DDD508: 12022EFF 0000E408
	s_clause 0x1                                               // 000000DDD510: BF850001
	scratch_store_b32 off, v41, off offset:504                 // 000000DDD514: DC6901F8 007C2900
	scratch_store_b32 off, v23, off offset:88                  // 000000DDD51C: DC690058 007C1700
	.long 0xcc0f4017                                           // 000000DDD524: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000DDD528: 120230FF 0000E408
	v_or_b32_e32 v24, 0x64006400, v49                          // 000000DDD530: 383062FF 64006400
	scratch_store_b32 off, v23, off offset:92                  // 000000DDD538: DC69005C 007C1700
	v_perm_b32 v23, v34, v121, 0xc040c00                       // 000000DDD540: D6440017 03FEF322 0C040C00
	scratch_store_b32 off, v23, off offset:580                 // 000000DDD54C: DC690244 007C1700
	v_perm_b32 v23, v34, v121, 0xc050c01                       // 000000DDD554: D6440017 03FEF322 0C050C01
	scratch_store_b32 off, v23, off offset:584                 // 000000DDD560: DC690248 007C1700
	v_perm_b32 v23, v34, v121, 0xc060c02                       // 000000DDD568: D6440017 03FEF322 0C060C02
	scratch_store_b32 off, v23, off offset:588                 // 000000DDD574: DC69024C 007C1700
	v_perm_b32 v23, v34, v121, 0xc070c03                       // 000000DDD57C: D6440017 03FEF322 0C070C03
	scratch_store_b32 off, v23, off offset:544                 // 000000DDD588: DC690220 007C1700
	v_or_b32_e32 v23, 0x64006400, v50                          // 000000DDD590: 382E64FF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDD598: BF870001
	.long 0xcc0f4017                                           // 000000DDD59C: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DDD5A0: 12022EFF 0000E408
	scratch_store_b32 off, v23, off offset:96                  // 000000DDD5A8: DC690060 007C1700
	.long 0xcc0f4017                                           // 000000DDD5B0: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000DDD5B4: 120230FF 0000E408
	v_or_b32_e32 v24, 0x64006400, v53                          // 000000DDD5BC: 38306AFF 64006400
	scratch_store_b32 off, v23, off offset:100                 // 000000DDD5C4: DC690064 007C1700
	v_perm_b32 v23, v70, v123, 0xc040c00                       // 000000DDD5CC: D6440017 03FEF746 0C040C00
	scratch_store_b32 off, v23, off offset:592                 // 000000DDD5D8: DC690250 007C1700
	v_perm_b32 v23, v70, v123, 0xc050c01                       // 000000DDD5E0: D6440017 03FEF746 0C050C01
	scratch_store_b32 off, v23, off offset:596                 // 000000DDD5EC: DC690254 007C1700
	v_perm_b32 v23, v70, v123, 0xc060c02                       // 000000DDD5F4: D6440017 03FEF746 0C060C02
	scratch_store_b32 off, v23, off offset:600                 // 000000DDD600: DC690258 007C1700
	v_perm_b32 v23, v70, v123, 0xc070c03                       // 000000DDD608: D6440017 03FEF746 0C070C03
	v_and_b32_e32 v70, 0xf0f0f0f, v126                         // 000000DDD614: 368CFCFF 0F0F0F0F
	v_and_b32_e32 v126, 0xf0f0f0f, v144                        // 000000DDD61C: 36FD20FF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:604                 // 000000DDD624: DC69025C 007C1700
	v_or_b32_e32 v23, 0x64006400, v54                          // 000000DDD62C: 382E6CFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDD634: BF870001
	.long 0xcc0f4017                                           // 000000DDD638: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DDD63C: 12022EFF 0000E408
	scratch_store_b32 off, v23, off offset:104                 // 000000DDD644: DC690068 007C1700
	.long 0xcc0f4017                                           // 000000DDD64C: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000DDD650: 120230FF 0000E408
	v_or_b32_e32 v24, 0x64006400, v57                          // 000000DDD658: 383072FF 64006400
	v_or_b32_e32 v57, 0x64006400, v58                          // 000000DDD660: 387274FF 64006400
	scratch_store_b32 off, v23, off offset:108                 // 000000DDD668: DC69006C 007C1700
	v_perm_b32 v23, v70, v125, 0xc040c00                       // 000000DDD670: D6440017 03FEFB46 0C040C00
	scratch_store_b32 off, v23, off offset:608                 // 000000DDD67C: DC690260 007C1700
	v_perm_b32 v23, v70, v125, 0xc050c01                       // 000000DDD684: D6440017 03FEFB46 0C050C01
	scratch_store_b32 off, v23, off offset:612                 // 000000DDD690: DC690264 007C1700
	v_perm_b32 v23, v70, v125, 0xc060c02                       // 000000DDD698: D6440017 03FEFB46 0C060C02
	scratch_store_b32 off, v23, off offset:616                 // 000000DDD6A4: DC690268 007C1700
	v_perm_b32 v23, v70, v125, 0xc070c03                       // 000000DDD6AC: D6440017 03FEFB46 0C070C03
	v_or_b32_e32 v125, 0x64006400, v218                        // 000000DDD6B8: 38FBB4FF 64006400
	scratch_store_b32 off, v23, off offset:620                 // 000000DDD6C0: DC69026C 007C1700
	.long 0xcc0f4017                                           // 000000DDD6C8: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000DDD6CC: 120230FF 0000E408
	scratch_store_b32 off, v23, off offset:112                 // 000000DDD6D4: DC690070 007C1700
	.long 0xcc0f4017                                           // 000000DDD6DC: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v57                          // 000000DDD6E0: 120272FF 0000E408
	scratch_store_b32 off, v23, off offset:116                 // 000000DDD6E8: DC690074 007C1700
	v_perm_b32 v23, v71, v127, 0xc040c00                       // 000000DDD6F0: D6440017 03FEFF47 0C040C00
	scratch_store_b32 off, v23, off offset:668                 // 000000DDD6FC: DC69029C 007C1700
	v_perm_b32 v23, v71, v127, 0xc050c01                       // 000000DDD704: D6440017 03FEFF47 0C050C01
	scratch_store_b32 off, v23, off offset:624                 // 000000DDD710: DC690270 007C1700
	v_perm_b32 v23, v71, v127, 0xc060c02                       // 000000DDD718: D6440017 03FEFF47 0C060C02
	scratch_store_b32 off, v23, off offset:628                 // 000000DDD724: DC690274 007C1700
	v_perm_b32 v23, v71, v127, 0xc070c03                       // 000000DDD72C: D6440017 03FEFF47 0C070C03
	v_or_b32_e32 v71, 0x64006400, v232                         // 000000DDD738: 388FD0FF 64006400
	v_perm_b32 v232, v89, v139, 0xc040c00                      // 000000DDD740: D64400E8 03FF1759 0C040C00
	scratch_store_b32 off, v23, off offset:632                 // 000000DDD74C: DC690278 007C1700
	.long 0xcc0f4017                                           // 000000DDD754: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v71                          // 000000DDD758: 12028EFF 0000E408
	scratch_load_b32 v71, off, off offset:336                  // 000000DDD760: DC510150 477C0000
	scratch_store_b32 off, v23, off offset:120                 // 000000DDD768: DC690078 007C1700
	.long 0xcc0f4017                                           // 000000DDD770: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v72                          // 000000DDD774: 120290FF 0000E408
	scratch_store_b32 off, v23, off offset:124                 // 000000DDD77C: DC69007C 007C1700
	v_perm_b32 v23, v74, v129, 0xc040c00                       // 000000DDD784: D6440017 03FF034A 0C040C00
	scratch_store_b32 off, v23, off offset:672                 // 000000DDD790: DC6902A0 007C1700
	v_perm_b32 v23, v74, v129, 0xc060c02                       // 000000DDD798: D6440017 03FF034A 0C060C02
	scratch_store_b32 off, v23, off offset:636                 // 000000DDD7A4: DC69027C 007C1700
	v_perm_b32 v23, v74, v129, 0xc070c03                       // 000000DDD7AC: D6440017 03FF034A 0C070C03
	v_or_b32_e32 v74, 0x64006400, v229                         // 000000DDD7B8: 3895CAFF 64006400
	v_perm_b32 v229, v83, v135, 0xc060c02                      // 000000DDD7C0: D64400E5 03FF0F53 0C060C02
	scratch_store_b32 off, v23, off offset:640                 // 000000DDD7CC: DC690280 007C1700
	.long 0xcc0f4017                                           // 000000DDD7D4: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v74                          // 000000DDD7D8: 120294FF 0000E408
	scratch_store_b32 off, v23, off offset:128                 // 000000DDD7E0: DC690080 007C1700
	.long 0xcc0f4017                                           // 000000DDD7E8: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v75                          // 000000DDD7EC: 120296FF 0000E408
	scratch_store_b32 off, v23, off offset:132                 // 000000DDD7F4: DC690084 007C1700
	v_perm_b32 v23, v78, v131, 0xc050c01                       // 000000DDD7FC: D6440017 03FF074E 0C050C01
	scratch_store_b32 off, v23, off offset:676                 // 000000DDD808: DC6902A4 007C1700
	v_perm_b32 v23, v78, v131, 0xc060c02                       // 000000DDD810: D6440017 03FF074E 0C060C02
	scratch_store_b32 off, v23, off offset:680                 // 000000DDD81C: DC6902A8 007C1700
	v_perm_b32 v23, v78, v131, 0xc070c03                       // 000000DDD824: D6440017 03FF074E 0C070C03
	v_or_b32_e32 v78, 0x64006400, v227                         // 000000DDD830: 389DC6FF 64006400
	v_perm_b32 v227, v86, v137, 0xc040c00                      // 000000DDD838: D64400E3 03FF1356 0C040C00
	scratch_store_b32 off, v23, off offset:644                 // 000000DDD844: DC690284 007C1700
	.long 0xcc0f4017                                           // 000000DDD84C: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v78                          // 000000DDD850: 12029CFF 0000E408
	scratch_store_b32 off, v23, off offset:136                 // 000000DDD858: DC690088 007C1700
	.long 0xcc0f4017                                           // 000000DDD860: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v79                          // 000000DDD864: 12029EFF 0000E408
	scratch_store_b32 off, v23, off offset:140                 // 000000DDD86C: DC69008C 007C1700
	v_perm_b32 v23, v80, v133, 0xc040c00                       // 000000DDD874: D6440017 03FF0B50 0C040C00
	scratch_store_b32 off, v23, off offset:684                 // 000000DDD880: DC6902AC 007C1700
	v_perm_b32 v23, v80, v133, 0xc060c02                       // 000000DDD888: D6440017 03FF0B50 0C060C02
	scratch_store_b32 off, v23, off offset:688                 // 000000DDD894: DC6902B0 007C1700
	v_perm_b32 v23, v80, v133, 0xc070c03                       // 000000DDD89C: D6440017 03FF0B50 0C070C03
	v_or_b32_e32 v80, 0x64006400, v225                         // 000000DDD8A8: 38A1C2FF 64006400
	scratch_store_b32 off, v23, off offset:692                 // 000000DDD8B0: DC6902B4 007C1700
	.long 0xcc0f4017                                           // 000000DDD8B8: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v80                          // 000000DDD8BC: 1202A0FF 0000E408
	scratch_store_b32 off, v23, off offset:144                 // 000000DDD8C4: DC690090 007C1700
	.long 0xcc0f4017                                           // 000000DDD8CC: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v81                          // 000000DDD8D0: 1202A2FF 0000E408
	scratch_store_b32 off, v23, off offset:148                 // 000000DDD8D8: DC690094 007C1700
	v_perm_b32 v23, v83, v135, 0xc040c00                       // 000000DDD8E0: D6440017 03FF0F53 0C040C00
	scratch_store_b32 off, v23, off offset:696                 // 000000DDD8EC: DC6902B8 007C1700
	v_perm_b32 v23, v83, v135, 0xc050c01                       // 000000DDD8F4: D6440017 03FF0F53 0C050C01
	scratch_store_b32 off, v23, off offset:700                 // 000000DDD900: DC6902BC 007C1700
	v_perm_b32 v23, v83, v135, 0xc070c03                       // 000000DDD908: D6440017 03FF0F53 0C070C03
	scratch_store_b32 off, v23, off offset:704                 // 000000DDD914: DC6902C0 007C1700
	.long 0xcc0f4017                                           // 000000DDD91C: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v84                          // 000000DDD920: 1202A8FF 0000E408
	scratch_store_b32 off, v23, off offset:152                 // 000000DDD928: DC690098 007C1700
	.long 0xcc0f4017                                           // 000000DDD930: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v85                          // 000000DDD934: 1202AAFF 0000E408
	scratch_store_b32 off, v23, off offset:156                 // 000000DDD93C: DC69009C 007C1700
	v_perm_b32 v23, v86, v137, 0xc050c01                       // 000000DDD944: D6440017 03FF1356 0C050C01
	scratch_store_b32 off, v23, off offset:708                 // 000000DDD950: DC6902C4 007C1700
	v_perm_b32 v23, v86, v137, 0xc060c02                       // 000000DDD958: D6440017 03FF1356 0C060C02
	scratch_store_b32 off, v23, off offset:712                 // 000000DDD964: DC6902C8 007C1700
	v_perm_b32 v23, v86, v137, 0xc070c03                       // 000000DDD96C: D6440017 03FF1356 0C070C03
	scratch_store_b32 off, v23, off offset:716                 // 000000DDD978: DC6902CC 007C1700
	.long 0xcc0f4017                                           // 000000DDD980: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v87                          // 000000DDD984: 1202AEFF 0000E408
	scratch_store_b32 off, v23, off offset:160                 // 000000DDD98C: DC6900A0 007C1700
	.long 0xcc0f4017                                           // 000000DDD994: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v88                          // 000000DDD998: 1202B0FF 0000E408
	scratch_store_b32 off, v23, off offset:164                 // 000000DDD9A0: DC6900A4 007C1700
	v_perm_b32 v23, v89, v139, 0xc050c01                       // 000000DDD9A8: D6440017 03FF1759 0C050C01
	scratch_store_b32 off, v23, off offset:772                 // 000000DDD9B4: DC690304 007C1700
	v_perm_b32 v23, v89, v139, 0xc060c02                       // 000000DDD9BC: D6440017 03FF1759 0C060C02
	scratch_store_b32 off, v23, off offset:720                 // 000000DDD9C8: DC6902D0 007C1700
	v_perm_b32 v23, v89, v139, 0xc070c03                       // 000000DDD9D0: D6440017 03FF1759 0C070C03
	v_or_b32_e32 v89, 0x64006400, v219                         // 000000DDD9DC: 38B3B6FF 64006400
	scratch_store_b32 off, v23, off offset:724                 // 000000DDD9E4: DC6902D4 007C1700
	.long 0xcc0f4017                                           // 000000DDD9EC: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v89                          // 000000DDD9F0: 1202B2FF 0000E408
	scratch_store_b32 off, v23, off offset:168                 // 000000DDD9F8: DC6900A8 007C1700
	.long 0xcc0f4017                                           // 000000DDDA00: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v105                         // 000000DDDA04: 1202D2FF 0000E408
	scratch_store_b32 off, v23, off offset:172                 // 000000DDDA0C: DC6900AC 007C1700
	v_perm_b32 v23, v124, v141, 0xc040c00                      // 000000DDDA14: D6440017 03FF1B7C 0C040C00
	scratch_store_b32 off, v23, off offset:776                 // 000000DDDA20: DC690308 007C1700
	v_perm_b32 v23, v124, v141, 0xc050c01                      // 000000DDDA28: D6440017 03FF1B7C 0C050C01
	scratch_store_b32 off, v23, off offset:780                 // 000000DDDA34: DC69030C 007C1700
	v_perm_b32 v23, v124, v141, 0xc060c02                      // 000000DDDA3C: D6440017 03FF1B7C 0C060C02
	scratch_store_b32 off, v23, off offset:784                 // 000000DDDA48: DC690310 007C1700
	v_perm_b32 v23, v124, v141, 0xc070c03                      // 000000DDDA50: D6440017 03FF1B7C 0C070C03
	v_or_b32_e32 v124, 0x64006400, v217                        // 000000DDDA5C: 38F9B2FF 64006400
	scratch_store_b32 off, v23, off offset:728                 // 000000DDDA64: DC6902D8 007C1700
	.long 0xcc0f4017                                           // 000000DDDA6C: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDDA70: 1202F8FF 0000E408
	v_or_b32_e32 v124, 0x64006400, v215                        // 000000DDDA78: 38F9AEFF 64006400
	scratch_store_b32 off, v23, off offset:176                 // 000000DDDA80: DC6900B0 007C1700
	.long 0xcc0f4017                                           // 000000DDDA88: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDDA8C: 1202FAFF 0000E408
	v_or_b32_e32 v125, 0x64006400, v216                        // 000000DDDA94: 38FBB0FF 64006400
	scratch_store_b32 off, v23, off offset:180                 // 000000DDDA9C: DC6900B4 007C1700
	v_perm_b32 v23, v126, v143, 0xc040c00                      // 000000DDDAA4: D6440017 03FF1F7E 0C040C00
	scratch_store_b32 off, v23, off offset:788                 // 000000DDDAB0: DC690314 007C1700
	v_perm_b32 v23, v126, v143, 0xc050c01                      // 000000DDDAB8: D6440017 03FF1F7E 0C050C01
	scratch_store_b32 off, v23, off offset:792                 // 000000DDDAC4: DC690318 007C1700
	v_perm_b32 v23, v126, v143, 0xc060c02                      // 000000DDDACC: D6440017 03FF1F7E 0C060C02
	scratch_store_b32 off, v23, off offset:796                 // 000000DDDAD8: DC69031C 007C1700
	v_perm_b32 v23, v126, v143, 0xc070c03                      // 000000DDDAE0: D6440017 03FF1F7E 0C070C03
	v_and_b32_e32 v126, 0xf0f0f0f, v146                        // 000000DDDAEC: 36FD24FF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:800                 // 000000DDDAF4: DC690320 007C1700
	.long 0xcc0f4017                                           // 000000DDDAFC: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDDB00: 1202F8FF 0000E408
	v_or_b32_e32 v124, 0x64006400, v213                        // 000000DDDB08: 38F9AAFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDDB10: BF870001
	.long 0xcc0f4001                                           // 000000DDDB14: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDDB18: 1202F8FF 0000E408
	scratch_store_b32 off, v23, off offset:184                 // 000000DDDB20: DC6900B8 007C1700
	.long 0xcc0f4017                                           // 000000DDDB28: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDDB2C: 1202FAFF 0000E408
	v_and_b32_e32 v125, 0xf0f0f0f, v148                        // 000000DDDB34: 36FB28FF 0F0F0F0F
	v_and_b32_e32 v124, 0xf0f0f0f, v150                        // 000000DDDB3C: 36F92CFF 0F0F0F0F
	scratch_store_b32 off, v1, off offset:196                  // 000000DDDB44: DC6900C4 007C0100
	v_perm_b32 v1, v125, v147, 0xc040c00                       // 000000DDDB4C: D6440001 03FF277D 0C040C00
	v_perm_b32 v252, v125, v147, 0xc050c01                     // 000000DDDB58: D64400FC 03FF277D 0C050C01
	v_perm_b32 v253, v125, v147, 0xc060c02                     // 000000DDDB64: D64400FD 03FF277D 0C060C02
	v_perm_b32 v254, v125, v147, 0xc070c03                     // 000000DDDB70: D64400FE 03FF277D 0C070C03
	v_and_b32_e32 v125, 0xf0f0f0f, v152                        // 000000DDDB7C: 36FB30FF 0F0F0F0F
	v_perm_b32 v0, v124, v149, 0xc040c00                       // 000000DDDB84: D6440000 03FF2B7C 0C040C00
	v_perm_b32 v121, v124, v149, 0xc050c01                     // 000000DDDB90: D6440079 03FF2B7C 0C050C01
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DDDB9C: 380202FF 64006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DDDBA4: BF870004
	v_perm_b32 v3, v125, v151, 0xc040c00                       // 000000DDDBA8: D6440003 03FF2F7D 0C040C00
	v_perm_b32 v122, v125, v151, 0xc050c01                     // 000000DDDBB4: D644007A 03FF2F7D 0C050C01
	v_perm_b32 v29, v125, v151, 0xc060c02                      // 000000DDDBC0: D644001D 03FF2F7D 0C060C02
	v_or_b32_e32 v0, 0x64006400, v0                            // 000000DDDBCC: 380000FF 64006400
	scratch_store_b32 off, v3, off offset:836                  // 000000DDDBD4: DC690344 007C0300
	v_perm_b32 v3, v125, v151, 0xc070c03                       // 000000DDDBDC: D6440003 03FF2F7D 0C070C03
	scratch_store_b32 off, v23, off offset:188                 // 000000DDDBE8: DC6900BC 007C1700
	v_perm_b32 v23, v126, v145, 0xc040c00                      // 000000DDDBF0: D6440017 03FF237E 0C040C00
	v_or_b32_e32 v125, 0x64006400, v209                        // 000000DDDBFC: 38FBA2FF 64006400
	s_clause 0x1                                               // 000000DDDC04: BF850001
	scratch_store_b32 off, v3, off offset:828                  // 000000DDDC08: DC69033C 007C0300
	scratch_store_b32 off, v23, off offset:804                 // 000000DDDC10: DC690324 007C1700
	v_perm_b32 v23, v126, v145, 0xc050c01                      // 000000DDDC18: D6440017 03FF237E 0C050C01
	scratch_store_b32 off, v23, off offset:808                 // 000000DDDC24: DC690328 007C1700
	v_perm_b32 v23, v126, v145, 0xc060c02                      // 000000DDDC2C: D6440017 03FF237E 0C060C02
	scratch_store_b32 off, v23, off offset:812                 // 000000DDDC38: DC69032C 007C1700
	v_perm_b32 v23, v126, v145, 0xc070c03                      // 000000DDDC40: D6440017 03FF237E 0C070C03
	v_and_b32_e32 v126, 0xf0f0f0f, v154                        // 000000DDDC4C: 36FD34FF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:816                 // 000000DDDC54: DC690330 007C1700
	v_or_b32_e32 v23, 0x64006400, v214                         // 000000DDDC5C: 382FACFF 64006400
	v_perm_b32 v30, v126, v153, 0xc040c00                      // 000000DDDC64: D644001E 03FF337E 0C040C00
	v_perm_b32 v32, v126, v153, 0xc050c01                      // 000000DDDC70: D6440020 03FF337E 0C050C01
	v_perm_b32 v120, v126, v153, 0xc060c02                     // 000000DDDC7C: D6440078 03FF337E 0C060C02
	v_perm_b32 v34, v126, v153, 0xc070c03                      // 000000DDDC88: D6440022 03FF337E 0C070C03
	.long 0xcc0f4017                                           // 000000DDDC94: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DDDC98: 12022EFF 0000E408
	v_and_b32_e32 v126, 0xf0f0f0f, v156                        // 000000DDDCA0: 36FD38FF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:200                 // 000000DDDCA8: DC6900C8 007C1700
	v_perm_b32 v23, v124, v149, 0xc060c02                      // 000000DDDCB0: D6440017 03FF2B7C 0C060C02
	v_perm_b32 v116, v126, v155, 0xc040c00                     // 000000DDDCBC: D6440074 03FF377E 0C040C00
	v_perm_b32 v123, v126, v155, 0xc050c01                     // 000000DDDCC8: D644007B 03FF377E 0C050C01
	v_perm_b32 v119, v126, v155, 0xc060c02                     // 000000DDDCD4: D6440077 03FF377E 0C060C02
	scratch_store_b32 off, v23, off offset:820                 // 000000DDDCE0: DC690334 007C1700
	v_perm_b32 v23, v124, v149, 0xc070c03                      // 000000DDDCE8: D6440017 03FF2B7C 0C070C03
	v_or_b32_e32 v124, 0x64006400, v212                        // 000000DDDCF4: 38F9A8FF 64006400
	scratch_store_b32 off, v23, off offset:824                 // 000000DDDCFC: DC690338 007C1700
	.long 0xcc0f4017                                           // 000000DDDD04: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDDD08: 1202F8FF 0000E408
	v_or_b32_e32 v124, 0x64006400, v211                        // 000000DDDD10: 38F9A6FF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDDD18: BF870001
	.long 0xcc0f4003                                           // 000000DDDD1C: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDDD20: 1202F8FF 0000E408
	scratch_store_b32 off, v23, off offset:208                 // 000000DDDD28: DC6900D0 007C1700
	v_or_b32_e32 v124, 0x64006400, v210                        // 000000DDDD30: 38F9A4FF 64006400
	scratch_store_b32 off, v3, off offset:216                  // 000000DDDD38: DC6900D8 007C0300
	.long 0xcc0f4003                                           // 000000DDDD40: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDDD44: 1202FAFF 0000E408
	v_or_b32_e32 v125, 0x64006400, v207                        // 000000DDDD4C: 38FB9EFF 64006400
	scratch_store_b32 off, v3, off offset:220                  // 000000DDDD54: DC6900DC 007C0300
	.long 0xcc0f4003                                           // 000000DDDD5C: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDDD60: 1202F8FF 0000E408
	v_or_b32_e32 v124, 0x64006400, v208                        // 000000DDDD68: 38F9A0FF 64006400
	scratch_store_b32 off, v3, off offset:224                  // 000000DDDD70: DC6900E0 007C0300
	.long 0xcc0f4003                                           // 000000DDDD78: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDDD7C: 1202FAFF 0000E408
	v_or_b32_e32 v125, 0x64006400, v205                        // 000000DDDD84: 38FB9AFF 64006400
	scratch_store_b32 off, v3, off offset:228                  // 000000DDDD8C: DC6900E4 007C0300
	v_perm_b32 v3, v126, v155, 0xc070c03                       // 000000DDDD94: D6440003 03FF377E 0C070C03
	v_and_b32_e32 v126, 0xf0f0f0f, v158                        // 000000DDDDA0: 36FD3CFF 0F0F0F0F
	scratch_store_b32 off, v3, off offset:840                  // 000000DDDDA8: DC690348 007C0300
	.long 0xcc0f4003                                           // 000000DDDDB0: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDDDB4: 1202F8FF 0000E408
	v_or_b32_e32 v124, 0x64006400, v206                        // 000000DDDDBC: 38F99CFF 64006400
	v_perm_b32 v33, v126, v157, 0xc040c00                      // 000000DDDDC4: D6440021 03FF3B7E 0C040C00
	v_perm_b32 v117, v126, v157, 0xc050c01                     // 000000DDDDD0: D6440075 03FF3B7E 0C050C01
	v_perm_b32 v115, v126, v157, 0xc070c03                     // 000000DDDDDC: D6440073 03FF3B7E 0C070C03
	scratch_store_b32 off, v3, off offset:232                  // 000000DDDDE8: DC6900E8 007C0300
	.long 0xcc0f4003                                           // 000000DDDDF0: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDDDF4: 1202FAFF 0000E408
	v_or_b32_e32 v125, 0x64006400, v203                        // 000000DDDDFC: 38FB96FF 64006400
	scratch_store_b32 off, v3, off offset:236                  // 000000DDDE04: DC6900EC 007C0300
	v_perm_b32 v3, v126, v157, 0xc060c02                       // 000000DDDE0C: D6440003 03FF3B7E 0C060C02
	v_and_b32_e32 v126, 0xf0f0f0f, v160                        // 000000DDDE18: 36FD40FF 0F0F0F0F
	scratch_store_b32 off, v3, off offset:844                  // 000000DDDE20: DC69034C 007C0300
	.long 0xcc0f4003                                           // 000000DDDE28: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDDE2C: 1202F8FF 0000E408
	v_or_b32_e32 v124, 0x64006400, v204                        // 000000DDDE34: 38F998FF 64006400
	v_perm_b32 v105, v126, v159, 0xc040c00                     // 000000DDDE3C: D6440069 03FF3F7E 0C040C00
	v_perm_b32 v24, v126, v159, 0xc050c01                      // 000000DDDE48: D6440018 03FF3F7E 0C050C01
	v_perm_b32 v114, v126, v159, 0xc060c02                     // 000000DDDE54: D6440072 03FF3F7E 0C060C02
	scratch_store_b32 off, v3, off offset:240                  // 000000DDDE60: DC6900F0 007C0300
	.long 0xcc0f4003                                           // 000000DDDE68: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDDE6C: 1202FAFF 0000E408
	v_or_b32_e32 v125, 0x64006400, v202                        // 000000DDDE74: 38FB94FF 64006400
	v_perm_b32 v118, v126, v159, 0xc070c03                     // 000000DDDE7C: D6440076 03FF3F7E 0C070C03
	v_and_b32_e32 v126, 0xf0f0f0f, v162                        // 000000DDDE88: 36FD44FF 0F0F0F0F
	scratch_store_b32 off, v3, off offset:244                  // 000000DDDE90: DC6900F4 007C0300
	.long 0xcc0f4003                                           // 000000DDDE98: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDDE9C: 1202F8FF 0000E408
	v_or_b32_e32 v124, 0x64006400, v200                        // 000000DDDEA4: 38F990FF 64006400
	v_perm_b32 v108, v126, v161, 0xc040c00                     // 000000DDDEAC: D644006C 03FF437E 0C040C00
	v_perm_b32 v92, v126, v161, 0xc050c01                      // 000000DDDEB8: D644005C 03FF437E 0C050C01
	v_perm_b32 v88, v126, v161, 0xc060c02                      // 000000DDDEC4: D6440058 03FF437E 0C060C02
	scratch_store_b32 off, v3, off offset:248                  // 000000DDDED0: DC6900F8 007C0300
	.long 0xcc0f4003                                           // 000000DDDED8: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDDEDC: 1202FAFF 0000E408
	v_or_b32_e32 v125, 0x64006400, v201                        // 000000DDDEE4: 38FB92FF 64006400
	scratch_store_b32 off, v3, off offset:252                  // 000000DDDEEC: DC6900FC 007C0300
	v_perm_b32 v3, v126, v161, 0xc070c03                       // 000000DDDEF4: D6440003 03FF437E 0C070C03
	v_and_b32_e32 v126, 0xf0f0f0f, v164                        // 000000DDDF00: 36FD48FF 0F0F0F0F
	scratch_store_b32 off, v3, off offset:848                  // 000000DDDF08: DC690350 007C0300
	v_perm_b32 v94, v126, v163, 0xc040c00                      // 000000DDDF10: D644005E 03FF477E 0C040C00
	v_perm_b32 v89, v126, v163, 0xc050c01                      // 000000DDDF1C: D6440059 03FF477E 0C050C01
	v_perm_b32 v93, v126, v163, 0xc060c02                      // 000000DDDF28: D644005D 03FF477E 0C060C02
	v_perm_b32 v106, v126, v163, 0xc070c03                     // 000000DDDF34: D644006A 03FF477E 0C070C03
	v_and_b32_e32 v126, 0xf0f0f0f, v166                        // 000000DDDF40: 36FD4CFF 0F0F0F0F
	.long 0xcc0f4003                                           // 000000DDDF48: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDDF4C: 1202F8FF 0000E408
	v_or_b32_e32 v124, 0x64006400, v198                        // 000000DDDF54: 38F98CFF 64006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DDDF5C: BF870003
	v_perm_b32 v100, v126, v165, 0xc040c00                     // 000000DDDF60: D6440064 03FF4B7E 0C040C00
	v_perm_b32 v101, v126, v165, 0xc050c01                     // 000000DDDF6C: D6440065 03FF4B7E 0C050C01
	v_perm_b32 v99, v126, v165, 0xc060c02                      // 000000DDDF78: D6440063 03FF4B7E 0C060C02
	v_perm_b32 v104, v126, v165, 0xc070c03                     // 000000DDDF84: D6440068 03FF4B7E 0C070C03
	v_and_b32_e32 v126, 0xf0f0f0f, v168                        // 000000DDDF90: 36FD50FF 0F0F0F0F
	scratch_store_b32 off, v3, off offset:256                  // 000000DDDF98: DC690100 007C0300
	.long 0xcc0f4003                                           // 000000DDDFA0: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDDFA4: 1202FAFF 0000E408
	v_or_b32_e32 v125, 0x64006400, v199                        // 000000DDDFAC: 38FB8EFF 64006400
	v_or_b32_e32 v22, 0x64006400, v99                          // 000000DDDFB4: 382CC6FF 64006400
	v_perm_b32 v23, v126, v167, 0xc040c00                      // 000000DDDFBC: D6440017 03FF4F7E 0C040C00
	v_perm_b32 v102, v126, v167, 0xc050c01                     // 000000DDDFC8: D6440066 03FF4F7E 0C050C01
	v_perm_b32 v107, v126, v167, 0xc060c02                     // 000000DDDFD4: D644006B 03FF4F7E 0C060C02
	v_perm_b32 v103, v126, v167, 0xc070c03                     // 000000DDDFE0: D6440067 03FF4F7E 0C070C03
	v_and_b32_e32 v126, 0xf0f0f0f, v170                        // 000000DDDFEC: 36FD54FF 0F0F0F0F
	scratch_store_b32 off, v3, off offset:260                  // 000000DDDFF4: DC690104 007C0300
	.long 0xcc0f4003                                           // 000000DDDFFC: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDE000: 1202F8FF 0000E408
	v_or_b32_e32 v124, 0x64006400, v196                        // 000000DDE008: 38F988FF 64006400
	.long 0xcc0f4016                                           // 000000DDE010: CC0F4016
	v_mul_i32_i24_e32 v1, 0xe408, v22                          // 000000DDE014: 12022CFF 0000E408
	v_perm_b32 v41, v126, v169, 0xc040c00                      // 000000DDE01C: D6440029 03FF537E 0C040C00
	v_perm_b32 v42, v126, v169, 0xc050c01                      // 000000DDE028: D644002A 03FF537E 0C050C01
	v_perm_b32 v90, v126, v169, 0xc060c02                      // 000000DDE034: D644005A 03FF537E 0C060C02
	v_perm_b32 v91, v126, v169, 0xc070c03                      // 000000DDE040: D644005B 03FF537E 0C070C03
	v_and_b32_e32 v126, 0xf0f0f0f, v172                        // 000000DDE04C: 36FD58FF 0F0F0F0F
	scratch_store_b32 off, v3, off offset:264                  // 000000DDE054: DC690108 007C0300
	.long 0xcc0f4003                                           // 000000DDE05C: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDE060: 1202FAFF 0000E408
	v_or_b32_e32 v125, 0x64006400, v197                        // 000000DDE068: 38FB8AFF 64006400
	v_perm_b32 v46, v126, v171, 0xc040c00                      // 000000DDE070: D644002E 03FF577E 0C040C00
	v_perm_b32 v49, v126, v171, 0xc050c01                      // 000000DDE07C: D6440031 03FF577E 0C050C01
	v_perm_b32 v50, v126, v171, 0xc060c02                      // 000000DDE088: D6440032 03FF577E 0C060C02
	v_perm_b32 v98, v126, v171, 0xc070c03                      // 000000DDE094: D6440062 03FF577E 0C070C03
	v_and_b32_e32 v126, 0xf0f0f0f, v174                        // 000000DDE0A0: 36FD5CFF 0F0F0F0F
	scratch_store_b32 off, v3, off offset:268                  // 000000DDE0A8: DC69010C 007C0300
	.long 0xcc0f4003                                           // 000000DDE0B0: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDE0B4: 1202F8FF 0000E408
	v_or_b32_e32 v124, 0x64006400, v194                        // 000000DDE0BC: 38F984FF 64006400
	v_or_b32_e32 v50, 0x64006400, v50                          // 000000DDE0C4: 386464FF 64006400
	v_perm_b32 v53, v126, v173, 0xc040c00                      // 000000DDE0CC: D6440035 03FF5B7E 0C040C00
	v_perm_b32 v54, v126, v173, 0xc050c01                      // 000000DDE0D8: D6440036 03FF5B7E 0C050C01
	v_perm_b32 v56, v126, v173, 0xc060c02                      // 000000DDE0E4: D6440038 03FF5B7E 0C060C02
	v_perm_b32 v57, v126, v173, 0xc070c03                      // 000000DDE0F0: D6440039 03FF5B7E 0C070C03
	v_and_b32_e32 v126, 0xf0f0f0f, v176                        // 000000DDE0FC: 36FD60FF 0F0F0F0F
	scratch_store_b32 off, v3, off offset:272                  // 000000DDE104: DC690110 007C0300
	.long 0xcc0f4003                                           // 000000DDE10C: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDE110: 1202FAFF 0000E408
	v_or_b32_e32 v125, 0x64006400, v195                        // 000000DDE118: 38FB86FF 64006400
	.long 0xcc0f4032                                           // 000000DDE120: CC0F4032
	v_mul_i32_i24_e32 v1, 0xe408, v50                          // 000000DDE124: 120264FF 0000E408
	v_perm_b32 v58, v126, v175, 0xc040c00                      // 000000DDE12C: D644003A 03FF5F7E 0C040C00
	v_perm_b32 v59, v126, v175, 0xc050c01                      // 000000DDE138: D644003B 03FF5F7E 0C050C01
	v_perm_b32 v81, v126, v175, 0xc060c02                      // 000000DDE144: D6440051 03FF5F7E 0C060C02
	v_perm_b32 v63, v126, v175, 0xc070c03                      // 000000DDE150: D644003F 03FF5F7E 0C070C03
	v_and_b32_e32 v126, 0xf0f0f0f, v67                         // 000000DDE15C: 36FC86FF 0F0F0F0F
	scratch_load_b32 v67, off, off offset:328                  // 000000DDE164: DC510148 437C0000
	scratch_store_b32 off, v3, off offset:276                  // 000000DDE16C: DC690114 007C0300
	.long 0xcc0f4003                                           // 000000DDE174: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDE178: 1202F8FF 0000E408
	v_or_b32_e32 v124, 0x64006400, v192                        // 000000DDE180: 38F980FF 64006400
	v_perm_b32 v64, v126, v177, 0xc050c01                      // 000000DDE188: D6440040 03FF637E 0C050C01
	v_perm_b32 v65, v126, v177, 0xc060c02                      // 000000DDE194: D6440041 03FF637E 0C060C02
	v_perm_b32 v70, v126, v177, 0xc070c03                      // 000000DDE1A0: D6440046 03FF637E 0C070C03
	scratch_store_b32 off, v3, off offset:280                  // 000000DDE1AC: DC690118 007C0300
	.long 0xcc0f4003                                           // 000000DDE1B4: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDE1B8: 1202FAFF 0000E408
	v_or_b32_e32 v125, 0x64006400, v193                        // 000000DDE1C0: 38FB82FF 64006400
	scratch_store_b32 off, v3, off offset:284                  // 000000DDE1C8: DC69011C 007C0300
	.long 0xcc0f4003                                           // 000000DDE1D0: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDE1D4: 1202F8FF 0000E408
	v_or_b32_e32 v124, 0x64006400, v190                        // 000000DDE1DC: 38F97CFF 64006400
	scratch_store_b32 off, v3, off offset:288                  // 000000DDE1E4: DC690120 007C0300
	.long 0xcc0f4003                                           // 000000DDE1EC: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDE1F0: 1202FAFF 0000E408
	v_or_b32_e32 v125, 0x64006400, v191                        // 000000DDE1F8: 38FB7EFF 64006400
	scratch_store_b32 off, v3, off offset:292                  // 000000DDE200: DC690124 007C0300
	.long 0xcc0f4003                                           // 000000DDE208: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDE20C: 1202F8FF 0000E408
	v_or_b32_e32 v124, 0x64006400, v188                        // 000000DDE214: 38F978FF 64006400
	scratch_store_b32 off, v3, off offset:296                  // 000000DDE21C: DC690128 007C0300
	.long 0xcc0f4003                                           // 000000DDE224: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDE228: 1202FAFF 0000E408
	v_or_b32_e32 v125, 0x64006400, v189                        // 000000DDE230: 38FB7AFF 64006400
	scratch_store_b32 off, v3, off offset:300                  // 000000DDE238: DC69012C 007C0300
	.long 0xcc0f4003                                           // 000000DDE240: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDE244: 1202F8FF 0000E408
	v_or_b32_e32 v124, 0x64006400, v186                        // 000000DDE24C: 38F974FF 64006400
	scratch_store_b32 off, v3, off offset:304                  // 000000DDE254: DC690130 007C0300
	.long 0xcc0f4003                                           // 000000DDE25C: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDE260: 1202FAFF 0000E408
	v_or_b32_e32 v125, 0x64006400, v187                        // 000000DDE268: 38FB76FF 64006400
	scratch_store_b32 off, v3, off offset:308                  // 000000DDE270: DC690134 007C0300
	.long 0xcc0f4003                                           // 000000DDE278: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDE27C: 1202F8FF 0000E408
	v_or_b32_e32 v124, 0x64006400, v185                        // 000000DDE284: 38F972FF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDE28C: BF870001
	.long 0xcc0f403d                                           // 000000DDE290: CC0F403D
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDE294: 1202F8FF 0000E408
	scratch_store_b32 off, v3, off offset:312                  // 000000DDE29C: DC690138 007C0300
	.long 0xcc0f4003                                           // 000000DDE2A4: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDE2A8: 1202FAFF 0000E408
	v_or_b32_e32 v125, 0x64006400, v183                        // 000000DDE2B0: 38FB6EFF 64006400
	v_or_b32_e32 v124, 0x64006400, v184                        // 000000DDE2B8: 38F970FF 64006400
	scratch_store_b32 off, v61, off offset:320                 // 000000DDE2C0: DC690140 007C3D00
	.long 0xcc0f403d                                           // 000000DDE2C8: CC0F403D
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDE2CC: 1202FAFF 0000E408
	scratch_store_b32 off, v3, off offset:316                  // 000000DDE2D4: DC69013C 007C0300
	v_perm_b32 v3, v126, v177, 0xc040c00                       // 000000DDE2DC: D6440003 03FF637E 0C040C00
	v_and_b32_e32 v126, 0xf0f0f0f, v244                        // 000000DDE2E8: 36FDE8FF 0F0F0F0F
	v_or_b32_e32 v125, 0x64006400, v181                        // 000000DDE2F0: 38FB6AFF 64006400
	scratch_store_b32 off, v61, off offset:324                 // 000000DDE2F8: DC690144 007C3D00
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DDE300: 380606FF 64006400
	v_perm_b32 v61, v126, v96, 0xc040c00                       // 000000DDE308: D644003D 03FEC17E 0C040C00
	v_perm_b32 v62, v126, v96, 0xc050c01                       // 000000DDE314: D644003E 03FEC17E 0C050C01
	v_perm_b32 v75, v126, v96, 0xc060c02                       // 000000DDE320: D644004B 03FEC17E 0C060C02
	v_perm_b32 v96, v126, v96, 0xc070c03                       // 000000DDE32C: D6440060 03FEC17E 0C070C03
	s_waitcnt vmcnt(0)                                         // 000000DDE338: BF8903F7
	v_and_b32_e32 v126, 0xf0f0f0f, v67                         // 000000DDE33C: 36FC86FF 0F0F0F0F
	.long 0xcc0f4043                                           // 000000DDE344: CC0F4043
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDE348: 1202F8FF 0000E408
	v_or_b32_e32 v124, 0x64006400, v180                        // 000000DDE350: 38F968FF 64006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DDE358: BF870003
	v_perm_b32 v68, v126, v66, 0xc050c01                       // 000000DDE35C: D6440044 03FE857E 0C050C01
	scratch_store_b32 off, v67, off offset:328                 // 000000DDE368: DC690148 007C4300
	.long 0xcc0f4043                                           // 000000DDE370: CC0F4043
	v_mul_i32_i24_e32 v1, 0xe408, v125                         // 000000DDE374: 1202FAFF 0000E408
	v_and_b32_e32 v125, 0xf0f0f0f, v71                         // 000000DDE37C: 36FA8EFF 0F0F0F0F
	v_perm_b32 v69, v126, v66, 0xc060c02                       // 000000DDE384: D6440045 03FE857E 0C060C02
	v_perm_b32 v82, v126, v66, 0xc070c03                       // 000000DDE390: D6440052 03FE857E 0C070C03
	scratch_store_b32 off, v67, off offset:332                 // 000000DDE39C: DC69014C 007C4300
	v_perm_b32 v71, v125, v35, 0xc040c00                       // 000000DDE3A4: D6440047 03FE477D 0C040C00
	v_perm_b32 v72, v125, v35, 0xc050c01                       // 000000DDE3B0: D6440048 03FE477D 0C050C01
	v_perm_b32 v73, v125, v35, 0xc060c02                       // 000000DDE3BC: D6440049 03FE477D 0C060C02
	v_perm_b32 v74, v125, v35, 0xc070c03                       // 000000DDE3C8: D644004A 03FE477D 0C070C03
	scratch_load_b32 v35, off, off offset:400                  // 000000DDE3D4: DC510190 237C0000
	v_perm_b32 v67, v126, v66, 0xc040c00                       // 000000DDE3DC: D6440043 03FE857E 0C040C00
	v_or_b32_e32 v66, 0x64006400, v182                         // 000000DDE3E8: 38856CFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDE3F0: BF870001
	.long 0xcc0f4042                                           // 000000DDE3F4: CC0F4042
	v_mul_i32_i24_e32 v1, 0xe408, v66                          // 000000DDE3F8: 120284FF 0000E408
	scratch_store_b32 off, v66, off offset:336                 // 000000DDE400: DC690150 007C4200
	.long 0xcc0f4042                                           // 000000DDE408: CC0F4042
	v_mul_i32_i24_e32 v1, 0xe408, v124                         // 000000DDE40C: 1202F8FF 0000E408
	scratch_load_b32 v124, off, off offset:484                 // 000000DDE414: DC5101E4 7C7C0000
	s_waitcnt vmcnt(1)                                         // 000000DDE41C: BF8907F7
	v_and_b32_e32 v35, 0xf0f0f0f, v35                          // 000000DDE420: 364646FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDE428: BF870001
	v_perm_b32 v80, v35, v16, 0xc040c00                        // 000000DDE42C: D6440050 03FE2123 0C040C00
	v_perm_b32 v77, v35, v16, 0xc050c01                        // 000000DDE438: D644004D 03FE2123 0C050C01
	v_perm_b32 v78, v35, v16, 0xc060c02                        // 000000DDE444: D644004E 03FE2123 0C060C02
	v_perm_b32 v79, v35, v16, 0xc070c03                        // 000000DDE450: D644004F 03FE2123 0C070C03
	scratch_load_b32 v16, off, off offset:356                  // 000000DDE45C: DC510164 107C0000
	s_waitcnt vmcnt(1)                                         // 000000DDE464: BF8907F7
	v_cmp_eq_u32_e32 vcc_lo, 0, v124                           // 000000DDE468: 7C94F880
	s_waitcnt vmcnt(0)                                         // 000000DDE46C: BF8903F7
	v_and_b32_e32 v16, 0xf0f0f0f, v16                          // 000000DDE470: 362020FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDE478: BF870001
	v_perm_b32 v76, v16, v15, 0xc040c00                        // 000000DDE47C: D644004C 03FE1F10 0C040C00
	v_perm_b32 v86, v16, v15, 0xc050c01                        // 000000DDE488: D6440056 03FE1F10 0C050C01
	v_perm_b32 v87, v16, v15, 0xc060c02                        // 000000DDE494: D6440057 03FE1F10 0C060C02
	v_perm_b32 v85, v16, v15, 0xc070c03                        // 000000DDE4A0: D6440055 03FE1F10 0C070C03
	s_clause 0x1                                               // 000000DDE4AC: BF850001
	scratch_load_b32 v15, off, off offset:352                  // 000000DDE4B0: DC510160 0F7C0000
	scratch_load_b32 v16, off, off offset:388                  // 000000DDE4B8: DC510184 107C0000
	s_waitcnt vmcnt(1)                                         // 000000DDE4C0: BF8907F7
	v_and_b32_e32 v15, 0xf0f0f0f, v15                          // 000000DDE4C4: 361E1EFF 0F0F0F0F
	s_waitcnt vmcnt(0)                                         // 000000DDE4CC: BF8903F7
	v_or_b32_e32 v16, 0x64006400, v16                          // 000000DDE4D0: 382020FF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DDE4D8: BF870002
	v_perm_b32 v83, v15, v13, 0xc040c00                        // 000000DDE4DC: D6440053 03FE1B0F 0C040C00
	v_perm_b32 v84, v15, v13, 0xc050c01                        // 000000DDE4E8: D6440054 03FE1B0F 0C050C01
	v_perm_b32 v113, v15, v13, 0xc060c02                       // 000000DDE4F4: D6440071 03FE1B0F 0C060C02
	v_perm_b32 v112, v15, v13, 0xc070c03                       // 000000DDE500: D6440070 03FE1B0F 0C070C03
	s_clause 0x1                                               // 000000DDE50C: BF850001
	scratch_load_b32 v13, off, off offset:348                  // 000000DDE510: DC51015C 0D7C0000
	scratch_load_b32 v15, off, off offset:368                  // 000000DDE518: DC510170 0F7C0000
	s_waitcnt vmcnt(1)                                         // 000000DDE520: BF8907F7
	v_and_b32_e32 v13, 0xf0f0f0f, v13                          // 000000DDE524: 361A1AFF 0F0F0F0F
	s_waitcnt vmcnt(0)                                         // 000000DDE52C: BF8903F7
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000DDE530: 381E1EFF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DDE538: BF870002
	v_perm_b32 v109, v13, v10, 0xc040c00                       // 000000DDE53C: D644006D 03FE150D 0C040C00
	v_perm_b32 v110, v13, v10, 0xc050c01                       // 000000DDE548: D644006E 03FE150D 0C050C01
	v_perm_b32 v111, v13, v10, 0xc060c02                       // 000000DDE554: D644006F 03FE150D 0C060C02
	v_perm_b32 v10, v13, v10, 0xc070c03                        // 000000DDE560: D644000A 03FE150D 0C070C03
	scratch_store_b32 off, v10, off offset:832                 // 000000DDE56C: DC690340 007C0A00
	scratch_load_b32 v10, off, off offset:344                  // 000000DDE574: DC510158 0A7C0000
	s_waitcnt vmcnt(0)                                         // 000000DDE57C: BF8903F7
	v_and_b32_e32 v10, 0xf0f0f0f, v10                          // 000000DDE580: 361414FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDE588: BF870001
	v_perm_b32 v13, v10, v9, 0xc040c00                         // 000000DDE58C: D644000D 03FE130A 0C040C00
	scratch_store_b32 off, v13, off offset:852                 // 000000DDE598: DC690354 007C0D00
	v_perm_b32 v13, v10, v9, 0xc050c01                         // 000000DDE5A0: D644000D 03FE130A 0C050C01
	scratch_store_b32 off, v13, off offset:856                 // 000000DDE5AC: DC690358 007C0D00
	v_perm_b32 v13, v10, v9, 0xc060c02                         // 000000DDE5B4: D644000D 03FE130A 0C060C02
	v_perm_b32 v9, v10, v9, 0xc070c03                          // 000000DDE5C0: D6440009 03FE130A 0C070C03
	scratch_load_b32 v10, off, off offset:360                  // 000000DDE5CC: DC510168 0A7C0000
	scratch_store_b32 off, v9, off offset:864                  // 000000DDE5D4: DC690360 007C0900
	v_cvt_f32_f16_e32 v9, v25                                  // 000000DDE5DC: 7E121719
	s_clause 0x1                                               // 000000DDE5E0: BF850001
	scratch_store_b32 off, v66, off offset:340                 // 000000DDE5E4: DC690154 007C4200
	scratch_store_b32 off, v13, off offset:860                 // 000000DDE5EC: DC69035C 007C0D00
	scratch_load_b32 v13, off, off offset:376                  // 000000DDE5F4: DC510178 0D7C0000
	scratch_store_b32 off, v9, off offset:344                  // 000000DDE5FC: DC690158 007C0900
	v_cvt_f32_f16_e32 v9, v153/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DDE604: 7E121799
	v_or_b32_e32 v25, 0x64006400, v23                          // 000000DDE608: 38322EFF 64006400
	scratch_store_b32 off, v9, off offset:348                  // 000000DDE610: DC69015C 007C0900
	v_cvt_f32_f16_e32 v9, v26                                  // 000000DDE618: 7E12171A
	scratch_store_b32 off, v9, off offset:352                  // 000000DDE61C: DC690160 007C0900
	v_cvt_f32_f16_e32 v9, v154/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DDE624: 7E12179A
	v_or_b32_e32 v26, 0x64006400, v41                          // 000000DDE628: 383452FF 64006400
	scratch_store_b32 off, v9, off offset:356                  // 000000DDE630: DC690164 007C0900
	scratch_load_b32 v9, off, off offset:396                   // 000000DDE638: DC51018C 097C0000
	s_waitcnt vmcnt(2)                                         // 000000DDE640: BF890BF7
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DDE644: 381414FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DDE64C: BF8700D1
	.long 0xcc0f400a                                           // 000000DDE650: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DDE654: 120214FF 0000E408
	s_waitcnt vmcnt(1)                                         // 000000DDE65C: BF8907F7
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DDE660: 381A1AFF 64006400
	s_waitcnt vmcnt(0)                                         // 000000DDE668: BF8903F7
	v_or_b32_e32 v9, 0x64006400, v9                            // 000000DDE66C: 381212FF 64006400
	.long 0xcc0f4009                                           // 000000DDE674: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DDE678: 120212FF 0000E408
	scratch_store_b32 off, v9, off offset:360                  // 000000DDE680: DC690168 007C0900
	scratch_load_b32 v9, off, off offset:364                   // 000000DDE688: DC51016C 097C0000
	scratch_store_b32 off, v10, off offset:364                 // 000000DDE690: DC69016C 007C0A00
	.long 0xcc0f400a                                           // 000000DDE698: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DDE69C: 12021AFF 0000E408
	scratch_load_b32 v13, off, off offset:380                  // 000000DDE6A4: DC51017C 0D7C0000
	scratch_store_b32 off, v10, off offset:368                 // 000000DDE6AC: DC690170 007C0A00
	scratch_load_b32 v10, off, off offset:372                  // 000000DDE6B4: DC510174 0A7C0000
	s_waitcnt vmcnt(2)                                         // 000000DDE6BC: BF890BF7
	v_or_b32_e32 v9, 0x64006400, v9                            // 000000DDE6C0: 381212FF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DDE6C8: BF8907F7
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DDE6CC: 381A1AFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000DDE6D4: BF8700B2
	.long 0xcc0f4009                                           // 000000DDE6D8: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DDE6DC: 120212FF 0000E408
	s_waitcnt vmcnt(0)                                         // 000000DDE6E4: BF8903F7
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DDE6E8: 381414FF 64006400
	.long 0xcc0f400a                                           // 000000DDE6F0: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DDE6F4: 120214FF 0000E408
	scratch_store_b32 off, v9, off offset:372                  // 000000DDE6FC: DC690174 007C0900
	.long 0xcc0f4009                                           // 000000DDE704: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DDE708: 12021EFF 0000E408
	scratch_load_b32 v15, off, off offset:384                  // 000000DDE710: DC510180 0F7C0000
	scratch_store_b32 off, v9, off offset:376                  // 000000DDE718: DC690178 007C0900
	scratch_load_b32 v9, off, off offset:392                   // 000000DDE720: DC510188 097C0000
	s_waitcnt vmcnt(1)                                         // 000000DDE728: BF8907F7
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000DDE72C: 381E1EFF 64006400
	s_waitcnt vmcnt(0)                                         // 000000DDE734: BF8903F7
	v_or_b32_e32 v9, 0x64006400, v9                            // 000000DDE738: 381212FF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDE740: BF870001
	.long 0xcc0f4009                                           // 000000DDE744: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DDE748: 120212FF 0000E408
	scratch_store_b32 off, v10, off offset:380                 // 000000DDE750: DC69017C 007C0A00
	v_or_b32_e32 v10, 0x64006400, v234                         // 000000DDE758: 3815D4FF 64006400
	scratch_store_b32 off, v9, off offset:384                  // 000000DDE760: DC690180 007C0900
	.long 0xcc0f4009                                           // 000000DDE768: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DDE76C: 12021AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v235                         // 000000DDE774: 381BD6FF 64006400
	scratch_store_b32 off, v9, off offset:388                  // 000000DDE77C: DC690184 007C0900
	.long 0xcc0f4009                                           // 000000DDE784: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DDE788: 12021EFF 0000E408
	v_or_b32_e32 v15, 0x64006400, v236                         // 000000DDE790: 381FD8FF 64006400
	scratch_store_b32 off, v9, off offset:392                  // 000000DDE798: DC690188 007C0900
	.long 0xcc0f4009                                           // 000000DDE7A0: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000DDE7A4: 120220FF 0000E408
	v_or_b32_e32 v16, 0x64006400, v239                         // 000000DDE7AC: 3821DEFF 64006400
	scratch_store_b32 off, v9, off offset:396                  // 000000DDE7B4: DC69018C 007C0900
	v_or_b32_e32 v9, 0x64006400, v233                          // 000000DDE7BC: 3813D2FF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDE7C4: BF870001
	.long 0xcc0f4009                                           // 000000DDE7C8: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DDE7CC: 120212FF 0000E408
	scratch_store_b32 off, v9, off offset:400                  // 000000DDE7D4: DC690190 007C0900
	.long 0xcc0f4009                                           // 000000DDE7DC: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DDE7E0: 120214FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v241                         // 000000DDE7E8: 3815E2FF 64006400
	scratch_store_b32 off, v9, off offset:404                  // 000000DDE7F0: DC690194 007C0900
	.long 0xcc0f4009                                           // 000000DDE7F8: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DDE7FC: 12021AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v246                         // 000000DDE804: 381BECFF 64006400
	scratch_store_b32 off, v9, off offset:408                  // 000000DDE80C: DC690198 007C0900
	.long 0xcc0f4009                                           // 000000DDE814: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DDE818: 12021EFF 0000E408
	v_or_b32_e32 v15, 0x64006400, v251                         // 000000DDE820: 381FF6FF 64006400
	.long 0xcc0f40fb                                           // 000000DDE828: CC0F40FB
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DDE82C: 120202FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v252                          // 000000DDE834: 3803F8FF 64006400
	scratch_store_b32 off, v9, off offset:412                  // 000000DDE83C: DC69019C 007C0900
	.long 0xcc0f4009                                           // 000000DDE844: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000DDE848: 120220FF 0000E408
	v_or_b32_e32 v16, 0x64006400, v255                         // 000000DDE850: 3821FEFF 64006400
	.long 0xcc0f40fc                                           // 000000DDE858: CC0F40FC
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DDE85C: 120202FF 0000E408
	.long 0xcc0f40ff                                           // 000000DDE864: CC0F40FF
	v_mul_i32_i24_e32 v1, 0xe408, v0                           // 000000DDE868: 120200FF 0000E408
	scratch_load_b32 v1, off, off offset:824                   // 000000DDE870: DC510338 017C0000
	scratch_store_b32 off, v9, off offset:416                  // 000000DDE878: DC6901A0 007C0900
	v_or_b32_e32 v9, 0x64006400, v240                          // 000000DDE880: 3813E0FF 64006400
	scratch_load_b32 v0, off, off offset:820                   // 000000DDE888: DC510334 007C0000
	.long 0xcc0f4009                                           // 000000DDE890: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DDE894: 120212FF 0000E408
	scratch_store_b32 off, v9, off offset:420                  // 000000DDE89C: DC6901A4 007C0900
	.long 0xcc0f4009                                           // 000000DDE8A4: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DDE8A8: 120214FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v20                          // 000000DDE8B0: 381428FF 64006400
	scratch_store_b32 off, v9, off offset:424                  // 000000DDE8B8: DC6901A8 007C0900
	.long 0xcc0f4009                                           // 000000DDE8C0: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DDE8C4: 12021AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v21                          // 000000DDE8CC: 381A2AFF 64006400
	scratch_store_b32 off, v9, off offset:428                  // 000000DDE8D4: DC6901AC 007C0900
	.long 0xcc0f4009                                           // 000000DDE8DC: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DDE8E0: 12021EFF 0000E408
	scratch_store_b32 off, v9, off offset:432                  // 000000DDE8E8: DC6901B0 007C0900
	.long 0xcc0f4009                                           // 000000DDE8F0: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000DDE8F4: 120220FF 0000E408
	scratch_store_b32 off, v9, off offset:436                  // 000000DDE8FC: DC6901B4 007C0900
	v_or_b32_e32 v9, 0x64006400, v19                           // 000000DDE904: 381226FF 64006400
	v_or_b32_e32 v19, 0x64006400, v106                         // 000000DDE90C: 3826D4FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DDE914: BF8701A2
	.long 0xcc0f4002                                           // 000000DDE918: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DDE91C: 120212FF 0000E408
	v_or_b32_e32 v9, 0x64006400, v28                           // 000000DDE924: 381238FF 64006400
	.long 0xcc0f4013                                           // 000000DDE92C: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 000000DDE930: 120226FF 0000E408
	scratch_store_b32 off, v2, off offset:448                  // 000000DDE938: DC6901C0 007C0200
	.long 0xcc0f4002                                           // 000000DDE940: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DDE944: 120214FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v31                          // 000000DDE94C: 38143EFF 64006400
	.long 0xcc0f407d                                           // 000000DDE954: CC0F407D
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DDE958: 120212FF 0000E408
	v_or_b32_e32 v9, 0x64006400, v34                           // 000000DDE960: 381244FF 64006400
	scratch_store_b32 off, v2, off offset:452                  // 000000DDE968: DC6901C4 007C0200
	.long 0xcc0f4002                                           // 000000DDE970: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DDE974: 12021AFF 0000E408
	.long 0xcc0f407e                                           // 000000DDE97C: CC0F407E
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DDE980: 120214FF 0000E408
	v_or_b32_e32 v13, 0x64006400, v92                          // 000000DDE988: 381AB8FF 64006400
	scratch_store_b32 off, v2, off offset:456                  // 000000DDE990: DC6901C8 007C0200
	v_or_b32_e32 v2, 0x64006400, v5                            // 000000DDE998: 38040AFF 64006400
	v_or_b32_e32 v5, 0x64006400, v27                           // 000000DDE9A0: 380A36FF 64006400
	.long 0xcc0f400d                                           // 000000DDE9A8: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DDE9AC: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DDE9B4: BF870003
	.long 0xcc0f4002                                           // 000000DDE9B8: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDE9BC: 120204FF 0000E408
	scratch_store_b32 off, v2, off offset:460                  // 000000DDE9C4: DC6901CC 007C0200
	.long 0xcc0f4002                                           // 000000DDE9CC: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDE9D0: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v7                            // 000000DDE9D8: 38080EFF 64006400
	v_or_b32_e32 v7, 0x64006400, v43                           // 000000DDE9E0: 380E56FF 64006400
	scratch_store_b32 off, v2, off offset:464                  // 000000DDE9E8: DC6901D0 007C0200
	.long 0xcc0f4002                                           // 000000DDE9F0: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDE9F4: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v8                            // 000000DDE9FC: 380A10FF 64006400
	.long 0xcc0f4080                                           // 000000DDEA04: CC0F4080
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDEA08: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v14                           // 000000DDEA10: 38081CFF 64006400
	.long 0xcc0f4083                                           // 000000DDEA18: CC0F4083
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDEA1C: 12020EFF 0000E408
	scratch_store_b32 off, v2, off offset:468                  // 000000DDEA24: DC6901D4 007C0200
	v_or_b32_e32 v2, 0x64006400, v6                            // 000000DDEA2C: 38040CFF 64006400
	v_or_b32_e32 v6, 0x64006400, v11                           // 000000DDEA34: 380C16FF 64006400
	.long 0xcc0f4081                                           // 000000DDEA3C: CC0F4081
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDEA40: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v17                           // 000000DDEA48: 380A22FF 64006400
	.long 0xcc0f4085                                           // 000000DDEA50: CC0F4085
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDEA54: 120208FF 0000E408
	.long 0xcc0f407f                                           // 000000DDEA5C: CC0F407F
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDEA60: 120204FF 0000E408
	.long 0xcc0f4082                                           // 000000DDEA68: CC0F4082
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDEA6C: 12020CFF 0000E408
	v_or_b32_e32 v2, 0x64006400, v12                           // 000000DDEA74: 380418FF 64006400
	v_or_b32_e32 v6, 0x64006400, v44                           // 000000DDEA7C: 380C58FF 64006400
	.long 0xcc0f4086                                           // 000000DDEA84: CC0F4086
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDEA88: 12020AFF 0000E408
	v_or_b32_e32 v4, 0x64006400, v18                           // 000000DDEA90: 380824FF 64006400
	v_or_b32_e32 v5, 0x64006400, v47                           // 000000DDEA98: 380A5EFF 64006400
	.long 0xcc0f4084                                           // 000000DDEAA0: CC0F4084
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDEAA4: 120204FF 0000E408
	.long 0xcc0f4087                                           // 000000DDEAAC: CC0F4087
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDEAB0: 12020CFF 0000E408
	v_or_b32_e32 v2, 0x64006400, v36                           // 000000DDEAB8: 380448FF 64006400
	v_or_b32_e32 v6, 0x64006400, v48                           // 000000DDEAC0: 380C60FF 64006400
	.long 0xcc0f408a                                           // 000000DDEAC8: CC0F408A
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDEACC: 120208FF 0000E408
	.long 0xcc0f408b                                           // 000000DDEAD4: CC0F408B
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDEAD8: 12020AFF 0000E408
	v_or_b32_e32 v4, 0x64006400, v52                           // 000000DDEAE0: 380868FF 64006400
	.long 0xcc0f4089                                           // 000000DDEAE8: CC0F4089
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDEAEC: 120204FF 0000E408
	.long 0xcc0f408c                                           // 000000DDEAF4: CC0F408C
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDEAF8: 12020CFF 0000E408
	v_or_b32_e32 v2, 0x64006400, v37                           // 000000DDEB00: 38044AFF 64006400
	v_or_b32_e32 v5, 0x64006400, v55                           // 000000DDEB08: 380A6EFF 64006400
	v_or_b32_e32 v6, 0x64006400, v60                           // 000000DDEB10: 380C78FF 64006400
	.long 0xcc0f408f                                           // 000000DDEB18: CC0F408F
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDEB1C: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v40                           // 000000DDEB24: 380850FF 64006400
	.long 0xcc0f408e                                           // 000000DDEB2C: CC0F408E
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDEB30: 120204FF 0000E408
	.long 0xcc0f4090                                           // 000000DDEB38: CC0F4090
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDEB3C: 12020AFF 0000E408
	.long 0xcc0f4091                                           // 000000DDEB44: CC0F4091
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDEB48: 12020CFF 0000E408
	v_or_b32_e32 v2, 0x64006400, v39                           // 000000DDEB50: 38044EFF 64006400
	v_or_b32_e32 v5, 0x64006400, v95                           // 000000DDEB58: 380ABEFF 64006400
	v_or_b32_e32 v6, 0x64006400, v97                           // 000000DDEB60: 380CC2FF 64006400
	.long 0xcc0f4094                                           // 000000DDEB68: CC0F4094
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDEB6C: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v242                          // 000000DDEB74: 3809E4FF 64006400
	.long 0xcc0f4093                                           // 000000DDEB7C: CC0F4093
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDEB80: 120204FF 0000E408
	.long 0xcc0f4095                                           // 000000DDEB88: CC0F4095
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDEB8C: 12020AFF 0000E408
	.long 0xcc0f4096                                           // 000000DDEB94: CC0F4096
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDEB98: 12020CFF 0000E408
	v_or_b32_e32 v2, 0x64006400, v238                          // 000000DDEBA0: 3805DCFF 64006400
	v_or_b32_e32 v5, 0x64006400, v243                          // 000000DDEBA8: 380BE6FF 64006400
	v_or_b32_e32 v6, 0x64006400, v237                          // 000000DDEBB0: 380DDAFF 64006400
	.long 0xcc0f4099                                           // 000000DDEBB8: CC0F4099
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDEBBC: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v250                          // 000000DDEBC4: 3809F4FF 64006400
	.long 0xcc0f4098                                           // 000000DDEBCC: CC0F4098
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDEBD0: 120204FF 0000E408
	.long 0xcc0f409a                                           // 000000DDEBD8: CC0F409A
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDEBDC: 12020AFF 0000E408
	.long 0xcc0f409b                                           // 000000DDEBE4: CC0F409B
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDEBE8: 12020CFF 0000E408
	v_or_b32_e32 v2, 0x64006400, v249                          // 000000DDEBF0: 3805F2FF 64006400
	v_or_b32_e32 v5, 0x64006400, v245                          // 000000DDEBF8: 380BEAFF 64006400
	v_or_b32_e32 v6, 0x64006400, v248                          // 000000DDEC00: 380DF0FF 64006400
	.long 0xcc0f409e                                           // 000000DDEC08: CC0F409E
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDEC0C: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:756                   // 000000DDEC14: DC5102F4 047C0000
	.long 0xcc0f409d                                           // 000000DDEC1C: CC0F409D
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDEC20: 120204FF 0000E408
	.long 0xcc0f409f                                           // 000000DDEC28: CC0F409F
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDEC2C: 12020AFF 0000E408
	.long 0xcc0f40a0                                           // 000000DDEC34: CC0F40A0
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDEC38: 12020CFF 0000E408
	s_clause 0x2                                               // 000000DDEC40: BF850002
	scratch_load_b32 v2, off, off offset:752                   // 000000DDEC44: DC5102F0 027C0000
	scratch_load_b32 v5, off, off offset:760                   // 000000DDEC4C: DC5102F8 057C0000
	scratch_load_b32 v6, off, off offset:764                   // 000000DDEC54: DC5102FC 067C0000
	v_or_b32_e32 v7, 0x64006400, v45                           // 000000DDEC5C: 380E5AFF 64006400
	v_or_b32_e32 v8, 0x64006400, v120                          // 000000DDEC64: 3810F0FF 64006400
	v_or_b32_e32 v11, 0x64006400, v33                          // 000000DDEC6C: 381642FF 64006400
	v_or_b32_e32 v45, 0x64006400, v42                          // 000000DDEC74: 385A54FF 64006400
	.long 0xcc0f402c                                           // 000000DDEC7C: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DDEC80: 120234FF 0000E408
	.long 0xcc0f4088                                           // 000000DDEC88: CC0F4088
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDEC8C: 12020EFF 0000E408
	v_or_b32_e32 v7, 0x64006400, v51                           // 000000DDEC94: 380E66FF 64006400
	.long 0xcc0f4024                                           // 000000DDEC9C: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DDECA0: 120216FF 0000E408
	v_or_b32_e32 v11, 0x64006400, v24                          // 000000DDECA8: 381630FF 64006400
	v_or_b32_e32 v24, 0x64006400, v104                         // 000000DDECB0: 3830D0FF 64006400
	v_or_b32_e32 v26, 0x64006400, v49                          // 000000DDECB8: 383462FF 64006400
	.long 0xcc0f408d                                           // 000000DDECC0: CC0F408D
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDECC4: 12020EFF 0000E408
	v_or_b32_e32 v7, 0x64006400, v178                          // 000000DDECCC: 380F64FF 64006400
	v_or_b32_e32 v55, 0x64006400, v57                          // 000000DDECD4: 386E72FF 64006400
	.long 0xcc0f4017                                           // 000000DDECDC: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000DDECE0: 120230FF 0000E408
	.long 0xcc0f4018                                           // 000000DDECE8: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DDECEC: 120232FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v103                         // 000000DDECF4: 3832CEFF 64006400
	.long 0xcc0f4092                                           // 000000DDECFC: CC0F4092
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDED00: 12020EFF 0000E408
	v_or_b32_e32 v7, 0x64006400, v38                           // 000000DDED08: 380E4CFF 64006400
	.long 0xcc0f4031                                           // 000000DDED10: CC0F4031
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DDED14: 120234FF 0000E408
	v_or_b32_e32 v26, 0x64006400, v56                          // 000000DDED1C: 383470FF 64006400
	.long 0xcc0f402b                                           // 000000DDED24: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DDED28: 120232FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v46                          // 000000DDED30: 38325CFF 64006400
	.long 0xcc0f4097                                           // 000000DDED38: CC0F4097
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDED3C: 12020EFF 0000E408
	v_or_b32_e32 v7, 0x64006400, v179                          // 000000DDED44: 380F66FF 64006400
	.long 0xcc0f403c                                           // 000000DDED4C: CC0F403C
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DDED50: 120206FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v64                           // 000000DDED58: 380680FF 64006400
	.long 0xcc0f4030                                           // 000000DDED60: CC0F4030
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DDED64: 120232FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v54                          // 000000DDED6C: 38326CFF 64006400
	.long 0xcc0f409c                                           // 000000DDED74: CC0F409C
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDED78: 12020EFF 0000E408
	v_or_b32_e32 v7, 0x64006400, v247                          // 000000DDED80: 380FEEFF 64006400
	.long 0xcc0f4036                                           // 000000DDED88: CC0F4036
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DDED8C: 120234FF 0000E408
	v_or_b32_e32 v26, 0x64006400, v63                          // 000000DDED94: 38347EFF 64006400
	v_or_b32_e32 v14, 0x64006400, v88                          // 000000DDED9C: 381CB0FF 64006400
	v_or_b32_e32 v17, 0x64006400, v89                          // 000000DDEDA4: 3822B2FF 64006400
	.long 0xcc0f40a1                                           // 000000DDEDAC: CC0F40A1
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDEDB0: 12020EFF 0000E408
	scratch_load_b32 v7, off, off offset:768                   // 000000DDEDB8: DC510300 077C0000
	v_or_b32_e32 v12, 0x64006400, v108                         // 000000DDEDC0: 3818D8FF 64006400
	v_or_b32_e32 v18, 0x64006400, v93                          // 000000DDEDC8: 3824BAFF 64006400
	.long 0xcc0f400e                                           // 000000DDEDD0: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DDEDD4: 12021CFF 0000E408
	.long 0xcc0f4011                                           // 000000DDEDDC: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DDEDE0: 120222FF 0000E408
	.long 0xcc0f402d                                           // 000000DDEDE8: CC0F402D
	v_mul_i32_i24_e32 v1, 0xe408, v45                          // 000000DDEDEC: 12025AFF 0000E408
	.long 0xcc0f400c                                           // 000000DDEDF4: CC0F400C
	v_mul_i32_i24_e32 v1, 0xe408, v12                          // 000000DDEDF8: 120218FF 0000E408
	.long 0xcc0f4012                                           // 000000DDEE00: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DDEE04: 120224FF 0000E408
	.long 0xcc0f4037                                           // 000000DDEE0C: CC0F4037
	v_mul_i32_i24_e32 v1, 0xe408, v55                          // 000000DDEE10: 12026EFF 0000E408
	s_waitcnt vmcnt(5)                                         // 000000DDEE18: BF8917F7
	v_or_b32_e32 v0, 0x64006400, v0                            // 000000DDEE1C: 380000FF 64006400
	s_waitcnt vmcnt(4)                                         // 000000DDEE24: BF8913F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDEE28: 380808FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDEE30: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDEE34: 380404FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DDEE3C: BF890BF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDEE40: 380A0AFF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DDEE48: BF8907F7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDEE4C: 380C0CFF 64006400
	.long 0xcc0f40a3                                           // 000000DDEE54: CC0F40A3
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDEE58: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:736                   // 000000DDEE60: DC5102E0 047C0000
	.long 0xcc0f40a2                                           // 000000DDEE68: CC0F40A2
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDEE6C: 120204FF 0000E408
	.long 0xcc0f40a4                                           // 000000DDEE74: CC0F40A4
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDEE78: 12020AFF 0000E408
	.long 0xcc0f40a5                                           // 000000DDEE80: CC0F40A5
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDEE84: 12020CFF 0000E408
	s_clause 0x2                                               // 000000DDEE8C: BF850002
	scratch_load_b32 v2, off, off offset:732                   // 000000DDEE90: DC5102DC 027C0000
	scratch_load_b32 v5, off, off offset:740                   // 000000DDEE98: DC5102E4 057C0000
	scratch_load_b32 v6, off, off offset:744                   // 000000DDEEA0: DC5102E8 067C0000
	s_waitcnt vmcnt(4)                                         // 000000DDEEA8: BF8913F7
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DDEEAC: 380E0EFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDEEB4: BF870001
	.long 0xcc0f40a6                                           // 000000DDEEB8: CC0F40A6
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDEEBC: 12020EFF 0000E408
	scratch_load_b32 v7, off, off offset:748                   // 000000DDEEC4: DC5102EC 077C0000
	s_waitcnt vmcnt(4)                                         // 000000DDEECC: BF8913F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDEED0: 380808FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDEED8: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDEEDC: 380404FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DDEEE4: BF890BF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDEEE8: 380A0AFF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DDEEF0: BF8907F7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDEEF4: 380C0CFF 64006400
	.long 0xcc0f40a8                                           // 000000DDEEFC: CC0F40A8
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDEF00: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:652                   // 000000DDEF08: DC51028C 047C0000
	.long 0xcc0f40a7                                           // 000000DDEF10: CC0F40A7
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDEF14: 120204FF 0000E408
	.long 0xcc0f40a9                                           // 000000DDEF1C: CC0F40A9
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDEF20: 12020AFF 0000E408
	.long 0xcc0f40aa                                           // 000000DDEF28: CC0F40AA
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDEF2C: 12020CFF 0000E408
	s_clause 0x2                                               // 000000DDEF34: BF850002
	scratch_load_b32 v2, off, off offset:648                   // 000000DDEF38: DC510288 027C0000
	scratch_load_b32 v5, off, off offset:656                   // 000000DDEF40: DC510290 057C0000
	scratch_load_b32 v6, off, off offset:660                   // 000000DDEF48: DC510294 067C0000
	s_waitcnt vmcnt(4)                                         // 000000DDEF50: BF8913F7
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DDEF54: 380E0EFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDEF5C: BF870001
	.long 0xcc0f40ab                                           // 000000DDEF60: CC0F40AB
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDEF64: 12020EFF 0000E408
	scratch_load_b32 v7, off, off offset:664                   // 000000DDEF6C: DC510298 077C0000
	s_waitcnt vmcnt(4)                                         // 000000DDEF74: BF8913F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDEF78: 380808FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDEF80: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDEF84: 380404FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DDEF8C: BF890BF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDEF90: 380A0AFF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DDEF98: BF8907F7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDEF9C: 380C0CFF 64006400
	.long 0xcc0f40ad                                           // 000000DDEFA4: CC0F40AD
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDEFA8: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:552                   // 000000DDEFB0: DC510228 047C0000
	.long 0xcc0f40ac                                           // 000000DDEFB8: CC0F40AC
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDEFBC: 120204FF 0000E408
	.long 0xcc0f40ae                                           // 000000DDEFC4: CC0F40AE
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDEFC8: 12020AFF 0000E408
	.long 0xcc0f40af                                           // 000000DDEFD0: CC0F40AF
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDEFD4: 12020CFF 0000E408
	s_clause 0x2                                               // 000000DDEFDC: BF850002
	scratch_load_b32 v2, off, off offset:548                   // 000000DDEFE0: DC510224 027C0000
	scratch_load_b32 v5, off, off offset:556                   // 000000DDEFE8: DC51022C 057C0000
	scratch_load_b32 v6, off, off offset:560                   // 000000DDEFF0: DC510230 067C0000
	s_waitcnt vmcnt(4)                                         // 000000DDEFF8: BF8913F7
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DDEFFC: 380E0EFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDF004: BF870001
	.long 0xcc0f40b0                                           // 000000DDF008: CC0F40B0
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDF00C: 12020EFF 0000E408
	scratch_load_b32 v7, off, off offset:564                   // 000000DDF014: DC510234 077C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF01C: BF8913F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDF020: 380808FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDF028: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDF02C: 380404FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DDF034: BF890BF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDF038: 380A0AFF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DDF040: BF8907F7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDF044: 380C0CFF 64006400
	.long 0xcc0f40b2                                           // 000000DDF04C: CC0F40B2
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDF050: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:492                   // 000000DDF058: DC5101EC 047C0000
	.long 0xcc0f40b1                                           // 000000DDF060: CC0F40B1
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDF064: 120204FF 0000E408
	.long 0xcc0f40b3                                           // 000000DDF06C: CC0F40B3
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDF070: 12020AFF 0000E408
	.long 0xcc0f40b4                                           // 000000DDF078: CC0F40B4
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDF07C: 12020CFF 0000E408
	s_clause 0x2                                               // 000000DDF084: BF850002
	scratch_load_b32 v2, off, off offset:488                   // 000000DDF088: DC5101E8 027C0000
	scratch_load_b32 v5, off, off offset:496                   // 000000DDF090: DC5101F0 057C0000
	scratch_load_b32 v6, off, off offset:500                   // 000000DDF098: DC5101F4 067C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF0A0: BF8913F7
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DDF0A4: 380E0EFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDF0AC: BF870001
	.long 0xcc0f40b5                                           // 000000DDF0B0: CC0F40B5
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDF0B4: 12020EFF 0000E408
	scratch_load_b32 v7, off, off offset:504                   // 000000DDF0BC: DC5101F8 077C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF0C4: BF8913F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDF0C8: 380808FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDF0D0: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDF0D4: 380404FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DDF0DC: BF890BF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDF0E0: 380A0AFF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DDF0E8: BF8907F7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDF0EC: 380C0CFF 64006400
	.long 0xcc0f40b7                                           // 000000DDF0F4: CC0F40B7
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDF0F8: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:512                   // 000000DDF100: DC510200 047C0000
	.long 0xcc0f40b6                                           // 000000DDF108: CC0F40B6
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDF10C: 120204FF 0000E408
	.long 0xcc0f40b8                                           // 000000DDF114: CC0F40B8
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDF118: 12020AFF 0000E408
	.long 0xcc0f40b9                                           // 000000DDF120: CC0F40B9
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDF124: 12020CFF 0000E408
	s_clause 0x2                                               // 000000DDF12C: BF850002
	scratch_load_b32 v2, off, off offset:508                   // 000000DDF130: DC5101FC 027C0000
	scratch_load_b32 v5, off, off offset:516                   // 000000DDF138: DC510204 057C0000
	scratch_load_b32 v6, off, off offset:520                   // 000000DDF140: DC510208 067C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF148: BF8913F7
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DDF14C: 380E0EFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDF154: BF870001
	.long 0xcc0f40ba                                           // 000000DDF158: CC0F40BA
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDF15C: 12020EFF 0000E408
	scratch_load_b32 v7, off, off offset:568                   // 000000DDF164: DC510238 077C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF16C: BF8913F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDF170: 380808FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDF178: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDF17C: 380404FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DDF184: BF890BF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDF188: 380A0AFF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DDF190: BF8907F7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDF194: 380C0CFF 64006400
	.long 0xcc0f40bc                                           // 000000DDF19C: CC0F40BC
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDF1A0: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:528                   // 000000DDF1A8: DC510210 047C0000
	.long 0xcc0f40bb                                           // 000000DDF1B0: CC0F40BB
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDF1B4: 120204FF 0000E408
	.long 0xcc0f40bd                                           // 000000DDF1BC: CC0F40BD
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDF1C0: 12020AFF 0000E408
	.long 0xcc0f40be                                           // 000000DDF1C8: CC0F40BE
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDF1CC: 12020CFF 0000E408
	s_clause 0x2                                               // 000000DDF1D4: BF850002
	scratch_load_b32 v2, off, off offset:524                   // 000000DDF1D8: DC51020C 027C0000
	scratch_load_b32 v5, off, off offset:532                   // 000000DDF1E0: DC510214 057C0000
	scratch_load_b32 v6, off, off offset:572                   // 000000DDF1E8: DC51023C 067C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF1F0: BF8913F7
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DDF1F4: 380E0EFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDF1FC: BF870001
	.long 0xcc0f40bf                                           // 000000DDF200: CC0F40BF
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDF204: 12020EFF 0000E408
	scratch_load_b32 v7, off, off offset:576                   // 000000DDF20C: DC510240 077C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF214: BF8913F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDF218: 380808FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDF220: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDF224: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DDF22C: BF870002
	.long 0xcc0f40c1                                           // 000000DDF230: CC0F40C1
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDF234: 120208FF 0000E408
	s_waitcnt vmcnt(1)                                         // 000000DDF23C: BF8907F7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDF240: 380C0CFF 64006400
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDF248: 380A0AFF 64006400
	.long 0xcc0f40c0                                           // 000000DDF250: CC0F40C0
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDF254: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:536                   // 000000DDF25C: DC510218 027C0000
	.long 0xcc0f40c3                                           // 000000DDF264: CC0F40C3
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDF268: 12020CFF 0000E408
	s_clause 0x1                                               // 000000DDF270: BF850001
	scratch_load_b32 v6, off, off offset:584                   // 000000DDF274: DC510248 067C0000
	scratch_load_b32 v4, off, off offset:540                   // 000000DDF27C: DC51021C 047C0000
	.long 0xcc0f40c2                                           // 000000DDF284: CC0F40C2
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDF288: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:580                   // 000000DDF290: DC510244 057C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF298: BF8913F7
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DDF29C: 380E0EFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDF2A4: BF870001
	.long 0xcc0f40c4                                           // 000000DDF2A8: CC0F40C4
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDF2AC: 12020EFF 0000E408
	scratch_load_b32 v7, off, off offset:588                   // 000000DDF2B4: DC51024C 077C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF2BC: BF8913F7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDF2C0: 380404FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDF2C8: BF890FF7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDF2CC: 380C0CFF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DDF2D4: BF890BF7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDF2D8: 380808FF 64006400
	.long 0xcc0f40c5                                           // 000000DDF2E0: CC0F40C5
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDF2E4: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DDF2EC: BF870193
	.long 0xcc0f40c8                                           // 000000DDF2F0: CC0F40C8
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDF2F4: 12020CFF 0000E408
	.long 0xcc0f40c6                                           // 000000DDF2FC: CC0F40C6
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDF300: 120208FF 0000E408
	s_clause 0x2                                               // 000000DDF308: BF850002
	scratch_load_b32 v4, off, off offset:592                   // 000000DDF30C: DC510250 047C0000
	scratch_load_b32 v6, off, off offset:600                   // 000000DDF314: DC510258 067C0000
	scratch_load_b32 v2, off, off offset:544                   // 000000DDF31C: DC510220 027C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF324: BF8913F7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDF328: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DDF330: BF8700C1
	.long 0xcc0f40c7                                           // 000000DDF334: CC0F40C7
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDF338: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:596                   // 000000DDF340: DC510254 057C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF348: BF8913F7
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DDF34C: 380E0EFF 64006400
	.long 0xcc0f40c9                                           // 000000DDF354: CC0F40C9
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDF358: 12020EFF 0000E408
	scratch_load_b32 v7, off, off offset:604                   // 000000DDF360: DC51025C 077C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF368: BF8913F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDF36C: 380808FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDF374: BF890FF7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDF378: 380C0CFF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DDF380: BF890BF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDF384: 380404FF 64006400
	.long 0xcc0f40cb                                           // 000000DDF38C: CC0F40CB
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDF390: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:612                   // 000000DDF398: DC510264 047C0000
	.long 0xcc0f40ca                                           // 000000DDF3A0: CC0F40CA
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDF3A4: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:608                   // 000000DDF3AC: DC510260 027C0000
	.long 0xcc0f40cd                                           // 000000DDF3B4: CC0F40CD
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDF3B8: 12020CFF 0000E408
	scratch_load_b32 v6, off, off offset:620                   // 000000DDF3C0: DC51026C 067C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF3C8: BF8913F7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDF3CC: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DDF3D4: BF8700C1
	.long 0xcc0f40cc                                           // 000000DDF3D8: CC0F40CC
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDF3DC: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:616                   // 000000DDF3E4: DC510268 057C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF3EC: BF8913F7
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DDF3F0: 380E0EFF 64006400
	.long 0xcc0f40ce                                           // 000000DDF3F8: CC0F40CE
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDF3FC: 12020EFF 0000E408
	scratch_load_b32 v7, off, off offset:668                   // 000000DDF404: DC51029C 077C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF40C: BF8913F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDF410: 380808FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDF418: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDF41C: 380404FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DDF424: BF890BF7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDF428: 380C0CFF 64006400
	.long 0xcc0f40d0                                           // 000000DDF430: CC0F40D0
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDF434: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:628                   // 000000DDF43C: DC510274 047C0000
	.long 0xcc0f40cf                                           // 000000DDF444: CC0F40CF
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDF448: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:624                   // 000000DDF450: DC510270 027C0000
	.long 0xcc0f40d2                                           // 000000DDF458: CC0F40D2
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDF45C: 12020CFF 0000E408
	scratch_load_b32 v6, off, off offset:672                   // 000000DDF464: DC5102A0 067C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF46C: BF8913F7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDF470: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DDF478: BF8700C1
	.long 0xcc0f40d1                                           // 000000DDF47C: CC0F40D1
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDF480: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:632                   // 000000DDF488: DC510278 057C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF490: BF8913F7
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DDF494: 380E0EFF 64006400
	.long 0xcc0f40d3                                           // 000000DDF49C: CC0F40D3
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDF4A0: 12020EFF 0000E408
	v_or_b32_e32 v7, 0x64006400, v231                          // 000000DDF4A8: 380FCEFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDF4B0: BF870001
	.long 0xcc0f40d8                                           // 000000DDF4B4: CC0F40D8
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDF4B8: 12020EFF 0000E408
	scratch_load_b32 v7, off, off offset:680                   // 000000DDF4C0: DC5102A8 077C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF4C8: BF8913F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDF4CC: 380808FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDF4D4: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDF4D8: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DDF4E0: BF870002
	.long 0xcc0f40d5                                           // 000000DDF4E4: CC0F40D5
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDF4E8: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:640                   // 000000DDF4F0: DC510280 047C0000
	.long 0xcc0f40d4                                           // 000000DDF4F8: CC0F40D4
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDF4FC: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:636                   // 000000DDF504: DC51027C 027C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF50C: BF8913F7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDF510: 380C0CFF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDF518: BF890FF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDF51C: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DDF524: BF8700C2
	.long 0xcc0f40d7                                           // 000000DDF528: CC0F40D7
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDF52C: 12020CFF 0000E408
	scratch_load_b32 v6, off, off offset:676                   // 000000DDF534: DC5102A4 067C0000
	.long 0xcc0f40d6                                           // 000000DDF53C: CC0F40D6
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDF540: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v230                          // 000000DDF548: 380BCCFF 64006400
	.long 0xcc0f40db                                           // 000000DDF550: CC0F40DB
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDF554: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v228                          // 000000DDF55C: 380BC8FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000DDF564: BF870141
	.long 0xcc0f40e0                                           // 000000DDF568: CC0F40E0
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDF56C: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v229                          // 000000DDF574: 380BCAFF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDF57C: BF890FF7
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DDF580: 380E0EFF 64006400
	.long 0xcc0f40e5                                           // 000000DDF588: CC0F40E5
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDF58C: 12020AFF 0000E408
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DDF594: BF870002
	.long 0xcc0f40dd                                           // 000000DDF598: CC0F40DD
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDF59C: 12020EFF 0000E408
	s_clause 0x1                                               // 000000DDF5A4: BF850001
	scratch_load_b32 v7, off, off offset:692                   // 000000DDF5A8: DC5102B4 077C0000
	scratch_load_b32 v5, off, off offset:716                   // 000000DDF5B0: DC5102CC 057C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF5B8: BF8913F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDF5BC: 380808FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDF5C4: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDF5C8: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DDF5D0: BF870002
	.long 0xcc0f40da                                           // 000000DDF5D4: CC0F40DA
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDF5D8: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:684                   // 000000DDF5E0: DC5102AC 047C0000
	.long 0xcc0f40d9                                           // 000000DDF5E8: CC0F40D9
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDF5EC: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:644                   // 000000DDF5F4: DC510284 027C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF5FC: BF8913F7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDF600: 380C0CFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDF608: BF870001
	.long 0xcc0f40dc                                           // 000000DDF60C: CC0F40DC
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDF610: 12020CFF 0000E408
	scratch_load_b32 v6, off, off offset:688                   // 000000DDF618: DC5102B0 067C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF620: BF8913F7
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DDF624: 380E0EFF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDF62C: BF890FF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDF630: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DDF638: BF8701A2
	.long 0xcc0f40e2                                           // 000000DDF63C: CC0F40E2
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDF640: 12020EFF 0000E408
	v_or_b32_e32 v7, 0x64006400, v227                          // 000000DDF648: 380FC6FF 64006400
	.long 0xcc0f40ea                                           // 000000DDF650: CC0F40EA
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDF654: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:776                   // 000000DDF65C: DC510308 057C0000
	.long 0xcc0f40e7                                           // 000000DDF664: CC0F40E7
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDF668: 12020EFF 0000E408
	scratch_load_b32 v7, off, off offset:772                   // 000000DDF670: DC510304 077C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF678: BF8913F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDF67C: 380808FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDF684: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDF688: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DDF690: BF870002
	.long 0xcc0f40df                                           // 000000DDF694: CC0F40DF
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDF698: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:700                   // 000000DDF6A0: DC5102BC 047C0000
	.long 0xcc0f40de                                           // 000000DDF6A8: CC0F40DE
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDF6AC: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:696                   // 000000DDF6B4: DC5102B8 027C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF6BC: BF8913F7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDF6C0: 380C0CFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDF6C8: BF870001
	.long 0xcc0f40e1                                           // 000000DDF6CC: CC0F40E1
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDF6D0: 12020CFF 0000E408
	scratch_load_b32 v6, off, off offset:704                   // 000000DDF6D8: DC5102C0 067C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF6E0: BF8913F7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDF6E4: 380A0AFF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDF6EC: BF890FF7
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DDF6F0: 380E0EFF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DDF6F8: BF870002
	.long 0xcc0f40ef                                           // 000000DDF6FC: CC0F40EF
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDF700: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:792                   // 000000DDF708: DC510318 057C0000
	.long 0xcc0f40ec                                           // 000000DDF710: CC0F40EC
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDF714: 12020EFF 0000E408
	scratch_load_b32 v7, off, off offset:784                   // 000000DDF71C: DC510310 077C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF724: BF8913F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDF728: 380808FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDF730: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDF734: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DDF73C: BF870002
	.long 0xcc0f40e4                                           // 000000DDF740: CC0F40E4
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDF744: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:712                   // 000000DDF74C: DC5102C8 047C0000
	.long 0xcc0f40e3                                           // 000000DDF754: CC0F40E3
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDF758: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:708                   // 000000DDF760: DC5102C4 027C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF768: BF8913F7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDF76C: 380C0CFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DDF774: BF8700A1
	.long 0xcc0f40e6                                           // 000000DDF778: CC0F40E6
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDF77C: 12020CFF 0000E408
	v_or_b32_e32 v6, 0x64006400, v232                          // 000000DDF784: 380DD0FF 64006400
	.long 0xcc0f40eb                                           // 000000DDF78C: CC0F40EB
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDF790: 12020CFF 0000E408
	scratch_load_b32 v6, off, off offset:780                   // 000000DDF798: DC51030C 067C0000
	s_waitcnt vmcnt(4)                                         // 000000DDF7A0: BF8913F7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDF7A4: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDF7AC: BF870001
	.long 0xcc0f40f4                                           // 000000DDF7B0: CC0F40F4
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDF7B4: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:812                   // 000000DDF7BC: DC51032C 057C0000
	s_waitcnt vmcnt(3)                                         // 000000DDF7C4: BF890FF7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDF7C8: 380808FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DDF7D0: BF890BF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDF7D4: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DDF7DC: BF870002
	.long 0xcc0f40e9                                           // 000000DDF7E0: CC0F40E9
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDF7E4: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:724                   // 000000DDF7EC: DC5102D4 047C0000
	.long 0xcc0f40e8                                           // 000000DDF7F4: CC0F40E8
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDF7F8: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:720                   // 000000DDF800: DC5102D0 027C0000
	s_waitcnt vmcnt(3)                                         // 000000DDF808: BF890FF7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDF80C: 380C0CFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DDF814: BF8700C1
	.long 0xcc0f40f0                                           // 000000DDF818: CC0F40F0
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDF81C: 12020CFF 0000E408
	scratch_load_b32 v6, off, off offset:796                   // 000000DDF824: DC51031C 067C0000
	s_waitcnt vmcnt(3)                                         // 000000DDF82C: BF890FF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDF830: 380A0AFF 64006400
	.long 0xcc0f40f9                                           // 000000DDF838: CC0F40F9
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDF83C: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v121                          // 000000DDF844: 380AF2FF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDF84C: BF870001
	.long 0xcc0f401b                                           // 000000DDF850: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDF854: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v122                          // 000000DDF85C: 380AF4FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DDF864: BF890BF7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDF868: 380808FF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DDF870: BF8907F7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDF874: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DDF87C: BF8700D2
	.long 0xcc0f40ee                                           // 000000DDF880: CC0F40EE
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDF884: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:788                   // 000000DDF88C: DC510314 047C0000
	.long 0xcc0f40ed                                           // 000000DDF894: CC0F40ED
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDF898: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:728                   // 000000DDF8A0: DC5102D8 027C0000
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DDF8A8: 380E0EFF 64006400
	.long 0xcc0f40f1                                           // 000000DDF8B0: CC0F40F1
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDF8B4: 12020EFF 0000E408
	scratch_load_b32 v7, off, off offset:800                   // 000000DDF8BC: DC510320 077C0000
	s_waitcnt vmcnt(3)                                         // 000000DDF8C4: BF890FF7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDF8C8: 380C0CFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDF8D0: BF870001
	.long 0xcc0f40f5                                           // 000000DDF8D4: CC0F40F5
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDF8D8: 12020CFF 0000E408
	scratch_load_b32 v6, off, off offset:816                   // 000000DDF8E0: DC510330 067C0000
	s_waitcnt vmcnt(3)                                         // 000000DDF8E8: BF890FF7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDF8EC: 380808FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DDF8F4: BF890BF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDF8F8: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DDF900: BF870002
	.long 0xcc0f40f3                                           // 000000DDF904: CC0F40F3
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDF908: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:808                   // 000000DDF910: DC510328 047C0000
	.long 0xcc0f40f2                                           // 000000DDF918: CC0F40F2
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDF91C: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:804                   // 000000DDF924: DC510324 027C0000
	s_waitcnt vmcnt(3)                                         // 000000DDF92C: BF890FF7
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DDF930: 380E0EFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDF938: BF870001
	.long 0xcc0f40f6                                           // 000000DDF93C: CC0F40F6
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDF940: 12020EFF 0000E408
	v_or_b32_e32 v7, 0x64006400, v32                           // 000000DDF948: 380E40FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DDF950: BF890BF7
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DDF954: 380C0CFF 64006400
	.long 0xcc0f4020                                           // 000000DDF95C: CC0F4020
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DDF960: 120212FF 0000E408
	v_or_b32_e32 v9, 0x64006400, v119                          // 000000DDF968: 3812EEFF 64006400
	.long 0xcc0f401f                                           // 000000DDF970: CC0F401F
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DDF974: 12020EFF 0000E408
	.long 0xcc0f4007                                           // 000000DDF97C: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000DDF980: 120210FF 0000E408
	.long 0xcc0f40fa                                           // 000000DDF988: CC0F40FA
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDF98C: 12020CFF 0000E408
	v_or_b32_e32 v6, 0x64006400, v29                           // 000000DDF994: 380C3AFF 64006400
	.long 0xcc0f4022                                           // 000000DDF99C: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DDF9A0: 120212FF 0000E408
	v_or_b32_e32 v9, 0x64006400, v115                          // 000000DDF9A8: 3812E6FF 64006400
	scratch_load_b32 v8, off, off offset:840                   // 000000DDF9B0: DC510348 087C0000
	.long 0xcc0f401d                                           // 000000DDF9B8: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DDF9BC: 12020CFF 0000E408
	.long 0xcc0f4027                                           // 000000DDF9C4: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DDF9C8: 120212FF 0000E408
	.long 0xcc0f4009                                           // 000000DDF9D0: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DDF9D4: 120216FF 0000E408
	s_waitcnt vmcnt(2)                                         // 000000DDF9DC: BF890BF7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDF9E0: 380808FF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DDF9E8: BF8907F7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DDF9EC: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DDF9F4: BF8701A2
	.long 0xcc0f40f8                                           // 000000DDF9F8: CC0F40F8
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDF9FC: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v254                          // 000000DDFA04: 3809FCFF 64006400
	.long 0xcc0f40f7                                           // 000000DDFA0C: CC0F40F7
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDFA10: 120204FF 0000E408
	v_or_b32_e32 v2, 0x64006400, v253                          // 000000DDFA18: 3805FAFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DDFA20: BF870113
	.long 0xcc0f40fe                                           // 000000DDFA24: CC0F40FE
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFA28: 120208FF 0000E408
	.long 0xcc0f40fd                                           // 000000DDFA30: CC0F40FD
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDFA34: 120204FF 0000E408
	v_or_b32_e32 v2, 0x64006400, v1                            // 000000DDFA3C: 380402FF 64006400
	scratch_load_b32 v1, off, off offset:836                   // 000000DDFA44: DC510344 017C0000
	.long 0xcc0f4002                                           // 000000DDFA4C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DDFA50: 120204FF 0000E408
	s_waitcnt vmcnt(0)                                         // 000000DDFA58: BF8903F7
	v_or_b32_e32 v4, 0x64006400, v1                            // 000000DDFA5C: 380802FF 64006400
	.long 0xcc0f4001                                           // 000000DDFA64: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v0                           // 000000DDFA68: 120200FF 0000E408
	.long 0xcc0f4000                                           // 000000DDFA70: CC0F4000
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFA74: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v30                           // 000000DDFA7C: 380A3CFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DDFA84: BF8700C4
	.long 0xcc0f401c                                           // 000000DDFA88: CC0F401C
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFA8C: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:828                   // 000000DDFA94: DC51033C 047C0000
	.long 0xcc0f4006                                           // 000000DDFA9C: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFAA0: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v123                          // 000000DDFAA8: 380AF6FF 64006400
	.long 0xcc0f4021                                           // 000000DDFAB0: CC0F4021
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFAB4: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:844                   // 000000DDFABC: DC51034C 057C0000
	v_or_b32_e32 v10, 0x64006400, v8                           // 000000DDFAC4: 381410FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DDFACC: BF8700A1
	.long 0xcc0f4023                                           // 000000DDFAD0: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DDFAD4: 120214FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v105                         // 000000DDFADC: 3814D2FF 64006400
	.long 0xcc0f4028                                           // 000000DDFAE4: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DDFAE8: 120214FF 0000E408
	s_waitcnt vmcnt(1)                                         // 000000DDFAF0: BF8907F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDFAF4: 380808FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000DDFAFC: BF870141
	.long 0xcc0f401e                                           // 000000DDFB00: CC0F401E
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFB04: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v116                          // 000000DDFB0C: 3808E8FF 64006400
	s_waitcnt vmcnt(0)                                         // 000000DDFB14: BF8903F7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDFB18: 380A0AFF 64006400
	.long 0xcc0f4008                                           // 000000DDFB20: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFB24: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v117                          // 000000DDFB2C: 3808EAFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DDFB34: BF8701A3
	.long 0xcc0f4026                                           // 000000DDFB38: CC0F4026
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFB3C: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v118                          // 000000DDFB44: 380AECFF 64006400
	.long 0xcc0f4025                                           // 000000DDFB4C: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFB50: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v114                          // 000000DDFB58: 3808E4FF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DDFB60: BF8701A3
	.long 0xcc0f400b                                           // 000000DDFB64: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFB68: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v94                           // 000000DDFB70: 380ABCFF 64006400
	.long 0xcc0f400a                                           // 000000DDFB78: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFB7C: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:848                   // 000000DDFB84: DC510350 047C0000
	.long 0xcc0f4010                                           // 000000DDFB8C: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFB90: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v101                          // 000000DDFB98: 380ACAFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DDFBA0: BF8700A1
	.long 0xcc0f4015                                           // 000000DDFBA4: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFBA8: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v107                          // 000000DDFBB0: 380AD6FF 64006400
	.long 0xcc0f402a                                           // 000000DDFBB8: CC0F402A
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFBBC: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v91                           // 000000DDFBC4: 380AB6FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000DDFBCC: BF8701C1
	.long 0xcc0f402f                                           // 000000DDFBD0: CC0F402F
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFBD4: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v53                           // 000000DDFBDC: 380A6AFF 64006400
	.long 0xcc0f4035                                           // 000000DDFBE4: CC0F4035
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DDFBE8: 120232FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v81                          // 000000DDFBF0: 3832A2FF 64006400
	.long 0xcc0f4034                                           // 000000DDFBF8: CC0F4034
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFBFC: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v59                           // 000000DDFC04: 380A76FF 64006400
	.long 0xcc0f403b                                           // 000000DDFC0C: CC0F403B
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DDFC10: 120234FF 0000E408
	v_or_b32_e32 v26, 0x64006400, v62                          // 000000DDFC18: 38347CFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DDFC20: BF8700A3
	.long 0xcc0f4039                                           // 000000DDFC24: CC0F4039
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFC28: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v70                           // 000000DDFC30: 380A8CFF 64006400
	.long 0xcc0f403f                                           // 000000DDFC38: CC0F403F
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFC3C: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v67                           // 000000DDFC44: 380A86FF 64006400
	s_waitcnt vmcnt(0)                                         // 000000DDFC4C: BF8903F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDFC50: 380808FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DDFC58: BF8700A1
	.long 0xcc0f400f                                           // 000000DDFC5C: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFC60: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v100                          // 000000DDFC68: 3808C8FF 64006400
	.long 0xcc0f4014                                           // 000000DDFC70: CC0F4014
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFC74: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v102                          // 000000DDFC7C: 3808CCFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DDFC84: BF8700A1
	.long 0xcc0f4029                                           // 000000DDFC88: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFC8C: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v90                           // 000000DDFC94: 3808B4FF 64006400
	.long 0xcc0f402e                                           // 000000DDFC9C: CC0F402E
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFCA0: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v98                           // 000000DDFCA8: 3808C4FF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDFCB0: BF870001
	.long 0xcc0f4033                                           // 000000DDFCB4: CC0F4033
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFCB8: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v58                           // 000000DDFCC0: 380874FF 64006400
	.long 0xcc0f403a                                           // 000000DDFCC8: CC0F403A
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DDFCCC: 120232FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v61                          // 000000DDFCD4: 38327AFF 64006400
	.long 0xcc0f403d                                           // 000000DDFCDC: CC0F403D
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DDFCE0: 120206FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v75                           // 000000DDFCE8: 380696FF 64006400
	.long 0xcc0f4038                                           // 000000DDFCF0: CC0F4038
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFCF4: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v65                           // 000000DDFCFC: 380882FF 64006400
	.long 0xcc0f4040                                           // 000000DDFD04: CC0F4040
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DDFD08: 120232FF 0000E408
	.long 0xcc0f4041                                           // 000000DDFD10: CC0F4041
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DDFD14: 120234FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v68                          // 000000DDFD1C: 383288FF 64006400
	v_or_b32_e32 v26, 0x64006400, v69                          // 000000DDFD24: 38348AFF 64006400
	.long 0xcc0f403e                                           // 000000DDFD2C: CC0F403E
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFD30: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v96                           // 000000DDFD38: 3808C0FF 64006400
	.long 0xcc0f4042                                           // 000000DDFD40: CC0F4042
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DDFD44: 120206FF 0000E408
	.long 0xcc0f4044                                           // 000000DDFD4C: CC0F4044
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFD50: 12020AFF 0000E408
	.long 0xcc0f4045                                           // 000000DDFD58: CC0F4045
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DDFD5C: 120232FF 0000E408
	.long 0xcc0f4046                                           // 000000DDFD64: CC0F4046
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DDFD68: 120234FF 0000E408
	.long 0xcc0f4043                                           // 000000DDFD70: CC0F4043
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFD74: 120208FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v82                           // 000000DDFD7C: 3806A4FF 64006400
	v_or_b32_e32 v4, 0x64006400, v71                           // 000000DDFD84: 38088EFF 64006400
	v_or_b32_e32 v5, 0x64006400, v72                           // 000000DDFD8C: 380A90FF 64006400
	v_or_b32_e32 v25, 0x64006400, v73                          // 000000DDFD94: 383292FF 64006400
	v_or_b32_e32 v26, 0x64006400, v74                          // 000000DDFD9C: 383494FF 64006400
	.long 0xcc0f4047                                           // 000000DDFDA4: CC0F4047
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DDFDA8: 120206FF 0000E408
	.long 0xcc0f4048                                           // 000000DDFDB0: CC0F4048
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFDB4: 120208FF 0000E408
	.long 0xcc0f4049                                           // 000000DDFDBC: CC0F4049
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFDC0: 12020AFF 0000E408
	.long 0xcc0f404a                                           // 000000DDFDC8: CC0F404A
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DDFDCC: 120232FF 0000E408
	.long 0xcc0f404b                                           // 000000DDFDD4: CC0F404B
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DDFDD8: 120234FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v80                           // 000000DDFDE0: 3806A0FF 64006400
	v_or_b32_e32 v4, 0x64006400, v77                           // 000000DDFDE8: 38089AFF 64006400
	v_or_b32_e32 v5, 0x64006400, v78                           // 000000DDFDF0: 380A9CFF 64006400
	v_or_b32_e32 v25, 0x64006400, v79                          // 000000DDFDF8: 38329EFF 64006400
	v_or_b32_e32 v26, 0x64006400, v76                          // 000000DDFE00: 383498FF 64006400
	.long 0xcc0f404c                                           // 000000DDFE08: CC0F404C
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DDFE0C: 120206FF 0000E408
	.long 0xcc0f404d                                           // 000000DDFE14: CC0F404D
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFE18: 120208FF 0000E408
	.long 0xcc0f404e                                           // 000000DDFE20: CC0F404E
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFE24: 12020AFF 0000E408
	.long 0xcc0f404f                                           // 000000DDFE2C: CC0F404F
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DDFE30: 120232FF 0000E408
	.long 0xcc0f4050                                           // 000000DDFE38: CC0F4050
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DDFE3C: 120234FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v86                           // 000000DDFE44: 3806ACFF 64006400
	v_or_b32_e32 v4, 0x64006400, v87                           // 000000DDFE4C: 3808AEFF 64006400
	v_or_b32_e32 v5, 0x64006400, v85                           // 000000DDFE54: 380AAAFF 64006400
	v_or_b32_e32 v25, 0x64006400, v83                          // 000000DDFE5C: 3832A6FF 64006400
	v_or_b32_e32 v26, 0x64006400, v84                          // 000000DDFE64: 3834A8FF 64006400
	.long 0xcc0f4051                                           // 000000DDFE6C: CC0F4051
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DDFE70: 120206FF 0000E408
	.long 0xcc0f4052                                           // 000000DDFE78: CC0F4052
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFE7C: 120208FF 0000E408
	.long 0xcc0f4053                                           // 000000DDFE84: CC0F4053
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFE88: 12020AFF 0000E408
	.long 0xcc0f4054                                           // 000000DDFE90: CC0F4054
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DDFE94: 120232FF 0000E408
	.long 0xcc0f4055                                           // 000000DDFE9C: CC0F4055
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DDFEA0: 120234FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v113                          // 000000DDFEA8: 3806E2FF 64006400
	v_or_b32_e32 v4, 0x64006400, v112                          // 000000DDFEB0: 3808E0FF 64006400
	v_or_b32_e32 v5, 0x64006400, v109                          // 000000DDFEB8: 380ADAFF 64006400
	v_or_b32_e32 v25, 0x64006400, v110                         // 000000DDFEC0: 3832DCFF 64006400
	v_or_b32_e32 v26, 0x64006400, v111                         // 000000DDFEC8: 3834DEFF 64006400
	.long 0xcc0f4056                                           // 000000DDFED0: CC0F4056
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DDFED4: 120206FF 0000E408
	.long 0xcc0f4057                                           // 000000DDFEDC: CC0F4057
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFEE0: 120208FF 0000E408
	.long 0xcc0f4058                                           // 000000DDFEE8: CC0F4058
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFEEC: 12020AFF 0000E408
	.long 0xcc0f4059                                           // 000000DDFEF4: CC0F4059
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DDFEF8: 120232FF 0000E408
	.long 0xcc0f405a                                           // 000000DDFF00: CC0F405A
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DDFF04: 120234FF 0000E408
	s_clause 0x4                                               // 000000DDFF0C: BF850004
	scratch_load_b32 v3, off, off offset:832                   // 000000DDFF10: DC510340 037C0000
	scratch_load_b32 v4, off, off offset:852                   // 000000DDFF18: DC510354 047C0000
	scratch_load_b32 v5, off, off offset:856                   // 000000DDFF20: DC510358 057C0000
	scratch_load_b32 v25, off, off offset:860                  // 000000DDFF28: DC51035C 197C0000
	scratch_load_b32 v26, off, off offset:864                  // 000000DDFF30: DC510360 1A7C0000
	s_waitcnt vmcnt(4)                                         // 000000DDFF38: BF8913F7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DDFF3C: 380606FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DDFF44: BF890FF7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DDFF48: 380808FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DDFF50: BF890BF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DDFF54: 380A0AFF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DDFF5C: BF8907F7
	v_or_b32_e32 v25, 0x64006400, v25                          // 000000DDFF60: 383232FF 64006400
	s_waitcnt vmcnt(0)                                         // 000000DDFF68: BF8903F7
	v_or_b32_e32 v26, 0x64006400, v26                          // 000000DDFF6C: 383434FF 64006400
	.long 0xcc0f405b                                           // 000000DDFF74: CC0F405B
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DDFF78: 120206FF 0000E408
	.long 0xcc0f405c                                           // 000000DDFF80: CC0F405C
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DDFF84: 120208FF 0000E408
	.long 0xcc0f405d                                           // 000000DDFF8C: CC0F405D
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DDFF90: 12020AFF 0000E408
	.long 0xcc0f405e                                           // 000000DDFF98: CC0F405E
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DDFF9C: 120232FF 0000E408
	.long 0xcc0f405f                                           // 000000DDFFA4: CC0F405F
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DDFFA8: 120234FF 0000E408
	v_lshl_or_b32 v3, v124, 6, 0x2800                          // 000000DDFFB0: D6560003 03FD0D7C 00002800
	s_branch 5                                                 // 000000DDFFBC: BFA00005 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x68d4>
	s_or_b32 exec_lo, exec_lo, s2                              // 000000DDFFC0: 8C7E027E
	s_add_i32 s1, s1, 1                                        // 000000DDFFC4: 81018101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DDFFC8: BF870009
	s_cmp_lg_u32 s1, s3                                        // 000000DDFFCC: BF070301
	s_cbranch_scc0 1042                                        // 000000DDFFD0: BFA10412 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x791c>
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DDFFD4: BF870001
	v_mad_u64_u32 v[4:5], null, 0x1400, s1, v[3:4]             // 000000DDFFD8: D6FE7C04 040C02FF 00001400
	scratch_load_b32 v5, off, off offset:388                   // 000000DDFFE4: DC510184 057C0000
	v_mov_b32_e32 v25, 0                                       // 000000DDFFEC: 7E320280
	ds_load_b128 v[96:99], v4                                  // 000000DDFFF0: DBFC0000 60000004
	ds_load_b128 v[100:103], v4 offset:16                      // 000000DDFFF8: DBFC0010 64000004
	ds_load_b128 v[108:111], v4 offset:512                     // 000000DE0000: DBFC0200 6C000004
	ds_load_b128 v[112:115], v4 offset:528                     // 000000DE0008: DBFC0210 70000004
	scratch_load_b32 v26, off, off offset:312                  // 000000DE0010: DC510138 1A7C0000
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 000000DE0018: BF890437
	v_dual_mov_b32 v124, 0 :: v_dual_dot2acc_f32_f16 v25, v5, v96// 000000DE001C: CA180080 7C18C105
	scratch_load_b32 v5, off, off offset:392                   // 000000DE0024: DC510188 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE002C: BF8903F7
	v_dot2acc_f32_f16 v25, v5, v97                             // 000000DE0030: 0432C305
	scratch_load_b32 v5, off, off offset:396                   // 000000DE0034: DC51018C 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE003C: BF8903F7
	v_dot2acc_f32_f16 v25, v5, v98                             // 000000DE0040: 0432C505
	scratch_load_b32 v5, off, off offset:384                   // 000000DE0044: DC510180 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE004C: BF8903F7
	v_dot2acc_f32_f16 v25, v5, v99                             // 000000DE0050: 0432C705
	ds_load_b128 v[96:99], v4 offset:256                       // 000000DE0054: DBFC0100 60000004
	ds_load_b128 v[104:107], v4 offset:272                     // 000000DE005C: DBFC0110 68000004
	v_mov_b32_e32 v5, 0                                        // 000000DE0064: 7E0A0280
	s_waitcnt lgkmcnt(1)                                       // 000000DE0068: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DE006C: BF870001
	v_dot2acc_f32_f16 v5, v26, v96                             // 000000DE0070: 040AC11A
	scratch_load_b32 v26, off, off offset:316                  // 000000DE0074: DC51013C 1A7C0000
	s_waitcnt vmcnt(0)                                         // 000000DE007C: BF8903F7
	v_dual_mov_b32 v96, 0 :: v_dual_dot2acc_f32_f16 v5, v26, v97// 000000DE0080: CA180080 6004C31A
	s_clause 0x1                                               // 000000DE0088: BF850001
	scratch_load_b32 v26, off, off offset:304                  // 000000DE008C: DC510130 1A7C0000
	scratch_load_b32 v97, off, off offset:184                  // 000000DE0094: DC5100B8 617C0000
	s_waitcnt vmcnt(1)                                         // 000000DE009C: BF8907F7
	v_dot2acc_f32_f16 v5, v26, v98                             // 000000DE00A0: 040AC51A
	s_clause 0x1                                               // 000000DE00A4: BF850001
	scratch_load_b32 v26, off, off offset:308                  // 000000DE00A8: DC510134 1A7C0000
	scratch_load_b32 v98, off, off offset:124                  // 000000DE00B0: DC51007C 627C0000
	s_waitcnt vmcnt(1)                                         // 000000DE00B8: BF8907F7
	v_dot2acc_f32_f16 v5, v26, v99                             // 000000DE00BC: 040AC71A
	scratch_load_b32 v26, off, off offset:252                  // 000000DE00C0: DC5100FC 1A7C0000
	s_waitcnt vmcnt(0)                                         // 000000DE00C8: BF8903F7
	v_dot2acc_f32_f16 v96, v26, v108                           // 000000DE00CC: 04C0D91A
	scratch_load_b32 v26, off, off offset:244                  // 000000DE00D0: DC5100F4 1A7C0000
	s_waitcnt vmcnt(0)                                         // 000000DE00D8: BF8903F7
	v_dot2acc_f32_f16 v96, v26, v109                           // 000000DE00DC: 04C0DB1A
	scratch_load_b32 v26, off, off offset:248                  // 000000DE00E0: DC5100F8 1A7C0000
	s_waitcnt vmcnt(0)                                         // 000000DE00E8: BF8903F7
	v_dot2acc_f32_f16 v96, v26, v110                           // 000000DE00EC: 04C0DD1A
	scratch_load_b32 v26, off, off offset:236                  // 000000DE00F0: DC5100EC 1A7C0000
	s_waitcnt vmcnt(0)                                         // 000000DE00F8: BF8903F7
	v_dot2acc_f32_f16 v96, v26, v111                           // 000000DE00FC: 04C0DF1A
	ds_load_b128 v[108:111], v4 offset:768                     // 000000DE0100: DBFC0300 6C000004
	ds_load_b128 v[116:119], v4 offset:784                     // 000000DE0108: DBFC0310 74000004
	v_mov_b32_e32 v26, 0                                       // 000000DE0110: 7E340280
	s_waitcnt lgkmcnt(1)                                       // 000000DE0114: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DE0118: BF870001
	v_dot2acc_f32_f16 v26, v97, v108                           // 000000DE011C: 0434D961
	scratch_load_b32 v97, off, off offset:188                  // 000000DE0120: DC5100BC 617C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0128: BF8903F7
	v_dot2acc_f32_f16 v26, v97, v109                           // 000000DE012C: 0434DB61
	scratch_load_b32 v97, off, off offset:176                  // 000000DE0130: DC5100B0 617C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0138: BF8903F7
	v_dot2acc_f32_f16 v26, v97, v110                           // 000000DE013C: 0434DD61
	scratch_load_b32 v97, off, off offset:180                  // 000000DE0140: DC5100B4 617C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0148: BF8903F7
	v_dot2acc_f32_f16 v26, v97, v111                           // 000000DE014C: 0434DF61
	ds_load_b128 v[108:111], v4 offset:1024                    // 000000DE0150: DBFC0400 6C000004
	ds_load_b128 v[120:123], v4 offset:1040                    // 000000DE0158: DBFC0410 78000004
	v_mov_b32_e32 v97, 0                                       // 000000DE0160: 7EC20280
	s_waitcnt lgkmcnt(1)                                       // 000000DE0164: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DE0168: BF870001
	v_dot2acc_f32_f16 v97, v98, v108                           // 000000DE016C: 04C2D962
	scratch_load_b32 v98, off, off offset:116                  // 000000DE0170: DC510074 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0178: BF8903F7
	v_dot2acc_f32_f16 v97, v98, v109                           // 000000DE017C: 04C2DB62
	scratch_load_b32 v98, off, off offset:120                  // 000000DE0180: DC510078 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0188: BF8903F7
	v_dot2acc_f32_f16 v97, v98, v110                           // 000000DE018C: 04C2DD62
	s_clause 0x1                                               // 000000DE0190: BF850001
	scratch_load_b32 v98, off, off offset:108                  // 000000DE0194: DC51006C 627C0000
	scratch_load_b32 v110, off, off offset:280                 // 000000DE019C: DC510118 6E7C0000
	s_waitcnt vmcnt(1)                                         // 000000DE01A4: BF8907F7
	v_dot2acc_f32_f16 v97, v98, v111                           // 000000DE01A8: 04C2DF62
	scratch_load_b32 v98, off, off offset:372                  // 000000DE01AC: DC510174 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE01B4: BF8903F7
	v_dot2acc_f32_f16 v25, v98, v100                           // 000000DE01B8: 0432C962
	scratch_load_b32 v98, off, off offset:376                  // 000000DE01BC: DC510178 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE01C4: BF8903F7
	v_dot2acc_f32_f16 v25, v98, v101                           // 000000DE01C8: 0432CB62
	scratch_load_b32 v98, off, off offset:380                  // 000000DE01CC: DC51017C 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE01D4: BF8903F7
	v_dot2acc_f32_f16 v25, v98, v102                           // 000000DE01D8: 0432CD62
	scratch_load_b32 v98, off, off offset:364                  // 000000DE01DC: DC51016C 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE01E4: BF8903F7
	v_dot2acc_f32_f16 v25, v98, v103                           // 000000DE01E8: 0432CF62
	scratch_load_b32 v98, off, off offset:296                  // 000000DE01EC: DC510128 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE01F4: BF8903F7
	v_dot2acc_f32_f16 v5, v98, v104                            // 000000DE01F8: 040AD162
	scratch_load_b32 v98, off, off offset:300                  // 000000DE01FC: DC51012C 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0204: BF8903F7
	v_dot2acc_f32_f16 v5, v98, v105                            // 000000DE0208: 040AD362
	scratch_load_b32 v98, off, off offset:288                  // 000000DE020C: DC510120 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0214: BF8903F7
	v_dot2acc_f32_f16 v5, v98, v106                            // 000000DE0218: 040AD562
	s_clause 0x1                                               // 000000DE021C: BF850001
	scratch_load_b32 v98, off, off offset:292                  // 000000DE0220: DC510124 627C0000
	scratch_load_b32 v106, off, off offset:368                 // 000000DE0228: DC510170 6A7C0000
	s_waitcnt vmcnt(1)                                         // 000000DE0230: BF8907F7
	v_dot2acc_f32_f16 v5, v98, v107                            // 000000DE0234: 040AD762
	scratch_load_b32 v98, off, off offset:240                  // 000000DE0238: DC5100F0 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0240: BF8903F7
	v_dot2acc_f32_f16 v96, v98, v112                           // 000000DE0244: 04C0E162
	scratch_load_b32 v98, off, off offset:228                  // 000000DE0248: DC5100E4 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0250: BF8903F7
	v_dot2acc_f32_f16 v96, v98, v113                           // 000000DE0254: 04C0E362
	scratch_load_b32 v98, off, off offset:232                  // 000000DE0258: DC5100E8 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0260: BF8903F7
	v_dot2acc_f32_f16 v96, v98, v114                           // 000000DE0264: 04C0E562
	s_clause 0x1                                               // 000000DE0268: BF850001
	scratch_load_b32 v98, off, off offset:220                  // 000000DE026C: DC5100DC 627C0000
	scratch_load_b32 v114, off, off offset:224                 // 000000DE0274: DC5100E0 727C0000
	s_waitcnt vmcnt(1)                                         // 000000DE027C: BF8907F7
	v_dot2acc_f32_f16 v96, v98, v115                           // 000000DE0280: 04C0E762
	scratch_load_b32 v98, off, off offset:168                  // 000000DE0284: DC5100A8 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE028C: BF8903F7
	v_dot2acc_f32_f16 v26, v98, v116                           // 000000DE0290: 0434E962
	scratch_load_b32 v98, off, off offset:172                  // 000000DE0294: DC5100AC 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE029C: BF8903F7
	v_dot2acc_f32_f16 v26, v98, v117                           // 000000DE02A0: 0434EB62
	scratch_load_b32 v98, off, off offset:160                  // 000000DE02A4: DC5100A0 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE02AC: BF8903F7
	v_dot2acc_f32_f16 v26, v98, v118                           // 000000DE02B0: 0434ED62
	s_clause 0x1                                               // 000000DE02B4: BF850001
	scratch_load_b32 v98, off, off offset:164                  // 000000DE02B8: DC5100A4 627C0000
	scratch_load_b32 v118, off, off offset:152                 // 000000DE02C0: DC510098 767C0000
	s_waitcnt vmcnt(1)                                         // 000000DE02C8: BF8907F7
	v_dot2acc_f32_f16 v26, v98, v119                           // 000000DE02CC: 0434EF62
	scratch_load_b32 v98, off, off offset:112                  // 000000DE02D0: DC510070 627C0000
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000DE02D8: BF890007
	v_dot2acc_f32_f16 v97, v98, v120                           // 000000DE02DC: 04C2F162
	scratch_load_b32 v98, off, off offset:100                  // 000000DE02E0: DC510064 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE02E8: BF8903F7
	v_dot2acc_f32_f16 v97, v98, v121                           // 000000DE02EC: 04C2F362
	scratch_load_b32 v98, off, off offset:104                  // 000000DE02F0: DC510068 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE02F8: BF8903F7
	v_dot2acc_f32_f16 v97, v98, v122                           // 000000DE02FC: 04C2F562
	s_clause 0x1                                               // 000000DE0300: BF850001
	scratch_load_b32 v98, off, off offset:92                   // 000000DE0304: DC51005C 627C0000
	scratch_load_b32 v122, off, off offset:96                  // 000000DE030C: DC510060 7A7C0000
	s_waitcnt vmcnt(1)                                         // 000000DE0314: BF8907F7
	v_dot2acc_f32_f16 v97, v98, v123                           // 000000DE0318: 04C2F762
	ds_load_b128 v[98:101], v4 offset:32                       // 000000DE031C: DBFC0020 62000004
	ds_load_b128 v[102:105], v4 offset:48                      // 000000DE0324: DBFC0030 66000004
	v_mov_b32_e32 v123, 0                                      // 000000DE032C: 7EF60280
	s_waitcnt lgkmcnt(1)                                       // 000000DE0330: BF89FC17
	v_dot2acc_f32_f16 v25, v106, v98                           // 000000DE0334: 0432C56A
	scratch_load_b32 v98, off, off offset:340                  // 000000DE0338: DC510154 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0340: BF8903F7
	v_dot2acc_f32_f16 v25, v98, v99                            // 000000DE0344: 0432C762
	scratch_load_b32 v98, off, off offset:360                  // 000000DE0348: DC510168 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0350: BF8903F7
	v_dot2acc_f32_f16 v25, v98, v100                           // 000000DE0354: 0432C962
	scratch_load_b32 v98, off, off offset:332                  // 000000DE0358: DC51014C 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0360: BF8903F7
	v_dot2acc_f32_f16 v25, v98, v101                           // 000000DE0364: 0432CB62
	ds_load_b128 v[98:101], v4 offset:288                      // 000000DE0368: DBFC0120 62000004
	ds_load_b128 v[106:109], v4 offset:304                     // 000000DE0370: DBFC0130 6A000004
	s_waitcnt lgkmcnt(1)                                       // 000000DE0378: BF89FC17
	v_dot2acc_f32_f16 v5, v110, v98                            // 000000DE037C: 040AC56E
	scratch_load_b32 v98, off, off offset:284                  // 000000DE0380: DC51011C 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0388: BF8903F7
	v_dot2acc_f32_f16 v5, v98, v99                             // 000000DE038C: 040AC762
	scratch_load_b32 v98, off, off offset:272                  // 000000DE0390: DC510110 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0398: BF8903F7
	v_dot2acc_f32_f16 v5, v98, v100                            // 000000DE039C: 040AC962
	scratch_load_b32 v98, off, off offset:276                  // 000000DE03A0: DC510114 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE03A8: BF8903F7
	v_dot2acc_f32_f16 v5, v98, v101                            // 000000DE03AC: 040ACB62
	ds_load_b128 v[98:101], v4 offset:544                      // 000000DE03B0: DBFC0220 62000004
	ds_load_b128 v[110:113], v4 offset:560                     // 000000DE03B8: DBFC0230 6E000004
	s_waitcnt lgkmcnt(1)                                       // 000000DE03C0: BF89FC17
	v_dot2acc_f32_f16 v96, v114, v98                           // 000000DE03C4: 04C0C572
	scratch_load_b32 v98, off, off offset:212                  // 000000DE03C8: DC5100D4 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE03D0: BF8903F7
	v_dot2acc_f32_f16 v96, v98, v99                            // 000000DE03D4: 04C0C762
	scratch_load_b32 v98, off, off offset:216                  // 000000DE03D8: DC5100D8 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE03E0: BF8903F7
	v_dot2acc_f32_f16 v96, v98, v100                           // 000000DE03E4: 04C0C962
	scratch_load_b32 v98, off, off offset:204                  // 000000DE03E8: DC5100CC 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE03F0: BF8903F7
	v_dot2acc_f32_f16 v96, v98, v101                           // 000000DE03F4: 04C0CB62
	ds_load_b128 v[98:101], v4 offset:800                      // 000000DE03F8: DBFC0320 62000004
	ds_load_b128 v[114:117], v4 offset:816                     // 000000DE0400: DBFC0330 72000004
	s_waitcnt lgkmcnt(1)                                       // 000000DE0408: BF89FC17
	v_dot2acc_f32_f16 v26, v118, v98                           // 000000DE040C: 0434C576
	scratch_load_b32 v98, off, off offset:156                  // 000000DE0410: DC51009C 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0418: BF8903F7
	v_dot2acc_f32_f16 v26, v98, v99                            // 000000DE041C: 0434C762
	scratch_load_b32 v98, off, off offset:144                  // 000000DE0420: DC510090 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0428: BF8903F7
	v_dot2acc_f32_f16 v26, v98, v100                           // 000000DE042C: 0434C962
	scratch_load_b32 v98, off, off offset:148                  // 000000DE0430: DC510094 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0438: BF8903F7
	v_dot2acc_f32_f16 v26, v98, v101                           // 000000DE043C: 0434CB62
	ds_load_b128 v[98:101], v4 offset:1056                     // 000000DE0440: DBFC0420 62000004
	ds_load_b128 v[118:121], v4 offset:1072                    // 000000DE0448: DBFC0430 76000004
	s_waitcnt lgkmcnt(1)                                       // 000000DE0450: BF89FC17
	v_dot2acc_f32_f16 v97, v122, v98                           // 000000DE0454: 04C2C57A
	scratch_load_b32 v98, off, off offset:84                   // 000000DE0458: DC510054 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0460: BF8903F7
	v_dual_mov_b32 v122, 0 :: v_dual_dot2acc_f32_f16 v97, v98, v99// 000000DE0464: CA180080 7A60C762
	scratch_load_b32 v98, off, off offset:88                   // 000000DE046C: DC510058 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0474: BF8903F7
	v_dot2acc_f32_f16 v97, v98, v100                           // 000000DE0478: 04C2C962
	scratch_load_b32 v98, off, off offset:76                   // 000000DE047C: DC51004C 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0484: BF8903F7
	v_dot2acc_f32_f16 v97, v98, v101                           // 000000DE0488: 04C2CB62
	scratch_load_b32 v98, off, off offset:336                  // 000000DE048C: DC510150 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0494: BF8903F7
	v_dot2acc_f32_f16 v25, v98, v102                           // 000000DE0498: 0432CD62
	scratch_load_b32 v98, off, off offset:324                  // 000000DE049C: DC510144 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE04A4: BF8903F7
	v_dot2acc_f32_f16 v25, v98, v103                           // 000000DE04A8: 0432CF62
	scratch_load_b32 v98, off, off offset:328                  // 000000DE04AC: DC510148 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE04B4: BF8903F7
	v_dot2acc_f32_f16 v25, v98, v104                           // 000000DE04B8: 0432D162
	scratch_load_b32 v98, off, off offset:320                  // 000000DE04BC: DC510140 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE04C4: BF8903F7
	v_dot2acc_f32_f16 v25, v98, v105                           // 000000DE04C8: 0432D362
	scratch_load_b32 v98, off, off offset:264                  // 000000DE04CC: DC510108 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE04D4: BF8903F7
	v_dot2acc_f32_f16 v5, v98, v106                            // 000000DE04D8: 040AD562
	scratch_load_b32 v98, off, off offset:268                  // 000000DE04DC: DC51010C 627C0000
	ds_load_b128 v[99:102], v4 offset:1280                     // 000000DE04E4: DBFC0500 63000004
	ds_load_b128 v[103:106], v4 offset:1296                    // 000000DE04EC: DBFC0510 67000004
	s_waitcnt vmcnt(0)                                         // 000000DE04F4: BF8903F7
	v_dot2acc_f32_f16 v5, v98, v107                            // 000000DE04F8: 040AD762
	s_clause 0x1                                               // 000000DE04FC: BF850001
	scratch_load_b32 v98, off, off offset:256                  // 000000DE0500: DC510100 627C0000
	scratch_load_b32 v107, off, off offset:400                 // 000000DE0508: DC510190 6B7C0000
	s_waitcnt vmcnt(1)                                         // 000000DE0510: BF8907F7
	v_dot2acc_f32_f16 v5, v98, v108                            // 000000DE0514: 040AD962
	scratch_load_b32 v98, off, off offset:260                  // 000000DE0518: DC510104 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0520: BF8903F7
	v_dot2acc_f32_f16 v5, v98, v109                            // 000000DE0524: 040ADB62
	scratch_load_b32 v98, off, off offset:208                  // 000000DE0528: DC5100D0 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0530: BF8903F7
	v_dot2acc_f32_f16 v96, v98, v110                           // 000000DE0534: 04C0DD62
	scratch_load_b32 v98, off, off offset:196                  // 000000DE0538: DC5100C4 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0540: BF8903F7
	v_dot2acc_f32_f16 v96, v98, v111                           // 000000DE0544: 04C0DF62
	scratch_load_b32 v98, off, off offset:200                  // 000000DE0548: DC5100C8 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0550: BF8903F7
	v_dot2acc_f32_f16 v96, v98, v112                           // 000000DE0554: 04C0E162
	scratch_load_b32 v98, off, off offset:192                  // 000000DE0558: DC5100C0 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0560: BF8903F7
	v_dot2acc_f32_f16 v96, v98, v113                           // 000000DE0564: 04C0E362
	scratch_load_b32 v98, off, off offset:136                  // 000000DE0568: DC510088 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0570: BF8903F7
	v_dot2acc_f32_f16 v26, v98, v114                           // 000000DE0574: 0434E562
	scratch_load_b32 v98, off, off offset:140                  // 000000DE0578: DC51008C 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0580: BF8903F7
	v_dot2acc_f32_f16 v26, v98, v115                           // 000000DE0584: 0434E762
	scratch_load_b32 v98, off, off offset:128                  // 000000DE0588: DC510080 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0590: BF8903F7
	v_dot2acc_f32_f16 v26, v98, v116                           // 000000DE0594: 0434E962
	scratch_load_b32 v98, off, off offset:132                  // 000000DE0598: DC510084 627C0000
	s_waitcnt vmcnt(0)                                         // 000000DE05A0: BF8903F7
	v_dot2acc_f32_f16 v26, v98, v117                           // 000000DE05A4: 0434EB62
	v_mov_b32_e32 v98, 0                                       // 000000DE05A8: 7EC40280
	s_waitcnt lgkmcnt(1)                                       // 000000DE05AC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DE05B0: BF870001
	v_dot2acc_f32_f16 v98, v107, v99                           // 000000DE05B4: 04C4C76B
	s_clause 0x1                                               // 000000DE05B8: BF850001
	scratch_load_b32 v99, off, off offset:404                  // 000000DE05BC: DC510194 637C0000
	scratch_load_b32 v107, off, off offset:432                 // 000000DE05C4: DC5101B0 6B7C0000
	s_waitcnt vmcnt(1)                                         // 000000DE05CC: BF8907F7
	v_dot2acc_f32_f16 v98, v99, v100                           // 000000DE05D0: 04C4C963
	scratch_load_b32 v99, off, off offset:408                  // 000000DE05D4: DC510198 637C0000
	s_waitcnt vmcnt(0)                                         // 000000DE05DC: BF8903F7
	v_dot2acc_f32_f16 v98, v99, v101                           // 000000DE05E0: 04C4CB63
	scratch_load_b32 v99, off, off offset:412                  // 000000DE05E4: DC51019C 637C0000
	s_waitcnt vmcnt(0)                                         // 000000DE05EC: BF8903F7
	v_dot2acc_f32_f16 v98, v99, v102                           // 000000DE05F0: 04C4CD63
	scratch_load_b32 v99, off, off offset:80                   // 000000DE05F4: DC510050 637C0000
	s_waitcnt vmcnt(0)                                         // 000000DE05FC: BF8903F7
	v_dot2acc_f32_f16 v97, v99, v118                           // 000000DE0600: 04C2ED63
	scratch_load_b32 v99, off, off offset:68                   // 000000DE0604: DC510044 637C0000
	s_waitcnt vmcnt(0)                                         // 000000DE060C: BF8903F7
	v_dot2acc_f32_f16 v97, v99, v119                           // 000000DE0610: 04C2EF63
	scratch_load_b32 v99, off, off offset:72                   // 000000DE0614: DC510048 637C0000
	s_waitcnt vmcnt(0)                                         // 000000DE061C: BF8903F7
	v_dot2acc_f32_f16 v97, v99, v120                           // 000000DE0620: 04C2F163
	scratch_load_b32 v99, off, off offset:64                   // 000000DE0624: DC510040 637C0000
	s_waitcnt vmcnt(0)                                         // 000000DE062C: BF8903F7
	v_dot2acc_f32_f16 v97, v99, v121                           // 000000DE0630: 04C2F363
	scratch_load_b32 v99, off, off offset:416                  // 000000DE0634: DC5101A0 637C0000
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000DE063C: BF890007
	v_dot2acc_f32_f16 v98, v99, v103                           // 000000DE0640: 04C4CF63
	scratch_load_b32 v99, off, off offset:420                  // 000000DE0644: DC5101A4 637C0000
	s_waitcnt vmcnt(0)                                         // 000000DE064C: BF8903F7
	v_dot2acc_f32_f16 v98, v99, v104                           // 000000DE0650: 04C4D163
	scratch_load_b32 v99, off, off offset:424                  // 000000DE0654: DC5101A8 637C0000
	s_waitcnt vmcnt(0)                                         // 000000DE065C: BF8903F7
	v_dot2acc_f32_f16 v98, v99, v105                           // 000000DE0660: 04C4D363
	scratch_load_b32 v99, off, off offset:428                  // 000000DE0664: DC5101AC 637C0000
	s_waitcnt vmcnt(0)                                         // 000000DE066C: BF8903F7
	v_dot2acc_f32_f16 v98, v99, v106                           // 000000DE0670: 04C4D563
	ds_load_b128 v[99:102], v4 offset:1312                     // 000000DE0674: DBFC0520 63000004
	ds_load_b128 v[103:106], v4 offset:1328                    // 000000DE067C: DBFC0530 67000004
	s_waitcnt lgkmcnt(1)                                       // 000000DE0684: BF89FC17
	v_dot2acc_f32_f16 v98, v107, v99                           // 000000DE0688: 04C4C76B
	scratch_load_b32 v99, off, off offset:436                  // 000000DE068C: DC5101B4 637C0000
	ds_load_b128 v[107:110], v4 offset:1536                    // 000000DE0694: DBFC0600 6B000004
	ds_load_b128 v[111:114], v4 offset:1552                    // 000000DE069C: DBFC0610 6F000004
	s_waitcnt vmcnt(0)                                         // 000000DE06A4: BF8903F7
	v_dot2acc_f32_f16 v98, v99, v100                           // 000000DE06A8: 04C4C963
	s_clause 0x1                                               // 000000DE06AC: BF850001
	scratch_load_b32 v99, off, off offset:440                  // 000000DE06B0: DC5101B8 637C0000
	scratch_load_b32 v100, off, off offset:464                 // 000000DE06B8: DC5101D0 647C0000
	s_waitcnt vmcnt(1)                                         // 000000DE06C0: BF8907F7
	v_dot2acc_f32_f16 v98, v99, v101                           // 000000DE06C4: 04C4CB63
	scratch_load_b32 v99, off, off offset:444                  // 000000DE06C8: DC5101BC 637C0000
	s_waitcnt vmcnt(0)                                         // 000000DE06D0: BF8903F7
	v_dual_dot2acc_f32_f16 v98, v99, v102 :: v_dual_mov_b32 v99, 0// 000000DE06D4: CB10CD63 62620080
	s_waitcnt lgkmcnt(1)                                       // 000000DE06DC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DE06E0: BF870001
	v_dot2acc_f32_f16 v99, v100, v107                          // 000000DE06E4: 04C6D764
	scratch_load_b32 v100, off, off offset:468                 // 000000DE06E8: DC5101D4 647C0000
	s_waitcnt vmcnt(0)                                         // 000000DE06F0: BF8903F7
	v_dot2acc_f32_f16 v99, v100, v108                          // 000000DE06F4: 04C6D964
	scratch_load_b32 v100, off, off offset:448                 // 000000DE06F8: DC5101C0 647C0000
	v_dot2acc_f32_f16 v99, v125, v109                          // 000000DE0700: 04C6DB7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DE0704: BF8700A1
	v_dot2acc_f32_f16 v99, v126, v110                          // 000000DE0708: 04C6DD7E
	s_waitcnt lgkmcnt(0)                                       // 000000DE070C: BF89FC07
	v_dot2acc_f32_f16 v99, v127, v111                          // 000000DE0710: 04C6DF7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0714: BF870091
	v_dot2acc_f32_f16 v99, v128, v112                          // 000000DE0718: 04C6E180
	v_dot2acc_f32_f16 v99, v129, v113                          // 000000DE071C: 04C6E381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DE0720: BF870001
	v_dot2acc_f32_f16 v99, v130, v114                          // 000000DE0724: 04C6E582
	ds_load_b128 v[108:111], v4 offset:1792                    // 000000DE0728: DBFC0700 6C000004
	ds_load_b128 v[112:115], v4 offset:1808                    // 000000DE0730: DBFC0710 70000004
	s_waitcnt vmcnt(0)                                         // 000000DE0738: BF8903F7
	v_dot2acc_f32_f16 v98, v100, v103                          // 000000DE073C: 04C4CF64
	scratch_load_b32 v100, off, off offset:452                 // 000000DE0740: DC5101C4 647C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0748: BF8903F7
	v_dot2acc_f32_f16 v98, v100, v104                          // 000000DE074C: 04C4D164
	scratch_load_b32 v100, off, off offset:456                 // 000000DE0750: DC5101C8 647C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0758: BF8903F7
	v_dot2acc_f32_f16 v98, v100, v105                          // 000000DE075C: 04C4D364
	scratch_load_b32 v100, off, off offset:460                 // 000000DE0760: DC5101CC 647C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0768: BF8903F7
	v_dot2acc_f32_f16 v98, v100, v106                          // 000000DE076C: 04C4D564
	ds_load_b128 v[100:103], v4 offset:1568                    // 000000DE0770: DBFC0620 64000004
	ds_load_b128 v[104:107], v4 offset:1584                    // 000000DE0778: DBFC0630 68000004
	s_waitcnt lgkmcnt(1)                                       // 000000DE0780: BF89FC17
	v_dual_dot2acc_f32_f16 v99, v131, v100 :: v_dual_mov_b32 v100, 0// 000000DE0784: CB10C983 63640080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE078C: BF870091
	v_dual_dot2acc_f32_f16 v99, v132, v101 :: v_dual_dot2acc_f32_f16 v100, v139, v108// 000000DE0790: CB18CB84 6364D98B
	v_dual_dot2acc_f32_f16 v99, v133, v102 :: v_dual_dot2acc_f32_f16 v100, v140, v109// 000000DE0798: CB18CD85 6364DB8C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DE07A0: BF8700A1
	v_dual_dot2acc_f32_f16 v99, v134, v103 :: v_dual_dot2acc_f32_f16 v100, v141, v110// 000000DE07A4: CB18CF86 6364DD8D
	s_waitcnt lgkmcnt(0)                                       // 000000DE07AC: BF89FC07
	v_dual_dot2acc_f32_f16 v99, v135, v104 :: v_dual_dot2acc_f32_f16 v100, v142, v111// 000000DE07B0: CB18D187 6364DF8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE07B8: BF870091
	v_dual_dot2acc_f32_f16 v99, v136, v105 :: v_dual_dot2acc_f32_f16 v100, v143, v112// 000000DE07BC: CB18D388 6364E18F
	v_dual_dot2acc_f32_f16 v99, v137, v106 :: v_dual_dot2acc_f32_f16 v100, v144, v113// 000000DE07C4: CB18D589 6364E390
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DE07CC: BF870001
	v_dual_dot2acc_f32_f16 v99, v138, v107 :: v_dual_dot2acc_f32_f16 v100, v145, v114// 000000DE07D0: CB18D78A 6364E591
	ds_load_b128 v[101:104], v4 offset:1824                    // 000000DE07D8: DBFC0720 65000004
	ds_load_b128 v[105:108], v4 offset:1840                    // 000000DE07E0: DBFC0730 69000004
	v_dot2acc_f32_f16 v100, v146, v115                         // 000000DE07E8: 04C8E792
	ds_load_b128 v[109:112], v4 offset:2048                    // 000000DE07EC: DBFC0800 6D000004
	ds_load_b128 v[113:116], v4 offset:2064                    // 000000DE07F4: DBFC0810 71000004
	s_waitcnt lgkmcnt(3)                                       // 000000DE07FC: BF89FC37
	v_dual_dot2acc_f32_f16 v100, v147, v101 :: v_dual_mov_b32 v101, 0// 000000DE0800: CB10CB93 64640080
	s_waitcnt lgkmcnt(1)                                       // 000000DE0808: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE080C: BF870091
	v_dual_dot2acc_f32_f16 v100, v148, v102 :: v_dual_dot2acc_f32_f16 v101, v155, v109// 000000DE0810: CB18CD94 6464DB9B
	v_dual_dot2acc_f32_f16 v100, v149, v103 :: v_dual_dot2acc_f32_f16 v101, v156, v110// 000000DE0818: CB18CF95 6464DD9C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0820: BF870091
	v_dot2acc_f32_f16 v101, v157, v111                         // 000000DE0824: 04CADF9D
	v_dot2acc_f32_f16 v101, v158, v112                         // 000000DE0828: 04CAE19E
	s_waitcnt lgkmcnt(0)                                       // 000000DE082C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0830: BF870091
	v_dot2acc_f32_f16 v101, v159, v113                         // 000000DE0834: 04CAE39F
	v_dual_dot2acc_f32_f16 v101, v160, v114 :: v_dual_dot2acc_f32_f16 v100, v150, v104// 000000DE0838: CB18E5A0 6564D196
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0840: BF870091
	v_dual_dot2acc_f32_f16 v101, v161, v115 :: v_dual_dot2acc_f32_f16 v100, v151, v105// 000000DE0844: CB18E7A1 6564D397
	v_dual_dot2acc_f32_f16 v101, v162, v116 :: v_dual_dot2acc_f32_f16 v100, v152, v106// 000000DE084C: CB18E9A2 6564D598
	ds_load_b128 v[110:113], v4 offset:2304                    // 000000DE0854: DBFC0900 6E000004
	ds_load_b128 v[114:117], v4 offset:2320                    // 000000DE085C: DBFC0910 72000004
	v_dot2acc_f32_f16 v100, v153, v107                         // 000000DE0864: 04C8D799
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DE0868: BF8700D1
	v_dot2acc_f32_f16 v100, v154, v108                         // 000000DE086C: 04C8D99A
	ds_load_b128 v[102:105], v4 offset:2080                    // 000000DE0870: DBFC0820 66000004
	ds_load_b128 v[106:109], v4 offset:2096                    // 000000DE0878: DBFC0830 6A000004
	s_waitcnt lgkmcnt(1)                                       // 000000DE0880: BF89FC17
	v_dual_dot2acc_f32_f16 v101, v163, v102 :: v_dual_mov_b32 v102, 0// 000000DE0884: CB10CDA3 65660080
	v_dual_dot2acc_f32_f16 v101, v164, v103 :: v_dual_dot2acc_f32_f16 v102, v171, v110// 000000DE088C: CB18CFA4 6566DDAB
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0894: BF870091
	v_dual_dot2acc_f32_f16 v101, v165, v104 :: v_dual_dot2acc_f32_f16 v102, v172, v111// 000000DE0898: CB18D1A5 6566DFAC
	v_dual_dot2acc_f32_f16 v101, v166, v105 :: v_dual_dot2acc_f32_f16 v102, v173, v112// 000000DE08A0: CB18D3A6 6566E1AD
	s_waitcnt lgkmcnt(0)                                       // 000000DE08A8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE08AC: BF870091
	v_dual_dot2acc_f32_f16 v101, v167, v106 :: v_dual_dot2acc_f32_f16 v102, v174, v113// 000000DE08B0: CB18D5A7 6566E3AE
	v_dot2acc_f32_f16 v102, v175, v114                         // 000000DE08B8: 04CCE5AF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE08BC: BF870091
	v_dot2acc_f32_f16 v102, v176, v115                         // 000000DE08C0: 04CCE7B0
	v_dual_dot2acc_f32_f16 v102, v177, v116 :: v_dual_dot2acc_f32_f16 v101, v168, v107// 000000DE08C4: CB18E9B1 6664D7A8
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DE08CC: BF870001
	v_dual_dot2acc_f32_f16 v102, v178, v117 :: v_dual_dot2acc_f32_f16 v101, v169, v108// 000000DE08D0: CB18EBB2 6664D9A9
	ds_load_b128 v[111:114], v4 offset:2560                    // 000000DE08D8: DBFC0A00 6F000004
	ds_load_b128 v[115:118], v4 offset:2576                    // 000000DE08E0: DBFC0A10 73000004
	v_dot2acc_f32_f16 v101, v170, v109                         // 000000DE08E8: 04CADBAA
	ds_load_b128 v[103:106], v4 offset:2336                    // 000000DE08EC: DBFC0920 67000004
	ds_load_b128 v[107:110], v4 offset:2352                    // 000000DE08F4: DBFC0930 6B000004
	s_waitcnt lgkmcnt(1)                                       // 000000DE08FC: BF89FC17
	v_dot2acc_f32_f16 v102, v179, v103                         // 000000DE0900: 04CCCFB3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0904: BF870091
	v_dot2acc_f32_f16 v102, v180, v104                         // 000000DE0908: 04CCD1B4
	v_dot2acc_f32_f16 v102, v181, v105                         // 000000DE090C: 04CCD3B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DE0910: BF8700A1
	v_dot2acc_f32_f16 v102, v182, v106                         // 000000DE0914: 04CCD5B6
	s_waitcnt lgkmcnt(0)                                       // 000000DE0918: BF89FC07
	v_dot2acc_f32_f16 v102, v183, v107                         // 000000DE091C: 04CCD7B7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0920: BF870091
	v_dot2acc_f32_f16 v102, v184, v108                         // 000000DE0924: 04CCD9B8
	v_dual_dot2acc_f32_f16 v102, v185, v109 :: v_dual_mov_b32 v103, 0// 000000DE0928: CB10DBB9 66660080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DE0930: BF8700C1
	v_dual_dot2acc_f32_f16 v102, v186, v110 :: v_dual_dot2acc_f32_f16 v103, v187, v111// 000000DE0934: CB18DDBA 6666DFBB
	ds_load_b128 v[104:107], v4 offset:2592                    // 000000DE093C: DBFC0A20 68000004
	ds_load_b128 v[108:111], v4 offset:2608                    // 000000DE0944: DBFC0A30 6C000004
	v_dot2acc_f32_f16 v103, v188, v112                         // 000000DE094C: 04CEE1BC
	v_dot2acc_f32_f16 v103, v189, v113                         // 000000DE0950: 04CEE3BD
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0954: BF870091
	v_dot2acc_f32_f16 v103, v190, v114                         // 000000DE0958: 04CEE5BE
	v_dot2acc_f32_f16 v103, v191, v115                         // 000000DE095C: 04CEE7BF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0960: BF870091
	v_dot2acc_f32_f16 v103, v192, v116                         // 000000DE0964: 04CEE9C0
	v_dot2acc_f32_f16 v103, v193, v117                         // 000000DE0968: 04CEEBC1
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DE096C: BF870001
	v_dot2acc_f32_f16 v103, v194, v118                         // 000000DE0970: 04CEEDC2
	ds_load_b128 v[112:115], v4 offset:2816                    // 000000DE0974: DBFC0B00 70000004
	ds_load_b128 v[116:119], v4 offset:2832                    // 000000DE097C: DBFC0B10 74000004
	s_waitcnt lgkmcnt(3)                                       // 000000DE0984: BF89FC37
	v_dual_dot2acc_f32_f16 v103, v195, v104 :: v_dual_mov_b32 v104, 0// 000000DE0988: CB10D1C3 67680080
	s_waitcnt lgkmcnt(1)                                       // 000000DE0990: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0994: BF870091
	v_dot2acc_f32_f16 v104, v203, v112                         // 000000DE0998: 04D0E1CB
	v_dot2acc_f32_f16 v104, v204, v113                         // 000000DE099C: 04D0E3CC
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE09A0: BF870091
	v_dot2acc_f32_f16 v104, v205, v114                         // 000000DE09A4: 04D0E5CD
	v_dot2acc_f32_f16 v104, v206, v115                         // 000000DE09A8: 04D0E7CE
	s_waitcnt lgkmcnt(0)                                       // 000000DE09AC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE09B0: BF870091
	v_dot2acc_f32_f16 v104, v207, v116                         // 000000DE09B4: 04D0E9CF
	v_dot2acc_f32_f16 v104, v208, v117                         // 000000DE09B8: 04D0EBD0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE09BC: BF870091
	v_dual_dot2acc_f32_f16 v104, v209, v118 :: v_dual_dot2acc_f32_f16 v103, v196, v105// 000000DE09C0: CB18EDD1 6866D3C4
	v_dual_dot2acc_f32_f16 v104, v210, v119 :: v_dual_dot2acc_f32_f16 v103, v197, v106// 000000DE09C8: CB18EFD2 6866D5C5
	ds_load_b128 v[113:116], v4 offset:3072                    // 000000DE09D0: DBFC0C00 71000004
	ds_load_b128 v[117:120], v4 offset:3088                    // 000000DE09D8: DBFC0C10 75000004
	v_dot2acc_f32_f16 v103, v198, v107                         // 000000DE09E0: 04CED7C6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE09E4: BF870091
	v_dot2acc_f32_f16 v103, v199, v108                         // 000000DE09E8: 04CED9C7
	v_dot2acc_f32_f16 v103, v200, v109                         // 000000DE09EC: 04CEDBC8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE09F0: BF870091
	v_dot2acc_f32_f16 v103, v201, v110                         // 000000DE09F4: 04CEDDC9
	v_dot2acc_f32_f16 v103, v202, v111                         // 000000DE09F8: 04CEDFCA
	ds_load_b128 v[105:108], v4 offset:2848                    // 000000DE09FC: DBFC0B20 69000004
	ds_load_b128 v[109:112], v4 offset:2864                    // 000000DE0A04: DBFC0B30 6D000004
	s_waitcnt lgkmcnt(1)                                       // 000000DE0A0C: BF89FC17
	v_dot2acc_f32_f16 v104, v211, v105                         // 000000DE0A10: 04D0D3D3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0A14: BF870091
	v_dot2acc_f32_f16 v104, v212, v106                         // 000000DE0A18: 04D0D5D4
	v_dot2acc_f32_f16 v104, v213, v107                         // 000000DE0A1C: 04D0D7D5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DE0A20: BF8700A1
	v_dot2acc_f32_f16 v104, v214, v108                         // 000000DE0A24: 04D0D9D6
	s_waitcnt lgkmcnt(0)                                       // 000000DE0A28: BF89FC07
	v_dot2acc_f32_f16 v104, v215, v109                         // 000000DE0A2C: 04D0DBD7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0A30: BF870091
	v_dot2acc_f32_f16 v104, v216, v110                         // 000000DE0A34: 04D0DDD8
	v_dual_dot2acc_f32_f16 v104, v217, v111 :: v_dual_mov_b32 v105, 0// 000000DE0A38: CB10DFD9 68680080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DE0A40: BF8700C1
	v_dual_dot2acc_f32_f16 v104, v218, v112 :: v_dual_dot2acc_f32_f16 v105, v219, v113// 000000DE0A44: CB18E1DA 6868E3DB
	ds_load_b128 v[106:109], v4 offset:3104                    // 000000DE0A4C: DBFC0C20 6A000004
	ds_load_b128 v[110:113], v4 offset:3120                    // 000000DE0A54: DBFC0C30 6E000004
	v_dot2acc_f32_f16 v105, v220, v114                         // 000000DE0A5C: 04D2E5DC
	v_dot2acc_f32_f16 v105, v221, v115                         // 000000DE0A60: 04D2E7DD
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0A64: BF870091
	v_dot2acc_f32_f16 v105, v222, v116                         // 000000DE0A68: 04D2E9DE
	v_dot2acc_f32_f16 v105, v223, v117                         // 000000DE0A6C: 04D2EBDF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0A70: BF870091
	v_dual_dot2acc_f32_f16 v105, v224, v118 :: v_dual_mov_b32 v118, 0// 000000DE0A74: CB10EDE0 69760080
	v_dot2acc_f32_f16 v105, v225, v119                         // 000000DE0A7C: 04D2EFE1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DE0A80: BF8700A1
	v_dual_dot2acc_f32_f16 v105, v226, v120 :: v_dual_mov_b32 v120, 0// 000000DE0A84: CB10F1E2 69780080
	s_waitcnt lgkmcnt(1)                                       // 000000DE0A8C: BF89FC17
	v_dot2acc_f32_f16 v105, v227, v106                         // 000000DE0A90: 04D2D5E3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0A94: BF870091
	v_dot2acc_f32_f16 v105, v228, v107                         // 000000DE0A98: 04D2D7E4
	v_dot2acc_f32_f16 v105, v229, v108                         // 000000DE0A9C: 04D2D9E5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DE0AA0: BF8700D1
	v_dot2acc_f32_f16 v105, v230, v109                         // 000000DE0AA4: 04D2DBE6
	ds_load_b128 v[106:109], v4 offset:3328                    // 000000DE0AA8: DBFC0D00 6A000004
	ds_load_b128 v[114:117], v4 offset:3344                    // 000000DE0AB0: DBFC0D10 72000004
	s_waitcnt lgkmcnt(2)                                       // 000000DE0AB8: BF89FC27
	v_dot2acc_f32_f16 v105, v231, v110                         // 000000DE0ABC: 04D2DDE7
	v_dot2acc_f32_f16 v105, v232, v111                         // 000000DE0AC0: 04D2DFE8
	s_waitcnt lgkmcnt(1)                                       // 000000DE0AC4: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0AC8: BF870091
	v_dual_dot2acc_f32_f16 v105, v233, v112 :: v_dual_dot2acc_f32_f16 v118, v235, v106// 000000DE0ACC: CB18E1E9 6976D5EB
	v_dual_dot2acc_f32_f16 v105, v234, v113 :: v_dual_dot2acc_f32_f16 v118, v236, v107// 000000DE0AD4: CB18E3EA 6976D7EC
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0ADC: BF870091
	v_dot2acc_f32_f16 v118, v237, v108                         // 000000DE0AE0: 04ECD9ED
	v_dot2acc_f32_f16 v118, v238, v109                         // 000000DE0AE4: 04ECDBEE
	ds_load_b128 v[106:109], v4 offset:3360                    // 000000DE0AE8: DBFC0D20 6A000004
	ds_load_b128 v[110:113], v4 offset:3376                    // 000000DE0AF0: DBFC0D30 6E000004
	s_waitcnt lgkmcnt(2)                                       // 000000DE0AF8: BF89FC27
	v_dot2acc_f32_f16 v118, v239, v114                         // 000000DE0AFC: 04ECE5EF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0B00: BF870091
	v_dot2acc_f32_f16 v118, v240, v115                         // 000000DE0B04: 04ECE7F0
	v_dot2acc_f32_f16 v118, v241, v116                         // 000000DE0B08: 04ECE9F1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DE0B0C: BF8700A1
	v_dot2acc_f32_f16 v118, v242, v117                         // 000000DE0B10: 04ECEBF2
	s_waitcnt lgkmcnt(1)                                       // 000000DE0B14: BF89FC17
	v_dot2acc_f32_f16 v118, v243, v106                         // 000000DE0B18: 04ECD5F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0B1C: BF870091
	v_dot2acc_f32_f16 v118, v244, v107                         // 000000DE0B20: 04ECD7F4
	v_dot2acc_f32_f16 v118, v245, v108                         // 000000DE0B24: 04ECD9F5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DE0B28: BF8700D1
	v_dot2acc_f32_f16 v118, v246, v109                         // 000000DE0B2C: 04ECDBF6
	ds_load_b128 v[106:109], v4 offset:3584                    // 000000DE0B30: DBFC0E00 6A000004
	ds_load_b128 v[114:117], v4 offset:3600                    // 000000DE0B38: DBFC0E10 72000004
	s_waitcnt lgkmcnt(2)                                       // 000000DE0B40: BF89FC27
	v_dot2acc_f32_f16 v118, v247, v110                         // 000000DE0B44: 04ECDDF7
	v_dot2acc_f32_f16 v118, v248, v111                         // 000000DE0B48: 04ECDFF8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DE0B4C: BF8700A1
	v_dual_dot2acc_f32_f16 v118, v249, v112 :: v_dual_mov_b32 v119, 0// 000000DE0B50: CB10E1F9 76760080
	s_waitcnt lgkmcnt(1)                                       // 000000DE0B58: BF89FC17
	v_dual_dot2acc_f32_f16 v118, v250, v113 :: v_dual_dot2acc_f32_f16 v119, v251, v106// 000000DE0B5C: CB18E3FA 7676D5FB
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0B64: BF870091
	v_dot2acc_f32_f16 v119, v252, v107                         // 000000DE0B68: 04EED7FC
	v_dot2acc_f32_f16 v119, v253, v108                         // 000000DE0B6C: 04EED9FD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DE0B70: BF8700D1
	v_dot2acc_f32_f16 v119, v254, v109                         // 000000DE0B74: 04EEDBFE
	ds_load_b128 v[106:109], v4 offset:3616                    // 000000DE0B78: DBFC0E20 6A000004
	ds_load_b128 v[110:113], v4 offset:3632                    // 000000DE0B80: DBFC0E30 6E000004
	s_waitcnt lgkmcnt(2)                                       // 000000DE0B88: BF89FC27
	v_dot2acc_f32_f16 v119, v255, v114                         // 000000DE0B8C: 04EEE5FF
	v_dot2acc_f32_f16 v119, v27, v115                          // 000000DE0B90: 04EEE71B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0B94: BF870091
	v_dot2acc_f32_f16 v119, v1, v116                           // 000000DE0B98: 04EEE901
	v_dot2acc_f32_f16 v119, v2, v117                           // 000000DE0B9C: 04EEEB02
	s_waitcnt lgkmcnt(1)                                       // 000000DE0BA0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0BA4: BF870091
	v_dot2acc_f32_f16 v119, v28, v106                          // 000000DE0BA8: 04EED51C
	v_dot2acc_f32_f16 v119, v0, v107                           // 000000DE0BAC: 04EED700
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0BB0: BF870091
	v_dot2acc_f32_f16 v119, v29, v108                          // 000000DE0BB4: 04EED91D
	v_dot2acc_f32_f16 v119, v30, v109                          // 000000DE0BB8: 04EEDB1E
	ds_load_b128 v[106:109], v4 offset:3840                    // 000000DE0BBC: DBFC0F00 6A000004
	ds_load_b128 v[114:117], v4 offset:3856                    // 000000DE0BC4: DBFC0F10 72000004
	s_waitcnt lgkmcnt(2)                                       // 000000DE0BCC: BF89FC27
	v_dot2acc_f32_f16 v119, v6, v110                           // 000000DE0BD0: 04EEDD06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DE0BD4: BF8700A1
	v_dot2acc_f32_f16 v119, v31, v111                          // 000000DE0BD8: 04EEDF1F
	s_waitcnt lgkmcnt(1)                                       // 000000DE0BDC: BF89FC17
	v_dual_dot2acc_f32_f16 v119, v7, v112 :: v_dual_dot2acc_f32_f16 v120, v8, v106// 000000DE0BE0: CB18E107 7778D508
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0BE8: BF870091
	v_dual_dot2acc_f32_f16 v119, v32, v113 :: v_dual_dot2acc_f32_f16 v120, v33, v107// 000000DE0BEC: CB18E320 7778D721
	v_dot2acc_f32_f16 v120, v34, v108                          // 000000DE0BF4: 04F0D922
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DE0BF8: BF8700D1
	v_dot2acc_f32_f16 v120, v35, v109                          // 000000DE0BFC: 04F0DB23
	ds_load_b128 v[106:109], v4 offset:3872                    // 000000DE0C00: DBFC0F20 6A000004
	ds_load_b128 v[110:113], v4 offset:3888                    // 000000DE0C08: DBFC0F30 6E000004
	s_waitcnt lgkmcnt(2)                                       // 000000DE0C10: BF89FC27
	v_dot2acc_f32_f16 v120, v36, v114                          // 000000DE0C14: 04F0E524
	v_dot2acc_f32_f16 v120, v37, v115                          // 000000DE0C18: 04F0E725
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0C1C: BF870091
	v_dot2acc_f32_f16 v120, v38, v116                          // 000000DE0C20: 04F0E926
	v_dot2acc_f32_f16 v120, v39, v117                          // 000000DE0C24: 04F0EB27
	s_waitcnt lgkmcnt(1)                                       // 000000DE0C28: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0C2C: BF870091
	v_dot2acc_f32_f16 v120, v40, v106                          // 000000DE0C30: 04F0D528
	v_dot2acc_f32_f16 v120, v9, v107                           // 000000DE0C34: 04F0D709
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0C38: BF870091
	v_dot2acc_f32_f16 v120, v10, v108                          // 000000DE0C3C: 04F0D90A
	v_dot2acc_f32_f16 v120, v11, v109                          // 000000DE0C40: 04F0DB0B
	ds_load_b128 v[106:109], v4 offset:4096                    // 000000DE0C44: DBFC1000 6A000004
	ds_load_b128 v[114:117], v4 offset:4112                    // 000000DE0C4C: DBFC1010 72000004
	s_waitcnt lgkmcnt(2)                                       // 000000DE0C54: BF89FC27
	v_dot2acc_f32_f16 v120, v12, v110                          // 000000DE0C58: 04F0DD0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0C5C: BF870091
	v_dot2acc_f32_f16 v120, v13, v111                          // 000000DE0C60: 04F0DF0D
	v_dual_dot2acc_f32_f16 v120, v14, v112 :: v_dual_mov_b32 v121, 0// 000000DE0C64: CB10E10E 78780080
	s_waitcnt lgkmcnt(1)                                       // 000000DE0C6C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0C70: BF870091
	v_dual_dot2acc_f32_f16 v120, v15, v113 :: v_dual_dot2acc_f32_f16 v121, v16, v106// 000000DE0C74: CB18E30F 7878D510
	v_dot2acc_f32_f16 v121, v17, v107                          // 000000DE0C7C: 04F2D711
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0C80: BF870091
	v_dot2acc_f32_f16 v121, v18, v108                          // 000000DE0C84: 04F2D912
	v_dot2acc_f32_f16 v121, v19, v109                          // 000000DE0C88: 04F2DB13
	ds_load_b128 v[106:109], v4 offset:4128                    // 000000DE0C8C: DBFC1020 6A000004
	ds_load_b128 v[110:113], v4 offset:4144                    // 000000DE0C94: DBFC1030 6E000004
	s_waitcnt lgkmcnt(2)                                       // 000000DE0C9C: BF89FC27
	v_dot2acc_f32_f16 v121, v20, v114                          // 000000DE0CA0: 04F2E514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0CA4: BF870091
	v_dot2acc_f32_f16 v121, v21, v115                          // 000000DE0CA8: 04F2E715
	v_dot2acc_f32_f16 v121, v22, v116                          // 000000DE0CAC: 04F2E916
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DE0CB0: BF8700A1
	v_dot2acc_f32_f16 v121, v23, v117                          // 000000DE0CB4: 04F2EB17
	s_waitcnt lgkmcnt(1)                                       // 000000DE0CB8: BF89FC17
	v_dot2acc_f32_f16 v121, v24, v106                          // 000000DE0CBC: 04F2D518
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0CC0: BF870091
	v_dot2acc_f32_f16 v121, v41, v107                          // 000000DE0CC4: 04F2D729
	v_dot2acc_f32_f16 v121, v42, v108                          // 000000DE0CC8: 04F2D92A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DE0CCC: BF8700D1
	v_dot2acc_f32_f16 v121, v43, v109                          // 000000DE0CD0: 04F2DB2B
	ds_load_b128 v[106:109], v4 offset:4352                    // 000000DE0CD4: DBFC1100 6A000004
	ds_load_b128 v[114:117], v4 offset:4368                    // 000000DE0CDC: DBFC1110 72000004
	s_waitcnt lgkmcnt(2)                                       // 000000DE0CE4: BF89FC27
	v_dot2acc_f32_f16 v121, v44, v110                          // 000000DE0CE8: 04F2DD2C
	v_dot2acc_f32_f16 v121, v45, v111                          // 000000DE0CEC: 04F2DF2D
	s_waitcnt lgkmcnt(1)                                       // 000000DE0CF0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0CF4: BF870091
	v_dual_dot2acc_f32_f16 v121, v46, v112 :: v_dual_dot2acc_f32_f16 v122, v48, v106// 000000DE0CF8: CB18E12E 797AD530
	v_dual_dot2acc_f32_f16 v121, v47, v113 :: v_dual_dot2acc_f32_f16 v122, v49, v107// 000000DE0D00: CB18E32F 797AD731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0D08: BF870091
	v_dot2acc_f32_f16 v122, v50, v108                          // 000000DE0D0C: 04F4D932
	v_dot2acc_f32_f16 v122, v51, v109                          // 000000DE0D10: 04F4DB33
	ds_load_b128 v[106:109], v4 offset:4384                    // 000000DE0D14: DBFC1120 6A000004
	ds_load_b128 v[110:113], v4 offset:4400                    // 000000DE0D1C: DBFC1130 6E000004
	s_waitcnt lgkmcnt(2)                                       // 000000DE0D24: BF89FC27
	v_dot2acc_f32_f16 v122, v52, v114                          // 000000DE0D28: 04F4E534
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0D2C: BF870091
	v_dot2acc_f32_f16 v122, v53, v115                          // 000000DE0D30: 04F4E735
	v_dot2acc_f32_f16 v122, v54, v116                          // 000000DE0D34: 04F4E936
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DE0D38: BF8700A1
	v_dot2acc_f32_f16 v122, v55, v117                          // 000000DE0D3C: 04F4EB37
	s_waitcnt lgkmcnt(1)                                       // 000000DE0D40: BF89FC17
	v_dot2acc_f32_f16 v122, v56, v106                          // 000000DE0D44: 04F4D538
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0D48: BF870091
	v_dot2acc_f32_f16 v122, v57, v107                          // 000000DE0D4C: 04F4D739
	v_dot2acc_f32_f16 v122, v58, v108                          // 000000DE0D50: 04F4D93A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DE0D54: BF8700D1
	v_dot2acc_f32_f16 v122, v59, v109                          // 000000DE0D58: 04F4DB3B
	ds_load_b128 v[106:109], v4 offset:4608                    // 000000DE0D5C: DBFC1200 6A000004
	ds_load_b128 v[114:117], v4 offset:4624                    // 000000DE0D64: DBFC1210 72000004
	s_waitcnt lgkmcnt(2)                                       // 000000DE0D6C: BF89FC27
	v_dot2acc_f32_f16 v122, v60, v110                          // 000000DE0D70: 04F4DD3C
	v_dot2acc_f32_f16 v122, v61, v111                          // 000000DE0D74: 04F4DF3D
	s_waitcnt lgkmcnt(1)                                       // 000000DE0D78: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0D7C: BF870091
	v_dual_dot2acc_f32_f16 v122, v62, v112 :: v_dual_dot2acc_f32_f16 v123, v64, v106// 000000DE0D80: CB18E13E 7A7AD540
	v_dual_dot2acc_f32_f16 v122, v63, v113 :: v_dual_dot2acc_f32_f16 v123, v65, v107// 000000DE0D88: CB18E33F 7A7AD741
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0D90: BF870091
	v_dot2acc_f32_f16 v123, v66, v108                          // 000000DE0D94: 04F6D942
	v_dot2acc_f32_f16 v123, v67, v109                          // 000000DE0D98: 04F6DB43
	ds_load_b128 v[106:109], v4 offset:4864                    // 000000DE0D9C: DBFC1300 6A000004
	ds_load_b128 v[110:113], v4 offset:4880                    // 000000DE0DA4: DBFC1310 6E000004
	s_waitcnt lgkmcnt(1)                                       // 000000DE0DAC: BF89FC17
	v_dot2acc_f32_f16 v124, v80, v106                          // 000000DE0DB0: 04F8D550
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0DB4: BF870091
	v_dot2acc_f32_f16 v124, v81, v107                          // 000000DE0DB8: 04F8D751
	v_dot2acc_f32_f16 v124, v82, v108                          // 000000DE0DBC: 04F8D952
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DE0DC0: BF8700A1
	v_dot2acc_f32_f16 v124, v83, v109                          // 000000DE0DC4: 04F8DB53
	s_waitcnt lgkmcnt(0)                                       // 000000DE0DC8: BF89FC07
	v_dot2acc_f32_f16 v124, v84, v110                          // 000000DE0DCC: 04F8DD54
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0DD0: BF870091
	v_dual_dot2acc_f32_f16 v123, v68, v114 :: v_dual_dot2acc_f32_f16 v124, v85, v111// 000000DE0DD4: CB18E544 7B7CDF55
	v_dual_dot2acc_f32_f16 v123, v69, v115 :: v_dual_dot2acc_f32_f16 v124, v86, v112// 000000DE0DDC: CB18E745 7B7CE156
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0DE4: BF870091
	v_dual_dot2acc_f32_f16 v123, v70, v116 :: v_dual_dot2acc_f32_f16 v124, v87, v113// 000000DE0DE8: CB18E946 7B7CE357
	v_dot2acc_f32_f16 v123, v71, v117                          // 000000DE0DF0: 04F6EB47
	ds_load_b128 v[106:109], v4 offset:4640                    // 000000DE0DF4: DBFC1220 6A000004
	ds_load_b128 v[114:117], v4 offset:4656                    // 000000DE0DFC: DBFC1230 72000004
	s_waitcnt lgkmcnt(1)                                       // 000000DE0E04: BF89FC17
	v_dot2acc_f32_f16 v123, v72, v106                          // 000000DE0E08: 04F6D548
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0E0C: BF870091
	v_dot2acc_f32_f16 v123, v73, v107                          // 000000DE0E10: 04F6D749
	v_dot2acc_f32_f16 v123, v74, v108                          // 000000DE0E14: 04F6D94A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DE0E18: BF870001
	v_dot2acc_f32_f16 v123, v75, v109                          // 000000DE0E1C: 04F6DB4B
	ds_load_b128 v[106:109], v4 offset:4896                    // 000000DE0E20: DBFC1320 6A000004
	ds_load_b128 v[110:113], v4 offset:4912                    // 000000DE0E28: DBFC1330 6E000004
	scratch_load_b32 v4, off, off                              // 000000DE0E30: DC510000 047C0000
	s_waitcnt lgkmcnt(1)                                       // 000000DE0E38: BF89FC17
	v_dot2acc_f32_f16 v124, v88, v106                          // 000000DE0E3C: 04F8D558
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0E40: BF870091
	v_dot2acc_f32_f16 v124, v89, v107                          // 000000DE0E44: 04F8D759
	v_dot2acc_f32_f16 v124, v90, v108                          // 000000DE0E48: 04F8D95A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DE0E4C: BF8700A1
	v_dot2acc_f32_f16 v124, v91, v109                          // 000000DE0E50: 04F8DB5B
	s_waitcnt lgkmcnt(0)                                       // 000000DE0E54: BF89FC07
	v_dot2acc_f32_f16 v124, v92, v110                          // 000000DE0E58: 04F8DD5C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0E5C: BF870091
	v_dual_dot2acc_f32_f16 v123, v76, v114 :: v_dual_dot2acc_f32_f16 v124, v93, v111// 000000DE0E60: CB18E54C 7B7CDF5D
	v_dual_dot2acc_f32_f16 v123, v77, v115 :: v_dual_dot2acc_f32_f16 v124, v94, v112// 000000DE0E68: CB18E74D 7B7CE15E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DE0E70: BF870001
	v_dual_dot2acc_f32_f16 v123, v78, v116 :: v_dual_dot2acc_f32_f16 v124, v95, v113// 000000DE0E74: CB18E94E 7B7CE35F
	s_waitcnt vmcnt(0)                                         // 000000DE0E7C: BF8903F7
	v_fma_f32 v4, v4, v25, 0                                   // 000000DE0E80: D6130004 02023304
	scratch_load_b32 v25, off, off offset:4                    // 000000DE0E88: DC510004 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0E90: BF8903F7
	v_fmac_f32_e32 v4, v25, v5                                 // 000000DE0E94: 56080B19
	scratch_load_b32 v5, off, off offset:8                     // 000000DE0E98: DC510008 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0EA0: BF8903F7
	v_dual_dot2acc_f32_f16 v123, v79, v117 :: v_dual_fmac_f32 v4, v5, v96// 000000DE0EA4: CB00EB4F 7B04C105
	scratch_load_b32 v5, off, off offset:12                    // 000000DE0EAC: DC51000C 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0EB4: BF8903F7
	v_fmac_f32_e32 v4, v5, v26                                 // 000000DE0EB8: 56083505
	scratch_load_b32 v5, off, off offset:16                    // 000000DE0EBC: DC510010 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0EC4: BF8903F7
	v_fmac_f32_e32 v4, v5, v97                                 // 000000DE0EC8: 5608C305
	scratch_load_b32 v5, off, off offset:20                    // 000000DE0ECC: DC510014 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0ED4: BF8903F7
	v_fmac_f32_e32 v4, v5, v98                                 // 000000DE0ED8: 5608C505
	scratch_load_b32 v5, off, off offset:24                    // 000000DE0EDC: DC510018 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0EE4: BF8903F7
	v_fmac_f32_e32 v4, v5, v99                                 // 000000DE0EE8: 5608C705
	scratch_load_b32 v5, off, off offset:28                    // 000000DE0EEC: DC51001C 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0EF4: BF8903F7
	v_fmac_f32_e32 v4, v5, v100                                // 000000DE0EF8: 5608C905
	scratch_load_b32 v5, off, off offset:32                    // 000000DE0EFC: DC510020 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0F04: BF8903F7
	v_fmac_f32_e32 v4, v5, v101                                // 000000DE0F08: 5608CB05
	scratch_load_b32 v5, off, off offset:36                    // 000000DE0F0C: DC510024 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0F14: BF8903F7
	v_fmac_f32_e32 v4, v5, v102                                // 000000DE0F18: 5608CD05
	scratch_load_b32 v5, off, off offset:40                    // 000000DE0F1C: DC510028 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0F24: BF8903F7
	v_fmac_f32_e32 v4, v5, v103                                // 000000DE0F28: 5608CF05
	scratch_load_b32 v5, off, off offset:44                    // 000000DE0F2C: DC51002C 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0F34: BF8903F7
	v_fmac_f32_e32 v4, v5, v104                                // 000000DE0F38: 5608D105
	scratch_load_b32 v5, off, off offset:48                    // 000000DE0F3C: DC510030 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0F44: BF8903F7
	v_fmac_f32_e32 v4, v5, v105                                // 000000DE0F48: 5608D305
	scratch_load_b32 v5, off, off offset:52                    // 000000DE0F4C: DC510034 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0F54: BF8903F7
	v_fmac_f32_e32 v4, v5, v118                                // 000000DE0F58: 5608ED05
	scratch_load_b32 v5, off, off offset:56                    // 000000DE0F5C: DC510038 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0F64: BF8903F7
	v_fmac_f32_e32 v4, v5, v119                                // 000000DE0F68: 5608EF05
	scratch_load_b32 v5, off, off offset:60                    // 000000DE0F6C: DC51003C 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0F74: BF8903F7
	v_fmac_f32_e32 v4, v5, v120                                // 000000DE0F78: 5608F105
	scratch_load_b32 v5, off, off offset:344                   // 000000DE0F7C: DC510158 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0F84: BF8903F7
	v_fmac_f32_e32 v4, v5, v121                                // 000000DE0F88: 5608F305
	scratch_load_b32 v5, off, off offset:348                   // 000000DE0F8C: DC51015C 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0F94: BF8903F7
	v_fmac_f32_e32 v4, v5, v122                                // 000000DE0F98: 5608F505
	scratch_load_b32 v5, off, off offset:352                   // 000000DE0F9C: DC510160 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0FA4: BF8903F7
	v_fmac_f32_e32 v4, v5, v123                                // 000000DE0FA8: 5608F705
	scratch_load_b32 v5, off, off offset:356                   // 000000DE0FAC: DC510164 057C0000
	s_waitcnt vmcnt(0)                                         // 000000DE0FB4: BF8903F7
	v_fmac_f32_e32 v4, v5, v124                                // 000000DE0FB8: 5608F905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE0FBC: BF870091
	v_mov_b32_dpp v5, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DE0FC0: 7E0A02FA FF016104
	v_add_f32_e32 v4, v4, v5                                   // 000000DE0FC8: 06080B04
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DE0FCC: BF870001
	v_mov_b32_dpp v5, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DE0FD0: 7E0A02FA FF016204
	s_and_saveexec_b32 s2, vcc_lo                              // 000000DE0FD8: BE82206A
	s_cbranch_execz 64504                                      // 000000DE0FDC: BFA5FBF8 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x68c0>
	scratch_load_b64 v[96:97], off, off offset:472             // 000000DE0FE0: DC5501D8 607C0000
	s_lshl_b32 s4, s1, 2                                       // 000000DE0FE8: 84048201
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DE0FEC: BF870009
	v_dual_add_f32 v4, v4, v5 :: v_dual_mov_b32 v25, s4        // 000000DE0FF0: C9100B04 04180004
	ds_load_b32 v25, v25 offset:20480                          // 000000DE0FF8: D8D85000 19000019
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000DE1000: BF890007
	v_mad_i64_i32 v[25:26], null, 0x1400, v25, v[96:97]        // 000000DE1004: D6FF7C19 058232FF 00001400
	global_store_b32 v[25:26], v4, off                         // 000000DE1010: DC6A0000 007C0419
	s_branch 64489                                             // 000000DE1018: BFA0FBE9 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x68c0>
	scratch_load_b32 v77, off, off offset:480                  // 000000DE101C: DC5101E0 4D7C0000
	s_mul_hi_i32 s1, s0, 0x66666667                            // 000000DE1024: 9701FF00 66666667
	s_waitcnt vmcnt(0)                                         // 000000DE102C: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 000000DE1030: BC7C0000
	buffer_gl1_inv                                             // 000000DE1034: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DE103C: E0AC0000 00000000
	s_lshr_b32 s2, s1, 31                                      // 000000DE1044: 85029F01
	s_lshr_b32 s1, s1, 2                                       // 000000DE1048: 85018201
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000DE104C: BF8704D9
	s_add_i32 s1, s1, s2                                       // 000000DE1050: 81010201
	s_barrier                                                  // 000000DE1054: BFBD0000
	s_mul_i32 s1, s1, 10                                       // 000000DE1058: 96018A01
	buffer_gl0_inv                                             // 000000DE105C: E0AC0000 00000000
	s_sub_i32 s0, s0, s1                                       // 000000DE1064: 81800100
	s_bfe_u32 s1, s0, 0x10007                                  // 000000DE1068: 9301FF00 00010007
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DE1070: BF870499
	s_add_i32 s0, s0, s1                                       // 000000DE1074: 81000100
	s_bfe_i32 s0, s0, 0x80000                                  // 000000DE1078: 9380FF00 00080000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DE1080: BF870499
	s_sext_i32_i16 s0, s0                                      // 000000DE1084: BE800F00
	s_ashr_i32 s8, s0, 1                                       // 000000DE1088: 86088100
	s_mov_b32 s0, exec_lo                                      // 000000DE108C: BE80007E
	.long 0xd4cc007e                                           // 000000DE1090: D4CC007E
	v_cndmask_b32_e32 v1, s3, v77, vcc_lo                      // 000000DE1094: 02029A03
	s_cbranch_execz 24                                         // 000000DE1098: BFA50018 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x79fc>
	v_dual_mov_b32 v3, 1 :: v_dual_lshlrev_b32 v2, 2, v77      // 000000DE109C: CA220081 03029A82
	ds_load_b32 v0, v2 offset:20480                            // 000000DE10A4: D8D85000 00000002
	s_waitcnt lgkmcnt(0)                                       // 000000DE10AC: BF89FC07
	v_mad_u64_u32 v[0:1], null, v0, 5, s[8:9]                  // 000000DE10B0: D6FE7C00 00210B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE10B8: BF870091
	v_ashrrev_i32_e32 v1, 31, v0                               // 000000DE10BC: 3402009F
	.long 0xd73c0000                                           // 000000DE10C0: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000DE10C4: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE10C8: BF870091
	.long 0xd7006a00                                           // 000000DE10CC: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000DE10D0: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000DE10D4: D5207C01 01AA0211
	global_atomic_add_u32 v0, v[0:1], v3, off glc              // 000000DE10DC: DCD64000 007C0300
	s_waitcnt vmcnt(0)                                         // 000000DE10E4: BF8903F7
	v_cmp_eq_u32_e32 vcc_lo, 3, v0                             // 000000DE10E8: 7C940083
	v_cndmask_b32_e64 v0, 0, 1, vcc_lo                         // 000000DE10EC: D5010000 01A90280
	ds_store_b32 v2, v0 offset:20488                           // 000000DE10F4: D8345008 00000002
	s_or_b32 exec_lo, exec_lo, s0                              // 000000DE10FC: 8C7E007E
	v_lshrrev_b32_e32 v0, 5, v77                               // 000000DE1100: 32009A85
	s_waitcnt lgkmcnt(0)                                       // 000000DE1104: BF89FC07
	s_barrier                                                  // 000000DE1108: BFBD0000
	buffer_gl0_inv                                             // 000000DE110C: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 000000DE1114: BE80007E
	.long 0xd4c4007e                                           // 000000DE1118: D4C4007E
	v_cndmask_b32_e32 v1, s3, v0, vcc_lo                       // 000000DE111C: 02020003
	s_cbranch_execz 665                                        // 000000DE1120: BFA50299 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8488>
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000DE1124: 30000082
	ds_load_b32 v1, v0 offset:20488                            // 000000DE1128: D8D85008 01000000
	s_waitcnt lgkmcnt(0)                                       // 000000DE1130: BF89FC07
	v_cmp_ne_u32_e32 vcc_lo, 0, v1                             // 000000DE1134: 7C9A0280
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000DE1138: 8B7E6A7E
	s_cbranch_execz 658                                        // 000000DE113C: BFA50292 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8488>
	v_add_nc_u32_e32 v0, 0x5008, v0                            // 000000DE1140: 4A0000FF 00005008
	buffer_gl1_inv                                             // 000000DE1148: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DE1150: E0AC0000 00000000
	s_lshl_b32 s10, s8, 7                                      // 000000DE1158: 840A8708
	v_and_b32_e32 v1, 31, v77                                  // 000000DE115C: 36029A9F
	s_ashr_i32 s11, s10, 31                                    // 000000DE1160: 860B9F0A
	v_add_nc_u32_e32 v0, -8, v0                                // 000000DE1164: 4A0000C8
	s_lshl_b64 s[0:1], s[10:11], 2                             // 000000DE1168: 8480820A
	s_mov_b32 s9, 0x76543210                                   // 000000DE116C: BE8900FF 76543210
	v_lshlrev_b32_e32 v4, 4, v1                                // 000000DE1174: 30080284
	ds_load_b32 v0, v0                                         // 000000DE1178: D8D80000 00000000
	s_waitcnt lgkmcnt(0)                                       // 000000DE1180: BF89FC07
	v_mad_i64_i32 v[2:3], null, 0x1400, v0, s[48:49]           // 000000DE1184: D6FF7C02 00C200FF 00001400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE1190: BF870091
	.long 0xd7006a02                                           // 000000DE1194: D7006A02
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 000000DE1198: 02000102
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 000000DE119C: D5207C03 01AA0601
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE11A4: BF870092
	.long 0xd7006a02                                           // 000000DE11A8: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000DE11AC: 02020902
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000DE11B0: D5207C03 01AA0680
	s_clause 0x7                                               // 000000DE11B8: BF850007
	global_load_b32 v8, v[2:3], off glc                        // 000000DE11BC: DC524000 087C0002
	global_load_b32 v9, v[2:3], off offset:2560 glc            // 000000DE11C4: DC524A00 097C0002
	global_load_b32 v10, v[2:3], off offset:4 glc              // 000000DE11CC: DC524004 0A7C0002
	global_load_b32 v11, v[2:3], off offset:2564 glc           // 000000DE11D4: DC524A04 0B7C0002
	global_load_b32 v12, v[2:3], off offset:8 glc              // 000000DE11DC: DC524008 0C7C0002
	global_load_b32 v13, v[2:3], off offset:2568 glc           // 000000DE11E4: DC524A08 0D7C0002
	global_load_b32 v14, v[2:3], off offset:12 glc             // 000000DE11EC: DC52400C 0E7C0002
	global_load_b32 v15, v[2:3], off offset:2572 glc           // 000000DE11F4: DC524A0C 0F7C0002
	v_and_b32_e32 v16, 1, v77                                  // 000000DE11FC: 36209A81
	v_and_b32_e32 v17, 2, v77                                  // 000000DE1200: 36229A82
	v_and_b32_e32 v19, 8, v77                                  // 000000DE1204: 36269A88
	s_waitcnt vmcnt(5)                                         // 000000DE1208: BF8917F7
	v_add_f32_e32 v21, v8, v10                                 // 000000DE120C: 062A1508
	v_sub_f32_e32 v8, v8, v10                                  // 000000DE1210: 08101508
	v_lshl_or_b32 v2, v1, 2, s10                               // 000000DE1214: D6560002 00290501
	s_waitcnt vmcnt(1)                                         // 000000DE121C: BF8907F7
	v_add_f32_e32 v10, v12, v14                                // 000000DE1220: 06141D0C
	v_sub_f32_e32 v12, v12, v14                                // 000000DE1224: 08181D0C
	v_add_f32_e32 v14, v9, v11                                 // 000000DE1228: 061C1709
	v_ashrrev_i32_e32 v3, 31, v2                               // 000000DE122C: 3406049F
	v_sub_f32_e32 v9, v9, v11                                  // 000000DE1230: 08121709
	s_waitcnt vmcnt(0)                                         // 000000DE1234: BF8903F7
	v_add_f32_e32 v11, v13, v15                                // 000000DE1238: 06161F0D
	v_dual_sub_f32 v13, v13, v15 :: v_dual_add_f32 v22, v8, v12// 000000DE123C: C9481F0D 0D161908
	.long 0xd73c0002                                           // 000000DE1244: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 000000DE1248: 02020481
	.long 0xd44a0000                                           // 000000DE124C: D44A0000
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 000000DE1250: 02022080
	v_and_b32_e32 v20, 16, v77                                 // 000000DE1254: 36289A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DE1258: BF8700C4
	v_add_f32_e32 v16, v9, v13                                 // 000000DE125C: 06201B09
	v_sub_f32_e32 v9, v9, v13                                  // 000000DE1260: 08121B09
	v_dual_add_f32 v15, v21, v10 :: v_dual_and_b32 v18, 4, v77 // 000000DE1264: C9241515 0F129A84
	.long 0xd7006a04                                           // 000000DE126C: D7006A04
	v_cndmask_b32_e32 v1, s50, v2, vcc_lo                      // 000000DE1270: 02020432
	v_add_co_ci_u32_e64 v5, null, s51, v3, vcc_lo              // 000000DE1274: D5207C05 01AA0633
	s_clause 0x1                                               // 000000DE127C: BF850001
	global_load_b64 v[6:7], v[4:5], off                        // 000000DE1280: DC560000 067C0004
	global_load_b64 v[4:5], v[4:5], off offset:1280            // 000000DE1288: DC560500 047C0004
	.long 0xd7006a02                                           // 000000DE1290: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000DE1294: 0202040C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DE1298: BF870001
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000DE129C: D5207C03 01AA060D
	v_mov_b32_dpp v27, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DE12A4: 7E3602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000DE12AC: D5010009 20021309
	v_sub_f32_e32 v8, v8, v12                                  // 000000DE12B4: 08101908
	global_load_b64 v[2:3], v[2:3], off                        // 000000DE12B8: DC560000 027C0002
	v_add_f32_e32 v12, v14, v11                                // 000000DE12C0: 0618170E
	v_sub_f32_e32 v11, v14, v11                                // 000000DE12C4: 0816170E
	v_mov_b32_dpp v13, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DE12C8: 7E1A02FA FF01610F
	v_cndmask_b32_e64 v14, -v15, v15, s0                       // 000000DE12D0: D501000E 20021F0F
	v_sub_f32_e32 v10, v21, v10                                // 000000DE12D8: 08141515
	v_mov_b32_dpp v15, v22 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DE12DC: 7E1E02FA FF016116
	v_mov_b32_dpp v26, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DE12E4: 7E3402FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000DE12EC: D501000B 2002170B
	v_cndmask_b32_e64 v21, -v22, v22, s0                       // 000000DE12F4: D5010015 20022D16
	.long 0xd44a0001                                           // 000000DE12FC: D44A0001
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 000000DE1300: 02022280
	v_add_f32_e32 v13, v14, v13                                // 000000DE1304: 061A1B0E
	v_mov_b32_dpp v22, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DE1308: 7E2C02FA FF01610A
	v_add_f32_e32 v11, v11, v26                                // 000000DE1310: 0616350B
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000DE1314: D501000A 2002150A
	v_add_f32_e32 v15, v21, v15                                // 000000DE131C: 061E1F15
	v_add_f32_e32 v9, v9, v27                                  // 000000DE1320: 06123709
	v_mov_b32_dpp v23, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DE1324: 7E2E02FA FF016108
	v_mov_b32_dpp v21, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DE132C: 7E2A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000DE1334: D501000B 2006170B
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000DE133C: D5010008 20021108
	v_add_f32_e32 v10, v10, v22                                // 000000DE1344: 06142D0A
	v_mov_b32_dpp v22, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DE1348: 7E2C02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000DE1350: D5010009 20061309
	v_add_f32_e32 v11, v11, v21                                // 000000DE1358: 06162B0B
	v_mov_b32_dpp v24, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DE135C: 7E3002FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000DE1364: D501000C 2002190C
	.long 0xd44a0003                                           // 000000DE136C: D44A0003
	v_cndmask_b32_e32 v1, 0, v18, vcc_lo                       // 000000DE1370: 02022480
	v_add_f32_e32 v9, v9, v22                                  // 000000DE1374: 06122D09
	v_mov_b32_dpp v18, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DE1378: 7E2402FA FF01640B
	.long 0xd44a0002                                           // 000000DE1380: D44A0002
	v_cndmask_b32_e32 v1, 0, v19, vcc_lo                       // 000000DE1384: 02022680
	v_add_f32_e32 v12, v12, v24                                // 000000DE1388: 0618310C
	v_mov_b32_dpp v24, v15 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DE138C: 7E3002FA FF01620F
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000DE1394: D501000F 20061F0F
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000DE139C: D501000B 200E170B
	v_add_f32_e32 v8, v8, v23                                  // 000000DE13A4: 06102F08
	v_mov_b32_dpp v23, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DE13A8: 7E2E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000DE13B0: D501000D 20061B0D
	v_add_f32_e32 v15, v15, v24                                // 000000DE13B8: 061E310F
	v_mov_b32_dpp v25, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DE13BC: 7E3202FA FF016110
	v_cndmask_b32_e64 v16, -v16, v16, s0                       // 000000DE13C4: D5010010 20022110
	v_mov_b32_dpp v14, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DE13CC: 7E1C02FA FF01620C
	v_add_f32_e32 v13, v13, v23                                // 000000DE13D4: 061A2F0D
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DE13D8: D501000C 2006190C
	v_mov_b32_dpp v23, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DE13E0: 7E2E02FA FF01640F
	v_add_f32_e32 v16, v16, v25                                // 000000DE13E8: 06203310
	v_mov_b32_dpp v25, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DE13EC: 7E3202FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000DE13F4: D501000A 2006150A
	v_mov_b32_dpp v22, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DE13FC: 7E2C02FA FF01640D
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 000000DE1404: D501000F 200E1F0F
	v_mov_b32_dpp v17, v16 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DE140C: 7E2202FA FF016210
	v_cndmask_b32_e64 v16, -v16, v16, s1                       // 000000DE1414: D5010010 20062110
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000DE141C: D501000D 200E1B0D
	v_add_f32_e32 v10, v10, v25                                // 000000DE1424: 0614330A
	v_mov_b32_dpp v21, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DE1428: 7E2A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000DE1430: D5010009 200E1309
	v_add_f32_e32 v12, v12, v14                                // 000000DE1438: 06181D0C
	v_dual_add_f32 v14, v16, v17 :: v_dual_add_f32 v15, v15, v23// 000000DE143C: C9082310 0E0E2F0F
	v_add_f32_e32 v11, v11, v18                                // 000000DE1444: 0616250B
	v_mov_b32_dpp v26, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DE1448: 7E3402FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DE1450: D5010008 20061108
	v_add_f32_e32 v13, v13, v22                                // 000000DE1458: 061A2D0D
	v_mov_b32_dpp v17, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DE145C: 7E2202FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 000000DE1464: D501000E 200E1D0E
	v_add_f32_e32 v9, v9, v21                                  // 000000DE146C: 06122B09
	v_mov_b32_dpp v22, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DE1470: 7E2C02FA FF01680F
	v_mov_b32_dpp v21, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DE1478: 7E2A02FA FF01680D
	v_cndmask_b32_e64 v15, -v15, v15, s2                       // 000000DE1480: D501000F 200A1F0F
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000DE1488: D501000D 200A1B0D
	v_add_f32_e32 v8, v8, v26                                  // 000000DE1490: 06103508
	v_mov_b32_dpp v16, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DE1494: 7E2002FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000DE149C: D501000C 200E190C
	v_dual_add_f32 v14, v14, v17 :: v_dual_add_f32 v15, v15, v22// 000000DE14A4: C908230E 0E0E2D0F
	v_mov_b32_dpp v18, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DE14AC: 7E2402FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000DE14B4: D501000B 200A170B
	v_add_f32_e32 v13, v13, v21                                // 000000DE14BC: 061A2B0D
	v_mov_b32_dpp v25, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DE14C0: 7E3202FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000DE14C8: D5010008 200E1108
	v_mov_b32_dpp v24, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DE14D0: 7E3002FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000DE14D8: D501000A 200E150A
	v_dual_add_f32 v12, v12, v16 :: v_dual_add_f32 v11, v11, v18// 000000DE14E0: C908210C 0C0A250B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DE14E8: BF870004
	v_add_f32_e32 v8, v8, v25                                  // 000000DE14EC: 06103308
	v_mov_b32_dpp v17, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DE14F0: 7E2202FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000DE14F8: D501000E 200A1D0E
	.long 0xd44a0004                                           // 000000DE1500: D44A0004
	v_cndmask_b32_e32 v1, 0, v20, vcc_lo                       // 000000DE1504: 02022880
	v_mov_b32_e32 v18, v15                                     // 000000DE1508: 7E24030F
	v_add_f32_e32 v10, v10, v24                                // 000000DE150C: 0614310A
	v_mov_b32_dpp v16, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DE1510: 7E2002FA FF01680C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000DE1518: D501000C 200A190C
	v_cndmask_b32_e64 v15, -v15, v15, s4                       // 000000DE1520: D501000F 20121F0F
	v_permlanex16_b32 v18, v18, s9, 0xfedcba98                 // 000000DE1528: D65C0012 03FC1312 FEDCBA98
	v_dual_add_f32 v14, v14, v17 :: v_dual_mov_b32 v17, v13    // 000000DE1534: C910230E 0E10010D
	v_mov_b32_dpp v24, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DE153C: 7E3002FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DE1544: D5010008 200A1108
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000DE154C: D501000D 20121B0D
	v_add_f32_e32 v15, v15, v18                                // 000000DE1554: 061E250F
	v_permlanex16_b32 v17, v17, s9, 0xfedcba98                 // 000000DE1558: D65C0011 03FC1311 FEDCBA98
	v_mov_b32_dpp v19, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DE1564: 7E2602FA FF016809
	v_add_f32_e32 v8, v8, v24                                  // 000000DE156C: 06103108
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000DE1570: D5010009 200A1309
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 000000DE1578: 101E1EFF 3DB504F3
	v_dual_add_f32 v13, v13, v17 :: v_dual_add_f32 v12, v12, v16// 000000DE1580: C908230D 0D0C210C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DE1588: BF870234
	v_mov_b32_e32 v21, v8                                      // 000000DE158C: 7E2A0308
	v_mov_b32_dpp v23, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DE1590: 7E2E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000DE1598: D501000A 200A150A
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 000000DE15A0: 101A1AFF 3DB504F3
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000DE15A8: D5010008 20121108
	v_permlanex16_b32 v21, v21, s9, 0xfedcba98                 // 000000DE15B0: D65C0015 03FC1315 FEDCBA98
	v_add_f32_e32 v9, v9, v19                                  // 000000DE15BC: 06122709
	v_add_f32_e32 v10, v10, v23                                // 000000DE15C0: 06142F0A
	v_mov_b32_e32 v17, v14                                     // 000000DE15C4: 7E22030E
	v_cndmask_b32_e64 v16, -v12, v12, s4                       // 000000DE15C8: D5010010 2012190C
	v_add_f32_e32 v8, v8, v21                                  // 000000DE15D0: 06102B08
	v_permlanex16_b32 v12, v12, s9, 0xfedcba98                 // 000000DE15D4: D65C000C 03FC130C FEDCBA98
	v_mov_b32_e32 v21, v9                                      // 000000DE15E0: 7E2A0309
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000DE15E4: D5010009 20121309
	v_permlanex16_b32 v17, v17, s9, 0xfedcba98                 // 000000DE15EC: D65C0011 03FC1311 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE15F8: BF870093
	v_permlanex16_b32 v21, v21, s9, 0xfedcba98                 // 000000DE15FC: D65C0015 03FC1315 FEDCBA98
	v_add_f32_e32 v9, v9, v21                                  // 000000DE1608: 06122B09
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DE160C: BF870001
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000DE1610: 101212FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 000000DE1618: BF890BF7
	v_fma_mix_f32 v13, v6, v13, neg(0) op_sel_hi:[1,0,0]       // 000000DE161C: CC20000D 8A021B06
	v_fma_mix_f32 v6, v6, v15, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DE1624: CC200806 8A021F06
	v_mov_b32_e32 v20, v10                                     // 000000DE162C: 7E28030A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 000000DE1630: D501000A 2012150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DE1638: BF870193
	v_mul_f32_e32 v15, 0xbfb8aa3b, v6                          // 000000DE163C: 101E0CFF BFB8AA3B
	v_permlanex16_b32 v20, v20, s9, 0xfedcba98                 // 000000DE1644: D65C0014 03FC1314 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE1650: BF870092
	v_exp_f32_e32 v15, v15                                     // 000000DE1654: 7E1E4B0F
	v_add_f32_e32 v10, v10, v20                                // 000000DE1658: 0614290A
	v_mov_b32_e32 v20, v11                                     // 000000DE165C: 7E28030B
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000DE1660: 101010FF 3DB504F3
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000DE1668: D501000B 2012170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DE1670: BF870214
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000DE1674: 101414FF 3DB504F3
	v_permlanex16_b32 v20, v20, s9, 0xfedcba98                 // 000000DE167C: D65C0014 03FC1314 FEDCBA98
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DE1688: BF870195
	v_add_f32_e32 v15, 1.0, v15                                // 000000DE168C: 061E1EF2
	v_fma_mix_f32 v10, v7, v10, neg(0) op_sel_hi:[1,0,0]       // 000000DE1690: CC20000A 8A021507
	v_fma_mix_f32 v7, v7, v8, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DE1698: CC200807 8A021107
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DE16A0: BF870234
	v_add_f32_e32 v11, v11, v20                                // 000000DE16A4: 0616290B
	v_cndmask_b32_e64 v8, -v14, v14, s4                        // 000000DE16A8: D5010008 20121D0E
	v_div_scale_f32 v23, null, v15, v15, v6                    // 000000DE16B0: D6FC7C17 041A1F0F
	v_dual_mul_f32 v18, 0xbfb8aa3b, v10 :: v_dual_mul_f32 v19, 0xbfb8aa3b, v7// 000000DE16B8: C8C614FF 12120EFF BFB8AA3B
	v_div_scale_f32 v20, s5, v6, v15, v6                       // 000000DE16C4: D6FC0514 041A1F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DE16CC: BF870194
	v_dual_add_f32 v8, v8, v17 :: v_dual_mul_f32 v11, 0x3db504f3, v11// 000000DE16D0: C9062308 080A16FF 3DB504F3
	v_exp_f32_e32 v18, v18                                     // 000000DE16DC: 7E244B12
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(TRANS32_DEP_2)// 000000DE16E0: BF870343
	v_exp_f32_e32 v19, v19                                     // 000000DE16E4: 7E264B13
	v_mul_f32_e32 v14, 0xbfb8aa3b, v13                         // 000000DE16E8: 101C1AFF BFB8AA3B
	v_rcp_f32_e32 v26, v23                                     // 000000DE16F0: 7E345517
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000DE16F4: 101010FF 3DB504F3
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_add_f32 v19, 1.0, v19// 000000DE16FC: C90824F2 121226F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DE1704: BF870313
	v_exp_f32_e32 v14, v14                                     // 000000DE1708: 7E1C4B0E
	v_fma_f32 v30, -v23, v26, 1.0                              // 000000DE170C: D613001E 23CA3517
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DE1714: BF870192
	v_div_scale_f32 v24, null, v18, v18, v10                   // 000000DE1718: D6FC7C18 042A2512
	v_div_scale_f32 v25, null, v19, v19, v7                    // 000000DE1720: D6FC7C19 041E2713
	v_div_scale_f32 v33, s7, v7, v19, v7                       // 000000DE1728: D6FC0721 041E2707
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DE1730: BF870214
	v_fmac_f32_e32 v26, v30, v26                               // 000000DE1734: 5634351E
	v_rcp_f32_e32 v27, v24                                     // 000000DE1738: 7E365518
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DE173C: BF870313
	v_rcp_f32_e32 v28, v25                                     // 000000DE1740: 7E385519
	v_fma_f32 v31, -v24, v27, 1.0                              // 000000DE1744: D613001F 23CA3718
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DE174C: BF870297
	v_add_f32_e32 v14, 1.0, v14                                // 000000DE1750: 061C1CF2
	v_fma_f32 v32, -v25, v28, 1.0                              // 000000DE1754: D6130020 23CA3919
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DE175C: BF870193
	v_fmac_f32_e32 v27, v31, v27                               // 000000DE1760: 5636371F
	v_div_scale_f32 v22, null, v14, v14, v13                   // 000000DE1764: D6FC7C16 04361D0E
	v_add_f32_e32 v12, v16, v12                                // 000000DE176C: 06181910
	v_div_scale_f32 v17, vcc_lo, v13, v14, v13                 // 000000DE1770: D6FC6A11 04361D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DE1778: BF870293
	v_rcp_f32_e32 v16, v22                                     // 000000DE177C: 7E205516
	v_fma_f32 v29, -v22, v16, 1.0                              // 000000DE1780: D613001D 23CA2116
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE1788: BF870091
	v_fmac_f32_e32 v16, v29, v16                               // 000000DE178C: 5620211D
	v_mul_f32_e32 v29, v17, v16                                // 000000DE1790: 103A2111
	v_div_scale_f32 v21, s6, v10, v18, v10                     // 000000DE1794: D6FC0615 042A250A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DE179C: BF870112
	v_fma_f32 v34, -v22, v29, v17                              // 000000DE17A0: D6130022 24463B16
	v_dual_mul_f32 v31, v21, v27 :: v_dual_mul_f32 v12, 0x3db504f3, v12// 000000DE17A8: C8C63715 1F0C18FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DE17B4: BF870121
	v_fma_f32 v36, -v24, v31, v21                              // 000000DE17B8: D6130024 24563F18
	s_waitcnt vmcnt(1)                                         // 000000DE17C0: BF8907F7
	v_fma_mix_f32 v12, v4, v12, neg(0) op_sel_hi:[1,0,0]       // 000000DE17C4: CC20000C 8A021904
	v_fma_mix_f32 v4, v4, v8, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DE17CC: CC200804 8A021104
	v_fma_mix_f32 v8, v5, v9, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DE17D4: CC200808 8A021305
	v_fma_mix_f32 v5, v5, v11, neg(0) op_sel_hi:[1,0,0]        // 000000DE17DC: CC200005 8A021705
	v_fmac_f32_e32 v31, v36, v27                               // 000000DE17E4: 563E3724
	v_dual_mul_f32 v30, v20, v26 :: v_dual_fmac_f32 v29, v34, v16// 000000DE17E8: C8C03514 1E1C2122
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DE17F0: BF870112
	v_fma_f32 v21, -v24, v31, v21                              // 000000DE17F4: D6130015 24563F18
	v_fma_f32 v35, -v23, v30, v20                              // 000000DE17FC: D6130023 24523D17
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DE1804: BF870113
	v_fma_f32 v17, -v22, v29, v17                              // 000000DE1808: D6130011 24463B16
	v_fmac_f32_e32 v30, v35, v26                               // 000000DE1810: 563C3523
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DE1814: BF870132
	v_div_fmas_f32 v16, v17, v16, v29                          // 000000DE1818: D6370010 04762111
	s_mov_b32 vcc_lo, s5                                       // 000000DE1820: BEEA0005
	s_mov_b32 s5, 0x3db504f3                                   // 000000DE1824: BE8500FF 3DB504F3
	v_fma_f32 v20, -v23, v30, v20                              // 000000DE182C: D6130014 24523D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DE1834: BF8701A2
	v_div_fixup_f32 v9, v16, v14, v13                          // 000000DE1838: D6270009 04361D10
	v_lshlrev_b32_e32 v13, 3, v1                               // 000000DE1840: 301A0283
	v_div_fmas_f32 v17, v20, v26, v30                          // 000000DE1844: D6370011 047A3514
	s_mov_b32 vcc_lo, s6                                       // 000000DE184C: BEEA0006
	v_div_fmas_f32 v20, v21, v27, v31                          // 000000DE1850: D6370014 047E3715
	s_mov_b32 vcc_lo, s7                                       // 000000DE1858: BEEA0007
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DE185C: BF870112
	v_div_fixup_f32 v6, v17, v15, v6                           // 000000DE1860: D6270006 041A1F11
	v_div_fixup_f32 v10, v20, v18, v10                         // 000000DE1868: D627000A 042A2514
	v_fmac_f32_e32 v28, v32, v28                               // 000000DE1870: 56383920
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DE1874: BF870193
	v_mul_f32_e32 v4, v4, v6                                   // 000000DE1878: 10080D04
	v_mul_f32_e32 v5, v5, v10                                  // 000000DE187C: 100A1505
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DE1880: BF8701A3
	v_mul_f32_e32 v32, v33, v28                                // 000000DE1884: 10403921
	s_waitcnt vmcnt(0)                                         // 000000DE1888: BF8903F7
	v_fma_mix_f32 v4, v2, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DE188C: CC200804 8A020902
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE1894: BF870092
	v_fma_f32 v37, -v25, v32, v33                              // 000000DE1898: D6130025 24864119
	v_fmac_f32_e32 v32, v37, v28                               // 000000DE18A0: 56403925
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE18A4: BF870091
	v_fma_f32 v22, -v25, v32, v33                              // 000000DE18A8: D6130016 24864119
	v_div_fmas_f32 v21, v22, v28, v32                          // 000000DE18B0: D6370015 04823916
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE18B8: BF870091
	v_div_fixup_f32 v7, v21, v19, v7                           // 000000DE18BC: D6270007 041E2715
	v_mul_f32_e32 v6, v8, v7                                   // 000000DE18C4: 100C0F08
	v_mul_f32_e32 v7, v12, v9                                  // 000000DE18C8: 100E130C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DE18CC: BF870112
	v_fma_mix_f32 v6, v3, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DE18D0: CC200806 8A020D03
	v_fma_mix_f32 v8, v7, v2, v4 op_sel_hi:[0,1,0]             // 000000DE18D8: CC200008 14120507
	v_fma_mix_f32 v2, v7, v2, -v4 op_sel_hi:[0,1,0]            // 000000DE18E0: CC200002 94120507
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DE18E8: BF8700A3
	v_fma_mix_f32 v9, v5, v3, v6 op_sel_hi:[0,1,0]             // 000000DE18EC: CC200009 141A0705
	v_fma_mix_f32 v3, v5, v3, -v6 op_sel_hi:[0,1,0]            // 000000DE18F4: CC200003 941A0705
	v_dual_add_f32 v4, v8, v9 :: v_dual_add_f32 v5, v2, v3     // 000000DE18FC: C9081308 04040702
	v_sub_f32_e32 v2, v2, v3                                   // 000000DE1904: 08040702
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DE1908: BF870222
	v_mov_b32_dpp v3, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DE190C: 7E0602FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000DE1914: D5010004 20020904
	v_mov_b32_dpp v7, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DE191C: 7E0E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000DE1924: D5010005 20020B05
	v_cndmask_b32_e64 v10, -v2, v2, s0                         // 000000DE192C: D501000A 20020502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DE1934: BF870194
	v_add_f32_e32 v3, v4, v3                                   // 000000DE1938: 06060704
	v_add_f32_e32 v4, v5, v7                                   // 000000DE193C: 06080F05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DE1940: BF8700A2
	v_mov_b32_dpp v7, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DE1944: 7E0E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000DE194C: D5010003 20060703
	v_add_f32_e32 v3, v3, v7                                   // 000000DE1954: 06060F03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DE1958: BF8700A1
	v_mov_b32_dpp v7, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DE195C: 7E0E02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000DE1964: D5010003 200E0703
	v_add_f32_e32 v3, v3, v7                                   // 000000DE196C: 06060F03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000DE1970: BF8701C1
	v_mov_b32_dpp v7, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DE1974: 7E0E02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000DE197C: D5010003 200A0703
	v_sub_f32_e32 v6, v8, v9                                   // 000000DE1984: 080C1308
	v_mov_b32_dpp v9, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DE1988: 7E1202FA FF016102
	v_add_f32_e32 v7, v3, v7                                   // 000000DE1990: 060E0F03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DE1994: BF8700A3
	v_mov_b32_dpp v8, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DE1998: 7E1002FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000DE19A0: D5010006 20020D06
	v_dual_mov_b32 v2, 0 :: v_dual_add_f32 v5, v6, v8          // 000000DE19A8: CA080080 02041106
	v_add_f32_e32 v6, v10, v9                                  // 000000DE19B0: 060C130A
	v_mov_b32_dpp v8, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DE19B4: 7E1002FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000DE19BC: D5010004 20060904
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DE19C4: BF870004
	v_mov_b32_dpp v9, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DE19C8: 7E1202FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000DE19D0: D5010005 20060B05
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DE19D8: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000DE19E0: D5010006 20060D06
	v_add_f32_e32 v4, v4, v8                                   // 000000DE19E8: 06081104
	s_lshl_b64 s[0:1], s[10:11], 1                             // 000000DE19EC: 8480810A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DE19F0: BF870112
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v6, v6, v10    // 000000DE19F4: C9081305 05061506
	v_mov_b32_dpp v8, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DE19FC: 7E1002FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000DE1A04: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000DE1A0C: BF8701C3
	v_mov_b32_dpp v9, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DE1A10: 7E1202FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000DE1A18: D5010005 200E0B05
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DE1A20: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000DE1A28: D5010006 200E0D06
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v5, v5, v9     // 000000DE1A30: C9081104 04041305
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DE1A38: BF870112
	v_add_f32_e32 v6, v6, v10                                  // 000000DE1A3C: 060C1506
	v_mov_b32_dpp v8, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DE1A40: 7E1002FA FF016804
	v_cndmask_b32_e64 v9, -v4, v4, s2                          // 000000DE1A48: D5010009 200A0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000DE1A50: BF870254
	v_mov_b32_dpp v10, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DE1A54: 7E1402FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000DE1A5C: D5010005 200A0B05
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DE1A64: 7E1602FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000DE1A6C: D5010006 200A0D06
	v_dual_add_f32 v8, v9, v8 :: v_dual_mov_b32 v9, v7         // 000000DE1A74: C9101109 08080107
	v_add_f32_e32 v5, v5, v10                                  // 000000DE1A7C: 060A1505
	v_mad_i64_i32 v[3:4], null, 0x500, v0, s[14:15]            // 000000DE1A80: D6FF7C03 003A00FF 00000500
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DE1A8C: BF870214
	v_add_f32_e32 v6, v6, v11                                  // 000000DE1A90: 060C1706
	v_mov_b32_e32 v10, v8                                      // 000000DE1A94: 7E140308
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000DE1A98: D5010007 20120F07
	v_mov_b32_e32 v11, v5                                      // 000000DE1AA0: 7E160305
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000DE1AA4: D5010005 20120B05
	v_mov_b32_e32 v12, v6                                      // 000000DE1AAC: 7E180306
	v_permlanex16_b32 v9, v9, s9, 0xfedcba98                   // 000000DE1AB0: D65C0009 03FC1309 FEDCBA98
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000DE1ABC: D5010008 20121108
	v_permlanex16_b32 v11, v11, s9, 0xfedcba98                 // 000000DE1AC4: D65C000B 03FC130B FEDCBA98
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 000000DE1AD0: D5010006 20120D06
	v_permlanex16_b32 v10, v10, s9, 0xfedcba98                 // 000000DE1AD8: D65C000A 03FC130A FEDCBA98
	v_permlanex16_b32 v12, v12, s9, 0xfedcba98                 // 000000DE1AE4: D65C000C 03FC130C FEDCBA98
	v_add_f32_e32 v7, v7, v9                                   // 000000DE1AF0: 060E1307
	v_add_f32_e32 v5, v5, v11                                  // 000000DE1AF4: 060A1705
	.long 0xd7006a09                                           // 000000DE1AF8: D7006A09
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 000000DE1AFC: 02000103
	v_add_f32_e32 v8, v8, v10                                  // 000000DE1B00: 06101508
	v_add_f32_e32 v6, v6, v12                                  // 000000DE1B04: 060C1906
	v_add_co_ci_u32_e64 v10, null, s1, v4, vcc_lo              // 000000DE1B08: D5207C0A 01AA0801
	v_fma_mixlo_f16 v4, v5, s5, 0                              // 000000DE1B10: CC210004 02000B05
	.long 0xd7006a05                                           // 000000DE1B18: D7006A05
	v_cndmask_b32_e32 v1, v9, v13, vcc_lo                      // 000000DE1B1C: 02021B09
	v_fma_mixlo_f16 v3, v7, s5, 0                              // 000000DE1B20: CC210003 02000B07
	v_fma_mixhi_f16 v3, v8, s5, 0                              // 000000DE1B28: CC220003 02000B08
	v_fma_mixhi_f16 v4, v6, s5, 0                              // 000000DE1B30: CC220004 02000B06
	v_add_co_ci_u32_e64 v6, null, 0, v10, vcc_lo               // 000000DE1B38: D5207C06 01AA1480
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000DE1B40: 7C940280
	global_store_b64 v[5:6], v[3:4], off                       // 000000DE1B44: DC6E0000 007C0305
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000DE1B4C: 8B7E6A7E
	s_cbranch_execz 13                                         // 000000DE1B50: BFA5000D <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi2ELi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8488>
	v_mad_u64_u32 v[0:1], null, v0, 5, s[8:9]                  // 000000DE1B54: D6FE7C00 00210B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE1B5C: BF870091
	v_ashrrev_i32_e32 v1, 31, v0                               // 000000DE1B60: 3402009F
	.long 0xd73c0000                                           // 000000DE1B64: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000DE1B68: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DE1B6C: BF870091
	.long 0xd7006a00                                           // 000000DE1B70: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000DE1B74: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000DE1B78: D5207C01 01AA0211
	global_store_b32 v[0:1], v2, off                           // 000000DE1B80: DC6A0000 007C0200
	s_nop 0                                                    // 000000DE1B88: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000DE1B8C: BFB60003
	s_endpgm                                                   // 000000DE1B90: BFB00000
		...

