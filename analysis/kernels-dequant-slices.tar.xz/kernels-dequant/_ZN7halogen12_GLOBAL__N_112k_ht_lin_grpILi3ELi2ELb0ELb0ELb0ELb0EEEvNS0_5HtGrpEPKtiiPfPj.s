00000000003f4100 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj>:
; _ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj():
	s_clause 0x1                                               // 0000003F4100: BF850001
	s_load_b64 s[4:5], s[0:1], 0x130                           // 0000003F4104: F4040100 F8000130
	s_load_b128 s[16:19], s[0:1], 0x198                        // 0000003F410C: F4080400 F8000198
	s_waitcnt lgkmcnt(0)                                       // 0000003F4114: BF89FC07
	s_cmp_eq_u64 s[4:5], 0                                     // 0000003F4118: BF108004
	s_cbranch_scc1 244                                         // 0000003F411C: BFA200F4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f0>
	s_load_b32 s6, s[0:1], 0x138                               // 0000003F4120: F4000180 F8000138
	s_waitcnt lgkmcnt(0)                                       // 0000003F4128: BF89FC07
	s_cmp_lt_i32 s2, s6                                        // 0000003F412C: BF040602
	s_cselect_b32 s3, -1, 0                                    // 0000003F4130: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000003F4134: BF030602
	s_cbranch_scc0 233                                         // 0000003F4138: BFA100E9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3e0>
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000003F413C: 32020085
	s_sub_i32 s6, s2, s6                                       // 0000003F4140: 81860602
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000003F4144: BF870481
	v_lshl_or_b32 v1, s6, 3, v1                                // 0000003F4148: D6560001 04050606
	s_mul_i32 s6, s18, 20                                      // 0000003F4150: 96069412
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000003F4154: BF870481
	v_cmp_gt_i32_e32 vcc_lo, s6, v1                            // 0000003F4158: 7C880206
	s_and_saveexec_b32 s6, vcc_lo                              // 0000003F415C: BE86206A
	s_cbranch_execz 222                                        // 0000003F4160: BFA500DE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3dc>
	.long 0xd72e0002                                           // 0000003F4164: D72E0002
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 0000003F4168: 020202FF 66666667
	v_and_b32_e32 v9, 31, v0                                   // 0000003F4170: 3612009F
	s_load_b64 s[8:9], s[0:1], 0x128                           // 0000003F4174: F4040200 F8000128
	s_mov_b32 s7, 0x76543210                                   // 0000003F417C: BE8700FF 76543210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F4184: BF8700A2
	v_lshrrev_b32_e32 v3, 31, v2                               // 0000003F4188: 3206049F
	v_ashrrev_i32_e32 v2, 3, v2                                // 0000003F418C: 34040483
	v_add_nc_u32_e32 v8, v2, v3                                // 0000003F4190: 4A100702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003F4194: BF870121
	.long 0xd72c0002                                           // 0000003F4198: D72C0002
	v_cndmask_b32_e32 v1, 0xffffffec, v8, vcc_lo               // 0000003F419C: 020210FF FFFFFFEC
	v_mad_i64_i32 v[4:5], null, 0x1400, v8, s[16:17]           // 0000003F41A4: D6FF7C04 004210FF 00001400
	v_add_lshl_u32 v1, v2, v1, 7                               // 0000003F41B0: D6470001 021E0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F41B8: BF870091
	v_lshl_or_b32 v2, v9, 2, v1                                // 0000003F41BC: D6560002 04050509
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000003F41C4: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F41C8: BF870091
	.long 0xd73c0002                                           // 0000003F41CC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000003F41D0: 02020481
	.long 0xd7006a04                                           // 0000003F41D4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000003F41D8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003F41DC: BF8700B1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000003F41E0: D5207C05 01AA0705
	s_waitcnt lgkmcnt(0)                                       // 0000003F41E8: BF89FC07
	.long 0xd7006a02                                           // 0000003F41EC: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000003F41F0: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 0000003F41F4: D5207C03 01AA0609
	global_load_b64 v[4:5], v[4:5], off                        // 0000003F41FC: DC560000 047C0004
	s_mov_b32 s8, 0x3db504f3                                   // 0000003F4204: BE8800FF 3DB504F3
	global_load_b64 v[6:7], v[2:3], off                        // 0000003F420C: DC560000 067C0002
	s_waitcnt vmcnt(1)                                         // 0000003F4214: BF8907F7
	.long 0x7e043904                                           // 0000003F4218: 7E043904
	v_and_b32_e32 v3, 0xffff0000, v4                           // 0000003F421C: 360608FF FFFF0000
	.long 0x7e083905                                           // 0000003F4224: 7E083905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000003F4228: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F4230: BF870004
	v_lshlrev_b32_e32 v14, 16, v2                              // 0000003F4234: 301C0490
	s_waitcnt vmcnt(0)                                         // 0000003F4238: BF8903F7
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003F423C: CC200803 8A020706
	v_lshlrev_b32_e32 v4, 16, v4                               // 0000003F4244: 30080890
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003F4248: CC200805 8A020B07
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000003F4250: 3404029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F4254: BF870224
	v_fma_mix_f32 v15, v6, v14, v3 op_sel_hi:[1,0,0]           // 0000003F4258: CC20000F 0C0E1D06
	v_fma_mix_f32 v6, v6, v14, -v3 op_sel_hi:[1,0,0]           // 0000003F4260: CC200006 8C0E1D06
	v_fma_mix_f32 v14, v7, v4, v5 op_sel_hi:[1,0,0]            // 0000003F4268: CC20000E 0C160907
	v_fma_mix_f32 v5, v7, v4, -v5 op_sel_hi:[1,0,0]            // 0000003F4270: CC200005 8C160907
	v_and_b32_e32 v10, 1, v0                                   // 0000003F4278: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000003F427C: 36160082
	v_and_b32_e32 v13, 8, v0                                   // 0000003F4280: 361A0088
	.long 0xd73c0001                                           // 0000003F4284: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003F4288: 02020281
	v_add_f32_e32 v16, v6, v5                                  // 0000003F428C: 06200B06
	v_sub_f32_e32 v5, v6, v5                                   // 0000003F4290: 080A0B06
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000003F4294: 7C941480
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F4298: BF870193
	v_mov_b32_dpp v10, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F429C: 7E1402FA FF016110
	v_mov_b32_dpp v17, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F42A4: 7E2202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F42AC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000003F42B4: BF8701D1
	v_add_f32_e32 v5, v5, v17                                  // 0000003F42B8: 060A2305
	v_mad_i64_i32 v[3:4], null, 0x1400, v8, s[4:5]             // 0000003F42BC: D6FF7C03 001210FF 00001400
	v_add_f32_e32 v8, v15, v14                                 // 0000003F42C8: 06101D0F
	v_sub_f32_e32 v14, v15, v14                                // 0000003F42CC: 081C1D0F
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 0000003F42D0: D501000F 21AA2110
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F42D8: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003F42E0: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003F42E8: BF870234
	v_mov_b32_dpp v16, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F42EC: 7E2002FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000003F42F4: D501000E 21AA1D0E
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000003F42FC: 7C941680
	v_dual_add_f32 v6, v8, v6 :: v_dual_lshlrev_b32 v7, 3, v9  // 0000003F4300: C9220D08 06061283
	v_add_f32_e32 v8, v15, v10                                 // 0000003F4308: 0610150F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F430C: BF870004
	v_add_f32_e32 v10, v14, v16                                // 0000003F4310: 0614210E
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F4314: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F431C: D5010005 21AA0B05
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F4324: 7E1602FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003F432C: D5010006 21AA0D06
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F4334: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000003F433C: D501000A 21AA150A
	v_add_f32_e32 v5, v5, v16                                  // 0000003F4344: 060A2105
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F4348: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003F4350: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 0000003F4358: 060C1706
	v_add_f32_e32 v10, v10, v15                                // 0000003F435C: 06141F0A
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F4360: 7E1E02FA FF016405
	v_and_b32_e32 v12, 4, v0                                   // 0000003F4368: 36180084
	v_add_f32_e32 v8, v8, v14                                  // 0000003F436C: 06101D08
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F4370: 7E1602FA FF016406
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F4378: 7E1C02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000003F4380: BF8701C4
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 0000003F4384: 7C941880
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003F4388: D5010006 21AA0D06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F4390: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000003F4398: D501000A 21AA150A
	v_add_f32_e32 v6, v6, v11                                  // 0000003F43A0: 060C1706
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003F43A4: BF870003
	v_add_f32_e32 v5, v5, v15                                  // 0000003F43A8: 060A1F05
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F43AC: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003F43B4: D5010008 21AA1108
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 0000003F43BC: 7C941A80
	v_add_f32_e32 v10, v10, v14                                // 0000003F43C0: 06141D0A
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F43C4: 7E1602FA FF016806
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F43CC: 7E1C02FA FF016805
	v_add_f32_e32 v8, v8, v12                                  // 0000003F43D4: 06101908
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003F43D8: D5010006 21AA0D06
	v_mov_b32_dpp v13, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F43E0: 7E1A02FA FF01680A
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F43E8: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000003F43F0: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F43F8: 7E1802FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003F4400: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 0000003F4408: 060C1706
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 0000003F440C: 7C981290
	v_add_f32_e32 v5, v5, v14                                  // 0000003F4410: 060A1D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F4414: BF870214
	v_dual_add_f32 v9, v10, v13 :: v_dual_add_f32 v8, v8, v12  // 0000003F4418: C9081B0A 09081908
	v_mov_b32_e32 v10, v6                                      // 0000003F4420: 7E140306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003F4424: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F442C: BF870214
	v_mov_b32_e32 v13, v5                                      // 0000003F4430: 7E1A0305
	v_mov_b32_e32 v12, v9                                      // 0000003F4434: 7E180309
	v_cndmask_b32_e64 v11, -v8, v8, vcc_lo                     // 0000003F4438: D501000B 21AA1108
	v_permlanex16_b32 v8, v8, s7, 0xfedcba98                   // 0000003F4440: D65C0008 03FC0F08 FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F444C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003F4454: D5010009 21AA1309
	v_permlanex16_b32 v10, v10, s7, 0xfedcba98                 // 0000003F445C: D65C000A 03FC0F0A FEDCBA98
	v_permlanex16_b32 v12, v12, s7, 0xfedcba98                 // 0000003F4468: D65C000C 03FC0F0C FEDCBA98
	v_permlanex16_b32 v13, v13, s7, 0xfedcba98                 // 0000003F4474: D65C000D 03FC0F0D FEDCBA98
	.long 0xd7006a01                                           // 0000003F4480: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 0000003F4484: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003F4488: BF8700D1
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 0000003F448C: D5207C02 01AA0504
	v_dual_add_f32 v3, v11, v8 :: v_dual_add_f32 v4, v6, v10   // 0000003F4494: C908110B 03041506
	v_add_f32_e32 v6, v9, v12                                  // 0000003F449C: 060C1909
	v_add_f32_e32 v5, v5, v13                                  // 0000003F44A0: 060A1B05
	.long 0xd7006a01                                           // 0000003F44A4: D7006A01
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 0000003F44A8: 02020F01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000003F44AC: D5207C02 01AA0480
	v_fma_mixhi_f16 v3, v3, s8, 0                              // 0000003F44B4: CC220003 02001103
	v_fma_mixlo_f16 v3, v4, s8, 0                              // 0000003F44BC: CC210003 02001104
	v_fma_mixhi_f16 v4, v5, s8, 0                              // 0000003F44C4: CC220004 02001105
	v_fma_mixlo_f16 v4, v6, s8, 0                              // 0000003F44CC: CC210004 02001106
	global_store_b64 v[1:2], v[3:4], off                       // 0000003F44D4: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 0000003F44DC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F44E0: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000003F44E4: 8B6A037E
	s_cbranch_vccnz 2                                          // 0000003F44E8: BFA40002 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f4>
	s_endpgm                                                   // 0000003F44EC: BFB00000
	s_cbranch_execz 65534                                      // 0000003F44F0: BFA5FFFE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_clause 0x3                                               // 0000003F44F4: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000003F44F8: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x7c                                // 0000003F4500: F4000100 F800007C
	s_load_b32 s5, s[0:1], 0xc4                                // 0000003F4508: F4000140 F80000C4
	s_load_b32 s6, s[0:1], 0x10c                               // 0000003F4510: F4000180 F800010C
	v_and_b32_e32 v12, 31, v0                                  // 0000003F4518: 3618009F
	v_lshrrev_b32_e32 v11, 5, v0                               // 0000003F451C: 32160085
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003F4520: BF870002
	v_lshlrev_b32_e32 v2, 3, v12                               // 0000003F4524: 30041883
	s_waitcnt lgkmcnt(0)                                       // 0000003F4528: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000003F452C: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000003F4530: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 0000003F4534: BF030402
	s_cselect_b32 s4, -1, 0                                    // 0000003F4538: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F453C: BF870009
	s_and_b32 s4, s7, s4                                       // 0000003F4540: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000003F4544: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000003F4548: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000003F4550: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 0000003F4554: BF030502
	s_cselect_b32 s5, -1, 0                                    // 0000003F4558: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F455C: BF870009
	s_and_b32 s4, s7, s5                                       // 0000003F4560: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000003F4564: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000003F4568: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000003F456C: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000003F4570: BF030602
	s_cselect_b32 s6, -1, 0                                    // 0000003F4574: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000003F4578: BF8704D9
	s_and_b32 s3, s3, s6                                       // 0000003F457C: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000003F4580: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000003F4584: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000003F4588: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000003F458C: 98030483
	s_mulk_i32 s3, 0x48                                        // 0000003F4590: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F4594: BF870009
	s_add_u32 s4, s0, s3                                       // 0000003F4598: 80040300
	s_addc_u32 s5, s1, 0                                       // 0000003F459C: 82058001
	s_clause 0x3                                               // 0000003F45A0: BF850003
	s_load_b32 s28, s[4:5], 0x38                               // 0000003F45A4: F4000702 F8000038
	s_load_b64 s[30:31], s[4:5], 0x40                          // 0000003F45AC: F4040782 F8000040
	s_load_b128 s[20:23], s[4:5], 0x28                         // 0000003F45B4: F4080502 F8000028
	s_load_b64 s[24:25], s[4:5], 0x20                          // 0000003F45BC: F4040602 F8000020
	s_waitcnt lgkmcnt(0)                                       // 0000003F45C4: BF89FC07
	s_abs_i32 s3, s21                                          // 0000003F45C8: BE831515
	s_sub_i32 s2, s2, s23                                      // 0000003F45CC: 81821702
	s_cvt_f32_u32 s6, s3                                       // 0000003F45D0: BE866503
	s_sub_i32 s7, 0, s3                                        // 0000003F45D4: 81870380
	s_abs_i32 s8, s2                                           // 0000003F45D8: BE881502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003F45DC: BF870299
	v_rcp_iflag_f32_e32 v1, s6                                 // 0000003F45E0: 7E025606
	v_readfirstlane_b32 s6, v1                                 // 0000003F45E4: 7E0C0501
	s_mul_f32 s6, s6, 0x4f7ffffe                               // 0000003F45E8: A206FF06 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000003F45F0: BF87059B
	s_cvt_u32_f32 s6, s6                                       // 0000003F45F4: BE866706
	s_mul_i32 s7, s7, s6                                       // 0000003F45F8: 96070607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000003F45FC: BF870499
	s_mul_hi_u32 s7, s6, s7                                    // 0000003F4600: 96870706
	s_add_i32 s6, s6, s7                                       // 0000003F4604: 81060706
	s_xor_b32 s7, s2, s21                                      // 0000003F4608: 8D071502
	s_mul_hi_u32 s6, s8, s6                                    // 0000003F460C: 96860608
	s_ashr_i32 s7, s7, 31                                      // 0000003F4610: 86079F07
	s_mul_i32 s9, s6, s3                                       // 0000003F4614: 96090306
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F4618: BF870009
	s_sub_i32 s8, s8, s9                                       // 0000003F461C: 81880908
	s_add_i32 s9, s6, 1                                        // 0000003F4620: 81098106
	s_sub_i32 s10, s8, s3                                      // 0000003F4624: 818A0308
	s_cmp_ge_u32 s8, s3                                        // 0000003F4628: BF090308
	s_cselect_b32 s6, s9, s6                                   // 0000003F462C: 98060609
	s_cselect_b32 s8, s10, s8                                  // 0000003F4630: 9808080A
	s_add_i32 s9, s6, 1                                        // 0000003F4634: 81098106
	s_cmp_ge_u32 s8, s3                                        // 0000003F4638: BF090308
	s_cselect_b32 s3, s9, s6                                   // 0000003F463C: 98030609
	s_load_b256 s[8:15], s[4:5], null                          // 0000003F4640: F40C0202 F8000000
	s_xor_b32 s3, s3, s7                                       // 0000003F4648: 8D030703
	s_ashr_i32 s27, s19, 31                                    // 0000003F464C: 861B9F13
	s_sub_i32 s26, s3, s7                                      // 0000003F4650: 819A0703
	s_lshr_b32 s4, s27, 25                                     // 0000003F4654: 8504991B
	s_mul_i32 s3, s26, s21                                     // 0000003F4658: 9603151A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000003F465C: BF8704D9
	s_sub_i32 s23, s2, s3                                      // 0000003F4660: 81970302
	s_add_i32 s2, s19, s4                                      // 0000003F4664: 81020413
	s_mul_i32 s29, s22, s23                                    // 0000003F4668: 961D1716
	s_ashr_i32 s2, s2, 7                                       // 0000003F466C: 86028702
	s_add_i32 s3, s29, s22                                     // 0000003F4670: 8103161D
	s_min_i32 s2, s2, s3                                       // 0000003F4674: 89020302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000003F4678: BF8704B9
	s_sub_i32 s7, s2, s29                                      // 0000003F467C: 81871D02
	s_mov_b32 s2, exec_lo                                      // 0000003F4680: BE82007E
	s_lshl_b32 s22, s7, 1                                      // 0000003F4684: 84168107
	.long 0xd4c3007e                                           // 0000003F4688: D4C3007E
	v_cndmask_b32_e32 v1, s22, v11, vcc_lo                     // 0000003F468C: 02021616
	s_xor_b32 s2, exec_lo, s2                                  // 0000003F4690: 8D02027E
	v_lshlrev_b32_e32 v2, 3, v12                               // 0000003F4694: 30041883
	s_and_not1_saveexec_b32 s33, s2                            // 0000003F4698: BEA13002
	s_cbranch_execz 291                                        // 0000003F469C: BFA50123 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xa2c>
	s_abs_i32 s34, s7                                          // 0000003F46A0: BEA21507
	v_lshlrev_b32_e32 v9, 7, v11                               // 0000003F46A4: 30121687
	s_cvt_f32_u32 s2, s34                                      // 0000003F46A8: BE826522
	v_and_b32_e32 v3, 1, v0                                    // 0000003F46AC: 36060081
	v_and_b32_e32 v5, 4, v0                                    // 0000003F46B0: 360A0084
	v_lshl_or_b32 v8, v11, 8, v2                               // 0000003F46B4: D6560008 0409110B
	v_rcp_iflag_f32_e32 v1, s2                                 // 0000003F46BC: 7E025602
	s_sub_i32 s2, 0, s34                                       // 0000003F46C0: 81822280
	v_lshl_add_u32 v9, s29, 7, v9                              // 0000003F46C4: D6460009 04250E1D
	s_ashr_i32 s38, s7, 31                                     // 0000003F46CC: 86269F07
	.long 0xd44a0004                                           // 0000003F46D0: D44A0004
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000003F46D4: 02020A80
	s_mul_i32 s40, s38, 0x1400                                 // 0000003F46D8: 9628FF26 00001400
	s_lshl_b32 s6, s7, 7                                       // 0000003F46E0: 84068707
	s_add_i32 s35, s18, -1                                     // 0000003F46E4: 8123C112
	s_mov_b32 s36, s19                                         // 0000003F46E8: BEA40013
	s_mov_b32 s37, 0                                           // 0000003F46EC: BEA50080
	v_dual_mul_f32 v1, 0x4f7ffffe, v1 :: v_dual_and_b32 v6, 8, v0// 0000003F46F0: C8E402FF 01060088 4F7FFFFE
	s_lshl_b32 s39, s7, 8                                      // 0000003F46FC: 84278807
	s_mov_b32 s41, 0x76543210                                  // 0000003F4700: BEA900FF 76543210
	s_mov_b32 s42, 0x3db504f3                                  // 0000003F4708: BEAA00FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F4710: BF870001
	v_cvt_u32_f32_e32 v4, v1                                   // 0000003F4714: 7E080F01
	v_and_b32_e32 v1, 2, v0                                    // 0000003F4718: 36020082
	.long 0xd44a0005                                           // 0000003F471C: D44A0005
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 0000003F4720: 02020C80
	v_cmp_gt_u32_e32 vcc_lo, 16, v12                           // 0000003F4724: 7C981890
	v_mov_b32_e32 v5, v11                                      // 0000003F4728: 7E0A030B
	.long 0xd72c0007                                           // 0000003F472C: D72C0007
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 0000003F4730: 02020802
	.long 0xd44a0002                                           // 0000003F4734: D44A0002
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 0000003F4738: 02020680
	.long 0xd44a0003                                           // 0000003F473C: D44A0003
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000003F4740: 02020280
	v_subrev_nc_u32_e32 v3, s40, v8                            // 0000003F4744: 4E061028
	v_lshl_or_b32 v1, v12, 2, v9                               // 0000003F4748: D6560001 0425050C
	s_sub_i32 s40, 0, s6                                       // 0000003F4750: 81A80680
	.long 0xd72d0007                                           // 0000003F4754: D72D0007
	v_cndmask_b32_e32 v1, v4, v7, vcc_lo                       // 0000003F4758: 02020F04
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F475C: BF870001
	v_add_nc_u32_e32 v4, v4, v7                                // 0000003F4760: 4A080F04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F4764: BF870091
	.long 0xd72d0006                                           // 0000003F4768: D72D0006
	v_cndmask_b32_e32 v1, v5, v4, vcc_lo                       // 0000003F476C: 02020905
	.long 0xd72c0007                                           // 0000003F4770: D72C0007
	v_cndmask_b32_e32 v0, v6, v34, vcc_lo                      // 0000003F4774: 02004506
	v_add_nc_u32_e32 v8, 1, v6                                 // 0000003F4778: 4A100C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F477C: BF870092
	v_sub_nc_u32_e32 v7, v5, v7                                // 0000003F4780: 4C0E0F05
	v_subrev_nc_u32_e32 v9, s34, v7                            // 0000003F4784: 4E120E22
	.long 0xd44b0006                                           // 0000003F4788: D44B0006
	v_cndmask_b32_e32 v1, s34, v7, vcc_lo                      // 0000003F478C: 02020E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F4790: BF870191
	v_cndmask_b32_e64 v6, v6, v8, s6                           // 0000003F4794: D5010006 001A1106
	v_cndmask_b32_e64 v7, v7, v9, s6                           // 0000003F479C: D5010007 001A1307
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F47A4: BF870112
	v_add_nc_u32_e32 v8, 1, v6                                 // 0000003F47A8: 4A100C81
	.long 0xd44b0006                                           // 0000003F47AC: D44B0006
	v_cndmask_b32_e32 v1, s34, v7, vcc_lo                      // 0000003F47B0: 02020E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F47B4: BF870091
	v_cndmask_b32_e64 v6, v6, v8, s6                           // 0000003F47B8: D5010006 001A1106
	v_xor_b32_e32 v10, s38, v6                                 // 0000003F47C0: 3A140C26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003F47C4: BF870121
	v_subrev_nc_u32_e32 v13, s38, v10                          // 0000003F47C8: 4E1A1426
	.long 0xd72c000a                                           // 0000003F47CC: D72C000A
	v_cndmask_b32_e32 v1, 0x1400, v10, vcc_lo                  // 0000003F47D0: 020214FF 00001400
	v_min_i32_e32 v8, s35, v13                                 // 0000003F47D8: 22101A23
	v_mad_u64_u32 v[6:7], null, s40, v13, v[1:2]               // 0000003F47DC: D6FE7C06 04061A28
	.long 0xd72c000d                                           // 0000003F47E4: D72C000D
	v_cndmask_b32_e32 v1, s39, v13, vcc_lo                     // 0000003F47E8: 02021A27
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F47EC: BF870193
	v_mad_i64_i32 v[8:9], null, v8, s36, 0                     // 0000003F47F0: D6FF7C08 02004908
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000003F47F8: 340E0C9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F47FC: BF870193
	v_sub_nc_u32_e32 v10, v10, v13                             // 0000003F4800: 4C141B0A
	.long 0xd73c0008                                           // 0000003F4804: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000003F4808: 02021081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F480C: BF870193
	.long 0xd73c0006                                           // 0000003F4810: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000003F4814: 02020C81
	v_add_nc_u32_e32 v10, v3, v10                              // 0000003F4818: 4A141503
	v_add_nc_u32_e32 v3, 0x800, v3                             // 0000003F481C: 4A0606FF 00000800
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F4824: BF870094
	.long 0xd700060e                                           // 0000003F4828: D700060E
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 0000003F482C: 02021010
	v_add_co_ci_u32_e64 v15, null, s17, v9, s6                 // 0000003F4830: D5207C0F 001A1211
	s_waitcnt lgkmcnt(0)                                       // 0000003F4838: BF89FC07
	.long 0xd7000608                                           // 0000003F483C: D7000608
	v_cndmask_b32_e32 v1, s10, v6, vcc_lo                      // 0000003F4840: 02020C0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F4844: BF8700A1
	v_add_co_ci_u32_e64 v9, null, s11, v7, s6                  // 0000003F4848: D5207C09 001A0E0B
	.long 0xd7000606                                           // 0000003F4850: D7000606
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 0000003F4854: 02020D0E
	v_add_co_ci_u32_e64 v7, null, v15, v7, s6                  // 0000003F4858: D5207C07 001A0F0F
	global_load_b64 v[6:7], v[6:7], off                        // 0000003F4860: DC560000 067C0006
	global_load_b64 v[8:9], v[8:9], off                        // 0000003F4868: DC560000 087C0008
	s_waitcnt vmcnt(1)                                         // 0000003F4870: BF8907F7
	.long 0x7e1c3906                                           // 0000003F4874: 7E1C3906
	.long 0x7e1e3907                                           // 0000003F4878: 7E1E3907
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000003F487C: 360E0EFF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000003F4884: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F488C: BF870214
	v_lshlrev_b32_e32 v14, 16, v14                             // 0000003F4890: 301C1C90
	v_lshlrev_b32_e32 v15, 16, v15                             // 0000003F4894: 301E1E90
	s_waitcnt vmcnt(0)                                         // 0000003F4898: BF8903F7
	v_fma_mix_f32 v7, v9, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003F489C: CC200807 8A020F09
	v_fma_mix_f32 v6, v8, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003F48A4: CC200806 8A020D08
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F48AC: BF870112
	v_fma_mix_f32 v16, v9, v15, v7 op_sel_hi:[1,0,0]           // 0000003F48B0: CC200010 0C1E1F09
	v_fma_mix_f32 v17, v8, v14, v6 op_sel_hi:[1,0,0]           // 0000003F48B8: CC200011 0C1A1D08
	v_fma_mix_f32 v6, v8, v14, -v6 op_sel_hi:[1,0,0]           // 0000003F48C0: CC200006 8C1A1D08
	v_fma_mix_f32 v7, v9, v15, -v7 op_sel_hi:[1,0,0]           // 0000003F48C8: CC200007 8C1E1F09
	v_add_nc_u32_e32 v5, 8, v5                                 // 0000003F48D0: 4A0A0A88
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F48D4: BF870194
	v_dual_sub_f32 v14, v17, v16 :: v_dual_add_nc_u32 v1, 0x400, v1// 0000003F48D8: C9602111 0E0002FF 00000400
	v_dual_add_f32 v8, v17, v16 :: v_dual_add_f32 v9, v7, v6   // 0000003F48E4: C9082111 08080D07
	v_sub_f32_e32 v6, v6, v7                                   // 0000003F48EC: 080C0F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F48F0: BF870214
	.long 0xd4430006                                           // 0000003F48F4: D4430006
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000003F48F8: 02020A16
	v_mov_b32_dpp v16, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F48FC: 7E2002FA FF01610E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F4904: BF870004
	v_mov_b32_dpp v7, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F4908: 7E0E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 0000003F4910: D5010008 200A1108
	v_mov_b32_dpp v17, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F4918: 7E2202FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 0000003F4920: D5010006 200A0D06
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 0000003F4928: D501000E 200A1D0E
	s_or_b32 s37, s6, s37                                      // 0000003F4930: 8C252506
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F4934: BF870092
	v_dual_add_f32 v7, v8, v7 :: v_dual_add_f32 v6, v6, v17    // 0000003F4938: C9080F08 07062306
	v_mov_b32_dpp v17, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F4940: 7E2202FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 0000003F4948: D5010006 200E0D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003F4950: BF8701B1
	v_add_f32_e32 v6, v6, v17                                  // 0000003F4954: 060C2306
	v_mov_b32_dpp v15, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F4958: 7E1E02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 0000003F4960: D5010009 200A1309
	v_mov_b32_dpp v17, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F4968: 7E2202FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 0000003F4970: D5010006 20120D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003F4978: BF8701B3
	v_dual_add_f32 v8, v9, v15 :: v_dual_add_f32 v9, v14, v16  // 0000003F497C: C9081F09 0808210E
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F4984: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 0000003F498C: D5010007 200E0F07
	v_mov_b32_dpp v16, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F4994: 7E2002FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000003F499C: D5010009 200E1309
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003F49A4: BF870233
	v_add_f32_e32 v7, v7, v14                                  // 0000003F49A8: 060E1D07
	v_mov_b32_dpp v15, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F49AC: 7E1E02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 0000003F49B4: D5010008 200E1108
	v_add_f32_e32 v9, v9, v16                                  // 0000003F49BC: 06122109
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F49C0: BF870224
	v_mov_b32_dpp v14, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F49C4: 7E1C02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 0000003F49CC: D5010007 20120F07
	v_add_f32_e32 v8, v8, v15                                  // 0000003F49D4: 06101F08
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F49D8: BF870224
	v_mov_b32_dpp v16, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F49DC: 7E2002FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 0000003F49E4: D5010009 20121309
	v_add_f32_e32 v7, v7, v14                                  // 0000003F49EC: 060E1D07
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F49F0: BF870224
	v_mov_b32_dpp v15, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F49F4: 7E1E02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 0000003F49FC: D5010008 20121108
	v_add_f32_e32 v9, v9, v16                                  // 0000003F4A04: 06122109
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F4A08: BF870224
	v_mov_b32_dpp v14, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F4A0C: 7E1C02FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s5                          // 0000003F4A14: D5010007 20160F07
	v_add_f32_e32 v8, v8, v15                                  // 0000003F4A1C: 06101F08
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F4A20: BF870224
	v_mov_b32_dpp v16, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F4A24: 7E2002FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 0000003F4A2C: D5010009 20161309
	v_dual_add_f32 v6, v6, v17 :: v_dual_add_f32 v7, v7, v14   // 0000003F4A34: C9082306 06061D07
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F4A3C: BF870224
	v_mov_b32_dpp v15, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F4A40: 7E1E02FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 0000003F4A48: D5010008 20161108
	v_add_f32_e32 v9, v9, v16                                  // 0000003F4A50: 06122109
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F4A54: BF8700A4
	v_mov_b32_dpp v17, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F4A58: 7E2202FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 0000003F4A60: D5010006 20160D06
	v_add_f32_e32 v6, v6, v17                                  // 0000003F4A68: 060C2306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F4A6C: BF870091
	v_dual_add_f32 v8, v8, v15 :: v_dual_mov_b32 v17, v6       // 0000003F4A70: C9101F08 08100106
	v_mov_b32_e32 v15, v8                                      // 0000003F4A78: 7E1E0308
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003F4A7C: D5010006 21AA0D06
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003F4A84: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003F4A8C: BF870244
	v_permlanex16_b32 v17, v17, s41, 0xfedcba98                // 0000003F4A90: D65C0011 03FC5311 FEDCBA98
	v_mov_b32_e32 v14, v7                                      // 0000003F4A9C: 7E1C0307
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000003F4AA0: D5010007 21AA0F07
	v_permlanex16_b32 v15, v15, s41, 0xfedcba98                // 0000003F4AA8: D65C000F 03FC530F FEDCBA98
	v_add_f32_e32 v13, v6, v17                                 // 0000003F4AB4: 061A2306
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003F4AB8: BF8701B4
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 0000003F4ABC: D65C000E 03FC530E FEDCBA98
	v_mov_b32_e32 v16, v9                                      // 0000003F4AC8: 7E200309
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003F4ACC: D5010009 21AA1309
	v_add_f32_e32 v7, v7, v14                                  // 0000003F4AD4: 060E1D07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F4AD8: BF8701A3
	v_permlanex16_b32 v16, v16, s41, 0xfedcba98                // 0000003F4ADC: D65C0010 03FC5310 FEDCBA98
	v_add_f32_e32 v8, v8, v15                                  // 0000003F4AE8: 06101F08
	v_fma_mixlo_f16 v6, v7, s42, 0                             // 0000003F4AEC: CC210006 02005507
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F4AF4: BF870193
	v_add_f32_e32 v9, v9, v16                                  // 0000003F4AF8: 06122109
	v_fma_mixhi_f16 v6, v8, s42, 0                             // 0000003F4AFC: CC220006 02005508
	v_fma_mixhi_f16 v7, v13, s42, 0                            // 0000003F4B04: CC220007 0200550D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003F4B0C: BF870003
	v_fma_mixlo_f16 v7, v9, s42, 0                             // 0000003F4B10: CC210007 02005509
	ds_store_b64 v10, v[6:7]                                   // 0000003F4B18: D9340000 0000060A
	s_and_not1_b32 exec_lo, exec_lo, s37                       // 0000003F4B20: 917E257E
	s_cbranch_execnz 65295                                     // 0000003F4B24: BFA6FF0F <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x664>
	s_or_b32 exec_lo, exec_lo, s37                             // 0000003F4B28: 8C7E257E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F4B2C: BF870009
	s_or_b32 exec_lo, exec_lo, s33                             // 0000003F4B30: 8C7E217E
	s_bfe_i32 s6, s7, 0x1001c                                  // 0000003F4B34: 9386FF07 0001001C
	s_lshr_b32 s5, s27, 28                                     // 0000003F4B3C: 85059C1B
	s_lshr_b64 s[2:3], s[6:7], 29                              // 0000003F4B40: 85829D06
	s_add_i32 s5, s19, s5                                      // 0000003F4B44: 81050513
	s_add_i32 s2, s2, 7                                        // 0000003F4B48: 81028702
	s_lshl_b32 s4, s7, 3                                       // 0000003F4B4C: 84048307
	s_ashr_i32 s2, s2, 3                                       // 0000003F4B50: 86028302
	s_lshl_b32 s3, s29, 3                                      // 0000003F4B54: 8403831D
	.long 0xd72c0001                                           // 0000003F4B58: D72C0001
	v_cndmask_b32_e32 v1, s2, v11, vcc_lo                      // 0000003F4B5C: 02021602
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v18, 0             // 0000003F4B60: CA100080 0F120080
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v13, 2, v12    // 0000003F4B68: CA220080 140C1882
	v_mov_b32_e32 v17, 0                                       // 0000003F4B70: 7E220280
	v_mov_b32_e32 v19, 0                                       // 0000003F4B74: 7E260280
	v_mov_b32_e32 v21, 0                                       // 0000003F4B78: 7E2A0280
	v_add_nc_u32_e32 v3, s2, v1                                // 0000003F4B7C: 4A060202
	s_ashr_i32 s2, s5, 4                                       // 0000003F4B80: 86028405
	s_ashr_i32 s5, s3, 31                                      // 0000003F4B84: 86059F03
	s_mul_hi_i32 s6, s26, s2                                   // 0000003F4B88: 9706021A
	s_mul_i32 s2, s26, s2                                      // 0000003F4B8C: 9602021A
	v_min_i32_e32 v16, s4, v3                                  // 0000003F4B90: 22200604
	s_add_u32 s2, s2, s3                                       // 0000003F4B94: 80020302
	s_addc_u32 s3, s6, s5                                      // 0000003F4B98: 82030506
	v_mov_b32_e32 v25, 0                                       // 0000003F4B9C: 7E320280
	s_mul_hi_u32 s4, s2, 0x300                                 // 0000003F4BA0: 9684FF02 00000300
	v_cmp_lt_i32_e32 vcc_lo, v1, v16                           // 0000003F4BA8: 7C822101
	s_mulk_i32 s3, 0x300                                       // 0000003F4BAC: B8030300
	s_waitcnt lgkmcnt(0)                                       // 0000003F4BB0: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000003F4BB4: BC7C0000
	s_add_i32 s5, s4, s3                                       // 0000003F4BB8: 81050304
	s_mul_i32 s4, s2, 0x300                                    // 0000003F4BBC: 9604FF02 00000300
	s_barrier                                                  // 0000003F4BC4: BFBD0000
	buffer_gl0_inv                                             // 0000003F4BC8: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 0000003F4BD0: BE83206A
	s_cbranch_execz 24                                         // 0000003F4BD4: BFA50018 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xb38>
	s_add_u32 s6, s8, s4                                       // 0000003F4BD8: 80060408
	s_addc_u32 s7, s9, s5                                      // 0000003F4BDC: 82070509
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F4BE0: BF870099
	v_mad_i64_i32 v[3:4], null, 0x300, v1, s[6:7]              // 0000003F4BE4: D6FF7C03 001A02FF 00000300
	.long 0xd7000203                                           // 0000003F4BF0: D7000203
	v_cndmask_b32_e32 v1, v3, v13, vcc_lo                      // 0000003F4BF4: 02021B03
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F4BF8: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, s2                    // 0000003F4BFC: D5207C04 000A0880
	s_clause 0x5                                               // 0000003F4C04: BF850005
	global_load_b32 v17, v[3:4], off                           // 0000003F4C08: DC520000 117C0003
	global_load_b32 v18, v[3:4], off offset:128                // 0000003F4C10: DC520080 127C0003
	global_load_b32 v19, v[3:4], off offset:256                // 0000003F4C18: DC520100 137C0003
	global_load_b32 v20, v[3:4], off offset:384                // 0000003F4C20: DC520180 147C0003
	global_load_b32 v21, v[3:4], off offset:512                // 0000003F4C28: DC520200 157C0003
	global_load_b32 v25, v[3:4], off offset:640                // 0000003F4C30: DC520280 197C0003
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003F4C38: 8C7E037E
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v35, 0             // 0000003F4C3C: CA100080 24220080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v33, 0             // 0000003F4C44: CA100080 22200080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v31, 0             // 0000003F4C4C: CA100080 201E0080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v29, 0             // 0000003F4C54: CA100080 161C0080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v23, 0             // 0000003F4C5C: CA100080 1E160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v27, 0             // 0000003F4C64: CA100080 181A0080
	v_mov_b32_e32 v28, 0                                       // 0000003F4C6C: 7E380280
	v_mov_b32_e32 v26, 0                                       // 0000003F4C70: 7E340280
	v_mov_b32_e32 v14, 0                                       // 0000003F4C74: 7E1C0280
	s_ashr_i32 s27, s26, 31                                    // 0000003F4C78: 861B9F1A
	s_and_saveexec_b32 s3, vcc_lo                              // 0000003F4C7C: BE83206A
	s_cbranch_execz 1097                                       // 0000003F4C80: BFA50449 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1ca8>
	v_or_b32_e32 v4, 4, v2                                     // 0000003F4C84: 38080484
	v_mad_u32_u24 v7, v12, 24, 0x2f0                           // 0000003F4C88: D60B0007 03FD310C 000002F0
	v_mad_i64_i32 v[2:3], null, 0x300, v1, s[4:5]              // 0000003F4C94: D6FF7C02 001202FF 00000300
	v_mul_u32_u24_e32 v6, 0x320, v11                           // 0000003F4CA0: 160C16FF 00000320
	v_mul_i32_i24_e32 v8, 0xffffffe8, v12                      // 0000003F4CA8: 121018FF FFFFFFE8
	v_mad_u32_u24 v5, v4, 3, 0x2f0                             // 0000003F4CB0: D60B0005 03FD0704 000002F0
	v_cmp_lt_u32_e32 vcc_lo, 5, v4                             // 0000003F4CBC: 7C920885
	v_lshrrev_b32_e32 v22, 5, v7                               // 0000003F4CC0: 322C0E85
	v_mul_i32_i24_e32 v23, -3, v4                              // 0000003F4CC4: 122E08C3
	v_dual_mov_b32 v14, 0 :: v_dual_and_b32 v7, 0x7e0, v7      // 0000003F4CC8: CA240080 0E060EFF 000007E0
	v_lshrrev_b32_e32 v9, 5, v5                                // 0000003F4CD4: 32120A85
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v5, 0x7e0, v5      // 0000003F4CD8: CA240080 1A040AFF 000007E0
	v_mad_u32_u24 v15, 0x320, v11, v13                         // 0000003F4CE4: D60B000F 043616FF 00000320
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F4CF0: BF870214
	v_add3_u32 v37, v8, v7, 0xfffffd34                         // 0000003F4CF4: D6550025 03FE0F08 FFFFFD34
	v_subrev_nc_u32_e32 v9, 24, v9                             // 0000003F4D00: 4E121298
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003F4D04: BF870234
	v_add3_u32 v38, v23, v5, 0xfffffd34                        // 0000003F4D08: D6550026 03FE0B17 FFFFFD34
	v_sub_nc_u32_e32 v40, 0, v16                               // 0000003F4D14: 4C502080
	v_dual_mov_b32 v28, 0 :: v_dual_add_nc_u32 v41, 1, v1      // 0000003F4D18: CA200080 1C280281
	v_cndmask_b32_e32 v4, 23, v9, vcc_lo                       // 0000003F4D20: 02081297
	.long 0xd7006a02                                           // 0000003F4D24: D7006A02
	v_cndmask_b32_e32 v1, v2, v13, vcc_lo                      // 0000003F4D28: 02021B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F4D2C: BF870221
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000003F4D30: D5207C03 01AA0680
	v_subrev_nc_u32_e32 v9, 24, v22                            // 0000003F4D38: 4E122C98
	v_dual_mov_b32 v27, 0 :: v_dual_add_nc_u32 v22, 1, v4      // 0000003F4D3C: CA200080 1B160881
	v_cmp_ne_u32_e32 vcc_lo, 0, v12                            // 0000003F4D44: 7C9A1880
	v_and_b32_e32 v10, 16, v0                                  // 0000003F4D48: 36140090
	v_subrev_nc_u32_e32 v24, 23, v4                            // 0000003F4D4C: 4E300897
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v42, 0x2800, v15// 0000003F4D50: CA200080 1D2A1EFF 00002800
	v_cndmask_b32_e32 v9, 23, v9, vcc_lo                       // 0000003F4D5C: 02121297
	v_cmp_gt_u32_e32 vcc_lo, 24, v22                           // 0000003F4D60: 7C982C98
	v_lshl_or_b32 v39, v1, 5, v10                              // 0000003F4D64: D6560027 04290B01
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v15, 0             // 0000003F4D6C: CA100080 200E0080
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003F4D74: BF870244
	v_lshl_add_u32 v7, v9, 2, v6                               // 0000003F4D78: D6460007 04190509
	v_cndmask_b32_e32 v5, v24, v22, vcc_lo                     // 0000003F4D80: 020A2D18
	v_cmp_gt_i32_e32 vcc_lo, 23, v9                            // 0000003F4D84: 7C881297
	v_lshl_add_u32 v4, v4, 2, v6                               // 0000003F4D88: D6460004 04190504
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v43, 0x2800, v7 // 0000003F4D90: CA200080 182A0EFF 00002800
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003F4D9C: BF8700B4
	v_lshl_add_u32 v5, v5, 2, v6                               // 0000003F4DA0: D6460005 04190505
	v_cndmask_b32_e64 v8, 0xffffffa4, 4, vcc_lo                // 0000003F4DA8: D5010008 01A908FF FFFFFFA4
	.long 0xd7006a02                                           // 0000003F4DB4: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000003F4DB8: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 0000003F4DBC: D5207C03 01AA0609
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v45, 0x2800, v4 // 0000003F4DC4: CA200080 1E2C08FF 00002800
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F4DD0: BF870223
	.long 0xd7006a09                                           // 0000003F4DD4: D7006A09
	v_cndmask_b32_e32 v1, 0x300, v2, vcc_lo                    // 0000003F4DD8: 020204FF 00000300
	v_dual_mov_b32 v23, 0 :: v_dual_add_nc_u32 v2, v7, v8      // 0000003F4DE0: CA200080 17021107
	v_add_co_ci_u32_e64 v10, null, 0, v3, vcc_lo               // 0000003F4DE8: D5207C0A 01AA0680
	v_dual_mov_b32 v33, 0 :: v_dual_add_nc_u32 v46, 0x2800, v5 // 0000003F4DF0: CA200080 212E0AFF 00002800
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003F4DFC: BF870003
	v_dual_mov_b32 v31, 0 :: v_dual_add_nc_u32 v44, 0x2800, v2 // 0000003F4E00: CA200080 1F2C04FF 00002800
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v35, 0             // 0000003F4E0C: CA100080 16220080
	v_mov_b32_e32 v34, 0                                       // 0000003F4E14: 7E440280
	v_mov_b32_e32 v36, 0                                       // 0000003F4E18: 7E480280
	s_mov_b32 s4, 0                                            // 0000003F4E1C: BE840080
	s_movk_i32 s5, 0x1eee                                      // 0000003F4E20: B0051EEE
	s_branch 964                                               // 0000003F4E24: BFA003C4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1c38>
	s_or_b32 exec_lo, exec_lo, s2                              // 0000003F4E28: 8C7E027E
	ds_load_2addr_b32 v[47:48], v44 offset1:24                 // 0000003F4E2C: D8DC1800 2F00002C
	ds_load_2addr_b32 v[49:50], v46 offset1:24                 // 0000003F4E34: D8DC1800 3100002E
	ds_load_2addr_b32 v[2:3], v43 offset1:24                   // 0000003F4E3C: D8DC1800 0200002B
	ds_load_2addr_b32 v[53:54], v45 offset1:24                 // 0000003F4E44: D8DC1800 3500002D
	.long 0xd7000209                                           // 0000003F4E4C: D7000209
	v_cndmask_b32_e32 v1, 0x300, v9, vcc_lo                    // 0000003F4E50: 020212FF 00000300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F4E58: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v10, s2                  // 0000003F4E5C: D5207C0A 000A1480
	v_add_nc_u32_e32 v41, 1, v41                               // 0000003F4E64: 4A525281
	s_waitcnt lgkmcnt(2)                                       // 0000003F4E68: BF89FC27
	v_dual_mov_b32 v1, v47 :: v_dual_mov_b32 v52, v49          // 0000003F4E6C: CA10012F 01340131
	s_waitcnt lgkmcnt(0)                                       // 0000003F4E74: BF89FC07
	v_mov_b32_e32 v51, v54                                     // 0000003F4E78: 7E660336
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F4E7C: BF870192
	.long 0xd73d0038                                           // 0000003F4E80: D73D0038
	v_cndmask_b32_e32 v1, v37, v1, vcc_lo                      // 0000003F4E84: 02020325
	.long 0xd73d0034                                           // 0000003F4E88: D73D0034
	v_cndmask_b32_e32 v1, v38, v52, vcc_lo                     // 0000003F4E8C: 02026926
	v_mov_b32_e32 v49, v3                                      // 0000003F4E90: 7E620303
	ds_load_b128 v[1:4], v39                                   // 0000003F4E94: DBFC0000 01000027
	ds_load_b128 v[5:8], v39 offset:5120                       // 0000003F4E9C: DBFC1400 05000027
	ds_load_2addr_b32 v[54:55], v44 offset0:48 offset1:72      // 0000003F4EA4: D8DC4830 3600002C
	v_add_nc_u32_e32 v39, 32, v39                              // 0000003F4EAC: 4A4E4EA0
	.long 0xd73d002f                                           // 0000003F4EB0: D73D002F
	v_cndmask_b32_e32 v1, v37, v48, vcc_lo                     // 0000003F4EB4: 02026125
	.long 0xd73d0030                                           // 0000003F4EB8: D73D0030
	v_cndmask_b32_e32 v1, v38, v50, vcc_lo                     // 0000003F4EBC: 02026526
	v_bfe_u32 v49, v56, 9, 16                                  // 0000003F4EC0: D6100031 02411338
	v_bfe_u32 v50, v56, 6, 16                                  // 0000003F4EC8: D6100032 02410D38
	v_bfe_u32 v51, v56, 3, 16                                  // 0000003F4ED0: D6100033 02410738
	v_bfe_u32 v57, v52, 6, 16                                  // 0000003F4ED8: D6100039 02410D34
	v_bfe_u32 v59, v47, 9, 16                                  // 0000003F4EE0: D610003B 0241132F
	.long 0xd72c0031                                           // 0000003F4EE8: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 0000003F4EEC: 020262FF 83DCD12D
	.long 0xd72c0032                                           // 0000003F4EF4: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000003F4EF8: 020264FF 83DCD12D
	v_bfe_u32 v60, v47, 6, 16                                  // 0000003F4F00: D610003C 02410D2F
	.long 0xd72c0033                                           // 0000003F4F08: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000003F4F0C: 020266FF 83DCD12D
	.long 0xd72c003b                                           // 0000003F4F14: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000003F4F18: 020276FF 83DCD12D
	v_bfe_u32 v61, v47, 3, 16                                  // 0000003F4F20: D610003D 0241072F
	v_bfe_u32 v58, v52, 3, 16                                  // 0000003F4F28: D610003A 02410734
	.long 0xd72c003c                                           // 0000003F4F30: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000003F4F34: 020278FF 83DCD12D
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000003F4F3C: D6220031 03FD0131 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000003F4F48: D6220032 03FD0132 00006400
	.long 0xd72c003d                                           // 0000003F4F54: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000003F4F58: 02027AFF 83DCD12D
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000003F4F60: D6220033 03FD0133 00006400
	.long 0xd72c003a                                           // 0000003F4F6C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000003F4F70: 020274FF 83DCD12D
	v_and_b32_e32 v49, 0xffff, v49                             // 0000003F4F78: 366262FF 0000FFFF
	.long 0xd72c0039                                           // 0000003F4F80: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000003F4F84: 020272FF 83DCD12D
	v_bfe_u32 v62, v48, 9, 16                                  // 0000003F4F8C: D610003E 02411330
	v_bfe_u32 v63, v48, 6, 16                                  // 0000003F4F94: D610003F 02410D30
	v_bfe_u32 v64, v48, 3, 16                                  // 0000003F4F9C: D6100040 02410730
	v_lshl_or_b32 v49, v50, 16, v49                            // 0000003F4FA4: D6560031 04C52132
	v_sad_u8 v50, v59, 0, 0x6400                               // 0000003F4FAC: D6220032 03FD013B 00006400
	v_sad_u8 v59, v60, 0, 0x6400                               // 0000003F4FB8: D622003B 03FD013C 00006400
	v_and_b32_e32 v48, 0xffff, v48                             // 0000003F4FC4: 366060FF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000003F4FCC: D622003A 03FD013A 00006400
	v_pk_fma_f16 v49, v49, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F4FD8: CC0E0031 0BFC0B31 0000C931
	v_and_b32_e32 v53, 0xffff, v56                             // 0000003F4FE4: 366A70FF 0000FFFF
	v_bfe_u32 v56, v52, 9, 16                                  // 0000003F4FEC: D6100038 02411334
	v_and_b32_e32 v50, 0xffff, v50                             // 0000003F4FF4: 366464FF 0000FFFF
	v_and_b32_e32 v52, 0xffff, v52                             // 0000003F4FFC: 366868FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 0000003F5004: BF89FC27
	v_dot2acc_f32_f16 v14, v49, v1                             // 0000003F5008: 041C0331
	.long 0xd72c0035                                           // 0000003F500C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000003F5010: 02026AFF 83DCD12D
	.long 0xd72c0038                                           // 0000003F5018: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000003F501C: 020270FF 83DCD12D
	v_lshl_or_b32 v59, v59, 16, v50                            // 0000003F5024: D656003B 04C9213B
	.long 0xd72c0034                                           // 0000003F502C: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000003F5030: 020268FF 83DCD12D
	.long 0xd72c003e                                           // 0000003F5038: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000003F503C: 02027CFF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000003F5044: D6220039 03FD0139 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003F5050: BF870244
	v_pk_fma_f16 v59, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5054: CC0E003B 0BFC0B3B 0000C931
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000003F5060: D6220035 03FD0135 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000003F506C: D6220038 03FD0138 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000003F5078: D6220034 03FD0134 00006400
	v_dot2acc_f32_f16 v27, v59, v1                             // 0000003F5084: 0436033B
	s_waitcnt lgkmcnt(1)                                       // 0000003F5088: BF89FC17
	v_dot2acc_f32_f16 v26, v49, v5                             // 0000003F508C: 04340B31
	v_lshlrev_b32_e32 v53, 16, v53                             // 0000003F5090: 306A6A90
	v_and_b32_e32 v56, 0xffff, v56                             // 0000003F5094: 367070FF 0000FFFF
	v_lshlrev_b32_e32 v52, 16, v52                             // 0000003F509C: 30686890
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F50A0: BF870223
	v_and_or_b32 v51, 0xffff, v51, v53                         // 0000003F50A4: D6570033 04D666FF 0000FFFF
	v_sad_u8 v53, v61, 0, 0x6400                               // 0000003F50B0: D6220035 03FD013D 00006400
	v_lshl_or_b32 v56, v57, 16, v56                            // 0000003F50BC: D6560038 04E12139
	v_sad_u8 v57, v62, 0, 0x6400                               // 0000003F50C4: D6220039 03FD013E 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F50D0: BF8701A4
	v_pk_fma_f16 v60, v51, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F50D4: CC0E003C 0BFC0B33 0000C931
	v_and_b32_e32 v47, 0xffff, v47                             // 0000003F50E0: 365E5EFF 0000FFFF
	v_and_b32_e32 v62, 0xffff, v57                             // 0000003F50E8: 367C72FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F50F0: BF870193
	v_dot2acc_f32_f16 v14, v60, v2                             // 0000003F50F4: 041C053C
	.long 0xd72c002f                                           // 0000003F50F8: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000003F50FC: 02025EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F5104: BF870091
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000003F5108: D622002F 03FD012F 00006400
	v_lshlrev_b32_e32 v47, 16, v47                             // 0000003F5114: 305E5E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003F5118: BF870121
	v_and_or_b32 v47, 0xffff, v53, v47                         // 0000003F511C: D657002F 04BE6AFF 0000FFFF
	.long 0xd72c0035                                           // 0000003F5128: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 0000003F512C: 020280FF 83DCD12D
	v_pk_fma_f16 v64, v47, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5134: CC0E0040 0BFC0B2F 0000C931
	s_waitcnt lgkmcnt(0)                                       // 0000003F5140: BF89FC07
	v_mov_b32_e32 v47, v54                                     // 0000003F5144: 7E5E0336
	v_and_or_b32 v51, 0xffff, v58, v52                         // 0000003F5148: D6570033 04D274FF 0000FFFF
	.long 0xd72c003a                                           // 0000003F5154: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 0000003F5158: 020260FF 83DCD12D
	ds_load_2addr_b32 v[48:49], v43 offset0:48 offset1:72      // 0000003F5160: D8DC4830 3000002B
	v_pk_fma_f16 v52, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5168: CC0E0034 0BFC0B38 0000C931
	.long 0xd72c0038                                           // 0000003F5174: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 0000003F5178: 02027EFF 83DCD12D
	v_pk_fma_f16 v61, v51, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5180: CC0E003D 0BFC0B33 0000C931
	ds_load_2addr_b32 v[50:51], v46 offset0:48 offset1:72      // 0000003F518C: D8DC4830 3200002E
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000003F5194: D6220035 03FD0135 00006400
	v_dot2acc_f32_f16 v27, v64, v2                             // 0000003F51A0: 04360540
	v_sad_u8 v63, v58, 0, 0x6400                               // 0000003F51A4: D622003F 03FD013A 00006400
	ds_load_2addr_b32 v[57:58], v45 offset0:48 offset1:72      // 0000003F51B0: D8DC4830 3900002D
	v_dot2acc_f32_f16 v26, v60, v6                             // 0000003F51B8: 04340D3C
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000003F51BC: D6220038 03FD0138 00006400
	v_dot2acc_f32_f16 v14, v52, v3                             // 0000003F51C8: 041C0734
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F51CC: BF870193
	v_dot2acc_f32_f16 v26, v52, v7                             // 0000003F51D0: 04340F34
	v_lshl_or_b32 v56, v56, 16, v62                            // 0000003F51D4: D6560038 04F92138
	v_lshlrev_b32_e32 v62, 16, v63                             // 0000003F51DC: 307C7E90
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F51E0: BF870004
	v_dot2acc_f32_f16 v14, v61, v4                             // 0000003F51E4: 041C093D
	s_waitcnt lgkmcnt(2)                                       // 0000003F51E8: BF89FC27
	.long 0xd73d002f                                           // 0000003F51EC: D73D002F
	v_cndmask_b32_e32 v1, v37, v47, vcc_lo                     // 0000003F51F0: 02025F25
	v_pk_fma_f16 v54, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F51F4: CC0E0036 0BFC0B38 0000C931
	v_and_or_b32 v53, 0xffff, v53, v62                         // 0000003F5200: D6570035 04FA6AFF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 0000003F520C: BF89FC17
	v_mov_b32_e32 v56, v50                                     // 0000003F5210: 7E700332
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F5214: BF870194
	v_bfe_u32 v48, v47, 9, 16                                  // 0000003F5218: D6100030 0241132F
	v_pk_fma_f16 v60, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5220: CC0E003C 0BFC0B35 0000C931
	v_and_b32_e32 v50, 0xffff, v47                             // 0000003F522C: 36645EFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 0000003F5234: BF89FC07
	.long 0xd73d0034                                           // 0000003F5238: D73D0034
	v_cndmask_b32_e32 v1, v38, v56, vcc_lo                     // 0000003F523C: 02027126
	v_bfe_u32 v53, v47, 6, 16                                  // 0000003F5240: D6100035 02410D2F
	.long 0xd72c0030                                           // 0000003F5248: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 0000003F524C: 020260FF 83DCD12D
	v_bfe_u32 v47, v47, 3, 16                                  // 0000003F5254: D610002F 0241072F
	.long 0xd72c0032                                           // 0000003F525C: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000003F5260: 020264FF 83DCD12D
	v_dot2acc_f32_f16 v27, v54, v3                             // 0000003F5268: 04360736
	v_bfe_u32 v56, v52, 9, 16                                  // 0000003F526C: D6100038 02411334
	.long 0xd72c0035                                           // 0000003F5274: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000003F5278: 02026AFF 83DCD12D
	v_bfe_u32 v57, v52, 6, 16                                  // 0000003F5280: D6100039 02410D34
	.long 0xd72c002f                                           // 0000003F5288: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000003F528C: 02025EFF 83DCD12D
	v_sad_u8 v48, v48, 0, 0x6400                               // 0000003F5294: D6220030 03FD0130 00006400
	.long 0xd72c0038                                           // 0000003F52A0: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000003F52A4: 020270FF 83DCD12D
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000003F52AC: D6220032 03FD0132 00006400
	.long 0xd72c0039                                           // 0000003F52B8: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000003F52BC: 020272FF 83DCD12D
	v_dot2acc_f32_f16 v27, v60, v4                             // 0000003F52C4: 0436093C
	v_and_b32_e32 v48, 0xffff, v48                             // 0000003F52C8: 366060FF 0000FFFF
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000003F52D0: D6220035 03FD0135 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000003F52DC: D622002F 03FD012F 00006400
	v_lshlrev_b32_e32 v50, 16, v50                             // 0000003F52E8: 30646490
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000003F52EC: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F52F8: BF870194
	v_lshl_or_b32 v48, v53, 16, v48                            // 0000003F52FC: D6560030 04C12135
	v_and_or_b32 v47, 0xffff, v47, v50                         // 0000003F5304: D657002F 04CA5EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F5310: BF870223
	v_and_b32_e32 v53, 0xffff, v56                             // 0000003F5314: 366A70FF 0000FFFF
	v_sad_u8 v56, v57, 0, 0x6400                               // 0000003F531C: D6220038 03FD0139 00006400
	v_pk_fma_f16 v48, v48, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5328: CC0E0030 0BFC0B30 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F5334: BF870194
	v_pk_fma_f16 v47, v47, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5338: CC0E002F 0BFC0B2F 0000C931
	v_lshl_or_b32 v53, v56, 16, v53                            // 0000003F5344: D6560035 04D52138
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F534C: BF8701A3
	v_dot2acc_f32_f16 v24, v48, v1                             // 0000003F5350: 04300330
	v_dual_dot2acc_f32_f16 v23, v48, v5 :: v_dual_mov_b32 v56, v49// 0000003F5354: CB100B30 17380131
	v_pk_fma_f16 v49, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F535C: CC0E0031 0BFC0B35 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F5368: BF870193
	v_dot2acc_f32_f16 v24, v47, v2                             // 0000003F536C: 0430052F
	v_dot2acc_f32_f16 v23, v47, v6                             // 0000003F5370: 042E0D2F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003F5374: BF870234
	.long 0xd73d002f                                           // 0000003F5378: D73D002F
	v_cndmask_b32_e32 v1, v37, v55, vcc_lo                     // 0000003F537C: 02026F25
	v_dot2acc_f32_f16 v26, v61, v8                             // 0000003F5380: 0434113D
	v_bfe_u32 v61, v52, 3, 16                                  // 0000003F5384: D610003D 02410734
	v_dual_dot2acc_f32_f16 v23, v49, v7 :: v_dual_and_b32 v52, 0xffff, v52// 0000003F538C: CB240F31 173468FF 0000FFFF
	v_dot2acc_f32_f16 v24, v49, v3                             // 0000003F5398: 04300731
	v_bfe_u32 v53, v47, 9, 16                                  // 0000003F539C: D6100035 0241132F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F53A4: BF870214
	.long 0xd72c0032                                           // 0000003F53A8: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000003F53AC: 02027AFF 83DCD12D
	.long 0xd72c0034                                           // 0000003F53B4: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000003F53B8: 020268FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F53C0: BF870112
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000003F53C4: D6220032 03FD0132 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000003F53D0: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F53DC: BF870091
	v_lshlrev_b32_e32 v52, 16, v52                             // 0000003F53E0: 30686890
	v_and_or_b32 v50, 0xffff, v50, v52                         // 0000003F53E4: D6570032 04D264FF 0000FFFF
	v_mov_b32_e32 v52, v58                                     // 0000003F53F0: 7E68033A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F53F4: BF870112
	v_pk_fma_f16 v48, v50, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F53F8: CC0E0030 0BFC0B32 0000C931
	.long 0xd73d0031                                           // 0000003F5404: D73D0031
	v_cndmask_b32_e32 v1, v38, v51, vcc_lo                     // 0000003F5408: 02026726
	v_bfe_u32 v50, v47, 6, 16                                  // 0000003F540C: D6100032 02410D2F
	v_bfe_u32 v51, v47, 3, 16                                  // 0000003F5414: D6100033 0241072F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003F541C: BF870234
	v_dual_dot2acc_f32_f16 v24, v48, v4 :: v_dual_and_b32 v47, 0xffff, v47// 0000003F5420: CB240930 182E5EFF 0000FFFF
	v_dot2acc_f32_f16 v23, v48, v8                             // 0000003F542C: 042E1130
	v_bfe_u32 v52, v49, 9, 16                                  // 0000003F5430: D6100034 02411331
	.long 0xd72c0038                                           // 0000003F5438: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000003F543C: 020266FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F5444: BF870004
	.long 0xd72c0039                                           // 0000003F5448: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000003F544C: 02025EFF 83DCD12D
	.long 0xd72c0030                                           // 0000003F5454: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000003F5458: 02026AFF 83DCD12D
	.long 0xd72c0032                                           // 0000003F5460: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000003F5464: 020264FF 83DCD12D
	v_bfe_u32 v55, v49, 3, 16                                  // 0000003F546C: D6100037 02410731
	v_sad_u8 v61, v56, 0, 0x6400                               // 0000003F5474: D622003D 03FD0138 00006400
	v_sad_u8 v56, v57, 0, 0x6400                               // 0000003F5480: D6220038 03FD0139 00006400
	v_dot2acc_f32_f16 v28, v59, v5                             // 0000003F548C: 04380B3B
	.long 0xd72c003b                                           // 0000003F5490: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000003F5494: 020268FF 83DCD12D
	v_sad_u8 v53, v48, 0, 0x6400                               // 0000003F549C: D6220035 03FD0130 00006400
	ds_load_2addr_b32 v[47:48], v44 offset0:96 offset1:120     // 0000003F54A8: D8DC7860 2F00002C
	.long 0xd72c003e                                           // 0000003F54B0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000003F54B4: 02026EFF 83DCD12D
	v_and_b32_e32 v58, 0xffff, v53                             // 0000003F54BC: 36746AFF 0000FFFF
	ds_load_2addr_b32 v[52:53], v46 offset0:96 offset1:120     // 0000003F54C4: D8DC7860 3400002E
	v_sad_u8 v57, v59, 0, 0x6400                               // 0000003F54CC: D6220039 03FD013B 00006400
	v_dual_dot2acc_f32_f16 v28, v64, v6 :: v_dual_lshlrev_b32 v59, 16, v56// 0000003F54D8: CB220D40 1C3A7090
	ds_load_2addr_b32 v[55:56], v45 offset0:96 offset1:120     // 0000003F54E0: D8DC7860 3700002D
	v_and_b32_e32 v57, 0xffff, v57                             // 0000003F54E8: 367272FF 0000FFFF
	v_and_or_b32 v59, 0xffff, v61, v59                         // 0000003F54F0: D657003B 04EE7AFF 0000FFFF
	v_dot2acc_f32_f16 v28, v54, v7                             // 0000003F54FC: 04380F36
	v_bfe_u32 v54, v49, 6, 16                                  // 0000003F5500: D6100036 02410D31
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003F5508: BF870002
	v_dual_dot2acc_f32_f16 v28, v60, v8 :: v_dual_and_b32 v49, 0xffff, v49// 0000003F550C: CB24113C 1C3062FF 0000FFFF
	v_sad_u8 v60, v50, 0, 0x6400                               // 0000003F5518: D622003C 03FD0132 00006400
	ds_load_2addr_b32 v[50:51], v43 offset0:96 offset1:120     // 0000003F5524: D8DC7860 3200002B
	.long 0xd72c0031                                           // 0000003F552C: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 0000003F5530: 020262FF 83DCD12D
	.long 0xd72c0036                                           // 0000003F5538: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000003F553C: 02026CFF 83DCD12D
	v_lshl_or_b32 v58, v60, 16, v58                            // 0000003F5544: D656003A 04E9213C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F554C: BF870193
	v_sad_u8 v60, v49, 0, 0x6400                               // 0000003F5550: D622003C 03FD0131 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000003F555C: D6220036 03FD0136 00006400
	s_waitcnt lgkmcnt(3)                                       // 0000003F5568: BF89FC37
	v_mov_b32_e32 v49, v47                                     // 0000003F556C: 7E62032F
	v_sad_u8 v47, v62, 0, 0x6400                               // 0000003F5570: D622002F 03FD013E 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000003F557C: BF8701C3
	v_lshl_or_b32 v54, v54, 16, v57                            // 0000003F5580: D6560036 04E52136
	v_pk_fma_f16 v57, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5588: CC0E0039 0BFC0B3A 0000C931
	s_waitcnt lgkmcnt(0)                                       // 0000003F5594: BF89FC07
	.long 0xd73d0031                                           // 0000003F5598: D73D0031
	v_cndmask_b32_e32 v1, v37, v49, vcc_lo                     // 0000003F559C: 02026325
	v_pk_fma_f16 v58, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F55A0: CC0E003A 0BFC0B36 0000C931
	v_mov_b32_e32 v54, v52                                     // 0000003F55AC: 7E6C0334
	v_pk_fma_f16 v50, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F55B0: CC0E0032 0BFC0B3B 0000C931
	v_dot2acc_f32_f16 v29, v57, v1                             // 0000003F55BC: 043A0339
	v_dot2acc_f32_f16 v30, v57, v5                             // 0000003F55C0: 043C0B39
	v_bfe_u32 v52, v49, 9, 16                                  // 0000003F55C4: D6100034 02411331
	.long 0xd73d0036                                           // 0000003F55CC: D73D0036
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 0000003F55D0: 02026D26
	v_bfe_u32 v55, v49, 6, 16                                  // 0000003F55D4: D6100037 02410D31
	v_dot2acc_f32_f16 v29, v50, v2                             // 0000003F55DC: 043A0532
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F55E0: BF870194
	.long 0xd72c0034                                           // 0000003F55E4: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000003F55E8: 020268FF 83DCD12D
	.long 0xd72c0037                                           // 0000003F55F0: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000003F55F4: 02026EFF 83DCD12D
	v_bfe_u32 v61, v54, 6, 16                                  // 0000003F55FC: D610003D 02410D36
	v_bfe_u32 v62, v54, 3, 16                                  // 0000003F5604: D610003E 02410736
	v_dot2acc_f32_f16 v29, v58, v3                             // 0000003F560C: 043A073A
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000003F5610: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F561C: BF8701A4
	.long 0xd72c003d                                           // 0000003F5620: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000003F5624: 02027AFF 83DCD12D
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000003F562C: D6220037 03FD0137 00006400
	v_and_b32_e32 v52, 0xffff, v52                             // 0000003F5638: 366868FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F5640: BF870091
	v_lshl_or_b32 v52, v55, 16, v52                            // 0000003F5644: D6560034 04D12137
	v_pk_fma_f16 v52, v52, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F564C: CC0E0034 0BFC0B34 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F5658: BF870091
	v_dual_dot2acc_f32_f16 v31, v52, v5 :: v_dual_lshlrev_b32 v60, 16, v60// 0000003F565C: CB220B34 1F3C7890
	v_and_or_b32 v47, 0xffff, v47, v60                         // 0000003F5664: D657002F 04F25EFF 0000FFFF
	v_bfe_u32 v60, v54, 9, 16                                  // 0000003F5670: D610003C 02411336
	v_and_b32_e32 v54, 0xffff, v54                             // 0000003F5678: 366C6CFF 0000FFFF
	v_dot2acc_f32_f16 v22, v52, v1                             // 0000003F5680: 042C0334
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F5684: BF870004
	v_pk_fma_f16 v59, v47, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5688: CC0E003B 0BFC0B2F 0000C931
	v_and_b32_e32 v47, 0xffff, v49                             // 0000003F5694: 365E62FF 0000FFFF
	v_bfe_u32 v49, v49, 3, 16                                  // 0000003F569C: D6100031 02410731
	.long 0xd72c003c                                           // 0000003F56A4: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000003F56A8: 020278FF 83DCD12D
	.long 0xd72c0036                                           // 0000003F56B0: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000003F56B4: 02026CFF 83DCD12D
	v_dot2acc_f32_f16 v29, v59, v4                             // 0000003F56BC: 043A093B
	.long 0xd72c002f                                           // 0000003F56C0: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000003F56C4: 02025EFF 83DCD12D
	.long 0xd72c0031                                           // 0000003F56CC: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 0000003F56D0: 020262FF 83DCD12D
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000003F56D8: D622003C 03FD013C 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000003F56E4: D6220036 03FD0136 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F56F0: BF870214
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000003F56F4: D622002F 03FD012F 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000003F5700: D6220031 03FD0131 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F570C: BF870224
	v_and_b32_e32 v55, 0xffff, v60                             // 0000003F5710: 366E78FF 0000FFFF
	v_sad_u8 v60, v61, 0, 0x6400                               // 0000003F5718: D622003C 03FD013D 00006400
	v_lshlrev_b32_e32 v47, 16, v47                             // 0000003F5724: 305E5E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003F5728: BF870121
	v_and_or_b32 v47, 0xffff, v49, v47                         // 0000003F572C: D657002F 04BE62FF 0000FFFF
	.long 0xd72c0031                                           // 0000003F5738: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000003F573C: 02027CFF 83DCD12D
	v_pk_fma_f16 v57, v47, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5744: CC0E0039 0BFC0B2F 0000C931
	v_lshl_or_b32 v47, v60, 16, v55                            // 0000003F5750: D656002F 04DD213C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F5758: BF8701A3
	v_sad_u8 v55, v49, 0, 0x6400                               // 0000003F575C: D6220037 03FD0131 00006400
	v_mov_b32_e32 v49, v51                                     // 0000003F5768: 7E620333
	v_pk_fma_f16 v60, v47, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F576C: CC0E003C 0BFC0B2F 0000C931
	v_dot2acc_f32_f16 v31, v57, v6                             // 0000003F5778: 043E0D39
	v_lshlrev_b32_e32 v54, 16, v54                             // 0000003F577C: 306C6C90
	v_dot2acc_f32_f16 v22, v57, v2                             // 0000003F5780: 042C0539
	.long 0xd73d002f                                           // 0000003F5784: D73D002F
	v_cndmask_b32_e32 v1, v37, v48, vcc_lo                     // 0000003F5788: 02026125
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F578C: BF870114
	v_dot2acc_f32_f16 v31, v60, v7                             // 0000003F5790: 043E0F3C
	v_and_b32_e32 v51, 0xffff, v47                             // 0000003F5794: 36665EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F579C: BF870091
	.long 0xd72c0033                                           // 0000003F57A0: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000003F57A4: 020266FF 83DCD12D
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000003F57AC: D6220033 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003F57B8: BF8701B1
	v_dual_dot2acc_f32_f16 v30, v50, v6 :: v_dual_lshlrev_b32 v57, 16, v51// 0000003F57BC: CB220D32 1E386690
	v_and_or_b32 v50, 0xffff, v55, v54                         // 0000003F57C4: D6570032 04DA6EFF 0000FFFF
	v_mov_b32_e32 v54, v56                                     // 0000003F57D0: 7E6C0338
	v_dot2acc_f32_f16 v30, v58, v7                             // 0000003F57D4: 043C0F3A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F57D8: BF870223
	v_pk_fma_f16 v58, v50, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F57DC: CC0E003A 0BFC0B32 0000C931
	v_bfe_u32 v50, v47, 9, 16                                  // 0000003F57E8: D6100032 0241132F
	.long 0xd73d0030                                           // 0000003F57F0: D73D0030
	v_cndmask_b32_e32 v1, v38, v53, vcc_lo                     // 0000003F57F4: 02026B26
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F57F8: BF870214
	v_dot2acc_f32_f16 v30, v59, v8                             // 0000003F57FC: 043C113B
	v_dot2acc_f32_f16 v31, v58, v8                             // 0000003F5800: 043E113A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F5804: BF870004
	.long 0xd72c0031                                           // 0000003F5808: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000003F580C: 020264FF 83DCD12D
	v_bfe_u32 v50, v47, 6, 16                                  // 0000003F5814: D6100032 02410D2F
	v_bfe_u32 v47, v47, 3, 16                                  // 0000003F581C: D610002F 0241072F
	v_bfe_u32 v52, v48, 9, 16                                  // 0000003F5824: D6100034 02411330
	v_bfe_u32 v53, v48, 6, 16                                  // 0000003F582C: D6100035 02410D30
	v_bfe_u32 v54, v48, 3, 16                                  // 0000003F5834: D6100036 02410730
	.long 0xd72c0032                                           // 0000003F583C: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000003F5840: 020264FF 83DCD12D
	.long 0xd72c002f                                           // 0000003F5848: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000003F584C: 02025EFF 83DCD12D
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000003F5854: D6220031 03FD0131 00006400
	.long 0xd72c0034                                           // 0000003F5860: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000003F5864: 020268FF 83DCD12D
	v_and_b32_e32 v55, 0xffff, v48                             // 0000003F586C: 366E60FF 0000FFFF
	.long 0xd72c003b                                           // 0000003F5874: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000003F5878: 02026AFF 83DCD12D
	.long 0xd72c0036                                           // 0000003F5880: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000003F5884: 02026CFF 83DCD12D
	v_and_b32_e32 v49, 0xffff, v49                             // 0000003F588C: 366262FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000003F5894: D6220032 03FD0132 00006400
	v_sad_u8 v56, v47, 0, 0x6400                               // 0000003F58A0: D6220038 03FD012F 00006400
	ds_load_2addr_b32 v[47:48], v44 offset0:144 offset1:168    // 0000003F58AC: D8DCA890 2F00002C
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000003F58B4: D6220034 03FD0134 00006400
	.long 0xd72c0037                                           // 0000003F58C0: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000003F58C4: 02026EFF 83DCD12D
	v_lshl_or_b32 v49, v50, 16, v49                            // 0000003F58CC: D6560031 04C52132
	ds_load_2addr_b32 v[50:51], v43 offset0:144 offset1:168    // 0000003F58D4: D8DCA890 3200002B
	v_and_or_b32 v56, 0xffff, v56, v57                         // 0000003F58DC: D6570038 04E670FF 0000FFFF
	v_and_b32_e32 v57, 0xffff, v52                             // 0000003F58E8: 367268FF 0000FFFF
	ds_load_2addr_b32 v[52:53], v46 offset0:144 offset1:168    // 0000003F58F0: D8DCA890 3400002E
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000003F58F8: D622003B 03FD013B 00006400
	v_pk_fma_f16 v49, v49, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5904: CC0E0031 0BFC0B31 0000C931
	v_sad_u8 v61, v55, 0, 0x6400                               // 0000003F5910: D622003D 03FD0137 00006400
	v_pk_fma_f16 v62, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F591C: CC0E003E 0BFC0B38 0000C931
	ds_load_2addr_b32 v[55:56], v45 offset0:144 offset1:168    // 0000003F5928: D8DCA890 3700002D
	v_lshl_or_b32 v57, v59, 16, v57                            // 0000003F5930: D6560039 04E5213B
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000003F5938: D6220036 03FD0136 00006400
	v_lshlrev_b32_e32 v59, 16, v61                             // 0000003F5944: 30767A90
	v_dot2acc_f32_f16 v32, v49, v1                             // 0000003F5948: 04400331
	v_dual_dot2acc_f32_f16 v33, v49, v5 :: v_dual_dot2acc_f32_f16 v22, v60, v3// 0000003F594C: CB180B31 2116073C
	s_waitcnt lgkmcnt(3)                                       // 0000003F5954: BF89FC37
	v_mov_b32_e32 v49, v47                                     // 0000003F5958: 7E62032F
	v_and_or_b32 v54, 0xffff, v54, v59                         // 0000003F595C: D6570036 04EE6CFF 0000FFFF
	v_pk_fma_f16 v47, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5968: CC0E002F 0BFC0B39 0000C931
	v_dot2acc_f32_f16 v32, v62, v2                             // 0000003F5974: 0440053E
	v_dot2acc_f32_f16 v33, v62, v6                             // 0000003F5978: 04420D3E
	s_waitcnt lgkmcnt(2)                                       // 0000003F597C: BF89FC27
	.long 0xd73d0031                                           // 0000003F5980: D73D0031
	v_cndmask_b32_e32 v1, v37, v49, vcc_lo                     // 0000003F5984: 02026325
	v_pk_fma_f16 v50, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5988: CC0E0032 0BFC0B36 0000C931
	s_waitcnt lgkmcnt(1)                                       // 0000003F5994: BF89FC17
	v_mov_b32_e32 v54, v52                                     // 0000003F5998: 7E6C0334
	v_dual_dot2acc_f32_f16 v22, v58, v4 :: v_dual_dot2acc_f32_f16 v33, v47, v7// 0000003F599C: CB18093A 16200F2F
	v_dot2acc_f32_f16 v32, v47, v3                             // 0000003F59A4: 0440072F
	v_and_b32_e32 v52, 0xffff, v49                             // 0000003F59A8: 366862FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 0000003F59B0: BF89FC07
	.long 0xd73d0036                                           // 0000003F59B4: D73D0036
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 0000003F59B8: 02026D26
	v_bfe_u32 v47, v49, 9, 16                                  // 0000003F59BC: D610002F 02411331
	v_dot2acc_f32_f16 v33, v50, v8                             // 0000003F59C4: 04421132
	v_dot2acc_f32_f16 v32, v50, v4                             // 0000003F59C8: 04400932
	v_bfe_u32 v50, v49, 6, 16                                  // 0000003F59CC: D6100032 02410D31
	v_bfe_u32 v49, v49, 3, 16                                  // 0000003F59D4: D6100031 02410731
	.long 0xd72c0034                                           // 0000003F59DC: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000003F59E0: 020268FF 83DCD12D
	.long 0xd72c002f                                           // 0000003F59E8: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000003F59EC: 02025EFF 83DCD12D
	v_bfe_u32 v55, v54, 9, 16                                  // 0000003F59F4: D6100037 02411336
	.long 0xd72c0032                                           // 0000003F59FC: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000003F5A00: 020264FF 83DCD12D
	.long 0xd72c0031                                           // 0000003F5A08: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 0000003F5A0C: 020262FF 83DCD12D
	v_and_b32_e32 v58, 0xffff, v54                             // 0000003F5A14: 36746CFF 0000FFFF
	v_bfe_u32 v57, v54, 6, 16                                  // 0000003F5A1C: D6100039 02410D36
	.long 0xd72c0037                                           // 0000003F5A24: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000003F5A28: 02026EFF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000003F5A30: D6220034 03FD0134 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000003F5A3C: D622002F 03FD012F 00006400
	v_bfe_u32 v54, v54, 3, 16                                  // 0000003F5A48: D6100036 02410736
	.long 0xd72c003a                                           // 0000003F5A50: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000003F5A54: 020274FF 83DCD12D
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000003F5A5C: D6220031 03FD0131 00006400
	v_lshlrev_b32_e32 v52, 16, v52                             // 0000003F5A68: 30686890
	v_and_b32_e32 v47, 0xffff, v47                             // 0000003F5A6C: 365E5EFF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000003F5A74: D6220032 03FD0132 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000003F5A80: D6220037 03FD0137 00006400
	.long 0xd72c0036                                           // 0000003F5A8C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000003F5A90: 02026CFF 83DCD12D
	v_and_or_b32 v52, 0xffff, v49, v52                         // 0000003F5A98: D6570034 04D262FF 0000FFFF
	.long 0xd72c0039                                           // 0000003F5AA4: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000003F5AA8: 020272FF 83DCD12D
	v_lshl_or_b32 v47, v50, 16, v47                            // 0000003F5AB0: D656002F 04BD2132
	v_mov_b32_e32 v49, v51                                     // 0000003F5AB8: 7E620333
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000003F5ABC: BF8701D4
	v_pk_fma_f16 v52, v52, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5AC0: CC0E0034 0BFC0B34 0000C931
	v_and_b32_e32 v50, 0xffff, v55                             // 0000003F5ACC: 36646EFF 0000FFFF
	v_sad_u8 v55, v58, 0, 0x6400                               // 0000003F5AD4: D6220037 03FD013A 00006400
	v_sad_u8 v51, v54, 0, 0x6400                               // 0000003F5AE0: D6220033 03FD0136 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000003F5AEC: D6220039 03FD0139 00006400
	v_lshlrev_b32_e32 v54, 16, v55                             // 0000003F5AF8: 306C6E90
	v_pk_fma_f16 v55, v47, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5AFC: CC0E0037 0BFC0B2F 0000C931
	.long 0xd73d002f                                           // 0000003F5B08: D73D002F
	v_cndmask_b32_e32 v1, v37, v48, vcc_lo                     // 0000003F5B0C: 02026125
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F5B10: BF870193
	v_and_or_b32 v48, 0xffff, v51, v54                         // 0000003F5B14: D6570030 04DA66FF 0000FFFF
	v_dot2acc_f32_f16 v35, v55, v5                             // 0000003F5B20: 04460B37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F5B24: BF870113
	v_bfe_u32 v51, v47, 9, 16                                  // 0000003F5B28: D6100033 0241132F
	v_dot2acc_f32_f16 v35, v52, v6                             // 0000003F5B30: 04460D34
	v_lshl_or_b32 v50, v57, 16, v50                            // 0000003F5B34: D6560032 04C92139
	v_and_b32_e32 v57, 0xffff, v47                             // 0000003F5B3C: 36725EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003F5B44: BF8701B2
	v_pk_fma_f16 v50, v50, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5B48: CC0E0032 0BFC0B32 0000C931
	v_mov_b32_e32 v54, v56                                     // 0000003F5B54: 7E6C0338
	v_pk_fma_f16 v56, v48, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5B58: CC0E0038 0BFC0B30 0000C931
	v_dot2acc_f32_f16 v35, v50, v7                             // 0000003F5B64: 04460F32
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003F5B68: BF870003
	.long 0xd73d0030                                           // 0000003F5B6C: D73D0030
	v_cndmask_b32_e32 v1, v38, v53, vcc_lo                     // 0000003F5B70: 02026B26
	.long 0xd72c0031                                           // 0000003F5B74: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000003F5B78: 020266FF 83DCD12D
	v_bfe_u32 v51, v47, 6, 16                                  // 0000003F5B80: D6100033 02410D2F
	v_bfe_u32 v47, v47, 3, 16                                  // 0000003F5B88: D610002F 0241072F
	.long 0xd72c0035                                           // 0000003F5B90: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000003F5B94: 020272FF 83DCD12D
	v_dot2acc_f32_f16 v35, v56, v8                             // 0000003F5B9C: 04461138
	v_bfe_u32 v54, v48, 9, 16                                  // 0000003F5BA0: D6100036 02411330
	.long 0xd72c0033                                           // 0000003F5BA8: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000003F5BAC: 020266FF 83DCD12D
	v_bfe_u32 v57, v48, 6, 16                                  // 0000003F5BB4: D6100039 02410D30
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000003F5BBC: D6220031 03FD0131 00006400
	.long 0xd72c002f                                           // 0000003F5BC8: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000003F5BCC: 02025EFF 83DCD12D
	.long 0xd72c0036                                           // 0000003F5BD4: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000003F5BD8: 02026CFF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000003F5BE0: D6220035 03FD0135 00006400
	.long 0xd72c0039                                           // 0000003F5BEC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000003F5BF0: 020272FF 83DCD12D
	v_and_b32_e32 v49, 0xffff, v49                             // 0000003F5BF8: 366262FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000003F5C00: D6220033 03FD0133 00006400
	v_bfe_u32 v58, v48, 3, 16                                  // 0000003F5C0C: D610003A 02410730
	v_and_b32_e32 v48, 0xffff, v48                             // 0000003F5C14: 366060FF 0000FFFF
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000003F5C1C: D622002F 03FD012F 00006400
	v_lshlrev_b32_e32 v53, 16, v53                             // 0000003F5C28: 306A6A90
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000003F5C2C: D6220036 03FD0136 00006400
	v_lshl_or_b32 v49, v51, 16, v49                            // 0000003F5C38: D6560031 04C52133
	.long 0xd72c0030                                           // 0000003F5C40: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 0000003F5C44: 020260FF 83DCD12D
	.long 0xd72c0033                                           // 0000003F5C4C: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000003F5C50: 020274FF 83DCD12D
	v_and_or_b32 v47, 0xffff, v47, v53                         // 0000003F5C58: D657002F 04D65EFF 0000FFFF
	v_and_b32_e32 v53, 0xffff, v54                             // 0000003F5C64: 366A6CFF 0000FFFF
	v_sad_u8 v54, v57, 0, 0x6400                               // 0000003F5C6C: D6220036 03FD0139 00006400
	v_pk_fma_f16 v49, v49, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5C78: CC0E0031 0BFC0B31 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F5C84: BF870224
	v_pk_fma_f16 v47, v47, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000003F5C88: CC0E002F 0BFC0B2F 0000C931
	v_sad_u8 v48, v48, 0, 0x6400                               // 0000003F5C94: D6220030 03FD0130 00006400
	v_lshl_or_b32 v53, v54, 16, v53                            // 0000003F5CA0: D6560035 04D52136
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003F5CA8: BF8701B4
	v_dot2acc_f32_f16 v15, v49, v5                             // 0000003F5CAC: 041E0B31
	v_dot2acc_f32_f16 v36, v49, v1                             // 0000003F5CB0: 04480331
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000003F5CB4: D6220033 03FD0133 00006400
	v_dual_dot2acc_f32_f16 v15, v47, v6 :: v_dual_lshlrev_b32 v48, 16, v48// 0000003F5CC0: CB220D2F 0F306090
	v_dot2acc_f32_f16 v34, v55, v1                             // 0000003F5CC8: 04440337
	v_pk_fma_f16 v1, v53, s5, 0xc931 op_sel_hi:[1,0,0]         // 0000003F5CCC: CC0E0001 0BFC0B35 0000C931
	v_dot2acc_f32_f16 v36, v47, v2                             // 0000003F5CD8: 0448052F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F5CDC: BF870194
	v_and_or_b32 v5, 0xffff, v51, v48                          // 0000003F5CE0: D6570005 04C266FF 0000FFFF
	v_dual_dot2acc_f32_f16 v15, v1, v7 :: v_dual_dot2acc_f32_f16 v34, v52, v2// 0000003F5CEC: CB180F01 0F220534
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F5CF4: BF870193
	v_dual_dot2acc_f32_f16 v36, v1, v3 :: v_dual_add_nc_u32 v1, v40, v41// 0000003F5CF8: CB200701 24005328
	v_pk_fma_f16 v2, v5, s5, 0xc931 op_sel_hi:[1,0,0]          // 0000003F5D00: CC0E0002 0BFC0B05 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F5D0C: BF870193
	v_dot2acc_f32_f16 v34, v50, v3                             // 0000003F5D10: 04440732
	v_cmp_eq_u32_e32 vcc_lo, 1, v1                             // 0000003F5D14: 7C940281
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F5D18: BF870223
	v_dot2acc_f32_f16 v36, v2, v4                              // 0000003F5D1C: 04480902
	v_dot2acc_f32_f16 v15, v2, v8                              // 0000003F5D20: 041E1102
	v_dot2acc_f32_f16 v34, v56, v4                             // 0000003F5D24: 04440938
	s_or_b32 s4, vcc_lo, s4                                    // 0000003F5D28: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F5D2C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000003F5D30: 917E047E
	s_cbranch_execz 27                                         // 0000003F5D34: BFA5001B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1ca4>
	s_mov_b32 s2, exec_lo                                      // 0000003F5D38: BE82007E
	s_waitcnt vmcnt(4)                                         // 0000003F5D3C: BF8913F7
	ds_store_2addr_b32 v42, v17, v18 offset1:32                // 0000003F5D40: D8382000 0012112A
	s_waitcnt vmcnt(2)                                         // 0000003F5D48: BF890BF7
	ds_store_2addr_b32 v42, v19, v20 offset0:64 offset1:96     // 0000003F5D4C: D8386040 0014132A
	s_waitcnt vmcnt(0)                                         // 0000003F5D54: BF8903F7
	ds_store_2addr_b32 v42, v21, v25 offset0:128 offset1:160   // 0000003F5D58: D838A080 0019152A
	.long 0xd4c1007e                                           // 0000003F5D60: D4C1007E
	v_cndmask_b32_e32 v1, v41, v16, vcc_lo                     // 0000003F5D64: 02022129
	s_cbranch_execz 64559                                      // 0000003F5D68: BFA5FC2F <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xd28>
	s_clause 0x5                                               // 0000003F5D6C: BF850005
	global_load_b32 v17, v[9:10], off                          // 0000003F5D70: DC520000 117C0009
	global_load_b32 v18, v[9:10], off offset:128               // 0000003F5D78: DC520080 127C0009
	global_load_b32 v19, v[9:10], off offset:256               // 0000003F5D80: DC520100 137C0009
	global_load_b32 v20, v[9:10], off offset:384               // 0000003F5D88: DC520180 147C0009
	global_load_b32 v21, v[9:10], off offset:512               // 0000003F5D90: DC520200 157C0009
	global_load_b32 v25, v[9:10], off offset:640               // 0000003F5D98: DC520280 197C0009
	s_branch 64545                                             // 0000003F5DA0: BFA0FC21 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xd28>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003F5DA4: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F5DA8: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003F5DAC: 8C7E037E
	v_dual_mov_b32 v1, v14 :: v_dual_mov_b32 v6, v28           // 0000003F5DB0: CA10010E 0106011C
	v_dual_mov_b32 v2, v26 :: v_dual_mov_b32 v3, v27           // 0000003F5DB8: CA10011A 0202011B
	v_dual_mov_b32 v4, v24 :: v_dual_mov_b32 v5, v23           // 0000003F5DC0: CA100118 04040117
	v_dual_mov_b32 v8, v29 :: v_dual_mov_b32 v9, v30           // 0000003F5DC8: CA10011D 0808011E
	v_dual_mov_b32 v7, v22 :: v_dual_mov_b32 v10, v31          // 0000003F5DD0: CA100116 070A011F
	s_waitcnt vmcnt(5)                                         // 0000003F5DD8: BF8917F7
	v_dual_mov_b32 v16, v32 :: v_dual_mov_b32 v17, v33         // 0000003F5DDC: CA100120 10100121
	s_waitcnt vmcnt(3)                                         // 0000003F5DE4: BF890FF7
	v_dual_mov_b32 v18, v34 :: v_dual_mov_b32 v19, v35         // 0000003F5DE8: CA100122 12120123
	s_waitcnt vmcnt(1)                                         // 0000003F5DF0: BF8907F7
	v_dual_mov_b32 v20, v36 :: v_dual_mov_b32 v21, v15         // 0000003F5DF4: CA100124 1414010F
	s_mov_b32 s2, 0x76543210                                   // 0000003F5DFC: BE8200FF 76543210
	s_waitcnt vmcnt(0)                                         // 0000003F5E04: BF8903F7
	v_permlanex16_b32 v1, v1, s2, 0xfedcba98                   // 0000003F5E08: D65C0001 03FC0501 FEDCBA98
	v_permlanex16_b32 v2, v2, s2, 0xfedcba98                   // 0000003F5E14: D65C0002 03FC0502 FEDCBA98
	v_permlanex16_b32 v3, v3, s2, 0xfedcba98                   // 0000003F5E20: D65C0003 03FC0503 FEDCBA98
	v_permlanex16_b32 v6, v6, s2, 0xfedcba98                   // 0000003F5E2C: D65C0006 03FC0506 FEDCBA98
	v_permlanex16_b32 v4, v4, s2, 0xfedcba98                   // 0000003F5E38: D65C0004 03FC0504 FEDCBA98
	v_permlanex16_b32 v5, v5, s2, 0xfedcba98                   // 0000003F5E44: D65C0005 03FC0505 FEDCBA98
	v_permlanex16_b32 v8, v8, s2, 0xfedcba98                   // 0000003F5E50: D65C0008 03FC0508 FEDCBA98
	v_permlanex16_b32 v9, v9, s2, 0xfedcba98                   // 0000003F5E5C: D65C0009 03FC0509 FEDCBA98
	v_permlanex16_b32 v7, v7, s2, 0xfedcba98                   // 0000003F5E68: D65C0007 03FC0507 FEDCBA98
	v_permlanex16_b32 v10, v10, s2, 0xfedcba98                 // 0000003F5E74: D65C000A 03FC050A FEDCBA98
	v_permlanex16_b32 v16, v16, s2, 0xfedcba98                 // 0000003F5E80: D65C0010 03FC0510 FEDCBA98
	v_permlanex16_b32 v17, v17, s2, 0xfedcba98                 // 0000003F5E8C: D65C0011 03FC0511 FEDCBA98
	v_permlanex16_b32 v18, v18, s2, 0xfedcba98                 // 0000003F5E98: D65C0012 03FC0512 FEDCBA98
	v_permlanex16_b32 v19, v19, s2, 0xfedcba98                 // 0000003F5EA4: D65C0013 03FC0513 FEDCBA98
	v_permlanex16_b32 v20, v20, s2, 0xfedcba98                 // 0000003F5EB0: D65C0014 03FC0514 FEDCBA98
	v_permlanex16_b32 v21, v21, s2, 0xfedcba98                 // 0000003F5EBC: D65C0015 03FC0515 FEDCBA98
	.long 0xd44c0002                                           // 0000003F5EC8: D44C0002
	v_cndmask_b32_e32 v1, 16, v12, vcc_lo                      // 0000003F5ECC: 02021890
	s_barrier                                                  // 0000003F5ED0: BFBD0000
	buffer_gl0_inv                                             // 0000003F5ED4: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 0000003F5EDC: BE832002
	s_cbranch_execz 34                                         // 0000003F5EE0: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1e6c>
	v_dual_add_f32 v8, v29, v8 :: v_dual_add_f32 v3, v27, v3   // 0000003F5EE4: C908111D 0802071B
	v_dual_add_f32 v6, v28, v6 :: v_dual_add_f32 v1, v14, v1   // 0000003F5EEC: C9080D1C 0600030E
	v_lshl_or_b32 v13, v11, 10, v13                            // 0000003F5EF4: D656000D 0435150B
	v_dual_add_f32 v2, v26, v2 :: v_dual_add_f32 v5, v23, v5   // 0000003F5EFC: C908051A 02040B17
	v_dual_add_f32 v4, v24, v4 :: v_dual_add_f32 v7, v22, v7   // 0000003F5F04: C9080918 04060F16
	v_dual_add_f32 v10, v31, v10 :: v_dual_add_f32 v9, v30, v9 // 0000003F5F0C: C908151F 0A08131E
	v_dual_add_f32 v17, v33, v17 :: v_dual_add_f32 v16, v32, v16// 0000003F5F14: C9082321 11102120
	v_dual_add_f32 v12, v15, v21 :: v_dual_add_f32 v15, v36, v20// 0000003F5F1C: C9082B0F 0C0E2924
	v_dual_add_f32 v19, v35, v19 :: v_dual_add_f32 v18, v34, v18// 0000003F5F24: C9082723 13122522
	ds_store_2addr_b32 v13, v1, v3 offset1:16                  // 0000003F5F2C: D8381000 0003010D
	ds_store_2addr_b32 v13, v2, v6 offset0:128 offset1:144     // 0000003F5F34: D8389080 0006020D
	ds_store_2addr_b32 v13, v4, v8 offset0:32 offset1:48       // 0000003F5F3C: D8383020 0008040D
	ds_store_2addr_b32 v13, v5, v9 offset0:160 offset1:176     // 0000003F5F44: D838B0A0 0009050D
	ds_store_2addr_b32 v13, v7, v16 offset0:64 offset1:80      // 0000003F5F4C: D8385040 0010070D
	ds_store_2addr_b32 v13, v10, v17 offset0:192 offset1:208   // 0000003F5F54: D838D0C0 00110A0D
	ds_store_2addr_b32 v13, v18, v15 offset0:96 offset1:112    // 0000003F5F5C: D8387060 000F120D
	ds_store_2addr_b32 v13, v19, v12 offset0:224 offset1:240   // 0000003F5F64: D838F0E0 000C130D
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003F5F6C: 8C7E037E
	.long 0xd44c0003                                           // 0000003F5F70: D44C0003
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 0000003F5F74: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000003F5F7C: BF89FC07
	s_barrier                                                  // 0000003F5F80: BFBD0000
	buffer_gl0_inv                                             // 0000003F5F84: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000003F5F8C: BE842003
	s_cbranch_execnz 7                                         // 0000003F5F90: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1eb0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003F5F94: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 0000003F5F98: BF048215
	s_mov_b32 s4, -1                                           // 0000003F5F9C: BE8400C1
	s_cbranch_scc0 33                                          // 0000003F5FA0: BFA10021 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1f28>
	s_and_b32 vcc_lo, exec_lo, s4                              // 0000003F5FA4: 8B6A047E
	s_cbranch_vccz 63824                                       // 0000003F5FA8: BFA3F950 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 201                                               // 0000003F5FAC: BFA000C9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x21d4>
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000003F5FB0: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 0000003F5FB4: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 0000003F5FBC: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 0000003F5FC4: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 0000003F5FCC: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 0000003F5FD0: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F5FD4: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 0000003F5FD8: 06020501
	s_waitcnt lgkmcnt(1)                                       // 0000003F5FDC: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 0000003F5FE0: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 0000003F5FE4: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 0000003F5FEC: 06060903
	s_waitcnt lgkmcnt(1)                                       // 0000003F5FF0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F5FF4: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 0000003F5FF8: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 0000003F5FFC: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 0000003F6000: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6004: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 0000003F6008: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 0000003F600C: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 0000003F6010: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003F6018: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 0000003F601C: BF048215
	s_mov_b32 s4, -1                                           // 0000003F6020: BE8400C1
	s_cbranch_scc1 65503                                       // 0000003F6024: BFA2FFDF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1ea4>
	s_load_b128 s[4:7], s[0:1], 0x1a8                          // 0000003F6028: F4080100 F80001A8
	s_lshl_b64 s[8:9], s[30:31], 2                             // 0000003F6030: 8488821E
	s_waitcnt lgkmcnt(0)                                       // 0000003F6034: BF89FC07
	s_barrier                                                  // 0000003F6038: BFBD0000
	buffer_gl0_inv                                             // 0000003F603C: E0AC0000 00000000
	s_add_u32 s1, s4, s8                                       // 0000003F6044: 80010804
	s_addc_u32 s4, s5, s9                                      // 0000003F6048: 82040905
	s_and_saveexec_b32 s0, s3                                  // 0000003F604C: BE802003
	s_cbranch_execz 41                                         // 0000003F6050: BFA50029 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1ff8>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000003F6054: 32020087
	s_ashr_i32 s5, s20, 31                                     // 0000003F6058: 86059F14
	v_lshlrev_b32_e32 v4, 2, v0                                // 0000003F605C: 30080082
	s_lshl_b32 s8, s26, 7                                      // 0000003F6060: 8408871A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F6064: BF870009
	s_ashr_i32 s9, s8, 31                                      // 0000003F6068: 86099F08
	v_lshl_or_b32 v1, s23, 1, v1                               // 0000003F606C: D6560001 04050217
	ds_load_b32 v4, v4 offset:8192                             // 0000003F6074: D8D82000 04000004
	s_lshl_b64 s[8:9], s[8:9], 2                               // 0000003F607C: 84888208
	.long 0xd72c0003                                           // 0000003F6080: D72C0003
	v_cndmask_b32_e32 v0, v1, v5, vcc_lo                       // 0000003F6084: 02000B01
	v_mad_u64_u32 v[1:2], null, v1, s20, 0                     // 0000003F6088: D6FE7C01 02002901
	s_ashr_i32 s5, s23, 31                                     // 0000003F6090: 86059F17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000003F6094: BF870499
	s_mul_i32 s5, s5, s20                                      // 0000003F6098: 96051405
	v_add3_u32 v2, v2, v3, s5                                  // 0000003F609C: D6550002 00160702
	v_and_b32_e32 v3, 0x7f, v0                                 // 0000003F60A4: 360600FF 0000007F
	s_add_u32 s5, s1, s8                                       // 0000003F60AC: 80050801
	s_addc_u32 s8, s4, s9                                      // 0000003F60B0: 82080904
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F60B4: BF870112
	.long 0xd73c0001                                           // 0000003F60B8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000003F60BC: 02020282
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000003F60C0: 30060682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F60C4: BF870092
	.long 0xd7006a01                                           // 0000003F60C8: D7006A01
	v_cndmask_b32_e32 v1, s5, v1, vcc_lo                       // 0000003F60CC: 02020205
	v_add_co_ci_u32_e64 v2, null, s8, v2, vcc_lo               // 0000003F60D0: D5207C02 01AA0408
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F60D8: BF870092
	.long 0xd7006a01                                           // 0000003F60DC: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000003F60E0: 02020701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000003F60E4: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 0000003F60EC: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 0000003F60F0: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003F60F8: 8C7E007E
	s_ashr_i32 s29, s28, 31                                    // 0000003F60FC: 861D9F1C
	.long 0xd44a0000                                           // 0000003F6100: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000003F6104: 02020080
	s_lshl_b64 s[8:9], s[28:29], 2                             // 0000003F6108: 8488821C
	s_waitcnt_vscnt null, 0x0                                  // 0000003F610C: BC7C0000
	buffer_gl1_inv                                             // 0000003F6110: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003F6118: E0AC0000 00000000
	s_add_u32 s5, s6, s8                                       // 0000003F6120: 80050806
	s_addc_u32 s6, s7, s9                                      // 0000003F6124: 82060907
	s_barrier                                                  // 0000003F6128: BFBD0000
	buffer_gl0_inv                                             // 0000003F612C: E0AC0000 00000000
	s_and_saveexec_b32 s7, s0                                  // 0000003F6134: BE872000
	s_cbranch_execz 29                                         // 0000003F6138: BFA5001D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x20b0>
	s_mov_b32 s9, exec_lo                                      // 0000003F613C: BE89007E
	s_mov_b32 s8, exec_lo                                      // 0000003F6140: BE88007E
	.long 0xd71f0001                                           // 0000003F6144: D71F0001
	v_cndmask_b32_e32 v0, s9, v128, vcc_lo                     // 0000003F6148: 02010009
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F614C: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 0000003F6150: 7D940280
	s_cbranch_execz 9                                          // 0000003F6154: BFA50009 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x207c>
	s_lshl_b64 s[10:11], s[26:27], 2                           // 0000003F6158: 848A821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000003F615C: BF8704B9
	s_add_u32 s10, s5, s10                                     // 0000003F6160: 800A0A05
	s_addc_u32 s11, s6, s11                                    // 0000003F6164: 820B0B06
	s_bcnt1_i32_b32 s9, s9                                     // 0000003F6168: BE891809
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s9              // 0000003F616C: CA100080 02020009
	global_atomic_add_u32 v2, v2, v3, s[10:11] glc             // 0000003F6174: DCD64000 020A0302
	s_or_b32 exec_lo, exec_lo, s8                              // 0000003F617C: 8C7E087E
	s_waitcnt vmcnt(0)                                         // 0000003F6180: BF8903F7
	v_readfirstlane_b32 s8, v2                                 // 0000003F6184: 7E100502
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F6188: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s8, v1       // 0000003F618C: CA200080 02000208
	s_add_i32 s8, s21, -1                                      // 0000003F6194: 8108C115
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000003F6198: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s8, v1                            // 0000003F619C: 7C940208
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000003F61A0: D5010001 01A90280
	ds_store_b32 v2, v1 offset:16640                           // 0000003F61A8: D8344100 00000102
	s_or_b32 exec_lo, exec_lo, s7                              // 0000003F61B0: 8C7E077E
	v_mov_b32_e32 v1, 0                                        // 0000003F61B4: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000003F61B8: BF89FC07
	s_barrier                                                  // 0000003F61BC: BFBD0000
	buffer_gl0_inv                                             // 0000003F61C0: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:16640                            // 0000003F61C8: D8D84100 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000003F61D0: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000003F61D4: 7C940280
	s_cbranch_vccnz 61                                         // 0000003F61D8: BFA4003D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x21d0>
	buffer_gl1_inv                                             // 0000003F61DC: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003F61E4: E0AC0000 00000000
	s_and_saveexec_b32 s7, s3                                  // 0000003F61EC: BE872003
	s_cbranch_execz 43                                         // 0000003F61F0: BFA5002B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x21a0>
	v_and_b32_e32 v2, 0x7f, v0                                 // 0000003F61F4: 360400FF 0000007F
	s_lshl_b32 s8, s26, 7                                      // 0000003F61FC: 8408871A
	s_ashr_i32 s3, s20, 31                                     // 0000003F6200: 86039F14
	s_ashr_i32 s9, s8, 31                                      // 0000003F6204: 86099F08
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000003F6208: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 0000003F620C: CA220080 02020482
	s_lshl_b64 s[8:9], s[8:9], 2                               // 0000003F6214: 84888208
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F6218: BF8700A9
	s_add_u32 s1, s1, s8                                       // 0000003F621C: 80010801
	s_addc_u32 s4, s4, s9                                      // 0000003F6220: 82040904
	.long 0xd7000103                                           // 0000003F6224: D7000103
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 0000003F6228: 02020601
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F622C: BF870001
	v_add_co_ci_u32_e64 v4, null, s4, 0, s1                    // 0000003F6230: D5207C04 00050004
	s_mov_b32 s1, s20                                          // 0000003F6238: BE810014
	s_nop 0                                                    // 0000003F623C: BF800000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003F6240: BF8704A9
	v_mad_u64_u32 v[5:6], null, v1, s1, 0                      // 0000003F6244: D6FE7C05 02000301
	s_add_i32 s21, s21, -1                                     // 0000003F624C: 8115C115
	s_cmp_eq_u32 s21, 0                                        // 0000003F6250: BF068015
	v_mad_u64_u32 v[6:7], null, v1, s3, v[6:7]                 // 0000003F6254: D6FE7C06 04180701
	v_add_nc_u32_e32 v1, 2, v1                                 // 0000003F625C: 4A020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6260: BF870092
	.long 0xd73c0005                                           // 0000003F6264: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000003F6268: 02020A82
	.long 0xd7006a05                                           // 0000003F626C: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000003F6270: 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F6274: BF870001
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 0000003F6278: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 0000003F6280: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000003F6288: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 0000003F628C: 06040B02
	s_cbranch_scc0 65515                                       // 0000003F6290: BFA1FFEB <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2140>
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000003F6294: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 0000003F6298: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s7                              // 0000003F62A0: 8C7E077E
	s_and_saveexec_b32 s1, s0                                  // 0000003F62A4: BE812000
	s_cbranch_execz 6                                          // 0000003F62A8: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x21c4>
	s_lshl_b64 s[8:9], s[26:27], 2                             // 0000003F62AC: 8488821A
	v_mov_b32_e32 v1, 0                                        // 0000003F62B0: 7E020280
	s_add_u32 s4, s5, s8                                       // 0000003F62B4: 80040805
	s_addc_u32 s5, s6, s9                                      // 0000003F62B8: 82050906
	global_store_b32 v1, v1, s[4:5]                            // 0000003F62BC: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 0000003F62C4: 8C7E017E
	s_cbranch_execz 63624                                      // 0000003F62C8: BFA5F888 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 1                                                 // 0000003F62CC: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x21d4>
	s_branch 63622                                             // 0000003F62D0: BFA0F886 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_cmp_gt_i32_e32 vcc_lo, s18, v11                          // 0000003F62D4: 7C881612
	.long 0xd44c0000                                           // 0000003F62D8: D44C0000
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 0000003F62DC: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 0000003F62E0: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000003F62E4: BC7C0000
	s_barrier                                                  // 0000003F62E8: BFBD0000
	buffer_gl0_inv                                             // 0000003F62EC: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 0000003F62F4: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F62F8: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000003F62FC: BE812000
	s_cbranch_execz 63610                                      // 0000003F6300: BFA5F87A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_and_b32_e32 v1, 15, v0                                   // 0000003F6304: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6308: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000003F630C: 30040282
	v_lshl_or_b32 v2, v11, 9, v2                               // 0000003F6310: D6560002 0409130B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F6318: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 0000003F631C: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000003F6324: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000003F632C: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000003F6334: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000003F633C: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000003F6344: 36140081
	s_waitcnt lgkmcnt(3)                                       // 0000003F6348: BF89FC37
	v_dual_add_f32 v14, v2, v3 :: v_dual_and_b32 v13, 4, v0    // 0000003F634C: C9240702 0E0C0084
	s_waitcnt lgkmcnt(2)                                       // 0000003F6354: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 0000003F6358: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 0000003F6360: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000003F6364: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000003F636C: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 0000003F6370: C9480F06 06061308
	v_sub_f32_e32 v8, v8, v9                                   // 0000003F6378: 08101308
	v_dual_add_f32 v9, v14, v3 :: v_dual_and_b32 v12, 2, v0    // 0000003F637C: C924070E 090C0082
	v_sub_f32_e32 v3, v14, v3                                  // 0000003F6384: 0806070E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003F6388: BF8701B4
	v_dual_add_f32 v14, v2, v4 :: v_dual_add_f32 v15, v5, v7   // 0000003F638C: C9080902 0E0E0F05
	v_sub_f32_e32 v2, v2, v4                                   // 0000003F6394: 08040902
	v_dual_add_f32 v4, v6, v8 :: v_dual_sub_f32 v5, v5, v7     // 0000003F6398: C90A1106 04040F05
	v_dual_sub_f32 v6, v6, v8 :: v_dual_add_f32 v7, v9, v15    // 0000003F63A0: C9481106 06061F09
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003F63A8: BF870222
	v_dual_sub_f32 v8, v9, v15 :: v_dual_add_f32 v9, v14, v4   // 0000003F63AC: C9481F09 0808090E
	v_sub_f32_e32 v4, v14, v4                                  // 0000003F63B4: 0808090E
	v_add_f32_e32 v14, v3, v5                                  // 0000003F63B8: 061C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 0000003F63BC: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 0000003F63C0: 060A0D02
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000003F63C4: 7C941480
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F63C8: 7E1402FA FF016109
	v_mov_b32_dpp v15, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F63D0: 7E1E02FA FF01610E
	v_mov_b32_dpp v17, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F63D8: 7E2202FA FF016108
	v_mov_b32_dpp v16, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F63E0: 7E2002FA FF016105
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003F63E8: D5010009 21AA1309
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000003F63F0: D501000E 21AA1D0E
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F63F8: D5010005 21AA0B05
	v_sub_f32_e32 v2, v2, v6                                   // 0000003F6400: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F6404: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000003F640C: D5010007 21AA0F07
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003F6414: D5010008 21AA1108
	v_mov_b32_dpp v18, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F641C: 7E2402FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000003F6424: D5010004 21AA0904
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F642C: 7E2602FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000003F6434: D5010003 21AA0703
	v_add_f32_e32 v6, v7, v6                                   // 0000003F643C: 060C0D07
	v_add_f32_e32 v7, v9, v10                                  // 0000003F6440: 060E1509
	v_add_f32_e32 v9, v14, v15                                 // 0000003F6444: 06121F0E
	v_add_f32_e32 v5, v5, v16                                  // 0000003F6448: 060A2105
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F644C: 7E2802FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000003F6454: D5010002 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 0000003F645C: 7C941880
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F6460: 7E1C02FA FF016209
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F6468: 7E1402FA FF016206
	.long 0xd44a0000                                           // 0000003F6470: D44A0000
	v_cndmask_b32_e32 v1, 0, v13, vcc_lo                       // 0000003F6474: 02021A80
	v_mov_b32_dpp v12, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F6478: 7E1802FA FF016207
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003F6480: D5010009 21AA1309
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003F6488: D5010006 21AA0D06
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000003F6490: D5010007 21AA0F07
	v_add_f32_e32 v8, v8, v17                                  // 0000003F6498: 06102308
	v_mov_b32_dpp v15, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F649C: 7E1E02FA FF016205
	v_add_f32_e32 v9, v9, v14                                  // 0000003F64A4: 06121D09
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F64A8: D5010005 21AA0B05
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v4, v4, v18   // 0000003F64B0: C9081907 07042504
	v_add_f32_e32 v3, v3, v19                                  // 0000003F64B8: 06062703
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003F64BC: BF870004
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F64C0: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 0000003F64C8: D5010009 20021309
	v_add_f32_e32 v6, v6, v10                                  // 0000003F64D0: 060C1506
	v_mov_b32_dpp v12, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F64D4: 7E1802FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 0000003F64DC: D5010007 20020F07
	v_add_f32_e32 v15, v5, v15                                 // 0000003F64E4: 061E1F05
	v_add_f32_e32 v21, v9, v13                                 // 0000003F64E8: 062A1B09
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F64EC: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 0000003F64F4: D5010006 20020D06
	v_add_f32_e32 v2, v2, v20                                  // 0000003F64FC: 06042902
	v_mov_b32_dpp v16, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F6500: 7E2002FA FF016208
	v_add_f32_e32 v14, v7, v12                                 // 0000003F6508: 061C1907
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F650C: 7E1802FA FF016203
	v_add_f32_e32 v5, v6, v10                                  // 0000003F6514: 060A1506
	v_mov_b32_dpp v10, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F6518: 7E1402FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000003F6520: D5010004 21AA0904
	v_cndmask_b32_e64 v6, -v8, v8, vcc_lo                      // 0000003F6528: D5010006 21AA1108
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000003F6530: D5010003 21AA0703
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F6538: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000003F6540: D5010002 21AA0502
	v_add_f32_e32 v4, v4, v10                                  // 0000003F6548: 06081504
	v_mov_b32_dpp v7, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F654C: 7E0E02FA FF01640F
	v_cndmask_b32_e64 v9, -v15, v15, s0                        // 0000003F6554: D5010009 20021F0F
	v_add_f32_e32 v6, v6, v16                                  // 0000003F655C: 060C2106
	v_add_f32_e32 v3, v3, v12                                  // 0000003F6560: 06061903
	v_mov_b32_dpp v12, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F6564: 7E1802FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 0000003F656C: D5010004 20020904
	v_dual_add_f32 v2, v2, v13 :: v_dual_add_f32 v19, v9, v7   // 0000003F6574: C9081B02 02120F09
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F657C: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 0000003F6584: D5010006 20020D06
	v_mov_b32_dpp v13, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F658C: 7E1A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 0000003F6594: D5010003 20020703
	v_add_f32_e32 v15, v4, v12                                 // 0000003F659C: 061E1904
	v_mov_b32_dpp v16, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F65A0: 7E2002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 0000003F65A8: D5010002 20020502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003F65B0: BF870234
	v_dual_add_f32 v17, v6, v10 :: v_dual_add_f32 v12, v3, v13 // 0000003F65B4: C9081506 110C1B03
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F65BC: 7E1002FA FF016805
	v_mov_b32_dpp v23, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F65C4: 7E2E02FA FF01680E
	v_add_f32_e32 v9, v2, v16                                  // 0000003F65CC: 06122102
	v_mov_b32_dpp v22, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F65D0: 7E2C02FA FF016815
	v_mov_b32_dpp v20, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F65D8: 7E2802FA FF016813
	v_mov_b32_dpp v18, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F65E0: 7E2402FA FF016811
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F65E8: 7E2002FA FF01680F
	v_mov_b32_dpp v13, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F65F0: 7E1A02FA FF01680C
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F65F8: 7E1402FA FF016809
	s_and_b32 exec_lo, exec_lo, s2                             // 0000003F6600: 8B7E027E
	s_cbranch_execz 63417                                      // 0000003F6604: BFA5F7B9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_lshl_or_b32 v3, s26, 7, v1                               // 0000003F6608: D6560003 04050E1A
	v_and_b32_e32 v0, 8, v0                                    // 0000003F6610: 36000088
	s_cmp_lg_u64 s[24:25], 0                                   // 0000003F6614: BF118018
	s_cselect_b32 s1, -1, 0                                    // 0000003F6618: 980180C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F661C: BF870112
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000003F6620: 3408069F
	.long 0xd44a0000                                           // 0000003F6624: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000003F6628: 02020080
	s_lshr_b32 s2, s20, 31                                     // 0000003F662C: 85029F14
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F6630: BF870009
	s_add_i32 s2, s20, s2                                      // 0000003F6634: 81020214
	.long 0xd73c0001                                           // 0000003F6638: D73C0001
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000003F663C: 02020681
	v_cndmask_b32_e64 v0, -v5, v5, s0                          // 0000003F6640: D5010000 20020B05
	v_mad_i64_i32 v[4:5], null, s20, v11, 0                    // 0000003F6648: D6FF7C04 02021614
	s_ashr_i32 s2, s2, 1                                       // 0000003F6650: 86028102
	s_cmp_eq_u64 s[24:25], 0                                   // 0000003F6654: BF108018
	v_add_f32_e32 v0, v0, v8                                   // 0000003F6658: 06001100
	.long 0xd7006a06                                           // 0000003F665C: D7006A06
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 0000003F6660: 0202020C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F6664: BF870191
	v_add_co_ci_u32_e64 v7, null, s13, v2, vcc_lo              // 0000003F6668: D5207C07 01AA040D
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000003F6670: 100000FF 3DB504F3
	.long 0xd73c0004                                           // 0000003F6678: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000003F667C: 02020881
	global_load_d16_b16 v24, v[6:7], off                       // 0000003F6680: DC820000 187C0006
	s_waitcnt vmcnt(0)                                         // 0000003F6688: BF8903F7
	v_fma_mix_f32 v26, v24, v0, neg(0) op_sel_hi:[1,0,0]       // 0000003F668C: CC20001A 8A020118
	v_mad_i64_i32 v[24:25], null, s2, v11, 0                   // 0000003F6694: D6FF7C18 02021602
	.long 0xd7006a00                                           // 0000003F669C: D7006A00
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 0000003F66A0: 0202080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F66A4: BF870211
	v_add_co_ci_u32_e64 v8, null, s15, v5, vcc_lo              // 0000003F66A8: D5207C08 01AA0A0F
	v_bfe_u32 v27, v26, 16, 1                                  // 0000003F66B0: D610001B 0205211A
	v_ashrrev_i32_e32 v11, 31, v3                              // 0000003F66B8: 3416069F
	.long 0xd73c0004                                           // 0000003F66BC: D73C0004
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000003F66C0: 02023081
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003F66C4: BF870003
	v_add3_u32 v24, v26, v27, 0x7fff                           // 0000003F66C8: D6550018 03FE371A 00007FFF
	s_cbranch_scc1 569                                         // 0000003F66D4: BFA20239 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ebc>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003F66D8: BF870123
	v_lshrrev_b32_e32 v25, 23, v11                             // 0000003F66DC: 32321697
	v_mov_b32_e32 v29, s14                                     // 0000003F66E0: 7E3A020E
	v_add_nc_u32_e32 v25, v3, v25                              // 0000003F66E4: 4A323303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F66E8: BF870091
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 0000003F66EC: 363432FF FFFFFE00
	v_sub_nc_u32_e32 v27, v3, v26                              // 0000003F66F4: 4C363503
	v_mov_b32_e32 v26, s15                                     // 0000003F66F8: 7E34020F
	v_ashrrev_i32_e32 v25, 9, v25                              // 0000003F66FC: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F6700: BF8701A3
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v27                        // 0000003F6704: 7C8836FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v27                      // 0000003F670C: 4A3836FF FFFFFF00
	v_dual_cndmask_b32 v30, s25, v26 :: v_dual_lshlrev_b32 v25, 8, v25// 0000003F6714: CA623419 1E183288
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F671C: BF870112
	v_cndmask_b32_e32 v27, v28, v27, vcc_lo                    // 0000003F6720: 0236371C
	v_ashrrev_i32_e32 v26, 31, v25                             // 0000003F6724: 3434329F
	v_cndmask_b32_e32 v29, s24, v29, vcc_lo                    // 0000003F6728: 023A3A18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F672C: BF870193
	v_ashrrev_i32_e32 v28, 31, v27                             // 0000003F6730: 3438369F
	.long 0xd73c0019                                           // 0000003F6734: D73C0019
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 0000003F6738: 02023281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F673C: BF870093
	.long 0xd7006a1d                                           // 0000003F6740: D7006A1D
	v_cndmask_b32_e32 v1, v29, v4, vcc_lo                      // 0000003F6744: 0202091D
	v_add_co_ci_u32_e64 v30, null, v30, v5, vcc_lo             // 0000003F6748: D5207C1E 01AA0B1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F6750: BF870194
	.long 0xd73c001b                                           // 0000003F6754: D73C001B
	v_cndmask_b32_e32 v1, 1, v27, vcc_lo                       // 0000003F6758: 02023681
	.long 0xd7006a19                                           // 0000003F675C: D7006A19
	v_cndmask_b32_e32 v1, v29, v25, vcc_lo                     // 0000003F6760: 0202331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F6764: BF870111
	v_add_co_ci_u32_e64 v26, null, v30, v26, vcc_lo            // 0000003F6768: D5207C1A 01AA351E
	.long 0xd7006a19                                           // 0000003F6770: D7006A19
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 0000003F6774: 02023719
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F6778: BF870001
	v_add_co_ci_u32_e64 v26, null, v26, v28, vcc_lo            // 0000003F677C: D5207C1A 01AA391A
	global_store_d16_hi_b16 v[25:26], v24, off                 // 0000003F6784: DC960000 007C1819
	s_cbranch_execnz 7                                         // 0000003F678C: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x26ac>
	.long 0xd7006a19                                           // 0000003F6790: D7006A19
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F6794: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F6798: BF870001
	v_add_co_ci_u32_e64 v26, null, v8, v2, vcc_lo              // 0000003F679C: D5207C1A 01AA0508
	global_store_d16_hi_b16 v[25:26], v24, off                 // 0000003F67A4: DC960000 007C1819
	global_load_d16_b16 v24, v[6:7], off offset:32             // 0000003F67AC: DC820020 187C0006
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 0000003F67B4: D501000E 20021D0E
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000003F67BC: 916A017E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F67C0: BF870091
	v_add_f32_e32 v14, v14, v23                                // 0000003F67C4: 061C2F0E
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 0000003F67C8: 101C1CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F67D0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003F67D4: BF870121
	v_fma_mix_f32 v23, v24, v14, neg(0) op_sel_hi:[1,0,0]      // 0000003F67D8: CC200017 8A021D18
	v_cndmask_b32_e64 v14, 0, 1, s1                            // 0000003F67E0: D501000E 00050280
	v_bfe_u32 v24, v23, 16, 1                                  // 0000003F67E8: D6100018 02052117
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F67F0: BF870001
	v_add3_u32 v23, v23, v24, 0x7fff                           // 0000003F67F4: D6550017 03FE3117 00007FFF
	s_cbranch_vccnz 495                                        // 0000003F6800: BFA401EF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ec0>
	v_or_b32_e32 v24, 16, v3                                   // 0000003F6804: 38300690
	v_lshrrev_b32_e32 v25, 23, v11                             // 0000003F6808: 32321697
	v_mov_b32_e32 v27, s15                                     // 0000003F680C: 7E36020F
	v_mov_b32_e32 v29, s14                                     // 0000003F6810: 7E3A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6814: BF870093
	v_add_nc_u32_e32 v25, v24, v25                             // 0000003F6818: 4A323318
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 0000003F681C: 363432FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6824: BF870091
	v_sub_nc_u32_e32 v26, v24, v26                             // 0000003F6828: 4C343518
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v26                        // 0000003F682C: 7C8834FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v26                      // 0000003F6834: 4A3834FF FFFFFF00
	v_cndmask_b32_e32 v30, s25, v27, vcc_lo                    // 0000003F683C: 023C3619
	v_ashrrev_i32_e32 v25, 9, v25                              // 0000003F6840: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F6844: BF8701A3
	v_cndmask_b32_e32 v26, v28, v26, vcc_lo                    // 0000003F6848: 0234351C
	v_cndmask_b32_e32 v28, s24, v29, vcc_lo                    // 0000003F684C: 02383A18
	v_lshlrev_b32_e32 v24, 8, v25                              // 0000003F6850: 30303288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F6854: BF870193
	v_ashrrev_i32_e32 v27, 31, v26                             // 0000003F6858: 3436349F
	.long 0xd7006a1c                                           // 0000003F685C: D7006A1C
	v_cndmask_b32_e32 v1, v28, v4, vcc_lo                      // 0000003F6860: 0202091C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F6864: BF870211
	v_add_co_ci_u32_e64 v29, null, v30, v5, vcc_lo             // 0000003F6868: D5207C1D 01AA0B1E
	v_ashrrev_i32_e32 v25, 31, v24                             // 0000003F6870: 3432309F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F6874: BF870114
	.long 0xd73c001a                                           // 0000003F6878: D73C001A
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000003F687C: 02023481
	.long 0xd73c0018                                           // 0000003F6880: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000003F6884: 02023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6888: BF870091
	.long 0xd7006a18                                           // 0000003F688C: D7006A18
	v_cndmask_b32_e32 v1, v28, v24, vcc_lo                     // 0000003F6890: 0202311C
	v_add_co_ci_u32_e64 v25, null, v29, v25, vcc_lo            // 0000003F6894: D5207C19 01AA331D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F689C: BF870092
	.long 0xd7006a18                                           // 0000003F68A0: D7006A18
	v_cndmask_b32_e32 v1, v24, v26, vcc_lo                     // 0000003F68A4: 02023518
	v_add_co_ci_u32_e64 v25, null, v25, v27, vcc_lo            // 0000003F68A8: D5207C19 01AA3719
	global_store_d16_hi_b16 v[24:25], v23, off                 // 0000003F68B0: DC960000 007C1718
	s_cbranch_execnz 7                                         // 0000003F68B8: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x27d8>
	.long 0xd7006a18                                           // 0000003F68BC: D7006A18
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F68C0: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F68C4: BF870001
	v_add_co_ci_u32_e64 v25, null, v8, v2, vcc_lo              // 0000003F68C8: D5207C19 01AA0508
	global_store_d16_hi_b16 v[24:25], v23, off offset:32       // 0000003F68D0: DC960020 007C1718
	global_load_d16_b16 v23, v[6:7], off offset:64             // 0000003F68D8: DC820040 177C0006
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 0000003F68E0: D5010015 20022B15
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003F68E8: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F68EC: BF8700A2
	v_add_f32_e32 v21, v21, v22                                // 0000003F68F0: 062A2D15
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003F68F4: 8B6A6A7E
	v_mul_f32_e32 v21, 0x3db504f3, v21                         // 0000003F68F8: 102A2AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F6900: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6904: BF870091
	v_fma_mix_f32 v21, v23, v21, neg(0) op_sel_hi:[1,0,0]      // 0000003F6908: CC200015 8A022B17
	v_bfe_u32 v22, v21, 16, 1                                  // 0000003F6910: D6100016 02052115
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F6918: BF870001
	v_add3_u32 v21, v21, v22, 0x7fff                           // 0000003F691C: D6550015 03FE2D15 00007FFF
	s_cbranch_vccnz 422                                        // 0000003F6928: BFA401A6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ec4>
	v_or_b32_e32 v22, 32, v3                                   // 0000003F692C: 382C06A0
	v_lshrrev_b32_e32 v23, 23, v11                             // 0000003F6930: 322E1697
	v_mov_b32_e32 v25, s15                                     // 0000003F6934: 7E32020F
	v_mov_b32_e32 v27, s14                                     // 0000003F6938: 7E36020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F693C: BF870093
	v_add_nc_u32_e32 v23, v22, v23                             // 0000003F6940: 4A2E2F16
	v_and_b32_e32 v24, 0xfffffe00, v23                         // 0000003F6944: 36302EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F694C: BF870091
	v_sub_nc_u32_e32 v24, v22, v24                             // 0000003F6950: 4C303116
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v24                        // 0000003F6954: 7C8830FF 00000100
	v_add_nc_u32_e32 v26, 0xffffff00, v24                      // 0000003F695C: 4A3430FF FFFFFF00
	v_cndmask_b32_e32 v28, s25, v25, vcc_lo                    // 0000003F6964: 02383219
	v_ashrrev_i32_e32 v23, 9, v23                              // 0000003F6968: 342E2E89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F696C: BF8701A3
	v_cndmask_b32_e32 v24, v26, v24, vcc_lo                    // 0000003F6970: 0230311A
	v_cndmask_b32_e32 v26, s24, v27, vcc_lo                    // 0000003F6974: 02343618
	v_lshlrev_b32_e32 v22, 8, v23                              // 0000003F6978: 302C2E88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F697C: BF870193
	v_ashrrev_i32_e32 v25, 31, v24                             // 0000003F6980: 3432309F
	.long 0xd7006a1a                                           // 0000003F6984: D7006A1A
	v_cndmask_b32_e32 v1, v26, v4, vcc_lo                      // 0000003F6988: 0202091A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F698C: BF870211
	v_add_co_ci_u32_e64 v27, null, v28, v5, vcc_lo             // 0000003F6990: D5207C1B 01AA0B1C
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000003F6998: 342E2C9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F699C: BF870114
	.long 0xd73c0018                                           // 0000003F69A0: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000003F69A4: 02023081
	.long 0xd73c0016                                           // 0000003F69A8: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000003F69AC: 02022C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F69B0: BF870091
	.long 0xd7006a16                                           // 0000003F69B4: D7006A16
	v_cndmask_b32_e32 v1, v26, v22, vcc_lo                     // 0000003F69B8: 02022D1A
	v_add_co_ci_u32_e64 v23, null, v27, v23, vcc_lo            // 0000003F69BC: D5207C17 01AA2F1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F69C4: BF870092
	.long 0xd7006a16                                           // 0000003F69C8: D7006A16
	v_cndmask_b32_e32 v1, v22, v24, vcc_lo                     // 0000003F69CC: 02023116
	v_add_co_ci_u32_e64 v23, null, v23, v25, vcc_lo            // 0000003F69D0: D5207C17 01AA3317
	global_store_d16_hi_b16 v[22:23], v21, off                 // 0000003F69D8: DC960000 007C1516
	s_cbranch_execnz 7                                         // 0000003F69E0: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2900>
	.long 0xd7006a16                                           // 0000003F69E4: D7006A16
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F69E8: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F69EC: BF870001
	v_add_co_ci_u32_e64 v23, null, v8, v2, vcc_lo              // 0000003F69F0: D5207C17 01AA0508
	global_store_d16_hi_b16 v[22:23], v21, off offset:64       // 0000003F69F8: DC960040 007C1516
	global_load_d16_b16 v21, v[6:7], off offset:96             // 0000003F6A00: DC820060 157C0006
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 0000003F6A08: D5010013 20022713
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003F6A10: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F6A14: BF8700A2
	v_add_f32_e32 v19, v19, v20                                // 0000003F6A18: 06262913
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003F6A1C: 8B6A6A7E
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 0000003F6A20: 102626FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F6A28: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6A2C: BF870091
	v_fma_mix_f32 v19, v21, v19, neg(0) op_sel_hi:[1,0,0]      // 0000003F6A30: CC200013 8A022715
	v_bfe_u32 v20, v19, 16, 1                                  // 0000003F6A38: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F6A40: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000003F6A44: D6550013 03FE2913 00007FFF
	s_cbranch_vccnz 349                                        // 0000003F6A50: BFA4015D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ec8>
	v_or_b32_e32 v20, 48, v3                                   // 0000003F6A54: 382806B0
	v_lshrrev_b32_e32 v21, 23, v11                             // 0000003F6A58: 322A1697
	v_mov_b32_e32 v23, s15                                     // 0000003F6A5C: 7E2E020F
	v_mov_b32_e32 v25, s14                                     // 0000003F6A60: 7E32020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6A64: BF870093
	v_add_nc_u32_e32 v21, v20, v21                             // 0000003F6A68: 4A2A2B14
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 0000003F6A6C: 362C2AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6A74: BF870091
	v_sub_nc_u32_e32 v22, v20, v22                             // 0000003F6A78: 4C2C2D14
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 0000003F6A7C: 7C882CFF 00000100
	v_add_nc_u32_e32 v24, 0xffffff00, v22                      // 0000003F6A84: 4A302CFF FFFFFF00
	v_cndmask_b32_e32 v26, s25, v23, vcc_lo                    // 0000003F6A8C: 02342E19
	v_ashrrev_i32_e32 v21, 9, v21                              // 0000003F6A90: 342A2A89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F6A94: BF8701A3
	v_cndmask_b32_e32 v22, v24, v22, vcc_lo                    // 0000003F6A98: 022C2D18
	v_cndmask_b32_e32 v24, s24, v25, vcc_lo                    // 0000003F6A9C: 02303218
	v_lshlrev_b32_e32 v20, 8, v21                              // 0000003F6AA0: 30282A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F6AA4: BF870193
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000003F6AA8: 342E2C9F
	.long 0xd7006a18                                           // 0000003F6AAC: D7006A18
	v_cndmask_b32_e32 v1, v24, v4, vcc_lo                      // 0000003F6AB0: 02020918
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F6AB4: BF870211
	v_add_co_ci_u32_e64 v25, null, v26, v5, vcc_lo             // 0000003F6AB8: D5207C19 01AA0B1A
	v_ashrrev_i32_e32 v21, 31, v20                             // 0000003F6AC0: 342A289F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F6AC4: BF870114
	.long 0xd73c0016                                           // 0000003F6AC8: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000003F6ACC: 02022C81
	.long 0xd73c0014                                           // 0000003F6AD0: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000003F6AD4: 02022881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6AD8: BF870091
	.long 0xd7006a14                                           // 0000003F6ADC: D7006A14
	v_cndmask_b32_e32 v1, v24, v20, vcc_lo                     // 0000003F6AE0: 02022918
	v_add_co_ci_u32_e64 v21, null, v25, v21, vcc_lo            // 0000003F6AE4: D5207C15 01AA2B19
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6AEC: BF870092
	.long 0xd7006a14                                           // 0000003F6AF0: D7006A14
	v_cndmask_b32_e32 v1, v20, v22, vcc_lo                     // 0000003F6AF4: 02022D14
	v_add_co_ci_u32_e64 v21, null, v21, v23, vcc_lo            // 0000003F6AF8: D5207C15 01AA2F15
	global_store_d16_hi_b16 v[20:21], v19, off                 // 0000003F6B00: DC960000 007C1314
	s_cbranch_execnz 7                                         // 0000003F6B08: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a28>
	.long 0xd7006a14                                           // 0000003F6B0C: D7006A14
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F6B10: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F6B14: BF870001
	v_add_co_ci_u32_e64 v21, null, v8, v2, vcc_lo              // 0000003F6B18: D5207C15 01AA0508
	global_store_d16_hi_b16 v[20:21], v19, off offset:96       // 0000003F6B20: DC960060 007C1314
	global_load_d16_b16 v19, v[6:7], off offset:128            // 0000003F6B28: DC820080 137C0006
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 0000003F6B30: D5010011 20022311
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003F6B38: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F6B3C: BF8700A2
	v_add_f32_e32 v17, v17, v18                                // 0000003F6B40: 06222511
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003F6B44: 8B6A6A7E
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 0000003F6B48: 102222FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F6B50: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6B54: BF870091
	v_fma_mix_f32 v17, v19, v17, neg(0) op_sel_hi:[1,0,0]      // 0000003F6B58: CC200011 8A022313
	v_bfe_u32 v18, v17, 16, 1                                  // 0000003F6B60: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F6B68: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 0000003F6B6C: D6550011 03FE2511 00007FFF
	s_cbranch_vccnz 276                                        // 0000003F6B78: BFA40114 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ecc>
	v_or_b32_e32 v18, 64, v3                                   // 0000003F6B7C: 382406C0
	v_lshrrev_b32_e32 v19, 23, v11                             // 0000003F6B80: 32261697
	v_mov_b32_e32 v21, s15                                     // 0000003F6B84: 7E2A020F
	v_mov_b32_e32 v23, s14                                     // 0000003F6B88: 7E2E020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6B8C: BF870093
	v_add_nc_u32_e32 v19, v18, v19                             // 0000003F6B90: 4A262712
	v_and_b32_e32 v20, 0xfffffe00, v19                         // 0000003F6B94: 362826FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6B9C: BF870091
	v_sub_nc_u32_e32 v20, v18, v20                             // 0000003F6BA0: 4C282912
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v20                        // 0000003F6BA4: 7C8828FF 00000100
	v_add_nc_u32_e32 v22, 0xffffff00, v20                      // 0000003F6BAC: 4A2C28FF FFFFFF00
	v_cndmask_b32_e32 v24, s25, v21, vcc_lo                    // 0000003F6BB4: 02302A19
	v_ashrrev_i32_e32 v19, 9, v19                              // 0000003F6BB8: 34262689
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F6BBC: BF8701A3
	v_cndmask_b32_e32 v20, v22, v20, vcc_lo                    // 0000003F6BC0: 02282916
	v_cndmask_b32_e32 v22, s24, v23, vcc_lo                    // 0000003F6BC4: 022C2E18
	v_lshlrev_b32_e32 v18, 8, v19                              // 0000003F6BC8: 30242688
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F6BCC: BF870193
	v_ashrrev_i32_e32 v21, 31, v20                             // 0000003F6BD0: 342A289F
	.long 0xd7006a16                                           // 0000003F6BD4: D7006A16
	v_cndmask_b32_e32 v1, v22, v4, vcc_lo                      // 0000003F6BD8: 02020916
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F6BDC: BF870211
	v_add_co_ci_u32_e64 v23, null, v24, v5, vcc_lo             // 0000003F6BE0: D5207C17 01AA0B18
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000003F6BE8: 3426249F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F6BEC: BF870114
	.long 0xd73c0014                                           // 0000003F6BF0: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000003F6BF4: 02022881
	.long 0xd73c0012                                           // 0000003F6BF8: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000003F6BFC: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6C00: BF870091
	.long 0xd7006a12                                           // 0000003F6C04: D7006A12
	v_cndmask_b32_e32 v1, v22, v18, vcc_lo                     // 0000003F6C08: 02022516
	v_add_co_ci_u32_e64 v19, null, v23, v19, vcc_lo            // 0000003F6C0C: D5207C13 01AA2717
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6C14: BF870092
	.long 0xd7006a12                                           // 0000003F6C18: D7006A12
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 0000003F6C1C: 02022912
	v_add_co_ci_u32_e64 v19, null, v19, v21, vcc_lo            // 0000003F6C20: D5207C13 01AA2B13
	global_store_d16_hi_b16 v[18:19], v17, off                 // 0000003F6C28: DC960000 007C1112
	s_cbranch_execnz 7                                         // 0000003F6C30: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2b50>
	.long 0xd7006a12                                           // 0000003F6C34: D7006A12
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F6C38: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F6C3C: BF870001
	v_add_co_ci_u32_e64 v19, null, v8, v2, vcc_lo              // 0000003F6C40: D5207C13 01AA0508
	global_store_d16_hi_b16 v[18:19], v17, off offset:128      // 0000003F6C48: DC960080 007C1112
	global_load_d16_b16 v17, v[6:7], off offset:160            // 0000003F6C50: DC8200A0 117C0006
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 0000003F6C58: D501000F 20021F0F
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003F6C60: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F6C64: BF8700A2
	v_add_f32_e32 v15, v15, v16                                // 0000003F6C68: 061E210F
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003F6C6C: 8B6A6A7E
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 0000003F6C70: 101E1EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F6C78: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6C7C: BF870091
	v_fma_mix_f32 v15, v17, v15, neg(0) op_sel_hi:[1,0,0]      // 0000003F6C80: CC20000F 8A021F11
	v_bfe_u32 v16, v15, 16, 1                                  // 0000003F6C88: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F6C90: BF870001
	v_add3_u32 v15, v15, v16, 0x7fff                           // 0000003F6C94: D655000F 03FE210F 00007FFF
	s_cbranch_vccnz 203                                        // 0000003F6CA0: BFA400CB <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ed0>
	v_or_b32_e32 v16, 0x50, v3                                 // 0000003F6CA4: 382006FF 00000050
	v_lshrrev_b32_e32 v17, 23, v11                             // 0000003F6CAC: 32221697
	v_mov_b32_e32 v19, s15                                     // 0000003F6CB0: 7E26020F
	v_mov_b32_e32 v21, s14                                     // 0000003F6CB4: 7E2A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6CB8: BF870093
	v_add_nc_u32_e32 v17, v16, v17                             // 0000003F6CBC: 4A222310
	v_and_b32_e32 v18, 0xfffffe00, v17                         // 0000003F6CC0: 362422FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6CC8: BF870091
	v_sub_nc_u32_e32 v18, v16, v18                             // 0000003F6CCC: 4C242510
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v18                        // 0000003F6CD0: 7C8824FF 00000100
	v_add_nc_u32_e32 v20, 0xffffff00, v18                      // 0000003F6CD8: 4A2824FF FFFFFF00
	v_cndmask_b32_e32 v22, s25, v19, vcc_lo                    // 0000003F6CE0: 022C2619
	v_ashrrev_i32_e32 v17, 9, v17                              // 0000003F6CE4: 34222289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F6CE8: BF8701A3
	v_cndmask_b32_e32 v18, v20, v18, vcc_lo                    // 0000003F6CEC: 02242514
	v_cndmask_b32_e32 v20, s24, v21, vcc_lo                    // 0000003F6CF0: 02282A18
	v_lshlrev_b32_e32 v16, 8, v17                              // 0000003F6CF4: 30202288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F6CF8: BF870193
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000003F6CFC: 3426249F
	.long 0xd7006a14                                           // 0000003F6D00: D7006A14
	v_cndmask_b32_e32 v1, v20, v4, vcc_lo                      // 0000003F6D04: 02020914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F6D08: BF870211
	v_add_co_ci_u32_e64 v21, null, v22, v5, vcc_lo             // 0000003F6D0C: D5207C15 01AA0B16
	v_ashrrev_i32_e32 v17, 31, v16                             // 0000003F6D14: 3422209F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F6D18: BF870114
	.long 0xd73c0012                                           // 0000003F6D1C: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000003F6D20: 02022481
	.long 0xd73c0010                                           // 0000003F6D24: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000003F6D28: 02022081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6D2C: BF870091
	.long 0xd7006a10                                           // 0000003F6D30: D7006A10
	v_cndmask_b32_e32 v1, v20, v16, vcc_lo                     // 0000003F6D34: 02022114
	v_add_co_ci_u32_e64 v17, null, v21, v17, vcc_lo            // 0000003F6D38: D5207C11 01AA2315
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6D40: BF870092
	.long 0xd7006a10                                           // 0000003F6D44: D7006A10
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 0000003F6D48: 02022510
	v_add_co_ci_u32_e64 v17, null, v17, v19, vcc_lo            // 0000003F6D4C: D5207C11 01AA2711
	global_store_d16_hi_b16 v[16:17], v15, off                 // 0000003F6D54: DC960000 007C0F10
	s_cbranch_execnz 7                                         // 0000003F6D5C: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2c7c>
	.long 0xd7006a10                                           // 0000003F6D60: D7006A10
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F6D64: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F6D68: BF870001
	v_add_co_ci_u32_e64 v17, null, v8, v2, vcc_lo              // 0000003F6D6C: D5207C11 01AA0508
	global_store_d16_hi_b16 v[16:17], v15, off offset:160      // 0000003F6D74: DC9600A0 007C0F10
	global_load_d16_b16 v15, v[6:7], off offset:192            // 0000003F6D7C: DC8200C0 0F7C0006
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 0000003F6D84: D501000C 2002190C
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003F6D8C: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F6D90: BF8700A2
	v_add_f32_e32 v12, v12, v13                                // 0000003F6D94: 06181B0C
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003F6D98: 8B6A6A7E
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 0000003F6D9C: 101818FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F6DA4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6DA8: BF870091
	v_fma_mix_f32 v12, v15, v12, neg(0) op_sel_hi:[1,0,0]      // 0000003F6DAC: CC20000C 8A02190F
	v_bfe_u32 v13, v12, 16, 1                                  // 0000003F6DB4: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F6DBC: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 0000003F6DC0: D655000C 03FE1B0C 00007FFF
	s_cbranch_vccnz 129                                        // 0000003F6DCC: BFA40081 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ed4>
	v_or_b32_e32 v13, 0x60, v3                                 // 0000003F6DD0: 381A06FF 00000060
	v_lshrrev_b32_e32 v15, 23, v11                             // 0000003F6DD8: 321E1697
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6DDC: BF870091
	v_dual_mov_b32 v18, s14 :: v_dual_add_nc_u32 v15, v13, v15 // 0000003F6DE0: CA20000E 120E1F0D
	v_and_b32_e32 v16, 0xfffffe00, v15                         // 0000003F6DE8: 36201EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003F6DF0: BF8701B1
	v_sub_nc_u32_e32 v13, v13, v16                             // 0000003F6DF4: 4C1A210D
	v_mov_b32_e32 v16, s15                                     // 0000003F6DF8: 7E20020F
	v_ashrrev_i32_e32 v15, 9, v15                              // 0000003F6DFC: 341E1E89
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v13                        // 0000003F6E00: 7C881AFF 00000100
	v_add_nc_u32_e32 v17, 0xffffff00, v13                      // 0000003F6E08: 4A221AFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F6E10: BF8701A3
	v_lshlrev_b32_e32 v15, 8, v15                              // 0000003F6E14: 301E1E88
	v_cndmask_b32_e32 v19, s25, v16, vcc_lo                    // 0000003F6E18: 02262019
	v_cndmask_b32_e32 v17, v17, v13, vcc_lo                    // 0000003F6E1C: 02221B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F6E20: BF8701A3
	v_ashrrev_i32_e32 v16, 31, v15                             // 0000003F6E24: 34201E9F
	v_cndmask_b32_e32 v13, s24, v18, vcc_lo                    // 0000003F6E28: 021A2418
	v_ashrrev_i32_e32 v18, 31, v17                             // 0000003F6E2C: 3424229F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F6E30: BF870193
	.long 0xd73c000f                                           // 0000003F6E34: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000003F6E38: 02021E81
	.long 0xd7006a0d                                           // 0000003F6E3C: D7006A0D
	v_cndmask_b32_e32 v1, v13, v4, vcc_lo                      // 0000003F6E40: 0202090D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F6E44: BF870211
	v_add_co_ci_u32_e64 v19, null, v19, v5, vcc_lo             // 0000003F6E48: D5207C13 01AA0B13
	.long 0xd73c0011                                           // 0000003F6E50: D73C0011
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 0000003F6E54: 02022281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6E58: BF870093
	.long 0xd7006a0d                                           // 0000003F6E5C: D7006A0D
	v_cndmask_b32_e32 v1, v13, v15, vcc_lo                     // 0000003F6E60: 02021F0D
	v_add_co_ci_u32_e64 v16, null, v19, v16, vcc_lo            // 0000003F6E64: D5207C10 01AA2113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6E6C: BF870092
	.long 0xd7006a0f                                           // 0000003F6E70: D7006A0F
	v_cndmask_b32_e32 v1, v13, v17, vcc_lo                     // 0000003F6E74: 0202230D
	v_add_co_ci_u32_e64 v16, null, v16, v18, vcc_lo            // 0000003F6E78: D5207C10 01AA2510
	global_store_d16_hi_b16 v[15:16], v12, off                 // 0000003F6E80: DC960000 007C0C0F
	s_cbranch_execnz 7                                         // 0000003F6E88: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2da8>
	.long 0xd7006a0f                                           // 0000003F6E8C: D7006A0F
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F6E90: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F6E94: BF870001
	v_add_co_ci_u32_e64 v16, null, v8, v2, vcc_lo              // 0000003F6E98: D5207C10 01AA0508
	global_store_d16_hi_b16 v[15:16], v12, off offset:192      // 0000003F6EA0: DC9600C0 007C0C0F
	global_load_d16_b16 v6, v[6:7], off offset:224             // 0000003F6EA8: DC8200E0 067C0006
	v_cndmask_b32_e64 v7, -v9, v9, s0                          // 0000003F6EB0: D5010007 20021309
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003F6EB8: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F6EBC: BF8700A2
	v_add_f32_e32 v7, v7, v10                                  // 0000003F6EC0: 060E1507
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003F6EC4: 8B6A6A7E
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 0000003F6EC8: 100E0EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F6ED0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6ED4: BF870091
	v_fma_mix_f32 v6, v6, v7, neg(0) op_sel_hi:[1,0,0]         // 0000003F6ED8: CC200006 8A020F06
	v_bfe_u32 v7, v6, 16, 1                                    // 0000003F6EE0: D6100007 02052106
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F6EE8: BF870001
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000003F6EEC: D6550006 03FE0F06 00007FFF
	s_cbranch_vccnz 55                                         // 0000003F6EF8: BFA40037 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ed8>
	v_or_b32_e32 v3, 0x70, v3                                  // 0000003F6EFC: 380606FF 00000070
	v_lshrrev_b32_e32 v7, 23, v11                              // 0000003F6F04: 320E1697
	v_mov_b32_e32 v10, s15                                     // 0000003F6F08: 7E14020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6F0C: BF870092
	v_dual_mov_b32 v12, s14 :: v_dual_add_nc_u32 v7, v3, v7    // 0000003F6F10: CA20000E 0C060F03
	v_and_b32_e32 v9, 0xfffffe00, v7                           // 0000003F6F18: 36120EFF FFFFFE00
	v_ashrrev_i32_e32 v7, 9, v7                                // 0000003F6F20: 340E0E89
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F6F24: BF870112
	v_sub_nc_u32_e32 v3, v3, v9                                // 0000003F6F28: 4C061303
	v_lshlrev_b32_e32 v9, 8, v7                                // 0000003F6F2C: 30120E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003F6F30: BF870232
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v3                         // 0000003F6F34: 7C8806FF 00000100
	v_add_nc_u32_e32 v7, 0xffffff00, v3                        // 0000003F6F3C: 4A0E06FF FFFFFF00
	v_cndmask_b32_e32 v13, s25, v10, vcc_lo                    // 0000003F6F44: 021A1419
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000003F6F48: 3414129F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F6F4C: BF8701A3
	v_cndmask_b32_e32 v11, v7, v3, vcc_lo                      // 0000003F6F50: 02160707
	v_cndmask_b32_e32 v3, s24, v12, vcc_lo                     // 0000003F6F54: 02061818
	.long 0xd73c0009                                           // 0000003F6F58: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000003F6F5C: 02021281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F6F60: BF870193
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000003F6F64: 3418169F
	.long 0xd7006a07                                           // 0000003F6F68: D7006A07
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 0000003F6F6C: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F6F70: BF870191
	v_add_co_ci_u32_e64 v5, null, v13, v5, vcc_lo              // 0000003F6F74: D5207C05 01AA0B0D
	.long 0xd73c0003                                           // 0000003F6F7C: D73C0003
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000003F6F80: 02021681
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6F84: BF870093
	.long 0xd7006a07                                           // 0000003F6F88: D7006A07
	v_cndmask_b32_e32 v1, v7, v9, vcc_lo                       // 0000003F6F8C: 02021307
	v_add_co_ci_u32_e64 v5, null, v5, v10, vcc_lo              // 0000003F6F90: D5207C05 01AA1505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F6F98: BF870092
	.long 0xd7006a03                                           // 0000003F6F9C: D7006A03
	v_cndmask_b32_e32 v1, v7, v3, vcc_lo                       // 0000003F6FA0: 02020707
	v_add_co_ci_u32_e64 v4, null, v5, v4, vcc_lo               // 0000003F6FA4: D5207C04 01AA0905
	global_store_d16_hi_b16 v[3:4], v6, off                    // 0000003F6FAC: DC960000 007C0603
	s_cbranch_execnz 62797                                     // 0000003F6FB4: BFA6F54D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 7                                                 // 0000003F6FB8: BFA00007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ed8>
	s_branch 65012                                             // 0000003F6FBC: BFA0FDF4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2690>
	s_branch 65086                                             // 0000003F6FC0: BFA0FE3E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x27bc>
	s_branch 65159                                             // 0000003F6FC4: BFA0FE87 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x28e4>
	s_branch 65232                                             // 0000003F6FC8: BFA0FED0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a0c>
	s_branch 65305                                             // 0000003F6FCC: BFA0FF19 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2b34>
	s_branch 65379                                             // 0000003F6FD0: BFA0FF63 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2c60>
	s_branch 65453                                             // 0000003F6FD4: BFA0FFAD <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2d8c>
	.long 0xd7006a00                                           // 0000003F6FD8: D7006A00
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F6FDC: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F6FE0: BF870001
	v_add_co_ci_u32_e64 v1, null, v8, v2, vcc_lo               // 0000003F6FE4: D5207C01 01AA0508
	global_store_d16_hi_b16 v[0:1], v6, off offset:224         // 0000003F6FEC: DC9600E0 007C0600
	s_endpgm                                                   // 0000003F6FF4: BFB00000
		...

