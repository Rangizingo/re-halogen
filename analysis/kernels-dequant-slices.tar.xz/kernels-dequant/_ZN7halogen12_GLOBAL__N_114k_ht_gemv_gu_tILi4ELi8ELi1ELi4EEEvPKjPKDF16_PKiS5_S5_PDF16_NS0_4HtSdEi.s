0000000000a34000 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi():
	s_clause 0x1                                               // 000000A34000: BF850001
	s_load_b32 s3, s[0:1], 0x88                                // 000000A34004: F40000C0 F8000088
	s_load_b512 s[12:27], s[0:1], null                         // 000000A3400C: F4100300 F8000000
	v_and_b32_e32 v25, 31, v0                                  // 000000A34014: 3632009F
	v_lshrrev_b32_e32 v24, 5, v0                               // 000000A34018: 32300085
	s_mov_b32 s4, -1                                           // 000000A3401C: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 000000A34020: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 000000A34024: BF040302
	s_cbranch_scc1 2240                                        // 000000A34028: BFA208C0 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x232c>
	s_load_b64 s[8:9], s[0:1], 0x7c                            // 000000A3402C: F4040200 F800007C
	s_sub_i32 s3, s2, s3                                       // 000000A34034: 81830302
	s_clause 0x1                                               // 000000A34038: BF850001
	s_load_b256 s[44:51], s[0:1], 0x60                         // 000000A3403C: F40C0B00 F8000060
	s_load_b256 s[36:43], s[0:1], 0x40                         // 000000A34044: F40C0900 F8000040
	s_mov_b32 s33, 0                                           // 000000A3404C: BEA10080
	s_mov_b32 s28, exec_lo                                     // 000000A34050: BE9C007E
	s_waitcnt lgkmcnt(0)                                       // 000000A34054: BF89FC07
	s_abs_i32 s4, s9                                           // 000000A34058: BE841509
	s_ashr_i32 s7, s9, 31                                      // 000000A3405C: 86079F09
	s_cvt_f32_u32 s5, s4                                       // 000000A34060: BE856504
	s_sub_i32 s6, 0, s4                                        // 000000A34064: 81860480
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000A34068: BF87029A
	v_rcp_iflag_f32_e32 v1, s5                                 // 000000A3406C: 7E025605
	v_readfirstlane_b32 s5, v1                                 // 000000A34070: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 000000A34074: A205FF05 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000A3407C: BF87059B
	s_cvt_u32_f32 s5, s5                                       // 000000A34080: BE856705
	s_mul_i32 s6, s6, s5                                       // 000000A34084: 96060506
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A34088: BF870499
	s_mul_hi_u32 s6, s5, s6                                    // 000000A3408C: 96860605
	s_add_i32 s5, s5, s6                                       // 000000A34090: 81050605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A34094: BF870499
	s_mul_hi_u32 s5, s3, s5                                    // 000000A34098: 96850503
	s_mul_i32 s6, s5, s4                                       // 000000A3409C: 96060405
	s_add_i32 s10, s5, 1                                       // 000000A340A0: 810A8105
	s_sub_i32 s6, s3, s6                                       // 000000A340A4: 81860603
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A340A8: BF870009
	s_sub_i32 s11, s6, s4                                      // 000000A340AC: 818B0406
	s_cmp_ge_u32 s6, s4                                        // 000000A340B0: BF090406
	s_cselect_b32 s5, s10, s5                                  // 000000A340B4: 9805050A
	s_cselect_b32 s6, s11, s6                                  // 000000A340B8: 9806060B
	s_add_i32 s10, s5, 1                                       // 000000A340BC: 810A8105
	s_cmp_ge_u32 s6, s4                                        // 000000A340C0: BF090406
	s_cselect_b32 s4, s10, s5                                  // 000000A340C4: 9804050A
	s_ashr_i32 s11, s50, 31                                    // 000000A340C8: 860B9F32
	s_xor_b32 s4, s4, s7                                       // 000000A340CC: 8D040704
	s_lshr_b32 s1, s11, 25                                     // 000000A340D0: 8501990B
	s_sub_i32 s10, s4, s7                                      // 000000A340D4: 818A0704
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A340D8: BF870499
	s_mul_i32 s0, s10, s9                                      // 000000A340DC: 9600090A
	s_sub_i32 s30, s3, s0                                      // 000000A340E0: 819E0003
	s_add_i32 s0, s50, s1                                      // 000000A340E4: 81000132
	s_mul_i32 s31, s30, s8                                     // 000000A340E8: 961F081E
	s_ashr_i32 s0, s0, 7                                       // 000000A340EC: 86008700
	s_add_i32 s1, s31, s8                                      // 000000A340F0: 8101081F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A340F4: BF870499
	s_min_i32 s0, s0, s1                                       // 000000A340F8: 89000100
	s_sub_i32 s29, s0, s31                                     // 000000A340FC: 819D1F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A34100: BF870009
	.long 0xd4c4007e                                           // 000000A34104: D4C4007E
	v_cndmask_b32_e32 v1, s29, v24, vcc_lo                     // 000000A34108: 0202301D
	s_cbranch_execz 503                                        // 000000A3410C: BFA501F7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8ec>
	s_add_i32 s34, s48, -1                                     // 000000A34110: 8122C130
	s_cmp_lg_u64 s[40:41], 0                                   // 000000A34114: BF118028
	v_dual_mov_b32 v8, v24 :: v_dual_and_b32 v1, 1, v0         // 000000A34118: CA240118 08000081
	s_cselect_b32 s35, -1, 0                                   // 000000A34120: 982380C1
	s_abs_i32 s51, s29                                         // 000000A34124: BEB3151D
	v_and_b32_e32 v2, 2, v0                                    // 000000A34128: 36040082
	s_cvt_f32_u32 s0, s51                                      // 000000A3412C: BE806533
	v_lshlrev_b32_e32 v6, 3, v25                               // 000000A34130: 300C3283
	v_lshlrev_b32_e32 v7, 7, v24                               // 000000A34134: 300E3087
	v_and_b32_e32 v3, 4, v0                                    // 000000A34138: 36060084
	v_rcp_iflag_f32_e32 v4, s0                                 // 000000A3413C: 7E085600
	v_and_b32_e32 v5, 8, v0                                    // 000000A34140: 360A0088
	.long 0xd44a0001                                           // 000000A34144: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000A34148: 02020280
	.long 0xd44a0003                                           // 000000A3414C: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000A34150: 02020480
	v_lshl_or_b32 v1, v24, 8, v6                               // 000000A34154: D6560001 04191118
	v_lshl_add_u32 v2, s31, 7, v7                              // 000000A3415C: D6460002 041D0E1F
	s_ashr_i32 s53, s29, 31                                    // 000000A34164: 86359F1D
	s_sub_i32 s55, 0, s51                                      // 000000A34168: 81B73380
	s_mul_i32 s8, s53, 0x1400                                  // 000000A3416C: 9608FF35 00001400
	.long 0xd44c0000                                           // 000000A34174: D44C0000
	v_cndmask_b32_e32 v1, 16, v25, vcc_lo                      // 000000A34178: 02023290
	v_readfirstlane_b32 s5, v4                                 // 000000A3417C: 7E0A0504
	.long 0xd44a0004                                           // 000000A34180: D44A0004
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000A34184: 02020680
	v_subrev_nc_u32_e32 v9, s8, v1                             // 000000A34188: 4E120208
	v_lshl_or_b32 v1, v25, 2, v2                               // 000000A3418C: D6560001 04090519
	s_lshl_b32 s6, s29, 7                                      // 000000A34194: 8406871D
	s_mul_f32 s7, s5, 0x4f7ffffe                               // 000000A34198: A207FF05 4F7FFFFE
	.long 0xd44a0005                                           // 000000A341A0: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000A341A4: 02020A80
	s_mov_b32 s52, 0x76543210                                  // 000000A341A8: BEB400FF 76543210
	s_lshl_b32 s54, s29, 8                                     // 000000A341B0: 8436881D
	s_cvt_u32_f32 s7, s7                                       // 000000A341B4: BE876707
	s_mov_b32 s57, 0x3db504f3                                  // 000000A341B8: BEB900FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A341C0: BF87049A
	s_mul_i32 s55, s55, s7                                     // 000000A341C4: 96370737
	s_mul_hi_u32 s8, s7, s55                                   // 000000A341C8: 96883707
	s_sub_i32 s55, 0, s6                                       // 000000A341CC: 81B70680
	s_add_i32 s56, s7, s8                                      // 000000A341D0: 81380807
	s_branch 164                                               // 000000A341D4: BFA000A4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x468>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A341D8: BF870091
	.long 0xd7006a02                                           // 000000A341DC: D7006A02
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000A341E0: 0202041A
	v_add_co_ci_u32_e64 v3, null, s27, v3, vcc_lo              // 000000A341E4: D5207C03 01AA061B
	v_sub_f32_e32 v4, v15, v13                                 // 000000A341EC: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000A341F0: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000A341F8: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000A34200: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 000000A34204: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 000000A3420C: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 000000A34214: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A34218: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000A3421C: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000A34220: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000A34224: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000A34228: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A3422C: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A34230: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A34238: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A34240: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000A34248: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A34250: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 000000A34254: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A34258: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000A34260: D5010007 20060F07
	.long 0xd72c0006                                           // 000000A34268: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 000000A3426C: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 000000A34274: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A34278: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000A34280: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A34288: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 000000A3428C: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A34290: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000A34298: D5010003 20060703
	.long 0xd72c0007                                           // 000000A342A0: D72C0007
	v_cndmask_b32_e32 v1, s54, v10, vcc_lo                     // 000000A342A4: 02021436
	v_add_f32_e32 v2, v2, v13                                  // 000000A342A8: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A342AC: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000A342B4: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 000000A342BC: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A342C0: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A342C4: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000A342CC: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 000000A342D4: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A342D8: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000A342E0: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A342E8: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000A342F0: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 000000A342F8: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A342FC: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 000000A34304: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000A34308: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 000000A34310: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A34314: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000A3431C: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A34324: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000A3432C: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A34334: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000A3433C: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 000000A34344: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000A34348: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 000000A3434C: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A34350: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 000000A34354: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A34358: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000A34360: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A34368: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A3436C: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000A34374: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000A3437C: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A34380: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000A34388: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 000000A34390: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 000000A34398: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s29, v8                           // 000000A3439C: 7C86101D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A343A0: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 000000A343A4: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 000000A343AC: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A343B4: BF870234
	v_mov_b32_e32 v13, v2                                      // 000000A343B8: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000A343BC: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000A343C4: D5010004 20020904
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000A343CC: D65C000B 03FC690B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 000000A343D8: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000A343DC: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000A343E4: D5010003 20020703
	v_permlanex16_b32 v10, v10, s52, 0xfedcba98                // 000000A343EC: D65C000A 03FC690A FEDCBA98
	v_permlanex16_b32 v13, v13, s52, 0xfedcba98                // 000000A343F8: D65C000D 03FC690D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 000000A34404: 060A1705
	v_permlanex16_b32 v12, v12, s52, 0xfedcba98                // 000000A34408: D65C000C 03FC690C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A34414: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 000000A34418: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 000000A34424: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A34428: BF870214
	v_fma_mixhi_f16 v2, v5, s57, 0                             // 000000A3442C: CC220002 02007305
	v_add_f32_e32 v10, v3, v12                                 // 000000A34434: 06141903
	s_or_b32 s33, vcc_lo, s33                                  // 000000A34438: 8C21216A
	v_fma_mixlo_f16 v2, v4, s57, 0                             // 000000A3443C: CC210002 02007304
	v_fma_mixhi_f16 v3, v7, s57, 0                             // 000000A34444: CC220003 02007307
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A3444C: BF870003
	v_fma_mixlo_f16 v3, v10, s57, 0                            // 000000A34450: CC210003 0200730A
	ds_store_b64 v6, v[2:3] offset:22016                       // 000000A34458: D9345600 00000206
	s_and_not1_b32 exec_lo, exec_lo, s33                       // 000000A34460: 917E217E
	s_cbranch_execz 289                                        // 000000A34464: BFA50121 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8ec>
	.long 0xd72d0002                                           // 000000A34468: D72D0002
	v_cndmask_b32_e32 v0, v8, v56, vcc_lo                      // 000000A3446C: 02007108
	s_mov_b32 s6, -1                                           // 000000A34470: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A34474: BF870091
	.long 0xd72c0003                                           // 000000A34478: D72C0003
	v_cndmask_b32_e32 v0, v2, v51, vcc_lo                      // 000000A3447C: 02006702
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000A34480: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A34484: BF870121
	v_subrev_nc_u32_e32 v5, s51, v3                            // 000000A34488: 4E0A0633
	v_cmp_le_u32_e32 vcc_lo, s51, v3                           // 000000A3448C: 7C960633
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000A34490: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A34498: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000A3449C: 02040902
	v_cmp_le_u32_e32 vcc_lo, s51, v3                           // 000000A344A0: 7C960633
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A344A4: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000A344A8: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000A344AC: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s35                        // 000000A344B0: 916A237E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A344B4: BF870091
	v_xor_b32_e32 v11, s53, v2                                 // 000000A344B8: 3A160435
	v_subrev_nc_u32_e32 v10, s53, v11                          // 000000A344BC: 4E141635
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A344C0: BF8700A1
	v_mad_u64_u32 v[6:7], null, s55, v10, v[1:2]               // 000000A344C4: D6FE7C06 04061437
	v_min_i32_e32 v2, s34, v10                                 // 000000A344CC: 22041422
	v_mad_i64_i32 v[4:5], null, v2, s50, 0                     // 000000A344D0: D6FF7C04 02006502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A344D8: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000A344DC: 340E0C9F
	.long 0xd73c0002                                           // 000000A344E0: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000A344E4: 02020C81
	s_cbranch_vccnz 212                                        // 000000A344E8: BFA400D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x83c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A344EC: BF870093
	.long 0xd7006a06                                           // 000000A344F0: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000A344F4: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000A344F8: D5207C07 01AA0F05
	.long 0x7f3c3880                                           // 000000A34500: 7F3C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A34504: BF870112
	.long 0xd73c0006                                           // 000000A34508: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000A3450C: 02020C81
	.long 0x7f42399e                                           // 000000A34510: 7F42399E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A34514: BF870092
	.long 0xd7006a0c                                           // 000000A34518: D7006A0C
	v_cndmask_b32_e32 v1, s38, v6, vcc_lo                      // 000000A3451C: 02020C26
	v_add_co_ci_u32_e64 v13, null, s39, v7, vcc_lo             // 000000A34520: D5207C0D 01AA0E27
	.long 0xd7006a06                                           // 000000A34528: D7006A06
	v_cndmask_b32_e32 v1, s40, v6, vcc_lo                      // 000000A3452C: 02020C28
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A34530: BF870001
	v_add_co_ci_u32_e64 v7, null, s41, v7, vcc_lo              // 000000A34534: D5207C07 01AA0E29
	global_load_b64 v[12:13], v[12:13], off                    // 000000A3453C: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 000000A34544: D7006A0E
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000A34548: 0202041A
	global_load_b64 v[6:7], v[6:7], off                        // 000000A3454C: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s27, v3, vcc_lo             // 000000A34554: D5207C0F 01AA061B
	s_clause 0x1                                               // 000000A3455C: BF850001
	global_load_b32 v16, v[14:15], off                         // 000000A34560: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 000000A34568: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 000000A34570: BF890FF7
	.long 0x7e1e390c                                           // 000000A34574: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 000000A34578: BF890BF7
	v_and_b32_e32 v40, 0xffff0000, v6                          // 000000A3457C: 36500CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000A34584: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A34588: BF870093
	v_lshlrev_b32_e32 v15, 16, v15                             // 000000A3458C: 301E1E90
	v_mul_f32_e32 v19, 0xbfb8aa3b, v15                         // 000000A34590: 10261EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000A34598: BF870291
	v_exp_f32_e32 v19, v19                                     // 000000A3459C: 7E264B13
	v_dual_add_f32 v19, 1.0, v19 :: v_dual_and_b32 v12, 0xffff0000, v12// 000000A345A0: C92426F2 130C18FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A345AC: BF870111
	v_mul_f32_e32 v18, 0xbfb8aa3b, v12                         // 000000A345B0: 102418FF BFB8AA3B
	v_div_scale_f32 v23, null, v19, v19, v15                   // 000000A345B8: D6FC7C17 043E2713
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A345C0: BF8701B2
	v_exp_f32_e32 v18, v18                                     // 000000A345C4: 7E244B12
	v_lshlrev_b32_e32 v17, 16, v13                             // 000000A345C8: 30221A90
	v_div_scale_f32 v38, s7, v15, v19, v15                     // 000000A345CC: D6FC0726 043E270F
	v_rcp_f32_e32 v29, v23                                     // 000000A345D4: 7E3A5517
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A345D8: BF870196
	v_add_f32_e32 v18, 1.0, v18                                // 000000A345DC: 062424F2
	v_mul_f32_e32 v20, 0xbfb8aa3b, v17                         // 000000A345E0: 102822FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A345E8: BF870195
	v_fma_f32 v37, -v23, v29, 1.0                              // 000000A345EC: D6130025 23CA3B17
	v_div_scale_f32 v22, null, v18, v18, v12                   // 000000A345F4: D6FC7C16 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A345FC: BF8701B3
	v_exp_f32_e32 v20, v20                                     // 000000A34600: 7E284B14
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000A34604: 361A1AFF FFFF0000
	v_div_scale_f32 v34, vcc_lo, v12, v18, v12                 // 000000A3460C: D6FC6A22 0432250C
	v_rcp_f32_e32 v27, v22                                     // 000000A34614: 7E365516
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 000000A34618: BF870106
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_mul_f32 v21, 0xbfb8aa3b, v13// 000000A3461C: C90628F2 14141AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A34628: BF870115
	v_fma_f32 v35, -v22, v27, 1.0                              // 000000A3462C: D6130023 23CA3716
	v_div_scale_f32 v26, null, v20, v20, v17                   // 000000A34634: D6FC7C1A 04462914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A3463C: BF8701A3
	v_exp_f32_e32 v21, v21                                     // 000000A34640: 7E2A4B15
	v_div_scale_f32 v36, s6, v17, v20, v17                     // 000000A34644: D6FC0624 04462911
	v_fmac_f32_e32 v27, v35, v27                               // 000000A3464C: 56363723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000A34650: BF870313
	v_rcp_f32_e32 v31, v26                                     // 000000A34654: 7E3E551A
	v_add_f32_e32 v21, 1.0, v21                                // 000000A34658: 062A2AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A3465C: BF870115
	v_fma_f32 v39, -v26, v31, 1.0                              // 000000A34660: D6130027 23CA3F1A
	v_div_scale_f32 v28, null, v21, v21, v13                   // 000000A34668: D6FC7C1C 04362B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A34670: BF8701A2
	v_fmac_f32_e32 v31, v39, v31                               // 000000A34674: 563E3F27
	v_mul_f32_e32 v39, v34, v27                                // 000000A34678: 104E3722
	v_rcp_f32_e32 v32, v28                                     // 000000A3467C: 7E40551C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A34680: BF870112
	v_mul_f32_e32 v41, v36, v31                                // 000000A34684: 10523F24
	v_fma_f32 v42, -v22, v39, v34                              // 000000A34688: D613002A 248A4F16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A34690: BF870112
	v_fma_f32 v45, -v26, v41, v36                              // 000000A34694: D613002D 2492531A
	v_fmac_f32_e32 v39, v42, v27                               // 000000A3469C: 564E372A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A346A0: BF870195
	v_fma_f32 v35, -v28, v32, 1.0                              // 000000A346A4: D6130023 23CA411C
	v_fmac_f32_e32 v41, v45, v31                               // 000000A346AC: 56523F2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A346B0: BF870193
	v_fma_f32 v22, -v22, v39, v34                              // 000000A346B4: D6130016 248A4F16
	v_fmac_f32_e32 v32, v35, v32                               // 000000A346BC: 56404123
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A346C0: BF870193
	v_fma_f32 v26, -v26, v41, v36                              // 000000A346C4: D613001A 2492531A
	v_div_fmas_f32 v22, v22, v27, v39                          // 000000A346CC: D6370016 049E3716
	s_mov_b32 vcc_lo, s7                                       // 000000A346D4: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000A346D8: BF870131
	v_div_fixup_f32 v12, v22, v18, v12                         // 000000A346DC: D627000C 04322516
	v_fmac_f32_e32 v29, v37, v29                               // 000000A346E4: 563A3B25
	v_div_scale_f32 v37, s8, v13, v21, v13                     // 000000A346E8: D6FC0825 04362B0D
	v_dual_mul_f32 v12, v12, v40 :: v_dual_mul_f32 v35, v38, v29// 000000A346F0: C8C6510C 0C223B26
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A346F8: BF870112
	v_mul_f32_e32 v43, v37, v32                                // 000000A346FC: 10564125
	.long 0x7e3c398c                                           // 000000A34700: 7E3C398C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A34704: BF870193
	v_fma_f32 v44, -v23, v35, v38                              // 000000A34708: D613002C 249A4717
	v_fma_f32 v42, -v28, v43, v37                              // 000000A34710: D613002A 2496571C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A34718: BF870112
	v_fmac_f32_e32 v35, v44, v29                               // 000000A3471C: 56463B2C
	v_fmac_f32_e32 v43, v42, v32                               // 000000A34720: 5656412A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A34724: BF870112
	v_fma_f32 v23, -v23, v35, v38                              // 000000A34728: D6130017 249A4717
	v_fma_f32 v22, -v28, v43, v37                              // 000000A34730: D6130016 2496571C
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A34738: BF870002
	v_div_fmas_f32 v23, v23, v29, v35                          // 000000A3473C: D6370017 048E3B17
	s_mov_b32 vcc_lo, s6                                       // 000000A34744: BEEA0006
	s_mov_b32 s6, 0                                            // 000000A34748: BE860080
	v_div_fmas_f32 v18, v26, v31, v41                          // 000000A3474C: D6370012 04A63F1A
	s_mov_b32 vcc_lo, s8                                       // 000000A34754: BEEA0008
	v_div_fixup_f32 v15, v23, v19, v15                         // 000000A34758: D627000F 043E2717
	v_lshlrev_b32_e32 v19, 16, v7                              // 000000A34760: 30260E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000A34764: 360E0EFF FFFF0000
	v_div_fixup_f32 v17, v18, v20, v17                         // 000000A3476C: D6270011 04462912
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A34774: BF8701A4
	v_mul_f32_e32 v6, v15, v6                                  // 000000A34778: 100C0D0F
	v_div_fmas_f32 v15, v22, v32, v43                          // 000000A3477C: D637000F 04AE4116
	v_mul_f32_e32 v17, v17, v19                                // 000000A34784: 10222711
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A34788: BF870193
	.long 0x7e423986                                           // 000000A3478C: 7E423986
	v_div_fixup_f32 v13, v15, v21, v13                         // 000000A34790: D627000D 04362B0F
	v_and_b32_e32 v15, 1, v30                                  // 000000A34798: 361E3C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A3479C: BF870214
	v_bfe_u32 v18, v17, 16, 1                                  // 000000A347A0: D6100012 02052111
	v_and_b32_e32 v19, 1, v33                                  // 000000A347A8: 36264281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A347AC: BF870214
	v_mul_f32_e32 v7, v13, v7                                  // 000000A347B0: 100E0F0D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000A347B4: D655000C 03FE1F0C 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A347C0: BF870214
	v_add3_u32 v13, v17, v18, 0x7fff                           // 000000A347C4: D655000D 03FE2511 00007FFF
	v_add3_u32 v6, v6, v19, 0x7fff                             // 000000A347D0: D6550006 03FE2706 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A347DC: BF870214
	v_bfe_u32 v15, v7, 16, 1                                   // 000000A347E0: D610000F 02052107
	v_and_b32_e32 v12, 0xffff0000, v12                         // 000000A347E8: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A347F0: BF870214
	v_and_b32_e32 v17, 0xffff0000, v13                         // 000000A347F4: 36221AFF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000A347FC: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A34804: BF870004
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000A34808: D6550007 03FE1F07 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000A34814: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000A34818: CC20080D 8A021910
	s_waitcnt vmcnt(0)                                         // 000000A34820: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 000000A34824: CC20000C 8A02230E
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 000000A3482C: CC20000F 8A020D10
	v_and_b32_e32 v14, 0xffff0000, v7                          // 000000A34834: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000A3483C: 916A067E
	s_cbranch_vccnz 65125                                      // 000000A34840: BFA4FE65 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d8>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A34844: BF870093
	.long 0xd73c0004                                           // 000000A34848: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000A3484C: 02020881
	.long 0xd7006a04                                           // 000000A34850: D7006A04
	v_cndmask_b32_e32 v1, s38, v4, vcc_lo                      // 000000A34854: 02020826
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A34858: BF870111
	v_add_co_ci_u32_e64 v5, null, s39, v5, vcc_lo              // 000000A3485C: D5207C05 01AA0A27
	.long 0xd7006a04                                           // 000000A34864: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000A34868: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A3486C: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000A34870: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000A34878: D7006A06
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000A3487C: 0202041A
	v_add_co_ci_u32_e64 v7, null, s27, v3, vcc_lo              // 000000A34880: D5207C07 01AA061B
	global_load_b64 v[4:5], v[4:5], off                        // 000000A34888: DC560000 047C0004
	s_clause 0x1                                               // 000000A34890: BF850001
	global_load_b32 v14, v[6:7], off                           // 000000A34894: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000A3489C: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000A348A4: BF890BF7
	.long 0x7e0e3904                                           // 000000A348A8: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000A348AC: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 000000A348B4: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A348B8: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000A348BC: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000A348C0: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000A348C4: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 000000A348CC: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 000000A348D0: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 000000A348D8: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 000000A348E0: 361C0AFF FFFF0000
	s_branch 65083                                             // 000000A348E8: BFA0FE3B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d8>
	s_or_b32 exec_lo, exec_lo, s28                             // 000000A348EC: 8C7E1C7E
	s_bfe_i32 s28, s29, 0x1001c                                // 000000A348F0: 939CFF1D 0001001C
	s_lshr_b32 s3, s11, 28                                     // 000000A348F8: 85039C0B
	s_lshr_b64 s[0:1], s[28:29], 29                            // 000000A348FC: 85809D1C
	s_add_i32 s3, s50, s3                                      // 000000A34900: 81030332
	s_add_i32 s0, s0, 7                                        // 000000A34904: 81008700
	s_lshl_b32 s1, s29, 3                                      // 000000A34908: 8401831D
	s_ashr_i32 s0, s0, 3                                       // 000000A3490C: 86008300
	s_lshl_b32 s4, s31, 3                                      // 000000A34910: 8404831F
	.long 0xd72c0001                                           // 000000A34914: D72C0001
	v_cndmask_b32_e32 v1, s0, v24, vcc_lo                      // 000000A34918: 02023000
	v_lshlrev_b32_e32 v7, 2, v25                               // 000000A3491C: 300E3282
	s_waitcnt lgkmcnt(0)                                       // 000000A34920: BF89FC07
	s_barrier                                                  // 000000A34924: BFBD0000
	buffer_gl0_inv                                             // 000000A34928: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 000000A34930: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 000000A34934: 86008403
	s_ashr_i32 s3, s4, 31                                      // 000000A34938: 86039F04
	s_mul_hi_i32 s5, s10, s0                                   // 000000A3493C: 9705000A
	s_mul_i32 s0, s10, s0                                      // 000000A34940: 9600000A
	v_min_i32_e32 v8, s1, v2                                   // 000000A34944: 22100401
	s_add_u32 s0, s0, s4                                       // 000000A34948: 80000400
	s_addc_u32 s1, s5, s3                                      // 000000A3494C: 82010305
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A34950: BF870099
	s_lshl_b64 s[4:5], s[0:1], 10                              // 000000A34954: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v8                            // 000000A34958: 7C821101
	s_add_u32 s1, s24, s4                                      // 000000A3495C: 80010418
	s_addc_u32 s3, s25, s5                                     // 000000A34960: 82030519
	s_and_saveexec_b32 s4, vcc_lo                              // 000000A34964: BE84206A
	s_cbranch_execz 93                                         // 000000A34968: BFA5005D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xae0>
	.long 0xd7010002                                           // 000000A3496C: D7010002
	v_cndmask_b32_e32 v0, v25, v129, vcc_lo                    // 000000A34970: 02010319
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A34974: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 000000A34978: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000A34980: 3404029F
	.long 0xd44c0000                                           // 000000A34984: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000A34988: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A3498C: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 000000A34990: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v9, v5, v3       // 000000A3499C: CA200080 04080705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A349A4: BF870114
	.long 0xd73c0005                                           // 000000A349A8: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000A349AC: 0202028A
	.long 0xd73c0002                                           // 000000A349B0: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000A349B4: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A349B8: BF870223
	v_lshlrev_b32_e32 v4, 24, v9                               // 000000A349BC: 30081298
	v_bfe_i32 v10, v9, 7, 1                                    // 000000A349C0: D611000A 02050F09
	.long 0xd700000b                                           // 000000A349C8: D700000B
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000A349CC: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A349D0: BF870211
	v_add_co_ci_u32_e64 v6, null, s3, v6, s0                   // 000000A349D4: D5207C06 00020C03
	v_ashrrev_i32_e32 v9, 22, v4                               // 000000A349DC: 34120896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A349E0: BF870093
	.long 0xd7000004                                           // 000000A349E4: D7000004
	v_cndmask_b32_e32 v1, v11, v2, vcc_lo                      // 000000A349E8: 0202050B
	v_add_co_ci_u32_e64 v5, null, v6, v3, s0                   // 000000A349EC: D5207C05 00020706
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A349F4: BF870093
	.long 0xd7000009                                           // 000000A349F8: D7000009
	v_cndmask_b32_e32 v1, v11, v9, vcc_lo                      // 000000A349FC: 0202130B
	v_add_co_ci_u32_e64 v10, null, v6, v10, s0                 // 000000A34A00: D5207C0A 00021506
	.long 0xd700000b                                           // 000000A34A08: D700000B
	v_cndmask_b32_e32 v1, v11, v7, vcc_lo                      // 000000A34A0C: 02020F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A34A10: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v6, s0                   // 000000A34A14: D5207C0C 00020C80
	s_clause 0x17                                              // 000000A34A1C: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000A34A20: DC520000 027C0004
	global_load_b32 v56, v[4:5], off offset:128                // 000000A34A28: DC520080 387C0004
	global_load_b32 v53, v[4:5], off offset:256                // 000000A34A30: DC520100 357C0004
	global_load_b32 v50, v[4:5], off offset:384                // 000000A34A38: DC520180 327C0004
	global_load_b32 v47, v[4:5], off offset:512                // 000000A34A40: DC520200 2F7C0004
	global_load_b32 v44, v[4:5], off offset:640                // 000000A34A48: DC520280 2C7C0004
	global_load_b32 v26, v[4:5], off offset:768                // 000000A34A50: DC520300 1A7C0004
	global_load_b32 v18, v[4:5], off offset:896                // 000000A34A58: DC520380 127C0004
	global_load_b32 v4, v[9:10], off                           // 000000A34A60: DC520000 047C0009
	global_load_b32 v57, v[9:10], off offset:128               // 000000A34A68: DC520080 397C0009
	global_load_b32 v54, v[9:10], off offset:256               // 000000A34A70: DC520100 367C0009
	global_load_b32 v51, v[9:10], off offset:384               // 000000A34A78: DC520180 337C0009
	global_load_b32 v48, v[9:10], off offset:512               // 000000A34A80: DC520200 307C0009
	global_load_b32 v45, v[9:10], off offset:640               // 000000A34A88: DC520280 2D7C0009
	global_load_b32 v27, v[9:10], off offset:768               // 000000A34A90: DC520300 1B7C0009
	global_load_b32 v19, v[9:10], off offset:896               // 000000A34A98: DC520380 137C0009
	global_load_b32 v3, v[11:12], off                          // 000000A34AA0: DC520000 037C000B
	global_load_b32 v55, v[11:12], off offset:128              // 000000A34AA8: DC520080 377C000B
	global_load_b32 v52, v[11:12], off offset:256              // 000000A34AB0: DC520100 347C000B
	global_load_b32 v49, v[11:12], off offset:384              // 000000A34AB8: DC520180 317C000B
	global_load_b32 v46, v[11:12], off offset:512              // 000000A34AC0: DC520200 2E7C000B
	global_load_b32 v43, v[11:12], off offset:640              // 000000A34AC8: DC520280 2B7C000B
	global_load_b32 v23, v[11:12], off offset:768              // 000000A34AD0: DC520300 177C000B
	global_load_b32 v17, v[11:12], off offset:896              // 000000A34AD8: DC520380 117C000B
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A34AE0: 8C7E047E
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 000000A34AE4: CA100080 0A080080
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 000000A34AEC: CA100080 0B0C0080
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v14, 0             // 000000A34AF4: CA100080 0D0E0080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 000000A34AFC: CA100080 0F100080
	s_ashr_i32 s11, s10, 31                                    // 000000A34B04: 860B9F0A
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A34B08: BE80206A
	s_cbranch_execz 939                                        // 000000A34B0C: BFA503AB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x19bc>
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v5, -1, v0      // 000000A34B10: CA200080 0A0400C1
	v_and_or_b32 v20, v0, 16, 0x5600                           // 000000A34B18: D6570014 03FD2100 00005600
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v21, 2, v25    // 000000A34B24: CA220080 0C143282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A34B2C: BF870123
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v5, 31, v5         // 000000A34B30: CA240080 10040A9F
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v14, 0              // 000000A34B38: CA100080 090E0080
	v_dual_mov_b32 v11, 0 :: v_dual_lshlrev_b32 v22, 2, v5     // 000000A34B40: CA220080 0B160A82
	v_mov_b32_e32 v13, 0                                       // 000000A34B48: 7E1A0280
	v_mov_b32_e32 v15, 0                                       // 000000A34B4C: 7E1E0280
	s_mov_b32 s4, 0                                            // 000000A34B50: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000A34B54: B0051EEE
	s_branch 861                                               // 000000A34B58: BFA0035D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x18d0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000A34B5C: 8C7E067E
	s_waitcnt vmcnt(15)                                        // 000000A34B60: BF893FF7
	v_alignbit_b32 v58, v2, v4, 16                             // 000000A34B64: D616003A 02420902
	s_waitcnt vmcnt(7)                                         // 000000A34B6C: BF891FF7
	v_bfe_u32 v59, v3, 12, 16                                  // 000000A34B70: D610003B 02411903
	v_bfe_u32 v60, v3, 8, 16                                   // 000000A34B78: D610003C 02411103
	v_lshl_add_u32 v1, v1, 5, v20                              // 000000A34B80: D6460001 04510B01
	v_bfe_u32 v61, v3, 4, 16                                   // 000000A34B88: D610003D 02410903
	v_bfe_u32 v62, v58, 12, 16                                 // 000000A34B90: D610003E 0241193A
	v_bfe_u32 v65, v58, 8, 16                                  // 000000A34B98: D6100041 0241113A
	.long 0xd72c003b                                           // 000000A34BA0: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A34BA4: 020276FF 83DCD12D
	.long 0xd72c003c                                           // 000000A34BAC: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A34BB0: 020278FF 83DCD12D
	.long 0xd72c003d                                           // 000000A34BB8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A34BBC: 02027AFF 83DCD12D
	.long 0xd72c003e                                           // 000000A34BC4: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A34BC8: 02027CFF 83DCD12D
	.long 0xd72c0041                                           // 000000A34BD0: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A34BD4: 020282FF 83DCD12D
	v_alignbit_b32 v56, v56, v57, 16                           // 000000A34BDC: D6160038 02427338
	v_alignbit_b32 v53, v53, v54, 16                           // 000000A34BE4: D6160035 02426D35
	v_alignbit_b32 v50, v50, v51, 16                           // 000000A34BEC: D6160032 02426732
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A34BF4: D622003B 03FD013B 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A34C00: D622003C 03FD013C 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A34C0C: D622003D 03FD013D 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A34C18: D622003E 03FD013E 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A34C24: D6220041 03FD0141 00006400
	v_and_b32_e32 v59, 0xffff, v59                             // 000000A34C30: 367676FF 0000FFFF
	v_bfe_u32 v51, v50, 12, 16                                 // 000000A34C38: D6100033 02411932
	v_alignbit_b32 v47, v47, v48, 16                           // 000000A34C40: D616002F 0242612F
	v_and_b32_e32 v62, 0xffff, v62                             // 000000A34C48: 367C7CFF 0000FFFF
	v_alignbit_b32 v44, v44, v45, 16                           // 000000A34C50: D616002C 02425B2C
	v_lshl_or_b32 v59, v60, 16, v59                            // 000000A34C58: D656003B 04ED213C
	.long 0xd72c0033                                           // 000000A34C60: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000A34C64: 020266FF 83DCD12D
	v_alignbit_b32 v26, v26, v27, 16                           // 000000A34C6C: D616001A 0242371A
	v_lshl_or_b32 v62, v65, 16, v62                            // 000000A34C74: D656003E 04F92141
	s_waitcnt vmcnt(5)                                         // 000000A34C7C: BF8917F7
	v_bfe_u32 v65, v52, 4, 16                                  // 000000A34C80: D6100041 02410934
	v_pk_fma_f16 v59, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A34C88: CC0E003B 0BFC0B3B 0000C931
	v_alignbit_b32 v18, v18, v19, 16                           // 000000A34C94: D6160012 02422712
	v_cmp_eq_u32_e32 vcc_lo, v5, v8                            // 000000A34C9C: 7C941105
	v_pk_fma_f16 v60, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A34CA0: CC0E003C 0BFC0B3E 0000C931
	v_and_b32_e32 v63, 0xffff, v3                              // 000000A34CAC: 367E06FF 0000FFFF
	ds_load_b128 v[1:4], v1                                    // 000000A34CB4: DBFC0000 01000001
	v_bfe_u32 v62, v55, 12, 16                                 // 000000A34CBC: D610003E 02411937
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000A34CC4: D6220033 03FD0133 00006400
	s_or_b32 s4, vcc_lo, s4                                    // 000000A34CD0: 8C04046A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A34CD4: BF870112
	.long 0xd72c003e                                           // 000000A34CD8: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A34CDC: 02027CFF 83DCD12D
	v_and_b32_e32 v51, 0xffff, v51                             // 000000A34CE4: 366666FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A34CEC: BF870092
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A34CF0: D622003E 03FD013E 00006400
	v_and_b32_e32 v62, 0xffff, v62                             // 000000A34CFC: 367C7CFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A34D04: BF89FC07
	v_dot2acc_f32_f16 v16, v60, v1                             // 000000A34D08: 0420033C
	.long 0xd72c003f                                           // 000000A34D0C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A34D10: 02027EFF 83DCD12D
	v_and_b32_e32 v60, 0xffff, v56                             // 000000A34D18: 367870FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A34D20: BF870191
	.long 0xd72c003c                                           // 000000A34D24: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A34D28: 020278FF 83DCD12D
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A34D30: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A34D3C: BF870191
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000A34D40: 307E7E90
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A34D44: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A34D50: BF870002
	v_and_or_b32 v57, 0xffff, v61, v63                         // 000000A34D54: D6570039 04FE7AFF 0000FFFF
	v_bfe_u32 v61, v56, 12, 16                                 // 000000A34D60: D610003D 02411938
	v_bfe_u32 v63, v56, 8, 16                                  // 000000A34D68: D610003F 02411138
	v_bfe_u32 v56, v56, 4, 16                                  // 000000A34D70: D6100038 02410938
	v_lshlrev_b32_e32 v60, 16, v60                             // 000000A34D78: 30787890
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A34D7C: CC0E0039 0BFC0B39 0000C931
	.long 0xd72c003d                                           // 000000A34D88: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A34D8C: 02027AFF 83DCD12D
	.long 0xd72c003f                                           // 000000A34D94: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A34D98: 02027EFF 83DCD12D
	.long 0xd72c0038                                           // 000000A34DA0: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A34DA4: 020270FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A34DAC: BF870193
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A34DB0: D622003D 03FD013D 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A34DBC: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A34DC8: BF870193
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A34DCC: D6220038 03FD0138 00006400
	v_and_b32_e32 v61, 0xffff, v61                             // 000000A34DD8: 367A7AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A34DE0: BF870112
	v_and_or_b32 v56, 0xffff, v56, v60                         // 000000A34DE4: D6570038 04F270FF 0000FFFF
	v_lshl_or_b32 v61, v63, 16, v61                            // 000000A34DF0: D656003D 04F5213F
	v_bfe_u32 v63, v52, 12, 16                                 // 000000A34DF8: D610003F 02411934
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A34E00: BF870193
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A34E04: CC0E0038 0BFC0B38 0000C931
	v_pk_fma_f16 v54, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A34E10: CC0E0036 0BFC0B3D 0000C931
	v_and_b32_e32 v64, 0xffff, v58                             // 000000A34E1C: 368074FF 0000FFFF
	v_bfe_u32 v58, v58, 4, 16                                  // 000000A34E24: D610003A 0241093A
	v_and_b32_e32 v61, 0xffff, v53                             // 000000A34E2C: 367A6AFF 0000FFFF
	.long 0xd72c003f                                           // 000000A34E34: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A34E38: 02027EFF 83DCD12D
	v_dot2acc_f32_f16 v15, v54, v1                             // 000000A34E40: 041E0336
	.long 0xd72c0040                                           // 000000A34E44: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A34E48: 020280FF 83DCD12D
	.long 0xd72c003a                                           // 000000A34E50: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A34E54: 020274FF 83DCD12D
	.long 0xd72c0036                                           // 000000A34E5C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A34E60: 020282FF 83DCD12D
	.long 0xd72c003d                                           // 000000A34E68: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A34E6C: 02027AFF 83DCD12D
	v_dot2acc_f32_f16 v15, v56, v2                             // 000000A34E74: 041E0538
	s_waitcnt vmcnt(4)                                         // 000000A34E78: BF8913F7
	v_bfe_u32 v56, v49, 4, 16                                  // 000000A34E7C: D6100038 02410931
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A34E84: D622003F 03FD013F 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A34E90: D6220040 03FD0140 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A34E9C: D622003A 03FD013A 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000A34EA8: D6220036 03FD0136 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A34EB4: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A34EC0: BF870114
	v_lshlrev_b32_e32 v64, 16, v64                             // 000000A34EC4: 30808090
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000A34EC8: 307A7A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A34ECC: BF870122
	v_and_or_b32 v58, 0xffff, v58, v64                         // 000000A34ED0: D657003A 050274FF 0000FFFF
	v_bfe_u32 v64, v55, 8, 16                                  // 000000A34EDC: D6100040 02411137
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A34EE4: CC0E003A 0BFC0B3A 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A34EF0: BF870191
	v_dot2acc_f32_f16 v16, v58, v2                             // 000000A34EF4: 0420053A
	.long 0xd72c003a                                           // 000000A34EF8: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A34EFC: 020280FF 83DCD12D
	v_bfe_u32 v64, v55, 4, 16                                  // 000000A34F04: D6100040 02410937
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A34F0C: BF8701A3
	v_dot2acc_f32_f16 v16, v59, v3                             // 000000A34F10: 0420073B
	v_bfe_u32 v59, v53, 12, 16                                 // 000000A34F14: D610003B 02411935
	.long 0xd72c003c                                           // 000000A34F1C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A34F20: 020280FF 83DCD12D
	v_bfe_u32 v64, v52, 8, 16                                  // 000000A34F28: D6100040 02411134
	v_and_b32_e32 v52, 0xffff, v52                             // 000000A34F30: 366868FF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A34F38: D622003A 03FD013A 00006400
	.long 0xd72c003b                                           // 000000A34F44: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A34F48: 020276FF 83DCD12D
	v_dot2acc_f32_f16 v16, v57, v4                             // 000000A34F50: 04200939
	.long 0xd72c0040                                           // 000000A34F54: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A34F58: 020280FF 83DCD12D
	.long 0xd72c0034                                           // 000000A34F60: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000A34F64: 020268FF 83DCD12D
	v_lshl_or_b32 v58, v58, 16, v62                            // 000000A34F6C: D656003A 04F9213A
	v_bfe_u32 v62, v53, 8, 16                                  // 000000A34F74: D610003E 02411135
	v_bfe_u32 v53, v53, 4, 16                                  // 000000A34F7C: D6100035 02410935
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A34F84: D622003C 03FD013C 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A34F90: D622003B 03FD013B 00006400
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A34F9C: CC0E003A 0BFC0B3A 0000C931
	.long 0xd72c003e                                           // 000000A34FA8: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A34FAC: 02027CFF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000A34FB4: D6220034 03FD0134 00006400
	.long 0xd72c0035                                           // 000000A34FC0: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A34FC4: 02026AFF 83DCD12D
	s_waitcnt vmcnt(3)                                         // 000000A34FCC: BF890FF7
	v_bfe_u32 v57, v46, 8, 16                                  // 000000A34FD0: D6100039 0241112E
	v_dot2acc_f32_f16 v15, v58, v3                             // 000000A34FD8: 041E073A
	v_bfe_u32 v58, v46, 4, 16                                  // 000000A34FDC: D610003A 0241092E
	v_lshlrev_b32_e32 v52, 16, v52                             // 000000A34FE4: 30686890
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A34FE8: D622003E 03FD013E 00006400
	.long 0xd72c0039                                           // 000000A34FF4: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A34FF8: 020272FF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A35000: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A3500C: BF870114
	v_and_or_b32 v52, 0xffff, v54, v52                         // 000000A35010: D6570034 04D26CFF 0000FFFF
	v_and_or_b32 v53, 0xffff, v53, v61                         // 000000A3501C: D6570035 04F66AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A35028: BF870232
	v_pk_fma_f16 v52, v52, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A3502C: CC0E0034 0BFC0B34 0000C931
	v_and_b32_e32 v59, 0xffff, v59                             // 000000A35038: 367676FF 0000FFFF
	v_and_b32_e32 v61, 0xffff, v63                             // 000000A35040: 367A7EFF 0000FFFF
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A35048: CC0E0035 0BFC0B35 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A35054: BF870123
	v_lshl_or_b32 v59, v62, 16, v59                            // 000000A35058: D656003B 04ED213E
	v_sad_u8 v62, v64, 0, 0x6400                               // 000000A35060: D622003E 03FD0140 00006400
	v_pk_fma_f16 v59, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A3506C: CC0E003B 0BFC0B3B 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A35078: BF870112
	v_lshl_or_b32 v61, v62, 16, v61                            // 000000A3507C: D656003D 04F5213E
	v_dual_dot2acc_f32_f16 v14, v59, v1 :: v_dual_and_b32 v55, 0xffff, v55// 000000A35084: CB24033B 0E366EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A35090: BF870112
	v_pk_fma_f16 v54, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A35094: CC0E0036 0BFC0B3D 0000C931
	v_dot2acc_f32_f16 v14, v53, v2                             // 000000A350A0: 041C0535
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A350A4: BF870113
	.long 0xd72c0037                                           // 000000A350A8: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A350AC: 02026EFF 83DCD12D
	v_dot2acc_f32_f16 v14, v54, v3                             // 000000A350B4: 041C0736
	v_bfe_u32 v54, v49, 12, 16                                 // 000000A350B8: D6100036 02411931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A350C0: BF870193
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A350C4: D6220037 03FD0137 00006400
	v_dot2acc_f32_f16 v14, v52, v4                             // 000000A350D0: 041C0934
	v_bfe_u32 v52, v50, 8, 16                                  // 000000A350D4: D6100034 02411132
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A350DC: BF870214
	.long 0xd72c0036                                           // 000000A350E0: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000A350E4: 02026CFF 83DCD12D
	v_lshlrev_b32_e32 v55, 16, v55                             // 000000A350EC: 306E6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A350F0: BF870113
	.long 0xd72c0034                                           // 000000A350F4: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000A350F8: 020268FF 83DCD12D
	v_and_or_b32 v55, 0xffff, v60, v55                         // 000000A35100: D6570037 04DE78FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A3510C: BF870114
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000A35110: D6220036 03FD0136 00006400
	v_pk_fma_f16 v53, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A3511C: CC0E0035 0BFC0B37 0000C931
	v_bfe_u32 v55, v49, 8, 16                                  // 000000A35128: D6100037 02411131
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A35130: BF870003
	v_and_b32_e32 v54, 0xffff, v54                             // 000000A35134: 366C6CFF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v49                             // 000000A3513C: 366262FF 0000FFFF
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000A35144: D6220034 03FD0134 00006400
	v_dot2acc_f32_f16 v15, v53, v4                             // 000000A35150: 041E0935
	v_and_b32_e32 v53, 0xffff, v50                             // 000000A35154: 366A64FF 0000FFFF
	v_bfe_u32 v50, v50, 4, 16                                  // 000000A3515C: D6100032 02410932
	.long 0xd72c0037                                           // 000000A35164: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A35168: 02026EFF 83DCD12D
	.long 0xd72c0031                                           // 000000A35170: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000A35174: 020262FF 83DCD12D
	v_lshl_or_b32 v51, v52, 16, v51                            // 000000A3517C: D6560033 04CD2134
	.long 0xd72c0035                                           // 000000A35184: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A35188: 02026AFF 83DCD12D
	.long 0xd72c0032                                           // 000000A35190: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000A35194: 020264FF 83DCD12D
	.long 0xd72c0034                                           // 000000A3519C: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A351A0: 020270FF 83DCD12D
	v_bfe_u32 v56, v46, 12, 16                                 // 000000A351A8: D6100038 0241192E
	v_pk_fma_f16 v51, v51, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A351B0: CC0E0033 0BFC0B33 0000C931
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A351BC: D6220037 03FD0137 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000A351C8: D6220031 03FD0131 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A351D4: D6220035 03FD0135 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000A351E0: D6220032 03FD0132 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A351EC: BF870004
	v_lshl_or_b32 v48, v55, 16, v54                            // 000000A351F0: D6560030 04D92137
	v_and_b32_e32 v54, 0xffff, v47                             // 000000A351F8: 366C5EFF 0000FFFF
	v_bfe_u32 v55, v47, 8, 16                                  // 000000A35200: D6100037 0241112F
	v_lshlrev_b32_e32 v53, 16, v53                             // 000000A35208: 306A6A90
	.long 0xd72c0038                                           // 000000A3520C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A35210: 020270FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000A35218: D6220034 03FD0134 00006400
	.long 0xd72c0036                                           // 000000A35224: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000A35228: 02026CFF 83DCD12D
	.long 0xd72c0037                                           // 000000A35230: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A35234: 02026EFF 83DCD12D
	v_and_or_b32 v50, 0xffff, v50, v53                         // 000000A3523C: D6570032 04D664FF 0000FFFF
	v_bfe_u32 v53, v47, 12, 16                                 // 000000A35248: D6100035 0241192F
	v_bfe_u32 v47, v47, 4, 16                                  // 000000A35250: D610002F 0241092F
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000A35258: 30626290
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A3525C: D6220038 03FD0138 00006400
	v_pk_fma_f16 v50, v50, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A35268: CC0E0032 0BFC0B32 0000C931
	.long 0xd72c0035                                           // 000000A35274: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A35278: 02026AFF 83DCD12D
	.long 0xd72c002f                                           // 000000A35280: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000A35284: 02025EFF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000A3528C: D6220036 03FD0136 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A35298: D6220037 03FD0137 00006400
	v_and_or_b32 v49, 0xffff, v52, v49                         // 000000A352A4: D6570031 04C668FF 0000FFFF
	v_dot2acc_f32_f16 v13, v51, v1                             // 000000A352B0: 041A0333
	v_pk_fma_f16 v48, v48, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A352B4: CC0E0030 0BFC0B30 0000C931
	v_lshlrev_b32_e32 v54, 16, v54                             // 000000A352C0: 306C6C90
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A352C4: D6220035 03FD0135 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000A352D0: D622002F 03FD012F 00006400
	v_dot2acc_f32_f16 v13, v50, v2                             // 000000A352DC: 041A0532
	s_waitcnt vmcnt(2)                                         // 000000A352E0: BF890BF7
	v_bfe_u32 v50, v43, 12, 16                                 // 000000A352E4: D6100032 0241192B
	v_and_b32_e32 v53, 0xffff, v53                             // 000000A352EC: 366A6AFF 0000FFFF
	v_and_or_b32 v47, 0xffff, v47, v54                         // 000000A352F4: D657002F 04DA5EFF 0000FFFF
	v_dual_dot2acc_f32_f16 v13, v48, v3 :: v_dual_and_b32 v54, 0xffff, v56// 000000A35300: CB240730 0D3670FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A3530C: BF870214
	.long 0xd72c0032                                           // 000000A35310: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000A35314: 020264FF 83DCD12D
	v_lshl_or_b32 v52, v55, 16, v53                            // 000000A3531C: D6560034 04D52137
	v_sad_u8 v55, v57, 0, 0x6400                               // 000000A35324: D6220037 03FD0139 00006400
	v_pk_fma_f16 v47, v47, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A35330: CC0E002F 0BFC0B2F 0000C931
	.long 0xd72c0035                                           // 000000A3533C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A35340: 020274FF 83DCD12D
	v_mov_b32_e32 v57, v41                                     // 000000A35348: 7E720329
	v_pk_fma_f16 v51, v52, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A3534C: CC0E0033 0BFC0B34 0000C931
	v_lshl_or_b32 v52, v55, 16, v54                            // 000000A35358: D6560034 04D92137
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000A35360: D6220032 03FD0132 00006400
	v_dual_mov_b32 v55, v41 :: v_dual_mov_b32 v56, v35         // 000000A3536C: CA100129 37380123
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A35374: BF870214
	v_dot2acc_f32_f16 v12, v51, v1                             // 000000A35378: 04180333
	v_pk_fma_f16 v45, v52, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A3537C: CC0E002D 0BFC0B34 0000C931
	v_bfe_u32 v51, v43, 8, 16                                  // 000000A35388: D6100033 0241112B
	v_bfe_u32 v52, v43, 4, 16                                  // 000000A35390: D6100034 0241092B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A35398: BF870234
	v_dual_dot2acc_f32_f16 v12, v47, v2 :: v_dual_and_b32 v43, 0xffff, v43// 000000A3539C: CB24052F 0C2A56FF 0000FFFF
	v_pk_fma_f16 v47, v49, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A353A8: CC0E002F 0BFC0B31 0000C931
	v_bfe_u32 v49, v44, 12, 16                                 // 000000A353B4: D6100031 0241192C
	.long 0xd72c0034                                           // 000000A353BC: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000A353C0: 020268FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A353C8: BF870004
	.long 0xd72c002b                                           // 000000A353CC: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000A353D0: 020256FF 83DCD12D
	v_dot2acc_f32_f16 v12, v45, v3                             // 000000A353D8: 0418072D
	v_bfe_u32 v45, v44, 8, 16                                  // 000000A353DC: D610002D 0241112C
	.long 0xd72c0030                                           // 000000A353E4: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000A353E8: 020262FF 83DCD12D
	v_and_b32_e32 v49, 0xffff, v44                             // 000000A353F0: 366258FF 0000FFFF
	v_bfe_u32 v44, v44, 4, 16                                  // 000000A353F8: D610002C 0241092C
	.long 0xd72c0033                                           // 000000A35400: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000A35404: 020266FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000A3540C: D6220034 03FD0134 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000A35418: D622002B 03FD012B 00006400
	.long 0xd72c0031                                           // 000000A35424: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000A35428: 020262FF 83DCD12D
	.long 0xd72c002d                                           // 000000A35430: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000A35434: 02025AFF 83DCD12D
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000A3543C: D6220030 03FD0130 00006400
	.long 0xd72c002c                                           // 000000A35448: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000A3544C: 020258FF 83DCD12D
	v_lshlrev_b32_e32 v43, 16, v43                             // 000000A35454: 30565690
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000A35458: D6220033 03FD0133 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A35464: D6220035 03FD0135 00006400
	v_and_b32_e32 v48, 0xffff, v48                             // 000000A35470: 366060FF 0000FFFF
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000A35478: D6220031 03FD0131 00006400
	v_and_or_b32 v43, 0xffff, v52, v43                         // 000000A35484: D657002B 04AE68FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000A35490: D622002D 03FD012D 00006400
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000A3549C: D622002C 03FD012C 00006400
	s_waitcnt vmcnt(1)                                         // 000000A354A8: BF8907F7
	v_bfe_u32 v52, v23, 8, 16                                  // 000000A354AC: D6100034 02411117
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000A354B4: 30626290
	v_pk_fma_f16 v43, v43, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A354B8: CC0E002B 0BFC0B2B 0000C931
	v_and_b32_e32 v50, 0xffff, v50                             // 000000A354C4: 366464FF 0000FFFF
	v_lshl_or_b32 v45, v45, 16, v48                            // 000000A354CC: D656002D 04C1212D
	v_bfe_u32 v48, v26, 12, 16                                 // 000000A354D4: D6100030 0241191A
	v_and_or_b32 v44, 0xffff, v44, v49                         // 000000A354DC: D657002C 04C658FF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v26                             // 000000A354E8: 366234FF 0000FFFF
	v_lshl_or_b32 v27, v51, 16, v50                            // 000000A354F0: D656001B 04C92133
	v_bfe_u32 v50, v23, 12, 16                                 // 000000A354F8: D6100032 02411917
	v_pk_fma_f16 v45, v45, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A35500: CC0E002D 0BFC0B2D 0000C931
	.long 0xd72c0030                                           // 000000A3550C: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A35510: 020260FF 83DCD12D
	v_bfe_u32 v51, v26, 8, 16                                  // 000000A35518: D6100033 0241111A
	v_bfe_u32 v26, v26, 4, 16                                  // 000000A35520: D610001A 0241091A
	.long 0xd72c0032                                           // 000000A35528: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000A3552C: 020264FF 83DCD12D
	.long 0xd72c0031                                           // 000000A35534: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000A35538: 020262FF 83DCD12D
	v_dot2acc_f32_f16 v11, v45, v1                             // 000000A35540: 0416032D
	.long 0xd72c0033                                           // 000000A35544: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000A35548: 020266FF 83DCD12D
	.long 0xd72c002d                                           // 000000A35550: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000A35554: 020268FF 83DCD12D
	v_pk_fma_f16 v44, v44, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A3555C: CC0E002C 0BFC0B2C 0000C931
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000A35568: D6220030 03FD0130 00006400
	.long 0xd72c001a                                           // 000000A35574: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 000000A35578: 020234FF 83DCD12D
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000A35580: D6220032 03FD0132 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000A3558C: D6220031 03FD0131 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A35598: BF870224
	v_dual_dot2acc_f32_f16 v11, v44, v2 :: v_dual_and_b32 v48, 0xffff, v48// 000000A3559C: CB24052C 0B3060FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000A355A8: D6220033 03FD0133 00006400
	v_and_b32_e32 v50, 0xffff, v50                             // 000000A355B4: 366464FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000A355BC: D622002D 03FD012D 00006400
	v_bfe_u32 v44, v18, 12, 16                                 // 000000A355C8: D610002C 02411912
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000A355D0: D622001A 03FD011A 00006400
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000A355DC: 30626290
	v_bfe_u32 v52, v23, 4, 16                                  // 000000A355E0: D6100034 02410917
	v_lshl_or_b32 v48, v51, 16, v48                            // 000000A355E8: D6560030 04C12133
	v_lshl_or_b32 v45, v45, 16, v50                            // 000000A355F0: D656002D 04C9212D
	.long 0xd72c002c                                           // 000000A355F8: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000A355FC: 020258FF 83DCD12D
	v_bfe_u32 v50, v18, 8, 16                                  // 000000A35604: D6100032 02411112
	s_waitcnt vmcnt(0)                                         // 000000A3560C: BF8903F7
	v_bfe_u32 v51, v17, 12, 16                                 // 000000A35610: D6100033 02411911
	v_and_or_b32 v26, 0xffff, v26, v49                         // 000000A35618: D657001A 04C634FF 0000FFFF
	.long 0xd72c0031                                           // 000000A35624: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000A35628: 020268FF 83DCD12D
	v_bfe_u32 v52, v17, 8, 16                                  // 000000A35630: D6100034 02411111
	.long 0xd72c0032                                           // 000000A35638: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000A3563C: 020264FF 83DCD12D
	.long 0xd72c0033                                           // 000000A35644: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000A35648: 020266FF 83DCD12D
	v_pk_fma_f16 v27, v27, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A35650: CC0E001B 0BFC0B1B 0000C931
	v_and_b32_e32 v46, 0xffff, v46                             // 000000A3565C: 365C5CFF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000A35664: D622002C 03FD012C 00006400
	.long 0xd72c0034                                           // 000000A35670: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000A35674: 020268FF 83DCD12D
	v_and_b32_e32 v23, 0xffff, v23                             // 000000A3567C: 362E2EFF 0000FFFF
	v_dot2acc_f32_f16 v11, v27, v3                             // 000000A35684: 0416071B
	.long 0xd72c002e                                           // 000000A35688: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000A3568C: 02025CFF 83DCD12D
	v_and_b32_e32 v44, 0xffff, v44                             // 000000A35694: 365858FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000A3569C: D6220032 03FD0132 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000A356A8: D6220033 03FD0133 00006400
	v_dual_mov_b32 v54, v40 :: v_dual_dot2acc_f32_f16 v13, v47, v4// 000000A356B4: CA180128 360C092F
	v_pk_fma_f16 v26, v26, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A356BC: CC0E001A 0BFC0B1A 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A356C8: BF870214
	v_lshl_or_b32 v44, v50, 16, v44                            // 000000A356CC: D656002C 04B12132
	v_dual_mov_b32 v27, v36 :: v_dual_and_b32 v50, 0xffff, v51 // 000000A356D4: CA240124 1B3266FF 0000FFFF
	v_sad_u8 v51, v52, 0, 0x6400                               // 000000A356E0: D6220033 03FD0134 00006400
	v_mov_b32_e32 v52, v40                                     // 000000A356EC: 7E680328
	.long 0xd72c0013                                           // 000000A356F0: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 000000A356F4: 02022EFF 83DCD12D
	v_pk_fma_f16 v23, v48, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A356FC: CC0E0017 0BFC0B30 0000C931
	v_sad_u8 v48, v49, 0, 0x6400                               // 000000A35708: D6220030 03FD0131 00006400
	v_and_b32_e32 v49, 0xffff, v18                             // 000000A35714: 366224FF 0000FFFF
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000A3571C: D622002E 03FD012E 00006400
	v_bfe_u32 v18, v18, 4, 16                                  // 000000A35728: D6100012 02410912
	v_dot2acc_f32_f16 v9, v23, v1                              // 000000A35730: 04120317
	v_pk_fma_f16 v23, v44, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A35734: CC0E0017 0BFC0B2C 0000C931
	.long 0xd72c0031                                           // 000000A35740: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000A35744: 020262FF 83DCD12D
	v_lshlrev_b32_e32 v46, 16, v46                             // 000000A3574C: 305C5C90
	.long 0xd72c0012                                           // 000000A35750: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 000000A35754: 020224FF 83DCD12D
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000A3575C: D6220013 03FD0113 00006400
	v_lshl_or_b32 v44, v51, 16, v50                            // 000000A35768: D656002C 04C92133
	v_dot2acc_f32_f16 v10, v23, v1                             // 000000A35770: 04140317
	v_and_or_b32 v46, 0xffff, v53, v46                         // 000000A35774: D657002E 04BA6AFF 0000FFFF
	v_bfe_u32 v53, v17, 4, 16                                  // 000000A35780: D6100035 02410911
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000A35788: D6220031 03FD0131 00006400
	v_and_b32_e32 v17, 0xffff, v17                             // 000000A35794: 362222FF 0000FFFF
	v_sad_u8 v18, v18, 0, 0x6400                               // 000000A3579C: D6220012 03FD0112 00006400
	v_lshlrev_b32_e32 v19, 16, v19                             // 000000A357A8: 30262690
	v_pk_fma_f16 v45, v45, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A357AC: CC0E002D 0BFC0B2D 0000C931
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000A357B8: 30626290
	.long 0xd72c0011                                           // 000000A357BC: D72C0011
	v_cndmask_b32_e32 v1, 0x83dcd12d, v17, vcc_lo              // 000000A357C0: 020222FF 83DCD12D
	v_dot2acc_f32_f16 v9, v26, v2                              // 000000A357C8: 0412051A
	v_and_or_b32 v1, 0xffff, v48, v19                          // 000000A357CC: D6570001 044E60FF 0000FFFF
	v_pk_fma_f16 v19, v44, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A357D8: CC0E0013 0BFC0B2C 0000C931
	v_and_or_b32 v18, 0xffff, v18, v49                         // 000000A357E4: D6570012 04C624FF 0000FFFF
	.long 0xd72c0031                                           // 000000A357F0: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A357F4: 02026AFF 83DCD12D
	v_pk_fma_f16 v46, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A357FC: CC0E002E 0BFC0B2E 0000C931
	v_pk_fma_f16 v1, v1, s5, 0xc931 op_sel_hi:[1,0,0]          // 000000A35808: CC0E0001 0BFC0B01 0000C931
	v_sad_u8 v17, v17, 0, 0x6400                               // 000000A35814: D6220011 03FD0111 00006400
	v_pk_fma_f16 v18, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A35820: CC0E0012 0BFC0B12 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A3582C: BF870234
	v_dual_dot2acc_f32_f16 v9, v45, v3 :: v_dual_dot2acc_f32_f16 v12, v46, v4// 000000A35830: CB18072D 090C092E
	v_dot2acc_f32_f16 v11, v43, v4                             // 000000A35838: 0416092B
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000A3583C: D6220031 03FD0131 00006400
	v_dual_dot2acc_f32_f16 v10, v18, v2 :: v_dual_lshlrev_b32 v17, 16, v17// 000000A35848: CB220512 0A102290
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A35850: BF8701A4
	v_dual_dot2acc_f32_f16 v9, v1, v4 :: v_dual_mov_b32 v18, v6// 000000A35854: CB100901 09120106
	v_mov_b32_e32 v23, v36                                     // 000000A3585C: 7E2E0324
	v_and_or_b32 v17, 0xffff, v49, v17                         // 000000A35860: D6570011 044662FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A3586C: BF8701A4
	v_dual_dot2acc_f32_f16 v10, v19, v3 :: v_dual_mov_b32 v19, v34// 000000A35870: CB100713 0A120122
	v_dual_mov_b32 v26, v28 :: v_dual_mov_b32 v43, v37         // 000000A35878: CA10011C 1A2A0125
	v_pk_fma_f16 v2, v17, s5, 0xc931 op_sel_hi:[1,0,0]         // 000000A35880: CC0E0002 0BFC0B11 0000C931
	v_mov_b32_e32 v17, v34                                     // 000000A3588C: 7E220322
	v_mov_b32_e32 v45, v37                                     // 000000A35890: 7E5A0325
	v_mov_b32_e32 v44, v29                                     // 000000A35894: 7E58031D
	v_mov_b32_e32 v46, v38                                     // 000000A35898: 7E5C0326
	v_dot2acc_f32_f16 v10, v2, v4                              // 000000A3589C: 04140902
	v_mov_b32_e32 v48, v38                                     // 000000A358A0: 7E600326
	v_mov_b32_e32 v47, v30                                     // 000000A358A4: 7E5E031E
	v_mov_b32_e32 v49, v39                                     // 000000A358A8: 7E620327
	v_mov_b32_e32 v51, v39                                     // 000000A358AC: 7E660327
	v_dual_mov_b32 v50, v31 :: v_dual_mov_b32 v53, v32         // 000000A358B0: CA10011F 32340120
	v_mov_b32_e32 v3, v42                                      // 000000A358B8: 7E06032A
	v_mov_b32_e32 v4, v42                                      // 000000A358BC: 7E08032A
	v_mov_b32_e32 v2, v33                                      // 000000A358C0: 7E040321
	v_mov_b32_e32 v1, v5                                       // 000000A358C4: 7E020305
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A358C8: 917E047E
	s_cbranch_execz 58                                         // 000000A358CC: BFA5003A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x19b8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A358D0: BF8700A1
	v_add_nc_u32_e32 v5, 1, v1                                 // 000000A358D4: 4A0A0281
	s_mov_b32 s6, exec_lo                                      // 000000A358D8: BE86007E
	.long 0xd4c1007e                                           // 000000A358DC: D4C1007E
	v_cndmask_b32_e32 v1, v5, v8, vcc_lo                       // 000000A358E0: 02021105
	s_cbranch_execz 64669                                      // 000000A358E4: BFA5FC9D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xb5c>
	v_ashrrev_i32_e32 v6, 31, v5                               // 000000A358E8: 340C0A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A358EC: BF870091
	.long 0xd73c001c                                           // 000000A358F0: D73C001C
	v_cndmask_b32_e32 v1, 10, v5, vcc_lo                       // 000000A358F4: 02020A8A
	.long 0xd7006a06                                           // 000000A358F8: D7006A06
	v_cndmask_b32_e32 v1, s1, v28, vcc_lo                      // 000000A358FC: 02023801
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A35900: BF870111
	v_add_co_ci_u32_e64 v28, null, s3, v29, vcc_lo             // 000000A35904: D5207C1C 01AA3A03
	.long 0xd7006a24                                           // 000000A3590C: D7006A24
	v_cndmask_b32_e32 v1, v6, v22, vcc_lo                      // 000000A35910: 02022D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A35914: BF8700A1
	v_add_co_ci_u32_e64 v37, null, 0, v28, vcc_lo              // 000000A35918: D5207C25 01AA3880
	.long 0xd7006a3a                                           // 000000A35920: D7006A3A
	v_cndmask_b32_e32 v1, v6, v21, vcc_lo                      // 000000A35924: 02022B06
	v_add_co_ci_u32_e64 v59, null, 0, v28, vcc_lo              // 000000A35928: D5207C3B 01AA3880
	s_clause 0xf                                               // 000000A35930: BF85000F
	global_load_b32 v33, v[36:37], off                         // 000000A35934: DC520000 217C0024
	global_load_b32 v35, v[36:37], off offset:128              // 000000A3593C: DC520080 237C0024
	global_load_b32 v32, v[36:37], off offset:256              // 000000A35944: DC520100 207C0024
	global_load_b32 v31, v[36:37], off offset:384              // 000000A3594C: DC520180 1F7C0024
	global_load_b32 v30, v[36:37], off offset:512              // 000000A35954: DC520200 1E7C0024
	global_load_b32 v29, v[36:37], off offset:640              // 000000A3595C: DC520280 1D7C0024
	global_load_b32 v28, v[36:37], off offset:768              // 000000A35964: DC520300 1C7C0024
	global_load_b32 v6, v[36:37], off offset:896               // 000000A3596C: DC520380 067C0024
	global_load_b32 v42, v[58:59], off                         // 000000A35974: DC520000 2A7C003A
	global_load_b32 v41, v[58:59], off offset:128              // 000000A3597C: DC520080 297C003A
	global_load_b32 v40, v[58:59], off offset:256              // 000000A35984: DC520100 287C003A
	global_load_b32 v39, v[58:59], off offset:384              // 000000A3598C: DC520180 277C003A
	global_load_b32 v38, v[58:59], off offset:512              // 000000A35994: DC520200 267C003A
	global_load_b32 v37, v[58:59], off offset:640              // 000000A3599C: DC520280 257C003A
	global_load_b32 v36, v[58:59], off offset:768              // 000000A359A4: DC520300 247C003A
	global_load_b32 v34, v[58:59], off offset:896              // 000000A359AC: DC520380 227C003A
	s_branch 64617                                             // 000000A359B4: BFA0FC69 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xb5c>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A359B8: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A359BC: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A359C0: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 000000A359C4: BF895FF7
	v_dual_mov_b32 v1, v16 :: v_dual_mov_b32 v2, v15           // 000000A359C8: CA100110 0102010F
	s_waitcnt vmcnt(7)                                         // 000000A359D0: BF891FF7
	v_dual_mov_b32 v3, v14 :: v_dual_mov_b32 v4, v13           // 000000A359D4: CA10010E 0304010D
	v_dual_mov_b32 v5, v12 :: v_dual_mov_b32 v6, v11           // 000000A359DC: CA10010C 0506010B
	s_waitcnt vmcnt(0)                                         // 000000A359E4: BF8903F7
	v_dual_mov_b32 v8, v9 :: v_dual_mov_b32 v17, v10           // 000000A359E8: CA100109 0810010A
	s_mov_b32 s0, 0x76543210                                   // 000000A359F0: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A359F8: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000A359FC: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000A35A08: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000A35A14: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000A35A20: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000A35A2C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000A35A38: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000A35A44: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000A35A50: D65C0011 03FC0111 FEDCBA98
	.long 0xd44c0000                                           // 000000A35A5C: D44C0000
	v_cndmask_b32_e32 v1, 16, v25, vcc_lo                      // 000000A35A60: 02023290
	s_barrier                                                  // 000000A35A64: BFBD0000
	buffer_gl0_inv                                             // 000000A35A68: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000A35A70: BE812000
	s_cbranch_execz 21                                         // 000000A35A74: BFA50015 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1acc>
	v_lshl_or_b32 v7, v24, 9, v7                               // 000000A35A78: D6560007 041D1318
	v_add_f32_e32 v10, v10, v17                                // 000000A35A80: 0614230A
	v_dual_add_f32 v1, v16, v1 :: v_dual_add_f32 v2, v15, v2   // 000000A35A84: C9080310 0102050F
	v_dual_add_f32 v3, v14, v3 :: v_dual_add_f32 v4, v13, v4   // 000000A35A8C: C908070E 0304090D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A35A94: BF870004
	v_add_nc_u32_e32 v7, 0x5400, v7                            // 000000A35A98: 4A0E0EFF 00005400
	v_dual_add_f32 v5, v12, v5 :: v_dual_add_f32 v6, v11, v6   // 000000A35AA0: C9080B0C 05060D0B
	v_add_f32_e32 v8, v9, v8                                   // 000000A35AA8: 06101109
	ds_store_2addr_b32 v7, v1, v2 offset0:128 offset1:144      // 000000A35AAC: D8389080 00020107
	ds_store_2addr_b32 v7, v3, v4 offset0:160 offset1:176      // 000000A35AB4: D838B0A0 00040307
	ds_store_2addr_b32 v7, v5, v6 offset0:192 offset1:208      // 000000A35ABC: D838D0C0 00060507
	ds_store_2addr_b32 v7, v8, v10 offset0:224 offset1:240     // 000000A35AC4: D838F0E0 000A0807
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A35ACC: 8C7E017E
	.long 0xd44c0001                                           // 000000A35AD0: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000A35AD4: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000A35ADC: BF89FC07
	s_barrier                                                  // 000000A35AE0: BFBD0000
	buffer_gl0_inv                                             // 000000A35AE4: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000A35AEC: BE832001
	s_cbranch_execnz 7                                         // 000000A35AF0: BFA60007 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1b10>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A35AF4: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 000000A35AF8: BF048209
	s_mov_b32 s3, -1                                           // 000000A35AFC: BE8300C1
	s_cbranch_scc0 33                                          // 000000A35B00: BFA10021 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1b88>
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000A35B04: 8B6A037E
	s_cbranch_vccnz 155                                        // 000000A35B08: BFA4009B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d78>
	s_branch 518                                               // 000000A35B0C: BFA00206 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2328>
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000A35B10: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:86 offset1:88// 000000A35B14: D8E05856 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:90 offset1:92// 000000A35B1C: D8E05C5A 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:94 offset1:96// 000000A35B24: D8E0605E 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000A35B2C: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000A35B30: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A35B34: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000A35B38: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000A35B3C: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000A35B40: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:98 offset1:100// 000000A35B44: D8E06462 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000A35B4C: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000A35B50: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A35B54: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000A35B58: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000A35B5C: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000A35B60: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A35B64: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000A35B68: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000A35B6C: 06020501
	ds_store_b32 v7, v1 offset:26112                           // 000000A35B70: D8346600 00000107
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A35B78: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 000000A35B7C: BF048209
	s_mov_b32 s3, -1                                           // 000000A35B80: BE8300C1
	s_cbranch_scc1 65503                                       // 000000A35B84: BFA2FFDF <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1b04>
	s_waitcnt lgkmcnt(0)                                       // 000000A35B88: BF89FC07
	s_barrier                                                  // 000000A35B8C: BFBD0000
	buffer_gl0_inv                                             // 000000A35B90: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000A35B98: BE832001
	s_cbranch_execz 17                                         // 000000A35B9C: BFA50011 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1be4>
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000A35BA0: 30020082
	s_mul_hi_i32 s5, s30, s49                                  // 000000A35BA4: 9705311E
	s_mul_i32 s4, s30, s49                                     // 000000A35BA8: 9604311E
	s_lshl_b32 s6, s10, 7                                      // 000000A35BAC: 8406870A
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000A35BB0: 84848204
	ds_load_b32 v2, v1 offset:26112                            // 000000A35BB4: D8D86600 02000001
	s_ashr_i32 s7, s6, 31                                      // 000000A35BBC: 86079F06
	s_add_u32 s8, s44, s4                                      // 000000A35BC0: 8008042C
	s_addc_u32 s24, s45, s5                                    // 000000A35BC4: 8218052D
	s_lshl_b64 s[4:5], s[6:7], 2                               // 000000A35BC8: 84848206
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A35BCC: BF870009
	s_add_u32 s4, s8, s4                                       // 000000A35BD0: 80040408
	s_addc_u32 s5, s24, s5                                     // 000000A35BD4: 82050518
	s_waitcnt lgkmcnt(0)                                       // 000000A35BD8: BF89FC07
	global_store_b32 v1, v2, s[4:5]                            // 000000A35BDC: DC6A0000 00040201
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A35BE4: 8C7E037E
	.long 0xd44a0003                                           // 000000A35BE8: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000A35BEC: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000A35BF0: BC7C0000
	buffer_gl1_inv                                             // 000000A35BF4: E0B00000 00000000
	buffer_gl0_inv                                             // 000000A35BFC: E0AC0000 00000000
	s_barrier                                                  // 000000A35C04: BFBD0000
	buffer_gl0_inv                                             // 000000A35C08: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 000000A35C10: BE842003
	s_cbranch_execz 29                                         // 000000A35C14: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1c8c>
	s_mov_b32 s6, exec_lo                                      // 000000A35C18: BE86007E
	s_mov_b32 s5, exec_lo                                      // 000000A35C1C: BE85007E
	.long 0xd71f0001                                           // 000000A35C20: D71F0001
	v_cndmask_b32_e32 v0, s6, v128, vcc_lo                     // 000000A35C24: 02010006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A35C28: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000A35C2C: 7D940280
	s_cbranch_execz 9                                          // 000000A35C30: BFA50009 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1c58>
	s_lshl_b64 s[24:25], s[10:11], 2                           // 000000A35C34: 8498820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000A35C38: BF8704B9
	s_add_u32 s24, s46, s24                                    // 000000A35C3C: 8018182E
	s_addc_u32 s25, s47, s25                                   // 000000A35C40: 8219192F
	s_bcnt1_i32_b32 s6, s6                                     // 000000A35C44: BE861806
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s6              // 000000A35C48: CA100080 02020006
	global_atomic_add_u32 v2, v2, v3, s[24:25] glc             // 000000A35C50: DCD64000 02180302
	s_or_b32 exec_lo, exec_lo, s5                              // 000000A35C58: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 000000A35C5C: BF8903F7
	v_readfirstlane_b32 s5, v2                                 // 000000A35C60: 7E0A0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A35C64: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s5, v1       // 000000A35C68: CA200080 02000205
	s_add_i32 s5, s9, -1                                       // 000000A35C70: 8105C109
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000A35C74: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s5, v1                            // 000000A35C78: 7C940205
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000A35C7C: D5010001 01A90280
	ds_store_b32 v2, v1 offset:27136                           // 000000A35C84: D8346A00 00000102
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A35C8C: 8C7E047E
	v_mov_b32_e32 v1, 0                                        // 000000A35C90: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000A35C94: BF89FC07
	s_barrier                                                  // 000000A35C98: BFBD0000
	buffer_gl0_inv                                             // 000000A35C9C: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:27136                            // 000000A35CA4: D8D86A00 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000A35CAC: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000A35CB0: 7C940280
	s_cbranch_vccnz 47                                         // 000000A35CB4: BFA4002F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d74>
	buffer_gl1_inv                                             // 000000A35CB8: E0B00000 00000000
	buffer_gl0_inv                                             // 000000A35CC0: E0AC0000 00000000
	s_and_saveexec_b32 s6, s1                                  // 000000A35CC8: BE862001
	s_cbranch_execz 29                                         // 000000A35CCC: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d44>
	s_lshl_b32 s4, s10, 7                                      // 000000A35CD0: 8404870A
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 000000A35CD4: CA220080 04020082
	s_ashr_i32 s5, s4, 31                                      // 000000A35CDC: 86059F04
	s_ashr_i32 s25, s49, 31                                    // 000000A35CE0: 86199F31
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000A35CE4: 84848204
	s_mov_b32 s24, s49                                         // 000000A35CE8: BE980031
	s_add_u32 s1, s44, s4                                      // 000000A35CEC: 8001042C
	s_addc_u32 s4, s45, s5                                     // 000000A35CF0: 8204052D
	.long 0xd7000101                                           // 000000A35CF4: D7000101
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 000000A35CF8: 02020601
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A35CFC: BF870001
	v_add_co_ci_u32_e64 v2, null, s4, 0, s1                    // 000000A35D00: D5207C02 00050004
	s_lshl_b64 s[4:5], s[24:25], 2                             // 000000A35D08: 84848218
	global_load_b32 v5, v[1:2], off glc                        // 000000A35D0C: DC524000 057C0001
	.long 0xd7006a01                                           // 000000A35D14: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000A35D18: 02000901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000A35D1C: BF8704A1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000A35D20: D5207C02 01AA0405
	s_add_i32 s9, s9, -1                                       // 000000A35D28: 8109C109
	s_cmp_eq_u32 s9, 0                                         // 000000A35D2C: BF068009
	s_waitcnt vmcnt(0)                                         // 000000A35D30: BF8903F7
	v_add_f32_e32 v4, v4, v5                                   // 000000A35D34: 06080B04
	s_cbranch_scc0 65524                                       // 000000A35D38: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d0c>
	ds_store_b32 v3, v4 offset:26112                           // 000000A35D3C: D8346600 00000403
	s_or_b32 exec_lo, exec_lo, s6                              // 000000A35D44: 8C7E067E
	s_and_saveexec_b32 s1, s3                                  // 000000A35D48: BE812003
	s_cbranch_execz 6                                          // 000000A35D4C: BFA50006 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d68>
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000A35D50: 8484820A
	v_mov_b32_e32 v1, 0                                        // 000000A35D54: 7E020280
	s_add_u32 s4, s46, s4                                      // 000000A35D58: 8004042E
	s_addc_u32 s5, s47, s5                                     // 000000A35D5C: 8205052F
	global_store_b32 v1, v1, s[4:5]                            // 000000A35D60: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A35D68: 8C7E017E
	s_cbranch_execnz 2                                         // 000000A35D6C: BFA60002 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d78>
	s_branch 365                                               // 000000A35D70: BFA0016D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2328>
	s_branch 364                                               // 000000A35D74: BFA0016C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2328>
	v_cmp_eq_u32_e32 vcc_lo, 0, v24                            // 000000A35D78: 7C943080
	s_cmp_gt_i32 s48, 0                                        // 000000A35D7C: BF028030
	s_waitcnt lgkmcnt(0)                                       // 000000A35D80: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000A35D84: BC7C0000
	s_cselect_b32 s1, -1, 0                                    // 000000A35D88: 980180C1
	s_barrier                                                  // 000000A35D8C: BFBD0000
	s_and_b32 s1, vcc_lo, s1                                   // 000000A35D90: 8B01016A
	buffer_gl0_inv                                             // 000000A35D94: E0AC0000 00000000
	s_and_saveexec_b32 s4, s1                                  // 000000A35D9C: BE842001
	s_cbranch_execz 352                                        // 000000A35DA0: BFA50160 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2324>
	v_and_b32_e32 v1, 15, v0                                   // 000000A35DA4: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A35DA8: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000A35DAC: 30040282
	v_add_nc_u32_e32 v8, 0x6400, v2                            // 000000A35DB0: 4A1004FF 00006400
	ds_load_2addr_b32 v[2:3], v8 offset0:128 offset1:144       // 000000A35DB8: D8DC9080 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:160 offset1:176       // 000000A35DC0: D8DCB0A0 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:192 offset1:208       // 000000A35DC8: D8DCD0C0 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:224 offset1:240       // 000000A35DD0: D8DCF0E0 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000A35DD8: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 000000A35DDC: 36160082
	s_waitcnt lgkmcnt(3)                                       // 000000A35DE0: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 000000A35DE4: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000A35DEC: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000A35DF0: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000A35DF8: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000A35DFC: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000A35E04: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000A35E08: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000A35E10: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000A35E18: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A35E1C: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000A35E20: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 000000A35E28: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000A35E30: 7C941480
	.long 0xd44a0001                                           // 000000A35E34: D44A0001
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 000000A35E38: 02021680
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000A35E3C: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000A35E44: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000A35E48: 08101D09
	.long 0xd44a0003                                           // 000000A35E4C: D44A0003
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000A35E50: 02021880
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A35E54: BF870003
	v_dual_add_f32 v9, v13, v4 :: v_dual_sub_f32 v10, v2, v6   // 000000A35E58: C90A090D 090A0D02
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000A35E60: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000A35E68: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000A35E6C: 060A0D02
	v_mov_b32_dpp v2, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A35E70: 7E0402FA FF016107
	v_cndmask_b32_e64 v6, -v7, v7, vcc_lo                      // 000000A35E78: D5010006 21AA0F07
	v_mov_b32_dpp v7, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A35E80: 7E0E02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000A35E88: D5010009 21AA1309
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A35E90: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000A35E98: D5010005 21AA0B05
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A35EA0: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000A35EA8: D501000D 21AA1B0D
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A35EB0: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000A35EB8: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A35EC0: 7E2202FA FF016104
	v_cndmask_b32_e64 v18, -v4, v4, vcc_lo                     // 000000A35EC8: D5010012 21AA0904
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A35ED0: 7E2602FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 000000A35ED8: D5010014 21AA0703
	v_dual_add_f32 v3, v9, v7 :: v_dual_add_f32 v2, v6, v2     // 000000A35EE0: C9080F09 03020506
	v_dual_add_f32 v4, v5, v15 :: v_dual_add_f32 v7, v8, v16   // 000000A35EE8: C9081F05 04062108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A35EF0: BF870192
	v_cndmask_b32_e64 v8, -v3, v3, s1                          // 000000A35EF4: D5010008 20060703
	v_mov_b32_dpp v6, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A35EFC: 7E0C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000A35F04: D5010002 20060502
	v_mov_b32_dpp v3, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A35F0C: 7E0602FA FF016203
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A35F14: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A35F1C: D5010004 20060904
	v_add_f32_e32 v5, v13, v14                                 // 000000A35F24: 060A1D0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A35F28: BF870224
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v8, v3     // 000000A35F2C: C9080D02 02020708
	v_mov_b32_dpp v13, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A35F34: 7E1A02FA FF016207
	v_add_f32_e32 v4, v4, v11                                  // 000000A35F3C: 06081704
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A35F40: BF870004
	v_mov_b32_dpp v9, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A35F44: 7E1202FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000A35F4C: D5010005 20060B05
	v_mov_b32_dpp v6, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A35F54: 7E0C02FA FF016402
	v_cndmask_b32_e64 v8, -v3, v3, s3                          // 000000A35F5C: D5010008 200E0703
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000A35F64: D5010002 200E0502
	v_mov_b32_dpp v11, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A35F6C: 7E1602FA FF016403
	v_add_f32_e32 v5, v5, v9                                   // 000000A35F74: 060A1305
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A35F78: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000A35F80: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A35F88: BF870214
	v_dual_add_f32 v3, v2, v6 :: v_dual_add_f32 v6, v8, v11    // 000000A35F8C: C9080D02 03061708
	v_mov_b32_dpp v8, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A35F94: 7E1002FA FF016405
	v_cndmask_b32_e64 v11, -v5, v5, s3                         // 000000A35F9C: D501000B 200E0B05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A35FA4: BF870004
	v_add_f32_e32 v4, v4, v9                                   // 000000A35FA8: 06081304
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A35FAC: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000A35FB4: D501000A 21AA150A
	v_add_f32_e32 v12, v18, v17                                // 000000A35FBC: 06182312
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000A35FC0: D5010007 20060F07
	v_add_f32_e32 v14, v20, v19                                // 000000A35FC8: 061C2714
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A35FCC: 7E0402FA FF016803
	v_add_f32_e32 v9, v10, v9                                  // 000000A35FD4: 0612130A
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A35FD8: 7E0A02FA FF016806
	v_add_f32_e32 v13, v7, v13                                 // 000000A35FE0: 061A1B07
	v_mov_b32_dpp v15, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A35FE4: 7E1E02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000A35FEC: D501000E 20061D0E
	v_mov_b32_dpp v16, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A35FF4: 7E2002FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A35FFC: D5010009 20061309
	v_add_f32_e32 v7, v11, v8                                  // 000000A36004: 060E110B
	v_mov_b32_dpp v10, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A36008: 7E1402FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000A36010: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A36018: BF870114
	v_dual_add_f32 v8, v14, v15 :: v_dual_add_f32 v9, v9, v16  // 000000A3601C: C9081F0E 08082109
	v_add_f32_e32 v10, v12, v10                                // 000000A36024: 0614150C
	v_mov_b32_dpp v11, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A36028: 7E1602FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000A36030: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A36038: BF870004
	v_mov_b32_dpp v15, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A3603C: 7E1E02FA FF016408
	v_mov_b32_dpp v17, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A36044: 7E2202FA FF016409
	v_mov_b32_dpp v12, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A3604C: 7E1802FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000A36054: D501000A 200E150A
	v_cndmask_b32_e64 v18, -v8, v8, s3                         // 000000A3605C: D5010012 200E1108
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A36064: D5010009 200E1309
	v_add_f32_e32 v14, v13, v11                                // 000000A3606C: 061C170D
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A36070: 7E1002FA FF016807
	v_add_f32_e32 v16, v10, v12                                // 000000A36078: 0620190A
	v_add_f32_e32 v15, v18, v15                                // 000000A3607C: 061E1F12
	v_add_f32_e32 v17, v9, v17                                 // 000000A36080: 06222309
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A36084: 7E1202FA FF016804
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A3608C: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A36094: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A3609C: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A360A4: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 000000A360AC: 8B7E007E
	s_cbranch_execz 156                                        // 000000A360B0: BFA5009C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2324>
	v_lshl_or_b32 v18, s10, 7, v1                              // 000000A360B4: D6560012 04050E0A
	v_and_b32_e32 v1, 8, v0                                    // 000000A360BC: 36020088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A360C0: BF870092
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000A360C4: 3426249F
	.long 0xd73c0012                                           // 000000A360C8: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000A360CC: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A360D0: BF870091
	.long 0xd7006a14                                           // 000000A360D4: D7006A14
	v_cndmask_b32_e32 v1, s36, v18, vcc_lo                     // 000000A360D8: 02022424
	v_add_co_ci_u32_e64 v21, null, s37, v19, vcc_lo            // 000000A360DC: D5207C15 01AA2625
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000A360E4: 7C940280
	s_clause 0x7                                               // 000000A360E8: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000A360EC: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000A360F4: DC820000 177C0014
	global_load_d16_b16 v26, v[20:21], off offset:64           // 000000A360FC: DC820040 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:96           // 000000A36104: DC820060 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:128          // 000000A3610C: DC820080 1C7C0014
	global_load_d16_b16 v29, v[20:21], off offset:160          // 000000A36114: DC8200A0 1D7C0014
	global_load_d16_b16 v30, v[20:21], off offset:192          // 000000A3611C: DC8200C0 1E7C0014
	global_load_d16_b16 v20, v[20:21], off offset:224          // 000000A36124: DC8200E0 147C0014
	.long 0x7f2a3880                                           // 000000A3612C: 7F2A3880
	v_cndmask_b32_e64 v1, -v6, v6, vcc_lo                      // 000000A36130: D5010001 21AA0D06
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000A36138: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000A36140: D501000E 21AA1D0E
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000A36148: D5010003 21AA0703
	s_waitcnt vmcnt(7)                                         // 000000A36150: BF891FF7
	.long 0x7f2c3995                                           // 000000A36154: 7F2C3995
	v_add_f32_e32 v1, v1, v5                                   // 000000A36158: 06020B01
	v_cndmask_b32_e64 v5, -v7, v7, vcc_lo                      // 000000A3615C: D5010005 21AA0F07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 000000A36164: D5010007 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000A3616C: D5010010 21AA2311
	v_add_f32_e32 v4, v4, v9                                   // 000000A36174: 06081304
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000A36178: D501000F 21AA1F0F
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v8, v14, v10   // 000000A36180: C9081105 0508150E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A36188: BF8701A3
	v_dual_mul_f32 v17, 0x3db504f3, v1 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000A3618C: C8C602FF 110408FF 3DB504F3
	v_dual_add_f32 v3, v3, v2 :: v_dual_add_f32 v10, v16, v13  // 000000A36198: C9080503 030A1B10
	v_dual_add_f32 v7, v7, v11 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000A361A0: C9061707 070810FF 3DB504F3
	.long 0x7f0c3995                                           // 000000A361AC: 7F0C3995
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A361B0: BF870003
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 000000A361B4: 100606FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000A361BC: BF8903F7
	.long 0x7f283995                                           // 000000A361C0: 7F283995
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v10, 0x3db504f3, v10// 000000A361C4: C8C60EFF 070A14FF 3DB504F3
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000A361D0: 100A0AFF 3DB504F3
	.long 0x7f2e3995                                           // 000000A361D8: 7F2E3995
	.long 0xd7006a01                                           // 000000A361DC: D7006A01
	v_cndmask_b32_e32 v1, s42, v18, vcc_lo                     // 000000A361E0: 0202242A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A361E4: BF870221
	v_add_co_ci_u32_e64 v2, null, s43, v19, vcc_lo             // 000000A361E8: D5207C02 01AA262B
	v_fma_mix_f32 v11, v22, v17, neg(0) op_sel_hi:[1,0,0]      // 000000A361F0: CC20000B 8A022316
	v_fma_mix_f32 v3, v23, v3, neg(0) op_sel_hi:[1,0,0]        // 000000A361F8: CC200003 8A020717
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 000000A36200: CC200005 8A020B1A
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 000000A36208: CC200004 8A02091B
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000A36210: CC200008 8A02111C
	.long 0x7e2a398b                                           // 000000A36218: 7E2A398B
	v_add_f32_e32 v9, v15, v12                                 // 000000A3621C: 0612190F
	v_fma_mix_f32 v7, v29, v7, neg(0) op_sel_hi:[1,0,0]        // 000000A36220: CC200007 8A020F1D
	v_fma_mix_f32 v10, v20, v10, neg(0) op_sel_hi:[1,0,0]      // 000000A36228: CC20000A 8A021514
	.long 0x7e0c3983                                           // 000000A36230: 7E0C3983
	v_and_b32_e32 v12, 1, v21                                  // 000000A36234: 36182A81
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000A36238: 101212FF 3DB504F3
	.long 0x7e2a3984                                           // 000000A36240: 7E2A3984
	.long 0x7e283985                                           // 000000A36244: 7E283985
	.long 0x7e2c3988                                           // 000000A36248: 7E2C3988
	v_and_b32_e32 v6, 1, v6                                    // 000000A3624C: 360C0C81
	v_fma_mix_f32 v9, v30, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A36250: CC200009 8A02131E
	v_and_b32_e32 v13, 1, v21                                  // 000000A36258: 361A2A81
	.long 0x7e2a3987                                           // 000000A3625C: 7E2A3987
	v_and_b32_e32 v14, 1, v20                                  // 000000A36260: 361C2881
	v_and_b32_e32 v15, 1, v22                                  // 000000A36264: 361E2C81
	.long 0x7e2e3989                                           // 000000A36268: 7E2E3989
	v_add3_u32 v3, v3, v6, 0x7fff                              // 000000A3626C: D6550003 03FE0D03 00007FFF
	v_and_b32_e32 v16, 1, v21                                  // 000000A36278: 36202A81
	.long 0x7e2a398a                                           // 000000A3627C: 7E2A398A
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000A36280: D655000B 03FE190B 00007FFF
	v_and_b32_e32 v17, 1, v23                                  // 000000A3628C: 36222E81
	v_add3_u32 v5, v5, v14, 0x7fff                             // 000000A36290: D6550005 03FE1D05 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 000000A3629C: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v6, 1, v21                                   // 000000A362A8: 360C2A81
	v_add3_u32 v8, v8, v15, 0x7fff                             // 000000A362AC: D6550008 03FE1F08 00007FFF
	v_add3_u32 v9, v9, v17, 0x7fff                             // 000000A362B8: D6550009 03FE2309 00007FFF
	v_add3_u32 v7, v7, v16, 0x7fff                             // 000000A362C4: D6550007 03FE2107 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A362D0: BF870004
	v_add3_u32 v6, v10, v6, 0x7fff                             // 000000A362D4: D6550006 03FE0D0A 00007FFF
	s_clause 0x7                                               // 000000A362E0: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 000000A362E4: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v11, off offset:32         // 000000A362EC: DC960020 007C0B01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 000000A362F4: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 000000A362FC: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 000000A36304: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v7, off offset:160         // 000000A3630C: DC9600A0 007C0701
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 000000A36314: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v6, off offset:224         // 000000A3631C: DC9600E0 007C0601
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A36324: 8C7E047E
	s_mov_b32 s4, 0                                            // 000000A36328: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A3632C: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000A36330: 8B6A047E
	s_cbranch_vccz 3751                                        // 000000A36334: BFA30EA7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x5dd4>
	s_mul_hi_i32 s0, s2, 0x66666667                            // 000000A36338: 9700FF02 66666667
	v_mov_b32_e32 v1, 0                                        // 000000A36340: 7E020280
	s_lshr_b32 s1, s0, 31                                      // 000000A36344: 85019F00
	s_ashr_i32 s0, s0, 1                                       // 000000A36348: 86008100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A3634C: BF870499
	s_add_i32 s10, s0, s1                                      // 000000A36350: 810A0100
	s_ashr_i32 s11, s10, 31                                    // 000000A36354: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A36358: BF870499
	s_lshl_b64 s[0:1], s[10:11], 2                             // 000000A3635C: 8480820A
	s_add_u32 s0, s16, s0                                      // 000000A36360: 80000010
	s_addc_u32 s1, s17, s1                                     // 000000A36364: 82010111
	global_load_b32 v1, v1, s[0:1]                             // 000000A36368: DC520000 01000001
	s_mov_b32 s1, exec_lo                                      // 000000A36370: BE81007E
	s_waitcnt vmcnt(0)                                         // 000000A36374: BF8903F7
	v_readfirstlane_b32 s3, v1                                 // 000000A36378: 7E060501
	v_cmpx_gt_u32_e32 0x140, v0                                // 000000A3637C: 7D9800FF 00000140
	s_cbranch_execz 50                                         // 000000A36384: BFA50032 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2450>
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 000000A36388: 9700FF02 51EB851F
	v_lshlrev_b32_e32 v4, 4, v0                                // 000000A36390: 30080084
	s_lshr_b32 s4, s0, 31                                      // 000000A36394: 85049F00
	s_ashr_i32 s0, s0, 4                                       // 000000A36398: 86008400
	v_or_b32_e32 v3, 0xffffff00, v0                            // 000000A3639C: 380600FF FFFFFF00
	s_add_i32 s0, s0, s4                                       // 000000A363A4: 81000400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000A363A8: BF8700D9
	s_mul_i32 s4, s0, 0x1400                                   // 000000A363AC: 9604FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 000000A363B4: 9700FF00 00001400
	s_add_u32 s4, s14, s4                                      // 000000A363BC: 8004040E
	s_addc_u32 s0, s15, s0                                     // 000000A363C0: 8200000F
	.long 0xd7000401                                           // 000000A363C4: D7000401
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 000000A363C8: 02020804
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 000000A363CC: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 000000A363D4: BE840080
	s_nop 0                                                    // 000000A363D8: BF800000
	s_nop 0                                                    // 000000A363DC: BF800000
	s_nop 0                                                    // 000000A363E0: BF800000
	s_nop 0                                                    // 000000A363E4: BF800000
	s_nop 0                                                    // 000000A363E8: BF800000
	s_nop 0                                                    // 000000A363EC: BF800000
	s_nop 0                                                    // 000000A363F0: BF800000
	s_nop 0                                                    // 000000A363F4: BF800000
	s_nop 0                                                    // 000000A363F8: BF800000
	s_nop 0                                                    // 000000A363FC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 000000A36400: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x100, v3                             // 000000A36408: 4A0606FF 00000100
	.long 0xd7006a01                                           // 000000A36410: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 000000A36414: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A3641C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000A36420: D5207C02 01AA0480
	.long 0xd4490000                                           // 000000A36428: D4490000
	v_cndmask_b32_e32 v1, 63, v3, vcc_lo                       // 000000A3642C: 020206BF
	s_or_b32 s4, s0, s4                                        // 000000A36430: 8C040400
	s_waitcnt vmcnt(0)                                         // 000000A36434: BF8903F7
	ds_store_b128 v4, v[5:8]                                   // 000000A36438: DB7C0000 00000504
	v_add_nc_u32_e32 v4, 0x1000, v4                            // 000000A36440: 4A0808FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A36448: 917E047E
	s_cbranch_execnz 65516                                     // 000000A3644C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2400>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A36450: 8C7E017E
	v_mul_u32_u24_e32 v18, 20, v24                             // 000000A36454: 16243094
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v26, 2, v25     // 000000A36458: CA220080 011A3282
	s_mul_i32 s0, s10, -5                                      // 000000A36460: 9600C50A
	s_mul_hi_i32 s1, s3, 0x190000                              // 000000A36464: 9701FF03 00190000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A3646C: BF870112
	v_min_u32_e32 v19, 0x8c, v18                               // 000000A36470: 262624FF 0000008C
	v_mov_b32_e32 v16, v1                                      // 000000A36478: 7E200301
	v_mov_b32_e32 v2, v1                                       // 000000A3647C: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000A36480: 7E060301
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A36484: BF870004
	v_dual_mov_b32 v4, v1 :: v_dual_add_nc_u32 v27, 20, v19    // 000000A36488: CA200101 041A2694
	v_mov_b32_e32 v5, v1                                       // 000000A36490: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000A36494: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000A36498: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 000000A3649C: 7E100301
	v_mov_b32_e32 v9, v1                                       // 000000A364A0: 7E120301
	v_mov_b32_e32 v10, v1                                      // 000000A364A4: 7E140301
	v_mov_b32_e32 v11, v1                                      // 000000A364A8: 7E160301
	v_mov_b32_e32 v12, v1                                      // 000000A364AC: 7E180301
	v_mov_b32_e32 v13, v1                                      // 000000A364B0: 7E1A0301
	v_mov_b32_e32 v14, v1                                      // 000000A364B4: 7E1C0301
	v_mov_b32_e32 v15, v1                                      // 000000A364B8: 7E1E0301
	v_mov_b32_e32 v17, v16                                     // 000000A364BC: 7E220310
	v_cmp_lt_u32_e32 vcc_lo, v18, v27                          // 000000A364C0: 7C923712
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A364C4: BF870003
	v_mov_b32_e32 v16, v15                                     // 000000A364C8: 7E20030F
	v_mov_b32_e32 v15, v14                                     // 000000A364CC: 7E1E030E
	v_mov_b32_e32 v14, v13                                     // 000000A364D0: 7E1C030D
	v_mov_b32_e32 v13, v12                                     // 000000A364D4: 7E1A030C
	v_mov_b32_e32 v12, v11                                     // 000000A364D8: 7E18030B
	v_mov_b32_e32 v11, v10                                     // 000000A364DC: 7E16030A
	v_mov_b32_e32 v10, v9                                      // 000000A364E0: 7E140309
	v_mov_b32_e32 v9, v8                                       // 000000A364E4: 7E120308
	v_mov_b32_e32 v8, v7                                       // 000000A364E8: 7E100307
	v_mov_b32_e32 v7, v6                                       // 000000A364EC: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 000000A364F0: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000A364F4: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000A364F8: 7E080303
	v_mov_b32_e32 v3, v2                                       // 000000A364FC: 7E060302
	v_mov_b32_e32 v2, v1                                       // 000000A36500: 7E040301
	s_add_i32 s2, s0, s2                                       // 000000A36504: 81020200
	s_mul_i32 s6, s3, 0x190000                                 // 000000A36508: 9606FF03 00190000
	s_mul_hi_i32 s5, s2, 0x50000                               // 000000A36510: 9705FF02 00050000
	s_mul_i32 s7, s2, 0x50000                                  // 000000A36518: 9607FF02 00050000
	s_waitcnt lgkmcnt(0)                                       // 000000A36520: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000A36524: BC7C0000
	s_barrier                                                  // 000000A36528: BFBD0000
	buffer_gl0_inv                                             // 000000A3652C: E0AC0000 00000000
	s_and_saveexec_b32 s4, vcc_lo                              // 000000A36534: BE84206A
	s_cbranch_execz 49                                         // 000000A36538: BFA50031 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2600>
	v_mul_u32_u24_e32 v2, 0xa000, v24                          // 000000A3653C: 160430FF 0000A000
	s_add_u32 s0, s12, s6                                      // 000000A36544: 8000060C
	s_addc_u32 s8, s13, s1                                     // 000000A36548: 8208010D
	s_add_u32 s0, s0, s7                                       // 000000A3654C: 80000700
	s_addc_u32 s8, s8, s5                                      // 000000A36550: 82080508
	.long 0xd7000002                                           // 000000A36554: D7000002
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000A36558: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A3655C: BF870111
	v_add_co_ci_u32_e64 v3, null, s8, 0, s0                    // 000000A36560: D5207C03 00010008
	.long 0xd7000014                                           // 000000A36568: D7000014
	v_cndmask_b32_e32 v1, v2, v26, vcc_lo                      // 000000A3656C: 02023502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A36570: BF870001
	v_add_co_ci_u32_e64 v21, null, 0, v3, s0                   // 000000A36574: D5207C15 00020680
	s_clause 0xf                                               // 000000A3657C: BF85000F
	global_load_b32 v2, v[20:21], off                          // 000000A36580: DC520000 027C0014
	global_load_b32 v3, v[20:21], off offset:128               // 000000A36588: DC520080 037C0014
	global_load_b32 v4, v[20:21], off offset:256               // 000000A36590: DC520100 047C0014
	global_load_b32 v5, v[20:21], off offset:384               // 000000A36598: DC520180 057C0014
	global_load_b32 v6, v[20:21], off offset:512               // 000000A365A0: DC520200 067C0014
	global_load_b32 v7, v[20:21], off offset:640               // 000000A365A8: DC520280 077C0014
	global_load_b32 v8, v[20:21], off offset:768               // 000000A365B0: DC520300 087C0014
	global_load_b32 v9, v[20:21], off offset:896               // 000000A365B8: DC520380 097C0014
	global_load_b32 v10, v[20:21], off offset:1024             // 000000A365C0: DC520400 0A7C0014
	global_load_b32 v11, v[20:21], off offset:1152             // 000000A365C8: DC520480 0B7C0014
	global_load_b32 v12, v[20:21], off offset:1280             // 000000A365D0: DC520500 0C7C0014
	global_load_b32 v13, v[20:21], off offset:1408             // 000000A365D8: DC520580 0D7C0014
	global_load_b32 v14, v[20:21], off offset:1536             // 000000A365E0: DC520600 0E7C0014
	global_load_b32 v15, v[20:21], off offset:1664             // 000000A365E8: DC520680 0F7C0014
	global_load_b32 v16, v[20:21], off offset:1792             // 000000A365F0: DC520700 107C0014
	global_load_b32 v17, v[20:21], off offset:1920             // 000000A365F8: DC520780 117C0014
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A36600: 8C7E047E
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v30, 0             // 000000A36604: CA100080 1D1E0080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 000000A3660C: CA100080 1F200080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 000000A36614: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000A3661C: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000A36624: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 000000A3662C: CA100080 27280080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 000000A36634: CA100080 292A0080
	v_mov_b32_e32 v28, 0                                       // 000000A3663C: 7E380280
	s_and_saveexec_b32 s4, vcc_lo                              // 000000A36640: BE84206A
	s_cbranch_execz 2095                                       // 000000A36644: BFA5082F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4704>
	v_dual_mov_b32 v28, 0 :: v_dual_lshlrev_b32 v1, 5, v25     // 000000A36648: CA220080 1C003285
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v23, 11, v18   // 000000A36650: CA220080 2816248B
	s_add_u32 s0, s6, s7                                       // 000000A36658: 80000706
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A3665C: BF870122
	v_dual_mov_b32 v41, 0 :: v_dual_add_nc_u32 v20, 0x3f0, v1  // 000000A36660: CA200080 291402FF 000003F0
	s_addc_u32 s1, s1, s5                                      // 000000A3666C: 82010501
	.long 0xd7000017                                           // 000000A36670: D7000017
	v_cndmask_b32_e32 v1, s0, v23, vcc_lo                      // 000000A36674: 02022E00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A36678: BF870242
	v_lshrrev_b32_e32 v22, 5, v20                              // 000000A3667C: 322C2885
	v_dual_mov_b32 v39, 0 :: v_dual_and_b32 v20, 0x7e0, v20    // 000000A36680: CA240080 271428FF 000007E0
	v_cmp_eq_u32_e32 vcc_lo, 0, v25                            // 000000A3668C: 7C943280
	v_add_co_ci_u32_e64 v29, null, s1, 0, s0                   // 000000A36690: D5207C1D 00010001
	v_subrev_nc_u32_e32 v22, 32, v22                           // 000000A36698: 4E2C2CA0
	v_mul_u32_u24_e32 v43, 0x840, v24                          // 000000A3669C: 165630FF 00000840
	v_sub_nc_u32_e32 v1, v20, v1                               // 000000A366A4: 4C020314
	v_mad_u32_u24 v44, 0x840, v24, v26                         // 000000A366A8: D60B002C 046A30FF 00000840
	v_dual_mov_b32 v42, 0 :: v_dual_and_b32 v21, 16, v0        // 000000A366B4: CA240080 2A140090
	v_cndmask_b32_e64 v20, v22, 31, vcc_lo                     // 000000A366BC: D5010014 01A93F16
	.long 0xd7000016                                           // 000000A366C4: D7000016
	v_cndmask_b32_e32 v1, v23, v26, vcc_lo                     // 000000A366C8: 02023517
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A366CC: BF870221
	v_add_co_ci_u32_e64 v23, null, 0, v29, s0                  // 000000A366D0: D5207C17 00023A80
	v_dual_mov_b32 v38, 0 :: v_dual_add_nc_u32 v45, 0xfffffc30, v1// 000000A366D8: CA200080 262C02FF FFFFFC30
	v_lshl_add_u32 v1, v20, 2, v43                             // 000000A366E4: D6460001 04AD0514
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A366EC: BF870094
	.long 0xd7000014                                           // 000000A366F0: D7000014
	v_cndmask_b32_e32 v1, s12, v22, vcc_lo                     // 000000A366F4: 02022C0C
	v_add_co_ci_u32_e64 v23, null, s13, v23, s0                // 000000A366F8: D5207C17 00022E0D
	v_lshl_or_b32 v46, v18, 5, v21                             // 000000A36700: D656002E 04550B12
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A36708: BF870093
	.long 0xd7000016                                           // 000000A3670C: D7000016
	v_cndmask_b32_e32 v1, 0x800, v20, vcc_lo                   // 000000A36710: 020228FF 00000800
	v_add_co_ci_u32_e64 v23, null, 0, v23, s0                  // 000000A36718: D5207C17 00022E80
	v_sub_nc_u32_e32 v47, 0, v19                               // 000000A36720: 4C5E2680
	v_dual_mov_b32 v37, 0 :: v_dual_add_nc_u32 v48, 1, v18     // 000000A36724: CA200080 25302481
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v49, 0x1400, v1 // 000000A3672C: CA200080 243002FF 00001400
	v_dual_mov_b32 v35, 0 :: v_dual_add_nc_u32 v50, 0x1484, v1 // 000000A36738: CA200080 233202FF 00001484
	v_dual_mov_b32 v34, 0 :: v_dual_add_nc_u32 v51, 0x1508, v1 // 000000A36744: CA200080 223202FF 00001508
	v_dual_mov_b32 v33, 0 :: v_dual_add_nc_u32 v52, 0x158c, v1 // 000000A36750: CA200080 213402FF 0000158C
	v_dual_mov_b32 v32, 0 :: v_dual_add_nc_u32 v53, 0x1610, v1 // 000000A3675C: CA200080 203402FF 00001610
	v_dual_mov_b32 v31, 0 :: v_dual_add_nc_u32 v54, 0x1694, v1 // 000000A36768: CA200080 1F3602FF 00001694
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v55, 0x1718, v1 // 000000A36774: CA200080 1E3602FF 00001718
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v56, 0x179c, v1 // 000000A36780: CA200080 1D3802FF 0000179C
	v_add_nc_u32_e32 v57, 0x1820, v1                           // 000000A3678C: 4A7202FF 00001820
	v_add_nc_u32_e32 v58, 0x18a4, v1                           // 000000A36794: 4A7402FF 000018A4
	v_add_nc_u32_e32 v59, 0x1928, v1                           // 000000A3679C: 4A7602FF 00001928
	v_add_nc_u32_e32 v60, 0x19ac, v1                           // 000000A367A4: 4A7802FF 000019AC
	v_add_nc_u32_e32 v61, 0x1a30, v1                           // 000000A367AC: 4A7A02FF 00001A30
	v_add_nc_u32_e32 v62, 0x1ab4, v1                           // 000000A367B4: 4A7C02FF 00001AB4
	v_add_nc_u32_e32 v63, 0x1b38, v1                           // 000000A367BC: 4A7E02FF 00001B38
	v_add_nc_u32_e32 v64, 0x1bbc, v1                           // 000000A367C4: 4A8002FF 00001BBC
	v_add_nc_u32_e32 v65, 0x1400, v44                          // 000000A367CC: 4A8258FF 00001400
	v_dual_mov_b32 v1, 0 :: v_dual_add_nc_u32 v66, 0x1800, v44 // 000000A367D4: CA200080 014258FF 00001800
	s_mov_b32 s5, 0                                            // 000000A367E0: BE850080
	s_movk_i32 s6, 0x1eee                                      // 000000A367E4: B0061EEE
	s_branch 1732                                              // 000000A367E8: BFA006C4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x42fc>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A367EC: 8C7E017E
	ds_load_2addr_b32 v[67:68], v49 offset1:1                  // 000000A367F0: D8DC0100 43000031
	ds_load_2addr_b32 v[78:79], v65 offset1:33                 // 000000A367F8: D8DC2100 4E000041
	ds_load_2addr_b32 v[70:71], v50 offset1:1                  // 000000A36800: D8DC0100 46000032
	ds_load_b128 v[18:21], v46                                 // 000000A36808: DBFC0000 1200002E
	ds_load_2addr_b32 v[73:74], v51 offset1:1                  // 000000A36810: D8DC0100 49000033
	ds_load_2addr_b32 v[76:77], v52 offset1:1                  // 000000A36818: D8DC0100 4C000034
	v_add_nc_u32_e32 v48, 1, v48                               // 000000A36820: 4A606081
	.long 0xd7000116                                           // 000000A36824: D7000116
	v_cndmask_b32_e32 v1, 0x800, v22, vcc_lo                   // 000000A36828: 02022CFF 00000800
	v_add_nc_u32_e32 v46, 32, v46                              // 000000A36830: 4A5C5CA0
	v_add_co_ci_u32_e64 v23, null, 0, v23, s1                  // 000000A36834: D5207C17 00062E80
	s_waitcnt lgkmcnt(5)                                       // 000000A3683C: BF89FC57
	v_mov_b32_e32 v69, v67                                     // 000000A36840: 7E8A0343
	s_waitcnt lgkmcnt(4)                                       // 000000A36844: BF89FC47
	v_bfe_u32 v75, v78, 12, 16                                 // 000000A36848: D610004B 0241194E
	v_bfe_u32 v80, v78, 8, 16                                  // 000000A36850: D6100050 0241114E
	v_bfe_u32 v81, v78, 4, 16                                  // 000000A36858: D6100051 0241094E
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A36860: 369C9CFF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 000000A36868: BF89FC37
	v_mov_b32_e32 v72, v70                                     // 000000A3686C: 7E900346
	.long 0xd73d0043                                           // 000000A36870: D73D0043
	v_cndmask_b32_e32 v1, v45, v68, vcc_lo                     // 000000A36874: 0202892D
	v_bfe_u32 v70, v79, 12, 16                                 // 000000A36878: D6100046 0241194F
	v_bfe_u32 v82, v79, 8, 16                                  // 000000A36880: D6100052 0241114F
	v_bfe_u32 v83, v79, 4, 16                                  // 000000A36888: D6100053 0241094F
	v_and_b32_e32 v79, 0xffff, v79                             // 000000A36890: 369E9EFF 0000FFFF
	.long 0xd73d0044                                           // 000000A36898: D73D0044
	v_cndmask_b32_e32 v1, v45, v71, vcc_lo                     // 000000A3689C: 02028F2D
	.long 0xd72c0045                                           // 000000A368A0: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A368A4: 02028CFF 83DCD12D
	v_bfe_u32 v70, v67, 12, 16                                 // 000000A368AC: D6100046 02411943
	v_bfe_u32 v71, v67, 8, 16                                  // 000000A368B4: D6100047 02411143
	v_bfe_u32 v72, v67, 4, 16                                  // 000000A368BC: D6100048 02410943
	.long 0xd72c004b                                           // 000000A368C4: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A368C8: 020296FF 83DCD12D
	.long 0xd72c0050                                           // 000000A368D0: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A368D4: 0202A0FF 83DCD12D
	.long 0xd72c0046                                           // 000000A368DC: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A368E0: 02028CFF 83DCD12D
	.long 0xd72c0047                                           // 000000A368E8: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A368EC: 02028EFF 83DCD12D
	v_bfe_u32 v84, v68, 12, 16                                 // 000000A368F4: D6100054 02411944
	.long 0xd72c0048                                           // 000000A368FC: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A36900: 020290FF 83DCD12D
	v_bfe_u32 v85, v68, 8, 16                                  // 000000A36908: D6100055 02411144
	.long 0xd72c004e                                           // 000000A36910: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A36914: 02029CFF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A3691C: D622004B 03FD014B 00006400
	.long 0xd72c0054                                           // 000000A36928: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A3692C: 0202A8FF 83DCD12D
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A36934: D6220046 03FD0146 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A36940: D6220047 03FD0147 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A3694C: D6220050 03FD0150 00006400
	v_and_b32_e32 v75, 0xffff, v75                             // 000000A36958: 369696FF 0000FFFF
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A36960: D6220048 03FD0148 00006400
	v_and_b32_e32 v70, 0xffff, v70                             // 000000A3696C: 368C8CFF 0000FFFF
	.long 0xd72c0055                                           // 000000A36974: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A36978: 0202AAFF 83DCD12D
	.long 0xd72c0051                                           // 000000A36980: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A36984: 0202A2FF 83DCD12D
	v_lshl_or_b32 v75, v80, 16, v75                            // 000000A3698C: D656004B 052D2150
	v_sad_u8 v80, v84, 0, 0x6400                               // 000000A36994: D6220050 03FD0154 00006400
	v_lshl_or_b32 v70, v71, 16, v70                            // 000000A369A0: D6560046 05192147
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A369A8: D622004E 03FD014E 00006400
	v_bfe_u32 v86, v68, 4, 16                                  // 000000A369B4: D6100056 02410944
	v_and_b32_e32 v68, 0xffff, v68                             // 000000A369BC: 368888FF 0000FFFF
	.long 0xd72c0052                                           // 000000A369C4: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A369C8: 0202A4FF 83DCD12D
	v_pk_fma_f16 v70, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A369D0: CC0E0046 0BFC0D46 0000C931
	v_and_b32_e32 v67, 0xffff, v67                             // 000000A369DC: 368686FF 0000FFFF
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A369E4: D6220051 03FD0151 00006400
	v_lshlrev_b32_e32 v78, 16, v78                             // 000000A369F0: 309C9C90
	.long 0xd72c0056                                           // 000000A369F4: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A369F8: 0202ACFF 83DCD12D
	s_waitcnt lgkmcnt(2)                                       // 000000A36A00: BF89FC27
	v_dot2acc_f32_f16 v28, v70, v18                            // 000000A36A04: 04382546
	.long 0xd72c0043                                           // 000000A36A08: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A36A0C: 020286FF 83DCD12D
	.long 0xd72c004f                                           // 000000A36A14: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A36A18: 02029EFF 83DCD12D
	v_and_or_b32 v78, 0xffff, v81, v78                         // 000000A36A20: D657004E 053AA2FF 0000FFFF
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A36A2C: D6220045 03FD0145 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A36A38: BF870214
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A36A3C: D6220043 03FD0143 00006400
	v_sad_u8 v70, v79, 0, 0x6400                               // 000000A36A48: D6220046 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A36A54: BF870112
	v_lshlrev_b32_e32 v67, 16, v67                             // 000000A36A58: 30868690
	v_lshlrev_b32_e32 v70, 16, v70                             // 000000A36A5C: 308C8C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A36A60: BF8701B2
	v_and_or_b32 v67, 0xffff, v72, v67                         // 000000A36A64: D6570043 050E90FF 0000FFFF
	v_pk_fma_f16 v72, v75, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A36A70: CC0E0048 0BFC0D4B 0000C931
	v_sad_u8 v75, v85, 0, 0x6400                               // 000000A36A7C: D622004B 03FD0155 00006400
	v_pk_fma_f16 v67, v67, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A36A88: CC0E0043 0BFC0D43 0000C931
	v_and_b32_e32 v71, 0xffff, v80                             // 000000A36A94: 368EA0FF 0000FFFF
	v_sad_u8 v80, v86, 0, 0x6400                               // 000000A36A9C: D6220050 03FD0156 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A36AA8: BF870193
	v_dot2acc_f32_f16 v28, v67, v19                            // 000000A36AAC: 04382743
	v_lshl_or_b32 v71, v75, 16, v71                            // 000000A36AB0: D6560047 051D214B
	.long 0xd72c004b                                           // 000000A36AB8: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A36ABC: 0202A6FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A36AC4: BF870193
	v_dot2acc_f32_f16 v28, v72, v20                            // 000000A36AC8: 04382948
	v_pk_fma_f16 v71, v71, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A36ACC: CC0E0047 0BFC0D47 0000C931
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A36AD8: BF870003
	v_sad_u8 v81, v75, 0, 0x6400                               // 000000A36ADC: D6220051 03FD014B 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A36AE8: BF89FC17
	v_mov_b32_e32 v75, v73                                     // 000000A36AEC: 7E960349
	.long 0xd72c0044                                           // 000000A36AF0: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A36AF4: 020288FF 83DCD12D
	v_dot2acc_f32_f16 v42, v71, v18                            // 000000A36AFC: 04542547
	v_and_or_b32 v73, 0xffff, v81, v70                         // 000000A36B00: D6570049 051AA2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A36B0C: BF870234
	.long 0xd73d0046                                           // 000000A36B10: D73D0046
	v_cndmask_b32_e32 v1, v45, v74, vcc_lo                     // 000000A36B14: 0202952D
	v_pk_fma_f16 v71, v78, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A36B18: CC0E0047 0BFC0D4E 0000C931
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A36B24: D6220044 03FD0144 00006400
	v_pk_fma_f16 v72, v73, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A36B30: CC0E0048 0BFC0D49 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A36B3C: BF870092
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000A36B40: 30888890
	v_and_or_b32 v68, 0xffff, v80, v68                         // 000000A36B44: D6570044 0512A0FF 0000FFFF
	v_sad_u8 v80, v82, 0, 0x6400                               // 000000A36B50: D6220050 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A36B5C: BF870092
	v_pk_fma_f16 v79, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A36B60: CC0E004F 0BFC0D44 0000C931
	v_dual_dot2acc_f32_f16 v42, v79, v19 :: v_dual_and_b32 v69, 0xffff, v69// 000000A36B6C: CB24274F 2A448AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A36B78: BF8700B1
	v_lshl_or_b32 v80, v80, 16, v69                            // 000000A36B7C: D6560050 05152150
	ds_load_2addr_b32 v[68:69], v65 offset0:66 offset1:99      // 000000A36B84: D8DC6342 44000041
	v_pk_fma_f16 v67, v80, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A36B8C: CC0E0043 0BFC0D50 0000C931
	v_dot2acc_f32_f16 v42, v67, v20                            // 000000A36B98: 04542943
	v_bfe_u32 v67, v70, 12, 16                                 // 000000A36B9C: D6100043 02411946
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A36BA4: BF870251
	.long 0xd72c0043                                           // 000000A36BA8: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A36BAC: 020286FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A36BB4: BF89FC07
	v_bfe_u32 v73, v68, 12, 16                                 // 000000A36BB8: D6100049 02411944
	v_bfe_u32 v74, v68, 8, 16                                  // 000000A36BC0: D610004A 02411144
	v_bfe_u32 v75, v68, 4, 16                                  // 000000A36BC8: D610004B 02410944
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A36BD0: D6220043 03FD0143 00006400
	v_and_b32_e32 v68, 0xffff, v68                             // 000000A36BDC: 368888FF 0000FFFF
	.long 0xd72c0049                                           // 000000A36BE4: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A36BE8: 020292FF 83DCD12D
	.long 0xd72c004a                                           // 000000A36BF0: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A36BF4: 020294FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A36BFC: BF870194
	v_and_b32_e32 v79, 0xffff, v67                             // 000000A36C00: 369E86FF 0000FFFF
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A36C08: D6220049 03FD0149 00006400
	v_mov_b32_e32 v78, v76                                     // 000000A36C14: 7E9C034C
	.long 0xd72c004c                                           // 000000A36C18: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A36C1C: 020288FF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A36C24: D622004A 03FD014A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A36C30: BF870214
	v_and_b32_e32 v73, 0xffff, v73                             // 000000A36C34: 369292FF 0000FFFF
	.long 0xd73d0043                                           // 000000A36C3C: D73D0043
	v_cndmask_b32_e32 v1, v45, v77, vcc_lo                     // 000000A36C40: 02029B2D
	v_dot2acc_f32_f16 v28, v71, v21                            // 000000A36C44: 04382B47
	v_bfe_u32 v71, v70, 8, 16                                  // 000000A36C48: D6100047 02411146
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A36C50: D622004C 03FD014C 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A36C5C: BF870092
	.long 0xd72c0047                                           // 000000A36C60: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A36C64: 02028EFF 83DCD12D
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A36C6C: D6220047 03FD0147 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A36C78: BF8700B1
	v_lshl_or_b32 v71, v71, 16, v79                            // 000000A36C7C: D6560047 053D2147
	ds_load_2addr_b32 v[78:79], v65 offset0:132 offset1:165    // 000000A36C84: D8DCA584 4E000041
	v_pk_fma_f16 v71, v71, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A36C8C: CC0E0047 0BFC0D47 0000C931
	v_dot2acc_f32_f16 v41, v71, v18                            // 000000A36C98: 04522547
	v_bfe_u32 v71, v69, 12, 16                                 // 000000A36C9C: D6100047 02411945
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A36CA4: BF870091
	.long 0xd72c0047                                           // 000000A36CA8: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A36CAC: 02028EFF 83DCD12D
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A36CB4: D6220047 03FD0147 00006400
	v_dot2acc_f32_f16 v42, v72, v21                            // 000000A36CC0: 04542B48
	v_and_b32_e32 v72, 0xffff, v70                             // 000000A36CC4: 36908CFF 0000FFFF
	v_bfe_u32 v70, v70, 4, 16                                  // 000000A36CCC: D6100046 02410946
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A36CD4: BF870194
	v_and_b32_e32 v85, 0xffff, v71                             // 000000A36CD8: 36AA8EFF 0000FFFF
	.long 0xd72c0048                                           // 000000A36CE0: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A36CE4: 020290FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A36CEC: BF870113
	.long 0xd72c0046                                           // 000000A36CF0: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A36CF4: 02028CFF 83DCD12D
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A36CFC: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A36D08: BF870112
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A36D0C: D6220046 03FD0146 00006400
	v_lshlrev_b32_e32 v68, 16, v72                             // 000000A36D18: 30889090
	.long 0xd72c0048                                           // 000000A36D1C: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A36D20: 020296FF 83DCD12D
	v_bfe_u32 v75, v67, 12, 16                                 // 000000A36D28: D610004B 02411943
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A36D30: BF8701A3
	v_and_or_b32 v68, 0xffff, v70, v68                         // 000000A36D34: D6570044 05128CFF 0000FFFF
	v_lshl_or_b32 v70, v74, 16, v73                            // 000000A36D40: D6560046 0525214A
	.long 0xd72c0049                                           // 000000A36D48: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A36D4C: 020296FF 83DCD12D
	v_bfe_u32 v75, v67, 8, 16                                  // 000000A36D54: D610004B 02411143
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A36D5C: D6220048 03FD0148 00006400
	v_pk_fma_f16 v80, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A36D68: CC0E0050 0BFC0D44 0000C931
	v_pk_fma_f16 v81, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A36D74: CC0E0051 0BFC0D46 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A36D80: BF870194
	.long 0xd72c0044                                           // 000000A36D84: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A36D88: 020296FF 83DCD12D
	v_dot2acc_f32_f16 v41, v80, v19                            // 000000A36D90: 04522750
	v_sad_u8 v70, v73, 0, 0x6400                               // 000000A36D94: D6220046 03FD0149 00006400
	v_and_b32_e32 v73, 0xffff, v67                             // 000000A36DA0: 369286FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A36DA8: BF870003
	v_dot2acc_f32_f16 v41, v81, v20                            // 000000A36DAC: 04522951
	v_lshlrev_b32_e32 v74, 16, v76                             // 000000A36DB0: 30949890
	v_sad_u8 v75, v68, 0, 0x6400                               // 000000A36DB4: D622004B 03FD0144 00006400
	v_and_b32_e32 v70, 0xffff, v70                             // 000000A36DC0: 368C8CFF 0000FFFF
	.long 0xd72c0049                                           // 000000A36DC8: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A36DCC: 020292FF 83DCD12D
	v_bfe_u32 v76, v69, 8, 16                                  // 000000A36DD4: D610004C 02411145
	v_and_or_b32 v72, 0xffff, v72, v74                         // 000000A36DDC: D6570048 052A90FF 0000FFFF
	v_bfe_u32 v74, v67, 4, 16                                  // 000000A36DE8: D610004A 02410943
	ds_load_2addr_b32 v[67:68], v53 offset1:1                  // 000000A36DF0: D8DC0100 43000035
	v_lshl_or_b32 v70, v75, 16, v70                            // 000000A36DF8: D6560046 0519214B
	.long 0xd72c004b                                           // 000000A36E00: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A36E04: 020298FF 83DCD12D
	.long 0xd72c004a                                           // 000000A36E0C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A36E10: 020294FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A36E18: D6220049 03FD0149 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A36E24: BF870234
	v_pk_fma_f16 v82, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A36E28: CC0E0052 0BFC0D46 0000C931
	v_and_b32_e32 v77, 0xffff, v69                             // 000000A36E34: 369A8AFF 0000FFFF
	v_bfe_u32 v69, v69, 4, 16                                  // 000000A36E3C: D6100045 02410945
	v_lshlrev_b32_e32 v84, 16, v73                             // 000000A36E44: 30A89290
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A36E48: BF870214
	v_dot2acc_f32_f16 v40, v82, v18                            // 000000A36E4C: 04502552
	.long 0xd72c004c                                           // 000000A36E50: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A36E54: 02029AFF 83DCD12D
	v_sad_u8 v83, v74, 0, 0x6400                               // 000000A36E5C: D6220053 03FD014A 00006400
	.long 0xd72c0056                                           // 000000A36E68: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A36E6C: 02028AFF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A36E74: D622004B 03FD014B 00006400
	v_pk_fma_f16 v82, v72, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A36E80: CC0E0052 0BFC0D48 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A36E8C: BF870004
	v_and_or_b32 v83, 0xffff, v83, v84                         // 000000A36E90: D6570053 0552A6FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A36E9C: BF89FC07
	v_mov_b32_e32 v69, v67                                     // 000000A36EA0: 7E8A0343
	v_sad_u8 v87, v76, 0, 0x6400                               // 000000A36EA4: D6220057 03FD014C 00006400
	ds_load_2addr_b32 v[70:71], v54 offset1:1                  // 000000A36EB0: D8DC0100 46000036
	ds_load_2addr_b32 v[73:74], v55 offset1:1                  // 000000A36EB8: D8DC0100 49000037
	ds_load_2addr_b32 v[76:77], v56 offset1:1                  // 000000A36EC0: D8DC0100 4C000038
	v_lshl_or_b32 v75, v75, 16, v85                            // 000000A36EC8: D656004B 0555214B
	v_sad_u8 v84, v86, 0, 0x6400                               // 000000A36ED0: D6220054 03FD0156 00006400
	.long 0xd73d0043                                           // 000000A36EDC: D73D0043
	v_cndmask_b32_e32 v1, v45, v68, vcc_lo                     // 000000A36EE0: 0202892D
	v_pk_fma_f16 v68, v83, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A36EE4: CC0E0044 0BFC0D53 0000C931
	v_bfe_u32 v83, v78, 4, 16                                  // 000000A36EF0: D6100053 0241094E
	v_pk_fma_f16 v69, v75, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A36EF8: CC0E0045 0BFC0D4B 0000C931
	v_dot2acc_f32_f16 v41, v82, v21                            // 000000A36F04: 04522B52
	v_bfe_u32 v72, v67, 8, 16                                  // 000000A36F08: D6100048 02411143
	v_bfe_u32 v80, v67, 12, 16                                 // 000000A36F10: D6100050 02411943
	v_dot2acc_f32_f16 v40, v68, v19                            // 000000A36F18: 04502744
	v_lshlrev_b32_e32 v85, 16, v87                             // 000000A36F1C: 30AAAE90
	.long 0xd72c0053                                           // 000000A36F20: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A36F24: 0202A6FF 83DCD12D
	.long 0xd72c0048                                           // 000000A36F2C: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A36F30: 020290FF 83DCD12D
	.long 0xd72c0044                                           // 000000A36F38: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A36F3C: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v40, v69, v20                            // 000000A36F44: 04502945
	v_and_or_b32 v75, 0xffff, v84, v85                         // 000000A36F48: D657004B 0556A8FF 0000FFFF
	v_and_b32_e32 v69, 0xffff, v67                             // 000000A36F54: 368A86FF 0000FFFF
	v_bfe_u32 v67, v67, 4, 16                                  // 000000A36F5C: D6100043 02410943
	v_bfe_u32 v80, v78, 8, 16                                  // 000000A36F64: D6100050 0241114E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A36F6C: BF870004
	v_pk_fma_f16 v81, v75, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A36F70: CC0E0051 0BFC0D4B 0000C931
	v_bfe_u32 v75, v78, 12, 16                                 // 000000A36F7C: D610004B 0241194E
	v_sad_u8 v84, v72, 0, 0x6400                               // 000000A36F84: D6220054 03FD0148 00006400
	s_waitcnt lgkmcnt(2)                                       // 000000A36F90: BF89FC27
	v_mov_b32_e32 v72, v70                                     // 000000A36F94: 7E900346
	.long 0xd72c0045                                           // 000000A36F98: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A36F9C: 02028AFF 83DCD12D
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A36FA4: D6220044 03FD0144 00006400
	.long 0xd72c004b                                           // 000000A36FB0: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A36FB4: 020296FF 83DCD12D
	.long 0xd72c0043                                           // 000000A36FBC: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A36FC0: 020286FF 83DCD12D
	.long 0xd72c0050                                           // 000000A36FC8: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A36FCC: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v40, v81, v21                            // 000000A36FD4: 04502B51
	v_and_b32_e32 v68, 0xffff, v68                             // 000000A36FD8: 368888FF 0000FFFF
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A36FE0: D6220045 03FD0145 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A36FEC: D622004B 03FD014B 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A36FF8: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A37004: BF870214
	v_lshl_or_b32 v70, v84, 16, v68                            // 000000A37008: D6560046 05112154
	v_lshlrev_b32_e32 v69, 16, v69                             // 000000A37010: 308A8A90
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A37014: D6220050 03FD0150 00006400
	v_and_b32_e32 v75, 0xffff, v75                             // 000000A37020: 369696FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A37028: BF870214
	v_pk_fma_f16 v70, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A3702C: CC0E0046 0BFC0D46 0000C931
	v_and_or_b32 v69, 0xffff, v67, v69                         // 000000A37038: D6570045 051686FF 0000FFFF
	.long 0xd73d0043                                           // 000000A37044: D73D0043
	v_cndmask_b32_e32 v1, v45, v71, vcc_lo                     // 000000A37048: 02028F2D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A3704C: BF870004
	v_lshl_or_b32 v75, v80, 16, v75                            // 000000A37050: D656004B 052D2150
	v_sad_u8 v68, v83, 0, 0x6400                               // 000000A37058: D6220044 03FD0153 00006400
	v_dot2acc_f32_f16 v39, v70, v18                            // 000000A37064: 044E2546
	v_pk_fma_f16 v69, v69, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37068: CC0E0045 0BFC0D45 0000C931
	v_bfe_u32 v80, v79, 4, 16                                  // 000000A37074: D6100050 0241094F
	v_pk_fma_f16 v72, v75, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A3707C: CC0E0048 0BFC0D4B 0000C931
	v_bfe_u32 v75, v67, 12, 16                                 // 000000A37088: D610004B 02411943
	v_bfe_u32 v70, v67, 8, 16                                  // 000000A37090: D6100046 02411143
	v_dot2acc_f32_f16 v39, v69, v19                            // 000000A37098: 044E2745
	v_bfe_u32 v69, v79, 12, 16                                 // 000000A3709C: D6100045 0241194F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A370A4: BF870214
	.long 0xd72c004b                                           // 000000A370A8: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A370AC: 020296FF 83DCD12D
	.long 0xd72c0046                                           // 000000A370B4: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A370B8: 02028CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A370C0: BF870214
	v_dual_dot2acc_f32_f16 v39, v72, v20 :: v_dual_and_b32 v78, 0xffff, v78// 000000A370C4: CB242948 274E9CFF 0000FFFF
	.long 0xd72c0045                                           // 000000A370D0: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A370D4: 02028AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A370DC: BF870232
	.long 0xd72c004e                                           // 000000A370E0: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A370E4: 02029CFF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A370EC: D622004B 03FD014B 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A370F8: D6220046 03FD0146 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A37104: D6220045 03FD0145 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A37110: BF8701A3
	v_and_b32_e32 v75, 0xffff, v75                             // 000000A37114: 369696FF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A3711C: D622004E 03FD014E 00006400
	v_and_b32_e32 v69, 0xffff, v69                             // 000000A37128: 368A8AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A37130: BF870003
	v_lshl_or_b32 v70, v70, 16, v75                            // 000000A37134: D6560046 052D2146
	s_waitcnt lgkmcnt(1)                                       // 000000A3713C: BF89FC17
	v_mov_b32_e32 v75, v73                                     // 000000A37140: 7E960349
	v_lshlrev_b32_e32 v71, 16, v78                             // 000000A37144: 308E9C90
	v_bfe_u32 v78, v79, 8, 16                                  // 000000A37148: D610004E 0241114F
	.long 0xd72c0049                                           // 000000A37150: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A37154: 0202A0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A3715C: BF870253
	v_and_or_b32 v71, 0xffff, v68, v71                         // 000000A37160: D6570047 051E88FF 0000FFFF
	v_and_b32_e32 v68, 0xffff, v67                             // 000000A3716C: 368886FF 0000FFFF
	v_bfe_u32 v67, v67, 4, 16                                  // 000000A37174: D6100043 02410943
	.long 0xd72c004e                                           // 000000A3717C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A37180: 02029CFF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A37188: D6220049 03FD0149 00006400
	.long 0xd72c0044                                           // 000000A37194: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A37198: 020288FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A371A0: BF870214
	.long 0xd72c0043                                           // 000000A371A4: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A371A8: 020286FF 83DCD12D
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A371B0: D622004E 03FD014E 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A371BC: BF870193
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A371C0: D6220044 03FD0144 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A371CC: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A371D8: BF870092
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000A371DC: 30888890
	v_and_or_b32 v83, 0xffff, v67, v68                         // 000000A371E0: D6570053 051286FF 0000FFFF
	.long 0xd73d0043                                           // 000000A371EC: D73D0043
	v_cndmask_b32_e32 v1, v45, v74, vcc_lo                     // 000000A371F0: 0202952D
	v_pk_fma_f16 v68, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A371F4: CC0E0044 0BFC0D46 0000C931
	v_lshl_or_b32 v74, v78, 16, v69                            // 000000A37200: D656004A 0515214E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A37208: BF870194
	v_pk_fma_f16 v70, v83, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A3720C: CC0E0046 0BFC0D53 0000C931
	v_dot2acc_f32_f16 v38, v68, v18                            // 000000A37218: 044C2544
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A3721C: BF870003
	v_pk_fma_f16 v74, v74, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37220: CC0E004A 0BFC0D4A 0000C931
	v_bfe_u32 v78, v67, 12, 16                                 // 000000A3722C: D610004E 02411943
	ds_load_2addr_b32 v[68:69], v65 offset0:198 offset1:231    // 000000A37234: D8DCE7C6 44000041
	v_dot2acc_f32_f16 v38, v70, v19                            // 000000A3723C: 044C2746
	v_and_b32_e32 v79, 0xffff, v79                             // 000000A37240: 369E9EFF 0000FFFF
	v_pk_fma_f16 v70, v71, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37248: CC0E0046 0BFC0D47 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A37254: BF870193
	v_dot2acc_f32_f16 v38, v74, v20                            // 000000A37258: 044C294A
	.long 0xd72c004f                                           // 000000A3725C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A37260: 02029EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A37268: BF870113
	v_dot2acc_f32_f16 v39, v70, v21                            // 000000A3726C: 044E2B46
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A37270: D622004F 03FD014F 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000A3727C: BF89FC07
	v_bfe_u32 v74, v68, 8, 16                                  // 000000A37280: D610004A 02411144
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A37288: BF870112
	v_lshlrev_b32_e32 v75, 16, v79                             // 000000A3728C: 30969E90
	.long 0xd72c004a                                           // 000000A37290: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A37294: 020294FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A3729C: BF8701B2
	v_and_or_b32 v73, 0xffff, v73, v75                         // 000000A372A0: D6570049 052E92FF 0000FFFF
	.long 0xd72c004b                                           // 000000A372AC: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A372B0: 02029CFF 83DCD12D
	v_bfe_u32 v78, v67, 8, 16                                  // 000000A372B8: D610004E 02411143
	v_pk_fma_f16 v71, v73, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A372C0: CC0E0047 0BFC0D49 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A372CC: BF870232
	.long 0xd72c0048                                           // 000000A372D0: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A372D4: 02029CFF 83DCD12D
	v_mov_b32_e32 v78, v76                                     // 000000A372DC: 7E9C034C
	v_sad_u8 v73, v75, 0, 0x6400                               // 000000A372E0: D6220049 03FD014B 00006400
	v_dot2acc_f32_f16 v38, v71, v21                            // 000000A372EC: 044C2B47
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A372F0: D622004A 03FD014A 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A372FC: BF870253
	v_and_b32_e32 v70, 0xffff, v73                             // 000000A37300: 368C92FF 0000FFFF
	v_sad_u8 v71, v72, 0, 0x6400                               // 000000A37308: D6220047 03FD0148 00006400
	v_and_b32_e32 v72, 0xffff, v67                             // 000000A37314: 369086FF 0000FFFF
	v_bfe_u32 v67, v67, 4, 16                                  // 000000A3731C: D6100043 02410943
	v_bfe_u32 v73, v68, 12, 16                                 // 000000A37324: D6100049 02411944
	v_lshl_or_b32 v70, v71, 16, v70                            // 000000A3732C: D6560046 05192147
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A37334: BF870214
	.long 0xd72c0047                                           // 000000A37338: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A3733C: 020290FF 83DCD12D
	.long 0xd72c004b                                           // 000000A37344: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A37348: 020286FF 83DCD12D
	v_and_b32_e32 v72, 0xffff, v68                             // 000000A37350: 369088FF 0000FFFF
	v_bfe_u32 v68, v68, 4, 16                                  // 000000A37358: D6100044 02410944
	.long 0xd72c0049                                           // 000000A37360: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A37364: 020292FF 83DCD12D
	v_pk_fma_f16 v70, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A3736C: CC0E0046 0BFC0D46 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A37378: BF870004
	.long 0xd72c0048                                           // 000000A3737C: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A37380: 020290FF 83DCD12D
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A37388: D6220047 03FD0147 00006400
	.long 0xd72c004c                                           // 000000A37394: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A37398: 020288FF 83DCD12D
	.long 0xd73d0043                                           // 000000A373A0: D73D0043
	v_cndmask_b32_e32 v1, v45, v77, vcc_lo                     // 000000A373A4: 02029B2D
	v_sad_u8 v68, v75, 0, 0x6400                               // 000000A373A8: D6220044 03FD014B 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A373B4: D6220049 03FD0149 00006400
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000A373C0: 308E8E90
	v_dot2acc_f32_f16 v37, v70, v18                            // 000000A373C4: 044A2546
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A373C8: D6220048 03FD0148 00006400
	v_bfe_u32 v75, v67, 12, 16                                 // 000000A373D4: D610004B 02411943
	v_and_b32_e32 v73, 0xffff, v73                             // 000000A373DC: 369292FF 0000FFFF
	v_and_or_b32 v68, 0xffff, v68, v71                         // 000000A373E4: D6570044 051E88FF 0000FFFF
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A373F0: D622004C 03FD014C 00006400
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000A373FC: 30909090
	v_bfe_u32 v77, v69, 8, 16                                  // 000000A37400: D610004D 02411145
	v_lshl_or_b32 v71, v74, 16, v73                            // 000000A37408: D6560047 0525214A
	v_pk_fma_f16 v68, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37410: CC0E0044 0BFC0D44 0000C931
	v_bfe_u32 v74, v67, 8, 16                                  // 000000A3741C: D610004A 02411143
	.long 0xd72c0049                                           // 000000A37424: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A37428: 020296FF 83DCD12D
	v_and_or_b32 v72, 0xffff, v76, v72                         // 000000A37430: D6570048 052298FF 0000FFFF
	v_bfe_u32 v75, v67, 4, 16                                  // 000000A3743C: D610004B 02410943
	v_dot2acc_f32_f16 v37, v68, v19                            // 000000A37444: 044A2744
	v_and_b32_e32 v68, 0xffff, v67                             // 000000A37448: 368886FF 0000FFFF
	v_pk_fma_f16 v70, v71, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37450: CC0E0046 0BFC0D47 0000C931
	.long 0xd72c0047                                           // 000000A3745C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A37460: 020294FF 83DCD12D
	v_bfe_u32 v74, v69, 12, 16                                 // 000000A37468: D610004A 02411945
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A37470: D6220049 03FD0149 00006400
	.long 0xd72c004c                                           // 000000A3747C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A37480: 020288FF 83DCD12D
	ds_load_2addr_b32 v[67:68], v57 offset1:1                  // 000000A37488: D8DC0100 43000039
	.long 0xd72c0053                                           // 000000A37490: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A37494: 02029AFF 83DCD12D
	.long 0xd72c004a                                           // 000000A3749C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A374A0: 020294FF 83DCD12D
	v_dual_dot2acc_f32_f16 v37, v70, v20 :: v_dual_and_b32 v70, 0xffff, v69// 000000A374A8: CB242946 25468AFF 0000FFFF
	v_bfe_u32 v69, v69, 4, 16                                  // 000000A374B4: D6100045 02410945
	v_and_b32_e32 v73, 0xffff, v73                             // 000000A374BC: 369292FF 0000FFFF
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A374C4: D6220047 03FD0147 00006400
	.long 0xd72c004b                                           // 000000A374D0: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A374D4: 020296FF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A374DC: D6220053 03FD0153 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A374E8: D622004A 03FD014A 00006400
	.long 0xd72c0054                                           // 000000A374F4: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A374F8: 02028AFF 83DCD12D
	v_lshl_or_b32 v71, v71, 16, v73                            // 000000A37500: D6560047 05252147
	v_sad_u8 v73, v76, 0, 0x6400                               // 000000A37508: D6220049 03FD014C 00006400
	ds_load_2addr_b32 v[78:79], v66 offset0:8 offset1:41       // 000000A37514: D8DC2908 4E000042
	v_and_b32_e32 v82, 0xffff, v74                             // 000000A3751C: 36A494FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A37524: D622004B 03FD014B 00006400
	v_pk_fma_f16 v80, v71, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37530: CC0E0050 0BFC0D47 0000C931
	v_pk_fma_f16 v72, v72, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A3753C: CC0E0048 0BFC0D48 0000C931
	.long 0xd72c0046                                           // 000000A37548: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A3754C: 02028CFF 83DCD12D
	s_waitcnt lgkmcnt(1)                                       // 000000A37554: BF89FC17
	v_mov_b32_e32 v69, v67                                     // 000000A37558: 7E8A0343
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A3755C: D6220054 03FD0154 00006400
	v_dot2acc_f32_f16 v36, v80, v18                            // 000000A37568: 04482550
	v_dot2acc_f32_f16 v37, v72, v21                            // 000000A3756C: 044A2B48
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000A37570: BF870134
	.long 0xd73d0043                                           // 000000A37574: D73D0043
	v_cndmask_b32_e32 v1, v45, v68, vcc_lo                     // 000000A37578: 0202892D
	v_lshl_or_b32 v68, v83, 16, v82                            // 000000A3757C: D6560044 05492153
	v_sad_u8 v85, v70, 0, 0x6400                               // 000000A37584: D6220055 03FD0146 00006400
	v_pk_fma_f16 v80, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37590: CC0E0050 0BFC0D44 0000C931
	v_lshlrev_b32_e32 v81, 16, v73                             // 000000A3759C: 30A29290
	ds_load_2addr_b32 v[70:71], v58 offset1:1                  // 000000A375A0: D8DC0100 4600003A
	ds_load_2addr_b32 v[73:74], v59 offset1:1                  // 000000A375A8: D8DC0100 4900003B
	ds_load_2addr_b32 v[76:77], v60 offset1:1                  // 000000A375B0: D8DC0100 4C00003C
	v_and_b32_e32 v68, 0xffff, v67                             // 000000A375B8: 368886FF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 000000A375C0: BF89FC37
	v_bfe_u32 v82, v78, 8, 16                                  // 000000A375C4: D6100052 0241114E
	v_bfe_u32 v83, v78, 4, 16                                  // 000000A375CC: D6100053 0241094E
	v_and_or_b32 v75, 0xffff, v75, v81                         // 000000A375D4: D657004B 054696FF 0000FFFF
	v_bfe_u32 v81, v78, 12, 16                                 // 000000A375E0: D6100051 0241194E
	.long 0xd72c0044                                           // 000000A375E8: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A375EC: 020288FF 83DCD12D
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A375F4: 369C9CFF 0000FFFF
	.long 0xd72c0052                                           // 000000A375FC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A37600: 0202A4FF 83DCD12D
	v_pk_fma_f16 v72, v75, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37608: CC0E0048 0BFC0D4B 0000C931
	v_bfe_u32 v75, v67, 12, 16                                 // 000000A37614: D610004B 02411943
	.long 0xd72c0051                                           // 000000A3761C: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A37620: 0202A2FF 83DCD12D
	.long 0xd72c004e                                           // 000000A37628: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A3762C: 02029CFF 83DCD12D
	.long 0xd72c0053                                           // 000000A37634: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A37638: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v36, v72, v19                            // 000000A37640: 04482748
	.long 0xd72c0048                                           // 000000A37644: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A37648: 020296FF 83DCD12D
	v_bfe_u32 v75, v67, 8, 16                                  // 000000A37650: D610004B 02411143
	v_bfe_u32 v67, v67, 4, 16                                  // 000000A37658: D6100043 02410943
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A37660: D6220044 03FD0144 00006400
	v_lshlrev_b32_e32 v85, 16, v85                             // 000000A3766C: 30AAAA90
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A37670: D6220051 03FD0151 00006400
	.long 0xd72c004b                                           // 000000A3767C: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A37680: 020296FF 83DCD12D
	.long 0xd72c0043                                           // 000000A37688: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A3768C: 020286FF 83DCD12D
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A37694: D6220048 03FD0148 00006400
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000A376A0: 30888890
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A376A4: D622004E 03FD014E 00006400
	v_and_or_b32 v69, 0xffff, v84, v85                         // 000000A376B0: D6570045 0556A8FF 0000FFFF
	v_dot2acc_f32_f16 v36, v80, v20                            // 000000A376BC: 04482950
	v_and_b32_e32 v72, 0xffff, v72                             // 000000A376C0: 369090FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A376C8: D622004B 03FD014B 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A376D4: D6220043 03FD0143 00006400
	v_pk_fma_f16 v69, v69, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A376E0: CC0E0045 0BFC0D45 0000C931
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A376EC: BF870003
	v_lshl_or_b32 v75, v75, 16, v72                            // 000000A376F0: D656004B 0521214B
	s_waitcnt lgkmcnt(2)                                       // 000000A376F8: BF89FC27
	v_mov_b32_e32 v72, v70                                     // 000000A376FC: 7E900346
	v_and_or_b32 v84, 0xffff, v67, v68                         // 000000A37700: D6570054 051286FF 0000FFFF
	v_and_b32_e32 v70, 0xffff, v81                             // 000000A3770C: 368CA2FF 0000FFFF
	v_sad_u8 v81, v82, 0, 0x6400                               // 000000A37714: D6220051 03FD0152 00006400
	v_pk_fma_f16 v75, v75, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37720: CC0E004B 0BFC0D4B 0000C931
	.long 0xd73d0043                                           // 000000A3772C: D73D0043
	v_cndmask_b32_e32 v1, v45, v71, vcc_lo                     // 000000A37730: 02028F2D
	v_sad_u8 v71, v83, 0, 0x6400                               // 000000A37734: D6220047 03FD0153 00006400
	v_lshlrev_b32_e32 v72, 16, v78                             // 000000A37740: 30909C90
	v_pk_fma_f16 v68, v84, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37744: CC0E0044 0BFC0D54 0000C931
	v_lshl_or_b32 v70, v81, 16, v70                            // 000000A37750: D6560046 05192151
	v_dot2acc_f32_f16 v35, v75, v18                            // 000000A37758: 0446254B
	v_bfe_u32 v75, v67, 12, 16                                 // 000000A3775C: D610004B 02411943
	v_and_or_b32 v71, 0xffff, v71, v72                         // 000000A37764: D6570047 05228EFF 0000FFFF
	v_bfe_u32 v72, v67, 8, 16                                  // 000000A37770: D6100048 02411143
	v_pk_fma_f16 v70, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37778: CC0E0046 0BFC0D46 0000C931
	v_dot2acc_f32_f16 v35, v68, v19                            // 000000A37784: 04462744
	.long 0xd72c0044                                           // 000000A37788: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A3778C: 020296FF 83DCD12D
	v_pk_fma_f16 v78, v71, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37794: CC0E004E 0BFC0D47 0000C931
	v_bfe_u32 v71, v79, 12, 16                                 // 000000A377A0: D6100047 0241194F
	v_and_b32_e32 v75, 0xffff, v79                             // 000000A377A8: 36969EFF 0000FFFF
	v_dot2acc_f32_f16 v35, v70, v20                            // 000000A377B0: 04462946
	.long 0xd72c0046                                           // 000000A377B4: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A377B8: 020290FF 83DCD12D
	v_bfe_u32 v72, v79, 8, 16                                  // 000000A377C0: D6100048 0241114F
	.long 0xd72c0047                                           // 000000A377C8: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A377CC: 02028EFF 83DCD12D
	.long 0xd72c004b                                           // 000000A377D4: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A377D8: 020296FF 83DCD12D
	v_dot2acc_f32_f16 v36, v69, v21                            // 000000A377E0: 04482B45
	v_bfe_u32 v69, v67, 4, 16                                  // 000000A377E4: D6100045 02410943
	v_and_b32_e32 v67, 0xffff, v67                             // 000000A377EC: 368686FF 0000FFFF
	.long 0xd72c0048                                           // 000000A377F4: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A377F8: 020290FF 83DCD12D
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A37800: D6220044 03FD0144 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A3780C: D6220046 03FD0146 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A37818: D6220047 03FD0147 00006400
	.long 0xd72c0043                                           // 000000A37824: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A37828: 020286FF 83DCD12D
	.long 0xd72c0045                                           // 000000A37830: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A37834: 02028AFF 83DCD12D
	v_and_b32_e32 v68, 0xffff, v68                             // 000000A3783C: 368888FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A37844: D622004B 03FD014B 00006400
	v_and_b32_e32 v71, 0xffff, v71                             // 000000A37850: 368E8EFF 0000FFFF
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A37858: D6220048 03FD0148 00006400
	v_bfe_u32 v79, v79, 4, 16                                  // 000000A37864: D610004F 0241094F
	v_lshl_or_b32 v70, v70, 16, v68                            // 000000A3786C: D6560046 05112146
	v_lshlrev_b32_e32 v81, 16, v75                             // 000000A37874: 30A29690
	s_waitcnt lgkmcnt(1)                                       // 000000A37878: BF89FC17
	v_mov_b32_e32 v75, v73                                     // 000000A3787C: 7E960349
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A37880: D6220043 03FD0143 00006400
	v_lshl_or_b32 v72, v72, 16, v71                            // 000000A3788C: D6560048 051D2148
	v_sad_u8 v80, v69, 0, 0x6400                               // 000000A37894: D6220050 03FD0145 00006400
	ds_load_2addr_b32 v[68:69], v66 offset0:74 offset1:107     // 000000A378A0: D8DC6B4A 44000042
	v_pk_fma_f16 v73, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A378A8: CC0E0049 0BFC0D46 0000C931
	.long 0xd73d0046                                           // 000000A378B4: D73D0046
	v_cndmask_b32_e32 v1, v45, v74, vcc_lo                     // 000000A378B8: 0202952D
	v_pk_fma_f16 v71, v72, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A378BC: CC0E0047 0BFC0D48 0000C931
	v_lshlrev_b32_e32 v67, 16, v67                             // 000000A378C8: 30868690
	.long 0xd72c004f                                           // 000000A378CC: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A378D0: 02029EFF 83DCD12D
	v_dual_dot2acc_f32_f16 v34, v73, v18 :: v_dual_dot2acc_f32_f16 v35, v78, v21// 000000A378D8: CB182549 22222B4E
	v_bfe_u32 v73, v70, 12, 16                                 // 000000A378E0: D6100049 02411946
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A378E8: BF8701B4
	v_and_or_b32 v67, 0xffff, v80, v67                         // 000000A378EC: D6570043 050EA0FF 0000FFFF
	v_bfe_u32 v74, v70, 8, 16                                  // 000000A378F8: D610004A 02411146
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A37900: D622004F 03FD014F 00006400
	v_pk_fma_f16 v67, v67, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A3790C: CC0E0043 0BFC0D43 0000C931
	.long 0xd72c0049                                           // 000000A37918: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A3791C: 020292FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A37924: BF870214
	.long 0xd72c004a                                           // 000000A37928: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A3792C: 020294FF 83DCD12D
	v_and_or_b32 v79, 0xffff, v79, v81                         // 000000A37934: D657004F 05469EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A37940: BF870004
	v_dual_dot2acc_f32_f16 v34, v67, v19 :: v_dual_and_b32 v67, 0xffff, v70// 000000A37944: CB242743 22428CFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A37950: BF89FC07
	v_bfe_u32 v75, v68, 12, 16                                 // 000000A37954: D610004B 02411944
	v_bfe_u32 v70, v70, 4, 16                                  // 000000A3795C: D6100046 02410946
	v_bfe_u32 v78, v68, 8, 16                                  // 000000A37964: D610004E 02411144
	v_pk_fma_f16 v72, v79, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A3796C: CC0E0048 0BFC0D4F 0000C931
	.long 0xd72c0043                                           // 000000A37978: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A3797C: 020286FF 83DCD12D
	.long 0xd72c004b                                           // 000000A37984: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A37988: 020296FF 83DCD12D
	.long 0xd72c0046                                           // 000000A37990: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A37994: 02028CFF 83DCD12D
	v_bfe_u32 v79, v68, 4, 16                                  // 000000A3799C: D610004F 02410944
	v_and_b32_e32 v80, 0xffff, v68                             // 000000A379A4: 36A088FF 0000FFFF
	.long 0xd72c0044                                           // 000000A379AC: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A379B0: 02029CFF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A379B8: D6220049 03FD0149 00006400
	v_mov_b32_e32 v78, v76                                     // 000000A379C4: 7E9C034C
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A379C8: D6220043 03FD0143 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A379D4: D622004B 03FD014B 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A379E0: D6220046 03FD0146 00006400
	v_dual_dot2acc_f32_f16 v34, v71, v20 :: v_dual_and_b32 v73, 0xffff, v73// 000000A379EC: CB242947 224892FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A379F8: BF870004
	v_lshlrev_b32_e32 v67, 16, v67                             // 000000A379FC: 30868690
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A37A00: D622004A 03FD014A 00006400
	v_and_b32_e32 v75, 0xffff, v75                             // 000000A37A0C: 369696FF 0000FFFF
	v_sad_u8 v76, v68, 0, 0x6400                               // 000000A37A14: D622004C 03FD0144 00006400
	v_dot2acc_f32_f16 v34, v72, v21                            // 000000A37A20: 04442B48
	v_and_or_b32 v70, 0xffff, v70, v67                         // 000000A37A24: D6570046 050E8CFF 0000FFFF
	.long 0xd73d0043                                           // 000000A37A30: D73D0043
	v_cndmask_b32_e32 v1, v45, v77, vcc_lo                     // 000000A37A34: 02029B2D
	v_lshl_or_b32 v73, v74, 16, v73                            // 000000A37A38: D6560049 0525214A
	.long 0xd72c004a                                           // 000000A37A40: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A37A44: 02029EFF 83DCD12D
	v_lshl_or_b32 v68, v76, 16, v75                            // 000000A37A4C: D6560044 052D214C
	.long 0xd72c004b                                           // 000000A37A54: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A37A58: 0202A0FF 83DCD12D
	v_pk_fma_f16 v80, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37A60: CC0E0050 0BFC0D46 0000C931
	v_bfe_u32 v70, v67, 12, 16                                 // 000000A37A6C: D6100046 02411943
	v_pk_fma_f16 v71, v73, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37A74: CC0E0047 0BFC0D49 0000C931
	v_pk_fma_f16 v81, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37A80: CC0E0051 0BFC0D44 0000C931
	v_and_b32_e32 v73, 0xffff, v67                             // 000000A37A8C: 369286FF 0000FFFF
	v_sad_u8 v68, v74, 0, 0x6400                               // 000000A37A94: D6220044 03FD014A 00006400
	.long 0xd72c0046                                           // 000000A37AA0: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A37AA4: 02028CFF 83DCD12D
	v_sad_u8 v74, v75, 0, 0x6400                               // 000000A37AAC: D622004A 03FD014B 00006400
	v_bfe_u32 v75, v67, 8, 16                                  // 000000A37AB8: D610004B 02411143
	v_bfe_u32 v67, v67, 4, 16                                  // 000000A37AC0: D6100043 02410943
	.long 0xd72c0049                                           // 000000A37AC8: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A37ACC: 020292FF 83DCD12D
	v_bfe_u32 v76, v69, 12, 16                                 // 000000A37AD4: D610004C 02411945
	v_lshlrev_b32_e32 v74, 16, v74                             // 000000A37ADC: 30949490
	.long 0xd72c004b                                           // 000000A37AE0: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A37AE4: 020296FF 83DCD12D
	.long 0xd72c0043                                           // 000000A37AEC: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A37AF0: 020286FF 83DCD12D
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A37AF8: D6220046 03FD0146 00006400
	.long 0xd72c004c                                           // 000000A37B04: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A37B08: 020298FF 83DCD12D
	v_and_or_b32 v82, 0xffff, v68, v74                         // 000000A37B10: D6570052 052A88FF 0000FFFF
	v_bfe_u32 v74, v69, 8, 16                                  // 000000A37B1C: D610004A 02411145
	v_and_b32_e32 v78, 0xffff, v69                             // 000000A37B24: 369C8AFF 0000FFFF
	v_and_b32_e32 v70, 0xffff, v70                             // 000000A37B2C: 368C8CFF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A37B34: D622004B 03FD014B 00006400
	v_sad_u8 v77, v67, 0, 0x6400                               // 000000A37B40: D622004D 03FD0143 00006400
	ds_load_2addr_b32 v[67:68], v61 offset1:1                  // 000000A37B4C: D8DC0100 4300003D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A37B54: D6220049 03FD0149 00006400
	.long 0xd72c004a                                           // 000000A37B60: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A37B64: 020294FF 83DCD12D
	v_bfe_u32 v69, v69, 4, 16                                  // 000000A37B6C: D6100045 02410945
	v_lshl_or_b32 v70, v75, 16, v70                            // 000000A37B74: D6560046 0519214B
	.long 0xd72c004b                                           // 000000A37B7C: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A37B80: 02029CFF 83DCD12D
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000A37B88: 30929290
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A37B8C: D622004C 03FD014C 00006400
	.long 0xd72c004e                                           // 000000A37B98: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A37B9C: 02028AFF 83DCD12D
	v_pk_fma_f16 v83, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37BA4: CC0E0053 0BFC0D46 0000C931
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A37BB0: D622004A 03FD014A 00006400
	v_and_or_b32 v73, 0xffff, v77, v73                         // 000000A37BBC: D6570049 05269AFF 0000FFFF
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A37BC8: 369898FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A37BD0: D622004B 03FD014B 00006400
	v_dot2acc_f32_f16 v33, v71, v18                            // 000000A37BDC: 04422547
	v_dot2acc_f32_f16 v32, v83, v18                            // 000000A37BE0: 04402553
	v_pk_fma_f16 v84, v73, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37BE4: CC0E0054 0BFC0D49 0000C931
	v_lshl_or_b32 v85, v74, 16, v76                            // 000000A37BF0: D6560055 0531214A
	ds_load_2addr_b32 v[70:71], v62 offset1:1                  // 000000A37BF8: D8DC0100 4600003E
	ds_load_2addr_b32 v[73:74], v63 offset1:1                  // 000000A37C00: D8DC0100 4900003F
	ds_load_2addr_b32 v[76:77], v64 offset1:1                  // 000000A37C08: D8DC0100 4C000040
	v_sad_u8 v86, v78, 0, 0x6400                               // 000000A37C10: D6220056 03FD014E 00006400
	s_waitcnt lgkmcnt(3)                                       // 000000A37C1C: BF89FC37
	v_mov_b32_e32 v69, v67                                     // 000000A37C20: 7E8A0343
	ds_load_2addr_b32 v[78:79], v66 offset0:140 offset1:173    // 000000A37C24: D8DCAD8C 4E000042
	v_lshlrev_b32_e32 v75, 16, v75                             // 000000A37C2C: 30969690
	v_dot2acc_f32_f16 v32, v84, v19                            // 000000A37C30: 04402754
	v_dot2acc_f32_f16 v33, v80, v19                            // 000000A37C34: 04422750
	.long 0xd73d0043                                           // 000000A37C38: D73D0043
	v_cndmask_b32_e32 v1, v45, v68, vcc_lo                     // 000000A37C3C: 0202892D
	v_pk_fma_f16 v68, v85, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37C40: CC0E0044 0BFC0D55 0000C931
	v_and_or_b32 v69, 0xffff, v86, v75                         // 000000A37C4C: D6570045 052EACFF 0000FFFF
	v_pk_fma_f16 v75, v82, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37C58: CC0E004B 0BFC0D52 0000C931
	v_dot2acc_f32_f16 v33, v81, v20                            // 000000A37C64: 04422951
	v_bfe_u32 v80, v67, 12, 16                                 // 000000A37C68: D6100050 02411943
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A37C70: BF870224
	v_pk_fma_f16 v69, v69, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37C74: CC0E0045 0BFC0D45 0000C931
	v_dot2acc_f32_f16 v32, v68, v20                            // 000000A37C80: 04402944
	v_dual_dot2acc_f32_f16 v33, v75, v21 :: v_dual_and_b32 v72, 0xffff, v67// 000000A37C84: CB242B4B 214886FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A37C90: BF870194
	.long 0xd72c0044                                           // 000000A37C94: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A37C98: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v32, v69, v21                            // 000000A37CA0: 04402B45
	v_bfe_u32 v69, v67, 8, 16                                  // 000000A37CA4: D6100045 02411143
	v_bfe_u32 v67, v67, 4, 16                                  // 000000A37CAC: D6100043 02410943
	.long 0xd72c0048                                           // 000000A37CB4: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A37CB8: 020290FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A37CC0: BF89FC07
	v_bfe_u32 v75, v78, 12, 16                                 // 000000A37CC4: D610004B 0241194E
	v_bfe_u32 v80, v78, 8, 16                                  // 000000A37CCC: D6100050 0241114E
	.long 0xd72c0045                                           // 000000A37CD4: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A37CD8: 02028AFF 83DCD12D
	.long 0xd72c0043                                           // 000000A37CE0: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A37CE4: 020286FF 83DCD12D
	v_bfe_u32 v81, v78, 4, 16                                  // 000000A37CEC: D6100051 0241094E
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A37CF4: 369C9CFF 0000FFFF
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A37CFC: D6220044 03FD0144 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A37D08: D6220048 03FD0148 00006400
	.long 0xd72c004b                                           // 000000A37D14: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A37D18: 020296FF 83DCD12D
	.long 0xd72c0050                                           // 000000A37D20: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A37D24: 0202A0FF 83DCD12D
	.long 0xd72c004e                                           // 000000A37D2C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A37D30: 02029CFF 83DCD12D
	v_and_b32_e32 v68, 0xffff, v68                             // 000000A37D38: 368888FF 0000FFFF
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A37D40: D6220045 03FD0145 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A37D4C: D6220043 03FD0143 00006400
	v_lshlrev_b32_e32 v82, 16, v72                             // 000000A37D58: 30A49090
	v_mov_b32_e32 v72, v70                                     // 000000A37D5C: 7E900346
	.long 0xd72c0051                                           // 000000A37D60: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A37D64: 0202A2FF 83DCD12D
	v_sad_u8 v70, v75, 0, 0x6400                               // 000000A37D6C: D6220046 03FD014B 00006400
	v_lshl_or_b32 v69, v69, 16, v68                            // 000000A37D78: D6560045 05112145
	v_and_or_b32 v75, 0xffff, v67, v82                         // 000000A37D80: D657004B 054A86FF 0000FFFF
	.long 0xd73d0043                                           // 000000A37D8C: D73D0043
	v_cndmask_b32_e32 v1, v45, v71, vcc_lo                     // 000000A37D90: 02028F2D
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A37D94: D622004E 03FD014E 00006400
	v_and_b32_e32 v68, 0xffff, v70                             // 000000A37DA0: 36888CFF 0000FFFF
	v_sad_u8 v70, v80, 0, 0x6400                               // 000000A37DA8: D6220046 03FD0150 00006400
	v_sad_u8 v71, v81, 0, 0x6400                               // 000000A37DB4: D6220047 03FD0151 00006400
	v_pk_fma_f16 v69, v69, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37DC0: CC0E0045 0BFC0D45 0000C931
	v_lshlrev_b32_e32 v72, 16, v78                             // 000000A37DCC: 30909C90
	v_bfe_u32 v78, v67, 12, 16                                 // 000000A37DD0: D610004E 02411943
	v_lshl_or_b32 v68, v70, 16, v68                            // 000000A37DD8: D6560044 05112146
	v_pk_fma_f16 v75, v75, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37DE0: CC0E004B 0BFC0D4B 0000C931
	v_dot2acc_f32_f16 v31, v69, v18                            // 000000A37DEC: 043E2545
	v_and_or_b32 v70, 0xffff, v71, v72                         // 000000A37DF0: D6570046 05228EFF 0000FFFF
	.long 0xd72c0045                                           // 000000A37DFC: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A37E00: 02029CFF 83DCD12D
	v_bfe_u32 v71, v67, 8, 16                                  // 000000A37E08: D6100047 02411143
	v_and_b32_e32 v78, 0xffff, v79                             // 000000A37E10: 369C9EFF 0000FFFF
	v_dot2acc_f32_f16 v31, v75, v19                            // 000000A37E18: 043E274B
	v_pk_fma_f16 v80, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37E1C: CC0E0050 0BFC0D46 0000C931
	v_bfe_u32 v75, v79, 8, 16                                  // 000000A37E28: D610004B 0241114F
	.long 0xd72c0046                                           // 000000A37E30: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A37E34: 02028EFF 83DCD12D
	v_bfe_u32 v71, v79, 12, 16                                 // 000000A37E3C: D6100047 0241194F
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A37E44: D6220045 03FD0145 00006400
	v_bfe_u32 v79, v79, 4, 16                                  // 000000A37E50: D610004F 0241094F
	.long 0xd72c004e                                           // 000000A37E58: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A37E5C: 02029CFF 83DCD12D
	v_pk_fma_f16 v72, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37E64: CC0E0048 0BFC0D44 0000C931
	.long 0xd72c0047                                           // 000000A37E70: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A37E74: 02028EFF 83DCD12D
	v_and_b32_e32 v69, 0xffff, v69                             // 000000A37E7C: 368A8AFF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A37E84: D6220046 03FD0146 00006400
	v_bfe_u32 v68, v67, 4, 16                                  // 000000A37E90: D6100044 02410943
	v_dot2acc_f32_f16 v31, v72, v20                            // 000000A37E98: 043E2948
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A37E9C: D622004E 03FD014E 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A37EA8: BF870004
	v_lshl_or_b32 v69, v70, 16, v69                            // 000000A37EAC: D6560045 05152146
	.long 0xd72c0046                                           // 000000A37EB4: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A37EB8: 020296FF 83DCD12D
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A37EC0: D6220047 03FD0147 00006400
	.long 0xd72c004b                                           // 000000A37ECC: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A37ED0: 02029EFF 83DCD12D
	v_lshlrev_b32_e32 v78, 16, v78                             // 000000A37ED8: 309C9C90
	.long 0xd72c0044                                           // 000000A37EDC: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A37EE0: 020288FF 83DCD12D
	v_dot2acc_f32_f16 v31, v80, v21                            // 000000A37EE8: 043E2B50
	v_and_b32_e32 v71, 0xffff, v71                             // 000000A37EEC: 368E8EFF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A37EF4: D6220046 03FD0146 00006400
	v_sad_u8 v82, v75, 0, 0x6400                               // 000000A37F00: D6220052 03FD014B 00006400
	v_mov_b32_e32 v75, v73                                     // 000000A37F0C: 7E960349
	v_sad_u8 v79, v68, 0, 0x6400                               // 000000A37F10: D622004F 03FD0144 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A37F1C: BF870214
	v_lshl_or_b32 v71, v70, 16, v71                            // 000000A37F20: D6560047 051D2146
	v_and_or_b32 v78, 0xffff, v82, v78                         // 000000A37F28: D657004E 053AA4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A37F34: BF8701A2
	v_pk_fma_f16 v71, v71, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37F38: CC0E0047 0BFC0D47 0000C931
	v_and_b32_e32 v67, 0xffff, v67                             // 000000A37F44: 368686FF 0000FFFF
	v_pk_fma_f16 v72, v78, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37F4C: CC0E0048 0BFC0D4E 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A37F58: BF870092
	.long 0xd72c0043                                           // 000000A37F5C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A37F60: 020286FF 83DCD12D
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A37F68: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000A37F74: BF8701D1
	v_lshlrev_b32_e32 v81, 16, v67                             // 000000A37F78: 30A28690
	ds_load_2addr_b32 v[67:68], v66 offset0:206 offset1:239    // 000000A37F7C: D8DCEFCE 43000042
	v_and_or_b32 v73, 0xffff, v79, v81                         // 000000A37F84: D6570049 05469EFF 0000FFFF
	v_pk_fma_f16 v79, v69, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37F90: CC0E004F 0BFC0D45 0000C931
	.long 0xd73d0045                                           // 000000A37F9C: D73D0045
	v_cndmask_b32_e32 v1, v45, v74, vcc_lo                     // 000000A37FA0: 0202952D
	v_pk_fma_f16 v70, v73, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A37FA4: CC0E0046 0BFC0D49 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A37FB0: BF870193
	v_dot2acc_f32_f16 v30, v79, v18                            // 000000A37FB4: 043C254F
	v_bfe_u32 v73, v69, 12, 16                                 // 000000A37FB8: D6100049 02411945
	v_bfe_u32 v74, v69, 8, 16                                  // 000000A37FC0: D610004A 02411145
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A37FC8: BF870223
	v_dot2acc_f32_f16 v30, v70, v19                            // 000000A37FCC: 043C2746
	v_and_b32_e32 v70, 0xffff, v69                             // 000000A37FD0: 368C8AFF 0000FFFF
	.long 0xd72c0049                                           // 000000A37FD8: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A37FDC: 020292FF 83DCD12D
	v_bfe_u32 v69, v69, 4, 16                                  // 000000A37FE4: D6100045 02410945
	.long 0xd72c004a                                           // 000000A37FEC: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A37FF0: 020294FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A37FF8: BF89FC07
	v_bfe_u32 v75, v67, 12, 16                                 // 000000A37FFC: D610004B 02411943
	.long 0xd72c0046                                           // 000000A38004: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A38008: 02028CFF 83DCD12D
	v_bfe_u32 v78, v67, 8, 16                                  // 000000A38010: D610004E 02411143
	.long 0xd72c0045                                           // 000000A38018: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A3801C: 02028AFF 83DCD12D
	v_dot2acc_f32_f16 v30, v71, v20                            // 000000A38024: 043C2947
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A38028: D6220049 03FD0149 00006400
	.long 0xd72c004b                                           // 000000A38034: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A38038: 020296FF 83DCD12D
	.long 0xd72c0051                                           // 000000A38040: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A38044: 02029CFF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A3804C: D622004A 03FD014A 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A38058: D6220046 03FD0146 00006400
	v_and_b32_e32 v73, 0xffff, v73                             // 000000A38064: 369292FF 0000FFFF
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A3806C: D6220045 03FD0145 00006400
	v_mov_b32_e32 v78, v76                                     // 000000A38078: 7E9C034C
	v_bfe_u32 v79, v67, 4, 16                                  // 000000A3807C: D610004F 02410943
	v_lshlrev_b32_e32 v70, 16, v70                             // 000000A38084: 308C8C90
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A38088: D622004B 03FD014B 00006400
	v_lshl_or_b32 v73, v74, 16, v73                            // 000000A38094: D6560049 0525214A
	v_sad_u8 v76, v81, 0, 0x6400                               // 000000A3809C: D622004C 03FD0151 00006400
	.long 0xd72c004f                                           // 000000A380A8: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A380AC: 02029EFF 83DCD12D
	v_and_or_b32 v74, 0xffff, v69, v70                         // 000000A380B4: D657004A 051A8AFF 0000FFFF
	.long 0xd73d0045                                           // 000000A380C0: D73D0045
	v_cndmask_b32_e32 v1, v45, v77, vcc_lo                     // 000000A380C4: 02029B2D
	v_and_b32_e32 v75, 0xffff, v75                             // 000000A380C8: 369696FF 0000FFFF
	v_pk_fma_f16 v71, v73, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A380D0: CC0E0047 0BFC0D49 0000C931
	v_bfe_u32 v78, v68, 12, 16                                 // 000000A380DC: D610004E 02411944
	v_pk_fma_f16 v73, v74, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A380E4: CC0E0049 0BFC0D4A 0000C931
	v_and_b32_e32 v67, 0xffff, v67                             // 000000A380F0: 368686FF 0000FFFF
	v_bfe_u32 v74, v69, 12, 16                                 // 000000A380F8: D610004A 02411945
	v_lshl_or_b32 v70, v76, 16, v75                            // 000000A38100: D6560046 052D214C
	v_and_b32_e32 v76, 0xffff, v69                             // 000000A38108: 36988AFF 0000FFFF
	v_bfe_u32 v77, v69, 8, 16                                  // 000000A38110: D610004D 02411145
	v_bfe_u32 v69, v69, 4, 16                                  // 000000A38118: D6100045 02410945
	.long 0xd72c004a                                           // 000000A38120: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A38124: 020294FF 83DCD12D
	v_sad_u8 v75, v79, 0, 0x6400                               // 000000A3812C: D622004B 03FD014F 00006400
	.long 0xd72c004c                                           // 000000A38138: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A3813C: 020298FF 83DCD12D
	.long 0xd72c004d                                           // 000000A38144: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A38148: 02029AFF 83DCD12D
	.long 0xd72c0045                                           // 000000A38150: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A38154: 02028AFF 83DCD12D
	v_bfe_u32 v79, v68, 8, 16                                  // 000000A3815C: D610004F 02411144
	.long 0xd72c004e                                           // 000000A38164: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A38168: 02029CFF 83DCD12D
	v_bfe_u32 v81, v68, 4, 16                                  // 000000A38170: D6100051 02410944
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A38178: D622004A 03FD014A 00006400
	v_and_b32_e32 v68, 0xffff, v68                             // 000000A38184: 368888FF 0000FFFF
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A3818C: D622004C 03FD014C 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A38198: D622004D 03FD014D 00006400
	.long 0xd72c0043                                           // 000000A381A4: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A381A8: 020286FF 83DCD12D
	v_and_b32_e32 v74, 0xffff, v74                             // 000000A381B0: 369494FF 0000FFFF
	.long 0xd72c004f                                           // 000000A381B8: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A381BC: 02029EFF 83DCD12D
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A381C4: D6220045 03FD0145 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 000000A381D0: 30989890
	.long 0xd72c0044                                           // 000000A381D4: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A381D8: 020288FF 83DCD12D
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A381E0: D622004E 03FD014E 00006400
	v_lshl_or_b32 v74, v77, 16, v74                            // 000000A381EC: D656004A 0529214D
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A381F4: D6220043 03FD0143 00006400
	v_and_or_b32 v69, 0xffff, v69, v76                         // 000000A38200: D6570045 05328AFF 0000FFFF
	.long 0xd72c004c                                           // 000000A3820C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A38210: 0202A2FF 83DCD12D
	v_and_b32_e32 v77, 0xffff, v78                             // 000000A38218: 369A9CFF 0000FFFF
	v_sad_u8 v78, v79, 0, 0x6400                               // 000000A38220: D622004E 03FD014F 00006400
	v_dot2acc_f32_f16 v29, v71, v18                            // 000000A3822C: 043A2547
	v_pk_fma_f16 v71, v74, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A38230: CC0E0047 0BFC0D4A 0000C931
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A3823C: D6220044 03FD0144 00006400
	v_lshlrev_b32_e32 v67, 16, v67                             // 000000A38248: 30868690
	v_pk_fma_f16 v69, v69, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A3824C: CC0E0045 0BFC0D45 0000C931
	v_lshl_or_b32 v74, v78, 16, v77                            // 000000A38258: D656004A 0535214E
	v_dot2acc_f32_f16 v1, v71, v18                             // 000000A38260: 04022547
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A38264: D622004C 03FD014C 00006400
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000A38270: 30888890
	v_pk_fma_f16 v70, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A38274: CC0E0046 0BFC0D46 0000C931
	v_and_or_b32 v18, 0xffff, v75, v67                         // 000000A38280: D6570012 050E96FF 0000FFFF
	v_dot2acc_f32_f16 v29, v73, v19                            // 000000A3828C: 043A2749
	v_pk_fma_f16 v67, v74, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A38290: CC0E0043 0BFC0D4A 0000C931
	v_dot2acc_f32_f16 v1, v69, v19                             // 000000A3829C: 04022745
	v_and_or_b32 v68, 0xffff, v76, v68                         // 000000A382A0: D6570044 051298FF 0000FFFF
	v_pk_fma_f16 v18, v18, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A382AC: CC0E0012 0BFC0D12 0000C931
	v_dual_dot2acc_f32_f16 v29, v70, v20 :: v_dual_dot2acc_f32_f16 v30, v72, v21// 000000A382B8: CB182946 1D1E2B48
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A382C0: BF870234
	v_dot2acc_f32_f16 v1, v67, v20                             // 000000A382C4: 04022943
	v_add_nc_u32_e32 v20, v47, v48                             // 000000A382C8: 4A28612F
	v_pk_fma_f16 v19, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000A382CC: CC0E0013 0BFC0D44 0000C931
	v_dot2acc_f32_f16 v29, v18, v21                            // 000000A382D8: 043A2B12
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A382DC: BF870193
	.long 0xd44a0000                                           // 000000A382E0: D44A0000
	v_cndmask_b32_e32 v1, 21, v20, vcc_lo                      // 000000A382E4: 02022895
	v_dot2acc_f32_f16 v1, v19, v21                             // 000000A382E8: 04022B13
	s_or_b32 s5, s0, s5                                        // 000000A382EC: 8C050500
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A382F0: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000A382F4: 917E057E
	s_cbranch_execz 257                                        // 000000A382F8: BFA50101 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4700>
	s_waitcnt vmcnt(15)                                        // 000000A382FC: BF893FF7
	ds_store_b32 v44, v2 offset:5120                           // 000000A38300: D8341400 0000022C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38308: BE80206A
	s_cbranch_execnz 131                                       // 000000A3830C: BFA60083 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x451c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38310: 8C7E007E
	s_waitcnt vmcnt(14)                                        // 000000A38314: BF893BF7
	ds_store_b32 v44, v3 offset:5252                           // 000000A38318: D8341484 0000032C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38320: BE80206A
	s_cbranch_execnz 133                                       // 000000A38324: BFA60085 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x453c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38328: 8C7E007E
	s_waitcnt vmcnt(13)                                        // 000000A3832C: BF8937F7
	ds_store_b32 v44, v4 offset:5384                           // 000000A38330: D8341508 0000042C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38338: BE80206A
	s_cbranch_execnz 135                                       // 000000A3833C: BFA60087 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x455c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38340: 8C7E007E
	s_waitcnt vmcnt(12)                                        // 000000A38344: BF8933F7
	ds_store_b32 v44, v5 offset:5516                           // 000000A38348: D834158C 0000052C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38350: BE80206A
	s_cbranch_execnz 137                                       // 000000A38354: BFA60089 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x457c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38358: 8C7E007E
	s_waitcnt vmcnt(11)                                        // 000000A3835C: BF892FF7
	ds_store_b32 v44, v6 offset:5648                           // 000000A38360: D8341610 0000062C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38368: BE80206A
	s_cbranch_execnz 139                                       // 000000A3836C: BFA6008B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x459c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38370: 8C7E007E
	s_waitcnt vmcnt(10)                                        // 000000A38374: BF892BF7
	ds_store_b32 v44, v7 offset:5780                           // 000000A38378: D8341694 0000072C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38380: BE80206A
	s_cbranch_execnz 141                                       // 000000A38384: BFA6008D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x45bc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38388: 8C7E007E
	s_waitcnt vmcnt(9)                                         // 000000A3838C: BF8927F7
	ds_store_b32 v44, v8 offset:5912                           // 000000A38390: D8341718 0000082C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38398: BE80206A
	s_cbranch_execnz 143                                       // 000000A3839C: BFA6008F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x45dc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A383A0: 8C7E007E
	s_waitcnt vmcnt(8)                                         // 000000A383A4: BF8923F7
	ds_store_b32 v44, v9 offset:6044                           // 000000A383A8: D834179C 0000092C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A383B0: BE80206A
	s_cbranch_execnz 145                                       // 000000A383B4: BFA60091 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x45fc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A383B8: 8C7E007E
	s_waitcnt vmcnt(7)                                         // 000000A383BC: BF891FF7
	ds_store_b32 v44, v10 offset:6176                          // 000000A383C0: D8341820 00000A2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A383C8: BE80206A
	s_cbranch_execnz 147                                       // 000000A383CC: BFA60093 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x461c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A383D0: 8C7E007E
	s_waitcnt vmcnt(6)                                         // 000000A383D4: BF891BF7
	ds_store_b32 v44, v11 offset:6308                          // 000000A383D8: D83418A4 00000B2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A383E0: BE80206A
	s_cbranch_execnz 149                                       // 000000A383E4: BFA60095 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x463c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A383E8: 8C7E007E
	s_waitcnt vmcnt(5)                                         // 000000A383EC: BF8917F7
	ds_store_b32 v44, v12 offset:6440                          // 000000A383F0: D8341928 00000C2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A383F8: BE80206A
	s_cbranch_execnz 151                                       // 000000A383FC: BFA60097 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x465c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38400: 8C7E007E
	s_waitcnt vmcnt(4)                                         // 000000A38404: BF8913F7
	ds_store_b32 v44, v13 offset:6572                          // 000000A38408: D83419AC 00000D2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38410: BE80206A
	s_cbranch_execnz 153                                       // 000000A38414: BFA60099 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x467c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38418: 8C7E007E
	s_waitcnt vmcnt(3)                                         // 000000A3841C: BF890FF7
	ds_store_b32 v44, v14 offset:6704                          // 000000A38420: D8341A30 00000E2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38428: BE80206A
	s_cbranch_execnz 155                                       // 000000A3842C: BFA6009B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x469c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38430: 8C7E007E
	s_waitcnt vmcnt(2)                                         // 000000A38434: BF890BF7
	ds_store_b32 v44, v15 offset:6836                          // 000000A38438: D8341AB4 00000F2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38440: BE80206A
	s_cbranch_execnz 157                                       // 000000A38444: BFA6009D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x46bc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38448: 8C7E007E
	s_waitcnt vmcnt(1)                                         // 000000A3844C: BF8907F7
	ds_store_b32 v44, v16 offset:6968                          // 000000A38450: D8341B38 0000102C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38458: BE80206A
	s_cbranch_execnz 159                                       // 000000A3845C: BFA6009F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x46dc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38460: 8C7E007E
	s_waitcnt vmcnt(0)                                         // 000000A38464: BF8903F7
	ds_store_b32 v44, v17 offset:7100                          // 000000A38468: D8341BBC 0000112C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38470: BE80206A
	ds_store_b32 v43, v17 offset:7228                          // 000000A38474: D8341C3C 0000112B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A3847C: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A38480: BF870009
	s_mov_b32 s1, exec_lo                                      // 000000A38484: BE81007E
	.long 0xd4c9007e                                           // 000000A38488: D4C9007E
	v_cndmask_b32_e32 v1, v48, v27, vcc_lo                     // 000000A3848C: 02023730
	s_cbranch_execz 63702                                      // 000000A38490: BFA5F8D6 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x27ec>
	s_clause 0xf                                               // 000000A38494: BF85000F
	global_load_b32 v2, v[22:23], off                          // 000000A38498: DC520000 027C0016
	global_load_b32 v3, v[22:23], off offset:128               // 000000A384A0: DC520080 037C0016
	global_load_b32 v4, v[22:23], off offset:256               // 000000A384A8: DC520100 047C0016
	global_load_b32 v5, v[22:23], off offset:384               // 000000A384B0: DC520180 057C0016
	global_load_b32 v6, v[22:23], off offset:512               // 000000A384B8: DC520200 067C0016
	global_load_b32 v7, v[22:23], off offset:640               // 000000A384C0: DC520280 077C0016
	global_load_b32 v8, v[22:23], off offset:768               // 000000A384C8: DC520300 087C0016
	global_load_b32 v9, v[22:23], off offset:896               // 000000A384D0: DC520380 097C0016
	global_load_b32 v10, v[22:23], off offset:1024             // 000000A384D8: DC520400 0A7C0016
	global_load_b32 v11, v[22:23], off offset:1152             // 000000A384E0: DC520480 0B7C0016
	global_load_b32 v12, v[22:23], off offset:1280             // 000000A384E8: DC520500 0C7C0016
	global_load_b32 v13, v[22:23], off offset:1408             // 000000A384F0: DC520580 0D7C0016
	global_load_b32 v14, v[22:23], off offset:1536             // 000000A384F8: DC520600 0E7C0016
	global_load_b32 v15, v[22:23], off offset:1664             // 000000A38500: DC520680 0F7C0016
	global_load_b32 v16, v[22:23], off offset:1792             // 000000A38508: DC520700 107C0016
	global_load_b32 v17, v[22:23], off offset:1920             // 000000A38510: DC520780 117C0016
	s_branch 63668                                             // 000000A38518: BFA0F8B4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x27ec>
	ds_store_b32 v43, v2 offset:5248                           // 000000A3851C: D8341480 0000022B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38524: 8C7E007E
	s_waitcnt vmcnt(14)                                        // 000000A38528: BF893BF7
	ds_store_b32 v44, v3 offset:5252                           // 000000A3852C: D8341484 0000032C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38534: BE80206A
	s_cbranch_execz 65403                                      // 000000A38538: BFA5FF7B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4328>
	ds_store_b32 v43, v3 offset:5380                           // 000000A3853C: D8341504 0000032B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38544: 8C7E007E
	s_waitcnt vmcnt(13)                                        // 000000A38548: BF8937F7
	ds_store_b32 v44, v4 offset:5384                           // 000000A3854C: D8341508 0000042C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38554: BE80206A
	s_cbranch_execz 65401                                      // 000000A38558: BFA5FF79 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4340>
	ds_store_b32 v43, v4 offset:5512                           // 000000A3855C: D8341588 0000042B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38564: 8C7E007E
	s_waitcnt vmcnt(12)                                        // 000000A38568: BF8933F7
	ds_store_b32 v44, v5 offset:5516                           // 000000A3856C: D834158C 0000052C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38574: BE80206A
	s_cbranch_execz 65399                                      // 000000A38578: BFA5FF77 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4358>
	ds_store_b32 v43, v5 offset:5644                           // 000000A3857C: D834160C 0000052B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38584: 8C7E007E
	s_waitcnt vmcnt(11)                                        // 000000A38588: BF892FF7
	ds_store_b32 v44, v6 offset:5648                           // 000000A3858C: D8341610 0000062C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38594: BE80206A
	s_cbranch_execz 65397                                      // 000000A38598: BFA5FF75 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4370>
	ds_store_b32 v43, v6 offset:5776                           // 000000A3859C: D8341690 0000062B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A385A4: 8C7E007E
	s_waitcnt vmcnt(10)                                        // 000000A385A8: BF892BF7
	ds_store_b32 v44, v7 offset:5780                           // 000000A385AC: D8341694 0000072C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A385B4: BE80206A
	s_cbranch_execz 65395                                      // 000000A385B8: BFA5FF73 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4388>
	ds_store_b32 v43, v7 offset:5908                           // 000000A385BC: D8341714 0000072B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A385C4: 8C7E007E
	s_waitcnt vmcnt(9)                                         // 000000A385C8: BF8927F7
	ds_store_b32 v44, v8 offset:5912                           // 000000A385CC: D8341718 0000082C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A385D4: BE80206A
	s_cbranch_execz 65393                                      // 000000A385D8: BFA5FF71 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x43a0>
	ds_store_b32 v43, v8 offset:6040                           // 000000A385DC: D8341798 0000082B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A385E4: 8C7E007E
	s_waitcnt vmcnt(8)                                         // 000000A385E8: BF8923F7
	ds_store_b32 v44, v9 offset:6044                           // 000000A385EC: D834179C 0000092C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A385F4: BE80206A
	s_cbranch_execz 65391                                      // 000000A385F8: BFA5FF6F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x43b8>
	ds_store_b32 v43, v9 offset:6172                           // 000000A385FC: D834181C 0000092B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38604: 8C7E007E
	s_waitcnt vmcnt(7)                                         // 000000A38608: BF891FF7
	ds_store_b32 v44, v10 offset:6176                          // 000000A3860C: D8341820 00000A2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38614: BE80206A
	s_cbranch_execz 65389                                      // 000000A38618: BFA5FF6D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x43d0>
	ds_store_b32 v43, v10 offset:6304                          // 000000A3861C: D83418A0 00000A2B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38624: 8C7E007E
	s_waitcnt vmcnt(6)                                         // 000000A38628: BF891BF7
	ds_store_b32 v44, v11 offset:6308                          // 000000A3862C: D83418A4 00000B2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38634: BE80206A
	s_cbranch_execz 65387                                      // 000000A38638: BFA5FF6B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x43e8>
	ds_store_b32 v43, v11 offset:6436                          // 000000A3863C: D8341924 00000B2B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38644: 8C7E007E
	s_waitcnt vmcnt(5)                                         // 000000A38648: BF8917F7
	ds_store_b32 v44, v12 offset:6440                          // 000000A3864C: D8341928 00000C2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38654: BE80206A
	s_cbranch_execz 65385                                      // 000000A38658: BFA5FF69 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4400>
	ds_store_b32 v43, v12 offset:6568                          // 000000A3865C: D83419A8 00000C2B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38664: 8C7E007E
	s_waitcnt vmcnt(4)                                         // 000000A38668: BF8913F7
	ds_store_b32 v44, v13 offset:6572                          // 000000A3866C: D83419AC 00000D2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38674: BE80206A
	s_cbranch_execz 65383                                      // 000000A38678: BFA5FF67 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4418>
	ds_store_b32 v43, v13 offset:6700                          // 000000A3867C: D8341A2C 00000D2B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A38684: 8C7E007E
	s_waitcnt vmcnt(3)                                         // 000000A38688: BF890FF7
	ds_store_b32 v44, v14 offset:6704                          // 000000A3868C: D8341A30 00000E2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A38694: BE80206A
	s_cbranch_execz 65381                                      // 000000A38698: BFA5FF65 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4430>
	ds_store_b32 v43, v14 offset:6832                          // 000000A3869C: D8341AB0 00000E2B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A386A4: 8C7E007E
	s_waitcnt vmcnt(2)                                         // 000000A386A8: BF890BF7
	ds_store_b32 v44, v15 offset:6836                          // 000000A386AC: D8341AB4 00000F2C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A386B4: BE80206A
	s_cbranch_execz 65379                                      // 000000A386B8: BFA5FF63 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4448>
	ds_store_b32 v43, v15 offset:6964                          // 000000A386BC: D8341B34 00000F2B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A386C4: 8C7E007E
	s_waitcnt vmcnt(1)                                         // 000000A386C8: BF8907F7
	ds_store_b32 v44, v16 offset:6968                          // 000000A386CC: D8341B38 0000102C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A386D4: BE80206A
	s_cbranch_execz 65377                                      // 000000A386D8: BFA5FF61 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4460>
	ds_store_b32 v43, v16 offset:7096                          // 000000A386DC: D8341BB8 0000102B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A386E4: 8C7E007E
	s_waitcnt vmcnt(0)                                         // 000000A386E8: BF8903F7
	ds_store_b32 v44, v17 offset:7100                          // 000000A386EC: D8341BBC 0000112C
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A386F4: BE80206A
	s_cbranch_execnz 65374                                     // 000000A386F8: BFA6FF5E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4474>
	s_branch 65375                                             // 000000A386FC: BFA0FF5F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x447c>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000A38700: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A38704: BF870009
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A38708: 8C7E047E
	s_waitcnt vmcnt(14)                                        // 000000A3870C: BF893BF7
	v_dual_mov_b32 v2, v28 :: v_dual_mov_b32 v3, v42           // 000000A38710: CA10011C 0202012A
	s_waitcnt vmcnt(12)                                        // 000000A38718: BF8933F7
	v_dual_mov_b32 v4, v41 :: v_dual_mov_b32 v5, v40           // 000000A3871C: CA100129 04040128
	s_waitcnt vmcnt(10)                                        // 000000A38724: BF892BF7
	v_dual_mov_b32 v6, v39 :: v_dual_mov_b32 v7, v38           // 000000A38728: CA100127 06060126
	s_waitcnt vmcnt(8)                                         // 000000A38730: BF8923F7
	v_dual_mov_b32 v8, v37 :: v_dual_mov_b32 v9, v36           // 000000A38734: CA100125 08080124
	s_waitcnt vmcnt(6)                                         // 000000A3873C: BF891BF7
	v_dual_mov_b32 v10, v35 :: v_dual_mov_b32 v11, v34         // 000000A38740: CA100123 0A0A0122
	s_waitcnt vmcnt(4)                                         // 000000A38748: BF8913F7
	v_dual_mov_b32 v12, v33 :: v_dual_mov_b32 v13, v32         // 000000A3874C: CA100121 0C0C0120
	s_waitcnt vmcnt(2)                                         // 000000A38754: BF890BF7
	v_dual_mov_b32 v14, v31 :: v_dual_mov_b32 v15, v30         // 000000A38758: CA10011F 0E0E011E
	s_waitcnt vmcnt(1)                                         // 000000A38760: BF8907F7
	v_mov_b32_e32 v16, v29                                     // 000000A38764: 7E20031D
	s_waitcnt vmcnt(0)                                         // 000000A38768: BF8903F7
	v_mov_b32_e32 v17, v1                                      // 000000A3876C: 7E220301
	s_mov_b32 s0, 0x76543210                                   // 000000A38770: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A38778: BF870009
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000A3877C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000A38788: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000A38794: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000A387A0: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000A387AC: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000A387B8: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000A387C4: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000A387D0: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000A387DC: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000A387E8: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000A387F4: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000A38800: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000A3880C: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000A38818: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000A38824: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000A38830: D65C0011 03FC0111 FEDCBA98
	.long 0xd44c0000                                           // 000000A3883C: D44C0000
	v_cndmask_b32_e32 v1, 16, v25, vcc_lo                      // 000000A38840: 02023290
	s_barrier                                                  // 000000A38844: BFBD0000
	buffer_gl0_inv                                             // 000000A38848: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000A38850: BE812000
	s_cbranch_execz 34                                         // 000000A38854: BFA50022 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x48e0>
	v_dual_add_f32 v1, v1, v17 :: v_dual_add_f32 v2, v28, v2   // 000000A38858: C9082301 0102051C
	v_dual_add_f32 v3, v42, v3 :: v_dual_add_f32 v4, v41, v4   // 000000A38860: C908072A 03040929
	v_lshl_or_b32 v17, v24, 10, v26                            // 000000A38868: D6560011 04691518
	v_dual_add_f32 v5, v40, v5 :: v_dual_add_f32 v6, v39, v6   // 000000A38870: C9080B28 05060D27
	v_dual_add_f32 v7, v38, v7 :: v_dual_add_f32 v8, v37, v8   // 000000A38878: C9080F26 07081125
	v_dual_add_f32 v9, v36, v9 :: v_dual_add_f32 v10, v35, v10 // 000000A38880: C9081324 090A1523
	v_dual_add_f32 v11, v34, v11 :: v_dual_add_f32 v12, v33, v12// 000000A38888: C9081722 0B0C1921
	v_dual_add_f32 v13, v32, v13 :: v_dual_add_f32 v14, v31, v14// 000000A38890: C9081B20 0D0E1D1F
	v_dual_add_f32 v15, v30, v15 :: v_dual_add_f32 v16, v29, v16// 000000A38898: C9081F1E 0F10211D
	ds_store_2addr_b32 v17, v2, v3 offset1:16                  // 000000A388A0: D8381000 00030211
	ds_store_2addr_b32 v17, v4, v5 offset0:32 offset1:48       // 000000A388A8: D8383020 00050411
	ds_store_2addr_b32 v17, v6, v7 offset0:64 offset1:80       // 000000A388B0: D8385040 00070611
	ds_store_2addr_b32 v17, v8, v9 offset0:96 offset1:112      // 000000A388B8: D8387060 00090811
	ds_store_2addr_b32 v17, v10, v11 offset0:128 offset1:144   // 000000A388C0: D8389080 000B0A11
	ds_store_2addr_b32 v17, v12, v13 offset0:160 offset1:176   // 000000A388C8: D838B0A0 000D0C11
	ds_store_2addr_b32 v17, v14, v15 offset0:192 offset1:208   // 000000A388D0: D838D0C0 000F0E11
	ds_store_2addr_b32 v17, v16, v1 offset0:224 offset1:240    // 000000A388D8: D838F0E0 00011011
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A388E0: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 000000A388E4: BF89FC07
	s_barrier                                                  // 000000A388E8: BFBD0000
	buffer_gl0_inv                                             // 000000A388EC: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 000000A388F4: BE81007E
	v_cmpx_eq_u32_e32 0, v24                                   // 000000A388F8: 7D943080
	s_cbranch_execz 1333                                       // 000000A388FC: BFA50535 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x5dd4>
	v_and_b32_e32 v3, 15, v0                                   // 000000A38900: 3606008F
	s_mul_i32 s1, s3, 0xa00                                    // 000000A38904: 9601FF03 00000A00
	s_mul_hi_i32 s4, s3, 0xa00                                 // 000000A3890C: 9704FF03 00000A00
	s_add_u32 s1, s18, s1                                      // 000000A38914: 80010112
	s_addc_u32 s7, s19, s4                                     // 000000A38918: 82070413
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000A3891C: 30080682
	s_lshl_b32 s4, s2, 7                                       // 000000A38920: 84048702
	s_mul_hi_i32 s2, s3, 0x500                                 // 000000A38924: 9702FF03 00000500
	s_ashr_i32 s5, s4, 31                                      // 000000A3892C: 86059F04
	ds_load_2addr_b32 v[1:2], v4 offset1:16                    // 000000A38930: D8DC1000 01000004
	ds_load_2addr_b32 v[5:6], v4 offset0:128 offset1:144       // 000000A38938: D8DC9080 05000004
	s_lshl_b64 s[12:13], s[4:5], 1                             // 000000A38940: 848C8104
	v_lshlrev_b32_e32 v52, 1, v0                               // 000000A38944: 30680081
	s_add_u32 s6, s1, s12                                      // 000000A38948: 80060C01
	s_addc_u32 s7, s7, s13                                     // 000000A3894C: 82070D07
	s_mul_i32 s1, s3, 0x500                                    // 000000A38950: 9601FF03 00000500
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A38958: BF870009
	s_add_u32 s1, s20, s1                                      // 000000A3895C: 80010114
	s_addc_u32 s2, s21, s2                                     // 000000A38960: 82020215
	s_add_u32 s8, s1, s12                                      // 000000A38964: 80080C01
	s_addc_u32 s9, s2, s13                                     // 000000A38968: 82090D02
	s_waitcnt lgkmcnt(1)                                       // 000000A3896C: BF89FC17
	v_add_f32_e32 v1, 0, v1                                    // 000000A38970: 06020280
	v_add_nc_u32_e32 v45, 0x400, v4                            // 000000A38974: 4A5A08FF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000A3897C: BF89FC07
	v_dual_add_f32 v5, 0, v5 :: v_dual_add_nc_u32 v46, 0x800, v4// 000000A38980: C9200A80 052E08FF 00000800
	v_add_nc_u32_e32 v47, 0xc00, v4                            // 000000A3898C: 4A5E08FF 00000C00
	v_add_nc_u32_e32 v48, 0x1000, v4                           // 000000A38994: 4A6008FF 00001000
	v_add_nc_u32_e32 v49, 0x1400, v4                           // 000000A3899C: 4A6208FF 00001400
	v_add_nc_u32_e32 v50, 0x1800, v4                           // 000000A389A4: 4A6408FF 00001800
	v_add_nc_u32_e32 v51, 0x1c00, v4                           // 000000A389AC: 4A6608FF 00001C00
	ds_load_2addr_b32 v[7:8], v45 offset1:16                   // 000000A389B4: D8DC1000 0700002D
	ds_load_2addr_b32 v[9:10], v4 offset0:32 offset1:48        // 000000A389BC: D8DC3020 09000004
	ds_load_2addr_b32 v[11:12], v4 offset0:160 offset1:176     // 000000A389C4: D8DCB0A0 0B000004
	ds_load_2addr_b32 v[13:14], v45 offset0:128 offset1:144    // 000000A389CC: D8DC9080 0D00002D
	ds_load_2addr_b32 v[15:16], v46 offset1:16                 // 000000A389D4: D8DC1000 0F00002E
	ds_load_2addr_b32 v[17:18], v46 offset0:128 offset1:144    // 000000A389DC: D8DC9080 1100002E
	ds_load_2addr_b32 v[19:20], v47 offset1:16                 // 000000A389E4: D8DC1000 1300002F
	ds_load_2addr_b32 v[21:22], v47 offset0:128 offset1:144    // 000000A389EC: D8DC9080 1500002F
	ds_load_2addr_b32 v[23:24], v48 offset1:16                 // 000000A389F4: D8DC1000 17000030
	ds_load_2addr_b32 v[25:26], v48 offset0:128 offset1:144    // 000000A389FC: D8DC9080 19000030
	ds_load_2addr_b32 v[27:28], v49 offset1:16                 // 000000A38A04: D8DC1000 1B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:128 offset1:144    // 000000A38A0C: D8DC9080 1D000031
	ds_load_2addr_b32 v[31:32], v50 offset1:16                 // 000000A38A14: D8DC1000 1F000032
	ds_load_2addr_b32 v[33:34], v50 offset0:128 offset1:144    // 000000A38A1C: D8DC9080 21000032
	ds_load_2addr_b32 v[35:36], v51 offset1:16                 // 000000A38A24: D8DC1000 23000033
	v_add_f32_e32 v2, 0, v2                                    // 000000A38A2C: 06040480
	ds_load_2addr_b32 v[43:44], v46 offset0:32 offset1:48      // 000000A38A30: D8DC3020 2B00002E
	s_waitcnt lgkmcnt(15)                                      // 000000A38A38: BF89FCF7
	v_add_f32_e32 v1, v1, v7                                   // 000000A38A3C: 06020F01
	v_dual_add_f32 v7, 0, v6 :: v_dual_add_f32 v2, v2, v8      // 000000A38A40: C9080C80 07021102
	s_waitcnt lgkmcnt(12)                                      // 000000A38A48: BF89FCC7
	v_add_f32_e32 v13, v5, v13                                 // 000000A38A4C: 061A1B05
	ds_load_2addr_b32 v[5:6], v46 offset0:160 offset1:176      // 000000A38A50: D8DCB0A0 0500002E
	s_waitcnt lgkmcnt(12)                                      // 000000A38A58: BF89FCC7
	v_dual_add_f32 v1, v1, v15 :: v_dual_add_f32 v14, v7, v14  // 000000A38A5C: C9081F01 010E1D07
	s_waitcnt lgkmcnt(11)                                      // 000000A38A64: BF89FCB7
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v13, v13, v17 // 000000A38A68: C9082102 020C230D
	ds_load_2addr_b32 v[15:16], v48 offset0:32 offset1:48      // 000000A38A70: D8DC3020 0F000030
	v_add_f32_e32 v14, v14, v18                                // 000000A38A78: 061C250E
	s_waitcnt lgkmcnt(11)                                      // 000000A38A7C: BF89FCB7
	v_dual_add_f32 v2, v2, v20 :: v_dual_add_f32 v1, v1, v19   // 000000A38A80: C9082902 02002701
	ds_load_2addr_b32 v[7:8], v47 offset0:32 offset1:48        // 000000A38A88: D8DC3020 0700002F
	ds_load_2addr_b32 v[17:18], v48 offset0:160 offset1:176    // 000000A38A90: D8DCB0A0 11000030
	s_waitcnt lgkmcnt(12)                                      // 000000A38A98: BF89FCC7
	v_add_f32_e32 v14, v14, v22                                // 000000A38A9C: 061C2D0E
	s_waitcnt lgkmcnt(11)                                      // 000000A38AA0: BF89FCB7
	v_dual_add_f32 v2, v2, v24 :: v_dual_add_f32 v1, v1, v23   // 000000A38AA4: C9083102 02002F01
	ds_load_2addr_b32 v[19:20], v49 offset0:32 offset1:48      // 000000A38AAC: D8DC3020 13000031
	s_waitcnt lgkmcnt(11)                                      // 000000A38AB4: BF89FCB7
	v_add_f32_e32 v14, v14, v26                                // 000000A38AB8: 061C350E
	ds_load_2addr_b32 v[37:38], v51 offset0:128 offset1:144    // 000000A38ABC: D8DC9080 25000033
	ds_load_2addr_b32 v[39:40], v45 offset0:32 offset1:48      // 000000A38AC4: D8DC3020 2700002D
	ds_load_2addr_b32 v[41:42], v45 offset0:160 offset1:176    // 000000A38ACC: D8DCB0A0 2900002D
	v_add_f32_e32 v13, v13, v21                                // 000000A38AD4: 061A2B0D
	s_waitcnt lgkmcnt(13)                                      // 000000A38AD8: BF89FCD7
	v_add_f32_e32 v1, v1, v27                                  // 000000A38ADC: 06023701
	v_add_f32_e32 v23, v2, v28                                 // 000000A38AE0: 062E3902
	s_waitcnt lgkmcnt(12)                                      // 000000A38AE4: BF89FCC7
	v_dual_add_f32 v24, v14, v30 :: v_dual_add_f32 v9, 0, v9   // 000000A38AE8: C9083D0E 18081280
	ds_load_2addr_b32 v[21:22], v49 offset0:160 offset1:176    // 000000A38AF0: D8DCB0A0 15000031
	v_add_f32_e32 v11, 0, v11                                  // 000000A38AF8: 06161680
	s_waitcnt lgkmcnt(11)                                      // 000000A38AFC: BF89FCB7
	v_dual_add_f32 v1, v1, v31 :: v_dual_add_f32 v26, v24, v34 // 000000A38B00: C9083F01 011A4518
	s_waitcnt lgkmcnt(3)                                       // 000000A38B08: BF89FC37
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A38B0C: BF870001
	v_dual_add_f32 v13, v13, v25 :: v_dual_add_f32 v54, v26, v38// 000000A38B10: C908330D 0D364D1A
	s_waitcnt lgkmcnt(2)                                       // 000000A38B18: BF89FC27
	v_add_f32_e32 v9, v9, v39                                  // 000000A38B1C: 06124F09
	v_add_f32_e32 v39, v1, v35                                 // 000000A38B20: 064E4701
	v_lshlrev_b32_e32 v1, 1, v3                                // 000000A38B24: 30020681
	s_waitcnt lgkmcnt(1)                                       // 000000A38B28: BF89FC17
	v_add_f32_e32 v3, v11, v41                                 // 000000A38B2C: 0606530B
	v_add_f32_e32 v11, v23, v32                                // 000000A38B30: 06164117
	v_add_f32_e32 v9, v9, v43                                  // 000000A38B34: 06125709
	ds_load_2addr_b32 v[23:24], v50 offset0:32 offset1:48      // 000000A38B38: D8DC3020 17000032
	v_or_b32_e32 v41, 32, v52                                  // 000000A38B40: 385268A0
	v_add_f32_e32 v5, v3, v5                                   // 000000A38B44: 060A0B03
	v_add_f32_e32 v53, v11, v36                                // 000000A38B48: 066A490B
	v_add_f32_e32 v7, v9, v7                                   // 000000A38B4C: 060E0F09
	global_load_d16_b16 v3, v41, s[6:7]                        // 000000A38B50: DC820000 03060029
	v_add_f32_e32 v7, v7, v15                                  // 000000A38B58: 060E1F07
	v_add_f32_e32 v15, 0, v12                                  // 000000A38B5C: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:192 offset1:208     // 000000A38B60: D8DCD0C0 0B000004
	ds_load_2addr_b32 v[27:28], v51 offset0:32 offset1:48      // 000000A38B68: D8DC3020 1B000033
	v_add_f32_e32 v7, v7, v19                                  // 000000A38B70: 060E2707
	s_waitcnt lgkmcnt(2)                                       // 000000A38B74: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A38B78: BF870001
	v_add_f32_e32 v19, v7, v23                                 // 000000A38B7C: 06262F07
	v_add_f32_e32 v13, v13, v29                                // 000000A38B80: 061A3B0D
	ds_load_2addr_b32 v[29:30], v45 offset0:64 offset1:80      // 000000A38B84: D8DC5040 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:192 offset1:208    // 000000A38B8C: D8DCD0C0 1F00002D
	v_add_f32_e32 v25, v13, v33                                // 000000A38B94: 0632430D
	ds_load_2addr_b32 v[13:14], v47 offset0:160 offset1:176    // 000000A38B98: D8DCB0A0 0D00002F
	s_waitcnt lgkmcnt(4)                                       // 000000A38BA0: BF89FC47
	v_add_f32_e32 v11, 0, v11                                  // 000000A38BA4: 06161680
	v_add_f32_e32 v43, v25, v37                                // 000000A38BA8: 06564B19
	ds_load_2addr_b32 v[25:26], v50 offset0:160 offset1:176    // 000000A38BAC: D8DCB0A0 19000032
	ds_load_2addr_b32 v[37:38], v48 offset0:192 offset1:208    // 000000A38BB4: D8DCD0C0 25000030
	s_waitcnt lgkmcnt(3)                                       // 000000A38BBC: BF89FC37
	v_add_f32_e32 v11, v11, v31                                // 000000A38BC0: 06163F0B
	s_waitcnt lgkmcnt(2)                                       // 000000A38BC4: BF89FC27
	v_add_f32_e32 v5, v5, v13                                  // 000000A38BC8: 060A1B05
	v_add_f32_e32 v13, 0, v10                                  // 000000A38BCC: 061A1480
	ds_load_2addr_b32 v[9:10], v4 offset0:64 offset1:80        // 000000A38BD0: D8DC5040 09000004
	v_add_f32_e32 v5, v5, v17                                  // 000000A38BD8: 060A2305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A38BDC: BF8701C1
	v_add_f32_e32 v17, v5, v21                                 // 000000A38BE0: 06222B05
	v_add_f32_e32 v5, v13, v40                                 // 000000A38BE4: 060A510D
	v_add_f32_e32 v13, v15, v42                                // 000000A38BE8: 061A550F
	s_waitcnt lgkmcnt(2)                                       // 000000A38BEC: BF89FC27
	v_dual_add_f32 v40, v19, v27 :: v_dual_add_f32 v21, v17, v25// 000000A38BF0: C9083713 28143311
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A38BF8: BF870193
	v_add_f32_e32 v7, v5, v44                                  // 000000A38BFC: 060E5905
	v_add_f32_e32 v13, v13, v6                                 // 000000A38C00: 061A0D0D
	ds_load_2addr_b32 v[5:6], v46 offset0:64 offset1:80        // 000000A38C04: D8DC5040 0500002E
	ds_load_2addr_b32 v[33:34], v46 offset0:192 offset1:208    // 000000A38C0C: D8DCD0C0 2100002E
	ds_load_2addr_b32 v[35:36], v51 offset0:160 offset1:176    // 000000A38C14: D8DCB0A0 23000033
	v_add_f32_e32 v15, v7, v8                                  // 000000A38C1C: 061E1107
	ds_load_2addr_b32 v[7:8], v47 offset0:64 offset1:80        // 000000A38C20: D8DC5040 0700002F
	v_add_f32_e32 v17, v13, v14                                // 000000A38C28: 06221D0D
	ds_load_2addr_b32 v[13:14], v47 offset0:192 offset1:208    // 000000A38C2C: D8DCD0C0 0D00002F
	s_waitcnt lgkmcnt(5)                                       // 000000A38C34: BF89FC57
	v_add_f32_e32 v9, 0, v9                                    // 000000A38C38: 06121280
	v_add_f32_e32 v23, v15, v16                                // 000000A38C3C: 062E210F
	ds_load_2addr_b32 v[15:16], v48 offset0:64 offset1:80      // 000000A38C40: D8DC5040 0F000030
	v_add_f32_e32 v17, v17, v18                                // 000000A38C48: 06222511
	v_add_f32_e32 v9, v9, v29                                  // 000000A38C4C: 06123B09
	v_add_f32_e32 v23, v23, v20                                // 000000A38C50: 062E2917
	ds_load_2addr_b32 v[19:20], v49 offset0:192 offset1:208    // 000000A38C54: D8DCD0C0 13000031
	v_add_f32_e32 v22, v17, v22                                // 000000A38C5C: 062C2D11
	ds_load_2addr_b32 v[17:18], v49 offset0:64 offset1:80      // 000000A38C60: D8DC5040 11000031
	s_waitcnt lgkmcnt(7)                                       // 000000A38C68: BF89FC77
	v_add_f32_e32 v5, v9, v5                                   // 000000A38C6C: 060A0B09
	s_waitcnt lgkmcnt(5)                                       // 000000A38C70: BF89FC57
	v_dual_add_f32 v9, v11, v33 :: v_dual_add_f32 v42, v21, v35// 000000A38C74: C908430B 092A4715
	v_add_f32_e32 v27, v23, v24                                // 000000A38C7C: 06363117
	v_add_f32_e32 v33, v22, v26                                // 000000A38C80: 06423516
	ds_load_2addr_b32 v[21:22], v50 offset0:64 offset1:80      // 000000A38C84: D8DC5040 15000032
	ds_load_2addr_b32 v[23:24], v50 offset0:192 offset1:208    // 000000A38C8C: D8DCD0C0 17000032
	s_waitcnt lgkmcnt(6)                                       // 000000A38C94: BF89FC67
	v_add_f32_e32 v5, v5, v7                                   // 000000A38C98: 060A0F05
	s_waitcnt lgkmcnt(5)                                       // 000000A38C9C: BF89FC57
	v_add_f32_e32 v7, v9, v13                                  // 000000A38CA0: 060E1B09
	s_waitcnt lgkmcnt(4)                                       // 000000A38CA4: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A38CA8: BF870002
	v_add_f32_e32 v13, v5, v15                                 // 000000A38CAC: 061A1F05
	v_add_f32_e32 v5, 0, v10                                   // 000000A38CB0: 060A1480
	ds_load_2addr_b32 v[9:10], v51 offset0:64 offset1:80       // 000000A38CB4: D8DC5040 09000033
	ds_load_2addr_b32 v[25:26], v51 offset0:192 offset1:208    // 000000A38CBC: D8DCD0C0 19000033
	v_add_f32_e32 v7, v7, v37                                  // 000000A38CC4: 060E4B07
	v_add_f32_e32 v15, 0, v12                                  // 000000A38CC8: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:96 offset1:112      // 000000A38CCC: D8DC7060 0B000004
	v_add_f32_e32 v31, v5, v30                                 // 000000A38CD4: 063E3D05
	ds_load_2addr_b32 v[29:30], v4 offset0:224 offset1:240     // 000000A38CD8: D8DCF0E0 1D000004
	s_waitcnt lgkmcnt(6)                                       // 000000A38CE0: BF89FC67
	v_dual_add_f32 v13, v13, v17 :: v_dual_add_f32 v4, v15, v32// 000000A38CE4: C908230D 0D04410F
	v_add_f32_e32 v15, v7, v19                                 // 000000A38CEC: 061E2707
	v_add_f32_e32 v17, v31, v6                                 // 000000A38CF0: 06220D1F
	ds_load_2addr_b32 v[6:7], v45 offset0:96 offset1:112       // 000000A38CF4: D8DC7060 0600002D
	ds_load_2addr_b32 v[31:32], v45 offset0:224 offset1:240    // 000000A38CFC: D8DCF0E0 1F00002D
	s_waitcnt lgkmcnt(7)                                       // 000000A38D04: BF89FC77
	v_dual_add_f32 v13, v13, v21 :: v_dual_add_f32 v4, v4, v34 // 000000A38D08: C9082B0D 0D044504
	s_waitcnt lgkmcnt(6)                                       // 000000A38D10: BF89FC67
	v_dual_add_f32 v15, v15, v23 :: v_dual_add_f32 v8, v17, v8 // 000000A38D14: C9082F0F 0F081111
	s_clause 0x1                                               // 000000A38D1C: BF850001
	global_load_d16_b16 v2, v1, s[6:7]                         // 000000A38D20: DC820000 02060001
	global_load_d16_b16 v5, v1, s[6:7] offset:64               // 000000A38D28: DC820040 05060001
	v_dual_add_f32 v4, v4, v14 :: v_dual_add_f32 v37, v27, v28 // 000000A38D30: C9081D04 0424391B
	s_waitcnt lgkmcnt(5)                                       // 000000A38D38: BF89FC57
	v_add_f32_e32 v23, v13, v9                                 // 000000A38D3C: 062E130D
	s_waitcnt lgkmcnt(4)                                       // 000000A38D40: BF89FC47
	v_dual_add_f32 v25, v15, v25 :: v_dual_add_f32 v8, v8, v16 // 000000A38D44: C908330F 19082108
	ds_load_2addr_b32 v[13:14], v46 offset0:96 offset1:112     // 000000A38D4C: D8DC7060 0D00002E
	ds_load_2addr_b32 v[15:16], v46 offset0:224 offset1:240    // 000000A38D54: D8DCF0E0 0F00002E
	v_add_f32_e32 v9, v4, v38                                  // 000000A38D5C: 06124D04
	s_waitcnt lgkmcnt(5)                                       // 000000A38D60: BF89FC57
	v_add_f32_e32 v11, 0, v11                                  // 000000A38D64: 06161680
	s_waitcnt lgkmcnt(4)                                       // 000000A38D68: BF89FC47
	v_dual_add_f32 v17, 0, v29 :: v_dual_add_f32 v38, v8, v18  // 000000A38D6C: C9083A80 11262508
	v_add_f32_e32 v21, v33, v36                                // 000000A38D74: 062A4921
	v_add_f32_e32 v44, v9, v20                                 // 000000A38D78: 06582909
	s_waitcnt lgkmcnt(2)                                       // 000000A38D7C: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A38D80: BF870003
	v_dual_add_f32 v8, v11, v6 :: v_dual_add_f32 v11, v17, v31 // 000000A38D84: C9080D0B 080A3F11
	ds_load_2addr_b32 v[17:18], v47 offset0:96 offset1:112     // 000000A38D8C: D8DC7060 1100002F
	ds_load_2addr_b32 v[19:20], v47 offset0:224 offset1:240    // 000000A38D94: D8DCF0E0 1300002F
	ds_load_2addr_b32 v[27:28], v48 offset0:96 offset1:112     // 000000A38D9C: D8DC7060 1B000030
	ds_load_2addr_b32 v[33:34], v48 offset0:224 offset1:240    // 000000A38DA4: D8DCF0E0 21000030
	v_add_f32_e32 v31, 0, v12                                  // 000000A38DAC: 063E1880
	v_add_f32_e32 v35, 0, v30                                  // 000000A38DB0: 06463C80
	s_clause 0x1                                               // 000000A38DB4: BF850001
	global_load_d16_b16 v6, v41, s[6:7] offset:1280            // 000000A38DB8: DC820500 06060029
	global_load_d16_b16 v4, v1, s[6:7] offset:1280             // 000000A38DC0: DC820500 04060001
	v_or_b32_e32 v45, 0x60, v52                                // 000000A38DC8: 385A68FF 00000060
	v_add_f32_e32 v7, v31, v7                                  // 000000A38DD0: 060E0F1F
	s_waitcnt lgkmcnt(5)                                       // 000000A38DD4: BF89FC57
	v_add_f32_e32 v13, v8, v13                                 // 000000A38DD8: 061A1B08
	global_load_d16_b16 v8, v41, s[8:9]                        // 000000A38DDC: DC820000 08080029
	s_waitcnt lgkmcnt(4)                                       // 000000A38DE4: BF89FC47
	v_add_f32_e32 v15, v11, v15                                // 000000A38DE8: 061E1F0B
	ds_load_2addr_b32 v[11:12], v49 offset0:96 offset1:112     // 000000A38DEC: D8DC7060 0B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:224 offset1:240    // 000000A38DF4: D8DCF0E0 1D000031
	v_add_f32_e32 v41, v35, v32                                // 000000A38DFC: 06524123
	ds_load_2addr_b32 v[31:32], v50 offset0:96 offset1:112     // 000000A38E00: D8DC7060 1F000032
	ds_load_2addr_b32 v[35:36], v50 offset0:224 offset1:240    // 000000A38E08: D8DCF0E0 23000032
	v_add_f32_e32 v7, v7, v14                                  // 000000A38E10: 060E1D07
	global_load_d16_b16 v9, v45, s[6:7]                        // 000000A38E14: DC820000 0906002D
	v_add_f32_e32 v41, v41, v16                                // 000000A38E1C: 06522129
	s_waitcnt lgkmcnt(7)                                       // 000000A38E20: BF89FC77
	v_add_f32_e32 v17, v13, v17                                // 000000A38E24: 0622230D
	s_waitcnt lgkmcnt(6)                                       // 000000A38E28: BF89FC67
	v_add_f32_e32 v19, v15, v19                                // 000000A38E2C: 0626270F
	ds_load_2addr_b32 v[13:14], v51 offset0:96 offset1:112     // 000000A38E30: D8DC7060 0D000033
	ds_load_2addr_b32 v[15:16], v51 offset0:224 offset1:240    // 000000A38E38: D8DCF0E0 0F000033
	v_dual_add_f32 v7, v7, v18 :: v_dual_add_f32 v18, v41, v20 // 000000A38E40: C9082507 07122929
	s_waitcnt lgkmcnt(7)                                       // 000000A38E48: BF89FC77
	v_add_f32_e32 v17, v17, v27                                // 000000A38E4C: 06223711
	s_waitcnt lgkmcnt(6)                                       // 000000A38E50: BF89FC67
	v_dual_add_f32 v19, v19, v33 :: v_dual_add_f32 v20, v38, v22// 000000A38E54: C9084313 13142D26
	v_dual_add_f32 v7, v7, v28 :: v_dual_add_f32 v18, v18, v34 // 000000A38E5C: C9083907 07124512
	v_add_f32_e32 v22, v44, v24                                // 000000A38E64: 062C312C
	v_or_b32_e32 v28, 0xa0, v52                                // 000000A38E68: 383868FF 000000A0
	s_waitcnt lgkmcnt(5)                                       // 000000A38E70: BF89FC57
	v_add_f32_e32 v11, v17, v11                                // 000000A38E74: 06161711
	s_waitcnt lgkmcnt(4)                                       // 000000A38E78: BF89FC47
	v_add_f32_e32 v17, v19, v29                                // 000000A38E7C: 06223B13
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v12, v18, v30 // 000000A38E80: C9081907 070C3D12
	s_waitcnt lgkmcnt(3)                                       // 000000A38E88: BF89FC37
	v_dual_add_f32 v10, v20, v10 :: v_dual_add_f32 v11, v11, v31// 000000A38E8C: C9081514 0A0A3F0B
	s_waitcnt lgkmcnt(2)                                       // 000000A38E94: BF89FC27
	v_dual_add_f32 v17, v17, v35 :: v_dual_add_f32 v18, v22, v26// 000000A38E98: C9084711 11123516
	v_add_f32_e32 v12, v12, v36                                // 000000A38EA0: 0618490C
	v_add_f32_e32 v7, v7, v32                                  // 000000A38EA4: 060E4107
	s_waitcnt lgkmcnt(1)                                       // 000000A38EA8: BF89FC17
	v_add_f32_e32 v11, v11, v13                                // 000000A38EAC: 06161B0B
	s_waitcnt lgkmcnt(0)                                       // 000000A38EB0: BF89FC07
	v_add_f32_e32 v13, v17, v15                                // 000000A38EB4: 061A1F11
	v_dual_add_f32 v19, v23, v10 :: v_dual_add_f32 v12, v12, v16// 000000A38EB8: C9081517 130C210C
	v_sub_f32_e32 v10, v23, v10                                // 000000A38EC0: 08141517
	v_dual_add_f32 v22, v43, v54 :: v_dual_add_f32 v23, v42, v21// 000000A38EC4: C9086D2B 16162B2A
	v_add_f32_e32 v24, v25, v18                                // 000000A38ECC: 06302519
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A38ED0: BF870004
	v_add_f32_e32 v27, v13, v12                                // 000000A38ED4: 0636190D
	v_add_f32_e32 v7, v7, v14                                  // 000000A38ED8: 060E1D07
	v_sub_f32_e32 v15, v39, v53                                // 000000A38EDC: 081E6B27
	v_add_f32_e32 v16, v40, v37                                // 000000A38EE0: 06204B28
	v_dual_sub_f32 v17, v40, v37 :: v_dual_add_f32 v30, v22, v23// 000000A38EE4: C9484B28 111E2F16
	v_add_f32_e32 v31, v24, v27                                // 000000A38EEC: 063E3718
	v_dual_add_f32 v20, v11, v7 :: v_dual_and_b32 v37, 1, v0   // 000000A38EF0: C9240F0B 14240081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A38EF8: BF870223
	v_add_f32_e32 v36, v15, v17                                // 000000A38EFC: 0648230F
	v_sub_f32_e32 v15, v15, v17                                // 000000A38F00: 081E230F
	v_add_f32_e32 v17, v30, v31                                // 000000A38F04: 06223F1E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A38F08: BF870004
	.long 0xd44a0002                                           // 000000A38F0C: D44A0002
	v_cndmask_b32_e32 v1, 0, v37, vcc_lo                       // 000000A38F10: 02024A80
	v_add_f32_e32 v14, v39, v53                                // 000000A38F14: 061C6B27
	v_add_f32_e32 v39, v19, v20                                // 000000A38F18: 064E2913
	v_sub_f32_e32 v19, v19, v20                                // 000000A38F1C: 08262913
	v_mov_b32_dpp v20, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A38F20: 7E2802FA FF016111
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000A38F28: D5010011 200A2311
	v_sub_f32_e32 v37, v43, v54                                // 000000A38F30: 084A6D2B
	v_dual_sub_f32 v21, v42, v21 :: v_dual_sub_f32 v18, v25, v18// 000000A38F34: C94A2B2A 15122519
	v_dual_sub_f32 v12, v13, v12 :: v_dual_sub_f32 v11, v11, v7// 000000A38F3C: C94A190D 0C0A0F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A38F44: BF8701A4
	v_add_f32_e32 v13, v17, v20                                // 000000A38F48: 061A2911
	v_and_b32_e32 v17, 2, v0                                   // 000000A38F4C: 36220082
	v_dual_add_f32 v25, v37, v21 :: v_dual_add_f32 v40, v18, v12// 000000A38F50: C9082B25 19281912
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A38F58: BF870224
	v_add_f32_e32 v20, v10, v11                                // 000000A38F5C: 0628170A
	v_sub_f32_e32 v10, v10, v11                                // 000000A38F60: 0814170A
	.long 0xd44a0003                                           // 000000A38F64: D44A0003
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 000000A38F68: 02022280
	v_sub_f32_e32 v17, v22, v23                                // 000000A38F6C: 08222F16
	v_dual_add_f32 v11, v25, v40 :: v_dual_sub_f32 v22, v24, v27// 000000A38F70: C90A5119 0B163718
	v_and_b32_e32 v23, 4, v0                                   // 000000A38F78: 362E0084
	v_mov_b32_dpp v41, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A38F7C: 7E5202FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000A38F84: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A38F8C: BF870254
	v_mov_b32_dpp v24, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A38F90: 7E3002FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000A38F98: D501000B 200A170B
	v_add_f32_e32 v27, v17, v22                                // 000000A38FA0: 06362D11
	.long 0xd44a0004                                           // 000000A38FA4: D44A0004
	v_cndmask_b32_e32 v1, 0, v23, vcc_lo                       // 000000A38FA8: 02022E80
	v_dual_add_f32 v13, v13, v41 :: v_dual_and_b32 v0, 8, v0   // 000000A38FAC: C924530D 0D000088
	v_add_f32_e32 v11, v11, v24                                // 000000A38FB4: 0616310B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A38FB8: BF870224
	v_mov_b32_dpp v23, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A38FBC: 7E2E02FA FF01611B
	v_cndmask_b32_e64 v24, -v27, v27, s2                       // 000000A38FC4: D5010018 200A371B
	.long 0xd44a0001                                           // 000000A38FCC: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000A38FD0: 02020080
	v_sub_f32_e32 v0, v37, v21                                 // 000000A38FD4: 08002B25
	v_mov_b32_dpp v27, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A38FD8: 7E3602FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000A38FE0: D501000B 200E170B
	v_dual_add_f32 v23, v24, v23 :: v_dual_sub_f32 v12, v18, v12// 000000A38FE8: C90A2F18 170C1912
	v_mov_b32_dpp v41, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A38FF0: 7E5202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000A38FF8: D501000D 20121B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A39000: BF870214
	v_add_f32_e32 v11, v11, v27                                // 000000A39004: 0616370B
	v_mov_b32_dpp v18, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39008: 7E2402FA FF016217
	v_cndmask_b32_e64 v21, -v23, v23, s3                       // 000000A39010: D5010015 200E2F17
	v_sub_f32_e32 v24, v25, v40                                // 000000A39018: 08305119
	v_add_f32_e32 v13, v13, v41                                // 000000A3901C: 061A530D
	v_mov_b32_dpp v25, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39020: 7E3202FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000A39028: D501000B 2012170B
	v_dual_add_f32 v18, v21, v18 :: v_dual_add_f32 v21, v0, v12// 000000A39030: C9082515 12141900
	v_sub_f32_e32 v23, v30, v31                                // 000000A39038: 082E3F1E
	v_sub_f32_e32 v17, v17, v22                                // 000000A3903C: 08222D11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A39040: BF870214
	v_add_f32_e32 v11, v11, v25                                // 000000A39044: 0616330B
	v_mov_b32_dpp v25, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39048: 7E3202FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 000000A39050: D5010012 20122512
	v_mov_b32_dpp v30, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A39058: 7E3C02FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000A39060: D5010015 200A2B15
	v_mov_b32_dpp v22, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A39068: 7E2C02FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000A39070: D501000D 20061B0D
	v_add_f32_e32 v18, v18, v25                                // 000000A39078: 06243312
	v_add_f32_e32 v29, v14, v16                                // 000000A3907C: 063A210E
	v_dual_add_f32 v21, v21, v30 :: v_dual_sub_f32 v14, v14, v16// 000000A39080: C90A3D15 150E210E
	v_or_b32_e32 v16, 0xe0, v52                                // 000000A39088: 382068FF 000000E0
	v_sub_f32_e32 v0, v0, v12                                  // 000000A39090: 08001900
	v_add_f32_e32 v12, v13, v22                                // 000000A39094: 06182D0D
	v_mov_b32_dpp v13, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A39098: 7E1A02FA FF016812
	v_mov_b32_dpp v22, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A390A0: 7E2C02FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000A390A8: D5010015 200E2B15
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000A390B0: D5010012 20062512
	v_mov_b32_dpp v25, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A390B8: 7E3202FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s2                       // 000000A390C0: D5010017 200A2F17
	global_load_d16_b16 v38, v16, s[6:7]                       // 000000A390C8: DC820000 26060010
	v_add_f32_e32 v21, v21, v22                                // 000000A390D0: 062A2D15
	v_add_f32_e32 v13, v18, v13                                // 000000A390D4: 061A1B12
	global_load_d16_b16 v22, v28, s[6:7] offset:1280           // 000000A390D8: DC820500 1606001C
	v_add_f32_e32 v18, v23, v25                                // 000000A390E0: 06243317
	s_clause 0x7                                               // 000000A390E4: BF850007
	global_load_d16_b16 v25, v16, s[6:7] offset:1280           // 000000A390E8: DC820500 19060010
	global_load_d16_b16 v26, v1, s[6:7] offset:128             // 000000A390F0: DC820080 1A060001
	global_load_d16_b16 v32, v28, s[6:7]                       // 000000A390F8: DC820000 2006001C
	global_load_d16_b16 v33, v1, s[6:7] offset:1344            // 000000A39100: DC820540 21060001
	global_load_d16_b16 v7, v1, s[6:7] offset:1408             // 000000A39108: DC820580 07060001
	global_load_d16_b16 v34, v1, s[6:7] offset:1472            // 000000A39110: DC8205C0 22060001
	global_load_d16_b16 v35, v1, s[6:7] offset:192             // 000000A39118: DC8200C0 23060001
	global_load_d16_b16 v27, v45, s[6:7] offset:1280           // 000000A39120: DC820500 1B06002D
	v_mov_b32_dpp v23, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39128: 7E2E02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s4                       // 000000A39130: D5010015 20122B15
	s_clause 0x5                                               // 000000A39138: BF850005
	global_load_d16_b16 v28, v28, s[8:9]                       // 000000A3913C: DC820000 1C08001C
	global_load_d16_b16 v16, v16, s[8:9]                       // 000000A39144: DC820000 10080010
	global_load_d16_b16 v37, v1, s[8:9]                        // 000000A3914C: DC820000 25080001
	global_load_d16_b16 v40, v1, s[8:9] offset:64              // 000000A39154: DC820040 28080001
	global_load_d16_b16 v41, v1, s[8:9] offset:128             // 000000A3915C: DC820080 29080001
	global_load_d16_b16 v42, v1, s[8:9] offset:192             // 000000A39164: DC8200C0 2A080001
	v_mov_b32_dpp v31, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A3916C: 7E3E02FA FF01680B
	v_add_f32_e32 v21, v21, v23                                // 000000A39174: 062A2F15
	global_load_d16_b16 v23, v45, s[8:9]                       // 000000A39178: DC820000 1708002D
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A39180: D501000B 2006170B
	v_mov_b32_dpp v30, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39188: 7E3C02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000A39190: D5010012 200E2512
	v_add_f32_e32 v43, v36, v20                                // 000000A39198: 06562924
	v_mov_b32_dpp v47, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A3919C: 7E5E02FA FF016118
	v_add_f32_e32 v11, v11, v31                                // 000000A391A4: 06163F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A391A8: BF870214
	v_dual_add_f32 v31, v29, v39 :: v_dual_add_f32 v18, v18, v30// 000000A391AC: C9084F1D 1F123D12
	v_mov_b32_dpp v45, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A391B4: 7E5A02FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 000000A391BC: D501002B 200A572B
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 000000A391C4: D5010018 200A3118
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A391CC: BF870004
	v_mov_b32_dpp v30, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A391D0: 7E3C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000A391D8: D501001F 200A3F1F
	v_mov_b32_dpp v44, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A391E0: 7E5802FA FF016815
	v_add_f32_e32 v43, v43, v45                                // 000000A391E8: 06565B2B
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000A391EC: D5010015 20062B15
	v_add_f32_e32 v24, v24, v47                                // 000000A391F4: 06305F18
	v_add_f32_e32 v30, v31, v30                                // 000000A391F8: 063C3D1F
	v_mov_b32_dpp v31, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A391FC: 7E3E02FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 000000A39204: D5010012 20122512
	v_add_f32_e32 v21, v21, v44                                // 000000A3920C: 062A5915
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000A39210: 101818FF 3DB504F3
	v_mov_b32_dpp v46, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39218: 7E5C02FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000A39220: D501001E 200E3D1E
	v_add_f32_e32 v18, v18, v31                                // 000000A39228: 06243F12
	v_mov_b32_dpp v31, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A3922C: 7E3E02FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 000000A39234: D501002B 200E572B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A3923C: BF870234
	v_dual_sub_f32 v29, v29, v39 :: v_dual_add_f32 v30, v30, v46// 000000A39240: C9484F1D 1D1E5D1E
	v_mov_b32_dpp v46, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39248: 7E5C02FA FF016218
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000A39250: D5010018 200E3118
	v_add_f32_e32 v31, v43, v31                                // 000000A39258: 063E3F2B
	v_mov_b32_dpp v43, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A3925C: 7E5602FA FF016812
	v_mov_b32_dpp v45, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39264: 7E5A02FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s4                       // 000000A3926C: D501001E 20123D1E
	v_add_f32_e32 v24, v24, v46                                // 000000A39274: 06305D18
	v_mov_b32_dpp v44, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39278: 7E5802FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 000000A39280: D501001F 20123F1F
	v_mov_b32_dpp v46, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A39288: 7E5C02FA FF016111
	v_add_f32_e32 v30, v30, v45                                // 000000A39290: 063C5B1E
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000A39294: D5010011 200A2311
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000A3929C: D5010012 20062512
	v_add_f32_e32 v31, v31, v44                                // 000000A392A4: 063E591F
	v_mov_b32_dpp v44, v24 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A392A8: 7E5802FA FF016418
	v_mov_b32_dpp v45, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A392B0: 7E5A02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000A392B8: D501001E 20063D1E
	v_add_f32_e32 v17, v17, v46                                // 000000A392C0: 06225D11
	v_cndmask_b32_e64 v24, -v24, v24, s4                       // 000000A392C4: D5010018 20123118
	v_add_f32_e32 v18, v18, v43                                // 000000A392CC: 06245712
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A392D0: BF870004
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_add_f32 v30, v30, v45// 000000A392D4: C8C816FF 0B1E5B1E 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A392E0: 7E5A02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A392E8: D501001F 20063F1F
	v_mov_b32_dpp v46, v17 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A392F0: 7E5C02FA FF016211
	v_cndmask_b32_e64 v17, -v17, v17, s3                       // 000000A392F8: D5010011 200E2311
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000A39300: 103C3CFF 3DB504F3
	v_add_f32_e32 v24, v24, v44                                // 000000A39308: 06305918
	v_dual_sub_f32 v20, v36, v20 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 000000A3930C: C9462924 140C1AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A39318: BF8701A4
	v_add_f32_e32 v17, v17, v46                                // 000000A3931C: 06225D11
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 000000A39320: C8C62AFF 151224FF 3DB504F3
	v_mov_b32_dpp v36, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A3932C: 7E4802FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000A39334: D5010014 200A2914
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A3933C: BF8700A4
	v_mov_b32_dpp v44, v17 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39340: 7E5802FA FF016411
	v_cndmask_b32_e64 v17, -v17, v17, s4                       // 000000A39348: D5010011 20122311
	v_add_f32_e32 v17, v17, v44                                // 000000A39350: 06225911
	v_mov_b32_dpp v44, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A39354: 7E5802FA FF016100
	v_cndmask_b32_e64 v0, -v0, v0, s2                          // 000000A3935C: D5010000 200A0100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A39364: BF870211
	v_add_f32_e32 v0, v0, v44                                  // 000000A39368: 06005900
	v_mov_b32_dpp v44, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A3936C: 7E5802FA FF016811
	v_cndmask_b32_e64 v17, -v17, v17, s1                       // 000000A39374: D5010011 20062311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A3937C: BF870091
	v_add_f32_e32 v17, v17, v44                                // 000000A39380: 06225911
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 000000A39384: 102222FF 3DB504F3
	s_waitcnt vmcnt(22)                                        // 000000A3938C: BF895BF7
	v_fma_mix_f32 v2, v2, v30, neg(0) op_sel_hi:[1,0,0]        // 000000A39390: CC200002 8A023D02
	v_add_f32_e32 v30, v31, v45                                // 000000A39398: 063C5B1F
	v_mov_b32_dpp v31, v24 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A3939C: 7E3E02FA FF016818
	v_cndmask_b32_e64 v24, -v24, v24, s1                       // 000000A393A4: D5010018 20063118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A393AC: BF870214
	v_mul_f32_e32 v43, 0xbfb8aa3b, v2                          // 000000A393B0: 105604FF BFB8AA3B
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000A393B8: 103C3CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A393C0: BF870223
	v_add_f32_e32 v24, v24, v31                                // 000000A393C4: 06303F18
	v_add_f32_e32 v31, v14, v19                                // 000000A393C8: 063E270E
	v_exp_f32_e32 v43, v43                                     // 000000A393CC: 7E564B2B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A393D0: BF870003
	v_fma_mix_f32 v3, v3, v30, neg(0) op_sel_hi:[1,0,0]        // 000000A393D4: CC200003 8A023D03
	v_sub_f32_e32 v14, v14, v19                                // 000000A393DC: 081C270E
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 000000A393E0: 103030FF 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A393E8: 7E5A02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000A393F0: D501001F 200A3F1F
	v_mul_f32_e32 v30, 0xbfb8aa3b, v3                          // 000000A393F8: 103C06FF BFB8AA3B
	v_mov_b32_dpp v19, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A39400: 7E2602FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000A39408: D501000E 200A1D0E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A39410: BF870215
	v_add_f32_e32 v43, 1.0, v43                                // 000000A39414: 065656F2
	v_exp_f32_e32 v30, v30                                     // 000000A39418: 7E3C4B1E
	v_add_f32_e32 v31, v31, v45                                // 000000A3941C: 063E5B1F
	v_mov_b32_dpp v45, v0 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39420: 7E5A02FA FF016200
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 000000A39428: D5010000 200E0100
	v_div_scale_f32 v46, null, v43, v43, v2                    // 000000A39430: D6FC7C2E 040A572B
	s_waitcnt vmcnt(19)                                        // 000000A39438: BF894FF7
	v_fma_mix_f32 v4, v4, v12, neg(0) op_sel_hi:[1,0,0]        // 000000A3943C: CC200004 8A021904
	v_mov_b32_dpp v48, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39444: 7E6002FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000A3944C: D501001F 200E3F1F
	v_add_f32_e32 v0, v0, v45                                  // 000000A39454: 06005B00
	v_rcp_f32_e32 v47, v46                                     // 000000A39458: 7E5E552E
	v_add_f32_e32 v30, 1.0, v30                                // 000000A3945C: 063C3CF2
	v_fma_mix_f32 v6, v6, v11, neg(0) op_sel_hi:[1,0,0]        // 000000A39460: CC200006 8A021706
	v_add_f32_e32 v31, v31, v48                                // 000000A39468: 063E611F
	v_mov_b32_dpp v44, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A3946C: 7E5802FA FF016400
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000A39474: D5010000 20120100
	v_div_scale_f32 v45, null, v30, v30, v3                    // 000000A3947C: D6FC7C2D 040E3D1E
	v_add_f32_e32 v14, v14, v19                                // 000000A39484: 061C270E
	v_mov_b32_dpp v50, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39488: 7E6402FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 000000A39490: D501001F 20123F1F
	v_add_f32_e32 v0, v0, v44                                  // 000000A39498: 06005900
	v_rcp_f32_e32 v48, v45                                     // 000000A3949C: 7E60552D
	v_add_f32_e32 v44, v15, v10                                // 000000A394A0: 0658150F
	v_fma_f32 v49, -v46, v47, 1.0                              // 000000A394A4: D6130031 23CA5F2E
	v_add_f32_e32 v31, v31, v50                                // 000000A394AC: 063E651F
	v_sub_f32_e32 v10, v15, v10                                // 000000A394B0: 0814150F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 000000A394B4: BF8702C4
	v_mov_b32_dpp v51, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A394B8: 7E6602FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000A394C0: D501002C 200A592C
	v_fmac_f32_e32 v47, v49, v47                               // 000000A394C8: 565E5F31
	v_div_scale_f32 v49, vcc_lo, v2, v43, v2                   // 000000A394CC: D6FC6A31 040A5702
	v_fma_f32 v50, -v45, v48, 1.0                              // 000000A394D4: D6130032 23CA612D
	v_mov_b32_dpp v52, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A394DC: 7E6802FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A394E4: D501001F 20063F1F
	v_add_f32_e32 v44, v44, v51                                // 000000A394EC: 0658672C
	v_mov_b32_dpp v51, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A394F0: 7E6602FA FF016800
	v_fmac_f32_e32 v48, v50, v48                               // 000000A394F8: 56606132
	v_div_scale_f32 v50, s5, v3, v30, v3                       // 000000A394FC: D6FC0532 040E3D03
	v_dual_add_f32 v31, v31, v52 :: v_dual_mul_f32 v52, v49, v47// 000000A39504: C906691F 1F345F31
	v_mov_b32_dpp v54, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A3950C: 7E6C02FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000A39514: D501002C 200E592C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A3951C: BF870214
	v_mul_f32_e32 v53, v50, v48                                // 000000A39520: 106A6132
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 000000A39524: 103E3EFF 3DB504F3
	v_fma_f32 v55, -v46, v52, v49                              // 000000A3952C: D6130037 24C6692E
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000A39534: D5010000 20060100
	v_add_f32_e32 v44, v44, v54                                // 000000A3953C: 06586D2C
	v_fma_f32 v56, -v45, v53, v50                              // 000000A39540: D6130038 24CA6B2D
	v_fma_mix_f32 v5, v5, v31, neg(0) op_sel_hi:[1,0,0]        // 000000A39548: CC200005 8A023F05
	v_fmac_f32_e32 v52, v55, v47                               // 000000A39550: 56685F37
	v_add_f32_e32 v0, v0, v51                                  // 000000A39554: 06006700
	v_mov_b32_dpp v31, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39558: 7E3E02FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s4                       // 000000A39560: D501002C 2012592C
	v_fmac_f32_e32 v53, v56, v48                               // 000000A39568: 566A6138
	v_fma_f32 v46, -v46, v52, v49                              // 000000A3956C: D613002E 24C6692E
	v_mul_f32_e32 v51, 0xbfb8aa3b, v5                          // 000000A39574: 10660AFF BFB8AA3B
	v_mov_b32_dpp v19, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A3957C: 7E2602FA FF01610A
	v_add_f32_e32 v31, v44, v31                                // 000000A39584: 063E3F2C
	v_fma_f32 v45, -v45, v53, v50                              // 000000A39588: D613002D 24CA6B2D
	v_div_fmas_f32 v44, v46, v47, v52                          // 000000A39590: D637002C 04D25F2E
	s_mov_b32 vcc_lo, s5                                       // 000000A39598: BEEA0005
	v_exp_f32_e32 v49, v51                                     // 000000A3959C: 7E624B33
	v_mov_b32_dpp v46, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A395A0: 7E5C02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A395A8: D501001F 20063F1F
	v_div_fmas_f32 v45, v45, v48, v53                          // 000000A395B0: D637002D 04D6612D
	v_div_fixup_f32 v2, v44, v43, v2                           // 000000A395B8: D6270002 040A572C
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A395C0: D501000A 200A150A
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000A395C8: 100000FF 3DB504F3
	v_add_f32_e32 v12, v31, v46                                // 000000A395D0: 06185D1F
	v_mov_b32_dpp v31, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A395D4: 7E3E02FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000A395DC: D501001D 200A3B1D
	v_div_fixup_f32 v3, v45, v30, v3                           // 000000A395E4: D6270003 040E3D2D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A395EC: BF870224
	v_dual_mul_f32 v2, v4, v2 :: v_dual_mul_f32 v11, 0x3db504f3, v12// 000000A395F0: C8C60504 020A18FF 3DB504F3
	v_add_f32_e32 v10, v10, v19                                // 000000A395FC: 0614270A
	v_add_f32_e32 v4, v29, v31                                 // 000000A39600: 06083F1D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A39604: BF870004
	v_mul_f32_e32 v3, v6, v3                                   // 000000A39608: 10060706
	v_add_f32_e32 v47, 1.0, v49                                // 000000A3960C: 065E62F2
	s_waitcnt vmcnt(17)                                        // 000000A39610: BF8947F7
	v_fma_mix_f32 v6, v9, v11, neg(0) op_sel_hi:[1,0,0]        // 000000A39614: CC200006 8A021709
	v_add_f32_e32 v9, v20, v36                                 // 000000A3961C: 06124914
	v_mov_b32_dpp v20, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39620: 7E2802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000A39628: D5010004 200E0904
	v_fma_mix_f32 v3, v8, v3, neg(0) op_sel_hi:[1,0,0]         // 000000A39630: CC200003 8A020708
	v_mul_f32_e32 v8, 0xbfb8aa3b, v6                           // 000000A39638: 10100CFF BFB8AA3B
	v_mov_b32_dpp v29, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39640: 7E3A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A39648: D5010009 200E1309
	v_add_f32_e32 v4, v4, v20                                  // 000000A39650: 06082904
	v_div_scale_f32 v30, null, v47, v47, v5                    // 000000A39654: D6FC7C1E 04165F2F
	v_exp_f32_e32 v8, v8                                       // 000000A3965C: 7E104B08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A39660: BF870193
	v_add_f32_e32 v9, v9, v29                                  // 000000A39664: 06123B09
	v_mov_b32_dpp v15, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39668: 7E1E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000A39670: D5010004 20120904
	v_mov_b32_dpp v29, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39678: 7E3A02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 000000A39680: D501000E 200E1D0E
	v_mov_b32_dpp v20, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39688: 7E2802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000A39690: D5010009 20121309
	v_add_f32_e32 v4, v4, v15                                  // 000000A39698: 06081F04
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A3969C: 7E1E02FA FF01620A
	v_add_f32_e32 v14, v14, v29                                // 000000A396A4: 061C3B0E
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000A396A8: D501000A 200E150A
	v_add_f32_e32 v9, v9, v20                                  // 000000A396B0: 06122909
	v_mov_b32_dpp v19, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A396B4: 7E2602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A396BC: D5010004 20060904
	v_mov_b32_dpp v20, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A396C4: 7E2802FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000A396CC: D501000E 20121D0E
	v_add_f32_e32 v10, v10, v15                                // 000000A396D4: 06141F0A
	v_rcp_f32_e32 v12, v30                                     // 000000A396D8: 7E18551E
	v_mov_b32_dpp v15, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A396DC: 7E1E02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A396E4: D5010009 20061309
	v_add_f32_e32 v4, v4, v19                                  // 000000A396EC: 06082704
	v_add_f32_e32 v14, v14, v20                                // 000000A396F0: 061C290E
	v_mov_b32_dpp v19, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A396F4: 7E2602FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 000000A396FC: D501000A 2012150A
	v_dual_add_f32 v8, 1.0, v8 :: v_dual_add_f32 v9, v9, v15   // 000000A39704: C90810F2 08081F09
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A3970C: BF870224
	v_mov_b32_dpp v15, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A39710: 7E1E02FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000A39718: D501000E 20061D0E
	v_add_f32_e32 v10, v10, v19                                // 000000A39720: 0614270A
	v_fma_f32 v11, -v30, v12, 1.0                              // 000000A39724: D613000B 23CA191E
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000A3972C: 100808FF 3DB504F3
	v_div_scale_f32 v19, null, v8, v8, v6                      // 000000A39734: D6FC7C13 041A1108
	v_add_f32_e32 v14, v14, v15                                // 000000A3973C: 061C1F0E
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A39740: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A39748: D501000A 2006150A
	v_fmac_f32_e32 v12, v11, v12                               // 000000A39750: 5618190B
	v_div_scale_f32 v11, vcc_lo, v5, v47, v5                   // 000000A39754: D6FC6A0B 04165F05
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000A3975C: 101212FF 3DB504F3
	v_rcp_f32_e32 v20, v19                                     // 000000A39764: 7E285513
	v_add_f32_e32 v10, v10, v15                                // 000000A39768: 06141F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A3976C: BF8701B3
	v_dual_mul_f32 v14, 0x3db504f3, v14 :: v_dual_mul_f32 v15, v11, v12// 000000A39770: C8C61CFF 0E0E190B 3DB504F3
	s_waitcnt vmcnt(12)                                        // 000000A3977C: BF8933F7
	v_fma_mix_f32 v9, v32, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A39780: CC200009 8A021320
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000A39788: 101414FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A39790: BF870003
	v_fma_f32 v31, -v30, v15, v11                              // 000000A39794: D613001F 242E1F1E
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000A3979C: CC200004 8A02091A
	s_waitcnt vmcnt(8)                                         // 000000A397A4: BF8923F7
	v_fma_mix_f32 v14, v35, v14, neg(0) op_sel_hi:[1,0,0]      // 000000A397A8: CC20000E 8A021D23
	v_mul_f32_e32 v29, 0xbfb8aa3b, v9                          // 000000A397B0: 103A12FF BFB8AA3B
	v_fma_f32 v32, -v19, v20, 1.0                              // 000000A397B8: D6130020 23CA2913
	v_fma_mix_f32 v10, v38, v10, neg(0) op_sel_hi:[1,0,0]      // 000000A397C0: CC20000A 8A021526
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A397C8: BF870214
	v_dual_mul_f32 v26, 0xbfb8aa3b, v4 :: v_dual_mul_f32 v35, 0xbfb8aa3b, v14// 000000A397CC: C8C608FF 1A221CFF BFB8AA3B
	v_exp_f32_e32 v29, v29                                     // 000000A397D8: 7E3A4B1D
	v_fmac_f32_e32 v15, v31, v12                               // 000000A397DC: 561E191F
	v_fmac_f32_e32 v20, v32, v20                               // 000000A397E0: 56282920
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A397E4: BF870003
	v_exp_f32_e32 v26, v26                                     // 000000A397E8: 7E344B1A
	v_mul_f32_e32 v32, 0xbfb8aa3b, v10                         // 000000A397EC: 104014FF BFB8AA3B
	v_exp_f32_e32 v31, v35                                     // 000000A397F4: 7E3E4B23
	v_fma_f32 v11, -v30, v15, v11                              // 000000A397F8: D613000B 242E1F1E
	v_div_scale_f32 v35, s5, v6, v8, v6                        // 000000A39800: D6FC0523 041A1106
	v_fma_mix_f32 v13, v33, v13, neg(0) op_sel_hi:[1,0,0]      // 000000A39808: CC20000D 8A021B21
	v_exp_f32_e32 v30, v32                                     // 000000A39810: 7E3C4B20
	v_add_f32_e32 v29, 1.0, v29                                // 000000A39814: 063A3AF2
	v_div_fmas_f32 v11, v11, v12, v15                          // 000000A39818: D637000B 043E190B
	v_mul_f32_e32 v32, v35, v20                                // 000000A39820: 10402923
	v_add_f32_e32 v26, 1.0, v26                                // 000000A39824: 063434F2
	s_mov_b32 vcc_lo, s5                                       // 000000A39828: BEEA0005
	v_add_f32_e32 v31, 1.0, v31                                // 000000A3982C: 063E3EF2
	v_div_scale_f32 v39, null, v29, v29, v9                    // 000000A39830: D6FC7C27 04263B1D
	v_fma_f32 v15, -v19, v32, v35                              // 000000A39838: D613000F 248E4113
	v_div_scale_f32 v36, null, v26, v26, v4                    // 000000A39840: D6FC7C24 0412351A
	v_add_f32_e32 v30, 1.0, v30                                // 000000A39848: 063C3CF2
	v_div_scale_f32 v12, null, v31, v31, v14                   // 000000A3984C: D6FC7C0C 043A3F1F
	v_rcp_f32_e32 v43, v39                                     // 000000A39854: 7E565527
	v_fmac_f32_e32 v32, v15, v20                               // 000000A39858: 5640290F
	v_rcp_f32_e32 v38, v36                                     // 000000A3985C: 7E4C5524
	v_div_scale_f32 v33, null, v30, v30, v10                   // 000000A39860: D6FC7C21 042A3D1E
	v_rcp_f32_e32 v45, v12                                     // 000000A39868: 7E5A550C
	v_div_fixup_f32 v5, v11, v47, v5                           // 000000A3986C: D6270005 04165F0B
	v_div_scale_f32 v11, s6, v4, v26, v4                       // 000000A39874: D6FC060B 04123504
	v_fma_f32 v19, -v19, v32, v35                              // 000000A3987C: D6130013 248E4113
	v_rcp_f32_e32 v15, v33                                     // 000000A39884: 7E1E5521
	s_waitcnt vmcnt(7)                                         // 000000A39888: BF891FF7
	v_fma_mix_f32 v21, v27, v21, neg(0) op_sel_hi:[1,0,0]      // 000000A3988C: CC200015 8A022B1B
	v_mul_f32_e32 v5, v13, v5                                  // 000000A39894: 100A0B0D
	v_fma_mix_f32 v0, v25, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A39898: CC200000 8A020119
	v_fma_f32 v44, -v36, v38, 1.0                              // 000000A398A0: D613002C 23CA4D24
	v_div_fmas_f32 v19, v19, v20, v32                          // 000000A398A8: D6370013 04822913
	v_fma_f32 v13, -v12, v45, 1.0                              // 000000A398B0: D613000D 23CA5B0C
	s_mov_b32 vcc_lo, s6                                       // 000000A398B8: BEEA0006
	v_fma_mix_f32 v7, v7, v18, neg(0) op_sel_hi:[1,0,0]        // 000000A398BC: CC200007 8A022507
	v_fmac_f32_e32 v38, v44, v38                               // 000000A398C4: 564C4D2C
	v_fma_f32 v44, -v39, v43, 1.0                              // 000000A398C8: D613002C 23CA5727
	v_fma_f32 v46, -v33, v15, 1.0                              // 000000A398D0: D613002E 23CA1F21
	v_fmac_f32_e32 v45, v13, v45                               // 000000A398D8: 565A5B0D
	v_div_scale_f32 v13, s8, v14, v31, v14                     // 000000A398DC: D6FC080D 043A3F0E
	v_mul_f32_e32 v35, v11, v38                                // 000000A398E4: 10464D0B
	v_fmac_f32_e32 v43, v44, v43                               // 000000A398E8: 5656572C
	v_div_scale_f32 v44, s7, v9, v29, v9                       // 000000A398EC: D6FC072C 04263B09
	v_fmac_f32_e32 v15, v46, v15                               // 000000A398F4: 561E1F2E
	v_div_scale_f32 v46, s5, v10, v30, v10                     // 000000A398F8: D6FC052E 042A3D0A
	v_fma_f32 v20, -v36, v35, v11                              // 000000A39900: D6130014 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A39908: BF8701A4
	v_dual_mul_f32 v47, v13, v45 :: v_dual_mul_f32 v32, v44, v43// 000000A3990C: C8C65B0D 2F20572C
	v_div_fixup_f32 v6, v19, v8, v6                            // 000000A39914: D6270006 041A1113
	v_dual_fmac_f32 v35, v20, v38 :: v_dual_mul_f32 v20, v46, v15// 000000A3991C: C8064D14 23141F2E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A39924: BF870213
	v_fma_f32 v8, -v39, v32, v44                               // 000000A39928: D6130008 24B24127
	v_fma_f32 v19, -v12, v47, v13                              // 000000A39930: D6130013 24365F0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A39938: BF870214
	v_mul_f32_e32 v6, v21, v6                                  // 000000A3993C: 100C0D15
	v_fma_f32 v11, -v36, v35, v11                              // 000000A39940: D613000B 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A39948: BF870234
	v_fmac_f32_e32 v32, v8, v43                                // 000000A3994C: 56405708
	v_fma_f32 v8, -v33, v20, v46                               // 000000A39950: D6130008 24BA2921
	v_fmac_f32_e32 v47, v19, v45                               // 000000A39958: 565E5B13
	v_div_fmas_f32 v11, v11, v38, v35                          // 000000A3995C: D637000B 048E4D0B
	s_mov_b32 vcc_lo, s7                                       // 000000A39964: BEEA0007
	v_fma_f32 v19, -v39, v32, v44                              // 000000A39968: D6130013 24B24127
	v_fmac_f32_e32 v20, v8, v15                                // 000000A39970: 56281F08
	v_fma_f32 v8, -v12, v47, v13                               // 000000A39974: D6130008 24365F0C
	v_div_fixup_f32 v4, v11, v26, v4                           // 000000A3997C: D6270004 0412350B
	v_fma_mix_f32 v11, v34, v17, neg(0) op_sel_hi:[1,0,0]      // 000000A39984: CC20000B 8A022322
	v_div_fmas_f32 v12, v19, v43, v32                          // 000000A3998C: D637000C 04825713
	v_fma_f32 v13, -v33, v20, v46                              // 000000A39994: D613000D 24BA2921
	s_mov_b32 vcc_lo, s8                                       // 000000A3999C: BEEA0008
	s_waitcnt vmcnt(0)                                         // 000000A399A0: BF8903F7
	v_fma_mix_f32 v6, v23, v6, neg(0) op_sel_hi:[1,0,0]        // 000000A399A4: CC200006 8A020D17
	v_div_fmas_f32 v8, v8, v45, v47                            // 000000A399AC: D6370008 04BE5B08
	s_mov_b32 vcc_lo, s5                                       // 000000A399B4: BEEA0005
	v_div_fixup_f32 v9, v12, v29, v9                           // 000000A399B8: D6270009 04263B0C
	v_div_fmas_f32 v13, v13, v15, v20                          // 000000A399C0: D637000D 04521F0D
	v_fma_mix_f32 v12, v22, v24, neg(0) op_sel_hi:[1,0,0]      // 000000A399C8: CC20000C 8A023116
	v_div_fixup_f32 v8, v8, v31, v14                           // 000000A399D0: D6270008 043A3F08
	v_mul_f32_e32 v4, v7, v4                                   // 000000A399D8: 10080907
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A399DC: BF870194
	v_div_fixup_f32 v10, v13, v30, v10                         // 000000A399E0: D627000A 042A3D0D
	v_dual_mul_f32 v9, v12, v9 :: v_dual_mul_f32 v8, v11, v8   // 000000A399E8: C8C6130C 0908110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A399F0: BF870112
	v_mul_f32_e32 v0, v0, v10                                  // 000000A399F4: 10001500
	v_fma_mix_f32 v7, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A399F8: CC200007 8A02131C
	v_fma_mix_f32 v9, v2, v37, v3 op_sel_hi:[0,1,0]            // 000000A39A00: CC200009 140E4B02
	v_fma_mix_f32 v10, v5, v40, v6 op_sel_hi:[0,1,0]           // 000000A39A08: CC20000A 141A5105
	v_fma_mix_f32 v2, v2, v37, -v3 op_sel_hi:[0,1,0]           // 000000A39A10: CC200002 940E4B02
	v_fma_mix_f32 v0, v16, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A39A18: CC200000 8A020110
	v_fma_mix_f32 v11, v4, v41, v7 op_sel_hi:[0,1,0]           // 000000A39A20: CC20000B 141E5304
	v_fma_mix_f32 v3, v5, v40, -v6 op_sel_hi:[0,1,0]           // 000000A39A28: CC200003 941A5105
	v_fma_mix_f32 v4, v4, v41, -v7 op_sel_hi:[0,1,0]           // 000000A39A30: CC200004 941E5304
	v_add_f32_e32 v5, v9, v10                                  // 000000A39A38: 060A1509
	v_fma_mix_f32 v12, v8, v42, v0 op_sel_hi:[0,1,0]           // 000000A39A3C: CC20000C 14025508
	v_fma_mix_f32 v0, v8, v42, -v0 op_sel_hi:[0,1,0]           // 000000A39A44: CC200000 94025508
	v_dual_sub_f32 v7, v9, v10 :: v_dual_add_f32 v8, v2, v3    // 000000A39A4C: C9481509 07080702
	v_sub_f32_e32 v2, v2, v3                                   // 000000A39A54: 08040702
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A39A58: BF8701B4
	v_add_f32_e32 v6, v11, v12                                 // 000000A39A5C: 060C190B
	v_sub_f32_e32 v9, v11, v12                                 // 000000A39A60: 0812190B
	v_add_f32_e32 v10, v4, v0                                  // 000000A39A64: 06140104
	v_dual_sub_f32 v0, v4, v0 :: v_dual_add_f32 v3, v5, v6     // 000000A39A68: C9480104 00020D05
	v_sub_f32_e32 v4, v5, v6                                   // 000000A39A70: 08080D05
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A39A74: BF870003
	v_add_f32_e32 v6, v8, v10                                  // 000000A39A78: 060C1508
	v_sub_f32_e32 v8, v8, v10                                  // 000000A39A7C: 08101508
	v_add_f32_e32 v10, v7, v9                                  // 000000A39A80: 06141307
	v_mov_b32_dpp v5, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A39A84: 7E0A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000A39A8C: D5010003 200A0703
	v_sub_f32_e32 v7, v7, v9                                   // 000000A39A94: 080E1307
	v_mov_b32_dpp v14, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A39A98: 7E1C02FA FF016104
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A39AA0: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A39AA8: D501000A 200A150A
	v_add_f32_e32 v3, v3, v5                                   // 000000A39AB0: 06060B03
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A39AB4: 7E0A02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000A39ABC: D5010006 200A0D06
	v_cndmask_b32_e64 v15, -v4, v4, s2                         // 000000A39AC4: D501000F 200A0904
	v_add_f32_e32 v9, v10, v9                                  // 000000A39ACC: 0612130A
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39AD0: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000A39AD8: D5010003 200E0703
	v_add_f32_e32 v5, v6, v5                                   // 000000A39AE0: 060A0B06
	v_add_f32_e32 v6, v2, v0                                   // 000000A39AE4: 060C0102
	v_sub_f32_e32 v10, v2, v0                                  // 000000A39AE8: 08140102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A39AEC: BF870214
	v_add_f32_e32 v0, v3, v11                                  // 000000A39AF0: 06001703
	v_mov_b32_dpp v2, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39AF4: 7E0402FA FF016205
	v_cndmask_b32_e64 v3, -v5, v5, s3                          // 000000A39AFC: D5010003 200E0B05
	v_mov_b32_dpp v5, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39B04: 7E0A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A39B0C: D5010009 200E1309
	v_mov_b32_dpp v11, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A39B14: 7E1602FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000A39B1C: D5010006 200A0D06
	v_add_f32_e32 v2, v3, v2                                   // 000000A39B24: 06040503
	v_mov_b32_dpp v16, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A39B28: 7E2002FA FF01610A
	v_add_f32_e32 v5, v9, v5                                   // 000000A39B30: 060A0B09
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A39B34: D501000A 200A150A
	v_add_f32_e32 v6, v6, v11                                  // 000000A39B3C: 060C1706
	v_mov_b32_dpp v9, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39B40: 7E1202FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000A39B48: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39B50: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000A39B58: D5010005 20120B05
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39B60: 7E1802FA FF016206
	v_cndmask_b32_e64 v13, -v6, v6, s3                         // 000000A39B68: D501000D 200E0D06
	v_add_f32_e32 v4, v2, v9                                   // 000000A39B70: 06081302
	v_add_f32_e32 v10, v10, v16                                // 000000A39B74: 0614210A
	v_dual_add_f32 v6, v5, v11 :: v_dual_add_f32 v11, v15, v14 // 000000A39B78: C9081705 060A1D0F
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A39B80: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000A39B88: D5010008 200A1108
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A39B90: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000A39B98: D5010007 200A0F07
	v_add_f32_e32 v9, v13, v12                                 // 000000A39BA0: 0612190D
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39BA4: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000A39BAC: D501000B 200E170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A39BB4: BF870234
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v7, v15   // 000000A39BB8: C9081D08 08061F07
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39BC0: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000A39BC8: D501000A 200E150A
	v_add_f32_e32 v11, v11, v13                                // 000000A39BD0: 06161B0B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A39BD4: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39BD8: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000A39BE0: D5010008 200E1108
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A39BE8: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000A39BF0: D5010007 200E0F07
	v_add_f32_e32 v10, v10, v15                                // 000000A39BF8: 06141F0A
	v_mov_b32_dpp v3, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39BFC: 7E0602FA FF016400
	v_add_f32_e32 v8, v8, v13                                  // 000000A39C04: 06101B08
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000A39C08: D5010000 20120100
	v_add_f32_e32 v7, v7, v14                                  // 000000A39C10: 060E1D07
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39C14: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000A39C1C: D5010009 20121309
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39C24: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000A39C2C: D501000B 2012170B
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39C34: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000A39C3C: D5010008 20121108
	v_mov_b32_dpp v15, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39C44: 7E1E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000A39C4C: D5010007 20120F07
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A39C54: 7E2002FA FF01640A
	v_cndmask_b32_e64 v17, -v10, v10, s4                       // 000000A39C5C: D5010011 2012150A
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v9, v9, v12    // 000000A39C64: C9080700 00081909
	v_dual_add_f32 v10, v11, v13 :: v_dual_add_f32 v11, v8, v14// 000000A39C6C: C9081B0B 0A0A1D08
	v_add_f32_e32 v13, v7, v15                                 // 000000A39C74: 061A1F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A39C78: BF870214
	v_add_f32_e32 v15, v17, v16                                // 000000A39C7C: 061E2111
	v_mov_b32_dpp v2, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A39C80: 7E0402FA FF016800
	v_mov_b32_dpp v3, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A39C88: 7E0602FA FF016804
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A39C90: 7E0A02FA FF016806
	v_mov_b32_dpp v7, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A39C98: 7E0E02FA FF016809
	v_mov_b32_dpp v8, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A39CA0: 7E1002FA FF01680A
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A39CA8: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A39CB0: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A39CB8: 7E2002FA FF01680F
	s_mov_b32 s2, 0x3db504f3                                   // 000000A39CC0: BE8200FF 3DB504F3
	s_and_b32 exec_lo, exec_lo, s0                             // 000000A39CC8: 8B7E007E
	s_cbranch_execz 65                                         // 000000A39CCC: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi1ELi4EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x5dd4>
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000A39CD0: D501000F 20061F0F
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000A39CD8: D5010000 20060100
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A39CE0: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A39CE8: D5010006 20060D06
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A39CF0: D5010009 20061309
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000A39CF8: D501000D 20061B0D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A39D00: D501000A 2006150A
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A39D08: D501000B 2006170B
	v_dual_add_f32 v15, v15, v16 :: v_dual_add_f32 v0, v0, v2  // 000000A39D10: C908210F 0F000500
	v_add_f32_e32 v3, v4, v3                                   // 000000A39D18: 06060704
	v_add_f32_e32 v5, v6, v5                                   // 000000A39D1C: 060A0B06
	v_add_f32_e32 v7, v9, v7                                   // 000000A39D20: 060E0F09
	s_mul_i32 s0, s10, 0x500                                   // 000000A39D24: 9600FF0A 00000500
	v_dual_add_f32 v13, v13, v14 :: v_dual_add_f32 v8, v10, v8 // 000000A39D2C: C9081D0D 0D08110A
	s_mul_hi_i32 s1, s10, 0x500                                // 000000A39D34: 9701FF0A 00000500
	v_add_f32_e32 v11, v11, v12                                // 000000A39D3C: 0616190B
	s_add_u32 s0, s22, s0                                      // 000000A39D40: 80000016
	v_fma_mixlo_f16 v0, v0, s2, 0                              // 000000A39D44: CC210000 02000500
	s_addc_u32 s1, s23, s1                                     // 000000A39D4C: 82010117
	v_fma_mixhi_f16 v0, v3, s2, 0                              // 000000A39D50: CC220000 02000503
	s_add_u32 s0, s0, s12                                      // 000000A39D58: 80000C00
	v_fma_mixlo_f16 v2, v5, s2, 0                              // 000000A39D5C: CC210002 02000505
	s_addc_u32 s1, s1, s13                                     // 000000A39D64: 82010D01
	v_fma_mixhi_f16 v2, v7, s2, 0                              // 000000A39D68: CC220002 02000507
	v_fma_mixlo_f16 v3, v8, s2, 0                              // 000000A39D70: CC210003 02000508
	v_fma_mixhi_f16 v3, v11, s2, 0                             // 000000A39D78: CC220003 0200050B
	v_fma_mixlo_f16 v4, v13, s2, 0                             // 000000A39D80: CC210004 0200050D
	v_fma_mixhi_f16 v4, v15, s2, 0                             // 000000A39D88: CC220004 0200050F
	s_clause 0x7                                               // 000000A39D90: BF850007
	global_store_b16 v1, v0, s[0:1]                            // 000000A39D94: DC660000 00000001
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 000000A39D9C: DC960020 00000001
	global_store_b16 v1, v2, s[0:1] offset:64                  // 000000A39DA4: DC660040 00000201
	global_store_d16_hi_b16 v1, v2, s[0:1] offset:96           // 000000A39DAC: DC960060 00000201
	global_store_b16 v1, v3, s[0:1] offset:128                 // 000000A39DB4: DC660080 00000301
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:160          // 000000A39DBC: DC9600A0 00000301
	global_store_b16 v1, v4, s[0:1] offset:192                 // 000000A39DC4: DC6600C0 00000401
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:224          // 000000A39DCC: DC9600E0 00000401
	s_endpgm                                                   // 000000A39DD4: BFB00000
		...

