000000000076a600 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000076A600: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v15, 15, v0         // 00000076A608: CA240080 040E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000076A610: 32020084
	s_ashr_i32 s3, s2, 31                                      // 00000076A614: 86039F02
	v_mov_b32_e32 v16, 0                                       // 00000076A618: 7E200280
	s_lshl_b64 s[0:1], s[2:3], 4                               // 00000076A61C: 84808402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000076A620: BF870009
	v_dual_mov_b32 v9, s1 :: v_dual_lshlrev_b32 v2, 2, v15     // 00000076A624: CA220001 09021E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 00000076A62C: 30060282
	v_or_b32_e32 v8, s0, v1                                    // 00000076A630: 38100200
	.long 0x7f183880                                           // 00000076A634: 7F183880
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v5, 0              // 00000076A638: CA100080 1C040080
	v_mov_b32_e32 v6, 0                                        // 00000076A640: 7E0C0280
	s_waitcnt lgkmcnt(0)                                       // 00000076A644: BF89FC07
	s_clause 0x1                                               // 00000076A648: BF850001
	global_load_b32 v7, v2, s[4:5]                             // 00000076A64C: DC520000 07040002
	global_load_b32 v3, v3, s[4:5]                             // 00000076A654: DC520000 03040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 00000076A65C: 7CA8100C
	s_add_u32 s2, s4, s14                                      // 00000076A660: 80020E04
	s_addc_u32 s3, s5, s15                                     // 00000076A664: 82030F05
	s_lshr_b32 s0, s11, 31                                     // 00000076A668: 85009F0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000076A66C: BF870009
	s_add_u32 s14, s10, s0                                     // 00000076A670: 800E000A
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 00000076A674: 02141080
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 00000076A678: D501000E 01A80280
	s_addc_u32 s15, s11, 0                                     // 00000076A680: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000076A684: 86149F0B
	s_ashr_i64 s[0:1], s[14:15], 1                             // 00000076A688: 8680810E
	s_lshr_b32 s14, s20, 27                                    // 00000076A68C: 850E9B14
	.long 0xd72c0013                                           // 00000076A690: D72C0013
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 00000076A694: 0200010E
	.long 0xd72c000e                                           // 00000076A698: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 00000076A69C: 02021C12
	s_waitcnt vmcnt(1)                                         // 00000076A6A0: BF8907F7
	v_bfe_u32 v11, v7, 16, 1                                   // 00000076A6A4: D610000B 02052107
	s_waitcnt vmcnt(0)                                         // 00000076A6AC: BF8903F7
	v_bfe_u32 v18, v3, 16, 1                                   // 00000076A6B0: D6100012 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000076A6B8: BF870112
	v_add3_u32 v7, v7, v11, 0x7fff                             // 00000076A6BC: D6550007 03FE1707 00007FFF
	v_add3_u32 v3, v3, v18, 0x7fff                             // 00000076A6C8: D6550003 03FE2503 00007FFF
	v_lshlrev_b32_e32 v18, 2, v0                               // 00000076A6D4: 30240082
	s_delay_alu instid0(VALU_DEP_3)                            // 00000076A6D8: BF870003
	.long 0x7e183987                                           // 00000076A6DC: 7E183987
	v_mov_b32_e32 v7, 0                                        // 00000076A6E0: 7E0E0280
	.long 0xd72c000d                                           // 00000076A6E4: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 00000076A6E8: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 00000076A6EC: D6FE7C01 02021412
	.long 0xd72c0011                                           // 00000076A6F4: D72C0011
	v_cndmask_b32_e32 v0, v10, v1, vcc_lo                      // 00000076A6F8: 0200030A
	v_mad_u64_u32 v[10:11], null, v10, s0, s[2:3]              // 00000076A6FC: D6FE7C0A 0008010A
	s_add_u32 s2, s10, s14                                     // 00000076A704: 80020E0A
	s_addc_u32 s3, s11, 0                                      // 00000076A708: 8203800B
	v_and_or_b32 v3, 0xffff0000, v3, v12                       // 00000076A70C: D6570003 043206FF FFFF0000
	s_lshr_b64 s[2:3], s[2:3], 5                               // 00000076A718: 85828502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000076A71C: BF870009
	.long 0xd4440000                                           // 00000076A720: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 00000076A724: 02021E02
	v_add3_u32 v0, v2, v14, v13                                // 00000076A728: D6550000 04361D02
	v_add3_u32 v17, v19, v11, v17                              // 00000076A730: D6550011 04461713
	ds_store_b32 v18, v3                                       // 00000076A738: D8340000 00000312
	s_waitcnt lgkmcnt(0)                                       // 00000076A740: BF89FC07
	s_barrier                                                  // 00000076A744: BFBD0000
	buffer_gl0_inv                                             // 00000076A748: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 00000076A750: BE832000
	s_cbranch_execz 26                                         // 00000076A754: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1c0>
	s_add_u32 s1, s4, s16                                      // 00000076A758: 80011004
	s_addc_u32 s14, s5, s17                                    // 00000076A75C: 820E1105
	v_lshlrev_b32_e32 v2, 1, v15                               // 00000076A760: 30041E81
	.long 0xd7000103                                           // 00000076A764: D7000103
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 00000076A768: 02020201
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000076A76C: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s14, v0, s1                  // 00000076A770: D5207C04 0006000E
	v_lshlrev_b32_e32 v5, 4, v15                               // 00000076A778: 300A1E84
	.long 0xd7000102                                           // 00000076A77C: D7000102
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000076A780: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000076A784: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s1                    // 00000076A788: D5207C03 00060880
	.long 0xd7000104                                           // 00000076A790: D7000104
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 00000076A794: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000076A798: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s1                   // 00000076A79C: D5207C05 00062280
	s_clause 0x1                                               // 00000076A7A4: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 00000076A7A8: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 00000076A7B0: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 00000076A7B8: BF8907F7
	v_cvt_f32_f16_e32 v28, v2                                  // 00000076A7BC: 7E381702
	s_or_b32 exec_lo, exec_lo, s3                              // 00000076A7C0: 8C7E037E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 00000076A7C4: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 00000076A7CC: CA100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 00000076A7D4: CA100080 16160080
	v_mov_b32_e32 v24, 0                                       // 00000076A7DC: 7E300280
	s_and_saveexec_b32 s3, s0                                  // 00000076A7E0: BE832000
	s_cbranch_execz 657                                        // 00000076A7E4: BFA50291 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xc2c>
	s_mul_i32 s0, s11, 6                                       // 00000076A7E8: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 00000076A7EC: 9681860A
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 00000076A7F0: CA220080 0C0A1E85
	s_add_i32 s18, s1, s0                                      // 00000076A7F8: 81120001
	v_lshlrev_b32_e32 v2, 1, v15                               // 00000076A7FC: 30041E81
	.long 0xd7000001                                           // 00000076A800: D7000001
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000076A804: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000076A808: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s0                  // 00000076A80C: D5207C00 00020011
	v_mov_b32_e32 v23, v12                                     // 00000076A814: 7E2E030C
	.long 0xd7000001                                           // 00000076A818: D7000001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000076A81C: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000076A820: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s0                    // 00000076A824: D5207C00 00020080
	v_lshl_or_b32 v25, v15, 4, 0x100                           // 00000076A82C: D6560019 03FD090F 00000100
	.long 0xd7000001                                           // 00000076A838: D7000001
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000076A83C: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000076A840: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s0                   // 00000076A844: D5207C00 00020005
	v_dual_mov_b32 v26, v15 :: v_dual_mov_b32 v21, v12         // 00000076A84C: CA10010F 1A14010C
	.long 0xd700000d                                           // 00000076A854: D700000D
	v_cndmask_b32_e32 v0, v1, v160, vcc_lo                     // 00000076A858: 02014101
	s_delay_alu instid0(VALU_DEP_1)                            // 00000076A85C: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s0                   // 00000076A860: D5207C0E 00020080
	v_mov_b32_e32 v24, v12                                     // 00000076A868: 7E30030C
	v_mov_b32_e32 v22, v12                                     // 00000076A86C: 7E2C030C
	v_mov_b32_e32 v20, v12                                     // 00000076A870: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 00000076A874: 7E26030C
	v_mov_b32_e32 v18, v12                                     // 00000076A878: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 00000076A87C: 7E20030C
	v_mov_b32_e32 v27, v28                                     // 00000076A880: 7E36031C
	s_lshl_b64 s[14:15], s[10:11], 2                           // 00000076A884: 848E820A
	s_mul_i32 s17, s10, 6                                      // 00000076A888: 9611860A
	s_mov_b32 s16, 0                                           // 00000076A88C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000076A890: 8484810A
	s_branch 587                                               // 00000076A894: BFA0024B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xbc4>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000076A898: 8C7E0A7E
	v_and_b32_e32 v29, 0xff, v4                                // 00000076A89C: 363A08FF 000000FF
	s_and_b32 s0, exec_lo, s0                                  // 00000076A8A4: 8B00007E
	v_add_nc_u32_e32 v25, 0x100, v25                           // 00000076A8A8: 4A3232FF 00000100
	s_or_b32 s16, s0, s16                                      // 00000076A8B0: 8C101000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076A8B4: BF8700B2
	v_lshlrev_b32_e32 v29, 2, v29                              // 00000076A8B8: 303A3A82
	ds_load_b32 v45, v29                                       // 00000076A8BC: D8D80000 2D00001D
	v_lshrrev_b32_e32 v29, 6, v4                               // 00000076A8C4: 323A0886
	v_and_b32_e32 v29, 0x3fc, v29                              // 00000076A8C8: 363A3AFF 000003FC
	ds_load_b32 v46, v29                                       // 00000076A8D0: D8D80000 2E00001D
	v_lshrrev_b32_e32 v29, 14, v4                              // 00000076A8D8: 323A088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 00000076A8DC: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000076A8E0: BF870112
	v_and_b32_e32 v29, 0x3fc, v29                              // 00000076A8E4: 363A3AFF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000076A8EC: 360808FF 000003FC
	ds_load_b32 v47, v29                                       // 00000076A8F4: D8D80000 2F00001D
	ds_load_b32 v48, v4                                        // 00000076A8FC: D8D80000 30000004
	v_and_b32_e32 v4, 0xff, v5                                 // 00000076A904: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076A90C: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000076A910: 30080882
	ds_load_b32 v49, v4                                        // 00000076A914: D8D80000 31000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 00000076A91C: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000076A920: 360808FF 000003FC
	ds_load_b32 v50, v4                                        // 00000076A928: D8D80000 32000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 00000076A930: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076A934: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000076A938: 360808FF 000003FC
	ds_load_b32 v51, v4                                        // 00000076A940: D8D80000 33000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 00000076A948: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000076A94C: 360808FF 000003FC
	ds_load_b32 v52, v4                                        // 00000076A954: D8D80000 34000004
	v_and_b32_e32 v4, 0xff, v6                                 // 00000076A95C: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076A964: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000076A968: 30080882
	ds_load_b32 v53, v4                                        // 00000076A96C: D8D80000 35000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 00000076A974: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000076A978: 360808FF 000003FC
	ds_load_b32 v54, v4                                        // 00000076A980: D8D80000 36000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 00000076A988: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076A98C: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000076A990: 360808FF 000003FC
	ds_load_b32 v55, v4                                        // 00000076A998: D8D80000 37000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 00000076A9A0: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000076A9A4: 360808FF 000003FC
	ds_load_b32 v56, v4                                        // 00000076A9AC: D8D80000 38000004
	v_and_b32_e32 v4, 0xff, v7                                 // 00000076A9B4: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076A9BC: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000076A9C0: 30080882
	ds_load_b32 v57, v4                                        // 00000076A9C4: D8D80000 39000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 00000076A9CC: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000076A9D0: 360808FF 000003FC
	ds_load_b32 v58, v4                                        // 00000076A9D8: D8D80000 3A000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 00000076A9E0: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076A9E4: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000076A9E8: 360808FF 000003FC
	ds_load_b32 v59, v4                                        // 00000076A9F0: D8D80000 3B000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 00000076A9F8: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000076A9FC: 360808FF 000003FC
	ds_load_b32 v60, v4                                        // 00000076AA04: D8D80000 3C000004
	.long 0xd73c0004                                           // 00000076AA0C: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000076AA10: 02021681
	v_add_nc_u32_e32 v11, 0x200, v11                           // 00000076AA14: 4A1616FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AA1C: BF870092
	.long 0xd7000029                                           // 00000076AA20: D7000029
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 00000076AA24: 02020806
	v_add_co_ci_u32_e64 v42, null, s7, v5, s0                  // 00000076AA28: D5207C2A 00020A07
	s_clause 0x3                                               // 00000076AA30: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 00000076AA34: DC5E0000 047C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 00000076AA3C: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 00000076AA44: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 00000076AA4C: DC5E0030 257C0029
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000076AA54: BF890CF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 00000076AA58: CC1A4004 1A025B04
	s_waitcnt lgkmcnt(14)                                      // 00000076AA60: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076AA64: BF8700A1
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 00000076AA68: CC1A4004 1C125D05
	s_waitcnt lgkmcnt(13)                                      // 00000076AA70: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 00000076AA74: CC1A4004 1C125F06
	s_waitcnt lgkmcnt(12)                                      // 00000076AA7C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076AA80: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 00000076AA84: CC1A4004 1C126107
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000076AA8C: BF8908B7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000076AA90: CC1A4004 1C12631D
	s_waitcnt lgkmcnt(10)                                      // 00000076AA98: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076AA9C: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000076AAA0: CC1A4004 1C12651E
	s_waitcnt lgkmcnt(9)                                       // 00000076AAA8: BF89FC97
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000076AAAC: CC1A4004 1C12671F
	s_waitcnt lgkmcnt(8)                                       // 00000076AAB4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076AAB8: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000076AABC: CC1A4004 1C126920
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000076AAC4: BF890477
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000076AAC8: CC1A4004 1C126B21
	s_waitcnt lgkmcnt(6)                                       // 00000076AAD0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076AAD4: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000076AAD8: CC1A4004 1C126D22
	s_waitcnt lgkmcnt(5)                                       // 00000076AAE0: BF89FC57
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000076AAE4: CC1A4004 1C126F23
	s_waitcnt lgkmcnt(4)                                       // 00000076AAEC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076AAF0: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000076AAF4: CC1A4004 1C127124
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000076AAFC: BF890037
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000076AB00: CC1A4004 1C127325
	.long 0xd7000025                                           // 00000076AB08: D7000025
	v_cndmask_b32_e32 v0, v41, v4, vcc_lo                      // 00000076AB0C: 02000929
	s_waitcnt lgkmcnt(2)                                       // 00000076AB10: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000076AB14: BF8701C2
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000076AB18: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v38, null, s5, v42, s0                 // 00000076AB20: D5207C26 00025405
	.long 0xd700002b                                           // 00000076AB28: D700002B
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 00000076AB2C: 02001D29
	s_waitcnt lgkmcnt(1)                                       // 00000076AB30: BF89FC17
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 00000076AB34: CC1A4004 1C127727
	v_add_co_ci_u32_e64 v44, null, s15, v42, s0                // 00000076AB3C: D5207C2C 0002540F
	.long 0xd7000029                                           // 00000076AB44: D7000029
	v_cndmask_b32_e32 v0, v41, v17, vcc_lo                     // 00000076AB48: 02002329
	s_waitcnt lgkmcnt(0)                                       // 00000076AB4C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000076AB50: BF870123
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 00000076AB54: CC1A4004 1C127928
	v_add_co_ci_u32_e64 v42, null, s18, v42, s0                // 00000076AB5C: D5207C2A 00025412
	v_fmac_f32_e32 v24, v28, v4                                // 00000076AB64: 5630091C
	s_clause 0x3                                               // 00000076AB68: BF850003
	global_load_b128 v[4:7], v[37:38], off                     // 00000076AB6C: DC5E0000 047C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 00000076AB74: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 00000076AB7C: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 00000076AB84: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 00000076AB8C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 00000076AB90: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AB98: BF870091
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 00000076AB9C: CC1A4004 1C125D05
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 00000076ABA4: CC1A4004 1C125F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076ABAC: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 00000076ABB0: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 00000076ABB8: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000076ABBC: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076ABC4: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000076ABC8: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000076ABD0: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076ABD8: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000076ABDC: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 00000076ABE4: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000076ABE8: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076ABF0: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000076ABF4: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000076ABFC: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076AC04: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000076AC08: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 00000076AC10: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000076AC14: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AC1C: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000076AC20: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 00000076AC28: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AC30: BF870091
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 00000076AC34: CC1A4004 1C127928
	v_fmac_f32_e32 v23, v28, v4                                // 00000076AC3C: 562E091C
	s_clause 0x3                                               // 00000076AC40: BF850003
	global_load_b128 v[4:7], v[43:44], off                     // 00000076AC44: DC5E0000 047C002B
	global_load_b128 v[29:32], v[43:44], off offset:16         // 00000076AC4C: DC5E0010 1D7C002B
	global_load_b128 v[33:36], v[43:44], off offset:32         // 00000076AC54: DC5E0020 217C002B
	global_load_b128 v[37:40], v[43:44], off offset:48         // 00000076AC5C: DC5E0030 257C002B
	.long 0xd700002b                                           // 00000076AC64: D700002B
	v_cndmask_b32_e32 v0, v43, v14, vcc_lo                     // 00000076AC68: 02001D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076AC6C: BF8700B1
	v_add_co_ci_u32_e64 v44, null, s15, v44, s0                // 00000076AC70: D5207C2C 0002580F
	s_waitcnt vmcnt(3)                                         // 00000076AC78: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 00000076AC7C: CC1A4004 1A025B04
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 00000076AC84: CC1A4004 1C125D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AC8C: BF870091
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 00000076AC90: CC1A4004 1C125F06
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 00000076AC98: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 00000076ACA0: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076ACA4: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000076ACA8: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000076ACB0: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076ACB8: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000076ACBC: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000076ACC4: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 00000076ACCC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076ACD0: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000076ACD4: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000076ACDC: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076ACE4: BF870091
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000076ACE8: CC1A4004 1C126F23
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000076ACF0: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 00000076ACF8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076ACFC: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000076AD00: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000076AD08: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AD10: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 00000076AD14: CC1A4004 1C127727
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 00000076AD1C: CC1A4004 1C127928
	s_delay_alu instid0(VALU_DEP_1)                            // 00000076AD24: BF870001
	v_fmac_f32_e32 v22, v28, v4                                // 00000076AD28: 562C091C
	s_clause 0x3                                               // 00000076AD2C: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 00000076AD30: DC5E0000 047C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 00000076AD38: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 00000076AD40: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 00000076AD48: DC5E0030 257C0029
	.long 0xd7000029                                           // 00000076AD50: D7000029
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 00000076AD54: 02001D29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076AD58: BF8700B1
	v_add_co_ci_u32_e64 v42, null, s15, v42, s0                // 00000076AD5C: D5207C2A 0002540F
	s_waitcnt vmcnt(3)                                         // 00000076AD64: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 00000076AD68: CC1A4004 1A025B04
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 00000076AD70: CC1A4004 1C125D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AD78: BF870091
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 00000076AD7C: CC1A4004 1C125F06
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 00000076AD84: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 00000076AD8C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AD90: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000076AD94: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000076AD9C: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076ADA4: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000076ADA8: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000076ADB0: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 00000076ADB8: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076ADBC: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000076ADC0: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000076ADC8: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076ADD0: BF870091
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000076ADD4: CC1A4004 1C126F23
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000076ADDC: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 00000076ADE4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076ADE8: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000076ADEC: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000076ADF4: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076ADFC: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 00000076AE00: CC1A4004 1C127727
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 00000076AE08: CC1A4004 1C127928
	s_delay_alu instid0(VALU_DEP_1)                            // 00000076AE10: BF870001
	v_fmac_f32_e32 v21, v28, v4                                // 00000076AE14: 562A091C
	s_clause 0x3                                               // 00000076AE18: BF850003
	global_load_b128 v[4:7], v[43:44], off                     // 00000076AE1C: DC5E0000 047C002B
	global_load_b128 v[29:32], v[43:44], off offset:16         // 00000076AE24: DC5E0010 1D7C002B
	global_load_b128 v[33:36], v[43:44], off offset:32         // 00000076AE2C: DC5E0020 217C002B
	global_load_b128 v[37:40], v[43:44], off offset:48         // 00000076AE34: DC5E0030 257C002B
	s_waitcnt vmcnt(3)                                         // 00000076AE3C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 00000076AE40: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AE48: BF870091
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 00000076AE4C: CC1A4004 1C125D05
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 00000076AE54: CC1A4004 1C125F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076AE5C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 00000076AE60: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 00000076AE68: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000076AE6C: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AE74: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000076AE78: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000076AE80: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076AE88: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000076AE8C: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 00000076AE94: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000076AE98: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AEA0: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000076AEA4: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000076AEAC: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076AEB4: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000076AEB8: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 00000076AEC0: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000076AEC4: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AECC: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000076AED0: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 00000076AED8: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AEE0: BF870091
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 00000076AEE4: CC1A4004 1C127928
	v_fmac_f32_e32 v20, v28, v4                                // 00000076AEEC: 5628091C
	s_clause 0x3                                               // 00000076AEF0: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 00000076AEF4: DC5E0000 047C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 00000076AEFC: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 00000076AF04: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 00000076AF0C: DC5E0030 257C0029
	s_waitcnt vmcnt(3)                                         // 00000076AF14: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 00000076AF18: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AF20: BF870091
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 00000076AF24: CC1A4004 1C125D05
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 00000076AF2C: CC1A4004 1C125F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076AF34: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 00000076AF38: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 00000076AF40: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000076AF44: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AF4C: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000076AF50: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000076AF58: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076AF60: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000076AF64: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 00000076AF6C: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000076AF70: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AF78: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000076AF7C: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000076AF84: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076AF8C: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000076AF90: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 00000076AF98: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000076AF9C: CC1A4004 1C127325
	.long 0xd7000025                                           // 00000076AFA4: D7000025
	v_cndmask_b32_e32 v0, v43, v14, vcc_lo                     // 00000076AFA8: 02001D2B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000076AFAC: BF870122
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000076AFB0: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v38, null, s15, v44, s0                // 00000076AFB8: D5207C26 0002580F
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 00000076AFC0: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076AFC8: BF870091
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 00000076AFCC: CC1A4004 1C127928
	v_fmac_f32_e32 v19, v28, v4                                // 00000076AFD4: 5626091C
	s_clause 0x3                                               // 00000076AFD8: BF850003
	global_load_b128 v[4:7], v[37:38], off                     // 00000076AFDC: DC5E0000 047C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 00000076AFE4: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 00000076AFEC: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 00000076AFF4: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 00000076AFFC: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 00000076B000: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B008: BF870091
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 00000076B00C: CC1A4004 1C125D05
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 00000076B014: CC1A4004 1C125F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076B01C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 00000076B020: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 00000076B028: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000076B02C: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B034: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000076B038: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000076B040: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076B048: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000076B04C: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 00000076B054: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000076B058: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B060: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000076B064: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000076B06C: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076B074: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000076B078: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 00000076B080: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000076B084: CC1A4004 1C127325
	.long 0xd7000025                                           // 00000076B08C: D7000025
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 00000076B090: 02001D29
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000076B094: BF8701B2
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000076B098: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v38, null, s15, v42, s0                // 00000076B0A0: D5207C26 0002540F
	.long 0xd700000d                                           // 00000076B0A8: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 00000076B0AC: 0201410D
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 00000076B0B0: CC1A4004 1C127727
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 00000076B0B8: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B0C0: BF870092
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 00000076B0C4: CC1A4004 1C127928
	v_fmac_f32_e32 v18, v28, v4                                // 00000076B0CC: 5624091C
	s_clause 0x3                                               // 00000076B0D0: BF850003
	global_load_b128 v[4:7], v[37:38], off                     // 00000076B0D4: DC5E0000 047C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 00000076B0DC: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 00000076B0E4: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 00000076B0EC: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 00000076B0F4: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 00000076B0F8: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000076B100: BF870121
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 00000076B104: CC1A4004 1C125D05
	v_mov_b32_e32 v5, v1                                       // 00000076B10C: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 00000076B110: CC1A4004 1C125F06
	v_mov_b32_e32 v6, v2                                       // 00000076B118: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000076B11C: BF870132
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 00000076B120: CC1A4004 1C126107
	v_mov_b32_e32 v7, v3                                       // 00000076B128: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 00000076B12C: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000076B130: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B138: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000076B13C: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000076B144: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076B14C: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000076B150: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 00000076B158: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000076B15C: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B164: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000076B168: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000076B170: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076B178: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000076B17C: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 00000076B184: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000076B188: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B190: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000076B194: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 00000076B19C: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B1A4: BF870091
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 00000076B1A8: CC1A4004 1C127928
	v_fmac_f32_e32 v16, v28, v4                                // 00000076B1B0: 5620091C
	v_mov_b32_e32 v4, v0                                       // 00000076B1B4: 7E080300
	v_mov_b32_e32 v28, v27                                     // 00000076B1B8: 7E38031B
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000076B1BC: 917E107E
	s_cbranch_execz 25                                         // 00000076B1C0: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xc28>
	s_waitcnt vmcnt(0)                                         // 00000076B1C4: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v26, 16, v26    // 00000076B1C8: CA200105 011A3490
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v3, v7             // 00000076B1D0: CA100104 00020107
	v_mov_b32_e32 v2, v6                                       // 00000076B1D8: 7E040306
	s_delay_alu instid0(VALU_DEP_3)                            // 00000076B1DC: BF870003
	.long 0xd4430000                                           // 00000076B1E0: D4430000
	v_cndmask_b32_e32 v1, s2, v26, vcc_lo                      // 00000076B1E4: 02023402
	s_mov_b32 s10, exec_lo                                     // 00000076B1E8: BE8A007E
	.long 0xd4c4007e                                           // 00000076B1EC: D4C4007E
	v_cndmask_b32_e32 v1, s2, v26, vcc_lo                      // 00000076B1F0: 02023402
	s_cbranch_execz 64936                                      // 00000076B1F4: BFA5FDA8 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x298>
	.long 0xd7000100                                           // 00000076B1F8: D7000100
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 00000076B1FC: 0202330A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000076B200: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s1                   // 00000076B204: D5207C01 00062280
	global_load_d16_b16 v27, v[13:14], off                     // 00000076B20C: DC820000 1B7C000D
	global_load_b128 v[0:3], v[0:1], off                       // 00000076B214: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 00000076B21C: BF8907F7
	v_cvt_f32_f16_e32 v27, v27                                 // 00000076B220: 7E36171B
	s_branch 64924                                             // 00000076B224: BFA0FD9C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x298>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000076B228: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076B22C: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000076B230: 8C7E037E
	.long 0xd71f0000                                           // 00000076B234: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000076B238: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 00000076B23C: 3A020088
	v_xor_b32_e32 v11, 4, v0                                   // 00000076B240: 3A160084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B244: BF870092
	.long 0xd44c0000                                           // 00000076B248: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 00000076B24C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 00000076B250: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000076B258: BF870113
	.long 0xd44c0000                                           // 00000076B25C: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 00000076B260: 020216A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000076B264: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 00000076B268: BF870002
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 00000076B26C: D501000B 00021700
	ds_bpermute_b32 v2, v1, v24                                // 00000076B274: DACC0000 02001801
	s_waitcnt lgkmcnt(0)                                       // 00000076B27C: BF89FC07
	v_add_f32_e32 v2, v24, v2                                  // 00000076B280: 06040518
	s_waitcnt vmcnt(0)                                         // 00000076B284: BF8903F7
	ds_bpermute_b32 v4, v1, v22                                // 00000076B288: DACC0000 04001601
	ds_bpermute_b32 v3, v1, v23                                // 00000076B290: DACC0000 03001701
	ds_bpermute_b32 v6, v1, v20                                // 00000076B298: DACC0000 06001401
	ds_bpermute_b32 v5, v1, v21                                // 00000076B2A0: DACC0000 05001501
	ds_bpermute_b32 v7, v1, v19                                // 00000076B2A8: DACC0000 07001301
	ds_bpermute_b32 v10, v1, v18                               // 00000076B2B0: DACC0000 0A001201
	ds_bpermute_b32 v1, v1, v16                                // 00000076B2B8: DACC0000 01001001
	s_waitcnt lgkmcnt(6)                                       // 00000076B2C0: BF89FC67
	v_dual_add_f32 v4, v22, v4 :: v_dual_lshlrev_b32 v11, 2, v11// 00000076B2C4: C9220916 040A1682
	ds_bpermute_b32 v12, v11, v2                               // 00000076B2CC: DACC0000 0C00020B
	s_waitcnt lgkmcnt(5)                                       // 00000076B2D4: BF89FC57
	v_dual_add_f32 v3, v23, v3 :: v_dual_add_f32 v6, v20, v6   // 00000076B2D8: C9080717 03060D14
	v_xor_b32_e32 v20, 2, v0                                   // 00000076B2E0: 3A280082
	s_waitcnt lgkmcnt(2)                                       // 00000076B2E4: BF89FC27
	v_dual_add_f32 v5, v21, v5 :: v_dual_add_f32 v10, v18, v10 // 00000076B2E8: C9080B15 050A1512
	s_waitcnt lgkmcnt(1)                                       // 00000076B2F0: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 00000076B2F4: 06020310
	ds_bpermute_b32 v13, v11, v3                               // 00000076B2F8: DACC0000 0D00030B
	.long 0xd44c0000                                           // 00000076B300: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 00000076B304: 020228A0
	ds_bpermute_b32 v14, v11, v4                               // 00000076B308: DACC0000 0E00040B
	ds_bpermute_b32 v16, v11, v5                               // 00000076B310: DACC0000 1000050B
	ds_bpermute_b32 v17, v11, v6                               // 00000076B318: DACC0000 1100060B
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 00000076B320: D5010014 00022900
	v_add_f32_e32 v7, v19, v7                                  // 00000076B328: 060E0F13
	ds_bpermute_b32 v19, v11, v10                              // 00000076B32C: DACC0000 13000A0B
	v_lshlrev_b32_e32 v20, 2, v20                              // 00000076B334: 30282882
	ds_bpermute_b32 v18, v11, v7                               // 00000076B338: DACC0000 1200070B
	s_waitcnt lgkmcnt(6)                                       // 00000076B340: BF89FC67
	v_add_f32_e32 v2, v2, v12                                  // 00000076B344: 06041902
	ds_bpermute_b32 v11, v11, v1                               // 00000076B348: DACC0000 0B00010B
	s_waitcnt lgkmcnt(5)                                       // 00000076B350: BF89FC57
	v_dual_add_f32 v3, v3, v13 :: v_dual_add_f32 v12, v4, v14  // 00000076B354: C9081B03 030C1D04
	v_xor_b32_e32 v4, 1, v0                                    // 00000076B35C: 3A080081
	s_waitcnt lgkmcnt(3)                                       // 00000076B360: BF89FC37
	v_dual_add_f32 v13, v5, v16 :: v_dual_add_f32 v14, v6, v17 // 00000076B364: C9082105 0D0E2306
	ds_bpermute_b32 v5, v20, v3                                // 00000076B36C: DACC0000 05000314
	ds_bpermute_b32 v6, v20, v12                               // 00000076B374: DACC0000 06000C14
	s_waitcnt lgkmcnt(4)                                       // 00000076B37C: BF89FC47
	v_add_f32_e32 v10, v10, v19                                // 00000076B380: 0614270A
	.long 0xd44c0000                                           // 00000076B384: D44C0000
	v_cndmask_b32_e32 v1, 32, v4, vcc_lo                       // 00000076B388: 020208A0
	ds_bpermute_b32 v16, v20, v13                              // 00000076B38C: DACC0000 10000D14
	ds_bpermute_b32 v17, v20, v14                              // 00000076B394: DACC0000 11000E14
	s_waitcnt lgkmcnt(5)                                       // 00000076B39C: BF89FC57
	v_add_f32_e32 v7, v7, v18                                  // 00000076B3A0: 060E2507
	ds_bpermute_b32 v19, v20, v10                              // 00000076B3A4: DACC0000 13000A14
	s_waitcnt lgkmcnt(5)                                       // 00000076B3AC: BF89FC57
	v_add_f32_e32 v11, v1, v11                                 // 00000076B3B0: 06161701
	ds_bpermute_b32 v1, v20, v2                                // 00000076B3B4: DACC0000 01000214
	v_cndmask_b32_e64 v0, v0, v4, s0                           // 00000076B3BC: D5010000 00020900
	ds_bpermute_b32 v18, v20, v7                               // 00000076B3C4: DACC0000 12000714
	.long 0xd44a0000                                           // 00000076B3CC: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 00000076B3D0: 02021E80
	v_lshlrev_b32_e32 v21, 2, v0                               // 00000076B3D4: 302A0082
	s_and_b32 s0, s0, vcc_lo                                   // 00000076B3D8: 8B006A00
	s_waitcnt lgkmcnt(5)                                       // 00000076B3DC: BF89FC57
	v_dual_add_f32 v5, v3, v5 :: v_dual_add_f32 v6, v12, v6    // 00000076B3E0: C9080B03 05060D0C
	s_waitcnt lgkmcnt(4)                                       // 00000076B3E8: BF89FC47
	v_add_f32_e32 v0, v13, v16                                 // 00000076B3EC: 0600210D
	ds_bpermute_b32 v12, v21, v6                               // 00000076B3F0: DACC0000 0C000615
	s_waitcnt lgkmcnt(2)                                       // 00000076B3F8: BF89FC27
	v_add_f32_e32 v4, v2, v1                                   // 00000076B3FC: 06080302
	ds_bpermute_b32 v20, v20, v11                              // 00000076B400: DACC0000 14000B14
	v_add_f32_e32 v1, v14, v17                                 // 00000076B408: 0602230E
	s_waitcnt lgkmcnt(2)                                       // 00000076B40C: BF89FC27
	v_dual_add_f32 v7, v7, v18 :: v_dual_add_f32 v14, v10, v19 // 00000076B410: C9082507 070E270A
	ds_bpermute_b32 v10, v21, v4                               // 00000076B418: DACC0000 0A000415
	ds_bpermute_b32 v2, v21, v0                                // 00000076B420: DACC0000 02000015
	ds_bpermute_b32 v13, v21, v7                               // 00000076B428: DACC0000 0D000715
	ds_bpermute_b32 v17, v21, v14                              // 00000076B430: DACC0000 11000E15
	s_waitcnt lgkmcnt(4)                                       // 00000076B438: BF89FC47
	v_add_f32_e32 v16, v11, v20                                // 00000076B43C: 0620290B
	ds_bpermute_b32 v11, v21, v5                               // 00000076B440: DACC0000 0B000515
	ds_bpermute_b32 v3, v21, v1                                // 00000076B448: DACC0000 03000115
	ds_bpermute_b32 v18, v21, v16                              // 00000076B450: DACC0000 12001015
	s_and_saveexec_b32 s1, s0                                  // 00000076B458: BE812000
	s_cbranch_execz 69                                         // 00000076B45C: BFA50045 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xf74>
	.long 0xd73c0008                                           // 00000076B460: D73C0008
	v_cndmask_b32_e32 v1, 2, v8, vcc_lo                        // 00000076B464: 02021082
	s_waitcnt lgkmcnt(4)                                       // 00000076B468: BF89FC47
	v_dual_add_f32 v13, v7, v13 :: v_dual_add_f32 v12, v6, v12 // 00000076B46C: C9081B07 0D0C1906
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000076B474: 8480820C
	s_waitcnt lgkmcnt(0)                                       // 00000076B478: BF89FC07
	v_dual_add_f32 v15, v16, v18 :: v_dual_add_f32 v14, v14, v17// 00000076B47C: C9082510 0F0E230E
	.long 0xd7006a06                                           // 00000076B484: D7006A06
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 00000076B488: 02021008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000076B48C: BF8701A1
	v_add_co_ci_u32_e64 v7, null, s9, v9, vcc_lo               // 00000076B490: D5207C07 01AA1209
	v_dual_add_f32 v16, v5, v11 :: v_dual_add_f32 v17, v4, v10 // 00000076B498: C9081705 10101504
	.long 0xd7006a08                                           // 00000076B4A0: D7006A08
	v_cndmask_b32_e32 v0, v6, v0, vcc_lo                       // 00000076B4A4: 02000106
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000076B4A8: BF8700D3
	v_mad_u64_u32 v[4:5], null, s12, 12, v[6:7]                // 00000076B4AC: D6FE7C04 0419180C
	v_add_co_ci_u32_e64 v9, null, s1, v7, vcc_lo               // 00000076B4B4: D5207C09 01AA0E01
	s_lshl_b64 s[0:1], s[12:13], 3                             // 00000076B4BC: 8480830C
	v_dual_add_f32 v18, v1, v3 :: v_dual_add_f32 v19, v0, v2   // 00000076B4C0: C9080701 12120500
	.long 0xd7006a0a                                           // 00000076B4C8: D7006A0A
	v_cndmask_b32_e32 v0, v6, v0, vcc_lo                       // 00000076B4CC: 02000106
	v_add_co_ci_u32_e64 v11, null, s1, v7, vcc_lo              // 00000076B4D0: D5207C0B 01AA0E01
	s_clause 0x2                                               // 00000076B4D8: BF850002
	global_store_b32 v[6:7], v17, off                          // 00000076B4DC: DC6A0000 007C1106
	global_store_b32 v[8:9], v16, off                          // 00000076B4E4: DC6A0000 007C1008
	global_store_b32 v[10:11], v12, off                        // 00000076B4EC: DC6A0000 007C0C0A
	v_mad_u64_u32 v[5:6], null, s13, 12, v[5:6]                // 00000076B4F4: D6FE7C05 0415180D
	.long 0xd7006a00                                           // 00000076B4FC: D7006A00
	v_cndmask_b32_e32 v0, v10, v0, vcc_lo                      // 00000076B500: 0200010A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076B504: BF8700A1
	v_add_co_ci_u32_e64 v1, null, s1, v11, vcc_lo              // 00000076B508: D5207C01 01AA1601
	.long 0xd7006a02                                           // 00000076B510: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 00000076B514: 02000104
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 00000076B518: D5207C03 01AA0A01
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B520: BF870094
	.long 0xd7006a06                                           // 00000076B524: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000076B528: 02000100
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 00000076B52C: D5207C07 01AA0201
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B534: BF870094
	.long 0xd7006a08                                           // 00000076B538: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 00000076B53C: 02000102
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 00000076B540: D5207C09 01AA0601
	s_clause 0x4                                               // 00000076B548: BF850004
	global_store_b32 v[4:5], v19, off                          // 00000076B54C: DC6A0000 007C1304
	global_store_b32 v[0:1], v18, off                          // 00000076B554: DC6A0000 007C1200
	global_store_b32 v[2:3], v13, off                          // 00000076B55C: DC6A0000 007C0D02
	global_store_b32 v[6:7], v14, off                          // 00000076B564: DC6A0000 007C0E06
	global_store_b32 v[8:9], v15, off                          // 00000076B56C: DC6A0000 007C0F08
	s_endpgm                                                   // 00000076B574: BFB00000
		...

