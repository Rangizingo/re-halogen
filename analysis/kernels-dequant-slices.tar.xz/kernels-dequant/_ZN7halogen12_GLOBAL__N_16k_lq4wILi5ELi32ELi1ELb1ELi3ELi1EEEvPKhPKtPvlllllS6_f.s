000000000084d900 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 00000084D900: F4100200 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000084D908: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000084D90C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 3                               // 00000084D910: 84828302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084D914: BF8701A9
	v_dual_mov_b32 v24, s3 :: v_dual_and_b32 v1, 15, v0        // 00000084D918: CA240003 1800008F
	v_and_b32_e32 v30, 31, v0                                  // 00000084D920: 363C009F
	v_and_b32_e32 v2, 60, v2                                   // 00000084D924: 360404BC
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000084D928: 300E0082
	s_delay_alu instid0(VALU_DEP_4)                            // 00000084D92C: BF870004
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000084D930: 30020282
	.long 0x7f0c3880                                           // 00000084D934: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 00000084D938: BF89FC07
	s_clause 0x1                                               // 00000084D93C: BF850001
	global_load_b32 v3, v1, s[8:9]                             // 00000084D940: DC520000 03080001
	global_load_b32 v4, v2, s[8:9]                             // 00000084D948: DC520000 04080002
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000084D950: 32020085
	s_add_u32 s24, s8, s20                                     // 00000084D954: 80181408
	s_addc_u32 s25, s9, s21                                    // 00000084D958: 82191509
	s_ashr_i32 s4, s15, 31                                     // 00000084D95C: 86049F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000084D960: BF8704A1
	v_or_b32_e32 v23, s2, v1                                   // 00000084D964: 382E0202
	s_lshr_b32 s4, s4, 27                                      // 00000084D968: 85049B04
	s_add_u32 s4, s14, s4                                      // 00000084D96C: 8004040E
	s_addc_u32 s5, s15, 0                                      // 00000084D970: 8205800F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000084D974: BF8704A1
	.long 0xd4540002                                           // 00000084D978: D4540002
	v_cndmask_b32_e32 v1, s16, v23, vcc_lo                     // 00000084D97C: 02022E10
	s_lshr_b64 s[6:7], s[4:5], 5                               // 00000084D980: 85868504
	s_cmpk_lt_i32 s6, 0x101                                    // 00000084D984: B3860101
	.long 0xd4440004                                           // 00000084D988: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 00000084D98C: 02023C06
	v_cndmask_b32_e64 v2, 0, v23, s2                           // 00000084D990: D5010002 000A2E80
	v_cndmask_b32_e64 v5, 0, s3, s2                            // 00000084D998: D5010005 00080680
	s_cselect_b32 s3, -1, 0                                    // 00000084D9A0: 980380C1
	s_cmpk_gt_i32 s6, 0x100                                    // 00000084D9A4: B2860100
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000084D9A8: BF8704B2
	.long 0xd72c0008                                           // 00000084D9AC: D72C0008
	v_cndmask_b32_e32 v1, s23, v2, vcc_lo                      // 00000084D9B0: 02020417
	v_mad_u64_u32 v[0:1], null, s22, v2, 0                     // 00000084D9B4: D6FE7C00 02020416
	s_cselect_b32 s7, -1, 0                                    // 00000084D9BC: 980780C1
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000084D9C0: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 00000084D9C4: BF8907F7
	v_bfe_u32 v9, v3, 16, 1                                    // 00000084D9C8: D6100009 02052103
	s_waitcnt vmcnt(0)                                         // 00000084D9D0: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 00000084D9D4: D610000A 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084D9DC: BF8701A2
	v_add3_u32 v3, v3, v9, 0x7fff                              // 00000084D9E0: D6550003 03FE1303 00007FFF
	.long 0xd72c0009                                           // 00000084D9EC: D72C0009
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 00000084D9F0: 02020A16
	v_add3_u32 v4, v4, v10, 0x7fff                             // 00000084D9F4: D6550004 03FE1504 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000084DA00: BF870223
	.long 0x7e0c3983                                           // 00000084DA04: 7E0C3983
	.long 0xd7000503                                           // 00000084DA08: D7000503
	v_cndmask_b32_e32 v1, s24, v0, vcc_lo                      // 00000084DA0C: 02020018
	v_add3_u32 v1, v1, v9, v8                                  // 00000084DA10: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084DA18: BF870113
	v_and_or_b32 v6, 0xffff0000, v4, v6                        // 00000084DA1C: D6570006 041A08FF FFFF0000
	v_add_co_ci_u32_e64 v4, null, s25, v1, s5                  // 00000084DA28: D5207C04 00160219
	ds_store_b32 v7, v6                                        // 00000084DA30: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 00000084DA38: BF89FC07
	s_barrier                                                  // 00000084DA3C: BFBD0000
	buffer_gl0_inv                                             // 00000084DA40: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 00000084DA48: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x394>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 00000084DA4C: CA100080 08060080
	s_and_saveexec_b32 s5, s4                                  // 00000084DA54: BE852004
	s_cbranch_execz 10                                         // 00000084DA58: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x184>
	v_lshlrev_b32_e32 v6, 1, v30                               // 00000084DA5C: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084DA60: BF870091
	.long 0xd7006a06                                           // 00000084DA64: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000084DA68: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 00000084DA6C: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 00000084DA74: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000084DA7C: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 00000084DA80: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s5                              // 00000084DA84: 8C7E057E
	v_or_b32_e32 v6, 32, v30                                   // 00000084DA88: 380C3CA0
	s_mov_b32 s4, exec_lo                                      // 00000084DA8C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084DA90: BF870001
	.long 0xd4c4007e                                           // 00000084DA94: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000084DA98: 02020C06
	s_cbranch_execz 10                                         // 00000084DA9C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1c8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000084DAA0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084DAA4: BF870091
	.long 0xd7006a08                                           // 00000084DAA8: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000084DAAC: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 00000084DAB0: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 00000084DAB8: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 00000084DAC0: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 00000084DAC4: 7E101706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000084DAC8: 8C7E047E
	v_or_b32_e32 v6, 64, v30                                   // 00000084DACC: 380C3CC0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 00000084DAD0: CA100080 0A080080
	s_mov_b32 s4, exec_lo                                      // 00000084DAD8: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084DADC: BF870002
	.long 0xd4c4007e                                           // 00000084DAE0: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000084DAE4: 02020C06
	s_cbranch_execz 10                                         // 00000084DAE8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x214>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000084DAEC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084DAF0: BF870091
	.long 0xd7006a0b                                           // 00000084DAF4: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000084DAF8: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 00000084DAFC: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 00000084DB04: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 00000084DB0C: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 00000084DB10: 7E121706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000084DB14: 8C7E047E
	v_or_b32_e32 v6, 0x60, v30                                 // 00000084DB18: 380C3CFF 00000060
	s_mov_b32 s4, exec_lo                                      // 00000084DB20: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084DB24: BF870001
	.long 0xd4c4007e                                           // 00000084DB28: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000084DB2C: 02020C06
	s_cbranch_execz 10                                         // 00000084DB30: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x25c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000084DB34: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084DB38: BF870091
	.long 0xd7006a0a                                           // 00000084DB3C: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000084DB40: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 00000084DB44: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 00000084DB4C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 00000084DB54: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 00000084DB58: 7E141706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000084DB5C: 8C7E047E
	v_or_b32_e32 v6, 0x80, v30                                 // 00000084DB60: 380C3CFF 00000080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 00000084DB68: CA100080 0C0A0080
	s_mov_b32 s4, exec_lo                                      // 00000084DB70: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084DB74: BF870002
	.long 0xd4c4007e                                           // 00000084DB78: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000084DB7C: 02020C06
	s_cbranch_execz 10                                         // 00000084DB80: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2ac>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000084DB84: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084DB88: BF870091
	.long 0xd7006a0d                                           // 00000084DB8C: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000084DB90: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 00000084DB94: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 00000084DB9C: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 00000084DBA4: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 00000084DBA8: 7E161706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000084DBAC: 8C7E047E
	v_or_b32_e32 v6, 0xa0, v30                                 // 00000084DBB0: 380C3CFF 000000A0
	s_mov_b32 s4, exec_lo                                      // 00000084DBB8: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084DBBC: BF870001
	.long 0xd4c4007e                                           // 00000084DBC0: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000084DBC4: 02020C06
	s_cbranch_execz 10                                         // 00000084DBC8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2f4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000084DBCC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084DBD0: BF870091
	.long 0xd7006a0c                                           // 00000084DBD4: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000084DBD8: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 00000084DBDC: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 00000084DBE4: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 00000084DBEC: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 00000084DBF0: 7E181706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000084DBF4: 8C7E047E
	v_or_b32_e32 v6, 0xc0, v30                                 // 00000084DBF8: 380C3CFF 000000C0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 00000084DC00: CA100080 0E0C0080
	s_mov_b32 s4, exec_lo                                      // 00000084DC08: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084DC0C: BF870002
	.long 0xd4c4007e                                           // 00000084DC10: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000084DC14: 02020C06
	s_cbranch_execz 10                                         // 00000084DC18: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x344>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000084DC1C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084DC20: BF870091
	.long 0xd7006a0f                                           // 00000084DC24: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000084DC28: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000084DC2C: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 00000084DC34: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 00000084DC3C: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 00000084DC40: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000084DC44: 8C7E047E
	v_or_b32_e32 v6, 0xe0, v30                                 // 00000084DC48: 380C3CFF 000000E0
	s_mov_b32 s4, exec_lo                                      // 00000084DC50: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084DC54: BF870001
	.long 0xd4c4007e                                           // 00000084DC58: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000084DC5C: 02020C06
	s_cbranch_execz 10                                         // 00000084DC60: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x38c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000084DC64: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084DC68: BF870091
	.long 0xd7006a0e                                           // 00000084DC6C: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000084DC70: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 00000084DC74: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 00000084DC7C: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 00000084DC84: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 00000084DC88: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000084DC8C: 8C7E047E
	s_branch 9                                                 // 00000084DC90: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_mov_b32_e32 v7, 0                                        // 00000084DC94: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084DC98: BF870001
	v_mov_b32_e32 v8, v7                                       // 00000084DC9C: 7E100307
	v_mov_b32_e32 v9, v7                                       // 00000084DCA0: 7E120307
	v_mov_b32_e32 v10, v7                                      // 00000084DCA4: 7E140307
	v_mov_b32_e32 v11, v7                                      // 00000084DCA8: 7E160307
	v_mov_b32_e32 v12, v7                                      // 00000084DCAC: 7E180307
	v_mov_b32_e32 v13, v7                                      // 00000084DCB0: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 00000084DCB4: 7E1C0307
	s_add_u32 s4, s8, s18                                      // 00000084DCB8: 80041208
	s_addc_u32 s5, s9, s19                                     // 00000084DCBC: 82051309
	s_lshr_b32 s18, s15, 31                                    // 00000084DCC0: 85129F0F
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 00000084DCC4: CA100080 13140080
	s_add_u32 s18, s14, s18                                    // 00000084DCCC: 8012120E
	s_addc_u32 s19, s15, 0                                     // 00000084DCD0: 8213800F
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v22, 0             // 00000084DCD4: CA100080 21160080
	s_ashr_i64 s[18:19], s[18:19], 1                           // 00000084DCDC: 86928112
	v_cndmask_b32_e64 v31, 0, 1, s7                            // 00000084DCE0: D501001F 001D0280
	v_mad_u64_u32 v[25:26], null, v2, s18, s[4:5]              // 00000084DCE8: D6FE7C19 00102502
	.long 0xd72c0002                                           // 00000084DCF0: D72C0002
	v_cndmask_b32_e32 v0, v2, v19, vcc_lo                      // 00000084DCF4: 02002702
	.long 0xd72c0005                                           // 00000084DCF8: D72C0005
	v_cndmask_b32_e32 v0, v5, v18, vcc_lo                      // 00000084DCFC: 02002505
	.long 0xd4440004                                           // 00000084DD00: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 00000084DD04: 02023C06
	v_mov_b32_e32 v41, 0                                       // 00000084DD08: 7E520280
	v_mov_b32_e32 v21, 0                                       // 00000084DD0C: 7E2A0280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000084DD10: BF870004
	v_add3_u32 v32, v5, v26, v2                                // 00000084DD14: D6550020 040A3505
	s_and_saveexec_b32 s5, s4                                  // 00000084DD1C: BE852004
	s_cbranch_execz 21                                         // 00000084DD20: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_dual_mov_b32 v41, 0 :: v_dual_lshlrev_b32 v2, 4, v30     // 00000084DD24: CA220080 29023C84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084DD2C: BF870091
	.long 0xd7006a05                                           // 00000084DD30: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 00000084DD34: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v32, vcc_lo               // 00000084DD38: D5207C06 01AA4080
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 00000084DD40: 916A077E
	global_load_b128 v[19:22], v[5:6], off                     // 00000084DD44: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 00000084DD4C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 1, v30                               // 00000084DD50: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084DD54: BF870091
	.long 0xd7006a02                                           // 00000084DD58: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000084DD5C: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 00000084DD60: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 00000084DD68: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000084DD70: BF8903F7
	v_cvt_f32_f16_e32 v41, v2                                  // 00000084DD74: 7E521702
	s_or_b32 exec_lo, exec_lo, s5                              // 00000084DD78: 8C7E057E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 00000084DD7C: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 00000084DD84: CA100080 24240080
	s_and_saveexec_b32 s5, s4                                  // 00000084DD8C: BE852004
	s_cbranch_execz 507                                        // 00000084DD90: BFA501FB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xc80>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 00000084DD94: CA220080 1B023C81
	.long 0xd7006a00                                           // 00000084DD9C: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 00000084DDA0: 02020014
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084DDA4: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 00000084DDA8: D5207C01 01AA0215
	v_dual_mov_b32 v39, v30 :: v_dual_lshlrev_b32 v26, 5, v30  // 00000084DDB0: CA22011E 271A3C85
	.long 0xd7006a00                                           // 00000084DDB8: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 00000084DDBC: 02020500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084DDC0: BF8701A1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000084DDC4: D5207C01 01AA0280
	v_lshl_or_b32 v38, v30, 4, 0x200                           // 00000084DDCC: D6560026 03FD091E 00000200
	.long 0xd7006a00                                           // 00000084DDD8: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000084DDDC: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084DDE0: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000084DDE4: D5207C01 01AA0209
	v_dual_mov_b32 v37, v27 :: v_dual_mov_b32 v40, v41         // 00000084DDEC: CA10011B 25280129
	.long 0xd7006a1c                                           // 00000084DDF4: D7006A1C
	v_cndmask_b32_e32 v0, v0, v192, vcc_lo                     // 00000084DDF8: 02018100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084DDFC: BF870001
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 00000084DE00: D5207C1D 01AA0280
	v_mov_b32_e32 v36, v27                                     // 00000084DE08: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 00000084DE0C: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 00000084DE10: 7E44031B
	v_mov_b32_e32 v33, v27                                     // 00000084DE14: 7E42031B
	s_mul_i32 s4, s15, 6                                       // 00000084DE18: 9604860F
	s_mul_hi_u32 s7, s14, 6                                    // 00000084DE1C: 9687860E
	s_lshl_b64 s[18:19], s[14:15], 2                           // 00000084DE20: 8492820E
	s_add_i32 s7, s7, s4                                       // 00000084DE24: 81070407
	s_mul_i32 s21, s14, 6                                      // 00000084DE28: 9615860E
	s_mov_b32 s20, 0                                           // 00000084DE2C: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 00000084DE30: 8488810E
	s_branch 437                                               // 00000084DE34: BFA001B5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xc0c>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000084DE38: 8C7E0E7E
	v_cndmask_b32_e64 v51, v41, v7, s3                         // 00000084DE3C: D5010033 000E0F29
	v_cndmask_b32_e64 v1, v8, v9, s3                           // 00000084DE44: D5010001 000E1308
	v_cndmask_b32_e64 v0, v7, v8, s3                           // 00000084DE4C: D5010000 000E1107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 00000084DE54: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s3                         // 00000084DE60: D5010006 000E1D0D
	v_cndmask_b32_e64 v5, v12, v13, s3                         // 00000084DE68: D5010005 000E1B0C
	v_cndmask_b32_e64 v4, v11, v12, s3                         // 00000084DE70: D5010004 000E190B
	v_cndmask_b32_e64 v3, v10, v11, s3                         // 00000084DE78: D5010003 000E170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000084DE80: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s3                          // 00000084DE84: D5010002 000E1509
	s_and_b32 s4, exec_lo, s4                                  // 00000084DE8C: 8B04047E
	v_add_nc_u32_e32 v38, 0x200, v38                           // 00000084DE90: 4A4C4CFF 00000200
	s_or_b32 s20, s4, s20                                      // 00000084DE98: 8C141404
	ds_load_b32 v14, v8                                        // 00000084DE9C: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 00000084DEA4: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084DEA8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084DEAC: 361010FF 000003FC
	ds_load_b32 v52, v8                                        // 00000084DEB4: D8D80000 34000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 00000084DEBC: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084DEC0: 361010FF 000003FC
	ds_load_b32 v53, v8                                        // 00000084DEC8: D8D80000 35000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 00000084DED0: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084DED4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084DED8: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 00000084DEE0: D8D80000 36000008
	v_and_b32_e32 v8, 0xff, v20                                // 00000084DEE8: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000084DEF0: 30101082
	ds_load_b32 v55, v8                                        // 00000084DEF4: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 00000084DEFC: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084DF00: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084DF04: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 00000084DF0C: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 00000084DF14: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084DF18: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 00000084DF20: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 00000084DF28: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084DF2C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084DF30: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 00000084DF38: D8D80000 3A000008
	v_and_b32_e32 v8, 0xff, v21                                // 00000084DF40: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000084DF48: 30101082
	ds_load_b32 v59, v8                                        // 00000084DF4C: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 00000084DF54: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084DF58: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084DF5C: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 00000084DF64: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 00000084DF6C: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084DF70: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 00000084DF78: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 00000084DF80: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084DF84: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084DF88: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 00000084DF90: D8D80000 3E000008
	v_and_b32_e32 v8, 0xff, v22                                // 00000084DF98: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000084DFA0: 30101082
	ds_load_b32 v63, v8                                        // 00000084DFA4: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 00000084DFAC: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084DFB0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084DFB4: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 00000084DFBC: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 00000084DFC4: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084DFC8: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 00000084DFD0: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 00000084DFD8: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000084DFDC: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084DFE0: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 00000084DFE8: D8D80000 42000008
	.long 0xd73c0008                                           // 00000084DFF0: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 00000084DFF4: 02023481
	v_add_nc_u32_e32 v26, 0x400, v26                           // 00000084DFF8: 4A3434FF 00000400
	.long 0xd7006a0c                                           // 00000084E000: D7006A0C
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 00000084E004: 0202100A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084E008: BF870001
	v_add_co_ci_u32_e64 v13, null, s11, v9, vcc_lo             // 00000084E00C: D5207C0D 01AA120B
	s_clause 0x3                                               // 00000084E014: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000084E018: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000084E020: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 00000084E028: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 00000084E030: DC5E0030 2D7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000084E038: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000084E03C: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 00000084E044: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E048: BF8700A1
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 00000084E04C: CC1A4008 1C226909
	s_waitcnt lgkmcnt(13)                                      // 00000084E054: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 00000084E058: CC1A4008 1C226B0A
	s_waitcnt lgkmcnt(12)                                      // 00000084E060: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E064: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 00000084E068: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000084E070: BF8908B7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 00000084E074: CC1A4008 1C226F13
	s_waitcnt lgkmcnt(10)                                      // 00000084E07C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E080: BF8700A1
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 00000084E084: CC1A4008 1C227114
	s_waitcnt lgkmcnt(9)                                       // 00000084E08C: BF89FC97
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 00000084E090: CC1A4008 1C227315
	s_waitcnt lgkmcnt(8)                                       // 00000084E098: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E09C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 00000084E0A0: CC1A4008 1C227516
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000084E0A8: BF890477
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 00000084E0AC: CC1A4008 1C227729
	s_waitcnt lgkmcnt(6)                                       // 00000084E0B4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E0B8: BF8700A1
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000084E0BC: CC1A4008 1C22792A
	s_waitcnt lgkmcnt(5)                                       // 00000084E0C4: BF89FC57
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000084E0C8: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(4)                                       // 00000084E0D0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E0D4: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000084E0D8: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000084E0E0: BF890037
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000084E0E4: CC1A4008 1C227F2D
	.long 0xd7006a2d                                           // 00000084E0EC: D7006A2D
	v_cndmask_b32_e32 v0, v12, v8, vcc_lo                      // 00000084E0F0: 0200110C
	s_waitcnt lgkmcnt(2)                                       // 00000084E0F4: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000084E0F8: BF8701C2
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000084E0FC: CC1A4008 1C22812E
	v_add_co_ci_u32_e64 v46, null, s9, v13, vcc_lo             // 00000084E104: D5207C2E 01AA1A09
	.long 0xd7006a31                                           // 00000084E10C: D7006A31
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 00000084E110: 0200250C
	s_waitcnt lgkmcnt(1)                                       // 00000084E114: BF89FC17
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000084E118: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v50, null, s19, v13, vcc_lo            // 00000084E120: D5207C32 01AA1A13
	.long 0xd7006a0c                                           // 00000084E128: D7006A0C
	v_cndmask_b32_e32 v0, v12, v21, vcc_lo                     // 00000084E12C: 02002B0C
	s_waitcnt lgkmcnt(0)                                       // 00000084E130: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000084E134: BF870123
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000084E138: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v13, null, s7, v13, vcc_lo             // 00000084E140: D5207C0D 01AA1A07
	v_fmac_f32_e32 v37, v51, v8                                // 00000084E148: 564A1133
	s_clause 0x3                                               // 00000084E14C: BF850003
	global_load_b128 v[8:11], v[45:46], off                    // 00000084E150: DC5E0000 087C002D
	global_load_b128 v[19:22], v[45:46], off offset:16         // 00000084E158: DC5E0010 137C002D
	global_load_b128 v[41:44], v[45:46], off offset:32         // 00000084E160: DC5E0020 297C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 00000084E168: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 00000084E170: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000084E174: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E17C: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 00000084E180: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 00000084E188: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E190: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 00000084E194: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 00000084E19C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 00000084E1A0: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E1A8: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 00000084E1AC: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 00000084E1B4: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E1BC: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 00000084E1C0: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 00000084E1C8: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 00000084E1CC: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E1D4: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000084E1D8: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000084E1E0: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E1E8: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000084E1EC: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 00000084E1F4: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000084E1F8: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E200: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000084E204: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000084E20C: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E214: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000084E218: CC1A4008 1C228530
	v_fmac_f32_e32 v36, v51, v8                                // 00000084E220: 56481133
	s_clause 0x3                                               // 00000084E224: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 00000084E228: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 00000084E230: DC5E0010 137C0031
	global_load_b128 v[41:44], v[49:50], off offset:32         // 00000084E238: DC5E0020 297C0031
	global_load_b128 v[45:48], v[49:50], off offset:48         // 00000084E240: DC5E0030 2D7C0031
	s_waitcnt vmcnt(3)                                         // 00000084E248: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000084E24C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E254: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 00000084E258: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 00000084E260: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E268: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 00000084E26C: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 00000084E274: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 00000084E278: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E280: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 00000084E284: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 00000084E28C: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E294: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 00000084E298: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 00000084E2A0: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 00000084E2A4: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E2AC: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000084E2B0: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000084E2B8: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E2C0: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000084E2C4: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 00000084E2CC: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000084E2D0: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E2D8: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000084E2DC: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000084E2E4: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E2EC: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000084E2F0: CC1A4008 1C228530
	v_fmac_f32_e32 v35, v51, v8                                // 00000084E2F8: 56461133
	s_clause 0x3                                               // 00000084E2FC: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000084E300: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000084E308: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 00000084E310: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 00000084E318: DC5E0030 2D7C000C
	.long 0xd7006a0c                                           // 00000084E320: D7006A0C
	v_cndmask_b32_e32 v0, v49, v18, vcc_lo                     // 00000084E324: 02002531
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E328: BF8700A1
	v_add_co_ci_u32_e64 v13, null, s19, v50, vcc_lo            // 00000084E32C: D5207C0D 01AA6413
	.long 0xd7006a1c                                           // 00000084E334: D7006A1C
	v_cndmask_b32_e32 v0, v28, v192, vcc_lo                    // 00000084E338: 0201811C
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 00000084E33C: D5207C1D 01AA3A80
	s_waitcnt vmcnt(3)                                         // 00000084E344: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000084E348: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E350: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 00000084E354: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 00000084E35C: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E364: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 00000084E368: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 00000084E370: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 00000084E374: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E37C: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 00000084E380: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 00000084E388: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E390: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 00000084E394: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 00000084E39C: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 00000084E3A0: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E3A8: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000084E3AC: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000084E3B4: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E3BC: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000084E3C0: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 00000084E3C8: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000084E3CC: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E3D4: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000084E3D8: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000084E3E0: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E3E8: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000084E3EC: CC1A4008 1C228530
	v_fmac_f32_e32 v34, v51, v8                                // 00000084E3F4: 56441133
	s_clause 0x3                                               // 00000084E3F8: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000084E3FC: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000084E404: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 00000084E40C: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 00000084E414: DC5E0030 2D7C000C
	s_waitcnt vmcnt(3)                                         // 00000084E41C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000084E420: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E428: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 00000084E42C: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 00000084E434: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E43C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 00000084E440: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 00000084E448: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 00000084E44C: CC1A4008 1C226F13
	v_mov_b32_e32 v19, v15                                     // 00000084E454: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000084E458: BF870122
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 00000084E45C: CC1A4008 1C227114
	v_mov_b32_e32 v20, v16                                     // 00000084E464: 7E280310
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 00000084E468: CC1A4008 1C227315
	v_mov_b32_e32 v21, v17                                     // 00000084E470: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000084E474: BF870132
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 00000084E478: CC1A4008 1C227516
	v_mov_b32_e32 v22, v18                                     // 00000084E480: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 00000084E484: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 00000084E488: CC1A4008 1C227729
	v_mov_b32_e32 v41, v40                                     // 00000084E490: 7E520328
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E494: BF870092
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000084E498: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000084E4A0: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E4A8: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000084E4AC: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 00000084E4B4: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000084E4B8: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E4C0: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000084E4C4: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000084E4CC: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E4D4: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000084E4D8: CC1A4008 1C228530
	v_fmac_f32_e32 v33, v51, v8                                // 00000084E4E0: 56421133
	v_mov_b32_e32 v14, v7                                      // 00000084E4E4: 7E1C0307
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 00000084E4E8: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 00000084E4F0: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 00000084E4F8: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 00000084E500: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 00000084E504: 917E147E
	s_cbranch_execz 28                                         // 00000084E508: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xc7c>
	s_waitcnt vmcnt(0)                                         // 00000084E50C: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v39, 32, v39  // 00000084E510: CA200114 10264EA0
	v_dual_mov_b32 v15, v19 :: v_dual_mov_b32 v18, v22         // 00000084E518: CA100113 0F120116
	v_mov_b32_e32 v17, v21                                     // 00000084E520: 7E220315
	s_delay_alu instid0(VALU_DEP_3)                            // 00000084E524: BF870003
	.long 0xd4430004                                           // 00000084E528: D4430004
	v_cndmask_b32_e32 v1, s6, v39, vcc_lo                      // 00000084E52C: 02024E06
	s_mov_b32 s14, exec_lo                                     // 00000084E530: BE8E007E
	.long 0xd4c4007e                                           // 00000084E534: D4C4007E
	v_cndmask_b32_e32 v1, s6, v39, vcc_lo                      // 00000084E538: 02024E06
	s_cbranch_execz 65086                                      // 00000084E53C: BFA5FE3E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x538>
	.long 0xd7006a00                                           // 00000084E540: D7006A00
	v_cndmask_b32_e32 v1, v25, v38, vcc_lo                     // 00000084E544: 02024D19
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084E548: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v32, vcc_lo               // 00000084E54C: D5207C01 01AA4080
	v_cmp_ne_u32_e32 vcc_lo, 1, v31                            // 00000084E554: 7C9A3E81
	v_mov_b32_e32 v40, v41                                     // 00000084E558: 7E500329
	global_load_b128 v[15:18], v[0:1], off                     // 00000084E55C: DC5E0000 0F7C0000
	s_cbranch_vccnz 65076                                      // 00000084E564: BFA4FE34 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x538>
	global_load_d16_b16 v0, v[28:29], off                      // 00000084E568: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 00000084E570: BF8903F7
	v_cvt_f32_f16_e32 v40, v0                                  // 00000084E574: 7E501700
	s_branch 65071                                             // 00000084E578: BFA0FE2F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x538>
	s_or_b32 exec_lo, exec_lo, s20                             // 00000084E57C: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084E580: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 00000084E584: 8C7E057E
	.long 0xd71f0000                                           // 00000084E588: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000084E58C: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 00000084E590: 3A020090
	v_xor_b32_e32 v6, 8, v0                                    // 00000084E594: 3A0C0088
	v_xor_b32_e32 v11, 4, v0                                   // 00000084E598: 3A160084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000084E59C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 00000084E5A0: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000084E5A4: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000084E5A8: 7C980CA0
	v_cndmask_b32_e32 v6, v0, v6, vcc_lo                       // 00000084E5AC: 020C0D00
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 00000084E5B0: 7C9816A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084E5B4: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 00000084E5B8: 300C0C82
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000084E5BC: 30020282
	ds_bpermute_b32 v2, v1, v37                                // 00000084E5C0: DACC0000 02002501
	s_waitcnt lgkmcnt(0)                                       // 00000084E5C8: BF89FC07
	v_add_f32_e32 v2, v37, v2                                  // 00000084E5CC: 06040525
	ds_bpermute_b32 v3, v1, v36                                // 00000084E5D0: DACC0000 03002401
	ds_bpermute_b32 v4, v1, v35                                // 00000084E5D8: DACC0000 04002301
	ds_bpermute_b32 v5, v1, v34                                // 00000084E5E0: DACC0000 05002201
	ds_bpermute_b32 v1, v1, v33                                // 00000084E5E8: DACC0000 01002101
	ds_bpermute_b32 v7, v6, v2                                 // 00000084E5F0: DACC0000 07000206
	s_waitcnt lgkmcnt(3)                                       // 00000084E5F8: BF89FC37
	v_dual_add_f32 v3, v36, v3 :: v_dual_add_f32 v4, v35, v4   // 00000084E5FC: C9080724 03040923
	s_waitcnt lgkmcnt(2)                                       // 00000084E604: BF89FC27
	v_add_f32_e32 v5, v34, v5                                  // 00000084E608: 060A0B22
	s_waitcnt lgkmcnt(0)                                       // 00000084E60C: BF89FC07
	v_dual_add_f32 v1, v33, v1 :: v_dual_add_f32 v2, v2, v7    // 00000084E610: C9080321 01020F02
	ds_bpermute_b32 v8, v6, v3                                 // 00000084E618: DACC0000 08000306
	ds_bpermute_b32 v9, v6, v4                                 // 00000084E620: DACC0000 09000406
	ds_bpermute_b32 v10, v6, v5                                // 00000084E628: DACC0000 0A000506
	ds_bpermute_b32 v6, v6, v1                                 // 00000084E630: DACC0000 06000106
	v_cndmask_b32_e32 v11, v0, v11, vcc_lo                     // 00000084E638: 02161700
	s_waitcnt lgkmcnt(2)                                       // 00000084E63C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084E640: BF870001
	v_dual_add_f32 v4, v4, v9 :: v_dual_lshlrev_b32 v11, 2, v11// 00000084E644: C9221304 040A1682
	s_waitcnt lgkmcnt(1)                                       // 00000084E64C: BF89FC17
	v_add_f32_e32 v5, v5, v10                                  // 00000084E650: 060A1505
	s_waitcnt lgkmcnt(0)                                       // 00000084E654: BF89FC07
	v_add_f32_e32 v1, v1, v6                                   // 00000084E658: 06020D01
	ds_bpermute_b32 v6, v11, v2                                // 00000084E65C: DACC0000 0600020B
	ds_bpermute_b32 v10, v11, v1                               // 00000084E664: DACC0000 0A00010B
	v_add_f32_e32 v3, v3, v8                                   // 00000084E66C: 06061103
	ds_bpermute_b32 v8, v11, v4                                // 00000084E670: DACC0000 0800040B
	s_waitcnt lgkmcnt(2)                                       // 00000084E678: BF89FC27
	v_add_f32_e32 v2, v2, v6                                   // 00000084E67C: 06040D02
	v_xor_b32_e32 v6, 1, v0                                    // 00000084E680: 3A0C0081
	s_waitcnt lgkmcnt(0)                                       // 00000084E684: BF89FC07
	v_add_f32_e32 v4, v4, v8                                   // 00000084E688: 06081104
	ds_bpermute_b32 v9, v11, v5                                // 00000084E68C: DACC0000 0900050B
	v_add_f32_e32 v8, v1, v10                                  // 00000084E694: 06101501
	ds_bpermute_b32 v7, v11, v3                                // 00000084E698: DACC0000 0700030B
	v_xor_b32_e32 v11, 2, v0                                   // 00000084E6A0: 3A160082
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000084E6A4: BF870131
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 00000084E6A8: 7C9816A0
	v_cndmask_b32_e32 v11, v0, v11, vcc_lo                     // 00000084E6AC: 02161700
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000084E6B0: 7C980CA0
	v_dual_cndmask_b32 v0, v0, v6 :: v_dual_lshlrev_b32 v11, 2, v11// 00000084E6B4: CA620D00 000A1682
	s_waitcnt lgkmcnt(1)                                       // 00000084E6BC: BF89FC17
	v_add_f32_e32 v5, v5, v9                                   // 00000084E6C0: 060A1305
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 00000084E6C4: 7C943C80
	ds_bpermute_b32 v9, v11, v4                                // 00000084E6C8: DACC0000 0900040B
	s_waitcnt lgkmcnt(1)                                       // 00000084E6D0: BF89FC17
	v_add_f32_e32 v3, v3, v7                                   // 00000084E6D4: 06060F03
	ds_bpermute_b32 v1, v11, v2                                // 00000084E6D8: DACC0000 0100020B
	ds_bpermute_b32 v10, v11, v5                               // 00000084E6E0: DACC0000 0A00050B
	v_lshlrev_b32_e32 v12, 2, v0                               // 00000084E6E8: 30180082
	s_and_b32 s2, vcc_lo, s2                                   // 00000084E6EC: 8B02026A
	s_waitcnt lgkmcnt(2)                                       // 00000084E6F0: BF89FC27
	v_add_f32_e32 v0, v4, v9                                   // 00000084E6F4: 06001304
	ds_bpermute_b32 v7, v11, v3                                // 00000084E6F8: DACC0000 0700030B
	ds_bpermute_b32 v11, v11, v8                               // 00000084E700: DACC0000 0B00080B
	s_waitcnt lgkmcnt(1)                                       // 00000084E708: BF89FC17
	v_dual_add_f32 v6, v2, v1 :: v_dual_add_f32 v7, v3, v7     // 00000084E70C: C9080302 06060F03
	s_waitcnt lgkmcnt(0)                                       // 00000084E714: BF89FC07
	v_dual_add_f32 v2, v8, v11 :: v_dual_add_f32 v1, v5, v10   // 00000084E718: C9081708 02001505
	ds_bpermute_b32 v8, v12, v6                                // 00000084E720: DACC0000 0800060C
	ds_bpermute_b32 v3, v12, v0                                // 00000084E728: DACC0000 0300000C
	ds_bpermute_b32 v9, v12, v7                                // 00000084E730: DACC0000 0900070C
	ds_bpermute_b32 v5, v12, v2                                // 00000084E738: DACC0000 0500020C
	ds_bpermute_b32 v4, v12, v1                                // 00000084E740: DACC0000 0400010C
	s_and_saveexec_b32 s3, s2                                  // 00000084E748: BE832002
	s_cbranch_execz 229                                        // 00000084E74C: BFA500E5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x11e4>
	s_load_b32 s0, s[0:1], 0x48                                // 00000084E750: F4000000 F8000048
	s_waitcnt lgkmcnt(0)                                       // 00000084E758: BF89FC07
	v_dual_add_f32 v6, v6, v8 :: v_dual_add_f32 v7, v7, v9     // 00000084E75C: C9081106 06061307
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v1, v1, v4     // 00000084E764: C9080700 00000901
	s_lshl_b64 s[4:5], s[16:17], 2                             // 00000084E76C: 84848210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000084E770: BF870192
	v_bfe_u32 v8, v6, 16, 1                                    // 00000084E774: D6100008 02052106
	v_bfe_u32 v9, v7, 16, 1                                    // 00000084E77C: D6100009 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084E784: BF8701A2
	v_add3_u32 v3, v6, v8, 0x7fff                              // 00000084E788: D6550003 03FE1106 00007FFF
	v_add_f32_e32 v2, v2, v5                                   // 00000084E794: 06040B02
	v_add3_u32 v4, v7, v9, 0x7fff                              // 00000084E798: D6550004 03FE1307 00007FFF
	v_bfe_u32 v6, v1, 16, 1                                    // 00000084E7A4: D6100006 02052101
	v_bfe_u32 v5, v0, 16, 1                                    // 00000084E7AC: D6100005 02052100
	v_and_b32_e32 v3, 0xffff0000, v3                           // 00000084E7B4: 360606FF FFFF0000
	v_bfe_u32 v7, v2, 16, 1                                    // 00000084E7BC: D6100007 02052102
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000084E7C4: 360808FF FFFF0000
	v_add3_u32 v1, v1, v6, 0x7fff                              // 00000084E7CC: D6550001 03FE0D01 00007FFF
	v_add3_u32 v0, v0, v5, 0x7fff                              // 00000084E7D8: D6550000 03FE0B00 00007FFF
	v_mul_f32_e32 v3, s0, v3                                   // 00000084E7E4: 10060600
	v_add3_u32 v2, v2, v7, 0x7fff                              // 00000084E7E8: D6550002 03FE0F02 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000084E7F4: BF870214
	v_dual_mul_f32 v4, s0, v4 :: v_dual_and_b32 v1, 0xffff0000, v1// 00000084E7F8: C8E40800 040002FF FFFF0000
	v_and_b32_e32 v0, 0xffff0000, v0                           // 00000084E804: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084E80C: BF870112
	v_dual_mul_f32 v3, 0xbfb8aa3b, v3 :: v_dual_mul_f32 v4, 0xbfb8aa3b, v4// 00000084E810: C8C606FF 030408FF BFB8AA3B
	v_dual_mul_f32 v1, s0, v1 :: v_dual_mul_f32 v0, s0, v0     // 00000084E81C: C8C60200 01000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084E824: BF8701A2
	v_exp_f32_e32 v3, v3                                       // 00000084E828: 7E064B03
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000084E82C: 360404FF FFFF0000
	v_exp_f32_e32 v4, v4                                       // 00000084E834: 7E084B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000084E838: BF870122
	v_dual_mul_f32 v6, 0xbfb8aa3b, v1 :: v_dual_mul_f32 v5, 0xbfb8aa3b, v0// 00000084E83C: C8C602FF 060400FF BFB8AA3B
	.long 0xd73c0000                                           // 00000084E848: D73C0000
	v_cndmask_b32_e32 v1, 2, v23, vcc_lo                       // 00000084E84C: 02022E82
	v_exp_f32_e32 v5, v5                                       // 00000084E850: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000084E854: BF870317
	v_dual_add_f32 v7, 1.0, v3 :: v_dual_mul_f32 v2, s0, v2    // 00000084E858: C90606F2 07020400
	v_add_f32_e32 v8, 1.0, v4                                  // 00000084E860: 061008F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000084E864: BF870193
	.long 0xd7006a03                                           // 00000084E868: D7006A03
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 00000084E86C: 0202000C
	v_div_scale_f32 v0, null, v7, v7, 1.0                      // 00000084E870: D6FC7C00 03CA0F07
	v_add_co_ci_u32_e64 v4, null, s13, v1, vcc_lo              // 00000084E878: D5207C04 01AA020D
	v_div_scale_f32 v14, vcc_lo, 1.0, v7, 1.0                  // 00000084E880: D6FC6A0E 03CA0EF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000084E888: BF870125
	v_add_f32_e32 v1, 1.0, v5                                  // 00000084E88C: 06020AF2
	v_div_scale_f32 v5, null, v8, v8, 1.0                      // 00000084E890: D6FC7C05 03CA1108
	v_div_scale_f32 v10, null, v1, v1, 1.0                     // 00000084E898: D6FC7C0A 03CA0301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000084E8A0: BF870132
	v_rcp_f32_e32 v11, v5                                      // 00000084E8A4: 7E165505
	s_waitcnt vmcnt(0)                                         // 00000084E8A8: BF8903F7
	v_div_scale_f32 v20, s1, 1.0, v1, 1.0                      // 00000084E8AC: D6FC0114 03CA02F2
	v_rcp_f32_e32 v15, v10                                     // 00000084E8B4: 7E1E550A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084E8B8: BF870096
	v_fma_f32 v21, -v5, v11, 1.0                               // 00000084E8BC: D6130015 23CA1705
	v_fmac_f32_e32 v11, v21, v11                               // 00000084E8C4: 56161715
	v_exp_f32_e32 v6, v6                                       // 00000084E8C8: 7E0C4B06
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000084E8CC: BF870135
	v_add_f32_e32 v9, 1.0, v6                                  // 00000084E8D0: 06120CF2
	v_rcp_f32_e32 v6, v0                                       // 00000084E8D4: 7E0C5500
	v_div_scale_f32 v16, s0, 1.0, v8, 1.0                      // 00000084E8D8: D6FC0010 03CA10F2
	v_div_scale_f32 v12, null, v9, v9, 1.0                     // 00000084E8E0: D6FC7C0C 03CA1309
	v_div_scale_f32 v22, s2, 1.0, v9, 1.0                      // 00000084E8E8: D6FC0216 03CA12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000084E8F0: BF870312
	v_rcp_f32_e32 v17, v12                                     // 00000084E8F4: 7E22550C
	v_fma_f32 v19, -v0, v6, 1.0                                // 00000084E8F8: D6130013 23CA0D00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084E900: BF870115
	v_fma_f32 v21, -v12, v17, 1.0                              // 00000084E904: D6130015 23CA230C
	v_fmac_f32_e32 v6, v19, v6                                 // 00000084E90C: 560C0D13
	v_fma_f32 v19, -v10, v15, 1.0                              // 00000084E910: D6130013 23CA1F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084E918: BF870113
	v_dual_mul_f32 v2, 0xbfb8aa3b, v2 :: v_dual_fmac_f32 v17, v21, v17// 00000084E91C: C8C004FF 02102315 BFB8AA3B
	v_fmac_f32_e32 v15, v19, v15                               // 00000084E928: 561E1F13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000084E92C: BF870142
	v_exp_f32_e32 v2, v2                                       // 00000084E930: 7E044B02
	v_mul_f32_e32 v25, v14, v6                                 // 00000084E934: 10320D0E
	v_mul_f32_e32 v19, v16, v11                                // 00000084E938: 10261710
	v_mul_f32_e32 v27, v22, v17                                // 00000084E93C: 10362316
	v_fma_f32 v26, -v5, v19, v16                               // 00000084E940: D613001A 24422705
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 00000084E948: BF870085
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_fmac_f32 v19, v26, v11// 00000084E94C: C90004F2 0212171A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084E954: BF870113
	v_fma_f32 v26, -v12, v27, v22                              // 00000084E958: D613001A 245A370C
	v_div_scale_f32 v13, null, v2, v2, 1.0                     // 00000084E960: D6FC7C0D 03CA0502
	v_div_scale_f32 v23, s3, 1.0, v2, 1.0                      // 00000084E968: D6FC0317 03CA04F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000084E970: BF870214
	v_fma_f32 v5, -v5, v19, v16                                // 00000084E974: D6130005 24422705
	v_fmac_f32_e32 v27, v26, v17                               // 00000084E97C: 5636231A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000084E980: BF870294
	v_rcp_f32_e32 v18, v13                                     // 00000084E984: 7E24550D
	v_fma_f32 v24, -v13, v18, 1.0                              // 00000084E988: D6130018 23CA250D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000084E990: BF8701B1
	v_fmac_f32_e32 v18, v24, v18                               // 00000084E994: 56242518
	v_mul_f32_e32 v24, v20, v15                                // 00000084E998: 10301F14
	v_fma_f32 v21, -v0, v25, v14                               // 00000084E99C: D6130015 243A3300
	v_mul_f32_e32 v28, v23, v18                                // 00000084E9A4: 10382517
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000084E9A8: BF870212
	v_fmac_f32_e32 v25, v21, v6                                // 00000084E9AC: 56320D15
	v_fma_f32 v21, -v10, v24, v20                              // 00000084E9B0: D6130015 2452310A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000084E9B8: BF870193
	v_fma_f32 v29, -v13, v28, v23                              // 00000084E9BC: D613001D 245E390D
	v_fma_f32 v0, -v0, v25, v14                                // 00000084E9C4: D6130000 243A3300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084E9CC: BF870113
	v_fmac_f32_e32 v24, v21, v15                               // 00000084E9D0: 56301F15
	v_div_fmas_f32 v0, v0, v6, v25                             // 00000084E9D4: D6370000 04660D00
	s_mov_b32 vcc_lo, s0                                       // 00000084E9DC: BEEA0000
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084E9E0: BF870002
	v_fma_f32 v6, -v10, v24, v20                               // 00000084E9E4: D6130006 2452310A
	v_div_fmas_f32 v5, v5, v11, v19                            // 00000084E9EC: D6370005 044E1705
	s_mov_b32 vcc_lo, s1                                       // 00000084E9F4: BEEA0001
	v_div_fixup_f32 v0, v0, v7, 1.0                            // 00000084E9F8: D6270000 03CA0F00
	v_fmac_f32_e32 v28, v29, v18                               // 00000084EA00: 5638251D
	v_div_fmas_f32 v7, v6, v15, v24                            // 00000084EA04: D6370007 04621F06
	v_div_fixup_f32 v5, v5, v8, 1.0                            // 00000084EA0C: D6270005 03CA1105
	s_lshl_b64 s[0:1], s[16:17], 3                             // 00000084EA14: 84808310
	v_add_f32_e32 v11, v0, v0                                  // 00000084EA18: 06160100
	v_fma_f32 v0, -v12, v27, v22                               // 00000084EA1C: D6130000 245A370C
	v_div_fixup_f32 v1, v7, v1, 1.0                            // 00000084EA24: D6270001 03CA0307
	v_add_f32_e32 v14, v5, v5                                  // 00000084EA2C: 061C0B05
	.long 0xd7006a05                                           // 00000084EA30: D7006A05
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 00000084EA34: 02000903
	v_fma_f32 v7, -v13, v28, v23                               // 00000084EA38: D6130007 245E390D
	v_add_co_ci_u32_e64 v6, null, s5, v4, vcc_lo               // 00000084EA40: D5207C06 01AA0805
	s_mov_b32 vcc_lo, s2                                       // 00000084EA48: BEEA0002
	v_add_f32_e32 v12, v1, v1                                  // 00000084EA4C: 06180301
	v_div_fmas_f32 v8, v0, v17, v27                            // 00000084EA50: D6370008 046E2300
	s_mov_b32 vcc_lo, s3                                       // 00000084EA58: BEEA0003
	v_mad_u64_u32 v[0:1], null, s16, 12, v[3:4]                // 00000084EA5C: D6FE7C00 040D1810
	v_div_fmas_f32 v7, v7, v18, v28                            // 00000084EA64: D6370007 04722507
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084EA6C: BF870113
	v_div_fixup_f32 v9, v8, v9, 1.0                            // 00000084EA70: D6270009 03CA1308
	v_div_fixup_f32 v10, v7, v2, 1.0                           // 00000084EA78: D627000A 03CA0507
	.long 0xd7006a07                                           // 00000084EA80: D7006A07
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 00000084EA84: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000084EA88: BF870221
	v_add_co_ci_u32_e64 v8, null, s1, v4, vcc_lo               // 00000084EA8C: D5207C08 01AA0801
	v_mad_u64_u32 v[1:2], null, s17, 12, v[1:2]                // 00000084EA94: D6FE7C01 04051811
	v_dual_add_f32 v13, v9, v9 :: v_dual_add_f32 v2, v10, v10  // 00000084EA9C: C9081309 0D02150A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084EAA4: BF870094
	.long 0xd7006a09                                           // 00000084EAA8: D7006A09
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 00000084EAAC: 02000107
	v_add_co_ci_u32_e64 v10, null, s1, v8, vcc_lo              // 00000084EAB0: D5207C0A 01AA1001
	s_clause 0x4                                               // 00000084EAB8: BF850004
	global_store_b32 v[3:4], v11, off                          // 00000084EABC: DC6A0000 007C0B03
	global_store_b32 v[5:6], v14, off                          // 00000084EAC4: DC6A0000 007C0E05
	global_store_b32 v[7:8], v12, off                          // 00000084EACC: DC6A0000 007C0C07
	global_store_b32 v[0:1], v13, off                          // 00000084EAD4: DC6A0000 007C0D00
	global_store_b32 v[9:10], v2, off                          // 00000084EADC: DC6A0000 007C0209
	s_endpgm                                                   // 00000084EAE4: BFB00000
		...

