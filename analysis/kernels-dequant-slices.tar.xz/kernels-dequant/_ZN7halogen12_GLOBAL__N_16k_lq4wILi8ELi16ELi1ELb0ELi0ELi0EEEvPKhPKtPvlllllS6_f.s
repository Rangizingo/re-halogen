000000000057c300 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000057C300: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v15, 15, v0         // 00000057C308: CA240080 040E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000057C310: 32020084
	s_ashr_i32 s3, s2, 31                                      // 00000057C314: 86039F02
	v_mov_b32_e32 v16, 0                                       // 00000057C318: 7E200280
	s_lshl_b64 s[0:1], s[2:3], 4                               // 00000057C31C: 84808402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000057C320: BF870009
	v_dual_mov_b32 v9, s1 :: v_dual_lshlrev_b32 v2, 2, v15     // 00000057C324: CA220001 09021E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 00000057C32C: 30060282
	v_or_b32_e32 v8, s0, v1                                    // 00000057C330: 38100200
	.long 0x7f183880                                           // 00000057C334: 7F183880
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v5, 0              // 00000057C338: CA100080 1C040080
	v_mov_b32_e32 v6, 0                                        // 00000057C340: 7E0C0280
	s_waitcnt lgkmcnt(0)                                       // 00000057C344: BF89FC07
	s_clause 0x1                                               // 00000057C348: BF850001
	global_load_b32 v7, v2, s[4:5]                             // 00000057C34C: DC520000 07040002
	global_load_b32 v3, v3, s[4:5]                             // 00000057C354: DC520000 03040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 00000057C35C: 7CA8100C
	s_add_u32 s2, s4, s14                                      // 00000057C360: 80020E04
	s_addc_u32 s3, s5, s15                                     // 00000057C364: 82030F05
	s_lshr_b32 s0, s11, 31                                     // 00000057C368: 85009F0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000057C36C: BF870009
	s_add_u32 s14, s10, s0                                     // 00000057C370: 800E000A
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 00000057C374: 02141080
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 00000057C378: D501000E 01A80280
	s_addc_u32 s15, s11, 0                                     // 00000057C380: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000057C384: 86149F0B
	s_ashr_i64 s[0:1], s[14:15], 1                             // 00000057C388: 8680810E
	s_lshr_b32 s14, s20, 27                                    // 00000057C38C: 850E9B14
	.long 0xd72c0013                                           // 00000057C390: D72C0013
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 00000057C394: 0200010E
	.long 0xd72c000e                                           // 00000057C398: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 00000057C39C: 02021C12
	s_waitcnt vmcnt(1)                                         // 00000057C3A0: BF8907F7
	v_bfe_u32 v11, v7, 16, 1                                   // 00000057C3A4: D610000B 02052107
	s_waitcnt vmcnt(0)                                         // 00000057C3AC: BF8903F7
	v_bfe_u32 v18, v3, 16, 1                                   // 00000057C3B0: D6100012 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000057C3B8: BF870112
	v_add3_u32 v7, v7, v11, 0x7fff                             // 00000057C3BC: D6550007 03FE1707 00007FFF
	v_add3_u32 v3, v3, v18, 0x7fff                             // 00000057C3C8: D6550003 03FE2503 00007FFF
	v_lshlrev_b32_e32 v18, 2, v0                               // 00000057C3D4: 30240082
	s_delay_alu instid0(VALU_DEP_3)                            // 00000057C3D8: BF870003
	.long 0x7e183987                                           // 00000057C3DC: 7E183987
	v_mov_b32_e32 v7, 0                                        // 00000057C3E0: 7E0E0280
	.long 0xd72c000d                                           // 00000057C3E4: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 00000057C3E8: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 00000057C3EC: D6FE7C01 02021412
	.long 0xd72c0011                                           // 00000057C3F4: D72C0011
	v_cndmask_b32_e32 v0, v10, v1, vcc_lo                      // 00000057C3F8: 0200030A
	v_mad_u64_u32 v[10:11], null, v10, s0, s[2:3]              // 00000057C3FC: D6FE7C0A 0008010A
	s_add_u32 s2, s10, s14                                     // 00000057C404: 80020E0A
	s_addc_u32 s3, s11, 0                                      // 00000057C408: 8203800B
	v_and_or_b32 v3, 0xffff0000, v3, v12                       // 00000057C40C: D6570003 043206FF FFFF0000
	s_lshr_b64 s[2:3], s[2:3], 5                               // 00000057C418: 85828502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000057C41C: BF870009
	.long 0xd4440000                                           // 00000057C420: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 00000057C424: 02021E02
	v_add3_u32 v0, v2, v14, v13                                // 00000057C428: D6550000 04361D02
	v_add3_u32 v17, v19, v11, v17                              // 00000057C430: D6550011 04461713
	ds_store_b32 v18, v3                                       // 00000057C438: D8340000 00000312
	s_waitcnt lgkmcnt(0)                                       // 00000057C440: BF89FC07
	s_barrier                                                  // 00000057C444: BFBD0000
	buffer_gl0_inv                                             // 00000057C448: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 00000057C450: BE832000
	s_cbranch_execz 26                                         // 00000057C454: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1c0>
	s_add_u32 s1, s4, s16                                      // 00000057C458: 80011004
	s_addc_u32 s14, s5, s17                                    // 00000057C45C: 820E1105
	v_lshlrev_b32_e32 v2, 1, v15                               // 00000057C460: 30041E81
	.long 0xd7000103                                           // 00000057C464: D7000103
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 00000057C468: 02020201
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000057C46C: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s14, v0, s1                  // 00000057C470: D5207C04 0006000E
	v_lshlrev_b32_e32 v5, 4, v15                               // 00000057C478: 300A1E84
	.long 0xd7000102                                           // 00000057C47C: D7000102
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000057C480: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000057C484: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s1                    // 00000057C488: D5207C03 00060880
	.long 0xd7000104                                           // 00000057C490: D7000104
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 00000057C494: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057C498: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s1                   // 00000057C49C: D5207C05 00062280
	s_clause 0x1                                               // 00000057C4A4: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 00000057C4A8: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 00000057C4B0: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 00000057C4B8: BF8907F7
	v_cvt_f32_f16_e32 v28, v2                                  // 00000057C4BC: 7E381702
	s_or_b32 exec_lo, exec_lo, s3                              // 00000057C4C0: 8C7E037E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 00000057C4C4: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 00000057C4CC: CA100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 00000057C4D4: CA100080 16160080
	v_mov_b32_e32 v24, 0                                       // 00000057C4DC: 7E300280
	s_and_saveexec_b32 s3, s0                                  // 00000057C4E0: BE832000
	s_cbranch_execz 657                                        // 00000057C4E4: BFA50291 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xc2c>
	s_mul_i32 s0, s11, 6                                       // 00000057C4E8: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 00000057C4EC: 9681860A
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 00000057C4F0: CA220080 0C0A1E85
	s_add_i32 s18, s1, s0                                      // 00000057C4F8: 81120001
	v_lshlrev_b32_e32 v2, 1, v15                               // 00000057C4FC: 30041E81
	.long 0xd7000001                                           // 00000057C500: D7000001
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000057C504: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000057C508: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s0                  // 00000057C50C: D5207C00 00020011
	v_mov_b32_e32 v23, v12                                     // 00000057C514: 7E2E030C
	.long 0xd7000001                                           // 00000057C518: D7000001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000057C51C: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000057C520: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s0                    // 00000057C524: D5207C00 00020080
	v_lshl_or_b32 v25, v15, 4, 0x100                           // 00000057C52C: D6560019 03FD090F 00000100
	.long 0xd7000001                                           // 00000057C538: D7000001
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000057C53C: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000057C540: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s0                   // 00000057C544: D5207C00 00020005
	v_dual_mov_b32 v26, v15 :: v_dual_mov_b32 v21, v12         // 00000057C54C: CA10010F 1A14010C
	.long 0xd700000d                                           // 00000057C554: D700000D
	v_cndmask_b32_e32 v0, v1, v160, vcc_lo                     // 00000057C558: 02014101
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057C55C: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s0                   // 00000057C560: D5207C0E 00020080
	v_mov_b32_e32 v24, v12                                     // 00000057C568: 7E30030C
	v_mov_b32_e32 v22, v12                                     // 00000057C56C: 7E2C030C
	v_mov_b32_e32 v19, v12                                     // 00000057C570: 7E26030C
	v_mov_b32_e32 v20, v12                                     // 00000057C574: 7E28030C
	v_mov_b32_e32 v18, v12                                     // 00000057C578: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 00000057C57C: 7E20030C
	v_mov_b32_e32 v27, v28                                     // 00000057C580: 7E36031C
	s_lshl_b64 s[14:15], s[10:11], 2                           // 00000057C584: 848E820A
	s_mul_i32 s17, s10, 6                                      // 00000057C588: 9611860A
	s_mov_b32 s16, 0                                           // 00000057C58C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000057C590: 8484810A
	s_branch 587                                               // 00000057C594: BFA0024B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xbc4>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000057C598: 8C7E0A7E
	v_and_b32_e32 v29, 0xff, v4                                // 00000057C59C: 363A08FF 000000FF
	s_and_b32 s0, exec_lo, s0                                  // 00000057C5A4: 8B00007E
	v_add_nc_u32_e32 v25, 0x100, v25                           // 00000057C5A8: 4A3232FF 00000100
	s_or_b32 s16, s0, s16                                      // 00000057C5B0: 8C101000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057C5B4: BF8700B2
	v_lshlrev_b32_e32 v29, 2, v29                              // 00000057C5B8: 303A3A82
	ds_load_b32 v45, v29                                       // 00000057C5BC: D8D80000 2D00001D
	v_lshrrev_b32_e32 v29, 6, v4                               // 00000057C5C4: 323A0886
	v_and_b32_e32 v29, 0x3fc, v29                              // 00000057C5C8: 363A3AFF 000003FC
	ds_load_b32 v46, v29                                       // 00000057C5D0: D8D80000 2E00001D
	v_lshrrev_b32_e32 v29, 14, v4                              // 00000057C5D8: 323A088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 00000057C5DC: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000057C5E0: BF870112
	v_and_b32_e32 v29, 0x3fc, v29                              // 00000057C5E4: 363A3AFF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000057C5EC: 360808FF 000003FC
	ds_load_b32 v47, v29                                       // 00000057C5F4: D8D80000 2F00001D
	ds_load_b32 v48, v4                                        // 00000057C5FC: D8D80000 30000004
	v_and_b32_e32 v4, 0xff, v5                                 // 00000057C604: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057C60C: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000057C610: 30080882
	ds_load_b32 v49, v4                                        // 00000057C614: D8D80000 31000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 00000057C61C: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000057C620: 360808FF 000003FC
	ds_load_b32 v50, v4                                        // 00000057C628: D8D80000 32000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 00000057C630: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057C634: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000057C638: 360808FF 000003FC
	ds_load_b32 v51, v4                                        // 00000057C640: D8D80000 33000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 00000057C648: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000057C64C: 360808FF 000003FC
	ds_load_b32 v52, v4                                        // 00000057C654: D8D80000 34000004
	v_and_b32_e32 v4, 0xff, v6                                 // 00000057C65C: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057C664: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000057C668: 30080882
	ds_load_b32 v53, v4                                        // 00000057C66C: D8D80000 35000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 00000057C674: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000057C678: 360808FF 000003FC
	ds_load_b32 v54, v4                                        // 00000057C680: D8D80000 36000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 00000057C688: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057C68C: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000057C690: 360808FF 000003FC
	ds_load_b32 v55, v4                                        // 00000057C698: D8D80000 37000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 00000057C6A0: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000057C6A4: 360808FF 000003FC
	ds_load_b32 v56, v4                                        // 00000057C6AC: D8D80000 38000004
	v_and_b32_e32 v4, 0xff, v7                                 // 00000057C6B4: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057C6BC: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000057C6C0: 30080882
	ds_load_b32 v57, v4                                        // 00000057C6C4: D8D80000 39000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 00000057C6CC: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000057C6D0: 360808FF 000003FC
	ds_load_b32 v58, v4                                        // 00000057C6D8: D8D80000 3A000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 00000057C6E0: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057C6E4: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000057C6E8: 360808FF 000003FC
	ds_load_b32 v59, v4                                        // 00000057C6F0: D8D80000 3B000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 00000057C6F8: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000057C6FC: 360808FF 000003FC
	ds_load_b32 v60, v4                                        // 00000057C704: D8D80000 3C000004
	.long 0xd73c0004                                           // 00000057C70C: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000057C710: 02021681
	v_add_nc_u32_e32 v11, 0x200, v11                           // 00000057C714: 4A1616FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057C71C: BF870092
	.long 0xd7000029                                           // 00000057C720: D7000029
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 00000057C724: 02020806
	v_add_co_ci_u32_e64 v42, null, s7, v5, s0                  // 00000057C728: D5207C2A 00020A07
	s_clause 0x3                                               // 00000057C730: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 00000057C734: DC5E0000 047C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 00000057C73C: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 00000057C744: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 00000057C74C: DC5E0030 257C0029
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000057C754: BF890CF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 00000057C758: CC1A4004 1A025B04
	s_waitcnt lgkmcnt(14)                                      // 00000057C760: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057C764: BF8700A1
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 00000057C768: CC1A4004 1C125D05
	s_waitcnt lgkmcnt(13)                                      // 00000057C770: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 00000057C774: CC1A4004 1C125F06
	s_waitcnt lgkmcnt(12)                                      // 00000057C77C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057C780: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 00000057C784: CC1A4004 1C126107
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000057C78C: BF8908B7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000057C790: CC1A4004 1C12631D
	s_waitcnt lgkmcnt(10)                                      // 00000057C798: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057C79C: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000057C7A0: CC1A4004 1C12651E
	s_waitcnt lgkmcnt(9)                                       // 00000057C7A8: BF89FC97
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000057C7AC: CC1A4004 1C12671F
	s_waitcnt lgkmcnt(8)                                       // 00000057C7B4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057C7B8: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000057C7BC: CC1A4004 1C126920
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000057C7C4: BF890477
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000057C7C8: CC1A4004 1C126B21
	s_waitcnt lgkmcnt(6)                                       // 00000057C7D0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057C7D4: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000057C7D8: CC1A4004 1C126D22
	s_waitcnt lgkmcnt(5)                                       // 00000057C7E0: BF89FC57
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000057C7E4: CC1A4004 1C126F23
	s_waitcnt lgkmcnt(4)                                       // 00000057C7EC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057C7F0: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000057C7F4: CC1A4004 1C127124
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000057C7FC: BF890037
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000057C800: CC1A4004 1C127325
	.long 0xd7000025                                           // 00000057C808: D7000025
	v_cndmask_b32_e32 v0, v41, v4, vcc_lo                      // 00000057C80C: 02000929
	s_waitcnt lgkmcnt(2)                                       // 00000057C810: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000057C814: BF8701C2
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000057C818: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v38, null, s5, v42, s0                 // 00000057C820: D5207C26 00025405
	.long 0xd700002b                                           // 00000057C828: D700002B
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 00000057C82C: 02001D29
	s_waitcnt lgkmcnt(1)                                       // 00000057C830: BF89FC17
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 00000057C834: CC1A4004 1C127727
	v_add_co_ci_u32_e64 v44, null, s15, v42, s0                // 00000057C83C: D5207C2C 0002540F
	.long 0xd7000029                                           // 00000057C844: D7000029
	v_cndmask_b32_e32 v0, v41, v17, vcc_lo                     // 00000057C848: 02002329
	s_waitcnt lgkmcnt(0)                                       // 00000057C84C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000057C850: BF870123
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 00000057C854: CC1A4004 1C127928
	v_add_co_ci_u32_e64 v42, null, s18, v42, s0                // 00000057C85C: D5207C2A 00025412
	v_fmac_f32_e32 v23, v28, v4                                // 00000057C864: 562E091C
	s_clause 0x3                                               // 00000057C868: BF850003
	global_load_b128 v[4:7], v[37:38], off                     // 00000057C86C: DC5E0000 047C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 00000057C874: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 00000057C87C: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 00000057C884: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 00000057C88C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 00000057C890: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057C898: BF870091
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 00000057C89C: CC1A4004 1C125D05
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 00000057C8A4: CC1A4004 1C125F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057C8AC: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 00000057C8B0: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 00000057C8B8: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000057C8BC: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057C8C4: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000057C8C8: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000057C8D0: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057C8D8: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000057C8DC: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 00000057C8E4: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000057C8E8: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057C8F0: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000057C8F4: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000057C8FC: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057C904: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000057C908: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 00000057C910: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000057C914: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057C91C: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000057C920: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 00000057C928: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057C930: BF870091
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 00000057C934: CC1A4004 1C127928
	v_fmac_f32_e32 v24, v28, v4                                // 00000057C93C: 5630091C
	s_clause 0x3                                               // 00000057C940: BF850003
	global_load_b128 v[4:7], v[43:44], off                     // 00000057C944: DC5E0000 047C002B
	global_load_b128 v[29:32], v[43:44], off offset:16         // 00000057C94C: DC5E0010 1D7C002B
	global_load_b128 v[33:36], v[43:44], off offset:32         // 00000057C954: DC5E0020 217C002B
	global_load_b128 v[37:40], v[43:44], off offset:48         // 00000057C95C: DC5E0030 257C002B
	.long 0xd700002b                                           // 00000057C964: D700002B
	v_cndmask_b32_e32 v0, v43, v14, vcc_lo                     // 00000057C968: 02001D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057C96C: BF8700B1
	v_add_co_ci_u32_e64 v44, null, s15, v44, s0                // 00000057C970: D5207C2C 0002580F
	s_waitcnt vmcnt(3)                                         // 00000057C978: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 00000057C97C: CC1A4004 1A025B04
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 00000057C984: CC1A4004 1C125D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057C98C: BF870091
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 00000057C990: CC1A4004 1C125F06
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 00000057C998: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 00000057C9A0: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057C9A4: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000057C9A8: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000057C9B0: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057C9B8: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000057C9BC: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000057C9C4: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 00000057C9CC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057C9D0: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000057C9D4: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000057C9DC: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057C9E4: BF870091
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000057C9E8: CC1A4004 1C126F23
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000057C9F0: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 00000057C9F8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057C9FC: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000057CA00: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000057CA08: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CA10: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 00000057CA14: CC1A4004 1C127727
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 00000057CA1C: CC1A4004 1C127928
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057CA24: BF870001
	v_fmac_f32_e32 v21, v28, v4                                // 00000057CA28: 562A091C
	s_clause 0x3                                               // 00000057CA2C: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 00000057CA30: DC5E0000 047C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 00000057CA38: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 00000057CA40: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 00000057CA48: DC5E0030 257C0029
	.long 0xd7000029                                           // 00000057CA50: D7000029
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 00000057CA54: 02001D29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057CA58: BF8700B1
	v_add_co_ci_u32_e64 v42, null, s15, v42, s0                // 00000057CA5C: D5207C2A 0002540F
	s_waitcnt vmcnt(3)                                         // 00000057CA64: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 00000057CA68: CC1A4004 1A025B04
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 00000057CA70: CC1A4004 1C125D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CA78: BF870091
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 00000057CA7C: CC1A4004 1C125F06
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 00000057CA84: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 00000057CA8C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CA90: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000057CA94: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000057CA9C: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CAA4: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000057CAA8: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000057CAB0: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 00000057CAB8: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CABC: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000057CAC0: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000057CAC8: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CAD0: BF870091
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000057CAD4: CC1A4004 1C126F23
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000057CADC: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 00000057CAE4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CAE8: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000057CAEC: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000057CAF4: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CAFC: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 00000057CB00: CC1A4004 1C127727
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 00000057CB08: CC1A4004 1C127928
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057CB10: BF870001
	v_fmac_f32_e32 v22, v28, v4                                // 00000057CB14: 562C091C
	s_clause 0x3                                               // 00000057CB18: BF850003
	global_load_b128 v[4:7], v[43:44], off                     // 00000057CB1C: DC5E0000 047C002B
	global_load_b128 v[29:32], v[43:44], off offset:16         // 00000057CB24: DC5E0010 1D7C002B
	global_load_b128 v[33:36], v[43:44], off offset:32         // 00000057CB2C: DC5E0020 217C002B
	global_load_b128 v[37:40], v[43:44], off offset:48         // 00000057CB34: DC5E0030 257C002B
	s_waitcnt vmcnt(3)                                         // 00000057CB3C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 00000057CB40: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CB48: BF870091
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 00000057CB4C: CC1A4004 1C125D05
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 00000057CB54: CC1A4004 1C125F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057CB5C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 00000057CB60: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 00000057CB68: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000057CB6C: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CB74: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000057CB78: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000057CB80: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057CB88: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000057CB8C: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 00000057CB94: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000057CB98: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CBA0: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000057CBA4: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000057CBAC: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057CBB4: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000057CBB8: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 00000057CBC0: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000057CBC4: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CBCC: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000057CBD0: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 00000057CBD8: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CBE0: BF870091
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 00000057CBE4: CC1A4004 1C127928
	v_fmac_f32_e32 v19, v28, v4                                // 00000057CBEC: 5626091C
	s_clause 0x3                                               // 00000057CBF0: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 00000057CBF4: DC5E0000 047C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 00000057CBFC: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 00000057CC04: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 00000057CC0C: DC5E0030 257C0029
	s_waitcnt vmcnt(3)                                         // 00000057CC14: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 00000057CC18: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CC20: BF870091
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 00000057CC24: CC1A4004 1C125D05
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 00000057CC2C: CC1A4004 1C125F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057CC34: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 00000057CC38: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 00000057CC40: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000057CC44: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CC4C: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000057CC50: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000057CC58: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057CC60: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000057CC64: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 00000057CC6C: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000057CC70: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CC78: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000057CC7C: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000057CC84: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057CC8C: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000057CC90: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 00000057CC98: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000057CC9C: CC1A4004 1C127325
	.long 0xd7000025                                           // 00000057CCA4: D7000025
	v_cndmask_b32_e32 v0, v43, v14, vcc_lo                     // 00000057CCA8: 02001D2B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000057CCAC: BF870122
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000057CCB0: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v38, null, s15, v44, s0                // 00000057CCB8: D5207C26 0002580F
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 00000057CCC0: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CCC8: BF870091
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 00000057CCCC: CC1A4004 1C127928
	v_fmac_f32_e32 v20, v28, v4                                // 00000057CCD4: 5628091C
	s_clause 0x3                                               // 00000057CCD8: BF850003
	global_load_b128 v[4:7], v[37:38], off                     // 00000057CCDC: DC5E0000 047C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 00000057CCE4: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 00000057CCEC: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 00000057CCF4: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 00000057CCFC: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 00000057CD00: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CD08: BF870091
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 00000057CD0C: CC1A4004 1C125D05
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 00000057CD14: CC1A4004 1C125F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057CD1C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 00000057CD20: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 00000057CD28: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000057CD2C: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CD34: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000057CD38: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000057CD40: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057CD48: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000057CD4C: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 00000057CD54: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000057CD58: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CD60: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000057CD64: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000057CD6C: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057CD74: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000057CD78: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 00000057CD80: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000057CD84: CC1A4004 1C127325
	.long 0xd7000025                                           // 00000057CD8C: D7000025
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 00000057CD90: 02001D29
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000057CD94: BF8701B2
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000057CD98: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v38, null, s15, v42, s0                // 00000057CDA0: D5207C26 0002540F
	.long 0xd700000d                                           // 00000057CDA8: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 00000057CDAC: 0201410D
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 00000057CDB0: CC1A4004 1C127727
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 00000057CDB8: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CDC0: BF870092
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 00000057CDC4: CC1A4004 1C127928
	v_fmac_f32_e32 v18, v28, v4                                // 00000057CDCC: 5624091C
	s_clause 0x3                                               // 00000057CDD0: BF850003
	global_load_b128 v[4:7], v[37:38], off                     // 00000057CDD4: DC5E0000 047C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 00000057CDDC: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 00000057CDE4: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 00000057CDEC: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 00000057CDF4: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 00000057CDF8: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000057CE00: BF870121
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 00000057CE04: CC1A4004 1C125D05
	v_mov_b32_e32 v5, v1                                       // 00000057CE0C: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 00000057CE10: CC1A4004 1C125F06
	v_mov_b32_e32 v6, v2                                       // 00000057CE18: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000057CE1C: BF870132
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 00000057CE20: CC1A4004 1C126107
	v_mov_b32_e32 v7, v3                                       // 00000057CE28: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 00000057CE2C: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000057CE30: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CE38: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000057CE3C: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000057CE44: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057CE4C: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000057CE50: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 00000057CE58: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000057CE5C: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CE64: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000057CE68: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000057CE70: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057CE78: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000057CE7C: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 00000057CE84: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000057CE88: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CE90: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000057CE94: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 00000057CE9C: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CEA4: BF870091
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 00000057CEA8: CC1A4004 1C127928
	v_fmac_f32_e32 v16, v28, v4                                // 00000057CEB0: 5620091C
	v_mov_b32_e32 v4, v0                                       // 00000057CEB4: 7E080300
	v_mov_b32_e32 v28, v27                                     // 00000057CEB8: 7E38031B
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000057CEBC: 917E107E
	s_cbranch_execz 25                                         // 00000057CEC0: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xc28>
	s_waitcnt vmcnt(0)                                         // 00000057CEC4: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v26, 16, v26    // 00000057CEC8: CA200105 011A3490
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v3, v7             // 00000057CED0: CA100104 00020107
	v_mov_b32_e32 v2, v6                                       // 00000057CED8: 7E040306
	s_delay_alu instid0(VALU_DEP_3)                            // 00000057CEDC: BF870003
	.long 0xd4430000                                           // 00000057CEE0: D4430000
	v_cndmask_b32_e32 v1, s2, v26, vcc_lo                      // 00000057CEE4: 02023402
	s_mov_b32 s10, exec_lo                                     // 00000057CEE8: BE8A007E
	.long 0xd4c4007e                                           // 00000057CEEC: D4C4007E
	v_cndmask_b32_e32 v1, s2, v26, vcc_lo                      // 00000057CEF0: 02023402
	s_cbranch_execz 64936                                      // 00000057CEF4: BFA5FDA8 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x298>
	.long 0xd7000100                                           // 00000057CEF8: D7000100
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 00000057CEFC: 0202330A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057CF00: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s1                   // 00000057CF04: D5207C01 00062280
	global_load_d16_b16 v27, v[13:14], off                     // 00000057CF0C: DC820000 1B7C000D
	global_load_b128 v[0:3], v[0:1], off                       // 00000057CF14: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 00000057CF1C: BF8907F7
	v_cvt_f32_f16_e32 v27, v27                                 // 00000057CF20: 7E36171B
	s_branch 64924                                             // 00000057CF24: BFA0FD9C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x298>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000057CF28: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057CF2C: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000057CF30: 8C7E037E
	.long 0xd71f0000                                           // 00000057CF34: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000057CF38: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 00000057CF3C: 3A020088
	v_xor_b32_e32 v11, 4, v0                                   // 00000057CF40: 3A160084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057CF44: BF870092
	.long 0xd44c0000                                           // 00000057CF48: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 00000057CF4C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 00000057CF50: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000057CF58: BF870113
	.long 0xd44c0000                                           // 00000057CF5C: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 00000057CF60: 020216A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000057CF64: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 00000057CF68: BF870002
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 00000057CF6C: D501000B 00021700
	ds_bpermute_b32 v2, v1, v24                                // 00000057CF74: DACC0000 02001801
	s_waitcnt lgkmcnt(0)                                       // 00000057CF7C: BF89FC07
	v_add_f32_e32 v2, v24, v2                                  // 00000057CF80: 06040518
	s_waitcnt vmcnt(0)                                         // 00000057CF84: BF8903F7
	ds_bpermute_b32 v4, v1, v22                                // 00000057CF88: DACC0000 04001601
	ds_bpermute_b32 v3, v1, v23                                // 00000057CF90: DACC0000 03001701
	ds_bpermute_b32 v6, v1, v20                                // 00000057CF98: DACC0000 06001401
	ds_bpermute_b32 v5, v1, v21                                // 00000057CFA0: DACC0000 05001501
	ds_bpermute_b32 v7, v1, v19                                // 00000057CFA8: DACC0000 07001301
	ds_bpermute_b32 v10, v1, v16                               // 00000057CFB0: DACC0000 0A001001
	ds_bpermute_b32 v1, v1, v18                                // 00000057CFB8: DACC0000 01001201
	s_waitcnt lgkmcnt(6)                                       // 00000057CFC0: BF89FC67
	v_dual_add_f32 v4, v22, v4 :: v_dual_lshlrev_b32 v11, 2, v11// 00000057CFC4: C9220916 040A1682
	s_waitcnt lgkmcnt(4)                                       // 00000057CFCC: BF89FC47
	v_dual_add_f32 v3, v23, v3 :: v_dual_add_f32 v6, v20, v6   // 00000057CFD0: C9080717 03060D14
	v_xor_b32_e32 v20, 2, v0                                   // 00000057CFD8: 3A280082
	s_waitcnt lgkmcnt(1)                                       // 00000057CFDC: BF89FC17
	v_dual_add_f32 v5, v21, v5 :: v_dual_add_f32 v10, v16, v10 // 00000057CFE0: C9080B15 050A1510
	ds_bpermute_b32 v14, v11, v4                               // 00000057CFE8: DACC0000 0E00040B
	s_waitcnt lgkmcnt(1)                                       // 00000057CFF0: BF89FC17
	v_add_f32_e32 v1, v18, v1                                  // 00000057CFF4: 06020312
	.long 0xd44c0000                                           // 00000057CFF8: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 00000057CFFC: 020228A0
	ds_bpermute_b32 v12, v11, v2                               // 00000057D000: DACC0000 0C00020B
	ds_bpermute_b32 v13, v11, v3                               // 00000057D008: DACC0000 0D00030B
	ds_bpermute_b32 v16, v11, v5                               // 00000057D010: DACC0000 1000050B
	ds_bpermute_b32 v17, v11, v6                               // 00000057D018: DACC0000 1100060B
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 00000057D020: D5010014 00022900
	v_add_f32_e32 v7, v19, v7                                  // 00000057D028: 060E0F13
	ds_bpermute_b32 v19, v11, v10                              // 00000057D02C: DACC0000 13000A0B
	v_lshlrev_b32_e32 v20, 2, v20                              // 00000057D034: 30282882
	ds_bpermute_b32 v18, v11, v7                               // 00000057D038: DACC0000 1200070B
	s_waitcnt lgkmcnt(6)                                       // 00000057D040: BF89FC67
	v_add_f32_e32 v4, v4, v14                                  // 00000057D044: 06081D04
	ds_bpermute_b32 v11, v11, v1                               // 00000057D048: DACC0000 0B00010B
	v_xor_b32_e32 v14, 1, v0                                   // 00000057D050: 3A1C0081
	s_waitcnt lgkmcnt(5)                                       // 00000057D054: BF89FC57
	v_dual_add_f32 v2, v2, v12 :: v_dual_add_f32 v3, v3, v13   // 00000057D058: C9081902 02021B03
	s_waitcnt lgkmcnt(3)                                       // 00000057D060: BF89FC37
	v_dual_add_f32 v5, v5, v16 :: v_dual_add_f32 v6, v6, v17   // 00000057D064: C9082105 05062306
	.long 0xd44c0000                                           // 00000057D06C: D44C0000
	v_cndmask_b32_e32 v1, 32, v14, vcc_lo                      // 00000057D070: 02021CA0
	ds_bpermute_b32 v13, v20, v4                               // 00000057D074: DACC0000 0D000414
	s_waitcnt lgkmcnt(3)                                       // 00000057D07C: BF89FC37
	v_add_f32_e32 v12, v10, v19                                // 00000057D080: 0618270A
	ds_bpermute_b32 v10, v20, v2                               // 00000057D084: DACC0000 0A000214
	ds_bpermute_b32 v17, v20, v5                               // 00000057D08C: DACC0000 11000514
	v_cndmask_b32_e64 v0, v0, v14, s0                          // 00000057D094: D5010000 00021D00
	s_waitcnt lgkmcnt(4)                                       // 00000057D09C: BF89FC47
	v_add_f32_e32 v7, v7, v18                                  // 00000057D0A0: 060E2507
	ds_bpermute_b32 v18, v20, v6                               // 00000057D0A4: DACC0000 12000614
	ds_bpermute_b32 v21, v20, v12                              // 00000057D0AC: DACC0000 15000C14
	.long 0xd44a0000                                           // 00000057D0B4: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 00000057D0B8: 02021E80
	v_lshlrev_b32_e32 v22, 2, v0                               // 00000057D0BC: 302C0082
	ds_bpermute_b32 v19, v20, v7                               // 00000057D0C0: DACC0000 13000714
	s_waitcnt lgkmcnt(6)                                       // 00000057D0C8: BF89FC67
	v_add_f32_e32 v1, v1, v11                                  // 00000057D0CC: 06021701
	ds_bpermute_b32 v11, v20, v3                               // 00000057D0D0: DACC0000 0B000314
	s_and_b32 s0, s0, vcc_lo                                   // 00000057D0D8: 8B006A00
	ds_bpermute_b32 v20, v20, v1                               // 00000057D0DC: DACC0000 14000114
	s_waitcnt lgkmcnt(6)                                       // 00000057D0E4: BF89FC67
	v_add_f32_e32 v14, v2, v10                                 // 00000057D0E8: 061C1502
	v_add_f32_e32 v10, v4, v13                                 // 00000057D0EC: 06141B04
	s_waitcnt lgkmcnt(4)                                       // 00000057D0F0: BF89FC47
	v_add_f32_e32 v4, v6, v18                                  // 00000057D0F4: 06082506
	s_waitcnt lgkmcnt(3)                                       // 00000057D0F8: BF89FC37
	v_add_f32_e32 v0, v12, v21                                 // 00000057D0FC: 06002B0C
	s_waitcnt lgkmcnt(1)                                       // 00000057D100: BF89FC17
	v_dual_add_f32 v16, v3, v11 :: v_dual_add_f32 v11, v5, v17 // 00000057D104: C9081703 100A2305
	v_add_f32_e32 v5, v7, v19                                  // 00000057D10C: 060A2707
	ds_bpermute_b32 v18, v22, v14                              // 00000057D110: DACC0000 12000E16
	s_waitcnt lgkmcnt(1)                                       // 00000057D118: BF89FC17
	v_add_f32_e32 v1, v1, v20                                  // 00000057D11C: 06022901
	ds_bpermute_b32 v17, v22, v16                              // 00000057D120: DACC0000 11001016
	ds_bpermute_b32 v13, v22, v11                              // 00000057D128: DACC0000 0D000B16
	ds_bpermute_b32 v12, v22, v10                              // 00000057D130: DACC0000 0C000A16
	ds_bpermute_b32 v6, v22, v5                                // 00000057D138: DACC0000 06000516
	ds_bpermute_b32 v7, v22, v4                                // 00000057D140: DACC0000 07000416
	ds_bpermute_b32 v2, v22, v1                                // 00000057D148: DACC0000 02000116
	ds_bpermute_b32 v3, v22, v0                                // 00000057D150: DACC0000 03000016
	s_and_saveexec_b32 s1, s0                                  // 00000057D158: BE812000
	s_cbranch_execz 120                                        // 00000057D15C: BFA50078 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1040>
	s_waitcnt lgkmcnt(6)                                       // 00000057D160: BF89FC67
	v_dual_add_f32 v14, v14, v18 :: v_dual_add_f32 v15, v16, v17// 00000057D164: C908250E 0E0E2310
	.long 0x7f203880                                           // 00000057D16C: 7F203880
	.long 0xd73c0008                                           // 00000057D170: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000057D174: 02021081
	s_lshl_b64 s[0:1], s[12:13], 1                             // 00000057D178: 8480810C
	s_delay_alu instid0(VALU_DEP_3)                            // 00000057D17C: BF870003
	.long 0x7e20398e                                           // 00000057D180: 7E20398E
	.long 0x7e22398f                                           // 00000057D184: 7E22398F
	.long 0x7f223990                                           // 00000057D188: 7F223990
	s_waitcnt lgkmcnt(5)                                       // 00000057D18C: BF89FC57
	v_add_f32_e32 v13, v11, v13                                // 00000057D190: 061A1B0B
	.long 0xd7006a08                                           // 00000057D194: D7006A08
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 00000057D198: 02021008
	v_and_b32_e32 v18, 1, v16                                  // 00000057D19C: 36242081
	s_waitcnt lgkmcnt(4)                                       // 00000057D1A0: BF89FC47
	v_dual_add_f32 v12, v10, v12 :: v_dual_and_b32 v17, 1, v17 // 00000057D1A4: C924190A 0C102281
	v_add_co_ci_u32_e64 v9, null, s9, v9, vcc_lo               // 00000057D1AC: D5207C09 01AA1209
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000057D1B4: BF870223
	v_add3_u32 v18, v14, v18, 0x7fff                           // 00000057D1B8: D6550012 03FE250E 00007FFF
	.long 0xd7006a0e                                           // 00000057D1C4: D7006A0E
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 00000057D1C8: 02000108
	v_add3_u32 v17, v15, v17, 0x7fff                           // 00000057D1CC: D6550011 03FE230F 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000057D1D8: BF870004
	v_add_co_ci_u32_e64 v15, null, s1, v9, vcc_lo              // 00000057D1DC: D5207C0F 01AA1201
	s_clause 0x1                                               // 00000057D1E4: BF850001
	global_store_d16_hi_b16 v[8:9], v17, off                   // 00000057D1E8: DC960000 007C1108
	global_store_d16_hi_b16 v[14:15], v18, off                 // 00000057D1F0: DC960000 007C120E
	.long 0x7e1c398d                                           // 00000057D1F8: 7E1C398D
	.long 0x7f1c3990                                           // 00000057D1FC: 7F1C3990
	.long 0x7e20398c                                           // 00000057D200: 7E20398C
	s_waitcnt lgkmcnt(3)                                       // 00000057D204: BF89FC37
	v_add_f32_e32 v15, v5, v6                                  // 00000057D208: 061E0D05
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000057D20C: 8480820C
	s_waitcnt lgkmcnt(2)                                       // 00000057D210: BF89FC27
	v_dual_add_f32 v7, v4, v7 :: v_dual_and_b32 v14, 1, v14    // 00000057D214: C9240F04 070E1C81
	v_mad_u64_u32 v[4:5], null, s12, 6, v[8:9]                 // 00000057D21C: D6FE7C04 04210C0C
	.long 0xd7006a0a                                           // 00000057D224: D7006A0A
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 00000057D228: 02000108
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057D22C: BF870001
	v_add_co_ci_u32_e64 v11, null, s1, v9, vcc_lo              // 00000057D230: D5207C0B 01AA1201
	v_and_b32_e32 v6, 1, v16                                   // 00000057D238: 360C2081
	v_add3_u32 v8, v13, v14, 0x7fff                            // 00000057D23C: D6550008 03FE1D0D 00007FFF
	.long 0x7e12398f                                           // 00000057D248: 7E12398F
	.long 0x7f123990                                           // 00000057D24C: 7F123990
	.long 0x7e203987                                           // 00000057D250: 7E203987
	v_add3_u32 v12, v12, v6, 0x7fff                            // 00000057D254: D655000C 03FE0D0C 00007FFF
	global_store_d16_hi_b16 v[10:11], v8, off                  // 00000057D260: DC960000 007C080A
	v_mad_u64_u32 v[5:6], null, s13, 6, v[5:6]                 // 00000057D268: D6FE7C05 04150C0D
	s_waitcnt lgkmcnt(0)                                       // 00000057D270: BF89FC07
	v_dual_add_f32 v13, v0, v3 :: v_dual_and_b32 v8, 1, v9     // 00000057D274: C9240700 0D081281
	v_dual_add_f32 v9, v1, v2 :: v_dual_and_b32 v6, 1, v16     // 00000057D27C: C9240501 09062081
	.long 0xd7006a00                                           // 00000057D284: D7006A00
	v_cndmask_b32_e32 v0, v10, v0, vcc_lo                      // 00000057D288: 0200010A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000057D28C: BF870193
	.long 0x7e20398d                                           // 00000057D290: 7E20398D
	v_add3_u32 v10, v7, v6, 0x7fff                             // 00000057D294: D655000A 03FE0D07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000057D2A0: BF870004
	.long 0x7e0c3989                                           // 00000057D2A4: 7E0C3989
	.long 0x7f0c3990                                           // 00000057D2A8: 7F0C3990
	v_add_co_ci_u32_e64 v1, null, s1, v11, vcc_lo              // 00000057D2AC: D5207C01 01AA1601
	v_add3_u32 v11, v15, v8, 0x7fff                            // 00000057D2B4: D655000B 03FE110F 00007FFF
	.long 0xd7006a02                                           // 00000057D2C0: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 00000057D2C4: 02000104
	v_and_b32_e32 v8, 1, v16                                   // 00000057D2C8: 36102081
	v_and_b32_e32 v14, 1, v6                                   // 00000057D2CC: 361C0C81
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 00000057D2D0: D5207C03 01AA0A01
	.long 0xd7006a06                                           // 00000057D2D8: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000057D2DC: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057D2E0: BF870001
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 00000057D2E4: D5207C07 01AA0201
	v_add3_u32 v13, v13, v8, 0x7fff                            // 00000057D2EC: D655000D 03FE110D 00007FFF
	.long 0xd7006a08                                           // 00000057D2F8: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 00000057D2FC: 02000102
	v_add3_u32 v14, v9, v14, 0x7fff                            // 00000057D300: D655000E 03FE1D09 00007FFF
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 00000057D30C: D5207C09 01AA0601
	s_clause 0x4                                               // 00000057D314: BF850004
	global_store_d16_hi_b16 v[4:5], v12, off                   // 00000057D318: DC960000 007C0C04
	global_store_d16_hi_b16 v[0:1], v11, off                   // 00000057D320: DC960000 007C0B00
	global_store_d16_hi_b16 v[2:3], v10, off                   // 00000057D328: DC960000 007C0A02
	global_store_d16_hi_b16 v[6:7], v14, off                   // 00000057D330: DC960000 007C0E06
	global_store_d16_hi_b16 v[8:9], v13, off                   // 00000057D338: DC960000 007C0D08
	s_endpgm                                                   // 00000057D340: BFB00000
		...

