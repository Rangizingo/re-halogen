00000000008c3f00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008C3F00: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 0000008C3F08: CA240080 1200008F
	v_lshrrev_b32_e32 v14, 2, v0                               // 0000008C3F10: 321C0082
	v_lshrrev_b32_e32 v15, 6, v0                               // 0000008C3F14: 321E0086
	v_mov_b32_e32 v5, 0                                        // 0000008C3F18: 7E0A0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008C3F1C: BF870214
	v_dual_mov_b32 v22, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 0000008C3F20: CA220080 16000282
	v_and_b32_e32 v2, 60, v14                                  // 0000008C3F28: 36041CBC
	s_ashr_i32 s3, s2, 31                                      // 0000008C3F2C: 86039F02
	v_bfe_u32 v16, v0, 5, 1                                    // 0000008C3F30: D6100010 02050B00
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000008C3F38: 84948202
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v17, 31, v0         // 0000008C3F3C: CA240080 0610009F
	.long 0x7f103880                                           // 0000008C3F44: 7F103880
	s_waitcnt lgkmcnt(0)                                       // 0000008C3F48: BF89FC07
	s_clause 0x1                                               // 0000008C3F4C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 0000008C3F50: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 0000008C3F58: DC520000 04040002
	v_or_b32_e32 v1, s20, v15                                  // 0000008C3F60: 38021E14
	v_mov_b32_e32 v2, s21                                      // 0000008C3F64: 7E040215
	s_add_u32 s2, s4, s14                                      // 0000008C3F68: 80020E04
	s_addc_u32 s3, s5, s15                                     // 0000008C3F6C: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 0000008C3F70: 850E9F0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008C3F74: BF870009
	s_add_u32 s14, s10, s14                                    // 0000008C3F78: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 0000008C3F7C: 820F800B
	s_ashr_i32 s22, s11, 31                                    // 0000008C3F80: 86169F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000008C3F84: 7CA8020C
	s_lshr_b32 s22, s22, 27                                    // 0000008C3F88: 85169B16
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000008C3F8C: 868E810E
	s_add_u32 s22, s10, s22                                    // 0000008C3F90: 8016160A
	s_addc_u32 s23, s11, 0                                     // 0000008C3F94: 8217800B
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000008C3F98: 02020280
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000008C3F9C: 85968516
	v_cndmask_b32_e64 v7, 0, s21, vcc_lo                       // 0000008C3FA0: D5010007 01A82A80
	s_add_i32 s23, s22, 1                                      // 0000008C3FA8: 81178116
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C3FAC: BF870002
	.long 0xd72c0002                                           // 0000008C3FB0: D72C0002
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 0000008C3FB4: 02020213
	s_lshr_b32 s19, s23, 31                                    // 0000008C3FB8: 85139F17
	.long 0xd72c000d                                           // 0000008C3FBC: D72C000D
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 0000008C3FC0: 02001F01
	s_add_i32 s23, s23, s19                                    // 0000008C3FC4: 81171317
	v_mad_u64_u32 v[9:10], null, v1, s14, s[2:3]               // 0000008C3FC8: D6FE7C09 00081D01
	s_ashr_i32 s15, s23, 1                                     // 0000008C3FD0: 860F8117
	s_add_u32 s2, s4, s16                                      // 0000008C3FD4: 80021004
	.long 0xd72c0013                                           // 0000008C3FD8: D72C0013
	v_cndmask_b32_e32 v1, s15, v16, vcc_lo                     // 0000008C3FDC: 0202200F
	s_addc_u32 s3, s5, s17                                     // 0000008C3FE0: 82031105
	.long 0xd72c0015                                           // 0000008C3FE4: D72C0015
	v_cndmask_b32_e32 v0, v7, v14, vcc_lo                      // 0000008C3FE8: 02001D07
	.long 0xd72c0017                                           // 0000008C3FEC: D72C0017
	v_cndmask_b32_e32 v1, s18, v7, vcc_lo                      // 0000008C3FF0: 02020E12
	v_mov_b32_e32 v7, 0                                        // 0000008C3FF4: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008C3FF8: BF870153
	v_add3_u32 v10, v21, v10, v13                              // 0000008C3FFC: D655000A 04361515
	s_waitcnt vmcnt(1)                                         // 0000008C4004: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 0000008C4008: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 0000008C4010: BF8903F7
	v_bfe_u32 v20, v4, 16, 1                                   // 0000008C4014: D6100014 02052104
	v_add3_u32 v3, v3, v11, 0x7fff                             // 0000008C401C: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v1, s[2:3]              // 0000008C4028: D6FE7C0B 000A0212
	v_add_nc_u32_e32 v1, s15, v19                              // 0000008C4030: 4A02260F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008C4034: BF870004
	v_add3_u32 v4, v4, v20, 0x7fff                             // 0000008C4038: D6550004 03FE2904 00007FFF
	v_add_nc_u32_e32 v19, v19, v17                             // 0000008C4044: 4A262313
	.long 0x7e103983                                           // 0000008C4048: 7E103983
	v_lshlrev_b32_e32 v3, 2, v0                                // 0000008C404C: 30060082
	v_min_i32_e32 v20, s22, v1                                 // 0000008C4050: 22280216
	v_add3_u32 v21, v2, v12, v23                               // 0000008C4054: D6550015 045E1902
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008C405C: BF870224
	v_and_or_b32 v1, 0xffff0000, v4, v8                        // 0000008C4060: D6570001 042208FF FFFF0000
	v_mov_b32_e32 v8, 0                                        // 0000008C406C: 7E100280
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 0000008C4070: 7C822913
	ds_store_b32 v3, v1                                        // 0000008C4074: D8340000 00000103
	s_waitcnt lgkmcnt(0)                                       // 0000008C407C: BF89FC07
	s_barrier                                                  // 0000008C4080: BFBD0000
	buffer_gl0_inv                                             // 0000008C4084: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 0000008C408C: BE83206A
	s_cbranch_execz 21                                         // 0000008C4090: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x1e8>
	v_lshlrev_b32_e32 v1, 1, v19                               // 0000008C4094: 30022681
	v_lshlrev_b32_e32 v3, 4, v19                               // 0000008C4098: 30062684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008C409C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008C40A0: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000008C40A4: 3408069F
	.long 0xd7000201                                           // 0000008C40A8: D7000201
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000008C40AC: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C40B0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s2                  // 0000008C40B4: D5207C02 000A0515
	.long 0xd7000203                                           // 0000008C40BC: D7000203
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000008C40C0: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s2                  // 0000008C40C4: D5207C04 000A090A
	s_clause 0x1                                               // 0000008C40CC: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 0000008C40D0: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 0000008C40D8: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 0000008C40E0: BF8907F7
	v_cvt_f32_f16_e32 v22, v1                                  // 0000008C40E4: 7E2C1701
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008C40E8: 8C7E037E
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 0000008C40EC: CA100080 18180080
	v_mov_b32_e32 v23, 0                                       // 0000008C40F4: 7E2E0280
	s_and_saveexec_b32 s3, vcc_lo                              // 0000008C40F8: BE83206A
	s_cbranch_execz 401                                        // 0000008C40FC: BFA50191 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x844>
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v1, 32, v19     // 0000008C4100: CA200080 180026A0
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v12, 5, v19    // 0000008C4108: CA220080 170C2685
	v_mov_b32_e32 v28, v22                                     // 0000008C4110: 7E380316
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C4114: BF870003
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v26, 4, v1     // 0000008C4118: CA220080 191A0284
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v27, 1, v1     // 0000008C4120: CA220080 121A0281
	s_mul_i32 s2, s11, 6                                       // 0000008C4128: 9602860B
	s_mul_hi_u32 s14, s10, 6                                   // 0000008C412C: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000008C4130: 8484820A
	s_add_i32 s14, s14, s2                                     // 0000008C4134: 810E020E
	s_mul_i32 s16, s10, 6                                      // 0000008C4138: 9610860A
	s_mov_b32 s15, 0                                           // 0000008C413C: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000008C4140: 848A810A
	s_branch 351                                               // 0000008C4144: BFA0015F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x7c4>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000008C4148: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 0000008C414C: 361A0AFF 000000FF
	s_and_b32 s2, exec_lo, vcc_lo                              // 0000008C4154: 8B026A7E
	v_add_nc_u32_e32 v26, 0x200, v26                           // 0000008C4158: 4A3434FF 00000200
	s_or_b32 s15, s2, s15                                      // 0000008C4160: 8C0F0F02
	v_add_nc_u32_e32 v27, 64, v27                              // 0000008C4164: 4A3636C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 0000008C4168: 301A1A82
	ds_load_b32 v43, v13                                       // 0000008C416C: D8D80000 2B00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 0000008C4174: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008C4178: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 0000008C417C: 361A1AFF 000003FC
	ds_load_b32 v44, v13                                       // 0000008C4184: D8D80000 2C00000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 0000008C418C: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 0000008C4190: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 0000008C4194: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008C419C: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C41A0: 360A0AFF 000003FC
	ds_load_b32 v45, v13                                       // 0000008C41A8: D8D80000 2D00000D
	ds_load_b32 v46, v5                                        // 0000008C41B0: D8D80000 2E000005
	v_and_b32_e32 v5, 0xff, v6                                 // 0000008C41B8: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000008C41C0: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008C41C4: 300A0A82
	ds_load_b32 v47, v5                                        // 0000008C41C8: D8D80000 2F000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 0000008C41D0: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C41D4: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C41D8: 360A0AFF 000003FC
	ds_load_b32 v48, v5                                        // 0000008C41E0: D8D80000 30000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 0000008C41E8: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C41EC: 360A0AFF 000003FC
	ds_load_b32 v49, v5                                        // 0000008C41F4: D8D80000 31000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 0000008C41FC: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C4200: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C4204: 360A0AFF 000003FC
	ds_load_b32 v50, v5                                        // 0000008C420C: D8D80000 32000005
	v_and_b32_e32 v5, 0xff, v7                                 // 0000008C4214: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008C421C: 300A0A82
	ds_load_b32 v51, v5                                        // 0000008C4220: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 0000008C4228: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C422C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C4230: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 0000008C4238: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 0000008C4240: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C4244: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 0000008C424C: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 0000008C4254: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C4258: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C425C: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 0000008C4264: D8D80000 36000005
	v_and_b32_e32 v5, 0xff, v8                                 // 0000008C426C: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008C4274: 300A0A82
	ds_load_b32 v55, v5                                        // 0000008C4278: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 0000008C4280: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C4284: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C4288: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 0000008C4290: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 0000008C4298: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C429C: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 0000008C42A4: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 0000008C42AC: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008C42B0: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C42B4: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 0000008C42BC: D8D80000 3A000005
	.long 0xd73c0005                                           // 0000008C42C4: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000008C42C8: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000008C42CC: 4A1818FF 00000400
	.long 0xd7006a29                                           // 0000008C42D4: D7006A29
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000008C42D8: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C42DC: BF870001
	v_add_co_ci_u32_e64 v42, null, s7, v6, vcc_lo              // 0000008C42E0: D5207C2A 01AA0C07
	s_clause 0x3                                               // 0000008C42E8: BF850003
	global_load_b128 v[5:8], v[41:42], off                     // 0000008C42EC: DC5E0000 057C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 0000008C42F4: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 0000008C42FC: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 0000008C4304: DC5E0030 257C0029
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000008C430C: BF890CF7
	v_dot2_f32_bf16 v5, v5, v43, 0                             // 0000008C4310: CC1A4005 1A025705
	s_waitcnt lgkmcnt(14)                                      // 0000008C4318: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C431C: BF8700A1
	v_dot2_f32_bf16 v5, v6, v44, v5                            // 0000008C4320: CC1A4005 1C165906
	s_waitcnt lgkmcnt(13)                                      // 0000008C4328: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v45, v5                            // 0000008C432C: CC1A4005 1C165B07
	s_waitcnt lgkmcnt(12)                                      // 0000008C4334: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C4338: BF8700A1
	v_dot2_f32_bf16 v5, v8, v46, v5                            // 0000008C433C: CC1A4005 1C165D08
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000008C4344: BF8908B7
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 0000008C4348: CC1A4005 1C165F1D
	s_waitcnt lgkmcnt(10)                                      // 0000008C4350: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C4354: BF8700A1
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 0000008C4358: CC1A4005 1C16611E
	s_waitcnt lgkmcnt(9)                                       // 0000008C4360: BF89FC97
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 0000008C4364: CC1A4005 1C16631F
	s_waitcnt lgkmcnt(8)                                       // 0000008C436C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C4370: BF8700A1
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 0000008C4374: CC1A4005 1C166520
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008C437C: BF890477
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 0000008C4380: CC1A4005 1C166721
	s_waitcnt lgkmcnt(6)                                       // 0000008C4388: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C438C: BF8700A1
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 0000008C4390: CC1A4005 1C166922
	s_waitcnt lgkmcnt(5)                                       // 0000008C4398: BF89FC57
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 0000008C439C: CC1A4005 1C166B23
	s_waitcnt lgkmcnt(4)                                       // 0000008C43A4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C43A8: BF8700A1
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 0000008C43AC: CC1A4005 1C166D24
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008C43B4: BF890037
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 0000008C43B8: CC1A4005 1C166F25
	.long 0xd7006a25                                           // 0000008C43C0: D7006A25
	v_cndmask_b32_e32 v0, v41, v10, vcc_lo                     // 0000008C43C4: 02001529
	s_waitcnt lgkmcnt(2)                                       // 0000008C43C8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008C43CC: BF870132
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 0000008C43D0: CC1A4005 1C167126
	v_add_co_ci_u32_e64 v38, null, s11, v42, vcc_lo            // 0000008C43D8: D5207C26 01AA540B
	s_waitcnt lgkmcnt(1)                                       // 0000008C43E0: BF89FC17
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 0000008C43E4: CC1A4005 1C167327
	s_waitcnt lgkmcnt(0)                                       // 0000008C43EC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C43F0: BF870091
	v_dot2_f32_bf16 v5, v40, v58, v5                           // 0000008C43F4: CC1A4005 1C167528
	v_fmac_f32_e32 v23, v22, v5                                // 0000008C43FC: 562E0B16
	s_clause 0x3                                               // 0000008C4400: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 0000008C4404: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000008C440C: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000008C4414: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000008C441C: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 0000008C4424: BF890FF7
	v_dot2_f32_bf16 v5, v5, v43, 0                             // 0000008C4428: CC1A4005 1A025705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C4430: BF870091
	v_dot2_f32_bf16 v5, v6, v44, v5                            // 0000008C4434: CC1A4005 1C165906
	v_dot2_f32_bf16 v5, v7, v45, v5                            // 0000008C443C: CC1A4005 1C165B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C4444: BF8700A1
	v_dot2_f32_bf16 v5, v8, v46, v5                            // 0000008C4448: CC1A4005 1C165D08
	s_waitcnt vmcnt(2)                                         // 0000008C4450: BF890BF7
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 0000008C4454: CC1A4005 1C165F1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C445C: BF870091
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 0000008C4460: CC1A4005 1C16611E
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 0000008C4468: CC1A4005 1C16631F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C4470: BF8700A1
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 0000008C4474: CC1A4005 1C166520
	s_waitcnt vmcnt(1)                                         // 0000008C447C: BF8907F7
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 0000008C4480: CC1A4005 1C166721
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C4488: BF870091
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 0000008C448C: CC1A4005 1C166922
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 0000008C4494: CC1A4005 1C166B23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C449C: BF8700A1
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 0000008C44A0: CC1A4005 1C166D24
	s_waitcnt vmcnt(0)                                         // 0000008C44A8: BF8903F7
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 0000008C44AC: CC1A4005 1C166F25
	.long 0xd7006a25                                           // 0000008C44B4: D7006A25
	v_cndmask_b32_e32 v0, v41, v4, vcc_lo                      // 0000008C44B8: 02000929
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008C44BC: BF870122
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 0000008C44C0: CC1A4005 1C167126
	v_add_co_ci_u32_e64 v38, null, s5, v42, vcc_lo             // 0000008C44C8: D5207C26 01AA5405
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 0000008C44D0: CC1A4005 1C167327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C44D8: BF870091
	v_dot2_f32_bf16 v5, v40, v58, v5                           // 0000008C44DC: CC1A4005 1C167528
	v_fmac_f32_e32 v25, v22, v5                                // 0000008C44E4: 56320B16
	s_clause 0x3                                               // 0000008C44E8: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 0000008C44EC: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000008C44F4: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000008C44FC: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000008C4504: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 0000008C450C: BF890FF7
	v_dot2_f32_bf16 v5, v5, v43, 0                             // 0000008C4510: CC1A4005 1A025705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C4518: BF870091
	v_dot2_f32_bf16 v5, v6, v44, v5                            // 0000008C451C: CC1A4005 1C165906
	v_dot2_f32_bf16 v5, v7, v45, v5                            // 0000008C4524: CC1A4005 1C165B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C452C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v46, v5                            // 0000008C4530: CC1A4005 1C165D08
	s_waitcnt vmcnt(2)                                         // 0000008C4538: BF890BF7
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 0000008C453C: CC1A4005 1C165F1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C4544: BF870091
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 0000008C4548: CC1A4005 1C16611E
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 0000008C4550: CC1A4005 1C16631F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C4558: BF8700A1
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 0000008C455C: CC1A4005 1C166520
	s_waitcnt vmcnt(1)                                         // 0000008C4564: BF8907F7
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 0000008C4568: CC1A4005 1C166721
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C4570: BF870091
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 0000008C4574: CC1A4005 1C166922
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 0000008C457C: CC1A4005 1C166B23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C4584: BF8700A1
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 0000008C4588: CC1A4005 1C166D24
	s_waitcnt vmcnt(0)                                         // 0000008C4590: BF8903F7
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 0000008C4594: CC1A4005 1C166F25
	.long 0xd7006a25                                           // 0000008C459C: D7006A25
	v_cndmask_b32_e32 v0, v41, v16, vcc_lo                     // 0000008C45A0: 02002129
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008C45A4: BF870122
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 0000008C45A8: CC1A4005 1C167126
	v_add_co_ci_u32_e64 v38, null, s14, v42, vcc_lo            // 0000008C45B0: D5207C26 01AA540E
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 0000008C45B8: CC1A4005 1C167327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C45C0: BF870091
	v_dot2_f32_bf16 v5, v40, v58, v5                           // 0000008C45C4: CC1A4005 1C167528
	v_fmac_f32_e32 v24, v22, v5                                // 0000008C45CC: 56300B16
	s_clause 0x3                                               // 0000008C45D0: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 0000008C45D4: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000008C45DC: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000008C45E4: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000008C45EC: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 0000008C45F4: BF890FF7
	v_dot2_f32_bf16 v5, v5, v43, 0                             // 0000008C45F8: CC1A4005 1A025705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008C4600: BF870121
	v_dot2_f32_bf16 v5, v6, v44, v5                            // 0000008C4604: CC1A4005 1C165906
	v_mov_b32_e32 v6, v2                                       // 0000008C460C: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v45, v5                            // 0000008C4610: CC1A4005 1C165B07
	v_mov_b32_e32 v7, v3                                       // 0000008C4618: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008C461C: BF870132
	v_dot2_f32_bf16 v5, v8, v46, v5                            // 0000008C4620: CC1A4005 1C165D08
	v_mov_b32_e32 v8, v4                                       // 0000008C4628: 7E100304
	s_waitcnt vmcnt(2)                                         // 0000008C462C: BF890BF7
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 0000008C4630: CC1A4005 1C165F1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C4638: BF870091
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 0000008C463C: CC1A4005 1C16611E
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 0000008C4644: CC1A4005 1C16631F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C464C: BF8700A1
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 0000008C4650: CC1A4005 1C166520
	s_waitcnt vmcnt(1)                                         // 0000008C4658: BF8907F7
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 0000008C465C: CC1A4005 1C166721
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C4664: BF870091
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 0000008C4668: CC1A4005 1C166922
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 0000008C4670: CC1A4005 1C166B23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C4678: BF8700A1
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 0000008C467C: CC1A4005 1C166D24
	s_waitcnt vmcnt(0)                                         // 0000008C4684: BF8903F7
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 0000008C4688: CC1A4005 1C166F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C4690: BF870091
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 0000008C4694: CC1A4005 1C167126
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 0000008C469C: CC1A4005 1C167327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C46A4: BF870091
	v_dot2_f32_bf16 v5, v40, v58, v5                           // 0000008C46A8: CC1A4005 1C167528
	v_dual_fmac_f32 v18, v22, v5 :: v_dual_mov_b32 v5, v1      // 0000008C46B0: C8100B16 12040101
	v_mov_b32_e32 v22, v28                                     // 0000008C46B8: 7E2C031C
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000008C46BC: 917E0F7E
	s_cbranch_execz 31                                         // 0000008C46C0: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x840>
	s_waitcnt vmcnt(0)                                         // 0000008C46C4: BF8903F7
	v_dual_mov_b32 v2, v6 :: v_dual_add_nc_u32 v19, 32, v19    // 0000008C46C8: CA200106 021226A0
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v4, v8             // 0000008C46D0: CA100105 01040108
	v_mov_b32_e32 v3, v7                                       // 0000008C46D8: 7E060307
	s_mov_b32 s17, exec_lo                                     // 0000008C46DC: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C46E0: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 0000008C46E4: 7C8C2913
	.long 0xd4c1007e                                           // 0000008C46E8: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 0000008C46EC: 02022913
	s_cbranch_execz 65173                                      // 0000008C46F0: BFA5FE95 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x248>
	v_ashrrev_i32_e32 v2, 31, v27                              // 0000008C46F4: 3404369F
	v_ashrrev_i32_e32 v4, 31, v26                              // 0000008C46F8: 3408349F
	.long 0xd7000201                                           // 0000008C46FC: D7000201
	v_cndmask_b32_e32 v1, v11, v27, vcc_lo                     // 0000008C4700: 0202370B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C4704: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s2                  // 0000008C4708: D5207C02 000A0515
	.long 0xd7000203                                           // 0000008C4710: D7000203
	v_cndmask_b32_e32 v1, v9, v26, vcc_lo                      // 0000008C4714: 02023509
	v_add_co_ci_u32_e64 v4, null, v10, v4, s2                  // 0000008C4718: D5207C04 000A090A
	s_clause 0x1                                               // 0000008C4720: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 0000008C4724: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000008C472C: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000008C4734: BF8907F7
	v_cvt_f32_f16_e32 v28, v13                                 // 0000008C4738: 7E38170D
	s_branch 65154                                             // 0000008C473C: BFA0FE82 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x248>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008C4740: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C4744: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008C4748: 8C7E037E
	.long 0xd71f0001                                           // 0000008C474C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008C4750: 020100C1
	s_mov_b32 s2, exec_lo                                      // 0000008C4754: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000008C4758: 3A040290
	s_waitcnt vmcnt(0)                                         // 0000008C475C: BF8903F7
	v_xor_b32_e32 v6, 8, v1                                    // 0000008C4760: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 0000008C4764: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008C4768: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000008C476C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000008C4770: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000008C4774: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C4778: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008C477C: 30040482
	ds_bpermute_b32 v5, v2, v24                                // 0000008C4780: DACC0000 05001802
	s_waitcnt lgkmcnt(0)                                       // 0000008C4788: BF89FC07
	v_add_f32_e32 v5, v24, v5                                  // 0000008C478C: 060A0B18
	ds_bpermute_b32 v3, v2, v23                                // 0000008C4790: DACC0000 03001702
	ds_bpermute_b32 v4, v2, v25                                // 0000008C4798: DACC0000 04001902
	ds_bpermute_b32 v2, v2, v18                                // 0000008C47A0: DACC0000 02001202
	s_waitcnt lgkmcnt(2)                                       // 0000008C47A8: BF89FC27
	v_dual_add_f32 v3, v23, v3 :: v_dual_cndmask_b32 v6, v1, v6// 0000008C47AC: C9120717 03060D01
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000008C47B4: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C47B8: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000008C47BC: 300C0C82
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000008C47C0: 02141501
	ds_bpermute_b32 v9, v6, v5                                 // 0000008C47C4: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 0000008C47CC: BF89FC07
	v_dual_add_f32 v5, v5, v9 :: v_dual_lshlrev_b32 v10, 2, v10// 0000008C47D0: C9221305 050A1482
	ds_bpermute_b32 v7, v6, v3                                 // 0000008C47D8: DACC0000 07000306
	s_waitcnt lgkmcnt(0)                                       // 0000008C47E0: BF89FC07
	v_dual_add_f32 v2, v18, v2 :: v_dual_add_f32 v3, v3, v7    // 0000008C47E4: C9080512 02020F03
	v_add_f32_e32 v4, v25, v4                                  // 0000008C47EC: 06080919
	ds_bpermute_b32 v8, v6, v4                                 // 0000008C47F0: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 0000008C47F8: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 0000008C4800: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 0000008C4804: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 0000008C4808: DACC0000 0600030A
	ds_bpermute_b32 v9, v10, v2                                // 0000008C4810: DACC0000 0900020A
	s_waitcnt lgkmcnt(1)                                       // 0000008C4818: BF89FC17
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v8     // 0000008C481C: C9080D03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 0000008C4824: DACC0000 0800050A
	s_waitcnt lgkmcnt(1)                                       // 0000008C482C: BF89FC17
	v_add_f32_e32 v6, v2, v9                                   // 0000008C4830: 060C1302
	ds_bpermute_b32 v7, v10, v4                                // 0000008C4834: DACC0000 0700040A
	v_xor_b32_e32 v10, 2, v1                                   // 0000008C483C: 3A140282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C4840: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000008C4844: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000008C4848: 02141501
	s_waitcnt lgkmcnt(1)                                       // 0000008C484C: BF89FC17
	v_dual_add_f32 v5, v5, v8 :: v_dual_lshlrev_b32 v10, 2, v10// 0000008C4850: C9221105 050A1482
	ds_bpermute_b32 v2, v10, v3                                // 0000008C4858: DACC0000 0200030A
	s_waitcnt lgkmcnt(1)                                       // 0000008C4860: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 0000008C4864: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 0000008C4868: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 0000008C4870: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 0000008C4878: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 0000008C4880: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C4884: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000008C4888: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 0000008C488C: 02021501
	s_waitcnt lgkmcnt(3)                                       // 0000008C4890: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 0000008C4894: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 0000008C489C: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 0000008C48A0: 06061105
	s_waitcnt lgkmcnt(0)                                       // 0000008C48A4: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 0000008C48A8: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 0000008C48B0: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 0000008C48B8: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 0000008C48C0: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 0000008C48C8: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v17                                   // 0000008C48D0: 7D942280
	s_cbranch_execz 11                                         // 0000008C48D4: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xa04>
	s_waitcnt lgkmcnt(0)                                       // 0000008C48D8: BF89FC07
	v_dual_add_f32 v6, v2, v6 :: v_dual_lshlrev_b32 v9, 4, v16 // 0000008C48DC: C9220D02 06082084
	v_dual_add_f32 v8, v5, v8 :: v_dual_add_f32 v7, v3, v7     // 0000008C48E4: C9081105 08060F03
	v_add_f32_e32 v5, v1, v4                                   // 0000008C48EC: 060A0901
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C48F0: BF870003
	v_lshl_or_b32 v1, v15, 5, v9                               // 0000008C48F4: D6560001 04250B0F
	ds_store_b128 v1, v[5:8] offset:1024                       // 0000008C48FC: DB7C0400 00000501
	s_or_b32 exec_lo, exec_lo, s2                              // 0000008C4904: 8C7E027E
	v_or_b32_e32 v1, s20, v14                                  // 0000008C4908: 38021C14
	v_mov_b32_e32 v2, s21                                      // 0000008C490C: 7E040215
	.long 0xd44c0002                                           // 0000008C4910: D44C0002
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 0000008C4914: 02020090
	s_waitcnt lgkmcnt(0)                                       // 0000008C4918: BF89FC07
	s_barrier                                                  // 0000008C491C: BFBD0000
	buffer_gl0_inv                                             // 0000008C4920: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000008C4928: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 0000008C492C: 8B026A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008C4930: BF870009
	s_and_saveexec_b32 s3, s2                                  // 0000008C4934: BE832002
	s_cbranch_execz 80                                         // 0000008C4938: BFA50050 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xb7c>
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000008C493C: 3406049F
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008C4940: F4040080 F8000040
	s_lshr_b32 s0, s13, 31                                     // 0000008C4948: 85009F0D
	v_dual_mov_b32 v10, s8 :: v_dual_and_b32 v5, 3, v0         // 0000008C494C: CA240008 0A040083
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008C4954: BF870132
	v_lshrrev_b32_e32 v3, 23, v3                               // 0000008C4958: 32060697
	s_add_u32 s0, s12, s0                                      // 0000008C495C: 8000000C
	s_addc_u32 s1, s13, 0                                      // 0000008C4960: 8201800D
	v_lshlrev_b32_e32 v0, 2, v5                                // 0000008C4964: 30000A82
	s_ashr_i64 s[0:1], s[0:1], 1                               // 0000008C4968: 86808100
	.long 0xd7006a03                                           // 0000008C496C: D7006A03
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000008C4970: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008C4974: BF870111
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000008C4978: D5207C08 01AA0480
	v_and_b32_e32 v9, 0xfffffe00, v3                           // 0000008C4980: 361206FF FFFFFE00
	v_mad_u64_u32 v[3:4], null, s0, v5, 0                      // 0000008C4988: D6FE7C03 02020A00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C4990: BF8700B1
	v_mad_u64_u32 v[4:5], null, s1, v5, v[4:5]                 // 0000008C4994: D6FE7C04 04120A01
	v_mov_b32_e32 v5, s9                                       // 0000008C499C: 7E0A0209
	v_lshl_or_b32 v0, v14, 5, v0                               // 0000008C49A0: D6560000 04010B0E
	v_add_nc_u32_e32 v0, 0x400, v0                             // 0000008C49A8: 4A0000FF 00000400
	ds_load_2addr_b32 v[6:7], v0 offset1:4                     // 0000008C49B0: D8DC0400 06000000
	.long 0xd7016a00                                           // 0000008C49B8: D7016A00
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 0000008C49BC: 02021301
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C49C0: BF8701A1
	v_sub_co_ci_u32_e64 v1, null, v2, v8, vcc_lo               // 0000008C49C4: D5217C01 01AA1102
	.long 0xd73c0002                                           // 0000008C49CC: D73C0002
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000008C49D0: 02020681
	.long 0xd700000b                                           // 0000008C49D4: D700000B
	v_cndmask_b32_e32 v1, 0xffffff00, v0, vcc_lo               // 0000008C49D8: 020200FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008C49E0: BF8701B3
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[0:1]                     // 0000008C49E4: 7CA800FF 00000100
	v_add_co_ci_u32_e64 v12, null, -1, v1, s0                  // 0000008C49EC: D5207C0C 000202C1
	s_waitcnt lgkmcnt(0)                                       // 0000008C49F4: BF89FC07
	v_dual_cndmask_b32 v5, s3, v5 :: v_dual_cndmask_b32 v0, v11, v0// 0000008C49F8: CA520A03 0500010B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008C4A00: BF870122
	v_dual_cndmask_b32 v1, v12, v1 :: v_dual_add_f32 v4, 0, v6 // 0000008C4A04: CA48030C 01040C80
	v_cndmask_b32_e32 v6, s2, v10, vcc_lo                      // 0000008C4A0C: 020C1402
	.long 0xd73c0000                                           // 0000008C4A10: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000008C4A14: 02020081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C4A18: BF870193
	v_add_f32_e32 v4, v4, v7                                   // 0000008C4A1C: 06080F04
	.long 0xd7006a02                                           // 0000008C4A20: D7006A02
	v_cndmask_b32_e32 v1, v6, v2, vcc_lo                       // 0000008C4A24: 02020506
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C4A28: BF870191
	v_add_co_ci_u32_e64 v3, null, v5, v3, vcc_lo               // 0000008C4A2C: D5207C03 01AA0705
	v_bfe_u32 v5, v4, 16, 1                                    // 0000008C4A34: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C4A3C: BF870093
	.long 0xd7006a02                                           // 0000008C4A40: D7006A02
	v_cndmask_b32_e32 v1, v2, v9, vcc_lo                       // 0000008C4A44: 02021302
	v_add_co_ci_u32_e64 v3, null, v3, v8, vcc_lo               // 0000008C4A48: D5207C03 01AA1103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C4A50: BF870193
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000008C4A54: D6550004 03FE0B04 00007FFF
	.long 0xd7006a00                                           // 0000008C4A60: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 0000008C4A64: 02020102
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C4A68: BF870001
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 0000008C4A6C: D5207C01 01AA0303
	global_store_d16_hi_b16 v[0:1], v4, off                    // 0000008C4A74: DC960000 007C0400
	s_endpgm                                                   // 0000008C4A7C: BFB00000
		...

