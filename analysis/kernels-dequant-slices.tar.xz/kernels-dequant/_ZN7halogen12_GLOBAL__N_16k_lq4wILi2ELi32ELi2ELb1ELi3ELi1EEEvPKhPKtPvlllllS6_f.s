0000000000836a00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000836A00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000836A08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000836A0C: 32040082
	s_lshl_b64 s[20:21], s[2:3], 2                             // 000000836A10: 84948202
	v_and_b32_e32 v1, 15, v0                                   // 000000836A14: 3602008F
	v_lshrrev_b32_e32 v21, 6, v0                               // 000000836A18: 322A0086
	v_bfe_u32 v22, v0, 5, 1                                    // 000000836A1C: D6100016 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 000000836A24: 360404BC
	v_and_b32_e32 v23, 31, v0                                  // 000000836A28: 362E009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000836A2C: 30020282
	.long 0x7f0a3880                                           // 000000836A30: 7F0A3880
	s_waitcnt lgkmcnt(0)                                       // 000000836A34: BF89FC07
	s_clause 0x1                                               // 000000836A38: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000836A3C: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000836A44: DC520000 04040002
	s_add_u32 s2, s4, s16                                      // 000000836A4C: 80021004
	s_addc_u32 s3, s5, s17                                     // 000000836A50: 82031105
	s_ashr_i32 s16, s11, 31                                    // 000000836A54: 86109F0B
	v_mov_b32_e32 v2, s21                                      // 000000836A58: 7E040215
	s_lshr_b32 s16, s16, 27                                    // 000000836A5C: 85109B10
	v_or_b32_e32 v1, s20, v21                                  // 000000836A60: 38022A14
	s_add_u32 s16, s10, s16                                    // 000000836A64: 8010100A
	s_addc_u32 s17, s11, 0                                     // 000000836A68: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000836A6C: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000836A70: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000836A74: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 000000836A78: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000836A7C: BF870499
	s_lshr_b32 s22, s17, 31                                    // 000000836A80: 85169F11
	s_add_i32 s17, s17, s22                                    // 000000836A84: 81111611
	v_cndmask_b32_e32 v9, 0, v1, vcc_lo                        // 000000836A88: 02120280
	s_ashr_i32 s17, s17, 1                                     // 000000836A8C: 86118111
	v_cndmask_b32_e64 v10, 0, s21, vcc_lo                      // 000000836A90: D501000A 01A82A80
	.long 0xd72c0002                                           // 000000836A98: D72C0002
	v_cndmask_b32_e32 v1, s17, v22, vcc_lo                     // 000000836A9C: 02022C11
	s_cmpk_lt_i32 s16, 0x201                                   // 000000836AA0: B3900201
	.long 0xd72c0007                                           // 000000836AA4: D72C0007
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 000000836AA8: 02021213
	v_mad_u64_u32 v[17:18], null, s18, v9, s[2:3]              // 000000836AAC: D6FE7C11 000A1212
	s_cselect_b32 s2, -1, 0                                    // 000000836AB4: 980280C1
	s_cmpk_gt_i32 s16, 0x200                                   // 000000836AB8: B2900200
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000836ABC: 30020082
	v_add_nc_u32_e32 v11, s17, v2                              // 000000836AC0: 4A160411
	v_add_nc_u32_e32 v24, v2, v23                              // 000000836AC4: 4A302F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000836AC8: BF8704A2
	v_min_i32_e32 v25, s16, v11                                // 000000836ACC: 22321610
	s_cselect_b32 s16, -1, 0                                   // 000000836AD0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 000000836AD4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000836AD8: BF870151
	.long 0xd4410003                                           // 000000836ADC: D4410003
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000836AE0: 02023318
	s_waitcnt vmcnt(1)                                         // 000000836AE4: BF8907F7
	v_bfe_u32 v6, v3, 16, 1                                    // 000000836AE8: D6100006 02052103
	s_waitcnt vmcnt(0)                                         // 000000836AF0: BF8903F7
	v_bfe_u32 v8, v4, 16, 1                                    // 000000836AF4: D6100008 02052104
	v_add3_u32 v3, v3, v6, 0x7fff                              // 000000836AFC: D6550003 03FE0D03 00007FFF
	.long 0xd72c0006                                           // 000000836B08: D72C0006
	v_cndmask_b32_e32 v1, s18, v10, vcc_lo                     // 000000836B0C: 02021412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000836B10: BF870193
	v_add3_u32 v4, v4, v8, 0x7fff                              // 000000836B14: D6550004 03FE1104 00007FFF
	.long 0x7e0a3983                                           // 000000836B20: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000836B24: BF870113
	v_add3_u32 v26, v7, v18, v6                                // 000000836B28: D655001A 041A2507
	v_and_or_b32 v2, 0xffff0000, v4, v5                        // 000000836B30: D6570002 041608FF FFFF0000
	ds_store_b32 v1, v2                                        // 000000836B3C: D8340000 00000201
	s_waitcnt lgkmcnt(0)                                       // 000000836B44: BF89FC07
	s_barrier                                                  // 000000836B48: BFBD0000
	buffer_gl0_inv                                             // 000000836B4C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000836B54: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 000000836B58: CA100080 02000080
	s_and_saveexec_b32 s17, s3                                 // 000000836B60: BE912003
	s_cbranch_execz 11                                         // 000000836B64: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v1, 1, v24                               // 000000836B68: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000836B6C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 000000836B70: 3408029F
	.long 0xd7006a03                                           // 000000836B74: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000836B78: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 000000836B7C: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 000000836B84: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 000000836B8C: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000836B90: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 000000836B94: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v24                               // 000000836B98: 4A0630A0
	s_mov_b32 s3, exec_lo                                      // 000000836B9C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000836BA0: BF870001
	.long 0xd4c1007e                                           // 000000836BA4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 000000836BA8: 02023303
	s_cbranch_execz 11                                         // 000000836BAC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v2, 1, v3                                // 000000836BB0: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000836BB4: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 000000836BB8: 3406049F
	.long 0xd7006a02                                           // 000000836BBC: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 000000836BC0: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 000000836BC4: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 000000836BCC: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000836BD4: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 000000836BD8: 7E041702
	s_or_b32 exec_lo, exec_lo, s3                              // 000000836BDC: 8C7E037E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 000000836BE0: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 000000836BE8: 7E060280
	s_mov_b32 s3, exec_lo                                      // 000000836BEC: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000836BF0: BF870002
	.long 0xd4c1007e                                           // 000000836BF4: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 000000836BF8: 02023305
	s_cbranch_execz 11                                         // 000000836BFC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v5                                // 000000836C00: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000836C04: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 000000836C08: 340C069F
	.long 0xd7006a05                                           // 000000836C0C: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 000000836C10: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 000000836C14: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 000000836C1C: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 000000836C24: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000836C28: 7E061703
	s_or_b32 exec_lo, exec_lo, s3                              // 000000836C2C: 8C7E037E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 000000836C30: 4A0A30FF 00000060
	s_mov_b32 s3, exec_lo                                      // 000000836C38: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000836C3C: BF870001
	.long 0xd4c1007e                                           // 000000836C40: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 000000836C44: 02023305
	s_cbranch_execz 11                                         // 000000836C48: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v4, 1, v5                                // 000000836C4C: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000836C50: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 000000836C54: 340A089F
	.long 0xd7006a04                                           // 000000836C58: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 000000836C5C: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 000000836C60: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 000000836C68: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000836C70: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000836C74: 7E081704
	s_or_b32 exec_lo, exec_lo, s3                              // 000000836C78: 8C7E037E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 000000836C7C: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 000000836C88: 7E0A0280
	s_mov_b32 s3, exec_lo                                      // 000000836C8C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000836C90: BF870002
	.long 0xd4c1007e                                           // 000000836C94: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 000000836C98: 02023307
	s_cbranch_execz 11                                         // 000000836C9C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v5, 1, v7                                // 000000836CA0: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000836CA4: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 000000836CA8: 34100A9F
	.long 0xd7006a07                                           // 000000836CAC: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 000000836CB0: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 000000836CB4: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 000000836CBC: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 000000836CC4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 000000836CC8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s3                              // 000000836CCC: 8C7E037E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 000000836CD0: 4A0E30FF 000000A0
	s_mov_b32 s3, exec_lo                                      // 000000836CD8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000836CDC: BF870001
	.long 0xd4c1007e                                           // 000000836CE0: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 000000836CE4: 02023307
	s_cbranch_execz 11                                         // 000000836CE8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v6, 1, v7                                // 000000836CEC: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000836CF0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000836CF4: 340E0C9F
	.long 0xd7006a06                                           // 000000836CF8: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 000000836CFC: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 000000836D00: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 000000836D08: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000836D10: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000836D14: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s3                              // 000000836D18: 8C7E037E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0xc0, v24   // 000000836D1C: CA200080 080A30FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 000000836D28: 7E0E0280
	s_mov_b32 s3, exec_lo                                      // 000000836D2C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000836D30: BF870002
	.long 0xd4c1007e                                           // 000000836D34: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 000000836D38: 0202330B
	s_cbranch_execz 11                                         // 000000836D3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v7, 1, v11                               // 000000836D40: 300E1681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000836D44: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v7                              // 000000836D48: 34180E9F
	.long 0xd7006a0b                                           // 000000836D4C: D7006A0B
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 000000836D50: 02020F11
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 000000836D54: D5207C0C 01AA191A
	global_load_d16_b16 v7, v[11:12], off                      // 000000836D5C: DC820000 077C000B
	s_waitcnt vmcnt(0)                                         // 000000836D64: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000836D68: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s3                              // 000000836D6C: 8C7E037E
	v_add_nc_u32_e32 v11, 0xe0, v24                            // 000000836D70: 4A1630FF 000000E0
	s_mov_b32 s3, exec_lo                                      // 000000836D78: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000836D7C: BF870001
	.long 0xd4c1007e                                           // 000000836D80: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 000000836D84: 0202330B
	s_cbranch_execz 11                                         // 000000836D88: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v8, 1, v11                               // 000000836D8C: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000836D90: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 000000836D94: 3418109F
	.long 0xd7006a0b                                           // 000000836D98: D7006A0B
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 000000836D9C: 02021111
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 000000836DA0: D5207C0C 01AA191A
	global_load_d16_b16 v8, v[11:12], off                      // 000000836DA8: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 000000836DB0: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 000000836DB4: 7E101708
	s_or_b32 exec_lo, exec_lo, s3                              // 000000836DB8: 8C7E037E
	s_branch 9                                                 // 000000836DBC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v1, 0                                        // 000000836DC0: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000836DC4: BF870001
	v_mov_b32_e32 v2, v1                                       // 000000836DC8: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000836DCC: 7E060301
	v_mov_b32_e32 v4, v1                                       // 000000836DD0: 7E080301
	v_mov_b32_e32 v5, v1                                       // 000000836DD4: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000836DD8: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000836DDC: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 000000836DE0: 7E100301
	s_add_u32 s4, s4, s14                                      // 000000836DE4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000836DE8: 82050F05
	s_lshr_b32 s3, s11, 31                                     // 000000836DEC: 85039F0B
	v_mov_b32_e32 v27, 0                                       // 000000836DF0: 7E360280
	s_add_u32 s14, s10, s3                                     // 000000836DF4: 800E030A
	s_addc_u32 s15, s11, 0                                     // 000000836DF8: 820F800B
	.long 0xd4410003                                           // 000000836DFC: D4410003
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000836E00: 02023318
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000836E04: 868E810E
	v_cndmask_b32_e64 v28, 0, 1, s16                           // 000000836E08: D501001C 00410280
	v_mad_u64_u32 v[18:19], null, v9, s14, s[4:5]              // 000000836E10: D6FE7C12 00101D09
	.long 0xd72c000c                                           // 000000836E18: D72C000C
	v_cndmask_b32_e32 v0, v9, v15, vcc_lo                      // 000000836E1C: 02001F09
	.long 0xd72c000d                                           // 000000836E20: D72C000D
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 000000836E24: 02001D0A
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v10, 0              // 000000836E28: CA100080 090A0080
	v_mov_b32_e32 v31, 0                                       // 000000836E30: 7E3E0280
	v_mov_b32_e32 v11, 0                                       // 000000836E34: 7E160280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000836E38: BF870004
	v_add3_u32 v29, v13, v19, v12                              // 000000836E3C: D655001D 0432270D
	v_mov_b32_e32 v12, 0                                       // 000000836E44: 7E180280
	s_and_saveexec_b32 s4, s3                                  // 000000836E48: BE842003
	s_cbranch_execz 22                                         // 000000836E4C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v9, 4, v24                               // 000000836E50: 30123084
	v_mov_b32_e32 v31, 0                                       // 000000836E54: 7E3E0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000836E58: BF8700A2
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000836E5C: 3414129F
	.long 0xd7006a09                                           // 000000836E60: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 000000836E64: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 000000836E68: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000836E70: 916A107E
	global_load_b128 v[9:12], v[9:10], off                     // 000000836E74: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 000000836E7C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v13, 1, v24                              // 000000836E80: 301A3081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000836E84: BF870091
	.long 0xd7006a0d                                           // 000000836E88: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 000000836E8C: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v26, vcc_lo              // 000000836E90: D5207C0E 01AA3480
	global_load_d16_b16 v13, v[13:14], off                     // 000000836E98: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 000000836EA0: BF8903F7
	v_cvt_f32_f16_e32 v31, v13                                 // 000000836EA4: 7E3E170D
	s_or_b32 exec_lo, exec_lo, s4                              // 000000836EA8: 8C7E047E
	v_mov_b32_e32 v30, 0                                       // 000000836EAC: 7E3C0280
	s_and_saveexec_b32 s14, s3                                 // 000000836EB0: BE8E2003
	s_cbranch_execz 290                                        // 000000836EB4: BFA50122 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x940>
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v13, 32, v24    // 000000836EB8: CA200080 1E0C30A0
	v_dual_mov_b32 v34, v31 :: v_dual_lshlrev_b32 v19, 5, v24  // 000000836EC0: CA22011F 22123085
	s_delay_alu instid0(VALU_DEP_2)                            // 000000836EC8: BF870002
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v32, 4, v13    // 000000836ECC: CA220080 1B201A84
	v_lshlrev_b32_e32 v33, 1, v13                              // 000000836ED4: 30421A81
	s_mov_b32 s15, 0                                           // 000000836ED8: BE8F0080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000836EDC: 8484810A
	s_branch 243                                               // 000000836EE0: BFA000F3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x8b0>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000836EE4: 8C7E0A7E
	v_ashrrev_i32_e32 v20, 31, v19                             // 000000836EE8: 3428269F
	v_lshrrev_b32_e32 v67, 6, v9                               // 000000836EEC: 32861286
	v_lshrrev_b32_e32 v68, 14, v9                              // 000000836EF0: 3288128E
	v_and_b32_e32 v69, 0xff, v10                               // 000000836EF4: 368A14FF 000000FF
	v_lshrrev_b32_e32 v70, 6, v10                              // 000000836EFC: 328C1486
	.long 0xd73c0023                                           // 000000836F00: D73C0023
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000836F04: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 000000836F08: 362812FF 000000FF
	v_and_b32_e32 v67, 0x3fc, v67                              // 000000836F10: 368686FF 000003FC
	v_and_b32_e32 v68, 0x3fc, v68                              // 000000836F18: 368888FF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 000000836F20: 32121296
	v_lshrrev_b32_e32 v71, 14, v10                             // 000000836F24: 328E148E
	.long 0xd7006a3b                                           // 000000836F28: D7006A3B
	v_cndmask_b32_e32 v1, s6, v35, vcc_lo                      // 000000836F2C: 02024606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000836F30: BF8701A1
	v_add_co_ci_u32_e64 v60, null, s7, v36, vcc_lo             // 000000836F34: D5207C3C 01AA4807
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000836F3C: 30282882
	.long 0xd7006a3f                                           // 000000836F40: D7006A3F
	v_cndmask_b32_e32 v0, v59, v4, vcc_lo                      // 000000836F44: 0200093B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000836F48: BF870001
	v_add_co_ci_u32_e64 v64, null, s5, v60, vcc_lo             // 000000836F4C: D5207C40 01AA7805
	ds_load_b32 v20, v20                                       // 000000836F54: D8D80000 14000014
	ds_load_b32 v67, v67                                       // 000000836F5C: D8D80000 43000043
	ds_load_b32 v68, v68                                       // 000000836F64: D8D80000 44000044
	s_clause 0x7                                               // 000000836F6C: BF850007
	global_load_b128 v[35:38], v[59:60], off                   // 000000836F70: DC5E0000 237C003B
	global_load_b128 v[39:42], v[63:64], off                   // 000000836F78: DC5E0000 277C003F
	global_load_b128 v[43:46], v[59:60], off offset:16         // 000000836F80: DC5E0010 2B7C003B
	global_load_b128 v[47:50], v[63:64], off offset:16         // 000000836F88: DC5E0010 2F7C003F
	global_load_b128 v[51:54], v[59:60], off offset:32         // 000000836F90: DC5E0020 337C003B
	global_load_b128 v[55:58], v[63:64], off offset:32         // 000000836F98: DC5E0020 377C003F
	global_load_b128 v[59:62], v[59:60], off offset:48         // 000000836FA0: DC5E0030 3B7C003B
	global_load_b128 v[63:66], v[63:64], off offset:48         // 000000836FA8: DC5E0030 3F7C003F
	v_lshrrev_b32_e32 v10, 22, v10                             // 000000836FB0: 32141496
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000836FB4: 361212FF 000003FC
	v_lshlrev_b32_e32 v69, 2, v69                              // 000000836FBC: 308A8A82
	v_and_b32_e32 v70, 0x3fc, v70                              // 000000836FC0: 368C8CFF 000003FC
	v_and_b32_e32 v71, 0x3fc, v71                              // 000000836FC8: 368E8EFF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 000000836FD0: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 000000836FD8: D8D80000 09000009
	ds_load_b32 v69, v69                                       // 000000836FE0: D8D80000 45000045
	ds_load_b32 v70, v70                                       // 000000836FE8: D8D80000 46000046
	ds_load_b32 v71, v71                                       // 000000836FF0: D8D80000 47000047
	ds_load_b32 v10, v10                                       // 000000836FF8: D8D80000 0A00000A
	v_add_nc_u32_e32 v32, 0x200, v32                           // 000000837000: 4A4040FF 00000200
	s_and_b32 s3, exec_lo, s3                                  // 000000837008: 8B03037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000083700C: BF870009
	s_or_b32 s15, s3, s15                                      // 000000837010: 8C0F0F03
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 000000837014: BF891C77
	v_dot2_f32_bf16 v35, v35, v20, 0                           // 000000837018: CC1A4023 1A022923
	s_waitcnt vmcnt(6)                                         // 000000837020: BF891BF7
	v_dot2_f32_bf16 v20, v39, v20, 0                           // 000000837024: CC1A4014 1A022927
	v_and_b32_e32 v39, 0xff, v11                               // 00000083702C: 364E16FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 000000837034: BF89FC67
	v_dot2_f32_bf16 v35, v36, v67, v35                         // 000000837038: CC1A4023 1C8E8724
	s_delay_alu instid0(VALU_DEP_3)                            // 000000837040: BF870003
	v_dot2_f32_bf16 v20, v40, v67, v20                         // 000000837044: CC1A4014 1C528728
	v_lshrrev_b32_e32 v36, 6, v11                              // 00000083704C: 32481686
	v_lshrrev_b32_e32 v40, 14, v11                             // 000000837050: 3250168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 000000837054: 32161696
	s_waitcnt lgkmcnt(5)                                       // 000000837058: BF89FC57
	v_dot2_f32_bf16 v35, v37, v68, v35                         // 00000083705C: CC1A4023 1C8E8925
	v_dot2_f32_bf16 v20, v41, v68, v20                         // 000000837064: CC1A4014 1C528929
	v_and_b32_e32 v36, 0x3fc, v36                              // 00000083706C: 364848FF 000003FC
	v_lshrrev_b32_e32 v41, 6, v12                              // 000000837074: 32521886
	v_and_b32_e32 v37, 0xff, v12                               // 000000837078: 364A18FF 000000FF
	s_waitcnt lgkmcnt(4)                                       // 000000837080: BF89FC47
	v_dot2_f32_bf16 v35, v38, v9, v35                          // 000000837084: CC1A4023 1C8E1326
	v_dot2_f32_bf16 v9, v42, v9, v20                           // 00000083708C: CC1A4009 1C52132A
	v_lshlrev_b32_e32 v20, 2, v39                              // 000000837094: 30284E82
	v_and_b32_e32 v38, 0x3fc, v40                              // 000000837098: 364C50FF 000003FC
	v_lshrrev_b32_e32 v67, 14, v12                             // 0000008370A0: 3286188E
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000008370A4: BF891437
	v_dot2_f32_bf16 v35, v43, v69, v35                         // 0000008370A8: CC1A4023 1C8E8B2B
	s_waitcnt vmcnt(4)                                         // 0000008370B0: BF8913F7
	v_dot2_f32_bf16 v9, v47, v69, v9                           // 0000008370B4: CC1A4009 1C268B2F
	ds_load_b32 v20, v20                                       // 0000008370BC: D8D80000 14000014
	ds_load_b32 v36, v36                                       // 0000008370C4: D8D80000 24000024
	ds_load_b32 v38, v38                                       // 0000008370CC: D8D80000 26000026
	s_waitcnt lgkmcnt(5)                                       // 0000008370D4: BF89FC57
	v_dot2_f32_bf16 v35, v44, v70, v35                         // 0000008370D8: CC1A4023 1C8E8D2C
	v_dot2_f32_bf16 v9, v48, v70, v9                           // 0000008370E0: CC1A4009 1C268D30
	v_lshrrev_b32_e32 v12, 22, v12                             // 0000008370E8: 32181896
	v_and_b32_e32 v39, 0x3fc, v41                              // 0000008370EC: 364E52FF 000003FC
	v_cndmask_b32_e64 v41, v7, v8, s2                          // 0000008370F4: D5010029 000A1107
	s_waitcnt lgkmcnt(4)                                       // 0000008370FC: BF89FC47
	v_dot2_f32_bf16 v35, v45, v71, v35                         // 000000837100: CC1A4023 1C8E8F2D
	v_dot2_f32_bf16 v9, v49, v71, v9                           // 000000837108: CC1A4009 1C268F31
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000837110: 361616FF 000003FC
	v_lshlrev_b32_e32 v37, 2, v37                              // 000000837118: 304A4A82
	v_and_b32_e32 v40, 0x3fc, v67                              // 00000083711C: 365086FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 000000837124: BF89FC37
	v_dot2_f32_bf16 v35, v46, v10, v35                         // 000000837128: CC1A4023 1C8E152E
	v_dot2_f32_bf16 v9, v50, v10, v9                           // 000000837130: CC1A4009 1C261532
	v_and_b32_e32 v12, 0x3fc, v12                              // 000000837138: 361818FF 000003FC
	ds_load_b32 v10, v11                                       // 000000837140: D8D80000 0A00000B
	ds_load_b32 v11, v37                                       // 000000837148: D8D80000 0B000025
	ds_load_b32 v42, v39                                       // 000000837150: D8D80000 2A000027
	ds_load_b32 v43, v40                                       // 000000837158: D8D80000 2B000028
	ds_load_b32 v44, v12                                       // 000000837160: D8D80000 2C00000C
	v_cndmask_b32_e64 v40, v6, v7, s2                          // 000000837168: D5010028 000A0F06
	v_cndmask_b32_e64 v39, v5, v6, s2                          // 000000837170: D5010027 000A0D05
	v_cndmask_b32_e64 v37, v3, v4, s2                          // 000000837178: D5010025 000A0903
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 000000837180: BF890C77
	v_dot2_f32_bf16 v12, v51, v20, v35                         // 000000837184: CC1A400C 1C8E2933
	s_waitcnt vmcnt(2)                                         // 00000083718C: BF890BF7
	v_dot2_f32_bf16 v9, v55, v20, v9                           // 000000837190: CC1A4009 1C262937
	v_cndmask_b32_e64 v20, v31, v1, s2                         // 000000837198: D5010014 000A031F
	v_cndmask_b32_e64 v35, v1, v2, s2                          // 0000008371A0: D5010023 000A0501
	v_mov_b32_e32 v31, v34                                     // 0000008371A8: 7E3E0322
	s_waitcnt lgkmcnt(6)                                       // 0000008371AC: BF89FC67
	v_dot2_f32_bf16 v12, v52, v36, v12                         // 0000008371B0: CC1A400C 1C324934
	v_dot2_f32_bf16 v9, v56, v36, v9                           // 0000008371B8: CC1A4009 1C264938
	v_cndmask_b32_e64 v36, v2, v3, s2                          // 0000008371C0: D5010024 000A0702
	s_waitcnt lgkmcnt(5)                                       // 0000008371C8: BF89FC57
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008371CC: BF870193
	v_dot2_f32_bf16 v12, v53, v38, v12                         // 0000008371D0: CC1A400C 1C324D35
	v_dot2_f32_bf16 v9, v57, v38, v9                           // 0000008371D8: CC1A4009 1C264D39
	v_cndmask_b32_e64 v38, v4, v5, s2                          // 0000008371E0: D5010026 000A0B04
	s_waitcnt lgkmcnt(4)                                       // 0000008371E8: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008371EC: BF870193
	v_dot2_f32_bf16 v12, v54, v10, v12                         // 0000008371F0: CC1A400C 1C321536
	v_dot2_f32_bf16 v9, v58, v10, v9                           // 0000008371F8: CC1A4009 1C26153A
	v_mov_b32_e32 v10, v14                                     // 000000837200: 7E14030E
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 000000837204: BF890437
	s_delay_alu instid0(VALU_DEP_3)                            // 000000837208: BF870003
	v_dot2_f32_bf16 v5, v59, v11, v12                          // 00000083720C: CC1A4005 1C32173B
	s_waitcnt vmcnt(0)                                         // 000000837214: BF8903F7
	v_dot2_f32_bf16 v6, v63, v11, v9                           // 000000837218: CC1A4006 1C26173F
	v_dual_mov_b32 v12, v16 :: v_dual_mov_b32 v11, v15         // 000000837220: CA100110 0C0A010F
	v_mov_b32_e32 v9, v13                                      // 000000837228: 7E12030D
	s_waitcnt lgkmcnt(2)                                       // 00000083722C: BF89FC27
	v_dot2_f32_bf16 v1, v60, v42, v5                           // 000000837230: CC1A4001 1C16553C
	v_dot2_f32_bf16 v2, v64, v42, v6                           // 000000837238: CC1A4002 1C1A5540
	v_dual_mov_b32 v42, v8 :: v_dual_add_nc_u32 v33, 64, v33   // 000000837240: CA200108 2A2042C0
	v_add_nc_u32_e32 v19, 0x400, v19                           // 000000837248: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 000000837250: BF89FC17
	v_dot2_f32_bf16 v1, v61, v43, v1                           // 000000837254: CC1A4001 1C06573D
	v_dot2_f32_bf16 v2, v65, v43, v2                           // 00000083725C: CC1A4002 1C0A5741
	s_waitcnt lgkmcnt(0)                                       // 000000837264: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000837268: BF870112
	v_dot2_f32_bf16 v1, v62, v44, v1                           // 00000083726C: CC1A4001 1C06593E
	v_dot2_f32_bf16 v2, v66, v44, v2                           // 000000837274: CC1A4002 1C0A5942
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083727C: BF870112
	v_fmac_f32_e32 v30, v20, v1                                // 000000837280: 563C0314
	v_fmac_f32_e32 v27, v20, v2                                // 000000837284: 56360514
	v_dual_mov_b32 v1, v35 :: v_dual_mov_b32 v2, v36           // 000000837288: CA100123 01020124
	v_dual_mov_b32 v3, v37 :: v_dual_mov_b32 v4, v38           // 000000837290: CA100125 03040126
	v_dual_mov_b32 v5, v39 :: v_dual_mov_b32 v6, v40           // 000000837298: CA100127 05060128
	v_dual_mov_b32 v7, v41 :: v_dual_mov_b32 v8, v42           // 0000008372A0: CA100129 0708012A
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000008372A8: 917E0F7E
	s_cbranch_execz 35                                         // 0000008372AC: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x93c>
	s_waitcnt vmcnt(0)                                         // 0000008372B0: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v24, 32, v24   // 0000008372B4: CA200109 0D1830A0
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 0000008372BC: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 0000008372C4: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008372C8: BF870003
	.long 0xd4460003                                           // 0000008372CC: D4460003
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000008372D0: 02023318
	s_mov_b32 s10, exec_lo                                     // 0000008372D4: BE8A007E
	.long 0xd4c1007e                                           // 0000008372D8: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000008372DC: 02023318
	s_cbranch_execz 65280                                      // 0000008372E0: BFA5FF00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4e4>
	v_ashrrev_i32_e32 v14, 31, v32                             // 0000008372E4: 341C409F
	.long 0xd7006a0d                                           // 0000008372E8: D7006A0D
	v_cndmask_b32_e32 v1, v18, v32, vcc_lo                     // 0000008372EC: 02024112
	v_mov_b32_e32 v34, v31                                     // 0000008372F0: 7E44031F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008372F4: BF870003
	v_add_co_ci_u32_e64 v14, null, v29, v14, vcc_lo            // 0000008372F8: D5207C0E 01AA1D1D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 000000837300: 7C9A3881
	global_load_b128 v[13:16], v[13:14], off                   // 000000837304: DC5E0000 0D7C000D
	s_cbranch_vccnz 65269                                      // 00000083730C: BFA4FEF5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4e4>
	v_ashrrev_i32_e32 v20, 31, v33                             // 000000837310: 3428429F
	.long 0xd7006a22                                           // 000000837314: D7006A22
	v_cndmask_b32_e32 v1, v17, v33, vcc_lo                     // 000000837318: 02024311
	s_delay_alu instid0(VALU_DEP_1)                            // 00000083731C: BF870001
	v_add_co_ci_u32_e64 v35, null, v26, v20, vcc_lo            // 000000837320: D5207C23 01AA291A
	global_load_d16_b16 v20, v[34:35], off                     // 000000837328: DC820000 147C0022
	s_waitcnt vmcnt(0)                                         // 000000837330: BF8903F7
	v_cvt_f32_f16_e32 v34, v20                                 // 000000837334: 7E441714
	s_branch 65258                                             // 000000837338: BFA0FEEA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4e4>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000083733C: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000837340: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 000000837344: 8C7E0E7E
	.long 0xd71f0001                                           // 000000837348: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000083734C: 020100C1
	s_mov_b32 s2, exec_lo                                      // 000000837350: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000837354: 3A040290
	v_xor_b32_e32 v4, 8, v1                                    // 000000837358: 3A080288
	v_xor_b32_e32 v6, 4, v1                                    // 00000083735C: 3A0C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000837360: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000837364: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000837368: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000083736C: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000837370: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000837374: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000837378: 02080901
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000083737C: 7C980CA0
	ds_bpermute_b32 v3, v2, v30                                // 000000837380: DACC0000 03001E02
	s_waitcnt lgkmcnt(0)                                       // 000000837388: BF89FC07
	v_dual_add_f32 v3, v30, v3 :: v_dual_lshlrev_b32 v4, 2, v4 // 00000083738C: C922071E 03040882
	ds_bpermute_b32 v5, v4, v3                                 // 000000837394: DACC0000 05000304
	s_waitcnt lgkmcnt(0)                                       // 00000083739C: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 0000008373A0: 06060B03
	ds_bpermute_b32 v2, v2, v27                                // 0000008373A4: DACC0000 02001B02
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 0000008373AC: 020C0D01
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008373B0: BF870001
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000008373B4: 300C0C82
	s_waitcnt lgkmcnt(0)                                       // 0000008373B8: BF89FC07
	v_add_f32_e32 v2, v27, v2                                  // 0000008373BC: 0604051B
	ds_bpermute_b32 v4, v4, v2                                 // 0000008373C0: DACC0000 04000204
	s_waitcnt lgkmcnt(0)                                       // 0000008373C8: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 0000008373CC: 06040902
	ds_bpermute_b32 v4, v6, v3                                 // 0000008373D0: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 0000008373D8: DACC0000 05000206
	v_xor_b32_e32 v6, 2, v1                                    // 0000008373E0: 3A0C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008373E4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000008373E8: 7C980CA0
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 0000008373EC: 020C0D01
	s_waitcnt lgkmcnt(1)                                       // 0000008373F0: BF89FC17
	v_dual_add_f32 v3, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v6  // 0000008373F4: C9220903 03060C82
	s_waitcnt lgkmcnt(0)                                       // 0000008373FC: BF89FC07
	v_add_f32_e32 v4, v2, v5                                   // 000000837400: 06080B02
	ds_bpermute_b32 v2, v6, v3                                 // 000000837404: DACC0000 02000306
	ds_bpermute_b32 v5, v6, v4                                 // 00000083740C: DACC0000 05000406
	v_xor_b32_e32 v6, 1, v1                                    // 000000837414: 3A0C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000837418: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000083741C: 7C980CA0
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 000000837420: 02020D01
	v_lshlrev_b32_e32 v6, 2, v1                                // 000000837424: 300C0282
	s_waitcnt lgkmcnt(0)                                       // 000000837428: BF89FC07
	v_dual_add_f32 v2, v3, v2 :: v_dual_add_f32 v1, v4, v5     // 00000083742C: C9080503 02000B04
	ds_bpermute_b32 v4, v6, v2                                 // 000000837434: DACC0000 04000206
	ds_bpermute_b32 v3, v6, v1                                 // 00000083743C: DACC0000 03000106
	v_cmpx_eq_u32_e32 0, v23                                   // 000000837444: 7D942E80
	s_cbranch_execz 10                                         // 000000837448: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xa74>
	s_waitcnt lgkmcnt(1)                                       // 00000083744C: BF89FC17
	v_dual_add_f32 v2, v2, v4 :: v_dual_lshlrev_b32 v5, 3, v22 // 000000837450: C9220902 02042C83
	s_waitcnt lgkmcnt(0)                                       // 000000837458: BF89FC07
	v_add_f32_e32 v3, v1, v3                                   // 00000083745C: 06060701
	s_delay_alu instid0(VALU_DEP_2)                            // 000000837460: BF870002
	v_lshl_or_b32 v4, v21, 4, v5                               // 000000837464: D6560004 04150915
	ds_store_b64 v4, v[2:3] offset:1024                        // 00000083746C: D9340400 00000204
	s_or_b32 exec_lo, exec_lo, s2                              // 000000837474: 8C7E027E
	s_waitcnt lgkmcnt(0)                                       // 000000837478: BF89FC07
	v_lshrrev_b32_e32 v3, 1, v0                                // 00000083747C: 32060081
	v_mov_b32_e32 v2, s21                                      // 000000837480: 7E040215
	.long 0xd44c0002                                           // 000000837484: D44C0002
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 000000837488: 02020088
	s_waitcnt vmcnt(0)                                         // 00000083748C: BF8903F7
	s_barrier                                                  // 000000837490: BFBD0000
	v_or_b32_e32 v1, s20, v3                                   // 000000837494: 38020614
	buffer_gl0_inv                                             // 000000837498: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000008374A0: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 0000008374A4: 8B026A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008374A8: BF870009
	s_and_saveexec_b32 s3, s2                                  // 0000008374AC: BE832002
	s_cbranch_execz 75                                         // 0000008374B0: BFA5004B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xbe0>
	v_and_b32_e32 v0, 1, v0                                    // 0000008374B4: 36000081
	s_load_b32 s0, s[0:1], 0x48                                // 0000008374B8: F4000000 F8000048
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008374C0: BF870091
	v_lshlrev_b32_e32 v4, 2, v0                                // 0000008374C4: 30080082
	v_lshl_or_b32 v3, v3, 4, v4                                // 0000008374C8: D6560003 04110903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000008374D0: BF8700C1
	v_add_nc_u32_e32 v3, 0x400, v3                             // 0000008374D4: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:2                     // 0000008374DC: D8DC0200 03000003
	s_waitcnt lgkmcnt(0)                                       // 0000008374E4: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 0000008374E8: 06060680
	v_add_f32_e32 v3, v3, v4                                   // 0000008374EC: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008374F0: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 0000008374F4: D6100004 02052103
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000008374FC: D6550003 03FE0903 00007FFF
	.long 0xd72c0004                                           // 000000837508: D72C0004
	v_cndmask_b32_e32 v1, s13, v0, vcc_lo                      // 00000083750C: 0202000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000837510: BF870092
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000837514: 360606FF FFFF0000
	v_mul_f32_e32 v3, s0, v3                                   // 00000083751C: 10060600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000837520: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 000000837524: 100606FF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 00000083752C: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000837530: BF870095
	v_add_f32_e32 v5, 1.0, v3                                  // 000000837534: 060A06F2
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 000000837538: D6FC7C06 03CA0B05
	v_div_scale_f32 v8, vcc_lo, 1.0, v5, 1.0                   // 000000837540: D6FC6A08 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000837548: BF870292
	v_rcp_f32_e32 v7, v6                                       // 00000083754C: 7E0E5506
	v_fma_f32 v3, -v6, v7, 1.0                                 // 000000837550: D6130003 23CA0F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000837558: BF870091
	v_fmac_f32_e32 v7, v3, v7                                  // 00000083755C: 560E0F03
	v_mul_f32_e32 v9, v8, v7                                   // 000000837560: 10120F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000837564: BF870091
	v_fma_f32 v3, -v6, v9, v8                                  // 000000837568: D6130003 24221306
	v_fmac_f32_e32 v9, v3, v7                                  // 000000837570: 56120F03
	.long 0xd72c0003                                           // 000000837574: D72C0003
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 000000837578: 0202000C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083757C: BF870112
	v_fma_f32 v0, -v6, v9, v8                                  // 000000837580: D6130000 24221306
	.long 0xd73c0003                                           // 000000837588: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000083758C: 02020682
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000837590: BF8701A2
	v_div_fmas_f32 v6, v0, v7, v9                              // 000000837594: D6370006 04260F00
	.long 0xd73c0000                                           // 00000083759C: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000008375A0: 02020282
	.long 0xd7006a03                                           // 0000008375A4: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 0000008375A8: 02020608
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008375AC: BF8701A3
	v_div_fixup_f32 v2, v6, v5, 1.0                            // 0000008375B0: D6270002 03CA0B06
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000008375B8: D5207C04 01AA0809
	.long 0xd7006a00                                           // 0000008375C0: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 0000008375C4: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008375C8: BF870193
	v_add_f32_e32 v2, v2, v2                                   // 0000008375CC: 06040502
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000008375D0: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 0000008375D8: DC6A0000 007C0200
	s_endpgm                                                   // 0000008375E0: BFB00000
		...

