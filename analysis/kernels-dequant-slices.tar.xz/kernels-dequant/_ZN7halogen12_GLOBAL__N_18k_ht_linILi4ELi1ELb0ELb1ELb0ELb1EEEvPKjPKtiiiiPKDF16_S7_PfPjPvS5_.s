0000000000471400 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x3                                               // 000000471400: BF850003
	s_load_b256 s[20:27], s[0:1], null                         // 000000471404: F40C0500 F8000000
	s_load_b256 s[12:19], s[0:1], 0x20                         // 00000047140C: F40C0300 F8000020
	s_load_b128 s[28:31], s[0:1], 0x40                         // 000000471414: F4080700 F8000040
	s_load_b32 s33, s[0:1], 0x54                               // 00000047141C: F4000840 F8000054
	v_and_b32_e32 v10, 31, v0                                  // 000000471424: 3614009F
	v_lshrrev_b32_e32 v8, 5, v0                                // 000000471428: 32100085
	s_mov_b32 s4, s3                                           // 00000047142C: BE840003
	s_mov_b32 s10, exec_lo                                     // 000000471430: BE8A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000471434: BF870002
	v_lshlrev_b32_e32 v9, 2, v10                               // 000000471438: 30121482
	s_waitcnt lgkmcnt(0)                                       // 00000047143C: BF89FC07
	s_ashr_i32 s34, s25, 31                                    // 000000471440: 86229F19
	s_mul_i32 s35, s27, s3                                     // 000000471444: 9623031B
	s_lshr_b32 s0, s34, 25                                     // 000000471448: 85009922
	s_add_i32 s1, s35, s27                                     // 00000047144C: 81011B23
	s_add_i32 s0, s25, s0                                      // 000000471450: 81000019
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000471454: BF870499
	s_ashr_i32 s0, s0, 7                                       // 000000471458: 86008700
	s_min_i32 s0, s0, s1                                       // 00000047145C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000471460: BF870499
	s_sub_i32 s11, s0, s35                                     // 000000471464: 818B2300
	.long 0xd4c4007e                                           // 000000471468: D4C4007E
	v_cndmask_b32_e32 v1, s11, v8, vcc_lo                      // 00000047146C: 0202100B
	s_cbranch_execz 501                                        // 000000471470: BFA501F5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x848>
	s_add_i32 s27, s24, -1                                     // 000000471474: 811BC118
	s_cmp_lg_u64 s[30:31], 0                                   // 000000471478: BF11801E
	v_dual_mov_b32 v11, v8 :: v_dual_and_b32 v2, 2, v0         // 00000047147C: CA240108 0B020082
	s_cselect_b32 s36, -1, 0                                   // 000000471484: 982480C1
	s_abs_i32 s37, s11                                         // 000000471488: BEA5150B
	v_lshlrev_b32_e32 v6, 3, v10                               // 00000047148C: 300C1483
	s_cvt_f32_u32 s0, s37                                      // 000000471490: BE806525
	v_and_b32_e32 v1, 1, v0                                    // 000000471494: 36020081
	v_and_b32_e32 v4, 4, v0                                    // 000000471498: 36080084
	v_and_b32_e32 v5, 8, v0                                    // 00000047149C: 360A0088
	v_rcp_iflag_f32_e32 v3, s0                                 // 0000004714A0: 7E065600
	v_add_nc_u32_e32 v7, s35, v8                               // 0000004714A4: 4A0E1023
	.long 0xd44a0003                                           // 0000004714A8: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000004714AC: 02020480
	v_lshl_or_b32 v2, v8, 8, v6                                // 0000004714B0: D6560002 04191108
	s_ashr_i32 s41, s11, 31                                    // 0000004714B8: 86299F0B
	s_sub_i32 s9, 0, s37                                       // 0000004714BC: 81892580
	s_mul_i32 s43, s41, 0x1400                                 // 0000004714C0: 962BFF29 00001400
	.long 0xd44c0000                                           // 0000004714C8: D44C0000
	v_cndmask_b32_e32 v1, 16, v10, vcc_lo                      // 0000004714CC: 02021490
	.long 0xd44a0001                                           // 0000004714D0: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000004714D4: 02020280
	.long 0xd44a0006                                           // 0000004714D8: D44A0006
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000004714DC: 02020A80
	v_readfirstlane_b32 s5, v3                                 // 0000004714E0: 7E0A0503
	v_lshl_or_b32 v1, v7, 7, v9                                // 0000004714E4: D6560001 04250F07
	v_subrev_nc_u32_e32 v12, s43, v2                           // 0000004714EC: 4E18042B
	s_lshl_b32 s7, s11, 7                                      // 0000004714F0: 8407870B
	s_mov_b32 s38, s25                                         // 0000004714F4: BEA60019
	s_mul_f32 s8, s5, 0x4f7ffffe                               // 0000004714F8: A208FF05 4F7FFFFE
	.long 0xd44a0005                                           // 000000471500: D44A0005
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000471504: 02020880
	s_mov_b32 s39, 0                                           // 000000471508: BEA70080
	s_mov_b32 s40, 0x76543210                                  // 00000047150C: BEA800FF 76543210
	s_cvt_u32_f32 s8, s8                                       // 000000471514: BE886708
	s_lshl_b32 s42, s11, 8                                     // 000000471518: 842A880B
	s_sub_i32 s43, 0, s7                                       // 00000047151C: 81AB0780
	s_mov_b32 s45, 0x3db504f3                                  // 000000471520: BEAD00FF 3DB504F3
	s_mul_i32 s9, s9, s8                                       // 000000471528: 96090809
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000047152C: BF870499
	s_mul_hi_u32 s9, s8, s9                                    // 000000471530: 96890908
	s_add_i32 s44, s8, s9                                      // 000000471534: 812C0908
	s_branch 164                                               // 000000471538: BFA000A4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3cc>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047153C: BF870091
	.long 0xd7006a02                                           // 000000471540: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000471544: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000471548: D5207C03 01AA060D
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000471550: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000471558: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000471560: BF8903F7
	v_fma_mix_f32 v5, v17, v2, v15 op_sel_hi:[0,1,0]           // 000000471564: CC200005 143E0511
	v_sub_f32_e32 v4, v18, v16                                 // 00000047156C: 08082112
	v_fma_mix_f32 v2, -v17, v2, v15 op_sel_hi:[0,1,0]          // 000000471570: CC200002 343E0511
	v_add_f32_e32 v3, v18, v16                                 // 000000471578: 06062112
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047157C: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000471580: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000471584: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000471588: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000047158C: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000471590: BF870193
	v_mov_b32_dpp v16, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000471594: 7E2002FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047159C: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000004715A4: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 0000004715AC: D5010002 20060502
	v_mov_b32_dpp v15, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004715B4: 7E1E02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000004715BC: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000004715C4: BF870144
	v_add_f32_e32 v4, v6, v4                                   // 0000004715C8: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004715CC: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000004715D4: D5010007 20060F07
	.long 0xd72c0006                                           // 0000004715DC: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v14, vcc_lo                  // 0000004715E0: 02021CFF 00001400
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v5, v7, v5    // 0000004715E8: C9082102 02040B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004715F0: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000004715F8: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000471600: BF8701C3
	v_mov_b32_dpp v16, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000471604: 7E2002FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 00000047160C: D5010002 200E0502
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000471614: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 00000047161C: D5010005 200E0B05
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 000000471624: C9081F03 03022102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047162C: BF870112
	v_add_f32_e32 v5, v5, v14                                  // 000000471630: 060A1D05
	v_mov_b32_dpp v15, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000471634: 7E1E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 00000047163C: D5010003 200E0703
	s_delay_alu instid0(VALU_DEP_4)                            // 000000471644: BF870004
	v_mov_b32_dpp v16, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000471648: 7E2002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000471650: D5010002 20160502
	v_mov_b32_dpp v14, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000471658: 7E1C02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000471660: D5010005 20160B05
	v_add_f32_e32 v4, v4, v7                                   // 000000471668: 06080F04
	.long 0xd72c0007                                           // 00000047166C: D72C0007
	v_cndmask_b32_e32 v1, s42, v13, vcc_lo                     // 000000471670: 02021A2A
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_nc_u32 v11, 8, v11// 000000471674: C9202102 020A1688
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047167C: BF870214
	v_add_f32_e32 v5, v5, v14                                  // 000000471680: 060A1D05
	v_mov_b32_dpp v13, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000471684: 7E1A02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 00000047168C: D5010004 20160904
	v_add_f32_e32 v3, v3, v15                                  // 000000471694: 06061F03
	v_mov_b32_dpp v16, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000471698: 7E2002FA FF016802
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004716A0: 7E1C02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 0000004716A8: D5010005 201A0B05
	v_add_f32_e32 v4, v4, v13                                  // 0000004716B0: 06081B04
	v_mov_b32_dpp v15, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004716B4: 7E1E02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 0000004716BC: D5010003 20160703
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 0000004716C4: D5010002 201A0502
	v_add_f32_e32 v5, v5, v14                                  // 0000004716CC: 060A1D05
	v_mov_b32_dpp v13, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004716D0: 7E1A02FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 0000004716D8: D5010004 201A0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004716E0: BF870214
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 0000004716E4: C9081F03 03022102
	v_mov_b32_e32 v14, v5                                      // 0000004716EC: 7E1C0305
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 0000004716F0: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004716F8: BF870214
	v_add_f32_e32 v4, v4, v13                                  // 0000004716FC: 06081B04
	v_mov_b32_dpp v15, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000471700: 7E1E02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000471708: D5010003 201A0703
	v_mov_b32_e32 v16, v2                                      // 000000471710: 7E200302
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000471714: D5010002 20020502
	v_mov_b32_e32 v13, v4                                      // 00000047171C: 7E1A0304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000471720: D5010004 20020904
	v_add_f32_e32 v3, v3, v15                                  // 000000471728: 06061F03
	v_permlanex16_b32 v14, v14, s40, 0xfedcba98                // 00000047172C: D65C000E 03FC510E FEDCBA98
	v_permlanex16_b32 v16, v16, s40, 0xfedcba98                // 000000471738: D65C0010 03FC5110 FEDCBA98
	v_permlanex16_b32 v13, v13, s40, 0xfedcba98                // 000000471744: D65C000D 03FC510D FEDCBA98
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000471750: 4C0C0F06
	v_mov_b32_e32 v15, v3                                      // 000000471754: 7E1E0303
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000471758: D5010003 20020703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000471760: BF870214
	v_dual_add_f32 v5, v5, v14 :: v_dual_add_f32 v4, v4, v13   // 000000471764: C9081D05 05041B04
	v_dual_add_f32 v7, v2, v16 :: v_dual_add_nc_u32 v6, v12, v6// 00000047176C: C9202102 07060D0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000471774: BF870224
	v_permlanex16_b32 v15, v15, s40, 0xfedcba98                // 000000471778: D65C000F 03FC510F FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s11, v11                          // 000000471784: 7C86160B
	v_fma_mixlo_f16 v2, v4, s45, 0                             // 000000471788: CC210002 02005B04
	v_add_nc_u32_e32 v12, 0x800, v12                           // 000000471790: 4A1818FF 00000800
	v_fma_mixhi_f16 v2, v5, s45, 0                             // 000000471798: CC220002 02005B05
	v_add_f32_e32 v13, v3, v15                                 // 0000004717A0: 061A1F03
	v_fma_mixhi_f16 v3, v7, s45, 0                             // 0000004717A4: CC220003 02005B07
	s_or_b32 s39, vcc_lo, s39                                  // 0000004717AC: 8C27276A
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004717B0: BF870002
	v_fma_mixlo_f16 v3, v13, s45, 0                            // 0000004717B4: CC210003 02005B0D
	ds_store_b64 v6, v[2:3]                                    // 0000004717BC: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s39                       // 0000004717C4: 917E277E
	s_cbranch_execz 287                                        // 0000004717C8: BFA5011F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x848>
	.long 0xd72d0002                                           // 0000004717CC: D72D0002
	v_cndmask_b32_e32 v0, v11, v44, vcc_lo                     // 0000004717D0: 0200590B
	s_mov_b32 s7, -1                                           // 0000004717D4: BE8700C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004717D8: BF870091
	.long 0xd72c0003                                           // 0000004717DC: D72C0003
	v_cndmask_b32_e32 v0, v2, v37, vcc_lo                      // 0000004717E0: 02004B02
	v_sub_nc_u32_e32 v3, v11, v3                               // 0000004717E4: 4C06070B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004717E8: BF870121
	v_subrev_nc_u32_e32 v5, s37, v3                            // 0000004717EC: 4E0A0625
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 0000004717F0: 7C960625
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 0000004717F4: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004717FC: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000471800: 02040902
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000471804: 7C960625
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000471808: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000047180C: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000471810: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s36                        // 000000471814: 916A247E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000471818: BF870091
	v_xor_b32_e32 v14, s41, v2                                 // 00000047181C: 3A1C0429
	v_subrev_nc_u32_e32 v13, s41, v14                          // 000000471820: 4E1A1C29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000471824: BF8700A1
	v_mad_u64_u32 v[6:7], null, s43, v13, v[1:2]               // 000000471828: D6FE7C06 04061A2B
	v_min_i32_e32 v2, s27, v13                                 // 000000471830: 22041A1B
	v_mad_i64_i32 v[4:5], null, v2, s38, 0                     // 000000471834: D6FF7C04 02004D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047183C: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000471840: 340E0C9F
	.long 0xd73c0002                                           // 000000471844: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000471848: 02020C81
	s_cbranch_vccnz 210                                        // 00000047184C: BFA400D2 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x798>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000471850: BF870093
	.long 0xd7006a06                                           // 000000471854: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000471858: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 00000047185C: D5207C07 01AA0F05
	.long 0x7f3e3880                                           // 000000471864: 7F3E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000471868: BF870112
	.long 0xd73c0006                                           // 00000047186C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000471870: 02020C81
	.long 0x7f44399f                                           // 000000471874: 7F44399F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000471878: BF870092
	.long 0xd7006a0f                                           // 00000047187C: D7006A0F
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 000000471880: 02020C16
	v_add_co_ci_u32_e64 v16, null, s23, v7, vcc_lo             // 000000471884: D5207C10 01AA0E17
	.long 0xd7006a06                                           // 00000047188C: D7006A06
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000471890: 02020C1E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000471894: BF870001
	v_add_co_ci_u32_e64 v7, null, s31, v7, vcc_lo              // 000000471898: D5207C07 01AA0E1F
	global_load_b64 v[15:16], v[15:16], off                    // 0000004718A0: DC560000 0F7C000F
	.long 0xd7006a11                                           // 0000004718A8: D7006A11
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000004718AC: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 0000004718B0: DC560000 067C0006
	v_add_co_ci_u32_e64 v18, null, s13, v3, vcc_lo             // 0000004718B8: D5207C12 01AA060D
	s_clause 0x1                                               // 0000004718C0: BF850001
	global_load_b32 v19, v[17:18], off                         // 0000004718C4: DC520000 137C0011
	global_load_d16_b16 v17, v[17:18], off offset:4            // 0000004718CC: DC820004 117C0011
	s_waitcnt vmcnt(3)                                         // 0000004718D4: BF890FF7
	.long 0x7e24390f                                           // 0000004718D8: 7E24390F
	s_waitcnt vmcnt(2)                                         // 0000004718DC: BF890BF7
	v_and_b32_e32 v41, 0xffff0000, v6                          // 0000004718E0: 36520CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000004718E8: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004718EC: BF870093
	v_lshlrev_b32_e32 v18, 16, v18                             // 0000004718F0: 30242490
	v_mul_f32_e32 v22, 0xbfb8aa3b, v18                         // 0000004718F4: 102C24FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000004718FC: BF870291
	v_exp_f32_e32 v22, v22                                     // 000000471900: 7E2C4B16
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_and_b32 v15, 0xffff0000, v15// 000000471904: C9242CF2 160E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000471910: BF870111
	v_mul_f32_e32 v21, 0xbfb8aa3b, v15                         // 000000471914: 102A1EFF BFB8AA3B
	v_div_scale_f32 v26, null, v22, v22, v18                   // 00000047191C: D6FC7C1A 044A2D16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000471924: BF8701B2
	v_exp_f32_e32 v21, v21                                     // 000000471928: 7E2A4B15
	v_lshlrev_b32_e32 v20, 16, v16                             // 00000047192C: 30282090
	v_div_scale_f32 v39, s8, v18, v22, v18                     // 000000471930: D6FC0827 044A2D12
	v_rcp_f32_e32 v30, v26                                     // 000000471938: 7E3C551A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047193C: BF870196
	v_add_f32_e32 v21, 1.0, v21                                // 000000471940: 062A2AF2
	v_mul_f32_e32 v23, 0xbfb8aa3b, v20                         // 000000471944: 102E28FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047194C: BF870195
	v_fma_f32 v38, -v26, v30, 1.0                              // 000000471950: D6130026 23CA3D1A
	v_div_scale_f32 v25, null, v21, v21, v15                   // 000000471958: D6FC7C19 043E2B15
	s_delay_alu instid0(VALU_DEP_3)                            // 000000471960: BF870003
	v_exp_f32_e32 v23, v23                                     // 000000471964: 7E2E4B17
	v_and_b32_e32 v16, 0xffff0000, v16                         // 000000471968: 362020FF FFFF0000
	v_div_scale_f32 v35, vcc_lo, v15, v21, v15                 // 000000471970: D6FC6A23 043E2B0F
	v_fmac_f32_e32 v30, v38, v30                               // 000000471978: 563C3D26
	v_rcp_f32_e32 v28, v25                                     // 00000047197C: 7E385519
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000471980: BF870186
	v_dual_add_f32 v23, 1.0, v23 :: v_dual_mul_f32 v24, 0xbfb8aa3b, v16// 000000471984: C9062EF2 171820FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000471990: BF870115
	v_fma_f32 v36, -v25, v28, 1.0                              // 000000471994: D6130024 23CA3919
	v_div_scale_f32 v27, null, v23, v23, v20                   // 00000047199C: D6FC7C1B 04522F17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004719A4: BF8701A3
	v_exp_f32_e32 v24, v24                                     // 0000004719A8: 7E304B18
	v_div_scale_f32 v37, s7, v20, v23, v20                     // 0000004719AC: D6FC0725 04522F14
	v_fmac_f32_e32 v28, v36, v28                               // 0000004719B4: 56383924
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000004719B8: BF870313
	v_rcp_f32_e32 v32, v27                                     // 0000004719BC: 7E40551B
	v_add_f32_e32 v24, 1.0, v24                                // 0000004719C0: 063030F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004719C4: BF870115
	v_fma_f32 v40, -v27, v32, 1.0                              // 0000004719C8: D6130028 23CA411B
	v_div_scale_f32 v29, null, v24, v24, v16                   // 0000004719D0: D6FC7C1D 04423118
	v_div_scale_f32 v38, s9, v16, v24, v16                     // 0000004719D8: D6FC0926 04423110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004719E0: BF870193
	v_fmac_f32_e32 v32, v40, v32                               // 0000004719E4: 56404128
	v_rcp_f32_e32 v33, v29                                     // 0000004719E8: 7E42551D
	v_mul_f32_e32 v40, v35, v28                                // 0000004719EC: 10503923
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004719F0: BF870112
	v_mul_f32_e32 v42, v37, v32                                // 0000004719F4: 10544125
	v_fma_f32 v43, -v25, v40, v35                              // 0000004719F8: D613002B 248E5119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000471A00: BF870292
	v_fma_f32 v46, -v27, v42, v37                              // 000000471A04: D613002E 2496551B
	v_fma_f32 v36, -v29, v33, 1.0                              // 000000471A0C: D6130024 23CA431D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000471A14: BF870113
	v_fmac_f32_e32 v40, v43, v28                               // 000000471A18: 5650392B
	v_dual_fmac_f32 v42, v46, v32 :: v_dual_fmac_f32 v33, v36, v33// 000000471A1C: C800412E 2A204324
	v_mul_f32_e32 v36, v39, v30                                // 000000471A24: 10483D27
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000471A28: BF870193
	v_fma_f32 v25, -v25, v40, v35                              // 000000471A2C: D6130019 248E5119
	v_fma_f32 v27, -v27, v42, v37                              // 000000471A34: D613001B 2496551B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000471A3C: BF870214
	v_mul_f32_e32 v44, v38, v33                                // 000000471A40: 10584326
	v_fma_f32 v45, -v26, v36, v39                              // 000000471A44: D613002D 249E491A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000471A4C: BF8701A4
	v_div_fmas_f32 v25, v25, v28, v40                          // 000000471A50: D6370019 04A23919
	s_mov_b32 vcc_lo, s8                                       // 000000471A58: BEEA0008
	v_fma_f32 v43, -v29, v44, v38                              // 000000471A5C: D613002B 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000471A64: BF870193
	v_fmac_f32_e32 v36, v45, v30                               // 000000471A68: 56483D2D
	v_div_fixup_f32 v15, v25, v21, v15                         // 000000471A6C: D627000F 043E2B19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000471A74: BF870193
	v_fmac_f32_e32 v44, v43, v33                               // 000000471A78: 5658432B
	v_fma_f32 v26, -v26, v36, v39                              // 000000471A7C: D613001A 249E491A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000471A84: BF870193
	v_mul_f32_e32 v15, v15, v41                                // 000000471A88: 101E530F
	v_fma_f32 v25, -v29, v44, v38                              // 000000471A8C: D6130019 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000471A94: BF8701A3
	v_div_fmas_f32 v26, v26, v30, v36                          // 000000471A98: D637001A 04923D1A
	s_mov_b32 vcc_lo, s7                                       // 000000471AA0: BEEA0007
	.long 0x7e3e398f                                           // 000000471AA4: 7E3E398F
	v_div_fmas_f32 v21, v27, v32, v42                          // 000000471AA8: D6370015 04AA411B
	s_mov_b32 vcc_lo, s9                                       // 000000471AB0: BEEA0009
	v_div_fixup_f32 v18, v26, v22, v18                         // 000000471AB4: D6270012 044A2D1A
	v_lshlrev_b32_e32 v22, 16, v7                              // 000000471ABC: 302C0E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000471AC0: 360E0EFF FFFF0000
	v_div_fixup_f32 v20, v21, v23, v20                         // 000000471AC8: D6270014 04522F15
	s_mov_b32 s7, 0                                            // 000000471AD0: BE870080
	v_mul_f32_e32 v6, v18, v6                                  // 000000471AD4: 100C0D12
	v_div_fmas_f32 v18, v25, v33, v44                          // 000000471AD8: D6370012 04B24319
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000471AE0: BF870193
	v_mul_f32_e32 v20, v20, v22                                // 000000471AE4: 10282D14
	.long 0x7e443986                                           // 000000471AE8: 7E443986
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000471AEC: BF870223
	v_div_fixup_f32 v16, v18, v24, v16                         // 000000471AF0: D6270010 04423112
	v_and_b32_e32 v18, 1, v31                                  // 000000471AF8: 36243E81
	v_bfe_u32 v21, v20, 16, 1                                  // 000000471AFC: D6100015 02052114
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000471B04: BF870193
	v_dual_mul_f32 v7, v16, v7 :: v_dual_and_b32 v22, 1, v34   // 000000471B08: C8E40F10 07164481
	v_add3_u32 v15, v15, v18, 0x7fff                           // 000000471B10: D655000F 03FE250F 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000471B1C: BF870193
	v_add3_u32 v16, v20, v21, 0x7fff                           // 000000471B20: D6550010 03FE2B14 00007FFF
	v_add3_u32 v6, v6, v22, 0x7fff                             // 000000471B2C: D6550006 03FE2D06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000471B38: BF870214
	v_bfe_u32 v18, v7, 16, 1                                   // 000000471B3C: D6100012 02052107
	v_and_b32_e32 v15, 0xffff0000, v15                         // 000000471B44: 361E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000471B4C: BF870214
	v_and_b32_e32 v20, 0xffff0000, v16                         // 000000471B50: 362820FF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000471B58: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000471B60: BF870004
	v_add3_u32 v7, v7, v18, 0x7fff                             // 000000471B64: D6550007 03FE2507 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000471B70: BF8907F7
	v_fma_mix_f32 v16, v19, v15, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000471B74: CC200810 8A021F13
	s_waitcnt vmcnt(0)                                         // 000000471B7C: BF8903F7
	v_fma_mix_f32 v15, v17, v20, neg(0) op_sel_hi:[1,0,0]      // 000000471B80: CC20000F 8A022911
	v_fma_mix_f32 v18, v19, v6, neg(0) op_sel_hi:[1,0,0]       // 000000471B88: CC200012 8A020D13
	v_and_b32_e32 v17, 0xffff0000, v7                          // 000000471B90: 36220EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 000000471B98: 916A077E
	s_cbranch_vccnz 65127                                      // 000000471B9C: BFA4FE67 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x13c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000471BA0: BF870093
	.long 0xd73c0004                                           // 000000471BA4: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000471BA8: 02020881
	.long 0xd7006a04                                           // 000000471BAC: D7006A04
	v_cndmask_b32_e32 v1, s22, v4, vcc_lo                      // 000000471BB0: 02020816
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000471BB4: BF870111
	v_add_co_ci_u32_e64 v5, null, s23, v5, vcc_lo              // 000000471BB8: D5207C05 01AA0A17
	.long 0xd7006a04                                           // 000000471BC0: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000471BC4: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000471BC8: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000471BCC: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000471BD4: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000471BD8: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 000000471BDC: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 000000471BE4: DC560000 047C0004
	s_clause 0x1                                               // 000000471BEC: BF850001
	global_load_b32 v17, v[6:7], off                           // 000000471BF0: DC520000 117C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000471BF8: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000471C00: BF890BF7
	.long 0x7e0e3904                                           // 000000471C04: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000471C08: 360808FF FFFF0000
	v_lshlrev_b32_e32 v15, 16, v5                              // 000000471C10: 301E0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000471C14: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000471C18: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000471C1C: BF8907F7
	v_fma_mix_f32 v16, v17, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000471C20: CC200810 8A020911
	s_waitcnt vmcnt(0)                                         // 000000471C28: BF8903F7
	v_fma_mix_f32 v15, v6, v15, neg(0) op_sel_hi:[1,0,0]       // 000000471C2C: CC20000F 8A021F06
	v_fma_mix_f32 v18, v17, v7, neg(0) op_sel_hi:[1,0,0]       // 000000471C34: CC200012 8A020F11
	v_and_b32_e32 v17, 0xffff0000, v5                          // 000000471C3C: 36220AFF FFFF0000
	s_branch 65085                                             // 000000471C44: BFA0FE3D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x13c>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000471C48: 8C7E0A7E
	s_bfe_i32 s10, s11, 0x1001c                                // 000000471C4C: 938AFF0B 0001001C
	s_lshr_b32 s3, s34, 28                                     // 000000471C54: 85039C22
	s_lshr_b64 s[0:1], s[10:11], 29                            // 000000471C58: 85809D0A
	s_add_i32 s3, s25, s3                                      // 000000471C5C: 81030319
	s_add_i32 s0, s0, 7                                        // 000000471C60: 81008700
	s_lshl_b32 s1, s11, 3                                      // 000000471C64: 8401830B
	s_ashr_i32 s0, s0, 3                                       // 000000471C68: 86008300
	s_lshl_b32 s5, s35, 3                                      // 000000471C6C: 84058323
	.long 0xd72c0001                                           // 000000471C70: D72C0001
	v_cndmask_b32_e32 v1, s0, v8, vcc_lo                       // 000000471C74: 02021000
	s_waitcnt lgkmcnt(0)                                       // 000000471C78: BF89FC07
	s_barrier                                                  // 000000471C7C: BFBD0000
	buffer_gl0_inv                                             // 000000471C80: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 000000471C88: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 000000471C8C: 86008403
	s_ashr_i32 s3, s5, 31                                      // 000000471C90: 86039F05
	s_mul_hi_i32 s6, s0, s2                                    // 000000471C94: 97060200
	s_mul_i32 s0, s0, s2                                       // 000000471C98: 96000200
	v_min_i32_e32 v7, s1, v2                                   // 000000471C9C: 220E0401
	v_add_nc_u32_e32 v2, 1, v1                                 // 000000471CA0: 4A040281
	s_add_u32 s0, s0, s5                                       // 000000471CA4: 80000500
	s_addc_u32 s1, s6, s3                                      // 000000471CA8: 82010306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000471CAC: BF870099
	s_lshl_b64 s[6:7], s[0:1], 10                              // 000000471CB0: 84868A00
	v_cmp_lt_i32_e32 vcc_lo, v2, v7                            // 000000471CB4: 7C820F02
	s_add_u32 s1, s20, s6                                      // 000000471CB8: 80010614
	s_addc_u32 s5, s21, s7                                     // 000000471CBC: 82050715
	s_and_saveexec_b32 s0, vcc_lo                              // 000000471CC0: BE80206A
	s_cbranch_execz 91                                         // 000000471CC4: BFA5005B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xa34>
	.long 0xd7010303                                           // 000000471CC8: D7010303
	v_cndmask_b32_e32 v0, v10, v129, vcc_lo                    // 000000471CCC: 0201030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000471CD0: BF870121
	v_cndmask_b32_e64 v4, v3, 31, s3                           // 000000471CD4: D5010004 000D3F03
	v_ashrrev_i32_e32 v3, 31, v2                               // 000000471CDC: 3406049F
	v_cmp_gt_u32_e32 vcc_lo, 31, v4                            // 000000471CE0: 7C98089F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000471CE4: BF8701B2
	.long 0xd73c0002                                           // 000000471CE8: D73C0002
	v_cndmask_b32_e32 v1, 10, v2, vcc_lo                       // 000000471CEC: 0202048A
	v_cndmask_b32_e64 v6, 0xe1, 1, vcc_lo                      // 000000471CF0: D5010006 01A902FF 000000E1
	v_mov_b32_e32 v5, 0                                        // 000000471CFC: 7E0A0280
	.long 0xd7006a0c                                           // 000000471D00: D7006A0C
	v_cndmask_b32_e32 v1, s1, v2, vcc_lo                       // 000000471D04: 02020401
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000471D08: BF870211
	v_add_co_ci_u32_e64 v13, null, s5, v3, vcc_lo              // 000000471D0C: D5207C0D 01AA0605
	v_add_nc_u32_e32 v6, v6, v4                                // 000000471D14: 4A0C0906
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000471D18: BF870114
	.long 0xd73c0004                                           // 000000471D1C: D73C0004
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 000000471D20: 02020882
	v_lshlrev_b32_e32 v11, 24, v6                              // 000000471D24: 30160C98
	v_bfe_i32 v6, v6, 7, 1                                     // 000000471D28: D6110006 02050F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000471D30: BF870093
	.long 0xd7006a02                                           // 000000471D34: D7006A02
	v_cndmask_b32_e32 v1, v12, v4, vcc_lo                      // 000000471D38: 0202090C
	v_add_co_ci_u32_e64 v3, null, v13, v5, vcc_lo              // 000000471D3C: D5207C03 01AA0B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000471D44: BF870094
	v_ashrrev_i32_e32 v11, 22, v11                             // 000000471D48: 34161696
	.long 0xd7006a04                                           // 000000471D4C: D7006A04
	v_cndmask_b32_e32 v1, v12, v11, vcc_lo                     // 000000471D50: 0202170C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000471D54: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v13, v6, vcc_lo              // 000000471D58: D5207C05 01AA0D0D
	.long 0xd7006a23                                           // 000000471D60: D7006A23
	v_cndmask_b32_e32 v1, v12, v9, vcc_lo                      // 000000471D64: 0202130C
	v_add_co_ci_u32_e64 v36, null, 0, v13, vcc_lo              // 000000471D68: D5207C24 01AA1A80
	s_clause 0x17                                              // 000000471D70: BF850017
	global_load_b32 v11, v[2:3], off                           // 000000471D74: DC520000 0B7C0002
	global_load_b32 v18, v[2:3], off offset:128                // 000000471D7C: DC520080 127C0002
	global_load_b32 v17, v[2:3], off offset:256                // 000000471D84: DC520100 117C0002
	global_load_b32 v16, v[2:3], off offset:384                // 000000471D8C: DC520180 107C0002
	global_load_b32 v15, v[2:3], off offset:512                // 000000471D94: DC520200 0F7C0002
	global_load_b32 v14, v[2:3], off offset:640                // 000000471D9C: DC520280 0E7C0002
	global_load_b32 v13, v[2:3], off offset:768                // 000000471DA4: DC520300 0D7C0002
	global_load_b32 v12, v[2:3], off offset:896                // 000000471DAC: DC520380 0C7C0002
	global_load_b32 v30, v[4:5], off                           // 000000471DB4: DC520000 1E7C0004
	global_load_b32 v28, v[4:5], off offset:128                // 000000471DBC: DC520080 1C7C0004
	global_load_b32 v26, v[4:5], off offset:256                // 000000471DC4: DC520100 1A7C0004
	global_load_b32 v24, v[4:5], off offset:384                // 000000471DCC: DC520180 187C0004
	global_load_b32 v22, v[4:5], off offset:512                // 000000471DD4: DC520200 167C0004
	global_load_b32 v21, v[4:5], off offset:640                // 000000471DDC: DC520280 157C0004
	global_load_b32 v20, v[4:5], off offset:768                // 000000471DE4: DC520300 147C0004
	global_load_b32 v19, v[4:5], off offset:896                // 000000471DEC: DC520380 137C0004
	global_load_b32 v34, v[35:36], off                         // 000000471DF4: DC520000 227C0023
	global_load_b32 v33, v[35:36], off offset:128              // 000000471DFC: DC520080 217C0023
	global_load_b32 v32, v[35:36], off offset:256              // 000000471E04: DC520100 207C0023
	global_load_b32 v31, v[35:36], off offset:384              // 000000471E0C: DC520180 1F7C0023
	global_load_b32 v29, v[35:36], off offset:512              // 000000471E14: DC520200 1D7C0023
	global_load_b32 v27, v[35:36], off offset:640              // 000000471E1C: DC520280 1B7C0023
	global_load_b32 v25, v[35:36], off offset:768              // 000000471E24: DC520300 197C0023
	global_load_b32 v23, v[35:36], off offset:896              // 000000471E2C: DC520380 177C0023
	s_or_b32 exec_lo, exec_lo, s0                              // 000000471E34: 8C7E007E
	v_cmp_lt_i32_e32 vcc_lo, v1, v7                            // 000000471E38: 7C820F01
	s_and_saveexec_b32 s3, vcc_lo                              // 000000471E3C: BE83206A
	s_cbranch_execz 93                                         // 000000471E40: BFA5005D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xbb8>
	.long 0xd7010002                                           // 000000471E44: D7010002
	v_cndmask_b32_e32 v0, v10, v129, vcc_lo                    // 000000471E48: 0201030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000471E4C: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 000000471E50: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000471E58: 3404029F
	.long 0xd44c0000                                           // 000000471E5C: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000471E60: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000471E64: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 000000471E68: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v35, v5, v3      // 000000471E74: CA200080 04220705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000471E7C: BF870114
	.long 0xd73c0005                                           // 000000471E80: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000471E84: 0202028A
	.long 0xd73c0002                                           // 000000471E88: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000471E8C: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000471E90: BF870223
	v_lshlrev_b32_e32 v4, 24, v35                              // 000000471E94: 30084698
	v_bfe_i32 v36, v35, 7, 1                                   // 000000471E98: D6110024 02050F23
	.long 0xd7000025                                           // 000000471EA0: D7000025
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000471EA4: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000471EA8: BF870211
	v_add_co_ci_u32_e64 v6, null, s5, v6, s0                   // 000000471EAC: D5207C06 00020C05
	v_ashrrev_i32_e32 v35, 22, v4                              // 000000471EB4: 34460896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000471EB8: BF870093
	.long 0xd7000004                                           // 000000471EBC: D7000004
	v_cndmask_b32_e32 v1, v37, v2, vcc_lo                      // 000000471EC0: 02020525
	v_add_co_ci_u32_e64 v5, null, v6, v3, s0                   // 000000471EC4: D5207C05 00020706
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000471ECC: BF870093
	.long 0xd7000023                                           // 000000471ED0: D7000023
	v_cndmask_b32_e32 v1, v37, v35, vcc_lo                     // 000000471ED4: 02024725
	v_add_co_ci_u32_e64 v36, null, v6, v36, s0                 // 000000471ED8: D5207C24 00024906
	.long 0xd7000025                                           // 000000471EE0: D7000025
	v_cndmask_b32_e32 v1, v37, v9, vcc_lo                      // 000000471EE4: 02021325
	s_delay_alu instid0(VALU_DEP_1)                            // 000000471EE8: BF870001
	v_add_co_ci_u32_e64 v38, null, 0, v6, s0                   // 000000471EEC: D5207C26 00020C80
	s_clause 0x17                                              // 000000471EF4: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000471EF8: DC520000 027C0004
	global_load_b32 v81, v[4:5], off offset:128                // 000000471F00: DC520080 517C0004
	global_load_b32 v78, v[4:5], off offset:256                // 000000471F08: DC520100 4E7C0004
	global_load_b32 v75, v[4:5], off offset:384                // 000000471F10: DC520180 4B7C0004
	global_load_b32 v72, v[4:5], off offset:512                // 000000471F18: DC520200 487C0004
	global_load_b32 v69, v[4:5], off offset:640                // 000000471F20: DC520280 457C0004
	global_load_b32 v51, v[4:5], off offset:768                // 000000471F28: DC520300 337C0004
	global_load_b32 v44, v[4:5], off offset:896                // 000000471F30: DC520380 2C7C0004
	global_load_b32 v3, v[35:36], off                          // 000000471F38: DC520000 037C0023
	global_load_b32 v82, v[35:36], off offset:128              // 000000471F40: DC520080 527C0023
	global_load_b32 v79, v[35:36], off offset:256              // 000000471F48: DC520100 4F7C0023
	global_load_b32 v76, v[35:36], off offset:384              // 000000471F50: DC520180 4C7C0023
	global_load_b32 v73, v[35:36], off offset:512              // 000000471F58: DC520200 497C0023
	global_load_b32 v70, v[35:36], off offset:640              // 000000471F60: DC520280 467C0023
	global_load_b32 v52, v[35:36], off offset:768              // 000000471F68: DC520300 347C0023
	global_load_b32 v45, v[35:36], off offset:896              // 000000471F70: DC520380 2D7C0023
	global_load_b32 v83, v[37:38], off                         // 000000471F78: DC520000 537C0025
	global_load_b32 v80, v[37:38], off offset:128              // 000000471F80: DC520080 507C0025
	global_load_b32 v77, v[37:38], off offset:256              // 000000471F88: DC520100 4D7C0025
	global_load_b32 v74, v[37:38], off offset:384              // 000000471F90: DC520180 4A7C0025
	global_load_b32 v71, v[37:38], off offset:512              // 000000471F98: DC520200 477C0025
	global_load_b32 v68, v[37:38], off offset:640              // 000000471FA0: DC520280 447C0025
	global_load_b32 v50, v[37:38], off offset:768              // 000000471FA8: DC520300 327C0025
	global_load_b32 v43, v[37:38], off offset:896              // 000000471FB0: DC520380 2B7C0025
	s_or_b32 exec_lo, exec_lo, s3                              // 000000471FB8: 8C7E037E
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000471FBC: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000471FC4: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 000000471FCC: CA100080 27280080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 000000471FD4: CA100080 292A0080
	s_ashr_i32 s3, s2, 31                                      // 000000471FDC: 86039F02
	s_and_saveexec_b32 s0, vcc_lo                              // 000000471FE0: BE80206A
	s_cbranch_execz 959                                        // 000000471FE4: BFA503BF <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ae4>
	v_dual_mov_b32 v35, 0 :: v_dual_add_nc_u32 v4, -1, v0      // 000000471FE8: CA200080 230400C1
	v_dual_mov_b32 v37, 0 :: v_dual_and_b32 v6, 16, v0         // 000000471FF0: CA240080 25060090
	v_sub_nc_u32_e32 v46, 0, v7                                // 000000471FF8: 4C5C0E80
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000471FFC: BF870243
	v_dual_mov_b32 v39, 0 :: v_dual_and_b32 v4, 31, v4         // 000000472000: CA240080 2704089F
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v5, 2, v1       // 000000472008: CA200080 24040282
	v_dual_mov_b32 v38, 0 :: v_dual_lshlrev_b32 v47, 2, v10    // 000000472010: CA220080 262E1482
	v_lshl_or_b32 v48, v1, 5, v6                               // 000000472018: D6560030 04190B01
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v49, 2, v4     // 000000472020: CA220080 28300882
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 000000472028: CA100080 292A0080
	s_mov_b32 s6, 0                                            // 000000472030: BE860080
	s_movk_i32 s7, 0x1eee                                      // 000000472034: B0071EEE
	s_branch 881                                               // 000000472038: BFA00371 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1a00>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000047203C: 8C7E087E
	s_waitcnt vmcnt(15)                                        // 000000472040: BF893FF7
	v_alignbit_b32 v84, v2, v3, 16                             // 000000472044: D6160054 02420702
	s_waitcnt vmcnt(14)                                        // 00000047204C: BF893BF7
	v_alignbit_b32 v81, v81, v82, 16                           // 000000472050: D6160051 0242A551
	ds_load_b128 v[1:4], v48                                   // 000000472058: DBFC0000 01000030
	s_waitcnt vmcnt(7)                                         // 000000472060: BF891FF7
	v_bfe_u32 v85, v83, 12, 16                                 // 000000472064: D6100055 02411953
	v_bfe_u32 v86, v83, 8, 16                                  // 00000047206C: D6100056 02411153
	v_bfe_u32 v88, v84, 12, 16                                 // 000000472074: D6100058 02411954
	v_bfe_u32 v82, v84, 8, 16                                  // 00000047207C: D6100052 02411154
	v_bfe_u32 v87, v83, 4, 16                                  // 000000472084: D6100057 02410953
	.long 0xd72c0055                                           // 00000047208C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000472090: 0202AAFF 83DCD12D
	.long 0xd72c0056                                           // 000000472098: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 00000047209C: 0202ACFF 83DCD12D
	.long 0xd72c0058                                           // 0000004720A4: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 0000004720A8: 0202B0FF 83DCD12D
	.long 0xd72c0052                                           // 0000004720B0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 0000004720B4: 0202A4FF 83DCD12D
	.long 0xd72c0057                                           // 0000004720BC: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 0000004720C0: 0202AEFF 83DCD12D
	s_waitcnt vmcnt(6)                                         // 0000004720C8: BF891BF7
	v_bfe_u32 v90, v80, 12, 16                                 // 0000004720CC: D610005A 02411950
	v_bfe_u32 v91, v81, 12, 16                                 // 0000004720D4: D610005B 02411951
	v_alignbit_b32 v78, v78, v79, 16                           // 0000004720DC: D616004E 02429F4E
	v_sad_u8 v85, v85, 0, 0x6400                               // 0000004720E4: D6220055 03FD0155 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 0000004720F0: D6220056 03FD0156 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 0000004720FC: D6220058 03FD0158 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000472108: D6220052 03FD0152 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000472114: D6220057 03FD0157 00006400
	v_and_b32_e32 v85, 0xffff, v85                             // 000000472120: 36AAAAFF 0000FFFF
	v_alignbit_b32 v75, v75, v76, 16                           // 000000472128: D616004B 0242994B
	v_and_b32_e32 v88, 0xffff, v88                             // 000000472130: 36B0B0FF 0000FFFF
	v_alignbit_b32 v72, v72, v73, 16                           // 000000472138: D6160048 02429348
	v_alignbit_b32 v69, v69, v70, 16                           // 000000472140: D6160045 02428D45
	v_lshl_or_b32 v85, v86, 16, v85                            // 000000472148: D6560055 05552156
	.long 0xd72c0056                                           // 000000472150: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000472154: 0202B6FF 83DCD12D
	v_lshl_or_b32 v82, v82, 16, v88                            // 00000047215C: D6560052 05612152
	v_bfe_u32 v88, v80, 4, 16                                  // 000000472164: D6100058 02410950
	v_alignbit_b32 v51, v51, v52, 16                           // 00000047216C: D6160033 02426933
	v_pk_fma_f16 v85, v85, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472174: CC0E0055 0BFC0F55 0000C931
	v_alignbit_b32 v44, v44, v45, 16                           // 000000472180: D616002C 02425B2C
	v_pk_fma_f16 v82, v82, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472188: CC0E0052 0BFC0F52 0000C931
	v_and_b32_e32 v83, 0xffff, v83                             // 000000472194: 36A6A6FF 0000FFFF
	v_sad_u8 v86, v86, 0, 0x6400                               // 00000047219C: D6220056 03FD0156 00006400
	v_add_nc_u32_e32 v5, 1, v5                                 // 0000004721A8: 4A0A0A81
	v_add_nc_u32_e32 v48, 32, v48                              // 0000004721AC: 4A6060A0
	s_waitcnt lgkmcnt(0)                                       // 0000004721B0: BF89FC07
	v_dual_dot2acc_f32_f16 v42, v82, v1 :: v_dual_and_b32 v89, 0xffff, v84// 0000004721B4: CB240352 2A58A8FF 0000FFFF
	v_bfe_u32 v84, v84, 4, 16                                  // 0000004721C0: D6100054 02410954
	.long 0xd72c0053                                           // 0000004721C8: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000004721CC: 0202A6FF 83DCD12D
	v_bfe_u32 v82, v80, 8, 16                                  // 0000004721D4: D6100052 02411150
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004721DC: BF870214
	.long 0xd72c0059                                           // 0000004721E0: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000004721E4: 0202B2FF 83DCD12D
	.long 0xd72c0054                                           // 0000004721EC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000004721F0: 0202A8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004721F8: BF870223
	.long 0xd72c0052                                           // 0000004721FC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000472200: 0202A4FF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000472208: D6220053 03FD0153 00006400
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000472214: D6220059 03FD0159 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000472220: BF870194
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000472224: D6220054 03FD0154 00006400
	v_lshlrev_b32_e32 v83, 16, v83                             // 000000472230: 30A6A690
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000472234: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000472240: BF870194
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000472244: 30B2B290
	v_and_or_b32 v83, 0xffff, v87, v83                         // 000000472248: D6570053 054EAEFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000472254: BF870112
	v_and_or_b32 v84, 0xffff, v84, v89                         // 000000472258: D6570054 0566A8FF 0000FFFF
	v_pk_fma_f16 v83, v83, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472264: CC0E0053 0BFC0F53 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000472270: BF870092
	v_pk_fma_f16 v84, v84, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472274: CC0E0054 0BFC0F54 0000C931
	v_dot2acc_f32_f16 v42, v84, v2                             // 000000472280: 04540554
	v_bfe_u32 v84, v81, 8, 16                                  // 000000472284: D6100054 02411151
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047228C: BF8701A2
	v_dual_dot2acc_f32_f16 v42, v85, v3 :: v_dual_and_b32 v87, 0xffff, v81// 000000472290: CB240755 2A56A2FF 0000FFFF
	v_bfe_u32 v81, v81, 4, 16                                  // 00000047229C: D6100051 02410951
	.long 0xd72c0054                                           // 0000004722A4: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000004722A8: 0202A8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004722B0: BF870213
	v_dot2acc_f32_f16 v42, v83, v4                             // 0000004722B4: 04540953
	.long 0xd72c0055                                           // 0000004722B8: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 0000004722BC: 0202AEFF 83DCD12D
	.long 0xd72c0057                                           // 0000004722C4: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 0000004722C8: 0202B4FF 83DCD12D
	.long 0xd72c0051                                           // 0000004722D0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000004722D4: 0202A2FF 83DCD12D
	s_waitcnt vmcnt(3)                                         // 0000004722DC: BF890FF7
	v_bfe_u32 v83, v71, 4, 16                                  // 0000004722E0: D6100053 02410947
	v_sad_u8 v84, v84, 0, 0x6400                               // 0000004722E8: D6220054 03FD0154 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 0000004722F4: D6220055 03FD0155 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000472300: D6220057 03FD0157 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 00000047230C: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000472318: BF870193
	v_lshlrev_b32_e32 v85, 16, v85                             // 00000047231C: 30AAAA90
	v_and_b32_e32 v87, 0xffff, v87                             // 000000472320: 36AEAEFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000472328: BF870112
	v_and_or_b32 v81, 0xffff, v81, v85                         // 00000047232C: D6570051 0556A2FF 0000FFFF
	v_lshl_or_b32 v79, v82, 16, v87                            // 000000472338: D656004F 055D2152
	v_bfe_u32 v85, v78, 12, 16                                 // 000000472340: D6100055 0241194E
	v_bfe_u32 v87, v77, 8, 16                                  // 000000472348: D6100057 0241114D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000472350: BF870214
	v_pk_fma_f16 v81, v81, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472354: CC0E0051 0BFC0F51 0000C931
	v_pk_fma_f16 v79, v79, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472360: CC0E004F 0BFC0F4F 0000C931
	v_and_b32_e32 v86, 0xffff, v86                             // 00000047236C: 36ACACFF 0000FFFF
	.long 0xd72c0055                                           // 000000472374: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000472378: 0202AAFF 83DCD12D
	.long 0xd72c0057                                           // 000000472380: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000472384: 0202AEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000047238C: BF870243
	v_lshl_or_b32 v84, v84, 16, v86                            // 000000472390: D6560054 05592154
	.long 0xd72c0056                                           // 000000472398: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 00000047239C: 0202B0FF 83DCD12D
	v_and_b32_e32 v88, 0xffff, v77                             // 0000004723A4: 36B09AFF 0000FFFF
	v_sad_u8 v85, v85, 0, 0x6400                               // 0000004723AC: D6220055 03FD0155 00006400
	v_pk_fma_f16 v84, v84, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000004723B8: CC0E0054 0BFC0F54 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004723C4: BF8701A3
	.long 0xd72c0058                                           // 0000004723C8: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 0000004723CC: 0202B0FF 83DCD12D
	v_sad_u8 v82, v86, 0, 0x6400                               // 0000004723D4: D6220052 03FD0156 00006400
	v_dual_dot2acc_f32_f16 v41, v84, v1 :: v_dual_and_b32 v80, 0xffff, v80// 0000004723E0: CB240354 2950A0FF 0000FFFF
	v_bfe_u32 v84, v77, 12, 16                                 // 0000004723EC: D6100054 0241194D
	v_and_b32_e32 v85, 0xffff, v85                             // 0000004723F4: 36AAAAFF 0000FFFF
	v_bfe_u32 v77, v77, 4, 16                                  // 0000004723FC: D610004D 0241094D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000472404: BF870234
	v_dot2acc_f32_f16 v41, v81, v2                             // 000000472408: 04520551
	.long 0xd72c0050                                           // 00000047240C: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000472410: 0202A0FF 83DCD12D
	.long 0xd72c0054                                           // 000000472418: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 00000047241C: 0202A8FF 83DCD12D
	.long 0xd72c004d                                           // 000000472424: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000472428: 02029AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000472430: BF870214
	v_dot2acc_f32_f16 v41, v79, v3                             // 000000472434: 0452074F
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000472438: D6220050 03FD0150 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000472444: BF870214
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000472448: D6220054 03FD0154 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000472454: D622004D 03FD014D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000472460: BF870193
	v_lshlrev_b32_e32 v80, 16, v80                             // 000000472464: 30A0A090
	v_and_b32_e32 v84, 0xffff, v84                             // 000000472468: 36A8A8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000472470: BF870122
	v_and_or_b32 v80, 0xffff, v82, v80                         // 000000472474: D6570050 0542A4FF 0000FFFF
	v_bfe_u32 v82, v78, 8, 16                                  // 000000472480: D6100052 0241114E
	v_pk_fma_f16 v80, v80, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472488: CC0E0050 0BFC0F50 0000C931
	v_and_b32_e32 v86, 0xffff, v78                             // 000000472494: 36AC9CFF 0000FFFF
	v_bfe_u32 v78, v78, 4, 16                                  // 00000047249C: D610004E 0241094E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004724A4: BF870214
	.long 0xd72c0052                                           // 0000004724A8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 0000004724AC: 0202A4FF 83DCD12D
	v_dot2acc_f32_f16 v41, v80, v4                             // 0000004724B4: 04520950
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004724B8: BF870214
	.long 0xd72c0056                                           // 0000004724BC: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000004724C0: 0202ACFF 83DCD12D
	.long 0xd72c004e                                           // 0000004724C8: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000004724CC: 02029CFF 83DCD12D
	v_bfe_u32 v80, v74, 12, 16                                 // 0000004724D4: D6100050 0241194A
	v_sad_u8 v82, v82, 0, 0x6400                               // 0000004724DC: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004724E8: BF870232
	.long 0xd72c0050                                           // 0000004724EC: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000004724F0: 0202A0FF 83DCD12D
	v_sad_u8 v86, v86, 0, 0x6400                               // 0000004724F8: D6220056 03FD0156 00006400
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000472504: D622004E 03FD014E 00006400
	v_lshl_or_b32 v82, v82, 16, v85                            // 000000472510: D6560052 05552152
	v_sad_u8 v85, v87, 0, 0x6400                               // 000000472518: D6220055 03FD0157 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000472524: BF870194
	v_lshlrev_b32_e32 v86, 16, v86                             // 000000472528: 30ACAC90
	v_pk_fma_f16 v81, v82, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047252C: CC0E0051 0BFC0F52 0000C931
	v_sad_u8 v82, v88, 0, 0x6400                               // 000000472538: D6220052 03FD0158 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000472544: BF870214
	v_lshl_or_b32 v84, v85, 16, v84                            // 000000472548: D6560054 05512155
	v_and_or_b32 v78, 0xffff, v78, v86                         // 000000472550: D657004E 055A9CFF 0000FFFF
	v_sad_u8 v80, v80, 0, 0x6400                               // 00000047255C: D6220050 03FD0150 00006400
	v_dot2acc_f32_f16 v40, v81, v1                             // 000000472568: 04500351
	v_lshlrev_b32_e32 v76, 16, v82                             // 00000047256C: 3098A490
	v_pk_fma_f16 v79, v84, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472570: CC0E004F 0BFC0F54 0000C931
	v_pk_fma_f16 v78, v78, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047257C: CC0E004E 0BFC0F4E 0000C931
	v_bfe_u32 v81, v75, 12, 16                                 // 000000472588: D6100051 0241194B
	v_and_b32_e32 v82, 0xffff, v74                             // 000000472590: 36A494FF 0000FFFF
	v_and_or_b32 v76, 0xffff, v77, v76                         // 000000472598: D657004C 05329AFF 0000FFFF
	v_and_b32_e32 v80, 0xffff, v80                             // 0000004725A4: 36A0A0FF 0000FFFF
	v_dot2acc_f32_f16 v40, v78, v2                             // 0000004725AC: 0450054E
	.long 0xd72c004d                                           // 0000004725B0: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000004725B4: 0202A2FF 83DCD12D
	v_bfe_u32 v78, v75, 8, 16                                  // 0000004725BC: D610004E 0241114B
	v_pk_fma_f16 v76, v76, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000004725C4: CC0E004C 0BFC0F4C 0000C931
	v_bfe_u32 v81, v74, 8, 16                                  // 0000004725D0: D6100051 0241114A
	v_dot2acc_f32_f16 v40, v79, v3                             // 0000004725D8: 0450074F
	v_bfe_u32 v79, v75, 4, 16                                  // 0000004725DC: D610004F 0241094B
	v_and_b32_e32 v75, 0xffff, v75                             // 0000004725E4: 369696FF 0000FFFF
	.long 0xd72c004e                                           // 0000004725EC: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000004725F0: 02029CFF 83DCD12D
	v_sad_u8 v77, v77, 0, 0x6400                               // 0000004725F8: D622004D 03FD014D 00006400
	v_dot2acc_f32_f16 v40, v76, v4                             // 000000472604: 0450094C
	v_bfe_u32 v74, v74, 4, 16                                  // 000000472608: D610004A 0241094A
	.long 0xd72c004b                                           // 000000472610: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000472614: 020296FF 83DCD12D
	.long 0xd72c004f                                           // 00000047261C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000472620: 02029EFF 83DCD12D
	.long 0xd72c0052                                           // 000000472628: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000047262C: 0202A4FF 83DCD12D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000472634: 369A9AFF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000047263C: D622004E 03FD014E 00006400
	.long 0xd72c0051                                           // 000000472648: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 00000047264C: 0202A2FF 83DCD12D
	.long 0xd72c004a                                           // 000000472654: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000472658: 020294FF 83DCD12D
	s_waitcnt vmcnt(2)                                         // 000000472660: BF890BF7
	v_bfe_u32 v76, v68, 4, 16                                  // 000000472664: D610004C 02410944
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000047266C: D622004B 03FD014B 00006400
	v_lshl_or_b32 v77, v78, 16, v77                            // 000000472678: D656004D 0535214E
	v_sad_u8 v78, v79, 0, 0x6400                               // 000000472680: D622004E 03FD014F 00006400
	v_sad_u8 v79, v82, 0, 0x6400                               // 00000047268C: D622004F 03FD0152 00006400
	v_bfe_u32 v82, v71, 8, 16                                  // 000000472698: D6100052 02411147
	v_lshlrev_b32_e32 v75, 16, v75                             // 0000004726A0: 30969690
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000004726A4: D6220051 03FD0151 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 0000004726B0: D622004A 03FD014A 00006400
	v_lshlrev_b32_e32 v79, 16, v79                             // 0000004726BC: 309E9E90
	v_pk_fma_f16 v77, v77, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000004726C0: CC0E004D 0BFC0F4D 0000C931
	v_and_or_b32 v73, 0xffff, v78, v75                         // 0000004726CC: D6570049 052E9CFF 0000FFFF
	v_bfe_u32 v78, v72, 12, 16                                 // 0000004726D8: D610004E 02411948
	v_lshl_or_b32 v75, v81, 16, v80                            // 0000004726E0: D656004B 05412151
	v_and_or_b32 v74, 0xffff, v74, v79                         // 0000004726E8: D657004A 053E94FF 0000FFFF
	v_and_b32_e32 v79, 0xffff, v72                             // 0000004726F4: 369E90FF 0000FFFF
	v_bfe_u32 v80, v72, 8, 16                                  // 0000004726FC: D6100050 02411148
	.long 0xd72c004e                                           // 000000472704: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000472708: 02029CFF 83DCD12D
	v_bfe_u32 v72, v72, 4, 16                                  // 000000472710: D6100048 02410948
	v_bfe_u32 v81, v71, 12, 16                                 // 000000472718: D6100051 02411947
	.long 0xd72c004f                                           // 000000472720: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000472724: 02029EFF 83DCD12D
	.long 0xd72c0050                                           // 00000047272C: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000472730: 0202A0FF 83DCD12D
	.long 0xd72c0052                                           // 000000472738: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000047273C: 0202A4FF 83DCD12D
	.long 0xd72c0048                                           // 000000472744: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000472748: 020290FF 83DCD12D
	.long 0xd72c0051                                           // 000000472750: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000472754: 0202A2FF 83DCD12D
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000047275C: D622004E 03FD014E 00006400
	v_pk_fma_f16 v73, v73, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472768: CC0E0049 0BFC0F49 0000C931
	v_dot2acc_f32_f16 v39, v77, v1                             // 000000472774: 044E034D
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000472778: D622004F 03FD014F 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000472784: D6220050 03FD0150 00006400
	v_and_b32_e32 v78, 0xffff, v78                             // 000000472790: 369C9CFF 0000FFFF
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000472798: D6220048 03FD0148 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000004727A4: D6220051 03FD0151 00006400
	v_lshlrev_b32_e32 v79, 16, v79                             // 0000004727B0: 309E9E90
	v_pk_fma_f16 v75, v75, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000004727B4: CC0E004B 0BFC0F4B 0000C931
	v_lshl_or_b32 v77, v80, 16, v78                            // 0000004727C0: D656004D 05392150
	v_sad_u8 v80, v82, 0, 0x6400                               // 0000004727C8: D6220050 03FD0152 00006400
	v_dot2acc_f32_f16 v39, v73, v2                             // 0000004727D4: 044E0549
	v_and_or_b32 v72, 0xffff, v72, v79                         // 0000004727D8: D6570048 053E90FF 0000FFFF
	v_and_b32_e32 v79, 0xffff, v81                             // 0000004727E4: 369EA2FF 0000FFFF
	v_pk_fma_f16 v73, v77, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000004727EC: CC0E0049 0BFC0F4D 0000C931
	v_pk_fma_f16 v74, v74, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000004727F8: CC0E004A 0BFC0F4A 0000C931
	v_dot2acc_f32_f16 v39, v75, v3                             // 000000472804: 044E074B
	v_pk_fma_f16 v72, v72, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472808: CC0E0048 0BFC0F48 0000C931
	v_lshl_or_b32 v77, v80, 16, v79                            // 000000472814: D656004D 053D2150
	v_dot2acc_f32_f16 v38, v73, v1                             // 00000047281C: 044C0349
	v_bfe_u32 v75, v68, 8, 16                                  // 000000472820: D610004B 02411144
	v_dot2acc_f32_f16 v39, v74, v4                             // 000000472828: 044E094A
	v_bfe_u32 v74, v68, 12, 16                                 // 00000047282C: D610004A 02411944
	v_pk_fma_f16 v70, v77, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472834: CC0E0046 0BFC0F4D 0000C931
	v_dot2acc_f32_f16 v38, v72, v2                             // 000000472840: 044C0548
	v_bfe_u32 v72, v69, 12, 16                                 // 000000472844: D6100048 02411945
	v_and_b32_e32 v68, 0xffff, v68                             // 00000047284C: 368888FF 0000FFFF
	v_and_b32_e32 v73, 0xffff, v69                             // 000000472854: 36928AFF 0000FFFF
	.long 0xd72c004c                                           // 00000047285C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000472860: 020298FF 83DCD12D
	v_dot2acc_f32_f16 v38, v70, v3                             // 000000472868: 044C0746
	v_bfe_u32 v70, v69, 8, 16                                  // 00000047286C: D6100046 02411145
	.long 0xd72c0048                                           // 000000472874: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000472878: 020290FF 83DCD12D
	.long 0xd72c0044                                           // 000000472880: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000472884: 020288FF 83DCD12D
	v_bfe_u32 v69, v69, 4, 16                                  // 00000047288C: D6100045 02410945
	.long 0xd72c0049                                           // 000000472894: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000472898: 020292FF 83DCD12D
	.long 0xd72c0046                                           // 0000004728A0: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 0000004728A4: 02028CFF 83DCD12D
	.long 0xd72c004a                                           // 0000004728AC: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 0000004728B0: 020294FF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000004728B8: D622004C 03FD014C 00006400
	.long 0xd72c0045                                           // 0000004728C4: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 0000004728C8: 02028AFF 83DCD12D
	v_sad_u8 v72, v72, 0, 0x6400                               // 0000004728D0: D6220048 03FD0148 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 0000004728DC: D6220044 03FD0144 00006400
	.long 0xd72c004b                                           // 0000004728E8: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 0000004728EC: 020296FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000004728F4: D6220049 03FD0149 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000472900: D6220046 03FD0146 00006400
	v_and_b32_e32 v72, 0xffff, v72                             // 00000047290C: 369090FF 0000FFFF
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000472914: 30888890
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000472918: D622004A 03FD014A 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000472924: D6220045 03FD0145 00006400
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000472930: 30929290
	v_lshl_or_b32 v70, v70, 16, v72                            // 000000472934: D6560046 05212146
	v_and_or_b32 v52, 0xffff, v76, v68                         // 00000047293C: D6570034 051298FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000472948: D622004B 03FD014B 00006400
	.long 0xd72c004e                                           // 000000472954: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000472958: 0202A6FF 83DCD12D
	v_and_or_b32 v69, 0xffff, v69, v73                         // 000000472960: D6570045 05268AFF 0000FFFF
	v_pk_fma_f16 v68, v70, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047296C: CC0E0044 0BFC0F46 0000C931
	v_pk_fma_f16 v52, v52, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472978: CC0E0034 0BFC0F34 0000C931
	v_and_b32_e32 v74, 0xffff, v74                             // 000000472984: 369494FF 0000FFFF
	s_waitcnt vmcnt(1)                                         // 00000047298C: BF8907F7
	v_bfe_u32 v73, v50, 12, 16                                 // 000000472990: D6100049 02411932
	v_pk_fma_f16 v69, v69, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472998: CC0E0045 0BFC0F45 0000C931
	v_dual_dot2acc_f32_f16 v37, v68, v1 :: v_dual_and_b32 v68, 0xffff, v51// 0000004729A4: CB240344 254466FF 0000FFFF
	v_lshl_or_b32 v72, v75, 16, v74                            // 0000004729B0: D6560048 0529214B
	v_bfe_u32 v74, v51, 8, 16                                  // 0000004729B8: D610004A 02411133
	.long 0xd72c0049                                           // 0000004729C0: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 0000004729C4: 020292FF 83DCD12D
	v_bfe_u32 v75, v50, 8, 16                                  // 0000004729CC: D610004B 02411132
	.long 0xd72c0044                                           // 0000004729D4: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 0000004729D8: 020288FF 83DCD12D
	v_pk_fma_f16 v70, v72, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000004729E0: CC0E0046 0BFC0F48 0000C931
	v_bfe_u32 v72, v51, 12, 16                                 // 0000004729EC: D6100048 02411933
	v_bfe_u32 v51, v51, 4, 16                                  // 0000004729F4: D6100033 02410933
	v_dot2acc_f32_f16 v37, v69, v2                             // 0000004729FC: 044A0545
	.long 0xd72c0045                                           // 000000472A00: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000472A04: 020296FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000472A0C: D6220049 03FD0149 00006400
	.long 0xd72c0048                                           // 000000472A18: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000472A1C: 020290FF 83DCD12D
	.long 0xd72c0033                                           // 000000472A24: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000472A28: 020266FF 83DCD12D
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000472A30: D6220044 03FD0144 00006400
	.long 0xd72c004a                                           // 000000472A3C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000472A40: 020294FF 83DCD12D
	v_and_b32_e32 v73, 0xffff, v73                             // 000000472A48: 369292FF 0000FFFF
	v_dot2acc_f32_f16 v37, v70, v3                             // 000000472A50: 044A0746
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000472A54: D6220045 03FD0145 00006400
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000472A60: 30888890
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000472A64: D6220048 03FD0148 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000472A70: D6220033 03FD0133 00006400
	v_bfe_u32 v70, v44, 12, 16                                 // 000000472A7C: D6100046 0241192C
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000472A84: D622004A 03FD014A 00006400
	v_bfe_u32 v75, v50, 4, 16                                  // 000000472A90: D610004B 02410932
	v_and_b32_e32 v72, 0xffff, v72                             // 000000472A98: 369090FF 0000FFFF
	v_and_or_b32 v51, 0xffff, v51, v68                         // 000000472AA0: D6570033 051266FF 0000FFFF
	v_lshl_or_b32 v68, v69, 16, v73                            // 000000472AAC: D6560044 05252145
	.long 0xd72c0046                                           // 000000472AB4: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000472AB8: 02028CFF 83DCD12D
	v_bfe_u32 v73, v44, 8, 16                                  // 000000472AC0: D6100049 0241112C
	v_and_b32_e32 v50, 0xffff, v50                             // 000000472AC8: 366464FF 0000FFFF
	v_lshl_or_b32 v72, v74, 16, v72                            // 000000472AD0: D6560048 0521214A
	s_waitcnt vmcnt(0)                                         // 000000472AD8: BF8903F7
	v_bfe_u32 v74, v43, 12, 16                                 // 000000472ADC: D610004A 0241192B
	.long 0xd72c0045                                           // 000000472AE4: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000472AE8: 020296FF 83DCD12D
	.long 0xd72c0049                                           // 000000472AF0: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000472AF4: 020292FF 83DCD12D
	.long 0xd72c002d                                           // 000000472AFC: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000472B00: 020264FF 83DCD12D
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000472B08: D6220046 03FD0146 00006400
	v_bfe_u32 v75, v43, 8, 16                                  // 000000472B14: D610004B 0241112B
	.long 0xd72c004a                                           // 000000472B1C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000472B20: 020294FF 83DCD12D
	v_pk_fma_f16 v50, v72, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472B28: CC0E0032 0BFC0F48 0000C931
	v_pk_fma_f16 v51, v51, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472B34: CC0E0033 0BFC0F33 0000C931
	v_and_b32_e32 v70, 0xffff, v70                             // 000000472B40: 368C8CFF 0000FFFF
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000472B48: D6220049 03FD0149 00006400
	.long 0xd72c004b                                           // 000000472B54: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000472B58: 020296FF 83DCD12D
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000472B60: D622002D 03FD012D 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000472B6C: D6220045 03FD0145 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000472B78: D622004A 03FD014A 00006400
	v_lshl_or_b32 v70, v73, 16, v70                            // 000000472B84: D6560046 05192149
	v_dot2acc_f32_f16 v36, v50, v1                             // 000000472B8C: 04480332
	v_lshlrev_b32_e32 v45, 16, v45                             // 000000472B90: 305A5A90
	v_pk_fma_f16 v68, v68, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472B94: CC0E0044 0BFC0F44 0000C931
	v_and_b32_e32 v73, 0xffff, v74                             // 000000472BA0: 369294FF 0000FFFF
	v_sad_u8 v74, v75, 0, 0x6400                               // 000000472BA8: D622004A 03FD014B 00006400
	v_pk_fma_f16 v50, v70, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472BB4: CC0E0032 0BFC0F46 0000C931
	v_dot2acc_f32_f16 v36, v51, v2                             // 000000472BC0: 04480533
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000472BC4: D622004E 03FD014E 00006400
	v_and_b32_e32 v72, 0xffff, v44                             // 000000472BD0: 369058FF 0000FFFF
	v_lshl_or_b32 v70, v74, 16, v73                            // 000000472BD8: D6560046 0525214A
	v_dual_dot2acc_f32_f16 v35, v50, v1 :: v_dual_mov_b32 v74, v31// 000000472BE0: CB100332 234A011F
	v_and_or_b32 v1, 0xffff, v69, v45                          // 000000472BE8: D6570001 04B68AFF 0000FFFF
	v_dot2acc_f32_f16 v36, v68, v3                             // 000000472BF4: 04480744
	v_mov_b32_e32 v50, v25                                     // 000000472BF8: 7E640319
	v_bfe_u32 v44, v44, 4, 16                                  // 000000472BFC: D610002C 0241092C
	v_bfe_u32 v76, v43, 4, 16                                  // 000000472C04: D610004C 0241092B
	v_pk_fma_f16 v1, v1, s7, 0xc931 op_sel_hi:[1,0,0]          // 000000472C0C: CC0E0001 0BFC0F01 0000C931
	v_and_b32_e32 v71, 0xffff, v71                             // 000000472C18: 368E8EFF 0000FFFF
	v_and_b32_e32 v43, 0xffff, v43                             // 000000472C20: 365656FF 0000FFFF
	.long 0xd72c002c                                           // 000000472C28: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000472C2C: 020258FF 83DCD12D
	v_pk_fma_f16 v45, v70, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472C34: CC0E002D 0BFC0F46 0000C931
	v_dot2acc_f32_f16 v36, v1, v4                              // 000000472C40: 04480901
	.long 0xd72c0047                                           // 000000472C44: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000472C48: 02028EFF 83DCD12D
	.long 0xd72c002b                                           // 000000472C50: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000472C54: 020256FF 83DCD12D
	v_dual_mov_b32 v80, v33 :: v_dual_dot2acc_f32_f16 v37, v52, v4// 000000472C5C: CA180121 50240934
	v_mov_b32_e32 v52, v20                                     // 000000472C64: 7E680314
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000472C68: D622002C 03FD012C 00006400
	v_dual_mov_b32 v51, v13 :: v_dual_mov_b32 v68, v27         // 000000472C74: CA10010D 3344011B
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000472C7C: D6220047 03FD0147 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000472C88: D622002B 03FD012B 00006400
	v_dual_mov_b32 v70, v21 :: v_dual_mov_b32 v69, v14         // 000000472C94: CA100115 4644010E
	v_mov_b32_e32 v73, v22                                     // 000000472C9C: 7E920316
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000472CA0: BF870214
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000472CA4: 308E8E90
	v_lshlrev_b32_e32 v43, 16, v43                             // 000000472CA8: 30565690
	v_mov_b32_e32 v77, v32                                     // 000000472CAC: 7E9A0320
	v_mov_b32_e32 v79, v26                                     // 000000472CB0: 7E9E031A
	v_dual_mov_b32 v81, v18 :: v_dual_mov_b32 v20, v61         // 000000472CB4: CA100112 5114013D
	v_and_or_b32 v71, 0xffff, v78, v71                         // 000000472CBC: D6570047 051E9CFF 0000FFFF
	v_dual_mov_b32 v75, v16 :: v_dual_mov_b32 v78, v17         // 000000472CC8: CA100110 4B4E0111
	v_dual_mov_b32 v83, v34 :: v_dual_mov_b32 v22, v63         // 000000472CD0: CA100122 5316013F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000472CD8: BF870243
	v_pk_fma_f16 v71, v71, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472CDC: CC0E0047 0BFC0F47 0000C931
	v_dual_mov_b32 v25, v61 :: v_dual_mov_b32 v16, v56         // 000000472CE8: CA10013D 19100138
	v_mov_b32_e32 v13, v53                                     // 000000472CF0: 7E1A0335
	v_dual_mov_b32 v27, v62 :: v_dual_mov_b32 v32, v65         // 000000472CF4: CA10013E 1B200141
	v_dual_dot2acc_f32_f16 v38, v71, v4 :: v_dual_mov_b32 v71, v29// 000000472CFC: CB100947 2646011D
	.long 0xd72c0048                                           // 000000472D04: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000472D08: 020290FF 83DCD12D
	v_dual_mov_b32 v21, v62 :: v_dual_mov_b32 v26, v65         // 000000472D10: CA10013E 151A0141
	v_dual_mov_b32 v29, v63 :: v_dual_mov_b32 v18, v60         // 000000472D18: CA10013F 1D12013C
	v_dual_mov_b32 v31, v64 :: v_dual_mov_b32 v34, v67         // 000000472D20: CA100140 1F220143
	v_mov_b32_e32 v82, v28                                     // 000000472D28: 7EA4031C
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000472D2C: D6220048 03FD0148 00006400
	v_dual_mov_b32 v14, v54 :: v_dual_mov_b32 v17, v57         // 000000472D38: CA100136 0E100139
	v_mov_b32_e32 v33, v66                                     // 000000472D40: 7E420342
	v_mov_b32_e32 v28, v66                                     // 000000472D44: 7E380342
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000472D48: BF870094
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000472D4C: 30909090
	v_and_or_b32 v44, 0xffff, v44, v72                         // 000000472D50: D657002C 052258FF 0000FFFF
	.long 0xd72c0048                                           // 000000472D5C: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000472D60: 020298FF 83DCD12D
	v_mov_b32_e32 v76, v24                                     // 000000472D68: 7E980318
	v_mov_b32_e32 v24, v64                                     // 000000472D6C: 7E300340
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000472D70: BF870214
	v_pk_fma_f16 v44, v44, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000472D74: CC0E002C 0BFC0F2C 0000C931
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000472D80: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000472D8C: BF870232
	v_dot2acc_f32_f16 v35, v44, v2                             // 000000472D90: 0446052C
	v_mov_b32_e32 v44, v12                                     // 000000472D94: 7E58030C
	v_mov_b32_e32 v12, v6                                      // 000000472D98: 7E180306
	v_and_or_b32 v43, 0xffff, v72, v43                         // 000000472D9C: D657002B 04AE90FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000472DA8: BF870004
	v_dot2acc_f32_f16 v35, v45, v3                             // 000000472DAC: 0446072D
	v_add_nc_u32_e32 v3, v46, v5                               // 000000472DB0: 4A060B2E
	v_mov_b32_e32 v45, v19                                     // 000000472DB4: 7E5A0313
	v_mov_b32_e32 v72, v15                                     // 000000472DB8: 7E90030F
	v_pk_fma_f16 v2, v43, s7, 0xc931 op_sel_hi:[1,0,0]         // 000000472DBC: CC0E0002 0BFC0F2B 0000C931
	v_mov_b32_e32 v43, v23                                     // 000000472DC8: 7E560317
	v_cmp_eq_u32_e32 vcc_lo, 2, v3                             // 000000472DCC: 7C940682
	v_mov_b32_e32 v3, v30                                      // 000000472DD0: 7E06031E
	v_mov_b32_e32 v23, v59                                     // 000000472DD4: 7E2E033B
	v_dual_dot2acc_f32_f16 v35, v2, v4 :: v_dual_mov_b32 v2, v11// 000000472DD8: CB100902 2302010B
	v_mov_b32_e32 v19, v59                                     // 000000472DE0: 7E26033B
	v_mov_b32_e32 v15, v55                                     // 000000472DE4: 7E1E0337
	v_dual_mov_b32 v30, v67 :: v_dual_mov_b32 v11, v58         // 000000472DE8: CA100143 1E0A013A
	s_or_b32 s6, vcc_lo, s6                                    // 000000472DF0: 8C06066A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000472DF4: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000472DF8: 917E067E
	s_cbranch_execz 56                                         // 000000472DFC: BFA50038 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ae0>
	s_mov_b32 s8, exec_lo                                      // 000000472E00: BE88007E
	.long 0xd4c1007e                                           // 000000472E04: D4C1007E
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000472E08: 02020F05
	s_cbranch_execz 64651                                      // 000000472E0C: BFA5FC8B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc3c>
	v_ashrrev_i32_e32 v6, 31, v5                               // 000000472E10: 340C0A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000472E14: BF870091
	.long 0xd73c0035                                           // 000000472E18: D73C0035
	v_cndmask_b32_e32 v1, 10, v5, vcc_lo                       // 000000472E1C: 02020A8A
	.long 0xd7006a01                                           // 000000472E20: D7006A01
	v_cndmask_b32_e32 v1, s1, v53, vcc_lo                      // 000000472E24: 02026A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000472E28: BF870111
	v_add_co_ci_u32_e64 v4, null, s5, v54, vcc_lo              // 000000472E2C: D5207C04 01AA6C05
	.long 0xd7006a3d                                           // 000000472E34: D7006A3D
	v_cndmask_b32_e32 v1, v1, v49, vcc_lo                      // 000000472E38: 02026301
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000472E3C: BF8700A1
	v_add_co_ci_u32_e64 v62, null, 0, v4, vcc_lo               // 000000472E40: D5207C3E 01AA0880
	.long 0xd7006a54                                           // 000000472E48: D7006A54
	v_cndmask_b32_e32 v1, v1, v47, vcc_lo                      // 000000472E4C: 02025F01
	v_add_co_ci_u32_e64 v85, null, 0, v4, vcc_lo               // 000000472E50: D5207C55 01AA0880
	s_clause 0xf                                               // 000000472E58: BF85000F
	global_load_b32 v58, v[61:62], off                         // 000000472E5C: DC520000 3A7C003D
	global_load_b32 v60, v[61:62], off offset:128              // 000000472E64: DC520080 3C7C003D
	global_load_b32 v57, v[61:62], off offset:256              // 000000472E6C: DC520100 397C003D
	global_load_b32 v56, v[61:62], off offset:384              // 000000472E74: DC520180 387C003D
	global_load_b32 v55, v[61:62], off offset:512              // 000000472E7C: DC520200 377C003D
	global_load_b32 v54, v[61:62], off offset:640              // 000000472E84: DC520280 367C003D
	global_load_b32 v53, v[61:62], off offset:768              // 000000472E8C: DC520300 357C003D
	global_load_b32 v6, v[61:62], off offset:896               // 000000472E94: DC520380 067C003D
	global_load_b32 v67, v[84:85], off                         // 000000472E9C: DC520000 437C0054
	global_load_b32 v66, v[84:85], off offset:128              // 000000472EA4: DC520080 427C0054
	global_load_b32 v65, v[84:85], off offset:256              // 000000472EAC: DC520100 417C0054
	global_load_b32 v64, v[84:85], off offset:384              // 000000472EB4: DC520180 407C0054
	global_load_b32 v63, v[84:85], off offset:512              // 000000472EBC: DC520200 3F7C0054
	global_load_b32 v62, v[84:85], off offset:640              // 000000472EC4: DC520280 3E7C0054
	global_load_b32 v61, v[84:85], off offset:768              // 000000472ECC: DC520300 3D7C0054
	global_load_b32 v59, v[84:85], off offset:896              // 000000472ED4: DC520380 3B7C0054
	s_branch 64599                                             // 000000472EDC: BFA0FC57 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc3c>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000472EE0: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000472EE4: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000472EE8: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 000000472EEC: BF895FF7
	v_dual_mov_b32 v1, v42 :: v_dual_mov_b32 v2, v41           // 000000472EF0: CA10012A 01020129
	s_waitcnt vmcnt(15)                                        // 000000472EF8: BF893FF7
	v_dual_mov_b32 v3, v40 :: v_dual_mov_b32 v4, v38           // 000000472EFC: CA100128 03040126
	v_dual_mov_b32 v7, v39 :: v_dual_mov_b32 v6, v36           // 000000472F04: CA100127 07060124
	v_mov_b32_e32 v5, v37                                      // 000000472F0C: 7E0A0325
	v_mov_b32_e32 v11, v35                                     // 000000472F10: 7E160323
	s_mov_b32 s0, 0x76543210                                   // 000000472F14: BE8000FF 76543210
	s_waitcnt vmcnt(0)                                         // 000000472F1C: BF8903F7
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000472F20: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000472F2C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000472F38: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000472F44: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000472F50: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000472F5C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000472F68: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000472F74: D65C000B 03FC010B FEDCBA98
	.long 0xd44c0000                                           // 000000472F80: D44C0000
	v_cndmask_b32_e32 v1, 16, v10, vcc_lo                      // 000000472F84: 02021490
	s_barrier                                                  // 000000472F88: BFBD0000
	buffer_gl0_inv                                             // 000000472F8C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000472F94: BE812000
	s_cbranch_execz 18                                         // 000000472F98: BFA50012 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1be4>
	v_dual_add_f32 v10, v35, v11 :: v_dual_add_f32 v1, v42, v1 // 000000472F9C: C9081723 0A00032A
	v_dual_add_f32 v2, v41, v2 :: v_dual_add_f32 v3, v40, v3   // 000000472FA4: C9080529 02020728
	v_lshl_or_b32 v9, v8, 9, v9                                // 000000472FAC: D6560009 04251308
	v_dual_add_f32 v7, v39, v7 :: v_dual_add_f32 v4, v38, v4   // 000000472FB4: C9080F27 07040926
	v_dual_add_f32 v5, v37, v5 :: v_dual_add_f32 v6, v36, v6   // 000000472FBC: C9080B25 05060D24
	ds_store_2addr_b32 v9, v1, v2 offset1:16                   // 000000472FC4: D8381000 00020109
	ds_store_2addr_b32 v9, v3, v7 offset0:32 offset1:48        // 000000472FCC: D8383020 00070309
	ds_store_2addr_b32 v9, v4, v5 offset0:64 offset1:80        // 000000472FD4: D8385040 00050409
	ds_store_2addr_b32 v9, v6, v10 offset0:96 offset1:112      // 000000472FDC: D8387060 000A0609
	s_or_b32 exec_lo, exec_lo, s1                              // 000000472FE4: 8C7E017E
	.long 0xd44c0001                                           // 000000472FE8: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000472FEC: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000472FF4: BF89FC07
	s_barrier                                                  // 000000472FF8: BFBD0000
	buffer_gl0_inv                                             // 000000472FFC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000473004: BE852001
	s_cbranch_execnz 7                                         // 000000473008: BFA60007 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c28>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000047300C: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 000000473010: BF048221
	s_mov_b32 s5, -1                                           // 000000473014: BE8500C1
	s_cbranch_scc0 33                                          // 000000473018: BFA10021 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ca0>
	s_and_b32 vcc_lo, exec_lo, s5                              // 00000047301C: 8B6A057E
	s_cbranch_vccnz 154                                        // 000000473020: BFA4009A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e8c>
	s_endpgm                                                   // 000000473024: BFB00000
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000473028: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:2            // 00000047302C: D8E00200 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:4 offset1:6  // 000000473034: D8E00604 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:8 offset1:10 // 00000047303C: D8E00A08 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000473044: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000473048: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000047304C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000473050: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000473054: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000473058: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:12 offset1:14// 00000047305C: D8E00E0C 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000473064: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000473068: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047306C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000473070: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000473074: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000473078: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047307C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000473080: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000473084: 06020501
	ds_store_b32 v7, v1 offset:4096                            // 000000473088: D8341000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 000000473090: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 000000473094: BF048221
	s_mov_b32 s5, -1                                           // 000000473098: BE8500C1
	s_cbranch_scc1 65503                                       // 00000047309C: BFA2FFDF <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c1c>
	s_waitcnt lgkmcnt(0)                                       // 0000004730A0: BF89FC07
	s_barrier                                                  // 0000004730A4: BFBD0000
	buffer_gl0_inv                                             // 0000004730A8: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 0000004730B0: BE852001
	s_cbranch_execz 17                                         // 0000004730B4: BFA50011 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1cfc>
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000004730B8: 30020082
	s_mul_hi_i32 s7, s26, s4                                   // 0000004730BC: 9707041A
	s_mul_i32 s6, s26, s4                                      // 0000004730C0: 9606041A
	s_lshl_b32 s8, s2, 7                                       // 0000004730C4: 84088702
	s_lshl_b64 s[6:7], s[6:7], 2                               // 0000004730C8: 84868206
	ds_load_b32 v2, v1 offset:4096                             // 0000004730CC: D8D81000 02000001
	s_ashr_i32 s9, s8, 31                                      // 0000004730D4: 86099F08
	s_add_u32 s4, s16, s6                                      // 0000004730D8: 80040610
	s_addc_u32 s10, s17, s7                                    // 0000004730DC: 820A0711
	s_lshl_b64 s[6:7], s[8:9], 2                               // 0000004730E0: 84868208
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004730E4: BF870009
	s_add_u32 s6, s4, s6                                       // 0000004730E8: 80060604
	s_addc_u32 s7, s10, s7                                     // 0000004730EC: 8207070A
	s_waitcnt lgkmcnt(0)                                       // 0000004730F0: BF89FC07
	global_store_b32 v1, v2, s[6:7]                            // 0000004730F4: DC6A0000 00060201
	s_or_b32 exec_lo, exec_lo, s5                              // 0000004730FC: 8C7E057E
	.long 0xd44a0004                                           // 000000473100: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000473104: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000473108: BC7C0000
	buffer_gl1_inv                                             // 00000047310C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000473114: E0AC0000 00000000
	s_barrier                                                  // 00000047311C: BFBD0000
	buffer_gl0_inv                                             // 000000473120: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000473128: BE852004
	s_cbranch_execz 29                                         // 00000047312C: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1da4>
	s_mov_b32 s7, exec_lo                                      // 000000473130: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000473134: BE86007E
	.long 0xd71f0001                                           // 000000473138: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 00000047313C: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000473140: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000473144: 7D940280
	s_cbranch_execz 9                                          // 000000473148: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d70>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 00000047314C: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000473150: BF8704B9
	s_add_u32 s8, s18, s8                                      // 000000473154: 80080812
	s_addc_u32 s9, s19, s9                                     // 000000473158: 82090913
	s_bcnt1_i32_b32 s7, s7                                     // 00000047315C: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 000000473160: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 000000473168: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 000000473170: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000473174: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 000000473178: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047317C: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 000000473180: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 000000473188: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000047318C: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 000000473190: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000473194: D5010001 01A90280
	ds_store_b32 v2, v1 offset:5120                            // 00000047319C: D8341400 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 0000004731A4: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 0000004731A8: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000004731AC: BF89FC07
	s_barrier                                                  // 0000004731B0: BFBD0000
	buffer_gl0_inv                                             // 0000004731B4: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:5120                             // 0000004731BC: D8D81400 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000004731C4: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000004731C8: 7C940280
	s_cbranch_vccnz 46                                         // 0000004731CC: BFA4002E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e88>
	buffer_gl1_inv                                             // 0000004731D0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000004731D8: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 0000004731E0: BE852001
	s_cbranch_execz 28                                         // 0000004731E4: BFA5001C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e58>
	s_lshl_b32 s6, s2, 7                                       // 0000004731E8: 84068702
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 0000004731EC: CA220080 04020082
	s_ashr_i32 s7, s6, 31                                      // 0000004731F4: 86079F06
	s_ashr_i32 s27, s26, 31                                    // 0000004731F8: 861B9F1A
	s_lshl_b64 s[6:7], s[6:7], 2                               // 0000004731FC: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000473200: BF8700B9
	s_add_u32 s1, s16, s6                                      // 000000473204: 80010610
	s_addc_u32 s6, s17, s7                                     // 000000473208: 82060711
	.long 0xd7000101                                           // 00000047320C: D7000101
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 000000473210: 02020601
	v_add_co_ci_u32_e64 v2, null, s6, 0, s1                    // 000000473214: D5207C02 00050006
	s_lshl_b64 s[6:7], s[26:27], 2                             // 00000047321C: 8486821A
	global_load_b32 v5, v[1:2], off glc                        // 000000473220: DC524000 057C0001
	.long 0xd7006a01                                           // 000000473228: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 00000047322C: 02000D01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000473230: BF8704A1
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000473234: D5207C02 01AA0407
	s_add_i32 s33, s33, -1                                     // 00000047323C: 8121C121
	s_cmp_eq_u32 s33, 0                                        // 000000473240: BF068021
	s_waitcnt vmcnt(0)                                         // 000000473244: BF8903F7
	v_add_f32_e32 v4, v4, v5                                   // 000000473248: 06080B04
	s_cbranch_scc0 65524                                       // 00000047324C: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e20>
	ds_store_b32 v3, v4 offset:4096                            // 000000473250: D8341000 00000403
	s_or_b32 exec_lo, exec_lo, s5                              // 000000473258: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 00000047325C: BE812004
	s_cbranch_execz 6                                          // 000000473260: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e7c>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 000000473264: 84848202
	v_mov_b32_e32 v1, 0                                        // 000000473268: 7E020280
	s_add_u32 s4, s18, s4                                      // 00000047326C: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000473270: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 000000473274: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 00000047327C: 8C7E017E
	s_cbranch_execz 65384                                      // 000000473280: BFA5FF68 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c24>
	s_branch 1                                                 // 000000473284: BFA00001 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e8c>
	s_branch 65382                                             // 000000473288: BFA0FF66 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c24>
	v_cmp_eq_u32_e32 vcc_lo, 0, v8                             // 00000047328C: 7C941080
	s_cmp_gt_i32 s24, 0                                        // 000000473290: BF028018
	s_waitcnt lgkmcnt(0)                                       // 000000473294: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000473298: BC7C0000
	s_cselect_b32 s1, -1, 0                                    // 00000047329C: 980180C1
	s_barrier                                                  // 0000004732A0: BFBD0000
	s_and_b32 s1, vcc_lo, s1                                   // 0000004732A4: 8B01016A
	buffer_gl0_inv                                             // 0000004732A8: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 0000004732B0: BE832001
	s_cbranch_execz 65371                                      // 0000004732B4: BFA5FF5B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c24>
	v_and_b32_e32 v1, 15, v0                                   // 0000004732B8: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004732BC: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000004732C0: 30040282
	v_add_nc_u32_e32 v8, 0x1000, v2                            // 0000004732C4: 4A1004FF 00001000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000004732CC: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000004732D4: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000004732DC: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000004732E4: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000004732EC: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000004732F0: 36160082
	s_waitcnt lgkmcnt(3)                                       // 0000004732F4: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 0000004732F8: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000473300: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000473304: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000047330C: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000473310: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000473318: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 00000047331C: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000473324: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 00000047332C: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000473330: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000473334: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 00000047333C: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000473344: 7C941480
	.long 0xd44a0001                                           // 000000473348: D44A0001
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 00000047334C: 02021680
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000473350: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000473358: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 00000047335C: 08101D09
	.long 0xd44a0003                                           // 000000473360: D44A0003
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000473364: 02021880
	s_delay_alu instid0(VALU_DEP_3)                            // 000000473368: BF870003
	v_dual_add_f32 v9, v13, v4 :: v_dual_sub_f32 v10, v2, v6   // 00000047336C: C90A090D 090A0D02
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000473374: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000047337C: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000473380: 060A0D02
	v_mov_b32_dpp v2, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000473384: 7E0402FA FF016107
	v_cndmask_b32_e64 v6, -v7, v7, vcc_lo                      // 00000047338C: D5010006 21AA0F07
	v_mov_b32_dpp v7, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000473394: 7E0E02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000047339C: D5010009 21AA1309
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004733A4: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004733AC: D5010005 21AA0B05
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004733B4: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000004733BC: D501000D 21AA1B0D
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004733C4: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000004733CC: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004733D4: 7E2202FA FF016104
	v_cndmask_b32_e64 v18, -v4, v4, vcc_lo                     // 0000004733DC: D5010012 21AA0904
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004733E4: 7E2602FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 0000004733EC: D5010014 21AA0703
	v_dual_add_f32 v3, v9, v7 :: v_dual_add_f32 v2, v6, v2     // 0000004733F4: C9080F09 03020506
	v_dual_add_f32 v4, v5, v15 :: v_dual_add_f32 v7, v8, v16   // 0000004733FC: C9081F05 04062108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000473404: BF870192
	v_cndmask_b32_e64 v8, -v3, v3, s1                          // 000000473408: D5010008 20060703
	v_mov_b32_dpp v6, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000473410: 7E0C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000473418: D5010002 20060502
	v_mov_b32_dpp v3, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000473420: 7E0602FA FF016203
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000473428: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000473430: D5010004 20060904
	v_add_f32_e32 v5, v13, v14                                 // 000000473438: 060A1D0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000047343C: BF870224
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v8, v3     // 000000473440: C9080D02 02020708
	v_mov_b32_dpp v13, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000473448: 7E1A02FA FF016207
	v_add_f32_e32 v4, v4, v11                                  // 000000473450: 06081704
	s_delay_alu instid0(VALU_DEP_4)                            // 000000473454: BF870004
	v_mov_b32_dpp v9, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000473458: 7E1202FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000473460: D5010005 20060B05
	v_mov_b32_dpp v6, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000473468: 7E0C02FA FF016402
	v_cndmask_b32_e64 v8, -v3, v3, s3                          // 000000473470: D5010008 200E0703
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000473478: D5010002 200E0502
	v_mov_b32_dpp v11, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000473480: 7E1602FA FF016403
	v_add_f32_e32 v5, v5, v9                                   // 000000473488: 060A1305
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047348C: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000473494: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047349C: BF870214
	v_dual_add_f32 v3, v2, v6 :: v_dual_add_f32 v6, v8, v11    // 0000004734A0: C9080D02 03061708
	v_mov_b32_dpp v8, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004734A8: 7E1002FA FF016405
	v_cndmask_b32_e64 v11, -v5, v5, s3                         // 0000004734B0: D501000B 200E0B05
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004734B8: BF870004
	v_add_f32_e32 v4, v4, v9                                   // 0000004734BC: 06081304
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004734C0: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000004734C8: D501000A 21AA150A
	v_add_f32_e32 v12, v18, v17                                // 0000004734D0: 06182312
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000004734D4: D5010007 20060F07
	v_add_f32_e32 v14, v20, v19                                // 0000004734DC: 061C2714
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004734E0: 7E0402FA FF016803
	v_add_f32_e32 v9, v10, v9                                  // 0000004734E8: 0612130A
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004734EC: 7E0A02FA FF016806
	v_add_f32_e32 v13, v7, v13                                 // 0000004734F4: 061A1B07
	v_mov_b32_dpp v15, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004734F8: 7E1E02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000473500: D501000E 20061D0E
	v_mov_b32_dpp v16, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000473508: 7E2002FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000473510: D5010009 20061309
	v_add_f32_e32 v7, v11, v8                                  // 000000473518: 060E110B
	v_mov_b32_dpp v10, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047351C: 7E1402FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000473524: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047352C: BF870114
	v_dual_add_f32 v8, v14, v15 :: v_dual_add_f32 v9, v9, v16  // 000000473530: C9081F0E 08082109
	v_add_f32_e32 v10, v12, v10                                // 000000473538: 0614150C
	v_mov_b32_dpp v11, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047353C: 7E1602FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000473544: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047354C: BF870004
	v_mov_b32_dpp v15, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000473550: 7E1E02FA FF016408
	v_mov_b32_dpp v17, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000473558: 7E2202FA FF016409
	v_mov_b32_dpp v12, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000473560: 7E1802FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000473568: D501000A 200E150A
	v_cndmask_b32_e64 v18, -v8, v8, s3                         // 000000473570: D5010012 200E1108
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000473578: D5010009 200E1309
	v_add_f32_e32 v14, v13, v11                                // 000000473580: 061C170D
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000473584: 7E1002FA FF016807
	v_add_f32_e32 v16, v10, v12                                // 00000047358C: 0620190A
	v_add_f32_e32 v15, v18, v15                                // 000000473590: 061E1F12
	v_add_f32_e32 v17, v9, v17                                 // 000000473594: 06222309
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000473598: 7E1202FA FF016804
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004735A0: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004735A8: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004735B0: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004735B8: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 0000004735C0: 8B7E007E
	s_cbranch_execz 65175                                      // 0000004735C4: BFA5FE97 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c24>
	v_lshl_or_b32 v18, s2, 7, v1                               // 0000004735C8: D6560012 04050E02
	v_and_b32_e32 v0, 8, v0                                    // 0000004735D0: 36000088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004735D4: BF870092
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000004735D8: 3426249F
	.long 0xd73c0012                                           // 0000004735DC: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004735E0: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004735E4: BF870091
	.long 0xd7006a14                                           // 0000004735E8: D7006A14
	v_cndmask_b32_e32 v1, s14, v18, vcc_lo                     // 0000004735EC: 0202240E
	v_add_co_ci_u32_e64 v21, null, s15, v19, vcc_lo            // 0000004735F0: D5207C15 01AA260F
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000004735F8: 7C940080
	s_clause 0x7                                               // 0000004735FC: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000473600: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000473608: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 000000473610: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 000000473618: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 000000473620: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 000000473628: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 000000473630: DC8200C0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:224          // 000000473638: DC8200E0 147C0014
	.long 0x7f2a3880                                           // 000000473640: 7F2A3880
	v_cndmask_b32_e64 v0, -v6, v6, vcc_lo                      // 000000473644: D5010000 21AA0D06
	v_cndmask_b32_e64 v1, -v3, v3, vcc_lo                      // 00000047364C: D5010001 21AA0703
	v_cndmask_b32_e64 v3, -v4, v4, vcc_lo                      // 000000473654: D5010003 21AA0904
	v_cndmask_b32_e64 v4, -v7, v7, vcc_lo                      // 00000047365C: D5010004 21AA0F07
	v_cndmask_b32_e64 v7, -v14, v14, vcc_lo                    // 000000473664: D5010007 21AA1D0E
	v_add_f32_e32 v0, v0, v5                                   // 00000047366C: 06000B00
	v_cndmask_b32_e64 v5, -v16, v16, vcc_lo                    // 000000473670: D5010005 21AA2110
	v_add_f32_e32 v3, v3, v9                                   // 000000473678: 06061303
	s_waitcnt vmcnt(7)                                         // 00000047367C: BF891FF7
	.long 0x7f2c3995                                           // 000000473680: 7F2C3995
	v_dual_add_f32 v7, v7, v10 :: v_dual_mul_f32 v16, 0x3db504f3, v0// 000000473684: C9061507 071000FF 3DB504F3
	v_add_f32_e32 v5, v5, v11                                  // 000000473690: 060A1705
	v_cndmask_b32_e64 v14, -v17, v17, vcc_lo                   // 000000473694: D501000E 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000047369C: D501000F 21AA1F0F
	v_add_f32_e32 v2, v1, v2                                   // 0000004736A4: 06040501
	v_dual_add_f32 v4, v4, v8 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 0000004736A8: C9061104 040206FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004736B4: BF870193
	v_dual_add_f32 v9, v14, v13 :: v_dual_add_f32 v8, v15, v12 // 0000004736B8: C9081B0E 0908190F
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 0000004736C0: C8C60AFF 050204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004736CC: BF870193
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 0000004736D0: C8C60EFF 070408FF 3DB504F3
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 0000004736DC: 101212FF 3DB504F3
	s_waitcnt vmcnt(6)                                         // 0000004736E4: BF891BF7
	.long 0x7f2e3995                                           // 0000004736E8: 7F2E3995
	.long 0x7f0c3995                                           // 0000004736EC: 7F0C3995
	s_waitcnt vmcnt(0)                                         // 0000004736F0: BF8903F7
	.long 0x7f283995                                           // 0000004736F4: 7F283995
	.long 0xd7006a00                                           // 0000004736F8: D7006A00
	v_cndmask_b32_e32 v1, s28, v18, vcc_lo                     // 0000004736FC: 0202241C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000473700: BF870001
	v_add_co_ci_u32_e64 v1, null, s29, v19, vcc_lo             // 000000473704: D5207C01 01AA261D
	v_fma_mix_f32 v10, v22, v16, neg(0) op_sel_hi:[1,0,0]      // 00000047370C: CC20000A 8A022116
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 000000473714: CC200002 8A020517
	v_fma_mix_f32 v4, v24, v4, neg(0) op_sel_hi:[1,0,0]        // 00000047371C: CC200004 8A020918
	v_fma_mix_f32 v3, v25, v3, neg(0) op_sel_hi:[1,0,0]        // 000000473724: CC200003 8A020719
	v_fma_mix_f32 v7, v26, v7, neg(0) op_sel_hi:[1,0,0]        // 00000047372C: CC200007 8A020F1A
	.long 0x7e2a398a                                           // 000000473734: 7E2A398A
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000473738: 101010FF 3DB504F3
	v_fma_mix_f32 v5, v27, v5, neg(0) op_sel_hi:[1,0,0]        // 000000473740: CC200005 8A020B1B
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 000000473748: CC200009 8A021314
	.long 0x7e0c3982                                           // 000000473750: 7E0C3982
	v_and_b32_e32 v11, 1, v21                                  // 000000473754: 36162A81
	.long 0x7e2a3983                                           // 000000473758: 7E2A3983
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 00000047375C: CC200008 8A02111C
	.long 0x7e283984                                           // 000000473764: 7E283984
	.long 0x7e2c3987                                           // 000000473768: 7E2C3987
	v_and_b32_e32 v6, 1, v6                                    // 00000047376C: 360C0C81
	v_and_b32_e32 v12, 1, v21                                  // 000000473770: 36182A81
	.long 0x7e2a3985                                           // 000000473774: 7E2A3985
	.long 0x7e2e3988                                           // 000000473778: 7E2E3988
	v_and_b32_e32 v13, 1, v20                                  // 00000047377C: 361A2881
	v_and_b32_e32 v14, 1, v22                                  // 000000473780: 361C2C81
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000473784: D6550002 03FE0D02 00007FFF
	v_and_b32_e32 v15, 1, v21                                  // 000000473790: 361E2A81
	.long 0x7e2a3989                                           // 000000473794: 7E2A3989
	v_and_b32_e32 v16, 1, v23                                  // 000000473798: 36202E81
	v_add3_u32 v10, v10, v11, 0x7fff                           // 00000047379C: D655000A 03FE170A 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 0000004737A8: D6550004 03FE1B04 00007FFF
	v_add3_u32 v3, v3, v12, 0x7fff                             // 0000004737B4: D6550003 03FE1903 00007FFF
	v_and_b32_e32 v6, 1, v21                                   // 0000004737C0: 360C2A81
	v_add3_u32 v7, v7, v14, 0x7fff                             // 0000004737C4: D6550007 03FE1D07 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 0000004737D0: D6550008 03FE2108 00007FFF
	v_add3_u32 v5, v5, v15, 0x7fff                             // 0000004737DC: D6550005 03FE1F05 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004737E8: BF870004
	v_add3_u32 v6, v9, v6, 0x7fff                              // 0000004737EC: D6550006 03FE0D09 00007FFF
	s_clause 0x7                                               // 0000004737F8: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000004737FC: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v10, off offset:32         // 000000473804: DC960020 007C0A00
	global_store_d16_hi_b16 v[0:1], v4, off offset:64          // 00000047380C: DC960040 007C0400
	global_store_d16_hi_b16 v[0:1], v3, off offset:96          // 000000473814: DC960060 007C0300
	global_store_d16_hi_b16 v[0:1], v7, off offset:128         // 00000047381C: DC960080 007C0700
	global_store_d16_hi_b16 v[0:1], v5, off offset:160         // 000000473824: DC9600A0 007C0500
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 00000047382C: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v6, off offset:224         // 000000473834: DC9600E0 007C0600
	s_endpgm                                                   // 00000047383C: BFB00000
		...

