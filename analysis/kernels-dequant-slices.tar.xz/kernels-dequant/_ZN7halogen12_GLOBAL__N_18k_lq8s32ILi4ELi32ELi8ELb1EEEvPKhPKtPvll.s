0000000000729000 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi8ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi8ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000729000: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000729004: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000072900C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 000000729014: BE830080
	v_lshrrev_b32_e32 v14, 5, v0                               // 000000729018: 321C0085
	v_mov_b32_e32 v16, 0                                       // 00000072901C: 7E200280
	.long 0x7e323880                                           // 000000729020: 7E323880
	v_and_b32_e32 v15, 31, v0                                  // 000000729024: 361E009F
	s_waitcnt lgkmcnt(0)                                       // 000000729028: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 00000072902C: 86009F0B
	.long 0xd451000e                                           // 000000729030: D451000E
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000729034: 02001802
	s_lshr_b32 s0, s0, 28                                      // 000000729038: 85009C00
	v_dual_mov_b32 v1, s4 :: v_dual_mov_b32 v2, s5             // 00000072903C: CA100004 01020005
	s_add_u32 s0, s10, s0                                      // 000000729044: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000729048: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000072904C: BF870499
	s_ashr_i64 s[0:1], s[0:1], 4                               // 000000729050: 86808400
	s_add_u32 s15, s10, s0                                     // 000000729054: 800F000A
	s_addc_u32 s1, s11, s1                                     // 000000729058: 8201010B
	s_add_u32 s15, s15, 15                                     // 00000072905C: 800F8F0F
	s_addc_u32 s1, s1, 0                                       // 000000729060: 82018001
	s_and_b32 s15, s15, -16                                    // 000000729064: 8B0FD00F
	s_and_b32 s14, s14, exec_lo                                // 000000729068: 8B0E7E0E
	s_cselect_b32 s14, s2, 0                                   // 00000072906C: 980E8002
	s_add_i32 s16, s0, 7                                       // 000000729070: 81108700
	v_mad_u64_u32 v[10:11], null, s14, s15, v[1:2]             // 000000729074: D6FE7C0A 04041E0E
	s_ashr_i32 s17, s16, 31                                    // 00000072907C: 86119F10
	v_mov_b32_e32 v2, 0                                        // 000000729080: 7E040280
	s_lshr_b32 s17, s17, 29                                    // 000000729084: 85119D11
	s_mul_i32 s14, s14, s1                                     // 000000729088: 960E010E
	s_add_i32 s16, s16, s17                                    // 00000072908C: 81101110
	v_mov_b32_e32 v1, 0                                        // 000000729090: 7E020280
	s_ashr_i32 s4, s16, 3                                      // 000000729094: 86048310
	v_add_nc_u32_e32 v11, s14, v11                             // 000000729098: 4A16160E
	.long 0xd72c0004                                           // 00000072909C: D72C0004
	v_cndmask_b32_e32 v1, s4, v14, vcc_lo                      // 0000007290A0: 02021C04
	.long 0xd7006a13                                           // 0000007290A4: D7006A13
	v_cndmask_b32_e32 v0, v10, v10, vcc_lo                     // 0000007290A8: 0200150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007290AC: BF870191
	v_add_co_ci_u32_e64 v20, null, s11, v11, vcc_lo            // 0000007290B0: D5207C14 01AA160B
	v_add_nc_u32_e32 v5, s4, v4                                // 0000007290B8: 4A0A0804
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v17, v4, v15     // 0000007290BC: CA200080 04101F04
	v_mov_b32_e32 v3, 0                                        // 0000007290C4: 7E060280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007290C8: BF870193
	v_min_i32_e32 v18, s0, v5                                  // 0000007290CC: 22240A00
	v_lshlrev_b32_e32 v12, 4, v17                              // 0000007290D0: 30182284
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007290D4: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v17, v18                          // 0000007290D8: 7C822511
	s_and_saveexec_b32 s1, vcc_lo                              // 0000007290DC: BE81206A
	s_cbranch_execz 19                                         // 0000007290E0: BFA50013 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi8ELb1EEEvPKhPKtPvll+0x130>
	v_lshlrev_b32_e32 v1, 4, v17                               // 0000007290E4: 30022284
	v_and_b32_e32 v3, -2, v17                                  // 0000007290E8: 360622C2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007290EC: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007290F0: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007290F4: 3408069F
	.long 0xd7000001                                           // 0000007290F8: D7000001
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 0000007290FC: 0202030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000729100: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 000000729104: D5207C02 0002050B
	.long 0xd7000005                                           // 00000072910C: D7000005
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 000000729110: 02020713
	v_add_co_ci_u32_e64 v6, null, v20, v4, s0                  // 000000729114: D5207C06 00020914
	s_clause 0x1                                               // 00000072911C: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 000000729120: DC5E0000 017C0001
	global_load_d16_b16 v25, v[5:6], off                       // 000000729128: DC820000 197C0005
	s_or_b32 exec_lo, exec_lo, s1                              // 000000729130: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000729134: CA100080 16160080
	v_mov_b32_e32 v21, 0                                       // 00000072913C: 7E2A0280
	s_and_saveexec_b32 s1, vcc_lo                              // 000000729140: BE81206A
	s_cbranch_execz 372                                        // 000000729144: BFA50174 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi8ELb1EEEvPKhPKtPvll+0x718>
	v_dual_mov_b32 v21, 0 :: v_dual_add_nc_u32 v24, 0x200, v12 // 000000729148: CA200080 151818FF 00000200
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 000000729154: CA100080 17160080
	v_mov_b32_e32 v16, 0                                       // 00000072915C: 7E200280
	s_mul_i32 s0, s11, 6                                       // 000000729160: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000729164: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000729168: 8484820A
	s_add_i32 s14, s14, s0                                     // 00000072916C: 810E000E
	s_mul_i32 s16, s10, 6                                      // 000000729170: 9610860A
	s_mov_b32 s15, 0                                           // 000000729174: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000729178: 848A810A
	s_branch 325                                               // 00000072917C: BFA00145 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi8ELb1EEEvPKhPKtPvll+0x694>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000729180: 8C7E117E
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000729184: 341A189F
	v_bfe_i32 v58, v1, 8, 8                                    // 000000729188: D611003A 02211101
	v_bfe_i32 v59, v1, 16, 8                                   // 000000729190: D611003B 02212101
	v_bfe_i32 v60, v2, 0, 8                                    // 000000729198: D611003C 02210102
	v_bfe_i32 v61, v2, 8, 8                                    // 0000007291A0: D611003D 02211102
	.long 0xd73c001a                                           // 0000007291A8: D73C001A
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000007291AC: 02021881
	v_bfe_i32 v13, v1, 0, 8                                    // 0000007291B0: D611000D 02210101
	v_bfe_i32 v62, v2, 16, 8                                   // 0000007291B8: D611003E 02212102
	v_ashrrev_i32_e32 v63, 24, v2                              // 0000007291C0: 347E0498
	s_waitcnt vmcnt(1)                                         // 0000007291C4: BF8907F7
	v_mov_b32_e32 v2, v6                                       // 0000007291C8: 7E040306
	.long 0x7f323880                                           // 0000007291CC: 7F323880
	.long 0xd700002a                                           // 0000007291D0: D700002A
	v_cndmask_b32_e32 v1, s6, v26, vcc_lo                      // 0000007291D4: 02023406
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007291D8: BF8701A1
	v_add_co_ci_u32_e64 v43, null, s7, v27, s0                 // 0000007291DC: D5207C2B 00023607
	v_cvt_f32_i32_e32 v6, v13                                  // 0000007291E4: 7E0C0B0D
	.long 0xd700002e                                           // 0000007291E8: D700002E
	v_cndmask_b32_e32 v0, v42, v10, vcc_lo                     // 0000007291EC: 0200152A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007291F0: BF8700A1
	v_add_co_ci_u32_e64 v47, null, s11, v43, s0                // 0000007291F4: D5207C2F 0002560B
	.long 0xd7000032                                           // 0000007291FC: D7000032
	v_cndmask_b32_e32 v0, v42, v4, vcc_lo                      // 000000729200: 0200092A
	v_add_co_ci_u32_e64 v51, null, s5, v43, s0                 // 000000729204: D5207C33 00025605
	.long 0xd7000036                                           // 00000072920C: D7000036
	v_cndmask_b32_e32 v0, v42, v16, vcc_lo                     // 000000729210: 0200212A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000729214: BF870001
	v_add_co_ci_u32_e64 v55, null, s14, v43, s0                // 000000729218: D5207C37 0002560E
	s_clause 0x7                                               // 000000729220: BF850007
	global_load_b128 v[26:29], v[42:43], off                   // 000000729224: DC5E0000 1A7C002A
	global_load_b128 v[30:33], v[46:47], off                   // 00000072922C: DC5E0000 1E7C002E
	global_load_b128 v[34:37], v[50:51], off                   // 000000729234: DC5E0000 227C0032
	global_load_b128 v[38:41], v[54:55], off                   // 00000072923C: DC5E0000 267C0036
	global_load_b128 v[42:45], v[42:43], off offset:16         // 000000729244: DC5E0010 2A7C002A
	global_load_b128 v[46:49], v[46:47], off offset:16         // 00000072924C: DC5E0010 2E7C002E
	global_load_b128 v[50:53], v[50:51], off offset:16         // 000000729254: DC5E0010 327C0032
	global_load_b128 v[54:57], v[54:55], off offset:16         // 00000072925C: DC5E0010 367C0036
	v_ashrrev_i32_e32 v1, 24, v1                               // 000000729264: 34020298
	v_bfe_i32 v64, v3, 0, 8                                    // 000000729268: D6110040 02210103
	v_bfe_i32 v65, v3, 8, 8                                    // 000000729270: D6110041 02211103
	v_bfe_i32 v66, v3, 16, 8                                   // 000000729278: D6110042 02212103
	v_ashrrev_i32_e32 v67, 24, v3                              // 000000729280: 34860698
	v_bfe_i32 v68, v4, 0, 8                                    // 000000729284: D6110044 02210104
	v_bfe_i32 v69, v4, 8, 8                                    // 00000072928C: D6110045 02211104
	v_bfe_i32 v70, v4, 16, 8                                   // 000000729294: D6110046 02212104
	v_ashrrev_i32_e32 v71, 24, v4                              // 00000072929C: 348E0898
	v_dual_mov_b32 v3, v7 :: v_dual_add_nc_u32 v24, 0x200, v24 // 0000007292A0: CA200107 031830FF 00000200
	v_mov_b32_e32 v4, v8                                       // 0000007292AC: 7E080308
	v_cvt_f32_i32_e32 v7, v58                                  // 0000007292B0: 7E0E0B3A
	v_cvt_f32_i32_e32 v8, v59                                  // 0000007292B4: 7E100B3B
	v_fma_mix_f32 v6, v25, v6, neg(0) op_sel_hi:[1,0,0]        // 0000007292B8: CC200006 8A020D19
	v_cvt_f32_i32_e32 v1, v1                                   // 0000007292C0: 7E020B01
	v_cvt_f32_i32_e32 v58, v60                                 // 0000007292C4: 7E740B3C
	v_fma_mix_f32 v7, v25, v7, neg(0) op_sel_hi:[1,0,0]        // 0000007292C8: CC200007 8A020F19
	v_fma_mix_f32 v8, v25, v8, neg(0) op_sel_hi:[1,0,0]        // 0000007292D0: CC200008 8A021119
	v_bfe_u32 v73, v6, 16, 1                                   // 0000007292D8: D6100049 02052106
	v_cvt_f32_i32_e32 v59, v61                                 // 0000007292E0: 7E760B3D
	v_cvt_f32_i32_e32 v60, v62                                 // 0000007292E4: 7E780B3E
	v_cvt_f32_i32_e32 v62, v63                                 // 0000007292E8: 7E7C0B3F
	v_cvt_f32_i32_e32 v63, v64                                 // 0000007292EC: 7E7E0B40
	v_cvt_f32_i32_e32 v64, v65                                 // 0000007292F0: 7E800B41
	v_cvt_f32_i32_e32 v65, v66                                 // 0000007292F4: 7E820B42
	v_cvt_f32_i32_e32 v67, v67                                 // 0000007292F8: 7E860B43
	v_cvt_f32_i32_e32 v68, v68                                 // 0000007292FC: 7E880B44
	v_cvt_f32_i32_e32 v69, v69                                 // 000000729300: 7E8A0B45
	v_cvt_f32_i32_e32 v70, v70                                 // 000000729304: 7E8C0B46
	v_cvt_f32_i32_e32 v71, v71                                 // 000000729308: 7E8E0B47
	v_fma_mix_f32 v1, v25, v1, neg(0) op_sel_hi:[1,0,0]        // 00000072930C: CC200001 8A020319
	v_fma_mix_f32 v58, v25, v58, neg(0) op_sel_hi:[1,0,0]      // 000000729314: CC20003A 8A027519
	v_bfe_u32 v74, v7, 16, 1                                   // 00000072931C: D610004A 02052107
	v_bfe_u32 v75, v8, 16, 1                                   // 000000729324: D610004B 02052108
	v_add3_u32 v6, v6, v73, 0x7fff                             // 00000072932C: D6550006 03FE9306 00007FFF
	v_fma_mix_f32 v59, v25, v59, neg(0) op_sel_hi:[1,0,0]      // 000000729338: CC20003B 8A027719
	v_fma_mix_f32 v60, v25, v60, neg(0) op_sel_hi:[1,0,0]      // 000000729340: CC20003C 8A027919
	v_fma_mix_f32 v62, v25, v62, neg(0) op_sel_hi:[1,0,0]      // 000000729348: CC20003E 8A027D19
	v_fma_mix_f32 v63, v25, v63, neg(0) op_sel_hi:[1,0,0]      // 000000729350: CC20003F 8A027F19
	v_fma_mix_f32 v64, v25, v64, neg(0) op_sel_hi:[1,0,0]      // 000000729358: CC200040 8A028119
	v_fma_mix_f32 v65, v25, v65, neg(0) op_sel_hi:[1,0,0]      // 000000729360: CC200041 8A028319
	v_fma_mix_f32 v67, v25, v67, neg(0) op_sel_hi:[1,0,0]      // 000000729368: CC200043 8A028719
	v_fma_mix_f32 v68, v25, v68, neg(0) op_sel_hi:[1,0,0]      // 000000729370: CC200044 8A028919
	v_fma_mix_f32 v69, v25, v69, neg(0) op_sel_hi:[1,0,0]      // 000000729378: CC200045 8A028B19
	v_fma_mix_f32 v70, v25, v70, neg(0) op_sel_hi:[1,0,0]      // 000000729380: CC200046 8A028D19
	v_fma_mix_f32 v71, v25, v71, neg(0) op_sel_hi:[1,0,0]      // 000000729388: CC200047 8A028F19
	v_bfe_u32 v76, v1, 16, 1                                   // 000000729390: D610004C 02052101
	v_bfe_u32 v77, v58, 16, 1                                  // 000000729398: D610004D 0205213A
	v_add3_u32 v7, v7, v74, 0x7fff                             // 0000007293A0: D6550007 03FE9507 00007FFF
	v_add3_u32 v8, v8, v75, 0x7fff                             // 0000007293AC: D6550008 03FE9708 00007FFF
	.long 0x7e323986                                           // 0000007293B8: 7E323986
	.long 0x7f1a3999                                           // 0000007293BC: 7F1A3999
	v_bfe_u32 v78, v59, 16, 1                                  // 0000007293C0: D610004E 0205213B
	v_bfe_u32 v79, v60, 16, 1                                  // 0000007293C8: D610004F 0205213C
	v_add3_u32 v1, v1, v76, 0x7fff                             // 0000007293D0: D6550001 03FE9901 00007FFF
	v_add3_u32 v58, v58, v77, 0x7fff                           // 0000007293DC: D655003A 03FE9B3A 00007FFF
	.long 0x7e1a3988                                           // 0000007293E8: 7E1A3988
	v_and_or_b32 v6, 0xffff0000, v7, v25                       // 0000007293EC: D6570006 04660EFF FFFF0000
	v_bfe_u32 v80, v62, 16, 1                                  // 0000007293F8: D6100050 0205213E
	v_bfe_u32 v81, v63, 16, 1                                  // 000000729400: D6100051 0205213F
	v_add3_u32 v59, v59, v78, 0x7fff                           // 000000729408: D655003B 03FE9D3B 00007FFF
	v_add3_u32 v60, v60, v79, 0x7fff                           // 000000729414: D655003C 03FE9F3C 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v13                       // 000000729420: D6570001 043602FF FFFF0000
	.long 0x7e3239ba                                           // 00000072942C: 7E3239BA
	.long 0x7f7a3999                                           // 000000729430: 7F7A3999
	v_bfe_u32 v82, v64, 16, 1                                  // 000000729434: D6100052 02052140
	v_bfe_u32 v83, v65, 16, 1                                  // 00000072943C: D6100053 02052141
	v_add3_u32 v62, v62, v80, 0x7fff                           // 000000729444: D655003E 03FEA13E 00007FFF
	v_add3_u32 v63, v63, v81, 0x7fff                           // 000000729450: D655003F 03FEA33F 00007FFF
	.long 0x7e7a39bc                                           // 00000072945C: 7E7A39BC
	v_bfe_u32 v84, v67, 16, 1                                  // 000000729460: D6100054 02052143
	v_bfe_u32 v85, v68, 16, 1                                  // 000000729468: D6100055 02052144
	v_add3_u32 v64, v64, v82, 0x7fff                           // 000000729470: D6550040 03FEA540 00007FFF
	v_add3_u32 v65, v65, v83, 0x7fff                           // 00000072947C: D6550041 03FEA741 00007FFF
	v_and_or_b32 v7, 0xffff0000, v62, v61                      // 000000729488: D6570007 04F67CFF FFFF0000
	.long 0x7f843999                                           // 000000729494: 7F843999
	v_bfe_u32 v86, v69, 16, 1                                  // 000000729498: D6100056 02052145
	v_bfe_u32 v87, v70, 16, 1                                  // 0000007294A0: D6100057 02052146
	v_add3_u32 v67, v67, v84, 0x7fff                           // 0000007294A8: D6550043 03FEA943 00007FFF
	v_add3_u32 v68, v68, v85, 0x7fff                           // 0000007294B4: D6550044 03FEAB44 00007FFF
	.long 0x7e8439c1                                           // 0000007294C0: 7E8439C1
	v_bfe_u32 v88, v71, 16, 1                                  // 0000007294C4: D6100058 02052147
	v_add3_u32 v69, v69, v86, 0x7fff                           // 0000007294CC: D6550045 03FEAD45 00007FFF
	v_add3_u32 v70, v70, v87, 0x7fff                           // 0000007294D8: D6550046 03FEAF46 00007FFF
	.long 0x7f903999                                           // 0000007294E4: 7F903999
	v_and_or_b32 v8, 0xffff0000, v67, v66                      // 0000007294E8: D6570008 050A86FF FFFF0000
	v_add3_u32 v71, v71, v88, 0x7fff                           // 0000007294F4: D6550047 03FEB147 00007FFF
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000729500: 8B006A7E
	.long 0x7e9039c6                                           // 000000729504: 7E9039C6
	s_or_b32 s15, s0, s15                                      // 000000729508: 8C0F0F00
	s_waitcnt vmcnt(7)                                         // 00000072950C: BF891FF7
	v_dot2_f32_bf16 v13, v26, v6, 0                            // 000000729510: CC1A400D 1A020D1A
	s_waitcnt vmcnt(6)                                         // 000000729518: BF891BF7
	v_dot2_f32_bf16 v26, v30, v6, 0                            // 00000072951C: CC1A401A 1A020D1E
	s_waitcnt vmcnt(5)                                         // 000000729524: BF8917F7
	v_dot2_f32_bf16 v30, v34, v6, 0                            // 000000729528: CC1A401E 1A020D22
	s_waitcnt vmcnt(4)                                         // 000000729530: BF8913F7
	v_dot2_f32_bf16 v6, v38, v6, 0                             // 000000729534: CC1A4006 1A020D26
	v_and_or_b32 v34, 0xffff0000, v59, v25                     // 00000072953C: D6570022 046676FF FFFF0000
	v_dot2_f32_bf16 v13, v27, v1, v13                          // 000000729548: CC1A400D 1C36031B
	v_dot2_f32_bf16 v26, v31, v1, v26                          // 000000729550: CC1A401A 1C6A031F
	v_dot2_f32_bf16 v27, v35, v1, v30                          // 000000729558: CC1A401B 1C7A0323
	v_dot2_f32_bf16 v1, v39, v1, v6                            // 000000729560: CC1A4001 1C1A0327
	.long 0x7e3239bf                                           // 000000729568: 7E3239BF
	v_dot2_f32_bf16 v6, v28, v34, v13                          // 00000072956C: CC1A4006 1C36451C
	v_dot2_f32_bf16 v13, v32, v34, v26                         // 000000729574: CC1A400D 1C6A4520
	v_dot2_f32_bf16 v26, v36, v34, v27                         // 00000072957C: CC1A401A 1C6E4524
	v_dot2_f32_bf16 v1, v40, v34, v1                           // 000000729584: CC1A4001 1C064528
	v_and_or_b32 v27, 0xffff0000, v64, v25                     // 00000072958C: D657001B 046680FF FFFF0000
	v_dot2_f32_bf16 v6, v29, v7, v6                            // 000000729598: CC1A4006 1C1A0F1D
	v_dot2_f32_bf16 v13, v33, v7, v13                          // 0000007295A0: CC1A400D 1C360F21
	v_dot2_f32_bf16 v26, v37, v7, v26                          // 0000007295A8: CC1A401A 1C6A0F25
	v_dot2_f32_bf16 v1, v41, v7, v1                            // 0000007295B0: CC1A4001 1C060F29
	.long 0x7e3239c4                                           // 0000007295B8: 7E3239C4
	s_waitcnt vmcnt(3)                                         // 0000007295BC: BF890FF7
	v_dot2_f32_bf16 v6, v42, v27, v6                           // 0000007295C0: CC1A4006 1C1A372A
	s_waitcnt vmcnt(2)                                         // 0000007295C8: BF890BF7
	v_dot2_f32_bf16 v7, v46, v27, v13                          // 0000007295CC: CC1A4007 1C36372E
	s_waitcnt vmcnt(1)                                         // 0000007295D4: BF8907F7
	v_dot2_f32_bf16 v13, v50, v27, v26                         // 0000007295D8: CC1A400D 1C6A3732
	s_waitcnt vmcnt(0)                                         // 0000007295E0: BF8903F7
	v_dot2_f32_bf16 v1, v54, v27, v1                           // 0000007295E4: CC1A4001 1C063736
	v_and_or_b32 v25, 0xffff0000, v69, v25                     // 0000007295EC: D6570019 04668AFF FFFF0000
	v_dot2_f32_bf16 v6, v43, v8, v6                            // 0000007295F8: CC1A4006 1C1A112B
	v_dot2_f32_bf16 v7, v47, v8, v7                            // 000000729600: CC1A4007 1C1E112F
	v_dot2_f32_bf16 v13, v51, v8, v13                          // 000000729608: CC1A400D 1C361133
	v_dot2_f32_bf16 v1, v55, v8, v1                            // 000000729610: CC1A4001 1C061137
	v_and_or_b32 v8, 0xffff0000, v71, v72                      // 000000729618: D6570008 05228EFF FFFF0000
	v_dot2_f32_bf16 v6, v44, v25, v6                           // 000000729624: CC1A4006 1C1A332C
	v_dot2_f32_bf16 v7, v48, v25, v7                           // 00000072962C: CC1A4007 1C1E3330
	v_dot2_f32_bf16 v13, v52, v25, v13                         // 000000729634: CC1A400D 1C363334
	v_dot2_f32_bf16 v25, v56, v25, v1                          // 00000072963C: CC1A4019 1C063338
	v_mov_b32_e32 v1, v5                                       // 000000729644: 7E020305
	v_dot2_f32_bf16 v5, v45, v8, v6                            // 000000729648: CC1A4005 1C1A112D
	v_dot2_f32_bf16 v6, v49, v8, v7                            // 000000729650: CC1A4006 1C1E1131
	v_dot2_f32_bf16 v7, v53, v8, v13                           // 000000729658: CC1A4007 1C361135
	v_dot2_f32_bf16 v8, v57, v8, v25                           // 000000729660: CC1A4008 1C661139
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000729668: BF870194
	v_dual_add_f32 v21, v21, v5 :: v_dual_add_nc_u32 v12, 0x200, v12// 00000072966C: C9200B15 150C18FF 00000200
	v_dual_add_f32 v23, v23, v6 :: v_dual_add_f32 v22, v22, v7 // 000000729678: C9080D17 17160F16
	s_delay_alu instid0(VALU_DEP_3)                            // 000000729680: BF870003
	v_add_f32_e32 v16, v16, v8                                 // 000000729684: 06201110
	.long 0x7e323909                                           // 000000729688: 7E323909
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000072968C: 917E0F7E
	s_cbranch_execz 32                                         // 000000729690: BFA50020 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi8ELb1EEEvPKhPKtPvll+0x714>
	s_waitcnt vmcnt(1)                                         // 000000729694: BF8907F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v17, 32, v17    // 000000729698: CA200102 061022A0
	s_waitcnt vmcnt(0)                                         // 0000007296A0: BF8903F7
	.long 0x7e123919                                           // 0000007296A4: 7E123919
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000007296A8: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000007296B0: 7E0E0303
	s_mov_b32 s17, exec_lo                                     // 0000007296B4: BE91007E
	v_cmp_ge_i32_e32 vcc_lo, v17, v18                          // 0000007296B8: 7C8C2511
	.long 0xd4c1007e                                           // 0000007296BC: D4C1007E
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000007296C0: 02022511
	s_cbranch_execz 65198                                      // 0000007296C4: BFA5FEAE <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi8ELb1EEEvPKhPKtPvll+0x180>
	v_and_b32_e32 v7, -2, v17                                  // 0000007296C8: 360E22C2
	v_ashrrev_i32_e32 v6, 31, v24                              // 0000007296CC: 340C309F
	.long 0xd7000005                                           // 0000007296D0: D7000005
	v_cndmask_b32_e32 v1, v10, v24, vcc_lo                     // 0000007296D4: 0202310A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007296D8: BF870193
	v_ashrrev_i32_e32 v8, 31, v7                               // 0000007296DC: 34100E9F
	v_add_co_ci_u32_e64 v6, null, v11, v6, s0                  // 0000007296E0: D5207C06 00020D0B
	.long 0xd700001a                                           // 0000007296E8: D700001A
	v_cndmask_b32_e32 v1, v19, v7, vcc_lo                      // 0000007296EC: 02020F13
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007296F0: BF870001
	v_add_co_ci_u32_e64 v27, null, v20, v8, s0                 // 0000007296F4: D5207C1B 00021114
	s_clause 0x1                                               // 0000007296FC: BF850001
	global_load_b128 v[5:8], v[5:6], off                       // 000000729700: DC5E0000 057C0005
	global_load_d16_b16 v9, v[26:27], off                      // 000000729708: DC820000 097C001A
	s_branch 65179                                             // 000000729710: BFA0FE9B <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi8ELb1EEEvPKhPKtPvll+0x180>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000729714: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000729718: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000072971C: 8C7E017E
	s_waitcnt vmcnt(1)                                         // 000000729720: BF8907F7
	.long 0xd71f0001                                           // 000000729724: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000729728: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000072972C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000729730: 3A040290
	v_xor_b32_e32 v6, 8, v1                                    // 000000729734: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 000000729738: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000072973C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000729740: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000729744: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000729748: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000072974C: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000729750: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 000000729754: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 00000072975C: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 000000729760: 06060715
	ds_bpermute_b32 v5, v2, v22                                // 000000729764: DACC0000 05001602
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 00000072976C: 020C0D01
	ds_bpermute_b32 v4, v2, v23                                // 000000729770: DACC0000 04001702
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000729778: 7C9814A0
	ds_bpermute_b32 v2, v2, v16                                // 00000072977C: DACC0000 02001002
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000729784: 02141501
	s_waitcnt lgkmcnt(2)                                       // 000000729788: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000072978C: BF870001
	v_dual_add_f32 v5, v22, v5 :: v_dual_lshlrev_b32 v10, 2, v10// 000000729790: C9220B16 050A1482
	v_lshlrev_b32_e32 v6, 2, v6                                // 000000729798: 300C0C82
	s_waitcnt lgkmcnt(1)                                       // 00000072979C: BF89FC17
	v_add_f32_e32 v4, v23, v4                                  // 0000007297A0: 06080917
	ds_bpermute_b32 v9, v6, v5                                 // 0000007297A4: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 0000007297AC: BF89FC07
	v_add_f32_e32 v5, v5, v9                                   // 0000007297B0: 060A1305
	ds_bpermute_b32 v7, v6, v3                                 // 0000007297B4: DACC0000 07000306
	ds_bpermute_b32 v8, v6, v4                                 // 0000007297BC: DACC0000 08000406
	s_waitcnt lgkmcnt(0)                                       // 0000007297C4: BF89FC07
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v4, v8     // 0000007297C8: C9080F03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 0000007297D0: DACC0000 0800050A
	s_waitcnt lgkmcnt(0)                                       // 0000007297D8: BF89FC07
	v_dual_add_f32 v2, v16, v2 :: v_dual_add_f32 v5, v5, v8    // 0000007297DC: C9080510 02041105
	ds_bpermute_b32 v6, v6, v2                                 // 0000007297E4: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 0000007297EC: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 0000007297F0: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 0000007297F4: DACC0000 0600030A
	ds_bpermute_b32 v9, v10, v2                                // 0000007297FC: DACC0000 0900020A
	s_waitcnt lgkmcnt(1)                                       // 000000729804: BF89FC17
	v_add_f32_e32 v3, v3, v6                                   // 000000729808: 06060D03
	ds_bpermute_b32 v7, v10, v4                                // 00000072980C: DACC0000 0700040A
	v_xor_b32_e32 v10, 2, v1                                   // 000000729814: 3A140282
	s_waitcnt lgkmcnt(1)                                       // 000000729818: BF89FC17
	v_add_f32_e32 v6, v2, v9                                   // 00000072981C: 060C1302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000729820: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000729824: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000729828: 02141501
	v_lshlrev_b32_e32 v10, 2, v10                              // 00000072982C: 30141482
	ds_bpermute_b32 v2, v10, v3                                // 000000729830: DACC0000 0200030A
	s_waitcnt lgkmcnt(1)                                       // 000000729838: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 00000072983C: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 000000729840: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 000000729848: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 000000729850: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 000000729858: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000072985C: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000729860: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 000000729864: 02021501
	s_waitcnt lgkmcnt(3)                                       // 000000729868: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 00000072986C: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 000000729874: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 000000729878: 06061105
	s_waitcnt lgkmcnt(0)                                       // 00000072987C: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 000000729880: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 000000729888: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 000000729890: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 000000729898: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 0000007298A0: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v15                                   // 0000007298A8: 7D941E80
	s_cbranch_execz 9                                          // 0000007298AC: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi8ELb1EEEvPKhPKtPvll+0x8d4>
	s_waitcnt lgkmcnt(1)                                       // 0000007298B0: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_add_f32 v7, v3, v7     // 0000007298B4: C9081105 08060F03
	s_waitcnt lgkmcnt(0)                                       // 0000007298BC: BF89FC07
	v_dual_add_f32 v6, v2, v6 :: v_dual_add_f32 v5, v1, v4     // 0000007298C0: C9080D02 06040901
	v_lshlrev_b32_e32 v1, 4, v14                               // 0000007298C8: 30021C84
	ds_store_b128 v1, v[5:8]                                   // 0000007298CC: DB7C0000 00000501
	s_or_b32 exec_lo, exec_lo, s0                              // 0000007298D4: 8C7E007E
	.long 0xd4510000                                           // 0000007298D8: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000007298DC: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 4, v0                             // 0000007298E0: 7C980084
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000007298E4: BF890007
	s_barrier                                                  // 0000007298E8: BFBD0000
	buffer_gl0_inv                                             // 0000007298EC: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 0000007298F4: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007298F8: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000007298FC: BE812000
	s_cbranch_execz 43                                         // 000000729900: BFA5002B <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi8ELb1EEEvPKhPKtPvll+0x9b0>
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000729904: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 2                               // 000000729908: 84808202
	ds_load_2addr_b32 v[1:2], v7 offset1:4                     // 00000072990C: D8DC0400 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:8 offset1:12          // 000000729914: D8DC0C08 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:16 offset1:20         // 00000072991C: D8DC1410 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000729924: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000729928: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000072992C: BF870131
	v_add_f32_e32 v9, v1, v2                                   // 000000729930: 06120501
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000729934: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(1)                                       // 00000072993C: BF89FC17
	v_add_f32_e32 v3, v9, v3                                   // 000000729940: 06060709
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000729944: BF870191
	v_add_f32_e32 v4, v3, v4                                   // 000000729948: 06080903
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 00000072994C: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 000000729954: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000729958: BF8700C2
	v_add_f32_e32 v0, v4, v5                                   // 00000072995C: 06000B04
	ds_load_2addr_b32 v[7:8], v7 offset0:24 offset1:28         // 000000729960: D8DC1C18 07000007
	v_add_f32_e32 v3, v0, v6                                   // 000000729968: 06060D00
	.long 0xd73c0000                                           // 00000072996C: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000729970: 02020282
	.long 0xd7006a00                                           // 000000729974: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000729978: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000072997C: BF870111
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000729980: D5207C01 01AA0209
	.long 0xd7006a00                                           // 000000729988: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000072998C: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000729990: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000729994: D5207C01 01AA0201
	s_waitcnt lgkmcnt(0)                                       // 00000072999C: BF89FC07
	v_add_f32_e32 v2, v3, v7                                   // 0000007299A0: 06040F03
	v_add_f32_e32 v2, v2, v8                                   // 0000007299A4: 06041102
	global_store_b32 v[0:1], v2, off                           // 0000007299A8: DC6A0000 007C0200
	s_endpgm                                                   // 0000007299B0: BFB00000
		...

