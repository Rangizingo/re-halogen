00000000002b7500 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 0000002B7500: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000002B7504: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 0000002B750C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 0000002B7514: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 0000002B751C: F4000180 F8000118
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000002B7524: 32040082
	s_load_b128 s[12:15], s[0:1], 0x128                        // 0000002B7528: F4080300 F8000128
	v_and_b32_e32 v24, 31, v0                                  // 0000002B7530: 3630009F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002B7534: BF870002
	v_and_b32_e32 v2, 60, v2                                   // 0000002B7538: 360404BC
	s_waitcnt lgkmcnt(0)                                       // 0000002B753C: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000002B7540: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000002B7544: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 0000002B7548: BF030402
	s_cselect_b32 s4, -1, 0                                    // 0000002B754C: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B7550: BF870009
	s_and_b32 s4, s7, s4                                       // 0000002B7554: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000002B7558: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000002B755C: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000002B7564: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 0000002B7568: BF030502
	s_cselect_b32 s5, -1, 0                                    // 0000002B756C: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B7570: BF870009
	s_and_b32 s4, s7, s5                                       // 0000002B7574: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000002B7578: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000002B757C: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000002B7580: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000002B7584: BF030602
	v_and_b32_e32 v1, 15, v0                                   // 0000002B7588: 3602008F
	s_cselect_b32 s6, -1, 0                                    // 0000002B758C: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B7590: BF870009
	s_and_b32 s3, s3, s6                                       // 0000002B7594: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000002B7598: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000002B759C: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000002B75A0: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000002B75A4: 98030483
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002B75A8: 30020282
	s_mulk_i32 s3, 0x48                                        // 0000002B75AC: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B75B0: BF870009
	s_add_u32 s16, s0, s3                                      // 0000002B75B4: 80100300
	s_addc_u32 s17, s1, 0                                      // 0000002B75B8: 82118001
	s_clause 0x1                                               // 0000002B75BC: BF850001
	s_load_b64 s[18:19], s[16:17], null                        // 0000002B75C0: F4040488 F8000000
	s_load_b256 s[4:11], s[16:17], 0x18                        // 0000002B75C8: F40C0108 F8000018
	s_waitcnt lgkmcnt(0)                                       // 0000002B75D0: BF89FC07
	s_clause 0x1                                               // 0000002B75D4: BF850001
	global_load_b32 v1, v1, s[18:19]                           // 0000002B75D8: DC520000 01120001
	global_load_b32 v2, v2, s[18:19]                           // 0000002B75E0: DC520000 02120002
	.long 0xd4510015                                           // 0000002B75E8: D4510015
	v_cndmask_b32_e32 v0, s10, v137, vcc_lo                    // 0000002B75EC: 0201120A
	s_and_b32 s3, s21, exec_lo                                 // 0000002B75F0: 8B037E15
	s_cselect_b32 s3, 8, 2                                     // 0000002B75F4: 98038288
	s_cselect_b32 s20, 3, 1                                    // 0000002B75F8: 98148183
	s_add_i32 s26, s3, -1                                      // 0000002B75FC: 811AC103
	s_waitcnt vmcnt(1)                                         // 0000002B7600: BF8907F7
	v_bfe_u32 v3, v1, 16, 1                                    // 0000002B7604: D6100003 02052101
	s_waitcnt vmcnt(0)                                         // 0000002B760C: BF8903F7
	v_bfe_u32 v4, v2, 16, 1                                    // 0000002B7610: D6100004 02052102
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002B7618: BF8701A2
	v_add3_u32 v1, v1, v3, 0x7fff                              // 0000002B761C: D6550001 03FE0701 00007FFF
	.long 0x7f063880                                           // 0000002B7628: 7F063880
	v_add3_u32 v2, v2, v4, 0x7fff                              // 0000002B762C: D6550002 03FE0902 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B7638: BF870123
	.long 0x7e063981                                           // 0000002B763C: 7E063981
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000002B7640: 30020082
	v_and_or_b32 v2, 0xffff0000, v2, v3                        // 0000002B7644: D6570002 040E04FF FFFF0000
	v_lshrrev_b32_e32 v3, 5, v0                                // 0000002B7650: 32060085
	ds_store_b32 v1, v2                                        // 0000002B7654: D8340000 00000201
	v_cvt_f32_ubyte0_e32 v1, s3                                // 0000002B765C: 7E022203
	v_lshrrev_b32_e32 v22, s20, v3                             // 0000002B7660: 322C0614
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B7664: BF870292
	v_rcp_iflag_f32_e32 v1, v1                                 // 0000002B7668: 7E025701
	v_readfirstlane_b32 s23, v1                                // 0000002B766C: 7E2E0501
	s_mul_f32 s23, s23, 0x4f7ffffe                             // 0000002B7670: A217FF17 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3)                          // 0000002B7678: BF87000B
	s_cvt_u32_f32 s23, s23                                     // 0000002B767C: BE976717
	s_waitcnt lgkmcnt(0)                                       // 0000002B7680: BF89FC07
	s_barrier                                                  // 0000002B7684: BFBD0000
	buffer_gl0_inv                                             // 0000002B7688: E0AC0000 00000000
	s_load_b32 s22, s[16:17], 0x40                             // 0000002B7690: F4000588 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002B7698: BF89FC07
	s_sub_i32 s0, s2, s22                                      // 0000002B769C: 81801602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000002B76A0: BF8704B9
	s_ashr_i32 s1, s0, 31                                      // 0000002B76A4: 86019F00
	s_and_b32 s22, s21, exec_lo                                // 0000002B76A8: 8B167E15
	s_cselect_b32 s22, 0, 2                                    // 0000002B76AC: 98168280
	s_lshl_b64 s[0:1], s[0:1], s22                             // 0000002B76B0: 84801600
	s_add_u32 s6, s18, s6                                      // 0000002B76B4: 80060612
	s_addc_u32 s7, s19, s7                                     // 0000002B76B8: 82070713
	s_ashr_i32 s24, s15, 31                                    // 0000002B76BC: 86189F0F
	.long 0xd7000001                                           // 0000002B76C0: D7000001
	v_cndmask_b32_e32 v1, s0, v22, vcc_lo                      // 0000002B76C4: 02022C00
	s_lshr_b32 s24, s24, 27                                    // 0000002B76C8: 85189B18
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 0000002B76CC: D5207C02 00010001
	s_add_u32 s24, s14, s24                                    // 0000002B76D4: 8018180E
	s_addc_u32 s25, s15, 0                                     // 0000002B76D8: 8219800F
	s_sub_i32 s27, 0, s3                                       // 0000002B76DC: 819B0380
	s_lshr_b64 s[24:25], s[24:25], 5                           // 0000002B76E0: 85988518
	s_mul_i32 s27, s27, s23                                    // 0000002B76E4: 961B171B
	s_add_i32 s25, s26, s24                                    // 0000002B76E8: 8119181A
	s_mul_hi_u32 s27, s23, s27                                 // 0000002B76EC: 969B1B17
	s_abs_i32 s28, s25                                         // 0000002B76F0: BE9C1519
	s_add_i32 s23, s23, s27                                    // 0000002B76F4: 81171B17
	s_ashr_i32 s25, s25, 31                                    // 0000002B76F8: 86199F19
	s_mul_hi_u32 s23, s28, s23                                 // 0000002B76FC: 9697171C
	v_cmp_gt_i64_e32 vcc_lo, s[10:11], v[1:2]                  // 0000002B7700: 7CA8020A
	s_mul_i32 s27, s23, s3                                     // 0000002B7704: 961B0317
	v_and_b32_e32 v23, s26, v3                                 // 0000002B7708: 362E061A
	s_sub_i32 s27, s28, s27                                    // 0000002B770C: 819B1B1C
	s_add_i32 s28, s23, 1                                      // 0000002B7710: 811C8117
	s_sub_i32 s29, s27, s3                                     // 0000002B7714: 819D031B
	s_cmp_ge_u32 s27, s3                                       // 0000002B7718: BF09031B
	v_cndmask_b32_e32 v10, 0, v1, vcc_lo                       // 0000002B771C: 02140280
	s_cselect_b32 s0, s28, s23                                 // 0000002B7720: 9800171C
	s_cselect_b32 s1, s29, s27                                 // 0000002B7724: 98011B1D
	s_add_i32 s23, s0, 1                                       // 0000002B7728: 81178100
	s_cmp_ge_u32 s1, s3                                        // 0000002B772C: BF090301
	v_cndmask_b32_e32 v9, 0, v2, vcc_lo                        // 0000002B7730: 02120480
	s_cselect_b32 s0, s23, s0                                  // 0000002B7734: 98000017
	.long 0xd72c0003                                           // 0000002B7738: D72C0003
	v_cndmask_b32_e32 v0, v10, v9, vcc_lo                      // 0000002B773C: 0200130A
	s_xor_b32 s0, s0, s25                                      // 0000002B7740: 8D001900
	v_mad_u64_u32 v[17:18], null, v10, s8, s[6:7]              // 0000002B7744: D6FE7C11 0018110A
	s_sub_i32 s1, s0, s25                                      // 0000002B774C: 81811900
	.long 0xd72c0002                                           // 0000002B7750: D72C0002
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 0000002B7754: 02001109
	.long 0xd72c000d                                           // 0000002B7758: D72C000D
	v_cndmask_b32_e32 v1, s1, v23, vcc_lo                      // 0000002B775C: 02022E01
	s_cmpk_lt_i32 s1, 0x101                                    // 0000002B7760: B3810101
	s_cselect_b32 s0, -1, 0                                    // 0000002B7764: 980080C1
	s_cmpk_gt_i32 s1, 0x100                                    // 0000002B7768: B2810100
	s_cselect_b32 s6, -1, 0                                    // 0000002B776C: 980680C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B7770: BF870112
	v_add3_u32 v27, v2, v18, v3                                // 0000002B7774: D655001B 040E2502
	v_add_nc_u32_e32 v1, s1, v13                               // 0000002B777C: 4A021A01
	v_add_nc_u32_e32 v26, v13, v24                             // 0000002B7780: 4A34310D
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002B7784: 8B6A067E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B7788: BF870122
	v_min_i32_e32 v25, s24, v1                                 // 0000002B778C: 22320218
	v_mov_b32_e32 v1, 0                                        // 0000002B7790: 7E020280
	.long 0xd4410001                                           // 0000002B7794: D4410001
	v_cndmask_b32_e32 v1, v26, v25, vcc_lo                     // 0000002B7798: 0202331A
	s_cbranch_vccnz 153                                        // 0000002B779C: BFA40099 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x504>
	s_and_saveexec_b32 s7, s1                                  // 0000002B77A0: BE872001
	s_cbranch_execz 11                                         // 0000002B77A4: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x2d4>
	v_lshlrev_b32_e32 v1, 1, v26                               // 0000002B77A8: 30023481
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B77AC: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002B77B0: 3404029F
	.long 0xd7006a01                                           // 0000002B77B4: D7006A01
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000002B77B8: 02020311
	v_add_co_ci_u32_e64 v2, null, v27, v2, vcc_lo              // 0000002B77BC: D5207C02 01AA051B
	global_load_d16_b16 v1, v[1:2], off                        // 0000002B77C4: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000002B77CC: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000002B77D0: 7E021701
	s_or_b32 exec_lo, exec_lo, s7                              // 0000002B77D4: 8C7E077E
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v4, 32, v26      // 0000002B77D8: CA200080 030434A0
	v_mov_b32_e32 v2, 0                                        // 0000002B77E0: 7E040280
	s_mov_b32 s1, exec_lo                                      // 0000002B77E4: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002B77E8: BF870002
	.long 0xd4c1007e                                           // 0000002B77EC: D4C1007E
	v_cndmask_b32_e32 v1, v4, v25, vcc_lo                      // 0000002B77F0: 02023304
	s_cbranch_execz 11                                         // 0000002B77F4: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x324>
	v_lshlrev_b32_e32 v2, 1, v4                                // 0000002B77F8: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B77FC: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v2                               // 0000002B7800: 340A049F
	.long 0xd7006a04                                           // 0000002B7804: D7006A04
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 0000002B7808: 02020511
	v_add_co_ci_u32_e64 v5, null, v27, v5, vcc_lo              // 0000002B780C: D5207C05 01AA0B1B
	global_load_d16_b16 v2, v[4:5], off                        // 0000002B7814: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 0000002B781C: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000002B7820: 7E041702
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002B7824: 8C7E017E
	v_add_nc_u32_e32 v4, 64, v26                               // 0000002B7828: 4A0834C0
	s_mov_b32 s1, exec_lo                                      // 0000002B782C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B7830: BF870001
	.long 0xd4c1007e                                           // 0000002B7834: D4C1007E
	v_cndmask_b32_e32 v1, v4, v25, vcc_lo                      // 0000002B7838: 02023304
	s_cbranch_execz 11                                         // 0000002B783C: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x36c>
	v_lshlrev_b32_e32 v3, 1, v4                                // 0000002B7840: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B7844: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002B7848: 3408069F
	.long 0xd7006a03                                           // 0000002B784C: D7006A03
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 0000002B7850: 02020711
	v_add_co_ci_u32_e64 v4, null, v27, v4, vcc_lo              // 0000002B7854: D5207C04 01AA091B
	global_load_d16_b16 v3, v[3:4], off                        // 0000002B785C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000002B7864: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000002B7868: 7E061703
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002B786C: 8C7E017E
	v_dual_mov_b32 v5, 0 :: v_dual_add_nc_u32 v6, 0x60, v26    // 0000002B7870: CA200080 050634FF 00000060
	v_mov_b32_e32 v4, 0                                        // 0000002B787C: 7E080280
	s_mov_b32 s1, exec_lo                                      // 0000002B7880: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002B7884: BF870002
	.long 0xd4c1007e                                           // 0000002B7888: D4C1007E
	v_cndmask_b32_e32 v1, v6, v25, vcc_lo                      // 0000002B788C: 02023306
	s_cbranch_execz 11                                         // 0000002B7890: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x3c0>
	v_lshlrev_b32_e32 v4, 1, v6                                // 0000002B7894: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B7898: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v4                               // 0000002B789C: 340E089F
	.long 0xd7006a06                                           // 0000002B78A0: D7006A06
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 0000002B78A4: 02020911
	v_add_co_ci_u32_e64 v7, null, v27, v7, vcc_lo              // 0000002B78A8: D5207C07 01AA0F1B
	global_load_d16_b16 v4, v[6:7], off                        // 0000002B78B0: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 0000002B78B8: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000002B78BC: 7E081704
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002B78C0: 8C7E017E
	v_add_nc_u32_e32 v6, 0x80, v26                             // 0000002B78C4: 4A0C34FF 00000080
	s_mov_b32 s1, exec_lo                                      // 0000002B78CC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B78D0: BF870001
	.long 0xd4c1007e                                           // 0000002B78D4: D4C1007E
	v_cndmask_b32_e32 v1, v6, v25, vcc_lo                      // 0000002B78D8: 02023306
	s_cbranch_execz 11                                         // 0000002B78DC: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x40c>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000002B78E0: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B78E4: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v5                               // 0000002B78E8: 340C0A9F
	.long 0xd7006a05                                           // 0000002B78EC: D7006A05
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000002B78F0: 02020B11
	v_add_co_ci_u32_e64 v6, null, v27, v6, vcc_lo              // 0000002B78F4: D5207C06 01AA0D1B
	global_load_d16_b16 v5, v[5:6], off                        // 0000002B78FC: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000002B7904: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000002B7908: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002B790C: 8C7E017E
	v_dual_mov_b32 v7, 0 :: v_dual_add_nc_u32 v8, 0xa0, v26    // 0000002B7910: CA200080 070834FF 000000A0
	v_mov_b32_e32 v6, 0                                        // 0000002B791C: 7E0C0280
	s_mov_b32 s1, exec_lo                                      // 0000002B7920: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002B7924: BF870002
	.long 0xd4c1007e                                           // 0000002B7928: D4C1007E
	v_cndmask_b32_e32 v1, v8, v25, vcc_lo                      // 0000002B792C: 02023308
	s_cbranch_execz 11                                         // 0000002B7930: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x460>
	v_lshlrev_b32_e32 v6, 1, v8                                // 0000002B7934: 300C1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B7938: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v6                               // 0000002B793C: 34100C9F
	.long 0xd7006a0b                                           // 0000002B7940: D7006A0B
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000002B7944: 02020D11
	v_add_co_ci_u32_e64 v12, null, v27, v8, vcc_lo             // 0000002B7948: D5207C0C 01AA111B
	global_load_d16_b16 v6, v[11:12], off                      // 0000002B7950: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 0000002B7958: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000002B795C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002B7960: 8C7E017E
	v_add_nc_u32_e32 v8, 0xc0, v26                             // 0000002B7964: 4A1034FF 000000C0
	s_mov_b32 s1, exec_lo                                      // 0000002B796C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B7970: BF870001
	.long 0xd4c1007e                                           // 0000002B7974: D4C1007E
	v_cndmask_b32_e32 v1, v8, v25, vcc_lo                      // 0000002B7978: 02023308
	s_cbranch_execz 11                                         // 0000002B797C: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x4ac>
	v_lshlrev_b32_e32 v7, 1, v8                                // 0000002B7980: 300E1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B7984: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v7                               // 0000002B7988: 34100E9F
	.long 0xd7006a07                                           // 0000002B798C: D7006A07
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 0000002B7990: 02020F11
	v_add_co_ci_u32_e64 v8, null, v27, v8, vcc_lo              // 0000002B7994: D5207C08 01AA111B
	global_load_d16_b16 v7, v[7:8], off                        // 0000002B799C: DC820000 077C0007
	s_waitcnt vmcnt(0)                                         // 0000002B79A4: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000002B79A8: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002B79AC: 8C7E017E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0xe0, v26   // 0000002B79B0: CA200080 080A34FF 000000E0
	s_mov_b32 s1, exec_lo                                      // 0000002B79BC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B79C0: BF870001
	.long 0xd4c1007e                                           // 0000002B79C4: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 0000002B79C8: 0202330B
	s_cbranch_execz 11                                         // 0000002B79CC: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x4fc>
	v_lshlrev_b32_e32 v8, 1, v11                               // 0000002B79D0: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B79D4: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 0000002B79D8: 3418109F
	.long 0xd7006a0b                                           // 0000002B79DC: D7006A0B
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 0000002B79E0: 02021111
	v_add_co_ci_u32_e64 v12, null, v27, v12, vcc_lo            // 0000002B79E4: D5207C0C 01AA191B
	global_load_d16_b16 v8, v[11:12], off                      // 0000002B79EC: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 0000002B79F4: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000002B79F8: 7E101708
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002B79FC: 8C7E017E
	s_branch 9                                                 // 0000002B7A00: BFA00009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x528>
	v_mov_b32_e32 v1, 0                                        // 0000002B7A04: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B7A08: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000002B7A0C: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000002B7A10: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000002B7A14: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000002B7A18: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000002B7A1C: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000002B7A20: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000002B7A24: 7E100301
	s_add_u32 s4, s18, s4                                      // 0000002B7A28: 80040412
	s_addc_u32 s5, s19, s5                                     // 0000002B7A2C: 82050513
	s_lshr_b32 s1, s15, 31                                     // 0000002B7A30: 85019F0F
	v_cndmask_b32_e64 v29, 0, 1, s6                            // 0000002B7A34: D501001D 00190280
	s_add_u32 s8, s14, s1                                      // 0000002B7A3C: 8008010E
	s_addc_u32 s9, s15, 0                                      // 0000002B7A40: 8209800F
	.long 0xd4410001                                           // 0000002B7A44: D4410001
	v_cndmask_b32_e32 v1, v26, v25, vcc_lo                     // 0000002B7A48: 0202331A
	s_ashr_i64 s[8:9], s[8:9], 1                               // 0000002B7A4C: 86888108
	v_mov_b32_e32 v28, 0                                       // 0000002B7A50: 7E380280
	v_mad_u64_u32 v[18:19], null, v10, s8, s[4:5]              // 0000002B7A54: D6FE7C12 0010110A
	.long 0xd72c000c                                           // 0000002B7A5C: D72C000C
	v_cndmask_b32_e32 v0, v10, v9, vcc_lo                      // 0000002B7A60: 0200130A
	.long 0xd72c000e                                           // 0000002B7A64: D72C000E
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 0000002B7A68: 02001109
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v40, 0              // 0000002B7A6C: CA100080 09280080
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v10, 0             // 0000002B7A74: CA100080 0B0A0080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002B7A7C: BF870003
	v_add3_u32 v30, v14, v19, v12                              // 0000002B7A80: D655001E 0432270E
	v_mov_b32_e32 v12, 0                                       // 0000002B7A88: 7E180280
	s_and_saveexec_b32 s4, s1                                  // 0000002B7A8C: BE842001
	s_cbranch_execz 22                                         // 0000002B7A90: BFA50016 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x5ec>
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v9, 4, v26     // 0000002B7A94: CA220080 28083484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B7A9C: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000002B7AA0: 3414129F
	.long 0xd7006a09                                           // 0000002B7AA4: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 0000002B7AA8: 02021312
	v_add_co_ci_u32_e64 v10, null, v30, v10, vcc_lo            // 0000002B7AAC: D5207C0A 01AA151E
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 0000002B7AB4: 916A067E
	global_load_b128 v[9:12], v[9:10], off                     // 0000002B7AB8: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 0000002B7AC0: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x5ec>
	v_lshlrev_b32_e32 v14, 1, v26                              // 0000002B7AC4: 301C3481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7AC8: BF870091
	.long 0xd7006a0e                                           // 0000002B7ACC: D7006A0E
	v_cndmask_b32_e32 v1, v17, v14, vcc_lo                     // 0000002B7AD0: 02021D11
	v_add_co_ci_u32_e64 v15, null, 0, v27, vcc_lo              // 0000002B7AD4: D5207C0F 01AA3680
	global_load_d16_b16 v14, v[14:15], off                     // 0000002B7ADC: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 0000002B7AE4: BF8903F7
	v_cvt_f32_f16_e32 v40, v14                                 // 0000002B7AE8: 7E50170E
	s_or_b32 exec_lo, exec_lo, s4                              // 0000002B7AEC: 8C7E047E
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v33, 0             // 0000002B7AF0: CA100080 20200080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 0000002B7AF8: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v31, 0             // 0000002B7B00: CA100080 241E0080
	s_and_saveexec_b32 s8, s1                                  // 0000002B7B08: BE882001
	s_cbranch_execz 559                                        // 0000002B7B0C: BFA5022F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0xecc>
	v_dual_mov_b32 v31, 0 :: v_dual_lshlrev_b32 v14, 5, v24    // 0000002B7B10: CA220080 1F0E3085
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v15, 32, v26    // 0000002B7B18: CA200080 240E34A0
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0             // 0000002B7B20: CA100080 21200080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B7B28: BF870193
	v_lshl_add_u32 v19, v13, 5, v14                            // 0000002B7B2C: D6460013 04390B0D
	v_dual_mov_b32 v34, 0 :: v_dual_lshlrev_b32 v37, 4, v15    // 0000002B7B34: CA220080 22241E84
	v_dual_mov_b32 v35, 0 :: v_dual_lshlrev_b32 v38, 1, v15    // 0000002B7B3C: CA220080 23261E81
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v39, v40           // 0000002B7B44: CA100080 1C260128
	s_mul_i32 s1, s15, 6                                       // 0000002B7B4C: 9601860F
	s_mul_hi_u32 s6, s14, 6                                    // 0000002B7B50: 9686860E
	s_lshl_b64 s[4:5], s[14:15], 2                             // 0000002B7B54: 8484820E
	s_add_i32 s9, s6, s1                                       // 0000002B7B58: 81090106
	s_mul_i32 s19, s14, 6                                      // 0000002B7B5C: 9613860E
	s_mov_b32 s18, 0                                           // 0000002B7B60: BE920080
	s_lshl_b64 s[6:7], s[14:15], 1                             // 0000002B7B64: 8486810E
	s_branch 500                                               // 0000002B7B68: BFA001F4 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0xe3c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000002B7B6C: 8C7E0E7E
	v_ashrrev_i32_e32 v20, 31, v19                             // 0000002B7B70: 3428269F
	v_cndmask_b32_e64 v89, v40, v1, s0                         // 0000002B7B74: D5010059 00020328
	v_cndmask_b32_e64 v41, v1, v2, s0                          // 0000002B7B7C: D5010029 00020501
	v_dual_mov_b32 v48, v8 :: v_dual_and_b32 v1, 0xff, v9      // 0000002B7B84: CA240108 300012FF 000000FF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002B7B90: BF870004
	.long 0xd73c0014                                           // 0000002B7B94: D73C0014
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000002B7B98: 02022681
	v_cndmask_b32_e64 v42, v2, v3, s0                          // 0000002B7B9C: D501002A 00020702
	v_lshrrev_b32_e32 v2, 6, v9                                // 0000002B7BA4: 32041286
	v_cndmask_b32_e64 v43, v3, v4, s0                          // 0000002B7BA8: D501002B 00020903
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002B7BB0: 30020282
	v_lshrrev_b32_e32 v3, 14, v9                               // 0000002B7BB4: 3206128E
	.long 0xd7006a14                                           // 0000002B7BB8: D7006A14
	v_cndmask_b32_e32 v1, s12, v20, vcc_lo                     // 0000002B7BBC: 0202280C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002B7BC0: BF8701A1
	v_add_co_ci_u32_e64 v21, null, s13, v21, vcc_lo            // 0000002B7BC4: D5207C15 01AA2A0D
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000002B7BCC: 360404FF 000003FC
	.long 0xd7006a49                                           // 0000002B7BD4: D7006A49
	v_cndmask_b32_e32 v0, v20, v6, vcc_lo                      // 0000002B7BD8: 02000D14
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B7BDC: BF870001
	v_add_co_ci_u32_e64 v74, null, s7, v21, vcc_lo             // 0000002B7BE0: D5207C4A 01AA2A07
	.long 0xd7006a4d                                           // 0000002B7BE8: D7006A4D
	v_cndmask_b32_e32 v0, v20, v4, vcc_lo                      // 0000002B7BEC: 02000914
	s_clause 0x1                                               // 0000002B7BF0: BF850001
	global_load_b128 v[49:52], v[20:21], off                   // 0000002B7BF4: DC5E0000 317C0014
	global_load_b128 v[53:56], v[73:74], off                   // 0000002B7BFC: DC5E0000 357C0049
	v_add_co_ci_u32_e64 v78, null, s5, v21, vcc_lo             // 0000002B7C04: D5207C4E 01AA2A05
	.long 0xd7006a4f                                           // 0000002B7C0C: D7006A4F
	v_cndmask_b32_e32 v0, v20, v19, vcc_lo                     // 0000002B7C10: 02002714
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B7C14: BF8700A1
	v_add_co_ci_u32_e64 v80, null, s9, v21, vcc_lo             // 0000002B7C18: D5207C50 01AA2A09
	.long 0xd7006a51                                           // 0000002B7C20: D7006A51
	v_cndmask_b32_e32 v0, v77, v4, vcc_lo                      // 0000002B7C24: 0200094D
	v_add_co_ci_u32_e64 v82, null, s5, v78, vcc_lo             // 0000002B7C28: D5207C52 01AA9C05
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002B7C30: BF870004
	.long 0xd7006a55                                           // 0000002B7C34: D7006A55
	v_cndmask_b32_e32 v0, v79, v4, vcc_lo                      // 0000002B7C38: 0200094F
	s_clause 0x1                                               // 0000002B7C3C: BF850001
	global_load_b128 v[57:60], v[77:78], off                   // 0000002B7C40: DC5E0000 397C004D
	global_load_b128 v[61:64], v[79:80], off                   // 0000002B7C48: DC5E0000 3D7C004F
	v_add_co_ci_u32_e64 v86, null, s5, v80, vcc_lo             // 0000002B7C50: D5207C56 01AAA005
	s_clause 0x1                                               // 0000002B7C58: BF850001
	global_load_b128 v[65:68], v[81:82], off                   // 0000002B7C5C: DC5E0000 417C0051
	global_load_b128 v[69:72], v[85:86], off                   // 0000002B7C64: DC5E0000 457C0055
	ds_load_b32 v75, v1                                        // 0000002B7C6C: D8D80000 4B000001
	ds_load_b32 v90, v2                                        // 0000002B7C74: D8D80000 5A000002
	v_and_b32_e32 v1, 0x3fc, v3                                // 0000002B7C7C: 360206FF 000003FC
	v_cndmask_b32_e64 v44, v4, v5, s0                          // 0000002B7C84: D501002C 00020B04
	v_lshrrev_b32_e32 v4, 22, v9                               // 0000002B7C8C: 32081296
	v_cndmask_b32_e64 v45, v5, v6, s0                          // 0000002B7C90: D501002D 00020D05
	v_and_b32_e32 v5, 0xff, v10                                // 0000002B7C98: 360A14FF 000000FF
	ds_load_b32 v93, v1                                        // 0000002B7CA0: D8D80000 5D000001
	v_cndmask_b32_e64 v46, v6, v7, s0                          // 0000002B7CA8: D501002E 00020F06
	v_lshrrev_b32_e32 v6, 6, v10                               // 0000002B7CB0: 320C1486
	v_cndmask_b32_e64 v47, v7, v8, s0                          // 0000002B7CB4: D501002F 00021107
	v_lshrrev_b32_e32 v7, 14, v10                              // 0000002B7CBC: 320E148E
	v_lshrrev_b32_e32 v8, 22, v10                              // 0000002B7CC0: 32101496
	v_and_b32_e32 v2, 0x3fc, v4                                // 0000002B7CC4: 360408FF 000003FC
	v_and_b32_e32 v91, 0xff, v12                               // 0000002B7CCC: 36B618FF 000000FF
	v_lshrrev_b32_e32 v92, 6, v12                              // 0000002B7CD4: 32B81886
	v_lshrrev_b32_e32 v99, 14, v12                             // 0000002B7CD8: 32C6188E
	v_lshrrev_b32_e32 v100, 22, v12                            // 0000002B7CDC: 32C81896
	s_waitcnt vmcnt(6)                                         // 0000002B7CE0: BF891BF7
	v_dual_mov_b32 v12, v16 :: v_dual_lshlrev_b32 v3, 2, v5    // 0000002B7CE4: CA220110 0C020A82
	v_and_b32_e32 v1, 0x3fc, v6                                // 0000002B7CEC: 36020CFF 000003FC
	v_and_b32_e32 v4, 0x3fc, v7                                // 0000002B7CF4: 36080EFF 000003FC
	v_and_b32_e32 v5, 0x3fc, v8                                // 0000002B7CFC: 360A10FF 000003FC
	ds_load_b32 v94, v2                                        // 0000002B7D04: D8D80000 5E000002
	ds_load_b32 v95, v3                                        // 0000002B7D0C: D8D80000 5F000003
	ds_load_b32 v96, v1                                        // 0000002B7D14: D8D80000 60000001
	ds_load_b32 v97, v4                                        // 0000002B7D1C: D8D80000 61000004
	ds_load_b32 v98, v5                                        // 0000002B7D24: D8D80000 62000005
	.long 0xd7006a57                                           // 0000002B7D2C: D7006A57
	v_cndmask_b32_e32 v0, v81, v4, vcc_lo                      // 0000002B7D30: 02000951
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B7D34: BF870001
	v_add_co_ci_u32_e64 v88, null, s5, v82, vcc_lo             // 0000002B7D38: D5207C58 01AAA405
	s_clause 0x1                                               // 0000002B7D40: BF850001
	global_load_b128 v[1:4], v[20:21], off offset:16           // 0000002B7D44: DC5E0010 017C0014
	global_load_b128 v[5:8], v[73:74], off offset:16           // 0000002B7D4C: DC5E0010 057C0049
	v_and_b32_e32 v40, 0xff, v11                               // 0000002B7D54: 365016FF 000000FF
	v_lshrrev_b32_e32 v76, 6, v11                              // 0000002B7D5C: 32981686
	v_lshrrev_b32_e32 v83, 14, v11                             // 0000002B7D60: 32A6168E
	v_lshrrev_b32_e32 v84, 22, v11                             // 0000002B7D64: 32A81696
	v_mov_b32_e32 v11, v15                                     // 0000002B7D68: 7E16030F
	v_add_nc_u32_e32 v37, 0x200, v37                           // 0000002B7D6C: 4A4A4AFF 00000200
	v_add_nc_u32_e32 v38, 64, v38                              // 0000002B7D74: 4A4C4CC0
	v_add_nc_u32_e32 v19, 0x400, v19                           // 0000002B7D78: 4A2626FF 00000400
	s_and_b32 s1, exec_lo, s1                                  // 0000002B7D80: 8B01017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B7D84: BF870009
	s_or_b32 s18, s1, s18                                      // 0000002B7D88: 8C121201
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000002B7D8C: BF891C77
	v_dot2_f32_bf16 v9, v49, v75, 0                            // 0000002B7D90: CC1A4009 1A029731
	s_waitcnt vmcnt(6)                                         // 0000002B7D98: BF891BF7
	v_dot2_f32_bf16 v10, v53, v75, 0                           // 0000002B7D9C: CC1A400A 1A029735
	s_waitcnt lgkmcnt(6)                                       // 0000002B7DA4: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B7DA8: BF870112
	v_dot2_f32_bf16 v9, v50, v90, v9                           // 0000002B7DAC: CC1A4009 1C26B532
	v_dot2_f32_bf16 v16, v54, v90, v10                         // 0000002B7DB4: CC1A4010 1C2AB536
	v_mov_b32_e32 v10, v14                                     // 0000002B7DBC: 7E14030E
	s_waitcnt lgkmcnt(5)                                       // 0000002B7DC0: BF89FC57
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B7DC4: BF870193
	v_dot2_f32_bf16 v49, v51, v93, v9                          // 0000002B7DC8: CC1A4031 1C26BB33
	v_dot2_f32_bf16 v53, v55, v93, v16                         // 0000002B7DD0: CC1A4035 1C42BB37
	v_mov_b32_e32 v9, v13                                      // 0000002B7DD8: 7E12030D
	s_waitcnt vmcnt(5)                                         // 0000002B7DDC: BF8917F7
	v_dot2_f32_bf16 v54, v57, v75, 0                           // 0000002B7DE0: CC1A4036 1A029739
	global_load_b128 v[13:16], v[77:78], off offset:16         // 0000002B7DE8: DC5E0010 0D7C004D
	s_waitcnt lgkmcnt(4)                                       // 0000002B7DF0: BF89FC47
	v_dot2_f32_bf16 v101, v52, v94, v49                        // 0000002B7DF4: CC1A4065 1CC6BD34
	v_dot2_f32_bf16 v102, v56, v94, v53                        // 0000002B7DFC: CC1A4066 1CD6BD38
	s_waitcnt vmcnt(5)                                         // 0000002B7E04: BF8917F7
	v_dot2_f32_bf16 v53, v61, v75, 0                           // 0000002B7E08: CC1A4035 1A02973D
	s_waitcnt vmcnt(4)                                         // 0000002B7E10: BF8913F7
	v_dot2_f32_bf16 v61, v65, v75, 0                           // 0000002B7E14: CC1A403D 1A029741
	v_dot2_f32_bf16 v54, v58, v90, v54                         // 0000002B7E1C: CC1A4036 1CDAB53A
	global_load_b128 v[49:52], v[79:80], off offset:16         // 0000002B7E24: DC5E0010 317C004F
	v_dot2_f32_bf16 v53, v62, v90, v53                         // 0000002B7E2C: CC1A4035 1CD6B53E
	s_waitcnt vmcnt(4)                                         // 0000002B7E34: BF8913F7
	v_dot2_f32_bf16 v62, v69, v75, 0                           // 0000002B7E38: CC1A403E 1A029745
	v_dot2_f32_bf16 v61, v66, v90, v61                         // 0000002B7E40: CC1A403D 1CF6B542
	v_dot2_f32_bf16 v54, v59, v93, v54                         // 0000002B7E48: CC1A4036 1CDABB3B
	v_dot2_f32_bf16 v57, v63, v93, v53                         // 0000002B7E50: CC1A4039 1CD6BB3F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002B7E58: BF870214
	v_dot2_f32_bf16 v62, v70, v90, v62                         // 0000002B7E5C: CC1A403E 1CFAB546
	v_dot2_f32_bf16 v61, v67, v93, v61                         // 0000002B7E64: CC1A403D 1CF6BB43
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002B7E6C: BF870004
	v_dot2_f32_bf16 v103, v60, v94, v54                        // 0000002B7E70: CC1A4067 1CDABD3C
	global_load_b128 v[53:56], v[81:82], off offset:16         // 0000002B7E78: DC5E0010 357C0051
	v_dot2_f32_bf16 v104, v64, v94, v57                        // 0000002B7E80: CC1A4068 1CE6BD40
	v_dot2_f32_bf16 v62, v71, v93, v62                         // 0000002B7E88: CC1A403E 1CFABB47
	v_dot2_f32_bf16 v69, v68, v94, v61                         // 0000002B7E90: CC1A4045 1CF6BD44
	global_load_b128 v[57:60], v[85:86], off offset:16         // 0000002B7E98: DC5E0010 397C0055
	v_dot2_f32_bf16 v70, v72, v94, v62                         // 0000002B7EA0: CC1A4046 1CFABD48
	s_clause 0x1                                               // 0000002B7EA8: BF850001
	global_load_b128 v[61:64], v[87:88], off                   // 0000002B7EAC: DC5E0000 3D7C0057
	global_load_b128 v[65:68], v[87:88], off offset:16         // 0000002B7EB4: DC5E0010 417C0057
	v_and_b32_e32 v72, 0x3fc, v76                              // 0000002B7EBC: 369098FF 000003FC
	v_and_b32_e32 v76, 0x3fc, v84                              // 0000002B7EC4: 3698A8FF 000003FC
	v_and_b32_e32 v84, 0x3fc, v92                              // 0000002B7ECC: 36A8B8FF 000003FC
	s_waitcnt vmcnt(1)                                         // 0000002B7ED4: BF8907F7
	v_dot2_f32_bf16 v61, v61, v75, 0                           // 0000002B7ED8: CC1A403D 1A02973D
	v_and_b32_e32 v75, 0x3fc, v83                              // 0000002B7EE0: 3696A6FF 000003FC
	v_lshlrev_b32_e32 v83, 2, v91                              // 0000002B7EE8: 30A6B682
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7EEC: BF870093
	v_dot2_f32_bf16 v61, v62, v90, v61                         // 0000002B7EF0: CC1A403D 1CF6B53E
	v_dot2_f32_bf16 v61, v63, v93, v61                         // 0000002B7EF8: CC1A403D 1CF6BB3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002B7F00: BF8700D1
	v_dot2_f32_bf16 v71, v64, v94, v61                         // 0000002B7F04: CC1A4047 1CF6BD40
	global_load_b128 v[61:64], v[20:21], off offset:32         // 0000002B7F0C: DC5E0020 3D7C0014
	s_waitcnt lgkmcnt(3)                                       // 0000002B7F14: BF89FC37
	v_dot2_f32_bf16 v1, v1, v95, v101                          // 0000002B7F18: CC1A4001 1D96BF01
	s_waitcnt lgkmcnt(2)                                       // 0000002B7F20: BF89FC27
	v_dot2_f32_bf16 v1, v2, v96, v1                            // 0000002B7F24: CC1A4001 1C06C102
	v_dot2_f32_bf16 v2, v5, v95, v102                          // 0000002B7F2C: CC1A4002 1D9ABF05
	v_dot2_f32_bf16 v5, v13, v95, v103                         // 0000002B7F34: CC1A4005 1D9EBF0D
	v_dot2_f32_bf16 v13, v53, v95, v69                         // 0000002B7F3C: CC1A400D 1D16BF35
	s_waitcnt vmcnt(1)                                         // 0000002B7F44: BF8907F7
	v_dot2_f32_bf16 v53, v65, v95, v71                         // 0000002B7F48: CC1A4035 1D1EBF41
	s_waitcnt lgkmcnt(1)                                       // 0000002B7F50: BF89FC17
	v_dot2_f32_bf16 v1, v3, v97, v1                            // 0000002B7F54: CC1A4001 1C06C303
	v_dot2_f32_bf16 v2, v6, v96, v2                            // 0000002B7F5C: CC1A4002 1C0AC106
	v_dot2_f32_bf16 v6, v49, v95, v104                         // 0000002B7F64: CC1A4006 1DA2BF31
	v_dot2_f32_bf16 v49, v57, v95, v70                         // 0000002B7F6C: CC1A4031 1D1ABF39
	v_dot2_f32_bf16 v5, v14, v96, v5                           // 0000002B7F74: CC1A4005 1C16C10E
	v_dot2_f32_bf16 v65, v66, v96, v53                         // 0000002B7F7C: CC1A4041 1CD6C142
	v_dot2_f32_bf16 v7, v7, v97, v2                            // 0000002B7F84: CC1A4007 1C0AC307
	v_dot2_f32_bf16 v14, v50, v96, v6                          // 0000002B7F8C: CC1A400E 1C1AC132
	v_dot2_f32_bf16 v50, v54, v96, v13                         // 0000002B7F94: CC1A4032 1C36C136
	v_dot2_f32_bf16 v54, v58, v96, v49                         // 0000002B7F9C: CC1A4036 1CC6C13A
	v_and_b32_e32 v66, 0x3fc, v99                              // 0000002B7FA4: 3684C6FF 000003FC
	ds_load_b32 v96, v75                                       // 0000002B7FAC: D8D80000 6000004B
	v_and_b32_e32 v75, 0x3fc, v100                             // 0000002B7FB4: 3696C8FF 000003FC
	s_waitcnt lgkmcnt(1)                                       // 0000002B7FBC: BF89FC17
	v_dot2_f32_bf16 v91, v4, v98, v1                           // 0000002B7FC0: CC1A405B 1C06C504
	v_dot2_f32_bf16 v57, v59, v97, v54                         // 0000002B7FC8: CC1A4039 1CDAC33B
	global_load_b128 v[1:4], v[73:74], off offset:32           // 0000002B7FD0: DC5E0020 017C0049
	v_dot2_f32_bf16 v15, v15, v97, v5                          // 0000002B7FD8: CC1A400F 1C16C30F
	v_dot2_f32_bf16 v92, v8, v98, v7                           // 0000002B7FE0: CC1A405C 1C1EC508
	global_load_b128 v[5:8], v[77:78], off offset:32           // 0000002B7FE8: DC5E0020 057C004D
	v_dot2_f32_bf16 v51, v51, v97, v14                         // 0000002B7FF0: CC1A4033 1C3AC333
	v_dot2_f32_bf16 v55, v55, v97, v50                         // 0000002B7FF8: CC1A4037 1CCAC337
	v_dot2_f32_bf16 v99, v60, v98, v57                         // 0000002B8000: CC1A4063 1CE6C53C
	global_load_b128 v[57:60], v[20:21], off offset:48         // 0000002B8008: DC5E0030 397C0014
	v_dot2_f32_bf16 v20, v67, v97, v65                         // 0000002B8010: CC1A4014 1D06C343
	ds_load_b32 v21, v76                                       // 0000002B8018: D8D80000 1500004C
	ds_load_b32 v97, v83                                       // 0000002B8020: D8D80000 61000053
	ds_load_b32 v100, v84                                      // 0000002B8028: D8D80000 64000054
	ds_load_b32 v101, v66                                      // 0000002B8030: D8D80000 65000042
	ds_load_b32 v102, v75                                      // 0000002B8038: D8D80000 6600004B
	global_load_b128 v[73:76], v[73:74], off offset:48         // 0000002B8040: DC5E0030 497C0049
	v_lshlrev_b32_e32 v40, 2, v40                              // 0000002B8048: 30505082
	ds_load_b32 v40, v40                                       // 0000002B804C: D8D80000 28000028
	ds_load_b32 v90, v72                                       // 0000002B8054: D8D80000 5A000048
	v_dot2_f32_bf16 v93, v16, v98, v15                         // 0000002B805C: CC1A405D 1C3EC510
	global_load_b128 v[13:16], v[79:80], off offset:32         // 0000002B8064: DC5E0020 0D7C004F
	v_dot2_f32_bf16 v94, v52, v98, v51                         // 0000002B806C: CC1A405E 1CCEC534
	s_clause 0x1                                               // 0000002B8074: BF850001
	global_load_b128 v[49:52], v[81:82], off offset:32         // 0000002B8078: DC5E0020 317C0051
	global_load_b128 v[69:72], v[85:86], off offset:32         // 0000002B8080: DC5E0020 457C0055
	v_dot2_f32_bf16 v95, v56, v98, v55                         // 0000002B8088: CC1A405F 1CDEC538
	global_load_b128 v[53:56], v[87:88], off offset:32         // 0000002B8090: DC5E0020 357C0057
	v_dot2_f32_bf16 v20, v68, v98, v20                         // 0000002B8098: CC1A4014 1C52C544
	s_clause 0x2                                               // 0000002B80A0: BF850002
	global_load_b128 v[65:68], v[77:78], off offset:48         // 0000002B80A4: DC5E0030 417C004D
	global_load_b128 v[77:80], v[79:80], off offset:48         // 0000002B80AC: DC5E0030 4D7C004F
	global_load_b128 v[81:84], v[81:82], off offset:48         // 0000002B80B4: DC5E0030 517C0051
	s_waitcnt vmcnt(11) lgkmcnt(1)                             // 0000002B80BC: BF892C17
	v_dot2_f32_bf16 v61, v61, v40, v91                         // 0000002B80C0: CC1A403D 1D6E513D
	s_waitcnt lgkmcnt(0)                                       // 0000002B80C8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B80CC: BF870091
	v_dot2_f32_bf16 v61, v62, v90, v61                         // 0000002B80D0: CC1A403D 1CF6B53E
	v_dot2_f32_bf16 v61, v63, v96, v61                         // 0000002B80D8: CC1A403D 1CF6C13F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B80E0: BF870001
	v_dot2_f32_bf16 v91, v64, v21, v61                         // 0000002B80E4: CC1A405B 1CF62B40
	s_clause 0x1                                               // 0000002B80EC: BF850001
	global_load_b128 v[61:64], v[85:86], off offset:48         // 0000002B80F0: DC5E0030 3D7C0055
	global_load_b128 v[85:88], v[87:88], off offset:48         // 0000002B80F8: DC5E0030 557C0057
	s_waitcnt vmcnt(12)                                        // 0000002B8100: BF8933F7
	v_dot2_f32_bf16 v1, v1, v40, v92                           // 0000002B8104: CC1A4001 1D725101
	s_waitcnt vmcnt(11)                                        // 0000002B810C: BF892FF7
	v_dot2_f32_bf16 v5, v5, v40, v93                           // 0000002B8110: CC1A4005 1D765105
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B8118: BF870112
	v_dot2_f32_bf16 v1, v2, v90, v1                            // 0000002B811C: CC1A4001 1C06B502
	v_dot2_f32_bf16 v2, v6, v90, v5                            // 0000002B8124: CC1A4002 1C16B506
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B812C: BF870112
	v_dot2_f32_bf16 v1, v3, v96, v1                            // 0000002B8130: CC1A4001 1C06C103
	v_dot2_f32_bf16 v2, v7, v96, v2                            // 0000002B8138: CC1A4002 1C0AC107
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002B8140: BF870002
	v_dot2_f32_bf16 v1, v4, v21, v1                            // 0000002B8144: CC1A4001 1C062B04
	s_waitcnt vmcnt(10)                                        // 0000002B814C: BF892BF7
	v_dot2_f32_bf16 v4, v57, v97, v91                          // 0000002B8150: CC1A4004 1D6EC339
	s_waitcnt vmcnt(8)                                         // 0000002B8158: BF8923F7
	v_dot2_f32_bf16 v13, v13, v40, v94                         // 0000002B815C: CC1A400D 1D7A510D
	v_dot2_f32_bf16 v2, v8, v21, v2                            // 0000002B8164: CC1A4002 1C0A2B08
	s_waitcnt vmcnt(7)                                         // 0000002B816C: BF891FF7
	v_dot2_f32_bf16 v6, v49, v40, v95                          // 0000002B8170: CC1A4006 1D7E5131
	v_dot2_f32_bf16 v4, v58, v100, v4                          // 0000002B8178: CC1A4004 1C12C93A
	v_dot2_f32_bf16 v1, v73, v97, v1                           // 0000002B8180: CC1A4001 1C06C349
	v_dot2_f32_bf16 v5, v14, v90, v13                          // 0000002B8188: CC1A4005 1C36B50E
	s_waitcnt vmcnt(6)                                         // 0000002B8190: BF891BF7
	v_dot2_f32_bf16 v13, v69, v40, v99                         // 0000002B8194: CC1A400D 1D8E5145
	s_waitcnt vmcnt(5)                                         // 0000002B819C: BF8917F7
	v_dot2_f32_bf16 v14, v53, v40, v20                         // 0000002B81A0: CC1A400E 1C525135
	v_dot2_f32_bf16 v4, v59, v101, v4                          // 0000002B81A8: CC1A4004 1C12CB3B
	s_waitcnt vmcnt(4)                                         // 0000002B81B0: BF8913F7
	v_dot2_f32_bf16 v2, v65, v97, v2                           // 0000002B81B4: CC1A4002 1C0AC341
	v_dot2_f32_bf16 v3, v15, v96, v5                           // 0000002B81BC: CC1A4003 1C16C10F
	v_dot2_f32_bf16 v5, v50, v90, v6                           // 0000002B81C4: CC1A4005 1C1AB532
	v_dot2_f32_bf16 v6, v70, v90, v13                          // 0000002B81CC: CC1A4006 1C36B546
	v_dot2_f32_bf16 v7, v54, v90, v14                          // 0000002B81D4: CC1A4007 1C3AB536
	v_dot2_f32_bf16 v1, v74, v100, v1                          // 0000002B81DC: CC1A4001 1C06C94A
	v_dot2_f32_bf16 v3, v16, v21, v3                           // 0000002B81E4: CC1A4003 1C0E2B10
	v_dot2_f32_bf16 v5, v51, v96, v5                           // 0000002B81EC: CC1A4005 1C16C133
	v_dot2_f32_bf16 v6, v71, v96, v6                           // 0000002B81F4: CC1A4006 1C1AC147
	v_dot2_f32_bf16 v7, v55, v96, v7                           // 0000002B81FC: CC1A4007 1C1EC137
	v_dot2_f32_bf16 v4, v60, v102, v4                          // 0000002B8204: CC1A4004 1C12CD3C
	s_waitcnt vmcnt(3)                                         // 0000002B820C: BF890FF7
	v_dot2_f32_bf16 v3, v77, v97, v3                           // 0000002B8210: CC1A4003 1C0EC34D
	v_dot2_f32_bf16 v5, v52, v21, v5                           // 0000002B8218: CC1A4005 1C162B34
	v_dot2_f32_bf16 v6, v72, v21, v6                           // 0000002B8220: CC1A4006 1C1A2B48
	v_dot2_f32_bf16 v7, v56, v21, v7                           // 0000002B8228: CC1A4007 1C1E2B38
	v_dot2_f32_bf16 v2, v66, v100, v2                          // 0000002B8230: CC1A4002 1C0AC942
	v_dot2_f32_bf16 v3, v78, v100, v3                          // 0000002B8238: CC1A4003 1C0EC94E
	s_waitcnt vmcnt(2)                                         // 0000002B8240: BF890BF7
	v_dot2_f32_bf16 v5, v81, v97, v5                           // 0000002B8244: CC1A4005 1C16C351
	v_dot2_f32_bf16 v1, v75, v101, v1                          // 0000002B824C: CC1A4001 1C06CB4B
	v_fmac_f32_e32 v31, v89, v4                                // 0000002B8254: 563E0959
	v_dot2_f32_bf16 v2, v67, v101, v2                          // 0000002B8258: CC1A4002 1C0ACB43
	v_dot2_f32_bf16 v3, v79, v101, v3                          // 0000002B8260: CC1A4003 1C0ECB4F
	v_dot2_f32_bf16 v5, v82, v100, v5                          // 0000002B8268: CC1A4005 1C16C952
	v_dot2_f32_bf16 v1, v76, v102, v1                          // 0000002B8270: CC1A4001 1C06CD4C
	v_mov_b32_e32 v40, v39                                     // 0000002B8278: 7E500327
	v_dot2_f32_bf16 v2, v68, v102, v2                          // 0000002B827C: CC1A4002 1C0ACD44
	v_dot2_f32_bf16 v3, v80, v102, v3                          // 0000002B8284: CC1A4003 1C0ECD50
	v_dot2_f32_bf16 v5, v83, v101, v5                          // 0000002B828C: CC1A4005 1C16CB53
	v_fmac_f32_e32 v36, v89, v1                                // 0000002B8294: 56480359
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002B8298: BF870214
	v_fmac_f32_e32 v35, v89, v2                                // 0000002B829C: 56460559
	v_fmac_f32_e32 v34, v89, v3                                // 0000002B82A0: 56440759
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B82A4: BF870094
	v_dot2_f32_bf16 v1, v84, v102, v5                          // 0000002B82A8: CC1A4001 1C16CD54
	v_fmac_f32_e32 v33, v89, v1                                // 0000002B82B0: 56420359
	s_waitcnt vmcnt(1)                                         // 0000002B82B4: BF8907F7
	v_dot2_f32_bf16 v6, v61, v97, v6                           // 0000002B82B8: CC1A4006 1C1AC33D
	s_waitcnt vmcnt(0)                                         // 0000002B82C0: BF8903F7
	v_dot2_f32_bf16 v7, v85, v97, v7                           // 0000002B82C4: CC1A4007 1C1EC355
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B82CC: BF870112
	v_dot2_f32_bf16 v6, v62, v100, v6                          // 0000002B82D0: CC1A4006 1C1AC93E
	v_dot2_f32_bf16 v4, v86, v100, v7                          // 0000002B82D8: CC1A4004 1C1EC956
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B82E0: BF870112
	v_dot2_f32_bf16 v6, v63, v101, v6                          // 0000002B82E4: CC1A4006 1C1ACB3F
	v_dot2_f32_bf16 v4, v87, v101, v4                          // 0000002B82EC: CC1A4004 1C12CB57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B82F4: BF870112
	v_dot2_f32_bf16 v5, v64, v102, v6                          // 0000002B82F8: CC1A4005 1C1ACD40
	v_dot2_f32_bf16 v4, v88, v102, v4                          // 0000002B8300: CC1A4004 1C12CD58
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B8308: BF870112
	v_fmac_f32_e32 v32, v89, v5                                // 0000002B830C: 56400B59
	v_fmac_f32_e32 v28, v89, v4                                // 0000002B8310: 56380959
	v_dual_mov_b32 v1, v41 :: v_dual_mov_b32 v2, v42           // 0000002B8314: CA100129 0102012A
	v_dual_mov_b32 v3, v43 :: v_dual_mov_b32 v4, v44           // 0000002B831C: CA10012B 0304012C
	v_dual_mov_b32 v5, v45 :: v_dual_mov_b32 v6, v46           // 0000002B8324: CA10012D 0506012E
	v_dual_mov_b32 v7, v47 :: v_dual_mov_b32 v8, v48           // 0000002B832C: CA10012F 07080130
	s_and_not1_b32 exec_lo, exec_lo, s18                       // 0000002B8334: 917E127E
	s_cbranch_execz 35                                         // 0000002B8338: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0xec8>
	s_waitcnt vmcnt(0)                                         // 0000002B833C: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v26, 32, v26   // 0000002B8340: CA200109 0D1A34A0
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 0000002B8348: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 0000002B8350: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002B8354: BF870003
	.long 0xd4460001                                           // 0000002B8358: D4460001
	v_cndmask_b32_e32 v1, v26, v25, vcc_lo                     // 0000002B835C: 0202331A
	s_mov_b32 s14, exec_lo                                     // 0000002B8360: BE8E007E
	.long 0xd4c1007e                                           // 0000002B8364: D4C1007E
	v_cndmask_b32_e32 v1, v26, v25, vcc_lo                     // 0000002B8368: 0202331A
	s_cbranch_execz 65023                                      // 0000002B836C: BFA5FDFF <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x66c>
	v_ashrrev_i32_e32 v14, 31, v37                             // 0000002B8370: 341C4A9F
	.long 0xd7006a0d                                           // 0000002B8374: D7006A0D
	v_cndmask_b32_e32 v1, v18, v37, vcc_lo                     // 0000002B8378: 02024B12
	v_mov_b32_e32 v39, v40                                     // 0000002B837C: 7E4E0328
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002B8380: BF870003
	v_add_co_ci_u32_e64 v14, null, v30, v14, vcc_lo            // 0000002B8384: D5207C0E 01AA1D1E
	v_cmp_ne_u32_e32 vcc_lo, 1, v29                            // 0000002B838C: 7C9A3A81
	global_load_b128 v[13:16], v[13:14], off                   // 0000002B8390: DC5E0000 0D7C000D
	s_cbranch_vccnz 65012                                      // 0000002B8398: BFA4FDF4 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x66c>
	v_ashrrev_i32_e32 v21, 31, v38                             // 0000002B839C: 342A4C9F
	.long 0xd7006a14                                           // 0000002B83A0: D7006A14
	v_cndmask_b32_e32 v1, v17, v38, vcc_lo                     // 0000002B83A4: 02024D11
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B83A8: BF870001
	v_add_co_ci_u32_e64 v21, null, v27, v21, vcc_lo            // 0000002B83AC: D5207C15 01AA2B1B
	global_load_d16_b16 v20, v[20:21], off                     // 0000002B83B4: DC820000 147C0014
	s_waitcnt vmcnt(0)                                         // 0000002B83BC: BF8903F7
	v_cvt_f32_f16_e32 v39, v20                                 // 0000002B83C0: 7E4E1714
	s_branch 65001                                             // 0000002B83C4: BFA0FDE9 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x66c>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000002B83C8: 8C7E127E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002B83CC: BF8700B9
	s_or_b32 exec_lo, exec_lo, s8                              // 0000002B83D0: 8C7E087E
	.long 0xd71f0001                                           // 0000002B83D4: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002B83D8: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000002B83DC: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000002B83E0: 3A040290
	s_waitcnt vmcnt(0)                                         // 0000002B83E4: BF8903F7
	v_xor_b32_e32 v9, 8, v1                                    // 0000002B83E8: 3A120288
	v_xor_b32_e32 v16, 4, v1                                   // 0000002B83EC: 3A200284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002B83F0: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000002B83F4: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000002B83F8: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000002B83FC: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 0000002B8400: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000002B8404: 7C9820A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002B8408: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000002B840C: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000002B8410: 30040482
	ds_bpermute_b32 v3, v2, v31                                // 0000002B8414: DACC0000 03001F02
	s_waitcnt lgkmcnt(0)                                       // 0000002B841C: BF89FC07
	v_add_f32_e32 v3, v31, v3                                  // 0000002B8420: 0606071F
	ds_bpermute_b32 v5, v2, v35                                // 0000002B8424: DACC0000 05002302
	ds_bpermute_b32 v6, v2, v34                                // 0000002B842C: DACC0000 06002202
	ds_bpermute_b32 v7, v2, v33                                // 0000002B8434: DACC0000 07002102
	ds_bpermute_b32 v4, v2, v36                                // 0000002B843C: DACC0000 04002402
	ds_bpermute_b32 v8, v2, v32                                // 0000002B8444: DACC0000 08002002
	ds_bpermute_b32 v2, v2, v28                                // 0000002B844C: DACC0000 02001C02
	ds_bpermute_b32 v10, v9, v3                                // 0000002B8454: DACC0000 0A000309
	s_waitcnt lgkmcnt(6)                                       // 0000002B845C: BF89FC67
	v_dual_cndmask_b32 v16, v1, v16 :: v_dual_add_f32 v5, v35, v5// 0000002B8460: CA482101 10040B23
	s_waitcnt lgkmcnt(4)                                       // 0000002B8468: BF89FC47
	v_dual_add_f32 v6, v34, v6 :: v_dual_add_f32 v7, v33, v7   // 0000002B846C: C9080D22 06060F21
	s_waitcnt lgkmcnt(3)                                       // 0000002B8474: BF89FC37
	v_add_f32_e32 v4, v36, v4                                  // 0000002B8478: 06080924
	s_waitcnt lgkmcnt(2)                                       // 0000002B847C: BF89FC27
	v_add_f32_e32 v8, v32, v8                                  // 0000002B8480: 06101120
	ds_bpermute_b32 v12, v9, v5                                // 0000002B8484: DACC0000 0C000509
	s_waitcnt lgkmcnt(2)                                       // 0000002B848C: BF89FC27
	v_add_f32_e32 v2, v28, v2                                  // 0000002B8490: 0604051C
	ds_bpermute_b32 v14, v9, v7                                // 0000002B8494: DACC0000 0E000709
	ds_bpermute_b32 v11, v9, v4                                // 0000002B849C: DACC0000 0B000409
	ds_bpermute_b32 v13, v9, v6                                // 0000002B84A4: DACC0000 0D000609
	ds_bpermute_b32 v15, v9, v8                                // 0000002B84AC: DACC0000 0F000809
	s_waitcnt lgkmcnt(5)                                       // 0000002B84B4: BF89FC57
	v_dual_add_f32 v3, v3, v10 :: v_dual_lshlrev_b32 v16, 2, v16// 0000002B84B8: C9221503 03102082
	s_waitcnt lgkmcnt(4)                                       // 0000002B84C0: BF89FC47
	v_add_f32_e32 v5, v5, v12                                  // 0000002B84C4: 060A1905
	ds_bpermute_b32 v9, v9, v2                                 // 0000002B84C8: DACC0000 09000209
	s_waitcnt lgkmcnt(0)                                       // 0000002B84D0: BF89FC07
	v_dual_add_f32 v7, v7, v14 :: v_dual_add_f32 v2, v2, v9    // 0000002B84D4: C9081D07 07021302
	ds_bpermute_b32 v9, v16, v3                                // 0000002B84DC: DACC0000 09000310
	v_add_f32_e32 v4, v4, v11                                  // 0000002B84E4: 06081704
	ds_bpermute_b32 v11, v16, v5                               // 0000002B84E8: DACC0000 0B000510
	v_add_f32_e32 v6, v6, v13                                  // 0000002B84F0: 060C1B06
	ds_bpermute_b32 v13, v16, v7                               // 0000002B84F4: DACC0000 0D000710
	s_waitcnt lgkmcnt(2)                                       // 0000002B84FC: BF89FC27
	v_dual_add_f32 v8, v8, v15 :: v_dual_add_f32 v3, v3, v9    // 0000002B8500: C9081F08 08021303
	ds_bpermute_b32 v10, v16, v4                               // 0000002B8508: DACC0000 0A000410
	s_waitcnt lgkmcnt(2)                                       // 0000002B8510: BF89FC27
	v_add_f32_e32 v5, v5, v11                                  // 0000002B8514: 060A1705
	ds_bpermute_b32 v12, v16, v6                               // 0000002B8518: DACC0000 0C000610
	s_waitcnt lgkmcnt(2)                                       // 0000002B8520: BF89FC27
	v_add_f32_e32 v7, v7, v13                                  // 0000002B8524: 060E1B07
	ds_bpermute_b32 v14, v16, v8                               // 0000002B8528: DACC0000 0E000810
	s_waitcnt lgkmcnt(2)                                       // 0000002B8530: BF89FC27
	v_add_f32_e32 v4, v4, v10                                  // 0000002B8534: 06081504
	s_waitcnt lgkmcnt(0)                                       // 0000002B8538: BF89FC07
	v_add_f32_e32 v9, v8, v14                                  // 0000002B853C: 06121D08
	ds_bpermute_b32 v15, v16, v2                               // 0000002B8540: DACC0000 0F000210
	v_xor_b32_e32 v16, 2, v1                                   // 0000002B8548: 3A200282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002B854C: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000002B8550: 7C9820A0
	s_waitcnt lgkmcnt(0)                                       // 0000002B8554: BF89FC07
	v_dual_cndmask_b32 v16, v1, v16 :: v_dual_add_f32 v11, v2, v15// 0000002B8558: CA482101 100A1F02
	v_lshlrev_b32_e32 v16, 2, v16                              // 0000002B8560: 30202082
	ds_bpermute_b32 v10, v16, v5                               // 0000002B8564: DACC0000 0A000510
	v_add_f32_e32 v6, v6, v12                                  // 0000002B856C: 060C1906
	ds_bpermute_b32 v2, v16, v3                                // 0000002B8570: DACC0000 02000310
	ds_bpermute_b32 v8, v16, v4                                // 0000002B8578: DACC0000 08000410
	ds_bpermute_b32 v13, v16, v7                               // 0000002B8580: DACC0000 0D000710
	ds_bpermute_b32 v14, v16, v9                               // 0000002B8588: DACC0000 0E000910
	ds_bpermute_b32 v12, v16, v6                               // 0000002B8590: DACC0000 0C000610
	ds_bpermute_b32 v15, v16, v11                              // 0000002B8598: DACC0000 0F000B10
	v_xor_b32_e32 v16, 1, v1                                   // 0000002B85A0: 3A200281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002B85A4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000002B85A8: 7C9820A0
	v_cndmask_b32_e32 v1, v1, v16, vcc_lo                      // 0000002B85AC: 02022101
	s_waitcnt lgkmcnt(5)                                       // 0000002B85B0: BF89FC57
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v16, 2, v1 // 0000002B85B4: C9220503 01100282
	s_waitcnt lgkmcnt(4)                                       // 0000002B85BC: BF89FC47
	v_dual_add_f32 v2, v4, v8 :: v_dual_add_f32 v3, v5, v10    // 0000002B85C0: C9081104 02021505
	s_waitcnt lgkmcnt(1)                                       // 0000002B85C8: BF89FC17
	v_add_f32_e32 v4, v6, v12                                  // 0000002B85CC: 06081906
	v_add_f32_e32 v8, v7, v13                                  // 0000002B85D0: 06101B07
	s_waitcnt lgkmcnt(0)                                       // 0000002B85D4: BF89FC07
	v_dual_add_f32 v10, v9, v14 :: v_dual_add_f32 v11, v11, v15// 0000002B85D8: C9081D09 0A0A1F0B
	ds_bpermute_b32 v5, v16, v1                                // 0000002B85E0: DACC0000 05000110
	ds_bpermute_b32 v6, v16, v2                                // 0000002B85E8: DACC0000 06000210
	ds_bpermute_b32 v7, v16, v3                                // 0000002B85F0: DACC0000 07000310
	ds_bpermute_b32 v9, v16, v4                                // 0000002B85F8: DACC0000 09000410
	ds_bpermute_b32 v12, v16, v8                               // 0000002B8600: DACC0000 0C000810
	ds_bpermute_b32 v13, v16, v10                              // 0000002B8608: DACC0000 0D000A10
	ds_bpermute_b32 v14, v16, v11                              // 0000002B8610: DACC0000 0E000B10
	v_cmpx_eq_u32_e32 0, v24                                   // 0000002B8618: 7D943080
	s_cbranch_execz 29                                         // 0000002B861C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x1194>
	s_waitcnt lgkmcnt(2)                                       // 0000002B8620: BF89FC27
	v_dual_add_f32 v8, v8, v12 :: v_dual_add_f32 v3, v3, v7    // 0000002B8624: C9081908 08020F03
	v_lshl_add_u32 v12, v22, s20, v23                          // 0000002B862C: D646000C 045C2916
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v1, v1, v5     // 0000002B8634: C9080D02 02000B01
	s_waitcnt lgkmcnt(0)                                       // 0000002B863C: BF89FC07
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v11, v11, v14  // 0000002B8640: C9081304 040A1D0B
	v_add_f32_e32 v10, v10, v13                                // 0000002B8648: 06141B0A
	v_mad_u32_u24 v5, v12, 28, 0x400                           // 0000002B864C: D60B0005 03FD390C 00000400
	v_mad_u32_u24 v6, v12, 28, 0x408                           // 0000002B8658: D60B0006 03FD390C 00000408
	v_mad_u32_u24 v7, v12, 28, 0x410                           // 0000002B8664: D60B0007 03FD390C 00000410
	v_mul_u32_u24_e32 v9, 28, v12                              // 0000002B8670: 1612189C
	ds_store_2addr_b32 v5, v1, v2 offset1:1                    // 0000002B8674: D8380100 00020105
	ds_store_2addr_b32 v6, v3, v4 offset1:1                    // 0000002B867C: D8380100 00040306
	ds_store_2addr_b32 v7, v8, v10 offset1:1                   // 0000002B8684: D8380100 000A0807
	ds_store_b32 v9, v11 offset:1048                           // 0000002B868C: D8340418 00000B09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002B8694: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B8698: BF870009
	s_and_b32 s0, s21, exec_lo                                 // 0000002B869C: 8B007E15
	s_cselect_b32 s0, 7, 28                                    // 0000002B86A0: 98009C87
	s_waitcnt lgkmcnt(0)                                       // 0000002B86A4: BF89FC07
	v_cmp_gt_u32_e32 vcc_lo, s0, v0                            // 0000002B86A8: 7C980000
	s_barrier                                                  // 0000002B86AC: BFBD0000
	buffer_gl0_inv                                             // 0000002B86B0: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 0000002B86B8: BE80206A
	s_cbranch_execz 425                                        // 0000002B86BC: BFA501A9 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x1864>
	.long 0xd7054000                                           // 0000002B86C0: D7054000
	v_cndmask_b32_e32 v0, v0, v165, vcc_lo                     // 0000002B86C4: 02014B00
	s_load_b32 s0, s[16:17], 0x40                              // 0000002B86C8: F4000008 F8000040
	.long 0x7f063880                                           // 0000002B86D0: 7F063880
	v_mov_b32_e32 v4, 0                                        // 0000002B86D4: 7E080280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B86D8: BF870093
	.long 0xd7395000                                           // 0000002B86DC: D7395000
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 0000002B86E0: 02020088
	.long 0xd7041001                                           // 0000002B86E4: D7041001
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000002B86E8: 02020100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B86EC: BF870091
	.long 0xd7390001                                           // 0000002B86F0: D7390001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002B86F4: 02020281
	.long 0xd7620001                                           // 0000002B86F8: D7620001
	v_cndmask_b32_e32 v1, 0x7f, v1, vcc_lo                     // 0000002B86FC: 020202FF 0000007F
	s_waitcnt lgkmcnt(0)                                       // 0000002B8704: BF89FC07
	s_sub_i32 s0, s2, s0                                       // 0000002B8708: 81800002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002B870C: BF870499
	s_ashr_i32 s1, s0, 31                                      // 0000002B8710: 86019F00
	s_lshl_b64 s[0:1], s[0:1], s22                             // 0000002B8714: 84801600
	.long 0xd7035000                                           // 0000002B8718: D7035000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002B871C: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8720: BF870091
	.long 0xd7391003                                           // 0000002B8724: D7391003
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000002B8728: 02020082
	.long 0xd7000001                                           // 0000002B872C: D7000001
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000002B8730: 02020600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8734: BF870091
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 0000002B8738: D5207C02 00010001
	v_cmp_gt_i64_e32 vcc_lo, s[10:11], v[1:2]                  // 0000002B8740: 7CA8020A
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000002B8744: 8B7E6A7E
	s_cbranch_execz 390                                        // 0000002B8748: BFA50186 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x1864>
	.long 0xd7054000                                           // 0000002B874C: D7054000
	v_cndmask_b32_e32 v0, v3, v135, vcc_lo                     // 0000002B8750: 02010F03
	v_lshlrev_b32_e32 v3, s20, v3                              // 0000002B8754: 30060614
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B8758: BF870112
	.long 0xd7041000                                           // 0000002B875C: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000002B8760: 02020100
	v_mul_u32_u24_e32 v3, 28, v3                               // 0000002B8764: 1606069C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8768: BF870092
	v_and_b32_e32 v5, 0xff, v0                                 // 0000002B876C: 360A00FF 000000FF
	v_lshl_add_u32 v3, v5, 2, v3                               // 0000002B8774: D6460003 040D0505
	ds_load_b32 v5, v3 offset:1024                             // 0000002B877C: D8D80400 05000003
	v_add_nc_u32_e32 v3, 28, v3                                // 0000002B8784: 4A06069C
	s_add_i32 s3, s3, -1                                       // 0000002B8788: 8103C103
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B878C: BF870009
	s_cmp_eq_u32 s3, 0                                         // 0000002B8790: BF068003
	s_waitcnt lgkmcnt(0)                                       // 0000002B8794: BF89FC07
	v_add_f32_e32 v4, v4, v5                                   // 0000002B8798: 06080B04
	s_cbranch_scc0 65527                                       // 0000002B879C: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x127c>
	s_clause 0x1                                               // 0000002B87A0: BF850001
	s_load_b64 s[4:5], s[16:17], 0x38                          // 0000002B87A4: F4040108 F8000038
	s_load_b64 s[2:3], s[16:17], 0x8                           // 0000002B87AC: F4040088 F8000008
	v_and_b32_e32 v3, 0xff, v0                                 // 0000002B87B4: 360600FF 000000FF
	s_mov_b32 s6, -1                                           // 0000002B87BC: BE8600C1
	s_mov_b32 s1, 0                                            // 0000002B87C0: BE810080
	s_mov_b32 s0, 0                                            // 0000002B87C4: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000002B87C8: BF89FC07
	s_cmp_lt_i32 s5, 3                                         // 0000002B87CC: BF048305
	s_cbranch_scc1 191                                         // 0000002B87D0: BFA200BF <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x15d0>
	s_cmp_gt_i32 s5, 3                                         // 0000002B87D4: BF028305
	s_cbranch_scc0 125                                         // 0000002B87D8: BFA1007D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x14d0>
	s_cmp_gt_i32 s5, 4                                         // 0000002B87DC: BF028405
	s_cbranch_scc0 70                                          // 0000002B87E0: BFA10046 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x13fc>
	s_cmp_eq_u32 s5, 5                                         // 0000002B87E4: BF068505
	s_mov_b32 s0, -1                                           // 0000002B87E8: BE8000C1
	s_cbranch_scc0 66                                          // 0000002B87EC: BFA10042 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x13f8>
	v_lshrrev_b32_e32 v0, 23, v2                               // 0000002B87F0: 32000497
	s_lshr_b32 s0, s11, 31                                     // 0000002B87F4: 85009F0B
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002B87F8: F4040208 F8000010
	s_add_u32 s6, s10, s0                                      // 0000002B8800: 8006000A
	s_addc_u32 s7, s11, 0                                      // 0000002B8804: 8207800B
	.long 0xd7006a00                                           // 0000002B8808: D7006A00
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002B880C: 02020101
	s_ashr_i64 s[6:7], s[6:7], 1                               // 0000002B8810: 86868106
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000002B8814: D5207C0A 01AA0480
	v_dual_mov_b32 v11, s3 :: v_dual_and_b32 v0, 0xfffffe00, v0// 0000002B881C: CA240003 0B0000FF FFFFFE00
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 0000002B8828: D6FE7C05 02020606
	v_bfe_u32 v14, v4, 16, 1                                   // 0000002B8830: D610000E 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8838: BF870093
	.long 0xd7016a08                                           // 0000002B883C: D7016A08
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002B8840: 02020101
	v_sub_co_ci_u32_e64 v9, null, v2, v10, vcc_lo              // 0000002B8844: D5217C09 01AA1502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B884C: BF870194
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 0000002B8850: D6FE7C06 041A0607
	.long 0xd700000c                                           // 0000002B8858: D700000C
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 0000002B885C: 020210FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002B8864: BF870003
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 0000002B8868: 7CA810FF 00000100
	v_mov_b32_e32 v7, s2                                       // 0000002B8870: 7E0E0202
	v_add_co_ci_u32_e64 v13, null, -1, v9, s0                  // 0000002B8874: D5207C0D 000212C1
	s_mov_b32 s0, 0                                            // 0000002B887C: BE800080
	.long 0xd73c0005                                           // 0000002B8880: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000002B8884: 02020A81
	s_waitcnt lgkmcnt(0)                                       // 0000002B8888: BF89FC07
	v_dual_cndmask_b32 v8, v12, v8 :: v_dual_cndmask_b32 v7, s8, v7// 0000002B888C: CA52110C 08060E08
	v_cndmask_b32_e32 v11, s9, v11, vcc_lo                     // 0000002B8894: 02161609
	v_cndmask_b32_e32 v9, v13, v9, vcc_lo                      // 0000002B8898: 0212130D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B889C: BF870093
	.long 0xd7006a07                                           // 0000002B88A0: D7006A07
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 0000002B88A4: 02020B07
	v_add_co_ci_u32_e64 v11, null, v11, v6, vcc_lo             // 0000002B88A8: D5207C0B 01AA0D0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B88B0: BF870193
	.long 0xd73c0005                                           // 0000002B88B4: D73C0005
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000002B88B8: 02021081
	.long 0xd7006a00                                           // 0000002B88BC: D7006A00
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000002B88C0: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002B88C4: BF8701A1
	v_add_co_ci_u32_e64 v7, null, v11, v10, vcc_lo             // 0000002B88C8: D5207C07 01AA150B
	v_add3_u32 v8, v4, v14, 0x7fff                             // 0000002B88D0: D6550008 03FE1D04 00007FFF
	.long 0xd7006a05                                           // 0000002B88DC: D7006A05
	v_cndmask_b32_e32 v1, v0, v5, vcc_lo                       // 0000002B88E0: 02020B00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B88E4: BF870001
	v_add_co_ci_u32_e64 v6, null, v7, v6, vcc_lo               // 0000002B88E8: D5207C06 01AA0D07
	global_store_d16_hi_b16 v[5:6], v8, off                    // 0000002B88F0: DC960000 007C0805
	s_mov_b32 s6, 0                                            // 0000002B88F8: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B88FC: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002B8900: 8B6A067E
	s_cbranch_vccz 49                                          // 0000002B8904: BFA30031 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x14cc>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v4                           // 0000002B8908: 100008FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B8910: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002B8914: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002B8918: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B891C: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 0000002B8920: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 0000002B8928: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 0000002B8930: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8934: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 0000002B8938: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 0000002B8940: 56121305
	v_mad_u64_u32 v[5:6], null, s10, v3, 0                     // 0000002B8944: D6FE7C05 0202060A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B894C: BF870112
	v_mul_f32_e32 v11, v10, v9                                 // 0000002B8950: 1016130A
	v_mad_u64_u32 v[6:7], null, s11, v3, v[6:7]                // 0000002B8954: D6FE7C06 041A060B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B895C: BF870092
	v_fma_f32 v12, -v8, v11, v10                               // 0000002B8960: D613000C 242A1708
	v_fmac_f32_e32 v11, v12, v9                                // 0000002B8968: 5616130C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B896C: BF870113
	.long 0xd73c0005                                           // 0000002B8970: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000002B8974: 02020A82
	v_fma_f32 v10, -v8, v11, v10                               // 0000002B8978: D613000A 242A1708
	.long 0xd73c0007                                           // 0000002B8980: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000002B8984: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002B8988: BF870212
	v_div_fmas_f32 v9, v10, v9, v11                            // 0000002B898C: D6370009 042E130A
	.long 0xd7006a05                                           // 0000002B8994: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000002B8998: 02020A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B899C: BF870191
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002B89A0: D5207C06 01AA0C03
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 0000002B89A8: D6270000 03CA0109
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B89B0: BF870093
	.long 0xd7006a05                                           // 0000002B89B4: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002B89B8: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002B89BC: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 0000002B89C4: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 0000002B89CC: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B89D0: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002B89D4: 8B6A067E
	s_cbranch_vccz 60                                          // 0000002B89D8: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x15cc>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002B89DC: D6100000 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B89E4: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002B89E8: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002B89F4: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B89FC: BF870091
	v_mul_f32_e32 v0, s4, v0                                   // 0000002B8A00: 10000004
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002B8A04: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B8A0C: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002B8A10: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002B8A14: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B8A18: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 0000002B8A1C: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 0000002B8A24: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 0000002B8A2C: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8A30: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 0000002B8A34: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 0000002B8A3C: 56121305
	v_mad_u64_u32 v[5:6], null, s10, v3, 0                     // 0000002B8A40: D6FE7C05 0202060A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8A48: BF870092
	v_mul_f32_e32 v11, v10, v9                                 // 0000002B8A4C: 1016130A
	v_fma_f32 v7, -v8, v11, v10                                // 0000002B8A50: D6130007 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002B8A58: BF870211
	v_fmac_f32_e32 v11, v7, v9                                 // 0000002B8A5C: 56161307
	v_mad_u64_u32 v[6:7], null, s11, v3, v[6:7]                // 0000002B8A60: D6FE7C06 041A060B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B8A68: BF870112
	v_fma_f32 v7, -v8, v11, v10                                // 0000002B8A6C: D6130007 242A1708
	.long 0xd73c0005                                           // 0000002B8A74: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000002B8A78: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002B8A7C: BF8701A2
	v_div_fmas_f32 v9, v7, v9, v11                             // 0000002B8A80: D6370009 042E1307
	.long 0xd73c0007                                           // 0000002B8A88: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000002B8A8C: 02020282
	.long 0xd7006a05                                           // 0000002B8A90: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000002B8A94: 02020A02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002B8A98: BF8701A3
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 0000002B8A9C: D6270000 03CA0109
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002B8AA4: D5207C06 01AA0C03
	.long 0xd7006a05                                           // 0000002B8AAC: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002B8AB0: 02020F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B8AB4: BF870193
	v_add_f32_e32 v0, v0, v0                                   // 0000002B8AB8: 06000100
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002B8ABC: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 0000002B8AC4: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 0000002B8ACC: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B8AD0: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002B8AD4: 8B6A067E
	s_cbranch_vccz 73                                          // 0000002B8AD8: BFA30049 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x1700>
	s_cmp_gt_i32 s5, 1                                         // 0000002B8ADC: BF028105
	s_mov_b32 s1, -1                                           // 0000002B8AE0: BE8100C1
	s_cbranch_scc0 64                                          // 0000002B8AE4: BFA10040 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x16e8>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002B8AE8: D6100000 02052104
	s_mov_b32 s1, 0                                            // 0000002B8AF0: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8AF4: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002B8AF8: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002B8B04: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8B0C: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002B8B10: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000002B8B18: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8B1C: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002B8B20: 060000F2
	v_div_scale_f32 v7, null, v0, v0, 1.0                      // 0000002B8B24: D6FC7C07 03CA0100
	v_div_scale_f32 v9, vcc_lo, 1.0, v0, 1.0                   // 0000002B8B2C: D6FC6A09 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B8B34: BF870292
	v_rcp_f32_e32 v8, v7                                       // 0000002B8B38: 7E105507
	v_fma_f32 v5, -v7, v8, 1.0                                 // 0000002B8B3C: D6130005 23CA1107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B8B44: BF870121
	v_fmac_f32_e32 v8, v5, v8                                  // 0000002B8B48: 56101105
	v_mad_u64_u32 v[5:6], null, s10, v3, 0                     // 0000002B8B4C: D6FE7C05 0202060A
	v_mul_f32_e32 v10, v9, v8                                  // 0000002B8B54: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8B58: BF870091
	v_fma_f32 v11, -v7, v10, v9                                // 0000002B8B5C: D613000B 24261507
	v_fmac_f32_e32 v10, v11, v8                                // 0000002B8B64: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B8B68: BF870121
	v_fma_f32 v9, -v7, v10, v9                                 // 0000002B8B6C: D6130009 24261507
	v_mad_u64_u32 v[6:7], null, s11, v3, v[6:7]                // 0000002B8B74: D6FE7C06 041A060B
	v_div_fmas_f32 v7, v9, v8, v10                             // 0000002B8B7C: D6370007 042A1109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B8B84: BF870112
	.long 0xd73c0005                                           // 0000002B8B88: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000002B8B8C: 02020A81
	v_div_fixup_f32 v0, v7, v0, 1.0                            // 0000002B8B90: D6270000 03CA0107
	.long 0xd73c0007                                           // 0000002B8B98: D73C0007
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002B8B9C: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B8BA0: BF870193
	.long 0xd7006a05                                           // 0000002B8BA4: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000002B8BA8: 02020A02
	v_bfe_u32 v9, v0, 16, 1                                    // 0000002B8BAC: D6100009 02052100
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002B8BB4: D5207C06 01AA0C03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B8BBC: BF870193
	.long 0xd7006a05                                           // 0000002B8BC0: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002B8BC4: 02020F05
	v_add3_u32 v0, v0, v9, 0x7fff                              // 0000002B8BC8: D6550000 03FE1300 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002B8BD4: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002B8BD8: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v0, off                    // 0000002B8BE0: DC960000 007C0005
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002B8BE8: 916A017E
	s_mov_b32 s1, 0                                            // 0000002B8BEC: BE810080
	s_cbranch_vccnz 3                                          // 0000002B8BF0: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x1700>
	s_cmp_lg_u32 s5, 1                                         // 0000002B8BF4: BF078105
	s_mov_b32 s1, -1                                           // 0000002B8BF8: BE8100C1
	s_cselect_b32 s0, -1, 0                                    // 0000002B8BFC: 980080C1
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002B8C00: D6100005 02052104
	.long 0xd73c0000                                           // 0000002B8C08: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002B8C0C: 02020281
	s_and_b32 vcc_lo, exec_lo, s0                              // 0000002B8C10: 8B6A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002B8C14: BF870002
	v_add3_u32 v2, v4, v5, 0x7fff                              // 0000002B8C18: D6550002 03FE0B04 00007FFF
	s_cbranch_vccz 20                                          // 0000002B8C24: BFA30014 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x1778>
	v_mad_u64_u32 v[4:5], null, s10, v3, 0                     // 0000002B8C28: D6FE7C04 0202060A
	s_mov_b32 s1, 0                                            // 0000002B8C30: BE810080
	v_mad_u64_u32 v[5:6], null, s11, v3, v[5:6]                // 0000002B8C34: D6FE7C05 0416060B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8C3C: BF870091
	.long 0xd73c0004                                           // 0000002B8C40: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002B8C44: 02020881
	.long 0xd7006a04                                           // 0000002B8C48: D7006A04
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 0000002B8C4C: 02020802
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B8C50: BF870111
	v_add_co_ci_u32_e64 v5, null, s3, v5, vcc_lo               // 0000002B8C54: D5207C05 01AA0A03
	.long 0xd7006a04                                           // 0000002B8C5C: D7006A04
	v_cndmask_b32_e32 v1, v4, v0, vcc_lo                       // 0000002B8C60: 02020104
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B8C64: BF870001
	v_add_co_ci_u32_e64 v5, null, v5, v1, vcc_lo               // 0000002B8C68: D5207C05 01AA0305
	global_store_d16_hi_b16 v[4:5], v2, off                    // 0000002B8C70: DC960000 007C0204
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002B8C78: 916A017E
	s_cbranch_vccnz 57                                         // 0000002B8C7C: BFA40039 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi7ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x1864>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8C80: BF870091
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000002B8C84: 360404FF FFFF0000
	v_mul_f32_e32 v2, s4, v2                                   // 0000002B8C8C: 10040404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8C90: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v2                           // 0000002B8C94: 100804FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 0000002B8C9C: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8CA0: BF870095
	v_add_f32_e32 v7, 1.0, v4                                  // 0000002B8CA4: 060E08F2
	v_div_scale_f32 v6, null, v7, v7, v2                       // 0000002B8CA8: D6FC7C06 040A0F07
	v_div_scale_f32 v9, vcc_lo, v2, v7, v2                     // 0000002B8CB0: D6FC6A09 040A0F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B8CB8: BF870292
	v_rcp_f32_e32 v8, v6                                       // 0000002B8CBC: 7E105506
	v_fma_f32 v4, -v6, v8, 1.0                                 // 0000002B8CC0: D6130004 23CA1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B8CC8: BF870121
	v_fmac_f32_e32 v8, v4, v8                                  // 0000002B8CCC: 56101104
	v_mad_u64_u32 v[4:5], null, s10, v3, 0                     // 0000002B8CD0: D6FE7C04 0202060A
	v_mul_f32_e32 v10, v9, v8                                  // 0000002B8CD8: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8CDC: BF870091
	v_fma_f32 v11, -v6, v10, v9                                // 0000002B8CE0: D613000B 24261506
	v_fmac_f32_e32 v10, v11, v8                                // 0000002B8CE8: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B8CEC: BF870121
	v_fma_f32 v9, -v6, v10, v9                                 // 0000002B8CF0: D6130009 24261506
	v_mad_u64_u32 v[5:6], null, s11, v3, v[5:6]                // 0000002B8CF8: D6FE7C05 0416060B
	v_div_fmas_f32 v3, v9, v8, v10                             // 0000002B8D00: D6370003 042A1109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B8D08: BF870191
	v_div_fixup_f32 v6, v3, v7, v2                             // 0000002B8D0C: D6270006 040A0F03
	.long 0xd73c0002                                           // 0000002B8D14: D73C0002
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002B8D18: 02020881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B8D1C: BF870112
	v_bfe_u32 v4, v6, 16, 1                                    // 0000002B8D20: D6100004 02052106
	.long 0xd7006a02                                           // 0000002B8D28: D7006A02
	v_cndmask_b32_e32 v1, s2, v2, vcc_lo                       // 0000002B8D2C: 02020402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B8D30: BF870191
	v_add_co_ci_u32_e64 v3, null, s3, v3, vcc_lo               // 0000002B8D34: D5207C03 01AA0603
	v_add3_u32 v4, v6, v4, 0x7fff                              // 0000002B8D3C: D6550004 03FE0906 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B8D48: BF870093
	.long 0xd7006a00                                           // 0000002B8D4C: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 0000002B8D50: 02020102
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 0000002B8D54: D5207C01 01AA0303
	global_store_d16_hi_b16 v[0:1], v4, off                    // 0000002B8D5C: DC960000 007C0400
	s_nop 0                                                    // 0000002B8D64: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000002B8D68: BFB60003
	s_endpgm                                                   // 0000002B8D6C: BFB00000
		...

