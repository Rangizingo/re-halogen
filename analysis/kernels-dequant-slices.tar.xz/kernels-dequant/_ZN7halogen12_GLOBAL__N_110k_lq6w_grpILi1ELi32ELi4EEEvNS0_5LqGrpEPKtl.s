0000000000362500 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 000000362500: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 000000362504: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 00000036250C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 000000362514: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 00000036251C: F4000180 F8000118
	v_lshrrev_b32_e32 v5, 5, v0                                // 000000362524: 320A0085
	v_dual_mov_b32 v2, 0 :: v_dual_and_b32 v19, 31, v0         // 000000362528: CA240080 0212009F
	v_mov_b32_e32 v18, 0                                       // 000000362530: 7E240280
	v_mov_b32_e32 v14, 0                                       // 000000362534: 7E1C0280
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v15, 0             // 000000362538: CA100080 200E0080
	s_waitcnt lgkmcnt(0)                                       // 000000362540: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 000000362544: BF028103
	s_cselect_b32 s7, -1, 0                                    // 000000362548: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000036254C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 000000362550: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000362554: BF870009
	s_and_b32 s4, s7, s4                                       // 000000362558: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000036255C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 000000362560: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 000000362568: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000036256C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 000000362570: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000362574: BF870009
	s_and_b32 s4, s7, s5                                       // 000000362578: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000036257C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 000000362580: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 000000362584: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000362588: BF030602
	s_cselect_b32 s6, -1, 0                                    // 00000036258C: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000362590: BF870009
	s_and_b32 s3, s3, s6                                       // 000000362594: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 000000362598: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 00000036259C: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000003625A0: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000003625A4: 98030483
	s_load_b128 s[4:7], s[0:1], 0x128                          // 0000003625A8: F4080100 F8000128
	s_mulk_i32 s3, 0x48                                        // 0000003625B0: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003625B4: BF870009
	s_add_u32 s8, s0, s3                                       // 0000003625B8: 80080300
	s_addc_u32 s9, s1, 0                                       // 0000003625BC: 82098001
	s_clause 0x2                                               // 0000003625C0: BF850002
	s_load_b64 s[10:11], s[8:9], 0x30                          // 0000003625C4: F4040284 F8000030
	s_load_b32 s12, s[8:9], 0x40                               // 0000003625CC: F4000304 F8000040
	s_load_b64 s[0:1], s[8:9], null                            // 0000003625D4: F4040004 F8000000
	s_waitcnt lgkmcnt(0)                                       // 0000003625DC: BF89FC07
	.long 0xd454000f                                           // 0000003625E0: D454000F
	v_cndmask_b32_e32 v0, s10, v136, vcc_lo                    // 0000003625E4: 0201100A
	s_and_b32 s3, s15, exec_lo                                 // 0000003625E8: 8B037E0F
	s_cselect_b32 s14, 4, 8                                    // 0000003625EC: 980E8884
	s_cselect_b32 s16, 2, 3                                    // 0000003625F0: 98108382
	v_cvt_f32_ubyte0_e32 v1, s14                               // 0000003625F4: 7E02220E
	s_ashr_i32 s17, s7, 31                                     // 0000003625F8: 86119F07
	s_sub_i32 s2, s2, s12                                      // 0000003625FC: 81820C02
	s_lshr_b32 s12, s17, 27                                    // 000000362600: 850C9B11
	s_add_i32 s20, s14, -1                                     // 000000362604: 8114C10E
	v_rcp_iflag_f32_e32 v4, v1                                 // 000000362608: 7E085701
	s_add_u32 s12, s6, s12                                     // 00000036260C: 800C0C06
	v_cndmask_b32_e64 v3, 0, 1, s15                            // 000000362610: D5010003 003D0280
	s_mov_b32 s3, 0                                            // 000000362618: BE830080
	v_lshrrev_b32_e32 v20, s16, v5                             // 00000036261C: 32280A10
	v_mov_b32_e32 v1, 0                                        // 000000362620: 7E020280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000362624: BF870293
	.long 0xd73c0009                                           // 000000362628: D73C0009
	v_cndmask_b32_e32 v0, v3, v2, vcc_lo                       // 00000036262C: 02000503
	v_readfirstlane_b32 s13, v4                                // 000000362630: 7E1A0504
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_2)// 000000362634: BF870532
	.long 0xd7006a03                                           // 000000362638: D7006A03
	v_cndmask_b32_e32 v1, v9, v20, vcc_lo                      // 00000036263C: 02022909
	s_mul_f32 s13, s13, 0x4f7ffffe                             // 000000362640: A20DFF0D 4F7FFFFE
	v_add_co_ci_u32_e64 v4, null, 0, v10, vcc_lo               // 000000362648: D5207C04 01AA1480
	s_cvt_u32_f32 s21, s13                                     // 000000362650: BE95670D
	s_addc_u32 s13, s7, 0                                      // 000000362654: 820D8007
	s_sub_i32 s22, 0, s14                                      // 000000362658: 81960E80
	s_lshr_b64 s[18:19], s[12:13], 5                           // 00000036265C: 8592850C
	s_mul_i32 s22, s22, s21                                    // 000000362660: 96161516
	s_add_i32 s12, s20, s18                                    // 000000362664: 810C1214
	s_mul_hi_u32 s13, s21, s22                                 // 000000362668: 968D1615
	s_abs_i32 s19, s12                                         // 00000036266C: BE93150C
	s_add_i32 s21, s21, s13                                    // 000000362670: 81150D15
	s_ashr_i32 s3, s12, 31                                     // 000000362674: 86039F0C
	s_mul_hi_u32 s13, s19, s21                                 // 000000362678: 968D1513
	v_cmp_gt_i64_e32 vcc_lo, s[10:11], v[3:4]                  // 00000036267C: 7CA8060A
	s_mul_i32 s2, s13, s14                                     // 000000362680: 96020E0D
	s_add_i32 s12, s13, 1                                      // 000000362684: 810C810D
	s_sub_i32 s2, s19, s2                                      // 000000362688: 81820213
	v_and_b32_e32 v21, s20, v5                                 // 00000036268C: 362A0A14
	s_sub_i32 s19, s2, s14                                     // 000000362690: 81930E02
	s_cmp_ge_u32 s2, s14                                       // 000000362694: BF090E02
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 000000362698: 02080880
	s_cselect_b32 s12, s12, s13                                // 00000036269C: 980C0D0C
	s_cselect_b32 s2, s19, s2                                  // 0000003626A0: 98020213
	s_add_i32 s13, s12, 1                                      // 0000003626A4: 810D810C
	s_cmp_ge_u32 s2, s14                                       // 0000003626A8: BF090E02
	s_cselect_b32 s2, s13, s12                                 // 0000003626AC: 98020C0D
	s_lshr_b32 s12, s7, 31                                     // 0000003626B0: 850C9F07
	s_xor_b32 s2, s2, s3                                       // 0000003626B4: 8D020302
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003626B8: BF870009
	s_sub_i32 s19, s2, s3                                      // 0000003626BC: 81930302
	s_add_u32 s2, s6, s12                                      // 0000003626C0: 80020C06
	s_addc_u32 s3, s7, 0                                       // 0000003626C4: 82038007
	s_lshr_b32 s20, s17, 30                                    // 0000003626C8: 85149E11
	s_ashr_i64 s[12:13], s[2:3], 1                             // 0000003626CC: 868C8102
	s_add_u32 s2, s6, s20                                      // 0000003626D0: 80021406
	s_addc_u32 s3, s7, 0                                       // 0000003626D4: 82038007
	s_lshr_b32 s17, s17, 28                                    // 0000003626D8: 85119C11
	s_ashr_i64 s[2:3], s[2:3], 2                               // 0000003626DC: 86828202
	s_add_u32 s6, s6, s17                                      // 0000003626E0: 80061106
	s_addc_u32 s7, s7, 0                                       // 0000003626E4: 82078007
	.long 0xd72c0005                                           // 0000003626E8: D72C0005
	v_cndmask_b32_e32 v0, v21, v19, vcc_lo                     // 0000003626EC: 02002715
	s_ashr_i64 s[6:7], s[6:7], 4                               // 0000003626F0: 86868406
	s_add_u32 s17, s2, s12                                     // 0000003626F4: 80110C02
	s_addc_u32 s20, s3, s13                                    // 0000003626F8: 82140D03
	s_add_u32 s6, s17, s6                                      // 0000003626FC: 80060611
	s_addc_u32 s7, s20, s7                                     // 000000362700: 82070714
	s_add_u32 s6, s6, 15                                       // 000000362704: 80068F06
	s_addc_u32 s7, s7, 0                                       // 000000362708: 82078007
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_add_nc_u32 v6, s19, v5// 00000036270C: CA600680 03060A13
	s_ashr_i32 s17, s7, 31                                     // 000000362714: 86119F07
	v_add_nc_u32_e32 v22, v5, v19                              // 000000362718: 4A2C2705
	s_lshr_b32 s17, s17, 28                                    // 00000036271C: 85119C11
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000362720: BF870009
	s_add_u32 s6, s6, s17                                      // 000000362724: 80061106
	s_addc_u32 s7, s7, 0                                       // 000000362728: 82078007
	s_and_b32 s6, s6, -16                                      // 00000036272C: 8B06D006
	.long 0xd72c0007                                           // 000000362730: D72C0007
	v_cndmask_b32_e32 v1, s7, v3, vcc_lo                       // 000000362734: 02020607
	.long 0xd72c0008                                           // 000000362738: D72C0008
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 00000036273C: 02020806
	v_mad_u64_u32 v[11:12], null, s6, v3, s[0:1]               // 000000362740: D6FE7C0B 00020606
	v_min_i32_e32 v23, s18, v6                                 // 000000362748: 222E0C12
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v4, 0               // 00000036274C: CA100080 03040080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000362754: BF870212
	v_cmp_lt_i32_e32 vcc_lo, v22, v23                          // 000000362758: 7C822F16
	v_add3_u32 v24, v7, v12, v8                                // 00000036275C: D6550018 04221907
	s_and_saveexec_b32 s1, vcc_lo                              // 000000362764: BE81206A
	s_cbranch_execz 39                                         // 000000362768: BFA50027 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x308>
	v_lshlrev_b32_e32 v1, 4, v22                               // 00000036276C: 30022C84
	v_lshlrev_b32_e32 v4, 1, v22                               // 000000362770: 30082C81
	v_lshlrev_b32_e32 v3, 3, v22                               // 000000362774: 30062C83
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000362778: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000036277C: 3404029F
	.long 0xd7000001                                           // 000000362780: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 000000362784: 0202030B
	v_and_b32_e32 v4, -4, v4                                   // 000000362788: 360808C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000036278C: BF870214
	v_ashrrev_i32_e32 v8, 31, v3                               // 000000362790: 3410069F
	v_add_co_ci_u32_e64 v2, null, v24, v2, s0                  // 000000362794: D5207C02 00020518
	.long 0xd7000006                                           // 00000036279C: D7000006
	v_cndmask_b32_e32 v0, v11, v12, vcc_lo                     // 0000003627A0: 0200190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003627A4: BF8701A1
	v_add_co_ci_u32_e64 v7, null, s13, v24, s0                 // 0000003627A8: D5207C07 0002300D
	v_ashrrev_i32_e32 v14, 31, v4                              // 0000003627B0: 341C089F
	.long 0xd700000c                                           // 0000003627B4: D700000C
	v_cndmask_b32_e32 v0, v6, v2, vcc_lo                       // 0000003627B8: 02000506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003627BC: BF8700A1
	v_add_co_ci_u32_e64 v13, null, s3, v7, s0                  // 0000003627C0: D5207C0D 00020E03
	.long 0xd7000006                                           // 0000003627C8: D7000006
	v_cndmask_b32_e32 v1, v6, v3, vcc_lo                       // 0000003627CC: 02020706
	v_add_co_ci_u32_e64 v7, null, v7, v8, s0                   // 0000003627D0: D5207C07 00021107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003627D8: BF870094
	.long 0xd700000c                                           // 0000003627DC: D700000C
	v_cndmask_b32_e32 v1, v12, v4, vcc_lo                      // 0000003627E0: 0202090C
	v_add_co_ci_u32_e64 v13, null, v13, v14, s0                // 0000003627E4: D5207C0D 00021D0D
	s_clause 0x2                                               // 0000003627EC: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 0000003627F0: DC5E0000 017C0001
	global_load_b64 v[14:15], v[6:7], off                      // 0000003627F8: DC560000 0E7C0006
	global_load_b32 v32, v[12:13], off                         // 000000362800: DC520000 207C000C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000362808: 8C7E017E
	s_and_saveexec_b32 s1, vcc_lo                              // 00000036280C: BE81206A
	s_cbranch_execz 620                                        // 000000362810: BFA5026C <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0xcc4>
	.long 0xd7006a19                                           // 000000362814: D7006A19
	v_cndmask_b32_e32 v0, v11, v12, vcc_lo                     // 000000362818: 0200190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000036281C: BF8700D1
	v_add_co_ci_u32_e64 v26, null, s13, v24, vcc_lo            // 000000362820: D5207C1A 01AA300D
	s_waitcnt vmcnt(0)                                         // 000000362828: BF8903F7
	v_dual_mov_b32 v33, v32 :: v_dual_lshlrev_b32 v6, 5, v19   // 00000036282C: CA220120 21062685
	v_dual_mov_b32 v18, 0 :: v_dual_add_nc_u32 v7, 32, v22     // 000000362834: CA200080 12062CA0
	.long 0xd7006a1b                                           // 00000036283C: D7006A1B
	v_cndmask_b32_e32 v0, v25, v2, vcc_lo                      // 000000362840: 02000519
	v_add_co_ci_u32_e64 v28, null, s3, v26, vcc_lo             // 000000362844: D5207C1C 01AA3403
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000036284C: BF870214
	v_lshl_add_u32 v12, v5, 5, v6                              // 000000362850: D646000C 04190B05
	v_lshlrev_b32_e32 v29, 4, v7                               // 000000362858: 303A0E84
	v_lshlrev_b32_e32 v30, 3, v7                               // 00000036285C: 303C0E83
	v_lshlrev_b32_e32 v31, 1, v7                               // 000000362860: 303E0E81
	s_mov_b32 s2, 0                                            // 000000362864: BE820080
	s_branch 558                                               // 000000362868: BFA0022E <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0xc24>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000036286C: 8C7E037E
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000362870: 341A189F
	v_lshlrev_b32_e32 v50, 2, v14                              // 000000362874: 30641C82
	v_lshrrev_b32_e32 v51, 4, v1                               // 000000362878: 32660284
	v_lshrrev_b32_e32 v52, 8, v1                               // 00000036287C: 32680288
	v_lshrrev_b32_e32 v53, 2, v14                              // 000000362880: 326A1C82
	.long 0xd73c0022                                           // 000000362884: D73C0022
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000362888: 02021881
	v_lshlrev_b32_e32 v13, 4, v14                              // 00000036288C: 301A1C84
	v_and_b32_e32 v50, 48, v50                                 // 000000362890: 366464B0
	v_and_b32_e32 v54, 48, v14                                 // 000000362894: 366C1CB0
	v_lshrrev_b32_e32 v55, 12, v1                              // 000000362898: 326E028C
	v_and_b32_e32 v53, 48, v53                                 // 00000036289C: 366A6AB0
	.long 0xd700002e                                           // 0000003628A0: D700002E
	v_cndmask_b32_e32 v1, s4, v34, vcc_lo                      // 0000003628A4: 02024404
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003628A8: BF870001
	v_add_co_ci_u32_e64 v47, null, s5, v35, s0                 // 0000003628AC: D5207C2F 00024605
	v_and_b32_e32 v13, 48, v13                                 // 0000003628B4: 361A1AB0
	v_and_or_b32 v50, v51, 15, v50                             // 0000003628B8: D6570032 04C91F33
	v_and_or_b32 v51, v52, 15, v54                             // 0000003628C0: D6570033 04D91F34
	s_clause 0x3                                               // 0000003628C8: BF850003
	global_load_b128 v[34:37], v[46:47], off                   // 0000003628CC: DC5E0000 227C002E
	global_load_b128 v[38:41], v[46:47], off offset:16         // 0000003628D4: DC5E0010 267C002E
	global_load_b128 v[42:45], v[46:47], off offset:32         // 0000003628DC: DC5E0020 2A7C002E
	global_load_b128 v[46:49], v[46:47], off offset:48         // 0000003628E4: DC5E0030 2E7C002E
	v_and_or_b32 v52, v55, 15, v53                             // 0000003628EC: D6570034 04D51F37
	v_and_or_b32 v13, v1, 15, v13                              // 0000003628F4: D657000D 04351F01
	v_cvt_f32_ubyte0_e32 v50, v50                              // 0000003628FC: 7E642332
	v_cvt_f32_ubyte0_e32 v51, v51                              // 000000362900: 7E662333
	.long 0x7f6e3880                                           // 000000362904: 7F6E3880
	v_cvt_f32_ubyte0_e32 v52, v52                              // 000000362908: 7E682334
	v_cvt_f32_ubyte0_e32 v13, v13                              // 00000036290C: 7E1A230D
	v_fma_mix_f32 v50, v50, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362910: CC206032 14824132
	v_fma_mix_f32 v51, v51, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362918: CC206033 14824133
	v_lshrrev_b32_e32 v57, 10, v14                             // 000000362920: 32721C8A
	v_fma_mix_f32 v52, v52, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362924: CC206034 14824134
	v_fma_mix_f32 v13, v13, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036292C: CC20600D 1482410D
	v_bfe_u32 v54, v50, 16, 1                                  // 000000362934: D6100036 02052132
	v_lshrrev_b32_e32 v62, 22, v14                             // 00000036293C: 327C1C96
	v_lshrrev_b32_e32 v61, 20, v2                              // 000000362940: 327A0494
	v_bfe_u32 v56, v52, 16, 1                                  // 000000362944: D6100038 02052134
	v_bfe_u32 v53, v13, 16, 1                                  // 00000036294C: D6100035 0205210D
	v_add3_u32 v50, v50, v54, 0x7fff                           // 000000362954: D6550032 03FE6D32 00007FFF
	v_lshrrev_b32_e32 v54, 20, v1                              // 000000362960: 326C0294
	v_lshrrev_b32_e32 v63, 24, v2                              // 000000362964: 327E0498
	v_add3_u32 v52, v52, v56, 0x7fff                           // 000000362968: D6550034 03FE7134 00007FFF
	v_add3_u32 v13, v13, v53, 0x7fff                           // 000000362974: D655000D 03FE6B0D 00007FFF
	v_bfe_u32 v53, v51, 16, 1                                  // 000000362980: D6100035 02052133
	v_lshrrev_b32_e32 v56, 24, v1                              // 000000362988: 32700298
	v_lshlrev_b32_e32 v66, 4, v15                              // 00000036298C: 30841E84
	v_and_b32_e32 v62, 48, v62                                 // 000000362990: 367C7CB0
	.long 0x7e6e398d                                           // 000000362994: 7E6E398D
	v_add3_u32 v13, v51, v53, 0x7fff                           // 000000362998: D655000D 03FE6B33 00007FFF
	v_lshrrev_b32_e32 v51, 4, v14                              // 0000003629A4: 32661C84
	v_lshrrev_b32_e32 v53, 8, v14                              // 0000003629A8: 326A1C88
	v_lshrrev_b32_e32 v59, 14, v14                             // 0000003629AC: 32761C8E
	v_and_or_b32 v50, 0xffff0000, v50, v55                     // 0000003629B0: D6570032 04DE64FF FFFF0000
	.long 0x7e6e398d                                           // 0000003629BC: 7E6E398D
	v_lshrrev_b32_e32 v13, 6, v14                              // 0000003629C0: 321A1C86
	v_and_b32_e32 v51, 48, v51                                 // 0000003629C4: 366666B0
	v_and_b32_e32 v53, 48, v53                                 // 0000003629C8: 366A6AB0
	v_lshrrev_b32_e32 v64, 28, v2                              // 0000003629CC: 3280049C
	v_and_or_b32 v52, 0xffff0000, v52, v55                     // 0000003629D0: D6570034 04DE68FF FFFF0000
	.long 0x7e6e3981                                           // 0000003629DC: 7E6E3981
	v_and_b32_e32 v13, 48, v13                                 // 0000003629E0: 361A1AB0
	v_lshrrev_b32_e32 v1, 28, v1                               // 0000003629E4: 3202029C
	v_and_or_b32 v53, v56, 15, v53                             // 0000003629E8: D6570035 04D51F38
	v_lshlrev_b32_e32 v68, 2, v15                              // 0000003629F0: 30881E82
	v_and_or_b32 v51, v55, 15, v51                             // 0000003629F4: D6570033 04CD1F37
	v_and_or_b32 v13, v54, 15, v13                             // 0000003629FC: D657000D 04351F36
	v_and_or_b32 v1, v57, 48, v1                               // 000000362A04: D6570001 04056139
	v_cvt_f32_ubyte0_e32 v53, v53                              // 000000362A0C: 7E6A2335
	v_lshrrev_b32_e32 v54, 12, v14                             // 000000362A10: 326C1C8C
	v_cvt_f32_ubyte0_e32 v51, v51                              // 000000362A14: 7E662333
	v_cvt_f32_ubyte0_e32 v13, v13                              // 000000362A18: 7E1A230D
	v_cvt_f32_ubyte0_e32 v1, v1                                // 000000362A1C: 7E022301
	v_fma_mix_f32 v53, v53, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362A20: CC206035 14824135
	v_and_or_b32 v61, v61, 15, v62                             // 000000362A28: D657003D 04F91F3D
	v_fma_mix_f32 v51, v51, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362A30: CC206033 14824133
	v_fma_mix_f32 v13, v13, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362A38: CC20600D 1482410D
	v_fma_mix_f32 v1, v1, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362A40: CC206001 14824101
	v_lshrrev_b32_e32 v67, 4, v3                               // 000000362A48: 32860684
	v_and_b32_e32 v69, 48, v15                                 // 000000362A4C: 368A1EB0
	v_bfe_u32 v56, v51, 16, 1                                  // 000000362A50: D6100038 02052133
	v_bfe_u32 v58, v13, 16, 1                                  // 000000362A58: D610003A 0205210D
	v_bfe_u32 v60, v1, 16, 1                                   // 000000362A60: D610003C 02052101
	v_cvt_f32_ubyte0_e32 v61, v61                              // 000000362A68: 7E7A233D
	v_lshrrev_b32_e32 v70, 12, v3                              // 000000362A6C: 328C068C
	v_add3_u32 v51, v51, v56, 0x7fff                           // 000000362A70: D6550033 03FE7133 00007FFF
	v_bfe_u32 v56, v53, 16, 1                                  // 000000362A7C: D6100038 02052135
	v_add3_u32 v13, v13, v58, 0x7fff                           // 000000362A84: D655000D 03FE750D 00007FFF
	v_add3_u32 v1, v1, v60, 0x7fff                             // 000000362A90: D6550001 03FE7901 00007FFF
	v_lshrrev_b32_e32 v58, 18, v14                             // 000000362A9C: 32741C92
	.long 0x7e6e39b3                                           // 000000362AA0: 7E6E39B3
	v_add3_u32 v51, v53, v56, 0x7fff                           // 000000362AA4: D6550033 03FE7135 00007FFF
	v_lshrrev_b32_e32 v53, 8, v2                               // 000000362AB0: 326A0488
	v_lshrrev_b32_e32 v56, 20, v14                             // 000000362AB4: 32701C94
	v_and_b32_e32 v58, 48, v58                                 // 000000362AB8: 367474B0
	v_and_or_b32 v13, 0xffff0000, v13, v55                     // 000000362ABC: D657000D 04DE1AFF FFFF0000
	.long 0x7e6e39b3                                           // 000000362AC8: 7E6E39B3
	v_lshrrev_b32_e32 v51, 12, v2                              // 000000362ACC: 3266048C
	v_lshrrev_b32_e32 v60, 24, v14                             // 000000362AD0: 32781C98
	v_and_b32_e32 v56, 48, v56                                 // 000000362AD4: 367070B0
	v_fma_mix_f32 v61, v61, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362AD8: CC20603D 1482413D
	v_and_or_b32 v1, 0xffff0000, v1, v55                       // 000000362AE0: D6570001 04DE02FF FFFF0000
	.long 0x7e6e398e                                           // 000000362AEC: 7E6E398E
	v_and_or_b32 v51, v51, 15, v58                             // 000000362AF0: D6570033 04E91F33
	v_and_b32_e32 v60, 48, v60                                 // 000000362AF8: 367878B0
	v_lshrrev_b32_e32 v14, 26, v14                             // 000000362AFC: 321C1C9A
	v_lshrrev_b32_e32 v58, 2, v15                              // 000000362B00: 32741E82
	v_and_b32_e32 v65, 48, v55                                 // 000000362B04: 36826EB0
	v_cvt_f32_ubyte0_e32 v51, v51                              // 000000362B08: 7E662333
	v_and_or_b32 v60, v63, 15, v60                             // 000000362B0C: D657003C 04F11F3F
	v_and_or_b32 v14, v14, 48, v64                             // 000000362B14: D657000E 0501610E
	v_and_b32_e32 v64, 48, v68                                 // 000000362B1C: 368088B0
	v_and_or_b32 v53, v53, 15, v65                             // 000000362B20: D6570035 05051F35
	v_fma_mix_f32 v51, v51, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362B28: CC206033 14824133
	v_lshrrev_b32_e32 v65, 8, v3                               // 000000362B30: 32820688
	v_cvt_f32_ubyte0_e32 v60, v60                              // 000000362B34: 7E78233C
	v_and_b32_e32 v58, 48, v58                                 // 000000362B38: 367474B0
	v_cvt_f32_ubyte0_e32 v53, v53                              // 000000362B3C: 7E6A2335
	v_bfe_u32 v80, v51, 16, 1                                  // 000000362B40: D6100050 02052133
	v_and_or_b32 v65, v65, 15, v69                             // 000000362B48: D6570041 05151F41
	v_cvt_f32_ubyte0_e32 v14, v14                              // 000000362B50: 7E1C230E
	v_and_or_b32 v62, v67, 15, v64                             // 000000362B54: D657003E 05011F43
	v_fma_mix_f32 v53, v53, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362B5C: CC206035 14824135
	v_add3_u32 v51, v51, v80, 0x7fff                           // 000000362B64: D6550033 03FEA133 00007FFF
	v_fma_mix_f32 v60, v60, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362B70: CC20603C 1482413C
	v_and_or_b32 v58, v70, 15, v58                             // 000000362B78: D657003A 04E91F46
	v_cvt_f32_ubyte0_e32 v63, v65                              // 000000362B80: 7E7E2341
	v_bfe_u32 v76, v53, 16, 1                                  // 000000362B84: D610004C 02052135
	v_fma_mix_f32 v14, v14, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362B8C: CC20600E 1482410E
	v_cvt_f32_ubyte0_e32 v62, v62                              // 000000362B94: 7E7C233E
	v_cvt_f32_ubyte0_e32 v58, v58                              // 000000362B98: 7E74233A
	v_fma_mix_f32 v63, v63, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362B9C: CC20603F 1482413F
	v_add3_u32 v53, v53, v76, 0x7fff                           // 000000362BA4: D6550035 03FE9935 00007FFF
	v_bfe_u32 v65, v14, 16, 1                                  // 000000362BB0: D6100041 0205210E
	v_fma_mix_f32 v62, v62, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362BB8: CC20603E 1482413E
	v_fma_mix_f32 v58, v58, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362BC0: CC20603A 1482413A
	v_lshrrev_b32_e32 v72, 4, v15                              // 000000362BC8: 32901E84
	.long 0x7e6e39b5                                           // 000000362BCC: 7E6E39B5
	v_and_b32_e32 v53, 48, v66                                 // 000000362BD0: 366A84B0
	v_bfe_u32 v66, v61, 16, 1                                  // 000000362BD4: D6100042 0205213D
	v_add3_u32 v14, v14, v65, 0x7fff                           // 000000362BDC: D655000E 03FE830E 00007FFF
	v_lshrrev_b32_e32 v71, 8, v15                              // 000000362BE8: 328E1E88
	v_and_or_b32 v51, 0xffff0000, v51, v55                     // 000000362BEC: D6570033 04DE66FF FFFF0000
	.long 0x7e6e3982                                           // 000000362BF8: 7E6E3982
	v_and_or_b32 v53, v3, 15, v53                              // 000000362BFC: D6570035 04D51F03
	v_add3_u32 v61, v61, v66, 0x7fff                           // 000000362C04: D655003D 03FE853D 00007FFF
	v_lshrrev_b32_e32 v74, 6, v15                              // 000000362C10: 32941E86
	v_and_b32_e32 v65, 48, v72                                 // 000000362C14: 368290B0
	v_and_or_b32 v56, v55, 15, v56                             // 000000362C18: D6570038 04E11F37
	v_cvt_f32_ubyte0_e32 v53, v53                              // 000000362C20: 7E6A2335
	v_lshrrev_b32_e32 v73, 20, v3                              // 000000362C24: 32920694
	v_lshrrev_b32_e32 v75, 24, v3                              // 000000362C28: 32960698
	v_and_b32_e32 v68, 48, v74                                 // 000000362C2C: 368894B0
	v_cvt_f32_ubyte0_e32 v56, v56                              // 000000362C30: 7E702338
	v_fma_mix_f32 v53, v53, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362C34: CC206035 14824135
	v_and_b32_e32 v69, 48, v71                                 // 000000362C3C: 368A8EB0
	v_lshrrev_b32_e32 v78, 28, v3                              // 000000362C40: 329C069C
	v_lshrrev_b32_e32 v79, 10, v15                             // 000000362C44: 329E1E8A
	v_fma_mix_f32 v56, v56, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362C48: CC206038 14824138
	v_and_or_b32 v68, v73, 15, v68                             // 000000362C50: D6570044 05111F49
	v_and_or_b32 v69, v75, 15, v69                             // 000000362C58: D6570045 05151F4B
	v_and_b32_e32 v54, 48, v54                                 // 000000362C60: 366C6CB0
	v_and_or_b32 v73, v79, 48, v78                             // 000000362C64: D6570049 0539614F
	v_bfe_u32 v64, v56, 16, 1                                  // 000000362C6C: D6100040 02052138
	v_cvt_f32_ubyte0_e32 v68, v68                              // 000000362C74: 7E882344
	v_cvt_f32_ubyte0_e32 v69, v69                              // 000000362C78: 7E8A2345
	v_lshrrev_b32_e32 v57, 4, v2                               // 000000362C7C: 32720484
	v_cvt_f32_ubyte0_e32 v73, v73                              // 000000362C80: 7E922349
	v_add3_u32 v56, v56, v64, 0x7fff                           // 000000362C84: D6550038 03FE8138 00007FFF
	v_bfe_u32 v64, v60, 16, 1                                  // 000000362C90: D6100040 0205213C
	v_fma_mix_f32 v68, v68, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362C98: CC206044 14824144
	v_fma_mix_f32 v69, v69, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362CA0: CC206045 14824145
	v_fma_mix_f32 v73, v73, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362CA8: CC206049 14824149
	.long 0x7e6e39b8                                           // 000000362CB0: 7E6E39B8
	v_add3_u32 v56, v60, v64, 0x7fff                           // 000000362CB4: D6550038 03FE813C 00007FFF
	v_bfe_u32 v60, v53, 16, 1                                  // 000000362CC0: D610003C 02052135
	v_bfe_u32 v64, v62, 16, 1                                  // 000000362CC8: D6100040 0205213E
	v_bfe_u32 v78, v68, 16, 1                                  // 000000362CD0: D610004E 02052144
	v_and_or_b32 v61, 0xffff0000, v61, v55                     // 000000362CD8: D657003D 04DE7AFF FFFF0000
	.long 0x7e6e39b8                                           // 000000362CE4: 7E6E39B8
	v_add3_u32 v53, v53, v60, 0x7fff                           // 000000362CE8: D6550035 03FE7935 00007FFF
	v_bfe_u32 v56, v63, 16, 1                                  // 000000362CF4: D6100038 0205213F
	v_bfe_u32 v60, v58, 16, 1                                  // 000000362CFC: D610003C 0205213A
	v_add3_u32 v62, v62, v64, 0x7fff                           // 000000362D04: D655003E 03FE813E 00007FFF
	v_and_or_b32 v14, 0xffff0000, v14, v55                     // 000000362D10: D657000E 04DE1CFF FFFF0000
	.long 0x7e6e39b5                                           // 000000362D1C: 7E6E39B5
	v_add3_u32 v53, v63, v56, 0x7fff                           // 000000362D20: D6550035 03FE713F 00007FFF
	v_add3_u32 v58, v58, v60, 0x7fff                           // 000000362D2C: D655003A 03FE793A 00007FFF
	v_bfe_u32 v79, v73, 16, 1                                  // 000000362D38: D610004F 02052149
	v_add3_u32 v68, v68, v78, 0x7fff                           // 000000362D40: D6550044 03FE9D44 00007FFF
	v_and_or_b32 v60, 0xffff0000, v62, v55                     // 000000362D4C: D657003C 04DE7CFF FFFF0000
	.long 0x7e6e39b5                                           // 000000362D58: 7E6E39B5
	v_and_b32_e32 v59, 48, v59                                 // 000000362D5C: 367676B0
	v_add3_u32 v73, v73, v79, 0x7fff                           // 000000362D60: D6550049 03FE9F49 00007FFF
	v_and_or_b32 v2, v2, 15, v54                               // 000000362D6C: D6570002 04D91F02
	v_lshrrev_b32_e32 v77, 12, v15                             // 000000362D74: 329A1E8C
	v_and_or_b32 v58, 0xffff0000, v58, v55                     // 000000362D78: D657003A 04DE74FF FFFF0000
	.long 0x7e6e3983                                           // 000000362D84: 7E6E3983
	v_lshrrev_b32_e32 v53, 14, v15                             // 000000362D88: 326A1E8E
	v_lshrrev_b32_e32 v64, 20, v15                             // 000000362D8C: 32801E94
	v_lshrrev_b32_e32 v66, 18, v15                             // 000000362D90: 32841E92
	v_lshrrev_b32_e32 v67, 24, v15                             // 000000362D94: 32861E98
	v_and_or_b32 v65, v55, 15, v65                             // 000000362D98: D6570041 05051F37
	v_lshrrev_b32_e32 v71, 22, v15                             // 000000362DA0: 328E1E96
	v_lshrrev_b32_e32 v76, 26, v15                             // 000000362DA4: 32981E9A
	v_cvt_f32_ubyte0_e32 v2, v2                                // 000000362DA8: 7E042302
	v_lshrrev_b32_e32 v62, 8, v4                               // 000000362DAC: 327C0888
	v_cvt_f32_ubyte0_e32 v65, v65                              // 000000362DB0: 7E822341
	v_lshrrev_b32_e32 v3, 12, v4                               // 000000362DB4: 3206088C
	v_and_b32_e32 v56, 15, v4                                  // 000000362DB8: 3670088F
	v_fma_mix_f32 v2, v2, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362DBC: CC206002 14824102
	v_lshrrev_b32_e32 v63, 4, v4                               // 000000362DC4: 327E0884
	v_fma_mix_f32 v65, v65, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362DC8: CC206041 14824141
	v_lshrrev_b32_e32 v74, 28, v4                              // 000000362DD0: 3294089C
	v_and_or_b32 v56, v77, 48, v56                             // 000000362DD4: D6570038 04E1614D
	v_and_b32_e32 v53, 48, v53                                 // 000000362DDC: 366A6AB0
	v_lshrrev_b32_e32 v70, 20, v4                              // 000000362DE0: 328C0894
	v_bfe_u32 v75, v65, 16, 1                                  // 000000362DE4: D610004B 02052141
	v_lshrrev_b32_e32 v72, 24, v4                              // 000000362DEC: 32900898
	v_and_b32_e32 v67, 48, v67                                 // 000000362DF0: 368686B0
	.long 0x7f6c39b7                                           // 000000362DF4: 7F6C39B7
	v_add_nc_u32_e32 v29, 0x200, v29                           // 000000362DF8: 4A3A3AFF 00000200
	v_add3_u32 v65, v65, v75, 0x7fff                           // 000000362E00: D6550041 03FE9741 00007FFF
	v_bfe_u32 v75, v69, 16, 1                                  // 000000362E0C: D610004B 02052145
	v_add_nc_u32_e32 v30, 0x100, v30                           // 000000362E14: 4A3C3CFF 00000100
	v_add_nc_u32_e32 v31, 64, v31                              // 000000362E1C: 4A3E3EC0
	v_add_nc_u32_e32 v12, 0x400, v12                           // 000000362E20: 4A1818FF 00000400
	.long 0x7e6e39c1                                           // 000000362E28: 7E6E39C1
	v_add3_u32 v65, v69, v75, 0x7fff                           // 000000362E2C: D6550041 03FE9745 00007FFF
	.long 0x7f8a39b7                                           // 000000362E38: 7F8A39B7
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000362E3C: 8B006A7E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000362E40: BF870193
	v_and_or_b32 v68, 0xffff0000, v68, v55                     // 000000362E44: D6570044 04DE88FF FFFF0000
	.long 0x7e6e39c1                                           // 000000362E50: 7E6E39C1
	s_or_b32 s2, s0, s2                                        // 000000362E54: 8C020200
	s_delay_alu instid0(VALU_DEP_1)                            // 000000362E58: BF870001
	v_and_or_b32 v65, 0xffff0000, v73, v55                     // 000000362E5C: D6570041 04DE92FF FFFF0000
	.long 0x7e6e398f                                           // 000000362E68: 7E6E398F
	v_and_or_b32 v15, v57, 15, v59                             // 000000362E6C: D657000F 04ED1F39
	v_and_b32_e32 v59, 48, v64                                 // 000000362E74: 367680B0
	v_and_b32_e32 v57, 48, v66                                 // 000000362E78: 367284B0
	v_and_b32_e32 v66, 48, v71                                 // 000000362E7C: 36848EB0
	v_and_b32_e32 v64, 48, v55                                 // 000000362E80: 36806EB0
	v_cvt_f32_ubyte0_e32 v15, v15                              // 000000362E84: 7E1E230F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000362E88: BF870194
	v_and_or_b32 v3, v3, 15, v57                               // 000000362E8C: D6570003 04E51F03
	v_and_or_b32 v62, v62, 15, v64                             // 000000362E94: D657003E 05011F3E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000362E9C: BF870223
	v_fma_mix_f32 v15, v15, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362EA0: CC20600F 1482410F
	v_bfe_u32 v64, v2, 16, 1                                   // 000000362EA8: D6100040 02052102
	v_cvt_f32_ubyte0_e32 v3, v3                                // 000000362EB0: 7E062303
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000362EB4: BF870193
	v_bfe_u32 v57, v15, 16, 1                                  // 000000362EB8: D6100039 0205210F
	v_add3_u32 v2, v2, v64, 0x7fff                             // 000000362EC0: D6550002 03FE8102 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000362ECC: BF870193
	v_fma_mix_f32 v3, v3, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362ED0: CC206003 14824103
	v_add3_u32 v15, v15, v57, 0x7fff                           // 000000362ED8: D655000F 03FE730F 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000362EE4: BF870093
	.long 0x7e8a3982                                           // 000000362EE8: 7E8A3982
	v_and_or_b32 v15, 0xffff0000, v15, v69                     // 000000362EEC: D657000F 05161EFF FFFF0000
	s_waitcnt vmcnt(3)                                         // 000000362EF8: BF890FF7
	v_dot2_f32_bf16 v34, v34, v50, 0                           // 000000362EFC: CC1A4022 1A026522
	v_cvt_f32_ubyte0_e32 v50, v62                              // 000000362F04: 7E64233E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000362F08: BF870112
	v_dot2_f32_bf16 v34, v35, v52, v34                         // 000000362F0C: CC1A4022 1C8A6923
	v_fma_mix_f32 v35, v50, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362F14: CC206023 14824132
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000362F1C: BF870112
	v_dot2_f32_bf16 v2, v36, v13, v34                          // 000000362F20: CC1A4002 1C8A1B24
	v_bfe_u32 v13, v35, 16, 1                                  // 000000362F28: D610000D 02052123
	v_and_or_b32 v34, v76, 48, v74                             // 000000362F30: D6570022 0529614C
	v_cvt_f32_ubyte0_e32 v36, v56                              // 000000362F38: 7E482338
	s_delay_alu instid0(VALU_DEP_4)                            // 000000362F3C: BF870004
	v_dot2_f32_bf16 v1, v37, v1, v2                            // 000000362F40: CC1A4001 1C0A0325
	v_bfe_u32 v2, v3, 16, 1                                    // 000000362F48: D6100002 02052103
	v_add3_u32 v13, v35, v13, 0x7fff                           // 000000362F50: D655000D 03FE1B23 00007FFF
	v_and_or_b32 v35, v63, 15, v53                             // 000000362F5C: D6570023 04D51F3F
	s_waitcnt vmcnt(2)                                         // 000000362F64: BF890BF7
	v_dot2_f32_bf16 v1, v38, v15, v1                           // 000000362F68: CC1A4001 1C061F26
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000362F70: D6550002 03FE0503 00007FFF
	.long 0x7e6e398d                                           // 000000362F7C: 7E6E398D
	v_cvt_f32_ubyte0_e32 v15, v34                              // 000000362F80: 7E1E2322
	v_cvt_f32_ubyte0_e32 v34, v35                              // 000000362F84: 7E442323
	v_dot2_f32_bf16 v1, v39, v51, v1                           // 000000362F88: CC1A4001 1C066727
	v_and_or_b32 v3, v70, 15, v66                              // 000000362F90: D6570003 05091F46
	v_and_or_b32 v2, 0xffff0000, v2, v55                       // 000000362F98: D6570002 04DE04FF FFFF0000
	.long 0x7e6e3984                                           // 000000362FA4: 7E6E3984
	v_fma_mix_f32 v4, v36, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362FA8: CC206004 14824124
	v_dot2_f32_bf16 v1, v40, v61, v1                           // 000000362FB0: CC1A4001 1C067B28
	v_and_or_b32 v13, v72, 15, v67                             // 000000362FB8: D657000D 050D1F48
	v_fma_mix_f32 v34, v34, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362FC0: CC206022 14824122
	v_and_or_b32 v35, v55, 15, v59                             // 000000362FC8: D6570023 04ED1F37
	v_cvt_f32_ubyte0_e32 v3, v3                                // 000000362FD0: 7E062303
	v_dot2_f32_bf16 v1, v41, v14, v1                           // 000000362FD4: CC1A4001 1C061D29
	v_fma_mix_f32 v14, v15, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000362FDC: CC20600E 1482410F
	v_bfe_u32 v15, v4, 16, 1                                   // 000000362FE4: D610000F 02052104
	v_cvt_f32_ubyte0_e32 v35, v35                              // 000000362FEC: 7E462323
	v_cvt_f32_ubyte0_e32 v13, v13                              // 000000362FF0: 7E1A230D
	s_waitcnt vmcnt(1)                                         // 000000362FF4: BF8907F7
	v_dot2_f32_bf16 v1, v42, v60, v1                           // 000000362FF8: CC1A4001 1C06792A
	v_fma_mix_f32 v3, v3, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000363000: CC206003 14824103
	v_add3_u32 v4, v4, v15, 0x7fff                             // 000000363008: D6550004 03FE1F04 00007FFF
	v_fma_mix_f32 v15, v35, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000363014: CC20600F 14824123
	v_bfe_u32 v35, v34, 16, 1                                  // 00000036301C: D6100023 02052122
	v_dot2_f32_bf16 v1, v43, v58, v1                           // 000000363024: CC1A4001 1C06752B
	v_fma_mix_f32 v13, v13, v32, v32 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036302C: CC20600D 1482410D
	.long 0x7e6c3984                                           // 000000363034: 7E6C3984
	v_bfe_u32 v4, v15, 16, 1                                   // 000000363038: D6100004 0205210F
	v_add3_u32 v32, v34, v35, 0x7fff                           // 000000363040: D6550020 03FE4722 00007FFF
	v_dot2_f32_bf16 v1, v44, v68, v1                           // 00000036304C: CC1A4001 1C06892C
	v_bfe_u32 v34, v3, 16, 1                                   // 000000363054: D6100022 02052103
	v_bfe_u32 v35, v13, 16, 1                                  // 00000036305C: D6100023 0205210D
	v_add3_u32 v4, v15, v4, 0x7fff                             // 000000363064: D6550004 03FE090F 00007FFF
	v_and_or_b32 v15, 0xffff0000, v32, v54                     // 000000363070: D657000F 04DA40FF FFFF0000
	v_dot2_f32_bf16 v1, v45, v65, v1                           // 00000036307C: CC1A4001 1C06832D
	v_bfe_u32 v32, v14, 16, 1                                  // 000000363084: D6100020 0205210E
	v_add3_u32 v3, v3, v34, 0x7fff                             // 00000036308C: D6550003 03FE4503 00007FFF
	.long 0x7e6e3984                                           // 000000363098: 7E6E3984
	v_add3_u32 v4, v13, v35, 0x7fff                            // 00000036309C: D6550004 03FE470D 00007FFF
	s_waitcnt vmcnt(0)                                         // 0000003630A8: BF8903F7
	v_dot2_f32_bf16 v1, v46, v15, v1                           // 0000003630AC: CC1A4001 1C061F2E
	v_add3_u32 v13, v14, v32, 0x7fff                           // 0000003630B4: D655000D 03FE410E 00007FFF
	v_mov_b32_e32 v14, v16                                     // 0000003630C0: 7E1C0310
	v_and_or_b32 v3, 0xffff0000, v3, v55                       // 0000003630C4: D6570003 04DE06FF FFFF0000
	.long 0x7e6e3984                                           // 0000003630D0: 7E6E3984
	v_dot2_f32_bf16 v1, v47, v2, v1                            // 0000003630D4: CC1A4001 1C06052F
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v15, v17           // 0000003630DC: CA100106 020E0111
	v_mov_b32_e32 v32, v33                                     // 0000003630E4: 7E400321
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003630E8: BF870214
	v_and_or_b32 v4, 0xffff0000, v13, v55                      // 0000003630EC: D6570004 04DE1AFF FFFF0000
	v_dot2_f32_bf16 v1, v48, v3, v1                            // 0000003630F8: CC1A4001 1C060730
	v_mov_b32_e32 v3, v7                                       // 000000363100: 7E060307
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000363104: BF870122
	v_dot2_f32_bf16 v1, v49, v4, v1                            // 000000363108: CC1A4001 1C060931
	v_mov_b32_e32 v4, v8                                       // 000000363110: 7E080308
	v_dual_add_f32 v18, v18, v1 :: v_dual_mov_b32 v1, v5       // 000000363114: C9100312 12000105
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 00000036311C: 917E027E
	s_cbranch_execz 39                                         // 000000363120: BFA50027 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0xcc0>
	s_delay_alu instid0(VALU_DEP_1)                            // 000000363124: BF870001
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v22, 32, v22    // 000000363128: CA200101 05162CA0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 000000363130: CA100102 06060103
	v_dual_mov_b32 v8, v4 :: v_dual_mov_b32 v17, v15           // 000000363138: CA100104 0810010F
	v_mov_b32_e32 v16, v14                                     // 000000363140: 7E20030E
	s_mov_b32 s3, exec_lo                                      // 000000363144: BE83007E
	v_cmp_ge_i32_e32 vcc_lo, v22, v23                          // 000000363148: 7C8C2F16
	.long 0xd4c1007e                                           // 00000036314C: D4C1007E
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                     // 000000363150: 02022F16
	s_cbranch_execz 64965                                      // 000000363154: BFA5FDC5 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x36c>
	v_and_b32_e32 v7, -4, v31                                  // 000000363158: 360E3EC4
	v_ashrrev_i32_e32 v6, 31, v29                              // 00000036315C: 340C3A9F
	v_ashrrev_i32_e32 v8, 31, v30                              // 000000363160: 34103C9F
	.long 0xd7000005                                           // 000000363164: D7000005
	v_cndmask_b32_e32 v1, v11, v29, vcc_lo                     // 000000363168: 02023B0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000036316C: BF870214
	v_ashrrev_i32_e32 v13, 31, v7                              // 000000363170: 341A0E9F
	v_add_co_ci_u32_e64 v6, null, v24, v6, s0                  // 000000363174: D5207C06 00020D18
	.long 0xd7000010                                           // 00000036317C: D7000010
	v_cndmask_b32_e32 v1, v25, v30, vcc_lo                     // 000000363180: 02023D19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000363184: BF8700A1
	v_add_co_ci_u32_e64 v17, null, v26, v8, s0                 // 000000363188: D5207C11 0002111A
	.long 0xd7000021                                           // 000000363190: D7000021
	v_cndmask_b32_e32 v1, v27, v7, vcc_lo                      // 000000363194: 02020F1B
	v_add_co_ci_u32_e64 v34, null, v28, v13, s0                // 000000363198: D5207C22 00021B1C
	s_clause 0x2                                               // 0000003631A0: BF850002
	global_load_b128 v[5:8], v[5:6], off                       // 0000003631A4: DC5E0000 057C0005
	global_load_b64 v[16:17], v[16:17], off                    // 0000003631AC: DC560000 107C0010
	global_load_b32 v33, v[33:34], off                         // 0000003631B4: DC520000 217C0021
	s_branch 64939                                             // 0000003631BC: BFA0FDAB <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x36c>
	s_or_b32 exec_lo, exec_lo, s2                              // 0000003631C0: 8C7E027E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000003631C4: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000003631C8: 8C7E017E
	s_waitcnt vmcnt(2)                                         // 0000003631CC: BF890BF7
	.long 0xd71f0001                                           // 0000003631D0: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003631D4: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000003631D8: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000003631DC: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 0000003631E0: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 0000003631E4: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003631E8: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000003631EC: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000003631F0: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000003631F4: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 0000003631F8: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000003631FC: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000363200: BF870002
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000363204: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000363208: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000036320C: 02080901
	ds_bpermute_b32 v2, v2, v18                                // 000000363210: DACC0000 02001202
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000363218: 30080882
	s_waitcnt lgkmcnt(0)                                       // 00000036321C: BF89FC07
	v_add_f32_e32 v2, v18, v2                                  // 000000363220: 06040512
	ds_bpermute_b32 v3, v3, v2                                 // 000000363224: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 00000036322C: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000363230: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 000000363234: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 00000036323C: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000363240: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000363244: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000363248: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000036324C: 30080882
	s_waitcnt lgkmcnt(0)                                       // 000000363250: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000363254: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 000000363258: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 000000363260: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000363264: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000363268: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 00000036326C: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 000000363270: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 000000363278: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 00000036327C: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v19                                   // 000000363284: 7D942680
	s_cbranch_execz 9                                          // 000000363288: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0xdb0>
	v_lshlrev_b32_e32 v3, s16, v20                             // 00000036328C: 30062810
	s_waitcnt lgkmcnt(0)                                       // 000000363290: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 000000363294: 06020501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000363298: BF870092
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000036329C: 30060682
	v_lshl_add_u32 v2, v21, 2, v3                              // 0000003632A0: D6460002 040D0515
	ds_store_b32 v2, v1                                        // 0000003632A8: D8340000 00000102
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003632B0: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003632B4: BF870009
	s_and_b32 s0, s15, exec_lo                                 // 0000003632B8: 8B007E0F
	s_cselect_b32 s0, 2, 1                                     // 0000003632BC: 98008182
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000003632C0: BF890007
	v_cmp_gt_u32_e32 vcc_lo, s0, v0                            // 0000003632C4: 7C980000
	s_barrier                                                  // 0000003632C8: BFBD0000
	buffer_gl0_inv                                             // 0000003632CC: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 0000003632D4: BE80206A
	s_cbranch_execz 308                                        // 0000003632D8: BFA50134 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x12ac>
	.long 0xd7006a01                                           // 0000003632DC: D7006A01
	v_cndmask_b32_e32 v1, v9, v0, vcc_lo                       // 0000003632E0: 02020109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003632E4: BF870121
	v_add_co_ci_u32_e64 v2, null, 0, v10, vcc_lo               // 0000003632E8: D5207C02 01AA1480
	v_mov_b32_e32 v3, 0                                        // 0000003632F0: 7E060280
	v_cmp_gt_i64_e32 vcc_lo, s[10:11], v[1:2]                  // 0000003632F4: 7CA8020A
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000003632F8: 8B7E6A7E
	s_cbranch_execz 299                                        // 0000003632FC: BFA5012B <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x12ac>
	v_lshlrev_b32_e32 v0, s16, v0                              // 000000363300: 30000010
	s_delay_alu instid0(VALU_DEP_1)                            // 000000363304: BF870001
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000363308: 30000082
	ds_load_b32 v4, v0                                         // 00000036330C: D8D80000 04000000
	v_add_nc_u32_e32 v0, 4, v0                                 // 000000363314: 4A000084
	s_add_i32 s14, s14, -1                                     // 000000363318: 810EC10E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036331C: BF870009
	s_cmp_eq_u32 s14, 0                                        // 000000363320: BF06800E
	s_waitcnt lgkmcnt(0)                                       // 000000363324: BF89FC07
	v_add_f32_e32 v3, v3, v4                                   // 000000363328: 06060903
	s_cbranch_scc0 65527                                       // 00000036332C: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0xe0c>
	s_clause 0x1                                               // 000000363330: BF850001
	s_load_b64 s[2:3], s[8:9], 0x38                            // 000000363334: F4040084 F8000038
	s_load_b64 s[0:1], s[8:9], 0x8                             // 00000036333C: F4040004 F8000008
	s_mov_b32 s6, -1                                           // 000000363344: BE8600C1
	s_mov_b32 s4, 0                                            // 000000363348: BE840080
	s_mov_b32 s5, 0                                            // 00000036334C: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000363350: BF89FC07
	s_cmp_lt_i32 s3, 3                                         // 000000363354: BF048303
	s_cbranch_scc1 146                                         // 000000363358: BFA20092 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x10a4>
	s_cmp_gt_i32 s3, 3                                         // 00000036335C: BF028303
	s_cbranch_scc0 91                                          // 000000363360: BFA1005B <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0xfd0>
	s_cmp_gt_i32 s3, 4                                         // 000000363364: BF028403
	s_cbranch_scc0 48                                          // 000000363368: BFA10030 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0xf2c>
	s_cmp_eq_u32 s3, 5                                         // 00000036336C: BF068503
	s_mov_b32 s5, -1                                           // 000000363370: BE8500C1
	s_cbranch_scc0 44                                          // 000000363374: BFA1002C <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0xf28>
	s_load_b64 s[6:7], s[8:9], 0x10                            // 000000363378: F4040184 F8000010
	v_dual_mov_b32 v5, 0 :: v_dual_and_b32 v4, 0x1ff, v1       // 000000363380: CA240080 050402FF 000001FF
	v_dual_mov_b32 v0, s1 :: v_dual_mov_b32 v7, s0             // 00000036338C: CA100001 00060000
	v_and_b32_e32 v8, 3, v2                                    // 000000363394: 36100483
	v_bfe_u32 v9, v3, 16, 1                                    // 000000363398: D6100009 02052103
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003633A0: BF8700A4
	v_cmp_gt_u64_e32 vcc_lo, 0x100, v[4:5]                     // 0000003633A4: 7CB808FF 00000100
	.long 0xd7000505                                           // 0000003633AC: D7000505
	v_cndmask_b32_e32 v1, 0xffffff00, v4, vcc_lo               // 0000003633B0: 020208FF FFFFFF00
	v_add_co_ci_u32_e64 v6, null, 0, -1, s5                    // 0000003633B8: D5207C06 00158280
	s_mov_b32 s5, 0                                            // 0000003633C0: BE850080
	v_cndmask_b32_e32 v4, v5, v4, vcc_lo                       // 0000003633C4: 02080905
	v_cndmask_b32_e64 v5, v6, 0, vcc_lo                        // 0000003633C8: D5010005 01A90106
	v_and_b32_e32 v6, 0xfffffe00, v1                           // 0000003633D0: 360C02FF FFFFFE00
	s_waitcnt lgkmcnt(0)                                       // 0000003633D8: BF89FC07
	v_cndmask_b32_e32 v7, s6, v7, vcc_lo                       // 0000003633DC: 020E0E06
	v_cndmask_b32_e32 v0, s7, v0, vcc_lo                       // 0000003633E0: 02000007
	.long 0xd73c0004                                           // 0000003633E4: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000003633E8: 02020881
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003633EC: BF870093
	.long 0xd7006a06                                           // 0000003633F0: D7006A06
	v_cndmask_b32_e32 v1, v7, v6, vcc_lo                       // 0000003633F4: 02020D07
	v_add_co_ci_u32_e64 v0, null, v0, v8, vcc_lo               // 0000003633F8: D5207C00 01AA1100
	v_add3_u32 v7, v3, v9, 0x7fff                              // 000000363400: D6550007 03FE1303 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036340C: BF870093
	.long 0xd7006a04                                           // 000000363410: D7006A04
	v_cndmask_b32_e32 v1, v6, v4, vcc_lo                       // 000000363414: 02020906
	v_add_co_ci_u32_e64 v5, null, v0, v5, vcc_lo               // 000000363418: D5207C05 01AA0B00
	global_store_d16_hi_b16 v[4:5], v7, off                    // 000000363420: DC960000 007C0704
	s_mov_b32 s6, 0                                            // 000000363428: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036342C: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000363430: 8B6A067E
	s_cbranch_vccz 37                                          // 000000363434: BFA30025 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0xfcc>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v3                           // 000000363438: 100006FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000363440: BF870291
	v_exp_f32_e32 v0, v0                                       // 000000363444: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 000000363448: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000036344C: BF870121
	v_div_scale_f32 v4, null, v0, v0, 1.0                      // 000000363450: D6FC7C04 03CA0100
	v_div_scale_f32 v7, vcc_lo, 1.0, v0, 1.0                   // 000000363458: D6FC6A07 03CA00F2
	v_rcp_f32_e32 v5, v4                                       // 000000363460: 7E0A5504
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000363464: BF870095
	v_fma_f32 v6, -v4, v5, 1.0                                 // 000000363468: D6130006 23CA0B04
	v_fmac_f32_e32 v5, v6, v5                                  // 000000363470: 560A0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000363474: BF870091
	v_mul_f32_e32 v6, v7, v5                                   // 000000363478: 100C0B07
	v_fma_f32 v8, -v4, v6, v7                                  // 00000036347C: D6130008 241E0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000363484: BF870091
	v_fmac_f32_e32 v6, v8, v5                                  // 000000363488: 560C0B08
	v_fma_f32 v4, -v4, v6, v7                                  // 00000036348C: D6130004 241E0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000363494: BF870121
	v_div_fmas_f32 v6, v4, v5, v6                              // 000000363498: D6370006 041A0B04
	.long 0xd73c0004                                           // 0000003634A0: D73C0004
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000003634A4: 02020282
	v_div_fixup_f32 v0, v6, v0, 1.0                            // 0000003634A8: D6270000 03CA0106
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003634B0: BF870092
	.long 0xd7006a04                                           // 0000003634B4: D7006A04
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 0000003634B8: 02020800
	v_add_co_ci_u32_e64 v5, null, s1, v5, vcc_lo               // 0000003634BC: D5207C05 01AA0A01
	global_store_b32 v[4:5], v0, off                           // 0000003634C4: DC6A0000 007C0004
	s_mov_b32 s6, 0                                            // 0000003634CC: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003634D0: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000003634D4: 8B6A067E
	s_cbranch_vccz 49                                          // 0000003634D8: BFA30031 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x10a0>
	v_bfe_u32 v0, v3, 16, 1                                    // 0000003634DC: D6100000 02052103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003634E4: BF870091
	v_add3_u32 v0, v3, v0, 0x7fff                              // 0000003634E8: D6550000 03FE0103 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000003634F4: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003634FC: BF870091
	v_mul_f32_e32 v0, s2, v0                                   // 000000363500: 10000002
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 000000363504: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000036350C: BF870291
	v_exp_f32_e32 v0, v0                                       // 000000363510: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 000000363514: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000363518: BF870121
	v_div_scale_f32 v4, null, v0, v0, 1.0                      // 00000036351C: D6FC7C04 03CA0100
	v_div_scale_f32 v7, vcc_lo, 1.0, v0, 1.0                   // 000000363524: D6FC6A07 03CA00F2
	v_rcp_f32_e32 v5, v4                                       // 00000036352C: 7E0A5504
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000363530: BF870095
	v_fma_f32 v6, -v4, v5, 1.0                                 // 000000363534: D6130006 23CA0B04
	v_fmac_f32_e32 v5, v6, v5                                  // 00000036353C: 560A0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000363540: BF870091
	v_mul_f32_e32 v6, v7, v5                                   // 000000363544: 100C0B07
	v_fma_f32 v8, -v4, v6, v7                                  // 000000363548: D6130008 241E0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000363550: BF870091
	v_fmac_f32_e32 v6, v8, v5                                  // 000000363554: 560C0B08
	v_fma_f32 v4, -v4, v6, v7                                  // 000000363558: D6130004 241E0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000363560: BF870091
	v_div_fmas_f32 v4, v4, v5, v6                              // 000000363564: D6370004 041A0B04
	v_div_fixup_f32 v0, v4, v0, 1.0                            // 00000036356C: D6270000 03CA0104
	.long 0xd73c0004                                           // 000000363574: D73C0004
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000363578: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000036357C: BF870112
	v_add_f32_e32 v0, v0, v0                                   // 000000363580: 06000100
	.long 0xd7006a04                                           // 000000363584: D7006A04
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 000000363588: 02020800
	s_delay_alu instid0(VALU_DEP_1)                            // 00000036358C: BF870001
	v_add_co_ci_u32_e64 v5, null, s1, v5, vcc_lo               // 000000363590: D5207C05 01AA0A01
	global_store_b32 v[4:5], v0, off                           // 000000363598: DC6A0000 007C0004
	s_mov_b32 s6, 0                                            // 0000003635A0: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003635A4: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000003635A8: 8B6A067E
	s_cbranch_vccz 62                                          // 0000003635AC: BFA3003E <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x11a8>
	s_cmp_gt_i32 s3, 1                                         // 0000003635B0: BF028103
	s_mov_b32 s4, -1                                           // 0000003635B4: BE8400C1
	s_cbranch_scc0 53                                          // 0000003635B8: BFA10035 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x1190>
	v_bfe_u32 v0, v3, 16, 1                                    // 0000003635BC: D6100000 02052103
	s_mov_b32 s4, 0                                            // 0000003635C4: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003635C8: BF870091
	v_add3_u32 v0, v3, v0, 0x7fff                              // 0000003635CC: D6550000 03FE0103 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000003635D8: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003635E0: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000003635E4: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000003635EC: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003635F0: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 0000003635F4: 060000F2
	v_div_scale_f32 v4, null, v0, v0, 1.0                      // 0000003635F8: D6FC7C04 03CA0100
	v_div_scale_f32 v7, vcc_lo, 1.0, v0, 1.0                   // 000000363600: D6FC6A07 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000363608: BF870292
	v_rcp_f32_e32 v5, v4                                       // 00000036360C: 7E0A5504
	v_fma_f32 v6, -v4, v5, 1.0                                 // 000000363610: D6130006 23CA0B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000363618: BF870091
	v_fmac_f32_e32 v5, v6, v5                                  // 00000036361C: 560A0B06
	v_mul_f32_e32 v6, v7, v5                                   // 000000363620: 100C0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000363624: BF870091
	v_fma_f32 v8, -v4, v6, v7                                  // 000000363628: D6130008 241E0D04
	v_fmac_f32_e32 v6, v8, v5                                  // 000000363630: 560C0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000363634: BF870091
	v_fma_f32 v4, -v4, v6, v7                                  // 000000363638: D6130004 241E0D04
	v_div_fmas_f32 v4, v4, v5, v6                              // 000000363640: D6370004 041A0B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000363648: BF870121
	v_div_fixup_f32 v0, v4, v0, 1.0                            // 00000036364C: D6270000 03CA0104
	.long 0xd73c0004                                           // 000000363654: D73C0004
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000363658: 02020281
	v_bfe_u32 v6, v0, 16, 1                                    // 00000036365C: D6100006 02052100
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000363664: BF870092
	.long 0xd7006a04                                           // 000000363668: D7006A04
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 00000036366C: 02020800
	v_add_co_ci_u32_e64 v5, null, s1, v5, vcc_lo               // 000000363670: D5207C05 01AA0A01
	s_delay_alu instid0(VALU_DEP_3)                            // 000000363678: BF870003
	v_add3_u32 v0, v0, v6, 0x7fff                              // 00000036367C: D6550000 03FE0D00 00007FFF
	global_store_d16_hi_b16 v[4:5], v0, off                    // 000000363688: DC960000 007C0004
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 000000363690: 916A047E
	s_mov_b32 s4, 0                                            // 000000363694: BE840080
	s_cbranch_vccnz 3                                          // 000000363698: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x11a8>
	s_cmp_lg_u32 s3, 1                                         // 00000036369C: BF078103
	s_mov_b32 s4, -1                                           // 0000003636A0: BE8400C1
	s_cselect_b32 s5, -1, 0                                    // 0000003636A4: 980580C1
	v_bfe_u32 v4, v3, 16, 1                                    // 0000003636A8: D6100004 02052103
	.long 0xd73c0000                                           // 0000003636B0: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003636B4: 02020281
	s_and_b32 vcc_lo, exec_lo, s5                              // 0000003636B8: 8B6A057E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003636BC: BF870002
	v_add3_u32 v2, v3, v4, 0x7fff                              // 0000003636C0: D6550002 03FE0903 00007FFF
	s_cbranch_vccz 8                                           // 0000003636CC: BFA30008 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x11f0>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003636D0: BF870092
	.long 0xd7006a03                                           // 0000003636D4: D7006A03
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000003636D8: 02020000
	v_add_co_ci_u32_e64 v4, null, s1, v1, vcc_lo               // 0000003636DC: D5207C04 01AA0201
	s_mov_b32 s4, 0                                            // 0000003636E4: BE840080
	global_store_d16_hi_b16 v[3:4], v2, off                    // 0000003636E8: DC960000 007C0203
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 0000003636F0: 916A047E
	s_cbranch_vccnz 45                                         // 0000003636F4: BFA4002D <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x12ac>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003636F8: BF870091
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000003636FC: 360404FF FFFF0000
	v_mul_f32_e32 v2, s2, v2                                   // 000000363704: 10040402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000363708: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v2                           // 00000036370C: 100604FF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 000000363714: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000363718: BF870095
	v_add_f32_e32 v3, 1.0, v3                                  // 00000036371C: 060606F2
	v_div_scale_f32 v4, null, v3, v3, v2                       // 000000363720: D6FC7C04 040A0703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000363728: BF870291
	v_rcp_f32_e32 v5, v4                                       // 00000036372C: 7E0A5504
	v_fma_f32 v6, -v4, v5, 1.0                                 // 000000363730: D6130006 23CA0B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000363738: BF8700A1
	v_fmac_f32_e32 v5, v6, v5                                  // 00000036373C: 560A0B06
	v_div_scale_f32 v7, vcc_lo, v2, v3, v2                     // 000000363740: D6FC6A07 040A0702
	v_mul_f32_e32 v6, v7, v5                                   // 000000363748: 100C0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036374C: BF870091
	v_fma_f32 v8, -v4, v6, v7                                  // 000000363750: D6130008 241E0D04
	v_fmac_f32_e32 v6, v8, v5                                  // 000000363758: 560C0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036375C: BF870091
	v_fma_f32 v4, -v4, v6, v7                                  // 000000363760: D6130004 241E0D04
	v_div_fmas_f32 v4, v4, v5, v6                              // 000000363768: D6370004 041A0B04
	.long 0xd7006a00                                           // 000000363770: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000363774: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000363778: BF870191
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000036377C: D5207C01 01AA0201
	v_div_fixup_f32 v2, v4, v3, v2                             // 000000363784: D6270002 040A0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036378C: BF870091
	v_bfe_u32 v3, v2, 16, 1                                    // 000000363790: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000363798: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000003637A4: DC960000 007C0200
	s_endpgm                                                   // 0000003637AC: BFB00000
		...

