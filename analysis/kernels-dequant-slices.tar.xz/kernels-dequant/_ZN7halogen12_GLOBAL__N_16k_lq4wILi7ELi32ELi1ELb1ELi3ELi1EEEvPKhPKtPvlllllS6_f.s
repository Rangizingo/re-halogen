000000000085f500 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 00000085F500: F4100200 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000085F508: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000085F50C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 3                               // 00000085F510: 84828302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000085F514: BF8701A9
	v_dual_mov_b32 v24, s3 :: v_dual_and_b32 v1, 15, v0        // 00000085F518: CA240003 1800008F
	v_and_b32_e32 v30, 31, v0                                  // 00000085F520: 363C009F
	v_and_b32_e32 v2, 60, v2                                   // 00000085F524: 360404BC
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000085F528: 300E0082
	s_delay_alu instid0(VALU_DEP_4)                            // 00000085F52C: BF870004
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000085F530: 30020282
	.long 0x7f0c3880                                           // 00000085F534: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 00000085F538: BF89FC07
	s_clause 0x1                                               // 00000085F53C: BF850001
	global_load_b32 v3, v1, s[8:9]                             // 00000085F540: DC520000 03080001
	global_load_b32 v4, v2, s[8:9]                             // 00000085F548: DC520000 04080002
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000085F550: 32020085
	s_add_u32 s24, s8, s20                                     // 00000085F554: 80181408
	s_addc_u32 s25, s9, s21                                    // 00000085F558: 82191509
	s_ashr_i32 s4, s15, 31                                     // 00000085F55C: 86049F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000085F560: BF8704A1
	v_or_b32_e32 v23, s2, v1                                   // 00000085F564: 382E0202
	s_lshr_b32 s4, s4, 27                                      // 00000085F568: 85049B04
	s_add_u32 s4, s14, s4                                      // 00000085F56C: 8004040E
	s_addc_u32 s5, s15, 0                                      // 00000085F570: 8205800F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000085F574: BF8704A1
	.long 0xd4540002                                           // 00000085F578: D4540002
	v_cndmask_b32_e32 v1, s16, v23, vcc_lo                     // 00000085F57C: 02022E10
	s_lshr_b64 s[6:7], s[4:5], 5                               // 00000085F580: 85868504
	s_cmpk_lt_i32 s6, 0x101                                    // 00000085F584: B3860101
	.long 0xd4440004                                           // 00000085F588: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 00000085F58C: 02023C06
	v_cndmask_b32_e64 v2, 0, v23, s2                           // 00000085F590: D5010002 000A2E80
	v_cndmask_b32_e64 v5, 0, s3, s2                            // 00000085F598: D5010005 00080680
	s_cselect_b32 s3, -1, 0                                    // 00000085F5A0: 980380C1
	s_cmpk_gt_i32 s6, 0x100                                    // 00000085F5A4: B2860100
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000085F5A8: BF8704B2
	.long 0xd72c0008                                           // 00000085F5AC: D72C0008
	v_cndmask_b32_e32 v1, s23, v2, vcc_lo                      // 00000085F5B0: 02020417
	v_mad_u64_u32 v[0:1], null, s22, v2, 0                     // 00000085F5B4: D6FE7C00 02020416
	s_cselect_b32 s7, -1, 0                                    // 00000085F5BC: 980780C1
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000085F5C0: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 00000085F5C4: BF8907F7
	v_bfe_u32 v9, v3, 16, 1                                    // 00000085F5C8: D6100009 02052103
	s_waitcnt vmcnt(0)                                         // 00000085F5D0: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 00000085F5D4: D610000A 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000085F5DC: BF8701A2
	v_add3_u32 v3, v3, v9, 0x7fff                              // 00000085F5E0: D6550003 03FE1303 00007FFF
	.long 0xd72c0009                                           // 00000085F5EC: D72C0009
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 00000085F5F0: 02020A16
	v_add3_u32 v4, v4, v10, 0x7fff                             // 00000085F5F4: D6550004 03FE1504 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000085F600: BF870223
	.long 0x7e0c3983                                           // 00000085F604: 7E0C3983
	.long 0xd7000503                                           // 00000085F608: D7000503
	v_cndmask_b32_e32 v1, s24, v0, vcc_lo                      // 00000085F60C: 02020018
	v_add3_u32 v1, v1, v9, v8                                  // 00000085F610: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000085F618: BF870113
	v_and_or_b32 v6, 0xffff0000, v4, v6                        // 00000085F61C: D6570006 041A08FF FFFF0000
	v_add_co_ci_u32_e64 v4, null, s25, v1, s5                  // 00000085F628: D5207C04 00160219
	ds_store_b32 v7, v6                                        // 00000085F630: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 00000085F638: BF89FC07
	s_barrier                                                  // 00000085F63C: BFBD0000
	buffer_gl0_inv                                             // 00000085F640: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 00000085F648: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x394>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 00000085F64C: CA100080 08060080
	s_and_saveexec_b32 s5, s4                                  // 00000085F654: BE852004
	s_cbranch_execz 10                                         // 00000085F658: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x184>
	v_lshlrev_b32_e32 v6, 1, v30                               // 00000085F65C: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085F660: BF870091
	.long 0xd7006a06                                           // 00000085F664: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000085F668: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 00000085F66C: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 00000085F674: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000085F67C: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 00000085F680: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s5                              // 00000085F684: 8C7E057E
	v_or_b32_e32 v6, 32, v30                                   // 00000085F688: 380C3CA0
	s_mov_b32 s4, exec_lo                                      // 00000085F68C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085F690: BF870001
	.long 0xd4c4007e                                           // 00000085F694: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085F698: 02020C06
	s_cbranch_execz 10                                         // 00000085F69C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1c8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000085F6A0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085F6A4: BF870091
	.long 0xd7006a08                                           // 00000085F6A8: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000085F6AC: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 00000085F6B0: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 00000085F6B8: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 00000085F6C0: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 00000085F6C4: 7E101706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085F6C8: 8C7E047E
	v_or_b32_e32 v6, 64, v30                                   // 00000085F6CC: 380C3CC0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 00000085F6D0: CA100080 0A080080
	s_mov_b32 s4, exec_lo                                      // 00000085F6D8: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000085F6DC: BF870002
	.long 0xd4c4007e                                           // 00000085F6E0: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085F6E4: 02020C06
	s_cbranch_execz 10                                         // 00000085F6E8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x214>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000085F6EC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085F6F0: BF870091
	.long 0xd7006a0b                                           // 00000085F6F4: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000085F6F8: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 00000085F6FC: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 00000085F704: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 00000085F70C: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 00000085F710: 7E121706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085F714: 8C7E047E
	v_or_b32_e32 v6, 0x60, v30                                 // 00000085F718: 380C3CFF 00000060
	s_mov_b32 s4, exec_lo                                      // 00000085F720: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085F724: BF870001
	.long 0xd4c4007e                                           // 00000085F728: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085F72C: 02020C06
	s_cbranch_execz 10                                         // 00000085F730: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x25c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000085F734: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085F738: BF870091
	.long 0xd7006a0a                                           // 00000085F73C: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000085F740: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 00000085F744: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 00000085F74C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 00000085F754: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 00000085F758: 7E141706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085F75C: 8C7E047E
	v_or_b32_e32 v6, 0x80, v30                                 // 00000085F760: 380C3CFF 00000080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 00000085F768: CA100080 0C0A0080
	s_mov_b32 s4, exec_lo                                      // 00000085F770: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000085F774: BF870002
	.long 0xd4c4007e                                           // 00000085F778: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085F77C: 02020C06
	s_cbranch_execz 10                                         // 00000085F780: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2ac>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000085F784: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085F788: BF870091
	.long 0xd7006a0d                                           // 00000085F78C: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000085F790: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 00000085F794: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 00000085F79C: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 00000085F7A4: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 00000085F7A8: 7E161706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085F7AC: 8C7E047E
	v_or_b32_e32 v6, 0xa0, v30                                 // 00000085F7B0: 380C3CFF 000000A0
	s_mov_b32 s4, exec_lo                                      // 00000085F7B8: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085F7BC: BF870001
	.long 0xd4c4007e                                           // 00000085F7C0: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085F7C4: 02020C06
	s_cbranch_execz 10                                         // 00000085F7C8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2f4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000085F7CC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085F7D0: BF870091
	.long 0xd7006a0c                                           // 00000085F7D4: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000085F7D8: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 00000085F7DC: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 00000085F7E4: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 00000085F7EC: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 00000085F7F0: 7E181706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085F7F4: 8C7E047E
	v_or_b32_e32 v6, 0xc0, v30                                 // 00000085F7F8: 380C3CFF 000000C0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 00000085F800: CA100080 0E0C0080
	s_mov_b32 s4, exec_lo                                      // 00000085F808: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000085F80C: BF870002
	.long 0xd4c4007e                                           // 00000085F810: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085F814: 02020C06
	s_cbranch_execz 10                                         // 00000085F818: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x344>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000085F81C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085F820: BF870091
	.long 0xd7006a0f                                           // 00000085F824: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000085F828: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000085F82C: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 00000085F834: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 00000085F83C: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 00000085F840: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085F844: 8C7E047E
	v_or_b32_e32 v6, 0xe0, v30                                 // 00000085F848: 380C3CFF 000000E0
	s_mov_b32 s4, exec_lo                                      // 00000085F850: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085F854: BF870001
	.long 0xd4c4007e                                           // 00000085F858: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085F85C: 02020C06
	s_cbranch_execz 10                                         // 00000085F860: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x38c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000085F864: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085F868: BF870091
	.long 0xd7006a0e                                           // 00000085F86C: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000085F870: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 00000085F874: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 00000085F87C: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 00000085F884: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 00000085F888: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085F88C: 8C7E047E
	s_branch 9                                                 // 00000085F890: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_mov_b32_e32 v7, 0                                        // 00000085F894: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085F898: BF870001
	v_mov_b32_e32 v8, v7                                       // 00000085F89C: 7E100307
	v_mov_b32_e32 v9, v7                                       // 00000085F8A0: 7E120307
	v_mov_b32_e32 v10, v7                                      // 00000085F8A4: 7E140307
	v_mov_b32_e32 v11, v7                                      // 00000085F8A8: 7E160307
	v_mov_b32_e32 v12, v7                                      // 00000085F8AC: 7E180307
	v_mov_b32_e32 v13, v7                                      // 00000085F8B0: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 00000085F8B4: 7E1C0307
	s_add_u32 s4, s8, s18                                      // 00000085F8B8: 80041208
	s_addc_u32 s5, s9, s19                                     // 00000085F8BC: 82051309
	s_lshr_b32 s18, s15, 31                                    // 00000085F8C0: 85129F0F
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 00000085F8C4: CA100080 13140080
	s_add_u32 s18, s14, s18                                    // 00000085F8CC: 8012120E
	s_addc_u32 s19, s15, 0                                     // 00000085F8D0: 8213800F
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v22, 0             // 00000085F8D4: CA100080 1F160080
	s_ashr_i64 s[18:19], s[18:19], 1                           // 00000085F8DC: 86928112
	v_cndmask_b32_e64 v32, 0, 1, s7                            // 00000085F8E0: D5010020 001D0280
	v_mad_u64_u32 v[25:26], null, v2, s18, s[4:5]              // 00000085F8E8: D6FE7C19 00102502
	.long 0xd72c0002                                           // 00000085F8F0: D72C0002
	v_cndmask_b32_e32 v0, v2, v19, vcc_lo                      // 00000085F8F4: 02002702
	.long 0xd72c0005                                           // 00000085F8F8: D72C0005
	v_cndmask_b32_e32 v0, v5, v18, vcc_lo                      // 00000085F8FC: 02002505
	.long 0xd4440004                                           // 00000085F900: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 00000085F904: 02023C06
	v_mov_b32_e32 v43, 0                                       // 00000085F908: 7E560280
	v_mov_b32_e32 v21, 0                                       // 00000085F90C: 7E2A0280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000085F910: BF870004
	v_add3_u32 v33, v5, v26, v2                                // 00000085F914: D6550021 040A3505
	s_and_saveexec_b32 s5, s4                                  // 00000085F91C: BE852004
	s_cbranch_execz 21                                         // 00000085F920: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_dual_mov_b32 v43, 0 :: v_dual_lshlrev_b32 v2, 4, v30     // 00000085F924: CA220080 2B023C84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085F92C: BF870091
	.long 0xd7006a05                                           // 00000085F930: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 00000085F934: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 00000085F938: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 00000085F940: 916A077E
	global_load_b128 v[19:22], v[5:6], off                     // 00000085F944: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 00000085F94C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 1, v30                               // 00000085F950: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085F954: BF870091
	.long 0xd7006a02                                           // 00000085F958: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000085F95C: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 00000085F960: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 00000085F968: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000085F970: BF8903F7
	v_cvt_f32_f16_e32 v43, v2                                  // 00000085F974: 7E561702
	s_or_b32 exec_lo, exec_lo, s5                              // 00000085F978: 8C7E057E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 00000085F97C: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 00000085F984: CA100080 24240080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 00000085F98C: CA100080 26260080
	s_and_saveexec_b32 s5, s4                                  // 00000085F994: BE852004
	s_cbranch_execz 627                                        // 00000085F998: BFA50273 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xe68>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 00000085F99C: CA220080 1B023C81
	.long 0xd7006a00                                           // 00000085F9A4: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 00000085F9A8: 02020014
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000085F9AC: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 00000085F9B0: D5207C01 01AA0215
	v_dual_mov_b32 v41, v30 :: v_dual_lshlrev_b32 v26, 5, v30  // 00000085F9B8: CA22011E 291A3C85
	.long 0xd7006a00                                           // 00000085F9C0: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 00000085F9C4: 02020500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000085F9C8: BF8701A1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000085F9CC: D5207C01 01AA0280
	v_lshl_or_b32 v40, v30, 4, 0x200                           // 00000085F9D4: D6560028 03FD091E 00000200
	.long 0xd7006a00                                           // 00000085F9E0: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000085F9E4: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000085F9E8: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000085F9EC: D5207C01 01AA0209
	v_mov_b32_e32 v39, v27                                     // 00000085F9F4: 7E4E031B
	.long 0xd7006a1c                                           // 00000085F9F8: D7006A1C
	v_cndmask_b32_e32 v0, v0, v192, vcc_lo                     // 00000085F9FC: 02018100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085FA00: BF870001
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 00000085FA04: D5207C1D 01AA0280
	v_mov_b32_e32 v38, v27                                     // 00000085FA0C: 7E4C031B
	v_mov_b32_e32 v37, v27                                     // 00000085FA10: 7E4A031B
	v_mov_b32_e32 v36, v27                                     // 00000085FA14: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 00000085FA18: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 00000085FA1C: 7E44031B
	v_mov_b32_e32 v31, v27                                     // 00000085FA20: 7E3E031B
	v_mov_b32_e32 v42, v43                                     // 00000085FA24: 7E54032B
	s_mul_i32 s4, s15, 6                                       // 00000085FA28: 9604860F
	s_mul_hi_u32 s7, s14, 6                                    // 00000085FA2C: 9687860E
	s_lshl_b64 s[18:19], s[14:15], 2                           // 00000085FA30: 8492820E
	s_add_i32 s7, s7, s4                                       // 00000085FA34: 81070407
	s_mul_i32 s21, s14, 6                                      // 00000085FA38: 9615860E
	s_mov_b32 s20, 0                                           // 00000085FA3C: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 00000085FA40: 8488810E
	s_branch 555                                               // 00000085FA44: BFA0022B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xdf4>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000085FA48: 8C7E0E7E
	v_cndmask_b32_e64 v53, v43, v7, s3                         // 00000085FA4C: D5010035 000E0F2B
	v_cndmask_b32_e64 v1, v8, v9, s3                           // 00000085FA54: D5010001 000E1308
	v_cndmask_b32_e64 v0, v7, v8, s3                           // 00000085FA5C: D5010000 000E1107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 00000085FA64: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s3                         // 00000085FA70: D5010006 000E1D0D
	v_cndmask_b32_e64 v5, v12, v13, s3                         // 00000085FA78: D5010005 000E1B0C
	v_cndmask_b32_e64 v4, v11, v12, s3                         // 00000085FA80: D5010004 000E190B
	v_cndmask_b32_e64 v3, v10, v11, s3                         // 00000085FA88: D5010003 000E170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000085FA90: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s3                          // 00000085FA94: D5010002 000E1509
	v_add_nc_u32_e32 v40, 0x200, v40                           // 00000085FA9C: 4A5050FF 00000200
	s_and_b32 s4, exec_lo, s4                                  // 00000085FAA4: 8B04047E
	ds_load_b32 v14, v8                                        // 00000085FAA8: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 00000085FAB0: 32102686
	s_or_b32 s20, s4, s20                                      // 00000085FAB4: 8C141404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085FAB8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085FABC: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 00000085FAC4: D8D80000 36000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 00000085FACC: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085FAD0: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 00000085FAD8: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 00000085FAE0: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085FAE4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085FAE8: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 00000085FAF0: D8D80000 38000008
	v_and_b32_e32 v8, 0xff, v20                                // 00000085FAF8: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000085FB00: 30101082
	ds_load_b32 v57, v8                                        // 00000085FB04: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 00000085FB0C: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085FB10: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085FB14: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 00000085FB1C: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 00000085FB24: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085FB28: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 00000085FB30: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 00000085FB38: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085FB3C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085FB40: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 00000085FB48: D8D80000 3C000008
	v_and_b32_e32 v8, 0xff, v21                                // 00000085FB50: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000085FB58: 30101082
	ds_load_b32 v61, v8                                        // 00000085FB5C: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 00000085FB64: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085FB68: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085FB6C: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 00000085FB74: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 00000085FB7C: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085FB80: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 00000085FB88: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 00000085FB90: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085FB94: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085FB98: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 00000085FBA0: D8D80000 40000008
	v_and_b32_e32 v8, 0xff, v22                                // 00000085FBA8: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000085FBB0: 30101082
	ds_load_b32 v65, v8                                        // 00000085FBB4: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 00000085FBBC: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085FBC0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085FBC4: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 00000085FBCC: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 00000085FBD4: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085FBD8: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 00000085FBE0: D8D80000 43000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 00000085FBE8: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000085FBEC: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085FBF0: 361010FF 000003FC
	ds_load_b32 v68, v8                                        // 00000085FBF8: D8D80000 44000008
	.long 0xd73c0008                                           // 00000085FC00: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 00000085FC04: 02023481
	v_add_nc_u32_e32 v26, 0x400, v26                           // 00000085FC08: 4A3434FF 00000400
	.long 0xd7006a0c                                           // 00000085FC10: D7006A0C
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 00000085FC14: 0202100A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085FC18: BF870001
	v_add_co_ci_u32_e64 v13, null, s11, v9, vcc_lo             // 00000085FC1C: D5207C0D 01AA120B
	s_clause 0x3                                               // 00000085FC24: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000085FC28: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000085FC30: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 00000085FC38: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 00000085FC40: DC5E0030 2F7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000085FC48: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000085FC4C: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 00000085FC54: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085FC58: BF8700A1
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 00000085FC5C: CC1A4008 1C226D09
	s_waitcnt lgkmcnt(13)                                      // 00000085FC64: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 00000085FC68: CC1A4008 1C226F0A
	s_waitcnt lgkmcnt(12)                                      // 00000085FC70: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085FC74: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 00000085FC78: CC1A4008 1C22710B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000085FC80: BF8908B7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 00000085FC84: CC1A4008 1C227313
	s_waitcnt lgkmcnt(10)                                      // 00000085FC8C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085FC90: BF8700A1
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 00000085FC94: CC1A4008 1C227514
	s_waitcnt lgkmcnt(9)                                       // 00000085FC9C: BF89FC97
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 00000085FCA0: CC1A4008 1C227715
	s_waitcnt lgkmcnt(8)                                       // 00000085FCA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085FCAC: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 00000085FCB0: CC1A4008 1C227916
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000085FCB8: BF890477
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000085FCBC: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(6)                                       // 00000085FCC4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085FCC8: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000085FCCC: CC1A4008 1C227D2C
	s_waitcnt lgkmcnt(5)                                       // 00000085FCD4: BF89FC57
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000085FCD8: CC1A4008 1C227F2D
	s_waitcnt lgkmcnt(4)                                       // 00000085FCE0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085FCE4: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000085FCE8: CC1A4008 1C22812E
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000085FCF0: BF890037
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000085FCF4: CC1A4008 1C22832F
	.long 0xd7006a2f                                           // 00000085FCFC: D7006A2F
	v_cndmask_b32_e32 v0, v12, v8, vcc_lo                      // 00000085FD00: 0200110C
	s_waitcnt lgkmcnt(2)                                       // 00000085FD04: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000085FD08: BF8701C2
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000085FD0C: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v48, null, s9, v13, vcc_lo             // 00000085FD14: D5207C30 01AA1A09
	.long 0xd7006a33                                           // 00000085FD1C: D7006A33
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 00000085FD20: 0200250C
	s_waitcnt lgkmcnt(1)                                       // 00000085FD24: BF89FC17
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000085FD28: CC1A4008 1C228731
	v_add_co_ci_u32_e64 v52, null, s19, v13, vcc_lo            // 00000085FD30: D5207C34 01AA1A13
	.long 0xd7006a0c                                           // 00000085FD38: D7006A0C
	v_cndmask_b32_e32 v0, v12, v21, vcc_lo                     // 00000085FD3C: 02002B0C
	s_waitcnt lgkmcnt(0)                                       // 00000085FD40: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000085FD44: BF870123
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 00000085FD48: CC1A4008 1C228932
	v_add_co_ci_u32_e64 v13, null, s7, v13, vcc_lo             // 00000085FD50: D5207C0D 01AA1A07
	v_fmac_f32_e32 v39, v53, v8                                // 00000085FD58: 564E1135
	s_clause 0x3                                               // 00000085FD5C: BF850003
	global_load_b128 v[8:11], v[47:48], off                    // 00000085FD60: DC5E0000 087C002F
	global_load_b128 v[19:22], v[47:48], off offset:16         // 00000085FD68: DC5E0010 137C002F
	global_load_b128 v[43:46], v[47:48], off offset:32         // 00000085FD70: DC5E0020 2B7C002F
	global_load_b128 v[47:50], v[47:48], off offset:48         // 00000085FD78: DC5E0030 2F7C002F
	s_waitcnt vmcnt(3)                                         // 00000085FD80: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000085FD84: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FD8C: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 00000085FD90: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 00000085FD98: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085FDA0: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 00000085FDA4: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 00000085FDAC: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 00000085FDB0: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FDB8: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 00000085FDBC: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 00000085FDC4: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085FDCC: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 00000085FDD0: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 00000085FDD8: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000085FDDC: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FDE4: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000085FDE8: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000085FDF0: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085FDF8: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000085FDFC: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 00000085FE04: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000085FE08: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FE10: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000085FE14: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000085FE1C: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FE24: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 00000085FE28: CC1A4008 1C228932
	v_fmac_f32_e32 v38, v53, v8                                // 00000085FE30: 564C1135
	s_clause 0x3                                               // 00000085FE34: BF850003
	global_load_b128 v[8:11], v[51:52], off                    // 00000085FE38: DC5E0000 087C0033
	global_load_b128 v[19:22], v[51:52], off offset:16         // 00000085FE40: DC5E0010 137C0033
	global_load_b128 v[43:46], v[51:52], off offset:32         // 00000085FE48: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[51:52], off offset:48         // 00000085FE50: DC5E0030 2F7C0033
	.long 0xd7006a33                                           // 00000085FE58: D7006A33
	v_cndmask_b32_e32 v0, v51, v18, vcc_lo                     // 00000085FE5C: 02002533
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085FE60: BF8700B1
	v_add_co_ci_u32_e64 v52, null, s19, v52, vcc_lo            // 00000085FE64: D5207C34 01AA6813
	s_waitcnt vmcnt(3)                                         // 00000085FE6C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000085FE70: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 00000085FE78: CC1A4008 1C226D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FE80: BF870091
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 00000085FE84: CC1A4008 1C226F0A
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 00000085FE8C: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 00000085FE94: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FE98: BF870091
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 00000085FE9C: CC1A4008 1C227313
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 00000085FEA4: CC1A4008 1C227514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FEAC: BF870091
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 00000085FEB0: CC1A4008 1C227715
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 00000085FEB8: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 00000085FEC0: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FEC4: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000085FEC8: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000085FED0: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FED8: BF870091
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000085FEDC: CC1A4008 1C227F2D
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000085FEE4: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 00000085FEEC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FEF0: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000085FEF4: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000085FEFC: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FF04: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000085FF08: CC1A4008 1C228731
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 00000085FF10: CC1A4008 1C228932
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085FF18: BF870001
	v_fmac_f32_e32 v37, v53, v8                                // 00000085FF1C: 564A1135
	s_clause 0x3                                               // 00000085FF20: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000085FF24: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000085FF2C: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 00000085FF34: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 00000085FF3C: DC5E0030 2F7C000C
	.long 0xd7006a0c                                           // 00000085FF44: D7006A0C
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 00000085FF48: 0200250C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085FF4C: BF8700B1
	v_add_co_ci_u32_e64 v13, null, s19, v13, vcc_lo            // 00000085FF50: D5207C0D 01AA1A13
	s_waitcnt vmcnt(3)                                         // 00000085FF58: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000085FF5C: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 00000085FF64: CC1A4008 1C226D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FF6C: BF870091
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 00000085FF70: CC1A4008 1C226F0A
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 00000085FF78: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 00000085FF80: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FF84: BF870091
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 00000085FF88: CC1A4008 1C227313
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 00000085FF90: CC1A4008 1C227514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FF98: BF870091
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 00000085FF9C: CC1A4008 1C227715
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 00000085FFA4: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 00000085FFAC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FFB0: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000085FFB4: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000085FFBC: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FFC4: BF870091
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000085FFC8: CC1A4008 1C227F2D
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000085FFD0: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 00000085FFD8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FFDC: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000085FFE0: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000085FFE8: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085FFF0: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000085FFF4: CC1A4008 1C228731
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 00000085FFFC: CC1A4008 1C228932
	s_delay_alu instid0(VALU_DEP_1)                            // 000000860004: BF870001
	v_fmac_f32_e32 v36, v53, v8                                // 000000860008: 56481135
	s_clause 0x3                                               // 00000086000C: BF850003
	global_load_b128 v[8:11], v[51:52], off                    // 000000860010: DC5E0000 087C0033
	global_load_b128 v[19:22], v[51:52], off offset:16         // 000000860018: DC5E0010 137C0033
	global_load_b128 v[43:46], v[51:52], off offset:32         // 000000860020: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[51:52], off offset:48         // 000000860028: DC5E0030 2F7C0033
	s_waitcnt vmcnt(3)                                         // 000000860030: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000860034: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086003C: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 000000860040: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 000000860048: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000860050: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 000000860054: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 00000086005C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 000000860060: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000860068: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 00000086006C: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 000000860074: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086007C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 000000860080: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 000000860088: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000086008C: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000860094: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000860098: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008600A0: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008600A8: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008600AC: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 0000008600B4: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008600B8: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008600C0: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008600C4: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000008600CC: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008600D4: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000008600D8: CC1A4008 1C228932
	v_fmac_f32_e32 v35, v53, v8                                // 0000008600E0: 56461135
	s_clause 0x3                                               // 0000008600E4: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000008600E8: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000008600F0: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 0000008600F8: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 000000860100: DC5E0030 2F7C000C
	.long 0xd7006a0c                                           // 000000860108: D7006A0C
	v_cndmask_b32_e32 v0, v51, v18, vcc_lo                     // 00000086010C: 02002533
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000860110: BF8700A1
	v_add_co_ci_u32_e64 v13, null, s19, v52, vcc_lo            // 000000860114: D5207C0D 01AA6813
	.long 0xd7006a1c                                           // 00000086011C: D7006A1C
	v_cndmask_b32_e32 v0, v28, v192, vcc_lo                    // 000000860120: 0201811C
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 000000860124: D5207C1D 01AA3A80
	s_waitcnt vmcnt(3)                                         // 00000086012C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000860130: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000860138: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 00000086013C: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 000000860144: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086014C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 000000860150: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 000000860158: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 00000086015C: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000860164: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 000000860168: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 000000860170: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000860178: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 00000086017C: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 000000860184: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000860188: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000860190: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000860194: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000086019C: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008601A4: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008601A8: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 0000008601B0: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008601B4: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008601BC: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008601C0: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000008601C8: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008601D0: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000008601D4: CC1A4008 1C228932
	v_fmac_f32_e32 v34, v53, v8                                // 0000008601DC: 56441135
	s_clause 0x3                                               // 0000008601E0: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000008601E4: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000008601EC: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 0000008601F4: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 0000008601FC: DC5E0030 2F7C000C
	s_waitcnt vmcnt(3)                                         // 000000860204: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000860208: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000860210: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 000000860214: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 00000086021C: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000860224: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 000000860228: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 000000860230: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 000000860234: CC1A4008 1C227313
	v_mov_b32_e32 v19, v15                                     // 00000086023C: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000860240: BF870122
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 000000860244: CC1A4008 1C227514
	v_mov_b32_e32 v20, v16                                     // 00000086024C: 7E280310
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 000000860250: CC1A4008 1C227715
	v_mov_b32_e32 v21, v17                                     // 000000860258: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000086025C: BF870132
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 000000860260: CC1A4008 1C227916
	v_mov_b32_e32 v22, v18                                     // 000000860268: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 00000086026C: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000860270: CC1A4008 1C227B2B
	v_mov_b32_e32 v43, v42                                     // 000000860278: 7E56032A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086027C: BF870092
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000860280: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000860288: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000860290: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000860294: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 00000086029C: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008602A0: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008602A8: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008602AC: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000008602B4: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008602BC: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000008602C0: CC1A4008 1C228932
	v_dual_fmac_f32 v31, v53, v8 :: v_dual_mov_b32 v14, v7     // 0000008602C8: C8101135 1F0E0107
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 0000008602D0: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 0000008602D8: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 0000008602E0: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 0000008602E8: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 0000008602EC: 917E147E
	s_cbranch_execz 28                                         // 0000008602F0: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xe64>
	s_waitcnt vmcnt(0)                                         // 0000008602F4: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v41, 32, v41  // 0000008602F8: CA200114 102852A0
	v_dual_mov_b32 v15, v19 :: v_dual_mov_b32 v18, v22         // 000000860300: CA100113 0F120116
	v_mov_b32_e32 v17, v21                                     // 000000860308: 7E220315
	s_delay_alu instid0(VALU_DEP_3)                            // 00000086030C: BF870003
	.long 0xd4430004                                           // 000000860310: D4430004
	v_cndmask_b32_e32 v1, s6, v41, vcc_lo                      // 000000860314: 02025206
	s_mov_b32 s14, exec_lo                                     // 000000860318: BE8E007E
	.long 0xd4c4007e                                           // 00000086031C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v41, vcc_lo                      // 000000860320: 02025206
	s_cbranch_execz 64968                                      // 000000860324: BFA5FDC8 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x548>
	.long 0xd7006a00                                           // 000000860328: D7006A00
	v_cndmask_b32_e32 v1, v25, v40, vcc_lo                     // 00000086032C: 02025119
	s_delay_alu instid0(VALU_DEP_1)                            // 000000860330: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 000000860334: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v32                            // 00000086033C: 7C9A4081
	v_mov_b32_e32 v42, v43                                     // 000000860340: 7E54032B
	global_load_b128 v[15:18], v[0:1], off                     // 000000860344: DC5E0000 0F7C0000
	s_cbranch_vccnz 64958                                      // 00000086034C: BFA4FDBE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x548>
	global_load_d16_b16 v0, v[28:29], off                      // 000000860350: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 000000860358: BF8903F7
	v_cvt_f32_f16_e32 v42, v0                                  // 00000086035C: 7E541700
	s_branch 64953                                             // 000000860360: BFA0FDB9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x548>
	s_or_b32 exec_lo, exec_lo, s20                             // 000000860364: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000860368: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 00000086036C: 8C7E057E
	.long 0xd71f0000                                           // 000000860370: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000860374: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000860378: 3A020090
	v_xor_b32_e32 v8, 8, v0                                    // 00000086037C: 3A100088
	v_xor_b32_e32 v15, 4, v0                                   // 000000860380: 3A1E0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000860384: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000860388: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000086038C: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000860390: 7C9810A0
	v_cndmask_b32_e32 v8, v0, v8, vcc_lo                       // 000000860394: 02101100
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 000000860398: 7C981EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000086039C: BF870002
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008603A0: 30101082
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008603A4: 30020282
	ds_bpermute_b32 v2, v1, v39                                // 0000008603A8: DACC0000 02002701
	s_waitcnt lgkmcnt(0)                                       // 0000008603B0: BF89FC07
	v_add_f32_e32 v2, v39, v2                                  // 0000008603B4: 06040527
	ds_bpermute_b32 v4, v1, v37                                // 0000008603B8: DACC0000 04002501
	ds_bpermute_b32 v5, v1, v36                                // 0000008603C0: DACC0000 05002401
	ds_bpermute_b32 v6, v1, v35                                // 0000008603C8: DACC0000 06002301
	ds_bpermute_b32 v3, v1, v38                                // 0000008603D0: DACC0000 03002601
	ds_bpermute_b32 v7, v1, v34                                // 0000008603D8: DACC0000 07002201
	ds_bpermute_b32 v1, v1, v31                                // 0000008603E0: DACC0000 01001F01
	ds_bpermute_b32 v9, v8, v2                                 // 0000008603E8: DACC0000 09000208
	s_waitcnt lgkmcnt(6)                                       // 0000008603F0: BF89FC67
	v_dual_cndmask_b32 v15, v0, v15 :: v_dual_add_f32 v4, v37, v4// 0000008603F4: CA481F00 0F040925
	s_waitcnt lgkmcnt(4)                                       // 0000008603FC: BF89FC47
	v_dual_add_f32 v5, v36, v5 :: v_dual_add_f32 v6, v35, v6   // 000000860400: C9080B24 05060D23
	s_waitcnt lgkmcnt(3)                                       // 000000860408: BF89FC37
	v_add_f32_e32 v3, v38, v3                                  // 00000086040C: 06060726
	s_waitcnt lgkmcnt(2)                                       // 000000860410: BF89FC27
	v_add_f32_e32 v7, v34, v7                                  // 000000860414: 060E0F22
	ds_bpermute_b32 v11, v8, v4                                // 000000860418: DACC0000 0B000408
	s_waitcnt lgkmcnt(2)                                       // 000000860420: BF89FC27
	v_add_f32_e32 v1, v31, v1                                  // 000000860424: 0602031F
	ds_bpermute_b32 v13, v8, v6                                // 000000860428: DACC0000 0D000608
	ds_bpermute_b32 v10, v8, v3                                // 000000860430: DACC0000 0A000308
	ds_bpermute_b32 v12, v8, v5                                // 000000860438: DACC0000 0C000508
	ds_bpermute_b32 v14, v8, v7                                // 000000860440: DACC0000 0E000708
	s_waitcnt lgkmcnt(5)                                       // 000000860448: BF89FC57
	v_dual_add_f32 v2, v2, v9 :: v_dual_lshlrev_b32 v15, 2, v15// 00000086044C: C9221302 020E1E82
	s_waitcnt lgkmcnt(4)                                       // 000000860454: BF89FC47
	v_add_f32_e32 v4, v4, v11                                  // 000000860458: 06081704
	ds_bpermute_b32 v8, v8, v1                                 // 00000086045C: DACC0000 08000108
	s_waitcnt lgkmcnt(0)                                       // 000000860464: BF89FC07
	v_dual_add_f32 v6, v6, v13 :: v_dual_add_f32 v1, v1, v8    // 000000860468: C9081B06 06001101
	ds_bpermute_b32 v8, v15, v2                                // 000000860470: DACC0000 0800020F
	v_add_f32_e32 v3, v3, v10                                  // 000000860478: 06061503
	ds_bpermute_b32 v10, v15, v4                               // 00000086047C: DACC0000 0A00040F
	v_add_f32_e32 v5, v5, v12                                  // 000000860484: 060A1905
	ds_bpermute_b32 v12, v15, v6                               // 000000860488: DACC0000 0C00060F
	v_add_f32_e32 v7, v7, v14                                  // 000000860490: 060E1D07
	ds_bpermute_b32 v14, v15, v1                               // 000000860494: DACC0000 0E00010F
	s_waitcnt lgkmcnt(3)                                       // 00000086049C: BF89FC37
	v_add_f32_e32 v2, v2, v8                                   // 0000008604A0: 06041102
	ds_bpermute_b32 v9, v15, v3                                // 0000008604A4: DACC0000 0900030F
	s_waitcnt lgkmcnt(3)                                       // 0000008604AC: BF89FC37
	v_add_f32_e32 v4, v4, v10                                  // 0000008604B0: 06081504
	ds_bpermute_b32 v11, v15, v5                               // 0000008604B4: DACC0000 0B00050F
	s_waitcnt lgkmcnt(3)                                       // 0000008604BC: BF89FC37
	v_add_f32_e32 v6, v6, v12                                  // 0000008604C0: 060C1906
	ds_bpermute_b32 v13, v15, v7                               // 0000008604C4: DACC0000 0D00070F
	v_xor_b32_e32 v15, 2, v0                                   // 0000008604CC: 3A1E0082
	v_xor_b32_e32 v10, 1, v0                                   // 0000008604D0: 3A140081
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008604D4: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 0000008604D8: 7C981EA0
	v_cndmask_b32_e32 v15, v0, v15, vcc_lo                     // 0000008604DC: 021E1F00
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000008604E0: 7C9814A0
	s_waitcnt lgkmcnt(2)                                       // 0000008604E4: BF89FC27
	v_dual_add_f32 v3, v3, v9 :: v_dual_cndmask_b32 v0, v0, v10// 0000008604E8: C9121303 03001500
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008604F0: BF870003
	v_dual_add_f32 v8, v1, v14 :: v_dual_lshlrev_b32 v15, 2, v15// 0000008604F4: C9221D01 080E1E82
	s_waitcnt lgkmcnt(0)                                       // 0000008604FC: BF89FC07
	v_add_f32_e32 v7, v7, v13                                  // 000000860500: 060E1B07
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 000000860504: 7C943C80
	ds_bpermute_b32 v1, v15, v2                                // 000000860508: DACC0000 0100020F
	s_and_b32 s2, vcc_lo, s2                                   // 000000860510: 8B02026A
	s_waitcnt lgkmcnt(0)                                       // 000000860514: BF89FC07
	v_add_f32_e32 v10, v2, v1                                  // 000000860518: 06140302
	ds_bpermute_b32 v16, v15, v7                               // 00000086051C: DACC0000 1000070F
	v_add_f32_e32 v5, v5, v11                                  // 000000860524: 060A1705
	ds_bpermute_b32 v9, v15, v3                                // 000000860528: DACC0000 0900030F
	ds_bpermute_b32 v12, v15, v4                               // 000000860530: DACC0000 0C00040F
	ds_bpermute_b32 v14, v15, v6                               // 000000860538: DACC0000 0E00060F
	v_lshlrev_b32_e32 v17, 2, v0                               // 000000860540: 30220082
	s_waitcnt lgkmcnt(3)                                       // 000000860544: BF89FC37
	v_add_f32_e32 v0, v7, v16                                  // 000000860548: 06002107
	ds_bpermute_b32 v13, v15, v5                               // 00000086054C: DACC0000 0D00050F
	ds_bpermute_b32 v15, v15, v8                               // 000000860554: DACC0000 0F00080F
	s_waitcnt lgkmcnt(4)                                       // 00000086055C: BF89FC47
	v_add_f32_e32 v11, v3, v9                                  // 000000860560: 06161303
	s_waitcnt lgkmcnt(3)                                       // 000000860564: BF89FC37
	v_add_f32_e32 v1, v4, v12                                  // 000000860568: 06021904
	s_waitcnt lgkmcnt(1)                                       // 00000086056C: BF89FC17
	v_dual_add_f32 v3, v6, v14 :: v_dual_add_f32 v2, v5, v13   // 000000860570: C9081D06 03021B05
	s_waitcnt lgkmcnt(0)                                       // 000000860578: BF89FC07
	v_add_f32_e32 v5, v8, v15                                  // 00000086057C: 060A1F08
	ds_bpermute_b32 v12, v17, v10                              // 000000860580: DACC0000 0C000A11
	ds_bpermute_b32 v13, v17, v11                              // 000000860588: DACC0000 0D000B11
	ds_bpermute_b32 v6, v17, v1                                // 000000860590: DACC0000 06000111
	ds_bpermute_b32 v7, v17, v2                                // 000000860598: DACC0000 07000211
	ds_bpermute_b32 v8, v17, v3                                // 0000008605A0: DACC0000 08000311
	ds_bpermute_b32 v4, v17, v0                                // 0000008605A8: DACC0000 04000011
	ds_bpermute_b32 v9, v17, v5                                // 0000008605B0: DACC0000 09000511
	s_and_saveexec_b32 s3, s2                                  // 0000008605B8: BE832002
	s_cbranch_execz 320                                        // 0000008605BC: BFA50140 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x15c0>
	s_load_b32 s2, s[0:1], 0x48                                // 0000008605C0: F4000080 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000008605C8: BF89FC07
	v_dual_add_f32 v10, v10, v12 :: v_dual_add_f32 v11, v11, v13// 0000008605CC: C908190A 0A0A1B0B
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v2, v2, v7     // 0000008605D4: C9081305 05020F02
	v_dual_add_f32 v6, v1, v6 :: v_dual_add_f32 v3, v3, v8     // 0000008605DC: C9080D01 06021103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008605E4: BF870213
	v_bfe_u32 v12, v10, 16, 1                                  // 0000008605E8: D610000C 0205210A
	v_bfe_u32 v13, v11, 16, 1                                  // 0000008605F0: D610000D 0205210B
	s_lshl_b64 s[0:1], s[16:17], 2                             // 0000008605F8: 84808210
	s_lshl_b64 s[4:5], s[16:17], 3                             // 0000008605FC: 84848310
	v_add_f32_e32 v4, v0, v4                                   // 000000860600: 06080900
	v_add3_u32 v9, v10, v12, 0x7fff                            // 000000860604: D6550009 03FE190A 00007FFF
	v_add3_u32 v10, v11, v13, 0x7fff                           // 000000860610: D655000A 03FE1B0B 00007FFF
	v_bfe_u32 v11, v3, 16, 1                                   // 00000086061C: D610000B 02052103
	v_bfe_u32 v13, v5, 16, 1                                   // 000000860624: D610000D 02052105
	.long 0xd73c0000                                           // 00000086062C: D73C0000
	v_cndmask_b32_e32 v1, 2, v23, vcc_lo                       // 000000860630: 02022E82
	v_and_b32_e32 v7, 0xffff0000, v9                           // 000000860634: 360E12FF FFFF0000
	v_and_b32_e32 v8, 0xffff0000, v10                          // 00000086063C: 361014FF FFFF0000
	v_bfe_u32 v9, v6, 16, 1                                    // 000000860644: D6100009 02052106
	v_add3_u32 v3, v3, v11, 0x7fff                             // 00000086064C: D6550003 03FE1703 00007FFF
	v_bfe_u32 v12, v4, 16, 1                                   // 000000860658: D610000C 02052104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000860660: BF870214
	v_dual_mul_f32 v7, s2, v7 :: v_dual_mul_f32 v8, s2, v8     // 000000860664: C8C60E02 07081002
	v_add3_u32 v6, v6, v9, 0x7fff                              // 00000086066C: D6550006 03FE1306 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 000000860678: D6550005 03FE1B05 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000860684: BF870214
	v_add3_u32 v4, v4, v12, 0x7fff                             // 000000860688: D6550004 03FE1904 00007FFF
	v_mul_f32_e32 v7, 0xbfb8aa3b, v7                           // 000000860694: 100E0EFF BFB8AA3B
	v_bfe_u32 v10, v2, 16, 1                                   // 00000086069C: D610000A 02052102
	.long 0xd7006a00                                           // 0000008606A4: D7006A00
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 0000008606A8: 0202000C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008606AC: BF870214
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000008606B0: 360808FF FFFF0000
	v_exp_f32_e32 v7, v7                                       // 0000008606B8: 7E0E4B07
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 0000008606BC: 101010FF BFB8AA3B
	v_add3_u32 v2, v2, v10, 0x7fff                             // 0000008606C4: D6550002 03FE1502 00007FFF
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 0000008606D0: D5207C01 01AA020D
	v_and_b32_e32 v9, 0xffff0000, v3                           // 0000008606D8: 361206FF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000008606E0: 360C0CFF FFFF0000
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000008606E8: 360A0AFF FFFF0000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008606F0: BF8701A5
	v_add_f32_e32 v7, 1.0, v7                                  // 0000008606F4: 060E0EF2
	v_exp_f32_e32 v8, v8                                       // 0000008606F8: 7E104B08
	v_dual_mul_f32 v9, s2, v9 :: v_dual_mul_f32 v6, s2, v6     // 0000008606FC: C8C61202 09060C02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000860704: BF870113
	v_mul_f32_e32 v5, s2, v5                                   // 000000860708: 100A0A02
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 00000086070C: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000860714: BF870003
	v_mul_f32_e32 v3, 0xbfb8aa3b, v6                           // 000000860718: 10060CFF BFB8AA3B
	v_div_scale_f32 v6, null, v7, v7, 1.0                      // 000000860720: D6FC7C06 03CA0F07
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 000000860728: BF870205
	v_dual_mul_f32 v5, 0xbfb8aa3b, v5 :: v_dual_add_f32 v8, 1.0, v8// 00000086072C: C8C80AFF 050810F2 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000860738: BF870114
	v_exp_f32_e32 v9, v9                                       // 00000086073C: 7E124B09
	v_rcp_f32_e32 v13, v6                                      // 000000860740: 7E1A5506
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000860744: BF870091
	v_exp_f32_e32 v5, v5                                       // 000000860748: 7E0A4B05
	v_div_scale_f32 v10, null, v8, v8, 1.0                     // 00000086074C: D6FC7C0A 03CA1108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_3)// 000000860754: BF8703A1
	v_rcp_f32_e32 v14, v10                                     // 000000860758: 7E1C550A
	v_add_f32_e32 v9, 1.0, v9                                  // 00000086075C: 061212F2
	v_fma_f32 v15, -v6, v13, 1.0                               // 000000860760: D613000F 23CA1B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000860768: BF870091
	v_dual_fmac_f32 v13, v15, v13 :: v_dual_and_b32 v2, 0xffff0000, v2// 00000086076C: C8241B0F 0D0204FF FFFF0000
	v_dual_mul_f32 v11, s2, v2 :: v_dual_mul_f32 v4, s2, v4    // 000000860778: C8C60402 0B040802
	v_exp_f32_e32 v12, v3                                      // 000000860780: 7E184B03
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000860784: BF8701A6
	v_fma_f32 v16, -v10, v14, 1.0                              // 000000860788: D6130010 23CA1D0A
	.long 0xd7006a02                                           // 000000860790: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000860794: 02000100
	v_mul_f32_e32 v11, 0xbfb8aa3b, v11                         // 000000860798: 101616FF BFB8AA3B
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 0000008607A0: D5207C03 01AA0201
	v_div_scale_f32 v17, vcc_lo, 1.0, v7, 1.0                  // 0000008607A8: D6FC6A11 03CA0EF2
	v_div_scale_f32 v18, s0, 1.0, v8, 1.0                      // 0000008607B0: D6FC0012 03CA10F2
	v_fmac_f32_e32 v14, v16, v14                               // 0000008607B8: 561C1D10
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000008607BC: BF870005
	v_add_f32_e32 v12, 1.0, v12                                // 0000008607C0: 061818F2
	v_exp_f32_e32 v11, v11                                     // 0000008607C4: 7E164B0B
	v_mul_f32_e32 v16, v17, v13                                // 0000008607C8: 10201B11
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 0000008607CC: 100808FF BFB8AA3B
	s_waitcnt vmcnt(0)                                         // 0000008607D4: BF8903F7
	v_mul_f32_e32 v20, v18, v14                                // 0000008607D8: 10281D12
	v_div_scale_f32 v19, null, v12, v12, 1.0                   // 0000008607DC: D6FC7C13 03CA190C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008607E4: BF870113
	v_exp_f32_e32 v4, v4                                       // 0000008607E8: 7E084B04
	v_fma_f32 v22, -v10, v20, v18                              // 0000008607EC: D6130016 244A290A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 0000008607F4: BF870392
	v_rcp_f32_e32 v15, v19                                     // 0000008607F8: 7E1E5513
	v_add_f32_e32 v11, 1.0, v11                                // 0000008607FC: 061616F2
	v_fma_f32 v21, -v6, v16, v17                               // 000000860800: D6130015 24462106
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000860808: BF870193
	v_fmac_f32_e32 v20, v22, v14                               // 00000086080C: 56281D16
	v_div_scale_f32 v22, null, v11, v11, 1.0                   // 000000860810: D6FC7C16 03CA170B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000860818: BF870292
	v_fma_f32 v10, -v10, v20, v18                              // 00000086081C: D613000A 244A290A
	v_fma_f32 v23, -v19, v15, 1.0                              // 000000860824: D6130017 23CA1F13
	v_fmac_f32_e32 v16, v21, v13                               // 00000086082C: 56201B15
	v_div_scale_f32 v21, s1, 1.0, v12, 1.0                     // 000000860830: D6FC0115 03CA18F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000860838: BF870193
	v_fmac_f32_e32 v15, v23, v15                               // 00000086083C: 561E1F17
	v_fma_f32 v6, -v6, v16, v17                                // 000000860840: D6130006 24462106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000860848: BF8701A1
	v_div_fmas_f32 v6, v6, v13, v16                            // 00000086084C: D6370006 04421B06
	s_mov_b32 vcc_lo, s0                                       // 000000860854: BEEA0000
	v_mul_f32_e32 v13, v21, v15                                // 000000860858: 101A1F15
	v_div_scale_f32 v16, null, v9, v9, 1.0                     // 00000086085C: D6FC7C10 03CA1309
	v_div_fmas_f32 v10, v10, v14, v20                          // 000000860864: D637000A 04521D0A
	v_rcp_f32_e32 v14, v22                                     // 00000086086C: 7E1C5516
	s_mov_b32 vcc_lo, s1                                       // 000000860870: BEEA0001
	v_div_fixup_f32 v6, v6, v7, 1.0                            // 000000860874: D6270006 03CA0F06
	v_rcp_f32_e32 v17, v16                                     // 00000086087C: 7E225510
	v_div_fixup_f32 v7, v10, v8, 1.0                           // 000000860880: D6270007 03CA110A
	v_add_f32_e32 v10, 1.0, v4                                 // 000000860888: 061408F2
	v_fma_f32 v8, -v19, v13, v21                               // 00000086088C: D6130008 24561B13
	v_add_f32_e32 v4, v6, v6                                   // 000000860894: 06080D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000860898: BF870314
	v_add_f32_e32 v6, v7, v7                                   // 00000086089C: 060C0F07
	v_fma_f32 v7, -v22, v14, 1.0                               // 0000008608A0: D6130007 23CA1D16
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008608A8: BF870004
	v_fmac_f32_e32 v13, v8, v15                                // 0000008608AC: 561A1F08
	v_div_scale_f32 v8, null, v10, v10, 1.0                    // 0000008608B0: D6FC7C08 03CA150A
	v_div_scale_f32 v20, s2, 1.0, v10, 1.0                     // 0000008608B8: D6FC0214 03CA14F2
	s_clause 0x1                                               // 0000008608C0: BF850001
	global_store_b32 v[0:1], v4, off                           // 0000008608C4: DC6A0000 007C0400
	global_store_b32 v[2:3], v6, off                           // 0000008608CC: DC6A0000 007C0602
	v_fma_f32 v3, -v16, v17, 1.0                               // 0000008608D4: D6130003 23CA2310
	v_div_scale_f32 v6, s0, 1.0, v11, 1.0                      // 0000008608DC: D6FC0006 03CA16F2
	v_fmac_f32_e32 v14, v7, v14                                // 0000008608E4: 561C1D07
	v_rcp_f32_e32 v7, v8                                       // 0000008608E8: 7E0E5508
	v_fma_f32 v2, -v19, v13, v21                               // 0000008608EC: D6130002 24561B13
	v_fmac_f32_e32 v17, v3, v17                                // 0000008608F4: 56222303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000008608F8: BF8702A2
	v_div_fmas_f32 v2, v2, v15, v13                            // 0000008608FC: D6370002 04361F02
	v_div_scale_f32 v15, s1, 1.0, v9, 1.0                      // 000000860904: D6FC010F 03CA12F2
	v_fma_f32 v3, -v8, v7, 1.0                                 // 00000086090C: D6130003 23CA0F08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000860914: BF870113
	v_div_fixup_f32 v2, v2, v12, 1.0                           // 000000860918: D6270002 03CA1902
	v_fmac_f32_e32 v7, v3, v7                                  // 000000860920: 560E0F03
	.long 0xd7006a03                                           // 000000860924: D7006A03
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000860928: 02000900
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000086092C: BF870193
	v_add_f32_e32 v21, v2, v2                                  // 000000860930: 062A0502
	v_dual_mul_f32 v23, v20, v7 :: v_dual_add_f32 v18, 1.0, v5 // 000000860934: C8C80F14 17120AF2
	v_mul_f32_e32 v5, v6, v14                                  // 00000086093C: 100A1D06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000860940: BF870112
	v_div_scale_f32 v13, null, v18, v18, 1.0                   // 000000860944: D6FC7C0D 03CA2512
	v_fma_f32 v4, -v22, v5, v6                                 // 00000086094C: D6130004 241A0B16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000860954: BF870092
	v_rcp_f32_e32 v12, v13                                     // 000000860958: 7E18550D
	v_fmac_f32_e32 v5, v4, v14                                 // 00000086095C: 560A1D04
	v_add_co_ci_u32_e64 v4, null, s5, v1, vcc_lo               // 000000860960: D5207C04 01AA0205
	s_mov_b32 vcc_lo, s0                                       // 000000860968: BEEA0000
	v_mad_u64_u32 v[0:1], null, s16, 12, v[0:1]                // 00000086096C: D6FE7C00 04011810
	v_fma_f32 v6, -v22, v5, v6                                 // 000000860974: D6130006 241A0B16
	v_div_scale_f32 v22, s3, 1.0, v18, 1.0                     // 00000086097C: D6FC0316 03CA24F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000860984: BF870195
	v_fma_f32 v24, -v13, v12, 1.0                              // 000000860988: D6130018 23CA190D
	v_div_fmas_f32 v5, v6, v14, v5                             // 000000860990: D6370005 04161D06
	s_mov_b32 vcc_lo, s1                                       // 000000860998: BEEA0001
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000086099C: BF870112
	v_dual_fmac_f32 v12, v24, v12 :: v_dual_mul_f32 v19, v15, v17// 0000008609A0: C8061918 0C12230F
	v_div_fixup_f32 v5, v5, v11, 1.0                           // 0000008609A8: D6270005 03CA1705
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008609B0: BF870192
	v_mul_f32_e32 v14, v22, v12                                // 0000008609B4: 101C1916
	v_fma_f32 v2, -v16, v19, v15                               // 0000008609B8: D6130002 243E2710
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008609C0: BF870121
	v_fmac_f32_e32 v19, v2, v17                                // 0000008609C4: 56262302
	v_fma_f32 v2, -v8, v23, v20                                // 0000008609C8: D6130002 24522F08
	v_fma_f32 v6, -v16, v19, v15                               // 0000008609D0: D6130006 243E2710
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008609D8: BF870112
	v_fmac_f32_e32 v23, v2, v7                                 // 0000008609DC: 562E0F02
	v_div_fmas_f32 v2, v6, v17, v19                            // 0000008609E0: D6370002 044E2306
	v_fma_f32 v6, -v13, v14, v22                               // 0000008609E8: D6130006 245A1D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008609F0: BF8701A3
	v_fma_f32 v8, -v8, v23, v20                                // 0000008609F4: D6130008 24522F08
	s_mov_b32 vcc_lo, s2                                       // 0000008609FC: BEEA0002
	v_div_fixup_f32 v9, v2, v9, 1.0                            // 000000860A00: D6270009 03CA1302
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000860A08: BF8701C3
	v_fmac_f32_e32 v14, v6, v12                                // 000000860A0C: 561C1906
	v_mad_u64_u32 v[1:2], null, s17, 12, v[1:2]                // 000000860A10: D6FE7C01 04051811
	v_div_fmas_f32 v6, v8, v7, v23                             // 000000860A18: D6370006 045E0F08
	s_mov_b32 vcc_lo, s3                                       // 000000860A20: BEEA0003
	v_fma_f32 v2, -v13, v14, v22                               // 000000860A24: D6130002 245A1D0D
	v_add_f32_e32 v13, v9, v9                                  // 000000860A2C: 061A1309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000860A30: BF870193
	v_div_fixup_f32 v7, v6, v10, 1.0                           // 000000860A34: D6270007 03CA1506
	v_div_fmas_f32 v2, v2, v12, v14                            // 000000860A3C: D6370002 043A1902
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000860A44: BF870112
	v_add_f32_e32 v12, v7, v7                                  // 000000860A48: 06180F07
	v_div_fixup_f32 v2, v2, v18, 1.0                           // 000000860A4C: D6270002 03CA2502
	v_add_f32_e32 v11, v5, v5                                  // 000000860A54: 06160B05
	.long 0xd7006a05                                           // 000000860A58: D7006A05
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 000000860A5C: 02000903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000860A60: BF8700A1
	v_add_co_ci_u32_e64 v6, null, s5, v4, vcc_lo               // 000000860A64: D5207C06 01AA0805
	.long 0xd7006a07                                           // 000000860A6C: D7006A07
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000860A70: 02000900
	v_add_co_ci_u32_e64 v8, null, s5, v1, vcc_lo               // 000000860A74: D5207C08 01AA0205
	s_delay_alu instid0(VALU_DEP_4)                            // 000000860A7C: BF870004
	.long 0xd7006a09                                           // 000000860A80: D7006A09
	v_cndmask_b32_e32 v0, v5, v4, vcc_lo                       // 000000860A84: 02000905
	v_add_f32_e32 v2, v2, v2                                   // 000000860A88: 06040502
	v_add_co_ci_u32_e64 v10, null, s5, v6, vcc_lo              // 000000860A8C: D5207C0A 01AA0C05
	s_clause 0x4                                               // 000000860A94: BF850004
	global_store_b32 v[3:4], v21, off                          // 000000860A98: DC6A0000 007C1503
	global_store_b32 v[0:1], v11, off                          // 000000860AA0: DC6A0000 007C0B00
	global_store_b32 v[5:6], v13, off                          // 000000860AA8: DC6A0000 007C0D05
	global_store_b32 v[7:8], v12, off                          // 000000860AB0: DC6A0000 007C0C07
	global_store_b32 v[9:10], v2, off                          // 000000860AB8: DC6A0000 007C0209
	s_endpgm                                                   // 000000860AC0: BFB00000
		...

