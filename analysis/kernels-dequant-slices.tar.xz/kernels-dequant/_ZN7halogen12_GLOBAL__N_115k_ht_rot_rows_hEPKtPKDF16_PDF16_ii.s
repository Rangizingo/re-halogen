000000000022ef00 <_ZN7halogen12_GLOBAL__N_115k_ht_rot_rows_hEPKtPKDF16_PDF16_ii>:
; _ZN7halogen12_GLOBAL__N_115k_ht_rot_rows_hEPKtPKDF16_PDF16_ii():
	s_load_b64 s[4:5], s[0:1], 0x18                            // 00000022EF00: F4040100 F8000018
	s_mov_b32 s3, 0                                            // 00000022EF08: BE830080
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000022EF0C: 32020085
	s_lshl_b64 s[2:3], s[2:3], 3                               // 00000022EF10: 84828302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022EF14: BF870119
	v_mov_b32_e32 v2, s3                                       // 00000022EF18: 7E040203
	v_or_b32_e32 v1, s2, v1                                    // 00000022EF1C: 38020202
	s_mov_b32 s2, exec_lo                                      // 00000022EF20: BE82007E
	s_waitcnt lgkmcnt(0)                                       // 00000022EF24: BF89FC07
	s_ashr_i32 s10, s5, 31                                     // 00000022EF28: 860A9F05
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000022EF2C: BF870499
	s_lshr_b32 s6, s10, 25                                     // 00000022EF30: 8506990A
	s_add_i32 s3, s5, s6                                       // 00000022EF34: 81030605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000022EF38: BF870499
	s_ashr_i32 s3, s3, 7                                       // 00000022EF3C: 86038703
	s_mul_hi_i32 s7, s3, s4                                    // 00000022EF40: 97070403
	s_mul_i32 s6, s3, s4                                       // 00000022EF44: 96060403
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000022EF48: BF870009
	.long 0xd4d4007e                                           // 00000022EF4C: D4D4007E
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 00000022EF50: 02020206
	s_cbranch_execz 437                                        // 00000022EF54: BFA501B5 <_ZN7halogen12_GLOBAL__N_115k_ht_rot_rows_hEPKtPKDF16_PDF16_ii+0x72c>
	s_ashr_i32 s2, s3, 31                                      // 00000022EF58: 86029F03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022EF5C: BF870099
	v_or_b32_e32 v3, s2, v2                                    // 00000022EF60: 38060402
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 00000022EF64: 7C9A0680
	s_and_saveexec_b32 s4, vcc_lo                              // 00000022EF68: BE84206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000022EF6C: BF870009
	s_xor_b32 s4, exec_lo, s4                                  // 00000022EF70: 8D04047E
	s_cbranch_execz 170                                        // 00000022EF74: BFA500AA <_ZN7halogen12_GLOBAL__N_115k_ht_rot_rows_hEPKtPKDF16_PDF16_ii+0x320>
	s_ashr_i32 s6, s2, 31                                      // 00000022EF78: 86069F02
	v_ashrrev_i32_e32 v8, 31, v2                               // 00000022EF7C: 3410049F
	s_add_u32 s8, s3, s6                                       // 00000022EF80: 80080603
	s_mov_b32 s7, s6                                           // 00000022EF84: BE870006
	s_addc_u32 s9, s2, s6                                      // 00000022EF88: 82090602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000022EF8C: BF870499
	s_xor_b64 s[8:9], s[8:9], s[6:7]                           // 00000022EF90: 8D880608
	s_cvt_f32_u32 s2, s8                                       // 00000022EF94: BE826508
	s_cvt_f32_u32 s7, s9                                       // 00000022EF98: BE876509
	s_sub_u32 s11, 0, s8                                       // 00000022EF9C: 808B0880
	s_subb_u32 s12, 0, s9                                      // 00000022EFA0: 828C0980
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000022EFA4: BF870599
	s_fmamk_f32 s2, s7, 0x4f800000, s2                         // 00000022EFA8: A3020207 4F800000
	v_rcp_f32_e32 v3, s2                                       // 00000022EFB0: 7E065402
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000022EFB4: BF8700A5
	v_readfirstlane_b32 s2, v3                                 // 00000022EFB8: 7E040503
	.long 0xd7006a03                                           // 00000022EFBC: D7006A03
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 00000022EFC0: 02021101
	v_add_co_ci_u32_e64 v2, null, v2, v8, vcc_lo               // 00000022EFC4: D5207C02 01AA1102
	s_mul_f32 s2, s2, 0x5f7ffffc                               // 00000022EFCC: A202FF02 5F7FFFFC
	v_xor_b32_e32 v10, v3, v8                                  // 00000022EFD4: 3A141103
	v_xor_b32_e32 v9, v2, v8                                   // 00000022EFD8: 3A121102
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000022EFDC: BF870599
	s_mul_f32 s7, s2, 0x2f800000                               // 00000022EFE0: A207FF02 2F800000
	s_trunc_f32 s7, s7                                         // 00000022EFE8: BE876207
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 00000022EFEC: BF87052B
	s_fmamk_f32 s2, s7, 0xcf800000, s2                         // 00000022EFF0: A3020207 CF800000
	s_cvt_u32_f32 s7, s7                                       // 00000022EFF8: BE876707
	s_cvt_u32_f32 s2, s2                                       // 00000022EFFC: BE826702
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_2)// 00000022F000: BF87051A
	s_mul_i32 s13, s11, s7                                     // 00000022F004: 960D070B
	s_mul_hi_u32 s15, s11, s2                                  // 00000022F008: 968F020B
	s_mul_i32 s14, s12, s2                                     // 00000022F00C: 960E020C
	s_add_i32 s13, s15, s13                                    // 00000022F010: 810D0D0F
	s_mul_i32 s16, s11, s2                                     // 00000022F014: 9610020B
	s_add_i32 s13, s13, s14                                    // 00000022F018: 810D0E0D
	s_mul_hi_u32 s15, s2, s16                                  // 00000022F01C: 968F1002
	s_mul_i32 s18, s2, s13                                     // 00000022F020: 96120D02
	s_mul_hi_u32 s17, s7, s16                                  // 00000022F024: 96911007
	s_mul_i32 s14, s7, s16                                     // 00000022F028: 960E1007
	s_mul_hi_u32 s16, s2, s13                                  // 00000022F02C: 96900D02
	s_add_u32 s15, s15, s18                                    // 00000022F030: 800F120F
	s_addc_u32 s16, 0, s16                                     // 00000022F034: 82101080
	s_mul_hi_u32 s19, s7, s13                                  // 00000022F038: 96930D07
	s_add_u32 s14, s15, s14                                    // 00000022F03C: 800E0E0F
	s_mul_i32 s13, s7, s13                                     // 00000022F040: 960D0D07
	s_addc_u32 s14, s16, s17                                   // 00000022F044: 820E1110
	s_addc_u32 s15, s19, 0                                     // 00000022F048: 820F8013
	s_add_u32 s13, s14, s13                                    // 00000022F04C: 800D0D0E
	s_addc_u32 s14, 0, s15                                     // 00000022F050: 820E0F80
	s_add_u32 s2, s2, s13                                      // 00000022F054: 80020D02
	s_addc_u32 s7, s7, s14                                     // 00000022F058: 82070E07
	s_mul_hi_u32 s13, s11, s2                                  // 00000022F05C: 968D020B
	s_mul_i32 s14, s11, s2                                     // 00000022F060: 960E020B
	s_mul_i32 s11, s11, s7                                     // 00000022F064: 960B070B
	s_mul_i32 s12, s12, s2                                     // 00000022F068: 960C020C
	s_add_i32 s11, s13, s11                                    // 00000022F06C: 810B0B0D
	s_mul_i32 s13, s7, s14                                     // 00000022F070: 960D0E07
	s_add_i32 s11, s11, s12                                    // 00000022F074: 810B0C0B
	s_mul_hi_u32 s12, s2, s14                                  // 00000022F078: 968C0E02
	s_mul_i32 s17, s2, s11                                     // 00000022F07C: 96110B02
	s_mul_hi_u32 s16, s2, s11                                  // 00000022F080: 96900B02
	s_add_u32 s12, s12, s17                                    // 00000022F084: 800C110C
	s_mul_hi_u32 s15, s7, s14                                  // 00000022F088: 968F0E07
	s_addc_u32 s16, 0, s16                                     // 00000022F08C: 82101080
	s_mul_hi_u32 s14, s7, s11                                  // 00000022F090: 968E0B07
	s_add_u32 s12, s12, s13                                    // 00000022F094: 800C0D0C
	s_mul_i32 s11, s7, s11                                     // 00000022F098: 960B0B07
	s_addc_u32 s12, s16, s15                                   // 00000022F09C: 820C0F10
	s_addc_u32 s13, s14, 0                                     // 00000022F0A0: 820D800E
	s_add_u32 s11, s12, s11                                    // 00000022F0A4: 800B0B0C
	s_addc_u32 s12, 0, s13                                     // 00000022F0A8: 820C0D80
	s_add_u32 s2, s2, s11                                      // 00000022F0AC: 80020B02
	s_addc_u32 s7, s7, s12                                     // 00000022F0B0: 82070C07
	.long 0xd72d000b                                           // 00000022F0B4: D72D000B
	v_cndmask_b32_e32 v0, v10, v2, vcc_lo                      // 00000022F0B8: 0200050A
	v_mad_u64_u32 v[2:3], null, v10, s7, 0                     // 00000022F0BC: D6FE7C02 02000F0A
	v_mad_u64_u32 v[4:5], null, v9, s2, 0                      // 00000022F0C4: D6FE7C04 02000509
	v_mad_u64_u32 v[6:7], null, v9, s7, 0                      // 00000022F0CC: D6FE7C06 02000F09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022F0D4: BF870093
	.long 0xd7006a02                                           // 00000022F0D8: D7006A02
	v_cndmask_b32_e32 v1, v11, v2, vcc_lo                      // 00000022F0DC: 0202050B
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000022F0E0: D5207C03 01AA0680
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022F0E8: BF870112
	.long 0xd7006a02                                           // 00000022F0EC: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000022F0F0: 02020902
	v_add_co_ci_u32_e32 v2, vcc_lo, v3, v5, vcc_lo             // 00000022F0F4: 40040B03
	v_add_co_ci_u32_e32 v3, vcc_lo, 0, v7, vcc_lo              // 00000022F0F8: 40060E80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022F0FC: BF870092
	.long 0xd7006a04                                           // 00000022F100: D7006A04
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000022F104: 02020D02
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 00000022F108: D5207C05 01AA0680
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000022F110: BF8701A2
	.long 0xd72c0006                                           // 00000022F114: D72C0006
	v_cndmask_b32_e32 v1, s9, v4, vcc_lo                       // 00000022F118: 02020809
	v_mad_u64_u32 v[2:3], null, s8, v4, 0                      // 00000022F11C: D6FE7C02 02020808
	.long 0xd72c0007                                           // 00000022F124: D72C0007
	v_cndmask_b32_e32 v1, s8, v5, vcc_lo                       // 00000022F128: 02020A08
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022F12C: BF870112
	.long 0xd7016a02                                           // 00000022F130: D7016A02
	v_cndmask_b32_e32 v1, v10, v2, vcc_lo                      // 00000022F134: 0202050A
	v_add3_u32 v3, v3, v7, v6                                  // 00000022F138: D6550003 041A0F03
	.long 0xd7000207                                           // 00000022F140: D7000207
	v_cndmask_b32_e32 v0, v4, v130, vcc_lo                     // 00000022F144: 02010504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000022F148: BF870191
	v_add_co_ci_u32_e64 v10, null, 0, v5, s2                   // 00000022F14C: D5207C0A 000A0A80
	v_sub_nc_u32_e32 v6, v9, v3                                // 00000022F154: 4C0C0709
	.long 0xd701020b                                           // 00000022F158: D701020B
	v_cndmask_b32_e32 v0, v2, v8, vcc_lo                       // 00000022F15C: 02001102
	v_sub_co_ci_u32_e64 v3, null, v9, v3, vcc_lo               // 00000022F160: D5217C03 01AA0709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000022F168: BF870193
	v_subrev_co_ci_u32_e64 v6, null, s9, v6, vcc_lo            // 00000022F16C: D5227C06 01AA0C09
	v_cmp_le_u32_e32 vcc_lo, s8, v11                           // 00000022F174: 7C961608
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000022F178: BF870122
	v_subrev_co_ci_u32_e64 v6, null, 0, v6, s2                 // 00000022F17C: D5227C06 000A0C80
	v_cndmask_b32_e64 v9, 0, -1, vcc_lo                        // 00000022F184: D5010009 01A98280
	v_cmp_le_u32_e32 vcc_lo, s9, v6                            // 00000022F18C: 7C960C09
	v_cndmask_b32_e64 v11, 0, -1, vcc_lo                       // 00000022F190: D501000B 01A98280
	v_cmp_le_u32_e32 vcc_lo, s8, v2                            // 00000022F198: 7C960408
	v_cndmask_b32_e64 v2, 0, -1, vcc_lo                        // 00000022F19C: D5010002 01A98280
	v_cmp_le_u32_e32 vcc_lo, s9, v3                            // 00000022F1A4: 7C960609
	v_cndmask_b32_e64 v12, 0, -1, vcc_lo                       // 00000022F1A8: D501000C 01A98280
	v_cmp_eq_u32_e32 vcc_lo, s9, v6                            // 00000022F1B0: 7C940C09
	v_cndmask_b32_e32 v6, v11, v9, vcc_lo                      // 00000022F1B4: 020C130B
	.long 0xd7006a09                                           // 00000022F1B8: D7006A09
	v_cndmask_b32_e32 v0, v4, v129, vcc_lo                     // 00000022F1BC: 02010304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000022F1C0: BF8701D1
	v_add_co_ci_u32_e64 v11, null, 0, v5, vcc_lo               // 00000022F1C4: D5207C0B 01AA0A80
	v_cmp_eq_u32_e32 vcc_lo, s9, v3                            // 00000022F1CC: 7C940609
	v_cndmask_b32_e32 v2, v12, v2, vcc_lo                      // 00000022F1D0: 0204050C
	v_cmp_ne_u32_e32 vcc_lo, 0, v6                             // 00000022F1D4: 7C9A0C80
	v_xor_b32_e32 v6, s6, v8                                   // 00000022F1D8: 3A0C1006
	.long 0xd44d0002                                           // 00000022F1DC: D44D0002
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 00000022F1E0: 02020480
	v_dual_cndmask_b32 v3, v11, v10 :: v_dual_cndmask_b32 v2, v9, v7// 00000022F1E4: CA52150B 03020F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022F1EC: BF870111
	v_cndmask_b32_e64 v3, v5, v3, s2                           // 00000022F1F0: D5010003 000A0705
	v_cndmask_b32_e64 v2, v4, v2, s2                           // 00000022F1F8: D5010002 000A0504
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022F200: BF870112
	v_xor_b32_e32 v4, v3, v6                                   // 00000022F204: 3A080D03
	v_xor_b32_e32 v2, v2, v6                                   // 00000022F208: 3A040D02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022F20C: BF870091
	.long 0xd7016a03                                           // 00000022F210: D7016A03
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000022F214: 02020D02
	v_sub_co_ci_u32_e64 v4, null, v4, v6, vcc_lo               // 00000022F218: D5217C04 01AA0D04
	s_and_not1_saveexec_b32 s2, s4                             // 00000022F220: BE823004
	s_cbranch_execz 32                                         // 00000022F224: BFA50020 <_ZN7halogen12_GLOBAL__N_115k_ht_rot_rows_hEPKtPKDF16_PDF16_ii+0x3a8>
	v_cvt_f32_u32_e32 v2, s3                                   // 00000022F228: 7E040C03
	s_sub_i32 s4, 0, s3                                        // 00000022F22C: 81840380
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000022F230: BF870291
	v_rcp_iflag_f32_e32 v2, v2                                 // 00000022F234: 7E045702
	v_mul_f32_e32 v2, 0x4f7ffffe, v2                           // 00000022F238: 100404FF 4F7FFFFE
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022F240: BF870091
	v_cvt_u32_f32_e32 v2, v2                                   // 00000022F244: 7E040F02
	.long 0xd72c0003                                           // 00000022F248: D72C0003
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000022F24C: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022F250: BF870091
	.long 0xd72d0003                                           // 00000022F254: D72D0003
	v_cndmask_b32_e32 v1, v2, v3, vcc_lo                       // 00000022F258: 02020702
	v_add_nc_u32_e32 v2, v2, v3                                // 00000022F25C: 4A040702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022F260: BF870091
	.long 0xd72d0002                                           // 00000022F264: D72D0002
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000022F268: 02020501
	.long 0xd72c0003                                           // 00000022F26C: D72C0003
	v_cndmask_b32_e32 v0, v2, v3, vcc_lo                       // 00000022F270: 02000702
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000022F274: 4A080481
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022F278: BF870092
	v_sub_nc_u32_e32 v3, v1, v3                                // 00000022F27C: 4C060701
	v_subrev_nc_u32_e32 v5, s3, v3                             // 00000022F280: 4E0A0603
	v_cmp_le_u32_e32 vcc_lo, s3, v3                            // 00000022F284: 7C960603
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022F288: BF870092
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_cndmask_b32 v2, v2, v4// 00000022F28C: CA520B03 03020902
	v_cmp_le_u32_e32 vcc_lo, s3, v3                            // 00000022F294: 7C960603
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022F298: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000022F29C: 4A080481
	v_dual_cndmask_b32 v3, v2, v4 :: v_dual_mov_b32 v4, 0      // 00000022F2A0: CA500902 03040080
	s_or_b32 exec_lo, exec_lo, s2                              // 00000022F2A8: 8C7E027E
	s_load_b128 s[12:15], s[0:1], null                         // 00000022F2AC: F4080300 F8000000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022F2B4: BF870111
	.long 0xd72c0005                                           // 00000022F2B8: D72C0005
	v_cndmask_b32_e32 v0, v3, v3, vcc_lo                       // 00000022F2BC: 02000703
	.long 0xd72c0004                                           // 00000022F2C0: D72C0004
	v_cndmask_b32_e32 v0, v4, v5, vcc_lo                       // 00000022F2C4: 02000B04
	.long 0xd72c0006                                           // 00000022F2C8: D72C0006
	v_cndmask_b32_e32 v0, v3, v10, vcc_lo                      // 00000022F2CC: 02001503
	v_mad_u64_u32 v[2:3], null, v3, s5, 0                      // 00000022F2D0: D6FE7C02 02000B03
	v_and_b32_e32 v9, 31, v0                                   // 00000022F2D8: 3612009F
	s_load_b64 s[0:1], s[0:1], 0x10                            // 00000022F2DC: F4040000 F8000010
	s_mov_b32 s2, 0x76543210                                   // 00000022F2E4: BE8200FF 76543210
	s_mov_b32 s3, 0x3db504f3                                   // 00000022F2EC: BE8300FF 3DB504F3
	v_sub_nc_u32_e32 v1, v1, v5                                // 00000022F2F4: 4C020B01
	v_lshlrev_b32_e32 v7, 2, v9                                // 00000022F2F8: 300E1282
	v_mov_b32_e32 v5, 0                                        // 00000022F2FC: 7E0A0280
	v_add3_u32 v3, v3, v6, v4                                  // 00000022F300: D6550003 04120D03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022F308: BF870113
	v_lshl_or_b32 v4, v1, 7, v7                                // 00000022F30C: D6560004 041D0F01
	.long 0xd73c0001                                           // 00000022F314: D73C0001
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 00000022F318: 02020481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000022F31C: BF870122
	.long 0xd73c0003                                           // 00000022F320: D73C0003
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000022F324: 02020881
	s_waitcnt lgkmcnt(0)                                       // 00000022F328: BF89FC07
	.long 0xd7006a05                                           // 00000022F32C: D7006A05
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 00000022F330: 0202020C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022F334: BF870111
	v_add_co_ci_u32_e64 v6, null, s13, v2, vcc_lo              // 00000022F338: D5207C06 01AA040D
	.long 0xd7006a05                                           // 00000022F340: D7006A05
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 00000022F344: 02020705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000022F348: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v6, v4, vcc_lo               // 00000022F34C: D5207C06 01AA0906
	.long 0xd7006a07                                           // 00000022F354: D7006A07
	v_cndmask_b32_e32 v1, s14, v3, vcc_lo                      // 00000022F358: 0202060E
	v_add_co_ci_u32_e64 v8, null, s15, v4, vcc_lo              // 00000022F35C: D5207C08 01AA080F
	global_load_b64 v[5:6], v[5:6], off                        // 00000022F364: DC560000 057C0005
	global_load_b64 v[7:8], v[7:8], off                        // 00000022F36C: DC560000 077C0007
	s_waitcnt vmcnt(1)                                         // 00000022F374: BF8907F7
	.long 0x7e143905                                           // 00000022F378: 7E143905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000022F37C: 360A0AFF FFFF0000
	.long 0x7e163906                                           // 00000022F384: 7E163906
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000022F388: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000022F390: BF8701D4
	v_lshlrev_b32_e32 v10, 16, v10                             // 00000022F394: 30141490
	s_waitcnt vmcnt(0)                                         // 00000022F398: BF8903F7
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000022F39C: CC200805 8A020B07
	v_lshlrev_b32_e32 v11, 16, v11                             // 00000022F3A4: 30161690
	v_fma_mix_f32 v6, v8, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000022F3A8: CC200806 8A020D08
	v_fma_mix_f32 v15, v7, v10, v5 op_sel_hi:[1,0,0]           // 00000022F3B0: CC20000F 0C161507
	v_fma_mix_f32 v5, v7, v10, -v5 op_sel_hi:[1,0,0]           // 00000022F3B8: CC200005 8C161507
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000022F3C0: BF870243
	v_fma_mix_f32 v7, v8, v11, v6 op_sel_hi:[1,0,0]            // 00000022F3C4: CC200007 0C1A1708
	v_and_b32_e32 v12, 1, v0                                   // 00000022F3CC: 36180081
	v_fma_mix_f32 v6, v8, v11, -v6 op_sel_hi:[1,0,0]           // 00000022F3D0: CC200006 8C1A1708
	v_and_b32_e32 v14, 4, v0                                   // 00000022F3D8: 361C0084
	v_add_f32_e32 v8, v15, v7                                  // 00000022F3DC: 06100F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000022F3E0: BF870233
	v_dual_sub_f32 v7, v15, v7 :: v_dual_add_f32 v10, v5, v6   // 00000022F3E4: C9480F0F 070A0D05
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 00000022F3EC: 7C941880
	v_sub_f32_e32 v5, v5, v6                                   // 00000022F3F0: 080A0D05
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022F3F4: 7E0C02FA FF016108
	s_delay_alu instid0(VALU_DEP_4)                            // 00000022F3FC: BF870004
	v_mov_b32_dpp v12, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022F400: 7E1802FA FF016107
	v_mov_b32_dpp v11, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022F408: 7E1602FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000022F410: D501000A 21AA150A
	v_and_b32_e32 v13, 2, v0                                   // 00000022F418: 361A0082
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000022F41C: D5010008 21AA1108
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022F424: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000022F42C: D5010005 21AA0B05
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000022F434: D5010007 21AA0F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000022F43C: BF870244
	v_add_f32_e32 v6, v8, v6                                   // 00000022F440: 060C0D08
	v_add_f32_e32 v8, v10, v11                                 // 00000022F444: 0610170A
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 00000022F448: 7C941A80
	v_add_f32_e32 v5, v5, v15                                  // 00000022F44C: 060A1F05
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022F450: 7E1402FA FF016206
	s_delay_alu instid0(VALU_DEP_4)                            // 00000022F458: BF870004
	v_mov_b32_dpp v11, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022F45C: 7E1602FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000022F464: D5010008 21AA1108
	v_add_f32_e32 v7, v7, v12                                  // 00000022F46C: 060E1907
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000022F470: D5010006 21AA0D06
	v_mov_b32_dpp v13, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022F478: 7E1A02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000022F480: D5010005 21AA0B05
	v_add_f32_e32 v8, v8, v11                                  // 00000022F488: 06101708
	v_mov_b32_dpp v12, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022F48C: 7E1802FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000022F494: D5010007 21AA0F07
	v_add_f32_e32 v6, v6, v10                                  // 00000022F49C: 060C1506
	v_cmp_eq_u32_e32 vcc_lo, 0, v14                            // 00000022F4A0: 7C941C80
	v_dual_add_f32 v5, v5, v13 :: v_dual_and_b32 v0, 8, v0     // 00000022F4A4: C9241B05 05000088
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022F4AC: 7E1602FA FF016408
	s_delay_alu instid0(VALU_DEP_4)                            // 00000022F4B4: BF870004
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022F4B8: 7E1402FA FF016406
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000022F4C0: D5010008 21AA1108
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000022F4C8: D5010006 21AA0D06
	v_add_f32_e32 v7, v7, v12                                  // 00000022F4D0: 060E1907
	v_mov_b32_dpp v13, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022F4D4: 7E1A02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000022F4DC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000022F4E4: BF870214
	v_add_f32_e32 v6, v6, v10                                  // 00000022F4E8: 060C1506
	v_mov_b32_dpp v12, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022F4EC: 7E1802FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000022F4F4: D5010007 21AA0F07
	v_add_f32_e32 v8, v8, v11                                  // 00000022F4FC: 06101708
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 00000022F500: 7C940080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000022F504: BF870223
	v_dual_add_f32 v0, v5, v13 :: v_dual_add_f32 v5, v7, v12   // 00000022F508: C9081B05 00041907
	v_mov_b32_dpp v7, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022F510: 7E0E02FA FF016806
	v_mov_b32_dpp v10, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022F518: 7E1402FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000022F520: D5010008 21AA1108
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000022F528: D5010006 21AA0D06
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022F530: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000022F538: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000022F540: BF870143
	v_dual_add_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v10    // 00000022F544: C9080F06 06061508
	v_mov_b32_dpp v12, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022F54C: 7E1802FA FF016800
	v_cndmask_b32_e64 v0, -v0, v0, vcc_lo                      // 00000022F554: D5010000 21AA0100
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 00000022F55C: 7C981290
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v0, v0, v12   // 00000022F560: C9081705 05001900
	v_cndmask_b32_e64 v9, -v7, v7, vcc_lo                      // 00000022F568: D5010009 21AA0F07
	v_permlanex16_b32 v7, v7, s2, 0xfedcba98                   // 00000022F570: D65C0007 03FC0507 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000022F57C: BF870233
	v_mov_b32_e32 v10, v5                                      // 00000022F580: 7E140305
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000022F584: D5010005 21AA0B05
	v_dual_mov_b32 v11, v0 :: v_dual_mov_b32 v8, v6            // 00000022F58C: CA100100 0B080106
	v_add_f32_e32 v7, v9, v7                                   // 00000022F594: 060E0F09
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000022F598: D5010006 21AA0D06
	v_cndmask_b32_e64 v0, -v0, v0, vcc_lo                      // 00000022F5A0: D5010000 21AA0100
	v_permlanex16_b32 v10, v10, s2, 0xfedcba98                 // 00000022F5A8: D65C000A 03FC050A FEDCBA98
	v_permlanex16_b32 v8, v8, s2, 0xfedcba98                   // 00000022F5B4: D65C0008 03FC0508 FEDCBA98
	v_permlanex16_b32 v11, v11, s2, 0xfedcba98                 // 00000022F5C0: D65C000B 03FC050B FEDCBA98
	.long 0xd7006a01                                           // 00000022F5CC: D7006A01
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 00000022F5D0: 02020200
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000022F5D4: BF870211
	v_add_co_ci_u32_e64 v2, null, s1, v2, vcc_lo               // 00000022F5D8: D5207C02 01AA0401
	v_dual_add_f32 v6, v6, v8 :: v_dual_add_f32 v5, v5, v10    // 00000022F5E0: C9081106 06041505
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000022F5E8: BF870214
	v_add_f32_e32 v8, v0, v11                                  // 00000022F5EC: 06101700
	.long 0xd7006a00                                           // 00000022F5F0: D7006A00
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000022F5F4: 02020701
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022F5F8: BF870001
	v_add_co_ci_u32_e64 v1, null, v2, v4, vcc_lo               // 00000022F5FC: D5207C01 01AA0902
	v_fma_mixhi_f16 v2, v7, s3, 0                              // 00000022F604: CC220002 02000707
	v_fma_mixlo_f16 v2, v6, s3, 0                              // 00000022F60C: CC210002 02000706
	v_fma_mixhi_f16 v3, v8, s3, 0                              // 00000022F614: CC220003 02000708
	v_fma_mixlo_f16 v3, v5, s3, 0                              // 00000022F61C: CC210003 02000705
	global_store_b64 v[0:1], v[2:3], off                       // 00000022F624: DC6E0000 007C0200
	s_endpgm                                                   // 00000022F62C: BFB00000
		...

