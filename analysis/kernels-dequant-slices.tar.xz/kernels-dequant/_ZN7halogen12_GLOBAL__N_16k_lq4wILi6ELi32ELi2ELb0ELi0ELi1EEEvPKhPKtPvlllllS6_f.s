0000000000568100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000568100: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000568108: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000056810C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000568110: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 000000568114: 3602008F
	v_lshrrev_b32_e32 v28, 6, v0                               // 000000568118: 32380086
	v_bfe_u32 v29, v0, 5, 1                                    // 00000056811C: D610001D 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 000000568124: 360404BC
	v_and_b32_e32 v30, 31, v0                                  // 000000568128: 363C009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000056812C: 30020282
	.long 0x7f0a3880                                           // 000000568130: 7F0A3880
	v_lshlrev_b32_e32 v6, 2, v0                                // 000000568134: 300C0082
	s_waitcnt lgkmcnt(0)                                       // 000000568138: BF89FC07
	s_clause 0x1                                               // 00000056813C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000568140: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000568148: DC520000 04040002
	s_add_u32 s0, s4, s16                                      // 000000568150: 80001004
	s_addc_u32 s1, s5, s17                                     // 000000568154: 82011105
	s_ashr_i32 s16, s11, 31                                    // 000000568158: 86109F0B
	v_mov_b32_e32 v2, s3                                       // 00000056815C: 7E040203
	s_lshr_b32 s16, s16, 27                                    // 000000568160: 85109B10
	v_or_b32_e32 v1, s2, v28                                   // 000000568164: 38023802
	s_add_u32 s16, s10, s16                                    // 000000568168: 8010100A
	s_addc_u32 s17, s11, 0                                     // 00000056816C: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568170: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000568174: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000568178: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 00000056817C: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000568180: BF870499
	s_lshr_b32 s20, s17, 31                                    // 000000568184: 85149F11
	s_add_i32 s17, s17, s20                                    // 000000568188: 81111411
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000056818C: 02020280
	s_ashr_i32 s17, s17, 1                                     // 000000568190: 86118111
	v_cndmask_b32_e64 v2, 0, s3, vcc_lo                        // 000000568194: D5010002 01A80680
	.long 0xd72c0007                                           // 00000056819C: D72C0007
	v_cndmask_b32_e32 v1, s17, v29, vcc_lo                     // 0000005681A0: 02023A11
	s_cmpk_lt_i32 s16, 0x201                                   // 0000005681A4: B3900201
	.long 0xd72c0009                                           // 0000005681A8: D72C0009
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 0000005681AC: 02020213
	v_mad_u64_u32 v[24:25], null, s18, v1, s[0:1]              // 0000005681B0: D6FE7C18 00020212
	s_cselect_b32 s0, -1, 0                                    // 0000005681B8: 980080C1
	s_cmpk_gt_i32 s16, 0x200                                   // 0000005681BC: B2900200
	v_add_nc_u32_e32 v11, s17, v7                              // 0000005681C0: 4A160E11
	v_add_nc_u32_e32 v31, v7, v30                              // 0000005681C4: 4A3E3D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000005681C8: BF8704A2
	v_min_i32_e32 v32, s16, v11                                // 0000005681CC: 22401610
	s_cselect_b32 s16, -1, 0                                   // 0000005681D0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000005681D4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000005681D8: BF870151
	.long 0xd4410001                                           // 0000005681DC: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000005681E0: 0202411F
	s_waitcnt vmcnt(1)                                         // 0000005681E4: BF8907F7
	v_bfe_u32 v8, v3, 16, 1                                    // 0000005681E8: D6100008 02052103
	s_waitcnt vmcnt(0)                                         // 0000005681F0: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 0000005681F4: D610000A 02052104
	v_add3_u32 v3, v3, v8, 0x7fff                              // 0000005681FC: D6550003 03FE1103 00007FFF
	.long 0xd72c0008                                           // 000000568208: D72C0008
	v_cndmask_b32_e32 v1, s18, v2, vcc_lo                      // 00000056820C: 02020412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000568210: BF870193
	v_add3_u32 v4, v4, v10, 0x7fff                             // 000000568214: D6550004 03FE1504 00007FFF
	.long 0x7e0a3983                                           // 000000568220: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000568224: BF870113
	v_add3_u32 v33, v9, v25, v8                                // 000000568228: D6550021 04223309
	v_and_or_b32 v3, 0xffff0000, v4, v5                        // 000000568230: D6570003 041608FF FFFF0000
	ds_store_b32 v6, v3                                        // 00000056823C: D8340000 00000306
	s_waitcnt lgkmcnt(0)                                       // 000000568244: BF89FC07
	s_barrier                                                  // 000000568248: BFBD0000
	buffer_gl0_inv                                             // 00000056824C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000568254: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 000000568258: CA100080 09080080
	s_and_saveexec_b32 s17, s1                                 // 000000568260: BE912001
	s_cbranch_execz 11                                         // 000000568264: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v3, 1, v31                               // 000000568268: 30063E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056826C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000568270: 3408069F
	.long 0xd7006a03                                           // 000000568274: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000568278: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000056827C: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000568284: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000056828C: BF8903F7
	v_cvt_f32_f16_e32 v8, v3                                   // 000000568290: 7E101703
	s_or_b32 exec_lo, exec_lo, s17                             // 000000568294: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v31                               // 000000568298: 4A063EA0
	s_mov_b32 s1, exec_lo                                      // 00000056829C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005682A0: BF870001
	.long 0xd4c1007e                                           // 0000005682A4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000005682A8: 02024103
	s_cbranch_execz 11                                         // 0000005682AC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000005682B0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005682B4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000005682B8: 3408069F
	.long 0xd7006a03                                           // 0000005682BC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000005682C0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000005682C4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000005682CC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000005682D4: BF8903F7
	v_cvt_f32_f16_e32 v9, v3                                   // 0000005682D8: 7E121703
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005682DC: 8C7E017E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v3, 64, v31     // 0000005682E0: CA200080 0A023EC0
	v_mov_b32_e32 v11, 0                                       // 0000005682E8: 7E160280
	s_mov_b32 s1, exec_lo                                      // 0000005682EC: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005682F0: BF870002
	.long 0xd4c1007e                                           // 0000005682F4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000005682F8: 02024103
	s_cbranch_execz 11                                         // 0000005682FC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000568300: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568304: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000568308: 3408069F
	.long 0xd7006a03                                           // 00000056830C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000568310: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000568314: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000056831C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000568324: BF8903F7
	v_cvt_f32_f16_e32 v10, v3                                  // 000000568328: 7E141703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000056832C: 8C7E017E
	v_add_nc_u32_e32 v3, 0x60, v31                             // 000000568330: 4A063EFF 00000060
	s_mov_b32 s1, exec_lo                                      // 000000568338: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056833C: BF870001
	.long 0xd4c1007e                                           // 000000568340: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000568344: 02024103
	s_cbranch_execz 11                                         // 000000568348: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000056834C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568350: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000568354: 3408069F
	.long 0xd7006a03                                           // 000000568358: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000056835C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000568360: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000568368: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000568370: BF8903F7
	v_cvt_f32_f16_e32 v11, v3                                  // 000000568374: 7E161703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000568378: 8C7E017E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v3, 0x80, v31   // 00000056837C: CA200080 0C023EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 000000568388: 7E1A0280
	s_mov_b32 s1, exec_lo                                      // 00000056838C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000568390: BF870002
	.long 0xd4c1007e                                           // 000000568394: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000568398: 02024103
	s_cbranch_execz 11                                         // 00000056839C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000005683A0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005683A4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000005683A8: 3408069F
	.long 0xd7006a03                                           // 0000005683AC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000005683B0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000005683B4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000005683BC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000005683C4: BF8903F7
	v_cvt_f32_f16_e32 v12, v3                                  // 0000005683C8: 7E181703
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005683CC: 8C7E017E
	v_add_nc_u32_e32 v3, 0xa0, v31                             // 0000005683D0: 4A063EFF 000000A0
	s_mov_b32 s1, exec_lo                                      // 0000005683D8: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005683DC: BF870001
	.long 0xd4c1007e                                           // 0000005683E0: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000005683E4: 02024103
	s_cbranch_execz 11                                         // 0000005683E8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000005683EC: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005683F0: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000005683F4: 3408069F
	.long 0xd7006a03                                           // 0000005683F8: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000005683FC: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000568400: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000568408: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000568410: BF8903F7
	v_cvt_f32_f16_e32 v13, v3                                  // 000000568414: 7E1A1703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000568418: 8C7E017E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v3, 0xc0, v31   // 00000056841C: CA200080 0E023EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 000000568428: 7E1E0280
	s_mov_b32 s1, exec_lo                                      // 00000056842C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000568430: BF870002
	.long 0xd4c1007e                                           // 000000568434: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000568438: 02024103
	s_cbranch_execz 11                                         // 00000056843C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000568440: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568444: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000568448: 3408069F
	.long 0xd7006a03                                           // 00000056844C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000568450: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000568454: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000056845C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000568464: BF8903F7
	v_cvt_f32_f16_e32 v14, v3                                  // 000000568468: 7E1C1703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000056846C: 8C7E017E
	v_add_nc_u32_e32 v3, 0xe0, v31                             // 000000568470: 4A063EFF 000000E0
	s_mov_b32 s1, exec_lo                                      // 000000568478: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056847C: BF870001
	.long 0xd4c1007e                                           // 000000568480: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000568484: 02024103
	s_cbranch_execz 11                                         // 000000568488: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000056848C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568490: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000568494: 3408069F
	.long 0xd7006a03                                           // 000000568498: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000056849C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000005684A0: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000005684A8: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000005684B0: BF8903F7
	v_cvt_f32_f16_e32 v15, v3                                  // 0000005684B4: 7E1E1703
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005684B8: 8C7E017E
	s_branch 9                                                 // 0000005684BC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v8, 0                                        // 0000005684C0: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005684C4: BF870001
	v_mov_b32_e32 v9, v8                                       // 0000005684C8: 7E120308
	v_mov_b32_e32 v10, v8                                      // 0000005684CC: 7E140308
	v_mov_b32_e32 v11, v8                                      // 0000005684D0: 7E160308
	v_mov_b32_e32 v12, v8                                      // 0000005684D4: 7E180308
	v_mov_b32_e32 v13, v8                                      // 0000005684D8: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 0000005684DC: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 0000005684E0: 7E1E0308
	s_add_u32 s4, s4, s14                                      // 0000005684E4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 0000005684E8: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 0000005684EC: 85019F0B
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v27, 0             // 0000005684F0: CA100080 141A0080
	s_add_u32 s14, s10, s1                                     // 0000005684F8: 800E010A
	s_addc_u32 s15, s11, 0                                     // 0000005684FC: 820F800B
	.long 0xd4410001                                           // 000000568500: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000568504: 0202411F
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000568508: 868E810E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v21, 0             // 00000056850C: CA100080 22140080
	v_mad_u64_u32 v[25:26], null, v1, s14, s[4:5]              // 000000568514: D6FE7C19 00101D01
	.long 0xd72c0001                                           // 00000056851C: D72C0001
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 000000568520: 02001F01
	.long 0xd72c0002                                           // 000000568524: D72C0002
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 000000568528: 02001D02
	v_cndmask_b32_e64 v35, 0, 1, s16                           // 00000056852C: D5010023 00410280
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000568534: CA100080 16160080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000056853C: BF870003
	v_add3_u32 v36, v2, v26, v1                                // 000000568540: D6550024 04063502
	s_and_saveexec_b32 s4, s1                                  // 000000568548: BE842001
	s_cbranch_execz 22                                         // 00000056854C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 4, v31                               // 000000568550: 30023E84
	v_mov_b32_e32 v27, 0                                       // 000000568554: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568558: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000056855C: 3404029F
	.long 0xd7006a01                                           // 000000568560: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 000000568564: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 000000568568: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000568570: 916A107E
	global_load_b128 v[20:23], v[1:2], off                     // 000000568574: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 00000056857C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 1, v31                               // 000000568580: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568584: BF870091
	.long 0xd7006a01                                           // 000000568588: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 00000056858C: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 000000568590: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 000000568598: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000005685A0: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 0000005685A4: 7E361701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000005685A8: 8C7E047E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 0000005685AC: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 0000005685B4: CA100080 28280080
	v_mov_b32_e32 v37, 0                                       // 0000005685BC: 7E4A0280
	s_and_saveexec_b32 s14, s1                                 // 0000005685C0: BE8E2001
	s_cbranch_execz 548                                        // 0000005685C4: BFA50224 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xd58>
	v_dual_mov_b32 v40, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 0000005685C8: CA200080 28003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 0000005685D0: CA220080 251A3E85
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v34, 0             // 0000005685D8: CA100080 27220080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005685E0: BF870003
	v_dual_mov_b32 v41, 0 :: v_dual_lshlrev_b32 v42, 4, v1     // 0000005685E4: CA220080 292A0284
	v_dual_mov_b32 v38, 0 :: v_dual_lshlrev_b32 v43, 1, v1     // 0000005685EC: CA220080 262A0281
	v_mov_b32_e32 v44, v27                                     // 0000005685F4: 7E58031B
	s_mul_i32 s1, s11, 6                                       // 0000005685F8: 9601860B
	s_mul_hi_u32 s15, s10, 6                                   // 0000005685FC: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000568600: 8484820A
	s_add_i32 s15, s15, s1                                     // 000000568604: 810F010F
	s_mul_i32 s17, s10, 6                                      // 000000568608: 9611860A
	s_mov_b32 s16, 0                                           // 00000056860C: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000568610: 848A810A
	s_branch 492                                               // 000000568614: BFA001EC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xcc8>
	s_or_b32 exec_lo, exec_lo, s18                             // 000000568618: 8C7E127E
	v_cndmask_b32_e64 v55, v27, v8, s0                         // 00000056861C: D5010037 0002111B
	v_cndmask_b32_e64 v2, v9, v10, s0                          // 000000568624: D5010002 00021509
	v_cndmask_b32_e64 v1, v8, v9, s0                           // 00000056862C: D5010001 00021308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 000000568634: CA24010F 080828FF 000000FF
	v_cndmask_b32_e64 v7, v14, v15, s0                         // 000000568640: D5010007 00021F0E
	v_cndmask_b32_e64 v6, v13, v14, s0                         // 000000568648: D5010006 00021D0D
	v_cndmask_b32_e64 v5, v12, v13, s0                         // 000000568650: D5010005 00021B0C
	v_cndmask_b32_e64 v4, v11, v12, s0                         // 000000568658: D5010004 0002190B
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000568660: 30121282
	v_cndmask_b32_e64 v3, v10, v11, s0                         // 000000568664: D5010003 0002170A
	v_ashrrev_i32_e32 v27, 31, v26                             // 00000056866C: 3436349F
	s_and_b32 s1, exec_lo, s1                                  // 000000568670: 8B01017E
	v_add_nc_u32_e32 v42, 0x200, v42                           // 000000568674: 4A5454FF 00000200
	ds_load_b32 v15, v9                                        // 00000056867C: D8D80000 0F000009
	v_lshrrev_b32_e32 v9, 6, v20                               // 000000568684: 32122886
	s_or_b32 s16, s1, s16                                      // 000000568688: 8C101001
	v_add_nc_u32_e32 v43, 64, v43                              // 00000056868C: 4A5656C0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000568690: BF8700B2
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000568694: 361212FF 000003FC
	ds_load_b32 v56, v9                                        // 00000056869C: D8D80000 38000009
	v_lshrrev_b32_e32 v9, 14, v20                              // 0000005686A4: 3212288E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000005686A8: 361212FF 000003FC
	ds_load_b32 v57, v9                                        // 0000005686B0: D8D80000 39000009
	v_lshrrev_b32_e32 v9, 22, v20                              // 0000005686B8: 32122896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005686BC: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000005686C0: 361212FF 000003FC
	ds_load_b32 v58, v9                                        // 0000005686C8: D8D80000 3A000009
	v_and_b32_e32 v9, 0xff, v21                                // 0000005686D0: 36122AFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000005686D8: 30121282
	ds_load_b32 v59, v9                                        // 0000005686DC: D8D80000 3B000009
	v_lshrrev_b32_e32 v9, 6, v21                               // 0000005686E4: 32122A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005686E8: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000005686EC: 361212FF 000003FC
	ds_load_b32 v60, v9                                        // 0000005686F4: D8D80000 3C000009
	v_lshrrev_b32_e32 v9, 14, v21                              // 0000005686FC: 32122A8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000568700: 361212FF 000003FC
	ds_load_b32 v61, v9                                        // 000000568708: D8D80000 3D000009
	v_lshrrev_b32_e32 v9, 22, v21                              // 000000568710: 32122A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000568714: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000568718: 361212FF 000003FC
	ds_load_b32 v62, v9                                        // 000000568720: D8D80000 3E000009
	v_and_b32_e32 v9, 0xff, v22                                // 000000568728: 36122CFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000568730: 30121282
	ds_load_b32 v63, v9                                        // 000000568734: D8D80000 3F000009
	v_lshrrev_b32_e32 v9, 6, v22                               // 00000056873C: 32122C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000568740: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000568744: 361212FF 000003FC
	ds_load_b32 v64, v9                                        // 00000056874C: D8D80000 40000009
	v_lshrrev_b32_e32 v9, 14, v22                              // 000000568754: 32122C8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000568758: 361212FF 000003FC
	ds_load_b32 v65, v9                                        // 000000568760: D8D80000 41000009
	v_lshrrev_b32_e32 v9, 22, v22                              // 000000568768: 32122C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056876C: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000568770: 361212FF 000003FC
	ds_load_b32 v66, v9                                        // 000000568778: D8D80000 42000009
	v_and_b32_e32 v9, 0xff, v23                                // 000000568780: 36122EFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000568788: 30121282
	ds_load_b32 v67, v9                                        // 00000056878C: D8D80000 43000009
	v_lshrrev_b32_e32 v9, 6, v23                               // 000000568794: 32122E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000568798: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000056879C: 361212FF 000003FC
	ds_load_b32 v68, v9                                        // 0000005687A4: D8D80000 44000009
	v_lshrrev_b32_e32 v9, 14, v23                              // 0000005687AC: 32122E8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000005687B0: 361212FF 000003FC
	ds_load_b32 v69, v9                                        // 0000005687B8: D8D80000 45000009
	v_lshrrev_b32_e32 v9, 22, v23                              // 0000005687C0: 32122E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000005687C4: BF870141
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000005687C8: 361212FF 000003FC
	ds_load_b32 v70, v9                                        // 0000005687D0: D8D80000 46000009
	.long 0xd73c0009                                           // 0000005687D8: D73C0009
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000005687DC: 02023481
	v_dual_mov_b32 v27, v44 :: v_dual_add_nc_u32 v26, 0x400, v26// 0000005687E0: CA20012C 1B1A34FF 00000400
	.long 0xd7006a0d                                           // 0000005687EC: D7006A0D
	v_cndmask_b32_e32 v1, s6, v9, vcc_lo                       // 0000005687F0: 02021206
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005687F4: BF870001
	v_add_co_ci_u32_e64 v14, null, s7, v10, vcc_lo             // 0000005687F8: D5207C0E 01AA1407
	s_clause 0x3                                               // 000000568800: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 000000568804: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 00000056880C: DC5E0010 147C000D
	global_load_b128 v[45:48], v[13:14], off offset:32         // 000000568814: DC5E0020 2D7C000D
	global_load_b128 v[49:52], v[13:14], off offset:48         // 00000056881C: DC5E0030 317C000D
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000568824: BF890CF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000568828: CC1A4009 1A021F09
	s_waitcnt lgkmcnt(14)                                      // 000000568830: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568834: BF8700A1
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 000000568838: CC1A4009 1C26710A
	s_waitcnt lgkmcnt(13)                                      // 000000568840: BF89FCD7
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 000000568844: CC1A4009 1C26730B
	s_waitcnt lgkmcnt(12)                                      // 00000056884C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568850: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000568854: CC1A4009 1C26750C
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000056885C: BF8908B7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 000000568860: CC1A4009 1C267714
	s_waitcnt lgkmcnt(10)                                      // 000000568868: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056886C: BF8700A1
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 000000568870: CC1A4009 1C267915
	s_waitcnt lgkmcnt(9)                                       // 000000568878: BF89FC97
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 00000056887C: CC1A4009 1C267B16
	s_waitcnt lgkmcnt(8)                                       // 000000568884: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568888: BF8700A1
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 00000056888C: CC1A4009 1C267D17
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000568894: BF890477
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000568898: CC1A4009 1C267F2D
	s_waitcnt lgkmcnt(6)                                       // 0000005688A0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005688A4: BF8700A1
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000005688A8: CC1A4009 1C26812E
	s_waitcnt lgkmcnt(5)                                       // 0000005688B0: BF89FC57
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000005688B4: CC1A4009 1C26832F
	s_waitcnt lgkmcnt(4)                                       // 0000005688BC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005688C0: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000005688C4: CC1A4009 1C268530
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000005688CC: BF890037
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000005688D0: CC1A4009 1C268731
	.long 0xd7006a31                                           // 0000005688D8: D7006A31
	v_cndmask_b32_e32 v0, v13, v10, vcc_lo                     // 0000005688DC: 0200150D
	s_waitcnt lgkmcnt(2)                                       // 0000005688E0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000005688E4: BF8701C2
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000005688E8: CC1A4009 1C268932
	v_add_co_ci_u32_e64 v50, null, s11, v14, vcc_lo            // 0000005688F0: D5207C32 01AA1C0B
	.long 0xd7006a35                                           // 0000005688F8: D7006A35
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 0000005688FC: 0200090D
	s_waitcnt lgkmcnt(1)                                       // 000000568900: BF89FC17
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 000000568904: CC1A4009 1C268B33
	v_add_co_ci_u32_e64 v54, null, s5, v14, vcc_lo             // 00000056890C: D5207C36 01AA1C05
	.long 0xd7006a0d                                           // 000000568914: D7006A0D
	v_cndmask_b32_e32 v0, v13, v17, vcc_lo                     // 000000568918: 0200230D
	s_waitcnt lgkmcnt(0)                                       // 00000056891C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000568920: BF870123
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 000000568924: CC1A4009 1C268D34
	v_add_co_ci_u32_e64 v14, null, s15, v14, vcc_lo            // 00000056892C: D5207C0E 01AA1C0F
	v_fmac_f32_e32 v37, v55, v9                                // 000000568934: 564A1337
	s_clause 0x3                                               // 000000568938: BF850003
	global_load_b128 v[9:12], v[49:50], off                    // 00000056893C: DC5E0000 097C0031
	global_load_b128 v[20:23], v[49:50], off offset:16         // 000000568944: DC5E0010 147C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 00000056894C: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 000000568954: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 00000056895C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000568960: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568968: BF870091
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 00000056896C: CC1A4009 1C26710A
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 000000568974: CC1A4009 1C26730B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056897C: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000568980: CC1A4009 1C26750C
	s_waitcnt vmcnt(2)                                         // 000000568988: BF890BF7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 00000056898C: CC1A4009 1C267714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568994: BF870091
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 000000568998: CC1A4009 1C267915
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 0000005689A0: CC1A4009 1C267B16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005689A8: BF8700A1
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 0000005689AC: CC1A4009 1C267D17
	s_waitcnt vmcnt(1)                                         // 0000005689B4: BF8907F7
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 0000005689B8: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005689C0: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000005689C4: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000005689CC: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005689D4: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000005689D8: CC1A4009 1C268530
	s_waitcnt vmcnt(0)                                         // 0000005689E0: BF8903F7
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000005689E4: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005689EC: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000005689F0: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000005689F8: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568A00: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 000000568A04: CC1A4009 1C268D34
	v_fmac_f32_e32 v41, v55, v9                                // 000000568A0C: 56521337
	s_clause 0x3                                               // 000000568A10: BF850003
	global_load_b128 v[9:12], v[53:54], off                    // 000000568A14: DC5E0000 097C0035
	global_load_b128 v[20:23], v[53:54], off offset:16         // 000000568A1C: DC5E0010 147C0035
	global_load_b128 v[45:48], v[53:54], off offset:32         // 000000568A24: DC5E0020 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:48         // 000000568A2C: DC5E0030 317C0035
	s_waitcnt vmcnt(3)                                         // 000000568A34: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000568A38: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568A40: BF870091
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 000000568A44: CC1A4009 1C26710A
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 000000568A4C: CC1A4009 1C26730B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568A54: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000568A58: CC1A4009 1C26750C
	s_waitcnt vmcnt(2)                                         // 000000568A60: BF890BF7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 000000568A64: CC1A4009 1C267714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568A6C: BF870091
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 000000568A70: CC1A4009 1C267915
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 000000568A78: CC1A4009 1C267B16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568A80: BF8700A1
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 000000568A84: CC1A4009 1C267D17
	s_waitcnt vmcnt(1)                                         // 000000568A8C: BF8907F7
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000568A90: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568A98: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000568A9C: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 000000568AA4: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568AAC: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000568AB0: CC1A4009 1C268530
	s_waitcnt vmcnt(0)                                         // 000000568AB8: BF8903F7
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 000000568ABC: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568AC4: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 000000568AC8: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 000000568AD0: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568AD8: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 000000568ADC: CC1A4009 1C268D34
	v_fmac_f32_e32 v40, v55, v9                                // 000000568AE4: 56501337
	s_clause 0x3                                               // 000000568AE8: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 000000568AEC: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 000000568AF4: DC5E0010 147C000D
	global_load_b128 v[45:48], v[13:14], off offset:32         // 000000568AFC: DC5E0020 2D7C000D
	global_load_b128 v[49:52], v[13:14], off offset:48         // 000000568B04: DC5E0030 317C000D
	s_waitcnt vmcnt(3)                                         // 000000568B0C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000568B10: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568B18: BF870091
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 000000568B1C: CC1A4009 1C26710A
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 000000568B24: CC1A4009 1C26730B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568B2C: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000568B30: CC1A4009 1C26750C
	s_waitcnt vmcnt(2)                                         // 000000568B38: BF890BF7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 000000568B3C: CC1A4009 1C267714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568B44: BF870091
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 000000568B48: CC1A4009 1C267915
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 000000568B50: CC1A4009 1C267B16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568B58: BF8700A1
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 000000568B5C: CC1A4009 1C267D17
	s_waitcnt vmcnt(1)                                         // 000000568B64: BF8907F7
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000568B68: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568B70: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000568B74: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 000000568B7C: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568B84: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000568B88: CC1A4009 1C268530
	s_waitcnt vmcnt(0)                                         // 000000568B90: BF8903F7
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 000000568B94: CC1A4009 1C268731
	.long 0xd7006a31                                           // 000000568B9C: D7006A31
	v_cndmask_b32_e32 v0, v53, v4, vcc_lo                      // 000000568BA0: 02000935
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000568BA4: BF8701B2
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 000000568BA8: CC1A4009 1C268932
	v_add_co_ci_u32_e64 v50, null, s5, v54, vcc_lo             // 000000568BB0: D5207C32 01AA6C05
	.long 0xd7006a0d                                           // 000000568BB8: D7006A0D
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 000000568BBC: 0200090D
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 000000568BC0: CC1A4009 1C268B33
	v_add_co_ci_u32_e64 v14, null, s5, v14, vcc_lo             // 000000568BC8: D5207C0E 01AA1C05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568BD0: BF870092
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 000000568BD4: CC1A4009 1C268D34
	v_fmac_f32_e32 v39, v55, v9                                // 000000568BDC: 564E1337
	s_clause 0x3                                               // 000000568BE0: BF850003
	global_load_b128 v[9:12], v[49:50], off                    // 000000568BE4: DC5E0000 097C0031
	global_load_b128 v[20:23], v[49:50], off offset:16         // 000000568BEC: DC5E0010 147C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 000000568BF4: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 000000568BFC: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 000000568C04: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000568C08: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568C10: BF870091
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 000000568C14: CC1A4009 1C26710A
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 000000568C1C: CC1A4009 1C26730B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568C24: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000568C28: CC1A4009 1C26750C
	s_waitcnt vmcnt(2)                                         // 000000568C30: BF890BF7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 000000568C34: CC1A4009 1C267714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568C3C: BF870091
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 000000568C40: CC1A4009 1C267915
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 000000568C48: CC1A4009 1C267B16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568C50: BF8700A1
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 000000568C54: CC1A4009 1C267D17
	s_waitcnt vmcnt(1)                                         // 000000568C5C: BF8907F7
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000568C60: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568C68: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000568C6C: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 000000568C74: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568C7C: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000568C80: CC1A4009 1C268530
	s_waitcnt vmcnt(0)                                         // 000000568C88: BF8903F7
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 000000568C8C: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568C94: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 000000568C98: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 000000568CA0: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568CA8: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 000000568CAC: CC1A4009 1C268D34
	v_fmac_f32_e32 v38, v55, v9                                // 000000568CB4: 564C1337
	s_clause 0x3                                               // 000000568CB8: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 000000568CBC: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 000000568CC4: DC5E0010 147C000D
	global_load_b128 v[45:48], v[13:14], off offset:32         // 000000568CCC: DC5E0020 2D7C000D
	global_load_b128 v[49:52], v[13:14], off offset:48         // 000000568CD4: DC5E0030 317C000D
	s_waitcnt vmcnt(3)                                         // 000000568CDC: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000568CE0: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568CE8: BF870091
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 000000568CEC: CC1A4009 1C26710A
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 000000568CF4: CC1A4009 1C26730B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568CFC: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000568D00: CC1A4009 1C26750C
	s_waitcnt vmcnt(2)                                         // 000000568D08: BF890BF7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 000000568D0C: CC1A4009 1C267714
	v_mov_b32_e32 v20, v16                                     // 000000568D14: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000568D18: BF870122
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 000000568D1C: CC1A4009 1C267915
	v_mov_b32_e32 v21, v17                                     // 000000568D24: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 000000568D28: CC1A4009 1C267B16
	v_mov_b32_e32 v22, v18                                     // 000000568D30: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000568D34: BF870132
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 000000568D38: CC1A4009 1C267D17
	v_mov_b32_e32 v23, v19                                     // 000000568D40: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 000000568D44: BF8907F7
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000568D48: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568D50: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000568D54: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 000000568D5C: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568D64: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000568D68: CC1A4009 1C268530
	s_waitcnt vmcnt(0)                                         // 000000568D70: BF8903F7
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 000000568D74: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568D7C: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 000000568D80: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 000000568D88: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000568D90: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 000000568D94: CC1A4009 1C268D34
	v_dual_fmac_f32 v34, v55, v9 :: v_dual_mov_b32 v15, v8     // 000000568D9C: C8101337 220E0108
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 000000568DA4: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 000000568DAC: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 000000568DB4: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 000000568DBC: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000568DC0: 917E107E
	s_cbranch_execz 35                                         // 000000568DC4: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xd54>
	s_waitcnt vmcnt(0)                                         // 000000568DC8: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 000000568DCC: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 000000568DD4: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 000000568DDC: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 000000568DE0: BF870003
	.long 0xd4460001                                           // 000000568DE4: D4460001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000568DE8: 0202411F
	s_mov_b32 s18, exec_lo                                     // 000000568DEC: BE92007E
	.long 0xd4c1007e                                           // 000000568DF0: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000568DF4: 0202411F
	s_cbranch_execz 65031                                      // 000000568DF8: BFA5FE07 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	v_ashrrev_i32_e32 v2, 31, v42                              // 000000568DFC: 3404549F
	.long 0xd7006a01                                           // 000000568E00: D7006A01
	v_cndmask_b32_e32 v1, v25, v42, vcc_lo                     // 000000568E04: 02025519
	v_mov_b32_e32 v44, v27                                     // 000000568E08: 7E58031B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000568E0C: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 000000568E10: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 000000568E18: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 000000568E1C: DC5E0000 107C0001
	s_cbranch_vccnz 65020                                      // 000000568E24: BFA4FDFC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	v_ashrrev_i32_e32 v2, 31, v43                              // 000000568E28: 3404569F
	.long 0xd7006a01                                           // 000000568E2C: D7006A01
	v_cndmask_b32_e32 v1, v24, v43, vcc_lo                     // 000000568E30: 02025718
	s_delay_alu instid0(VALU_DEP_1)                            // 000000568E34: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000568E38: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000568E40: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000568E48: BF8903F7
	v_cvt_f32_f16_e32 v44, v1                                  // 000000568E4C: 7E581701
	s_branch 65009                                             // 000000568E50: BFA0FDF1 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000568E54: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000568E58: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 000000568E5C: 8C7E0E7E
	.long 0xd71f0001                                           // 000000568E60: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000568E64: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000568E68: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000568E6C: 3A040290
	v_xor_b32_e32 v8, 8, v1                                    // 000000568E70: 3A100288
	v_xor_b32_e32 v14, 4, v1                                   // 000000568E74: 3A1C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000568E78: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000568E7C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000568E80: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000568E84: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000568E88: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000568E8C: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 000000568E90: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 000000568E98: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 000000568E9C: 06060725
	ds_bpermute_b32 v7, v2, v38                                // 000000568EA0: DACC0000 07002602
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 000000568EA8: 02101101
	ds_bpermute_b32 v5, v2, v40                                // 000000568EAC: DACC0000 05002802
	ds_bpermute_b32 v6, v2, v39                                // 000000568EB4: DACC0000 06002702
	ds_bpermute_b32 v4, v2, v41                                // 000000568EBC: DACC0000 04002902
	ds_bpermute_b32 v2, v2, v34                                // 000000568EC4: DACC0000 02002202
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 000000568ECC: 7C981CA0
	s_waitcnt lgkmcnt(4)                                       // 000000568ED0: BF89FC47
	v_dual_add_f32 v7, v38, v7 :: v_dual_lshlrev_b32 v8, 2, v8 // 000000568ED4: C9220F26 07081082
	s_waitcnt lgkmcnt(3)                                       // 000000568EDC: BF89FC37
	v_add_f32_e32 v5, v40, v5                                  // 000000568EE0: 060A0B28
	ds_bpermute_b32 v9, v8, v3                                 // 000000568EE4: DACC0000 09000308
	s_waitcnt lgkmcnt(0)                                       // 000000568EEC: BF89FC07
	v_add_f32_e32 v3, v3, v9                                   // 000000568EF0: 06061303
	ds_bpermute_b32 v11, v8, v5                                // 000000568EF4: DACC0000 0B000508
	ds_bpermute_b32 v13, v8, v7                                // 000000568EFC: DACC0000 0D000708
	v_add_f32_e32 v6, v39, v6                                  // 000000568F04: 060C0D27
	v_add_f32_e32 v4, v41, v4                                  // 000000568F08: 06080929
	s_waitcnt lgkmcnt(1)                                       // 000000568F0C: BF89FC17
	v_dual_add_f32 v2, v34, v2 :: v_dual_add_f32 v5, v5, v11   // 000000568F10: C9080522 02041705
	ds_bpermute_b32 v12, v8, v6                                // 000000568F18: DACC0000 0C000608
	s_waitcnt lgkmcnt(1)                                       // 000000568F20: BF89FC17
	v_dual_add_f32 v7, v7, v13 :: v_dual_cndmask_b32 v14, v1, v14// 000000568F24: C9121B07 070E1D01
	ds_bpermute_b32 v10, v8, v4                                // 000000568F2C: DACC0000 0A000408
	ds_bpermute_b32 v8, v8, v2                                 // 000000568F34: DACC0000 08000208
	v_lshlrev_b32_e32 v14, 2, v14                              // 000000568F3C: 301C1C82
	s_waitcnt lgkmcnt(2)                                       // 000000568F40: BF89FC27
	v_add_f32_e32 v6, v6, v12                                  // 000000568F44: 060C1906
	ds_bpermute_b32 v12, v14, v7                               // 000000568F48: DACC0000 0C00070E
	s_waitcnt lgkmcnt(1)                                       // 000000568F50: BF89FC17
	v_add_f32_e32 v2, v2, v8                                   // 000000568F54: 06041102
	ds_bpermute_b32 v8, v14, v3                                // 000000568F58: DACC0000 0800030E
	ds_bpermute_b32 v13, v14, v2                               // 000000568F60: DACC0000 0D00020E
	s_waitcnt lgkmcnt(2)                                       // 000000568F68: BF89FC27
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v4, v4, v10   // 000000568F6C: C9081907 07041504
	ds_bpermute_b32 v10, v14, v5                               // 000000568F74: DACC0000 0A00050E
	s_waitcnt lgkmcnt(2)                                       // 000000568F7C: BF89FC27
	v_add_f32_e32 v3, v3, v8                                   // 000000568F80: 06061103
	ds_bpermute_b32 v9, v14, v4                                // 000000568F84: DACC0000 0900040E
	s_waitcnt lgkmcnt(1)                                       // 000000568F8C: BF89FC17
	v_dual_add_f32 v8, v2, v13 :: v_dual_add_f32 v5, v5, v10   // 000000568F90: C9081B02 08041505
	ds_bpermute_b32 v11, v14, v6                               // 000000568F98: DACC0000 0B00060E
	v_xor_b32_e32 v14, 2, v1                                   // 000000568FA0: 3A1C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000568FA4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 000000568FA8: 7C981CA0
	v_cndmask_b32_e32 v14, v1, v14, vcc_lo                     // 000000568FAC: 021C1D01
	v_lshlrev_b32_e32 v14, 2, v14                              // 000000568FB0: 301C1C82
	s_waitcnt lgkmcnt(0)                                       // 000000568FB4: BF89FC07
	v_add_f32_e32 v6, v6, v11                                  // 000000568FB8: 060C1706
	ds_bpermute_b32 v2, v14, v3                                // 000000568FBC: DACC0000 0200030E
	v_add_f32_e32 v4, v4, v9                                   // 000000568FC4: 06081304
	ds_bpermute_b32 v10, v14, v5                               // 000000568FC8: DACC0000 0A00050E
	ds_bpermute_b32 v12, v14, v7                               // 000000568FD0: DACC0000 0C00070E
	ds_bpermute_b32 v11, v14, v6                               // 000000568FD8: DACC0000 0B00060E
	ds_bpermute_b32 v13, v14, v8                               // 000000568FE0: DACC0000 0D00080E
	ds_bpermute_b32 v9, v14, v4                                // 000000568FE8: DACC0000 0900040E
	v_xor_b32_e32 v14, 1, v1                                   // 000000568FF0: 3A1C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000568FF4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 000000568FF8: 7C981CA0
	v_cndmask_b32_e32 v1, v1, v14, vcc_lo                      // 000000568FFC: 02021D01
	s_waitcnt lgkmcnt(5)                                       // 000000569000: BF89FC57
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v14, 2, v1 // 000000569004: C9220503 010E0282
	s_waitcnt lgkmcnt(0)                                       // 00000056900C: BF89FC07
	v_dual_add_f32 v3, v7, v12 :: v_dual_add_f32 v2, v4, v9    // 000000569010: C9081907 03021304
	v_dual_add_f32 v4, v5, v10 :: v_dual_add_f32 v5, v6, v11   // 000000569018: C9081505 04041706
	v_add_f32_e32 v9, v8, v13                                  // 000000569020: 06121B08
	ds_bpermute_b32 v6, v14, v1                                // 000000569024: DACC0000 0600010E
	ds_bpermute_b32 v7, v14, v2                                // 00000056902C: DACC0000 0700020E
	ds_bpermute_b32 v10, v14, v4                               // 000000569034: DACC0000 0A00040E
	ds_bpermute_b32 v11, v14, v5                               // 00000056903C: DACC0000 0B00050E
	ds_bpermute_b32 v8, v14, v3                                // 000000569044: DACC0000 0800030E
	ds_bpermute_b32 v12, v14, v9                               // 00000056904C: DACC0000 0C00090E
	v_cmpx_eq_u32_e32 0, v30                                   // 000000569054: 7D943C80
	s_cbranch_execz 16                                         // 000000569058: BFA50010 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xf9c>
	.long 0xd72c000d                                           // 00000056905C: D72C000D
	v_cndmask_b32_e32 v0, v28, v176, vcc_lo                    // 000000569060: 0201611C
	s_waitcnt lgkmcnt(0)                                       // 000000569064: BF89FC07
	v_dual_add_f32 v9, v9, v12 :: v_dual_add_f32 v4, v4, v10   // 000000569068: C9081909 09041504
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v8, v3, v8    // 000000569070: C9081705 05081103
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v1, v1, v6     // 000000569078: C9080F02 02000D01
	s_delay_alu instid0(VALU_DEP_4)                            // 000000569080: BF870004
	v_mad_u32_u24 v6, v29, 24, v13                             // 000000569084: D60B0006 0435311D
	ds_store_2addr_b64 v6, v[1:2], v[4:5] offset0:128 offset1:129// 00000056908C: D9388180 00040106
	ds_store_b64 v6, v[8:9] offset:1040                        // 000000569094: D9340410 00000806
	s_or_b32 exec_lo, exec_lo, s0                              // 00000056909C: 8C7E007E
	.long 0xd7050001                                           // 0000005690A0: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 0000005690A4: 020200FF 000000AB
	.long 0x7f063880                                           // 0000005690AC: 7F063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000005690B0: BF890007
	s_barrier                                                  // 0000005690B4: BFBD0000
	buffer_gl0_inv                                             // 0000005690B8: E0AC0000 00000000
	.long 0xd7390003                                           // 0000005690C0: D7390003
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000005690C4: 0202028A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005690C8: BF870091
	.long 0xd7000001                                           // 0000005690CC: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 0000005690D0: 02020602
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 0000005690D4: D5207C02 00010003
	.long 0xd44c0000                                           // 0000005690DC: D44C0000
	v_cndmask_b32_e32 v1, 24, v0, vcc_lo                       // 0000005690E0: 02020098
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000005690E4: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000005690E8: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 0000005690EC: 8B006A00
	s_and_saveexec_b32 s1, s0                                  // 0000005690F0: BE812000
	s_cbranch_execz 45                                         // 0000005690F4: BFA5002D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x10ac>
	.long 0xd7054000                                           // 0000005690F8: D7054000
	v_cndmask_b32_e32 v0, v3, v134, vcc_lo                     // 0000005690FC: 02010D03
	v_mul_u32_u24_e32 v3, 48, v3                               // 000000569100: 160606B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569104: BF870092
	.long 0xd7041000                                           // 000000569108: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 00000056910C: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 000000569110: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569118: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 00000056911C: D6460003 040D0500
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000569124: 4A0606FF 00000400
	ds_load_2addr_b32 v[6:7], v3 offset1:6                     // 00000056912C: D8DC0600 06000003
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000569134: D6FE7C03 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056913C: BF870091
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000569140: D6FE7C04 0412000D
	.long 0xd73c0003                                           // 000000569148: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000056914C: 02020681
	s_waitcnt lgkmcnt(0)                                       // 000000569150: BF89FC07
	v_add_f32_e32 v0, 0, v6                                    // 000000569154: 06000C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000569158: BF870112
	.long 0xd7006a03                                           // 00000056915C: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000569160: 02020608
	v_add_f32_e32 v5, v0, v7                                   // 000000569164: 060A0F00
	.long 0xd73c0000                                           // 000000569168: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000056916C: 02020281
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000569170: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000569178: BF870193
	v_bfe_u32 v2, v5, 16, 1                                    // 00000056917C: D6100002 02052105
	.long 0xd7006a00                                           // 000000569184: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000569188: 02020103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000056918C: BF870191
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000569190: D5207C01 01AA0304
	v_add3_u32 v2, v5, v2, 0x7fff                              // 000000569198: D6550002 03FE0505 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000005691A4: DC960000 007C0200
	s_endpgm                                                   // 0000005691AC: BFB00000
		...

