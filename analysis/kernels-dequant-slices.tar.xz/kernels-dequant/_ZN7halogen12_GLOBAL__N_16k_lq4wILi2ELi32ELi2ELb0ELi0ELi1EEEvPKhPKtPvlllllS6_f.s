000000000054f200 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000054F200: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000054F208: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000054F20C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 00000054F210: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 00000054F214: 3602008F
	v_lshrrev_b32_e32 v21, 6, v0                               // 00000054F218: 322A0086
	v_bfe_u32 v22, v0, 5, 1                                    // 00000054F21C: D6100016 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 00000054F224: 360404BC
	v_and_b32_e32 v23, 31, v0                                  // 00000054F228: 362E009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000054F22C: 30020282
	.long 0x7f0a3880                                           // 00000054F230: 7F0A3880
	s_waitcnt lgkmcnt(0)                                       // 00000054F234: BF89FC07
	s_clause 0x1                                               // 00000054F238: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000054F23C: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 00000054F244: DC520000 04040002
	s_add_u32 s0, s4, s16                                      // 00000054F24C: 80001004
	s_addc_u32 s1, s5, s17                                     // 00000054F250: 82011105
	s_ashr_i32 s16, s11, 31                                    // 00000054F254: 86109F0B
	v_mov_b32_e32 v2, s3                                       // 00000054F258: 7E040203
	s_lshr_b32 s16, s16, 27                                    // 00000054F25C: 85109B10
	v_or_b32_e32 v1, s2, v21                                   // 00000054F260: 38022A02
	s_add_u32 s16, s10, s16                                    // 00000054F264: 8010100A
	s_addc_u32 s17, s11, 0                                     // 00000054F268: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054F26C: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 00000054F270: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000054F274: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 00000054F278: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000054F27C: BF870499
	s_lshr_b32 s20, s17, 31                                    // 00000054F280: 85149F11
	s_add_i32 s17, s17, s20                                    // 00000054F284: 81111411
	v_cndmask_b32_e32 v9, 0, v1, vcc_lo                        // 00000054F288: 02120280
	s_ashr_i32 s17, s17, 1                                     // 00000054F28C: 86118111
	v_cndmask_b32_e64 v10, 0, s3, vcc_lo                       // 00000054F290: D501000A 01A80680
	.long 0xd72c0002                                           // 00000054F298: D72C0002
	v_cndmask_b32_e32 v1, s17, v22, vcc_lo                     // 00000054F29C: 02022C11
	s_cmpk_lt_i32 s16, 0x201                                   // 00000054F2A0: B3900201
	.long 0xd72c0007                                           // 00000054F2A4: D72C0007
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 00000054F2A8: 02021213
	v_mad_u64_u32 v[17:18], null, s18, v9, s[0:1]              // 00000054F2AC: D6FE7C11 00021212
	s_cselect_b32 s0, -1, 0                                    // 00000054F2B4: 980080C1
	s_cmpk_gt_i32 s16, 0x200                                   // 00000054F2B8: B2900200
	v_lshlrev_b32_e32 v1, 2, v0                                // 00000054F2BC: 30020082
	v_add_nc_u32_e32 v11, s17, v2                              // 00000054F2C0: 4A160411
	v_add_nc_u32_e32 v24, v2, v23                              // 00000054F2C4: 4A302F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000054F2C8: BF8704A2
	v_min_i32_e32 v25, s16, v11                                // 00000054F2CC: 22321610
	s_cselect_b32 s16, -1, 0                                   // 00000054F2D0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 00000054F2D4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000054F2D8: BF870151
	.long 0xd4410001                                           // 00000054F2DC: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 00000054F2E0: 02023318
	s_waitcnt vmcnt(1)                                         // 00000054F2E4: BF8907F7
	v_bfe_u32 v6, v3, 16, 1                                    // 00000054F2E8: D6100006 02052103
	s_waitcnt vmcnt(0)                                         // 00000054F2F0: BF8903F7
	v_bfe_u32 v8, v4, 16, 1                                    // 00000054F2F4: D6100008 02052104
	v_add3_u32 v3, v3, v6, 0x7fff                              // 00000054F2FC: D6550003 03FE0D03 00007FFF
	.long 0xd72c0006                                           // 00000054F308: D72C0006
	v_cndmask_b32_e32 v1, s18, v10, vcc_lo                     // 00000054F30C: 02021412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000054F310: BF870193
	v_add3_u32 v4, v4, v8, 0x7fff                              // 00000054F314: D6550004 03FE1104 00007FFF
	.long 0x7e0a3983                                           // 00000054F320: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054F324: BF870113
	v_add3_u32 v26, v7, v18, v6                                // 00000054F328: D655001A 041A2507
	v_and_or_b32 v2, 0xffff0000, v4, v5                        // 00000054F330: D6570002 041608FF FFFF0000
	ds_store_b32 v1, v2                                        // 00000054F33C: D8340000 00000201
	s_waitcnt lgkmcnt(0)                                       // 00000054F344: BF89FC07
	s_barrier                                                  // 00000054F348: BFBD0000
	buffer_gl0_inv                                             // 00000054F34C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 00000054F354: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 00000054F358: CA100080 02000080
	s_and_saveexec_b32 s17, s1                                 // 00000054F360: BE912001
	s_cbranch_execz 11                                         // 00000054F364: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v1, 1, v24                               // 00000054F368: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054F36C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 00000054F370: 3408029F
	.long 0xd7006a03                                           // 00000054F374: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 00000054F378: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 00000054F37C: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 00000054F384: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 00000054F38C: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 00000054F390: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 00000054F394: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v24                               // 00000054F398: 4A0630A0
	s_mov_b32 s1, exec_lo                                      // 00000054F39C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054F3A0: BF870001
	.long 0xd4c1007e                                           // 00000054F3A4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 00000054F3A8: 02023303
	s_cbranch_execz 11                                         // 00000054F3AC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v2, 1, v3                                // 00000054F3B0: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054F3B4: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000054F3B8: 3406049F
	.long 0xd7006a02                                           // 00000054F3BC: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 00000054F3C0: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 00000054F3C4: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 00000054F3CC: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000054F3D4: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 00000054F3D8: 7E041702
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054F3DC: 8C7E017E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 00000054F3E0: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 00000054F3E8: 7E060280
	s_mov_b32 s1, exec_lo                                      // 00000054F3EC: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054F3F0: BF870002
	.long 0xd4c1007e                                           // 00000054F3F4: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 00000054F3F8: 02023305
	s_cbranch_execz 11                                         // 00000054F3FC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v5                                // 00000054F400: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054F404: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 00000054F408: 340C069F
	.long 0xd7006a05                                           // 00000054F40C: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 00000054F410: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 00000054F414: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 00000054F41C: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 00000054F424: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 00000054F428: 7E061703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054F42C: 8C7E017E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 00000054F430: 4A0A30FF 00000060
	s_mov_b32 s1, exec_lo                                      // 00000054F438: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054F43C: BF870001
	.long 0xd4c1007e                                           // 00000054F440: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 00000054F444: 02023305
	s_cbranch_execz 11                                         // 00000054F448: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v4, 1, v5                                // 00000054F44C: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054F450: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 00000054F454: 340A089F
	.long 0xd7006a04                                           // 00000054F458: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 00000054F45C: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 00000054F460: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 00000054F468: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 00000054F470: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 00000054F474: 7E081704
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054F478: 8C7E017E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 00000054F47C: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 00000054F488: 7E0A0280
	s_mov_b32 s1, exec_lo                                      // 00000054F48C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054F490: BF870002
	.long 0xd4c1007e                                           // 00000054F494: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 00000054F498: 02023307
	s_cbranch_execz 11                                         // 00000054F49C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v5, 1, v7                                // 00000054F4A0: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054F4A4: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 00000054F4A8: 34100A9F
	.long 0xd7006a07                                           // 00000054F4AC: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 00000054F4B0: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 00000054F4B4: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 00000054F4BC: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 00000054F4C4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 00000054F4C8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054F4CC: 8C7E017E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 00000054F4D0: 4A0E30FF 000000A0
	s_mov_b32 s1, exec_lo                                      // 00000054F4D8: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054F4DC: BF870001
	.long 0xd4c1007e                                           // 00000054F4E0: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 00000054F4E4: 02023307
	s_cbranch_execz 11                                         // 00000054F4E8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v6, 1, v7                                // 00000054F4EC: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054F4F0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 00000054F4F4: 340E0C9F
	.long 0xd7006a06                                           // 00000054F4F8: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 00000054F4FC: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 00000054F500: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 00000054F508: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000054F510: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 00000054F514: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054F518: 8C7E017E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0xc0, v24   // 00000054F51C: CA200080 080A30FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 00000054F528: 7E0E0280
	s_mov_b32 s1, exec_lo                                      // 00000054F52C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054F530: BF870002
	.long 0xd4c1007e                                           // 00000054F534: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 00000054F538: 0202330B
	s_cbranch_execz 11                                         // 00000054F53C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v7, 1, v11                               // 00000054F540: 300E1681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054F544: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v7                              // 00000054F548: 34180E9F
	.long 0xd7006a0b                                           // 00000054F54C: D7006A0B
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 00000054F550: 02020F11
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 00000054F554: D5207C0C 01AA191A
	global_load_d16_b16 v7, v[11:12], off                      // 00000054F55C: DC820000 077C000B
	s_waitcnt vmcnt(0)                                         // 00000054F564: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 00000054F568: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054F56C: 8C7E017E
	v_add_nc_u32_e32 v11, 0xe0, v24                            // 00000054F570: 4A1630FF 000000E0
	s_mov_b32 s1, exec_lo                                      // 00000054F578: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054F57C: BF870001
	.long 0xd4c1007e                                           // 00000054F580: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 00000054F584: 0202330B
	s_cbranch_execz 11                                         // 00000054F588: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v8, 1, v11                               // 00000054F58C: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054F590: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 00000054F594: 3418109F
	.long 0xd7006a0b                                           // 00000054F598: D7006A0B
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 00000054F59C: 02021111
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 00000054F5A0: D5207C0C 01AA191A
	global_load_d16_b16 v8, v[11:12], off                      // 00000054F5A8: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 00000054F5B0: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 00000054F5B4: 7E101708
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054F5B8: 8C7E017E
	s_branch 9                                                 // 00000054F5BC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v1, 0                                        // 00000054F5C0: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054F5C4: BF870001
	v_mov_b32_e32 v2, v1                                       // 00000054F5C8: 7E040301
	v_mov_b32_e32 v3, v1                                       // 00000054F5CC: 7E060301
	v_mov_b32_e32 v4, v1                                       // 00000054F5D0: 7E080301
	v_mov_b32_e32 v5, v1                                       // 00000054F5D4: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 00000054F5D8: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000054F5DC: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 00000054F5E0: 7E100301
	s_add_u32 s4, s4, s14                                      // 00000054F5E4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 00000054F5E8: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 00000054F5EC: 85019F0B
	v_mov_b32_e32 v27, 0                                       // 00000054F5F0: 7E360280
	s_add_u32 s14, s10, s1                                     // 00000054F5F4: 800E010A
	s_addc_u32 s15, s11, 0                                     // 00000054F5F8: 820F800B
	.long 0xd4410001                                           // 00000054F5FC: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 00000054F600: 02023318
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000054F604: 868E810E
	v_cndmask_b32_e64 v28, 0, 1, s16                           // 00000054F608: D501001C 00410280
	v_mad_u64_u32 v[18:19], null, v9, s14, s[4:5]              // 00000054F610: D6FE7C12 00101D09
	.long 0xd72c000c                                           // 00000054F618: D72C000C
	v_cndmask_b32_e32 v0, v9, v15, vcc_lo                      // 00000054F61C: 02001F09
	.long 0xd72c000d                                           // 00000054F620: D72C000D
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 00000054F624: 02001D0A
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v10, 0              // 00000054F628: CA100080 090A0080
	v_mov_b32_e32 v31, 0                                       // 00000054F630: 7E3E0280
	v_mov_b32_e32 v11, 0                                       // 00000054F634: 7E160280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000054F638: BF870004
	v_add3_u32 v29, v13, v19, v12                              // 00000054F63C: D655001D 0432270D
	v_mov_b32_e32 v12, 0                                       // 00000054F644: 7E180280
	s_and_saveexec_b32 s4, s1                                  // 00000054F648: BE842001
	s_cbranch_execz 22                                         // 00000054F64C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v9, 4, v24                               // 00000054F650: 30123084
	v_mov_b32_e32 v31, 0                                       // 00000054F654: 7E3E0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054F658: BF8700A2
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000054F65C: 3414129F
	.long 0xd7006a09                                           // 00000054F660: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 00000054F664: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 00000054F668: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 00000054F670: 916A107E
	global_load_b128 v[9:12], v[9:10], off                     // 00000054F674: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 00000054F67C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v13, 1, v24                              // 00000054F680: 301A3081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054F684: BF870091
	.long 0xd7006a0d                                           // 00000054F688: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 00000054F68C: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v26, vcc_lo              // 00000054F690: D5207C0E 01AA3480
	global_load_d16_b16 v13, v[13:14], off                     // 00000054F698: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 00000054F6A0: BF8903F7
	v_cvt_f32_f16_e32 v31, v13                                 // 00000054F6A4: 7E3E170D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000054F6A8: 8C7E047E
	v_mov_b32_e32 v30, 0                                       // 00000054F6AC: 7E3C0280
	s_and_saveexec_b32 s14, s1                                 // 00000054F6B0: BE8E2001
	s_cbranch_execz 290                                        // 00000054F6B4: BFA50122 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x940>
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v13, 32, v24    // 00000054F6B8: CA200080 1E0C30A0
	v_dual_mov_b32 v34, v31 :: v_dual_lshlrev_b32 v19, 5, v24  // 00000054F6C0: CA22011F 22123085
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054F6C8: BF870002
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v32, 4, v13    // 00000054F6CC: CA220080 1B201A84
	v_lshlrev_b32_e32 v33, 1, v13                              // 00000054F6D4: 30421A81
	s_mov_b32 s15, 0                                           // 00000054F6D8: BE8F0080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000054F6DC: 8484810A
	s_branch 243                                               // 00000054F6E0: BFA000F3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x8b0>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000054F6E4: 8C7E0A7E
	v_ashrrev_i32_e32 v20, 31, v19                             // 00000054F6E8: 3428269F
	v_lshrrev_b32_e32 v67, 6, v9                               // 00000054F6EC: 32861286
	v_lshrrev_b32_e32 v68, 14, v9                              // 00000054F6F0: 3288128E
	v_and_b32_e32 v69, 0xff, v10                               // 00000054F6F4: 368A14FF 000000FF
	v_lshrrev_b32_e32 v70, 6, v10                              // 00000054F6FC: 328C1486
	.long 0xd73c0023                                           // 00000054F700: D73C0023
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 00000054F704: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 00000054F708: 362812FF 000000FF
	v_and_b32_e32 v67, 0x3fc, v67                              // 00000054F710: 368686FF 000003FC
	v_and_b32_e32 v68, 0x3fc, v68                              // 00000054F718: 368888FF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 00000054F720: 32121296
	v_lshrrev_b32_e32 v71, 14, v10                             // 00000054F724: 328E148E
	.long 0xd7006a3b                                           // 00000054F728: D7006A3B
	v_cndmask_b32_e32 v1, s6, v35, vcc_lo                      // 00000054F72C: 02024606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054F730: BF8701A1
	v_add_co_ci_u32_e64 v60, null, s7, v36, vcc_lo             // 00000054F734: D5207C3C 01AA4807
	v_lshlrev_b32_e32 v20, 2, v20                              // 00000054F73C: 30282882
	.long 0xd7006a3f                                           // 00000054F740: D7006A3F
	v_cndmask_b32_e32 v0, v59, v4, vcc_lo                      // 00000054F744: 0200093B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054F748: BF870001
	v_add_co_ci_u32_e64 v64, null, s5, v60, vcc_lo             // 00000054F74C: D5207C40 01AA7805
	ds_load_b32 v20, v20                                       // 00000054F754: D8D80000 14000014
	ds_load_b32 v67, v67                                       // 00000054F75C: D8D80000 43000043
	ds_load_b32 v68, v68                                       // 00000054F764: D8D80000 44000044
	s_clause 0x7                                               // 00000054F76C: BF850007
	global_load_b128 v[35:38], v[59:60], off                   // 00000054F770: DC5E0000 237C003B
	global_load_b128 v[39:42], v[63:64], off                   // 00000054F778: DC5E0000 277C003F
	global_load_b128 v[43:46], v[59:60], off offset:16         // 00000054F780: DC5E0010 2B7C003B
	global_load_b128 v[47:50], v[63:64], off offset:16         // 00000054F788: DC5E0010 2F7C003F
	global_load_b128 v[51:54], v[59:60], off offset:32         // 00000054F790: DC5E0020 337C003B
	global_load_b128 v[55:58], v[63:64], off offset:32         // 00000054F798: DC5E0020 377C003F
	global_load_b128 v[59:62], v[59:60], off offset:48         // 00000054F7A0: DC5E0030 3B7C003B
	global_load_b128 v[63:66], v[63:64], off offset:48         // 00000054F7A8: DC5E0030 3F7C003F
	v_lshrrev_b32_e32 v10, 22, v10                             // 00000054F7B0: 32141496
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000054F7B4: 361212FF 000003FC
	v_lshlrev_b32_e32 v69, 2, v69                              // 00000054F7BC: 308A8A82
	v_and_b32_e32 v70, 0x3fc, v70                              // 00000054F7C0: 368C8CFF 000003FC
	v_and_b32_e32 v71, 0x3fc, v71                              // 00000054F7C8: 368E8EFF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 00000054F7D0: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 00000054F7D8: D8D80000 09000009
	ds_load_b32 v69, v69                                       // 00000054F7E0: D8D80000 45000045
	ds_load_b32 v70, v70                                       // 00000054F7E8: D8D80000 46000046
	ds_load_b32 v71, v71                                       // 00000054F7F0: D8D80000 47000047
	ds_load_b32 v10, v10                                       // 00000054F7F8: D8D80000 0A00000A
	v_add_nc_u32_e32 v32, 0x200, v32                           // 00000054F800: 4A4040FF 00000200
	s_and_b32 s1, exec_lo, s1                                  // 00000054F808: 8B01017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000054F80C: BF870009
	s_or_b32 s15, s1, s15                                      // 00000054F810: 8C0F0F01
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 00000054F814: BF891C77
	v_dot2_f32_bf16 v35, v35, v20, 0                           // 00000054F818: CC1A4023 1A022923
	s_waitcnt vmcnt(6)                                         // 00000054F820: BF891BF7
	v_dot2_f32_bf16 v20, v39, v20, 0                           // 00000054F824: CC1A4014 1A022927
	v_and_b32_e32 v39, 0xff, v11                               // 00000054F82C: 364E16FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 00000054F834: BF89FC67
	v_dot2_f32_bf16 v35, v36, v67, v35                         // 00000054F838: CC1A4023 1C8E8724
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054F840: BF870003
	v_dot2_f32_bf16 v20, v40, v67, v20                         // 00000054F844: CC1A4014 1C528728
	v_lshrrev_b32_e32 v36, 6, v11                              // 00000054F84C: 32481686
	v_lshrrev_b32_e32 v40, 14, v11                             // 00000054F850: 3250168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 00000054F854: 32161696
	s_waitcnt lgkmcnt(5)                                       // 00000054F858: BF89FC57
	v_dot2_f32_bf16 v35, v37, v68, v35                         // 00000054F85C: CC1A4023 1C8E8925
	v_dot2_f32_bf16 v20, v41, v68, v20                         // 00000054F864: CC1A4014 1C528929
	v_and_b32_e32 v36, 0x3fc, v36                              // 00000054F86C: 364848FF 000003FC
	v_lshrrev_b32_e32 v41, 6, v12                              // 00000054F874: 32521886
	v_and_b32_e32 v37, 0xff, v12                               // 00000054F878: 364A18FF 000000FF
	s_waitcnt lgkmcnt(4)                                       // 00000054F880: BF89FC47
	v_dot2_f32_bf16 v35, v38, v9, v35                          // 00000054F884: CC1A4023 1C8E1326
	v_dot2_f32_bf16 v9, v42, v9, v20                           // 00000054F88C: CC1A4009 1C52132A
	v_lshlrev_b32_e32 v20, 2, v39                              // 00000054F894: 30284E82
	v_and_b32_e32 v38, 0x3fc, v40                              // 00000054F898: 364C50FF 000003FC
	v_lshrrev_b32_e32 v67, 14, v12                             // 00000054F8A0: 3286188E
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 00000054F8A4: BF891437
	v_dot2_f32_bf16 v35, v43, v69, v35                         // 00000054F8A8: CC1A4023 1C8E8B2B
	s_waitcnt vmcnt(4)                                         // 00000054F8B0: BF8913F7
	v_dot2_f32_bf16 v9, v47, v69, v9                           // 00000054F8B4: CC1A4009 1C268B2F
	ds_load_b32 v20, v20                                       // 00000054F8BC: D8D80000 14000014
	ds_load_b32 v36, v36                                       // 00000054F8C4: D8D80000 24000024
	ds_load_b32 v38, v38                                       // 00000054F8CC: D8D80000 26000026
	s_waitcnt lgkmcnt(5)                                       // 00000054F8D4: BF89FC57
	v_dot2_f32_bf16 v35, v44, v70, v35                         // 00000054F8D8: CC1A4023 1C8E8D2C
	v_dot2_f32_bf16 v9, v48, v70, v9                           // 00000054F8E0: CC1A4009 1C268D30
	v_lshrrev_b32_e32 v12, 22, v12                             // 00000054F8E8: 32181896
	v_and_b32_e32 v39, 0x3fc, v41                              // 00000054F8EC: 364E52FF 000003FC
	v_cndmask_b32_e64 v41, v7, v8, s0                          // 00000054F8F4: D5010029 00021107
	s_waitcnt lgkmcnt(4)                                       // 00000054F8FC: BF89FC47
	v_dot2_f32_bf16 v35, v45, v71, v35                         // 00000054F900: CC1A4023 1C8E8F2D
	v_dot2_f32_bf16 v9, v49, v71, v9                           // 00000054F908: CC1A4009 1C268F31
	v_and_b32_e32 v11, 0x3fc, v11                              // 00000054F910: 361616FF 000003FC
	v_lshlrev_b32_e32 v37, 2, v37                              // 00000054F918: 304A4A82
	v_and_b32_e32 v40, 0x3fc, v67                              // 00000054F91C: 365086FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 00000054F924: BF89FC37
	v_dot2_f32_bf16 v35, v46, v10, v35                         // 00000054F928: CC1A4023 1C8E152E
	v_dot2_f32_bf16 v9, v50, v10, v9                           // 00000054F930: CC1A4009 1C261532
	v_and_b32_e32 v12, 0x3fc, v12                              // 00000054F938: 361818FF 000003FC
	ds_load_b32 v10, v11                                       // 00000054F940: D8D80000 0A00000B
	ds_load_b32 v11, v37                                       // 00000054F948: D8D80000 0B000025
	ds_load_b32 v42, v39                                       // 00000054F950: D8D80000 2A000027
	ds_load_b32 v43, v40                                       // 00000054F958: D8D80000 2B000028
	ds_load_b32 v44, v12                                       // 00000054F960: D8D80000 2C00000C
	v_cndmask_b32_e64 v40, v6, v7, s0                          // 00000054F968: D5010028 00020F06
	v_cndmask_b32_e64 v39, v5, v6, s0                          // 00000054F970: D5010027 00020D05
	v_cndmask_b32_e64 v37, v3, v4, s0                          // 00000054F978: D5010025 00020903
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 00000054F980: BF890C77
	v_dot2_f32_bf16 v12, v51, v20, v35                         // 00000054F984: CC1A400C 1C8E2933
	s_waitcnt vmcnt(2)                                         // 00000054F98C: BF890BF7
	v_dot2_f32_bf16 v9, v55, v20, v9                           // 00000054F990: CC1A4009 1C262937
	v_cndmask_b32_e64 v20, v31, v1, s0                         // 00000054F998: D5010014 0002031F
	v_cndmask_b32_e64 v35, v1, v2, s0                          // 00000054F9A0: D5010023 00020501
	v_mov_b32_e32 v31, v34                                     // 00000054F9A8: 7E3E0322
	s_waitcnt lgkmcnt(6)                                       // 00000054F9AC: BF89FC67
	v_dot2_f32_bf16 v12, v52, v36, v12                         // 00000054F9B0: CC1A400C 1C324934
	v_dot2_f32_bf16 v9, v56, v36, v9                           // 00000054F9B8: CC1A4009 1C264938
	v_cndmask_b32_e64 v36, v2, v3, s0                          // 00000054F9C0: D5010024 00020702
	s_waitcnt lgkmcnt(5)                                       // 00000054F9C8: BF89FC57
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000054F9CC: BF870193
	v_dot2_f32_bf16 v12, v53, v38, v12                         // 00000054F9D0: CC1A400C 1C324D35
	v_dot2_f32_bf16 v9, v57, v38, v9                           // 00000054F9D8: CC1A4009 1C264D39
	v_cndmask_b32_e64 v38, v4, v5, s0                          // 00000054F9E0: D5010026 00020B04
	s_waitcnt lgkmcnt(4)                                       // 00000054F9E8: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000054F9EC: BF870193
	v_dot2_f32_bf16 v12, v54, v10, v12                         // 00000054F9F0: CC1A400C 1C321536
	v_dot2_f32_bf16 v9, v58, v10, v9                           // 00000054F9F8: CC1A4009 1C26153A
	v_mov_b32_e32 v10, v14                                     // 00000054FA00: 7E14030E
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 00000054FA04: BF890437
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054FA08: BF870003
	v_dot2_f32_bf16 v5, v59, v11, v12                          // 00000054FA0C: CC1A4005 1C32173B
	s_waitcnt vmcnt(0)                                         // 00000054FA14: BF8903F7
	v_dot2_f32_bf16 v6, v63, v11, v9                           // 00000054FA18: CC1A4006 1C26173F
	v_dual_mov_b32 v12, v16 :: v_dual_mov_b32 v11, v15         // 00000054FA20: CA100110 0C0A010F
	v_mov_b32_e32 v9, v13                                      // 00000054FA28: 7E12030D
	s_waitcnt lgkmcnt(2)                                       // 00000054FA2C: BF89FC27
	v_dot2_f32_bf16 v1, v60, v42, v5                           // 00000054FA30: CC1A4001 1C16553C
	v_dot2_f32_bf16 v2, v64, v42, v6                           // 00000054FA38: CC1A4002 1C1A5540
	v_dual_mov_b32 v42, v8 :: v_dual_add_nc_u32 v33, 64, v33   // 00000054FA40: CA200108 2A2042C0
	v_add_nc_u32_e32 v19, 0x400, v19                           // 00000054FA48: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 00000054FA50: BF89FC17
	v_dot2_f32_bf16 v1, v61, v43, v1                           // 00000054FA54: CC1A4001 1C06573D
	v_dot2_f32_bf16 v2, v65, v43, v2                           // 00000054FA5C: CC1A4002 1C0A5741
	s_waitcnt lgkmcnt(0)                                       // 00000054FA64: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054FA68: BF870112
	v_dot2_f32_bf16 v1, v62, v44, v1                           // 00000054FA6C: CC1A4001 1C06593E
	v_dot2_f32_bf16 v2, v66, v44, v2                           // 00000054FA74: CC1A4002 1C0A5942
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054FA7C: BF870112
	v_fmac_f32_e32 v30, v20, v1                                // 00000054FA80: 563C0314
	v_fmac_f32_e32 v27, v20, v2                                // 00000054FA84: 56360514
	v_dual_mov_b32 v1, v35 :: v_dual_mov_b32 v2, v36           // 00000054FA88: CA100123 01020124
	v_dual_mov_b32 v3, v37 :: v_dual_mov_b32 v4, v38           // 00000054FA90: CA100125 03040126
	v_dual_mov_b32 v5, v39 :: v_dual_mov_b32 v6, v40           // 00000054FA98: CA100127 05060128
	v_dual_mov_b32 v7, v41 :: v_dual_mov_b32 v8, v42           // 00000054FAA0: CA100129 0708012A
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000054FAA8: 917E0F7E
	s_cbranch_execz 35                                         // 00000054FAAC: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x93c>
	s_waitcnt vmcnt(0)                                         // 00000054FAB0: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v24, 32, v24   // 00000054FAB4: CA200109 0D1830A0
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 00000054FABC: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 00000054FAC4: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054FAC8: BF870003
	.long 0xd4460001                                           // 00000054FACC: D4460001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 00000054FAD0: 02023318
	s_mov_b32 s10, exec_lo                                     // 00000054FAD4: BE8A007E
	.long 0xd4c1007e                                           // 00000054FAD8: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 00000054FADC: 02023318
	s_cbranch_execz 65280                                      // 00000054FAE0: BFA5FF00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4e4>
	v_ashrrev_i32_e32 v14, 31, v32                             // 00000054FAE4: 341C409F
	.long 0xd7006a0d                                           // 00000054FAE8: D7006A0D
	v_cndmask_b32_e32 v1, v18, v32, vcc_lo                     // 00000054FAEC: 02024112
	v_mov_b32_e32 v34, v31                                     // 00000054FAF0: 7E44031F
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054FAF4: BF870003
	v_add_co_ci_u32_e64 v14, null, v29, v14, vcc_lo            // 00000054FAF8: D5207C0E 01AA1D1D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 00000054FB00: 7C9A3881
	global_load_b128 v[13:16], v[13:14], off                   // 00000054FB04: DC5E0000 0D7C000D
	s_cbranch_vccnz 65269                                      // 00000054FB0C: BFA4FEF5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4e4>
	v_ashrrev_i32_e32 v20, 31, v33                             // 00000054FB10: 3428429F
	.long 0xd7006a22                                           // 00000054FB14: D7006A22
	v_cndmask_b32_e32 v1, v17, v33, vcc_lo                     // 00000054FB18: 02024311
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054FB1C: BF870001
	v_add_co_ci_u32_e64 v35, null, v26, v20, vcc_lo            // 00000054FB20: D5207C23 01AA291A
	global_load_d16_b16 v20, v[34:35], off                     // 00000054FB28: DC820000 147C0022
	s_waitcnt vmcnt(0)                                         // 00000054FB30: BF8903F7
	v_cvt_f32_f16_e32 v34, v20                                 // 00000054FB34: 7E441714
	s_branch 65258                                             // 00000054FB38: BFA0FEEA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4e4>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000054FB3C: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000054FB40: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 00000054FB44: 8C7E0E7E
	.long 0xd71f0001                                           // 00000054FB48: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000054FB4C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000054FB50: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000054FB54: 3A040290
	v_xor_b32_e32 v4, 8, v1                                    // 00000054FB58: 3A080288
	v_xor_b32_e32 v6, 4, v1                                    // 00000054FB5C: 3A0C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000054FB60: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000054FB64: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000054FB68: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000054FB6C: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054FB70: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000054FB74: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000054FB78: 02080901
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000054FB7C: 7C980CA0
	ds_bpermute_b32 v3, v2, v30                                // 00000054FB80: DACC0000 03001E02
	s_waitcnt lgkmcnt(0)                                       // 00000054FB88: BF89FC07
	v_dual_add_f32 v3, v30, v3 :: v_dual_lshlrev_b32 v4, 2, v4 // 00000054FB8C: C922071E 03040882
	ds_bpermute_b32 v5, v4, v3                                 // 00000054FB94: DACC0000 05000304
	s_waitcnt lgkmcnt(0)                                       // 00000054FB9C: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 00000054FBA0: 06060B03
	ds_bpermute_b32 v2, v2, v27                                // 00000054FBA4: DACC0000 02001B02
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 00000054FBAC: 020C0D01
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054FBB0: BF870001
	v_lshlrev_b32_e32 v6, 2, v6                                // 00000054FBB4: 300C0C82
	s_waitcnt lgkmcnt(0)                                       // 00000054FBB8: BF89FC07
	v_add_f32_e32 v2, v27, v2                                  // 00000054FBBC: 0604051B
	ds_bpermute_b32 v4, v4, v2                                 // 00000054FBC0: DACC0000 04000204
	s_waitcnt lgkmcnt(0)                                       // 00000054FBC8: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 00000054FBCC: 06040902
	ds_bpermute_b32 v4, v6, v3                                 // 00000054FBD0: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 00000054FBD8: DACC0000 05000206
	v_xor_b32_e32 v6, 2, v1                                    // 00000054FBE0: 3A0C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000054FBE4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000054FBE8: 7C980CA0
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 00000054FBEC: 020C0D01
	s_waitcnt lgkmcnt(1)                                       // 00000054FBF0: BF89FC17
	v_dual_add_f32 v3, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v6  // 00000054FBF4: C9220903 03060C82
	s_waitcnt lgkmcnt(0)                                       // 00000054FBFC: BF89FC07
	v_add_f32_e32 v4, v2, v5                                   // 00000054FC00: 06080B02
	ds_bpermute_b32 v2, v6, v3                                 // 00000054FC04: DACC0000 02000306
	ds_bpermute_b32 v5, v6, v4                                 // 00000054FC0C: DACC0000 05000406
	v_xor_b32_e32 v6, 1, v1                                    // 00000054FC14: 3A0C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054FC18: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000054FC1C: 7C980CA0
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 00000054FC20: 02020D01
	v_lshlrev_b32_e32 v6, 2, v1                                // 00000054FC24: 300C0282
	s_waitcnt lgkmcnt(0)                                       // 00000054FC28: BF89FC07
	v_dual_add_f32 v2, v3, v2 :: v_dual_add_f32 v1, v4, v5     // 00000054FC2C: C9080503 02000B04
	ds_bpermute_b32 v4, v6, v2                                 // 00000054FC34: DACC0000 04000206
	ds_bpermute_b32 v3, v6, v1                                 // 00000054FC3C: DACC0000 03000106
	v_cmpx_eq_u32_e32 0, v23                                   // 00000054FC44: 7D942E80
	s_cbranch_execz 10                                         // 00000054FC48: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xa74>
	s_waitcnt lgkmcnt(1)                                       // 00000054FC4C: BF89FC17
	v_dual_add_f32 v2, v2, v4 :: v_dual_lshlrev_b32 v5, 3, v22 // 00000054FC50: C9220902 02042C83
	s_waitcnt lgkmcnt(0)                                       // 00000054FC58: BF89FC07
	v_add_f32_e32 v3, v1, v3                                   // 00000054FC5C: 06060701
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054FC60: BF870002
	v_lshl_or_b32 v4, v21, 4, v5                               // 00000054FC64: D6560004 04150915
	ds_store_b64 v4, v[2:3] offset:1024                        // 00000054FC6C: D9340400 00000204
	s_or_b32 exec_lo, exec_lo, s0                              // 00000054FC74: 8C7E007E
	s_waitcnt lgkmcnt(0)                                       // 00000054FC78: BF89FC07
	v_lshrrev_b32_e32 v3, 1, v0                                // 00000054FC7C: 32060081
	v_mov_b32_e32 v2, s3                                       // 00000054FC80: 7E040203
	.long 0xd44c0000                                           // 00000054FC84: D44C0000
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 00000054FC88: 02020088
	s_waitcnt vmcnt(0)                                         // 00000054FC8C: BF8903F7
	s_barrier                                                  // 00000054FC90: BFBD0000
	v_or_b32_e32 v1, s2, v3                                    // 00000054FC94: 38020602
	buffer_gl0_inv                                             // 00000054FC98: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000054FCA0: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 00000054FCA4: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000054FCA8: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000054FCAC: BE812000
	s_cbranch_execz 39                                         // 00000054FCB0: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xb50>
	v_and_b32_e32 v0, 1, v0                                    // 00000054FCB4: 36000081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000054FCB8: BF8701B1
	v_lshlrev_b32_e32 v4, 2, v0                                // 00000054FCBC: 30080082
	.long 0xd72c0006                                           // 00000054FCC0: D72C0006
	v_cndmask_b32_e32 v1, s13, v0, vcc_lo                      // 00000054FCC4: 0202000D
	.long 0xd72c0005                                           // 00000054FCC8: D72C0005
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 00000054FCCC: 0202000C
	v_lshl_or_b32 v3, v3, 4, v4                                // 00000054FCD0: D6560003 04110903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000054FCD8: BF8700C1
	v_add_nc_u32_e32 v3, 0x400, v3                             // 00000054FCDC: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:2                     // 00000054FCE4: D8DC0200 03000003
	s_waitcnt lgkmcnt(0)                                       // 00000054FCEC: BF89FC07
	v_add_f32_e32 v0, 0, v3                                    // 00000054FCF0: 06000680
	v_add_f32_e32 v7, v0, v4                                   // 00000054FCF4: 060E0900
	.long 0xd73c0003                                           // 00000054FCF8: D73C0003
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000054FCFC: 02020A81
	.long 0xd73c0000                                           // 00000054FD00: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000054FD04: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000054FD08: BF870193
	v_bfe_u32 v2, v7, 16, 1                                    // 00000054FD0C: D6100002 02052107
	.long 0xd7006a03                                           // 00000054FD14: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 00000054FD18: 02020608
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000054FD1C: BF870191
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000054FD20: D5207C04 01AA0809
	v_add3_u32 v2, v7, v2, 0x7fff                              // 00000054FD28: D6550002 03FE0507 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054FD34: BF870093
	.long 0xd7006a00                                           // 00000054FD38: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000054FD3C: 02020103
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 00000054FD40: D5207C01 01AA0304
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000054FD48: DC960000 007C0200
	s_endpgm                                                   // 00000054FD50: BFB00000
		...

