00000000007b9000 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007B9000: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000007B9008: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007B900C: 32040082
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000007B9010: 84948202
	v_and_b32_e32 v1, 15, v0                                   // 0000007B9014: 3602008F
	v_lshrrev_b32_e32 v21, 6, v0                               // 0000007B9018: 322A0086
	v_bfe_u32 v22, v0, 5, 1                                    // 0000007B901C: D6100016 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 0000007B9024: 360404BC
	v_and_b32_e32 v23, 31, v0                                  // 0000007B9028: 362E009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007B902C: 30020282
	.long 0x7f0a3880                                           // 0000007B9030: 7F0A3880
	s_waitcnt lgkmcnt(0)                                       // 0000007B9034: BF89FC07
	s_clause 0x1                                               // 0000007B9038: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 0000007B903C: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 0000007B9044: DC520000 04040002
	s_add_u32 s2, s4, s16                                      // 0000007B904C: 80021004
	s_addc_u32 s3, s5, s17                                     // 0000007B9050: 82031105
	s_ashr_i32 s16, s11, 31                                    // 0000007B9054: 86109F0B
	v_mov_b32_e32 v2, s21                                      // 0000007B9058: 7E040215
	s_lshr_b32 s16, s16, 27                                    // 0000007B905C: 85109B10
	v_or_b32_e32 v1, s20, v21                                  // 0000007B9060: 38022A14
	s_add_u32 s16, s10, s16                                    // 0000007B9064: 8010100A
	s_addc_u32 s17, s11, 0                                     // 0000007B9068: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B906C: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 0000007B9070: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007B9074: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 0000007B9078: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000007B907C: BF870499
	s_lshr_b32 s22, s17, 31                                    // 0000007B9080: 85169F11
	s_add_i32 s17, s17, s22                                    // 0000007B9084: 81111611
	v_cndmask_b32_e32 v9, 0, v1, vcc_lo                        // 0000007B9088: 02120280
	s_ashr_i32 s17, s17, 1                                     // 0000007B908C: 86118111
	v_cndmask_b32_e64 v10, 0, s21, vcc_lo                      // 0000007B9090: D501000A 01A82A80
	.long 0xd72c0002                                           // 0000007B9098: D72C0002
	v_cndmask_b32_e32 v1, s17, v22, vcc_lo                     // 0000007B909C: 02022C11
	s_cmpk_lt_i32 s16, 0x201                                   // 0000007B90A0: B3900201
	.long 0xd72c0007                                           // 0000007B90A4: D72C0007
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 0000007B90A8: 02021213
	v_mad_u64_u32 v[17:18], null, s18, v9, s[2:3]              // 0000007B90AC: D6FE7C11 000A1212
	s_cselect_b32 s2, -1, 0                                    // 0000007B90B4: 980280C1
	s_cmpk_gt_i32 s16, 0x200                                   // 0000007B90B8: B2900200
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000007B90BC: 30020082
	v_add_nc_u32_e32 v11, s17, v2                              // 0000007B90C0: 4A160411
	v_add_nc_u32_e32 v24, v2, v23                              // 0000007B90C4: 4A302F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007B90C8: BF8704A2
	v_min_i32_e32 v25, s16, v11                                // 0000007B90CC: 22321610
	s_cselect_b32 s16, -1, 0                                   // 0000007B90D0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000007B90D4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007B90D8: BF870151
	.long 0xd4410003                                           // 0000007B90DC: D4410003
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007B90E0: 02023318
	s_waitcnt vmcnt(1)                                         // 0000007B90E4: BF8907F7
	v_bfe_u32 v6, v3, 16, 1                                    // 0000007B90E8: D6100006 02052103
	s_waitcnt vmcnt(0)                                         // 0000007B90F0: BF8903F7
	v_bfe_u32 v8, v4, 16, 1                                    // 0000007B90F4: D6100008 02052104
	v_add3_u32 v3, v3, v6, 0x7fff                              // 0000007B90FC: D6550003 03FE0D03 00007FFF
	.long 0xd72c0006                                           // 0000007B9108: D72C0006
	v_cndmask_b32_e32 v1, s18, v10, vcc_lo                     // 0000007B910C: 02021412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007B9110: BF870193
	v_add3_u32 v4, v4, v8, 0x7fff                              // 0000007B9114: D6550004 03FE1104 00007FFF
	.long 0x7e0a3983                                           // 0000007B9120: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007B9124: BF870113
	v_add3_u32 v26, v7, v18, v6                                // 0000007B9128: D655001A 041A2507
	v_and_or_b32 v2, 0xffff0000, v4, v5                        // 0000007B9130: D6570002 041608FF FFFF0000
	ds_store_b32 v1, v2                                        // 0000007B913C: D8340000 00000201
	s_waitcnt lgkmcnt(0)                                       // 0000007B9144: BF89FC07
	s_barrier                                                  // 0000007B9148: BFBD0000
	buffer_gl0_inv                                             // 0000007B914C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000007B9154: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 0000007B9158: CA100080 02000080
	s_and_saveexec_b32 s17, s3                                 // 0000007B9160: BE912003
	s_cbranch_execz 11                                         // 0000007B9164: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v1, 1, v24                               // 0000007B9168: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B916C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 0000007B9170: 3408029F
	.long 0xd7006a03                                           // 0000007B9174: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000007B9178: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 0000007B917C: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 0000007B9184: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 0000007B918C: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000007B9190: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 0000007B9194: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v24                               // 0000007B9198: 4A0630A0
	s_mov_b32 s3, exec_lo                                      // 0000007B919C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007B91A0: BF870001
	.long 0xd4c1007e                                           // 0000007B91A4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 0000007B91A8: 02023303
	s_cbranch_execz 11                                         // 0000007B91AC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v2, 1, v3                                // 0000007B91B0: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B91B4: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000007B91B8: 3406049F
	.long 0xd7006a02                                           // 0000007B91BC: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 0000007B91C0: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 0000007B91C4: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 0000007B91CC: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000007B91D4: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007B91D8: 7E041702
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007B91DC: 8C7E037E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 0000007B91E0: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 0000007B91E8: 7E060280
	s_mov_b32 s3, exec_lo                                      // 0000007B91EC: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007B91F0: BF870002
	.long 0xd4c1007e                                           // 0000007B91F4: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000007B91F8: 02023305
	s_cbranch_execz 11                                         // 0000007B91FC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v5                                // 0000007B9200: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B9204: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 0000007B9208: 340C069F
	.long 0xd7006a05                                           // 0000007B920C: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 0000007B9210: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 0000007B9214: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 0000007B921C: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 0000007B9224: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000007B9228: 7E061703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007B922C: 8C7E037E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 0000007B9230: 4A0A30FF 00000060
	s_mov_b32 s3, exec_lo                                      // 0000007B9238: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007B923C: BF870001
	.long 0xd4c1007e                                           // 0000007B9240: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000007B9244: 02023305
	s_cbranch_execz 11                                         // 0000007B9248: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v4, 1, v5                                // 0000007B924C: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B9250: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 0000007B9254: 340A089F
	.long 0xd7006a04                                           // 0000007B9258: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 0000007B925C: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 0000007B9260: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 0000007B9268: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000007B9270: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000007B9274: 7E081704
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007B9278: 8C7E037E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 0000007B927C: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 0000007B9288: 7E0A0280
	s_mov_b32 s3, exec_lo                                      // 0000007B928C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007B9290: BF870002
	.long 0xd4c1007e                                           // 0000007B9294: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000007B9298: 02023307
	s_cbranch_execz 11                                         // 0000007B929C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v5, 1, v7                                // 0000007B92A0: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B92A4: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 0000007B92A8: 34100A9F
	.long 0xd7006a07                                           // 0000007B92AC: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000007B92B0: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 0000007B92B4: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 0000007B92BC: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000007B92C4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007B92C8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007B92CC: 8C7E037E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 0000007B92D0: 4A0E30FF 000000A0
	s_mov_b32 s3, exec_lo                                      // 0000007B92D8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007B92DC: BF870001
	.long 0xd4c1007e                                           // 0000007B92E0: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000007B92E4: 02023307
	s_cbranch_execz 11                                         // 0000007B92E8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000007B92EC: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B92F0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000007B92F4: 340E0C9F
	.long 0xd7006a06                                           // 0000007B92F8: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000007B92FC: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 0000007B9300: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 0000007B9308: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 0000007B9310: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000007B9314: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007B9318: 8C7E037E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0xc0, v24   // 0000007B931C: CA200080 080A30FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 0000007B9328: 7E0E0280
	s_mov_b32 s3, exec_lo                                      // 0000007B932C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007B9330: BF870002
	.long 0xd4c1007e                                           // 0000007B9334: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 0000007B9338: 0202330B
	s_cbranch_execz 11                                         // 0000007B933C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v7, 1, v11                               // 0000007B9340: 300E1681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B9344: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v7                              // 0000007B9348: 34180E9F
	.long 0xd7006a0b                                           // 0000007B934C: D7006A0B
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 0000007B9350: 02020F11
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 0000007B9354: D5207C0C 01AA191A
	global_load_d16_b16 v7, v[11:12], off                      // 0000007B935C: DC820000 077C000B
	s_waitcnt vmcnt(0)                                         // 0000007B9364: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000007B9368: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007B936C: 8C7E037E
	v_add_nc_u32_e32 v11, 0xe0, v24                            // 0000007B9370: 4A1630FF 000000E0
	s_mov_b32 s3, exec_lo                                      // 0000007B9378: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007B937C: BF870001
	.long 0xd4c1007e                                           // 0000007B9380: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 0000007B9384: 0202330B
	s_cbranch_execz 11                                         // 0000007B9388: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v8, 1, v11                               // 0000007B938C: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B9390: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 0000007B9394: 3418109F
	.long 0xd7006a0b                                           // 0000007B9398: D7006A0B
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 0000007B939C: 02021111
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 0000007B93A0: D5207C0C 01AA191A
	global_load_d16_b16 v8, v[11:12], off                      // 0000007B93A8: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 0000007B93B0: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000007B93B4: 7E101708
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007B93B8: 8C7E037E
	s_branch 9                                                 // 0000007B93BC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v1, 0                                        // 0000007B93C0: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007B93C4: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000007B93C8: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000007B93CC: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000007B93D0: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000007B93D4: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000007B93D8: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000007B93DC: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000007B93E0: 7E100301
	s_add_u32 s4, s4, s14                                      // 0000007B93E4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 0000007B93E8: 82050F05
	s_lshr_b32 s3, s11, 31                                     // 0000007B93EC: 85039F0B
	v_mov_b32_e32 v27, 0                                       // 0000007B93F0: 7E360280
	s_add_u32 s10, s10, s3                                     // 0000007B93F4: 800A030A
	s_addc_u32 s11, s11, 0                                     // 0000007B93F8: 820B800B
	.long 0xd4410003                                           // 0000007B93FC: D4410003
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007B9400: 02023318
	s_ashr_i64 s[10:11], s[10:11], 1                           // 0000007B9404: 868A810A
	v_cndmask_b32_e64 v28, 0, 1, s16                           // 0000007B9408: D501001C 00410280
	v_mad_u64_u32 v[18:19], null, v9, s10, s[4:5]              // 0000007B9410: D6FE7C12 00101509
	.long 0xd72c000c                                           // 0000007B9418: D72C000C
	v_cndmask_b32_e32 v0, v9, v11, vcc_lo                      // 0000007B941C: 02001709
	.long 0xd72c000d                                           // 0000007B9420: D72C000D
	v_cndmask_b32_e32 v0, v10, v10, vcc_lo                     // 0000007B9424: 0200150A
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v30, 0              // 0000007B9428: CA100080 091E0080
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 0000007B9430: CA100080 0A0A0080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007B9438: BF870003
	v_add3_u32 v29, v13, v19, v12                              // 0000007B943C: D655001D 0432270D
	v_mov_b32_e32 v12, 0                                       // 0000007B9444: 7E180280
	s_and_saveexec_b32 s4, s3                                  // 0000007B9448: BE842003
	s_cbranch_execz 22                                         // 0000007B944C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_dual_mov_b32 v30, 0 :: v_dual_lshlrev_b32 v9, 4, v24     // 0000007B9450: CA220080 1E083084
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B9458: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000007B945C: 3414129F
	.long 0xd7006a09                                           // 0000007B9460: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 0000007B9464: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 0000007B9468: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 0000007B9470: 916A107E
	global_load_b128 v[9:12], v[9:10], off                     // 0000007B9474: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 0000007B947C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v13, 1, v24                              // 0000007B9480: 301A3081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B9484: BF870091
	.long 0xd7006a0d                                           // 0000007B9488: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 0000007B948C: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v26, vcc_lo              // 0000007B9490: D5207C0E 01AA3480
	global_load_d16_b16 v13, v[13:14], off                     // 0000007B9498: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 0000007B94A0: BF8903F7
	v_cvt_f32_f16_e32 v30, v13                                 // 0000007B94A4: 7E3C170D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007B94A8: 8C7E047E
	s_and_saveexec_b32 s4, s3                                  // 0000007B94AC: BE842003
	s_cbranch_execz 232                                        // 0000007B94B0: BFA500E8 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x854>
	v_add_nc_u32_e32 v13, 32, v24                              // 0000007B94B4: 4A1A30A0
	v_lshlrev_b32_e32 v19, 5, v24                              // 0000007B94B8: 30263085
	v_mov_b32_e32 v27, 0                                       // 0000007B94BC: 7E360280
	v_mov_b32_e32 v33, v30                                     // 0000007B94C0: 7E42031E
	s_mov_b32 s5, 0                                            // 0000007B94C4: BE850080
	v_lshlrev_b32_e32 v31, 4, v13                              // 0000007B94C8: 303E1A84
	v_lshlrev_b32_e32 v32, 1, v13                              // 0000007B94CC: 30401A81
	s_branch 188                                               // 0000007B94D0: BFA000BC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x7c4>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000007B94D4: 8C7E0A7E
	v_ashrrev_i32_e32 v20, 31, v19                             // 0000007B94D8: 3428269F
	v_lshrrev_b32_e32 v50, 6, v9                               // 0000007B94DC: 32641286
	v_lshrrev_b32_e32 v51, 14, v9                              // 0000007B94E0: 3266128E
	v_and_b32_e32 v52, 0xff, v10                               // 0000007B94E4: 366814FF 000000FF
	v_lshrrev_b32_e32 v53, 6, v10                              // 0000007B94EC: 326A1486
	.long 0xd73c0022                                           // 0000007B94F0: D73C0022
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000007B94F4: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 0000007B94F8: 362812FF 000000FF
	v_and_b32_e32 v50, 0x3fc, v50                              // 0000007B9500: 366464FF 000003FC
	v_and_b32_e32 v51, 0x3fc, v51                              // 0000007B9508: 366666FF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000007B9510: 32121296
	v_lshrrev_b32_e32 v54, 14, v10                             // 0000007B9514: 326C148E
	.long 0xd7006a2e                                           // 0000007B9518: D7006A2E
	v_cndmask_b32_e32 v1, s6, v34, vcc_lo                      // 0000007B951C: 02024406
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007B9520: BF870001
	v_add_co_ci_u32_e64 v47, null, s7, v35, vcc_lo             // 0000007B9524: D5207C2F 01AA4607
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000007B952C: 30282882
	ds_load_b32 v50, v50                                       // 0000007B9530: D8D80000 32000032
	ds_load_b32 v51, v51                                       // 0000007B9538: D8D80000 33000033
	s_clause 0x3                                               // 0000007B9540: BF850003
	global_load_b128 v[34:37], v[46:47], off                   // 0000007B9544: DC5E0000 227C002E
	global_load_b128 v[38:41], v[46:47], off offset:16         // 0000007B954C: DC5E0010 267C002E
	global_load_b128 v[42:45], v[46:47], off offset:32         // 0000007B9554: DC5E0020 2A7C002E
	global_load_b128 v[46:49], v[46:47], off offset:48         // 0000007B955C: DC5E0030 2E7C002E
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000007B9564: 32141496
	ds_load_b32 v20, v20                                       // 0000007B9568: D8D80000 14000014
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007B9570: 361212FF 000003FC
	v_lshlrev_b32_e32 v52, 2, v52                              // 0000007B9578: 30686882
	v_and_b32_e32 v53, 0x3fc, v53                              // 0000007B957C: 366A6AFF 000003FC
	v_and_b32_e32 v54, 0x3fc, v54                              // 0000007B9584: 366C6CFF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000007B958C: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 0000007B9594: D8D80000 09000009
	ds_load_b32 v52, v52                                       // 0000007B959C: D8D80000 34000034
	ds_load_b32 v53, v53                                       // 0000007B95A4: D8D80000 35000035
	ds_load_b32 v54, v54                                       // 0000007B95AC: D8D80000 36000036
	ds_load_b32 v10, v10                                       // 0000007B95B4: D8D80000 0A00000A
	v_add_nc_u32_e32 v32, 64, v32                              // 0000007B95BC: 4A4040C0
	s_and_b32 s3, exec_lo, s3                                  // 0000007B95C0: 8B03037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007B95C4: BF870149
	s_or_b32 s5, s3, s5                                        // 0000007B95C8: 8C050503
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 0000007B95CC: BF890C57
	v_dot2_f32_bf16 v20, v34, v20, 0                           // 0000007B95D0: CC1A4014 1A022922
	v_and_b32_e32 v34, 0xff, v11                               // 0000007B95D8: 364416FF 000000FF
	v_dot2_f32_bf16 v20, v35, v50, v20                         // 0000007B95E0: CC1A4014 1C526523
	v_lshrrev_b32_e32 v35, 6, v11                              // 0000007B95E8: 32461686
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007B95EC: BF8701A2
	v_dot2_f32_bf16 v20, v36, v51, v20                         // 0000007B95F0: CC1A4014 1C526724
	v_lshrrev_b32_e32 v36, 14, v11                             // 0000007B95F8: 3248168E
	v_and_b32_e32 v35, 0x3fc, v35                              // 0000007B95FC: 364646FF 000003FC
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000007B9604: 32161696
	s_waitcnt lgkmcnt(4)                                       // 0000007B9608: BF89FC47
	v_dot2_f32_bf16 v9, v37, v9, v20                           // 0000007B960C: CC1A4009 1C521325
	v_and_b32_e32 v36, 0x3fc, v36                              // 0000007B9614: 364848FF 000003FC
	v_lshrrev_b32_e32 v37, 6, v12                              // 0000007B961C: 324A1886
	ds_load_b32 v35, v35                                       // 0000007B9620: D8D80000 23000023
	s_waitcnt vmcnt(2) lgkmcnt(4)                              // 0000007B9628: BF890847
	v_dot2_f32_bf16 v9, v38, v52, v9                           // 0000007B962C: CC1A4009 1C266926
	ds_load_b32 v36, v36                                       // 0000007B9634: D8D80000 24000024
	v_lshrrev_b32_e32 v38, 14, v12                             // 0000007B963C: 324C188E
	v_and_b32_e32 v37, 0x3fc, v37                              // 0000007B9640: 364A4AFF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000007B9648: BF89FC47
	v_dot2_f32_bf16 v9, v39, v53, v9                           // 0000007B964C: CC1A4009 1C266B27
	v_cndmask_b32_e64 v39, v6, v7, s2                          // 0000007B9654: D5010027 000A0F06
	v_and_b32_e32 v38, 0x3fc, v38                              // 0000007B965C: 364C4CFF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000007B9664: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007B9668: BF870133
	v_dot2_f32_bf16 v9, v40, v54, v9                           // 0000007B966C: CC1A4009 1C266D28
	v_cndmask_b32_e64 v40, v7, v8, s2                          // 0000007B9674: D5010028 000A1107
	s_waitcnt lgkmcnt(2)                                       // 0000007B967C: BF89FC27
	v_dot2_f32_bf16 v9, v41, v10, v9                           // 0000007B9680: CC1A4009 1C261529
	v_dual_mov_b32 v41, v8 :: v_dual_lshlrev_b32 v20, 2, v34   // 0000007B9688: CA220108 29144482
	v_and_b32_e32 v34, 0xff, v12                               // 0000007B9690: 364418FF 000000FF
	v_lshrrev_b32_e32 v12, 22, v12                             // 0000007B9698: 32181896
	ds_load_b32 v20, v20                                       // 0000007B969C: D8D80000 14000014
	v_lshlrev_b32_e32 v34, 2, v34                              // 0000007B96A4: 30444482
	v_and_b32_e32 v12, 0x3fc, v12                              // 0000007B96A8: 361818FF 000003FC
	s_waitcnt vmcnt(1) lgkmcnt(0)                              // 0000007B96B0: BF890407
	v_dot2_f32_bf16 v9, v42, v20, v9                           // 0000007B96B4: CC1A4009 1C26292A
	v_cndmask_b32_e64 v20, v30, v1, s2                         // 0000007B96BC: D5010014 000A031E
	v_mov_b32_e32 v30, v33                                     // 0000007B96C4: 7E3C0321
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007B96C8: BF870123
	v_dot2_f32_bf16 v9, v43, v35, v9                           // 0000007B96CC: CC1A4009 1C26472B
	v_cndmask_b32_e64 v35, v2, v3, s2                          // 0000007B96D4: D5010023 000A0702
	v_dot2_f32_bf16 v9, v44, v36, v9                           // 0000007B96DC: CC1A4009 1C26492C
	v_cndmask_b32_e64 v36, v3, v4, s2                          // 0000007B96E4: D5010024 000A0903
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007B96EC: 361616FF 000003FC
	ds_load_b32 v10, v11                                       // 0000007B96F4: D8D80000 0A00000B
	ds_load_b32 v11, v34                                       // 0000007B96FC: D8D80000 0B000022
	ds_load_b32 v34, v37                                       // 0000007B9704: D8D80000 22000025
	ds_load_b32 v50, v38                                       // 0000007B970C: D8D80000 32000026
	ds_load_b32 v51, v12                                       // 0000007B9714: D8D80000 3300000C
	v_cndmask_b32_e64 v38, v5, v6, s2                          // 0000007B971C: D5010026 000A0D05
	v_cndmask_b32_e64 v37, v4, v5, s2                          // 0000007B9724: D5010025 000A0B04
	v_mov_b32_e32 v12, v16                                     // 0000007B972C: 7E180310
	s_waitcnt lgkmcnt(4)                                       // 0000007B9730: BF89FC47
	v_dot2_f32_bf16 v9, v45, v10, v9                           // 0000007B9734: CC1A4009 1C26152D
	v_mov_b32_e32 v10, v14                                     // 0000007B973C: 7E14030E
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007B9740: BF890037
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007B9744: BF870132
	v_dot2_f32_bf16 v9, v46, v11, v9                           // 0000007B9748: CC1A4009 1C26172E
	v_mov_b32_e32 v11, v15                                     // 0000007B9750: 7E16030F
	s_waitcnt lgkmcnt(2)                                       // 0000007B9754: BF89FC27
	v_dot2_f32_bf16 v5, v47, v34, v9                           // 0000007B9758: CC1A4005 1C26452F
	v_cndmask_b32_e64 v34, v1, v2, s2                          // 0000007B9760: D5010022 000A0501
	v_add_nc_u32_e32 v31, 0x200, v31                           // 0000007B9768: 4A3E3EFF 00000200
	v_mov_b32_e32 v9, v13                                      // 0000007B9770: 7E12030D
	v_add_nc_u32_e32 v19, 0x400, v19                           // 0000007B9774: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 0000007B977C: BF89FC17
	v_dot2_f32_bf16 v1, v48, v50, v5                           // 0000007B9780: CC1A4001 1C166530
	s_waitcnt lgkmcnt(0)                                       // 0000007B9788: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B978C: BF870091
	v_dot2_f32_bf16 v1, v49, v51, v1                           // 0000007B9790: CC1A4001 1C066731
	v_fmac_f32_e32 v27, v20, v1                                // 0000007B9798: 56360314
	v_dual_mov_b32 v1, v34 :: v_dual_mov_b32 v2, v35           // 0000007B979C: CA100122 01020123
	v_dual_mov_b32 v3, v36 :: v_dual_mov_b32 v4, v37           // 0000007B97A4: CA100124 03040125
	v_dual_mov_b32 v5, v38 :: v_dual_mov_b32 v6, v39           // 0000007B97AC: CA100126 05060127
	v_dual_mov_b32 v7, v40 :: v_dual_mov_b32 v8, v41           // 0000007B97B4: CA100128 07080129
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000007B97BC: 917E057E
	s_cbranch_execz 35                                         // 0000007B97C0: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x850>
	s_waitcnt vmcnt(0)                                         // 0000007B97C4: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v24, 32, v24   // 0000007B97C8: CA200109 0D1830A0
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 0000007B97D0: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 0000007B97D8: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007B97DC: BF870003
	.long 0xd4460003                                           // 0000007B97E0: D4460003
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007B97E4: 02023318
	s_mov_b32 s10, exec_lo                                     // 0000007B97E8: BE8A007E
	.long 0xd4c1007e                                           // 0000007B97EC: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007B97F0: 02023318
	s_cbranch_execz 65335                                      // 0000007B97F4: BFA5FF37 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4d4>
	v_ashrrev_i32_e32 v14, 31, v31                             // 0000007B97F8: 341C3E9F
	.long 0xd7006a0d                                           // 0000007B97FC: D7006A0D
	v_cndmask_b32_e32 v1, v18, v31, vcc_lo                     // 0000007B9800: 02023F12
	v_mov_b32_e32 v33, v30                                     // 0000007B9804: 7E42031E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007B9808: BF870003
	v_add_co_ci_u32_e64 v14, null, v29, v14, vcc_lo            // 0000007B980C: D5207C0E 01AA1D1D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 0000007B9814: 7C9A3881
	global_load_b128 v[13:16], v[13:14], off                   // 0000007B9818: DC5E0000 0D7C000D
	s_cbranch_vccnz 65324                                      // 0000007B9820: BFA4FF2C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4d4>
	v_ashrrev_i32_e32 v20, 31, v32                             // 0000007B9824: 3428409F
	.long 0xd7006a21                                           // 0000007B9828: D7006A21
	v_cndmask_b32_e32 v1, v17, v32, vcc_lo                     // 0000007B982C: 02024111
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007B9830: BF870001
	v_add_co_ci_u32_e64 v34, null, v26, v20, vcc_lo            // 0000007B9834: D5207C22 01AA291A
	global_load_d16_b16 v20, v[33:34], off                     // 0000007B983C: DC820000 147C0021
	s_waitcnt vmcnt(0)                                         // 0000007B9844: BF8903F7
	v_cvt_f32_f16_e32 v33, v20                                 // 0000007B9848: 7E421714
	s_branch 65313                                             // 0000007B984C: BFA0FF21 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4d4>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007B9850: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007B9854: BF8700B9
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007B9858: 8C7E047E
	.long 0xd71f0001                                           // 0000007B985C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007B9860: 020100C1
	s_mov_b32 s2, exec_lo                                      // 0000007B9864: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007B9868: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 0000007B986C: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 0000007B9870: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007B9874: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007B9878: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007B987C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007B9880: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 0000007B9884: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007B9888: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007B988C: BF870002
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000007B9890: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007B9894: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000007B9898: 02080901
	ds_bpermute_b32 v2, v2, v27                                // 0000007B989C: DACC0000 02001B02
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007B98A4: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000007B98A8: BF89FC07
	v_add_f32_e32 v2, v27, v2                                  // 0000007B98AC: 0604051B
	ds_bpermute_b32 v3, v3, v2                                 // 0000007B98B0: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 0000007B98B8: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000007B98BC: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000007B98C0: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 0000007B98C8: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B98CC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007B98D0: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000007B98D4: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007B98D8: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000007B98DC: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000007B98E0: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000007B98E4: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 0000007B98EC: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007B98F0: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007B98F4: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 0000007B98F8: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 0000007B98FC: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 0000007B9904: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 0000007B9908: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v23                                   // 0000007B9910: 7D942E80
	s_cbranch_execz 8                                          // 0000007B9914: BFA50008 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x938>
	v_lshlrev_b32_e32 v3, 2, v22                               // 0000007B9918: 30062C82
	s_waitcnt lgkmcnt(0)                                       // 0000007B991C: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000007B9920: 06020501
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007B9924: BF870002
	v_lshl_or_b32 v3, v21, 3, v3                               // 0000007B9928: D6560003 040D0715
	ds_store_b32 v3, v1 offset:1024                            // 0000007B9930: D8340400 00000103
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007B9938: 8C7E027E
	v_or_b32_e32 v1, s20, v0                                   // 0000007B993C: 38020014
	s_waitcnt lgkmcnt(0)                                       // 0000007B9940: BF89FC07
	v_mov_b32_e32 v2, s21                                      // 0000007B9944: 7E040215
	.long 0xd44c0002                                           // 0000007B9948: D44C0002
	v_cndmask_b32_e32 v1, 4, v0, vcc_lo                        // 0000007B994C: 02020084
	s_waitcnt vmcnt(0)                                         // 0000007B9950: BF8903F7
	s_barrier                                                  // 0000007B9954: BFBD0000
	buffer_gl0_inv                                             // 0000007B9958: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007B9960: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 0000007B9964: 8B026A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007B9968: BF870009
	s_and_saveexec_b32 s3, s2                                  // 0000007B996C: BE832002
	s_cbranch_execz 62                                         // 0000007B9970: BFA5003E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xa6c>
	v_lshlrev_b32_e32 v0, 3, v0                                // 0000007B9974: 30000083
	s_load_b32 s0, s[0:1], 0x48                                // 0000007B9978: F4000000 F8000048
	ds_load_b64 v[3:4], v0 offset:1024                         // 0000007B9980: D9D80400 03000000
	s_waitcnt lgkmcnt(0)                                       // 0000007B9988: BF89FC07
	v_add_f32_e32 v0, 0, v3                                    // 0000007B998C: 06000680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B9990: BF870091
	v_add_f32_e32 v0, v0, v4                                   // 0000007B9994: 06000900
	v_bfe_u32 v3, v0, 16, 1                                    // 0000007B9998: D6100003 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B99A0: BF870091
	v_add3_u32 v0, v0, v3, 0x7fff                              // 0000007B99A4: D6550000 03FE0700 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007B99B0: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B99B8: BF870091
	v_mul_f32_e32 v0, s0, v0                                   // 0000007B99BC: 10000000
	v_mul_f32_e32 v3, 0xbfb8aa3b, v0                           // 0000007B99C0: 100600FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007B99C8: BF870291
	v_exp_f32_e32 v3, v3                                       // 0000007B99CC: 7E064B03
	v_add_f32_e32 v3, 1.0, v3                                  // 0000007B99D0: 060606F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007B99D4: BF870121
	v_div_scale_f32 v4, null, v3, v3, v0                       // 0000007B99D8: D6FC7C04 04020703
	v_div_scale_f32 v7, vcc_lo, v0, v3, v0                     // 0000007B99E0: D6FC6A07 04020700
	v_rcp_f32_e32 v5, v4                                       // 0000007B99E8: 7E0A5504
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B99EC: BF870095
	v_fma_f32 v6, -v4, v5, 1.0                                 // 0000007B99F0: D6130006 23CA0B04
	v_fmac_f32_e32 v5, v6, v5                                  // 0000007B99F8: 560A0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B99FC: BF870091
	v_mul_f32_e32 v6, v7, v5                                   // 0000007B9A00: 100C0B07
	v_fma_f32 v8, -v4, v6, v7                                  // 0000007B9A04: D6130008 241E0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B9A0C: BF870091
	v_fmac_f32_e32 v6, v8, v5                                  // 0000007B9A10: 560C0B08
	v_fma_f32 v4, -v4, v6, v7                                  // 0000007B9A14: D6130004 241E0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B9A1C: BF870091
	v_div_fmas_f32 v4, v4, v5, v6                              // 0000007B9A20: D6370004 041A0B04
	v_div_fixup_f32 v3, v4, v3, v0                             // 0000007B9A28: D6270003 04020704
	.long 0xd73c0000                                           // 0000007B9A30: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000007B9A34: 02020281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007B9A38: BF870112
	v_bfe_u32 v4, v3, 16, 1                                    // 0000007B9A3C: D6100004 02052103
	.long 0xd7006a00                                           // 0000007B9A44: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007B9A48: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007B9A4C: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007B9A50: D5207C01 01AA0209
	v_add3_u32 v2, v3, v4, 0x7fff                              // 0000007B9A58: D6550002 03FE0903 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007B9A64: DC960000 007C0200
	s_endpgm                                                   // 0000007B9A6C: BFB00000
		...

