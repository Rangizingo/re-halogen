0000000000364d00 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 000000364D00: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 000000364D04: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 000000364D0C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 000000364D14: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 000000364D1C: F4000180 F8000118
	v_lshrrev_b32_e32 v5, 5, v0                                // 000000364D24: 320A0085
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v2, 0              // 000000364D28: CA100080 43020080
	v_dual_mov_b32 v62, 0 :: v_dual_mov_b32 v83, 0             // 000000364D30: CA100080 3E520080
	v_dual_mov_b32 v63, 0 :: v_dual_and_b32 v68, 31, v0        // 000000364D38: CA240080 3F44009F
	s_waitcnt lgkmcnt(0)                                       // 000000364D40: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 000000364D44: BF028103
	s_cselect_b32 s7, -1, 0                                    // 000000364D48: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 000000364D4C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 000000364D50: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000364D54: BF870009
	s_and_b32 s4, s7, s4                                       // 000000364D58: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 000000364D5C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 000000364D60: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 000000364D68: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 000000364D6C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 000000364D70: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000364D74: BF870009
	s_and_b32 s4, s7, s5                                       // 000000364D78: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 000000364D7C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 000000364D80: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 000000364D84: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000364D88: BF030602
	s_cselect_b32 s6, -1, 0                                    // 000000364D8C: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000364D90: BF870009
	s_and_b32 s3, s3, s6                                       // 000000364D94: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 000000364D98: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 000000364D9C: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 000000364DA0: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 000000364DA4: 98030483
	s_load_b128 s[4:7], s[0:1], 0x128                          // 000000364DA8: F4080100 F8000128
	s_mulk_i32 s3, 0x48                                        // 000000364DB0: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000364DB4: BF870009
	s_add_u32 s10, s0, s3                                      // 000000364DB8: 800A0300
	s_addc_u32 s11, s1, 0                                      // 000000364DBC: 820B8001
	s_clause 0x2                                               // 000000364DC0: BF850002
	s_load_b64 s[8:9], s[10:11], 0x30                          // 000000364DC4: F4040205 F8000030
	s_load_b32 s12, s[10:11], 0x40                             // 000000364DCC: F4000305 F8000040
	s_load_b64 s[0:1], s[10:11], null                          // 000000364DD4: F4040005 F8000000
	s_waitcnt lgkmcnt(0)                                       // 000000364DDC: BF89FC07
	.long 0xd4540003                                           // 000000364DE0: D4540003
	v_cndmask_b32_e32 v0, s8, v136, vcc_lo                     // 000000364DE4: 02011008
	s_delay_alu instid0(VALU_DEP_1)                            // 000000364DE8: BF870001
	v_cndmask_b32_e64 v66, 0, 1, s3                            // 000000364DEC: D5010042 000D0280
	s_and_b32 s3, s3, exec_lo                                  // 000000364DF4: 8B037E03
	s_cselect_b32 s14, 4, 8                                    // 000000364DF8: 980E8884
	s_cselect_b32 s15, 2, 3                                    // 000000364DFC: 980F8382
	v_cvt_f32_ubyte0_e32 v1, s14                               // 000000364E00: 7E02220E
	s_ashr_i32 s18, s7, 31                                     // 000000364E04: 86129F07
	s_sub_i32 s2, s2, s12                                      // 000000364E08: 81820C02
	s_lshr_b32 s12, s18, 27                                    // 000000364E0C: 850C9B12
	s_add_i32 s19, s14, -1                                     // 000000364E10: 8113C10E
	v_rcp_iflag_f32_e32 v3, v1                                 // 000000364E14: 7E065701
	s_add_u32 s12, s6, s12                                     // 000000364E18: 800C0C06
	s_mov_b32 s3, 0                                            // 000000364E1C: BE830080
	v_lshrrev_b32_e32 v69, s15, v5                             // 000000364E20: 328A0A0F
	.long 0xd73c0039                                           // 000000364E24: D73C0039
	v_cndmask_b32_e32 v0, v66, v2, vcc_lo                      // 000000364E28: 02000542
	v_mov_b32_e32 v1, 0                                        // 000000364E2C: 7E020280
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000364E30: BF870195
	v_readfirstlane_b32 s13, v3                                // 000000364E34: 7E1A0503
	.long 0xd7006a03                                           // 000000364E38: D7006A03
	v_cndmask_b32_e32 v1, v57, v69, vcc_lo                     // 000000364E3C: 02028B39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_2)// 000000364E40: BF870531
	v_add_co_ci_u32_e64 v4, null, 0, v58, vcc_lo               // 000000364E44: D5207C04 01AA7480
	s_mul_f32 s13, s13, 0x4f7ffffe                             // 000000364E4C: A20DFF0D 4F7FFFFE
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[3:4]                    // 000000364E54: 7CA80608
	s_cvt_u32_f32 s20, s13                                     // 000000364E58: BE94670D
	s_addc_u32 s13, s7, 0                                      // 000000364E5C: 820D8007
	s_sub_i32 s21, 0, s14                                      // 000000364E60: 81950E80
	s_lshr_b64 s[16:17], s[12:13], 5                           // 000000364E64: 8590850C
	s_mul_i32 s21, s21, s20                                    // 000000364E68: 96151415
	s_add_i32 s12, s19, s16                                    // 000000364E6C: 810C1013
	s_mul_hi_u32 s13, s20, s21                                 // 000000364E70: 968D1514
	s_abs_i32 s17, s12                                         // 000000364E74: BE91150C
	s_add_i32 s20, s20, s13                                    // 000000364E78: 81140D14
	s_ashr_i32 s3, s12, 31                                     // 000000364E7C: 86039F0C
	s_mul_hi_u32 s13, s17, s20                                 // 000000364E80: 968D1411
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_and_b32 v70, s19, v5// 000000364E84: CA640680 03460A13
	s_mul_i32 s2, s13, s14                                     // 000000364E8C: 96020E0D
	s_add_i32 s12, s13, 1                                      // 000000364E90: 810C810D
	s_sub_i32 s2, s17, s2                                      // 000000364E94: 81820211
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 000000364E98: 02080880
	s_sub_i32 s17, s2, s14                                     // 000000364E9C: 81910E02
	s_cmp_ge_u32 s2, s14                                       // 000000364EA0: BF090E02
	s_cselect_b32 s12, s12, s13                                // 000000364EA4: 980C0D0C
	s_cselect_b32 s2, s17, s2                                  // 000000364EA8: 98020211
	s_add_i32 s13, s12, 1                                      // 000000364EAC: 810D810C
	s_cmp_ge_u32 s2, s14                                       // 000000364EB0: BF090E02
	s_cselect_b32 s2, s13, s12                                 // 000000364EB4: 98020C0D
	s_lshr_b32 s12, s7, 31                                     // 000000364EB8: 850C9F07
	s_xor_b32 s2, s2, s3                                       // 000000364EBC: 8D020302
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000364EC0: BF870009
	s_sub_i32 s17, s2, s3                                      // 000000364EC4: 81910302
	s_add_u32 s2, s6, s12                                      // 000000364EC8: 80020C06
	s_addc_u32 s3, s7, 0                                       // 000000364ECC: 82038007
	s_lshr_b32 s19, s18, 30                                    // 000000364ED0: 85139E12
	s_ashr_i64 s[12:13], s[2:3], 1                             // 000000364ED4: 868C8102
	s_add_u32 s2, s6, s19                                      // 000000364ED8: 80021306
	s_addc_u32 s3, s7, 0                                       // 000000364EDC: 82038007
	s_lshr_b32 s18, s18, 28                                    // 000000364EE0: 85129C12
	s_ashr_i64 s[2:3], s[2:3], 2                               // 000000364EE4: 86828202
	s_add_u32 s18, s6, s18                                     // 000000364EE8: 80121206
	s_addc_u32 s19, s7, 0                                      // 000000364EEC: 82138007
	.long 0xd72c0005                                           // 000000364EF0: D72C0005
	v_cndmask_b32_e32 v0, v70, v17, vcc_lo                     // 000000364EF4: 02002346
	s_ashr_i64 s[18:19], s[18:19], 4                           // 000000364EF8: 86928412
	s_add_u32 s20, s2, s12                                     // 000000364EFC: 80140C02
	s_addc_u32 s21, s3, s13                                    // 000000364F00: 82150D03
	s_add_u32 s18, s20, s18                                    // 000000364F04: 80121214
	s_addc_u32 s19, s21, s19                                   // 000000364F08: 82131315
	s_add_u32 s18, s18, 15                                     // 000000364F0C: 80128F12
	s_addc_u32 s19, s19, 0                                     // 000000364F10: 82138013
	v_add_nc_u32_e32 v6, s17, v5                               // 000000364F14: 4A0C0A11
	s_ashr_i32 s20, s19, 31                                    // 000000364F18: 86149F13
	v_add_nc_u32_e32 v71, v5, v68                              // 000000364F1C: 4A8E8905
	s_lshr_b32 s20, s20, 28                                    // 000000364F20: 85149C14
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000364F24: BF870009
	s_add_u32 s17, s18, s20                                    // 000000364F28: 80111412
	s_addc_u32 s18, s19, 0                                     // 000000364F2C: 82128013
	s_and_b32 s17, s17, -16                                    // 000000364F30: 8B11D011
	.long 0xd72c0007                                           // 000000364F34: D72C0007
	v_cndmask_b32_e32 v1, s18, v3, vcc_lo                      // 000000364F38: 02020612
	v_mad_u64_u32 v[59:60], null, s17, v3, s[0:1]              // 000000364F3C: D6FE7C3B 00020611
	v_mov_b32_e32 v3, 0                                        // 000000364F44: 7E060280
	.long 0xd72c0008                                           // 000000364F48: D72C0008
	v_cndmask_b32_e32 v1, s17, v4, vcc_lo                      // 000000364F4C: 02020811
	v_min_i32_e32 v72, s16, v6                                 // 000000364F50: 22900C10
	v_mov_b32_e32 v4, 0                                        // 000000364F54: 7E080280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000364F58: BF870212
	v_cmp_lt_i32_e32 vcc_lo, v71, v72                          // 000000364F5C: 7C829147
	v_add3_u32 v73, v7, v60, v8                                // 000000364F60: D6550049 04227907
	s_and_saveexec_b32 s1, vcc_lo                              // 000000364F68: BE81206A
	s_cbranch_execz 39                                         // 000000364F6C: BFA50027 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x30c>
	v_lshlrev_b32_e32 v1, 4, v71                               // 000000364F70: 30028E84
	v_lshlrev_b32_e32 v4, 1, v71                               // 000000364F74: 30088E81
	v_lshlrev_b32_e32 v3, 3, v71                               // 000000364F78: 30068E83
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000364F7C: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000364F80: 3404029F
	.long 0xd7000001                                           // 000000364F84: D7000001
	v_cndmask_b32_e32 v1, v59, v1, vcc_lo                      // 000000364F88: 0202033B
	v_and_b32_e32 v4, -4, v4                                   // 000000364F8C: 360808C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000364F90: BF870214
	v_ashrrev_i32_e32 v8, 31, v3                               // 000000364F94: 3410069F
	v_add_co_ci_u32_e64 v2, null, v73, v2, s0                  // 000000364F98: D5207C02 00020549
	.long 0xd7000006                                           // 000000364FA0: D7000006
	v_cndmask_b32_e32 v0, v59, v12, vcc_lo                     // 000000364FA4: 0200193B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000364FA8: BF8701A1
	v_add_co_ci_u32_e64 v7, null, s13, v73, s0                 // 000000364FAC: D5207C07 0002920D
	v_ashrrev_i32_e32 v11, 31, v4                              // 000000364FB4: 3416089F
	.long 0xd7000009                                           // 000000364FB8: D7000009
	v_cndmask_b32_e32 v0, v6, v2, vcc_lo                       // 000000364FBC: 02000506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000364FC0: BF8700A1
	v_add_co_ci_u32_e64 v10, null, s3, v7, s0                  // 000000364FC4: D5207C0A 00020E03
	.long 0xd7000006                                           // 000000364FCC: D7000006
	v_cndmask_b32_e32 v1, v6, v3, vcc_lo                       // 000000364FD0: 02020706
	v_add_co_ci_u32_e64 v7, null, v7, v8, s0                   // 000000364FD4: D5207C07 00021107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000364FDC: BF870094
	.long 0xd7000008                                           // 000000364FE0: D7000008
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 000000364FE4: 02020909
	v_add_co_ci_u32_e64 v9, null, v10, v11, s0                 // 000000364FE8: D5207C09 0002170A
	s_clause 0x2                                               // 000000364FF0: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 000000364FF4: DC5E0000 017C0001
	global_load_b64 v[62:63], v[6:7], off                      // 000000364FFC: DC560000 3E7C0006
	global_load_b32 v83, v[8:9], off                           // 000000365004: DC520000 537C0008
	s_or_b32 exec_lo, exec_lo, s1                              // 00000036500C: 8C7E017E
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v75, 0             // 000000365010: CA100080 4A4A0080
	s_and_saveexec_b32 s1, vcc_lo                              // 000000365018: BE81206A
	s_cbranch_execz 716                                        // 00000036501C: BFA502CC <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0xe50>
	.long 0xd7006a4c                                           // 000000365020: D7006A4C
	v_cndmask_b32_e32 v0, v59, v12, vcc_lo                     // 000000365024: 0200193B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000365028: BF870231
	v_add_co_ci_u32_e64 v77, null, s13, v73, vcc_lo            // 00000036502C: D5207C4D 01AA920D
	v_dual_mov_b32 v67, 0 :: v_dual_lshlrev_b32 v6, 5, v68     // 000000365034: CA220080 43068885
	v_dual_mov_b32 v74, 0 :: v_dual_add_nc_u32 v7, 32, v71     // 00000036503C: CA200080 4A068EA0
	.long 0xd7006a4e                                           // 000000365044: D7006A4E
	v_cndmask_b32_e32 v0, v76, v2, vcc_lo                      // 000000365048: 0200054C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000036504C: BF870211
	v_add_co_ci_u32_e64 v79, null, s3, v77, vcc_lo             // 000000365050: D5207C4F 01AA9A03
	v_lshl_add_u32 v60, v5, 5, v6                              // 000000365058: D646003C 04190B05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000365060: BF870004
	v_dual_mov_b32 v75, 0 :: v_dual_lshlrev_b32 v80, 4, v7     // 000000365064: CA220080 4B500E84
	s_waitcnt vmcnt(0)                                         // 00000036506C: BF8903F7
	v_dual_mov_b32 v84, v83 :: v_dual_lshlrev_b32 v81, 3, v7   // 000000365070: CA220153 54500E83
	v_lshlrev_b32_e32 v82, 1, v7                               // 000000365078: 30A40E81
	s_lshl_b64 s[2:3], s[6:7], 2                               // 00000036507C: 84828206
	s_mov_b32 s12, 0                                           // 000000365080: BE8C0080
	s_lshl_b64 s[6:7], s[6:7], 1                               // 000000365084: 84868106
	s_branch 649                                               // 000000365088: BFA00289 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0xdb0>
	s_or_b32 exec_lo, exec_lo, s13                             // 00000036508C: 8C7E0D7E
	v_ashrrev_i32_e32 v61, 31, v60                             // 000000365090: 347A789F
	v_lshlrev_b32_e32 v85, 4, v62                              // 000000365094: 30AA7C84
	v_lshlrev_b32_e32 v86, 2, v62                              // 000000365098: 30AC7C82
	v_lshrrev_b32_e32 v87, 4, v1                               // 00000036509C: 32AE0284
	v_lshrrev_b32_e32 v88, 8, v1                               // 0000003650A0: 32B00288
	.long 0xd73c0009                                           // 0000003650A4: D73C0009
	v_cndmask_b32_e32 v1, 1, v60, vcc_lo                       // 0000003650A8: 02027881
	v_and_b32_e32 v85, 48, v85                                 // 0000003650AC: 36AAAAB0
	v_lshrrev_b32_e32 v89, 2, v62                              // 0000003650B0: 32B27C82
	v_and_b32_e32 v90, 48, v62                                 // 0000003650B4: 36B47CB0
	v_and_b32_e32 v86, 48, v86                                 // 0000003650B8: 36ACACB0
	v_lshrrev_b32_e32 v91, 12, v1                              // 0000003650BC: 32B6028C
	.long 0xd700002d                                           // 0000003650C0: D700002D
	v_cndmask_b32_e32 v1, s4, v9, vcc_lo                       // 0000003650C4: 02021204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003650C8: BF8701A1
	v_add_co_ci_u32_e64 v46, null, s5, v10, s0                 // 0000003650CC: D5207C2E 00021405
	v_and_or_b32 v85, v1, 15, v85                              // 0000003650D4: D6570055 05551F01
	.long 0xd7000031                                           // 0000003650DC: D7000031
	v_cndmask_b32_e32 v0, v45, v6, vcc_lo                      // 0000003650E0: 02000D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003650E4: BF8700A1
	v_add_co_ci_u32_e64 v50, null, s7, v46, s0                 // 0000003650E8: D5207C32 00025C07
	.long 0xd7000035                                           // 0000003650F0: D7000035
	v_cndmask_b32_e32 v0, v45, v2, vcc_lo                      // 0000003650F4: 0200052D
	v_add_co_ci_u32_e64 v54, null, s3, v46, s0                 // 0000003650F8: D5207C36 00025C03
	s_clause 0xb                                               // 000000365100: BF85000B
	global_load_b128 v[9:12], v[45:46], off                    // 000000365104: DC5E0000 097C002D
	global_load_b128 v[13:16], v[49:50], off                   // 00000036510C: DC5E0000 0D7C0031
	global_load_b128 v[17:20], v[53:54], off                   // 000000365114: DC5E0000 117C0035
	global_load_b128 v[21:24], v[45:46], off offset:16         // 00000036511C: DC5E0010 157C002D
	global_load_b128 v[25:28], v[49:50], off offset:16         // 000000365124: DC5E0010 197C0031
	global_load_b128 v[29:32], v[53:54], off offset:16         // 00000036512C: DC5E0010 1D7C0035
	global_load_b128 v[33:36], v[45:46], off offset:32         // 000000365134: DC5E0020 217C002D
	global_load_b128 v[37:40], v[49:50], off offset:32         // 00000036513C: DC5E0020 257C0031
	global_load_b128 v[41:44], v[53:54], off offset:32         // 000000365144: DC5E0020 297C0035
	global_load_b128 v[45:48], v[45:46], off offset:48         // 00000036514C: DC5E0030 2D7C002D
	global_load_b128 v[49:52], v[49:50], off offset:48         // 000000365154: DC5E0030 317C0031
	global_load_b128 v[53:56], v[53:54], off offset:48         // 00000036515C: DC5E0030 357C0035
	v_and_b32_e32 v89, 48, v89                                 // 000000365164: 36B2B2B0
	v_and_or_b32 v86, v87, 15, v86                             // 000000365168: D6570056 05591F57
	v_cvt_f32_ubyte0_e32 v85, v85                              // 000000365170: 7EAA2355
	v_and_or_b32 v87, v88, 15, v90                             // 000000365174: D6570057 05691F58
	.long 0x7f7a3880                                           // 00000036517C: 7F7A3880
	v_and_or_b32 v89, v91, 15, v89                             // 000000365180: D6570059 05651F5B
	v_cvt_f32_ubyte0_e32 v86, v86                              // 000000365188: 7EAC2356
	v_fma_mix_f32 v85, v85, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036518C: CC206055 154EA755
	v_cvt_f32_ubyte0_e32 v87, v87                              // 000000365194: 7EAE2357
	v_lshrrev_b32_e32 v93, 4, v62                              // 000000365198: 32BA7C84
	v_cvt_f32_ubyte0_e32 v89, v89                              // 00000036519C: 7EB22359
	v_fma_mix_f32 v86, v86, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003651A0: CC206056 154EA756
	v_bfe_u32 v91, v85, 16, 1                                  // 0000003651A8: D610005B 02052155
	v_fma_mix_f32 v87, v87, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003651B0: CC206057 154EA757
	v_lshrrev_b32_e32 v92, 8, v62                              // 0000003651B8: 32B87C88
	v_fma_mix_f32 v89, v89, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003651BC: CC206059 154EA759
	v_bfe_u32 v109, v86, 16, 1                                 // 0000003651C4: D610006D 02052156
	v_add3_u32 v85, v85, v91, 0x7fff                           // 0000003651CC: D6550055 03FEB755 00007FFF
	v_bfe_u32 v91, v87, 16, 1                                  // 0000003651D8: D610005B 02052157
	v_lshrrev_b32_e32 v95, 6, v62                              // 0000003651E0: 32BE7C86
	v_bfe_u32 v111, v89, 16, 1                                 // 0000003651E4: D610006F 02052159
	v_add3_u32 v86, v86, v109, 0x7fff                          // 0000003651EC: D6550056 03FEDB56 00007FFF
	.long 0x7e7a39d5                                           // 0000003651F8: 7E7A39D5
	v_add3_u32 v85, v87, v91, 0x7fff                           // 0000003651FC: D6550055 03FEB757 00007FFF
	v_and_b32_e32 v93, 48, v93                                 // 000000365208: 36BABAB0
	v_add3_u32 v89, v89, v111, 0x7fff                          // 00000036520C: D6550059 03FEDF59 00007FFF
	v_lshrrev_b32_e32 v94, 20, v1                              // 000000365218: 32BC0294
	v_and_or_b32 v86, 0xffff0000, v86, v61                     // 00000036521C: D6570056 04F6ACFF FFFF0000
	.long 0x7e7a39d5                                           // 000000365228: 7E7A39D5
	v_lshrrev_b32_e32 v96, 24, v1                              // 00000036522C: 32C00298
	v_and_b32_e32 v95, 48, v95                                 // 000000365230: 36BEBEB0
	v_and_b32_e32 v92, 48, v92                                 // 000000365234: 36B8B8B0
	v_lshrrev_b32_e32 v97, 28, v1                              // 000000365238: 32C2029C
	v_and_or_b32 v89, 0xffff0000, v89, v61                     // 00000036523C: D6570059 04F6B2FF FFFF0000
	.long 0x7e7a3981                                           // 000000365248: 7E7A3981
	v_lshrrev_b32_e32 v98, 10, v62                             // 00000036524C: 32C47C8A
	v_and_or_b32 v94, v94, 15, v95                             // 000000365250: D657005E 057D1F5E
	v_and_or_b32 v92, v96, 15, v92                             // 000000365258: D657005C 05711F60
	v_lshrrev_b32_e32 v99, 8, v2                               // 000000365260: 32C60488
	v_and_or_b32 v93, v61, 15, v93                             // 000000365264: D657005D 05751F3D
	v_and_or_b32 v96, v98, 48, v97                             // 00000036526C: D6570060 05856162
	v_cvt_f32_ubyte0_e32 v94, v94                              // 000000365274: 7EBC235E
	v_cvt_f32_ubyte0_e32 v92, v92                              // 000000365278: 7EB8235C
	v_lshrrev_b32_e32 v102, 18, v62                            // 00000036527C: 32CC7C92
	v_cvt_f32_ubyte0_e32 v93, v93                              // 000000365280: 7EBA235D
	v_cvt_f32_ubyte0_e32 v96, v96                              // 000000365284: 7EC02360
	v_fma_mix_f32 v94, v94, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000365288: CC20605E 154EA75E
	v_fma_mix_f32 v92, v92, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000365290: CC20605C 154EA75C
	v_lshrrev_b32_e32 v101, 12, v2                             // 000000365298: 32CA048C
	v_fma_mix_f32 v93, v93, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036529C: CC20605D 154EA75D
	v_fma_mix_f32 v96, v96, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003652A4: CC206060 154EA760
	v_bfe_u32 v117, v94, 16, 1                                 // 0000003652AC: D6100075 0205215E
	v_lshrrev_b32_e32 v87, 8, v3                               // 0000003652B4: 32AE0688
	v_and_b32_e32 v91, 48, v63                                 // 0000003652B8: 36B67EB0
	v_bfe_u32 v98, v93, 16, 1                                  // 0000003652BC: D6100062 0205215D
	v_bfe_u32 v119, v96, 16, 1                                 // 0000003652C4: D6100077 02052160
	v_add3_u32 v94, v94, v117, 0x7fff                          // 0000003652CC: D655005E 03FEEB5E 00007FFF
	v_and_b32_e32 v102, 48, v102                               // 0000003652D8: 36CCCCB0
	v_and_or_b32 v87, v87, 15, v91                             // 0000003652DC: D6570057 056D1F57
	v_add3_u32 v93, v93, v98, 0x7fff                           // 0000003652E4: D655005D 03FEC55D 00007FFF
	v_bfe_u32 v98, v92, 16, 1                                  // 0000003652F0: D6100062 0205215C
	v_add3_u32 v96, v96, v119, 0x7fff                          // 0000003652F8: D6550060 03FEEF60 00007FFF
	v_and_or_b32 v91, v101, 15, v102                           // 000000365304: D657005B 05991F65
	v_lshrrev_b32_e32 v107, 28, v2                             // 00000036530C: 32D6049C
	.long 0x7e7a39dd                                           // 000000365310: 7E7A39DD
	v_add3_u32 v92, v92, v98, 0x7fff                           // 000000365314: D655005C 03FEC55C 00007FFF
	v_lshrrev_b32_e32 v88, 26, v62                             // 000000365320: 32B07C9A
	v_cvt_f32_ubyte0_e32 v91, v91                              // 000000365324: 7EB6235B
	v_lshrrev_b32_e32 v109, 28, v3                             // 000000365328: 32DA069C
	v_and_or_b32 v94, 0xffff0000, v94, v61                     // 00000036532C: D657005E 04F6BCFF FFFF0000
	.long 0x7e7a39dc                                           // 000000365338: 7E7A39DC
	v_lshrrev_b32_e32 v111, 10, v63                            // 00000036533C: 32DE7E8A
	v_and_or_b32 v88, v88, 48, v107                            // 000000365340: D6570058 05AD6158
	v_fma_mix_f32 v91, v91, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000365348: CC20605B 154EA75B
	v_lshrrev_b32_e32 v100, 20, v62                            // 000000365350: 32C87C94
	v_and_or_b32 v96, 0xffff0000, v96, v61                     // 000000365354: D6570060 04F6C0FF FFFF0000
	.long 0x7e7a39be                                           // 000000365360: 7E7A39BE
	v_and_or_b32 v101, v111, 48, v109                          // 000000365364: D6570065 05B5616F
	v_bfe_u32 v111, v91, 16, 1                                 // 00000036536C: D610006F 0205215B
	v_lshrrev_b32_e32 v103, 24, v62                            // 000000365374: 32CE7C98
	v_lshrrev_b32_e32 v105, 22, v62                            // 000000365378: 32D27C96
	v_and_b32_e32 v124, 48, v61                                // 00000036537C: 36F87AB0
	v_lshlrev_b32_e32 v90, 4, v63                              // 000000365380: 30B47E84
	v_add3_u32 v91, v91, v111, 0x7fff                          // 000000365384: D655005B 03FEDF5B 00007FFF
	v_lshrrev_b32_e32 v1, 2, v63                               // 000000365390: 32027E82
	v_and_b32_e32 v100, 48, v100                               // 000000365394: 36C8C8B0
	v_and_or_b32 v99, v99, 15, v124                            // 000000365398: D6570063 05F11F63
	v_lshrrev_b32_e32 v104, 20, v2                             // 0000003653A0: 32D00494
	v_lshrrev_b32_e32 v106, 24, v2                             // 0000003653A4: 32D40498
	v_lshlrev_b32_e32 v110, 2, v63                             // 0000003653A8: 30DC7E82
	v_lshrrev_b32_e32 v85, 12, v3                              // 0000003653AC: 32AA068C
	v_cvt_f32_ubyte0_e32 v99, v99                              // 0000003653B0: 7EC62363
	v_and_b32_e32 v102, 48, v105                               // 0000003653B4: 36CCD2B0
	v_and_b32_e32 v103, 48, v103                               // 0000003653B8: 36CECEB0
	v_and_b32_e32 v1, 48, v1                                   // 0000003653BC: 360202B0
	v_and_b32_e32 v90, 48, v90                                 // 0000003653C0: 36B4B4B0
	v_fma_mix_f32 v99, v99, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003653C4: CC206063 154EA763
	v_lshrrev_b32_e32 v108, 4, v3                              // 0000003653CC: 32D80684
	v_and_b32_e32 v105, 48, v110                               // 0000003653D0: 36D2DCB0
	v_and_or_b32 v102, v104, 15, v102                          // 0000003653D4: D6570066 05991F68
	v_and_or_b32 v103, v106, 15, v103                          // 0000003653DC: D6570067 059D1F6A
	v_bfe_u32 v107, v99, 16, 1                                 // 0000003653E4: D610006B 02052163
	v_and_or_b32 v1, v85, 15, v1                               // 0000003653EC: D6570001 04051F55
	v_and_or_b32 v85, v3, 15, v90                              // 0000003653F4: D6570055 05691F03
	v_and_or_b32 v104, v108, 15, v105                          // 0000003653FC: D6570068 05A51F6C
	v_cvt_f32_ubyte0_e32 v88, v88                              // 000000365404: 7EB02358
	v_add3_u32 v99, v99, v107, 0x7fff                          // 000000365408: D6550063 03FED763 00007FFF
	v_cvt_f32_ubyte0_e32 v87, v87                              // 000000365414: 7EAE2357
	v_cvt_f32_ubyte0_e32 v85, v85                              // 000000365418: 7EAA2355
	v_cvt_f32_ubyte0_e32 v1, v1                                // 00000036541C: 7E022301
	v_fma_mix_f32 v88, v88, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000365420: CC206058 154EA758
	.long 0x7e7a39e3                                           // 000000365428: 7E7A39E3
	v_fma_mix_f32 v87, v87, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036542C: CC206057 154EA757
	v_fma_mix_f32 v85, v85, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000365434: CC206055 154EA755
	v_fma_mix_f32 v1, v1, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036543C: CC206001 154EA701
	v_bfe_u32 v105, v88, 16, 1                                 // 000000365444: D6100069 02052158
	v_and_or_b32 v91, 0xffff0000, v91, v61                     // 00000036544C: D657005B 04F6B6FF FFFF0000
	.long 0x7e7a3982                                           // 000000365458: 7E7A3982
	v_lshrrev_b32_e32 v115, 4, v63                             // 00000036545C: 32E67E84
	v_lshrrev_b32_e32 v97, 12, v62                             // 000000365460: 32C27C8C
	v_add3_u32 v88, v88, v105, 0x7fff                          // 000000365464: D6550058 03FED358 00007FFF
	v_lshrrev_b32_e32 v116, 14, v62                            // 000000365470: 32E87C8E
	v_and_or_b32 v100, v61, 15, v100                           // 000000365474: D6570064 05911F3D
	v_lshrrev_b32_e32 v113, 6, v63                             // 00000036547C: 32E27E86
	v_lshrrev_b32_e32 v114, 8, v63                             // 000000365480: 32E47E88
	v_lshrrev_b32_e32 v122, 4, v2                              // 000000365484: 32F40484
	v_and_b32_e32 v107, 48, v115                               // 000000365488: 36D6E6B0
	v_cvt_f32_ubyte0_e32 v90, v100                             // 00000036548C: 7EB42364
	v_cvt_f32_ubyte0_e32 v100, v102                            // 000000365490: 7EC82366
	v_cvt_f32_ubyte0_e32 v102, v103                            // 000000365494: 7ECC2367
	v_cvt_f32_ubyte0_e32 v103, v104                            // 000000365498: 7ECE2368
	v_and_b32_e32 v97, 48, v97                                 // 00000036549C: 36C2C2B0
	v_fma_mix_f32 v90, v90, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003654A0: CC20605A 154EA75A
	v_fma_mix_f32 v100, v100, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003654A8: CC206064 154EA764
	v_fma_mix_f32 v102, v102, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003654B0: CC206066 154EA766
	v_fma_mix_f32 v103, v103, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003654B8: CC206067 154EA767
	v_and_b32_e32 v99, 48, v116                                // 0000003654C0: 36C6E8B0
	v_bfe_u32 v104, v90, 16, 1                                 // 0000003654C4: D6100068 0205215A
	v_bfe_u32 v106, v100, 16, 1                                // 0000003654CC: D610006A 02052164
	v_lshrrev_b32_e32 v112, 20, v3                             // 0000003654D4: 32E00694
	v_lshrrev_b32_e32 v95, 24, v3                              // 0000003654D8: 32BE0698
	v_and_b32_e32 v109, 48, v113                               // 0000003654DC: 36DAE2B0
	v_add3_u32 v90, v90, v104, 0x7fff                          // 0000003654E0: D655005A 03FED15A 00007FFF
	v_bfe_u32 v104, v102, 16, 1                                // 0000003654EC: D6100068 02052166
	v_add3_u32 v100, v100, v106, 0x7fff                        // 0000003654F4: D6550064 03FED564 00007FFF
	v_and_b32_e32 v110, 48, v114                               // 000000365500: 36DCE4B0
	v_and_or_b32 v2, v2, 15, v97                               // 000000365504: D6570002 05851F02
	.long 0x7e7a39da                                           // 00000036550C: 7E7A39DA
	v_add3_u32 v90, v102, v104, 0x7fff                         // 000000365510: D655005A 03FED166 00007FFF
	v_bfe_u32 v102, v85, 16, 1                                 // 00000036551C: D6100066 02052155
	v_bfe_u32 v104, v103, 16, 1                                // 000000365524: D6100068 02052167
	v_and_or_b32 v97, v122, 15, v99                            // 00000036552C: D6570061 058D1F7A
	v_and_or_b32 v100, 0xffff0000, v100, v61                   // 000000365534: D6570064 04F6C8FF FFFF0000
	.long 0x7e7a39da                                           // 000000365540: 7E7A39DA
	v_add3_u32 v85, v85, v102, 0x7fff                          // 000000365544: D6550055 03FECD55 00007FFF
	v_bfe_u32 v90, v87, 16, 1                                  // 000000365550: D610005A 02052157
	v_bfe_u32 v102, v1, 16, 1                                  // 000000365558: D6100066 02052101
	v_add3_u32 v103, v103, v104, 0x7fff                        // 000000365560: D6550067 03FED167 00007FFF
	v_and_or_b32 v88, 0xffff0000, v88, v61                     // 00000036556C: D6570058 04F6B0FF FFFF0000
	.long 0x7e7a39d5                                           // 000000365578: 7E7A39D5
	v_add3_u32 v85, v87, v90, 0x7fff                           // 00000036557C: D6550055 03FEB557 00007FFF
	v_add3_u32 v1, v1, v102, 0x7fff                            // 000000365588: D6550001 03FECD01 00007FFF
	v_lshrrev_b32_e32 v118, 12, v63                            // 000000365594: 32EC7E8C
	v_and_b32_e32 v93, 15, v4                                  // 000000365598: 36BA088F
	v_and_or_b32 v102, 0xffff0000, v103, v61                   // 00000036559C: D6570066 04F6CEFF FFFF0000
	.long 0x7e7a39d5                                           // 0000003655A8: 7E7A39D5
	v_and_or_b32 v103, v112, 15, v109                          // 0000003655AC: D6570067 05B51F70
	v_lshrrev_b32_e32 v92, 14, v63                             // 0000003655B4: 32B87E8E
	v_lshrrev_b32_e32 v117, 18, v63                            // 0000003655B8: 32EA7E92
	v_lshrrev_b32_e32 v98, 26, v63                             // 0000003655BC: 32C47E9A
	v_and_or_b32 v1, 0xffff0000, v1, v61                       // 0000003655C0: D6570001 04F602FF FFFF0000
	.long 0x7e7a3983                                           // 0000003655CC: 7E7A3983
	v_and_or_b32 v3, v95, 15, v110                             // 0000003655D0: D6570003 05B91F5F
	v_cvt_f32_ubyte0_e32 v103, v103                            // 0000003655D8: 7ECE2367
	v_cvt_f32_ubyte0_e32 v95, v101                             // 0000003655DC: 7EBE2365
	v_lshrrev_b32_e32 v121, 28, v4                             // 0000003655E0: 32F2089C
	v_and_or_b32 v99, v61, 15, v107                            // 0000003655E4: D6570063 05AD1F3D
	v_cvt_f32_ubyte0_e32 v3, v3                                // 0000003655EC: 7E062303
	v_fma_mix_f32 v103, v103, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003655F0: CC206067 154EA767
	v_fma_mix_f32 v95, v95, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003655F8: CC20605F 154EA75F
	v_lshrrev_b32_e32 v123, 4, v4                              // 000000365600: 32F60884
	v_cvt_f32_ubyte0_e32 v99, v99                              // 000000365604: 7EC62363
	v_fma_mix_f32 v3, v3, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000365608: CC206003 154EA703
	v_bfe_u32 v106, v103, 16, 1                                // 000000365610: D610006A 02052167
	v_lshrrev_b32_e32 v125, 12, v4                             // 000000365618: 32FA088C
	v_and_or_b32 v93, v118, 48, v93                            // 00000036561C: D657005D 05756176
	v_fma_mix_f32 v99, v99, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000365624: CC206063 154EA763
	v_and_b32_e32 v92, 48, v92                                 // 00000036562C: 36B8B8B0
	v_and_b32_e32 v111, 48, v117                               // 000000365630: 36DEEAB0
	v_bfe_u32 v107, v95, 16, 1                                 // 000000365634: D610006B 0205215F
	v_add3_u32 v103, v103, v106, 0x7fff                        // 00000036563C: D6550067 03FED567 00007FFF
	v_bfe_u32 v105, v99, 16, 1                                 // 000000365648: D6100069 02052163
	v_and_or_b32 v98, v98, 48, v121                            // 000000365650: D6570062 05E56162
	v_and_or_b32 v92, v123, 15, v92                            // 000000365658: D657005C 05711F7B
	v_and_or_b32 v101, v125, 15, v111                          // 000000365660: D6570065 05BD1F7D
	v_cvt_f32_ubyte0_e32 v93, v93                              // 000000365668: 7EBA235D
	v_add3_u32 v99, v99, v105, 0x7fff                          // 00000036566C: D6550063 03FED363 00007FFF
	v_bfe_u32 v105, v3, 16, 1                                  // 000000365678: D6100069 02052103
	v_add3_u32 v95, v95, v107, 0x7fff                          // 000000365680: D655005F 03FED75F 00007FFF
	v_cvt_f32_ubyte0_e32 v98, v98                              // 00000036568C: 7EC42362
	v_fma_mix_f32 v93, v93, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000365690: CC20605D 154EA75D
	.long 0x7e7a39e3                                           // 000000365698: 7E7A39E3
	v_add3_u32 v3, v3, v105, 0x7fff                            // 00000036569C: D6550003 03FED303 00007FFF
	v_cvt_f32_ubyte0_e32 v92, v92                              // 0000003656A8: 7EB8235C
	v_cvt_f32_ubyte0_e32 v101, v101                            // 0000003656AC: 7ECA2365
	v_lshrrev_b32_e32 v119, 24, v63                            // 0000003656B0: 32EE7E98
	v_and_or_b32 v103, 0xffff0000, v103, v61                   // 0000003656B4: D6570067 04F6CEFF FFFF0000
	.long 0x7e7a3983                                           // 0000003656C0: 7E7A3983
	v_lshrrev_b32_e32 v120, 22, v63                            // 0000003656C4: 32F07E96
	v_lshrrev_b32_e32 v62, 20, v63                             // 0000003656C8: 327C7E94
	v_lshrrev_b32_e32 v124, 8, v4                              // 0000003656CC: 32F80888
	v_cvt_f32_ubyte0_e32 v2, v2                                // 0000003656D0: 7E042302
	v_and_or_b32 v95, 0xffff0000, v95, v61                     // 0000003656D4: D657005F 04F6BEFF FFFF0000
	.long 0x7e7a39bf                                           // 0000003656E0: 7E7A39BF
	v_cvt_f32_ubyte0_e32 v97, v97                              // 0000003656E4: 7EC22361
	v_fma_mix_f32 v3, v98, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003656E8: CC206003 154EA762
	v_bfe_u32 v98, v93, 16, 1                                  // 0000003656F0: D6100062 0205215D
	v_fma_mix_f32 v63, v92, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003656F8: CC20603F 154EA75C
	v_fma_mix_f32 v92, v101, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000365700: CC20605C 154EA765
	v_and_b32_e32 v101, 48, v61                                // 000000365708: 36CA7AB0
	v_fma_mix_f32 v2, v2, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036570C: CC206002 154EA702
	v_fma_mix_f32 v97, v97, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000365714: CC206061 154EA761
	v_add3_u32 v93, v93, v98, 0x7fff                           // 00000036571C: D655005D 03FEC55D 00007FFF
	.long 0x7fb439bd                                           // 000000365728: 7FB439BD
	v_and_or_b32 v98, v124, 15, v101                           // 00000036572C: D6570062 05951F7C
	v_bfe_u32 v105, v2, 16, 1                                  // 000000365734: D6100069 02052102
	v_bfe_u32 v106, v97, 16, 1                                 // 00000036573C: D610006A 02052161
	v_bfe_u32 v101, v92, 16, 1                                 // 000000365744: D6100065 0205215C
	v_lshrrev_b32_e32 v126, 20, v4                             // 00000036574C: 32FC0894
	v_cvt_f32_ubyte0_e32 v98, v98                              // 000000365750: 7EC42362
	v_add3_u32 v2, v2, v105, 0x7fff                            // 000000365754: D6550002 03FED302 00007FFF
	v_lshrrev_b32_e32 v127, 24, v4                             // 000000365760: 32FE0898
	v_and_b32_e32 v62, 48, v62                                 // 000000365764: 367C7CB0
	v_and_b32_e32 v113, 48, v120                               // 000000365768: 36E2F0B0
	v_and_b32_e32 v87, 48, v119                                // 00000036576C: 36AEEEB0
	.long 0x7eb43982                                           // 000000365770: 7EB43982
	v_bfe_u32 v107, v63, 16, 1                                 // 000000365774: D610006B 0205213F
	.long 0x7faa39bd                                           // 00000036577C: 7FAA39BD
	v_and_or_b32 v104, v126, 15, v113                          // 000000365780: D6570068 05C51F7E
	v_and_or_b32 v87, v127, 15, v87                            // 000000365788: D6570057 055D1F7F
	.long 0x7eaa39dd                                           // 000000365790: 7EAA39DD
	v_add_nc_u32_e32 v80, 0x200, v80                           // 000000365794: 4AA0A0FF 00000200
	v_add_nc_u32_e32 v81, 0x100, v81                           // 00000036579C: 4AA2A2FF 00000100
	v_cvt_f32_ubyte0_e32 v99, v104                             // 0000003657A4: 7EC62368
	v_cvt_f32_ubyte0_e32 v87, v87                              // 0000003657A8: 7EAE2357
	v_bfe_u32 v104, v3, 16, 1                                  // 0000003657AC: D6100068 02052103
	v_add_nc_u32_e32 v82, 64, v82                              // 0000003657B4: 4AA4A4C0
	v_add_nc_u32_e32 v60, 0x400, v60                           // 0000003657B8: 4A7878FF 00000400
	v_fma_mix_f32 v99, v99, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003657C0: CC206063 154EA763
	v_fma_mix_f32 v87, v87, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003657C8: CC206057 154EA757
	v_add3_u32 v3, v3, v104, 0x7fff                            // 0000003657D0: D6550003 03FED103 00007FFF
	s_and_b32 s0, exec_lo, vcc_lo                              // 0000003657DC: 8B006A7E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003657E0: BF870003
	v_bfe_u32 v108, v99, 16, 1                                 // 0000003657E4: D610006C 02052163
	s_or_b32 s12, s0, s12                                      // 0000003657EC: 8C0C0C00
	s_waitcnt vmcnt(11)                                        // 0000003657F0: BF892FF7
	v_dot2_f32_bf16 v9, v9, v86, 0                             // 0000003657F4: CC1A4009 1A02AD09
	s_waitcnt vmcnt(10)                                        // 0000003657FC: BF892BF7
	v_dot2_f32_bf16 v13, v13, v86, 0                           // 000000365800: CC1A400D 1A02AD0D
	s_waitcnt vmcnt(9)                                         // 000000365808: BF8927F7
	v_dot2_f32_bf16 v17, v17, v86, 0                           // 00000036580C: CC1A4011 1A02AD11
	v_add3_u32 v86, v97, v106, 0x7fff                          // 000000365814: D6550056 03FED561 00007FFF
	v_fma_mix_f32 v97, v98, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000365820: CC206061 154EA762
	v_dot2_f32_bf16 v9, v10, v89, v9                           // 000000365828: CC1A4009 1C26B30A
	v_dot2_f32_bf16 v10, v14, v89, v13                         // 000000365830: CC1A400A 1C36B30E
	v_dot2_f32_bf16 v13, v18, v89, v17                         // 000000365838: CC1A400D 1C46B312
	v_add3_u32 v14, v99, v108, 0x7fff                          // 000000365840: D655000E 03FED963 00007FFF
	v_bfe_u32 v2, v97, 16, 1                                   // 00000036584C: D6100002 02052161
	v_dot2_f32_bf16 v9, v11, v94, v9                           // 000000365854: CC1A4009 1C26BD0B
	v_dot2_f32_bf16 v10, v15, v94, v10                         // 00000036585C: CC1A400A 1C2ABD0F
	v_dot2_f32_bf16 v11, v19, v94, v13                         // 000000365864: CC1A400B 1C36BD13
	v_and_or_b32 v13, 0xffff0000, v86, v90                     // 00000036586C: D657000D 056AACFF FFFF0000
	v_add3_u32 v2, v97, v2, 0x7fff                             // 000000365878: D6550002 03FE0561 00007FFF
	v_dot2_f32_bf16 v9, v12, v96, v9                           // 000000365884: CC1A4009 1C26C10C
	v_dot2_f32_bf16 v10, v16, v96, v10                         // 00000036588C: CC1A400A 1C2AC110
	v_dot2_f32_bf16 v11, v20, v96, v11                         // 000000365894: CC1A400B 1C2EC114
	v_add3_u32 v12, v92, v101, 0x7fff                          // 00000036589C: D655000C 03FECB5C 00007FFF
	.long 0x7e7a3982                                           // 0000003658A8: 7E7A3982
	s_waitcnt vmcnt(8)                                         // 0000003658AC: BF8923F7
	v_dot2_f32_bf16 v2, v21, v13, v9                           // 0000003658B0: CC1A4002 1C261B15
	s_waitcnt vmcnt(7)                                         // 0000003658B8: BF891FF7
	v_dot2_f32_bf16 v9, v25, v13, v10                          // 0000003658BC: CC1A4009 1C2A1B19
	s_waitcnt vmcnt(6)                                         // 0000003658C4: BF891BF7
	v_dot2_f32_bf16 v10, v29, v13, v11                         // 0000003658C8: CC1A400A 1C2E1B1D
	v_add3_u32 v13, v63, v107, 0x7fff                          // 0000003658D0: D655000D 03FED73F 00007FFF
	v_and_or_b32 v12, 0xffff0000, v12, v61                     // 0000003658DC: D657000C 04F618FF FFFF0000
	v_dot2_f32_bf16 v2, v22, v91, v2                           // 0000003658E8: CC1A4002 1C0AB716
	v_dot2_f32_bf16 v9, v26, v91, v9                           // 0000003658F0: CC1A4009 1C26B71A
	v_dot2_f32_bf16 v10, v30, v91, v10                         // 0000003658F8: CC1A400A 1C2AB71E
	.long 0x7e7a3984                                           // 000000365900: 7E7A3984
	v_bfe_u32 v11, v87, 16, 1                                  // 000000365904: D610000B 02052157
	v_dot2_f32_bf16 v2, v23, v100, v2                          // 00000036590C: CC1A4002 1C0AC917
	v_dot2_f32_bf16 v4, v27, v100, v9                          // 000000365914: CC1A4004 1C26C91B
	v_dot2_f32_bf16 v9, v31, v100, v10                         // 00000036591C: CC1A4009 1C2AC91F
	v_and_or_b32 v10, v61, 15, v62                             // 000000365924: D657000A 04F91F3D
	v_add3_u32 v11, v87, v11, 0x7fff                           // 00000036592C: D655000B 03FE1757 00007FFF
	v_dot2_f32_bf16 v2, v24, v88, v2                           // 000000365938: CC1A4002 1C0AB118
	v_dot2_f32_bf16 v4, v28, v88, v4                           // 000000365940: CC1A4004 1C12B11C
	v_dot2_f32_bf16 v9, v32, v88, v9                           // 000000365948: CC1A4009 1C26B120
	v_cvt_f32_ubyte0_e32 v10, v10                              // 000000365950: 7E14230A
	v_mov_b32_e32 v62, v64                                     // 000000365954: 7E7C0340
	s_waitcnt vmcnt(5)                                         // 000000365958: BF8917F7
	v_dot2_f32_bf16 v2, v33, v102, v2                          // 00000036595C: CC1A4002 1C0ACD21
	s_waitcnt vmcnt(4)                                         // 000000365964: BF8913F7
	v_dot2_f32_bf16 v4, v37, v102, v4                          // 000000365968: CC1A4004 1C12CD25
	s_waitcnt vmcnt(3)                                         // 000000365970: BF890FF7
	v_dot2_f32_bf16 v9, v41, v102, v9                          // 000000365974: CC1A4009 1C26CD29
	v_fma_mix_f32 v10, v10, v83, v83 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036597C: CC20600A 154EA70A
	v_mov_b32_e32 v63, v65                                     // 000000365984: 7E7E0341
	v_dot2_f32_bf16 v2, v34, v1, v2                            // 000000365988: CC1A4002 1C0A0322
	v_dot2_f32_bf16 v4, v38, v1, v4                            // 000000365990: CC1A4004 1C120326
	v_dot2_f32_bf16 v1, v42, v1, v9                            // 000000365998: CC1A4001 1C26032A
	v_bfe_u32 v9, v10, 16, 1                                   // 0000003659A0: D6100009 0205210A
	v_mov_b32_e32 v83, v84                                     // 0000003659A8: 7EA60354
	v_dot2_f32_bf16 v2, v35, v103, v2                          // 0000003659AC: CC1A4002 1C0ACF23
	v_dot2_f32_bf16 v4, v39, v103, v4                          // 0000003659B4: CC1A4004 1C12CF27
	v_dot2_f32_bf16 v1, v43, v103, v1                          // 0000003659BC: CC1A4001 1C06CF2B
	v_add3_u32 v9, v10, v9, 0x7fff                             // 0000003659C4: D6550009 03FE130A 00007FFF
	v_and_or_b32 v10, 0xffff0000, v13, v85                     // 0000003659D0: D657000A 05561AFF FFFF0000
	v_dot2_f32_bf16 v2, v36, v95, v2                           // 0000003659DC: CC1A4002 1C0ABF24
	v_dot2_f32_bf16 v4, v40, v95, v4                           // 0000003659E4: CC1A4004 1C12BF28
	v_dot2_f32_bf16 v1, v44, v95, v1                           // 0000003659EC: CC1A4001 1C06BF2C
	.long 0x7e7a3989                                           // 0000003659F4: 7E7A3989
	s_waitcnt vmcnt(2)                                         // 0000003659F8: BF890BF7
	v_dot2_f32_bf16 v2, v45, v10, v2                           // 0000003659FC: CC1A4002 1C0A152D
	s_waitcnt vmcnt(1)                                         // 000000365A04: BF8907F7
	v_dot2_f32_bf16 v4, v49, v10, v4                           // 000000365A08: CC1A4004 1C121531
	s_waitcnt vmcnt(0)                                         // 000000365A10: BF8903F7
	v_dot2_f32_bf16 v1, v53, v10, v1                           // 000000365A14: CC1A4001 1C061535
	v_and_or_b32 v9, 0xffff0000, v14, v61                      // 000000365A1C: D6570009 04F61CFF FFFF0000
	.long 0x7e7a398b                                           // 000000365A28: 7E7A398B
	v_dot2_f32_bf16 v10, v46, v12, v2                          // 000000365A2C: CC1A400A 1C0A192E
	v_dot2_f32_bf16 v4, v50, v12, v4                           // 000000365A34: CC1A4004 1C121932
	v_dot2_f32_bf16 v1, v54, v12, v1                           // 000000365A3C: CC1A4001 1C061936
	v_mov_b32_e32 v2, v6                                       // 000000365A44: 7E040306
	v_and_or_b32 v6, 0xffff0000, v3, v61                       // 000000365A48: D6570006 04F606FF FFFF0000
	v_dot2_f32_bf16 v10, v47, v9, v10                          // 000000365A54: CC1A400A 1C2A132F
	v_dot2_f32_bf16 v4, v51, v9, v4                            // 000000365A5C: CC1A4004 1C121333
	v_dot2_f32_bf16 v1, v55, v9, v1                            // 000000365A64: CC1A4001 1C061337
	v_mov_b32_e32 v3, v7                                       // 000000365A6C: 7E060307
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000365A70: BF870214
	v_dot2_f32_bf16 v7, v48, v6, v10                           // 000000365A74: CC1A4007 1C2A0D30
	v_dot2_f32_bf16 v9, v52, v6, v4                            // 000000365A7C: CC1A4009 1C120D34
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000365A84: BF870194
	v_dot2_f32_bf16 v1, v56, v6, v1                            // 000000365A88: CC1A4001 1C060D38
	v_dual_mov_b32 v4, v8 :: v_dual_add_f32 v75, v75, v7       // 000000365A90: CA080108 044A0F4B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000365A98: BF870193
	v_add_f32_e32 v74, v74, v9                                 // 000000365A9C: 0694134A
	v_add_f32_e32 v67, v67, v1                                 // 000000365AA0: 06860343
	v_mov_b32_e32 v1, v5                                       // 000000365AA4: 7E020305
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 000000365AA8: 917E0C7E
	s_cbranch_execz 39                                         // 000000365AAC: BFA50027 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0xe4c>
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v71, 32, v71    // 000000365AB0: CA200102 06468EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000365AB8: BF870002
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 000000365ABC: CA100101 05080104
	v_dual_mov_b32 v7, v3 :: v_dual_mov_b32 v64, v62           // 000000365AC4: CA100103 0740013E
	v_mov_b32_e32 v65, v63                                     // 000000365ACC: 7E82033F
	s_mov_b32 s13, exec_lo                                     // 000000365AD0: BE8D007E
	v_cmp_ge_i32_e32 vcc_lo, v71, v72                          // 000000365AD4: 7C8C9147
	.long 0xd4c1007e                                           // 000000365AD8: D4C1007E
	v_cndmask_b32_e32 v1, v71, v72, vcc_lo                     // 000000365ADC: 02029147
	s_cbranch_execz 64874                                      // 000000365AE0: BFA5FD6A <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x38c>
	v_and_b32_e32 v7, -4, v82                                  // 000000365AE4: 360EA4C4
	v_ashrrev_i32_e32 v6, 31, v80                              // 000000365AE8: 340CA09F
	v_ashrrev_i32_e32 v8, 31, v81                              // 000000365AEC: 3410A29F
	.long 0xd7000005                                           // 000000365AF0: D7000005
	v_cndmask_b32_e32 v1, v59, v80, vcc_lo                     // 000000365AF4: 0202A13B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000365AF8: BF870214
	v_ashrrev_i32_e32 v12, 31, v7                              // 000000365AFC: 34180E9F
	v_add_co_ci_u32_e64 v6, null, v73, v6, s0                  // 000000365B00: D5207C06 00020D49
	.long 0xd7000009                                           // 000000365B08: D7000009
	v_cndmask_b32_e32 v1, v76, v81, vcc_lo                     // 000000365B0C: 0202A34C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000365B10: BF8700A1
	v_add_co_ci_u32_e64 v10, null, v77, v8, s0                 // 000000365B14: D5207C0A 0002114D
	.long 0xd700000b                                           // 000000365B1C: D700000B
	v_cndmask_b32_e32 v1, v78, v7, vcc_lo                      // 000000365B20: 02020F4E
	v_add_co_ci_u32_e64 v12, null, v79, v12, s0                // 000000365B24: D5207C0C 0002194F
	s_clause 0x2                                               // 000000365B2C: BF850002
	global_load_b128 v[5:8], v[5:6], off                       // 000000365B30: DC5E0000 057C0005
	global_load_b64 v[64:65], v[9:10], off                     // 000000365B38: DC560000 407C0009
	global_load_b32 v84, v[11:12], off                         // 000000365B40: DC520000 547C000B
	s_branch 64848                                             // 000000365B48: BFA0FD50 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x38c>
	s_or_b32 exec_lo, exec_lo, s12                             // 000000365B4C: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000365B50: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000365B54: 8C7E017E
	s_waitcnt vmcnt(2)                                         // 000000365B58: BF890BF7
	.long 0xd71f0001                                           // 000000365B5C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000365B60: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000365B64: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000365B68: 3A040290
	v_xor_b32_e32 v5, 8, v1                                    // 000000365B6C: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 000000365B70: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000365B74: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000365B78: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000365B7C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000365B80: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 000000365B84: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000365B88: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000365B8C: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000365B90: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000365B94: 30040482
	ds_bpermute_b32 v3, v2, v75                                // 000000365B98: DACC0000 03004B02
	s_waitcnt lgkmcnt(0)                                       // 000000365BA0: BF89FC07
	v_add_f32_e32 v3, v75, v3                                  // 000000365BA4: 0606074B
	ds_bpermute_b32 v4, v2, v74                                // 000000365BA8: DACC0000 04004A02
	ds_bpermute_b32 v2, v2, v67                                // 000000365BB0: DACC0000 02004302
	ds_bpermute_b32 v6, v5, v3                                 // 000000365BB8: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 000000365BC0: 02101101
	s_waitcnt lgkmcnt(2)                                       // 000000365BC4: BF89FC27
	v_add_f32_e32 v4, v74, v4                                  // 000000365BC8: 0608094A
	s_waitcnt lgkmcnt(1)                                       // 000000365BCC: BF89FC17
	v_add_f32_e32 v2, v67, v2                                  // 000000365BD0: 06040543
	s_waitcnt lgkmcnt(0)                                       // 000000365BD4: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 000000365BD8: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 000000365BDC: DACC0000 07000405
	ds_bpermute_b32 v5, v5, v2                                 // 000000365BE4: DACC0000 05000205
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000365BEC: 30101082
	s_waitcnt lgkmcnt(0)                                       // 000000365BF0: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 000000365BF4: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 000000365BF8: DACC0000 05000308
	s_waitcnt lgkmcnt(0)                                       // 000000365C00: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v7     // 000000365C04: C9080B03 03040F04
	ds_bpermute_b32 v7, v8, v2                                 // 000000365C0C: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 000000365C14: DACC0000 06000408
	v_xor_b32_e32 v8, 2, v1                                    // 000000365C1C: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000365C20: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000365C24: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 000000365C28: 02101101
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000365C2C: 30101082
	s_waitcnt lgkmcnt(1)                                       // 000000365C30: BF89FC17
	v_add_f32_e32 v2, v2, v7                                   // 000000365C34: 06040F02
	s_waitcnt lgkmcnt(0)                                       // 000000365C38: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 000000365C3C: 06080D04
	ds_bpermute_b32 v5, v8, v3                                 // 000000365C40: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 000000365C48: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 000000365C50: DACC0000 06000408
	v_xor_b32_e32 v8, 1, v1                                    // 000000365C58: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000365C5C: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000365C60: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 000000365C64: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000365C68: 30100282
	s_waitcnt lgkmcnt(1)                                       // 000000365C6C: BF89FC17
	v_dual_add_f32 v1, v3, v5 :: v_dual_add_f32 v2, v2, v7     // 000000365C70: C9080B03 01020F02
	s_waitcnt lgkmcnt(0)                                       // 000000365C78: BF89FC07
	v_add_f32_e32 v3, v4, v6                                   // 000000365C7C: 06060D04
	ds_bpermute_b32 v4, v8, v1                                 // 000000365C80: DACC0000 04000108
	ds_bpermute_b32 v5, v8, v2                                 // 000000365C88: DACC0000 05000208
	ds_bpermute_b32 v6, v8, v3                                 // 000000365C90: DACC0000 06000308
	v_cmpx_eq_u32_e32 0, v68                                   // 000000365C98: 7D948880
	s_cbranch_execz 12                                         // 000000365C9C: BFA5000C <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0xfd0>
	v_lshl_add_u32 v7, v69, s15, v70                           // 000000365CA0: D6460007 05181F45
	s_waitcnt lgkmcnt(0)                                       // 000000365CA8: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v2, v2, v5     // 000000365CAC: C9080D03 03020B02
	v_add_f32_e32 v1, v1, v4                                   // 000000365CB4: 06020901
	s_delay_alu instid0(VALU_DEP_3)                            // 000000365CB8: BF870003
	v_mul_u32_u24_e32 v4, 12, v7                               // 000000365CBC: 16080E8C
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 000000365CC0: D8380100 00030104
	ds_store_b32 v4, v2 offset:8                               // 000000365CC8: D8340008 00000204
	s_or_b32 exec_lo, exec_lo, s0                              // 000000365CD0: 8C7E007E
	.long 0xd5180001                                           // 000000365CD4: D5180001
	v_cndmask_b32_e32 v0, v66, v131, vcc_lo                    // 000000365CD8: 02010742
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000365CDC: BF890007
	s_barrier                                                  // 000000365CE0: BFBD0000
	buffer_gl0_inv                                             // 000000365CE4: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 000000365CEC: BE80007E
	.long 0xd4c9007e                                           // 000000365CF0: D4C9007E
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000365CF4: 02020300
	s_cbranch_execz 390                                        // 000000365CF8: BFA50186 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x1614>
	v_cmp_lt_u32_e32 vcc_lo, 2, v0                             // 000000365CFC: 7C920082
	v_cndmask_b32_e64 v3, 0, 1, vcc_lo                         // 000000365D00: D5010003 01A90280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000365D08: BF870091
	.long 0xd7006a01                                           // 000000365D0C: D7006A01
	v_cndmask_b32_e32 v1, v57, v3, vcc_lo                      // 000000365D10: 02020739
	v_add_co_ci_u32_e64 v2, null, 0, v58, vcc_lo               // 000000365D14: D5207C02 01AA7480
	s_delay_alu instid0(VALU_DEP_1)                            // 000000365D1C: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[1:2]                    // 000000365D20: 7CA80208
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000365D24: 8B7E6A7E
	s_cbranch_execz 378                                        // 000000365D28: BFA5017A <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x1614>
	v_lshlrev_b32_e32 v4, s15, v3                              // 000000365D2C: 3008060F
	.long 0xd7016a03                                           // 000000365D30: D7016A03
	v_cndmask_b32_e32 v0, v0, v131, vcc_lo                     // 000000365D34: 02010700
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000365D38: BF870191
	v_cndmask_b32_e32 v3, v3, v0, vcc_lo                       // 000000365D3C: 02060103
	v_mul_u32_u24_e32 v0, 12, v4                               // 000000365D40: 1600088C
	v_mov_b32_e32 v4, 0                                        // 000000365D44: 7E080280
	s_delay_alu instid0(VALU_DEP_2)                            // 000000365D48: BF870002
	v_lshl_add_u32 v0, v3, 2, v0                               // 000000365D4C: D6460000 04010503
	ds_load_b32 v5, v0                                         // 000000365D54: D8D80000 05000000
	v_add_nc_u32_e32 v0, 12, v0                                // 000000365D5C: 4A00008C
	s_add_i32 s14, s14, -1                                     // 000000365D60: 810EC10E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000365D64: BF870009
	s_cmp_eq_u32 s14, 0                                        // 000000365D68: BF06800E
	s_waitcnt lgkmcnt(0)                                       // 000000365D6C: BF89FC07
	v_add_f32_e32 v4, v4, v5                                   // 000000365D70: 06080B04
	s_cbranch_scc0 65527                                       // 000000365D74: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x1054>
	s_clause 0x1                                               // 000000365D78: BF850001
	s_load_b64 s[2:3], s[10:11], 0x38                          // 000000365D7C: F4040085 F8000038
	s_load_b64 s[0:1], s[10:11], 0x8                           // 000000365D84: F4040005 F8000008
	s_mov_b32 s6, -1                                           // 000000365D8C: BE8600C1
	s_mov_b32 s4, 0                                            // 000000365D90: BE840080
	s_mov_b32 s5, 0                                            // 000000365D94: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000365D98: BF89FC07
	s_cmp_lt_i32 s3, 3                                         // 000000365D9C: BF048303
	s_cbranch_scc1 183                                         // 000000365DA0: BFA200B7 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x1380>
	s_cmp_gt_i32 s3, 3                                         // 000000365DA4: BF028303
	s_cbranch_scc0 117                                         // 000000365DA8: BFA10075 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x1280>
	s_cmp_gt_i32 s3, 4                                         // 000000365DAC: BF028403
	s_cbranch_scc0 62                                          // 000000365DB0: BFA1003E <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x11ac>
	s_cmp_eq_u32 s3, 5                                         // 000000365DB4: BF068503
	s_mov_b32 s5, -1                                           // 000000365DB8: BE8500C1
	s_cbranch_scc0 58                                          // 000000365DBC: BFA1003A <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x11a8>
	s_load_b64 s[6:7], s[10:11], 0x10                          // 000000365DC0: F4040185 F8000010
	s_lshr_b64 s[10:11], s[8:9], 1                             // 000000365DC8: 858A8108
	v_dual_mov_b32 v9, 0 :: v_dual_and_b32 v0, 3, v2           // 000000365DCC: CA240080 09000483
	v_mad_u64_u32 v[5:6], null, s10, v3, 0                     // 000000365DD4: D6FE7C05 0202060A
	v_and_b32_e32 v8, 0x1ff, v1                                // 000000365DDC: 361002FF 000001FF
	s_lshr_b32 s5, s9, 1                                       // 000000365DE4: 85058109
	v_dual_mov_b32 v11, s0 :: v_dual_and_b32 v10, 0xfffffe00, v1// 000000365DE8: CA240000 0B0A02FF FFFFFE00
	v_bfe_u32 v14, v4, 16, 1                                   // 000000365DF4: D610000E 02052104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000365DFC: BF8700C4
	v_mad_u64_u32 v[6:7], null, s5, v3, v[6:7]                 // 000000365E00: D6FE7C06 041A0605
	v_mov_b32_e32 v7, s1                                       // 000000365E08: 7E0E0201
	v_cmp_gt_u64_e32 vcc_lo, 0x100, v[8:9]                     // 000000365E0C: 7CB810FF 00000100
	.long 0xd7000509                                           // 000000365E14: D7000509
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 000000365E18: 020210FF FFFFFF00
	v_add_co_ci_u32_e64 v12, null, 0, -1, s5                   // 000000365E20: D5207C0C 00158280
	s_mov_b32 s5, 0                                            // 000000365E28: BE850080
	.long 0xd73c0005                                           // 000000365E2C: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 000000365E30: 02020A81
	s_waitcnt lgkmcnt(0)                                       // 000000365E34: BF89FC07
	v_cndmask_b32_e32 v11, s6, v11, vcc_lo                     // 000000365E38: 02161606
	v_cndmask_b32_e32 v13, s7, v7, vcc_lo                      // 000000365E3C: 021A0E07
	v_cndmask_b32_e32 v7, v9, v8, vcc_lo                       // 000000365E40: 020E1109
	v_cndmask_b32_e64 v8, v12, 0, vcc_lo                       // 000000365E44: D5010008 01A9010C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000365E4C: BF870094
	.long 0xd7006a09                                           // 000000365E50: D7006A09
	v_cndmask_b32_e32 v1, v11, v5, vcc_lo                      // 000000365E54: 02020B0B
	v_add_co_ci_u32_e64 v11, null, v13, v6, vcc_lo             // 000000365E58: D5207C0B 01AA0D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000365E60: BF870193
	.long 0xd73c0005                                           // 000000365E64: D73C0005
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 000000365E68: 02020E81
	.long 0xd7006a07                                           // 000000365E6C: D7006A07
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000365E70: 02021509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000365E74: BF8701A1
	v_add_co_ci_u32_e64 v0, null, v11, v0, vcc_lo              // 000000365E78: D5207C00 01AA010B
	v_add3_u32 v8, v4, v14, 0x7fff                             // 000000365E80: D6550008 03FE1D04 00007FFF
	.long 0xd7006a05                                           // 000000365E8C: D7006A05
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 000000365E90: 02020B07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000365E94: BF870001
	v_add_co_ci_u32_e64 v6, null, v0, v6, vcc_lo               // 000000365E98: D5207C06 01AA0D00
	global_store_d16_hi_b16 v[5:6], v8, off                    // 000000365EA0: DC960000 007C0805
	s_mov_b32 s6, 0                                            // 000000365EA8: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000365EAC: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000365EB0: 8B6A067E
	s_cbranch_vccz 49                                          // 000000365EB4: BFA30031 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x127c>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v4                           // 000000365EB8: 100008FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000365EC0: BF870291
	v_exp_f32_e32 v0, v0                                       // 000000365EC4: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 000000365EC8: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000365ECC: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 000000365ED0: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 000000365ED8: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 000000365EE0: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000365EE4: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 000000365EE8: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 000000365EF0: 56121305
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 000000365EF4: D6FE7C05 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000365EFC: BF870112
	v_mul_f32_e32 v11, v10, v9                                 // 000000365F00: 1016130A
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 000000365F04: D6FE7C06 041A0609
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000365F0C: BF870092
	v_fma_f32 v12, -v8, v11, v10                               // 000000365F10: D613000C 242A1708
	v_fmac_f32_e32 v11, v12, v9                                // 000000365F18: 5616130C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000365F1C: BF870113
	.long 0xd73c0005                                           // 000000365F20: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000365F24: 02020A82
	v_fma_f32 v10, -v8, v11, v10                               // 000000365F28: D613000A 242A1708
	.long 0xd73c0007                                           // 000000365F30: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000365F34: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000365F38: BF870212
	v_div_fmas_f32 v9, v10, v9, v11                            // 000000365F3C: D6370009 042E130A
	.long 0xd7006a05                                           // 000000365F44: D7006A05
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                       // 000000365F48: 02020A00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000365F4C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, v6, vcc_lo               // 000000365F50: D5207C06 01AA0C01
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 000000365F58: D6270000 03CA0109
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000365F60: BF870093
	.long 0xd7006a05                                           // 000000365F64: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000365F68: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 000000365F6C: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 000000365F74: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 000000365F7C: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000365F80: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000365F84: 8B6A067E
	s_cbranch_vccz 60                                          // 000000365F88: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x137c>
	v_bfe_u32 v0, v4, 16, 1                                    // 000000365F8C: D6100000 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000365F94: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 000000365F98: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 000000365FA4: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000365FAC: BF870091
	v_mul_f32_e32 v0, s2, v0                                   // 000000365FB0: 10000002
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 000000365FB4: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000365FBC: BF870291
	v_exp_f32_e32 v0, v0                                       // 000000365FC0: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 000000365FC4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000365FC8: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 000000365FCC: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 000000365FD4: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 000000365FDC: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000365FE0: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 000000365FE4: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 000000365FEC: 56121305
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 000000365FF0: D6FE7C05 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000365FF8: BF870092
	v_mul_f32_e32 v11, v10, v9                                 // 000000365FFC: 1016130A
	v_fma_f32 v7, -v8, v11, v10                                // 000000366000: D6130007 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000366008: BF870211
	v_fmac_f32_e32 v11, v7, v9                                 // 00000036600C: 56161307
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 000000366010: D6FE7C06 041A0609
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000366018: BF870112
	v_fma_f32 v7, -v8, v11, v10                                // 00000036601C: D6130007 242A1708
	.long 0xd73c0005                                           // 000000366024: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000366028: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000036602C: BF8701A2
	v_div_fmas_f32 v9, v7, v9, v11                             // 000000366030: D6370009 042E1307
	.long 0xd73c0007                                           // 000000366038: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000036603C: 02020282
	.long 0xd7006a05                                           // 000000366040: D7006A05
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                       // 000000366044: 02020A00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000366048: BF8701A3
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 00000036604C: D6270000 03CA0109
	v_add_co_ci_u32_e64 v6, null, s1, v6, vcc_lo               // 000000366054: D5207C06 01AA0C01
	.long 0xd7006a05                                           // 00000036605C: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000366060: 02020F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000366064: BF870193
	v_add_f32_e32 v0, v0, v0                                   // 000000366068: 06000100
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 00000036606C: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 000000366074: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 00000036607C: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000366080: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000366084: 8B6A067E
	s_cbranch_vccz 73                                          // 000000366088: BFA30049 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x14b0>
	s_cmp_gt_i32 s3, 1                                         // 00000036608C: BF028103
	s_mov_b32 s4, -1                                           // 000000366090: BE8400C1
	s_cbranch_scc0 64                                          // 000000366094: BFA10040 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x1498>
	v_bfe_u32 v0, v4, 16, 1                                    // 000000366098: D6100000 02052104
	s_mov_b32 s4, 0                                            // 0000003660A0: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003660A4: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000003660A8: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000003660B4: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003660BC: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000003660C0: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000003660C8: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003660CC: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 0000003660D0: 060000F2
	v_div_scale_f32 v7, null, v0, v0, 1.0                      // 0000003660D4: D6FC7C07 03CA0100
	v_div_scale_f32 v9, vcc_lo, 1.0, v0, 1.0                   // 0000003660DC: D6FC6A09 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003660E4: BF870292
	v_rcp_f32_e32 v8, v7                                       // 0000003660E8: 7E105507
	v_fma_f32 v5, -v7, v8, 1.0                                 // 0000003660EC: D6130005 23CA1107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003660F4: BF870121
	v_fmac_f32_e32 v8, v5, v8                                  // 0000003660F8: 56101105
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 0000003660FC: D6FE7C05 02020608
	v_mul_f32_e32 v10, v9, v8                                  // 000000366104: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000366108: BF870091
	v_fma_f32 v11, -v7, v10, v9                                // 00000036610C: D613000B 24261507
	v_fmac_f32_e32 v10, v11, v8                                // 000000366114: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000366118: BF870121
	v_fma_f32 v9, -v7, v10, v9                                 // 00000036611C: D6130009 24261507
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 000000366124: D6FE7C06 041A0609
	v_div_fmas_f32 v7, v9, v8, v10                             // 00000036612C: D6370007 042A1109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000366134: BF870112
	.long 0xd73c0005                                           // 000000366138: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000036613C: 02020A81
	v_div_fixup_f32 v0, v7, v0, 1.0                            // 000000366140: D6270000 03CA0107
	.long 0xd73c0007                                           // 000000366148: D73C0007
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000036614C: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000366150: BF870193
	.long 0xd7006a05                                           // 000000366154: D7006A05
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                       // 000000366158: 02020A00
	v_bfe_u32 v9, v0, 16, 1                                    // 00000036615C: D6100009 02052100
	v_add_co_ci_u32_e64 v6, null, s1, v6, vcc_lo               // 000000366164: D5207C06 01AA0C01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000036616C: BF870193
	.long 0xd7006a05                                           // 000000366170: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000366174: 02020F05
	v_add3_u32 v0, v0, v9, 0x7fff                              // 000000366178: D6550000 03FE1300 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000366184: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 000000366188: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v0, off                    // 000000366190: DC960000 007C0005
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 000000366198: 916A047E
	s_mov_b32 s4, 0                                            // 00000036619C: BE840080
	s_cbranch_vccnz 3                                          // 0000003661A0: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x14b0>
	s_cmp_lg_u32 s3, 1                                         // 0000003661A4: BF078103
	s_mov_b32 s4, -1                                           // 0000003661A8: BE8400C1
	s_cselect_b32 s5, -1, 0                                    // 0000003661AC: 980580C1
	v_bfe_u32 v5, v4, 16, 1                                    // 0000003661B0: D6100005 02052104
	.long 0xd73c0000                                           // 0000003661B8: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003661BC: 02020281
	s_and_b32 vcc_lo, exec_lo, s5                              // 0000003661C0: 8B6A057E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003661C4: BF870002
	v_add3_u32 v2, v4, v5, 0x7fff                              // 0000003661C8: D6550002 03FE0B04 00007FFF
	s_cbranch_vccz 20                                          // 0000003661D4: BFA30014 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x1528>
	v_mad_u64_u32 v[4:5], null, s8, v3, 0                      // 0000003661D8: D6FE7C04 02020608
	s_mov_b32 s4, 0                                            // 0000003661E0: BE840080
	v_mad_u64_u32 v[5:6], null, s9, v3, v[5:6]                 // 0000003661E4: D6FE7C05 04160609
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003661EC: BF870091
	.long 0xd73c0004                                           // 0000003661F0: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000003661F4: 02020881
	.long 0xd7006a04                                           // 0000003661F8: D7006A04
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 0000003661FC: 02020800
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000366200: BF870111
	v_add_co_ci_u32_e64 v5, null, s1, v5, vcc_lo               // 000000366204: D5207C05 01AA0A01
	.long 0xd7006a04                                           // 00000036620C: D7006A04
	v_cndmask_b32_e32 v1, v4, v0, vcc_lo                       // 000000366210: 02020104
	s_delay_alu instid0(VALU_DEP_1)                            // 000000366214: BF870001
	v_add_co_ci_u32_e64 v5, null, v5, v1, vcc_lo               // 000000366218: D5207C05 01AA0305
	global_store_d16_hi_b16 v[4:5], v2, off                    // 000000366220: DC960000 007C0204
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 000000366228: 916A047E
	s_cbranch_vccnz 57                                         // 00000036622C: BFA40039 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi4EEEvNS0_5LqGrpEPKtl+0x1614>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000366230: BF870091
	v_and_b32_e32 v2, 0xffff0000, v2                           // 000000366234: 360404FF FFFF0000
	v_mul_f32_e32 v2, s2, v2                                   // 00000036623C: 10040402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000366240: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v2                           // 000000366244: 100804FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 00000036624C: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000366250: BF870095
	v_add_f32_e32 v7, 1.0, v4                                  // 000000366254: 060E08F2
	v_div_scale_f32 v6, null, v7, v7, v2                       // 000000366258: D6FC7C06 040A0F07
	v_div_scale_f32 v9, vcc_lo, v2, v7, v2                     // 000000366260: D6FC6A09 040A0F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000366268: BF870292
	v_rcp_f32_e32 v8, v6                                       // 00000036626C: 7E105506
	v_fma_f32 v4, -v6, v8, 1.0                                 // 000000366270: D6130004 23CA1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000366278: BF870121
	v_fmac_f32_e32 v8, v4, v8                                  // 00000036627C: 56101104
	v_mad_u64_u32 v[4:5], null, s8, v3, 0                      // 000000366280: D6FE7C04 02020608
	v_mul_f32_e32 v10, v9, v8                                  // 000000366288: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036628C: BF870091
	v_fma_f32 v11, -v6, v10, v9                                // 000000366290: D613000B 24261506
	v_fmac_f32_e32 v10, v11, v8                                // 000000366298: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000036629C: BF870121
	v_fma_f32 v9, -v6, v10, v9                                 // 0000003662A0: D6130009 24261506
	v_mad_u64_u32 v[5:6], null, s9, v3, v[5:6]                 // 0000003662A8: D6FE7C05 04160609
	v_div_fmas_f32 v3, v9, v8, v10                             // 0000003662B0: D6370003 042A1109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003662B8: BF870191
	v_div_fixup_f32 v6, v3, v7, v2                             // 0000003662BC: D6270006 040A0F03
	.long 0xd73c0002                                           // 0000003662C4: D73C0002
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000003662C8: 02020881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003662CC: BF870112
	v_bfe_u32 v4, v6, 16, 1                                    // 0000003662D0: D6100004 02052106
	.long 0xd7006a02                                           // 0000003662D8: D7006A02
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 0000003662DC: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003662E0: BF870191
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 0000003662E4: D5207C03 01AA0601
	v_add3_u32 v4, v6, v4, 0x7fff                              // 0000003662EC: D6550004 03FE0906 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003662F8: BF870093
	.long 0xd7006a00                                           // 0000003662FC: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 000000366300: 02020102
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 000000366304: D5207C01 01AA0303
	global_store_d16_hi_b16 v[0:1], v4, off                    // 00000036630C: DC960000 007C0400
	s_nop 0                                                    // 000000366314: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000366318: BFB60003
	s_endpgm                                                   // 00000036631C: BFB00000
		...

