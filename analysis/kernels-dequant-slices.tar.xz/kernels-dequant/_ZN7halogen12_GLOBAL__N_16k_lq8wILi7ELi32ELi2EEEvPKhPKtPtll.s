00000000002ee200 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi32ELi2EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi32ELi2EEEvPKhPKtPtll():
	s_clause 0x1                                               // 0000002EE200: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 0000002EE204: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000002EE20C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 0000002EE214: BE830080
	v_lshrrev_b32_e32 v13, 6, v0                               // 0000002EE218: 321A0086
	s_lshl_b64 s[2:3], s[2:3], 2                               // 0000002EE21C: 84828202
	v_bfe_u32 v14, v0, 5, 1                                    // 0000002EE220: D610000E 02050B00
	v_dual_mov_b32 v12, 0 :: v_dual_and_b32 v15, 31, v0        // 0000002EE228: CA240080 0C0E009F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002EE230: BF870003
	v_or_b32_e32 v1, s2, v13                                   // 0000002EE234: 38021A02
	v_mov_b32_e32 v2, s3                                       // 0000002EE238: 7E040203
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v5, 0              // 0000002EE23C: CA100080 10040080
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v8, 0               // 0000002EE244: CA100080 07080080
	s_waitcnt lgkmcnt(0)                                       // 0000002EE24C: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 0000002EE250: 86009F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000002EE254: 7CA8020C
	s_lshr_b32 s0, s0, 28                                      // 0000002EE258: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002EE25C: BF8704A9
	s_add_u32 s0, s10, s0                                      // 0000002EE260: 8000000A
	s_addc_u32 s1, s11, 0                                      // 0000002EE264: 8201800B
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000002EE268: 86808400
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000002EE26C: 02020280
	s_add_u32 s14, s0, s10                                     // 0000002EE270: 800E0A00
	s_addc_u32 s1, s1, s11                                     // 0000002EE274: 82010B01
	s_add_i32 s15, s0, 1                                       // 0000002EE278: 810F8100
	v_cndmask_b32_e64 v2, 0, s3, vcc_lo                        // 0000002EE27C: D5010002 01A80680
	s_lshr_b32 s16, s15, 31                                    // 0000002EE284: 85109F0F
	v_mad_u64_u32 v[9:10], null, v1, s14, s[4:5]               // 0000002EE288: D6FE7C09 00101D01
	s_add_i32 s15, s15, s16                                    // 0000002EE290: 810F100F
	.long 0xd72c0001                                           // 0000002EE294: D72C0001
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 0000002EE298: 02000301
	s_ashr_i32 s15, s15, 1                                     // 0000002EE29C: 860F810F
	.long 0xd72c0002                                           // 0000002EE2A0: D72C0002
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 0000002EE2A4: 02001D02
	.long 0xd72c0003                                           // 0000002EE2A8: D72C0003
	v_cndmask_b32_e32 v1, s15, v14, vcc_lo                     // 0000002EE2AC: 02021C0F
	v_mov_b32_e32 v6, 0                                        // 0000002EE2B0: 7E0C0280
	.long 0xd7006a13                                           // 0000002EE2B4: D7006A13
	v_cndmask_b32_e32 v0, v9, v10, vcc_lo                      // 0000002EE2B8: 02001509
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002EE2BC: BF870214
	v_add3_u32 v10, v2, v10, v1                                // 0000002EE2C0: D655000A 04061502
	v_add_nc_u32_e32 v4, s15, v3                               // 0000002EE2C8: 4A08060F
	v_add_nc_u32_e32 v17, v3, v15                              // 0000002EE2CC: 4A221F03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EE2D0: BF870193
	v_add_co_ci_u32_e64 v20, null, s11, v10, vcc_lo            // 0000002EE2D4: D5207C14 01AA140B
	v_min_i32_e32 v18, s0, v4                                  // 0000002EE2DC: 22240800
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EE2E0: BF870113
	v_lshlrev_b32_e32 v11, 4, v17                              // 0000002EE2E4: 30162284
	v_cmp_lt_i32_e32 vcc_lo, v17, v18                          // 0000002EE2E8: 7C822511
	s_and_saveexec_b32 s1, vcc_lo                              // 0000002EE2EC: BE81206A
	s_cbranch_execz 19                                         // 0000002EE2F0: BFA50013 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi32ELi2EEEvPKhPKtPtll+0x140>
	v_lshlrev_b32_e32 v1, 4, v17                               // 0000002EE2F4: 30022284
	v_and_b32_e32 v3, -4, v17                                  // 0000002EE2F8: 360622C4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EE2FC: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002EE300: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002EE304: 3408069F
	.long 0xd7000001                                           // 0000002EE308: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 0000002EE30C: 02020309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EE310: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v10, v2, s0                  // 0000002EE314: D5207C02 0002050A
	.long 0xd7000003                                           // 0000002EE31C: D7000003
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 0000002EE320: 02020713
	v_add_co_ci_u32_e64 v4, null, v20, v4, s0                  // 0000002EE324: D5207C04 00020914
	s_clause 0x1                                               // 0000002EE32C: BF850001
	global_load_b128 v[5:8], v[1:2], off                       // 0000002EE330: DC5E0000 057C0001
	global_load_b32 v12, v[3:4], off                           // 0000002EE338: DC520000 0C7C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002EE340: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000002EE344: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 0000002EE34C: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v21, 0             // 0000002EE354: CA100080 1A140080
	s_and_saveexec_b32 s1, vcc_lo                              // 0000002EE35C: BE81206A
	s_cbranch_execz 490                                        // 0000002EE360: BFA501EA <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi32ELi2EEEvPKhPKtPtll+0x90c>
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v27, 0x200, v11 // 0000002EE364: CA200080 1A1A16FF 00000200
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v24, 0             // 0000002EE370: CA100080 15180080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v22, 0             // 0000002EE378: CA100080 19160080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v16, 0             // 0000002EE380: CA100080 17100080
	s_waitcnt vmcnt(0)                                         // 0000002EE388: BF8903F7
	v_mov_b32_e32 v28, v12                                     // 0000002EE38C: 7E38030C
	s_mul_i32 s0, s11, 6                                       // 0000002EE390: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 0000002EE394: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000002EE398: 8484820A
	s_add_i32 s14, s14, s0                                     // 0000002EE39C: 810E000E
	s_mul_i32 s16, s10, 6                                      // 0000002EE3A0: 9610860A
	s_mov_b32 s15, 0                                           // 0000002EE3A4: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000002EE3A8: 848A810A
	s_branch 440                                               // 0000002EE3AC: BFA001B8 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi32ELi2EEEvPKhPKtPtll+0x890>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000002EE3B0: 8C7E117E
	v_cvt_f32_ubyte0_e32 v29, v5                               // 0000002EE3B4: 7E3A2305
	s_and_b32 s0, exec_lo, vcc_lo                              // 0000002EE3B8: 8B006A7E
	v_add_nc_u32_e32 v27, 0x200, v27                           // 0000002EE3BC: 4A3636FF 00000200
	s_or_b32 s15, s0, s15                                      // 0000002EE3C4: 8C0F0F00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE3C8: BF870092
	v_fma_mix_f32 v29, v29, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EE3CC: CC20601D 1432191D
	v_bfe_u32 v30, v29, 16, 1                                  // 0000002EE3D4: D610001E 0205211D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EE3DC: BF870121
	v_add3_u32 v29, v29, v30, 0x7fff                           // 0000002EE3E0: D655001D 03FE3D1D 00007FFF
	.long 0x7f3c3880                                           // 0000002EE3EC: 7F3C3880
	.long 0x7e3c399d                                           // 0000002EE3F0: 7E3C399D
	v_cvt_f32_ubyte1_e32 v29, v5                               // 0000002EE3F4: 7E3A2505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE3F8: BF870091
	v_fma_mix_f32 v29, v29, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EE3FC: CC20601D 1432191D
	v_bfe_u32 v31, v29, 16, 1                                  // 0000002EE404: D610001F 0205211D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002EE40C: BF8701B1
	v_add3_u32 v29, v29, v31, 0x7fff                           // 0000002EE410: D655001D 03FE3F1D 00007FFF
	v_cvt_f32_ubyte2_e32 v31, v5                               // 0000002EE41C: 7E3E2705
	v_cvt_f32_ubyte3_e32 v5, v5                                // 0000002EE420: 7E0A2905
	v_and_or_b32 v37, 0xffff0000, v29, v30                     // 0000002EE424: D6570025 047A3AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EE430: BF870193
	v_fma_mix_f32 v31, v31, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EE434: CC20601F 1432191F
	v_fma_mix_f32 v5, v5, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EE43C: CC206005 14321905
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE444: BF870092
	v_bfe_u32 v32, v31, 16, 1                                  // 0000002EE448: D6100020 0205211F
	v_add3_u32 v31, v31, v32, 0x7fff                           // 0000002EE450: D655001F 03FE411F 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EE45C: BF870113
	v_bfe_u32 v32, v5, 16, 1                                   // 0000002EE460: D6100020 02052105
	.long 0x7e3e399f                                           // 0000002EE468: 7E3E399F
	.long 0x7f3e399e                                           // 0000002EE46C: 7F3E399E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE470: BF870093
	v_add3_u32 v5, v5, v32, 0x7fff                             // 0000002EE474: D6550005 03FE4105 00007FFF
	v_and_or_b32 v38, 0xffff0000, v5, v31                      // 0000002EE480: D6570026 047E0AFF FFFF0000
	v_cvt_f32_ubyte0_e32 v5, v6                                // 0000002EE48C: 7E0A2306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE490: BF870091
	v_fma_mix_f32 v5, v5, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EE494: CC206005 14321905
	v_bfe_u32 v29, v5, 16, 1                                   // 0000002EE49C: D610001D 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE4A4: BF870091
	v_add3_u32 v5, v5, v29, 0x7fff                             // 0000002EE4A8: D6550005 03FE3B05 00007FFF
	.long 0x7e3c3985                                           // 0000002EE4B4: 7E3C3985
	v_cvt_f32_ubyte1_e32 v5, v6                                // 0000002EE4B8: 7E0A2506
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE4BC: BF870091
	v_fma_mix_f32 v5, v5, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EE4C0: CC206005 14321905
	v_bfe_u32 v29, v5, 16, 1                                   // 0000002EE4C8: D610001D 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002EE4D0: BF8701B1
	v_add3_u32 v5, v5, v29, 0x7fff                             // 0000002EE4D4: D6550005 03FE3B05 00007FFF
	v_cvt_f32_ubyte2_e32 v29, v6                               // 0000002EE4E0: 7E3A2706
	v_cvt_f32_ubyte3_e32 v6, v6                                // 0000002EE4E4: 7E0C2906
	v_and_or_b32 v39, 0xffff0000, v5, v30                      // 0000002EE4E8: D6570027 047A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EE4F4: BF870193
	v_fma_mix_f32 v29, v29, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EE4F8: CC20601D 1432191D
	v_fma_mix_f32 v6, v6, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EE500: CC206006 14321906
	v_cvt_f32_ubyte0_e32 v5, v7                                // 0000002EE508: 7E0A2307
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EE50C: BF870113
	v_bfe_u32 v31, v29, 16, 1                                  // 0000002EE510: D610001F 0205211D
	v_fma_mix_f32 v5, v5, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EE518: CC206005 14321905
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EE520: BF870122
	v_add3_u32 v29, v29, v31, 0x7fff                           // 0000002EE524: D655001D 03FE3F1D 00007FFF
	v_bfe_u32 v31, v6, 16, 1                                   // 0000002EE530: D610001F 02052106
	.long 0x7e3a399d                                           // 0000002EE538: 7E3A399D
	.long 0x7f3a399e                                           // 0000002EE53C: 7F3A399E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE540: BF870093
	v_add3_u32 v6, v6, v31, 0x7fff                             // 0000002EE544: D6550006 03FE3F06 00007FFF
	v_and_or_b32 v40, 0xffff0000, v6, v29                      // 0000002EE550: D6570028 04760CFF FFFF0000
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002EE55C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE564: BF870091
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000002EE568: D6550005 03FE0D05 00007FFF
	.long 0x7e3c3985                                           // 0000002EE574: 7E3C3985
	v_cvt_f32_ubyte1_e32 v5, v7                                // 0000002EE578: 7E0A2507
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE57C: BF870091
	v_fma_mix_f32 v5, v5, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EE580: CC206005 14321905
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002EE588: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002EE590: BF8701B1
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000002EE594: D6550005 03FE0D05 00007FFF
	v_cvt_f32_ubyte2_e32 v6, v7                                // 0000002EE5A0: 7E0C2707
	v_cvt_f32_ubyte3_e32 v7, v7                                // 0000002EE5A4: 7E0E2907
	v_and_or_b32 v41, 0xffff0000, v5, v30                      // 0000002EE5A8: D6570029 047A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EE5B4: BF870193
	v_fma_mix_f32 v6, v6, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EE5B8: CC206006 14321906
	v_fma_mix_f32 v7, v7, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EE5C0: CC206007 14321907
	v_cvt_f32_ubyte0_e32 v5, v8                                // 0000002EE5C8: 7E0A2308
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EE5CC: BF870113
	v_bfe_u32 v29, v6, 16, 1                                   // 0000002EE5D0: D610001D 02052106
	v_fma_mix_f32 v5, v5, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EE5D8: CC206005 14321905
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EE5E0: BF870122
	v_add3_u32 v6, v6, v29, 0x7fff                             // 0000002EE5E4: D6550006 03FE3B06 00007FFF
	v_bfe_u32 v29, v7, 16, 1                                   // 0000002EE5F0: D610001D 02052107
	.long 0x7e0c3986                                           // 0000002EE5F8: 7E0C3986
	.long 0x7f0c399e                                           // 0000002EE5FC: 7F0C399E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE600: BF870093
	v_add3_u32 v7, v7, v29, 0x7fff                             // 0000002EE604: D6550007 03FE3B07 00007FFF
	v_and_or_b32 v42, 0xffff0000, v7, v6                       // 0000002EE610: D657002A 041A0EFF FFFF0000
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002EE61C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE624: BF870091
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000002EE628: D6550005 03FE0D05 00007FFF
	.long 0x7e3c3985                                           // 0000002EE634: 7E3C3985
	v_cvt_f32_ubyte1_e32 v5, v8                                // 0000002EE638: 7E0A2508
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE63C: BF870091
	v_fma_mix_f32 v5, v5, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EE640: CC206005 14321905
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002EE648: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EE650: BF870121
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000002EE654: D6550005 03FE0D05 00007FFF
	v_cvt_f32_ubyte2_e32 v6, v8                                // 0000002EE660: 7E0C2708
	v_and_or_b32 v43, 0xffff0000, v5, v30                      // 0000002EE664: D657002B 047A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE670: BF870092
	v_fma_mix_f32 v6, v6, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EE674: CC206006 14321906
	v_bfe_u32 v7, v6, 16, 1                                    // 0000002EE67C: D6100007 02052106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EE684: BF870121
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000002EE688: D6550006 03FE0F06 00007FFF
	v_cvt_f32_ubyte3_e32 v7, v8                                // 0000002EE694: 7E0E2908
	.long 0x7e0c3986                                           // 0000002EE698: 7E0C3986
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002EE69C: BF8701B2
	v_fma_mix_f32 v7, v7, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EE6A0: CC206007 14321907
	.long 0x7f0c399e                                           // 0000002EE6A8: 7F0C399E
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000002EE6AC: 3418169F
	v_bfe_u32 v8, v7, 16, 1                                    // 0000002EE6B0: D6100008 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE6B8: BF870091
	v_add3_u32 v7, v7, v8, 0x7fff                              // 0000002EE6BC: D6550007 03FE1107 00007FFF
	v_and_or_b32 v44, 0xffff0000, v7, v6                       // 0000002EE6C8: D657002C 041A0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002EE6D4: BF870134
	.long 0xd73c0005                                           // 0000002EE6D8: D73C0005
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002EE6DC: 02021681
	s_waitcnt vmcnt(0)                                         // 0000002EE6E0: BF8903F7
	v_dual_mov_b32 v12, v28 :: v_dual_add_nc_u32 v11, 0x200, v11// 0000002EE6E4: CA20011C 0C0A16FF 00000200
	.long 0xd7006a21                                           // 0000002EE6F0: D7006A21
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000002EE6F4: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002EE6F8: BF870001
	v_add_co_ci_u32_e64 v34, null, s7, v6, vcc_lo              // 0000002EE6FC: D5207C22 01AA0C07
	s_clause 0x1                                               // 0000002EE704: BF850001
	global_load_b128 v[5:8], v[33:34], off                     // 0000002EE708: DC5E0000 057C0021
	global_load_b128 v[29:32], v[33:34], off offset:16         // 0000002EE710: DC5E0010 1D7C0021
	s_waitcnt vmcnt(1)                                         // 0000002EE718: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 0000002EE71C: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE724: BF870091
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 0000002EE728: CC1A4005 1C164D06
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 0000002EE730: CC1A4005 1C164F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EE738: BF8700A1
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 0000002EE73C: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 0000002EE744: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000002EE748: CC1A4005 1C16531D
	.long 0xd7006a1d                                           // 0000002EE750: D7006A1D
	v_cndmask_b32_e32 v0, v33, v10, vcc_lo                     // 0000002EE754: 02001521
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002EE758: BF8701B2
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000002EE75C: CC1A4005 1C16551E
	v_add_co_ci_u32_e64 v30, null, s11, v34, vcc_lo            // 0000002EE764: D5207C1E 01AA440B
	.long 0xd7006a23                                           // 0000002EE76C: D7006A23
	v_cndmask_b32_e32 v0, v33, v4, vcc_lo                      // 0000002EE770: 02000921
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 0000002EE774: CC1A4005 1C16571F
	v_add_co_ci_u32_e64 v36, null, s5, v34, vcc_lo             // 0000002EE77C: D5207C24 01AA4405
	.long 0xd7006a21                                           // 0000002EE784: D7006A21
	v_cndmask_b32_e32 v0, v33, v16, vcc_lo                     // 0000002EE788: 02002121
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EE78C: BF870123
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 0000002EE790: CC1A4005 1C165920
	v_add_co_ci_u32_e64 v34, null, s14, v34, vcc_lo            // 0000002EE798: D5207C22 01AA440E
	v_add_f32_e32 v21, v21, v5                                 // 0000002EE7A0: 062A0B15
	s_clause 0x1                                               // 0000002EE7A4: BF850001
	global_load_b128 v[5:8], v[29:30], off                     // 0000002EE7A8: DC5E0000 057C001D
	global_load_b128 v[29:32], v[29:30], off offset:16         // 0000002EE7B0: DC5E0010 1D7C001D
	s_waitcnt vmcnt(1)                                         // 0000002EE7B8: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 0000002EE7BC: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE7C4: BF870091
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 0000002EE7C8: CC1A4005 1C164D06
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 0000002EE7D0: CC1A4005 1C164F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EE7D8: BF8700A1
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 0000002EE7DC: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 0000002EE7E4: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000002EE7E8: CC1A4005 1C16531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE7F0: BF870091
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000002EE7F4: CC1A4005 1C16551E
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 0000002EE7FC: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE804: BF870091
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 0000002EE808: CC1A4005 1C165920
	v_add_f32_e32 v26, v26, v5                                 // 0000002EE810: 06340B1A
	s_clause 0x1                                               // 0000002EE814: BF850001
	global_load_b128 v[5:8], v[35:36], off                     // 0000002EE818: DC5E0000 057C0023
	global_load_b128 v[29:32], v[35:36], off offset:16         // 0000002EE820: DC5E0010 1D7C0023
	.long 0xd7006a23                                           // 0000002EE828: D7006A23
	v_cndmask_b32_e32 v0, v35, v4, vcc_lo                      // 0000002EE82C: 02000923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002EE830: BF8700B1
	v_add_co_ci_u32_e64 v36, null, s5, v36, vcc_lo             // 0000002EE834: D5207C24 01AA4805
	s_waitcnt vmcnt(1)                                         // 0000002EE83C: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 0000002EE840: CC1A4005 1A024B05
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 0000002EE848: CC1A4005 1C164D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE850: BF870091
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 0000002EE854: CC1A4005 1C164F07
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 0000002EE85C: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 0000002EE864: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE868: BF870091
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000002EE86C: CC1A4005 1C16531D
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000002EE874: CC1A4005 1C16551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE87C: BF870091
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 0000002EE880: CC1A4005 1C16571F
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 0000002EE888: CC1A4005 1C165920
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002EE890: BF870001
	v_add_f32_e32 v25, v25, v5                                 // 0000002EE894: 06320B19
	s_clause 0x1                                               // 0000002EE898: BF850001
	global_load_b128 v[5:8], v[33:34], off                     // 0000002EE89C: DC5E0000 057C0021
	global_load_b128 v[29:32], v[33:34], off offset:16         // 0000002EE8A4: DC5E0010 1D7C0021
	s_waitcnt vmcnt(1)                                         // 0000002EE8AC: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 0000002EE8B0: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE8B8: BF870091
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 0000002EE8BC: CC1A4005 1C164D06
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 0000002EE8C4: CC1A4005 1C164F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EE8CC: BF8700A1
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 0000002EE8D0: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 0000002EE8D8: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000002EE8DC: CC1A4005 1C16531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE8E4: BF870091
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000002EE8E8: CC1A4005 1C16551E
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 0000002EE8F0: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE8F8: BF870091
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 0000002EE8FC: CC1A4005 1C165920
	v_add_f32_e32 v24, v24, v5                                 // 0000002EE904: 06300B18
	s_clause 0x1                                               // 0000002EE908: BF850001
	global_load_b128 v[5:8], v[35:36], off                     // 0000002EE90C: DC5E0000 057C0023
	global_load_b128 v[29:32], v[35:36], off offset:16         // 0000002EE914: DC5E0010 1D7C0023
	s_waitcnt vmcnt(1)                                         // 0000002EE91C: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 0000002EE920: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE928: BF870091
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 0000002EE92C: CC1A4005 1C164D06
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 0000002EE934: CC1A4005 1C164F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EE93C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 0000002EE940: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 0000002EE948: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000002EE94C: CC1A4005 1C16531D
	.long 0xd7006a1d                                           // 0000002EE954: D7006A1D
	v_cndmask_b32_e32 v0, v33, v4, vcc_lo                      // 0000002EE958: 02000921
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EE95C: BF870122
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000002EE960: CC1A4005 1C16551E
	v_add_co_ci_u32_e64 v30, null, s5, v34, vcc_lo             // 0000002EE968: D5207C1E 01AA4405
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 0000002EE970: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE978: BF870091
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 0000002EE97C: CC1A4005 1C165920
	v_add_f32_e32 v23, v23, v5                                 // 0000002EE984: 062E0B17
	s_clause 0x1                                               // 0000002EE988: BF850001
	global_load_b128 v[5:8], v[29:30], off                     // 0000002EE98C: DC5E0000 057C001D
	global_load_b128 v[29:32], v[29:30], off offset:16         // 0000002EE994: DC5E0010 1D7C001D
	s_waitcnt vmcnt(1)                                         // 0000002EE99C: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 0000002EE9A0: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE9A8: BF870091
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 0000002EE9AC: CC1A4005 1C164D06
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 0000002EE9B4: CC1A4005 1C164F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EE9BC: BF8700A1
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 0000002EE9C0: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 0000002EE9C8: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000002EE9CC: CC1A4005 1C16531D
	.long 0xd7006a1d                                           // 0000002EE9D4: D7006A1D
	v_cndmask_b32_e32 v0, v35, v4, vcc_lo                      // 0000002EE9D8: 02000923
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EE9DC: BF870122
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000002EE9E0: CC1A4005 1C16551E
	v_add_co_ci_u32_e64 v30, null, s5, v36, vcc_lo             // 0000002EE9E8: D5207C1E 01AA4805
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 0000002EE9F0: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EE9F8: BF870091
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 0000002EE9FC: CC1A4005 1C165920
	v_add_f32_e32 v22, v22, v5                                 // 0000002EEA04: 062C0B16
	s_clause 0x1                                               // 0000002EEA08: BF850001
	global_load_b128 v[5:8], v[29:30], off                     // 0000002EEA0C: DC5E0000 057C001D
	global_load_b128 v[29:32], v[29:30], off offset:16         // 0000002EEA14: DC5E0010 1D7C001D
	s_waitcnt vmcnt(1)                                         // 0000002EEA1C: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 0000002EEA20: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EEA28: BF870121
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 0000002EEA2C: CC1A4005 1C164D06
	v_mov_b32_e32 v6, v2                                       // 0000002EEA34: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 0000002EEA38: CC1A4005 1C164F07
	v_mov_b32_e32 v7, v3                                       // 0000002EEA40: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002EEA44: BF870132
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 0000002EEA48: CC1A4005 1C165108
	v_mov_b32_e32 v8, v4                                       // 0000002EEA50: 7E100304
	s_waitcnt vmcnt(0)                                         // 0000002EEA54: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000002EEA58: CC1A4005 1C16531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EEA60: BF870091
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000002EEA64: CC1A4005 1C16551E
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 0000002EEA6C: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EEA74: BF870091
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 0000002EEA78: CC1A4005 1C165920
	v_dual_add_f32 v16, v16, v5 :: v_dual_mov_b32 v5, v1       // 0000002EEA80: C9100B10 10040101
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000002EEA88: 917E0F7E
	s_cbranch_execz 30                                         // 0000002EEA8C: BFA5001E <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi32ELi2EEEvPKhPKtPtll+0x908>
	v_dual_mov_b32 v2, v6 :: v_dual_add_nc_u32 v17, 32, v17    // 0000002EEA90: CA200106 021022A0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002EEA98: BF8701B2
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v4, v8             // 0000002EEA9C: CA100105 01040108
	v_mov_b32_e32 v3, v7                                       // 0000002EEAA4: 7E060307
	s_mov_b32 s17, exec_lo                                     // 0000002EEAA8: BE91007E
	v_cmp_ge_i32_e32 vcc_lo, v17, v18                          // 0000002EEAAC: 7C8C2511
	.long 0xd4c1007e                                           // 0000002EEAB0: D4C1007E
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000002EEAB4: 02022511
	s_cbranch_execz 65085                                      // 0000002EEAB8: BFA5FE3D <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi32ELi2EEEvPKhPKtPtll+0x1b0>
	v_and_b32_e32 v3, -4, v17                                  // 0000002EEABC: 360622C4
	v_ashrrev_i32_e32 v2, 31, v27                              // 0000002EEAC0: 3404369F
	.long 0xd7000001                                           // 0000002EEAC4: D7000001
	v_cndmask_b32_e32 v1, v9, v27, vcc_lo                      // 0000002EEAC8: 02023709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EEACC: BF870193
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002EEAD0: 3408069F
	v_add_co_ci_u32_e64 v2, null, v10, v2, s0                  // 0000002EEAD4: D5207C02 0002050A
	.long 0xd700001c                                           // 0000002EEADC: D700001C
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 0000002EEAE0: 02020713
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002EEAE4: BF870001
	v_add_co_ci_u32_e64 v29, null, v20, v4, s0                 // 0000002EEAE8: D5207C1D 00020914
	s_clause 0x1                                               // 0000002EEAF0: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 0000002EEAF4: DC5E0000 017C0001
	global_load_b32 v28, v[28:29], off                         // 0000002EEAFC: DC520000 1C7C001C
	s_branch 65066                                             // 0000002EEB04: BFA0FE2A <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi32ELi2EEEvPKhPKtPtll+0x1b0>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000002EEB08: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002EEB0C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002EEB10: 8C7E017E
	.long 0xd71f0001                                           // 0000002EEB14: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002EEB18: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000002EEB1C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000002EEB20: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 0000002EEB24: 3A120288
	v_xor_b32_e32 v19, 4, v1                                   // 0000002EEB28: 3A260284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002EEB2C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000002EEB30: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000002EEB34: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000002EEB38: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 0000002EEB3C: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 0000002EEB40: 7C9826A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002EEB44: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000002EEB48: 30121282
	v_dual_cndmask_b32 v19, v1, v19 :: v_dual_lshlrev_b32 v2, 2, v2// 0000002EEB4C: CA622701 13020482
	ds_bpermute_b32 v3, v2, v21                                // 0000002EEB54: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 0000002EEB5C: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 0000002EEB60: 06060715
	ds_bpermute_b32 v4, v2, v26                                // 0000002EEB64: DACC0000 04001A02
	s_waitcnt vmcnt(1)                                         // 0000002EEB6C: BF8907F7
	ds_bpermute_b32 v5, v2, v25                                // 0000002EEB70: DACC0000 05001902
	ds_bpermute_b32 v6, v2, v24                                // 0000002EEB78: DACC0000 06001802
	ds_bpermute_b32 v7, v2, v23                                // 0000002EEB80: DACC0000 07001702
	ds_bpermute_b32 v8, v2, v22                                // 0000002EEB88: DACC0000 08001602
	ds_bpermute_b32 v2, v2, v16                                // 0000002EEB90: DACC0000 02001002
	ds_bpermute_b32 v10, v9, v3                                // 0000002EEB98: DACC0000 0A000309
	s_waitcnt lgkmcnt(5)                                       // 0000002EEBA0: BF89FC57
	v_dual_add_f32 v4, v26, v4 :: v_dual_add_f32 v5, v25, v5   // 0000002EEBA4: C908091A 04040B19
	s_waitcnt lgkmcnt(3)                                       // 0000002EEBAC: BF89FC37
	v_dual_add_f32 v6, v24, v6 :: v_dual_add_f32 v7, v23, v7   // 0000002EEBB0: C9080D18 06060F17
	s_waitcnt lgkmcnt(2)                                       // 0000002EEBB8: BF89FC27
	v_add_f32_e32 v8, v22, v8                                  // 0000002EEBBC: 06101116
	ds_bpermute_b32 v11, v9, v4                                // 0000002EEBC0: DACC0000 0B000409
	s_waitcnt lgkmcnt(2)                                       // 0000002EEBC8: BF89FC27
	v_add_f32_e32 v2, v16, v2                                  // 0000002EEBCC: 06040510
	ds_bpermute_b32 v16, v9, v6                                // 0000002EEBD0: DACC0000 10000609
	s_waitcnt vmcnt(0)                                         // 0000002EEBD8: BF8903F7
	ds_bpermute_b32 v12, v9, v5                                // 0000002EEBDC: DACC0000 0C000509
	ds_bpermute_b32 v17, v9, v7                                // 0000002EEBE4: DACC0000 11000709
	ds_bpermute_b32 v18, v9, v8                                // 0000002EEBEC: DACC0000 12000809
	ds_bpermute_b32 v9, v9, v2                                 // 0000002EEBF4: DACC0000 09000209
	v_lshlrev_b32_e32 v19, 2, v19                              // 0000002EEBFC: 30262682
	s_waitcnt lgkmcnt(5)                                       // 0000002EEC00: BF89FC57
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v4, v4, v11   // 0000002EEC04: C9081503 03041704
	s_waitcnt lgkmcnt(4)                                       // 0000002EEC0C: BF89FC47
	v_add_f32_e32 v6, v6, v16                                  // 0000002EEC10: 060C2106
	s_waitcnt lgkmcnt(1)                                       // 0000002EEC14: BF89FC17
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v8, v8, v18   // 0000002EEC18: C9081905 05082508
	ds_bpermute_b32 v10, v19, v4                               // 0000002EEC20: DACC0000 0A000413
	v_add_f32_e32 v7, v7, v17                                  // 0000002EEC28: 060E2307
	s_waitcnt lgkmcnt(1)                                       // 0000002EEC2C: BF89FC17
	v_add_f32_e32 v2, v2, v9                                   // 0000002EEC30: 06041302
	ds_bpermute_b32 v9, v19, v3                                // 0000002EEC34: DACC0000 09000313
	ds_bpermute_b32 v11, v19, v5                               // 0000002EEC3C: DACC0000 0B000513
	ds_bpermute_b32 v12, v19, v6                               // 0000002EEC44: DACC0000 0C000613
	ds_bpermute_b32 v17, v19, v8                               // 0000002EEC4C: DACC0000 11000813
	ds_bpermute_b32 v18, v19, v2                               // 0000002EEC54: DACC0000 12000213
	s_waitcnt lgkmcnt(5)                                       // 0000002EEC5C: BF89FC57
	v_add_f32_e32 v4, v4, v10                                  // 0000002EEC60: 06081504
	ds_bpermute_b32 v16, v19, v7                               // 0000002EEC64: DACC0000 10000713
	v_xor_b32_e32 v19, 2, v1                                   // 0000002EEC6C: 3A260282
	s_waitcnt lgkmcnt(3)                                       // 0000002EEC70: BF89FC37
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v6, v6, v12   // 0000002EEC74: C9081705 05061906
	s_waitcnt lgkmcnt(2)                                       // 0000002EEC7C: BF89FC27
	v_add_f32_e32 v8, v8, v17                                  // 0000002EEC80: 06102308
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 0000002EEC84: 7C9826A0
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 0000002EEC88: 02262701
	s_waitcnt lgkmcnt(1)                                       // 0000002EEC8C: BF89FC17
	v_dual_add_f32 v3, v3, v9 :: v_dual_add_f32 v10, v2, v18   // 0000002EEC90: C9081303 030A2502
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002EEC98: BF870002
	v_lshlrev_b32_e32 v19, 2, v19                              // 0000002EEC9C: 30262682
	ds_bpermute_b32 v9, v19, v4                                // 0000002EECA0: DACC0000 09000413
	s_waitcnt lgkmcnt(1)                                       // 0000002EECA8: BF89FC17
	v_add_f32_e32 v7, v7, v16                                  // 0000002EECAC: 060E2107
	ds_bpermute_b32 v2, v19, v3                                // 0000002EECB0: DACC0000 02000313
	ds_bpermute_b32 v11, v19, v5                               // 0000002EECB8: DACC0000 0B000513
	ds_bpermute_b32 v12, v19, v6                               // 0000002EECC0: DACC0000 0C000613
	ds_bpermute_b32 v17, v19, v8                               // 0000002EECC8: DACC0000 11000813
	ds_bpermute_b32 v18, v19, v10                              // 0000002EECD0: DACC0000 12000A13
	s_waitcnt lgkmcnt(5)                                       // 0000002EECD8: BF89FC57
	v_add_f32_e32 v4, v4, v9                                   // 0000002EECDC: 06081304
	ds_bpermute_b32 v16, v19, v7                               // 0000002EECE0: DACC0000 10000713
	v_xor_b32_e32 v19, 1, v1                                   // 0000002EECE8: 3A260281
	s_waitcnt lgkmcnt(2)                                       // 0000002EECEC: BF89FC27
	v_dual_add_f32 v6, v6, v12 :: v_dual_add_f32 v9, v8, v17   // 0000002EECF0: C9081906 06082308
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EECF8: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 0000002EECFC: 7C9826A0
	v_cndmask_b32_e32 v1, v1, v19, vcc_lo                      // 0000002EED00: 02022701
	v_lshlrev_b32_e32 v19, 2, v1                               // 0000002EED04: 30260282
	v_dual_add_f32 v1, v3, v2 :: v_dual_add_f32 v2, v5, v11    // 0000002EED08: C9080503 01021705
	s_waitcnt lgkmcnt(1)                                       // 0000002EED10: BF89FC17
	v_add_f32_e32 v5, v10, v18                                 // 0000002EED14: 060A250A
	s_waitcnt lgkmcnt(0)                                       // 0000002EED18: BF89FC07
	v_add_f32_e32 v3, v7, v16                                  // 0000002EED1C: 06062107
	ds_bpermute_b32 v11, v19, v4                               // 0000002EED20: DACC0000 0B000413
	ds_bpermute_b32 v7, v19, v1                                // 0000002EED28: DACC0000 07000113
	ds_bpermute_b32 v8, v19, v2                                // 0000002EED30: DACC0000 08000213
	ds_bpermute_b32 v16, v19, v6                               // 0000002EED38: DACC0000 10000613
	ds_bpermute_b32 v10, v19, v3                               // 0000002EED40: DACC0000 0A000313
	ds_bpermute_b32 v17, v19, v9                               // 0000002EED48: DACC0000 11000913
	ds_bpermute_b32 v12, v19, v5                               // 0000002EED50: DACC0000 0C000513
	v_cmpx_eq_u32_e32 0, v15                                   // 0000002EED58: 7D941E80
	s_cbranch_execz 22                                         // 0000002EED5C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi32ELi2EEEvPKhPKtPtll+0xbb8>
	.long 0xd72c000d                                           // 0000002EED60: D72C000D
	v_cndmask_b32_e32 v0, v13, v184, vcc_lo                    // 0000002EED64: 0201710D
	s_waitcnt lgkmcnt(2)                                       // 0000002EED68: BF89FC27
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v3, v3, v10   // 0000002EED6C: C9081704 04021503
	v_dual_add_f32 v1, v1, v7 :: v_dual_add_f32 v2, v2, v8     // 0000002EED74: C9080F01 01021102
	s_waitcnt lgkmcnt(1)                                       // 0000002EED7C: BF89FC17
	v_dual_add_f32 v9, v9, v17 :: v_dual_add_f32 v6, v6, v16   // 0000002EED80: C9082309 09062106
	s_waitcnt lgkmcnt(0)                                       // 0000002EED88: BF89FC07
	v_add_f32_e32 v5, v5, v12                                  // 0000002EED8C: 060A1905
	v_mad_u32_u24 v7, v14, 28, v13                             // 0000002EED90: D60B0007 0435390E
	ds_store_2addr_b32 v7, v1, v4 offset1:1                    // 0000002EED98: D8380100 00040107
	ds_store_2addr_b32 v7, v2, v6 offset0:2 offset1:3          // 0000002EEDA0: D8380302 00060207
	ds_store_2addr_b32 v7, v3, v9 offset0:4 offset1:5          // 0000002EEDA8: D8380504 00090307
	ds_store_b32 v7, v5 offset:24                              // 0000002EEDB0: D8340018 00000507
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002EEDB8: 8C7E007E
	.long 0xd7050001                                           // 0000002EEDBC: D7050001
	v_cndmask_b32_e32 v0, v0, v165, vcc_lo                     // 0000002EEDC0: 02014B00
	.long 0x7f063880                                           // 0000002EEDC4: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 0000002EEDC8: BF89FC07
	s_barrier                                                  // 0000002EEDCC: BFBD0000
	buffer_gl0_inv                                             // 0000002EEDD0: E0AC0000 00000000
	.long 0xd7390001                                           // 0000002EEDD8: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 0000002EEDDC: 02020288
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EEDE0: BF870091
	.long 0xd7044001                                           // 0000002EEDE4: D7044001
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000002EEDE8: 02020300
	.long 0xd7395001                                           // 0000002EEDEC: D7395001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002EEDF0: 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EEDF4: BF870091
	.long 0xd7625001                                           // 0000002EEDF8: D7625001
	v_cndmask_b32_e32 v1, 0x7f, v1, vcc_lo                     // 0000002EEDFC: 020202FF 0000007F
	.long 0xd7030801                                           // 0000002EEE04: D7030801
	v_cndmask_b32_e32 v1, v1, v1, vcc_lo                       // 0000002EEE08: 02020301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EEE0C: BF870091
	.long 0xd7390003                                           // 0000002EEE10: D7390003
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000002EEE14: 02020282
	.long 0xd7000001                                           // 0000002EEE18: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 0000002EEE1C: 02020602
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EEE20: BF870121
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 0000002EEE24: D5207C02 00010003
	.long 0xd44c0000                                           // 0000002EEE2C: D44C0000
	v_cndmask_b32_e32 v1, 28, v0, vcc_lo                       // 0000002EEE30: 0202009C
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000002EEE34: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 0000002EEE38: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002EEE3C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000002EEE40: BE812000
	s_cbranch_execz 43                                         // 0000002EEE44: BFA5002B <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi32ELi2EEEvPKhPKtPtll+0xcf4>
	.long 0xd7054000                                           // 0000002EEE48: D7054000
	v_cndmask_b32_e32 v0, v3, v135, vcc_lo                     // 0000002EEE4C: 02010F03
	v_mul_u32_u24_e32 v3, 56, v3                               // 0000002EEE50: 160606B8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EEE54: BF870092
	.long 0xd7041000                                           // 0000002EEE58: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000002EEE5C: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 0000002EEE60: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002EEE68: BF8700B1
	v_lshl_add_u32 v3, v0, 2, v3                               // 0000002EEE6C: D6460003 040D0500
	ds_load_2addr_b32 v[6:7], v3 offset1:7                     // 0000002EEE74: D8DC0700 06000003
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 0000002EEE7C: D6FE7C03 0202000C
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 0000002EEE84: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002EEE8C: BF870131
	.long 0xd73c0003                                           // 0000002EEE90: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000002EEE94: 02020681
	s_waitcnt lgkmcnt(0)                                       // 0000002EEE98: BF89FC07
	v_add_f32_e32 v0, 0, v6                                    // 0000002EEE9C: 06000C80
	.long 0xd7006a03                                           // 0000002EEEA0: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 0000002EEEA4: 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002EEEA8: BF8701B2
	v_add_f32_e32 v5, v0, v7                                   // 0000002EEEAC: 060A0F00
	.long 0xd73c0000                                           // 0000002EEEB0: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002EEEB4: 02020281
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000002EEEB8: D5207C04 01AA0809
	v_bfe_u32 v2, v5, 16, 1                                    // 0000002EEEC0: D6100002 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EEEC8: BF870093
	.long 0xd7006a00                                           // 0000002EEECC: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 0000002EEED0: 02020103
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000002EEED4: D5207C01 01AA0304
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002EEEDC: BF870003
	v_add3_u32 v2, v5, v2, 0x7fff                              // 0000002EEEE0: D6550002 03FE0505 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002EEEEC: DC960000 007C0200
	s_endpgm                                                   // 0000002EEEF4: BFB00000
		...

