0000000000537600 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x3                                               // 000000537600: BF850003
	s_load_b256 s[12:19], s[0:1], null                         // 000000537604: F40C0300 F8000000
	s_load_b256 s[20:27], s[0:1], 0x20                         // 00000053760C: F40C0500 F8000020
	s_load_b128 s[28:31], s[0:1], 0x40                         // 000000537614: F4080700 F8000040
	s_load_b32 s33, s[0:1], 0x54                               // 00000053761C: F4000840 F8000054
	v_and_b32_e32 v21, 31, v0                                  // 000000537624: 362A009F
	v_lshrrev_b32_e32 v19, 5, v0                               // 000000537628: 32260085
	s_mov_b32 s10, s3                                          // 00000053762C: BE8A0003
	s_mov_b32 s35, exec_lo                                     // 000000537630: BEA3007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000537634: BF870002
	v_lshlrev_b32_e32 v20, 2, v21                              // 000000537638: 30282A82
	s_waitcnt lgkmcnt(0)                                       // 00000053763C: BF89FC07
	s_ashr_i32 s34, s17, 31                                    // 000000537640: 86229F11
	s_mul_i32 s11, s19, s3                                     // 000000537644: 960B0313
	s_lshr_b32 s0, s34, 25                                     // 000000537648: 85009922
	s_add_i32 s1, s11, s19                                     // 00000053764C: 8101130B
	s_add_i32 s0, s17, s0                                      // 000000537650: 81000011
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000537654: BF870499
	s_ashr_i32 s0, s0, 7                                       // 000000537658: 86008700
	s_min_i32 s0, s0, s1                                       // 00000053765C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000537660: BF870499
	s_sub_i32 s9, s0, s11                                      // 000000537664: 81890B00
	s_lshl_b32 s19, s9, 2                                      // 000000537668: 84138209
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000053766C: BF870009
	.long 0xd4c4007e                                           // 000000537670: D4C4007E
	v_cndmask_b32_e32 v1, s19, v19, vcc_lo                     // 000000537674: 02022613
	s_cbranch_execz 499                                        // 000000537678: BFA501F3 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x848>
	s_add_i32 s36, s16, -1                                     // 00000053767C: 8124C110
	s_cmp_lg_u64 s[30:31], 0                                   // 000000537680: BF11801E
	v_and_b32_e32 v2, 2, v0                                    // 000000537684: 36040082
	s_cselect_b32 s37, -1, 0                                   // 000000537688: 982580C1
	s_abs_i32 s38, s9                                          // 00000053768C: BEA61509
	v_lshlrev_b32_e32 v6, 3, v21                               // 000000537690: 300C2A83
	s_cvt_f32_u32 s0, s38                                      // 000000537694: BE806526
	v_dual_mov_b32 v8, v19 :: v_dual_and_b32 v1, 1, v0         // 000000537698: CA240113 08000081
	v_and_b32_e32 v4, 4, v0                                    // 0000005376A0: 36080084
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005376A4: BF870009
	v_rcp_iflag_f32_e32 v3, s0                                 // 0000005376A8: 7E065600
	v_and_b32_e32 v5, 8, v0                                    // 0000005376AC: 360A0088
	v_add_nc_u32_e32 v7, s11, v19                              // 0000005376B0: 4A0E260B
	.long 0xd44a0003                                           // 0000005376B4: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000005376B8: 02020480
	v_lshl_or_b32 v2, v19, 8, v6                               // 0000005376BC: D6560002 04191113
	s_ashr_i32 s42, s9, 31                                     // 0000005376C4: 862A9F09
	s_sub_i32 s8, 0, s38                                       // 0000005376C8: 81882680
	s_mul_i32 s44, s42, 0x1400                                 // 0000005376CC: 962CFF2A 00001400
	.long 0xd44c0000                                           // 0000005376D4: D44C0000
	v_cndmask_b32_e32 v1, 16, v21, vcc_lo                      // 0000005376D8: 02022A90
	.long 0xd44a0001                                           // 0000005376DC: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000005376E0: 02020280
	v_readfirstlane_b32 s4, v3                                 // 0000005376E4: 7E080503
	.long 0xd44a0005                                           // 0000005376E8: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000005376EC: 02020A80
	v_lshl_or_b32 v1, v7, 7, v20                               // 0000005376F0: D6560001 04510F07
	v_subrev_nc_u32_e32 v9, s44, v2                            // 0000005376F8: 4E12042C
	s_lshl_b32 s6, s9, 7                                       // 0000005376FC: 84068709
	s_mul_f32 s7, s4, 0x4f7ffffe                               // 000000537700: A207FF04 4F7FFFFE
	.long 0xd44a0004                                           // 000000537708: D44A0004
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 00000053770C: 02020880
	s_mov_b32 s39, s17                                         // 000000537710: BEA70011
	s_mov_b32 s40, 0                                           // 000000537714: BEA80080
	s_cvt_u32_f32 s7, s7                                       // 000000537718: BE876707
	s_mov_b32 s41, 0x76543210                                  // 00000053771C: BEA900FF 76543210
	s_lshl_b32 s43, s9, 8                                      // 000000537724: 842B8809
	s_sub_i32 s44, 0, s6                                       // 000000537728: 81AC0680
	s_mul_i32 s8, s8, s7                                       // 00000053772C: 96080708
	s_mov_b32 s46, 0x3db504f3                                  // 000000537730: BEAE00FF 3DB504F3
	s_mul_hi_u32 s8, s7, s8                                    // 000000537738: 96880807
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000053773C: BF870009
	s_add_i32 s45, s7, s8                                      // 000000537740: 812D0807
	s_branch 164                                               // 000000537744: BFA000A4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3d8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000537748: BF870091
	.long 0xd7006a02                                           // 00000053774C: D7006A02
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000537750: 02020414
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo              // 000000537754: D5207C03 01AA0615
	v_sub_f32_e32 v4, v15, v13                                 // 00000053775C: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000537760: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000537768: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000537770: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 000000537774: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 00000053777C: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 000000537784: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000537788: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 00000053778C: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000537790: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000537794: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000537798: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000053779C: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005377A0: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005377A8: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000005377B0: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 0000005377B8: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000005377C0: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 0000005377C4: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005377C8: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000005377D0: D5010007 20060F07
	.long 0xd72c0006                                           // 0000005377D8: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 0000005377DC: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 0000005377E4: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005377E8: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000005377F0: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005377F8: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 0000005377FC: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000537800: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000537808: D5010003 20060703
	.long 0xd72c0007                                           // 000000537810: D72C0007
	v_cndmask_b32_e32 v1, s43, v10, vcc_lo                     // 000000537814: 0202142B
	v_add_f32_e32 v2, v2, v13                                  // 000000537818: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000053781C: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000537824: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 00000053782C: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000537830: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000537834: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 00000053783C: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 000000537844: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000537848: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000537850: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000537858: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000537860: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 000000537868: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000053786C: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 000000537874: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000537878: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 000000537880: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000537884: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 00000053788C: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000537894: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 00000053789C: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005378A4: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 0000005378AC: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 0000005378B4: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 0000005378B8: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 0000005378BC: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005378C0: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 0000005378C4: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005378C8: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 0000005378D0: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000005378D8: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005378DC: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 0000005378E4: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 0000005378EC: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005378F0: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 0000005378F8: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 000000537900: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 000000537908: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s19, v8                           // 00000053790C: 7C861013
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000537910: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 000000537914: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 00000053791C: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000537924: BF870234
	v_mov_b32_e32 v13, v2                                      // 000000537928: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 00000053792C: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000537934: D5010004 20020904
	v_permlanex16_b32 v11, v11, s41, 0xfedcba98                // 00000053793C: D65C000B 03FC530B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 000000537948: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 00000053794C: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000537954: D5010003 20020703
	v_permlanex16_b32 v10, v10, s41, 0xfedcba98                // 00000053795C: D65C000A 03FC530A FEDCBA98
	v_permlanex16_b32 v13, v13, s41, 0xfedcba98                // 000000537968: D65C000D 03FC530D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 000000537974: 060A1705
	v_permlanex16_b32 v12, v12, s41, 0xfedcba98                // 000000537978: D65C000C 03FC530C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000537984: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 000000537988: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 000000537994: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000537998: BF870214
	v_fma_mixhi_f16 v2, v5, s46, 0                             // 00000053799C: CC220002 02005D05
	v_add_f32_e32 v10, v3, v12                                 // 0000005379A4: 06141903
	s_or_b32 s40, vcc_lo, s40                                  // 0000005379A8: 8C28286A
	v_fma_mixlo_f16 v2, v4, s46, 0                             // 0000005379AC: CC210002 02005D04
	v_fma_mixhi_f16 v3, v7, s46, 0                             // 0000005379B4: CC220003 02005D07
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005379BC: BF870003
	v_fma_mixlo_f16 v3, v10, s46, 0                            // 0000005379C0: CC210003 02005D0A
	ds_store_b64 v6, v[2:3]                                    // 0000005379C8: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 0000005379D0: 917E287E
	s_cbranch_execz 284                                        // 0000005379D4: BFA5011C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x848>
	.long 0xd72d0002                                           // 0000005379D8: D72D0002
	v_cndmask_b32_e32 v0, v8, v45, vcc_lo                      // 0000005379DC: 02005B08
	s_mov_b32 s6, -1                                           // 0000005379E0: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005379E4: BF870091
	.long 0xd72c0003                                           // 0000005379E8: D72C0003
	v_cndmask_b32_e32 v0, v2, v38, vcc_lo                      // 0000005379EC: 02004D02
	v_sub_nc_u32_e32 v3, v8, v3                                // 0000005379F0: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005379F4: BF870121
	v_subrev_nc_u32_e32 v5, s38, v3                            // 0000005379F8: 4E0A0626
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 0000005379FC: 7C960626
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000537A00: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000537A08: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000537A0C: 02040902
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000537A10: 7C960626
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000537A14: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000537A18: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000537A1C: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s37                        // 000000537A20: 916A257E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000537A24: BF870091
	v_xor_b32_e32 v11, s42, v2                                 // 000000537A28: 3A16042A
	v_subrev_nc_u32_e32 v10, s42, v11                          // 000000537A2C: 4E14162A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000537A30: BF8700A1
	v_mad_u64_u32 v[6:7], null, s44, v10, v[1:2]               // 000000537A34: D6FE7C06 0406142C
	v_min_i32_e32 v2, s36, v10                                 // 000000537A3C: 22041424
	v_mad_i64_i32 v[4:5], null, v2, s39, 0                     // 000000537A40: D6FF7C04 02004F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000537A48: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000537A4C: 340E0C9F
	.long 0xd73c0002                                           // 000000537A50: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000537A54: 02020C81
	s_cbranch_vccnz 207                                        // 000000537A58: BFA400CF <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x798>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000537A5C: BF870093
	.long 0xd7006a06                                           // 000000537A60: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000537A64: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000537A68: D5207C07 01AA0F05
	.long 0x7f3e3880                                           // 000000537A70: 7F3E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000537A74: BF870112
	.long 0xd73c0006                                           // 000000537A78: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000537A7C: 02020C81
	.long 0x7f44399f                                           // 000000537A80: 7F44399F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000537A84: BF870092
	.long 0xd7006a0c                                           // 000000537A88: D7006A0C
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 000000537A8C: 02020C0E
	v_add_co_ci_u32_e64 v13, null, s15, v7, vcc_lo             // 000000537A90: D5207C0D 01AA0E0F
	.long 0xd7006a06                                           // 000000537A98: D7006A06
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000537A9C: 02020C1E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000537AA0: BF870001
	v_add_co_ci_u32_e64 v7, null, s31, v7, vcc_lo              // 000000537AA4: D5207C07 01AA0E1F
	global_load_b64 v[12:13], v[12:13], off                    // 000000537AAC: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 000000537AB4: D7006A0E
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000537AB8: 02020414
	global_load_b64 v[6:7], v[6:7], off                        // 000000537ABC: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s21, v3, vcc_lo             // 000000537AC4: D5207C0F 01AA0615
	s_clause 0x1                                               // 000000537ACC: BF850001
	global_load_b32 v16, v[14:15], off                         // 000000537AD0: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 000000537AD8: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 000000537AE0: BF890FF7
	v_lshlrev_b32_e32 v17, 16, v13                             // 000000537AE4: 30221A90
	.long 0x7e1e390c                                           // 000000537AE8: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 000000537AEC: BF890BF7
	v_and_b32_e32 v41, 0xffff0000, v6                          // 000000537AF0: 36520CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000537AF8: BF870093
	v_dual_mul_f32 v23, 0xbfb8aa3b, v17 :: v_dual_lshlrev_b32 v6, 16, v6// 000000537AFC: C8E222FF 17060C90 BFB8AA3B
	v_exp_f32_e32 v23, v23                                     // 000000537B08: 7E2E4B17
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000537B0C: BF870095
	v_dual_add_f32 v23, 1.0, v23 :: v_dual_and_b32 v12, 0xffff0000, v12// 000000537B10: C9242EF2 170C18FF FFFF0000
	v_dual_mul_f32 v18, 0xbfb8aa3b, v12 :: v_dual_lshlrev_b32 v15, 16, v15// 000000537B1C: C8E218FF 120E1E90 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000537B28: BF870111
	v_mul_f32_e32 v22, 0xbfb8aa3b, v15                         // 000000537B2C: 102C1EFF BFB8AA3B
	v_exp_f32_e32 v18, v18                                     // 000000537B34: 7E244B12
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000537B38: 361A1AFF FFFF0000
	v_div_scale_f32 v27, null, v23, v23, v17                   // 000000537B40: D6FC7C1B 04462F17
	v_div_scale_f32 v37, s6, v17, v23, v17                     // 000000537B48: D6FC0625 04462F11
	v_exp_f32_e32 v22, v22                                     // 000000537B50: 7E2C4B16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 000000537B54: BF870392
	v_rcp_f32_e32 v32, v27                                     // 000000537B58: 7E40551B
	v_add_f32_e32 v18, 1.0, v18                                // 000000537B5C: 062424F2
	v_mul_f32_e32 v24, 0xbfb8aa3b, v13                         // 000000537B60: 10301AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000537B68: BF870196
	v_add_f32_e32 v22, 1.0, v22                                // 000000537B6C: 062C2CF2
	v_div_scale_f32 v25, null, v18, v18, v12                   // 000000537B70: D6FC7C19 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 000000537B78: BF870323
	v_exp_f32_e32 v24, v24                                     // 000000537B7C: 7E304B18
	v_div_scale_f32 v35, vcc_lo, v12, v18, v12                 // 000000537B80: D6FC6A23 0432250C
	v_fma_f32 v40, -v27, v32, 1.0                              // 000000537B88: D6130028 23CA411B
	v_div_scale_f32 v26, null, v22, v22, v15                   // 000000537B90: D6FC7C1A 043E2D16
	v_rcp_f32_e32 v28, v25                                     // 000000537B98: 7E385519
	v_div_scale_f32 v39, s7, v15, v22, v15                     // 000000537B9C: D6FC0727 043E2D0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000537BA4: BF870193
	v_fmac_f32_e32 v32, v40, v32                               // 000000537BA8: 56404128
	v_rcp_f32_e32 v30, v26                                     // 000000537BAC: 7E3C551A
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000537BB0: BF870117
	v_add_f32_e32 v24, 1.0, v24                                // 000000537BB4: 063030F2
	v_mul_f32_e32 v42, v37, v32                                // 000000537BB8: 10544125
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000537BBC: BF870196
	v_fma_f32 v36, -v25, v28, 1.0                              // 000000537BC0: D6130024 23CA3919
	v_div_scale_f32 v29, null, v24, v24, v13                   // 000000537BC8: D6FC7C1D 04363118
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000537BD0: BF870293
	v_fma_f32 v46, -v27, v42, v37                              // 000000537BD4: D613002E 2496551B
	v_fma_f32 v38, -v26, v30, 1.0                              // 000000537BDC: D6130026 23CA3D1A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000537BE4: BF870214
	v_fmac_f32_e32 v28, v36, v28                               // 000000537BE8: 56383924
	v_rcp_f32_e32 v33, v29                                     // 000000537BEC: 7E42551D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000537BF0: BF870193
	v_fmac_f32_e32 v42, v46, v32                               // 000000537BF4: 5654412E
	v_fmac_f32_e32 v30, v38, v30                               // 000000537BF8: 563C3D26
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000537BFC: BF870193
	v_mul_f32_e32 v40, v35, v28                                // 000000537C00: 10503923
	v_fma_f32 v27, -v27, v42, v37                              // 000000537C04: D613001B 2496551B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000537C0C: BF870292
	v_fma_f32 v43, -v25, v40, v35                              // 000000537C10: D613002B 248E5119
	v_fma_f32 v36, -v29, v33, 1.0                              // 000000537C18: D6130024 23CA431D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000537C20: BF8701B1
	v_dual_fmac_f32 v40, v43, v28 :: v_dual_fmac_f32 v33, v36, v33// 000000537C24: C800392B 28204324
	v_mul_f32_e32 v36, v39, v30                                // 000000537C2C: 10483D27
	v_div_scale_f32 v38, s8, v13, v24, v13                     // 000000537C30: D6FC0826 0436310D
	v_fma_f32 v25, -v25, v40, v35                              // 000000537C38: D6130019 248E5119
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000537C40: BF870193
	v_fma_f32 v45, -v26, v36, v39                              // 000000537C44: D613002D 249E491A
	v_mul_f32_e32 v44, v38, v33                                // 000000537C4C: 10584326
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000537C50: BF8701A3
	v_div_fmas_f32 v25, v25, v28, v40                          // 000000537C54: D6370019 04A23919
	s_mov_b32 vcc_lo, s7                                       // 000000537C5C: BEEA0007
	v_fmac_f32_e32 v36, v45, v30                               // 000000537C60: 56483D2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000537C64: BF870193
	v_fma_f32 v43, -v29, v44, v38                              // 000000537C68: D613002B 249A591D
	v_div_fixup_f32 v12, v25, v18, v12                         // 000000537C70: D627000C 04322519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000537C78: BF870193
	v_fma_f32 v26, -v26, v36, v39                              // 000000537C7C: D613001A 249E491A
	v_fmac_f32_e32 v44, v43, v33                               // 000000537C84: 5658432B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000537C88: BF870193
	v_mul_f32_e32 v12, v12, v41                                // 000000537C8C: 1018530C
	v_div_fmas_f32 v26, v26, v30, v36                          // 000000537C90: D637001A 04923D1A
	s_mov_b32 vcc_lo, s6                                       // 000000537C98: BEEA0006
	s_delay_alu instid0(VALU_DEP_3)                            // 000000537C9C: BF870003
	v_fma_f32 v25, -v29, v44, v38                              // 000000537CA0: D6130019 249A591D
	v_div_fmas_f32 v18, v27, v32, v42                          // 000000537CA8: D6370012 04AA411B
	s_mov_b32 vcc_lo, s8                                       // 000000537CB0: BEEA0008
	v_div_fixup_f32 v15, v26, v22, v15                         // 000000537CB4: D627000F 043E2D1A
	v_lshlrev_b32_e32 v22, 16, v7                              // 000000537CBC: 302C0E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000537CC0: 360E0EFF FFFF0000
	v_div_fixup_f32 v17, v18, v23, v17                         // 000000537CC8: D6270011 04462F12
	.long 0x7e3e398c                                           // 000000537CD0: 7E3E398C
	v_mul_f32_e32 v6, v15, v6                                  // 000000537CD4: 100C0D0F
	v_div_fmas_f32 v15, v25, v33, v44                          // 000000537CD8: D637000F 04B24319
	s_mov_b32 s6, 0                                            // 000000537CE0: BE860080
	v_mul_f32_e32 v17, v17, v22                                // 000000537CE4: 10222D11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000537CE8: BF870193
	.long 0x7e443986                                           // 000000537CEC: 7E443986
	v_div_fixup_f32 v13, v15, v24, v13                         // 000000537CF0: D627000D 0436310F
	v_and_b32_e32 v15, 1, v31                                  // 000000537CF8: 361E3E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000537CFC: BF870194
	v_bfe_u32 v18, v17, 16, 1                                  // 000000537D00: D6100012 02052111
	v_dual_mul_f32 v7, v13, v7 :: v_dual_and_b32 v22, 1, v34   // 000000537D08: C8E40F0D 07164481
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000537D10: BF870193
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000537D14: D655000C 03FE1F0C 00007FFF
	v_add3_u32 v13, v17, v18, 0x7fff                           // 000000537D20: D655000D 03FE2511 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000537D2C: BF870213
	v_add3_u32 v6, v6, v22, 0x7fff                             // 000000537D30: D6550006 03FE2D06 00007FFF
	v_bfe_u32 v15, v7, 16, 1                                   // 000000537D3C: D610000F 02052107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000537D44: BF870214
	v_and_b32_e32 v12, 0xffff0000, v12                         // 000000537D48: 361818FF FFFF0000
	v_and_b32_e32 v17, 0xffff0000, v13                         // 000000537D50: 36221AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000537D58: BF870214
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000537D5C: 360C0CFF FFFF0000
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000537D64: D6550007 03FE1F07 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000537D70: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000537D74: CC20080D 8A021910
	s_waitcnt vmcnt(0)                                         // 000000537D7C: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 000000537D80: CC20000C 8A02230E
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 000000537D88: CC20000F 8A020D10
	v_and_b32_e32 v14, 0xffff0000, v7                          // 000000537D90: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000537D98: 916A067E
	s_cbranch_vccnz 65130                                      // 000000537D9C: BFA4FE6A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x148>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000537DA0: BF870093
	.long 0xd73c0004                                           // 000000537DA4: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000537DA8: 02020881
	.long 0xd7006a04                                           // 000000537DAC: D7006A04
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 000000537DB0: 0202080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000537DB4: BF870111
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 000000537DB8: D5207C05 01AA0A0F
	.long 0xd7006a04                                           // 000000537DC0: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000537DC4: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000537DC8: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000537DCC: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000537DD4: D7006A06
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000537DD8: 02020414
	v_add_co_ci_u32_e64 v7, null, s21, v3, vcc_lo              // 000000537DDC: D5207C07 01AA0615
	global_load_b64 v[4:5], v[4:5], off                        // 000000537DE4: DC560000 047C0004
	s_clause 0x1                                               // 000000537DEC: BF850001
	global_load_b32 v14, v[6:7], off                           // 000000537DF0: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000537DF8: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000537E00: BF890BF7
	.long 0x7e0e3904                                           // 000000537E04: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000537E08: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 000000537E10: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000537E14: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000537E18: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000537E1C: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000537E20: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 000000537E28: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 000000537E2C: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 000000537E34: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 000000537E3C: 361C0AFF FFFF0000
	s_branch 65088                                             // 000000537E44: BFA0FE40 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x148>
	s_or_b32 exec_lo, exec_lo, s35                             // 000000537E48: 8C7E237E
	s_bfe_i32 s8, s9, 0x1001c                                  // 000000537E4C: 9388FF09 0001001C
	s_lshl_b32 s3, s9, 3                                       // 000000537E54: 84038309
	s_lshr_b64 s[0:1], s[8:9], 29                              // 000000537E58: 85809D08
	s_lshr_b32 s1, s34, 28                                     // 000000537E5C: 85019C22
	s_add_i32 s0, s0, 7                                        // 000000537E60: 81008700
	s_add_i32 s1, s17, s1                                      // 000000537E64: 81010111
	s_ashr_i32 s0, s0, 3                                       // 000000537E68: 86008300
	s_waitcnt lgkmcnt(0)                                       // 000000537E6C: BF89FC07
	.long 0xd72c0001                                           // 000000537E70: D72C0001
	v_cndmask_b32_e32 v1, s0, v19, vcc_lo                      // 000000537E74: 02022600
	s_barrier                                                  // 000000537E78: BFBD0000
	buffer_gl0_inv                                             // 000000537E7C: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 000000537E84: 4A040200
	s_ashr_i32 s0, s1, 4                                       // 000000537E88: 86008401
	s_lshl_b32 s1, s11, 3                                      // 000000537E8C: 8401830B
	s_mul_hi_i32 s4, s0, s2                                    // 000000537E90: 97040200
	s_mul_i32 s0, s0, s2                                       // 000000537E94: 96000200
	v_min_i32_e32 v23, s3, v2                                  // 000000537E98: 222E0403
	s_ashr_i32 s3, s1, 31                                      // 000000537E9C: 86039F01
	s_add_u32 s0, s0, s1                                       // 000000537EA0: 80000100
	s_addc_u32 s1, s4, s3                                      // 000000537EA4: 82010304
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000537EA8: BF870009
	s_lshl_b64 s[4:5], s[0:1], 10                              // 000000537EAC: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v23                           // 000000537EB0: 7C822F01
	s_add_u32 s1, s12, s4                                      // 000000537EB4: 8001040C
	s_addc_u32 s4, s13, s5                                     // 000000537EB8: 8204050D
	s_and_saveexec_b32 s3, vcc_lo                              // 000000537EBC: BE83206A
	s_cbranch_execz 93                                         // 000000537EC0: BFA5005D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xa38>
	.long 0xd7010002                                           // 000000537EC4: D7010002
	v_cndmask_b32_e32 v0, v21, v129, vcc_lo                    // 000000537EC8: 02010315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000537ECC: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 000000537ED0: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000537ED8: 3404029F
	.long 0xd44c0000                                           // 000000537EDC: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000537EE0: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000537EE4: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 000000537EE8: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 000000537EF4: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000537EFC: BF870114
	.long 0xd73c0005                                           // 000000537F00: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000537F04: 0202028A
	.long 0xd73c0002                                           // 000000537F08: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000537F0C: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000537F10: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 000000537F14: 30080E98
	v_bfe_i32 v7, v7, 7, 1                                     // 000000537F18: D6110007 02050F07
	.long 0xd7000008                                           // 000000537F20: D7000008
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000537F24: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000537F28: BF870211
	v_add_co_ci_u32_e64 v9, null, s4, v6, s0                   // 000000537F2C: D5207C09 00020C04
	v_ashrrev_i32_e32 v6, 22, v4                               // 000000537F34: 340C0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000537F38: BF870093
	.long 0xd7000004                                           // 000000537F3C: D7000004
	v_cndmask_b32_e32 v1, v8, v2, vcc_lo                       // 000000537F40: 02020508
	v_add_co_ci_u32_e64 v5, null, v9, v3, s0                   // 000000537F44: D5207C05 00020709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000537F4C: BF870093
	.long 0xd7000006                                           // 000000537F50: D7000006
	v_cndmask_b32_e32 v1, v8, v6, vcc_lo                       // 000000537F54: 02020D08
	v_add_co_ci_u32_e64 v7, null, v9, v7, s0                   // 000000537F58: D5207C07 00020F09
	.long 0xd7000008                                           // 000000537F60: D7000008
	v_cndmask_b32_e32 v1, v8, v20, vcc_lo                      // 000000537F64: 02022908
	s_delay_alu instid0(VALU_DEP_1)                            // 000000537F68: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v9, s0                    // 000000537F6C: D5207C09 00021280
	s_clause 0x17                                              // 000000537F74: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000537F78: DC520000 027C0004
	global_load_b32 v92, v[4:5], off offset:128                // 000000537F80: DC520080 5C7C0004
	global_load_b32 v89, v[4:5], off offset:256                // 000000537F88: DC520100 597C0004
	global_load_b32 v86, v[4:5], off offset:384                // 000000537F90: DC520180 567C0004
	global_load_b32 v83, v[4:5], off offset:512                // 000000537F98: DC520200 537C0004
	global_load_b32 v80, v[4:5], off offset:640                // 000000537FA0: DC520280 507C0004
	global_load_b32 v77, v[4:5], off offset:768                // 000000537FA8: DC520300 4D7C0004
	global_load_b32 v59, v[4:5], off offset:896                // 000000537FB0: DC520380 3B7C0004
	global_load_b32 v4, v[6:7], off                            // 000000537FB8: DC520000 047C0006
	global_load_b32 v93, v[6:7], off offset:128                // 000000537FC0: DC520080 5D7C0006
	global_load_b32 v90, v[6:7], off offset:256                // 000000537FC8: DC520100 5A7C0006
	global_load_b32 v87, v[6:7], off offset:384                // 000000537FD0: DC520180 577C0006
	global_load_b32 v84, v[6:7], off offset:512                // 000000537FD8: DC520200 547C0006
	global_load_b32 v81, v[6:7], off offset:640                // 000000537FE0: DC520280 517C0006
	global_load_b32 v78, v[6:7], off offset:768                // 000000537FE8: DC520300 4E7C0006
	global_load_b32 v60, v[6:7], off offset:896                // 000000537FF0: DC520380 3C7C0006
	global_load_b32 v3, v[8:9], off                            // 000000537FF8: DC520000 037C0008
	global_load_b32 v91, v[8:9], off offset:128                // 000000538000: DC520080 5B7C0008
	global_load_b32 v88, v[8:9], off offset:256                // 000000538008: DC520100 587C0008
	global_load_b32 v85, v[8:9], off offset:384                // 000000538010: DC520180 557C0008
	global_load_b32 v82, v[8:9], off offset:512                // 000000538018: DC520200 527C0008
	global_load_b32 v79, v[8:9], off offset:640                // 000000538020: DC520280 4F7C0008
	global_load_b32 v76, v[8:9], off offset:768                // 000000538028: DC520300 4C7C0008
	global_load_b32 v58, v[8:9], off offset:896                // 000000538030: DC520380 3A7C0008
	s_or_b32 exec_lo, exec_lo, s3                              // 000000538038: 8C7E037E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v25, 0             // 00000053803C: CA100080 16180080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v27, 0             // 000000538044: CA100080 181A0080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v31, 0             // 00000053804C: CA100080 1A1E0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v33, 0             // 000000538054: CA100080 1C200080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v35, 0             // 00000053805C: CA100080 1E220080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v37, 0             // 000000538064: CA100080 20240080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v39, 0             // 00000053806C: CA100080 22260080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v43, 0             // 000000538074: CA100080 242A0080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v45, 0             // 00000053807C: CA100080 262C0080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v29, 0             // 000000538084: CA100080 281C0080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v49, 0             // 00000053808C: CA100080 2A300080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v53, 0             // 000000538094: CA100080 2C340080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v47, 0             // 00000053809C: CA100080 2E2E0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v41, 0             // 0000005380A4: CA100080 30280080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v51, 0             // 0000005380AC: CA100080 34320080
	v_mov_b32_e32 v50, 0                                       // 0000005380B4: 7E640280
	v_mov_b32_e32 v54, 0                                       // 0000005380B8: 7E6C0280
	s_ashr_i32 s3, s2, 31                                      // 0000005380BC: 86039F02
	s_and_saveexec_b32 s0, vcc_lo                              // 0000005380C0: BE80206A
	s_cbranch_execz 1080                                       // 0000005380C4: BFA50438 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ba8>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v5, -1, v0      // 0000005380C8: CA200080 160400C1
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v55, 16, v0        // 0000005380D0: CA240080 18360090
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v56, 2, v21    // 0000005380D8: CA220080 19382A82
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005380E0: BF870123
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v5, 31, v5         // 0000005380E4: CA240080 1A040A9F
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 0000005380EC: CA100080 1B1C0080
	v_dual_mov_b32 v30, 0 :: v_dual_lshlrev_b32 v57, 2, v5     // 0000005380F4: CA220080 1E380A82
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 0000005380FC: CA100080 1F200080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 000000538104: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 00000053810C: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000538114: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 00000053811C: CA100080 27280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v43, 0             // 000000538124: CA100080 2A2A0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v45, 0             // 00000053812C: CA100080 2C2C0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v29, 0             // 000000538134: CA100080 2E1C0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v49, 0             // 00000053813C: CA100080 30300080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v53, 0             // 000000538144: CA100080 34340080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v50, 0             // 00000053814C: CA100080 2F320080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v54, 0             // 000000538154: CA100080 29360080
	v_mov_b32_e32 v51, 0                                       // 00000053815C: 7E660280
	s_mov_b32 s5, 0                                            // 000000538160: BE850080
	s_movk_i32 s6, 0x1eee                                      // 000000538164: B0061EEE
	s_branch 980                                               // 000000538168: BFA003D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1abc>
	s_or_b32 exec_lo, exec_lo, s7                              // 00000053816C: 8C7E077E
	s_waitcnt vmcnt(15)                                        // 000000538170: BF893FF7
	v_alignbit_b32 v2, v2, v4, 16                              // 000000538174: D6160002 02420902
	v_lshl_or_b32 v13, v1, 5, v55                              // 00000053817C: D656000D 04DD0B01
	s_waitcnt vmcnt(7)                                         // 000000538184: BF891FF7
	v_bfe_u32 v14, v3, 12, 16                                  // 000000538188: D610000E 02411903
	v_bfe_u32 v15, v3, 8, 16                                   // 000000538190: D610000F 02411103
	v_bfe_u32 v16, v3, 4, 16                                   // 000000538198: D6100010 02410903
	v_bfe_u32 v1, v2, 12, 16                                   // 0000005381A0: D6100001 02411902
	v_bfe_u32 v5, v2, 8, 16                                    // 0000005381A8: D6100005 02411102
	.long 0xd72c000e                                           // 0000005381B0: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 0000005381B4: 02021CFF 83DCD12D
	.long 0xd72c000f                                           // 0000005381BC: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 0000005381C0: 02021EFF 83DCD12D
	v_alignbit_b32 v92, v92, v93, 16                           // 0000005381C8: D616005C 0242BB5C
	.long 0xd72c005f                                           // 0000005381D0: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v1, vcc_lo               // 0000005381D4: 020202FF 83DCD12D
	.long 0xd72c0061                                           // 0000005381DC: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 0000005381E0: 02020AFF 83DCD12D
	s_waitcnt vmcnt(6)                                         // 0000005381E8: BF891BF7
	v_bfe_u32 v100, v91, 4, 16                                 // 0000005381EC: D6100064 0241095B
	v_alignbit_b32 v89, v89, v90, 16                           // 0000005381F4: D6160059 0242B559
	v_bfe_u32 v93, v92, 12, 16                                 // 0000005381FC: D610005D 0241195C
	v_sad_u8 v14, v14, 0, 0x6400                               // 000000538204: D622000E 03FD010E 00006400
	v_sad_u8 v99, v15, 0, 0x6400                               // 000000538210: D6220063 03FD010F 00006400
	v_alignbit_b32 v86, v86, v87, 16                           // 00000053821C: D6160056 0242AF56
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000538224: D622005F 03FD015F 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000538230: D6220061 03FD0161 00006400
	.long 0xd72c005d                                           // 00000053823C: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000538240: 0202BAFF 83DCD12D
	v_bfe_u32 v90, v89, 12, 16                                 // 000000538248: D610005A 02411959
	v_bfe_u32 v87, v86, 12, 16                                 // 000000538250: D6100057 02411956
	v_and_b32_e32 v95, 0xffff, v95                             // 000000538258: 36BEBEFF 0000FFFF
	v_alignbit_b32 v83, v83, v84, 16                           // 000000538260: D6160053 0242A953
	v_alignbit_b32 v80, v80, v81, 16                           // 000000538268: D6160050 0242A350
	.long 0xd72c005a                                           // 000000538270: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000538274: 0202B4FF 83DCD12D
	.long 0xd72c0057                                           // 00000053827C: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000538280: 0202AEFF 83DCD12D
	v_lshl_or_b32 v95, v97, 16, v95                            // 000000538288: D656005F 057D2161
	.long 0xd72c0061                                           // 000000538290: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 000000538294: 020220FF 83DCD12D
	v_sad_u8 v93, v93, 0, 0x6400                               // 00000053829C: D622005D 03FD015D 00006400
	v_bfe_u32 v84, v83, 12, 16                                 // 0000005382A8: D6100054 02411953
	v_bfe_u32 v81, v80, 12, 16                                 // 0000005382B0: D6100051 02411950
	v_pk_fma_f16 v95, v95, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005382B8: CC0E005F 0BFC0D5F 0000C931
	v_and_b32_e32 v4, 0xffff, v2                               // 0000005382C4: 360804FF 0000FFFF
	v_bfe_u32 v2, v2, 4, 16                                    // 0000005382CC: D6100002 02410902
	v_sad_u8 v90, v90, 0, 0x6400                               // 0000005382D4: D622005A 03FD015A 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 0000005382E0: D6220061 03FD0161 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 0000005382EC: D6220057 03FD0157 00006400
	.long 0xd72c0060                                           // 0000005382F8: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v4, vcc_lo               // 0000005382FC: 020208FF 83DCD12D
	.long 0xd72c0062                                           // 000000538304: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v2, vcc_lo               // 000000538308: 020204FF 83DCD12D
	.long 0xd72c0054                                           // 000000538310: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000538314: 0202A8FF 83DCD12D
	.long 0xd72c0051                                           // 00000053831C: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000538320: 0202A2FF 83DCD12D
	v_alignbit_b32 v77, v77, v78, 16                           // 000000538328: D616004D 02429D4D
	v_alignbit_b32 v59, v59, v60, 16                           // 000000538330: D616003B 0242793B
	v_cmp_eq_u32_e32 vcc_lo, v17, v23                          // 000000538338: 7C942F11
	v_and_b32_e32 v93, 0xffff, v93                             // 00000053833C: 36BABAFF 0000FFFF
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000538344: D6220060 03FD0160 00006400
	v_sad_u8 v98, v98, 0, 0x6400                               // 000000538350: D6220062 03FD0162 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 00000053835C: D6220054 03FD0154 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000538368: D6220051 03FD0151 00006400
	v_bfe_u32 v78, v77, 12, 16                                 // 000000538374: D610004E 0241194D
	v_lshlrev_b32_e32 v96, 16, v96                             // 00000053837C: 30C0C090
	v_bfe_u32 v60, v59, 12, 16                                 // 000000538380: D610003C 0241193B
	s_or_b32 s5, vcc_lo, s5                                    // 000000538388: 8C05056A
	v_and_b32_e32 v90, 0xffff, v90                             // 00000053838C: 36B4B4FF 0000FFFF
	.long 0xd72c004e                                           // 000000538394: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000538398: 02029CFF 83DCD12D
	v_and_or_b32 v96, 0xffff, v98, v96                         // 0000005383A0: D6570060 0582C4FF 0000FFFF
	.long 0xd72c003c                                           // 0000005383AC: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000005383B0: 020278FF 83DCD12D
	v_and_b32_e32 v84, 0xffff, v84                             // 0000005383B8: 36A8A8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005383C0: BF870003
	v_pk_fma_f16 v96, v96, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005383C4: CC0E0060 0BFC0D60 0000C931
	v_and_b32_e32 v94, 0xffff, v3                              // 0000005383D0: 36BC06FF 0000FFFF
	ds_load_b128 v[1:4], v13                                   // 0000005383D8: DBFC0000 0100000D
	ds_load_b128 v[5:8], v13 offset:5120                       // 0000005383E0: DBFC1400 0500000D
	ds_load_b128 v[9:12], v13 offset:10240                     // 0000005383E8: DBFC2800 0900000D
	v_and_b32_e32 v87, 0xffff, v87                             // 0000005383F0: 36AEAEFF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000005383F8: D622004E 03FD014E 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000538404: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000538410: BF870112
	v_and_b32_e32 v78, 0xffff, v78                             // 000000538414: 369C9CFF 0000FFFF
	v_and_b32_e32 v60, 0xffff, v60                             // 00000053841C: 367878FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 000000538424: BF89FC27
	v_dot2acc_f32_f16 v54, v95, v1                             // 000000538428: 046C035F
	s_waitcnt lgkmcnt(1)                                       // 00000053842C: BF89FC17
	v_dot2acc_f32_f16 v51, v95, v5                             // 000000538430: 04660B5F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000538434: BF8700A1
	v_dot2acc_f32_f16 v51, v96, v6                             // 000000538438: 04660D60
	.long 0xd72c005e                                           // 00000053843C: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000538440: 0202BCFF 83DCD12D
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000538448: D622005E 03FD015E 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000538454: BF870091
	v_lshlrev_b32_e32 v94, 16, v94                             // 000000538458: 30BCBC90
	v_and_or_b32 v94, 0xffff, v97, v94                         // 00000053845C: D657005E 057AC2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v54, v96, v2 :: v_dual_and_b32 v97, 0xffff, v92// 000000538468: CB240560 3660B8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000538474: BF870002
	v_pk_fma_f16 v94, v94, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000538478: CC0E005E 0BFC0D5E 0000C931
	v_and_b32_e32 v98, 0xffff, v14                             // 000000538484: 36C41CFF 0000FFFF
	ds_load_b128 v[13:16], v13 offset:15360                    // 00000053848C: DBFC3C00 0D00000D
	.long 0xd72c0061                                           // 000000538494: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000538498: 0202C2FF 83DCD12D
	v_lshl_or_b32 v98, v99, 16, v98                            // 0000005384A0: D6560062 05892163
	v_bfe_u32 v99, v91, 8, 16                                  // 0000005384A8: D6100063 0241115B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005384B0: BF870212
	v_pk_fma_f16 v98, v98, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005384B4: CC0E0062 0BFC0D62 0000C931
	v_sad_u8 v97, v97, 0, 0x6400                               // 0000005384C0: D6220061 03FD0161 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005384CC: BF870113
	.long 0xd72c0063                                           // 0000005384D0: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 0000005384D4: 0202C6FF 83DCD12D
	v_dual_dot2acc_f32_f16 v54, v98, v3 :: v_dual_lshlrev_b32 v97, 16, v97// 0000005384DC: CB220762 3660C290
	v_dot2acc_f32_f16 v51, v98, v7                             // 0000005384E4: 04660F62
	s_waitcnt lgkmcnt(0)                                       // 0000005384E8: BF89FC07
	v_dot2acc_f32_f16 v41, v95, v13                            // 0000005384EC: 04521B5F
	v_dot2acc_f32_f16 v50, v95, v9                             // 0000005384F0: 0464135F
	v_bfe_u32 v95, v92, 8, 16                                  // 0000005384F4: D610005F 0241115C
	v_bfe_u32 v92, v92, 4, 16                                  // 0000005384FC: D610005C 0241095C
	v_dot2acc_f32_f16 v51, v94, v8                             // 000000538504: 0466115E
	v_dot2acc_f32_f16 v41, v96, v14                            // 000000538508: 04521D60
	v_dot2acc_f32_f16 v50, v96, v10                            // 00000053850C: 04641560
	.long 0xd72c005f                                           // 000000538510: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000538514: 0202BEFF 83DCD12D
	v_bfe_u32 v96, v91, 12, 16                                 // 00000053851C: D6100060 0241195B
	.long 0xd72c005c                                           // 000000538524: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000538528: 0202B8FF 83DCD12D
	v_and_b32_e32 v91, 0xffff, v91                             // 000000538530: 36B6B6FF 0000FFFF
	v_dot2acc_f32_f16 v50, v98, v11                            // 000000538538: 04641762
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000053853C: BF870224
	.long 0xd72c0060                                           // 000000538540: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000538544: 0202C0FF 83DCD12D
	v_sad_u8 v95, v95, 0, 0x6400                               // 00000053854C: D622005F 03FD015F 00006400
	.long 0xd72c005b                                           // 000000538558: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 00000053855C: 0202B6FF 83DCD12D
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000538564: D622005C 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000538570: BF8701A3
	v_lshl_or_b32 v93, v95, 16, v93                            // 000000538574: D656005D 0575215F
	v_sad_u8 v96, v96, 0, 0x6400                               // 00000053857C: D6220060 03FD0160 00006400
	v_and_or_b32 v92, 0xffff, v92, v97                         // 000000538588: D657005C 0586B8FF 0000FFFF
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000538594: D622005B 03FD015B 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005385A0: BF870004
	v_pk_fma_f16 v93, v93, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005385A4: CC0E005D 0BFC0D5D 0000C931
	v_dot2acc_f32_f16 v41, v98, v15                            // 0000005385B0: 04521F62
	.long 0xd72c0062                                           // 0000005385B4: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 0000005385B8: 0202C8FF 83DCD12D
	v_pk_fma_f16 v92, v92, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005385C0: CC0E005C 0BFC0D5C 0000C931
	v_dual_dot2acc_f32_f16 v54, v94, v4 :: v_dual_lshlrev_b32 v91, 16, v91// 0000005385CC: CB22095E 365AB690
	v_dual_dot2acc_f32_f16 v52, v93, v9 :: v_dual_and_b32 v95, 0xffff, v96// 0000005385D4: CB24135D 345EC0FF 0000FFFF
	v_sad_u8 v96, v99, 0, 0x6400                               // 0000005385E0: D6220060 03FD0163 00006400
	v_dual_dot2acc_f32_f16 v50, v94, v12 :: v_dual_dot2acc_f32_f16 v47, v93, v1// 0000005385EC: CB18195E 322E035D
	v_sad_u8 v97, v98, 0, 0x6400                               // 0000005385F4: D6220061 03FD0162 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000538600: BF870214
	v_dot2acc_f32_f16 v52, v92, v10                            // 000000538604: 0468155C
	v_lshl_or_b32 v95, v96, 16, v95                            // 000000538608: D656005F 057D2160
	s_waitcnt vmcnt(5)                                         // 000000538610: BF8917F7
	v_bfe_u32 v96, v88, 12, 16                                 // 000000538614: D6100060 02411958
	v_dot2acc_f32_f16 v41, v94, v16                            // 00000053861C: 0452215E
	v_and_or_b32 v91, 0xffff, v97, v91                         // 000000538620: D657005B 056EC2FF 0000FFFF
	v_bfe_u32 v97, v88, 8, 16                                  // 00000053862C: D6100061 02411158
	v_pk_fma_f16 v95, v95, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000538634: CC0E005F 0BFC0D5F 0000C931
	.long 0xd72c0060                                           // 000000538640: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000538644: 0202C0FF 83DCD12D
	v_dot2acc_f32_f16 v53, v93, v5                             // 00000053864C: 046A0B5D
	v_pk_fma_f16 v91, v91, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000538650: CC0E005B 0BFC0D5B 0000C931
	v_and_b32_e32 v94, 0xffff, v89                             // 00000053865C: 36BCB2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v52, v95, v11 :: v_dual_dot2acc_f32_f16 v47, v92, v2// 000000538664: CB18175F 342E055C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000053866C: BF870234
	v_dot2acc_f32_f16 v53, v92, v6                             // 000000538670: 046A0D5C
	v_bfe_u32 v98, v88, 4, 16                                  // 000000538674: D6100062 02410958
	v_and_b32_e32 v88, 0xffff, v88                             // 00000053867C: 36B0B0FF 0000FFFF
	v_dot2acc_f32_f16 v52, v91, v12                            // 000000538684: 0468195B
	v_dot2acc_f32_f16 v47, v95, v3                             // 000000538688: 045E075F
	.long 0xd72c0061                                           // 00000053868C: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000538690: 0202C2FF 83DCD12D
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000538698: D6220060 03FD0160 00006400
	v_dot2acc_f32_f16 v49, v93, v13                            // 0000005386A4: 04621B5D
	v_bfe_u32 v93, v89, 8, 16                                  // 0000005386A8: D610005D 02411159
	v_bfe_u32 v89, v89, 4, 16                                  // 0000005386B0: D6100059 02410959
	.long 0xd72c005e                                           // 0000005386B8: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 0000005386BC: 0202BCFF 83DCD12D
	.long 0xd72c0058                                           // 0000005386C4: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 0000005386C8: 0202B0FF 83DCD12D
	v_and_b32_e32 v96, 0xffff, v96                             // 0000005386D0: 36C0C0FF 0000FFFF
	.long 0xd72c005d                                           // 0000005386D8: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 0000005386DC: 0202BAFF 83DCD12D
	v_sad_u8 v97, v97, 0, 0x6400                               // 0000005386E4: D6220061 03FD0161 00006400
	.long 0xd72c0059                                           // 0000005386F0: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000005386F4: 0202B2FF 83DCD12D
	v_dot2acc_f32_f16 v53, v95, v7                             // 0000005386FC: 046A0F5F
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000538700: D622005E 03FD015E 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 00000053870C: D6220058 03FD0158 00006400
	v_dot2acc_f32_f16 v49, v92, v14                            // 000000538718: 04621D5C
	v_sad_u8 v93, v93, 0, 0x6400                               // 00000053871C: D622005D 03FD015D 00006400
	v_lshl_or_b32 v92, v97, 16, v96                            // 000000538728: D656005C 05812161
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000538730: D6220059 03FD0159 00006400
	v_lshlrev_b32_e32 v88, 16, v88                             // 00000053873C: 30B0B090
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000538740: BF870214
	v_lshl_or_b32 v90, v93, 16, v90                            // 000000538744: D656005A 0569215D
	v_pk_fma_f16 v92, v92, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000053874C: CC0E005C 0BFC0D5C 0000C931
	v_lshlrev_b32_e32 v93, 16, v94                             // 000000538758: 30BABC90
	.long 0xd72c005e                                           // 00000053875C: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000538760: 0202C4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000538768: BF870224
	v_pk_fma_f16 v90, v90, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000053876C: CC0E005A 0BFC0D5A 0000C931
	v_dot2acc_f32_f16 v53, v91, v8                             // 000000538778: 046A115B
	v_and_or_b32 v89, 0xffff, v89, v93                         // 00000053877C: D6570059 0576B2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000538788: BF8701A3
	v_dual_dot2acc_f32_f16 v47, v91, v4 :: v_dual_dot2acc_f32_f16 v48, v90, v5// 00000053878C: CB18095B 2F300B5A
	v_sad_u8 v93, v94, 0, 0x6400                               // 000000538794: D622005D 03FD015E 00006400
	v_pk_fma_f16 v89, v89, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005387A0: CC0E0059 0BFC0D59 0000C931
	v_dot2acc_f32_f16 v46, v90, v9                             // 0000005387AC: 045C135A
	v_dot2acc_f32_f16 v29, v90, v1                             // 0000005387B0: 043A035A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005387B4: BF870214
	v_and_or_b32 v88, 0xffff, v93, v88                         // 0000005387B8: D6570058 0562BAFF 0000FFFF
	v_dot2acc_f32_f16 v48, v89, v6                             // 0000005387C4: 04600D59
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005387C8: BF870214
	v_dot2acc_f32_f16 v46, v89, v10                            // 0000005387CC: 045C1559
	v_dot2acc_f32_f16 v29, v89, v2                             // 0000005387D0: 043A0559
	s_waitcnt vmcnt(4)                                         // 0000005387D4: BF8913F7
	v_bfe_u32 v93, v85, 4, 16                                  // 0000005387D8: D610005D 02410955
	v_pk_fma_f16 v88, v88, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005387E0: CC0E0058 0BFC0D58 0000C931
	v_dot2acc_f32_f16 v48, v92, v7                             // 0000005387EC: 04600F5C
	v_dual_dot2acc_f32_f16 v46, v92, v11 :: v_dual_dot2acc_f32_f16 v45, v90, v13// 0000005387F0: CB18175C 2E2C1B5A
	v_dual_dot2acc_f32_f16 v29, v92, v3 :: v_dual_and_b32 v90, 0xffff, v86// 0000005387F8: CB24075C 1D5AACFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000538804: BF870193
	v_dual_dot2acc_f32_f16 v49, v95, v15 :: v_dual_dot2acc_f32_f16 v48, v88, v8// 000000538808: CB181F5F 31301158
	v_dual_dot2acc_f32_f16 v46, v88, v12 :: v_dual_dot2acc_f32_f16 v45, v89, v14// 000000538810: CB181958 2E2C1D59
	v_bfe_u32 v89, v86, 8, 16                                  // 000000538818: D6100059 02411156
	v_bfe_u32 v86, v86, 4, 16                                  // 000000538820: D6100056 02410956
	.long 0xd72c005a                                           // 000000538828: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 00000053882C: 0202B4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000538834: BF870193
	.long 0xd72c0059                                           // 000000538838: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 00000053883C: 0202B2FF 83DCD12D
	.long 0xd72c0056                                           // 000000538844: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000538848: 0202ACFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000538850: BF870003
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000538854: D622005A 03FD015A 00006400
	v_dot2acc_f32_f16 v49, v91, v16                            // 000000538860: 0462215B
	v_bfe_u32 v91, v85, 12, 16                                 // 000000538864: D610005B 02411955
	v_sad_u8 v89, v89, 0, 0x6400                               // 00000053886C: D6220059 03FD0159 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000538878: D6220056 03FD0156 00006400
	v_lshlrev_b32_e32 v90, 16, v90                             // 000000538884: 30B4B490
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000538888: BF870214
	.long 0xd72c005b                                           // 00000053888C: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000538890: 0202B6FF 83DCD12D
	v_lshl_or_b32 v87, v89, 16, v87                            // 000000538898: D6560057 055D2159
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005388A0: BF870113
	v_and_or_b32 v86, 0xffff, v86, v90                         // 0000005388A4: D6570056 056AACFF 0000FFFF
	v_pk_fma_f16 v87, v87, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005388B0: CC0E0057 0BFC0D57 0000C931
	v_dot2acc_f32_f16 v29, v88, v4                             // 0000005388BC: 043A0958
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005388C0: BF870223
	v_pk_fma_f16 v86, v86, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005388C4: CC0E0056 0BFC0D56 0000C931
	v_sad_u8 v91, v91, 0, 0x6400                               // 0000005388D0: D622005B 03FD015B 00006400
	v_dot2acc_f32_f16 v44, v87, v1                             // 0000005388DC: 04580357
	v_dual_dot2acc_f32_f16 v42, v87, v9 :: v_dual_dot2acc_f32_f16 v45, v92, v15// 0000005388E0: CB181357 2A2C1F5C
	v_bfe_u32 v92, v85, 8, 16                                  // 0000005388E8: D610005C 02411155
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005388F0: BF870193
	v_dual_dot2acc_f32_f16 v44, v86, v2 :: v_dual_and_b32 v85, 0xffff, v85// 0000005388F4: CB240556 2C54AAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v42, v86, v10 :: v_dual_dot2acc_f32_f16 v45, v88, v16// 000000538900: CB181556 2A2C2158
	v_dot2acc_f32_f16 v40, v87, v13                            // 000000538908: 04501B57
	s_delay_alu instid0(VALU_DEP_3)                            // 00000053890C: BF870003
	.long 0xd72c0055                                           // 000000538910: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000538914: 0202AAFF 83DCD12D
	.long 0xd72c0058                                           // 00000053891C: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000538920: 0202BAFF 83DCD12D
	.long 0xd72c005c                                           // 000000538928: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 00000053892C: 0202B8FF 83DCD12D
	v_mov_b32_e32 v93, v74                                     // 000000538934: 7EBA034A
	v_dot2acc_f32_f16 v40, v86, v14                            // 000000538938: 04501D56
	v_sad_u8 v85, v85, 0, 0x6400                               // 00000053893C: D6220055 03FD0155 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000538948: D6220058 03FD0158 00006400
	v_sad_u8 v90, v92, 0, 0x6400                               // 000000538954: D622005A 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000538960: BF870093
	v_dual_mov_b32 v92, v68 :: v_dual_lshlrev_b32 v85, 16, v85 // 000000538964: CA220144 5C54AA90
	v_and_or_b32 v85, 0xffff, v88, v85                         // 00000053896C: D6570055 0556B0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000538978: BF870141
	v_pk_fma_f16 v85, v85, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000053897C: CC0E0055 0BFC0D55 0000C931
	v_and_b32_e32 v89, 0xffff, v91                             // 000000538988: 36B2B6FF 0000FFFF
	s_waitcnt vmcnt(3)                                         // 000000538990: BF890FF7
	v_bfe_u32 v91, v82, 4, 16                                  // 000000538994: D610005B 02410952
	v_lshl_or_b32 v89, v90, 16, v89                            // 00000053899C: D6560059 0565215A
	v_bfe_u32 v90, v82, 8, 16                                  // 0000005389A4: D610005A 02411152
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000005389AC: BF870252
	v_pk_fma_f16 v88, v89, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005389B0: CC0E0058 0BFC0D59 0000C931
	v_dot2acc_f32_f16 v43, v87, v5                             // 0000005389BC: 04560B57
	v_bfe_u32 v89, v82, 12, 16                                 // 0000005389C0: D6100059 02411952
	v_and_b32_e32 v82, 0xffff, v82                             // 0000005389C8: 36A4A4FF 0000FFFF
	.long 0xd72c005a                                           // 0000005389D0: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 0000005389D4: 0202B4FF 83DCD12D
	v_dual_dot2acc_f32_f16 v42, v88, v11 :: v_dual_dot2acc_f32_f16 v43, v86, v6// 0000005389DC: CB181758 2A2A0D56
	v_bfe_u32 v86, v83, 8, 16                                  // 0000005389E4: D6100056 02411153
	.long 0xd72c0059                                           // 0000005389EC: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000005389F0: 0202B2FF 83DCD12D
	.long 0xd72c0052                                           // 0000005389F8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 0000005389FC: 0202A4FF 83DCD12D
	v_dot2acc_f32_f16 v44, v88, v3                             // 000000538A04: 04580758
	v_dot2acc_f32_f16 v43, v88, v7                             // 000000538A08: 04560F58
	.long 0xd72c0056                                           // 000000538A0C: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000538A10: 0202ACFF 83DCD12D
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000538A18: D622005A 03FD015A 00006400
	v_dot2acc_f32_f16 v42, v85, v12                            // 000000538A24: 04541955
	v_dot2acc_f32_f16 v44, v85, v4                             // 000000538A28: 04580955
	v_dot2acc_f32_f16 v43, v85, v8                             // 000000538A2C: 04561155
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000538A30: D6220059 03FD0159 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000538A3C: D6220052 03FD0152 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000538A48: D6220056 03FD0156 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000538A54: BF870091
	v_lshl_or_b32 v84, v86, 16, v84                            // 000000538A58: D6560054 05512156
	v_pk_fma_f16 v84, v84, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000538A60: CC0E0054 0BFC0D54 0000C931
	v_and_b32_e32 v87, 0xffff, v83                             // 000000538A6C: 36AEA6FF 0000FFFF
	v_bfe_u32 v83, v83, 4, 16                                  // 000000538A74: D6100053 02410953
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000538A7C: BF870223
	v_dual_dot2acc_f32_f16 v39, v84, v1 :: v_dual_lshlrev_b32 v82, 16, v82// 000000538A80: CB220354 2752A490
	v_dot2acc_f32_f16 v38, v84, v5                             // 000000538A88: 044C0B54
	.long 0xd72c0057                                           // 000000538A8C: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000538A90: 0202AEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000538A98: BF870004
	.long 0xd72c0053                                           // 000000538A9C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000538AA0: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v37, v84, v9                             // 000000538AA8: 044A1354
	v_dot2acc_f32_f16 v40, v88, v15                            // 000000538AAC: 04501F58
	v_dot2acc_f32_f16 v36, v84, v13                            // 000000538AB0: 04481B54
	v_bfe_u32 v84, v80, 8, 16                                  // 000000538AB4: D6100054 02411150
	s_waitcnt vmcnt(2)                                         // 000000538ABC: BF890BF7
	v_bfe_u32 v88, v79, 4, 16                                  // 000000538AC0: D6100058 0241094F
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000538AC8: D6220057 03FD0157 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000538AD4: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v40, v85, v16                            // 000000538AE0: 04502155
	v_bfe_u32 v85, v79, 12, 16                                 // 000000538AE4: D6100055 0241194F
	.long 0xd72c0054                                           // 000000538AEC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000538AF0: 0202A8FF 83DCD12D
	v_lshlrev_b32_e32 v87, 16, v87                             // 000000538AF8: 30AEAE90
	.long 0xd72c0058                                           // 000000538AFC: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000538B00: 0202B0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000538B08: BF870194
	.long 0xd72c0055                                           // 000000538B0C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000538B10: 0202AAFF 83DCD12D
	v_and_or_b32 v83, 0xffff, v83, v87                         // 000000538B18: D6570053 055EA6FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000538B24: D6220054 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000538B30: BF870002
	v_pk_fma_f16 v83, v83, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000538B34: CC0E0053 0BFC0D53 0000C931
	v_and_b32_e32 v86, 0xffff, v89                             // 000000538B40: 36ACB2FF 0000FFFF
	.long 0xd72c0059                                           // 000000538B48: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000538B4C: 0202B6FF 83DCD12D
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000538B54: D6220055 03FD0155 00006400
	v_mov_b32_e32 v91, v74                                     // 000000538B60: 7EB6034A
	v_dot2acc_f32_f16 v39, v83, v2                             // 000000538B64: 044E0553
	v_lshl_or_b32 v86, v90, 16, v86                            // 000000538B68: D6560056 0559215A
	v_dot2acc_f32_f16 v38, v83, v6                             // 000000538B70: 044C0D53
	v_dot2acc_f32_f16 v37, v83, v10                            // 000000538B74: 044A1553
	v_dual_dot2acc_f32_f16 v36, v83, v14 :: v_dual_and_b32 v83, 0xffff, v80// 000000538B78: CB241D53 2452A0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000538B84: BF870004
	v_pk_fma_f16 v86, v86, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000538B88: CC0E0056 0BFC0D56 0000C931
	v_sad_u8 v87, v89, 0, 0x6400                               // 000000538B94: D6220057 03FD0159 00006400
	v_bfe_u32 v80, v80, 4, 16                                  // 000000538BA0: D6100050 02410950
	v_and_b32_e32 v81, 0xffff, v81                             // 000000538BA8: 36A2A2FF 0000FFFF
	.long 0xd72c0053                                           // 000000538BB0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000538BB4: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v39, v86, v3                             // 000000538BBC: 044E0756
	v_dot2acc_f32_f16 v38, v86, v7                             // 000000538BC0: 044C0F56
	v_dot2acc_f32_f16 v37, v86, v11                            // 000000538BC4: 044A1756
	v_and_or_b32 v82, 0xffff, v87, v82                         // 000000538BC8: D6570052 054AAEFF 0000FFFF
	v_bfe_u32 v87, v79, 8, 16                                  // 000000538BD4: D6100057 0241114F
	.long 0xd72c0050                                           // 000000538BDC: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000538BE0: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v36, v86, v15                            // 000000538BE8: 04481F56
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000538BEC: D6220053 03FD0153 00006400
	v_pk_fma_f16 v82, v82, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000538BF8: CC0E0052 0BFC0D52 0000C931
	.long 0xd72c0057                                           // 000000538C04: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000538C08: 0202AEFF 83DCD12D
	v_lshl_or_b32 v81, v84, 16, v81                            // 000000538C10: D6560051 05452154
	v_and_b32_e32 v79, 0xffff, v79                             // 000000538C18: 369E9EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000538C20: BF870004
	v_dual_dot2acc_f32_f16 v36, v82, v16 :: v_dual_lshlrev_b32 v83, 16, v83// 000000538C24: CB222152 2452A690
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000538C2C: D6220050 03FD0150 00006400
	v_dot2acc_f32_f16 v38, v82, v8                             // 000000538C38: 044C1152
	v_pk_fma_f16 v81, v81, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000538C3C: CC0E0051 0BFC0D51 0000C931
	v_sad_u8 v84, v87, 0, 0x6400                               // 000000538C48: D6220054 03FD0157 00006400
	.long 0xd72c004f                                           // 000000538C54: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000538C58: 02029EFF 83DCD12D
	v_and_or_b32 v80, 0xffff, v80, v83                         // 000000538C60: D6570050 054EA0FF 0000FFFF
	v_and_b32_e32 v83, 0xffff, v85                             // 000000538C6C: 36A6AAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v39, v82, v4 :: v_dual_dot2acc_f32_f16 v34, v81, v5// 000000538C74: CB180952 27220B51
	v_sad_u8 v85, v88, 0, 0x6400                               // 000000538C7C: D6220055 03FD0158 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000538C88: BF870214
	v_pk_fma_f16 v80, v80, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000538C8C: CC0E0050 0BFC0D50 0000C931
	v_lshl_or_b32 v83, v84, 16, v83                            // 000000538C98: D6560053 054D2154
	v_dot2acc_f32_f16 v37, v82, v12                            // 000000538CA0: 044A1952
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000538CA4: D622004F 03FD014F 00006400
	v_and_b32_e32 v82, 0xffff, v77                             // 000000538CB0: 36A49AFF 0000FFFF
	v_dot2acc_f32_f16 v34, v80, v6                             // 000000538CB8: 04440D50
	v_pk_fma_f16 v83, v83, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000538CBC: CC0E0053 0BFC0D53 0000C931
	v_dot2acc_f32_f16 v35, v81, v1                             // 000000538CC8: 04460351
	v_dual_dot2acc_f32_f16 v32, v81, v13 :: v_dual_lshlrev_b32 v79, 16, v79// 000000538CCC: CB221B51 204E9E90
	v_bfe_u32 v84, v77, 8, 16                                  // 000000538CD4: D6100054 0241114D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000538CDC: BF870193
	v_dual_dot2acc_f32_f16 v34, v83, v7 :: v_dual_dot2acc_f32_f16 v35, v80, v2// 000000538CE0: CB180F53 22220550
	v_and_or_b32 v79, 0xffff, v85, v79                         // 000000538CE8: D657004F 053EAAFF 0000FFFF
	v_bfe_u32 v77, v77, 4, 16                                  // 000000538CF4: D610004D 0241094D
	.long 0xd72c0052                                           // 000000538CFC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000538D00: 0202A4FF 83DCD12D
	s_waitcnt vmcnt(1)                                         // 000000538D08: BF8907F7
	v_bfe_u32 v85, v76, 12, 16                                 // 000000538D0C: D6100055 0241194C
	.long 0xd72c0054                                           // 000000538D14: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000538D18: 0202A8FF 83DCD12D
	v_dot2acc_f32_f16 v33, v81, v9                             // 000000538D20: 04421351
	v_bfe_u32 v86, v76, 8, 16                                  // 000000538D24: D6100056 0241114C
	.long 0xd72c004d                                           // 000000538D2C: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000538D30: 02029AFF 83DCD12D
	v_bfe_u32 v87, v76, 4, 16                                  // 000000538D38: D6100057 0241094C
	.long 0xd72c0055                                           // 000000538D40: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000538D44: 0202AAFF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 000000538D4C: 369898FF 0000FFFF
	v_pk_fma_f16 v79, v79, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000538D54: CC0E004F 0BFC0D4F 0000C931
	v_dot2acc_f32_f16 v35, v83, v3                             // 000000538D60: 04460753
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000538D64: D6220052 03FD0152 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000538D70: D6220054 03FD0154 00006400
	.long 0xd72c0056                                           // 000000538D7C: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000538D80: 0202ACFF 83DCD12D
	.long 0xd72c004c                                           // 000000538D88: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000538D8C: 020298FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000538D94: BF870004
	v_dual_dot2acc_f32_f16 v35, v79, v4 :: v_dual_lshlrev_b32 v82, 16, v82// 000000538D98: CB22094F 2352A490
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000538DA0: D622004D 03FD014D 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000538DAC: D6220055 03FD0155 00006400
	v_lshl_or_b32 v78, v84, 16, v78                            // 000000538DB8: D656004E 05392154
	.long 0xd72c0051                                           // 000000538DC0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000538DC4: 0202AEFF 83DCD12D
	v_dot2acc_f32_f16 v33, v80, v10                            // 000000538DCC: 04421550
	v_and_or_b32 v77, 0xffff, v77, v82                         // 000000538DD0: D657004D 054A9AFF 0000FFFF
	v_and_b32_e32 v82, 0xffff, v85                             // 000000538DDC: 36A4AAFF 0000FFFF
	v_sad_u8 v84, v86, 0, 0x6400                               // 000000538DE4: D6220054 03FD0156 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000538DF0: D622004C 03FD014C 00006400
	v_pk_fma_f16 v78, v78, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000538DFC: CC0E004E 0BFC0D4E 0000C931
	v_dual_dot2acc_f32_f16 v33, v83, v11 :: v_dual_dot2acc_f32_f16 v32, v80, v14// 000000538E08: CB181753 21201D50
	v_pk_fma_f16 v77, v77, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000538E10: CC0E004D 0BFC0D4D 0000C931
	v_lshl_or_b32 v80, v84, 16, v82                            // 000000538E1C: D6560050 05492154
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000538E24: D6220051 03FD0151 00006400
	v_dual_dot2acc_f32_f16 v31, v78, v1 :: v_dual_lshlrev_b32 v76, 16, v76// 000000538E30: CB22034E 1F4C9890
	v_dual_dot2acc_f32_f16 v33, v79, v12 :: v_dual_dot2acc_f32_f16 v30, v78, v5// 000000538E38: CB18194F 211E0B4E
	v_dot2acc_f32_f16 v28, v78, v9                             // 000000538E40: 0438134E
	v_pk_fma_f16 v80, v80, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000538E44: CC0E0050 0BFC0D50 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000538E50: BF870244
	v_and_or_b32 v76, 0xffff, v81, v76                         // 000000538E54: D657004C 0532A2FF 0000FFFF
	v_dot2acc_f32_f16 v31, v77, v2                             // 000000538E60: 043E054D
	v_dot2acc_f32_f16 v30, v77, v6                             // 000000538E64: 043C0D4D
	v_dual_dot2acc_f32_f16 v32, v83, v15 :: v_dual_dot2acc_f32_f16 v27, v78, v13// 000000538E68: CB181F53 201A1B4E
	v_pk_fma_f16 v76, v76, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000538E70: CC0E004C 0BFC0D4C 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000538E7C: BF870194
	v_dual_dot2acc_f32_f16 v31, v80, v3 :: v_dual_dot2acc_f32_f16 v28, v77, v10// 000000538E80: CB180750 1F1C154D
	v_dual_dot2acc_f32_f16 v34, v79, v8 :: v_dual_dot2acc_f32_f16 v27, v77, v14// 000000538E88: CB18114F 221A1D4D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000538E90: BF870194
	v_dot2acc_f32_f16 v32, v79, v16                            // 000000538E94: 0440214F
	v_dot2acc_f32_f16 v31, v76, v4                             // 000000538E98: 043E094C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000538E9C: BF870004
	v_dot2acc_f32_f16 v28, v80, v11                            // 000000538EA0: 04381750
	v_bfe_u32 v79, v59, 8, 16                                  // 000000538EA4: D610004F 0241113B
	s_waitcnt vmcnt(0)                                         // 000000538EAC: BF8903F7
	v_bfe_u32 v81, v58, 12, 16                                 // 000000538EB0: D6100051 0241193A
	v_bfe_u32 v82, v58, 8, 16                                  // 000000538EB8: D6100052 0241113A
	v_bfe_u32 v83, v58, 4, 16                                  // 000000538EC0: D6100053 0241093A
	v_dot2acc_f32_f16 v27, v80, v15                            // 000000538EC8: 04361F50
	.long 0xd72c004f                                           // 000000538ECC: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000538ED0: 02029EFF 83DCD12D
	v_dual_mov_b32 v85, v72 :: v_dual_and_b32 v58, 0xffff, v58 // 000000538ED8: CA240148 553A74FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000538EE4: BF870214
	.long 0xd72c004d                                           // 000000538EE8: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000538EEC: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v27, v76, v16                            // 000000538EF4: 0436214C
	.long 0xd72c0051                                           // 000000538EF8: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000538EFC: 0202A2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000538F04: BF870004
	.long 0xd72c003a                                           // 000000538F08: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000538F0C: 020274FF 83DCD12D
	v_mov_b32_e32 v87, v72                                     // 000000538F14: 7EAE0348
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000538F18: D622004F 03FD014F 00006400
	.long 0xd72c0052                                           // 000000538F24: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000538F28: 0202A4FF 83DCD12D
	v_mov_b32_e32 v89, v65                                     // 000000538F30: 7EB20341
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000538F34: D622004D 03FD014D 00006400
	v_mov_b32_e32 v86, v64                                     // 000000538F40: 7EAC0340
	v_lshl_or_b32 v60, v79, 16, v60                            // 000000538F44: D656003C 04F1214F
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000538F4C: D622003A 03FD013A 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000538F58: D6220051 03FD0151 00006400
	v_dot2acc_f32_f16 v30, v80, v7                             // 000000538F64: 043C0F50
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000538F68: D6220052 03FD0152 00006400
	v_pk_fma_f16 v60, v60, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000538F74: CC0E003C 0BFC0D3C 0000C931
	v_and_b32_e32 v78, 0xffff, v59                             // 000000538F80: 369C76FF 0000FFFF
	v_bfe_u32 v59, v59, 4, 16                                  // 000000538F88: D610003B 0241093B
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000538F90: 30747490
	v_and_b32_e32 v81, 0xffff, v81                             // 000000538F94: 36A2A2FF 0000FFFF
	v_dot2acc_f32_f16 v25, v60, v5                             // 000000538F9C: 04320B3C
	.long 0xd72c004e                                           // 000000538FA0: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000538FA4: 02029CFF 83DCD12D
	.long 0xd72c003b                                           // 000000538FAC: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000538FB0: 020276FF 83DCD12D
	v_dot2acc_f32_f16 v26, v60, v1                             // 000000538FB8: 0434033C
	v_and_or_b32 v1, 0xffff, v77, v58                          // 000000538FBC: D6570001 04EA9AFF 0000FFFF
	v_dot2acc_f32_f16 v24, v60, v9                             // 000000538FC8: 0430133C
	v_dual_dot2acc_f32_f16 v22, v60, v13 :: v_dual_mov_b32 v79, v70// 000000538FCC: CB101B3C 164E0146
	v_mov_b32_e32 v77, v61                                     // 000000538FD4: 7E9A033D
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000538FD8: D622004E 03FD014E 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000538FE4: D622003B 03FD013B 00006400
	v_pk_fma_f16 v1, v1, s6, 0xc931 op_sel_hi:[1,0,0]          // 000000538FF0: CC0E0001 0BFC0D01 0000C931
	v_mov_b32_e32 v88, v73                                     // 000000538FFC: 7EB00349
	v_mov_b32_e32 v90, v73                                     // 000000539000: 7EB40349
	v_dual_mov_b32 v83, v63 :: v_dual_lshlrev_b32 v78, 16, v78 // 000000539004: CA22013F 534E9C90
	v_mov_b32_e32 v84, v71                                     // 00000053900C: 7EA80347
	v_mov_b32_e32 v80, v62                                     // 000000539010: 7EA0033E
	v_mov_b32_e32 v60, v67                                     // 000000539014: 7E780343
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000539018: BF870244
	v_and_or_b32 v59, 0xffff, v59, v78                         // 00000053901C: D657003B 053A76FF 0000FFFF
	v_lshl_or_b32 v78, v82, 16, v81                            // 000000539028: D656004E 05452152
	v_dual_mov_b32 v81, v70 :: v_dual_mov_b32 v82, v71         // 000000539030: CA100146 51520147
	v_mov_b32_e32 v58, v67                                     // 000000539038: 7E740343
	v_pk_fma_f16 v59, v59, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000053903C: CC0E003B 0BFC0D3B 0000C931
	v_dot2acc_f32_f16 v30, v76, v8                             // 000000539048: 043C114C
	v_pk_fma_f16 v78, v78, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000053904C: CC0E004E 0BFC0D4E 0000C931
	s_delay_alu instid0(VALU_DEP_3)                            // 000000539058: BF870003
	v_dot2acc_f32_f16 v26, v59, v2                             // 00000053905C: 0434053B
	v_dot2acc_f32_f16 v25, v59, v6                             // 000000539060: 04320D3B
	v_dot2acc_f32_f16 v24, v59, v10                            // 000000539064: 0430153B
	v_dot2acc_f32_f16 v22, v59, v14                            // 000000539068: 042C1D3B
	v_dot2acc_f32_f16 v28, v76, v12                            // 00000053906C: 0438194C
	v_dual_dot2acc_f32_f16 v26, v78, v3 :: v_dual_mov_b32 v3, v75// 000000539070: CB10074E 1A02014B
	v_dot2acc_f32_f16 v25, v78, v7                             // 000000539078: 04320F4E
	v_dot2acc_f32_f16 v24, v78, v11                            // 00000053907C: 0430174E
	v_dot2acc_f32_f16 v22, v78, v15                            // 000000539080: 042C1F4E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000539084: BF870214
	v_dual_dot2acc_f32_f16 v26, v1, v4 :: v_dual_mov_b32 v59, v18// 000000539088: CB100901 1A3A0112
	v_dot2acc_f32_f16 v25, v1, v8                              // 000000539090: 04321101
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000539094: BF870214
	v_dot2acc_f32_f16 v24, v1, v12                             // 000000539098: 04301901
	v_dot2acc_f32_f16 v22, v1, v16                             // 00000053909C: 042C2101
	v_mov_b32_e32 v4, v75                                      // 0000005390A0: 7E08034B
	v_mov_b32_e32 v2, v66                                      // 0000005390A4: 7E040342
	v_mov_b32_e32 v78, v69                                     // 0000005390A8: 7E9C0345
	v_mov_b32_e32 v76, v69                                     // 0000005390AC: 7E980345
	v_mov_b32_e32 v1, v17                                      // 0000005390B0: 7E020311
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000005390B4: 917E057E
	s_cbranch_execz 58                                         // 0000005390B8: BFA5003A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ba4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005390BC: BF8700A1
	v_add_nc_u32_e32 v17, 1, v1                                // 0000005390C0: 4A220281
	s_mov_b32 s7, exec_lo                                      // 0000005390C4: BE87007E
	.long 0xd4c1007e                                           // 0000005390C8: D4C1007E
	v_cndmask_b32_e32 v1, v17, v23, vcc_lo                     // 0000005390CC: 02022F11
	s_cbranch_execz 64550                                      // 0000005390D0: BFA5FC26 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb6c>
	v_ashrrev_i32_e32 v18, 31, v17                             // 0000005390D4: 3424229F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005390D8: BF870091
	.long 0xd73c0005                                           // 0000005390DC: D73C0005
	v_cndmask_b32_e32 v1, 10, v17, vcc_lo                      // 0000005390E0: 0202228A
	.long 0xd7006a07                                           // 0000005390E4: D7006A07
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 0000005390E8: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005390EC: BF870111
	v_add_co_ci_u32_e64 v8, null, s4, v6, vcc_lo               // 0000005390F0: D5207C08 01AA0C04
	.long 0xd7006a05                                           // 0000005390F8: D7006A05
	v_cndmask_b32_e32 v1, v7, v57, vcc_lo                      // 0000005390FC: 02027307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000539100: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v8, vcc_lo                // 000000539104: D5207C06 01AA1080
	.long 0xd7006a07                                           // 00000053910C: D7006A07
	v_cndmask_b32_e32 v1, v7, v56, vcc_lo                      // 000000539110: 02027107
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 000000539114: D5207C08 01AA1080
	s_clause 0xf                                               // 00000053911C: BF85000F
	global_load_b32 v66, v[5:6], off                           // 000000539120: DC520000 427C0005
	global_load_b32 v68, v[5:6], off offset:128                // 000000539128: DC520080 447C0005
	global_load_b32 v65, v[5:6], off offset:256                // 000000539130: DC520100 417C0005
	global_load_b32 v64, v[5:6], off offset:384                // 000000539138: DC520180 407C0005
	global_load_b32 v63, v[5:6], off offset:512                // 000000539140: DC520200 3F7C0005
	global_load_b32 v62, v[5:6], off offset:640                // 000000539148: DC520280 3E7C0005
	global_load_b32 v61, v[5:6], off offset:768                // 000000539150: DC520300 3D7C0005
	global_load_b32 v18, v[5:6], off offset:896                // 000000539158: DC520380 127C0005
	global_load_b32 v75, v[7:8], off                           // 000000539160: DC520000 4B7C0007
	global_load_b32 v74, v[7:8], off offset:128                // 000000539168: DC520080 4A7C0007
	global_load_b32 v73, v[7:8], off offset:256                // 000000539170: DC520100 497C0007
	global_load_b32 v72, v[7:8], off offset:384                // 000000539178: DC520180 487C0007
	global_load_b32 v71, v[7:8], off offset:512                // 000000539180: DC520200 477C0007
	global_load_b32 v70, v[7:8], off offset:640                // 000000539188: DC520280 467C0007
	global_load_b32 v69, v[7:8], off offset:768                // 000000539190: DC520300 457C0007
	global_load_b32 v67, v[7:8], off offset:896                // 000000539198: DC520380 437C0007
	s_branch 64498                                             // 0000005391A0: BFA0FBF2 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb6c>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000005391A4: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005391A8: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 0000005391AC: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 0000005391B0: BF895FF7
	v_dual_mov_b32 v1, v54 :: v_dual_mov_b32 v2, v51           // 0000005391B4: CA100136 01020133
	s_waitcnt vmcnt(7)                                         // 0000005391BC: BF891FF7
	v_dual_mov_b32 v4, v50 :: v_dual_mov_b32 v3, v41           // 0000005391C0: CA100132 04020129
	v_dual_mov_b32 v5, v47 :: v_dual_mov_b32 v8, v52           // 0000005391C8: CA10012F 05080134
	v_dual_mov_b32 v7, v53 :: v_dual_mov_b32 v10, v48          // 0000005391D0: CA100135 070A0130
	v_dual_mov_b32 v9, v49 :: v_dual_mov_b32 v14, v43          // 0000005391D8: CA100131 090E012B
	v_dual_mov_b32 v6, v29 :: v_dual_mov_b32 v11, v46          // 0000005391E0: CA10011D 060A012E
	v_dual_mov_b32 v12, v45 :: v_dual_mov_b32 v13, v44         // 0000005391E8: CA10012D 0C0C012C
	v_dual_mov_b32 v15, v42 :: v_dual_mov_b32 v16, v40         // 0000005391F0: CA10012A 0F100128
	v_dual_mov_b32 v17, v39 :: v_dual_mov_b32 v18, v38         // 0000005391F8: CA100127 11120126
	v_dual_mov_b32 v23, v37 :: v_dual_mov_b32 v56, v35         // 000000539200: CA100125 17380123
	s_waitcnt vmcnt(0)                                         // 000000539208: BF8903F7
	v_dual_mov_b32 v55, v36 :: v_dual_mov_b32 v58, v33         // 00000053920C: CA100124 373A0121
	v_dual_mov_b32 v57, v34 :: v_dual_mov_b32 v60, v31         // 000000539214: CA100122 393C011F
	v_dual_mov_b32 v59, v32 :: v_dual_mov_b32 v64, v26         // 00000053921C: CA100120 3B40011A
	v_dual_mov_b32 v61, v30 :: v_dual_mov_b32 v62, v28         // 000000539224: CA10011E 3D3E011C
	v_dual_mov_b32 v63, v27 :: v_dual_mov_b32 v66, v24         // 00000053922C: CA10011B 3F420118
	v_mov_b32_e32 v65, v25                                     // 000000539234: 7E820319
	v_mov_b32_e32 v67, v22                                     // 000000539238: 7E860316
	s_mov_b32 s0, 0x76543210                                   // 00000053923C: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000539244: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000539248: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000539254: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000539260: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 00000053926C: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000539278: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000539284: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000539290: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 00000053929C: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 0000005392A8: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 0000005392B4: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 0000005392C0: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 0000005392CC: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 0000005392D8: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 0000005392E4: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 0000005392F0: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 0000005392FC: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000539308: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 000000539314: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v23, v23, s0, 0xfedcba98                 // 000000539320: D65C0017 03FC0117 FEDCBA98
	v_permlanex16_b32 v55, v55, s0, 0xfedcba98                 // 00000053932C: D65C0037 03FC0137 FEDCBA98
	v_permlanex16_b32 v56, v56, s0, 0xfedcba98                 // 000000539338: D65C0038 03FC0138 FEDCBA98
	v_permlanex16_b32 v57, v57, s0, 0xfedcba98                 // 000000539344: D65C0039 03FC0139 FEDCBA98
	v_permlanex16_b32 v58, v58, s0, 0xfedcba98                 // 000000539350: D65C003A 03FC013A FEDCBA98
	v_permlanex16_b32 v59, v59, s0, 0xfedcba98                 // 00000053935C: D65C003B 03FC013B FEDCBA98
	v_permlanex16_b32 v60, v60, s0, 0xfedcba98                 // 000000539368: D65C003C 03FC013C FEDCBA98
	v_permlanex16_b32 v61, v61, s0, 0xfedcba98                 // 000000539374: D65C003D 03FC013D FEDCBA98
	v_permlanex16_b32 v62, v62, s0, 0xfedcba98                 // 000000539380: D65C003E 03FC013E FEDCBA98
	v_permlanex16_b32 v63, v63, s0, 0xfedcba98                 // 00000053938C: D65C003F 03FC013F FEDCBA98
	v_permlanex16_b32 v64, v64, s0, 0xfedcba98                 // 000000539398: D65C0040 03FC0140 FEDCBA98
	v_permlanex16_b32 v65, v65, s0, 0xfedcba98                 // 0000005393A4: D65C0041 03FC0141 FEDCBA98
	v_permlanex16_b32 v66, v66, s0, 0xfedcba98                 // 0000005393B0: D65C0042 03FC0142 FEDCBA98
	v_permlanex16_b32 v67, v67, s0, 0xfedcba98                 // 0000005393BC: D65C0043 03FC0143 FEDCBA98
	.long 0xd44c0000                                           // 0000005393C8: D44C0000
	v_cndmask_b32_e32 v1, 16, v21, vcc_lo                      // 0000005393CC: 02022A90
	s_barrier                                                  // 0000005393D0: BFBD0000
	buffer_gl0_inv                                             // 0000005393D4: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000005393DC: BE812000
	s_cbranch_execz 68                                         // 0000005393E0: BFA50044 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ef4>
	v_lshl_or_b32 v20, v19, 11, v20                            // 0000005393E4: D6560014 04511713
	v_dual_add_f32 v5, v47, v5 :: v_dual_add_f32 v4, v50, v4   // 0000005393EC: C9080B2F 05040932
	v_dual_add_f32 v1, v54, v1 :: v_dual_add_f32 v2, v51, v2   // 0000005393F4: C9080336 01020533
	v_dual_add_f32 v8, v52, v8 :: v_dual_add_f32 v7, v53, v7   // 0000005393FC: C9081134 08060F35
	v_dual_add_f32 v21, v22, v67 :: v_dual_add_f32 v22, v24, v66// 000000539404: C9088716 15168518
	v_dual_add_f32 v24, v25, v65 :: v_dual_add_f32 v25, v26, v64// 00000053940C: C9088319 1818811A
	v_dual_add_f32 v26, v27, v63 :: v_dual_add_f32 v27, v28, v62// 000000539414: C9087F1B 1A1A7D1C
	v_add_f32_e32 v28, v30, v61                                // 00000053941C: 06387B1E
	v_dual_add_f32 v30, v31, v60 :: v_dual_add_f32 v31, v32, v59// 000000539420: C908791F 1E1E7720
	v_dual_add_f32 v32, v33, v58 :: v_dual_add_f32 v33, v34, v57// 000000539428: C9087521 20207322
	v_dual_add_f32 v34, v35, v56 :: v_dual_add_f32 v23, v37, v23// 000000539430: C9087123 22162F25
	v_dual_add_f32 v35, v36, v55 :: v_dual_add_nc_u32 v36, 0x400, v20// 000000539438: C9206F24 232428FF 00000400
	v_dual_add_f32 v3, v41, v3 :: v_dual_add_f32 v10, v48, v10 // 000000539444: C9080729 030A1530
	v_dual_add_f32 v9, v49, v9 :: v_dual_add_f32 v14, v43, v14 // 00000053944C: C9081331 090E1D2B
	v_dual_add_f32 v13, v44, v13 :: v_dual_add_f32 v6, v29, v6 // 000000539454: C9081B2C 0D060D1D
	v_dual_add_f32 v18, v38, v18 :: v_dual_add_f32 v17, v39, v17// 00000053945C: C9082526 12102327
	v_dual_add_f32 v16, v40, v16 :: v_dual_add_f32 v15, v42, v15// 000000539464: C9082128 100E1F2A
	v_dual_add_f32 v12, v45, v12 :: v_dual_add_f32 v11, v46, v11// 00000053946C: C908192D 0C0A172E
	ds_store_2addr_b32 v20, v1, v5 offset1:16                  // 000000539474: D8381000 00050114
	ds_store_2addr_b32 v20, v2, v7 offset0:128 offset1:144     // 00000053947C: D8389080 00070214
	ds_store_2addr_b32 v36, v4, v8 offset1:16                  // 000000539484: D8381000 00080424
	ds_store_2addr_b32 v36, v3, v9 offset0:128 offset1:144     // 00000053948C: D8389080 00090324
	ds_store_2addr_b32 v20, v6, v13 offset0:32 offset1:48      // 000000539494: D8383020 000D0614
	ds_store_2addr_b32 v20, v10, v14 offset0:160 offset1:176   // 00000053949C: D838B0A0 000E0A14
	ds_store_2addr_b32 v36, v11, v15 offset0:32 offset1:48     // 0000005394A4: D8383020 000F0B24
	ds_store_2addr_b32 v36, v12, v16 offset0:160 offset1:176   // 0000005394AC: D838B0A0 00100C24
	ds_store_2addr_b32 v20, v17, v34 offset0:64 offset1:80     // 0000005394B4: D8385040 00221114
	ds_store_2addr_b32 v20, v18, v33 offset0:192 offset1:208   // 0000005394BC: D838D0C0 00211214
	ds_store_2addr_b32 v36, v23, v32 offset0:64 offset1:80     // 0000005394C4: D8385040 00201724
	ds_store_2addr_b32 v36, v35, v31 offset0:192 offset1:208   // 0000005394CC: D838D0C0 001F2324
	ds_store_2addr_b32 v20, v30, v25 offset0:96 offset1:112    // 0000005394D4: D8387060 00191E14
	ds_store_2addr_b32 v20, v28, v24 offset0:224 offset1:240   // 0000005394DC: D838F0E0 00181C14
	ds_store_2addr_b32 v36, v27, v22 offset0:96 offset1:112    // 0000005394E4: D8387060 00161B24
	ds_store_2addr_b32 v36, v26, v21 offset0:224 offset1:240   // 0000005394EC: D838F0E0 00151A24
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005394F4: 8C7E017E
	.long 0xd44c0001                                           // 0000005394F8: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000005394FC: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 000000539504: BF89FC07
	s_barrier                                                  // 000000539508: BFBD0000
	buffer_gl0_inv                                             // 00000053950C: E0AC0000 00000000
	s_and_saveexec_b32 s4, s1                                  // 000000539514: BE842001
	s_cbranch_execz 44                                         // 000000539518: BFA5002C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1fcc>
	v_mov_b32_e32 v1, v0                                       // 00000053951C: 7E020300
	s_mov_b32 s5, 0                                            // 000000539520: BE850080
	s_nop 0                                                    // 000000539524: BF800000
	s_nop 0                                                    // 000000539528: BF800000
	s_nop 0                                                    // 00000053952C: BF800000
	s_nop 0                                                    // 000000539530: BF800000
	s_nop 0                                                    // 000000539534: BF800000
	s_nop 0                                                    // 000000539538: BF800000
	s_nop 0                                                    // 00000053953C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000539540: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000539544: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 000000539548: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:8            // 000000539550: D8E00800 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:16 offset1:24// 000000539558: D8E01810 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:32 offset1:40// 000000539560: D8E02820 06000008
	s_or_b32 s5, vcc_lo, s5                                    // 000000539568: 8C05056A
	s_waitcnt lgkmcnt(2)                                       // 00000053956C: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 000000539570: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000539574: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000539578: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:48 offset1:56// 00000053957C: D8E03830 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000539584: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000539588: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 00000053958C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 000000539590: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000539594: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000539598: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 00000053959C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 0000005395A0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005395A4: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 0000005395A8: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 0000005395AC: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 0000005395B4: C9100702 02000104
	ds_store_b32 v8, v2 offset:16384                           // 0000005395BC: D8344000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000005395C4: 917E057E
	s_cbranch_execnz 65501                                     // 0000005395C8: BFA6FFDD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f40>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000005395CC: 8C7E047E
	s_cmp_lt_i32 s33, 2                                        // 0000005395D0: BF048221
	s_mov_b32 s4, -1                                           // 0000005395D4: BE8400C1
	s_cbranch_scc1 212                                         // 0000005395D8: BFA200D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x232c>
	s_waitcnt lgkmcnt(0)                                       // 0000005395DC: BF89FC07
	s_barrier                                                  // 0000005395E0: BFBD0000
	buffer_gl0_inv                                             // 0000005395E4: E0AC0000 00000000
	s_and_saveexec_b32 s6, s1                                  // 0000005395EC: BE862001
	s_cbranch_execz 71                                         // 0000005395F0: BFA50047 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2110>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000005395F4: 32020087
	s_ashr_i32 s11, s10, 31                                    // 0000005395F8: 860B9F0A
	s_ashr_i32 s19, s18, 31                                    // 0000005395FC: 86139F12
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000539600: 8484820A
	s_mov_b32 s7, 0                                            // 000000539604: BE870080
	v_or_b32_e32 v1, s4, v1                                    // 000000539608: 38020204
	s_mul_i32 s4, s5, s18                                      // 00000053960C: 96041205
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000539610: BF8700A1
	.long 0xd72c0003                                           // 000000539614: D72C0003
	v_cndmask_b32_e32 v0, v1, v19, vcc_lo                      // 000000539618: 02002701
	v_mad_u64_u32 v[1:2], null, v1, s18, 0                     // 00000053961C: D6FE7C01 02002501
	v_add3_u32 v2, v2, v3, s4                                  // 000000539624: D6550002 00120702
	s_lshl_b32 s4, s2, 7                                       // 00000053962C: 84048702
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000539630: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 000000539638: 86059F04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000053963C: BF870122
	.long 0xd73c0001                                           // 000000539640: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000539644: 02020282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000539648: 84848204
	v_lshlrev_b32_e32 v4, 2, v3                                // 00000053964C: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000539650: 30060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000539654: BF870093
	.long 0xd7006a01                                           // 000000539658: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000053965C: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000539660: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[18:19], 3                             // 000000539668: 84848312
	.long 0xd7006a01                                           // 00000053966C: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 000000539670: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000539674: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000539678: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 000000539680: 380800FF FFFFFF00
	.long 0xd7006a01                                           // 000000539688: D7006A01
	v_cndmask_b32_e32 v1, s24, v1, vcc_lo                      // 00000053968C: 02020218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000539690: BF870001
	v_add_co_ci_u32_e64 v2, null, s25, v2, vcc_lo              // 000000539694: D5207C02 01AA0419
	s_nop 0                                                    // 00000053969C: BF800000
	s_nop 0                                                    // 0000005396A0: BF800000
	s_nop 0                                                    // 0000005396A4: BF800000
	s_nop 0                                                    // 0000005396A8: BF800000
	s_nop 0                                                    // 0000005396AC: BF800000
	s_nop 0                                                    // 0000005396B0: BF800000
	s_nop 0                                                    // 0000005396B4: BF800000
	s_nop 0                                                    // 0000005396B8: BF800000
	s_nop 0                                                    // 0000005396BC: BF800000
	ds_load_b32 v5, v3 offset:16384                            // 0000005396C0: D8D84000 05000003
	.long 0xd7000804                                           // 0000005396C8: D7000804
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 0000005396CC: 020208FF 00000100
	s_xor_b32 s8, s8, -1                                       // 0000005396D4: 8D08C108
	v_add_nc_u32_e32 v3, 0x400, v3                             // 0000005396D8: 4A0606FF 00000400
	s_and_b32 s8, exec_lo, s8                                  // 0000005396E0: 8B08087E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000005396E4: BF8700C9
	s_or_b32 s7, s8, s7                                        // 0000005396E8: 8C070708
	s_waitcnt lgkmcnt(0)                                       // 0000005396EC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000005396F0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 0000005396F8: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 0000005396FC: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000539700: D5207C02 01AA0405
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 000000539708: 917E077E
	s_cbranch_execnz 65516                                     // 00000053970C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x20c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000539710: 8C7E067E
	.long 0xd44a0004                                           // 000000539714: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000539718: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 00000053971C: BC7C0000
	buffer_gl1_inv                                             // 000000539720: E0B00000 00000000
	buffer_gl0_inv                                             // 000000539728: E0AC0000 00000000
	s_barrier                                                  // 000000539730: BFBD0000
	buffer_gl0_inv                                             // 000000539734: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 00000053973C: BE852004
	s_cbranch_execz 29                                         // 000000539740: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x21b8>
	s_mov_b32 s7, exec_lo                                      // 000000539744: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000539748: BE86007E
	.long 0xd71f0001                                           // 00000053974C: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 000000539750: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000539754: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000539758: 7D940280
	s_cbranch_execz 9                                          // 00000053975C: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2184>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 000000539760: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000539764: BF8704B9
	s_add_u32 s8, s26, s8                                      // 000000539768: 8008081A
	s_addc_u32 s9, s27, s9                                     // 00000053976C: 8209091B
	s_bcnt1_i32_b32 s7, s7                                     // 000000539770: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 000000539774: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 00000053977C: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 000000539784: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000539788: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 00000053978C: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000539790: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 000000539794: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 00000053979C: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000005397A0: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 0000005397A4: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000005397A8: D5010001 01A90280
	ds_store_b32 v2, v1 offset:20480                           // 0000005397B0: D8345000 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 0000005397B8: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 0000005397BC: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000005397C0: BF89FC07
	s_barrier                                                  // 0000005397C4: BFBD0000
	buffer_gl0_inv                                             // 0000005397C8: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:20480                            // 0000005397D0: D8D85000 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000005397D8: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000005397DC: 7C940280
	s_cbranch_vccnz 424                                        // 0000005397E0: BFA401A8 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2884>
	buffer_gl1_inv                                             // 0000005397E4: E0B00000 00000000
	buffer_gl0_inv                                             // 0000005397EC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 0000005397F4: BE852001
	s_cbranch_execz 65                                         // 0000005397F8: BFA50041 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2300>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000005397FC: 32020087
	s_lshl_b32 s6, s2, 7                                       // 000000539800: 84068702
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000539804: 360600FF 0000007F
	s_ashr_i32 s7, s6, 31                                      // 00000053980C: 86079F06
	v_mov_b32_e32 v5, v0                                       // 000000539810: 7E0A0300
	v_mad_i64_i32 v[1:2], null, v1, s18, 0                     // 000000539814: D6FF7C01 02002501
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000053981C: 84868206
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000539820: 30060682
	s_ashr_i32 s19, s18, 31                                    // 000000539824: 86139F12
	s_mov_b32 s10, 0                                           // 000000539828: BE8A0080
	s_lshl_b64 s[8:9], s[18:19], 4                             // 00000053982C: 84888412
	.long 0xd73c0001                                           // 000000539830: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000539834: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000539838: BF870091
	.long 0xd7006a01                                           // 00000053983C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000539840: 02000D01
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000539844: D5207C02 01AA0407
	s_lshl_b64 s[6:7], s[18:19], 3                             // 00000053984C: 84868312
	.long 0xd7006a01                                           // 000000539850: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000539854: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000539858: BF870111
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000053985C: D5207C02 01AA0480
	.long 0xd7006a01                                           // 000000539864: D7006A01
	v_cndmask_b32_e32 v1, s24, v1, vcc_lo                      // 000000539868: 02020218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000053986C: BF870001
	v_add_co_ci_u32_e64 v2, null, s25, v2, vcc_lo              // 000000539870: D5207C02 01AA0419
	s_nop 0                                                    // 000000539878: BF800000
	s_nop 0                                                    // 00000053987C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000539880: BF870001
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 000000539884: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 00000053988C: 7E0C0280
	s_mov_b32 s1, s33                                          // 000000539890: BE810021
	global_load_b32 v7, v[3:4], off glc                        // 000000539894: DC524000 077C0003
	.long 0xd7006a03                                           // 00000053989C: D7006A03
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000005398A0: 02001103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000005398A4: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000005398A8: D5207C04 01AA0809
	s_add_i32 s1, s1, -1                                       // 0000005398B0: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 0000005398B4: BF068001
	s_waitcnt vmcnt(0)                                         // 0000005398B8: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 0000005398BC: 060C0F06
	s_cbranch_scc0 65524                                       // 0000005398C0: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2294>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 0000005398C4: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 0000005398CC: 7C920AFF 000000FF
	.long 0xd7000101                                           // 0000005398D4: D7000101
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 0000005398D8: 02000D01
	v_lshlrev_b32_e32 v3, 2, v5                                // 0000005398DC: 30060A82
	v_add_co_ci_u32_e64 v2, null, s7, v2, s1                   // 0000005398E0: D5207C02 00060407
	v_mov_b32_e32 v5, v4                                       // 0000005398E8: 7E0A0304
	s_or_b32 s10, vcc_lo, s10                                  // 0000005398EC: 8C0A0A6A
	ds_store_b32 v3, v6 offset:16384                           // 0000005398F0: D8344000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000005398F8: 917E0A7E
	s_cbranch_execnz 65504                                     // 0000005398FC: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2280>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000539900: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 000000539904: BE812004
	s_cbranch_execz 6                                          // 000000539908: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2324>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 00000053990C: 84848202
	v_mov_b32_e32 v1, 0                                        // 000000539910: 7E020280
	s_add_u32 s4, s26, s4                                      // 000000539914: 8004041A
	s_addc_u32 s5, s27, s5                                     // 000000539918: 8205051B
	global_store_b32 v1, v1, s[4:5]                            // 00000053991C: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000539924: 8C7E017E
	s_mov_b32 s4, -1                                           // 000000539928: BE8400C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000053992C: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000539930: 8B6A047E
	s_cbranch_vccz 339                                         // 000000539934: BFA30153 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2884>
	v_cmp_gt_i32_e32 vcc_lo, s16, v19                          // 000000539938: 7C882610
	.long 0xd44c0001                                           // 00000053993C: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000539940: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000539948: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000053994C: BC7C0000
	s_barrier                                                  // 000000539950: BFBD0000
	buffer_gl0_inv                                             // 000000539954: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000053995C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000539960: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000539964: BE832001
	s_cbranch_execz 326                                        // 000000539968: BFA50146 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2884>
	v_and_b32_e32 v1, 15, v0                                   // 00000053996C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000539970: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000539974: 30040282
	v_lshl_or_b32 v2, v19, 9, v2                               // 000000539978: D6560002 04091313
	s_delay_alu instid0(VALU_DEP_1)                            // 000000539980: BF870001
	v_add_nc_u32_e32 v8, 0x4000, v2                            // 000000539984: 4A1004FF 00004000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000053998C: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000539994: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000053999C: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000005399A4: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000005399AC: 36140081
	s_waitcnt lgkmcnt(3)                                       // 0000005399B0: BF89FC37
	v_dual_add_f32 v12, v2, v3 :: v_dual_and_b32 v11, 2, v0    // 0000005399B4: C9240702 0C0A0082
	s_waitcnt lgkmcnt(2)                                       // 0000005399BC: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 0000005399C0: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 0000005399C8: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000005399CC: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000005399D4: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_sub_f32 v7, v8, v9     // 0000005399D8: C94A0F06 06061308
	v_dual_add_f32 v8, v8, v9 :: v_dual_and_b32 v9, 4, v0      // 0000005399E0: C9241308 08080084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005399E8: BF8701A3
	v_add_f32_e32 v13, v2, v4                                  // 0000005399EC: 061A0902
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000005399F0: 7C941480
	v_add_f32_e32 v16, v5, v8                                  // 0000005399F4: 06201105
	v_dual_sub_f32 v5, v5, v8 :: v_dual_add_f32 v14, v12, v3   // 0000005399F8: C9481105 050E070C
	v_add_f32_e32 v15, v6, v7                                  // 000000539A00: 061E0F06
	v_dual_sub_f32 v3, v12, v3 :: v_dual_sub_f32 v2, v2, v4    // 000000539A04: C94A070C 03020902
	v_sub_f32_e32 v4, v6, v7                                   // 000000539A0C: 08080F06
	.long 0xd44a0001                                           // 000000539A10: D44A0001
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000539A14: 02021280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000539A18: BF870214
	v_add_f32_e32 v6, v13, v15                                 // 000000539A1C: 060C1F0D
	v_dual_sub_f32 v8, v13, v15 :: v_dual_add_f32 v13, v3, v5  // 000000539A20: C9481F0D 080C0B03
	v_add_f32_e32 v7, v14, v16                                 // 000000539A28: 060E210E
	v_dual_sub_f32 v3, v3, v5 :: v_dual_add_f32 v12, v2, v4    // 000000539A2C: C9480B03 030C0902
	v_sub_f32_e32 v2, v2, v4                                   // 000000539A34: 08040902
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000539A38: 7E0A02FA FF016106
	s_delay_alu instid0(VALU_DEP_4)                            // 000000539A40: BF870004
	v_mov_b32_dpp v4, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000539A44: 7E0802FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000539A4C: D5010007 21AA0F07
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000539A54: D5010006 21AA0D06
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000539A5C: 7E2402FA FF016103
	v_cndmask_b32_e64 v22, -v3, v3, vcc_lo                     // 000000539A64: D5010016 21AA0703
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000539A6C: 7E2802FA FF016102
	v_add_f32_e32 v3, v7, v4                                   // 000000539A74: 06060907
	v_mov_b32_dpp v15, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000539A78: 7E1E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000539A80: D5010008 21AA1108
	v_cndmask_b32_e64 v21, -v2, v2, vcc_lo                     // 000000539A88: D5010015 21AA0502
	v_add_f32_e32 v2, v6, v5                                   // 000000539A90: 06040B06
	v_mov_b32_dpp v6, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000539A94: 7E0C02FA FF016203
	v_sub_f32_e32 v10, v14, v16                                // 000000539A9C: 0814210E
	v_mov_b32_dpp v16, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000539AA0: 7E2002FA FF01610D
	v_mov_b32_dpp v17, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000539AA8: 7E2202FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000539AB0: D501000C 21AA190C
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000539AB8: D501000D 21AA1B0D
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000539AC0: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000539AC8: D501000A 21AA150A
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 000000539AD0: 7C941680
	v_add_f32_e32 v4, v8, v15                                  // 000000539AD4: 06081F08
	v_dual_add_f32 v7, v12, v17 :: v_dual_add_f32 v8, v13, v16 // 000000539AD8: C908230C 0708210D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000539AE0: BF870224
	v_add_f32_e32 v5, v10, v14                                 // 000000539AE4: 060A1D0A
	v_add_f32_e32 v13, v21, v20                                // 000000539AE8: 061A2915
	v_mov_b32_dpp v12, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000539AEC: 7E1802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000539AF4: D5010004 21AA0904
	v_mov_b32_dpp v10, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000539AFC: 7E1402FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000539B04: D5010002 21AA0502
	v_mov_b32_dpp v9, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000539B0C: 7E1202FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000539B14: D5010008 21AA1108
	v_add_f32_e32 v4, v4, v12                                  // 000000539B1C: 06081904
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000539B20: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000539B28: D501000D 21AA1B0D
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000539B30: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000539B38: D5010005 21AA0B05
	v_mov_b32_dpp v12, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000539B40: 7E1802FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000539B48: D5010004 20060904
	v_add_f32_e32 v8, v8, v9                                   // 000000539B50: 06101308
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000539B54: D5010003 21AA0703
	v_add_f32_e32 v11, v5, v11                                 // 000000539B5C: 06161705
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000539B60: 7E1C02FA FF016207
	v_add_f32_e32 v4, v4, v12                                  // 000000539B68: 06081904
	v_add_f32_e32 v12, v22, v18                                // 000000539B6C: 06182516
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000539B70: D5010007 21AA0F07
	v_add_f32_e32 v3, v3, v6                                   // 000000539B78: 06060D03
	s_delay_alu instid0(VALU_DEP_3)                            // 000000539B7C: BF870003
	v_mov_b32_dpp v9, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000539B80: 7E1202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000539B88: D501000C 21AA190C
	v_add_f32_e32 v2, v2, v10                                  // 000000539B90: 06041502
	v_add_f32_e32 v14, v7, v14                                 // 000000539B94: 061C1D07
	v_mov_b32_dpp v6, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000539B98: 7E0C02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000539BA0: D5010003 20060703
	v_add_f32_e32 v9, v12, v9                                  // 000000539BA8: 0612130C
	v_cndmask_b32_e64 v10, -v2, v2, s1                         // 000000539BAC: D501000A 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000539BB4: 7E0402FA FF016402
	v_mov_b32_dpp v12, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000539BBC: 7E1802FA FF01640E
	v_add_f32_e32 v3, v3, v6                                   // 000000539BC4: 06060D03
	v_mov_b32_dpp v16, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000539BC8: 7E2002FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000539BD0: D5010009 20061309
	v_add_f32_e32 v5, v10, v2                                  // 000000539BD8: 060A050A
	v_mov_b32_dpp v10, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000539BDC: 7E1402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000539BE4: D501000B 2006170B
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000539BEC: 7E0402FA FF016803
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000539BF4: BF870194
	v_mov_b32_dpp v6, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000539BF8: 7E0C02FA FF016805
	v_add_f32_e32 v7, v11, v10                                 // 000000539C00: 060E150B
	v_add_f32_e32 v11, v13, v15                                // 000000539C04: 06161F0D
	v_mov_b32_dpp v10, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000539C08: 7E1402FA FF016408
	v_cndmask_b32_e64 v13, -v14, v14, s1                       // 000000539C10: D501000D 20061D0E
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 000000539C18: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000539C20: BF870224
	v_mov_b32_dpp v18, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000539C24: 7E2402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000539C2C: D501000B 2006170B
	v_add_f32_e32 v17, v13, v12                                // 000000539C34: 0622190D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000539C38: BF870224
	v_dual_add_f32 v15, v14, v10 :: v_dual_add_f32 v14, v9, v16// 000000539C3C: C908150E 0F0E2109
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000539C44: 7E1002FA FF016807
	v_add_f32_e32 v16, v11, v18                                // 000000539C4C: 0620250B
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000539C50: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4)                            // 000000539C58: BF870004
	v_mov_b32_dpp v11, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000539C5C: 7E1602FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000539C64: 7E1A02FA FF016811
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000539C6C: 7E1402FA FF01680E
	v_mov_b32_dpp v12, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000539C74: 7E1802FA FF016810
	s_and_b32 exec_lo, exec_lo, s0                             // 000000539C7C: 8B7E007E
	s_cbranch_execz 128                                        // 000000539C80: BFA50080 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2884>
	v_lshl_or_b32 v20, s2, 7, v1                               // 000000539C84: D6560014 04050E02
	v_and_b32_e32 v18, 8, v0                                   // 000000539C8C: 36240088
	v_mad_i64_i32 v[0:1], null, s18, v19, 0                    // 000000539C90: D6FF7C00 02022612
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000539C98: BF870113
	v_ashrrev_i32_e32 v21, 31, v20                             // 000000539C9C: 342A289F
	.long 0xd73c0000                                           // 000000539CA0: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000539CA4: 02020082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000539CA8: BF870092
	.long 0xd73c0016                                           // 000000539CAC: D73C0016
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 000000539CB0: 02022881
	.long 0xd7006a16                                           // 000000539CB4: D7006A16
	v_cndmask_b32_e32 v1, s22, v22, vcc_lo                     // 000000539CB8: 02022C16
	s_delay_alu instid0(VALU_DEP_1)                            // 000000539CBC: BF870001
	v_add_co_ci_u32_e64 v23, null, s23, v23, vcc_lo            // 000000539CC0: D5207C17 01AA2E17
	v_cmp_eq_u32_e32 vcc_lo, 0, v18                            // 000000539CC8: 7C942480
	.long 0xd73c0012                                           // 000000539CCC: D73C0012
	v_cndmask_b32_e32 v1, 2, v20, vcc_lo                       // 000000539CD0: 02022882
	s_clause 0x7                                               // 000000539CD4: BF850007
	global_load_d16_b16 v24, v[22:23], off offset:32           // 000000539CD8: DC820020 187C0016
	global_load_d16_b16 v25, v[22:23], off                     // 000000539CE0: DC820000 197C0016
	global_load_d16_b16 v26, v[22:23], off offset:96           // 000000539CE8: DC820060 1A7C0016
	global_load_d16_b16 v27, v[22:23], off offset:64           // 000000539CF0: DC820040 1B7C0016
	global_load_d16_b16 v28, v[22:23], off offset:160          // 000000539CF8: DC8200A0 1C7C0016
	global_load_d16_b16 v29, v[22:23], off offset:128          // 000000539D00: DC820080 1D7C0016
	global_load_d16_b16 v30, v[22:23], off offset:224          // 000000539D08: DC8200E0 1E7C0016
	global_load_d16_b16 v22, v[22:23], off offset:192          // 000000539D10: DC8200C0 167C0016
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000539D18: D5010005 21AA0B05
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000539D20: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000539D28: D501000F 21AA1F0F
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000539D30: D5010004 21AA0904
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000539D38: D5010007 21AA0F07
	v_add_f32_e32 v5, v5, v6                                   // 000000539D40: 060A0D05
	v_cndmask_b32_e64 v6, -v17, v17, vcc_lo                    // 000000539D44: D5010006 21AA2311
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 000000539D4C: D5010010 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000539D54: D501000E 21AA1D0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000539D5C: BF870214
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 000000539D60: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v13 :: v_dual_add_f32 v6, v15, v11  // 000000539D6C: C9081B06 0506170F
	.long 0xd7006a00                                           // 000000539D74: D7006A00
	v_cndmask_b32_e32 v1, s28, v0, vcc_lo                      // 000000539D78: 0202001C
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v7, v7, v8     // 000000539D7C: C9081304 04061107
	v_add_co_ci_u32_e64 v1, null, s29, v1, vcc_lo              // 000000539D84: D5207C01 01AA021D
	v_dual_add_f32 v8, v16, v12 :: v_dual_add_f32 v9, v14, v10 // 000000539D8C: C9081910 0808150E
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000539D94: C8C604FF 02040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000539DA0: BF8700A4
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 000000539DA4: C8C60CFF 06060EFF 3DB504F3
	.long 0xd7006a00                                           // 000000539DB0: D7006A00
	v_cndmask_b32_e32 v1, v0, v18, vcc_lo                      // 000000539DB4: 02022500
	v_add_co_ci_u32_e64 v1, null, v1, v19, vcc_lo              // 000000539DB8: D5207C01 01AA2701
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_mul_f32 v9, 0x3db504f3, v9// 000000539DC0: C8C608FF 040812FF 3DB504F3
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000539DCC: 101010FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 000000539DD4: BF891FF7
	v_fma_mix_f32 v3, v24, v3, neg(0) op_sel_hi:[1,0,0]        // 000000539DD8: CC200003 8A020718
	s_waitcnt vmcnt(6)                                         // 000000539DE0: BF891BF7
	v_fma_mix_f32 v2, v25, v2, neg(0) op_sel_hi:[1,0,0]        // 000000539DE4: CC200002 8A020519
	s_waitcnt vmcnt(5)                                         // 000000539DEC: BF8917F7
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 000000539DF0: CC200005 8A020B1A
	s_waitcnt vmcnt(4)                                         // 000000539DF8: BF8913F7
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 000000539DFC: CC200006 8A020D1B
	s_waitcnt vmcnt(3)                                         // 000000539E04: BF890FF7
	v_fma_mix_f32 v4, v28, v4, neg(0) op_sel_hi:[1,0,0]        // 000000539E08: CC200004 8A02091C
	s_waitcnt vmcnt(2)                                         // 000000539E10: BF890BF7
	v_fma_mix_f32 v7, v29, v7, neg(0) op_sel_hi:[1,0,0]        // 000000539E14: CC200007 8A020F1D
	s_waitcnt vmcnt(1)                                         // 000000539E1C: BF8907F7
	v_fma_mix_f32 v8, v30, v8, neg(0) op_sel_hi:[1,0,0]        // 000000539E20: CC200008 8A02111E
	s_waitcnt vmcnt(0)                                         // 000000539E28: BF8903F7
	v_fma_mix_f32 v9, v22, v9, neg(0) op_sel_hi:[1,0,0]        // 000000539E2C: CC200009 8A021316
	s_clause 0x7                                               // 000000539E34: BF850007
	global_store_b32 v[0:1], v2, off                           // 000000539E38: DC6A0000 007C0200
	global_store_b32 v[0:1], v3, off offset:64                 // 000000539E40: DC6A0040 007C0300
	global_store_b32 v[0:1], v6, off offset:128                // 000000539E48: DC6A0080 007C0600
	global_store_b32 v[0:1], v5, off offset:192                // 000000539E50: DC6A00C0 007C0500
	global_store_b32 v[0:1], v7, off offset:256                // 000000539E58: DC6A0100 007C0700
	global_store_b32 v[0:1], v4, off offset:320                // 000000539E60: DC6A0140 007C0400
	global_store_b32 v[0:1], v9, off offset:384                // 000000539E68: DC6A0180 007C0900
	global_store_b32 v[0:1], v8, off offset:448                // 000000539E70: DC6A01C0 007C0800
	s_nop 0                                                    // 000000539E78: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000539E7C: BFB60003
	s_endpgm                                                   // 000000539E80: BFB00000
	s_nop 0                                                    // 000000539E84: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000539E88: BFB60003
	s_endpgm                                                   // 000000539E8C: BFB00000
		...

