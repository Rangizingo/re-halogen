0000000000292900 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 000000292900: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 000000292904: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 00000029290C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 000000292914: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 00000029291C: F4000180 F8000118
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000292924: 32040082
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 000000292928: CA240080 100E009F
	s_load_b128 s[12:15], s[0:1], 0x128                        // 000000292930: F4080300 F8000128
	s_delay_alu instid0(VALU_DEP_2)                            // 000000292938: BF870002
	v_and_b32_e32 v2, 60, v2                                   // 00000029293C: 360404BC
	s_waitcnt lgkmcnt(0)                                       // 000000292940: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 000000292944: BF028103
	s_cselect_b32 s7, -1, 0                                    // 000000292948: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000029294C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 000000292950: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000292954: BF870009
	s_and_b32 s4, s7, s4                                       // 000000292958: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000029295C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 000000292960: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 000000292968: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000029296C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 000000292970: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000292974: BF870009
	s_and_b32 s4, s7, s5                                       // 000000292978: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000029297C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 000000292980: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 000000292984: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000292988: BF030602
	v_and_b32_e32 v1, 15, v0                                   // 00000029298C: 3602008F
	s_cselect_b32 s6, -1, 0                                    // 000000292990: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000292994: BF870009
	s_and_b32 s3, s3, s6                                       // 000000292998: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 00000029299C: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000002929A0: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000002929A4: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000002929A8: 98030483
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002929AC: 30020282
	s_mulk_i32 s3, 0x48                                        // 0000002929B0: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002929B4: BF870009
	s_add_u32 s16, s0, s3                                      // 0000002929B8: 80100300
	s_addc_u32 s17, s1, 0                                      // 0000002929BC: 82118001
	s_clause 0x1                                               // 0000002929C0: BF850001
	s_load_b64 s[18:19], s[16:17], null                        // 0000002929C4: F4040488 F8000000
	s_load_b256 s[4:11], s[16:17], 0x18                        // 0000002929CC: F40C0108 F8000018
	s_waitcnt lgkmcnt(0)                                       // 0000002929D4: BF89FC07
	s_clause 0x1                                               // 0000002929D8: BF850001
	global_load_b32 v1, v1, s[18:19]                           // 0000002929DC: DC520000 01120001
	global_load_b32 v2, v2, s[18:19]                           // 0000002929E4: DC520000 02120002
	.long 0xd4510014                                           // 0000002929EC: D4510014
	v_cndmask_b32_e32 v0, s10, v137, vcc_lo                    // 0000002929F0: 0201120A
	s_and_b32 s3, s20, exec_lo                                 // 0000002929F4: 8B037E14
	s_cselect_b32 s3, 8, 2                                     // 0000002929F8: 98038288
	s_cselect_b32 s1, 3, 1                                     // 0000002929FC: 98018183
	s_add_i32 s26, s3, -1                                      // 000000292A00: 811AC103
	s_waitcnt vmcnt(1)                                         // 000000292A04: BF8907F7
	v_bfe_u32 v3, v1, 16, 1                                    // 000000292A08: D6100003 02052101
	s_waitcnt vmcnt(0)                                         // 000000292A10: BF8903F7
	v_bfe_u32 v4, v2, 16, 1                                    // 000000292A14: D6100004 02052102
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000292A1C: BF8701A2
	v_add3_u32 v1, v1, v3, 0x7fff                              // 000000292A20: D6550001 03FE0701 00007FFF
	.long 0x7f063880                                           // 000000292A2C: 7F063880
	v_add3_u32 v2, v2, v4, 0x7fff                              // 000000292A30: D6550002 03FE0902 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000292A3C: BF870123
	.long 0x7e063981                                           // 000000292A40: 7E063981
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000292A44: 30020082
	v_and_or_b32 v2, 0xffff0000, v2, v3                        // 000000292A48: D6570002 040E04FF FFFF0000
	v_lshrrev_b32_e32 v3, 5, v0                                // 000000292A54: 32060085
	ds_store_b32 v1, v2                                        // 000000292A58: D8340000 00000201
	v_cvt_f32_ubyte0_e32 v1, s3                                // 000000292A60: 7E022203
	v_lshrrev_b32_e32 v14, s1, v3                              // 000000292A64: 321C0601
	v_and_b32_e32 v17, s26, v3                                 // 000000292A68: 3622061A
	v_mov_b32_e32 v3, 0                                        // 000000292A6C: 7E060280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000292A70: BF870294
	v_rcp_iflag_f32_e32 v1, v1                                 // 000000292A74: 7E025701
	v_readfirstlane_b32 s0, v1                                 // 000000292A78: 7E000501
	s_mul_f32 s0, s0, 0x4f7ffffe                               // 000000292A7C: A200FF00 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3)                          // 000000292A84: BF87000B
	s_cvt_u32_f32 s0, s0                                       // 000000292A88: BE806700
	s_waitcnt lgkmcnt(0)                                       // 000000292A8C: BF89FC07
	s_barrier                                                  // 000000292A90: BFBD0000
	buffer_gl0_inv                                             // 000000292A94: E0AC0000 00000000
	s_load_b32 s21, s[16:17], 0x40                             // 000000292A9C: F4000548 F8000040
	s_waitcnt lgkmcnt(0)                                       // 000000292AA4: BF89FC07
	s_sub_i32 s22, s2, s21                                     // 000000292AA8: 81961502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000292AAC: BF870009
	s_ashr_i32 s23, s22, 31                                    // 000000292AB0: 86179F16
	s_and_b32 s21, s20, exec_lo                                // 000000292AB4: 8B157E14
	s_cselect_b32 s21, 0, 2                                    // 000000292AB8: 98158280
	s_lshr_b32 s24, s15, 31                                    // 000000292ABC: 85189F0F
	s_lshl_b64 s[22:23], s[22:23], s21                         // 000000292AC0: 84961516
	s_add_u32 s24, s14, s24                                    // 000000292AC4: 8018180E
	s_addc_u32 s25, s15, 0                                     // 000000292AC8: 8219800F
	s_ashr_i32 s27, s15, 31                                    // 000000292ACC: 861B9F0F
	s_ashr_i64 s[24:25], s[24:25], 1                           // 000000292AD0: 86988118
	s_lshr_b32 s27, s27, 27                                    // 000000292AD4: 851B9B1B
	.long 0xd7001601                                           // 000000292AD8: D7001601
	v_cndmask_b32_e32 v1, s22, v14, vcc_lo                     // 000000292ADC: 02021C16
	s_add_u32 s14, s14, s27                                    // 000000292AE0: 800E1B0E
	s_addc_u32 s15, s15, 0                                     // 000000292AE4: 820F800F
	s_sub_i32 s27, 0, s3                                       // 000000292AE8: 819B0380
	s_lshr_b64 s[14:15], s[14:15], 5                           // 000000292AEC: 858E850E
	s_mul_i32 s27, s27, s0                                     // 000000292AF0: 961B001B
	s_add_i32 s15, s26, s14                                    // 000000292AF4: 810F0E1A
	s_mul_hi_u32 s27, s0, s27                                  // 000000292AF8: 969B1B00
	s_abs_i32 s28, s15                                         // 000000292AFC: BE9C150F
	s_add_i32 s0, s0, s27                                      // 000000292B00: 81001B00
	v_add_co_ci_u32_e64 v2, null, s23, 0, s22                  // 000000292B04: D5207C02 00590017
	s_mul_hi_u32 s0, s28, s0                                   // 000000292B0C: 9680001C
	s_ashr_i32 s15, s15, 31                                    // 000000292B10: 860F9F0F
	s_mul_i32 s22, s0, s3                                      // 000000292B14: 96160300
	s_add_i32 s23, s0, 1                                       // 000000292B18: 81178100
	s_sub_i32 s22, s28, s22                                    // 000000292B1C: 8196161C
	v_cmp_gt_i64_e32 vcc_lo, s[10:11], v[1:2]                  // 000000292B20: 7CA8020A
	s_sub_i32 s27, s22, s3                                     // 000000292B24: 819B0316
	s_cmp_ge_u32 s22, s3                                       // 000000292B28: BF090316
	s_cselect_b32 s0, s23, s0                                  // 000000292B2C: 98000017
	s_cselect_b32 s22, s27, s22                                // 000000292B30: 9816161B
	s_add_i32 s23, s0, 1                                       // 000000292B34: 81178100
	s_cmp_ge_u32 s22, s3                                       // 000000292B38: BF090316
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 000000292B3C: 02040480
	s_cselect_b32 s0, s23, s0                                  // 000000292B40: 98000017
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000292B44: 02020280
	s_xor_b32 s0, s0, s15                                      // 000000292B48: 8D000F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000292B4C: BF870009
	s_sub_i32 s0, s0, s15                                      // 000000292B50: 81800F00
	s_add_u32 s4, s18, s4                                      // 000000292B54: 80040412
	.long 0xd72c0005                                           // 000000292B58: D72C0005
	v_cndmask_b32_e32 v1, s0, v17, vcc_lo                      // 000000292B5C: 02022200
	s_addc_u32 s5, s19, s5                                     // 000000292B60: 82050513
	.long 0xd72c0004                                           // 000000292B64: D72C0004
	v_cndmask_b32_e32 v0, v2, v24, vcc_lo                      // 000000292B68: 02003102
	.long 0xd72c0007                                           // 000000292B6C: D72C0007
	v_cndmask_b32_e32 v0, v1, v25, vcc_lo                      // 000000292B70: 02003301
	v_mad_u64_u32 v[9:10], null, v1, s24, s[4:5]               // 000000292B74: D6FE7C09 00103101
	s_add_u32 s6, s18, s6                                      // 000000292B7C: 80060612
	.long 0xd72c0006                                           // 000000292B80: D72C0006
	v_cndmask_b32_e32 v0, v2, v8, vcc_lo                       // 000000292B84: 02001102
	s_addc_u32 s7, s19, s7                                     // 000000292B88: 82070713
	v_add_nc_u32_e32 v2, s0, v5                                // 000000292B8C: 4A040A00
	.long 0xd72c0008                                           // 000000292B90: D72C0008
	v_cndmask_b32_e32 v0, v1, v9, vcc_lo                       // 000000292B94: 02001301
	v_mad_u64_u32 v[11:12], null, v1, s8, s[6:7]               // 000000292B98: D6FE7C0B 00181101
	v_mov_b32_e32 v1, 0                                        // 000000292BA0: 7E020280
	v_add3_u32 v10, v4, v10, v7                                // 000000292BA4: D655000A 041E1504
	v_min_i32_e32 v19, s14, v2                                 // 000000292BAC: 2226040E
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v21, 0              // 000000292BB0: CA100080 04140080
	v_add_nc_u32_e32 v18, v5, v15                              // 000000292BB8: 4A241F05
	v_mov_b32_e32 v2, 0                                        // 000000292BBC: 7E040280
	v_add3_u32 v20, v6, v12, v8                                // 000000292BC0: D6550014 04221906
	s_delay_alu instid0(VALU_DEP_3)                            // 000000292BC8: BF870003
	v_cmp_lt_i32_e32 vcc_lo, v18, v19                          // 000000292BCC: 7C822712
	s_and_saveexec_b32 s4, vcc_lo                              // 000000292BD0: BE84206A
	s_cbranch_execz 21                                         // 000000292BD4: BFA50015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x32c>
	v_lshlrev_b32_e32 v1, 1, v18                               // 000000292BD8: 30022481
	v_lshlrev_b32_e32 v3, 4, v18                               // 000000292BDC: 30062484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000292BE0: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000292BE4: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000292BE8: 3408069F
	.long 0xd7000001                                           // 000000292BEC: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 000000292BF0: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000292BF4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 000000292BF8: D5207C02 00020514
	.long 0xd7000003                                           // 000000292C00: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 000000292C04: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 000000292C08: D5207C04 0002090A
	s_clause 0x1                                               // 000000292C10: BF850001
	global_load_d16_b16 v6, v[1:2], off                        // 000000292C14: DC820000 067C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000292C1C: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000292C24: BF8907F7
	v_cvt_f32_f16_e32 v21, v6                                  // 000000292C28: 7E2A1706
	s_or_b32 exec_lo, exec_lo, s4                              // 000000292C2C: 8C7E047E
	s_and_saveexec_b32 s4, vcc_lo                              // 000000292C30: BE84206A
	s_cbranch_execz 209                                        // 000000292C34: BFA500D1 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x67c>
	v_lshlrev_b32_e32 v6, 5, v15                               // 000000292C38: 300C1E85
	v_dual_mov_b32 v16, 0 :: v_dual_add_nc_u32 v7, 32, v18     // 000000292C3C: CA200080 100624A0
	s_mov_b32 s5, 0                                            // 000000292C44: BE850080
	v_mov_b32_e32 v24, v21                                     // 000000292C48: 7E300315
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000292C4C: BF870193
	v_lshl_add_u32 v12, v5, 5, v6                              // 000000292C50: D646000C 04190B05
	v_lshlrev_b32_e32 v22, 4, v7                               // 000000292C58: 302C0E84
	v_lshlrev_b32_e32 v23, 1, v7                               // 000000292C5C: 302E0E81
	s_branch 166                                               // 000000292C60: BFA000A6 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x5fc>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000292C64: 8C7E067E
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000292C68: 341A189F
	v_lshrrev_b32_e32 v41, 6, v1                               // 000000292C6C: 32520286
	v_lshrrev_b32_e32 v42, 14, v1                              // 000000292C70: 3254028E
	v_and_b32_e32 v43, 0xff, v2                                // 000000292C74: 365604FF 000000FF
	v_lshrrev_b32_e32 v44, 6, v2                               // 000000292C7C: 32580486
	.long 0xd73c0019                                           // 000000292C80: D73C0019
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000292C84: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 000000292C88: 361A02FF 000000FF
	v_and_b32_e32 v41, 0x3fc, v41                              // 000000292C90: 365252FF 000003FC
	v_and_b32_e32 v42, 0x3fc, v42                              // 000000292C98: 365454FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 000000292CA0: 32020296
	v_lshrrev_b32_e32 v45, 14, v2                              // 000000292CA4: 325A048E
	.long 0xd7000025                                           // 000000292CA8: D7000025
	v_cndmask_b32_e32 v1, s12, v25, vcc_lo                     // 000000292CAC: 0202320C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000292CB0: BF870001
	v_add_co_ci_u32_e64 v38, null, s13, v26, s0                // 000000292CB4: D5207C26 0002340D
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000292CBC: 301A1A82
	ds_load_b32 v41, v41                                       // 000000292CC0: D8D80000 29000029
	ds_load_b32 v42, v42                                       // 000000292CC8: D8D80000 2A00002A
	s_clause 0x3                                               // 000000292CD0: BF850003
	global_load_b128 v[25:28], v[37:38], off                   // 000000292CD4: DC5E0000 197C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 000000292CDC: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 000000292CE4: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 000000292CEC: DC5E0030 257C0025
	v_lshrrev_b32_e32 v2, 22, v2                               // 000000292CF4: 32040496
	ds_load_b32 v13, v13                                       // 000000292CF8: D8D80000 0D00000D
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000292D00: 360202FF 000003FC
	v_lshlrev_b32_e32 v43, 2, v43                              // 000000292D08: 30565682
	v_and_b32_e32 v44, 0x3fc, v44                              // 000000292D0C: 365858FF 000003FC
	v_and_b32_e32 v45, 0x3fc, v45                              // 000000292D14: 365A5AFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 000000292D1C: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 000000292D24: D8D80000 01000001
	ds_load_b32 v43, v43                                       // 000000292D2C: D8D80000 2B00002B
	ds_load_b32 v44, v44                                       // 000000292D34: D8D80000 2C00002C
	ds_load_b32 v45, v45                                       // 000000292D3C: D8D80000 2D00002D
	ds_load_b32 v2, v2                                         // 000000292D44: D8D80000 02000002
	v_add_nc_u32_e32 v22, 0x200, v22                           // 000000292D4C: 4A2C2CFF 00000200
	v_add_nc_u32_e32 v23, 64, v23                              // 000000292D54: 4A2E2EC0
	v_add_nc_u32_e32 v12, 0x400, v12                           // 000000292D58: 4A1818FF 00000400
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000292D60: 8B006A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000292D64: BF870149
	s_or_b32 s5, s0, s5                                        // 000000292D68: 8C050500
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 000000292D6C: BF890C57
	v_dot2_f32_bf16 v13, v25, v13, 0                           // 000000292D70: CC1A400D 1A021B19
	v_and_b32_e32 v25, 0xff, v3                                // 000000292D78: 363206FF 000000FF
	v_dot2_f32_bf16 v13, v26, v41, v13                         // 000000292D80: CC1A400D 1C36531A
	v_lshrrev_b32_e32 v26, 6, v3                               // 000000292D88: 32340686
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000292D8C: BF8701A2
	v_dot2_f32_bf16 v13, v27, v42, v13                         // 000000292D90: CC1A400D 1C36551B
	v_lshrrev_b32_e32 v27, 14, v3                              // 000000292D98: 3236068E
	v_and_b32_e32 v26, 0x3fc, v26                              // 000000292D9C: 363434FF 000003FC
	v_lshrrev_b32_e32 v3, 22, v3                               // 000000292DA4: 32060696
	s_waitcnt lgkmcnt(4)                                       // 000000292DA8: BF89FC47
	v_dot2_f32_bf16 v1, v28, v1, v13                           // 000000292DAC: CC1A4001 1C36031C
	v_lshlrev_b32_e32 v13, 2, v25                              // 000000292DB4: 301A3282
	v_and_b32_e32 v27, 0x3fc, v27                              // 000000292DB8: 363636FF 000003FC
	v_and_b32_e32 v25, 0xff, v4                                // 000000292DC0: 363208FF 000000FF
	v_lshrrev_b32_e32 v28, 6, v4                               // 000000292DC8: 32380886
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 000000292DCC: BF890837
	v_dot2_f32_bf16 v1, v29, v43, v1                           // 000000292DD0: CC1A4001 1C06571D
	ds_load_b32 v13, v13                                       // 000000292DD8: D8D80000 0D00000D
	ds_load_b32 v26, v26                                       // 000000292DE0: D8D80000 1A00001A
	ds_load_b32 v27, v27                                       // 000000292DE8: D8D80000 1B00001B
	v_lshrrev_b32_e32 v29, 14, v4                              // 000000292DF0: 323A088E
	s_waitcnt lgkmcnt(5)                                       // 000000292DF4: BF89FC57
	v_dot2_f32_bf16 v1, v30, v44, v1                           // 000000292DF8: CC1A4001 1C06591E
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000292E00: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 000000292E04: 360606FF 000003FC
	v_lshlrev_b32_e32 v25, 2, v25                              // 000000292E0C: 30323282
	v_and_b32_e32 v28, 0x3fc, v28                              // 000000292E10: 363838FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 000000292E18: BF89FC47
	v_dot2_f32_bf16 v1, v31, v45, v1                           // 000000292E1C: CC1A4001 1C065B1F
	v_and_b32_e32 v29, 0x3fc, v29                              // 000000292E24: 363A3AFF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000292E2C: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 000000292E34: BF89FC37
	s_delay_alu instid0(VALU_DEP_3)                            // 000000292E38: BF870003
	v_dot2_f32_bf16 v1, v32, v2, v1                            // 000000292E3C: CC1A4001 1C060520
	ds_load_b32 v2, v3                                         // 000000292E44: D8D80000 02000003
	ds_load_b32 v3, v25                                        // 000000292E4C: D8D80000 03000019
	ds_load_b32 v25, v28                                       // 000000292E54: D8D80000 1900001C
	ds_load_b32 v28, v29                                       // 000000292E5C: D8D80000 1C00001D
	ds_load_b32 v29, v4                                        // 000000292E64: D8D80000 1D000004
	v_mov_b32_e32 v4, v8                                       // 000000292E6C: 7E080308
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000292E70: BF890477
	v_dot2_f32_bf16 v1, v33, v13, v1                           // 000000292E74: CC1A4001 1C061B21
	s_waitcnt lgkmcnt(6)                                       // 000000292E7C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000292E80: BF8700A1
	v_dot2_f32_bf16 v1, v34, v26, v1                           // 000000292E84: CC1A4001 1C063522
	s_waitcnt lgkmcnt(5)                                       // 000000292E8C: BF89FC57
	v_dot2_f32_bf16 v1, v35, v27, v1                           // 000000292E90: CC1A4001 1C063723
	s_waitcnt lgkmcnt(4)                                       // 000000292E98: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000292E9C: BF870131
	v_dot2_f32_bf16 v1, v36, v2, v1                            // 000000292EA0: CC1A4001 1C060524
	v_mov_b32_e32 v2, v6                                       // 000000292EA8: 7E040306
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000292EAC: BF890037
	v_dot2_f32_bf16 v1, v37, v3, v1                            // 000000292EB0: CC1A4001 1C060725
	v_mov_b32_e32 v3, v7                                       // 000000292EB8: 7E060307
	s_waitcnt lgkmcnt(2)                                       // 000000292EBC: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000292EC0: BF8700A2
	v_dot2_f32_bf16 v1, v38, v25, v1                           // 000000292EC4: CC1A4001 1C063326
	s_waitcnt lgkmcnt(1)                                       // 000000292ECC: BF89FC17
	v_dot2_f32_bf16 v1, v39, v28, v1                           // 000000292ED0: CC1A4001 1C063927
	s_waitcnt lgkmcnt(0)                                       // 000000292ED8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000292EDC: BF870121
	v_dot2_f32_bf16 v8, v40, v29, v1                           // 000000292EE0: CC1A4008 1C063B28
	v_mov_b32_e32 v1, v5                                       // 000000292EE8: 7E020305
	v_dual_fmac_f32 v16, v21, v8 :: v_dual_mov_b32 v21, v24    // 000000292EEC: C8101115 10140118
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000292EF4: 917E057E
	s_cbranch_execz 31                                         // 000000292EF8: BFA5001F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x678>
	s_waitcnt vmcnt(0)                                         // 000000292EFC: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v18, 32, v18    // 000000292F00: CA200101 051224A0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 000000292F08: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 000000292F10: 7E100304
	s_mov_b32 s6, exec_lo                                      // 000000292F14: BE86007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000292F18: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v18, v19                          // 000000292F1C: 7C8C2712
	.long 0xd4c1007e                                           // 000000292F20: D4C1007E
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000292F24: 02022712
	s_cbranch_execz 65358                                      // 000000292F28: BFA5FF4E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x364>
	v_ashrrev_i32_e32 v6, 31, v23                              // 000000292F2C: 340C2E9F
	v_ashrrev_i32_e32 v8, 31, v22                              // 000000292F30: 34102C9F
	.long 0xd7000005                                           // 000000292F34: D7000005
	v_cndmask_b32_e32 v1, v11, v23, vcc_lo                     // 000000292F38: 02022F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000292F3C: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v20, v6, s0                  // 000000292F40: D5207C06 00020D14
	.long 0xd7000007                                           // 000000292F48: D7000007
	v_cndmask_b32_e32 v1, v9, v22, vcc_lo                      // 000000292F4C: 02022D09
	v_add_co_ci_u32_e64 v8, null, v10, v8, s0                  // 000000292F50: D5207C08 0002110A
	s_clause 0x1                                               // 000000292F58: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 000000292F5C: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 000000292F64: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 000000292F6C: BF8907F7
	v_cvt_f32_f16_e32 v24, v13                                 // 000000292F70: 7E30170D
	s_branch 65339                                             // 000000292F74: BFA0FF3B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x364>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000292F78: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000292F7C: BF8700C9
	s_or_b32 exec_lo, exec_lo, s4                              // 000000292F80: 8C7E047E
	s_waitcnt vmcnt(0)                                         // 000000292F84: BF8903F7
	.long 0xd71f0001                                           // 000000292F88: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000292F8C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000292F90: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000292F94: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 000000292F98: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 000000292F9C: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000292FA0: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000292FA4: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000292FA8: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 000000292FAC: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 000000292FB0: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000292FB4: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000292FB8: BF870002
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000292FBC: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000292FC0: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000292FC4: 02080901
	ds_bpermute_b32 v2, v2, v16                                // 000000292FC8: DACC0000 02001002
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000292FD0: 30080882
	s_waitcnt lgkmcnt(0)                                       // 000000292FD4: BF89FC07
	v_add_f32_e32 v2, v16, v2                                  // 000000292FD8: 06040510
	ds_bpermute_b32 v3, v3, v2                                 // 000000292FDC: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 000000292FE4: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000292FE8: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 000000292FEC: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 000000292FF4: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000292FF8: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000292FFC: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000293000: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000293004: 30080882
	s_waitcnt lgkmcnt(0)                                       // 000000293008: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 00000029300C: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 000000293010: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 000000293018: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000029301C: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000293020: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 000000293024: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 000000293028: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 000000293030: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 000000293034: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v15                                   // 00000029303C: 7D941E80
	s_cbranch_execz 9                                          // 000000293040: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x768>
	v_lshlrev_b32_e32 v3, 2, v17                               // 000000293044: 30062282
	v_lshlrev_b32_e32 v4, s1, v14                              // 000000293048: 30081C01
	s_waitcnt lgkmcnt(0)                                       // 00000029304C: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 000000293050: 06020501
	s_delay_alu instid0(VALU_DEP_2)                            // 000000293054: BF870002
	v_lshl_add_u32 v3, v4, 2, v3                               // 000000293058: D6460003 040D0504
	ds_store_b32 v3, v1 offset:1024                            // 000000293060: D8340400 00000103
	s_or_b32 exec_lo, exec_lo, s0                              // 000000293068: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029306C: BF870009
	s_and_b32 s0, s20, exec_lo                                 // 000000293070: 8B007E14
	s_cselect_b32 s0, 1, 4                                     // 000000293074: 98008481
	s_waitcnt lgkmcnt(0)                                       // 000000293078: BF89FC07
	v_cmp_gt_u32_e32 vcc_lo, s0, v0                            // 00000029307C: 7C980000
	s_barrier                                                  // 000000293080: BFBD0000
	buffer_gl0_inv                                             // 000000293084: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 00000029308C: BE80206A
	s_cbranch_execz 325                                        // 000000293090: BFA50145 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0xca8>
	s_load_b32 s0, s[16:17], 0x40                              // 000000293094: F4000008 F8000040
	s_waitcnt lgkmcnt(0)                                       // 00000029309C: BF89FC07
	s_sub_i32 s4, s2, s0                                       // 0000002930A0: 81840002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002930A4: BF870499
	s_ashr_i32 s5, s4, 31                                      // 0000002930A8: 86059F04
	s_lshl_b64 s[4:5], s[4:5], s21                             // 0000002930AC: 84841504
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002930B0: BF870099
	.long 0xd7000001                                           // 0000002930B4: D7000001
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002930B8: 02020004
	v_add_co_ci_u32_e64 v2, null, s5, 0, s0                    // 0000002930BC: D5207C02 00010005
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002930C4: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[10:11], v[1:2]                  // 0000002930C8: 7CA8020A
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000002930CC: 8B7E6A7E
	s_cbranch_execz 309                                        // 0000002930D0: BFA50135 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0xca8>
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v0, s1, v0      // 0000002930D4: CA220080 03000001
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002930DC: BF870001
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000002930E0: 30000082
	ds_load_b32 v4, v0 offset:1024                             // 0000002930E4: D8D80400 04000000
	v_add_nc_u32_e32 v0, 4, v0                                 // 0000002930EC: 4A000084
	s_add_i32 s3, s3, -1                                       // 0000002930F0: 8103C103
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002930F4: BF870009
	s_cmp_eq_u32 s3, 0                                         // 0000002930F8: BF068003
	s_waitcnt lgkmcnt(0)                                       // 0000002930FC: BF89FC07
	v_add_f32_e32 v3, v3, v4                                   // 000000293100: 06060903
	s_cbranch_scc0 65527                                       // 000000293104: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x7e4>
	s_clause 0x1                                               // 000000293108: BF850001
	s_load_b64 s[4:5], s[16:17], 0x38                          // 00000029310C: F4040108 F8000038
	s_load_b64 s[2:3], s[16:17], 0x8                           // 000000293114: F4040088 F8000008
	s_mov_b32 s6, -1                                           // 00000029311C: BE8600C1
	s_mov_b32 s1, 0                                            // 000000293120: BE810080
	s_mov_b32 s0, 0                                            // 000000293124: BE800080
	s_waitcnt lgkmcnt(0)                                       // 000000293128: BF89FC07
	s_cmp_lt_i32 s5, 3                                         // 00000029312C: BF048305
	s_cbranch_scc1 155                                         // 000000293130: BFA2009B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0xaa0>
	s_cmp_gt_i32 s5, 3                                         // 000000293134: BF028305
	s_cbranch_scc0 100                                         // 000000293138: BFA10064 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x9cc>
	s_cmp_gt_i32 s5, 4                                         // 00000029313C: BF028405
	s_cbranch_scc0 57                                          // 000000293140: BFA10039 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x928>
	s_cmp_eq_u32 s5, 5                                         // 000000293144: BF068505
	s_mov_b32 s0, -1                                           // 000000293148: BE8000C1
	s_cbranch_scc0 53                                          // 00000029314C: BFA10035 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x924>
	v_lshrrev_b32_e32 v0, 23, v2                               // 000000293150: 32000497
	s_load_b64 s[6:7], s[16:17], 0x10                          // 000000293154: F4040188 F8000010
	v_mov_b32_e32 v7, s3                                       // 00000029315C: 7E0E0203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000293160: BF870092
	.long 0xd7006a00                                           // 000000293164: D7006A00
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 000000293168: 02020101
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 00000029316C: D5207C06 01AA0480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000293174: BF870092
	v_and_b32_e32 v0, 0xfffffe00, v0                           // 000000293178: 360000FF FFFFFE00
	.long 0xd7016a04                                           // 000000293180: D7016A04
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 000000293184: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000293188: BF870111
	v_sub_co_ci_u32_e64 v5, null, v2, v6, vcc_lo               // 00000029318C: D5217C05 01AA0D02
	.long 0xd7000008                                           // 000000293194: D7000008
	v_cndmask_b32_e32 v1, 0xffffff00, v4, vcc_lo               // 000000293198: 020208FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002931A0: BF870002
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[4:5]                     // 0000002931A4: 7CA808FF 00000100
	v_add_co_ci_u32_e64 v9, null, -1, v5, s0                   // 0000002931AC: D5207C09 00020AC1
	v_mov_b32_e32 v10, s2                                      // 0000002931B4: 7E140202
	s_mov_b32 s0, 0                                            // 0000002931B8: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000002931BC: BF89FC07
	v_dual_cndmask_b32 v7, s7, v7 :: v_dual_cndmask_b32 v4, v8, v4// 0000002931C0: CA520E07 07040908
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002931C8: BF870122
	v_dual_cndmask_b32 v5, v9, v5 :: v_dual_cndmask_b32 v8, s6, v10// 0000002931CC: CA520B09 05081406
	v_bfe_u32 v9, v3, 16, 1                                    // 0000002931D4: D6100009 02052103
	.long 0xd73c0004                                           // 0000002931DC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002931E0: 02020881
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002931E4: BF870093
	.long 0xd7006a00                                           // 0000002931E8: D7006A00
	v_cndmask_b32_e32 v1, v8, v0, vcc_lo                       // 0000002931EC: 02020108
	v_add_co_ci_u32_e64 v6, null, v7, v6, vcc_lo               // 0000002931F0: D5207C06 01AA0D07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002931F8: BF870194
	v_add3_u32 v7, v3, v9, 0x7fff                              // 0000002931FC: D6550007 03FE1303 00007FFF
	.long 0xd7006a04                                           // 000000293208: D7006A04
	v_cndmask_b32_e32 v1, v0, v4, vcc_lo                       // 00000029320C: 02020900
	s_delay_alu instid0(VALU_DEP_1)                            // 000000293210: BF870001
	v_add_co_ci_u32_e64 v5, null, v6, v5, vcc_lo               // 000000293214: D5207C05 01AA0B06
	global_store_d16_hi_b16 v[4:5], v7, off                    // 00000029321C: DC960000 007C0704
	s_mov_b32 s6, 0                                            // 000000293224: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000293228: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000029322C: 8B6A067E
	s_cbranch_vccz 37                                          // 000000293230: BFA30025 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0x9c8>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v3                           // 000000293234: 100006FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029323C: BF870291
	v_exp_f32_e32 v0, v0                                       // 000000293240: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 000000293244: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000293248: BF870121
	v_div_scale_f32 v4, null, v0, v0, 1.0                      // 00000029324C: D6FC7C04 03CA0100
	v_div_scale_f32 v7, vcc_lo, 1.0, v0, 1.0                   // 000000293254: D6FC6A07 03CA00F2
	v_rcp_f32_e32 v5, v4                                       // 00000029325C: 7E0A5504
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000293260: BF870095
	v_fma_f32 v6, -v4, v5, 1.0                                 // 000000293264: D6130006 23CA0B04
	v_fmac_f32_e32 v5, v6, v5                                  // 00000029326C: 560A0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000293270: BF870091
	v_mul_f32_e32 v6, v7, v5                                   // 000000293274: 100C0B07
	v_fma_f32 v8, -v4, v6, v7                                  // 000000293278: D6130008 241E0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000293280: BF870091
	v_fmac_f32_e32 v6, v8, v5                                  // 000000293284: 560C0B08
	v_fma_f32 v4, -v4, v6, v7                                  // 000000293288: D6130004 241E0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000293290: BF870121
	v_div_fmas_f32 v6, v4, v5, v6                              // 000000293294: D6370006 041A0B04
	.long 0xd73c0004                                           // 00000029329C: D73C0004
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000002932A0: 02020282
	v_div_fixup_f32 v0, v6, v0, 1.0                            // 0000002932A4: D6270000 03CA0106
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002932AC: BF870092
	.long 0xd7006a04                                           // 0000002932B0: D7006A04
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 0000002932B4: 02020802
	v_add_co_ci_u32_e64 v5, null, s3, v5, vcc_lo               // 0000002932B8: D5207C05 01AA0A03
	global_store_b32 v[4:5], v0, off                           // 0000002932C0: DC6A0000 007C0004
	s_mov_b32 s6, 0                                            // 0000002932C8: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002932CC: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002932D0: 8B6A067E
	s_cbranch_vccz 49                                          // 0000002932D4: BFA30031 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0xa9c>
	v_bfe_u32 v0, v3, 16, 1                                    // 0000002932D8: D6100000 02052103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002932E0: BF870091
	v_add3_u32 v0, v3, v0, 0x7fff                              // 0000002932E4: D6550000 03FE0103 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002932F0: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002932F8: BF870091
	v_mul_f32_e32 v0, s4, v0                                   // 0000002932FC: 10000004
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 000000293300: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000293308: BF870291
	v_exp_f32_e32 v0, v0                                       // 00000029330C: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 000000293310: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000293314: BF870121
	v_div_scale_f32 v4, null, v0, v0, 1.0                      // 000000293318: D6FC7C04 03CA0100
	v_div_scale_f32 v7, vcc_lo, 1.0, v0, 1.0                   // 000000293320: D6FC6A07 03CA00F2
	v_rcp_f32_e32 v5, v4                                       // 000000293328: 7E0A5504
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029332C: BF870095
	v_fma_f32 v6, -v4, v5, 1.0                                 // 000000293330: D6130006 23CA0B04
	v_fmac_f32_e32 v5, v6, v5                                  // 000000293338: 560A0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029333C: BF870091
	v_mul_f32_e32 v6, v7, v5                                   // 000000293340: 100C0B07
	v_fma_f32 v8, -v4, v6, v7                                  // 000000293344: D6130008 241E0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029334C: BF870091
	v_fmac_f32_e32 v6, v8, v5                                  // 000000293350: 560C0B08
	v_fma_f32 v4, -v4, v6, v7                                  // 000000293354: D6130004 241E0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029335C: BF870091
	v_div_fmas_f32 v4, v4, v5, v6                              // 000000293360: D6370004 041A0B04
	v_div_fixup_f32 v0, v4, v0, 1.0                            // 000000293368: D6270000 03CA0104
	.long 0xd73c0004                                           // 000000293370: D73C0004
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000293374: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000293378: BF870112
	v_add_f32_e32 v0, v0, v0                                   // 00000029337C: 06000100
	.long 0xd7006a04                                           // 000000293380: D7006A04
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 000000293384: 02020802
	s_delay_alu instid0(VALU_DEP_1)                            // 000000293388: BF870001
	v_add_co_ci_u32_e64 v5, null, s3, v5, vcc_lo               // 00000029338C: D5207C05 01AA0A03
	global_store_b32 v[4:5], v0, off                           // 000000293394: DC6A0000 007C0004
	s_mov_b32 s6, 0                                            // 00000029339C: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002933A0: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002933A4: 8B6A067E
	s_cbranch_vccz 62                                          // 0000002933A8: BFA3003E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0xba4>
	s_cmp_gt_i32 s5, 1                                         // 0000002933AC: BF028105
	s_mov_b32 s1, -1                                           // 0000002933B0: BE8100C1
	s_cbranch_scc0 53                                          // 0000002933B4: BFA10035 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0xb8c>
	v_bfe_u32 v0, v3, 16, 1                                    // 0000002933B8: D6100000 02052103
	s_mov_b32 s1, 0                                            // 0000002933C0: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002933C4: BF870091
	v_add3_u32 v0, v3, v0, 0x7fff                              // 0000002933C8: D6550000 03FE0103 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002933D4: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002933DC: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002933E0: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000002933E8: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002933EC: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002933F0: 060000F2
	v_div_scale_f32 v4, null, v0, v0, 1.0                      // 0000002933F4: D6FC7C04 03CA0100
	v_div_scale_f32 v7, vcc_lo, 1.0, v0, 1.0                   // 0000002933FC: D6FC6A07 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000293404: BF870292
	v_rcp_f32_e32 v5, v4                                       // 000000293408: 7E0A5504
	v_fma_f32 v6, -v4, v5, 1.0                                 // 00000029340C: D6130006 23CA0B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000293414: BF870091
	v_fmac_f32_e32 v5, v6, v5                                  // 000000293418: 560A0B06
	v_mul_f32_e32 v6, v7, v5                                   // 00000029341C: 100C0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000293420: BF870091
	v_fma_f32 v8, -v4, v6, v7                                  // 000000293424: D6130008 241E0D04
	v_fmac_f32_e32 v6, v8, v5                                  // 00000029342C: 560C0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000293430: BF870091
	v_fma_f32 v4, -v4, v6, v7                                  // 000000293434: D6130004 241E0D04
	v_div_fmas_f32 v4, v4, v5, v6                              // 00000029343C: D6370004 041A0B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000293444: BF870121
	v_div_fixup_f32 v0, v4, v0, 1.0                            // 000000293448: D6270000 03CA0104
	.long 0xd73c0004                                           // 000000293450: D73C0004
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000293454: 02020281
	v_bfe_u32 v6, v0, 16, 1                                    // 000000293458: D6100006 02052100
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000293460: BF870092
	.long 0xd7006a04                                           // 000000293464: D7006A04
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 000000293468: 02020802
	v_add_co_ci_u32_e64 v5, null, s3, v5, vcc_lo               // 00000029346C: D5207C05 01AA0A03
	s_delay_alu instid0(VALU_DEP_3)                            // 000000293474: BF870003
	v_add3_u32 v0, v0, v6, 0x7fff                              // 000000293478: D6550000 03FE0D00 00007FFF
	global_store_d16_hi_b16 v[4:5], v0, off                    // 000000293484: DC960000 007C0004
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000029348C: 916A017E
	s_mov_b32 s1, 0                                            // 000000293490: BE810080
	s_cbranch_vccnz 3                                          // 000000293494: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0xba4>
	s_cmp_lg_u32 s5, 1                                         // 000000293498: BF078105
	s_mov_b32 s1, -1                                           // 00000029349C: BE8100C1
	s_cselect_b32 s0, -1, 0                                    // 0000002934A0: 980080C1
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002934A4: D6100004 02052103
	.long 0xd73c0000                                           // 0000002934AC: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002934B0: 02020281
	s_and_b32 vcc_lo, exec_lo, s0                              // 0000002934B4: 8B6A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002934B8: BF870002
	v_add3_u32 v2, v3, v4, 0x7fff                              // 0000002934BC: D6550002 03FE0903 00007FFF
	s_cbranch_vccz 8                                           // 0000002934C8: BFA30008 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0xbec>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002934CC: BF870092
	.long 0xd7006a03                                           // 0000002934D0: D7006A03
	v_cndmask_b32_e32 v1, s2, v0, vcc_lo                       // 0000002934D4: 02020002
	v_add_co_ci_u32_e64 v4, null, s3, v1, vcc_lo               // 0000002934D8: D5207C04 01AA0203
	s_mov_b32 s1, 0                                            // 0000002934E0: BE810080
	global_store_d16_hi_b16 v[3:4], v2, off                    // 0000002934E4: DC960000 007C0203
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002934EC: 916A017E
	s_cbranch_vccnz 45                                         // 0000002934F0: BFA4002D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi32ELi2ELi0EEEvNS0_5LqGrpEPKtl+0xca8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002934F4: BF870091
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000002934F8: 360404FF FFFF0000
	v_mul_f32_e32 v2, s4, v2                                   // 000000293500: 10040404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000293504: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v2                           // 000000293508: 100604FF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 000000293510: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000293514: BF870095
	v_add_f32_e32 v3, 1.0, v3                                  // 000000293518: 060606F2
	v_div_scale_f32 v4, null, v3, v3, v2                       // 00000029351C: D6FC7C04 040A0703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000293524: BF870291
	v_rcp_f32_e32 v5, v4                                       // 000000293528: 7E0A5504
	v_fma_f32 v6, -v4, v5, 1.0                                 // 00000029352C: D6130006 23CA0B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000293534: BF8700A1
	v_fmac_f32_e32 v5, v6, v5                                  // 000000293538: 560A0B06
	v_div_scale_f32 v7, vcc_lo, v2, v3, v2                     // 00000029353C: D6FC6A07 040A0702
	v_mul_f32_e32 v6, v7, v5                                   // 000000293544: 100C0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000293548: BF870091
	v_fma_f32 v8, -v4, v6, v7                                  // 00000029354C: D6130008 241E0D04
	v_fmac_f32_e32 v6, v8, v5                                  // 000000293554: 560C0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000293558: BF870091
	v_fma_f32 v4, -v4, v6, v7                                  // 00000029355C: D6130004 241E0D04
	v_div_fmas_f32 v4, v4, v5, v6                              // 000000293564: D6370004 041A0B04
	.long 0xd7006a00                                           // 00000029356C: D7006A00
	v_cndmask_b32_e32 v1, s2, v0, vcc_lo                       // 000000293570: 02020002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000293574: BF870191
	v_add_co_ci_u32_e64 v1, null, s3, v1, vcc_lo               // 000000293578: D5207C01 01AA0203
	v_div_fixup_f32 v2, v4, v3, v2                             // 000000293580: D6270002 040A0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000293588: BF870091
	v_bfe_u32 v3, v2, 16, 1                                    // 00000029358C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000293594: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002935A0: DC960000 007C0200
	s_endpgm                                                   // 0000002935A8: BFB00000
		...

