0000000000229200 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_selEPKhPtPKilllll>:
; _ZN7halogen12_GLOBAL__N_114k_deq_q4cp_selEPKhPtPKilllll():
	s_load_b512 s[4:19], s[0:1], null                          // 000000229200: F4100100 F8000000
	s_mov_b32 s3, 0                                            // 000000229208: BE830080
	s_waitcnt lgkmcnt(0)                                       // 00000022920C: BF89FC07
	s_cmp_lg_u32 s11, 0                                        // 000000229210: BF07800B
	s_cbranch_scc0 307                                         // 000000229214: BFA10133 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_selEPKhPtPKilllll+0x4e4>
	s_ashr_i32 s20, s11, 31                                    // 000000229218: 86149F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000022921C: BF8704B9
	s_add_u32 s22, s10, s20                                    // 000000229220: 8016140A
	s_mov_b32 s21, s20                                         // 000000229224: BE950014
	s_addc_u32 s23, s11, s20                                   // 000000229228: 8217140B
	s_xor_b64 s[22:23], s[22:23], s[20:21]                     // 00000022922C: 8D961416
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000229230: BF8704C9
	s_cvt_f32_u32 s24, s22                                     // 000000229234: BE986516
	s_cvt_f32_u32 s25, s23                                     // 000000229238: BE996517
	s_sub_u32 s26, 0, s22                                      // 00000022923C: 809A1680
	s_subb_u32 s27, 0, s23                                     // 000000229240: 829B1780
	s_fmamk_f32 s24, s25, 0x4f800000, s24                      // 000000229244: A3181819 4F800000
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000022924C: BF87029B
	v_rcp_f32_e32 v1, s24                                      // 000000229250: 7E025418
	v_readfirstlane_b32 s24, v1                                // 000000229254: 7E300501
	s_mul_f32 s24, s24, 0x5f7ffffc                             // 000000229258: A218FF18 5F7FFFFC
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000229260: BF87059B
	s_mul_f32 s25, s24, 0x2f800000                             // 000000229264: A219FF18 2F800000
	s_trunc_f32 s25, s25                                       // 00000022926C: BE996219
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 000000229270: BF87052B
	s_fmamk_f32 s24, s25, 0xcf800000, s24                      // 000000229274: A3181819 CF800000
	s_cvt_u32_f32 s25, s25                                     // 00000022927C: BE996719
	s_cvt_u32_f32 s24, s24                                     // 000000229280: BE986718
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_2)// 000000229284: BF87051A
	s_mul_i32 s28, s26, s25                                    // 000000229288: 961C191A
	s_mul_hi_u32 s30, s26, s24                                 // 00000022928C: 969E181A
	s_mul_i32 s29, s27, s24                                    // 000000229290: 961D181B
	s_add_i32 s28, s30, s28                                    // 000000229294: 811C1C1E
	s_mul_i32 s31, s26, s24                                    // 000000229298: 961F181A
	s_add_i32 s28, s28, s29                                    // 00000022929C: 811C1D1C
	s_mul_hi_u32 s30, s24, s31                                 // 0000002292A0: 969E1F18
	s_mul_i32 s34, s24, s28                                    // 0000002292A4: 96221C18
	s_mul_hi_u32 s33, s25, s31                                 // 0000002292A8: 96A11F19
	s_mul_i32 s29, s25, s31                                    // 0000002292AC: 961D1F19
	s_mul_hi_u32 s31, s24, s28                                 // 0000002292B0: 969F1C18
	s_add_u32 s30, s30, s34                                    // 0000002292B4: 801E221E
	s_addc_u32 s31, 0, s31                                     // 0000002292B8: 821F1F80
	s_mul_hi_u32 s35, s25, s28                                 // 0000002292BC: 96A31C19
	s_add_u32 s29, s30, s29                                    // 0000002292C0: 801D1D1E
	s_mul_i32 s28, s25, s28                                    // 0000002292C4: 961C1C19
	s_addc_u32 s29, s31, s33                                   // 0000002292C8: 821D211F
	s_addc_u32 s30, s35, 0                                     // 0000002292CC: 821E8023
	s_add_u32 s28, s29, s28                                    // 0000002292D0: 801C1C1D
	s_addc_u32 s29, 0, s30                                     // 0000002292D4: 821D1E80
	s_add_u32 s24, s24, s28                                    // 0000002292D8: 80181C18
	s_addc_u32 s25, s25, s29                                   // 0000002292DC: 82191D19
	s_mul_hi_u32 s28, s26, s24                                 // 0000002292E0: 969C181A
	s_mul_i32 s29, s26, s24                                    // 0000002292E4: 961D181A
	s_mul_i32 s26, s26, s25                                    // 0000002292E8: 961A191A
	s_mul_i32 s27, s27, s24                                    // 0000002292EC: 961B181B
	s_add_i32 s26, s28, s26                                    // 0000002292F0: 811A1A1C
	s_mul_i32 s28, s25, s29                                    // 0000002292F4: 961C1D19
	s_add_i32 s26, s26, s27                                    // 0000002292F8: 811A1B1A
	s_mul_hi_u32 s27, s24, s29                                 // 0000002292FC: 969B1D18
	s_mul_i32 s33, s24, s26                                    // 000000229300: 96211A18
	s_mul_hi_u32 s31, s24, s26                                 // 000000229304: 969F1A18
	s_add_u32 s27, s27, s33                                    // 000000229308: 801B211B
	s_mul_hi_u32 s30, s25, s29                                 // 00000022930C: 969E1D19
	s_addc_u32 s31, 0, s31                                     // 000000229310: 821F1F80
	s_mul_hi_u32 s29, s25, s26                                 // 000000229314: 969D1A19
	s_add_u32 s27, s27, s28                                    // 000000229318: 801B1C1B
	s_mul_i32 s26, s25, s26                                    // 00000022931C: 961A1A19
	s_addc_u32 s27, s31, s30                                   // 000000229320: 821B1E1F
	s_addc_u32 s28, s29, 0                                     // 000000229324: 821C801D
	s_add_u32 s26, s27, s26                                    // 000000229328: 801A1A1B
	s_addc_u32 s27, 0, s28                                     // 00000022932C: 821B1C80
	s_add_u32 s26, s24, s26                                    // 000000229330: 801A1A18
	s_addc_u32 s27, s25, s27                                   // 000000229334: 821B1B19
	s_add_u32 s24, s2, 0                                       // 000000229338: 80188002
	s_addc_u32 s25, 0, 0                                       // 00000022933C: 82198080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000229340: BF870499
	s_xor_b64 s[24:25], s[24:25], 0                            // 000000229344: 8D988018
	s_mul_i32 s29, s24, s27                                    // 000000229348: 961D1B18
	s_mul_hi_u32 s30, s24, s26                                 // 00000022934C: 969E1A18
	s_mul_hi_u32 s28, s24, s27                                 // 000000229350: 969C1B18
	s_mul_hi_u32 s33, s25, s26                                 // 000000229354: 96A11A19
	s_mul_i32 s26, s25, s26                                    // 000000229358: 961A1A19
	s_add_u32 s29, s30, s29                                    // 00000022935C: 801D1D1E
	s_addc_u32 s28, 0, s28                                     // 000000229360: 821C1C80
	s_mul_hi_u32 s31, s25, s27                                 // 000000229364: 969F1B19
	s_add_u32 s26, s29, s26                                    // 000000229368: 801A1A1D
	s_mul_i32 s27, s25, s27                                    // 00000022936C: 961B1B19
	s_addc_u32 s26, s28, s33                                   // 000000229370: 821A211C
	s_addc_u32 s28, s31, 0                                     // 000000229374: 821C801F
	s_add_u32 s26, s26, s27                                    // 000000229378: 801A1B1A
	s_addc_u32 s27, 0, s28                                     // 00000022937C: 821B1C80
	s_mul_hi_u32 s28, s22, s26                                 // 000000229380: 969C1A16
	s_mul_i32 s29, s22, s27                                    // 000000229384: 961D1B16
	s_mul_i32 s30, s23, s26                                    // 000000229388: 961E1A17
	s_add_i32 s28, s28, s29                                    // 00000022938C: 811C1D1C
	s_mul_i32 s29, s22, s26                                    // 000000229390: 961D1A16
	s_add_i32 s28, s28, s30                                    // 000000229394: 811C1E1C
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000229398: BF870009
	s_sub_i32 s30, s25, s28                                    // 00000022939C: 819E1C19
	s_sub_u32 s24, s24, s29                                    // 0000002293A0: 80981D18
	s_cselect_b32 s29, -1, 0                                   // 0000002293A4: 981D80C1
	s_subb_u32 s30, s30, s23                                   // 0000002293A8: 829E171E
	s_sub_u32 s31, s24, s22                                    // 0000002293AC: 809F1618
	s_subb_u32 s30, s30, 0                                     // 0000002293B0: 829E801E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002293B4: BF870009
	s_cmp_ge_u32 s30, s23                                      // 0000002293B8: BF09171E
	s_cselect_b32 s33, -1, 0                                   // 0000002293BC: 982180C1
	s_cmp_ge_u32 s31, s22                                      // 0000002293C0: BF09161F
	s_cselect_b32 s31, -1, 0                                   // 0000002293C4: 981F80C1
	s_cmp_eq_u32 s30, s23                                      // 0000002293C8: BF06171E
	s_cselect_b32 s30, s31, s33                                // 0000002293CC: 981E211F
	s_add_u32 s31, s26, 1                                      // 0000002293D0: 801F811A
	s_addc_u32 s33, s27, 0                                     // 0000002293D4: 8221801B
	s_add_u32 s34, s26, 2                                      // 0000002293D8: 8022821A
	s_addc_u32 s35, s27, 0                                     // 0000002293DC: 8223801B
	s_cmp_lg_u32 s30, 0                                        // 0000002293E0: BF07801E
	s_cselect_b32 s30, s34, s31                                // 0000002293E4: 981E1F22
	s_cselect_b32 s31, s35, s33                                // 0000002293E8: 981F2123
	s_cmp_lg_u32 s29, 0                                        // 0000002293EC: BF07801D
	s_subb_u32 s25, s25, s28                                   // 0000002293F0: 82991C19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002293F4: BF870009
	s_cmp_ge_u32 s25, s23                                      // 0000002293F8: BF091719
	s_cselect_b32 s28, -1, 0                                   // 0000002293FC: 981C80C1
	s_cmp_ge_u32 s24, s22                                      // 000000229400: BF091618
	s_cselect_b32 s22, -1, 0                                   // 000000229404: 981680C1
	s_cmp_eq_u32 s25, s23                                      // 000000229408: BF061719
	s_cselect_b32 s22, s22, s28                                // 00000022940C: 98161C16
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000229410: BF8704C9
	s_cmp_lg_u32 s22, 0                                        // 000000229414: BF078016
	s_cselect_b32 s23, s31, s27                                // 000000229418: 98171B1F
	s_cselect_b32 s22, s30, s26                                // 00000022941C: 98161A1E
	s_xor_b64 s[20:21], 0, s[20:21]                            // 000000229420: 8D941480
	s_xor_b64 s[22:23], s[22:23], s[20:21]                     // 000000229424: 8D961416
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000229428: BF870009
	s_sub_u32 s20, s22, s20                                    // 00000022942C: 80941416
	s_subb_u32 s21, s23, s21                                   // 000000229430: 82951517
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 000000229434: 916A037E
	s_cbranch_vccnz 27                                         // 000000229438: BFA4001B <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_selEPKhPtPKilllll+0x2a8>
	v_cvt_f32_u32_e32 v1, s10                                  // 00000022943C: 7E020C0A
	s_sub_i32 s20, 0, s10                                      // 000000229440: 81940A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000229444: BF870291
	v_rcp_iflag_f32_e32 v1, v1                                 // 000000229448: 7E025701
	v_mul_f32_e32 v1, 0x4f7ffffe, v1                           // 00000022944C: 100202FF 4F7FFFFE
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000229454: BF870091
	v_cvt_u32_f32_e32 v1, v1                                   // 000000229458: 7E020F01
	v_readfirstlane_b32 s3, v1                                 // 00000022945C: 7E060501
	s_mul_i32 s20, s20, s3                                     // 000000229460: 96140314
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000229464: BF870499
	s_mul_hi_u32 s20, s3, s20                                  // 000000229468: 96941403
	s_add_i32 s3, s3, s20                                      // 00000022946C: 81031403
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000229470: BF870499
	s_mul_hi_u32 s3, s2, s3                                    // 000000229474: 96830302
	s_mul_i32 s20, s3, s10                                     // 000000229478: 96140A03
	s_add_i32 s21, s3, 1                                       // 00000022947C: 81158103
	s_sub_i32 s20, s2, s20                                     // 000000229480: 81941402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000229484: BF870009
	s_sub_i32 s22, s20, s10                                    // 000000229488: 81960A14
	s_cmp_ge_u32 s20, s10                                      // 00000022948C: BF090A14
	s_cselect_b32 s3, s21, s3                                  // 000000229490: 98030315
	s_cselect_b32 s20, s22, s20                                // 000000229494: 98141416
	s_add_i32 s22, s3, 1                                       // 000000229498: 81168103
	s_cmp_ge_u32 s20, s10                                      // 00000022949C: BF090A14
	s_mov_b32 s21, 0                                           // 0000002294A0: BE950080
	s_cselect_b32 s20, s22, s3                                 // 0000002294A4: 98140316
	v_mov_b32_e32 v1, 0                                        // 0000002294A8: 7E020280
	s_mov_b32 s3, exec_lo                                      // 0000002294AC: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002294B0: BF870001
	.long 0xd4d4007e                                           // 0000002294B4: D4D4007E
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 0000002294B8: 0202000C
	s_cbranch_execz 135                                        // 0000002294BC: BFA50087 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_selEPKhPtPKilllll+0x4dc>
	s_lshl_b64 s[22:23], s[20:21], 2                           // 0000002294C0: 84968214
	s_mul_i32 s21, s21, s10                                    // 0000002294C4: 96150A15
	s_add_u32 s8, s8, s22                                      // 0000002294C8: 80081608
	s_addc_u32 s9, s9, s23                                     // 0000002294CC: 82091709
	s_load_b32 s23, s[0:1], 0x4c                               // 0000002294D0: F40005C0 F800004C
	s_load_b32 s3, s[8:9], null                                // 0000002294D8: F40000C4 F8000000
	s_mul_i32 s8, s20, s11                                     // 0000002294E0: 96080B14
	s_mul_hi_u32 s9, s20, s10                                  // 0000002294E4: 96890A14
	s_mul_i32 s22, s20, s10                                    // 0000002294E8: 96160A14
	s_add_i32 s0, s9, s8                                       // 0000002294EC: 81000809
	s_mul_i32 s24, s13, s2                                     // 0000002294F0: 9618020D
	s_add_i32 s0, s0, s21                                      // 0000002294F4: 81001500
	s_mul_hi_u32 s25, s12, s2                                  // 0000002294F8: 9699020C
	s_mul_i32 s20, s12, s2                                     // 0000002294FC: 9614020C
	v_dual_mov_b32 v5, v1 :: v_dual_lshlrev_b32 v2, 1, v0      // 000000229500: CA220101 05020081
	v_mov_b32_e32 v4, v0                                       // 000000229508: 7E080300
	s_waitcnt lgkmcnt(0)                                       // 00000022950C: BF89FC07
	s_ashr_i32 s1, s3, 31                                      // 000000229510: 86019F03
	s_mul_hi_u32 s8, s10, s3                                   // 000000229514: 9688030A
	s_mul_i32 s1, s10, s1                                      // 000000229518: 9601010A
	s_mul_i32 s9, s11, s3                                      // 00000022951C: 9609030B
	s_add_i32 s1, s8, s1                                       // 000000229520: 81010108
	s_mul_i32 s3, s10, s3                                      // 000000229524: 9603030A
	s_add_i32 s1, s1, s9                                       // 000000229528: 81010901
	s_sub_u32 s2, s2, s22                                      // 00000022952C: 80821602
	s_subb_u32 s0, 0, s0                                       // 000000229530: 82800080
	s_add_u32 s3, s3, s2                                       // 000000229534: 80030203
	s_addc_u32 s2, s1, s0                                      // 000000229538: 82020001
	s_add_u32 s8, s4, s14                                      // 00000022953C: 80080E04
	s_addc_u32 s9, s5, s15                                     // 000000229540: 82090F05
	s_lshr_b32 s0, s13, 31                                     // 000000229544: 85009F0D
	s_mul_i32 s14, s2, s18                                     // 000000229548: 960E1202
	s_add_u32 s0, s12, s0                                      // 00000022954C: 8000000C
	s_addc_u32 s1, s13, 0                                      // 000000229550: 8201800D
	s_mul_i32 s10, s3, s19                                     // 000000229554: 960A1303
	s_ashr_i64 s[0:1], s[0:1], 1                               // 000000229558: 86808100
	s_mul_hi_u32 s11, s3, s18                                  // 00000022955C: 968B1203
	s_mul_i32 s1, s3, s1                                       // 000000229560: 96010103
	s_mul_hi_u32 s15, s3, s0                                   // 000000229564: 968F0003
	s_mul_i32 s2, s2, s0                                       // 000000229568: 96020002
	s_add_i32 s1, s15, s1                                      // 00000022956C: 8101010F
	s_mul_i32 s0, s3, s0                                       // 000000229570: 96000003
	s_add_i32 s2, s1, s2                                       // 000000229574: 81020201
	s_add_u32 s1, s8, s0                                       // 000000229578: 80010008
	s_addc_u32 s2, s9, s2                                      // 00000022957C: 82020209
	s_add_u32 s0, s4, s16                                      // 000000229580: 80001004
	s_addc_u32 s8, s5, s17                                     // 000000229584: 82081105
	s_add_i32 s9, s11, s10                                     // 000000229588: 81090A0B
	s_mul_i32 s3, s3, s18                                      // 00000022958C: 96031203
	s_add_i32 s9, s9, s14                                      // 000000229590: 81090E09
	s_add_u32 s3, s0, s3                                       // 000000229594: 80030300
	s_addc_u32 s8, s8, s9                                      // 000000229598: 82080908
	s_add_i32 s21, s25, s24                                    // 00000022959C: 81151819
	s_and_b32 s9, s23, 0xffff                                  // 0000002295A0: 8B09FF17 0000FFFF
	s_lshl_b64 s[10:11], s[20:21], 1                           // 0000002295A8: 848A8114
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002295AC: BF8700B9
	s_add_u32 s0, s6, s10                                      // 0000002295B0: 80000A06
	s_addc_u32 s6, s7, s11                                     // 0000002295B4: 82060B07
	.long 0xd7000002                                           // 0000002295B8: D7000002
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 0000002295BC: 02020400
	v_add_co_ci_u32_e64 v3, null, s6, 0, s0                    // 0000002295C0: D5207C03 00010006
	s_mov_b32 s6, 0                                            // 0000002295C8: BE860080
	s_lshl_b32 s7, s9, 1                                       // 0000002295CC: 84078109
	s_set_inst_prefetch_distance 0x1                           // 0000002295D0: BF840001
	s_nop 0                                                    // 0000002295D4: BF800000
	s_nop 0                                                    // 0000002295D8: BF800000
	s_nop 0                                                    // 0000002295DC: BF800000
	s_nop 0                                                    // 0000002295E0: BF800000
	s_nop 0                                                    // 0000002295E4: BF800000
	s_nop 0                                                    // 0000002295E8: BF800000
	s_nop 0                                                    // 0000002295EC: BF800000
	s_nop 0                                                    // 0000002295F0: BF800000
	s_nop 0                                                    // 0000002295F4: BF800000
	s_nop 0                                                    // 0000002295F8: BF800000
	s_nop 0                                                    // 0000002295FC: BF800000
	.long 0xd73d0006                                           // 000000229600: D73D0006
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000229604: 02020881
	v_and_b32_e32 v0, 1, v4                                    // 000000229608: 36000881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022960C: BF870092
	.long 0xd7006a06                                           // 000000229610: D7006A06
	v_cndmask_b32_e32 v1, s1, v6, vcc_lo                       // 000000229614: 02020C01
	v_add_co_ci_u32_e64 v7, null, s2, v7, vcc_lo               // 000000229618: D5207C07 01AA0E02
	global_load_u8 v8, v[6:7], off                             // 000000229620: DC420000 087C0006
	.long 0xd73d0006                                           // 000000229628: D73D0006
	v_cndmask_b32_e32 v1, 4, v4, vcc_lo                        // 00000022962C: 02020884
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000229630: BF870091
	v_and_b32_e32 v6, -2, v6                                   // 000000229634: 360C0CC2
	.long 0xd7006a06                                           // 000000229638: D7006A06
	v_cndmask_b32_e32 v1, s3, v6, vcc_lo                       // 00000022963C: 02020C03
	s_delay_alu instid0(VALU_DEP_1)                            // 000000229640: BF870001
	v_add_co_ci_u32_e64 v7, null, s8, v7, vcc_lo               // 000000229644: D5207C07 01AA0E08
	v_cmp_eq_u64_e32 vcc_lo, 0, v[0:1]                         // 00000022964C: 7CB40080
	global_load_d16_b16 v6, v[6:7], off                        // 000000229650: DC820000 067C0006
	s_waitcnt vmcnt(1)                                         // 000000229658: BF8907F7
	v_lshrrev_b32_e32 v7, 4, v8                                // 00000022965C: 320E1084
	v_and_b32_e32 v8, 15, v8                                   // 000000229660: 3610108F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000229664: BF8700A1
	v_cndmask_b32_e32 v0, v7, v8, vcc_lo                       // 000000229668: 02001107
	.long 0xd7006a04                                           // 00000022966C: D7006A04
	v_cndmask_b32_e32 v0, v4, v9, vcc_lo                       // 000000229670: 02001304
	v_add_co_ci_u32_e64 v5, null, 0, v5, vcc_lo                // 000000229674: D5207C05 01AA0A80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022967C: BF870113
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000229680: 30000082
	v_cmp_le_i64_e32 vcc_lo, s[12:13], v[4:5]                  // 000000229684: 7CA6080C
	global_load_b32 v0, v0, s[4:5]                             // 000000229688: DC520000 00040000
	s_or_b32 s6, vcc_lo, s6                                    // 000000229690: 8C06066A
	s_waitcnt vmcnt(0)                                         // 000000229694: BF8903F7
	v_fma_mix_f32 v0, v6, v0, neg(0) op_sel_hi:[1,0,0]         // 000000229698: CC200000 8A020106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002296A0: BF870091
	v_bfe_u32 v6, v0, 16, 1                                    // 0000002296A4: D6100006 02052100
	v_add3_u32 v0, v0, v6, 0x7fff                              // 0000002296AC: D6550000 03FE0D00 00007FFF
	global_store_d16_hi_b16 v[2:3], v0, off                    // 0000002296B8: DC960000 007C0002
	.long 0xd7000002                                           // 0000002296C0: D7000002
	v_cndmask_b32_e32 v0, v2, v7, vcc_lo                       // 0000002296C4: 02000F02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002296C8: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, s0                    // 0000002296CC: D5207C03 00020680
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000002296D4: 917E067E
	s_cbranch_execnz 65481                                     // 0000002296D8: BFA6FFC9 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_selEPKhPtPKilllll+0x400>
	s_set_inst_prefetch_distance 0x2                           // 0000002296DC: BF840002
	s_endpgm                                                   // 0000002296E0: BFB00000
	s_branch 65365                                             // 0000002296E4: BFA0FF55 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_selEPKhPtPKilllll+0x23c>
		...

