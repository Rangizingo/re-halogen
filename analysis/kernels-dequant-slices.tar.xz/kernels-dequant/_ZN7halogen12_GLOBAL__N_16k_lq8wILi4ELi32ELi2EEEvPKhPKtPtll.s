00000000002e5800 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi2EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi2EEEvPKhPKtPtll():
	s_clause 0x1                                               // 0000002E5800: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 0000002E5804: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000002E580C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 0000002E5814: BE830080
	v_lshrrev_b32_e32 v13, 6, v0                               // 0000002E5818: 321A0086
	s_lshl_b64 s[2:3], s[2:3], 2                               // 0000002E581C: 84828202
	v_bfe_u32 v14, v0, 5, 1                                    // 0000002E5820: D610000E 02050B00
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 0000002E5828: CA240080 100E009F
	v_mov_b32_e32 v25, 0                                       // 0000002E5830: 7E320280
	v_or_b32_e32 v1, s2, v13                                   // 0000002E5834: 38021A02
	v_dual_mov_b32 v2, s3 :: v_dual_mov_b32 v3, 0              // 0000002E5838: CA100003 02020080
	s_waitcnt lgkmcnt(0)                                       // 0000002E5840: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 0000002E5844: 86009F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002E5848: BF8704A1
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000002E584C: 7CA8020C
	s_lshr_b32 s0, s0, 28                                      // 0000002E5850: 85009C00
	s_add_u32 s0, s10, s0                                      // 0000002E5854: 8000000A
	s_addc_u32 s1, s11, 0                                      // 0000002E5858: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002E585C: BF870009
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000002E5860: 86808400
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000002E5864: 02020280
	s_add_u32 s14, s0, s10                                     // 0000002E5868: 800E0A00
	s_addc_u32 s1, s1, s11                                     // 0000002E586C: 82010B01
	s_add_i32 s15, s0, 1                                       // 0000002E5870: 810F8100
	v_cndmask_b32_e64 v2, 0, s3, vcc_lo                        // 0000002E5874: D5010002 01A80680
	s_lshr_b32 s16, s15, 31                                    // 0000002E587C: 85109F0F
	v_mad_u64_u32 v[9:10], null, v1, s14, s[4:5]               // 0000002E5880: D6FE7C09 00101D01
	s_add_i32 s15, s15, s16                                    // 0000002E5888: 810F100F
	.long 0xd72c0006                                           // 0000002E588C: D72C0006
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 0000002E5890: 02000301
	s_ashr_i32 s15, s15, 1                                     // 0000002E5894: 860F810F
	.long 0xd72c0005                                           // 0000002E5898: D72C0005
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 0000002E589C: 02001D02
	.long 0xd72c0004                                           // 0000002E58A0: D72C0004
	v_cndmask_b32_e32 v1, s15, v14, vcc_lo                     // 0000002E58A4: 02021C0F
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000002E58A8: CA100080 01020080
	.long 0xd7006a13                                           // 0000002E58B0: D7006A13
	v_cndmask_b32_e32 v0, v9, v10, vcc_lo                      // 0000002E58B4: 02001509
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002E58B8: BF870214
	v_add3_u32 v10, v5, v10, v6                                // 0000002E58BC: D655000A 041A1505
	v_add_nc_u32_e32 v7, s15, v4                               // 0000002E58C4: 4A0E080F
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v17, v4, v15     // 0000002E58C8: CA200080 04101F04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E58D0: BF870193
	v_add_co_ci_u32_e64 v20, null, s11, v10, vcc_lo            // 0000002E58D4: D5207C14 01AA140B
	v_min_i32_e32 v18, s0, v7                                  // 0000002E58DC: 22240E00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E58E0: BF870113
	v_lshlrev_b32_e32 v11, 4, v17                              // 0000002E58E4: 30162284
	v_cmp_lt_i32_e32 vcc_lo, v17, v18                          // 0000002E58E8: 7C822511
	s_and_saveexec_b32 s1, vcc_lo                              // 0000002E58EC: BE81206A
	s_cbranch_execz 19                                         // 0000002E58F0: BFA50013 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi2EEEvPKhPKtPtll+0x140>
	v_lshlrev_b32_e32 v1, 4, v17                               // 0000002E58F4: 30022284
	v_and_b32_e32 v3, -4, v17                                  // 0000002E58F8: 360622C4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E58FC: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002E5900: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002E5904: 3408069F
	.long 0xd7000001                                           // 0000002E5908: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 0000002E590C: 02020309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E5910: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v10, v2, s0                  // 0000002E5914: D5207C02 0002050A
	.long 0xd7000005                                           // 0000002E591C: D7000005
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 0000002E5920: 02020713
	v_add_co_ci_u32_e64 v6, null, v20, v4, s0                  // 0000002E5924: D5207C06 00020914
	s_clause 0x1                                               // 0000002E592C: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 0000002E5930: DC5E0000 017C0001
	global_load_b32 v25, v[5:6], off                           // 0000002E5938: DC520000 197C0005
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002E5940: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000002E5944: CA100080 16160080
	v_mov_b32_e32 v21, 0                                       // 0000002E594C: 7E2A0280
	s_and_saveexec_b32 s1, vcc_lo                              // 0000002E5950: BE81206A
	s_cbranch_execz 343                                        // 0000002E5954: BFA50157 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi2EEEvPKhPKtPtll+0x6b4>
	v_dual_mov_b32 v21, 0 :: v_dual_add_nc_u32 v24, 0x200, v11 // 0000002E5958: CA200080 151816FF 00000200
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 0000002E5964: CA100080 17160080
	v_mov_b32_e32 v16, 0                                       // 0000002E596C: 7E200280
	s_waitcnt vmcnt(0)                                         // 0000002E5970: BF8903F7
	v_mov_b32_e32 v26, v25                                     // 0000002E5974: 7E340319
	s_mul_i32 s0, s11, 6                                       // 0000002E5978: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 0000002E597C: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000002E5980: 8484820A
	s_add_i32 s14, s14, s0                                     // 0000002E5984: 810E000E
	s_mul_i32 s16, s10, 6                                      // 0000002E5988: 9610860A
	s_mov_b32 s15, 0                                           // 0000002E598C: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000002E5990: 848A810A
	s_branch 296                                               // 0000002E5994: BFA00128 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi2EEEvPKhPKtPtll+0x638>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000002E5998: 8C7E117E
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000002E599C: 3418169F
	v_cvt_f32_ubyte1_e32 v60, v1                               // 0000002E59A0: 7E782501
	v_cvt_f32_ubyte2_e32 v61, v1                               // 0000002E59A4: 7E7A2701
	v_cvt_f32_ubyte0_e32 v62, v2                               // 0000002E59A8: 7E7C2302
	v_cvt_f32_ubyte1_e32 v63, v2                               // 0000002E59AC: 7E7E2502
	.long 0xd73c001b                                           // 0000002E59B0: D73C001B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002E59B4: 02021681
	v_cvt_f32_ubyte0_e32 v12, v1                               // 0000002E59B8: 7E182301
	v_cvt_f32_ubyte3_e32 v1, v1                                // 0000002E59BC: 7E022901
	v_cvt_f32_ubyte2_e32 v64, v2                               // 0000002E59C0: 7E802702
	v_cvt_f32_ubyte3_e32 v65, v2                               // 0000002E59C4: 7E822902
	v_cvt_f32_ubyte0_e32 v66, v3                               // 0000002E59C8: 7E842303
	.long 0xd700002b                                           // 0000002E59CC: D700002B
	v_cndmask_b32_e32 v1, s6, v27, vcc_lo                      // 0000002E59D0: 02023606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E59D4: BF8701A1
	v_add_co_ci_u32_e64 v44, null, s7, v28, s0                 // 0000002E59D8: D5207C2C 00023807
	v_cvt_f32_ubyte1_e32 v67, v3                               // 0000002E59E0: 7E862503
	.long 0xd700002f                                           // 0000002E59E4: D700002F
	v_cndmask_b32_e32 v0, v43, v10, vcc_lo                     // 0000002E59E8: 0200152B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E59EC: BF8700A1
	v_add_co_ci_u32_e64 v48, null, s11, v44, s0                // 0000002E59F0: D5207C30 0002580B
	.long 0xd7000033                                           // 0000002E59F8: D7000033
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 0000002E59FC: 0200092B
	v_add_co_ci_u32_e64 v52, null, s5, v44, s0                 // 0000002E5A00: D5207C34 00025805
	.long 0xd7000037                                           // 0000002E5A08: D7000037
	v_cndmask_b32_e32 v0, v43, v16, vcc_lo                     // 0000002E5A0C: 0200212B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002E5A10: BF870001
	v_add_co_ci_u32_e64 v56, null, s14, v44, s0                // 0000002E5A14: D5207C38 0002580E
	s_clause 0x7                                               // 0000002E5A1C: BF850007
	global_load_b128 v[27:30], v[43:44], off                   // 0000002E5A20: DC5E0000 1B7C002B
	global_load_b128 v[31:34], v[47:48], off                   // 0000002E5A28: DC5E0000 1F7C002F
	global_load_b128 v[35:38], v[51:52], off                   // 0000002E5A30: DC5E0000 237C0033
	global_load_b128 v[39:42], v[55:56], off                   // 0000002E5A38: DC5E0000 277C0037
	global_load_b128 v[43:46], v[43:44], off offset:16         // 0000002E5A40: DC5E0010 2B7C002B
	global_load_b128 v[47:50], v[47:48], off offset:16         // 0000002E5A48: DC5E0010 2F7C002F
	global_load_b128 v[51:54], v[51:52], off offset:16         // 0000002E5A50: DC5E0010 337C0033
	global_load_b128 v[55:58], v[55:56], off offset:16         // 0000002E5A58: DC5E0010 377C0037
	v_cvt_f32_ubyte2_e32 v68, v3                               // 0000002E5A60: 7E882703
	v_cvt_f32_ubyte3_e32 v69, v3                               // 0000002E5A64: 7E8A2903
	v_cvt_f32_ubyte0_e32 v70, v4                               // 0000002E5A68: 7E8C2304
	v_cvt_f32_ubyte1_e32 v71, v4                               // 0000002E5A6C: 7E8E2504
	v_cvt_f32_ubyte2_e32 v72, v4                               // 0000002E5A70: 7E902704
	v_cvt_f32_ubyte3_e32 v73, v4                               // 0000002E5A74: 7E922904
	s_waitcnt vmcnt(9)                                         // 0000002E5A78: BF8927F7
	v_dual_mov_b32 v2, v6 :: v_dual_add_nc_u32 v11, 0x200, v11 // 0000002E5A7C: CA200106 020A16FF 00000200
	v_fma_mix_f32 v6, v12, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E5A88: CC206006 1466330C
	v_dual_mov_b32 v3, v7 :: v_dual_add_nc_u32 v24, 0x200, v24 // 0000002E5A90: CA200107 031830FF 00000200
	v_mov_b32_e32 v4, v8                                       // 0000002E5A9C: 7E080308
	v_fma_mix_f32 v7, v60, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E5AA0: CC206007 1466333C
	v_fma_mix_f32 v8, v61, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E5AA8: CC206008 1466333D
	v_fma_mix_f32 v1, v1, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E5AB0: CC206001 14663301
	v_fma_mix_f32 v60, v62, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E5AB8: CC20603C 1466333E
	v_fma_mix_f32 v61, v63, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E5AC0: CC20603D 1466333F
	v_fma_mix_f32 v62, v64, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E5AC8: CC20603E 14663340
	v_fma_mix_f32 v64, v65, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E5AD0: CC206040 14663341
	v_fma_mix_f32 v65, v66, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E5AD8: CC206041 14663342
	v_fma_mix_f32 v66, v67, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E5AE0: CC206042 14663343
	v_fma_mix_f32 v67, v68, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E5AE8: CC206043 14663344
	v_fma_mix_f32 v69, v69, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E5AF0: CC206045 14663345
	v_fma_mix_f32 v70, v70, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E5AF8: CC206046 14663346
	v_fma_mix_f32 v71, v71, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E5B00: CC206047 14663347
	v_fma_mix_f32 v72, v72, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E5B08: CC206048 14663348
	v_fma_mix_f32 v25, v73, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E5B10: CC206019 14663349
	v_bfe_u32 v73, v6, 16, 1                                   // 0000002E5B18: D6100049 02052106
	v_bfe_u32 v75, v7, 16, 1                                   // 0000002E5B20: D610004B 02052107
	v_bfe_u32 v76, v8, 16, 1                                   // 0000002E5B28: D610004C 02052108
	.long 0x7f763880                                           // 0000002E5B30: 7F763880
	v_bfe_u32 v77, v1, 16, 1                                   // 0000002E5B34: D610004D 02052101
	v_add3_u32 v6, v6, v73, 0x7fff                             // 0000002E5B3C: D6550006 03FE9306 00007FFF
	v_bfe_u32 v78, v60, 16, 1                                  // 0000002E5B48: D610004E 0205213C
	v_add3_u32 v7, v7, v75, 0x7fff                             // 0000002E5B50: D6550007 03FE9707 00007FFF
	v_add3_u32 v8, v8, v76, 0x7fff                             // 0000002E5B5C: D6550008 03FE9908 00007FFF
	.long 0x7f1839bb                                           // 0000002E5B68: 7F1839BB
	.long 0x7e763986                                           // 0000002E5B6C: 7E763986
	v_bfe_u32 v79, v61, 16, 1                                  // 0000002E5B70: D610004F 0205213D
	v_bfe_u32 v80, v62, 16, 1                                  // 0000002E5B78: D6100050 0205213E
	v_add3_u32 v1, v1, v77, 0x7fff                             // 0000002E5B80: D6550001 03FE9B01 00007FFF
	v_add3_u32 v60, v60, v78, 0x7fff                           // 0000002E5B8C: D655003C 03FE9D3C 00007FFF
	.long 0x7e183988                                           // 0000002E5B98: 7E183988
	v_and_or_b32 v6, 0xffff0000, v7, v59                       // 0000002E5B9C: D6570006 04EE0EFF FFFF0000
	v_bfe_u32 v81, v64, 16, 1                                  // 0000002E5BA8: D6100051 02052140
	v_bfe_u32 v82, v65, 16, 1                                  // 0000002E5BB0: D6100052 02052141
	v_add3_u32 v61, v61, v79, 0x7fff                           // 0000002E5BB8: D655003D 03FE9F3D 00007FFF
	v_add3_u32 v62, v62, v80, 0x7fff                           // 0000002E5BC4: D655003E 03FEA13E 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v12                       // 0000002E5BD0: D6570001 043202FF FFFF0000
	.long 0x7e7639bc                                           // 0000002E5BDC: 7E7639BC
	.long 0x7f7e39bb                                           // 0000002E5BE0: 7F7E39BB
	v_bfe_u32 v83, v66, 16, 1                                  // 0000002E5BE4: D6100053 02052142
	v_bfe_u32 v84, v67, 16, 1                                  // 0000002E5BEC: D6100054 02052143
	v_add3_u32 v64, v64, v81, 0x7fff                           // 0000002E5BF4: D6550040 03FEA340 00007FFF
	v_add3_u32 v65, v65, v82, 0x7fff                           // 0000002E5C00: D6550041 03FEA541 00007FFF
	.long 0x7e7e39be                                           // 0000002E5C0C: 7E7E39BE
	v_bfe_u32 v85, v69, 16, 1                                  // 0000002E5C10: D6100055 02052145
	v_bfe_u32 v86, v70, 16, 1                                  // 0000002E5C18: D6100056 02052146
	v_add3_u32 v66, v66, v83, 0x7fff                           // 0000002E5C20: D6550042 03FEA742 00007FFF
	v_add3_u32 v67, v67, v84, 0x7fff                           // 0000002E5C2C: D6550043 03FEA943 00007FFF
	v_and_or_b32 v7, 0xffff0000, v64, v63                      // 0000002E5C38: D6570007 04FE80FF FFFF0000
	.long 0x7f8839bb                                           // 0000002E5C44: 7F8839BB
	v_bfe_u32 v87, v71, 16, 1                                  // 0000002E5C48: D6100057 02052147
	v_bfe_u32 v88, v72, 16, 1                                  // 0000002E5C50: D6100058 02052148
	v_add3_u32 v69, v69, v85, 0x7fff                           // 0000002E5C58: D6550045 03FEAB45 00007FFF
	v_add3_u32 v70, v70, v86, 0x7fff                           // 0000002E5C64: D6550046 03FEAD46 00007FFF
	.long 0x7e8839c3                                           // 0000002E5C70: 7E8839C3
	v_bfe_u32 v89, v25, 16, 1                                  // 0000002E5C74: D6100059 02052119
	v_add3_u32 v71, v71, v87, 0x7fff                           // 0000002E5C7C: D6550047 03FEAF47 00007FFF
	v_add3_u32 v72, v72, v88, 0x7fff                           // 0000002E5C88: D6550048 03FEB148 00007FFF
	.long 0x7f9439bb                                           // 0000002E5C94: 7F9439BB
	v_and_or_b32 v8, 0xffff0000, v69, v68                      // 0000002E5C98: D6570008 05128AFF FFFF0000
	v_add3_u32 v25, v25, v89, 0x7fff                           // 0000002E5CA4: D6550019 03FEB319 00007FFF
	s_and_b32 s0, exec_lo, vcc_lo                              // 0000002E5CB0: 8B006A7E
	.long 0x7e9439c8                                           // 0000002E5CB4: 7E9439C8
	s_or_b32 s15, s0, s15                                      // 0000002E5CB8: 8C0F0F00
	s_waitcnt vmcnt(7)                                         // 0000002E5CBC: BF891FF7
	v_dot2_f32_bf16 v12, v27, v6, 0                            // 0000002E5CC0: CC1A400C 1A020D1B
	s_waitcnt vmcnt(6)                                         // 0000002E5CC8: BF891BF7
	v_dot2_f32_bf16 v27, v31, v6, 0                            // 0000002E5CCC: CC1A401B 1A020D1F
	s_waitcnt vmcnt(5)                                         // 0000002E5CD4: BF8917F7
	v_dot2_f32_bf16 v31, v35, v6, 0                            // 0000002E5CD8: CC1A401F 1A020D23
	s_waitcnt vmcnt(4)                                         // 0000002E5CE0: BF8913F7
	v_dot2_f32_bf16 v6, v39, v6, 0                             // 0000002E5CE4: CC1A4006 1A020D27
	v_and_or_b32 v35, 0xffff0000, v61, v59                     // 0000002E5CEC: D6570023 04EE7AFF FFFF0000
	v_dot2_f32_bf16 v12, v28, v1, v12                          // 0000002E5CF8: CC1A400C 1C32031C
	v_dot2_f32_bf16 v27, v32, v1, v27                          // 0000002E5D00: CC1A401B 1C6E0320
	v_dot2_f32_bf16 v28, v36, v1, v31                          // 0000002E5D08: CC1A401C 1C7E0324
	v_dot2_f32_bf16 v1, v40, v1, v6                            // 0000002E5D10: CC1A4001 1C1A0328
	.long 0x7e7639c1                                           // 0000002E5D18: 7E7639C1
	v_dot2_f32_bf16 v6, v29, v35, v12                          // 0000002E5D1C: CC1A4006 1C32471D
	v_dot2_f32_bf16 v12, v33, v35, v27                         // 0000002E5D24: CC1A400C 1C6E4721
	v_dot2_f32_bf16 v27, v37, v35, v28                         // 0000002E5D2C: CC1A401B 1C724725
	v_dot2_f32_bf16 v1, v41, v35, v1                           // 0000002E5D34: CC1A4001 1C064729
	v_and_or_b32 v28, 0xffff0000, v66, v59                     // 0000002E5D3C: D657001C 04EE84FF FFFF0000
	v_dot2_f32_bf16 v6, v30, v7, v6                            // 0000002E5D48: CC1A4006 1C1A0F1E
	v_dot2_f32_bf16 v12, v34, v7, v12                          // 0000002E5D50: CC1A400C 1C320F22
	v_dot2_f32_bf16 v27, v38, v7, v27                          // 0000002E5D58: CC1A401B 1C6E0F26
	v_dot2_f32_bf16 v1, v42, v7, v1                            // 0000002E5D60: CC1A4001 1C060F2A
	.long 0x7e7639c6                                           // 0000002E5D68: 7E7639C6
	s_waitcnt vmcnt(3)                                         // 0000002E5D6C: BF890FF7
	v_dot2_f32_bf16 v6, v43, v28, v6                           // 0000002E5D70: CC1A4006 1C1A392B
	s_waitcnt vmcnt(2)                                         // 0000002E5D78: BF890BF7
	v_dot2_f32_bf16 v7, v47, v28, v12                          // 0000002E5D7C: CC1A4007 1C32392F
	s_waitcnt vmcnt(1)                                         // 0000002E5D84: BF8907F7
	v_dot2_f32_bf16 v12, v51, v28, v27                         // 0000002E5D88: CC1A400C 1C6E3933
	s_waitcnt vmcnt(0)                                         // 0000002E5D90: BF8903F7
	v_dot2_f32_bf16 v1, v55, v28, v1                           // 0000002E5D94: CC1A4001 1C063937
	v_and_or_b32 v27, 0xffff0000, v71, v59                     // 0000002E5D9C: D657001B 04EE8EFF FFFF0000
	v_dot2_f32_bf16 v6, v44, v8, v6                            // 0000002E5DA8: CC1A4006 1C1A112C
	v_dot2_f32_bf16 v7, v48, v8, v7                            // 0000002E5DB0: CC1A4007 1C1E1130
	v_dot2_f32_bf16 v12, v52, v8, v12                          // 0000002E5DB8: CC1A400C 1C321134
	v_dot2_f32_bf16 v1, v56, v8, v1                            // 0000002E5DC0: CC1A4001 1C061138
	v_and_or_b32 v8, 0xffff0000, v25, v74                      // 0000002E5DC8: D6570008 052A32FF FFFF0000
	v_dot2_f32_bf16 v6, v45, v27, v6                           // 0000002E5DD4: CC1A4006 1C1A372D
	v_dot2_f32_bf16 v7, v49, v27, v7                           // 0000002E5DDC: CC1A4007 1C1E3731
	v_dot2_f32_bf16 v12, v53, v27, v12                         // 0000002E5DE4: CC1A400C 1C323735
	v_dot2_f32_bf16 v25, v57, v27, v1                          // 0000002E5DEC: CC1A4019 1C063739
	v_mov_b32_e32 v1, v5                                       // 0000002E5DF4: 7E020305
	v_dot2_f32_bf16 v5, v46, v8, v6                            // 0000002E5DF8: CC1A4005 1C1A112E
	v_dot2_f32_bf16 v6, v50, v8, v7                            // 0000002E5E00: CC1A4006 1C1E1132
	v_dot2_f32_bf16 v7, v54, v8, v12                           // 0000002E5E08: CC1A4007 1C321136
	v_dot2_f32_bf16 v8, v58, v8, v25                           // 0000002E5E10: CC1A4008 1C66113A
	v_mov_b32_e32 v25, v26                                     // 0000002E5E18: 7E32031A
	v_add_f32_e32 v21, v21, v5                                 // 0000002E5E1C: 062A0B15
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002E5E20: BF870214
	v_dual_add_f32 v23, v23, v6 :: v_dual_add_f32 v22, v22, v7 // 0000002E5E24: C9080D17 17160F16
	v_add_f32_e32 v16, v16, v8                                 // 0000002E5E2C: 06201110
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000002E5E30: 917E0F7E
	s_cbranch_execz 30                                         // 0000002E5E34: BFA5001E <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi2EEEvPKhPKtPtll+0x6b0>
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v17, 32, v17    // 0000002E5E38: CA200102 061022A0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000002E5E40: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000002E5E48: 7E0E0303
	s_mov_b32 s17, exec_lo                                     // 0000002E5E4C: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002E5E50: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v17, v18                          // 0000002E5E54: 7C8C2511
	.long 0xd4c1007e                                           // 0000002E5E58: D4C1007E
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000002E5E5C: 02022511
	s_cbranch_execz 65229                                      // 0000002E5E60: BFA5FECD <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi2EEEvPKhPKtPtll+0x198>
	v_and_b32_e32 v7, -4, v17                                  // 0000002E5E64: 360E22C4
	v_ashrrev_i32_e32 v6, 31, v24                              // 0000002E5E68: 340C309F
	.long 0xd7000005                                           // 0000002E5E6C: D7000005
	v_cndmask_b32_e32 v1, v9, v24, vcc_lo                      // 0000002E5E70: 02023109
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E5E74: BF870193
	v_ashrrev_i32_e32 v8, 31, v7                               // 0000002E5E78: 34100E9F
	v_add_co_ci_u32_e64 v6, null, v10, v6, s0                  // 0000002E5E7C: D5207C06 00020D0A
	.long 0xd700001a                                           // 0000002E5E84: D700001A
	v_cndmask_b32_e32 v1, v19, v7, vcc_lo                      // 0000002E5E88: 02020F13
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002E5E8C: BF870001
	v_add_co_ci_u32_e64 v27, null, v20, v8, s0                 // 0000002E5E90: D5207C1B 00021114
	s_clause 0x1                                               // 0000002E5E98: BF850001
	global_load_b128 v[5:8], v[5:6], off                       // 0000002E5E9C: DC5E0000 057C0005
	global_load_b32 v26, v[26:27], off                         // 0000002E5EA4: DC520000 1A7C001A
	s_branch 65210                                             // 0000002E5EAC: BFA0FEBA <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi2EEEvPKhPKtPtll+0x198>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000002E5EB0: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002E5EB4: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002E5EB8: 8C7E017E
	s_waitcnt vmcnt(1)                                         // 0000002E5EBC: BF8907F7
	.long 0xd71f0001                                           // 0000002E5EC0: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002E5EC4: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000002E5EC8: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000002E5ECC: 3A040290
	v_xor_b32_e32 v6, 8, v1                                    // 0000002E5ED0: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 0000002E5ED4: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002E5ED8: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000002E5EDC: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000002E5EE0: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000002E5EE4: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002E5EE8: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000002E5EEC: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 0000002E5EF0: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 0000002E5EF8: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 0000002E5EFC: 06060715
	ds_bpermute_b32 v5, v2, v22                                // 0000002E5F00: DACC0000 05001602
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 0000002E5F08: 020C0D01
	ds_bpermute_b32 v4, v2, v23                                // 0000002E5F0C: DACC0000 04001702
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000002E5F14: 7C9814A0
	ds_bpermute_b32 v2, v2, v16                                // 0000002E5F18: DACC0000 02001002
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000002E5F20: 02141501
	s_waitcnt lgkmcnt(2)                                       // 0000002E5F24: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002E5F28: BF870001
	v_dual_add_f32 v5, v22, v5 :: v_dual_lshlrev_b32 v10, 2, v10// 0000002E5F2C: C9220B16 050A1482
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000002E5F34: 300C0C82
	s_waitcnt lgkmcnt(1)                                       // 0000002E5F38: BF89FC17
	v_add_f32_e32 v4, v23, v4                                  // 0000002E5F3C: 06080917
	ds_bpermute_b32 v9, v6, v5                                 // 0000002E5F40: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 0000002E5F48: BF89FC07
	v_add_f32_e32 v5, v5, v9                                   // 0000002E5F4C: 060A1305
	ds_bpermute_b32 v7, v6, v3                                 // 0000002E5F50: DACC0000 07000306
	ds_bpermute_b32 v8, v6, v4                                 // 0000002E5F58: DACC0000 08000406
	s_waitcnt lgkmcnt(0)                                       // 0000002E5F60: BF89FC07
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v4, v8     // 0000002E5F64: C9080F03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 0000002E5F6C: DACC0000 0800050A
	s_waitcnt lgkmcnt(0)                                       // 0000002E5F74: BF89FC07
	v_dual_add_f32 v2, v16, v2 :: v_dual_add_f32 v5, v5, v8    // 0000002E5F78: C9080510 02041105
	ds_bpermute_b32 v6, v6, v2                                 // 0000002E5F80: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 0000002E5F88: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 0000002E5F8C: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 0000002E5F90: DACC0000 0600030A
	ds_bpermute_b32 v9, v10, v2                                // 0000002E5F98: DACC0000 0900020A
	s_waitcnt lgkmcnt(1)                                       // 0000002E5FA0: BF89FC17
	v_add_f32_e32 v3, v3, v6                                   // 0000002E5FA4: 06060D03
	ds_bpermute_b32 v7, v10, v4                                // 0000002E5FA8: DACC0000 0700040A
	v_xor_b32_e32 v10, 2, v1                                   // 0000002E5FB0: 3A140282
	s_waitcnt lgkmcnt(1)                                       // 0000002E5FB4: BF89FC17
	v_add_f32_e32 v6, v2, v9                                   // 0000002E5FB8: 060C1302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E5FBC: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000002E5FC0: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000002E5FC4: 02141501
	v_lshlrev_b32_e32 v10, 2, v10                              // 0000002E5FC8: 30141482
	ds_bpermute_b32 v2, v10, v3                                // 0000002E5FCC: DACC0000 0200030A
	s_waitcnt lgkmcnt(1)                                       // 0000002E5FD4: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 0000002E5FD8: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 0000002E5FDC: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 0000002E5FE4: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 0000002E5FEC: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 0000002E5FF4: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002E5FF8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000002E5FFC: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 0000002E6000: 02021501
	s_waitcnt lgkmcnt(3)                                       // 0000002E6004: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 0000002E6008: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 0000002E6010: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 0000002E6014: 06061105
	s_waitcnt lgkmcnt(0)                                       // 0000002E6018: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 0000002E601C: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 0000002E6024: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 0000002E602C: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 0000002E6034: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 0000002E603C: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v15                                   // 0000002E6044: 7D941E80
	s_cbranch_execz 12                                         // 0000002E6048: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi2EEEvPKhPKtPtll+0x87c>
	s_waitcnt lgkmcnt(1)                                       // 0000002E604C: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_lshlrev_b32 v9, 4, v14 // 0000002E6050: C9221105 08081C84
	s_waitcnt lgkmcnt(0)                                       // 0000002E6058: BF89FC07
	v_dual_add_f32 v7, v3, v7 :: v_dual_add_f32 v6, v2, v6     // 0000002E605C: C9080F03 07060D02
	v_add_f32_e32 v5, v1, v4                                   // 0000002E6064: 060A0901
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002E6068: BF870003
	v_lshl_or_b32 v1, v13, 5, v9                               // 0000002E606C: D6560001 04250B0D
	ds_store_b128 v1, v[5:8]                                   // 0000002E6074: DB7C0000 00000501
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002E607C: 8C7E007E
	v_lshrrev_b32_e32 v3, 2, v0                                // 0000002E6080: 32060082
	v_mov_b32_e32 v2, s3                                       // 0000002E6084: 7E040203
	.long 0xd44c0000                                           // 0000002E6088: D44C0000
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 0000002E608C: 02020090
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000002E6090: BF890007
	s_barrier                                                  // 0000002E6094: BFBD0000
	v_or_b32_e32 v1, s2, v3                                    // 0000002E6098: 38020602
	buffer_gl0_inv                                             // 0000002E609C: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000002E60A4: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 0000002E60A8: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002E60AC: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000002E60B0: BE812000
	s_cbranch_execz 37                                         // 0000002E60B4: BFA50025 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi2EEEvPKhPKtPtll+0x94c>
	v_and_b32_e32 v0, 3, v0                                    // 0000002E60B8: 36000083
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E60BC: BF870091
	v_lshlrev_b32_e32 v4, 2, v0                                // 0000002E60C0: 30080082
	v_lshl_or_b32 v3, v3, 5, v4                                // 0000002E60C4: D6560003 04110B03
	ds_load_2addr_b32 v[6:7], v3 offset1:4                     // 0000002E60CC: D8DC0400 06000003
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 0000002E60D4: D6FE7C03 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E60DC: BF870091
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 0000002E60E0: D6FE7C04 0412000D
	.long 0xd73c0003                                           // 0000002E60E8: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000002E60EC: 02020681
	s_waitcnt lgkmcnt(0)                                       // 0000002E60F0: BF89FC07
	v_add_f32_e32 v0, 0, v6                                    // 0000002E60F4: 06000C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E60F8: BF870112
	.long 0xd7006a03                                           // 0000002E60FC: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 0000002E6100: 02020608
	v_add_f32_e32 v5, v0, v7                                   // 0000002E6104: 060A0F00
	.long 0xd73c0000                                           // 0000002E6108: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002E610C: 02020281
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000002E6110: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E6118: BF870193
	v_bfe_u32 v2, v5, 16, 1                                    // 0000002E611C: D6100002 02052105
	.long 0xd7006a00                                           // 0000002E6124: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 0000002E6128: 02020103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E612C: BF870191
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000002E6130: D5207C01 01AA0304
	v_add3_u32 v2, v5, v2, 0x7fff                              // 0000002E6138: D6550002 03FE0505 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002E6144: DC960000 007C0200
	s_endpgm                                                   // 0000002E614C: BFB00000
		...

