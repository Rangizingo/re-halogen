0000000000528a00 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x3                                               // 000000528A00: BF850003
	s_load_b256 s[12:19], s[0:1], null                         // 000000528A04: F40C0300 F8000000
	s_load_b256 s[20:27], s[0:1], 0x20                         // 000000528A0C: F40C0500 F8000020
	s_load_b128 s[28:31], s[0:1], 0x40                         // 000000528A14: F4080700 F8000040
	s_load_b32 s33, s[0:1], 0x54                               // 000000528A1C: F4000840 F8000054
	v_and_b32_e32 v13, 31, v0                                  // 000000528A24: 361A009F
	v_lshrrev_b32_e32 v11, 5, v0                               // 000000528A28: 32160085
	s_mov_b32 s4, s3                                           // 000000528A2C: BE840003
	s_delay_alu instid0(VALU_DEP_2)                            // 000000528A30: BF870002
	v_lshlrev_b32_e32 v12, 2, v13                              // 000000528A34: 30181A82
	s_waitcnt lgkmcnt(0)                                       // 000000528A38: BF89FC07
	s_ashr_i32 s34, s17, 31                                    // 000000528A3C: 86229F11
	s_mul_i32 s35, s19, s3                                     // 000000528A40: 96230313
	s_lshr_b32 s0, s34, 25                                     // 000000528A44: 85009922
	s_add_i32 s1, s35, s19                                     // 000000528A48: 81011323
	s_add_i32 s0, s17, s0                                      // 000000528A4C: 81000011
	s_mov_b32 s19, exec_lo                                     // 000000528A50: BE93007E
	s_ashr_i32 s0, s0, 7                                       // 000000528A54: 86008700
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000528A58: BF870499
	s_min_i32 s0, s0, s1                                       // 000000528A5C: 89000100
	s_sub_i32 s11, s0, s35                                     // 000000528A60: 818B2300
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000528A64: BF870499
	s_lshl_b32 s10, s11, 1                                     // 000000528A68: 840A810B
	.long 0xd4c4007e                                           // 000000528A6C: D4C4007E
	v_cndmask_b32_e32 v1, s10, v11, vcc_lo                     // 000000528A70: 0202160A
	s_cbranch_execz 506                                        // 000000528A74: BFA501FA <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x860>
	s_add_i32 s36, s16, -1                                     // 000000528A78: 8124C110
	s_cmp_lg_u64 s[30:31], 0                                   // 000000528A7C: BF11801E
	v_and_b32_e32 v2, 2, v0                                    // 000000528A80: 36040082
	s_cselect_b32 s37, -1, 0                                   // 000000528A84: 982580C1
	s_abs_i32 s38, s11                                         // 000000528A88: BEA6150B
	v_lshlrev_b32_e32 v6, 3, v13                               // 000000528A8C: 300C1A83
	s_cvt_f32_u32 s0, s38                                      // 000000528A90: BE806526
	v_dual_mov_b32 v8, v11 :: v_dual_and_b32 v1, 1, v0         // 000000528A94: CA24010B 08000081
	v_and_b32_e32 v4, 4, v0                                    // 000000528A9C: 36080084
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000528AA0: BF870009
	v_rcp_iflag_f32_e32 v3, s0                                 // 000000528AA4: 7E065600
	v_and_b32_e32 v5, 8, v0                                    // 000000528AA8: 360A0088
	v_add_nc_u32_e32 v7, s35, v11                              // 000000528AAC: 4A0E1623
	.long 0xd44a0003                                           // 000000528AB0: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000528AB4: 02020480
	v_lshl_or_b32 v2, v11, 8, v6                               // 000000528AB8: D6560002 0419110B
	s_ashr_i32 s42, s11, 31                                    // 000000528AC0: 862A9F0B
	s_sub_i32 s9, 0, s38                                       // 000000528AC4: 81892680
	s_mul_i32 s44, s42, 0x1400                                 // 000000528AC8: 962CFF2A 00001400
	.long 0xd44c0000                                           // 000000528AD0: D44C0000
	v_cndmask_b32_e32 v1, 16, v13, vcc_lo                      // 000000528AD4: 02021A90
	.long 0xd44a0001                                           // 000000528AD8: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000528ADC: 02020280
	v_readfirstlane_b32 s5, v3                                 // 000000528AE0: 7E0A0503
	.long 0xd44a0006                                           // 000000528AE4: D44A0006
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000528AE8: 02020A80
	v_lshl_or_b32 v1, v7, 7, v12                               // 000000528AEC: D6560001 04310F07
	v_subrev_nc_u32_e32 v9, s44, v2                            // 000000528AF4: 4E12042C
	s_lshl_b32 s7, s11, 7                                      // 000000528AF8: 8407870B
	s_mul_f32 s8, s5, 0x4f7ffffe                               // 000000528AFC: A208FF05 4F7FFFFE
	.long 0xd44a0005                                           // 000000528B04: D44A0005
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000528B08: 02020880
	s_mov_b32 s39, s17                                         // 000000528B0C: BEA70011
	s_mov_b32 s40, 0                                           // 000000528B10: BEA80080
	s_cvt_u32_f32 s8, s8                                       // 000000528B14: BE886708
	s_mov_b32 s41, 0x76543210                                  // 000000528B18: BEA900FF 76543210
	s_lshl_b32 s43, s11, 8                                     // 000000528B20: 842B880B
	s_sub_i32 s44, 0, s7                                       // 000000528B24: 81AC0780
	s_mul_i32 s9, s9, s8                                       // 000000528B28: 96090809
	s_mov_b32 s46, 0x3db504f3                                  // 000000528B2C: BEAE00FF 3DB504F3
	s_mul_hi_u32 s9, s8, s9                                    // 000000528B34: 96890908
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000528B38: BF870009
	s_add_i32 s45, s8, s9                                      // 000000528B3C: 812D0908
	s_branch 168                                               // 000000528B40: BFA000A8 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3e4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000528B44: BF870091
	.long 0xd7006a02                                           // 000000528B48: D7006A02
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000528B4C: 02020414
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo              // 000000528B50: D5207C03 01AA0615
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000528B58: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000528B60: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000528B68: BF8903F7
	v_fma_mix_f32 v5, v17, v2, v15 op_sel_hi:[0,1,0]           // 000000528B6C: CC200005 143E0511
	v_sub_f32_e32 v4, v18, v16                                 // 000000528B74: 08082112
	v_fma_mix_f32 v2, -v17, v2, v15 op_sel_hi:[0,1,0]          // 000000528B78: CC200002 343E0511
	v_add_f32_e32 v3, v18, v16                                 // 000000528B80: 06062112
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000528B84: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000528B88: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000528B8C: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000528B90: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000528B94: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000528B98: BF870193
	v_mov_b32_dpp v16, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000528B9C: 7E2002FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000528BA4: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000528BAC: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000528BB4: D5010002 20060502
	v_mov_b32_dpp v15, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000528BBC: 7E1E02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000528BC4: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000528BCC: BF870144
	v_add_f32_e32 v4, v6, v4                                   // 000000528BD0: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000528BD4: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000528BDC: D5010007 20060F07
	.long 0xd72c0006                                           // 000000528BE4: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v14, vcc_lo                  // 000000528BE8: 02021CFF 00001400
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v5, v7, v5    // 000000528BF0: C9082102 02040B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000528BF8: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000528C00: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000528C08: BF8701C3
	v_mov_b32_dpp v16, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000528C0C: 7E2002FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000528C14: D5010002 200E0502
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000528C1C: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000528C24: D5010005 200E0B05
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 000000528C2C: C9081F03 03022102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000528C34: BF870112
	v_add_f32_e32 v5, v5, v14                                  // 000000528C38: 060A1D05
	v_mov_b32_dpp v15, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000528C3C: 7E1E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000528C44: D5010003 200E0703
	s_delay_alu instid0(VALU_DEP_4)                            // 000000528C4C: BF870004
	v_mov_b32_dpp v16, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000528C50: 7E2002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000528C58: D5010002 20160502
	v_mov_b32_dpp v14, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000528C60: 7E1C02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000528C68: D5010005 20160B05
	v_add_f32_e32 v4, v4, v7                                   // 000000528C70: 06080F04
	.long 0xd72c0007                                           // 000000528C74: D72C0007
	v_cndmask_b32_e32 v1, s43, v10, vcc_lo                     // 000000528C78: 0202142B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000528C7C: BF870193
	v_add_f32_e32 v5, v5, v14                                  // 000000528C80: 060A1D05
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000528C84: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000528C8C: D5010004 20160904
	v_add_f32_e32 v3, v3, v15                                  // 000000528C94: 06061F03
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000528C98: BF870224
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000528C9C: 7E1C02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 000000528CA4: D5010005 201A0B05
	v_add_f32_e32 v4, v4, v10                                  // 000000528CAC: 06081504
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000528CB0: BF870254
	v_mov_b32_dpp v15, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000528CB4: 7E1E02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000528CBC: D5010003 20160703
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000528CC4: 4A101088
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v5, v5, v14   // 000000528CC8: C9082102 02041D05
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000528CD0: 7E1402FA FF016804
	v_add_f32_e32 v3, v3, v15                                  // 000000528CD8: 06061F03
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 000000528CDC: D5010004 201A0904
	s_delay_alu instid0(VALU_DEP_4)                            // 000000528CE4: BF870004
	v_mov_b32_dpp v16, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000528CE8: 7E2002FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 000000528CF0: D5010002 201A0502
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000528CF8: 4C0C0F06
	v_mov_b32_dpp v15, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000528CFC: 7E1E02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000528D04: D5010003 201A0703
	v_add_f32_e32 v4, v4, v10                                  // 000000528D0C: 06081504
	v_cmp_le_i32_e32 vcc_lo, s10, v8                           // 000000528D10: 7C86100A
	v_add_nc_u32_e32 v6, v9, v6                                // 000000528D14: 4A0C0D09
	v_add_nc_u32_e32 v9, 0x800, v9                             // 000000528D18: 4A1212FF 00000800
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 000000528D20: C9081F03 03022102
	s_or_b32 s40, vcc_lo, s40                                  // 000000528D28: 8C28286A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000528D2C: BF8701B1
	v_dual_mov_b32 v15, v3 :: v_dual_mov_b32 v16, v2           // 000000528D30: CA100103 0F100102
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000528D38: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000528D40: D5010003 20020703
	v_permlanex16_b32 v15, v15, s41, 0xfedcba98                // 000000528D48: D65C000F 03FC530F FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000528D54: BF8701B4
	v_permlanex16_b32 v16, v16, s41, 0xfedcba98                // 000000528D58: D65C0010 03FC5310 FEDCBA98
	v_mov_b32_e32 v14, v5                                      // 000000528D64: 7E1C0305
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000528D68: D5010005 20020B05
	v_add_f32_e32 v7, v2, v16                                  // 000000528D70: 060E2102
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000528D74: BF8701B3
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 000000528D78: D65C000E 03FC530E FEDCBA98
	v_mov_b32_e32 v10, v4                                      // 000000528D84: 7E140304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000528D88: D5010004 20020904
	v_add_f32_e32 v5, v5, v14                                  // 000000528D90: 060A1D05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000528D94: BF870113
	v_permlanex16_b32 v10, v10, s41, 0xfedcba98                // 000000528D98: D65C000A 03FC530A FEDCBA98
	v_fma_mixhi_f16 v2, v5, s46, 0                             // 000000528DA4: CC220002 02005D05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000528DAC: BF8701B2
	v_add_f32_e32 v4, v4, v10                                  // 000000528DB0: 06081504
	v_add_f32_e32 v10, v3, v15                                 // 000000528DB4: 06141F03
	v_fma_mixhi_f16 v3, v7, s46, 0                             // 000000528DB8: CC220003 02005D07
	v_fma_mixlo_f16 v2, v4, s46, 0                             // 000000528DC0: CC210002 02005D04
	s_delay_alu instid0(VALU_DEP_3)                            // 000000528DC8: BF870003
	v_fma_mixlo_f16 v3, v10, s46, 0                            // 000000528DCC: CC210003 02005D0A
	ds_store_b64 v6, v[2:3]                                    // 000000528DD4: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 000000528DDC: 917E287E
	s_cbranch_execz 287                                        // 000000528DE0: BFA5011F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x860>
	.long 0xd72d0002                                           // 000000528DE4: D72D0002
	v_cndmask_b32_e32 v0, v8, v45, vcc_lo                      // 000000528DE8: 02005B08
	s_mov_b32 s7, -1                                           // 000000528DEC: BE8700C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000528DF0: BF870091
	.long 0xd72c0003                                           // 000000528DF4: D72C0003
	v_cndmask_b32_e32 v0, v2, v38, vcc_lo                      // 000000528DF8: 02004D02
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000528DFC: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000528E00: BF870121
	v_subrev_nc_u32_e32 v5, s38, v3                            // 000000528E04: 4E0A0626
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000528E08: 7C960626
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000528E0C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000528E14: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000528E18: 02040902
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000528E1C: 7C960626
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000528E20: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000528E24: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000528E28: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s37                        // 000000528E2C: 916A257E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000528E30: BF870091
	v_xor_b32_e32 v14, s42, v2                                 // 000000528E34: 3A1C042A
	v_subrev_nc_u32_e32 v10, s42, v14                          // 000000528E38: 4E141C2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000528E3C: BF8700A1
	v_mad_u64_u32 v[6:7], null, s44, v10, v[1:2]               // 000000528E40: D6FE7C06 0406142C
	v_min_i32_e32 v2, s36, v10                                 // 000000528E48: 22041424
	v_mad_i64_i32 v[4:5], null, v2, s39, 0                     // 000000528E4C: D6FF7C04 02004F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000528E54: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000528E58: 340E0C9F
	.long 0xd73c0002                                           // 000000528E5C: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000528E60: 02020C81
	s_cbranch_vccnz 210                                        // 000000528E64: BFA400D2 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7b0>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000528E68: BF870093
	.long 0xd7006a06                                           // 000000528E6C: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000528E70: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000528E74: D5207C07 01AA0F05
	.long 0x7f3e3880                                           // 000000528E7C: 7F3E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000528E80: BF870112
	.long 0xd73c0006                                           // 000000528E84: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000528E88: 02020C81
	.long 0x7f44399f                                           // 000000528E8C: 7F44399F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000528E90: BF870092
	.long 0xd7006a0f                                           // 000000528E94: D7006A0F
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 000000528E98: 02020C0E
	v_add_co_ci_u32_e64 v16, null, s15, v7, vcc_lo             // 000000528E9C: D5207C10 01AA0E0F
	.long 0xd7006a06                                           // 000000528EA4: D7006A06
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000528EA8: 02020C1E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000528EAC: BF870001
	v_add_co_ci_u32_e64 v7, null, s31, v7, vcc_lo              // 000000528EB0: D5207C07 01AA0E1F
	global_load_b64 v[15:16], v[15:16], off                    // 000000528EB8: DC560000 0F7C000F
	.long 0xd7006a11                                           // 000000528EC0: D7006A11
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000528EC4: 02020414
	global_load_b64 v[6:7], v[6:7], off                        // 000000528EC8: DC560000 067C0006
	v_add_co_ci_u32_e64 v18, null, s21, v3, vcc_lo             // 000000528ED0: D5207C12 01AA0615
	s_clause 0x1                                               // 000000528ED8: BF850001
	global_load_b32 v19, v[17:18], off                         // 000000528EDC: DC520000 137C0011
	global_load_d16_b16 v17, v[17:18], off offset:4            // 000000528EE4: DC820004 117C0011
	s_waitcnt vmcnt(3)                                         // 000000528EEC: BF890FF7
	.long 0x7e24390f                                           // 000000528EF0: 7E24390F
	s_waitcnt vmcnt(2)                                         // 000000528EF4: BF890BF7
	v_and_b32_e32 v41, 0xffff0000, v6                          // 000000528EF8: 36520CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000528F00: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000528F04: BF870093
	v_lshlrev_b32_e32 v18, 16, v18                             // 000000528F08: 30242490
	v_mul_f32_e32 v22, 0xbfb8aa3b, v18                         // 000000528F0C: 102C24FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000528F14: BF870291
	v_exp_f32_e32 v22, v22                                     // 000000528F18: 7E2C4B16
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_and_b32 v15, 0xffff0000, v15// 000000528F1C: C9242CF2 160E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000528F28: BF870111
	v_mul_f32_e32 v21, 0xbfb8aa3b, v15                         // 000000528F2C: 102A1EFF BFB8AA3B
	v_div_scale_f32 v26, null, v22, v22, v18                   // 000000528F34: D6FC7C1A 044A2D16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000528F3C: BF8701B2
	v_exp_f32_e32 v21, v21                                     // 000000528F40: 7E2A4B15
	v_lshlrev_b32_e32 v20, 16, v16                             // 000000528F44: 30282090
	v_div_scale_f32 v39, s8, v18, v22, v18                     // 000000528F48: D6FC0827 044A2D12
	v_rcp_f32_e32 v30, v26                                     // 000000528F50: 7E3C551A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000528F54: BF870196
	v_add_f32_e32 v21, 1.0, v21                                // 000000528F58: 062A2AF2
	v_mul_f32_e32 v23, 0xbfb8aa3b, v20                         // 000000528F5C: 102E28FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000528F64: BF870195
	v_fma_f32 v38, -v26, v30, 1.0                              // 000000528F68: D6130026 23CA3D1A
	v_div_scale_f32 v25, null, v21, v21, v15                   // 000000528F70: D6FC7C19 043E2B15
	s_delay_alu instid0(VALU_DEP_3)                            // 000000528F78: BF870003
	v_exp_f32_e32 v23, v23                                     // 000000528F7C: 7E2E4B17
	v_and_b32_e32 v16, 0xffff0000, v16                         // 000000528F80: 362020FF FFFF0000
	v_div_scale_f32 v35, vcc_lo, v15, v21, v15                 // 000000528F88: D6FC6A23 043E2B0F
	v_fmac_f32_e32 v30, v38, v30                               // 000000528F90: 563C3D26
	v_rcp_f32_e32 v28, v25                                     // 000000528F94: 7E385519
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000528F98: BF870186
	v_dual_add_f32 v23, 1.0, v23 :: v_dual_mul_f32 v24, 0xbfb8aa3b, v16// 000000528F9C: C9062EF2 171820FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000528FA8: BF870115
	v_fma_f32 v36, -v25, v28, 1.0                              // 000000528FAC: D6130024 23CA3919
	v_div_scale_f32 v27, null, v23, v23, v20                   // 000000528FB4: D6FC7C1B 04522F17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000528FBC: BF8701A3
	v_exp_f32_e32 v24, v24                                     // 000000528FC0: 7E304B18
	v_div_scale_f32 v37, s7, v20, v23, v20                     // 000000528FC4: D6FC0725 04522F14
	v_fmac_f32_e32 v28, v36, v28                               // 000000528FCC: 56383924
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000528FD0: BF870313
	v_rcp_f32_e32 v32, v27                                     // 000000528FD4: 7E40551B
	v_add_f32_e32 v24, 1.0, v24                                // 000000528FD8: 063030F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000528FDC: BF870115
	v_fma_f32 v40, -v27, v32, 1.0                              // 000000528FE0: D6130028 23CA411B
	v_div_scale_f32 v29, null, v24, v24, v16                   // 000000528FE8: D6FC7C1D 04423118
	v_div_scale_f32 v38, s9, v16, v24, v16                     // 000000528FF0: D6FC0926 04423110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000528FF8: BF870193
	v_fmac_f32_e32 v32, v40, v32                               // 000000528FFC: 56404128
	v_rcp_f32_e32 v33, v29                                     // 000000529000: 7E42551D
	v_mul_f32_e32 v40, v35, v28                                // 000000529004: 10503923
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000529008: BF870112
	v_mul_f32_e32 v42, v37, v32                                // 00000052900C: 10544125
	v_fma_f32 v43, -v25, v40, v35                              // 000000529010: D613002B 248E5119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000529018: BF870292
	v_fma_f32 v46, -v27, v42, v37                              // 00000052901C: D613002E 2496551B
	v_fma_f32 v36, -v29, v33, 1.0                              // 000000529024: D6130024 23CA431D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000052902C: BF870113
	v_fmac_f32_e32 v40, v43, v28                               // 000000529030: 5650392B
	v_dual_fmac_f32 v42, v46, v32 :: v_dual_fmac_f32 v33, v36, v33// 000000529034: C800412E 2A204324
	v_mul_f32_e32 v36, v39, v30                                // 00000052903C: 10483D27
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000529040: BF870193
	v_fma_f32 v25, -v25, v40, v35                              // 000000529044: D6130019 248E5119
	v_fma_f32 v27, -v27, v42, v37                              // 00000052904C: D613001B 2496551B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000529054: BF870214
	v_mul_f32_e32 v44, v38, v33                                // 000000529058: 10584326
	v_fma_f32 v45, -v26, v36, v39                              // 00000052905C: D613002D 249E491A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000529064: BF8701A4
	v_div_fmas_f32 v25, v25, v28, v40                          // 000000529068: D6370019 04A23919
	s_mov_b32 vcc_lo, s8                                       // 000000529070: BEEA0008
	v_fma_f32 v43, -v29, v44, v38                              // 000000529074: D613002B 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000052907C: BF870193
	v_fmac_f32_e32 v36, v45, v30                               // 000000529080: 56483D2D
	v_div_fixup_f32 v15, v25, v21, v15                         // 000000529084: D627000F 043E2B19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000052908C: BF870193
	v_fmac_f32_e32 v44, v43, v33                               // 000000529090: 5658432B
	v_fma_f32 v26, -v26, v36, v39                              // 000000529094: D613001A 249E491A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000052909C: BF870193
	v_mul_f32_e32 v15, v15, v41                                // 0000005290A0: 101E530F
	v_fma_f32 v25, -v29, v44, v38                              // 0000005290A4: D6130019 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005290AC: BF8701A3
	v_div_fmas_f32 v26, v26, v30, v36                          // 0000005290B0: D637001A 04923D1A
	s_mov_b32 vcc_lo, s7                                       // 0000005290B8: BEEA0007
	.long 0x7e3e398f                                           // 0000005290BC: 7E3E398F
	v_div_fmas_f32 v21, v27, v32, v42                          // 0000005290C0: D6370015 04AA411B
	s_mov_b32 vcc_lo, s9                                       // 0000005290C8: BEEA0009
	v_div_fixup_f32 v18, v26, v22, v18                         // 0000005290CC: D6270012 044A2D1A
	v_lshlrev_b32_e32 v22, 16, v7                              // 0000005290D4: 302C0E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000005290D8: 360E0EFF FFFF0000
	v_div_fixup_f32 v20, v21, v23, v20                         // 0000005290E0: D6270014 04522F15
	s_mov_b32 s7, 0                                            // 0000005290E8: BE870080
	v_mul_f32_e32 v6, v18, v6                                  // 0000005290EC: 100C0D12
	v_div_fmas_f32 v18, v25, v33, v44                          // 0000005290F0: D6370012 04B24319
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005290F8: BF870193
	v_mul_f32_e32 v20, v20, v22                                // 0000005290FC: 10282D14
	.long 0x7e443986                                           // 000000529100: 7E443986
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000529104: BF870223
	v_div_fixup_f32 v16, v18, v24, v16                         // 000000529108: D6270010 04423112
	v_and_b32_e32 v18, 1, v31                                  // 000000529110: 36243E81
	v_bfe_u32 v21, v20, 16, 1                                  // 000000529114: D6100015 02052114
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000052911C: BF870193
	v_dual_mul_f32 v7, v16, v7 :: v_dual_and_b32 v22, 1, v34   // 000000529120: C8E40F10 07164481
	v_add3_u32 v15, v15, v18, 0x7fff                           // 000000529128: D655000F 03FE250F 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000529134: BF870193
	v_add3_u32 v16, v20, v21, 0x7fff                           // 000000529138: D6550010 03FE2B14 00007FFF
	v_add3_u32 v6, v6, v22, 0x7fff                             // 000000529144: D6550006 03FE2D06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000529150: BF870214
	v_bfe_u32 v18, v7, 16, 1                                   // 000000529154: D6100012 02052107
	v_and_b32_e32 v15, 0xffff0000, v15                         // 00000052915C: 361E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000529164: BF870214
	v_and_b32_e32 v20, 0xffff0000, v16                         // 000000529168: 362820FF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000529170: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000529178: BF870004
	v_add3_u32 v7, v7, v18, 0x7fff                             // 00000052917C: D6550007 03FE2507 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000529188: BF8907F7
	v_fma_mix_f32 v16, v19, v15, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000052918C: CC200810 8A021F13
	s_waitcnt vmcnt(0)                                         // 000000529194: BF8903F7
	v_fma_mix_f32 v15, v17, v20, neg(0) op_sel_hi:[1,0,0]      // 000000529198: CC20000F 8A022911
	v_fma_mix_f32 v18, v19, v6, neg(0) op_sel_hi:[1,0,0]       // 0000005291A0: CC200012 8A020D13
	v_and_b32_e32 v17, 0xffff0000, v7                          // 0000005291A8: 36220EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000005291B0: 916A077E
	s_cbranch_vccnz 65123                                      // 0000005291B4: BFA4FE63 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x144>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005291B8: BF870093
	.long 0xd73c0004                                           // 0000005291BC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000005291C0: 02020881
	.long 0xd7006a04                                           // 0000005291C4: D7006A04
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 0000005291C8: 0202080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005291CC: BF870111
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 0000005291D0: D5207C05 01AA0A0F
	.long 0xd7006a04                                           // 0000005291D8: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000005291DC: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005291E0: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000005291E4: D5207C05 01AA0705
	.long 0xd7006a06                                           // 0000005291EC: D7006A06
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 0000005291F0: 02020414
	v_add_co_ci_u32_e64 v7, null, s21, v3, vcc_lo              // 0000005291F4: D5207C07 01AA0615
	global_load_b64 v[4:5], v[4:5], off                        // 0000005291FC: DC560000 047C0004
	s_clause 0x1                                               // 000000529204: BF850001
	global_load_b32 v17, v[6:7], off                           // 000000529208: DC520000 117C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000529210: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000529218: BF890BF7
	.long 0x7e0e3904                                           // 00000052921C: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000529220: 360808FF FFFF0000
	v_lshlrev_b32_e32 v15, 16, v5                              // 000000529228: 301E0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000052922C: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000529230: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000529234: BF8907F7
	v_fma_mix_f32 v16, v17, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000529238: CC200810 8A020911
	s_waitcnt vmcnt(0)                                         // 000000529240: BF8903F7
	v_fma_mix_f32 v15, v6, v15, neg(0) op_sel_hi:[1,0,0]       // 000000529244: CC20000F 8A021F06
	v_fma_mix_f32 v18, v17, v7, neg(0) op_sel_hi:[1,0,0]       // 00000052924C: CC200012 8A020F11
	v_and_b32_e32 v17, 0xffff0000, v5                          // 000000529254: 36220AFF FFFF0000
	s_branch 65081                                             // 00000052925C: BFA0FE39 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x144>
	s_or_b32 exec_lo, exec_lo, s19                             // 000000529260: 8C7E137E
	s_bfe_i32 s10, s11, 0x1001c                                // 000000529264: 938AFF0B 0001001C
	s_lshr_b32 s3, s34, 28                                     // 00000052926C: 85039C22
	s_lshr_b64 s[0:1], s[10:11], 29                            // 000000529270: 85809D0A
	s_add_i32 s3, s17, s3                                      // 000000529274: 81030311
	s_add_i32 s0, s0, 7                                        // 000000529278: 81008700
	s_lshl_b32 s1, s11, 3                                      // 00000052927C: 8401830B
	s_ashr_i32 s0, s0, 3                                       // 000000529280: 86008300
	s_lshl_b32 s5, s35, 3                                      // 000000529284: 84058323
	.long 0xd72c0001                                           // 000000529288: D72C0001
	v_cndmask_b32_e32 v1, s0, v11, vcc_lo                      // 00000052928C: 02021600
	s_waitcnt lgkmcnt(0)                                       // 000000529290: BF89FC07
	s_barrier                                                  // 000000529294: BFBD0000
	buffer_gl0_inv                                             // 000000529298: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 0000005292A0: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 0000005292A4: 86008403
	s_ashr_i32 s3, s5, 31                                      // 0000005292A8: 86039F05
	s_mul_hi_i32 s6, s0, s2                                    // 0000005292AC: 97060200
	s_mul_i32 s0, s0, s2                                       // 0000005292B0: 96000200
	v_min_i32_e32 v14, s1, v2                                  // 0000005292B4: 221C0401
	v_add_nc_u32_e32 v2, 1, v1                                 // 0000005292B8: 4A040281
	s_add_u32 s0, s0, s5                                       // 0000005292BC: 80000500
	s_addc_u32 s1, s6, s3                                      // 0000005292C0: 82010306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005292C4: BF870099
	s_lshl_b64 s[6:7], s[0:1], 10                              // 0000005292C8: 84868A00
	v_cmp_lt_i32_e32 vcc_lo, v2, v14                           // 0000005292CC: 7C821D02
	s_add_u32 s1, s12, s6                                      // 0000005292D0: 8001060C
	s_addc_u32 s5, s13, s7                                     // 0000005292D4: 8205070D
	s_and_saveexec_b32 s0, vcc_lo                              // 0000005292D8: BE80206A
	s_cbranch_execz 91                                         // 0000005292DC: BFA5005B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xa4c>
	.long 0xd7010303                                           // 0000005292E0: D7010303
	v_cndmask_b32_e32 v0, v13, v129, vcc_lo                    // 0000005292E4: 0201030D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005292E8: BF870121
	v_cndmask_b32_e64 v4, v3, 31, s3                           // 0000005292EC: D5010004 000D3F03
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000005292F4: 3406049F
	v_cmp_gt_u32_e32 vcc_lo, 31, v4                            // 0000005292F8: 7C98089F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000005292FC: BF8701B2
	.long 0xd73c0002                                           // 000000529300: D73C0002
	v_cndmask_b32_e32 v1, 10, v2, vcc_lo                       // 000000529304: 0202048A
	v_cndmask_b32_e64 v6, 0xe1, 1, vcc_lo                      // 000000529308: D5010006 01A902FF 000000E1
	v_mov_b32_e32 v5, 0                                        // 000000529314: 7E0A0280
	.long 0xd7006a08                                           // 000000529318: D7006A08
	v_cndmask_b32_e32 v1, s1, v2, vcc_lo                       // 00000052931C: 02020401
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000529320: BF870211
	v_add_co_ci_u32_e64 v9, null, s5, v3, vcc_lo               // 000000529324: D5207C09 01AA0605
	v_add_nc_u32_e32 v6, v6, v4                                // 00000052932C: 4A0C0906
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000529330: BF870114
	.long 0xd73c0004                                           // 000000529334: D73C0004
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 000000529338: 02020882
	v_lshlrev_b32_e32 v7, 24, v6                               // 00000052933C: 300E0C98
	v_bfe_i32 v6, v6, 7, 1                                     // 000000529340: D6110006 02050F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000529348: BF870093
	.long 0xd7006a02                                           // 00000052934C: D7006A02
	v_cndmask_b32_e32 v1, v8, v4, vcc_lo                       // 000000529350: 02020908
	v_add_co_ci_u32_e64 v3, null, v9, v5, vcc_lo               // 000000529354: D5207C03 01AA0B09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052935C: BF870094
	v_ashrrev_i32_e32 v7, 22, v7                               // 000000529360: 340E0E96
	.long 0xd7006a04                                           // 000000529364: D7006A04
	v_cndmask_b32_e32 v1, v8, v7, vcc_lo                       // 000000529368: 02020F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000052936C: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v9, v6, vcc_lo               // 000000529370: D5207C05 01AA0D09
	.long 0xd7006a06                                           // 000000529378: D7006A06
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 00000052937C: 02021908
	v_add_co_ci_u32_e64 v7, null, 0, v9, vcc_lo                // 000000529380: D5207C07 01AA1280
	s_clause 0x17                                              // 000000529388: BF850017
	global_load_b32 v15, v[2:3], off                           // 00000052938C: DC520000 0F7C0002
	global_load_b32 v20, v[2:3], off offset:128                // 000000529394: DC520080 147C0002
	global_load_b32 v19, v[2:3], off offset:256                // 00000052939C: DC520100 137C0002
	global_load_b32 v18, v[2:3], off offset:384                // 0000005293A4: DC520180 127C0002
	global_load_b32 v17, v[2:3], off offset:512                // 0000005293AC: DC520200 117C0002
	global_load_b32 v16, v[2:3], off offset:640                // 0000005293B4: DC520280 107C0002
	global_load_b32 v10, v[2:3], off offset:768                // 0000005293BC: DC520300 0A7C0002
	global_load_b32 v29, v[2:3], off offset:896                // 0000005293C4: DC520380 1D7C0002
	global_load_b32 v28, v[4:5], off                           // 0000005293CC: DC520000 1C7C0004
	global_load_b32 v26, v[4:5], off offset:128                // 0000005293D4: DC520080 1A7C0004
	global_load_b32 v24, v[4:5], off offset:256                // 0000005293DC: DC520100 187C0004
	global_load_b32 v23, v[4:5], off offset:384                // 0000005293E4: DC520180 177C0004
	global_load_b32 v22, v[4:5], off offset:512                // 0000005293EC: DC520200 167C0004
	global_load_b32 v21, v[4:5], off offset:640                // 0000005293F4: DC520280 157C0004
	global_load_b32 v37, v[4:5], off offset:768                // 0000005293FC: DC520300 257C0004
	global_load_b32 v36, v[4:5], off offset:896                // 000000529404: DC520380 247C0004
	global_load_b32 v35, v[6:7], off                           // 00000052940C: DC520000 237C0006
	global_load_b32 v32, v[6:7], off offset:128                // 000000529414: DC520080 207C0006
	global_load_b32 v31, v[6:7], off offset:256                // 00000052941C: DC520100 1F7C0006
	global_load_b32 v30, v[6:7], off offset:384                // 000000529424: DC520180 1E7C0006
	global_load_b32 v27, v[6:7], off offset:512                // 00000052942C: DC520200 1B7C0006
	global_load_b32 v25, v[6:7], off offset:640                // 000000529434: DC520280 197C0006
	global_load_b32 v34, v[6:7], off offset:768                // 00000052943C: DC520300 227C0006
	global_load_b32 v33, v[6:7], off offset:896                // 000000529444: DC520380 217C0006
	s_or_b32 exec_lo, exec_lo, s0                              // 00000052944C: 8C7E007E
	v_cmp_lt_i32_e32 vcc_lo, v1, v14                           // 000000529450: 7C821D01
	s_and_saveexec_b32 s3, vcc_lo                              // 000000529454: BE83206A
	s_cbranch_execz 93                                         // 000000529458: BFA5005D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xbd0>
	.long 0xd7010002                                           // 00000052945C: D7010002
	v_cndmask_b32_e32 v0, v13, v129, vcc_lo                    // 000000529460: 0201030D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000529464: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 000000529468: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000529470: 3404029F
	.long 0xd44c0000                                           // 000000529474: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000529478: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052947C: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 000000529480: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 00000052948C: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000529494: BF870114
	.long 0xd73c0005                                           // 000000529498: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000052949C: 0202028A
	.long 0xd73c0002                                           // 0000005294A0: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 0000005294A4: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005294A8: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 0000005294AC: 30080E98
	v_bfe_i32 v7, v7, 7, 1                                     // 0000005294B0: D6110007 02050F07
	.long 0xd7000008                                           // 0000005294B8: D7000008
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 0000005294BC: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005294C0: BF870211
	v_add_co_ci_u32_e64 v9, null, s5, v6, s0                   // 0000005294C4: D5207C09 00020C05
	v_ashrrev_i32_e32 v6, 22, v4                               // 0000005294CC: 340C0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005294D0: BF870093
	.long 0xd7000004                                           // 0000005294D4: D7000004
	v_cndmask_b32_e32 v1, v8, v2, vcc_lo                       // 0000005294D8: 02020508
	v_add_co_ci_u32_e64 v5, null, v9, v3, s0                   // 0000005294DC: D5207C05 00020709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005294E4: BF870093
	.long 0xd7000006                                           // 0000005294E8: D7000006
	v_cndmask_b32_e32 v1, v8, v6, vcc_lo                       // 0000005294EC: 02020D08
	v_add_co_ci_u32_e64 v7, null, v9, v7, s0                   // 0000005294F0: D5207C07 00020F09
	.long 0xd7000008                                           // 0000005294F8: D7000008
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 0000005294FC: 02021908
	s_delay_alu instid0(VALU_DEP_1)                            // 000000529500: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v9, s0                    // 000000529504: D5207C09 00021280
	s_clause 0x17                                              // 00000052950C: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000529510: DC520000 027C0004
	global_load_b32 v96, v[4:5], off offset:128                // 000000529518: DC520080 607C0004
	global_load_b32 v92, v[4:5], off offset:256                // 000000529520: DC520100 5C7C0004
	global_load_b32 v89, v[4:5], off offset:384                // 000000529528: DC520180 597C0004
	global_load_b32 v86, v[4:5], off offset:512                // 000000529530: DC520200 567C0004
	global_load_b32 v82, v[4:5], off offset:640                // 000000529538: DC520280 527C0004
	global_load_b32 v75, v[4:5], off offset:768                // 000000529540: DC520300 4B7C0004
	global_load_b32 v59, v[4:5], off offset:896                // 000000529548: DC520380 3B7C0004
	global_load_b32 v3, v[6:7], off                            // 000000529550: DC520000 037C0006
	global_load_b32 v97, v[6:7], off offset:128                // 000000529558: DC520080 617C0006
	global_load_b32 v93, v[6:7], off offset:256                // 000000529560: DC520100 5D7C0006
	global_load_b32 v90, v[6:7], off offset:384                // 000000529568: DC520180 5A7C0006
	global_load_b32 v87, v[6:7], off offset:512                // 000000529570: DC520200 577C0006
	global_load_b32 v84, v[6:7], off offset:640                // 000000529578: DC520280 547C0006
	global_load_b32 v83, v[6:7], off offset:768                // 000000529580: DC520300 537C0006
	global_load_b32 v60, v[6:7], off offset:896                // 000000529588: DC520380 3C7C0006
	global_load_b32 v95, v[8:9], off                           // 000000529590: DC520000 5F7C0008
	global_load_b32 v94, v[8:9], off offset:128                // 000000529598: DC520080 5E7C0008
	global_load_b32 v91, v[8:9], off offset:256                // 0000005295A0: DC520100 5B7C0008
	global_load_b32 v88, v[8:9], off offset:384                // 0000005295A8: DC520180 587C0008
	global_load_b32 v85, v[8:9], off offset:512                // 0000005295B0: DC520200 557C0008
	global_load_b32 v73, v[8:9], off offset:640                // 0000005295B8: DC520280 497C0008
	global_load_b32 v74, v[8:9], off offset:768                // 0000005295C0: DC520300 4A7C0008
	global_load_b32 v58, v[8:9], off offset:896                // 0000005295C8: DC520380 3A7C0008
	s_or_b32 exec_lo, exec_lo, s3                              // 0000005295D0: 8C7E037E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 0000005295D4: CA100080 26260080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 0000005295DC: CA100080 292A0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v47, 0             // 0000005295E4: CA100080 2C2E0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v49, 0             // 0000005295EC: CA100080 2E300080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v43, 0             // 0000005295F4: CA100080 282A0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v45, 0             // 0000005295FC: CA100080 302C0080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v52, 0             // 000000529604: CA100080 33340080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v53, 0             // 00000052960C: CA100080 32340080
	s_ashr_i32 s3, s2, 31                                      // 000000529614: 86039F02
	s_and_saveexec_b32 s0, vcc_lo                              // 000000529618: BE80206A
	s_cbranch_execz 1034                                       // 00000052961C: BFA5040A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c48>
	v_dual_mov_b32 v39, 0 :: v_dual_add_nc_u32 v4, -1, v0      // 000000529620: CA200080 270400C1
	v_dual_mov_b32 v42, 0 :: v_dual_and_b32 v5, 16, v0         // 000000529628: CA240080 2A040090
	v_dual_mov_b32 v38, 0 :: v_dual_add_nc_u32 v9, 2, v1       // 000000529630: CA200080 26080282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000529638: BF870243
	v_dual_mov_b32 v41, 0 :: v_dual_and_b32 v4, 31, v4         // 00000052963C: CA240080 2904089F
	v_sub_nc_u32_e32 v54, 0, v14                               // 000000529644: 4C6C1C80
	v_dual_mov_b32 v44, 0 :: v_dual_lshlrev_b32 v55, 2, v13    // 000000529648: CA220080 2C361A82
	v_lshl_or_b32 v56, v1, 5, v5                               // 000000529650: D6560038 04150B01
	v_dual_mov_b32 v46, 0 :: v_dual_lshlrev_b32 v57, 2, v4     // 000000529658: CA220080 2E380882
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v40, 0             // 000000529660: CA100080 2F280080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v49, 0             // 000000529668: CA100080 30300080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v52, 0             // 000000529670: CA100080 2B340080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v50, 0             // 000000529678: CA100080 2D320080
	v_mov_b32_e32 v51, 0                                       // 000000529680: 7E660280
	v_mov_b32_e32 v53, 0                                       // 000000529684: 7E6A0280
	s_mov_b32 s6, 0                                            // 000000529688: BE860080
	s_movk_i32 s7, 0x1eee                                      // 00000052968C: B0071EEE
	s_branch 936                                               // 000000529690: BFA003A8 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b34>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000529694: 8C7E087E
	v_alignbit_b32 v98, v2, v3, 16                             // 000000529698: D6160062 02420702
	v_alignbit_b32 v96, v96, v97, 16                           // 0000005296A0: D6160060 0242C360
	ds_load_b128 v[1:4], v56                                   // 0000005296A8: DBFC0000 01000038
	ds_load_b128 v[5:8], v56 offset:5120                       // 0000005296B0: DBFC1400 05000038
	v_bfe_u32 v99, v95, 12, 16                                 // 0000005296B8: D6100063 0241195F
	v_bfe_u32 v101, v95, 8, 16                                 // 0000005296C0: D6100065 0241115F
	v_bfe_u32 v100, v98, 12, 16                                // 0000005296C8: D6100064 02411962
	v_bfe_u32 v97, v98, 8, 16                                  // 0000005296D0: D6100061 02411162
	v_bfe_u32 v103, v95, 4, 16                                 // 0000005296D8: D6100067 0241095F
	.long 0xd72c0063                                           // 0000005296E0: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 0000005296E4: 0202C6FF 83DCD12D
	.long 0xd72c0065                                           // 0000005296EC: D72C0065
	v_cndmask_b32_e32 v1, 0x83dcd12d, v101, vcc_lo             // 0000005296F0: 0202CAFF 83DCD12D
	.long 0xd72c0064                                           // 0000005296F8: D72C0064
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 0000005296FC: 0202C8FF 83DCD12D
	.long 0xd72c0061                                           // 000000529704: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000529708: 0202C2FF 83DCD12D
	.long 0xd72c0067                                           // 000000529710: D72C0067
	v_cndmask_b32_e32 v1, 0x83dcd12d, v103, vcc_lo             // 000000529714: 0202CEFF 83DCD12D
	v_alignbit_b32 v92, v92, v93, 16                           // 00000052971C: D616005C 0242BB5C
	v_alignbit_b32 v89, v89, v90, 16                           // 000000529724: D6160059 0242B559
	v_alignbit_b32 v86, v86, v87, 16                           // 00000052972C: D6160056 0242AF56
	v_sad_u8 v99, v99, 0, 0x6400                               // 000000529734: D6220063 03FD0163 00006400
	v_alignbit_b32 v82, v82, v84, 16                           // 000000529740: D6160052 0242A952
	v_sad_u8 v100, v100, 0, 0x6400                             // 000000529748: D6220064 03FD0164 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000529754: D6220061 03FD0161 00006400
	v_alignbit_b32 v75, v75, v83, 16                           // 000000529760: D616004B 0242A74B
	v_alignbit_b32 v59, v59, v60, 16                           // 000000529768: D616003B 0242793B
	v_add_nc_u32_e32 v56, 32, v56                              // 000000529770: 4A7070A0
	v_and_b32_e32 v100, 0xffff, v100                           // 000000529774: 36C8C8FF 0000FFFF
	v_add_nc_u32_e32 v9, 1, v9                                 // 00000052977C: 4A121281
	v_bfe_u32 v83, v75, 4, 16                                  // 000000529780: D6100053 0241094B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000529788: BF870233
	v_lshl_or_b32 v97, v97, 16, v100                           // 00000052978C: D6560061 05912161
	v_sad_u8 v100, v101, 0, 0x6400                             // 000000529794: D6220064 03FD0165 00006400
	v_sad_u8 v101, v103, 0, 0x6400                             // 0000005297A0: D6220065 03FD0167 00006400
	.long 0xd72c0053                                           // 0000005297AC: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000005297B0: 0202A6FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000005297B8: BF8701C4
	v_pk_fma_f16 v97, v97, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000005297BC: CC0E0061 0BFC0F61 0000C931
	v_and_b32_e32 v102, 0xffff, v98                            // 0000005297C8: 36CCC4FF 0000FFFF
	v_bfe_u32 v98, v98, 4, 16                                  // 0000005297D0: D6100062 02410962
	s_waitcnt lgkmcnt(0)                                       // 0000005297D8: BF89FC07
	v_dual_dot2acc_f32_f16 v50, v97, v5 :: v_dual_and_b32 v95, 0xffff, v95// 0000005297DC: CB240B61 325EBEFF 0000FFFF
	v_dot2acc_f32_f16 v53, v97, v1                             // 0000005297E8: 046A0361
	.long 0xd72c0066                                           // 0000005297EC: D72C0066
	v_cndmask_b32_e32 v1, 0x83dcd12d, v102, vcc_lo             // 0000005297F0: 0202CCFF 83DCD12D
	v_and_b32_e32 v99, 0xffff, v99                             // 0000005297F8: 36C6C6FF 0000FFFF
	.long 0xd72c0062                                           // 000000529800: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000529804: 0202C4FF 83DCD12D
	v_bfe_u32 v97, v96, 12, 16                                 // 00000052980C: D6100061 02411960
	.long 0xd72c005f                                           // 000000529814: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000529818: 0202BEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000529820: BF870004
	v_lshl_or_b32 v99, v100, 16, v99                           // 000000529824: D6560063 058D2164
	v_bfe_u32 v100, v96, 4, 16                                 // 00000052982C: D6100064 02410960
	v_sad_u8 v102, v102, 0, 0x6400                             // 000000529834: D6220066 03FD0166 00006400
	.long 0xd72c0061                                           // 000000529840: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000529844: 0202C2FF 83DCD12D
	v_sad_u8 v98, v98, 0, 0x6400                               // 00000052984C: D6220062 03FD0162 00006400
	v_pk_fma_f16 v99, v99, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000529858: CC0E0063 0BFC0F63 0000C931
	.long 0xd72c0064                                           // 000000529864: D72C0064
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 000000529868: 0202C8FF 83DCD12D
	v_lshlrev_b32_e32 v102, 16, v102                           // 000000529870: 30CCCC90
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000529874: D622005F 03FD015F 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000529880: D6220061 03FD0161 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000052988C: BF8701A3
	v_and_or_b32 v98, 0xffff, v98, v102                        // 000000529890: D6570062 059AC4FF 0000FFFF
	v_bfe_u32 v102, v91, 4, 16                                 // 00000052989C: D6100066 0241095B
	v_and_b32_e32 v97, 0xffff, v97                             // 0000005298A4: 36C2C2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005298AC: BF870093
	v_pk_fma_f16 v98, v98, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000005298B0: CC0E0062 0BFC0F62 0000C931
	v_dot2acc_f32_f16 v53, v98, v2                             // 0000005298BC: 046A0562
	v_dot2acc_f32_f16 v50, v98, v6                             // 0000005298C0: 04640D62
	v_bfe_u32 v98, v94, 12, 16                                 // 0000005298C4: D6100062 0241195E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005298CC: BF870193
	v_dot2acc_f32_f16 v53, v99, v3                             // 0000005298D0: 046A0763
	v_dot2acc_f32_f16 v50, v99, v7                             // 0000005298D4: 04640F63
	v_bfe_u32 v99, v96, 8, 16                                  // 0000005298D8: D6100063 02411160
	v_and_b32_e32 v96, 0xffff, v96                             // 0000005298E0: 36C0C0FF 0000FFFF
	.long 0xd72c0062                                           // 0000005298E8: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 0000005298EC: 0202C4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005298F4: BF870193
	.long 0xd72c0063                                           // 0000005298F8: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 0000005298FC: 0202C6FF 83DCD12D
	.long 0xd72c0060                                           // 000000529904: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000529908: 0202C0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000529910: BF870193
	v_sad_u8 v98, v98, 0, 0x6400                               // 000000529914: D6220062 03FD0162 00006400
	v_sad_u8 v99, v99, 0, 0x6400                               // 000000529920: D6220063 03FD0163 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000052992C: BF870193
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000529930: D6220060 03FD0160 00006400
	v_and_b32_e32 v98, 0xffff, v98                             // 00000052993C: 36C4C4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000529944: BF870223
	v_lshl_or_b32 v97, v99, 16, v97                            // 000000529948: D6560061 05852163
	v_sad_u8 v99, v100, 0, 0x6400                              // 000000529950: D6220063 03FD0164 00006400
	v_lshlrev_b32_e32 v96, 16, v96                             // 00000052995C: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000529960: BF870211
	v_and_or_b32 v93, 0xffff, v99, v96                         // 000000529964: D657005D 0582C6FF 0000FFFF
	v_pk_fma_f16 v96, v97, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000529970: CC0E0060 0BFC0F61 0000C931
	v_lshlrev_b32_e32 v95, 16, v95                             // 00000052997C: 30BEBE90
	v_bfe_u32 v97, v92, 12, 16                                 // 000000529980: D6100061 0241195C
	v_bfe_u32 v99, v92, 8, 16                                  // 000000529988: D6100063 0241115C
	v_pk_fma_f16 v93, v93, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000529990: CC0E005D 0BFC0F5D 0000C931
	v_dot2acc_f32_f16 v52, v96, v1                             // 00000052999C: 04680360
	v_and_or_b32 v95, 0xffff, v101, v95                        // 0000005299A0: D657005F 057ECAFF 0000FFFF
	v_and_b32_e32 v101, 0xffff, v94                            // 0000005299AC: 36CABCFF 0000FFFF
	.long 0xd72c0061                                           // 0000005299B4: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 0000005299B8: 0202C2FF 83DCD12D
	.long 0xd72c0063                                           // 0000005299C0: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 0000005299C4: 0202C6FF 83DCD12D
	v_dot2acc_f32_f16 v52, v93, v2                             // 0000005299CC: 0468055D
	v_pk_fma_f16 v95, v95, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000005299D0: CC0E005F 0BFC0F5F 0000C931
	.long 0xd72c0065                                           // 0000005299DC: D72C0065
	v_cndmask_b32_e32 v1, 0x83dcd12d, v101, vcc_lo             // 0000005299E0: 0202CAFF 83DCD12D
	v_dot2acc_f32_f16 v51, v96, v5                             // 0000005299E8: 04660B60
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005299EC: BF870003
	v_dot2acc_f32_f16 v53, v95, v4                             // 0000005299F0: 046A095F
	v_dot2acc_f32_f16 v50, v95, v8                             // 0000005299F4: 0464115F
	v_bfe_u32 v95, v94, 8, 16                                  // 0000005299F8: D610005F 0241115E
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000529A00: D6220061 03FD0161 00006400
	v_sad_u8 v99, v99, 0, 0x6400                               // 000000529A0C: D6220063 03FD0163 00006400
	v_bfe_u32 v94, v94, 4, 16                                  // 000000529A18: D610005E 0241095E
	v_sad_u8 v100, v101, 0, 0x6400                             // 000000529A20: D6220064 03FD0165 00006400
	.long 0xd72c005f                                           // 000000529A2C: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000529A30: 0202BEFF 83DCD12D
	v_bfe_u32 v101, v91, 8, 16                                 // 000000529A38: D6100065 0241115B
	v_dot2acc_f32_f16 v51, v93, v6                             // 000000529A40: 04660D5D
	.long 0xd72c005e                                           // 000000529A44: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000529A48: 0202BCFF 83DCD12D
	v_lshlrev_b32_e32 v100, 16, v100                           // 000000529A50: 30C8C890
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000529A54: BF870224
	.long 0xd72c0065                                           // 000000529A58: D72C0065
	v_cndmask_b32_e32 v1, 0x83dcd12d, v101, vcc_lo             // 000000529A5C: 0202CAFF 83DCD12D
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000529A64: D622005F 03FD015F 00006400
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000529A70: D622005E 03FD015E 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000529A7C: BF870112
	v_lshl_or_b32 v95, v95, 16, v98                            // 000000529A80: D656005F 0589215F
	v_and_or_b32 v94, 0xffff, v94, v100                        // 000000529A88: D657005E 0592BCFF 0000FFFF
	v_bfe_u32 v100, v91, 12, 16                                // 000000529A94: D6100064 0241195B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000529A9C: BF870003
	v_pk_fma_f16 v95, v95, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000529AA0: CC0E005F 0BFC0F5F 0000C931
	v_and_b32_e32 v97, 0xffff, v97                             // 000000529AAC: 36C2C2FF 0000FFFF
	v_and_b32_e32 v91, 0xffff, v91                             // 000000529AB4: 36B6B6FF 0000FFFF
	v_pk_fma_f16 v94, v94, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000529ABC: CC0E005E 0BFC0F5E 0000C931
	.long 0xd72c0064                                           // 000000529AC8: D72C0064
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 000000529ACC: 0202C8FF 83DCD12D
	v_dot2acc_f32_f16 v52, v95, v3                             // 000000529AD4: 0468075F
	v_lshl_or_b32 v97, v99, 16, v97                            // 000000529AD8: D6560061 05852163
	.long 0xd72c005b                                           // 000000529AE0: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000529AE4: 0202B6FF 83DCD12D
	v_dot2acc_f32_f16 v51, v95, v7                             // 000000529AEC: 04660F5F
	v_bfe_u32 v95, v89, 8, 16                                  // 000000529AF0: D610005F 02411159
	v_dot2acc_f32_f16 v52, v94, v4                             // 000000529AF8: 0468095E
	v_pk_fma_f16 v96, v97, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000529AFC: CC0E0060 0BFC0F61 0000C931
	v_and_b32_e32 v98, 0xffff, v92                             // 000000529B08: 36C4B8FF 0000FFFF
	v_bfe_u32 v92, v92, 4, 16                                  // 000000529B10: D610005C 0241095C
	.long 0xd72c005f                                           // 000000529B18: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000529B1C: 0202BEFF 83DCD12D
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000529B24: D622005B 03FD015B 00006400
	v_dot2acc_f32_f16 v45, v96, v1                             // 000000529B30: 045A0360
	.long 0xd72c0062                                           // 000000529B34: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000529B38: 0202C4FF 83DCD12D
	.long 0xd72c005c                                           // 000000529B40: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000529B44: 0202B8FF 83DCD12D
	v_sad_u8 v100, v100, 0, 0x6400                             // 000000529B4C: D6220064 03FD0164 00006400
	v_lshlrev_b32_e32 v91, 16, v91                             // 000000529B58: 30B6B690
	v_dot2acc_f32_f16 v43, v96, v5                             // 000000529B5C: 04560B60
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000529B60: D622005F 03FD015F 00006400
	v_bfe_u32 v96, v88, 12, 16                                 // 000000529B6C: D6100060 02411958
	v_dot2acc_f32_f16 v51, v94, v8                             // 000000529B74: 0466115E
	v_sad_u8 v98, v98, 0, 0x6400                               // 000000529B78: D6220062 03FD0162 00006400
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000529B84: D622005C 03FD015C 00006400
	v_and_b32_e32 v94, 0xffff, v89                             // 000000529B90: 36BCB2FF 0000FFFF
	.long 0xd72c0060                                           // 000000529B98: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000529B9C: 0202C0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000529BA4: BF870194
	v_lshlrev_b32_e32 v98, 16, v98                             // 000000529BA8: 30C4C490
	.long 0xd72c005e                                           // 000000529BAC: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000529BB0: 0202BCFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000529BB8: BF8701B2
	v_and_or_b32 v92, 0xffff, v92, v98                         // 000000529BBC: D657005C 058AB8FF 0000FFFF
	.long 0xd72c0062                                           // 000000529BC8: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v102, vcc_lo             // 000000529BCC: 0202CCFF 83DCD12D
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000529BD4: D6220060 03FD0160 00006400
	v_pk_fma_f16 v92, v92, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000529BE0: CC0E005C 0BFC0F5C 0000C931
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000529BEC: D622005E 03FD015E 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000529BF8: BF870194
	v_sad_u8 v98, v98, 0, 0x6400                               // 000000529BFC: D6220062 03FD0162 00006400
	v_dot2acc_f32_f16 v45, v92, v2                             // 000000529C08: 045A055C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000529C0C: BF870193
	v_lshlrev_b32_e32 v94, 16, v94                             // 000000529C10: 30BCBC90
	v_and_or_b32 v91, 0xffff, v98, v91                         // 000000529C14: D657005B 056EC4FF 0000FFFF
	v_bfe_u32 v98, v88, 4, 16                                  // 000000529C20: D6100062 02410958
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000529C28: BF870132
	v_pk_fma_f16 v90, v91, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000529C2C: CC0E005A 0BFC0F5B 0000C931
	v_bfe_u32 v91, v89, 12, 16                                 // 000000529C38: D610005B 02411959
	v_bfe_u32 v89, v89, 4, 16                                  // 000000529C40: D6100059 02410959
	.long 0xd72c005b                                           // 000000529C48: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000529C4C: 0202B6FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000529C54: BF870112
	.long 0xd72c0059                                           // 000000529C58: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000529C5C: 0202B2FF 83DCD12D
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000529C64: D622005B 03FD015B 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000529C70: BF870112
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000529C74: D6220059 03FD0159 00006400
	v_and_b32_e32 v91, 0xffff, v91                             // 000000529C80: 36B6B6FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000529C88: BF870232
	v_and_or_b32 v89, 0xffff, v89, v94                         // 000000529C8C: D6570059 057AB2FF 0000FFFF
	v_and_b32_e32 v94, 0xffff, v96                             // 000000529C98: 36BCC0FF 0000FFFF
	v_bfe_u32 v96, v85, 4, 16                                  // 000000529CA0: D6100060 02410955
	v_lshl_or_b32 v91, v95, 16, v91                            // 000000529CA8: D656005B 056D215F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000529CB0: BF870114
	v_pk_fma_f16 v89, v89, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000529CB4: CC0E0059 0BFC0F59 0000C931
	v_pk_fma_f16 v91, v91, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000529CC0: CC0E005B 0BFC0F5B 0000C931
	v_and_b32_e32 v99, 0xffff, v100                            // 000000529CCC: 36C6C8FF 0000FFFF
	v_sad_u8 v100, v101, 0, 0x6400                             // 000000529CD4: D6220064 03FD0165 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000529CE0: BF8701A3
	v_dot2acc_f32_f16 v48, v91, v5                             // 000000529CE4: 04600B5B
	v_dot2acc_f32_f16 v49, v91, v1                             // 000000529CE8: 0462035B
	v_lshl_or_b32 v97, v100, 16, v99                           // 000000529CEC: D6560061 058D2164
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000529CF4: BF870113
	v_dot2acc_f32_f16 v48, v89, v6                             // 000000529CF8: 04600D59
	v_pk_fma_f16 v93, v97, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000529CFC: CC0E005D 0BFC0F61 0000C931
	v_bfe_u32 v97, v88, 8, 16                                  // 000000529D08: D6100061 02411158
	v_dual_dot2acc_f32_f16 v43, v92, v6 :: v_dual_and_b32 v88, 0xffff, v88// 000000529D10: CB240D5C 2B58B0FF 0000FFFF
	.long 0xd72c005c                                           // 000000529D1C: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000529D20: 0202C4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000529D28: BF870214
	v_dot2acc_f32_f16 v45, v93, v3                             // 000000529D2C: 045A075D
	.long 0xd72c0061                                           // 000000529D30: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000529D34: 0202C2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000529D3C: BF870194
	.long 0xd72c0058                                           // 000000529D40: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000529D44: 0202B0FF 83DCD12D
	v_dot2acc_f32_f16 v45, v90, v4                             // 000000529D4C: 045A095A
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000529D50: D622005C 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000529D5C: BF870214
	v_sad_u8 v95, v97, 0, 0x6400                               // 000000529D60: D622005F 03FD0161 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000529D6C: D6220058 03FD0158 00006400
	v_dual_mov_b32 v97, v26 :: v_dual_mov_b32 v26, v65         // 000000529D78: CA10011A 611A0141
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000529D80: BF870193
	v_lshl_or_b32 v94, v95, 16, v94                            // 000000529D84: D656005E 0579215F
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000529D8C: 30B0B090
	v_bfe_u32 v95, v85, 8, 16                                  // 000000529D90: D610005F 02411155
	s_delay_alu instid0(VALU_DEP_2)                            // 000000529D98: BF870002
	v_and_or_b32 v87, 0xffff, v92, v88                         // 000000529D9C: D6570057 0562B8FF 0000FFFF
	v_bfe_u32 v92, v86, 12, 16                                 // 000000529DA8: D610005C 02411956
	v_pk_fma_f16 v88, v94, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000529DB0: CC0E0058 0BFC0F5E 0000C931
	v_bfe_u32 v94, v85, 12, 16                                 // 000000529DBC: D610005E 02411955
	v_dot2acc_f32_f16 v49, v89, v2                             // 000000529DC4: 04620559
	v_pk_fma_f16 v87, v87, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000529DC8: CC0E0057 0BFC0F57 0000C931
	.long 0xd72c005c                                           // 000000529DD4: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000529DD8: 0202B8FF 83DCD12D
	v_dot2acc_f32_f16 v48, v88, v7                             // 000000529DE0: 04600F58
	.long 0xd72c005e                                           // 000000529DE4: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000529DE8: 0202BCFF 83DCD12D
	.long 0xd72c005f                                           // 000000529DF0: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000529DF4: 0202BEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000529DFC: BF870253
	v_dot2acc_f32_f16 v48, v87, v8                             // 000000529E00: 04601157
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000529E04: D622005C 03FD015C 00006400
	v_dot2acc_f32_f16 v43, v93, v7                             // 000000529E10: 04560F5D
	v_bfe_u32 v93, v86, 8, 16                                  // 000000529E14: D610005D 02411156
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000529E1C: D622005E 03FD015E 00006400
	v_dual_dot2acc_f32_f16 v49, v88, v3 :: v_dual_and_b32 v92, 0xffff, v92// 000000529E28: CB240758 315CB8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000529E34: BF870244
	v_dual_dot2acc_f32_f16 v43, v90, v8 :: v_dual_and_b32 v90, 0xffff, v86// 000000529E38: CB24115A 2B5AACFF 0000FFFF
	v_bfe_u32 v86, v86, 4, 16                                  // 000000529E44: D6100056 02410956
	.long 0xd72c005d                                           // 000000529E4C: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000529E50: 0202BAFF 83DCD12D
	v_bfe_u32 v88, v82, 12, 16                                 // 000000529E58: D6100058 02411952
	.long 0xd72c005a                                           // 000000529E60: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000529E64: 0202B4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000529E6C: BF870214
	.long 0xd72c0056                                           // 000000529E70: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000529E74: 0202ACFF 83DCD12D
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000529E7C: D622005D 03FD015D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000529E88: BF870193
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000529E8C: D622005A 03FD015A 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000529E98: D6220056 03FD0156 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000529EA4: BF870223
	v_lshl_or_b32 v91, v93, 16, v92                            // 000000529EA8: D656005B 0571215D
	v_dual_dot2acc_f32_f16 v49, v87, v4 :: v_dual_and_b32 v92, 0xffff, v94// 000000529EB0: CB240957 315CBCFF 0000FFFF
	v_lshlrev_b32_e32 v90, 16, v90                             // 000000529EBC: 30B4B490
	.long 0xd72c0057                                           // 000000529EC0: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000529EC4: 0202B0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000529ECC: BF870004
	v_pk_fma_f16 v89, v91, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000529ED0: CC0E0059 0BFC0F5B 0000C931
	v_bfe_u32 v88, v82, 8, 16                                  // 000000529EDC: D6100058 02411152
	v_sad_u8 v93, v95, 0, 0x6400                               // 000000529EE4: D622005D 03FD015F 00006400
	v_and_or_b32 v86, 0xffff, v86, v90                         // 000000529EF0: D6570056 056AACFF 0000FFFF
	.long 0xd72c005a                                           // 000000529EFC: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000529F00: 0202C0FF 83DCD12D
	v_dot2acc_f32_f16 v40, v89, v1                             // 000000529F08: 04500359
	.long 0xd72c0058                                           // 000000529F0C: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000529F10: 0202B0FF 83DCD12D
	v_lshl_or_b32 v91, v93, 16, v92                            // 000000529F18: D656005B 0571215D
	v_pk_fma_f16 v86, v86, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000529F20: CC0E0056 0BFC0F56 0000C931
	v_and_b32_e32 v85, 0xffff, v85                             // 000000529F2C: 36AAAAFF 0000FFFF
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000529F34: D6220057 03FD0157 00006400
	v_dot2acc_f32_f16 v47, v89, v5                             // 000000529F40: 045E0B59
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000529F44: D622005A 03FD015A 00006400
	v_dot2acc_f32_f16 v40, v86, v2                             // 000000529F50: 04500556
	.long 0xd72c0055                                           // 000000529F54: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000529F58: 0202AAFF 83DCD12D
	v_pk_fma_f16 v84, v91, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000529F60: CC0E0054 0BFC0F5B 0000C931
	v_and_b32_e32 v87, 0xffff, v87                             // 000000529F6C: 36AEAEFF 0000FFFF
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000529F74: D6220058 03FD0158 00006400
	v_bfe_u32 v91, v73, 8, 16                                  // 000000529F80: D610005B 02411149
	v_bfe_u32 v92, v73, 4, 16                                  // 000000529F88: D610005C 02410949
	v_dot2acc_f32_f16 v40, v84, v3                             // 000000529F90: 04500754
	v_mov_b32_e32 v94, v32                                     // 000000529F94: 7EBC0320
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000529F98: D6220055 03FD0155 00006400
	v_lshl_or_b32 v87, v88, 16, v87                            // 000000529FA4: D6560057 055D2158
	.long 0xd72c005b                                           // 000000529FAC: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000529FB0: 0202B6FF 83DCD12D
	v_dual_mov_b32 v96, v20 :: v_dual_mov_b32 v95, v35         // 000000529FB8: CA100114 605E0123
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000529FC0: BF8701C4
	v_dual_mov_b32 v32, v65 :: v_dual_lshlrev_b32 v85, 16, v85 // 000000529FC4: CA220141 2054AA90
	s_waitcnt vmcnt(6)                                         // 000000529FCC: BF891BF7
	v_dual_mov_b32 v20, v71 :: v_dual_mov_b32 v35, v66         // 000000529FD0: CA100147 14220142
	v_mov_b32_e32 v93, v24                                     // 000000529FD8: 7EBA0318
	v_and_or_b32 v85, 0xffff, v90, v85                         // 000000529FDC: D6570055 0556B4FF 0000FFFF
	v_bfe_u32 v90, v73, 12, 16                                 // 000000529FE8: D610005A 02411949
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000529FF0: D622005B 03FD015B 00006400
	v_mov_b32_e32 v24, v64                                     // 000000529FFC: 7E300340
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000052A000: BF870254
	v_pk_fma_f16 v85, v85, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000052A004: CC0E0055 0BFC0F55 0000C931
	v_dot2acc_f32_f16 v47, v86, v6                             // 00000052A010: 045E0D56
	v_pk_fma_f16 v86, v87, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000052A014: CC0E0056 0BFC0F57 0000C931
	v_and_b32_e32 v89, 0xffff, v82                             // 00000052A020: 36B2A4FF 0000FFFF
	v_bfe_u32 v82, v82, 4, 16                                  // 00000052A028: D6100052 02410952
	v_dual_dot2acc_f32_f16 v40, v85, v4 :: v_dual_dot2acc_f32_f16 v47, v84, v7// 00000052A030: CB180955 282E0F54
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000052A038: BF870214
	v_dot2acc_f32_f16 v46, v86, v1                             // 00000052A03C: 045C0356
	.long 0xd72c0059                                           // 00000052A040: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 00000052A044: 0202B2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000052A04C: BF870004
	.long 0xd72c0052                                           // 00000052A050: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000052A054: 0202A4FF 83DCD12D
	.long 0xd72c005a                                           // 00000052A05C: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 00000052A060: 0202B4FF 83DCD12D
	v_dual_dot2acc_f32_f16 v44, v86, v5 :: v_dual_dot2acc_f32_f16 v47, v85, v8// 00000052A068: CB180B56 2C2E1155
	v_bfe_u32 v84, v74, 12, 16                                 // 00000052A070: D6100054 0241194A
	v_bfe_u32 v85, v74, 8, 16                                  // 00000052A078: D6100055 0241114A
	v_sad_u8 v89, v89, 0, 0x6400                               // 00000052A080: D6220059 03FD0159 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 00000052A08C: D6220052 03FD0152 00006400
	v_sad_u8 v90, v90, 0, 0x6400                               // 00000052A098: D622005A 03FD015A 00006400
	.long 0xd72c0054                                           // 00000052A0A4: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 00000052A0A8: 0202A8FF 83DCD12D
	.long 0xd72c0055                                           // 00000052A0B0: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 00000052A0B4: 0202AAFF 83DCD12D
	v_lshlrev_b32_e32 v88, 16, v89                             // 00000052A0BC: 30B0B290
	.long 0xd72c0059                                           // 00000052A0C0: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 00000052A0C4: 0202B8FF 83DCD12D
	v_and_b32_e32 v90, 0xffff, v90                             // 00000052A0CC: 36B4B4FF 0000FFFF
	s_waitcnt vmcnt(5)                                         // 00000052A0D4: BF8917F7
	v_dual_mov_b32 v92, v19 :: v_dual_mov_b32 v19, v70         // 00000052A0D8: CA100113 5C120146
	v_and_or_b32 v82, 0xffff, v82, v88                         // 00000052A0E0: D6570052 0562A4FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 00000052A0EC: D6220054 03FD0154 00006400
	v_lshl_or_b32 v87, v91, 16, v90                            // 00000052A0F8: D6560057 0569215B
	v_sad_u8 v85, v85, 0, 0x6400                               // 00000052A100: D6220055 03FD0155 00006400
	v_sad_u8 v88, v89, 0, 0x6400                               // 00000052A10C: D6220058 03FD0159 00006400
	v_pk_fma_f16 v82, v82, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000052A118: CC0E0052 0BFC0F52 0000C931
	v_and_b32_e32 v73, 0xffff, v73                             // 00000052A124: 369292FF 0000FFFF
	v_pk_fma_f16 v86, v87, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000052A12C: CC0E0056 0BFC0F57 0000C931
	v_bfe_u32 v87, v58, 4, 16                                  // 00000052A138: D6100057 0241093A
	v_mov_b32_e32 v90, v23                                     // 00000052A140: 7EB40317
	v_dot2acc_f32_f16 v46, v82, v2                             // 00000052A144: 045C0552
	.long 0xd72c0049                                           // 00000052A148: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 00000052A14C: 020292FF 83DCD12D
	v_dot2acc_f32_f16 v44, v82, v6                             // 00000052A154: 04580D52
	v_bfe_u32 v82, v75, 12, 16                                 // 00000052A158: D6100052 0241194B
	v_mov_b32_e32 v89, v18                                     // 00000052A160: 7EB20312
	v_dual_dot2acc_f32_f16 v46, v86, v3 :: v_dual_mov_b32 v91, v31// 00000052A164: CB100756 2E5A011F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000052A16C: BF870214
	v_dot2acc_f32_f16 v44, v86, v7                             // 00000052A170: 04580F56
	.long 0xd72c0052                                           // 00000052A174: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000052A178: 0202A4FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 00000052A180: D6220049 03FD0149 00006400
	s_waitcnt vmcnt(4)                                         // 00000052A18C: BF8913F7
	v_dual_mov_b32 v23, v63 :: v_dual_mov_b32 v18, v69         // 00000052A190: CA10013F 17120145
	v_mov_b32_e32 v31, v64                                     // 00000052A198: 7E3E0340
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000052A19C: BF870123
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000052A1A0: 30929290
	v_sad_u8 v82, v82, 0, 0x6400                               // 00000052A1A4: D6220052 03FD0152 00006400
	v_and_or_b32 v73, 0xffff, v88, v73                         // 00000052A1B0: D6570049 0526B0FF 0000FFFF
	v_mov_b32_e32 v88, v30                                     // 00000052A1BC: 7EB0031E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000052A1C0: BF870223
	v_and_b32_e32 v82, 0xffff, v82                             // 00000052A1C4: 36A4A4FF 0000FFFF
	v_mov_b32_e32 v30, v63                                     // 00000052A1CC: 7E3C033F
	v_pk_fma_f16 v73, v73, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000052A1D0: CC0E0049 0BFC0F49 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000052A1DC: BF870141
	v_dot2acc_f32_f16 v46, v73, v4                             // 00000052A1E0: 045C0949
	v_dot2acc_f32_f16 v44, v73, v8                             // 00000052A1E4: 04581149
	v_bfe_u32 v73, v75, 8, 16                                  // 00000052A1E8: D6100049 0241114B
	v_and_b32_e32 v75, 0xffff, v75                             // 00000052A1F0: 369696FF 0000FFFF
	.long 0xd72c0049                                           // 00000052A1F8: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 00000052A1FC: 020292FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000052A204: BF870112
	.long 0xd72c004b                                           // 00000052A208: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000052A20C: 020296FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 00000052A214: D6220049 03FD0149 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000052A220: BF870112
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000052A224: D622004B 03FD014B 00006400
	v_lshl_or_b32 v73, v73, 16, v82                            // 00000052A230: D6560049 05492149
	v_sad_u8 v82, v83, 0, 0x6400                               // 00000052A238: D6220052 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000052A244: BF870193
	v_lshlrev_b32_e32 v75, 16, v75                             // 00000052A248: 30969690
	v_pk_fma_f16 v73, v73, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000052A24C: CC0E0049 0BFC0F49 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000052A258: BF8701A2
	v_and_or_b32 v75, 0xffff, v82, v75                         // 00000052A25C: D657004B 052EA4FF 0000FFFF
	v_bfe_u32 v82, v59, 12, 16                                 // 00000052A268: D6100052 0241193B
	v_dot2acc_f32_f16 v41, v73, v5                             // 00000052A270: 04520B49
	v_dot2acc_f32_f16 v42, v73, v1                             // 00000052A274: 04540349
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000052A278: BF8701B4
	v_pk_fma_f16 v75, v75, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000052A27C: CC0E004B 0BFC0F4B 0000C931
	v_and_b32_e32 v84, 0xffff, v84                             // 00000052A288: 36A8A8FF 0000FFFF
	.long 0xd72c0052                                           // 00000052A290: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000052A294: 0202A4FF 83DCD12D
	v_dot2acc_f32_f16 v41, v75, v6                             // 00000052A29C: 04520D4B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000052A2A0: BF870003
	v_lshl_or_b32 v60, v85, 16, v84                            // 00000052A2A4: D656003C 05512155
	v_bfe_u32 v84, v59, 8, 16                                  // 00000052A2AC: D6100054 0241113B
	v_dot2acc_f32_f16 v42, v75, v2                             // 00000052A2B4: 0454054B
	v_bfe_u32 v85, v58, 12, 16                                 // 00000052A2B8: D6100055 0241193A
	v_sad_u8 v82, v82, 0, 0x6400                               // 00000052A2C0: D6220052 03FD0152 00006400
	v_pk_fma_f16 v60, v60, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000052A2CC: CC0E003C 0BFC0F3C 0000C931
	v_and_b32_e32 v86, 0xffff, v74                             // 00000052A2D8: 36AC94FF 0000FFFF
	v_bfe_u32 v74, v74, 4, 16                                  // 00000052A2E0: D610004A 0241094A
	.long 0xd72c0054                                           // 00000052A2E8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 00000052A2EC: 0202A8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000052A2F4: BF870214
	v_dual_dot2acc_f32_f16 v41, v60, v7 :: v_dual_and_b32 v82, 0xffff, v82// 00000052A2F8: CB240F3C 2952A4FF 0000FFFF
	.long 0xd72c0056                                           // 00000052A304: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 00000052A308: 0202ACFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000052A310: BF870004
	.long 0xd72c004a                                           // 00000052A314: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 00000052A318: 020294FF 83DCD12D
	.long 0xd72c0055                                           // 00000052A320: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 00000052A324: 0202AAFF 83DCD12D
	v_mov_b32_e32 v75, v81                                     // 00000052A32C: 7E960351
	v_sad_u8 v84, v84, 0, 0x6400                               // 00000052A330: D6220054 03FD0154 00006400
	v_sad_u8 v83, v86, 0, 0x6400                               // 00000052A33C: D6220053 03FD0156 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000052A348: D622004A 03FD014A 00006400
	v_bfe_u32 v86, v58, 8, 16                                  // 00000052A354: D6100056 0241113A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000052A35C: BF870234
	v_lshl_or_b32 v82, v84, 16, v82                            // 00000052A360: D6560052 05492154
	v_sad_u8 v85, v85, 0, 0x6400                               // 00000052A368: D6220055 03FD0155 00006400
	v_lshlrev_b32_e32 v83, 16, v83                             // 00000052A374: 30A6A690
	.long 0xd72c0056                                           // 00000052A378: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 00000052A37C: 0202ACFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000052A384: BF870214
	v_pk_fma_f16 v73, v82, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000052A388: CC0E0049 0BFC0F52 0000C931
	v_and_b32_e32 v84, 0xffff, v85                             // 00000052A394: 36A8AAFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000052A39C: BF870004
	v_and_or_b32 v74, 0xffff, v74, v83                         // 00000052A3A0: D657004A 054E94FF 0000FFFF
	v_and_b32_e32 v83, 0xffff, v59                             // 00000052A3AC: 36A676FF 0000FFFF
	v_bfe_u32 v59, v59, 4, 16                                  // 00000052A3B4: D610003B 0241093B
	v_dot2acc_f32_f16 v38, v73, v5                             // 00000052A3BC: 044C0B49
	v_dot2acc_f32_f16 v39, v73, v1                             // 00000052A3C0: 044E0349
	v_pk_fma_f16 v74, v74, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000052A3C4: CC0E004A 0BFC0F4A 0000C931
	.long 0xd72c0053                                           // 00000052A3D0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 00000052A3D4: 0202A6FF 83DCD12D
	.long 0xd72c003b                                           // 00000052A3DC: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 00000052A3E0: 020276FF 83DCD12D
	v_and_b32_e32 v58, 0xffff, v58                             // 00000052A3E8: 367474FF 0000FFFF
	v_sad_u8 v85, v86, 0, 0x6400                               // 00000052A3F0: D6220055 03FD0156 00006400
	v_dot2acc_f32_f16 v41, v74, v8                             // 00000052A3FC: 0452114A
	v_mov_b32_e32 v73, v25                                     // 00000052A400: 7E920319
	v_mov_b32_e32 v86, v17                                     // 00000052A404: 7EAC0311
	.long 0xd72c003a                                           // 00000052A408: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 00000052A40C: 020274FF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 00000052A414: D6220053 03FD0153 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000052A420: D622003B 03FD013B 00006400
	v_lshl_or_b32 v82, v85, 16, v84                            // 00000052A42C: D6560052 05512155
	v_dual_mov_b32 v85, v27 :: v_dual_mov_b32 v84, v21         // 00000052A434: CA10011B 55540115
	s_delay_alu instid0(VALU_DEP_4)                            // 00000052A43C: BF870004
	v_lshlrev_b32_e32 v83, 16, v83                             // 00000052A440: 30A6A690
	v_mov_b32_e32 v25, v61                                     // 00000052A444: 7E32033D
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000052A448: D622003A 03FD013A 00006400
	v_pk_fma_f16 v1, v82, s7, 0xc931 op_sel_hi:[1,0,0]         // 00000052A454: CC0E0001 0BFC0F52 0000C931
	v_mov_b32_e32 v82, v16                                     // 00000052A460: 7EA40310
	v_and_or_b32 v59, 0xffff, v59, v83                         // 00000052A464: D657003B 054E76FF 0000FFFF
	.long 0xd72c0053                                           // 00000052A470: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 00000052A474: 0202AEFF 83DCD12D
	v_dual_mov_b32 v87, v22 :: v_dual_lshlrev_b32 v58, 16, v58 // 00000052A47C: CA220116 573A7490
	v_mov_b32_e32 v21, v61                                     // 00000052A484: 7E2A033D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000052A488: BF870004
	v_pk_fma_f16 v59, v59, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000052A48C: CC0E003B 0BFC0F3B 0000C931
	v_dot2acc_f32_f16 v42, v60, v3                             // 00000052A498: 0454073C
	s_waitcnt vmcnt(2)                                         // 00000052A49C: BF890BF7
	v_dual_mov_b32 v16, v67 :: v_dual_mov_b32 v27, v62         // 00000052A4A0: CA100143 101A013E
	v_sad_u8 v83, v83, 0, 0x6400                               // 00000052A4A8: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v39, v59, v2                             // 00000052A4B4: 044E053B
	v_dot2acc_f32_f16 v38, v59, v6                             // 00000052A4B8: 044C0D3B
	v_dot2acc_f32_f16 v42, v74, v4                             // 00000052A4BC: 0454094A
	v_mov_b32_e32 v22, v62                                     // 00000052A4C0: 7E2C033E
	v_and_or_b32 v5, 0xffff, v83, v58                          // 00000052A4C4: D6570005 04EAA6FF 0000FFFF
	v_dot2acc_f32_f16 v39, v1, v3                              // 00000052A4D0: 044E0701
	v_dual_dot2acc_f32_f16 v38, v1, v7 :: v_dual_add_nc_u32 v1, v54, v9// 00000052A4D4: CB200F01 26001336
	v_mov_b32_e32 v3, v28                                      // 00000052A4DC: 7E06031C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000052A4E0: BF870224
	v_pk_fma_f16 v2, v5, s7, 0xc931 op_sel_hi:[1,0,0]          // 00000052A4E4: CC0E0002 0BFC0F05 0000C931
	v_dual_mov_b32 v17, v68 :: v_dual_mov_b32 v28, v66         // 00000052A4F0: CA100144 111C0142
	v_cmp_eq_u32_e32 vcc_lo, 2, v1                             // 00000052A4F8: 7C940282
	v_mov_b32_e32 v83, v80                                     // 00000052A4FC: 7EA60350
	s_delay_alu instid0(VALU_DEP_4)                            // 00000052A500: BF870004
	v_dot2acc_f32_f16 v39, v2, v4                              // 00000052A504: 044E0902
	v_dot2acc_f32_f16 v38, v2, v8                              // 00000052A508: 044C1102
	v_dual_mov_b32 v2, v15 :: v_dual_mov_b32 v15, v72          // 00000052A50C: CA10010F 020E0148
	v_dual_mov_b32 v74, v79 :: v_dual_mov_b32 v59, v78         // 00000052A514: CA10014F 4A3A014E
	v_mov_b32_e32 v60, v77                                     // 00000052A51C: 7E78034D
	v_mov_b32_e32 v58, v76                                     // 00000052A520: 7E74034C
	s_or_b32 s6, vcc_lo, s6                                    // 00000052A524: 8C06066A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000052A528: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000052A52C: 917E067E
	s_cbranch_execz 68                                         // 00000052A530: BFA50044 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c44>
	s_waitcnt vmcnt(1)                                         // 00000052A534: BF8907F7
	v_dual_mov_b32 v81, v10 :: v_dual_mov_b32 v80, v37         // 00000052A538: CA10010A 51500125
	s_waitcnt vmcnt(0)                                         // 00000052A540: BF8903F7
	v_dual_mov_b32 v79, v34 :: v_dual_mov_b32 v78, v29         // 00000052A544: CA100122 4F4E011D
	s_waitcnt vmcnt(0)                                         // 00000052A54C: BF8903F7
	v_dual_mov_b32 v77, v36 :: v_dual_mov_b32 v76, v33         // 00000052A550: CA100124 4D4C0121
	s_mov_b32 s8, exec_lo                                      // 00000052A558: BE88007E
	.long 0xd4c1007e                                           // 00000052A55C: D4C1007E
	v_cndmask_b32_e32 v1, v9, v14, vcc_lo                      // 00000052A560: 02021D09
	s_cbranch_execz 64587                                      // 00000052A564: BFA5FC4B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc94>
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000052A568: 3414129F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052A56C: BF870091
	.long 0xd73c0004                                           // 00000052A570: D73C0004
	v_cndmask_b32_e32 v1, 10, v9, vcc_lo                       // 00000052A574: 0202128A
	.long 0xd7006a01                                           // 00000052A578: D7006A01
	v_cndmask_b32_e32 v1, s1, v4, vcc_lo                       // 00000052A57C: 02020801
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000052A580: BF870111
	v_add_co_ci_u32_e64 v7, null, s5, v5, vcc_lo               // 00000052A584: D5207C07 01AA0A05
	.long 0xd7006a04                                           // 00000052A58C: D7006A04
	v_cndmask_b32_e32 v1, v1, v55, vcc_lo                      // 00000052A590: 02026F01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000052A594: BF8700A1
	v_add_co_ci_u32_e64 v5, null, 0, v7, vcc_lo                // 00000052A598: D5207C05 01AA0E80
	.long 0xd7006a06                                           // 00000052A5A0: D7006A06
	v_cndmask_b32_e32 v1, v1, v57, vcc_lo                      // 00000052A5A4: 02027301
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 00000052A5A8: D5207C07 01AA0E80
	s_clause 0xf                                               // 00000052A5B0: BF85000F
	global_load_b32 v66, v[4:5], off                           // 00000052A5B4: DC520000 427C0004
	global_load_b32 v65, v[4:5], off offset:128                // 00000052A5BC: DC520080 417C0004
	global_load_b32 v64, v[4:5], off offset:256                // 00000052A5C4: DC520100 407C0004
	global_load_b32 v63, v[4:5], off offset:384                // 00000052A5CC: DC520180 3F7C0004
	global_load_b32 v62, v[4:5], off offset:512                // 00000052A5D4: DC520200 3E7C0004
	global_load_b32 v61, v[4:5], off offset:640                // 00000052A5DC: DC520280 3D7C0004
	global_load_b32 v34, v[4:5], off offset:768                // 00000052A5E4: DC520300 227C0004
	global_load_b32 v33, v[4:5], off offset:896                // 00000052A5EC: DC520380 217C0004
	global_load_b32 v72, v[6:7], off                           // 00000052A5F4: DC520000 487C0006
	global_load_b32 v71, v[6:7], off offset:128                // 00000052A5FC: DC520080 477C0006
	global_load_b32 v70, v[6:7], off offset:256                // 00000052A604: DC520100 467C0006
	global_load_b32 v69, v[6:7], off offset:384                // 00000052A60C: DC520180 457C0006
	global_load_b32 v68, v[6:7], off offset:512                // 00000052A614: DC520200 447C0006
	global_load_b32 v67, v[6:7], off offset:640                // 00000052A61C: DC520280 437C0006
	global_load_b32 v10, v[6:7], off offset:768                // 00000052A624: DC520300 0A7C0006
	global_load_b32 v29, v[6:7], off offset:896                // 00000052A62C: DC520380 1D7C0006
	s_waitcnt vmcnt(8)                                         // 00000052A634: BF8923F7
	v_dual_mov_b32 v37, v34 :: v_dual_mov_b32 v36, v33         // 00000052A638: CA100122 25240121
	s_branch 64532                                             // 00000052A640: BFA0FC14 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc94>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000052A644: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000052A648: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 00000052A64C: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 00000052A650: BF895FF7
	v_dual_mov_b32 v1, v53 :: v_dual_mov_b32 v2, v50           // 00000052A654: CA100135 01020132
	s_waitcnt vmcnt(15)                                        // 00000052A65C: BF893FF7
	v_dual_mov_b32 v3, v52 :: v_dual_mov_b32 v6, v51           // 00000052A660: CA100134 03060133
	v_dual_mov_b32 v4, v45 :: v_dual_mov_b32 v5, v43           // 00000052A668: CA10012D 0404012B
	v_dual_mov_b32 v8, v49 :: v_dual_mov_b32 v9, v48           // 00000052A670: CA100131 08080130
	s_waitcnt vmcnt(1)                                         // 00000052A678: BF8907F7
	v_dual_mov_b32 v7, v40 :: v_dual_mov_b32 v10, v47          // 00000052A67C: CA100128 070A012F
	v_dual_mov_b32 v14, v46 :: v_dual_mov_b32 v15, v44         // 00000052A684: CA10012E 0E0E012C
	v_dual_mov_b32 v16, v42 :: v_dual_mov_b32 v17, v41         // 00000052A68C: CA10012A 10100129
	v_dual_mov_b32 v18, v39 :: v_dual_mov_b32 v19, v38         // 00000052A694: CA100127 12120126
	s_mov_b32 s0, 0x76543210                                   // 00000052A69C: BE8000FF 76543210
	s_waitcnt vmcnt(0)                                         // 00000052A6A4: BF8903F7
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 00000052A6A8: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000052A6B4: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 00000052A6C0: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 00000052A6CC: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 00000052A6D8: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 00000052A6E4: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 00000052A6F0: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 00000052A6FC: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 00000052A708: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 00000052A714: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 00000052A720: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 00000052A72C: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 00000052A738: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 00000052A744: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 00000052A750: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 00000052A75C: D65C0013 03FC0113 FEDCBA98
	.long 0xd44c0000                                           // 00000052A768: D44C0000
	v_cndmask_b32_e32 v1, 16, v13, vcc_lo                      // 00000052A76C: 02021A90
	s_barrier                                                  // 00000052A770: BFBD0000
	buffer_gl0_inv                                             // 00000052A774: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000052A77C: BE812000
	s_cbranch_execz 34                                         // 00000052A780: BFA50022 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e0c>
	v_dual_add_f32 v8, v49, v8 :: v_dual_add_f32 v3, v52, v3   // 00000052A784: C9081131 08020734
	v_dual_add_f32 v6, v51, v6 :: v_dual_add_f32 v1, v53, v1   // 00000052A78C: C9080D33 06000335
	v_lshl_or_b32 v12, v11, 10, v12                            // 00000052A794: D656000C 0431150B
	v_dual_add_f32 v2, v50, v2 :: v_dual_add_f32 v5, v43, v5   // 00000052A79C: C9080532 02040B2B
	v_dual_add_f32 v4, v45, v4 :: v_dual_add_f32 v7, v40, v7   // 00000052A7A4: C908092D 04060F28
	v_dual_add_f32 v10, v47, v10 :: v_dual_add_f32 v9, v48, v9 // 00000052A7AC: C908152F 0A081330
	v_dual_add_f32 v15, v44, v15 :: v_dual_add_f32 v14, v46, v14// 00000052A7B4: C9081F2C 0F0E1D2E
	v_dual_add_f32 v13, v38, v19 :: v_dual_add_f32 v18, v39, v18// 00000052A7BC: C9082726 0D122527
	v_dual_add_f32 v17, v41, v17 :: v_dual_add_f32 v16, v42, v16// 00000052A7C4: C9082329 1110212A
	ds_store_2addr_b32 v12, v1, v3 offset1:16                  // 00000052A7CC: D8381000 0003010C
	ds_store_2addr_b32 v12, v2, v6 offset0:128 offset1:144     // 00000052A7D4: D8389080 0006020C
	ds_store_2addr_b32 v12, v4, v8 offset0:32 offset1:48       // 00000052A7DC: D8383020 0008040C
	ds_store_2addr_b32 v12, v5, v9 offset0:160 offset1:176     // 00000052A7E4: D838B0A0 0009050C
	ds_store_2addr_b32 v12, v7, v14 offset0:64 offset1:80      // 00000052A7EC: D8385040 000E070C
	ds_store_2addr_b32 v12, v10, v15 offset0:192 offset1:208   // 00000052A7F4: D838D0C0 000F0A0C
	ds_store_2addr_b32 v12, v16, v18 offset0:96 offset1:112    // 00000052A7FC: D8387060 0012100C
	ds_store_2addr_b32 v12, v17, v13 offset0:224 offset1:240   // 00000052A804: D838F0E0 000D110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000052A80C: 8C7E017E
	.long 0xd44c0001                                           // 00000052A810: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 00000052A814: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 00000052A81C: BF89FC07
	s_barrier                                                  // 00000052A820: BFBD0000
	buffer_gl0_inv                                             // 00000052A824: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 00000052A82C: BE852001
	s_cbranch_execnz 9                                         // 00000052A830: BFA60009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e58>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000052A834: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 00000052A838: BF048221
	s_mov_b32 s5, -1                                           // 00000052A83C: BE8500C1
	s_cbranch_scc0 35                                          // 00000052A840: BFA10023 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ed0>
	s_and_b32 vcc_lo, exec_lo, s5                              // 00000052A844: 8B6A057E
	s_cbranch_vccnz 193                                        // 00000052A848: BFA400C1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2150>
	s_nop 0                                                    // 00000052A84C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000052A850: BFB60003
	s_endpgm                                                   // 00000052A854: BFB00000
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000052A858: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 00000052A85C: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 00000052A864: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 00000052A86C: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 00000052A874: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 00000052A878: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000052A87C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 00000052A880: 06020501
	s_waitcnt lgkmcnt(1)                                       // 00000052A884: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 00000052A888: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 00000052A88C: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 00000052A894: 06060903
	s_waitcnt lgkmcnt(1)                                       // 00000052A898: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052A89C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 00000052A8A0: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 00000052A8A4: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 00000052A8A8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052A8AC: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 00000052A8B0: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 00000052A8B4: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 00000052A8B8: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 00000052A8C0: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 00000052A8C4: BF048221
	s_mov_b32 s5, -1                                           // 00000052A8C8: BE8500C1
	s_cbranch_scc1 65501                                       // 00000052A8CC: BFA2FFDD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e44>
	s_waitcnt lgkmcnt(0)                                       // 00000052A8D0: BF89FC07
	s_barrier                                                  // 00000052A8D4: BFBD0000
	buffer_gl0_inv                                             // 00000052A8D8: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 00000052A8E0: BE852001
	s_cbranch_execz 41                                         // 00000052A8E4: BFA50029 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f8c>
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000052A8E8: 32020087
	s_ashr_i32 s6, s18, 31                                     // 00000052A8EC: 86069F12
	v_lshlrev_b32_e32 v4, 2, v0                                // 00000052A8F0: 30080082
	s_delay_alu instid0(VALU_DEP_2)                            // 00000052A8F4: BF870002
	v_lshl_or_b32 v1, s4, 1, v1                                // 00000052A8F8: D6560001 04050204
	s_ashr_i32 s4, s4, 31                                      // 00000052A900: 86049F04
	ds_load_b32 v4, v4 offset:8192                             // 00000052A904: D8D82000 04000004
	s_mul_i32 s4, s4, s18                                      // 00000052A90C: 96041204
	.long 0xd72c0003                                           // 00000052A910: D72C0003
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 00000052A914: 02000D01
	v_mad_u64_u32 v[1:2], null, v1, s18, 0                     // 00000052A918: D6FE7C01 02002501
	s_lshl_b32 s6, s2, 7                                       // 00000052A920: 84068702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000052A924: BF870499
	s_ashr_i32 s7, s6, 31                                      // 00000052A928: 86079F06
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000052A92C: 84868206
	v_add3_u32 v2, v2, v3, s4                                  // 00000052A930: D6550002 00120702
	v_and_b32_e32 v3, 0x7f, v0                                 // 00000052A938: 360600FF 0000007F
	s_add_u32 s4, s24, s6                                      // 00000052A940: 80040618
	s_addc_u32 s6, s25, s7                                     // 00000052A944: 82060719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000052A948: BF870112
	.long 0xd73c0001                                           // 00000052A94C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000052A950: 02020282
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000052A954: 30060682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052A958: BF870092
	.long 0xd7006a01                                           // 00000052A95C: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000052A960: 02020204
	v_add_co_ci_u32_e64 v2, null, s6, v2, vcc_lo               // 00000052A964: D5207C02 01AA0406
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052A96C: BF870092
	.long 0xd7006a01                                           // 00000052A970: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000052A974: 02020701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000052A978: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 00000052A980: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 00000052A984: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s5                              // 00000052A98C: 8C7E057E
	.long 0xd44a0004                                           // 00000052A990: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000052A994: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 00000052A998: BC7C0000
	buffer_gl1_inv                                             // 00000052A99C: E0B00000 00000000
	buffer_gl0_inv                                             // 00000052A9A4: E0AC0000 00000000
	s_barrier                                                  // 00000052A9AC: BFBD0000
	buffer_gl0_inv                                             // 00000052A9B0: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 00000052A9B8: BE852004
	s_cbranch_execz 29                                         // 00000052A9BC: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2034>
	s_mov_b32 s7, exec_lo                                      // 00000052A9C0: BE87007E
	s_mov_b32 s6, exec_lo                                      // 00000052A9C4: BE86007E
	.long 0xd71f0001                                           // 00000052A9C8: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 00000052A9CC: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 00000052A9D0: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 00000052A9D4: 7D940280
	s_cbranch_execz 9                                          // 00000052A9D8: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2000>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 00000052A9DC: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000052A9E0: BF8704B9
	s_add_u32 s8, s26, s8                                      // 00000052A9E4: 8008081A
	s_addc_u32 s9, s27, s9                                     // 00000052A9E8: 8209091B
	s_bcnt1_i32_b32 s7, s7                                     // 00000052A9EC: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 00000052A9F0: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 00000052A9F8: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 00000052AA00: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 00000052AA04: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 00000052AA08: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 00000052AA0C: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 00000052AA10: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 00000052AA18: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000052AA1C: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 00000052AA20: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 00000052AA24: D5010001 01A90280
	ds_store_b32 v2, v1 offset:10240                           // 00000052AA2C: D8342800 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 00000052AA34: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 00000052AA38: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 00000052AA3C: BF89FC07
	s_barrier                                                  // 00000052AA40: BFBD0000
	buffer_gl0_inv                                             // 00000052AA44: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:10240                            // 00000052AA4C: D8D82800 01000001
	s_waitcnt lgkmcnt(0)                                       // 00000052AA54: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000052AA58: 7C940280
	s_cbranch_vccnz 59                                         // 00000052AA5C: BFA4003B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x214c>
	buffer_gl1_inv                                             // 00000052AA60: E0B00000 00000000
	buffer_gl0_inv                                             // 00000052AA68: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 00000052AA70: BE852001
	s_cbranch_execz 41                                         // 00000052AA74: BFA50029 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x211c>
	v_and_b32_e32 v2, 0x7f, v0                                 // 00000052AA78: 360400FF 0000007F
	s_lshl_b32 s6, s2, 7                                       // 00000052AA80: 84068702
	s_ashr_i32 s1, s18, 31                                     // 00000052AA84: 86019F12
	s_ashr_i32 s7, s6, 31                                      // 00000052AA88: 86079F06
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000052AA8C: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 00000052AA90: CA220080 02020482
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000052AA98: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000052AA9C: BF8700A9
	s_add_u32 s6, s24, s6                                      // 00000052AAA0: 80060618
	s_addc_u32 s7, s25, s7                                     // 00000052AAA4: 82070719
	.long 0xd7000603                                           // 00000052AAA8: D7000603
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 00000052AAAC: 02020606
	s_delay_alu instid0(VALU_DEP_1)                            // 00000052AAB0: BF870001
	v_add_co_ci_u32_e64 v4, null, s7, 0, s6                    // 00000052AAB4: D5207C04 00190007
	s_nop 0                                                    // 00000052AABC: BF800000
	v_mad_u64_u32 v[5:6], null, v1, s18, 0                     // 00000052AAC0: D6FE7C05 02002501
	s_add_i32 s33, s33, -1                                     // 00000052AAC8: 8121C121
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000052AACC: BF870139
	s_cmp_eq_u32 s33, 0                                        // 00000052AAD0: BF068021
	v_mad_u64_u32 v[6:7], null, v1, s1, v[6:7]                 // 00000052AAD4: D6FE7C06 04180301
	v_add_nc_u32_e32 v1, 2, v1                                 // 00000052AADC: 4A020282
	.long 0xd73c0005                                           // 00000052AAE0: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000052AAE4: 02020A82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052AAE8: BF870091
	.long 0xd7006a05                                           // 00000052AAEC: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 00000052AAF0: 02020B03
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 00000052AAF4: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 00000052AAFC: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 00000052AB04: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 00000052AB08: 06040B02
	s_cbranch_scc0 65516                                       // 00000052AB0C: BFA1FFEC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x20c0>
	v_lshlrev_b32_e32 v1, 2, v0                                // 00000052AB10: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 00000052AB14: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s5                              // 00000052AB1C: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 00000052AB20: BE812004
	s_cbranch_execz 6                                          // 00000052AB24: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2140>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 00000052AB28: 84848202
	v_mov_b32_e32 v1, 0                                        // 00000052AB2C: 7E020280
	s_add_u32 s4, s26, s4                                      // 00000052AB30: 8004041A
	s_addc_u32 s5, s27, s5                                     // 00000052AB34: 8205051B
	global_store_b32 v1, v1, s[4:5]                            // 00000052AB38: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 00000052AB40: 8C7E017E
	s_cbranch_execz 65345                                      // 00000052AB44: BFA5FF41 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e4c>
	s_branch 1                                                 // 00000052AB48: BFA00001 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2150>
	s_branch 65343                                             // 00000052AB4C: BFA0FF3F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e4c>
	v_cmp_gt_i32_e32 vcc_lo, s16, v11                          // 00000052AB50: 7C881610
	.long 0xd44c0001                                           // 00000052AB54: D44C0001
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 00000052AB58: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 00000052AB5C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000052AB60: BC7C0000
	s_barrier                                                  // 00000052AB64: BFBD0000
	buffer_gl0_inv                                             // 00000052AB68: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000052AB70: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000052AB74: BF870009
	s_and_saveexec_b32 s3, s1                                  // 00000052AB78: BE832001
	s_cbranch_execz 65331                                      // 00000052AB7C: BFA5FF33 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e4c>
	v_and_b32_e32 v1, 15, v0                                   // 00000052AB80: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052AB84: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 00000052AB88: 30040282
	v_lshl_or_b32 v2, v11, 9, v2                               // 00000052AB8C: D6560002 0409130B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000052AB94: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 00000052AB98: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000052ABA0: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 00000052ABA8: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000052ABB0: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 00000052ABB8: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 00000052ABC0: 36140081
	s_waitcnt lgkmcnt(3)                                       // 00000052ABC4: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 2, v0    // 00000052ABC8: C9240702 0D0C0082
	s_waitcnt lgkmcnt(2)                                       // 00000052ABD0: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 00000052ABD4: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000052ABDC: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000052ABE0: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 00000052ABE8: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_sub_f32 v7, v8, v9     // 00000052ABEC: C94A0F06 06061308
	v_dual_add_f32 v8, v8, v9 :: v_dual_add_f32 v15, v13, v3   // 00000052ABF4: C9081308 080E070D
	v_and_b32_e32 v9, 4, v0                                    // 00000052ABFC: 36120084
	v_dual_add_f32 v14, v2, v4 :: v_dual_sub_f32 v3, v13, v3   // 00000052AC00: C90A0902 0E02070D
	s_delay_alu instid0(VALU_DEP_3)                            // 00000052AC08: BF870003
	v_dual_add_f32 v17, v5, v8 :: v_dual_add_f32 v16, v6, v7   // 00000052AC0C: C9081105 11100F06
	v_sub_f32_e32 v5, v5, v8                                   // 00000052AC14: 080A1105
	v_sub_f32_e32 v2, v2, v4                                   // 00000052AC18: 08040902
	v_sub_f32_e32 v4, v6, v7                                   // 00000052AC1C: 08080F06
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000052AC20: 7C941480
	v_dual_add_f32 v6, v14, v16 :: v_dual_add_f32 v7, v15, v17 // 00000052AC24: C908210E 0606230F
	v_sub_f32_e32 v8, v14, v16                                 // 00000052AC2C: 0810210E
	v_add_f32_e32 v14, v3, v5                                  // 00000052AC30: 061C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000052AC34: 08060B03
	v_dual_sub_f32 v10, v15, v17 :: v_dual_add_f32 v13, v2, v4 // 00000052AC38: C948230F 0A0C0902
	v_sub_f32_e32 v2, v2, v4                                   // 00000052AC40: 08040902
	v_mov_b32_dpp v4, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000052AC44: 7E0802FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000052AC4C: D5010007 21AA0F07
	s_delay_alu instid0(VALU_DEP_4)                            // 00000052AC54: BF870004
	v_mov_b32_dpp v15, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000052AC58: 7E1E02FA FF01610A
	v_mov_b32_dpp v18, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000052AC60: 7E2402FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000052AC68: D501000D 21AA1B0D
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000052AC70: D501000A 21AA150A
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000052AC78: 7E2602FA FF016103
	v_cndmask_b32_e64 v22, -v3, v3, vcc_lo                     // 00000052AC80: D5010016 21AA0703
	v_add_f32_e32 v3, v7, v4                                   // 00000052AC88: 06060907
	v_add_f32_e32 v7, v13, v18                                 // 00000052AC8C: 060E250D
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000052AC90: 7E0A02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000052AC98: D5010006 21AA0D06
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000052ACA0: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000052ACA8: D5010008 21AA1108
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000052ACB0: 7E2802FA FF016102
	v_cndmask_b32_e64 v21, -v2, v2, vcc_lo                     // 00000052ACB8: D5010015 21AA0502
	v_add_f32_e32 v2, v6, v5                                   // 00000052ACC0: 06040B06
	v_add_f32_e32 v5, v10, v15                                 // 00000052ACC4: 060A1F0A
	v_mov_b32_dpp v17, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000052ACC8: 7E2202FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000052ACD0: D501000E 21AA1D0E
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 00000052ACD8: 7C941880
	v_mov_b32_dpp v15, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000052ACDC: 7E1E02FA FF016207
	.long 0xd44a0001                                           // 00000052ACE4: D44A0001
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 00000052ACE8: 02021280
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000052ACEC: 7E1802FA FF016205
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000052ACF4: D5010007 21AA0F07
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000052ACFC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000052AD04: BF870232
	v_add_f32_e32 v15, v7, v15                                 // 00000052AD08: 061E1F07
	v_mov_b32_dpp v10, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000052AD0C: 7E1402FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000052AD14: D5010002 21AA0502
	v_add_f32_e32 v12, v5, v12                                 // 00000052AD1C: 06181905
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052AD20: BF870092
	v_add_f32_e32 v2, v2, v10                                  // 00000052AD24: 06041502
	v_cndmask_b32_e64 v10, -v2, v2, s1                         // 00000052AD28: D501000A 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000052AD30: 7E0402FA FF016402
	v_add_f32_e32 v4, v8, v16                                  // 00000052AD38: 06082108
	v_add_f32_e32 v8, v14, v17                                 // 00000052AD3C: 0610230E
	v_mov_b32_dpp v6, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000052AD40: 7E0C02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000052AD48: D5010003 21AA0703
	v_add_f32_e32 v5, v10, v2                                  // 00000052AD50: 060A050A
	v_mov_b32_dpp v13, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000052AD54: 7E1A02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000052AD5C: D5010004 21AA0904
	v_mov_b32_dpp v9, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000052AD64: 7E1202FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000052AD6C: D5010008 21AA1108
	v_mov_b32_dpp v10, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000052AD74: 7E1402FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 00000052AD7C: D501000C 2006190C
	v_add_f32_e32 v4, v4, v13                                  // 00000052AD84: 06081B04
	v_add_f32_e32 v14, v21, v20                                // 00000052AD88: 061C2915
	v_dual_add_f32 v8, v8, v9 :: v_dual_add_f32 v3, v3, v6     // 00000052AD8C: C9081308 08020D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000052AD94: BF870214
	v_add_f32_e32 v7, v12, v10                                 // 00000052AD98: 060E150C
	v_mov_b32_dpp v13, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000052AD9C: 7E1A02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 00000052ADA4: D5010004 20060904
	v_mov_b32_dpp v16, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000052ADAC: 7E2002FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000052ADB4: D501000E 21AA1D0E
	v_mov_b32_dpp v10, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000052ADBC: 7E1402FA FF016408
	v_mov_b32_dpp v6, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000052ADC4: 7E0C02FA FF016403
	v_dual_add_f32 v4, v4, v13 :: v_dual_add_f32 v13, v22, v19 // 00000052ADCC: C9081B04 040C2716
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000052ADD4: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000052ADDC: BF8701A2
	v_mov_b32_dpp v9, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000052ADE0: 7E1202FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000052ADE8: D501000D 21AA1B0D
	v_add_f32_e32 v3, v3, v6                                   // 00000052ADF0: 06060D03
	v_mov_b32_dpp v6, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000052ADF4: 7E0C02FA FF016805
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000052ADFC: BF870223
	v_add_f32_e32 v9, v13, v9                                  // 00000052AE00: 0612130D
	v_mov_b32_dpp v13, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000052AE04: 7E1A02FA FF01640F
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000052AE0C: 7E0402FA FF016803
	s_delay_alu instid0(VALU_DEP_3)                            // 00000052AE14: BF870003
	v_mov_b32_dpp v17, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000052AE18: 7E2202FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 00000052AE20: D5010009 20061309
	v_add_f32_e32 v12, v14, v16                                // 00000052AE28: 0618210E
	v_cndmask_b32_e64 v14, -v15, v15, s1                       // 00000052AE2C: D501000E 20061F0F
	v_cndmask_b32_e64 v15, -v8, v8, s1                         // 00000052AE34: D501000F 20061108
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000052AE3C: 7E1002FA FF016807
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000052AE44: BF870193
	v_add_f32_e32 v18, v14, v13                                // 00000052AE48: 06241B0E
	v_dual_add_f32 v16, v15, v10 :: v_dual_add_f32 v15, v9, v17// 00000052AE4C: C908150F 100E2309
	v_mov_b32_dpp v19, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000052AE54: 7E2602FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 00000052AE5C: D501000C 2006190C
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000052AE64: 7E1202FA FF016804
	v_mov_b32_dpp v14, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000052AE6C: 7E1C02FA FF016812
	v_mov_b32_dpp v10, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000052AE74: 7E1402FA FF01680F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000052AE7C: BF870124
	v_add_f32_e32 v17, v12, v19                                // 00000052AE80: 0622270C
	v_mov_b32_dpp v12, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000052AE84: 7E1802FA FF016810
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000052AE8C: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 00000052AE94: 8B7E007E
	s_cbranch_execz 65132                                      // 00000052AE98: BFA5FE6C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e4c>
	v_lshl_or_b32 v19, s2, 7, v1                               // 00000052AE9C: D6560013 04050E02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052AEA4: BF870091
	v_ashrrev_i32_e32 v20, 31, v19                             // 00000052AEA8: 3428269F
	.long 0xd73c0015                                           // 00000052AEAC: D73C0015
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 00000052AEB0: 02022681
	.long 0xd73c0013                                           // 00000052AEB4: D73C0013
	v_cndmask_b32_e32 v1, 2, v19, vcc_lo                       // 00000052AEB8: 02022682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052AEBC: BF870092
	.long 0xd7006a15                                           // 00000052AEC0: D7006A15
	v_cndmask_b32_e32 v1, s22, v21, vcc_lo                     // 00000052AEC4: 02022A16
	v_add_co_ci_u32_e64 v22, null, s23, v22, vcc_lo            // 00000052AEC8: D5207C16 01AA2C17
	s_clause 0x7                                               // 00000052AED0: BF850007
	global_load_d16_b16 v23, v[21:22], off offset:32           // 00000052AED4: DC820020 177C0015
	global_load_d16_b16 v24, v[21:22], off                     // 00000052AEDC: DC820000 187C0015
	global_load_d16_b16 v25, v[21:22], off offset:96           // 00000052AEE4: DC820060 197C0015
	global_load_d16_b16 v26, v[21:22], off offset:64           // 00000052AEEC: DC820040 1A7C0015
	global_load_d16_b16 v27, v[21:22], off offset:160          // 00000052AEF4: DC8200A0 1B7C0015
	global_load_d16_b16 v28, v[21:22], off offset:128          // 00000052AEFC: DC820080 1C7C0015
	global_load_d16_b16 v29, v[21:22], off offset:224          // 00000052AF04: DC8200E0 1D7C0015
	global_load_d16_b16 v21, v[21:22], off offset:192          // 00000052AF0C: DC8200C0 157C0015
	v_and_b32_e32 v22, 8, v0                                   // 00000052AF14: 362C0088
	v_mad_i64_i32 v[0:1], null, s18, v11, 0                    // 00000052AF18: D6FF7C00 02021612
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000052AF20: BF870112
	v_cmp_eq_u32_e32 vcc_lo, 0, v22                            // 00000052AF24: 7C942C80
	.long 0xd73c0000                                           // 00000052AF28: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000052AF2C: 02020082
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000052AF30: D5010005 21AA0B05
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000052AF38: D5010003 21AA0703
	v_cndmask_b32_e64 v11, -v16, v16, vcc_lo                   // 00000052AF40: D501000B 21AA2110
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000052AF48: D5010004 21AA0904
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000052AF50: D5010007 21AA0F07
	v_add_f32_e32 v5, v5, v6                                   // 00000052AF58: 060A0D05
	v_cndmask_b32_e64 v6, -v18, v18, vcc_lo                    // 00000052AF5C: D5010006 21AA2512
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 00000052AF64: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000052AF6C: D501000F 21AA1F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000052AF74: BF870214
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 00000052AF78: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v14 :: v_dual_add_f32 v6, v11, v12  // 00000052AF84: C9081D06 0506190B
	.long 0xd7006a00                                           // 00000052AF8C: D7006A00
	v_cndmask_b32_e32 v1, s28, v0, vcc_lo                      // 00000052AF90: 0202001C
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v7, v7, v8     // 00000052AF94: C9081304 04061107
	v_add_co_ci_u32_e64 v1, null, s29, v1, vcc_lo              // 00000052AF9C: D5207C01 01AA021D
	v_dual_add_f32 v8, v16, v13 :: v_dual_add_f32 v9, v15, v10 // 00000052AFA4: C9081B10 0808150F
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 00000052AFAC: C8C604FF 02040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000052AFB8: BF8700A4
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 00000052AFBC: C8C60CFF 06060EFF 3DB504F3
	.long 0xd7006a00                                           // 00000052AFC8: D7006A00
	v_cndmask_b32_e32 v1, v0, v19, vcc_lo                      // 00000052AFCC: 02022700
	v_add_co_ci_u32_e64 v1, null, v1, v20, vcc_lo              // 00000052AFD0: D5207C01 01AA2901
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_mul_f32 v9, 0x3db504f3, v9// 00000052AFD8: C8C608FF 040812FF 3DB504F3
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 00000052AFE4: 101010FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 00000052AFEC: BF891FF7
	v_fma_mix_f32 v3, v23, v3, neg(0) op_sel_hi:[1,0,0]        // 00000052AFF0: CC200003 8A020717
	s_waitcnt vmcnt(6)                                         // 00000052AFF8: BF891BF7
	v_fma_mix_f32 v2, v24, v2, neg(0) op_sel_hi:[1,0,0]        // 00000052AFFC: CC200002 8A020518
	s_waitcnt vmcnt(5)                                         // 00000052B004: BF8917F7
	v_fma_mix_f32 v5, v25, v5, neg(0) op_sel_hi:[1,0,0]        // 00000052B008: CC200005 8A020B19
	s_waitcnt vmcnt(4)                                         // 00000052B010: BF8913F7
	v_fma_mix_f32 v6, v26, v6, neg(0) op_sel_hi:[1,0,0]        // 00000052B014: CC200006 8A020D1A
	s_waitcnt vmcnt(3)                                         // 00000052B01C: BF890FF7
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 00000052B020: CC200004 8A02091B
	s_waitcnt vmcnt(2)                                         // 00000052B028: BF890BF7
	v_fma_mix_f32 v7, v28, v7, neg(0) op_sel_hi:[1,0,0]        // 00000052B02C: CC200007 8A020F1C
	s_waitcnt vmcnt(1)                                         // 00000052B034: BF8907F7
	v_fma_mix_f32 v8, v29, v8, neg(0) op_sel_hi:[1,0,0]        // 00000052B038: CC200008 8A02111D
	s_waitcnt vmcnt(0)                                         // 00000052B040: BF8903F7
	v_fma_mix_f32 v9, v21, v9, neg(0) op_sel_hi:[1,0,0]        // 00000052B044: CC200009 8A021315
	s_clause 0x7                                               // 00000052B04C: BF850007
	global_store_b32 v[0:1], v2, off                           // 00000052B050: DC6A0000 007C0200
	global_store_b32 v[0:1], v3, off offset:64                 // 00000052B058: DC6A0040 007C0300
	global_store_b32 v[0:1], v6, off offset:128                // 00000052B060: DC6A0080 007C0600
	global_store_b32 v[0:1], v5, off offset:192                // 00000052B068: DC6A00C0 007C0500
	global_store_b32 v[0:1], v7, off offset:256                // 00000052B070: DC6A0100 007C0700
	global_store_b32 v[0:1], v4, off offset:320                // 00000052B078: DC6A0140 007C0400
	global_store_b32 v[0:1], v9, off offset:384                // 00000052B080: DC6A0180 007C0900
	global_store_b32 v[0:1], v8, off offset:448                // 00000052B088: DC6A01C0 007C0800
	s_nop 0                                                    // 00000052B090: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000052B094: BFB60003
	s_endpgm                                                   // 00000052B098: BFB00000
		...

